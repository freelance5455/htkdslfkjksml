# Gato Noturno — versão 2

Protótipo de jogo runner 2D feito em HTML5 Canvas, CSS e JavaScript puro, sem bibliotecas externas. Abra `index.html` em um navegador moderno.

## Recursos implementados
- Menu inicial, tela de pausa e tela de fim de corrida.
- Jogo desenhado em Canvas com gato pixelado, obstáculos, pássaros e fragmentos colecionáveis.
- Controles de toque e teclado; botões de esquerda/direita, pulo, abaixar e pausa.
- Recorde local salvo via localStorage.
- Configurações de qualidade gráfica (econômica/normal/alta), partículas, tremor de tela e dificuldade (tranquila/normal/difícil).
- Orientação horizontal sugerida; o bloqueio de orientação depende do navegador/dispositivo.
- Código e comentários em português para facilitar a edição.

## Como executar
1. Extraia o ZIP.
2. Abra `Gato_Noturno/index.html` num navegador moderno ou editor Android com pré-visualização HTML.
3. Gire o aparelho para horizontal.

## Como editar
- As variáveis básicas de velocidade, gravidade e pulo estão em `CONFIG` no início do JavaScript.
- Cores principais estão nas variáveis CSS `:root`.
- Opções de qualidade e dificuldade estão no menu Configurações.

## Limitações honestas
Este é um protótipo, não um jogo completo. Não possui ainda campanha, XP/níveis, missões persistentes, árvore de habilidades, inventário RPG, skins desbloqueáveis, biomas, salvamento em nuvem ou APK pronto. O código foi verificado sintaticamente com `node --check`; não foi testado num aparelho Android físico nem em todos os navegadores. A orientação horizontal pode depender do suporte do navegador.
