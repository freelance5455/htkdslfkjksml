# Gato Noturno — protótipo

Jogo 2D de corrida noturna em HTML5 Canvas, CSS e JavaScript puro, sem dependências externas.

## Recursos implementados
- Cenário noturno com lua, estrelas e montanhas.
- Gato em pixel art de alto contraste.
- Obstáculos escuros com contorno claro para facilitar a leitura.
- Controles circulares na parte inferior: esquerda, direita, pular e abaixar.
- Pausa, som opcional, distância, fragmentos e recorde salvo localmente.
- Controles de toque e teclado.

## Executar
Abra `index.html` num navegador moderno. Para Android, pode abrir o HTML localmente num navegador compatível; a conversão para APK é uma etapa separada.

## Editar
- `CONFIG`, no começo do JavaScript: velocidade, gravidade, força do pulo e geração de obstáculos/fragmentos.
- `:root`, no CSS: cores da interface.
- Funções `draw()` e `background()`: visual de obstáculos e cenário.

## Limitações conhecidas
Este é um protótipo, não um jogo final nem um APK. Não foi testado em aparelho Android físico. Não estão implementados sistema de níveis/XP, missões, inventário RPG, skins, biomas, narrativa ou progressão avançada. O jogo cria obstáculos continuamente durante a partida, mas isso não significa geração infinita sem limites de desempenho.
