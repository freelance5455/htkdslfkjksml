import { describe, expect, it } from 'vitest';
import { initialBatteries, initialFaults, initialShuttles } from './mockData';

describe('Fleet seed data quality and provenance', () => {
  it('contains exactly the operator-reported fleet composition', () => {
    expect(initialShuttles).toHaveLength(5);
    expect(initialFaults).toEqual([]);
    expect(initialShuttles.filter((item) => item.manufacturer === 'Cassioli')).toHaveLength(3);
    expect(initialShuttles.filter((item) => item.manufacturer === 'Craftsman')).toHaveLength(1);
    expect(initialShuttles.filter((item) => item.manufacturer === 'ACME')).toHaveLength(1);
  });

  it('does not invent model names, serials or telemetry that were not supplied', () => {
    expect(initialShuttles.map((shuttle) => shuttle.model)).toEqual(Array(5).fill('Not recorded'));
    for (const shuttle of initialShuttles) {
      expect(shuttle.serialNumber).toBe('Not recorded');
      expect(shuttle.hardwareVersion).toBe('Not recorded');
      expect(shuttle.firmwareVersion).toBe('Not recorded');
      expect(shuttle.connectivity).toBe('UNKNOWN');
      expect(shuttle.operatingHours).toBeNull();
      expect(shuttle.operatingCycles).toBeNull();
      expect(shuttle.lastCommunication).toBe('Not connected');
    }
  });

  it('preserves the reported ACME HMI zero as unverified, not live telemetry', () => {
    const battery = initialBatteries.find((item) => item.manufacturer === 'ACME');
    expect(battery).toBeDefined();
    expect(battery?.soc).toBeNull();
    expect(battery?.status).toBe('Installed');
    expect(battery?.assignment).toBe('SC-05');
    expect(battery?.notes).toMatch(/Historical HMI 0% display was reported after repair/i);
    expect(battery?.connectionMode).toBe('UNKNOWN');
    expect(battery?.soh).toBeNull();
    expect(battery?.temperature).toBeNull();
    expect(battery?.voltage).toBeNull();
    expect(battery?.current).toBeNull();
  });
});
