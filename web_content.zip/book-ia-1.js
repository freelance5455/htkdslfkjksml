/* JOSTECH — MANUEL 05 : INTELLIGENCE ARTIFICIELLE NIVEAU 1 */
registerLessonDetail(5, 1, "ia-1-1-1", {
  title: "Leçon 1 : Fondements, IA Symbolique et Machine Learning",
  duration: "40 min (Manuel complet)",
  objectives: [
    "Retracer l'histoire de l'IA (Alan Turing 1950, conférence de Dartmouth 1956).",
    "Opposer l'approche Symbolique (règles expertes) et l'approche Connexionniste / Machine Learning.",
    "Distinguer IA Faible (spécialisée) et IA Forte théorique, ainsi que les enjeux éthiques."
  ],
  prerequisites: ["Notions d'algorithmique."],
  sections: [
    {
      type: "definition",
      term: "Intelligence Artificielle (IA) et Test de Turing",
      text: "Terme proposé en 1956 par John McCarthy lors de la conférence de Dartmouth. L'IA désigne l'ensemble des théories et techniques visant à créer des machines capables de simuler certaines facultés cognitives humaines : perception, raisonnement logique, apprentissage et prise de décision.\n\nEn 1950, Alan Turing propose le célèbre « Jeu de l'Imitation » (Test de Turing) : une machine réussit le test si un examinateur humain dialoguant par écrit avec elle et avec un humain ne parvient plus à distinguer lequel est la machine."
    },
    {
      type: "theory",
      title: "1. IA Symbolique vs Machine Learning",
      text: "Historiquement, deux grands paradigmes se sont succédé :\n• L'IA Symbolique (années 1950-1980) : on encode explicitement les connaissances humaines sous forme de règles SI... ALORS... (Systèmes Experts). Très utile pour le diagnostic logique strict, mais incapable de gérer le flou du monde réel (comment écrire en règles SI... ALORS... à quoi ressemble un chat sur 1 million de photos différentes ?).\n• Le Machine Learning (Apprentissage automatique) : au lieu de programmer les règles à la main, on fournit à l'algorithme des milliers d'exemples étiquetés et on le laisse ajuster lui-même ses paramètres mathématiques."
    },
    {
      type: "table",
      title: "2. IA Faible vs IA Forte",
      headers: ["Catégorie", "Capacités", "Réalité actuelle"],
      rows: [
        ["IA Faible (Étroite)", "Excellente sur une tâche précise (échecs, traduction, chat, vision).", "100 % des IA actuelles (y compris les grands LLM)."],
        ["IA Générale (Forte)", "Compréhension consciente universelle égale à l'humain.", "Pure hypothèse de recherche, n'existe pas aujourd'hui."]
      ]
    },
    {
      type: "warning",
      title: "Pièges et Éthique (Biais des données)",
      text: "« Garbage In, Garbage Out » : une IA n'est pas neutre. Si une IA de recrutement est entraînée sur d'anciens dossiers humains biaisés ou incomplets, elle reproduira et amplifiera automatiquement ces discriminations."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Choisir entre Programmation classique et ML",
      question: "Indiquez la meilleure approche pour :\n1) Calculer la TVA (16 %) d'une facture.\n2) Détecter automatiquement une tumeur sur une radio médicale.",
      solution: "1) Programmation classique (règle mathématique exacte et invariable).\n2) Machine Learning / Vision par ordinateur (motifs visuels trop complexes pour des règles manuelles)."
    },
    {
      title: "Exercice 2 — Réflexion sur le Test de Turing",
      question: "Une IA qui réussit le Test de Turing en dialoguant en français possède-t-elle forcément une conscience humaine ?",
      solution: "Non ! Comme l'illustre l'expérience de la Chambre Chinoise (John Searle), une machine peut manipuler des symboles statistiques de façon convaincante sans aucune compréhension consciente."
    }
  ],
  summary: "L'IA oppose historiquement les systèmes à règles symboliques à l'apprentissage automatique par les données. Toutes les applications actuelles relèvent de l'IA faible spécialisée.",
  references: ["Turing, A. (1950) — Computing Machinery and Intelligence.", "Russell & Norvig — Artificial Intelligence: A Modern Approach."]
});