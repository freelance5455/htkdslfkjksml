# Hero Survivors — Android Build Guide

This folder is a ready-to-build **Capacitor** project that wraps the
`www/index.html` game (a single self-contained HTML5 file) into a real
Android app you can publish to Google Play.

This can't be compiled in this sandbox (no network access, no Android SDK,
no signing keys here) — everything below runs on **your own machine**.

## 0. One-time setup on your machine

Install these first if you don't already have them:

1. **Node.js LTS** (18+): https://nodejs.org
2. **Android Studio** (includes the Android SDK): https://developer.android.com/studio
3. A **JDK** (Android Studio bundles one — you usually don't need a separate install)

## 1. Install dependencies

```bash
cd android-package
npm install
```

## 2. Add the Android platform

```bash
npx cap add android
```

This generates an `android/` folder — a full native Android Studio project
that loads `www/index.html` in a WebView.

## 3. Sync the web assets into the native project

```bash
npx cap sync android
```

Run this again any time you update `www/index.html` with a new game build.

## 3a. AdMob setup (rewarded ads for the Revive flow)

The game's `RewardedAd.show()` (in `www/index.html`) already auto-detects
whether it's running natively with the AdMob plugin installed — if so it
shows a real rewarded ad; otherwise it falls back to a mock overlay (used
when just previewing the HTML in a browser). `@capacitor-community/admob`
is already listed in `package.json` and your App ID is already set in
`capacitor.config.json`, so `npm install` + `npx cap sync` (steps 1 and 3
above) pull in and wire up the plugin automatically.

**One manual step is still required** — the AdMob SDK requires your App ID
to also be declared directly in the Android manifest, or the app will
crash on launch. After running `npx cap add android` (step 2), open
`android/app/src/main/AndroidManifest.xml` and add this inside the
`<application>` tag:

```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-1374968715711516~8406492604"/>
```

Your ad unit is already set in `MonetizationConfig.admob.rewardedUnitId`
inside `www/index.html` (`ca-app-pub-1374968715711516/8833778720`) — no
further code changes needed for the rewarded/revive placement.

**Before you ship:**
- Test with a real device or emulator first. AdMob may show blank/test
  fill for a new ad unit for the first few hours to days after creation —
  this is normal.
- Only one ad unit (rewarded video) is wired up, powering the Revive
  button. If you want an interstitial or banner placement too, create
  those ad units in the AdMob console, add their IDs to
  `MonetizationConfig.interstitialUnitId` etc. in `www/index.html`, and add
  the matching plugin calls (`AdMob.prepareInterstitial()` /
  `showInterstitial()`, or a `BannerAd` component) following the
  [`@capacitor-community/admob` docs](https://github.com/capacitor-community/admob) —
  the plugin's exact method/event names can shift between major versions,
  so check against whichever version `npm install` actually resolves.
- Per Play Store policy, you must disclose ad usage and complete the Data
  Safety form (see step 7) — AdMob collects an advertising ID.

## 4. Open in Android Studio

```bash
npx cap open android
```

In Android Studio:

- **App icon**: right-click `app/src/main/res` → New → Image Asset → set
  your launcher icon (512×512 source recommended).
- **App name / package name**: already set via `capacitor.config.json`
  (`com.herosurvivors.game` / "Hero Survivors") — change the `appId` in that
  file *before* running `cap add android` if you want a different package name
  (it's baked into the generated project).
- **Version**: edit `android/app/build.gradle` → `versionCode` (integer,
  increment every release) and `versionName` (string shown to users, e.g. "1.0.0").
- **Orientation**: the game is designed for portrait phones. In
  `android/app/src/main/AndroidManifest.xml`, set on the `<activity>` tag:
  `android:screenOrientation="portrait"`.
- **Splash screen**: Capacitor's default splash is fine to start; customize
  later via the `@capacitor/splash-screen` plugin if desired.

## 5. Test on a device/emulator

Click ▶ Run in Android Studio, or:

```bash
npx cap run android
```

## 6. Build a release bundle for Play Store

In Android Studio: **Build → Generate Signed Bundle / APK → Android App
Bundle (.aab)**.

- Create a new keystore the first time (Android Studio walks you through
  this) — **back up this keystore file and its passwords somewhere safe**;
  losing it means you can never update the app again under the same listing.
- Choose the `release` build variant.
- This produces `app-release.aab` — this is the file you upload to Play
  Console, not an `.apk`.

## 7. Play Console checklist

- Create an app in [Play Console](https://play.google.com/console)
- Store listing: title, short description (80 chars), full description,
  screenshots (min 2, phone 16:9), feature graphic (1024×500), app icon (512×512)
- Content rating questionnaire (this is a mild cartoon violence game — expect
  something like PEGI 7 / Everyone 10+, but the questionnaire decides)
- Privacy policy URL — **required** even if the app collects no data; a
  simple hosted page stating "no personal data is collected, no ads, no
  tracking" is sufficient given the current build
- Data safety form — declare no data collection (true as of this build:
  everything is stored locally via `localStorage`, nothing is sent anywhere)
- Upload the `.aab`, set a release track (start with **Internal testing**
  before Production), and roll out

## Notes on the current build

- **Rewarded AdMob ads are wired up** for the Revive flow (see step 3a) —
  the game will attempt a real ad natively and only falls back to a mock
  when running outside the native app. **No interstitial/banner ads or
  IAP are wired up yet.**
- Because ads are now live, you **must** complete the Data Safety form
  honestly this time — AdMob collects an advertising ID and (depending on
  your consent/config) other data for ad personalization. Google's own
  [AdMob Data Safety guidance](https://support.google.com/admob/answer/11322340)
  walks through exactly what to declare.
- A **privacy policy URL is now mandatory**, not just good practice, since
  the app serves ads — it must disclose AdMob's data collection.
- **Debug/playground panel is disabled by default** in this build (it only
  activates with `?debug=1` in the URL, which doesn't apply inside the
  packaged WebView, so it's effectively unreachable to end users).
- Progress (high score, banked coins, permanent upgrades) is stored in the
  WebView's `localStorage`, which persists across app launches on the same
  device but is lost if the user clears app data or uninstalls.
- If you later add IAP, you'll need the `@capacitor-community/in-app-purchases`
  (or similar) plugin and to update the Data Safety form again.

## Updating the game after this point

Whenever the HTML game file changes:

```bash
cp path/to/new-index.html www/index.html
npx cap sync android
```

Then rebuild the signed bundle as in step 6.
