-- ScoreDeck Patch 3 Phase 1 follow-up migration (additive, no existing rows changed)
-- Run in Supabase SQL Editor as project owner.
create or replace function public.scoredeck_admin_registered_accounts()
returns table (user_id uuid, display_name text, class_level text, account_created_at timestamptz, role text)
language plpgsql stable security definer set search_path = ''
as $$
begin
 if auth.uid() is null or not exists (select 1 from public.scoredeck_admin_roles r where r.user_id=auth.uid() and r.role='owner') then
  raise exception 'Owner permission required';
 end if;
 return query select p.id, coalesce(nullif(p.display_name,''),'ScoreDeck user'), p.class_level, p.created_at, coalesce(r.role,'user')
 from public.profiles p left join public.scoredeck_admin_roles r on r.user_id=p.id order by p.created_at desc;
end; $$;
revoke all on function public.scoredeck_admin_registered_accounts() from public, anon;
grant execute on function public.scoredeck_admin_registered_accounts() to authenticated;

-- Admin-only aggregate from session records; works even if older clients did not maintain user_stats totals.
create or replace function public.scoredeck_admin_focus_totals()
returns table (user_id uuid, focus_seconds bigint, focus_sessions bigint)
language plpgsql stable security definer set search_path = ''
as $$
begin
 if auth.uid() is null or not exists (select 1 from public.scoredeck_admin_roles r where r.user_id=auth.uid() and r.role in ('owner','co_admin')) then
  raise exception 'Admin permission required';
 end if;
 return query select p.id, coalesce(sum(fs.duration_seconds),0)::bigint, count(fs.id)::bigint
 from public.profiles p left join public.focus_sessions fs on fs.user_id=p.id and fs.status='completed' group by p.id;
end; $$;
revoke all on function public.scoredeck_admin_focus_totals() from public, anon;
grant execute on function public.scoredeck_admin_focus_totals() to authenticated;
