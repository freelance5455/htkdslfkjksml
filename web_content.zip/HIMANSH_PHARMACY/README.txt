HIMANSH PHARMACY - Offline HTML app package

Files:
- index.html: Pharmacy billing/inventory application.

How to use:
1. Extract this ZIP.
2. Open index.html with Chrome on Android or a desktop browser.
3. Data is stored in the browser's local storage on that device.
4. Use Settings > Download Backup JSON regularly.

Notes:
- This ZIP contains the HTML application, not a compiled Android APK.
- For APK packaging, the HTML can be placed in an Android WebView project and built with Android Studio.
