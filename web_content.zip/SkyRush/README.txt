SKY RUSH V2
- index.html is the complete game in one file (HTML, CSS and JavaScript).
- 30 level-based stages with unlock progression.
- Endless mode.
- Collectible coins and 8 purchasable/equippable characters.
- Coins, best score, unlocked levels and owned/equipped characters save on this device.
- Touch controls; keyboard controls also work.
- Gentle controls and gradual difficulty.

ACODE:
1. Extract the ZIP.
2. Open SkyRush/index.html in Acode and Preview it.

MIT APP INVENTOR:
1. Upload index.html in Media/Assets.
2. Add a WebViewer; set Width and Height to Fill parent.
3. Set HomeUrl to the local asset path supported by your WebViewer version (commonly file:///android_asset/index.html).
4. Build and test the APK. If local assets do not load, check the WebViewer asset-path instructions for your App Inventor version.
