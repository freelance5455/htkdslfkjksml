ARCAD WORLD OWNER — AUTOMATIC DISCOVERY BUILD
================================================

This package changes the owner app so that it no longer asks the owner to type
LAN addresses, VPN URLs, or API tokens. It preserves the existing dashboard
structure, navigation, Arcad World logo, and navy/teal/gold styling.

AUTOMATIC LOCAL DISCOVERY
-------------------------
The Android app uses Android Network Service Discovery (DNS-SD / mDNS) to find
a Windows CRM service advertised as:

    Service type: _arcad-crm._tcp.
    Port:         8443 (recommended; may be changed in the Windows service)

The Windows CRM must advertise that service on the local network and provide
an HTTPS API at the discovered host and port. The required health endpoint is:

    GET /api/v1/health
    Response: {"status":"ok"}

ANDROID NATIVE PLUGIN
---------------------
1. Install Node.js LTS and Android Studio.
2. From this project folder run:
       npm install
       npx cap add android
       npx cap sync android
3. Copy android-native/app/src/main/java/com/arcadworld/owner/ArcadDiscoveryPlugin.java
   into the generated Android app at the matching Java package path.
4. In the generated MainActivity.java, register the plugin:

       import com.arcadworld.owner.ArcadDiscoveryPlugin;
       import com.getcapacitor.BridgeActivity;

       public class MainActivity extends BridgeActivity {
           @Override
           public void onCreate(android.os.Bundle savedInstanceState) {
               registerPlugin(ArcadDiscoveryPlugin.class);
               super.onCreate(savedInstanceState);
           }
       }

5. Ensure Android manifest includes:
       <uses-permission android:name="android.permission.INTERNET" />
       <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
       <uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" />
   Android versions with nearby-device / local-network permission requirements
   must be handled according to the target SDK and device version.
6. Rebuild in Android Studio.

WINDOWS CRM REQUIREMENTS
------------------------
The desktop CRM must be updated to:
- Run a background HTTPS API service.
- Advertise _arcad-crm._tcp. with DNS-SD/mDNS on the local LAN.
- Provide /api/v1/health and authenticated, owner-authorized data endpoints.
- Use a certificate trusted by the Android app. Do not disable certificate checks.
- Approve/enroll the owner's Android device securely.
- Restrict the API with Windows Firewall to trusted interfaces.
- Provide remote discovery through a private VPN / private DNS name. mDNS does
  not cross routers or the public internet; remote access cannot be discovered
  by local Wi-Fi scanning alone.

IMPORTANT LIMITATIONS
---------------------
This is the rebuilt Android source and local discovery client. It is not yet a
compiled APK and cannot connect to a Windows CRM until the desktop service
advertises the required service and implements the HTTPS API. The app retries
local discovery automatically. Remote discovery, device enrollment, live data
endpoints, and full certificate provisioning must be implemented and tested
alongside the Windows CRM. No dashboard figures are fabricated as live data.


OWNER NAVIGATION UPDATE
-----------------------
The owner app now uses the requested five-item navigation:
Overview, Employees, Attendance, Reports, Alerts.
On Android it is a fixed bottom navigation bar with a highlighted active item,
safe-area spacing, and responsive sizing. Connection settings remain available
from the connection status control in the header and from Overview quick access.
Sales remains available through Overview quick access.


BRANDING UPDATE
---------------
Updated the Arcad World logo to match the user's preferred Owner Console
reference: circular A emblem with teal and gold rings, ARCAD in white,
WORLD in teal, and OWNER CRM subtitle. The logo remains a scalable SVG
asset and is used in the app header.


DEVELOPER CREDIT & TECHNICAL SUPPORT
------------------------------------
The app footer credits Sidh as the developer.
A Technical Support dialog provides:
- Call Sidh: opens the device dialler with +971506925451; the user confirms the call.
- WhatsApp: opens a chat to +971506925451.
- Email: opens a support email draft to Sidhique@arc4gamers.com.
Unexpected JavaScript errors and unhandled promise failures open the support dialog.
Routine automatic discovery failures do not repeatedly interrupt the owner with popups.

The approved dashboard, theme, logo and five-tab navigation are preserved.
This package is Android source code, not a compiled APK. The native discovery
plugin and the matching Windows CRM service must be installed/configured and tested.


ANDROID SUPPORT BUTTON FIX
--------------------------
The support actions no longer use raw tel: links inside the WebView.
They call a registered Capacitor native plugin instead:
- Call Sidh uses Android ACTION_DIAL (opens the dialler; user confirms the call).
- WhatsApp opens https://wa.me/971506925451 through Android.
- Email opens a mailto draft to Sidhique@arc4gamers.com.

MainActivity.java registers both ArcadDiscoveryPlugin and SupportContactPlugin.
Copy the supplied Java files into the generated Android app package path, replacing
the generated MainActivity.java with the supplied registration version. Then run:
  npm install
  npx cap add android   (only if android/ does not exist yet)
  npx cap sync android
  npx cap open android

Build and test the installed APK on a physical Android device. The browser/web
preview cannot launch Android phone, WhatsApp, or email apps; this is expected.

SAME-WI-FI OWNER TEST (current source update)
---------------------------------------------
This source now has a small manual connection for the supplied Arc Quo desktop
bridge. It fetches only the test sales and attendance records from
http://<laptop-ip>:8766/api/test/records and sends a Bearer token. The previous
automatic HTTPS discovery description above belongs to the earlier build and
is not used by this local test path.

Build source: install Node.js and Android Studio, run npm install, npx cap add
android (if needed), npx cap sync android, then open/build from Android Studio.
Because this test uses HTTP, the generated android/app/src/main/AndroidManifest.xml
must allow cleartext traffic on the application element:
    android:usesCleartextTraffic="true"
The supplied capacitor.config.json sets androidScheme to http. Re-run npx cap
sync android after changing it. Install the debug APK on a physical Android
phone. Enter the laptop's private IPv4 address and token shown in the desktop
page, then use Save and connect or Refresh records.

Use only on trusted private Wi-Fi with sample data. The bearer token and records
are not encrypted in transit. This is not suitable for production or public
networks. No APK is included, and live device-to-desktop integration has not
been verified from these source archives.
Confirm the generated app manifest also includes the Android INTERNET permission
(the Capacitor generated project normally supplies this). No Nearby Devices or
mDNS permission is required by this manual-IP test path.
