package com.arcadworld.owner;

import android.content.Intent;
import android.net.Uri;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "SupportContact")
public class SupportContactPlugin extends Plugin {
    @PluginMethod
    public void dial(PluginCall call) {
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:+971506925451"));
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Unable to open the phone dialler.", e);
        }
    }

    @PluginMethod
    public void whatsapp(PluginCall call) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/971506925451"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Unable to open WhatsApp. Please check whether it is installed.", e);
        }
    }

    @PluginMethod
    public void email(PluginCall call) {
        try {
            Intent intent = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("mailto:Sidhique@arc4gamers.com?subject=Arcad%20World%20Owner%20CRM%20Support"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Unable to open an email application.", e);
        }
    }
}
