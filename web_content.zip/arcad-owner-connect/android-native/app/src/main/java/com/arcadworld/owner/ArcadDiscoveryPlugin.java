package com.arcadworld.owner;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.InetAddress;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "ArcadDiscovery")
public class ArcadDiscoveryPlugin extends Plugin {
    private NsdManager nsd;
    private NsdManager.DiscoveryListener activeListener;

    @PluginMethod
    public void discover(PluginCall call) {
        final String serviceType = call.getString("serviceType", "_arcad-crm._tcp.");
        final int timeoutMs = call.getInt("timeoutMs", 6000);
        final AtomicBoolean finished = new AtomicBoolean(false);
        final Handler handler = new Handler(Looper.getMainLooper());
        nsd = (NsdManager) getContext().getSystemService(Context.NSD_SERVICE);

        if (nsd == null) {
            call.reject("Android network service discovery is unavailable.");
            return;
        }

        Runnable timeout = () -> {
            if (finished.compareAndSet(false, true)) {
                stopDiscovery();
                call.resolve();
            }
        };

        activeListener = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String type) { }
            @Override public void onStartDiscoveryFailed(String type, int error) {
                if (finished.compareAndSet(false, true)) {
                    handler.removeCallbacks(timeout);
                    stopDiscovery();
                    call.reject("Could not start local network discovery. Error " + error);
                }
            }
            @Override public void onStopDiscoveryFailed(String type, int error) { }
            @Override public void onDiscoveryStopped(String type) { }
            @Override public void onServiceLost(NsdServiceInfo service) { }
            @Override public void onServiceFound(NsdServiceInfo service) {
                if (!serviceType.equals(service.getServiceType())) return;
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        nsd.registerServiceInfoCallback(service, getContext().getMainExecutor(),
                            new NsdManager.ServiceInfoCallback() {
                                @Override public void onServiceUpdated(NsdServiceInfo info) {
                                    resolveFound(info);
                                }
                                @Override public void onServiceLost() { }
                                @Override public void onServiceInfoCallbackRegistrationFailed(int error) { }
                                @Override public void onServiceInfoCallbackUnregistered() { }
                            });
                    } else {
                        nsd.resolveService(service, new NsdManager.ResolveListener() {
                            @Override public void onResolveFailed(NsdServiceInfo info, int error) { }
                            @Override public void onServiceResolved(NsdServiceInfo info) {
                                resolveFound(info);
                            }
                        });
                    }
                } catch (Exception ignored) { }
            }
            private void resolveFound(NsdServiceInfo info) {
                if (!finished.compareAndSet(false, true)) return;
                handler.removeCallbacks(timeout);
                stopDiscovery();
                InetAddress host = info.getHost();
                int port = info.getPort();
                JSObject result = new JSObject();
                result.put("host", host == null ? "" : host.getHostAddress());
                result.put("port", port);
                result.put("serviceName", info.getServiceName());
                // The Windows service must advertise a trusted HTTPS endpoint.
                // The advertised host/port are returned; certificate validation remains enforced by HTTPS.
                result.put("url", "https://" + (host == null ? "" : host.getHostAddress()) + ":" + port);
                call.resolve(result);
            }
        };

        try {
            nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, activeListener);
            handler.postDelayed(timeout, Math.max(1500, Math.min(timeoutMs, 15000)));
        } catch (Exception e) {
            if (finished.compareAndSet(false, true)) call.reject("Discovery failed: " + e.getMessage());
        }
    }

    private void stopDiscovery() {
        if (nsd != null && activeListener != null) {
            try { nsd.stopServiceDiscovery(activeListener); } catch (Exception ignored) { }
            activeListener = null;
        }
    }

    @Override
    protected void handleOnDestroy() {
        stopDiscovery();
        super.handleOnDestroy();
    }
}
