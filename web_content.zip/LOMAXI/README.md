# LOMAXI — playable prototype 0.1

LOMAXI is an original Roblox-inspired 3D sandbox prototype with:
- Third-person block avatar and starter island
- Desktop keyboard and mouse controls
- Android/tablet touchscreen joystick, camera drag, jump and place buttons
- Collectible crystals
- Creative block placement
- Solo mode and a local multiplayer *demo* with three simulated visitors
- Responsive interface and adjustable renderer pixel ratio

## Run it
This prototype uses Three.js from jsDelivr, so it needs an internet connection.
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run a local static server, for example:
   `python -m http.server 8000`
4. Open `http://localhost:8000` in a modern browser.

On Android, host the folder on a static web host and open the URL in Chrome. For a native APK, wrap the web project with Capacitor or build an Android Studio WebView shell.

## Current limitations
- Multiplayer is a local visual demo only; it does not connect players over the internet.
- Accounts, cloud saves, chat, moderation, publishing, payments and a full visual scripting editor are not implemented.
- This is a starter project, not a finished Roblox-scale platform.

## Suggested next milestones
1. Add real online multiplayer using an authoritative server (for example, Colyseus).
2. Add accounts, friends, parental/safety controls and report/block tools.
3. Add persistent worlds and creator publishing.
4. Package the client for Android with Capacitor and create desktop builds.
