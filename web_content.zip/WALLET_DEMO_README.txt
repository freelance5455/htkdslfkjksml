REDBROWSER REDD RILLION WALLET — LOCAL DEMO

This ZIP adds local demo-only wallet creation, a 12-word demo recovery phrase, simulated balance, simulated receive/send entries, transaction history export, lock, recovery, and delete.

IMPORTANT LIMITATIONS
- This is NOT a cryptocurrency wallet and is NOT connected to any blockchain.
- The starting 100 RRD and all transactions are simulated. No funds move.
- The phrase is a demo recovery token, not a BIP-39 or blockchain seed phrase.
- Data is stored in browser localStorage. This is not secure key storage; the demo password is only checked during creation and is not encryption.
- Do not use real seed phrases, private keys, or real money with this prototype.
- Real wallets require a carefully reviewed wallet library, key derivation and encrypted key storage, secure recovery design, chain integration, transaction signing, fee estimation, RPC/backend infrastructure, and security audits.
