const CACHE='alichat-v3.6';
const SHELL=['/','/manifest.webmanifest','/sw.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).pathname.startsWith('/api/'))return;e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(CACHE).then(x=>x.put(e.request,c));return r}).catch(()=>caches.match(e.request).then(r=>r||caches.match('/'))));});
self.addEventListener('push',e=>{let d={title:'AliChat',body:'پیام جدید'};try{d=Object.assign(d,e.data?.json()||{})}catch{};e.waitUntil(self.registration.showNotification(d.title,{body:d.body,tag:d.tag||'alichat',data:{room:d.room||''},dir:'rtl',lang:'fa'}));});
self.addEventListener('notificationclick',e=>{e.notification.close();const room=e.notification.data?.room||'';e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{for(const c of cs){if(room)c.postMessage({type:'open-room',room});return c.focus()}return clients.openWindow('/')}));});
self.addEventListener('sync',e=>{if(e.tag==='alichat-outbox')e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>cs.forEach(c=>c.postMessage({type:'flush-outbox'}))));});
