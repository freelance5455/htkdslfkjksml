# AliChat V1.5

امکانات: چت خصوصی WebRTC، چت گروهی WebSocket، مدیریت گروه، نام و تصویر گروه، لینک دعوت، مدیر، حذف عضو و ذخیره‌ی اطلاعات گروه در groups.json.

## اجرا
```bash
npm install
npm start
```
سپس http://localhost:3000 را باز کنید.
