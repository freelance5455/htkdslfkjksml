# AliChat V3.6

V3.6 adds offline-first behavior, Web Push, message synchronization, resilient WebSocket handling, and PostgreSQL/Redis migration readiness.

## Run

```bash
npm install
npm start
```

Node.js 22.5+ is required.

## Push notifications
Set `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, and `VAPID_SUBJECT`. Push requires HTTPS in production (localhost is allowed by browsers).

## Offline and sync
The service worker caches the app shell. Messages created while the WebSocket is unavailable are kept in the browser outbox and sent after reconnection. Every outgoing message has a `clientId`; the server deduplicates retries and returns an ACK. `/api/sync` fills message gaps after reconnect.

## PostgreSQL / Redis
`pg` and `redis` are included as migration/runtime dependencies. `DATABASE_URL` and `REDIS_URL` are documented. SQLite remains the default local store so the project runs without external services. A future production migration can move persistence to PostgreSQL and presence/pub-sub to Redis without changing the browser message protocol.

## WebSocket
The server sends ping frames every 25 seconds and terminates stale connections. The browser reconnects automatically and synchronizes the current room after reconnect.
