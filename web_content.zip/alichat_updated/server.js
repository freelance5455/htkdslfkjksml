const http=require('http'),fs=require('fs'),path=require('path'),WebSocket=require('ws');
const PORT=process.env.PORT||3000, DATA=path.join(__dirname,'groups.json');
let groups={}; try{groups=JSON.parse(fs.readFileSync(DATA,'utf8'))}catch{}
const save=()=>fs.writeFileSync(DATA,JSON.stringify(groups,null,2));
const server=http.createServer((req,res)=>{let p=req.url.split('?')[0];if(p==='/')p='/index.html';const file=path.join(__dirname,p);fs.readFile(file,(e,d)=>{if(e){res.writeHead(404);return res.end('Not found')}res.writeHead(200,{'Content-Type':({'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json'}[path.extname(file)]||'application/octet-stream')});res.end(d)})});
const wss=new WebSocket.Server({server}),rooms=new Map();
const id=()=>Math.random().toString(36).slice(2,10); const token=()=>Math.random().toString(36).slice(2,12);
function send(ws,m){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(m))} function members(room){return [...(rooms.get(room)||[])].map(x=>({id:x.user.id,name:x.user.name,admin:x.user.id===groups[room]?.adminId}))}
function broadcast(room,m,except){for(const p of rooms.get(room)||[])if(p!==except)send(p,m)}
wss.on('connection',ws=>{ws.room=null;ws.user={id:id(),name:'کاربر'};
 ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
  if(m.type==='join'){ws.room=String(m.room||'ali-room').slice(0,80);ws.user.name=String(m.name||'کاربر').slice(0,40);if(!groups[ws.room]){groups[ws.room]={name:ws.room,avatar:'',adminId:ws.user.id,invite:token(),createdAt:Date.now()};save()} if(!rooms.has(ws.room))rooms.set(ws.room,new Set());rooms.get(ws.room).add(ws);send(ws,{type:'group-info',group:groups[ws.room],members:members(ws.room)});broadcast(ws.room,{type:'member-joined',member:{id:ws.user.id,name:ws.user.name}},ws);return}
  if(!ws.room)return;
  if(m.type==='group-message'){broadcast(ws.room,{type:'group-message',id:ws.user.id,name:ws.user.name,text:String(m.text||'').slice(0,5000),time:Date.now()},null);return}
  if(m.type==='group-file'){broadcast(ws.room,{type:'group-file',id:ws.user.id,name:ws.user.name,file:m.file},null);return}
  if(m.type==='group-update'){let g=groups[ws.room];if(g&&g.adminId===ws.user.id){g.name=String(m.name||g.name).slice(0,80);g.avatar=String(m.avatar||'').slice(0,500000);save();broadcast(ws.room,{type:'group-updated',group:g},null)}}
  if(m.type==='group-remove'){let g=groups[ws.room];if(g&&g.adminId===ws.user.id){for(const p of rooms.get(ws.room)||[])if(p.user.id===m.memberId){send(p,{type:'removed'});p.close()}}}
 });
 ws.on('close',()=>{if(ws.room&&rooms.has(ws.room)){const set=rooms.get(ws.room);set.delete(ws);broadcast(ws.room,{type:'member-left',member:ws.user},null);if(!set.size)rooms.delete(ws.room)}})
});
server.listen(PORT,()=>console.log(`AliChat V1.5 running on http://localhost:${PORT}`));
