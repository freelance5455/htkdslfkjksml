(function () {
  'use strict';
  const H = window.Horary;
  const $ = (id) => document.getElementById(id);
  const VS = '︎'; // принуждава текстов (не емоджи) вид на символите

  /* ---------- градове: [група, име, ширина, дължина] ---------- */
  const CITIES = [
    ['България', 'София', 42.6977, 23.3219], ['България', 'Пловдив', 42.1354, 24.7453], ['България', 'Варна', 43.2141, 27.9147],
    ['България', 'Бургас', 42.5048, 27.4626], ['България', 'Русе', 43.8356, 25.9657], ['България', 'Стара Загора', 42.4258, 25.6345],
    ['България', 'Плевен', 43.4170, 24.6067], ['България', 'Сливен', 42.6817, 26.3229], ['България', 'Добрич', 43.5726, 27.8273],
    ['България', 'Шумен', 43.2706, 26.9361], ['България', 'Перник', 42.6052, 23.0378], ['България', 'Хасково', 41.9344, 25.5554],
    ['България', 'Ямбол', 42.4842, 26.5035], ['България', 'Пазарджик', 42.1928, 24.3336], ['България', 'Благоевград', 42.0209, 23.0943],
    ['България', 'Велико Търново', 43.0757, 25.6172], ['България', 'Враца', 43.2102, 23.5529], ['България', 'Габрово', 42.8742, 25.3187],
    ['България', 'Видин', 43.9900, 22.8725], ['България', 'Монтана', 43.4085, 23.2257], ['България', 'Кърджали', 41.6338, 25.3777],
    ['България', 'Кюстендил', 42.2839, 22.6911], ['България', 'Търговище', 43.2512, 26.5723], ['България', 'Силистра', 44.1147, 27.2672],
    ['България', 'Разград', 43.5333, 26.5167], ['България', 'Смолян', 41.5774, 24.7011], ['България', 'Ловеч', 43.1370, 24.7144],
    ['България', 'Сандански', 41.5666, 23.2813], ['България', 'Несебър', 42.6591, 27.7357], ['България', 'Банско', 41.8383, 23.4885],
    ['България', 'Асеновград', 42.0128, 24.8761], ['България', 'Димитровград', 42.0500, 25.6000], ['България', 'Казанлък', 42.6194, 25.3930],
    ['България', 'Свищов', 43.6186, 25.3500], ['България', 'Горна Оряховица', 43.1270, 25.6990], ['България', 'Дупница', 42.2667, 23.1167],
    ['България', 'Петрич', 41.3960, 23.2070], ['България', 'Севлиево', 43.0233, 25.1167], ['България', 'Карлово', 42.6364, 24.8084],
    ['България', 'Самоков', 42.3370, 23.5530], ['България', 'Велинград', 42.0270, 23.9910], ['България', 'Гоце Делчев', 41.5700, 23.7300],
    ['България', 'Свиленград', 41.7700, 26.2000], ['България', 'Созопол', 42.4167, 27.6958],
    ['Другаде', 'Атина', 37.9838, 23.7275], ['Другаде', 'Солун', 40.6401, 22.9444], ['Другаде', 'Никозия', 35.1856, 33.3823],
    ['Другаде', 'Истанбул', 41.0082, 28.9784], ['Другаде', 'Букурещ', 44.4268, 26.1025], ['Другаде', 'Белград', 44.7866, 20.4489],
    ['Другаде', 'Скопие', 41.9981, 21.4254], ['Другаде', 'Загреб', 45.8150, 15.9819], ['Другаде', 'Виена', 48.2082, 16.3738],
    ['Другаде', 'Прага', 50.0755, 14.4378], ['Другаде', 'Варшава', 52.2297, 21.0122], ['Другаде', 'Берлин', 52.5200, 13.4050],
    ['Другаде', 'Мюнхен', 48.1351, 11.5820], ['Другаде', 'Франкфурт', 50.1109, 8.6821], ['Другаде', 'Цюрих', 47.3769, 8.5417],
    ['Другаде', 'Милано', 45.4642, 9.1900], ['Другаде', 'Рим', 41.9028, 12.4964], ['Другаде', 'Париж', 48.8566, 2.3522],
    ['Другаде', 'Брюксел', 50.8503, 4.3517], ['Другаде', 'Амстердам', 52.3676, 4.9041], ['Другаде', 'Лондон', 51.5074, -0.1278],
    ['Другаде', 'Дъблин', 53.3498, -6.2603], ['Другаде', 'Мадрид', 40.4168, -3.7038], ['Другаде', 'Барселона', 41.3851, 2.1734],
    ['Другаде', 'Лисабон', 38.7223, -9.1393], ['Другаде', 'Стокхолм', 59.3293, 18.0686], ['Другаде', 'Киев', 50.4501, 30.5234],
    ['Другаде', 'Москва', 55.7558, 37.6173], ['Другаде', 'Дубай', 25.2048, 55.2708], ['Другаде', 'Ню Йорк', 40.7128, -74.0060],
    ['Другаде', 'Чикаго', 41.8781, -87.6298], ['Другаде', 'Лос Анджелис', 34.0522, -118.2437], ['Другаде', 'Торонто', 43.6532, -79.3832],
    ['Другаде', 'Сидни', -33.8688, 151.2093],
  ];

  const HOUSE_MEANING = {
    1: 'ти самият', 2: 'пари и вещи', 3: 'документи, новини, кратки пътувания', 4: 'дом и имот', 5: 'деца и творчество',
    7: 'партньор, договор, другата страна', 9: 'учене и далечни пътувания', 10: 'работа, кариера, успех', 11: 'приятели и надежди',
  };

  /* ---------- помощни ---------- */
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* няма хранилище */ } },
  };
  const VERSION = "1.2";
  const MONTHS = ['януари', 'февруари', 'март', 'април', 'май', 'юни', 'юли', 'август', 'септември', 'октомври', 'ноември', 'декември'];
  const pad2 = (n) => String(n).padStart(2, '0');
  // tzMin: отместване от UTC в минути. Показва момента с точност до секунди.
  function fmtAt(date, tzMin) {
    const d = new Date(date.getTime() + tzMin * 60000);
    return d.getUTCDate() + ' ' + MONTHS[d.getUTCMonth()] + ' ' + d.getUTCFullYear() + ', ' + pad2(d.getUTCHours()) + ':' + pad2(d.getUTCMinutes()) + ':' + pad2(d.getUTCSeconds());
  }
  function zoneLabel(tzMin) {
    const sgn = tzMin < 0 ? '−' : '+', a = Math.abs(tzMin), h = Math.floor(a / 60), m = a % 60;
    return 'UTC' + sgn + h + (m ? ':' + pad2(m) : '');
  }
  const deviceTz = () => -new Date().getTimezoneOffset();
  const fmtLat = (v) => Math.abs(v).toFixed(2) + '°' + (v >= 0 ? 'с.ш.' : 'ю.ш.');
  const fmtLon = (v) => Math.abs(v).toFixed(2) + '°' + (v >= 0 ? 'и.д.' : 'з.д.');
  const toneClass = (p) => (p >= 60 ? 'yes' : p <= 40 ? 'no' : 'mid');
  let toastTimer = null;
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 2200);
  }

  /* ---------- форма ---------- */
  const askView = $('view-ask'), resView = $('view-result');
  const topicSel = $('topic'), citySel = $('city');
  H.CATEGORIES.forEach((c) => topicSel.add(new Option(c.label, c.id)));
  CITIES.forEach((c, i) => citySel.add(new Option(c[1], String(i))));
  citySel.add(new Option('Свои координати', 'custom'));

  function syncPickers() {
    $('topic-val').textContent = topicSel.options[topicSel.selectedIndex] ? topicSel.options[topicSel.selectedIndex].text : '';
    $('city-val').textContent = citySel.options[citySel.selectedIndex] ? citySel.options[citySel.selectedIndex].text : '';
  }
  function setTopicHint() {
    const c = H.CATEGORIES.find((x) => x.id === topicSel.value);
    $('topic-hint').textContent = c ? c.hint : '';
  }
  function applyCity() {
    if (citySel.value === 'custom') return;
    const c = CITIES[Number(citySel.value)];
    if (!c) return;
    $('lat').value = c[2]; $('lon').value = c[3];
    store.set('horary.city', citySel.value);
  }
  function setTopic(v) { topicSel.value = v; setTopicHint(); syncPickers(); store.set('horary.topic', v); }
  function setCity(v) { citySel.value = v; applyCity(); syncPickers(); $('geo-status').textContent = ''; }
  ['lat', 'lon'].forEach((id) => $(id).addEventListener('input', () => { citySel.value = 'custom'; syncPickers(); }));

  /* ---------- собствен лист за избор ---------- */
  const sheet = $('sheet'), sheetList = $('sheet-list'), sheetSearch = $('sheet-search');
  let sheetState = null;
  function closeSheet() {
    if (sheet.hidden) return false;
    sheet.hidden = true; document.body.style.overflow = ''; sheetState = null; return true;
  }
  function fillSheet() {
    const st = sheetState, q = sheetSearch.hidden ? '' : sheetSearch.value.trim().toLowerCase();
    sheetList.textContent = '';
    let lastGroup = null, n = 0;
    st.options.forEach((o) => {
      if (q && o.label.toLowerCase().indexOf(q) < 0) return;
      if (o.group && o.group !== lastGroup && !q) { const g = document.createElement('div'); g.className = 'sheet-group'; g.textContent = o.group; sheetList.appendChild(g); }
      lastGroup = o.group;
      const b = document.createElement('button'); b.type = 'button'; b.className = 'opt'; b.setAttribute('role', 'option');
      b.setAttribute('aria-selected', o.value === st.selected ? 'true' : 'false');
      const t = document.createElement('span'); t.textContent = o.label; b.appendChild(t);
      b.addEventListener('click', () => { const cb = st.onPick; closeSheet(); cb(o.value); });
      sheetList.appendChild(b); n++;
    });
    if (!n) { const e = document.createElement('div'); e.className = 'sheet-empty'; e.textContent = 'Няма такъв град. Въведи координатите ръчно по-долу.'; sheetList.appendChild(e); }
  }
  function openSheet(st) {
    sheetState = st;
    $('sheet-title').textContent = st.title;
    sheetSearch.hidden = !st.searchable; sheetSearch.value = '';
    fillSheet();
    sheet.hidden = false; document.body.style.overflow = 'hidden';
    const sel = sheetList.querySelector('[aria-selected="true"]');
    if (sel) sel.scrollIntoView({ block: 'center' });
  }
  sheetSearch.addEventListener('input', () => { if (sheetState) fillSheet(); });
  $('sheet-x').addEventListener('click', closeSheet);
  $('sheet-bd').addEventListener('click', closeSheet);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheet(); });

  $('topic-btn').addEventListener('click', () => openSheet({
    title: 'За какво е въпросът', selected: topicSel.value, onPick: setTopic,
    options: H.CATEGORIES.map((c) => ({ value: c.id, label: c.label })),
  }));
  $('city-btn').addEventListener('click', () => openSheet({
    title: 'Къде си в момента', selected: citySel.value, searchable: true, onPick: setCity,
    options: CITIES.map((c, i) => ({ value: String(i), label: c[1], group: c[0] })),
  }));

  /* ---------- време ---------- */
  function fillNow() {
    const n = new Date();
    $('wd').value = n.getDate(); $('wm').value = n.getMonth() + 1; $('wy').value = n.getFullYear();
    $('wh').value = n.getHours(); $('wmin').value = n.getMinutes(); $('wz').value = deviceTz() / 60;
  }
  function tickClock() {
    const n = new Date(), tz = deviceTz();
    $('now-clock').textContent = fmtAt(n, tz);
    $('now-zone').textContent = zoneLabel(tz) + ' · по UTC: ' + fmtAt(n, 0).split(', ')[1];
  }
  setInterval(() => { if (!askView.hidden && !$('when-custom').checked) tickClock(); }, 250);
  document.querySelectorAll('input[name="when"]').forEach((r) => r.addEventListener('change', () => {
    const custom = $('when-custom').checked;
    $('when-fields').hidden = !custom; $('now-box').hidden = custom;
    if (custom) { if (!$('wd').value) fillNow(); } else tickClock();
  }));
  // връща { date: точният момент, tz: отместване в минути } или null
  function readCustomMoment() {
    const v = ['wy', 'wm', 'wd', 'wh', 'wmin'].map((id) => parseInt($(id).value, 10));
    const z = parseFloat($('wz').value);
    if (v.some((x) => !isFinite(x)) || !isFinite(z) || z < -12 || z > 14) return null;
    const utc = new Date(Date.UTC(v[0], v[1] - 1, v[2], v[3], v[4]));
    if (isNaN(utc) || utc.getUTCMonth() !== v[1] - 1 || utc.getUTCDate() !== v[2] || v[3] > 23 || v[4] > 59) return null;
    const tz = Math.round(z * 60);
    return { date: new Date(utc.getTime() - tz * 60000), tz };
  }

  /* ---------- история ---------- */
  function renderHistory() {
    const list = store.get('horary.history', []);
    $('hist-wrap').hidden = !list.length;
    const box = $('hist'); box.textContent = '';
    list.forEach((h, i) => {
      const b = document.createElement('button'); b.type = 'button';
      const q = document.createElement('span'); q.className = 'q'; q.textContent = h.q;
      const c = document.createElement('span'); c.className = 'chip ' + toneClass(h.pct); c.textContent = h.pct + '%';
      b.append(q, c);
      b.addEventListener('click', () => show({ q: h.q, cat: h.cat, date: new Date(h.date), tz: h.tz != null ? h.tz : deviceTz(), lat: h.lat, lon: h.lon, place: h.place }, false));
      box.appendChild(b);
    });
  }

  /* ---------- изпращане ---------- */
  $('ask-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const q = $('q').value.trim();
    $('q-err').hidden = !!q;
    if (!q) { $('q').focus(); return; }
    const lat = parseFloat($('lat').value), lon = parseFloat($('lon').value);
    if (!isFinite(lat) || !isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
      $('geo-status').textContent = 'Провери координатите или избери град.'; return;
    }
    // Моментът се взима в мига на натискане на бутона.
    let date = new Date(), tz = deviceTz();
    if ($('when-custom').checked) {
      const c = readCustomMoment();
      if (!c) { $('geo-status').textContent = 'Провери датата, часа и часовата зона.'; return; }
      date = c.date; tz = c.tz;
    }
    const place = citySel.value === 'custom' ? lat.toFixed(2) + '°, ' + lon.toFixed(2) + '°' : CITIES[Number(citySel.value)][1];
    show({ q, cat: topicSel.value, date, tz, lat, lon, place }, true);
  });

  /* ---------- екрани ---------- */
  function showAsk() { resView.hidden = true; askView.hidden = false; window.scrollTo(0, 0); renderHistory(); }
  window.__back = function () { if (closeSheet()) return true; if (!resView.hidden) { showAsk(); return true; } return false; };

  function show(inp, save) {
    const r = H.judge({ date: inp.date, lat: inp.lat, lon: inp.lon, category: inp.cat });
    if (save) {
      const list = store.get('horary.history', []);
      list.unshift({ q: inp.q, cat: inp.cat, date: inp.date.toISOString(), tz: inp.tz, lat: inp.lat, lon: inp.lon, place: inp.place, pct: r.pct });
      store.set('horary.history', list.slice(0, 15));
    }
    render(inp, r);
    askView.hidden = true; resView.hidden = false; window.scrollTo(0, 0);
    requestAnimationFrame(() => requestAnimationFrame(() => { const p = document.getElementById('pin'); if (p) p.style.left = r.pct + '%'; }));
  }

  /* ---------- колело на картата ---------- */
  function wheelSVG(ch, S1, S2) {
    const S = 340, c = S / 2, R1 = 160, R2 = 128, R3 = 66, RP = 98;
    const ang = (lon) => (180 + (lon - ch.asc)) * Math.PI / 180; // зодиакът върви обратно на часовниковата стрелка, Асцендентът е отляво
    const pt = (lon, r) => [c + r * Math.cos(ang(lon)), c - r * Math.sin(ang(lon))];
    const f = (n) => n.toFixed(1);
    let g = '';
    g += '<circle cx="' + c + '" cy="' + c + '" r="' + R1 + '" fill="var(--surface)" stroke="var(--line)" stroke-width="1.5"/>';
    g += '<circle cx="' + c + '" cy="' + c + '" r="' + R2 + '" fill="none" stroke="var(--line)"/>';
    g += '<circle cx="' + c + '" cy="' + c + '" r="' + R3 + '" fill="var(--bg)" stroke="var(--line)"/>';
    for (let s = 0; s < 12; s++) {
      const a = pt(s * 30, R2), b = pt(s * 30, R1), m = pt(s * 30 + 15, (R1 + R2) / 2);
      g += '<line x1="' + f(a[0]) + '" y1="' + f(a[1]) + '" x2="' + f(b[0]) + '" y2="' + f(b[1]) + '" stroke="var(--line)"/>';
      g += '<text x="' + f(m[0]) + '" y="' + f(m[1]) + '" text-anchor="middle" dominant-baseline="central" font-size="17" fill="var(--muted)">' + H.SIGN_GLYPH[s] + VS + '</text>';
    }
    for (let h = 1; h <= 12; h++) {
      const ang0 = ch.cusps[h], angular = h === 1 || h === 4 || h === 7 || h === 10;
      const a = pt(ang0, R3), b = pt(ang0, angular ? R1 + 6 : R2);
      g += '<line x1="' + f(a[0]) + '" y1="' + f(a[1]) + '" x2="' + f(b[0]) + '" y2="' + f(b[1]) + '" stroke="' + (angular ? 'var(--ink)' : 'var(--muted)') + '" stroke-width="' + (angular ? 1.6 : 0.8) + '"/>';
      const nextC = ch.cusps[h % 12 + 1], mid = ang0 + (((nextC - ang0) % 360 + 360) % 360) / 2, m = pt(mid, R3 + 12);
      g += '<text x="' + f(m[0]) + '" y="' + f(m[1]) + '" text-anchor="middle" dominant-baseline="central" font-size="11" fill="var(--muted)">' + h + '</text>';
    }
    const asc = pt(ch.asc, R1 + 14), mc = pt(ch.mc, R1 + 14);
    g += '<text x="' + f(asc[0] - 2) + '" y="' + f(asc[1]) + '" text-anchor="middle" dominant-baseline="central" font-size="10" font-weight="700" fill="var(--ink)">ASC</text>';
    g += '<text x="' + f(mc[0]) + '" y="' + f(mc[1] - 1) + '" text-anchor="middle" dominant-baseline="central" font-size="10" font-weight="700" fill="var(--ink)">MC</text>';
    // планети: разместване без застъпване
    const pl = ch.planets.map((p) => ({ p, a: p.lon })).sort((x, y) => x.a - y.a);
    for (let it = 0; it < 40; it++) {
      let moved = false;
      for (let i = 0; i < pl.length; i++) {
        const j = (i + 1) % pl.length;
        let d = pl[j].a - pl[i].a; if (j === 0) d += 360;
        if (d < 12) { const push = (12 - d) / 2; pl[i].a -= push; pl[j].a += push; moved = true; }
      }
      if (!moved) break;
    }
    pl.forEach(({ p, a }) => {
      const t1 = pt(p.lon, R2), t2 = pt(p.lon, R2 - 6), q = pt(a, RP);
      g += '<line x1="' + f(t1[0]) + '" y1="' + f(t1[1]) + '" x2="' + f(t2[0]) + '" y2="' + f(t2[1]) + '" stroke="var(--ink)"/>';
      const ring = p.key === S1 ? 'var(--accent)' : p.key === S2 ? 'var(--yes)' : 'none';
      g += '<circle cx="' + f(q[0]) + '" cy="' + f(q[1]) + '" r="12.5" fill="var(--surface2)" stroke="' + ring + '" stroke-width="2"/>';
      g += '<text x="' + f(q[0]) + '" y="' + f(q[1] + 0.5) + '" text-anchor="middle" dominant-baseline="central" font-size="16" fill="var(--ink)">' + p.glyph + VS + '</text>';
      if (p.retro) g += '<text x="' + f(q[0] + 11) + '" y="' + f(q[1] + 11) + '" font-size="9" font-weight="700" fill="var(--no)">R</text>';
    });
    return '<svg viewBox="-16 -16 ' + (S + 32) + ' ' + (S + 32) + '" role="img" aria-label="Хорарна карта: знаци, къщи и планети">' + g + '</svg>';
  }

  /* ---------- резултат ---------- */
  function render(inp, r) {
    const cat = r.significators.category, sg = r.significators, ch = r.chart;
    const P = (k) => ch.planets.find((x) => x.key === k);
    const p1 = P(sg.querent), p2 = P(sg.quesited), pm = P('moon');
    const ticks = [];
    for (let i = 0; i <= 100; i += 5) ticks.push('<i class="' + (i % 25 === 0 ? 'maj' : '') + '" style="left:' + i + '%"></i>');
    [0, 25, 50, 75, 100].forEach((i) => ticks.push('<b style="left:' + i + '%">' + i + '</b>'));

    const items = r.items.slice().sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));
    const fx = items.map((it) => {
      const d = Math.round(it.delta), cls = d > 0 ? 'pos' : d < 0 ? 'neg' : 'zero';
      const w = Math.min(50, Math.abs(it.delta) / 30 * 50);
      return '<li class="fx"><div class="fx-head"><span class="fx-title">' + esc(it.title) + '</span><span class="fx-delta ' + cls + '">' + (d > 0 ? '+' + d : d < 0 ? '−' + Math.abs(d) : '±0') + '</span></div>' +
        '<div class="fx-bar" aria-hidden="true">' + (d !== 0 ? '<i class="' + cls + '" style="width:' + w.toFixed(1) + '%"></i>' : '') + '</div>' +
        '<p>' + esc(it.text) + '</p></li>';
    }).join('');

    const moonLine = ch.moon.voc
      ? 'Луната е в ' + pm.fmt.signName + ' и до края на знака няма да образува аспект.'
      : 'Луната е в ' + pm.fmt.signName + '. Следващият ѝ аспект е ' + ch.moon.next.aspect + ' ' + H.withP(ch.moon.next.planet) + ' ' + H.fmtTime(ch.moon.next.days) + '.';

    const rows = ch.planets.map((p) => '<tr><td>' + p.glyph + VS + ' ' + esc(p.name) + '</td><td>' + esc(p.fmt.text) + (p.retro ? ' R' : '') + '</td><td>' + p.house + '</td></tr>').join('');
    const calcNote = r.pull < 1 ? 'Картата е с уговорки, затова ефектът е смален ×' + r.pull.toFixed(2) : '';

    resView.innerHTML =
      '<header class="stack" style="gap:8px"><span class="eyebrow">' + esc(cat.label) + '</span>' +
      '<div class="qecho" id="qecho"></div>' +
      '<div class="meta"><span><strong>' + esc(fmtAt(inp.date, inp.tz)) + '</strong> (' + esc(zoneLabel(inp.tz)) + ')</span><span>по UTC: ' + esc(fmtAt(inp.date, 0).split(', ')[1]) + '</span><span>' + esc(inp.place || '') + ' · ' + esc(fmtLat(inp.lat)) + ' ' + esc(fmtLon(inp.lon)) + '</span><span>Асцендент: ' + esc(ch.ascFmt.text) + '</span></div></header>' +

      '<section class="card verdict-card tone-' + r.tone + '" aria-label="Вероятност">' +
      '<div class="big"><div class="pct">' + r.pct + '<small>%</small></div><div class="vword">' + esc(r.verdict) + '</div></div>' +
      '<div class="gauge" role="img" aria-label="Вероятност ' + r.pct + ' процента от 100"><div class="g-track"><div class="g-pin" id="pin"></div></div>' +
      '<div class="g-ticks">' + ticks.join('') + '</div></div>' +
      '<div class="g-ends"><span>НЕ</span><span>ДА</span></div></section>' +

      '<section class="card"><h2>Накратко</h2><p class="lead">' + esc(r.summary) + '</p><p class="muted">' + esc(r.pctLine) + '</p>' +
      (r.timing ? '<p><strong>Срок:</strong> ако нещата тръгнат натам, развръзката е ' + esc(r.timing.text) + '. Сроковете са ориентировъчни.</p>' : '') +
      (r.warnings.length ? '<div class="notice">' + r.warnings.map((w) => '<span>' + esc(w) + '</span>').join('') + '</div>' : '') + '</section>' +

      '<section class="card"><h2>Какво влияе на процента</h2>' +
      '<p class="muted small">Започваме от 50% и добавяме или махаме точки за всеки белег в картата. Най-силните са отгоре.</p>' +
      '<ul class="fx-list">' + fx + '</ul>' +
      '<div class="calc"><span>50 ' + (r.sum >= 0 ? '+ ' : '− ') + Math.abs(r.sum) + (calcNote ? ' (' + esc(calcNote) + ')' : '') + ' = ' + (50 + r.pull * r.sum).toFixed(0) + (r.pct !== Math.round(50 + r.pull * r.sum) ? ', ограничено до 5–95' : '') + '</span><b>' + r.pct + '%</b></div></section>' +

      '<section class="card"><h2>Кой кого представлява</h2><div class="who">' +
      '<div class="who-item q1"><div class="glyph">' + p1.glyph + VS + '</div><div><strong>Ти — ' + esc(p1.name) + '</strong><span class="muted small">Асцендентът (1-ви дом) е ' + esc(ch.ascFmt.signName) + ', а негов управител е ' + esc(p1.name) + '. Той е в ' + esc(p1.fmt.text) + ', ' + p1.house + '-и дом.</span></div></div>' +
      (sg.querent === sg.quesited ? '' : '<div class="who-item q2"><div class="glyph">' + p2.glyph + VS + '</div><div><strong>' + esc(cat.thing.charAt(0).toUpperCase() + cat.thing.slice(1)) + ' — ' + esc(p2.name) + '</strong><span class="muted small">' + sg.house + '-и дом (' + esc(HOUSE_MEANING[sg.house] || '') + ') е в знака ' + esc(H.SIGNS[Math.floor(ch.cusps[sg.house] / 30)]) + ', а негов управител е ' + esc(p2.name) + '. Той е в ' + esc(p2.fmt.text) + ', ' + p2.house + '-и дом.</span></div></div>') +
      '<div class="who-item"><div class="glyph">' + pm.glyph + VS + '</div><div><strong>Луната — общият ход на събитията</strong><span class="muted small">' + esc(moonLine) + '</span></div></div>' +
      '</div></section>' +

      '<section class="card"><details open style="border-top:0;padding-top:0"><summary>Картата на въпроса</summary>' +
      '<div class="wheel-wrap">' + wheelSVG(ch, sg.querent, sg.quesited) +
      '<div class="legend"><span><i style="background:var(--accent)"></i>ти</span><span><i style="background:var(--yes)"></i>желаното</span><span>R — ретрограден ход</span></div></div>' +
      '<div class="tbl" style="margin-top:12px"><table><thead><tr><th>Планета</th><th>Позиция</th><th>Дом</th></tr></thead><tbody>' + rows + '</tbody></table></div></details></section>' +

      '<section class="card"><details style="border-top:0;padding-top:0"><summary>Как се получава числото</summary>' +
      '<div class="stack small" style="gap:10px"><p>Методът е традиционният хорарен по Уилям Лили. Картата е изчертана за точния час и място на въпроса, с къщи по Региомонтан.</p>' +
      '<p>Ти се представляваш от управителя на Асцендента, а желаното — от управителя на съответния дом. Основният въпрос е дали двата показателя се срещат в аспект преди да се разминат. Тригон и секстил са леки пътища, квадрат и опозиция минават през трудности.</p>' +
      '<p>Към това се добавят Луната (дали е „на празен ход“ и къде отива), силата на двете планети (знак, дом, ретроградност, изгаряне), посредници и пречки. Всеки белег добавя или маха точки от 50%.</p>' +
      '<p>Числото е оценка по тези правила. То не е статистика и не е доказана вероятност.</p></div></details></section>' +

      '<div class="actions"><button class="btn2" id="share" type="button">Копирай отговора</button><button class="btn2" id="again" type="button">Нов въпрос</button></div>' +
      '<p class="foot">Хорарната астрология е символична практика без научно потвърждение. Не използвай отговора за решения за здраве, право или пари.</p>';

    $('qecho').textContent = '„' + inp.q + '“';
    $('again').addEventListener('click', showAsk);
    $('share').addEventListener('click', () => {
      const txt = 'Хорарен въпрос: ' + inp.q + '\nОтговор: ' + r.pct + '% — ' + r.verdict + '\n' + r.summary + '\n(' + fmtAt(inp.date, inp.tz) + ' ' + zoneLabel(inp.tz) + ', ' + (inp.place || '') + ')';
      const fallback = () => {
        const ta = document.createElement('textarea'); ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        let ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
        document.body.removeChild(ta); toast(ok ? 'Копирано' : 'Не успях да копирам');
      };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(() => toast('Копирано'), fallback);
      else fallback();
    });
  }

  /* ---------- начално състояние ---------- */
  const savedTopic = store.get('horary.topic', 'love');
  topicSel.value = H.CATEGORIES.some((c) => c.id === savedTopic) ? savedTopic : 'love';
  const savedCity = store.get('horary.city', '0');
  citySel.value = CITIES[Number(savedCity)] ? savedCity : '0';
  setTopicHint(); applyCity(); syncPickers(); renderHistory(); tickClock();
  $('diag').textContent = 'Версия ' + VERSION + ' · екран ' + window.innerWidth + '×' + window.innerHeight + ' · ' + navigator.userAgent;
})();
