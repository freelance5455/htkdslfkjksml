/* Хорарен енджин: позиции на планетите, Асцендент, къщи (Региомонтан), аспекти,
 * традиционни достойнства и оценка на вероятността в проценти.
 * Без външни зависимости. Работи в браузър, WebView и Node.
 *
 * Ефемеридите са по опростените формули на Пол Шлайтър (орбитални елементи
 * с основните пертурбации). Точността е около 1-2' за Слънцето, няколко
 * ъглови минути за планетите и до около 0,1° за Луната - напълно достатъчно
 * за хорарна преценка, където орбите са в градуси.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Horary = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------- математика ---------- */
  const D2R = Math.PI / 180, R2D = 180 / Math.PI;
  const rev = (x) => ((x % 360) + 360) % 360;
  const n180 = (x) => { x = rev(x); return x > 180 ? x - 360 : x; };
  const sin = (x) => Math.sin(x * D2R);
  const cos = (x) => Math.cos(x * D2R);
  const tan = (x) => Math.tan(x * D2R);
  const atan2 = (y, x) => Math.atan2(y, x) * R2D;
  const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

  function jdFromDate(date) { return date.getTime() / 86400000 + 2440587.5; }

  /* ---------- имена ---------- */
  const SIGNS = ['Овен', 'Телец', 'Близнаци', 'Рак', 'Лъв', 'Дева', 'Везни', 'Скорпион', 'Стрелец', 'Козирог', 'Водолей', 'Риби'];
  const SIGN_GLYPH = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓'];
  const PL = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn'];
  const PBG = { sun: 'Слънцето', moon: 'Луната', mercury: 'Меркурий', venus: 'Венера', mars: 'Марс', jupiter: 'Юпитер', saturn: 'Сатурн' };
  const PGLYPH = { sun: '☉', moon: '☽', mercury: '☿', venus: '♀', mars: '♂', jupiter: '♃', saturn: '♄' };
  const withP = (k) => (k === 'sun' || k === 'saturn' || k === 'venus' ? 'със ' : 'с ') + PBG[k];
  const BENEFIC = { jupiter: true, venus: true };
  const MALEFIC = { mars: true, saturn: true };

  const ASPECTS = [
    { key: 'conj', angle: 0, bg: 'съвпад', soft: true },
    { key: 'sextile', angle: 60, bg: 'секстил', soft: true },
    { key: 'square', angle: 90, bg: 'квадрат', soft: false },
    { key: 'trine', angle: 120, bg: 'тригон', soft: true },
    { key: 'opp', angle: 180, bg: 'опозиция', soft: false },
  ];
  // половин орб (Лили): две планети са в аспект, ако разстоянието е <= сбора от половинките
  const MOIETY = { sun: 7.5, moon: 6, mercury: 3.5, venus: 4, mars: 3.75, jupiter: 6, saturn: 5 };
  const orbMax = (a, b) => MOIETY[a] + MOIETY[b];

  /* ---------- теми на въпросите ---------- */
  const CATEGORIES = [
    { id: 'love', label: 'Любов, връзка, брак', house: 7, thing: 'другия човек и връзката с него', hint: 'Например: „Ще се получи ли връзката ми с ...?“' },
    { id: 'contract', label: 'Сделка, договор, партньорство', house: 7, thing: 'другата страна по сделката', hint: 'Например: „Ще сключа ли договора?“' },
    { id: 'work', label: 'Работа, кариера, повишение', house: 10, thing: 'работата и длъжността', hint: 'Например: „Ще получа ли тази работа?“' },
    { id: 'money', label: 'Пари, доходи, заплата', house: 2, thing: 'парите', hint: 'Например: „Ще получа ли исканата сума?“' },
    { id: 'lost', label: 'Загубена вещ', house: 2, thing: 'загубената вещ', hint: 'Например: „Ще намеря ли ключовете си?“' },
    { id: 'study', label: 'Учене, изпит, обучение', house: 9, thing: 'ученето и изпита', hint: 'Например: „Ще взема ли изпита?“' },
    { id: 'travel', label: 'Далечно пътуване, чужбина', house: 9, thing: 'пътуването', hint: 'Например: „Ще замина ли за ... през лятото?“' },
    { id: 'docs', label: 'Документи, новини, кратко пътуване', house: 3, thing: 'документите и новините', hint: 'Например: „Ще получа ли отговор по документите?“' },
    { id: 'home', label: 'Дом, имот, преместване', house: 4, thing: 'дома или имота', hint: 'Например: „Ще купя ли този апартамент?“' },
    { id: 'children', label: 'Деца, бременност, творчество', house: 5, thing: 'децата или творческия проект', hint: 'Например: „Ще излезе ли проектът ми?“' },
    { id: 'hopes', label: 'Приятели, надежди, мечти', house: 11, thing: 'надеждата или приятелите', hint: 'Например: „Ще се сбъдне ли желанието ми?“' },
    { id: 'other', label: 'Друг въпрос (изход, успех)', house: 10, thing: 'желания резултат', hint: 'Формулирай въпроса така, че отговорът да е „да“ или „не“.' },
  ];

  /* ---------- ефемериди ---------- */
  const EL = {
    mercury: { N: [48.3313, 3.24587e-5], i: [7.0047, 5.00e-8], w: [29.1241, 1.01444e-5], a: 0.387098, e: [0.205635, 5.59e-10], M: [168.6562, 4.0923344368] },
    venus: { N: [76.6799, 2.46590e-5], i: [3.3946, 2.75e-8], w: [54.8910, 1.38374e-5], a: 0.723330, e: [0.006773, -1.302e-9], M: [48.0052, 1.6021302244] },
    mars: { N: [49.5574, 2.11081e-5], i: [1.8497, -1.78e-8], w: [286.5016, 2.92961e-5], a: 1.523688, e: [0.093405, 2.516e-9], M: [18.6021, 0.5240207766] },
    jupiter: { N: [100.4542, 2.76854e-5], i: [1.3030, -1.557e-7], w: [273.8777, 1.64505e-5], a: 5.20256, e: [0.048498, 4.469e-9], M: [19.8950, 0.0830853001] },
    saturn: { N: [113.6634, 2.38980e-5], i: [2.4886, -1.081e-7], w: [339.3939, 2.97661e-5], a: 9.55475, e: [0.055546, -9.499e-9], M: [316.9670, 0.0334442282] },
    moon: { N: [125.1228, -0.0529538083], i: [5.1454, 0], w: [318.0634, 0.1643573223], a: 60.2666, e: [0.054900, 0], M: [115.3654, 13.0649929509] },
  };

  function kepler(M, e) { // градуси
    let E = M + e * R2D * sin(M) * (1 + e * cos(M));
    for (let k = 0; k < 15; k++) {
      const dE = (E - e * R2D * sin(E) - M) / (1 - e * cos(E));
      E -= dE;
      if (Math.abs(dE) < 1e-8) break;
    }
    return E;
  }

  function orbit(el, d) {
    const N = rev(el.N[0] + el.N[1] * d), inc = el.i[0] + el.i[1] * d, w = rev(el.w[0] + el.w[1] * d);
    const e = el.e[0] + el.e[1] * d, M = rev(el.M[0] + el.M[1] * d), a = el.a;
    const E = kepler(M, e);
    const xv = a * (cos(E) - e), yv = a * Math.sqrt(1 - e * e) * sin(E);
    const v = atan2(yv, xv), r = Math.hypot(xv, yv), vw = v + w;
    return {
      xh: r * (cos(N) * cos(vw) - sin(N) * sin(vw) * cos(inc)),
      yh: r * (sin(N) * cos(vw) + cos(N) * sin(vw) * cos(inc)),
      zh: r * sin(vw) * sin(inc),
      r, M, N, w,
    };
  }

  function sunPos(d) {
    const w = rev(282.9404 + 4.70935e-5 * d), e = 0.016709 - 1.151e-9 * d, M = rev(356.0470 + 0.9856002585 * d);
    const E = kepler(M, e);
    const xv = cos(E) - e, yv = Math.sqrt(1 - e * e) * sin(E);
    const r = Math.hypot(xv, yv), lon = rev(atan2(yv, xv) + w);
    return { lon, r, x: r * cos(lon), y: r * sin(lon), M, w };
  }

  function moonPos(d, sun) {
    const o = orbit(EL.moon, d);
    let lon = atan2(o.yh, o.xh), lat = atan2(o.zh, Math.hypot(o.xh, o.yh)), r = o.r;
    const Ms = sun.M, Mm = o.M, Nm = o.N;
    const Ls = Ms + sun.w, Lm = Mm + o.w + Nm, D = Lm - Ls, F = Lm - Nm;
    lon += -1.274 * sin(Mm - 2 * D) + 0.658 * sin(2 * D) - 0.186 * sin(Ms) - 0.059 * sin(2 * Mm - 2 * D)
      - 0.057 * sin(Mm - 2 * D + Ms) + 0.053 * sin(Mm + 2 * D) + 0.046 * sin(2 * D - Ms) + 0.041 * sin(Mm - Ms)
      - 0.035 * sin(D) - 0.031 * sin(Mm + Ms) - 0.015 * sin(2 * F - 2 * D) + 0.011 * sin(Mm - 4 * D);
    lat += -0.173 * sin(F - 2 * D) - 0.055 * sin(Mm - F - 2 * D) - 0.046 * sin(Mm + F - 2 * D)
      + 0.033 * sin(F + 2 * D) + 0.017 * sin(2 * Mm + F);
    r += -0.58 * cos(Mm - 2 * D) - 0.46 * cos(2 * D);
    return { lon: rev(lon), lat, dist: r };
  }

  function positionsRaw(jd) {
    const d = jd - 2451543.5;
    const sun = sunPos(d);
    const out = { sun: { lon: sun.lon, lat: 0, dist: sun.r } };
    out.moon = moonPos(d, sun);
    const Mj = rev(EL.jupiter.M[0] + EL.jupiter.M[1] * d), Ms = rev(EL.saturn.M[0] + EL.saturn.M[1] * d);
    for (const k of ['mercury', 'venus', 'mars', 'jupiter', 'saturn']) {
      const o = orbit(EL[k], d);
      let lon = atan2(o.yh, o.xh), lat = atan2(o.zh, Math.hypot(o.xh, o.yh)), r = o.r;
      if (k === 'jupiter') {
        lon += -0.332 * sin(2 * Mj - 5 * Ms - 67.6) - 0.056 * sin(2 * Mj - 2 * Ms + 21) + 0.042 * sin(3 * Mj - 5 * Ms + 21)
          - 0.036 * sin(Mj - 2 * Ms) + 0.022 * cos(Mj - Ms) + 0.023 * sin(2 * Mj - 3 * Ms + 52) - 0.016 * sin(Mj - 5 * Ms - 69);
      } else if (k === 'saturn') {
        lon += 0.812 * sin(2 * Mj - 5 * Ms - 67.6) - 0.229 * cos(2 * Mj - 4 * Ms - 2) + 0.119 * sin(Mj - 2 * Ms - 3)
          + 0.046 * sin(2 * Mj - 6 * Ms - 69) + 0.014 * sin(Mj - 3 * Ms + 32);
        lat += -0.020 * cos(2 * Mj - 4 * Ms - 2) + 0.018 * sin(2 * Mj - 6 * Ms - 49);
      }
      const xh = r * cos(lat) * cos(lon), yh = r * cos(lat) * sin(lon), zh = r * sin(lat);
      const xg = xh + sun.x, yg = yh + sun.y, zg = zh;
      out[k] = { lon: rev(atan2(yg, xg)), lat: atan2(zg, Math.hypot(xg, yg)), dist: Math.sqrt(xg * xg + yg * yg + zg * zg) };
    }
    return out;
  }

  function rawLons(jd) {
    const p = positionsRaw(jd), o = {};
    for (const k of PL) o[k] = p[k].lon;
    return o;
  }

  function positions(jd) {
    const p = positionsRaw(jd), a = positionsRaw(jd - 0.05), b = positionsRaw(jd + 0.05);
    for (const k of PL) {
      p[k].speed = n180(b[k].lon - a[k].lon) / 0.1;
      p[k].retro = p[k].speed < 0;
    }
    return p;
  }

  /* ---------- Асцендент и къщи (Региомонтан) ---------- */
  function houses(jd, lat, lon) {
    const d = jd - 2451543.5;
    const eps = 23.4393 - 3.563e-7 * d;
    const T = (jd - 2451545.0) / 36525;
    const gmst = rev(280.46061837 + 360.98564736629 * (jd - 2451545.0) + 0.000387933 * T * T);
    const ramc = rev(gmst + lon);
    const cusp = (t) => rev(atan2(sin(ramc + t), cos(eps) * cos(ramc + t) - tan(lat) * sin(eps) * sin(t)));
    const c = [];
    c[10] = cusp(0); c[11] = cusp(30); c[12] = cusp(60); c[1] = cusp(90); c[2] = cusp(120); c[3] = cusp(150);
    c[4] = rev(c[10] + 180); c[5] = rev(c[11] + 180); c[6] = rev(c[12] + 180);
    c[7] = rev(c[1] + 180); c[8] = rev(c[2] + 180); c[9] = rev(c[3] + 180);
    return { cusps: c, asc: c[1], mc: c[10], ramc, eps };
  }

  function houseOf(lon, cusps) {
    for (let h = 1; h <= 12; h++) {
      const s = cusps[h], e = cusps[h % 12 + 1];
      if (rev(lon - s) < rev(e - s)) return h;
    }
    return 1;
  }

  /* ---------- достойнства ---------- */
  const DOMICILE = ['mars', 'venus', 'mercury', 'moon', 'sun', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'saturn', 'jupiter'];
  const EXALT = { sun: 0, moon: 1, mercury: 5, venus: 11, mars: 9, jupiter: 3, saturn: 6 };
  const TRIP = [['sun', 'jupiter'], ['venus', 'moon'], ['saturn', 'mercury'], ['venus', 'mars']]; // [ден, нощ] за огън, земя, въздух, вода
  const TERMS = [
    [['jupiter', 6], ['venus', 12], ['mercury', 20], ['mars', 25], ['saturn', 30]],
    [['venus', 8], ['mercury', 14], ['jupiter', 22], ['saturn', 27], ['mars', 30]],
    [['mercury', 6], ['jupiter', 12], ['venus', 17], ['mars', 24], ['saturn', 30]],
    [['mars', 7], ['venus', 13], ['mercury', 19], ['jupiter', 26], ['saturn', 30]],
    [['jupiter', 6], ['venus', 11], ['saturn', 18], ['mercury', 24], ['mars', 30]],
    [['mercury', 7], ['venus', 17], ['jupiter', 21], ['mars', 28], ['saturn', 30]],
    [['saturn', 6], ['mercury', 14], ['jupiter', 21], ['venus', 28], ['mars', 30]],
    [['mars', 7], ['venus', 11], ['mercury', 19], ['jupiter', 24], ['saturn', 30]],
    [['jupiter', 12], ['venus', 17], ['mercury', 21], ['saturn', 26], ['mars', 30]],
    [['mercury', 7], ['jupiter', 14], ['venus', 22], ['saturn', 26], ['mars', 30]],
    [['mercury', 7], ['venus', 13], ['jupiter', 20], ['mars', 25], ['saturn', 30]],
    [['venus', 12], ['jupiter', 16], ['mercury', 19], ['mars', 28], ['saturn', 30]],
  ];
  const FACES = ['mars', 'sun', 'venus', 'mercury', 'moon', 'saturn', 'jupiter'];

  function essential(p, lon, isDay) {
    const s = Math.floor(lon / 30), deg = lon - s * 30;
    const r = { score: 0, labels: [], domicile: false, exalt: false, detriment: false, fall: false, peregrine: false };
    let any = false;
    if (DOMICILE[s] === p) { r.score += 5; r.domicile = true; r.labels.push('в собствения си знак'); any = true; }
    if (EXALT[p] === s) { r.score += 4; r.exalt = true; r.labels.push('във възвишение'); any = true; }
    if (TRIP[s % 4][isDay ? 0 : 1] === p) { r.score += 3; r.labels.push('управлява стихията на знака'); any = true; }
    const term = TERMS[s].find((t) => deg < t[1]);
    if (term && term[0] === p) { r.score += 2; r.labels.push('в собствения си термин'); any = true; }
    if (FACES[Math.floor(lon / 10) % 7] === p) { r.score += 1; r.labels.push('в собствения си лик'); any = true; }
    if (DOMICILE[(s + 6) % 12] === p) { r.score -= 5; r.detriment = true; r.labels.push('в изгнание'); }
    if (EXALT[p] === (s + 6) % 12) { r.score -= 4; r.fall = true; r.labels.push('в падение'); }
    if (!any && !r.detriment && !r.fall) { r.score -= 5; r.peregrine = true; r.labels.push('без собствена сила в знака'); }
    else if (!any) { /* само изгнание или падение */ }
    return r;
  }

  const HOUSE_SCORE = { 1: 5, 2: 3, 3: 1, 4: 4, 5: 3, 6: -5, 7: 4, 8: -5, 9: 2, 10: 5, 11: 4, 12: -5 };

  function condition(k, pos, isDay, cusps) {
    const p = pos[k];
    const ess = essential(k, p.lon, isDay);
    const house = houseOf(p.lon, cusps);
    let acc = HOUSE_SCORE[house];
    const notes = [];
    if (house === 1 || house === 4 || house === 7 || house === 10) notes.push('в ъглов дом (' + house + '-и) — силно място');
    else if (house === 6 || house === 8 || house === 12) notes.push('в труден дом (' + house + '-и)');
    else notes.push('в ' + house + '-и дом');
    if (k !== 'sun' && k !== 'moon') {
      if (p.retro) { acc -= 5; notes.push('в ретрограден ход (върви „назад“)'); } else acc += 4;
      const ds = Math.abs(n180(p.lon - pos.sun.lon));
      if (ds < 0.2833) { acc += 5; notes.push('в сърцето на Слънцето (кацими) — подсилена'); }
      else if (ds < 8.5) { acc -= 5; notes.push('изгорена от Слънцето'); }
      else if (ds < 17) { acc -= 4; notes.push('под лъчите на Слънцето'); }
    }
    for (const o of PL) {
      if (o === k) continue;
      const dist = Math.abs(n180(p.lon - pos[o].lon));
      if (o === 'jupiter' && dist < 5) { acc += 5; notes.push('в съвпад с Юпитер (помага)'); }
      if (o === 'venus' && dist < 5) { acc += 4; notes.push('в съвпад с Венера (помага)'); }
      if (o === 'mars' && dist < 5) { acc -= 5; notes.push('в съвпад с Марс (пречи)'); }
      if (o === 'saturn' && dist < 5) { acc -= 5; notes.push('в съвпад със Сатурн (пречи)'); }
    }
    return { total: ess.score + acc, ess, acc, house, notes };
  }

  function strengthWord(t) {
    if (t >= 9) return 'много силна позиция';
    if (t >= 3) return 'добра позиция';
    if (t > -3) return 'средна позиция';
    if (t > -9) return 'слаба позиция';
    return 'много слаба позиция';
  }

  /* ---------- аспекти ---------- */
  function aspectNow(pa, pb, ka, kb) {
    const rel = n180(pb.lon - pa.lon), d = Math.abs(rel);
    const dd = (rel >= 0 ? 1 : -1) * (pb.speed - pa.speed);
    const max = orbMax(ka, kb);
    let best = null;
    for (const asp of ASPECTS) {
      const diff = d - asp.angle, orb = Math.abs(diff);
      if (orb <= max && (!best || orb < best.orb)) {
        best = { asp, orb, applying: (diff > 0 && dd < 0) || (diff < 0 && dd > 0), rate: Math.abs(dd) };
      }
    }
    return best;
  }

  function Sim(jd0, step, maxDays) {
    this.step = step; this.n = Math.ceil(maxDays / step); this.jd0 = jd0; this.cache = [];
  }
  Sim.prototype.lons = function (k) {
    if (!this.cache[k]) this.cache[k] = rawLons(this.jd0 + k * this.step);
    return this.cache[k];
  };

  // първият момент, в който a и b образуват точен аспект (от списъка) в следващите maxDays дни
  function firstCrossing(sim, a, b, maxDays, aspects) {
    const n = Math.min(sim.n, Math.ceil(maxDays / sim.step));
    const L0 = sim.lons(0);
    let best = null;
    for (const asp of aspects) {
      const targets = asp.angle === 0 || asp.angle === 180 ? [asp.angle] : [asp.angle, 360 - asp.angle];
      for (const T of targets) {
        const h0 = n180(rev(L0[b] - L0[a]) - T);
        let hPrev = h0;
        for (let k = 1; k <= n; k++) {
          const L = sim.lons(k);
          const h = n180(rev(L[b] - L[a]) - T);
          if (((hPrev < 0 && h >= 0) || (hPrev > 0 && h <= 0)) && Math.abs(hPrev) + Math.abs(h) < 60) {
            const frac = Math.abs(hPrev) / ((Math.abs(hPrev) + Math.abs(h)) || 1);
            const t = (k - 1 + frac) * sim.step;
            if (t <= maxDays + 1e-9 && (!best || t < best.t)) best = { t, asp, rem: Math.abs(h0), k };
            break;
          }
          hPrev = h;
        }
      }
    }
    return best;
  }

  function moonNextAspect(sim, pos) {
    const s0 = Math.floor(pos.moon.lon / 30);
    let exitT = 4;
    for (let k = 1; k <= sim.n; k++) {
      const lp = sim.lons(k - 1).moon;
      let lc = sim.lons(k).moon;
      if (Math.floor(lc / 30) !== s0) {
        if (lc < lp) lc += 360;
        const boundary = (s0 + 1) * 30;
        exitT = (k - 1 + (boundary - lp) / (lc - lp)) * sim.step;
        break;
      }
    }
    let best = null;
    for (const p of PL) {
      if (p === 'moon') continue;
      const c = firstCrossing(sim, 'moon', p, exitT, ASPECTS);
      if (c && (!best || c.t < best.t)) best = { t: c.t, asp: c.asp, planet: p };
    }
    return { exitT, next: best, voc: !best };
  }

  /* ---------- форматиране ---------- */
  function fmtPos(lon) {
    const s = Math.floor(lon / 30), x = lon - s * 30, deg = Math.floor(x);
    const min = Math.floor((x - deg) * 60);
    return { sign: s, signName: SIGNS[s], glyph: SIGN_GLYPH[s], deg, min, text: deg + '°' + String(min).padStart(2, '0') + '′ ' + SIGNS[s] };
  }

  function fmtTime(days) {
    if (days < 1 / 24) return 'след минути';
    if (days < 1) { const h = Math.max(1, Math.round(days * 24)); return 'след около ' + h + (h === 1 ? ' час' : ' часа'); }
    if (days < 14) { const n = Math.max(1, Math.round(days)); return 'след около ' + n + (n === 1 ? ' ден' : ' дни'); }
    if (days < 60) { const n = Math.round(days / 7); return 'след около ' + n + ' седмици'; }
    const n = Math.round(days / 30); return 'след около ' + n + (n === 1 ? ' месец' : ' месеца');
  }

  /* ---------- преценка ---------- */
  function judge(opts) {
    const date = opts.date instanceof Date ? opts.date : new Date();
    const lat = clamp(opts.lat, -66, 66), lon = opts.lon;
    const cat = CATEGORIES.find((c) => c.id === opts.category) || CATEGORIES[CATEGORIES.length - 1];
    const jd = jdFromDate(date);
    const pos = positions(jd);
    const H = houses(jd, lat, lon);
    for (const k of PL) { pos[k].house = houseOf(pos[k].lon, H.cusps); pos[k].fmt = fmtPos(pos[k].lon); }
    const isDay = pos.sun.house >= 7;
    const ascSign = Math.floor(H.asc / 30), qSign = Math.floor(H.cusps[cat.house] / 30);
    const S1 = DOMICILE[ascSign], S2 = DOMICILE[qSign];
    const n1 = PBG[S1], n2 = PBG[S2];
    const cond = {};
    for (const k of PL) cond[k] = condition(k, pos, isDay, H.cusps);

    const sim = new Sim(jd, 0.25, 366);
    const items = [];
    const warnings = [];
    const add = (id, title, delta, text) => items.push({ id, title, delta: Math.round(delta * 10) / 10, text });
    let timing = null;

    /* 0. предварителни условия */
    let pull = 1;
    const ascDeg = H.asc - ascSign * 30;
    if (ascDeg < 3) { pull *= 0.5; warnings.push('Асцендентът е в самото начало на знака (' + ascDeg.toFixed(1) + '°). Традиционно това значи, че въпросът е зададен твърде рано или картата не е „надеждна“. Отговорът е с по-малка сигурност.'); }
    else if (ascDeg > 27) { pull *= 0.5; warnings.push('Асцендентът е в самия край на знака (' + ascDeg.toFixed(1) + '°). Традиционно това значи, че въпросът е твърде късен или въпросът вече е решен. Отговорът е с по-малка сигурност.'); }
    if (pos.saturn.house === 7) { pull *= 0.85; warnings.push('Сатурн е в 7-и дом — по старите правила това смущава преценката. Отговорът е с по-малка сигурност.'); }

    /* 1. основна връзка между показателите */
    const hardNote = (a) => (a.soft ? '' : ' Връзката е налице, но с напрежение, трудности или забавяне.');
    let perfected = false; // има ли успешна връзка
    let mainKind = 'none';
    let tPerf = null;

    if (S1 === S2) {
      mainKind = 'same'; perfected = true;
      add('same', 'Един показател за теб и за желаното', 15, PBG[S1] + ' представлява едновременно теб и ' + cat.thing + '. Това е добър знак: двете страни са „в един отбор“ и не е нужно нищо да ги свързва.');
    } else {
      const now = aspectNow(pos[S1], pos[S2], S1, S2);
      const cross = firstCrossing(sim, S1, S2, 366, ASPECTS);
      const mx = orbMax(S1, S2);
      let weight = 0;
      if (cross) weight = cross.rem <= mx ? 1 : (cross.rem <= 15 ? 0.5 : 0);
      const signAt = (k, key) => Math.floor(sim.lons(k)[key] / 30);
      if (cross && weight > 0) {
        mainKind = 'aspect'; perfected = true; tPerf = cross.t;
        const asp = cross.asp;
        const kk = Math.min(sim.n, Math.round(cross.t / sim.step));
        const interrupted = signAt(kk, S1) !== Math.floor(pos[S1].lon / 30) || signAt(kk, S2) !== Math.floor(pos[S2].lon / 30);
        let base = asp.soft ? 30 : 12;
        const closeness = clamp(1 - 0.35 * (cross.rem / mx), 0.65, 1);
        let val = base * closeness * (weight < 1 ? 0.5 : 1) * (interrupted ? 0.5 : 1);
        let text = n1 + ' (ти) и ' + n2 + ' (' + cat.thing + ') се сближават и ' + fmtTime(cross.t) + ' ще образуват ' + asp.bg + '.';
        text += asp.soft ? ' Това е добър знак: двете страни се „срещат“ и въпросът може да се разреши.' : hardNote(asp);
        if (weight < 1) text += ' Засега са още доста далеч една от друга, затова връзката е по-слаба.';
        if (interrupted) text += ' Преди срещата обаче някоя от двете планети сменя знака си, което може да промени хода на нещата.';
        add('perfect', 'Връзка между теб и желаното', val, text);
        timing = { days: cross.t, text: fmtTime(cross.t) };
      } else if (now && now.applying) {
        mainKind = 'refrain';
        add('refrain', 'Връзката се къса в последния момент', -12, n1 + ' и ' + n2 + ' се приближават една към друга, но преди да се срещнат една от тях променя посоката си. Това традиционно означава, че работата почти стига до край, но се разваля в последния момент.');
      } else if (now && !now.applying) {
        mainKind = 'separating';
        add('separating', 'Връзката отминава', -10, n1 + ' и ' + n2 + ' вече се отдалечават след ' + now.asp.bg + '. Възможността е била налице, но отмира.');
      }

      /* посредник и събиране на светлина, ако няма пряка връзка */
      if (!perfected) {
        let trans = null;
        for (const X of PL) {
          if (X === S1 || X === S2) continue;
          const sx = Math.abs(pos[X].speed);
          if (!(sx > Math.abs(pos[S1].speed) && sx > Math.abs(pos[S2].speed))) continue;
          for (const [P, Q] of [[S1, S2], [S2, S1]]) {
            const sep = aspectNow(pos[X], pos[P], X, P);
            if (!sep || sep.applying) continue;
            const c = firstCrossing(sim, X, Q, 30, ASPECTS);
            if (c && c.rem <= orbMax(X, Q) && (!trans || c.t < trans.t)) trans = { X, P, Q, t: c.t, asp: c.asp };
          }
        }
        if (trans) {
          mainKind = 'translation'; perfected = true;
          const good = !MALEFIC[trans.X] && trans.asp.soft;
          add('translation', 'Посредник носи „светлината“', good ? 18 : 8, PBG[trans.X] + ' се отделя от ' + PBG[trans.P] + ' и се насочва към ' + PBG[trans.Q] + ' (' + trans.asp.bg + ' ' + fmtTime(trans.t) + '). Така той действа като посредник и може да свърши работата, дори двата главни показателя да не се срещат директно.' + (good ? '' : ' Посредникът обаче е труден, затова помощта идва с цена.'));
          timing = { days: trans.t, text: fmtTime(trans.t) };
        } else {
          for (const Y of PL) {
            if (Y === S1 || Y === S2 || Y === 'moon') continue;
            const sy = Math.abs(pos[Y].speed);
            if (!(sy < Math.abs(pos[S1].speed) && sy < Math.abs(pos[S2].speed))) continue;
            const a1 = aspectNow(pos[S1], pos[Y], S1, Y), a2 = aspectNow(pos[S2], pos[Y], S2, Y);
            if (a1 && a2 && a1.applying && a2.applying) {
              mainKind = 'collection'; perfected = true;
              add('collection', 'Бавна планета събира двете страни', 14, PBG[S1] + ' и ' + PBG[S2] + ' се насочват към ' + PBG[Y] + ', който е по-бавен от двете. Той „събира“ светлината им и може да доведе нещата до резултат.');
              break;
            }
          }
        }
        if (!perfected && mainKind === 'none') {
          add('none', 'Няма връзка между теб и желаното', -22, n1 + ' (ти) и ' + n2 + ' (' + cat.thing + ') не са свързани с аспект и нищо не ги води един към друг. Традиционно това значи, че по естествен път нищо няма да излезе.');
        }
      }

      /* рецепция */
      if (perfected) {
        const recv = (A, B) => { const s = Math.floor(pos[A].lon / 30); return DOMICILE[s] === B || EXALT[B] === s; };
        const r12 = recv(S1, S2), r21 = recv(S2, S1);
        if (r12 && r21) add('recv', 'Взаимно гостоприемство', 10, n1 + ' и ' + n2 + ' са „гости“ в знаците си един на друг (взаимна рецепция). Това улеснява споразумението и добрата воля между двете страни.');
        else if (r12 || r21) add('recv', 'Гостоприемство', 5, (r12 ? n2 : n1) + ' „приема“ другия показател в своя знак, което малко улеснява връзката.');
      }

      /* пречка (прохибиция): трета планета се намесва преди срещата */
      if (mainKind === 'aspect' && tPerf != null) {
        const lim = Math.min(tPerf, 30);
        let hit = null;
        for (const X of PL) {
          if (X === 'moon' || X === S1 || X === S2) continue;
          for (const Y of [S1, S2]) {
            const c = firstCrossing(sim, X, Y, lim, ASPECTS);
            if (c && c.t < tPerf && (MALEFIC[X] || !c.asp.soft) && (!hit || c.t < hit.t)) hit = { X, Y, t: c.t, asp: c.asp };
          }
        }
        if (hit) add('prohib', 'Намеса отвън', MALEFIC[hit.X] && !hit.asp.soft ? -12 : -9, PBG[hit.X] + ' образува ' + hit.asp.bg + ' ' + withP(hit.Y) + ' ' + fmtTime(hit.t) + ', преди двата главни показателя да се срещнат. Традиционно това е трета сила, която може да попречи или да забави.');
      }
    }

    /* 2. Луната */
    const mn = moonNextAspect(sim, pos);
    const moonSign = Math.floor(pos.moon.lon / 30);
    const vocSoft = [1, 3, 8, 11].indexOf(moonSign) >= 0; // Телец, Рак, Стрелец, Риби
    if (mn.voc) {
      add('voc', 'Луната е „на празен ход“', vocSoft ? -5 : -14, 'До края на знака си (' + SIGNS[moonSign] + ') Луната няма да образува нито един аспект с друга планета. Това е класическият знак, че „нищо няма да излезе“ от въпроса.' + (vocSoft ? ' В този знак правилото е по-меко, затова ефектът е по-слаб.' : ''));
    } else {
      const nx = mn.next;
      const tgt = nx.planet;
      let d = 0, txt = 'Следващото действие на Луната е ' + nx.asp.bg + ' ' + withP(tgt) + ' ' + fmtTime(nx.t) + '.';
      if (tgt === S2 && S2 !== S1) { d = nx.asp.soft ? (perfected ? 6 : 10) : 3; txt += ' Това е точно показателят на желаното, така че Луната води въпроса натам.'; if (!timing && nx.asp.soft) timing = { days: nx.t, text: fmtTime(nx.t) }; }
      else if (tgt === S1) { d = 0; txt += ' Това е твоят показател — Луната те „връща“ към самия теб.'; }
      else if (BENEFIC[tgt]) { d = nx.asp.soft ? 5 : 1; txt += nx.asp.soft ? ' Това е добронамерена планета — малко в плюс.' : ' Добронамерена планета, но с напрежение.'; }
      else if (MALEFIC[tgt]) { d = nx.asp.soft ? -2 : -8; txt += nx.asp.soft ? ' Тежка планета, но аспектът е мек.' : ' Това е тежка планета с напрегнат аспект — малко в минус.'; }
      add('moonnext', 'Следващият ход на Луната', d, txt);
    }
    const mdeg = pos.moon.lon - moonSign * 30;
    if ((moonSign === 6 && mdeg >= 15) || (moonSign === 7 && mdeg < 15)) {
      add('viacomb', 'Луната е в „горящия път“', -7, 'Луната е между 15° Везни и 15° Скорпион. Това е традиционно място на объркване, импулсивност и риск от грешна преценка.');
    }
    if (moonSign === 3 || moonSign === 1) add('moondig', 'Луната е силна', 4, 'Луната е в ' + SIGNS[moonSign] + ' — знак, в който е особено силна и надеждна.');
    else if (moonSign === 7 || moonSign === 9) add('moondig', 'Луната е слаба', -4, 'Луната е в ' + SIGNS[moonSign] + ' — знак, в който е затруднена.');

    /* 3. състояние на показателите */
    const c1 = cond[S1], c2 = cond[S2];
    const dtxt = (k, c) => PBG[k] + ' е в ' + pos[k].fmt.text + ', ' + c.notes.join(', ') + (c.ess.labels.length ? '; ' + c.ess.labels.join(', ') : '') + '.';
    if (S1 === S2) {
      add('cond', 'Сила на общия показател', 0.8 * clamp(c1.total, -12, 14), 'Състояние на ' + n1 + ': ' + strengthWord(c1.total) + '. ' + dtxt(S1, c1));
    } else {
      add('cond2', 'Сила на показателя на желаното (' + n2 + ')', 0.8 * clamp(c2.total, -12, 14), 'Състояние на ' + n2 + ': ' + strengthWord(c2.total) + '. ' + dtxt(S2, c2));
      add('cond1', 'Сила на твоя показател (' + n1 + ')', 0.4 * clamp(c1.total, -12, 14), 'Състояние на ' + n1 + ': ' + strengthWord(c1.total) + '. ' + dtxt(S1, c1));
    }

    /* 4. сумиране */
    const sum = items.reduce((s, x) => s + x.delta, 0);
    const raw = 50 + pull * sum;
    const pct = Math.round(clamp(raw, 5, 95));

    let verdict, tone;
    if (pct >= 75) { verdict = 'Много вероятно ДА'; tone = 'yes2'; }
    else if (pct >= 60) { verdict = 'По-скоро ДА'; tone = 'yes1'; }
    else if (pct > 40) { verdict = 'Неясно — около 50 на 50'; tone = 'mid'; }
    else if (pct > 25) { verdict = 'По-скоро НЕ'; tone = 'no1'; }
    else { verdict = 'Много вероятно НЕ'; tone = 'no2'; }

    /* 5. обяснение на български */
    const pos2 = items.filter((x) => x.delta >= 4).sort((a, b) => b.delta - a.delta);
    const neg2 = items.filter((x) => x.delta <= -4).sort((a, b) => a.delta - b.delta);
    const parts = [];
    const main = items.find((x) => ['perfect', 'same', 'translation', 'collection', 'refrain', 'separating', 'none'].indexOf(x.id) >= 0);
    if (main) parts.push(main.text);
    const mo = items.find((x) => x.id === 'voc' || x.id === 'moonnext');
    if (mo && Math.abs(mo.delta) >= 3) parts.push(mo.text);
    const cc = items.find((x) => x.id === 'cond2' || x.id === 'cond');
    if (cc && Math.abs(cc.delta) >= 3) parts.push(cc.delta > 0 ? 'Показателят на желаното е в добро състояние, което му дава сила да се осъществи.' : 'Показателят на желаното е в затруднено състояние, което намалява шансовете да се осъществи.');
    let summary = parts.join(' ');
    if (!summary) summary = 'Знаците в картата са смесени и не сочат ясно в една посока.';
    const pctLine = 'Общо, картата дава около ' + pct + '% за положителен изход.';

    const chartPlanets = PL.map((k) => ({ key: k, name: PBG[k], glyph: PGLYPH[k], lon: pos[k].lon, house: pos[k].house, retro: !!pos[k].retro, fmt: pos[k].fmt, speed: pos[k].speed, condition: cond[k].total }));

    return {
      pct, verdict, tone, summary, pctLine, items, warnings, timing,
      significators: { querent: S1, quesited: S2, querentName: n1, quesitedName: n2, house: cat.house, thing: cat.thing, category: cat },
      chart: {
        jd, date: date.toISOString(), lat, lon, asc: H.asc, mc: H.mc, cusps: H.cusps.slice(), isDay,
        ascFmt: fmtPos(H.asc), mcFmt: fmtPos(H.mc), planets: chartPlanets,
        moon: { voc: mn.voc, exitDays: mn.exitT, next: mn.next ? { planet: mn.next.planet, aspect: mn.next.asp.bg, days: mn.next.t } : null },
      },
      sum: Math.round(sum * 10) / 10, pull, mainKind,
    };
  }

  return {
    judge, positions, houses, houseOf, jdFromDate, essential, aspectNow, firstCrossing, Sim, moonNextAspect, rawLons,
    withP, CATEGORIES, SIGNS, SIGN_GLYPH, PBG, PGLYPH, PL, ASPECTS, fmtPos, fmtTime, rev, n180,
  };
});
