// Проверка на енджина срещу публикувани референтни стойности.
const H = require('../src/engine.js');
let fails = 0;
const ok = (name, cond, info) => { if (!cond) fails++; console.log((cond ? 'OK   ' : 'FAIL ') + name + (info ? '  ' + info : '')); };
const near = (a, b, tol) => Math.abs(H.n180(a - b)) <= tol;
const jdTT = (y, m, d, h = 0) => H.jdFromDate(new Date(Date.UTC(y, m - 1, d, Math.floor(h), Math.round((h % 1) * 60))));

// --- Meeus, Astronomical Algorithms (примери) ---
let p = H.positions(jdTT(1992, 4, 12));
ok('Луна 1992-04-12 0h: λ≈133.167°', near(p.moon.lon, 133.1673, 0.15), p.moon.lon.toFixed(3));
ok('Луна 1992-04-12 0h: β≈-3.229°', Math.abs(p.moon.lat + 3.2291) < 0.1, p.moon.lat.toFixed(3));
p = H.positions(jdTT(1992, 10, 13));
ok('Слънце 1992-10-13 0h: λ≈199.909°', near(p.sun.lon, 199.909, 0.03), p.sun.lon.toFixed(3));
p = H.positions(jdTT(1992, 12, 20));
ok('Венера 1992-12-20 0h: λ≈313.081°', near(p.venus.lon, 313.081, 0.1), p.venus.lon.toFixed(3));

// --- равноденствия и слънцестояния (UTC) ---
for (const [label, y, m, d, hh, mm, target] of [
  ['равноденствие 2024-03-20 03:06', 2024, 3, 20, 3, 6, 0],
  ['слънцестояние 2024-06-20 20:51', 2024, 6, 20, 20, 51, 90],
  ['равноденствие 2024-09-22 12:44', 2024, 9, 22, 12, 44, 180],
  ['слънцестояние 2024-12-21 09:21', 2024, 12, 21, 9, 21, 270],
]) {
  const q = H.positions(jdTT(y, m, d, hh + mm / 60));
  ok('Слънце ' + label, near(q.sun.lon, target, 0.03), q.sun.lon.toFixed(3));
}

// --- новолуния и пълнолуния (UTC) ---
for (const [label, y, m, d, hh, mm, opp] of [
  ['новолуние 2024-04-08 18:21', 2024, 4, 8, 18, 21, 0],
  ['пълнолуние 2024-04-23 23:49', 2024, 4, 23, 23, 49, 180],
  ['новолуние 2025-01-29 12:36', 2025, 1, 29, 12, 36, 0],
  ['пълнолуние 2025-03-14 06:55', 2025, 3, 14, 6, 55, 180],
  ['новолуние 2025-09-21 19:54', 2025, 9, 21, 19, 54, 0],
]) {
  const q = H.positions(jdTT(y, m, d, hh + mm / 60));
  const sep = H.n180(q.moon.lon - q.sun.lon - opp);
  ok('Луна/Слънце ' + label, Math.abs(sep) < 0.1, 'разлика ' + sep.toFixed(3) + '°');
}

// --- Голямо съвпадение Юпитер-Сатурн 2020-12-21 ~18:20 UTC, λ≈300.3° ---
p = H.positions(jdTT(2020, 12, 21, 18 + 20 / 60));
ok('Юпитер-Сатурн 2020-12-21: съвпад', Math.abs(H.n180(p.jupiter.lon - p.saturn.lon)) < 0.1, 'разлика ' + H.n180(p.jupiter.lon - p.saturn.lon).toFixed(3));
ok('Юпитер 2020-12-21: λ≈300.49° (0°29′ Водолей)', near(p.jupiter.lon, 300.49, 0.1), p.jupiter.lon.toFixed(3));

// --- ретроградност: Меркурий ретрограден 2024-04-01..04-25, директен в края на април ---
p = H.positions(jdTT(2024, 4, 10, 12));
ok('Меркурий ретрограден на 2024-04-10', p.mercury.retro === true, p.mercury.speed.toFixed(3));
p = H.positions(jdTT(2024, 5, 20, 12));
ok('Меркурий директен на 2024-05-20', p.mercury.retro === false);
p = H.positions(jdTT(2024, 8, 1, 12));
ok('Сатурн ретрограден на 2024-08-01', p.saturn.retro === true);
ok('Слънце и Луна никога ретроградни', !p.sun.retro && !p.moon.retro);

// --- Асцендент: височина 0 и изток; MC на меридиана ---
function horiz(lonEcl, latEcl, h, latObs) {
  const eps = h.eps;
  const x = Math.cos(lonEcl * Math.PI / 180) * Math.cos(latEcl * Math.PI / 180);
  const y = Math.sin(lonEcl * Math.PI / 180) * Math.cos(latEcl * Math.PI / 180) * Math.cos(eps * Math.PI / 180) - Math.sin(latEcl * Math.PI / 180) * Math.sin(eps * Math.PI / 180);
  const z = Math.sin(lonEcl * Math.PI / 180) * Math.cos(latEcl * Math.PI / 180) * Math.sin(eps * Math.PI / 180) + Math.sin(latEcl * Math.PI / 180) * Math.cos(eps * Math.PI / 180);
  const ra = Math.atan2(y, x) * 180 / Math.PI, dec = Math.asin(z) * 180 / Math.PI;
  const ha = H.n180(h.ramc - ra) * Math.PI / 180, ph = latObs * Math.PI / 180, d = dec * Math.PI / 180;
  const alt = Math.asin(Math.sin(ph) * Math.sin(d) + Math.cos(ph) * Math.cos(d) * Math.cos(ha)) * 180 / Math.PI;
  return { alt, ha: ha * 180 / Math.PI };
}
for (const [label, date, la, lo] of [
  ['София', new Date(Date.UTC(2026, 9, 17, 18, 0)), 42.7, 23.32],
  ['Атина', new Date(Date.UTC(2026, 0, 5, 3, 30)), 37.98, 23.73],
  ['Лондон', new Date(Date.UTC(2025, 6, 1, 12, 0)), 51.5, -0.12],
  ['Сидни', new Date(Date.UTC(2025, 2, 3, 22, 10)), -33.87, 151.2],
]) {
  const jd = H.jdFromDate(date), h = H.houses(jd, la, lo);
  const a = horiz(h.asc, 0, h, la), m = horiz(h.mc, 0, h, la);
  ok('ASC ' + label + ': височина 0 и на изток', Math.abs(a.alt) < 0.01 && a.ha < 0, 'alt=' + a.alt.toFixed(4) + ' ha=' + a.ha.toFixed(1));
  ok('MC ' + label + ': на меридиана', Math.abs(m.ha) < 0.01, 'ha=' + m.ha.toFixed(4));
  // къщите растат по ред
  let inc = true, tot = 0;
  for (let i = 1; i <= 12; i++) { const w = H.rev(h.cusps[i % 12 + 1] - h.cusps[i]); tot += w; if (w <= 0 || w >= 180) inc = false; }
  ok('Къщи ' + label + ': подредени, сума 360°', inc && Math.abs(tot - 360) < 1e-6, 'сума=' + tot.toFixed(3));
  // Региомонтан: кръгът на къщата минава през точката север/юг на хоризонта
  // проверка на условие: нормалата на къщата, умножена с точка от еклиптиката = 0
  const eps = h.eps * Math.PI / 180, R = h.ramc * Math.PI / 180, ph = la * Math.PI / 180;
  [[11, 30], [12, 60], [2, 120], [3, 150]].forEach(([hn, t]) => {
    const L = h.cusps[hn] * Math.PI / 180, tt = t * Math.PI / 180;
    const xe = Math.cos(L), ye = Math.sin(L) * Math.cos(eps), ze = Math.sin(L) * Math.sin(eps);
    const x = xe * Math.cos(R) + ye * Math.sin(R), y = -xe * Math.sin(R) + ye * Math.cos(R), z = ze;
    const n = [-Math.cos(ph) * Math.sin(tt), Math.cos(ph) * Math.cos(tt), -Math.sin(ph) * Math.sin(tt)];
    const dot = n[0] * x + n[1] * y + n[2] * z;
    ok('Региомонтан ' + label + ' къща ' + hn + ': на кръга', Math.abs(dot) < 1e-9, dot.toExponential(1));
  });
}

// --- пълна преценка: стабилност и разумни стойности ---
let minP = 100, maxP = 0, crashes = 0, n = 0;
const counts = {};
const t0 = Date.now();
for (let i = 0; i < 600; i++) {
  const date = new Date(Date.UTC(2026, 0, 1) + i * 37 * 3600 * 1000 + (i % 7) * 600000);
  for (const cat of ['love', 'work', 'money', 'other']) {
    try {
      const r = H.judge({ date, lat: 42.7, lon: 23.3, category: cat });
      if (!(r.pct >= 5 && r.pct <= 95) || !r.summary || !isFinite(r.sum)) throw new Error('bad result');
      minP = Math.min(minP, r.pct); maxP = Math.max(maxP, r.pct); n++;
      counts[r.mainKind] = (counts[r.mainKind] || 0) + 1;
    } catch (e) { crashes++; if (crashes < 4) console.log(e.stack); }
  }
}
ok('2400 преценки без грешка', crashes === 0, 'min=' + minP + ' max=' + maxP + ' време ' + (Date.now() - t0) + 'ms');
console.log('Разпределение на основната връзка:', counts);
// разпределение на процентите
const buckets = new Array(10).fill(0);
for (let i = 0; i < 400; i++) {
  const r = H.judge({ date: new Date(Date.UTC(2026, 3, 1) + i * 53 * 3600 * 1000), lat: 42.7, lon: 23.3, category: 'love' });
  buckets[Math.min(9, Math.floor(r.pct / 10))]++;
}
console.log('Хистограма на % (по 10):', buckets.join(' '));

console.log(fails ? '\nПровалени проверки: ' + fails : '\nВсички проверки минаха.');
process.exit(fails ? 1 : 0);
