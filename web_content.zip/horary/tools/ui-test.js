// Зарежда dist/index.html в Chromium, подава въпрос и снима резултата.
const { chromium } = require(process.env.PW_MODULE || 'playwright');
const path = require('path');
const out = process.argv[2];
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    const ctx = await browser.newContext({ viewport: { width: 400, height: 860 }, colorScheme: scheme, deviceScaleFactor: 2, locale: 'bg-BG' });
    const page = await ctx.newPage();
    page.on('console', (m) => { if (m.type() === 'error') errors.push(scheme + ' console: ' + m.text()); });
    page.on('pageerror', (e) => errors.push(scheme + ' pageerror: ' + e.message));
    await page.goto('file://' + path.resolve(__dirname, '../dist/index.html'));
    await page.screenshot({ path: out + '/ask-' + scheme + '.png', fullPage: true });
    await page.fill('#q', 'Ще получа ли работата, за която кандидатствах?');
    await page.selectOption('#topic', 'work');
    await page.click('#go');
    await page.waitForSelector('#view-result:not([hidden])');
    await page.waitForTimeout(1200);
    await page.screenshot({ path: out + '/result-' + scheme + '.png', fullPage: true });
    const sw = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    if (sw > 0) errors.push(scheme + ' хоризонтален скрол: ' + sw + 'px');
    if (scheme === 'light') {
      await page.click('#again');
      await page.waitForSelector('#view-ask:not([hidden])');
      const n = await page.locator('#hist button').count();
      if (n !== 1) errors.push('историята: очаквам 1, има ' + n);
      await page.click('#hist button');
      await page.waitForSelector('#view-result:not([hidden])');
      const back = await page.evaluate(() => window.__back());
      if (back !== true) errors.push('__back не върна true');
    }
    await ctx.close();
  }
  await browser.close();
  console.log(errors.length ? errors.join('\n') : 'Няма грешки в конзолата, няма хоризонтален скрол.');
})();
