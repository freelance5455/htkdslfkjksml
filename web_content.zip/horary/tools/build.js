// Сглобява единния HTML: src/index.template.html + engine.js + app.js.
// dist/artifact.html - фрагмент за публикуване като страница
// dist/index.html    - пълен документ за Android (assets) и за сайт/PWA
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const tpl = read('src/index.template.html');
const engine = read('src/engine.js'), app = read('src/app.js');
if (/<\/script/i.test(engine + app)) throw new Error('Кодът съдържа </script');
const body = tpl.replace('/*@@ENGINE@@*/', () => engine).replace('/*@@APP@@*/', () => app);
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/artifact.html'), body);

// титулът, метаданните, стиловете и скриптовете са в head; елементите на body трябва да са в body
const bodyStart = body.indexOf('<main id="app">'), scriptStart = body.indexOf('<script>');
const m = [body.slice(bodyStart, scriptStart).trim()];
const scripts = body.match(/<script>[\s\S]*<\/script>\s*$/)[0];
const headPart = body.slice(0, body.indexOf('<main id="app">')).replace('<meta name="claude:viewport-fit-sides" content="cover">\n', '');
const doc = '<!doctype html>\n<html lang="bg">\n<head>\n<meta charset="utf-8">\n' +
  '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n' +
  '<meta name="theme-color" content="#0C111F">\n' +
  '<style>:root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui,sans-serif}img{max-width:100%}[hidden]{display:none!important}</style>\n' +
  headPart + '</head>\n<body>\n' + m[0] + '\n' + scripts + '\n</body>\n</html>\n';
fs.writeFileSync(path.join(root, 'dist/index.html'), doc);
fs.mkdirSync(path.join(root, 'app/src/main/assets'), { recursive: true });
fs.writeFileSync(path.join(root, 'app/src/main/assets/index.html'), doc);
console.log('dist/artifact.html', (body.length / 1024).toFixed(0) + ' KB;', 'dist/index.html', (doc.length / 1024).toFixed(0) + ' KB');
