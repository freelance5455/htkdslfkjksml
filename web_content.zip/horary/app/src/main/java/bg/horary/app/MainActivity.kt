package bg.horary.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader

/**
 * Тънка обвивка около уеб приложението в assets/index.html.
 * Страницата се сервира от https://appassets.androidplatform.net (сигурен контекст),
 * изцяло от паметта на телефона, без интернет.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var pendingOrigin: String? = null
    private var pendingCallback: GeolocationPermissions.Callback? = null

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.setBackgroundColor(getColor(R.color.app_bg))

        webView = WebView(this)
        webView.setBackgroundColor(getColor(R.color.app_bg))
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.requestFocus()
        root.addView(
            webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)

        // Android 15+ чертае под системните ленти: оставяме място за тях.
        root.setOnApplyWindowInsetsListener { v, insets ->
            var l = 0
            var t = 0
            var r = 0
            var b = 0
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime()
                )
                l = bars.left
                t = bars.top
                r = bars.right
                b = bars.bottom
            } else {
                l = insets.systemWindowInsetLeft
                t = insets.systemWindowInsetTop
                r = insets.systemWindowInsetRight
                b = insets.systemWindowInsetBottom
                if (Build.VERSION.SDK_INT >= 28) {
                    insets.displayCutout?.let {
                        l = maxOf(l, it.safeInsetLeft)
                        t = maxOf(t, it.safeInsetTop)
                        r = maxOf(r, it.safeInsetRight)
                        b = maxOf(b, it.safeInsetBottom)
                    }
                }
            }
            v.setPadding(l, t, r, b)
            insets
        }

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            useWideViewPort = true
            loadWithOverviewMode = false
            setSupportZoom(false)
            builtInZoomControls = false
            setGeolocationEnabled(true)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            // Само собствената страница се отваря тук; външни връзки не се следват.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false)
                } else {
                    pendingOrigin = origin
                    pendingCallback = callback
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                        REQUEST_LOCATION
                    )
                }
            }
        }

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION) {
            val granted = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            pendingCallback?.invoke(pendingOrigin, granted, false)
            pendingCallback = null
            pendingOrigin = null
        }
    }

    // Бутонът „назад“ първо връща от резултата към формата, после затваря приложението.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        webView.evaluateJavascript("(function(){return window.__back ? window.__back() : false;})()") { result ->
            if (result != "true") finish()
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_LOCATION = 1
    }
}
