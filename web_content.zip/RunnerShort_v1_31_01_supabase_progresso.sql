-- Runner Short v1.31.02 — migração segura para salvar o progresso online.
-- Execute no SQL Editor do projeto Supabase usado pelo jogo.
-- Não apaga dados existentes. Não use service_role no jogo.

ALTER TABLE public.player_game_progress
  ADD COLUMN IF NOT EXISTS game_state jsonb NOT NULL DEFAULT '{}'::jsonb;

-- A sincronização usa upsert por player_id; esse índice garante uma linha por jogador.
CREATE UNIQUE INDEX IF NOT EXISTS player_game_progress_player_id_uidx
  ON public.player_game_progress (player_id);

ALTER TABLE public.player_game_progress ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON TABLE public.player_game_progress TO authenticated;
REVOKE ALL ON TABLE public.player_game_progress FROM anon;

-- Mantém a política SELECT já existente. Cria apenas INSERT/UPDATE se ainda não existirem.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'player_game_progress'
      AND policyname = 'Players can insert their own game progress'
  ) THEN
    CREATE POLICY "Players can insert their own game progress"
      ON public.player_game_progress
      FOR INSERT TO authenticated
      WITH CHECK (auth.uid() = player_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'player_game_progress'
      AND policyname = 'Players can update their own game progress'
  ) THEN
    CREATE POLICY "Players can update their own game progress"
      ON public.player_game_progress
      FOR UPDATE TO authenticated
      USING (auth.uid() = player_id)
      WITH CHECK (auth.uid() = player_id);
  END IF;
END $$;
