#!/data/data/com.termux/files/usr/bin/sh
set -eu
cd "$(dirname "$0")"
CC_BIN="${CC:-clang}"
if ! command -v "$CC_BIN" >/dev/null 2>&1; then
  echo "Compiler not found. In Termux run: pkg install clang openssl" >&2
  exit 1
fi
OPENSSL_PREFIX="${PREFIX:-/usr}"
if [ ! -f "$OPENSSL_PREFIX/include/openssl/sha.h" ] && [ ! -f /usr/include/openssl/sha.h ]; then
  echo "OpenSSL headers not found. In Termux run: pkg install openssl" >&2
  exit 1
fi
"$CC_BIN" -O3 -fPIC -shared miner_core.c -o miner_core.so -lcrypto
echo "Native SHA-256d accelerator built: miner_core.so"
