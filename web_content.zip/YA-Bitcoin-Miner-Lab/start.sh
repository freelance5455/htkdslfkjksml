#!/data/data/com.termux/files/usr/bin/sh
# One-command launcher for Termux: installs what is missing, builds the fast C core, starts the app.
set -eu
cd "$(dirname "$0")"
need=""
command -v python >/dev/null 2>&1 || need="$need python"
command -v clang >/dev/null 2>&1 || need="$need clang"
[ -f "${PREFIX:-/usr}/include/openssl/sha.h" ] || need="$need openssl"
if [ -n "$need" ] && command -v pkg >/dev/null 2>&1; then
  echo "Installing:$need"
  pkg install -y $need
fi
if [ ! -f miner_core.so ] || [ miner_core.c -nt miner_core.so ]; then
  sh build_native.sh || echo "Native build failed; the slow Python engine will be used."
fi
command -v termux-battery-status >/dev/null 2>&1 || echo "Tip: 'pkg install termux-api' (+ the Termux:API app) enables the battery-temperature guard."
command -v termux-open-url >/dev/null 2>&1 && (sleep 2; termux-open-url http://127.0.0.1:8765) &
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock || true
exec python app.py
