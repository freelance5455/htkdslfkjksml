import hashlib
import struct
import unittest

from app import DIFF1_TARGET, build_header_prefix, parse_target, sha256d


class MinerTests(unittest.TestCase):
    def test_sha256d_known_vector(self):
        expected = hashlib.sha256(hashlib.sha256(b"abc").digest()).digest()
        self.assertEqual(sha256d(b"abc"), expected)
        self.assertEqual(len(sha256d(b"")), 32)

    def test_target_for_difficulty_one(self):
        self.assertEqual(parse_target(1), DIFF1_TARGET)

    def test_target_clamps_at_max(self):
        self.assertEqual(parse_target("1e-100"), (1 << 256) - 1)

    def test_header_prefix_has_76_bytes(self):
        job = {
            "coinb1": "01000000", "coinb2": "ffffffff",
            "merkle_branch": [], "prevhash": "00" * 32,
            "version": "20000000", "ntime": "65f00000", "nbits": "1d00ffff",
        }
        prefix = build_header_prefix(job, "aabbccdd", "00000001")
        self.assertEqual(len(prefix), 76)
        self.assertEqual(prefix[:4], struct.pack("<I", 0x20000000))
        self.assertEqual(prefix[4:36], b"\x00" * 32)
        self.assertEqual(prefix[68:72], struct.pack("<I", 0x65f00000))
        self.assertEqual(prefix[72:76], struct.pack("<I", 0x1d00ffff))


if __name__ == "__main__":
    unittest.main(verbosity=2)
