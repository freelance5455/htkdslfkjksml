import hashlib
import struct
import unittest

import app


class MinerTests(unittest.TestCase):
    def test_sha256d_known_vector(self):
        expected = hashlib.sha256(hashlib.sha256(b"abc").digest()).digest()
        self.assertEqual(app.sha256d(b"abc"), expected)
        self.assertEqual(len(app.sha256d(b"")), 32)

    def test_target_for_difficulty_one(self):
        self.assertEqual(app.parse_target(1), app.DIFF1_TARGET)

    def test_target_clamps_at_max(self):
        self.assertEqual(app.parse_target("1e-100"), (1 << 256) - 1)

    def test_header_prefix_has_76_bytes(self):
        job = {
            "coinb1": "01000000", "coinb2": "ffffffff",
            "merkle_branch": [], "prevhash": "00" * 32,
            "version": "20000000", "ntime": "65f00000", "nbits": "1d00ffff",
        }
        prefix = app.build_header_prefix(job, "aabbccdd", "00000001")
        self.assertEqual(len(prefix), 76)
        self.assertEqual(prefix[:4], struct.pack("<I", 0x20000000))
        self.assertEqual(prefix[4:36], b"\x00" * 32)
        self.assertEqual(prefix[68:72], struct.pack("<I", 0x65f00000))
        self.assertEqual(prefix[72:76], struct.pack("<I", 0x1d00ffff))

    def test_stratum_prevhash_word_byte_order(self):
        job = {
            "coinb1": "01000000", "coinb2": "ffffffff",
            "merkle_branch": [], "prevhash": "00112233" * 8,
            "version": "20000000", "ntime": "65f00000", "nbits": "1d00ffff",
        }
        prefix = app.build_header_prefix(job, "aabbccdd", "00000001")
        self.assertEqual(prefix[4:36], bytes.fromhex("33221100" * 8))

    def test_mainnet_address_validation(self):
        self.assertTrue(app.valid_btc_mainnet_address("bc1q28kkr5hk4gnqe3evma6runjrd2pvqyp8fpwfzu"))
        self.assertTrue(app.valid_btc_mainnet_address("1BoatSLRHtKNngkdXEeobR76b53LETtpyT"))
        self.assertFalse(app.valid_btc_mainnet_address("not-a-bitcoin-address"))
        self.assertFalse(app.valid_btc_mainnet_address("tb1q28kkr5hk4gnqe3evma6runjrd2pvqyp8fpwfzu"))

    def test_scan_batch_reports_real_sha256d_hash(self):
        prefix = bytes(76)
        start_nonce = 1234
        done, found_nonce, digest = app.MINER._scan_batch(prefix, (1 << 256) - 1, start_nonce, 16)
        self.assertEqual(done, 1)
        self.assertEqual(found_nonce, start_nonce)
        self.assertEqual(digest, app.sha256d(prefix + struct.pack("<I", start_nonce)))

    def test_ckpool_requires_a_public_mainnet_address(self):
        miner = app.Miner()
        ok, message = miner.start({"pool_id": "ckpool-solo", "worker": "private-key-is-not-an-address"})
        self.assertFalse(ok)
        self.assertIn("آدرس عمومی", message)
        self.assertFalse(miner.status()["running"])

    def test_discovery_prefers_ckpool_when_stratum_is_available(self):
        from unittest.mock import patch
        def fake_probe(profile):
            return {"id": profile["id"], "name": profile["name"], "host": profile["host"], "port": profile["port"],
                    "mode": profile["mode"], "account_required": profile["account_required"], "docs": profile["docs"],
                    "description": profile["description"], "reachable": profile["id"] == "ckpool-solo",
                    "tcp_reachable": True, "stratum_v1": profile["id"] == "ckpool-solo", "latency_ms": 30,
                    "detail": "test"}
        with patch("app.probe_pool", side_effect=fake_probe):
            result = app.discover_pools()
        self.assertEqual(result["recommended_id"], "ckpool-solo")


if __name__ == "__main__":
    unittest.main(verbosity=2)
