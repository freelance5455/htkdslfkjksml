/* Optional native SHA-256d nonce scanner for YA Bitcoin Miner Lab.
 * This is CPU mining code, not a profitability promise. Uses OpenSSL/libcrypto.
 */
#include <stdint.h>
#include <string.h>
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>

static int hash_meets_target(const unsigned char digest[32], const unsigned char target_be[32]) {
    /* Bitcoin interprets the displayed block hash as the reverse of SHA256's raw digest. */
    for (int i = 0; i < 32; ++i) {
        unsigned char h = digest[31 - i];
        unsigned char t = target_be[i];
        if (h < t) return 1;
        if (h > t) return 0;
    }
    return 1; /* equal */
}

/*
 * Returns 1 if a share-candidate was found, otherwise 0.
 * hashes_done includes the candidate hash when found.
 * header_prefix is exactly the first 76 bytes of the Bitcoin block header.
 * target_be is a 32-byte big-endian integer target.
 */
int ya_scan_nonce(const unsigned char *header_prefix,
                  const unsigned char *target_be,
                  uint32_t start_nonce,
                  uint32_t max_hashes,
                  uint32_t *hashes_done,
                  uint32_t *found_nonce,
                  unsigned char *found_digest) {
    unsigned char header[80];
    unsigned char first[SHA256_DIGEST_LENGTH];
    unsigned char digest[SHA256_DIGEST_LENGTH];
    SHA256_CTX base_ctx;
    memcpy(header, header_prefix, 76);
    *hashes_done = 0;
    *found_nonce = 0;

    /* Cache the first 64-byte SHA-256 block: it is unchanged for every nonce. */
    SHA256_Init(&base_ctx);
    SHA256_Update(&base_ctx, header, 64);

    for (uint32_t i = 0; i < max_hashes; ++i) {
        uint32_t nonce = start_nonce + i; /* defined uint32_t wrap */
        header[76] = (unsigned char)(nonce & 0xffU);
        header[77] = (unsigned char)((nonce >> 8) & 0xffU);
        header[78] = (unsigned char)((nonce >> 16) & 0xffU);
        header[79] = (unsigned char)((nonce >> 24) & 0xffU);
        SHA256_CTX ctx = base_ctx;
        SHA256_Update(&ctx, header + 64, 16);
        SHA256_Final(first, &ctx);
        SHA256(first, sizeof(first), digest);
        *hashes_done = i + 1;
        if (hash_meets_target(digest, target_be)) {
            *found_nonce = nonce;
            memcpy(found_digest, digest, 32);
            return 1;
        }
    }
    return 0;
}
