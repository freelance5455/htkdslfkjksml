/* Optional native SHA-256d nonce scanner for YA Bitcoin Miner Lab (v0.3).
 *
 * Faster than the v0.2 scanner because:
 *   1. The first 64 header bytes are hashed once (midstate) and reused.
 *   2. Each nonce costs exactly two compression-function calls
 *      (SHA256_Transform) with prebuilt, pre-padded blocks; no Init/Update/Final
 *      bookkeeping. On ARMv8 phones OpenSSL dispatches Transform to the CPU's
 *      SHA-2 instructions when available.
 *   3. A 32-bit early-reject test on the last digest word discards almost every
 *      nonce without serialising the digest.
 *
 * This is CPU mining code, not a profitability promise.
 */
#include <stdint.h>
#include <string.h>
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>

static int hash_meets_target(const unsigned char digest[32], const unsigned char target_be[32]) {
    /* Bitcoin interprets the displayed block hash as the reverse of SHA256's raw digest. */
    for (int i = 0; i < 32; ++i) {
        unsigned char h = digest[31 - i];
        unsigned char t = target_be[i];
        if (h < t) return 1;
        if (h > t) return 0;
    }
    return 1; /* equal */
}

static inline void put_be32(unsigned char *p, uint32_t v) {
    p[0] = (unsigned char)(v >> 24);
    p[1] = (unsigned char)(v >> 16);
    p[2] = (unsigned char)(v >> 8);
    p[3] = (unsigned char)v;
}

static inline uint32_t swap32(uint32_t v) {
    return (v >> 24) | ((v >> 8) & 0x0000ff00U) | ((v << 8) & 0x00ff0000U) | (v << 24);
}

/* Reports the engine revision so the Python side can show it. */
int ya_core_version(void) { return 3; }

/*
 * Returns 1 if a share-candidate was found, otherwise 0.
 * hashes_done includes the candidate hash when found.
 * header_prefix is exactly the first 76 bytes of the Bitcoin block header.
 * target_be is a 32-byte big-endian integer target.
 */
int ya_scan_nonce(const unsigned char *header_prefix,
                  const unsigned char *target_be,
                  uint32_t start_nonce,
                  uint32_t max_hashes,
                  uint32_t *hashes_done,
                  uint32_t *found_nonce,
                  unsigned char *found_digest) {
    SHA256_CTX mid, iv, c1, c2;
    unsigned char block1[64]; /* header bytes 64..79 + padding for an 80-byte message */
    unsigned char block2[64]; /* first digest (32 bytes) + padding for a 32-byte message */
    unsigned char digest[32];

    *hashes_done = 0;
    *found_nonce = 0;

    /* Midstate over the first 64 bytes of the header. */
    SHA256_Init(&mid);
    SHA256_Update(&mid, header_prefix, 64);
    SHA256_Init(&iv); /* standard SHA-256 initial state for the second hash */

    memset(block1, 0, sizeof(block1));
    memcpy(block1, header_prefix + 64, 12); /* merkle tail(4) + ntime(4) + nbits(4) */
    block1[16] = 0x80;                      /* padding marker after the 80th byte */
    block1[62] = 0x02; block1[63] = 0x80;   /* message length = 640 bits */

    memset(block2, 0, sizeof(block2));
    block2[32] = 0x80;
    block2[62] = 0x01; block2[63] = 0x00;   /* message length = 256 bits */

    const uint32_t target_top =
        ((uint32_t)target_be[0] << 24) | ((uint32_t)target_be[1] << 16) |
        ((uint32_t)target_be[2] << 8) | (uint32_t)target_be[3];

    for (uint32_t i = 0; i < max_hashes; ++i) {
        uint32_t nonce = start_nonce + i; /* defined uint32_t wrap */
        block1[12] = (unsigned char)(nonce & 0xffU);
        block1[13] = (unsigned char)((nonce >> 8) & 0xffU);
        block1[14] = (unsigned char)((nonce >> 16) & 0xffU);
        block1[15] = (unsigned char)((nonce >> 24) & 0xffU);

        memcpy(c1.h, mid.h, sizeof(mid.h));
        SHA256_Transform(&c1, block1);
        for (int j = 0; j < 8; ++j) put_be32(block2 + 4 * j, c1.h[j]);

        memcpy(c2.h, iv.h, sizeof(iv.h));
        SHA256_Transform(&c2, block2);

        /* The most significant 32 bits of the hash-as-number are the byte-swapped
         * last state word. If they already exceed the target's top word the hash
         * cannot meet the target, so skip the full comparison. */
        if (swap32(c2.h[7]) > target_top) continue;

        for (int j = 0; j < 8; ++j) put_be32(digest + 4 * j, c2.h[j]);
        if (hash_meets_target(digest, target_be)) {
            *hashes_done = i + 1;
            *found_nonce = nonce;
            memcpy(found_digest, digest, 32);
            return 1;
        }
    }
    *hashes_done = max_hashes;
    return 0;
}
