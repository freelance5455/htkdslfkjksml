"""Tests for the v0.3 features. All network tests use local mock servers only."""
import hashlib
import http.client
import json
import os
import socket
import struct
import threading
import time
import unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch

import app

ADDR = "1BoatSLRHtKNngkdXEeobR76b53LETtpyT"


def sd(b):
    return hashlib.sha256(hashlib.sha256(b).digest()).digest()


class MockPool:
    """Tiny Stratum V1 pool. behaviour: 'ok' | 'reject_auth' | 'drop'. Validates every submitted share."""

    def __init__(self, behaviour="ok", difficulty="0.0001"):
        self.behaviour, self.difficulty = behaviour, difficulty
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(8)
        self.port = self.sock.getsockname()[1]
        self.connections = 0
        self.valid_shares = 0
        self.invalid_shares = 0
        self.ex2_seen = set()
        self.workers_seen = set()
        self.stop = False
        self.job = ["job1", "00112233" * 8, "01000000", "ffffffff", [], "20000000", "1d00ffff", "65f00000", True]
        threading.Thread(target=self._accept, daemon=True).start()

    def _accept(self):
        while not self.stop:
            try:
                conn, _ = self.sock.accept()
            except OSError:
                return
            self.connections += 1
            threading.Thread(target=self._serve, args=(conn,), daemon=True).start()

    def _send(self, conn, obj):
        conn.sendall((json.dumps(obj) + "\n").encode())

    def _serve(self, conn):
        try:
            with conn:
                if self.behaviour == "drop":
                    return
                conn.settimeout(10)
                buf = b""
                while not self.stop:
                    chunk = conn.recv(8192)
                    if not chunk:
                        return
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        if not line.strip():
                            continue
                        msg = json.loads(line)
                        m = msg.get("method")
                        if m == "mining.subscribe":
                            self._send(conn, {"id": msg["id"], "result": [[], "aabbccdd", 4], "error": None})
                        elif m == "mining.authorize":
                            self.workers_seen.add(msg["params"][0])
                            ok = self.behaviour != "reject_auth"
                            self._send(conn, {"id": msg["id"], "result": ok, "error": None if ok else [24, "Unauthorized", None]})
                            if ok:
                                self._send(conn, {"id": None, "method": "mining.set_difficulty", "params": [self.difficulty]})
                                self._send(conn, {"id": None, "method": "mining.notify", "params": self.job})
                        elif m == "mining.submit":
                            worker, job_id, ex2, ntime, nonce_hex = msg["params"]
                            job = dict(zip(["job_id", "prevhash", "coinb1", "coinb2", "merkle_branch", "version", "nbits", "ntime", "clean_jobs"], self.job))
                            prefix = app.build_header_prefix(job, "aabbccdd", ex2)
                            digest = sd(prefix + struct.pack("<I", int(nonce_hex, 16)))
                            good = int.from_bytes(digest, "little") <= app.parse_target(self.difficulty)
                            if good:
                                self.valid_shares += 1
                                self.ex2_seen.add(ex2)
                            else:
                                self.invalid_shares += 1
                            self._send(conn, {"id": msg["id"], "result": good, "error": None if good else [23, "Low difficulty", None]})
        except (OSError, ValueError):
            pass

    def close(self):
        self.stop = True
        try:
            self.sock.close()
        except OSError:
            pass


def fake_profiles(*pairs):
    """Build POOL_PROFILES entries pointing at local mock pools."""
    out = {}
    for pid, pool in pairs:
        out[pid] = app._solo(pid, pid, "127.0.0.1", pool.port, 0.0, "", "mock")
    return out


def wait_for(cond, timeout=15.0):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if cond():
            return True
        time.sleep(0.05)
    return cond()


class NativeCoreTests(unittest.TestCase):
    @unittest.skipUnless(app.NATIVE_CORE, "native core not built")
    def test_native_matches_python_reference(self):
        import random
        rnd = random.Random(1234)
        for _ in range(150):
            prefix = bytes(rnd.getrandbits(8) for _ in range(76))
            start = rnd.getrandbits(32)
            target = rnd.getrandbits(rnd.choice([236, 248, 252, 255, 256]))
            cnt = rnd.choice([1, 9, 500])
            got = app.MINER._scan_batch(prefix, target, start, cnt)
            ref, n = (cnt, None, None), start
            for i in range(cnt):
                dg = sd(prefix + struct.pack("<I", n))
                if int.from_bytes(dg, "little") <= target:
                    ref = (i + 1, n, dg)
                    break
                n = (n + 1) & 0xFFFFFFFF
            self.assertEqual(got, ref)

    @unittest.skipUnless(app.NATIVE_CORE, "native core not built")
    def test_nonce_wraps_around(self):
        done, nonce, digest = app.MINER._scan_batch(bytes(76), (1 << 256) - 1, 0xFFFFFFFF, 3)
        self.assertEqual((done, nonce), (1, 0xFFFFFFFF))


class HelperTests(unittest.TestCase):
    def test_difficulty_from_nbits(self):
        self.assertAlmostEqual(app.nbits_to_difficulty("1d00ffff"), 1.0)
        self.assertIsNone(app.nbits_to_difficulty("zz"))
        self.assertIsNone(app.nbits_to_difficulty("1d000000"))
        self.assertGreater(app.nbits_to_difficulty("1703a30c"), 1e12)

    def test_expected_outcome_is_honest_for_a_phone(self):
        diff = 1.3e14
        e = app.expected_outcome(1_000_000, diff, 2.0)
        self.assertGreater(e["years_per_block"], 1e6)          # millions of years per block at 1 MH/s
        self.assertLess(e["chance_per_year"], 1e-6)
        self.assertLess(e["btc_per_day"], 1e-9)
        self.assertIsNone(app.expected_outcome(0, diff))
        self.assertIsNone(app.expected_outcome(1e6, None))

    def test_parse_battery_status(self):
        self.assertEqual(app.parse_battery_status('{"temperature": 38.5, "percentage": 80}'), 38.5)
        self.assertIsNone(app.parse_battery_status("not json"))
        self.assertIsNone(app.parse_battery_status('{"temperature": null}'))
        self.assertIsNone(app.parse_battery_status('{"temperature": 0}'))

    def test_rank_pools_prefers_no_account_then_fee_then_latency(self):
        def r(pid, fee, lat, acct=False, ok=True):
            return {"id": pid, "fee": fee, "latency_ms": lat, "account_required": acct, "reachable": ok, "stratum_v1": ok}
        ranked = app.rank_pools([r("a", 2.0, 10), r("b", 0.0, 90), r("c", 2.0, 5), r("acct", 0.0, 1, acct=True),
                                 r("down", 0.0, 1, ok=False), r("unk", None, 3)])
        self.assertEqual([x["id"] for x in ranked], ["b", "unk", "c", "a", "acct"])

    def test_discover_returns_ranking_and_failover(self):
        def fake_probe(profile, timeout=3.5):
            ok = profile["id"] != "ocean"
            return {"id": profile["id"], "name": profile["name"], "host": profile["host"], "port": profile["port"],
                    "mode": profile["mode"], "account_required": profile["account_required"], "docs": profile["docs"],
                    "description": "", "reachable": ok, "tcp_reachable": ok, "stratum_v1": ok,
                    "latency_ms": 20.0, "detail": "", "fee": profile.get("fee")}
        with patch("app.probe_pool", side_effect=fake_probe):
            d = app.discover_pools()
        self.assertEqual(d["recommended_id"], "public-pool")       # 0% fee first
        self.assertNotIn("ocean", d["failover_ids"])
        self.assertNotIn("braiins-primary", d["failover_ids"])      # needs an account
        self.assertIn("ckpool-solo", d["failover_ids"])

    def test_auto_mode_requires_valid_address(self):
        ok, msg = app.Miner().start({"pool_id": "auto", "worker": "nope"})
        self.assertFalse(ok)
        self.assertIn("آدرس عمومی", msg)

    def test_worker_suffix_and_normalisation(self):
        ok, w = app.check_worker_name({"user_kind": "btc-address"}, ADDR)
        self.assertTrue(ok)
        self.assertEqual(w, ADDR + ".YAphone")
        ok, w = app.check_worker_name({"user_kind": "btc-address"}, ADDR + ".rig1")
        self.assertEqual(w, ADDR + ".rig1")
        ok, _ = app.check_worker_name({"user_kind": "account-worker"}, "")
        self.assertFalse(ok)


class MiningFlowTests(unittest.TestCase):
    def setUp(self):
        self.pools = []
        app.Miner.RETRY_BASE = 0.1

    def tearDown(self):
        app.Miner.RETRY_BASE = 2
        for p in self.pools:
            p.close()

    def mk(self, *a, **k):
        p = MockPool(*a, **k)
        self.pools.append(p)
        return p

    def stop(self, miner):
        miner.stop()
        if miner.thread:
            miner.thread.join(timeout=6)
            self.assertFalse(miner.thread.is_alive(), "miner thread did not stop in time")

    @unittest.skipUnless(app.NATIVE_CORE, "native core not built")
    def test_multithreaded_mining_submits_only_valid_distinct_work(self):
        pool = self.mk()
        miner = app.Miner()
        ok, msg = miner.start({"pool_id": "custom", "host": "127.0.0.1", "port": pool.port,
                               "worker": "t.w", "password": "x", "threads": 2})
        self.assertTrue(ok, msg)
        self.assertEqual(miner.status()["threads"], min(2, os.cpu_count() or 1))
        self.assertTrue(wait_for(lambda: pool.valid_shares >= 6, 20), (pool.valid_shares, miner.status()))
        st = miner.status()
        self.stop(miner)
        self.assertEqual(pool.invalid_shares, 0)                    # every share really meets the target
        self.assertGreaterEqual(st["accepted"], 1)
        if (os.cpu_count() or 1) >= 2:
            self.assertGreaterEqual(len(pool.ex2_seen), 2, "workers must use different extranonce2 values")
        self.assertIsNotNone(st["network_difficulty"])               # taken from the job's nbits

    def test_failover_after_auth_rejection(self):
        bad, good = self.mk("reject_auth"), self.mk("ok")
        profiles = fake_profiles(("bad", bad), ("good", good))
        with patch.dict(app.POOL_PROFILES, profiles), \
             patch("app.discover_pools", return_value={"failover_ids": ["bad", "good"]}):
            miner = app.Miner()
            ok, msg = miner.start({"pool_id": "auto", "worker": ADDR})
            self.assertTrue(ok, msg)
            self.assertTrue(wait_for(lambda: good.valid_shares >= 1, 20), miner.status())
            st = miner.status()
            self.stop(miner)
        self.assertEqual(bad.connections, 1)
        self.assertEqual(st["pool_id"], "good")
        self.assertEqual(st["pool_index"], 2)
        self.assertIn(ADDR + ".YAphone", good.workers_seen)

    def test_failover_after_repeated_connection_failures(self):
        dead, good = self.mk("drop"), self.mk("ok")
        profiles = fake_profiles(("dead", dead), ("good", good))
        with patch.dict(app.POOL_PROFILES, profiles), \
             patch("app.discover_pools", return_value={"failover_ids": ["dead", "good"]}):
            miner = app.Miner()
            miner.start({"pool_id": "auto", "worker": ADDR})
            self.assertTrue(wait_for(lambda: good.valid_shares >= 1, 20), miner.status())
            self.stop(miner)
        self.assertGreaterEqual(dead.connections, 2)

    def test_single_rejected_pool_stops_instead_of_hammering(self):
        bad = self.mk("reject_auth")
        miner = app.Miner()
        miner.start({"pool_id": "custom", "host": "127.0.0.1", "port": bad.port, "worker": "x.y"})
        self.assertTrue(wait_for(lambda: not miner.status()["running"], 10), miner.status())
        self.assertEqual(bad.connections, 1)

    def test_auto_falls_back_to_default_list_when_probe_finds_nothing(self):
        good = self.mk("ok")
        profiles = fake_profiles(("public-pool", good))
        with patch.dict(app.POOL_PROFILES, profiles), \
             patch("app.discover_pools", return_value={"failover_ids": []}), \
             patch("app.DEFAULT_AUTO_ORDER", ["public-pool"]):
            miner = app.Miner()
            miner.start({"pool_id": "auto", "worker": ADDR})
            self.assertTrue(wait_for(lambda: good.valid_shares >= 1, 20), miner.status())
            self.stop(miner)

    def test_thermal_guard_pauses_and_resumes(self):
        miner = app.Miner()
        miner.max_temp = 42
        with patch("app.battery_temperature_c", return_value=44.0):
            miner._thermal_tick()
        self.assertTrue(miner.paused)
        with patch("app.battery_temperature_c", return_value=41.0):
            miner._thermal_tick()
        self.assertTrue(miner.paused, "hysteresis: stay paused until 3 degrees below the limit")
        with patch("app.battery_temperature_c", return_value=38.5):
            miner._thermal_tick()
        self.assertFalse(miner.paused)
        miner.max_temp = 0
        with patch("app.battery_temperature_c", return_value=99.0):
            miner._thermal_tick()
        self.assertFalse(miner.paused, "guard disabled")

    @unittest.skipUnless(app.NATIVE_CORE, "native core not built")
    def test_duty_cycle_reduces_hashrate(self):
        rates = {}
        for duty in (100, 25):
            pool = self.mk(difficulty="1e-100")
            pool.behaviour = "ok"
            miner = app.Miner()
            miner.start({"pool_id": "custom", "host": "127.0.0.1", "port": pool.port, "worker": "t.w",
                         "threads": 1, "duty": duty})
            time.sleep(2.6)
            rates[duty] = miner.status()["hashes"]
            self.stop(miner)
        self.assertLess(rates[25], rates[100])


class HttpSecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), app.Handler)
        cls.port = cls.httpd.server_address[1]
        cls.hosts = patch.object(app, "ALLOWED_HOSTS", {f"127.0.0.1:{cls.port}"})
        cls.origins = patch.object(app, "ALLOWED_ORIGINS", {f"http://127.0.0.1:{cls.port}"})
        cls.hosts.start()
        cls.origins.start()
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.hosts.stop()
        cls.origins.stop()

    def req(self, method, path, headers=None, body=None):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        c.request(method, path, body=body, headers=headers or {})
        r = c.getresponse()
        data = r.read()
        c.close()
        return r.status, data

    def test_same_origin_json_post_allowed(self):
        h = {"Content-Type": "application/json", "Origin": f"http://127.0.0.1:{self.port}"}
        self.assertEqual(self.req("POST", "/api/stop", h, "{}")[0], 200)
        self.assertEqual(self.req("GET", "/api/status")[0], 200)

    def test_cross_site_post_is_blocked(self):
        h = {"Content-Type": "application/json", "Origin": "https://evil.example"}
        self.assertEqual(self.req("POST", "/api/start", h, json.dumps({"pool_id": "auto", "worker": ADDR}))[0], 403)
        self.assertFalse(app.MINER.status()["running"])

    def test_simple_form_post_without_json_type_is_blocked(self):
        h = {"Content-Type": "text/plain"}
        self.assertEqual(self.req("POST", "/api/start", h, json.dumps({"pool_id": "auto", "worker": ADDR}))[0], 403)
        self.assertFalse(app.MINER.status()["running"])

    def test_dns_rebinding_host_is_blocked(self):
        self.assertEqual(self.req("GET", "/api/status", {"Host": "attacker.example"})[0], 403)


if __name__ == "__main__":
    unittest.main(verbosity=2)
