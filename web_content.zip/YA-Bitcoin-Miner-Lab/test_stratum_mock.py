"""Local-only Stratum V1 integration test. Never connects to a public pool."""
import json
import socket
import threading
import time
import unittest

import app


def recv_json_line(conn, buf=b""):
    while b"\n" not in buf:
        chunk = conn.recv(8192)
        if not chunk:
            raise ConnectionError("client disconnected")
        buf += chunk
    line, rest = buf.split(b"\n", 1)
    return json.loads(line.decode()), rest


def send_json_line(conn, obj):
    conn.sendall((json.dumps(obj, separators=(",", ":")) + "\n").encode())


class MockStratumServer:
    def __init__(self):
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(1)
        self.port = self.sock.getsockname()[1]
        self.submitted = threading.Event()
        self.error = None
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        try:
            conn, _ = self.sock.accept()
            with conn:
                conn.settimeout(4)
                msg, buf = recv_json_line(conn)
                if msg.get("method") != "mining.subscribe":
                    raise AssertionError("expected mining.subscribe")
                send_json_line(conn, {"id": 1, "result": [[], "aabbccdd", 4], "error": None})
                msg, buf = recv_json_line(conn, buf)
                if msg.get("method") != "mining.authorize":
                    raise AssertionError("expected mining.authorize")
                send_json_line(conn, {"id": 2, "result": True, "error": None})
                send_json_line(conn, {"id": None, "method": "mining.set_difficulty", "params": ["1e-100"]})
                send_json_line(conn, {"id": None, "method": "mining.notify", "params": [
                    "mock-job-1", "00112233" * 8, "01000000", "ffffffff", [],
                    "20000000", "1d00ffff", "65f00000", True
                ]})
                deadline = time.monotonic() + 4
                while time.monotonic() < deadline:
                    msg, buf = recv_json_line(conn, buf)
                    if msg.get("method") == "mining.submit":
                        self.submitted.set()
                        send_json_line(conn, {"id": msg["id"], "result": True, "error": None})
                        return
        except Exception as exc:
            self.error = exc
        finally:
            try:
                self.sock.close()
            except OSError:
                pass


class MockDiscoveryServer:
    def __init__(self):
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(1)
        self.port = self.sock.getsockname()[1]
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        try:
            conn, _ = self.sock.accept()
            with conn:
                conn.settimeout(2)
                msg, _ = recv_json_line(conn)
                if msg.get("id") != 91001 or msg.get("method") != "mining.subscribe":
                    raise AssertionError("expected discovery subscribe probe")
                send_json_line(conn, {"id": 91001, "result": [[], "aabbccdd", 4], "error": None})
        finally:
            self.sock.close()


class StratumIntegrationTests(unittest.TestCase):
    def test_pool_discovery_requires_stratum_v1_subscribe_response(self):
        server = MockDiscoveryServer()
        profile = {
            "id": "local-test", "name": "local mock", "host": "127.0.0.1", "port": server.port,
            "mode": "test", "account_required": False, "docs": "", "description": "local test",
        }
        result = app.probe_pool(profile, timeout=2)
        self.assertTrue(result["tcp_reachable"])
        self.assertTrue(result["stratum_v1"])
        self.assertTrue(result["reachable"])

    def test_subscribe_authorize_mine_submit_round_trip(self):
        server = MockStratumServer()
        miner = app.Miner()
        ok, message = miner.start({
            "pool_id": "custom", "host": "127.0.0.1", "port": server.port,
            "worker": "test.worker", "password": "x", "tls": False,
        })
        self.assertTrue(ok, message)
        self.assertTrue(server.submitted.wait(6), f"No share submitted; server error={server.error!r}; status={miner.status()!r}")
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline and miner.status()["accepted"] < 1:
            time.sleep(0.05)
        self.assertGreaterEqual(miner.status()["accepted"], 1, miner.status())
        miner.stop()
        if miner.thread:
            miner.thread.join(timeout=2)
        self.assertIsNone(server.error)


if __name__ == "__main__":
    unittest.main(verbosity=2)
