#!/usr/bin/env python3
"""YA Bitcoin Miner Lab — local Stratum V1 CPU miner / pool finder for Termux.

Educational and experimental: smartphone CPU mining is not economically viable.
Pool search uses a curated official-endpoint allow-list; no credentials are stored
on disk, and the web interface binds to loopback only.
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import random
import socket
import ssl
import struct
import subprocess
import threading
import time
import ctypes
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal, InvalidOperation, localcontext
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

APP_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 8765
ALLOWED_HOSTS = {f"127.0.0.1:{PORT}", f"localhost:{PORT}"}
ALLOWED_ORIGINS = {f"http://127.0.0.1:{PORT}", f"http://localhost:{PORT}"}
APP_VERSION = "0.3.0"

# Manually curated endpoints (operators' documentation and public probes). The
# automatic search only probes this allow-list; it never scrapes arbitrary hosts.
# Every entry is re-verified at run time from the phone itself (TCP + a valid
# mining.subscribe reply), so a stale entry simply shows up as unreachable.
# "fee" is the operator's advertised percentage of a found block, or None when unknown.
_BTC_ADDR = "btc-address"


def _solo(pid: str, name: str, host: str, port: int, fee: float | None, docs: str, description: str) -> dict[str, Any]:
    return {"id": pid, "name": name, "host": host, "port": port, "tls": False,
            "mode": "solo", "account_required": False, "user_kind": _BTC_ADDR,
            "fee": fee, "docs": docs, "description": description}


POOL_PROFILES: dict[str, dict[str, Any]] = {
    "ckpool-solo": _solo(
        "ckpool-solo", "Solo CKPool (بدون ثبت‌نام)", "stratum.ckpool.org", 3333, 2.0,
        "https://solo.ckpool.org/",
        "استخراج انفرادی؛ نام کاربر آدرس عمومی BTC است. پاداش فقط با پیدا شدن بلاک؛ کارمزد اعلامی ۲٪."),
    "ckpool-solo-alt": _solo(
        "ckpool-solo-alt", "Solo CKPool (میزبان جایگزین)", "solo.ckpool.org", 3333, 2.0,
        "https://solo.ckpool.org/",
        "همان سرویس Solo CKPool با نام میزبان قدیمی‌تر؛ برای وقتی که میزبان اصلی در دسترس نیست."),
    "ckpool-solo-eu": _solo(
        "ckpool-solo-eu", "Solo CKPool اروپا (تأخیر کمتر در ایران/ترکیه)", "eusolo.ckpool.org", 3333, 2.0,
        "https://solo.ckpool.org/",
        "سرور اروپایی Solo CKPool؛ معمولاً برای کاربران منطقه تأخیر کمتری دارد."),
    "public-pool": _solo(
        "public-pool", "Public Pool (انفرادی، بدون کارمزد)", "public-pool.io", 21496, 0.0,
        "https://web.public-pool.io/",
        "پروژهٔ متن‌باز استخراج انفرادی؛ نام کاربر آدرس عمومی BTC و کارمزد اعلامی ۰٪."),
    "braiins-solo": _solo(
        "braiins-solo", "Braiins Solo (آدرس BTC)", "solo.stratum.braiins.com", 3333, None,
        "https://academy.braiins.com/",
        "سرویس انفرادی Braiins؛ نام کاربر آدرس عمومی BTC. شرایط و کارمزد را در مستندات بررسی کن."),
    "ocean": _solo(
        "ocean", "OCEAN (آدرس BTC، استخری غیرحضانتی)", "mine.ocean.xyz", 3334, None,
        "https://ocean.xyz/docs",
        "استخر غیرحضانتی با پرداخت مستقیم به آدرس؛ حداقل آستانهٔ پرداخت را در مستندات بررسی کن."),
    "braiins-primary": {
        "id": "braiins-primary", "name": "Braiins Pool (اصلی؛ حساب لازم است)",
        "host": "stratum.braiins.com", "port": 3333, "tls": False,
        "mode": "pool", "account_required": True, "user_kind": "account-worker", "fee": None,
        "docs": "https://academy.braiins.com/braiins-pool/btc-mining-setup",
        "description": "استخراج استخری؛ نام کاربر طبق راهنمای سرویس به شکل account.worker است. حساب لازم است.",
    },
    "braiins-backup": {
        "id": "braiins-backup", "name": "Braiins Pool (پورت جایگزین؛ حساب لازم است)",
        "host": "stratum.braiins.com", "port": 443, "tls": False,
        "mode": "pool", "account_required": True, "user_kind": "account-worker", "fee": None,
        "docs": "https://academy.braiins.com/braiins-pool/btc-mining-setup",
        "description": "مسیر جایگزین رسمی با Stratum روی TCP؛ حساب Braiins لازم است. این پورت در این نسخه TLS نیست.",
    },
}


def _load_native_core():
    """Load optional OpenSSL-backed C scanner if the user built it in Termux."""
    path = APP_DIR / "miner_core.so"
    if not path.is_file():
        return None
    try:
        lib = ctypes.CDLL(str(path))
        fn = lib.ya_scan_nonce
        u8p = ctypes.POINTER(ctypes.c_ubyte)
        u32p = ctypes.POINTER(ctypes.c_uint32)
        fn.argtypes = [u8p, u8p, ctypes.c_uint32, ctypes.c_uint32, u32p, u32p, u8p]
        fn.restype = ctypes.c_int
        lib.ya_scan_nonce = fn
        try:
            lib.ya_core_version.restype = ctypes.c_int
            lib.core_revision = int(lib.ya_core_version())
        except AttributeError:
            lib.core_revision = 2  # scanner built from the v0.2 sources (works, but slower)
        return lib
    except Exception as exc:
        logging.warning("Native miner core could not be loaded: %s", exc)
        return None


NATIVE_CORE = _load_native_core()


def _bech32_polymod(values: list[int]) -> int:
    generators = (0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
    chk = 1
    for value in values:
        top = chk >> 25
        chk = ((chk & 0x1ffffff) << 5) ^ value
        for i, gen in enumerate(generators):
            if (top >> i) & 1:
                chk ^= gen
    return chk


def _bech32_hrp_expand(hrp: str) -> list[int]:
    return [ord(c) >> 5 for c in hrp] + [0] + [ord(c) & 31 for c in hrp]


def _convertbits(data: list[int], frombits: int, tobits: int, pad: bool) -> list[int] | None:
    acc = 0
    bits = 0
    out: list[int] = []
    maxv = (1 << tobits) - 1
    max_acc = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            return None
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            out.append((acc >> bits) & maxv)
    if pad:
        if bits:
            out.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        return None
    return out


def valid_btc_mainnet_address(address: str) -> bool:
    """Check a Bitcoin mainnet Base58Check or SegWit Bech32/Bech32m address."""
    address = address.strip()
    if not address or len(address) > 90:
        return False
    # Base58Check (P2PKH/P2SH)
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    if address[0] in "123" and all(c in alphabet for c in address):
        number = 0
        for char in address:
            number = number * 58 + alphabet.index(char)
        raw = number.to_bytes((number.bit_length() + 7) // 8, "big") if number else b""
        pad = len(address) - len(address.lstrip("1"))
        raw = b"\x00" * pad + raw
        if len(raw) == 25:
            payload, check = raw[:-4], raw[-4:]
            return payload[0] in (0x00, 0x05) and hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4] == check
    # SegWit addresses: BIP-173 and BIP-350
    if not (address.lower() == address or address.upper() == address):
        return False
    addr = address.lower()
    if not addr.startswith("bc1"):
        return False
    pos = addr.rfind("1")
    if pos < 1 or pos + 7 > len(addr):
        return False
    hrp = addr[:pos]
    if hrp != "bc":
        return False
    charset = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
    try:
        data = [charset.index(c) for c in addr[pos + 1:]]
    except ValueError:
        return False
    if len(data) < 7:
        return False
    polymod = _bech32_polymod(_bech32_hrp_expand(hrp) + data)
    payload5 = data[:-6]
    if not payload5:
        return False
    witness_version = payload5[0]
    if not 0 <= witness_version <= 16:
        return False
    if witness_version == 0 and polymod != 1:
        return False
    if witness_version != 0 and polymod != 0x2bc830a3:
        return False
    program = _convertbits(payload5[1:], 5, 8, False)
    if program is None or not 2 <= len(program) <= 40:
        return False
    if witness_version == 0 and len(program) not in (20, 32):
        return False
    if witness_version == 1 and len(program) != 32:
        return False
    return True


def probe_pool(profile: dict[str, Any], timeout: float = 3.5) -> dict[str, Any]:
    """Verify TCP and a minimally valid Stratum V1 subscribe response (no login/share)."""
    result = {"id": profile["id"], "name": profile["name"], "host": profile["host"],
              "port": profile["port"], "mode": profile["mode"],
              "account_required": profile["account_required"], "docs": profile["docs"],
              "description": profile["description"], "reachable": False,
              "fee": profile.get("fee"), "user_kind": profile.get("user_kind"),
              "tcp_reachable": False, "stratum_v1": False, "latency_ms": None,
              "detail": "هنوز بررسی نشده است."}
    started = time.monotonic()
    try:
        with socket.create_connection((profile["host"], profile["port"]), timeout=timeout) as conn:
            result["tcp_reachable"] = True
            conn.settimeout(timeout)
            hello = {"id": 91001, "method": "mining.subscribe", "params": [f"YA-PhoneMiner/{APP_VERSION}"]}
            conn.sendall((json.dumps(hello, separators=(",", ":")) + "\n").encode("utf-8"))
            buf = b""
            while len(buf) < 256_000:
                chunk = conn.recv(8192)
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    msg = json.loads(line.decode("utf-8", errors="strict"))
                    if msg.get("id") != 91001:
                        continue
                    err = msg.get("error")
                    sub = msg.get("result")
                    if err not in (None, False) or not isinstance(sub, list) or len(sub) < 3:
                        result["detail"] = "TCP برقرار شد، اما پاسخ subscribe ساختار معتبر Stratum V1 نداشت."
                        return result
                    ex1 = str(sub[1])
                    ex2_size = int(sub[2])
                    bytes.fromhex(ex1)
                    if len(ex1) > 64 or not 1 <= ex2_size <= 16:
                        result["detail"] = "پاسخ subscribe دریافت شد، اما فیلدهای extranonce معتبر نبودند."
                        return result
                    result["reachable"] = True
                    result["stratum_v1"] = True
                    result["latency_ms"] = round((time.monotonic() - started) * 1000, 1)
                    result["detail"] = "پاسخ mining.subscribe سازگار با Stratum V1 تأیید شد؛ authorize و پذیرش سهم هنوز آزمایش نشده‌اند."
                    return result
            result["detail"] = "TCP برقرار شد، اما endpoint در مهلت تعیین‌شده پاسخ معتبر mining.subscribe نداد."
    except Exception as exc:
        result["detail"] = f"اتصال یا آزمون Stratum ناموفق بود: {type(exc).__name__}"
    return result


def rank_pools(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Order usable (Stratum V1-verified) pools: no account first, then lowest advertised
    fee (unknown fees are assumed to be 2%), then lowest latency."""
    usable = [r for r in results if r.get("reachable") and r.get("stratum_v1")]

    def key(r: dict[str, Any]):
        fee = r.get("fee")
        return (bool(r.get("account_required")), 2.0 if fee is None else float(fee),
                r.get("latency_ms") if r.get("latency_ms") is not None else 1e9)
    return sorted(usable, key=key)


def discover_pools() -> dict[str, Any]:
    """Probe only curated endpoints, in parallel, from the user's own device and rank them."""
    keys = list(POOL_PROFILES)
    with ThreadPoolExecutor(max_workers=min(8, len(keys))) as executor:
        results = list(executor.map(lambda key: probe_pool(POOL_PROFILES[key]), keys))
    for r in results:  # keep ranking inputs available to the caller / UI
        prof = POOL_PROFILES.get(r["id"], {})
        r.setdefault("fee", prof.get("fee"))
        r.setdefault("user_kind", prof.get("user_kind"))
    ranked = rank_pools(results)
    free = [r for r in ranked if not r["account_required"]]
    selected = ranked[0] if ranked else None
    if free:
        text = (f"{len(free)} استخر بدون ثبت‌نام در دسترس است؛ بهترین انتخاب: {free[0]['name']}. "
                "اگر قطع شود، برنامه خودکار به گزینهٔ بعدی می‌رود. آدرس عمومی BTC لازم است.")
    elif selected:
        text = "فقط استخرهایی که حساب می‌خواهند در دسترس‌اند؛ برای آن‌ها حساب معتبر لازم است."
    else:
        text = "هیچ نقطهٔ انتهایی از فهرست تأییدشده از این اتصال قابل دسترسی نبود (شاید شبکه پورت‌های استخراج را بسته باشد)."
    return {"ok": True, "pools": results, "ranking": [r["id"] for r in ranked],
            "failover_ids": [r["id"] for r in free],
            "recommended_id": selected["id"] if selected else None, "recommendation": text}


DIFF1_TARGET = int("00000000ffff0000000000000000000000000000000000000000000000000000", 16)
MAX_TARGET = (1 << 256) - 1


def sha256d(data: bytes) -> bytes:
    """Bitcoin double-SHA-256; returns the raw digest bytes."""
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()


def le_u32_from_hex(value: str) -> bytes:
    value = value.strip()
    if len(value) != 8:
        raise ValueError("A 32-bit header field must contain exactly 8 hex digits")
    return struct.pack("<I", int(value, 16))


def parse_target(difficulty: float | str) -> int:
    try:
        d = Decimal(str(difficulty))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("Invalid pool difficulty") from exc
    if not d.is_finite() or d <= 0:
        raise ValueError("Pool difficulty must be greater than zero")
    with localcontext() as ctx:
        ctx.prec = 100
        target = int(Decimal(DIFF1_TARGET) / d)
    return min(MAX_TARGET, max(1, target))


def build_header_prefix(job: dict[str, Any], extranonce1: str, extranonce2_hex: str) -> bytes:
    """Build the 76 fixed bytes of a classic Stratum V1 Bitcoin header.

    The pool's Stratum V1 prevhash field is used as transmitted, as expected by
    common Bitcoin Stratum V1 pools. Some non-standard pool dialects differ.
    """
    coinbase_hex = job["coinb1"] + extranonce1 + extranonce2_hex + job["coinb2"]
    coinbase = bytes.fromhex(coinbase_hex)
    merkle_root = sha256d(coinbase)
    for branch_hex in job["merkle_branch"]:
        merkle_root = sha256d(merkle_root + bytes.fromhex(branch_hex))

    prevhash_stratum = bytes.fromhex(job["prevhash"])
    if len(prevhash_stratum) != 32:
        raise ValueError("Pool supplied an invalid prevhash length")
    # Bitcoin Stratum V1 sends the previous hash as eight 32-bit little-endian
    # words. Reverse bytes within each 4-byte word for the serialized header.
    prevhash = b"".join(prevhash_stratum[i:i + 4][::-1] for i in range(0, 32, 4))
    version = le_u32_from_hex(job["version"])
    ntime = le_u32_from_hex(job["ntime"])
    nbits = le_u32_from_hex(job["nbits"])
    prefix = version + prevhash + merkle_root + ntime + nbits
    if len(prefix) != 76:
        raise ValueError("Internal error: Bitcoin header prefix must be 76 bytes")
    return prefix


# ---------------------------------------------------------------------------
# Realistic expectations: network difficulty from the job's nbits, expected time
# to find a block, and a battery-temperature guard (needs the optional Termux:API).
# ---------------------------------------------------------------------------
BLOCK_SUBSIDY_BTC = 3.125  # subsidy since the April 2024 halving; transaction fees ignored
DEFAULT_AUTO_ORDER = ["public-pool", "ckpool-solo", "ckpool-solo-eu", "ckpool-solo-alt"]


def nbits_to_difficulty(nbits_hex: str) -> float | None:
    """Convert the compact 'nbits' field to the (floating point) network difficulty."""
    try:
        raw = int(nbits_hex, 16)
    except (TypeError, ValueError):
        return None
    exponent, mantissa = raw >> 24, raw & 0x007fffff
    if mantissa == 0 or exponent < 3:
        return None
    target = mantissa * (1 << (8 * (exponent - 3)))
    if target <= 0:
        return None
    return DIFF1_TARGET / target


def expected_outcome(hashrate: float, difficulty: float | None, fee_percent: float | None = 2.0) -> dict[str, Any] | None:
    """Honest solo-mining expectation: how long until a block, on average, at this hash rate."""
    if not difficulty or not hashrate or hashrate <= 0:
        return None
    seconds_per_block = difficulty * 2 ** 32 / hashrate
    blocks_per_day = 86400.0 / seconds_per_block
    fee = 2.0 if fee_percent is None else fee_percent
    return {
        "network_difficulty": difficulty,
        "network_hashrate_ehs": difficulty * 2 ** 32 / 600.0 / 1e18,
        "years_per_block": seconds_per_block / (365.25 * 86400.0),
        "chance_per_year": -math.expm1(-365.25 * 86400.0 / seconds_per_block),
        "btc_per_day": blocks_per_day * BLOCK_SUBSIDY_BTC * (1 - fee / 100.0),
    }


_TEMP_TOOL_MISSING = False


def parse_battery_status(text: str) -> float | None:
    """Parse `termux-battery-status` JSON and return the battery temperature in °C."""
    try:
        value = json.loads(text).get("temperature")
        temp = float(value)
    except (ValueError, TypeError, AttributeError):
        return None
    return temp if 0.0 < temp < 100.0 else None


def battery_temperature_c() -> float | None:
    """Battery temperature via the optional Termux:API (pkg install termux-api); None if unavailable."""
    global _TEMP_TOOL_MISSING
    if _TEMP_TOOL_MISSING:
        return None
    try:
        out = subprocess.run(["termux-battery-status"], capture_output=True, text=True, timeout=5, check=False)
    except FileNotFoundError:
        _TEMP_TOOL_MISSING = True
        return None
    except (subprocess.SubprocessError, OSError):
        return None
    return parse_battery_status(out.stdout) if out.returncode == 0 else None


def _clamp_int(value: Any, low: int, high: int, default: int) -> int:
    try:
        return max(low, min(high, int(value)))
    except (TypeError, ValueError):
        return default


def check_worker_name(profile: dict[str, Any] | None, worker: str) -> tuple[bool, str]:
    """Validate/normalise the pool user name. Returns (ok, worker-or-Persian error message)."""
    worker = worker.strip()
    kind = (profile or {}).get("user_kind")
    if kind == _BTC_ADDR:
        address, dot, suffix = worker.partition(".")
        if not valid_btc_mainnet_address(address):
            return False, "آدرس عمومی بیت‌کوین معتبر نیست؛ آدرس دریافت mainnet را بررسی کن. عبارت بازیابی یا کلید خصوصی را هرگز وارد نکن."
        if address.lower().startswith("bc1"):
            address = address.lower()
        worker = address + ("." + suffix if dot else ".YAphone")
    elif not worker:
        return False, "نام حساب و کارگر را طبق قالب استخر (username.worker) وارد کن."
    if len(worker) > 256:
        return False, "نام کارگر بیش از حد بلند است."
    return True, worker


def make_spec(profile: dict[str, Any], worker: str) -> dict[str, Any]:
    return {"id": profile["id"], "label": profile["name"], "host": profile["host"],
            "port": int(profile["port"]), "tls": bool(profile["tls"]), "worker": worker,
            "fee": profile.get("fee")}


class Miner:
    RETRY_BASE = 2  # seconds; first reconnect delay (doubles up to 30 s)

    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.send_lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.sock: socket.socket | None = None
        self.running = False
        self.connected = False
        self.authorized = False
        self.stage = "آماده"
        self.config: dict[str, Any] | None = None
        self.cur: dict[str, Any] | None = None  # pool spec currently in use
        self.pool_index = 0
        self.pools_total = 0
        self.start_time = 0.0
        self.hashes = 0
        self.hashrate = 0.0
        self.accepted = 0
        self.rejected = 0
        self.submitted = 0
        self.last_share = "—"
        self.last_error = ""
        self.logs: list[dict[str, str]] = []
        self.job: dict[str, Any] | None = None
        self.job_generation = 0
        self.target: int | None = None
        self.net_difficulty: float | None = None
        self.extranonce1 = ""
        self.extranonce2_size = 4
        self.auth_event = threading.Event()
        self.auth_ok = False
        self.reader_done = threading.Event()
        self.rpc_id = 10
        self.pending_submits: set[int] = set()
        self.threads = 1
        self.duty = 100
        self.max_temp = 0
        self.temp: float | None = None
        self.paused = False
        self.ex2_counter = 0
        self._rate_hashes = 0

    def start(self, config: dict[str, Any]) -> tuple[bool, str]:
        with self.lock:
            if self.running:
                return False, "استخراج از قبل فعال است."
        pool_id = str(config.get("pool_id", "custom"))
        worker = str(config.get("worker", "")).strip()
        password = str(config.get("password", "x"))
        auto = pool_id == "auto"
        pools: list[dict[str, Any]] = []
        if auto:
            ok, result = check_worker_name({"user_kind": _BTC_ADDR}, worker)
            if not ok:
                return False, result
            worker = result
        elif pool_id in POOL_PROFILES:
            profile = POOL_PROFILES[pool_id]
            ok, result = check_worker_name(profile, worker)
            if not ok:
                return False, result
            worker = result
            pools = [make_spec(profile, worker)]
        else:
            host = str(config.get("host", "")).strip()
            try:
                port = int(config.get("port", 0))
            except (TypeError, ValueError):
                return False, "شمارهٔ پورت درست نیست."
            if not host or any(ch.isspace() for ch in host) or "/" in host:
                return False, "نام میزبان استخر را درست وارد کن."
            if not 1 <= port <= 65535:
                return False, "پورت باید بین 1 تا 65535 باشد."
            if not worker:
                return False, "نام کارگر/حساب استخر را وارد کن."
            pools = [{"id": "custom", "label": "استخر سفارشی", "host": host, "port": port,
                      "tls": bool(config.get("tls", False)), "worker": worker, "fee": None}]
        if len(worker) > 256 or len(password) > 256:
            return False, "نام کارگر/حساب استخر یا رمز آن معتبر نیست."
        cpus = os.cpu_count() or 1
        default_threads = max(1, cpus - 1) if NATIVE_CORE else 1
        threads = _clamp_int(config.get("threads"), 1, cpus, default_threads) if NATIVE_CORE else 1
        duty = _clamp_int(config.get("duty"), 10, 100, 100)
        max_temp = _clamp_int(config.get("max_temp"), 0, 60, 42)
        if 0 < max_temp < 35:
            max_temp = 35
        cfg = {"pool_id": pool_id, "auto": auto, "worker": worker, "password": password, "pools": pools}
        self.stop_event = threading.Event()
        with self.lock:
            self.config = cfg
            self.cur = pools[0] if pools else None
            self.pool_index = 0
            self.pools_total = len(pools)
            self.running = True
            self.connected = False
            self.authorized = False
            self.stage = "در حال اتصال"
            self.start_time = time.monotonic()
            self.hashes = 0
            self.hashrate = 0.0
            self.accepted = self.rejected = self.submitted = 0
            self.last_share = "—"
            self.last_error = ""
            self.logs = []
            self.job = None
            self.job_generation = 0
            self.target = None
            self.net_difficulty = None
            self.pending_submits = set()
            self.threads = threads
            self.duty = duty
            self.max_temp = max_temp
            self.temp = None
            self.paused = False
            self.ex2_counter = random.randrange(0, 1 << 32)
        self.log("شروع کار؛ " + ("جست‌وجوی خودکار استخر…" if auto else "در حال اتصال به استخر انتخاب‌شده…"))
        if NATIVE_CORE:
            rev = getattr(NATIVE_CORE, "core_revision", 2)
            self.log(f"شتاب‌دهندهٔ بومی C/OpenSSL (نسخهٔ هسته {rev}) با {threads} رشته فعال است.")
            if rev < 3:
                self.log("miner_core.so از نسخهٔ قدیمی ساخته شده؛ برای سرعت بیشتر دوباره build_native.sh را اجرا کن.", "warning")
        else:
            self.log("شتاب‌دهندهٔ بومی فعال نیست؛ موتور Python (تک‌رشته‌ای و کند) استفاده می‌شود. برای افزایش سرعت build_native.sh را اجرا کن.", "warning")
        self.thread = threading.Thread(target=self._run, name="ya-miner", daemon=True)
        self.thread.start()
        return True, "درخواست شروع ثبت شد."

    def log(self, message: str, level: str = "info") -> None:
        stamp = time.strftime("%H:%M:%S")
        safe = str(message)[:240]
        with self.lock:
            self.logs.append({"time": stamp, "message": safe, "level": level})
            self.logs = self.logs[-35:]
            if level == "error":
                self.last_error = safe
        logging.info("%s %s", stamp, safe)

    def status(self) -> dict[str, Any]:
        with self.lock:
            elapsed = max(0.0, time.monotonic() - self.start_time) if self.start_time else 0.0
            cur = self.cur or {}
            return {
                "running": self.running,
                "connected": self.connected,
                "authorized": self.authorized,
                "stage": self.stage,
                "hashes": self.hashes,
                "hashrate": round(self.hashrate, 1),
                "accepted": self.accepted,
                "rejected": self.rejected,
                "submitted": self.submitted,
                "uptime": int(elapsed),
                "last_share": self.last_share,
                "last_error": self.last_error,
                "logs": list(reversed(self.logs[-12:])),
                "pool": cur.get("host", ""),
                "pool_id": cur.get("id", ""),
                "pool_label": cur.get("label", ""),
                "port": cur.get("port", ""),
                "tls": bool(cur.get("tls", False)),
                "pool_index": self.pool_index + 1 if self.pools_total else 0,
                "pools_total": self.pools_total,
                "native_acceleration": NATIVE_CORE is not None,
                "engine": (f"C/OpenSSL v{getattr(NATIVE_CORE, 'core_revision', 2)}" if NATIVE_CORE else "Python"),
                "threads": self.threads,
                "duty": self.duty,
                "max_temp": self.max_temp,
                "temp": self.temp,
                "paused": self.paused,
                "expected": expected_outcome(self.hashrate, self.net_difficulty, cur.get("fee")),
                "network_difficulty": self.net_difficulty,
                "version": APP_VERSION,
                "cpu_count": os.cpu_count() or 1,
                "max_threads": (os.cpu_count() or 1) if NATIVE_CORE else 1,
                "default_threads": max(1, (os.cpu_count() or 1) - 1) if NATIVE_CORE else 1,
            }

    def tune(self, config: dict[str, Any]) -> tuple[bool, str]:
        """Change duty cycle and temperature limit while running (thread count needs a restart)."""
        with self.lock:
            if "duty" in config:
                self.duty = _clamp_int(config.get("duty"), 10, 100, self.duty)
            if "max_temp" in config:
                limit = _clamp_int(config.get("max_temp"), 0, 60, self.max_temp)
                self.max_temp = 0 if limit == 0 else max(35, limit)
                if self.max_temp == 0:
                    self.paused = False
        return True, "تنظیمات اعمال شد."

    def stop(self) -> tuple[bool, str]:
        self.stop_event.set()
        with self.lock:
            s = self.sock
            was_running = self.running
            if was_running:
                self.stage = "در حال توقف"
        if s:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                s.close()
            except OSError:
                pass
        return True, "درخواست توقف ارسال شد." if was_running else "استخراج فعال نبود."

    def _send(self, s: socket.socket, payload: dict[str, Any]) -> None:
        raw = (json.dumps(payload, separators=(",", ":"), ensure_ascii=True) + "\n").encode("utf-8")
        with self.send_lock:
            s.sendall(raw)

    def _resolve_pools(self) -> list[dict[str, Any]]:
        """Pool list for this run. In automatic mode the phone itself probes and ranks the allow-list."""
        cfg = self.config or {}
        if not cfg.get("auto"):
            return list(cfg.get("pools") or [])
        self.log("جست‌وجوی خودکار: بررسی استخرهای فهرست‌شده از همین گوشی…")
        try:
            found = discover_pools()
            ids = list(found.get("failover_ids") or [])
        except Exception as exc:  # network oddities must never kill the miner thread
            self.log(f"جست‌وجوی خودکار کامل نشد: {exc}", "warning")
            ids = []
        if ids:
            self.log("استخرهای در دسترس به‌ترتیب اولویت: " + "، ".join(ids))
        else:
            ids = list(DEFAULT_AUTO_ORDER)
            self.log("هیچ استخری در جست‌وجو تأیید نشد؛ فهرست پیش‌فرض را یکی‌یکی امتحان می‌کنم.", "warning")
        return [make_spec(POOL_PROFILES[i], cfg["worker"]) for i in ids if i in POOL_PROFILES]

    def _run(self) -> None:
        delay = self.RETRY_BASE
        fails = 0
        auth_rejected: set[str] = set()
        pools = self._resolve_pools()
        if not pools and not self.stop_event.is_set():
            self.log("هیچ استخری برای اتصال وجود ندارد.", "error")
            self.stop_event.set()
        with self.lock:
            self.pools_total = len(pools)
        idx = 0
        while not self.stop_event.is_set():
            spec = pools[idx % len(pools)]
            with self.lock:
                self.cur = spec
                self.pool_index = idx % len(pools)
            s: socket.socket | None = None
            reader: threading.Thread | None = None
            self.auth_event.clear()
            self.reader_done.clear()
            self.auth_ok = False
            rotate = False
            try:
                self.log(f"اتصال به {spec['host']}:{spec['port']} …")
                raw = socket.create_connection((spec["host"], spec["port"]), timeout=12)
                raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                if spec.get("tls"):
                    context = ssl.create_default_context()
                    s = context.wrap_socket(raw, server_hostname=spec["host"])
                else:
                    s = raw
                s.settimeout(None)
                with self.lock:
                    self.sock = s
                    self.connected = True
                    self.authorized = False
                    self.stage = "اتصال برقرار شد؛ ثبت‌نام…"
                    self.job = None
                    self.target = None
                    self.pending_submits.clear()
                self._send(s, {"id": 1, "method": "mining.subscribe", "params": [f"YA-PhoneMiner/{APP_VERSION}"]})
                reader = threading.Thread(target=self._reader, args=(s,), name="ya-stratum-reader", daemon=True)
                reader.start()
                auth_deadline = time.monotonic() + 35
                while not self.stop_event.is_set() and not self.reader_done.is_set():
                    if self.auth_event.wait(0.2):
                        break
                    if time.monotonic() > auth_deadline:
                        raise TimeoutError("استخر در مهلت تعیین‌شده پاسخ ثبت‌نام نداد.")
                if self.stop_event.is_set():
                    break
                if self.reader_done.is_set() and not self.auth_event.is_set():
                    raise ConnectionError("اتصال استخر قبل از تأیید کارگر قطع شد.")
                if not self.auth_ok:
                    raise PermissionError("استخر ورود را رد کرد؛ آدرس دریافت یا مشخصات کارگر را بررسی کن.")
                delay = self.RETRY_BASE
                fails = 0
                with self.lock:
                    self.stage = "در انتظار کار استخراج"
                self.log("کارگر توسط استخر تأیید شد؛ در انتظار کار معتبر…")
                self._mine_loop(s)
                if not self.stop_event.is_set():
                    raise ConnectionError("اتصال به استخر قطع شد.")
            except PermissionError as exc:
                if self.stop_event.is_set():
                    break
                auth_rejected.add(spec["id"])
                untried = [p for p in pools if p["id"] not in auth_rejected]
                self.log(f"خطا: {exc}", "error")
                if untried and len(pools) > 1:
                    self.log("به استخر بعدی در فهرست می‌روم.", "warning")
                    rotate = True
                    delay = self.RETRY_BASE
                else:
                    # Do not hammer pools with an address/account they refuse.
                    self.stop_event.set()
            except Exception as exc:
                if not self.stop_event.is_set():
                    self.log(f"خطا: {exc}", "error")
                    fails += 1
                    if len(pools) > 1 and fails >= 2:
                        rotate = True
                        fails = 0
                        self.log("این استخر دوبار پشت‌سرهم ناموفق بود؛ جابه‌جایی به استخر بعدی.", "warning")
            finally:
                with self.lock:
                    if self.sock is s:
                        self.sock = None
                    self.connected = False
                    self.authorized = False
                    self.job = None
                if s:
                    try:
                        s.shutdown(socket.SHUT_RDWR)
                    except OSError:
                        pass
                    try:
                        s.close()
                    except OSError:
                        pass
                if reader and reader.is_alive() and reader is not threading.current_thread():
                    reader.join(timeout=0.5)
            if self.stop_event.is_set():
                break
            if rotate:
                idx += 1
            with self.lock:
                self.stage = f"اتصال مجدد تا {delay} ثانیهٔ دیگر"
            self.log(f"تلاش مجدد پس از {delay} ثانیه…", "warning")
            self.stop_event.wait(delay)
            delay = min(30, delay * 2)
        with self.lock:
            self.running = False
            self.connected = False
            self.authorized = False
            self.stage = "متوقف شد"
            self.hashrate = 0.0
            self.sock = None
        self.log("استخراج متوقف شد.")

    def _reader(self, s: socket.socket) -> None:
        buf = b""
        try:
            while not self.stop_event.is_set():
                chunk = s.recv(8192)
                if not chunk:
                    break
                buf += chunk
                if len(buf) > 2_000_000:
                    raise ValueError("دادهٔ دریافتی از استخر بیش از حد بزرگ بود.")
                while b"\n" in buf:
                    raw_line, buf = buf.split(b"\n", 1)
                    if not raw_line.strip():
                        continue
                    try:
                        msg = json.loads(raw_line.decode("utf-8", errors="strict"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        self.log("پیام نامعتبر از استخر دریافت شد.", "warning")
                        continue
                    self._handle_message(s, msg)
        except (OSError, ValueError) as exc:
            if not self.stop_event.is_set():
                self.log(f"دریافت از استخر قطع شد: {exc}", "warning")
        finally:
            self.reader_done.set()
            with self.lock:
                self.connected = False

    def _handle_message(self, s: socket.socket, msg: dict[str, Any]) -> None:
        mid = msg.get("id")
        method = msg.get("method")
        if mid == 1:
            result = msg.get("result")
            if not isinstance(result, list) or len(result) < 3:
                self.log("پاسخ mining.subscribe از استخر شناخته نشد.", "error")
                self.auth_ok = False
                self.auth_event.set()
                return
            try:
                extranonce1 = str(result[1])
                ex2_size = int(result[2])
                if len(bytes.fromhex(extranonce1)) > 32 or not 1 <= ex2_size <= 16:
                    raise ValueError("extranonce field out of range")
                self.extranonce1 = extranonce1
                self.extranonce2_size = ex2_size
                cfg = self.config or {}
                spec = self.cur or {}
                self._send(s, {"id": 2, "method": "mining.authorize", "params": [spec.get("worker", ""), cfg.get("password", "x")]})
                self.log("ثبت‌نام Stratum انجام شد؛ در حال تأیید حساب…")
            except Exception as exc:
                self.log(f"پاسخ ثبت‌نام نامعتبر است: {exc}", "error")
                self.auth_ok = False
                self.auth_event.set()
            return
        if mid == 2:
            ok = msg.get("result") is True and msg.get("error") in (None, False)
            self.auth_ok = ok
            with self.lock:
                self.authorized = ok
                self.stage = "مجاز؛ در انتظار کار" if ok else "رد شدن اطلاعات ورود"
            if ok:
                self.log("تأیید حساب موفق بود.")
            else:
                self.log(f"استخر ورود را رد کرد: {msg.get('error')}", "error")
            self.auth_event.set()
            return
        if mid is not None:
            with self.lock:
                if mid in self.pending_submits:
                    self.pending_submits.discard(mid)
                    if msg.get("result") is True and msg.get("error") in (None, False):
                        self.accepted += 1
                        self.last_share = time.strftime("%H:%M:%S") + " — پذیرفته شد"
                        self.log("یک سهم توسط استخر پذیرفته شد.")
                    else:
                        self.rejected += 1
                        err = msg.get("error") or "پاسخ نامعتبر"
                        self.last_share = time.strftime("%H:%M:%S") + " — رد شد"
                        self.log(f"استخر یک سهم را رد کرد: {err}", "warning")
            return
        if not method:
            return
        params = msg.get("params", [])
        if method == "mining.set_difficulty" and params:
            try:
                target = parse_target(params[0])
                with self.lock:
                    self.target = target
                self.log(f"درجهٔ سختی استخر تنظیم شد: {params[0]}")
            except Exception as exc:
                self.log(f"سختی دریافتی معتبر نیست: {exc}", "error")
        elif method == "mining.set_extranonce" and len(params) >= 2:
            try:
                ex1, sz = str(params[0]), int(params[1])
                bytes.fromhex(ex1)
                if not 1 <= sz <= 16:
                    raise ValueError("invalid extranonce2 size")
                with self.lock:
                    self.extranonce1 = ex1
                    self.extranonce2_size = sz
                    self.job_generation += 1
                    self.job = None
                self.log("استخر extranonce را تغییر داد؛ کار قبلی کنار گذاشته شد.")
            except Exception as exc:
                self.log(f"پیام extranonce نامعتبر بود: {exc}", "error")
        elif method == "mining.notify":
            try:
                if len(params) < 9:
                    raise ValueError("notify message has too few fields")
                new_job = {
                    "job_id": str(params[0]), "prevhash": str(params[1]),
                    "coinb1": str(params[2]), "coinb2": str(params[3]),
                    "merkle_branch": list(params[4]), "version": str(params[5]),
                    "nbits": str(params[6]), "ntime": str(params[7]),
                    "clean_jobs": bool(params[8]),
                }
                # Validate hex now to prevent spinning on malformed data.
                for key in ("prevhash", "coinb1", "coinb2", "version", "nbits", "ntime"):
                    bytes.fromhex(new_job[key])
                if len(new_job["prevhash"]) != 64:
                    raise ValueError("prevhash must be 32 bytes")
                if any(not isinstance(b, str) for b in new_job["merkle_branch"]):
                    raise ValueError("invalid merkle branch")
                for b in new_job["merkle_branch"]:
                    bytes.fromhex(b)
                net_diff = nbits_to_difficulty(new_job["nbits"])
                with self.lock:
                    self.job_generation += 1
                    new_job["generation"] = self.job_generation
                    self.job = new_job
                    if net_diff:
                        self.net_difficulty = net_diff
                    self.stage = "استخراج فعال"
                self.log(f"کار جدید دریافت شد: {new_job['job_id'][:32]}")
            except Exception as exc:
                self.log(f"کار ارسالی استخر نامعتبر است: {exc}", "error")
        elif method in ("client.show_message", "client.reconnect"):
            self.log(f"پیام استخر ({method}): {str(params)[:120]}", "warning")

    def _send_share(self, s: socket.socket, job: dict[str, Any], ex2_hex: str, nonce: int,
                    digest: bytes | None = None) -> None:
        with self.lock:
            mid = self.rpc_id
            self.rpc_id += 1
            self.pending_submits.add(mid)
            self.submitted += 1
            worker = (self.cur or {}).get("worker", "")
        try:
            self._send(s, {"id": mid, "method": "mining.submit", "params": [
                worker, job["job_id"], ex2_hex, job["ntime"], f"{nonce:08x}"
            ]})
            digest_hex = digest[::-1].hex() if digest else ""
            self.log(f"ارسال سهم به استخر{('؛ هش ' + digest_hex[:16] + '…') if digest_hex else ''}")
        except OSError as exc:
            with self.lock:
                self.pending_submits.discard(mid)
                self.submitted = max(0, self.submitted - 1)
            self.log(f"ارسال سهم انجام نشد: {exc}", "warning")

    def _scan_batch(self, prefix: bytes, target: int, start_nonce: int, count: int):
        """Scan a bounded nonce batch; use native C when available, Python otherwise."""
        if NATIVE_CORE:
            u8 = ctypes.c_ubyte
            u32 = ctypes.c_uint32
            prefix_buf = (u8 * 76).from_buffer_copy(prefix)
            target_buf = (u8 * 32).from_buffer_copy(target.to_bytes(32, "big"))
            done = u32(0)
            found_nonce = u32(0)
            digest_buf = (u8 * 32)()
            found = NATIVE_CORE.ya_scan_nonce(prefix_buf, target_buf, start_nonce,
                                              count, ctypes.byref(done),
                                              ctypes.byref(found_nonce), digest_buf)
            digest = bytes(digest_buf) if found else None
            return int(done.value), (int(found_nonce.value) if found else None), digest
        done = 0
        nonce = start_nonce
        for _ in range(count):
            digest = sha256d(prefix + struct.pack("<I", nonce))
            done += 1
            if int.from_bytes(digest, "little") <= target:
                return done, nonce, digest
            nonce = (nonce + 1) & 0xffffffff
        return done, None, None

    def _next_ex2(self, size: int) -> str:
        """Hand out a unique extranonce2 so that parallel workers never repeat each other's work."""
        with self.lock:
            value = self.ex2_counter
            self.ex2_counter += 1
        return (value % (1 << (8 * size))).to_bytes(size, "big").hex()

    def _worker(self, s: socket.socket, conn_done: threading.Event) -> None:
        """One mining thread. ctypes releases the GIL during the C scan, so N workers use N cores."""
        active_generation = -1
        job: dict[str, Any] | None = None
        prefix: bytes | None = None
        ex2 = ""
        nonce = 0
        scanned = 0
        batch_size = 131072 if NATIVE_CORE else 2048

        def alive() -> bool:
            return not (self.stop_event.is_set() or self.reader_done.is_set() or conn_done.is_set())

        while alive():
            if self.paused:
                conn_done.wait(0.5)
                continue
            with self.lock:
                cur_job = self.job
                target = self.target
                gen = self.job_generation
                ex1 = self.extranonce1
                ex2_size = self.extranonce2_size
                duty = self.duty
            if cur_job is None or target is None:
                conn_done.wait(0.2)
                continue
            if gen != active_generation:
                job = cur_job
                ex2 = self._next_ex2(ex2_size)
                try:
                    prefix = build_header_prefix(job, ex1, ex2)
                except Exception as exc:
                    self.log(f"ساخت هدر ناموفق بود: {exc}", "error")
                    prefix = None
                    conn_done.wait(0.5)
                    continue
                active_generation = gen
                nonce = random.randrange(0, 1 << 32)
                scanned = 0
            if prefix is None or job is None:
                conn_done.wait(0.1)
                continue

            count = min(batch_size, (1 << 32) - scanned)
            t0 = time.perf_counter()
            try:
                done, found_nonce, digest = self._scan_batch(prefix, target, nonce, count)
            except Exception as exc:
                self.log(f"خطا هنگام محاسبهٔ هش: {exc}", "error")
                conn_done.wait(0.25)
                continue
            if done <= 0:
                continue
            with self.lock:
                self.hashes += done
                latest_gen = self.job_generation
                self.stage = "استخراج فعال"
            if found_nonce is not None and digest is not None:
                # A new job may have arrived during the scan; never submit stale work.
                if latest_gen == active_generation and alive():
                    self._send_share(s, job, ex2, found_nonce, digest)
            nonce = (nonce + done) & 0xffffffff
            scanned += done
            if scanned >= (1 << 32):
                # Whole nonce space used for this coinbase; switch to a fresh extranonce2.
                ex2 = self._next_ex2(ex2_size)
                try:
                    prefix = build_header_prefix(job, ex1, ex2)
                    nonce = random.randrange(0, 1 << 32)
                    scanned = 0
                except Exception as exc:
                    self.log(f"تعویض extranonce ناموفق بود: {exc}", "error")
                    prefix = None
            if duty < 100:
                # Duty-cycle throttle: rest in proportion to the time just spent hashing.
                busy = time.perf_counter() - t0
                conn_done.wait(min(2.0, busy * (100 - duty) / duty))
            elif not NATIVE_CORE:
                time.sleep(0.001)  # keep the status UI responsive on the slow Python engine

    def _thermal_tick(self) -> None:
        temp = battery_temperature_c()
        with self.lock:
            self.temp = temp
            limit = self.max_temp
            paused = self.paused
        if temp is None or limit <= 0:
            return
        if not paused and temp >= limit:
            with self.lock:
                self.paused = True
            self.log(f"دمای باتری {temp:.1f}°C به حد {limit}°C رسید؛ استخراج موقتاً متوقف شد تا گوشی خنک شود.", "warning")
        elif paused and temp <= limit - 3:
            with self.lock:
                self.paused = False
            self.log(f"دمای باتری به {temp:.1f}°C کاهش یافت؛ استخراج ادامه پیدا کرد.")

    def _mine_loop(self, s: socket.socket) -> None:
        """Supervisor for one pool connection: starts the workers, measures the hash rate, guards temperature."""
        conn_done = threading.Event()
        with self.lock:
            n_threads = self.threads
            self.paused = False
            self._rate_hashes = self.hashes
        workers = [threading.Thread(target=self._worker, args=(s, conn_done), name=f"ya-worker-{i}", daemon=True)
                   for i in range(n_threads)]
        for w in workers:
            w.start()
        last_at = time.monotonic()
        next_thermal = 0.0
        try:
            while not self.stop_event.is_set() and not self.reader_done.is_set():
                if self.stop_event.wait(1.0):
                    break
                now = time.monotonic()
                with self.lock:
                    done = self.hashes - self._rate_hashes
                    elapsed = max(0.1, now - last_at)
                    self.hashrate = 0.0 if self.paused else max(0.0, done / elapsed)
                    self._rate_hashes = self.hashes
                last_at = now
                if now >= next_thermal:
                    next_thermal = now + 20.0
                    self._thermal_tick()
        finally:
            conn_done.set()
            for w in workers:
                w.join(timeout=3)
            with self.lock:
                self.hashrate = 0.0


MINER = Miner()


class Handler(BaseHTTPRequestHandler):
    server_version = f"YA-Bitcoin-Miner-Lab/{APP_VERSION}"

    def log_message(self, fmt: str, *args: Any) -> None:
        # Avoid echoing request bodies, which can include pool login fields.
        logging.info("HTTP %s - %s", self.address_string(), fmt % args)

    def _headers(self, status: int = 200, content_type: str = "application/json; charset=utf-8") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()

    def _json(self, value: Any, status: int = 200) -> None:
        raw = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self._headers(status)
        self.wfile.write(raw)

    def _request_allowed(self, post: bool = False) -> bool:
        """Block other web pages from driving the miner (CSRF) and DNS-rebinding attacks.

        The control API is bound to 127.0.0.1, but any website open in the phone's browser
        could still send requests to it. We therefore only accept our own Host and Origin,
        and require a JSON content type for POST (which browsers cannot send cross-site
        without a CORS preflight that this server never grants)."""
        host = (self.headers.get("Host") or "").strip().lower()
        if host not in ALLOWED_HOSTS:
            return False
        origin = self.headers.get("Origin")
        if origin is not None and origin.strip().lower() not in ALLOWED_ORIGINS:
            return False
        if post:
            ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            if ctype != "application/json":
                return False
        return True

    def do_GET(self) -> None:  # noqa: N802
        if not self._request_allowed():
            self._json({"ok": False, "error": "Forbidden"}, 403)
            return
        path = urlparse(self.path).path
        if path == "/api/status":
            self._json(MINER.status())
            return
        if path == "/api/discover":
            self._json(discover_pools())
            return
        if path == "/api/pools":
            public = []
            for profile in POOL_PROFILES.values():
                public.append({k: profile[k] for k in ("id", "name", "host", "port", "tls", "mode", "account_required", "user_kind", "fee", "docs", "description")})
            self._json({"ok": True, "pools": public})
            return
        if path in ("/", "/index.html"):
            html = (APP_DIR / "index.html").read_bytes()
            self._headers(200, "text/html; charset=utf-8")
            self.wfile.write(html)
            return
        if path == "/favicon.ico":
            self._headers(204, "image/x-icon")
            return
        self._json({"ok": False, "error": "Not found"}, 404)

    def do_POST(self) -> None:  # noqa: N802
        if not self._request_allowed(post=True):
            self._json({"ok": False, "message": "درخواست از مبدأ مجاز نیست."}, 403)
            return
        path = urlparse(self.path).path
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length > 16_384:
            self._json({"ok": False, "message": "درخواست بیش از حد بزرگ است."}, 413)
            return
        try:
            body = self.rfile.read(length) if length else b"{}"
            data = json.loads(body.decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError("request must be an object")
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            self._json({"ok": False, "message": "دادهٔ درخواست درست نیست."}, 400)
            return
        if path == "/api/start":
            ok, message = MINER.start(data)
            self._json({"ok": ok, "message": message}, 200 if ok else 409)
            return
        if path == "/api/tune":
            ok, message = MINER.tune(data)
            self._json({"ok": ok, "message": message})
            return
        if path == "/api/stop":
            ok, message = MINER.stop()
            self._json({"ok": ok, "message": message})
            return
        self._json({"ok": False, "error": "Not found"}, 404)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    httpd.daemon_threads = True
    print(f"\nYA Bitcoin Miner Lab v{APP_VERSION}")
    print(f"موتور محاسبات: {'C/OpenSSL' if NATIVE_CORE else 'Python fallback'}")
    print(f"رابط محلی را در مرورگر همین گوشی باز کن: http://{HOST}:{PORT}")
    print("برای بستن برنامه، در همین Termux کلید Ctrl+C را بزن.")
    try:
        httpd.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        print("\nدر حال توقف…")
    finally:
        MINER.stop()
        httpd.server_close()


if __name__ == "__main__":
    main()
