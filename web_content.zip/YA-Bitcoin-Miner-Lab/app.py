#!/usr/bin/env python3
"""YA Bitcoin Miner Lab — local Stratum V1 CPU miner / pool finder for Termux.

Educational and experimental: smartphone CPU mining is not economically viable.
Pool search uses a curated official-endpoint allow-list; no credentials are stored
on disk, and the web interface binds to loopback only.
"""
from __future__ import annotations

import hashlib
import json
import logging
import random
import socket
import ssl
import struct
import threading
import time
import ctypes
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal, InvalidOperation, localcontext
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

APP_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 8765
APP_VERSION = "0.2.0"

# Manually curated endpoints from each operator's official documentation. The
# automatic search only probes this allow-list; it never scrapes arbitrary hosts.
POOL_PROFILES: dict[str, dict[str, Any]] = {
    "ckpool-solo": {
        "id": "ckpool-solo", "name": "Solo CKPool (بدون ثبت‌نام)",
        "host": "stratum.ckpool.org", "port": 3333, "tls": False,
        "mode": "solo", "account_required": False, "user_kind": "btc-address",
        "docs": "https://solo.ckpool.org/",
        "description": "استخراج انفرادی؛ نام کاربر باید آدرس عمومی دریافت BTC باشد. پرداخت فقط در صورت پیدا شدن بلاک؛ کارمزد اعلامی ۲٪ از پاداش بلاک.",
    },
    "braiins-primary": {
        "id": "braiins-primary", "name": "Braiins Pool (اصلی؛ حساب لازم است)",
        "host": "stratum.braiins.com", "port": 3333, "tls": False,
        "mode": "pool", "account_required": True, "user_kind": "account-worker",
        "docs": "https://academy.braiins.com/braiins-pool/btc-mining-setup",
        "description": "استخراج استخری؛ نام کاربر طبق راهنمای سرویس به شکل account.worker است. حساب لازم است.",
    },
    "braiins-backup": {
        "id": "braiins-backup", "name": "Braiins Pool (پورت جایگزین؛ حساب لازم است)",
        "host": "stratum.braiins.com", "port": 443, "tls": False,
        "mode": "pool", "account_required": True, "user_kind": "account-worker",
        "docs": "https://academy.braiins.com/braiins-pool/btc-mining-setup",
        "description": "مسیر جایگزین رسمی با Stratum روی TCP؛ حساب Braiins لازم است. این پورت در این نسخه TLS نیست.",
    },
}


def _load_native_core():
    """Load optional OpenSSL-backed C scanner if the user built it in Termux."""
    path = APP_DIR / "miner_core.so"
    if not path.is_file():
        return None
    try:
        lib = ctypes.CDLL(str(path))
        fn = lib.ya_scan_nonce
        u8p = ctypes.POINTER(ctypes.c_ubyte)
        u32p = ctypes.POINTER(ctypes.c_uint32)
        fn.argtypes = [u8p, u8p, ctypes.c_uint32, ctypes.c_uint32, u32p, u32p, u8p]
        fn.restype = ctypes.c_int
        lib.ya_scan_nonce = fn
        return lib
    except Exception as exc:
        logging.warning("Native miner core could not be loaded: %s", exc)
        return None


NATIVE_CORE = _load_native_core()


def _bech32_polymod(values: list[int]) -> int:
    generators = (0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
    chk = 1
    for value in values:
        top = chk >> 25
        chk = ((chk & 0x1ffffff) << 5) ^ value
        for i, gen in enumerate(generators):
            if (top >> i) & 1:
                chk ^= gen
    return chk


def _bech32_hrp_expand(hrp: str) -> list[int]:
    return [ord(c) >> 5 for c in hrp] + [0] + [ord(c) & 31 for c in hrp]


def _convertbits(data: list[int], frombits: int, tobits: int, pad: bool) -> list[int] | None:
    acc = 0
    bits = 0
    out: list[int] = []
    maxv = (1 << tobits) - 1
    max_acc = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            return None
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            out.append((acc >> bits) & maxv)
    if pad:
        if bits:
            out.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        return None
    return out


def valid_btc_mainnet_address(address: str) -> bool:
    """Check a Bitcoin mainnet Base58Check or SegWit Bech32/Bech32m address."""
    address = address.strip()
    if not address or len(address) > 90:
        return False
    # Base58Check (P2PKH/P2SH)
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    if address[0] in "123" and all(c in alphabet for c in address):
        number = 0
        for char in address:
            number = number * 58 + alphabet.index(char)
        raw = number.to_bytes((number.bit_length() + 7) // 8, "big") if number else b""
        pad = len(address) - len(address.lstrip("1"))
        raw = b"\x00" * pad + raw
        if len(raw) == 25:
            payload, check = raw[:-4], raw[-4:]
            return payload[0] in (0x00, 0x05) and hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4] == check
    # SegWit addresses: BIP-173 and BIP-350
    if not (address.lower() == address or address.upper() == address):
        return False
    addr = address.lower()
    if not addr.startswith("bc1"):
        return False
    pos = addr.rfind("1")
    if pos < 1 or pos + 7 > len(addr):
        return False
    hrp = addr[:pos]
    if hrp != "bc":
        return False
    charset = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
    try:
        data = [charset.index(c) for c in addr[pos + 1:]]
    except ValueError:
        return False
    if len(data) < 7:
        return False
    polymod = _bech32_polymod(_bech32_hrp_expand(hrp) + data)
    payload5 = data[:-6]
    if not payload5:
        return False
    witness_version = payload5[0]
    if not 0 <= witness_version <= 16:
        return False
    if witness_version == 0 and polymod != 1:
        return False
    if witness_version != 0 and polymod != 0x2bc830a3:
        return False
    program = _convertbits(payload5[1:], 5, 8, False)
    if program is None or not 2 <= len(program) <= 40:
        return False
    if witness_version == 0 and len(program) not in (20, 32):
        return False
    if witness_version == 1 and len(program) != 32:
        return False
    return True


def probe_pool(profile: dict[str, Any], timeout: float = 3.5) -> dict[str, Any]:
    """Verify TCP and a minimally valid Stratum V1 subscribe response (no login/share)."""
    result = {"id": profile["id"], "name": profile["name"], "host": profile["host"],
              "port": profile["port"], "mode": profile["mode"],
              "account_required": profile["account_required"], "docs": profile["docs"],
              "description": profile["description"], "reachable": False,
              "tcp_reachable": False, "stratum_v1": False, "latency_ms": None,
              "detail": "هنوز بررسی نشده است."}
    started = time.monotonic()
    try:
        with socket.create_connection((profile["host"], profile["port"]), timeout=timeout) as conn:
            result["tcp_reachable"] = True
            conn.settimeout(timeout)
            hello = {"id": 91001, "method": "mining.subscribe", "params": [f"YA-PhoneMiner/{APP_VERSION}"]}
            conn.sendall((json.dumps(hello, separators=(",", ":")) + "\n").encode("utf-8"))
            buf = b""
            while len(buf) < 256_000:
                chunk = conn.recv(8192)
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    msg = json.loads(line.decode("utf-8", errors="strict"))
                    if msg.get("id") != 91001:
                        continue
                    err = msg.get("error")
                    sub = msg.get("result")
                    if err not in (None, False) or not isinstance(sub, list) or len(sub) < 3:
                        result["detail"] = "TCP برقرار شد، اما پاسخ subscribe ساختار معتبر Stratum V1 نداشت."
                        return result
                    ex1 = str(sub[1])
                    ex2_size = int(sub[2])
                    bytes.fromhex(ex1)
                    if len(ex1) > 64 or not 1 <= ex2_size <= 16:
                        result["detail"] = "پاسخ subscribe دریافت شد، اما فیلدهای extranonce معتبر نبودند."
                        return result
                    result["reachable"] = True
                    result["stratum_v1"] = True
                    result["latency_ms"] = round((time.monotonic() - started) * 1000, 1)
                    result["detail"] = "پاسخ mining.subscribe سازگار با Stratum V1 تأیید شد؛ authorize و پذیرش سهم هنوز آزمایش نشده‌اند."
                    return result
            result["detail"] = "TCP برقرار شد، اما endpoint در مهلت تعیین‌شده پاسخ معتبر mining.subscribe نداد."
    except Exception as exc:
        result["detail"] = f"اتصال یا آزمون Stratum ناموفق بود: {type(exc).__name__}"
    return result


def discover_pools() -> dict[str, Any]:
    """Probe only curated official endpoints, in parallel, from the user's device."""
    keys = ["ckpool-solo", "braiins-primary", "braiins-backup"]
    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(lambda key: probe_pool(POOL_PROFILES[key]), keys))
    ck = next((r for r in results if r["id"] == "ckpool-solo" and r["reachable"]), None)
    selected = ck
    # Braiins is an alternative only when the user already has an account.
    if selected is None:
        selected = next((r for r in results if r["id"] == "braiins-primary" and r["reachable"]), None)
        if selected is None:
            selected = next((r for r in results if r["id"] == "braiins-backup" and r["reachable"]), None)
    return {"ok": True, "pools": results, "recommended_id": selected["id"] if selected else None,
            "recommendation": ("CKPool بدون ثبت‌نام در دسترس است؛ آدرس عمومی BTC لازم است." if ck else
             ("فقط Braiins در دسترس است؛ برای آن حساب معتبر لازم است." if selected else
              "هیچ نقطهٔ انتهایی از فهرست تأییدشده از این اتصال قابل دسترسی نبود."))}


DIFF1_TARGET = int("00000000ffff0000000000000000000000000000000000000000000000000000", 16)
MAX_TARGET = (1 << 256) - 1


def sha256d(data: bytes) -> bytes:
    """Bitcoin double-SHA-256; returns the raw digest bytes."""
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()


def le_u32_from_hex(value: str) -> bytes:
    value = value.strip()
    if len(value) != 8:
        raise ValueError("A 32-bit header field must contain exactly 8 hex digits")
    return struct.pack("<I", int(value, 16))


def parse_target(difficulty: float | str) -> int:
    try:
        d = Decimal(str(difficulty))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("Invalid pool difficulty") from exc
    if not d.is_finite() or d <= 0:
        raise ValueError("Pool difficulty must be greater than zero")
    with localcontext() as ctx:
        ctx.prec = 100
        target = int(Decimal(DIFF1_TARGET) / d)
    return min(MAX_TARGET, max(1, target))


def build_header_prefix(job: dict[str, Any], extranonce1: str, extranonce2_hex: str) -> bytes:
    """Build the 76 fixed bytes of a classic Stratum V1 Bitcoin header.

    The pool's Stratum V1 prevhash field is used as transmitted, as expected by
    common Bitcoin Stratum V1 pools. Some non-standard pool dialects differ.
    """
    coinbase_hex = job["coinb1"] + extranonce1 + extranonce2_hex + job["coinb2"]
    coinbase = bytes.fromhex(coinbase_hex)
    merkle_root = sha256d(coinbase)
    for branch_hex in job["merkle_branch"]:
        merkle_root = sha256d(merkle_root + bytes.fromhex(branch_hex))

    prevhash_stratum = bytes.fromhex(job["prevhash"])
    if len(prevhash_stratum) != 32:
        raise ValueError("Pool supplied an invalid prevhash length")
    # Bitcoin Stratum V1 sends the previous hash as eight 32-bit little-endian
    # words. Reverse bytes within each 4-byte word for the serialized header.
    prevhash = b"".join(prevhash_stratum[i:i + 4][::-1] for i in range(0, 32, 4))
    version = le_u32_from_hex(job["version"])
    ntime = le_u32_from_hex(job["ntime"])
    nbits = le_u32_from_hex(job["nbits"])
    prefix = version + prevhash + merkle_root + ntime + nbits
    if len(prefix) != 76:
        raise ValueError("Internal error: Bitcoin header prefix must be 76 bytes")
    return prefix


class Miner:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.send_lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.sock: socket.socket | None = None
        self.running = False
        self.connected = False
        self.authorized = False
        self.stage = "آماده"
        self.config: dict[str, Any] | None = None
        self.start_time = 0.0
        self.hashes = 0
        self.hashrate = 0.0
        self.accepted = 0
        self.rejected = 0
        self.submitted = 0
        self.last_share = "—"
        self.last_error = ""
        self.logs: list[dict[str, str]] = []
        self.job: dict[str, Any] | None = None
        self.job_generation = 0
        self.target: int | None = None
        self.extranonce1 = ""
        self.extranonce2_size = 4
        self.auth_event = threading.Event()
        self.auth_ok = False
        self.reader_done = threading.Event()
        self.rpc_id = 10
        self.pending_submits: set[int] = set()

    def log(self, message: str, level: str = "info") -> None:
        stamp = time.strftime("%H:%M:%S")
        safe = str(message)[:240]
        with self.lock:
            self.logs.append({"time": stamp, "message": safe, "level": level})
            self.logs = self.logs[-35:]
            if level == "error":
                self.last_error = safe
        logging.info("%s %s", stamp, safe)

    def start(self, config: dict[str, Any]) -> tuple[bool, str]:
        with self.lock:
            if self.running:
                return False, "استخراج از قبل فعال است."
        pool_id = str(config.get("pool_id", "custom"))
        worker = str(config.get("worker", "")).strip()
        password = str(config.get("password", "x"))
        if pool_id in POOL_PROFILES:
            profile = POOL_PROFILES[pool_id]
            host, port = profile["host"], int(profile["port"])
            tls = bool(profile["tls"])
            if pool_id == "ckpool-solo":
                address, dot, suffix = worker.partition(".")
                if not valid_btc_mainnet_address(address):
                    return False, "آدرس عمومی بیت‌کوین معتبر نیست؛ آدرس دریافت mainnet را بررسی کن. عبارت بازیابی یا کلید خصوصی را هرگز وارد نکن."
                if address.lower().startswith("bc1"):
                    address = address.lower()
                worker = address + ("." + suffix if dot else ".YAphone")
                if len(worker) > 256:
                    return False, "نام کارگر بیش از حد بلند است."
            elif not worker:
                return False, "برای Braiins نام حساب و کارگر را طبق فرمت username.worker وارد کن."
        else:
            host = str(config.get("host", "")).strip()
            try:
                port = int(config.get("port", 0))
            except (TypeError, ValueError):
                return False, "شمارهٔ پورت درست نیست."
            tls = bool(config.get("tls", False))
            if not host or any(ch.isspace() for ch in host) or "/" in host:
                return False, "نام میزبان استخر را درست وارد کن."
            if not 1 <= port <= 65535:
                return False, "پورت باید بین 1 تا 65535 باشد."
            if not worker:
                return False, "نام کارگر/حساب استخر را وارد کن."
        if len(worker) > 256 or len(password) > 256:
            return False, "نام کارگر/حساب استخر یا رمز آن معتبر نیست."
        cfg = {"pool_id": pool_id, "host": host, "port": port, "worker": worker,
               "password": password, "tls": tls}
        self.stop_event = threading.Event()
        with self.lock:
            self.config = cfg
            self.running = True
            self.connected = False
            self.authorized = False
            self.stage = "در حال اتصال"
            self.start_time = time.monotonic()
            self.hashes = 0
            self.hashrate = 0.0
            self.accepted = self.rejected = self.submitted = 0
            self.last_share = "—"
            self.last_error = ""
            self._last_rate_hashes = 0
            self._last_rate_at = self.start_time
            self.logs = []
            self.job = None
            self.job_generation = 0
            self.target = None
            self.pending_submits = set()
        self.log("شروع کار؛ در حال اتصال به استخر انتخاب‌شده…")
        if NATIVE_CORE:
            self.log("شتاب‌دهندهٔ بومی C/OpenSSL فعال است.")
        else:
            self.log("شتاب‌دهندهٔ بومی فعال نیست؛ موتور Python استفاده می‌شود. برای افزایش سرعت build_native.sh را اجرا کن.", "warning")
        self.thread = threading.Thread(target=self._run, name="ya-miner", daemon=True)
        self.thread.start()
        return True, "درخواست شروع ثبت شد."

    def stop(self) -> tuple[bool, str]:
        self.stop_event.set()
        with self.lock:
            s = self.sock
            was_running = self.running
            if was_running:
                self.stage = "در حال توقف"
        if s:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                s.close()
            except OSError:
                pass
        return True, "درخواست توقف ارسال شد." if was_running else "استخراج فعال نبود."

    def status(self) -> dict[str, Any]:
        with self.lock:
            elapsed = max(0.0, time.monotonic() - self.start_time) if self.start_time else 0.0
            return {
                "running": self.running,
                "connected": self.connected,
                "authorized": self.authorized,
                "stage": self.stage,
                "hashes": self.hashes,
                "hashrate": round(self.hashrate, 1),
                "accepted": self.accepted,
                "rejected": self.rejected,
                "submitted": self.submitted,
                "uptime": int(elapsed),
                "last_share": self.last_share,
                "last_error": self.last_error,
                "logs": list(reversed(self.logs[-12:])),
                "pool": (self.config or {}).get("host", ""),
                "pool_id": (self.config or {}).get("pool_id", ""),
                "pool_label": POOL_PROFILES.get((self.config or {}).get("pool_id", ""), {}).get("name", "استخر سفارشی"),
                "port": (self.config or {}).get("port", ""),
                "tls": bool((self.config or {}).get("tls", False)),
                "native_acceleration": NATIVE_CORE is not None,
                "engine": "C/OpenSSL" if NATIVE_CORE else "Python",
            }

    def _send(self, s: socket.socket, payload: dict[str, Any]) -> None:
        raw = (json.dumps(payload, separators=(",", ":"), ensure_ascii=True) + "\n").encode("utf-8")
        with self.send_lock:
            s.sendall(raw)

    def _run(self) -> None:
        delay = 2
        while not self.stop_event.is_set():
            s: socket.socket | None = None
            reader: threading.Thread | None = None
            self.auth_event.clear()
            self.reader_done.clear()
            self.auth_ok = False
            try:
                cfg = self.config or {}
                self.log(f"اتصال به {cfg.get('host')}:{cfg.get('port')} …")
                raw = socket.create_connection((cfg["host"], cfg["port"]), timeout=12)
                raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                if cfg.get("tls"):
                    context = ssl.create_default_context()
                    s = context.wrap_socket(raw, server_hostname=cfg["host"])
                else:
                    s = raw
                s.settimeout(None)
                with self.lock:
                    self.sock = s
                    self.connected = True
                    self.authorized = False
                    self.stage = "اتصال برقرار شد؛ ثبت‌نام…"
                    self.job = None
                    self.target = None
                    self.pending_submits.clear()
                self._send(s, {"id": 1, "method": "mining.subscribe", "params": ["YA-PhoneMiner/0.1"]})
                reader = threading.Thread(target=self._reader, args=(s,), name="ya-stratum-reader", daemon=True)
                reader.start()
                auth_deadline = time.monotonic() + 35
                while not self.stop_event.is_set() and not self.reader_done.is_set():
                    if self.auth_event.wait(0.2):
                        break
                    if time.monotonic() > auth_deadline:
                        raise TimeoutError("استخر در مهلت تعیین‌شده پاسخ ثبت‌نام نداد.")
                if self.stop_event.is_set():
                    break
                if self.reader_done.is_set():
                    raise ConnectionError("اتصال استخر قبل از تأیید کارگر قطع شد.")
                if not self.auth_ok:
                    # Do not hammer an endpoint with a rejected account/address.
                    self.stop_event.set()
                    raise PermissionError("استخر ورود را رد کرد؛ آدرس دریافت یا مشخصات کارگر را بررسی کن و دوباره شروع کن.")
                delay = 2
                with self.lock:
                    self.stage = "در انتظار کار استخراج"
                self.log("کارگر توسط استخر تأیید شد؛ در انتظار کار معتبر…")
                self._mine_loop(s)
                if not self.stop_event.is_set():
                    raise ConnectionError("اتصال به استخر قطع شد.")
            except Exception as exc:
                if not self.stop_event.is_set():
                    self.log(f"خطا: {exc}", "error")
            finally:
                with self.lock:
                    if self.sock is s:
                        self.sock = None
                    self.connected = False
                    self.authorized = False
                    self.job = None
                if s:
                    try:
                        s.shutdown(socket.SHUT_RDWR)
                    except OSError:
                        pass
                    try:
                        s.close()
                    except OSError:
                        pass
                if reader and reader.is_alive() and reader is not threading.current_thread():
                    reader.join(timeout=0.5)
            if self.stop_event.is_set():
                break
            with self.lock:
                self.stage = f"اتصال مجدد تا {delay} ثانیهٔ دیگر"
            self.log(f"تلاش مجدد پس از {delay} ثانیه…", "warning")
            self.stop_event.wait(delay)
            delay = min(30, delay * 2)
        with self.lock:
            self.running = False
            self.connected = False
            self.authorized = False
            self.stage = "متوقف شد"
            self.hashrate = 0.0
            self.sock = None
        self.log("استخراج متوقف شد.")

    def _reader(self, s: socket.socket) -> None:
        buf = b""
        try:
            while not self.stop_event.is_set():
                chunk = s.recv(8192)
                if not chunk:
                    break
                buf += chunk
                if len(buf) > 2_000_000:
                    raise ValueError("دادهٔ دریافتی از استخر بیش از حد بزرگ بود.")
                while b"\n" in buf:
                    raw_line, buf = buf.split(b"\n", 1)
                    if not raw_line.strip():
                        continue
                    try:
                        msg = json.loads(raw_line.decode("utf-8", errors="strict"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        self.log("پیام نامعتبر از استخر دریافت شد.", "warning")
                        continue
                    self._handle_message(s, msg)
        except (OSError, ValueError) as exc:
            if not self.stop_event.is_set():
                self.log(f"دریافت از استخر قطع شد: {exc}", "warning")
        finally:
            self.reader_done.set()
            with self.lock:
                self.connected = False

    def _handle_message(self, s: socket.socket, msg: dict[str, Any]) -> None:
        mid = msg.get("id")
        method = msg.get("method")
        if mid == 1:
            result = msg.get("result")
            if not isinstance(result, list) or len(result) < 3:
                self.log("پاسخ mining.subscribe از استخر شناخته نشد.", "error")
                self.auth_ok = False
                self.auth_event.set()
                return
            try:
                extranonce1 = str(result[1])
                ex2_size = int(result[2])
                if len(bytes.fromhex(extranonce1)) > 32 or not 1 <= ex2_size <= 16:
                    raise ValueError("extranonce field out of range")
                self.extranonce1 = extranonce1
                self.extranonce2_size = ex2_size
                cfg = self.config or {}
                self._send(s, {"id": 2, "method": "mining.authorize", "params": [cfg["worker"], cfg["password"]]})
                self.log("ثبت‌نام Stratum انجام شد؛ در حال تأیید حساب…")
            except Exception as exc:
                self.log(f"پاسخ ثبت‌نام نامعتبر است: {exc}", "error")
                self.auth_ok = False
                self.auth_event.set()
            return
        if mid == 2:
            ok = msg.get("result") is True and msg.get("error") in (None, False)
            self.auth_ok = ok
            with self.lock:
                self.authorized = ok
                self.stage = "مجاز؛ در انتظار کار" if ok else "رد شدن اطلاعات ورود"
            if ok:
                self.log("تأیید حساب موفق بود.")
            else:
                self.log(f"استخر ورود را رد کرد: {msg.get('error')}", "error")
            self.auth_event.set()
            return
        if mid is not None:
            with self.lock:
                if mid in self.pending_submits:
                    self.pending_submits.discard(mid)
                    if msg.get("result") is True and msg.get("error") in (None, False):
                        self.accepted += 1
                        self.last_share = time.strftime("%H:%M:%S") + " — پذیرفته شد"
                        self.log("یک سهم توسط استخر پذیرفته شد.")
                    else:
                        self.rejected += 1
                        err = msg.get("error") or "پاسخ نامعتبر"
                        self.last_share = time.strftime("%H:%M:%S") + " — رد شد"
                        self.log(f"استخر یک سهم را رد کرد: {err}", "warning")
            return
        if not method:
            return
        params = msg.get("params", [])
        if method == "mining.set_difficulty" and params:
            try:
                target = parse_target(params[0])
                with self.lock:
                    self.target = target
                self.log(f"درجهٔ سختی استخر تنظیم شد: {params[0]}")
            except Exception as exc:
                self.log(f"سختی دریافتی معتبر نیست: {exc}", "error")
        elif method == "mining.set_extranonce" and len(params) >= 2:
            try:
                ex1, sz = str(params[0]), int(params[1])
                bytes.fromhex(ex1)
                if not 1 <= sz <= 16:
                    raise ValueError("invalid extranonce2 size")
                with self.lock:
                    self.extranonce1 = ex1
                    self.extranonce2_size = sz
                    self.job_generation += 1
                    self.job = None
                self.log("استخر extranonce را تغییر داد؛ کار قبلی کنار گذاشته شد.")
            except Exception as exc:
                self.log(f"پیام extranonce نامعتبر بود: {exc}", "error")
        elif method == "mining.notify":
            try:
                if len(params) < 9:
                    raise ValueError("notify message has too few fields")
                new_job = {
                    "job_id": str(params[0]), "prevhash": str(params[1]),
                    "coinb1": str(params[2]), "coinb2": str(params[3]),
                    "merkle_branch": list(params[4]), "version": str(params[5]),
                    "nbits": str(params[6]), "ntime": str(params[7]),
                    "clean_jobs": bool(params[8]),
                }
                # Validate hex now to prevent spinning on malformed data.
                for key in ("prevhash", "coinb1", "coinb2", "version", "nbits", "ntime"):
                    bytes.fromhex(new_job[key])
                if len(new_job["prevhash"]) != 64:
                    raise ValueError("prevhash must be 32 bytes")
                if any(not isinstance(b, str) for b in new_job["merkle_branch"]):
                    raise ValueError("invalid merkle branch")
                for b in new_job["merkle_branch"]:
                    bytes.fromhex(b)
                with self.lock:
                    self.job_generation += 1
                    new_job["generation"] = self.job_generation
                    self.job = new_job
                    self.stage = "استخراج فعال"
                self.log(f"کار جدید دریافت شد: {new_job['job_id'][:32]}")
            except Exception as exc:
                self.log(f"کار ارسالی استخر نامعتبر است: {exc}", "error")
        elif method in ("client.show_message", "client.reconnect"):
            self.log(f"پیام استخر ({method}): {str(params)[:120]}", "warning")

    def _send_share(self, s: socket.socket, job: dict[str, Any], ex2_hex: str, nonce: int) -> None:
        with self.lock:
            mid = self.rpc_id
            self.rpc_id += 1
            self.pending_submits.add(mid)
            self.submitted += 1
        try:
            self._send(s, {"id": mid, "method": "mining.submit", "params": [
                (self.config or {}).get("worker", ""), job["job_id"], ex2_hex,
                job["ntime"], f"{nonce:08x}"
            ]})
            digest_hex = getattr(self, "_last_digest_hex", "")
            self.log(f"ارسال سهم به استخر{('؛ هش ' + digest_hex[:16] + '…') if digest_hex else ''}")
        except OSError as exc:
            with self.lock:
                self.pending_submits.discard(mid)
                self.submitted = max(0, self.submitted - 1)
            self.log(f"ارسال سهم انجام نشد: {exc}", "warning")

    def _scan_batch(self, prefix: bytes, target: int, start_nonce: int, count: int):
        """Scan a bounded nonce batch; use native C when available, Python otherwise."""
        if NATIVE_CORE:
            u8 = ctypes.c_ubyte
            u32 = ctypes.c_uint32
            prefix_buf = (u8 * 76).from_buffer_copy(prefix)
            target_buf = (u8 * 32).from_buffer_copy(target.to_bytes(32, "big"))
            done = u32(0)
            found_nonce = u32(0)
            digest_buf = (u8 * 32)()
            found = NATIVE_CORE.ya_scan_nonce(prefix_buf, target_buf, start_nonce,
                                              count, ctypes.byref(done),
                                              ctypes.byref(found_nonce), digest_buf)
            digest = bytes(digest_buf) if found else None
            return int(done.value), (int(found_nonce.value) if found else None), digest
        done = 0
        nonce = start_nonce
        for _ in range(count):
            digest = sha256d(prefix + struct.pack("<I", nonce))
            done += 1
            if int.from_bytes(digest, "little") <= target:
                return done, nonce, digest
            nonce = (nonce + 1) & 0xffffffff
        return done, None, None

    def _mine_loop(self, s: socket.socket) -> None:
        active_generation = -1
        local_hashes = 0
        extranonce_counter = random.randrange(0, 1 << 32)
        nonce = random.randrange(0, 1 << 32)
        scanned_nonce_space = 0
        prefix: bytes | None = None
        ex2 = ""
        last_no_job_log = 0.0
        batch_size = 65536 if NATIVE_CORE else 2048

        while not self.stop_event.is_set() and not self.reader_done.is_set():
            with self.lock:
                job = dict(self.job) if self.job else None
                target = self.target
                gen = self.job_generation
                connected = self.connected
                ex1 = self.extranonce1
                ex2_size = self.extranonce2_size
            if not connected:
                return
            if not job or target is None:
                now = time.monotonic()
                if now - last_no_job_log > 15:
                    self.log("در انتظار کار و سختی از استخر؛ هنوز هش انجام نمی‌شود.")
                    last_no_job_log = now
                self.stop_event.wait(0.2)
                continue
            if gen != active_generation:
                active_generation = gen
                ex2 = (extranonce_counter % (1 << (8 * ex2_size))).to_bytes(ex2_size, "big").hex()
                extranonce_counter += 1
                try:
                    prefix = build_header_prefix(job, ex1, ex2)
                except Exception as exc:
                    self.log(f"ساخت هدر ناموفق بود: {exc}", "error")
                    self.stop_event.wait(0.5)
                    active_generation = -1
                    continue
                nonce = random.randrange(0, 1 << 32)
                scanned_nonce_space = 0
                self.log("محاسبات SHA-256d واقعی آغاز شد؛ منتظر سهم معتبر هستیم.")
            if prefix is None:
                self.stop_event.wait(0.1)
                continue

            # Bounded batches keep stop responsive and discard work after new jobs arrive.
            count = min(batch_size, (1 << 32) - scanned_nonce_space)
            try:
                done, found_nonce, digest = self._scan_batch(prefix, target, nonce, count)
            except Exception as exc:
                self.log(f"خطا هنگام محاسبهٔ هش: {exc}", "error")
                self.stop_event.wait(0.25)
                continue
            if done <= 0:
                continue
            local_hashes += done
            scanned_nonce_space += done
            with self.lock:
                self.hashes += done
                now = time.monotonic()
                last_at = getattr(self, "_last_rate_at", now)
                last_count = getattr(self, "_last_rate_hashes", self.hashes - done)
                if now - last_at >= 1.0:
                    self.hashrate = max(0.0, (self.hashes - last_count) / max(0.1, now - last_at))
                    self._last_rate_hashes = self.hashes
                    self._last_rate_at = now
                self.stage = "استخراج فعال"
                latest_gen = self.job_generation
            if found_nonce is not None and digest is not None:
                # A new job may arrive while a native batch is scanning; do not submit stale work.
                if latest_gen == active_generation and not self.stop_event.is_set():
                    self._last_digest_hex = digest[::-1].hex()
                    self._send_share(s, job, ex2, found_nonce)
            nonce = (nonce + done) & 0xffffffff
            if local_hashes and local_hashes % 500000 < batch_size:
                self.log(f"محاسبات انجام‌شده در این اتصال: {local_hashes:,} هش")
            if scanned_nonce_space >= (1 << 32):
                # All 2^32 nonce values used with this extranonce; change the coinbase.
                extranonce_counter += 1
                ex2 = (extranonce_counter % (1 << (8 * ex2_size))).to_bytes(ex2_size, "big").hex()
                try:
                    prefix = build_header_prefix(job, ex1, ex2)
                    nonce = 0
                    scanned_nonce_space = 0
                except Exception as exc:
                    self.log(f"تعویض extranonce ناموفق بود: {exc}", "error")
                    prefix = None
            # Tiny yield avoids starving the local status UI; the native scanner does the work in C.
            time.sleep(0.001)
        with self.lock:
            self.hashrate = 0.0


MINER = Miner()


class Handler(BaseHTTPRequestHandler):
    server_version = f"YA-Bitcoin-Miner-Lab/{APP_VERSION}"

    def log_message(self, fmt: str, *args: Any) -> None:
        # Avoid echoing request bodies, which can include pool login fields.
        logging.info("HTTP %s - %s", self.address_string(), fmt % args)

    def _headers(self, status: int = 200, content_type: str = "application/json; charset=utf-8") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()

    def _json(self, value: Any, status: int = 200) -> None:
        raw = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self._headers(status)
        self.wfile.write(raw)

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/api/status":
            self._json(MINER.status())
            return
        if path == "/api/discover":
            self._json(discover_pools())
            return
        if path == "/api/pools":
            public = []
            for profile in POOL_PROFILES.values():
                public.append({k: profile[k] for k in ("id", "name", "host", "port", "tls", "mode", "account_required", "user_kind", "docs", "description")})
            self._json({"ok": True, "pools": public})
            return
        if path in ("/", "/index.html"):
            html = (APP_DIR / "index.html").read_bytes()
            self._headers(200, "text/html; charset=utf-8")
            self.wfile.write(html)
            return
        if path == "/favicon.ico":
            self._headers(204, "image/x-icon")
            return
        self._json({"ok": False, "error": "Not found"}, 404)

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length > 16_384:
            self._json({"ok": False, "message": "درخواست بیش از حد بزرگ است."}, 413)
            return
        try:
            body = self.rfile.read(length) if length else b"{}"
            data = json.loads(body.decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError("request must be an object")
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            self._json({"ok": False, "message": "دادهٔ درخواست درست نیست."}, 400)
            return
        if path == "/api/start":
            ok, message = MINER.start(data)
            self._json({"ok": ok, "message": message}, 200 if ok else 409)
            return
        if path == "/api/stop":
            ok, message = MINER.stop()
            self._json({"ok": ok, "message": message})
            return
        self._json({"ok": False, "error": "Not found"}, 404)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    httpd.daemon_threads = True
    print(f"\nYA Bitcoin Miner Lab v{APP_VERSION}")
    print(f"موتور محاسبات: {'C/OpenSSL' if NATIVE_CORE else 'Python fallback'}")
    print(f"رابط محلی را در مرورگر همین گوشی باز کن: http://{HOST}:{PORT}")
    print("برای بستن برنامه، در همین Termux کلید Ctrl+C را بزن.")
    try:
        httpd.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        print("\nدر حال توقف…")
    finally:
        MINER.stop()
        httpd.server_close()


if __name__ == "__main__":
    main()
