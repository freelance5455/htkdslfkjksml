/**
 * THE MORNING HUB – update API for the mobile app (v6)
 * Lets the app change Payment, Status, Menu and Settings in your Google Sheet.
 * Paste this whole file into your Apps Script project (Extensions > Apps Script),
 * set your own PIN below, then Deploy > Manage deployments > pencil > New version.
 */
const MH_SHEET_ID = '1T3F0fXzBpR3YHN-ljkntYAnamMRSC5-NJcmT37DJZqU';
const MH_PIN = 'CHANGE-ME-1234';           // <-- choose a PIN; type the same in the app

const MH_STATUS = ['New', 'Preparing', 'Out for delivery', 'Delivered', 'Cancelled'];
const MH_PAY = ['Pending', 'Paid'];

// SETUP (3 steps):
//  1) Paste this file as a NEW file in Extensions > Apps Script, keep or change MH_PIN, Save.
//  2) Select the function  mhAuthorize  in the top bar, press Run, then Review permissions > Allow.
//  3) Deploy > Manage deployments > pencil > Version: New version > Deploy.  (Execute as: Me, Who has access: Anyone)
// NOTE: only ONE doPost may exist in the whole project. If you already had your own doPost, delete the line below
// and instead add this as the FIRST line inside your doPost:
//   if (e.postData && String(e.postData.contents).indexOf('"pin"') >= 0) return mhHandle_(e);
function doPost(e) { return mhHandle_(e); }

// Run this once from the editor so Google asks you to allow access to the sheet.
function mhAuthorize() {
  const ss = SpreadsheetApp.openById(MH_SHEET_ID);
  Logger.log('OK - connected to: ' + ss.getName());
}

// Writes Status / Payment for a list of {id,status,pay}, then re-reads the sheet to confirm it really saved.
function mhApplyOrders_(ss, list) {
  const sh = ss.getSheetByName('Orders');
  const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(h => String(h).trim().toLowerCase());
  const cId = head.indexOf('order id') >= 0 ? head.indexOf('order id') : head.findIndex(h => h.indexOf('order') >= 0);
  const cSt = head.indexOf('status') >= 0 ? head.indexOf('status') : head.findIndex(h => h.indexOf('status') >= 0 && h.indexOf('payment') < 0);
  const cPay = head.indexOf('payment') >= 0 ? head.indexOf('payment') : head.findIndex(h => h.indexOf('payment') >= 0 && h.indexOf('mode') < 0);
  if (cId < 0 || cSt < 0 || cPay < 0) throw new Error('Orders columns not found (need Order ID, Status, Payment)');
  const last = sh.getLastRow();
  const ids = last > 1 ? sh.getRange(2, cId + 1, last - 1, 1).getValues() : [];
  const rowOf = {};
  ids.forEach((r, i) => { rowOf[String(r[0]).trim()] = i + 2; });
  const missing = [], want = [];
  let changed = 0;
  (list || []).forEach(o => {
    const row = rowOf[String(o.id).trim()];
    if (!row) { missing.push(o.id); return; }
    const stCell = sh.getRange(row, cSt + 1), payCell = sh.getRange(row, cPay + 1);
    if (MH_STATUS.indexOf(o.status) >= 0) { if (String(stCell.getValue()).trim() !== o.status) { stCell.setValue(o.status); changed++; } }
    if (MH_PAY.indexOf(o.pay) >= 0) { if (String(payCell.getValue()).trim() !== o.pay) { payCell.setValue(o.pay); changed++; } }
    want.push({ id: o.id, row: row, status: o.status, pay: o.pay });
  });
  SpreadsheetApp.flush();
  const bad = [];
  want.forEach(w => {
    const st = String(sh.getRange(w.row, cSt + 1).getValue()).trim();
    const pay = String(sh.getRange(w.row, cPay + 1).getValue()).trim();
    if ((MH_STATUS.indexOf(w.status) >= 0 && st !== w.status) || (MH_PAY.indexOf(w.pay) >= 0 && pay !== w.pay)) bad.push(w.id);
  });
  if (bad.length) throw new Error('Sheet did not keep Status/Payment for: ' + bad.join(', ') + ' (is the column a formula?)');
  return { changed: changed, missing: missing };
}

function mhHandle_(e) {
  const lock = LockService.getScriptLock();
  let out;
  try {
    lock.waitLock(20000);
    const req = JSON.parse(e.postData.contents);
    if (String(req.pin) !== String(MH_PIN)) throw new Error('Wrong PIN');
    const ss = SpreadsheetApp.openById(MH_SHEET_ID);

    if (req.a === 'ping') {
      out = { ok: true, version: 6,
              orders: Math.max(ss.getSheetByName('Orders').getLastRow() - 1, 0),
              menu: Math.max(ss.getSheetByName('Menu').getLastRow() - 1, 0) };

    } else if (req.a === 'orders') {            // batch: [{id, status, pay}, ...]
      const r = mhApplyOrders_(ss, req.list);
      out = { ok: true, changed: r.changed, missing: r.missing };

    } else if (req.a === 'read') {              // raw display values (exact text, no type guessing)
      const sh = ss.getSheetByName(req.sheet || 'Orders');
      out = { ok: true, values: sh.getDataRange().getDisplayValues() };

    } else if (req.a === 'orderedit') {         // edit any fields of one order
      const sh = ss.getSheetByName('Orders');
      const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(h => String(h).trim().toLowerCase());
      const find = function () {
        for (let a = 0; a < arguments.length; a++) { const i = head.indexOf(arguments[a]); if (i >= 0) return i; }
        for (let a = 0; a < arguments.length; a++) { const i = head.findIndex(h => h.indexOf(arguments[a]) >= 0); if (i >= 0) return i; }
        return -1;
      };
      const cId = find('order id');
      if (cId < 0) throw new Error('Orders column "Order ID" not found');
      const last = sh.getLastRow();
      const ids = last > 1 ? sh.getRange(2, cId + 1, last - 1, 1).getValues() : [];
      let row = -1;
      ids.forEach((r, i) => { if (String(r[0]).trim() === String(req.id).trim()) row = i + 2; });
      if (row < 0) throw new Error('Order ' + req.id + ' not found in sheet');
      const col = { name: find('name'), phone: find('phone', 'whatsapp'), wing: find('wing'), flat: find('flat'),
                    items: find('items', 'item'), plates: find('plates'), amount: find('amount'),
                    mode: find('payment mode'), note: find('note'), date: find('delivery date') };
      const f = req.fields || {};
      Object.keys(col).forEach(k => {
        if (col[k] < 0 || f[k] === undefined || f[k] === null) return;
        const cell = sh.getRange(row, col[k] + 1);
        const v = String(f[k]).trim();
        if (k === 'plates' || k === 'amount') cell.setValue(Number(v) || 0);
        else if (k === 'date') { const m = v.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) cell.setValue(new Date(+m[1], +m[2] - 1, +m[3])); }
        else if ((k === 'flat' || k === 'phone') && /^[1-9]\d*$/.test(v)) cell.setValue(Number(v));   // keep numbers numeric like the form does
        else cell.setValue(v);
      });
      SpreadsheetApp.flush();
      const r = mhApplyOrders_(ss, [{ id: req.id, status: f.status, pay: f.pay }]);
      out = { ok: true, changed: r.changed };

    } else if (req.a === 'order') {
      const r = mhApplyOrders_(ss, [req]);
      if (r.missing.length) throw new Error('Order ' + req.id + ' not found in sheet');
      out = { ok: true, changed: r.changed };

    } else if (req.a === 'card') {              // thank-you card sent: mark the order and every other order of the same flat
      const sh = ss.getSheetByName('Orders');
      const vals = sh.getDataRange().getValues();
      const head = vals[0].map(h => String(h).trim().toLowerCase());
      const cI = head.indexOf('order id'), cW = head.indexOf('wing'), cF = head.indexOf('flat'), cT = head.indexOf('thank-you card');
      if (cI < 0 || cT < 0) throw new Error('Orders columns "Order ID" / "Thank-you card" not found');
      const me = vals.find((r, i) => i > 0 && String(r[cI]).trim() === String(req.id).trim());
      if (!me) throw new Error('Order ' + req.id + ' not found in sheet');
      let n = 0;
      for (let i = 1; i < vals.length; i++) {
        const same = String(vals[i][cI]).trim() === String(req.id).trim() ||
          (String(vals[i][cW]).trim() === String(me[cW]).trim() && String(vals[i][cF]).trim() === String(me[cF]).trim() && String(vals[i][cT]).trim() === 'Needed');
        if (same && String(vals[i][cT]).trim() !== 'Sent') { sh.getRange(i + 1, cT + 1).setValue('Sent'); n++; }
      }
      const fl = ss.getSheetByName('Flats');
      if (fl && fl.getLastRow() > 1) {
        const fv = fl.getDataRange().getValues(), fh = fv[0].map(h => String(h).trim().toLowerCase());
        const a = fh.indexOf('society'), b = fh.indexOf('wing'), c = fh.indexOf('flat'), d = fh.indexOf('thank-you card');
        if (a >= 0 && b >= 0 && c >= 0 && d >= 0) for (let i = 1; i < fv.length; i++) {
          if (String(fv[i][a]).trim() + ' - ' + String(fv[i][b]).trim() === String(me[cW]).trim() && String(fv[i][c]).trim() === String(me[cF]).trim()) fl.getRange(i + 1, d + 1).setValue('Sent');
        }
      }
      SpreadsheetApp.flush();
      out = { ok: true, changed: n };

    } else if (req.a === 'menu') {
      const sh = ss.getSheetByName('Menu');
      const last = Math.max(sh.getLastRow(), 2);
      sh.getRange(2, 1, last - 1, 6).clearContent();
      const rows = (req.menu || []).map(m => [m.item, Number(m.price) || 0, m.avail === 'No' ? 'No' : 'Yes', m.desc || '', m.photo || '', m.prep || '']);
      if (rows.length) sh.getRange(2, 1, rows.length, 6).setValues(rows);
      out = { ok: true, rows: rows.length };

    } else if (req.a === 'setting') {
      const sh = ss.getSheetByName('Settings');
      const keys = sh.getRange(1, 1, sh.getLastRow(), 1).getValues();
      let row = -1;
      for (let i = 0; i < keys.length; i++) if (String(keys[i][0]).trim() === String(req.key).trim()) { row = i + 1; break; }
      if (row < 0) throw new Error('Setting not found: ' + req.key);
      const cell = sh.getRange(row, 2);
      if (cell.getDisplayValue() !== String(req.value)) cell.setValue(req.value);
      out = { ok: true };

    } else {
      throw new Error('Unknown action');
    }
  } catch (err) {
    out = { ok: false, error: String(err.message || err) };
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}
