/**
 * THE MORNING HUB – update API for the mobile app (v6)
 * Lets the app change Payment, Status, Menu and Settings in your Google Sheet.
 * Paste this whole file into your Apps Script project (Extensions > Apps Script),
 * set your own PIN below, then Deploy > Manage deployments > pencil > New version.
 */
const MH_SHEET_ID = '1w4KIunEDDUuZs-RkvDAY0gbH6SPu3lTEarGQsTSPGa0';
const MH_PIN = 'CHANGE-ME-1234';           // <-- choose a PIN; type the same in the app

const MH_STATUS = ['New', 'Preparing', 'Out for delivery', 'Delivered', 'Cancelled'];
const MH_PAY = ['Pending', 'Paid'];

function doPost(e) { return mhHandle_(e); }   // if you already have doPost, call mhHandle_(e) from it when the body has "pin"

// Writes Status / Payment for a list of {id,status,pay}, then re-reads the sheet to confirm it really saved.
function mhApplyOrders_(ss, list) {
  const sh = ss.getSheetByName('Orders');
  const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(h => String(h).trim().toLowerCase());
  const cId = head.indexOf('order id'), cSt = head.indexOf('status'), cPay = head.indexOf('payment');
  if (cId < 0 || cSt < 0 || cPay < 0) throw new Error('Orders columns not found (need Order ID, Status, Payment)');
  const last = sh.getLastRow();
  const ids = last > 1 ? sh.getRange(2, cId + 1, last - 1, 1).getValues() : [];
  const rowOf = {};
  ids.forEach((r, i) => { rowOf[String(r[0]).trim()] = i + 2; });
  const missing = [], want = [];
  let changed = 0;
  (list || []).forEach(o => {
    const row = rowOf[String(o.id).trim()];
    if (!row) { missing.push(o.id); return; }
    const stCell = sh.getRange(row, cSt + 1), payCell = sh.getRange(row, cPay + 1);
    if (MH_STATUS.indexOf(o.status) >= 0) { if (String(stCell.getValue()).trim() !== o.status) { stCell.setValue(o.status); changed++; } }
    if (MH_PAY.indexOf(o.pay) >= 0) { if (String(payCell.getValue()).trim() !== o.pay) { payCell.setValue(o.pay); changed++; } }
    want.push({ id: o.id, row: row, status: o.status, pay: o.pay });
  });
  SpreadsheetApp.flush();
  const bad = [];
  want.forEach(w => {
    const st = String(sh.getRange(w.row, cSt + 1).getValue()).trim();
    const pay = String(sh.getRange(w.row, cPay + 1).getValue()).trim();
    if ((MH_STATUS.indexOf(w.status) >= 0 && st !== w.status) || (MH_PAY.indexOf(w.pay) >= 0 && pay !== w.pay)) bad.push(w.id);
  });
  if (bad.length) throw new Error('Sheet did not keep Status/Payment for: ' + bad.join(', ') + ' (is the column a formula?)');
  return { changed: changed, missing: missing };
}

// Marks the Thank-you card status on the Flats sheet for the flat of the given Orders row (best effort).
function mhSetFlatCard_(ss, ordersSh, row, ohead, value) {
  try {
    const fl = ss.getSheetByName('Flats');
    if (!fl) return;
    const cW = ohead.indexOf('wing'), cF = ohead.indexOf('flat');
    if (cW < 0 || cF < 0) return;
    const wing = String(ordersSh.getRange(row, cW + 1).getDisplayValue()).trim();
    const flat = String(ordersSh.getRange(row, cF + 1).getDisplayValue()).trim();
    const parts = wing.split(' - ');
    const soc = parts.length > 1 ? parts[0].trim() : '';
    const wn = parts.length > 1 ? parts.slice(1).join(' - ').trim() : wing;
    const data = fl.getDataRange().getDisplayValues();
    const h = data[0].map(x => String(x).trim().toLowerCase());
    const cS = h.indexOf('society'), cWg = h.indexOf('wing'), cFl = h.indexOf('flat'), cC = h.indexOf('thank-you card');
    if (cWg < 0 || cFl < 0 || cC < 0) return;
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][cFl]).trim() === flat && String(data[i][cWg]).trim() === wn && (!soc || cS < 0 || String(data[i][cS]).trim() === soc)) {
        fl.getRange(i + 1, cC + 1).setValue(value);
        return;
      }
    }
  } catch (err) { /* Flats sheet is optional */ }
}

// 'yyyy-mm-dd' -> Date for the Menu tab's "Menu date" column; blank stays blank.
function mhMenuDate_(v) {
  const m = String(v || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : '';
}

function mhOrderCount_(ss) {
  const sh = ss.getSheetByName('Orders');
  const last = sh.getLastRow();
  if (last < 2) return 0;
  return sh.getRange(2, 2, last - 1, 1).getValues().filter(r => String(r[0]).trim() !== '').length;
}

function mhHandle_(e) {
  const lock = LockService.getScriptLock();
  let out;
  try {
    lock.waitLock(20000);
    const req = JSON.parse(e.postData.contents);
    if (String(req.pin) !== String(MH_PIN)) throw new Error('Wrong PIN');
    const ss = SpreadsheetApp.openById(MH_SHEET_ID);

    if (req.a === 'ping') {
      const mrows = ss.getSheetByName('Menu').getRange(2, 1, Math.max(ss.getSheetByName('Menu').getLastRow() - 1, 1), 1).getValues();
      out = { ok: true, version: 6,
              orders: mhOrderCount_(ss),
              menu: mrows.filter(r => String(r[0]).trim() !== '').length };

    } else if (req.a === 'orders') {            // batch: [{id, status, pay}, ...]
      const r = mhApplyOrders_(ss, req.list);
      out = { ok: true, changed: r.changed, missing: r.missing };

    } else if (req.a === 'read') {              // raw display values (exact text, no type guessing)
      const sh = ss.getSheetByName(req.sheet || 'Orders');
      out = { ok: true, values: sh.getDataRange().getDisplayValues() };

    } else if (req.a === 'orderedit') {         // edit any fields of one order
      const sh = ss.getSheetByName('Orders');
      const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(h => String(h).trim().toLowerCase());
      const find = function () {
        for (let a = 0; a < arguments.length; a++) { const i = head.indexOf(arguments[a]); if (i >= 0) return i; }
        for (let a = 0; a < arguments.length; a++) { const i = head.findIndex(h => h.indexOf(arguments[a]) >= 0); if (i >= 0) return i; }
        return -1;
      };
      const cId = find('order id');
      if (cId < 0) throw new Error('Orders column "Order ID" not found');
      const last = sh.getLastRow();
      const ids = last > 1 ? sh.getRange(2, cId + 1, last - 1, 1).getValues() : [];
      let row = -1;
      ids.forEach((r, i) => { if (String(r[0]).trim() === String(req.id).trim()) row = i + 2; });
      if (row < 0) throw new Error('Order ' + req.id + ' not found in sheet');
      const col = { name: find('name'), phone: find('phone', 'whatsapp'), wing: find('wing'), flat: find('flat'),
                    items: find('items', 'item'), plates: find('plates'), amount: find('amount'),
                    mode: find('payment mode'), note: find('note'), date: find('delivery date'),
                    card: find('thank-you card', 'thank you card') };
      const f = req.fields || {};
      Object.keys(col).forEach(k => {
        if (col[k] < 0 || f[k] === undefined || f[k] === null) return;
        const cell = sh.getRange(row, col[k] + 1);
        const v = String(f[k]).trim();
        if (k === 'plates' || k === 'amount') cell.setValue(Number(v) || 0);
        else if (k === 'date') { const m = v.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) cell.setValue(new Date(+m[1], +m[2] - 1, +m[3])); }
        else if ((k === 'flat' || k === 'phone') && /^[1-9]\d*$/.test(v)) cell.setValue(Number(v));   // keep numbers numeric like the form does
        else cell.setValue(v);
      });
      SpreadsheetApp.flush();
      if (f.card === 'Sent' || f.card === 'Needed') mhSetFlatCard_(ss, sh, row, head, f.card);
      const r = mhApplyOrders_(ss, [{ id: req.id, status: f.status, pay: f.pay }]);
      out = { ok: true, changed: r.changed };

    } else if (req.a === 'order') {
      const r = mhApplyOrders_(ss, [req]);
      if (r.missing.length) throw new Error('Order ' + req.id + ' not found in sheet');
      out = { ok: true, changed: r.changed };

    } else if (req.a === 'menu') {
      const sh = ss.getSheetByName('Menu');
      const last = Math.max(sh.getLastRow(), 2);
      sh.getRange(2, 1, last - 1, 7).clearContent();
      const rows = (req.menu || []).map(m => [m.item, Number(m.price) || 0, m.avail === 'No' ? 'No' : 'Yes', m.desc || '', m.photo || '', m.prep || '', mhMenuDate_(m.mdate)]);
      if (rows.length) {
        const rg = sh.getRange(2, 1, rows.length, 7);
        sh.getRange(2, 6, rows.length, 1).setNumberFormat('@');   // keep "07:00" as text
        sh.getRange(2, 7, rows.length, 1).setNumberFormat('yyyy-mm-dd');   // Menu date
        rg.setValues(rows);
      }
      out = { ok: true, rows: rows.length };

    } else if (req.a === 'setting') {
      const sh = ss.getSheetByName('Settings');
      const keys = sh.getRange(1, 1, sh.getLastRow(), 1).getValues();
      let row = -1;
      for (let i = 0; i < keys.length; i++) if (String(keys[i][0]).trim() === String(req.key).trim()) { row = i + 1; break; }
      if (row < 0) throw new Error('Setting not found: ' + req.key);
      const cell = sh.getRange(row, 2);
      const sval = String(req.value);
      if (/^[\d:]+$/.test(sval)) cell.setNumberFormat('@');   // keep 07:00 / 5814 / 1000 as text, like the sheet's own values
      if (cell.getDisplayValue() !== sval) cell.setValue(sval);
      out = { ok: true };

    } else {
      throw new Error('Unknown action');
    }
  } catch (err) {
    out = { ok: false, error: String(err.message || err) };
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}
