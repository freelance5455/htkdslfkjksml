/**
 * THE MORNING HUB – update API for the mobile app (v3)
 * Lets the app change Payment, Status, Menu and Settings in your Google Sheet.
 * Paste this whole file into your Apps Script project (Extensions > Apps Script),
 * set your own PIN below, then Deploy > Manage deployments > pencil > New version.
 */
const MH_SHEET_ID = '1w4KIunEDDUuZs-RkvDAY0gbH6SPu3lTEarGQsTSPGa0';
const MH_PIN = 'CHANGE-ME-1234';           // <-- choose a PIN; type the same in the app

const MH_STATUS = ['New', 'Out for delivery', 'Delivered'];
const MH_PAY = ['Pending', 'Paid'];

function doPost(e) { return mhHandle_(e); }   // if you already have doPost, call mhHandle_(e) from it when the body has "pin"

// Writes Status / Payment for a list of {id,status,pay}, then re-reads the sheet to confirm it really saved.
function mhApplyOrders_(ss, list) {
  const sh = ss.getSheetByName('Orders');
  const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(h => String(h).trim().toLowerCase());
  const cId = head.indexOf('order id'), cSt = head.indexOf('status'), cPay = head.indexOf('payment');
  if (cId < 0 || cSt < 0 || cPay < 0) throw new Error('Orders columns not found (need Order ID, Status, Payment)');
  const last = sh.getLastRow();
  const ids = last > 1 ? sh.getRange(2, cId + 1, last - 1, 1).getValues() : [];
  const rowOf = {};
  ids.forEach((r, i) => { rowOf[String(r[0]).trim()] = i + 2; });
  const missing = [], want = [];
  let changed = 0;
  (list || []).forEach(o => {
    const row = rowOf[String(o.id).trim()];
    if (!row) { missing.push(o.id); return; }
    const stCell = sh.getRange(row, cSt + 1), payCell = sh.getRange(row, cPay + 1);
    if (MH_STATUS.indexOf(o.status) >= 0) { if (String(stCell.getValue()).trim() !== o.status) { stCell.setValue(o.status); changed++; } }
    if (MH_PAY.indexOf(o.pay) >= 0) { if (String(payCell.getValue()).trim() !== o.pay) { payCell.setValue(o.pay); changed++; } }
    want.push({ id: o.id, row: row, status: o.status, pay: o.pay });
  });
  SpreadsheetApp.flush();
  const bad = [];
  want.forEach(w => {
    const st = String(sh.getRange(w.row, cSt + 1).getValue()).trim();
    const pay = String(sh.getRange(w.row, cPay + 1).getValue()).trim();
    if ((MH_STATUS.indexOf(w.status) >= 0 && st !== w.status) || (MH_PAY.indexOf(w.pay) >= 0 && pay !== w.pay)) bad.push(w.id);
  });
  if (bad.length) throw new Error('Sheet did not keep Status/Payment for: ' + bad.join(', ') + ' (is the column a formula?)');
  return { changed: changed, missing: missing };
}

function mhHandle_(e) {
  const lock = LockService.getScriptLock();
  let out;
  try {
    lock.waitLock(20000);
    const req = JSON.parse(e.postData.contents);
    if (String(req.pin) !== String(MH_PIN)) throw new Error('Wrong PIN');
    const ss = SpreadsheetApp.openById(MH_SHEET_ID);

    if (req.a === 'ping') {
      out = { ok: true, version: 3,
              orders: Math.max(ss.getSheetByName('Orders').getLastRow() - 1, 0),
              menu: Math.max(ss.getSheetByName('Menu').getLastRow() - 1, 0) };

    } else if (req.a === 'orders') {            // batch: [{id, status, pay}, ...]
      const r = mhApplyOrders_(ss, req.list);
      out = { ok: true, changed: r.changed, missing: r.missing };

    } else if (req.a === 'order') {
      const r = mhApplyOrders_(ss, [req]);
      if (r.missing.length) throw new Error('Order ' + req.id + ' not found in sheet');
      out = { ok: true, changed: r.changed };

    } else if (req.a === 'menu') {
      const sh = ss.getSheetByName('Menu');
      const last = Math.max(sh.getLastRow(), 2);
      sh.getRange(2, 1, last - 1, 5).clearContent();
      const rows = (req.menu || []).map(m => [m.item, Number(m.price) || 0, m.avail === 'No' ? 'No' : 'Yes', m.desc || '', m.photo || '']);
      if (rows.length) sh.getRange(2, 1, rows.length, 5).setValues(rows);
      out = { ok: true, rows: rows.length };

    } else if (req.a === 'setting') {
      const sh = ss.getSheetByName('Settings');
      const keys = sh.getRange(1, 1, sh.getLastRow(), 1).getValues();
      let row = -1;
      for (let i = 0; i < keys.length; i++) if (String(keys[i][0]).trim() === String(req.key).trim()) { row = i + 1; break; }
      if (row < 0) throw new Error('Setting not found: ' + req.key);
      const cell = sh.getRange(row, 2);
      if (cell.getDisplayValue() !== String(req.value)) cell.setValue(req.value);
      out = { ok: true };

    } else {
      throw new Error('Unknown action');
    }
  } catch (err) {
    out = { ok: false, error: String(err.message || err) };
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}
