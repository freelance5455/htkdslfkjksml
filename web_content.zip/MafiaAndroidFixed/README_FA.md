# پروژه Android مافیا

این نسخه HTML را به صورت محلی داخل APK اجرا می‌کند و برای رفع خطای `appassets.androidplatform.net/web/index.html` از `WebViewAssetLoader` استفاده شده است.

- صفحه اصلی داخل `app/src/main/assets/index.html` است.
- آیکون از تصویر ارسالی کاربر ساخته شده است.
- اینترنت برای اجرای بازی لازم نیست.
- JavaScript و DOM storage فعال است تا localStorage بازی کار کند.

در Android Studio پروژه را باز کنید و از Build > Build APK(s) خروجی بگیرید.
