KAWAII STICKER MERGE - APK BUILD PACKAGE
========================================

Contents:
1. index.html    - Complete, self-contained game (all 8 sketchbook doodles, fixed controls).
2. manifest.json - App manifest for standalone mobile installation and APK packaging.
3. icon.svg      - Custom Strawberry Bear app icon.

How to Build an Android .APK:
Option A (Offline / Desktop Builder):
- Open "Website 2 APK Builder" (or Apache Cordova / Capacitor), choose Local HTML Website, select this folder (with index.html as the main file), and click Generate APK.

Option B (Online Web-to-APK):
- Upload this .zip file directly to AppsGeyser (HTML/ZIP to APK template) or host the folder on GitHub Pages / Netlify and generate a signed APK via PWABuilder.com.
