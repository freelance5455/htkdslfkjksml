# KINGSMAN'S SON EDGE — PWA + Deriv Public Tick Adapter (0.2.0)

Mobile-first installable web app for digit Over/Under research. Includes seven screens, five fixed strategy profiles, four operating modes, a digit intelligence board, a public Deriv live-tick adapter, and explicit safety boundaries.

## Install on Android

This is a Progressive Web App (PWA), so it installs from a secure website rather than as an APK.

1. Upload the **contents** of this folder to an HTTPS static host (for example, a static site host you control). Keep `index.html`, `manifest.webmanifest`, `sw.js`, and `icon.svg` together in the same directory.
2. Open the HTTPS site in Chrome on Android.
3. Open Chrome's ⋮ menu and choose **Install app** or **Add to Home screen**.
4. Launch **KSE Edge** from the home screen.

For local desktop testing, run `python -m http.server 8080` in this folder and open `http://localhost:8080`. Service-worker/PWA installation requires localhost or HTTPS. A phone cannot use the computer's `localhost`; use a secure hosted URL or a LAN server reachable by phone (PWA install may still require HTTPS).

## Test live Deriv market data

1. Open **Risk and Settings**.
2. Choose **Deriv official public WebSocket**.
3. Select a symbol such as `R_100` or `1HZ100V`.
4. Press **Connect live ticks**. The connection indicator should progress from CONNECTING to CONNECTED, then show the latest quote and time.
5. Open **Digit Intelligence**. The red cursor follows the last digit extracted from the incoming quote, and frequency percentages use the observed rolling window.
6. Press **Disconnect** to stop the public stream.

The adapter uses Deriv's documented public WebSocket endpoint `wss://api.derivws.com/trading/v1/options/ws/public` and subscribes to `ticks`. No account token is requested, entered, or stored. Quote digit extraction uses the quote precision (`pip_size`) supplied by the tick when available. This is a market-data test adapter, not a forecast.

## What is real vs mocked

- **Real when connected:** public Deriv tick stream, tick quote/timestamp processing, rolling observed frequencies, rankings calculated from the received sample, latest-digit cursor.
- **Mock/local:** initial preview sample, preview tick generator, strategy evidence and decision screens, risk settings, journal placeholder, AI/research workflow, and demo-only stop/re-arm state.
- **Not implemented:** OAuth, account authorization, private account data, authenticated proposal/buy/sell, open-contract monitoring, settlement reconciliation, backend-enforced risk guardian, append-only audit storage, and production-grade tests. Live order entry is deliberately locked.

## Security and deployment

The app intentionally does not ask for a Deriv token. Do not add a permanent token to browser code or a public repository. For authenticated trading, build a secure backend using Deriv's current documented authentication/OTP flow, keep secrets server-side, enforce risk and idempotency on the server, and require explicit demo/live release approvals. The frontend must never be treated as the source of truth for order permissions.

Official documentation:
- API overview: https://developers.deriv.com/docs/intro/api-overview/
- Public tick stream: https://developers.deriv.com/docs/data/ticks/
- Price proposal: https://developers.deriv.com/docs/trading/proposal/
- Buy contract (authenticated): https://developers.deriv.com/docs/trading/buy/
- Authentication: https://api.deriv.com/docs/core-concepts/authorization-authentication/

## Current limitations

- The PWA requires HTTPS (or localhost) to install and use service workers.
- WebSocket availability can depend on network conditions and current Deriv API behavior.
- The digit-frequency board describes observations; rankings and streaks do not establish predictive edge.
- No profitability claims are made. Live trading is not enabled.
