#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WA-OSINT PRO 4.0 - public-information toolkit (single file, Android friendly)

Required : phonenumbers   (pip install phonenumbers)
Optional : dnspython, colorama (app falls back to stdlib / DNS-over-HTTPS / ANSI)

External free services used (no keys needed, all passive, all with timeouts):
  api.ipify.org          GET  public-IP discovery.            Limit: generous, may fail offline.
  ip-api.com/json/<ip>   GET  geo/ISP/ASN/proxy/hosting/mobile. Limit: 45 req/min per IP, HTTP only
                              (free tier), non-commercial use. Proxy/hosting flags are provider guesses.
  ipwho.is/<ip>          GET  fallback geo/ISP/ASN (no proxy/hosting flags). Fair-use limits.
  dns.google/resolve     GET  DNS-over-HTTPS fallback when dnspython is absent.
  rdap.org/domain/<d>    GET  public domain registration (RDAP). Coverage varies by TLD.
  api.github.com/search/users  GET public GitHub users whose PUBLIC profile email matches.
                              Limit: ~10 req/min unauthenticated.
"""
import os, sys, json, csv, re, time, socket, ssl, ipaddress, platform, shutil, subprocess, base64, uuid, hashlib, zipfile, mimetypes, struct
import html as htmllib
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from html.parser import HTMLParser
import datetime as dt
import urllib.request, urllib.parse, urllib.error

VERSION = "7.0"
APP = "WA-OSINT PRO"

try:
    import phonenumbers
    from phonenumbers import carrier, geocoder, timezone as pn_tz
except Exception:
    phonenumbers = None
try:
    import dns.resolver as dnsres
except Exception:
    dnsres = None
try:
    import colorama
    colorama.init()
except Exception:
    colorama = None

# ----------------------------------------------------------------- storage
def _base():
    try:
        root = os.path.dirname(os.path.abspath(__file__))
        if not os.access(root, os.W_OK):
            raise OSError
    except Exception:
        root = os.getcwd()
    return os.path.join(os.environ.get("WA_OSINT_HOME", root), "wa_osint_data")

BASE = _base()
SUBDIRS = ["reports", "phone_reports", "email_reports", "ip_reports",
           "business_database", "scam_reports", "settings", "logs", "cache", "scan_reports", "evidence_vault", "dns_history", "html_reports", "exports"]
DEFAULTS = {"colors": True, "animations": True, "report_dir": "", "version": VERSION,
            "allow_http_ip_api": False, "vt_key": "", "urlhaus_key": ""}
SETTINGS = dict(DEFAULTS)

def ensure_dirs():
    for d in SUBDIRS:
        try:
            os.makedirs(os.path.join(BASE, d), exist_ok=True)
        except OSError as e:
            print("Cannot create folder %s: %s" % (d, e))

def P(*a):
    return os.path.join(BASE, *a)

def log(msg):
    try:
        with open(P("logs", "app.log"), "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (dt.datetime.now().isoformat(timespec="seconds"), msg))
    except Exception:
        pass

def load_json(path, default):
    """Validate JSON before use; damaged files are backed up, never crash."""
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if type(data) is not type(default):
            raise ValueError("unexpected structure")
        return data
    except Exception as e:
        bak = path + ".damaged-%d" % int(time.time())
        try:
            os.replace(path, bak)
        except OSError:
            bak = "(could not back up)"
        log("JSON damaged %s -> %s (%s)" % (path, bak, e))
        warn("Damaged file %s (%s). Backed up to %s; starting clean." % (os.path.basename(path), e, os.path.basename(bak)))
        return default

def save_json(path, data):
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
        return True
    except Exception as e:
        log("save fail %s: %s" % (path, e))
        err("Could not save %s: %s" % (path, e))
        return False

def load_settings():
    global SETTINGS
    s = load_json(P("settings", "settings.json"), {})
    SETTINGS = dict(DEFAULTS)
    SETTINGS.update({k: v for k, v in s.items() if k in DEFAULTS})

def save_settings():
    save_json(P("settings", "settings.json"), SETTINGS)

def out_dir(kind="reports"):
    if SETTINGS.get("report_dir"):
        d = SETTINGS["report_dir"]
        try:
            os.makedirs(d, exist_ok=True)
            if os.access(d, os.W_OK):
                return d
        except OSError:
            pass
    return P(kind)

def now():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def safe_name(s):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s)[:60]

def save_report(kind, subject, data, folder):
    """Saves a new timestamped file. Never overwrites an existing report."""
    rec = {"type": kind, "subject": subject, "created": now(),
           "app": "%s %s" % (APP, VERSION), "notes": [], "data": data}
    base = "%s_%s_%s" % (kind, safe_name(subject), dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
    path = os.path.join(out_dir(folder), base + ".json")
    n = 1
    while os.path.exists(path):
        n += 1
        path = os.path.join(out_dir(folder), "%s_%d.json" % (base, n))
    if save_json(path, rec):
        ok("Report saved locally: " + path)
        return path
    return None

# ----------------------------------------------------------------- terminal ui
COL = {"Y": "1;33", "r": "31", "g": "32", "y": "33", "b": "34", "m": "35", "c": "36", "w": "37", "B": "1"}

def paint(t, c):
    if not SETTINGS.get("colors", True) or not sys.stdout.isatty():
        return t
    return "\033[%sm%s\033[0m" % (COL.get(c, "37"), t)

def ok(m): print(paint("[+] " + m, "g"))
def warn(m): print(paint("[!] " + m, "y"))
def err(m): print(paint("[x] " + m, "r"))
def info(m): print(paint("[i] " + m, "c"))

def line(ch="=", n=58): print(paint(ch * n, "b"))

def clear():
    if sys.stdout.isatty():
        os.system("cls" if os.name == "nt" else "clear")

def ask(prompt):
    try:
        return input(paint(prompt, "c")).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return ""

def pause():
    ask("\nPress Enter to continue...")

def confirm(q):
    return ask(q + " [y/N]: ").lower() in ("y", "yes")

def kv(k, v, w=22):
    print("%s %s" % (paint(("%s:" % k).ljust(w), "y"), v))

def title(t):
    print()
    line()
    print(paint(" " + t, "B"))
    line()

DISCLAIMER = " NOTE: THIS TOOL ONLY FOR EDUCATIONAL PURPOSE, DON'T USE THIS FOR ILLEGAL ACTIVITY"

LOGO = r"""
 __        __ _      ___  ____ ___ _   _ _____
 \ \      / // \    / _ \/ ___|_ _| \ | |_   _|
  \ \ /\ / // _ \  | | | \___ \| ||  \| | | |
   \ V  V // ___ \ | |_| |___) | || |\  | | |
    \_/\_//_/   \_\ \___/|____/___|_| \_| |_|   PRO"""

def loading():
    if not SETTINGS.get("animations", True) or not sys.stdout.isatty():
        return
    for i in range(0, 21):
        sys.stdout.write("\r" + paint("Loading modules [%s%s] %3d%%" % ("#" * i, "." * (20 - i), i * 5), "c"))
        sys.stdout.flush()
        time.sleep(0.03)
    print()

# ----------------------------------------------------------------- network helpers
UA = {"User-Agent": "WA-OSINT-PRO/%s (+passive public lookups)" % VERSION, "Accept": "application/json"}

def http_json(url, timeout=8, headers=None, data=None, maxbytes=2000000, json_body=None):
    """Returns (data, error). Never raises. data (dict) => form POST."""
    try:
        h = dict(UA); h.update(headers or {})
        body = urllib.parse.urlencode(data).encode() if data else None
        if json_body is not None: body = json.dumps(json_body).encode(); h["Content-Type"] = "application/json"
        req = urllib.request.Request(url, headers=h, data=body)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read(maxbytes).decode("utf-8", "replace")), None
    except urllib.error.HTTPError as e:
        if e.code == 429:
            return None, "Rate limit reached (HTTP 429). Wait a minute and try again."
        if e.code in (401, 403):
            return None, "Access denied (HTTP %s) - check the API key." % e.code
        return None, "Service returned HTTP %s." % e.code
    except urllib.error.URLError as e:
        return None, "Network error: %s" % getattr(e, "reason", e)
    except socket.timeout:
        return None, "Request timed out."
    except ValueError:
        return None, "Service returned invalid data."
    except Exception as e:
        return None, "Unexpected error: %s" % e

def online():
    for host in (("1.1.1.1", 53), ("8.8.8.8", 53)):
        try:
            s = socket.create_connection(host, timeout=2)
            s.close()
            return True
        except Exception:
            continue
    return False

def dns_query(name, rtype):
    """Returns (list_of_strings, error). Uses dnspython, else DNS-over-HTTPS."""
    try:
        if dnsres:
            res = dnsres.Resolver()
            res.lifetime = 6
            ans = (getattr(res, "resolve", None) or res.query)(name, rtype)
            return [a.to_text() for a in ans], None
    except Exception as e:
        nm = type(e).__name__
        if nm in ("NXDOMAIN",):
            return [], "Domain does not exist (NXDOMAIN)"
        if nm in ("NoAnswer",):
            return [], None
        return [], "DNS error: %s" % nm
    data, e = http_json("https://dns.google/resolve?name=%s&type=%s" % (urllib.parse.quote(name), rtype), 8)
    if e:
        return [], e
    if data.get("Status") == 3:
        return [], "Domain does not exist (NXDOMAIN)"
    return [a.get("data", "") for a in data.get("Answer", []) if a.get("type") == {"MX": 15, "TXT": 16, "A": 1, "AAAA": 28, "NS": 2, "CNAME": 5, "SOA": 6, "PTR": 12, "DS": 43, "DNSKEY": 48}.get(rtype)], None

def search_links(q):
    e = urllib.parse.quote_plus(q)
    return [("Google", "https://www.google.com/search?q=" + e),
            ("Bing", "https://www.bing.com/search?q=" + e),
            ("DuckDuckGo", "https://duckduckgo.com/?q=" + e)]

def show_links(q):
    for n, u in search_links(q):
        kv(n, u, 12)

# ----------------------------------------------------------------- 1/4 phone
NUM_TYPES = {}

def phone_analyze(raw, region=None):
    if phonenumbers is None:
        return None, "The 'phonenumbers' library is missing. Install it: pip install phonenumbers"
    raw = raw.strip()
    if not raw:
        return None, "Empty input."
    try:
        n = phonenumbers.parse(raw, region)
    except phonenumbers.NumberParseException as e:
        return None, "Invalid phone number: %s (use international format like +14155552671)" % e
    PT = phonenumbers.PhoneNumberType
    types = {PT.MOBILE: "Mobile", PT.FIXED_LINE: "Fixed line", PT.FIXED_LINE_OR_MOBILE: "Fixed line or mobile",
             PT.TOLL_FREE: "Toll free", PT.PREMIUM_RATE: "Premium rate", PT.VOIP: "VoIP", PT.PERSONAL_NUMBER: "Personal",
             PT.PAGER: "Pager", PT.UAN: "UAN", PT.VOICEMAIL: "Voicemail", PT.SHARED_COST: "Shared cost",
             PT.UNKNOWN: "Unknown"}
    e164 = phonenumbers.format_number(n, phonenumbers.PhoneNumberFormat.E164)
    valid = phonenumbers.is_valid_number(n)
    possible = phonenumbers.is_possible_number(n)
    try:
        car = carrier.name_for_number(n, "en") or "Unavailable"
    except Exception:
        car = "Unavailable"
    try:
        tz = list(pn_tz.time_zones_for_number(n))
    except Exception:
        tz = []
    rc = phonenumbers.region_code_for_number(n)
    d = {
        "input": raw, "international_number": e164,
        "national_number": str(n.national_number),
        "country_code_region": rc or "Unknown", "country": None,
        "calling_code": "+%d" % n.country_code,
        "region_area": geocoder.description_for_number(n, "en") or "Unavailable",
        "international_format": phonenumbers.format_number(n, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
        "national_format": phonenumbers.format_number(n, phonenumbers.PhoneNumberFormat.NATIONAL),
        "number_type": types.get(phonenumbers.number_type(n), "Unknown"),
        "valid": valid, "possible": possible,
        "carrier": car, "timezones": tz or ["Unavailable"],
        "whatsapp_link": "https://wa.me/" + e164.lstrip("+"),
    }
    try:
        d["country"] = geocoder.country_name_for_number(n, "en") or rc or "Unknown"
    except Exception:
        d["country"] = rc or "Unknown"
    d["search_links"] = {nm: u for nm, u in search_links('"%s" OR "%s"' % (e164, d["international_format"]))}
    return d, None

def phone_show(d):
    title("PHONE NUMBER LOOKUP")
    for k, lab in [("international_number", "International number"), ("national_number", "National number"),
                   ("country", "Country"), ("country_code_region", "Country code (region)"),
                   ("calling_code", "Calling code"), ("region_area", "Region / area"),
                   ("international_format", "International format"), ("national_format", "National format"),
                   ("number_type", "Number type"), ("valid", "Valid"), ("possible", "Possible"),
                   ("carrier", "Carrier (original)"), ("whatsapp_link", "wa.me link")]:
        kv(lab, d[k])
    kv("Time zones", ", ".join(d["timezones"]))
    print()
    warn("A working wa.me link does NOT prove a WhatsApp account exists.")
    warn("Carrier = ORIGINAL allocation; ported numbers may differ. No owner/SIM identity is available.")
    info("Public search links (manual review; results are not verified by this tool):")
    for n, u in d["search_links"].items():
        kv(n, u, 12)

def phone_menu():
    while True:
        title("[1] PHONE NUMBER LOOKUP")
        raw = ask("Enter number (+country code..., 0 = back): ")
        if raw in ("0", ""):
            return
        d, e = phone_analyze(raw)
        if e:
            err(e); pause()
            if phonenumbers is None: return
            continue
        phone_show(d)
        notes = []
        while True:
            c = ask("\n[n] add note  [s] save report  [b] business search  [Enter] back: ").lower()
            if c == "n":
                t = ask("Note: ")
                if t: notes.append({"time": now(), "note": t, "status": "USER NOTE (unverified)"})
            elif c == "s":
                p = save_report("phone", d["international_number"], {
                    "verified_technical_facts": {k: d[k] for k in d if k != "search_links"},
                    "unavailable": ["Subscriber identity", "SIM registration name", "WhatsApp account existence"],
                    "source_urls": d["search_links"], "notes": notes}, "phone_reports")
            elif c == "b":
                business_search(d["international_number"])
            else:
                break

def batch_menu():
    title("[4] BATCH PHONE ANALYZER")
    info("Enter numbers separated by commas or new lines. Empty line to finish.")
    items = []
    while True:
        s = ask("> ")
        if not s: break
        items += [x.strip() for x in re.split(r"[,;\n]", s) if x.strip()]
    if not items:
        return
    rows = []
    for raw in items:
        d, e = phone_analyze(raw)
        if e:
            rows.append({"input": raw, "error": e})
            if phonenumbers is None:
                err(e); break
            print(paint("%-18s INVALID: %s" % (raw, e[:40]), "r"))
            continue
        rows.append({k: d[k] for k in ("input", "international_number", "valid", "country", "calling_code",
                                       "number_type", "carrier", "whatsapp_link")})
        print("%s  valid=%s  %s  %s  %s  carrier=%s" % (paint(d["international_number"], "g"), d["valid"],
              d["country"], d["calling_code"], d["number_type"], d["carrier"]))
        print("    " + d["whatsapp_link"])
    if rows and confirm("Export JSON + CSV?"):
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        jp = os.path.join(out_dir("phone_reports"), "batch_%s.json" % stamp)
        cp = os.path.join(out_dir("phone_reports"), "batch_%s.csv" % stamp)
        save_json(jp, {"created": now(), "results": rows})
        try:
            fields = ["input", "international_number", "valid", "country", "calling_code", "number_type", "carrier", "whatsapp_link", "error"]
            with open(cp, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
                w.writeheader(); w.writerows(rows)
            ok("Saved " + jp); ok("Saved " + cp)
        except OSError as e:
            err("CSV export failed: %s" % e)
    pause()

# ----------------------------------------------------------------- 2 business
def business_search(q=None):
    title("[2] PUBLIC BUSINESS INTELLIGENCE")
    q = q or ask("Business name / number / website to search: ")
    if not q: return
    info("Public search links (nothing is auto-collected or invented):")
    show_links(q)
    show_links_extra(q)
    db_path = P("business_database", "businesses.json")
    db = load_json(db_path, [])
    hits = [b for b in db if q.lower() in json.dumps(b).lower()]
    if hits:
        info("Matches in your local verified database:")
        for b in hits: print_business(b)
    else:
        info("No local database entry matches. NOT PUBLICLY FOUND (locally).")

def show_links_extra(q):
    kv("Google Maps", "https://www.google.com/maps/search/" + urllib.parse.quote(q), 12)

def print_business(b):
    for k in ("name", "website", "category", "contact", "source_url", "evidence", "added"):
        kv(k.replace("_", " ").title(), b.get(k, ""), 14)
    print()

def business_menu():
    while True:
        title("[2] PUBLIC BUSINESS INTELLIGENCE")
        print("[1] Search (links + local database)\n[2] Add verified public business info\n[3] View database\n[0] Back")
        c = ask("Choice: ")
        if c == "1": business_search(); pause()
        elif c == "2":
            b = {"name": ask("Business name: "), "website": ask("Public website: "), "category": ask("Public category: "),
                 "contact": ask("Public contact info: "), "source_url": ask("Source URL (required): "),
                 "evidence": ask("Evidence notes: "), "added": now(), "status": "USER-ENTERED, verify at source"}
            if not b["name"] or not b["source_url"]:
                err("Name and Source URL are required (no unsourced entries)."); continue
            p = P("business_database", "businesses.json")
            db = load_json(p, []); db.append(b)
            if save_json(p, db): ok("Added.")
        elif c == "3":
            db = load_json(P("business_database", "businesses.json"), [])
            if not db: warn("Database is empty.")
            for b in db: print_business(b)
            pause()
        elif c == "0": return

# ----------------------------------------------------------------- 3 scam reports
LABEL = "UNVERIFIED COMMUNITY REPORT"

def scam_menu():
    p = P("scam_reports", "reports.json")
    while True:
        title("[3] COMMUNITY SCAM INTELLIGENCE")
        warn(LABEL + "S: not proof of wrongdoing. Never treat a number/person as a scammer based on these.")
        print("[1] Add report\n[2] View all\n[3] Search\n[4] Export\n[5] Delete report\n[0] Back")
        c = ask("Choice: ")
        db = load_json(p, [])
        if c == "1":
            num = ask("Reported phone number: ")
            if not num: continue
            norm = num
            if phonenumbers:
                d, e = phone_analyze(num)
                norm = d["international_number"] if d else num
            r = {"id": int(time.time() * 1000), "number": norm, "description": ask("Description: "),
                 "date": ask("Incident date (YYYY-MM-DD, Enter=today): ") or dt.date.today().isoformat(),
                 "evidence": ask("Evidence / source: "), "added": now(), "label": LABEL}
            db.append(r)
            if save_json(p, db): ok("Report added, labelled " + LABEL)
        elif c in ("2", "3"):
            q = ask("Search text: ").lower() if c == "3" else ""
            shown = [r for r in db if q in json.dumps(r).lower()]
            if not shown: warn("No reports.")
            for i, r in enumerate(shown):
                print(paint("#%s  [%s]" % (r["id"], r["label"]), "y"))
                kv("Number", r["number"], 12); kv("Date", r["date"], 12)
                kv("Description", r["description"], 12); kv("Evidence", r["evidence"], 12); print()
            pause()
        elif c == "4":
            ep = os.path.join(out_dir("scam_reports"), "export_%s.json" % dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
            if save_json(ep, db): ok("Exported " + ep)
        elif c == "5":
            i = ask("Report ID to delete: ")
            keep = [r for r in db if str(r["id"]) != i]
            if len(keep) == len(db): err("ID not found.")
            elif confirm("Delete report %s?" % i):
                save_json(p, keep); ok("Deleted.")
        elif c == "0": return

# ----------------------------------------------------------------- 5 reports
def all_report_files():
    seen, res = set(), []
    dirs = ["reports", "phone_reports", "email_reports", "ip_reports"]
    for d in dirs + ([SETTINGS["report_dir"]] if SETTINGS.get("report_dir") else []):
        path = d if os.path.isabs(d) else P(d)
        if not os.path.isdir(path): continue
        for f in sorted(os.listdir(path)):
            fp = os.path.join(path, f)
            if f.endswith(".json") and fp not in seen and not f.startswith("batch_"):
                seen.add(fp); res.append(fp)
    return res

def reports_menu():
    while True:
        title("[5] INVESTIGATION REPORTS")
        files = all_report_files()
        print("[1] List  [2] Search  [3] View/add note  [4] Export CSV of all  [5] Create manual report  [0] Back")
        c = ask("Choice: ")
        if c in ("1", "2"):
            q = ask("Search text: ").lower() if c == "2" else ""
            n = 0
            for i, fp in enumerate(files):
                try:
                    txt = open(fp, encoding="utf-8").read()
                except OSError:
                    continue
                if q in txt.lower():
                    n += 1; print("%3d) %s" % (i + 1, os.path.basename(fp)))
            if not n: warn("Nothing found.")
            pause()
        elif c == "3":
            i = ask("Report number: ")
            if not i.isdigit() or not (0 < int(i) <= len(files)): err("Invalid number."); continue
            fp = files[int(i) - 1]
            rec = load_json(fp, {})
            if not rec: continue
            print(json.dumps(rec, indent=2, ensure_ascii=False))
            t = ask("Add investigation note (Enter=none): ")
            if t:
                rec.setdefault("notes", []).append({"time": now(), "note": t, "status": "USER NOTE (unverified)"})
                save_json(fp, rec); ok("Note added with timestamp.")
            pause()
        elif c == "4":
            cp = os.path.join(out_dir("reports"), "all_reports_%s.csv" % dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
            try:
                with open(cp, "w", newline="", encoding="utf-8") as f:
                    w = csv.writer(f); w.writerow(["file", "type", "subject", "created", "notes_count"])
                    for fp in files:
                        r = load_json(fp, {})
                        if r: w.writerow([os.path.basename(fp), r.get("type"), r.get("subject"), r.get("created"), len(r.get("notes", []))])
                ok("Exported " + cp)
            except OSError as e:
                err("Export failed: %s" % e)
        elif c == "5":
            s = ask("Subject: ")
            if s:
                src = ask("Source URL(s): ")
                note = ask("Findings: ")
                save_report("manual", s, {"verified": [], "unverified": [{"text": note, "time": now()}], "source_urls": src}, "reports")
        elif c == "0": return

# ----------------------------------------------------------------- 6 webguard
def webguard():
    title("[6] WEBGUARD (passive checks only)")
    u = ask("URL or domain: ")
    if not u: return
    if "://" not in u: u = "https://" + u
    pu = urllib.parse.urlparse(u)
    host = pu.hostname
    if not host or pu.scheme not in ("http", "https") or not re.match(r"^[A-Za-z0-9.-]+$|^[0-9a-fA-F:]+$", host):
        err("Invalid URL."); pause(); return
    res = {"url": u, "host": host, "checked": now()}
    kv("Host", host)
    try:
        ips = sorted({x[4][0] for x in socket.getaddrinfo(host, 443, proto=socket.IPPROTO_TCP)})
        res["ips"] = ips; kv("Resolved IPs", ", ".join(ips))
    except socket.gaierror as e:
        err("DNS resolution failed: %s" % e); pause(); return
    obs = []
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, 443), timeout=8) as s:
            with ctx.wrap_socket(s, server_hostname=host) as ss:
                cert = ss.getpeercert()
                res["https"] = True; res["tls_version"] = ss.version()
        kv("HTTPS", paint("Available, certificate valid for host", "g")); kv("TLS version", res["tls_version"])
        exp = dt.datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z")
        days = (exp - dt.datetime.utcnow()).days
        iss = dict(x[0] for x in cert.get("issuer", ()))
        kv("Cert expires", "%s (%d days)" % (cert["notAfter"], days)); kv("Issuer", iss.get("organizationName", iss.get("commonName", "?")))
        res["cert_expires"] = cert["notAfter"]; res["cert_issuer"] = iss
        obs.append("Certificate expires within 14 days." if days < 14 else "Certificate validity period looks healthy.")
    except ssl.SSLCertVerificationError as e:
        res["https"] = False; kv("HTTPS", paint("Certificate FAILED verification: %s" % e.verify_message, "r"))
        obs.append("TLS certificate did not verify - browsers will warn.")
    except Exception as e:
        res["https"] = False; kv("HTTPS", paint("Not available (%s)" % type(e).__name__, "y"))
        obs.append("HTTPS on port 443 could not be established.")
    if res.get("https"):
        try:
            req = urllib.request.Request("https://%s/" % host, method="HEAD", headers=UA)
            with urllib.request.urlopen(req, timeout=8) as r:
                h = {k.lower(): v for k, v in r.headers.items()}
            for hd in ("strict-transport-security", "content-security-policy", "x-frame-options", "x-content-type-options"):
                kv(hd, h.get(hd, paint("not set", "y")), 28)
            if "strict-transport-security" not in h: obs.append("No HSTS header observed.")
            res["headers"] = {k: h.get(k) for k in ("server", "strict-transport-security", "content-security-policy")}
        except Exception as e:
            info("Header check skipped: %s" % type(e).__name__)
    parts = host.split(".")
    if len(parts) >= 2 and not re.match(r"^\d+\.\d+\.\d+\.\d+$", host):
        dom = ".".join(parts[-2:])
        data, e = http_json("https://rdap.org/domain/" + dom, 10)
        if e: info("Domain info unavailable: " + e)
        else:
            ev = {x.get("eventAction"): x.get("eventDate") for x in data.get("events", [])}
            kv("Domain (RDAP)", data.get("ldhName", dom)); kv("Registered", ev.get("registration", "n/a")); kv("Expires", ev.get("expiration", "n/a"))
            res["rdap"] = {"registered": ev.get("registration"), "expires": ev.get("expiration")}
    print(); info("Observations:")
    for o in obs: print("  - " + o)
    if confirm("\nSave as report?"): save_report("webguard", host, res, "reports")
    pause()

# ----------------------------------------------------------------- 7 IP
def public_ip():
    for url in ("https://api.ipify.org?format=json", "https://api64.ipify.org?format=json"):
        d, e = http_json(url, 6)
        if d and d.get("ip"): return d["ip"], None
    return None, e or "Could not discover public IP"

def ip_valid(s):
    try: return str(ipaddress.ip_address(s.strip()))
    except ValueError: return None

# ---- IP intelligence (v4.1: HTTPS-first providers, verified hosting/CDN detection) ----
def _asn_num(s):
    m = re.search(r"\bAS(\d+)\b", str(s or ""), re.I) or re.fullmatch(r"(\d+)", str(s or "").strip())
    return int(m.group(1)) if m else None

# provider -> (network type, verified ASNs, org keywords, hostname hints, note)
KNOWN_NETS = {
    "Cloudflare": ("CDN / Reverse Proxy", {13335, 209242}, ["cloudflare"], ["cloudflare"], ""),
    "Amazon AWS": ("Cloud Hosting", {16509, 14618, 8987}, ["amazon", "aws"], ["amazonaws.com", "awsglobalaccelerator"], ""),
    "Google Cloud": ("Cloud Hosting", {396982, 19527}, ["google"], ["googleusercontent.com", "bc.googleusercontent"], ""),
    "Google (AS15169)": ("Cloud or Google services", {15169}, ["google"], ["1e100.net", "googleusercontent.com"],
                         "AS15169 carries both Google Cloud and consumer Google services; cannot tell which."),
    "Microsoft Azure": ("Cloud Hosting", {8075}, ["microsoft"], ["azure", "cloudapp.net", "msedge.net"],
                        "AS8075 also carries other Microsoft services."),
    "DigitalOcean": ("Cloud Hosting", {14061}, ["digitalocean"], ["digitalocean", "ondigitalocean"], ""),
    "OVH": ("Hosting Provider", {16276}, ["ovh"], ["ovh.net", "ovh.com"], ""),
    "Hetzner": ("Hosting Provider", {24940, 213230}, ["hetzner"], ["hetzner", "your-server.de"], ""),
    "Akamai": ("CDN / Reverse Proxy", {20940, 16625, 35994, 63949}, ["akamai", "linode"], ["akamai", "linode"], ""),
    "Fastly": ("CDN / Reverse Proxy", {54113}, ["fastly"], ["fastly"], ""),
}

def detect_provider(asn, asn_org, hostname):
    """A provider is only reported when the ASN matches a known number.
    Organization and hostname are shown as corroboration, never as sole proof."""
    out = {"provider": "UNKNOWN", "network_type": "UNKNOWN", "evidence": [], "note": "",
           "detection": "Provider could not be verified from ASN data."}
    if asn is None:
        out["detection"] = "No ASN data available, so no provider claim is made."
        return out
    for name, (ntype, asns, kws, hints, note) in KNOWN_NETS.items():
        if asn in asns:
            out.update(provider=name, network_type=ntype, note=note)
            out["evidence"].append("ASN AS%d is a known %s ASN" % (asn, name.split(" (")[0]))
            if asn_org and any(k in asn_org.lower() for k in kws): out["evidence"].append("ASN organization: %s" % asn_org)
            if hostname and any(h in hostname.lower() for h in hints): out["evidence"].append("Hostname: %s" % hostname)
            out["detection"] = "Verified by ASN" + (" with %d corroborating signal(s)." % (len(out["evidence"]) - 1) if len(out["evidence"]) > 1 else " only (org/hostname did not corroborate).")
            return out
    out["detection"] = "AS%d is not in the known CDN/cloud list (likely an ISP or other network). No CDN/hosting claim made." % asn
    out["not_listed"] = True
    return out

def _D(x):
    return x if isinstance(x, dict) else {}

def _ll(v):
    try: return float(v)
    except (TypeError, ValueError): return None

def _prov_ipwho(ip):
    d, e = http_json("https://ipwho.is/" + ip, 8)
    if not isinstance(d, dict) or not d.get("success"): return None, "ipwho.is: " + (e or _D(d).get("message", "failed"))
    c = _D(d.get("connection"))
    return dict(source="ipwho.is (HTTPS)", country=d.get("country"), country_code=d.get("country_code"), region=d.get("region"),
                city=d.get("city"), lat=_ll(d.get("latitude")), lon=_ll(d.get("longitude")), isp=c.get("isp"), org=c.get("org"),
                asn=_asn_num(c.get("asn")), asn_org=c.get("org") or c.get("isp"), hostname=None), None

def _prov_ipinfo(ip):
    d, e = http_json("https://ipinfo.io/%s/json" % ip, 8)
    if not isinstance(d, dict) or d.get("bogon") or d.get("error"): return None, "ipinfo.io: " + (e or "no data")
    loc = (d.get("loc") or ",").split(",")
    org = d.get("org") or ""
    m = re.match(r"(AS\d+)\s+(.*)", org)
    return dict(source="ipinfo.io (HTTPS)", country=None, country_code=d.get("country"), region=d.get("region"), city=d.get("city"),
                lat=_ll(loc[0]), lon=_ll(loc[1] if len(loc) > 1 else None), isp=None, org=m.group(2) if m else org or None,
                asn=_asn_num(m.group(1)) if m else None, asn_org=m.group(2) if m else None, hostname=d.get("hostname")), None

def _prov_ipapico(ip):
    d, e = http_json("https://ipapi.co/%s/json/" % ip, 8)
    if not isinstance(d, dict) or d.get("error"): return None, "ipapi.co: " + (e or str(_D(d).get("reason", "failed")))
    return dict(source="ipapi.co (HTTPS)", country=d.get("country_name"), country_code=d.get("country_code"), region=d.get("region"),
                city=d.get("city"), lat=_ll(d.get("latitude")), lon=_ll(d.get("longitude")), isp=d.get("org"), org=d.get("org"),
                asn=_asn_num(d.get("asn")), asn_org=d.get("org"), hostname=None), None

def _flags_ipapiis(ip):
    """HTTPS source of VPN/proxy/datacenter/mobile flags (ipapi.is, free tier, no key). Flags are provider estimates."""
    d, e = http_json("https://api.ipapi.is/?q=" + ip, 8)
    if not isinstance(d, dict) or d.get("error") or ("ip" not in d and "is_vpn" not in d): return None, "ipapi.is: " + (e or str(_D(d).get("error", "no data")))
    bad = [d.get(k) for k in ("is_proxy", "is_vpn", "is_tor")]
    proxy = True if any(v is True for v in bad) else (False if all(v is False for v in bad) else None)
    kinds = [n for n, k in (("Proxy", "is_proxy"), ("VPN", "is_vpn"), ("Tor", "is_tor")) if d.get(k) is True]
    asn, co = d.get("asn"), d.get("company")
    if proxy is None and d.get("is_mobile") is None and d.get("is_datacenter") is None:
        return None, "ipapi.is: response had no flag fields (keys: %s)" % ",".join(sorted(d.keys()))[:80]
    return dict(src="ipapi.is", proxy=proxy, proxy_kinds=kinds, dc=d.get("is_datacenter"), mobile=d.get("is_mobile"),
                net_type=_D(asn).get("type") or _D(co).get("type"),
                asn=_asn_num(_D(asn).get("asn") if isinstance(asn, dict) else asn),
                asn_org=_D(asn).get("org") or _D(asn).get("descr"),
                company=_D(co).get("name") or (co if isinstance(co, str) else None)), None

def _flags_ipquery(ip):
    """Second free HTTPS flag source (ipquery.io, no key)."""
    d, e = http_json("https://api.ipquery.io/" + ip, 8)
    if not isinstance(d, dict) or not isinstance(d.get("risk"), dict): return None, "ipquery.io: " + (e or "no risk data in response")
    k, isp = d["risk"], _D(d.get("isp"))
    bad = [k.get(x) for x in ("is_proxy", "is_vpn", "is_tor")]
    proxy = True if any(v is True for v in bad) else (False if all(v is False for v in bad) else None)
    kinds = [n for n, x in (("Proxy", "is_proxy"), ("VPN", "is_vpn"), ("Tor", "is_tor")) if k.get(x) is True]
    if proxy is None and k.get("is_mobile") is None and k.get("is_datacenter") is None: return None, "ipquery.io: no flag fields"
    return dict(src="ipquery.io", proxy=proxy, proxy_kinds=kinds, dc=k.get("is_datacenter"), mobile=k.get("is_mobile"), net_type=None,
                asn=_asn_num(isp.get("asn")), asn_org=isp.get("org"), company=isp.get("isp")), None

def _prov_flags(ip):
    """Tries HTTPS flag sources in order; first one that actually returns flags wins. Flags are provider estimates."""
    errs = []
    for fn in (_flags_ipapiis, _flags_ipquery):
        try: d, e = fn(ip)
        except Exception as ex: d, e = None, "%s: unexpected data (%s)" % (fn.__name__, type(ex).__name__)
        if d: return d, None, errs
        errs.append(e)
    return None, "; ".join(errs), errs

def ip_analyze(ip):
    """THE common analyzer (custom IP, .me mode and scanner). HTTPS providers only by default."""
    a = ipaddress.ip_address(ip)
    if a.is_private or a.is_loopback or a.is_link_local or a.is_reserved or a.is_multicast:
        return None, "That is a private/reserved address; it has no public geolocation data."
    r = {"ip": ip, "sources": [], "errors": [], "proxy": None, "hosting": None, "mobile": None}
    for fn in (_prov_ipinfo, _prov_ipwho, _prov_ipapico):
        try: d, e = fn(ip)
        except Exception as ex: d, e = None, "%s: unexpected data (%s)" % (fn.__name__, type(ex).__name__)
        if e: r["errors"].append(e); continue
        r["sources"].append(d["source"])
        for k, v in d.items():
            if k != "source" and r.get(k) in (None, "") and v not in (None, ""): r[k] = v
        if r.get("asn") is not None and r.get("hostname") is not None: break
        if r.get("asn") is not None and len(r["sources"]) >= 2: break
    if not r["sources"]:
        return None, "All HTTPS lookup services failed: " + " | ".join(r["errors"])
    if not r.get("hostname"):
        try: r["hostname"] = socket.gethostbyaddr(ip)[0]
        except Exception: r["hostname"] = None
    try: fl, fe, ferrs = _prov_flags(ip)
    except Exception as ex: fl, fe, ferrs = None, "flag lookup: unexpected data (%s)" % type(ex).__name__, []
    r["errors"] += ferrs if fl else ([fe] if fe else [])
    if fl:
        r["sources"].append("%s (HTTPS, flags)" % fl["src"])
        r.update(proxy=fl["proxy"], mobile=fl["mobile"], proxy_kinds=fl["proxy_kinds"], net_type=fl["net_type"] or ("mobile carrier" if fl["mobile"] else None))
        if fl["dc"] is not None: r["provider_hosting_flag"] = fl["dc"]
        if r.get("asn") is None and fl["asn"]: r["asn"] = fl["asn"]
        if not r.get("asn_org") and fl["asn_org"]: r["asn_org"] = fl["asn_org"]
    if SETTINGS.get("allow_http_ip_api"):
        warn("UNENCRYPTED HTTP lookup enabled in Settings: ip-api.com request is readable on the network.")
        d, e = http_json("http://ip-api.com/json/%s?fields=status,proxy,hosting,mobile" % ip, 8)
        if d and d.get("status") == "success":
            if r.get("proxy") is None: r["proxy"] = d.get("proxy")
            if r.get("mobile") is None: r["mobile"] = d.get("mobile")
            if r.get("provider_hosting_flag") is None: r["provider_hosting_flag"] = d.get("hosting")
            r["sources"].append("ip-api.com (HTTP, flags only)")
        else: r["errors"].append("ip-api.com: %s" % (e or "no data"))
    prov = detect_provider(r.get("asn"), r.get("asn_org"), r.get("hostname"))
    r["network"] = prov
    if prov["provider"] != "UNKNOWN": r["hosting"] = True
    elif r.get("provider_hosting_flag") is not None: r["hosting"] = r["provider_hosting_flag"]
    r["risk"] = risk_score(r)
    return r, None

def risk_score(r):
    """NETWORK RISK HEURISTIC - transparent. Not a probability of criminal activity or of a person's intent."""
    if r.get("proxy") is None and not r.get("hosting") and r.get("hosting") is None:
        return {"score": None, "level": "UNKNOWN", "reasons": ["No proxy flag and no verified hosting/CDN ASN; no score is invented."]}
    s, why = 0, []
    if r.get("proxy") is True: s += 50; why.append("+50 provider flags proxy/VPN/Tor")
    if r.get("hosting") is True: s += 30; why.append("+30 hosting/CDN network (ASN-verified or provider flag)")
    if r.get("proxy") is False: why.append("0 provider reports no VPN/proxy/Tor")
    if r.get("hosting") is False: why.append("0 provider reports not a datacenter/hosting range")
    if r.get("mobile") is True: why.append("0 mobile network (informational; CGNAT shares IPs)")
    if r.get("proxy") is None: why.append("proxy/VPN status UNKNOWN (no provider flag available - flag service unreachable)")
    s = min(s, 100)
    return {"score": s, "level": "GREEN" if s <= 42 else "YELLOW" if s <= 60 else "RED", "reasons": why}

def yn(v): return "UNKNOWN" if v is None else ("Yes" if v else "No")

ORG_ALIASES = [("pakistan telecommunication company limited", "PTCL"), ("pakistan mobile communications limited", "Jazz"),
               ("pakistan telecom mobile limited", "Ufone"), ("telenor pakistan", "Telenor"), ("cmpak", "Zong"),
               ("china mobile pakistan", "Zong"), ("pakistan telecommunication", "PTCL")]

def pretty_org(name):
    """Display-only: fixes capitalisation of common words and adds a well-known short name when the org text matches."""
    if not name: return name
    t = re.sub(r"\b(company|limited|ltd|private|pvt|communications?|telecommunications?|telecom|mobile|pakistan|inc|llc|corporation)\b",
               lambda m: m.group(1).capitalize() if m.group(1) not in ("ltd", "pvt", "inc", "llc") else m.group(1).upper() if m.group(1) == "llc" else m.group(1).capitalize(),
               name, flags=re.I)
    low = name.lower()
    for key, short in ORG_ALIASES:
        if key in low and "(%s)" % short.lower() not in low and short.lower() not in low.split():
            return "%s (%s)" % (t, short)
    return t

def ip_show(r):
    title("IP INFORMATION")
    for k, v in [("IP", r["ip"]), ("Hostname (rDNS)", r.get("hostname") or "Unavailable"), ("Country", r.get("country") or "Unknown"),
                 ("Country Code", r.get("country_code") or "Unknown"), ("Region", r.get("region") or "Unknown"),
                 ("City", r.get("city") or "Unknown"), ("ISP", pretty_org(r.get("isp")) or "Unknown"),
                 ("Organization", pretty_org(r.get("org")) or "Unknown"),
                 ("ASN", ("AS%d" % r["asn"]) if r.get("asn") else "Unknown"), ("ASN Organization", pretty_org(r.get("asn_org")) or "Unknown"),
                 ("Latitude", r.get("lat") if r.get("lat") is not None else "Unavailable"),
                 ("Longitude", r.get("lon") if r.get("lon") is not None else "Unavailable")]:
        kv(k, v)
    if r.get("lat") is not None and r.get("lon") is not None:
        kv("Location", "%s, %s" % (r["lat"], r["lon"])); kv("Google Maps", "https://www.google.com/maps?q=%s,%s" % (r["lat"], r["lon"]))
    else: kv("Location", "Unavailable")
    n = r.get("network") or detect_provider(None, None, None)
    print()
    unl = n.get("not_listed")
    kv("Provider", ("Not a known CDN/cloud (%s)" % (pretty_org(r.get("asn_org")) or "unnamed ASN")) if unl else n["provider"])
    kv("Network Type", n["network_type"] if not unl else (str(r.get("net_type") or "UNKNOWN").upper() + " (per provider)" if r.get("net_type") else "UNKNOWN"))
    kv("Detection", n["detection"])
    for ev in n["evidence"]: print("    evidence: " + ev)
    if n["note"]: warn(n["note"])
    if n["network_type"] == "CDN / Reverse Proxy":
        warn("CDN/reverse-proxy IPs front many sites and can HIDE the website's real origin server.")
    print()
    kv("VPN / Proxy", yn(r.get("proxy")) + ((" - " + "/".join(r["proxy_kinds"])) if r.get("proxy_kinds") else "")); kv("Hosting provider", yn(r.get("hosting"))); kv("Mobile Network", yn(r.get("mobile")))
    k = r["risk"]; col = {"GREEN": "g", "YELLOW": "y", "RED": "r"}.get(k["level"], "w")
    kv("NETWORK RISK HEURISTIC", paint("%s%s" % (k["level"], "" if k["score"] is None else " (%d/100)" % k["score"]), col))
    for w in k["reasons"]: print("    - " + w)
    kv("Lookup provider(s)", ", ".join(r["sources"]))
    for e in r["errors"]: info("unavailable: " + e)
    print()
    warn("The lookup provider(s) above RECEIVED the IP you queried. HTTPS protects the request in transit; it is NOT anonymous.")
    warn("IP geolocation is APPROXIMATE and often shows an ISP hub, not the device.")
    warn("An IP cannot reveal a person's exact location, phone model, SIM, number or identity. A risk score never makes a person or organization malicious.")


def ip_menu():
    while True:
        title("[7] IP-WA-TRACE")
        print("[1] Analyze Custom IP\n[2] My Public IP (.me)\n[3] Back")
        c = ask("Choice: ")
        if c == "3": return
        ip = None
        if c == "1":
            ip = ip_valid(ask("IP address (IPv4/IPv6): "))
            if not ip: err("Invalid IP address."); pause(); continue
        elif c == "2":
            ip, e = public_ip()
            if e: err(e); pause(); continue
            ok("Discovered public IP: " + ip)
        else: continue
        r, e = ip_analyze(ip)
        if e: err(e); pause(); continue
        ip_show(r)
        if c == "2":
            print(); info("Local device information (separate from the IP lookup above):")
            device_show(brief=True)
        if confirm("\nSave IP report?"): save_report("ip", ip, r, "ip_reports")
        pause()

# ----------------------------------------------------------------- 9 device
def getprop(k):
    try:
        return subprocess.check_output(["getprop", k], stderr=subprocess.DEVNULL, timeout=3).decode().strip() or None
    except Exception:
        return None

def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]; s.close(); return ip
    except Exception:
        return "Unavailable"

def device_show(brief=False):
    if not brief: title("[9] LOCAL DEVICE INTELLIGENCE (your own device only)")
    sdk = getprop("ro.build.version.sdk")
    android = any(os.environ.get(k) for k in ("ANDROID_ROOT", "ANDROID_DATA", "TERMUX_VERSION")) or sdk
    kv("Manufacturer", getprop("ro.product.manufacturer") or "Unavailable")
    kv("Model", getprop("ro.product.model") or "Unavailable")
    kv("Android version", getprop("ro.build.version.release") or ("Unavailable" if android else "n/a (not Android)"))
    kv("Android SDK", sdk or "Unavailable")
    kv("Architecture", platform.machine()); kv("Python", platform.python_version())
    kv("OS", "%s %s" % (platform.system(), platform.release())); kv("Hostname", socket.gethostname())
    try:
        t = shutil.disk_usage(os.path.expanduser("~"))
        kv("Storage", "%.1f GB free of %.1f GB" % (t.free / 1e9, t.total / 1e9))
    except Exception:
        kv("Storage", "Unavailable")
    kv("Local network IP", local_ip())
    if "TERMUX_VERSION" in os.environ and shutil.which("termux-wifi-connectioninfo"):
        try:
            w = json.loads(subprocess.check_output(["termux-wifi-connectioninfo"], timeout=6).decode())
            kv("Wi-Fi SSID", w.get("ssid", "?")); kv("Wi-Fi state", w.get("supplicant_state", "?"))
        except Exception:
            info("Termux:API Wi-Fi info unavailable (app/permission missing).")
    elif not brief and "TERMUX_VERSION" in os.environ:
        info("Install Termux:API (app + 'pkg install termux-api') for Wi-Fi info.")
    if not brief:
        info("SIM/subscriber data is intentionally NOT collected. Nothing here relates to any remote IP.")
        pause()

# ----------------------------------------------------------------- 8 email
EMAIL_RE = re.compile(r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@([A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+)$")
PROVIDERS = {"gmail.com": "Google (Gmail)", "googlemail.com": "Google (Gmail)", "outlook.com": "Microsoft", "hotmail.com": "Microsoft",
             "live.com": "Microsoft", "yahoo.com": "Yahoo", "icloud.com": "Apple", "proton.me": "Proton", "protonmail.com": "Proton"}
MXHINT = [("google.com", "Google Workspace/Gmail"), ("outlook.com", "Microsoft 365/Outlook"), ("yahoodns", "Yahoo"),
          ("protonmail", "Proton"), ("zoho", "Zoho"), ("icloud", "Apple")]

def domain_dns(dom):
    r = {"domain": dom, "mx": [], "spf": None, "dmarc": None, "a": [], "ns": [], "errors": []}
    for key, name, typ in (("mx", dom, "MX"), ("a", dom, "A"), ("ns", dom, "NS")):
        v, e = dns_query(name, typ)
        r[key] = v
        if e: r["errors"].append("%s: %s" % (typ, e))
    txt, e = dns_query(dom, "TXT")
    r["spf"] = next((t.strip('"') for t in txt if "v=spf1" in t.lower()), None)
    dm, e2 = dns_query("_dmarc." + dom, "TXT")
    r["dmarc"] = next((t.strip('"') for t in dm if "v=dmarc1" in t.lower()), None)
    if e and "NXDOMAIN" not in e: r["errors"].append("TXT: " + e)
    return r

def provider_of(dom, mx):
    if dom.lower() in PROVIDERS: return PROVIDERS[dom.lower()]
    for h, n in MXHINT:
        if any(h in m.lower() for m in mx): return n + " (inferred from MX)"
    return "Unidentified"

def email_parse(em):
    m = EMAIL_RE.match(em.strip())
    if not m or len(em) > 254 or ".." in em or em.split("@")[0].startswith(".") or em.split("@")[0].endswith("."):
        return None
    local, dom = em.strip().rsplit("@", 1)
    return {"email": em.strip(), "local": local, "domain": dom.lower(), "ext": "." + dom.rsplit(".", 1)[-1].lower()}

def email_security(r):
    obs = []
    obs.append("MX present: mail can be received for this domain." if r["mx"] else "No MX records: domain may not receive mail.")
    if r["spf"]:
        obs.append("SPF found: " + ("strict (-all)" if "-all" in r["spf"] else "soft (~all)" if "~all" in r["spf"] else "permissive/neutral ending"))
    else: obs.append("No SPF record found.")
    if r["dmarc"]:
        m = re.search(r"p=(\w+)", r["dmarc"])
        obs.append("DMARC found, policy: %s" % (m.group(1) if m else "unspecified"))
    else: obs.append("No DMARC record found.")
    return obs

def email_show_dns(r):
    kv("MX", ("Available: " + ", ".join(r["mx"][:3])) if r["mx"] else "Not found")
    kv("SPF", ("Available: " + r["spf"][:70]) if r["spf"] else "Not found")
    kv("DMARC", ("Available: " + r["dmarc"][:70]) if r["dmarc"] else "Not found")
    kv("A records", ", ".join(r["a"][:3]) or "None"); kv("Nameservers", ", ".join(r["ns"][:3]) or "None")
    for e in r["errors"]: warn(e)

def github_public_email(em):
    d, e = http_json("https://api.github.com/search/users?q=%s+in:email&per_page=5" % urllib.parse.quote(em), 8)
    if e: return None, e
    out = []
    for it in d.get("items", []):
        out.append({"platform": "GitHub", "username": it.get("login"), "profile": it.get("html_url"),
                    "evidence": "https://api.github.com/search/users?q=%s+in:email" % urllib.parse.quote(em),
                    "description": "GitHub's public search matched this address to the user's PUBLIC profile email.",
                    "confidence": "Evidence-based (public profile email)"})
    return out, None

def email_footprint(p):
    title("PUBLIC EMAIL FOOTPRINT")
    info("Public search links - open them yourself; results are NOT checked or scraped by this tool:")
    show_links('"%s"' % p["email"])
    print(); info("Platform search links (searches only, NOT account-existence checks):")
    q = urllib.parse.quote_plus
    for n, u in [("Instagram", "https://www.google.com/search?q=site:instagram.com+" + q('"%s"' % p["email"])),
                 ("Facebook", "https://www.facebook.com/search/top?q=" + q(p["email"])),
                 ("TikTok", "https://www.google.com/search?q=site:tiktok.com+" + q('"%s"' % p["email"])),
                 ("X", "https://x.com/search?q=" + q('"%s"' % p["email"])),
                 ("LinkedIn", "https://www.google.com/search?q=site:linkedin.com+" + q('"%s"' % p["email"])),
                 ("GitHub", "https://github.com/search?q=%s&type=users" % q(p["email"])),
                 ("Reddit", "https://www.reddit.com/search/?q=" + q('"%s"' % p["email"])),
                 ("YouTube", "https://www.youtube.com/results?search_query=" + q(p["email"])),
                 ("Roblox", "https://www.google.com/search?q=site:roblox.com+" + q('"%s"' % p["email"]))]:
        kv(n, u, 12)
    print(); info("Checking GitHub's public API (public profile emails only)...")
    found, e = github_public_email(p["email"])
    results = []
    if e: warn("GitHub lookup unavailable: " + e)
    elif not found: print(paint("GitHub: NOT PUBLICLY FOUND", "y"))
    else:
        results += found
        for f in found:
            print(paint("Publicly visible result:", "g"))
            for k in ("platform", "username", "profile", "evidence", "description", "confidence"): kv(k.title(), f[k], 12)
    print()
    warn("Similar usernames elsewhere are NOT evidence. Only add an association if a public page shows both.")
    while confirm("Add a manually verified public association?"):
        results.append({"platform": ask("Platform/website: "), "username": ask("Public username: "), "profile": ask("Public profile URL: "),
                        "evidence": ask("Evidence URL: "), "description": ask("Evidence description: "),
                        "confidence": "User-reported (verify at evidence URL)"})
    if not results: print(paint("Result: NOT PUBLICLY FOUND", "y"))
    return results

def email_menu():
    while True:
        title("[8] EMAIL LOOKUP")
        print("[1] Analyze Email\n[2] Analyze Email Domain\n[3] Public Email Footprint\n[4] Email Security Checks\n[5] Back")
        c = ask("Choice: ")
        if c == "5": return
        if c not in "1234" or not c: continue
        if c == "2":
            dom = ask("Domain (e.g. example.com): ").lower()
            if not re.match(r"^[a-z0-9.-]+\.[a-z]{2,}$", dom): err("Invalid domain."); continue
            p = {"email": None, "local": None, "domain": dom, "ext": "." + dom.rsplit(".", 1)[-1]}
        else:
            p = email_parse(ask("Email address: "))
            if not p: err("Invalid email syntax."); pause(); continue
        r = domain_dns(p["domain"])
        if c in ("1", "2"):
            title("EMAIL INFORMATION")
            kv("Email", p["email"] or "(domain only)"); kv("Username", p["local"] or "-"); kv("Domain", p["domain"]); kv("Extension", p["ext"])
            kv("Syntax", "Valid"); kv("Domain DNS", "Resolves" if (r["a"] or r["mx"]) else paint("No A/MX found", "r"))
            email_show_dns(r); kv("Provider", provider_of(p["domain"], r["mx"]))
            warn("Valid syntax + valid domain does NOT prove the inbox exists.")
            data = {"parsed": p, "dns": r, "provider": provider_of(p["domain"], r["mx"])}
        elif c == "4":
            title("EMAIL SECURITY CHECKS"); email_show_dns(r)
            for o in email_security(r): print("  - " + o)
            data = {"parsed": p, "dns": r, "observations": email_security(r)}
        else:
            data = {"parsed": p, "public_associations": email_footprint(p), "source": "public web only"}
        if confirm("\nSave report?"): save_report("email", p["email"] or p["domain"], data, "email_reports")
        pause()

# ----------------------------------------------------------------- 10 settings
def settings_menu():
    while True:
        title("[10] SETTINGS")
        kv("Colors", SETTINGS["colors"]); kv("Animations", SETTINGS["animations"]); kv("Report dir", SETTINGS["report_dir"] or P("reports"))
        print("[1] Toggle colors  [2] Toggle animations  [3] Report directory  [4] Version\n[5] Dependencies  [6] Clear cache  [7] Export local database  [8] Reset settings  [9] Threat-intel keys & lookup privacy  [0] Back")
        c = ask("Choice: ")
        if c == "1": SETTINGS["colors"] = not SETTINGS["colors"]; save_settings()
        elif c == "2": SETTINGS["animations"] = not SETTINGS["animations"]; save_settings()
        elif c == "3":
            d = ask("New folder path (Enter = default): ")
            if d:
                try: os.makedirs(d, exist_ok=True)
                except OSError as e: err("Cannot use folder: %s" % e); continue
                if not os.access(d, os.W_OK): err("Folder not writable."); continue
            SETTINGS["report_dir"] = d; save_settings()
        elif c == "4": ok("%s v%s | Python %s" % (APP, VERSION, platform.python_version())); pause()
        elif c == "5": dep_menu()
        elif c == "6":
            n = 0
            for f in os.listdir(P("cache")):
                try: os.remove(P("cache", f)); n += 1
                except OSError: pass
            ok("Removed %d cache files." % n)
        elif c == "7":
            try:
                z = shutil.make_archive(os.path.join(os.path.dirname(BASE), "wa_osint_backup_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S")), "zip", BASE)
                ok("Exported: " + z)
            except Exception as e: err("Export failed: %s" % e)
            pause()
        elif c == "8":
            if confirm("Reset all settings?"):
                SETTINGS.clear(); SETTINGS.update(DEFAULTS); save_settings(); ok("Settings reset.")
        elif c == "9": keys_menu()
        elif c == "0": return

# ================================================================= v4.1 WEB SECURITY SCANNER
def api_key(name):
    return os.environ.get("WA_" + name.upper()) or SETTINGS.get(name, "") or ""

UA_WEB = {"User-Agent": "Mozilla/5.0 (compatible; WA-OSINT-PRO/%s passive-scanner)" % VERSION, "Accept": "text/html,*/*;q=0.5"}
BRANDS = ["paypal", "apple", "google", "microsoft", "amazon", "facebook", "instagram", "whatsapp", "netflix", "binance",
          "coinbase", "dhl", "fedex", "steam", "roblox", "tiktok", "icloud", "outlook", "office365", "bank"]
RISKY_TLDS = {"zip", "mov", "tk", "ml", "ga", "cf", "gq", "top", "xyz", "click", "country", "kim", "work", "support", "loan"}
KEYWORDS = ["login", "signin", "verify", "secure", "account", "update", "confirm", "wallet", "recover", "unlock", "suspend", "billing"]

def norm_target(raw):
    raw = (raw or "").strip()
    if not raw or len(raw) > 2048 or re.search(r"\s", raw): return None, None, "Invalid URL (empty, too long, or contains spaces)."
    if "://" not in raw: raw = "https://" + raw
    try: pu = urllib.parse.urlparse(raw); host = pu.hostname
    except ValueError: return None, None, "Invalid URL syntax."
    if pu.scheme not in ("http", "https"): return None, None, "Only http:// and https:// URLs are supported."
    if not host: return None, None, "URL has no host."
    try: host = host.encode("idna").decode("ascii")
    except UnicodeError: return None, None, "Host name cannot be encoded."
    if not re.match(r"^[A-Za-z0-9.-]+$|^[0-9a-fA-F:]+$", host) or host.startswith(("-", ".")): return None, None, "Invalid host name."
    return raw, pu, None

def reg_domain(host):
    p = host.split(".")
    if len(p) >= 3 and p[-2] in ("co", "com", "org", "net", "gov", "ac") and len(p[-1]) == 2: return ".".join(p[-3:])
    return ".".join(p[-2:])

def url_patterns(raw, pu, host):
    """Returns list of (points, text). Heuristic warning signs only."""
    w = []
    try: ipaddress.ip_address(host); w.append((2, "Host is a raw IP address instead of a domain name"))
    except ValueError: pass
    if "@" in (pu.netloc or ""): w.append((2, "URL contains '@' (can disguise the real destination)"))
    if "xn--" in host or any(ord(c) > 127 for c in (pu.hostname or "")): w.append((2, "Internationalized/punycode host (possible look-alike characters)"))
    if host.count(".") >= 4: w.append((1, "Many subdomain levels (%d)" % host.count(".")))
    if len(raw) > 120: w.append((1, "Very long URL (%d chars)" % len(raw)))
    if host.rsplit(".", 1)[-1].lower() in RISKY_TLDS: w.append((1, "Top-level domain frequently abused (.%s); many legitimate sites use it too" % host.rsplit(".", 1)[-1]))
    if pu.scheme == "http": w.append((1, "Plain HTTP URL (no encryption)"))
    rd = reg_domain(host); label = rd.split(".")[0]
    for b in BRANDS:
        if b in host and b != label and b not in label: w.append((2, "Brand name '%s' appears in a host that belongs to '%s'" % (b, rd))); break
    kws = [k for k in KEYWORDS if k in host or k in pu.path.lower()]
    if len(kws) >= 2: w.append((1, "Several credential-themed words in URL: " + ", ".join(kws[:4])))
    if re.search(r"-{2,}|\d{5,}", host): w.append((1, "Unusual hyphen/digit pattern in host"))
    return w

def load_feed(name, url, max_age=6 * 3600):
    """Public feed downloaded and matched LOCALLY: the scanned URL is never sent anywhere."""
    path = P("cache", name)
    try:
        if os.path.exists(path) and time.time() - os.path.getmtime(path) < max_age:
            return open(path, encoding="utf-8").read().split("\n"), None
    except OSError: pass
    try:
        req = urllib.request.Request(url, headers=UA_WEB)
        with urllib.request.urlopen(req, timeout=15) as r: body = r.read(6000000).decode("utf-8", "replace")
        if len(body) < 20 or "<html" in body[:200].lower(): return None, "feed returned unexpected content (may require an account/key now)"
        try: open(path, "w", encoding="utf-8").write(body)
        except OSError: pass
        return body.split("\n"), None
    except urllib.error.HTTPError as e: return None, "HTTP %s" % e.code
    except Exception as e: return None, "%s" % getattr(e, "reason", e)

def feed_match(lines, url, host):
    u = url.rstrip("/").lower(); exact = host_only = False
    for ln in lines:
        ln = ln.strip().rstrip("/").lower()
        if not ln.startswith("http"): continue
        if ln == u: return "exact"
        try:
            if urllib.parse.urlparse(ln).hostname == host: host_only = True
        except ValueError: pass
    return "host" if host_only else None

def tls_probe(host, port=443):
    r = {"ok": False}
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=8) as s:
            with ctx.wrap_socket(s, server_hostname=host) as ss:
                cert = ss.getpeercert(); r.update(ok=True, version=ss.version(), expires=cert["notAfter"])
                r["days_left"] = (dt.datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z") - dt.datetime.utcnow()).days
                iss = dict(x[0] for x in cert.get("issuer", ())); r["issuer"] = iss.get("organizationName", iss.get("commonName", "?"))
    except ssl.SSLCertVerificationError as e: r["error"] = "certificate verification failed: %s" % e.verify_message
    except Exception as e: r["error"] = "%s" % type(e).__name__
    return r

class _NoRedir(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None

def probe(url, timeout=8):
    """One request, redirects NOT followed. Returns (status, headers dict, error). Body is never read."""
    try:
        op = urllib.request.build_opener(_NoRedir, urllib.request.HTTPSHandler(context=ssl.create_default_context()))
        with op.open(urllib.request.Request(url, headers=UA_WEB), timeout=timeout) as r: return r.status, {k.lower(): v for k, v in r.headers.items()}, None
    except urllib.error.HTTPError as e: return e.code, {k.lower(): v for k, v in e.headers.items()}, None
    except Exception as e: return None, {}, "%s" % getattr(e, "reason", type(e).__name__)

def redirect_chain(url, limit=5):
    chain, cur, last_h = [], url, {}
    for _ in range(limit + 1):
        st, h, e = probe(cur)
        if e: chain.append((cur, None, e)); break
        chain.append((cur, st, None)); last_h = h
        if st in (301, 302, 303, 307, 308) and h.get("location"): cur = urllib.parse.urljoin(cur, h["location"])
        else: break
    return chain, last_h

def vt_lookup(url, key):
    uid = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    d, e = http_json("https://www.virustotal.com/api/v3/urls/" + uid, 10, headers={"x-apikey": key})
    if e: return None, ("not previously analysed by VirusTotal (no verdict)" if "HTTP 404" in e else e)
    st = d["data"]["attributes"]["last_analysis_stats"]; return st, None

def urlhaus_lookup(url, key):
    d, e = http_json("https://urlhaus-api.abuse.ch/v1/url/", 10, headers={"Auth-Key": key}, data={"url": url})
    if e: return None, e
    return d, None

def scan_core(raw, consent):
    """Runs passive checks, returns a scan dict. Never raises. No result is invented."""
    sc = {"scan_id": uuid.uuid4().hex[:10], "target": raw, "time": now(), "findings": [], "sources_ok": [], "sources_failed": [],
          "provider": None, "classification": "UNKNOWN", "reasons": [], "consent_external": bool(consent),
          "limitations": ["Reputation sources list only KNOWN threats; a new or unlisted site can still be dangerous.",
                          "Heuristic URL checks produce warning signs, not proof of malicious intent."]}
    pts = [0]; mal = []
    def F(check, status, detail, source="local"): sc["findings"].append({"check": check, "status": status, "detail": detail, "source": source})
    url, pu, e = norm_target(raw)
    if e: F("URL syntax", "bad", e); sc["reasons"].append(e); return sc
    host = pu.hostname.encode("idna").decode("ascii"); sc["url"] = url; sc["host"] = host
    F("URL syntax", "ok", "Valid %s URL for host %s" % (pu.scheme.upper(), host))
    for p, t in url_patterns(url, pu, host): pts[0] += p; F("Suspicious URL pattern", "warn", t)
    # local-match reputation feeds (URL never leaves the device)
    for nm, fu, label in (("openphish.txt", "https://openphish.com/feed.txt", "OpenPhish public feed (phishing)"),
                          ("urlhaus_online.txt", "https://urlhaus.abuse.ch/downloads/text_online/", "URLhaus public online-URL list (malware)")):
        lines, fe = load_feed(nm, fu)
        if fe: sc["sources_failed"].append("%s: %s" % (label, fe)); continue
        sc["sources_ok"].append(label)
        m = feed_match(lines, url, host)
        if m == "exact": mal.append("Exact URL listed in %s" % label); F("Reputation", "bad", "URL is LISTED in " + label, label)
        elif m == "host": pts[0] += 3; F("Reputation", "warn", "Host appears in %s with a different path (URL itself not listed)" % label, label)
        else: F("Reputation", "ok", "Not listed in " + label, label)
    # DNS
    ips = []
    try: ips = sorted({x[4][0] for x in socket.getaddrinfo(host, 443, proto=socket.IPPROTO_TCP)})
    except socket.gaierror as ge: F("DNS", "bad", "Does not resolve: %s" % ge)
    if ips:
        F("DNS", "ok", "Resolves to " + ", ".join(ips[:4]))
        pub = [i for i in ips if not (ipaddress.ip_address(i).is_private or ipaddress.ip_address(i).is_loopback or ipaddress.ip_address(i).is_link_local)]
        if not pub: F("DNS", "bad", "Resolves only to private/local addresses; no further network checks run"); sc["reasons"].append("Private/local target"); ips = []
    if not ips:
        _classify(sc, pts[0], mal); return sc
    if consent:
        for t in ("AAAA", "NS", "MX", "TXT"):
            v, de = dns_query(host, t)
            F("DNS " + t, "info" if not de else "n/a", (", ".join(x[:60] for x in v[:3]) or "none") if not de else de, "dns.google / resolver")
    # TLS
    if pu.scheme == "https" or True:
        t = tls_probe(host)
        if t["ok"]:
            F("TLS certificate", "ok", "Valid for host; %s; issuer %s; expires %s (%d days)" % (t["version"], t["issuer"], t["expires"], t["days_left"]))
            if t["days_left"] < 14: pts[0] += 1; F("TLS certificate", "warn", "Expires in under 14 days")
        else: pts[0] += 3; F("TLS certificate", "bad", "HTTPS unavailable or invalid: %s" % t.get("error"))
    # redirects + headers
    chain, h = redirect_chain(url)
    for i, (u, st, ce) in enumerate(chain):
        F("Redirect hop %d" % i, "info" if not ce else "n/a", "%s -> %s" % (u[:90], st if st else ce))
    if len(chain) > 1:
        a, b = urllib.parse.urlparse(chain[0][0]), urllib.parse.urlparse(chain[-1][0])
        if a.scheme == "https" and b.scheme == "http": pts[0] += 2; F("Redirect", "warn", "Redirect downgrades HTTPS to HTTP")
        if reg_domain(a.hostname or "") != reg_domain(b.hostname or ""): pts[0] += 1; F("Redirect", "warn", "Ends on a different domain: %s" % b.hostname)
        if len(chain) > 4: pts[0] += 1; F("Redirect", "warn", "Long redirect chain (%d hops)" % len(chain))
    if h:
        miss = [k for k in ("strict-transport-security", "content-security-policy", "x-frame-options", "x-content-type-options") if k not in h]
        F("Security headers", "info" if len(miss) < 3 else "warn", "Missing: %s" % (", ".join(miss) or "none"))
    # services that receive the domain / URL / IP (consent required)
    if consent:
        rd = reg_domain(host)
        if not re.match(r"^\d+\.\d+\.\d+\.\d+$", host):
            d, re_ = http_json("https://rdap.org/domain/" + rd, 10)
            if re_: sc["sources_failed"].append("RDAP: " + re_)
            else:
                ev = {x.get("eventAction"): x.get("eventDate") for x in d.get("events", [])}; reg = ev.get("registration")
                F("Domain registration (RDAP)", "info", "Registered %s, expires %s" % (reg or "n/a", ev.get("expiration", "n/a")), "rdap.org")
                try:
                    age = (dt.datetime.utcnow() - dt.datetime.strptime(reg[:10], "%Y-%m-%d")).days
                    if age < 30: pts[0] += 2; F("Domain age", "warn", "Registered only %d days ago" % age, "rdap.org")
                    elif age < 180: pts[0] += 1; F("Domain age", "warn", "Registered %d days ago (fairly new)" % age, "rdap.org")
                except Exception: pass
        r, ie = ip_analyze(ips[0])
        if r: sc["provider"] = {"ip": ips[0], "provider": r["network"]["provider"], "type": r["network"]["network_type"],
                                "detection": r["network"]["detection"], "asn": r.get("asn"), "source": ", ".join(r["sources"])}
        else: sc["sources_failed"].append("IP provider lookup: " + (ie or "failed"))
        if api_key("urlhaus_key"):
            d, ue = urlhaus_lookup(url, api_key("urlhaus_key"))
            if ue: sc["sources_failed"].append("URLhaus API: " + ue)
            else:
                sc["sources_ok"].append("URLhaus API")
                if d.get("query_status") == "ok": mal.append("URLhaus API reports this URL (%s, threat: %s)" % (d.get("url_status"), d.get("threat"))); F("Reputation", "bad", "URLhaus lists this URL: threat=%s status=%s" % (d.get("threat"), d.get("url_status")), "URLhaus API")
                else: F("Reputation", "ok", "URLhaus API: no match (%s)" % d.get("query_status"), "URLhaus API")
        if api_key("vt_key"):
            st, ve = vt_lookup(url, api_key("vt_key"))
            if ve: sc["sources_failed"].append("VirusTotal: " + ve)
            else:
                sc["sources_ok"].append("VirusTotal")
                m, s_ = st.get("malicious", 0), st.get("suspicious", 0)
                F("Reputation", "bad" if m >= 3 else "warn" if (m or s_) else "ok", "VirusTotal engines: %d malicious, %d suspicious, %d harmless" % (m, s_, st.get("harmless", 0)), "VirusTotal")
                if m >= 3: mal.append("VirusTotal: %d engines flag this URL as malicious" % m)
                elif m or s_: pts[0] += 2
    _classify(sc, pts[0], mal); return sc

def _classify(sc, pts, mal):
    sc["warning_points"] = pts
    if mal: sc["classification"] = "MALICIOUS"; sc["reasons"] = mal
    elif pts >= 2: sc["classification"] = "SUSPICIOUS"; sc["reasons"] = [f["detail"] for f in sc["findings"] if f["status"] in ("warn", "bad")]
    elif sc["sources_ok"] and any(f["check"] == "DNS" and f["status"] == "ok" for f in sc["findings"]):
        sc["classification"] = "SAFE"; sc["reasons"] = ["No known threat found in: " + ", ".join(sc["sources_ok"]) + "; no strong warning signs."]
    else:
        sc["classification"] = "UNKNOWN"; sc["reasons"] = sc["reasons"] or ["Not enough information: no reputation source completed or the target did not resolve."]
    sc["confidence"] = ("High" if sc["classification"] == "MALICIOUS" else "Low-to-moderate (%d reputation source(s) completed)" % len(sc["sources_ok"]))

CLASS_TXT = {"SAFE": "SAFE - No known threat detected by the checks performed.", "SUSPICIOUS": "SUSPICIOUS - Potential warning signs detected.",
             "MALICIOUS": "MALICIOUS - A reputable threat-intelligence source reports a known threat.", "UNKNOWN": "UNKNOWN - Insufficient information or scan unavailable."}

def scan_show(sc, brief=False):
    col = {"SAFE": "g", "SUSPICIOUS": "y", "MALICIOUS": "r", "UNKNOWN": "w"}[sc["classification"]]
    title("SCAN RESULT  " + sc["scan_id"])
    print(paint(CLASS_TXT[sc["classification"]], col)); kv("Target", sc["target"]); kv("Scan time", sc["time"])
    kv("Detection reason", "; ".join(sc["reasons"])[:300]); kv("Confidence", sc.get("confidence", "n/a"))
    if sc.get("provider"): p = sc["provider"]; kv("Hosting provider", "%s (%s) - %s" % (p["provider"], p["type"], p["detection"]))
    if not brief:
        print(); info("Evidence:")
        for f in sc["findings"]:
            c = {"ok": "g", "warn": "y", "bad": "r"}.get(f["status"], "w"); print(paint(" [%s] %s: %s" % (f["status"].upper(), f["check"], f["detail"]), c) + paint("  <%s>" % f["source"], "b"))
    kv("Sources completed", ", ".join(sc["sources_ok"]) or "none")
    for x in sc["sources_failed"]: info("source unavailable: " + x)
    if not sc["consent_external"]: info("External lookups (RDAP, VirusTotal, URLhaus API, provider) were NOT run - no consent given.")
    elif not api_key("vt_key") and not api_key("urlhaus_key"): info("No VirusTotal/URLhaus API key set (optional) - add keys in Settings > [9].")
    print(); warn("Limitations: " + " ".join(sc["limitations"])); warn("Never treat a missing detection as proof a site is completely safe.")

def scan_text(sc):
    L = ["WA-OSINT PRO %s - SCAN REPORT" % VERSION, "=" * 50, "Scan ID: " + sc["scan_id"], "Target: " + sc["target"], "Time: " + sc["time"],
         "Classification: " + CLASS_TXT[sc["classification"]], "Reason: " + "; ".join(sc["reasons"]), "Confidence: " + str(sc.get("confidence")), ""]
    if sc.get("provider"): L.append("Provider: %(provider)s | %(type)s | %(detection)s | source: %(source)s" % sc["provider"])
    L.append("Threat-intel sources completed: " + (", ".join(sc["sources_ok"]) or "none"))
    L += ["Sources unavailable: " + x for x in sc["sources_failed"]] + ["", "FINDINGS:"]
    L += ["[%s] %s: %s (source: %s)" % (f["status"].upper(), f["check"], f["detail"], f["source"]) for f in sc["findings"]]
    return "\n".join(L + ["", "LIMITATIONS:"] + ["- " + x for x in sc["limitations"]])

def history_add(sc):
    p = P("scan_reports", "history.json"); h = load_json(p, [])
    h.append({"scan_id": sc["scan_id"], "target": sc["target"], "time": sc["time"], "classification": sc["classification"]})
    save_json(p, h[-500:])

def scan_save(sc):
    base = os.path.join(out_dir("scan_reports"), "scan_%s_%s" % (sc["scan_id"], safe_name(sc.get("host") or sc["target"])))
    if os.path.exists(base + ".json") and not confirm("Report exists. Overwrite?"): return
    save_json(base + ".json", sc)
    try: open(base + ".txt", "w", encoding="utf-8").write(scan_text(sc)); ok("Saved %s.json and .txt" % base)
    except OSError as e: err("TXT export failed: %s" % e)

def ask_consent():
    info("Optional online checks send the domain/URL/IP to: rdap.org, dns.google (if needed), the IP lookup providers,")
    info("and VirusTotal / URLhaus API ONLY if you set keys. Feed checks (OpenPhish, URLhaus list) never send your URL.")
    return confirm("Allow these external lookups for this scan?")

def scanner_menu():
    title("[11] WEB SECURITY SCANNER (passive, defensive)")
    raw = ask("URL or domain (Enter = back): ")
    if not raw: return
    sc = scan_core(raw, ask_consent())
    history_add(sc); scan_show(sc)
    if confirm("\nSave JSON + TXT report?"): scan_save(sc)
    pause()

# ================================================================= v4.1 SECURE BROWSER (safe text-mode; see README)
class _Page(HTMLParser):
    def __init__(s):
        super().__init__(convert_charrefs=True); s.title = ""; s._t = False; s.skip = 0; s.text = []; s.links = []; s.forms = []; s.scripts = 0; s.iframes = 0; s.refresh = None
    def handle_starttag(s, tag, a):
        a = dict(a)
        if tag == "title": s._t = True
        elif tag in ("script", "style"): s.skip += 1; s.scripts += tag == "script"
        elif tag == "a" and a.get("href"): s.links.append(a["href"])
        elif tag == "form": s.forms.append({"action": a.get("action", ""), "password": False})
        elif tag == "input" and a.get("type", "").lower() == "password" and s.forms: s.forms[-1]["password"] = True
        elif tag == "iframe": s.iframes += 1
        elif tag == "meta" and a.get("http-equiv", "").lower() == "refresh": s.refresh = a.get("content")
    def handle_endtag(s, tag):
        if tag == "title": s._t = False
        elif tag in ("script", "style") and s.skip: s.skip -= 1
    def handle_data(s, d):
        if s._t: s.title += d
        elif not s.skip and d.strip(): s.text.append(d.strip())

def safe_fetch(url, allow_http=False):
    """Fetches ONE page as inert text. JS is never executed, cookies not stored, downloads refused, TLS errors never bypassed."""
    cur = url
    for _ in range(6):
        pu = urllib.parse.urlparse(cur)
        if pu.scheme == "http" and not allow_http: return None, "Blocked: plain HTTP is disabled (unencrypted)."
        if pu.scheme not in ("http", "https"): return None, "Blocked: unsupported scheme %s" % pu.scheme
        try:
            op = urllib.request.build_opener(_NoRedir, urllib.request.HTTPSHandler(context=ssl.create_default_context()))
            r = op.open(urllib.request.Request(cur, headers=UA_WEB), timeout=10)
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308) and e.headers.get("Location"): cur = urllib.parse.urljoin(cur, e.headers["Location"]); continue
            return None, "HTTP error %s" % e.code
        except ssl.SSLError as e: return None, "Blocked: TLS problem (%s). Certificate errors are never bypassed." % e
        except Exception as e:
            if "CERTIFICATE" in str(e).upper(): return None, "Blocked: TLS certificate invalid. Never bypassed."
            return None, "Cannot open page: %s" % getattr(e, "reason", e)
        ct = r.headers.get("Content-Type", "").lower()
        if "attachment" in r.headers.get("Content-Disposition", "").lower() or not (ct.startswith("text/html") or ct.startswith("text/plain")):
            r.close(); return None, "Download blocked: content type '%s' is not a web page." % (ct or "unknown")
        body = r.read(1000000).decode("utf-8", "replace"); r.close(); return {"url": cur, "body": body, "ct": ct}, None
    return None, "Too many redirects."

def page_show(res):
    pg = _Page()
    try: pg.feed(res["body"])
    except Exception: pass
    https = res["url"].startswith("https://")
    kv("Connection", paint("HTTPS (certificate verified)", "g") if https else paint("NOT ENCRYPTED", "r")); kv("Address", res["url"]); kv("Title", pg.title.strip()[:100] or "(none)")
    kv("Scripts (NOT executed)", pg.scripts); kv("iframes (not loaded)", pg.iframes)
    pw = [f for f in pg.forms if f["password"]]
    if pw: warn("This page has %d password form(s). Only enter credentials at addresses you fully trust." % len(pw))
    if pg.refresh: warn("Page requests an automatic redirect: " + pg.refresh[:100])
    print(paint("-" * 58, "b")); print(" ".join(pg.text)[:1500] or "(no readable text)")
    return pg

def open_external(url):
    if shutil.which("termux-open-url"): cmd = ["termux-open-url", url]
    elif shutil.which("am"): cmd = ["am", "start", "-a", "android.intent.action.VIEW", "-d", url]
    else:
        import webbrowser; webbrowser.open(url); return True
    try: subprocess.run(cmd, timeout=8, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return True
    except Exception as e: err("Could not launch browser: %s" % e); return False

def browser_menu():
    title("[12] SECURE BROWSER")
    info("Real Android WebView is not available from Pydroid/Termux scripts. This mode loads pages as inert text:")
    info("no JavaScript, no downloads, no cookies, no file access, TLS errors never bypassed.")
    hist, idx, last_scan, cur = [], -1, None, None
    def load(url):
        nonlocal last_scan, cur
        url, pu, e = norm_target(url)
        if e: err(e); return False
        if confirm("Run a security scan before opening?"):
            last_scan = scan_core(url, ask_consent()); history_add(last_scan); scan_show(last_scan, brief=True)
            if last_scan["classification"] == "MALICIOUS": err("BLOCKED: known threat reported. Navigation refused: " + "; ".join(last_scan["reasons"])[:200]); return False
            if last_scan["classification"] == "SUSPICIOUS" and not confirm("WARNING: suspicious signs found. Open anyway?"): return False
        allow = False
        if pu.scheme == "http": allow = confirm("This is plain HTTP (unencrypted). Open anyway?")
        res, e = safe_fetch(url, allow)
        if e: err(e); return False
        cur = page_show(res); cur.url = res["url"]; return res["url"]
    while True:
        c = ask("\n[o]pen [b]ack [f]orward [r]eload [s]can [l]inks [x]system-browser [q]uit: ").lower()
        if c == "q": return
        elif c == "o":
            u = load(ask("URL: "))
            if u: hist = hist[:idx + 1] + [u]; idx = len(hist) - 1
        elif c == "b" and idx > 0: idx -= 1; load(hist[idx])
        elif c == "f" and idx < len(hist) - 1: idx += 1; load(hist[idx])
        elif c == "r" and idx >= 0: load(hist[idx])
        elif c == "s" and idx >= 0:
            sc = scan_core(hist[idx], ask_consent()); history_add(sc); scan_show(sc)
        elif c == "l" and cur:
            for i, l in enumerate(cur.links[:25], 1): print("%2d) %s" % (i, urllib.parse.urljoin(hist[idx], l)[:100]))
        elif c == "x" and idx >= 0:
            sc = scan_core(hist[idx], False)
            if sc["classification"] == "MALICIOUS": err("Refused: listed as malicious.")
            elif confirm("This leaves safe mode (the system browser runs JavaScript). Continue?"): open_external(hist[idx])
        else: warn("Nothing to do (open a page first, or invalid key).")

# ================================================================= v4.1 THREAT INTELLIGENCE DASHBOARD
def dashboard_menu():
    while True:
        title("[13] THREAT INTELLIGENCE DASHBOARD")
        h = load_json(P("scan_reports", "history.json"), [])
        cnt = lambda k: sum(1 for x in h if x.get("classification") == k)
        kv("Total URLs checked", len(h)); kv("Known malicious matches", paint(str(cnt("MALICIOUS")), "r")); kv("Suspicious", paint(str(cnt("SUSPICIOUS")), "y"))
        kv("Safe results", paint(str(cnt("SAFE")), "g")); kv("Unknown", cnt("UNKNOWN"))
        print(); info("Recent scans:")
        for x in h[-10:][::-1]: print("  %s  %-10s %-11s %s" % (x["time"], x["scan_id"], x["classification"], x["target"][:40]))
        if not h: print("  (no scans yet)")
        c = ask("\n[1] Clear history  [0] Back: ")
        if c == "1" and confirm("Delete scan history?"): save_json(P("scan_reports", "history.json"), []); ok("Cleared.")
        elif c == "0": return

def keys_menu():
    title("THREAT-INTEL KEYS & LOOKUP PRIVACY")
    mask = lambda k: ("set (%s...)" % k[:3]) if k else "not set"
    kv("VirusTotal key", mask(SETTINGS.get("vt_key", ""))); kv("URLhaus Auth-Key", mask(SETTINGS.get("urlhaus_key", ""))); kv("Allow HTTP ip-api", SETTINGS.get("allow_http_ip_api"))
    info("Keys are optional, stored only in your local settings.json (or env WA_VT_KEY / WA_URLHAUS_KEY). Never hardcoded.")
    print("[1] Set VirusTotal key  [2] Set URLhaus key  [3] Toggle unencrypted ip-api (adds VPN/proxy flags)  [4] Remove keys  [0] Back")
    c = ask("Choice: ")
    if c == "1": SETTINGS["vt_key"] = ask("VirusTotal API key: ")
    elif c == "2": SETTINGS["urlhaus_key"] = ask("URLhaus Auth-Key: ")
    elif c == "3":
        if not SETTINGS.get("allow_http_ip_api") and not confirm("This sends IP lookups over UNENCRYPTED HTTP. Enable?"): return
        SETTINGS["allow_http_ip_api"] = not SETTINGS.get("allow_http_ip_api")
    elif c == "4": SETTINGS["vt_key"] = SETTINGS["urlhaus_key"] = ""
    save_settings()


# ================================================================= v7.0 COMMON HELPERS
CASE_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")
def esc(s): return htmllib.escape("" if s is None else str(s))
def sha256_text(t): return hashlib.sha256(t.encode("utf-8")).hexdigest()
def ts(t): return dt.datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M:%S")
def human(n):
    n = float(n)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB": return ("%d B" % n) if u == "B" else "%.1f %s" % (n, u)
        n /= 1024.0

def valid_domain(d):
    d = (d or "").strip().lower().rstrip(".")
    try: d = d.encode("idna").decode("ascii")
    except UnicodeError: return None
    return d if re.match(r"^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$", d) else None

def http_text(url, timeout=10, headers=None, maxbytes=3000000):
    try:
        h = dict(UA_WEB); h.update(headers or {})
        with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout) as r:
            return r.read(maxbytes).decode("utf-8", "replace"), None
    except urllib.error.HTTPError as e: return None, "Rate limit (HTTP 429)" if e.code == 429 else "HTTP %s" % e.code
    except urllib.error.URLError as e: return None, "Network error: %s" % getattr(e, "reason", e)
    except socket.timeout: return None, "Request timed out."
    except Exception as e: return None, "Unexpected error: %s" % e

def http_status(url, timeout=8, headers=None):
    """(status, final_url, body_snippet, error). TLS verified; no login/CAPTCHA handling."""
    try:
        h = dict(UA_WEB); h.update(headers or {})
        with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout) as r:
            return r.status, r.geturl(), r.read(20000).decode("utf-8", "replace"), None
    except urllib.error.HTTPError as e: return e.code, url, "", None
    except urllib.error.URLError as e: return None, url, "", "Network error: %s" % getattr(e, "reason", e)
    except socket.timeout: return None, url, "", "Request timed out."
    except Exception as e: return None, url, "", "Unexpected error: %s" % e

def consent_to(what):
    info("Information sent to third parties for this action: " + what)
    return confirm("Allow this?")

def pick_file(prompt="File path (or a folder to browse): "):
    p = ask(prompt).strip().strip('"').strip("'")
    if not p: return None
    p = os.path.expanduser(p)
    if os.path.isdir(p):
        try: names = sorted(f for f in os.listdir(p) if os.path.isfile(os.path.join(p, f)))[:40]
        except OSError as e: err("Cannot read folder: %s" % e); return None
        if not names: warn("No files in that folder."); return None
        for i, n in enumerate(names, 1): print("%2d) %s" % (i, n))
        c = ask("Number: ")
        if not c.isdigit() or not (0 < int(c) <= len(names)): err("Invalid choice."); return None
        p = os.path.join(p, names[int(c) - 1])
    if not os.path.isfile(p): err("File not found: %s" % p); return None
    if not os.access(p, os.R_OK): err("Permission denied (grant storage permission to Pydroid/Termux)."); return None
    return p

def hash_file(path, algos=("md5", "sha1", "sha256"), progress=False):
    """Chunked reading (1 MB). The file is only READ, never executed."""
    hs = {a: hashlib.new(a) for a in algos}; size = os.path.getsize(path); done = 0
    with open(path, "rb") as f:
        while True:
            b = f.read(1048576)
            if not b: break
            for h in hs.values(): h.update(b)
            done += len(b)
            if progress and size > 50e6 and sys.stdout.isatty(): sys.stdout.write("\r  hashing %3d%%" % (done * 100 // max(size, 1))); sys.stdout.flush()
    if progress and size > 50e6: print()
    return {a: h.hexdigest() for a, h in hs.items()}

# ================================================================= v7.0 HTML REPORTS
def esc_link(s):
    s = "" if s is None else str(s)
    return '<a href="%s" rel="noopener noreferrer">%s</a>' % (esc(s), esc(s)) if re.match(r"^https?://", s) else esc(s)

def html_render(rep):
    cls = rep.get("classification") or "N/A"
    col = {"MALICIOUS": "#c0392b", "SUSPICIOUS": "#b9770e", "SAFE": "#1e8449", "UNKNOWN": "#566573"}.get(cls.split()[0].upper(), "#2c3e50")
    fr = "".join("<tr><td>%s</td><td><span class='st'>%s</span></td><td>%s</td><td>%s</td></tr>" % (
        esc(f.get("check") or f.get("label")), esc(str(f.get("status", "info")).upper()), esc(f.get("detail")), esc_link(f.get("source"))) for f in rep.get("findings", [])) or "<tr><td colspan=4>No findings recorded.</td></tr>"
    ev = ""
    if rep.get("evidence"):
        ev = "<h2>Evidence</h2><table><tr><th>Time</th><th>Type</th><th>Note</th><th>Source</th><th>SHA-256</th></tr>%s</table>" % "".join(
            "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td class='mono'>%s</td></tr>" % (esc(e.get("time")), esc(e.get("kind")), esc(e.get("note")), esc_link(e.get("source_url")), esc(e.get("sha256"))) for e in rep["evidence"])
    src = "".join("<li>%s</li>" % esc_link(u) for u in rep.get("sources", []) if u) or "<li>None recorded</li>"
    tech = "".join("<tr><td>%s</td><td class='mono'>%s</td></tr>" % (esc(k), esc(json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v)) for k, v in (rep.get("technical") or {}).items())
    lim = ["Generated locally by %s %s from publicly available information; nothing was uploaded by this report." % (APP, VERSION),
           "Findings are indicators, not proof about any person or organization. IP geolocation is approximate. 'Not found' does not mean 'does not exist'.",
           "Search-result items are UNVERIFIED until confirmed at the source URL. A reputation match concerns an indicator (IP/domain/URL/file), never a person."] + list(rep.get("limitations", []))
    return """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>%(t)s - WA-OSINT PRO</title><style>
body{font-family:Arial,Helvetica,sans-serif;margin:0;background:#f4f6f8;color:#1b2631}
header{background:#0b2545;color:#fff;padding:18px 22px}header h1{margin:0;font-size:20px;letter-spacing:1px}header p{margin:4px 0 0;color:#9fb3c8;font-size:13px}
main{padding:18px 22px;max-width:980px;margin:auto}h2{border-bottom:2px solid #0b2545;padding-bottom:4px;margin-top:26px;font-size:17px}
table{width:100%%;border-collapse:collapse;background:#fff;font-size:13px}th,td{border:1px solid #d5d8dc;padding:6px 8px;text-align:left;vertical-align:top;word-break:break-word}th{background:#e8edf3}
.badge{display:inline-block;padding:6px 14px;border-radius:4px;color:#fff;font-weight:bold;background:%(c)s}.st{font-weight:bold;font-size:11px}
.mono{font-family:monospace;font-size:12px}.meta td:first-child{width:28%%;font-weight:bold;background:#f0f3f6}footer{font-size:12px;color:#566573}li{margin:3px 0}</style></head><body>
<header><h1>WA-OSINT PRO v%(v)s</h1><p>Investigation report</p></header><main>
<table class="meta"><tr><td>Case ID</td><td>%(case)s</td></tr><tr><td>Report title</td><td>%(t)s</td></tr><tr><td>Investigation date/time</td><td>%(time)s</td></tr><tr><td>Target</td><td>%(target)s</td></tr><tr><td>Risk classification</td><td><span class="badge">%(cls)s</span></td></tr></table>
<h2>Findings</h2><table><tr><th>Check</th><th>Status</th><th>Detail</th><th>Source</th></tr>%(fr)s</table>%(ev)s
<h2>Source URLs</h2><ul>%(src)s</ul><h2>Technical details</h2><table class="meta">%(tech)s</table>
<h2>Limitations &amp; disclaimers</h2><footer><ul>%(lim)s</ul></footer></main></body></html>""" % dict(
        t=esc(rep.get("title")), c=col, v=VERSION, case=esc(rep.get("case_id") or "N/A"), time=esc(rep.get("time") or now()), target=esc(rep.get("target")),
        cls=esc(cls), fr=fr, ev=ev, src=src, tech=tech or "<tr><td colspan=2>None</td></tr>", lim="".join("<li>%s</li>" % esc(x) for x in lim))

def html_save(rep):
    base = os.path.join(out_dir("html_reports"), "report_%s_%s" % (safe_name(rep.get("title", "report")), dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    path, n = base + ".html", 1
    while os.path.exists(path): n += 1; path = "%s_%d.html" % (base, n)
    try:
        with open(path, "w", encoding="utf-8") as f: f.write(html_render(rep))
        ok("HTML report saved (works offline): " + path); return path
    except OSError as e: err("Could not save HTML report: %s" % e)

def offer_outputs(title_, target, classification, findings, sources=None, technical=None, limitations=None):
    """Common end step: Evidence Vault / offline HTML / JSON. Nothing is uploaded."""
    rep = {"title": title_, "target": target, "classification": classification, "findings": findings, "sources": sources or [],
           "technical": technical or {}, "limitations": limitations or [], "time": now()}
    c = ask("\n[v] Evidence Vault  [h] HTML report  [j] JSON report  [Enter] skip: ").lower()
    if c == "v":
        cid = ask("Case ID (letters/digits/-/_): ")
        if vault_valid(cid): vault_add(cid, "finding", json.dumps(rep, ensure_ascii=False), ", ".join((sources or [])[:3]), "%s - %s" % (title_, target))
    elif c == "h":
        cid = ask("Case ID for the report (Enter = none): ")
        if cid and not vault_valid(cid): return
        rep["case_id"] = cid or None; html_save(rep)
    elif c == "j": save_report("analysis", target, rep, "reports")

# ================================================================= v7.0 EVIDENCE VAULT
def vault_path(cid): return P("evidence_vault", cid + ".json")
def vault_valid(cid):
    if CASE_RE.match(cid or ""): return True
    err("Case ID must be 1-40 characters: letters, digits, - or _"); return False
def vault_load(cid):
    c = load_json(vault_path(cid), {}); return c if c and isinstance(c.get("items"), list) else None
def item_hash(it):
    b = {k: it.get(k) for k in ("time", "kind", "note", "source_url", "content")}; b["file_sha256"] = (it.get("file") or {}).get("sha256")
    return sha256_text(json.dumps(b, sort_keys=True, ensure_ascii=False))

def vault_add(cid, kind, content, source_url="", note="", file_info=None):
    c = vault_load(cid) or {"case_id": cid, "title": cid, "created": now(), "items": []}
    it = {"id": max([i.get("id", 0) for i in c["items"]] or [0]) + 1, "time": now(), "kind": kind, "note": note, "source_url": source_url, "content": content, "file": file_info}
    it["sha256"] = item_hash(it); c["items"].append(it)
    if save_json(vault_path(cid), c): ok("Evidence #%d stored locally in case %s (SHA-256 %s...)" % (it["id"], cid, it["sha256"][:16])); return it

def vault_verify(c):
    res = []
    for it in c["items"]:
        st = "OK" if item_hash(it) == it.get("sha256") else "MODIFIED (record hash mismatch)"
        f = it.get("file")
        if f and st == "OK":
            if not os.path.isfile(f.get("path", "")): st = "FILE MISSING (record intact)"
            else:
                try:
                    if hash_file(f["path"], ("sha256",))["sha256"] != f.get("sha256"): st = "FILE CHANGED since it was recorded"
                except OSError as e: st = "FILE UNREADABLE (%s)" % e
        res.append((it["id"], st))
    return res

def vault_report(c):
    return {"title": "Evidence Vault - " + c.get("title", c["case_id"]), "case_id": c["case_id"], "target": c["case_id"], "classification": "N/A (evidence log)", "time": now(),
            "findings": [{"check": "#%d %s" % (i["id"], i["kind"]), "status": "info", "detail": (i.get("note") or i["content"])[:300], "source": i.get("source_url")} for i in c["items"]],
            "evidence": [{"time": i["time"], "kind": i["kind"], "note": i.get("note"), "source_url": i.get("source_url"), "sha256": i["sha256"]} for i in c["items"]],
            "sources": [i["source_url"] for i in c["items"] if i.get("source_url")], "technical": {"case created": c["created"], "items": len(c["items"]), "verification": dict((str(a), b) for a, b in vault_verify(c))}}

def vault_menu():
    while True:
        title("[17] EVIDENCE VAULT (local only)")
        print("[1] Add note  [2] Add source URL  [3] Add file evidence (hash)  [4] View case  [5] Verify integrity\n[6] Export case (JSON + HTML)  [7] Delete item/case  [8] List cases  [0] Back")
        c = ask("Choice: ")
        if c == "0": return
        if c == "8":
            names = sorted(f[:-5] for f in os.listdir(P("evidence_vault")) if f.endswith(".json"))
            for n in names: print(" - " + n)
            if not names: warn("No cases yet.")
            continue
        if c not in "1234567" or not c: continue
        cid = ask("Case ID: ")
        if not vault_valid(cid): continue
        if c == "1":
            t = ask("Investigation note: ")
            if t: vault_add(cid, "note", t)
        elif c == "2":
            u = ask("Source URL: ")
            if not re.match(r"^https?://", u): err("URL must start with http:// or https://"); continue
            vault_add(cid, "source_url", u, u, ask("Description: "))
        elif c == "3":
            p = pick_file()
            if p:
                try: h = hash_file(p, ("sha256",), True)["sha256"]
                except OSError as e: err("Cannot read file: %s" % e); continue
                vault_add(cid, "file", "file:" + os.path.basename(p), "", ask("Note: "), {"path": os.path.abspath(p), "size": os.path.getsize(p), "sha256": h})
        else:
            case = vault_load(cid)
            if not case: err("Case not found (or file damaged)."); continue
            if c == "4":
                for i in case["items"]: print("#%d [%s] %s\n    %s\n    note: %s | source: %s\n    SHA-256: %s" % (i["id"], i["kind"], i["time"], i["content"][:120], i.get("note") or "-", i.get("source_url") or "-", i["sha256"]))
                if not case["items"]: warn("Case has no items.")
            elif c == "5":
                for a, b in vault_verify(case): print(paint("  #%s: %s" % (a, b), "g" if b == "OK" else "r"))
            elif c == "6":
                base = os.path.join(out_dir("exports"), "case_%s_%s" % (cid, dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
                save_json(base + ".json", case); rep = vault_report(case)
                try: open(base + ".html", "w", encoding="utf-8").write(html_render(rep)); ok("Exported %s.json and .html" % base)
                except OSError as e: err("HTML export failed: %s" % e)
            elif c == "7":
                n = ask("Item number to delete (Enter = whole case): ")
                if n.isdigit():
                    if confirm("Delete item #%s?" % n):
                        case["items"] = [i for i in case["items"] if str(i["id"]) != n]; save_json(vault_path(cid), case); ok("Deleted.")
                elif not n and confirm("Delete the ENTIRE case %s? This cannot be undone." % cid):
                    try: os.remove(vault_path(cid)); ok("Case deleted.")
                    except OSError as e: err(str(e))
        pause()

# ================================================================= v7.0 DNS INTELLIGENCE
def txt_clean(t): return re.sub(r'"\s*"', "", t).strip().strip('"')
def spf_analyze(txts):
    recs = [txt_clean(t) for t in txts if txt_clean(t).lower().startswith("v=spf1")]
    R = {"record": recs[0] if recs else None, "issues": [], "lookups": 0}
    if not recs: R["issues"].append("No SPF record found."); return R
    if len(recs) > 1: R["issues"].append("Multiple SPF records (invalid; receivers may ignore SPF).")
    toks = recs[0].split()[1:]
    R["lookups"] = sum(1 for t in toks if re.match(r"^[+\-~?]?(include:|a\b|mx\b|ptr\b|exists:|redirect=)", t, re.I))
    if R["lookups"] > 10: R["issues"].append("%d DNS-lookup mechanisms (limit is 10; may cause permerror). Nested includes not counted." % R["lookups"])
    if any(re.match(r"^[+\-~?]?ptr\b", t, re.I) for t in toks): R["issues"].append("Uses deprecated 'ptr' mechanism.")
    al = [t for t in toks if re.match(r"^[+\-~?]?all$", t, re.I)]
    if not al and not any(t.lower().startswith("redirect=") for t in toks): R["issues"].append("No 'all' or redirect= ending.")
    elif al: R["issues"].append({"-all": "Policy: strict (-all).", "~all": "Policy: soft fail (~all).", "?all": "Policy: neutral (?all) - weak.", "+all": "DANGEROUS: +all permits any sender.", "all": "DANGEROUS: bare 'all' permits any sender."}[al[-1].lower()])
    return R
def dmarc_analyze(txts):
    recs = [txt_clean(t) for t in txts if txt_clean(t).lower().startswith("v=dmarc1")]
    R = {"record": recs[0] if recs else None, "tags": {}, "issues": []}
    if not recs: R["issues"].append("No DMARC record found."); return R
    for part in recs[0].split(";"):
        if "=" in part: k, v = part.split("=", 1); R["tags"][k.strip().lower()] = v.strip()
    t = R["tags"]; p = t.get("p", "").lower()
    R["issues"].append({"none": "p=none: monitoring only, spoofed mail is not blocked.", "quarantine": "p=quarantine: suspicious mail goes to spam.", "reject": "p=reject: strongest policy."}.get(p, "Missing/invalid p= policy."))
    if "rua" not in t: R["issues"].append("No rua= aggregate-report address.")
    if t.get("pct", "100") != "100": R["issues"].append("pct=%s: policy applies to only part of mail." % t.get("pct"))
    return R
def dkim_check(domain, selector):
    if not re.match(r"^[A-Za-z0-9._-]{1,63}$", selector or ""): return {"selector": selector, "status": "invalid selector"}
    v, e = dns_query("%s._domainkey.%s" % (selector, domain), "TXT")
    if e: return {"selector": selector, "status": "DNS error: " + e}
    rec = txt_clean(" ".join(v)) if v else ""
    if not rec: return {"selector": selector, "status": "NOT FOUND at %s._domainkey.%s" % (selector, domain)}
    tags = {}
    for part in rec.split(";"):
        if "=" in part: k, x = part.split("=", 1); tags[k.strip().lower()] = x.strip().replace(" ", "")
    pk = tags.get("p", ""); R = {"selector": selector, "tags": {k: (x[:30] + "...") if len(x) > 30 else x for k, x in tags.items()}}
    if not pk: R["status"] = "REVOKED (empty p= key)"
    else:
        R["status"] = "FOUND"
        if tags.get("k", "rsa").lower() == "rsa":
            try:
                n = len(base64.b64decode(pk + "=" * (-len(pk) % 4)))
                R["key_estimate"] = "~1024-bit or less (weak)" if n < 200 else "~2048-bit" if n < 400 else "3072-bit or larger"
            except Exception: R["key_estimate"] = "could not decode key"
    return R
def dnssec_status(domain):
    d, e = http_json("https://dns.google/resolve?name=%s&type=A&do=1" % urllib.parse.quote(domain), 8)
    if e or not isinstance(d, dict): return "UNKNOWN (%s)" % (e or "bad response")
    ds, _ = dns_query(domain, "DS")
    if d.get("AD") is True: return "SIGNED and validated (resolver reported authenticated data)"
    return "DS record present but answer not validated (possible misconfiguration)" if ds else "Not signed (no DS record found) or not validated"

def dns_target(raw):
    raw = (raw or "").strip()
    try: ip = ipaddress.ip_address(raw); return ("ip", str(ip))
    except ValueError: pass
    d = valid_domain(raw); return ("domain", d) if d else (None, None)

def dns_lookup(kind, target, types=None):
    res = {}
    for t in (types or (["PTR"] if kind == "ip" else ["A", "AAAA", "CNAME", "MX", "NS", "SOA", "TXT"])):
        name = ipaddress.ip_address(target).reverse_pointer if kind == "ip" else target
        v, e = dns_query(name, t); res[t] = {"records": v, "error": e}
    return res

def dns_history_add(target, res):
    p = P("dns_history", "history.json"); h = load_json(p, [])
    prev = next((x for x in reversed(h) if x["target"] == target), None)
    h.append({"time": now(), "target": target, "results": {k: v["records"] for k, v in res.items()}}); save_json(p, h[-300:]); return prev
def dns_diff(prev, res):
    out = []
    for t in sorted(set(prev["results"]) | set(res)):
        a, b = set(prev["results"].get(t, [])), set(r for r in res.get(t, {}).get("records", []))
        out += ["  + %s %s" % (t, x) for x in sorted(b - a)] + ["  - %s %s" % (t, x) for x in sorted(a - b)]
    return out

def dns_export(target, res, analysis):
    base = os.path.join(out_dir("exports"), "dns_%s_%s" % (safe_name(target), dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    save_json(base + ".json", {"target": target, "time": now(), "records": res, "analysis": analysis})
    try:
        with open(base + ".txt", "w", encoding="utf-8") as f:
            f.write("DNS lookup %s (%s)\n" % (target, now()))
            for t, v in res.items(): f.write("\n[%s] %s\n" % (t, v["error"] or "")); f.writelines("  %s\n" % r for r in v["records"])
        with open(base + ".csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(["target", "type", "record"])
            for t, v in res.items():
                for r in v["records"]: w.writerow([target, t, r])
        ok("Exported %s.json/.txt/.csv" % base)
    except OSError as e: err("Export failed: %s" % e)

def dns_menu():
    while True:
        title("[16] DNS INTELLIGENCE")
        info("Queries go to your resolver (dnspython) or to Google DNS-over-HTTPS (dns.google) if dnspython is missing; DNSSEC checks always use dns.google.")
        print("[1] Full lookup (A AAAA CNAME MX NS SOA TXT / PTR for an IP)  [2] SPF/DMARC/DKIM  [3] DNSSEC  [4] History  [0] Back")
        c = ask("Choice: ")
        if c == "0": return
        if c == "4":
            for x in load_json(P("dns_history", "history.json"), [])[-15:][::-1]: print("  %s  %s  (%d record types)" % (x["time"], x["target"], len(x["results"])))
            pause(); continue
        if c not in ("1", "2", "3"): continue
        kind, tgt = dns_target(ask("Domain (or IP for PTR): "))
        if not kind: err("Invalid domain or IP address."); pause(); continue
        analysis, findings = {}, []
        if c == "1":
            res = dns_lookup(kind, tgt)
            for t, v in res.items():
                print(paint("[%s]" % t, "y") + (paint(" " + v["error"], "r") if v["error"] else ""))
                for r in v["records"]: print("   " + r[:110]); findings.append({"check": "DNS " + t, "status": "info", "detail": r[:200], "source": "DNS resolver"})
            prev = dns_history_add(tgt, res)
            if prev: d = dns_diff(prev, res); info("Changes since %s:" % prev["time"]); print("\n".join(d) if d else "  no changes")
            else: info("First lookup of this target stored in local history.")
            if kind == "domain":
                txt = res["TXT"]["records"]; dm, _ = dns_query("_dmarc." + tgt, "TXT")
                analysis = {"spf": spf_analyze(txt), "dmarc": dmarc_analyze(dm)}
                print(); info("SPF: " + (analysis["spf"]["record"] or "none")); [print("   - " + i) for i in analysis["spf"]["issues"]]
                info("DMARC: " + (analysis["dmarc"]["record"] or "none")); [print("   - " + i) for i in analysis["dmarc"]["issues"]]
                findings += [{"check": "SPF", "status": "info", "detail": "; ".join(analysis["spf"]["issues"]), "source": "DNS"}, {"check": "DMARC", "status": "info", "detail": "; ".join(analysis["dmarc"]["issues"]), "source": "DNS"}]
            if confirm("Export JSON/TXT/CSV?"): dns_export(tgt, res, analysis)
        elif kind == "ip": err("This needs a domain."); pause(); continue
        elif c == "2":
            res = dns_lookup("domain", tgt, ["TXT"]); dm, _ = dns_query("_dmarc." + tgt, "TXT")
            sp, dmr = spf_analyze(res["TXT"]["records"]), dmarc_analyze(dm); print(); info("SPF: " + (sp["record"] or "none")); [print("   - " + i) for i in sp["issues"]]
            info("DMARC: " + (dmr["record"] or "none")); [print("   - " + i) for i in dmr["issues"]]
            dk = []
            for sel in [s.strip() for s in ask("DKIM selector(s), comma separated (Enter = skip): ").split(",") if s.strip()]:
                r = dkim_check(tgt, sel); dk.append(r); print("   DKIM %s: %s %s" % (sel, r["status"], r.get("key_estimate", "")))
            analysis = {"spf": sp, "dmarc": dmr, "dkim": dk}
            findings = [{"check": "SPF", "status": "info", "detail": "; ".join(sp["issues"]), "source": "DNS"}, {"check": "DMARC", "status": "info", "detail": "; ".join(dmr["issues"]), "source": "DNS"}] + [{"check": "DKIM " + r["selector"], "status": "info", "detail": r["status"], "source": "DNS"} for r in dk]
            res = {}
        else:
            s_ = dnssec_status(tgt); kv("DNSSEC", s_); findings = [{"check": "DNSSEC", "status": "info", "detail": s_, "source": "dns.google"}]
        offer_outputs("DNS Intelligence", tgt, "N/A", findings, [], analysis)
        pause()

# ================================================================= v7.0 THREAT INTELLIGENCE CENTER
TI_FEEDS = {
    "urlhaus": ("urlhaus_online.txt", "https://urlhaus.abuse.ch/downloads/text_online/", "URLhaus (online malware URLs)"),
    "openphish": ("openphish.txt", "https://openphish.com/feed.txt", "OpenPhish (phishing URLs)"),
    "feodo": ("feodo_ips.txt", "https://feodotracker.abuse.ch/downloads/ipblocklist.txt", "Feodo Tracker (botnet C2 IPs)"),
    "drop": ("spamhaus_drop.txt", "https://www.spamhaus.org/drop/drop.txt", "Spamhaus DROP (hijacked/criminal netblocks)"),
    "tor": ("tor_exit.txt", "https://check.torproject.org/torbulkexitlist", "Tor exit-node list (privacy network, informational only)")}
_FEEDMEM = {}
def ti_feed(key):
    if key not in _FEEDMEM:
        fn, url, label = TI_FEEDS[key]; lines, e = load_feed(fn, url); t = None
        try: t = ts(os.path.getmtime(P("cache", fn)))
        except OSError: pass
        _FEEDMEM[key] = (lines, e, t)
    return _FEEDMEM[key]

def ti_type(x):
    x = (x or "").strip()
    try: ipaddress.ip_address(x); return "ip"
    except ValueError: pass
    if "://" in x or "/" in x: return "url"
    return "domain" if valid_domain(x) else None

def vt_get(path, key):
    d, e = http_json("https://www.virustotal.com/api/v3/" + path, 10, headers={"x-apikey": key})
    if e: return None, ("not known to VirusTotal (no verdict)" if "HTTP 404" in e else e)
    try: return d["data"]["attributes"]["last_analysis_stats"], None
    except (KeyError, TypeError): return None, "unexpected VirusTotal response"

def ti_check(ind, use_keys=False):
    ind = ind.strip(); typ = ti_type(ind)
    R = {"indicator": ind, "type": typ, "matches": [], "info": [], "sources_ok": [], "sources_failed": [], "time": now(), "classification": "UNKNOWN"}
    if not typ: R["sources_failed"].append("Not a valid IP, domain or URL"); return R
    def use(key):
        lines, e, t = ti_feed(key); lab = TI_FEEDS[key][2]
        if e: R["sources_failed"].append("%s: %s" % (lab, e)); return None, lab, t
        R["sources_ok"].append(lab); return lines, lab, t
    def add(src, cat, detail, strength, t): R["matches"].append({"source": src, "category": cat, "detail": detail, "time": t or now(), "strength": strength})
    host = url = None
    if typ == "ip":
        ipo = ipaddress.ip_address(ind); lines, lab, t = use("feodo")
        if lines is not None and any(l.split("#")[0].strip() == str(ipo) for l in lines): add(lab, "Botnet command-and-control IP", "IP is on the Feodo Tracker blocklist", "strong", t)
        lines, lab, t = use("drop")
        if lines is not None:
            for l in lines:
                l = l.split(";")[0].strip()
                try:
                    if l and ipo.version == 4 and ipo in ipaddress.ip_network(l, strict=False): add(lab, "Listed netblock (criminal/hijacked range)", "IP falls inside %s" % l, "strong", t); break
                except ValueError: pass
        lines, lab, t = use("tor")
        if lines is not None and any(l.strip() == str(ipo) for l in lines): R["info"].append("%s: IP is a Tor exit relay (%s). Tor is a legitimate privacy tool; this is NOT a threat finding." % (lab, t))
    else:
        url = ind if typ == "url" else None
        if url and "://" not in url: url = "https://" + url
        host = urllib.parse.urlparse(url).hostname if url else valid_domain(ind)
        for key in ("urlhaus", "openphish"):
            lines, lab, t = use(key)
            if lines is None: continue
            m = feed_match(lines, url or "", host or "")
            cat = "Malware distribution" if key == "urlhaus" else "Phishing"
            if m == "exact": add(lab, cat + " URL", "Exact URL is listed", "strong", t)
            elif m == "host": add(lab, cat + " (host-level)", "Host appears in the feed with other URL(s); this exact URL is not listed", "weak", t)
    if use_keys and host or use_keys and typ == "ip":
        h = host or ind; uh = api_key("urlhaus_key")
        if uh:
            d, e = (urlhaus_lookup(url, uh) if url else http_json("https://urlhaus-api.abuse.ch/v1/host/", 10, headers={"Auth-Key": uh}, data={"host": h}))
            if e: R["sources_failed"].append("URLhaus API: " + e)
            else:
                R["sources_ok"].append("URLhaus API"); qs = d.get("query_status")
                if qs == "ok":
                    on = int(d.get("urls_online") or 0) if "urls_online" in d else (1 if d.get("url_status") == "online" else 0)
                    add("URLhaus API", "Malware distribution", "threat=%s status=%s urls=%s online=%s" % (d.get("threat"), d.get("url_status"), d.get("url_count"), on), "strong" if on else "weak", now())
        vk = api_key("vt_key")
        if vk:
            path = ("urls/" + base64.urlsafe_b64encode(url.encode()).decode().strip("=")) if url else ("ip_addresses/" + ind if typ == "ip" else "domains/" + h)
            st, e = vt_get(path, vk)
            if e: R["sources_failed"].append("VirusTotal: " + e)
            else:
                R["sources_ok"].append("VirusTotal"); m, s_ = st.get("malicious", 0), st.get("suspicious", 0)
                if m >= 3: add("VirusTotal", "Multi-engine detection", "%d engines malicious, %d suspicious" % (m, s_), "strong", now())
                elif m or s_: add("VirusTotal", "Multi-engine detection", "%d malicious, %d suspicious" % (m, s_), "weak", now())
    st = [x["strength"] for x in R["matches"]]
    R["classification"] = "MALICIOUS" if "strong" in st else "SUSPICIOUS" if st else "SAFE" if R["sources_ok"] else "UNKNOWN"
    return R

def ti_show(R):
    col = {"SAFE": "g", "SUSPICIOUS": "y", "MALICIOUS": "r", "UNKNOWN": "w"}[R["classification"]]
    title("THREAT INTELLIGENCE RESULT"); print(paint(CLASS_TXT[R["classification"]], col)); kv("Indicator", R["indicator"]); kv("Type", R["type"] or "invalid"); kv("Checked", R["time"])
    for m in R["matches"]:
        print(paint(" MATCH [%s] %s" % (m["strength"].upper(), m["category"]), "r" if m["strength"] == "strong" else "y")); kv("  Source", m["source"]); kv("  Feed time", m["time"]); kv("  Details", m["detail"])
    for i in R["info"]: info(i)
    kv("Sources completed", ", ".join(R["sources_ok"]) or "none")
    for x in R["sources_failed"]: info("source unavailable: " + x)
    print(); warn("Feeds list KNOWN indicators only. No match is not proof of safety. A reputation hit concerns this IP/domain/URL, never the person using it.")

def ti_findings(R):
    f = [{"check": m["category"], "status": "bad" if m["strength"] == "strong" else "warn", "detail": m["detail"], "source": m["source"]} for m in R["matches"]]
    return f + [{"check": "Sources", "status": "info", "detail": ", ".join(R["sources_ok"]) or "none completed", "source": "feeds"}]

def ti_menu():
    while True:
        title("[15] THREAT INTELLIGENCE CENTER")
        print("[1] Check IP / domain / URL  [2] Check a list  [3] Feed status & refresh  [0] Back")
        c = ask("Choice: ")
        if c == "0": return
        if c == "1":
            ind = ask("Indicator: ")
            if not ti_type(ind): err("Enter a valid IP address, domain or URL."); continue
            info("Feed lists are downloaded and matched ON YOUR DEVICE; the indicator is not sent. Optional API checks (URLhaus/VirusTotal) send it to them, only if you set keys.")
            R = ti_check(ind, bool(api_key("vt_key") or api_key("urlhaus_key")) and confirm("Also query your configured API keys (sends the indicator to those services)?"))
            ti_show(R); offer_outputs("Threat Intelligence", ind, R["classification"], ti_findings(R), [m["source"] for m in R["matches"]], {"type": R["type"], "sources_ok": R["sources_ok"]}); pause()
        elif c == "2":
            info("One indicator per line, empty line to finish (max 50).")
            L = []
            while len(L) < 50:
                x = ask("> ")
                if not x: break
                L.append(x)
            for x in L:
                R = ti_check(x); print("%-11s %-6s %s" % (R["classification"], R["type"] or "?", x[:60]))
            pause()
        elif c == "3":
            for k, (fn, url, lab) in TI_FEEDS.items():
                p = P("cache", fn); kv(lab[:34], ("cached " + ts(os.path.getmtime(p))) if os.path.exists(p) else "not downloaded", 36)
            if confirm("Delete cached feeds and refresh on next check?"):
                for fn, _, _ in TI_FEEDS.values():
                    try: os.remove(P("cache", fn))
                    except OSError: pass
                _FEEDMEM.clear(); ok("Cache cleared.")

# ================================================================= v7.0 USERNAME CHECKER
UN_PLATFORMS = [("GitHub", "https://github.com/{u}", "github"), ("Reddit", "https://www.reddit.com/user/{u}", "reddit"), ("Instagram", "https://www.instagram.com/{u}/", "web"),
                ("TikTok", "https://www.tiktok.com/@{u}", "web"), ("YouTube", "https://www.youtube.com/@{u}", "yt"), ("X", "https://x.com/{u}", "web"),
                ("LinkedIn", "https://www.linkedin.com/in/{u}", "web"), ("Roblox", "https://www.roblox.com/user.aspx?username={u}", "roblox")]
UN_RE = re.compile(r"^[A-Za-z0-9._-]{1,40}$")

def un_check(name, url_t, mode, u):
    url = url_t.format(u=urllib.parse.quote(u)); R = {"platform": name, "url": url, "status": "UNKNOWN", "detail": "", "time": now()}
    if mode == "github":
        s, _, body, e = http_status("https://api.github.com/users/" + urllib.parse.quote(u), headers={"Accept": "application/vnd.github+json"})
        if s == 200:
            try: j = json.loads(body); R.update(status="FOUND", detail="GitHub API: login=%s name=%s public_repos=%s created=%s (self-reported profile data)" % (j.get("login"), j.get("name"), j.get("public_repos"), j.get("created_at")))
            except ValueError: R["detail"] = "GitHub answered 200 but data could not be parsed"
        elif s == 404: R.update(status="NOT FOUND", detail="GitHub API: no such user")
        else: R["detail"] = e or "HTTP %s (rate limited or blocked)" % s
    elif mode == "reddit":
        s, _, body, e = http_status("https://www.reddit.com/user/%s/about.json" % urllib.parse.quote(u))
        if s == 200: R.update(status="FOUND", detail="Reddit public profile endpoint responded")
        elif s == 404: R.update(status="NOT FOUND", detail="Reddit: no such user")
        else: R["detail"] = e or "HTTP %s - Reddit blocks many automated requests; check the link manually" % s
    elif mode == "roblox":
        d, e = http_json("https://users.roblox.com/v1/usernames/users", 8, json_body={"usernames": [u], "excludeBannedUsers": False})
        if e: R["detail"] = e
        elif isinstance(d, dict) and d.get("data"): x = d["data"][0]; R.update(status="FOUND", url="https://www.roblox.com/users/%s/profile" % x.get("id"), detail="Roblox public API: id=%s name=%s" % (x.get("id"), x.get("name")))
        else: R.update(status="NOT FOUND", detail="Roblox public API: no such username")
    else:
        s, final, body, e = http_status(url)
        if e: R["detail"] = e
        elif s == 404: R.update(status="NOT FOUND", detail="Page returns 404")
        elif mode == "yt" and s == 200 and "consent." not in urllib.parse.urlparse(final).netloc: R.update(status="FOUND", detail="Public channel page exists (HTTP 200)")
        elif s == 200: R["detail"] = "Page loads, but this platform serves a generic page for any name; open the link to verify manually"
        else: R["detail"] = "HTTP %s - login wall/anti-bot; not bypassed. Open the link manually" % s
    return R

def un_run(u):
    out = []
    for i, (n, t, m) in enumerate(UN_PLATFORMS):
        if i: time.sleep(1.0)
        r = un_check(n, t, m, u); out.append(r); col = {"FOUND": "g", "NOT FOUND": "y"}.get(r["status"], "w")
        print(paint(" %-10s %-9s" % (n, r["status"]), col) + " " + r["detail"][:70]); print("    " + r["url"])
    return out

def un_findings(rs):
    return [{"check": r["platform"], "status": {"FOUND": "ok", "NOT FOUND": "info"}.get(r["status"], "warn"), "detail": "%s - %s" % (r["status"], r["detail"]), "source": r["url"]} for r in rs]

def un_menu():
    title("[18] USERNAME CHECKER")
    u = ask("Username (Enter = back): ")
    if not u: return
    if not UN_RE.match(u): err("Username may only contain letters, digits, . _ - (max 40)."); pause(); return
    info("Each platform receives a normal public request from your device (your IP and this username). Login walls/CAPTCHAs are never bypassed.")
    if not confirm("Continue?"): return
    rs = un_run(u); print(); warn("FOUND = a public page exists at that URL. It does NOT prove the account belongs to any particular person. UNKNOWN = could not be determined.")
    offer_outputs("Username Check", u, "N/A", un_findings(rs), [r["url"] for r in rs if r["status"] == "FOUND"]); pause()

# ================================================================= v7.0 DIGITAL FOOTPRINT ANALYZER
def fp_menu():
    title("[14] DIGITAL FOOTPRINT ANALYZER")
    print("[1] Username footprint  [2] Domain footprint  [0] Back")
    c = ask("Choice: ")
    if c not in ("1", "2"): return
    F, S = [], []
    if c == "1":
        u = ask("Username: ")
        if not UN_RE.match(u or ""): err("Invalid username."); pause(); return
        print(); info("A) Public search links - UNVERIFIED (open them yourself; results are not checked by this tool):")
        for n, link in search_links('"%s"' % u): kv(n, link, 12); F.append({"check": "Search link " + n, "status": "unverified", "detail": "Manual review required", "source": link})
        for plat in ("instagram.com", "tiktok.com", "linkedin.com", "x.com", "github.com"):
            F.append({"check": "Site search " + plat, "status": "unverified", "detail": "Manual review required", "source": "https://www.google.com/search?q=" + urllib.parse.quote_plus('site:%s "%s"' % (plat, u))})
        info("B) Profile URL checks - need to contact each platform:")
        if not confirm("Each platform receives a public request from your device. Continue?"): return
        rs = un_run(u); F += un_findings(rs); S = [r["url"] for r in rs if r["status"] == "FOUND"]
        print(); info("VERIFIED = retrieved directly from the platform/API. Identity of the account holder remains UNVERIFIED.")
        target = u
    else:
        d = valid_domain(ask("Domain: "))
        if not d: err("Invalid domain."); pause(); return
        if not consent_to("the domain goes to your DNS resolver / dns.google, rdap.org and archive.org (Wayback)"): return
        for t in ("A", "MX", "NS"):
            v, e = dns_query(d, t); kv("DNS " + t, ", ".join(v[:4]) or e or "none"); F.append({"check": "DNS " + t, "status": "ok" if v else "info", "detail": ", ".join(v[:6]) or e or "none", "source": "DNS (VERIFIED)"})
        rd, e = http_json("https://rdap.org/domain/" + d, 10)
        if e or not isinstance(rd, dict): kv("RDAP", e or "no data")
        else:
            ev = {x.get("eventAction"): x.get("eventDate") for x in rd.get("events", []) if isinstance(x, dict)}; kv("Registered", ev.get("registration", "n/a")); kv("Expires", ev.get("expiration", "n/a"))
            F.append({"check": "RDAP registration", "status": "ok", "detail": "registered %s, expires %s (VERIFIED, rdap.org)" % (ev.get("registration"), ev.get("expiration")), "source": "https://rdap.org/domain/" + d}); S.append("https://rdap.org/domain/" + d)
        wb, e = http_json("https://archive.org/wayback/available?url=" + urllib.parse.quote(d), 10)
        snap = ((wb or {}).get("archived_snapshots") or {}).get("closest") if isinstance(wb, dict) else None
        if snap: kv("Wayback snapshot", snap.get("url")); F.append({"check": "Wayback snapshot", "status": "ok", "detail": "closest archived copy " + str(snap.get("timestamp")), "source": snap.get("url")}); S.append(snap.get("url"))
        else: kv("Wayback snapshot", e or "none found")
        print(); info("Search links - UNVERIFIED:")
        for lab, q in (("Pages on the domain", "site:" + d), ("Mentions elsewhere", '"%s" -site:%s' % (d, d))):
            for n, link in search_links(q)[:2]: kv(n + " " + lab[:5], link, 14); F.append({"check": "%s (%s)" % (lab, n), "status": "unverified", "detail": "Manual review required", "source": link})
        extra = ["https://web.archive.org/web/*/" + d, "https://urlscan.io/search/#domain:" + d]
        for x in extra: kv("Public archive", x, 14); F.append({"check": "Public archive/scan search", "status": "unverified", "detail": "Manual review required", "source": x})
        target = d
    offer_outputs("Digital Footprint", target, "N/A", F, S, {"verified": [f["check"] for f in F if f["status"] == "ok"], "note": "Verified = fetched from the source; search links are unverified"}); pause()

# ================================================================= v7.0 FILE HASH ANALYZER
def hash_reputation(sha):
    vk, mb = api_key("vt_key"), api_key("urlhaus_key"); out = []
    if mb:
        d, e = http_json("https://mb-api.abuse.ch/api/v1/", 10, headers={"Auth-Key": mb}, data={"query": "get_info", "hash": sha})
        if e: out.append(("MalwareBazaar", "unavailable", e))
        elif isinstance(d, dict) and d.get("query_status") == "ok": x = (d.get("data") or [{}])[0]; out.append(("MalwareBazaar", "MATCH", "known malware sample: signature=%s type=%s first_seen=%s" % (x.get("signature"), x.get("file_type"), x.get("first_seen"))))
        else: out.append(("MalwareBazaar", "no match", str(d.get("query_status") if isinstance(d, dict) else "no data")))
    if vk:
        st, e = vt_get("files/" + sha, vk)
        if e: out.append(("VirusTotal", "unavailable" if "not known" not in e else "no match", e))
        else: out.append(("VirusTotal", "MATCH" if st.get("malicious", 0) else "no match", "%d malicious, %d suspicious, %d harmless engines" % (st.get("malicious", 0), st.get("suspicious", 0), st.get("harmless", 0))))
    return out

def hash_menu():
    title("[19] FILE HASH ANALYZER (files are read, never executed)")
    p = pick_file()
    if not p: return
    try: size = os.path.getsize(p); H = hash_file(p, progress=True)
    except OSError as e: err("Cannot read file: %s" % e); pause(); return
    kv("File name", os.path.basename(p)); kv("Size", "%s (%d bytes)" % (human(size), size)); kv("MD5", H["md5"]); kv("SHA-1", H["sha1"]); kv("SHA-256", H["sha256"]); kv("Scan time", now())
    F = [{"check": k, "status": "info", "detail": v, "source": "local"} for k, v in H.items()]; cls = "UNKNOWN"
    if (api_key("vt_key") or api_key("urlhaus_key")) and consent_to("ONLY the SHA-256 hash (never the file) goes to VirusTotal / MalwareBazaar"):
        rep = hash_reputation(H["sha256"])
        for s_, v, d in rep: print("  %-14s %-12s %s" % (s_, v, d)); F.append({"check": s_, "status": "bad" if v == "MATCH" else "info", "detail": "%s: %s" % (v, d), "source": s_})
        cls = "MALICIOUS" if any(v == "MATCH" for _, v, _ in rep) else "UNKNOWN"
    else: info("No reputation lookup performed (needs optional keys in Settings > 9 and your consent).")
    warn("'No match' means this hash is not in those databases - it does not prove the file is safe.")
    offer_outputs("File Hash Analysis", os.path.basename(p), cls, F, [], {"size": size, "path": os.path.abspath(p), **H}); pause()

# ================================================================= v7.0 QR CODE SECURITY
URL_RE = re.compile(r"(?i)\b(?:https?://|www\.)[^\s\"'<>]+")
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rebrand.ly", "ow.ly", "buff.ly", "shorturl.at", "t.ly", "rb.gy", "tiny.cc"}
def qr_analyze(text):
    low = text.lower().strip(); R = {"shown": text, "type": "Plain text", "urls": [], "warnings": [], "fields": {}}
    if low.startswith("wifi:"):
        R["type"] = "Wi-Fi network credentials"; R["shown"] = re.sub(r"(P:)([^;]*)", r"\1***hidden***", text, flags=re.I)
        for k, v in re.findall(r"(?:^|;)(S|T):([^;]*)", text[5:]): R["fields"][{"S": "SSID", "T": "Security"}[k]] = v
        R["warnings"].append("Scanning this would join a network; only join networks you trust. Password is hidden here and never saved.")
    elif low.startswith("otpauth://"): R["type"] = "Authenticator (2FA) secret"; R["shown"] = re.sub(r"(secret=)[^&]+", r"\1***hidden***", text, flags=re.I); R["warnings"].append("Contains a 2FA secret. Never share it.")
    elif low.startswith(("upi://", "bitcoin:", "ethereum:", "litecoin:")):
        R["type"] = "Payment request"; R["fields"] = {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(text).query).items()}; R["warnings"].append("Payment request - verify the payee and amount before paying anything.")
    elif low.startswith(("tel:", "sms:", "smsto:", "mailto:", "geo:")): R["type"] = low.split(":")[0].upper() + " action"
    elif low.startswith("begin:vcard"): R["type"] = "Contact card (vCard)"
    for m in URL_RE.findall(text):
        m = m.rstrip(".,);"); u = m if "://" in m else "https://" + m; R["urls"].append(u)
        n, pu, e = norm_target(u)
        if e: R["warnings"].append("%s: %s" % (u[:50], e)); continue
        host = pu.hostname.encode("idna").decode("ascii")
        if host in SHORTENERS: R["warnings"].append("Link shortener (%s) hides the real destination." % host)
        for _, w in url_patterns(n, pu, host): R["warnings"].append("%s: %s" % (host, w))
    if R["urls"] and R["type"] == "Plain text": R["type"] = "Web link"
    return R

def qr_decode_image(path):
    try:
        import cv2
        img = cv2.imread(path)
        if img is None: return None, "OpenCV could not read the image"
        v, _, _ = cv2.QRCodeDetector().detectAndDecode(img)
        if v: return v, None
    except ImportError: pass
    except Exception as e: return None, "OpenCV error: %s" % e
    try:
        from PIL import Image
        from pyzbar.pyzbar import decode
        r = decode(Image.open(path))
        if r: return r[0].data.decode("utf-8", "replace"), None
        return None, "No QR code found in the image"
    except ImportError: return None, "No QR decoder installed (needs opencv-python, or pyzbar+Pillow)"
    except Exception as e: return None, "pyzbar error: %s" % e

def qr_menu():
    title("[20] QR CODE SECURITY (nothing is ever opened automatically)")
    print("[1] Decode a QR image file  [2] Paste decoded QR text  [0] Back")
    c = ask("Choice: "); text = None
    if c == "1":
        p = pick_file("Image path or folder (png/jpg): ")
        if not p: return
        text, e = qr_decode_image(p)
        if e: err(e); info("Fallback: scan the QR with any scanner app WITHOUT opening it, copy the text, then use option 2."); pause(); return
    elif c == "2": text = ask("Decoded text: ")
    if not text: return
    R = qr_analyze(text); title("DECODED QR CONTENT (NOT OPENED)"); kv("Type", R["type"]); print(paint(R["shown"][:500], "w"))
    for k, v in R["fields"].items(): kv(k, v)
    F = [{"check": "QR type", "status": "info", "detail": R["type"], "source": "local"}] + [{"check": "Warning", "status": "warn", "detail": w, "source": "local"} for w in R["warnings"]]
    for w in R["warnings"]: warn(w)
    cls = "SUSPICIOUS" if len(R["warnings"]) >= 2 and R["urls"] else "UNKNOWN"; src = []
    for u in R["urls"][:3]:
        kv("URL", u); src.append(u)
        if confirm("Scan this URL with the Web Security Scanner?"):
            sc = scan_core(u, ask_consent()); history_add(sc); scan_show(sc, brief=True); cls = sc["classification"]; F.append({"check": "Scanner", "status": "info", "detail": CLASS_TXT[cls], "source": u})
    offer_outputs("QR Code Security", R["shown"][:60], cls, F, src, {"type": R["type"]}); pause()

# ================================================================= v7.0 SUBDOMAIN INTELLIGENCE
def sub_norm(n, d):
    n = n.strip().lower().lstrip("*.").rstrip(".")
    return n if (n == d or n.endswith("." + d)) and re.match(r"^[a-z0-9._-]+$", n) and ".." not in n else None

def sub_sources(d):
    S = {}
    j, e = http_json("https://crt.sh/?q=%25." + d + "&output=json", 30, maxbytes=12000000)
    S["crt.sh"] = ([x for it in j if isinstance(it, dict) for x in str(it.get("name_value", "")).split("\n")] if isinstance(j, list) else [], e)
    j, e = http_json("https://api.certspotter.com/v1/issuances?domain=%s&include_subdomains=true&expand=dns_names" % d, 20, maxbytes=6000000)
    S["Certspotter"] = ([x for it in j if isinstance(it, dict) for x in it.get("dns_names", [])] if isinstance(j, list) else [], e)
    t, e = http_text("https://api.hackertarget.com/hostsearch/?q=" + d, 15)
    S["HackerTarget"] = ([l.split(",")[0] for l in t.splitlines() if "," in l and " " not in l] if t and "error" not in t[:40].lower() and "API count" not in t[:60] else [], e or (("limit/denied: " + t[:60]) if t and ("error" in t[:40].lower() or "API count" in t[:60]) else None))
    j, e = http_json("https://jldc.me/anubis/subdomains/" + d, 15)
    S["Anubis"] = (j if isinstance(j, list) else [], e)
    return S

def sub_collect(d, S):
    found = {}
    for src, (names, e) in S.items():
        for n in names:
            n = sub_norm(str(n), d)
            if n: found.setdefault(n, {"sources": set(), "first_seen": now(), "ip": None})["sources"].add(src)
    return found

def sub_resolve(found, limit=150):
    names = sorted(found)[:limit]
    def r(h):
        try: return sorted({x[4][0] for x in socket.getaddrinfo(h, None)})[:3]
        except Exception: return []
    try:
        with ThreadPoolExecutor(max_workers=12) as ex:
            fut = {ex.submit(r, h): h for h in names}
            for f in as_completed(fut, timeout=90): found[fut[f]]["ip"] = f.result()
    except Exception as e: warn("Resolution incomplete: %s" % type(e).__name__)

def sub_export(d, found):
    base = os.path.join(out_dir("exports"), "subdomains_%s_%s" % (safe_name(d), dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    rows = [{"subdomain": k, "resolves": bool(v["ip"]) if v["ip"] is not None else None, "ips": v["ip"] or [], "sources": sorted(v["sources"]), "discovered": v["first_seen"]} for k, v in sorted(found.items())]
    try:
        save_json(base + ".json", {"domain": d, "time": now(), "results": rows})
        open(base + ".txt", "w", encoding="utf-8").write("\n".join(r["subdomain"] for r in rows) + "\n")
        with open(base + ".csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(["subdomain", "resolves", "ips", "sources", "discovered"])
            for r in rows: w.writerow([r["subdomain"], r["resolves"], " ".join(r["ips"]), " ".join(r["sources"]), r["discovered"]])
        ok("Exported %s.txt/.csv/.json" % base)
    except OSError as e: err("Export failed: %s" % e)

def sub_menu():
    title("[21] SUBDOMAIN INTELLIGENCE (passive sources only)")
    d = valid_domain(ask("Domain (Enter = back): "))
    if not d: return
    if not consent_to("the domain %s goes to crt.sh, Certspotter, HackerTarget and jldc.me (Anubis) over HTTPS" % d): return
    S = sub_sources(d); found = sub_collect(d, S)
    for src, (names, e) in S.items(): kv(src, ("%d names" % len(names)) if not e else paint("unavailable: " + e, "y"), 14)
    if not found: warn("No subdomains found (sources may be rate limited or down)."); pause(); return
    if confirm("DNS-resolve up to 150 discovered names?"): sub_resolve(found)
    for k in sorted(found)[:60]: v = found[k]; print("%-38s %-8s %s" % (k[:38], "-" if v["ip"] is None else ("resolves" if v["ip"] else "no DNS"), ",".join(sorted(v["sources"]))))
    ok("%d unique subdomains (duplicates removed)." % len(found))
    if confirm("Export TXT/CSV/JSON?"): sub_export(d, found)
    F = [{"check": k, "status": "info", "detail": "sources: %s; resolves: %s" % (",".join(sorted(v["sources"])), v["ip"] if v["ip"] is not None else "not checked"), "source": "passive sources, " + v["first_seen"]} for k, v in sorted(found.items())[:200]]
    offer_outputs("Subdomain Intelligence", d, "N/A", F, [], {"total": len(found)}); pause()

# ================================================================= v7.0 METADATA VIEWER
_TT = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8}
IFD0 = {0x010F: "Make", 0x0110: "Model", 0x0131: "Software", 0x0132: "DateTime", 0x013B: "Artist", 0x8298: "Copyright", 0x0112: "Orientation"}
EXIFT = {0x9003: "DateTimeOriginal", 0x9004: "DateTimeDigitized", 0xA434: "LensModel", 0xA433: "LensMake", 0x829A: "ExposureTime", 0x829D: "FNumber", 0x8827: "ISO",
         0x920A: "FocalLength", 0xA002: "PixelWidth", 0xA003: "PixelHeight", 0xA430: "CameraOwnerName", 0xA431: "BodySerialNumber"}
def _ifd(t, off, e):
    out = {}; n = struct.unpack(e + "H", t[off:off + 2])[0]
    for i in range(min(n, 200)):
        b = off + 2 + i * 12; tag, typ, cnt = struct.unpack(e + "HHI", t[b:b + 8]); raw = t[b + 8:b + 12]; size = _TT.get(typ, 1) * cnt
        if size > 100000: continue
        data = raw[:size] if size <= 4 else t[struct.unpack(e + "I", raw)[0]:struct.unpack(e + "I", raw)[0] + size]
        if typ == 2: v = data.split(b"\0")[0].decode("utf-8", "replace").strip()
        elif typ == 3: v = struct.unpack(e + "%dH" % cnt, data[:2 * cnt])
        elif typ == 4: v = struct.unpack(e + "%dI" % cnt, data[:4 * cnt])
        elif typ in (5, 10): v = [(lambda a, b_: a / b_ if b_ else None)(*struct.unpack(e + "II" if typ == 5 else e + "ii", data[k * 8:k * 8 + 8])) for k in range(cnt)]
        else: v = data
        out[tag] = v[0] if isinstance(v, (tuple, list)) and len(v) == 1 else v
    return out
def parse_tiff(t):
    e = "<" if t[:2] == b"II" else ">"; ifd0 = _ifd(t, struct.unpack(e + "I", t[4:8])[0], e); R = {}
    for tag, name in IFD0.items():
        if tag in ifd0: R[name] = ifd0[tag]
    if 0x8769 in ifd0:
        x = _ifd(t, ifd0[0x8769], e)
        for tag, name in EXIFT.items():
            if tag in x: R[name] = x[tag]
    if 0x8825 in ifd0:
        g = _ifd(t, ifd0[0x8825], e)
        def dms(v): return v[0] + v[1] / 60 + v[2] / 3600 if isinstance(v, list) and len(v) == 3 and None not in v else None
        la, lo = dms(g.get(2)), dms(g.get(4))
        if la is not None and lo is not None:
            R["GPS"] = (round(-la if g.get(1) == "S" else la, 6), round(-lo if g.get(3) == "W" else lo, 6))
        alt = g.get(6)
        if isinstance(alt, (int, float)): R["GPS Altitude (m)"] = round(-alt if g.get(5) in (1, b"\x01") else alt, 1)
        if isinstance(g.get(29), str) and g.get(29): R["GPS Date"] = g[29]
        tm = g.get(7)
        if isinstance(tm, list) and len(tm) == 3 and None not in tm: R["GPS Time (UTC)"] = "%02d:%02d:%02d" % (int(tm[0]), int(tm[1]), int(tm[2]))
        if isinstance(g.get(17), (int, float)): R["GPS Direction (deg)"] = round(g[17], 1)
    return R
def exif_jpeg(data):
    if data[:2] != b"\xff\xd8": return None
    i = 2
    while i + 4 <= len(data) and data[i] == 0xFF:
        mk = data[i + 1]
        if mk in (0xDA, 0xD9): break
        ln = struct.unpack(">H", data[i + 2:i + 4])[0]; seg = data[i + 4:i + 2 + ln]
        if mk == 0xE1 and seg[:6] == b"Exif\0\0": return parse_tiff(seg[6:])
        i += 2 + ln
    return {}
def png_meta(path):
    R = {}
    with open(path, "rb") as f:
        if f.read(8) != b"\x89PNG\r\n\x1a\n": return None
        for _ in range(500):
            h = f.read(8)
            if len(h) < 8: break
            ln, typ = struct.unpack(">I4s", h)
            if typ == b"IHDR": R["Dimensions"] = "%dx%d" % struct.unpack(">II", f.read(8)); f.seek(ln - 8 + 4, 1)
            elif typ == b"tEXt" and ln < 100000: k, _, v = f.read(ln).partition(b"\0"); R["Text: " + k.decode("latin-1")] = v.decode("latin-1")[:200]; f.seek(4, 1)
            elif typ == b"eXIf" and ln < 200000:
                try: R.update(parse_tiff(f.read(ln)))
                except Exception: pass
                f.seek(4, 1)
            elif typ == b"IEND": break
            else: f.seek(ln + 4, 1)
    return R
def office_meta(path):
    R = {}
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        for n in ("docProps/core.xml", "docProps/app.xml", "meta.xml"):
            if n in names:
                try:
                    for el in ET.fromstring(z.open(n).read(1000000)).iter():
                        tg = el.tag.split("}")[-1]
                        if el.text and el.text.strip() and len(list(el)) == 0: R[tg] = el.text.strip()[:200]
                except ET.ParseError: pass
    return R
def pdf_meta(path):
    sz = os.path.getsize(path)
    with open(path, "rb") as f:
        data = f.read(1500000) + (b"" if sz <= 1500000 else (f.seek(-1000000, 2) or f.read()))
    R = {}
    for k, v in re.findall(rb"/(Title|Author|Subject|Keywords|Creator|Producer|CreationDate|ModDate)\s*\(((?:\\.|[^\\)])*)\)", data):
        R[k.decode()] = (v.decode("utf-16-be", "replace") if v[:2] == b"\xfe\xff" else v.decode("latin-1", "replace"))[:200]
    return R
MAGIC = [(b"\xff\xd8\xff", "JPEG image"), (b"\x89PNG", "PNG image"), (b"GIF8", "GIF image"), (b"%PDF", "PDF document"), (b"PK\x03\x04", "ZIP container (Office/ODF/APK/ZIP)"), (b"MZ", "Windows executable"), (b"\x7fELF", "ELF executable"), (b"RIFF", "RIFF (WAV/WebP/AVI)")]

def meta_collect(path):
    st = os.stat(path); R = {"file": {"Name": os.path.basename(path), "Size": "%s (%d bytes)" % (human(st.st_size), st.st_size), "Modified": ts(st.st_mtime), "Accessed": ts(st.st_atime),
          ("Created" if hasattr(st, "st_birthtime") or os.name == "nt" else "Metadata changed (not creation time on Linux/Android)"): ts(getattr(st, "st_birthtime", st.st_ctime)),
          "Guessed MIME": mimetypes.guess_type(path)[0] or "unknown"}}
    with open(path, "rb") as f: head = f.read(16)
    R["file"]["Detected type"] = next((n for m, n in MAGIC if head.startswith(m)), "unknown/other"); R["hashes"] = hash_file(path, progress=True); kind = R["file"]["Detected type"]; x = None
    try:
        if kind == "JPEG image":
            with open(path, "rb") as f: x = exif_jpeg(f.read(2000000))
        elif kind == "PNG image": x = png_meta(path)
        elif kind.startswith("ZIP"): x = office_meta(path)
        elif kind == "PDF document": x = pdf_meta(path)
    except (OSError, struct.error, zipfile.BadZipFile, ValueError) as e: R["error"] = "Could not parse metadata: %s" % e
    R["metadata"] = x; return R

def meta_menu():
    title("[22] METADATA VIEWER + PHOTO GPS (local files only; nothing is uploaded)")
    print("[1] File metadata & hashes  [2] Photo GPS Intelligence  [0] Back")
    c = ask("Choice: ")
    if c == "2": photo_menu_item(); pause(); return
    if c != "1": return
    p = pick_file()
    if not p: return
    try: R = meta_collect(p)
    except OSError as e: err("Cannot read file: %s" % e); pause(); return
    F = []
    for k, v in R["file"].items(): kv(k, v); F.append({"check": k, "status": "info", "detail": v, "source": "local file system"})
    for k, v in R["hashes"].items(): kv(k.upper(), v); F.append({"check": k.upper(), "status": "info", "detail": v, "source": "local"})
    print()
    if R.get("error"): err(R["error"])
    if R["metadata"]:
        info("Embedded metadata:")
        for k, v in R["metadata"].items():
            if k == "GPS": kv("GPS", "%s, %s" % v); kv("Google Maps", "https://www.google.com/maps?q=%s,%s" % v); warn("This file contains GPS coordinates. Sharing it may reveal where it was taken.")
            else: kv(k, v)
            F.append({"check": k, "status": "info", "detail": str(v)[:200], "source": "embedded metadata"})
    else: info("No embedded metadata found, or this file type is not supported (supported: JPEG EXIF, PNG text/EXIF, Office/ODF, PDF Info).")
    offer_outputs("Metadata Report", os.path.basename(p), "N/A", F, [], {"path": os.path.abspath(p)}); pause()


# ================================================================= v7.0 PHOTO GPS INTELLIGENCE (local files only)
PHOTO_EXT = (".jpg", ".jpeg", ".png")
def photo_meta(path):
    """Returns (metadata dict or None, error). Reads the file locally; nothing is uploaded."""
    try:
        with open(path, "rb") as f: head = f.read(8)
        if head[:3] == b"\xff\xd8\xff":
            with open(path, "rb") as f: return exif_jpeg(f.read(2000000)) or {}, None
        if head[:4] == b"\x89PNG": return png_meta(path) or {}, None
        return None, "Not a JPEG or PNG photo"
    except (OSError, struct.error, ValueError) as e: return None, "Could not read metadata: %s" % e

def photo_gps_show(path, m):
    F = []
    def row(k, v, src="embedded EXIF"): kv(k, v); F.append({"check": k, "status": "info", "detail": str(v)[:200], "source": src})
    for k in ("Make", "Model", "Software", "DateTimeOriginal", "DateTime", "LensModel", "CameraOwnerName", "BodySerialNumber"):
        if m.get(k): row(k, m[k])
    g = m.get("GPS")
    if not g: info("No GPS coordinates are stored in this photo."); return F, False
    print(); info("GPS found in this photo (coordinates recorded by the camera at capture time):")
    row("Latitude", g[0]); row("Longitude", g[1]); row("Combined coordinates", "%s, %s" % g)
    row("Google Maps link", "https://www.google.com/maps?q=%s,%s" % g, "generated link"); row("OpenStreetMap link", "https://www.openstreetmap.org/?mlat=%s&mlon=%s#map=17/%s/%s" % (g[0], g[1], g[0], g[1]), "generated link")
    for k in ("GPS Altitude (m)", "GPS Date", "GPS Time (UTC)", "GPS Direction (deg)"):
        if k in m: row(k, m[k])
    print(); warn("Privacy: anyone who receives this file can read this location. Remove metadata before sharing (option 3 in this menu).")
    warn("These links are only text; opening them contacts Google/OpenStreetMap. EXIF can be edited, so it proves nothing about who took the photo or whether it is genuine.")
    return F, True

def strip_jpeg(path):
    """Writes a COPY without EXIF/XMP (APP1) and IPTC (APP13); the original is never modified."""
    with open(path, "rb") as f: d = f.read()
    if d[:2] != b"\xff\xd8": return None, "Only JPEG files are supported for cleaning"
    out, i = bytearray(d[:2]), 2
    while i + 4 <= len(d) and d[i] == 0xFF:
        mk = d[i + 1]
        if mk == 0xDA: break
        ln = struct.unpack(">H", d[i + 2:i + 4])[0]
        if mk not in (0xE1, 0xED): out += d[i:i + 2 + ln]
        i += 2 + ln
    out += d[i:]
    base = os.path.join(out_dir("exports"), safe_name(os.path.splitext(os.path.basename(path))[0]) + "_clean")
    dest, n = base + ".jpg", 1
    while os.path.exists(dest): n += 1; dest = "%s_%d.jpg" % (base, n)
    with open(dest, "wb") as f: f.write(out)
    return dest, None

def photo_folder_scan(folder):
    rows = []
    try: names = sorted(f for f in os.listdir(folder) if f.lower().endswith(PHOTO_EXT))[:300]
    except OSError as e: return None, "Cannot read folder: %s" % e
    for n in names:
        m, e = photo_meta(os.path.join(folder, n)); rows.append((n, (m or {}).get("GPS"), e))
    return rows, None

def photo_menu_item():
    print("[1] Photo GPS analysis  [2] Folder GPS privacy scan  [3] Create metadata-free JPEG copy  [0] Back")
    c = ask("Choice: ")
    if c == "2":
        fo = os.path.expanduser(ask("Folder path (e.g. /storage/emulated/0/DCIM/Camera): ").strip().strip('"'))
        rows, e = photo_folder_scan(fo)
        if e: err(e); return
        withg = [r for r in rows if r[1]]
        for n, g, er in rows: print("  %-34s %s" % (n[:34], ("GPS %s, %s" % g) if g else (er or "no GPS")))
        ok("%d photos checked, %d contain GPS coordinates." % (len(rows), len(withg)))
        offer_outputs("Photo GPS Privacy Scan", fo, "N/A", [{"check": n, "status": "warn" if g else "info", "detail": ("GPS %s, %s" % g) if g else (er or "no GPS"), "source": "embedded EXIF"} for n, g, er in rows], [], {"photos": len(rows), "with_gps": len(withg)})
        return
    if c not in ("1", "3"): return
    p = pick_file("Photo path or folder (jpg/png): ")
    if not p: return
    if c == "3":
        d, e = strip_jpeg(p)
        if e: err(e)
        else:
            m, _ = photo_meta(d); ok("Clean copy saved (original untouched): " + d); ok("Verification: GPS in copy = %s" % ("STILL PRESENT" if (m or {}).get("GPS") else "none"))
        return
    m, e = photo_meta(p)
    if e: err(e); return
    F, has = photo_gps_show(p, m)
    offer_outputs("Photo GPS Intelligence", os.path.basename(p), "N/A", F, [], {"path": os.path.abspath(p), "has_gps": has, "sha256": hash_file(p, ("sha256",))["sha256"]})

# ================================================================= v7.0 HTML REPORT CENTER + DEPENDENCIES
def rep_from_scan(sc):
    return {"title": "Web Security Scan", "target": sc.get("target"), "classification": sc.get("classification"), "time": sc.get("time"),
            "findings": sc.get("findings", []), "sources": sc.get("sources_ok", []), "limitations": sc.get("limitations", []), "technical": {"scan_id": sc.get("scan_id"), "provider": sc.get("provider"), "warning_points": sc.get("warning_points")}}
def rep_from_record(r):
    return {"title": "%s report" % r.get("type", "Investigation"), "target": r.get("subject"), "classification": "N/A", "time": r.get("created"),
            "findings": [{"check": "Notes", "status": "info", "detail": n.get("note"), "source": n.get("time")} for n in r.get("notes", [])], "sources": [], "technical": r.get("data", {})}

def htmlcenter_menu():
    while True:
        title("[23] HTML REPORT CENTER (offline, saved locally)")
        print("[1] From an Evidence Vault case  [2] From a saved scan report  [3] From any saved investigation report  [4] List HTML reports  [0] Back")
        c = ask("Choice: ")
        if c == "0": return
        if c == "1":
            cid = ask("Case ID: ")
            case = vault_load(cid) if vault_valid(cid) else None
            if case: html_save(vault_report(case))
            elif cid: err("Case not found.")
        elif c == "2":
            fs = sorted(f for f in os.listdir(out_dir("scan_reports")) if f.endswith(".json") and f != "history.json")
            for i, f in enumerate(fs, 1): print("%3d) %s" % (i, f))
            n = ask("Number: ")
            if n.isdigit() and 0 < int(n) <= len(fs):
                sc = load_json(os.path.join(out_dir("scan_reports"), fs[int(n) - 1]), {})
                if sc: html_save(rep_from_scan(sc))
        elif c == "3":
            fs = all_report_files()
            for i, f in enumerate(fs, 1): print("%3d) %s" % (i, os.path.basename(f)))
            n = ask("Number: ")
            if n.isdigit() and 0 < int(n) <= len(fs):
                r = load_json(fs[int(n) - 1], {})
                if r: html_save(rep_from_record(r))
        elif c == "4":
            for f in sorted(os.listdir(out_dir("html_reports"))): print(" - " + f)
            pause()

DEPS = [("phonenumbers", "phonenumbers", "REQUIRED for phone modules"), ("dns", "dnspython", "optional: native DNS (else DNS-over-HTTPS)"), ("colorama", "colorama", "optional: Windows colors"),
        ("cv2", "opencv-python", "optional: QR image decoding"), ("PIL", "Pillow", "optional: needed with pyzbar"), ("pyzbar", "pyzbar", "optional: QR decoding (needs zbar library)")]
def dep_state():
    out = []
    for mod, pkg, why in DEPS:
        try: __import__(mod); ok_ = True
        except Exception: ok_ = False
        out.append((mod, pkg, why, ok_))
    return out
def dep_menu():
    title("DEPENDENCY CHECKER")
    st = dep_state()
    for mod, pkg, why, ok_ in st: kv(pkg, (paint("installed", "g") if ok_ else paint("missing", "y")) + "  - " + why, 16)
    kv("Python", platform.python_version(), 16); kv("Everything else", "Python standard library", 16)
    miss = [pkg for _, pkg, _, ok_ in st if not ok_]
    if miss and confirm("\nTry to install the missing packages with pip now?"):
        for pkg in miss:
            if pkg == "pyzbar": info("Skipping pyzbar (needs a native zbar library; use opencv-python instead)."); continue
            try:
                r = subprocess.run([sys.executable, "-m", "pip", "install", pkg], capture_output=True, text=True, timeout=300); print("  %s: %s" % (pkg, "installed" if r.returncode == 0 else "failed - install it from your app's pip menu"))
            except Exception as e: print("  %s: could not run pip (%s). On Pydroid 3 use the Pip menu." % (pkg, type(e).__name__))
    pause()


# ----------------------------------------------------------------- main
def main():
    ensure_dirs(); load_settings()
    loading()
    handlers = {"1": phone_menu, "2": business_menu, "3": scam_menu, "4": batch_menu, "5": reports_menu, "6": webguard,
                "7": ip_menu, "8": email_menu, "9": device_show, "10": settings_menu,
                "11": scanner_menu, "12": browser_menu, "13": dashboard_menu,
                "14": fp_menu, "15": ti_menu, "16": dns_menu, "17": vault_menu, "18": un_menu, "19": hash_menu, "20": qr_menu, "21": sub_menu, "22": meta_menu, "23": htmlcenter_menu}
    names = ["Phone Number Lookup", "Public Business Intelligence", "Community Scam Intelligence", "Batch Phone Analyzer",
             "Investigation Reports", "WebGuard", "IP-WA-TRACE", "Email Lookup", "Local Device Intelligence", "Settings",
             "Web Security Scanner", "Secure Browser", "Threat Intelligence Dashboard",
             "Digital Footprint Analyzer", "Threat Intelligence Center", "DNS Intelligence", "Evidence Vault", "Username Checker", "File Hash Analyzer",
             "QR Code Security", "Subdomain Intelligence", "Metadata Viewer", "HTML Report Center"]
    miss = [p for _, p, _, ok_ in dep_state() if not ok_ and p in ('phonenumbers',)]
    if miss: warn('Missing required library: %s  (Settings > 5 can install it)' % ', '.join(miss)); time.sleep(1.2)
    status = None
    while True:
        clear()
        print(paint(LOGO, "c"))
        line(); print(paint(" %s  v%s   |   %s" % (APP, VERSION, now()), "B"))
        if status is None:
            status = online(); log("connectivity check: %s" % ("online" if status else "offline"))
        print(); print(paint(DISCLAIMER, "Y")); print()
        line()
        for i, n in enumerate(names, 1): print(paint("[%d]" % i, "y") + " " + n)
        print(paint("[c]", "y") + " Clear screen / refresh status\n" + paint("[0]", "y") + " Exit")
        ch = ask("\nSelect: ").lower()
        if ch == "0":
            print("Goodbye."); return
        if ch == "c": status = None; continue
        h = handlers.get(ch)
        if not h: err("Invalid option."); time.sleep(0.8); continue
        try:
            h()
        except KeyboardInterrupt:
            print(); warn("Cancelled.")
        except Exception as e:
            log("module error %s: %r" % (ch, e)); err("Unexpected error (logged): %s" % e); pause()

if __name__ == "__main__":
    main()
