BHAI BHAI STORE POS — UPDATED UI + LOCAL USER LOGIN

Files:
- index.html: standalone offline POS app

GET STARTED
1. Extract the ZIP file.
2. Open index.html in Chrome or Microsoft Edge.
3. First login: username admin, password/PIN 1234.
4. Immediately open Backup & Settings > User Login Management > Change Password and set your own PIN/password.
5. Use Add User to create separate logins for staff.
6. Add your products and change the example Internet Cafe service prices to your actual rates.

WHAT'S INCLUDED
- Refreshed responsive interface for desktop and mobile
- Custom colourful BB storefront logo, branded login screen, high-contrast colours, and quick section tiles
- One-tap dashboard shortcuts for Grocery, Cosmetics, Hardware, and Internet Cafe
- Login screen, logout button, and multiple local user accounts
- Admin can add users, change passwords, and remove staff logins
- Grocery, Cosmetics, Hardware, Internet Cafe services
- Bills, stock management, sales history, reports, expenses
- JSON backup/restore and CSV exports
- Works offline after saving the HTML file locally

IMPORTANT LIMITATIONS
- This is a local/offline convenience login, not strong security. Passwords are stored in this browser's local storage and a technically skilled person with device access may bypass it. Keep your PC/mobile locked and use a unique password.
- User accounts and business records are stored separately on each device. There is no automatic PC-mobile sync.
- Export backups regularly. Clearing browser data can erase records.
- This starter is not audited accounting or GST-compliance software and does not directly print receipts.
- KhataBook / Credit Customers: customer directory, phone numbers, credit-bill tracking, outstanding balance totals, customer ledger statements, and full/partial payment receipts (Cash/UPI/Bank Transfer/Other)
- Credit/Due bills require a customer name and automatically create or link the customer record
