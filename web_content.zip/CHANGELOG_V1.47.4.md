# Carreira de Craque v1.47.4

- Flamengo: listras horizontais pretas mais grossas, com faixas largas inspiradas na camisa de referência enviada pelo usuário.
- Preservadas as demais correções de uniformes e funcionalidades da versão 1.47.3.
- Cache PWA atualizado para carregar os arquivos novos.
