# Link Store YACKUZA by Digital Empire — prototype v1

Prototype web mobile-first en français pour organiser des liens de fichiers et de projets avec une identité noire/rouge.

## Lancer
- Ouvrir `index.html` dans un navigateur moderne (Chrome Android ou ordinateur).
- Ajouter une URL réelle (`https://...`), choisir une catégorie et enregistrer.
- Les entrées sont stockées localement dans le navigateur (`localStorage`).

## Limites actuelles
- Ce dossier est un prototype web, pas encore un APK Android.
- Les alias `Link_yackuza_digital_empire/Nom_du_projet` servent d'identifiants visuels; ils ne deviennent pas des URL publiques tant qu'un domaine et un serveur/API ne sont pas configurés.
- Les fichiers ne sont pas hébergés ici : le bouton ouvrir redirige vers l'URL que l'utilisateur a ajoutée.
- Avant publication, ajouter une vraie API/backend, contrôle de liens, gestion d'erreurs, confidentialité, tests Android et droits sur les contenus hébergés.

## Identité
Nom : Link Store YACKUZA
Signature : by Digital Empire
Créateur affiché : LORD DÉMON YACKUZA
Thème : noir / rouge
Fond : `assets/yackuza-background.png`
