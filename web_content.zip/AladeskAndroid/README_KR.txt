알라데스크 Android 앱 프로젝트

1. Android Studio를 설치합니다.
2. 이 폴더(AladeskAndroid)를 Android Studio에서 Open 합니다.
3. Gradle Sync가 끝나면 Build > Build APK(s)를 선택합니다.
4. 생성된 APK를 Android 휴대폰으로 옮겨 설치합니다.

앱 내부에는 업로드한 알라데스크1.html 원본이 index.html로 포함되어 있습니다.
인터넷이 없어도 HTML 자체는 실행되지만, 원본 HTML에서 외부 Google Fonts 등을 사용하는 부분은 인터넷 연결이 필요할 수 있습니다.
