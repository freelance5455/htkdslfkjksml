MANOLO CARTAS - proyecto web preparado para empaquetar en Android

Contenido:
- index.html: juego
- manifest.webmanifest: nombre e iconos de la PWA
- sw.js: service worker
- icon-192.png, icon-512.png, icon-maskable-512.png: iconos

Nombre de la aplicación: Manolo cartas

Este ZIP todavía NO es un APK. Para generar un APK hay que compilarlo con una herramienta Android (por ejemplo, Capacitor + Android SDK/Android Studio) o empaquetarlo mediante un servicio compatible. El proyecto web se puede probar en un navegador y, si se aloja por HTTPS, instalar como PWA desde el menú del navegador.
