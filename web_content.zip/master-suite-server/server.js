'use strict';
/**
 * Master Suite – Login & Sync Server
 * Zero dependency (Node.js 18+). Run:  node server.js
 *
 *  - Server-side login (scrypt password hash, HttpOnly session cookie)
 *  - Admin / Staff roles, per-user tab permission (enforced on the server)
 *  - Business data (localStorage) sync between devices, with daily backups
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { promisify } = require('util');
const scrypt = promisify(crypto.scrypt);

const PORT = +process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const ROOT = __dirname;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const PUB = path.join(ROOT, 'public');
const APP_FILE = path.join(ROOT, 'Master_Business.html');
const COOKIE = 'msid';

const TABS = ['counting', 'due', 'bank', 'stock', 'fin'];
// which localStorage key belongs to which tab (unknown keys => admin only)
const KEY_TAB = {
  DSR_EXCEL_STYLE_DB_V4: 'counting', DSR_EXCEL_STYLE_DSR_LIST_V4: 'counting',
  DSR_FULL_PROD_DUE_DB_V6: 'counting', DSR_SIM_HLR_DATABASE_V8: 'counting',
  due_entries: 'due', due_entries_reset_v1: 'due',
  master_dash_db: 'bank', master_dash_config: 'bank',
  master_dash_db_reset_v1: 'bank', master_dash_config_reset_v1: 'bank',
  dh_simData: 'stock', dh_scData: 'stock', dh_simProducts: 'stock', dh_scProducts: 'stock',
  incomeData: 'fin', expenseData: 'fin', incomeCategories: 'fin',
  expenseCategories: 'fin', categories_reset_v1: 'fin',
};

fs.mkdirSync(BACKUP_DIR, { recursive: true });

/* ---------------------------- tiny JSON db ---------------------------- */
const F_USERS = path.join(DATA_DIR, 'users.json');
const F_STORE = path.join(DATA_DIR, 'store.json');
const F_SESS = path.join(DATA_DIR, 'sessions.json');

function readJSON(f, def) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return def; }
}
function writeJSON(f, obj) {
  const tmp = f + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj));
  fs.renameSync(tmp, f);
}
let users = readJSON(F_USERS, { users: [] });
let store = readJSON(F_STORE, { rev: 0, keys: {} });
let sessions = new Map(Object.entries(readJSON(F_SESS, {})));
let storeTimer = null;
const saveUsers = () => writeJSON(F_USERS, users);
const saveSessions = () => writeJSON(F_SESS, Object.fromEntries(sessions));
function saveStoreSoon() {
  if (storeTimer) return;
  storeTimer = setTimeout(() => { storeTimer = null; writeJSON(F_STORE, store); }, 300);
}
function flushStore() { if (storeTimer) { clearTimeout(storeTimer); storeTimer = null; } writeJSON(F_STORE, store); }

/* ------------------------------ helpers ------------------------------ */
const now = () => Date.now();
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const uid = () => crypto.randomBytes(8).toString('hex');
const send = (res, code, body, headers = {}) => {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(code, Object.assign({
    'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/html; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'X-Frame-Options': 'SAMEORIGIN',
  }, headers));
  res.end(isObj ? JSON.stringify(body) : body);
};
const fail = (res, code, msg) => send(res, code, { error: msg });

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(Object.assign(new Error('too big'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch (e) { reject(Object.assign(new Error('bad json'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach(p => {
    const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function clientIp(req) {
  if (TRUST_PROXY && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim();
  return req.socket.remoteAddress || '';
}
function isSecure(req) {
  return !!req.socket.encrypted || (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https');
}
function isDirectLoopback(req) {
  const ip = req.socket.remoteAddress || '';
  return (ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1') && !req.headers['x-forwarded-for'];
}
function cookieHeader(req, token, maxAge) {
  let c = `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict`;
  if (maxAge != null) c += `; Max-Age=${maxAge}`;
  if (isSecure(req)) c += '; Secure';
  return c;
}

/* ------------------------------ passwords ---------------------------- */
async function hashPw(pw, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const h = (await scrypt(pw, salt, 64)).toString('hex');
  return { salt, hash: h };
}
async function checkPw(pw, u) {
  const dummy = { salt: '00'.repeat(16), hash: '00'.repeat(64) };
  const t = u || dummy;
  const h = (await scrypt(pw, t.salt, 64));
  const ok = crypto.timingSafeEqual(h, Buffer.from(t.hash, 'hex'));
  return !!u && ok;
}
const validUsername = s => typeof s === 'string' && /^[A-Za-z0-9_.@-]{3,32}$/.test(s);
const validPw = s => typeof s === 'string' && s.length >= 6 && s.length <= 200;

/* ------------------------------ sessions ----------------------------- */
function createSession(userId, remember) {
  const token = crypto.randomBytes(32).toString('base64url');
  const ttl = remember ? 30 * 864e5 : 12 * 36e5;
  sessions.set(sha(token), { uid: userId, exp: now() + ttl });
  saveSessions();
  return { token, maxAge: remember ? Math.floor(ttl / 1000) : null };
}
function getAuth(req) {
  const tok = parseCookies(req)[COOKIE];
  if (!tok) return null;
  const s = sessions.get(sha(tok));
  if (!s) return null;
  if (s.exp < now()) { sessions.delete(sha(tok)); saveSessions(); return null; }
  const u = users.users.find(x => x.id === s.uid);
  if (!u || u.disabled) return null;
  return { user: u, tokenHash: sha(tok) };
}
function revokeUserSessions(userId, exceptHash) {
  for (const [k, v] of sessions) if (v.uid === userId && k !== exceptHash) sessions.delete(k);
  saveSessions();
}
setInterval(() => {
  let ch = false;
  for (const [k, v] of sessions) if (v.exp < now()) { sessions.delete(k); ch = true; }
  if (ch) saveSessions();
}, 36e5).unref();

/* ---------------------------- login throttle ------------------------- */
const attempts = new Map();
function throttleKey(req, uname) { return clientIp(req) + '|' + String(uname || '').toLowerCase(); }
function lockedFor(k) {
  const a = attempts.get(k); if (!a || !a.until) return 0;
  return Math.max(0, a.until - now());
}
function recordFail(k) {
  const a = attempts.get(k) || { n: 0, until: 0 };
  a.n++;
  if (a.n >= 5) a.until = now() + Math.min(15 * 60e3, 30e3 * 2 ** (a.n - 5));
  attempts.set(k, a);
}
setInterval(() => { for (const [k, a] of attempts) if (a.until < now() - 36e5) attempts.delete(k); }, 36e5).unref();

/* ------------------------------ user model --------------------------- */
const publicUser = u => ({
  id: u.id, username: u.username, name: u.name, role: u.role,
  tabs: u.role === 'admin' ? TABS.slice() : (u.tabs || []),
  disabled: !!u.disabled, createdAt: u.createdAt,
});
const activeAdmins = () => users.users.filter(u => u.role === 'admin' && !u.disabled);
function keyAllowed(u, key) {
  if (key.startsWith('MASTER_SUITE_')) return false;       // per-device UI prefs
  if (u.role === 'admin') return true;
  const tab = KEY_TAB[key];
  return !!tab && (u.tabs || []).includes(tab);
}
function cleanTabs(t) { return Array.isArray(t) ? TABS.filter(x => t.includes(x)) : []; }

/* ------------------------------ first-run ---------------------------- */
let setupCode = null;
function ensureSetupCode() {
  if (users.users.length) { setupCode = null; try { fs.unlinkSync(path.join(DATA_DIR, 'SETUP_CODE.txt')); } catch (e) {} return; }
  setupCode = String(crypto.randomInt(100000, 999999));
  fs.writeFileSync(path.join(DATA_DIR, 'SETUP_CODE.txt'), setupCode + '\n');
  console.log('\n  First-time setup code (needed when opening from another device): ' + setupCode + '\n');
}
ensureSetupCode();

/* ------------------------------ backups ------------------------------ */
function dailyBackup() {
  try {
    if (!fs.existsSync(F_STORE)) return;
    const d = new Date(); const p = n => String(n).padStart(2, '0');
    const name = `store-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}.json`;
    const dest = path.join(BACKUP_DIR, name);
    if (!fs.existsSync(dest)) fs.copyFileSync(F_STORE, dest);
    const files = fs.readdirSync(BACKUP_DIR).filter(f => /^store-.*\.json$/.test(f)).sort();
    files.slice(0, Math.max(0, files.length - 14)).forEach(f => fs.unlinkSync(path.join(BACKUP_DIR, f)));
  } catch (e) { console.error('backup failed', e.message); }
}
dailyBackup(); setInterval(dailyBackup, 36e5).unref();

/* ------------------------------ static ------------------------------- */
const fileCache = new Map();
function cachedFile(f) {
  const st = fs.statSync(f);
  const c = fileCache.get(f);
  if (c && c.mtime === st.mtimeMs) return c.buf;
  const buf = fs.readFileSync(f); fileCache.set(f, { mtime: st.mtimeMs, buf });
  return buf;
}
function appHtml() {
  const html = cachedFile(APP_FILE).toString('utf8');
  const tag = '<script src="/assets/auth-client.js"></script>';
  return html.includes('</body>') ? html.replace('</body>', tag + '\n</body>') : html + tag;
}

/* ------------------------------ router ------------------------------- */
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const p = url.pathname;
    const method = req.method;

    // CSRF: same-origin only for anything that changes state
    if (method !== 'GET' && method !== 'HEAD') {
      const o = req.headers.origin;
      if (o) { let h = ''; try { h = new URL(o).host; } catch (e) {} if (h !== req.headers.host) return fail(res, 403, 'Forbidden'); }
    }

    /* ---------- pages ---------- */
    if (method === 'GET' && (p === '/' || p === '/index.html')) {
      const a = getAuth(req);
      if (!a) return send(res, 200, cachedFile(path.join(PUB, 'login.html')));
      return send(res, 200, appHtml());
    }
    if (method === 'GET' && p === '/assets/auth-client.js') {
      if (!getAuth(req)) return fail(res, 401, 'login দরকার');
      return send(res, 200, cachedFile(path.join(PUB, 'auth-client.js')), { 'Content-Type': 'application/javascript; charset=utf-8' });
    }
    if (method === 'GET' && p === '/healthz') return send(res, 200, { ok: true });

    if (!p.startsWith('/api/')) return send(res, 404, 'Not found');

    /* ---------- public API ---------- */
    if (p === '/api/status' && method === 'GET') {
      const a = getAuth(req);
      return send(res, 200, {
        setup: users.users.length === 0,
        needCode: users.users.length === 0 && !isDirectLoopback(req),
        loggedIn: !!a,
      });
    }

    if (p === '/api/setup' && method === 'POST') {
      if (users.users.length) return fail(res, 403, 'সেটআপ আগেই সম্পন্ন হয়েছে');
      const b = await readBody(req, 8192);
      if (!isDirectLoopback(req) && String(b.code || '').trim() !== setupCode) return fail(res, 403, 'সেটআপ কোড ভুল (server console / data/SETUP_CODE.txt দেখুন)');
      if (!validUsername(b.username)) return fail(res, 400, 'ইউজারনেম ৩-৩২ অক্ষর (a-z, 0-9, _ . - @) হতে হবে');
      if (!validPw(b.password)) return fail(res, 400, 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে');
      const { salt, hash } = await hashPw(b.password);
      const u = { id: uid(), username: b.username, name: String(b.name || b.username).slice(0, 60), role: 'admin', tabs: TABS.slice(), salt, hash, disabled: false, createdAt: now() };
      users.users.push(u); saveUsers(); ensureSetupCode();
      const s = createSession(u.id, true);
      return send(res, 200, { ok: true, user: publicUser(u) }, { 'Set-Cookie': cookieHeader(req, s.token, s.maxAge) });
    }

    if (p === '/api/login' && method === 'POST') {
      const b = await readBody(req, 4096);
      const k = throttleKey(req, b.username);
      const wait = lockedFor(k);
      if (wait) return fail(res, 429, `অনেকবার ভুল হয়েছে। ${Math.ceil(wait / 1000)} সেকেন্ড পরে চেষ্টা করুন`);
      const u = users.users.find(x => x.username.toLowerCase() === String(b.username || '').toLowerCase());
      const ok = await checkPw(String(b.password || ''), u);
      if (!ok || u.disabled) {
        recordFail(k);
        return fail(res, 401, u && u.disabled && ok ? 'এই অ্যাকাউন্ট বন্ধ করা আছে' : 'ইউজারনেম বা পাসওয়ার্ড ভুল');
      }
      attempts.delete(k);
      const s = createSession(u.id, !!b.remember);
      return send(res, 200, { ok: true, user: publicUser(u) }, { 'Set-Cookie': cookieHeader(req, s.token, s.maxAge) });
    }

    /* ---------- authenticated API ---------- */
    const auth = getAuth(req);
    if (!auth) return fail(res, 401, 'login দরকার');
    const me = auth.user;

    if (p === '/api/logout' && method === 'POST') {
      sessions.delete(auth.tokenHash); saveSessions();
      return send(res, 200, { ok: true }, { 'Set-Cookie': cookieHeader(req, '', 0) });
    }
    if (p === '/api/me' && method === 'GET') return send(res, 200, { user: publicUser(me) });

    if (p === '/api/password' && method === 'POST') {
      const b = await readBody(req, 4096);
      if (!(await checkPw(String(b.current || ''), me))) return fail(res, 400, 'বর্তমান পাসওয়ার্ড ভুল');
      if (!validPw(b.next)) return fail(res, 400, 'নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে');
      const { salt, hash } = await hashPw(b.next);
      me.salt = salt; me.hash = hash; saveUsers(); revokeUserSessions(me.id, auth.tokenHash);
      return send(res, 200, { ok: true });
    }

    /* ---------- data sync ---------- */
    if (p === '/api/sync' && method === 'POST') {
      const b = await readBody(req, 60 * 1024 * 1024);
      const since = +b.since || 0;
      let wrote = 0;
      if (b.changes && typeof b.changes === 'object') {
        for (const [k, v] of Object.entries(b.changes)) {
          if (k.length > 200 || !keyAllowed(me, k)) continue;
          if (v === null) { if (store.keys[k]) { store.rev++; store.keys[k] = { v: null, rev: store.rev, by: me.username, at: now() }; wrote++; } continue; }
          if (typeof v !== 'string') continue;
          if (store.keys[k] && store.keys[k].v === v) continue;
          store.rev++; store.keys[k] = { v, rev: store.rev, by: me.username, at: now() }; wrote++;
        }
        if (wrote) saveStoreSoon();
      }
      const out = {};
      for (const [k, e] of Object.entries(store.keys)) if (e.rev > since && keyAllowed(me, k)) out[k] = e.v;
      return send(res, 200, { rev: store.rev, keys: out, empty: Object.keys(store.keys).length === 0 });
    }

    /* ---------- admin API ---------- */
    if (p.startsWith('/api/users') || p === '/api/backup') {
      if (me.role !== 'admin') return fail(res, 403, 'শুধু Admin এই কাজ করতে পারবে');

      if (p === '/api/backup' && method === 'GET') {
        flushStore();
        const name = `master-suite-backup-${new Date().toISOString().slice(0, 10)}.json`;
        return send(res, 200, JSON.stringify({ exportedAt: new Date().toISOString(), rev: store.rev, keys: Object.fromEntries(Object.entries(store.keys).filter(([, e]) => e.v !== null).map(([k, e]) => [k, e.v])) }),
          { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': `attachment; filename="${name}"` });
      }
      if (p === '/api/users' && method === 'GET') return send(res, 200, { users: users.users.map(publicUser) });

      if (p === '/api/users' && method === 'POST') {
        const b = await readBody(req, 8192);
        if (!validUsername(b.username)) return fail(res, 400, 'ইউজারনেম ৩-৩২ অক্ষর (a-z, 0-9, _ . - @) হতে হবে');
        if (users.users.some(x => x.username.toLowerCase() === b.username.toLowerCase())) return fail(res, 409, 'এই ইউজারনেম আগে থেকেই আছে');
        if (!validPw(b.password)) return fail(res, 400, 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে');
        const { salt, hash } = await hashPw(b.password);
        const role = b.role === 'admin' ? 'admin' : 'staff';
        const u = { id: uid(), username: b.username, name: String(b.name || b.username).slice(0, 60), role, tabs: role === 'admin' ? TABS.slice() : cleanTabs(b.tabs), salt, hash, disabled: false, createdAt: now() };
        users.users.push(u); saveUsers();
        return send(res, 200, { user: publicUser(u) });
      }

      const m = p.match(/^\/api\/users\/([a-f0-9]+)$/);
      if (m) {
        const t = users.users.find(x => x.id === m[1]);
        if (!t) return fail(res, 404, 'ইউজার পাওয়া যায়নি');
        if (method === 'PUT') {
          const b = await readBody(req, 8192);
          const wasAdmin = t.role === 'admin' && !t.disabled;
          const next = {
            role: b.role === 'admin' ? 'admin' : (b.role === 'staff' ? 'staff' : t.role),
            disabled: b.disabled === undefined ? t.disabled : !!b.disabled,
          };
          if (wasAdmin && (next.role !== 'admin' || next.disabled) && activeAdmins().length <= 1) return fail(res, 400, 'কমপক্ষে একজন সক্রিয় Admin থাকতে হবে');
          if (t.id === me.id && next.disabled) return fail(res, 400, 'নিজের অ্যাকাউন্ট বন্ধ করা যাবে না');
          if (b.name !== undefined) t.name = String(b.name).slice(0, 60) || t.username;
          t.role = next.role; t.disabled = next.disabled;
          if (b.tabs !== undefined) t.tabs = cleanTabs(b.tabs);
          if (t.role === 'admin') t.tabs = TABS.slice();
          if (b.password) {
            if (!validPw(b.password)) return fail(res, 400, 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে');
            const h = await hashPw(b.password); t.salt = h.salt; t.hash = h.hash;
            revokeUserSessions(t.id, t.id === me.id ? auth.tokenHash : undefined);
          }
          if (t.disabled) revokeUserSessions(t.id);
          saveUsers();
          return send(res, 200, { user: publicUser(t) });
        }
        if (method === 'DELETE') {
          if (t.id === me.id) return fail(res, 400, 'নিজের অ্যাকাউন্ট ডিলিট করা যাবে না');
          if (t.role === 'admin' && !t.disabled && activeAdmins().length <= 1) return fail(res, 400, 'কমপক্ষে একজন সক্রিয় Admin থাকতে হবে');
          users.users = users.users.filter(x => x.id !== t.id); saveUsers(); revokeUserSessions(t.id);
          return send(res, 200, { ok: true });
        }
      }
    }

    return fail(res, 404, 'Not found');
  } catch (e) {
    if (e && e.status) return fail(res, e.status, e.status === 413 ? 'ডাটা অনেক বড়' : 'ভুল অনুরোধ');
    console.error(e);
    try { fail(res, 500, 'Server error'); } catch (_) {}
  }
});

if (process.argv[2] === 'reset-password') {
  // usage: node server.js reset-password <username> <newpassword>
  (async () => {
    const name = String(process.argv[3] || ''), pw = process.argv[4];
    const u = users.users.find(x => x.username.toLowerCase() === name.toLowerCase());
    if (!u || !validPw(pw)) { console.log('Usage: node server.js reset-password <username> <new password (min 6 chars)>'); process.exit(1); }
    const h = await hashPw(pw); u.salt = h.salt; u.hash = h.hash; u.disabled = false;
    saveUsers(); sessions.clear(); saveSessions();
    console.log('Password reset done for @' + u.username); process.exit(0);
  })();
} else {
  server.listen(PORT, HOST, () => {
    console.log(`Master Suite server running → http://localhost:${PORT}`);
    console.log(`Data folder: ${DATA_DIR}`);
  });
}
process.on('SIGINT', () => { flushStore(); process.exit(0); });
process.on('SIGTERM', () => { flushStore(); process.exit(0); });
