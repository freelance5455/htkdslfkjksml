/* Master Suite – auth + sync client (injected by server.js into the app page) */
(function () {
  'use strict';
  const TABS = [
    ['counting', 'DSR Counting'], ['due', 'Due Database'], ['bank', 'Daily Bank'],
    ['stock', 'Product & Payment'], ['fin', 'Income & Expense'],
  ];
  const KEY_TAB = {
    DSR_EXCEL_STYLE_DB_V4: 'counting', DSR_EXCEL_STYLE_DSR_LIST_V4: 'counting', DSR_FULL_PROD_DUE_DB_V6: 'counting', DSR_SIM_HLR_DATABASE_V8: 'counting',
    due_entries: 'due', due_entries_reset_v1: 'due',
    master_dash_db: 'bank', master_dash_config: 'bank', master_dash_db_reset_v1: 'bank', master_dash_config_reset_v1: 'bank',
    dh_simData: 'stock', dh_scData: 'stock', dh_simProducts: 'stock', dh_scProducts: 'stock',
    incomeData: 'fin', expenseData: 'fin', incomeCategories: 'fin', expenseCategories: 'fin', categories_reset_v1: 'fin',
  };
  const PREFIX = 'MASTER_SUITE_';
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));

  let me = null, rev = 0, busy = false, loopTimer = null, online = true;
  const known = {};            // key -> hash of last synced value
  const stale = new Set();     // loaded tabs whose data changed remotely

  /* ------------------------------ helpers ------------------------------ */
  function hash(s) {
    if (s == null) return 'n';
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return s.length + ':' + (h >>> 0).toString(36);
  }
  function syncKeys() {
    const out = [];
    for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && !k.startsWith(PREFIX)) out.push(k); }
    return out;
  }
  function clearLocal() {
    syncKeys().forEach(k => localStorage.removeItem(k));
    localStorage.removeItem(PREFIX + 'UID');
  }
  async function api(path, opt) {
    opt = opt || {};
    const init = { method: opt.method || 'GET', credentials: 'same-origin', headers: {} };
    if (opt.body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opt.body); }
    if (opt.keepalive) init.keepalive = true;
    const r = await fetch(path, init);
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (r.status === 401) { location.reload(); throw new Error('session'); }
    if (!r.ok) { const e = new Error(j.error || ('Error ' + r.status)); e.status = r.status; throw e; }
    return j;
  }

  /* -------------------------------- UI css ------------------------------ */
  const css = document.createElement('style');
  css.textContent = `
  .ms-boot{position:fixed;inset:0;z-index:9999;display:grid;place-items:center;background:var(--bg,#070b14);color:var(--muted,#8d9ab5);font:600 14px 'Plus Jakarta Sans','Hind Siliguri',sans-serif}
  .ms-boot .sp{width:34px;height:34px;border-radius:50%;border:3px solid var(--line,#333);border-top-color:var(--accent,#4f8cff);animation:msSp 1s linear infinite;margin:0 auto 12px}
  @keyframes msSp{to{transform:rotate(360deg)}}
  .ms-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#2fd39a;margin-right:8px;vertical-align:middle}
  .ms-dot.pend{background:#ffb84d}.ms-dot.off{background:#ff6b7d}
  .ms-wrap{position:relative}
  .ms-menu{position:absolute;right:0;top:46px;min-width:230px;background:var(--panel-solid,#111a2e);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow);padding:6px;z-index:60;display:none}
  .ms-menu.show{display:block}
  .ms-menu .who{padding:10px 12px;border-bottom:1px solid var(--line);margin-bottom:4px}
  .ms-menu .who b{display:block;font-size:13.5px}.ms-menu .who small{color:var(--muted);font-size:11.5px}
  .ms-menu button{display:flex;width:100%;align-items:center;gap:10px;border:0;background:transparent;color:var(--text);font:inherit;font-size:13px;font-weight:600;padding:10px 12px;border-radius:9px;cursor:pointer;text-align:left}
  .ms-menu button:hover{background:rgba(127,150,200,.12)}
  .ms-menu button.danger{color:var(--bad,#ff6b7d)}
  .ms-back{position:fixed;inset:0;z-index:9000;background:rgba(0,0,0,.55);display:grid;place-items:center;padding:16px}
  .ms-modal{width:100%;max-width:640px;max-height:92vh;display:flex;flex-direction:column;background:var(--panel-solid,#111a2e);color:var(--text);border:1px solid var(--line);border-radius:18px;box-shadow:var(--shadow)}
  .ms-modal header{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--line)}
  .ms-modal header h3{font-size:16px;font-weight:800}
  .ms-x{border:0;background:transparent;color:var(--muted);font-size:20px;cursor:pointer;width:34px;height:34px;border-radius:9px}
  .ms-x:hover{background:rgba(127,150,200,.12)}
  .ms-body{padding:18px 20px;overflow:auto}
  .ms-body label{display:block;font-size:11.5px;font-weight:700;color:var(--muted);margin:12px 0 5px;letter-spacing:.3px}
  .ms-body input[type=text],.ms-body input[type=password],.ms-body select{width:100%;height:42px;padding:0 12px;border-radius:10px;border:1px solid var(--line);background:transparent;color:var(--text);font:inherit;font-size:14px;outline:none}
  .ms-body select option{background:var(--panel-solid,#111a2e);color:var(--text)}
  .ms-body input:focus,.ms-body select:focus{border-color:var(--accent)}
  .ms-tabs{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:4px}
  .ms-chk{display:flex!important;align-items:center;gap:8px;margin:0!important;padding:9px 11px;border:1px solid var(--line);border-radius:10px;font-size:13px!important;color:var(--text)!important;font-weight:600!important;cursor:pointer}
  .ms-chk input{accent-color:var(--accent);width:15px;height:15px}
  .ms-row{display:flex;gap:10px;justify-content:flex-end;margin-top:18px;flex-wrap:wrap}
  .ms-btn{height:40px;padding:0 16px;border-radius:10px;border:1px solid var(--line);background:transparent;color:var(--text);font:inherit;font-size:13px;font-weight:700;cursor:pointer}
  .ms-btn:hover{border-color:var(--accent)}
  .ms-btn.pri{border:0;color:#fff;background:linear-gradient(135deg,var(--accent),var(--accent2))}
  .ms-btn.del{color:var(--bad,#ff6b7d)}
  .ms-btn.sm{height:32px;padding:0 11px;font-size:12px}
  .ms-err{margin-top:12px;padding:9px 12px;border-radius:9px;background:rgba(255,107,125,.12);border:1px solid rgba(255,107,125,.35);color:var(--bad,#ff6b7d);font-size:13px;display:none}
  .ms-ok{margin-top:12px;padding:9px 12px;border-radius:9px;background:rgba(47,211,154,.12);border:1px solid rgba(47,211,154,.35);color:var(--ok,#2fd39a);font-size:13px;display:none}
  .ms-ulist{display:flex;flex-direction:column;gap:8px;margin-top:12px}
  .ms-u{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid var(--line);border-radius:12px;flex-wrap:wrap}
  .ms-u .i{flex:1;min-width:150px}.ms-u .i b{font-size:14px}.ms-u .i small{display:block;color:var(--muted);font-size:11.5px;margin-top:2px}
  .ms-tag{font-size:10.5px;font-weight:800;padding:3px 8px;border-radius:99px;background:rgba(79,140,255,.18);color:var(--accent);margin-left:6px;vertical-align:middle}
  .ms-tag.off{background:rgba(255,107,125,.18);color:var(--bad,#ff6b7d)}
  .ms-toast{position:fixed;right:18px;bottom:18px;z-index:9500;max-width:340px;background:var(--panel-solid,#111a2e);color:var(--text);border:1px solid var(--accent);border-radius:14px;padding:12px 14px;box-shadow:var(--shadow);font:600 13px 'Plus Jakarta Sans','Hind Siliguri',sans-serif;display:flex;align-items:center;gap:12px}
  `;
  document.head.appendChild(css);

  const boot = document.createElement('div');
  boot.className = 'ms-boot';
  boot.innerHTML = '<div><div class="sp"></div><span id="msBootTxt">ডাটা লোড হচ্ছে…</span></div>';
  document.body.appendChild(boot);

  function toast(msg, actionLabel, action) {
    const old = $('.ms-toast'); if (old) old.remove();
    const t = document.createElement('div'); t.className = 'ms-toast';
    t.innerHTML = '<span>' + esc(msg) + '</span>';
    if (actionLabel) {
      const b = document.createElement('button'); b.className = 'ms-btn pri sm'; b.textContent = actionLabel;
      b.onclick = () => { t.remove(); action && action(); }; t.appendChild(b);
    }
    const x = document.createElement('button'); x.className = 'ms-x'; x.textContent = '×'; x.onclick = () => t.remove(); t.appendChild(x);
    document.body.appendChild(t);
    setTimeout(() => t.isConnected && t.remove(), 12000);
  }

  /* -------------------------------- sync ------------------------------- */
  function setDot(state) {
    const d = $('#msDot'); if (!d) return;
    d.className = 'ms-dot' + (state === 'pend' ? ' pend' : state === 'off' ? ' off' : '');
    d.title = state === 'off' ? 'অফলাইন – সার্ভারে সেভ হচ্ছে না' : state === 'pend' ? 'সেভ হচ্ছে…' : 'সার্ভারে সেভ আছে';
  }
  function reloadTab(id) {
    const f = $('#view-' + id + ' iframe'), ld = $('#view-' + id + ' .loader');
    const app = APPS.find(a => a.id === id);
    if (f && app) { ld && ld.classList.remove('hide'); f.srcdoc = b64(app.data); }
  }

  async function sync(keepalive) {
    if (busy) return; busy = true;
    try {
      const changes = {}, sent = {};
      const keys = syncKeys(), keySet = new Set(keys);
      for (const k of keys) { const v = localStorage.getItem(k), h = hash(v); if (known[k] !== h) { changes[k] = v; sent[k] = h; } }
      for (const k of Object.keys(known)) if (!keySet.has(k)) { changes[k] = null; sent[k] = null; }
      const has = Object.keys(changes).length > 0;
      if (has) setDot('pend');
      const body = { since: rev, changes };
      const r = await api('/api/sync', { method: 'POST', body, keepalive: !!(keepalive && JSON.stringify(body).length < 60000) });
      for (const k in sent) { if (sent[k] === null) delete known[k]; else known[k] = sent[k]; }
      rev = r.rev;
      const touched = new Set(); let any = false;
      for (const [k, v] of Object.entries(r.keys || {})) {
        if (k in sent) continue;
        const lh = hash(localStorage.getItem(k));
        if (known[k] !== undefined ? lh !== known[k] : localStorage.getItem(k) !== null) continue; // edited locally meanwhile
        if (lh === hash(v)) { known[k] = lh; continue; }
        if (v === null) { localStorage.removeItem(k); delete known[k]; } else { localStorage.setItem(k, v); known[k] = hash(v); }
        any = true; touched.add(KEY_TAB[k] || '*');
      }
      if (any) {
        const ids = touched.has('*') ? TABS.map(t => t[0]) : [...touched];
        ids.forEach(id => { if (typeof loaded !== 'undefined' && loaded[id]) stale.add(id); });
        if (current === 'overview') renderOverview();
        else if (stale.has(current)) toast('অন্য ডিভাইস/ইউজার থেকে নতুন ডাটা এসেছে', 'রিফ্রেশ', () => { stale.delete(current); reloadTab(current); });
      }
      online = true; setDot('ok');
    } catch (e) {
      if (e.message !== 'session') { online = false; setDot('off'); }
      throw e;
    } finally { busy = false; }
  }
  function startLoop() {
    const tick = async () => {
      try { await sync(); } catch (e) {}
      loopTimer = setTimeout(tick, document.hidden ? 8000 : 2000);
    };
    loopTimer = setTimeout(tick, 2000);
    document.addEventListener('visibilitychange', () => { if (document.hidden) sync(true).catch(() => {}); else sync().catch(() => {}); });
    window.addEventListener('pagehide', () => { sync(true).catch(() => {}); });
  }

  /* ----------------------------- permissions --------------------------- */
  function allowedTabs() { return me.role === 'admin' ? TABS.map(t => t[0]) : me.tabs; }
  function overviewAllowed() { return me.role === 'admin' || me.tabs.length === TABS.length; }
  function applyPermissions() {
    const ok = new Set(allowedTabs());
    document.querySelectorAll('.nav').forEach(n => {
      const id = n.dataset.id;
      n.style.display = (id === 'overview' ? overviewAllowed() : ok.has(id)) ? '' : 'none';
    });
    document.querySelectorAll('.side .group').forEach(g => {
      let n = g.nextElementSibling, any = false;
      while (n && !n.classList.contains('group') && !n.classList.contains('side-foot')) { if (n.classList.contains('nav') && n.style.display !== 'none') any = true; n = n.nextElementSibling; }
      g.style.display = any ? '' : 'none';
    });
    const orig = window.show;
    window.show = function (id) {
      if (id === 'overview' ? !overviewAllowed() : !ok.has(id)) return;
      const wasLoaded = typeof loaded !== 'undefined' && loaded[id];
      orig(id);
      if (stale.has(id)) { stale.delete(id); if (wasLoaded) reloadTab(id); }
    };
  }

  /* ------------------------------- top bar ----------------------------- */
  function buildTopbar() {
    const host = $('.top'), theme = $('#themeBtn');
    const wrap = document.createElement('div'); wrap.className = 'ms-wrap';
    wrap.innerHTML = `<button class="tbtn" id="msUserBtn"><i class="ms-dot" id="msDot"></i>${esc(me.name)}</button>
      <div class="ms-menu" id="msMenu">
        <div class="who"><b>${esc(me.name)}</b><small>@${esc(me.username)} • ${me.role === 'admin' ? 'Admin' : 'Staff'}</small></div>
        <button data-a="pw">🔑 পাসওয়ার্ড পরিবর্তন</button>
        ${me.role === 'admin' ? '<button data-a="users">👥 ইউজার ম্যানেজমেন্ট</button><button data-a="backup">💾 ডাটা ব্যাকআপ ডাউনলোড</button>' : ''}
        <button data-a="out" class="danger">⎋ লগআউট</button>
      </div>`;
    host.insertBefore(wrap, theme);
    const menu = $('#msMenu');
    $('#msUserBtn').onclick = e => { e.stopPropagation(); menu.classList.toggle('show'); };
    document.addEventListener('click', e => { if (!menu.contains(e.target)) menu.classList.remove('show'); });
    menu.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return; menu.classList.remove('show');
      const a = b.dataset.a;
      if (a === 'pw') passwordModal();
      else if (a === 'users') usersModal();
      else if (a === 'backup') location.href = '/api/backup';
      else if (a === 'out') logout();
    });
  }
  async function logout() {
    try { await sync(); } catch (e) { if (e.message !== 'session' && !confirm('সার্ভারে সব ডাটা সেভ করা যায়নি (অফলাইন?)। তবুও লগআউট করলে এই ডিভাইসের সর্বশেষ পরিবর্তন হারাতে পারে। চালিয়ে যাবেন?')) return; }
    clearTimeout(loopTimer);
    try { await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' }); } catch (e) {}
    clearLocal(); location.reload();
  }

  /* -------------------------------- modals ----------------------------- */
  function modal(title, html) {
    const back = document.createElement('div'); back.className = 'ms-back';
    back.innerHTML = `<div class="ms-modal"><header><h3>${esc(title)}</h3><button class="ms-x" aria-label="close">×</button></header><div class="ms-body">${html}</div></div>`;
    const close = () => back.remove();
    $('.ms-x', back).onclick = close;
    back.addEventListener('mousedown', e => { if (e.target === back) close(); });
    document.body.appendChild(back);
    return { el: $('.ms-body', back), close };
  }
  const showMsg = (root, cls, m) => { const e = $(cls, root); e.textContent = m; e.style.display = 'block'; };

  function passwordModal() {
    const m = modal('পাসওয়ার্ড পরিবর্তন', `
      <label>বর্তমান পাসওয়ার্ড</label><input type="password" id="pw0" autocomplete="current-password">
      <label>নতুন পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)</label><input type="password" id="pw1" autocomplete="new-password">
      <label>নতুন পাসওয়ার্ড আবার</label><input type="password" id="pw2" autocomplete="new-password">
      <div class="ms-err"></div><div class="ms-ok"></div>
      <div class="ms-row"><button class="ms-btn" id="pwc">বাতিল</button><button class="ms-btn pri" id="pws">সেভ করুন</button></div>`);
    $('#pwc', m.el).onclick = m.close;
    $('#pws', m.el).onclick = async () => {
      const a = $('#pw0', m.el).value, b = $('#pw1', m.el).value, c = $('#pw2', m.el).value;
      $('.ms-err', m.el).style.display = 'none';
      if (b !== c) return showMsg(m.el, '.ms-err', 'নতুন পাসওয়ার্ড দুটি মিলছে না');
      try { await api('/api/password', { method: 'POST', body: { current: a, next: b } }); showMsg(m.el, '.ms-ok', 'পাসওয়ার্ড পরিবর্তন হয়েছে। অন্য ডিভাইসে আবার লগইন করতে হবে।'); setTimeout(m.close, 1800); }
      catch (e) { showMsg(m.el, '.ms-err', e.message); }
    };
  }

  async function usersModal() {
    const m = modal('ইউজার ম্যানেজমেন্ট', '<div class="empty">লোড হচ্ছে…</div>');
    let list = [];
    async function load() { list = (await api('/api/users')).users; renderList(); }
    function renderList() {
      m.el.innerHTML = `<div class="ms-row" style="margin:0;justify-content:space-between;align-items:center"><span style="color:var(--muted);font-size:12.5px">${list.length} জন ইউজার</span><button class="ms-btn pri" id="uadd">＋ নতুন ইউজার</button></div>
        <div class="ms-ulist">${list.map(u => `<div class="ms-u"><div class="i"><b>${esc(u.name)}</b>${u.role === 'admin' ? '<span class="ms-tag">Admin</span>' : ''}${u.disabled ? '<span class="ms-tag off">বন্ধ</span>' : ''}
          <small>@${esc(u.username)}${u.role === 'admin' ? ' • সব ট্যাব' : ' • ' + (u.tabs.length ? u.tabs.map(t => (TABS.find(x => x[0] === t) || [, t])[1]).join(', ') : 'কোনো ট্যাব নেই')}</small></div>
          <button class="ms-btn sm" data-e="${u.id}">এডিট</button>${u.id === me.id ? '' : `<button class="ms-btn sm del" data-d="${u.id}">ডিলিট</button>`}</div>`).join('')}</div>
        <div class="ms-err"></div>`;
      $('#uadd', m.el).onclick = () => renderForm(null);
      m.el.querySelectorAll('[data-e]').forEach(b => b.onclick = () => renderForm(list.find(u => u.id === b.dataset.e)));
      m.el.querySelectorAll('[data-d]').forEach(b => b.onclick = async () => {
        const u = list.find(x => x.id === b.dataset.d);
        if (!confirm(`"${u.name}" (@${u.username}) কে ডিলিট করবেন?`)) return;
        try { await api('/api/users/' + u.id, { method: 'DELETE' }); await load(); } catch (e) { showMsg(m.el, '.ms-err', e.message); }
      });
    }
    function renderForm(u) {
      const isNew = !u; const tabs = u ? u.tabs : TABS.map(t => t[0]);
      m.el.innerHTML = `
        <label>নাম</label><input type="text" id="fn" value="${esc(u ? u.name : '')}">
        <label>ইউজারনেম</label><input type="text" id="fu" value="${esc(u ? u.username : '')}" ${isNew ? '' : 'disabled'} autocapitalize="none" spellcheck="false">
        <label>${isNew ? 'পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)' : 'নতুন পাসওয়ার্ড (বদলাতে চাইলে লিখুন, না চাইলে খালি রাখুন)'}</label><input type="password" id="fp" autocomplete="new-password">
        <label>ভূমিকা</label><select id="fr"><option value="staff">Staff – শুধু অনুমোদিত ট্যাব</option><option value="admin">Admin – সব ট্যাব + ইউজার ম্যানেজমেন্ট</option></select>
        <div id="ftw"><label>অনুমোদিত ট্যাব</label><div class="ms-tabs">${TABS.map(t => `<label class="ms-chk"><input type="checkbox" value="${t[0]}" ${tabs.includes(t[0]) ? 'checked' : ''}>${esc(t[1])}</label>`).join('')}</div></div>
        ${isNew ? '' : `<label class="ms-chk" style="margin-top:14px!important"><input type="checkbox" id="fd" ${u.disabled ? 'checked' : ''} ${u.id === me.id ? 'disabled' : ''}>অ্যাকাউন্ট বন্ধ রাখো (লগইন করতে পারবে না)</label>`}
        <div class="ms-err"></div>
        <div class="ms-row"><button class="ms-btn" id="fc">← ফিরে যান</button><button class="ms-btn pri" id="fs">${isNew ? 'ইউজার তৈরি করুন' : 'সেভ করুন'}</button></div>`;
      $('#fr', m.el).value = u ? u.role : 'staff';
      const tw = $('#ftw', m.el), sync_ = () => { tw.style.display = $('#fr', m.el).value === 'admin' ? 'none' : ''; };
      $('#fr', m.el).onchange = sync_; sync_();
      $('#fc', m.el).onclick = renderList;
      $('#fs', m.el).onclick = async () => {
        const body = { name: $('#fn', m.el).value.trim(), role: $('#fr', m.el).value, tabs: [...m.el.querySelectorAll('.ms-tabs input:checked')].map(i => i.value) };
        const pw = $('#fp', m.el).value; if (pw) body.password = pw;
        try {
          if (isNew) { body.username = $('#fu', m.el).value.trim(); await api('/api/users', { method: 'POST', body }); }
          else { const d = $('#fd', m.el); if (d) body.disabled = d.checked; await api('/api/users/' + u.id, { method: 'PUT', body }); }
          await load();
        } catch (e) { showMsg(m.el, '.ms-err', e.message); }
      };
    }
    try { await load(); } catch (e) { m.el.innerHTML = '<div class="ms-err" style="display:block">' + esc(e.message) + '</div>'; }
  }

  /* --------------------------------- boot ------------------------------ */
  async function start() {
    try {
      me = (await api('/api/me')).user;
      const last = localStorage.getItem(PREFIX + 'UID');
      if (last && last !== me.id) clearLocal();           // another user used this browser before
      localStorage.setItem(PREFIX + 'UID', me.id);

      const r = await api('/api/sync', { method: 'POST', body: { since: 0, changes: {} } });
      rev = r.rev;
      if (r.empty) {                                     // first ever login: upload existing browser data
        const changes = {}, sent = {};
        syncKeys().forEach(k => { const v = localStorage.getItem(k); changes[k] = v; sent[k] = hash(v); });
        if (Object.keys(changes).length) { const r2 = await api('/api/sync', { method: 'POST', body: { since: rev, changes } }); rev = r2.rev; Object.assign(known, sent); }
      } else {
        for (const [k, v] of Object.entries(r.keys)) { if (v === null) localStorage.removeItem(k); else { localStorage.setItem(k, v); known[k] = hash(v); } }
        syncKeys().forEach(k => { if (!(k in known) && !(k in r.keys)) { /* local-only key: pushed by the loop */ } });
      }
    } catch (e) {
      if (e.message !== 'session') { $('#msBootTxt').textContent = 'সার্ভারের সাথে সংযোগ হয়নি: ' + e.message; }
      return;
    }
    buildTopbar(); applyPermissions(); setDot('ok');
    const first = overviewAllowed() ? 'overview' : allowedTabs()[0];
    if (!first) {
      $('#ovRoot').innerHTML = '<div class="empty" style="margin-top:60px">আপনাকে কোনো ট্যাবের অনুমতি দেওয়া হয়নি। Admin-এর সাথে যোগাযোগ করুন।</div>';
    } else if (first === 'overview') { renderOverview(); }
    else { window.show(first); }
    boot.remove();
    startLoop();
  }
  start();
})();
