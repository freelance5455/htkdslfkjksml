@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js install kora nei. https://nodejs.org theke LTS version install korun, tarpor abar chalan.
  pause
  exit /b
)
start "" http://localhost:3000
node server.js
pause
