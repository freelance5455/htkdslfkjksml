// Simple WebSocket signaling relay. Host this on a trusted server with TLS (wss://).
const http = require('http');
const WebSocket = require('ws');
const server = http.createServer((req,res)=>{res.writeHead(200);res.end('Vishal Live Camera signaling server');});
const wss = new WebSocket.Server({server});
const rooms = new Map();
wss.on('connection', ws => {
  ws.on('message', raw => {
    let m; try { m=JSON.parse(raw); } catch { return; }
    if (m.type==='join') {
      if (!/^\d{6}$/.test(m.room||'') || !['host','viewer'].includes(m.role)) return;
      ws.room=m.room;
      if (!rooms.has(m.room)) rooms.set(m.room,new Set());
      const r=rooms.get(m.room);
      if (r.size>=2) { ws.send(JSON.stringify({type:'error',message:'इस कोड पर दो फोन पहले से जुड़े हैं'})); ws.close(); return; }
      r.add(ws);
      if (r.size===2) for (const c of r) if(c.readyState===1)c.send(JSON.stringify({type:'peer-ready'}));
      return;
    }
    if (!ws.room) return;
    const r=rooms.get(ws.room); if(!r)return;
    for(const c of r) if(c!==ws&&c.readyState===1)c.send(JSON.stringify(m));
  });
  ws.on('close',()=>{if(ws.room&&rooms.has(ws.room)){const r=rooms.get(ws.room);r.delete(ws);for(const c of r)if(c.readyState===1)c.send(JSON.stringify({type:'error',message:'दूसरा फोन डिस्कनेक्ट हो गया'}));if(!r.size)rooms.delete(ws.room);}});
});
server.listen(process.env.PORT||3000,()=>console.log('Signaling server ready'));
