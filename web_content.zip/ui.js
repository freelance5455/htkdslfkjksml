import {setPreset} from './settings.js';
import {getRecipes} from './src/campaign.js';

const moneyFormat=new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'});
const money=value=>moneyFormat.format(value);

const NOTE_KEY='ramenShiftNotes';
function readNotes(){try{return localStorage.getItem(NOTE_KEY)||'';}catch{return '';}}
function saveNotes(value){try{localStorage.setItem(NOTE_KEY,value);}catch{/* Notes remain editable for this session if storage is disabled. */}}

export function createUI({applyGraphics,onStart,onAccuse,onSleep,onPause,onResume,onRestart,onSoundToggle,onScareSetting=()=>{},scareLevel='full',graphicsPreset='medium',soundEnabled=true,onEvidence=()=>{},getEvidenceCounts=()=>({emails:0,profiles:0,ghostClips:0})}) {
  const menu=document.querySelector('#menu'),hud=document.querySelector('#hud'),computer=document.querySelector('#computer');
  const content=document.querySelector('#terminal-content'),sleep=document.querySelector('#sleep-button'),scare=document.querySelector('#scare'),decision=document.querySelector('#decision');
  const interact=document.querySelector('#interact');
  const menuPanels={home:document.querySelector('#menu-home'),settings:document.querySelector('#menu-settings'),about:document.querySelector('#menu-about'),ending:document.querySelector('#menu-ending')};
  function showMenuPage(page){for(const [name,panel] of Object.entries(menuPanels))panel.style.display=name===page?'block':'none';}
  let day=1,night=null,activeTab='mail',seen=[],selectedIndex=-1,computerWasOpen=false,shiftReady=false,served=0,mistakes=0,earnings=0,ghostCCTVAvailable=false;
  function render(tab=activeTab){
    activeTab=tab;
    if(tab==='mail'){
      onEvidence('email-'+day);content.innerHTML=`<strong>INBOX / ${night.emailFrom}</strong><h3>${night.subject}</h3><p>${night.emailBody}</p><p><b>Tonight’s lead:</b> ${night.clue}</p><p>Read the plates on CCTV, search the city database, and keep the records that connect customers to Lantern House.</p>`;
    }else if(tab==='cctv'){
      if(ghostCCTVAvailable)onEvidence('ghost-'+day);content.innerHTML='<strong>CAMERA NETWORK · PLATE READER</strong>'+(ghostCCTVAvailable?'<div class="feed ghost-feed"><strong>ARCHIVED MOTION · CAM 03</strong><span class="cctv-ghost" role="img" aria-label="A pale human figure appears in the grainy CCTV image"></span><br>00:09:14 · Figure at the road edge.<br>00:09:16 · Image tears. No plate detected.<br><small>Clip saved to the night archive.</small></div>':'<div class="feed">MOTION ARCHIVE<br>NO UNUSUAL MOVEMENT DETECTED</div>')+['FRONT ROAD','SERVICE LANE','ALLEY CAM'].map(cam=>{const cars=seen.filter(r=>r.cam===cam);return `<div class="feed">CAM ${cam}<br>${cars.length?cars.map(r=>`PLATE ${r.plate} · ${r.vehicle}`).join('<br>'):'NO VEHICLE IN FRAME'}</div>`;}).join('');
    }else if(tab==='lookup'){
      content.innerHTML=`<strong>CITY VEHICLE & RESIDENT DATABASE</strong><p>Enter a plate read from CCTV.</p><form id="plate-form"><input id="plate-input" maxlength="12" autocomplete="off" placeholder="RS-000" required><button>Search</button></form><div id="lookup-result">SEARCH READY</div>`;
      document.querySelector('#plate-form').addEventListener('submit',e=>{e.preventDefault();const plate=document.querySelector('#plate-input').value.trim().toUpperCase(),record=seen.find(r=>r.plate===plate),result=document.querySelector('#lookup-result');if(!record){result.textContent='NO MATCH IN TONIGHT’S CAMERA LOG.';return;}result.innerHTML=`<hr><strong>${record.name}</strong><p>Registered vehicle: ${record.vehicle}<br>Occupation: ${record.job}<br>Plate: ${record.plate}</p>${record.fileNote?`<p><b>Archive match:</b> ${record.fileNote}</p>`:''}`;if(record.killer)onEvidence('profile-'+day+'-'+record.plate);});
    }else if(tab==='notes'){
      content.innerHTML='<strong>PERSONAL NOTES</strong><p>Write down plates, names, patterns, and anything suspicious. Notes stay on this device.</p><textarea id="notes-input" maxlength="4000" aria-label="Investigation notes" placeholder="Type your notes here…"></textarea><small id="notes-count"></small>';
      const input=document.querySelector('#notes-input');input.value=readNotes();const count=document.querySelector('#notes-count');count.textContent=`${input.value.length}/4000`;input.addEventListener('input',()=>{saveNotes(input.value);count.textContent=`${input.value.length}/4000`;});
    }else if(tab==='recipes'){
      content.innerHTML='<strong>STAND RECIPE BOOK · NIGHT '+String(day).padStart(2,'0')+'</strong>'+getRecipes(day).map(recipe=>`<article class="recipe-card${recipe.unlocked?'':' locked'}"><header><b>${recipe.dish}</b><span>${recipe.unlocked?money(recipe.price):'UNLOCKS NIGHT '+String(recipe.unlockDay).padStart(2,'0')}</span></header>${recipe.unlocked?`<small>${recipe.type.toUpperCase()} · ${recipe.ingredients.join(' · ')}</small><p>${recipe.method}</p>`:'<p>Recipe not yet added to the family menu.</p>'}</article>`).join('');
    }else{
      const found=getEvidenceCounts();content.innerHTML=`<strong>NIGHT ${String(day).padStart(2,'0')} CASE FILE</strong><p>One killer is among tonight’s ${night.records.length} customers. Compare email clues, camera plates, and resident records.</p><p><b>Lead:</b> ${night.clue}</p><p><b>Arrivals recorded:</b> ${seen.length} / ${night.records.length}</p><div class="feed">ARCHIVE TRAIL<br>EMAILS ${found.emails}/7 · PLATE FILES ${found.profiles}/7 · GHOST CLIPS ${found.ghostClips}/6</div><p>More records unlock a fuller ending. You can still finish the week without finding everything.</p>`;
    }
    document.querySelectorAll('#tabs button').forEach(button=>button.classList.toggle('active',button.dataset.tab===tab));
  }
  function openComputer(tab='mail'){computer.style.display='block';render(tab);}
  function closeComputer(){computer.style.display='none';}
  const soundButtons=['#sound-toggle-menu','#sound-toggle-game','#pause-sound-toggle'].map(selector=>document.querySelector(selector));
  function updateSoundLabels(enabled){soundEnabled=Boolean(enabled);for(const button of soundButtons)button.textContent=button.id==='sound-toggle-game'?(soundEnabled?'SND ON':'SND OFF'):`Sound: ${soundEnabled?'On':'Off'}`;}
  updateSoundLabels(soundEnabled);soundButtons.forEach(button=>button.addEventListener('click',()=>updateSoundLabels(onSoundToggle())));
  document.querySelector('#quality').value=graphicsPreset;document.querySelector('#quality').addEventListener('change',e=>applyGraphics(e.target.value,setPreset(e.target.value)));
  document.querySelector('#scare-level').value=scareLevel;document.querySelector('#scare-level').addEventListener('change',e=>onScareSetting(e.target.value));
  document.querySelector('#open-settings').addEventListener('click',()=>showMenuPage('settings'));
  document.querySelector('#open-about').addEventListener('click',()=>showMenuPage('about'));
  document.querySelector('#settings-back').addEventListener('click',()=>showMenuPage('home'));
  document.querySelector('#about-back').addEventListener('click',()=>showMenuPage('home'));
  document.querySelector('#ending-back').addEventListener('click',()=>showMenuPage('home'));
  document.querySelector('#start').addEventListener('click',()=>{const status=document.querySelector('#runtime-status');if(status){status.style.display='none';status.textContent='';}menu.style.display='none';hud.style.display='block';try{onStart();}catch(error){menu.style.display='grid';hud.style.display='none';if(status){status.style.display='block';status.textContent=`Could not begin shift: ${error?.stack||error}`;}console.error(error);}});
  document.querySelector('#computer-button').addEventListener('click',()=>openComputer());
  document.querySelector('#close-computer').addEventListener('click',closeComputer);
  document.querySelectorAll('#tabs button').forEach(button=>button.addEventListener('click',()=>render(button.dataset.tab)));
  document.querySelector('#end-shift-button').addEventListener('click',()=>{if(shiftReady){selectedIndex=-1;document.querySelector('#sales-summary').textContent=`Sales: ${money(earnings)} · Served ${served}/${seen.length} · Mistakes ${mistakes}`;decision.style.display='grid';renderCandidates();}});
  function renderCandidates(){const list=document.querySelector('#suspect-list');list.innerHTML=seen.map((record,index)=>`<button class="suspect${index===selectedIndex?' selected':''}" data-suspect="${index}"><strong>${record.name}</strong><br>${record.plate} · ${record.vehicle}</button>`).join('');list.querySelectorAll('[data-suspect]').forEach(button=>button.addEventListener('click',()=>{selectedIndex=Number(button.dataset.suspect);renderCandidates();}));document.querySelector('#confirm-suspect').disabled=selectedIndex<0;}
  document.querySelector('#confirm-suspect').addEventListener('click',()=>{if(selectedIndex>=0){decision.style.display='none';onAccuse(seen[selectedIndex]);}});
  document.querySelector('#cancel-decision').addEventListener('click',()=>decision.style.display='none');
  document.querySelector('#sleep-button').addEventListener('click',()=>{if(sleep.style.display==='block'){sleep.style.display='none';closeComputer();onSleep();}});
  document.querySelector('#pause-button').addEventListener('click',onPause);
  document.querySelector('#resume-button').addEventListener('click',onResume);
  document.querySelector('#restart-button').addEventListener('click',onRestart);
  document.addEventListener('keydown',e=>{if(e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement)return;if(e.code==='KeyC'&&!e.repeat&&hud.style.display==='block'&&document.querySelector('#pause-overlay').style.display!=='grid')openComputer();if(e.code==='Escape'){if(computer.style.display==='block')closeComputer();else onPause?.();}if(e.code==='KeyP'&&!e.repeat&&hud.style.display==='block')onPause?.();});
  return {
    beginShift(number,data){day=number;night=data;activeTab='mail';seen=[];served=0;mistakes=0;earnings=0;shiftReady=false;ghostCCTVAvailable=false;hud.classList.remove('shift-ready');selectedIndex=-1;computer.style.display='none';scare.classList.remove('show');document.querySelector('#order-panel').style.display='none';document.querySelector('#arrival-count').textContent=`CUSTOMERS 0/${night.records.length} · SERVED 0 · ${money(0)}`;document.querySelector('#computer header strong').textContent=`STAND TERMINAL · NIGHT ${day}`;document.querySelector('#title').textContent=`NIGHT ${String(day).padStart(2,'0')} · 11:47 PM`;document.querySelector('#prompt').textContent='Check the new email, then watch the cameras.';sleep.style.display='none';document.querySelector('#end-shift-button').style.display='none';document.querySelector('#pause-overlay').style.display='none';decision.style.display='none';},
    setContinue(number,completed){document.querySelector('#start').textContent=completed?'PLAY AGAIN':'PLAY';document.querySelector('#play-caption').textContent=completed?'The last night is complete. Start again?':number>1?`Continue from night ${String(number).padStart(2,'0')}.`:'Your first night is waiting.';},
    openComputer,closeComputer,revealGhostCCTV(){ghostCCTVAvailable=true;if(computer.style.display==='block'&&activeTab==='cctv')render('cctv');},get computerIsOpen(){return computer.style.display==='block';},
    observe(record){seen.push(record);document.querySelector('#arrival-count').textContent=`CUSTOMERS ${seen.length}/${night.records.length} · SERVED ${served} · ${money(earnings)}`;if(activeTab==='cctv'&&computer.style.display==='block')render('cctv');},
    setShiftReady(ready){shiftReady=Boolean(ready);hud.classList.toggle('shift-ready',shiftReady);document.querySelector('#end-shift-button').style.display=shiftReady?'block':'none';},
    customerWaiting(record,remark){const panel=document.querySelector('#order-panel');panel.style.display='block';document.querySelector('#order-customer').textContent=record.name+' · AT THE WINDOW';document.querySelector('#order-details').textContent='“'+remark+'”';document.querySelector('#order-step').textContent='Interact at the service window to take their order.';},
    customerOrder(record,order,remark,step){const panel=document.querySelector('#order-panel');panel.style.display='block';document.querySelector('#order-customer').textContent=record.name+' · CUSTOMER ORDER';document.querySelector('#order-details').textContent='“'+remark+'”\n'+order.dish+' · '+order.ingredients.join(', ')+'\n'+money(order.price);this.serviceStep(step,order.type);},
    customerMistake(count,target,totalMistakes=count){mistakes=totalMistakes;document.querySelector('#order-step').textContent='Wrong station. '+target+' needed · this order: '+count;},
    customerHonk(record){const status=document.querySelector('#arrival-count');status.classList.remove('honk');void status.offsetWidth;status.classList.add('honk');setTimeout(()=>status.classList.remove('honk'),1000);document.querySelector('#prompt').textContent=record.name+' taps the car horn to get your attention.';},
    serviceStep(step,type='ramen'){const labels=type==='sushi'?['Take order at the window','Cook sushi rice at the stove','Assemble sushi at the prep counter','Serve sushi at the pass']:['Take order at the window','Cook noodles at the stove','Add broth and toppings at the bowl','Serve ramen at the pass'];document.querySelector('#order-step').textContent='STEP '+(step+1)+'/4 · '+(labels[step]||'');},
    customerServed(count,total,sales,record,price,totalMistakes=mistakes){served=count;earnings=sales;mistakes=totalMistakes;document.querySelector('#arrival-count').textContent='CUSTOMERS '+seen.length+'/'+total+' · SERVED '+served+' · '+money(earnings);document.querySelector('#order-panel').style.display='none';document.querySelector('#prompt').textContent=(record?.name||'Customer')+' pays '+money(price||0)+' and drives back into the fog. Sales: '+money(earnings)+'.';},
    updateContext({nearComputer,nearBed,solved,serviceLabel}){const bedReady=solved&&nearBed;const desktop=globalThis.matchMedia?.('(pointer:fine)').matches??false;sleep.style.display=bedReady&&desktop?'block':'none';interact.textContent=bedReady?'Sleep':serviceLabel|| (nearComputer?'Use':'Interact');},
    solved(){document.querySelector('#end-shift-button').style.display='none';document.querySelector('#prompt').textContent='Correct. Go to the bed in your room and sleep to continue.';},
    gameOver(){scare.classList.remove('show');document.querySelector('#pause-overlay').style.display='none';decision.style.display='none';computer.style.display='none';hud.style.display='none';document.querySelector('#game-over').style.display='grid';},
    setPrompt(text){document.querySelector('#prompt').textContent=text;},
    pause(){computerWasOpen=computer.style.display==='block';computer.style.display='none';document.querySelector('#pause-overlay').style.display='grid';},
    resume(){document.querySelector('#pause-overlay').style.display='none';if(computerWasOpen)computer.style.display='block';computerWasOpen=false;},
    flashScare(message='IT WAS WATCHING YOU',duration=1450){const word=scare.querySelector('.scare-word');if(word)word.textContent=message;scare.classList.remove('show');void scare.offsetWidth;scare.classList.add('show');setTimeout(()=>scare.classList.remove('show'),duration);},
    finish(ending){scare.classList.remove('show');document.querySelector('#pause-overlay').style.display='none';hud.style.display='none';computer.style.display='none';document.querySelector('#game-over').style.display='none';menu.style.display='grid';showMenuPage('ending');document.querySelector('#ending-rank').textContent=ending.rank;document.querySelector('#ending-title').textContent=ending.title;document.querySelector('#ending-copy').textContent=ending.body;document.querySelector('#ending-evidence').textContent=ending.evidence;document.querySelector('#play-caption').textContent='Seven shifts are over. The stand is finally quiet.';document.querySelector('#start').textContent='PLAY AGAIN';},
    resetToTitle(){hud.style.display='none';computer.style.display='none';document.querySelector('#game-over').style.display='none';document.querySelector('#pause-overlay').style.display='none';document.querySelector('#decision').style.display='none';document.querySelector('#order-panel').style.display='none';document.querySelector('#sleep-button').style.display='none';document.querySelector('#end-shift-button').style.display='none';scare.classList.remove('show');menu.style.display='grid';showMenuPage('home');}
  };
}
