window.UI = {
    elements: {},

    init() {
        this.elements = {
            dropZone: document.getElementById('drop-zone'),
            fileInput: document.getElementById('file-input'),
            chooseBtn: document.getElementById('choose-button'),
            clearBtn: document.getElementById('clear-button'),
            jsonBtn: document.getElementById('json-button'),
            txtBtn: document.getElementById('txt-button'),
            copyBtn: document.getElementById('copy-button'),
            fileCard: document.getElementById('file-card'),
            fileName: document.getElementById('file-name'),
            fileInfo: document.getElementById('file-info'),
            progressContainer: document.getElementById('progress-container'),
            progressBar: document.getElementById('progress-bar'),
            progressText: document.getElementById('progress-text'),
            statDex: document.getElementById('stat-dex'),
            statStrings: document.getElementById('stat-strings'),
            statClasses: document.getElementById('stat-classes'),
            statMethods: document.getElementById('stat-methods'),
            resultsContent: document.getElementById('results-content'),
            log: document.getElementById('log'),
            tabEditable: document.getElementById('tab-editable'),
            tabStrings: document.getElementById('tab-strings'),
            tabClasses: document.getElementById('tab-classes'),
            tabMethods: document.getElementById('tab-methods'),
            searchInput: document.getElementById('search-input')
        };

        this.bindEvents();
    },

    bindEvents() {
        if (this.elements.tabEditable) this.elements.tabEditable.onclick = () => this.setActiveTab('editable');
        if (this.elements.tabStrings) this.elements.tabStrings.onclick = () => this.setActiveTab('strings');
        if (this.elements.tabClasses) this.elements.tabClasses.onclick = () => this.setActiveTab('classes');
        if (this.elements.tabMethods) this.elements.tabMethods.onclick = () => this.setActiveTab('methods');

        if (this.elements.searchInput) {
            this.elements.searchInput.oninput = (e) => {
                AppState.searchQuery = e.target.value;
                this.renderTabContent();
            };
        }
    },

    log(message, type = 'info') {
        if (!this.elements.log) return;
        const entry = document.createElement('div');
        entry.style.color = type === 'error' ? '#ef4444' : (type === 'success' ? '#10b981' : '#a3e635');
        const time = new Date().toLocaleTimeString('ar-EG');
        entry.textContent = `[${time}] ${message}`;
        this.elements.log.appendChild(entry);
        this.elements.log.scrollTop = this.elements.log.scrollHeight;
    },

    updateProgress(percent, text = 'جاري المعالجة...') {
        if (this.elements.progressContainer) this.elements.progressContainer.classList.add('visible');
        if (this.elements.progressBar) this.elements.progressBar.style.width = `${percent}%`;
        if (this.elements.progressText) this.elements.progressText.textContent = `${text} (${percent}%)`;
    },

    hideProgress() {
        if (this.elements.progressContainer) this.elements.progressContainer.classList.remove('visible');
        if (this.elements.progressText) this.elements.progressText.textContent = '';
    },

    showFileInfo(name, size, hash) {
        if (this.elements.fileName) this.elements.fileName.textContent = name;
        if (this.elements.fileInfo) this.elements.fileInfo.textContent = `الحجم: ${Utils.formatSize(size)} | SHA-256: ${hash}`;
        if (this.elements.fileCard) this.elements.fileCard.classList.add('visible');
    },

    updateStats(dexCount, stringsCount, classesCount, methodsCount) {
        if (this.elements.statDex) this.elements.statDex.textContent = dexCount;
        if (this.elements.statStrings) this.elements.statStrings.textContent = stringsCount;
        if (this.elements.statClasses) this.elements.statClasses.textContent = classesCount;
        if (this.elements.statMethods) this.elements.statMethods.textContent = methodsCount;
    },

    setActiveTab(tabName) {
        AppState.activeTab = tabName;
        
        [this.elements.tabEditable, this.elements.tabStrings, this.elements.tabClasses, this.elements.tabMethods].forEach(btn => {
            if (btn) btn.classList.remove('active');
        });

        if (tabName === 'editable' && this.elements.tabEditable) this.elements.tabEditable.classList.add('active');
        if (tabName === 'strings' && this.elements.tabStrings) this.elements.tabStrings.classList.add('active');
        if (tabName === 'classes' && this.elements.tabClasses) this.elements.tabClasses.classList.add('active');
        if (tabName === 'methods' && this.elements.tabMethods) this.elements.tabMethods.classList.add('active');

        this.renderTabContent();
    },

    renderTabContent() {
        if (!this.elements.resultsContent) return;

        const tab = AppState.activeTab || 'editable';
        const query = (AppState.searchQuery || '').trim().toLowerCase();
        let list = AppState.parsedData[tab] || [];

        if (query) {
            list = list.filter(item => item.toLowerCase().includes(query));
        }

        const total = list.length;
        const limit = 500;
        const sliced = list.slice(0, limit);

        if (total === 0) {
            this.elements.resultsContent.textContent = query 
                ? `لم يتم العثور على أي نتائج تطابق البحث: "${query}"`
                : `لا توجد أهداف متوفرة في قسم ${tab.toUpperCase()}`;
            return;
        }

        let header = `--- [ ${tab.toUpperCase()} ] (إجمالي الأهداف: ${total.toLocaleString()}) ---\n`;
        if (total > limit) {
            header += `(عرض أول ${limit} عنصر رئيسي. استخدم مربع البحث لتحديد عناصر إضافية)\n\n`;
        } else {
            header += `\n`;
        }

        this.elements.resultsContent.textContent = header + sliced.join('\n');
    },

    resetView() {
        if (this.elements.fileCard) this.elements.fileCard.classList.remove('visible');
        if (this.elements.progressContainer) this.elements.progressContainer.classList.remove('visible');
        this.updateStats('-', 0, 0, 0);
        if (this.elements.resultsContent) {
            this.elements.resultsContent.textContent = 'بانتظار رفع أو اختيار ملف لبدء عمليات التفكيك الاستاتيكي...';
        }
        if (this.elements.log) this.elements.log.innerHTML = '';
        if (this.elements.fileInput) this.elements.fileInput.value = '';
        if (this.elements.searchInput) this.elements.searchInput.value = '';
        if (typeof AppState !== 'undefined') AppState.searchQuery = '';
    }
};

document.addEventListener('DOMContentLoaded', () => window.UI.init());
