'use strict';
/* ============================================================
   UI base: toast, modais acessíveis, áudio, wake lock, cronômetro, desfazer
   ============================================================ */
const $ = sel => document.querySelector(sel);

/* ---------- Toast ---------- */
let toastTimeout;
function showToast(msg, type=''){
  const el = $('#toast'); if(!el) return;
  el.textContent = msg; el.className = 'toast ' + type;
  void el.offsetWidth; el.classList.add('show');
  clearTimeout(toastTimeout); toastTimeout = setTimeout(()=>el.classList.remove('show'), 3000);
}
function srAnnounce(msg){ const el = $('#srLive'); if(!el) return; el.textContent = ''; setTimeout(()=>{ el.textContent = msg; }, 30); }

/* Celebração de conquista: não bloqueia o uso */
const achQueue = []; let achBusy = false;
function toastAchievement(id){ achQueue.push(id); if(!achBusy) nextAchToast(); }
function nextAchToast(){
  const id = achQueue.shift(), el = $('#achToast');
  if(!id || !el){ achBusy = false; return; }
  achBusy = true;
  const def = ACHIEVEMENTS.find(a=>a.id === id);
  U.clear(el);
  el.appendChild(U.el('span', { class:'ach-toast-ic', html:achIconSVG(def.icon, '#FFD76A', 26) }));
  const tx = U.el('div', { class:'ach-toast-tx' });
  tx.appendChild(U.el('small', { text:t('ach.unlocked') }));
  tx.appendChild(U.el('b', { text:t('ach.' + id + '.n') }));
  el.appendChild(tx);
  el.classList.add('show'); vibrate([60,40,60]); srAnnounce(t('ach.unlocked') + ': ' + t('ach.' + id + '.n'));
  setTimeout(()=>{ el.classList.remove('show'); setTimeout(nextAchToast, 350); }, 3200);
}

/* ---------- Modais (role=dialog, aria-modal, armadilha de foco, foco devolvido, Voltar do Android) ---------- */
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
function trapTab(container, e){
  if(e.key !== 'Tab') return;
  const items = [...container.querySelectorAll(FOCUSABLE)].filter(n=>n.offsetParent !== null || n === document.activeElement);
  if(!items.length){ e.preventDefault(); return; }
  const first = items[0], last = items[items.length-1];
  if(e.shiftKey && (document.activeElement === first || !container.contains(document.activeElement))){ e.preventDefault(); last.focus(); }
  else if(!e.shiftKey && (document.activeElement === last || !container.contains(document.activeElement))){ e.preventDefault(); first.focus(); }
}
const Modals = {
  cur:null, hasEntry:false, ignore:0, opener:null,
  open(spec){
    const host = $('#modal'), sheet = $('#modalSheet');
    if(!this.cur) this.opener = document.activeElement;
    this.cur = { onDismiss: spec.onDismiss || null, dismissable: spec.dismissable !== false };
    $('#modalTitle').textContent = spec.title || '';
    const body = $('#modalBody'), foot = $('#modalFoot');
    U.clear(body); U.clear(foot);
    sheet.className = 'modal-sheet' + (spec.tall ? ' tall' : '') + (spec.cls ? ' ' + spec.cls : '');
    $('#modalX').hidden = spec.dismissable === false;
    spec.build(body, foot);
    foot.style.display = foot.children.length ? '' : 'none';
    host.classList.add('active'); body.scrollTop = 0;
    if(!this.hasEntry && this.ignore === 0){ try{ history.pushState({pt:1}, ''); this.hasEntry = true; }catch(e){} }
    setTimeout(()=>{ const f = body.querySelector(FOCUSABLE) || $('#modalX'); if(f && !f.hidden) f.focus(); else { $('#modalTitle').setAttribute('tabindex','-1'); $('#modalTitle').focus(); } }, 30);
  },
  close(){
    if(!this.cur) return;
    const c = this.cur; this.cur = null;
    $('#modal').classList.remove('active');
    setTimeout(()=>{ if(!this.cur && this.hasEntry){ this.hasEntry = false; this.ignore++; try{ history.back(); }catch(e){ this.ignore--; } } }, 0);
    const op = this.opener; 
    if(c.onDismiss) c.onDismiss();
    if(!this.cur){ this.opener = null; if(op && op.focus && document.contains(op)) setTimeout(()=>{ try{ op.focus(); }catch(e){} }, 0); }
  },
  onPop(){
    if(this.ignore > 0){ this.ignore--; return; }
    if(this.cur){ if(this.cur.dismissable){ this.hasEntry = false; this.close(); } else { try{ history.pushState({pt:1}, ''); }catch(e){} } }
  }
};
function initModals(){
  window.addEventListener('popstate', ()=>Modals.onPop());
  $('#modal').addEventListener('click', e=>{ if(e.target === $('#modal') && Modals.cur && Modals.cur.dismissable) Modals.close(); });
  $('#modalX').addEventListener('click', ()=>Modals.close());
  document.addEventListener('keydown', e=>{
    if(Modals.cur){
      if(e.key === 'Escape' && Modals.cur.dismissable) Modals.close();
      else trapTab($('#modalSheet'), e);
    } else { const ob = $('#onboarding'); if(ob && !ob.hidden) trapTab(ob, e); }
  });
  document.addEventListener('focusin', e=>{
    const tg = e.target;
    if(tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.tagName === 'SELECT')) setTimeout(()=>{ try{ tg.scrollIntoView({block:'center', behavior:'smooth'}); }catch(_){} }, 300);
  });
}
function confirmDialog({ title, message, confirmText, cancelText, danger=true }){
  return new Promise(resolve=>{
    let settled = false; const done = v=>{ if(!settled){ settled = true; resolve(v); } };
    Modals.open({ title: title || t('dlg.confirm'), onDismiss:()=>done(false), build(body, foot){
      body.appendChild(U.el('p', { class:'dlg-msg', text:message || '' }));
      foot.appendChild(U.el('button', { class:'btn btn-ghost', type:'button', text:cancelText || t('btn.cancel'), onclick:()=>Modals.close() }));
      foot.appendChild(U.el('button', { class:'btn ' + (danger ? 'btn-danger' : 'btn-primary'), type:'button', text:confirmText || t('btn.confirm'), onclick:()=>{ done(true); Modals.close(); } }));
    }});
  });
}
/** items: [{label, icon, danger, disabled, opens, onClick}] */
function actionSheet(title, items){
  Modals.open({ title, build(body){
    body.classList.add('sheet-list');
    items.forEach(it=>{
      const b = U.el('button', { class:'sheet-item' + (it.danger ? ' danger' : ''), type:'button', disabled:it.disabled });
      b.appendChild(icon(it.icon || 'edit')); b.appendChild(document.createTextNode(it.label));
      b.addEventListener('click', ()=>{ if(it.opens) it.onClick(); else { Modals.close(); it.onClick(); } });
      body.appendChild(b);
    });
  }});
}

/* ---------- Áudio / vibração / Wake Lock ---------- */
let audioCtx = null;
function unlockAudio(){ try{ if(!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)(); if(audioCtx.state === 'suspended') audioCtx.resume(); }catch(e){} }
function beep(){
  if(!S().sound || !audioCtx) return;
  try{ [0,.22,.44].forEach(off=>{
    const o = audioCtx.createOscillator(), g = audioCtx.createGain(); o.type = 'sine'; o.frequency.value = 880;
    g.gain.setValueAtTime(0.0001, audioCtx.currentTime + off); g.gain.exponentialRampToValueAtTime(0.35, audioCtx.currentTime + off + .02); g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + off + .18);
    o.connect(g); g.connect(audioCtx.destination); o.start(audioCtx.currentTime + off); o.stop(audioCtx.currentTime + off + .2);
  }); }catch(e){}
}
function vibrate(p){ if(S().sound && navigator.vibrate){ try{ navigator.vibrate(p); }catch(e){} } }
let wakeLock = null;
async function syncWakeLock(){
  const want = !!State.active && document.visibilityState === 'visible';
  try{
    if(want && !wakeLock && 'wakeLock' in navigator){ wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', ()=>{ wakeLock = null; }); }
    else if(!want && wakeLock){ await wakeLock.release(); wakeLock = null; }
  }catch(e){ wakeLock = null; }
}

/* ---------- Cronômetro de descanso (baseado em timestamp) ---------- */
function persistRest(){ const rt = State.rest; if(rt.endAt == null) Storage.saveRest(null); else Storage.saveRest({ endAt:rt.endAt, pausedRemaining:rt.pausedRemaining, totalMs:rt.totalMs }); }
function restRemaining(){ const rt = State.rest; if(rt.endAt == null) return null; return rt.pausedRemaining != null ? rt.pausedRemaining : rt.endAt - Date.now(); }
function startRest(seconds){
  if(!seconds || seconds <= 0) return;
  unlockAudio(); const rt = State.rest;
  rt.totalMs = seconds * 1000; rt.endAt = Date.now() + rt.totalMs; rt.pausedRemaining = null; rt.finished = false;
  persistRest(); ensureRestTick(); renderRestTimer();
}
function ensureRestTick(){ const rt = State.rest; if(!rt.interval) rt.interval = setInterval(renderRestTimer, 250); }
function stopRestTick(){ const rt = State.rest; if(rt.interval){ clearInterval(rt.interval); rt.interval = null; } }
function renderRestTimer(){
  const el = $('#restTimer'), rt = State.rest, remaining = restRemaining();
  if(remaining === null){ el.classList.remove('show','finished'); document.body.classList.remove('has-timer'); stopRestTick(); return; }
  el.classList.add('show'); document.body.classList.add('has-timer');
  const pauseBtn = $('#restPause');
  if(remaining <= 0){
    if(!rt.finished){ rt.finished = true; beep(); vibrate([250,120,250,120,250]); }
    el.classList.add('finished'); $('#restLbl').textContent = t('rest.done'); pauseBtn.textContent = t('rest.restart');
    stopRestTick(); $('#restTime').textContent = '00:00'; $('#restBarFill').style.width = '0%'; return;
  }
  rt.finished = false; el.classList.remove('finished');
  $('#restLbl').textContent = rt.pausedRemaining != null ? t('rest.paused') : t('rest.title');
  pauseBtn.textContent = rt.pausedRemaining != null ? t('rest.resume') : t('rest.pause');
  $('#restTime').textContent = fmtClock(remaining);
  $('#restBarFill').style.width = (rt.totalMs > 0 ? Math.min(100, remaining / rt.totalMs * 100) : 0) + '%';
}
function closeRestTimer(){ const rt = State.rest; rt.endAt = null; rt.pausedRemaining = null; rt.finished = false; stopRestTick(); persistRest(); renderRestTimer(); }
function initRestTimer(){
  $('#restClose').addEventListener('click', closeRestTimer);
  $('#restPause').addEventListener('click', ()=>{
    const rt = State.rest; if(rt.endAt == null) return;
    if(rt.finished || restRemaining() <= 0){ rt.endAt = Date.now() + rt.totalMs; rt.pausedRemaining = null; rt.finished = false; }
    else if(rt.pausedRemaining != null){ rt.endAt = Date.now() + rt.pausedRemaining; rt.pausedRemaining = null; }
    else rt.pausedRemaining = Math.max(0, rt.endAt - Date.now());
    persistRest(); ensureRestTick(); renderRestTimer();
  });
  const adjust = delta=>{
    const rt = State.rest; if(rt.endAt == null) return;
    const rem = restRemaining();
    if(rem <= 0){ if(delta <= 0) return; rt.totalMs = delta; rt.endAt = Date.now() + delta; rt.pausedRemaining = null; rt.finished = false; }
    else if(rt.pausedRemaining != null) rt.pausedRemaining = Math.max(0, rt.pausedRemaining + delta);
    else rt.endAt += delta;
    const nr = restRemaining(); if(nr > rt.totalMs) rt.totalMs = nr;
    persistRest(); ensureRestTick(); renderRestTimer();
  };
  $('#restMinus').addEventListener('click', ()=>adjust(-15000));
  $('#restPlus').addEventListener('click', ()=>adjust(15000));
}

/* ---------- Desfazer por 30 s ---------- */
let undoTimer = null;
function showUndoBar(message){
  const bar = $('#undoBar'); if(!bar) return;
  $('#undoMsg').textContent = message; bar.classList.add('show'); bar.hidden = false;
  clearTimeout(undoTimer); undoTimer = setTimeout(hideUndoBar, UNDO_MS);
}
function hideUndoBar(){ const bar = $('#undoBar'); if(bar){ bar.classList.remove('show'); setTimeout(()=>{ if(!bar.classList.contains('show')) bar.hidden = true; }, 300); } clearTimeout(undoTimer); }
function doUndo(){
  const u = State.undo; hideUndoBar();
  if(!u || Date.now() > u.until){ showToast(t('undo.expired'), 'warn'); return; }
  State.data = u.snap.data; State.history = u.snap.history; State.active = u.snap.active; State.undo = null;
  persistData(); persistHistory(); persistActive(); closeRestTimer();
  rebuildGamification(); pickInitialDay(); syncWakeLock(); applyLanguage(); renderAll();
  showToast(t('undo.done'), 'success');
}
