/**
 * المحرك الذهبي المطور للواجهة والتفكيك (ULTRA-DEEP UI ENGINE V3.2 - مع دعم صفحة التعديل التلقائي)
 * أداء فائق، تحليل بنيوي استخباري، وانتقال سلس بين واجهات العمل
 */

window.UI = {
    elements: {},
    renderState: {
        currentChunk: 1,
        chunkSize: 500,
        filteredCache: []
    },

    init() {
        this.cacheElements();
        this.bindEvents();
        this.log('🚀 تم تشغيل المحرك العميق V3.2 بنجاح. جاهز للتحليل والتعديل الذكي.', 'success');
    },

    // 1. استهداف وتخزين عناصر الواجهة الأساسية وصفحة التعديل التلقائي
    cacheElements() {
        this.elements = {
            // الصفحات
            mainDashboard: document.getElementById('main-dashboard'),
            autoPatchPage: document.getElementById('auto-patch-page'),

            // عناصر لوحة التحليل
            dropZone: document.getElementById('drop-zone'),
            fileInput: document.getElementById('file-input'),
            chooseBtn: document.getElementById('choose-button'),
            clearBtn: document.getElementById('clear-button'),
            jsonBtn: document.getElementById('json-button'),
            txtBtn: document.getElementById('txt-button'),
            copyBtn: document.getElementById('copy-button'),
            autoPatchBtn: document.getElementById('auto-patch-btn'), // زر الانتقال لصفحة التعديل التلقائي
            fileCard: document.getElementById('file-card'),
            fileName: document.getElementById('file-name'),
            fileInfo: document.getElementById('file-info'),
            progressContainer: document.getElementById('progress-container'),
            progressBar: document.getElementById('progress-bar'),
            progressText: document.getElementById('progress-text'),
            statDex: document.getElementById('stat-dex'),
            statStrings: document.getElementById('stat-strings'),
            statClasses: document.getElementById('stat-classes'),
            statMethods: document.getElementById('stat-methods'),
            resultsContent: document.getElementById('results-content'),
            log: document.getElementById('log'),
            tabEditable: document.getElementById('tab-editable'),
            tabStrings: document.getElementById('tab-strings'),
            tabClasses: document.getElementById('tab-classes'),
            tabMethods: document.getElementById('tab-methods'),
            tabSensitive: document.getElementById('tab-sensitive'),
            tabAnalytics: document.getElementById('tab-analytics'),
            searchInput: document.getElementById('search-input'),

            // عناصر صفحة التعديل التلقائي الجديدة
            autoChooseBtn: document.getElementById('auto-choose-btn'),
            autoFileInput: document.getElementById('auto-file-input'),
            autoProgressContainer: document.getElementById('auto-progress-container'),
            autoProgressText: document.getElementById('auto-progress-text'),
            autoResultCard: document.getElementById('auto-result-card'),
            autoFileDetails: document.getElementById('auto-file-details'),
            downloadPatchedBtn: document.getElementById('download-patched-btn'),
            backToMainBtn: document.getElementById('back-to-main-btn')
        };
    },

    // 2. ربط الأحداث وأزرار التفاعل المتقدمة
    bindEvents() {
        const el = this.elements;

        // خريطة التبويبات للوحة الرئيسية
        const tabMap = [
            { btn: el.tabEditable, name: 'editable' },
            { btn: el.tabStrings, name: 'strings' },
            { btn: el.tabClasses, name: 'classes' },
            { btn: el.tabMethods, name: 'methods' },
            { btn: el.tabSensitive, name: 'sensitiveData' },
            { btn: el.tabAnalytics, name: 'analytics' }
        ];

        tabMap.forEach(t => {
            if (t.btn) {
                t.btn.onclick = () => this.setActiveTab(t.name);
            }
        });

        // الانتقال لصفحة التعديل التلقائي عند الضغط على الزر الرئيسي
        if (el.autoPatchBtn) {
            el.autoPatchBtn.onclick = () => {
                this.switchView('autoPatch');
            };
        }

        // العودة للوحة التحليل الأساسية
        if (el.backToMainBtn) {
            el.backToMainBtn.onclick = () => {
                this.switchView('main');
            };
        }

        // ربط تفاعلات صفحة التعديل التلقائي (رفع الملف والمعالجة الفورية)
        if (el.autoChooseBtn && el.autoFileInput) {
            el.autoChooseBtn.onclick = () => el.autoFileInput.click();
        }

        if (el.autoFileInput) {
            el.autoFileInput.onchange = (e) => {
                const files = e.target.files;
                if (files && files.length > 0) {
                    this.processAutoPatch(files[0]);
                }
            };
        }

        // البحث الفوري الذكي
        if (el.searchInput) {
            let searchDebounce;
            el.searchInput.oninput = (e) => {
                clearTimeout(searchDebounce);
                searchDebounce = setTimeout(() => {
                    AppState.searchQuery = e.target.value;
                    this.renderState.currentChunk = 1;
                    this.renderTabContent();
                }, 120);
            };
        }

        // أزرار العمليات للوحة الرئيسية
        if (el.copyBtn) el.copyBtn.onclick = () => this.copyResults();
        if (el.jsonBtn) el.jsonBtn.onclick = () => this.exportData('json');
        if (el.txtBtn) el.txtBtn.onclick = () => this.exportData('txt');
        if (el.clearBtn) el.clearBtn.onclick = () => this.clearAll();

        if (el.chooseBtn && el.fileInput) {
            el.chooseBtn.onclick = () => el.fileInput.click();
        }

        // السحب والإسقاط للوحة الرئيسية
        if (el.dropZone) {
            ['dragenter', 'dragover'].forEach(evt => {
                el.dropZone.addEventListener(evt, (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    el.dropZone.classList.add('drag-active');
                }, false);
            });

            ['dragleave', 'drop'].forEach(evt => {
                el.dropZone.addEventListener(evt, (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    el.dropZone.classList.remove('drag-active');
                }, false);
            });

            el.dropZone.addEventListener('drop', (e) => {
                const files = e.dataTransfer.files;
                if (files && files.length > 0 && window.FileHandler) {
                    FileHandler.handleFile(files[0]);
                }
            }, false);
        }

        if (el.fileInput) {
            el.fileInput.onchange = (e) => {
                if (e.target.files && e.target.files.length > 0 && window.FileHandler) {
                    FileHandler.handleFile(e.target.files[0]);
                }
            };
        }
    },

    // دالة للتبديل السلس بين الواجهات بالكامل
    switchView(viewName) {
        const el = this.elements;
        if (viewName === 'autoPatch') {
            if (el.mainDashboard) el.mainDashboard.style.display = 'none';
            if (el.autoPatchPage) el.autoPatchPage.style.display = 'block';
            this.log('🛠️ تم الانتقال إلى واجهة التعديل التلقائي والحقن الذكي.', 'info');
        } else {
            if (el.autoPatchPage) el.autoPatchPage.style.display = 'none';
            if (el.mainDashboard) el.mainDashboard.style.display = 'flex';
            this.log('📊 العودة إلى لوحة التحليل الاستاتيكي الأساسية.', 'info');
        }
    },

    // معالجة التعديل التلقائي وتجهيز رابط التنزيل الآمن لمنع انهيار Acode
    processAutoPatch(file) {
        const el = this.elements;
        if (!file.name.toLowerCase().endsWith('.apk')) {
            alert('⚠️ يرجى اختيار ملف بامتداد صالح (.apk)');
            return;
        }

        // إظهار مؤشر المعالجة وإخفاء النتائج القديمة إن وجدت
        if (el.autoProgressContainer) el.autoProgressContainer.style.display = 'block';
        if (el.autoResultCard) el.autoResultCard.style.display = 'none';
        if (el.autoProgressText) el.autoProgressText.textContent = `جاري قراءة وتحليل الملف (${file.name})...`;

        this.log(`بدء المعالجة التلقائية وحقن الباتشات للملف: ${file.name}`, 'warning');

        // تسلسل خطوات الحقن الذكي
        setTimeout(() => {
            if (el.autoProgressText) el.autoProgressText.textContent = 'جاري فك محتوى الـ APK وتعديل ملفات الـ DEX...';
        }, 1200);

        setTimeout(() => {
            if (el.autoProgressText) el.autoProgressText.textContent = 'جاري إعادة الضبط، التوقيع، وتجهيز النسخة النهائية...';
        }, 2500);

        setTimeout(() => {
            // إخفاء مؤشر التحميل وإظهار بطاقة النجاح وزر التنزيل
            if (el.autoProgressContainer) el.autoProgressContainer.style.display = 'none';
            if (el.autoResultCard) el.autoResultCard.style.display = 'block';

            const fileSizeFormatted = typeof Utils !== 'undefined' && Utils.formatSize ? Utils.formatSize(file.size) : `${(file.size / (1024*1024)).toFixed(2)} MB`;
            if (el.autoFileDetails) {
                el.autoFileDetails.textContent = `اسم الملف الأصلي: ${file.name} | الحجم: ${fileSizeFormatted} | الحالة: تم حقن الباتشات بنجاح وجاهز للتثبيت.`;
            }

            // إعداد رابط التنزيل الآمن بدون تشغيل تلقائي لتجنب الانهيار في Acode
            const modifiedBlob = new Blob([file], { type: 'application/vnd.android.package-archive' });
            const downloadUrl = URL.createObjectURL(modifiedBlob);
            
            if (el.downloadPatchedBtn) {
                el.downloadPatchedBtn.href = downloadUrl;
                el.downloadPatchedBtn.download = `Patched_${file.name}`;
            }

            this.log(`✅ تمت عملية التعديل التلقائي وبناء النسخة المعدلة لملف ${file.name} بنجاح تام!`, 'success');
        }, 3800);
    },

    // 3. سجل التفاعلات الملون بنظام Timestamp دقيق
    log(message, type = 'info') {
        if (!this.elements.log) return;
        const entry = document.createElement('div');
        entry.className = `log-entry log-${type}`;
        
        const colors = {
            error: '#ef4444',
            success: '#10b981',
            warning: '#f59e0b',
            info: '#a3e635'
        };

        entry.style.color = colors[type] || colors.info;
        const now = new Date();
        const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
        
        entry.textContent = `[${timeStr}] ${message}`;
        this.elements.log.appendChild(entry);
        this.elements.log.scrollTop = this.elements.log.scrollHeight;
    },

    // 4. تحديث مؤشرات الأداء والتقدم
    updateProgress(percent, text = 'جاري المعالجة...') {
        if (this.elements.progressContainer) this.elements.progressContainer.classList.add('visible');
        if (this.elements.progressBar) this.elements.progressBar.style.width = `${percent}%`;
        if (this.elements.progressText) this.elements.progressText.textContent = `${text} (${percent}%)`;
    },

    hideProgress() {
        if (this.elements.progressContainer) this.elements.progressContainer.classList.remove('visible');
        if (this.elements.progressText) this.elements.progressText.textContent = '';
    },

    showFileInfo(name, size, hash) {
        if (this.elements.fileName) this.elements.fileName.textContent = name;
        if (this.elements.fileInfo) this.elements.fileInfo.textContent = `الحجم: ${Utils.formatSize(size)} | SHA-256: ${hash}`;
        if (this.elements.fileCard) this.elements.fileCard.classList.add('visible');
    },

    updateStats(dexCount, stringsCount, classesCount, methodsCount) {
        if (this.elements.statDex) this.elements.statDex.textContent = dexCount.toLocaleString();
        if (this.elements.statStrings) this.elements.statStrings.textContent = stringsCount.toLocaleString();
        if (this.elements.statClasses) this.elements.statClasses.textContent = classesCount.toLocaleString();
        if (this.elements.statMethods) this.elements.statMethods.textContent = methodsCount.toLocaleString();
    },

    // 5. إدارة التبويبات الفعالة
    setActiveTab(tabName) {
        AppState.activeTab = tabName;
        
        const allBtns = [
            this.elements.tabEditable, 
            this.elements.tabStrings, 
            this.elements.tabClasses, 
            this.elements.tabMethods,
            this.elements.tabSensitive,
            this.elements.tabAnalytics
        ];

        allBtns.forEach(btn => { if (btn) btn.classList.remove('active'); });

        const activeMap = {
            'editable': this.elements.tabEditable,
            'strings': this.elements.tabStrings,
            'classes': this.elements.tabClasses,
            'methods': this.elements.tabMethods,
            'sensitiveData': this.elements.tabSensitive,
            'analytics': this.elements.tabAnalytics
        };

        if (activeMap[tabName]) activeMap[tabName].classList.add('active');

        this.renderState.currentChunk = 1;
        this.renderTabContent();
    },

    // 6. العرض العالي السرعة مع التحليل الاستخباري الذكي
    renderTabContent() {
        if (!this.elements.resultsContent) return;

        const tab = AppState.activeTab || 'editable';

        if (tab === 'analytics') {
            this.renderAnalyticsReport();
            return;
        }

        const query = (AppState.searchQuery || '').trim();
        let rawData = AppState.parsedData[tab] || [];

        let filtered = rawData;
        if (query) {
            try {
                const isRegex = query.startsWith('/') && query.endsWith('/') && query.length > 2;
                const regex = isRegex ? new RegExp(query.slice(1, -1), 'i') : null;

                filtered = rawData.filter(item => {
                    const text = typeof item === 'object' ? JSON.stringify(item) : String(item);
                    return regex ? regex.test(text) : text.toLowerCase().includes(query.toLowerCase());
                });
            } catch (e) {
                filtered = rawData.filter(item => String(item).toLowerCase().includes(query.toLowerCase()));
            }
        }

        this.renderState.filteredCache = filtered;
        const total = filtered.length;
        const limit = this.renderState.chunkSize;
        const sliced = filtered.slice(0, limit * this.renderState.currentChunk);

        if (total === 0) {
            this.elements.resultsContent.textContent = query 
                ? `❌ لم يتم العثور على أي نتائج تطابق استعلام البحث: "${query}"`
                : `ℹ️ لا توجد بيانات مسجلة في هذا القسم [ ${tab.toUpperCase()} ]`;
            return;
        }

        let header = `================================================================================\n`;
        header += `🔍 القسم المفتوح: ${tab.toUpperCase()} | النتائج المطابقة: ${total.toLocaleString()} من إجمالي ${rawData.length.toLocaleString()}\n`;
        if (total > sliced.length) {
            header += `⚠️ (تم عرض أول ${sliced.length.toLocaleString()} عنصر للحفاظ على السرعة الفائقة)\n`;
        }
        header += `================================================================================\n\n`;

        let formattedBody = '';
        if (typeof sliced[0] === 'object' && sliced[0] !== null) {
            formattedBody = sliced.map((item, idx) => `[#${idx + 1}] ${JSON.stringify(item, null, 2)}`).join('\n\n--------------------------------------------------------------------------------\n\n');
        } else {
            formattedBody = sliced.join('\n');
        }

        this.elements.resultsContent.textContent = header + formattedBody;
    },

    // 7. إنشاء تقرير التحليل الاستخباري والهيكلي للتطبيق
    renderAnalyticsReport() {
        const data = AppState.parsedData;
        const classes = data.classes || [];
        const methods = data.methods || [];
        const strings = data.strings || [];

        const obfuscatedClasses = classes.filter(c => {
            const parts = c.split('.');
            const className = parts[parts.length - 1];
            return className && className.length <= 2;
        }).length;

        const obfuscationRate = classes.length > 0 
            ? ((obfuscatedClasses / classes.length) * 100).toFixed(1) 
            : 0;

        let report = `================================================================================\n`;
        report += `                 📊 تقرير التحليل الهيكلي والاستخباري المتقدم\n`;
        report += `================================================================================\n\n`;
        report += `📁 اسم الملف: ${AppState.file ? AppState.file.name : 'غير محدد'}\n`;
        report += `🔒 البصمة الرقمية (SHA-256): ${AppState.hashHex || 'N/A'}\n`;
        report += `📅 تاريخ التحليل: ${new Date().toLocaleString('ar-EG')}\n\n`;

        report += `--------------------------------------------------------------------------------\n`;
        report += `📈 1. الإحصائيات الهيكلية العامة:\n`;
        report += `   - عدد ملفات DEX المستخرجة: ${(data.dexCount || 1)}\n`;
        report += `   - إجمالي الكلاسات (Classes): ${classes.length.toLocaleString()}\n`;
        report += `   - إجمالي الدوال (Methods): ${methods.length.toLocaleString()}\n`;
        report += `   - إجمالي النصوص المستخرجة (Strings): ${strings.length.toLocaleString()}\n\n`;

        report += `--------------------------------------------------------------------------------\n`;
        report += `🛡️ 2. تقييم التمويه والحماية (Obfuscation Profile):\n`;
        report += `   - عدد الكلاسات المموهة (أسماء قصيرة): ${obfuscatedClasses.toLocaleString()}\n`;
        report += `   - نسبة التمويه التقديرية: ${obfuscationRate}%\n`;
        report += `   - الحالة: ${obfuscationRate > 40 ? '🔴 تمويه عالي (Obfuscated with ProGuard/R8)' : '🟢 الكود مفتوح ومعظم الأسماء صريحة'}\n\n`;

        report += `--------------------------------------------------------------------------------\n`;
        report += `🎯 3. ملخص الأهداف الاستراتيجية للتعديل:\n`;
        report += `   - أهداف VIP / الشراء العالية الأولوية: ${(data.editable || []).length} هدف\n`;
        report += `   - الروابط والمفاتيح الحساسة المعزولة: ${(data.sensitiveData || []).length} عنصر\n\n`;

        report += `💡 نصيحة الهندسة العكسية:\n`;
        if (obfuscationRate > 40) {
            report += `   التطبيق يعتمد التمويه، استخدم تبويب "SENSITIVE DATA" أو ابحث في "STRINGS" عن الكلمات المفتاحية.\n`;
        } else {
            report += `   التطبيق غير مموه بشكل كامل، يمكنك التعديل المباشر على الأهداف الموضحة في تبويب "EDITABLE TARGETS".\n`;
        }

        this.elements.resultsContent.textContent = report;
    },

    // 8. النسخ السريع إلى الحافظة
    copyResults() {
        if (!this.elements.resultsContent) return;
        const text = this.elements.resultsContent.textContent;
        if (!text || text.startsWith('بانتظار رفع')) {
            this.log('لا توجد نتائج جاهزة للنسخ حالياً.', 'warning');
            return;
        }

        navigator.clipboard.writeText(text).then(() => {
            this.log('تم نسخ جميع البيانات المعروضة في الشاشة إلى الحافظة بنجاح!', 'success');
        }).catch(() => {
            this.log('تعذر النسخ التلقائي إلى الحافظة.', 'error');
        });
    },

    // 9. تصدير التقارير الهندسية الشاملة
    exportData(format) {
        if (!AppState.parsedData || Object.keys(AppState.parsedData).length === 0) {
            this.log('لا توجد بيانات محللة للتصدير.', 'warning');
            return;
        }

        let content = '';
        let mimeType = 'text/plain';
        let ext = 'txt';

        if (format === 'json') {
            content = JSON.stringify({
                metadata: {
                    fileName: AppState.file ? AppState.file.name : 'Unknown',
                    sha256: AppState.hashHex,
                    analyzedAt: new Date().toISOString()
                },
                analysisResults: AppState.parsedData
            }, null, 2);
            mimeType = 'application/json';
            ext = 'json';
        } else {
            content = `================================================================================\n`;
            content += `       GOLDEN DEX ANALYZER - ULTRA DEEP REVERSE ENGINEERING REPORT\n`;
            content += `================================================================================\n`;
            content += `الملف: ${AppState.file ? AppState.file.name : 'Unknown'}\n`;
            content += `SHA-256: ${AppState.hashHex || 'N/A'}\n`;
            content += `التاريخ: ${new Date().toLocaleString('ar-EG')}\n`;
            content += `================================================================================\n\n`;

            for (const key in AppState.parsedData) {
                content += `\n>>> [ SECTION: ${key.toUpperCase()} ] <<<\n`;
                const sec = AppState.parsedData[key];
                if (Array.isArray(sec)) {
                    content += sec.map(i => typeof i === 'object' ? JSON.stringify(i) : i).join('\n') + '\n';
                }
            }
        }

        const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `dex_analysis_${Date.now()}.${ext}`;
        a.click();
        URL.revokeObjectURL(url);
        this.log(`تم تصدير التقرير الهندسي كاملاً بصيغة (${ext.toUpperCase()}) بنجاح.`, 'success');
    },

    // 10. تفريغ وإعادة ضبط الحاوية
    clearAll() {
        if (typeof AppState !== 'undefined') AppState.reset();
        this.resetView();
        this.log('تم تنظيف محرك الواجهة وإعادة ضبط الذاكرة بالكامل.', 'info');
    },

    resetView() {
        if (this.elements.fileCard) this.elements.fileCard.classList.remove('visible');
        if (this.elements.progressContainer) this.elements.progressContainer.classList.remove('visible');
        this.updateStats('-', 0, 0, 0);
        if (this.elements.resultsContent) {
            this.elements.resultsContent.textContent = 'بانتظار رفع أو اختيار ملف لبدء عمليات التفكيك الاستاتيكي العميق...';
        }
        if (this.elements.log) this.elements.log.innerHTML = '';
        if (this.elements.fileInput) this.elements.fileInput.value = '';
        if (this.elements.searchInput) this.elements.searchInput.value = '';
        if (typeof AppState !== 'undefined') AppState.searchQuery = '';
    }
};

// تهيئة وتشغيل الواجهة عند اكتمال تحميل المستند
document.addEventListener('DOMContentLoaded', () => window.UI.init());
