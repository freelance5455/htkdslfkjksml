/* ==========================================================
   抽屉④ 表现层：唯一碰 DOM 的地方
   ========================================================== */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

/* ---------- 场景渲染 ---------- */
let token = 0;
function showScene(cfg){
  const my = ++token;
  $('#artIcon').textContent = cfg.icon || '🌸';
  $('#sceneTitle').innerHTML = cfg.title || '';
  $('#sceneMeta').textContent = cfg.meta || '';
  const body = $('#sceneBody');
  body.innerHTML = cfg.html || '';
  body.scrollTop = 0;
  const box = $('#choices');
  box.innerHTML = '';
  (cfg.choices||[]).forEach((c,i)=>{
    const b=document.createElement('button');
    b.className='choice';
    b.style.animationDelay=(i*.05)+'s';
    b.innerHTML = `<span>${c.label}</span>` + (c.hint?`<em>${c.hint}</em>`:'');
    b.onclick = ()=>{
      if(my !== token) return;
      try{ c.run(); }
      catch(err){ console.error(err); try{ nightPhase(); }catch(e){ location.reload(); } }
    };
    box.appendChild(b);
  });
}

/* ---------- HUD / 侧栏 ---------- */
/* 文档 v3.0 阶段码 / 路线 / 意向 的中文文案（表1-1 / 表3-1） */
const PHASE_NAME  = {P1:'P1 共通探索期',P2:'P2 好感线共同期',P3:'P3 勇气分支点',P4:'P4 心动分支',P5:'P5 遗憾分支',P6:'P6 隔阂线'};
const ROUTE_NAME  = {'':'未定线',A:'A 心动',B:'B 遗憾',C:'C 隔阂'};
const INTENT_NAME = {SHEN:'倾向沈',LU:'倾向陆',UNSET:'意向未定'};
function renderStoryBar(){
  if(!G.story) return '';
  const s = G.story;
  return `<div class="hud-story">
      <i>${PHASE_NAME[s.phase]||s.phase}</i>
      <i>${ROUTE_NAME[s.route]||'未定线'}</i>
      <i>${INTENT_NAME[s.intent]||''}</i>
    </div>
    <div class="hud-item hud-story-num">沈 ${G.fav.shen} · 陆 ${G.fav.lu} · 勇气 ${s.courage} · 隔阂 ${s.tense}</div>`;
}
function renderHUD(){
  if(!G) return;
  const wIcon = G.weather==='晴'?'☀️':G.weather==='阴'?'☁️':'🌧️';
  const prog = clamp(G.day/TOTAL*100,0,100);
  const left = TOTAL - G.day;
  let warnHtml='';
  if(G.day>=50 && G.day<58) warnHtml=`<div class="hud-warn">🌸 樱花开始凋零 · 剩 ${left} 天</div>`;
  else if(G.day>=58 && G.day<TOTAL) warnHtml=`<div class="hud-warn">🌸 樱花已落大半 · 剩 ${left} 天</div>`;
  $('#hud').innerHTML=`
    <div class="hud-title">🌸 樱色60天<small>SAKURA · 60 DAYS</small></div>
    <div class="hud-item">第 <b>${Math.min(G.day,TOTAL)}</b> / ${TOTAL} 天</div>
    <div class="hud-item">${weekdayOf(Math.max(1,G.day))}</div>
    <div class="hud-item">${wIcon} ${G.weather}</div>
    <div class="hud-item">${PHASE[G.phase]||''}</div>
    <div class="hud-progress"><i style="width:${prog}%"></i></div>
    ${warnHtml}
    ${renderStoryBar()}
    <button class="hud-btn" onclick="saveGame()">💾 存档</button>
    <button class="hud-btn" onclick="loadGame()">📂 读档</button>
  `;
  renderSide();
}
/* 侧栏：三路线进度卡（文档 3.7 推进顺序的可视化） */
function storyCard(){
  if(!G.story) return '';
  const s = G.story;
  const steps = [
    ['BP-1  D14 分线',  s.flags['f_route_lock']],
    ['BP-1.5 D28 意向', s.flags['f_intent_lock']],
    ['BP-2  D29 勇气',  !!s.route && s.route!=='C'],
    ['BP-3  D46 交信',  s.flags['shen_against_family']!==undefined]
  ];
  return `<div class="npc-card story-card">
    <div class="npc-name" style="margin-bottom:6px"><span>◆ 三路线剧情</span>
      <em style="color:#e5344f">${PHASE_NAME[s.phase]||s.phase}</em></div>
    <div class="npc-tags">
      <i class="on">${ROUTE_NAME[s.route]||'未定线'}</i>
      <i>${INTENT_NAME[s.intent]||''}</i>
      <i>勇气 ${s.courage}</i>
      <i>隔阂 ${s.tense}</i>
      <i>${s.secretShen?'秘密已见':'秘密未见'}</i>
    </div>
    ${steps.map(([t,ok])=>`<div style="font-size:11.5px;color:${ok?'#54b18a':'#b79aa6'};margin-top:3px">${ok?'✔':'○'} ${t}</div>`).join('')}
  </div>`;
}
function renderSide(){
  if(!G) return;
  $('#statBody').innerHTML = Object.keys(STAT_NAME).map(k=>{
    const v=G.stats[k];
    return `<div class="stat ${v>=40?'lv40':''}">
      <div class="stat-head"><span>${STAT_EMOJI[k]} ${STAT_NAME[k]}${v>=40?' <small style="color:#d94a7c">·加成中</small>':''}</span><b>${v}</b></div>
      <div class="bar"><i style="width:${v}%"></i></div>
    </div>`;
  }).join('');
  $('#favBody').innerHTML = storyCard() + Object.keys(NPC).map(k=>{
    const v=G.fav[k], st=favStage(v), n=NPC[k];
    const t=G.tense[k], ts=tenseStage(t), mem=G.memory[k].length;
    const met = G.flags['f_met_'+k];
    const rivalKeys = CONFLICTS.filter(c=>c.a===k||c.b===k).map(c=>({k:c.pair,v:G.rival[c.pair]}));
    const maxRival = rivalKeys.reduce((m,r)=> r.v>m.v?r:m, {v:0});
    return `<div class="npc-card">
      <div class="npc-row">
        <div class="npc-av" style="background:${n.color}">${n.emoji}</div>
        <div class="npc-info">
          <div class="npc-name"><span>${n.name}</span><em style="color:${st.color}">${st.name}</em></div>
          <div class="bar small"><i style="width:${v}%;background:${n.color}"></i></div>
        </div>
        <b class="npc-val">${v}</b>
      </div>
      <div class="npc-tags">
        <i class="${met?'on':''}">${met?'说过话':'没说过话'}</i>
        <i class="${G.secret[k]?'on':''}">${G.secret[k]?'秘密已见':'秘密未见'}</i>
        <i class="tense" style="color:${ts.color}">张力 ${t}</i>
        <i>回忆 ${mem}</i>
        ${maxRival.v>0?`<i class="rival">吃醋 ${maxRival.v}</i>`:''}
      </div>
    </div>`;
  }).join('');
  $('#codexBody').innerHTML = Object.keys(NPC).map(k=>{
    const n=NPC[k];
    return `<div class="codex-npc">
      <div class="t"><span style="color:${n.color}">${n.emoji}</span>${n.name}
        <small style="font-weight:400;color:#b79aa6;margin-left:auto;font-size:10.5px">${n.tag}</small></div>
      <div class="d">${n.desc}<br><span>物件：</span>${n.secretName}
      <br><span>喜欢：</span>${n.likes}<br><span>出没：</span>${n.places}</div>
    </div>`;
  }).join('');
}

/* ---------- 浮动 / 提示 ---------- */
function floatText(npcId,v,sym,isTense){
  const n = NPC[npcId];
  const el = document.createElement('div');
  el.className = 'floater';
  el.style.color = isTense ? (v>0?'#e08c3c':'#7fb0a0') : (v>0 ? n.color : '#d9534f');
  el.textContent = `${n.name} ${v>0?'+':''}${v} ${sym}`;
  el.style.left = (window.innerWidth - 260 + Math.random()*120)+'px';
  el.style.top  = (window.innerHeight*0.35 + Math.random()*60)+'px';
  $('#floaters').appendChild(el);
  setTimeout(()=>el.remove(),1500);
}
function deltas(favObj,statObj,tenseObj,memList,rivalObj){
  let s='';
  Object.keys(favObj||{}).forEach(k=>{
    if(!NPC[k]) return;
    const v=favObj[k];
    if(v) s += `<span class="tag ${v>0?'up':'down'}">${NPC[k].name} 好感 ${v>0?'+':''}${v}</span>`;
  });
  Object.keys(tenseObj||{}).forEach(k=>{
    if(!NPC[k]) return;
    const v=tenseObj[k];
    if(v) s += `<span class="tag ten">${NPC[k].name} 张力 ${v>0?'+':''}${v}</span>`;
  });
  Object.keys(statObj||{}).forEach(k=>{
    const v=statObj[k];
    if(v) s += `<span class="tag ${v>0?'up':'down'}">${STAT_NAME[k]} ${v>0?'+':''}${v}</span>`;
  });
  (memList||[]).forEach(t=>{ s += `<span class="tag mem">✎ ${t}</span>`; });
  Object.keys(rivalObj||{}).forEach(p=>{
    const v=rivalObj[p];
    if(v) s += `<span class="tag rival">吃醋 +${v}</span>`;
  });
  return s ? `<div class="deltas">${s}</div>` : '';
}
function toast(text,icon='🌸'){
  const el = document.createElement('div');
  el.className='toast';
  el.innerHTML = `<span style="font-size:16px">${icon}</span><span>${text}</span>`;
  $('#toasts').appendChild(el);
  setTimeout(()=>{ el.classList.add('out'); setTimeout(()=>el.remove(),400); },2400);
}

/* ---------- 地图 ---------- */
const MAP = {
  '樱丘高中':{icon:'🏫',places:[
    {id:'classroom',name:'教室',npc:'—'},
    {id:'rooftop',name:'天台',npc:'随机'},
    {id:'library',name:'图书馆',npc:'沈逸舟'},
    {id:'student',name:'学生会室',npc:'沈逸舟'},
    {id:'litclub',name:'文学社教室',npc:'苏念秋'},
    {id:'music',name:'音乐教室',npc:'苏念秋'},
    {id:'gym',name:'体育馆',npc:'陆鸣'},
    {id:'field',name:'操场',npc:'陆鸣'},
    {id:'shop',name:'小卖部',npc:'陆鸣'},
    {id:'canteen',name:'食堂',npc:'—'}
  ]},
  '商业街':{icon:'🏬',places:[
    {id:'cafe',name:'咖啡店',npc:'林小满'},
    {id:'bookstore',name:'书店',npc:'苏念秋'},
    {id:'clothes',name:'服装店',npc:'林小满'},
    {id:'store',name:'便利店',npc:'—'}
  ]},
  '樱丘公园':{icon:'🌳',places:[
    {id:'sakura',name:'樱花步道',npc:'随机'},
    {id:'lake',name:'湖边',npc:'苏念秋'},
    {id:'bball',name:'篮球场',npc:'陆鸣'},
    {id:'shrine',name:'神社',npc:'随机'}
  ]},
  '校外':{icon:'🍲',places:[
    {id:'hotpot',name:'陆家火锅店',npc:'陆鸣'},
    {id:'ramen',name:'拉面馆',npc:'—'},
    {id:'post',name:'邮局',npc:'—'}
  ]}
};
let _mapCancel=null,_mapSelecting=false;
function openMap(callback,filter,onCancel){
  const allowed = filter || Object.keys(MAP);
  let html='';
  Object.keys(MAP).forEach(group=>{
    if(!allowed.includes(group)) return;
    const g = MAP[group];
    html += `<div class="map-group"><h4>${g.icon} ${group}</h4><div class="map-places">`;
    g.places.forEach(p=>{
      html += `<button class="map-btn" data-place="${p.id}">${p.name}<small>${p.npc}</small></button>`;
    });
    html += `</div></div>`;
  });
  const w = weekIdx(Math.max(1,G.day));
  const used = G.flags['_directed_w'+w] || 0;
  if(used < 2){
    html += `<button class="directed-btn" id="directedBtn">🎯 定向拜访（本周剩 ${2-used} 次）</button>`;
  }
  $('#choices').innerHTML='';
  $('#sceneBody').innerHTML='<p class="nar" style="color:#b79aa6;text-align:center;padding:24px 0">请在地图上选择目的地…</p>';
  $('#sceneTitle').textContent='地图 · 选择目的地';
  $('#sceneMeta').textContent=`${weekdayOf(Math.max(1,G.day))} · ${G.weather}`;
  _mapCancel = typeof onCancel === 'function' ? onCancel : (()=>{});
  _mapSelecting = true;
  $('#modalTitle').textContent='地图 · 选择目的地';
  $('#modalBody').innerHTML=html;
  $('#modal').classList.add('show');
  $$('#modalBody .map-btn').forEach(b=>{
    b.onclick=()=>{
      _mapSelecting=false; _mapCancel=null; closeModal();
      setTimeout(()=> callback(b.dataset.place),100);
    };
  });
  const dBtn = document.getElementById('directedBtn');
  if(dBtn){
    dBtn.onclick=()=>{
      _mapSelecting=false; _mapCancel=null; closeModal();
      setTimeout(()=> directedVisit(w),100);
    };
  }
}
function directedVisit(w){
  let html='<p class="nar" style="color:#a0838f;font-size:13px;margin-bottom:10px">选择你想专门去找的人。</p><div class="map-places">';
  Object.keys(NPC).forEach(k=>{
    html += `<button class="map-btn" data-npc="${k}">${NPC[k].emoji} ${NPC[k].name}</button>`;
  });
  html += '</div>';
  $('#modalTitle').textContent='定向拜访';
  $('#modalBody').innerHTML=html;
  $('#modal').classList.add('show');
  $$('#modalBody .map-btn').forEach(b=>{
    b.onclick=()=>{
      closeModal();
      G.flags['_directed_w'+w] = (G.flags['_directed_w'+w]||0)+1;
      G.selfCount += 0.5;
      const npcId = b.dataset.npc;
      const pool = NPC_SCENES[npcId].filter(e=>!G.flags[e.eventId]);
      if(pool.length){
        const s = pick(pool);
        G.flags[s.eventId]=true;
        G.lastVisit[npcId]=G.day;
        const n = NPC[npcId];
        const stage = favStage(G.fav[npcId]).idx;
        showScene({
          icon:n.emoji, title:`🎯 专门去找 ${n.name}`,
          meta:`${weekdayOf(G.day)} · ${G.weather}`,
          html:`<p class="say">${OPENING[npcId][stage]}</p><p class="nar">${s.text}</p>`,
          choices: s.choices.map(c=>({
            label:c.label,
            run:()=>{
              const r = favWithBonus(npcId, c.fav);
              addStat(c.stat);
              if(c.tense) addTense(c.tense);
              const mem=[];
              if(c.memo){ remember(npcId,c.memo); mem.push(c.memo); }
              renderHUD();
              const jeal = checkJealous(npcId, r.total);
              showScene({icon:n.emoji, title:n.name,
                html:`<p class="nar">${c.res}</p>` + (jeal?`<p class="jealous">${jeal}</p>`:'') + deltas({[npcId]:r.total}, c.stat, c.tense, mem),
                choices:[{label:'继续 ▶', run:()=> gotoPhase('night')}]});
            }
          }))
        });
      }else{
        toast('这个人的浅层事件都看过了','ℹ️');
        showScene({icon:'🌸', title:'此处安静',
          html:`<p class="nar">你去找${NPC[npcId].name}，但今天没有遇见。</p>`,
          choices:[{label:'回去 ▶', run:()=> gotoPhase('night')}]});
      }
    };
  });
}
function closeModal(){
  $('#modal').classList.remove('show');
  $('#choices').innerHTML='';
  if(_mapSelecting){
    _mapSelecting=false;
    const fn=_mapCancel; _mapCancel=null;
    if(fn) setTimeout(fn,100);
  }
}

/* ---------- 事件绑定 ---------- */
$$('.tabs button').forEach(b=>{
  b.onclick=()=>{
    $$('.tabs button').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    ['stats','fav','codex'].forEach(t=>{
      $('#tab-'+t).classList.toggle('hidden', t!==b.dataset.tab);
    });
  };
});
$('#modalClose').onclick=closeModal;
$('#modal').onclick=e=>{ if(e.target===e.currentTarget) closeModal(); };

/* ---------- 花瓣 ---------- */
(function(){
  const box = $('#petals');
  for(let i=0;i<14;i++){
    const el=document.createElement('i');
    el.style.left=Math.random()*100+'%';
    el.style.animationDuration=(9+Math.random()*11)+'s';
    el.style.animationDelay=(-Math.random()*20)+'s';
    el.style.opacity=.22+Math.random()*.4;
    box.appendChild(el);
  }
})();

/* ---------- 启动 ---------- */
startGame();
//（注：内容由AI生成）