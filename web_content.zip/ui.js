import { setPreset } from './settings.js';

export function createUI({applyGraphics,onStart,onAccuse,onSleep}) {
  const menu=document.querySelector('#menu'),hud=document.querySelector('#hud'),computer=document.querySelector('#computer');
  const content=document.querySelector('#terminal-content'),sleep=document.querySelector('#sleep-button'),scare=document.querySelector('#scare');
  let day=1,night=null,activeTab='mail',seen=[];
  function render(tab=activeTab){
    activeTab=tab;
    if(tab==='mail'){
      content.innerHTML=`<strong>INBOX / ${night.emailFrom}</strong><h3>${night.subject}</h3><p>Seven nights. Keep the ramen stand open, watch every car, and report the person who matches this file.</p><p>${night.clue}</p><p>The old family account has been used to hide something. Don't ask your cousin about it over the phone.</p>`;
    } else if(tab==='cctv'){
      content.innerHTML='<strong>CAMERA NETWORK · PLATE READER</strong>'+['FRONT ROAD','SERVICE LANE','ALLEY CAM'].map(cam=>{
        const cars=seen.filter(r=>r.cam===cam);
        return `<div class="feed">CAM ${cam}<br>${cars.length?cars.map(r=>`PLATE ${r.plate} · ${r.vehicle}`).join('<br>'):'NO VEHICLE IN FRAME'}</div>`;
      }).join('');
    } else if(tab==='lookup'){
      content.innerHTML=`<strong>CITY VEHICLE & RESIDENT DATABASE</strong><p>Enter a plate read from CCTV.</p><form id="plate-form"><input id="plate-input" maxlength="12" autocomplete="off" placeholder="RS-000" required><button>Search</button></form><div id="lookup-result">SEARCH READY</div>`;
      document.querySelector('#plate-form').addEventListener('submit',e=>{
        e.preventDefault();const plate=document.querySelector('#plate-input').value.trim().toUpperCase();
        const record=night.records.find(r=>r.plate===plate),result=document.querySelector('#lookup-result');
        if(!record){result.textContent='NO MATCH. CHECK THE PLATE AND TRY AGAIN.';return;}
        result.innerHTML=`<hr><strong>${record.name}</strong><p>Registered vehicle: ${record.vehicle}<br>Occupation: ${record.job}<br>Plate: ${record.plate}</p><button id="accuse">Submit this identity</button>`;
        document.querySelector('#accuse').addEventListener('click',()=>onAccuse(record));
      });
    } else {
      content.innerHTML=`<strong>NIGHT ${String(day).padStart(2,'0')} CASE FILE</strong><p>One murderer is using the late shift to pass through the stand. Compare the email clue with the CCTV plate and database profile.</p><p><b>Lead:</b> ${night.clue}</p><p>There are ${night.records.length} registered visitors in the camera log.</p><p>Submit the matching identity to close this shift.</p>`;
    }
    document.querySelectorAll('#tabs button').forEach(button=>button.classList.toggle('active',button.dataset.tab===tab));
  }
  function openComputer(tab='mail'){computer.style.display='block';render(tab);}
  function closeComputer(){computer.style.display='none';}
  document.querySelector('#quality').addEventListener('change',e=>applyGraphics(e.target.value,setPreset(e.target.value)));
  document.querySelector('#start').addEventListener('click',()=>{menu.style.display='none';hud.style.display='block';document.querySelector('.subtitle').textContent='A quiet street. One more night shift.';document.querySelector('#start').textContent='Begin shift';onStart();});
  document.querySelector('#computer-button').addEventListener('click',()=>openComputer());
  document.querySelector('#close-computer').addEventListener('click',closeComputer);
  document.querySelectorAll('#tabs button').forEach(button=>button.addEventListener('click',()=>render(button.dataset.tab)));
  document.querySelector('#sleep-button').addEventListener('click',()=>{sleep.style.display='none';closeComputer();onSleep();});
  document.addEventListener('keydown',e=>{if(e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement)return;if(e.code==='KeyC'&&!e.repeat&&hud.style.display==='block')openComputer();if(e.code==='Escape')closeComputer();});
  return {
    beginShift(number,data){day=number;night=data;seen=[];document.querySelector('#computer header strong').textContent=`STAND TERMINAL · NIGHT ${day}`;document.querySelector('#title').textContent=`NIGHT ${String(day).padStart(2,'0')} · 11:47 PM`;document.querySelector('#prompt').textContent='Check the new email, then watch the cameras.';sleep.style.display='none';},
    openComputer,closeComputer,
    observe(record){seen.push(record);if(activeTab==='cctv'&&computer.style.display==='block')render('cctv');},
    solved(){sleep.style.display='block';document.querySelector('#prompt').textContent='Identity submitted. Return to your room and sleep.';},
    setPrompt(text){document.querySelector('#prompt').textContent=text;},
    flashScare(){scare.classList.remove('show');void scare.offsetWidth;scare.classList.add('show');setTimeout(()=>scare.classList.remove('show'),1100);},
    finish(){hud.style.display='none';computer.style.display='none';menu.style.display='grid';document.querySelector('.subtitle').textContent='Seven shifts are over. The stand is finally quiet.';document.querySelector('#start').textContent='Play again';}
  };
}
