import { isTaskActive, isTaskDone, repeatSummary, isPaused, applyVacationAdjustment } from './recurrence.js';
import { t } from './i18n.js';

const el = (tag, className, text) => { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; };
const emptyState = (title, hint) => { const box = el('div', 'empty-state'); box.append(el('strong', '', title), el('span', '', hint)); return box; };
const timeToMinutes = (value) => { if (!/^\d{2}:\d{2}$/.test(value || '')) return null; const [hours, minutes] = value.split(':').map(Number); return hours * 60 + minutes; };
const safeId = (value) => String(value || '').replace(/[^a-zA-Z0-9_-]/g, '-');
const subtaskLabel = (count) => count === 1 ? t('subtasks.one') : t('subtasks.count', { count });
const repeatText = (task) => { const { frequency, weekdays } = repeatSummary(task); if (frequency === 'none') return ''; if (frequency === 'weekly' && weekdays.length) return t('repeat.weeklyOn', { days: weekdays.map((day) => t(`weekdays.${day}`)).join(', ') }); return t(`repeat.${frequency}`); };
const taskMeta = (task) => task.endTime ? t('taskMeta.range', { from: task.time || '—', to: task.endTime, category: t(`categories.${task.category || 'routine'}`) }) : t('taskMeta.text', { time: task.time || '—', duration: task.duration || '—', category: t(`categories.${task.category || 'routine'}`) });
const expandedTasks = new Set(); const expandedTodos = new Set();
export function revealTask(taskId) { expandedTasks.add(taskId); }

function makeSubtaskList(item, handlers, className, expanded) { const list = el('ul', className); list.hidden = !expanded; (item.subtasks || []).forEach((subtask, index) => { const row = el('li', subtask.done ? 'task-subtask is-done row-toggle' : 'task-subtask row-toggle'); const check = el('button', 'subtask-check', subtask.done ? '✓' : ''); check.type = 'button'; check.setAttribute('aria-label', subtask.done ? t('todo.markOpen') : t('todo.markDone')); check.addEventListener('click', () => handlers.toggleSubtask?.(item.id, index)); row.append(check, el('span', '', subtask.text)); row.addEventListener('click', (event) => { if (event.target.closest('button')) return; handlers.toggleSubtask?.(item.id, index); }); list.append(row); }); return list; }
function makeSubtaskToggle(item, expanded, onToggle) { const button = el('button', 'subtask-toggle', `${expanded ? '▾' : '▸'} ${subtaskLabel(item.subtasks.length)}`); button.type = 'button'; button.setAttribute('aria-expanded', String(expanded)); button.setAttribute('aria-label', t(expanded ? 'subtasks.hide' : 'subtasks.show')); button.addEventListener('click', onToggle); return button; }
function actionButtons(actions, handlers, id) { const box = el('div', 'task-actions'); const names = actions ? Object.keys(actions).filter((name) => actions[name]) : ['edit', 'remove']; names.forEach((name) => { const key = name === 'edit' ? 'actions.edit' : 'actions.delete'; const button = el('button', 'small-action', t(key)); button.type = 'button'; button.addEventListener('click', () => handlers[name]?.(id)); box.append(button); }); return box; }

export function renderTimeline(container, tasks, appointments, pausedKeys = new Set(), handlers = {}) { container.replaceChildren(); const now = new Date(); const nowMinutes = now.getHours() * 60 + now.getMinutes(); const timeNode = document.getElementById('currentTime'); const formattedNow = new Intl.DateTimeFormat(t('dateLocale'), { hour: '2-digit', minute: '2-digit' }).format(now); if (timeNode) { timeNode.textContent = `${t('timeline.now')} · ${formattedNow}`; timeNode.setAttribute('aria-label', t('timeline.currentTime', { time: formattedNow })); } const todayKeyValue = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`; const taskEntries = tasks.filter((task) => isTaskActive(task, now) && !pausedKeys.has(`task:${task.id}`)).map((task) => ({ kind: 'task', start: timeToMinutes(task.time), duration: Number(task.duration) || 0, data: task })); const appointmentEntries = (appointments || []).filter((appointment) => appointment.date === todayKeyValue).map((appointment) => ({ kind: 'appointment', start: timeToMinutes(appointment.time), duration: Number(appointment.duration) || 0, data: appointment })); const sorted = [...taskEntries, ...appointmentEntries].sort((a, b) => (a.start ?? 1440) - (b.start ?? 1440)); if (!sorted.length) { container.append(emptyState(t('timeline.empty'), t('timeline.emptyHint'))); return; } const list = el('ol', 'timeline-list'); list.setAttribute('aria-label', t('timeline.ariaLabel')); let markerAdded = false; sorted.forEach((entry) => { const start = entry.start; const duration = entry.duration; const current = start !== null && nowMinutes >= start && nowMinutes <= start + duration; if (!markerAdded && (start === null || nowMinutes < start || current)) { list.append(el('li', 'timeline-now', t('timeline.now'))); markerAdded = true; }
    if (entry.kind === 'appointment') {
      const appointment = entry.data;
      const event = el('li', `timeline-event timeline-event-appointment${current ? ' is-current' : ''}`);
      event.dataset.appointmentId = appointment.id;
      const dot = el('span', 'timeline-dot timeline-dot-appointment'); dot.setAttribute('aria-hidden', 'true');
      const body = el('div', 'timeline-event-body'); body.setAttribute('role', 'button'); body.tabIndex = 0; body.setAttribute('aria-label', t('timeline.openAppointment', { name: appointment.title }));
      const openAppointment = () => handlers.openAppointment?.(appointment.id);
      body.addEventListener('click', openAppointment);
      body.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openAppointment(); } });
      body.append(el('div', 'timeline-event-time', appointment.time || t('timeline.noTime')), el('div', 'timeline-event-name', appointment.title), el('div', 'timeline-event-meta', appointment.location || appointmentTimeText(appointment)));
      if (current) { event.setAttribute('aria-current', 'step'); body.append(el('span', 'timeline-current-label', t('timeline.current'))); }
      event.append(dot, body);
      list.append(event);
      return;
    }
    const task = entry.data; const done = isTaskDone(task, now); const event = el('li', `timeline-event${done ? ' is-done' : ''}${current ? ' is-current' : ''}`); event.dataset.taskId = task.id; const dot = el('span', 'timeline-dot'); dot.setAttribute('aria-hidden', 'true'); const body = el('div', 'timeline-event-body'); body.setAttribute('role', 'button'); body.tabIndex = 0; body.setAttribute('aria-label', t('timeline.openTask', { name: task.name })); const openTask = () => handlers.openTask?.(task.id); body.addEventListener('click', openTask); body.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openTask(); } }); body.append(el('div', 'timeline-event-time', task.time || t('timeline.noTime')), el('div', 'timeline-event-name', task.name), el('div', 'timeline-event-meta', taskMeta(task))); const repeat = repeatText(task); if (repeat) body.append(el('span', 'task-repeat', repeat)); if (current) { event.setAttribute('aria-current', 'step'); body.append(el('span', 'timeline-current-label', t('timeline.current'))); } event.append(dot, body); list.append(event); }); if (!markerAdded) list.append(el('li', 'timeline-now', t('timeline.now'))); container.append(list); }

export function renderTasks(container, tasks, filter = 'all', handlers = {}, options = {}) { container.replaceChildren(); const pausedKeys = options.pausedKeys || new Set(); const source = (options.includeInactive ? tasks : tasks.filter((task) => isTaskActive(task))).filter((task) => !pausedKeys.has(`task:${task.id}`)); const filtered = source.filter((task) => { const done = isTaskDone(task); return filter === 'all' || (filter === 'done' ? done : !done); }).sort((a, b) => (a.time || '').localeCompare(b.time || '')); if (!filtered.length) { container.append(emptyState(t('messages.emptyTasks'), t('messages.emptyTasksHint'))); return; } filtered.forEach((task) => { const done = isTaskDone(task); const item = el('article', `task-item${done ? ' is-done' : ''}`); item.dataset.taskId = task.id; item.id = `task-${safeId(task.id)}`; item.tabIndex = -1; const row = el('div', 'task-main-row row-toggle'); const check = el('button', 'check-button', done ? '✓' : ''); check.type = 'button'; check.setAttribute('aria-label', done ? t('filters.open') : t('actions.markDone')); check.addEventListener('click', () => handlers.toggle?.(task.id)); const copy = el('div', 'task-copy'); const subtasks = Array.isArray(task.subtasks) ? task.subtasks : []; const hasSubtasks = subtasks.length > 0; const expanded = expandedTasks.has(task.id); const name = hasSubtasks ? el('button', 'task-expand', task.name) : el('div', 'task-name', task.name); if (hasSubtasks) { name.type = 'button'; name.setAttribute('aria-expanded', String(expanded)); name.setAttribute('aria-label', t(expanded ? 'subtasks.hide' : 'subtasks.show')); name.addEventListener('click', () => { expandedTasks.has(task.id) ? expandedTasks.delete(task.id) : expandedTasks.add(task.id); renderTasks(container, tasks, filter, handlers, options); }); } copy.append(name, el('div', 'task-meta', taskMeta(task))); const repeat = repeatText(task); if (repeat) copy.append(el('span', 'task-repeat', repeat)); if (task.routineId || task.routineIds?.length) copy.append(el('span', 'task-routine', `↻ ${t('taskMeta.routine')}`)); row.append(check, copy, actionButtons(null, handlers, task.id)); row.addEventListener('click', (event) => { if (event.target.closest('button')) return; handlers.toggle?.(task.id); }); item.append(row); if (subtasks.length) { const toggle = makeSubtaskToggle(task, expanded, () => { expanded ? expandedTasks.delete(task.id) : expandedTasks.add(task.id); renderTasks(container, tasks, filter, handlers, options); }); toggle.setAttribute('aria-controls', `task-subtasks-${safeId(task.id)}`); const list = makeSubtaskList(task, handlers, 'task-subtasks', expanded); list.id = `task-subtasks-${safeId(task.id)}`; item.append(toggle, list); } container.append(item); }); }

export function renderTodo(container, items, handlers = {}, options = {}) { container.replaceChildren(); const pausedKeys = options.pausedKeys || new Set(); const sorted = items.filter((item) => !pausedKeys.has(`todo:${item.id}`)).slice().sort((a, b) => Number(a.done) - Number(b.done) || a.name.localeCompare(b.name, t('dateLocale'))); if (!sorted.length) { container.append(emptyState(t('todo.empty'), t('todo.emptyHint'))); return; } sorted.forEach((item) => { const done = Boolean(item.done); const card = el('article', `todo-card${done ? ' is-done' : ''}`); const row = el('div', 'todo-main-row row-toggle'); const check = el('button', 'check-button', done ? '✓' : ''); check.type = 'button'; check.setAttribute('aria-label', done ? t('todo.itemMarkOpen') : t('todo.itemMarkDone')); check.addEventListener('click', () => handlers.toggle?.(item.id)); const copy = el('div', 'task-copy'); const subtasks = Array.isArray(item.subtasks) ? item.subtasks : []; const expanded = expandedTodos.has(item.id); const name = subtasks.length ? el('button', 'task-expand', item.name) : el('div', 'task-name', item.name); if (subtasks.length) { name.type = 'button'; name.setAttribute('aria-expanded', String(expanded)); name.setAttribute('aria-label', t(expanded ? 'subtasks.hide' : 'subtasks.show')); name.addEventListener('click', () => { expandedTodos.has(item.id) ? expandedTodos.delete(item.id) : expandedTodos.add(item.id); renderTodo(container, items, handlers, options); }); } copy.append(name, el('div', 'task-meta', t('todo.noTime'))); row.append(check, copy, actionButtons(null, handlers, item.id)); row.addEventListener('click', (event) => { if (event.target.closest('button')) return; handlers.toggle?.(item.id); }); card.append(row); if (subtasks.length) { const toggle = makeSubtaskToggle(item, expanded, () => { expanded ? expandedTodos.delete(item.id) : expandedTodos.add(item.id); renderTodo(container, items, handlers, options); }); const list = makeSubtaskList(item, handlers, 'todo-subtasks', expanded); card.append(toggle, list); } container.append(card); }); }

export function renderRoutines(container, routines, handlers = {}, pausedKeys = new Set()) { container.replaceChildren(); const visible = routines.filter((routine) => !pausedKeys.has(`routine:${routine.id}`)); if (!visible.length) { container.append(emptyState(t('messages.emptyRoutines'), t('messages.emptyRoutinesHint'))); return; } visible.forEach((routine) => { const card = el('article', 'routine-card'); const top = el('div', 'routine-top'); top.append(el('h2', '', routine.name), actionButtons(null, handlers, routine.id)); const list = el('ol'); (routine.steps || []).forEach((step) => list.append(el('li', '', step))); card.append(top, list); container.append(card); }); }
export function renderNotes(container, notes, handlers = {}) { container.replaceChildren(); if (!notes.length) { container.append(emptyState(t('messages.emptyNotes'), t('messages.emptyNotesHint'))); return; } notes.forEach((note) => { const card = el('article', 'todo-card note-card'); const row = el('div', 'note-main-row'); row.append(el('div', 'task-name', note.title || t('form.noteDefault')), actionButtons(null, handlers, note.id)); card.append(row); if (note.body) card.append(el('p', 'note-body', note.body)); container.append(card); }); }
export function renderReviews(container, reviews, handlers = {}) { container.replaceChildren(); reviews.slice().reverse().slice(0, 5).forEach((review) => { const item = el('article', 'history-item'); const text = el('div', '', `${review.date}\n${review.good || '—'} · ${review.easy || '—'}`); text.style.whiteSpace = 'pre-line'; item.append(text, actionButtons({ edit: true }, handlers, review.id)); container.append(item); }); }

function formatDate(value) { if (!value) return ''; try { return new Intl.DateTimeFormat(t('dateLocale'), { dateStyle: 'medium' }).format(new Date(`${value}T12:00:00`)); } catch { return value; } }
const appointmentTimeText = (appointment) => { if (appointment.endTime && appointment.time) return t('appointments.timeRange', { from: appointment.time, to: appointment.endTime }); if (appointment.duration && appointment.time) return t('appointments.timeDuration', { time: appointment.time, duration: appointment.duration }); return appointment.time || t('appointments.noTime'); };
export function renderTodayAppointments(container, appointments, handlers) { const now = new Date(); const key = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`; renderAppointments(container, (appointments || []).filter((appointment) => appointment.date === key), handlers); }
export function renderAppointments(container, appointments, handlers, options = {}) {
  container.replaceChildren();
  const groupBy = options.groupBy || 'none';
  const showExpired = options.showExpired !== false;
  const cutoff = options.todayKey || '';
  const visible = (appointments || []).filter((appointment) => showExpired || !cutoff || appointment.date >= cutoff);
  const sorted = visible.slice().sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
  if (!sorted.length) { container.append(emptyState(t('appointments.empty'), t('appointments.emptyHint'))); return; }
  let currentGroup = null;
  sorted.forEach((appointment) => {
    if (groupBy !== 'none' && /^\d{4}-\d{2}-\d{2}$/.test(appointment.date)) {
      const [year, month] = appointment.date.split('-');
      const groupKey = groupBy === 'year' ? year : `${year}-${month}`;
      if (groupKey !== currentGroup) {
        currentGroup = groupKey;
        const label = groupBy === 'year' ? year : new Intl.DateTimeFormat(t('dateLocale'), { year: 'numeric', month: 'long' }).format(new Date(`${year}-${month}-01T12:00:00`));
        container.append(el('h3', 'appointment-group-heading', label));
      }
    }
    const card = el('article', 'appointment-card');
    const top = el('div', 'appointment-top');
    top.append(el('div', 'appointment-date', formatDate(appointment.date)), actionButtons(null, handlers, appointment.id));
    card.append(top, el('h2', '', appointment.title), el('div', 'appointment-time', appointmentTimeText(appointment)));
    if (appointment.location) card.append(el('p', 'appointment-detail', `⌖ ${appointment.location}`));
    if (appointment.notes) card.append(el('p', 'appointment-detail', appointment.notes));
    if (appointment.reminders?.mode === 'off') card.append(el('span', 'appointment-reminder-badge', t('appointments.remindersOff')));
    else if (appointment.reminders?.mode === 'custom' && appointment.reminders.minutes.length) card.append(el('span', 'appointment-reminder-badge', t('appointments.remindersCustom', { count: appointment.reminders.minutes.length })));
    container.append(card);
  });
}
export function renderLists(container, lists, handlers, pausedKeys = new Set()) { container.replaceChildren(); const visible = lists.filter((list) => !pausedKeys.has(`list:${list.id}`)); if (!visible.length) { container.append(emptyState(t('lists.empty'), t('lists.emptyHint'))); return; } visible.forEach((list) => { const card = el('article', 'todo-card list-card'); const row = el('div', 'note-main-row'); row.append(el('div', 'task-name', list.name), actionButtons(null, handlers, list.id)); const body = list.type === 'numbered' ? el('ol', 'saved-list numbered-list') : el('ul', 'saved-list'); (list.items || []).forEach((item, index) => { const itemRow = el('li', item.done ? 'saved-list-item is-done' : 'saved-list-item'); if (list.type === 'checklist') { const check = el('button', 'subtask-check', item.done ? '✓' : ''); check.type = 'button'; check.setAttribute('aria-label', item.done ? t('lists.markOpen') : t('lists.markDone')); check.addEventListener('click', () => handlers.toggleItem?.(list.id, index)); itemRow.append(check); itemRow.classList.add('row-toggle'); itemRow.addEventListener('click', (event) => { if (event.target.closest('button')) return; handlers.toggleItem?.(list.id, index); }); } itemRow.append(el('span', '', item.text)); body.append(itemRow); }); card.append(row, el('span', 'list-type', t(`listTypes.${list.type}`)), body); container.append(card); }); }
const expandedGoals = new Set();
export function renderGoals(container, goals, handlers) { container.replaceChildren(); if (!goals.length) { container.append(emptyState(t('goals.empty'), t('goals.emptyHint'))); return; } const today = new Date(); const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`; goals.forEach((goal) => { const steps = Array.isArray(goal.nextSteps) ? goal.nextSteps : []; const completedSteps = steps.filter((step) => step.completedDate === todayKey).length; const progress = steps.length ? Math.round(completedSteps / steps.length * 100) : Math.max(0, Math.min(100, Number(goal.progress) || 0)); const card = el('article', 'todo-card goal-card'); const row = el('div', 'todo-main-row'); const badge = el('button', 'check-button goal-progress-badge', `${progress}%`); badge.type = 'button'; if (!steps.length) { badge.setAttribute('aria-label', t('goals.advance')); badge.addEventListener('click', () => handlers.changeProgress?.(goal.id, 10)); } else { badge.disabled = true; badge.setAttribute('aria-label', `${progress}%`); } const copy = el('div', 'task-copy'); const expanded = expandedGoals.has(goal.id); const name = steps.length ? el('button', 'task-expand', goal.name) : el('div', 'task-name', goal.name); if (steps.length) { name.type = 'button'; name.setAttribute('aria-expanded', String(expanded)); name.setAttribute('aria-label', t(expanded ? 'subtasks.hide' : 'subtasks.show')); name.addEventListener('click', () => { expandedGoals.has(goal.id) ? expandedGoals.delete(goal.id) : expandedGoals.add(goal.id); renderGoals(container, goals, handlers); }); } copy.append(name, el('div', 'task-meta', goal.why || t('goals.noWhy'))); row.append(badge, copy, actionButtons(null, handlers, goal.id)); card.append(row); if (steps.length) { const toggle = el('button', 'subtask-toggle', `${expanded ? '▾' : '▸'} ${t('goals.next')} (${steps.length})`); toggle.type = 'button'; toggle.setAttribute('aria-expanded', String(expanded)); toggle.addEventListener('click', () => { expandedGoals.has(goal.id) ? expandedGoals.delete(goal.id) : expandedGoals.add(goal.id); renderGoals(container, goals, handlers); }); card.append(toggle); const list = el('ul', 'task-subtasks'); list.hidden = !expanded; steps.forEach((step) => { const done = step.completedDate === todayKey; const stepRow = el('li', done ? 'task-subtask is-done row-toggle' : 'task-subtask row-toggle'); const check = el('button', 'subtask-check', done ? '✓' : ''); check.type = 'button'; check.setAttribute('aria-label', t(done ? 'goals.markOpen' : 'goals.markDone')); check.addEventListener('click', () => handlers.toggleStep?.(goal.id, step.id)); stepRow.append(check, el('span', '', step.text)); stepRow.addEventListener('click', (event) => { if (event.target.closest('button')) return; handlers.toggleStep?.(goal.id, step.id); }); list.append(stepRow); }); card.append(list); } container.append(card); }); }
export function renderVacations(container, vacations, handlers) { container.replaceChildren(); if (!vacations.length) { container.append(emptyState(t('vacations.empty'), t('vacations.emptyHint'))); return; } vacations.slice().sort((a, b) => a.from.localeCompare(b.from)).forEach((vacation) => { const card = el('article', 'vacation-card'); const top = el('div', 'vacation-top'); top.append(el('div', '', `${formatDate(vacation.from)} – ${formatDate(vacation.to)}`), actionButtons(null, handlers, vacation.id)); card.append(top, el('h2', '', vacation.name), el('p', 'vacation-paused', t('vacations.pausedCount', { count: vacation.pausedItems?.length || 0 }))); if (vacation.adjustedItems?.length) card.append(el('p', 'vacation-adjusted', t('vacations.adjustedCount', { count: vacation.adjustedItems.length }))); container.append(card); }); }
const defaultVacationWeekdays = (item) => { const repeat = item?.repeat; if (repeat?.frequency === 'weekly' && Array.isArray(repeat.weekdays) && repeat.weekdays.length) return repeat.weekdays; return [1, 2, 3, 4, 5, 6, 7]; };
const weekdayOptions = [['1', 'weekdays.mon'], ['2', 'weekdays.tue'], ['3', 'weekdays.wed'], ['4', 'weekdays.thu'], ['5', 'weekdays.fri'], ['6', 'weekdays.sat'], ['7', 'weekdays.sun']];

export function populatePauseItems(container, state, selected = [], adjusted = []) { container.replaceChildren(); const groups = [['task', state.tasks, 'vacationGroups.tasks'], ['todo', state.todoItems, 'vacationGroups.todos'], ['routine', state.routines, 'vacationGroups.routines'], ['list', state.lists, 'vacationGroups.lists']]; const paused = Array.isArray(selected) ? selected : []; const changes = Array.isArray(adjusted) ? adjusted : []; groups.forEach(([type, items, groupKey]) => { if (!items.length) return; const group = el('div', 'pause-group'); group.append(el('strong', '', t(groupKey))); items.forEach((item) => { const existing = changes.find((entry) => entry.type === type && entry.id === item.id); const row = el('div', 'vacation-option'); const top = el('div', 'vacation-option-top'); const title = el('span', 'vacation-option-name', item.name); const mode = document.createElement('select'); mode.className = 'vacation-mode'; mode.dataset.vacationMode = 'true'; mode.dataset.vacationType = type; mode.dataset.vacationId = item.id; mode.setAttribute('aria-label', t('form.vacationModeLabel', { name: item.name })); [['keep', 'form.vacationKeep'], ['pause', 'form.vacationPause'], ['adjust', 'form.vacationAdjust']].forEach(([value, key]) => { const option = document.createElement('option'); option.value = value; option.textContent = t(key); mode.append(option); }); mode.value = paused.some((entry) => entry.type === type && entry.id === item.id) ? 'pause' : (existing ? 'adjust' : 'keep'); top.append(title, mode); row.append(top); const fields = el('div', 'vacation-adjustment-fields'); const nameLabel = document.createElement('label'); nameLabel.append(el('span', '', t('form.vacationAdjustName'))); const nameInput = document.createElement('input'); nameInput.type = 'text'; nameInput.maxLength = 100; nameInput.value = existing?.name || item.name; nameInput.dataset.vacationField = 'name'; nameLabel.append(nameInput); fields.append(nameLabel); if (type === 'task') { const grid = el('div', 'form-grid'); [['time', 'form.vacationAdjustTime', 'time'], ['duration', 'form.vacationAdjustDuration', 'number'], ['endTime', 'form.vacationAdjustEnd', 'time']].forEach(([field, key, inputType]) => { const label = document.createElement('label'); label.append(el('span', '', t(key))); const input = document.createElement('input'); input.type = inputType; input.value = existing?.[field] || item[field] || ''; input.dataset.vacationField = field; if (field === 'duration') { input.min = '1'; input.max = '1440'; input.step = '1'; } label.append(input); grid.append(label); }); fields.append(grid); const weekdayFieldset = document.createElement('fieldset'); weekdayFieldset.className = 'vacation-weekday-picker'; const legend = document.createElement('legend'); legend.textContent = t('form.vacationAdjustDays'); const weekdayList = el('div', 'vacation-weekdays'); const selectedDays = Array.isArray(existing?.activeWeekdays) ? existing.activeWeekdays : defaultVacationWeekdays(item); weekdayOptions.forEach(([value, key]) => { const label = el('label', 'vacation-weekday'); const input = document.createElement('input'); input.type = 'checkbox'; input.value = value; input.checked = selectedDays.includes(Number(value)); input.dataset.vacationWeekday = 'true'; const text = el('span', '', t(key)); label.append(input, text); weekdayList.append(label); }); weekdayFieldset.append(legend, weekdayList, el('p', 'form-help', t('form.vacationAdjustDaysHint'))); fields.append(weekdayFieldset); } fields.append(el('p', 'form-help', t('form.vacationAdjustHint'))); row.append(fields); const sync = () => { fields.hidden = mode.value !== 'adjust'; }; mode.addEventListener('change', sync); sync(); group.append(row); }); container.append(group); }); if (!container.children.length) container.append(el('p', 'form-help', t('vacations.noItems'))); }
export function renderEnergyHistory(container, entries = []) { container.replaceChildren(); const today = energyDateKey(new Date()); const sorted = (Array.isArray(entries) ? entries : []).filter((entry) => energyDateKey(entry.recordedAt) === today).slice().sort((a, b) => String(b.recordedAt).localeCompare(String(a.recordedAt))); if (!sorted.length) { container.append(el('span', 'energy-history-empty', t('today.energyEmpty'))); return; } container.append(el('div', 'energy-history-heading', t('today.energyHistory'))); const list = el('ul', 'energy-history-list'); sorted.slice(0, 8).forEach((entry) => { const row = el('li', 'energy-history-entry'); const value = el('strong', '', t('today.energyEntry', { value: entry.value })); const timestamp = el('time', '', new Intl.DateTimeFormat(t('dateLocale'), { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(entry.recordedAt))); timestamp.dateTime = entry.recordedAt; row.append(value, timestamp); list.append(row); }); container.append(list); }

export function updateDashboard(state, pausedKeys = new Set()) {
  const todayTasks = state.tasks.filter((task) => isTaskActive(task) && !pausedKeys.has(`task:${task.id}`));
  const total = todayTasks.length;
  const done = todayTasks.filter((task) => isTaskDone(task)).length;
  const value = document.getElementById('progressValue');
  const bar = document.getElementById('progressBar');
  if (value) value.textContent = `${done} / ${total}`;
  if (bar) bar.style.width = `${total ? Math.round(done / total * 100) : 0}%`;
  const today = energyDateKey(new Date());
  const todayEntries = Array.isArray(state.energyEntries) ? state.energyEntries.filter((entry) => energyDateKey(entry.recordedAt) === today) : [];
  const latestEnergy = todayEntries.length ? todayEntries[todayEntries.length - 1].value : null;
  const energy = document.getElementById('energyValue');
  if (energy) energy.textContent = latestEnergy ? t('messages.energy', { value: latestEnergy }) : t('messages.energyOpen');
  document.querySelectorAll('[data-energy]').forEach((button) => button.classList.toggle('is-selected', latestEnergy !== null && Number(button.dataset.energy) === Number(latestEnergy)));
  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const todayKeyValue = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const openTasks = todayTasks.filter((task) => !isTaskDone(task, now));
  const taskEntries = openTasks.map((task) => ({ kind: 'task', start: timeToMinutes(task.time), data: task }));
  const todaysAppointments = (state.appointments || []).filter((appointment) => appointment.date === todayKeyValue);
  const appointmentEntries = todaysAppointments.map((appointment) => ({ kind: 'appointment', start: timeToMinutes(appointment.time), data: appointment }));
  const isCurrentOrUpcoming = (entry) => { if (entry.start === null) return false; const duration = Number(entry.data.duration) || 0; return entry.start >= nowMinutes || (nowMinutes >= entry.start && nowMinutes <= entry.start + duration); };
  const upcomingCombined = [...taskEntries, ...appointmentEntries].filter(isCurrentOrUpcoming).sort((a, b) => (a.start ?? 1440) - (b.start ?? 1440));
  // Fallback bleibt wie bisher eine Aufgabe (die erste offene, auch wenn überfällig) -
  // für Termine gibt es kein "überfällig, aber noch offen", die fallen nach ihrer Zeit einfach weg.
  const fallbackTask = taskEntries.slice().sort((a, b) => (a.start ?? 1440) - (b.start ?? 1440))[0] || null;
  const focus = upcomingCombined[0] || fallbackTask;
  const focusTitle = document.getElementById('focusTitle');
  const focusMeta = document.getElementById('focusMeta');
  const focusDone = document.getElementById('focusDoneBtn');
  const isTaskFocus = focus?.kind === 'task';
  if (focusTitle) focusTitle.textContent = focus ? (isTaskFocus ? focus.data.name : focus.data.title) : t('messages.emptyTasks');
  if (focusMeta) focusMeta.textContent = focus ? (isTaskFocus ? taskMeta(focus.data) : appointmentTimeText(focus.data)) : t('messages.emptyTasksHint');
  if (focusDone) {
    focusDone.dataset.taskId = isTaskFocus ? focus.data.id : '';
    focusDone.dataset.appointmentId = focus && !isTaskFocus ? focus.data.id : '';
    focusDone.disabled = !isTaskFocus;
    focusDone.setAttribute('aria-disabled', String(!isTaskFocus));
  }
}
export const THEME_PRESETS = {
  sand: { bg: '#f5f1e9', primary: '#39766c', accent: '#d98b63' },
  sky: { bg: '#edf4f2', primary: '#3e7880', accent: '#d58d58' },
  peach: { bg: '#fbf0e9', primary: '#9a5c61', accent: '#d48658' },
  night: { bg: '#202829', primary: '#80b7aa', accent: '#e3a27d' },
  graphit: { bg: '#1c1d1f', primary: '#8791a0', accent: '#c9935a' },
};

const hexToRgb = (hex) => { const clean = String(hex || '').replace('#', ''); const full = clean.length === 3 ? clean.split('').map((c) => c + c).join('') : clean.padStart(6, '0'); const value = parseInt(full, 16); return { r: (value >> 16) & 255, g: (value >> 8) & 255, b: value & 255 }; };
const rgbToHex = ({ r, g, b }) => `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`;
const relativeLuminance = ({ r, g, b }) => { const [R, G, B] = [r, g, b].map((v) => { const c = v / 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; }); return 0.2126 * R + 0.7152 * G + 0.0722 * B; };
const mix = (hexA, hexB, weight) => { const a = hexToRgb(hexA); const b = hexToRgb(hexB); return rgbToHex({ r: a.r + (b.r - a.r) * weight, g: a.g + (b.g - a.g) * weight, b: a.b + (b.b - a.b) * weight }); };

// Leitet aus den drei vom Nutzer gewählten Farben (Hintergrund/Hauptfarbe/Akzent) eine
// vollständige, stimmige Palette für ALLE Oberflächen ab (Karten, Ränder, gedämpfter Text,
// Badges usw.) - statt nur die drei Grundfarben zu setzen und den Rest fest auf dem
// Sand-Standard zu belassen.
function deriveCustomPalette(bg, primary, accent) {
  const isDark = relativeLuminance(hexToRgb(bg)) < 0.4;
  const white = '#ffffff'; const black = '#000000';
  return {
    bg,
    surface: isDark ? mix(bg, white, 0.09) : mix(bg, white, 0.65),
    surfaceSoft: isDark ? mix(bg, white, 0.17) : mix(bg, black, 0.06),
    ink: isDark ? mix(bg, white, 0.88) : mix(bg, black, 0.82),
    muted: isDark ? mix(bg, white, 0.55) : mix(bg, black, 0.45),
    line: isDark ? mix(bg, white, 0.24) : mix(bg, black, 0.12),
    primary,
    primaryDeep: isDark ? mix(primary, white, 0.2) : mix(primary, black, 0.24),
    accent,
    accentSoft: isDark ? mix(accent, bg, 0.72) : mix(accent, white, 0.82),
    focus: mix(accent, '#ffe08a', 0.35),
    shadow: isDark ? '0 14px 35px rgba(0,0,0,.4)' : '0 14px 35px rgba(46,60,52,.08)',
    colorScheme: isDark ? 'dark' : 'light',
  };
}

const CUSTOM_VARS = ['--bg', '--surface', '--surface-soft', '--ink', '--muted', '--line', '--primary', '--primary-deep', '--accent', '--accent-soft', '--focus', '--shadow'];

export function applySettings(settings) {
  const root = document.documentElement;
  root.dataset.theme = settings.theme || 'sand';
  root.dataset.size = settings.size || 'normal';
  root.dataset.radius = settings.radius || 'soft';
  root.dataset.reduceMotion = settings.reduceMotion ? 'true' : 'false';
  CUSTOM_VARS.forEach((name) => root.style.removeProperty(name));
  root.style.removeProperty('color-scheme');
  if (settings.theme === 'custom') {
    const palette = deriveCustomPalette(settings.customBackground || THEME_PRESETS.sand.bg, settings.customPrimary || THEME_PRESETS.sand.primary, settings.customAccent || THEME_PRESETS.sand.accent);
    root.style.setProperty('--bg', palette.bg);
    root.style.setProperty('--surface', palette.surface);
    root.style.setProperty('--surface-soft', palette.surfaceSoft);
    root.style.setProperty('--ink', palette.ink);
    root.style.setProperty('--muted', palette.muted);
    root.style.setProperty('--line', palette.line);
    root.style.setProperty('--primary', palette.primary);
    root.style.setProperty('--primary-deep', palette.primaryDeep);
    root.style.setProperty('--accent', palette.accent);
    root.style.setProperty('--accent-soft', palette.accentSoft);
    root.style.setProperty('--focus', palette.focus);
    root.style.setProperty('--shadow', palette.shadow);
    root.style.setProperty('color-scheme', palette.colorScheme);
  }
}
export { t };

const energyDateKey = (date) => { const value = new Date(date); if (Number.isNaN(value.getTime())) return ''; return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, '0')}-${String(value.getDate()).padStart(2, '0')}`; };
const energyDateLabel = (value) => { if (!value) return ''; try { return new Intl.DateTimeFormat(t('dateLocale'), { dateStyle: 'medium' }).format(new Date(`${value}T12:00:00`)); } catch { return value; } };

export function renderEnergyReport(container, entries = [], options = {}) {
  if (!container) return;
  container.replaceChildren();
  const validEntries = (Array.isArray(entries) ? entries : []).filter((entry) => Number(entry?.value) >= 1 && Number(entry?.value) <= 5 && !Number.isNaN(Date.parse(entry?.recordedAt)));
  const period = options.period || '30';
  let from = '';
  let to = energyDateKey(new Date());
  if (period === 'all') {
    from = validEntries.length ? energyDateKey(validEntries.reduce((oldest, entry) => Date.parse(entry.recordedAt) < Date.parse(oldest) ? entry.recordedAt : oldest, validEntries[0].recordedAt)) : '';
    to = '';
  } else if (period === 'custom') {
    from = options.from || '';
    to = options.to || '';
  } else {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - (Number(period) - 1));
    from = energyDateKey(start);
  }
  if (period === 'custom' && (!from || !to || from > to)) {
    container.append(emptyState(t('energy.invalidRange'), t('energy.emptyHint')));
    return;
  }
  const filtered = validEntries.filter((entry) => { const key = energyDateKey(entry.recordedAt); return (!from || key >= from) && (!to || key <= to); }).sort((a, b) => String(b.recordedAt).localeCompare(String(a.recordedAt)));
  const range = period === 'all' ? t('energy.periodAll') : period === 'custom' ? `${energyDateLabel(from)} – ${energyDateLabel(to)}` : t(`energy.period${period}`);
  container.append(el('h2', 'energy-report-title', t('energy.summary', { range })));
  if (!filtered.length) { container.append(emptyState(t('energy.empty'), t('energy.emptyHint'))); return; }
  const values = filtered.map((entry) => Number(entry.value));
  const average = values.reduce((sum, value) => sum + value, 0) / values.length;
  const stats = el('div', 'energy-report-stats');
  [[t('energy.average'), average.toFixed(1).replace('.', ',')], [t('energy.measurements'), values.length], [t('energy.lowest'), Math.min(...values)], [t('energy.highest'), Math.max(...values)]].forEach(([label, value]) => { const card = el('div', 'energy-report-stat'); card.append(el('span', '', label), el('strong', '', String(value))); stats.append(card); });
  const list = el('div', 'energy-report-list');
  filtered.forEach((entry) => { const row = el('div', 'energy-report-entry'); const top = el('div', 'energy-report-entry-top'); const timestamp = new Intl.DateTimeFormat(t('dateLocale'), { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(entry.recordedAt)); top.append(el('time', '', timestamp), el('strong', '', t('energy.entry', { value: entry.value }))); const track = el('div', 'energy-meter'); const fill = el('span'); fill.style.width = `${Number(entry.value) * 20}%`; fill.setAttribute('aria-hidden', 'true'); track.append(fill); row.append(top, track); list.append(row); });
  container.append(stats, el('h3', 'energy-report-list-title', t('today.energyHistory')), list);
}

