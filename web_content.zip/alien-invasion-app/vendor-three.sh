#!/usr/bin/env bash
# OPTIONAL but recommended: make the game fully offline by storing three.js inside the app.
# Run once, with internet, inside this folder:   bash vendor-three.sh
set -e
mkdir -p vendor/three/examples/jsm
npm pack three@0.160.0 >/dev/null
tar -xzf three-0.160.0.tgz
cp package/build/three.module.js vendor/three/three.module.js
cp -r package/examples/jsm/postprocessing vendor/three/examples/jsm/
cp -r package/examples/jsm/shaders vendor/three/examples/jsm/
rm -rf package three-0.160.0.tgz
sed -i 's#https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js#./vendor/three/three.module.js#' index.html
sed -i "s#https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/#./vendor/three/examples/jsm/#" index.html
echo "Done. Add the vendor/ files to the PRE list in sw.js (or just open the game once online)."
