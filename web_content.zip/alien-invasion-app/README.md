# Space Fight: Alien Invasion — Android / Play Store package

This folder is a Progressive Web App (PWA). Google Play accepts it as a real Android app through a
Trusted Web Activity (TWA). Nothing here can be uploaded to the Play Store automatically — follow the steps.

## What the game now does
- **Memory card**: progress is saved on the device. Each chapter shows ✔ complete / ▶ current / 🔒 locked.
- **Chapters open only after the previous one is completed.** No admin code, no cheat button.
- **Cutscene SKIP is locked (🔒)** until that chapter has been completed once.
- "Continue" button loads the latest chapter on the card. "Erase card" resets progress.

## 1. Host the folder on HTTPS (free)
Netlify Drop, GitHub Pages, Firebase Hosting or Cloudflare Pages. You get a URL like `https://yourgame.netlify.app/`.
Open it on your phone: it should offer "Install app". (Optional, for full offline play: run `bash vendor-three.sh` first.)

## 2. Build the Android app (AAB)
Easiest: go to **pwabuilder.com**, paste your URL, choose **Android → Google Play**, download the package.
Alternative: Bubblewrap CLI (`npm i -g @bubblewrap/cli`, `bubblewrap init --manifest https://yourgame.netlify.app/manifest.webmanifest`, `bubblewrap build`).
Pick a package name such as `com.yourname.alieninvasion`, orientation landscape, fullscreen.

## 3. Digital Asset Links (removes the browser address bar)
After uploading to Play Console, copy the **App signing SHA-256 fingerprint** (Play Console → Setup → App signing).
Put it, and your package name, in `.well-known/assetlinks.json`, and re-host so
`https://yourgame.netlify.app/.well-known/assetlinks.json` opens.

## 4. Play Console
1. Create a developer account (one-time fee) at play.google.com/console.
2. Create app → upload the `.aab` → store listing (icon 512×512 is in `icons/`, feature graphic 1024×500, phone screenshots).
3. Privacy policy URL: host `privacy.html` and put your email in it.
4. Fill in Data safety (no data collected), content rating (fantasy violence), target audience, "contains no ads".
5. New personal developer accounts must run a **closed test with testers for ~2 weeks** before production — check the current rule in Play Console.

## 5. READ THIS BEFORE SUBMITTING — characters and names
The game uses **Thor, Mjölnir, Hela, Asgard** (Marvel), **Warden, Wither, Iron Golem, Ender Dragon, Minecraft-style blocks** (Mojang/Microsoft),
**Adu Du** (BoBoiBoy / Monsta) and real YouTuber names. Google Play's Intellectual Property and Impersonation policies
can reject or remove apps that use other companies' characters or trademarks without permission, even when free.
For a Play Store release, replace these with original characters/names (and get written permission for any real person's name or likeness).
I did not change them here because you did not ask me to.
