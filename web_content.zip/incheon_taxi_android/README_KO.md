# 오늘도 달린다 오늘도 참는다 - Android Studio 프로젝트

기존 HTML 매출관리 화면을 Android WebView 앱으로 감싼 프로젝트입니다. 매출·주유량·메모는 앱 내부 WebView의 localStorage에 저장됩니다.

## AAB(Play 스토어 업로드 파일) 만들기
1. PC에 Android Studio 최신 안정판과 JDK 17을 설치합니다.
2. Android Studio에서 이 폴더 `incheon_taxi_android`를 엽니다.
3. SDK Manager에서 Android SDK Platform 36과 Build Tools를 설치하고 Gradle 동기화를 완료합니다.
4. 메뉴 **Build > Generate Signed Bundle / APK**를 선택합니다.
5. **Android App Bundle**을 선택합니다.
6. 새 keystore를 만들고 비밀번호를 안전하게 보관합니다. 키 파일과 비밀번호를 잃으면 이후 업데이트가 어려울 수 있습니다.
7. Release 빌드를 완료하면 Android Studio가 `.aab` 파일 위치를 알려줍니다.
8. Google Play Console에서 개발자 계정을 등록하고 앱을 만든 뒤, AAB를 업로드하고 스토어 등록정보·개인정보처리방침·테스트 및 필수 정책 항목을 완료합니다.

## 주의
- 이 환경에는 Android SDK/Gradle 빌드 도구가 설치되어 있지 않아, 여기서 서명된 APK/AAB를 직접 빌드하거나 Google Play에 업로드할 수는 없습니다. 이 ZIP은 Android Studio에서 빌드할 프로젝트 소스입니다.
- Play Console에 공개하려면 개발자 계정, 앱 아이콘/스토어 그래픽, 개인정보처리방침 등 Google Play가 요구하는 항목이 추가로 필요할 수 있습니다.
- 현재 `applicationId`는 `kr.co.incheontaxi.sales`입니다. Play Console에 같은 ID의 앱이 이미 있거나 소유권 문제가 있으면, 최초 배포 전에 본인 소유의 고유 ID로 바꾸세요. 첫 출시 후에는 ID를 변경할 수 없습니다.
- 앱 데이터를 지우거나 앱을 삭제하면 저장된 기록이 없어질 수 있으므로 앱의 백업 기능으로 주기적으로 백업하세요.
