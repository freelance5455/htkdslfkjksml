인천택시 매출관리 - Android Studio 프로젝트

이 폴더는 APK를 빌드하기 위한 Android Studio 프로젝트 소스입니다.
현재 제공 파일은 APK 설치파일이 아니라 프로젝트 ZIP입니다.

APK 빌드 방법
1. PC에 Android Studio 최신 안정 버전을 설치합니다.
2. Android Studio에서 이 압축을 푼 폴더 'incheon_taxi_android'를 엽니다.
3. Gradle 동기화가 끝날 때까지 기다립니다. SDK Platform 35가 필요할 수 있습니다.
4. 메뉴 Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
5. 빌드 성공 알림에서 Locate를 누릅니다.
6. APK 경로: app/build/outputs/apk/debug/app-debug.apk
7. APK를 휴대전화로 옮겨 설치합니다. 처음에는 Android가 '알 수 없는 앱 설치' 권한을 물을 수 있습니다.

앱 특징
- 기존 매출관리 웹앱을 Android WebView 안에서 실행합니다.
- JavaScript와 로컬 저장소를 켜서 입력 자동 저장을 지원합니다.
- 인터넷 연결 없이 앱 화면을 열 수 있도록 웹 파일을 앱에 포함했습니다.

중요
- 이 프로젝트는 여기서 실제 APK로 컴파일/서명/기기 설치 테스트를 완료한 것이 아닙니다.
- APK 파일이 필요하면 Android Studio 빌드 과정이 필요합니다.
- 앱 데이터는 해당 앱의 로컬 저장공간에 저장됩니다. 앱 삭제 또는 앱 데이터 삭제 전에 내보내기 백업을 권장합니다.
