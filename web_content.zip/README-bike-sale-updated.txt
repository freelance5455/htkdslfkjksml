බයික් සේල් — Updated offline web app

Updated:
- Bike card price and arrow spacing adjusted to avoid overlap.
- Drawer menu now immediately displays unsold-bike investment and total realized profit/loss.
- Bike add/edit, additional costs, SOLD, search, dashboard and JSON backup/restore retained.

How to use:
1. Download and open bike-sale-manager-updated.html in your Android browser.
2. Use the left menu > Backup data to download a JSON backup.
3. On another phone, open the app file and use Restore backup to import that JSON file.

Important:
- This is still an HTML web app file, not an installable APK.
- Local data is saved in that browser on that phone. Keep backup files safe.
- Email login and automatic cloud syncing are not configured. A Firebase/cloud project and Android build are needed for that.
- No APK has been compiled in this environment, so this package should not be described as an APK.
