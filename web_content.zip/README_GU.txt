HARSH AI — ANDROID STUDIO PROJECT 1.1

આ Android Studio માં ખોલી શકાય એવો source project છે (તૈયાર APK નથી).

બે ફીચર જ રાખ્યાં છે:
1) Text to Speech — Androidના native TextToSpeech એન્જિનથી લખાણ બોલે, voice પસંદગી અને speed.
2) Text to Speech + Auto Caption — લાઇન પ્રમાણે બોલે અને caption બતાવે; Android API 26+ પર TTS range callbacks મળતાં શબ્દ હાઇલાઇટ થાય છે.

Build કરવાની રીત:
1. ZIP extract કરો.
2. Android Studio માં આ folder (જ્યાં settings.gradle છે) Open કરો.
3. Gradle sync પૂરો થવા દો.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/ માં મળશે.

જરૂરી: Android Studio અને Android SDK Platform 35 તથા compatible JDK જરૂરી છે. આ પર્યાવરણમાં Android SDK/Gradle build ઉપલબ્ધ ન હોવાથી APK compile test કરવામાં આવી નથી.

નોંધ: Voice list ફોનના Android TTS એન્જિન/ઇન્સ્ટોલ થયેલી ભાષાઓ પર આધારિત છે. SRT સમય અંદાજિત છે. આ project SRT/TXT આપે છે; final MP4 video rendering સામેલ નથી.
