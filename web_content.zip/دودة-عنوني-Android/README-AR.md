# دودة عنوني — مشروع Android يعمل دون إنترنت

## ما الذي جهزته؟
- نسخة اللعبة داخل `www/index.html`.
- صورة الأيقونة التي أرسلتها داخل `www/icon-512.png`.
- إعدادات Capacitor باسم التطبيق `دودة عنوني`.
- ملفات محلية؛ لا تحتاج اللعبة إلى اتصال إنترنت أثناء اللعب.

## إنشاء APK على Windows أو macOS أو Linux
تحتاج إلى Node.js LTS وAndroid Studio مع Android SDK.

1. فك ضغط الملف.
2. افتح المجلد في Terminal / PowerShell.
3. نفّذ:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. في Android Studio انتظر اكتمال Gradle Sync.
5. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. بعد نجاح البناء سيظهر مسار APK داخل مجلد `android/app/build/outputs/apk/`.

## ملاحظات
- هذا ملف مشروع جاهز للبناء، وليس APK مُجمّعاً أو مُوقّعاً بعد.
- أول مرة تحتاج إنترنت لتنزيل حزم npm ومكونات Gradle/Android؛ بعد ذلك محتوى اللعبة نفسه يعمل دون إنترنت.
- إذا أردت نشر التطبيق على متجر Google Play، أنشئ مفتاح توقيع خاصاً بك ولا تشاركه.
