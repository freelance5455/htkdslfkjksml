(function(){
  'use strict';
  const modules = {};
  const cache = {};
  function normalize(path){
    const parts=[];
    for(const p of path.split('/')){
      if(!p || p==='.') continue;
      if(p==='..') parts.pop(); else parts.push(p);
    }
    return parts.join('/');
  }
  function resolve(from, req){
    if(req.startsWith('./') || req.startsWith('../')){
      return normalize(from.split('/').slice(0,-1).concat(req.split('/')).join('/'));
    }
    return req;
  }
  function load(id){
    if(id==='react') return window.React;
    if(id==='react-dom/client') return window.ReactDOM;
    if(id==='lucide-react') return window.__LucideShim;
    if(id.endsWith('.css')) return {};
    const clean=id.replace(/\.tsx$|\.ts$|\.js$/,'');
    if(cache[clean]) return cache[clean].exports;
    const factory=modules[clean];
    if(!factory) throw new Error('Module not found: '+clean);
    const module={exports:{}};
    cache[clean]=module;
    function localRequire(req){ return load(resolve(clean, req)); }
    factory(module,module.exports,localRequire);
    return module.exports;
  }
  function Activity(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function AlertCircle(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function AlertTriangle(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function ArrowLeft(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function ArrowRight(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Bot(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Calendar(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Check(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function CheckCircle(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function CheckCircle2(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Clock(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Coins(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Copy(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Download(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function ExternalLink(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Eye(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function EyeOff(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function FileText(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Filter(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Flame(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Gift(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Heart(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function HelpCircle(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Instagram(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function KeyRound(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Lock(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Mail(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function MessageCircle(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function RefreshCw(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function RotateCcw(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Save(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Search(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Send(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Server(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Settings(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Share2(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Shield(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function ShieldCheck(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Sparkles(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Trash2(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function TrendingUp(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Type(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function User(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Users(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function X(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  function Zap(props){ const p=props||{}; return React.createElement('svg', Object.assign({xmlns:'http://www.w3.org/2000/svg', viewBox:'0 0 24 24', fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round'}, p, {className:p.className||'w-5 h-5', 'aria-hidden':p['aria-hidden']!==undefined?p['aria-hidden']:'true'}), React.createElement('circle',{cx:12,cy:12,r:9}), React.createElement('path',{d:'M12 8v8M8 12h8'})); }
  const __LucideShim = {Activity:Activity,AlertCircle:AlertCircle,AlertTriangle:AlertTriangle,ArrowLeft:ArrowLeft,ArrowRight:ArrowRight,Bot:Bot,Calendar:Calendar,Check:Check,CheckCircle:CheckCircle,CheckCircle2:CheckCircle2,Clock:Clock,Coins:Coins,Copy:Copy,Download:Download,ExternalLink:ExternalLink,Eye:Eye,EyeOff:EyeOff,FileText:FileText,Filter:Filter,Flame:Flame,Gift:Gift,Heart:Heart,HelpCircle:HelpCircle,Instagram:Instagram,KeyRound:KeyRound,Lock:Lock,Mail:Mail,MessageCircle:MessageCircle,RefreshCw:RefreshCw,RotateCcw:RotateCcw,Save:Save,Search:Search,Send:Send,Server:Server,Settings:Settings,Share2:Share2,Shield:Shield,ShieldCheck:ShieldCheck,Sparkles:Sparkles,Trash2:Trash2,TrendingUp:TrendingUp,Type:Type,User:User,Users:Users,X:X,Zap:Zap};
  window.__LucideShim=__LucideShim;
  modules["main"]=function(module,exports,require){
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const client_1 = require("react-dom/client");
const App_tsx_1 = __importDefault(require("./App"));
require("./index.css");
(0, client_1.createRoot)(document.getElementById('root')).render(React.createElement(react_1.StrictMode, null,
    React.createElement(App_tsx_1.default, null)));

  };
  modules["App"]=function(module,exports,require){
"use strict";
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = App;
const react_1 = __importStar(require("react"));
const Header_1 = require("./components/Header");
const GrowthForm_1 = require("./components/GrowthForm");
const FollowerSelectionModal_1 = require("./components/FollowerSelectionModal");
const CountdownModal_1 = require("./components/CountdownModal");
const SuccessModal_1 = require("./components/SuccessModal");
const ChatbotModal_1 = require("./components/ChatbotModal");
const AdminPanel_1 = require("./components/AdminPanel");
const SettingsModal_1 = require("./components/SettingsModal");
const CoinRewardModal_1 = require("./components/CoinRewardModal");
const api_1 = require("./services/api");
const lucide_react_1 = require("lucide-react");
function App() {
    // App state
    const [settings, setSettings] = (0, react_1.useState)({
        admin_code: '805040',
        app_title: 'Grow Your Instagram',
        app_subtitle: 'Get real followers instantly ✨',
        form_title: 'Add Instagram Account',
        form_subtitle: 'अपना Instagram अकाउंट जोड़ें',
        coins_default: 500,
    });
    const [accounts, setAccounts] = (0, react_1.useState)([]);
    const [coins, setCoins] = (0, react_1.useState)(500);
    const [isAdminUnlocked, setIsAdminUnlocked] = (0, react_1.useState)(false);
    // Workflow modals state
    const [tempUsername, setTempUsername] = (0, react_1.useState)('');
    const [tempPassword, setTempPassword] = (0, react_1.useState)('');
    const [selectedFollowers, setSelectedFollowers] = (0, react_1.useState)(500);
    const [currentOrderId, setCurrentOrderId] = (0, react_1.useState)('');
    const [isFollowersModalOpen, setIsFollowersModalOpen] = (0, react_1.useState)(false);
    const [isCountdownOpen, setIsCountdownOpen] = (0, react_1.useState)(false);
    const [isSuccessModalOpen, setIsSuccessModalOpen] = (0, react_1.useState)(false);
    // Feature modals state
    const [isChatOpen, setIsChatOpen] = (0, react_1.useState)(false);
    const [isAdminPanelOpen, setIsAdminPanelOpen] = (0, react_1.useState)(false);
    const [isSettingsModalOpen, setIsSettingsModalOpen] = (0, react_1.useState)(false);
    const [isCoinsModalOpen, setIsCoinsModalOpen] = (0, react_1.useState)(false);
    // Initial load
    const loadInitialData = (0, react_1.useCallback)(async () => {
        try {
            const fetchedSettings = await api_1.api.getSettings();
            setSettings(fetchedSettings);
            const fetchedAccounts = await api_1.api.getAccounts();
            setAccounts(fetchedAccounts);
            const userCoins = api_1.api.getCoins();
            setCoins(userCoins);
            const adminAuth = api_1.api.isAdminAuthenticated();
            setIsAdminUnlocked(adminAuth);
        }
        catch (err) {
            console.error('Error initializing app state:', err);
        }
    }, []);
    (0, react_1.useEffect)(() => {
        loadInitialData();
    }, [loadInitialData]);
    // Step 1 & 2: User submits Add Account form
    const handleInitiateAddAccount = (username, pass) => {
        setTempUsername(username);
        setTempPassword(pass);
        setIsFollowersModalOpen(true);
    };
    // Step 3 & 4: User selects followers and clicks Send
    const handleConfirmSendFollowers = (followersCount) => {
        setSelectedFollowers(followersCount);
        setIsFollowersModalOpen(false);
        setIsCountdownOpen(true);
    };
    // Step 5 & 6: 10-second countdown finishes -> save to DB and show Success popup
    const handleCountdownComplete = async () => {
        setIsCountdownOpen(false);
        // Save to database
        try {
            const newAcc = await api_1.api.addAccount({
                username: tempUsername,
                password: tempPassword,
                followers_requested: selectedFollowers,
                created_by: api_1.USER_EMAIL,
            });
            // Deduct coins if appropriate
            api_1.api.deductCoins(Math.min(100, coins));
            setCoins(api_1.api.getCoins());
            // Update accounts list
            setAccounts((prev) => [newAcc, ...prev.filter((a) => a.id !== newAcc.id)]);
            setCurrentOrderId(newAcc.id.toUpperCase());
        }
        catch (err) {
            console.error('Failed to save account to database:', err);
            setCurrentOrderId(`ORD-${Date.now().toString(36).toUpperCase()}`);
        }
        setIsSuccessModalOpen(true);
    };
    // Admin Verification & Actions
    const handleUnlockAdmin = () => {
        setIsAdminUnlocked(true);
        api_1.api.setAdminAuthenticated(true);
    };
    const handleOpenAdmin = () => {
        setIsAdminPanelOpen(true);
        setIsChatOpen(false);
    };
    const handleCloseAdmin = () => {
        setIsAdminPanelOpen(false);
    };
    const handleSaveSettings = async (newSettings) => {
        const updated = await api_1.api.updateSettings(newSettings);
        setSettings(updated);
    };
    const handleUpdateStatus = async (id, status) => {
        await api_1.api.updateAccountStatus(id, status);
        setAccounts((prev) => prev.map((acc) => (acc.id === id ? { ...acc, status } : acc)));
    };
    const handleDeleteAccount = async (id) => {
        await api_1.api.deleteAccount(id);
        setAccounts((prev) => prev.filter((acc) => acc.id !== id));
    };
    const handleRefreshAccounts = async () => {
        const refreshed = await api_1.api.getAccounts();
        setAccounts(refreshed);
    };
    const handleAddCoins = (amount) => {
        const updated = api_1.api.addCoins(amount);
        setCoins(updated);
    };
    // If Admin Panel is open, display full Admin View
    if (isAdminPanelOpen) {
        return (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(AdminPanel_1.AdminPanel, { accounts: accounts, settings: settings, onClose: handleCloseAdmin, onOpenSettings: () => setIsSettingsModalOpen(true), onUpdateStatus: handleUpdateStatus, onDeleteAccount: handleDeleteAccount, onRefresh: handleRefreshAccounts }),
            react_1.default.createElement(SettingsModal_1.SettingsModal, { settings: settings, isOpen: isSettingsModalOpen, onClose: () => setIsSettingsModalOpen(false), onSaveSettings: handleSaveSettings })));
    }
    return (react_1.default.createElement("div", { className: "min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-purple-950 text-slate-100 flex flex-col justify-between selection:bg-pink-500 selection:text-white" },
        react_1.default.createElement(Header_1.Header, { coins: coins, onOpenChat: () => setIsChatOpen(true), onOpenCoinsModal: () => setIsCoinsModalOpen(true), isAdminUnlocked: isAdminUnlocked, onOpenAdmin: handleOpenAdmin }),
        react_1.default.createElement("main", { className: "flex-1 max-w-6xl w-full mx-auto px-4 py-8 sm:py-12 flex flex-col items-center justify-center" },
            react_1.default.createElement(GrowthForm_1.GrowthForm, { settings: settings, onInitiateAddAccount: handleInitiateAddAccount }),
            react_1.default.createElement("div", { className: "w-full max-w-4xl mt-12 grid grid-cols-1 md:grid-cols-3 gap-4" },
                react_1.default.createElement("div", { className: "p-4 rounded-2xl bg-slate-900/60 border border-purple-500/20 backdrop-blur-md flex items-start gap-3" },
                    react_1.default.createElement("div", { className: "w-9 h-9 rounded-xl bg-pink-500/15 text-pink-400 flex items-center justify-center shrink-0" },
                        react_1.default.createElement(lucide_react_1.Zap, { className: "w-5 h-5" })),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("h4", { className: "text-sm font-bold text-white" }, "Instant Safe Delivery"),
                        react_1.default.createElement("p", { className: "text-xs text-slate-400 mt-0.5" }, "Orders dispatch automatically within seconds. Followers arrive steadily within 24 hours."))),
                react_1.default.createElement("div", { className: "p-4 rounded-2xl bg-slate-900/60 border border-purple-500/20 backdrop-blur-md flex items-start gap-3" },
                    react_1.default.createElement("div", { className: "w-9 h-9 rounded-xl bg-purple-500/15 text-purple-400 flex items-center justify-center shrink-0" },
                        react_1.default.createElement(lucide_react_1.Shield, { className: "w-5 h-5" })),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("h4", { className: "text-sm font-bold text-white" }, "Zero Ban Risk Protocol"),
                        react_1.default.createElement("p", { className: "text-xs text-slate-400 mt-0.5" }, "Engineered with compliant organic drip velocity to strictly protect your Instagram profile."))),
                react_1.default.createElement("div", { className: "p-4 rounded-2xl bg-slate-900/60 border border-purple-500/20 backdrop-blur-md flex items-start gap-3" },
                    react_1.default.createElement("div", { className: "w-9 h-9 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0" },
                        react_1.default.createElement(lucide_react_1.Heart, { className: "w-5 h-5" })),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("h4", { className: "text-sm font-bold text-white" }, "Active High Retention"),
                        react_1.default.createElement("p", { className: "text-xs text-slate-400 mt-0.5" }, "Real accounts with profiles, bios, and active history backed by 30-day drop protection."))))),
        react_1.default.createElement("footer", { className: "w-full border-t border-purple-500/15 bg-slate-950/80 backdrop-blur-md py-6 text-center text-xs text-slate-400" },
            react_1.default.createElement("div", { className: "max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3" },
                react_1.default.createElement("div", { className: "flex items-center gap-2" },
                    react_1.default.createElement(lucide_react_1.Instagram, { className: "w-4 h-4 text-pink-400" }),
                    react_1.default.createElement("span", { className: "font-semibold text-slate-200" }, "InstaBoost Premium"),
                    react_1.default.createElement("span", { className: "text-slate-600" }, "\u2022"),
                    react_1.default.createElement("span", null, "All rights reserved")),
                react_1.default.createElement("div", { className: "flex items-center gap-4 text-[11px] text-slate-400" },
                    react_1.default.createElement("button", { onClick: () => setIsChatOpen(true), className: "hover:text-pink-300 transition-colors" }, "Support Chatbot"),
                    react_1.default.createElement("span", null, "\u2022"),
                    react_1.default.createElement("button", { onClick: () => setIsCoinsModalOpen(true), className: "hover:text-amber-300 transition-colors" }, "Coins & Rewards"),
                    react_1.default.createElement("span", null, "\u2022"),
                    react_1.default.createElement("button", { onClick: () => {
                            if (isAdminUnlocked) {
                                handleOpenAdmin();
                            }
                            else {
                                setIsChatOpen(true);
                            }
                        }, className: "text-purple-400 hover:text-purple-300 transition-colors" }, isAdminUnlocked ? 'Admin Panel 🚀' : 'Admin Login')))),
        isFollowersModalOpen && (react_1.default.createElement(FollowerSelectionModal_1.FollowerSelectionModal, { username: tempUsername, userCoins: coins, onClose: () => setIsFollowersModalOpen(false), onConfirmSend: handleConfirmSendFollowers })),
        isCountdownOpen && (react_1.default.createElement(CountdownModal_1.CountdownModal, { username: tempUsername, followersCount: selectedFollowers, onComplete: handleCountdownComplete })),
        isSuccessModalOpen && (react_1.default.createElement(SuccessModal_1.SuccessModal, { username: tempUsername, followersCount: selectedFollowers, orderId: currentOrderId, onClose: () => setIsSuccessModalOpen(false), onOpenAdmin: handleOpenAdmin, isAdminUnlocked: isAdminUnlocked })),
        react_1.default.createElement(ChatbotModal_1.ChatbotModal, { settings: settings, isOpen: isChatOpen, onClose: () => setIsChatOpen(false), onUnlockAdmin: handleUnlockAdmin, onOpenAdmin: handleOpenAdmin, isAdminUnlocked: isAdminUnlocked }),
        react_1.default.createElement(CoinRewardModal_1.CoinRewardModal, { isOpen: isCoinsModalOpen, coins: coins, onClose: () => setIsCoinsModalOpen(false), onAddCoins: handleAddCoins }),
        react_1.default.createElement(SettingsModal_1.SettingsModal, { settings: settings, isOpen: isSettingsModalOpen, onClose: () => setIsSettingsModalOpen(false), onSaveSettings: handleSaveSettings })));
}

  };
  modules["services/api"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.api = exports.USER_EMAIL = void 0;
exports.USER_EMAIL = 'jiteshprajapati18392@gmail.com';
const DEFAULT_SETTINGS = {
    admin_code: '805040',
    app_title: 'Grow Your Instagram',
    app_subtitle: 'Get real followers instantly ✨',
    form_title: 'Add Instagram Account',
    form_subtitle: 'अपना Instagram अकाउंट जोड़ें',
    coins_default: 500,
};
const LOCAL_STORAGE_SETTINGS_KEY = 'instaboost_settings_v1';
const LOCAL_STORAGE_ACCOUNTS_KEY = 'instaboost_accounts_v1';
const LOCAL_STORAGE_COINS_KEY = 'instaboost_user_coins_v1';
const LOCAL_STORAGE_ADMIN_AUTH_KEY = 'instaboost_admin_authenticated_v1';
// Initial mock accounts if localStorage is empty
const INITIAL_LOCAL_ACCOUNTS = [
    {
        id: 'acc_demo_1',
        username: 'rohit_sharma_official',
        password: 'password_sample_982',
        followers_requested: 1000,
        status: 'completed',
        created_by: exports.USER_EMAIL,
        created_at: new Date(Date.now() - 3600000 * 24).toISOString(),
    },
    {
        id: 'acc_demo_2',
        username: 'priya.creatives',
        password: 'priya_secure_pass1!',
        followers_requested: 500,
        status: 'processing',
        created_by: exports.USER_EMAIL,
        created_at: new Date(Date.now() - 3600000 * 5).toISOString(),
    },
    {
        id: 'acc_demo_3',
        username: 'vikram_fit_life',
        password: 'vikram_fit#2026',
        followers_requested: 2500,
        status: 'pending',
        created_by: exports.USER_EMAIL,
        created_at: new Date(Date.now() - 3600000 * 1).toISOString(),
    },
];
// Helper: load from localStorage
function getLocalSettings() {
    try {
        const raw = localStorage.getItem(LOCAL_STORAGE_SETTINGS_KEY);
        if (raw)
            return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    }
    catch (e) {
        console.warn('Error reading local settings:', e);
    }
    return DEFAULT_SETTINGS;
}
function saveLocalSettings(settings) {
    try {
        localStorage.setItem(LOCAL_STORAGE_SETTINGS_KEY, JSON.stringify(settings));
    }
    catch (e) {
        console.warn('Error saving local settings:', e);
    }
}
function getLocalAccounts() {
    try {
        const raw = localStorage.getItem(LOCAL_STORAGE_ACCOUNTS_KEY);
        if (raw) {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0)
                return parsed;
        }
    }
    catch (e) {
        console.warn('Error reading local accounts:', e);
    }
    return INITIAL_LOCAL_ACCOUNTS;
}
function saveLocalAccounts(accounts) {
    try {
        localStorage.setItem(LOCAL_STORAGE_ACCOUNTS_KEY, JSON.stringify(accounts));
    }
    catch (e) {
        console.warn('Error saving local accounts:', e);
    }
}
exports.api = {
    // --- Settings ---
    async getSettings() {
        try {
            const res = await fetch('/api/settings');
            if (res.ok) {
                const json = await res.json();
                if (json.data) {
                    saveLocalSettings(json.data);
                    return json.data;
                }
            }
        }
        catch {
            // server offline or failed, fallback to localStorage
        }
        return getLocalSettings();
    },
    async updateSettings(settings) {
        try {
            const res = await fetch('/api/settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(settings),
            });
            if (res.ok) {
                const json = await res.json();
                if (json.data) {
                    saveLocalSettings(json.data);
                    return json.data;
                }
            }
        }
        catch {
            // fallback
        }
        const current = getLocalSettings();
        const updated = { ...current, ...settings };
        saveLocalSettings(updated);
        return updated;
    },
    // --- Verify Admin Code ---
    async verifyAdminCode(code) {
        const cleanCode = code.trim();
        try {
            const res = await fetch('/api/verify-admin', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code: cleanCode }),
            });
            if (res.ok) {
                const json = await res.json();
                if (json.verified) {
                    localStorage.setItem(LOCAL_STORAGE_ADMIN_AUTH_KEY, 'true');
                    return true;
                }
            }
        }
        catch {
            // fallback to local check
        }
        const currentSettings = getLocalSettings();
        const verified = cleanCode === currentSettings.admin_code;
        if (verified) {
            localStorage.setItem(LOCAL_STORAGE_ADMIN_AUTH_KEY, 'true');
        }
        return verified;
    },
    isAdminAuthenticated() {
        return localStorage.getItem(LOCAL_STORAGE_ADMIN_AUTH_KEY) === 'true';
    },
    setAdminAuthenticated(auth) {
        if (auth) {
            localStorage.setItem(LOCAL_STORAGE_ADMIN_AUTH_KEY, 'true');
        }
        else {
            localStorage.removeItem(LOCAL_STORAGE_ADMIN_AUTH_KEY);
        }
    },
    // --- Instagram Accounts ---
    async getAccounts() {
        try {
            const res = await fetch('/api/accounts');
            if (res.ok) {
                const json = await res.json();
                if (Array.isArray(json.data)) {
                    saveLocalAccounts(json.data);
                    return json.data;
                }
            }
        }
        catch {
            // fallback
        }
        return getLocalAccounts();
    },
    async addAccount(accountData) {
        const payload = {
            ...accountData,
            created_by: accountData.created_by || exports.USER_EMAIL,
        };
        try {
            const res = await fetch('/api/accounts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            if (res.ok) {
                const json = await res.json();
                if (json.data) {
                    const accounts = getLocalAccounts();
                    saveLocalAccounts([json.data, ...accounts]);
                    return json.data;
                }
            }
        }
        catch {
            // fallback
        }
        const newAcc = {
            id: `acc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
            username: accountData.username.replace(/^@+/, '').trim(),
            password: accountData.password.trim(),
            followers_requested: accountData.followers_requested,
            status: 'pending',
            created_by: accountData.created_by || exports.USER_EMAIL,
            created_at: new Date().toISOString(),
        };
        const current = getLocalAccounts();
        saveLocalAccounts([newAcc, ...current]);
        return newAcc;
    },
    async updateAccountStatus(id, status) {
        try {
            const res = await fetch(`/api/accounts/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status }),
            });
            if (res.ok) {
                // sync local
                const accounts = getLocalAccounts().map((acc) => acc.id === id ? { ...acc, status, updated_at: new Date().toISOString() } : acc);
                saveLocalAccounts(accounts);
                return true;
            }
        }
        catch {
            // fallback
        }
        const accounts = getLocalAccounts().map((acc) => acc.id === id ? { ...acc, status, updated_at: new Date().toISOString() } : acc);
        saveLocalAccounts(accounts);
        return true;
    },
    async deleteAccount(id) {
        try {
            const res = await fetch(`/api/accounts/${id}`, {
                method: 'DELETE',
            });
            if (res.ok) {
                const accounts = getLocalAccounts().filter((acc) => acc.id !== id);
                saveLocalAccounts(accounts);
                return true;
            }
        }
        catch {
            // fallback
        }
        const accounts = getLocalAccounts().filter((acc) => acc.id !== id);
        saveLocalAccounts(accounts);
        return true;
    },
    // --- Coins Management ---
    getCoins() {
        try {
            const val = localStorage.getItem(LOCAL_STORAGE_COINS_KEY);
            if (val !== null)
                return parseInt(val, 10);
        }
        catch {
            // ignore
        }
        return 500;
    },
    setCoins(coins) {
        try {
            localStorage.setItem(LOCAL_STORAGE_COINS_KEY, String(Math.max(0, coins)));
        }
        catch (e) {
            console.warn('Error saving coins:', e);
        }
    },
    addCoins(amount) {
        const current = this.getCoins();
        const updated = current + amount;
        this.setCoins(updated);
        return updated;
    },
    deductCoins(amount) {
        const current = this.getCoins();
        if (current >= amount) {
            this.setCoins(current - amount);
            return true;
        }
        return false;
    },
};

  };
  modules["types/index"]=function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

  };
  modules["components/CountdownModal"]=function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CountdownModal = void 0;
const react_1 = __importStar(require("react"));
const lucide_react_1 = require("lucide-react");
const STATUS_STEPS = {
    10: 'Connecting to Instagram secure API gateway...',
    9: 'Validating target profile @{user}...',
    8: 'Verifying profile eligibility & status...',
    7: 'Allocating high-retention follower node pool...',
    6: 'Encrypting data payload with 256-bit SSL...',
    5: 'Preparing follower delivery batch queue...',
    4: 'Calibrating safe-velocity anti-ban protocol...',
    3: 'Establishing live Instagram delivery tunnel...',
    2: 'Synchronizing record with cloud database...',
    1: 'Finalizing order verification...',
    0: 'Dispatching growth request!',
};
const CountdownModal = ({ username, followersCount, onComplete, }) => {
    const [secondsLeft, setSecondsLeft] = (0, react_1.useState)(10);
    (0, react_1.useEffect)(() => {
        if (secondsLeft <= 0) {
            const timer = setTimeout(() => {
                onComplete();
            }, 500);
            return () => clearTimeout(timer);
        }
        const interval = setInterval(() => {
            setSecondsLeft((prev) => prev - 1);
        }, 1000);
        return () => clearInterval(interval);
    }, [secondsLeft, onComplete]);
    // Circle stroke offset calculation
    const totalSeconds = 10;
    const radius = 64;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - ((10 - secondsLeft) / totalSeconds) * circumference;
    const currentStatus = (STATUS_STEPS[secondsLeft] || STATUS_STEPS[1]).replace('{user}', username);
    return (react_1.default.createElement("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-300" },
        react_1.default.createElement("div", { className: "relative w-full max-w-md rounded-3xl bg-slate-900/95 border border-purple-500/40 p-8 shadow-2xl shadow-purple-950/90 text-center overflow-hidden" },
            react_1.default.createElement("div", { className: "absolute -top-16 -right-16 w-36 h-36 bg-pink-500/20 rounded-full blur-2xl pointer-events-none" }),
            react_1.default.createElement("div", { className: "absolute -bottom-16 -left-16 w-36 h-36 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" }),
            react_1.default.createElement("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-200 text-xs font-semibold mb-6" },
                react_1.default.createElement(lucide_react_1.Activity, { className: "w-3.5 h-3.5 text-pink-400 animate-pulse" }),
                react_1.default.createElement("span", null, "Processing Follower Transmission")),
            react_1.default.createElement("div", { className: "relative w-44 h-44 mx-auto mb-6 flex items-center justify-center" },
                react_1.default.createElement("svg", { className: "w-full h-full transform -rotate-90", viewBox: "0 0 160 160" },
                    react_1.default.createElement("circle", { cx: "80", cy: "80", r: radius, stroke: "rgba(147, 51, 234, 0.2)", strokeWidth: "10", fill: "transparent" }),
                    react_1.default.createElement("circle", { cx: "80", cy: "80", r: radius, stroke: "url(#gradient)", strokeWidth: "10", strokeDasharray: circumference, strokeDashoffset: strokeDashoffset, strokeLinecap: "round", fill: "transparent", className: "transition-all duration-1000 ease-linear" }),
                    react_1.default.createElement("defs", null,
                        react_1.default.createElement("linearGradient", { id: "gradient", x1: "0%", y1: "0%", x2: "100%", y2: "100%" },
                            react_1.default.createElement("stop", { offset: "0%", stopColor: "#ec4899" }),
                            react_1.default.createElement("stop", { offset: "50%", stopColor: "#a855f7" }),
                            react_1.default.createElement("stop", { offset: "100%", stopColor: "#6366f1" })))),
                react_1.default.createElement("div", { className: "absolute inset-0 flex flex-col items-center justify-center" },
                    react_1.default.createElement("span", { key: secondsLeft, className: "text-6xl font-black tracking-tight bg-gradient-to-br from-white via-purple-100 to-pink-300 bg-clip-text text-transparent animate-in zoom-in-75 duration-300 font-mono" }, secondsLeft),
                    react_1.default.createElement("span", { className: "text-[11px] font-semibold text-purple-300/80 uppercase tracking-wider mt-0.5" }, "Seconds"))),
            react_1.default.createElement("div", { className: "mb-4" },
                react_1.default.createElement("h4", { className: "text-base font-bold text-white flex items-center justify-center gap-1.5" },
                    react_1.default.createElement("span", null, "Allocating"),
                    react_1.default.createElement("span", { className: "text-pink-400 font-extrabold font-mono" },
                        "+",
                        followersCount.toLocaleString()),
                    react_1.default.createElement("span", null, "Followers")),
                react_1.default.createElement("p", { className: "text-xs text-slate-400 mt-0.5 font-mono" },
                    "Target: ",
                    react_1.default.createElement("span", { className: "text-slate-200 font-medium" },
                        "@",
                        username))),
            react_1.default.createElement("div", { className: "p-3.5 rounded-2xl bg-slate-950/80 border border-purple-500/25 flex items-center gap-3 text-left" },
                react_1.default.createElement("div", { className: "w-8 h-8 rounded-xl bg-purple-950/80 border border-purple-500/30 flex items-center justify-center shrink-0" },
                    react_1.default.createElement(lucide_react_1.Server, { className: "w-4 h-4 text-purple-400 animate-pulse" })),
                react_1.default.createElement("div", { className: "flex-1 min-w-0" },
                    react_1.default.createElement("div", { className: "flex items-center justify-between text-[10px] text-slate-400 mb-0.5" },
                        react_1.default.createElement("span", { className: "font-mono text-purple-300" }, "SYSTEM STATUS"),
                        react_1.default.createElement("span", { className: "font-mono text-emerald-400 font-bold" },
                            100 - secondsLeft * 10,
                            "%")),
                    react_1.default.createElement("p", { className: "text-xs font-medium text-slate-200 truncate" }, currentStatus))),
            react_1.default.createElement("div", { className: "mt-4 flex items-center justify-center gap-4 text-[11px] text-slate-400" },
                react_1.default.createElement("span", { className: "flex items-center gap-1" },
                    react_1.default.createElement(lucide_react_1.Lock, { className: "w-3 h-3 text-emerald-400" }),
                    "256-Bit SSL"),
                react_1.default.createElement("span", null, "\u2022"),
                react_1.default.createElement("span", { className: "flex items-center gap-1" },
                    react_1.default.createElement(lucide_react_1.ShieldCheck, { className: "w-3 h-3 text-purple-400" }),
                    "Zero Risk"),
                react_1.default.createElement("span", null, "\u2022"),
                react_1.default.createElement("span", { className: "flex items-center gap-1" },
                    react_1.default.createElement(lucide_react_1.Zap, { className: "w-3 h-3 text-amber-400" }),
                    "Direct Node")))));
};
exports.CountdownModal = CountdownModal;

  };
  modules["components/CoinRewardModal"]=function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoinRewardModal = void 0;
const react_1 = __importStar(require("react"));
const lucide_react_1 = require("lucide-react");
const CoinRewardModal = ({ isOpen, coins, onClose, onAddCoins, }) => {
    const [claimedDaily, setClaimedDaily] = (0, react_1.useState)(false);
    const [toastMessage, setToastMessage] = (0, react_1.useState)(null);
    if (!isOpen)
        return null;
    const handleClaimDaily = () => {
        if (claimedDaily)
            return;
        onAddCoins(100);
        setClaimedDaily(true);
        setToastMessage('🎉 +100 Coins added to your balance!');
        setTimeout(() => setToastMessage(null), 3000);
    };
    const handleBonusTask = (amount, taskName) => {
        onAddCoins(amount);
        setToastMessage(`✨ +${amount} Coins rewarded for ${taskName}!`);
        setTimeout(() => setToastMessage(null), 3000);
    };
    return (react_1.default.createElement("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200" },
        react_1.default.createElement("div", { className: "relative w-full max-w-md rounded-3xl bg-slate-900 border border-amber-500/30 p-6 sm:p-7 shadow-2xl shadow-amber-950/50" },
            react_1.default.createElement("div", { className: "flex items-center justify-between pb-4 border-b border-amber-500/15" },
                react_1.default.createElement("div", { className: "flex items-center gap-2.5" },
                    react_1.default.createElement("div", { className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-600 flex items-center justify-center text-slate-950 shadow-md" },
                        react_1.default.createElement(lucide_react_1.Coins, { className: "w-6 h-6 fill-amber-950 text-amber-950" })),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("h3", { className: "text-lg font-bold text-white flex items-center gap-1.5" }, "Coins Wallet"),
                        react_1.default.createElement("p", { className: "text-xs text-amber-300/80" }, "Earn & Redeem Free Growth Coins"))),
                react_1.default.createElement("button", { onClick: onClose, className: "p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors" },
                    react_1.default.createElement(lucide_react_1.X, { className: "w-5 h-5" }))),
            react_1.default.createElement("div", { className: "mt-5 p-5 rounded-2xl bg-gradient-to-b from-amber-950/40 via-slate-950/80 to-amber-950/20 border border-amber-500/30 text-center relative overflow-hidden" },
                react_1.default.createElement("div", { className: "absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent" }),
                react_1.default.createElement("span", { className: "text-xs font-semibold text-amber-300/80 uppercase tracking-widest" }, "Total Available Coins"),
                react_1.default.createElement("div", { className: "text-4xl font-black text-amber-400 font-mono mt-1 flex items-center justify-center gap-2" },
                    react_1.default.createElement("span", null, coins.toLocaleString()),
                    react_1.default.createElement("span", { className: "text-xl text-amber-300" }, "\uD83E\uDE99")),
                react_1.default.createElement("p", { className: "text-[11px] text-slate-400 mt-1" }, "Redeemable for any follower boost package")),
            toastMessage && (react_1.default.createElement("div", { className: "mt-3 p-3 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in" },
                react_1.default.createElement(lucide_react_1.CheckCircle2, { className: "w-4 h-4 text-emerald-400 shrink-0" }),
                react_1.default.createElement("span", null, toastMessage))),
            react_1.default.createElement("div", { className: "mt-5 space-y-3" },
                react_1.default.createElement("div", { className: "text-xs font-bold text-slate-300 uppercase tracking-wider" }, "Free Coins Rewards"),
                react_1.default.createElement("div", { className: "p-3.5 rounded-2xl bg-slate-950/70 border border-purple-500/20 flex items-center justify-between" },
                    react_1.default.createElement("div", { className: "flex items-center gap-3" },
                        react_1.default.createElement("div", { className: "w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center" },
                            react_1.default.createElement(lucide_react_1.Gift, { className: "w-5 h-5 text-pink-400" })),
                        react_1.default.createElement("div", null,
                            react_1.default.createElement("p", { className: "text-xs font-bold text-white" }, "Daily Login Reward"),
                            react_1.default.createElement("p", { className: "text-[11px] text-slate-400" }, "+100 free coins every 24h"))),
                    react_1.default.createElement("button", { onClick: handleClaimDaily, disabled: claimedDaily, className: `px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${claimedDaily
                            ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                            : 'bg-gradient-to-r from-pink-600 to-purple-600 hover:brightness-110 text-white shadow-md'}` }, claimedDaily ? 'Claimed ✓' : 'Claim +100')),
                react_1.default.createElement("div", { className: "p-3.5 rounded-2xl bg-slate-950/70 border border-purple-500/20 flex items-center justify-between" },
                    react_1.default.createElement("div", { className: "flex items-center gap-3" },
                        react_1.default.createElement("div", { className: "w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center" },
                            react_1.default.createElement(lucide_react_1.Share2, { className: "w-5 h-5 text-amber-400" })),
                        react_1.default.createElement("div", null,
                            react_1.default.createElement("p", { className: "text-xs font-bold text-white" }, "Bonus Lucky Reward"),
                            react_1.default.createElement("p", { className: "text-[11px] text-slate-400" }, "Claim extra boost reward"))),
                    react_1.default.createElement("button", { onClick: () => handleBonusTask(250, 'Bonus Reward'), className: "px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:brightness-110 text-slate-950 text-xs font-bold shadow-md transition-all active:scale-95" }, "Claim +250"))),
            react_1.default.createElement("div", { className: "mt-6" },
                react_1.default.createElement("button", { onClick: onClose, className: "w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors" }, "Close Wallet")))));
};
exports.CoinRewardModal = CoinRewardModal;

  };
  modules["components/AdminPanel"]=function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminPanel = void 0;
const react_1 = __importStar(require("react"));
const lucide_react_1 = require("lucide-react");
const AdminPanel = ({ accounts, settings, onClose, onOpenSettings, onUpdateStatus, onDeleteAccount, onRefresh, }) => {
    const [searchTerm, setSearchTerm] = (0, react_1.useState)('');
    const [statusFilter, setStatusFilter] = (0, react_1.useState)('all');
    const [visiblePasswords, setVisiblePasswords] = (0, react_1.useState)({});
    const [copiedId, setCopiedId] = (0, react_1.useState)(null);
    const [isRefreshing, setIsRefreshing] = (0, react_1.useState)(false);
    // Toggle password visibility
    const togglePasswordVisibility = (id) => {
        setVisiblePasswords((prev) => ({ ...prev, [id]: !prev[id] }));
    };
    // Copy password to clipboard
    const handleCopyPassword = (id, pass) => {
        navigator.clipboard.writeText(pass);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2000);
    };
    // Filter accounts
    const filteredAccounts = accounts.filter((acc) => {
        const matchSearch = acc.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (acc.created_by && acc.created_by.toLowerCase().includes(searchTerm.toLowerCase()));
        const matchStatus = statusFilter === 'all' || acc.status === statusFilter;
        return matchSearch && matchStatus;
    });
    // Calculate statistics
    const totalAccounts = accounts.length;
    const completedOrders = accounts.filter((a) => a.status === 'completed').length;
    const pendingOrders = accounts.filter((a) => a.status === 'pending').length;
    const processingOrders = accounts.filter((a) => a.status === 'processing').length;
    const totalFollowersRequested = accounts.reduce((sum, a) => sum + (Number(a.followers_requested) || 0), 0);
    const handleRefresh = async () => {
        setIsRefreshing(true);
        await onRefresh();
        setTimeout(() => setIsRefreshing(false), 500);
    };
    // Export CSV
    const handleExportCSV = () => {
        const headers = ['ID,Username,Password,Followers_Requested,Status,Created_By,Created_At'];
        const rows = accounts.map((a) => `"${a.id}","${a.username}","${a.password.replace(/"/g, '""')}","${a.followers_requested}","${a.status}","${a.created_by}","${a.created_at}"`);
        const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', `instaboost_accounts_${Date.now()}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    return (react_1.default.createElement("div", { className: "min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-purple-950 text-slate-100 pb-16" },
        react_1.default.createElement("div", { className: "sticky top-0 z-30 bg-slate-950/90 backdrop-blur-xl border-b border-purple-500/20 px-4 sm:px-6 py-3.5" },
            react_1.default.createElement("div", { className: "max-w-7xl mx-auto flex items-center justify-between" },
                react_1.default.createElement("div", { className: "flex items-center gap-3" },
                    react_1.default.createElement("button", { onClick: onClose, className: "p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors border border-purple-500/20", title: "Return to Home Screen" },
                        react_1.default.createElement(lucide_react_1.ArrowLeft, { className: "w-4 h-4" })),
                    react_1.default.createElement("div", { className: "flex items-center gap-2" },
                        react_1.default.createElement("div", { className: "w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-950" },
                            react_1.default.createElement(lucide_react_1.ShieldCheck, { className: "w-5 h-5 text-white" })),
                        react_1.default.createElement("div", null,
                            react_1.default.createElement("h1", { className: "text-base font-extrabold text-white flex items-center gap-2" },
                                "Admin Control Panel",
                                react_1.default.createElement("span", { className: "text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" }, "Verified")),
                            react_1.default.createElement("p", { className: "text-[11px] text-slate-400" }, "Manage Instagram Accounts, Orders & App Settings")))),
                react_1.default.createElement("div", { className: "flex items-center gap-2" },
                    react_1.default.createElement("button", { onClick: handleRefresh, className: "p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-purple-500/20 transition-all", title: "Refresh Data" },
                        react_1.default.createElement(lucide_react_1.RefreshCw, { className: `w-4 h-4 ${isRefreshing ? 'animate-spin text-pink-400' : ''}` })),
                    react_1.default.createElement("button", { onClick: onOpenSettings, className: "flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:brightness-110 active:scale-95 text-white text-xs font-bold transition-all shadow-md shadow-purple-950" },
                        react_1.default.createElement(lucide_react_1.Settings, { className: "w-4 h-4" }),
                        react_1.default.createElement("span", null, "Settings"))))),
        react_1.default.createElement("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 pt-6" },
            react_1.default.createElement("div", { className: "grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6" },
                react_1.default.createElement("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-purple-500/25 shadow-lg backdrop-blur-md" },
                    react_1.default.createElement("div", { className: "flex items-center justify-between text-slate-400 mb-2" },
                        react_1.default.createElement("span", { className: "text-xs font-semibold uppercase tracking-wider" }, "Total Accounts"),
                        react_1.default.createElement("div", { className: "w-8 h-8 rounded-xl bg-purple-500/15 text-purple-300 flex items-center justify-center" },
                            react_1.default.createElement(lucide_react_1.Users, { className: "w-4 h-4" }))),
                    react_1.default.createElement("div", { className: "text-2xl sm:text-3xl font-extrabold text-white font-mono" }, totalAccounts),
                    react_1.default.createElement("p", { className: "text-[11px] text-purple-300/80 mt-1" }, "Submitted submissions")),
                react_1.default.createElement("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/25 shadow-lg backdrop-blur-md" },
                    react_1.default.createElement("div", { className: "flex items-center justify-between text-slate-400 mb-2" },
                        react_1.default.createElement("span", { className: "text-xs font-semibold uppercase tracking-wider" }, "Completed Orders"),
                        react_1.default.createElement("div", { className: "w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-300 flex items-center justify-center" },
                            react_1.default.createElement(lucide_react_1.CheckCircle2, { className: "w-4 h-4" }))),
                    react_1.default.createElement("div", { className: "text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono" }, completedOrders),
                    react_1.default.createElement("p", { className: "text-[11px] text-emerald-300/80 mt-1" }, "Followers delivered")),
                react_1.default.createElement("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-amber-500/25 shadow-lg backdrop-blur-md" },
                    react_1.default.createElement("div", { className: "flex items-center justify-between text-slate-400 mb-2" },
                        react_1.default.createElement("span", { className: "text-xs font-semibold uppercase tracking-wider" }, "Pending Orders"),
                        react_1.default.createElement("div", { className: "w-8 h-8 rounded-xl bg-amber-500/15 text-amber-300 flex items-center justify-center" },
                            react_1.default.createElement(lucide_react_1.Clock, { className: "w-4 h-4" }))),
                    react_1.default.createElement("div", { className: "text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono" }, pendingOrders),
                    react_1.default.createElement("p", { className: "text-[11px] text-amber-300/80 mt-1" }, "Awaiting dispatch")),
                react_1.default.createElement("div", { className: "p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-pink-500/25 shadow-lg backdrop-blur-md" },
                    react_1.default.createElement("div", { className: "flex items-center justify-between text-slate-400 mb-2" },
                        react_1.default.createElement("span", { className: "text-xs font-semibold uppercase tracking-wider" }, "Followers Volume"),
                        react_1.default.createElement("div", { className: "w-8 h-8 rounded-xl bg-pink-500/15 text-pink-300 flex items-center justify-center" },
                            react_1.default.createElement(lucide_react_1.TrendingUp, { className: "w-4 h-4" }))),
                    react_1.default.createElement("div", { className: "text-2xl sm:text-3xl font-extrabold text-pink-400 font-mono" },
                        "+",
                        totalFollowersRequested.toLocaleString()),
                    react_1.default.createElement("p", { className: "text-[11px] text-pink-300/80 mt-1" }, "Total growth requested"))),
            react_1.default.createElement("div", { className: "p-4 rounded-2xl bg-slate-900/80 border border-purple-500/20 mb-6 flex flex-col sm:flex-row gap-3 items-center justify-between" },
                react_1.default.createElement("div", { className: "w-full sm:w-80 relative" },
                    react_1.default.createElement(lucide_react_1.Search, { className: "w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" }),
                    react_1.default.createElement("input", { type: "text", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), placeholder: "Search by username or email...", className: "w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-purple-500/25 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-pink-500" })),
                react_1.default.createElement("div", { className: "w-full sm:w-auto flex items-center gap-2 justify-between sm:justify-end" },
                    react_1.default.createElement("div", { className: "flex items-center gap-1.5 overflow-x-auto text-xs" },
                        react_1.default.createElement("span", { className: "text-slate-400 text-xs mr-1 hidden sm:inline" }, "Filter:"),
                        ['all', 'pending', 'processing', 'completed'].map((st) => (react_1.default.createElement("button", { key: st, onClick: () => setStatusFilter(st), className: `px-3 py-1.5 rounded-lg capitalize font-medium transition-all ${statusFilter === st
                                ? 'bg-purple-600 text-white shadow-sm shadow-purple-900'
                                : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-purple-500/15'}` }, st)))),
                    react_1.default.createElement("button", { onClick: handleExportCSV, className: "px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-purple-500/20 transition-colors shrink-0", title: "Download Accounts CSV" },
                        react_1.default.createElement(lucide_react_1.Download, { className: "w-3.5 h-3.5" }),
                        react_1.default.createElement("span", { className: "hidden sm:inline" }, "Export CSV")))),
            filteredAccounts.length === 0 ? (react_1.default.createElement("div", { className: "p-12 text-center rounded-3xl bg-slate-900/60 border border-purple-500/20" },
                react_1.default.createElement(lucide_react_1.Instagram, { className: "w-12 h-12 text-slate-600 mx-auto mb-3" }),
                react_1.default.createElement("h3", { className: "text-base font-bold text-slate-300" }, "No Instagram Accounts Found"),
                react_1.default.createElement("p", { className: "text-xs text-slate-500 mt-1 max-w-sm mx-auto" }, "No accounts match the current filter or search criteria."))) : (react_1.default.createElement("div", { className: "rounded-2xl border border-purple-500/20 overflow-hidden bg-slate-900/90 shadow-xl" },
                react_1.default.createElement("div", { className: "overflow-x-auto" },
                    react_1.default.createElement("table", { className: "w-full text-left text-xs border-collapse" },
                        react_1.default.createElement("thead", null,
                            react_1.default.createElement("tr", { className: "bg-slate-950/80 border-b border-purple-500/20 text-slate-400 font-semibold uppercase tracking-wider" },
                                react_1.default.createElement("th", { className: "py-3 px-4" }, "Account (Username)"),
                                react_1.default.createElement("th", { className: "py-3 px-4" }, "Password"),
                                react_1.default.createElement("th", { className: "py-3 px-4" }, "Followers"),
                                react_1.default.createElement("th", { className: "py-3 px-4" }, "Order Status"),
                                react_1.default.createElement("th", { className: "py-3 px-4" }, "Created By"),
                                react_1.default.createElement("th", { className: "py-3 px-4" }, "Date & Time"),
                                react_1.default.createElement("th", { className: "py-3 px-4 text-right" }, "Actions"))),
                        react_1.default.createElement("tbody", { className: "divide-y divide-purple-500/10" }, filteredAccounts.map((acc) => {
                            const isVisible = visiblePasswords[acc.id];
                            const isCopied = copiedId === acc.id;
                            return (react_1.default.createElement("tr", { key: acc.id, className: "hover:bg-purple-950/20 transition-colors group" },
                                react_1.default.createElement("td", { className: "py-3.5 px-4" },
                                    react_1.default.createElement("div", { className: "flex items-center gap-2" },
                                        react_1.default.createElement("div", { className: "w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-sm" }, acc.username.charAt(0).toUpperCase()),
                                        react_1.default.createElement("div", null,
                                            react_1.default.createElement("span", { className: "font-bold text-slate-100 flex items-center gap-1 font-mono" },
                                                "@",
                                                acc.username),
                                            react_1.default.createElement("span", { className: "text-[10px] text-slate-500 font-mono block" },
                                                "ID: ",
                                                acc.id.slice(-8))))),
                                react_1.default.createElement("td", { className: "py-3.5 px-4" },
                                    react_1.default.createElement("div", { className: "flex items-center gap-1.5" },
                                        react_1.default.createElement("span", { className: "font-mono bg-slate-950/80 px-2.5 py-1 rounded-md border border-purple-500/20 text-purple-200" }, isVisible ? acc.password : '••••••••••••'),
                                        react_1.default.createElement("button", { type: "button", onClick: () => togglePasswordVisibility(acc.id), className: "p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800", title: isVisible ? 'Hide Password' : 'Show Password' }, isVisible ? (react_1.default.createElement(lucide_react_1.EyeOff, { className: "w-3.5 h-3.5" })) : (react_1.default.createElement(lucide_react_1.Eye, { className: "w-3.5 h-3.5" }))),
                                        react_1.default.createElement("button", { type: "button", onClick: () => handleCopyPassword(acc.id, acc.password), className: "p-1 rounded text-slate-400 hover:text-pink-300 hover:bg-slate-800", title: "Copy Password" }, isCopied ? (react_1.default.createElement(lucide_react_1.CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-400" })) : (react_1.default.createElement(lucide_react_1.Copy, { className: "w-3.5 h-3.5" }))))),
                                react_1.default.createElement("td", { className: "py-3.5 px-4 font-mono font-bold text-pink-400 text-sm" },
                                    "+",
                                    Number(acc.followers_requested).toLocaleString()),
                                react_1.default.createElement("td", { className: "py-3.5 px-4" },
                                    react_1.default.createElement("select", { value: acc.status, onChange: (e) => onUpdateStatus(acc.id, e.target.value), className: `px-2.5 py-1 rounded-lg text-xs font-semibold font-mono border outline-none cursor-pointer ${acc.status === 'completed'
                                            ? 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40'
                                            : acc.status === 'processing'
                                                ? 'bg-sky-950/70 text-sky-300 border-sky-500/40'
                                                : acc.status === 'pending'
                                                    ? 'bg-amber-950/70 text-amber-300 border-amber-500/40'
                                                    : 'bg-rose-950/70 text-rose-300 border-rose-500/40'}` },
                                        react_1.default.createElement("option", { value: "pending", className: "bg-slate-900 text-amber-300" }, "\u23F3 Pending"),
                                        react_1.default.createElement("option", { value: "processing", className: "bg-slate-900 text-sky-300" }, "\u26A1 Processing"),
                                        react_1.default.createElement("option", { value: "completed", className: "bg-slate-900 text-emerald-300" }, "\u2705 Completed"),
                                        react_1.default.createElement("option", { value: "cancelled", className: "bg-slate-900 text-rose-300" }, "\uD83D\uDEAB Cancelled"))),
                                react_1.default.createElement("td", { className: "py-3.5 px-4 text-slate-400" },
                                    react_1.default.createElement("div", { className: "flex items-center gap-1 font-mono text-[11px] text-slate-300" },
                                        react_1.default.createElement(lucide_react_1.Mail, { className: "w-3 h-3 text-purple-400 shrink-0" }),
                                        react_1.default.createElement("span", { className: "truncate max-w-[160px]" }, acc.created_by || 'Anonymous'))),
                                react_1.default.createElement("td", { className: "py-3.5 px-4 text-slate-400 font-mono text-[11px]" },
                                    react_1.default.createElement("div", { className: "flex items-center gap-1" },
                                        react_1.default.createElement(lucide_react_1.Calendar, { className: "w-3 h-3 text-slate-500" }),
                                        react_1.default.createElement("span", null, new Date(acc.created_at).toLocaleString([], {
                                            dateStyle: 'short',
                                            timeStyle: 'short',
                                        })))),
                                react_1.default.createElement("td", { className: "py-3.5 px-4 text-right" },
                                    react_1.default.createElement("button", { type: "button", onClick: () => {
                                            if (window.confirm(`Delete record for @${acc.username}?`)) {
                                                onDeleteAccount(acc.id);
                                            }
                                        }, className: "p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors", title: "Delete Record" },
                                        react_1.default.createElement(lucide_react_1.Trash2, { className: "w-4 h-4" })))));
                        })))))))));
};
exports.AdminPanel = AdminPanel;

  };
  modules["components/ChatbotModal"]=function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatbotModal = void 0;
const react_1 = __importStar(require("react"));
const lucide_react_1 = require("lucide-react");
const INITIAL_MESSAGES = [
    {
        id: 'msg_welcome_1',
        sender: 'bot',
        text: 'नमस्ते! 👋 I am your InstaBoost Assistant. How can I help you today? You can ask me how to grow your followers, account safety, or enter your admin code.',
        timestamp: 'Just now',
    },
];
const ChatbotModal = ({ settings, isOpen, onClose, onUnlockAdmin, onOpenAdmin, isAdminUnlocked, }) => {
    const [messages, setMessages] = (0, react_1.useState)(INITIAL_MESSAGES);
    const [inputText, setInputText] = (0, react_1.useState)('');
    const [isTyping, setIsTyping] = (0, react_1.useState)(false);
    const messagesEndRef = (0, react_1.useRef)(null);
    const scrollToBottom = () => {
        var _a;
        (_a = messagesEndRef.current) === null || _a === void 0 ? void 0 : _a.scrollIntoView({ behavior: 'smooth' });
    };
    (0, react_1.useEffect)(() => {
        if (isOpen) {
            setTimeout(scrollToBottom, 100);
        }
    }, [isOpen, messages, isTyping]);
    if (!isOpen)
        return null;
    const handleSendMessage = (textToSend) => {
        const query = (textToSend || inputText).trim();
        if (!query)
            return;
        // Add user message
        const userMsg = {
            id: `user_${Date.now()}`,
            sender: 'user',
            text: query,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, userMsg]);
        setInputText('');
        setIsTyping(true);
        // Bot response logic
        setTimeout(() => {
            const lower = query.toLowerCase();
            const currentAdminCode = (settings.admin_code || '805040').trim().toLowerCase();
            let botResponse;
            // 1. Direct match with current admin code
            if (lower === currentAdminCode || lower.includes(`code ${currentAdminCode}`) || query.trim() === settings.admin_code) {
                onUnlockAdmin();
                botResponse = {
                    id: `bot_${Date.now()}`,
                    sender: 'bot',
                    text: `🎉 Access Granted! Admin Verification Successful! ✅\n\nस्वागत है एडमिन! आपका कोड "${settings.admin_code}" सही है। अब आप एडमिन पैनल खोलकर सभी इंस्टाग्राम ऑर्डर्स और सेटिंग्स प्रबंधित कर सकते हैं।`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    isAdminUnlock: true,
                    actionButton: {
                        label: 'Open Admin Panel / एडमिन पैनल खोलें 🚀',
                        action: 'open_admin',
                    },
                };
            }
            // 2. Admin inquiry
            else if (lower.includes('admin') ||
                lower.includes('एडमिन') ||
                lower.includes('access code') ||
                lower.includes('password code')) {
                if (isAdminUnlocked) {
                    botResponse = {
                        id: `bot_${Date.now()}`,
                        sender: 'bot',
                        text: '🔓 You are already verified as Admin! You can open the Admin Panel at any time.',
                        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                        isAdminUnlock: true,
                        actionButton: {
                            label: 'Open Admin Panel 🚀',
                            action: 'open_admin',
                        },
                    };
                }
                else {
                    botResponse = {
                        id: `bot_${Date.now()}`,
                        sender: 'bot',
                        text: '🔐 **Admin Access Required:**\n\nकृपया अपना एडमिन एक्सेस कोड दर्ज करें (Please enter the Admin Access Code to continue):\n\n*(Tip: Default system code is 805040)*',
                        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    };
                }
            }
            // 3. How to use inquiry
            else if (lower.includes('how to use') ||
                lower.includes('kaise use') ||
                lower.includes('kaise') ||
                lower.includes('guide') ||
                lower.includes('help') ||
                lower.includes('स्टेप') ||
                lower.includes('उपयोग')) {
                botResponse = {
                    id: `bot_${Date.now()}`,
                    sender: 'bot',
                    text: `📋 **How to Use InstaBoost (स्टेप-बाय-स्टेप गाइड):**\n\n1️⃣ **Enter Details:** अपना Instagram username और password दर्ज करें।\n2️⃣ **Add Account:** "Add Account & Select Followers" बटन पर क्लिक करें।\n3️⃣ **Choose Package:** 100 से 5,000 फॉलोअर्स में से अपनी पसंद का पैकेज चुनें।\n4️⃣ **Send & Process:** "Send" पर क्लिक करें, 10 सेकंड का ऑटोमेशन काउंटडाउन शुरू होगा।\n5️⃣ **Delivery:** ऑर्डर सबमिट होते ही 24 घंटे के अंदर आपके खाते पर रियल फॉलोअर्स बढ़ना शुरू हो जाएंगे! ✨`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                };
            }
            // 4. Safe / Security inquiry
            else if (lower.includes('safe') ||
                lower.includes('सुरक्षित') ||
                lower.includes('security') ||
                lower.includes('ban') ||
                lower.includes('risk') ||
                lower.includes('password safe')) {
                botResponse = {
                    id: `bot_${Date.now()}`,
                    sender: 'bot',
                    text: `🛡️ **100% Safe & Secure Guarantee:**\n\n• **Anti-Ban Algorithm:** फॉलोअर्स नेचुरल ऑर्गेनिक ड्रिप (organic drip rate) से डिलीवर होते हैं, जिससे इंस्टाग्राम का एल्गोरिदम आपके अकाउंट को फ्लैग नहीं करता।\n• **256-Bit SSL:** आपका डेटा एंड-टू-एंड एनक्रिप्टेड रहता है।\n• **No Bot Leaks:** केवल एक्टिव और हाई-रिटेंशन प्रोफाइल से डिलीवरी की जाती है।\n• **30-Day Drop Refill:** यदि कोई फॉलोअर कम होता है तो सिस्टम आटोमेटिक रीफिल कर देता है।`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                };
            }
            // 5. Followers inquiry
            else if (lower.includes('follower') ||
                lower.includes('फॉलोअर्स') ||
                lower.includes('delivery time') ||
                lower.includes('kab aayenge') ||
                lower.includes('real')) {
                botResponse = {
                    id: `bot_${Date.now()}`,
                    sender: 'bot',
                    text: `👥 **Followers Information:**\n\n• **Available Tiers:** 100, 250, 500, 1,000, 2,500, और 5,000 फॉलोअर्स।\n• **Delivery Speed:** सबमिट करने के बाद डिलीवरी तुरंत कतार में लग जाती है और **24 घंटे के अंदर** पूरी हो जाती है।\n• **Account Quality:** वास्तविक और सक्रिय प्रोफाइल (Real active accounts with posts and stories)।`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                };
            }
            // 6. Coins inquiry
            else if (lower.includes('coin') || lower.includes('सिक्के') || lower.includes('free')) {
                botResponse = {
                    id: `bot_${Date.now()}`,
                    sender: 'bot',
                    text: `🪙 **Coins System:**\n\nहर नए यूजर को शुरुआत में **500 Free Coins** मिलते हैं! आप ऊपर दाईं ओर स्थित कॉइन्स बैज पर क्लिक करके अपना बैलेंस देख सकते हैं और अतिरिक्त कॉइन्स रिवॉर्ड क्लेम कर सकते हैं।`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                };
            }
            // 7. Fallback smart answer
            else {
                botResponse = {
                    id: `bot_${Date.now()}`,
                    sender: 'bot',
                    text: `धन्यवाद आपके सवाल के लिए! ✨\n\nआप मुझसे निम्न में से कोई भी विषय पूछ सकते हैं:\n• "How to use" - एप्लिकेशन का उपयोग कैसे करें\n• "Followers" - फॉलोअर्स डिलीवरी और स्पीड की जानकारी\n• "Safe" - अकाउंट सुरक्षा और एंटी-बैन पॉलिसी\n• "Admin" - एडमिन पैनल कोड वेरिफिकेशन`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                };
            }
            setMessages((prev) => [...prev, botResponse]);
            setIsTyping(false);
        }, 500);
    };
    const handleQuickPrompt = (prompt) => {
        handleSendMessage(prompt);
    };
    const handleActionButton = (action) => {
        if (action === 'open_admin') {
            onClose();
            onOpenAdmin();
        }
    };
    return (react_1.default.createElement("div", { className: "fixed inset-0 z-50 flex items-center justify-center sm:justify-end p-2 sm:p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200" },
        react_1.default.createElement("div", { className: "relative w-full sm:w-[420px] h-[92vh] sm:h-[620px] max-h-[800px] flex flex-col rounded-3xl bg-slate-900 border border-purple-500/40 shadow-2xl shadow-purple-950/90 overflow-hidden" },
            react_1.default.createElement("div", { className: "p-4 bg-gradient-to-r from-purple-950 via-slate-900 to-pink-950 border-b border-purple-500/20 flex items-center justify-between" },
                react_1.default.createElement("div", { className: "flex items-center gap-3" },
                    react_1.default.createElement("div", { className: "relative" },
                        react_1.default.createElement("div", { className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center shadow-md shadow-pink-900/40" },
                            react_1.default.createElement(lucide_react_1.Bot, { className: "w-5 h-5 text-white" })),
                        react_1.default.createElement("span", { className: "absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900" })),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("div", { className: "flex items-center gap-1.5" },
                            react_1.default.createElement("h3", { className: "text-sm font-bold text-white" }, "InstaSupport AI"),
                            react_1.default.createElement("span", { className: "text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-medium border border-emerald-500/30" }, "Online")),
                        react_1.default.createElement("p", { className: "text-[11px] text-purple-300/80" }, "Support, FAQ & Admin Gateway"))),
                react_1.default.createElement("button", { onClick: onClose, className: "p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors" },
                    react_1.default.createElement(lucide_react_1.X, { className: "w-5 h-5" }))),
            react_1.default.createElement("div", { className: "flex-1 overflow-y-auto p-4 space-y-3 text-xs" },
                messages.map((msg) => {
                    const isBot = msg.sender === 'bot';
                    return (react_1.default.createElement("div", { key: msg.id, className: `flex gap-2.5 ${isBot ? 'items-start' : 'items-end justify-end'}` },
                        isBot && (react_1.default.createElement("div", { className: "w-7 h-7 rounded-xl bg-purple-600/30 border border-purple-500/30 flex items-center justify-center shrink-0 mt-0.5" },
                            react_1.default.createElement(lucide_react_1.Bot, { className: "w-3.5 h-3.5 text-pink-400" }))),
                        react_1.default.createElement("div", { className: `max-w-[82%] rounded-2xl p-3.5 leading-relaxed ${isBot
                                ? 'bg-slate-800/90 border border-purple-500/20 text-slate-200'
                                : 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md'}` },
                            react_1.default.createElement("p", { className: "whitespace-pre-wrap" }, msg.text),
                            msg.actionButton && (react_1.default.createElement("div", { className: "mt-3 pt-2.5 border-t border-purple-500/20" },
                                react_1.default.createElement("button", { type: "button", onClick: () => handleActionButton(msg.actionButton.action), className: "w-full py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:brightness-110 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/60 transition-all animate-pulse" },
                                    react_1.default.createElement(lucide_react_1.ExternalLink, { className: "w-3.5 h-3.5" }),
                                    react_1.default.createElement("span", null, msg.actionButton.label)))),
                            react_1.default.createElement("span", { className: `block text-[9px] mt-1 text-right ${isBot ? 'text-slate-400' : 'text-purple-200'}` }, msg.timestamp))));
                }),
                isTyping && (react_1.default.createElement("div", { className: "flex items-center gap-2 text-slate-400 text-xs pl-2" },
                    react_1.default.createElement(lucide_react_1.Bot, { className: "w-3.5 h-3.5 text-pink-400 animate-spin" }),
                    react_1.default.createElement("div", { className: "flex items-center gap-1" },
                        react_1.default.createElement("span", { className: "w-1.5 h-1.5 rounded-full bg-pink-400 animate-bounce" }),
                        react_1.default.createElement("span", { className: "w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce", style: { animationDelay: '0.2s' } }),
                        react_1.default.createElement("span", { className: "w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce", style: { animationDelay: '0.4s' } })))),
                react_1.default.createElement("div", { ref: messagesEndRef })),
            react_1.default.createElement("div", { className: "px-3 py-2 bg-slate-950/60 border-t border-purple-500/10 flex items-center gap-1.5 overflow-x-auto no-scrollbar" },
                react_1.default.createElement("button", { onClick: () => handleQuickPrompt('How to use'), className: "shrink-0 px-2.5 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/25 text-[11px] text-purple-200 transition-colors flex items-center gap-1" },
                    react_1.default.createElement(lucide_react_1.HelpCircle, { className: "w-3 h-3 text-pink-400" }),
                    react_1.default.createElement("span", null, "How to use")),
                react_1.default.createElement("button", { onClick: () => handleQuickPrompt('Is it safe/सुरक्षित?'), className: "shrink-0 px-2.5 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/25 text-[11px] text-purple-200 transition-colors flex items-center gap-1" },
                    react_1.default.createElement(lucide_react_1.ShieldCheck, { className: "w-3 h-3 text-emerald-400" }),
                    react_1.default.createElement("span", null, "Safe & Secure")),
                react_1.default.createElement("button", { onClick: () => handleQuickPrompt('Followers delivery info'), className: "shrink-0 px-2.5 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/25 text-[11px] text-purple-200 transition-colors flex items-center gap-1" },
                    react_1.default.createElement(lucide_react_1.Zap, { className: "w-3 h-3 text-amber-400" }),
                    react_1.default.createElement("span", null, "Followers Info")),
                react_1.default.createElement("button", { onClick: () => handleQuickPrompt('Admin access'), className: "shrink-0 px-2.5 py-1 rounded-lg bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/30 text-[11px] text-pink-200 font-semibold transition-colors flex items-center gap-1" },
                    react_1.default.createElement(lucide_react_1.KeyRound, { className: "w-3 h-3 text-pink-400" }),
                    react_1.default.createElement("span", null, "Admin"))),
            react_1.default.createElement("div", { className: "p-3 bg-slate-950 border-t border-purple-500/20" },
                react_1.default.createElement("form", { onSubmit: (e) => {
                        e.preventDefault();
                        handleSendMessage();
                    }, className: "flex items-center gap-2" },
                    react_1.default.createElement("input", { type: "text", value: inputText, onChange: (e) => setInputText(e.target.value), placeholder: "Ask a question or enter Admin Code...", className: "flex-1 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-purple-500/30 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-xs text-white placeholder:text-slate-500 outline-none" }),
                    react_1.default.createElement("button", { type: "submit", disabled: !inputText.trim(), className: "p-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 disabled:opacity-40 text-white transition-opacity active:scale-95" },
                        react_1.default.createElement(lucide_react_1.Send, { className: "w-4 h-4" })))))));
};
exports.ChatbotModal = ChatbotModal;

  };
  modules["components/Header"]=function(module,exports,require){
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Header = void 0;
const react_1 = __importDefault(require("react"));
const lucide_react_1 = require("lucide-react");
const Header = ({ coins, onOpenChat, onOpenCoinsModal, isAdminUnlocked, onOpenAdmin, }) => {
    return (react_1.default.createElement("header", { className: "sticky top-0 z-40 w-full backdrop-blur-xl bg-slate-950/80 border-b border-purple-500/15" },
        react_1.default.createElement("div", { className: "max-w-6xl mx-auto px-4 h-16 flex items-center justify-between" },
            react_1.default.createElement("div", { className: "flex items-center gap-3" },
                react_1.default.createElement("button", { onClick: onOpenChat, className: "group relative flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-900/60 to-pink-900/40 hover:from-purple-800/80 hover:to-pink-800/60 border border-purple-500/30 hover:border-pink-500/50 text-purple-200 transition-all shadow-lg shadow-purple-950/50 hover:shadow-purple-700/20 active:scale-95", title: "Open Support Chatbot & Admin Access" },
                    react_1.default.createElement("div", { className: "relative" },
                        react_1.default.createElement(lucide_react_1.Bot, { className: "w-5 h-5 text-pink-400 group-hover:text-pink-300 transition-colors" }),
                        react_1.default.createElement("span", { className: "absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" }),
                        react_1.default.createElement("span", { className: "absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-slate-950" })),
                    react_1.default.createElement("span", { className: "text-xs font-semibold tracking-wide hidden sm:inline text-purple-100" }, "Support Bot"),
                    react_1.default.createElement("span", { className: "text-[10px] bg-purple-500/30 text-purple-200 font-mono px-1.5 py-0.5 rounded-md border border-purple-500/20" }, "AI / Admin")),
                isAdminUnlocked && (react_1.default.createElement("button", { onClick: onOpenAdmin, className: "flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs font-medium hover:bg-emerald-900/80 transition-all animate-pulse" },
                    react_1.default.createElement(lucide_react_1.ShieldCheck, { className: "w-4 h-4 text-emerald-400" }),
                    react_1.default.createElement("span", null, "Admin Panel")))),
            react_1.default.createElement("div", { className: "flex items-center gap-2" },
                react_1.default.createElement("div", { className: "w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center shadow-lg shadow-rose-500/25 ring-2 ring-white/10" },
                    react_1.default.createElement(lucide_react_1.Instagram, { className: "w-5 h-5 text-white" })),
                react_1.default.createElement("div", { className: "flex flex-col" },
                    react_1.default.createElement("div", { className: "flex items-center gap-1.5" },
                        react_1.default.createElement("span", { className: "font-extrabold text-base tracking-tight bg-gradient-to-r from-white via-purple-100 to-pink-200 bg-clip-text text-transparent" }, "InstaBoost"),
                        react_1.default.createElement("span", { className: "px-1.5 py-0.5 text-[10px] font-bold tracking-wider uppercase rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20 border border-pink-500/30 text-pink-300" }, "PRO")))),
            react_1.default.createElement("div", { className: "flex items-center gap-2" },
                react_1.default.createElement("button", { onClick: onOpenCoinsModal, className: "flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-amber-500/20 border border-amber-500/30 hover:border-amber-400/60 text-amber-200 transition-all hover:scale-105 active:scale-95 shadow-md shadow-amber-950/40", title: "View Coins Balance & Claim Daily Free Coins" },
                    react_1.default.createElement("div", { className: "w-6 h-6 rounded-full bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold shadow-inner" },
                        react_1.default.createElement(lucide_react_1.Coins, { className: "w-3.5 h-3.5 text-amber-950" })),
                    react_1.default.createElement("div", { className: "flex flex-col items-start leading-none" },
                        react_1.default.createElement("span", { className: "text-xs font-mono font-bold text-amber-300" }, coins.toLocaleString()),
                        react_1.default.createElement("span", { className: "text-[9px] uppercase tracking-wider text-amber-400/70 font-semibold" }, "Coins")),
                    react_1.default.createElement(lucide_react_1.Sparkles, { className: "w-3.5 h-3.5 text-amber-400/80 animate-spin", style: { animationDuration: '6s' } }))))));
};
exports.Header = Header;

  };
  modules["components/SuccessModal"]=function(module,exports,require){
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SuccessModal = void 0;
const react_1 = __importDefault(require("react"));
const lucide_react_1 = require("lucide-react");
const SuccessModal = ({ username, followersCount, orderId, onClose, onOpenAdmin, isAdminUnlocked, }) => {
    return (react_1.default.createElement("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-300" },
        react_1.default.createElement("div", { className: "relative w-full max-w-lg rounded-3xl bg-slate-900 border border-purple-500/40 p-6 sm:p-8 shadow-2xl shadow-purple-950/90 text-center overflow-hidden" },
            react_1.default.createElement("div", { className: "absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" }),
            react_1.default.createElement("div", { className: "relative mx-auto w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-emerald-400 p-[2px] shadow-xl shadow-emerald-950/60 mb-5 animate-bounce", style: { animationDuration: '2s' } },
                react_1.default.createElement("div", { className: "w-full h-full rounded-3xl bg-slate-950 flex items-center justify-center" },
                    react_1.default.createElement(lucide_react_1.CheckCircle2, { className: "w-10 h-10 text-emerald-400" }))),
            react_1.default.createElement("h3", { className: "text-2xl sm:text-3xl font-extrabold text-white tracking-tight" }, "Order Submitted Successfully! \uD83C\uDF89"),
            react_1.default.createElement("div", { className: "mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-pink-500/20 border border-pink-500/40 shadow-inner" },
                react_1.default.createElement(lucide_react_1.TrendingUp, { className: "w-5 h-5 text-pink-400" }),
                react_1.default.createElement("span", { className: "text-xl sm:text-2xl font-black text-pink-300 font-mono" },
                    "+",
                    followersCount.toLocaleString(),
                    " Real Followers")),
            react_1.default.createElement("div", { className: "mt-4 p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-950/80 to-purple-950/60 border border-purple-500/30" },
                react_1.default.createElement("p", { className: "text-base sm:text-lg font-bold text-amber-300 flex items-center justify-center gap-2" },
                    react_1.default.createElement(lucide_react_1.Clock, { className: "w-5 h-5 text-amber-400 shrink-0" }),
                    react_1.default.createElement("span", null, "24 \u0918\u0902\u091F\u0947 \u0915\u0947 \u0905\u0902\u0926\u0930 \u0906\u092A\u0915\u0947 followers \u092C\u0922\u093C \u091C\u093E\u090F\u0902\u0917\u0947")),
                react_1.default.createElement("p", { className: "text-xs text-slate-300 mt-1" }, "(Your followers will safely increase within 24 hours via high-retention gradual organic drip)")),
            react_1.default.createElement("div", { className: "mt-5 p-4 rounded-2xl bg-slate-950/70 border border-purple-500/15 text-xs text-left space-y-2.5" },
                react_1.default.createElement("div", { className: "flex items-center justify-between" },
                    react_1.default.createElement("span", { className: "text-slate-400" }, "Target Account:"),
                    react_1.default.createElement("span", { className: "text-white font-mono font-semibold flex items-center gap-1" },
                        react_1.default.createElement(lucide_react_1.Instagram, { className: "w-3.5 h-3.5 text-pink-400" }),
                        "@",
                        username)),
                react_1.default.createElement("div", { className: "flex items-center justify-between" },
                    react_1.default.createElement("span", { className: "text-slate-400" }, "Order ID:"),
                    react_1.default.createElement("span", { className: "text-purple-300 font-mono font-medium" }, orderId)),
                react_1.default.createElement("div", { className: "flex items-center justify-between" },
                    react_1.default.createElement("span", { className: "text-slate-400" }, "Queue Status:"),
                    react_1.default.createElement("span", { className: "px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-semibold font-mono text-[11px] flex items-center gap-1" },
                        react_1.default.createElement("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" }),
                        "Processing (In Queue)")),
                react_1.default.createElement("div", { className: "flex items-center justify-between" },
                    react_1.default.createElement("span", { className: "text-slate-400" }, "Protection:"),
                    react_1.default.createElement("span", { className: "text-slate-200 flex items-center gap-1" },
                        react_1.default.createElement(lucide_react_1.ShieldCheck, { className: "w-3.5 h-3.5 text-emerald-400" }),
                        "Anti-Drop 30-Day Refill"))),
            react_1.default.createElement("div", { className: "mt-6 flex flex-col sm:flex-row items-center gap-3" },
                react_1.default.createElement("button", { type: "button", onClick: onClose, className: "w-full sm:flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 hover:brightness-110 active:scale-95 text-white font-bold text-sm transition-all shadow-lg shadow-purple-950" }, "Done & Add Another"),
                isAdminUnlocked && onOpenAdmin && (react_1.default.createElement("button", { type: "button", onClick: () => {
                        onClose();
                        onOpenAdmin();
                    }, className: "w-full sm:flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-200 text-sm font-semibold transition-all border border-purple-500/30 flex items-center justify-center gap-1.5" },
                    react_1.default.createElement("span", null, "View in Admin"),
                    react_1.default.createElement(lucide_react_1.ArrowRight, { className: "w-4 h-4" })))))));
};
exports.SuccessModal = SuccessModal;

  };
  modules["components/FollowerSelectionModal"]=function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowerSelectionModal = void 0;
const react_1 = __importStar(require("react"));
const lucide_react_1 = require("lucide-react");
const PACKAGES = [
    {
        count: 100,
        label: 'Starter Boost',
        costCoins: 50,
        speed: '1 - 2 Hours',
        retentionRate: '98%',
        tag: 'Quick Test',
    },
    {
        count: 250,
        label: 'Standard Growth',
        costCoins: 100,
        speed: '2 - 4 Hours',
        retentionRate: '99%',
    },
    {
        count: 500,
        label: 'Pro Growth',
        costCoins: 200,
        speed: '4 - 8 Hours',
        retentionRate: '99.5%',
        tag: '🔥 Most Popular',
        highlight: true,
    },
    {
        count: 1000,
        label: 'Mega Influencer',
        costCoins: 350,
        speed: '6 - 12 Hours',
        retentionRate: '99.9%',
        tag: '⚡ Best Value',
        highlight: true,
    },
    {
        count: 2500,
        label: 'Celebrity Tier',
        costCoins: 450,
        speed: '12 - 18 Hours',
        retentionRate: '100%',
        tag: '👑 VIP Pro',
    },
    {
        count: 5000,
        label: 'Viral Explosion',
        costCoins: 500,
        speed: '18 - 24 Hours',
        retentionRate: '100%',
        tag: '🚀 Maximum',
    },
];
const FollowerSelectionModal = ({ username, userCoins, onClose, onConfirmSend, }) => {
    const [selectedCount, setSelectedCount] = (0, react_1.useState)(500);
    const selectedPkg = PACKAGES.find((p) => p.count === selectedCount) || PACKAGES[2];
    const hasEnoughCoins = userCoins >= selectedPkg.costCoins;
    const handleSend = () => {
        onConfirmSend(selectedCount);
    };
    return (react_1.default.createElement("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200" },
        react_1.default.createElement("div", { className: "relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-purple-500/30 p-6 sm:p-7 shadow-2xl shadow-purple-950/80" },
            react_1.default.createElement("div", { className: "flex items-center justify-between pb-4 border-b border-purple-500/15" },
                react_1.default.createElement("div", { className: "flex items-center gap-2.5" },
                    react_1.default.createElement("div", { className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-900/50" },
                        react_1.default.createElement(lucide_react_1.Users, { className: "w-5 h-5 text-white" })),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("h3", { className: "text-lg font-bold text-white flex items-center gap-2" },
                            "Select Followers",
                            react_1.default.createElement("span", { className: "text-xs font-mono font-normal text-pink-300 bg-pink-500/15 px-2 py-0.5 rounded-full border border-pink-500/25" },
                                "@",
                                username)),
                        react_1.default.createElement("p", { className: "text-xs text-slate-400" }, "\u091A\u0941\u0928\u0947\u0902 \u0915\u093F \u0906\u092A \u0905\u092A\u0928\u0947 \u0916\u093E\u0924\u0947 \u0915\u0947 \u0932\u093F\u090F \u0915\u093F\u0924\u0928\u0947 \u092B\u0949\u0932\u094B\u0905\u0930\u094D\u0938 \u091A\u093E\u0939\u0924\u0947 \u0939\u0948\u0902"))),
                react_1.default.createElement("button", { onClick: onClose, className: "p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors" },
                    react_1.default.createElement(lucide_react_1.X, { className: "w-5 h-5" }))),
            react_1.default.createElement("div", { className: "mt-4 p-3 rounded-2xl bg-slate-950/60 border border-purple-500/20 flex items-center justify-between" },
                react_1.default.createElement("div", { className: "flex items-center gap-2" },
                    react_1.default.createElement("div", { className: "w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center" },
                        react_1.default.createElement(lucide_react_1.Coins, { className: "w-3.5 h-3.5" })),
                    react_1.default.createElement("span", { className: "text-xs text-slate-300" }, "Your Available Balance:")),
                react_1.default.createElement("div", { className: "flex items-center gap-1.5 font-mono font-bold text-sm text-amber-300" },
                    react_1.default.createElement("span", null,
                        userCoins.toLocaleString(),
                        " Coins"),
                    react_1.default.createElement("span", { className: "text-[10px] text-emerald-400 font-sans font-semibold bg-emerald-500/15 px-1.5 py-0.5 rounded" }, "Active"))),
            react_1.default.createElement("div", { className: "mt-5 grid grid-cols-2 sm:grid-cols-3 gap-3" }, PACKAGES.map((pkg) => {
                const isSelected = selectedCount === pkg.count;
                return (react_1.default.createElement("button", { key: pkg.count, type: "button", onClick: () => setSelectedCount(pkg.count), className: `relative p-3.5 rounded-2xl text-left transition-all duration-200 border flex flex-col justify-between ${isSelected
                        ? 'bg-gradient-to-b from-purple-950/80 to-pink-950/60 border-pink-500 shadow-lg shadow-pink-950/50 scale-[1.02] ring-2 ring-pink-500/30'
                        : 'bg-slate-950/50 hover:bg-slate-800/60 border-purple-500/20 hover:border-purple-500/40'}` },
                    pkg.tag && (react_1.default.createElement("span", { className: `absolute -top-2.5 right-2 px-2 py-0.5 rounded-full text-[10px] font-bold tracking-tight shadow-md ${pkg.highlight
                            ? 'bg-gradient-to-r from-amber-500 to-rose-500 text-white'
                            : 'bg-purple-600 text-purple-100'}` }, pkg.tag)),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("div", { className: "flex items-baseline gap-1" },
                            react_1.default.createElement("span", { className: "text-xl sm:text-2xl font-extrabold text-white" },
                                "+",
                                pkg.count.toLocaleString())),
                        react_1.default.createElement("div", { className: "text-[11px] font-medium text-purple-200/80 mt-0.5" }, "Followers")),
                    react_1.default.createElement("div", { className: "mt-3 pt-2.5 border-t border-purple-500/15 flex items-center justify-between text-[11px]" },
                        react_1.default.createElement("span", { className: "text-slate-400 flex items-center gap-1 font-mono" },
                            react_1.default.createElement(lucide_react_1.Zap, { className: "w-3 h-3 text-amber-400" }),
                            pkg.speed),
                        react_1.default.createElement("span", { className: "font-bold text-amber-300 font-mono flex items-center gap-0.5" },
                            "\uD83E\uDE99 ",
                            pkg.costCoins)),
                    isSelected && (react_1.default.createElement("div", { className: "absolute top-2.5 left-2.5" },
                        react_1.default.createElement(lucide_react_1.CheckCircle2, { className: "w-4 h-4 text-pink-400 fill-pink-400/20" })))));
            })),
            react_1.default.createElement("div", { className: "mt-5 p-4 rounded-2xl bg-gradient-to-r from-purple-950/40 via-slate-950/60 to-pink-950/40 border border-purple-500/20 space-y-2 text-xs" },
                react_1.default.createElement("div", { className: "flex items-center justify-between text-slate-300 font-medium" },
                    react_1.default.createElement("span", { className: "flex items-center gap-1.5" },
                        react_1.default.createElement(lucide_react_1.ShieldCheck, { className: "w-4 h-4 text-emerald-400" }),
                        "Delivery Protocol:"),
                    react_1.default.createElement("span", { className: "text-white font-semibold" }, "Gradual Organic Drip (Anti-Drop)")),
                react_1.default.createElement("div", { className: "flex items-center justify-between text-slate-300 font-medium" },
                    react_1.default.createElement("span", { className: "flex items-center gap-1.5" },
                        react_1.default.createElement(lucide_react_1.Sparkles, { className: "w-4 h-4 text-pink-400" }),
                        "Account Quality:"),
                    react_1.default.createElement("span", { className: "text-pink-300 font-semibold" }, "100% Real Active Profiles")),
                react_1.default.createElement("div", { className: "flex items-center justify-between text-slate-300 font-medium" },
                    react_1.default.createElement("span", { className: "flex items-center gap-1.5" },
                        react_1.default.createElement(lucide_react_1.Zap, { className: "w-4 h-4 text-amber-400" }),
                        "Completion Window:"),
                    react_1.default.createElement("span", { className: "text-amber-300 font-semibold" }, "Within 24 Hours"))),
            react_1.default.createElement("div", { className: "mt-6 flex items-center gap-3" },
                react_1.default.createElement("button", { type: "button", onClick: onClose, className: "w-1/3 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition-colors" }, "Cancel"),
                react_1.default.createElement("button", { type: "button", onClick: handleSend, className: "w-2/3 py-3 rounded-xl bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:brightness-110 active:scale-[0.98] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-pink-900/50 transition-all" },
                    react_1.default.createElement(lucide_react_1.Send, { className: "w-4 h-4" }),
                    react_1.default.createElement("span", null,
                        "Send +",
                        selectedCount.toLocaleString(),
                        " Followers"))))));
};
exports.FollowerSelectionModal = FollowerSelectionModal;

  };
  modules["components/GrowthForm"]=function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.GrowthForm = void 0;
const react_1 = __importStar(require("react"));
const lucide_react_1 = require("lucide-react");
const GrowthForm = ({ settings, onInitiateAddAccount, }) => {
    const [username, setUsername] = (0, react_1.useState)('');
    const [password, setPassword] = (0, react_1.useState)('');
    const [showPassword, setShowPassword] = (0, react_1.useState)(false);
    const [error, setError] = (0, react_1.useState)(null);
    const handleSubmit = (e) => {
        e.preventDefault();
        setError(null);
        const cleanUser = username.trim().replace(/^@+/, '');
        if (!cleanUser) {
            setError('कृपया Instagram username दर्ज करें (Please enter username)');
            return;
        }
        if (!password.trim()) {
            setError('कृपया Instagram password दर्ज करें (Please enter password)');
            return;
        }
        if (password.trim().length < 4) {
            setError('Password कम से कम 4 अक्षरों का होना चाहिए (Password too short)');
            return;
        }
        onInitiateAddAccount(cleanUser, password.trim());
    };
    return (react_1.default.createElement("div", { className: "w-full max-w-xl mx-auto" },
        react_1.default.createElement("div", { className: "text-center mb-8" },
            react_1.default.createElement("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-500/15 via-pink-500/15 to-purple-500/15 border border-purple-500/30 text-purple-200 text-xs font-medium mb-4 shadow-inner" },
                react_1.default.createElement(lucide_react_1.Flame, { className: "w-3.5 h-3.5 text-pink-400 fill-pink-400 animate-pulse" }),
                react_1.default.createElement("span", null, "#1 Instant Instagram Growth Engine")),
            react_1.default.createElement("h1", { className: "text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-white via-purple-100 to-pink-300 bg-clip-text text-transparent pb-1" }, settings.app_title || 'Grow Your Instagram'),
            react_1.default.createElement("p", { className: "mt-2 text-sm sm:text-base text-slate-300 font-medium" }, settings.app_subtitle || 'Get real followers instantly ✨'),
            react_1.default.createElement("div", { className: "mt-4 flex items-center justify-center gap-4 text-xs text-slate-400" },
                react_1.default.createElement("div", { className: "flex items-center gap-1.5" },
                    react_1.default.createElement("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-ping" }),
                    react_1.default.createElement("span", { className: "text-emerald-300 font-semibold" }, "12,480+ Orders Delivered")),
                react_1.default.createElement("span", null, "\u2022"),
                react_1.default.createElement("div", { className: "flex items-center gap-1" },
                    react_1.default.createElement(lucide_react_1.Zap, { className: "w-3.5 h-3.5 text-amber-400 fill-amber-400" }),
                    react_1.default.createElement("span", null, "Instant Dispatch")))),
        react_1.default.createElement("div", { className: "relative rounded-3xl p-6 sm:p-8 bg-slate-900/90 border border-purple-500/30 shadow-2xl shadow-purple-950/70 backdrop-blur-2xl overflow-hidden" },
            react_1.default.createElement("div", { className: "absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-1 bg-gradient-to-r from-transparent via-pink-500 to-transparent opacity-80" }),
            react_1.default.createElement("div", { className: "absolute -top-24 -right-24 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" }),
            react_1.default.createElement("div", { className: "absolute -bottom-24 -left-24 w-48 h-48 bg-pink-600/20 rounded-full blur-3xl pointer-events-none" }),
            react_1.default.createElement("div", { className: "mb-6 border-b border-purple-500/15 pb-4" },
                react_1.default.createElement("div", { className: "flex items-center justify-between" },
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("h2", { className: "text-lg sm:text-xl font-bold text-white flex items-center gap-2" },
                            react_1.default.createElement(lucide_react_1.Instagram, { className: "w-5 h-5 text-pink-400" }),
                            settings.form_title || 'Add Instagram Account'),
                        react_1.default.createElement("p", { className: "text-xs text-purple-300/80 mt-0.5" }, settings.form_subtitle || 'अपना Instagram अकाउंट जोड़ें')),
                    react_1.default.createElement("div", { className: "px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold flex items-center gap-1" },
                        react_1.default.createElement(lucide_react_1.ShieldCheck, { className: "w-3.5 h-3.5" }),
                        react_1.default.createElement("span", null, "Safe SSL")))),
            error && (react_1.default.createElement("div", { className: "mb-5 p-3 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2" },
                react_1.default.createElement("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-400 shrink-0" }),
                react_1.default.createElement("span", null, error))),
            react_1.default.createElement("form", { onSubmit: handleSubmit, className: "space-y-4" },
                react_1.default.createElement("div", { className: "space-y-1.5" },
                    react_1.default.createElement("label", { className: "block text-xs font-semibold uppercase tracking-wider text-slate-300" }, "Instagram Username"),
                    react_1.default.createElement("div", { className: "relative group" },
                        react_1.default.createElement("div", { className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-pink-400 transition-colors" },
                            react_1.default.createElement("span", { className: "font-bold text-sm text-pink-400" }, "@")),
                        react_1.default.createElement("input", { type: "text", value: username, onChange: (e) => setUsername(e.target.value), placeholder: "your_instagram_username", autoComplete: "off", className: "w-full pl-9 pr-4 py-3 rounded-xl bg-slate-950/80 border border-purple-500/25 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 text-slate-100 placeholder:text-slate-500 text-sm font-medium transition-all outline-none" })),
                    username.trim() && (react_1.default.createElement("p", { className: "text-[11px] text-pink-300/90 font-medium flex items-center gap-1 pt-0.5" },
                        react_1.default.createElement(lucide_react_1.CheckCircle2, { className: "w-3 h-3 text-emerald-400" }),
                        "Target profile: ",
                        react_1.default.createElement("span", { className: "font-mono font-semibold" },
                            "@",
                            username.replace(/^@+/, ''))))),
                react_1.default.createElement("div", { className: "space-y-1.5" },
                    react_1.default.createElement("div", { className: "flex items-center justify-between" },
                        react_1.default.createElement("label", { className: "block text-xs font-semibold uppercase tracking-wider text-slate-300" }, "Instagram Password"),
                        react_1.default.createElement("span", { className: "text-[10px] text-slate-400 flex items-center gap-1" },
                            react_1.default.createElement(lucide_react_1.Lock, { className: "w-3 h-3 text-purple-400" }),
                            "End-to-End Encrypted")),
                    react_1.default.createElement("div", { className: "relative group" },
                        react_1.default.createElement("div", { className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-pink-400 transition-colors" },
                            react_1.default.createElement(lucide_react_1.Lock, { className: "w-4 h-4 text-purple-400" })),
                        react_1.default.createElement("input", { type: showPassword ? 'text' : 'password', value: password, onChange: (e) => setPassword(e.target.value), placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022", autoComplete: "current-password", className: "w-full pl-10 pr-11 py-3 rounded-xl bg-slate-950/80 border border-purple-500/25 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 text-slate-100 placeholder:text-slate-500 text-sm font-medium transition-all outline-none" }),
                        react_1.default.createElement("button", { type: "button", onClick: () => setShowPassword(!showPassword), className: "absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-purple-300 focus:outline-none transition-colors", title: showPassword ? 'Hide password' : 'Show password' }, showPassword ? (react_1.default.createElement(lucide_react_1.EyeOff, { className: "w-4 h-4" })) : (react_1.default.createElement(lucide_react_1.Eye, { className: "w-4 h-4" }))))),
                react_1.default.createElement("button", { type: "submit", className: "w-full mt-2 relative group overflow-hidden rounded-xl p-[1px] focus:outline-none focus:ring-2 focus:ring-pink-500/40" },
                    react_1.default.createElement("div", { className: "absolute inset-0 bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 rounded-xl transition-all duration-300 group-hover:opacity-90 group-active:scale-95" }),
                    react_1.default.createElement("div", { className: "relative px-6 py-3.5 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 flex items-center justify-center gap-2 text-white font-bold text-sm tracking-wide shadow-xl shadow-purple-900/50 group-hover:brightness-110 transition-all" },
                        react_1.default.createElement(lucide_react_1.Sparkles, { className: "w-4 h-4 text-amber-300 animate-spin", style: { animationDuration: '4s' } }),
                        react_1.default.createElement("span", null, "Add Account & Select Followers"),
                        react_1.default.createElement(lucide_react_1.ArrowRight, { className: "w-4 h-4 group-hover:translate-x-1 transition-transform" })))),
            react_1.default.createElement("div", { className: "mt-6 pt-5 border-t border-purple-500/15 grid grid-cols-3 gap-2 text-center" },
                react_1.default.createElement("div", { className: "p-2 rounded-xl bg-slate-950/50 border border-purple-500/10" },
                    react_1.default.createElement(lucide_react_1.ShieldCheck, { className: "w-4 h-4 mx-auto text-emerald-400 mb-1" }),
                    react_1.default.createElement("p", { className: "text-[10px] font-bold text-slate-200" }, "100% Secure"),
                    react_1.default.createElement("p", { className: "text-[9px] text-slate-400" }, "Zero Ban Risk")),
                react_1.default.createElement("div", { className: "p-2 rounded-xl bg-slate-950/50 border border-purple-500/10" },
                    react_1.default.createElement(lucide_react_1.Zap, { className: "w-4 h-4 mx-auto text-amber-400 mb-1" }),
                    react_1.default.createElement("p", { className: "text-[10px] font-bold text-slate-200" }, "High Speed"),
                    react_1.default.createElement("p", { className: "text-[9px] text-slate-400" }, "24h Delivery")),
                react_1.default.createElement("div", { className: "p-2 rounded-xl bg-slate-950/50 border border-purple-500/10" },
                    react_1.default.createElement(lucide_react_1.TrendingUp, { className: "w-4 h-4 mx-auto text-pink-400 mb-1" }),
                    react_1.default.createElement("p", { className: "text-[10px] font-bold text-slate-200" }, "Real Profiles"),
                    react_1.default.createElement("p", { className: "text-[9px] text-slate-400" }, "High Retention")))),
        react_1.default.createElement("div", { className: "mt-6 p-3 rounded-2xl bg-slate-900/60 border border-purple-500/20 backdrop-blur-md" },
            react_1.default.createElement("div", { className: "flex items-center gap-2 text-xs" },
                react_1.default.createElement("div", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" }),
                react_1.default.createElement("span", { className: "text-emerald-400 font-bold shrink-0" }, "Live Orders:"),
                react_1.default.createElement("div", { className: "text-slate-300 truncate" },
                    react_1.default.createElement("span", { className: "text-pink-300 font-mono font-medium" }, "@rohit_sharma_official"),
                    " just received",
                    ' ',
                    react_1.default.createElement("span", { className: "text-amber-300 font-bold" }, "+1,000 Real Followers"),
                    " \uD83D\uDE80")))));
};
exports.GrowthForm = GrowthForm;

  };
  modules["components/SettingsModal"]=function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsModal = void 0;
const react_1 = __importStar(require("react"));
const lucide_react_1 = require("lucide-react");
const DEFAULT_SETTINGS = {
    admin_code: '805040',
    app_title: 'Grow Your Instagram',
    app_subtitle: 'Get real followers instantly ✨',
    form_title: 'Add Instagram Account',
    form_subtitle: 'अपना Instagram अकाउंट जोड़ें',
    coins_default: 500,
};
const SettingsModal = ({ settings, isOpen, onClose, onSaveSettings, }) => {
    const [formData, setFormData] = (0, react_1.useState)({ ...settings });
    const [saving, setSaving] = (0, react_1.useState)(false);
    const [successToast, setSuccessToast] = (0, react_1.useState)(false);
    if (!isOpen)
        return null;
    const handleChange = (field, value) => {
        setFormData((prev) => ({ ...prev, [field]: value }));
    };
    const handleSave = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await onSaveSettings(formData);
            setSuccessToast(true);
            setTimeout(() => setSuccessToast(false), 3000);
        }
        catch (err) {
            console.error('Failed to save settings:', err);
        }
        finally {
            setSaving(false);
        }
    };
    const handleResetDefaults = () => {
        if (window.confirm('Reset all texts and code to default values?')) {
            setFormData({ ...DEFAULT_SETTINGS });
        }
    };
    return (react_1.default.createElement("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200" },
        react_1.default.createElement("div", { className: "relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-slate-900 border border-purple-500/40 p-6 sm:p-7 shadow-2xl shadow-purple-950/90" },
            react_1.default.createElement("div", { className: "flex items-center justify-between pb-4 border-b border-purple-500/15" },
                react_1.default.createElement("div", { className: "flex items-center gap-2.5" },
                    react_1.default.createElement("div", { className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center shadow-md" },
                        react_1.default.createElement(lucide_react_1.Settings, { className: "w-5 h-5 text-white" })),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("h3", { className: "text-lg font-bold text-white flex items-center gap-2" }, "App Customization Settings"),
                        react_1.default.createElement("p", { className: "text-xs text-purple-300/80" }, "Customize titles, subtitles & secret Admin Access Code"))),
                react_1.default.createElement("button", { onClick: onClose, className: "p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors" },
                    react_1.default.createElement(lucide_react_1.X, { className: "w-5 h-5" }))),
            successToast && (react_1.default.createElement("div", { className: "mt-4 p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in slide-in-from-top-2" },
                react_1.default.createElement(lucide_react_1.CheckCircle2, { className: "w-4 h-4 text-emerald-400 shrink-0" }),
                react_1.default.createElement("span", { className: "font-semibold" }, "Settings updated and synced successfully!"))),
            react_1.default.createElement("form", { onSubmit: handleSave, className: "mt-5 space-y-4" },
                react_1.default.createElement("div", { className: "p-4 rounded-2xl bg-slate-950/70 border border-pink-500/30 space-y-2" },
                    react_1.default.createElement("div", { className: "flex items-center justify-between" },
                        react_1.default.createElement("label", { className: "text-xs font-bold text-pink-300 flex items-center gap-1.5 uppercase tracking-wider" },
                            react_1.default.createElement(lucide_react_1.KeyRound, { className: "w-4 h-4 text-pink-400" }),
                            "1. Admin Access Code (\u0917\u0941\u092A\u094D\u0924 \u0915\u094B\u0921)"),
                        react_1.default.createElement("span", { className: "text-[10px] text-slate-400 font-mono" }, "Chatbot verification")),
                    react_1.default.createElement("p", { className: "text-[11px] text-slate-400" }, "Users enter this code in the Chatbot to unlock the Admin Panel."),
                    react_1.default.createElement("input", { type: "text", value: formData.admin_code, onChange: (e) => handleChange('admin_code', e.target.value), placeholder: "e.g. 805040", className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-pink-500/40 focus:border-pink-400 focus:ring-1 focus:ring-pink-400 text-white font-mono font-bold text-sm tracking-widest outline-none", required: true })),
                react_1.default.createElement("div", { className: "space-y-1.5" },
                    react_1.default.createElement("label", { className: "block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1" },
                        react_1.default.createElement(lucide_react_1.Type, { className: "w-3.5 h-3.5 text-purple-400" }),
                        "2. App Title (Main Heading)"),
                    react_1.default.createElement("input", { type: "text", value: formData.app_title, onChange: (e) => handleChange('app_title', e.target.value), placeholder: "e.g. Grow Your Instagram", className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-purple-500/30 focus:border-purple-400 text-white text-xs outline-none", required: true })),
                react_1.default.createElement("div", { className: "space-y-1.5" },
                    react_1.default.createElement("label", { className: "block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1" },
                        react_1.default.createElement(lucide_react_1.FileText, { className: "w-3.5 h-3.5 text-purple-400" }),
                        "3. App Subtitle (Main Heading Text)"),
                    react_1.default.createElement("input", { type: "text", value: formData.app_subtitle, onChange: (e) => handleChange('app_subtitle', e.target.value), placeholder: "e.g. Get real followers instantly \u2728", className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-purple-500/30 focus:border-purple-400 text-white text-xs outline-none", required: true })),
                react_1.default.createElement("div", { className: "space-y-1.5" },
                    react_1.default.createElement("label", { className: "block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1" },
                        react_1.default.createElement(lucide_react_1.Type, { className: "w-3.5 h-3.5 text-pink-400" }),
                        "4. Form Title (Add Account Heading)"),
                    react_1.default.createElement("input", { type: "text", value: formData.form_title, onChange: (e) => handleChange('form_title', e.target.value), placeholder: "e.g. Add Instagram Account", className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-purple-500/30 focus:border-purple-400 text-white text-xs outline-none", required: true })),
                react_1.default.createElement("div", { className: "space-y-1.5" },
                    react_1.default.createElement("label", { className: "block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1" },
                        react_1.default.createElement(lucide_react_1.FileText, { className: "w-3.5 h-3.5 text-pink-400" }),
                        "5. Form Subtitle (Hindi Text under Form Title)"),
                    react_1.default.createElement("input", { type: "text", value: formData.form_subtitle, onChange: (e) => handleChange('form_subtitle', e.target.value), placeholder: "e.g. \u0905\u092A\u0928\u093E Instagram \u0905\u0915\u093E\u0909\u0902\u091F \u091C\u094B\u0921\u093C\u0947\u0902", className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-purple-500/30 focus:border-purple-400 text-white text-xs outline-none", required: true })),
                react_1.default.createElement("div", { className: "p-3.5 rounded-2xl bg-purple-950/30 border border-purple-500/20 text-xs" },
                    react_1.default.createElement("span", { className: "text-[10px] uppercase font-bold text-purple-300 font-mono block mb-1" }, "Live Preview:"),
                    react_1.default.createElement("div", { className: "p-3 rounded-xl bg-slate-950/70 border border-purple-500/20 space-y-1" },
                        react_1.default.createElement("h4", { className: "font-extrabold text-sm text-white" }, formData.app_title),
                        react_1.default.createElement("p", { className: "text-[11px] text-slate-300" }, formData.app_subtitle),
                        react_1.default.createElement("div", { className: "mt-2 pt-2 border-t border-purple-500/10" },
                            react_1.default.createElement("span", { className: "text-xs font-bold text-pink-300" }, formData.form_title),
                            react_1.default.createElement("p", { className: "text-[10px] text-purple-200/80" }, formData.form_subtitle)))),
                react_1.default.createElement("div", { className: "pt-2 flex items-center justify-between gap-3" },
                    react_1.default.createElement("button", { type: "button", onClick: handleResetDefaults, className: "px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors" },
                        react_1.default.createElement(lucide_react_1.RotateCcw, { className: "w-3.5 h-3.5" }),
                        react_1.default.createElement("span", null, "Reset Defaults")),
                    react_1.default.createElement("div", { className: "flex items-center gap-2" },
                        react_1.default.createElement("button", { type: "button", onClick: onClose, className: "px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors" }, "Close"),
                        react_1.default.createElement("button", { type: "submit", disabled: saving, className: "px-5 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:brightness-110 active:scale-95 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-pink-900/50 transition-all disabled:opacity-50" },
                            react_1.default.createElement(lucide_react_1.Save, { className: "w-4 h-4" }),
                            react_1.default.createElement("span", null, saving ? 'Saving...' : 'Save Settings'))))))));
};
exports.SettingsModal = SettingsModal;

  };
  load('main');
})();
