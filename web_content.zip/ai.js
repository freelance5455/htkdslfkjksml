/* Learnova Creator Studio — AI assist (bring-your-own Anthropic API key) */
(function(){
const p=data.projects.find(x=>x.id===Q.get("id")),page=document.body.dataset.ws;if(!p||!page)return;
const C=()=>`Video: "${p.title||p.name}"\nFormat: ${p.format} (${p.length||"length not set"})\nPillar: ${p.pillar}\nGoal: ${p.goal||"-"}\nAudience: ${p.audience||"-"}\nResearch notes: ${p.research||"-"}\nHook: ${p.hook||"-"}`;
function put(id,v){const el=$(id);if(!el||!v)return;if(el.value.trim()&&!confirm("Replace the current text in this field?"))return;el.value=v;el.dispatchEvent(new Event("input",{bubbles:true}));}
const words=p.format==="YouTube Short"?"under 130 words":"matching the target length at about 150 words per minute";
const A={
overview:[["✨ Draft research outline",async()=>put("researchInput",await ai(C()+"\n\nWrite a concise research outline: 5-7 key points to cover, questions to verify, and the kinds of sources to check. Plain text, no markdown.",1200))]],
script:[["✨ Write hook",async()=>put("hookInput",await ai(C()+"\n\nWrite one strong 1-2 sentence opening hook for this video. Return only the hook.",300))],
 ["✨ Draft script",async()=>put("scriptInput",await ai(C()+`\n\nWrite the narration script, ${words}. Use short ALL-CAPS section labels on their own line, then spoken text. Plain text, no markdown. Mark claims to fact-check with [verify].`,2500))],
 ["✨ Tighten script",async()=>{if(!p.script){toast("Write or draft a script first.");return;}const t=await ai("Tighten this narration: cut filler, keep the meaning, keep the section labels, keep it natural to speak aloud. Return only the revised script.\n\n"+p.script,2500);if(t){const el=$("scriptInput");if(confirm("Replace your script with the tightened version?")){el.value=t;el.dispatchEvent(new Event("input",{bubbles:true}));}}}]],
scenes:[["✨ AI visual prompts",async()=>{if(!p.scenes.length){toast("Add or split into scenes first.");return;}
 const t=await ai(`${C()}\nVisual style: ${p.visualStyle||"clean, modern educational"}\n\nFor each scene write one image-generation prompt (no text in the image, no real people). Return ONLY a JSON array of ${p.scenes.length} strings, in order.\n\n`+p.scenes.map((s,i)=>`${i+1}. ${s.beat}: ${s.narration}`).join("\n"),2500);
 if(!t)return;const a=J(t);if(!Array.isArray(a))throw new Error("Unexpected reply");a.forEach((x,i)=>{if(p.scenes[i]&&x)p.scenes[i].prompt=String(x);});p.updated=new Date().toISOString();save();location.reload();}]],
thumbnail:[["✨ Titles, thumbnail & tags",async()=>{const t=await ai(C()+"\n\nReturn ONLY JSON: {\"titles\":[3 click-worthy but honest titles under 70 chars],\"thumbText\":\"max 4 words\",\"thumbPrompt\":\"image prompt for the thumbnail, no text in image\",\"description\":\"2-3 sentence YouTube description\",\"tags\":\"10 comma-separated tags\"}",1200);
 if(!t)return;const o=J(t);put("thumbTextInput",o.thumbText);put("thumbPromptInput",o.thumbPrompt);put("descriptionInput",o.description);put("tagsInput",o.tags);
 $("aiOut").innerHTML="<strong>Title options</strong><br>"+(o.titles||[]).map(esc).join("<br>");}]]};
const bar=document.createElement("div");bar.className="ai-bar";
(A[page]||[]).forEach(([label,fn])=>{const b=document.createElement("button");b.type="button";b.className="ai-btn";b.textContent=label;
 b.onclick=async()=>{b.disabled=true;b.textContent="Thinking…";try{await fn();}catch(e){toast("AI error: "+e.message);}b.disabled=false;b.textContent=label;};bar.appendChild(b);});
if(bar.children.length){const tp=document.querySelector(".tab-panel");tp.insertBefore(bar,tp.firstChild.nextSibling||null);bar.insertAdjacentHTML("afterend",'<p class="helper" id="aiOut"></p>');}
})();
