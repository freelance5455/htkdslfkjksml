import {
  getAI,
  getGenerativeModel,
  GoogleAIBackend
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-ai.js";

import { app } from "./firebase.js";

const ai = getAI(app, {
  backend: new GoogleAIBackend()
});

const model = getGenerativeModel(ai, {
  model: "gemini-3.5-flash-lite"
});

// تحويل الصورة إلى صيغة يستطيع Gemini قراءتها
function fileToGenerativePart(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => {
      const base64 = reader.result.split(",")[1];

      resolve({
        inlineData: {
          data: base64,
          mimeType: file.type
        }
      });
    };

    reader.onerror = () => {
      reject(new Error("تعذرت قراءة إحدى الصور."));
    };

    reader.readAsDataURL(file);
  });
}

// إنشاء جلسة محادثة
export function createAHMADAiChat(history = []) {
  const chat = model.startChat({
    history: history
  });

  return {
    // إرسال النص بالطريقة القديمة
    async send(prompt) {
      const result = await chat.sendMessage(prompt);
      return result.response.text();
    },

    // إرسال النص مع صور الدرس
    async sendWithImages(prompt, images = []) {
      const imageParts = await Promise.all(
        images.map(fileToGenerativePart)
      );

      const result = await chat.sendMessage([
        { text: prompt },
        ...imageParts
      ]);

      return result.response.text();
    }
  };
}