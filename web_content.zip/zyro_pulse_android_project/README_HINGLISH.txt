ZYRO PULSE — ANDROID STARTER PROJECT
====================================

Is project mein:
- Stocks, Crypto, Commodities, Indices aur Futures & Options ke fictional demo markets
- ₹10,000 virtual trading wallet; successful BUY par cash turant deduct hota hai
- Alag MARKETS aur UP / DOWN PULSE screens
- Up/Down practice points (cash nahi), simulated chart aur automatic price movement
- Local browser/app storage; no sign-in; no live market connection
- Capacitor Android starter project

IMPORTANT
---------
Yeh ZIP source project hai, APK/AAB file nahi. Google Play par publish karne ke liye Android Studio/Android SDK se build karna, app test karna, Play Console account aur Google Play ke current policies/required declarations complete karna hoga. Publishing guaranteed nahi hoti.

ANDROID BUILD (PC/LAPTOP PAR)
-----------------------------
1. Install Node.js (LTS) and Android Studio.
2. Extract this ZIP.
3. Terminal/Command Prompt mein project folder open karo.
4. Run:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
5. Android Studio mein Gradle sync hone do.
6. Testing ke liye Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Google Play release ke liye signed Android App Bundle (.aab) create karna hota hai; Android Studio ke Build > Generate Signed Bundle / APK menu se AAB select karo.
8. Play Console ke app setup, privacy/data-safety, content rating, target API, testing aur other current requirements follow karo.

PHONE-ONLY NOTE
---------------
Sirf HTML file ko Google Play par direct upload nahi kar sakte. APK/AAB build karne ke liye Android build environment chahiye. Agar sirf phone hai, to cloud/online build service ya kisi computer ki zaroorat padegi.

SIMULATION DISCLAIMER
--------------------
Saare asset names/prices aur Up/Down movement fictional/simulated hain. Koi real order, live market data, real-money bet, cash payout ya financial advice nahi. Practice points ka koi cash value nahi.
