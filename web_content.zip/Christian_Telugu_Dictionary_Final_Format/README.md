# Christian Telugu Dictionary — Android Project

This project wraps the current Christian Telugu Dictionary HTML UI in an Android WebView.

Included:
- Current Home UI
- Left slide-in Sidebar
- Dark Mode option in Sidebar
- Telugu / English / Greek UI
- Android native Status Bar and Navigation Bar colors set to dark (#101216)
- WebView JavaScript + local asset support

Open this folder in Android Studio and run/build the app.

For APK:
Android Studio -> Build -> Build APK(s)

The debug APK is normally generated under:
app/build/outputs/apk/debug/app-debug.apk
