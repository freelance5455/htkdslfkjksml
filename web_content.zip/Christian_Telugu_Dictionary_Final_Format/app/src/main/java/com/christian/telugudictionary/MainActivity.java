package com.christian.telugudictionary;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private static final String WEBVIEW_STATE = "dictionary_webview_state";
    private boolean userLeftApp = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        makeTrueFullscreen();

        webView = new WebView(this);
        webView.setSaveEnabled(true);
        webView.setBackgroundColor(Color.rgb(16, 18, 22));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);

        if (savedInstanceState != null && savedInstanceState.containsKey(WEBVIEW_STATE)) {
            Bundle state = savedInstanceState.getBundle(WEBVIEW_STATE);
            if (state != null) {
                webView.restoreState(state);
                return;
            }
        }

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void makeTrueFullscreen() {
        Window window = getWindow();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
                controller.hide(
                    WindowInsets.Type.statusBars() |
                    WindowInsets.Type.navigationBars()
                );
            }
        } else {
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);

            int flags =
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

            window.getDecorView().setSystemUiVisibility(flags);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        makeTrueFullscreen();

        if (webView != null) {
            webView.onResume();

            if (userLeftApp) {
                userLeftApp = false;
                webView.postDelayed(() -> webView.evaluateJavascript(
                    "window.returnToDictionaryHome && window.returnToDictionaryHome();",
                    null
                ), 150);
            }
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onUserLeaveHint() {
        userLeftApp = true;
        super.onUserLeaveHint();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            makeTrueFullscreen();
        }
    }

    @Override
    protected void onSaveInstanceState(@Nullable Bundle outState) {
        if (outState != null && webView != null) {
            Bundle state = new Bundle();
            webView.saveState(state);
            outState.putBundle(WEBVIEW_STATE, state);
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                "(document.body.classList.contains('search-result-mode') || " +
                "(document.getElementById('result') && " +
                "getComputedStyle(document.getElementById('result')).display !== 'none')) " +
                "? 'RESULT' : 'HOME'",
                value -> {
                    if ("\"RESULT\"".equals(value)) {
                        webView.evaluateJavascript(
                            "window.returnToDictionaryHome && window.returnToDictionaryHome();",
                            null
                        );
                    } else if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        MainActivity.super.onBackPressed();
                    }
                }
            );
            return;
        }
        super.onBackPressed();
    }
}
