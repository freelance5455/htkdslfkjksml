package com.christian.telugudictionary;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private static final String WEBVIEW_STATE = "dictionary_webview_state";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(16,18,22));
        window.setNavigationBarColor(Color.rgb(16,18,22));

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            window.getDecorView().setSystemUiVisibility(0);
        }

        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }

        webView = new WebView(this);
        webView.setSaveEnabled(true);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setBackgroundColor(Color.rgb(16,18,22));
        webView.setWebViewClient(new WebViewClient());

        setContentView(webView);

        // Restore the exact WebView screen/state after returning from the phone Home gesture
        // or after an Activity recreation. Only load index.html when there is no saved state.
        if (savedInstanceState != null
                && savedInstanceState.containsKey(WEBVIEW_STATE)) {
            Bundle state = savedInstanceState.getBundle(WEBVIEW_STATE);
            if (state != null) {
                webView.restoreState(state);
                return;
            }
        }

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onSaveInstanceState(@Nullable Bundle outState) {
        if (outState != null && webView != null) {
            Bundle webState = new Bundle();
            webView.saveState(webState);
            outState.putBundle(WEBVIEW_STATE, webState);
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                "(document.body.classList.contains('search-result-mode') || " +
                "(document.getElementById('result') && " +
                "getComputedStyle(document.getElementById('result')).display !== 'none')) " +
                "? 'RESULT' : 'HOME'",
                value -> {
                    if ("\"RESULT\"".equals(value)) {
                        webView.evaluateJavascript(
                            "window.returnToDictionaryHome && window.returnToDictionaryHome();",
                            null
                        );
                    } else if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        MainActivity.super.onBackPressed();
                    }
                }
            );
            return;
        }
        super.onBackPressed();
    }
}
