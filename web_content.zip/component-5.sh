npm run build
# اسحب مجلد dist إلى https://app.netlify.com/drop