/**
 * MohamiOffice - Google Apps Script backup endpoint
 * 1) Create a new Apps Script project.
 * 2) Paste this file as Code.gs.
 * 3) Set BACKUP_TOKEN below to a long random secret, then use the same value in the app.
 * 4) Deploy > New deployment > Web app.
 *    Execute as: Me
 *    Who has access: Anyone (the token protects requests; do not share the URL/token).
 * 5) Copy the /exec URL into MohamiOffice settings.
 */
const BACKUP_TOKEN = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET';
const BACKUP_FILE_NAME = 'MohamiOffice_AutoBackup.json';

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (body.token !== BACKUP_TOKEN) return output({ok:false, error:'Unauthorized'});
    if (!body.data || body.data.app !== 'MohamiOffice') return output({ok:false, error:'Invalid data'});
    const content = JSON.stringify(body.data, null, 2);
    const files = DriveApp.getFilesByName(BACKUP_FILE_NAME);
    if (files.hasNext()) {
      const file = files.next();
      file.setContent(content);
    } else {
      DriveApp.createFile(BACKUP_FILE_NAME, content, MimeType.PLAIN_TEXT);
    }
    return output({ok:true, savedAt:new Date().toISOString()});
  } catch (err) {
    return output({ok:false, error:String(err)});
  }
}
function doGet() {
  return output({service:'MohamiOffice backup endpoint', ready:true});
}
function output(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
