# Terra Forge para Android (WebView + HTML local)

Este projeto Android Studio inclui o jogo em `app/src/main/assets/index.html`. Não é necessário publicar o HTML num site para abrir o jogo dentro do app.

## Importante sobre internet

O HTML foi feito com dependências externas: ele carrega o motor 3D Three.js pelo CDN `cdnjs.cloudflare.com`. O modo online/multiplayer também usa serviços PeerJS/WebRTC e servidores de conexão. Por isso, **os arquivos principais do jogo ficam dentro do APK, mas a primeira execução precisa de internet para carregar o Three.js se ainda não estiver em cache; recursos online e multiplayer também dependem de internet**. Este pacote não é uma versão totalmente offline.

## Como gerar o APK

1. Num computador, instale o Android Studio atualizado.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `TerraForgeAndroid` (a pasta que contém `settings.gradle`).
4. Aguarde a sincronização do Gradle e a instalação dos componentes solicitados.
5. Para testar, conecte um celular Android com depuração USB ativada ou use um emulador e pressione **Run**.
6. Para gerar um APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de teste costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

## Testes recomendados

- Abra o app com internet e confirme que o cenário 3D aparece.
- Teste os controles de toque e a gravação/carregamento de jogo.
- Teste separadamente o modo online, porque conexões WebRTC podem depender da rede e dos servidores externos.

## Dados técnicos

- Package/application ID: `br.com.terraforge`
- Min SDK: Android 6.0 (API 23)
- Target/compile SDK: API 35
- WebView com JavaScript, DOM Storage e aceleração de hardware habilitados.
