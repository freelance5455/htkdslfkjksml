# City Drive Lite – Android Studio Project

यह प्रोजेक्ट आपके दिए गए `City_Drive_Lite_Project.zip` वाले HTML गेम को Android WebView ऐप में चलाने के लिए बनाया गया है।

## Android Studio में APK बनाने के चरण

1. ZIP को Extract करें।
2. Android Studio खोलें और **Open** चुनें।
3. Extract किए गए `CityDriveLite_Android` फ़ोल्डर को चुनें।
4. Gradle Sync पूरा होने दें। जरूरत पड़ने पर Android Studio का सुझाया हुआ Gradle JDK चुनें।
5. ऊपर मेन्यू में **Build > Build Bundle(s) / APK(s) > Build APK(s)** चुनें।
6. Build पूरा होने पर APK आमतौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगी।

## जरूरी बात

- गेम `app/src/main/assets/index.html` में रखा गया है।
- ऐप इंटरनेट URL के बजाय `file:///android_asset/index.html` से गेम खोलती है। इससे `appassets.androidplatform.net` वाली URL लोडिंग समस्या से बचा जाता है।
- यह Android Studio source project है, पहले से बनी APK नहीं।
- प्रोजेक्ट को Android Studio में खोलकर APK build करें।
