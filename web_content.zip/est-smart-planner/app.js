/**
 * EST Smart Planner & Visual Hub
 * Full client-side interactive application
 */

// ===================== STATE =====================
const STORAGE_KEY = 'est_smart_planner_v1';

const state = {
  currentSection: 'dashboard',
  currentTable: 'academic', // academic | family | habits | custom
  data: {
    academic: [],
    family: [],
    habits: [],
    custom: []
  },
  filters: {
    priority: 'all',
    status: 'all',
    search: ''
  }
};

// ===================== INIT =====================
document.addEventListener('DOMContentLoaded', () => {
  loadFromStorage();
  bindNavigation();
  bindTableEvents();
  bindAIEvents();
  bindExportEvents();
  bindDashboardCards();
  updateStats();
  registerServiceWorker();
  setupInstallPrompt();
});

// ===================== STORAGE =====================
function saveToStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.data));
  } catch (e) {
    console.warn('Storage full or unavailable', e);
  }
}

function loadFromStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      state.data = { ...state.data, ...parsed };
    }
  } catch (e) {
    console.warn('Could not load storage', e);
  }
}

// ===================== NAVIGATION =====================
function bindNavigation() {
  document.querySelectorAll('.nav-card').forEach(btn => {
    btn.addEventListener('click', () => {
      const section = btn.dataset.section;
      navigateTo(section);
    });
  });
}

function navigateTo(section) {
  // Update nav
  document.querySelectorAll('.nav-card').forEach(b => b.classList.remove('active'));
  const navBtn = document.querySelector(`.nav-card[data-section="${section}"]`);
  if (navBtn) navBtn.classList.add('active');

  // Hide all sections
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));

  if (['academic', 'family', 'habits', 'custom'].includes(section)) {
    state.currentTable = section;
    state.currentSection = 'table';
    document.getElementById('section-table').classList.add('active');
    updateTableHeader();
    renderTable();
  } else {
    state.currentSection = section;
    const el = document.getElementById(`section-${section}`);
    if (el) el.classList.add('active');
  }
}

function bindDashboardCards() {
  document.querySelectorAll('.dash-card[data-goto]').forEach(card => {
    card.addEventListener('click', () => {
      navigateTo(card.dataset.goto);
    });
  });
}

function updateTableHeader() {
  const titles = {
    academic: { title: '📚 الجدول الدراسي', sub: 'نظم دروسك وامتحاناتك ومهامك الأكاديمية' },
    family: { title: '👨‍👩‍👧‍👦 قائمة العائلة والمنزل', sub: 'مهام المنزل، التسوق، ومسؤوليات الأسرة' },
    habits: { title: '🔥 متتبع العادات', sub: 'تتبع عاداتك اليومية وابنِ روتينًا قويًا' },
    custom: { title: '📋 جدول بيانات مخصص', sub: 'أنشئ أي قائمة تناسب احتياجاتك' }
  };
  const t = titles[state.currentTable] || titles.custom;
  document.getElementById('table-title').textContent = t.title;
  document.getElementById('table-subtitle').textContent = t.sub;
}

// ===================== TABLE MODULE =====================
function bindTableEvents() {
  document.getElementById('btn-add-row').addEventListener('click', () => openRowForm());
  document.getElementById('btn-cancel-form').addEventListener('click', closeRowForm);
  document.getElementById('row-form').addEventListener('submit', handleRowSubmit);
  document.getElementById('btn-clear-completed').addEventListener('click', clearCompleted);

  document.getElementById('filter-priority').addEventListener('change', e => {
    state.filters.priority = e.target.value;
    renderTable();
  });
  document.getElementById('filter-status').addEventListener('change', e => {
    state.filters.status = e.target.value;
    renderTable();
  });
  document.getElementById('filter-search').addEventListener('input', e => {
    state.filters.search = e.target.value.trim().toLowerCase();
    renderTable();
  });
}

function getCurrentList() {
  return state.data[state.currentTable] || [];
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function openRowForm(editItem = null) {
  const modal = document.getElementById('row-form-modal');
  const form = document.getElementById('row-form');
  form.reset();
  document.getElementById('edit-id').value = '';

  if (editItem) {
    document.getElementById('form-title').textContent = 'تعديل المهمة';
    document.getElementById('edit-id').value = editItem.id;
    document.getElementById('f-task').value = editItem.task;
    document.getElementById('f-priority').value = editItem.priority;
    document.getElementById('f-deadline').value = editItem.deadline || '';
    document.getElementById('f-tag').value = editItem.tag || '';
    document.getElementById('f-notes').value = editItem.notes || '';
    document.getElementById('f-subtasks').value = (editItem.subtasks || []).map(s => s.text).join('\n');
  } else {
    document.getElementById('form-title').textContent = 'إضافة مهمة جديدة';
  }
  modal.classList.remove('hidden');
  document.getElementById('f-task').focus();
}

function closeRowForm() {
  document.getElementById('row-form-modal').classList.add('hidden');
}

function handleRowSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('edit-id').value;
  const task = document.getElementById('f-task').value.trim();
  if (!task) return;

  const subtasksRaw = document.getElementById('f-subtasks').value.trim();
  const subtasks = subtasksRaw
    ? subtasksRaw.split('\n').filter(l => l.trim()).map(text => ({
        id: generateId(),
        text: text.trim(),
        done: false
      }))
    : [];

  const item = {
    id: id || generateId(),
    task,
    priority: document.getElementById('f-priority').value,
    deadline: document.getElementById('f-deadline').value || null,
    tag: document.getElementById('f-tag').value.trim() || null,
    notes: document.getElementById('f-notes').value.trim() || null,
    subtasks,
    done: false,
    createdAt: new Date().toISOString()
  };

  const list = getCurrentList();
  if (id) {
    const idx = list.findIndex(x => x.id === id);
    if (idx !== -1) {
      item.done = list[idx].done;
      item.createdAt = list[idx].createdAt;
      // Preserve subtask done states if same text
      list[idx] = item;
    }
  } else {
    list.unshift(item);
  }

  saveToStorage();
  closeRowForm();
  renderTable();
  updateStats();
  showToast(id ? 'تم التعديل بنجاح' : 'تمت الإضافة بنجاح');
}

function toggleDone(id) {
  const list = getCurrentList();
  const item = list.find(x => x.id === id);
  if (item) {
    item.done = !item.done;
    saveToStorage();
    renderTable();
    updateStats();
  }
}

function toggleSubtask(rowId, subId) {
  const list = getCurrentList();
  const item = list.find(x => x.id === rowId);
  if (item && item.subtasks) {
    const sub = item.subtasks.find(s => s.id === subId);
    if (sub) {
      sub.done = !sub.done;
      saveToStorage();
      renderTable();
    }
  }
}

function deleteRow(id) {
  if (!confirm('هل أنت متأكد من حذف هذه المهمة؟')) return;
  const list = getCurrentList();
  const idx = list.findIndex(x => x.id === id);
  if (idx !== -1) {
    list.splice(idx, 1);
    saveToStorage();
    renderTable();
    updateStats();
    showToast('تم الحذف');
  }
}

function clearCompleted() {
  const list = getCurrentList();
  const before = list.length;
  state.data[state.currentTable] = list.filter(x => !x.done);
  if (state.data[state.currentTable].length < before) {
    saveToStorage();
    renderTable();
    updateStats();
    showToast('تم مسح المهام المكتملة');
  } else {
    showToast('لا توجد مهام مكتملة');
  }
}

function renderTable() {
  const tbody = document.getElementById('table-body');
  let list = [...getCurrentList()];

  // Filters
  if (state.filters.priority !== 'all') {
    list = list.filter(x => x.priority === state.filters.priority);
  }
  if (state.filters.status === 'done') {
    list = list.filter(x => x.done);
  } else if (state.filters.status === 'pending') {
    list = list.filter(x => !x.done);
  }
  if (state.filters.search) {
    const q = state.filters.search;
    list = list.filter(x =>
      x.task.toLowerCase().includes(q) ||
      (x.tag && x.tag.toLowerCase().includes(q)) ||
      (x.notes && x.notes.toLowerCase().includes(q))
    );
  }

  if (list.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6">
          <div class="empty-state">
            <div class="empty-icon">📝</div>
            <p>لا توجد مهام بعد. اضغط "إضافة صف" للبدء.</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  tbody.innerHTML = list.map(item => {
    const priorityLabel = { high: 'عالية', medium: 'متوسطة', low: 'منخفضة' }[item.priority] || item.priority;
    const deadlineStr = item.deadline
      ? new Date(item.deadline).toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric' })
      : '—';

    let subtasksHtml = '';
    if (item.subtasks && item.subtasks.length) {
      subtasksHtml = `<div class="subtasks">` +
        item.subtasks.map(s => `
          <div class="subtask">
            <input type="checkbox" ${s.done ? 'checked' : ''} 
              onchange="toggleSubtask('${item.id}','${s.id}')" />
            <span style="${s.done ? 'text-decoration:line-through;opacity:0.7' : ''}">${escapeHtml(s.text)}</span>
          </div>`).join('') + `</div>`;
    }

    return `
      <tr class="${item.done ? 'done' : ''}" data-id="${item.id}">
        <td class="check-cell">
          <input type="checkbox" ${item.done ? 'checked' : ''} onchange="toggleDone('${item.id}')" />
        </td>
        <td>
          <div class="task-cell">
            <span class="task-text">${escapeHtml(item.task)}</span>
            ${item.notes ? `<span class="task-notes">${escapeHtml(item.notes)}</span>` : ''}
            ${subtasksHtml}
          </div>
        </td>
        <td><span class="priority-badge ${item.priority}">${priorityLabel}</span></td>
        <td>${deadlineStr}</td>
        <td>${item.tag ? `<span class="tag-badge">${escapeHtml(item.tag)}</span>` : '—'}</td>
        <td>
          <div class="row-actions">
            <button class="btn btn-sm btn-secondary" onclick="openRowForm(getCurrentList().find(x=>x.id==='${item.id}'))">تعديل</button>
            <button class="btn btn-sm btn-danger" onclick="deleteRow('${item.id}')">حذف</button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ===================== AI ASSISTANT =====================
function bindAIEvents() {
  document.getElementById('btn-ai-send').addEventListener('click', sendAIMessage);
  document.getElementById('ai-input').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendAIMessage();
    }
  });
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.getElementById('ai-input').value = chip.dataset.prompt;
      sendAIMessage();
    });
  });
}

function sendAIMessage() {
  const input = document.getElementById('ai-input');
  const text = input.value.trim();
  if (!text) return;

  appendMessage('user', text);
  input.value = '';
  input.disabled = true;

  // Simulate thinking
  setTimeout(() => {
    const plan = generateSmartPlan(text);
    appendMessage('bot', plan.html, plan.items);
    input.disabled = false;
    input.focus();
  }, 600 + Math.random() * 400);
}

function appendMessage(role, content, planItems = null) {
  const chat = document.getElementById('ai-chat');
  const div = document.createElement('div');
  div.className = `ai-message ${role}`;

  const avatar = role === 'user' ? '👤' : '🤖';
  let bubbleContent = content;

  if (planItems && planItems.length) {
    bubbleContent += `<button class="btn-use-plan" onclick="applyPlanToTable(this)">📥 نقل إلى الجدول الحالي</button>`;
    div.dataset.plan = JSON.stringify(planItems);
  }

  div.innerHTML = `
    <div class="msg-avatar">${avatar}</div>
    <div class="msg-bubble">${bubbleContent}</div>
  `;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

function applyPlanToTable(btn) {
  const msg = btn.closest('.ai-message');
  const items = JSON.parse(msg.dataset.plan || '[]');
  if (!items.length) return;

  // Decide target table based on keywords or current
  let target = state.currentTable;
  if (state.currentSection !== 'table') {
    // Heuristic
    const sample = items[0]?.task?.toLowerCase() || '';
    if (sample.includes('تسوق') || sample.includes('منزل') || sample.includes('عائلة')) target = 'family';
    else if (sample.includes('عادة') || sample.includes('روتين') || sample.includes('صحة')) target = 'habits';
    else if (sample.includes('دراسة') || sample.includes('امتحان') || sample.includes('مراجعة')) target = 'academic';
    else target = 'custom';
  }

  items.forEach(it => {
    state.data[target].unshift({
      id: generateId(),
      task: it.task,
      priority: it.priority || 'medium',
      deadline: it.deadline || null,
      tag: it.tag || null,
      notes: it.notes || null,
      subtasks: (it.subtasks || []).map(t => ({ id: generateId(), text: t, done: false })),
      done: false,
      createdAt: new Date().toISOString()
    });
  });

  saveToStorage();
  updateStats();
  showToast(`تم نقل ${items.length} عنصر إلى ${getTableName(target)}`);
  navigateTo(target);
}

function getTableName(key) {
  return { academic: 'الجدول الدراسي', family: 'قائمة العائلة', habits: 'متتبع العادات', custom: 'الجدول المخصص' }[key] || key;
}

/**
 * Rule-based smart plan generator (no external API needed)
 */
function generateSmartPlan(prompt) {
  const p = prompt.toLowerCase();
  let items = [];
  let html = '';

  // ---- Exam / Study plan ----
  if (p.includes('مراجعة') || p.includes('امتحان') || p.includes('دراسة') || p.includes('خطة') && (p.includes('يوم') || p.includes('أيام'))) {
    const daysMatch = p.match(/(\d+)\s*يوم/);
    const days = daysMatch ? Math.min(parseInt(daysMatch[1]), 14) : 5;
    const subject = extractSubject(p) || 'المادة';

    html = `<strong>📅 خطة مراجعة ${days} أيام لـ ${subject}</strong><br><br>`;
    const topics = [
      'مراجعة المفاهيم الأساسية',
      'حل تمارين الفصل الأول',
      'مراجعة الفصل الثاني + ملخص',
      'حل نماذج امتحانات سابقة',
      'مراجعة شاملة + نقاط ضعف',
      'اختبار ذاتي + تصحيح',
      'مراجعة سريعة نهائية'
    ];

    for (let i = 0; i < days; i++) {
      const topic = topics[i % topics.length];
      const priority = i < 2 ? 'high' : (i < days - 1 ? 'medium' : 'high');
      const deadline = addDays(i + 1);
      items.push({
        task: `اليوم ${i + 1}: ${topic}`,
        priority,
        deadline,
        tag: subject,
        notes: `خصص 2-3 ساعات مركزة`,
        subtasks: ['قراءة', 'تلخيص', 'تمارين']
      });
      html += `<div class="plan-item">📌 <strong>اليوم ${i + 1}</strong> — ${topic} <span class="priority-badge ${priority}" style="font-size:0.7rem">${priority === 'high' ? 'عالية' : 'متوسطة'}</span></div>`;
    }
    html += `<br><em>نصيحة: استخدم تقنية بومودورو (25 دقيقة تركيز + 5 راحة).</em>`;
  }
  // ---- Grocery / Shopping ----
  else if (p.includes('تسوق') || p.includes('قائمة') && (p.includes('شراء') || p.includes('بقالة') || p.includes('سوبر'))) {
    html = `<strong>🛒 قائمة تسوق أسبوعية مقترحة</strong><br><br>`;
    const categories = [
      { tag: 'خضروات', items: ['طماطم', 'خيار', 'بصل', 'بطاطس', 'خس', 'جزر'] },
      { tag: 'فواكه', items: ['تفاح', 'موز', 'برتقال', 'فراولة'] },
      { tag: 'ألبان', items: ['حليب', 'زبادي', 'جبنة'] },
      { tag: 'بروتين', items: ['دجاج', 'بيض', 'لحم مفروم'] },
      { tag: 'أساسيات', items: ['أرز', 'معكرونة', 'زيت', 'سكر', 'شاي'] }
    ];
    categories.forEach(cat => {
      cat.items.forEach(it => {
        items.push({ task: it, priority: 'medium', tag: cat.tag });
        html += `<div class="plan-item">• ${it} <span class="tag-badge">${cat.tag}</span></div>`;
      });
    });
  }
  // ---- Daily routine / Habits ----
  else if (p.includes('روتين') || p.includes('عادة') || p.includes('يومي') || p.includes('صحي')) {
    html = `<strong>🌅 روتين يومي صحي مقترح</strong><br><br>`;
    const habits = [
      { task: 'شرب كوب ماء فور الاستيقاظ', priority: 'high', tag: 'صحة' },
      { task: 'تمارين صباحية أو مشي 20 دقيقة', priority: 'high', tag: 'رياضة' },
      { task: 'إفطار متوازن', priority: 'medium', tag: 'تغذية' },
      { task: 'مراجعة أهداف اليوم (5 دقائق)', priority: 'medium', tag: 'إنتاجية' },
      { task: 'قراءة 15-20 صفحة', priority: 'medium', tag: 'تعلم' },
      { task: 'شرب 8 أكواب ماء خلال اليوم', priority: 'high', tag: 'صحة' },
      { task: 'مراجعة المساء + شكر 3 أشياء', priority: 'low', tag: 'ذهني' },
      { task: 'النوم قبل 11 مساءً', priority: 'high', tag: 'نوم' }
    ];
    habits.forEach(h => {
      items.push(h);
      html += `<div class="plan-item">✅ ${h.task} <span class="tag-badge">${h.tag}</span></div>`;
    });
  }
  // ---- Weekly study schedule ----
  else if (p.includes('أسبوعي') || p.includes('جدول') && p.includes('دراس')) {
    html = `<strong>📆 جدول دراسي أسبوعي</strong><br><br>`;
    const days = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
    const subjects = ['رياضيات', 'فيزياء', 'لغة عربية', 'إنجليزي', 'كيمياء', 'مراجعة عامة', 'راحة / هواية'];
    days.forEach((d, i) => {
      items.push({
        task: `${d}: ${subjects[i]}`,
        priority: i === 6 ? 'low' : 'medium',
        tag: 'جدول أسبوعي',
        notes: '2-3 ساعات'
      });
      html += `<div class="plan-item">📅 <strong>${d}</strong> — ${subjects[i]}</div>`;
    });
  }
  // ---- Default / General ----
  else {
    html = `<strong>✨ خطة عامة بناءً على طلبك</strong><br><br>`;
    html += `لقد فهمت طلبك: "<em>${escapeHtml(prompt)}</em>"<br><br>`;
    html += `إليك قائمة مهام مقترحة يمكنك تخصيصها:<br>`;
    const generic = [
      { task: 'تحديد الأهداف الرئيسية', priority: 'high', tag: 'تخطيط' },
      { task: 'تقسيم المهام إلى خطوات صغيرة', priority: 'high', tag: 'تخطيط' },
      { task: 'تحديد مواعيد نهائية واقعية', priority: 'medium', tag: 'تنظيم' },
      { task: 'مراجعة التقدم يوميًا', priority: 'medium', tag: 'متابعة' },
      { task: 'تعديل الخطة حسب الحاجة', priority: 'low', tag: 'مرونة' }
    ];
    generic.forEach(g => {
      items.push(g);
      html += `<div class="plan-item">• ${g.task}</div>`;
    });
    html += `<br><em>يمكنك تعديل هذه العناصر بعد نقلها إلى الجدول.</em>`;
  }

  return { html, items };
}

function extractSubject(text) {
  const subjects = ['رياضيات', 'فيزياء', 'كيمياء', 'أحياء', 'عربي', 'إنجليزي', 'تاريخ', 'جغرافيا', 'فلسفة', 'فرنسي'];
  for (const s of subjects) {
    if (text.includes(s.toLowerCase()) || text.includes(s)) return s;
  }
  // Try English
  const eng = { math: 'رياضيات', physics: 'فيزياء', chemistry: 'كيمياء', biology: 'أحياء', english: 'إنجليزي' };
  for (const [k, v] of Object.entries(eng)) {
    if (text.includes(k)) return v;
  }
  return null;
}

function addDays(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

// ===================== EXPORT =====================
function bindExportEvents() {
  document.getElementById('btn-export-pdf').addEventListener('click', exportPDF);
  document.getElementById('btn-export-image').addEventListener('click', exportImage);
  document.getElementById('btn-share-link').addEventListener('click', createShareLink);
  document.getElementById('btn-export-json').addEventListener('click', exportJSON);
  document.getElementById('btn-import-json').addEventListener('click', () => {
    document.getElementById('import-file').click();
  });
  document.getElementById('import-file').addEventListener('change', importJSON);
}

async function exportPDF() {
  // Ensure we are on a table view
  if (state.currentSection !== 'table') {
    showToast('انتقل أولاً إلى أحد الجداول ثم صدّر');
    navigateTo('academic');
    return;
  }

  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(26, 54, 93);
  const title = document.getElementById('table-title').textContent.replace(/[^\w\s\u0600-\u06FF]/g, '').trim() || 'EST Smart Planner';
  doc.text('EST Smart Planner', 105, 20, { align: 'center' });

  doc.setFontSize(12);
  doc.setTextColor(49, 151, 149);
  doc.text(getTableName(state.currentTable), 105, 28, { align: 'center' });

  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(new Date().toLocaleDateString('ar-EG'), 105, 35, { align: 'center' });

  // Table data
  const list = getCurrentList().filter(x => {
    // Apply same filters roughly
    if (state.filters.status === 'done' && !x.done) return false;
    if (state.filters.status === 'pending' && x.done) return false;
    return true;
  });

  let y = 45;
  doc.setFontSize(9);
  doc.setTextColor(0);

  // Header
  doc.setFillColor(26, 54, 93);
  doc.rect(14, y - 5, 182, 8, 'F');
  doc.setTextColor(255);
  doc.text('Task', 20, y);
  doc.text('Priority', 110, y);
  doc.text('Deadline', 140, y);
  doc.text('Status', 170, y);
  y += 10;

  doc.setTextColor(30);
  list.forEach((item, idx) => {
    if (y > 270) {
      doc.addPage();
      y = 20;
    }
    const status = item.done ? 'Done' : 'Pending';
    const pri = item.priority;
    // Simple latin for better PDF compatibility
    const taskText = item.task.length > 45 ? item.task.slice(0, 42) + '...' : item.task;
    doc.text(taskText, 20, y);
    doc.text(pri, 110, y);
    doc.text(item.deadline || '-', 140, y);
    doc.text(status, 170, y);
    y += 7;
    if (idx % 2 === 1) {
      doc.setFillColor(247, 250, 252);
      doc.rect(14, y - 11, 182, 7, 'F');
    }
  });

  doc.setFontSize(8);
  doc.setTextColor(150);
  doc.text('Generated by EST Smart Planner & Visual Hub', 105, 290, { align: 'center' });

  doc.save(`EST-Planner-${state.currentTable}-${Date.now()}.pdf`);
  showToast('تم تصدير PDF بنجاح');
}

async function exportImage() {
  if (state.currentSection !== 'table') {
    showToast('انتقل أولاً إلى أحد الجداول');
    navigateTo('academic');
    return;
  }

  const area = document.getElementById('table-capture-area');
  try {
    const canvas = await html2canvas(area, {
      scale: 2,
      backgroundColor: '#ffffff',
      useCORS: true
    });
    const link = document.createElement('a');
    link.download = `EST-Planner-${state.currentTable}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    showToast('تم حفظ الصورة');
  } catch (err) {
    console.error(err);
    showToast('حدث خطأ أثناء التقاط الصورة');
  }
}

function createShareLink() {
  // Simulated shareable link (client-side only)
  const payload = {
    table: state.currentTable,
    data: getCurrentList(),
    generated: new Date().toISOString()
  };
  const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
  const fakeLink = `${location.origin}${location.pathname}?share=${encoded.slice(0, 32)}...`;

  const result = document.getElementById('share-result');
  result.innerHTML = `
    <strong>رابط المشاركة (محاكي):</strong><br>
    <code style="font-size:0.75rem">${fakeLink}</code><br><br>
    <small>ملاحظة: هذا تطبيق محلي بالكامل. للمشاركة الحقيقية انسخ البيانات عبر تصدير JSON.</small>
  `;
  result.classList.remove('hidden');

  // Also copy a summary
  navigator.clipboard?.writeText(JSON.stringify(payload, null, 2)).then(() => {
    showToast('تم نسخ بيانات القائمة إلى الحافظة');
  }).catch(() => {});
}

function exportJSON() {
  const blob = new Blob([JSON.stringify(state.data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `est-planner-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('تم تصدير النسخة الاحتياطية');
}

function importJSON(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    try {
      const data = JSON.parse(ev.target.result);
      if (data.academic || data.family || data.habits || data.custom) {
        state.data = { ...state.data, ...data };
        saveToStorage();
        updateStats();
        renderTable();
        showToast('تم استيراد البيانات بنجاح');
      } else {
        showToast('ملف غير صالح');
      }
    } catch {
      showToast('خطأ في قراءة الملف');
    }
  };
  reader.readAsText(file);
  e.target.value = '';
}

// ===================== STATS =====================
function updateStats() {
  document.getElementById('stat-academic').textContent = `${state.data.academic.length} مهمة`;
  document.getElementById('stat-family').textContent = `${state.data.family.length} مهمة`;
  document.getElementById('stat-habits').textContent = `${state.data.habits.length} عادة`;
  document.getElementById('stat-custom').textContent = `${state.data.custom.length} صف`;
}

// ===================== UI HELPERS =====================
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), 2800);
}

// Theme toggle (simple)
document.getElementById('btn-theme')?.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  // Optional dark mode could be expanded
  showToast('وضع العرض تبدّل (تجريبي)');
});

// ===================== PWA =====================
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
}

let deferredPrompt;
function setupInstallPrompt() {
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    const btn = document.getElementById('btn-install');
    btn.classList.remove('hidden');
    btn.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') showToast('تم تثبيت التطبيق!');
      deferredPrompt = null;
      btn.classList.add('hidden');
    });
  });
}

// Make some functions global for inline handlers
window.toggleDone = toggleDone;
window.toggleSubtask = toggleSubtask;
window.deleteRow = deleteRow;
window.openRowForm = openRowForm;
window.getCurrentList = getCurrentList;
window.applyPlanToTable = applyPlanToTable;
