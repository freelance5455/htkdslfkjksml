// js/downloads.js
// Limite diário de downloads (5 por utilizador/dia) + download real do ficheiro.
// v2 — funciona no navegador E dentro do APK (Capacitor/WebView), onde o
// download por blob (<a download>) não faz nada.

export const LIMITE_DOWNLOADS_DIARIO = 5;

function hojeStr() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function nomeFicheiroSeguro(titulo) {
  const base = (titulo || 'livro').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9 _-]/g, '').trim();
  return (base || 'livro') + '.pdf';
}

function isNativo() {
  try { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); }
  catch (e) { return false; }
}

// Cloudinary: fl_attachment força o "guardar" em vez de abrir no ecrã
function urlComAttachment(url, nome) {
  if (!/res\.cloudinary\.com/.test(url) || url.indexOf('/upload/') === -1) return url;
  if (url.indexOf('fl_attachment') !== -1) return url;
  const nomeSemExt = nome.replace(/\.pdf$/i, '').replace(/\s+/g, '_');
  return url.replace('/upload/', '/upload/fl_attachment:' + encodeURIComponent(nomeSemExt) + '/');
}

// Abre o URL fora do WebView (navegador do sistema), que trata do download
async function abrirNoSistema(url) {
  const cap = window.Capacitor;
  try {
    const Browser = cap && cap.Plugins && cap.Plugins.Browser;
    if (Browser && Browser.open) { await Browser.open({ url }); return true; }
  } catch (e) { /* tenta o próximo */ }
  try {
    const App = cap && cap.Plugins && cap.Plugins.App;
    if (App && App.openUrl) { await App.openUrl({ url }); return true; }
  } catch (e) { /* tenta o próximo */ }
  try {
    const w = window.open(url, '_system');
    if (w !== null && w !== undefined) return true;
  } catch (e) { /* tenta o próximo */ }
  // Último recurso: o Capacitor abre hosts externos no navegador do sistema
  window.location.href = url;
  return true;
}

async function descarregarPorBlob(url, nome) {
  const resp = await fetch(url, { mode: 'cors' });
  if (!resp.ok) throw new Error('Falha ao obter o ficheiro (' + resp.status + ')');
  const blob = await resp.blob();
  const blobUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = nome;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(blobUrl), 8000);
}

export async function descarregarLivro({ db, fns, uid, book, showToast, onStart, onEnd }) {
  const { doc, getDoc, setDoc } = fns;

  if (!book || !book.mediaUrl) {
    showToast('Este livro ainda não tem ficheiro disponível para download.', 'error');
    return false;
  }

  try {
    const ref = doc(db, 'downloads', uid);
    const snap = await getDoc(ref);
    const hoje = hojeStr();
    let count = 0;
    if (snap.exists()) {
      const data = snap.data();
      count = data.date === hoje ? (data.count || 0) : 0;
    }

    if (count >= LIMITE_DOWNLOADS_DIARIO) {
      showToast(`Atingiste o limite de ${LIMITE_DOWNLOADS_DIARIO} downloads hoje. Volta amanhã.`, 'error');
      return false;
    }

    if (onStart) onStart();

    const nome = nomeFicheiroSeguro(book.titulo);
    const urlDownload = urlComAttachment(book.mediaUrl, nome);

    if (isNativo()) {
      // APK/WebView: o download por blob não funciona -> navegador do sistema
      await abrirNoSistema(urlDownload);
    } else {
      try {
        await descarregarPorBlob(book.mediaUrl, nome);
      } catch (blobErr) {
        // CORS/rede: cai para o link direto com fl_attachment
        console.warn('Download por blob falhou, a usar link direto:', blobErr);
        await abrirNoSistema(urlDownload);
      }
    }

    // Só regista a quota depois de o download ter arrancado
    await setDoc(ref, { uid, date: hoje, count: count + 1 });
    showToast(`Download iniciado! (${count + 1}/${LIMITE_DOWNLOADS_DIARIO} hoje)`);
    return true;
  } catch (e) {
    console.error('Erro ao descarregar livro:', e);
    showToast('Não foi possível descarregar o livro agora. Tenta novamente.', 'error');
    return false;
  } finally {
    if (onEnd) onEnd();
  }
}
