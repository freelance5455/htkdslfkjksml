/* =========================================================
   MUEEN | HTML to APK Builder compatibility layer
   يحاول استخدام AndroidAPI عند توفره، مع بقاء MueenNative
   هو المسار الأساسي لنسخة Android الأصلية.
========================================================= */
"use strict";

(function () {
    const api = window.AndroidAPI || window.androidAPI || null;

    function find(names) {
        if (!api) return null;
        for (const name of names) {
            if (typeof api[name] === "function") return api[name].bind(api);
        }
        return null;
    }

    function call(names, ...args) {
        const fn = find(names);
        if (!fn) return null;
        try { return fn(...args); } catch (e) {
            console.warn("MUEEN AndroidAPI:", e);
            return null;
        }
    }

    window.MueenBuilderBridge = {
        available: !!api,

        scheduleNotification(title, body, id, whenMs) {
            return call(
                ["scheduleNotification", "scheduleNotificationAt", "notifyAt", "notification"],
                String(title || "مُعين"),
                String(body || ""),
                String(id || Date.now()),
                Number(whenMs || Date.now())
            );
        },

        cancelNotification(id) {
            return call(
                ["cancelScheduledNotification", "cancelNotification", "cancelNotificationById"],
                String(id || "")
            );
        },

        cancelAllNotifications() {
            return call(["cancelAllScheduledNotifications", "cancelAllNotifications"]);
        },

        requestNotificationPermission() {
            return call(["requestNotificationPermission", "requestNotificationsPermission"]);
        },

        saveFileBase64(base64, filename, mime) {
            return call(
                ["saveFile", "saveFileBase64", "writeFile"],
                String(base64 || ""),
                String(filename || "MUEEN-file"),
                String(mime || "application/octet-stream")
            );
        },

        vibrate(ms = 80) {
            return call(["vibrate", "vibration"], Number(ms));
        }
    };
})();
