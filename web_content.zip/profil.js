"use strict";

function bacPage() {
  let e = exam(D),
    active = activeCourses(),
    master = active.filter(mastered).length;
  let rows = g => BAC.map((b, i) => {
    if (b[2] !== g) return "";
    let x = D.bac[i];
    return '<div class="examline"><label for="b' + i + '">' + esc(b[0]) + '<small>Coefficient ' + b[1] + '</small></label><input id="b' + i + '" aria-label="' + esc(b[0]) + ' sur 20" type="number" min="0" max="20" step="any" value="' + (x ? x.v : "") + '" placeholder="/20" onchange="setBac(' + i + ')"><select id="k' + i + '" aria-label="Statut de ' + esc(b[0]) + '" onchange="setBac(' + i + ')">' + option(0, "Estimée", x && x.known ? 1 : 0) + option(1, "Connue", x && x.known ? 1 : 0) + '</select></div>';
  }).join("");
  return heading("Session 2027 · STI2D", "Mon bac") + '<div class="grid"><div class="cards">' + box("Simulateur de points", '<p>Candidat scolaire, enseignements obligatoires, hors options. Saisis les notes connues ou tes hypothèses. Les champs vides restent exclus.</p><div id="bacTotals">' + bacTotals(e) + '</div>') + ["Contrôle continu", "Épreuves anticipées", "Épreuves terminales"].map((g, i) => '<details class="card" ' + (i === 0 ? 'open' : '') + '><summary>' + g + ' · ' + [40, 12, 48][i] + ' coefficients</summary>' + rows(g) + '</details>').join("") + '</div><div class="cards">' + box("Objectif de mention", choose("Seuil visé", "mention", [[10, "Admission"], [12, "Assez bien"], [14, "Bien"], [16, "Très bien"]].map(([v, n]) => option(v, n, D.settings.mention)).join("")).replace('<select ', '<select onchange="D.settings.mention=+this.value;save();render()" ') + '<p>' + master + ' chapitre(s) maîtrisé(s) sur ' + active.length + '</p>' + bar(master * 100 / (active.length || 1)) + '<p class="small">À revoir : ' + esc(weak().map(c => c.title).join(", ") || "aucun chapitre identifié") + '</p>') + paperLinks() + box("Entraînements chronométrés", '<p>Deux études courtes, 10 minutes chacune. Cinq questions, 4 points par réponse juste. Le corrigé apparaît après chaque réponse.</p>' + MOCKS.map(m => '<div class="entry">' + btn(esc(m.title) + " →", "startQuiz('" + m.id + "',true)", "link") + '</div>').join("") + '<h3>Mes résultats</h3>' + (D.sessions.filter(s => s.mock).slice(-5).reverse().map(s => '<p>' + esc(s.title) + ' · ' + s.right * 4 + '/20 · ' + s.date + '</p>').join("") || '<p>Aucun sujet blanc réalisé.</p>')) + box("Grand oral et pratique ITEC", '<details><summary>Construire un argument à l’oral</summary><p>Pars d’une question liée à ton projet, par exemple « Comment alléger le support sans dépasser 2 mm de flèche ? ». Présente le besoin et les critères. Compare deux solutions, donne une mesure issue de ton projet, puis explique une limite. Entraîne-toi à répondre à « Quelle hypothèse changerait ton choix ? ».</p><p>Répète une présentation de 10 minutes, puis fais expliquer tes choix pendant 10 minutes d’échange.</p></details><details><summary>Préparer une manipulation en ITEC</summary><p>Repère la grandeur à vérifier et le seuil du cahier des charges. En CAO, identifie les appuis et le chargement. Note la flèche simulée, réalise la mesure dans les mêmes conditions, puis calcule l’écart absolu. Si 1,8 mm sont mesurés pour 1,5 mm simulés, l’écart est de 0,3 mm. Face à une limite de 2 mm, discute la marge de 0,2 mm avec l’incertitude de mesure.</p></details>') + '</div></div>';
}
function bacTotals(e) {
  return '<div class="row"><div><strong>' + fmt(e.known) + ' pts connus</strong><small> · coef. ' + e.kw + '/100</small></div><div><strong>' + fmt(e.pts) + ' pts avec estimations</strong></div></div><p>' + (e.w === 100 ? "Moyenne estimée du bac" : "Moyenne partielle sur les coefficients renseignés") + ' · <b>' + fmt(e.w ? e.pts / e.w : null) + ' / 20</b> · coef. ' + e.w + '/100</p>' + [10, 12, 14, 16].map((v, i) => '<div class="entry"><b>' + ["Admission", "Assez bien", "Bien", "Très bien"][i] + ' · ' + v * 100 + ' points</b><br><small>Restent ' + fmt(Math.max(0, v * 100 - e.known)) + ' pts après notes connues · ' + fmt(Math.max(0, v * 100 - e.pts)) + ' pts après estimations.</small></div>').join("");
}
function setBac(i) {
  let el = $("#b" + i),
    raw = el.value;
  if (!el.validity.valid) {
    notice("Saisis une note entre 0 et 20.");
    return;
  }
  if (raw === "") delete D.bac[i];else D.bac[i] = {
    v: +raw,
    known: $("#k" + i).value === "1"
  };
  if (save()) $("#bacTotals").innerHTML = bacTotals(exam(D));else render();
}
function profile() {
  let p = D.settings,
    s = streak(D.sessions),
    target = [1, 3, 7, 14, 30, 100].find(x => x > s.current),
    a = stats(),
    days = [...new Set(D.answers.map(x => x.date))],
    xp = D.answers.concat(D.sessions).reduce((n, v) => n + v.xp, 0);
  return heading("Réglages et progression", "Mon profil") + '<div class="grid"><div class="cards">' + box("Objectifs et préférences", '<form onsubmit="savePrefs(event)"><div class="two">' + field("Objectif de moyenne / 20", "goal", p.goal, "number", markAttr) + choose("Objectif quotidien", "daily", [5, 10, 15, 20].map(i => option(i, i + " min", p.daily)).join("")) + '</div><div class="two">' + choose("Thème", "theme", ["sombre", "clair"].map(v => option(v, v === "clair" ? "Clair" : "Sombre", p.theme)).join("")) + choose("Difficulté préférée", "level", levels.map((n, i) => option(i, n, p.level)).join("")) + '</div>' + field("Mon objectif EPS", "eps", p.eps, "text", 'maxlength="350" placeholder="Ex. gagner 10 s au 800 m"') + '<button class="primary">Enregistrer mes préférences</button></form>') + box("Configuration du bulletin", btn("Matières et coefficients", "subjectsDialog()") + btn("Regroupements et trimestres", "configure()")) + box("Mes données", '<p>Les données restent sur cet appareil. Le navigateur ou la désinstallation de l’APK peuvent effacer le stockage. Garde un export avant une mise à jour.</p><p class="small">' + fmt(new Blob([serial || JSON.stringify(D)]).size) + ' octets · format V3</p><div class="inline">' + btn("Exporter en JSON", "exportData()") + btn("Importer un JSON", "importData()") + '</div>' + localLegacy() + btn("Réinitialiser mes données", "resetAll()", "link danger")) + '</div><div class="cards">' + box("Mes flammes", '<div class="row"><strong>' + s.current + ' jour(s) de suite</strong><span class="tag">Record · ' + s.record + '</span></div><p>' + (target ? "Prochaine récompense à " + target + " jour(s)." : "Tous les paliers sont atteints.") + '</p>' + bar(target ? 100 * s.current / target : 100) + '<p class="small">1 j · première flamme. 3 j · +30 XP. 7 et 14 j · badges. 30 j · +100 XP. 100 j · badge exceptionnel.</p><p>' + [1, 7, 14, 30, 100].filter(x => s.record >= x).map(x => '<span class="tag">' + x + ' j ✓</span> ').join("") + '</p><details><summary>Calendrier des validations</summary>' + calendar(s.days) + '</details><p class="small">Une séance complète de cinq réponses valide la journée. Après une pause, les acquis restent disponibles.</p>') + box("Mon activité", (D.legacy ? '<p class="small">Archive V1 · ' + D.legacy.correct + ' réussites et ' + D.legacy.days.length + ' jours actifs avant migration.</p>' : '') + '<p>' + xp + ' XP · niveau ' + (1 + Math.floor(Math.sqrt(xp / 100))) + '</p><p>' + a.n + ' question(s) · ' + fmt(a.n ? a.ok / a.n * 100 : null) + ' % de réussite</p><p>' + fmt(a.sec / 60) + ' minutes de réponse active · ' + days.length + ' jour(s) actif(s)</p><details><summary>Résultats par matière et chapitre</summary>' + D.subjects.filter(s => COURSES.some(c => c.sub === s.id)).map(s => {
    let list = COURSES.filter(c => c.sub === s.id),
      n = list.reduce((v, c) => v + stats(c.id).n, 0),
      ok = list.reduce((v, c) => v + stats(c.id).ok, 0);
    return '<div class="entry"><b>' + esc(s.name) + ' · ' + fmt(n ? 100 * ok / n : null) + ' %</b>' + list.map(c => {
      let a = stats(c.id);
      return '<p class="small">' + esc(c.title) + ' · ' + a.ok + '/' + a.n + ' réponses justes</p>';
    }).join("") + '</div>';
  }).join("") + '</details>') + '</div></div>';
}
function calendar(days) {
  let months = [...new Set(days.concat(day()).map(d => d.slice(0, 7)))].sort().reverse();
  return months.map(m => {
    let first = m + "-01",
      dt = new Date(first + "T12:00:00"),
      last = new Date(dt.getFullYear(), dt.getMonth() + 1, 0).getDate();
    return '<p>' + dt.toLocaleDateString("fr-FR", {
      month: "long",
      year: "numeric"
    }) + '</p><div class="week">' + ["L", "M", "M", "J", "V", "S", "D"].map(x => '<span>' + x + '</span>').join("") + '<span></span>'.repeat((dt.getDay() + 6) % 7) + Array.from({
      length: last
    }, (_, i) => {
      let d = shift(first, i);
      return '<span><b class="' + (days.includes(d) ? "done " : "") + (d === day() ? "today" : "") + '">' + (i + 1) + '</b></span>';
    }).join("") + '</div>';
  }).join("");
}
function savePrefs(event) {
  event.preventDefault();
  let e = event.target.elements;
  Object.assign(D.settings, {
    goal: +e.goal.value,
    daily: +e.daily.value,
    theme: e.theme.value,
    level: +e.level.value,
    eps: e.eps.value.trim()
  });
  commit();
}
function configure() {
  let p = D.settings;
  dlg("Règles du bulletin", '<form>' + check("Regrouper 2I2D et ITEC en une matière", "group", p.group) + field("Coefficient du groupe dans le bulletin", "groupCoef", p.groupCoef, "number", weightAttr) + '<p class="small">Les deux moyennes sont pondérées par leurs coefficients de matière. Le groupe compte une fois dans le bulletin.</p>' + check("Pondérer les deux moyennes de sous-catégorie en spécialité", "split", p.split) + '<div class="two">' + field("Poids physique-chimie", "pcWeight", p.pcWeight, "number", weightAttr) + field("Poids maths spé", "msWeight", p.msWeight, "number", weightAttr) + '</div><p class="small">Option désactivée : toutes les évaluations de la spécialité partagent une seule moyenne pondérée.</p>' + p.periods.map((a, i) => '<b>Trimestre ' + (i + 1) + '</b><div class="two">' + field("Début", "s" + i, a[0], "date", "required") + field("Fin", "e" + i, a[1], "date", "required") + '</div>').join("") + '<p class="small">Ces dates préremplissent le trimestre des nouvelles notes. Chaque note conserve le trimestre que tu lui as attribué.</p><button class="primary">Enregistrer</button></form>', f => {
    let e = f.elements,
      periods = [0, 1, 2].map(i => [e["s" + i].value, e["e" + i].value]);
    if (periods.some((a, i) => a[0] > a[1] || i && a[0] <= periods[i - 1][1])) {
      notice("Les trimestres doivent se suivre sans se chevaucher.");
      return;
    }
    Object.assign(p, {
      group: e.group.checked,
      groupCoef: +e.groupCoef.value,
      split: e.split.checked,
      pcWeight: +e.pcWeight.value,
      msWeight: +e.msWeight.value,
      periods
    });
    commit();
  });
}
function exportData() {
  let data = storageIssue && serial ? serial : JSON.stringify(D, null, 2);
  dlg("Exporter mes données", '<p>Télécharge le fichier ou sélectionne le texte pour le copier dans un fichier .json.</p><textarea id="json" aria-label="Sauvegarde JSON" readonly></textarea><div class="inline">' + btn("Télécharger", "downloadJson()", "primary") + btn("Sélectionner le texte", "selectJson()") + '</div>');
  $("#json").value = data;
}
function selectJson() {
  let t = $("#json");
  t.focus();
  t.select();
  t.setSelectionRange(0, t.value.length);
}
function downloadJson() {
  try {
    let url = URL.createObjectURL(new Blob([$("#json").value], {
        type: "application/json"
      })),
      a = document.createElement("a");
    a.href = url;
    a.download = "sti2d-" + day() + ".json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  } catch (e) {
    selectJson();
    notice("Copie le texte sélectionné pour sauvegarder.");
  }
}
function importData() {
  dlg("Restaurer une sauvegarde", '<p>Choisis un export V1 ou V3, ou colle son contenu. La restauration remplace tes données après confirmation.</p><input type="file" id="file" accept=".json,application/json" aria-label="Fichier JSON"><label>Contenu JSON<textarea id="json"></textarea></label>' + btn("Vérifier et restaurer", "restore()", "primary"));
  $("#file").onchange = e => {
    let f = e.target.files[0];
    if (!f) return;
    if (f.size > 8000000) {
      notice("Fichier trop volumineux.");
      return;
    }
    let r = new FileReader();
    r.onload = () => $("#json").value = r.result;
    r.onerror = () => notice("Lecture du fichier impossible.");
    r.readAsText(f);
  };
}
function replaceData(next) {
  try {
    let raw = JSON.stringify(next);
    if (!volatileMode) localStorage.setItem(keyName, raw);
    D = next;
    serial = raw;
    if (!volatileMode) storageIssue = "";
    T = term(D);
    quiz = null;
    courseId = "";
    filterSub = "";
    query = "";
    closeDlg();
    render();
    return true;
  } catch (e) {
    notice("Stockage inaccessible. Les données actuelles sont conservées.");
    return false;
  }
}
function restore() {
  let raw = $("#json").value;
  let old = oldData(raw);
  if (old) {
    legacyDialog(old);
    return;
  }
  if (!validSafe(raw)) {
    notice("Import refusé : structure, version, date ou valeur invalide.");
    return;
  }
  let next = JSON.parse(raw);
  confirmAction("Restaurer " + next.grades.length + " note(s) et " + next.sessions.length + " séance(s) à la place des données actuelles ?", () => {
    if (replaceData(next)) notice("Sauvegarde restaurée.");
  });
}
function resetAll() {
  confirmAction("Effacer définitivement toutes les notes, révisions et réglages de cet appareil ?", () => {
    if (replaceData(fresh())) notice("Données réinitialisées.");
  });
}
