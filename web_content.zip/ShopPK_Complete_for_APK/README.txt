ShopPK Complete

This is a single-file mobile shopping app prototype ready for HTML-to-APK conversion.
Includes customer login/signup demo, profile/address, product search/categories, wishlist, cart, COD checkout, orders/status, and seller panel.

Important: login, products and orders are stored locally on the phone. A real online marketplace needs a backend/database and secure authentication; this package does not contain real payment processing.

For HTML & ZIP to APK: choose ZIP File to APK and select this ZIP. Keep the ZIP under the free-plan size limit.
