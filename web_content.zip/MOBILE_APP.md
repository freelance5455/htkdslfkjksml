# موبایل اپ (PWA)

د Ahmadi WiFi ISP Manager لپاره د موبایل اپ. د Android او iPhone دواړو کې کار کوي، د Play Store اړتیا نشته.

## نصب
1. پروژه لکه څنګه چې په README.md کې ده، Hosting ته پورته کړئ (HTTPS اړین دی).
2. موبایل کې دا آدرس پرانیزئ: `https://YOUR-DOMAIN/app/`
3. Android Chrome: ⋮ ← «Install app / Add to Home screen».
   iPhone Safari: Share ← «Add to Home Screen».
4. په همدې ایمیل/پاسورډ ننوځئ چې `scripts/create_admin.php` سره مو جوړ کړی.

## د اپ ځانګړتیاوې
ډشبورډ، د مشتریانو لټون/فلټر/ثبت، بندول/فعالول، پکیجونه، تادیې، او «تادیه + نوی کول» (پای نېټه د پکیج ورځو په اندازه اوږدېږي).

## مهم
- دا اپ یوازې د ډیټابیس ریکارډ بدلوي. په MikroTik کې یوزر نه جوړوي، نه بندوي (لکه README کې چې ویل شوي).
- API: `public/api/index.php` (JSON، session + CSRF).
- د پیسو نښه په `public/app/app.js` کې `CUR` ده.
- د ریښتیني APK لپاره: همدا `/app/` URL په PWABuilder یا Capacitor کې واچوئ.
