package com.monitor.simulador;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowManager;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0000CC);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new GalleryBridge(), "AndroidGallery");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class GalleryBridge {
        @JavascriptInterface
        public void confirmSaveGallery() {
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                .setTitle("Monitor")
                .setMessage("Salvar 30 cópias de galeria.png na galeria do dispositivo, na pasta Imagens/Monitor?")
                .setNegativeButton("Cancelar", (dialog, which) -> {})
                .setPositiveButton("Salvar 30 imagens", (dialog, which) -> saveThirtyImages())
                .show());
        }
    }

    private void saveThirtyImages() {
        int saved = 0;
        try {
            for (int i = 1; i <= 30; i++) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME,
                    String.format("galeria_%02d.png", i));
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/Monitor");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri uri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) continue;

                try (InputStream in = getAssets().open("galeria.png");
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Não foi possível gravar a imagem");
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                }

                ContentValues ready = new ContentValues();
                ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, ready, null, null);
                saved++;
            }
            final int total = saved;
            new AlertDialog.Builder(this)
                .setTitle("Monitor")
                .setMessage(total + " imagens salvas em Imagens/Monitor.")
                .setPositiveButton("OK", null)
                .show();
        } catch (Exception e) {
            new AlertDialog.Builder(this)
                .setTitle("Erro ao salvar")
                .setMessage("Não foi possível concluir: " + e.getMessage())
                .setPositiveButton("OK", null)
                .show();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
