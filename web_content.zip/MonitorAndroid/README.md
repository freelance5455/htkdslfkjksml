# Monitor — projeto Android

Projeto Android que empacota o HTML e as duas imagens fornecidas. Nome do app: **Monitor**. Ícone: `monstro.png`.

## Gerar o APK no Android Studio
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle e instale o Android SDK Platform 35, se solicitado.
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK ficará em `app/build/outputs/apk/debug/app-debug.apk`.

O workflow `.github/workflows/build.yml` também compila o APK de depuração no GitHub Actions.

## Observações
- Funciona offline: HTML e imagens são incluídos no APK.
- É uma simulação visual/sonora, não malware real.
- Som e animações são encerrados após 20 segundos.
- Não solicita acesso à internet, arquivos, contatos ou administração do dispositivo.
