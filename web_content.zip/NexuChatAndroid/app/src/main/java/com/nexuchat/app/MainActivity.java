package com.nexuchat.app;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.URLUtil;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Nexu Chat — native Android shell around the app (assets/www/index.html).
 * The page is served from the app's own assets under its real https origin, so CORS, localStorage,
 * WebRTC, WebAuthn and Firebase behave exactly like the website, while the app gets native powers:
 *  - FLAG_SECURE (no screenshots / screen recording / recents preview) on demand via NexuNative.setSecure()
 *  - hardware back button wired to the app's own back handler
 *  - camera / microphone / location / file-picker / downloads
 */
public class MainActivity extends Activity {
    private static final String ORIGIN_HOST = "nexuchat-official.pages.dev";
    private static final String START_URL = "https://" + ORIGIN_HOST + "/index.html";
    private static final int REQ_PERMS = 41, REQ_FILE = 42;

    private WebView web;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> filePathCb;
    private PermissionRequest pendingPerm;
    private GeolocationPermissions.Callback pendingGeo;
    private String pendingGeoOrigin;
    private long lastBack = 0;
    private boolean secureOn = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0F0F14"));
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setBars(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(ORIGIN_HOST)
                .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this) {
                    @Override public WebResourceResponse handle(String path) {
                        if (path == null || path.isEmpty() || path.equals("/")) path = "index.html";
                        return super.handle("www/" + path.replaceFirst("^/", ""));
                    }
                })
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setGeolocationEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " NexuChatApp/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "NexuNative");

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                // Only the app shell itself comes from assets; everything else (API, images, CDN) uses the network.
                if (ORIGIN_HOST.equals(u.getHost())) {
                    String p = u.getPath();
                    if (p == null || p.equals("/") || p.equals("/index.html")) return loader.shouldInterceptRequest(u);
                    return null;
                }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sch = u.getScheme() == null ? "" : u.getScheme();
                if (ORIGIN_HOST.equals(u.getHost())) return false;
                if (sch.equals("http") || sch.equals("https") || sch.equals("tel") || sch.equals("mailto") || sch.equals("sms") || sch.equals("geo") || sch.equals("intent")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> handleWebPermission(req));
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) { cb.invoke(origin, true, false); return; }
                pendingGeo = cb; pendingGeoOrigin = origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERMS + 1);
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                try { startActivityForResult(p.createIntent(), REQ_FILE); }
                catch (Exception e) { filePathCb = null; return false; }
                return true;
            }
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = v; customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                web.setVisibility(View.GONE);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
            @Override public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView); customView = null;
                web.setVisibility(View.VISIBLE);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                if (customCb != null) customCb.onCustomViewHidden();
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                if (url.startsWith("blob:") || url.startsWith("data:")) { Toast.makeText(this, "Download not supported for this link", Toast.LENGTH_SHORT).show(); return; }
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime));
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        });

        if (b != null) web.restoreState(b); else web.loadUrl(START_URL);
    }

    /* ---------- web permission → Android runtime permission ---------- */
    private void handleWebPermission(PermissionRequest req) {
        List<String> need = new ArrayList<>();
        for (String r : req.getResources()) {
            if (r.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.CAMERA);
            if (r.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
        }
        if (need.isEmpty()) { req.grant(req.getResources()); return; }
        pendingPerm = req;
        requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean ok = res.length > 0; for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        if (code == REQ_PERMS && pendingPerm != null) {
            PermissionRequest p = pendingPerm; pendingPerm = null;
            if (ok) p.grant(p.getResources()); else p.deny();
        } else if (code == REQ_PERMS + 1 && pendingGeo != null) {
            pendingGeo.invoke(pendingGeoOrigin, ok, false); pendingGeo = null;
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && filePathCb != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount(); r = new Uri[n];
                    for (int i = 0; i < n; i++) r[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) r = new Uri[]{data.getData()};
            }
            filePathCb.onReceiveValue(r); filePathCb = null;
        } else super.onActivityResult(req, res, data);
    }

    /* ---------- back button: use the app's own back handler; double-tap to exit from the root ---------- */
    private static final String BACK_JS =
        "(function(){try{function sig(){var v=[].slice.call(document.querySelectorAll('.screen:not(.hidden)')).map(function(e){return e.id}).join(',');" +
        "var m=document.querySelectorAll('.modal:not(.hidden)').length;var t=(document.querySelector('#mainApp .tab-pane.active')||{}).id;" +
        "return v+'|'+m+'|'+t+'|'+document.body.children.length}var a=sig();if(typeof handleBackButton==='function')handleBackButton();" +
        "return sig()!==a?'1':'0'}catch(e){return '0'}})()";

    @Override public void onBackPressed() {
        if (customView != null) { web.getWebChromeClient().onHideCustomView(); return; }
        web.evaluateJavascript(BACK_JS, v -> {
            boolean consumed = v != null && v.contains("1");
            if (consumed) { lastBack = 0; return; }
            long now = System.currentTimeMillis();
            if (now - lastBack < 2000) { finish(); }
            else { lastBack = now; Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show(); }
        });
    }

    /* ---------- native bridge ---------- */
    private void setBars(boolean dark) {
        Window w = getWindow();
        int c = dark ? Color.parseColor("#0B0B10") : Color.WHITE;
        w.setStatusBarColor(c); w.setNavigationBarColor(c);
        View d = w.getDecorView(); int f = d.getSystemUiVisibility();
        if (dark) f &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        else f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        d.setSystemUiVisibility(f);
        root.setBackgroundColor(c);
    }

    private class Bridge {
        /** Blocks screenshots, screen recording and the recent-apps thumbnail while true. */
        @JavascriptInterface public void setSecure(final boolean on) {
            runOnUiThread(() -> {
                secureOn = on;
                if (on) getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            });
        }
        @JavascriptInterface public void setBars(final boolean dark) { runOnUiThread(() -> MainActivity.this.setBars(dark)); }
        /** Links this phone's push subscription to the user (OneSignal external id = uid) and asks for notification permission. */
        @JavascriptInterface public void loginPush(final String uid) {
            runOnUiThread(() -> {
                try {
                    com.onesignal.OneSignal.login(uid);
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_PERMS + 2);
                    com.onesignal.OneSignal.getUser().getPushSubscription().optIn();
                } catch (Throwable ignored) {}
            });
        }
        @JavascriptInterface public void logoutPush() {
            runOnUiThread(() -> { try { com.onesignal.OneSignal.logout(); } catch (Throwable ignored) {} });
        }
        @JavascriptInterface public boolean isNative() { return true; }
    }

    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }
    @Override protected void onPause() { super.onPause(); NexuApp.inForeground = false; web.onPause(); }
    @Override protected void onResume() { super.onResume(); NexuApp.inForeground = true; web.onResume(); }
    @Override protected void onDestroy() { if (web != null) { web.destroy(); } super.onDestroy(); }
}
