package com.nexuchat.app;

import android.app.Application;
import com.onesignal.OneSignal;
import com.onesignal.debug.LogLevel;
import com.onesignal.notifications.IDisplayableNotification;
import com.onesignal.notifications.INotificationLifecycleListener;
import com.onesignal.notifications.INotificationWillDisplayEvent;
import org.json.JSONObject;

/** Native push: same OneSignal app as the website, so the existing backend keeps working (it targets external_id = user uid). */
public class NexuApp extends Application {
    public static final String ONESIGNAL_APP_ID = "f2391ce9-decf-4019-80b6-d48aad4a4446";
    public static volatile boolean inForeground = false;

    @Override public void onCreate() {
        super.onCreate();
        OneSignal.getDebug().setLogLevel(LogLevel.NONE);
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);
        // While the app is open the in-app UI already rings / shows these, so don't also pop a system notification.
        OneSignal.getNotifications().addForegroundLifecycleListener(new INotificationLifecycleListener() {
            @Override public void onWillDisplay(INotificationWillDisplayEvent event) {
                try {
                    IDisplayableNotification n = event.getNotification();
                    JSONObject d = n.getAdditionalData();
                    String type = d == null ? "" : d.optString("type", "");
                    if (inForeground && (type.equals("incoming_call") || type.equals("missed_call") || type.equals("ai_reply"))) {
                        event.preventDefault();
                    }
                } catch (Throwable ignored) {}
            }
        });
    }
}
