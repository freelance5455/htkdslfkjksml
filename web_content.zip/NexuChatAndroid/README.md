# Nexu Chat — Native Android project

Android Studio (Hedgehog+/Koala) → **Open** this folder → wait for Gradle sync → **Build ▸ Build APK(s)** (or Run on a phone).
Requires JDK 17 and Android SDK 34. From a terminal: `gradle assembleDebug` (Gradle 8.7+), APK: `app/build/outputs/apk/debug/`.

## What changed vs. the web page
- The app (`app/src/main/assets/www/index.html`) runs inside a native Activity, served under its real origin
  `https://nexuchat-official.pages.dev`, so the backend / Firebase CORS rules keep working.
- **Screenshot & screen-recording block (FLAG_SECURE)** – switched on automatically while:
  a call screen is open, a view-once photo/video is open, or someone else's *locked profile* is open.
  Also hides the app preview in Recent Apps during those moments.
- Hardware back button uses the app's own back handler; from the root screen press back twice to exit.
- Camera / microphone (calls, photos, voice notes), location, file picker, downloads, fullscreen video.
- Status/navigation bar follows Day / Night mode.

## Notes
- Web push (OneSignal web SDK) does not run in a WebView. For background notifications add the OneSignal **Android** SDK
  (or Firebase Cloud Messaging) – the backend can keep sending to the same OneSignal app.
- To update the app UI, replace `app/src/main/assets/www/index.html` and rebuild.
- Replace the launcher icon in `res/drawable/ic_fg.xml` / `ic_bg.xml` with your own logo if you like.
- Before publishing: create a signing key (Build ▸ Generate Signed Bundle / APK).

## Push notifications (native OneSignal)
- Uses the same OneSignal App ID as the website (`f2391ce9-…`), linked by `external_id = user uid`, so your Render backend needs **no change**.
- One-time setup in the OneSignal dashboard: *Settings ▸ Push & In-App ▸ Google Android (FCM)* → upload your Firebase service-account JSON. Without it Android pushes are not delivered.
- Call/AI-reply pushes are not shown as system pop-ups while the app is open (the in-app UI already handles them).
