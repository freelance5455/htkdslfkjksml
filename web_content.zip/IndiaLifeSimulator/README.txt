INDIA LIFE SIMULATOR — ANDROID PROJECT

Contents:
- app/src/main/assets/index.html : offline game
- app/src/main/java/.../MainActivity.java : Android WebView shell
- Gradle Android project files

IMPORTANT:
This is an Android Studio project, not a prebuilt APK. The current build environment does not have the Android SDK/Gradle installed, so a signed APK could not be compiled here.

To build:
1. Install Android Studio (latest stable) on a computer.
2. Open this folder as an existing project.
3. Let Android Studio install the Android Gradle Plugin / SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will appear under app/build/outputs/apk/debug/app-debug.apk.
6. For sharing/publishing, use Build > Generate Signed Bundle / APK and create your own signing key.

The game is offline and stores its manual save in the app's local browser storage.
Simulation note: exam rules, eligibility, pay levels, allowances, promotions, tax, inflation and investment returns are simplified educational approximations. Verify current official notifications before relying on real-world figures.
