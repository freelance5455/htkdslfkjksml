
from flask import Flask, jsonify, render_template
import requests

app = Flask(__name__)

BASE_URL = "http://node.tconect.xyz:2121/"

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/health")
def health():
    try:
        response = requests.get(
            BASE_URL,
            timeout=10
        )

        return jsonify({
            "connected": response.status_code == 200,
            "status": response.status_code,
            "content_type": response.headers.get(
                "Content-Type"
            ),
            "size": len(response.content)
        })

    except requests.RequestException as error:
        return jsonify({
            "connected": False,
            "error": str(error)
        }), 502


if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5001,
        debug=False
    )
