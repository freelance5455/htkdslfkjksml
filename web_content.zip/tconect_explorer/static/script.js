
const button = document.getElementById("testButton");

const output = document.getElementById("output");
const message = document.getElementById("message");

const history = document.getElementById("history");

let tests = [];

async function testConnection() {

    button.disabled = true;
    button.textContent = "TESTANDO...";

    message.textContent = "Realizando diagnóstico...";

    try {

        const response = await fetch("/api/health");

        const data = await response.json();

        document.getElementById("connValue").textContent =
            data.connected ? "ONLINE" : "OFFLINE";

        document.getElementById("httpValue").textContent =
            data.status ?? "--";

        document.getElementById("sizeValue").textContent =
            data.size ? (data.size / 1024).toFixed(1) + " KB" : "--";

        document.getElementById("connection").textContent =
            data.connected ? "ONLINE" : "OFFLINE";

        document.querySelector(".dot").style.background =
            data.connected ? "#4ade80" : "#ef4444";

        output.textContent =
            JSON.stringify(data, null, 2);

        message.textContent =
            data.connected
            ? "Diagnóstico concluído com sucesso."
            : "O serviço não respondeu corretamente.";

        tests.unshift(
            new Date().toLocaleTimeString() +
            " — HTTP " + (data.status ?? "ERROR")
        );

        tests = tests.slice(0, 8);

        history.textContent = tests.join("\n");

    } catch (error) {

        message.textContent = "Erro: " + error.message;

        output.textContent = JSON.stringify({
            error: error.message
        }, null, 2);

    } finally {

        button.disabled = false;
        button.innerHTML = "↻ TESTAR CONEXÃO";

    }
}

button.addEventListener("click", testConnection);
