Contractor Pro V1
Independent new product; not connected to Yashar Stone Pro.
HTML-to-APK structure: web/index.html
Languages: English, Persian, Arabic, Turkish, Russian
Core: roles, projects, clients, estimates, contracts, team, finance, reports, documents placeholder.
Data is stored locally in the browser/app WebView.
