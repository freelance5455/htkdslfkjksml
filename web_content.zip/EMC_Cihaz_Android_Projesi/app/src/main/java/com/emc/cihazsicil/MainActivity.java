package com.emc.cihazsicil;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u=req.getUrl();
                if ("emc".equalsIgnoreCase(u.getScheme()) && "device".equalsIgnoreCase(u.getHost())) {
                    handleDeepLink(u); return true;
                }
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try { Uri u=Uri.parse(url); if ("emc".equalsIgnoreCase(u.getScheme())) { handleDeepLink(u); return true; } } catch(Exception ignored){}
                return false;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        if (getIntent()!=null && getIntent().getData()!=null) handleDeepLink(getIntent().getData());
    }

    private void handleDeepLink(Uri uri) {
        String key=uri.getPath();
        if (key!=null && key.startsWith("/")) key=key.substring(1);
        if (key==null) key="";
        final String jsKey = key.replace("\\","\\\\").replace("'","\\'");
        final String action = uri.getQueryParameter("action") == null ? "" : uri.getQueryParameter("action").replace("'","\\'");
        webView.postDelayed(() -> webView.evaluateJavascript("if(window.openDeviceFromAndroid){window.openDeviceFromAndroid('"+jsKey+"','"+action+"');}", null), 700);
    }

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if (intent.getData()!=null) handleDeepLink(intent.getData());
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
