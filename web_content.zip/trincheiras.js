(() => {
'use strict';
/* ================= base ================= */
const $ = s => document.querySelector(s);
const M = window.MUNDO, W = M.W, H = M.H, RES = M.res, LAT0 = M.lat0, NPX = W * H;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = n => n >= 1000 ? (n / 1000).toFixed(1).replace('.', ',') + ' mi' : Math.round(n) + ' mil';
const fmtKm = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.', ',') + ' mi km²' : Math.round(n / 1000) + ' mil km²';
const fmtPop = n => n >= 1000 ? (n / 1000).toFixed(2).replace('.', ',') + ' bi' : n >= 10 ? Math.round(n) + ' mi' : n.toFixed(1).replace('.', ',') + ' mi';
const ICON = k => `<svg class="ic"><use href="#i-${k}"/></svg>`;
const P_SWORDS = new Path2D('M4 4L16 16M12.5 17.5L17.5 12.5M16 16L19.5 19.5M20 4L8 16M11.5 17.5L6.5 12.5M8 16L4.5 19.5');
const P_STAR = new Path2D('M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z');
const PALETTE = ['#7a7a2e', '#a03a2a', '#c9a24b', '#4f8a72', '#7f5f95', '#b5651d', '#5c80a0', '#98a04f', '#b0574a', '#3f7a63', '#c98d5c', '#7d8ea0', '#8a7a50', '#5f9a88', '#d0b070', '#6a4a3a'];
const REAL_CONT = { NA: { n: 'América do Norte', box: [-170, -50, 5, 75] }, SA: { n: 'América do Sul', box: [-82, -34, -56, 13] }, EU: { n: 'Europa', box: [-12, 45, 34, 72] }, AF: { n: 'África', box: [-20, 52, -36, 38] }, AS: { n: 'Ásia', box: [25, 150, -10, 70] }, OC: { n: 'Oceania', box: [110, 180, -48, 0] }, AN: { n: 'Antártida', box: [-180, 180, -90, -62] } };
let CONT = REAL_CONT;
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }
function hex2rgb(h) { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; }
function shadeCol(hex, amt) { const c = hex2rgb(hex), f = v => clamp(Math.round(amt < 0 ? v * (1 + amt) : v + (255 - v) * amt), 0, 255); return `rgb(${f(c[0])},${f(c[1])},${f(c[2])})`; }
function norm(s) { return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function bytesToB64(bytes) { let s = ''; for (let i = 0; i < bytes.length; i += 8192) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192)); return btoa(s); }
function rleEnc(arr) { const out = []; let i = 0; const n = arr.length; const push = v => { while (v >= 128) { out.push((v & 127) | 128); v >>= 7; } out.push(v); }; while (i < n) { const v = arr[i]; let j = i + 1; while (j < n && arr[j] === v) j++; push(v); push(j - i); i = j; } return bytesToB64(Uint8Array.from(out)); }
function rleDec(b64, n) { const bin = atob(b64), out = new Uint16Array(n); let i = 0, o = 0; const rd = () => { let v = 0, sh = 0, b; do { b = bin.charCodeAt(i++); v |= (b & 127) << sh; sh += 7; } while (b & 128); return v; }; while (i < bin.length && o < n) { const v = rd(), len = rd(); out.fill(v, o, o + len); o += len; } return out; }
function decodeRLE8(b64, n) { const bin = atob(b64), out = new Uint16Array(n); let i = 0, o = 0; while (i < bin.length) { const v = bin.charCodeAt(i++); let len = 0, sh = 0, b; do { b = bin.charCodeAt(i++); len |= (b & 127) << sh; sh += 7; } while (b & 128); out.fill(v, o, o + len); o += len; } return out; }

/* ================= dados do mundo real ================= */
const CAPLIST = 'RU:Moscou|CA:Ottawa|US:Washington D.C.|CN:Pequim|BR:Brasília|AU:Camberra|IN:Nova Délhi|AR:Buenos Aires|KZ:Astana|DZ:Argel|CD:Kinshasa|GL:Nuuk|SA:Riade|MX:Cidade do México|ID:Jacarta|SD:Cartum|LY:Trípoli|IR:Teerã|MN:Ulã Bator|PE:Lima|TD:N\'Djamena|NE:Niamei|AO:Luanda|ML:Bamaco|ZA:Pretória|CO:Bogotá|ET:Adis Abeba|BO:La Paz|MR:Nouakchott|EG:Cairo|TZ:Dodoma|NG:Abuja|VE:Caracas|NA:Windhoek|PK:Islamabad|MZ:Maputo|TR:Ancara|CL:Santiago|ZM:Lusaka|MM:Nepiedó|AF:Cabul|SS:Juba|SO:Mogadíscio|CF:Bangui|UA:Kiev|MG:Antananarivo|BW:Gaborone|KE:Nairóbi|FR:Paris|YE:Sanaa|TH:Bangcoc|ES:Madri|TM:Asgabate|CM:Iaundé|PG:Port Moresby|SE:Estocolmo|UZ:Tashkent|MA:Rabat|IQ:Bagdá|PY:Assunção|ZW:Harare|JP:Tóquio|DE:Berlim|CG:Brazzaville|FI:Helsinque|VN:Hanói|MY:Kuala Lumpur|NO:Oslo|CI:Yamoussoukro|PL:Varsóvia|OM:Mascate|IT:Roma|PH:Manila|EC:Quito|BF:Uagadugu|NZ:Wellington|GA:Libreville|GN:Conacri|GB:Londres|UG:Kampala|GH:Acra|RO:Bucareste|LA:Vienciana|GY:Georgetown|BY:Minsk|KG:Bisqueque|SN:Dacar|SY:Damasco|KH:Phnom Penh|UY:Montevidéu|TN:Túnis|SR:Paramaribo|NP:Catmandu|BD:Daca|TJ:Duchambe|GR:Atenas|NI:Manágua|MW:Lilongwe|ER:Asmara|BJ:Porto Novo|HN:Tegucigalpa|LR:Monróvia|BG:Sófia|CU:Havana|GT:Cidade da Guatemala|IS:Reykjavik|KR:Seul|HU:Budapeste|PT:Lisboa|JO:Amã|AZ:Baku|AT:Viena|AE:Abu Dhabi|CZ:Praga|PA:Cidade do Panamá|SL:Freetown|IE:Dublin|GE:Tbilisi|LK:Sri Jayawardenapura Kotte|LT:Vilnius|LV:Riga|TG:Lomé|HR:Zagreb|BA:Sarajevo|CR:San José|SK:Bratislava|DO:Santo Domingo|EE:Tallinn|DK:Copenhague|NL:Amsterdã|CH:Berna|BT:Timbu|TW:Taipé|GW:Bissau|MD:Chisinau|BE:Bruxelas|LS:Maseru|AM:Erevã|AL:Tirana|GQ:Malabo|BI:Gitega|HT:Porto Príncipe|RW:Kigali|MK:Escópia|DJ:Djibuti|BZ:Belmopan|SV:San Salvador|IL:Jerusalém|SI:Liubliana|FJ:Suva|KW:Cidade do Kuwait|SZ:Mbabane|TL:Díli|ME:Podgorica|RS:Belgrado|QA:Doha|GM:Banjul|JM:Kingston|LB:Beirute|CY:Nicósia|LU:Luxemburgo|KP:Pyongyang|PS:Ramallah|XK:Pristina|EH:El Aaiún|BN:Bandar Seri Begawan|SG:Singapura|GF:Caiena|AQ:Estação Polar';
const CAPS = {}; CAPLIST.split('|').forEach(s => { const [k, v] = s.split(':'); CAPS[k] = v; });
const FLAGEXT = {}; M.paises.forEach(q => { FLAGEXT[q.iso] = q.f; });
const POP = { CN: 1410, IN: 1430, US: 335, ID: 277, PK: 240, NG: 224, BR: 216, BD: 172, RU: 144, MX: 128, JP: 124, ET: 126, PH: 117, EG: 112, CD: 102, VN: 99, IR: 89, TR: 85, DE: 84, TH: 72, GB: 67, FR: 68, TZ: 67, ZA: 60, IT: 59, KE: 55, MM: 54, CO: 52, KR: 52, ES: 48, UG: 48, SD: 48, AR: 46, DZ: 45, UA: 37, IQ: 44, AF: 41, PL: 38, CA: 40, MA: 37, SA: 36, UZ: 35, PE: 34, MY: 34, AO: 36, GH: 34, MZ: 33, YE: 34, NP: 30, VE: 28, MG: 30, CM: 28, CI: 28, NE: 26, AU: 26, KP: 26, TW: 24, LK: 22, BF: 23, ML: 23, SY: 22, RO: 19, CL: 19, KZ: 20, ZM: 20, GT: 18, EC: 18, NL: 17.5, SN: 17, TD: 18, SO: 18, ZW: 16, KH: 17, SS: 11, BE: 11.7, CU: 11, GR: 10.4, PT: 10.3, CZ: 10.8, SE: 10.5, HU: 9.6, AT: 9, BY: 9.2, CH: 8.8, IL: 9.7, TJ: 10, BG: 6.5, RS: 6.7, DK: 5.9, FI: 5.5, NO: 5.5, NZ: 5.1, IE: 5.2, LA: 7.5, PY: 6.9, BO: 12, HN: 10, SL: 8.6, AZ: 10, JO: 11, AE: 10, CR: 5.2, PA: 4.4, UY: 3.4, MN: 3.4, LB: 5.4, KW: 4.3, OM: 4.6, AM: 2.8, GE: 3.7, IS: 0.38, AQ: 0.004 };
const NAME_SYL = ['Al', 'Bre', 'Cal', 'Dra', 'Es', 'Fer', 'Gal', 'Hes', 'Ith', 'Jor', 'Kal', 'Lum', 'Mor', 'Nor', 'Oth', 'Pra', 'Qua', 'Ruv', 'Sel', 'Tor', 'Ul', 'Val', 'Wes', 'Xan', 'Yor', 'Zen', 'Bor', 'Cor', 'Dov', 'Ele'];
const NAME_END = ['doria', 'vânia', 'eon', 'vena', 'karra', 'rovia', 'drun', 'péria', 'mar', 'vik', 'dera', 'meria', 'vane', 'dak', 'land', 'gard', 'nia', 'tória', 'zuela', 'landia'];
const CAP_PRE = ['Porto ', 'Vila ', 'Monte ', 'Forte ', 'Nova ', 'Alto ', 'Ponte ', 'Cabo '];
const GREEK = ['Alfa', 'Beta', 'Gama', 'Delta', 'Épsilon', 'Zeta', 'Eta', 'Teta', 'Iota', 'Capa', 'Lambda', 'Sigma'];

/* ================= grade hexagonal (fonte única de propriedade) ================= */
const HS = 2.2, HW = Math.sqrt(3) * HS, HV = 1.5 * HS, HEXRES = 1.5;
const HC = Math.ceil(W / HW) + 1, HR = Math.ceil((H - HS) / HV) + 1, HN = HC * HR;
const hcx = new Float32Array(HN), hcy = new Float32Array(HN);
const HCOR = []; for (let k = 0; k < 6; k++) { const a = (60 * k - 30) * Math.PI / 180; HCOR.push([HS * Math.cos(a), HS * Math.sin(a)]); }
for (let r = 0; r < HR; r++) for (let c = 0; c < HC; c++) { const i = r * HC + c; hcx[i] = HW * (c + 0.5 * (r & 1)) + HW / 2; hcy[i] = HS + HV * r; }
function hexNb(i, k) {
  const c = i % HC, r = (i / HC) | 0, odd = r & 1; let nc, nr;
  switch (k) {
    case 0: nc = c + 1; nr = r; break;
    case 1: nc = c + odd; nr = r + 1; break;
    case 2: nc = c + odd - 1; nr = r + 1; break;
    case 3: nc = c - 1; nr = r; break;
    case 4: nc = c + odd - 1; nr = r - 1; break;
    default: nc = c + odd; nr = r - 1;
  }
  return (nc < 0 || nc >= HC || nr < 0 || nr >= HR) ? -1 : nr * HC + nc;
}
const KM2 = (111.32 / RES) * (111.32 / RES), HEXPXAREA = 1.5 * Math.sqrt(3) * HS * HS, COSR = new Float32Array(HR);
for (let r = 0; r < HR; r++) COSR[r] = Math.cos((LAT0 - hcy[r * HC] / RES) * Math.PI / 180);
const hexAreaKm2 = i => KM2 * HEXPXAREA * COSR[(i / HC) | 0];

const hown = new Uint16Array(HN);
let hexOwnerArr = [], hexPos = new Int32Array(HN).fill(-1);
function ownerArr(cid) { return hexOwnerArr[cid] || (hexOwnerArr[cid] = []); }
function setHexOwnerData(i, newOwner) {
  const old = hown[i]; if (old === newOwner) return;
  if (old) { const arr = hexOwnerArr[old], pos = hexPos[i], last = arr[arr.length - 1]; arr[pos] = last; hexPos[last] = pos; arr.pop(); hexPos[i] = -1; const c = C[old]; c.cells--; c.area -= hexAreaKm2(i); c.sumX -= hcx[i]; c.sumY -= hcy[i]; }
  hown[i] = newOwner;
  if (newOwner) { const arr = ownerArr(newOwner); arr.push(i); hexPos[i] = arr.length - 1; const c = C[newOwner]; c.cells++; c.area += hexAreaKm2(i); c.sumX += hcx[i]; c.sumY += hcy[i]; }
}
function countryComponents(cid, cap) {
  const arr = hexOwnerArr[cid]; if (!arr || !arr.length) return [];
  const visited = new Set(), comps = [];
  for (const s of arr) {
    if (visited.has(s)) continue;
    const comp = [s], st = [s]; visited.add(s);
    while (st.length) { const a = st.pop(); for (let k = 0; k < 6; k++) { const j = hexNb(a, k); if (j >= 0 && hown[j] === cid && !visited.has(j)) { visited.add(j); comp.push(j); st.push(j); } } }
    comps.push(comp);
    if (cap && comps.length >= cap) break;
  }
  return comps;
}

/* ================= modelo de país ================= */
let C = [null];
function makeCountry(id, m) {
  return {
    id, iso: m.iso || '', name: m.name, cont: m.cont || 'NEW', cap: m.cap || null, capName: m.capName || '', pw: m.pw == null ? 30 : m.pw, ext: m.ext || 'gen',
    army: 0, treasury: 0, eco: 50, ind: 40, pop: 5, tech: 3, morale: 80, alive: false, deleted: false, allies: new Set(), wars: new Set(),
    cells: 0, totalHex: 0, lost: 0, color: '#888888', rgb: [136, 136, 136], colorIdx: 0, area: 0, sumX: 0, sumY: 0, capHex: -1,
    planted: false, custom: null, customURL: null, flagSrc: null, plantT: -9999, bmp: null, bmpState: 0, genURL: null
  };
}
function powerScore(c) { return clamp(100 * (0.3 * Math.sqrt(c.army / 5000) + 0.22 * c.eco / 100 + 0.18 * c.tech / 10 + 0.12 * c.morale / 100 + 0.1 * c.ind / 100 + 0.08 * Math.sqrt(c.pop / 1500)), 0, 100); }
function initOne(c, seed) {
  const rnd = i => (((i * 2654435761 + seed) >>> 0) % 1000) / 1000;
  if (!c.cells) { c.alive = false; c.deleted = c.deleted || !c.keep; return; }
  c.pop = POP[c.iso] != null ? POP[c.iso] : clamp(0.6 + c.area / 1e5 * (world && world.type === 'real' ? 0.9 : 3), 0.3, 400);
  c.army = 20 + c.pop * (0.5 + c.pw / 40) + rnd(c.id) * 10;
  c.eco = clamp(12 + c.pw * 0.85 + rnd(c.id + 3) * 8, 5, 100);
  c.ind = clamp(15 + c.pw * 0.7 + rnd(c.id + 7) * 10, 5, 100);
  c.treasury = 100 + c.eco * 12 + c.cells * 0.6;
  c.tech = clamp(1 + Math.round(c.pw / 11) + (rnd(c.id + 9) > 0.6 ? 1 : 0), 1, 10);
  c.morale = 70 + rnd(c.id + 5) * 22;
  c.alive = true; c.deleted = false; c.lost = 0; c.allies.clear(); c.wars.clear();
}
function initStats(seed) { for (let i = 1; i < C.length; i++) initOne(C[i], seed); }
function pickColorForHexes(cid, hexList) {
  const taken = new Set();
  for (const i of hexList) for (let k = 0; k < 6; k++) { const j = hexNb(i, k); if (j >= 0 && hown[j] && hown[j] !== cid && C[hown[j]].colorIdx != null) taken.add(C[hown[j]].colorIdx); }
  let best = 0; for (let i = 0; i < PALETTE.length; i++) if (!taken.has(i)) { best = i; break; }
  const c = C[cid]; c.colorIdx = best; c.color = PALETTE[best]; c.rgb = hex2rgb(c.color);
}
function colorizeAll() {
  const nb = Array.from({ length: C.length }, () => new Set());
  for (let cid = 1; cid < C.length; cid++) {
    const arr = hexOwnerArr[cid]; if (!arr) continue;
    for (const i of arr) for (let k = 0; k < 3; k++) { const j = hexNb(i, k); if (j >= 0 && hown[j] && hown[j] !== cid) { nb[cid].add(hown[j]); nb[hown[j]].add(cid); } }
  }
  const order = C.slice(1).filter(c => c.cells > 0).sort((a, b) => b.area - a.area);
  const used = new Array(PALETTE.length).fill(0);
  for (const c of order) {
    const taken = new Set(); nb[c.id].forEach(o => { if (C[o].colorIdx != null) taken.add(C[o].colorIdx); });
    let best = -1, bu = 1e9; for (let i = 0; i < PALETTE.length; i++) if (!taken.has(i) && used[i] < bu) { bu = used[i]; best = i; }
    if (best < 0) best = 0; c.colorIdx = best; used[best]++; c.color = PALETTE[best]; c.rgb = hex2rgb(c.color);
  }
}
function findCapitalHex(cid, lon, lat) {
  const arr = hexOwnerArr[cid]; if (!arr || !arr.length) return -1;
  if (lon == null) return arr[0];
  const tx = (lon + 180) * RES, ty = (LAT0 - lat) * RES;
  let best = arr[0], bd = 1e18;
  for (const i of arr) { const d = (hcx[i] - tx) ** 2 + (hcy[i] - ty) ** 2; if (d < bd) { bd = d; best = i; } }
  return best;
}

/* ================= construção do mundo a partir de pixels ================= */
function buildHexesFromPixels(pixArr) {
  hown.fill(0); hexOwnerArr = new Array(C.length); hexPos.fill(-1);
  for (let i = 1; i < C.length; i++) { const c = C[i]; c.cells = 0; c.area = 0; c.sumX = 0; c.sumY = 0; }
  for (let i = 0; i < HN; i++) {
    const px = Math.floor(hcx[i]), py = Math.floor(hcy[i]);
    if (px < 0 || px >= W || py < 0 || py >= H) continue;
    const o = pixArr[py * W + px]; if (!o || o >= C.length) continue;
    hown[i] = o; const arr = ownerArr(o); arr.push(i); hexPos[i] = arr.length - 1;
    const c = C[o]; c.cells++; c.area += hexAreaKm2(i); c.sumX += hcx[i]; c.sumY += hcy[i];
  }
  for (let i = 1; i < C.length; i++) {
    const c = C[i];
    c.capHex = c.cells ? findCapitalHex(i, c.cap ? c.cap[0] : null, c.cap ? c.cap[1] : null) : -1;
    c.totalHex = c.cells;
    if (!c.cap && c.capHex >= 0) c.cap = [hcx[c.capHex] / RES - 180, LAT0 - hcy[c.capHex] / RES];
  }
}
function rebuildFromHownSaved(arr) {
  hown.set(arr); hexOwnerArr = new Array(C.length); hexPos.fill(-1);
  for (let i = 1; i < C.length; i++) { const c = C[i]; c.cells = 0; c.area = 0; c.sumX = 0; c.sumY = 0; }
  for (let i = 0; i < HN; i++) {
    const o = hown[i]; if (!o || o >= C.length) { hown[i] = 0; continue; }
    const a = ownerArr(o); a.push(i); hexPos[i] = a.length - 1;
    const c = C[o]; c.cells++; c.area += hexAreaKm2(i); c.sumX += hcx[i]; c.sumY += hcy[i];
  }
}

/* ================= estado do jogo ================= */
let wars = [], events = [], day = 0, casualties = 0, mode = 'war', paused = false, speedIdx = 0, ended = false;
let selected = null, sticky = null, allyPick = null, flagsAll = false, flagOp = 0.94, dirtySave = false;
const opts = { labels: true, capitals: true, fatigue: true, allyJoin: true, hex: true };
const atWar = (a, b) => C[a].wars.has(b);
const SPEEDS = [1, 2, 4], HOLD_MS = 650, TAP_MS = 450, MOVE_PX = 14, DRAW_PX = 5, ARM_WINDOW = 9000, FL = 1.6;

/* ---------- camadas ---------- */
const mkCanvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
const hexFill = mkCanvas(W * HEXRES, H * HEXRES), hexFillCtx = hexFill.getContext('2d');
const hexGrid = mkCanvas(W * HEXRES, H * HEXRES), hexGridCtx = hexGrid.getContext('2d');
const hexBorder = mkCanvas(W * HEXRES, H * HEXRES), hexBorderCtx = hexBorder.getContext('2d');
const warHex = mkCanvas(W * HEXRES, H * HEXRES), warHexCtx = warHex.getContext('2d');
const flagLayer = mkCanvas(W * FL, H * FL), flagCtx = flagLayer.getContext('2d');
const flagLo = mkCanvas(W, H), flagLoCtx = flagLo.getContext('2d');
const flagSm = mkCanvas(W * FL, H * FL), flagSmCtx = flagSm.getContext('2d');
let warDirty = true, flagDirty = true;
const flagDirtyC = new Set();

function hexColor(i) { const c = C[hown[i]].rgb, f = 0.965 + (((i * 2654435761) >>> 0) % 100) / 1400; return `rgb(${Math.min(255, c[0] * f) | 0},${Math.min(255, c[1] * f) | 0},${Math.min(255, c[2] * f) | 0})`; }
function hexPathOn(g, i, sc) { const x = hcx[i] * sc, y = hcy[i] * sc; g.moveTo(x + HCOR[0][0] * sc, y + HCOR[0][1] * sc); for (let k = 1; k < 6; k++) g.lineTo(x + HCOR[k][0] * sc, y + HCOR[k][1] * sc); g.closePath(); }
function drawHexFillTo(g, i, sc) { g.beginPath(); hexPathOn(g, i, sc); g.fillStyle = hexColor(i); g.fill(); }
function drawHexGridTo(g, i, sc) { g.beginPath(); hexPathOn(g, i, sc); g.lineWidth = 0.14 * sc; g.strokeStyle = 'rgba(0,0,0,.24)'; g.lineJoin = 'round'; g.stroke(); }
function drawHexBorderTo(g, i, sc) {
  const o = hown[i]; if (!o) return;
  const x = hcx[i] * sc, y = hcy[i] * sc; let hb = false, hc = false;
  g.beginPath();
  for (let k = 0; k < 6; k++) { const j = hexNb(i, k), oj = j < 0 ? 0 : hown[j]; if (oj && oj !== o) { const a = HCOR[k], b = HCOR[(k + 1) % 6]; g.moveTo(x + a[0] * sc, y + a[1] * sc); g.lineTo(x + b[0] * sc, y + b[1] * sc); hb = true; } }
  if (hb) { g.lineWidth = 0.42 * sc; g.strokeStyle = 'rgba(2,3,2,.82)'; g.lineCap = 'round'; g.stroke(); }
  g.beginPath();
  for (let k = 0; k < 6; k++) { const j = hexNb(i, k), oj = j < 0 ? 0 : hown[j]; if (!oj) { const a = HCOR[k], b = HCOR[(k + 1) % 6]; g.moveTo(x + a[0] * sc, y + a[1] * sc); g.lineTo(x + b[0] * sc, y + b[1] * sc); hc = true; } }
  if (hc) { g.lineWidth = 0.3 * sc; g.strokeStyle = 'rgba(2,3,2,.6)'; g.lineCap = 'round'; g.stroke(); }
}
function paintAllHex() {
  [hexFillCtx, hexGridCtx, hexBorderCtx].forEach(g => { g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, hexFill.width, hexFill.height); });
  for (let i = 0; i < HN; i++) if (hown[i]) drawHexFillTo(hexFillCtx, i, HEXRES);
  for (let i = 0; i < HN; i++) if (hown[i]) { drawHexGridTo(hexGridCtx, i, HEXRES); drawHexBorderTo(hexBorderCtx, i, HEXRES); }
  warDirty = true; repaintFlagsAll();
}
function paintHex(i) {
  const s = HEXRES, q = HS * s * 1.6, cx = hcx[i] * s, cy = hcy[i] * s;
  const box = [cx - q, cy - q, 2 * q, 2 * q];
  hexFillCtx.clearRect(...box); hexGridCtx.clearRect(...box); hexBorderCtx.clearRect(...box);
  if (hown[i]) { drawHexFillTo(hexFillCtx, i, s); drawHexGridTo(hexGridCtx, i, s); drawHexBorderTo(hexBorderCtx, i, s); }
  for (let k = 0; k < 6; k++) { const j = hexNb(i, k); if (j >= 0 && hown[j]) { drawHexFillTo(hexFillCtx, j, s); drawHexGridTo(hexGridCtx, j, s); drawHexBorderTo(hexBorderCtx, j, s); } }
}
function rebuildWarHex() {
  warDirty = false; warHexCtx.setTransform(1, 0, 0, 1, 0, 0); warHexCtx.clearRect(0, 0, warHex.width, warHex.height);
  if (!wars.length) return;
  const g = warHexCtx; g.strokeStyle = '#ff4a3d'; g.lineWidth = 0.9 * HEXRES; g.lineCap = 'round'; g.beginPath();
  const done = new Set();
  for (let ci = 1; ci < C.length; ci++) {
    if (!C[ci].alive || !C[ci].wars.size || done.has(ci)) continue; done.add(ci);
    const arr = hexOwnerArr[ci]; if (!arr) continue;
    for (const i of arr) for (let k = 0; k < 3; k++) {
      const j = hexNb(i, k), oj = j < 0 ? 0 : hown[j];
      if (oj && oj !== ci && C[ci].wars.has(oj)) { const a = HCOR[k], b = HCOR[(k + 1) % 6], x = hcx[i] * HEXRES, y = hcy[i] * HEXRES; g.moveTo(x + a[0] * HEXRES, y + a[1] * HEXRES); g.lineTo(x + b[0] * HEXRES, y + b[1] * HEXRES); }
    }
  }
  g.stroke();
}
function drawHexVector(edgesOnly) {
  const x0 = -cam.x / cam.z, y0 = -cam.y / cam.z, x1 = (VW - cam.x) / cam.z, y1 = (VH - cam.y) / cam.z;
  const r0 = clamp(Math.floor((y0 - HS) / HV) - 1, 0, HR - 1), r1 = clamp(Math.ceil((y1 - HS) / HV) + 1, 0, HR - 1);
  const c0 = clamp(Math.floor(x0 / HW) - 1, 0, HC - 1), c1 = clamp(Math.ceil(x1 / HW) + 1, 0, HC - 1);
  if (!edgesOnly) for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) { const i = r * HC + c; if (hown[i]) drawHexFillTo(ctx, i, 1); }
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) { const i = r * HC + c; if (hown[i]) drawHexBorderTo(ctx, i, 1); }
}
function hexVisibleCount() { return ((VW / cam.z) / HW) * ((VH / cam.z) / HV); }

/* ---------- bandeiras ---------- */
function genFlagCanvas(c) {
  const cv = mkCanvas(360, 240), g = cv.getContext('2d'), a = c.color, b = '#f0e6c8', d = shadeCol(c.color, -0.5), k = c.id % 6;
  const R_ = (x, y, w, h, col) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
  if (k === 0) { R_(0, 0, 360, 240, a); R_(0, 80, 360, 80, b); }
  else if (k === 1) { R_(0, 0, 360, 240, a); R_(120, 0, 120, 240, b); }
  else if (k === 2) { R_(0, 0, 360, 240, a); R_(96, 0, 54, 240, b); R_(0, 93, 360, 54, b); }
  else if (k === 3) { R_(0, 0, 360, 240, d); g.fillStyle = a; g.beginPath(); g.moveTo(0, 0); g.lineTo(360, 0); g.lineTo(0, 240); g.fill(); g.fillStyle = b; g.beginPath(); g.arc(84, 72, 27, 0, 6.283); g.fill(); }
  else if (k === 4) { R_(0, 0, 360, 240, a); g.fillStyle = b; g.beginPath(); g.arc(180, 120, 66, 0, 6.283); g.fill(); g.fillStyle = d; g.beginPath(); g.arc(180, 120, 33, 0, 6.283); g.fill(); }
  else { R_(0, 0, 360, 240, b); g.fillStyle = a; g.beginPath(); g.moveTo(0, 0); g.lineTo(180, 120); g.lineTo(0, 240); g.fill(); R_(180, 102, 180, 36, d); }
  return cv;
}
function flagOn(c) { return c.alive && (flagsAll || c.planted); }
function flagSrcOf(c) { return c.flagSrc || (c.ext === 'gen' ? 'GEN' : c.iso); }
function flagURL(c) {
  if (c.customURL) return c.customURL;
  const s = flagSrcOf(c);
  if (s === 'GEN') { if (!c.genURL) c.genURL = genFlagCanvas(c).toDataURL(); return c.genURL; }
  return `flags/${s}.${FLAGEXT[s] || 'svg'}`;
}
function ensureFlag(c) {
  if (c.custom) { c.bmp = c.custom; c.bmpState = 2; return c.bmp; }
  const s = flagSrcOf(c);
  if (s === 'GEN') { if (!c.bmp) c.bmp = genFlagCanvas(c); c.bmpState = 2; return c.bmp; }
  if (c.bmpState === 2) return c.bmp;
  if (c.bmpState === 0) {
    c.bmpState = 1; const im = new Image();
    im.onload = () => { const w = 360, h = Math.max(60, Math.round(360 * (im.naturalHeight || 240) / (im.naturalWidth || 360))); const cv = mkCanvas(w, h); cv.getContext('2d').drawImage(im, 0, 0, w, h); c.bmp = cv; c.bmpState = 2; markFlagDirty(c.id); requestDraw(); };
    im.onerror = () => { c.bmpState = 3; };
    im.src = flagURL(c);
  }
  return null;
}
function coverCanvas(im, w, h) {
  const cv = mkCanvas(w, h), g = cv.getContext('2d'), ia = im.width / im.height, ca = w / h;
  let sw = im.width, sh = im.height, sx = 0, sy = 0;
  if (ia > ca) { sw = im.height * ca; sx = (im.width - sw) / 2; } else { sh = im.width / ca; sy = (im.height - sh) / 2; }
  g.drawImage(im, sx, sy, sw, sh, 0, 0, w, h);
  return cv;
}
function drawFlagBoxG(g, bmp, b) {
  const ba = b.w / b.h, fa = bmp.width / bmp.height;
  if (ba < 0.55 || ba > 2.2) { g.drawImage(bmp, b.x, b.y, b.w, b.h); return; }
  let sw = bmp.width, sh = bmp.height, sx = 0, sy = 0;
  if (ba > fa) { sh = bmp.width / ba; sy = (bmp.height - sh) / 2; } else { sw = bmp.height * ba; sx = (bmp.width - sw) / 2; }
  g.drawImage(bmp, sx, sy, sw, sh, b.x, b.y, b.w, b.h);
}
function paintFlagForCountry(cid) {
  const c = C[cid];
  flagCtx.setTransform(FL, 0, 0, FL, 0, 0);
  const comps = countryComponents(cid, 24);
  let minx = 1e9, miny = 1e9, maxx = -1, maxy = -1;
  for (const comp of comps) for (const h of comp) { minx = Math.min(minx, hcx[h]); maxx = Math.max(maxx, hcx[h]); miny = Math.min(miny, hcy[h]); maxy = Math.max(maxy, hcy[h]); }
  if (maxx >= 0) { const m = HS * 3; flagCtx.clearRect(minx - m, miny - m, maxx - minx + 2 * m, maxy - miny + 2 * m); }
  if (!flagOn(c)) return;
  const bmp = ensureFlag(c);
  for (const comp of comps) {
    if (comp.length < 3) continue;
    let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9;
    for (const h of comp) { bx0 = Math.min(bx0, hcx[h] - HS); bx1 = Math.max(bx1, hcx[h] + HS); by0 = Math.min(by0, hcy[h] - HS); by1 = Math.max(by1, hcy[h] + HS); }
    let w = bx1 - bx0, h = by1 - by0; const mw = 15, mh = 10.5; if (w < mw) { bx0 -= (mw - w) / 2; w = mw; } if (h < mh) { by0 -= (mh - h) / 2; h = mh; }
    flagCtx.save(); flagCtx.beginPath();
    for (const hx of comp) hexPathOn(flagCtx, hx, 1);
    flagCtx.clip();
    if (bmp) drawFlagBoxG(flagCtx, bmp, { x: bx0, y: by0, w, h }); else { flagCtx.fillStyle = c.color; flagCtx.fillRect(bx0, by0, w, h); }
    flagCtx.restore();
  }
}
function markFlagDirty(cid) { flagDirtyC.add(cid); flagDirty = true; }
function repaintFlagOwner(cid) { paintFlagForCountry(cid); flagDirty = true; requestDraw(); }
function anyFlags() { if (flagsAll) return true; for (let i = 1; i < C.length; i++) if (C[i].planted) return true; return false; }
function repaintFlagsAll() {
  flagCtx.setTransform(1, 0, 0, 1, 0, 0); flagCtx.clearRect(0, 0, flagLayer.width, flagLayer.height);
  if (flagsAll) { for (let i = 1; i < C.length; i++) if (C[i].alive) paintFlagForCountry(i); }
  else { for (let i = 1; i < C.length; i++) if (C[i].planted) paintFlagForCountry(i); }
  flagDirty = true; requestDraw();
}
function flushFlagDirty() { if (!flagDirtyC.size) return; for (const cid of flagDirtyC) if (C[cid]) paintFlagForCountry(cid); flagDirtyC.clear(); flagDirty = true; }
let flagTarget = null;
function resetFlagCache(c) { c.custom = null; c.customURL = null; c.bmp = null; c.bmpState = 0; c.genURL = null; }
function plantDefault(cid) { const c = C[cid]; resetFlagCache(c); c.flagSrc = null; c.planted = true; c.plantT = performance.now(); ensureFlag(c); repaintFlagOwner(cid); dirtySave = true; updateSheet(true); }
function plantFrom(cid, src) { const c = C[cid]; resetFlagCache(c); c.flagSrc = src; c.planted = true; c.plantT = performance.now(); ensureFlag(c); repaintFlagOwner(cid); dirtySave = true; updateSheet(true); toast(`Bandeira aplicada em ${c.name}`); }
function plantCustomCanvas(cid, cv) { const c = C[cid]; resetFlagCache(c); c.custom = cv; c.bmp = cv; c.bmpState = 2; try { c.customURL = cv.toDataURL('image/jpeg', 0.88); } catch (_) { c.customURL = null; } c.planted = true; c.plantT = performance.now(); repaintFlagOwner(cid); dirtySave = true; updateSheet(true); }
function removeFlag(cid) { const c = C[cid]; resetFlagCache(c); c.flagSrc = null; c.planted = false; repaintFlagOwner(cid); dirtySave = true; updateSheet(true); }
$('#fileFlag').addEventListener('change', e => {
  const f = e.target.files && e.target.files[0]; e.target.value = '';
  if (!f || flagTarget == null) return;
  const cid = flagTarget, url = URL.createObjectURL(f), im = new Image();
  im.onload = () => { plantCustomCanvas(cid, coverCanvas(im, 480, 320)); URL.revokeObjectURL(url); toast(`Bandeira de ${C[cid].name} plantada`); };
  im.onerror = () => { URL.revokeObjectURL(url); toast('Não consegui abrir essa imagem'); };
  im.src = url;
});

/* ================= câmera e desenho ================= */
const canvas = $('#map'), ctx = canvas.getContext('2d');
let VW = 1, VH = 1, DPR = 1, viewInit = false;
const cam = { x: 0, y: 0, z: 1 };
const MAXZ = 26;
const minZoom = () => Math.max(0.1, VW / W);
function clampCam() {
  cam.z = clamp(cam.z, minZoom(), MAXZ);
  const mw = W * cam.z, mh = H * cam.z;
  cam.x = mw <= VW ? (VW - mw) / 2 : Math.min(0, Math.max(VW - mw, cam.x));
  cam.y = mh <= VH ? (VH - mh) / 2 : Math.min(0, Math.max(VH - mh, cam.y));
}
function resize() {
  const r = canvas.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return;
  DPR = Math.min(2, window.devicePixelRatio || 1); VW = r.width; VH = r.height;
  canvas.width = Math.round(VW * DPR); canvas.height = Math.round(VH * DPR);
  if (!viewInit) { viewInit = true; viewLonLat(10, 30, VH / H); } else clampCam();
  requestDraw();
}
function viewLonLat(lon, lat, z) { cam.z = z; cam.x = VW / 2 - (lon + 180) * RES * z; cam.y = VH / 2 - (LAT0 - lat) * RES * z; clampCam(); }
const toMapX = sx => (sx - cam.x) / cam.z, toMapY = sy => (sy - cam.y) / cam.z;
function hexAt(sx, sy) {
  const mx = toMapX(sx), my = toMapY(sy);
  if (mx < -HW || my < -HV || mx > W + HW || my > H + HV) return -1;
  let r0 = clamp(Math.round((my - HS) / HV), 0, HR - 1), best = -1, bd = 1e18;
  for (let r = Math.max(0, r0 - 1); r <= Math.min(HR - 1, r0 + 1); r++) {
    const c0 = clamp(Math.round(mx / HW - 0.5 * (r & 1)), 0, HC - 1);
    for (let c = Math.max(0, c0 - 1); c <= Math.min(HC - 1, c0 + 1); c++) { const i = r * HC + c, d = (hcx[i] - mx) ** 2 + (hcy[i] - my) ** 2; if (d < bd) { bd = d; best = i; } }
  }
  return best;
}
function countryAt(sx, sy) { const h = hexAt(sx, sy); return h >= 0 ? hown[h] : 0; }
let tween = null;
function animateTo(cx, cy, z, dur) { z = clamp(z, minZoom(), MAXZ); tween = { t0: performance.now(), dur: dur || 650, cx0: (VW / 2 - cam.x) / cam.z, cy0: (VH / 2 - cam.y) / cam.z, z0: cam.z, cx, cy, z }; requestDraw(); }
function flyBox(lon0, lon1, lat0, lat1) { const bw = (lon1 - lon0) * RES, bh = (lat1 - lat0) * RES, z = Math.min(VW / bw, VH / bh) * 0.92; animateTo(((lon0 + lon1) / 2 + 180) * RES, (LAT0 - (lat0 + lat1) / 2) * RES, z); }
function flyCountry(cid) {
  const comps = countryComponents(cid, 40); if (!comps.length) return;
  let best = comps[0]; for (const cp of comps) if (cp.length > best.length) best = cp;
  let minx = 1e9, miny = 1e9, maxx = -1, maxy = -1;
  for (const h of best) { minx = Math.min(minx, hcx[h]); maxx = Math.max(maxx, hcx[h]); miny = Math.min(miny, hcy[h]); maxy = Math.max(maxy, hcy[h]); }
  const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2, bw = Math.max(30, maxx - minx + 10), bh = Math.max(20, maxy - miny + 10);
  const z = Math.min(VW / bw, VH * 0.42 / bh) * 0.9;
  animateTo(cx, cy + (VH * 0.2) / Math.max(z, 0.01), z);
}
const pathCache = new Map();
function countryPath(cid) {
  let p = pathCache.get(cid); if (p) return p;
  p = new Path2D(); const arr = hexOwnerArr[cid];
  if (arr) for (const i of arr) hexPathOn(p, i, 1);
  pathCache.set(cid, p); return p;
}
function invalidateCountryPath(cid) { pathCache.delete(cid); }
const fxs = [];
function addFx(kind, hex, color) { if (fxs.length < 40) fxs.push({ t0: performance.now(), kind, x: hcx[hex], y: hcy[hex], color }); requestDraw(); }
function icon(path, x, y, s, stroke, color, lw) { ctx.save(); ctx.translate(x - s / 2, y - s / 2); ctx.scale(s / 24, s / 24); if (stroke) { ctx.strokeStyle = color; ctx.lineWidth = lw || 2; ctx.lineCap = 'round'; ctx.stroke(path); } else { ctx.fillStyle = color; ctx.fill(path); } ctx.restore(); }
let rafId = 0, running = false;
function requestDraw() { if (!running) return; if (!rafId) rafId = requestAnimationFrame(frame); }
function keepAnimating() { return ptrs.size > 0 || sticky || fxs.length || tween || wars.length || plantingActive() || drawSt.on; }
function plantingActive() { const t = performance.now(); for (let i = 1; i < C.length; i++) if (C[i].planted && t - C[i].plantT < 1200) return true; return false; }
function frame(now) {
  rafId = 0; if (!running) return; now = now || performance.now();
  if (tween) {
    const k = Math.min(1, (now - tween.t0) / tween.dur), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
    const z = Math.exp(Math.log(tween.z0) + (Math.log(tween.z) - Math.log(tween.z0)) * e);
    const cx = tween.cx0 + (tween.cx - tween.cx0) * e, cy = tween.cy0 + (tween.cy - tween.cy0) * e;
    cam.z = z; cam.x = VW / 2 - cx * z; cam.y = VH / 2 - cy * z; clampCam();
    if (k >= 1) tween = null;
  }
  updateHolds(now);
  if (warDirty) rebuildWarHex();
  if (flagDirty && anyFlags()) {
    flagLoCtx.clearRect(0, 0, W, H); flagLoCtx.imageSmoothingEnabled = true; flagLoCtx.drawImage(flagLayer, 0, 0, W, H);
    flagSmCtx.setTransform(1, 0, 0, 1, 0, 0); flagSmCtx.clearRect(0, 0, W * FL, H * FL); flagSmCtx.drawImage(flagLayer, 0, 0);
    flagSmCtx.globalCompositeOperation = 'destination-in'; flagSmCtx.imageSmoothingEnabled = true; flagSmCtx.drawImage(flagLo, 0, 0, W * FL, H * FL);
    flagSmCtx.globalCompositeOperation = 'source-over'; flagDirty = false;
  }
  render(now);
  if (keepAnimating()) rafId = requestAnimationFrame(frame);
}
function render(now) {
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  const g = ctx.createLinearGradient(0, 0, 0, VH); g.addColorStop(0, '#12302c'); g.addColorStop(1, '#070d0c');
  ctx.fillStyle = g; ctx.fillRect(0, 0, VW, VH);
  ctx.setTransform(DPR * cam.z, 0, 0, DPR * cam.z, DPR * cam.x, DPR * cam.y);
  ctx.strokeStyle = 'rgba(240,225,180,.06)'; ctx.lineWidth = 1 / cam.z; ctx.beginPath();
  for (let lon = -180; lon <= 180; lon += 30) { const x = (lon + 180) * RES; ctx.moveTo(x, 0); ctx.lineTo(x, H); }
  for (let lat = -80; lat <= 80; lat += 20) { const y = (LAT0 - lat) * RES; ctx.moveTo(0, y); ctx.lineTo(W, y); }
  ctx.stroke();
  ctx.imageSmoothingEnabled = true;
  const vec = cam.z >= 3.4 && hexVisibleCount() < 9000;
  if (vec) drawHexVector(false); else { ctx.drawImage(hexFill, 0, 0, W, H); if (opts.hex) ctx.drawImage(hexGrid, 0, 0, W, H); ctx.drawImage(hexBorder, 0, 0, W, H); }
  if (anyFlags()) { ctx.globalAlpha = flagOp; ctx.drawImage(flagSm, 0, 0, W, H); ctx.globalAlpha = 1; }
  if (vec) drawHexVector(true);
  if (wars.length) { ctx.globalAlpha = 0.6 + 0.4 * Math.sin(now / 230); ctx.drawImage(warHex, 0, 0, W, H); ctx.globalAlpha = 1; }
  const pulse = 0.28 + 0.14 * Math.sin(now / 200);
  const hl = (cid, col) => { if (cid == null || !C[cid] || !C[cid].alive) return; ctx.fillStyle = col; ctx.fill(countryPath(cid)); };
  if (!drawSt.on) {
    for (const h of ptrs.values()) if (h.cid != null && !h.moved && mode === 'war') hl(h.cid, h.done ? `rgba(230,200,138,${pulse + 0.1})` : 'rgba(255,255,255,.2)');
    if (sticky) hl(sticky.country, `rgba(230,200,138,${pulse + 0.1})`);
    if (selected != null) hl(selected, 'rgba(255,255,255,.26)');
    if (allyPick != null) hl(allyPick, 'rgba(127,176,196,.4)');
  } else if (drawSt.target != null) hl(drawSt.target, 'rgba(230,200,138,.18)');
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  const z = cam.z; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  if (opts.labels) for (let i = 1; i < C.length; i++) {
    const c = C[i]; if (!c.alive) continue;
    const sx = cam.x + (c.sumX / c.cells) * z, sy = cam.y + (c.sumY / c.cells) * z;
    if (sx < -60 || sx > VW + 60 || sy < -30 || sy > VH + 30) continue;
    const extent = Math.sqrt(c.cells) * z, fs = clamp(extent * 0.09 + 6, 9, 15);
    if (extent > 22 + c.name.length * 3.2) { ctx.font = `700 ${fs}px "Segoe UI",system-ui,sans-serif`; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(6,5,2,.88)'; ctx.strokeText(c.name, sx, sy + 14); ctx.fillStyle = '#f6edd2'; ctx.fillText(c.name, sx, sy + 14); }
  }
  if (opts.capitals) for (let i = 1; i < C.length; i++) {
    const c = C[i]; if (!c.alive || c.capHex < 0) continue;
    if (z < 2.6 && !c.wars.size && !(c.planted && z > 0.9) && selected !== i) continue;
    const sx = cam.x + hcx[c.capHex] * z, sy = cam.y + hcy[c.capHex] * z;
    if (sx < -30 || sx > VW + 30 || sy < -30 || sy > VH + 30) continue;
    if (c.planted && hown[c.capHex] === i) drawPole(c, sx, sy, now); else icon(P_STAR, sx, sy, 11, false, '#e6c88a');
    if (c.wars.size) { ctx.beginPath(); ctx.arc(sx + 9, sy - 9, 8, 0, 6.283); ctx.fillStyle = '#b3261e'; ctx.fill(); icon(P_SWORDS, sx + 9, sy - 9, 12, true, '#fff', 2); }
  }
  for (let i = fxs.length - 1; i >= 0; i--) {
    const f = fxs[i], k = (now - f.t0) / (f.kind === 'cap' ? 1100 : 600);
    if (k >= 1) { fxs.splice(i, 1); continue; }
    const sx = cam.x + f.x * z, sy = cam.y + f.y * z;
    ctx.globalAlpha = 1 - k; ctx.strokeStyle = f.color; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(sx, sy, 5 + k * (f.kind === 'cap' ? 22 : 12), 0, 6.283); ctx.stroke();
    if (f.kind === 'cap') icon(P_SWORDS, sx, sy - k * 10, 14, true, '#fff', 2);
    ctx.globalAlpha = 1;
  }
  if (drawSt.on) drawPreview();
  else for (const h of ptrs.values()) {
    if (h.cid == null || h.moved || mode !== 'war') continue;
    const p = h.done ? 1 : Math.min(1, (now - h.t0) / HOLD_MS);
    ctx.beginPath(); ctx.arc(h.sx, h.sy, 28, 0, 6.283); ctx.fillStyle = h.done ? 'rgba(230,200,138,.3)' : 'rgba(6,5,2,.45)'; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.stroke();
    ctx.beginPath(); ctx.arc(h.sx, h.sy, 28, -Math.PI / 2, -Math.PI / 2 + p * 6.283); ctx.lineWidth = 4; ctx.strokeStyle = '#e6c88a'; ctx.lineCap = 'round'; ctx.stroke();
  }
}
function drawPole(c, sx, sy, now) {
  const k = clamp((now - c.plantT) / 900, 0, 1), e = 1 - Math.pow(1 - k, 3), ph = 26 * e, fw = 22 * e, fh = 14 * e;
  ctx.lineCap = 'round';
  ctx.strokeStyle = '#0a0a08'; ctx.lineWidth = 3.4; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx, sy - ph); ctx.stroke();
  ctx.strokeStyle = '#e8e2d0'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx, sy - ph); ctx.stroke();
  if (fw > 2) { const bmp = ensureFlag(c); ctx.save(); ctx.beginPath(); ctx.rect(sx + 1, sy - ph, fw, fh); ctx.clip(); if (bmp) ctx.drawImage(bmp, sx + 1, sy - ph, fw, fh); else { ctx.fillStyle = c.color; ctx.fillRect(sx + 1, sy - ph, fw, fh); } ctx.restore(); ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 1; ctx.strokeRect(sx + 1, sy - ph, fw, fh); }
  ctx.beginPath(); ctx.arc(sx, sy, 2.4, 0, 6.283); ctx.fillStyle = '#e8e2d0'; ctx.fill();
}

/* ================= desenhar territórios ================= */
const drawSt = { on: false, pts: [], marks: [], target: null, take: true };
function startDraw(target) {
  drawSt.on = true; drawSt.pts = []; drawSt.marks = []; drawSt.target = target == null ? null : target; drawSt.take = true;
  $('#dbTake .switch').classList.add('on');
  $('#dbTxt').textContent = target == null ? 'Arraste para desenhar ou toque para marcar pontos' : `Expandindo ${C[target].name}. Arraste ou toque nos pontos`;
  $('#drawbar').classList.remove('hidden');
  closeSettings(); closeSheet(); closeHub(); sticky = null; updateArm(); requestDraw();
}
function stopDraw() { drawSt.on = false; drawSt.pts = []; drawSt.marks = []; $('#drawbar').classList.add('hidden'); requestDraw(); }
function drawPreview() {
  const pts = drawSt.pts; if (!pts.length) return;
  ctx.save(); ctx.beginPath();
  pts.forEach((p, i) => { const x = cam.x + p[0] * cam.z, y = cam.y + p[1] * cam.z; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
  if (pts.length > 2) { ctx.save(); ctx.closePath(); ctx.fillStyle = 'rgba(230,200,138,.22)'; ctx.fill(); ctx.restore(); }
  ctx.strokeStyle = '#e6c88a'; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();
  if (pts.length > 2) { const a = pts[pts.length - 1], b = pts[0]; ctx.beginPath(); ctx.setLineDash([6, 6]); ctx.moveTo(cam.x + a[0] * cam.z, cam.y + a[1] * cam.z); ctx.lineTo(cam.x + b[0] * cam.z, cam.y + b[1] * cam.z); ctx.lineWidth = 1.8; ctx.strokeStyle = 'rgba(230,200,138,.7)'; ctx.stroke(); ctx.setLineDash([]); }
  for (const i of drawSt.marks) { const p = pts[i]; if (!p) continue; ctx.beginPath(); ctx.arc(cam.x + p[0] * cam.z, cam.y + p[1] * cam.z, 4.5, 0, 6.283); ctx.fillStyle = '#f6edd2'; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = '#7a1a1a'; ctx.stroke(); }
  ctx.restore();
}
function pointInPoly(x, y, pts) { let inside = false; for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) { const xi = pts[i][0], yi = pts[i][1], xj = pts[j][0], yj = pts[j][1]; if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside; } return inside; }
function hexesInPolygon(pts) {
  let minx = 1e9, miny = 1e9, maxx = -1e9, maxy = -1e9;
  for (const p of pts) { minx = Math.min(minx, p[0]); maxx = Math.max(maxx, p[0]); miny = Math.min(miny, p[1]); maxy = Math.max(maxy, p[1]); }
  const r0 = clamp(Math.floor((miny - HS) / HV) - 1, 0, HR - 1), r1 = clamp(Math.ceil((maxy + HS) / HV) + 1, 0, HR - 1);
  const c0 = clamp(Math.floor(minx / HW) - 1, 0, HC - 1), c1 = clamp(Math.ceil(maxx / HW) + 1, 0, HC - 1);
  const out = [];
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) { const i = r * HC + c; if (pointInPoly(hcx[i], hcy[i], pts)) out.push(i); }
  return out;
}

/* ================= interação no mapa ================= */
const ptrs = new Map();
let pinchBase = null;
function pt(e) { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
canvas.addEventListener('pointerdown', e => {
  if (!running) return; if (e.pointerType === 'mouse' && e.button !== 0) return;
  tween = null; const [sx, sy] = pt(e);
  ptrs.set(e.pointerId, { sx, sy, x0: sx, y0: sy, t0: performance.now(), cid: drawSt.on ? null : countryAt(sx, sy), done: false, moved: false });
  try { canvas.setPointerCapture(e.pointerId); } catch (_) { }
  if (ptrs.size === 2) { const a = [...ptrs.values()], mx = (a[0].sx + a[1].sx) / 2, my = (a[0].sy + a[1].sy) / 2; pinchBase = { d0: Math.hypot(a[0].sx - a[1].sx, a[0].sy - a[1].sy) || 1, z0: cam.z, mx0: toMapX(mx), my0: toMapY(my) }; }
  requestDraw();
});
canvas.addEventListener('pointermove', e => {
  const h = ptrs.get(e.pointerId); if (!h) return;
  const [sx, sy] = pt(e), dx = sx - h.sx, dy = sy - h.sy; h.sx = sx; h.sy = sy;
  if (ptrs.size === 1) {
    if (drawSt.on) {
      if (!h.moved && Math.hypot(sx - h.x0, sy - h.y0) > DRAW_PX) { h.moved = true; drawSt.marks.push(drawSt.pts.length); drawSt.pts.push([toMapX(h.x0), toMapY(h.y0)]); }
      if (h.moved) { const l = drawSt.pts[drawSt.pts.length - 1]; if (Math.hypot(sx - (cam.x + l[0] * cam.z), sy - (cam.y + l[1] * cam.z)) > 4) drawSt.pts.push([toMapX(sx), toMapY(sy)]); requestDraw(); }
      return;
    }
    if (!h.moved && Math.hypot(sx - h.x0, sy - h.y0) > MOVE_PX) h.moved = true;
    if (h.moved) { cam.x += dx; cam.y += dy; clampCam(); requestDraw(); }
  } else if (ptrs.size === 2 && pinchBase) {
    const a = [...ptrs.values()], d = Math.hypot(a[0].sx - a[1].sx, a[0].sy - a[1].sy) || 1, mx = (a[0].sx + a[1].sx) / 2, my = (a[0].sy + a[1].sy) / 2;
    const moved = Math.abs(d - pinchBase.d0) > MOVE_PX || a.some(p => Math.hypot(p.sx - p.x0, p.sy - p.y0) > MOVE_PX);
    if (moved) { a.forEach(p => { p.moved = true; }); cam.z = clamp(pinchBase.z0 * d / pinchBase.d0, minZoom(), MAXZ); cam.x = mx - pinchBase.mx0 * cam.z; cam.y = my - pinchBase.my0 * cam.z; clampCam(); requestDraw(); }
  }
});
function release(e, tap) {
  const h = ptrs.get(e.pointerId); if (!h) return;
  const wasOne = ptrs.size === 1; ptrs.delete(e.pointerId);
  if (ptrs.size === 1) { const o = [...ptrs.values()][0]; if (pinchBase) o.moved = true; }
  if (ptrs.size === 0) pinchBase = null;
  if (tap && drawSt.on) { if (wasOne && !h.moved && performance.now() - h.t0 < 700) { drawSt.marks.push(drawSt.pts.length); drawSt.pts.push([toMapX(h.x0), toMapY(h.y0)]); } }
  else if (tap && !h.moved && !h.done && performance.now() - h.t0 < TAP_MS) onTap(h.cid);
  requestDraw();
}
canvas.addEventListener('pointerup', e => release(e, true));
canvas.addEventListener('pointercancel', e => release(e, false));
canvas.addEventListener('contextmenu', e => e.preventDefault());
canvas.addEventListener('wheel', e => { e.preventDefault(); const [sx, sy] = pt(e), mx = toMapX(sx), my = toMapY(sy); cam.z = clamp(cam.z * Math.exp(-e.deltaY * 0.0015), minZoom(), MAXZ); cam.x = sx - mx * cam.z; cam.y = sy - my * cam.z; clampCam(); requestDraw(); }, { passive: false });
canvas.addEventListener('dblclick', e => { if (drawSt.on) return; const [sx, sy] = pt(e); animateTo(toMapX(sx), toMapY(sy), cam.z * 2); });
function zoomBy(f) { animateTo((VW / 2 - cam.x) / cam.z, (VH / 2 - cam.y) / cam.z, cam.z * f, 300); }
$('#zIn').onclick = () => zoomBy(1.8); $('#zOut').onclick = () => zoomBy(1 / 1.8); $('#zFit').onclick = () => animateTo(W / 2, H / 2, minZoom(), 700);

function updateHolds(now) {
  if (mode !== 'war' || drawSt.on) return;
  for (const [pid, h] of ptrs) { if (h.done || h.moved || h.cid == null || h.cid === 0) continue; if (now - h.t0 >= HOLD_MS) { h.done = true; if (navigator.vibrate) navigator.vibrate(25); onHoldComplete(pid, h); } }
}
function onHoldComplete(pid, h) {
  const cid = h.cid; if (cid == null || !cid || !C[cid].alive) return;
  let other = null;
  for (const [p2, h2] of ptrs) if (p2 !== pid && h2.done && !h2.moved && h2.cid && h2.cid !== cid && C[h2.cid].alive) { other = h2.cid; break; }
  if (other == null && sticky && sticky.country !== cid && C[sticky.country].alive && performance.now() - sticky.t < ARM_WINDOW) other = sticky.country;
  if (other != null) { sticky = null; declareWar(other, cid); } else if (sticky && sticky.country === cid) sticky.t = performance.now(); else sticky = { country: cid, t: performance.now() };
  updateArm();
}
function onTap(cid) {
  if (!cid) { sticky = null; allyPick = null; if (selected != null) closeSheet(); updateArm(); return; }
  if (mode === 'war') openSheet(cid);
  else if (mode === 'ally') { if (allyPick == null) { allyPick = cid; toast(`${C[cid].name} escolhido. Toque em outro país.`); } else if (allyPick === cid) allyPick = null; else { toggleAlliance(allyPick, cid); allyPick = null; } }
  else if (mode === 'peace') makePeace(cid);
  requestDraw();
}
function updateArm() {
  const bar = $('#armbar');
  if (sticky && performance.now() - sticky.t > ARM_WINDOW) sticky = null;
  if (!sticky || !world) { bar.classList.add('hidden'); return; }
  bar.classList.remove('hidden'); $('#armTxt').textContent = `${C[sticky.country].name} pronto. Segure outro país para declarar guerra.`;
  $('#armFill').style.width = Math.max(0, 100 - (performance.now() - sticky.t) / ARM_WINDOW * 100) + '%';
}
setInterval(() => { if (!running) return; const had = !!sticky; updateArm(); if (had && !sticky) requestDraw(); }, 200);

/* ================= guerra hex a hex ================= */
function log(text, kind, cid) { events.unshift({ day, text, kind, cid: cid || 0 }); if (events.length > 200) events.pop(); pokeHub('events'); }
function startWar(a, b) { const w = { a, b, start: day, landing: null }; wars.push(w); C[a].wars.add(b); C[b].wars.add(a); warDirty = true; dirtySave = true; return w; }
function declareWar(a, b) {
  if (a === b || !C[a].alive || !C[b].alive) return false;
  if (atWar(a, b)) { toast(`${C[a].name} e ${C[b].name} já estão em guerra`); return false; }
  if (C[a].allies.has(b)) { C[a].allies.delete(b); C[b].allies.delete(a); log(`A aliança entre ${C[a].name} e ${C[b].name} foi rompida`, 'war', a); }
  startWar(a, b); log(`${C[a].name} declarou guerra a ${C[b].name}`, 'war', a); toast(`${C[a].name} declarou guerra a ${C[b].name}`);
  if (opts.allyJoin) {
    const join = (side, foe) => { for (const x of [...C[side].allies]) { if (x === foe || !C[x].alive || atWar(x, foe)) continue; if (C[x].allies.has(foe)) { C[x].allies.delete(foe); C[foe].allies.delete(x); } if (Math.random() < 0.8) { startWar(x, foe); log(`${C[x].name} entrou na guerra ao lado de ${C[side].name}`, 'war', x); } } };
    join(a, b); join(b, a);
  }
  refreshAll(); return true;
}
function endWar(w, why, silent) {
  const i = wars.indexOf(w); if (i < 0) return;
  wars.splice(i, 1); C[w.a].wars.delete(w.b); C[w.b].wars.delete(w.a); warDirty = true; dirtySave = true;
  if (!silent) { const t = `Cessar-fogo entre ${C[w.a].name} e ${C[w.b].name}${why ? ' (' + why + ')' : ''}`; log(t, 'peace', w.a); toast(t); }
}
function makePeace(cid) { const mine = wars.filter(w => w.a === cid || w.b === cid); if (!mine.length) { toast(`${C[cid].name} não está em guerra`); return; } mine.forEach(w => endWar(w, 'pedido de paz', false)); refreshAll(); }
function toggleAlliance(a, b) {
  if (C[a].allies.has(b)) { C[a].allies.delete(b); C[b].allies.delete(a); log(`${C[a].name} e ${C[b].name} romperam a aliança`, 'ally', a); toast('Aliança desfeita'); }
  else if (atWar(a, b)) { toast('Países em guerra não podem se aliar. Use Paz antes.'); return; }
  else { C[a].allies.add(b); C[b].allies.add(a); log(`${C[a].name} e ${C[b].name} firmaram uma aliança`, 'ally', a); toast(`${C[a].name} e ${C[b].name} agora são aliados`); }
  dirtySave = true; refreshAll();
}
function randHex(cid) { const arr = hexOwnerArr[cid]; return arr && arr.length ? arr[(Math.random() * arr.length) | 0] : -1; }
function findFrontier(att, def) {
  for (let t = 0; t < 30; t++) { const i = randHex(att); if (i < 0) break; for (let k = 0; k < 6; k++) { const j = hexNb(i, k); if (j >= 0 && hown[j] === def) return [i, j, 1]; } }
  for (let t = 0; t < 30; t++) { const i = randHex(def); if (i < 0) break; for (let k = 0; k < 6; k++) { const j = hexNb(i, k); if (j >= 0 && hown[j] === att) return [j, i, 1]; } }
  return null;
}
function landingFor(w, att, def) {
  const key = att < def ? 'ab' : 'ba';
  if (w.landing && hown[w.landing[0]] === att && hown[w.landing[1]] === def) return w.landing;
  const A = hexOwnerArr[att], D = hexOwnerArr[def]; if (!A || !D || !A.length || !D.length) return null;
  let bestA = null, bestD = null, bd = 1e18;
  for (let t = 0; t < 70; t++) {
    const ai = A[(Math.random() * A.length) | 0], di = D[(Math.random() * D.length) | 0];
    const d = (hcx[ai] - hcx[di]) ** 2 + (hcy[ai] - hcy[di]) ** 2;
    if (d < bd) { bd = d; bestA = ai; bestD = di; }
  }
  if (bestA == null) return null;
  w.landing = [bestA, bestD]; return w.landing;
}
function clash(w, att, def) {
  const A = C[att], D = C[def]; if (!A.alive || !D.alive) return;
  let pair = findFrontier(att, def), amph = 1;
  if (!pair) { pair = landingFor(w, att, def); if (!pair) return; amph = 0.62; }
  const [ai, di] = pair;
  const pa = Math.sqrt(A.army) * (1 + A.tech * 0.14) * (0.45 + A.morale / 180) * (0.7 + Math.random() * 0.6) * amph * (0.85 + A.eco / 400);
  let pd = Math.sqrt(D.army) * (1 + D.tech * 0.14) * (0.45 + D.morale / 180) * (0.7 + Math.random() * 0.6) * 1.2 * (0.85 + D.eco / 400);
  if (di === D.capHex) pd *= 1.55; else { for (let k = 0; k < 6; k++) { const j = hexNb(D.capHex, k); if (j === di) { pd *= 1.18; break; } } }
  const win = pa > pd;
  const la = A.army * (0.003 + Math.random() * 0.006) * (win ? 0.7 : 1.3), ld = D.army * (0.003 + Math.random() * 0.006) * (win ? 1.3 : 0.8);
  A.army = Math.max(0, A.army - la); D.army = Math.max(0, D.army - ld); A.lost += la; D.lost += ld; casualties += la + ld;
  if (win) { D.morale = Math.max(0, D.morale - 2.5); A.morale = Math.min(100, A.morale + 1.5); } else { A.morale = Math.max(0, A.morale - 1); D.morale = Math.min(100, D.morale + 1); }
  addFx(win ? 'cap' : 'clash', di, A.color);
  if (win) capture(di, att);
}
function capture(hex, att) {
  const def = hown[hex]; if (!def || def === att) return;
  const wasCap = hex === C[def].capHex;
  if (flagOn(C[def])) markFlagDirty(def); if (flagOn(C[att])) markFlagDirty(att);
  setHexOwnerData(hex, att);
  paintHex(hex); invalidateCountryPath(def); invalidateCountryPath(att); warDirty = true;
  if (wasCap) capitulate(def, att, 'capital tomada'); else if (C[def].cells <= 0) capitulate(def, att, 'território perdido');
}
function capitulate(loser, winner, why) {
  const L = C[loser], Wn = C[winner];
  const arr = (hexOwnerArr[loser] || []).slice();
  for (const h of arr) setHexOwnerData(h, winner);
  L.cells = 0; L.alive = false;
  for (const w of [...wars]) if (w.a === loser || w.b === loser) endWar(w, null, true);
  for (let i = 1; i < C.length; i++) C[i].allies.delete(loser);
  L.allies.clear(); Wn.morale = Math.min(100, Wn.morale + 12);
  const t = `${Wn.name} anexou ${L.name} (${why})`; log(t, 'fall', winner); toast(t);
  if (selected === loser) closeSheet(); if (sticky && sticky.country === loser) sticky = null; if (allyPick === loser) allyPick = null;
  paintAllHex(); invalidateCountryPath(loser); invalidateCountryPath(winner); pathCache.clear();
}
function checkEnd() {
  let alive = 0, last = 0; for (let i = 1; i < C.length; i++) if (C[i].alive && C[i].iso !== 'AQ') { alive++; last = i; }
  if (alive === 1 && !ended && C.length > 3) { ended = true; paused = true; syncPlay(); const t = `${C[last].name} domina o mundo inteiro`; log(t, 'fall', last); toast(t); }
}
function tick() {
  day++;
  for (let i = 1; i < C.length; i++) {
    const c = C[i]; if (!c.alive) continue; const war = c.wars.size > 0;
    const income = (c.pop * 0.35 + c.cells * 0.06) * (0.3 + c.eco / 60) + c.tech * 0.6;
    c.treasury = Math.max(-500, c.treasury + income - c.army * (war ? 0.16 : 0.05));
    if (c.treasury < 0) { c.morale = Math.max(0, c.morale - 0.4); c.army *= 0.998; } else c.army = Math.min(c.pop * 12 + 60, c.army + (c.pop * 0.004 + c.cells * 0.006) * (0.4 + c.ind / 60) * (war ? 0.6 : 1));
    if (!war) c.morale = Math.min(100, c.morale + 0.3);
  }
  for (const w of [...wars]) { if (!wars.includes(w)) continue; clash(w, w.a, w.b); if (wars.includes(w)) clash(w, w.b, w.a); }
  if (opts.fatigue) for (const w of [...wars]) { if (!wars.includes(w)) continue; const A = C[w.a], B = C[w.b]; if (A.morale < 30 && B.morale < 30 && Math.random() < 0.08) endWar(w, 'cansaço de guerra'); else if (day - w.start > 150 && Math.random() < 0.01) endWar(w, 'cansaço de guerra'); }
  for (let i = 1; i < C.length; i++) { const c = C[i]; if (c.alive && c.wars.size && (c.morale < 6 || c.army < 1)) { let foe = null; for (const f of c.wars) if (foe === null || C[f].army > C[foe].army) foe = f; if (foe !== null) capitulate(c.id, foe, 'rendição'); } }
  flushFlagDirty(); dirtySave = true; checkEnd(); refreshAll();
}
let timer = null;
function loop() { clearTimeout(timer); if (paused || !running) return; timer = setTimeout(() => { tick(); loop(); }, 750 / SPEEDS[speedIdx]); }
function syncPlay() { $('#playUse').setAttribute('href', paused ? '#i-play' : '#i-pause'); $('#playTxt').textContent = paused ? 'Retomar' : 'Pausar'; loop(); }
function refreshAll() { updateHud(); updateSheet(); pokeHub(); requestDraw(); }
function updateHud() { let alive = 0; for (let i = 1; i < C.length; i++) if (C[i].alive) alive++; $('#hDay').textContent = day; $('#hWars').textContent = wars.length; $('#hAlive').textContent = alive; $('#hDead').textContent = fmt(casualties); }
function killCountry(cid, why) { const c = C[cid]; c.alive = false; for (const w of [...wars]) if (w.a === cid || w.b === cid) endWar(w, null, true); for (let i = 1; i < C.length; i++) C[i].allies.delete(cid); c.allies.clear(); if (selected === cid) closeSheet(); if (why) log(`${c.name} deixou de existir (${why})`, 'fall', cid); }

/* ================= criar, expandir e excluir territórios ================= */
function uniqueName(base) { const used = new Set(C.filter(Boolean).map(c => c.name)); if (!used.has(base)) return base; for (let i = 2; i < 999; i++) if (!used.has(`${base} ${i}`)) return `${base} ${i}`; return base; }
function ensureContEditable() { if (CONT === REAL_CONT) CONT = JSON.parse(JSON.stringify(REAL_CONT)); }
function createTerritory(hexList, target) {
  let cid = target, created = false;
  if (cid == null) { cid = C.length; const c = makeCountry(cid, { iso: 'X' + cid, name: uniqueName('Novo território'), cont: 'NEW', pw: 30, ext: 'gen', cap: null }); c.keep = true; C.push(c); hexOwnerArr.push([]); created = true; }
  const lost = new Set();
  for (const i of hexList) { const old = hown[i]; if (old && old !== cid) lost.add(old); if (old !== cid) { if (flagOn(C[old] || {})) markFlagDirty(old); setHexOwnerData(i, cid); } }
  const c = C[cid];
  if (created) {
    pickColorForHexes(cid, hexList);
    const cnt = {}; lost.forEach(o => { const k = C[o].cont; cnt[k] = (cnt[k] || 0) + 1; }); const best = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a])[0];
    c.cont = best && CONT[best] ? best : 'NEW'; if (c.cont === 'NEW' && !CONT.NEW) { ensureContEditable(); CONT.NEW = { n: 'Territórios criados' }; }
    c.capHex = findCapitalHex(cid, null); c.totalHex = c.cells; c.capName = 'Capital de ' + c.name; initOne(c, (world && world.seed) || 7);
  } else { c.totalHex = Math.max(c.totalHex, c.cells); if (!c.alive && c.cells > 0) { c.alive = true; if (c.capHex < 0) c.capHex = findCapitalHex(cid, null); } }
  lost.forEach(o => { if (C[o].cells <= 0 && C[o].alive) killCountry(o, 'território tomado'); });
  paintAllHex(); pathCache.clear(); dirtySave = true; refreshAll();
  return cid;
}
function deleteCountry(cid) {
  const arr = (hexOwnerArr[cid] || []).slice(); for (const h of arr) setHexOwnerData(h, 0);
  const c = C[cid]; c.deleted = true; c.keep = false; c.alive = false;
  for (const w of [...wars]) if (w.a === cid || w.b === cid) endWar(w, null, true);
  for (let i = 1; i < C.length; i++) C[i].allies.delete(cid);
  c.allies.clear(); closeSheet(); paintAllHex(); pathCache.clear(); dirtySave = true; refreshAll(); toast(`${c.name} foi apagado do mapa`);
}
function confirmDraw() {
  if (drawSt.pts.length < 3) { toast('Marque ao menos 3 pontos'); return; }
  let hexList = hexesInPolygon(drawSt.pts);
  if (!drawSt.take) hexList = hexList.filter(i => hown[i] === 0);
  if (hexList.length < 3) { toast(drawSt.take ? 'Território muito pequeno' : 'Nada livre nessa área. Ative "Tomar terra".'); return; }
  const target = drawSt.target; stopDraw();
  const cid = createTerritory(hexList, target);
  flyCountry(cid); openSheet(cid, target == null);
  toast(target == null ? 'Território criado. Ajuste nome, bandeira e poder.' : 'Território expandido');
}
$('#dbUndo').onclick = () => { if (!drawSt.marks.length) return; drawSt.pts.length = drawSt.marks.pop(); requestDraw(); };
$('#dbClear').onclick = () => { drawSt.pts = []; drawSt.marks = []; requestDraw(); };
$('#dbCancel').onclick = () => { stopDraw(); };
$('#dbOk').onclick = confirmDraw;
$('#dbTake').onclick = () => { drawSt.take = !drawSt.take; $('#dbTake .switch').classList.toggle('on', drawSt.take); };

/* ================= ficha do país ================= */
const SLIDERS = [
  ['eco', 'Economia', 0, 100, 1, 'coin'], ['army', 'Exército', 0, 8000, 5, 'soldier'], ['tech', 'Tecnologia', 1, 10, 1, 'chip'],
  ['morale', 'Moral', 0, 100, 1, 'heart'], ['ind', 'Indústria', 0, 100, 1, 'bolt'], ['pop', 'População', 0.1, 1600, 0.1, 'globe'], ['treasury', 'Tesouro', 0, 9000, 10, 'coin']
];
let dragging = false;
function openSheet(cid, isNew) { closeSettings(); selected = cid; buildSheet(isNew); $('#sheet').classList.remove('hidden'); requestDraw(); }
function closeSheet() { selected = null; $('#sheet').classList.add('hidden'); requestDraw(); }
function contOptions(sel) { return Object.entries(CONT).map(([k, v]) => `<option value="${k}" ${k === sel ? 'selected' : ''}>${esc(v.n)}</option>`).join(''); }
function buildSheet(isNew) {
  const c = C[selected], sh = $('#sheet');
  sh.innerHTML = `
  <div class="s-head">
    <div class="flag" id="sFlag"></div>
    <div class="s-title"><input id="sName" value="${esc(c.name)}" maxlength="24" spellcheck="false" autocomplete="off">
      <div class="s-meta"><span>${ICON('pin')}<i id="mCap"></i></span><span>${ICON('globe')}<i id="mCont"></i></span></div>
      <div class="tags" id="sTags"></div></div>
    <button class="x" id="sClose" aria-label="Fechar">${ICON('close')}</button>
  </div>
  <div class="tiles">
    <div class="tile">${ICON('flag')}<div><small>Território</small><b id="tCells"></b></div></div>
    <div class="tile">${ICON('skull')}<div><small>Baixas</small><b id="tLost"></b></div></div>
  </div>
  <div class="power-meter">
    <div class="pm-n" id="pmN">0</div>
    <div class="pm-t"><b id="pmT">Poder do país</b><i class="pm-bar"><u id="pmB" style="width:0"></u></i></div>
  </div>
  <div class="flagpanel">
    <div class="fp-head">${ICON('image')}<span>Bandeira no território</span></div>
    <div class="fbtns">
      <button class="fbtn" id="fbDef">${ICON('flag')}Padrão</button>
      <button class="fbtn" id="fbGal">${ICON('layers')}Galeria</button>
      <button class="fbtn" id="fbGen">${ICON('pencil')}Criar</button>
      <label class="fbtn" id="fbFile" for="fileFlag">${ICON('upload')}Arquivo</label>
      <button class="fbtn" id="fbOff">${ICON('trash')}Remover</button>
    </div>
    <div class="frow"><span>Opacidade das bandeiras</span><input type="range" id="fOp" min="30" max="100" step="2" style="width:46%"></div>
  </div>
  <details class="more" ${isNew ? '' : 'open'}><summary>Poder do país</summary>
    <div class="presets"><button data-p="weak">Fraco</button><button data-p="mid">Médio</button><button data-p="strong">Forte</button><button data-p="super">Superpotência</button></div>
    ${SLIDERS.map(s => `<label class="sl">${ICON(s[5])}<span>${s[1]}</span><input type="range" data-k="${s[0]}" min="${s[2]}" max="${s[3]}" step="${s[4]}"><output data-o="${s[0]}"></output></label>`).join('')}
  </details>
  <details class="more" ${isNew ? 'open' : ''}><summary>Identidade e território</summary>
    <label class="fld">Capital<input class="txt" id="sCap" maxlength="28" value="${esc(c.capName || '')}"></label>
    <label class="fld">Continente<select class="txt" id="sCont">${contOptions(c.cont)}</select></label>
    <div class="swatches">${PALETTE.map(p => `<button class="sw" data-c="${p}" style="background:${p}" aria-label="Cor"></button>`).join('')}</div>
    <div class="s-actions" style="margin:10px 0 8px"><button class="btn" id="sExpand">${ICON('pencil')}Expandir</button><button class="btn" id="sDel" style="color:var(--war)">${ICON('trash')}Apagar</button></div>
  </details>
  <div class="s-actions"><button class="btn" id="sZoom">${ICON('fit')}Ver no mapa</button><button class="btn peace" id="sPeace">${ICON('peace')}Cessar-fogo</button></div>`;
  $('#sClose').onclick = closeSheet;
  $('#sName').addEventListener('input', e => { c.name = e.target.value.trim() || c.name; dirtySave = true; requestDraw(); pokeHub('countries'); pokeHub('ranking'); });
  $('#sCap').addEventListener('input', e => { c.capName = e.target.value; $('#mCap').textContent = c.capName; dirtySave = true; });
  $('#sCont').addEventListener('change', e => { c.cont = e.target.value; $('#mCont').textContent = CONT[c.cont] ? CONT[c.cont].n : ''; dirtySave = true; pokeHub(); });
  sh.querySelectorAll('input[type=range][data-k]').forEach(inp => {
    inp.addEventListener('pointerdown', () => { dragging = true; });
    inp.addEventListener('input', () => { c[inp.dataset.k] = +inp.value; dirtySave = true; refreshPower(c); sh.querySelector(`[data-o="${inp.dataset.k}"]`).textContent = valText(inp.dataset.k, c); pokeHub('ranking'); });
  });
  sh.querySelectorAll('.presets button').forEach(b => b.addEventListener('click', () => { applyPreset(c, b.dataset.p); updateSheet(true); pokeHub('ranking'); }));
  $('#fOp').addEventListener('input', e => { flagOp = e.target.value / 100; dirtySave = true; requestDraw(); });
  sh.querySelectorAll('.sw').forEach(b => b.addEventListener('click', () => {
    c.color = b.dataset.c; c.rgb = hex2rgb(c.color);
    if (flagSrcOf(c) === 'GEN') { c.genURL = null; if (!c.custom) { c.bmp = null; c.bmpState = 0; } }
    paintAllHex(); pathCache.clear(); dirtySave = true; updateSheet(true); requestDraw(); pokeHub();
  }));
  $('#fbDef').onclick = () => plantDefault(c.id);
  $('#fbGal').onclick = () => openGallery(c.id);
  $('#fbGen').onclick = () => openGenerator(c.id);
  $('#fbFile').addEventListener('click', () => { flagTarget = c.id; });
  $('#fbOff').onclick = () => removeFlag(c.id);
  $('#sPeace').onclick = () => makePeace(c.id);
  $('#sZoom').onclick = () => flyCountry(c.id);
  $('#sExpand').onclick = () => startDraw(c.id);
  $('#sDel').onclick = () => askConfirm('Apagar país', `Apagar ${c.name} do mapa? O território vira oceano.`, () => deleteCountry(c.id), { ok: 'Apagar', danger: true });
  updateSheet(true);
  if (isNew) { const n = $('#sName'); n.focus(); n.select(); }
}
window.addEventListener('pointerup', () => { dragging = false; });
function applyPreset(c, k) { const P = { weak: [20, 15, 2, 60, 0.4, 15], mid: [45, 40, 4, 72, 1.2, 30], strong: [70, 65, 7, 82, 2.2, 60], super: [95, 90, 10, 92, 3.2, 100] }[k]; c.eco = P[0]; c.ind = P[1]; c.tech = P[2]; c.morale = P[3]; c.army = c.pop * P[4] + P[5]; c.treasury = 100 + c.eco * 12; dirtySave = true; }
function valText(k, c) { return k === 'army' ? fmt(c.army) : k === 'pop' ? fmtPop(c.pop) : k === 'treasury' ? Math.round(c.treasury) : k === 'tech' ? c.tech : Math.round(c[k]) + (k === 'morale' ? '%' : ''); }
function refreshPower(c) { const s = powerScore(c); let rank = 1, n = 0; for (let i = 1; i < C.length; i++) if (C[i].alive) { n++; if (i !== c.id && powerScore(C[i]) > s) rank++; } $('#pmN').textContent = Math.round(s); $('#pmB').style.width = s + '%'; $('#pmT').textContent = `Poder mundial: ${rank}º de ${n}`; }
function updateSheet(force) {
  if (selected == null) return; const c = C[selected]; if (!c.alive) { closeSheet(); return; } const sh = $('#sheet');
  if (force) {
    $('#sFlag').innerHTML = `<img alt="" src="${flagURL(c)}">`;
    sh.querySelectorAll('.sw').forEach(b => b.classList.toggle('on', b.dataset.c === c.color));
    $('#fbDef').classList.toggle('on', c.planted && !c.custom && !c.flagSrc);
    $('#fbGal').classList.toggle('on', c.planted && !c.custom && !!c.flagSrc);
    $('#fbFile').classList.toggle('on', c.planted && !!c.custom);
    $('#fbOff').classList.toggle('on', !c.planted);
    $('#fOp').value = Math.round(flagOp * 100);
    $('#mCap').textContent = c.capName || 'sem capital'; $('#mCont').textContent = CONT[c.cont] ? CONT[c.cont].n : '';
  }
  $('#tCells').textContent = `${c.cells} de ${c.totalHex} hexágonos`;
  $('#tLost').textContent = fmt(c.lost);
  if (force || !dragging) sh.querySelectorAll('input[type=range][data-k]').forEach(inp => { inp.value = c[inp.dataset.k]; });
  SLIDERS.forEach(s => { const o = sh.querySelector(`[data-o="${s[0]}"]`); if (o) o.textContent = valText(s[0], c); });
  refreshPower(c);
  let tags = '';
  if (c.wars.size) for (const f of c.wars) tags += `<span class="tag war">${ICON('swords')}<i style="background:${C[f].color}"></i>${esc(C[f].name)}</span>`; else tags += `<span class="tag peace">${ICON('peace')}Em paz</span>`;
  for (const a of c.allies) tags += `<span class="tag ally">${ICON('link')}<i style="background:${C[a].color}"></i>${esc(C[a].name)}</span>`;
  $('#sTags').innerHTML = tags; $('#sPeace').disabled = !c.wars.size;
}

/* ================= galeria de bandeiras ================= */
let galTarget = null;
function openGallery(cid) {
  galTarget = cid; const g = $('#gallery');
  g.innerHTML = `<div class="hub-top"><div class="hub-title">${ICON('flag')}<h2>Galeria de bandeiras</h2></div><button id="galClose" class="x" aria-label="Fechar">${ICON('close')}</button></div>
    <label class="hub-search">${ICON('search')}<input id="galSearch" type="text" placeholder="Buscar bandeira" autocomplete="off" spellcheck="false"></label><div id="galGrid" class="gal-grid"></div>`;
  g.classList.remove('hidden'); $('#galClose').onclick = () => g.classList.add('hidden');
  $('#galSearch').addEventListener('input', e => renderGallery(e.target.value));
  renderGallery('');
}
function renderGallery(q) {
  const nq = norm(q), items = M.paises.filter(p => !nq || norm(p.n).includes(nq)).sort((a, b) => a.n.localeCompare(b.n, 'pt'));
  let html = '';
  if (!nq || 'gerada'.includes(nq)) html += `<button class="gtile" data-src="GEN"><img alt="" src="${genFlagCanvas(C[galTarget]).toDataURL()}"><span>Gerada</span></button>`;
  html += items.map(p => `<button class="gtile" data-src="${p.iso}"><img loading="lazy" alt="" src="flags/${p.iso}.${p.f}"><span>${esc(p.n)}</span></button>`).join('');
  $('#galGrid').innerHTML = html || '<p class="empty">Nenhuma bandeira encontrada.</p>';
}
$('#gallery').addEventListener('click', e => { const t = e.target.closest('.gtile'); if (!t || galTarget == null) return; $('#gallery').classList.add('hidden'); plantFrom(galTarget, t.dataset.src); });

/* ================= gerador de bandeiras ================= */
const FLAG_TEMPLATES = [
  ['h2', 'Duas faixas', (g, a, b) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.fillStyle = b; g.fillRect(0, 120, 360, 120); }],
  ['v2', 'Divisão vertical', (g, a, b) => { g.fillStyle = a; g.fillRect(0, 0, 180, 240); g.fillStyle = b; g.fillRect(180, 0, 180, 240); }],
  ['h3', 'Tricolor horizontal', (g, a, b, c) => { g.fillStyle = a; g.fillRect(0, 0, 360, 80); g.fillStyle = b; g.fillRect(0, 80, 360, 80); g.fillStyle = c; g.fillRect(0, 160, 360, 80); }],
  ['v3', 'Tricolor vertical', (g, a, b, c) => { g.fillStyle = a; g.fillRect(0, 0, 120, 240); g.fillStyle = b; g.fillRect(120, 0, 120, 240); g.fillStyle = c; g.fillRect(240, 0, 120, 240); }],
  ['cross', 'Cruz nórdica', (g, a, b) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.fillStyle = b; g.fillRect(0, 96, 360, 48); g.fillRect(120, 0, 48, 240); }],
  ['saltire', 'Cruz diagonal', (g, a, b) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.strokeStyle = b; g.lineWidth = 46; g.beginPath(); g.moveTo(0, 0); g.lineTo(360, 240); g.moveTo(360, 0); g.lineTo(0, 240); g.stroke(); }],
  ['diag', 'Diagonal', (g, a, b) => { g.fillStyle = b; g.fillRect(0, 0, 360, 240); g.fillStyle = a; g.beginPath(); g.moveTo(0, 0); g.lineTo(300, 0); g.lineTo(60, 240); g.lineTo(0, 240); g.fill(); }],
  ['chevron', 'Chevron', (g, a, b) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.fillStyle = b; g.beginPath(); g.moveTo(0, 0); g.lineTo(170, 120); g.lineTo(0, 240); g.closePath(); g.fill(); }],
  ['canton', 'Canhão + faixas', (g, a, b, c) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.fillStyle = b; g.fillRect(0, 80, 360, 80); g.fillStyle = c; g.fillRect(0, 0, 150, 120); }],
  ['circle', 'Círculo central', (g, a, b) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.fillStyle = b; g.beginPath(); g.arc(180, 120, 62, 0, 6.283); g.fill(); }],
  ['sun', 'Sol', (g, a, b, c) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.fillStyle = c; g.save(); g.translate(180, 120); for (let k = 0; k < 12; k++) { g.rotate(Math.PI / 6); g.beginPath(); g.moveTo(0, 0); g.lineTo(-9, -95); g.lineTo(9, -95); g.closePath(); g.fill(); } g.restore(); g.fillStyle = b; g.beginPath(); g.arc(180, 120, 36, 0, 6.283); g.fill(); }],
  ['border', 'Moldura', (g, a, b) => { g.fillStyle = b; g.fillRect(0, 0, 360, 240); g.fillStyle = a; g.fillRect(22, 22, 316, 196); }],
  ['ring', 'Anel', (g, a, b, c) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.strokeStyle = b; g.lineWidth = 18; g.beginPath(); g.arc(180, 120, 58, 0, 6.283); g.stroke(); g.fillStyle = c; g.beginPath(); g.arc(180, 120, 30, 0, 6.283); g.fill(); }],
  ['stripes5', 'Cinco faixas', (g, a, b) => { g.fillStyle = a; g.fillRect(0, 0, 360, 240); g.fillStyle = b; for (let i = 1; i < 5; i += 2) g.fillRect(0, i * 48, 360, 48); }]
];
let genTarget = null, genState = { t: 'h2', a: '#a03a2a', b: '#f0e6c8', c: '#2c2a1a' };
function genDraw(cv, t, a, b, c) { const g = cv.getContext('2d'); g.clearRect(0, 0, 360, 240); const tpl = FLAG_TEMPLATES.find(x => x[0] === t) || FLAG_TEMPLATES[0]; tpl[2](g, a, b, c); g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 3; g.strokeRect(1.5, 1.5, 357, 237); }
function openGenerator(cid) {
  genTarget = cid; genState = { t: 'h2', a: C[cid].color || '#a03a2a', b: '#f0e6c8', c: '#2c2a1a' };
  const g = $('#gallery');
  g.innerHTML = `<div class="hub-top"><div class="hub-title">${ICON('pencil')}<h2>Gerador de bandeiras</h2></div><button id="genClose" class="x" aria-label="Fechar">${ICON('close')}</button></div>
  <div class="gen-body">
    <canvas id="genPrev" width="360" height="240" class="gen-preview"></canvas>
    <div class="gen-colors">
      <label>Cor A<input type="color" id="gcA" value="${genState.a}"></label>
      <label>Cor B<input type="color" id="gcB" value="${genState.b}"></label>
      <label>Cor C<input type="color" id="gcC" value="${genState.c}"></label>
      <button class="btn" id="gRand">${ICON('dice')}Sortear cores</button>
    </div>
    <div class="gen-label">Estilo</div>
    <div class="gen-grid" id="genGrid"></div>
    <button class="btn primary" id="gApply" style="width:100%;margin-top:12px">${ICON('check')}Usar esta bandeira</button>
  </div>`;
  g.classList.remove('hidden');
  const prev = $('#genPrev');
  const redraw = () => genDraw(prev, genState.t, genState.a, genState.b, genState.c);
  $('#genGrid').innerHTML = FLAG_TEMPLATES.map(t => `<button class="gtpl ${t[0] === genState.t ? 'on' : ''}" data-t="${t[0]}"><canvas width="72" height="48"></canvas><span>${t[1]}</span></button>`).join('');
  $('#genGrid').querySelectorAll('.gtpl').forEach(b => { genDraw(b.querySelector('canvas'), b.dataset.t, genState.a, genState.b, genState.c); });
  const refreshThumbs = () => $('#genGrid').querySelectorAll('.gtpl').forEach(b => genDraw(b.querySelector('canvas'), b.dataset.t, genState.a, genState.b, genState.c));
  $('#genClose').onclick = () => g.classList.add('hidden');
  $('#genGrid').addEventListener('click', e => { const b = e.target.closest('.gtpl'); if (!b) return; genState.t = b.dataset.t; $('#genGrid').querySelectorAll('.gtpl').forEach(x => x.classList.toggle('on', x === b)); redraw(); });
  $('#gcA').addEventListener('input', e => { genState.a = e.target.value; redraw(); refreshThumbs(); });
  $('#gcB').addEventListener('input', e => { genState.b = e.target.value; redraw(); refreshThumbs(); });
  $('#gcC').addEventListener('input', e => { genState.c = e.target.value; redraw(); refreshThumbs(); });
  $('#gRand').onclick = () => { const r = () => PALETTE[(Math.random() * PALETTE.length) | 0]; genState.a = r(); genState.b = Math.random() < 0.5 ? '#f0e6c8' : r(); genState.c = r(); $('#gcA').value = genState.a; $('#gcB').value = genState.b; $('#gcC').value = genState.c; redraw(); refreshThumbs(); };
  $('#gApply').onclick = () => { const cv = mkCanvas(360, 240); genDraw(cv, genState.t, genState.a, genState.b, genState.c); plantCustomCanvas(genTarget, cv); g.classList.add('hidden'); toast(`Bandeira criada para ${C[genTarget].name}`); };
  redraw();
}

/* ================= hub ================= */
let hubOpen = false, hubTab = 'countries', hubCont = 'ALL', hubSort = 'name', hubQuery = '', rankMetric = 'area';
function openHub() { if (!world) return; closeSettings(); hubOpen = true; $('#hub').classList.remove('hidden'); if (selected != null) closeSheet(); renderHub(true); }
function closeHub() { hubOpen = false; $('#hub').classList.add('hidden'); }
function pokeHub(tab) { if (!hubOpen) return; if (tab && hubTab !== tab) return; renderHub(); }
function contMembers(k) { return C.filter(c => c && !c.deleted && c.cont === k); }
function contStats(k) { const cs = contMembers(k); return { list: cs, alive: cs.filter(c => c.alive).length, army: cs.reduce((s, c) => s + (c.alive ? c.army : 0), 0), area: cs.reduce((s, c) => s + c.area, 0), wars: cs.reduce((s, c) => s + (c.alive ? c.wars.size : 0), 0) / 2 }; }
function contBox(k) {
  const v = CONT[k]; if (v && v.box) return v.box;
  let minx = 1e9, maxx = -1, miny = 1e9, maxy = -1;
  for (const c of contMembers(k)) if (c.cells) { const comps = countryComponents(c.id, 6); for (const cp of comps) if (cp.length >= 15) for (const h of cp) { minx = Math.min(minx, hcx[h]); maxx = Math.max(maxx, hcx[h]); miny = Math.min(miny, hcy[h]); maxy = Math.max(maxy, hcy[h]); } }
  if (maxx < 0) return [-180, 180, -70, 84];
  return [minx / RES - 180 - 3, maxx / RES - 180 + 3, LAT0 - maxy / RES - 3, LAT0 - miny / RES + 3];
}
const RANKS = { area: ['Área', c => c.area, v => fmtKm(v)], power: ['Poder', c => powerScore(c), v => Math.round(v) + ' pts'], army: ['Exército', c => c.army, v => fmt(v)], pop: ['População', c => c.pop, v => fmtPop(v)], eco: ['Economia', c => c.eco, v => Math.round(v) + ' pts'], cells: ['Hexágonos', c => c.cells, v => String(v)] };
function renderHub(resetScroll) {
  const body = $('#hubBody'), chips = $('#hubChips'), keep = body.scrollTop;
  $('#hub .hub-search').style.display = hubTab === 'countries' ? '' : 'none';
  document.querySelectorAll('#hub .tab').forEach(t => t.classList.toggle('active', t.dataset.tab === hubTab));
  const real = C.filter(c => c && !c.deleted);
  if (hubTab === 'countries') {
    const cnt = { ALL: real.length }; Object.keys(CONT).forEach(k => { cnt[k] = real.filter(c => c.cont === k).length; });
    if (hubCont !== 'ALL' && !CONT[hubCont]) hubCont = 'ALL';
    chips.style.display = ''; chips.innerHTML = [['ALL', 'Todos'], ...Object.entries(CONT).map(([k, v]) => [k, v.n])].map(([k, n]) => `<button class="hchip2 ${hubCont === k ? 'on' : ''}" data-k="${k}">${esc(n)}<b>${cnt[k] || 0}</b></button>`).join('');
    const q = norm(hubQuery.trim());
    const list = real.filter(c => (hubCont === 'ALL' || c.cont === hubCont) && (!q || norm(c.name).includes(q) || norm(c.capName || '').includes(q) || c.iso.toLowerCase() === q));
    const by = { name: (a, b) => a.name.localeCompare(b.name, 'pt'), army: (a, b) => (b.alive ? b.army : -1) - (a.alive ? a.army : -1), area: (a, b) => b.area - a.area, power: (a, b) => (b.alive ? powerScore(b) : -1) - (a.alive ? powerScore(a) : -1) };
    list.sort(by[hubSort]);
    body.innerHTML = `<div class="sortbar">Ordenar:${[['name', 'Nome'], ['power', 'Poder'], ['area', 'Área'], ['army', 'Exército']].map(([k, n]) => `<button data-s="${k}" class="${hubSort === k ? 'on' : ''}">${n}</button>`).join('')}</div>` +
      (list.length ? list.map(c => `<button class="crow ${c.alive ? '' : 'dead'}" data-id="${c.id}">
        <span class="fl"><img loading="lazy" alt="" src="${flagURL(c)}"></span>
        <span class="rn"><b>${esc(c.name)}</b><small>${esc(c.capName || '')}${c.capName ? ' · ' : ''}${esc(CONT[c.cont] ? CONT[c.cont].n : 'Sem continente')} · ${fmtKm(c.area)}</small></span>
        <span class="rr">${c.alive ? `<span>${Math.round(powerScore(c))} pts</span>${c.wars.size ? `<span class="tag war">${ICON('swords')}${c.wars.size}</span>` : `<span>${c.cells}/${c.totalHex}</span>`}` : '<span>extinto</span>'}</span></button>`).join('') : '<p class="empty">' + (real.length ? 'Nenhum país encontrado.' : 'Ainda não há países. Abra as Configurações e crie um território.') + '</p>');
  } else if (hubTab === 'ranking') {
    chips.style.display = ''; chips.innerHTML = Object.entries(RANKS).map(([k, v]) => `<button class="hchip2 ${rankMetric === k ? 'on' : ''}" data-rk="${k}">${v[0]}</button>`).join('');
    const [nm, get, f] = RANKS[rankMetric];
    const list = real.filter(c => c.alive && c.iso !== 'AQ').map(c => ({ c, v: get(c) })).sort((a, b) => b.v - a.v);
    const max = list.length ? Math.max(list[0].v, 1e-9) : 1;
    body.innerHTML = list.length ? `<div class="rk-head">Ranking por ${nm.toLowerCase()} · atualiza ao vivo</div>` + list.map((o, i) => `<button class="rkrow" data-id="${o.c.id}">
      <span class="rkn n${i < 3 ? i + 1 : 0}">${i + 1}</span><span class="fl"><img loading="lazy" alt="" src="${flagURL(o.c)}"></span>
      <span class="rkm"><b>${esc(o.c.name)}</b><i class="pm-bar"><u style="width:${(o.v / max * 100).toFixed(1)}%;background:${o.c.color}"></u></i></span><span class="rkv">${f(o.v)}</span></button>`).join('') : '<p class="empty">Nenhum país ativo para ranquear.</p>';
  } else if (hubTab === 'continents') {
    chips.style.display = 'none'; const ents = Object.entries(CONT);
    body.innerHTML = `<div class="cb-top"><button class="btn" id="cNew">${ICON('plus')}Criar continente</button></div>` + (ents.length ? ents.map(([k, v]) => {
      const s = contStats(k);
      return `<div class="ccard"><h3>${esc(v.n)}</h3><div class="s-meta"><span>${ICON('flag')}${s.alive} de ${s.list.length} países ativos</span></div>
        <div class="cs"><div>Área<b>${fmtKm(s.area)}</b></div><div>Exército<b>${fmt(s.army)}</b></div><div>Guerras<b>${Math.round(s.wars)}</b></div></div>
        <div class="cb"><button class="btn" data-go="${k}">${ICON('fit')}Ver no mapa</button><button class="btn" data-list="${k}">${ICON('list')}Países</button></div>
        <div class="cb2"><button class="btn" data-ren="${k}">${ICON('edit')}Renomear</button><button class="btn" data-delc="${k}" style="color:var(--war)">${ICON('trash')}Excluir</button></div></div>`;
    }).join('') : '<p class="empty">Sem continentes neste mapa. Crie um e atribua países pela ficha de cada um.</p>');
  } else {
    chips.style.display = 'none'; const iconFor = k => ({ war: 'swords', peace: 'peace', ally: 'link', fall: 'skull' }[k] || 'flag');
    body.innerHTML = events.length ? events.map(e => `<div class="ev ${e.kind}">${ICON(iconFor(e.kind))}<span><small>Dia ${e.day}</small>${esc(e.text)}</span></div>`).join('') : '<p class="empty">Nenhum evento ainda. Segure dois países no mapa para começar uma guerra.</p>';
  }
  body.scrollTop = resetScroll ? 0 : keep;
}
function gotoCountry(id) { if (C[id].alive) { closeHub(); flyCountry(id); openSheet(id); } else toast(`${C[id].name} foi anexado`); }
$('#hub').addEventListener('click', e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.classList.contains('hchip2')) { if (t.dataset.rk) rankMetric = t.dataset.rk; else hubCont = t.dataset.k; renderHub(true); }
  else if (t.dataset.s) { hubSort = t.dataset.s; renderHub(true); }
  else if (t.classList.contains('crow') || t.classList.contains('rkrow')) gotoCountry(+t.dataset.id);
  else if (t.dataset.go) { closeHub(); const b = contBox(t.dataset.go); flyBox(b[0], b[1], b[2], b[3]); }
  else if (t.dataset.list) { hubCont = t.dataset.list; hubTab = 'countries'; renderHub(true); }
  else if (t.id === 'cNew') askText('Novo continente', '', name => { ensureContEditable(); CONT['C' + Date.now().toString(36)] = { n: name }; dirtySave = true; renderHub(); toast(`Continente ${name} criado`); }, { placeholder: 'Nome do continente' });
  else if (t.dataset.ren) { const k = t.dataset.ren; askText('Renomear continente', CONT[k].n, name => { ensureContEditable(); CONT[k].n = name; dirtySave = true; renderHub(); }); }
  else if (t.dataset.delc) { const k = t.dataset.delc, mem = contMembers(k); const doDel = () => { ensureContEditable(); if (mem.length) { if (!CONT.NONE) CONT.NONE = { n: 'Sem continente' }; mem.forEach(c => { c.cont = 'NONE'; }); } delete CONT[k]; dirtySave = true; renderHub(); }; askConfirm('Excluir continente', mem.length ? `${CONT[k].n} tem ${mem.length} países. Eles ficarão em "Sem continente".` : `Excluir ${CONT[k].n}?`, doDel, { ok: 'Excluir', danger: true }); }
  else if (t.classList.contains('tab')) { hubTab = t.dataset.tab; renderHub(true); }
});
$('#hSearch').addEventListener('input', e => { hubQuery = e.target.value; renderHub(true); });
$('#hubClose').onclick = closeHub;
$('#bHub').onclick = () => { hubOpen ? closeHub() : openHub(); };
setInterval(() => { if (hubOpen && hubTab === 'ranking') renderHub(); }, 1000);

/* ================= caixas de diálogo ================= */
function dialog(o, cb) {
  const d = $('#dlg');
  d.innerHTML = `<div class="dlg-card"><h3>${esc(o.title)}</h3>${o.msg ? `<p>${esc(o.msg)}</p>` : ''}${o.input ? `<input class="txt" id="dlgIn" maxlength="${o.max || 32}" value="${esc(o.value || '')}" placeholder="${esc(o.placeholder || '')}" autocomplete="off">` : ''}
    <div class="dlg-b"><button class="btn" id="dlgNo">Cancelar</button><button class="btn ${o.danger ? 'danger' : 'primary'}" id="dlgOk">${esc(o.ok || 'OK')}</button></div></div>`;
  d.classList.remove('hidden');
  const close = () => d.classList.add('hidden');
  $('#dlgNo').onclick = close; d.onclick = e => { if (e.target === d) close(); };
  const go = () => { let v = true; if (o.input) { v = $('#dlgIn').value.trim(); if (!v) { $('#dlgIn').focus(); return; } } close(); cb(v); };
  $('#dlgOk').onclick = go;
  if (o.input) { const i = $('#dlgIn'); i.focus(); i.select(); i.addEventListener('keydown', e => { if (e.key === 'Enter') go(); }); }
}
const askText = (title, value, cb, o = {}) => dialog({ title, input: true, value, ok: 'Salvar', ...o }, cb);
const askConfirm = (title, msg, cb, o = {}) => dialog({ title, msg, ok: o.ok || 'Confirmar', danger: o.danger }, cb);

/* ================= nomes dos países ================= */
function openNames(q) {
  const el = $('#settings');
  el.innerHTML = `<div class="hub-top"><div class="hub-title"><button id="nmBack" class="x" aria-label="Voltar">${ICON('back')}</button><h2>Nomes dos países</h2></div><button id="nmClose" class="x" aria-label="Fechar">${ICON('close')}</button></div>
    <label class="hub-search">${ICON('search')}<input id="nmSearch" type="text" placeholder="Buscar país" autocomplete="off" spellcheck="false" value="${esc(q || '')}"></label>
    <div class="set-body" id="nmList"></div>`;
  el.classList.remove('hidden'); settingsOpen = true;
  $('#nmBack').onclick = () => openSettings(); $('#nmClose').onclick = closeSettings;
  $('#nmSearch').addEventListener('input', e => renderNames(e.target.value));
  $('#nmList').addEventListener('input', e => {
    const inp = e.target.closest('input[data-f]'); if (!inp) return;
    const c = C[+inp.closest('.nmrow').dataset.id];
    if (inp.dataset.f === 'name') { const v = inp.value.trim(); if (v) c.name = v; } else c.capName = inp.value;
    dirtySave = true; requestDraw(); pokeHub();
  });
  renderNames(q || '');
}
function renderNames(q) {
  const nq = norm(q || '');
  const list = C.filter(c => c && !c.deleted && (!nq || norm(c.name).includes(nq) || norm(c.capName || '').includes(nq))).sort((a, b) => a.name.localeCompare(b.name, 'pt'));
  $('#nmList').innerHTML = list.length ? list.map(c => `<div class="nmrow" data-id="${c.id}"><span class="fl"><img loading="lazy" alt="" src="${flagURL(c)}"></span>
    <div class="nmf"><input class="txt" data-f="name" value="${esc(c.name)}" maxlength="24" placeholder="Nome do país"><input class="txt" data-f="cap" value="${esc(c.capName || '')}" maxlength="28" placeholder="Capital"></div></div>`).join('') : '<p class="empty">Nenhum país encontrado.</p>';
}

/* ================= configurações ================= */
let settingsOpen = false;
function sw(on) { return `<i class="switch ${on ? 'on' : ''}"><i></i></i>`; }
function openSettings() {
  if (!world) return; closeHub(); if (selected != null) closeSheet(); settingsOpen = true;
  const el = $('#settings');
  el.innerHTML = `
  <div class="hub-top"><div class="hub-title">${ICON('gear')}<h2>Configurações</h2></div><button id="setClose" class="x" aria-label="Fechar">${ICON('close')}</button></div>
  <div class="set-body">
    <div class="set-sec">Territórios</div>
    <div class="set-card">
      <button class="set-btn" id="sNew">${ICON('pencil')}<span><b>Criar território novo</b><small>Arraste ou toque no mapa para desenhar. Depois de confirmar, você edita nome, bandeira e poder.</small></span></button>
    </div>
    <div class="set-sec">Países</div>
    <div class="set-card">
      <button class="set-btn" id="sNames">${ICON('edit')}<span><b>Nomes dos países</b><small>Renomeie países e capitais.</small></span></button>
      <button class="set-btn" id="sRank">${ICON('list')}<span><b>Ranking dos maiores países</b><small>Área, poder, exército, população e mais — ao vivo.</small></span></button>
    </div>
    <div class="set-sec">Este mundo</div>
    <div class="set-card">
      <div class="set-row"><input type="text" id="sWName" maxlength="32" value="${esc(world.name)}"><button class="btn" id="sWRen">${ICON('edit')}Renomear</button></div>
      <div class="set-row"><span>Tipo<small>${world.type === 'real' ? 'Mapa-múndi real' : world.type === 'fiction' ? 'Mundo fictício' : 'Mapa em branco'} · dia ${day} · ${HN.toLocaleString('pt-BR')} hexágonos</small></span></div>
    </div>
    <div class="set-sec">Exibição</div>
    <div class="set-card">
      <div class="set-row" data-opt="hex"><span>Mapa em mini hexágonos<small>Cada célula é um hexágono, como na primeira versão.</small></span>${sw(opts.hex)}</div>
      <div class="set-row" data-opt="flagsAll"><span>Bandeiras em todos os países</span>${sw(flagsAll)}</div>
      <div class="set-row" data-opt="labels"><span>Nomes dos países</span>${sw(opts.labels)}</div>
      <div class="set-row" data-opt="capitals"><span>Capitais e mastros</span>${sw(opts.capitals)}</div>
      <div class="set-row"><span>Opacidade das bandeiras</span><input type="range" id="sOp" min="30" max="100" step="2" value="${Math.round(flagOp * 100)}" style="width:44%"></div>
    </div>
    <div class="set-sec">Simulação</div>
    <div class="set-card">
      <div class="set-row" data-opt="fatigue"><span>Cansaço de guerra<small>Países exaustos aceitam cessar-fogo sozinhos</small></span>${sw(opts.fatigue)}</div>
      <div class="set-row" data-opt="allyJoin"><span>Aliados entram na guerra<small>Parceiros seguem o país que declarou guerra</small></span>${sw(opts.allyJoin)}</div>
    </div>
    <div class="set-sec">Dados</div>
    <div class="set-card">
      <button class="set-btn" id="sSave">${ICON('save')}<span><b>Salvar agora</b><small>O jogo também salva sozinho.</small></span></button>
      <button class="set-btn" id="sHow">${ICON('hold')}<span><b>Como jogar</b></span></button>
      <button class="set-btn" id="sMenu">${ICON('back')}<span><b>Voltar ao menu</b><small>Mundos salvos e novo mundo.</small></span></button>
      <button class="set-btn danger" id="sReset">${ICON('trash')}<span><b>Reiniciar este mundo</b><small>Volta territórios, guerras e poder ao início.</small></span></button>
    </div>
  </div>`;
  el.classList.remove('hidden');
  $('#setClose').onclick = closeSettings;
  $('#sNew').onclick = () => startDraw(null);
  $('#sWRen').onclick = () => { const v = $('#sWName').value.trim(); if (v) { world.name = v; dirtySave = true; saveWorld(false); toast('Mundo renomeado'); } };
  el.querySelectorAll('[data-opt]').forEach(row => row.addEventListener('click', () => {
    const k = row.dataset.opt, sv = row.querySelector('.switch');
    if (k === 'flagsAll') { flagsAll = !flagsAll; sv.classList.toggle('on', flagsAll); $('#bFlags').classList.toggle('on', flagsAll); repaintFlagsAll(); }
    else { opts[k] = !opts[k]; sv.classList.toggle('on', opts[k]); }
    dirtySave = true; requestDraw();
  }));
  $('#sOp').addEventListener('input', e => { flagOp = e.target.value / 100; dirtySave = true; requestDraw(); });
  $('#sNames').onclick = () => openNames('');
  $('#sRank').onclick = () => { closeSettings(); hubTab = 'ranking'; rankMetric = 'area'; openHub(); };
  $('#sSave').onclick = () => { saveWorld(true); toast('Mundo salvo'); };
  $('#sHow').onclick = () => { closeSettings(); $('#intro').classList.remove('hidden'); };
  $('#sMenu').onclick = () => exitToMenu();
  $('#sReset').onclick = () => askConfirm('Reiniciar mundo', 'Volta territórios, guerras e poder ao início.', () => resetWorld(), { ok: 'Reiniciar', danger: true });
}
function closeSettings() { settingsOpen = false; $('#settings').classList.add('hidden'); }
$('#bGear').onclick = () => { settingsOpen ? closeSettings() : openSettings(); };

/* ================= barra inferior ================= */
const HINTS = { war: 'Toque para ver o país. Segure dois países para declarar guerra.', ally: 'Toque em dois países para firmar ou romper uma aliança.', peace: 'Toque em um país para encerrar as guerras dele.' };
document.querySelectorAll('.mode').forEach(b => b.addEventListener('click', () => { mode = b.dataset.mode; allyPick = null; sticky = null; document.querySelectorAll('.mode').forEach(x => x.classList.toggle('active', x === b)); toast(HINTS[mode]); updateArm(); requestDraw(); }));
$('#bPlay').onclick = () => { if (ended) return; paused = !paused; syncPlay(); };
$('#bSpeed').onclick = () => { speedIdx = (speedIdx + 1) % SPEEDS.length; $('#spdTxt').textContent = SPEEDS[speedIdx] + 'x'; loop(); };
$('#bChaos').onclick = () => {
  const alive = C.filter(c => c && c.alive && c.iso !== 'AQ'); if (alive.length < 2) { toast('São necessários ao menos dois países'); return; }
  for (let t = 0; t < 40; t++) { const a = alive[(Math.random() * alive.length) | 0], b = alive[(Math.random() * alive.length) | 0]; if (a && b && a !== b && !atWar(a.id, b.id)) { declareWar(a.id, b.id); return; } }
  toast('Todos os países já estão em guerra');
};
$('#bFlags').onclick = () => { flagsAll = !flagsAll; $('#bFlags').classList.toggle('on', flagsAll); dirtySave = true; toast(flagsAll ? 'Bandeiras em todos os territórios' : 'Bandeiras só nos países escolhidos'); repaintFlagsAll(); };
$('#armCancel').onclick = () => { sticky = null; updateArm(); requestDraw(); };
$('#introGo').onclick = () => { $('#intro').classList.add('hidden'); };

/* ================= mundo fictício (procedural, gera pixels) ================= */
function makeNoise(r) { const p = []; for (let k = 0; k < 4; k++) p.push({ fx: (0.006 + r() * 0.012) * (1 + k * 1.2), fy: (0.008 + r() * 0.016) * (1 + k * 1.2), a: 1 / (k + 1), p1: r() * 6.283, p2: r() * 6.283 }); return (x, y) => { let v = 0, s = 0; for (const q of p) { v += q.a * Math.sin(x * q.fx + q.p1) * Math.sin(y * q.fy + q.p2); s += q.a; } return v / s; }; }
function genName(r, used) { for (let t = 0; t < 60; t++) { const n = NAME_SYL[(r() * NAME_SYL.length) | 0] + NAME_END[(r() * NAME_END.length) | 0]; if (!used.has(n)) { used.add(n); return n; } } return 'País ' + used.size; }
function genFiction(seed) {
  const r = rng(seed), nz = makeNoise(r), land = new Uint8Array(NPX);
  const blobs = [], nb = 6 + ((r() * 3) | 0);
  for (let i = 0; i < nb; i++) blobs.push({ x: W * (0.08 + 0.84 * r()), y: H * (0.24 + 0.52 * r()), rx: W * (0.05 + r() * 0.09), ry: H * (0.055 + r() * 0.085) });
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { let v = 0; for (const b of blobs) { const dx = (x - b.x) / b.rx, dy = (y - b.y) / b.ry, e = Math.exp(-(dx * dx + dy * dy)); if (e > v) v = e; } v = v * 1.05 + nz(x, y) * 0.32 - 0.28; if (v > 0.2) land[y * W + x] = 1; }
  const comp = new Int16Array(NPX).fill(-1), comps = [];
  for (let s = 0; s < NPX; s++) { if (!land[s] || comp[s] >= 0) continue; const list = [], st = [s]; comp[s] = comps.length; while (st.length) { const p = st.pop(); list.push(p); const x = p % W; if (x > 0 && land[p - 1] && comp[p - 1] < 0) { comp[p - 1] = comps.length; st.push(p - 1); } if (x < W - 1 && land[p + 1] && comp[p + 1] < 0) { comp[p + 1] = comps.length; st.push(p + 1); } if (p >= W && land[p - W] && comp[p - W] < 0) { comp[p - W] = comps.length; st.push(p - W); } if (p < NPX - W && land[p + W] && comp[p + W] < 0) { comp[p + W] = comps.length; st.push(p + W); } } comps.push(list); }
  const keep = comps.map((l, i) => ({ l, i })).filter(o => o.l.length >= 900).sort((a, b) => b.l.length - a.l.length);
  const own = new Uint16Array(NPX), total = keep.reduce((s, o) => s + o.l.length, 0), target = 16 + ((r() * 9) | 0), used = new Set(), metas = [], conts = {}, frontier = [];
  keep.forEach((o, ci) => {
    const k = Math.max(1, Math.round(target * o.l.length / total)), seeds = [];
    seeds.push(o.l[(r() * o.l.length) | 0]);
    while (seeds.length < k) { let best = -1, bd = -1; for (let t = 0; t < 30; t++) { const p = o.l[(r() * o.l.length) | 0]; let md = 1e18; for (const s of seeds) md = Math.min(md, (s % W - p % W) ** 2 + ((s / W | 0) - (p / W | 0)) ** 2); if (md > bd) { bd = md; best = p; } } seeds.push(best); }
    const key = 'L' + ci; let minx = 1e9, maxx = -1, miny = 1e9, maxy = -1;
    for (const p of o.l) { const x = p % W, y = (p / W) | 0; if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y; }
    conts[key] = { n: 'Continente ' + GREEK[ci % GREEK.length], box: [minx / RES - 180, (maxx + 1) / RES - 180, LAT0 - (maxy + 1) / RES, LAT0 - miny / RES] };
    for (const s of seeds) { const id = metas.length + 1, nm = genName(r, used); metas.push({ name: nm, cont: key, cap: [(s % W) / RES - 180, LAT0 - ((s / W) | 0) / RES], capName: CAP_PRE[(r() * CAP_PRE.length) | 0] + NAME_SYL[(r() * NAME_SYL.length) | 0], pw: Math.round(10 + r() * 70), ext: 'gen' }); own[s] = id; frontier.push(s); }
  });
  while (frontier.length) { const i = (r() * frontier.length) | 0, p = frontier[i]; frontier[i] = frontier[frontier.length - 1]; frontier.pop(); const x = p % W, o = own[p], nbs = []; if (x > 0) nbs.push(p - 1); if (x < W - 1) nbs.push(p + 1); if (p >= W) nbs.push(p - W); if (p < NPX - W) nbs.push(p + W); for (const q of nbs) if (land[q] && !own[q] && comp[q] >= 0) { own[q] = o; frontier.push(q); } }
  return { own, metas, conts };
}

/* ================= mundos: criar, salvar e carregar ================= */
const K_INDEX = 'lf3_index', K_LAST = 'lf3_last', K_W = 'lf3_w_';
function readIndex() { try { return JSON.parse(localStorage.getItem(K_INDEX) || '[]'); } catch (_) { return []; } }
function writeIndex(a) { try { localStorage.setItem(K_INDEX, JSON.stringify(a)); } catch (_) { } }
const TYPE_NAME = { real: 'Mapa-múndi real', fiction: 'Mundo fictício', blank: 'Mapa em branco' };
function newId() { return 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function newWorldState(type, name, seed) {
  let pix, metas = [], conts = null;
  if (type === 'real') { pix = decodeRLE8(M.rle, NPX); metas = M.paises.map(p => ({ iso: p.iso, name: p.n, cont: p.c, cap: p.cap, capName: CAPS[p.iso] || '', pw: p.p, ext: p.f })); }
  else if (type === 'fiction') { const g = genFiction(seed); pix = g.own; metas = g.metas; conts = g.conts; }
  else { pix = new Uint16Array(NPX); conts = {}; }
  return { v: 3, id: newId(), name, type, seed, fresh: true, conts, pix: rleEnc(pix), c: metas.map(m => ({ m })), day: 0, casualties: 0, w: [], ev: [] };
}
function serialize(withImages) {
  return {
    v: 3, id: world.id, name: world.name, type: world.type, seed: world.seed, day, casualties, flagsAll, flagOp, speedIdx, opts: { ...opts },
    conts: CONT === REAL_CONT ? null : CONT, hown: rleEnc(hown),
    c: C.slice(1).map(c => ({
      m: { iso: c.iso, name: c.name, cont: c.cont, cap: c.cap, capName: c.capName, pw: c.pw, ext: c.ext },
      col: c.color, ci: c.colorIdx, a: Math.round(c.army), t: Math.round(c.treasury), eco: Math.round(c.eco), ind: Math.round(c.ind), pop: +c.pop.toFixed(2),
      te: c.tech, mo: +c.morale.toFixed(1), al: c.alive ? 1 : 0, del: c.deleted ? 1 : 0, keep: c.keep ? 1 : 0, lost: Math.round(c.lost), capHex: c.capHex, totalHex: c.totalHex,
      ally: [...c.allies], war: [...c.wars], pl: c.planted ? 1 : 0, fs: c.flagSrc || null, cu: withImages ? c.customURL : null
    })),
    w: wars.map(w => [w.a, w.b, w.start]), ev: events.slice(0, 60)
  };
}
function makeThumb() {
  const cv = mkCanvas(236, 118), g = cv.getContext('2d'); g.fillStyle = '#0f2a27'; g.fillRect(0, 0, 236, 118);
  g.imageSmoothingEnabled = true; g.drawImage(hexFill, 0, 0, 236, 118);
  try { return cv.toDataURL('image/jpeg', 0.6); } catch (_) { return null; }
}
function saveWorld(withThumb) {
  if (!world) return; let ok = true;
  try { localStorage.setItem(K_W + world.id, JSON.stringify(serialize(true))); }
  catch (_) { try { localStorage.setItem(K_W + world.id, JSON.stringify(serialize(false))); } catch (__) { ok = false; } }
  const idx = readIndex(); let e = idx.find(x => x.id === world.id); if (!e) { e = { id: world.id }; idx.push(e); }
  e.name = world.name; e.type = world.type; e.day = day; e.upd = Date.now(); if (withThumb || !e.thumb) e.thumb = makeThumb();
  writeIndex(idx); try { localStorage.setItem(K_LAST, world.id); } catch (_) { } dirtySave = false;
  if (!ok) toast('Sem espaço para salvar este mundo');
}
setInterval(() => { if (running && dirtySave) saveWorld(false); }, 4000);
setInterval(() => { if (running) saveWorld(true); }, 60000);
window.addEventListener('pagehide', () => { if (running) saveWorld(true); });

function enterWorld(st) {
  world = { id: st.id, name: st.name, type: st.type, seed: st.seed || 0 };
  CONT = st.conts ? st.conts : (st.type === 'real' ? REAL_CONT : {});
  C = [null]; st.c.forEach((d, i) => C.push(makeCountry(i + 1, d.m)));
  wars = []; events = []; selected = null; sticky = null; allyPick = null; ended = false; paused = false; fxs.length = 0; tween = null;
  hubCont = 'ALL'; hubQuery = ''; hubTab = 'countries'; $('#hSearch').value = '';
  if (st.fresh) {
    buildHexesFromPixels(rleDec(st.pix, NPX));
    colorizeAll();
    initStats(st.seed || 7); day = 0; casualties = 0; flagsAll = false; flagOp = 0.94; speedIdx = 0;
  } else {
    day = st.day || 0; casualties = st.casualties || 0; flagsAll = !!st.flagsAll; flagOp = st.flagOp || 0.94; speedIdx = st.speedIdx || 0;
    Object.assign(opts, st.opts || {});
    rebuildFromHownSaved(rleDec(st.hown, HN));
    st.c.forEach((d, i) => {
      const c = C[i + 1];
      c.color = d.col || c.color; c.rgb = hex2rgb(c.color); c.colorIdx = d.ci || 0; c.army = d.a; c.treasury = d.t; c.eco = d.eco == null ? 50 : d.eco; c.ind = d.ind == null ? 40 : d.ind;
      c.pop = d.pop == null ? 5 : d.pop; c.tech = d.te; c.morale = d.mo; c.alive = !!d.al && c.cells > 0; c.deleted = !!d.del; c.keep = !!d.keep; c.lost = d.lost || 0;
      c.capHex = d.capHex != null && d.capHex >= 0 && hown[d.capHex] === c.id ? d.capHex : (c.cells ? findCapitalHex(c.id, null) : -1);
      c.totalHex = d.totalHex || c.cells;
      c.allies = new Set(d.ally || []); c.wars = new Set(d.war || []); c.planted = !!d.pl; c.flagSrc = d.fs || null; c.customURL = d.cu || null;
      if (c.customURL) { const im = new Image(); im.onload = () => { c.custom = coverCanvas(im, 480, 320); c.bmp = c.custom; c.bmpState = 2; markFlagDirty(c.id); requestDraw(); }; im.src = c.customURL; }
    });
    wars = (st.w || []).map(w => ({ a: w[0], b: w[1], start: w[2], landing: null })).filter(w => C[w.a] && C[w.b] && C[w.a].alive && C[w.b].alive);
    events = st.ev || [];
  }
  mode = 'war'; document.querySelectorAll('.mode').forEach(x => x.classList.toggle('active', x.dataset.mode === 'war'));
  $('#bFlags').classList.toggle('on', flagsAll); $('#spdTxt').textContent = SPEEDS[speedIdx] + 'x';
  pathCache.clear(); paintAllHex();
  $('#menu').classList.add('hidden'); closeHub(); closeSettings(); closeSheet(); stopDraw();
  running = true; viewInit = false; resize();
  if (st.type === 'real') viewLonLat(10, 30, Math.max(VH / H, minZoom()));
  else if (st.type === 'fiction') viewLonLat(0, 15, Math.max(VH / H, minZoom()));
  else { viewInit = true; cam.z = minZoom(); clampCam(); }
  syncPlay(); refreshAll(); requestDraw();
  world.fresh = false; dirtySave = true; saveWorld(true);
  let seen = false; try { seen = localStorage.getItem('lf3_intro') === '1'; localStorage.setItem('lf3_intro', '1'); } catch (_) { }
  if (!seen) $('#intro').classList.remove('hidden');
  if (st.type === 'blank' && C.length === 1) setTimeout(() => toast('Mapa em branco: abra Configurações e crie um território.'), 300);
}
function openWorldById(id) { let st = null; try { st = JSON.parse(localStorage.getItem(K_W + id) || 'null'); } catch (_) { } if (!st) { toast('Não consegui abrir esse mundo'); return; } enterWorld(st); }
function createWorld(type, name, seed) { enterWorld(newWorldState(type, name, seed)); }
function resetWorld() { const st = newWorldState(world.type, world.name, world.seed); st.id = world.id; enterWorld(st); toast('Mundo reiniciado'); }
function exitToMenu() {
  saveWorld(true); running = false; clearTimeout(timer); ptrs.clear();
  if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
  closeSettings(); closeHub(); closeSheet(); stopDraw(); world = null;
  $('#armbar').classList.add('hidden'); menuView = 'main'; renderMenu(); $('#menu').classList.remove('hidden');
}

/* ================= menu inicial ================= */
let menuView = 'main', newType = 'real';
const mbody = $('#menuBody');
function fmtDate(t) { const d = new Date(t); return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }) + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
function renderMenu() {
  const idx = readIndex().sort((a, b) => b.upd - a.upd);
  let html = '<div class="mw">';
  if (menuView === 'main') {
    const last = idx.find(x => x.id === (localStorage.getItem(K_LAST) || '')) || idx[0];
    html += `<div class="mhero"><img src="assets/logo.png" alt=""><h1>Trincheiras</h1><p>Sandbox de guerras, países e territórios</p></div><div class="mact">`;
    if (last) html += `<button class="mbtn primary" data-act="play" data-id="${last.id}">${ICON('play')}<span>Continuar<small>${esc(last.name)} · dia ${last.day || 0}</small></span></button>`;
    html += `<button class="mbtn" data-act="saved">${ICON('list')}<span>Mundos salvos<small>${idx.length ? idx.length + (idx.length === 1 ? ' mundo' : ' mundos') : 'Nenhum ainda'}</small></span></button>
      <button class="mbtn" data-act="new">${ICON('plus')}<span>Novo mundo<small>Mapa-múndi real, mundo fictício ou mapa em branco</small></span></button>
      <button class="mbtn" data-act="how">${ICON('hold')}<span>Como jogar</span></button></div>`;
  } else if (menuView === 'saved') {
    html += `<div class="mhead"><button class="x" data-act="back" aria-label="Voltar">${ICON('back')}</button><h2>Mundos salvos</h2></div>`;
    if (!idx.length) html += '<p class="empty">Nenhum mundo salvo. Crie um novo mundo para começar.</p>';
    idx.forEach(w => { html += `<div class="wcard"><div class="wthumb">${w.thumb ? `<img alt="" src="${w.thumb}">` : ''}</div><div class="winfo"><b>${esc(w.name)}</b><small>${TYPE_NAME[w.type] || ''} · dia ${w.day || 0}<br>${fmtDate(w.upd)}</small>
        <div class="wbtns"><button class="play" data-act="play" data-id="${w.id}">Jogar</button><button data-act="ren" data-id="${w.id}" aria-label="Renomear">${ICON('edit')}</button><button data-act="dup" data-id="${w.id}" aria-label="Duplicar">${ICON('copy')}</button><button data-act="del" data-id="${w.id}" aria-label="Excluir">${ICON('trash')}</button></div></div></div>`; });
  } else if (menuView === 'new') {
    const defName = { real: 'Mapa-múndi', fiction: 'Mundo fictício', blank: 'Meu mapa' }[newType];
    html += `<div class="mhead"><button class="x" data-act="back" aria-label="Voltar">${ICON('back')}</button><h2>Novo mundo</h2></div><div class="tcards">
      <button class="tcard ${newType === 'real' ? 'on' : ''}" data-act="type" data-t="real">${ICON('globe')}<span><b>Mapa-múndi real</b><small>169 países com fronteiras, capitais e bandeiras oficiais, num mapa gigante.</small></span></button>
      <button class="tcard ${newType === 'fiction' ? 'on' : ''}" data-act="type" data-t="fiction">${ICON('dice')}<span><b>Mundo fictício</b><small>Continentes sorteados com países inventados. Cada semente gera um mapa diferente.</small></span></button>
      <button class="tcard ${newType === 'blank' ? 'on' : ''}" data-act="type" data-t="blank">${ICON('blank')}<span><b>Mapa em branco</b><small>Só oceano. Desenhe seus próprios territórios e países.</small></span></button></div>
      <label class="nfield">Nome do mundo<input class="txt" id="nName" maxlength="32" value="${defName}"></label>`;
    if (newType === 'fiction') html += `<label class="nfield">Semente (opcional)<input class="txt" id="nSeed" maxlength="12" placeholder="deixe vazio para sortear" inputmode="numeric"></label>`;
    html += `<button class="mbtn primary" data-act="create" style="width:100%;margin-top:14px">${ICON('check')}<span>Criar e jogar</span></button>`;
  }
  mbody.innerHTML = html + '</div>';
}
mbody.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act, id = b.dataset.id;
  if (a === 'saved') { menuView = 'saved'; renderMenu(); }
  else if (a === 'new') { menuView = 'new'; renderMenu(); }
  else if (a === 'back') { menuView = 'main'; renderMenu(); }
  else if (a === 'how') { $('#intro').classList.remove('hidden'); }
  else if (a === 'type') { newType = b.dataset.t; const nm = $('#nName') ? $('#nName').value : ''; renderMenu(); if ($('#nName') && nm && !['Mapa-múndi', 'Mundo fictício', 'Meu mapa'].includes(nm)) $('#nName').value = nm; }
  else if (a === 'play') openWorldById(id);
  else if (a === 'create') { const name = ($('#nName').value || '').trim() || 'Novo mundo'; let seed = 0; if (newType === 'fiction') { const s = $('#nSeed') ? $('#nSeed').value.trim() : ''; seed = s ? (parseInt(s, 10) || 1) : ((Math.random() * 1e6) | 0) + 1; } createWorld(newType, name, seed); }
  else if (a === 'ren') { const idx = readIndex(), w = idx.find(x => x.id === id); if (w) askText('Renomear mundo', w.name, v => { w.name = v; writeIndex(idx); try { const st = JSON.parse(localStorage.getItem(K_W + id)); st.name = v; localStorage.setItem(K_W + id, JSON.stringify(st)); } catch (_) { } renderMenu(); }); }
  else if (a === 'dup') { try { const st = JSON.parse(localStorage.getItem(K_W + id)), nid = newId(); st.id = nid; st.name += ' (cópia)'; localStorage.setItem(K_W + nid, JSON.stringify(st)); const idx = readIndex(), w = idx.find(x => x.id === id); idx.push({ ...w, id: nid, name: st.name, upd: Date.now() }); writeIndex(idx); renderMenu(); } catch (_) { toast('Não foi possível duplicar (sem espaço)'); } }
  else if (a === 'del') { askConfirm('Excluir mundo', 'Este mundo salvo será apagado.', () => { try { localStorage.removeItem(K_W + id); } catch (_) { } writeIndex(readIndex().filter(x => x.id !== id)); renderMenu(); }, { ok: 'Excluir', danger: true }); }
});

/* ================= início ================= */
let world = null;
window.addEventListener('resize', () => { if (running) resize(); });
if (window.ResizeObserver) new ResizeObserver(() => { if (running) resize(); }).observe($('#stage'));
renderMenu();
window.__t = {
  get C() { return C; }, get hown() { return hown; }, get wars() { return wars; }, get world() { return world; }, get HN() { return HN; },
  createWorld, tick, declareWar, createTerritory, hexesInPolygon, enterWorld, exitToMenu, get draw() { return drawSt; }, cam,
  viewLonLat: (a, b, z) => { viewLonLat(a, b, z); requestDraw(); }, screenOf: iso => { const c = C.find(x => x && x.iso === iso); return [cam.x + hcx[c.capHex] * cam.z, cam.y + hcy[c.capHex] * cam.z]; },
  hexOwnerArr: () => hexOwnerArr, plantDefault, plantFrom, plantCustomCanvas, removeFlag, openSheet, flyCountry, countryComponents, saveWorld: () => saveWorld(true)
};
})();
