(() => {
'use strict';

/* ================= constantes ================= */
const $ = s => document.querySelector(s);
const M = window.MUNDO, W = M.W, H = M.H, RES = M.res, LAT0 = M.lat0, NPX = W * H;
const HOLD_MS = 650, TAP_MS = 450, MOVE_PX = 14, DRAW_PX = 5, ARM_WINDOW = 9000, SPEEDS = [1, 2, 4], FL = 2;
const PALETTE = ['#7a7a2e','#a03a2a','#c9a24b','#4f8a72','#7f5f95','#b5651d','#5c80a0','#98a04f','#b0574a','#3f7a63','#c98d5c','#7d8ea0','#8a7a50','#5f9a88','#d0b070','#6a4a3a'];
const REAL_CONT = {
  NA: { n: 'América do Norte', box: [-170, -50, 5, 75] },
  SA: { n: 'América do Sul', box: [-82, -34, -56, 13] },
  EU: { n: 'Europa', box: [-12, 45, 34, 72] },
  AF: { n: 'África', box: [-20, 52, -36, 38] },
  AS: { n: 'Ásia', box: [25, 150, -10, 70] },
  OC: { n: 'Oceania', box: [110, 180, -48, 0] }
};
let CONT = REAL_CONT;
const ICON = k => `<svg class="ic"><use href="#i-${k}"/></svg>`;
const P_SWORDS = new Path2D('M4 4L16 16M12.5 17.5L17.5 12.5M16 16L19.5 19.5M20 4L8 16M11.5 17.5L6.5 12.5M8 16L4.5 19.5');
const P_STAR = new Path2D('M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z');
const COS = new Float32Array(H);
for (let y = 0; y < H; y++) COS[y] = Math.cos((LAT0 - (y + 0.5) / RES) * Math.PI / 180);
const KM2 = (111.32 / RES) * (111.32 / RES);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = n => n >= 1000 ? (n / 1000).toFixed(1).replace('.', ',') + ' mi' : Math.round(n) + ' mil';
const fmtKm = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.', ',') + ' mi km²' : Math.round(n / 1000) + ' mil km²';
const fmtPop = n => n >= 1000 ? (n / 1000).toFixed(2).replace('.', ',') + ' bi' : n >= 10 ? Math.round(n) + ' mi' : n.toFixed(1).replace('.', ',') + ' mi';
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }
function hex2rgb(h) { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; }
function shadeCol(hex, amt) {
  const c = hex2rgb(hex), f = v => clamp(Math.round(amt < 0 ? v * (1 + amt) : v + (255 - v) * amt), 0, 255);
  return `rgb(${f(c[0])},${f(c[1])},${f(c[2])})`;
}
function rng(seed) {
  return function () {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

/* ---------- codificação RLE (varint) ---------- */
function bytesToB64(bytes) { let s = ''; for (let i = 0; i < bytes.length; i += 8192) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192)); return btoa(s); }
function rleEnc(arr) {
  const out = []; let i = 0; const n = arr.length;
  const push = v => { while (v >= 128) { out.push((v & 127) | 128); v >>= 7; } out.push(v); };
  while (i < n) { const v = arr[i]; let j = i + 1; while (j < n && arr[j] === v) j++; push(v); push(j - i); i = j; }
  return bytesToB64(Uint8Array.from(out));
}
function rleDec(b64, n) {
  const bin = atob(b64), out = new Uint16Array(n); let i = 0, o = 0;
  const rd = () => { let v = 0, sh = 0, b; do { b = bin.charCodeAt(i++); v |= (b & 127) << sh; sh += 7; } while (b & 128); return v; };
  while (i < bin.length && o < n) { const v = rd(), len = rd(); out.fill(v, o, o + len); o += len; }
  return out;
}
function decodeRLE8(b64, n) {
  const bin = atob(b64), out = new Uint16Array(n); let i = 0, o = 0;
  while (i < bin.length) {
    const v = bin.charCodeAt(i++); let len = 0, sh = 0, b;
    do { b = bin.charCodeAt(i++); len |= (b & 127) << sh; sh += 7; } while (b & 128);
    out.fill(v, o, o + len); o += len;
  }
  return out;
}

/* ================= dados do mundo real ================= */
const CAPLIST = 'RU:Moscou|CA:Ottawa|US:Washington D.C.|CN:Pequim|BR:Brasília|AU:Camberra|IN:Nova Délhi|AR:Buenos Aires|KZ:Astana|DZ:Argel|CD:Kinshasa|GL:Nuuk|SA:Riade|MX:Cidade do México|ID:Jacarta|SD:Cartum|LY:Trípoli|IR:Teerã|MN:Ulã Bator|PE:Lima|TD:N\'Djamena|NE:Niamei|AO:Luanda|ML:Bamaco|ZA:Pretória|CO:Bogotá|ET:Adis Abeba|BO:La Paz|MR:Nouakchott|EG:Cairo|TZ:Dodoma|NG:Abuja|VE:Caracas|NA:Windhoek|PK:Islamabad|MZ:Maputo|TR:Ancara|CL:Santiago|ZM:Lusaka|MM:Nepiedó|AF:Cabul|SS:Juba|SO:Mogadíscio|CF:Bangui|UA:Kiev|MG:Antananarivo|BW:Gaborone|KE:Nairóbi|FR:Paris|YE:Sanaa|TH:Bangcoc|ES:Madri|TM:Asgabate|CM:Iaundé|PG:Port Moresby|SE:Estocolmo|UZ:Tashkent|MA:Rabat|IQ:Bagdá|PY:Assunção|ZW:Harare|JP:Tóquio|DE:Berlim|CG:Brazzaville|FI:Helsinque|VN:Hanói|MY:Kuala Lumpur|NO:Oslo|CI:Yamoussoukro|PL:Varsóvia|OM:Mascate|IT:Roma|PH:Manila|EC:Quito|BF:Uagadugu|NZ:Wellington|GA:Libreville|GN:Conacri|GB:Londres|UG:Kampala|GH:Acra|RO:Bucareste|LA:Vienciana|GY:Georgetown|BY:Minsk|KG:Bisqueque|SN:Dacar|SY:Damasco|KH:Phnom Penh|UY:Montevidéu|TN:Túnis|SR:Paramaribo|NP:Catmandu|BD:Daca|TJ:Duchambe|GR:Atenas|NI:Manágua|MW:Lilongwe|ER:Asmara|BJ:Porto Novo|HN:Tegucigalpa|LR:Monróvia|BG:Sófia|CU:Havana|GT:Cidade da Guatemala|IS:Reykjavik|KR:Seul|HU:Budapeste|PT:Lisboa|JO:Amã|AZ:Baku|AT:Viena|AE:Abu Dhabi|CZ:Praga|PA:Cidade do Panamá|SL:Freetown|IE:Dublin|GE:Tbilisi|LK:Sri Jayawardenapura Kotte|LT:Vilnius|LV:Riga|TG:Lomé|HR:Zagreb|BA:Sarajevo|CR:San José|SK:Bratislava|DO:Santo Domingo|EE:Tallinn|DK:Copenhague|NL:Amsterdã|CH:Berna|BT:Timbu|TW:Taipé|GW:Bissau|MD:Chisinau|BE:Bruxelas|LS:Maseru|AM:Erevã|AL:Tirana|GQ:Malabo|BI:Gitega|HT:Porto Príncipe|RW:Kigali|MK:Escópia|DJ:Djibuti|BZ:Belmopan|SV:San Salvador|IL:Jerusalém|SI:Liubliana|FJ:Suva|KW:Cidade do Kuwait|SZ:Mbabane|TL:Díli|ME:Podgorica|RS:Belgrado|QA:Doha|GM:Banjul|JM:Kingston|LB:Beirute|CY:Nicósia|LU:Luxemburgo|KP:Pyongyang|PS:Ramallah|XK:Pristina|EH:El Aaiún|BN:Bandar Seri Begawan|SG:Singapura|GF:Caiena';
const CAPS = {}; CAPLIST.split('|').forEach(s => { const [k, v] = s.split(':'); CAPS[k] = v; });
// população aproximada em milhões (o resto é estimado pela área)
const POP = { CN: 1410, IN: 1430, US: 335, ID: 277, PK: 240, NG: 224, BR: 216, BD: 172, RU: 144, MX: 128, JP: 124, ET: 126, PH: 117, EG: 112, CD: 102, VN: 99, IR: 89, TR: 85, DE: 84, TH: 72, GB: 67, FR: 68, TZ: 67, ZA: 60, IT: 59, KE: 55, MM: 54, CO: 52, KR: 52, ES: 48, UG: 48, SD: 48, AR: 46, DZ: 45, UA: 37, IQ: 44, AF: 41, PL: 38, CA: 40, MA: 37, SA: 36, UZ: 35, PE: 34, MY: 34, AO: 36, GH: 34, MZ: 33, YE: 34, NP: 30, VE: 28, MG: 30, CM: 28, CI: 28, NE: 26, AU: 26, KP: 26, TW: 24, LK: 22, BF: 23, ML: 23, SY: 22, RO: 19, CL: 19, KZ: 20, ZM: 20, GT: 18, EC: 18, NL: 17.5, SN: 17, TD: 18, SO: 18, ZW: 16, KH: 17, SS: 11, BE: 11.7, CU: 11, GR: 10.4, PT: 10.3, CZ: 10.8, SE: 10.5, HU: 9.6, AT: 9, BY: 9.2, CH: 8.8, IL: 9.7, TJ: 10, BG: 6.5, RS: 6.7, DK: 5.9, FI: 5.5, NO: 5.5, NZ: 5.1, IE: 5.2, LA: 7.5, PY: 6.9, BO: 12, HN: 10, SL: 8.6, AZ: 10, JO: 11, AE: 10, CR: 5.2, PA: 4.4, UY: 3.4, MN: 3.4, LB: 5.4, KW: 4.3, OM: 4.6, AM: 2.8, GE: 3.7, IS: 0.38 };
const NAME_SYL = ['Al','Bre','Cal','Dra','Es','Fer','Gal','Hes','Ith','Jor','Kal','Lum','Mor','Nor','Oth','Pra','Qua','Ruv','Sel','Tor','Ul','Val','Wes','Xan','Yor','Zen','Bor','Cor','Dov','Ele'];
const NAME_END = ['doria','vânia','eon','vena','karra','rovia','drun','péria','mar','vik','dera','meria','vane','dak','land','gard','nia','tória','zuela','landia'];
const CAP_PRE = ['Porto ','Vila ','Monte ','Forte ','Nova ','Alto ','Ponte ','Cabo '];

/* ================= estado do mundo ================= */
let world = null;
let C = [null], R = [null], ADJ = [], NBR = [];
const reg = new Uint16Array(NPX), ownPix = new Uint16Array(NPX), own0 = new Uint16Array(NPX);

function makeCountry(id, m) {
  return {
    id, iso: m.iso || '', name: m.name, cont: m.cont || 'NEW', cap: m.cap || null, capName: m.capName || '', pw: m.pw == null ? 30 : m.pw, ext: m.ext || 'gen',
    army: 0, treasury: 0, eco: 50, ind: 40, pop: 5, tech: 3, morale: 80, alive: true, deleted: false, allies: new Set(), wars: new Set(),
    cells: 0, lost: 0, color: '#888888', rgb: [136, 136, 136], colorIdx: 0, area: 0, regs: [], comps: [], capReg: 0, capX: null, capY: null,
    planted: false, custom: null, customURL: null, plantT: -9999, bmp: null, bmpState: 0, genURL: null
  };
}

/* ================= regiões (divisões jogáveis) ================= */
function addRegion(c, pixels, ci) {
  const id = R.length, n = pixels.length;
  let minx = 1e9, miny = 1e9, maxx = -1, maxy = -1, sx = 0, sy = 0, area = 0;
  for (let i = 0; i < n; i++) {
    const p = pixels[i], x = p % W, y = (p / W) | 0;
    reg[p] = id;
    if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y;
    sx += x; sy += y; area += KM2 * COS[y];
  }
  const runs = []; let i = 0;
  while (i < n) {
    let j = i;
    while (j + 1 < n && pixels[j + 1] === pixels[j] + 1 && (pixels[j + 1] % W) !== 0) j++;
    runs.push((pixels[i] / W) | 0, pixels[i] % W, j - i + 1);
    i = j + 1;
  }
  const h = ((id * 2654435761) >>> 0) / 4294967296;
  R.push({ id, own: c, px: Int32Array.from(pixels), comp: ci, minx, miny, maxx, maxy, cx: sx / n, cy: sy / n, area,
    runs: Int32Array.from(runs), sh: 0.92 + h * 0.14, path: null });
  C[c].regs.push(id); C[c].area += area;
}
function splitComp(c, comp, k, ci) {
  const n = comp.length;
  if (k <= 1 || n < 8) { addRegion(c, comp, ci); return; }
  const px = new Float32Array(n), py = new Float32Array(n);
  let mx = 0, my = 0;
  for (let i = 0; i < n; i++) { const p = comp[i]; px[i] = (p % W) * COS[(p / W) | 0]; py[i] = (p / W) | 0; mx += px[i]; my += py[i]; }
  mx /= n; my /= n;
  let i0 = 0, bd = 1e18;
  for (let i = 0; i < n; i++) { const d = (px[i] - mx) ** 2 + (py[i] - my) ** 2; if (d < bd) { bd = d; i0 = i; } }
  const sxs = [px[i0]], sys = [py[i0]], md = new Float32Array(n).fill(1e18);
  while (sxs.length < k) {
    const lx = sxs[sxs.length - 1], ly = sys[sys.length - 1];
    let best = 0, bv = -1;
    for (let i = 0; i < n; i++) {
      const d = (px[i] - lx) ** 2 + (py[i] - ly) ** 2;
      if (d < md[i]) md[i] = d;
      if (md[i] > bv) { bv = md[i]; best = i; }
    }
    sxs.push(px[best]); sys.push(py[best]);
  }
  const lab = new Uint8Array(n);
  const assign = () => {
    for (let i = 0; i < n; i++) {
      let b = 0, bv = 1e18;
      for (let s = 0; s < k; s++) { const d = (px[i] - sxs[s]) ** 2 + (py[i] - sys[s]) ** 2; if (d < bv) { bv = d; b = s; } }
      lab[i] = b;
    }
  };
  for (let it = 0; it < 3; it++) {
    assign();
    const ax = new Float64Array(k), ay = new Float64Array(k), an = new Int32Array(k);
    for (let i = 0; i < n; i++) { const l = lab[i]; ax[l] += px[i]; ay[l] += py[i]; an[l]++; }
    for (let s = 0; s < k; s++) if (an[s]) { sxs[s] = ax[s] / an[s]; sys[s] = ay[s] / an[s]; }
  }
  assign();
  const groups = Array.from({ length: k }, () => []);
  for (let i = 0; i < n; i++) groups[lab[i]].push(comp[i]);
  for (const g of groups) if (g.length) addRegion(c, g, ci);
}
function buildRegions() {
  R = [null]; reg.fill(0);
  const NCn = C.length - 1;
  for (let c = 1; c <= NCn; c++) { const co = C[c]; co.regs = []; co.comps = []; co.area = 0; co.cells = 0; }
  const lists = Array.from({ length: NCn + 1 }, () => []);
  for (let p = 0; p < NPX; p++) { const o = own0[p]; if (o && o <= NCn) lists[o].push(p); else own0[p] = 0; }
  const seen = new Uint8Array(NPX);
  for (let c = 1; c <= NCn; c++) {
    const px = lists[c]; if (!px.length) continue;
    const comps = [];
    for (const s of px) {
      if (seen[s]) continue;
      const comp = [], st = [s]; seen[s] = 1;
      while (st.length) {
        const p = st.pop(); comp.push(p); const x = p % W;
        if (x > 0) { const q = p - 1; if (!seen[q] && own0[q] === c) { seen[q] = 1; st.push(q); } }
        if (x < W - 1) { const q = p + 1; if (!seen[q] && own0[q] === c) { seen[q] = 1; st.push(q); } }
        if (p >= W) { const q = p - W; if (!seen[q] && own0[q] === c) { seen[q] = 1; st.push(q); } }
        if (p < NPX - W) { const q = p + W; if (!seen[q] && own0[q] === c) { seen[q] = 1; st.push(q); } }
      }
      comp.sort((a, b) => a - b); comps.push(comp);
    }
    comps.sort((a, b) => b.length - a.length);
    const total = comps.reduce((s, x) => s + x.length, 0);
    const nreg = Math.max(1, Math.min(48, Math.round(Math.sqrt(total) / 6)));
    let ci = 0;
    for (const comp of comps) {
      if (comp.length < 3 && total > 3) { for (const p of comp) own0[p] = 0; continue; }
      const k = comp.length < 12 ? 1 : Math.max(1, Math.round(nreg * comp.length / total));
      splitComp(c, comp, k, ci);
      C[c].comps[ci] = { minx: 1e9, miny: 1e9, maxx: -1, maxy: -1, n: comp.length };
      ci++;
    }
    for (const rid of C[c].regs) {
      const r = R[rid], cp = C[c].comps[r.comp];
      cp.minx = Math.min(cp.minx, r.minx); cp.miny = Math.min(cp.miny, r.miny); cp.maxx = Math.max(cp.maxx, r.maxx); cp.maxy = Math.max(cp.maxy, r.maxy);
    }
    C[c].cells = C[c].regs.length;
  }
  // adjacência
  const em = new Map();
  const addEdge = (a, b, p, q) => {
    if (a > b) { const t = a; a = b; b = t; }
    const k = a * 65536 + b; let e = em.get(k);
    if (!e) { e = [a, b, []]; em.set(k, e); }
    e[2].push(p, q);
  };
  for (let p = 0; p < NPX; p++) {
    const a = reg[p]; if (!a) continue;
    if (p % W < W - 1) { const b = reg[p + 1]; if (b && b !== a) addEdge(a, b, p, p + 1); }
    if (p < NPX - W) { const b = reg[p + W]; if (b && b !== a) addEdge(a, b, p, p + W); }
  }
  ADJ = [...em.values()].map(e => ({ a: e[0], b: e[1], px: Int32Array.from(e[2]) }));
  NBR = Array.from({ length: R.length }, () => []);
  ADJ.forEach(e => { NBR[e.a].push(e.b); NBR[e.b].push(e.a); });
  for (let p = 0; p < NPX; p++) ownPix[p] = reg[p] ? R[reg[p]].own : 0;
  placeCapitals();
}
function placeCapitals() {
  for (let c = 1; c < C.length; c++) {
    const co = C[c];
    if (!co.regs.length) { co.capReg = 0; co.capX = null; co.capY = null; continue; }
    let cx, cy;
    if (co.cap) { cx = (co.cap[0] + 180) * RES; cy = (LAT0 - co.cap[1]) * RES; }
    else { const big = R[co.regs.reduce((a, b) => R[a].px.length >= R[b].px.length ? a : b)]; cx = big.cx; cy = big.cy; }
    let best = 1e18, br = co.regs[0], bp = -1;
    for (const rid of co.regs) {
      const r = R[rid];
      if (cx < r.minx - 8 || cx > r.maxx + 8 || cy < r.miny - 8 || cy > r.maxy + 8) {
        const d = (r.cx - cx) ** 2 + (r.cy - cy) ** 2 + 400; if (d < best) { best = d; br = rid; bp = -1; } continue;
      }
      for (let i = 0; i < r.px.length; i++) { const p = r.px[i], d = (p % W - cx) ** 2 + ((p / W | 0) - cy) ** 2; if (d < best) { best = d; br = rid; bp = p; } }
    }
    co.capReg = br;
    if (bp >= 0 && best < 200) { co.capX = cx; co.capY = cy; }
    else if (bp >= 0) { co.capX = bp % W; co.capY = (bp / W) | 0; }
    else { co.capX = R[br].cx; co.capY = R[br].cy; }
    if (!co.cap) co.cap = [co.capX / RES - 180, LAT0 - co.capY / RES];
  }
}
function colorizeAll() {
  const nb = Array.from({ length: C.length }, () => new Set());
  ADJ.forEach(e => { const a = R[e.a].own, b = R[e.b].own; if (a !== b) { nb[a].add(b); nb[b].add(a); } });
  const order = C.slice(1).filter(c => c.regs.length).sort((a, b) => b.area - a.area);
  const used = new Array(PALETTE.length).fill(0);
  C.forEach(c => { if (c) c.colorIdx = null; });
  for (const c of order) {
    const taken = new Set();
    nb[c.id].forEach(o => { if (C[o].colorIdx != null) taken.add(C[o].colorIdx); });
    let best = -1, bu = 1e9;
    for (let i = 0; i < PALETTE.length; i++) if (!taken.has(i) && used[i] < bu) { bu = used[i]; best = i; }
    if (best < 0) best = 0;
    c.colorIdx = best; used[best]++; c.color = PALETTE[best]; c.rgb = hex2rgb(c.color);
  }
}
function pickColorFor(cid) {
  const taken = new Set();
  ADJ.forEach(e => { const a = R[e.a].own, b = R[e.b].own; if (a === cid && b !== cid && C[b].colorIdx != null) taken.add(C[b].colorIdx); if (b === cid && a !== cid && C[a].colorIdx != null) taken.add(C[a].colorIdx); });
  let best = 0;
  for (let i = 0; i < PALETTE.length; i++) if (!taken.has(i)) { best = i; break; }
  const c = C[cid]; c.colorIdx = best; c.color = PALETTE[best]; c.rgb = hex2rgb(c.color);
}

/* ================= estado do jogo ================= */
let wars = [], events = [], day = 0, casualties = 0, mode = 'war', paused = false, speedIdx = 0, ended = false;
let selected = null, sticky = null, allyPick = null, flagsAll = false, flagOp = 0.94, dirtySave = false;
const opts = { labels: true, capitals: true, fatigue: true, allyJoin: true };
const atWar = (a, b) => C[a].wars.has(b);
function powerScore(c) {
  return clamp(100 * (0.3 * Math.sqrt(c.army / 5000) + 0.22 * c.eco / 100 + 0.18 * c.tech / 10 + 0.12 * c.morale / 100 + 0.1 * c.ind / 100 + 0.08 * Math.sqrt(c.pop / 1500)), 0, 100);
}
function initOne(c, seed) {
  const rnd = i => (((i * 2654435761 + seed) >>> 0) % 1000) / 1000, nr = c.regs.length;
  c.deleted = nr === 0 && !c.keep;
  if (!nr) { c.alive = false; return; }
  c.pop = POP[c.iso] != null ? POP[c.iso] : clamp(0.6 + c.area / 1e5 * (world && world.type === 'real' ? 0.9 : 3), 0.3, 400);
  c.army = 20 + c.pop * (0.5 + c.pw / 40) + rnd(c.id) * 10;
  c.eco = clamp(12 + c.pw * 0.85 + rnd(c.id + 3) * 8, 5, 100);
  c.ind = clamp(15 + c.pw * 0.7 + rnd(c.id + 7) * 10, 5, 100);
  c.treasury = 100 + c.eco * 12 + nr * 6;
  c.tech = clamp(1 + Math.round(c.pw / 11) + (rnd(c.id + 9) > 0.6 ? 1 : 0), 1, 10);
  c.morale = 70 + rnd(c.id + 5) * 22;
  c.alive = true; c.lost = 0; c.allies.clear(); c.wars.clear(); c.cells = nr;
}
function initStats(seed) { for (let i = 1; i < C.length; i++) initOne(C[i], seed); }

/* ================= camadas base, bordas, guerra e bandeiras ================= */
const ownPixView = ownPix;
const baseCanvas = document.createElement('canvas'); baseCanvas.width = W; baseCanvas.height = H;
const baseCtx = baseCanvas.getContext('2d');
const baseImg = baseCtx.createImageData(W, H), base32 = new Uint32Array(baseImg.data.buffer);
const edgeCanvas = document.createElement('canvas'); edgeCanvas.width = W; edgeCanvas.height = H;
const edgeCtx = edgeCanvas.getContext('2d');
const edgeImg = edgeCtx.createImageData(W, H), edge32 = new Uint32Array(edgeImg.data.buffer);
const edgeSoft = document.createElement('canvas'); edgeSoft.width = W >> 1; edgeSoft.height = H >> 1;
const edgeSoftCtx = edgeSoft.getContext('2d');
const flagSm = document.createElement('canvas'); flagSm.width = W * FL; flagSm.height = H * FL;
const flagSmCtx = flagSm.getContext('2d');
const flagLo = document.createElement('canvas'); flagLo.width = W; flagLo.height = H;
const flagLoCtx = flagLo.getContext('2d');
let flagDirty = true;
const warLayer = document.createElement('canvas'); warLayer.width = W; warLayer.height = H;
const warCtx = warLayer.getContext('2d');
const flagLayer = document.createElement('canvas'); flagLayer.width = W * FL; flagLayer.height = H * FL;
const flagCtx = flagLayer.getContext('2d');
let baseDirty = true, warDirty = true;
const pathCache = new Map(), grpCache = new Map();

function paintPixel(p) {
  const o = ownPix[p];
  if (!o) { base32[p] = 0; edge32[p] = 0; return; }
  const c = C[o].rgb, sh = R[reg[p]].sh, x = p % W;
  let edge = 0;
  if (x > 0) { const q = ownPix[p - 1]; if (q !== o) edge = Math.max(edge, q === 0 ? 1 : 2); }
  if (x < W - 1) { const q = ownPix[p + 1]; if (q !== o) edge = Math.max(edge, q === 0 ? 1 : 2); }
  if (p >= W) { const q = ownPix[p - W]; if (q !== o) edge = Math.max(edge, q === 0 ? 1 : 2); }
  if (p < NPX - W) { const q = ownPix[p + W]; if (q !== o) edge = Math.max(edge, q === 0 ? 1 : 2); }
  let f = sh; if (edge === 2) f *= 0.55; else if (edge === 1) f *= 0.8;
  const r = Math.min(255, c[0] * f) | 0, g = Math.min(255, c[1] * f) | 0, b = Math.min(255, c[2] * f) | 0;
  base32[p] = (255 << 24) | (b << 16) | (g << 8) | r;
  edge32[p] = edge === 2 ? ((150 << 24) | (2 << 16) | (4 << 8) | 6) : edge === 1 ? ((100 << 24) | (2 << 16) | (4 << 8) | 6) : 0;
}
function paintAllBase() { for (let p = 0; p < NPX; p++) paintPixel(p); baseDirty = true; }
function paintRegionBase(r) {
  const px = r.px;
  for (let i = 0; i < px.length; i++) {
    const p = px[i]; paintPixel(p);
    if (p % W > 0) paintPixel(p - 1);
    if (p % W < W - 1) paintPixel(p + 1);
    if (p >= W) paintPixel(p - W);
    if (p < NPX - W) paintPixel(p + W);
  }
  baseDirty = true;
}
function rebuildWar() {
  warCtx.clearRect(0, 0, W, H); warDirty = false;
  if (!wars.length) return;
  warCtx.fillStyle = '#ff4a3d';
  for (const e of ADJ) {
    const oa = R[e.a].own, ob = R[e.b].own;
    if (oa !== ob && C[oa].wars.has(ob)) { const px = e.px; for (let i = 0; i < px.length; i++) { const p = px[i]; warCtx.fillRect(p % W, (p / W) | 0, 1, 1); } }
  }
}
function setOwner(r, o, quiet) {
  const old = r.own; r.own = o;
  const px = r.px; for (let i = 0; i < px.length; i++) ownPix[px[i]] = o;
  paintRegionBase(r); warDirty = true; dirtySave = true;
  if (old !== o) { pathCache.delete(old); pathCache.delete(o); grpCache.delete(old); grpCache.delete(o); }
  if (!quiet) paintFlagRegion(r);
}

/* ---------- bandeiras ---------- */
function genFlagCanvas(c) {
  const cv = document.createElement('canvas'); cv.width = 360; cv.height = 240;
  const g = cv.getContext('2d'), a = c.color, b = '#f0e6c8', d = shadeCol(c.color, -0.5), k = c.id % 6;
  const R_ = (x, y, w, h, col) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
  if (k === 0) { R_(0, 0, 360, 240, a); R_(0, 80, 360, 80, b); }
  else if (k === 1) { R_(0, 0, 360, 240, a); R_(120, 0, 120, 240, b); }
  else if (k === 2) { R_(0, 0, 360, 240, a); R_(96, 0, 54, 240, b); R_(0, 93, 360, 54, b); }
  else if (k === 3) { R_(0, 0, 360, 240, d); g.fillStyle = a; g.beginPath(); g.moveTo(0, 0); g.lineTo(360, 0); g.lineTo(0, 240); g.fill(); g.fillStyle = b; g.beginPath(); g.arc(84, 72, 27, 0, 6.283); g.fill(); }
  else if (k === 4) { R_(0, 0, 360, 240, a); g.fillStyle = b; g.beginPath(); g.arc(180, 120, 66, 0, 6.283); g.fill(); g.fillStyle = d; g.beginPath(); g.arc(180, 120, 33, 0, 6.283); g.fill(); }
  else { R_(0, 0, 360, 240, b); g.fillStyle = a; g.beginPath(); g.moveTo(0, 0); g.lineTo(180, 120); g.lineTo(0, 240); g.fill(); R_(180, 102, 180, 36, d); }
  return cv;
}
function flagOn(c) { return c.alive && (flagsAll || c.planted); }
function flagURL(c) {
  if (c.customURL) return c.customURL;
  if (c.ext === 'gen') { if (!c.genURL) c.genURL = genFlagCanvas(c).toDataURL(); return c.genURL; }
  return `flags/${c.iso}.${c.ext}`;
}
function ensureFlag(c) {
  if (c.custom) { c.bmp = c.custom; c.bmpState = 2; return c.bmp; }
  if (c.ext === 'gen') { if (!c.bmp) { c.bmp = genFlagCanvas(c); } c.bmpState = 2; return c.bmp; }
  if (c.bmpState === 2) return c.bmp;
  if (c.bmpState === 0) {
    c.bmpState = 1;
    const im = new Image();
    im.onload = () => {
      const w = 360, h = Math.max(60, Math.round(360 * (im.naturalHeight || 240) / (im.naturalWidth || 360)));
      const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      cv.getContext('2d').drawImage(im, 0, 0, w, h);
      c.bmp = cv; c.bmpState = 2; repaintFlagOwner(c.id); requestDraw();
    };
    im.onerror = () => { c.bmpState = 3; };
    im.src = flagURL(c);
  }
  return null;
}
function regionPath(r) {
  if (r.path) return r.path;
  const p = new Path2D(), a = r.runs;
  for (let i = 0; i < a.length; i += 3) p.rect(a[i + 1], a[i], a[i + 2], 1);
  r.path = p; return p;
}
function groupBox(r) {
  let m = grpCache.get(r.own);
  if (!m) {
    m = new Map();
    const set = new Set(); for (let i = 1; i < R.length; i++) if (R[i].own === r.own) set.add(i);
    for (const s of set) {
      if (m.has(s)) continue;
      const stack = [s], members = [s]; m.set(s, null);
      let minx = 1e9, miny = 1e9, maxx = -1, maxy = -1;
      while (stack.length) {
        const a = stack.pop(), ra = R[a];
        minx = Math.min(minx, ra.minx); miny = Math.min(miny, ra.miny); maxx = Math.max(maxx, ra.maxx); maxy = Math.max(maxy, ra.maxy);
        for (const b of NBR[a]) if (set.has(b) && !m.has(b)) { m.set(b, null); stack.push(b); members.push(b); }
      }
      const box = { x: minx, y: miny, w: maxx - minx + 1, h: maxy - miny + 1 };
      const mw = 16, mh = 11;
      if (box.w < mw) { box.x -= (mw - box.w) / 2; box.w = mw; }
      if (box.h < mh) { box.y -= (mh - box.h) / 2; box.h = mh; }
      for (const id of members) m.set(id, box);
    }
    grpCache.set(r.own, m);
  }
  return m.get(r.id);
}
function drawFlagBox(g, bmp, b) {
  const ba = b.w / b.h, fa = bmp.width / bmp.height;
  if (ba < 0.55 || ba > 2.2) { g.drawImage(bmp, b.x, b.y, b.w, b.h); return; }
  let sw = bmp.width, sh = bmp.height, sx = 0, sy = 0;
  if (ba > fa) { sh = bmp.width / ba; sy = (bmp.height - sh) / 2; } else { sw = bmp.height * ba; sx = (bmp.width - sw) / 2; }
  g.drawImage(bmp, sx, sy, sw, sh, b.x, b.y, b.w, b.h);
}
function paintFlagRegion(r) {
  flagDirty = true;
  const c = C[r.own];
  flagCtx.save(); flagCtx.setTransform(FL, 0, 0, FL, 0, 0);
  flagCtx.clip(regionPath(r));
  flagCtx.clearRect(r.minx - 1, r.miny - 1, r.maxx - r.minx + 3, r.maxy - r.miny + 3);
  if (flagOn(c)) {
    const bmp = ensureFlag(c), b = groupBox(r);
    if (bmp) drawFlagBox(flagCtx, bmp, b); else { flagCtx.fillStyle = c.color; flagCtx.fillRect(b.x, b.y, b.w, b.h); }
  }
  flagCtx.restore();
}
function repaintFlagOwner(cid) { for (let i = 1; i < R.length; i++) if (R[i].own === cid) paintFlagRegion(R[i]); requestDraw(); }
function repaintFlagsAll() {
  flagDirty = true;
  flagCtx.setTransform(1, 0, 0, 1, 0, 0); flagCtx.clearRect(0, 0, flagLayer.width, flagLayer.height);
  for (let i = 1; i < R.length; i++) paintFlagRegion(R[i]);
  requestDraw();
}
function coverCanvas(im, w, h) {
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const g = cv.getContext('2d'), ia = im.width / im.height, ca = w / h;
  let sw = im.width, sh = im.height, sx = 0, sy = 0;
  if (ia > ca) { sw = im.height * ca; sx = (im.width - sw) / 2; } else { sh = im.width / ca; sy = (im.height - sh) / 2; }
  g.drawImage(im, sx, sy, sw, sh, 0, 0, w, h);
  return cv;
}
let flagTarget = null;
function plantDefault(cid) {
  const c = C[cid]; c.custom = null; c.customURL = null; c.bmp = null; c.bmpState = 0; c.genURL = null;
  c.planted = true; c.plantT = performance.now(); ensureFlag(c);
  repaintFlagOwner(cid); dirtySave = true; updateSheet(true);
}
function removeFlag(cid) {
  const c = C[cid]; c.planted = false; c.custom = null; c.customURL = null; c.bmp = null; c.bmpState = 0;
  repaintFlagOwner(cid); dirtySave = true; updateSheet(true);
}
function pickFile(cid) { flagTarget = cid; $('#fileFlag').click(); }
$('#fileFlag').addEventListener('change', e => {
  const f = e.target.files && e.target.files[0]; e.target.value = '';
  if (!f || flagTarget == null) return;
  const cid = flagTarget, url = URL.createObjectURL(f), im = new Image();
  im.onload = () => {
    const c = C[cid], cv = coverCanvas(im, 480, 320);
    c.custom = cv; c.bmp = cv; c.bmpState = 2;
    try { c.customURL = cv.toDataURL('image/jpeg', 0.85); } catch (_) { c.customURL = null; }
    c.planted = true; c.plantT = performance.now();
    URL.revokeObjectURL(url); repaintFlagOwner(cid); dirtySave = true; updateSheet(true);
    toast(`Bandeira de ${c.name} plantada`);
  };
  im.onerror = () => { URL.revokeObjectURL(url); toast('Não consegui abrir essa imagem'); };
  im.src = url;
});

/* ================= câmera e desenho ================= */
const canvas = $('#map'), ctx = canvas.getContext('2d');
let VW = 1, VH = 1, DPR = 1, viewInit = false;
const cam = { x: 0, y: 0, z: 1 };
const MAXZ = 18;
const minZoom = () => Math.max(0.12, VW / W);
function clampCam() {
  cam.z = clamp(cam.z, minZoom(), MAXZ);
  const mw = W * cam.z, mh = H * cam.z;
  cam.x = mw <= VW ? (VW - mw) / 2 : Math.min(0, Math.max(VW - mw, cam.x));
  cam.y = mh <= VH ? (VH - mh) / 2 : Math.min(0, Math.max(VH - mh, cam.y));
}
function resize() {
  const r = canvas.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return;
  DPR = Math.min(2, window.devicePixelRatio || 1);
  VW = r.width; VH = r.height;
  canvas.width = Math.round(VW * DPR); canvas.height = Math.round(VH * DPR);
  if (!viewInit) { viewInit = true; viewLonLat(10, 30, VH / H); } else clampCam();
  requestDraw();
}
function viewLonLat(lon, lat, z) { cam.z = z; cam.x = VW / 2 - (lon + 180) * RES * z; cam.y = VH / 2 - (LAT0 - lat) * RES * z; clampCam(); }
const toMapX = sx => (sx - cam.x) / cam.z, toMapY = sy => (sy - cam.y) / cam.z;
function countryAt(sx, sy) {
  const mx = Math.floor(toMapX(sx)), my = Math.floor(toMapY(sy));
  if (mx < 0 || my < 0 || mx >= W || my >= H) return null;
  const p = my * W + mx, r = reg[p];
  if (r) return R[r].own;
  if (cam.z < 3) for (const d of [-1, 1, -W, W]) { const q = p + d; if (q >= 0 && q < NPX && reg[q]) return R[reg[q]].own; }
  return null;
}
let tween = null;
function animateTo(cx, cy, z, dur) {
  z = clamp(z, minZoom(), MAXZ);
  tween = { t0: performance.now(), dur: dur || 650, cx0: (VW / 2 - cam.x) / cam.z, cy0: (VH / 2 - cam.y) / cam.z, z0: cam.z, cx, cy, z };
  requestDraw();
}
function flyBox(lon0, lon1, lat0, lat1) {
  const bw = (lon1 - lon0) * RES, bh = (lat1 - lat0) * RES, z = Math.min(VW / bw, VH / bh) * 0.92;
  animateTo(((lon0 + lon1) / 2 + 180) * RES, (LAT0 - (lat0 + lat1) / 2) * RES, z);
}
function flyCountry(cid) {
  const c = C[cid]; if (!c.comps.length) return;
  let cp = c.comps[0];
  for (const k of c.comps) if (k && k.n > cp.n) cp = k;
  const cx = (cp.minx + cp.maxx) / 2, cy = (cp.miny + cp.maxy) / 2;
  const bw = Math.max(30, cp.maxx - cp.minx + 8), bh = Math.max(20, cp.maxy - cp.miny + 8);
  const z = Math.min(VW / bw, VH * 0.42 / bh) * 0.9;
  animateTo(cx, cy + (VH * 0.2) / Math.max(z, 0.01), z);
}
function countryPath(cid) {
  let p = pathCache.get(cid); if (p) return p;
  p = new Path2D();
  for (let i = 1; i < R.length; i++) {
    const r = R[i]; if (r.own !== cid) continue;
    const a = r.runs; for (let k = 0; k < a.length; k += 3) p.rect(a[k + 1], a[k], a[k + 2], 1);
  }
  pathCache.set(cid, p); return p;
}
const fxs = [];
function addFx(kind, x, y, color) { if (fxs.length < 40) fxs.push({ t0: performance.now(), kind, x, y, color }); requestDraw(); }
function centroidOf(cid) {
  const c = C[cid]; let sx = 0, sy = 0, n = 0, best = -1;
  for (const rid of c.regs) { const r = R[rid]; if (r.own === cid && r.comp === 0) { sx += r.cx * r.px.length; sy += r.cy * r.px.length; n += r.px.length; } }
  if (!n) for (const rid of c.regs) { const r = R[rid]; if (r.own === cid) { sx += r.cx * r.px.length; sy += r.cy * r.px.length; n += r.px.length; } }
  return n ? [sx / n, sy / n, n] : null;
}
function icon(path, x, y, s, stroke, color, lw) {
  ctx.save(); ctx.translate(x - s / 2, y - s / 2); ctx.scale(s / 24, s / 24);
  if (stroke) { ctx.strokeStyle = color; ctx.lineWidth = lw || 2; ctx.lineCap = 'round'; ctx.stroke(path); } else { ctx.fillStyle = color; ctx.fill(path); }
  ctx.restore();
}
let rafId = 0, running = false;
function requestDraw() { if (!running) return; if (!rafId) rafId = requestAnimationFrame(frame); }
function keepAnimating() { return ptrs.size > 0 || sticky || fxs.length || tween || wars.length || plantingActive() || draw.on; }
function plantingActive() { const t = performance.now(); for (let i = 1; i < C.length; i++) if (C[i].planted && t - C[i].plantT < 1200) return true; return false; }
let edgeDirty = true;
function frame(now) {
  rafId = 0; if (!running) return;
  now = now || performance.now();
  if (tween) {
    const k = Math.min(1, (now - tween.t0) / tween.dur), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
    const z = Math.exp(Math.log(tween.z0) + (Math.log(tween.z) - Math.log(tween.z0)) * e);
    const cx = tween.cx0 + (tween.cx - tween.cx0) * e, cy = tween.cy0 + (tween.cy - tween.cy0) * e;
    cam.z = z; cam.x = VW / 2 - cx * z; cam.y = VH / 2 - cy * z; clampCam();
    if (k >= 1) tween = null;
  }
  updateHolds(now);
  if (warDirty) rebuildWar();
  if (baseDirty) {
    baseCtx.putImageData(baseImg, 0, 0); edgeCtx.putImageData(edgeImg, 0, 0);
    edgeSoftCtx.clearRect(0, 0, W >> 1, H >> 1); edgeSoftCtx.drawImage(edgeCanvas, 0, 0, W >> 1, H >> 1);
    baseDirty = false;
  }
  if (flagDirty && anyFlags()) {
    flagLoCtx.clearRect(0, 0, W, H); flagLoCtx.imageSmoothingEnabled = true; flagLoCtx.drawImage(flagLayer, 0, 0, W, H);
    flagSmCtx.globalCompositeOperation = 'source-over'; flagSmCtx.clearRect(0, 0, W * FL, H * FL); flagSmCtx.drawImage(flagLayer, 0, 0);
    flagSmCtx.globalCompositeOperation = 'destination-in'; flagSmCtx.imageSmoothingEnabled = true; flagSmCtx.drawImage(flagLo, 0, 0, W * FL, H * FL);
    flagSmCtx.globalCompositeOperation = 'source-over'; flagDirty = false;
  }
  render(now);
  if (keepAnimating()) rafId = requestAnimationFrame(frame);
}
function anyFlags() { if (flagsAll) return true; for (let i = 1; i < C.length; i++) if (C[i].planted) return true; return false; }
function render(now) {
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  const g = ctx.createLinearGradient(0, 0, 0, VH);
  g.addColorStop(0, '#12302c'); g.addColorStop(1, '#070d0c');
  ctx.fillStyle = g; ctx.fillRect(0, 0, VW, VH);
  ctx.setTransform(DPR * cam.z, 0, 0, DPR * cam.z, DPR * cam.x, DPR * cam.y);
  ctx.strokeStyle = 'rgba(240,225,180,.07)'; ctx.lineWidth = 1 / cam.z; ctx.beginPath();
  for (let lon = -180; lon <= 180; lon += 30) { const x = (lon + 180) * RES; ctx.moveTo(x, 0); ctx.lineTo(x, H); }
  for (let lat = -60; lat <= 80; lat += 20) { const y = (LAT0 - lat) * RES; ctx.moveTo(0, y); ctx.lineTo(W, y); }
  ctx.stroke();
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(baseCanvas, 0, 0);
  const fl = anyFlags();
  if (fl) {
    ctx.globalAlpha = flagOp; ctx.drawImage(flagSm, 0, 0, W, H); ctx.globalAlpha = 1;
    ctx.globalAlpha = 0.5; ctx.drawImage(edgeSoft, 0, 0, W, H);
    ctx.globalAlpha = clamp(2.2 / cam.z, 0.4, 1); ctx.drawImage(edgeCanvas, 0, 0); ctx.globalAlpha = 1;
  }
  if (wars.length) { ctx.globalAlpha = 0.6 + 0.4 * Math.sin(now / 230); ctx.drawImage(warLayer, 0, 0); ctx.globalAlpha = 1; }
  const pulse = 0.28 + 0.14 * Math.sin(now / 200);
  const hl = (cid, col) => { if (cid == null || !C[cid] || !C[cid].alive) return; ctx.fillStyle = col; ctx.fill(countryPath(cid)); };
  if (!draw.on) {
    for (const h of ptrs.values()) if (h.cid != null && !h.moved && mode === 'war') hl(h.cid, h.done ? `rgba(230,200,138,${pulse + 0.1})` : 'rgba(255,255,255,.2)');
    if (sticky) hl(sticky.country, `rgba(230,200,138,${pulse + 0.1})`);
    if (selected != null) hl(selected, 'rgba(255,255,255,.26)');
    if (allyPick != null) hl(allyPick, 'rgba(127,176,196,.4)');
  } else if (draw.target != null) hl(draw.target, 'rgba(230,200,138,.18)');
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  const z = cam.z;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  if (opts.labels) for (let i = 1; i < C.length; i++) {
    const c = C[i]; if (!c.alive) continue;
    const ct = centroidOf(i); if (!ct) continue;
    const sx = cam.x + ct[0] * z, sy = cam.y + ct[1] * z;
    if (sx < -60 || sx > VW + 60 || sy < -30 || sy > VH + 30) continue;
    const extent = Math.sqrt(ct[2]) * z, fs = clamp(extent * 0.09 + 6, 9, 15);
    if (extent > 22 + c.name.length * 3.2) {
      ctx.font = `700 ${fs}px "Segoe UI",system-ui,sans-serif`;
      ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(6,5,2,.88)'; ctx.strokeText(c.name, sx, sy + 14);
      ctx.fillStyle = '#f6edd2'; ctx.fillText(c.name, sx, sy + 14);
    }
  }
  if (opts.capitals) for (let i = 1; i < C.length; i++) {
    const c = C[i]; if (!c.alive || c.capX == null || !c.regs.length) continue;
    if (z < 2.6 && !c.wars.size && !(c.planted && z > 0.9) && selected !== i) continue;
    const sx = cam.x + c.capX * z, sy = cam.y + c.capY * z;
    if (sx < -30 || sx > VW + 30 || sy < -30 || sy > VH + 30) continue;
    if (c.planted && R[c.capReg] && R[c.capReg].own === i) drawPole(c, sx, sy, now); else icon(P_STAR, sx, sy, 11, false, '#e6c88a');
    if (c.wars.size) { ctx.beginPath(); ctx.arc(sx + 9, sy - 9, 8, 0, 6.283); ctx.fillStyle = '#b3261e'; ctx.fill(); icon(P_SWORDS, sx + 9, sy - 9, 12, true, '#fff', 2); }
  }
  for (let i = fxs.length - 1; i >= 0; i--) {
    const f = fxs[i], k = (now - f.t0) / (f.kind === 'cap' ? 1100 : 600);
    if (k >= 1) { fxs.splice(i, 1); continue; }
    const sx = cam.x + f.x * z, sy = cam.y + f.y * z;
    ctx.globalAlpha = 1 - k; ctx.strokeStyle = f.color; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(sx, sy, 6 + k * (f.kind === 'cap' ? 30 : 16), 0, 6.283); ctx.stroke();
    if (f.kind === 'cap') icon(P_SWORDS, sx, sy - k * 12, 16, true, '#fff', 2);
    ctx.globalAlpha = 1;
  }
  if (draw.on) drawPreview();
  else for (const h of ptrs.values()) {
    if (h.cid == null || h.moved || mode !== 'war') continue;
    const p = h.done ? 1 : Math.min(1, (now - h.t0) / HOLD_MS);
    ctx.beginPath(); ctx.arc(h.sx, h.sy, 28, 0, 6.283); ctx.fillStyle = h.done ? 'rgba(230,200,138,.3)' : 'rgba(6,5,2,.45)'; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.stroke();
    ctx.beginPath(); ctx.arc(h.sx, h.sy, 28, -Math.PI / 2, -Math.PI / 2 + p * 6.283); ctx.lineWidth = 4; ctx.strokeStyle = '#e6c88a'; ctx.lineCap = 'round'; ctx.stroke();
  }
}
function drawPole(c, sx, sy, now) {
  const k = clamp((now - c.plantT) / 900, 0, 1), e = 1 - Math.pow(1 - k, 3);
  const ph = 26 * e, fw = 22 * e, fh = 14 * e;
  ctx.lineCap = 'round';
  ctx.strokeStyle = '#0a0a08'; ctx.lineWidth = 3.4; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx, sy - ph); ctx.stroke();
  ctx.strokeStyle = '#e8e2d0'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx, sy - ph); ctx.stroke();
  if (fw > 2) {
    const bmp = ensureFlag(c);
    ctx.save(); ctx.beginPath(); ctx.rect(sx + 1, sy - ph, fw, fh); ctx.clip();
    if (bmp) ctx.drawImage(bmp, sx + 1, sy - ph, fw, fh); else { ctx.fillStyle = c.color; ctx.fillRect(sx + 1, sy - ph, fw, fh); }
    ctx.restore();
    ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 1; ctx.strokeRect(sx + 1, sy - ph, fw, fh);
  }
  ctx.beginPath(); ctx.arc(sx, sy, 2.4, 0, 6.283); ctx.fillStyle = '#e8e2d0'; ctx.fill();
}

/* ================= desenhar territórios ================= */
const draw = { on: false, pts: [], marks: [], target: null, take: true };
function startDraw(target) {
  draw.on = true; draw.pts = []; draw.marks = []; draw.target = target == null ? null : target; draw.take = true;
  $('#dbTake .switch').classList.add('on');
  $('#dbTxt').textContent = target == null ? 'Arraste para desenhar ou toque para marcar pontos' : `Expandindo ${C[target].name}. Arraste ou toque nos pontos`;
  $('#drawbar').classList.remove('hidden');
  closeSettings(); closeSheet(); closeHub(); sticky = null; updateArm(); requestDraw();
}
function stopDraw() { draw.on = false; draw.pts = []; draw.marks = []; $('#drawbar').classList.add('hidden'); requestDraw(); }
function drawPreview() {
  const pts = draw.pts; if (!pts.length) return;
  ctx.save();
  ctx.beginPath();
  pts.forEach((p, i) => { const x = cam.x + p[0] * cam.z, y = cam.y + p[1] * cam.z; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
  if (pts.length > 2) { ctx.save(); ctx.closePath(); ctx.fillStyle = 'rgba(230,200,138,.22)'; ctx.fill(); ctx.restore(); }
  ctx.strokeStyle = '#e6c88a'; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();
  if (pts.length > 2) {
    const a = pts[pts.length - 1], b = pts[0];
    ctx.beginPath(); ctx.setLineDash([6, 6]); ctx.moveTo(cam.x + a[0] * cam.z, cam.y + a[1] * cam.z); ctx.lineTo(cam.x + b[0] * cam.z, cam.y + b[1] * cam.z);
    ctx.lineWidth = 1.8; ctx.strokeStyle = 'rgba(230,200,138,.7)'; ctx.stroke(); ctx.setLineDash([]);
  }
  for (const i of draw.marks) { const p = pts[i]; if (!p) continue; ctx.beginPath(); ctx.arc(cam.x + p[0] * cam.z, cam.y + p[1] * cam.z, 4.5, 0, 6.283); ctx.fillStyle = '#f6edd2'; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = '#7a1a1a'; ctx.stroke(); }
  ctx.restore();
}
function rasterPoly(pts) {
  let minx = 1e9, miny = 1e9, maxx = -1e9, maxy = -1e9;
  for (const p of pts) { minx = Math.min(minx, p[0]); maxx = Math.max(maxx, p[0]); miny = Math.min(miny, p[1]); maxy = Math.max(maxy, p[1]); }
  minx = Math.max(0, Math.floor(minx)); miny = Math.max(0, Math.floor(miny)); maxx = Math.min(W - 1, Math.ceil(maxx)); maxy = Math.min(H - 1, Math.ceil(maxy));
  const w = maxx - minx + 1, h = maxy - miny + 1; if (w < 2 || h < 2) return [];
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const g = cv.getContext('2d'); g.fillStyle = '#fff'; g.beginPath();
  pts.forEach((p, i) => { const x = p[0] - minx, y = p[1] - miny; i ? g.lineTo(x, y) : g.moveTo(x, y); });
  g.closePath(); g.fill();
  const d = g.getImageData(0, 0, w, h).data, out = [];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] > 127) out.push((y + miny) * W + (x + minx));
  return out;
}

/* ================= interação no mapa ================= */
const ptrs = new Map();
let pinchBase = null;
function pt(e) { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
canvas.addEventListener('pointerdown', e => {
  if (!running) return;
  if (e.pointerType === 'mouse' && e.button !== 0) return;
  tween = null;
  const [sx, sy] = pt(e);
  ptrs.set(e.pointerId, { sx, sy, x0: sx, y0: sy, t0: performance.now(), cid: draw.on ? null : countryAt(sx, sy), done: false, moved: false });
  try { canvas.setPointerCapture(e.pointerId); } catch (_) { }
  if (ptrs.size === 2) {
    const a = [...ptrs.values()], mx = (a[0].sx + a[1].sx) / 2, my = (a[0].sy + a[1].sy) / 2;
    pinchBase = { d0: Math.hypot(a[0].sx - a[1].sx, a[0].sy - a[1].sy) || 1, z0: cam.z, mx0: toMapX(mx), my0: toMapY(my) };
  }
  requestDraw();
});
canvas.addEventListener('pointermove', e => {
  const h = ptrs.get(e.pointerId); if (!h) return;
  const [sx, sy] = pt(e), dx = sx - h.sx, dy = sy - h.sy;
  h.sx = sx; h.sy = sy;
  if (ptrs.size === 1) {
    if (draw.on) {
      if (!h.moved && Math.hypot(sx - h.x0, sy - h.y0) > DRAW_PX) { h.moved = true; draw.marks.push(draw.pts.length); draw.pts.push([toMapX(h.x0), toMapY(h.y0)]); }
      if (h.moved) {
        const l = draw.pts[draw.pts.length - 1];
        if (Math.hypot(sx - (cam.x + l[0] * cam.z), sy - (cam.y + l[1] * cam.z)) > 4) draw.pts.push([toMapX(sx), toMapY(sy)]);
        requestDraw();
      }
      return;
    }
    if (!h.moved && Math.hypot(sx - h.x0, sy - h.y0) > MOVE_PX) h.moved = true;
    if (h.moved) { cam.x += dx; cam.y += dy; clampCam(); requestDraw(); }
  } else if (ptrs.size === 2 && pinchBase) {
    const a = [...ptrs.values()];
    const d = Math.hypot(a[0].sx - a[1].sx, a[0].sy - a[1].sy) || 1, mx = (a[0].sx + a[1].sx) / 2, my = (a[0].sy + a[1].sy) / 2;
    const moved = Math.abs(d - pinchBase.d0) > MOVE_PX || a.some(p => Math.hypot(p.sx - p.x0, p.sy - p.y0) > MOVE_PX);
    if (moved) {
      a.forEach(p => { p.moved = true; });
      cam.z = clamp(pinchBase.z0 * d / pinchBase.d0, minZoom(), MAXZ);
      cam.x = mx - pinchBase.mx0 * cam.z; cam.y = my - pinchBase.my0 * cam.z; clampCam(); requestDraw();
    }
  }
});
function release(e, tap) {
  const h = ptrs.get(e.pointerId); if (!h) return;
  const wasOne = ptrs.size === 1;
  ptrs.delete(e.pointerId);
  if (ptrs.size === 1) { const o = [...ptrs.values()][0]; if (pinchBase) o.moved = true; }
  if (ptrs.size === 0) pinchBase = null;
  if (tap && draw.on) {
    if (wasOne && !h.moved && performance.now() - h.t0 < 700) { draw.marks.push(draw.pts.length); draw.pts.push([toMapX(h.x0), toMapY(h.y0)]); }
  } else if (tap && !h.moved && !h.done && performance.now() - h.t0 < TAP_MS) onTap(h.cid);
  requestDraw();
}
canvas.addEventListener('pointerup', e => release(e, true));
canvas.addEventListener('pointercancel', e => release(e, false));
canvas.addEventListener('contextmenu', e => e.preventDefault());
canvas.addEventListener('wheel', e => {
  e.preventDefault();
  const [sx, sy] = pt(e), mx = toMapX(sx), my = toMapY(sy);
  cam.z = clamp(cam.z * Math.exp(-e.deltaY * 0.0015), minZoom(), MAXZ);
  cam.x = sx - mx * cam.z; cam.y = sy - my * cam.z; clampCam(); requestDraw();
}, { passive: false });
canvas.addEventListener('dblclick', e => { if (draw.on) return; const [sx, sy] = pt(e); animateTo(toMapX(sx), toMapY(sy), cam.z * 2); });
function zoomBy(f) { animateTo((VW / 2 - cam.x) / cam.z, (VH / 2 - cam.y) / cam.z, cam.z * f, 300); }
$('#zIn').onclick = () => zoomBy(1.8);
$('#zOut').onclick = () => zoomBy(1 / 1.8);
$('#zFit').onclick = () => animateTo(W / 2, H / 2, minZoom(), 700);

function updateHolds(now) {
  if (mode !== 'war' || draw.on) return;
  for (const [pid, h] of ptrs) {
    if (h.done || h.moved || h.cid == null) continue;
    if (now - h.t0 >= HOLD_MS) { h.done = true; if (navigator.vibrate) navigator.vibrate(25); onHoldComplete(pid, h); }
  }
}
function onHoldComplete(pid, h) {
  const cid = h.cid;
  if (cid == null || !C[cid].alive) return;
  let other = null;
  for (const [p2, h2] of ptrs) if (p2 !== pid && h2.done && !h2.moved && h2.cid != null && h2.cid !== cid && C[h2.cid].alive) { other = h2.cid; break; }
  if (other == null && sticky && sticky.country !== cid && C[sticky.country].alive && performance.now() - sticky.t < ARM_WINDOW) other = sticky.country;
  if (other != null) { sticky = null; declareWar(other, cid); }
  else if (sticky && sticky.country === cid) sticky.t = performance.now();
  else sticky = { country: cid, t: performance.now() };
  updateArm();
}
function onTap(cid) {
  if (cid == null) { sticky = null; allyPick = null; if (selected != null) closeSheet(); updateArm(); return; }
  if (mode === 'war') openSheet(cid);
  else if (mode === 'ally') {
    if (allyPick == null) { allyPick = cid; toast(`${C[cid].name} escolhido. Toque em outro país.`); }
    else if (allyPick === cid) allyPick = null;
    else { toggleAlliance(allyPick, cid); allyPick = null; }
  } else if (mode === 'peace') makePeace(cid);
  requestDraw();
}
function updateArm() {
  const bar = $('#armbar');
  if (sticky && performance.now() - sticky.t > ARM_WINDOW) sticky = null;
  if (!sticky || !world) { bar.classList.add('hidden'); return; }
  bar.classList.remove('hidden');
  $('#armTxt').textContent = `${C[sticky.country].name} pronto. Segure outro país para declarar guerra.`;
  $('#armFill').style.width = Math.max(0, 100 - (performance.now() - sticky.t) / ARM_WINDOW * 100) + '%';
}
setInterval(() => { if (!running) return; const had = !!sticky; updateArm(); if (had && !sticky) requestDraw(); }, 200);

/* ================= registro e simulação ================= */
function log(text, kind, cid) {
  events.unshift({ day, text, kind, cid: cid || 0 });
  if (events.length > 200) events.pop();
  if (hubOpen && hubTab === 'events') renderHub();
}
function startWar(a, b) { const w = { a, b, start: day }; wars.push(w); C[a].wars.add(b); C[b].wars.add(a); warDirty = true; dirtySave = true; return w; }
function declareWar(a, b) {
  if (a === b || !C[a].alive || !C[b].alive) return false;
  if (atWar(a, b)) { toast(`${C[a].name} e ${C[b].name} já estão em guerra`); return false; }
  if (C[a].allies.has(b)) { C[a].allies.delete(b); C[b].allies.delete(a); log(`A aliança entre ${C[a].name} e ${C[b].name} foi rompida`, 'war', a); }
  startWar(a, b);
  log(`${C[a].name} declarou guerra a ${C[b].name}`, 'war', a);
  toast(`${C[a].name} declarou guerra a ${C[b].name}`);
  if (opts.allyJoin) {
    const join = (side, foe) => {
      for (const x of [...C[side].allies]) {
        if (x === foe || !C[x].alive || atWar(x, foe)) continue;
        if (C[x].allies.has(foe)) { C[x].allies.delete(foe); C[foe].allies.delete(x); }
        if (Math.random() < 0.8) { startWar(x, foe); log(`${C[x].name} entrou na guerra ao lado de ${C[side].name}`, 'war', x); }
      }
    };
    join(a, b); join(b, a);
  }
  refreshAll(); return true;
}
function endWar(w, why, silent) {
  const i = wars.indexOf(w); if (i < 0) return;
  wars.splice(i, 1); C[w.a].wars.delete(w.b); C[w.b].wars.delete(w.a); warDirty = true; dirtySave = true;
  if (!silent) { const t = `Cessar-fogo entre ${C[w.a].name} e ${C[w.b].name}${why ? ' (' + why + ')' : ''}`; log(t, 'peace', w.a); toast(t); }
}
function makePeace(cid) {
  const mine = wars.filter(w => w.a === cid || w.b === cid);
  if (!mine.length) { toast(`${C[cid].name} não está em guerra`); return; }
  mine.forEach(w => endWar(w, 'pedido de paz', false)); refreshAll();
}
function toggleAlliance(a, b) {
  if (C[a].allies.has(b)) { C[a].allies.delete(b); C[b].allies.delete(a); log(`${C[a].name} e ${C[b].name} romperam a aliança`, 'ally', a); toast('Aliança desfeita'); }
  else if (atWar(a, b)) { toast('Países em guerra não podem se aliar. Use Paz antes.'); return; }
  else { C[a].allies.add(b); C[b].allies.add(a); log(`${C[a].name} e ${C[b].name} firmaram uma aliança`, 'ally', a); toast(`${C[a].name} e ${C[b].name} agora são aliados`); }
  dirtySave = true; refreshAll();
}
function pickFront(a, d) {
  const pairs = [];
  for (const e of ADJ) {
    const oa = R[e.a].own, ob = R[e.b].own;
    if (oa === a && ob === d) pairs.push([e.a, e.b]); else if (oa === d && ob === a) pairs.push([e.b, e.a]);
  }
  if (pairs.length) {
    if (Math.random() < 0.35) {
      const cr = R[C[d].capReg]; let best = pairs[0], bd = 1e18;
      for (const p of pairs) { const r = R[p[1]], dd = (r.cx - cr.cx) ** 2 + (r.cy - cr.cy) ** 2; if (dd < bd) { bd = dd; best = p; } }
      return [best[0], best[1], 1];
    }
    const p = pairs[(Math.random() * pairs.length) | 0];
    return [p[0], p[1], 1];
  }
  const mine = [], theirs = [];
  for (let i = 1; i < R.length; i++) { if (R[i].own === a) mine.push(i); else if (R[i].own === d) theirs.push(i); }
  if (!mine.length || !theirs.length) return null;
  let best = null, bd = 1e18;
  for (const i of mine) for (const j of theirs) { const dd = (R[i].cx - R[j].cx) ** 2 + (R[i].cy - R[j].cy) ** 2; if (dd < bd) { bd = dd; best = [i, j]; } }
  return [best[0], best[1], Math.max(0.2, Math.min(0.75, 0.8 - Math.sqrt(bd) / 900))];
}
function clash(att, def) {
  const A = C[att], D = C[def];
  if (!A.alive || !D.alive) return;
  const pr = pickFront(att, def); if (!pr) return;
  const [, di, amph] = pr, tr = R[di];
  const pa = Math.sqrt(A.army) * (1 + A.tech * 0.14) * (0.45 + A.morale / 180) * (0.7 + Math.random() * 0.6) * amph * (0.85 + A.eco / 400);
  let pd = Math.sqrt(D.army) * (1 + D.tech * 0.14) * (0.45 + D.morale / 180) * (0.7 + Math.random() * 0.6) * 1.2 * (0.85 + D.eco / 400);
  if (di === D.capReg) pd *= 1.5; else if (NBR[D.capReg].includes(di)) pd *= 1.2;
  const win = pa > pd;
  const la = A.army * (0.003 + Math.random() * 0.006) * (win ? 0.7 : 1.3);
  const ld = D.army * (0.003 + Math.random() * 0.006) * (win ? 1.3 : 0.8);
  A.army = Math.max(0, A.army - la); D.army = Math.max(0, D.army - ld);
  A.lost += la; D.lost += ld; casualties += la + ld;
  if (win) { D.morale = Math.max(0, D.morale - 2.5); A.morale = Math.min(100, A.morale + 1.5); }
  else { A.morale = Math.max(0, A.morale - 1); D.morale = Math.min(100, D.morale + 1); }
  addFx(win ? 'cap' : 'clash', tr.cx, tr.cy, A.color);
  if (win) capture(di, att);
}
function capture(rid, att) {
  const r = R[rid], def = r.own;
  setOwner(r, att, true); C[att].cells++; C[def].cells--;
  if (rid === C[def].capReg) capitulate(def, att, 'capital tomada');
  else { if (C[def].cells <= 0) capitulate(def, att, 'território perdido'); else if (flagOn(C[att]) || flagOn(C[def])) { repaintFlagOwner(att); repaintFlagOwner(def); } }
}
function capitulate(loser, winner, why) {
  const L = C[loser], Wn = C[winner];
  for (let i = 1; i < R.length; i++) if (R[i].own === loser) { setOwner(R[i], winner, true); Wn.cells++; }
  L.cells = 0; L.alive = false;
  for (const w of [...wars]) if (w.a === loser || w.b === loser) endWar(w, null, true);
  for (let i = 1; i < C.length; i++) C[i].allies.delete(loser);
  L.allies.clear(); Wn.morale = Math.min(100, Wn.morale + 12);
  const t = `${Wn.name} anexou ${L.name} (${why})`;
  log(t, 'fall', winner); toast(t);
  if (selected === loser) closeSheet();
  if (sticky && sticky.country === loser) sticky = null;
  if (allyPick === loser) allyPick = null;
  warDirty = true; if (flagOn(Wn)) repaintFlagOwner(winner);
}
function checkEnd() {
  let alive = 0, last = 0; for (let i = 1; i < C.length; i++) if (C[i].alive) { alive++; last = i; }
  if (alive === 1 && !ended && C.length > 3) { ended = true; paused = true; syncPlay(); const t = `${C[last].name} domina o mundo inteiro`; log(t, 'fall', last); toast(t); }
}
function tick() {
  day++;
  for (let i = 1; i < C.length; i++) {
    const c = C[i]; if (!c.alive) continue;
    const war = c.wars.size > 0;
    const income = (c.pop * 0.35 + c.cells * 0.5) * (0.3 + c.eco / 60) + c.tech * 0.6;
    c.treasury = Math.max(-500, c.treasury + income - c.army * (war ? 0.16 : 0.05));
    if (c.treasury < 0) { c.morale = Math.max(0, c.morale - 0.4); c.army *= 0.998; }
    else c.army = Math.min(c.pop * 12 + 60, c.army + (c.pop * 0.004 + c.cells * 0.05) * (0.4 + c.ind / 60) * (war ? 0.6 : 1));
    if (!war) c.morale = Math.min(100, c.morale + 0.3);
  }
  for (const w of [...wars]) { if (!wars.includes(w)) continue; clash(w.a, w.b); if (wars.includes(w)) clash(w.b, w.a); }
  if (opts.fatigue) for (const w of [...wars]) {
    if (!wars.includes(w)) continue;
    const A = C[w.a], B = C[w.b];
    if (A.morale < 30 && B.morale < 30 && Math.random() < 0.08) endWar(w, 'cansaço de guerra');
    else if (day - w.start > 150 && Math.random() < 0.01) endWar(w, 'cansaço de guerra');
  }
  for (let i = 1; i < C.length; i++) {
    const c = C[i];
    if (c.alive && c.wars.size && (c.morale < 6 || c.army < 1)) {
      let foe = null; for (const f of c.wars) if (foe === null || C[f].army > C[foe].army) foe = f;
      if (foe !== null) capitulate(c.id, foe, 'rendição');
    }
  }
  dirtySave = true; checkEnd(); refreshAll();
}
let timer = null;
function loop() { clearTimeout(timer); if (paused || !running) return; timer = setTimeout(() => { tick(); loop(); }, 750 / SPEEDS[speedIdx]); }
function syncPlay() { $('#playUse').setAttribute('href', paused ? '#i-play' : '#i-pause'); $('#playTxt').textContent = paused ? 'Retomar' : 'Pausar'; loop(); }
function refreshAll() { updateHud(); updateSheet(); if (hubOpen) renderHub(); requestDraw(); }
function updateHud() {
  let alive = 0; for (let i = 1; i < C.length; i++) if (C[i].alive) alive++;
  $('#hDay').textContent = day; $('#hWars').textContent = wars.length; $('#hAlive').textContent = alive; $('#hDead').textContent = fmt(casualties);
}
function killCountry(cid, why) {
  const c = C[cid]; c.alive = false;
  for (const w of [...wars]) if (w.a === cid || w.b === cid) endWar(w, null, true);
  for (let i = 1; i < C.length; i++) C[i].allies.delete(cid);
  c.allies.clear(); if (selected === cid) closeSheet();
  if (why) log(`${c.name} deixou de existir (${why})`, 'fall', cid);
}

/* ================= criar, expandir e excluir territórios ================= */
function rebuildAll() {
  own0.set(ownPix);
  buildRegions(); pathCache.clear(); grpCache.clear();
}
function paintEverything() { paintAllBase(); repaintFlagsAll(); warDirty = true; }
function uniqueName(base) {
  const used = new Set(C.filter(Boolean).map(c => c.name));
  if (!used.has(base)) return base;
  for (let i = 2; i < 999; i++) if (!used.has(`${base} ${i}`)) return `${base} ${i}`;
  return base;
}
function createTerritory(pixels, target) {
  let cid = target, created = false;
  if (cid == null) {
    cid = C.length;
    const c = makeCountry(cid, { iso: 'X' + cid, name: uniqueName('Novo território'), cont: 'NEW', pw: 30, ext: 'gen', cap: null });
    c.keep = true; C.push(c); created = true;
    if (!CONT.NEW) { CONT = Object.assign({}, CONT, { NEW: { n: 'Territórios criados', box: [-180, 180, -60, 84] } }); }
  }
  const lost = new Set();
  for (const p of pixels) { const o = ownPix[p]; if (o && o !== cid) lost.add(o); ownPix[p] = cid; }
  rebuildAll();
  const c = C[cid];
  if (created) {
    pickColorFor(cid); initOne(c, world.seed || 7);
    c.capName = 'Capital de ' + c.name; c.alive = true; c.deleted = false; c.cells = c.regs.length;
  } else if (c.regs.length && !c.alive) { c.alive = true; c.cells = c.regs.length; }
  lost.forEach(o => { if (!C[o].regs.length && C[o].alive) killCountry(o, 'território tomado'); });
  paintEverything(); dirtySave = true; refreshAll();
  return cid;
}
function deleteCountry(cid) {
  for (let p = 0; p < NPX; p++) if (ownPix[p] === cid) ownPix[p] = 0;
  const c = C[cid]; c.deleted = true; c.keep = false; c.alive = false;
  for (const w of [...wars]) if (w.a === cid || w.b === cid) endWar(w, null, true);
  for (let i = 1; i < C.length; i++) C[i].allies.delete(cid);
  c.allies.clear(); closeSheet(); rebuildAll(); paintEverything(); dirtySave = true; refreshAll(); toast(`${c.name} foi apagado do mapa`);
}
function confirmDraw() {
  if (draw.pts.length < 3) { toast('Marque ao menos 3 pontos'); return; }
  let px = rasterPoly(draw.pts);
  if (!draw.take) px = px.filter(p => ownPix[p] === 0);
  if (px.length < 6) { toast(draw.take ? 'Território muito pequeno' : 'Nada livre nessa área. Ative "Tomar terra".'); return; }
  const target = draw.target; stopDraw();
  const cid = createTerritory(px, target);
  flyCountry(cid); openSheet(cid, target == null);
  toast(target == null ? 'Território criado. Ajuste nome, bandeira e poder.' : 'Território expandido');
}
$('#dbUndo').onclick = () => { if (!draw.marks.length) return; draw.pts.length = draw.marks.pop(); requestDraw(); };
$('#dbClear').onclick = () => { draw.pts = []; draw.marks = []; requestDraw(); };
$('#dbCancel').onclick = () => { stopDraw(); };
$('#dbOk').onclick = confirmDraw;
$('#dbTake').onclick = () => { draw.take = !draw.take; $('#dbTake .switch').classList.toggle('on', draw.take); };

/* ================= ficha do país ================= */
const SLIDERS = [
  ['eco', 'Economia', 0, 100, 1, 'coin'], ['army', 'Exército', 0, 8000, 5, 'soldier'], ['tech', 'Tecnologia', 1, 10, 1, 'chip'],
  ['morale', 'Moral', 0, 100, 1, 'heart'], ['ind', 'Indústria', 0, 100, 1, 'bolt'], ['pop', 'População', 0.1, 1600, 0.1, 'globe'], ['treasury', 'Tesouro', 0, 9000, 10, 'coin']
];
let dragging = false;
function openSheet(cid, isNew) { closeSettings(); selected = cid; buildSheet(isNew); $('#sheet').classList.remove('hidden'); requestDraw(); }
function closeSheet() { selected = null; $('#sheet').classList.add('hidden'); requestDraw(); }
function contOptions(sel) { return Object.entries(CONT).map(([k, v]) => `<option value="${k}" ${k === sel ? 'selected' : ''}>${esc(v.n)}</option>`).join(''); }
function buildSheet(isNew) {
  const c = C[selected], sh = $('#sheet');
  sh.innerHTML = `
  <div class="s-head">
    <div class="flag" id="sFlag"></div>
    <div class="s-title"><input id="sName" value="${esc(c.name)}" maxlength="24" spellcheck="false" autocomplete="off">
      <div class="s-meta"><span>${ICON('pin')}<i id="mCap"></i></span><span>${ICON('globe')}<i id="mCont"></i></span></div>
      <div class="tags" id="sTags"></div></div>
    <button class="x" id="sClose" aria-label="Fechar">${ICON('close')}</button>
  </div>
  <div class="tiles">
    <div class="tile">${ICON('flag')}<div><small>Território</small><b id="tCells"></b></div></div>
    <div class="tile">${ICON('skull')}<div><small>Baixas</small><b id="tLost"></b></div></div>
  </div>
  <div class="power-meter">
    <div class="pm-n" id="pmN">0</div>
    <div class="pm-t"><b id="pmT">Poder do país</b><i class="pm-bar"><u id="pmB" style="width:0"></u></i></div>
  </div>
  <div class="flagpanel">
    <div class="fp-head">${ICON('image')}<span>Bandeira no território</span></div>
    <div class="fbtns">
      <button class="fbtn" id="fbDef">${ICON('flag')}Padrão</button>
      <button class="fbtn" id="fbFile">${ICON('upload')}Arquivo</button>
      <button class="fbtn" id="fbOff">${ICON('trash')}Remover</button>
    </div>
    <div class="frow"><span>Opacidade das bandeiras</span><input type="range" id="fOp" min="30" max="100" step="2" style="width:46%"></div>
  </div>
  <details class="more" ${isNew ? '' : 'open'}><summary>Poder do país</summary>
    <div class="presets"><button data-p="weak">Fraco</button><button data-p="mid">Médio</button><button data-p="strong">Forte</button><button data-p="super">Superpotência</button></div>
    ${SLIDERS.map(s => `<label class="sl">${ICON(s[5])}<span>${s[1]}</span><input type="range" data-k="${s[0]}" min="${s[2]}" max="${s[3]}" step="${s[4]}"><output data-o="${s[0]}"></output></label>`).join('')}
  </details>
  <details class="more" ${isNew ? 'open' : ''}><summary>Identidade e território</summary>
    <label class="fld">Capital<input class="txt" id="sCap" maxlength="28" value="${esc(c.capName || '')}"></label>
    <label class="fld">Continente<select class="txt" id="sCont">${contOptions(c.cont)}</select></label>
    <div class="swatches">${PALETTE.map(p => `<button class="sw" data-c="${p}" style="background:${p}" aria-label="Cor"></button>`).join('')}</div>
    <div class="s-actions" style="margin:10px 0 8px"><button class="btn" id="sExpand">${ICON('pencil')}Expandir</button><button class="btn" id="sDel" style="color:var(--war)">${ICON('trash')}Apagar</button></div>
  </details>
  <div class="s-actions"><button class="btn" id="sZoom">${ICON('fit')}Ver no mapa</button><button class="btn peace" id="sPeace">${ICON('peace')}Cessar-fogo</button></div>`;
  $('#sClose').onclick = closeSheet;
  $('#sName').addEventListener('input', e => { c.name = e.target.value.trim() || c.name; dirtySave = true; requestDraw(); });
  $('#sCap').addEventListener('input', e => { c.capName = e.target.value; $('#mCap').textContent = c.capName; dirtySave = true; });
  $('#sCont').addEventListener('change', e => { c.cont = e.target.value; $('#mCont').textContent = CONT[c.cont] ? CONT[c.cont].n : ''; dirtySave = true; });
  sh.querySelectorAll('input[type=range][data-k]').forEach(inp => {
    inp.addEventListener('pointerdown', () => { dragging = true; });
    inp.addEventListener('input', () => { c[inp.dataset.k] = +inp.value; dirtySave = true; refreshPower(c); sh.querySelector(`[data-o="${inp.dataset.k}"]`).textContent = valText(inp.dataset.k, c); });
  });
  sh.querySelectorAll('.presets button').forEach(b => b.addEventListener('click', () => { applyPreset(c, b.dataset.p); updateSheet(true); }));
  $('#fOp').addEventListener('input', e => { flagOp = e.target.value / 100; dirtySave = true; requestDraw(); });
  sh.querySelectorAll('.sw').forEach(b => b.addEventListener('click', () => {
    c.color = b.dataset.c; c.rgb = hex2rgb(c.color);
    if (c.ext === 'gen') { c.genURL = null; if (!c.custom) { c.bmp = null; c.bmpState = 0; } }
    paintAllBase(); if (flagOn(c)) repaintFlagOwner(c.id); dirtySave = true; updateSheet(true); requestDraw();
  }));
  $('#fbDef').onclick = () => plantDefault(c.id);
  $('#fbFile').onclick = () => pickFile(c.id);
  $('#fbOff').onclick = () => removeFlag(c.id);
  $('#sPeace').onclick = () => makePeace(c.id);
  $('#sZoom').onclick = () => flyCountry(c.id);
  $('#sExpand').onclick = () => startDraw(c.id);
  $('#sDel').onclick = () => { if (confirm(`Apagar ${c.name} do mapa? O território vira oceano.`)) deleteCountry(c.id); };
  updateSheet(true);
  if (isNew) { const n = $('#sName'); n.focus(); n.select(); }
}
window.addEventListener('pointerup', () => { dragging = false; });
function applyPreset(c, k) {
  const P = { weak: [20, 15, 2, 60, 0.4, 15], mid: [45, 40, 4, 72, 1.2, 30], strong: [70, 65, 7, 82, 2.2, 60], super: [95, 90, 10, 92, 3.2, 100] }[k];
  c.eco = P[0]; c.ind = P[1]; c.tech = P[2]; c.morale = P[3]; c.army = c.pop * P[4] + P[5]; c.treasury = 100 + c.eco * 12; dirtySave = true;
}
function valText(k, c) {
  return k === 'army' ? fmt(c.army) : k === 'pop' ? fmtPop(c.pop) : k === 'treasury' ? Math.round(c.treasury) : k === 'tech' ? c.tech : Math.round(c[k]) + (k === 'morale' ? '%' : '');
}
function refreshPower(c) {
  const s = powerScore(c); let rank = 1, n = 0;
  for (let i = 1; i < C.length; i++) if (C[i].alive) { n++; if (i !== c.id && powerScore(C[i]) > s) rank++; }
  $('#pmN').textContent = Math.round(s); $('#pmB').style.width = s + '%';
  $('#pmT').textContent = `Poder mundial: ${rank}º de ${n}`;
}
function updateSheet(force) {
  if (selected == null) return;
  const c = C[selected];
  if (!c.alive) { closeSheet(); return; }
  const sh = $('#sheet');
  if (force) {
    $('#sFlag').innerHTML = `<img alt="" src="${flagURL(c)}">`;
    sh.querySelectorAll('.sw').forEach(b => b.classList.toggle('on', b.dataset.c === c.color));
    $('#fbDef').classList.toggle('on', c.planted && !c.custom);
    $('#fbFile').classList.toggle('on', c.planted && !!c.custom);
    $('#fbOff').classList.toggle('on', !c.planted);
    $('#fOp').value = Math.round(flagOp * 100);
    $('#mCap').textContent = c.capName || 'sem capital'; $('#mCont').textContent = CONT[c.cont] ? CONT[c.cont].n : '';
  }
  $('#tCells').textContent = `${c.cells} de ${c.regs.length} regiões`;
  $('#tLost').textContent = fmt(c.lost);
  if (force || !dragging) sh.querySelectorAll('input[type=range][data-k]').forEach(inp => { inp.value = c[inp.dataset.k]; });
  SLIDERS.forEach(s => { const o = sh.querySelector(`[data-o="${s[0]}"]`); if (o) o.textContent = valText(s[0], c); });
  refreshPower(c);
  let tags = '';
  if (c.wars.size) for (const f of c.wars) tags += `<span class="tag war">${ICON('swords')}<i style="background:${C[f].color}"></i>${esc(C[f].name)}</span>`;
  else tags += `<span class="tag peace">${ICON('peace')}Em paz</span>`;
  for (const a of c.allies) tags += `<span class="tag ally">${ICON('link')}<i style="background:${C[a].color}"></i>${esc(C[a].name)}</span>`;
  $('#sTags').innerHTML = tags;
  $('#sPeace').disabled = !c.wars.size;
}

/* ================= hub ================= */
let hubOpen = false, hubTab = 'countries', hubCont = 'ALL', hubSort = 'name', hubQuery = '';
function openHub() { if (!world) return; closeSettings(); hubOpen = true; $('#hub').classList.remove('hidden'); if (selected != null) closeSheet(); renderHub(true); }
function closeHub() { hubOpen = false; $('#hub').classList.add('hidden'); }
function norm(s) { return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
function contStats(k) {
  const cs = C.filter(c => c && !c.deleted && c.cont === k);
  return { list: cs, alive: cs.filter(c => c.alive).length, army: cs.reduce((s, c) => s + (c.alive ? c.army : 0), 0), area: cs.reduce((s, c) => s + c.area, 0), wars: cs.reduce((s, c) => s + (c.alive ? c.wars.size : 0), 0) / 2 };
}
function renderHub(resetScroll) {
  const body = $('#hubBody'), chips = $('#hubChips'), keep = body.scrollTop;
  $('#hub .hub-search').style.display = hubTab === 'countries' ? '' : 'none';
  document.querySelectorAll('#hub .tab').forEach(t => t.classList.toggle('active', t.dataset.tab === hubTab));
  const real = C.filter(c => c && !c.deleted);
  if (hubTab === 'countries') {
    const cnt = { ALL: real.length };
    Object.keys(CONT).forEach(k => { cnt[k] = real.filter(c => c.cont === k).length; });
    if (hubCont !== 'ALL' && !CONT[hubCont]) hubCont = 'ALL';
    chips.style.display = '';
    chips.innerHTML = [['ALL', 'Todos'], ...Object.entries(CONT).map(([k, v]) => [k, v.n])].map(([k, n]) => `<button class="hchip2 ${hubCont === k ? 'on' : ''}" data-k="${k}">${esc(n)}<b>${cnt[k] || 0}</b></button>`).join('');
    const q = norm(hubQuery.trim());
    const list = real.filter(c => (hubCont === 'ALL' || c.cont === hubCont) && (!q || norm(c.name).includes(q) || norm(c.capName || '').includes(q) || c.iso.toLowerCase() === q));
    const by = { name: (a, b) => a.name.localeCompare(b.name, 'pt'), land: (a, b) => b.cells - a.cells, army: (a, b) => (b.alive ? b.army : -1) - (a.alive ? a.army : -1), area: (a, b) => b.area - a.area, power: (a, b) => (b.alive ? powerScore(b) : -1) - (a.alive ? powerScore(a) : -1) };
    list.sort(by[hubSort]);
    body.innerHTML = `<div class="sortbar">Ordenar:${[['name', 'Nome'], ['power', 'Poder'], ['area', 'Área'], ['army', 'Exército']].map(([k, n]) => `<button data-s="${k}" class="${hubSort === k ? 'on' : ''}">${n}</button>`).join('')}</div>` +
      (list.length ? list.map(c => `<button class="crow ${c.alive ? '' : 'dead'}" data-id="${c.id}">
        <span class="fl"><img loading="lazy" alt="" src="${flagURL(c)}"></span>
        <span class="rn"><b>${esc(c.name)}</b><small>${esc(c.capName || '')}${c.capName ? ' · ' : ''}${esc(CONT[c.cont] ? CONT[c.cont].n : '')} · ${fmtKm(c.area)}</small></span>
        <span class="rr">${c.alive ? `<span>${Math.round(powerScore(c))} pts</span>${c.wars.size ? `<span class="tag war">${ICON('swords')}${c.wars.size}</span>` : `<span>${c.cells}/${c.regs.length} reg.</span>`}` : '<span>extinto</span>'}</span></button>`).join('') : '<p class="empty">' + (real.length ? 'Nenhum país encontrado.' : 'Ainda não há países. Abra as Configurações e crie um território.') + '</p>');
  } else if (hubTab === 'continents') {
    chips.style.display = 'none';
    const ents = Object.entries(CONT);
    body.innerHTML = ents.length ? ents.map(([k, v]) => {
      const s = contStats(k);
      return `<div class="ccard"><h3>${esc(v.n)}</h3><div class="s-meta"><span>${ICON('flag')}${s.alive} de ${s.list.length} países ativos</span></div>
        <div class="cs"><div>Área<b>${fmtKm(s.area)}</b></div><div>Exército<b>${fmt(s.army)}</b></div><div>Guerras<b>${Math.round(s.wars)}</b></div></div>
        <div class="cb"><button class="btn" data-go="${k}">${ICON('fit')}Ver no mapa</button><button class="btn" data-list="${k}">${ICON('list')}Países</button></div></div>`;
    }).join('') : '<p class="empty">Sem continentes neste mapa.</p>';
  } else {
    chips.style.display = 'none';
    const iconFor = k => ({ war: 'swords', peace: 'peace', ally: 'link', fall: 'skull' }[k] || 'flag');
    body.innerHTML = events.length ? events.map(e => `<div class="ev ${e.kind}">${ICON(iconFor(e.kind))}<span><small>Dia ${e.day}</small>${esc(e.text)}</span></div>`).join('') : '<p class="empty">Nenhum evento ainda. Segure dois países no mapa para começar uma guerra.</p>';
  }
  body.scrollTop = resetScroll ? 0 : keep;
}
$('#hub').addEventListener('click', e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.classList.contains('hchip2')) { hubCont = t.dataset.k; renderHub(true); }
  else if (t.dataset.s) { hubSort = t.dataset.s; renderHub(true); }
  else if (t.classList.contains('crow')) { const id = +t.dataset.id; if (C[id].alive) { closeHub(); flyCountry(id); openSheet(id); } else toast(`${C[id].name} foi anexado`); }
  else if (t.dataset.go) { closeHub(); const b = CONT[t.dataset.go].box; flyBox(b[0], b[1], b[2], b[3]); }
  else if (t.dataset.list) { hubCont = t.dataset.list; hubTab = 'countries'; renderHub(true); }
  else if (t.classList.contains('tab')) { hubTab = t.dataset.tab; renderHub(true); }
});
$('#hSearch').addEventListener('input', e => { hubQuery = e.target.value; renderHub(true); });
$('#hubClose').onclick = closeHub;
$('#bHub').onclick = () => { hubOpen ? closeHub() : openHub(); };

/* ================= configurações ================= */
let settingsOpen = false;
function sw(on) { return `<i class="switch ${on ? 'on' : ''}"><i></i></i>`; }
function openSettings() {
  if (!world) return; closeHub(); if (selected != null) closeSheet(); settingsOpen = true;
  const el = $('#settings');
  el.innerHTML = `
  <div class="hub-top"><div class="hub-title">${ICON('gear')}<h2>Configurações</h2></div><button id="setClose" class="x" aria-label="Fechar">${ICON('close')}</button></div>
  <div class="set-body">
    <div class="set-sec">Territórios</div>
    <div class="set-card">
      <button class="set-btn" id="sNew">${ICON('pencil')}<span><b>Criar território novo</b><small>Arraste ou toque no mapa para desenhar. Depois de confirmar, você edita nome, bandeira e poder.</small></span></button>
    </div>
    <div class="set-sec">Este mundo</div>
    <div class="set-card">
      <div class="set-row"><input type="text" id="sWName" maxlength="32" value="${esc(world.name)}"><button class="btn" id="sWRen">${ICON('edit')}Renomear</button></div>
      <div class="set-row"><span>Tipo<small>${world.type === 'real' ? 'Mapa-múndi real' : world.type === 'fiction' ? 'Mundo fictício' : 'Mapa em branco'} · dia ${day}</small></span></div>
    </div>
    <div class="set-sec">Exibição</div>
    <div class="set-card">
      <div class="set-row" data-opt="flagsAll"><span>Bandeiras em todos os países</span>${sw(flagsAll)}</div>
      <div class="set-row" data-opt="labels"><span>Nomes dos países</span>${sw(opts.labels)}</div>
      <div class="set-row" data-opt="capitals"><span>Capitais e mastros</span>${sw(opts.capitals)}</div>
      <div class="set-row"><span>Opacidade das bandeiras</span><input type="range" id="sOp" min="30" max="100" step="2" value="${Math.round(flagOp * 100)}" style="width:44%"></div>
    </div>
    <div class="set-sec">Simulação</div>
    <div class="set-card">
      <div class="set-row" data-opt="fatigue"><span>Cansaço de guerra<small>Países exaustos aceitam cessar-fogo sozinhos</small></span>${sw(opts.fatigue)}</div>
      <div class="set-row" data-opt="allyJoin"><span>Aliados entram na guerra<small>Parceiros seguem o país que declarou guerra</small></span>${sw(opts.allyJoin)}</div>
    </div>
    <div class="set-sec">Dados</div>
    <div class="set-card">
      <button class="set-btn" id="sSave">${ICON('save')}<span><b>Salvar agora</b><small>O jogo também salva sozinho.</small></span></button>
      <button class="set-btn" id="sHow">${ICON('hold')}<span><b>Como jogar</b></span></button>
      <button class="set-btn" id="sMenu">${ICON('back')}<span><b>Voltar ao menu</b><small>Mundos salvos e novo mundo.</small></span></button>
      <button class="set-btn danger" id="sReset">${ICON('trash')}<span><b>Reiniciar este mundo</b><small>Volta territórios, guerras e poder ao início.</small></span></button>
    </div>
  </div>`;
  el.classList.remove('hidden');
  $('#setClose').onclick = closeSettings;
  $('#sNew').onclick = () => startDraw(null);
  $('#sWRen').onclick = () => { const v = $('#sWName').value.trim(); if (v) { world.name = v; dirtySave = true; saveWorld(false); toast('Mundo renomeado'); } };
  el.querySelectorAll('[data-opt]').forEach(row => row.addEventListener('click', () => {
    const k = row.dataset.opt, sv = row.querySelector('.switch');
    if (k === 'flagsAll') { flagsAll = !flagsAll; sv.classList.toggle('on', flagsAll); $('#bFlags').classList.toggle('on', flagsAll); repaintFlagsAll(); }
    else { opts[k] = !opts[k]; sv.classList.toggle('on', opts[k]); }
    dirtySave = true; requestDraw();
  }));
  $('#sOp').addEventListener('input', e => { flagOp = e.target.value / 100; dirtySave = true; requestDraw(); });
  $('#sSave').onclick = () => { saveWorld(true); toast('Mundo salvo'); };
  $('#sHow').onclick = () => { closeSettings(); $('#intro').classList.remove('hidden'); };
  $('#sMenu').onclick = () => exitToMenu();
  $('#sReset').onclick = () => { if (confirm('Reiniciar este mundo?')) resetWorld(); };
}
function closeSettings() { settingsOpen = false; $('#settings').classList.add('hidden'); }
$('#bGear').onclick = () => { settingsOpen ? closeSettings() : openSettings(); };

/* ================= barra inferior ================= */
const HINTS = { war: 'Toque para ver o país. Segure dois países para declarar guerra.', ally: 'Toque em dois países para firmar ou romper uma aliança.', peace: 'Toque em um país para encerrar as guerras dele.' };
document.querySelectorAll('.mode').forEach(b => b.addEventListener('click', () => {
  mode = b.dataset.mode; allyPick = null; sticky = null;
  document.querySelectorAll('.mode').forEach(x => x.classList.toggle('active', x === b));
  toast(HINTS[mode]); updateArm(); requestDraw();
}));
$('#bPlay').onclick = () => { if (ended) return; paused = !paused; syncPlay(); };
$('#bSpeed').onclick = () => { speedIdx = (speedIdx + 1) % SPEEDS.length; $('#spdTxt').textContent = SPEEDS[speedIdx] + 'x'; loop(); };
$('#bChaos').onclick = () => {
  const alive = C.filter(c => c && c.alive);
  if (alive.length < 2) { toast('São necessários ao menos dois países'); return; }
  for (let t = 0; t < 40; t++) {
    const a = alive[(Math.random() * alive.length) | 0], b = alive[(Math.random() * alive.length) | 0];
    if (a && b && a !== b && !atWar(a.id, b.id)) { declareWar(a.id, b.id); return; }
  }
  toast('Todos os países já estão em guerra');
};
$('#bFlags').onclick = () => {
  flagsAll = !flagsAll; $('#bFlags').classList.toggle('on', flagsAll); dirtySave = true;
  toast(flagsAll ? 'Bandeiras em todos os territórios' : 'Bandeiras só nos países escolhidos');
  repaintFlagsAll();
};
$('#armCancel').onclick = () => { sticky = null; updateArm(); requestDraw(); };
$('#introGo').onclick = () => { $('#intro').classList.add('hidden'); };

/* ================= mundo fictício (procedural) ================= */
const GREEK = ['Alfa', 'Beta', 'Gama', 'Delta', 'Épsilon', 'Zeta', 'Eta', 'Teta', 'Iota', 'Capa', 'Lambda', 'Sigma'];
function makeNoise(r) {
  const p = [];
  for (let k = 0; k < 4; k++) p.push({ fx: (0.006 + r() * 0.012) * (1 + k * 1.2), fy: (0.008 + r() * 0.016) * (1 + k * 1.2), a: 1 / (k + 1), p1: r() * 6.283, p2: r() * 6.283 });
  return (x, y) => { let v = 0, s = 0; for (const q of p) { v += q.a * Math.sin(x * q.fx + q.p1) * Math.sin(y * q.fy + q.p2); s += q.a; } return v / s; };
}
function genName(r, used) {
  for (let t = 0; t < 60; t++) {
    const n = NAME_SYL[(r() * NAME_SYL.length) | 0] + NAME_END[(r() * NAME_END.length) | 0];
    if (!used.has(n)) { used.add(n); return n; }
  }
  return 'País ' + used.size;
}
function genFiction(seed) {
  const r = rng(seed), nz = makeNoise(r), land = new Uint8Array(NPX);
  const blobs = [], nb = 6 + ((r() * 3) | 0);
  for (let i = 0; i < nb; i++) blobs.push({ x: W * (0.08 + 0.84 * r()), y: H * (0.24 + 0.52 * r()), rx: 110 + r() * 190, ry: 60 + r() * 90 });
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    let v = 0;
    for (const b of blobs) { const dx = (x - b.x) / b.rx, dy = (y - b.y) / b.ry, e = Math.exp(-(dx * dx + dy * dy)); if (e > v) v = e; }
    v = v * 1.05 + nz(x, y) * 0.32 - 0.28;
    if (v > 0.2) land[y * W + x] = 1;
  }
  // componentes (massas de terra)
  const comp = new Int16Array(NPX).fill(-1), comps = [];
  for (let s = 0; s < NPX; s++) {
    if (!land[s] || comp[s] >= 0) continue;
    const list = [], st = [s]; comp[s] = comps.length;
    while (st.length) {
      const p = st.pop(); list.push(p); const x = p % W;
      if (x > 0 && land[p - 1] && comp[p - 1] < 0) { comp[p - 1] = comps.length; st.push(p - 1); }
      if (x < W - 1 && land[p + 1] && comp[p + 1] < 0) { comp[p + 1] = comps.length; st.push(p + 1); }
      if (p >= W && land[p - W] && comp[p - W] < 0) { comp[p - W] = comps.length; st.push(p - W); }
      if (p < NPX - W && land[p + W] && comp[p + W] < 0) { comp[p + W] = comps.length; st.push(p + W); }
    }
    comps.push(list);
  }
  const keep = comps.map((l, i) => ({ l, i })).filter(o => o.l.length >= 260).sort((a, b) => b.l.length - a.l.length);
  const own = new Uint16Array(NPX);
  const total = keep.reduce((s, o) => s + o.l.length, 0);
  const target = 12 + ((r() * 5) | 0), used = new Set(), metas = [], conts = {};
  const frontier = [];
  keep.forEach((o, ci) => {
    const k = Math.max(1, Math.round(target * o.l.length / total)), seeds = [];
    seeds.push(o.l[(r() * o.l.length) | 0]);
    while (seeds.length < k) {
      let best = -1, bd = -1;
      for (let t = 0; t < 30; t++) {
        const p = o.l[(r() * o.l.length) | 0]; let md = 1e18;
        for (const s of seeds) md = Math.min(md, (s % W - p % W) ** 2 + ((s / W | 0) - (p / W | 0)) ** 2);
        if (md > bd) { bd = md; best = p; }
      }
      seeds.push(best);
    }
    const key = 'L' + ci; let minx = 1e9, maxx = -1, miny = 1e9, maxy = -1;
    for (const p of o.l) { const x = p % W, y = (p / W) | 0; if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y; }
    conts[key] = { n: 'Continente ' + GREEK[ci % GREEK.length], box: [minx / RES - 180, (maxx + 1) / RES - 180, LAT0 - (maxy + 1) / RES, LAT0 - miny / RES] };
    for (const s of seeds) {
      const id = metas.length + 1, nm = genName(r, used);
      metas.push({ name: nm, cont: key, cap: [(s % W) / RES - 180, LAT0 - ((s / W) | 0) / RES], capName: CAP_PRE[(r() * CAP_PRE.length) | 0] + NAME_SYL[(r() * NAME_SYL.length) | 0], pw: Math.round(10 + r() * 70), ext: 'gen' });
      own[s] = id; frontier.push(s);
    }
  });
  while (frontier.length) {
    const i = (r() * frontier.length) | 0, p = frontier[i]; frontier[i] = frontier[frontier.length - 1]; frontier.pop();
    const x = p % W, o = own[p], nbs = [];
    if (x > 0) nbs.push(p - 1); if (x < W - 1) nbs.push(p + 1); if (p >= W) nbs.push(p - W); if (p < NPX - W) nbs.push(p + W);
    for (const q of nbs) if (land[q] && !own[q] && comp[q] >= 0) { own[q] = o; frontier.push(q); }
  }
  for (let p = 0; p < NPX; p++) if (!own[p]) own[p] = 0;
  return { own, metas, conts };
}

/* ================= mundos: criar, salvar e carregar ================= */
const K_INDEX = 'lf2_index', K_LAST = 'lf2_last', K_W = 'lf2_w_';
function readIndex() { try { return JSON.parse(localStorage.getItem(K_INDEX) || '[]'); } catch (_) { return []; } }
function writeIndex(a) { try { localStorage.setItem(K_INDEX, JSON.stringify(a)); } catch (_) { } }
const TYPE_NAME = { real: 'Mapa-múndi real', fiction: 'Mundo fictício', blank: 'Mapa em branco' };
function newId() { return 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function newWorldState(type, name, seed) {
  let ownArr, metas = [], conts = null;
  if (type === 'real') {
    ownArr = decodeRLE8(M.rle, NPX);
    metas = M.paises.map(p => ({ iso: p.iso, name: p.n, cont: p.c, cap: p.cap, capName: CAPS[p.iso] || '', pw: p.p, ext: p.f }));
  } else if (type === 'fiction') { const g = genFiction(seed); ownArr = g.own; metas = g.metas; conts = g.conts; }
  else { ownArr = new Uint16Array(NPX); conts = {}; }
  return { v: 2, id: newId(), name, type, seed, fresh: true, conts, own: rleEnc(ownArr), c: metas.map(m => ({ m })), day: 0, casualties: 0, w: [], ev: [] };
}
function serialize(withImages) {
  return {
    v: 2, id: world.id, name: world.name, type: world.type, seed: world.seed, day, casualties, flagsAll, flagOp, speedIdx, opts: { ...opts },
    conts: CONT === REAL_CONT ? null : CONT, own: rleEnc(ownPix),
    c: C.slice(1).map(c => ({
      m: { iso: c.iso, name: c.name, cont: c.cont, cap: c.cap, capName: c.capName, pw: c.pw, ext: c.ext },
      col: c.color, ci: c.colorIdx, a: Math.round(c.army), t: Math.round(c.treasury), eco: Math.round(c.eco), ind: Math.round(c.ind), pop: +c.pop.toFixed(2),
      te: c.tech, mo: +c.morale.toFixed(1), al: c.alive ? 1 : 0, del: c.deleted ? 1 : 0, keep: c.keep ? 1 : 0, lost: Math.round(c.lost),
      ally: [...c.allies], war: [...c.wars], pl: c.planted ? 1 : 0, cu: withImages ? c.customURL : null
    })),
    w: wars.map(w => [w.a, w.b, w.start]), ev: events.slice(0, 60)
  };
}
function makeThumb() {
  const cv = document.createElement('canvas'); cv.width = 236; cv.height = 94;
  const g = cv.getContext('2d'); g.fillStyle = '#0f2a27'; g.fillRect(0, 0, 236, 94);
  baseCtx.putImageData(baseImg, 0, 0); g.imageSmoothingEnabled = true; g.drawImage(baseCanvas, 0, 0, 236, 94);
  try { return cv.toDataURL('image/jpeg', 0.6); } catch (_) { return null; }
}
function saveWorld(withThumb) {
  if (!world) return;
  let ok = true;
  try { localStorage.setItem(K_W + world.id, JSON.stringify(serialize(true))); }
  catch (_) { try { localStorage.setItem(K_W + world.id, JSON.stringify(serialize(false))); } catch (__) { ok = false; } }
  const idx = readIndex(); let e = idx.find(x => x.id === world.id);
  if (!e) { e = { id: world.id }; idx.push(e); }
  e.name = world.name; e.type = world.type; e.day = day; e.upd = Date.now();
  if (withThumb || !e.thumb) e.thumb = makeThumb();
  writeIndex(idx);
  try { localStorage.setItem(K_LAST, world.id); } catch (_) { }
  dirtySave = false;
  if (!ok) toast('Sem espaço para salvar este mundo');
}
setInterval(() => { if (running && dirtySave) saveWorld(false); }, 4000);
setInterval(() => { if (running) saveWorld(true); }, 60000);
window.addEventListener('pagehide', () => { if (running) saveWorld(true); });

function enterWorld(st) {
  world = { id: st.id, name: st.name, type: st.type, seed: st.seed || 0 };
  CONT = st.conts ? st.conts : (st.type === 'real' ? REAL_CONT : {});
  C = [null];
  st.c.forEach((d, i) => C.push(makeCountry(i + 1, d.m)));
  own0.set(rleDec(st.own, NPX));
  wars = []; events = []; selected = null; sticky = null; allyPick = null; ended = false; paused = false; fxs.length = 0; tween = null;
  hubCont = 'ALL'; hubQuery = ''; hubTab = 'countries'; $('#hSearch').value = '';
  buildRegions(); pathCache.clear(); grpCache.clear();
  if (st.fresh) { colorizeAll(); initStats(st.seed || 7); day = 0; casualties = 0; flagsAll = false; flagOp = 0.94; speedIdx = 0; }
  else {
    day = st.day || 0; casualties = st.casualties || 0; flagsAll = !!st.flagsAll; flagOp = st.flagOp || 0.94; speedIdx = st.speedIdx || 0;
    Object.assign(opts, st.opts || {});
    st.c.forEach((d, i) => {
      const c = C[i + 1];
      c.color = d.col || c.color; c.rgb = hex2rgb(c.color); c.colorIdx = d.ci || 0; c.army = d.a; c.treasury = d.t; c.eco = d.eco == null ? 50 : d.eco; c.ind = d.ind == null ? 40 : d.ind;
      c.pop = d.pop == null ? 5 : d.pop; c.tech = d.te; c.morale = d.mo; c.alive = !!d.al && c.regs.length > 0; c.deleted = !!d.del; c.keep = !!d.keep; c.lost = d.lost || 0;
      c.allies = new Set(d.ally || []); c.wars = new Set(d.war || []); c.planted = !!d.pl; c.customURL = d.cu || null; c.cells = c.regs.length;
      if (c.customURL) { const im = new Image(); im.onload = () => { c.custom = coverCanvas(im, 480, 320); c.bmp = c.custom; c.bmpState = 2; repaintFlagOwner(c.id); }; im.src = c.customURL; }
    });
    wars = (st.w || []).map(w => ({ a: w[0], b: w[1], start: w[2] })).filter(w => C[w.a] && C[w.b] && C[w.a].alive && C[w.b].alive);
    events = st.ev || [];
  }
  mode = 'war'; document.querySelectorAll('.mode').forEach(x => x.classList.toggle('active', x.dataset.mode === 'war'));
  $('#bFlags').classList.toggle('on', flagsAll); $('#spdTxt').textContent = SPEEDS[speedIdx] + 'x';
  paintAllBase(); flagCtx.setTransform(1, 0, 0, 1, 0, 0); flagCtx.clearRect(0, 0, flagLayer.width, flagLayer.height);
  if (anyFlags()) repaintFlagsAll();
  warDirty = true; edgeDirty = true;
  $('#menu').classList.add('hidden');
  closeHub(); closeSettings(); closeSheet(); stopDraw();
  running = true; viewInit = false; resize();
  if (st.type === 'real') viewLonLat(10, 30, Math.max(VH / H, minZoom()));
  else if (st.type === 'fiction') viewLonLat(0, 15, Math.max(VH / H, minZoom()));
  else { viewInit = true; cam.z = minZoom(); clampCam(); }
  syncPlay(); refreshAll(); requestDraw();
  world.fresh = false; dirtySave = true; saveWorld(true);
  let seen = false; try { seen = localStorage.getItem('lf2_intro') === '1'; localStorage.setItem('lf2_intro', '1'); } catch (_) { }
  if (!seen) $('#intro').classList.remove('hidden');
  if (st.type === 'blank' && C.length === 1) setTimeout(() => toast('Mapa em branco: abra Configurações e crie um território.'), 300);
}
function openWorldById(id) {
  let st = null; try { st = JSON.parse(localStorage.getItem(K_W + id) || 'null'); } catch (_) { }
  if (!st) { toast('Não consegui abrir esse mundo'); return; }
  enterWorld(st);
}
function createWorld(type, name, seed) {
  const st = newWorldState(type, name, seed);
  enterWorld(st);
}
function resetWorld() {
  const st = newWorldState(world.type, world.name, world.seed); st.id = world.id;
  enterWorld(st); toast('Mundo reiniciado');
}
function exitToMenu() {
  saveWorld(true); running = false; clearTimeout(timer); ptrs.clear();
  if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
  closeSettings(); closeHub(); closeSheet(); stopDraw(); world = null;
  $('#armbar').classList.add('hidden');
  menuView = 'main'; renderMenu(); $('#menu').classList.remove('hidden');
}

/* ================= menu inicial ================= */
let menuView = 'main', newType = 'real';
const mbody = $('#menuBody');
function fmtDate(t) { const d = new Date(t); return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }) + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
function renderMenu() {
  const idx = readIndex().sort((a, b) => b.upd - a.upd);
  let html = '<div class="mw">';
  if (menuView === 'main') {
    const last = idx.find(x => x.id === (localStorage.getItem(K_LAST) || '')) || idx[0];
    html += `<div class="mhero"><img src="assets/logo.png" alt=""><h1>Trincheiras</h1><p>Sandbox de guerras, países e territórios</p></div><div class="mact">`;
    if (last) html += `<button class="mbtn primary" data-act="play" data-id="${last.id}">${ICON('play')}<span>Continuar<small>${esc(last.name)} · dia ${last.day || 0}</small></span></button>`;
    html += `<button class="mbtn" data-act="saved">${ICON('list')}<span>Mundos salvos<small>${idx.length ? idx.length + (idx.length === 1 ? ' mundo' : ' mundos') : 'Nenhum ainda'}</small></span></button>
      <button class="mbtn" data-act="new">${ICON('plus')}<span>Novo mundo<small>Mapa-múndi real, mundo fictício ou mapa em branco</small></span></button>
      <button class="mbtn" data-act="how">${ICON('hold')}<span>Como jogar</span></button></div>`;
  } else if (menuView === 'saved') {
    html += `<div class="mhead"><button class="x" data-act="back" aria-label="Voltar">${ICON('back')}</button><h2>Mundos salvos</h2></div>`;
    if (!idx.length) html += '<p class="empty">Nenhum mundo salvo. Crie um novo mundo para começar.</p>';
    idx.forEach(w => {
      html += `<div class="wcard"><div class="wthumb">${w.thumb ? `<img alt="" src="${w.thumb}">` : ''}</div><div class="winfo"><b>${esc(w.name)}</b><small>${TYPE_NAME[w.type] || ''} · dia ${w.day || 0}<br>${fmtDate(w.upd)}</small>
        <div class="wbtns"><button class="play" data-act="play" data-id="${w.id}">Jogar</button><button data-act="ren" data-id="${w.id}" aria-label="Renomear">${ICON('edit')}</button><button data-act="dup" data-id="${w.id}" aria-label="Duplicar">${ICON('copy')}</button><button data-act="del" data-id="${w.id}" aria-label="Excluir">${ICON('trash')}</button></div></div></div>`;
    });
  } else if (menuView === 'new') {
    const defName = { real: 'Mapa-múndi', fiction: 'Mundo fictício', blank: 'Meu mapa' }[newType];
    html += `<div class="mhead"><button class="x" data-act="back" aria-label="Voltar">${ICON('back')}</button><h2>Novo mundo</h2></div><div class="tcards">
      <button class="tcard ${newType === 'real' ? 'on' : ''}" data-act="type" data-t="real">${ICON('globe')}<span><b>Mapa-múndi real</b><small>168 países com fronteiras, capitais e bandeiras oficiais.</small></span></button>
      <button class="tcard ${newType === 'fiction' ? 'on' : ''}" data-act="type" data-t="fiction">${ICON('dice')}<span><b>Mundo fictício</b><small>Continentes sorteados com países inventados. Cada semente gera um mapa diferente.</small></span></button>
      <button class="tcard ${newType === 'blank' ? 'on' : ''}" data-act="type" data-t="blank">${ICON('blank')}<span><b>Mapa em branco</b><small>Só oceano. Desenhe seus próprios territórios e países.</small></span></button></div>
      <label class="nfield">Nome do mundo<input class="txt" id="nName" maxlength="32" value="${defName}"></label>`;
    if (newType === 'fiction') html += `<label class="nfield">Semente (opcional)<input class="txt" id="nSeed" maxlength="12" placeholder="deixe vazio para sortear" inputmode="numeric"></label>`;
    html += `<button class="mbtn primary" data-act="create" style="width:100%;margin-top:14px">${ICON('check')}<span>Criar e jogar</span></button>`;
  }
  mbody.innerHTML = html + '</div>';
}
mbody.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act, id = b.dataset.id;
  if (a === 'saved') { menuView = 'saved'; renderMenu(); }
  else if (a === 'new') { menuView = 'new'; renderMenu(); }
  else if (a === 'back') { menuView = 'main'; renderMenu(); }
  else if (a === 'how') { $('#intro').classList.remove('hidden'); }
  else if (a === 'type') { newType = b.dataset.t; const nm = $('#nName') ? $('#nName').value : ''; renderMenu(); if ($('#nName') && nm && !['Mapa-múndi', 'Mundo fictício', 'Meu mapa'].includes(nm)) $('#nName').value = nm; }
  else if (a === 'play') openWorldById(id);
  else if (a === 'create') {
    const name = ($('#nName').value || '').trim() || 'Novo mundo';
    let seed = 0; if (newType === 'fiction') { const s = $('#nSeed') ? $('#nSeed').value.trim() : ''; seed = s ? (parseInt(s, 10) || 1) : ((Math.random() * 1e6) | 0) + 1; }
    createWorld(newType, name, seed);
  } else if (a === 'ren') {
    const idx = readIndex(), w = idx.find(x => x.id === id); const v = w && prompt('Novo nome do mundo', w.name);
    if (v && v.trim()) { w.name = v.trim(); writeIndex(idx); try { const st = JSON.parse(localStorage.getItem(K_W + id)); st.name = w.name; localStorage.setItem(K_W + id, JSON.stringify(st)); } catch (_) { } renderMenu(); }
  } else if (a === 'dup') {
    try {
      const st = JSON.parse(localStorage.getItem(K_W + id)), nid = newId(); st.id = nid; st.name += ' (cópia)';
      localStorage.setItem(K_W + nid, JSON.stringify(st));
      const idx = readIndex(), w = idx.find(x => x.id === id); idx.push({ ...w, id: nid, name: st.name, upd: Date.now() }); writeIndex(idx); renderMenu();
    } catch (_) { toast('Não foi possível duplicar (sem espaço)'); }
  } else if (a === 'del') {
    if (!confirm('Excluir este mundo salvo?')) return;
    try { localStorage.removeItem(K_W + id); } catch (_) { }
    writeIndex(readIndex().filter(x => x.id !== id)); renderMenu();
  }
});

/* ================= início ================= */
window.addEventListener('resize', () => { if (running) resize(); });
if (window.ResizeObserver) new ResizeObserver(() => { if (running) resize(); }).observe($('#stage'));
renderMenu();
window.__t = { get C() { return C; }, get R() { return R; }, get wars() { return wars; }, get world() { return world; }, createWorld, tick, declareWar, createTerritory, rasterPoly, enterWorld, exitToMenu, get draw() { return draw; }, cam, viewLonLat: (a, b, z) => { viewLonLat(a, b, z); requestDraw(); }, screenOf: iso => { const c = C.find(x => x && x.iso === iso); return [cam.x + c.capX * cam.z, cam.y + c.capY * cam.z]; } };
})();
