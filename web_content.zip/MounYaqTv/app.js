(function () {
  'use strict';
  var MQ = window.MQ, leagues = MQ.leagues, teams = MQ.teams, matches = MQ.matches, byId = MQ.byId, stateOf = MQ.stateOf;
  var VERSION = '1.0.0';
  var SUPPORT = { phone: '0674022457', intl: '212674022457', email: 'abdelhadielmotaouakel@gmail.com' };

  /* ---------- i18n  [ar, fr, en] ---------- */
  var D = {
    home: ['الرئيسية', 'Accueil', 'Home'], matches: ['المباريات', 'Matchs', 'Matches'], leagues: ['الدوريات', 'Ligues', 'Leagues'],
    women: ['نسائية', 'Féminin', 'Women'], favs: ['المفضلة', 'Favoris', 'Favorites'], settings: ['الإعدادات', 'Réglages', 'Settings'],
    live: ['مباشر', 'Direct', 'Live'], liveNow: ['مباريات مباشرة الآن', 'Matchs en direct', 'Live now'],
    today: ['اليوم', 'Aujourd’hui', 'Today'], todayMatches: ['مباريات اليوم', 'Matchs du jour', 'Today’s matches'],
    nextMatches: ['المباريات القادمة', 'Prochains matchs', 'Next matches'], results: ['آخر النتائج', 'Derniers résultats', 'Latest results'],
    ht: ['استراحة', 'MT', 'HT'], ft: ['انتهت', 'Terminé', 'FT'], all: ['الكل', 'Tous', 'All'], men: ['رجال', 'Hommes', 'Men'],
    standings: ['الترتيب', 'Classement', 'Standings'], scorersT: ['الهدافون', 'Buteurs', 'Top scorers'], round: ['الجولة', 'Journée', 'Round'],
    team: ['الفريق', 'Équipe', 'Team'], pl: ['لعب', 'J', 'P'], w: ['فوز', 'G', 'W'], d: ['تعادل', 'N', 'D'], l: ['خسارة', 'P', 'L'],
    gd: ['فارق', 'Diff', 'GD'], pts: ['نقاط', 'Pts', 'Pts'], goals: ['أهداف', 'Buts', 'Goals'],
    noMatches: ['لا توجد مباريات', 'Aucun match', 'No matches'], search: ['ابحث عن فريق أو دوري…', 'Rechercher équipe ou ligue…', 'Search team or league…'],
    tv: ['القناة الناقلة', 'Diffuseur', 'Broadcaster'], events: ['أحداث المباراة', 'Événements', 'Match events'], stats: ['إحصائيات', 'Statistiques', 'Stats'],
    poss: ['الاستحواذ', 'Possession', 'Possession'], shots: ['التسديدات', 'Tirs', 'Shots'], sot: ['على المرمى', 'Cadrés', 'On target'], corners: ['ركنيات', 'Corners', 'Corners'],
    addFav: ['أضف للمفضلة', 'Ajouter aux favoris', 'Add to favorites'], inFav: ['في المفضلة', 'Dans les favoris', 'In favorites'],
    remind: ['ذكّرني', 'Me rappeler', 'Remind me'], reminded: ['تم تفعيل التذكير', 'Rappel activé', 'Reminder on'], share: ['مشاركة', 'Partager', 'Share'],
    language: ['اللغة', 'Langue', 'Language'], theme: ['المظهر', 'Thème', 'Theme'], dark: ['داكن', 'Sombre', 'Dark'], light: ['فاتح', 'Clair', 'Light'], auto: ['تلقائي', 'Auto', 'Auto'],
    timeFmt: ['صيغة الوقت', 'Format de l’heure', 'Time format'], tz: ['المنطقة الزمنية', 'Fuseau horaire', 'Time zone'], device: ['حسب جهازي', 'Selon l’appareil', 'Device'],
    notif: ['الإشعارات', 'Notifications', 'Notifications'], notifHelp: ['تنبيه عند انطلاق مباريات فرقك المفضلة', 'Alerte au coup d’envoi de vos équipes favorites', 'Alert when your favorite teams kick off'],
    notifBlocked: ['الإشعارات محظورة في المتصفح', 'Notifications bloquées par le navigateur', 'Notifications are blocked in the browser'],
    showWomen: ['إظهار قسم كرة القدم النسائية', 'Afficher le football féminin', 'Show women’s football'],
    install: ['تثبيت التطبيق', 'Installer l’application', 'Install app'], installHelp: ['افتح قائمة المتصفح ثم «إضافة إلى الشاشة الرئيسية»', 'Menu du navigateur › « Ajouter à l’écran d’accueil »', 'Browser menu › “Add to Home screen”'],
    support: ['الدعم والتواصل', 'Support & contact', 'Support & contact'], call: ['اتصال', 'Appeler', 'Call'], email: ['بريد إلكتروني', 'E-mail', 'Email'],
    about: ['حول التطبيق', 'À propos', 'About'], demoNote: ['البيانات المعروضة تجريبية لأغراض العرض. يمكن ربط التطبيق بمزوّد بيانات حقيقي.', 'Les données affichées sont des exemples de démonstration. L’application peut être reliée à un fournisseur de données réel.', 'Data shown is sample data for demonstration. The app can be connected to a real data provider.'],
    clearFavs: ['مسح المفضلة', 'Effacer les favoris', 'Clear favorites'], reset: ['إعادة ضبط التطبيق', 'Réinitialiser l’application', 'Reset app'], sure: ['هل أنت متأكد؟', 'Confirmer ?', 'Are you sure?'],
    womenTitle: ['كرة القدم النسائية', 'Football féminin', 'Women’s football'], womenIntro: ['كل دوريات وبطولات السيدات في مكان واحد', 'Toutes les ligues et compétitions féminines', 'All women’s leagues and competitions'],
    myTeams: ['فرقي', 'Mes équipes', 'My teams'], noFavs: ['لا توجد مفضلة بعد', 'Pas encore de favoris', 'No favorites yet'],
    noFavsHelp: ['افتح أي فريق أو مباراة واضغط على النجمة ☆', 'Ouvrez une équipe ou un match et touchez l’étoile ☆', 'Open a team or match and tap the star ☆'],
    fixtures: ['المباريات', 'Matchs', 'Fixtures'], teamsT: ['الفرق', 'Équipes', 'Teams'], noEvents: ['لا أحداث بعد', 'Pas encore d’événements', 'No events yet'],
    zoneUp: ['تأهل / صدارة', 'Qualification', 'Qualification'], zoneDown: ['منطقة الهبوط', 'Relégation', 'Relegation'], seeAll: ['عرض الكل', 'Voir tout', 'See all'],
    explore: ['استكشف الدوريات', 'Explorer les ligues', 'Explore leagues'], mainLeagues: ['الدوريات الكبرى', 'Grandes ligues', 'Top leagues'],
    womenLeagues: ['دوريات السيدات', 'Ligues féminines', 'Women’s leagues'], menLeagues: ['دوريات الرجال', 'Ligues masculines', 'Men’s leagues'],
    version: ['الإصدار', 'Version', 'Version'], kickoffNow: ['انطلقت المباراة!', 'Coup d’envoi !', 'Kick-off!'], searchRes: ['نتائج البحث', 'Résultats', 'Search results'],
    langName: ['العربية', 'Français', 'English'], h24: ['24 ساعة', '24 h', '24-hour'], h12: ['12 ساعة', '12 h', '12-hour'],
    saved: ['تم', 'Fait', 'Done'], shareText: ['تابع المباريات مباشرة مع MounYaq Tv', 'Suivez les matchs avec MounYaq Tv', 'Follow the matches with MounYaq Tv'], copied: ['تم نسخ الرابط', 'Lien copié', 'Link copied'],
    venueRound: ['الجولة', 'Journée', 'Round'], vs: ['ضد', 'vs', 'vs'], prev: ['السابق', 'Précédent', 'Previous'], next: ['التالي', 'Suivant', 'Next'], close: ['إغلاق', 'Fermer', 'Close'],
    followed: ['مباريات فرقي', 'Matchs de mes équipes', 'My teams’ matches'], notStarted: ['لم تبدأ بعد', 'Pas encore commencé', 'Not started yet']
  };
  var LANGS = ['ar', 'fr', 'en'];
  var LOC = { ar: 'ar-MA-u-nu-latn', fr: 'fr-FR', en: 'en-GB' };
  var TZS = ['auto', 'Africa/Casablanca', 'Europe/Paris', 'Europe/London', 'Asia/Riyadh', 'Africa/Cairo', 'UTC'];

  /* ---------- Settings ---------- */
  var DEF = { lang: 'ar', theme: 'dark', h12: false, tz: 'auto', notif: false, women: true, favTeams: [], remind: [] };
  var S = (function () { try { return Object.assign({}, DEF, JSON.parse(localStorage.getItem('mq_s') || '{}')); } catch (e) { return Object.assign({}, DEF); } })();
  function save() { try { localStorage.setItem('mq_s', JSON.stringify(S)); } catch (e) { } }
  function t(k) { var v = D[k]; return v ? v[LANGS.indexOf(S.lang)] : k; }
  var tzOpt = function () { return S.tz === 'auto' ? undefined : S.tz; };

  /* ---------- helpers ---------- */
  var $ = function (s) { return document.querySelector(s); };
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lgOf(id) { return leagues.filter(function (l) { return l.id === id; })[0]; }
  function lname(l) { return l.name[S.lang]; }
  function tname(id) { return teams[id].name; }
  function timeStr(ms) { return new Intl.DateTimeFormat(LOC[S.lang], { hour: '2-digit', minute: '2-digit', hour12: S.h12, timeZone: tzOpt() }).format(ms); }
  function dayKey(ms) { return new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: tzOpt() }).format(ms); }
  function dayLabel(ms) { return new Intl.DateTimeFormat(LOC[S.lang], { weekday: 'short', day: 'numeric', month: 'short', timeZone: tzOpt() }).format(ms); }
  function dayLong(ms) { return new Intl.DateTimeFormat(LOC[S.lang], { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: tzOpt() }).format(ms); }
  function crest(id, sz) {
    var tm = teams[id], w = tm.name.split(/\s+/), ini = (w.length > 1 ? w[0][0] + w[1][0] : tm.name.slice(0, 2)).toUpperCase();
    var h = MQ.hash(id) % 360;
    return '<span class="crest' + (tm.women ? ' w' : '') + '" style="--h:' + h + ';' + (sz ? 'width:' + sz + 'px;height:' + sz + 'px;font-size:' + Math.round(sz * .38) + 'px' : '') + '">' + esc(ini) + '</span>';
  }
  function isFav(id) { return S.favTeams.indexOf(id) > -1; }
  function toast(msg) { var el = $('#toast'); el.textContent = msg; el.classList.remove('hidden'); clearTimeout(toast._t); toast._t = setTimeout(function () { el.classList.add('hidden'); }, 2600); }

  /* ---------- match rows ---------- */
  function statusCell(m, s) {
    if (s.status === 'NS') return '<span class="ko">' + timeStr(m.ko) + '</span>';
    if (s.status === 'LIVE') return '<span class="lv"><i></i>' + s.minute + '’</span>';
    if (s.status === 'HT') return '<span class="lv ht">' + t('ht') + '</span>';
    return '<span class="fin">' + t('ft') + '</span>';
  }
  function mrow(m) {
    var s = stateOf(m), fav = isFav(m.home) || isFav(m.away);
    return '<a class="mrow ' + s.status + (fav ? ' fav' : '') + '" href="#/match/' + m.id + '">' +
      '<div class="mt">' + statusCell(m, s) + '</div>' +
      '<div class="tm"><div class="side">' + crest(m.home) + '<span>' + esc(tname(m.home)) + '</span></div><div class="side">' + crest(m.away) + '<span>' + esc(tname(m.away)) + '</span></div></div>' +
      '<div class="sc">' + (s.status === 'NS' ? '<em>–</em><em>–</em>' : '<b>' + s.hg + '</b><b>' + s.ag + '</b>') + '</div></a>';
  }
  function groupHtml(list, opts) {
    opts = opts || {};
    if (!list.length) return '<div class="empty">' + t('noMatches') + '</div>';
    var order = leagues.map(function (l) { return l.id; }), groups = {};
    list.forEach(function (m) { (groups[m.league] = groups[m.league] || []).push(m); });
    return Object.keys(groups).sort(function (a, b) { return order.indexOf(a) - order.indexOf(b); }).map(function (id) {
      var lg = lgOf(id);
      return '<section class="grp"><a class="gh" href="#/league/' + id + '/fixtures"><span class="fl">' + lg.flag + '</span><b>' + esc(lname(lg)) + '</b>' + (lg.women ? '<span class="wtag">♀</span>' : '') + '<span class="arr">›</span></a>' +
        groups[id].sort(function (a, b) { return a.ko - b.ko; }).map(mrow).join('') + '</section>';
    }).join('');
  }
  function lgCard(lg) {
    return '<a class="lcard' + (lg.women ? ' w' : '') + '" href="#/league/' + lg.id + '/standings"><span class="lflag">' + lg.flag + '</span><span class="ln">' + esc(lname(lg)) + '</span></a>';
  }
  function head(txt, link) { return '<div class="sh"><h2>' + txt + '</h2>' + (link ? '<a href="' + link + '">' + t('seeAll') + '</a>' : '') + '</div>'; }

  /* ---------- pages ---------- */
  var mFilter = 'all', mDay = 0, roundSel = {};

  function pageHome() {
    var now = Date.now(), tk = dayKey(now);
    var live = matches.filter(function (m) { var s = stateOf(m).status; return s === 'LIVE' || s === 'HT'; });
    var up = matches.filter(function (m) { return m.ko > now && dayKey(m.ko) === tk; }).slice(0, 8);
    var done = matches.filter(function (m) { return stateOf(m).status === 'FT'; }).sort(function (a, b) { return b.ko - a.ko; }).slice(0, 8);
    var wup = matches.filter(function (m) { return lgOf(m.league).women && stateOf(m).status !== 'FT'; }).slice(0, 4);
    var mine = matches.filter(function (m) { return (isFav(m.home) || isFav(m.away)) && stateOf(m).status !== 'FT'; }).slice(0, 5);
    var h = '<div class="hero"><div><small>' + dayLong(now) + '</small><h1>MounYaq <b>Tv</b></h1></div><div class="livecount"><i></i>' + live.length + ' ' + t('live') + '</div></div>';
    if (live.length) h += head('🔴 ' + t('liveNow')) + groupHtml(live);
    if (mine.length) h += head('⭐ ' + t('followed'), '#/favorites') + groupHtml(mine);
    h += head(t('nextMatches'), '#/matches') + groupHtml(up);
    if (S.women && wup.length) h += '<div class="wband"><div><b>♀ ' + t('womenTitle') + '</b><small>' + t('womenIntro') + '</small></div><a href="#/women">' + t('seeAll') + '</a></div>' + groupHtml(wup);
    h += head(t('mainLeagues'), '#/leagues') + '<div class="lgrid">' + leagues.filter(function (l) { return !l.women; }).slice(0, 8).map(lgCard).join('') + '</div>';
    h += head(t('results')) + groupHtml(done);
    return h;
  }

  function pageMatches() {
    var now = Date.now(), days = [-3, -2, -1, 0, 1, 2, 3], key = dayKey(now + mDay * 86400000);
    var strip = '<div class="strip">' + days.map(function (o) {
      var ms = now + o * 86400000;
      return '<button data-act="day" data-v="' + o + '" class="' + (o === mDay ? 'on' : '') + '">' + (o === 0 ? t('today') : dayLabel(ms)) + '</button>';
    }).join('') + '</div>';
    var fl = ['all', 'live', 'men'].concat(S.women ? ['women'] : []);
    var chips = '<div class="chips">' + fl.map(function (f) { return '<button data-act="filter" data-v="' + f + '" class="' + (f === mFilter ? 'on' : '') + '">' + (f === 'women' ? '♀ ' + t('women') : f === 'live' ? '🔴 ' + t('live') : t(f)) + '</button>'; }).join('') + '</div>';
    var list = matches.filter(function (m) {
      if (dayKey(m.ko) !== key) return false;
      var w = lgOf(m.league).women, s = stateOf(m).status;
      if (!S.women && w) return false;
      if (mFilter === 'live') return s === 'LIVE' || s === 'HT';
      if (mFilter === 'men') return !w;
      if (mFilter === 'women') return w;
      return true;
    });
    return strip + chips + groupHtml(list);
  }

  function pageLeagues() {
    var h = head(t('menLeagues')) + '<div class="lgrid">' + leagues.filter(function (l) { return !l.women; }).map(lgCard).join('') + '</div>';
    if (S.women) h += head('♀ ' + t('womenLeagues')) + '<div class="lgrid">' + leagues.filter(function (l) { return l.women; }).map(lgCard).join('') + '</div>';
    return h;
  }

  function currentRound(id) {
    var ms = matches.filter(function (m) { return m.league === id; }), r = 1;
    for (var i = 0; i < ms.length; i++) { if (stateOf(ms[i]).status !== 'FT') { r = ms[i].round; break; } r = ms[i].round; }
    return r;
  }
  function pageLeague(id, tab) {
    var lg = lgOf(id); if (!lg) return '<div class="empty">404</div>';
    tab = tab || 'standings';
    var h = '<div class="lhead' + (lg.women ? ' w' : '') + '"><span class="lflag big">' + lg.flag + '</span><div><h1>' + esc(lname(lg)) + '</h1><small>' + t('tv') + ': ' + esc(lg.tv) + '</small></div></div>';
    h += '<div class="tabs2">' + ['standings', 'fixtures', 'scorersT', 'teamsT'].map(function (k) { var key = k === 'scorersT' ? 'scorers' : k === 'teamsT' ? 'teams' : k; return '<a class="' + (tab === key ? 'on' : '') + '" href="#/league/' + id + '/' + key + '">' + t(k) + '</a>'; }).join('') + '</div>';
    if (tab === 'standings') {
      var rows = MQ.standings(id), z = lg.zone;
      h += '<div class="tbl"><div class="tr th"><span>#</span><span class="tn">' + t('team') + '</span><span>' + t('pl') + '</span><span>' + t('w') + '</span><span>' + t('d') + '</span><span>' + t('l') + '</span><span>' + t('gd') + '</span><span>' + t('pts') + '</span></div>' +
        rows.map(function (r, i) {
          var cls = i < z.up ? 'up' : (z.down && i >= rows.length - z.down ? 'down' : '');
          return '<a class="tr ' + cls + '" href="#/team/' + r.team + '"><span>' + (i + 1) + '</span><span class="tn">' + crest(r.team, 22) + esc(tname(r.team)) + '</span><span>' + r.p + '</span><span>' + r.w + '</span><span>' + r.d + '</span><span>' + r.l + '</span><span>' + (r.gd > 0 ? '+' : '') + r.gd + '</span><span><b>' + r.pts + '</b></span></a>';
        }).join('') + '</div><div class="legend"><i class="up"></i>' + t('zoneUp') + (z.down ? '<i class="down"></i>' + t('zoneDown') : '') + '</div>';
    } else if (tab === 'fixtures') {
      var rd = roundSel[id] || currentRound(id), max = 14;
      h += '<div class="rsel"><button data-act="round" data-id="' + id + '" data-v="-1"' + (rd <= 1 ? ' disabled' : '') + '>‹</button><b>' + t('round') + ' ' + rd + '</b><button data-act="round" data-id="' + id + '" data-v="1"' + (rd >= max ? ' disabled' : '') + '>›</button></div>';
      h += groupHtml(matches.filter(function (m) { return m.league === id && m.round === rd; }));
    } else if (tab === 'scorers') {
      var sc = MQ.scorers(id);
      h += sc.length ? '<div class="tbl">' + sc.map(function (s, i) { return '<a class="tr sc2" href="#/team/' + s.team + '"><span>' + (i + 1) + '</span><span class="tn">' + crest(s.team, 22) + '<span>' + esc(s.player) + '<small>' + esc(tname(s.team)) + '</small></span></span><span><b>' + s.goals + '</b></span></a>'; }).join('') + '</div>' : '<div class="empty">' + t('noMatches') + '</div>';
    } else {
      h += '<div class="tgrid">' + lg.teamIds.map(function (tid) { return '<a class="tcard" href="#/team/' + tid + '">' + crest(tid, 44) + '<span>' + esc(tname(tid)) + '</span></a>'; }).join('') + '</div>';
    }
    return h;
  }

  function pageWomen() {
    var now = Date.now(), tk = dayKey(now), wl = leagues.filter(function (l) { return l.women; });
    var wm = matches.filter(function (m) { return lgOf(m.league).women; });
    var live = wm.filter(function (m) { var s = stateOf(m).status; return s === 'LIVE' || s === 'HT'; });
    var today = wm.filter(function (m) { return dayKey(m.ko) === tk && stateOf(m).status === 'NS'; });
    var next = wm.filter(function (m) { return m.ko > now && dayKey(m.ko) !== tk; }).slice(0, 8);
    var done = wm.filter(function (m) { return stateOf(m).status === 'FT'; }).sort(function (a, b) { return b.ko - a.ko; }).slice(0, 8);
    var h = '<div class="whero"><span>♀</span><div><h1>' + t('womenTitle') + '</h1><small>' + t('womenIntro') + '</small></div></div>';
    if (live.length) h += head('🔴 ' + t('liveNow')) + groupHtml(live);
    h += head(t('womenLeagues')) + '<div class="lgrid">' + wl.map(lgCard).join('') + '</div>';
    if (today.length) h += head(t('todayMatches')) + groupHtml(today);
    h += head(t('nextMatches')) + groupHtml(next);
    h += head(t('results')) + groupHtml(done);
    return h;
  }

  function pageFavs() {
    var h = head('⭐ ' + t('myTeams'));
    if (!S.favTeams.length) return h + '<div class="empty big">☆<br>' + t('noFavs') + '<small>' + t('noFavsHelp') + '</small></div>';
    h += '<div class="tgrid">' + S.favTeams.filter(function (i) { return teams[i]; }).map(function (tid) { return '<a class="tcard" href="#/team/' + tid + '">' + crest(tid, 44) + '<span>' + esc(tname(tid)) + '</span></a>'; }).join('') + '</div>';
    var ms = matches.filter(function (m) { return isFav(m.home) || isFav(m.away); });
    var now = Date.now();
    h += head(t('nextMatches')) + groupHtml(ms.filter(function (m) { return stateOf(m).status !== 'FT'; }).slice(0, 8));
    h += head(t('results')) + groupHtml(ms.filter(function (m) { return stateOf(m).status === 'FT'; }).sort(function (a, b) { return b.ko - a.ko; }).slice(0, 8));
    return h;
  }

  var deferred = null;
  function seg(act, items, cur) { return '<div class="seg">' + items.map(function (i) { return '<button data-act="' + act + '" data-v="' + i[0] + '" class="' + (String(cur) === String(i[0]) ? 'on' : '') + '">' + i[1] + '</button>'; }).join('') + '</div>'; }
  function sw(act, on) { return '<button class="sw' + (on ? ' on' : '') + '" data-act="' + act + '" aria-pressed="' + on + '"><i></i></button>'; }
  function pageSettings() {
    var h = '<div class="set">';
    h += '<div class="card"><div class="row"><b>' + t('language') + '</b>' + seg('lang', LANGS.map(function (l) { return [l, D.langName[LANGS.indexOf(l)]]; }), S.lang) + '</div>';
    h += '<div class="row"><b>' + t('theme') + '</b>' + seg('theme', [['dark', t('dark')], ['light', t('light')], ['auto', t('auto')]], S.theme) + '</div>';
    h += '<div class="row"><b>' + t('timeFmt') + '</b>' + seg('h12', [['0', t('h24')], ['1', t('h12')]], S.h12 ? 1 : 0) + '</div>';
    h += '<div class="row"><b>' + t('tz') + '</b><select data-act="tz">' + TZS.map(function (z) { return '<option value="' + z + '"' + (z === S.tz ? ' selected' : '') + '>' + (z === 'auto' ? t('device') : z) + '</option>'; }).join('') + '</select></div></div>';
    h += '<div class="card"><div class="row"><div><b>' + t('notif') + '</b><small>' + t('notifHelp') + '</small></div>' + sw('notif', S.notif) + '</div>';
    h += '<div class="row"><b>♀ ' + t('showWomen') + '</b>' + sw('women', S.women) + '</div></div>';
    h += '<div class="card"><div class="row"><div><b>' + t('install') + '</b><small>' + t('installHelp') + '</small></div><button class="btn" data-act="install">⬇</button></div>';
    h += '<div class="row"><b>' + t('share') + '</b><button class="btn" data-act="shareapp">↗</button></div>';
    h += '<div class="row"><b>' + t('clearFavs') + '</b><button class="btn ghost" data-act="clearfavs">🗑</button></div>';
    h += '<div class="row"><b>' + t('reset') + '</b><button class="btn ghost danger" data-act="reset">↺</button></div></div>';
    h += '<div class="card support"><h3>🎧 ' + t('support') + '</h3>' +
      '<a class="srow" href="tel:+' + SUPPORT.intl + '"><span>📞</span><div><b>' + SUPPORT.phone + '</b><small>' + t('call') + '</small></div></a>' +
      '<a class="srow" href="https://wa.me/' + SUPPORT.intl + '" target="_blank" rel="noopener"><span>💬</span><div><b>WhatsApp</b><small>+' + SUPPORT.intl + '</small></div></a>' +
      '<a class="srow" href="mailto:' + SUPPORT.email + '"><span>✉️</span><div><b>' + SUPPORT.email + '</b><small>' + t('email') + '</small></div></a></div>';
    h += '<div class="card about"><h3>' + t('about') + '</h3><p>MounYaq Tv · ' + t('version') + ' ' + VERSION + '</p><p class="note">' + t('demoNote') + '</p></div></div>';
    return h;
  }

  function pageSearch(q) {
    q = q.toLowerCase();
    var tm = Object.keys(teams).filter(function (id) { return (teams[id].name + (teams[id].women ? ' women féminin نسائية' : '')).toLowerCase().indexOf(q) > -1; }).slice(0, 14);
    var lg = leagues.filter(function (l) { return (l.name.ar + l.name.fr + l.name.en).toLowerCase().indexOf(q) > -1; });
    var h = head(t('searchRes'));
    if (lg.length) h += '<div class="lgrid">' + lg.map(lgCard).join('') + '</div>';
    if (tm.length) h += head(t('teamsT')) + '<div class="tgrid">' + tm.map(function (tid) { return '<a class="tcard" href="#/team/' + tid + '">' + crest(tid, 44) + '<span>' + esc(tname(tid)) + (teams[tid].women ? ' ♀' : '') + '</span></a>'; }).join('') + '</div>';
    if (!lg.length && !tm.length) h += '<div class="empty">' + t('noMatches') + '</div>';
    return h;
  }

  /* ---------- modals ---------- */
  function bar(label, a, b) {
    var tot = (a + b) || 1;
    return '<div class="stat"><span>' + a + '</span><div><small>' + label + '</small><div class="bars"><i style="width:' + (a / tot * 100) + '%"></i><u style="width:' + (b / tot * 100) + '%"></u></div></div><span>' + b + '</span></div>';
  }
  function modalMatch(id) {
    var m = byId[id]; if (!m) return '';
    var s = stateOf(m), lg = lgOf(m.league), f = Math.max(s.minute, 1) / 90, st = m.stats, rem = S.remind.indexOf(id) > -1;
    var scoreTxt = s.status === 'NS' ? '<span class="vsx">' + timeStr(m.ko) + '</span>' : '<b>' + s.hg + '</b><i>-</i><b>' + s.ag + '</b>';
    var stt = s.status === 'LIVE' ? '<span class="lv"><i></i>' + s.minute + '’</span>' : s.status === 'HT' ? '<span class="lv ht">' + t('ht') + '</span>' : s.status === 'FT' ? '<span class="fin">' + t('ft') + '</span>' : '<span class="ko">' + t('notStarted') + '</span>';
    var h = '<div class="sheet"><button class="x" data-act="close" aria-label="' + t('close') + '">✕</button>' +
      '<div class="mh"><a href="#/league/' + lg.id + '/fixtures">' + lg.flag + ' ' + esc(lname(lg)) + ' · ' + t('round') + ' ' + m.round + '</a><small>' + dayLong(m.ko) + '</small></div>' +
      '<div class="big"><a class="bt" href="#/team/' + m.home + '">' + crest(m.home, 56) + '<span>' + esc(tname(m.home)) + '</span></a><div class="bs">' + scoreTxt + '<div>' + stt + '</div></div><a class="bt" href="#/team/' + m.away + '">' + crest(m.away, 56) + '<span>' + esc(tname(m.away)) + '</span></a></div>' +
      '<div class="acts">' + (s.status === 'NS' ? '<button class="btn pill ' + (rem ? 'on' : '') + '" data-act="remind" data-id="' + id + '">🔔 ' + (rem ? t('reminded') : t('remind')) + '</button>' : '') +
      '<button class="btn pill" data-act="sharematch" data-id="' + id + '">↗ ' + t('share') + '</button></div>' +
      '<div class="info">📺 ' + t('tv') + ': <b>' + esc(lg.tv) + '</b></div>';
    if (s.status !== 'NS') {
      h += '<h3>' + t('events') + '</h3>' + (s.goals.length ? '<div class="ev">' + s.goals.map(function (g) { return '<div class="e ' + g.side + '"><span class="mn">' + g.min + '’</span><span>⚽ ' + esc(g.player) + '</span></div>'; }).join('') + '</div>' : '<div class="empty sm">' + t('noEvents') + '</div>');
      h += '<h3>' + t('stats') + '</h3>' + bar(t('poss') + ' %', st.poss[0], st.poss[1]) + bar(t('shots'), Math.round(st.shots[0] * f), Math.round(st.shots[1] * f)) + bar(t('sot'), Math.round(st.sot[0] * f), Math.round(st.sot[1] * f)) + bar(t('corners'), Math.round(st.corners[0] * f), Math.round(st.corners[1] * f));
    }
    return h + '</div>';
  }
  function modalTeam(id) {
    var tm = teams[id]; if (!tm) return '';
    var ms = matches.filter(function (m) { return m.home === id || m.away === id; });
    var past = ms.filter(function (m) { return stateOf(m).status === 'FT'; }).slice(-5).reverse();
    var fut = ms.filter(function (m) { return stateOf(m).status !== 'FT'; }).slice(0, 5);
    return '<div class="sheet"><button class="x" data-act="close" aria-label="' + t('close') + '">✕</button><div class="th2">' + crest(id, 72) + '<h2>' + esc(tm.name) + (tm.women ? ' ♀' : '') + '</h2>' +
      '<button class="btn pill ' + (isFav(id) ? 'on' : '') + '" data-act="favteam" data-id="' + id + '">' + (isFav(id) ? '★ ' + t('inFav') : '☆ ' + t('addFav')) + '</button></div>' +
      '<div class="chips2">' + tm.leagues.map(function (l) { var lg = lgOf(l); return '<a href="#/league/' + l + '/standings">' + lg.flag + ' ' + esc(lname(lg)) + '</a>'; }).join('') + '</div>' +
      '<h3>' + t('nextMatches') + '</h3>' + groupHtml(fut) + '<h3>' + t('results') + '</h3>' + groupHtml(past) + '</div>';
  }

  /* ---------- router / render ---------- */
  var searchQ = '', baseHash = '#/home';
  var TABS = [['home', '🏠', 'home'], ['matches', '⚽', 'matches'], ['leagues', '🏆', 'leagues'], ['women', '♀', 'women'], ['favorites', '⭐', 'favs'], ['settings', '⚙️', 'settings']];

  function parse() { var h = location.hash || '#/home'; var p = h.replace(/^#\/?/, '').split('/'); return { name: p[0] || 'home', a: p[1], b: p[2] }; }
  function renderBase(r) {
    if (searchQ.length >= 2) return pageSearch(searchQ);
    switch (r.name) {
      case 'matches': return pageMatches();
      case 'leagues': return pageLeagues();
      case 'league': return pageLeague(r.a, r.b);
      case 'women': return S.women ? pageWomen() : pageHome();
      case 'favorites': return pageFavs();
      case 'settings': return pageSettings();
      default: return pageHome();
    }
  }
  function render() {
    var r = parse(), modal = (r.name === 'match' || r.name === 'team');
    var base = modal ? parse2(baseHash) : r;
    var y = window.scrollY, app = $('#app');
    app.innerHTML = renderBase(base);
    var activeTab = base.name === 'league' ? (lgOf(base.a) && lgOf(base.a).women ? 'women' : 'leagues') : base.name;
    $('#tabs').innerHTML = TABS.filter(function (x) { return S.women || x[0] !== 'women'; }).map(function (x) {
      return '<a href="#/' + x[0] + '" class="' + (activeTab === x[0] ? 'on' : '') + '"><span>' + x[1] + '</span><small>' + t(x[2]) + '</small></a>';
    }).join('');
    var mo = $('#modal');
    if (modal) { mo.innerHTML = r.name === 'match' ? modalMatch(r.a) : modalTeam(r.a); mo.classList.remove('hidden'); document.body.classList.add('lock'); }
    else { mo.classList.add('hidden'); mo.innerHTML = ''; document.body.classList.remove('lock'); }
    window.scrollTo(0, modal ? y : y);
  }
  function parse2(h) { var p = h.replace(/^#\/?/, '').split('/'); return { name: p[0] || 'home', a: p[1], b: p[2] }; }
  function onHash() {
    var r = parse();
    if (r.name !== 'match' && r.name !== 'team') { var changed = baseHash !== (location.hash || '#/home'); baseHash = location.hash || '#/home'; if (changed) window.scrollTo(0, 0); }
    render();
  }

  function applyPrefs() {
    var de = document.documentElement; de.lang = S.lang; de.dir = S.lang === 'ar' ? 'rtl' : 'ltr';
    var th = S.theme === 'auto' ? (window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : S.theme;
    de.setAttribute('data-theme', th);
    var mt = document.querySelector('meta[name=theme-color]'); if (mt) mt.content = th === 'light' ? '#f2f7f4' : '#0b1410';
    $('#q').placeholder = t('search');
    document.title = 'MounYaq Tv';
  }

  /* ---------- notifications ---------- */
  var notified = {};
  function notify(m) {
    var title = '⚽ ' + t('kickoffNow'), body = tname(m.home) + ' – ' + tname(m.away);
    if ('Notification' in window && Notification.permission === 'granted') { try { new Notification(title, { body: body, icon: 'icon.svg' }); return; } catch (e) { } }
    toast(title + ' ' + body);
  }
  setInterval(function () {
    var now = Date.now();
    matches.forEach(function (m) {
      if (notified[m.id]) return;
      var d = m.ko - now; if (d > 60000 || d < -120000) return;
      var want = S.remind.indexOf(m.id) > -1 || (S.notif && (isFav(m.home) || isFav(m.away)));
      if (want) { notified[m.id] = 1; notify(m); }
    });
  }, 20000);
  setInterval(function () { if (document.visibilityState === 'visible' && document.activeElement !== $('#q')) render(); }, 30000);

  /* ---------- events ---------- */
  function shareLink(text) {
    var url = location.href.split('#')[0];
    if (navigator.share) { navigator.share({ title: 'MounYaq Tv', text: text, url: url }).catch(function () { }); }
    else if (navigator.clipboard) { navigator.clipboard.writeText(text + ' ' + url).then(function () { toast(t('copied')); }); }
  }
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-act]');
    if (!el) { if (e.target.id === 'modal') location.hash = baseHash; return; }
    var a = el.getAttribute('data-act'), v = el.getAttribute('data-v'), id = el.getAttribute('data-id');
    switch (a) {
      case 'close': location.hash = baseHash; return;
      case 'day': mDay = +v; break;
      case 'filter': mFilter = v; break;
      case 'round': { var cur = roundSel[id] || currentRound(id); roundSel[id] = Math.min(14, Math.max(1, cur + (+v))); break; }
      case 'lang': S.lang = v; applyPrefs(); break;
      case 'theme': S.theme = v; applyPrefs(); break;
      case 'h12': S.h12 = v === '1'; break;
      case 'women': S.women = !S.women; break;
      case 'notif':
        if (!S.notif) {
          if (!('Notification' in window)) { toast(t('notifBlocked')); return; }
          Notification.requestPermission().then(function (p) { S.notif = p === 'granted'; if (!S.notif) toast(t('notifBlocked')); save(); render(); });
          return;
        }
        S.notif = false; break;
      case 'favteam': var i = S.favTeams.indexOf(id); if (i > -1) S.favTeams.splice(i, 1); else S.favTeams.push(id); break;
      case 'remind':
        var j = S.remind.indexOf(id); if (j > -1) S.remind.splice(j, 1); else { S.remind.push(id); if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission(); toast(t('reminded')); } break;
      case 'sharematch': var mm = byId[id]; shareLink(tname(mm.home) + ' vs ' + tname(mm.away) + ' – MounYaq Tv'); return;
      case 'shareapp': shareLink(t('shareText')); return;
      case 'install':
        if (deferred) { deferred.prompt(); deferred = null; } else toast(t('installHelp')); return;
      case 'clearfavs': S.favTeams = []; S.remind = []; toast(t('saved')); break;
      case 'reset': if (confirm(t('sure'))) { S = Object.assign({}, DEF, { favTeams: [], remind: [] }); applyPrefs(); toast(t('saved')); } else return; break;
    }
    save(); render();
  });
  document.addEventListener('change', function (e) { if (e.target.getAttribute && e.target.getAttribute('data-act') === 'tz') { S.tz = e.target.value; save(); render(); } });
  $('#q').addEventListener('input', function (e) { searchQ = e.target.value.trim(); render(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('#modal').classList.contains('hidden')) location.hash = baseHash; });
  window.addEventListener('hashchange', function () { onHash(); });
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; });

  if ('serviceWorker' in navigator && /^https?:/.test(location.protocol)) { navigator.serviceWorker.register('sw.js').catch(function () { }); }

  applyPrefs();
  onHash();
})();
