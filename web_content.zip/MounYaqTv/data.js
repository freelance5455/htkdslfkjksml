/* MounYaq Tv — data layer
 * Sample data engine: generates leagues, teams, fixtures, live scores, events and standings
 * relative to the current date, so the app always looks "alive".
 * To use real data, replace window.MQ below with results from a football API
 * (keep the same shapes: leagues[], teams{}, matches[] and the helpers stateOf/standings/scorers).
 */
(function () {
  'use strict';

  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function slug(s) { return s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); }

  /* ---------- Leagues ---------- */
  var LEAGUES = [
    // Men
    { id: 'botola', women: false, flag: '🇲🇦', tv: 'Arryadia / SNRT', zone: { up: 2, down: 2 }, name: { ar: 'البطولة الاحترافية إنوي', fr: 'Botola Pro Inwi', en: 'Botola Pro' }, teams: ['Raja Casablanca', 'Wydad AC', 'AS FAR', 'RS Berkane', 'FUS Rabat', 'Maghreb Fès', 'Hassania Agadir', 'Difaâ El Jadida'] },
    { id: 'pl', women: false, flag: '🇬🇧', tv: 'beIN Sports', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الإنجليزي الممتاز', fr: 'Premier League', en: 'Premier League' }, teams: ['Arsenal', 'Manchester City', 'Liverpool', 'Chelsea', 'Manchester United', 'Tottenham', 'Newcastle', 'Aston Villa'] },
    { id: 'liga', women: false, flag: '🇪🇸', tv: 'beIN Sports', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الإسباني', fr: 'La Liga', en: 'La Liga' }, teams: ['Real Madrid', 'Barcelona', 'Atlético Madrid', 'Sevilla', 'Real Sociedad', 'Villarreal', 'Real Betis', 'Athletic Club'] },
    { id: 'seriea', women: false, flag: '🇮🇹', tv: 'beIN Sports', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الإيطالي', fr: 'Serie A', en: 'Serie A' }, teams: ['Inter', 'AC Milan', 'Juventus', 'Napoli', 'Roma', 'Lazio', 'Atalanta', 'Fiorentina'] },
    { id: 'bundes', women: false, flag: '🇩🇪', tv: 'beIN Sports', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الألماني', fr: 'Bundesliga', en: 'Bundesliga' }, teams: ['Bayern München', 'Borussia Dortmund', 'Bayer Leverkusen', 'RB Leipzig', 'VfB Stuttgart', 'Eintracht Frankfurt', 'SC Freiburg', 'VfL Wolfsburg'] },
    { id: 'ligue1', women: false, flag: '🇫🇷', tv: 'beIN Sports', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الفرنسي', fr: 'Ligue 1', en: 'Ligue 1' }, teams: ['Paris Saint-Germain', 'Marseille', 'Monaco', 'Lyon', 'Lille', 'Nice', 'Lens', 'Rennes'] },
    { id: 'ucl', women: false, flag: '🇪🇺', tv: 'beIN Sports', zone: { up: 4, down: 0 }, name: { ar: 'دوري أبطال أوروبا', fr: 'Ligue des champions', en: 'Champions League' }, teams: ['Real Madrid', 'Manchester City', 'Bayern München', 'Paris Saint-Germain', 'Inter', 'Barcelona', 'Arsenal', 'Juventus'] },
    { id: 'caf', women: false, flag: '🌍', tv: 'beIN Sports / Arryadia', zone: { up: 4, down: 0 }, name: { ar: 'دوري أبطال أفريقيا', fr: 'Ligue des champions CAF', en: 'CAF Champions League' }, teams: ['Al Ahly', 'Wydad AC', 'Raja Casablanca', 'Pyramids', 'Mamelodi Sundowns', 'Espérance Tunis', 'RS Berkane', 'TP Mazembe'] },
    // Women
    { id: 'botola-w', women: true, flag: '🇲🇦', tv: 'Arryadia', zone: { up: 2, down: 2 }, name: { ar: 'البطولة الوطنية النسائية', fr: 'Championnat féminin du Maroc', en: 'Moroccan Women’s League' }, teams: ['AS FAR', 'Sporting Casablanca', 'Wydad AC', 'Mohammedia', 'Raja Casablanca', 'FUS Rabat', 'Ittihad Chamalal', 'Hassania Agadir'] },
    { id: 'wafcon', women: true, flag: '🌍', tv: 'beIN Sports / Arryadia', zone: { up: 4, down: 0 }, name: { ar: 'كأس أمم أفريقيا للسيدات', fr: 'CAN féminine', en: 'Women’s AFCON' }, teams: ['Morocco', 'Nigeria', 'South Africa', 'Ghana', 'Zambia', 'Senegal', 'Algeria', 'Tunisia'] },
    { id: 'wucl', women: true, flag: '🇪🇺', tv: 'DAZN', zone: { up: 4, down: 0 }, name: { ar: 'دوري أبطال أوروبا للسيدات', fr: 'Ligue des champions féminine', en: 'Women’s Champions League' }, teams: ['Barcelona', 'Lyon', 'Chelsea', 'Arsenal', 'VfL Wolfsburg', 'Bayern München', 'Paris Saint-Germain', 'Real Madrid'] },
    { id: 'wsl', women: true, flag: '🇬🇧', tv: 'Sky Sports', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الإنجليزي للسيدات', fr: 'Women’s Super League', en: 'Women’s Super League' }, teams: ['Chelsea', 'Arsenal', 'Manchester City', 'Manchester United', 'Liverpool', 'Tottenham', 'Aston Villa', 'Brighton'] },
    { id: 'ligaf', women: true, flag: '🇪🇸', tv: 'DAZN', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الإسباني للسيدات', fr: 'Liga F', en: 'Liga F' }, teams: ['Barcelona', 'Real Madrid', 'Atlético Madrid', 'Levante', 'Athletic Club', 'Real Sociedad', 'Madrid CFF', 'Granada'] },
    { id: 'd1arkema', women: true, flag: '🇫🇷', tv: 'DAZN', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الفرنسي للسيدات', fr: 'Arkema Première Ligue', en: 'Première Ligue (Women)' }, teams: ['Lyon', 'Paris Saint-Germain', 'Paris FC', 'Fleury', 'Montpellier', 'Nantes', 'Dijon', 'Reims'] },
    { id: 'bundes-w', women: true, flag: '🇩🇪', tv: 'DAZN', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الألماني للسيدات', fr: 'Frauen-Bundesliga', en: 'Frauen-Bundesliga' }, teams: ['Bayern München', 'VfL Wolfsburg', 'Eintracht Frankfurt', 'Bayer Leverkusen', 'Hoffenheim', 'RB Leipzig', 'Freiburg', 'Werder Bremen'] },
    { id: 'nwsl', women: true, flag: '🇺🇸', tv: 'Paramount+ / CBS', zone: { up: 2, down: 2 }, name: { ar: 'الدوري الأمريكي للسيدات', fr: 'NWSL', en: 'NWSL' }, teams: ['Gotham FC', 'Orlando Pride', 'Washington Spirit', 'Portland Thorns', 'Kansas City Current', 'Seattle Reign', 'San Diego Wave', 'Houston Dash'] }
  ];

  /* ---------- Teams ---------- */
  var TEAMS = {};
  LEAGUES.forEach(function (lg) {
    lg.teamIds = lg.teams.map(function (n) {
      var id = slug(n) + (lg.women ? '-w' : '');
      if (!TEAMS[id]) TEAMS[id] = { id: id, name: n, women: lg.women, leagues: [] };
      TEAMS[id].leagues.push(lg.id);
      return id;
    });
  });

  var STRONG = { 'real-madrid': .9, 'barcelona': .9, 'manchester-city': .92, 'arsenal': .88, 'liverpool': .85, 'bayern-munchen': .92, 'paris-saint-germain': .9, 'inter': .85, 'raja-casablanca': .7, 'wydad-ac': .72, 'as-far': .65, 'al-ahly': .85, 'pyramids': .7, 'lyon-w': .8, 'barcelona-w': .95, 'chelsea-w': .88, 'arsenal-w': .8, 'wolfsburg-w': .75, 'morocco-w': .72, 'nigeria-w': .75, 'as-far-w': .85, 'sporting-casablanca-w': .55, 'bayern-munchen-w': .82, 'gotham-fc-w': .8 };
  function strength(id) { return STRONG[id] != null ? STRONG[id] : 0.3 + (hash(id) % 1000) / 1800; }

  /* ---------- Players (sample squads) ---------- */
  var FN_M = ['Karim', 'Mohamed', 'Youssef', 'Achraf', 'Lucas', 'Marco', 'Jonas', 'Hakim', 'Sadio', 'Luis', 'Rafael', 'Victor', 'Ayoub', 'Omar', 'Pedro', 'Julian', 'Declan', 'Bruno', 'Antoine', 'Mateo'];
  var FN_W = ['Aitana', 'Alexia', 'Lauren', 'Sam', 'Ada', 'Ghizlane', 'Salma', 'Chloe', 'Lena', 'Sophia', 'Ewa', 'Mariona', 'Wendie', 'Fatima', 'Rosella', 'Naomi', 'Khadija', 'Alessia', 'Beth', 'Mary'];
  var LN = ['Benali', 'Haddad', 'Silva', 'Costa', 'Müller', 'Rossi', 'Martin', 'Diallo', 'Okafor', 'Garcia', 'Fernandez', 'Lopez', 'Bennani', 'Alaoui', 'Mensah', 'Johnson', 'Dubois', 'Romano', 'Keita', 'Idrissi', 'Tazi', 'Berrada', 'Nunez', 'Weber'];
  var _players = {};
  function playersOf(tid) {
    if (_players[tid]) return _players[tid];
    var r = rng(hash('p' + tid)), pool = TEAMS[tid].women ? FN_W : FN_M, out = [];
    for (var i = 0; i < 6; i++) out.push(pool[Math.floor(r() * pool.length)] + ' ' + LN[Math.floor(r() * LN.length)]);
    return (_players[tid] = out);
  }

  /* ---------- Fixtures ---------- */
  function roundRobin(ids) {
    var n = ids.length, arr = ids.slice(), rounds = [];
    for (var r = 0; r < n - 1; r++) {
      var pairs = [];
      for (var i = 0; i < n / 2; i++) { var a = arr[i], b = arr[n - 1 - i]; pairs.push(r % 2 ? [b, a] : [a, b]); }
      rounds.push(pairs);
      arr.splice(1, 0, arr.pop());
    }
    return rounds;
  }

  var DAY = 86400000, base = new Date(); base.setHours(0, 0, 0, 0); base = base.getTime();
  var SLOTS = [[13, 30], [15, 0], [17, 30], [19, 0], [20, 45], [21, 0], [16, 0], [18, 30]];
  var matches = [], byId = {};

  LEAGUES.forEach(function (lg, li) {
    var first = roundRobin(lg.teamIds);
    var second = first.map(function (p) { return p.map(function (x) { return [x[1], x[0]]; }); });
    var rounds = first.concat(second);
    var shift = (li % 3) - 1;
    rounds.forEach(function (pairs, ri) {
      pairs.forEach(function (pr, k) {
        var s = SLOTS[(k + li) % SLOTS.length];
        var ko = base + ((ri - 6) * 3 + shift) * DAY + (s[0] * 60 + s[1]) * 60000;
        var m = { id: lg.id + '-' + (ri + 1) + '-' + (k + 1), league: lg.id, round: ri + 1, home: pr[0], away: pr[1], ko: ko };
        simulate(m);
        matches.push(m); byId[m.id] = m;
      });
    });
  });
  matches.sort(function (a, b) { return a.ko - b.ko; });

  function simulate(m) {
    var r = rng(hash(m.id)), sh = strength(m.home), sa = strength(m.away);
    var lh = Math.max(.35, 1.3 + (sh - sa) * 1.4 + .2), la = Math.max(.25, 1.0 + (sa - sh) * 1.4);
    function pois(l) { var L = Math.exp(-l), k = 0, p = 1; do { k++; p *= r(); } while (p > L && k < 8); return k - 1; }
    var hg = pois(lh), ag = pois(la), goals = [];
    function scorer(tid) { var pl = playersOf(tid); return pl[Math.floor(Math.pow(r(), 1.8) * pl.length)]; }
    for (var i = 0; i < hg; i++) goals.push({ min: 1 + Math.floor(r() * 90), side: 'h', player: scorer(m.home) });
    for (var j = 0; j < ag; j++) goals.push({ min: 1 + Math.floor(r() * 90), side: 'a', player: scorer(m.away) });
    goals.sort(function (a, b) { return a.min - b.min; });
    m.goals = goals;
    var pos = Math.max(28, Math.min(72, Math.round(50 + (sh - sa) * 28 + (r() - .5) * 10)));
    m.stats = {
      poss: [pos, 100 - pos],
      shots: [Math.round(6 + r() * 10 + (sh - sa) * 5 + hg), Math.round(5 + r() * 9 + (sa - sh) * 5 + ag)],
      sot: [Math.max(hg, Math.round(2 + r() * 5)), Math.max(ag, Math.round(1 + r() * 5))],
      corners: [Math.round(2 + r() * 8), Math.round(1 + r() * 7)]
    };
  }

  /* ---------- Live state ---------- */
  function stateOf(m, now) {
    now = now || Date.now();
    var e = (now - m.ko) / 60000, st, min;
    if (e < 0) return { status: 'NS', minute: 0, hg: 0, ag: 0, goals: [] };
    if (e <= 47) { st = 'LIVE'; min = Math.max(1, Math.min(45, Math.ceil(e))); }
    else if (e <= 62) { st = 'HT'; min = 45; }
    else if (e <= 110) { st = 'LIVE'; min = Math.min(90, 45 + Math.ceil(e - 62)); }
    else { st = 'FT'; min = 90; }
    var shown = m.goals.filter(function (g) { return g.min <= min; });
    var hg = 0, ag = 0; shown.forEach(function (g) { if (g.side === 'h') hg++; else ag++; });
    return { status: st, minute: min, hg: hg, ag: ag, goals: shown };
  }

  /* ---------- Standings & scorers ---------- */
  function standings(lid) {
    var lg = LEAGUES.filter(function (l) { return l.id === lid; })[0], t = {};
    lg.teamIds.forEach(function (id) { t[id] = { team: id, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, gd: 0, pts: 0 }; });
    matches.forEach(function (m) {
      if (m.league !== lid) return;
      var s = stateOf(m); if (s.status !== 'FT') return;
      var h = t[m.home], a = t[m.away];
      h.p++; a.p++; h.gf += s.hg; h.ga += s.ag; a.gf += s.ag; a.ga += s.hg;
      if (s.hg > s.ag) { h.w++; a.l++; h.pts += 3; } else if (s.hg < s.ag) { a.w++; h.l++; a.pts += 3; } else { h.d++; a.d++; h.pts++; a.pts++; }
    });
    var rows = Object.keys(t).map(function (k) { t[k].gd = t[k].gf - t[k].ga; return t[k]; });
    rows.sort(function (x, y) { return y.pts - x.pts || y.gd - x.gd || y.gf - x.gf || (x.team < y.team ? -1 : 1); });
    return rows;
  }

  function scorers(lid) {
    var map = {};
    matches.forEach(function (m) {
      if (m.league !== lid) return;
      var s = stateOf(m); if (s.status !== 'FT') return;
      s.goals.forEach(function (g) {
        var tid = g.side === 'h' ? m.home : m.away, k = g.player + '|' + tid;
        map[k] = map[k] || { player: g.player, team: tid, goals: 0 }; map[k].goals++;
      });
    });
    return Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) { return b.goals - a.goals || (a.player < b.player ? -1 : 1); }).slice(0, 10);
  }

  window.MQ = { leagues: LEAGUES, teams: TEAMS, matches: matches, byId: byId, stateOf: stateOf, standings: standings, scorers: scorers, playersOf: playersOf, hash: hash };
})();
