# PROFE LARRY IA v2.7

**Nueva arquitectura recomendada:** Cloudflare Workers + D1. Consulta `cloudflare/README_CLOUDFLARE.md` para desplegar la API y la base persistente. `DEPLOY_GRATIS.md` resume los límites.

> Esta versión es una migración inicial: la revisión administrativa y la actualización programada de fuentes siguen pendientes. No afirma alta disponibilidad absoluta ni incluye una segunda réplica automática.

# PROFE LARRY IA — v2.6 Despliegue gratuito de prueba y failover

Aplicación educativa mobile-first, preparada para PWA/Capacitor Android, con tutor por IA, clases descargables, voz y texto, cuestionarios calificados al final, biblioteca privada y biblioteca general moderada.

## Funciones incluidas

- **Tutor IA** compatible con un endpoint tipo OpenAI Chat Completions: adapta la explicación al modo y nivel del estudiante.
- **Memoria de aprendizaje/RAG**: guarda automáticamente las respuestas del tutor en la biblioteca privada cuando hay sesión; recupera lecciones previas pertinentes y material general aprobado antes de responder.
- **Aprendizaje continuo de la aplicación**: registra eventos de aprendizaje, resultados de cuestionarios, nuevas lecciones y fuentes. El conocimiento recuperado mejora el contexto futuro. Esto NO reentrena ni modifica automáticamente los pesos del modelo externo.
- **Búsqueda web en cada pregunta escrita**: el servidor intenta consultar siempre los motores de búsqueda configurados para cada pregunta del tutor, y después entrega al modelo los resultados para redactar una respuesta con enlaces. Si no hay motor configurado o falla, informa que no pudo verificar en la web; nunca simula una búsqueda exitosa.
- **Búsqueda multiproveedor**: puede combinar Tavily, Serper y Brave Search en paralelo, eliminar enlaces duplicados y reunir hasta diez resultados. Se configuran solo los motores para los que el administrador tenga credenciales.
- **Fallback de modelos IA**: intenta Gemini primero y, si falla, usa el endpoint compatible con OpenAI configurado. No se conectan proveedores automáticamente ni se comparten claves; el administrador decide cuáles habilitar.
- **Currículo ampliado**: incluye doce áreas temáticas por materia (Matemáticas, Ciencias, Inglés, Español, Historia y Tecnología), como mapa de contenidos para abrir nuevas clases con el tutor web.
- **Cuestionarios adaptativos**: al iniciar una práctica online solicita 20 preguntas generadas por IA para el tema de la lección. Ajusta el nivel inicial/intermedio/avanzado usando los últimos resultados por materia. Si no hay internet o falla la generación, usa el banco de 20 preguntas descargado.
- **Actualización programada**: cada seis horas consulta los temas de `refresh_topics`. Los resultados se almacenan en `knowledge_sources` como `pending_review`; no se convierten automáticamente en conocimiento verificado.
- **Administración editorial**: se pueden añadir temas de actualización y revisar/aprobar/rechazar fuentes con `ADMIN_REVIEW_KEY`.
- **Biblioteca privada por usuario**: las rutas de lecciones y progreso exigen JWT y filtran por `user_id`.
- **Biblioteca general**: las aportaciones de usuarios y fuentes web quedan pendientes de revisión. Nunca se publican automáticamente como verificadas.
- **Cuestionarios**: se seleccionan respuestas, se califica el cuestionario al final y, si hay sesión, se guarda el resultado.
- **Voz y texto**: entrada por reconocimiento de voz del navegador cuando está disponible y lectura de respuestas mediante síntesis de voz. Depende del soporte del dispositivo/navegador y permisos.
- **Modo sin conexión**: las clases incluidas en el paquete siguen disponibles offline; tutor IA y búsquedas web necesitan internet. La sincronización de cola requiere sesión y conexión.
- **Android**: configuración Capacitor lista para generar proyecto nativo y compilar con Android Studio.

## Configuración

1. Requiere Node.js 20 o superior.
2. Ejecuta `npm install`.
3. Copia `.env.example` a `.env`.
4. Define `JWT_SECRET` con al menos 32 caracteres aleatorios y una clave distinta para `ADMIN_REVIEW_KEY`.
5. Para el modelo IA, configura `GEMINI_API_KEY` (Gemini 2.5 Flash tiene cuota gratuita sujeta a límites, región y condiciones) y, opcionalmente, el fallback `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`.
6. Para que cada pregunta escrita tenga búsqueda web, configura al menos uno de estos motores: `TAVILY_API_KEY`, `SERPER_API_KEY`, `BRAVE_SEARCH_API_KEY`. Puedes habilitar varios para combinar resultados. Sin ninguno, el servidor indicará que la búsqueda no pudo realizarse; no afirmará que verificó información online.
7. Todas las claves se guardan exclusivamente en el servidor. No las incluyas en el frontend ni en el APK. El tutor web necesita internet y un servidor desplegado con URL HTTPS accesible desde Android.
8. Ejecuta `npm start` y abre `http://localhost:3000`.

## Alta disponibilidad y cambio automático de servidor (v2.5)

La aplicación ahora intenta el servidor de origen y, si no responde o devuelve un error temporal de infraestructura (502/503/504 y equivalentes), prueba los servidores de respaldo configurados en `public/server-config.js`. Guarda cuál fue el último servidor que respondió y lo prioriza en las siguientes solicitudes. La comprobación de estado prueba todos los destinos antes de mostrar que el tutor está disponible.

**Configurar los respaldos:**

1. Despliega el mismo backend en dos o más servicios independientes y configura en todos las mismas variables y proveedores autorizados.
2. Configura un almacenamiento de datos compartido y persistente para producción. No uses el SQLite local de cada réplica como si fuera una base compartida: las cuentas y bibliotecas divergirían. La versión actual sigue usando SQLite y por eso el failover entre servidores es solo una capa de transporte hasta que migres a PostgreSQL administrado compartido.
3. Edita `public/server-config.js` y agrega las URL HTTPS reales, por ejemplo `https://api-principal.tudominio.com` y `https://api-respaldo.tudominio.com`. No pongas claves ni contraseñas ahí.
4. Configura `/healthz` como health-check en el proveedor. La ruta responde solo cuando el proceso está activo; valida además la base de datos con una comprobación de readiness antes de producción.
5. Publica de nuevo la app web/PWA y ejecuta `npx cap sync android` para incluir los cambios en el proyecto Android.

El cliente cambia de destino al detectar fallos de red/infraestructura, pero ningún programa puede garantizar que siempre exista un servidor accesible: pueden fallar simultáneamente la red, todos los proveedores o la base de datos. Para reducir ese riesgo se necesitan instancias en proveedores/regiones independientes, base de datos redundante, copias de seguridad probadas y monitorización. Render recomienda varias instancias, health checks, reintentos y copias probadas; su escalado y recursos redundantes tienen coste. <https://render.com/docs/uptime-best-practices>.

**Importante:** no se han creado cuentas, contratado servidores ni desplegado el proyecto. Las URL de respaldo quedan vacías hasta que el administrador configure servicios reales. Antes de producción hace falta migrar SQLite a PostgreSQL compartido y probar escrituras/sincronización con idempotencia para evitar duplicados durante un cambio de servidor.

## Endpoints principales

- Salud y estado: `GET /api/health`, `GET /api/knowledge/status`
- Cuenta: `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- Tutor: `POST /api/tutor` (búsqueda web en cada consulta escrita); generación adaptativa: `POST /api/quiz/generate`
- Memoria privada: `POST/GET /api/memory/lessons`, `GET /api/memory/lessons/:id`, `DELETE /api/memory/lessons/:id`, `POST /api/memory/search`, `GET /api/memory/progress`, `POST /api/memory/quiz-results`
- Biblioteca general: `POST /api/shared/submit`, `GET /api/shared/search`, `POST /api/shared/:id/review`
- Fuentes web: `GET /api/knowledge/sources`, `GET /api/knowledge/search?q=...`, `POST /api/knowledge/sources/:id/review`
- Actualización: `POST /api/knowledge/topics`, `POST /api/knowledge/refresh`
- Sincronización: `POST /api/sync`

Las rutas administrativas requieren `x-review-key: <ADMIN_REVIEW_KEY>`. Las rutas privadas requieren `Authorization: Bearer <token>`.

## Cómo funciona el aprendizaje continuo

1. El estudiante hace preguntas, completa actividades y cuestionarios.
2. La app registra las lecciones y resultados en su biblioteca privada.
3. Antes de una respuesta, recupera fragmentos relevantes de su memoria y de la biblioteca general aprobada.
4. Cada pregunta escrita intenta consultar los motores web configurados y el tutor sintetiza los resultados junto con la memoria relevante.
5. El servicio programado consulta temas educativos cada seis horas; los hallazgos quedan pendientes de revisión.
6. Un revisor verifica precisión, fecha, reputación de la fuente, derechos de uso y ausencia de datos personales antes de aprobar.

No se entrena un modelo externo con los datos de los estudiantes. Para entrenamiento real o fine-tuning se necesitaría un proceso separado, consentimiento válido, controles de privacidad, curación de datos y un proveedor que lo admita. La memoria/RAG es la vía implementada aquí.

## Android

Primera vez: `npx cap add android`. Después: `npx cap sync android` y `npx cap open android`. Para publicar se requiere compilar, firmar y probar el APK/AAB desde Android Studio o CI.

## Limitaciones y tareas antes de producción

- El proveedor de IA y al menos un motor web requieren claves propias; no se incluyen credenciales. Gemini gratuito tiene cuotas y no garantiza disponibilidad continua.
- Las actualizaciones automáticas solo funcionan mientras el servidor esté activo y haya cuota/API disponible. Las fuentes nuevas no se autoaprueban.
- La calidad de búsqueda depende de los motores habilitados, sus cuotas y la disponibilidad de internet. Deben evaluarse fuentes y respuestas antes de producción.
- El motor de memoria actual usa búsqueda léxica local, no embeddings/vector DB. Para gran escala: PostgreSQL + pgvector, RLS y búsqueda híbrida.
- La sincronización offline cubre la cola de registros que envíe el cliente; se debe probar con pérdida de conexión y conflictos en Android real.
- SQLite local de servidor es apropiado para prototipo/instancia única; para producción multiusuario usar PostgreSQL, HTTPS, límites de peticiones, copias de seguridad, monitorización y gestión de secretos.
- El reconocimiento y la síntesis de voz dependen del soporte del navegador y pueden requerir internet.
- No es un APK firmado ni una app desplegada en internet. Debe configurarse y probarse en el entorno de destino.


## Despliegue gratuito

Consulta `DEPLOY_GRATIS.md` y `render.yaml` para desplegar la API de prueba en Render Free y el frontend estático en Cloudflare Pages. Este modo no es de producción: Render Free duerme y su disco es efímero; SQLite no debe almacenar datos importantes. El failover requiere una segunda API real y compatible.
