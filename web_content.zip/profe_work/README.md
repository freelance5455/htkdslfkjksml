# PROFE LARRY IA — v2.2 Aprendizaje continuo y actualización web

Aplicación educativa mobile-first, preparada para PWA/Capacitor Android, con tutor por IA, clases descargables, voz y texto, cuestionarios calificados al final, biblioteca privada y biblioteca general moderada.

## Funciones incluidas

- **Tutor IA** compatible con un endpoint tipo OpenAI Chat Completions: adapta la explicación al modo y nivel del estudiante.
- **Memoria de aprendizaje/RAG**: guarda automáticamente las respuestas del tutor en la biblioteca privada cuando hay sesión; recupera lecciones previas pertinentes y material general aprobado antes de responder.
- **Aprendizaje continuo de la aplicación**: registra eventos de aprendizaje, resultados de cuestionarios, nuevas lecciones y fuentes. El conocimiento recuperado mejora el contexto futuro. Esto NO reentrena ni modifica automáticamente los pesos del modelo externo.
- **Actualización web**: para preguntas con señales de actualidad (por ejemplo, hoy, últimas noticias, precios o datos vigentes), el tutor consulta primero el modelo y después realiza búsqueda web si está configurada; sintetiza la respuesta con fuentes y enlaces.
- **Actualización programada**: cada seis horas consulta los temas de `refresh_topics`. Los resultados se almacenan en `knowledge_sources` como `pending_review`; no se convierten automáticamente en conocimiento verificado.
- **Administración editorial**: se pueden añadir temas de actualización y revisar/aprobar/rechazar fuentes con `ADMIN_REVIEW_KEY`.
- **Biblioteca privada por usuario**: las rutas de lecciones y progreso exigen JWT y filtran por `user_id`.
- **Biblioteca general**: las aportaciones de usuarios y fuentes web quedan pendientes de revisión. Nunca se publican automáticamente como verificadas.
- **Cuestionarios**: se seleccionan respuestas, se califica el cuestionario al final y, si hay sesión, se guarda el resultado.
- **Voz y texto**: entrada por reconocimiento de voz del navegador cuando está disponible y lectura de respuestas mediante síntesis de voz. Depende del soporte del dispositivo/navegador y permisos.
- **Modo sin conexión**: las clases incluidas en el paquete siguen disponibles offline; tutor IA y búsquedas web necesitan internet. La sincronización de cola requiere sesión y conexión.
- **Android**: configuración Capacitor lista para generar proyecto nativo y compilar con Android Studio.

## Configuración

1. Requiere Node.js 20 o superior.
2. Ejecuta `npm install`.
3. Copia `.env.example` a `.env`.
4. Define `JWT_SECRET` con al menos 32 caracteres aleatorios y una clave distinta para `ADMIN_REVIEW_KEY`.
5. Configura `AI_API_KEY`, `AI_BASE_URL` y `AI_MODEL` con credenciales de un proveedor compatible con Chat Completions.
6. Configura `TAVILY_API_KEY` para habilitar búsqueda web y actualización programada. Sin ella, no habrá consulta externa ni actualización web.
7. Ejecuta `npm start` y abre `http://localhost:3000`.

## Endpoints principales

- Salud y estado: `GET /api/health`, `GET /api/knowledge/status`
- Cuenta: `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- Tutor: `POST /api/tutor`
- Memoria privada: `POST/GET /api/memory/lessons`, `GET /api/memory/lessons/:id`, `DELETE /api/memory/lessons/:id`, `POST /api/memory/search`, `GET /api/memory/progress`, `POST /api/memory/quiz-results`
- Biblioteca general: `POST /api/shared/submit`, `GET /api/shared/search`, `POST /api/shared/:id/review`
- Fuentes web: `GET /api/knowledge/sources`, `GET /api/knowledge/search?q=...`, `POST /api/knowledge/sources/:id/review`
- Actualización: `POST /api/knowledge/topics`, `POST /api/knowledge/refresh`
- Sincronización: `POST /api/sync`

Las rutas administrativas requieren `x-review-key: <ADMIN_REVIEW_KEY>`. Las rutas privadas requieren `Authorization: Bearer <token>`.

## Cómo funciona el aprendizaje continuo

1. El estudiante hace preguntas, completa actividades y cuestionarios.
2. La app registra las lecciones y resultados en su biblioteca privada.
3. Antes de una respuesta, recupera fragmentos relevantes de su memoria y de la biblioteca general aprobada.
4. Si la pregunta requiere actualidad, consulta el modelo y después busca fuentes web.
5. El servicio programado consulta temas educativos cada seis horas; los hallazgos quedan pendientes de revisión.
6. Un revisor verifica precisión, fecha, reputación de la fuente, derechos de uso y ausencia de datos personales antes de aprobar.

No se entrena un modelo externo con los datos de los estudiantes. Para entrenamiento real o fine-tuning se necesitaría un proceso separado, consentimiento válido, controles de privacidad, curación de datos y un proveedor que lo admita. La memoria/RAG es la vía implementada aquí.

## Android

Primera vez: `npx cap add android`. Después: `npx cap sync android` y `npx cap open android`. Para publicar se requiere compilar, firmar y probar el APK/AAB desde Android Studio o CI.

## Limitaciones y tareas antes de producción

- El proveedor de IA y Tavily requieren claves propias; no se incluyen credenciales.
- Las actualizaciones automáticas solo funcionan mientras el servidor esté activo y haya cuota/API disponible. Las fuentes nuevas no se autoaprueban.
- El clasificador de actualidad usa reglas sencillas; se debe ampliar y evaluar para cada materia.
- El motor de memoria actual usa búsqueda léxica local, no embeddings/vector DB. Para gran escala: PostgreSQL + pgvector, RLS y búsqueda híbrida.
- La sincronización offline cubre la cola de registros que envíe el cliente; se debe probar con pérdida de conexión y conflictos en Android real.
- SQLite local de servidor es apropiado para prototipo/instancia única; para producción multiusuario usar PostgreSQL, HTTPS, límites de peticiones, copias de seguridad, monitorización y gestión de secretos.
- El reconocimiento y la síntesis de voz dependen del soporte del navegador y pueden requerir internet.
- No es un APK firmado ni una app desplegada en internet. Debe configurarse y probarse en el entorno de destino.
