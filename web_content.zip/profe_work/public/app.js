const $=s=>document.querySelector(s);
const screen=$("#screen");
let quizAnswers={}, quizMeta=null;
let state={mode:localStorage.getItem("larry_mode")||"adulto",level:localStorage.getItem("larry_level")||"normal",progress:JSON.parse(localStorage.getItem("larry_progress")||"{}"),selectedSubject:"matematicas",token:localStorage.getItem("larry_token")||"",user:JSON.parse(localStorage.getItem("larry_user")||"null")};
const esc=v=>String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");

const subjects=[
 ["matematicas","➗","Matemáticas"],["ciencias","🔬","Ciencias"],["ingles","🇬🇧","Inglés"],
 ["espanol","📖","Español"],["historia","🏛️","Historia"],["tecnologia","💻","Tecnología"]
];

function setNav(name){
 document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.nav===name));
}
function save(){localStorage.setItem("larry_mode",state.mode);localStorage.setItem("larry_level",state.level);localStorage.setItem("larry_progress",JSON.stringify(state.progress))}
function home(){
 setNav("inicio");
 screen.innerHTML=`
 <section class="hero"><div class="eyebrow">¡Hola, estudiante! 👋</div><h1>¿Qué vamos a aprender hoy?</h1><p>Tu aprendizaje comienza aquí. Aprende a tu ritmo con tu profesor inteligente.</p><button class="primary" data-action="tutor">HABLAR CON PROFE LARRY</button></section>
 <div class="section-title"><h2>Empieza aquí</h2></div>
 <div class="grid">
  <button class="card" data-action="clases"><div class="icon">📚</div><h3>Mis clases</h3><p>Aprende cualquier materia</p></button>
  <button class="card" data-action="quiz"><div class="icon">📝</div><h3>Cuestionarios</h3><p>Practica y evalúate</p></button>
  <button class="card" data-action="progreso"><div class="icon">📈</div><h3>Mi progreso</h3><p>Observa tus avances</p></button><button class="card" data-action="biblioteca"><div class="icon">🧠</div><h3>Mi biblioteca</h3><p>Lecciones guardadas</p></button>
  <button class="card" data-action="voz"><div class="icon">🎙️</div><h3>Aprender con voz</h3><p>Habla y escucha</p></button>
 </div>
 <div class="section-title"><h2>Acceso rápido</h2><small>Ver todo</small></div>
 <div class="subjects">${subjects.map(s=>`<button class="subject" data-subject="${s[0]}"><span>${s[1]}</span>${s[2]}</button>`).join("")}</div>`;
}
function classes(){
 setNav("clases");
 screen.innerHTML=`<h1 class="page-title">Mis clases 📚</h1><p class="muted">Elige una materia y aprende paso a paso.</p><div class="subjects panel">${subjects.map(s=>`<button class="subject" data-subject="${s[0]}"><span>${s[1]}</span>${s[2]}</button>`).join("")}</div>`;
}
function subject(key){
 state.selectedSubject=key; const s=OFFLINE_CONTENT[key]||{title:"Materia",lessons:[]};
 setNav("clases");
 screen.innerHTML=`<button class="primary" data-action="clases">← Volver</button><h1 class="page-title">${s.title}</h1><p class="muted">Contenido disponible incluso sin internet.</p>${s.lessons.map(l=>`<article class="panel lesson"><h2>${l.title}</h2><p>${l.text}</p><button class="primary" data-lesson="${l.id}">Aprender y practicar</button></article>`).join("")}`;
}
function lesson(key,id){
 const s=OFFLINE_CONTENT[key], l=s.lessons.find(x=>x.id===id); if(!l)return;
 // Guardado automático de la lección abierta; si no hay red, se encola para sincronizar.
 if(state.token){const payload={title:l.title,subject:s.title,body:l.text,source:"clase_descargada"};if(navigator.onLine){fetch('/api/memory/lessons',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${state.token}`},body:JSON.stringify(payload)}).catch(()=>queueLesson(payload));}else queueLesson(payload);}
 quizAnswers={};quizMeta={key,id,title:l.title,total:l.quiz.length};
 screen.innerHTML=`<button class="primary" data-subject="${key}">← ${s.title}</button><article class="panel lesson"><h2>${l.title}</h2><p>${l.text}</p>${l.quiz.map((q,qi)=>`<div class="quiz-q">${qi+1}. ${q[0]}</div>${q[1].map((a,ai)=>`<button class="answer" data-ans="${ai}" data-q="${qi}">${a}</button>`).join("")}`).join("")}<button class="primary" data-action="finishQuiz">Calificar cuestionario</button><div id="result"></div></article>`;
}
function tutor(){
 setNav("tutor");
 screen.innerHTML=`<h1 class="page-title">Profe Larry 🧑‍🏫</h1><p class="muted">Pregúntame lo que quieras. Si no hay internet, te ayudaré con lo que esté disponible en el dispositivo.</p>
 <div class="panel"><strong>¿Cómo quieres que te explique?</strong><div class="select-row" style="margin-top:10px">${[["facil","Muy fácil"],["normal","Normal"],["profundo","Profundamente"],["experto","Nivel experto"]].map(x=>`<button class="choice ${state.level===x[0]?"selected":""}" data-level="${x[0]}"><strong>${x[1]}</strong><small>Adaptaré la explicación</small></button>`).join("")}</div></div>
 <div class="panel chat" id="chat"><div class="msg ai">¡Hola! Soy Profe Larry. 👋<br>Cuéntame qué quieres aprender.</div></div>
 <div class="row" style="gap:8px;margin:10px 0"><button class="choice" type="button" data-action="voiceInput">🎙️ Hablar</button><button class="choice" type="button" data-action="voiceStop">⏹ Detener voz</button></div>
 <form class="composer" id="composer"><input id="question" placeholder="Escribe tu pregunta…" autocomplete="off"><button>➤</button></form><p class="muted" id="knowledgeStatus">Comprobando actualización de contenidos…</p>`;
 fetch('/api/knowledge/status').then(r=>r.json()).then(d=>{const el=$('#knowledgeStatus');if(el)el.textContent=d.webSearchConfigured?`Búsqueda web disponible · actualización automática cada ${d.autoRefreshHours} h · ${d.verifiedSources} fuentes verificadas`:'Tutor conectado según configuración · búsqueda web pendiente de configurar';}).catch(()=>{});
}
function progress(){
 setNav("progreso");
 const vals=Object.values(state.progress), done=vals.length, total=subjects.length, pct=Math.min(100,Math.round(done/total*100));
 screen.innerHTML=`<h1 class="page-title">Mi progreso 📈</h1><p class="muted">Cada paso cuenta. Sigue aprendiendo.</p><div class="panel"><strong>Materias iniciadas</strong><h2>${done} de ${total}</h2><div class="progressbar"><i style="width:${pct}%"></i></div><p class="muted">${pct}% de avance general</p></div><div class="panel"><strong>Tu forma de aprender</strong><p>Modo: <b>${state.mode}</b><br>Nivel de explicación: <b>${state.level}</b></p><button class="primary" data-action="perfil">Cambiar preferencias</button></div>`;
}
function profile(){
 setNav("perfil");
 screen.innerHTML=`<h1 class="page-title">Mi perfil 🙂</h1><p class="muted">Personaliza cómo te enseña Profe Larry.</p><div class="panel"><strong>¿Quién está aprendiendo?</strong><div class="select-row" style="margin-top:10px">${[["nino","🧒 Niño"],["joven","🧑 Joven"],["adulto","🧑‍💼 Adulto"]].map(x=>`<button class="choice ${state.mode===x[0]?"selected":""}" data-mode="${x[0]}"><strong>${x[1]}</strong><small>Adaptaré ejemplos y lenguaje</small></button>`).join("")}</div></div><div class="panel"><strong>Mi cuenta y memoria privada</strong><p class="muted">${state.user?`Sesión iniciada como ${esc(state.user.email)}. Tus lecciones se guardan automáticamente.`:"Crea una cuenta o inicia sesión para guardar tus lecciones."}</p>${state.user?'<button class="primary" data-action="biblioteca">Abrir mi biblioteca</button><button class="choice" data-action="logout">Cerrar sesión</button>':`<form id="accountForm"><input name="name" placeholder="Tu nombre"><input name="email" type="email" placeholder="Correo electrónico" required><input name="password" type="password" placeholder="Contraseña (mínimo 10 caracteres)" minlength="10" required><button class="primary" type="button" data-account="register">Crear cuenta</button><button class="choice" type="button" data-account="login">Iniciar sesión</button><p id="accountMsg" class="muted"></p></form>`}</div><div class="panel"><strong>Instalación</strong><p class="muted">La app está preparada como PWA/Capacitor para Android. El contenido básico puede consultarse sin internet.</p></div>`;
}
async function ask(q){
 const chat=$("#chat"); chat.insertAdjacentHTML("beforeend",`<div class="msg me">${esc(q)}</div>`);
 try{
  const r=await fetch("/api/tutor",{method:"POST",body:JSON.stringify({message:q,level:state.level,mode:state.mode}),headers:{"Content-Type":"application/json",...(state.token?{Authorization:`Bearer ${state.token}`}:{})}});
  const d=await r.json(); chat.insertAdjacentHTML("beforeend",`<div class="msg ai">${esc(d.answer||d.error||"No pude responder.").replace(/\n/g,"<br>")}${d.savedLessonId?"<br><small>✓ Lección guardada en tu biblioteca privada</small>":""}</div>`); if(d.answer&&window.speechSynthesis){const utterance=new SpeechSynthesisUtterance(d.answer);utterance.lang="es-CO";window.speechSynthesis.speak(utterance);}
 }catch(e){chat.insertAdjacentHTML("beforeend",`<div class="msg ai">Ahora mismo no tengo conexión. Puedes seguir con las clases descargadas y los cuestionarios.</div>`)}
 chat.scrollIntoView({behavior:"smooth",block:"end"});
}
document.addEventListener("click",e=>{
 const nav=e.target.closest("[data-nav]"); if(nav){const n=nav.dataset.nav; if(n==="inicio")home();if(n==="clases")classes();if(n==="tutor")tutor();if(n==="progreso")progress();if(n==="perfil")profile();return}
 const a=e.target.closest("[data-action]"); if(a){const x=a.dataset.action;if(x==="tutor")tutor();if(x==="clases")classes();if(x==="quiz")subject(state.selectedSubject);if(x==="progreso")progress();if(x==="perfil")profile();if(x==="voz")tutor();if(x==="voiceInput"){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){alert("El reconocimiento de voz no está disponible en este navegador. Puedes escribir tu pregunta.");return;}const rec=new SR();rec.lang="es-CO";rec.onresult=ev=>{const q=ev.results[0][0].transcript;const input=$("#question");if(input){input.value=q;ask(q);}};rec.start();}if(x==="voiceStop"){if(window.speechSynthesis)window.speechSynthesis.cancel();}if(x==="finishQuiz"){if(!quizMeta)return;const l=OFFLINE_CONTENT[quizMeta.key].lessons.find(x=>x.id===quizMeta.id);const answered=Object.keys(quizAnswers).length;if(answered<quizMeta.total){$("#result").textContent=`Responde las ${quizMeta.total} preguntas antes de calificar.`;return;}let score=0;l.quiz.forEach((q,i)=>{if(quizAnswers[i]===q[2])score++;document.querySelectorAll(`[data-q="${i}"]`).forEach(b=>{b.disabled=true;if(Number(b.dataset.ans)===q[2])b.classList.add("correct");else if(Number(b.dataset.ans)===quizAnswers[i])b.classList.add("wrong");});});$("#result").textContent=`Resultado final: ${score} de ${quizMeta.total} (${Math.round(score/quizMeta.total*100)}%).`;if(state.token){const payload={subject:quizMeta.key,quiz_title:quizMeta.title,score,total:quizMeta.total};if(navigator.onLine)fetch('/api/memory/quiz-results',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${state.token}`},body:JSON.stringify(payload)}).catch(()=>{});else{const q=JSON.parse(localStorage.getItem('larry_quiz_queue')||'[]');q.push(payload);localStorage.setItem('larry_quiz_queue',JSON.stringify(q));}}}if(x==="biblioteca")library();if(x==="logout"){state.token="";state.user=null;localStorage.removeItem("larry_token");localStorage.removeItem("larry_user");profile()}return}
 const sub=e.target.closest("[data-subject]"); if(sub){subject(sub.dataset.subject);state.progress[sub.dataset.subject]=true;save();return}
 const lev=e.target.closest("[data-level]"); if(lev){state.level=lev.dataset.level;save();tutor();return}
 const mode=e.target.closest("[data-mode]"); if(mode){state.mode=mode.dataset.mode;save();profile();return}
 const lessonBtn=e.target.closest("[data-lesson]"); if(lessonBtn){lesson(state.selectedSubject,lessonBtn.dataset.lesson);return}
 const ans=e.target.closest("[data-ans]"); if(ans){quizAnswers[ans.dataset.q]=Number(ans.dataset.ans);document.querySelectorAll(`[data-q="${ans.dataset.q}"]`).forEach(b=>b.classList.toggle("selected",b===ans));return}

});

document.addEventListener("click",async e=>{const b=e.target.closest("[data-account]");if(!b)return;const f=$("#accountForm"),msg=$("#accountMsg"),fd=new FormData(f);try{const r=await fetch(`/api/auth/${b.dataset.account}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:fd.get("name"),email:fd.get("email"),password:fd.get("password")})});const d=await r.json();if(!r.ok)throw Error(d.error||"No se pudo acceder.");state.token=d.token;state.user=d.user;localStorage.setItem("larry_token",d.token);localStorage.setItem("larry_user",JSON.stringify(d.user));profile();}catch(err){if(msg)msg.textContent=err.message;}});
async function library(){setNav("perfil");screen.innerHTML='<h1 class="page-title">Mi biblioteca 🧠</h1><p class="muted">Tu espacio privado de aprendizaje.</p><div class="panel" id="libraryItems">Cargando lecciones…</div><button class="primary" data-action="perfil">Volver a mi perfil</button>';if(!state.token){$("#libraryItems").textContent="Inicia sesión para consultar tu biblioteca privada.";return;}try{const r=await fetch("/api/memory/lessons",{headers:{Authorization:`Bearer ${state.token}`}});const d=await r.json();$("#libraryItems").innerHTML=d.lessons?.length?d.lessons.map(l=>`<article class="lesson"><h3>${esc(l.title)}</h3><p class="muted">${esc(l.subject)} · ${esc(l.created_at)}</p><button class="choice" data-open-lesson="${esc(l.id)}">Leer lección</button></article>`).join(""):'Aún no hay lecciones guardadas. Conversa con Profe Larry para empezar.';}catch{$("#libraryItems").textContent="No se pudo cargar la biblioteca.";}}
document.addEventListener("click",async e=>{const b=e.target.closest("[data-open-lesson]");if(!b)return;const box=$("#libraryItems");try{const r=await fetch(`/api/memory/lessons/${encodeURIComponent(b.dataset.openLesson)}`,{headers:{Authorization:`Bearer ${state.token}`}});const d=await r.json();if(!r.ok)throw Error(d.error);box.innerHTML=`<button class="choice" data-action="biblioteca">← Biblioteca</button><h2>${esc(d.lesson.title)}</h2><p>${esc(d.lesson.body).replace(/\n/g,"<br>")}</p>`;}catch(err){box.textContent=err.message;}});

document.addEventListener("submit",e=>{if(e.target.id==="composer"){e.preventDefault();const i=$("#question");const q=i.value.trim();if(q){i.value="";ask(q)}}});
function online(){const el=$("#onlineState");el.innerHTML=navigator.onLine?'<i></i> Con internet':'<i style="background:#f0ad4e"></i> Sin internet · modo aprendizaje';}
window.addEventListener("online",()=>{online();syncPending();});window.addEventListener("offline",online);
function queueLesson(payload){const q=JSON.parse(localStorage.getItem('larry_sync_queue')||'[]');q.push({id:(crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random()}`),type:'lesson',payload});localStorage.setItem('larry_sync_queue',JSON.stringify(q));}
async function syncPending(){if(!state.token)return;const items=JSON.parse(localStorage.getItem("larry_sync_queue")||"[]");if(!items.length)return;try{const r=await fetch('/api/sync',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${state.token}`},body:JSON.stringify({items})});if(r.ok){localStorage.removeItem('larry_sync_queue');}const quizzes=JSON.parse(localStorage.getItem('larry_quiz_queue')||'[]');for(const quiz of quizzes){const qr=await fetch('/api/memory/quiz-results',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${state.token}`},body:JSON.stringify(quiz)});if(!qr.ok)break;}if(quizzes.length)localStorage.removeItem('larry_quiz_queue');}catch(e){}}
window.addEventListener('online',syncPending);if(navigator.onLine)syncPending();
home();online();

if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
