/* PROFE LARRY IA v2.7: la API se sirve desde el mismo Worker que el frontend.
   No agregues aquí claves privadas. Solo añade una URL secundaria después de
   desplegar y probar una segunda instancia independiente con datos replicados. */
window.PROFE_API_SERVERS = [];
