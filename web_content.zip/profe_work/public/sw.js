const CACHE="profe-larry-v2-4";
const ASSETS=["/","/index.html","/styles.css","/app.js","/offline.js","/manifest.webmanifest","/icon.svg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener("fetch",e=>{
 const u=new URL(e.request.url);
 if(u.origin!==location.origin)return;
 if(u.pathname.startsWith("/api/")){e.respondWith(fetch(e.request).catch(()=>new Response(JSON.stringify({error:"Sin conexión. El tutor y las búsquedas web requieren internet; usa las clases descargadas."}),{status:503,headers:{"Content-Type":"application/json"}})));return;}
 if(e.request.method!=="GET")return;
 e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}return r;}).catch(()=>caches.match("/index.html"))));
});
