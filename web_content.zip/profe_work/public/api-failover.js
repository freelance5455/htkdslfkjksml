/* Failover cliente: mismo origen primero, luego servidores HTTPS configurados. */
(() => {
  const nativeFetch = window.fetch.bind(window);
  const KEY = "profe_larry_active_api";
  const configured = Array.isArray(window.PROFE_API_SERVERS) ? window.PROFE_API_SERVERS : [];
  const normalize = value => String(value || "").trim().replace(/\/$/, "");
  const servers = [...new Set(["", ...configured.map(normalize).filter(Boolean)])];
  let active = Math.max(0, Math.min(servers.length - 1, Number(localStorage.getItem(KEY) || 0)));
  let lastHealthyAt = 0;

  function apiPath(input) {
    const raw = typeof input === "string" ? input : (input && input.url) || "";
    try {
      const u = new URL(raw, location.href);
      return u.origin === location.origin && u.pathname.startsWith("/api/") ? u.pathname + u.search : null;
    } catch { return null; }
  }
  function remember(index) {
    active = index;
    localStorage.setItem(KEY, String(index));
    lastHealthyAt = Date.now();
  }
  function makeUrl(base, path) { return base ? base + path : path; }

  window.fetch = async (input, init) => {
    const path = apiPath(input);
    if (!path || servers.length === 1 && !servers[0]) return nativeFetch(input, init);
    const order = servers.map((_, i) => i).sort((a, b) => (a === active ? -1 : b === active ? 1 : a - b));
    let lastError;
    for (const index of order) {
      const base = servers[index];
      try {
        const request = input instanceof Request ? new Request(makeUrl(base, path), input) : makeUrl(base, path);
        const response = await nativeFetch(request, init);
        if ([404, 502, 503, 504, 520, 521, 522, 523, 524].includes(response.status)) {
          lastError = new Error(`Servidor ${index + 1} no disponible (${response.status})`);
          continue;
        }
        remember(index);
        return response;
      } catch (error) {
        lastError = error;
      }
    }
    if (lastError) throw lastError;
    return nativeFetch(input, init);
  };

  window.ProfeServerFailover = {
    getServers: () => servers.map((url, index) => ({ index, url: url || "Servidor de origen" })),
    getActiveIndex: () => active,
    getLastHealthyAt: () => lastHealthyAt,
    async check() {
      const order = servers.map((_, i) => i).sort((a, b) => (a === active ? -1 : b === active ? 1 : a - b));
      for (const index of order) {
        try {
          const response = await nativeFetch(makeUrl(servers[index], "/api/health"), { cache: "no-store", signal: AbortSignal.timeout ? AbortSignal.timeout(5000) : undefined });
          if (response.ok) { const data = await response.json(); remember(index); return { ok: true, index, data }; }
        } catch (_) {}
      }
      return { ok: false };
    }
  };
})();
