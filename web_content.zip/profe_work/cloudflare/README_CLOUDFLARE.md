# PROFE LARRY IA 2.7 — Cloudflare Workers + D1

Esta variante elimina el servicio Node/Render que se dormía y sustituye SQLite local efímero por Cloudflare D1 persistente. El Worker sirve también los archivos de `public/`, por lo que la API queda en el mismo origen.

## Qué cambia
- API en Cloudflare Workers: no necesita una instancia Node encendida ni despierta después de inactividad.
- Datos de cuentas, biblioteca privada, resultados y cola de sincronización en D1.
- Hash de contraseñas PBKDF2 y sesiones JWT firmadas con un secreto estable.
- El frontend sigue usando `/api/...` y mantiene clases descargadas para el modo sin conexión.
- IA Gemini y búsqueda web son opcionales y se configuran como secretos del Worker.

## Instalación gratuita
1. Crea una cuenta de Cloudflare con ayuda de un adulto responsable si la plataforma solicita datos de pago o autorización. No actives planes de pago.
2. Instala Node.js LTS en tu computador y, desde esta carpeta `cloudflare`, ejecuta `npx wrangler login`.
3. Crea la base: `npx wrangler d1 create profe-larry-db`.
4. Copia el `database_id` que devuelve el comando y reemplaza `REEMPLAZA_CON_EL_ID_DE_D1` en `wrangler.toml`.
5. Crea las tablas: `npx wrangler d1 migrations apply profe-larry-db --remote`.
6. Configura secretos (no los escribas en archivos ni los compartas):
   - `npx wrangler secret put JWT_SECRET` (usa un valor aleatorio largo, mínimo 32 caracteres).
   - `npx wrangler secret put GEMINI_API_KEY` (opcional; necesaria para el tutor IA y cuestionarios generados).
   - `npx wrangler secret put TAVILY_API_KEY` o `SERPER_API_KEY` o `BRAVE_SEARCH_API_KEY` (al menos uno para búsqueda web).
   - `npx wrangler secret put ADMIN_REVIEW_KEY` (reservado para futuras funciones de revisión).
7. Despliega: `npx wrangler deploy`.
8. Abre la URL `*.workers.dev` que indique Wrangler y comprueba `/healthz` y `/api/health`.

## Límites del nivel gratuito (pueden cambiar)
- Workers Free: hasta 100.000 solicitudes al día y 10 ms de CPU por solicitud.
- D1 Free: hasta 500 MB por base, 5 millones de filas leídas/día, 100.000 filas escritas/día y hasta 5 GB sumados por cuenta. Si se supera un límite diario, las consultas pueden fallar hasta el siguiente periodo.
- Los servicios externos de IA y búsqueda tienen sus propias cuotas y pueden limitarse o cambiar. La app no puede garantizar que siempre haya IA o internet.
- Workers no se duerme como el servicio gratuito de Render, pero ningún servicio gratuito garantiza disponibilidad absoluta ni SLA.

## Importante: respaldo y recuperación
Esta versión elimina el servidor dormido y la base efímera. **No configura por sí sola un segundo proveedor ni replica datos a otra base.** El failover de cliente solo es seguro cuando exista una segunda API independiente, compatible y con datos sincronizados. No se inventan direcciones de respaldo ni se envían cuentas a una base vacía. D1 ofrece recuperación temporal según el plan; configura y prueba restauraciones periódicamente.

## Alcance y pruebas
El Worker implementa registro/inicio de sesión, perfil, biblioteca privada, progreso, resultados de cuestionarios, sincronización de lecciones, búsqueda compartida, búsqueda web, tutor y generación de cuestionarios. La revisión administrativa de biblioteca compartida y la actualización programada de fuentes no se migraron en esta primera versión; no se deben presentar como activas. Las rutas de búsqueda de memoria avanzada pueden requerir completar la migración antes de activar esos botones.

Antes de usar con estudiantes, prueba registro, cierre/inicio de sesión, privacidad entre dos cuentas distintas, biblioteca, resultados, modo avión y sincronización. No subas bases SQLite antiguas ni credenciales al repositorio. Para importar datos de v2.6 hace falta una migración explícita y verificada; no sobrescribas la base antigua.
