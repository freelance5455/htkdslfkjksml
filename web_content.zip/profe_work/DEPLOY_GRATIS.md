# Despliegue gratuito recomendado — v2.7

La arquitectura recomendada ya no usa Render Free ni SQLite en disco efímero. Usa **Cloudflare Workers + D1** para alojar API, archivos estáticos y datos persistentes. Sigue la guía paso a paso en `cloudflare/README_CLOUDFLARE.md`.

## Límites que debes conocer
- Workers Free: 100.000 solicitudes/día y 10 ms de CPU por solicitud.
- D1 Free: 500 MB por base; cuotas diarias de lecturas y escrituras. Si se exceden, las consultas pueden quedar temporalmente limitadas.
- No hay garantía de disponibilidad absoluta en el nivel gratuito.
- El backend alternativo no se configura automáticamente: para failover real se necesita una segunda API independiente con datos sincronizados.

No se requiere contratar un plan para seguir la guía gratuita. Si una pantalla solicita añadir tarjeta, habilitar facturación o pagar, detente y pide ayuda a un adulto responsable; no actives cargos.
