@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo =====================================
echo       MyVault - APK Vorbereitung
echo =====================================
echo.
echo Schritt 1/2: Abhaengigkeiten installieren ...
call npm install
if errorlevel 1 (
  echo.
  echo FEHLER: npm install fehlgeschlagen. Pruefe Internetverbindung und Node.js.
  pause
  exit /b 1
)
echo.
echo Schritt 2/2: Web-App bauen ...
call npm run build
if errorlevel 1 (
  echo.
  echo FEHLER: Build fehlgeschlagen.
  pause
  exit /b 1
)
echo.
echo Fertig! Der fertige Web-App-Inhalt liegt im Ordner dist.
echo Zippe den INHALT von dist, nicht den dist-Ordner selbst, fuer einen HTML-zu-APK-Konverter.
pause
