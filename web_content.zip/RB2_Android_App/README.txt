RB2 ANDROID APP - STARTER PROJECT

FILES
- index.html: app pages and structure
- style.css: blue/white mobile interface
- script.js: navigation, booking, local orders, dashboard, payment references, WhatsApp contact

IMPORTANT LIMITATIONS
1. This starter version stores bookings and profile in the app's local browser storage on that device.
2. It does NOT send bookings to the RB2 business automatically and does NOT synchronize customers' data across phones.
3. Customer-facing app dashboards show only data saved on that customer's device. They are not an admin dashboard.
4. Payment status is not verified automatically. A payment reference is only a customer-submitted reference.
5. Add your WhatsApp number in script.js: const WHATSAPP_NUMBER = "91XXXXXXXXXX"; Use country code and digits only.
6. Change service descriptions, logo, colors and contact details before launch.
7. Google Fonts is optional; the app uses fallback fonts when offline.

TEST ON A PHONE
- Extract this ZIP.
- Open index.html in a browser or HTML editor preview.
- Test booking, orders, payments, profile and navigation.
- To package as APK, use a reputable HTML-to-APK/WebView builder that supports importing a ZIP or local HTML project. Builder menus and free limits vary.
- Select index.html as the start page, set app name RB2, package ID such as com.rb2.support, and choose an app icon.
- Build a debug/test APK, install it, and test on another Android device.

SECURITY / PRODUCTION
Do not put private API keys or payment secrets in JavaScript. Before taking real customer orders at scale, connect a secure shared backend and publish a privacy policy. Do not collect UPI PINs, card numbers or passwords.
