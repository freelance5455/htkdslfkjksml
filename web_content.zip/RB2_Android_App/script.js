/* RB2 starter app. Customer data is stored locally in this browser/device. */
const WHATSAPP_NUMBER = ""; // Add RB2 WhatsApp number with country code, digits only, e.g. 919876543210
const SERVICES = [
  {name:"Product Listing Management",icon:"▤",desc:"Create, organize and update product listings for online stores."},
  {name:"Product Description Writing",icon:"✎",desc:"Clear, helpful product descriptions that explain product benefits."},
  {name:"Product Image Editing",icon:"▧",desc:"Improve product photos with editing, resizing and optimization."},
  {name:"Catalog Management",icon:"▦",desc:"Keep product catalogs organized, consistent and up to date."},
  {name:"Inventory Support",icon:"▣",desc:"Assist with stock records and inventory updates."},
  {name:"Online Store Maintenance",icon:"⚙",desc:"Routine store content checks and maintenance support."}
];
const $ = s => document.querySelector(s);
const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
let orders = read("rb2_orders", []);
let profile = read("rb2_profile", {name:"",phone:"",email:""});
function escapeHTML(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600);}
function serviceCard(s){return `<article class="service-card"><div class="service-icon">${s.icon}</div><b>${escapeHTML(s.name)}</b><p>${escapeHTML(s.desc)}</p></article>`;}
function renderServices(){
  $("#homeServices").innerHTML=SERVICES.slice(0,4).map(serviceCard).join("");
  $("#allServices").innerHTML=SERVICES.map((s,i)=>`<article class="service-row"><div class="service-icon">${s.icon}</div><div><b>${escapeHTML(s.name)}</b><p>${escapeHTML(s.desc)}</p></div><button class="small-btn" data-book="${i}">Book</button></article>`).join("");
  $("#serviceSelect").innerHTML='<option value="">Choose a service</option>'+SERVICES.map(s=>`<option>${escapeHTML(s.name)}</option>`).join("");
}
function go(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("selected",b.dataset.go===page));
  if(page==="orders")renderOrders(); if(page==="dashboard")renderDashboard(); if(page==="payments")renderPayments();
  window.scrollTo({top:0,behavior:"smooth"});
}
document.addEventListener("click",e=>{
  const nav=e.target.closest("[data-go]"); if(nav){go(nav.dataset.go);return;}
  const book=e.target.closest("[data-book]"); if(book){$("#serviceSelect").value=SERVICES[Number(book.dataset.book)].name;go("booking");}
});
function makeWhatsApp(text){
  if(!WHATSAPP_NUMBER){toast("Add your RB2 WhatsApp number in script.js first.");return;}
  window.open("https://wa.me/"+WHATSAPP_NUMBER+"?text="+encodeURIComponent(text),"_blank");
}
$("#bookingForm").addEventListener("submit",e=>{
  e.preventDefault(); const f=new FormData(e.currentTarget);
  const item={id:"RB2-"+Date.now().toString().slice(-7),created:new Date().toISOString(),name:f.get("name").trim(),phone:f.get("phone").trim(),email:f.get("email").trim(),store:f.get("store").trim(),service:f.get("service"),details:f.get("details").trim(),contact:f.get("contact"),status:"Request received",payment:"Pending",paymentRef:""};
  if(!/^[0-9+()\-\s]{7,18}$/.test(item.phone)){toast("Please enter a valid phone number.");return;}
  orders.unshift(item);save("rb2_orders",orders);
  if(!profile.name){profile={name:item.name,phone:item.phone,email:item.email};save("rb2_profile",profile);fillProfile();}
  e.currentTarget.reset();renderDashboard();toast("Booking request saved on this device.");
  const message=`Hello RB2, I submitted a service request.%0ARequest: ${item.id}%0AName: ${item.name}%0AService: ${item.service}%0AStore: ${item.store}%0ADetails: ${item.details}`;
  if(WHATSAPP_NUMBER)makeWhatsApp(decodeURIComponent(message));
  go("orders");
});
function orderHTML(o){
 return `<article class="order-card"><div class="order-head"><div><b>${escapeHTML(o.service)}</b><div class="order-id">${escapeHTML(o.id)} • ${new Date(o.created).toLocaleDateString()}</div></div><span class="status ${o.payment==="Paid"?"paid":o.status==="In progress"?"progress":""}">${escapeHTML(o.status)}</span></div><p>${escapeHTML(o.details||"No extra details provided.")}</p><p>Payment: <b>${escapeHTML(o.payment)}</b></p><div class="order-actions"><button class="outline-btn" data-contact="${escapeHTML(o.id)}">Contact RB2</button><button class="outline-btn" data-pay="${escapeHTML(o.id)}">Update payment reference</button></div></article>`;
}
function renderOrders(){$("#ordersList").innerHTML=orders.length?orders.map(orderHTML).join(""):'<div class="empty">No booking requests yet.<br><br>Choose a service and submit your first request.</div>';}
function renderDashboard(){
 $("#totalCount").textContent=orders.length;$("#progressCount").textContent=orders.filter(o=>o.status==="In progress").length;
 $("#paidCount").textContent=orders.filter(o=>o.payment==="Paid").length;$("#pendingCount").textContent=orders.filter(o=>o.payment!=="Paid").length;
 $("#recentOrders").innerHTML=orders.length?orders.slice(0,3).map(o=>`<p><b>${escapeHTML(o.service)}</b><br><span class="muted">${escapeHTML(o.id)} • ${escapeHTML(o.status)}</span></p>`).join(""):'<p class="muted">No requests to display yet.</p>';
}
function renderPayments(){
 $("#paymentsList").innerHTML=orders.length?orders.map(o=>`<article class="order-card"><div class="order-head"><div><b>${escapeHTML(o.service)}</b><div class="order-id">${escapeHTML(o.id)}</div></div><span class="status ${o.payment==="Paid"?"paid":""}">${escapeHTML(o.payment)}</span></div><p>Reference: ${escapeHTML(o.paymentRef||"Not provided")}</p><div class="order-actions"><button class="outline-btn" data-pay="${escapeHTML(o.id)}">Add payment reference</button></div></article>`).join(""):'<div class="empty">No payment records yet. Payment information appears after you book a service.</div>';
}
document.addEventListener("click",e=>{
 const contact=e.target.closest("[data-contact]");if(contact){const o=orders.find(x=>x.id===contact.dataset.contact);if(o)makeWhatsApp(`Hello RB2, I need an update on request ${o.id} for ${o.service}.`);}
 const pay=e.target.closest("[data-pay]");if(pay){const o=orders.find(x=>x.id===pay.dataset.pay);if(!o)return;const ref=prompt("Enter your payment reference / UTR (do not enter card or UPI PIN):",o.paymentRef||"");if(ref===null)return;o.paymentRef=ref.trim();save("rb2_orders",orders);renderPayments();renderOrders();toast("Payment reference saved. RB2 must verify payment.");}
});
function fillProfile(){const f=$("#profileForm");f.elements.name.value=profile.name||"";f.elements.phone.value=profile.phone||"";f.elements.email.value=profile.email||"";}
$("#profileForm").addEventListener("submit",e=>{e.preventDefault();const f=new FormData(e.currentTarget);profile={name:f.get("name").trim(),phone:f.get("phone").trim(),email:f.get("email").trim()};save("rb2_profile",profile);toast("Profile saved on this device.");});
$("#clearData").addEventListener("click",()=>{if(confirm("Delete all RB2 bookings and profile saved on this device? This cannot be undone.")){localStorage.removeItem("rb2_orders");localStorage.removeItem("rb2_profile");orders=[];profile={name:"",phone:"",email:""};fillProfile();renderOrders();renderDashboard();renderPayments();toast("Device data cleared.");}});
$("#helpBtn").addEventListener("click",()=>makeWhatsApp("Hello RB2, I need help with your services."));
renderServices();fillProfile();renderDashboard();
