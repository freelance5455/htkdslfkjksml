import test from 'node:test';
import assert from 'node:assert/strict';
import { calcStatus, normalizeOsCode, newRecord, toTSV, kpis, maisAntigas, applyChange, camposFaltando, STATUS } from '../js/osmodel.js';

const hoje = '2026-10-23';

test('status: mesma lógica da fórmula da planilha', () => {
  assert.equal(calcStatus({ cx: '❌', dataAbertura: '2026-01-01' }, hoje), STATUS.CANCELADO);
  assert.equal(calcStatus({ cx: '✓', dataAbertura: '2026-01-01' }, hoje), STATUS.CONCLUIDO);
  assert.equal(calcStatus({ cx: '', dataAbertura: '' }, hoje), '');
  assert.equal(calcStatus({ cx: '', dataAbertura: '2026-10-01', prazo: '2026-10-22' }, hoje), STATUS.ATRASADO);
  assert.equal(calcStatus({ cx: '', dataAbertura: '2026-10-01', prazo: '2026-10-23' }, hoje), STATUS.ANDAMENTO); // hoje <= prazo
  // sem prazo: exatamente 15 dias ainda é planejamento; 16 dias passa a AG. PRAZO
  assert.equal(calcStatus({ cx: '', dataAbertura: '2026-10-08' }, hoje), STATUS.PLANEJAMENTO);
  assert.equal(calcStatus({ cx: '', dataAbertura: '2026-10-07' }, hoje), STATUS.AG_PRAZO);
});

test('código da O.S.: corrige O/0 e detecta inválidos', () => {
  assert.deepEqual(normalizeOsCode('OSNO103911'), { code: 'OSN0103911', valid: true, changed: true });
  assert.equal(normalizeOsCode(' osn0103911 ').code, 'OSN0103911');
  assert.equal(normalizeOsCode('OSN01020107').valid, false);   // 8 dígitos (erro de digitação da planilha)
  assert.equal(normalizeOsCode('DS8700003282022').valid, false);
  assert.equal(normalizeOsCode('OSN0I03911').code, 'OSN0103911');
});

test('TSV segue a ordem das colunas da planilha', () => {
  const r = newRecord({ os: 'OSN0103911', setor: 'MANUTENÇÃO', problema: 'FIO\tSOLTO', equipamento: 'PRO-0001', dataAbertura: '2026-10-01' });
  assert.equal(toTSV([r], hoje), 'OSN0103911\tMANUTENÇÃO\tFIO SOLTO\tPRO-0001\t01/10/2026\t\t\tAG. PRAZO');
});

test('indicadores e mais antigas', () => {
  const mk = (os, setor, ab, extra = {}) => newRecord({ os, setor, dataAbertura: ab, ...extra });
  const rs = [
    mk('OSN0000001', 'MANUTENÇÃO', '2026-01-10', { cx: '✓' }),
    mk('OSN0000002', 'MANUTENÇÃO', '2026-01-11'),
    mk('OSN0000003', 'FERRAMENTARIA', '2026-10-20'),
    mk('OSN0000004', 'FERRAMENTARIA', '2026-02-01', { cx: '❌' }),
    mk('OSN0000005', 'FERRAMENTARIA', '2026-03-01', { prazo: '2026-03-10' }),
  ];
  const k = kpis(rs, hoje);
  assert.equal(k.porStatus[STATUS.CONCLUIDO], 1);
  assert.equal(k.porStatus[STATUS.CANCELADO], 1);
  assert.equal(k.porStatus[STATUS.ATRASADO], 1);
  assert.equal(k.porStatus[STATUS.AG_PRAZO], 1);
  assert.equal(k.porStatus[STATUS.PLANEJAMENTO], 1);
  assert.equal(k.indice['MANUTENÇÃO'], 0.5);               // 1 concluída / (1 + 1 aberta)
  assert.equal(k.indice['FERRAMENTARIA'], 0);              // cancelada fica fora da base
  assert.deepEqual(maisAntigas(rs, 2, hoje).map((r) => r.os), ['OSN0000002', 'OSN0000005']);
});

test('auditoria: histórico, rev e data de conclusão', () => {
  const r = newRecord({ os: 'OSN0103911' });
  const r2 = applyChange(r, { cx: '✓', prazo: '2026-10-30' }, 'rodrigo', '2026-10-23T10:00:00.000Z');
  assert.equal(r2.rev, r.rev + 1);
  assert.equal(r2.dataConclusao, '2026-10-23');
  assert.equal(r2.historico.length, 2);
  assert.deepEqual(camposFaltando(r), ['setor', 'problema', 'equipamento', 'dataAbertura']);
});
