import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { extractOS, nivelConf } from '../js/extract.js';

const fx = (n) => fs.readFileSync(new URL(`./fixtures/${n}`, import.meta.url), 'utf8');

function confere(res) {
  const r = res.record;
  assert.equal(res.isOS, true);
  assert.equal(r.os, 'OSN0103911');
  assert.equal(r.equipamento, 'PRO-0001');
  assert.equal(r.equipamentoDescricao, 'PRODUÇÃO');
  assert.equal(r.tipoServico, 'MANUTENÇÃO ELÉTRICA');
  assert.equal(r.problema, 'FIO DE ELETRICIDADE DESCASCADOPERTO NA SOLDA 2');
  assert.equal(r.dataAbertura, '2026-10-01');
  assert.equal(r.horaAbertura, '12:16:17');
  assert.equal(r.setor, 'MANUTENÇÃO');
  assert.equal(r.recepcao.centroTrabalho, '9232 - MANUTENCAO DE FABRICA');
  assert.equal(r.solicitante.matricula, '548');
  assert.equal(r.solicitante.nome, 'VITTOR VINICIUS DA SILVA');
  assert.equal(r.solicitante.centroTrabalho, '0005P - MANUTENCAO PREDIAL');
  assert.equal(r.criticidade, 'A - MUITO ELEVADO');
  assert.equal(r.centroCusto, '9268');
  assert.equal(r.unidadeFuncional, '117130000 - MANUTENCAO PREDIAL');
  assert.equal(r.tipoOS, 'NÃO PROGRAMADA');
  assert.equal(r.extraidoEm, '2026-10-01T12:18:05');
}

test('camada de texto do PDF', () => {
  const res = extractOS(fx('os_texto_pdf.txt'));
  confere(res);
  assert.equal(nivelConf(res.conf.os), 'ok');
  assert.deepEqual(res.warnings, []);
});

test('OCR real (O no lugar de 0 no código é corrigido e sinalizado)', () => {
  const res = extractOS(fx('os_ocr.txt'));
  confere(res);
  assert.equal(nivelConf(res.conf.os), 'conferir');
  assert.ok(res.warnings.some((w) => w.includes('corrigido')));
});

test('setor não mapeado gera aviso e fica vazio', () => {
  const t = fx('os_texto_pdf.txt').replace('MANUTENCAO DE FABRICA', 'ALMOXARIFADO');
  const res = extractOS(t);
  assert.equal(res.record.setor, '');
  assert.ok(res.warnings.some((w) => w.includes('Setor não mapeado')));
});

test('regras de setor configuráveis e observação em várias linhas', () => {
  let t = fx('os_texto_pdf.txt').replace('MANUTENCAO DE FABRICA', 'FERRAMENTARIA GERAL');
  t = t.replace('NA SOLDA 2\n', 'NA SOLDA 2\nCONTINUACAO DO TEXTO\n');
  const res = extractOS(t);
  assert.equal(res.record.setor, 'FERRAMENTARIA');
  assert.equal(res.record.problema, 'FIO DE ELETRICIDADE DESCASCADOPERTO NA SOLDA 2 CONTINUACAO DO TEXTO');
});

test('texto que não é O.S.', () => {
  const res = extractOS('RELATORIO DE QUALIDADE\nlote 12\n');
  assert.equal(res.isOS, false);
  assert.equal(res.record.os, '');
});

test('OCR de má qualidade (":" lido como "1", "+", ";"): campos continuam corretos', () => {
  const res = extractOS(fx('os_ocr_degradado.txt'));
  const r = res.record;
  assert.equal(r.os, 'OSN0103911');
  assert.equal(r.equipamento, 'PRO-0001');
  assert.equal(r.tipoServico, 'MANUTENÇÃO ELÉTRICA');
  assert.equal(r.problema, 'FIO DE ELETRICIDADE DESCASCADOPERTO NA SOLDA 2');
  assert.equal(r.dataAbertura, '2026-10-01');
  assert.equal(r.horaAbertura, '12:16:17');
  assert.equal(r.setor, 'MANUTENÇÃO');
  assert.equal(r.solicitante.nome, 'VITTOR VINICIUS DA SILVA');
});
