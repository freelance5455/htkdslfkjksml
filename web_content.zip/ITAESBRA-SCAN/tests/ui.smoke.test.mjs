// Teste de fumaça da interface: monta as telas num DOM simulado (jsdom) e percorre um fluxo completo
// (conferir O.S. → salvar → aparecer na gestão → editar). Só roda se o jsdom estiver instalado
// (npm i jsdom, ou defina JSDOM_DIR com a pasta que contém node_modules/jsdom).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { FakeDir } from './fakefs.mjs';

let JSDOM = null;
try { ({ JSDOM } = createRequire(process.env.JSDOM_DIR ? `${process.env.JSDOM_DIR}/` : import.meta.url)('jsdom')); } catch { /* sem jsdom */ }

test('interface: fluxo completo conferir → salvar → gestão → editar', { skip: !JSDOM && 'jsdom não instalado' }, async () => {
  const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8').replace(/<script[\s\S]*?<\/script>/g, '');
  const dom = new JSDOM(html, { url: 'http://localhost:8080/', pretendToBeVisual: true });
  const { window } = dom;
  window.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
  window.HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); this.dispatchEvent(new window.Event('close')); };
  Object.assign(globalThis, {
    window, document: window.document, localStorage: window.localStorage, location: window.location,
    HTMLElement: window.HTMLElement, Node: window.Node,
  });
  window.matchMedia ??= () => ({ matches: false, addEventListener() {}, removeEventListener() {} });
  const erros = [];
  window.addEventListener('error', (e) => erros.push(e.message));

  await import('../js/main.js');
  const { app, emit } = await import('../js/state.js');
  const { Repo } = await import('../js/storage.js');
  const { extractOS } = await import('../js/extract.js');
  const { newRecord } = await import('../js/osmodel.js');
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const esperar = (ms = 30) => new Promise((r) => setTimeout(r, ms));

  // telas montadas
  assert.equal($$('#rail .nav').length, 4);
  assert.match($('#view-scan').textContent, /Digitalizar/);
  assert.match($('#view-settings').textContent, /Pasta de armazenamento/);
  assert.match($('#avisos').textContent, /Escolha a pasta|navegador/);

  // conecta uma pasta simulada
  app.repo = new Repo(new FakeDir());
  app.pastaNome = 'REDE';
  app.conectada = true;
  app.quem = 'teste';
  emit('conexao');

  // job "a conferir" com os dados extraídos do texto real da O.S.
  const texto = fs.readFileSync(new URL('./fixtures/os_ocr.txt', import.meta.url), 'utf8');
  const ext = extractOS(texto);
  app.jobs.unshift({
    id: 'j1', estado: 'conferir', etapa: '', categoriaId: 'os', origem: 'arquivo', nome: 'OSN0103911.pdf', paginas: [],
    pdfBytes: new TextEncoder().encode('%PDF-teste'), pdfOriginal: true, previewUrl: '', extracao: ext,
    record: newRecord({ ...ext.record, origem: 'ocr' }), duplicada: null, avisos: [...ext.warnings], erro: '', numPaginas: 1,
  });
  emit('jobs');
  $$('#rail .nav')[1].click();
  await esperar();
  const view = $('#view-review');
  assert.equal($('#cnt-conf').textContent, '1');
  const campos = [...view.querySelectorAll('input, textarea, select')].map((e) => e.value);
  assert.ok(campos.includes('OSN0103911'), 'código da O.S. deve aparecer no formulário');
  assert.ok(campos.includes('PRO-0001'));
  assert.ok(campos.includes('2026-10-01'));
  assert.ok(campos.some((v) => v.startsWith('FIO DE ELETRICIDADE')));
  assert.ok(campos.includes('MANUTENÇÃO'));

  // salvar
  [...view.querySelectorAll('button')].find((b) => /^Salvar/.test(b.textContent)).click();
  await esperar(100);
  const salvo = await app.repo.carregarOS('OSN0103911');
  assert.equal(salvo.setor, 'MANUTENÇÃO');
  assert.equal(salvo.historico[0].quem, 'teste');
  assert.equal(app.jobs[0].estado, 'salvo');
  assert.ok(await app.repo.existe(['Documentos', 'Ordens de Serviço', '2026', '10-Outubro'], 'OSN0103911.pdf'));

  // gestão
  $$('#rail .nav')[2].click();
  await esperar();
  const g = $('#view-manage');
  assert.match(g.textContent, /OSN0103911/);
  assert.match(g.textContent, /AG\. PRAZO|EM PLANEJAMENTO/);
  g.querySelector('tbody tr').click();
  await esperar();
  const dlg = document.querySelector('dialog[open]');
  assert.ok(dlg, 'diálogo de edição');
  const selects = [...dlg.querySelectorAll('select')];
  const cx = selects.find((s) => [...s.options].some((o) => o.value === '✓'));
  cx.value = '✓';
  [...dlg.querySelectorAll('button')].find((b) => b.textContent === 'Salvar').click();
  await esperar(100);
  const depois = await app.repo.carregarOS('OSN0103911');
  assert.equal(depois.cx, '✓');
  assert.equal(depois.dataConclusao.length, 10);
  assert.equal(depois.rev, 2);
  assert.match($('#view-manage').textContent, /CONCLUÍDO/);
  assert.deepEqual(erros, []);
});
