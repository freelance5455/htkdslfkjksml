import fs from 'node:fs';
import { createRequire } from 'node:module';

/** Carrega o ExcelJS empacotado em vendor/ (bundle de navegador, formato UMD) dentro do Node. */
export function carregarExcelJS() {
  const require = createRequire(import.meta.url);
  const code = fs.readFileSync(new URL('../vendor/exceljs/exceljs.min.js', import.meta.url), 'utf8');
  const mod = { exports: {} };
  new Function('module', 'exports', 'require', code).call(mod.exports, mod, mod.exports, require);
  return mod.exports;
}
