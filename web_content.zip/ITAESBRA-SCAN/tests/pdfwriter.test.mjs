import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { buildPdf } from '../js/pdfwriter.js';

const jpg = (n) => new Uint8Array(fs.readFileSync(new URL(`./fixtures/${n}`, import.meta.url)));
const pages = () => [
  { jpeg: jpg('pagina1.jpg'), width: 400, height: 560 },
  { jpeg: jpg('pagina2.jpg'), width: 600, height: 400 },
];

test('estrutura do PDF: tabela xref aponta para os objetos corretos', () => {
  const pdf = buildPdf(pages(), { title: 'OSN0103911 — teste (ç)' });
  const text = Buffer.from(pdf).toString('latin1');
  assert.ok(text.startsWith('%PDF-1.4'));
  assert.ok(text.trimEnd().endsWith('%%EOF'));
  assert.match(text, /\/Count 2/);
  const sx = Number(/startxref\n(\d+)\n%%EOF/.exec(text)[1]);
  assert.ok(text.slice(sx).startsWith('xref'));
  const offs = [...text.slice(sx).matchAll(/(\d{10}) 00000 n /g)].map((m) => Number(m[1]));
  assert.equal(offs.length, 3 + 3 * 2);
  offs.forEach((o, i) => assert.ok(text.slice(o).startsWith(`${i + 1} 0 obj`), `objeto ${i + 1}`));
});

test('PDF é válido para o qpdf e tem 2 páginas (retrato e paisagem)', (t) => {
  const tmp = path.join(os.tmpdir(), `os-scan-test-${process.pid}.pdf`);
  fs.writeFileSync(tmp, buildPdf(pages()));
  const q = spawnSync('qpdf', ['--check', tmp], { encoding: 'utf8' });
  if (q.error) return t.skip('qpdf não instalado');
  assert.equal(q.status, 0, q.stdout + q.stderr);
  const info = spawnSync('pdfinfo', ['-f', '1', '-l', '2', tmp], { encoding: 'utf8' });
  if (!info.error) {
    assert.match(info.stdout, /Pages:\s+2/);
    assert.match(info.stdout, /Page\s+1 size:\s+595 x 842/);
    assert.match(info.stdout, /Page\s+2 size:\s+842 x 595/);
  }
  fs.rmSync(tmp, { force: true });
});

test('sem páginas gera erro claro', () => {
  assert.throws(() => buildPdf([]), /Nenhuma página/);
});
