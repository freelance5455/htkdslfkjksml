import test from 'node:test';
import assert from 'node:assert/strict';
import { FakeDir } from './fakefs.mjs';
import { Repo, ConflictError } from '../js/storage.js';
import { salvarDocumento } from '../js/service.js';
import { CATEGORIAS_PADRAO, nomeSequencial, pastaDestino, nomeSeguro } from '../js/config.js';
import { newRecord } from '../js/osmodel.js';

const catOS = CATEGORIAS_PADRAO[0];
const catQual = CATEGORIAS_PADRAO[1];
const pdf = (s) => new TextEncoder().encode(`%PDF-fake-${s}`);
const rec = (extra = {}) => newRecord({
  os: 'OSN0103911', setor: 'MANUTENÇÃO', problema: 'FIO DESCASCADO', equipamento: 'PRO-0001',
  dataAbertura: '2026-10-01', origem: 'ocr', ...extra,
});

test('nomes e pastas', () => {
  assert.deepEqual(pastaDestino(catOS, '2026-10-01'), ['Documentos', 'Ordens de Serviço', '2026', '10-Outubro']);
  assert.equal(nomeSeguro('a/b:c*?'), 'a_b_c__');
  assert.equal(nomeSequencial('QUAL', '2026-10-21', ['QUAL_20261021_000001.pdf', 'QUAL_20261021_000007.pdf', 'x.pdf']), 'QUAL_20261021_000008.pdf');
});

test('salva O.S.: PDF no destino certo + registro JSON + nunca sobrescreve PDF', async () => {
  const repo = new Repo(new FakeDir());
  const r1 = await salvarDocumento(repo, { categoria: catOS, pdfBytes: pdf('1'), record: rec(), quem: 'rodrigo' });
  assert.equal(r1.caminho, 'Documentos/Ordens de Serviço/2026/10-Outubro/OSN0103911.pdf');
  assert.equal(r1.atualizado, false);
  const salvo = await repo.carregarOS('OSN0103911');
  assert.equal(salvo.arquivoPdf, r1.caminho);
  assert.equal(salvo.rev, 1);
  assert.equal(salvo.historico[0].quem, 'rodrigo');

  // mesma O.S. de novo: atualiza o cadastro, PDF novo recebe sufixo _2 (nada é sobrescrito)
  const r2 = await salvarDocumento(repo, { categoria: catOS, pdfBytes: pdf('2'), record: rec({ problema: 'FIO DESCASCADO NA SOLDA 2' }), quem: 'ana' });
  assert.equal(r2.atualizado, true);
  assert.equal(r2.nome, 'OSN0103911_2.pdf');
  const atual = await repo.carregarOS('OSN0103911');
  assert.equal(atual.rev, 2);
  assert.equal(atual.problema, 'FIO DESCASCADO NA SOLDA 2');
  assert.ok(atual.historico.some((h) => h.campo === 'problema' && h.quem === 'ana'));
  const dir = await repo.listar(['Documentos', 'Ordens de Serviço', '2026', '10-Outubro']);
  assert.deepEqual(dir.map((d) => d.name).sort(), ['OSN0103911.pdf', 'OSN0103911_2.pdf']);
});

test('atualização preserva prazo e conclusão já definidos na gestão', async () => {
  const repo = new Repo(new FakeDir());
  await salvarDocumento(repo, { categoria: catOS, pdfBytes: pdf('1'), record: rec() });
  const r = await repo.carregarOS('OSN0103911');
  await repo.salvarOS({ ...r, prazo: '2026-10-30', cx: '✓', rev: r.rev + 1 }, { expectedRev: r.rev });
  await salvarDocumento(repo, { categoria: catOS, pdfBytes: pdf('2'), record: rec() });
  const f = await repo.carregarOS('OSN0103911');
  assert.equal(f.prazo, '2026-10-30');
  assert.equal(f.cx, '✓');
});

test('modo bloquear impede duplicada', async () => {
  const repo = new Repo(new FakeDir());
  await salvarDocumento(repo, { categoria: catOS, pdfBytes: pdf('1'), record: rec() });
  await assert.rejects(() => salvarDocumento(repo, { categoria: catOS, pdfBytes: pdf('2'), record: rec(), modoDuplicada: 'bloquear' }), /já está cadastrada/);
});

test('conflito de edição simultânea é detectado', async () => {
  const repo = new Repo(new FakeDir());
  await salvarDocumento(repo, { categoria: catOS, pdfBytes: pdf('1'), record: rec() });
  const a = await repo.carregarOS('OSN0103911');
  await repo.salvarOS({ ...a, prazo: '2026-11-01', rev: 2 }, { expectedRev: 1 });   // outra pessoa salvou antes
  await assert.rejects(() => repo.salvarOS({ ...a, prazo: '2026-12-01', rev: 2 }, { expectedRev: 1 }), ConflictError);
});

test('categoria comum usa nome sequencial e não cria registro de O.S.', async () => {
  const repo = new Repo(new FakeDir());
  const a = await salvarDocumento(repo, { categoria: catQual, pdfBytes: pdf('a'), record: null });
  const b = await salvarDocumento(repo, { categoria: catQual, pdfBytes: pdf('b'), record: null });
  const dia = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  assert.equal(a.nome, `QUAL_${dia}_000001.pdf`);
  assert.equal(b.nome, `QUAL_${dia}_000002.pdf`);
  assert.equal((await repo.listarOS()).registros.length, 0);
});

test('lista a base inteira e config compartilhada', async () => {
  const repo = new Repo(new FakeDir());
  for (const n of ['OSN0000002', 'OSN0000001']) await repo.salvarOS(rec({ os: n, dataAbertura: n.endsWith('1') ? '2026-01-01' : '2026-02-01' }));
  const { registros, erros } = await repo.listarOS();
  assert.deepEqual(registros.map((r) => r.os), ['OSN0000001', 'OSN0000002']);
  assert.equal(erros.length, 0);
  assert.equal((await repo.carregarConfig()).categorias.length, 6);
  assert.equal(await repo.testarGravacao(), true);
});
