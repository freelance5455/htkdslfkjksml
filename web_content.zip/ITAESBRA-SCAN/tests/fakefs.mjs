// Sistema de arquivos em memória com a mesma API de FileSystemDirectoryHandle (para testes).
class NotFound extends Error { constructor(m) { super(m); this.name = 'NotFoundError'; } }

export class FakeFile {
  constructor(name, bytes, mod) { this.name = name; this.bytes = bytes; this.lastModified = mod; }
  get size() { return this.bytes.length; }
  async text() { return new TextDecoder().decode(this.bytes); }
  async arrayBuffer() { return this.bytes.buffer.slice(this.bytes.byteOffset, this.bytes.byteOffset + this.bytes.byteLength); }
}

class FakeFileHandle {
  constructor(dir, name) { this.kind = 'file'; this.dir = dir; this.name = name; }
  async getFile() { const b = this.dir.files.get(this.name); if (!b) throw new NotFound(this.name); return new FakeFile(this.name, b, Date.now()); }
  async createWritable() {
    const chunks = [];
    return {
      write: async (data) => { chunks.push(typeof data === 'string' ? new TextEncoder().encode(data) : new Uint8Array(data.buffer ?? data, data.byteOffset ?? 0, data.byteLength ?? data.length)); },
      close: async () => { const len = chunks.reduce((s, c) => s + c.length, 0); const out = new Uint8Array(len); let o = 0; for (const c of chunks) { out.set(c, o); o += c.length; } this.dir.files.set(this.name, out); },
    };
  }
}

export class FakeDir {
  constructor(name = 'root') { this.kind = 'directory'; this.name = name; this.files = new Map(); this.dirs = new Map(); }
  async getDirectoryHandle(n, { create = false } = {}) {
    if (!this.dirs.has(n)) { if (!create) throw new NotFound(n); this.dirs.set(n, new FakeDir(n)); }
    return this.dirs.get(n);
  }
  async getFileHandle(n, { create = false } = {}) {
    if (!this.files.has(n)) { if (!create) throw new NotFound(n); this.files.set(n, new Uint8Array(0)); }
    return new FakeFileHandle(this, n);
  }
  async removeEntry(n) { if (!this.files.delete(n) && !this.dirs.delete(n)) throw new NotFound(n); }
  async *entries() {
    for (const n of this.dirs.keys()) yield [n, this.dirs.get(n)];
    for (const n of this.files.keys()) yield [n, new FakeFileHandle(this, n)];
  }
}
