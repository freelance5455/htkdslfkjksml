import test from 'node:test';
import assert from 'node:assert/strict';
import {
  makeImage, detectQuad, warpPerspective, outputSize, applyFilter, normalizeBackground,
  blurScore, boxBlurGray, rotate90, toGray, processPage, orderQuad,
} from '../js/imaging.js';

function inQuad(q, x, y) {
  let sign = 0;
  for (let i = 0; i < 4; i++) {
    const a = q[i], b = q[(i + 1) % 4];
    const c = (b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x);
    if (c !== 0) { if (sign === 0) sign = Math.sign(c); else if (Math.sign(c) !== sign) return false; }
  }
  return true;
}

/** Cena sintética: fundo + folha em perspectiva com "linhas de texto". */
function cena({ w = 640, h = 480, fundo = 60, papel = 235, quad, sombra = false }) {
  const img = makeImage(w, h, fundo);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (!inQuad(quad, x, y)) continue;
      let v = papel;
      if (sombra) v = papel * (1 - 0.5 * (x / w)); // sombra gradual da esquerda para a direita
      if (y % 22 < 3 && x % 40 < 28) v = 25;
      const p = (y * w + x) * 4;
      img.data[p] = img.data[p + 1] = img.data[p + 2] = v;
    }
  }
  return img;
}
const Q = [{ x: 110, y: 60 }, { x: 520, y: 90 }, { x: 560, y: 420 }, { x: 80, y: 400 }];
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

test('detecta a folha clara sobre fundo escuro (4 cantos)', () => {
  const det = detectQuad(cena({ quad: Q }));
  assert.ok(det, 'folha não detectada');
  det.quad.forEach((p, i) => assert.ok(dist(p, Q[i]) < 10, `canto ${i} fora: ${JSON.stringify(p)}`));
});

test('detecta a folha escura sobre fundo claro', () => {
  const det = detectQuad(cena({ quad: Q, fundo: 245, papel: 90 }));
  assert.ok(det);
  det.quad.forEach((p, i) => assert.ok(dist(p, Q[i]) < 10));
});

test('não inventa folha numa imagem uniforme', () => {
  assert.equal(detectQuad(makeImage(320, 240, 128)), null);
});

test('ordenação dos cantos independe da ordem de entrada', () => {
  const emb = [Q[2], Q[0], Q[3], Q[1]];
  assert.deepEqual(orderQuad(emb), Q);
});

test('correção de perspectiva produz retângulo com papel branco', () => {
  const img = cena({ quad: Q });
  const { w, h } = outputSize(Q, 800);
  const out = warpPerspective(img, Q, w, h);
  assert.equal(out.width, w);
  const g = toGray(out);
  // cantos da folha retificada devem ser papel (claro), nunca fundo escuro
  const janela = (cx, cy) => { let s = 0, n = 0; for (let y = cy - 4; y <= cy + 4; y++) for (let x = cx - 4; x <= cx + 4; x++) { s += g[y * w + x]; n++; } return s / n; };
  for (const [x, y] of [[8, 8], [w - 9, 8], [w - 9, h - 9], [8, h - 9]]) assert.ok(janela(x, y) > 170, `canto (${x},${y}) = ${janela(x, y)}`);
});

test('tratamento de sombras uniformiza o papel', () => {
  const quad = [{ x: 0, y: 0 }, { x: 639, y: 0 }, { x: 639, y: 479 }, { x: 0, y: 479 }];
  const img = cena({ quad, sombra: true });
  const antes = toGray(img);
  const depois = toGray(normalizeBackground(img));
  const media = (g, x0, x1) => { let s = 0, n = 0; for (let y = 5; y < 475; y++) for (let x = x0; x < x1; x++) { if (y % 22 < 6) continue; s += g[y * 640 + x]; n++; } return s / n; };
  assert.ok(media(antes, 10, 60) - media(antes, 580, 630) > 70);            // sombra forte antes
  assert.ok(Math.abs(media(depois, 10, 60) - media(depois, 580, 630)) < 12); // uniforme depois
  assert.ok(media(depois, 580, 630) > 235);
});

test('filtro P&B gera somente preto e branco e mantém o texto', () => {
  const quad = [{ x: 0, y: 0 }, { x: 639, y: 0 }, { x: 639, y: 479 }, { x: 0, y: 479 }];
  const out = applyFilter(cena({ quad, sombra: true }), { mode: 'bw' });
  const g = toGray(out);
  let pretos = 0;
  for (const v of g) { assert.ok(v === 0 || v === 255); if (v === 0) pretos++; }
  const frac = pretos / g.length;
  assert.ok(frac > 0.02 && frac < 0.2, `fração de preto ${frac}`); // texto ~ 3/22 * 28/40 ≈ 9%
});

test('nitidez: imagem nítida pontua muito mais que a desfocada', () => {
  const quad = [{ x: 0, y: 0 }, { x: 639, y: 0 }, { x: 639, y: 479 }, { x: 0, y: 479 }];
  const nitida = cena({ quad });
  const g = toGray(nitida);
  const emb = boxBlurGray(boxBlurGray(g, 640, 480, 3), 640, 480, 3);
  const borrada = makeImage(640, 480);
  for (let i = 0; i < emb.length; i++) borrada.data[i * 4] = borrada.data[i * 4 + 1] = borrada.data[i * 4 + 2] = emb[i];
  assert.ok(blurScore(nitida) > 5 * blurScore(borrada), `${blurScore(nitida)} vs ${blurScore(borrada)}`);
});

test('rotação de 90° no sentido horário', () => {
  const img = makeImage(3, 2, 0);
  img.data[0] = 200; // pixel (0,0) vermelho
  const r = rotate90(img);
  assert.equal(r.width, 2);
  assert.equal(r.height, 3);
  assert.equal(r.data[(0 * 2 + 1) * 4], 200); // (0,0) -> (h-1-0, 0) = (1,0)
});

test('pipeline completo da página', () => {
  const res = processPage(cena({ quad: Q }), { filter: 'color', maxSide: 900 });
  assert.equal(res.edgesFound, true);
  assert.equal(res.cutRisk, false);
  assert.ok(res.image.width > 300 && res.image.height > 300);
});
