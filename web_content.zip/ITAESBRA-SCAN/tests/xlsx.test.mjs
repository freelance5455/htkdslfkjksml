import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { exportarPlanilha, importarPlanilha } from '../js/xlsx.js';
import { newRecord, calcStatus } from '../js/osmodel.js';

import { carregarExcelJS } from './helpers.mjs';
const ExcelJS = carregarExcelJS();
const hoje = '2026-10-23';

const base = () => [
  newRecord({ os: 'OSN0103911', setor: 'MANUTENÇÃO', problema: 'FIO DESCASCADO', equipamento: 'PRO-0001', dataAbertura: '2026-10-01', tipoServico: 'MANUTENÇÃO ELÉTRICA', arquivoPdf: 'Documentos/x.pdf' }),
  newRecord({ os: 'OSN0103900', setor: 'FERRAMENTARIA', problema: 'AJUSTE', equipamento: 'SP-0439', dataAbertura: '2026-03-02', prazo: '2026-03-10' }),
  newRecord({ os: 'OSN0103800', setor: 'MANUTENÇÃO', problema: 'OK', equipamento: 'PR-0428', dataAbertura: '2026-02-02', cx: '✓' }),
];

test('exporta e reimporta sem perder dados (ida e volta)', async () => {
  const buf = await exportarPlanilha(base(), { today: hoje, ExcelJS });
  const r = await importarPlanilha(buf, { ExcelJS });
  assert.equal(r.unicas, 3);
  const a = r.records.find((x) => x.os === 'OSN0103900');
  assert.equal(a.setor, 'FERRAMENTARIA');
  assert.equal(a.dataAbertura, '2026-03-02');
  assert.equal(a.prazo, '2026-03-10');
  assert.equal(calcStatus(a, hoje), 'ATRASADO');
  assert.equal(r.records.find((x) => x.os === 'OSN0103800').cx, '✓');
  assert.equal(r.avisos.length, 0);
});

test('importa a planilha real de controle (se estiver em /mnt/user-data/uploads)', async (t) => {
  const f = '/mnt/user-data/uploads/CONTROLE_DE_ORDENS_DE_SERVIÇO_-_2026__solda.xlsx';
  if (!fs.existsSync(f)) return t.skip('planilha real não disponível');
  const r = await importarPlanilha(fs.readFileSync(f), { ExcelJS });
  console.log('   linhas:', r.linhas, '| O.S. únicas:', r.unicas, '| avisos:', r.avisos.length);
  assert.ok(r.linhas > 400);
  assert.ok(r.unicas < r.linhas);
  assert.ok(r.records.some((x) => x.os === 'OSN0102698'), 'OSNO102698 deve ser corrigida para OSN0102698');
  assert.ok(r.avisos.some((a) => a.tipo === 'codigo'));
  assert.ok(r.avisos.some((a) => a.tipo === 'conflito'));
});

test('grava arquivo para conferência externa', async () => {
  const buf = await exportarPlanilha(base(), { today: hoje, ExcelJS });
  fs.writeFileSync(path.join(os.tmpdir(), 'export_teste.xlsx'), buf);
  assert.ok(buf.length > 5000);
});
