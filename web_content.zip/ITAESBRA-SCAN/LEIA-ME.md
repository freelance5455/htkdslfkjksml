# ITAESBRA SCAN — digitalização e gestão de O.S. (versão HTML, v0.1)

Aplicativo que roda no navegador (Chrome ou Edge), sem internet e sem nenhum serviço externo:

1. **Digitaliza** documentos pela câmera (detecção automática da folha, correção de perspectiva, filtros, alerta de desfoque), ou **importa PDFs/imagens** do scanner (arrastar, escolher ou pasta de entrada).
2. **Lê a O.S.** (texto do PDF ou OCR em português) e preenche os campos da planilha de controle.
3. **Grava** o PDF e o registro da O.S. numa **pasta da rede**, organizada por categoria/ano/mês.
4. **Gerencia as O.S.**: painel por status, filtros, edição com histórico, exportação para Excel no formato da sua planilha e importação da planilha atual.

> Esta é a **versão para computador** (para testar). A versão para celular vem depois — veja "Próxima fase".

---

## 1. Como iniciar (Windows)

1. Descompacte a pasta inteira (ex.: `C:\ITAESBRA-SCAN`). Não abra o `index.html` com duplo clique: o navegador bloqueia câmera, OCR e acesso a pastas em arquivos abertos direto.
2. Dê dois cliques em **`INICIAR.bat`**. Ele abre uma janela preta (deixe aberta) e o navegador em `http://localhost:8080/`.
   - Se o Windows perguntar sobre o PowerShell/firewall, é só o servidor local; ele atende apenas este computador.
   - Use **Google Chrome** ou **Microsoft Edge**.
3. Vá em **Configurações → Escolher pasta…** e selecione a pasta de rede (unidade mapeada, ex. `I:\...`, ou `\\servidor\compartilhamento\pasta`). Clique em **Testar gravação**.
4. Em **Configurações**, preencha **Seu nome** (aparece no histórico de cada O.S.) e clique em **Salvar configurações**.
5. Nas próximas vezes, o navegador pede para **Reconectar pasta** (uma permissão por sessão, exigida pelo navegador).

## 2. Roteiro de teste (10 minutos) com a sua O.S. de exemplo

1. **Digitalizar → Importar PDFs / imagens…** e escolha `OSNO103911.pdf` (ou arraste o arquivo para a janela).
2. Vá em **Conferência**: os campos já vêm preenchidos (N° O.S., equipamento, tipo de serviço, problema, data, setor). Campos amarelos = conferir; vermelhos = corrigir.
3. **Salvar (Ctrl+Enter)**. O PDF vai para `Documentos/Ordens de Serviço/2026/10-Outubro/OSN0103911.pdf` e o registro para `BaseOS/os/OSN0103911.json`.
4. **Gestão de O.S.**: a O.S. aparece com status calculado. Clique nela para definir **Prazo**, concluir (✓) ou cancelar (❌).
5. **Exportar planilha (.xlsx)**: gera `CONTROLE_OS_AAAA-MM-DD_HHMM.xlsx` (baixa e grava uma cópia em `BaseOS/exportacoes/`).
6. **Importar planilha…**: selecione a sua planilha de controle 2026 para trazer o histórico (só entram as O.S. que ainda não existem na base).
7. Teste a câmera: **Digitalizar → Ligar câmera**, aponte para uma folha sobre uma superfície de cor diferente; a captura é automática quando a folha está parada (ou use a bolinha / barra de espaço).

## 3. Como os dados são guardados (banco de dados na pasta de rede)

```
<pasta escolhida>/
  Documentos/<Categoria>/<AAAA>/<MM-Mês>/arquivo.pdf    PDFs digitalizados
  BaseOS/os/OSN0103911.json                              um arquivo por O.S. (a base de dados)
  BaseOS/_config/config.json                             configuração compartilhada (categorias, regras de setor…)
  BaseOS/exportacoes/*.xlsx                              planilhas geradas
```

**Por que um arquivo por O.S. e não uma planilha/SQL única?** Vários computadores podem gravar ao mesmo tempo sem se atrapalhar (um SQLite ou Excel único em pasta de rede corrompe ou trava com acesso simultâneo). A planilha Excel é uma **visão gerada** dessa base, no mesmo formato da sua. Cada gravação tem controle de versão: se duas pessoas editarem a mesma O.S., a segunda é avisada em vez de sobrescrever.

- Nenhum PDF é sobrescrito: se já existir, o novo recebe `_2`, `_3`…
- Cada O.S. guarda **histórico** (quem alterou, quando, de/para).
- Os PDFs que não puderem ser gravados (pasta fora do ar) ficam numa **fila local** no navegador e podem ser reenviados.

## 4. Da O.S. para a planilha

| Campo do documento | Coluna da planilha | Observação |
|---|---|---|
| ORDEM DE SERVICO : OSN0103911 | N° DA O.S. | corrige O/0 do OCR (OSNO… → OSN0…) e avisa |
| Centro de trabalho da **RECEPCAO** (ex.: 9232 - MANUTENCAO DE FABRICA) | SETOR | pela regra "contém → setor" (Configurações). **Premissa minha**: confirme que "área que vai tratar o problema" é o que define o setor |
| OBSERVACAO | PROBLEMA | aceita várias linhas |
| EQUIPAMENTO (PRO-0001) | ÁREA/MÁQUINA/PRODUTO | |
| DATA/HORA da SOLICITACAO | DATA DE ABERTURA | a hora fica no cadastro |
| SERVICO SOLICITADO, CRITICIDADE, solicitante, recepção… | colunas extras na exportação | não existem na sua planilha atual |
| (gestão) | PRAZO, C/X | preenchidos na Gestão de O.S. |
| (calculado) | STATUS | mesma fórmula da sua planilha: ❌ cancelado, ✓ concluído, prazo vencido = atrasado, prazo vigente = em andamento, sem prazo há mais de 15 dias = ag. prazo, senão em planejamento |

Para continuar usando a **sua planilha atual** sem risco: na Conferência use **Copiar linha p/ planilha** e cole (Ctrl+V) na primeira célula (coluna B) da próxima linha — as 8 colunas já vêm na ordem certa. Ou use **Copiar linhas** na Gestão para colar várias.

A planilha exportada tem a aba de dados (STATUS por fórmula, listas suspensas e cores) e a aba **DASHBOARD** (contagens por status, índice de entrega por setor e as 5 O.S. abertas mais antigas, tudo por fórmula).

## 5. Pasta de entrada (scanner multifuncional)

Configure o scanner para salvar PDFs numa pasta. Em **Digitalizar → Pasta de entrada…** escolha essa pasta: o app lê cada arquivo novo, extrai os dados e organiza. Em Configurações você escolhe o que fazer com o original (mover para `_processados`, apagar ou manter) e pode ligar o monitoramento automático (a cada 20 s, com o app aberto).

## 6. O que foi testado (e o que não foi)

**Testado automaticamente (35 testes, `node --test tests/*.test.mjs`)**
- Leitura da O.S.: texto do PDF, OCR real da página e OCR degradado (':' lido como '1', '+', ';'); correção O/0; setor não mapeado; observação com várias linhas.
- Regras de status, indicadores, índice de entrega e "mais antigas", conferidos contra a sua planilha.
- Detecção da folha (clara/escura), perspectiva, remoção de sombras, preto e branco, nitidez, rotação.
- PDF gerado: validado pelo `qpdf --check` e `pdfinfo` (2 páginas, retrato e paisagem).
- Gravação: pastas/nomes, nunca sobrescrever, conflito de edição simultânea, atualização que preserva prazo/conclusão (sistema de arquivos simulado).
- Planilha: exportada → recalculada no LibreOffice (741 fórmulas, 0 erros) → valores do painel iguais aos do app; ida e volta sem perda; importação da **sua planilha real**: 417 linhas → 353 O.S. únicas, 73 pontos de atenção (códigos fora do padrão, repetidas, setores conflitantes).
- Interface (DOM simulado): fluxo conferir → salvar → aparecer na gestão → concluir.
- OCR: o mesmo motor e modelo em português que o app usa leram corretamente o código, equipamento, data, setor e problema da sua O.S. em imagem limpa, levemente desfocada e degradada. Desfoque forte (≥ 1,5 px) impede a leitura — o app avisa.

**NÃO testado (preciso do seu retorno no primeiro uso)**
- Câmera/webcam real, captura automática, e desempenho no seu computador (não há navegador nem câmera onde o app foi construído).
- Gravação em pasta de rede real (SMB), permissões do Windows, nomes longos.
- OCR de **fotos de câmera** (iluminação ruim, papel amassado) — só foi medido em imagens geradas do PDF.
- Dispositivos móveis.

Ajustes que dependem de medição real: o limiar de desfoque (Configurações, padrão 120, calibrado numa página de O.S. de 150 dpi), o filtro e a qualidade.

## 7. Dados da sua planilha que merecem atenção

Na planilha atual há **O.S. repetidas** (inclusive com setores diferentes, ex.: OSN0102303 em Ferramentaria e Manutenção), **códigos com erro de digitação** (`OSNO102698` com letra O, `OSN01020107` com 8 dígitos, `DS8700003282022` no lugar do código) e espaços sobrando. A importação normaliza o que dá, guarda uma O.S. por código e anota o problema em "Observações de gestão" para você revisar.

## 8. Próxima fase — celular

- O navegador do celular **só libera a câmera em HTTPS**, e **não consegue gravar em pastas de rede**. Será preciso: (a) publicar o app num servidor da fábrica com **HTTPS e certificado interno** e (b) um pequeno **serviço no servidor Windows** (API) que receba os PDFs e grave na pasta — o formato dos dados (pastas + JSON por O.S.) já foi pensado para isso. O envio offline com fila já existe (fila local).
- Instalação como app (PWA) e captura otimizada para o celular entram nessa fase.

## 9. Limitações conhecidas da v0.1

- Exige Chrome/Edge no computador (acesso a pastas). Firefox e Safari não servem.
- Só lê o layout "ORDEM DE SERVICO NAO PROGRAMADA" mostrado; outro layout precisa de ajuste nas regras de leitura.
- Sem login por usuário (usa o nome digitado + permissões do Windows na pasta). Sem apagar O.S. pela interface (por segurança).
- Reordenar páginas é por setas (sem arrastar).

## 10. Testes e bibliotecas

- Rodar os testes: instale o Node.js 20+ e execute `node --test tests/*.test.mjs` (o teste de interface precisa de `npm i jsdom`).
- Bibliotecas embutidas em `vendor/` (licenças nas pastas): **Tesseract.js** (Apache-2.0, com modelo `por` best_int), **pdf.js 3.11** (Apache-2.0), **ExcelJS 4.4** (MIT).
