@echo off
title ITAESBRA SCAN - servidor local
cd /d "%~dp0"
echo.
echo  Iniciando o ITAESBRA SCAN em http://localhost:8080/
echo  Deixe esta janela ABERTA enquanto usar o aplicativo.
echo  Para encerrar, feche esta janela.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor.ps1" -Porta 8080
pause
