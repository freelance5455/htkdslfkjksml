// Processa a página fora da thread principal (a câmera continua pronta para a próxima folha).
import { processPage } from './imaging.js';

self.onmessage = (ev) => {
  const { id, width, height, buffer, opts } = ev.data;
  try {
    const img = { data: new Uint8ClampedArray(buffer), width, height };
    const r = processPage(img, opts);
    self.postMessage({
      id, ok: true, width: r.image.width, height: r.image.height, buffer: r.image.data.buffer,
      quad: r.quad, edgesFound: r.edgesFound, cutRisk: r.cutRisk, blurScore: r.blurScore,
    }, [r.image.data.buffer]);
  } catch (e) {
    self.postMessage({ id, ok: false, erro: String(e.message || e) });
  }
};
