// Interface para o processamento de imagem: usa Web Worker; se não der, processa na thread principal.
import { processPage } from './imaging.js';

let worker = null;
let seq = 0;
const pend = new Map();
let semWorker = false;

function iniciar() {
  if (worker || semWorker) return;
  try {
    worker = new Worker(new URL('./imaging.worker.js', import.meta.url), { type: 'module' });
    worker.onmessage = (ev) => {
      const p = pend.get(ev.data.id);
      if (!p) return;
      pend.delete(ev.data.id);
      if (ev.data.ok) {
        p.resolve({
          image: { data: new Uint8ClampedArray(ev.data.buffer), width: ev.data.width, height: ev.data.height },
          quad: ev.data.quad, edgesFound: ev.data.edgesFound, cutRisk: ev.data.cutRisk, blurScore: ev.data.blurScore,
        });
      } else p.reject(new Error(ev.data.erro));
    };
    worker.onerror = () => { semWorker = true; worker = null; for (const p of pend.values()) p.reject(new Error('worker')); pend.clear(); };
  } catch { semWorker = true; worker = null; }
}

/** img = { data, width, height } (RGBA). O buffer da imagem original é copiado, não consumido. */
export function processarPagina(img, opts) {
  iniciar();
  if (!worker) return Promise.resolve().then(() => processPage(img, opts));
  const id = ++seq;
  return new Promise((resolve, reject) => {
    pend.set(id, { resolve, reject });
    const copia = img.data.slice().buffer;
    worker.postMessage({ id, width: img.width, height: img.height, buffer: copia, opts }, [copia]);
  }).catch(() => processPage(img, opts));
}
