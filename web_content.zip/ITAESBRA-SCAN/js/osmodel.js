// Modelo de dados da O.S., regras de status (idênticas às da planilha de controle) e indicadores.
// Módulo puro: funciona no navegador e no Node (testes).

export const SETORES = ['FERRAMENTARIA', 'MANUTENÇÃO'];

export const STATUS = {
  CANCELADO: 'CANCELADO',
  CONCLUIDO: 'CONCLUÍDO',
  ATRASADO: 'ATRASADO',
  ANDAMENTO: 'EM ANDAMENTO...',
  AG_PRAZO: 'AG. PRAZO',
  PLANEJAMENTO: 'EM PLANEJAMENTO',
};
export const STATUS_ABERTOS = [STATUS.ANDAMENTO, STATUS.ATRASADO, STATUS.AG_PRAZO, STATUS.PLANEJAMENTO];
export const CX_OK = '✓';
export const CX_CANCEL = '❌';
export const DIAS_AG_PRAZO = 15; // acima disso, sem prazo definido => AG. PRAZO

const pad = (n) => String(n).padStart(2, '0');

/** Data local de hoje no formato AAAA-MM-DD. */
export function todayISO(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** Número de dias desde 1970-01-01 (UTC) para uma data AAAA-MM-DD; null se inválida. */
export function dayNumber(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
  if (!m) return null;
  const t = Date.UTC(+m[1], +m[2] - 1, +m[3]);
  return Number.isNaN(t) ? null : Math.round(t / 86400000);
}

export function formatDateBR(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
  return m ? `${m[3]}/${m[2]}/${m[1]}` : '';
}

export function parseDateBR(txt) {
  const m = /^\s*(\d{1,2})\/(\d{1,2})\/(\d{2,4})\s*$/.exec(txt || '');
  if (!m) return '';
  let y = +m[3];
  if (y < 100) y += 2000;
  const iso = `${y}-${pad(+m[2])}-${pad(+m[1])}`;
  return dayNumber(iso) === null ? '' : iso;
}

/**
 * Status calculado — mesma lógica da fórmula da coluna STATUS da planilha:
 * ❌ => CANCELADO; ✓ => CONCLUÍDO; sem data => vazio;
 * com prazo: hoje > prazo => ATRASADO, senão EM ANDAMENTO...;
 * sem prazo: mais de 15 dias desde a abertura => AG. PRAZO, senão EM PLANEJAMENTO.
 */
export function calcStatus(rec, today = todayISO()) {
  if (rec.cx === CX_CANCEL) return STATUS.CANCELADO;
  if (rec.cx === CX_OK) return STATUS.CONCLUIDO;
  const ab = dayNumber(rec.dataAbertura);
  if (ab === null) return '';
  const t = dayNumber(today);
  const pr = dayNumber(rec.prazo);
  if (pr !== null) return t > pr ? STATUS.ATRASADO : STATUS.ANDAMENTO;
  return t - ab > DIAS_AG_PRAZO ? STATUS.AG_PRAZO : STATUS.PLANEJAMENTO;
}

/** Dias desde a abertura (ou null). */
export function diasEmAberto(rec, today = todayISO()) {
  const ab = dayNumber(rec.dataAbertura);
  const t = dayNumber(today);
  return ab === null || t === null ? null : t - ab;
}

/**
 * Normaliza o código da O.S. (OSN + 7 dígitos). Corrige confusões comuns de digitação/OCR
 * nos dígitos (O→0, I/L→1, S→5, B→8, Z→2). `valid` indica se ficou no padrão OSN#######.
 */
export function normalizeOsCode(raw) {
  const orig = String(raw ?? '').trim();
  const s = orig.toUpperCase().replace(/[\s_.:\-]/g, '');
  if (!s) return { code: '', valid: false, changed: false };
  const m = /^([O0][S5][NMH]?)([0-9OILSBZ|]+)$/.exec(s);
  if (!m) return { code: s, valid: /^OSN\d{7}$/.test(s), changed: s !== orig };
  const digits = m[2]
    .replace(/O/g, '0').replace(/[IL|]/g, '1').replace(/S/g, '5')
    .replace(/B/g, '8').replace(/Z/g, '2');
  const code = 'OSN' + digits;
  return { code, valid: /^OSN\d{7}$/.test(code), changed: code !== orig };
}

export function normalizeEquip(raw) {
  return String(raw ?? '').trim().toUpperCase().replace(/\s+/g, ' ');
}

export function newRecord(p = {}) {
  const now = new Date().toISOString();
  return {
    schema: 1,
    rev: 1,
    os: '',
    setor: '',
    problema: '',
    equipamento: '',
    equipamentoDescricao: '',
    dataAbertura: '',
    horaAbertura: '',
    prazo: '',
    cx: '',
    dataConclusao: '',
    tipoOS: '',
    tipoServico: '',
    servicoExecutado: '',
    criticidade: '',
    unidadeFuncional: '',
    centroCusto: '',
    solicitante: { matricula: '', nome: '', centroTrabalho: '' },
    recepcao: { matricula: '', centroTrabalho: '' },
    extraidoEm: '',
    arquivoPdf: '',
    origem: 'manual', // manual | texto-pdf | ocr | planilha
    observacoes: '',
    criadoEm: now,
    atualizadoEm: now,
    historico: [],
    ...p,
  };
}

/** Campos obrigatórios para considerar o registro completo. */
export function camposFaltando(rec) {
  const falta = [];
  if (!normalizeOsCode(rec.os).valid) falta.push('os');
  if (!rec.setor) falta.push('setor');
  if (!String(rec.problema || '').trim()) falta.push('problema');
  if (!String(rec.equipamento || '').trim()) falta.push('equipamento');
  if (dayNumber(rec.dataAbertura) === null) falta.push('dataAbertura');
  return falta;
}

/** Aplica alterações com trilha de auditoria; devolve novo registro (rev + 1). */
export function applyChange(rec, changes, quem = '', quando = new Date().toISOString()) {
  const out = { ...rec, historico: [...(rec.historico || [])] };
  for (const [campo, novo] of Object.entries(changes)) {
    const antigo = rec[campo];
    if (JSON.stringify(antigo) === JSON.stringify(novo)) continue;
    out.historico.push({ quando, quem, campo, de: antigo ?? '', para: novo ?? '' });
    out[campo] = novo;
  }
  if (out.cx === CX_OK && !out.dataConclusao) out.dataConclusao = quando.slice(0, 10);
  if (out.cx !== CX_OK && out.dataConclusao && changes.cx !== undefined) out.dataConclusao = '';
  out.rev = (rec.rev || 0) + 1;
  out.atualizadoEm = quando;
  return out;
}

/** Linha na ordem das colunas da planilha: N° O.S., SETOR, PROBLEMA, ÁREA/MÁQUINA/PRODUTO, ABERTURA, PRAZO, C/X, STATUS. */
export function recordToRow(rec, today = todayISO()) {
  return [
    rec.os, rec.setor, rec.problema, rec.equipamento,
    formatDateBR(rec.dataAbertura), formatDateBR(rec.prazo), rec.cx || '', calcStatus(rec, today),
  ];
}

/** Texto separado por TAB para colar direto na planilha de controle (colunas B a I). */
export function toTSV(records, today = todayISO()) {
  const clean = (v) => String(v ?? '').replace(/[\t\r\n]+/g, ' ').trim();
  return records.map((r) => recordToRow(r, today).map(clean).join('\t')).join('\n');
}

/** Indicadores iguais aos do DASHBOARD / CENTRO DE CÁLCULOS da planilha. */
export function kpis(records, today = todayISO()) {
  const porStatus = Object.fromEntries(Object.values(STATUS).map((s) => [s, 0]));
  const porSetor = {};
  for (const r of records) {
    const st = calcStatus(r, today);
    if (!st) continue;
    porStatus[st]++;
    const setor = r.setor || 'SEM SETOR';
    porSetor[setor] ??= Object.fromEntries(Object.values(STATUS).map((s) => [s, 0]));
    porSetor[setor][st]++;
  }
  const abertas = (c) => c[STATUS.ANDAMENTO] + c[STATUS.AG_PRAZO] + c[STATUS.PLANEJAMENTO];
  const indice = {};
  for (const [setor, c] of Object.entries(porSetor)) {
    const base = abertas(c) + c[STATUS.ATRASADO] + c[STATUS.CONCLUIDO]; // cancelados ficam fora
    indice[setor] = base ? c[STATUS.CONCLUIDO] / base : 0;
  }
  const c = porStatus;
  const base = abertas(c) + c[STATUS.ATRASADO] + c[STATUS.CONCLUIDO];
  return {
    porStatus, porSetor, indice,
    emAberto: abertas(c) + c[STATUS.ATRASADO],
    total: records.length,
    indiceGeral: base ? c[STATUS.CONCLUIDO] / base : 0,
  };
}

/** As N O.S. abertas mais antigas (equivale ao "TOP 5 O.S's MAIS ANTIGAS"). */
export function maisAntigas(records, n = 5, today = todayISO()) {
  return records
    .filter((r) => STATUS_ABERTOS.includes(calcStatus(r, today)))
    .sort((a, b) => (dayNumber(a.dataAbertura) - dayNumber(b.dataAbertura)) || a.os.localeCompare(b.os))
    .slice(0, n);
}
