// Conexão com a pasta de rede: permissão, carga da configuração e da base, fila local de reenvio.
import { app, emit } from './state.js';
import { Repo, garantirPermissao } from './storage.js';
import { mesclarConfig } from './config.js';
import { salvarDocumento } from './service.js';
import { outboxListar, outboxRemover } from './handles.js';

export async function conectar(handle, { pedirPermissao = false } = {}) {
  const ok = pedirPermissao
    ? await garantirPermissao(handle)
    : (await handle.queryPermission?.({ mode: 'readwrite' })) === 'granted';
  if (!ok) return false;
  app.repo = new Repo(handle);
  app.pastaNome = handle.name;
  app.conectada = true;
  try {
    app.config = await app.repo.carregarConfig();
    localStorage.setItem('osscan.config', JSON.stringify(app.config));
  } catch (e) { console.warn('config', e); }
  emit('config');
  emit('conexao');
  await recarregarBase();
  return true;
}

export async function recarregarBase(onProgress) {
  if (!app.repo || !app.conectada) return;
  const r = await app.repo.listarOS(onProgress);
  app.registros = r.registros;
  app.baseInfo = { carregadoEm: new Date(), erros: r.erros };
  emit('registros');
}

export async function salvarConfiguracao() {
  localStorage.setItem('osscan.config', JSON.stringify(app.config));
  if (app.repo && app.conectada) await app.repo.salvarConfig(app.config);
  emit('config');
}

export function configLocal() {
  try { return mesclarConfig(JSON.parse(localStorage.getItem('osscan.config') || '{}')); } catch { return mesclarConfig(); }
}

export async function contarOutbox() {
  try { return (await outboxListar()).length; } catch { return 0; }
}

/** Reenvia para a rede os documentos guardados localmente quando a pasta estava indisponível. */
export async function reenviarOutbox() {
  if (!app.repo || !app.conectada) throw new Error('Conecte a pasta de destino primeiro.');
  let ok = 0, falhas = 0;
  for (const it of await outboxListar()) {
    try {
      const categoria = app.config.categorias.find((c) => c.id === it.categoriaId) || app.config.categorias[0];
      const r = await salvarDocumento(app.repo, { categoria, pdfBytes: new Uint8Array(it.pdf), record: it.record, quem: app.quem, modoDuplicada: 'atualizar' });
      if (r.record) {
        const i = app.registros.findIndex((x) => x.os === r.record.os);
        if (i >= 0) app.registros[i] = r.record; else app.registros.push(r.record);
      }
      await outboxRemover(it.id);
      ok++;
    } catch (e) { console.warn(e); falhas++; }
  }
  emit('registros'); emit('outbox');
  return { ok, falhas };
}
