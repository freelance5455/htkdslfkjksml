// Regras de negócio de gravação: onde o PDF vai, como se chama e como o registro da O.S. é salvo.
import { pastaDestino, nomeSequencial, nomeSeguro } from './config.js';
import { normalizeOsCode, applyChange } from './osmodel.js';

/**
 * Grava o PDF e (para a categoria de O.S.) o registro na base.
 * @param job { categoria, pdfBytes: Uint8Array, record|null, quem, modoDuplicada: 'atualizar'|'bloquear' }
 * @returns { caminho, nome, record|null, atualizado: boolean }
 */
export async function salvarDocumento(repo, job) {
  const { categoria, pdfBytes, quem = '' } = job;
  let rec = job.record ? structuredClone(job.record) : null;
  const dataRef = rec?.dataAbertura || new Date().toISOString().slice(0, 10);
  const parts = pastaDestino(categoria, dataRef);

  let nomeArquivo;
  if (categoria.extrairOS && rec) {
    const n = normalizeOsCode(rec.os);
    if (!rec.os) throw new Error('Informe o código da O.S. antes de salvar.');
    rec.os = n.code || rec.os;
    nomeArquivo = `${nomeSeguro(rec.os)}.pdf`;
  } else {
    const existentes = (await repo.listar(parts)).map((e) => e.name);
    nomeArquivo = nomeSequencial(categoria.prefixo, dataRef, existentes);
  }

  let existente = null;
  if (rec) {
    existente = await repo.carregarOS(rec.os);
    if (existente && job.modoDuplicada === 'bloquear') {
      throw new Error(`A O.S. ${rec.os} já está cadastrada (aberta em ${existente.dataAbertura || 's/ data'}).`);
    }
  }

  const salvo = await repo.gravar(parts, nomeArquivo, pdfBytes, { unique: true });

  if (rec) {
    rec.arquivoPdf = salvo.caminho;
    const agora = new Date().toISOString();
    if (existente) {
      // atualiza o cadastro existente preservando prazo, conclusão e histórico já registrados
      const manter = { prazo: existente.prazo, cx: existente.cx, dataConclusao: existente.dataConclusao };
      const campos = { ...rec, ...Object.fromEntries(Object.entries(manter).filter(([, v]) => v)) };
      delete campos.historico; delete campos.rev; delete campos.criadoEm; delete campos.atualizadoEm;
      rec = applyChange(existente, campos, quem, agora);
      await repo.salvarOS(rec, { expectedRev: existente.rev });
    } else {
      rec.criadoEm = agora;
      rec.atualizadoEm = agora;
      rec.historico = [{ quando: agora, quem, campo: 'registro', de: '', para: 'criado a partir do documento digitalizado' }];
      await repo.salvarOS(rec, { expectedRev: 0 });
    }
  }
  return { caminho: salvo.caminho, nome: salvo.nome, record: rec, atualizado: !!existente };
}
