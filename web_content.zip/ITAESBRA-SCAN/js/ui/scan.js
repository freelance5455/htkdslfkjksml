// Tela "Digitalizar": câmera com detecção automática, importação de PDFs/imagens e pasta de entrada.
import { app, categoria, lembrar, on } from '../state.js';
import { h, toast, bip, dialogo, confirmar } from './dom.js';
import { Camera } from '../camera.js';
import { paginaDeImagem, jobDePaginas, jobDeArquivo, jpegParaCanvas } from '../jobs.js';
import { ajustarBordas } from './crop.js';
import { garantirPermissao } from '../storage.js';
import { salvarHandle } from '../handles.js';

let camera = null;
let raiz;
let el = {};
const vistosEntrada = new Set();
let timerEntrada = null;

export function montarScan(container) {
  raiz = container;
  container.replaceChildren(
    h('h1', {}, 'Digitalizar'),
    h('div', { class: 'painel linha', style: 'margin-bottom:14px' },
      h('label', { class: 'campo' }, h('span', { class: 'rot' }, 'Categoria'), el.cat = h('select', { onchange: (e) => { app.categoriaId = e.target.value; lembrar('categoria', app.categoriaId); renderPaginas(); } })),
      h('div', { class: 'campo' }, h('span', { class: 'rot muted', style: 'font-size:13px' }, 'Modo'),
        el.modo = h('div', { class: 'sel', role: 'group', 'aria-label': 'Modo de digitalização' },
          h('button', { 'data-m': 'A', title: 'Cada folha vira um PDF', onclick: () => trocarModo('A') }, 'A · Um PDF por folha'),
          h('button', { 'data-m': 'B', title: 'Várias folhas no mesmo PDF', onclick: () => trocarModo('B') }, 'B · Um PDF por documento'))),
      h('label', { class: 'campo' }, h('span', { class: 'rot' }, 'Filtro'),
        el.filtro = h('select', { onchange: (e) => { app.config.filtro = e.target.value; } },
          h('option', { value: 'color' }, 'Colorido'), h('option', { value: 'gray' }, 'Tons de cinza'),
          h('option', { value: 'bw' }, 'Preto e branco'), h('option', { value: 'original' }, 'Original (sem tratamento)'))),
      h('label', { class: 'linha', style: 'gap:6px; margin-top:18px' }, el.auto = h('input', { type: 'checkbox', onchange: (e) => { app.config.capturaAuto = e.target.checked; if (camera) camera.auto = e.target.checked; } }), 'Captura automática')),
    h('div', { class: 'scan-grid' },
      h('div', {},
        el.palco = h('div', { class: 'palco' },
          el.video = h('video', { playsinline: true, muted: true, autoplay: true }),
          el.overlay = h('canvas', { class: 'overlay' }),
          el.vazio = h('div', { class: 'vazio' },
            h('div', {}, 'Ligue a câmera para digitalizar, ou importe PDFs e imagens.'),
            h('div', {}, h('button', { class: 'btn primario grande', onclick: ligarCamera }, 'Ligar câmera'))),
          el.disparo = h('button', { class: 'disparo', title: 'Capturar (Espaço)', 'aria-label': 'Capturar página', hidden: true, onclick: () => capturar(false) })),
        h('div', { class: 'linha', style: 'margin-top:10px' },
          el.btnCam = h('button', { class: 'btn', onclick: alternarCamera }, 'Ligar câmera'),
          el.selCam = h('select', { style: 'width:auto', hidden: true, onchange: (e) => camera.iniciar(e.target.value).catch(erroCamera) }),
          el.btnLanterna = h('button', { class: 'btn', hidden: true, onclick: lanterna }, 'Lanterna'),
          h('button', { class: 'btn', onclick: () => el.arquivos.click() }, 'Importar PDFs / imagens…'),
          el.arquivos = h('input', { type: 'file', multiple: true, accept: '.pdf,application/pdf,image/*', hidden: true, onchange: (e) => { importar([...e.target.files]); e.target.value = ''; } }),
          h('button', { class: 'btn', onclick: abrirEntrada }, 'Pasta de entrada (scanner)…')),
        el.dica = h('p', { class: 'muted', style: 'font-size:13px' })),
      h('div', { class: 'painel' }, el.painelPag = h('div', {}))));
  el.cat.addEventListener('focus', preencherCategorias);
  document.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && !raiz.hidden && !/INPUT|TEXTAREA|SELECT|BUTTON/.test(e.target.tagName) && camera?.ativa) { e.preventDefault(); capturar(false); }
  });
  instalarArrastar();
  on('jobs', renderPaginas);
  on('config', atualizarControles);
  on('entrada-liberar', (e) => vistosEntrada.delete(e.detail));
  atualizarControles();
  renderPaginas();
  reiniciarMonitor();
}

function preencherCategorias() {
  const ativas = app.config.categorias.filter((c) => c.ativa !== false);
  el.cat.replaceChildren(...ativas.map((c) => h('option', { value: c.id, selected: c.id === app.categoriaId }, c.nome)));
}

function atualizarControles() {
  preencherCategorias();
  if (!app.config.categorias.some((c) => c.id === app.categoriaId)) app.categoriaId = app.config.categorias[0].id;
  el.cat.value = app.categoriaId;
  el.filtro.value = app.config.filtro;
  el.auto.checked = !!app.config.capturaAuto;
  el.modo.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.m === app.modo)));
  el.dica.textContent = app.modo === 'A'
    ? 'Modo A: cada folha capturada gera um PDF e já aparece em Conferência. A câmera continua pronta para a próxima folha.'
    : 'Modo B: capture todas as páginas; reordene, gire ou exclua; depois toque em "Finalizar documento".';
  if (camera) camera.auto = !!app.config.capturaAuto;
  reiniciarMonitor();
}

function trocarModo(m) {
  app.modo = m;
  lembrar('modo', m);
  atualizarControles();
  renderPaginas();
}

// ---------------------------------------------------------------- câmera

async function ligarCamera() {
  try {
    if (!camera) camera = new Camera(el.video, el.overlay, { aoEstavel: () => capturar(true) });
    camera.auto = !!app.config.capturaAuto;
    await camera.iniciar();
    el.vazio.hidden = true; el.disparo.hidden = false;
    el.btnCam.textContent = 'Desligar câmera';
    const cams = await camera.dispositivos();
    el.selCam.replaceChildren(...cams.map((c, i) => h('option', { value: c.deviceId }, c.label || `Câmera ${i + 1}`)));
    el.selCam.hidden = cams.length < 2;
    el.btnLanterna.hidden = !camera.stream?.getVideoTracks()[0]?.getCapabilities?.().torch;
  } catch (e) { erroCamera(e); }
}

function erroCamera(e) {
  const msg = e?.name === 'NotAllowedError' ? 'Permissão da câmera negada. Libere a câmera nas configurações do navegador (ícone de cadeado).'
    : e?.name === 'NotFoundError' ? 'Nenhuma câmera encontrada neste computador.'
      : `Não foi possível abrir a câmera: ${e?.message || e}`;
  toast(msg, 'erro', 8000);
}

function alternarCamera() {
  if (camera?.ativa) {
    camera.parar();
    el.vazio.hidden = false; el.disparo.hidden = true; el.btnCam.textContent = 'Ligar câmera';
  } else ligarCamera();
}

let torch = false;
async function lanterna() { torch = !torch; await camera.lanterna(torch).catch(() => {}); }

async function capturar(automatica) {
  if (!camera?.ativa || camera.ocupada) return;
  const cat = categoria();
  if (!cat) return toast('Escolha uma categoria.', 'aviso');
  camera.ocupada = true;
  try {
    const frame = camera.capturarQuadro();
    const pagina = await paginaDeImagem(frame, { quadNorm: frame.quadNorm });
    if (app.config.som) bip(!pagina.avisos.length);
    if (pagina.avisos.length) toast(pagina.avisos.join(' · '), 'aviso', 5000);
    if (app.modo === 'A') {
      jobDePaginas([pagina], `Captura ${new Date().toLocaleTimeString('pt-BR')}`);
      toast(automatica ? 'Folha capturada automaticamente.' : 'Folha capturada.', 'ok', 1800);
    } else {
      app.sessaoPaginas.push(pagina);
      renderPaginas();
    }
  } catch (e) {
    toast(`Falha na captura: ${e.message || e}`, 'erro');
  } finally { camera.ocupada = false; }
}

// ---------------------------------------------------------------- importação

function importar(arquivos) {
  const validos = arquivos.filter((f) => /\.(pdf|jpe?g|png|webp|bmp)$/i.test(f.name) || /^(image\/|application\/pdf)/.test(f.type));
  if (!validos.length) return toast('Nenhum PDF ou imagem encontrado.', 'aviso');
  validos.forEach((f) => jobDeArquivo(f));
  toast(`${validos.length} arquivo(s) enviados para leitura. Acompanhe em Conferência.`, 'ok');
}

function instalarArrastar() {
  let zona = null;
  const tem = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
  window.addEventListener('dragenter', (e) => { if (tem(e) && !zona) { zona = h('div', { class: 'dropzone' }, 'Solte aqui os PDFs ou imagens'); document.body.append(zona); } });
  window.addEventListener('dragover', (e) => { if (tem(e)) e.preventDefault(); });
  window.addEventListener('dragleave', (e) => { if (e.relatedTarget === null && zona) { zona.remove(); zona = null; } });
  window.addEventListener('drop', (e) => { if (!tem(e)) return; e.preventDefault(); zona?.remove(); zona = null; importar([...e.dataTransfer.files]); });
}

// ---------------------------------------------------------------- pasta de entrada (scanner multifuncional)

async function abrirEntrada() {
  if (!window.showDirectoryPicker) return toast('Este navegador não permite acessar pastas. Use o Chrome ou o Edge.', 'erro');
  try {
    if (!app.entrada) {
      app.entrada = await window.showDirectoryPicker({ id: 'entrada', mode: 'readwrite' });
      await salvarHandle('entrada', app.entrada);
      toast(`Pasta de entrada: ${app.entrada.name}`, 'ok');
    } else if (!(await garantirPermissao(app.entrada))) return toast('Sem permissão na pasta de entrada.', 'erro');
    await processarEntrada(false);
    reiniciarMonitor();
  } catch (e) { if (e.name !== 'AbortError') toast(`Pasta de entrada: ${e.message}`, 'erro'); }
}

export async function processarEntrada(silencioso) {
  if (!app.entrada) return;
  try {
    if (silencioso && (await app.entrada.queryPermission({ mode: 'readwrite' })) !== 'granted') return;
    let novos = 0;
    for await (const [nome, fh] of app.entrada.entries()) {
      if (fh.kind !== 'file' || nome.startsWith('_') || nome.startsWith('.') || vistosEntrada.has(nome)) continue;
      if (!/\.(pdf|jpe?g|png)$/i.test(nome)) continue;
      const f = await fh.getFile();
      if (!f.size || Date.now() - f.lastModified < 3000) continue; // ainda sendo gravado pelo scanner
      vistosEntrada.add(nome);
      jobDeArquivo(f, { entrada: { dir: app.entrada, nome }, origem: 'entrada' });
      novos++;
    }
    if (novos) toast(`${novos} arquivo(s) novos na pasta de entrada.`, 'ok');
    else if (!silencioso) toast('Nenhum arquivo novo na pasta de entrada.', 'info');
  } catch (e) { if (!silencioso) toast(`Pasta de entrada: ${e.message}`, 'erro'); }
}

function reiniciarMonitor() {
  clearInterval(timerEntrada);
  timerEntrada = null;
  if (app.config.monitorarEntrada && app.entrada) timerEntrada = setInterval(() => processarEntrada(true), 20000);
}

// ---------------------------------------------------------------- painel de páginas / capturas

function renderPaginas() {
  if (!el.painelPag) return;
  if (app.modo === 'A') {
    const recentes = app.jobs.filter((j) => j.origem === 'camera').slice(0, 6);
    el.painelPag.replaceChildren(
      h('h2', {}, 'Últimas capturas'),
      recentes.length ? h('div', { class: 'paginas' }, recentes.map((j) => h('div', { class: 'pagina' },
        h('img', { src: j.paginas[0]?.url, alt: j.nome }),
        h('small', { class: 'muted' }, rotuloEstado(j))))) : h('p', { class: 'muted' }, 'Nada capturado ainda.'));
    return;
  }
  const ps = app.sessaoPaginas;
  el.painelPag.replaceChildren(
    h('h2', {}, `Documento em andamento (${ps.length} pág.)`),
    ps.length ? h('div', { class: 'paginas' }, ps.map((p, i) => h('div', { class: 'pagina' },
      h('img', { src: p.url, alt: `Página ${i + 1}`, onclick: () => ampliar(p) }),
      p.avisos.map((a) => h('small', { class: 'aviso' }, a)),
      h('div', { class: 'acoes' },
        h('button', { title: 'Mover para a esquerda', disabled: i === 0, onclick: () => mover(i, -1) }, '◀'),
        h('button', { title: 'Mover para a direita', disabled: i === ps.length - 1, onclick: () => mover(i, 1) }, '▶'),
        h('button', { title: 'Girar 90°', onclick: () => girar(i) }, '⟳'),
        h('button', { title: 'Ajustar bordas', disabled: !p.raw, onclick: () => ajustar(i) }, '✂'),
        h('button', { title: 'Excluir página', onclick: () => { app.sessaoPaginas.splice(i, 1); renderPaginas(); } }, '✕'))))) : h('p', { class: 'muted' }, 'Capture as páginas do documento.'),
    h('div', { class: 'linha', style: 'margin-top:12px' },
      h('button', { class: 'btn primario', disabled: !ps.length, onclick: finalizar }, 'Finalizar documento'),
      h('button', { class: 'btn', disabled: !ps.length, onclick: async () => { if (await confirmar('Descartar todas as páginas deste documento?', { ok: 'Descartar', perigo: true })) { app.sessaoPaginas = []; renderPaginas(); } } }, 'Descartar tudo')));
}

const rotuloEstado = (j) => ({ processando: 'Processando…', conferir: 'Conferir', salvando: 'Salvando…', salvo: 'Salvo ✓', erro: 'Erro' }[j.estado] || j.estado);

function finalizar() {
  const ps = app.sessaoPaginas;
  if (!ps.length) return;
  jobDePaginas(ps, `Documento ${new Date().toLocaleTimeString('pt-BR')} (${ps.length} pág.)`);
  app.sessaoPaginas = [];
  renderPaginas();
  toast('Documento enviado para leitura. Acompanhe em Conferência.', 'ok');
}

function mover(i, d) {
  const ps = app.sessaoPaginas;
  const [p] = ps.splice(i, 1);
  ps.splice(i + d, 0, p);
  renderPaginas();
}

async function girar(i) {
  const p = app.sessaoPaginas[i];
  const c = await jpegParaCanvas(p.jpeg);
  const r = document.createElement('canvas');
  r.width = c.height; r.height = c.width;
  const ctx = r.getContext('2d');
  ctx.translate(r.width, 0); ctx.rotate(Math.PI / 2); ctx.drawImage(c, 0, 0);
  const blob = await new Promise((res) => r.toBlob(res, 'image/jpeg', 0.85));
  p.jpeg = new Uint8Array(await blob.arrayBuffer());
  p.width = r.width; p.height = r.height;
  URL.revokeObjectURL(p.url);
  p.url = URL.createObjectURL(blob);
  p.raw = null; // a imagem original deixou de corresponder à página girada
  renderPaginas();
}

async function ajustar(i) {
  const p = app.sessaoPaginas[i];
  const quad = await ajustarBordas(p.raw, p.quad);
  if (!quad) return;
  const nova = await paginaDeImagem(p.raw, { quad });
  nova.id = p.id;
  URL.revokeObjectURL(p.url);
  app.sessaoPaginas[i] = nova;
  renderPaginas();
}

export function ampliar(p) {
  const d = dialogo(h('div', { class: 'dlg-corpo' }, h('img', { src: p.url || p, style: 'width:100%' }),
    h('div', { class: 'dlg-acoes' }, h('button', { class: 'btn', onclick: () => d.close() }, 'Fechar'))), { largo: true });
}

export function pararCamera() { if (camera?.ativa) { camera.parar(); el.vazio.hidden = false; el.disparo.hidden = true; el.btnCam.textContent = 'Ligar câmera'; } }
