// Tela "Configurações": pasta de rede, categorias, regras de setor, imagem e pasta de entrada.
import { app, on, emit } from '../state.js';
import { h, toast, confirmar } from './dom.js';
import { conectar, salvarConfiguracao, recarregarBase } from '../conexao.js';
import { salvarHandle, lerHandle } from '../handles.js';
import { garantirPermissao } from '../storage.js';
import { obterOcr, ocrStatus } from '../ocr.js';
import { QUALIDADES } from '../config.js';

let raiz;

export function montarConfig(container) {
  raiz = container;
  on('conexao', render);
  on('config', render);
  render();
}

const check = (rot, valor, aoMudar) => h('label', { class: 'linha', style: 'gap:8px' }, Object.assign(h('input', { type: 'checkbox', onchange: (e) => aoMudar(e.target.checked) }), { checked: !!valor }), rot);
const campo = (rot, el) => h('label', { class: 'campo' }, h('span', { class: 'rot' }, rot), el);
const entrada = (valor, aoMudar, attrs = {}) => Object.assign(h('input', { type: 'text', oninput: (e) => aoMudar(e.target.value), ...attrs }), { value: valor ?? '' });

async function escolherPasta() {
  if (!window.showDirectoryPicker) return toast('Este navegador não permite acessar pastas. Use o Chrome ou o Edge no computador.', 'erro', 7000);
  try {
    const hdl = await window.showDirectoryPicker({ id: 'base', mode: 'readwrite' });
    await salvarHandle('base', hdl);
    if (await conectar(hdl, { pedirPermissao: true })) toast(`Pasta conectada: ${hdl.name}`, 'ok');
  } catch (e) { if (e.name !== 'AbortError') toast(`Não foi possível usar a pasta: ${e.message}`, 'erro', 7000); }
}

async function reconectar() {
  const hdl = await lerHandle('base');
  if (!hdl) return escolherPasta();
  if (!(await conectar(hdl, { pedirPermissao: true }))) toast('Permissão negada.', 'erro');
}

async function escolherEntrada() {
  try {
    app.entrada = await window.showDirectoryPicker({ id: 'entrada', mode: 'readwrite' });
    await salvarHandle('entrada', app.entrada);
    render();
  } catch (e) { if (e.name !== 'AbortError') toast(e.message, 'erro'); }
}

function salvar(msg = true) {
  salvarConfiguracao().then(() => { if (msg) toast('Configurações salvas.', 'ok', 2000); }).catch((e) => toast(`Erro ao gravar a configuração na pasta: ${e.message}`, 'erro', 7000));
}

function render() {
  if (!raiz) return;
  const c = app.config;
  const set = (k, conv = (v) => v) => (v) => { c[k] = conv(v); };
  const ocr = ocrStatus();

  const catRows = c.categorias.map((cat, i) => h('tr', {},
    h('td', {}, entrada(cat.nome, (v) => { cat.nome = v; }, { 'aria-label': 'Nome' })),
    h('td', {}, entrada(cat.prefixo, (v) => { cat.prefixo = v.toUpperCase(); }, { style: 'width:70px' })),
    h('td', {}, entrada(cat.pasta, (v) => { cat.pasta = v; })),
    h('td', {}, Object.assign(h('input', { type: 'checkbox', title: 'Ler os campos da O.S. neste tipo de documento', onchange: (e) => { cat.extrairOS = e.target.checked; } }), { checked: !!cat.extrairOS })),
    h('td', {}, Object.assign(h('input', { type: 'checkbox', title: 'Categoria ativa', onchange: (e) => { cat.ativa = e.target.checked; } }), { checked: cat.ativa !== false })),
    h('td', {}, h('button', { class: 'btn pequeno', onclick: () => { c.categorias.splice(i, 1); render(); } }, '✕'))));

  const regraRows = c.regrasSetor.map((r, i) => h('tr', {},
    h('td', {}, entrada(r.contem, (v) => { r.contem = v; })), h('td', {}, '→'),
    h('td', {}, entrada(r.setor, (v) => { r.setor = v; })),
    h('td', {}, h('button', { class: 'btn pequeno', onclick: () => { c.regrasSetor.splice(i, 1); render(); } }, '✕'))));

  raiz.replaceChildren(
    h('h1', {}, 'Configurações'),
    h('div', { class: 'cfg-grid' },
      h('div', { class: 'painel', style: 'display:flex; flex-direction:column; gap:10px' },
        h('h2', {}, 'Pasta de armazenamento (rede)'),
        h('p', { class: 'muted', style: 'margin:0; font-size:13px' }, 'Escolha a pasta do servidor onde ficam os PDFs e a base de O.S. (ex.: unidade mapeada ou \\\\servidor\\compartilhamento\\pasta). Tudo é gravado com o seu usuário do Windows.'),
        h('div', {}, app.conectada ? h('span', { class: 'chip ok' }, `Conectada: ${app.pastaNome}`) : h('span', { class: 'chip erro' }, 'Não conectada')),
        h('div', { class: 'linha' },
          h('button', { class: 'btn primario', onclick: escolherPasta }, app.conectada ? 'Trocar pasta…' : 'Escolher pasta…'),
          h('button', { class: 'btn', onclick: reconectar }, 'Reconectar'),
          h('button', { class: 'btn', disabled: !app.conectada, onclick: async () => { try { await app.repo.testarGravacao(); toast('Gravação na pasta funcionando.', 'ok'); } catch (e) { toast(`Falha ao gravar: ${e.message}`, 'erro', 8000); } } }, 'Testar gravação'),
          h('button', { class: 'btn', disabled: !app.conectada, onclick: async () => { await recarregarBase(); toast(`${app.registros.length} O.S. na base.`, 'ok'); } }, 'Recarregar base')),
        campo('Seu nome (aparece no histórico das O.S.)', entrada(app.quem, (v) => { app.quem = v; localStorage.setItem('osscan.quem', v); }, { placeholder: 'Ex.: Rodrigo' }))),

      h('div', { class: 'painel', style: 'display:flex; flex-direction:column; gap:10px' },
        h('h2', {}, 'Captura e imagem'),
        campo('Qualidade / compressão', Object.assign(h('select', { onchange: (e) => { c.qualidade = e.target.value; } }, ...Object.keys(QUALIDADES).map((q) => h('option', { value: q }, { ECO: 'Econômica (arquivos menores)', NORMAL: 'Normal', ALTA: 'Alta (arquivos maiores)' }[q]))), { value: c.qualidade })),
        campo('Filtro padrão', Object.assign(h('select', { onchange: (e) => { c.filtro = e.target.value; } }, h('option', { value: 'color' }, 'Colorido'), h('option', { value: 'gray' }, 'Tons de cinza'), h('option', { value: 'bw' }, 'Preto e branco'), h('option', { value: 'original' }, 'Original')), { value: c.filtro })),
        campo(`Contraste (${c.contraste})`, Object.assign(h('input', { type: 'range', min: '0.8', max: '1.6', step: '0.05', oninput: (e) => { c.contraste = +e.target.value; } }), { value: c.contraste })),
        campo(`Brilho (${c.brilho})`, Object.assign(h('input', { type: 'range', min: '-30', max: '40', step: '1', oninput: (e) => { c.brilho = +e.target.value; } }), { value: c.brilho })),
        campo('Alerta de desfoque (0 desliga; maior = mais exigente)', Object.assign(h('input', { type: 'number', min: '0', max: '2000', oninput: (e) => { c.limiarDesfoque = +e.target.value; } }), { value: c.limiarDesfoque })),
        check('Captura automática quando o documento estiver parado', c.capturaAuto, set('capturaAuto')),
        check('Som ao capturar', c.som, set('som'))),

      h('div', { class: 'painel', style: 'display:flex; flex-direction:column; gap:10px' },
        h('h2', {}, 'Leitura das O.S.'),
        check('Salvar sem conferência quando todos os campos forem lidos com segurança', c.salvarAutomatico, set('salvarAutomatico')),
        h('p', { class: 'muted', style: 'margin:0; font-size:13px' }, 'Desligado (recomendado no início): toda O.S. passa pela tela de Conferência.'),
        campo('Setores (separados por vírgula)', entrada((c.setores || []).join(', '), (v) => { c.setores = v.split(',').map((s) => s.trim().toUpperCase()).filter(Boolean); })),
        h('b', { style: 'font-size:13px' }, 'Regra: área de recepção contém… → setor'),
        h('table', { class: 'cfg-tab' }, h('tbody', {}, regraRows)),
        h('button', { class: 'btn pequeno', onclick: () => { c.regrasSetor.push({ contem: '', setor: '' }); render(); } }, '+ Regra')),

      h('div', { class: 'painel', style: 'display:flex; flex-direction:column; gap:10px; grid-column: 1 / -1' },
        h('h2', {}, 'Categorias de documentos'),
        h('table', { class: 'cfg-tab' },
          h('thead', {}, h('tr', {}, h('th', {}, 'Nome'), h('th', {}, 'Prefixo'), h('th', {}, 'Subpasta'), h('th', {}, 'Ler O.S.'), h('th', {}, 'Ativa'), h('th', {}))),
          h('tbody', {}, catRows)),
        h('div', { class: 'linha' }, h('button', { class: 'btn pequeno', onclick: () => { c.categorias.push({ id: `cat${Date.now().toString(36)}`, nome: 'Nova categoria', prefixo: 'DOC', pasta: 'Nova categoria', extrairOS: false, ativa: true }); render(); } }, '+ Categoria'))),

      h('div', { class: 'painel', style: 'display:flex; flex-direction:column; gap:10px' },
        h('h2', {}, 'Pasta de entrada (scanner multifuncional)'),
        h('p', { class: 'muted', style: 'margin:0; font-size:13px' }, 'Configure o scanner para salvar os PDFs numa pasta; o app lê, extrai os dados e organiza.'),
        h('div', {}, app.entrada ? h('span', { class: 'chip ok' }, `Pasta: ${app.entrada.name}`) : h('span', { class: 'chip' }, 'Não definida')),
        h('button', { class: 'btn', onclick: escolherEntrada }, 'Escolher pasta de entrada…'),
        campo('Depois de salvar, o arquivo original', Object.assign(h('select', { onchange: (e) => { c.entradaApagar = e.target.value; } }, h('option', { value: 'mover' }, 'Mover para a subpasta _processados'), h('option', { value: 'apagar' }, 'Apagar'), h('option', { value: 'manter' }, 'Manter onde está')), { value: c.entradaApagar })),
        check('Monitorar a pasta a cada 20 s enquanto o app estiver aberto', c.monitorarEntrada, set('monitorarEntrada'))),

      h('div', { class: 'painel', style: 'display:flex; flex-direction:column; gap:10px' },
        h('h2', {}, 'Diagnóstico'),
        h('div', {}, 'Acesso a pastas: ', window.showDirectoryPicker ? h('span', { class: 'chip ok' }, 'disponível') : h('span', { class: 'chip erro' }, 'indisponível — use Chrome ou Edge')),
        h('div', {}, 'Leitura por OCR (português): ', ocr.pronto ? h('span', { class: 'chip ok' }, 'pronta') : ocr.erro ? h('span', { class: 'chip erro' }, ocr.erro) : h('span', { class: 'chip' }, 'ainda não carregada')),
        h('button', { class: 'btn', onclick: async () => { try { toast('Carregando o OCR…', 'info', 2000); await obterOcr(); toast('OCR pronto.', 'ok'); render(); } catch (e) { toast(`OCR: ${e.message}`, 'erro', 8000); render(); } } }, 'Carregar OCR agora'))),
    h('div', { class: 'linha', style: 'margin-top:16px' },
      h('button', { class: 'btn primario grande', onclick: () => salvar() }, 'Salvar configurações'),
      h('span', { class: 'muted', style: 'font-size:13px' }, app.conectada ? 'A configuração fica na pasta de rede e vale para todos os computadores.' : 'Sem pasta conectada, a configuração fica só neste computador.')));
}
