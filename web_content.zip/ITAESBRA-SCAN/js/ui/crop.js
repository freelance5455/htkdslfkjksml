// Ajuste manual das bordas: 4 alças arrastáveis sobre a foto original.
import { h, dialogo } from './dom.js';
import { orderQuad } from '../imaging.js';

/** raw = { data, width, height } (RGBA); quad = 4 cantos em pixels. Devolve os cantos ajustados ou null. */
export function ajustarBordas(raw, quad) {
  return new Promise((resolve) => {
    const maxW = Math.min(880, window.innerWidth - 80);
    const k = Math.min(1, maxW / raw.width, (window.innerHeight * 0.65) / raw.height);
    const W = Math.round(raw.width * k), H = Math.round(raw.height * k);
    const base = document.createElement('canvas');
    base.width = raw.width; base.height = raw.height;
    base.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(raw.data.buffer ?? raw.data), raw.width, raw.height), 0, 0);
    const canvas = h('canvas', { width: W, height: H });
    const pts = (quad || [{ x: 0.05, y: 0.05 }, { x: 0.95, y: 0.05 }, { x: 0.95, y: 0.95 }, { x: 0.05, y: 0.95 }].map((p) => ({ x: p.x * raw.width, y: p.y * raw.height })))
      .map((p) => ({ x: p.x * k, y: p.y * k }));
    let arrastando = -1;
    const ctx = canvas.getContext('2d');
    const desenhar = () => {
      ctx.drawImage(base, 0, 0, W, H);
      ctx.beginPath();
      pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
      ctx.closePath();
      ctx.fillStyle = 'rgba(0,230,118,.15)'; ctx.fill();
      ctx.lineWidth = 3; ctx.strokeStyle = '#00e676'; ctx.stroke();
      pts.forEach((p) => { ctx.beginPath(); ctx.arc(p.x, p.y, 11, 0, 7); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = '#b3132b'; ctx.stroke(); });
    };
    const pos = (e) => { const r = canvas.getBoundingClientRect(); return { x: ((e.clientX - r.left) * W) / r.width, y: ((e.clientY - r.top) * H) / r.height }; };
    canvas.addEventListener('pointerdown', (e) => {
      const p = pos(e);
      let melhor = -1, d = 40;
      pts.forEach((q, i) => { const dd = Math.hypot(q.x - p.x, q.y - p.y); if (dd < d) { d = dd; melhor = i; } });
      arrastando = melhor;
      if (melhor >= 0) canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener('pointermove', (e) => {
      if (arrastando < 0) return;
      const p = pos(e);
      pts[arrastando] = { x: Math.max(0, Math.min(W, p.x)), y: Math.max(0, Math.min(H, p.y)) };
      desenhar();
    });
    canvas.addEventListener('pointerup', () => { arrastando = -1; });
    let ok = false;
    const d = dialogo(h('div', { class: 'dlg-corpo' },
      h('h2', {}, 'Ajustar bordas do documento'),
      h('p', { class: 'muted' }, 'Arraste os 4 círculos até os cantos do papel.'),
      h('div', { class: 'crop-area' }, canvas),
      h('div', { class: 'dlg-acoes' },
        h('button', { class: 'btn', onclick: () => d.close() }, 'Cancelar'),
        h('button', { class: 'btn primario', onclick: () => { ok = true; d.close(); } }, 'Aplicar'))),
    { largo: true, aoFechar: () => resolve(ok ? orderQuad(pts.map((p) => ({ x: p.x / k, y: p.y / k }))) : null) });
    desenhar();
  });
}
