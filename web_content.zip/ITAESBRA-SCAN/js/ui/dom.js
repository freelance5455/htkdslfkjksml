export const $ = (sel, raiz = document) => raiz.querySelector(sel);
export const $$ = (sel, raiz = document) => [...raiz.querySelectorAll(sel)];

export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/** Cria elemento: h('button', { class: 'x', onclick: fn }, 'texto', outroNo) */
export function h(tag, attrs = {}, ...filhos) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v === null || v === undefined) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const f of filhos.flat()) if (f !== null && f !== undefined && f !== false) el.append(f.nodeType ? f : document.createTextNode(String(f)));
  return el;
}

export function toast(msg, tipo = 'info', ms = 4000) {
  const box = document.getElementById('toasts');
  const t = h('div', { class: `toast ${tipo}`, role: 'status' }, msg);
  box.append(t);
  setTimeout(() => t.remove(), ms);
}

/** Diálogo modal simples. Devolve a <dialog>; feche com d.close(). */
export function dialogo(conteudo, { largo = false, aoFechar } = {}) {
  const d = h('dialog', { class: largo ? 'largo' : '' }, conteudo);
  d.addEventListener('close', () => { aoFechar?.(); d.remove(); });
  document.body.append(d);
  d.showModal();
  return d;
}

export function confirmar(msg, { ok = 'Confirmar', cancelar = 'Cancelar', perigo = false } = {}) {
  return new Promise((resolve) => {
    let r = false;
    const d = dialogo(h('div', { class: 'dlg-corpo' },
      h('p', {}, msg),
      h('div', { class: 'dlg-acoes' },
        h('button', { class: 'btn', onclick: () => d.close() }, cancelar),
        h('button', { class: `btn ${perigo ? 'perigo' : 'primario'}`, onclick: () => { r = true; d.close(); } }, ok))),
    { aoFechar: () => resolve(r) });
  });
}

export function baixar(nome, bytes, mime = 'application/octet-stream') {
  const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
  const a = h('a', { href: url, download: nome });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

let audio;
export function bip(ok = true) {
  try {
    audio ??= new (window.AudioContext || window.webkitAudioContext)();
    const o = audio.createOscillator(), g = audio.createGain();
    o.frequency.value = ok ? 880 : 300;
    g.gain.value = 0.08;
    o.connect(g); g.connect(audio.destination);
    o.start(); o.stop(audio.currentTime + (ok ? 0.09 : 0.25));
  } catch { /* sem áudio */ }
}
