// Tela "Conferência": confira os dados lidos do documento, corrija o que for preciso e salve.
import { app, categoria, on } from '../state.js';
import { h, toast, confirmar } from './dom.js';
import { nivelConf } from '../extract.js';
import { camposFaltando, toTSV, normalizeOsCode, calcStatus, formatDateBR, todayISO } from '../osmodel.js';
import { salvarJob, descartarJob, reprocessarJob, verificarDuplicada, paginaDeImagem } from '../jobs.js';
import { ajustarBordas } from './crop.js';
import { ampliar } from './scan.js';

let raiz, lista, detalhe;
let selId = null;
let chaveDetalhe = '';

const CAMPOS = [
  { k: 'os', rot: 'N° da O.S.', tipo: 'text', conf: 'os', mono: true },
  { k: 'setor', rot: 'Setor (área que vai tratar)', tipo: 'setor', conf: 'setor' },
  { k: 'equipamento', rot: 'Código da peça / equipamento', tipo: 'text', conf: 'equipamento', mono: true },
  { k: 'dataAbertura', rot: 'Data de abertura', tipo: 'date', conf: 'dataAbertura' },
  { k: 'tipoServico', rot: 'Tipo de serviço solicitado', tipo: 'text', conf: 'tipoServico' },
  { k: 'criticidade', rot: 'Criticidade', tipo: 'text' },
  { k: 'problema', rot: 'Problema (observação da O.S.)', tipo: 'textarea', conf: 'problema', largo: true },
  { k: 'prazo', rot: 'Prazo (opcional)', tipo: 'date' },
  { k: 'solicitante.nome', rot: 'Solicitante', tipo: 'text' },
  { k: 'recepcao.centroTrabalho', rot: 'Centro de trabalho da recepção', tipo: 'text', largo: true },
];

const obter = (o, k) => k.split('.').reduce((a, p) => a?.[p], o) ?? '';
const definir = (o, k, v) => { const ps = k.split('.'); let a = o; ps.slice(0, -1).forEach((p) => { a = a[p] ??= {}; }); a[ps.at(-1)] = v; };

const ROTULO = { processando: 'Processando', conferir: 'Conferir', salvando: 'Salvando', salvo: 'Salvo', erro: 'Erro' };
const CLASSE = { processando: 'info', conferir: 'aviso', salvando: 'info', salvo: 'ok', erro: 'erro' };

export function montarReview(container) {
  raiz = container;
  container.replaceChildren(
    h('h1', {}, 'Conferência'),
    h('div', { class: 'conf-grid' },
      h('div', {}, lista = h('div', { class: 'lista-jobs' }),
        h('div', { class: 'linha', style: 'margin-top:8px' }, h('button', { class: 'btn pequeno', onclick: limparSalvos }, 'Limpar salvos'))),
      detalhe = h('div', { class: 'painel' })));
  on('jobs', atualizar);
  on('registros', () => { chaveDetalhe = ''; atualizar(); });
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'Enter' && !raiz.hidden) { const j = selecionado(); if (j?.estado === 'conferir') salvar(j); }
  });
  atualizar();
}

const selecionado = () => app.jobs.find((j) => j.id === selId);

function atualizar() {
  if (!lista) return;
  if (!selecionado()) selId = (app.jobs.find((j) => j.estado === 'conferir') || app.jobs[0])?.id ?? null;
  lista.replaceChildren(...(app.jobs.length ? app.jobs.map(itemLista) : [h('p', { class: 'muted' }, 'Nada para conferir. Digitalize ou importe documentos.')]));
  const j = selecionado();
  const chave = j ? `${j.id}|${j.estado}|${j.etapa}|${!!j.duplicada}|${j.avisos.length}|${j.erro}` : 'vazio';
  if (chave !== chaveDetalhe) { chaveDetalhe = chave; renderDetalhe(j); }
}

function itemLista(j) {
  const rec = j.record;
  return h('button', { class: 'job', 'aria-current': String(j.id === selId), onclick: () => { selId = j.id; chaveDetalhe = ''; atualizar(); } },
    h('b', {}, rec?.os || j.nome),
    h('small', {}, `${categoria(j.categoriaId)?.nome || ''} · ${j.origem === 'entrada' ? 'pasta de entrada' : j.origem === 'camera' ? 'câmera' : 'arquivo'}`),
    h('div', {}, h('span', { class: `chip ${CLASSE[j.estado]}` }, j.etapa && j.estado === 'processando' ? j.etapa : ROTULO[j.estado])));
}

function limparSalvos() {
  app.jobs = app.jobs.filter((j) => j.estado !== 'salvo');
  atualizar();
}

function renderDetalhe(j) {
  if (!j) { detalhe.replaceChildren(h('p', { class: 'muted' }, 'Selecione um documento.')); return; }
  const cat = categoria(j.categoriaId);
  const topo = h('div', { class: 'linha', style: 'justify-content:space-between; margin-bottom:10px' },
    h('div', {}, h('b', {}, j.nome), ' ', h('span', { class: `chip ${CLASSE[j.estado]}` }, ROTULO[j.estado]),
      h('span', { class: 'muted' }, ` · ${cat?.nome || ''}${j.numPaginas ? ` · ${j.numPaginas} pág.` : ''}`)),
    h('button', { class: 'btn pequeno perigo', onclick: () => { descartarJob(j); } }, 'Descartar'));
  const corpo = [topo];
  if (j.estado === 'processando' || j.estado === 'salvando') {
    corpo.push(h('p', {}, j.etapa || (j.estado === 'salvando' ? 'Gravando na pasta…' : 'Processando…')));
  }
  if (j.erro) corpo.push(h('div', { class: 'alerta erro' }, j.erro, ' ',
    !j.naOutbox && j.estado === 'erro' && j.pdfBytes ? h('button', { class: 'btn pequeno', onclick: () => salvar(j) }, 'Tentar salvar de novo') : null));
  if (j.estado === 'salvo') {
    corpo.push(h('div', { class: 'alerta info' }, `Salvo em: ${j.caminho}`, j.atualizada ? ' (cadastro da O.S. atualizado)' : ''));
  }
  if (j.record && j.estado !== 'processando') corpo.push(...formulario(j));
  else if (j.previewUrl) corpo.push(h('div', { class: 'preview', style: 'max-width:360px' }, h('img', { src: j.previewUrl, alt: 'Documento', onclick: () => ampliar(j.previewUrl) })));
  detalhe.replaceChildren(...corpo);
}

function formulario(j) {
  const rec = j.record;
  const conf = j.extracao?.conf || {};
  const editaveis = j.estado === 'conferir' || j.estado === 'erro';
  const avisos = [...new Set(j.avisos)].map((a) => h('div', { class: 'alerta' }, a));
  if (j.duplicada) {
    const d = j.duplicada;
    avisos.unshift(h('div', { class: 'alerta erro' }, h('b', {}, `A O.S. ${d.os} já está cadastrada`),
      ` (aberta em ${formatDateBR(d.dataAbertura) || 's/ data'} · ${calcStatus(d, todayISO()) || 'sem status'}). Ao salvar, o cadastro é atualizado (prazo e conclusão são mantidos) e este PDF é guardado como nova versão do arquivo.`));
  }
  const campos = CAMPOS.map((c) => {
    const nivel = c.conf ? nivelConf(conf[c.k.split('.')[0]] ?? (j.extracao ? undefined : 1)) : 'ok';
    const vazioObrigatorio = ['os', 'setor', 'problema', 'equipamento', 'dataAbertura'].includes(c.k) && !String(obter(rec, c.k)).trim();
    const cls = vazioObrigatorio ? 'corrigir' : (c.conf && j.extracao && nivel !== 'ok' ? nivel : '');
    const onin = (e) => { definir(rec, c.k, e.target.value); e.target.classList.remove('corrigir', 'conferir'); };
    let input;
    if (c.tipo === 'setor') {
      const setores = [...new Set([...(app.config.setores || []), rec.setor].filter(Boolean))];
      input = h('select', { class: cls, disabled: !editaveis, onchange: onin }, h('option', { value: '' }, '— escolha —'),
        ...setores.map((s) => h('option', { value: s, selected: s === rec.setor }, s)));
    } else if (c.tipo === 'textarea') {
      input = h('textarea', { class: cls, disabled: !editaveis, oninput: onin }); input.value = obter(rec, c.k);
    } else {
      input = h('input', { type: c.tipo, class: cls, disabled: !editaveis, style: c.mono ? 'font-family:var(--mono)' : '', oninput: onin });
      input.value = obter(rec, c.k);
      if (c.k === 'os') input.addEventListener('change', async () => {
        const n = normalizeOsCode(input.value); input.value = n.code || input.value; definir(rec, 'os', input.value);
        await verificarDuplicada(j); chaveDetalhe = ''; atualizar();
      });
    }
    const lbl = h('label', { class: `campo${c.largo ? ' largo' : ''}` },
      h('span', { class: 'rot' }, c.rot, c.conf && j.extracao ? h('span', { class: `nivel ${nivel}` }, { ok: 'lido', conferir: 'conferir', corrigir: 'corrigir' }[nivel]) : null), input);
    return lbl;
  });
  const acoes = h('div', { class: 'linha', style: 'margin-top:12px' },
    h('button', { class: 'btn primario grande', disabled: !editaveis || j.estado === 'salvando', onclick: () => salvar(j) }, j.duplicada ? 'Atualizar e salvar (Ctrl+Enter)' : 'Salvar (Ctrl+Enter)'),
    h('button', { class: 'btn', title: 'Copia a linha na ordem das colunas da planilha de controle', onclick: () => copiar(j) }, 'Copiar linha p/ planilha'),
    j.paginas[0]?.raw ? h('button', { class: 'btn', onclick: () => ajustar(j) }, 'Ajustar bordas') : null,
    h('button', { class: 'btn', onclick: () => reprocessarJob(j) }, 'Reler documento'));
  const texto = j.extracao?.rawText ? h('details', { style: 'margin-top:10px' }, h('summary', {}, 'Texto lido do documento'), h('pre', { style: 'white-space:pre-wrap; font:12px var(--mono); max-height:220px; overflow:auto' }, j.extracao.rawText)) : null;
  return [
    ...avisos,
    h('div', { class: 'conf-corpo' },
      h('div', { class: 'preview' }, h('img', { src: j.previewUrl, alt: 'Documento digitalizado', onclick: () => ampliar(j.previewUrl) })),
      h('div', {}, h('div', { class: 'form-os' }, campos), acoes, texto)),
  ];
}

async function copiar(j) {
  try { await navigator.clipboard.writeText(toTSV([j.record])); toast('Linha copiada. Cole na planilha (Ctrl+V) na primeira célula da linha.', 'ok'); }
  catch { toast('O navegador não permitiu copiar.', 'erro'); }
}

async function ajustar(j) {
  const p = j.paginas[0];
  const quad = await ajustarBordas(p.raw, p.quad);
  if (!quad) return;
  const nova = await paginaDeImagem(p.raw, { quad });
  j.paginas[0] = nova;
  j.avisos = [];
  reprocessarJob(j);
}

async function salvar(j) {
  const rec = j.record;
  if (categoria(j.categoriaId).extrairOS) {
    if (!String(rec.os).trim()) return toast('Informe o N° da O.S.', 'erro');
    const falta = camposFaltando(rec);
    if (falta.length) {
      const nomes = { os: 'N° da O.S. fora do padrão OSN#######', setor: 'setor', problema: 'problema', equipamento: 'equipamento', dataAbertura: 'data de abertura' };
      if (!(await confirmar(`Atenção: ${falta.map((f) => nomes[f]).join(', ')}. Salvar mesmo assim?`, { ok: 'Salvar assim mesmo' }))) return;
    }
  }
  try {
    await salvarJob(j);
    toast(j.atualizada ? 'Cadastro da O.S. atualizado.' : 'Salvo.', 'ok');
    const prox = app.jobs.find((x) => x.estado === 'conferir');
    if (prox) selId = prox.id;
    chaveDetalhe = '';
    atualizar();
  } catch (e) {
    toast(String(e.message || e), 'erro', 8000);
    chaveDetalhe = '';
    atualizar();
  }
}
