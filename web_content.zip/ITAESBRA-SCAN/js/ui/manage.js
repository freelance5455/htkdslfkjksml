// Tela "Gestão de O.S.": painel, filtros, edição com histórico, exportação e importação da planilha.
import { app, on, emit } from '../state.js';
import { h, toast, dialogo, confirmar, baixar } from './dom.js';
import {
  calcStatus, diasEmAberto, kpis, maisAntigas, STATUS, applyChange, newRecord, normalizeOsCode,
  formatDateBR, toTSV, todayISO, dayNumber, camposFaltando,
} from '../osmodel.js';
import { ConflictError } from '../storage.js';
import { recarregarBase } from '../conexao.js';
import { DIR_EXPORT } from '../config.js';
import { exportarPlanilha, importarPlanilha } from '../xlsx.js';

let raiz, kpiBox, barra, tabelaBox, infoBox;
const filtro = { texto: '', setor: '', status: '', de: '', ate: '' };
let ordem = { col: 'dataAbertura', dir: 1 };
let limite = 300;

const COR = {
  [STATUS.ANDAMENTO]: '#1f5f99', [STATUS.ATRASADO]: '#b3132b', [STATUS.AG_PRAZO]: '#d9702a',
  [STATUS.PLANEJAMENTO]: '#c9a100', [STATUS.CONCLUIDO]: '#1f7a3d', [STATUS.CANCELADO]: '#8b979c',
};
const classeStatus = (s) => `st st-${s.replace(/[^A-ZÇÃÁÉÍÓÚ]/g, '')}`;

export function montarGestao(container) {
  raiz = container;
  container.replaceChildren(
    h('h1', {}, 'Gestão de O.S.'),
    kpiBox = h('div', { class: 'kpis' }),
    infoBox = h('div', { class: 'indice' }),
    barra = h('div', { class: 'barra' }),
    tabelaBox = h('div'));
  montarBarra();
  on('registros', render);
  on('conexao', render);
  render();
}

function montarBarra() {
  const set = (k) => (e) => { filtro[k] = e.target.value; limite = 300; render(); };
  barra.replaceChildren(
    h('input', { type: 'search', placeholder: 'Buscar O.S., problema, equipamento…', 'aria-label': 'Buscar', oninput: set('texto') }),
    h('select', { 'aria-label': 'Setor', onchange: set('setor') }, h('option', { value: '' }, 'Todos os setores'), ...(app.config.setores || []).map((s) => h('option', { value: s }, s))),
    h('select', { 'aria-label': 'Status', id: 'f-status', onchange: set('status') }, h('option', { value: '' }, 'Todos os status'), ...Object.values(STATUS).map((s) => h('option', { value: s }, s))),
    h('label', { class: 'linha', style: 'gap:4px; font-size:13px' }, 'de', h('input', { type: 'date', style: 'width:auto', onchange: set('de') })),
    h('label', { class: 'linha', style: 'gap:4px; font-size:13px' }, 'até', h('input', { type: 'date', style: 'width:auto', onchange: set('ate') })),
    h('span', { style: 'flex:1' }),
    h('button', { class: 'btn', onclick: nova }, '+ Nova O.S.'),
    h('button', { class: 'btn', onclick: copiarFiltradas }, 'Copiar linhas'),
    h('button', { class: 'btn', onclick: abrirImportar }, 'Importar planilha…'),
    h('button', { class: 'btn primario', onclick: exportar }, 'Exportar planilha (.xlsx)'),
    h('button', { class: 'btn', onclick: atualizarBase }, 'Atualizar'));
}

async function atualizarBase() {
  if (!app.conectada) return toast('Conecte a pasta em Configurações.', 'aviso');
  try { await recarregarBase(); toast(`${app.registros.length} O.S. carregadas.`, 'ok', 2000); } catch (e) { toast(`Erro ao ler a pasta: ${e.message}`, 'erro'); }
}

function linhas() {
  const hoje = todayISO();
  const t = filtro.texto.trim().toUpperCase();
  const rs = app.registros.map((r) => ({ r, status: calcStatus(r, hoje), dias: diasEmAberto(r, hoje) }))
    .filter(({ r, status }) =>
      (!filtro.setor || r.setor === filtro.setor) && (!filtro.status || status === filtro.status) &&
      (!filtro.de || (r.dataAbertura && r.dataAbertura >= filtro.de)) && (!filtro.ate || (r.dataAbertura && r.dataAbertura <= filtro.ate)) &&
      (!t || `${r.os} ${r.problema} ${r.equipamento} ${r.tipoServico} ${r.setor}`.toUpperCase().includes(t)));
  const v = (x) => (ordem.col === 'status' ? x.status : ordem.col === 'dias' ? (x.dias ?? -1) : (x.r[ordem.col] ?? ''));
  rs.sort((a, b) => (v(a) > v(b) ? 1 : v(a) < v(b) ? -1 : 0) * ordem.dir);
  return rs;
}

function render() {
  if (!kpiBox) return;
  const hoje = todayISO();
  const k = kpis(app.registros, hoje);
  kpiBox.replaceChildren(
    ...Object.values(STATUS).map((s) => h('button', {
      class: 'kpi', style: `--c:${COR[s]}`, 'aria-pressed': String(filtro.status === s),
      onclick: () => { filtro.status = filtro.status === s ? '' : s; const sel = document.getElementById('f-status'); if (sel) sel.value = filtro.status; limite = 300; render(); },
    }, h('b', {}, k.porStatus[s]), h('span', {}, s))),
    h('div', { class: 'kpi', style: '--c:#1c2226; cursor:default' }, h('b', {}, k.total), h('span', {}, 'Total de O.S.')));
  const setores = Object.keys(k.indice);
  infoBox.replaceChildren(
    h('span', {}, 'Índice de entrega: ', ...setores.map((s) => h('span', {}, `${s} `, h('b', {}, `${(k.indice[s] * 100).toFixed(1)}%`), '  · ')), h('b', {}, `Geral ${(k.indiceGeral * 100).toFixed(1)}%`)),
    h('span', {}, `Base: ${app.pastaNome ? app.pastaNome : 'pasta não conectada'}`, app.baseInfo.erros.length ? ` · ${app.baseInfo.erros.length} arquivo(s) ilegíveis` : ''));

  if (!app.registros.length) {
    tabelaBox.replaceChildren(h('div', { class: 'painel' },
      h('p', {}, app.conectada ? 'A base ainda está vazia. Digitalize O.S. ou importe sua planilha de controle.' : 'Conecte a pasta de armazenamento em Configurações para ver e gerenciar as O.S.')));
    return;
  }
  const rs = linhas();
  const th = (rot, col) => h('th', { onclick: () => { ordem = { col, dir: ordem.col === col ? -ordem.dir : 1 }; render(); }, title: 'Ordenar' },
    rot + (ordem.col === col ? (ordem.dir > 0 ? ' ▲' : ' ▼') : ''));
  tabelaBox.replaceChildren(
    h('div', { class: 'muted', style: 'font-size:13px; margin-bottom:4px' }, `${rs.length} de ${app.registros.length} O.S.`),
    h('div', { class: 'tabela-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, th('N° O.S.', 'os'), th('Setor', 'setor'), th('Problema', 'problema'), th('Equipamento', 'equipamento'),
        th('Abertura', 'dataAbertura'), th('Prazo', 'prazo'), th('C/X', 'cx'), th('Status', 'status'), th('Dias', 'dias'), h('th', {}, 'PDF'))),
      h('tbody', {}, rs.slice(0, limite).map(({ r, status, dias }) => h('tr', { onclick: () => editar(r) },
        h('td', { class: 'cod' }, r.os), h('td', {}, r.setor), h('td', { class: 'prob' }, r.problema), h('td', { class: 'cod' }, r.equipamento),
        h('td', {}, formatDateBR(r.dataAbertura)), h('td', {}, formatDateBR(r.prazo)), h('td', {}, r.cx),
        h('td', {}, status ? h('span', { class: classeStatus(status) }, status) : ''), h('td', {}, dias ?? ''),
        h('td', {}, r.arquivoPdf ? '📄' : '')))))),
    rs.length > limite ? h('p', {}, h('button', { class: 'btn', onclick: () => { limite += 500; render(); } }, `Mostrar mais (${rs.length - limite} restantes)`)) : null);
}

// ---------------------------------------------------------------- edição

export async function abrirPdfSalvo(caminho) {
  try {
    const partes = caminho.split('/');
    const f = await app.repo.ler(partes.slice(0, -1), partes.at(-1));
    window.open(URL.createObjectURL(f), '_blank');
  } catch (e) { toast(`Não foi possível abrir o PDF: ${e.message}`, 'erro'); }
}

function nova() {
  if (!app.conectada) return toast('Conecte a pasta em Configurações.', 'aviso');
  editar(newRecord({ origem: 'manual', dataAbertura: todayISO() }), true);
}

function editar(rec, ehNova = false) {
  if (!app.conectada) return toast('Conecte a pasta em Configurações.', 'aviso');
  const f = {};
  const campo = (k, rot, tipo = 'text', extra = {}) => h('label', { class: `campo${extra.largo ? ' largo' : ''}`, style: extra.largo ? 'grid-column:1/-1' : '' }, h('span', { class: 'rot' }, rot),
    tipo === 'textarea' ? (f[k] = Object.assign(h('textarea', {}), { value: rec[k] || '' }))
      : tipo === 'setor' ? (f[k] = h('select', {}, h('option', { value: '' }, '— escolha —'), ...[...new Set([...(app.config.setores || []), rec.setor].filter(Boolean))].map((s) => h('option', { value: s, selected: s === rec.setor }, s))))
        : tipo === 'cx' ? (f[k] = h('select', {}, h('option', { value: '' }, 'Em aberto'), h('option', { value: '✓', selected: rec.cx === '✓' }, '✓ Concluída'), h('option', { value: '❌', selected: rec.cx === '❌' }, '❌ Cancelada')))
          : (f[k] = Object.assign(h('input', { type: tipo, ...(extra.ro ? { readonly: true } : {}) }), { value: rec[k] || '' })));
  const info = [
    ['Criticidade', rec.criticidade], ['Solicitante', [rec.solicitante?.matricula, rec.solicitante?.nome].filter(Boolean).join(' - ')],
    ['Recepção', rec.recepcao?.centroTrabalho], ['Hora de abertura', rec.horaAbertura], ['Origem do cadastro', rec.origem],
  ].filter(([, v]) => v);
  const hist = (rec.historico || []).slice().reverse().map((x) => `${(x.quando || '').replace('T', ' ').slice(0, 16)} · ${x.quem || '—'} · ${x.campo}: ${x.de ? `"${x.de}" → ` : ''}"${x.para}"`);
  const d = dialogo(h('div', { class: 'dlg-corpo' },
    h('h2', {}, ehNova ? 'Nova O.S.' : `O.S. ${rec.os}`, ' ', ehNova ? '' : h('span', { class: classeStatus(calcStatus(rec) || '—') }, calcStatus(rec))),
    h('div', { class: 'dois-cols' },
      campo('os', 'N° da O.S.', 'text', { ro: !ehNova }), campo('setor', 'Setor', 'setor'),
      campo('equipamento', 'Código da peça / equipamento'), campo('dataAbertura', 'Data de abertura', 'date'),
      campo('prazo', 'Prazo', 'date'), campo('cx', 'Situação (C/X)', 'cx'),
      campo('tipoServico', 'Tipo de serviço solicitado', 'text', { largo: true }),
      campo('problema', 'Problema', 'textarea', { largo: true }), campo('observacoes', 'Observações de gestão', 'textarea', { largo: true })),
    info.length ? h('div', { class: 'muted', style: 'font-size:13px' }, info.map(([k, v]) => h('div', {}, `${k}: `, h('b', {}, v)))) : null,
    hist.length ? h('div', {}, h('b', {}, 'Histórico'), h('div', { class: 'hist' }, hist.map((x) => h('div', {}, x)))) : null,
    h('div', { class: 'dlg-acoes' },
      rec.arquivoPdf ? h('button', { class: 'btn', onclick: () => abrirPdfSalvo(rec.arquivoPdf) }, 'Abrir PDF') : null,
      h('button', { class: 'btn', onclick: () => d.close() }, 'Fechar'),
      h('button', { class: 'btn primario', onclick: async () => { if (await salvarEdicao(rec, f, ehNova)) d.close(); } }, 'Salvar'))), { largo: true });
}

async function salvarEdicao(rec, f, ehNova) {
  const val = (k) => f[k].value.trim();
  const mudancas = {
    setor: val('setor'), equipamento: val('equipamento').toUpperCase(), dataAbertura: val('dataAbertura'), prazo: val('prazo'),
    cx: val('cx'), tipoServico: val('tipoServico'), problema: val('problema').replace(/\s+/g, ' '), observacoes: val('observacoes'),
  };
  try {
    if (ehNova) {
      const n = normalizeOsCode(val('os'));
      if (!n.code) { toast('Informe o N° da O.S.', 'erro'); return false; }
      const novo = applyChange({ ...rec, os: n.code, historico: [] }, mudancas, app.quem);
      novo.historico.unshift({ quando: new Date().toISOString(), quem: app.quem, campo: 'registro', de: '', para: 'criado manualmente' });
      novo.rev = 1;
      await app.repo.salvarOS(novo, { expectedRev: 0 });
      app.registros.push(novo);
    } else {
      const novo = applyChange(rec, mudancas, app.quem);
      if (novo.rev === rec.rev + 1 && novo.historico.length === (rec.historico || []).length) { toast('Nada foi alterado.', 'info'); return true; }
      await app.repo.salvarOS(novo, { expectedRev: rec.rev });
      const i = app.registros.findIndex((x) => x.os === rec.os);
      app.registros[i] = novo;
    }
    emit('registros');
    toast('O.S. salva.', 'ok', 2000);
    return true;
  } catch (e) {
    if (e instanceof ConflictError) {
      toast(`${e.message} Os dados foram recarregados — abra a O.S. de novo e refaça a alteração.`, 'erro', 9000);
      if (e.atual) { const i = app.registros.findIndex((x) => x.os === e.atual.os); if (i >= 0) app.registros[i] = e.atual; else app.registros.push(e.atual); emit('registros'); }
    } else toast(`Não foi possível salvar: ${e.message}`, 'erro', 8000);
    return false;
  }
}

// ---------------------------------------------------------------- exportar / copiar / importar

async function copiarFiltradas() {
  const rs = linhas().map((x) => x.r);
  if (!rs.length) return toast('Nada para copiar.', 'aviso');
  try { await navigator.clipboard.writeText(toTSV(rs, todayISO())); toast(`${rs.length} linha(s) copiadas na ordem das colunas da planilha.`, 'ok'); } catch { toast('O navegador não permitiu copiar.', 'erro'); }
}

async function exportar() {
  if (!app.registros.length) return toast('Não há O.S. para exportar.', 'aviso');
  try {
    const hoje = todayISO();
    const bytes = await exportarPlanilha(linhasOuTodas(), { today: hoje });
    const hh = new Date().toTimeString().slice(0, 5).replace(':', '');
    const nome = `CONTROLE_OS_${hoje}_${hh}.xlsx`;
    let onde = '';
    if (app.conectada) { const r = await app.repo.gravar(DIR_EXPORT, nome, bytes, { unique: true }); onde = ` Cópia gravada em ${r.caminho}.`; }
    baixar(nome, bytes, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    toast(`Planilha gerada com ${app.registros.length} O.S.${onde}`, 'ok', 7000);
  } catch (e) { toast(`Erro ao exportar: ${e.message}`, 'erro', 8000); }
}
const linhasOuTodas = () => app.registros;

function abrirImportar() {
  if (!app.conectada) return toast('Conecte a pasta em Configurações.', 'aviso');
  const inp = h('input', { type: 'file', accept: '.xlsx', hidden: true, onchange: async (e) => { const f = e.target.files[0]; if (f) await prever(f); } });
  document.body.append(inp);
  inp.click();
  setTimeout(() => inp.remove(), 60000);
}

async function prever(file) {
  try {
    const r = await importarPlanilha(await file.arrayBuffer());
    const existentes = new Set(app.registros.map((x) => x.os));
    const novas = r.records.filter((x) => !existentes.has(x.os));
    const d = dialogo(h('div', { class: 'dlg-corpo' },
      h('h2', {}, 'Importar planilha de controle'),
      h('p', {}, `${r.linhas} linhas lidas → ${r.unicas} O.S. únicas. `, h('b', {}, `${novas.length} novas`), `, ${r.unicas - novas.length} já estão na base (não serão alteradas).`),
      h('div', { class: 'alerta info' }, `${r.avisos.length} ponto(s) de atenção encontrados (códigos fora do padrão, linhas repetidas, setores conflitantes). Eles ficam registrados nas "Observações de gestão" de cada O.S.`),
      h('div', { class: 'hist', style: 'max-height:220px' }, r.avisos.slice(0, 80).map((a) => h('div', {}, `Linha ${a.linha} · ${a.os} · ${a.msg}`))),
      h('div', { class: 'dlg-acoes' },
        h('button', { class: 'btn', onclick: () => d.close() }, 'Cancelar'),
        h('button', { class: 'btn primario', disabled: !novas.length, onclick: async () => { d.close(); await gravarImportadas(novas); } }, `Importar ${novas.length} novas`))), { largo: true });
  } catch (e) { toast(`Não foi possível ler a planilha: ${e.message}`, 'erro', 8000); }
}

async function gravarImportadas(novas) {
  let ok = 0, falhas = 0;
  toast(`Importando ${novas.length} O.S.…`, 'info', 2500);
  for (let i = 0; i < novas.length; i += 8) {
    await Promise.all(novas.slice(i, i + 8).map(async (r) => {
      try { await app.repo.salvarOS(r, { expectedRev: 0 }); app.registros.push(r); ok++; } catch { falhas++; }
    }));
  }
  emit('registros');
  toast(`Importação concluída: ${ok} gravadas${falhas ? `, ${falhas} não gravadas (já existiam ou erro)` : ''}.`, falhas ? 'aviso' : 'ok', 7000);
}
