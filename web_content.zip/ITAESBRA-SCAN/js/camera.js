// Câmera (webcam do computador ou câmera do celular) com detecção da folha em tempo real
// e captura automática quando o documento está enquadrado e parado.
import { detectQuad } from './imaging.js';

const ESTAVEL_QUADROS = 7;
const TOLERANCIA_MOVIMENTO = 0.025;
const TROCA_DE_FOLHA = 0.10;
const AREA_MINIMA = 0.2;
const INTERVALO_MS = 150;
const RECARGA_MS = 1500;

const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const maxDist = (qa, qb) => Math.max(...qa.map((p, i) => dist(p, qb[i])));

export class Camera {
  constructor(video, overlay, { aoEstavel, aoQuadro } = {}) {
    this.video = video;
    this.overlay = overlay;
    this.aoEstavel = aoEstavel || (() => {});
    this.aoQuadro = aoQuadro || (() => {});
    this.stream = null;
    this.timer = null;
    this.auto = true;
    this.ocupada = false;       // captura em andamento
    this.quadAtual = null;      // normalizado (0..1)
    this._prev = null; this._estavel = 0; this._armada = true; this._ausente = 0;
    this._quadCapturado = null; this._ultimoDisparo = 0;
    this._canvasLive = document.createElement('canvas');
  }

  async dispositivos() {
    const l = await navigator.mediaDevices.enumerateDevices();
    return l.filter((d) => d.kind === 'videoinput');
  }

  async iniciar(deviceId = '') {
    this.parar();
    const video = deviceId
      ? { deviceId: { exact: deviceId }, width: { ideal: 1920 }, height: { ideal: 1080 } }
      : { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } };
    this.stream = await navigator.mediaDevices.getUserMedia({ video, audio: false });
    this.video.srcObject = this.stream;
    await this.video.play();
    this.timer = setInterval(() => this._analisar(), INTERVALO_MS);
  }

  parar() {
    clearInterval(this.timer);
    this.timer = null;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    this.video.srcObject = null;
    this._desenhar(null, 0);
  }

  get ativa() { return !!this.stream; }

  async lanterna(ligar) {
    const t = this.stream?.getVideoTracks()[0];
    if (t?.getCapabilities?.().torch) await t.applyConstraints({ advanced: [{ torch: !!ligar }] });
  }

  /** Foto em resolução máxima do vídeo atual → { data, width, height }. */
  capturarQuadro() {
    const v = this.video;
    const c = document.createElement('canvas');
    c.width = v.videoWidth; c.height = v.videoHeight;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(v, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height);
    this.avisarCaptura();
    return { data: d.data, width: d.width, height: d.height, quadNorm: this.quadAtual };
  }

  /** Evita capturas repetidas: só rearma quando a folha sai ou é trocada. */
  avisarCaptura() {
    this._armada = false;
    this._quadCapturado = this.quadAtual;
    this._estavel = 0;
    this._ultimoDisparo = Date.now();
  }

  _analisar() {
    const v = this.video;
    if (!v.videoWidth || this.ocupada) return;
    const k = 320 / Math.max(v.videoWidth, v.videoHeight);
    const w = Math.round(v.videoWidth * k), h = Math.round(v.videoHeight * k);
    const c = this._canvasLive;
    c.width = w; c.height = h;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(v, 0, 0, w, h);
    const img = ctx.getImageData(0, 0, w, h);
    const det = detectQuad(img, { maxSide: 320 });
    const nq = det ? det.quad.map((p) => ({ x: p.x / w, y: p.y / h })) : null;
    this.quadAtual = nq;
    this._rastrear(nq);
    this._desenhar(nq, Math.min(1, this._estavel / ESTAVEL_QUADROS));
    this.aoQuadro(nq);
  }

  _rastrear(nq) {
    const agora = Date.now();
    if (!nq) {
      this._ausente++; this._estavel = 0; this._prev = null;
      if (this._ausente >= 4) this._armada = true;
      return;
    }
    this._ausente = 0;
    const mov = this._prev ? maxDist(this._prev, nq) : 1;
    this._estavel = mov < TOLERANCIA_MOVIMENTO ? this._estavel + 1 : 0;
    this._prev = nq;
    if (!this._armada && (!this._quadCapturado || maxDist(this._quadCapturado, nq) > TROCA_DE_FOLHA)) this._armada = true;
    const area = Math.abs(nq.reduce((s, p, i) => { const q = nq[(i + 1) % 4]; return s + p.x * q.y - q.x * p.y; }, 0)) / 2;
    if (this.auto && this._armada && this._estavel >= ESTAVEL_QUADROS && area >= AREA_MINIMA && agora - this._ultimoDisparo > RECARGA_MS) {
      this._armada = false;
      this._quadCapturado = nq;
      this._ultimoDisparo = agora;
      this._estavel = 0;
      this.aoEstavel();
    }
  }

  _desenhar(nq, progresso) {
    const o = this.overlay;
    const r = o.getBoundingClientRect();
    if (o.width !== Math.round(r.width) || o.height !== Math.round(r.height)) { o.width = Math.round(r.width); o.height = Math.round(r.height); }
    const ctx = o.getContext('2d');
    ctx.clearRect(0, 0, o.width, o.height);
    if (!nq || !this.video.videoWidth) return;
    // o vídeo usa object-fit: contain; mapeia coordenadas normalizadas para a área realmente exibida
    const va = this.video.videoWidth / this.video.videoHeight, oa = o.width / o.height;
    let dw = o.width, dh = o.height, ox = 0, oy = 0;
    if (va > oa) { dh = o.width / va; oy = (o.height - dh) / 2; } else { dw = o.height * va; ox = (o.width - dw) / 2; }
    ctx.beginPath();
    nq.forEach((p, i) => { const x = ox + p.x * dw, y = oy + p.y * dh; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
    ctx.closePath();
    const cor = progresso >= 1 ? '0,230,118' : '255,193,7';
    ctx.fillStyle = `rgba(${cor},0.18)`; ctx.fill();
    ctx.lineWidth = 4; ctx.strokeStyle = `rgb(${cor})`; ctx.stroke();
    if (progresso > 0 && progresso < 1) {
      ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.fillRect(ox + 12, oy + dh - 16, (dw - 24) * progresso, 5);
    }
  }
}
