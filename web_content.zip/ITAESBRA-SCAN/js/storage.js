// Acesso à pasta escolhida pelo usuário (File System Access API: Chrome/Edge).
// Tudo que é gravado na rede passa por aqui. Funciona com qualquer objeto que siga a API de
// FileSystemDirectoryHandle — por isso é testado no Node com um sistema de arquivos falso.
import { DIR_OS, DIR_CONFIG, mesclarConfig } from './config.js';

export class ConflictError extends Error {
  constructor(atual, msg = 'O registro foi alterado por outra pessoa.') {
    super(msg);
    this.name = 'ConflictError';
    this.atual = atual;
  }
}

export async function garantirPermissao(handle, mode = 'readwrite') {
  const opts = { mode };
  if ((await handle.queryPermission?.(opts)) === 'granted') return true;
  return (await handle.requestPermission?.(opts)) === 'granted';
}

export class Repo {
  constructor(root) {
    this.root = root;
  }

  async dir(parts, create = false) {
    let d = this.root;
    for (const p of parts) d = await d.getDirectoryHandle(p, { create });
    return d;
  }

  async existe(parts, nome) {
    try {
      const d = await this.dir(parts);
      await d.getFileHandle(nome);
      return true;
    } catch (e) {
      if (e?.name === 'NotFoundError' || e?.name === 'TypeMismatchError') return false;
      throw e;
    }
  }

  async listar(parts) {
    let d;
    try { d = await this.dir(parts); } catch (e) { if (e?.name === 'NotFoundError') return []; throw e; }
    const out = [];
    for await (const [name, h] of d.entries()) out.push({ name, kind: h.kind, handle: h });
    return out;
  }

  /** Grava bytes. Com unique=true, nunca sobrescreve: acrescenta _2, _3... ao nome. */
  async gravar(parts, nome, bytes, { unique = false } = {}) {
    const d = await this.dir(parts, true);
    let final = nome;
    if (unique) {
      const dot = nome.lastIndexOf('.');
      const base = dot > 0 ? nome.slice(0, dot) : nome;
      const ext = dot > 0 ? nome.slice(dot) : '';
      for (let i = 2; await this._existeEm(d, final); i++) final = `${base}_${i}${ext}`;
    }
    const fh = await d.getFileHandle(final, { create: true });
    const w = await fh.createWritable();
    await w.write(bytes);
    await w.close();
    const f = await fh.getFile();
    const esperado = bytes.byteLength ?? bytes.size ?? bytes.length;
    if (f.size !== esperado) throw new Error(`Falha ao gravar "${final}": tamanho gravado ${f.size} difere de ${esperado}.`);
    return { nome: final, caminho: [...parts, final].join('/') };
  }

  async _existeEm(d, nome) {
    try { await d.getFileHandle(nome); return true; } catch (e) {
      if (e?.name === 'NotFoundError') return false;
      throw e;
    }
  }

  async ler(parts, nome) {
    const d = await this.dir(parts);
    const fh = await d.getFileHandle(nome);
    return fh.getFile();
  }

  async lerJson(parts, nome) {
    try {
      const f = await this.ler(parts, nome);
      return JSON.parse(await f.text());
    } catch (e) {
      if (e?.name === 'NotFoundError') return null;
      throw e;
    }
  }

  async gravarJson(parts, nome, obj) {
    return this.gravar(parts, nome, new TextEncoder().encode(JSON.stringify(obj, null, 2)));
  }

  async remover(parts, nome) {
    const d = await this.dir(parts);
    await d.removeEntry(nome);
  }

  // ------------------------------------------------------------------ banco de O.S.

  async carregarOS(codigo) {
    return this.lerJson(DIR_OS, `${codigo}.json`);
  }

  /** Concorrência otimista: expectedRev=0 exige que o registro ainda não exista. */
  async salvarOS(rec, { expectedRev = null } = {}) {
    const atual = await this.carregarOS(rec.os);
    if (expectedRev !== null) {
      if (expectedRev === 0 && atual) throw new ConflictError(atual, `A O.S. ${rec.os} já está cadastrada.`);
      if (expectedRev > 0 && atual && atual.rev !== expectedRev) throw new ConflictError(atual);
    }
    await this.gravarJson(DIR_OS, `${rec.os}.json`, rec);
    return rec;
  }

  /** Lê todos os registros (em lotes, para não sobrecarregar a rede). */
  async listarOS(onProgress = () => {}) {
    const itens = (await this.listar(DIR_OS)).filter((e) => e.kind === 'file' && e.name.toLowerCase().endsWith('.json'));
    const out = [];
    const erros = [];
    for (let i = 0; i < itens.length; i += 16) {
      await Promise.all(itens.slice(i, i + 16).map(async (e) => {
        try { out.push(JSON.parse(await (await e.handle.getFile()).text())); } catch (err) { erros.push({ arquivo: e.name, erro: String(err.message || err) }); }
      }));
      onProgress(Math.min(itens.length, i + 16), itens.length);
    }
    out.sort((a, b) => (a.dataAbertura || '').localeCompare(b.dataAbertura || '') || a.os.localeCompare(b.os));
    return { registros: out, erros };
  }

  // ------------------------------------------------------------------ configuração compartilhada

  async carregarConfig() {
    return mesclarConfig((await this.lerJson(DIR_CONFIG, 'config.json')) || {});
  }

  async salvarConfig(cfg) {
    return this.gravarJson(DIR_CONFIG, 'config.json', cfg);
  }

  /** Teste de gravação usado em Configurações. */
  async testarGravacao() {
    const nome = `_teste_${Date.now()}.tmp`;
    await this.gravar(DIR_CONFIG, nome, new TextEncoder().encode('ok'));
    await this.remover(DIR_CONFIG, nome);
    return true;
  }
}
