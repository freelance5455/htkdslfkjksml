// Exportação e importação da planilha de controle (usa ExcelJS, carregado como global).
import { STATUS, STATUS_ABERTOS, calcStatus, kpis, maisAntigas, normalizeOsCode, normalizeEquip, newRecord, dayNumber, todayISO } from './osmodel.js';
import { TITULO_PLANILHA } from './config.js';

const ABA = 'CONTROLE DE ORDENS DE SERVIÇO';
const ULTIMA = 5000; // intervalo das fórmulas do painel
const FONTE = 'Arial';

const iso2date = (iso) => (dayNumber(iso) === null ? null : new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10))));
const fill = (argb) => ({ type: 'pattern', pattern: 'solid', fgColor: { argb }, bgColor: { argb } });

const CORES_STATUS = {
  [STATUS.CONCLUIDO]: ['FFC6EFCE', 'FF006100'],
  [STATUS.ATRASADO]: ['FFFFC7CE', 'FF9C0006'],
  [STATUS.ANDAMENTO]: ['FFBDD7EE', 'FF1F4E78'],
  [STATUS.AG_PRAZO]: ['FFFCE4D6', 'FF843C0C'],
  [STATUS.PLANEJAMENTO]: ['FFFFEB9C', 'FF7F6000'],
  [STATUS.CANCELADO]: ['FFD9D9D9', 'FF404040'],
};

/**
 * Gera a planilha no mesmo formato da "CONTROLE DE ORDENS DE SERVIÇO": colunas B a I
 * (N° DA O.S., SETOR, PROBLEMA, ÁREA/MÁQUINA/PRODUTO, DATA DE ABERTURA, PRAZO, C/X, STATUS),
 * STATUS por fórmula (recalcula sozinho com a data de hoje) e uma aba DASHBOARD com fórmulas.
 * Colunas extras (tipo de serviço, criticidade, solicitante, PDF...) ficam depois do ID.
 */
export async function exportarPlanilha(records, { today = todayISO(), titulo = TITULO_PLANILHA, ExcelJS = globalThis.ExcelJS } = {}) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'ITAESBRA SCAN';
  wb.created = new Date();
  const ws = wb.addWorksheet(ABA, { views: [{ state: 'frozen', ySplit: 3, showGridLines: false }] });
  const colunas = [
    ['A', 1.5], ['B', 16], ['C', 17], ['D', 62], ['E', 20], ['F', 17], ['G', 14], ['H', 7], ['I', 19], ['J', 13],
    ['K', 28], ['L', 24], ['M', 34], ['N', 12], ['O', 36], ['P', 52],
  ];
  colunas.forEach(([c, w]) => { ws.getColumn(c).width = w; });

  ws.mergeCells('B2:I2');
  const t = ws.getCell('B2');
  t.value = titulo;
  t.font = { name: FONTE, bold: true, size: 14, color: { argb: 'FFFFFFFF' } };
  t.fill = fill('FF1C2226');
  t.alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(2).height = 26;

  const cab = ['N° DA O.S.', 'SETOR', 'PROBLEMA', 'ÁREA/MÁQUINA/PRODUTO', 'DATA DE ABERTURA', 'PRAZO', 'C/X', 'STATUS', 'ID',
    'TIPO DE SERVIÇO', 'CRITICIDADE', 'SOLICITANTE', 'HORA ABERTURA', 'ÁREA DE RECEPÇÃO', 'ARQUIVO PDF'];
  cab.forEach((h, i) => {
    const c = ws.getCell(3, 2 + i);
    c.value = h;
    c.font = { name: FONTE, bold: true, color: { argb: 'FFFFFFFF' }, size: 10 };
    c.fill = fill(i < 8 ? 'FF3B4750' : 'FF7A8890');
    c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    c.border = { bottom: { style: 'medium', color: { argb: 'FFB3132B' } } };
  });
  ws.getRow(3).height = 30;

  const ordenados = [...records].sort((a, b) => (a.dataAbertura || '').localeCompare(b.dataAbertura || '') || a.os.localeCompare(b.os));
  ordenados.forEach((r, idx) => {
    const n = 4 + idx;
    const status = calcStatus(r, today);
    const aberta = STATUS_ABERTOS.includes(status);
    const ab = iso2date(r.dataAbertura);
    ws.getCell(`B${n}`).value = r.os;
    ws.getCell(`C${n}`).value = r.setor || null;
    ws.getCell(`D${n}`).value = r.problema || null;
    ws.getCell(`E${n}`).value = r.equipamento || null;
    ws.getCell(`F${n}`).value = ab;
    ws.getCell(`G${n}`).value = iso2date(r.prazo);
    ws.getCell(`H${n}`).value = r.cx || null;
    ws.getCell(`I${n}`).value = {
      formula: `IF(H${n}="❌","CANCELADO",IF(H${n}="✓","CONCLUÍDO",IF(F${n}="","",IF(AND(G${n}<>"",TODAY()>G${n}),"ATRASADO",IF(AND(G${n}<>"",TODAY()<=G${n}),"EM ANDAMENTO...",IF(TODAY()-F${n}>15,"AG. PRAZO","EM PLANEJAMENTO"))))))`,
      result: status,
    };
    ws.getCell(`J${n}`).value = {
      formula: `IF(OR(I${n}="EM ANDAMENTO...",I${n}="ATRASADO",I${n}="AG. PRAZO",I${n}="EM PLANEJAMENTO"),F${n}+ROW()/100000000,"")`,
      result: aberta && ab ? dayNumber(r.dataAbertura) + 25569 + (n / 1e8) : '',
    };
    ws.getCell(`K${n}`).value = r.tipoServico || null;
    ws.getCell(`L${n}`).value = r.criticidade || null;
    ws.getCell(`M${n}`).value = [r.solicitante?.matricula, r.solicitante?.nome].filter(Boolean).join(' - ') || null;
    ws.getCell(`N${n}`).value = r.horaAbertura || null;
    ws.getCell(`O${n}`).value = r.recepcao?.centroTrabalho || null;
    ws.getCell(`P${n}`).value = r.arquivoPdf || null;
    for (let c = 2; c <= 16; c++) {
      const cell = ws.getCell(n, c);
      cell.font = { name: FONTE, size: 10 };
      cell.border = { bottom: { style: 'hair', color: { argb: 'FFBFC5C7' } } };
      cell.alignment = { vertical: 'middle', horizontal: [4, 12, 14].includes(c) ? 'left' : 'center', wrapText: c === 4 };
    }
    ws.getCell(`F${n}`).numFmt = 'dd/mm/yyyy';
    ws.getCell(`G${n}`).numFmt = 'dd/mm/yyyy';
    ws.getCell(`J${n}`).numFmt = '0.00000000';
    ws.getCell(`J${n}`).font = { name: FONTE, size: 8, color: { argb: 'FF9AA3A7' } };
  });

  const fim = Math.max(4 + ordenados.length - 1, 4);
  ws.autoFilter = `B3:I${fim}`;
  const ate = ULTIMA;
  ws.dataValidations.add(`H4:H${ate}`, { type: 'list', allowBlank: true, formulae: ['"✓,❌"'] });
  ws.dataValidations.add(`C4:C${ate}`, { type: 'list', allowBlank: true, formulae: ['"FERRAMENTARIA,MANUTENÇÃO"'] });
  ws.addConditionalFormatting({
    ref: `I4:I${ate}`,
    rules: Object.entries(CORES_STATUS).map(([nome, [bg, fg]]) => ({
      type: 'cellIs', operator: 'equal', formulae: [`"${nome}"`], priority: 1,
      style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: bg } }, font: { color: { argb: fg }, bold: true } },
    })),
  });

  // ------------------------------------------------------------------ DASHBOARD (fórmulas)
  const d = wb.addWorksheet('DASHBOARD', { views: [{ showGridLines: false }] });
  [['A', 3], ['B', 24], ['C', 14], ['D', 20], ['E', 60], ['F', 20], ['G', 14]].forEach(([c, w]) => { d.getColumn(c).width = w; });
  const S = `'${ABA}'!$I$4:$I$${ate}`;
  const SE = `'${ABA}'!$C$4:$C$${ate}`;
  const k = kpis(records, today);
  const titulo2 = (cel, txt) => { const c = d.getCell(cel); c.value = txt; c.font = { name: FONTE, bold: true, size: 12, color: { argb: 'FFFFFFFF' } }; c.fill = fill('FF1C2226'); };
  const cabec = (cel, txt) => { const c = d.getCell(cel); c.value = txt; c.font = { name: FONTE, bold: true, size: 10, color: { argb: 'FFFFFFFF' } }; c.fill = fill('FF3B4750'); c.alignment = { horizontal: 'center' }; };
  const val = (cel, f, result, fmt) => { const c = d.getCell(cel); c.value = { formula: f, result }; c.font = { name: FONTE, size: 11 }; c.alignment = { horizontal: 'center' }; if (fmt) c.numFmt = fmt; };
  const rot = (cel, txt) => { const c = d.getCell(cel); c.value = txt; c.font = { name: FONTE, size: 10 }; };

  d.mergeCells('B2:C2'); titulo2('B2', 'TOTAL DE O.S.');
  cabec('B3', 'STATUS'); cabec('C3', 'QUANTIDADE');
  const linhas = [['EM ANDAMENTO', STATUS.ANDAMENTO], ['ATRASADOS', STATUS.ATRASADO], ['AG. PRAZO', STATUS.AG_PRAZO],
    ['EM PLANEJAMENTO', STATUS.PLANEJAMENTO], ['CONCLUÍDOS', STATUS.CONCLUIDO], ['CANCELADOS', STATUS.CANCELADO]];
  linhas.forEach(([rotulo, st], i) => {
    rot(`B${4 + i}`, rotulo);
    val(`C${4 + i}`, `COUNTIF(${S},"${st}")`, k.porStatus[st]);
  });
  rot('B10', 'TOTAL:'); d.getCell('B10').font = { name: FONTE, bold: true };
  val('C10', 'SUM(C4:C9)', Object.values(k.porStatus).reduce((a, b) => a + b, 0));

  d.mergeCells('E2:F2'); titulo2('E2', 'ÍNDICE DE ENTREGA (concluídas ÷ total sem canceladas)');
  cabec('E3', 'SETOR'); cabec('F3', 'PERCENTUAL');
  ['FERRAMENTARIA', 'MANUTENÇÃO'].forEach((setor, i) => {
    const n = 4 + i;
    const c = (st) => `COUNTIFS(${SE},"${setor}",${S},"${st}")`;
    const total = `${c(STATUS.ANDAMENTO)}+${c(STATUS.AG_PRAZO)}+${c(STATUS.PLANEJAMENTO)}+${c(STATUS.ATRASADO)}+${c(STATUS.CONCLUIDO)}`;
    rot(`E${n}`, setor);
    val(`F${n}`, `IFERROR(${c(STATUS.CONCLUIDO)}/(${total}),0)`, k.indice[setor] ?? 0, '0.0%');
  });
  rot('E6', 'GERAL'); d.getCell('E6').font = { name: FONTE, bold: true };
  val('F6', 'IFERROR(C8/(C4+C5+C6+C7+C8),0)', k.indiceGeral, '0.0%');

  d.mergeCells('B13:F13'); titulo2('B13', "TOP 5 O.S's ABERTAS MAIS ANTIGAS");
  ['DATA', 'N° DA O.S', 'SETOR', 'PROBLEMA', 'STATUS'].forEach((h, i) => cabec(`${'BCDEF'[i]}14`, h));
  const top = maisAntigas(records, 5, today);
  const ID = `'${ABA}'!$J$4:$J$${ate}`;
  const col = (c) => `'${ABA}'!$${c}$4:$${c}$${ate}`;
  for (let i = 0; i < 5; i++) {
    const n = 15 + i, r = top[i];
    val(`B${n}`, `IFERROR(SMALL(${ID},${i + 1}),"")`, r ? Math.floor(dayNumber(r.dataAbertura) + 25569) : '', 'dd/mm/yyyy');
    const via = (c, res) => val(`${c}${n}`, `IFERROR(INDEX(${col(c === 'C' ? 'B' : c === 'D' ? 'C' : c === 'E' ? 'D' : 'I')},MATCH(B${n},${ID},0)),"")`, res);
    via('C', r?.os ?? ''); via('D', r?.setor ?? ''); via('E', r?.problema ?? ''); via('F', r ? calcStatus(r, today) : '');
    d.getCell(`E${n}`).alignment = { horizontal: 'left', wrapText: true };
  }
  d.getCell('B21').value = `Gerado pelo ${'ITAESBRA SCAN'} em ${today.split('-').reverse().join('/')}. A coluna STATUS recalcula com a data de hoje ao abrir no Excel.`;
  d.getCell('B21').font = { name: FONTE, size: 9, italic: true, color: { argb: 'FF6B757A' } };

  const buf = await wb.xlsx.writeBuffer();
  return new Uint8Array(buf);
}

const cellText = (v) => {
  if (v === null || v === undefined) return '';
  if (typeof v === 'object') {
    if (v instanceof Date) return '';
    if ('result' in v) return cellText(v.result);
    if ('richText' in v) return v.richText.map((p) => p.text).join('');
    if ('text' in v) return String(v.text);
  }
  return String(v);
};
const cellDate = (v) => {
  const x = v && typeof v === 'object' && 'result' in v ? v.result : v;
  if (x instanceof Date && !Number.isNaN(+x)) return x.toISOString().slice(0, 10);
  return '';
};

/**
 * Lê a planilha de controle existente. Agrupa por código da O.S. (normalizado) e devolve também
 * os avisos: códigos fora do padrão, linhas repetidas e setores conflitantes.
 */
export async function importarPlanilha(arrayBuffer, { ExcelJS = globalThis.ExcelJS } = {}) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(arrayBuffer);
  let ws = null, linhaCab = 0;
  for (const s of wb.worksheets) {
    for (let r = 1; r <= Math.min(10, s.rowCount); r++) {
      const vals = [1, 2, 3, 4].map((c) => cellText(s.getCell(r, c + 1).value).toUpperCase());
      if (vals.some((v) => v.includes('DA O.S')) ) { ws = s; linhaCab = r; break; }
    }
    if (ws) break;
  }
  if (!ws) throw new Error('Não encontrei a tabela "N° DA O.S." nesta planilha.');
  const idx = {};
  ws.getRow(linhaCab).eachCell((cell, c) => { idx[cellText(cell.value).trim().toUpperCase()] = c; });
  const col = (nome) => Object.entries(idx).find(([k]) => k.includes(nome))?.[1];
  const cOS = col('DA O.S'), cSetor = col('SETOR'), cProb = col('PROBLEMA'), cEq = col('MÁQUINA') ?? col('MAQUINA'),
    cAb = col('ABERTURA'), cPrazo = col('PRAZO'), cCx = col('C/X');
  if (!cOS || !cAb) throw new Error('Colunas "N° DA O.S." e "DATA DE ABERTURA" são obrigatórias.');

  const grupos = new Map();
  const avisos = [];
  let linhas = 0;
  for (let r = linhaCab + 1; r <= ws.rowCount; r++) {
    const bruto = cellText(ws.getCell(r, cOS).value).trim();
    if (!bruto) continue;
    linhas++;
    const n = normalizeOsCode(bruto);
    const cx = cellText(ws.getCell(r, cCx).value).trim();
    const item = {
      linha: r, bruto, codigo: n.code || bruto.toUpperCase(), valido: n.valid,
      setor: cellText(ws.getCell(r, cSetor).value).trim().toUpperCase(),
      problema: cellText(ws.getCell(r, cProb).value).replace(/\s+/g, ' ').trim(),
      equipamento: normalizeEquip(cellText(ws.getCell(r, cEq).value)),
      dataAbertura: cellDate(ws.getCell(r, cAb).value),
      prazo: cPrazo ? cellDate(ws.getCell(r, cPrazo).value) : '',
      cx: cx === '✓' || cx === '❌' ? cx : '',
    };
    if (!grupos.has(item.codigo)) grupos.set(item.codigo, []);
    grupos.get(item.codigo).push(item);
  }

  const records = [];
  for (const [codigo, itens] of grupos) {
    // escolhe a linha mais "resolvida" (com C/X) e, no empate, a última digitada
    const escolhido = [...itens].reverse().find((i) => i.cx) || itens[itens.length - 1];
    const obs = [];
    if (!escolhido.valido) { obs.push(`Código fora do padrão OSN####### na planilha original ("${escolhido.bruto}").`); avisos.push({ linha: escolhido.linha, os: codigo, tipo: 'codigo', msg: 'Código fora do padrão OSN#######: confira.' }); }
    if (escolhido.bruto !== codigo && escolhido.valido) avisos.push({ linha: escolhido.linha, os: codigo, tipo: 'corrigido', msg: `Código corrigido de "${escolhido.bruto}".` });
    if (itens.length > 1) {
      const setores = [...new Set(itens.map((i) => i.setor).filter(Boolean))];
      const msg = `${itens.length} linhas com o mesmo código${setores.length > 1 ? ` (setores: ${setores.join(' / ')})` : ''}; importada 1 (linha ${escolhido.linha}).`;
      obs.push(msg);
      avisos.push({ linha: escolhido.linha, os: codigo, tipo: setores.length > 1 ? 'conflito' : 'repetida', msg });
    }
    if (!escolhido.dataAbertura) avisos.push({ linha: escolhido.linha, os: codigo, tipo: 'data', msg: 'Sem data de abertura.' });
    records.push(newRecord({
      os: codigo, setor: escolhido.setor, problema: escolhido.problema, equipamento: escolhido.equipamento,
      dataAbertura: escolhido.dataAbertura, prazo: escolhido.prazo, cx: escolhido.cx,
      dataConclusao: '', origem: 'planilha', observacoes: obs.join(' '),
      historico: [{ quando: new Date().toISOString(), quem: 'importação', campo: 'registro', de: '', para: 'importado da planilha de controle' }],
    }));
  }
  return { records, avisos, linhas, unicas: records.length };
}
