// Extração dos campos de uma "ORDEM DE SERVICO NAO PROGRAMADA" a partir do texto
// (camada de texto do PDF ou resultado de OCR). Módulo puro.
import { normalizeOsCode, normalizeEquip, dayNumber } from './osmodel.js';

export const REGRAS_SETOR_PADRAO = [
  { contem: 'FERRAMENTARIA', setor: 'FERRAMENTARIA' },
  { contem: 'MANUTENCAO', setor: 'MANUTENÇÃO' },
];

/** Maiúsculas e sem acentos, preservando o comprimento (índices equivalentes ao texto original). */
export function norm(s) {
  return Array.from(String(s ?? ''), (ch) => {
    const b = ch.normalize('NFD')[0];
    return b.toUpperCase();
  }).join('');
}

// OCR costuma ler ':' como ; . , | ! + * % ou até '1' — todos aceitos depois de um rótulo.
const SEP = String.raw`(?:[:;.,|!+*%=~]+\s*|\b[1lI|]\s+)?`;
const rx = (rotulo) => new RegExp(rotulo + String.raw`\s*` + SEP + String.raw`\s*`);
const clean = (s) => String(s ?? '').replace(/\s+/g, ' ').trim();
const DIGIT_FIX = (s) => s.replace(/[OQ]/gi, '0').replace(/[Il|]/g, '1').replace(/S/gi, '5').replace(/B/gi, '8').replace(/Z/gi, '2');

function parseDateTime(txt) {
  const m = /([0-9OIlSB]{2})\s*[\/.\-]\s*([0-9OIlSB]{2})\s*[\/.\-]\s*([0-9OIlSB]{2,4})(?:\s*[-–—]?\s*([0-9OIlSB]{2}\s*:\s*[0-9OIlSB]{2}(?:\s*:\s*[0-9OIlSB]{2})?))?/.exec(txt || '');
  if (!m) return null;
  const d = +DIGIT_FIX(m[1]);
  const mo = +DIGIT_FIX(m[2]);
  let y = +DIGIT_FIX(m[3]);
  if (y < 100) y += 2000;
  const iso = `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const valid = d >= 1 && d <= 31 && mo >= 1 && mo <= 12 && y >= 2000 && y <= 2100 && dayNumber(iso) !== null;
  const hora = m[4] ? DIGIT_FIX(m[4].replace(/\s+/g, '')) : '';
  return { iso, hora, valid, fixed: /[OIlSB]/.test(m[1] + m[2] + m[3]) };
}

/** Divide uma linha em colunas usando as ocorrências de um rótulo (ex.: "MATRICULA :" duas vezes). */
function porColunas(line, labelRe) {
  const re = new RegExp(labelRe.source, 'gi');
  const parts = [];
  let last = -1;
  let m;
  while ((m = re.exec(line)) !== null) {
    if (last >= 0) parts.push(line.slice(last, m.index));
    last = m.index + m[0].length;
  }
  if (last >= 0) parts.push(line.slice(last));
  return parts;
}

export function extractOS(text, { regrasSetor = REGRAS_SETOR_PADRAO } = {}) {
  const raw = String(text ?? '');
  const L = raw.split(/\r?\n/).map((l) => l.replace(/\s+$/, ''));
  const N = L.map(norm);
  const full = N.join('\n');
  const rec = {
    os: '', tipoOS: '', equipamento: '', equipamentoDescricao: '', unidadeFuncional: '', centroCusto: '',
    criticidade: '', tipoServico: '', servicoExecutado: '', problema: '',
    dataAbertura: '', horaAbertura: '', setor: '', extraidoEm: '',
    solicitante: { matricula: '', nome: '', centroTrabalho: '' },
    recepcao: { matricula: '', centroTrabalho: '' },
  };
  const conf = {};
  const warnings = [];

  // ---- código da O.S. ----
  let mOs = /ORDEM DE SERVICO\s*[:;.,|!]\s*([A-Z0-9|]{6,13})/.exec(full);
  if (mOs) {
    const n = normalizeOsCode(mOs[1]);
    rec.os = n.code;
    conf.os = /^OSN\d{7}$/.test(mOs[1]) ? 1 : n.valid ? 0.75 : 0.35;
  } else {
    const f = /\b[O0][S5]N[0-9OILSBZ|]{7}\b/.exec(full);
    if (f) {
      const n = normalizeOsCode(f[0]);
      rec.os = n.code;
      conf.os = n.valid ? 0.6 : 0.3;
    }
  }
  if (!rec.os) warnings.push('Código da O.S. não encontrado.');
  else if (conf.os < 0.85) warnings.push('Código da O.S. corrigido automaticamente (confira com o papel).');

  const mTipo = /ORDEM DE SERVICO\s+((?:NAO\s+)?PROGRAMADA)/.exec(full);
  if (mTipo) rec.tipoOS = clean(mTipo[1]).replace('NAO PROGRAMADA', 'NÃO PROGRAMADA');

  // ---- campos de uma linha (rótulo : valor) ----
  const campo = (re) => {
    for (let i = 0; i < N.length; i++) {
      const m = re.exec(N[i]);
      if (m) return { i, end: m.index + m[0].length, line: L[i], m };
    }
    return null;
  };

  const eq = campo(rx('EQUIPAMENTO'));
  if (eq) {
    const rest = clean(eq.line.slice(eq.end));
    const m = /^(\S+)(?:\s+[-–—]\s*(.*))?$/.exec(rest);
    if (m) {
      rec.equipamento = normalizeEquip(m[1]);
      rec.equipamentoDescricao = clean(m[2] || '');
      conf.equipamento = /^[A-Z0-9][A-Z0-9\-.\/]{2,}$/.test(rec.equipamento) ? 0.9 : 0.55;
    }
  }

  const uf = campo(rx(String.raw`UNI\.?\s*FUNCIONAL`));
  if (uf) rec.unidadeFuncional = clean(uf.line.slice(uf.end));

  const cc = campo(/CENTRO\s*CUSTO[^0-9A-Z]*/);
  if (cc) rec.centroCusto = (/^([0-9OIl]{3,})/.exec(clean(cc.line.slice(cc.end))) || [])[1] || '';
  if (rec.centroCusto) rec.centroCusto = DIGIT_FIX(rec.centroCusto);

  const cr = campo(rx('CRITICIDADE'));
  if (cr) rec.criticidade = clean(cr.line.slice(cr.end));

  const ss = campo(rx(String.raw`SERVICO\s+SOLICITADO`));
  if (ss) {
    rec.tipoServico = clean(ss.line.slice(ss.end));
    conf.tipoServico = rec.tipoServico ? 0.9 : 0;
  }
  const se = campo(rx(String.raw`SERVICO\s+EXECUTADO`));
  if (se) rec.servicoExecutado = clean(se.line.slice(se.end));

  // ---- observação (pode ocupar várias linhas até o bloco SOLICITACAO) ----
  const ob = campo(rx(String.raw`OBSERVA[CÇ][AÃ]O`));
  if (ob) {
    const partes = [clean(ob.line.slice(ob.end))];
    for (let i = ob.i + 1; i < L.length; i++) {
      const n = N[i].trim();
      if (!n) continue;
      if (/^SOLICITA[CÇ][AÃ]O/.test(n) || /^[-=_\s|]{8,}$/.test(n) || /^EXECUCAO/.test(n)) break;
      partes.push(clean(L[i]));
      if (partes.length > 8) break;
    }
    rec.problema = clean(partes.join(' '));
    conf.problema = rec.problema ? 0.9 : 0;
  }

  // ---- blocos SOLICITACAO | RECEPCAO (duas colunas na mesma linha) ----
  let ini = N.findIndex((n) => /SOLICITA[CÇ][AÃ]O\s+RECEP/.test(n));
  if (ini < 0) ini = N.findIndex((n) => /^SOLICITA[CÇ][AÃ]O/.test(n.trim()));
  let fim = N.findIndex((n, i) => i > ini && /^EXECU[CÇ][AÃ]O/.test(n.trim()));
  if (fim < 0) fim = Math.min(L.length, (ini < 0 ? 0 : ini) + 12);
  const ini0 = ini < 0 ? 0 : ini;
  const bloco = (re) => {
    for (let i = ini0; i < fim; i++) {
      if (re.test(N[i])) return porColunas(L[i], re).map(clean);
    }
    return null;
  };

  const mat = bloco(/MATRICULA\s*[:;.,|!]/);
  if (mat && mat[0]) {
    const m = /^([0-9OIl]+)\s*[-–—]\s*(.+)$/.exec(mat[0]);
    if (m) {
      rec.solicitante.matricula = DIGIT_FIX(m[1]);
      rec.solicitante.nome = clean(m[2]);
    } else rec.solicitante.nome = mat[0];
    if (mat[1] && mat[1] !== '-') rec.recepcao.matricula = mat[1];
  }
  const ct = bloco(/CENT\.?\s*TRAB\s*[:;.,|!]/);
  if (ct) {
    if (ct[0] && ct[0] !== '-') rec.solicitante.centroTrabalho = ct[0];
    if (ct[1] && ct[1] !== '-') rec.recepcao.centroTrabalho = ct[1];
  }
  const dh = bloco(/DATA\s*\/\s*HORA\s*[:;.,|!]/);
  if (dh && dh[0]) {
    const d = parseDateTime(dh[0]);
    if (d) {
      rec.dataAbertura = d.iso;
      rec.horaAbertura = d.hora;
      conf.dataAbertura = d.valid ? (d.fixed ? 0.7 : 1) : 0.3;
    }
  }
  if (!rec.dataAbertura) warnings.push('Data de abertura não encontrada.');
  else if (conf.dataAbertura < 0.85) warnings.push('Data de abertura precisa de conferência.');

  const ex = /EXTRAIDO\s+EM\s+(\S+)\s+AS\s+(\S+)/.exec(full);
  if (ex) {
    const d = parseDateTime(`${ex[1]} ${ex[2]}`);
    if (d && d.valid) rec.extraidoEm = `${d.iso}T${d.hora || '00:00:00'}`;
  }

  // ---- SETOR = área que vai tratar o problema (centro de trabalho da RECEPÇÃO) ----
  const alvo = norm(rec.recepcao.centroTrabalho);
  const regra = alvo ? regrasSetor.find((r) => alvo.includes(norm(r.contem))) : null;
  if (regra) {
    rec.setor = regra.setor;
    conf.setor = 0.9;
  } else {
    conf.setor = 0;
    warnings.push(alvo
      ? `Setor não mapeado para "${rec.recepcao.centroTrabalho}". Escolha o setor ou cadastre a regra em Configurações.`
      : 'Área de recepção não encontrada: escolha o setor.');
  }
  if (!rec.problema) warnings.push('Observação (problema) não encontrada.');
  if (!rec.equipamento) warnings.push('Código do equipamento não encontrado.');

  const isOS = !!rec.os && /ORDEM DE SERVICO/.test(full);
  const chaves = ['os', 'setor', 'problema', 'equipamento', 'dataAbertura'];
  const media = chaves.reduce((s, k) => s + (conf[k] || 0), 0) / chaves.length;
  return { record: rec, conf, warnings, isOS, confiancaGeral: media, rawText: raw };
}

/** Nível visual de confiança: ok | conferir | corrigir. */
export function nivelConf(c) {
  if (c === undefined || c < 0.5) return 'corrigir';
  if (c < 0.85) return 'conferir';
  return 'ok';
}
