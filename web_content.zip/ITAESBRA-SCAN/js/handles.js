// Guarda os "handles" das pastas escolhidas (IndexedDB) para reabrir sem escolher de novo.
const DB = 'osscan';
const abrir = () => new Promise((res, rej) => {
  const r = indexedDB.open(DB, 1);
  r.onupgradeneeded = () => {
    r.result.createObjectStore('handles');
    r.result.createObjectStore('outbox', { keyPath: 'id' });
  };
  r.onsuccess = () => res(r.result);
  r.onerror = () => rej(r.error);
});
const tx = async (store, modo, fn) => {
  const db = await abrir();
  return new Promise((res, rej) => {
    const t = db.transaction(store, modo);
    const out = fn(t.objectStore(store));
    t.oncomplete = () => res(out?.result);
    t.onerror = () => rej(t.error);
  });
};

export const salvarHandle = (chave, handle) => tx('handles', 'readwrite', (s) => s.put(handle, chave));
export const lerHandle = (chave) => tx('handles', 'readonly', (s) => s.get(chave));
export const apagarHandle = (chave) => tx('handles', 'readwrite', (s) => s.delete(chave));

// Fila local: documentos que não puderam ser gravados na rede (pasta indisponível, sem permissão...).
export const outboxAdicionar = (item) => tx('outbox', 'readwrite', (s) => s.put(item));
export const outboxListar = () => tx('outbox', 'readonly', (s) => s.getAll());
export const outboxRemover = (id) => tx('outbox', 'readwrite', (s) => s.delete(id));
