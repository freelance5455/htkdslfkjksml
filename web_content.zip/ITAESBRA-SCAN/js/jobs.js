// Fila de trabalho: cada documento digitalizado/importado vira um "job" que passa por
// processamento → leitura (texto do PDF ou OCR) → conferência → gravação na pasta de rede.
import { app, emit, categoria } from './state.js';
import { QUALIDADES } from './config.js';
import { buildPdf } from './pdfwriter.js';
import { extractOS } from './extract.js';
import { newRecord, camposFaltando, normalizeOsCode } from './osmodel.js';
import { processarPagina } from './imagingClient.js';
import { abrirPdf, renderizarPagina, ocrImagem } from './ocr.js';
import { salvarDocumento } from './service.js';
import { outboxAdicionar } from './handles.js';

let seq = 0;
let fila = Promise.resolve();
const enfileirar = (fn) => (fila = fila.then(fn, fn));

// ---------------------------------------------------------------- imagem ⇄ JPEG

export async function imagemParaJpeg(img, qualidade) {
  const c = document.createElement('canvas');
  c.width = img.width; c.height = img.height;
  c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(img.data.buffer ?? img.data), img.width, img.height), 0, 0);
  const blob = await new Promise((res) => c.toBlob(res, 'image/jpeg', qualidade));
  return new Uint8Array(await blob.arrayBuffer());
}

export async function jpegParaCanvas(jpeg) {
  const bmp = await createImageBitmap(new Blob([jpeg], { type: 'image/jpeg' }));
  const c = document.createElement('canvas');
  c.width = bmp.width; c.height = bmp.height;
  c.getContext('2d').drawImage(bmp, 0, 0);
  return c;
}

export async function arquivoParaImagem(file) {
  const bmp = await createImageBitmap(file);
  const c = document.createElement('canvas');
  c.width = bmp.width; c.height = bmp.height;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0);
  const d = ctx.getImageData(0, 0, c.width, c.height);
  return { data: d.data, width: d.width, height: d.height };
}

const opcoes = () => {
  const q = QUALIDADES[app.config.qualidade] || QUALIDADES.NORMAL;
  return { filter: app.config.filtro, maxSide: q.maxSide, contrast: app.config.contraste, brightness: app.config.brilho };
};

/** Processa uma foto/imagem (detecção da folha, perspectiva, filtro) e devolve a página pronta. */
export async function paginaDeImagem(raw, { quadNorm = null, quad = null } = {}) {
  let r = await processarPagina(raw, { ...opcoes(), quad });
  if (!quad && !r.edgesFound && quadNorm) {
    const q = quadNorm.map((p) => ({ x: p.x * raw.width, y: p.y * raw.height }));
    r = await processarPagina(raw, { ...opcoes(), quad: q });
    r.edgesFound = true;
  }
  const q = QUALIDADES[app.config.qualidade] || QUALIDADES.NORMAL;
  const jpeg = await imagemParaJpeg(r.image, q.jpeg);
  return {
    id: `p${++seq}`, jpeg, width: r.image.width, height: r.image.height,
    url: URL.createObjectURL(new Blob([jpeg], { type: 'image/jpeg' })),
    raw, quad: r.quad, edgesFound: r.edgesFound, cutRisk: r.cutRisk, blurScore: r.blurScore,
    avisos: avisosDaPagina(r),
  };
}

function avisosDaPagina(r) {
  const a = [];
  if (!r.edgesFound) a.push('Bordas do papel não detectadas');
  else if (r.cutRisk) a.push('Documento possivelmente cortado');
  if (app.config.limiarDesfoque > 0 && r.blurScore < app.config.limiarDesfoque) a.push('Imagem possivelmente desfocada');
  return a;
}

// ---------------------------------------------------------------- jobs

function novoJob(base) {
  const job = {
    id: `j${Date.now().toString(36)}${++seq}`, criadoEm: new Date(), estado: 'processando', etapa: 'Na fila…',
    categoriaId: app.categoriaId, origem: 'arquivo', nome: 'Documento', paginas: [], pdfBytes: null, pdfOriginal: false,
    previewUrl: '', extracao: null, record: null, duplicada: null, avisos: [], erro: '', entrada: null,
    ...base,
  };
  app.jobs.unshift(job);
  emit('jobs');
  return job;
}

const atualizar = (job, p) => { Object.assign(job, p); emit('jobs'); };

/** Job a partir de páginas já processadas (câmera: Modo A = 1 página, Modo B = várias). */
export function jobDePaginas(paginas, nome) {
  const job = novoJob({ origem: 'camera', nome, paginas });
  enfileirar(() => processarJob(job));
  return job;
}

/** Job a partir de um arquivo (PDF do scanner ou imagem). */
export function jobDeArquivo(file, { entrada = null, origem = 'arquivo' } = {}) {
  const job = novoJob({ origem, nome: file.name, entrada });
  enfileirar(async () => {
    try {
      atualizar(job, { etapa: 'Lendo arquivo…' });
      if (/\.pdf$/i.test(file.name) || file.type === 'application/pdf') {
        job.pdfBytes = new Uint8Array(await file.arrayBuffer());
        job.pdfOriginal = true;
      } else {
        atualizar(job, { etapa: 'Tratando imagem…' });
        const raw = await arquivoParaImagem(file);
        job.paginas = [await paginaDeImagem(raw)];
        job.avisos.push(...job.paginas[0].avisos);
      }
      await processarJob(job);
    } catch (e) {
      atualizar(job, { estado: 'erro', erro: `Não foi possível ler o arquivo: ${e.message || e}` });
    }
  });
  return job;
}

async function processarJob(job) {
  try {
    const cat = categoria(job.categoriaId);
    if (!job.pdfOriginal) {
      atualizar(job, { etapa: 'Gerando PDF…' });
      job.pdfBytes = buildPdf(job.paginas.map((p) => ({ jpeg: p.jpeg, width: p.width, height: p.height })), { title: job.nome });
      job.previewUrl = job.paginas[0]?.url || '';
    }

    let texto = '';
    let canvasPrimeira = null;
    let docPdf = null;
    if (job.pdfOriginal) {
      atualizar(job, { etapa: 'Abrindo PDF…' });
      const r = await abrirPdf(job.pdfBytes);
      docPdf = r.doc;
      texto = r.textoCamada;
      canvasPrimeira = await renderizarPagina(docPdf, 1, 1700);
      job.previewUrl = await canvasParaUrl(canvasPrimeira, 0.8);
      job.numPaginas = r.numPages;
    } else {
      job.numPaginas = job.paginas.length;
    }

    if (cat.extrairOS) {
      let ext = texto.length > 40 ? extractOS(texto, { regrasSetor: app.config.regrasSetor }) : null;
      let origem = 'texto-pdf';
      if (!ext || !ext.isOS) {
        atualizar(job, { etapa: 'Lendo o documento (OCR)…' });
        const fonte = canvasPrimeira || await jpegParaCanvas(job.paginas[0].jpeg);
        const t = await ocrImagem(fonte, (p) => atualizar(job, { etapa: `Lendo o documento (OCR) ${Math.round(p * 100)}%` }));
        ext = extractOS(t, { regrasSetor: app.config.regrasSetor });
        origem = 'ocr';
      }
      job.extracao = ext;
      job.record = newRecord({ ...ext.record, origem });
      if (!ext.isOS) job.avisos.push('Este documento não parece uma O.S. Confira ou escolha outra categoria.');
      job.avisos.push(...ext.warnings);
      await verificarDuplicada(job);
    }

    atualizar(job, { etapa: '' });
    const completo = cat.extrairOS && job.extracao?.isOS && !camposFaltando(job.record).length &&
      job.extracao.confiancaGeral >= 0.85 && !job.duplicada && !job.avisos.length;
    if (!cat.extrairOS || (app.config.salvarAutomatico && completo)) {
      atualizar(job, { estado: 'salvando' });
      await salvarJob(job);
    } else {
      atualizar(job, { estado: 'conferir' });
    }
  } catch (e) {
    console.error(e);
    atualizar(job, { estado: 'erro', erro: String(e.message || e) });
  }
}

async function canvasParaUrl(canvas, q) {
  const blob = await new Promise((res) => canvas.toBlob(res, 'image/jpeg', q));
  return URL.createObjectURL(blob);
}

export async function verificarDuplicada(job) {
  job.duplicada = null;
  const n = normalizeOsCode(job.record?.os);
  if (app.repo && app.conectada && n.code) {
    try { job.duplicada = (await app.repo.carregarOS(n.code)) || null; } catch { /* sem acesso: segue sem aviso */ }
  }
}

/** Refaz a leitura (ex.: depois de ajustar as bordas). */
export function reprocessarJob(job) {
  atualizar(job, { estado: 'processando', etapa: 'Reprocessando…', avisos: [], erro: '' });
  enfileirar(() => processarJob(job));
}

/** Grava o PDF e o registro na pasta de rede; se a rede falhar, guarda na fila local. */
export async function salvarJob(job, { modoDuplicada = 'atualizar' } = {}) {
  const cat = categoria(job.categoriaId);
  atualizar(job, { estado: 'salvando', erro: '' });
  const dados = { categoria: cat, pdfBytes: job.pdfBytes, record: cat.extrairOS ? job.record : null, quem: app.quem, modoDuplicada };
  try {
    if (!app.repo || !app.conectada) throw Object.assign(new Error('Pasta de destino não conectada.'), { semPasta: true });
    const r = await salvarDocumento(app.repo, dados);
    if (r.record) {
      const i = app.registros.findIndex((x) => x.os === r.record.os);
      if (i >= 0) app.registros[i] = r.record; else app.registros.push(r.record);
      emit('registros');
    }
    atualizar(job, { estado: 'salvo', caminho: r.caminho, atualizada: r.atualizado, record: r.record || job.record });
    await finalizarEntrada(job);
    emit('salvo', job);
    return r;
  } catch (e) {
    if (e.semPasta || /NotAllowed|Security|NetworkError|InvalidState|NoModification/i.test(`${e.name} ${e.message}`)) {
      await outboxAdicionar({
        id: job.id, criadoEm: Date.now(), categoriaId: job.categoriaId, record: dados.record,
        pdf: job.pdfBytes.buffer.slice(job.pdfBytes.byteOffset, job.pdfBytes.byteOffset + job.pdfBytes.byteLength), erro: String(e.message || e),
      });
      atualizar(job, { estado: 'erro', erro: `Pasta indisponível — documento guardado na fila local deste computador (${e.message}). Use "Reenviar" quando a pasta voltar.`, naOutbox: true });
      emit('outbox');
    } else {
      atualizar(job, { estado: job.record ? 'conferir' : 'erro', erro: String(e.message || e) });
    }
    throw e;
  }
}

/** Depois de salvo, trata o arquivo original da pasta de entrada (mover/apagar/manter). */
async function finalizarEntrada(job) {
  const e = job.entrada;
  if (!e) return;
  try {
    const modo = app.config.entradaApagar;
    if (modo === 'manter') return;
    if (modo === 'mover') {
      const proc = await e.dir.getDirectoryHandle('_processados', { create: true });
      const fh = await proc.getFileHandle(`${Date.now()}_${e.nome}`, { create: true });
      const w = await fh.createWritable();
      await w.write(job.pdfOriginal ? job.pdfBytes : await (await (await e.dir.getFileHandle(e.nome)).getFile()).arrayBuffer());
      await w.close();
    }
    await e.dir.removeEntry(e.nome);
  } catch (err) {
    console.warn('Não foi possível tratar o arquivo da pasta de entrada', err);
  }
}

export function descartarJob(job) {
  app.jobs = app.jobs.filter((j) => j !== job);
  if (job.entrada) emit('entrada-liberar', job.entrada.nome);
  emit('jobs');
}
