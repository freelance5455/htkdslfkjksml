import { REGRAS_SETOR_PADRAO } from './extract.js';

export const APP_NAME = 'ITAESBRA SCAN';
export const TITULO_PLANILHA = 'CONTROLE DE ORDENS DE SERVIÇO DA SOLDA';

export const MESES = ['01-Janeiro', '02-Fevereiro', '03-Março', '04-Abril', '05-Maio', '06-Junho',
  '07-Julho', '08-Agosto', '09-Setembro', '10-Outubro', '11-Novembro', '12-Dezembro'];

// Estrutura na pasta escolhida:
//   Documentos/<Categoria>/<AAAA>/<MM-Mês>/arquivo.pdf   (PDFs digitalizados)
//   BaseOS/os/<OSN#######>.json                           (um arquivo por O.S. = sem conflito entre usuários)
//   BaseOS/_config/config.json                            (configuração compartilhada)
//   BaseOS/exportacoes/                                   (planilhas geradas)
export const DIR_DOCUMENTOS = 'Documentos';
export const DIR_OS = ['BaseOS', 'os'];
export const DIR_CONFIG = ['BaseOS', '_config'];
export const DIR_EXPORT = ['BaseOS', 'exportacoes'];

export const CATEGORIAS_PADRAO = [
  { id: 'os', nome: 'Ordem de Serviço', prefixo: 'OS', pasta: 'Ordens de Serviço', extrairOS: true, ativa: true },
  { id: 'qualidade', nome: 'Qualidade', prefixo: 'QUAL', pasta: 'Qualidade', extrairOS: false, ativa: true },
  { id: 'producao', nome: 'Produção', prefixo: 'PROD', pasta: 'Produção', extrairOS: false, ativa: true },
  { id: 'manutencao', nome: 'Manutenção', prefixo: 'MANUT', pasta: 'Manutenção', extrairOS: false, ativa: true },
  { id: 'administrativo', nome: 'Administrativo', prefixo: 'ADM', pasta: 'Administrativo', extrairOS: false, ativa: true },
  { id: 'outros', nome: 'Outros', prefixo: 'DOC', pasta: 'Outros', extrairOS: false, ativa: true },
];

export const CONFIG_PADRAO = {
  versao: 1,
  categorias: CATEGORIAS_PADRAO,
  regrasSetor: REGRAS_SETOR_PADRAO,
  setores: ['FERRAMENTARIA', 'MANUTENÇÃO'],
  qualidade: 'NORMAL',        // ECO | NORMAL | ALTA
  filtro: 'color',            // color | gray | bw | original
  contraste: 1.1,
  brilho: 0,
  capturaAuto: true,
  limiarDesfoque: 120,        // variância do Laplaciano: abaixo disso avisa "possivelmente desfocada"
  som: true,
  salvarAutomatico: false,    // salva sem conferência quando tudo foi lido com segurança
  entradaApagar: 'mover',     // mover (para _processados) | apagar | manter
  monitorarEntrada: false,
};

export const QUALIDADES = {
  ECO: { maxSide: 1600, jpeg: 0.7 },
  NORMAL: { maxSide: 2100, jpeg: 0.8 },
  ALTA: { maxSide: 2800, jpeg: 0.88 },
};

/** Mescla a configuração salva com os padrões (campos novos nunca quebram versões antigas). */
export function mesclarConfig(salva = {}) {
  const cfg = { ...CONFIG_PADRAO, ...salva };
  if (!Array.isArray(cfg.categorias) || !cfg.categorias.length) cfg.categorias = CATEGORIAS_PADRAO;
  if (!Array.isArray(cfg.regrasSetor)) cfg.regrasSetor = REGRAS_SETOR_PADRAO;
  return cfg;
}

/** Nome seguro para arquivo/pasta do Windows. */
export function nomeSeguro(s, max = 80) {
  return String(s ?? '').normalize('NFC')
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').replace(/[. ]+$/g, '').replace(/^\.+/, '_').slice(0, max) || '_';
}

/** Subpastas do destino: Documentos/<Categoria>/<AAAA>/<MM-Mês>. */
export function pastaDestino(categoria, dataISO) {
  const m = /^(\d{4})-(\d{2})/.exec(dataISO || '');
  const ano = m ? m[1] : String(new Date().getFullYear());
  const mes = m ? MESES[Math.min(11, Math.max(0, +m[2] - 1))] : MESES[new Date().getMonth()];
  return [DIR_DOCUMENTOS, nomeSeguro(categoria.pasta || categoria.nome), ano, mes];
}

/** PREFIXO_AAAAMMDD_000001.pdf — próximo número livre na pasta. */
export function nomeSequencial(prefixo, dataISO, nomesExistentes) {
  const dia = (dataISO || new Date().toISOString().slice(0, 10)).replace(/-/g, '');
  const re = new RegExp(`^${nomeSeguro(prefixo)}_${dia}_(\\d{6})\\.pdf$`, 'i');
  let max = 0;
  for (const n of nomesExistentes) { const m = re.exec(n); if (m) max = Math.max(max, +m[1]); }
  return `${nomeSeguro(prefixo)}_${dia}_${String(max + 1).padStart(6, '0')}.pdf`;
}
