// Processamento de imagem 100% local, em JavaScript puro (sem bibliotecas externas).
// Trabalha sobre objetos { data: Uint8ClampedArray (RGBA), width, height } —
// o mesmo formato do ImageData do navegador — e por isso também roda no Node (testes).

export function makeImage(width, height, fill = 255) {
  const data = new Uint8ClampedArray(width * height * 4).fill(fill);
  for (let i = 3; i < data.length; i += 4) data[i] = 255;
  return { data, width, height };
}

export function toGray(img) {
  const { data, width: w, height: h } = img;
  const g = new Uint8ClampedArray(w * h);
  for (let i = 0, j = 0; i < g.length; i++, j += 4) g[i] = (data[j] * 77 + data[j + 1] * 150 + data[j + 2] * 29) >> 8;
  return g;
}

/** Redução por média de blocos até que o maior lado seja <= maxSide. */
export function downscaleTo(img, maxSide) {
  const { data, width: w, height: h } = img;
  if (Math.max(w, h) <= maxSide) return { img, sx: 1, sy: 1 };
  const k = maxSide / Math.max(w, h);
  const nw = Math.max(1, Math.round(w * k));
  const nh = Math.max(1, Math.round(h * k));
  const out = new Uint8ClampedArray(nw * nh * 4);
  for (let y = 0; y < nh; y++) {
    const y0 = Math.floor((y * h) / nh);
    const y1 = Math.max(y0 + 1, Math.floor(((y + 1) * h) / nh));
    for (let x = 0; x < nw; x++) {
      const x0 = Math.floor((x * w) / nw);
      const x1 = Math.max(x0 + 1, Math.floor(((x + 1) * w) / nw));
      let r = 0, g = 0, b = 0, n = 0;
      for (let yy = y0; yy < y1; yy++) {
        let p = (yy * w + x0) * 4;
        for (let xx = x0; xx < x1; xx++) { r += data[p]; g += data[p + 1]; b += data[p + 2]; n++; p += 4; }
      }
      const o = (y * nw + x) * 4;
      out[o] = r / n; out[o + 1] = g / n; out[o + 2] = b / n; out[o + 3] = 255;
    }
  }
  return { img: { data: out, width: nw, height: nh }, sx: nw / w, sy: nh / h };
}

export function otsuThreshold(gray) {
  const hist = new Float64Array(256);
  for (let i = 0; i < gray.length; i++) hist[gray[i]]++;
  const total = gray.length;
  let sum = 0;
  for (let t = 0; t < 256; t++) sum += t * hist[t];
  let sumB = 0, wB = 0, best = 0, thr = 127;
  for (let t = 0; t < 256; t++) {
    wB += hist[t];
    if (!wB) continue;
    const wF = total - wB;
    if (!wF) break;
    sumB += t * hist[t];
    const mB = sumB / wB, mF = (sum - sumB) / wF;
    const between = wB * wF * (mB - mF) * (mB - mF);
    if (between > best) { best = between; thr = t; }
  }
  return thr;
}

/** Desfoque de caixa separável (raio r), bordas replicadas. */
export function boxBlurGray(src, w, h, r) {
  if (r < 1) return src;
  const tmp = new Float32Array(w * h);
  const out = new Uint8ClampedArray(w * h);
  const win = 2 * r + 1;
  for (let y = 0; y < h; y++) {
    const row = y * w;
    let acc = 0;
    for (let k = -r; k <= r; k++) acc += src[row + Math.min(w - 1, Math.max(0, k))];
    for (let x = 0; x < w; x++) {
      tmp[row + x] = acc / win;
      acc += src[row + Math.min(w - 1, x + r + 1)] - src[row + Math.max(0, x - r)];
    }
  }
  for (let x = 0; x < w; x++) {
    let acc = 0;
    for (let k = -r; k <= r; k++) acc += tmp[Math.min(h - 1, Math.max(0, k)) * w + x];
    for (let y = 0; y < h; y++) {
      out[y * w + x] = acc / win;
      acc += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
    }
  }
  return out;
}

// ---------------------------------------------------------------- detecção da folha

function labelComponents(mask, w, h) {
  const labels = new Int32Array(w * h);
  const stack = new Int32Array(w * h);
  const comps = [];
  let id = 0;
  for (let i = 0; i < w * h; i++) {
    if (!mask[i] || labels[i]) continue;
    id++;
    let sp = 0;
    stack[sp++] = i;
    labels[i] = id;
    let area = 0, bl = 0, br = 0, bt = 0, bb = 0;
    while (sp) {
      const p = stack[--sp];
      area++;
      const x = p % w, y = (p / w) | 0;
      if (x === 0) bl = 1;
      if (x === w - 1) br = 1;
      if (y === 0) bt = 1;
      if (y === h - 1) bb = 1;
      if (x > 0 && mask[p - 1] && !labels[p - 1]) { labels[p - 1] = id; stack[sp++] = p - 1; }
      if (x < w - 1 && mask[p + 1] && !labels[p + 1]) { labels[p + 1] = id; stack[sp++] = p + 1; }
      if (y > 0 && mask[p - w] && !labels[p - w]) { labels[p - w] = id; stack[sp++] = p - w; }
      if (y < h - 1 && mask[p + w] && !labels[p + w]) { labels[p + w] = id; stack[sp++] = p + w; }
    }
    comps.push({ id, area, borders: bl + br + bt + bb });
  }
  return { labels, comps };
}

function convexHull(points) {
  const pts = points.slice().sort((a, b) => a.x - b.x || a.y - b.y);
  if (pts.length < 3) return pts;
  const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
  const lower = [];
  for (const p of pts) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper = [];
  for (let i = pts.length - 1; i >= 0; i--) {
    const p = pts[i];
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop();
    upper.push(p);
  }
  lower.pop();
  upper.pop();
  return lower.concat(upper);
}

const triArea = (a, b, c) => Math.abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)) / 2;

function distPointLine(p, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y;
  const len = Math.hypot(dx, dy);
  return len ? Math.abs(dx * (p.y - a.y) - dy * (p.x - a.x)) / len : Math.hypot(p.x - a.x, p.y - a.y);
}

function douglasPeucker(pts, eps) {
  if (pts.length < 3) return pts;
  const a = pts[0], b = pts[pts.length - 1];
  let idx = -1, dmax = -1;
  for (let i = 1; i < pts.length - 1; i++) {
    const d = distPointLine(pts[i], a, b);
    if (d > dmax) { dmax = d; idx = i; }
  }
  if (dmax <= eps) return [a, b];
  const l = douglasPeucker(pts.slice(0, idx + 1), eps);
  const r = douglasPeucker(pts.slice(idx), eps);
  return l.slice(0, -1).concat(r);
}

/** Simplifica um polígono fechado (poucos vértices, cantos preservados). */
function simplifyClosed(poly, eps) {
  if (poly.length <= 8) return poly;
  let far = 0, fd = -1;
  for (let i = 1; i < poly.length; i++) {
    const d = Math.hypot(poly[i].x - poly[0].x, poly[i].y - poly[0].y);
    if (d > fd) { fd = d; far = i; }
  }
  const a = douglasPeucker(poly.slice(0, far + 1), eps);
  const b = douglasPeucker(poly.slice(far).concat([poly[0]]), eps);
  return a.slice(0, -1).concat(b.slice(0, -1));
}

/** Entre os vértices de um polígono convexo, escolhe os 4 que formam o quadrilátero de maior área. */
function maxAreaQuad(poly) {
  const n = poly.length;
  if (n <= 4) return poly;
  let best = null, bestA = -1;
  for (let i = 0; i < n; i++) {
    for (let j = i + 2; j < n; j++) {
      if (i === 0 && j === n - 1) continue;
      let a1 = -1, k1 = -1, a2 = -1, k2 = -1;
      for (let k = i + 1; k < j; k++) {
        const a = triArea(poly[i], poly[k], poly[j]);
        if (a > a1) { a1 = a; k1 = k; }
      }
      for (let k = j + 1; k < n + i; k++) {
        const kk = k % n;
        const a = triArea(poly[i], poly[kk], poly[j]);
        if (a > a2) { a2 = a; k2 = kk; }
      }
      if (k1 >= 0 && k2 >= 0 && a1 + a2 > bestA) { bestA = a1 + a2; best = [poly[i], poly[k1], poly[j], poly[k2]]; }
    }
  }
  return best || poly.slice(0, 4);
}

export function quadArea(q) {
  let s = 0;
  for (let i = 0; i < 4; i++) {
    const a = q[i], b = q[(i + 1) % 4];
    s += a.x * b.y - b.x * a.y;
  }
  return Math.abs(s) / 2;
}

/** Ordena 4 pontos em [topo-esq, topo-dir, base-dir, base-esq]. */
export function orderQuad(pts) {
  const cx = pts.reduce((s, p) => s + p.x, 0) / 4;
  const cy = pts.reduce((s, p) => s + p.y, 0) / 4;
  const sorted = pts.slice().sort((a, b) => Math.atan2(a.y - cy, a.x - cx) - Math.atan2(b.y - cy, b.x - cx));
  let start = 0;
  for (let i = 1; i < 4; i++) if (sorted[i].x + sorted[i].y < sorted[start].x + sorted[start].y) start = i;
  return [0, 1, 2, 3].map((k) => sorted[(start + k) % 4]);
}

function anglesOk(q) {
  for (let i = 0; i < 4; i++) {
    const p = q[(i + 3) % 4], c = q[i], n = q[(i + 1) % 4];
    const v1 = { x: p.x - c.x, y: p.y - c.y }, v2 = { x: n.x - c.x, y: n.y - c.y };
    const cos = (v1.x * v2.x + v1.y * v2.y) / (Math.hypot(v1.x, v1.y) * Math.hypot(v2.x, v2.y) || 1);
    const ang = (Math.acos(Math.max(-1, Math.min(1, cos))) * 180) / Math.PI;
    if (ang < 45 || ang > 135) return false;
  }
  return true;
}

/**
 * Procura a folha de papel: separa claro/escuro (Otsu), pega a maior região plausível,
 * calcula o fecho convexo e reduz a 4 cantos. Devolve { quad, areaFrac, solidity } com os
 * cantos nas coordenadas da imagem original, ou null.
 */
export function detectQuad(img, { maxSide = 320, minArea = 0.12, maxArea = 0.97, minSolidity = 0.72 } = {}) {
  const { img: small, sx, sy } = downscaleTo(img, maxSide);
  const w = small.width, h = small.height;
  const gray = boxBlurGray(toGray(small), w, h, 1);
  const total = w * h;
  // Limiares: Otsu global e Otsu dentro de cada uma das duas classes (separa folha, fundo e texto).
  const t1 = otsuThreshold(gray);
  const lowPart = gray.filter((v) => v <= t1);
  const highPart = gray.filter((v) => v > t1);
  const thresholds = [...new Set([t1, lowPart.length > 50 ? otsuThreshold(lowPart) : t1, highPart.length > 50 ? otsuThreshold(highPart) : t1])];
  let best = null;
  for (const thr of thresholds) {
    for (const bright of [true, false]) {
      const mask = new Uint8Array(total);
      for (let i = 0; i < total; i++) mask[i] = (gray[i] > thr) === bright ? 1 : 0;
      const { labels, comps } = labelComponents(mask, w, h);
      const cands = comps
        .filter((c) => c.area >= total * minArea && c.area <= total * maxArea && c.borders <= 2)
        .sort((a, b) => b.area - a.area)
        .slice(0, 2);
      for (const c of cands) {
        const pts = [];
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const p = y * w + x;
            if (labels[p] !== c.id) continue;
            const edge = x === 0 || y === 0 || x === w - 1 || y === h - 1 ||
              labels[p - 1] !== c.id || labels[p + 1] !== c.id || labels[p - w] !== c.id || labels[p + w] !== c.id;
            if (edge) pts.push({ x, y });
          }
        }
        if (pts.length < 8) continue;
        const hull = convexHull(pts);
        if (hull.length < 4) continue;
        const quad = orderQuad(maxAreaQuad(simplifyClosed(hull, 1.2)));
        const qa = quadArea(quad);
        if (qa < total * minArea) continue;
        const solidity = c.area / qa;
        if (solidity < minSolidity || solidity > 1.2 || !anglesOk(quad)) continue;
        if (!best || qa > best.qa) best = { quad, qa, solidity, areaFrac: qa / total };
      }
    }
  }
  if (!best) return null;
  return {
    quad: best.quad.map((p) => ({ x: (p.x + 0.5) / sx, y: (p.y + 0.5) / sy })),
    areaFrac: best.areaFrac,
    solidity: best.solidity,
  };
}

/** Algum canto está colado na borda da imagem? (possível corte do documento) */
export function quadTouchesBorder(quad, w, h, margin = 0.01) {
  return quad.some((p) => p.x <= w * margin || p.y <= h * margin || p.x >= w * (1 - margin) || p.y >= h * (1 - margin));
}

// ---------------------------------------------------------------- perspectiva

function solveLinear(A, b) {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    [M[c], M[p]] = [M[p], M[c]];
    const d = M[c][c] || 1e-12;
    for (let k = c; k <= n; k++) M[c][k] /= d;
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c];
      if (!f) continue;
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  return M.map((row) => row[n]);
}

/** Homografia que leva o retângulo de saída (0..w-1, 0..h-1) ao quadrilátero de origem. */
function homographyRectToQuad(w, h, q) {
  const dst = [{ x: 0, y: 0 }, { x: w - 1, y: 0 }, { x: w - 1, y: h - 1 }, { x: 0, y: h - 1 }];
  const A = [], b = [];
  for (let i = 0; i < 4; i++) {
    const { x, y } = dst[i];
    const X = q[i].x, Y = q[i].y;
    A.push([x, y, 1, 0, 0, 0, -x * X, -y * X]); b.push(X);
    A.push([0, 0, 0, x, y, 1, -x * Y, -y * Y]); b.push(Y);
  }
  return solveLinear(A, b);
}

/** Tamanho natural da folha retificada, limitado a maxSide no maior lado. */
export function outputSize(quad, maxSide = 2100) {
  const d = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  let w = Math.max(d(quad[0], quad[1]), d(quad[3], quad[2]));
  let h = Math.max(d(quad[0], quad[3]), d(quad[1], quad[2]));
  const k = Math.min(1, maxSide / Math.max(w, h));
  w = Math.max(16, Math.round(w * k));
  h = Math.max(16, Math.round(h * k));
  return { w, h };
}

/** Correção de perspectiva com amostragem bilinear. */
export function warpPerspective(img, quad, outW, outH) {
  const H = homographyRectToQuad(outW, outH, quad);
  const { data, width: sw, height: sh } = img;
  const out = new Uint8ClampedArray(outW * outH * 4);
  let o = 0;
  for (let y = 0; y < outH; y++) {
    for (let x = 0; x < outW; x++) {
      const d = H[6] * x + H[7] * y + 1;
      let u = (H[0] * x + H[1] * y + H[2]) / d;
      let v = (H[3] * x + H[4] * y + H[5]) / d;
      u = Math.min(sw - 1.001, Math.max(0, u));
      v = Math.min(sh - 1.001, Math.max(0, v));
      const x0 = u | 0, y0 = v | 0, fx = u - x0, fy = v - y0;
      const p00 = (y0 * sw + x0) * 4, p10 = p00 + 4, p01 = p00 + sw * 4, p11 = p01 + 4;
      const w00 = (1 - fx) * (1 - fy), w10 = fx * (1 - fy), w01 = (1 - fx) * fy, w11 = fx * fy;
      out[o++] = data[p00] * w00 + data[p10] * w10 + data[p01] * w01 + data[p11] * w11;
      out[o++] = data[p00 + 1] * w00 + data[p10 + 1] * w10 + data[p01 + 1] * w01 + data[p11 + 1] * w11;
      out[o++] = data[p00 + 2] * w00 + data[p10 + 2] * w10 + data[p01 + 2] * w01 + data[p11 + 2] * w11;
      out[o++] = 255;
    }
  }
  return { data: out, width: outW, height: outH };
}

export function rotate90(img, times = 1) {
  let cur = img;
  for (let t = 0; t < ((times % 4) + 4) % 4; t++) {
    const { data, width: w, height: h } = cur;
    const out = new Uint8ClampedArray(w * h * 4);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const s = (y * w + x) * 4;
        const d = (x * h + (h - 1 - y)) * 4; // gira 90° horário: (x,y) -> (h-1-y, x)
        out[d] = data[s]; out[d + 1] = data[s + 1]; out[d + 2] = data[s + 2]; out[d + 3] = 255;
      }
    }
    cur = { data: out, width: h, height: w };
  }
  return cur;
}

// ---------------------------------------------------------------- filtros

/**
 * Tratamento de sombras: estima o fundo (papel) numa grade reduzida (máximo local + suavização)
 * e divide a imagem pelo fundo. O papel fica branco e uniforme; o texto é preservado.
 */
export function normalizeBackground(img) {
  const { data, width: w, height: h } = img;
  const k = 4;
  const sw = Math.ceil(w / k), sh = Math.ceil(h / k);
  const grid = [0, 1, 2].map(() => new Uint8ClampedArray(sw * sh));
  for (let gy = 0; gy < sh; gy++) {
    for (let gx = 0; gx < sw; gx++) {
      const x1 = Math.min(w, (gx + 1) * k), y1 = Math.min(h, (gy + 1) * k);
      const s = [0, 0, 0];
      let n = 0;
      for (let y = gy * k; y < y1; y++) {
        for (let x = gx * k; x < x1; x++) {
          const p = (y * w + x) * 4;
          s[0] += data[p]; s[1] += data[p + 1]; s[2] += data[p + 2]; n++;
        }
      }
      for (let c = 0; c < 3; c++) grid[c][gy * sw + gx] = s[c] / n;
    }
  }
  const bg = grid.map((g) => {
    const dil = maxFilter(g, sw, sh, 2);
    return boxBlurGray(dil, sw, sh, 2);
  });
  const out = new Uint8ClampedArray(w * h * 4);
  const xi = new Int32Array(w), xf = new Float32Array(w);
  for (let x = 0; x < w; x++) {
    const gxf = Math.min(sw - 1, Math.max(0, (x + 0.5) / k - 0.5));
    xi[x] = Math.min(sw - 2 < 0 ? 0 : sw - 2, gxf | 0);
    xf[x] = sw < 2 ? 0 : gxf - xi[x];
  }
  for (let y = 0; y < h; y++) {
    const gyf = Math.min(sh - 1, Math.max(0, (y + 0.5) / k - 0.5));
    const y0 = Math.min(sh - 2 < 0 ? 0 : sh - 2, gyf | 0);
    const fy = sh < 2 ? 0 : gyf - y0;
    const y1 = Math.min(sh - 1, y0 + 1);
    for (let x = 0; x < w; x++) {
      const x0 = xi[x], x1 = Math.min(sw - 1, x0 + 1), fx = xf[x];
      const p = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) {
        const g = bg[c];
        const b = (g[y0 * sw + x0] * (1 - fx) + g[y0 * sw + x1] * fx) * (1 - fy) +
          (g[y1 * sw + x0] * (1 - fx) + g[y1 * sw + x1] * fx) * fy;
        out[p + c] = (data[p + c] * 255) / Math.max(b, 1);
      }
      out[p + 3] = 255;
    }
  }
  return { data: out, width: w, height: h };
}

function maxFilter(src, w, h, r) {
  const tmp = new Uint8ClampedArray(w * h);
  const out = new Uint8ClampedArray(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let m = 0;
      for (let k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) m = Math.max(m, src[y * w + k]);
      tmp[y * w + x] = m;
    }
  }
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let m = 0;
      for (let k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) m = Math.max(m, tmp[k * w + x]);
      out[y * w + x] = m;
    }
  }
  return out;
}

function adaptiveBW(gray, w, h, radius, c) {
  const W = w + 1;
  const integral = new Float64Array(W * (h + 1));
  for (let y = 0; y < h; y++) {
    let row = 0;
    for (let x = 0; x < w; x++) {
      row += gray[y * w + x];
      integral[(y + 1) * W + x + 1] = integral[y * W + x + 1] + row;
    }
  }
  const out = new Uint8ClampedArray(w * h);
  for (let y = 0; y < h; y++) {
    const y0 = Math.max(0, y - radius), y1 = Math.min(h, y + radius + 1);
    for (let x = 0; x < w; x++) {
      const x0 = Math.max(0, x - radius), x1 = Math.min(w, x + radius + 1);
      const sum = integral[y1 * W + x1] - integral[y0 * W + x1] - integral[y1 * W + x0] + integral[y0 * W + x0];
      const mean = sum / ((x1 - x0) * (y1 - y0));
      out[y * w + x] = gray[y * w + x] < mean - c ? 0 : 255;
    }
  }
  return out;
}

/**
 * Filtros de documento. mode: 'color' | 'gray' | 'bw' | 'original'.
 * contrast/brightness: v' = v * contrast + brightness (como no app Android).
 */
export function applyFilter(img, { mode = 'color', contrast = 1.1, brightness = 0 } = {}) {
  if (mode === 'original') return img;
  const norm = normalizeBackground(img);
  const { data, width: w, height: h } = norm;
  if (mode === 'bw') {
    const g = toGray(norm);
    const bw = adaptiveBW(g, w, h, Math.max(8, Math.min(40, Math.round(Math.min(w, h) / 40))), 18);
    const out = new Uint8ClampedArray(w * h * 4);
    for (let i = 0, j = 0; i < bw.length; i++, j += 4) { out[j] = out[j + 1] = out[j + 2] = bw[i]; out[j + 3] = 255; }
    return { data: out, width: w, height: h };
  }
  const out = new Uint8ClampedArray(w * h * 4);
  for (let j = 0; j < data.length; j += 4) {
    if (mode === 'gray') {
      const v = ((data[j] * 77 + data[j + 1] * 150 + data[j + 2] * 29) >> 8) * contrast + brightness;
      out[j] = out[j + 1] = out[j + 2] = v;
    } else {
      out[j] = data[j] * contrast + brightness;
      out[j + 1] = data[j + 1] * contrast + brightness;
      out[j + 2] = data[j + 2] * contrast + brightness;
    }
    out[j + 3] = 255;
  }
  return { data: out, width: w, height: h };
}

/** Variância do Laplaciano numa imagem de ~700 px: baixo = desfocada. */
export function blurScore(img) {
  const { img: s } = downscaleTo(img, 700);
  const g = toGray(s);
  const w = s.width, h = s.height;
  let sum = 0, sum2 = 0, n = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const l = g[i - 1] + g[i + 1] + g[i - w] + g[i + w] - 4 * g[i];
      sum += l; sum2 += l * l; n++;
    }
  }
  const mean = sum / n;
  return sum2 / n - mean * mean;
}

/**
 * Pipeline de uma página: detecta bordas (ou usa o quad informado), corrige a perspectiva,
 * aplica o filtro e mede nitidez. quad = cantos [tl,tr,br,bl] em pixels, ou null para detectar.
 */
export function processPage(img, { quad = null, filter = 'color', maxSide = 2100, contrast = 1.1, brightness = 0 } = {}) {
  let found = !!quad;
  let q = quad;
  if (!q) {
    const det = detectQuad(img, { maxSide: 480 });
    if (det) { q = det.quad; found = true; }
  }
  if (!q) {
    q = [{ x: 0, y: 0 }, { x: img.width - 1, y: 0 }, { x: img.width - 1, y: img.height - 1 }, { x: 0, y: img.height - 1 }];
  }
  const cut = found && quadTouchesBorder(q, img.width, img.height, 0.01);
  const { w, h } = outputSize(q, maxSide);
  const warped = warpPerspective(img, q, w, h);
  const blur = blurScore(warped);
  const out = applyFilter(warped, { mode: filter, contrast, brightness });
  return { image: out, quad: q, edgesFound: found, cutRisk: cut, blurScore: blur };
}
