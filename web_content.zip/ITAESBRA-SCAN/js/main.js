import { app, on, emit } from './state.js';
import { APP_NAME } from './config.js';
import { h, $, $$, toast } from './ui/dom.js';
import { montarScan, processarEntrada, pararCamera } from './ui/scan.js';
import { montarReview } from './ui/review.js';
import { montarGestao } from './ui/manage.js';
import { montarConfig } from './ui/settings.js';
import { conectar, configLocal, contarOutbox, reenviarOutbox } from './conexao.js';
import { lerHandle } from './handles.js';
import { iniciarPdfJs, obterOcr, ocrStatus } from './ocr.js';

const VIEWS = ['scan', 'review', 'manage', 'settings'];
let handleBasePendente = null;

function mostrar(nome) {
  VIEWS.forEach((v) => { $(`#view-${v}`).hidden = v !== nome; });
  $$('#rail .nav').forEach((b) => (b.dataset.view === nome ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current')));
  if (nome !== 'scan') pararCamera();
  location.hash = nome;
}

function faixa() {
  const f = $('#faixa');
  const pend = app.jobs.filter((j) => ['processando', 'conferir', 'salvando'].includes(j.estado)).length;
  const aConferir = app.jobs.filter((j) => j.estado === 'conferir').length;
  const ocr = ocrStatus();
  const cnt = $('#cnt-conf');
  cnt.textContent = aConferir || '';
  cnt.dataset.n = String(aConferir);
  f.replaceChildren(
    h('span', { class: 'item' }, h('i', { class: `ponto ${app.conectada ? 'ok' : 'erro'}` }), app.conectada ? `Pasta: ${app.pastaNome}` : 'Pasta não conectada'),
    h('span', { class: 'item' }, h('i', { class: `ponto ${ocr.pronto ? 'ok' : ocr.erro ? 'erro' : 'aviso'}` }), ocr.pronto ? 'Leitura (OCR) pronta' : ocr.erro ? 'OCR com erro' : 'OCR carrega ao usar'),
    h('span', { class: 'item' }, `${app.registros.length} O.S. na base`),
    pend ? h('span', { class: 'item' }, h('i', { class: 'ponto aviso' }), `${pend} documento(s) em andamento`) : null,
    app.quem ? h('span', { class: 'item muted' }, `Operador: ${app.quem}`) : null);
}

async function avisos() {
  const box = $('#avisos');
  const linhas = [];
  if (!window.showDirectoryPicker) {
    linhas.push(h('div', { class: 'aviso-topo' }, 'Este navegador não permite gravar em pastas de rede. Abra o endereço no Google Chrome ou no Microsoft Edge (computador).'));
  } else if (!app.conectada) {
    linhas.push(h('div', { class: 'aviso-topo' }, handleBasePendente ? 'A pasta de armazenamento precisa ser liberada novamente nesta sessão.' : 'Escolha a pasta de armazenamento para começar.',
      h('button', { class: 'btn primario pequeno', onclick: async () => {
        if (handleBasePendente) { if (!(await conectar(handleBasePendente, { pedirPermissao: true }))) toast('Permissão negada.', 'erro'); } else { mostrar('settings'); }
      } }, handleBasePendente ? 'Reconectar pasta' : 'Ir para Configurações')));
  }
  const n = await contarOutbox();
  if (n) {
    linhas.push(h('div', { class: 'aviso-topo' }, `${n} documento(s) guardado(s) neste computador aguardando a pasta de rede.`,
      h('button', { class: 'btn pequeno', disabled: !app.conectada, onclick: async () => {
        try { const r = await reenviarOutbox(); toast(`Reenvio: ${r.ok} enviados${r.falhas ? `, ${r.falhas} com falha` : ''}.`, r.falhas ? 'aviso' : 'ok'); } catch (e) { toast(e.message, 'erro'); }
      } }, 'Reenviar agora')));
  }
  box.replaceChildren(...linhas);
}

async function iniciar() {
  document.title = `${APP_NAME} — digitalização e gestão de O.S.`;
  try { iniciarPdfJs(); } catch (e) { console.warn(e); }
  app.config = configLocal();

  montarScan($('#view-scan'));
  montarReview($('#view-review'));
  montarGestao($('#view-manage'));
  montarConfig($('#view-settings'));
  $$('#rail .nav').forEach((b) => b.addEventListener('click', () => mostrar(b.dataset.view)));
  [['jobs', faixa], ['registros', faixa], ['conexao', () => { faixa(); avisos(); }], ['config', faixa], ['outbox', avisos]].forEach(([e, fn]) => on(e, fn));
  on('salvo', () => { faixa(); });

  const inicial = VIEWS.includes(location.hash.slice(1)) ? location.hash.slice(1) : 'scan';
  mostrar(inicial);
  faixa();

  // reabre as pastas escolhidas em sessões anteriores
  try {
    const base = await lerHandle('base');
    if (base) {
      handleBasePendente = base;
      await conectar(base);
    }
    const ent = await lerHandle('entrada');
    if (ent) { app.entrada = ent; processarEntrada(true); }
  } catch (e) { console.warn('handles', e); }
  faixa();
  avisos();

  // carrega o OCR em segundo plano, sem travar a tela
  (window.requestIdleCallback || ((f) => setTimeout(f, 1500)))(() => obterOcr().then(faixa).catch(faixa));

  window.addEventListener('beforeunload', (e) => {
    const emAberto = app.jobs.some((j) => ['processando', 'conferir', 'salvando'].includes(j.estado)) || app.sessaoPaginas.length;
    if (emAberto) { e.preventDefault(); e.returnValue = ''; }
  });
}

iniciar();
