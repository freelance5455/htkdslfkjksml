// Leitura de PDFs (camada de texto ou OCR) e OCR de imagens. Tudo local: pdf.js e Tesseract
// vêm da pasta vendor/ (nenhum download em tempo de execução).
const abs = (p) => new URL(p, document.baseURI).href;

let workerPromise = null;
let status = { pronto: false, erro: '' };
export const ocrStatus = () => status;

export function iniciarPdfJs() {
  if (!globalThis.pdfjsLib) throw new Error('pdf.js não carregou (vendor/pdfjs).');
  globalThis.pdfjsLib.GlobalWorkerOptions.workerSrc = abs('vendor/pdfjs/pdf.worker.min.js');
}

export function obterOcr(onProgress = () => {}) {
  if (!workerPromise) {
    workerPromise = (async () => {
      if (!globalThis.Tesseract) throw new Error('Tesseract não carregou (vendor/tesseract).');
      const w = await globalThis.Tesseract.createWorker('por', 1, {
        workerPath: abs('vendor/tesseract/worker.min.js'),
        corePath: abs('vendor/tesseract/core'),
        langPath: abs('vendor/tesseract/lang'),
        gzip: true,
        workerBlobURL: false,
        logger: (m) => { if (m.status === 'recognizing text') onProgress(m.progress); },
      });
      await w.setParameters({ tessedit_pageseg_mode: '6', preserve_interword_spaces: '1' });
      status = { pronto: true, erro: '' };
      return w;
    })().catch((e) => { status = { pronto: false, erro: String(e.message || e) }; workerPromise = null; throw e; });
  }
  return workerPromise;
}

/** OCR de um canvas/imagem. Devolve o texto reconhecido. */
export async function ocrImagem(fonte, onProgress) {
  const w = await obterOcr(onProgress);
  const { data } = await w.recognize(fonte);
  return data.text || '';
}

/** Reconstrói as linhas do texto da página a partir dos itens do pdf.js (colunas lado a lado ficam na mesma linha). */
function linhasDaPagina(items) {
  const linhas = [];
  for (const it of items) {
    if (!it.str || !it.str.trim()) continue;
    const y = it.transform[5];
    let l = linhas.find((x) => Math.abs(x.y - y) < 3);
    if (!l) { l = { y, itens: [] }; linhas.push(l); }
    l.itens.push({ x: it.transform[4], w: it.width, s: it.str });
  }
  linhas.sort((a, b) => b.y - a.y);
  return linhas.map((l) => {
    l.itens.sort((a, b) => a.x - b.x);
    let out = '';
    let fim = null;
    for (const i of l.itens) {
      if (fim !== null) out += i.x - fim > 12 ? '   ' : ' ';
      out += i.s;
      fim = i.x + i.w;
    }
    return out;
  }).join('\n');
}

/** Abre um PDF e devolve { doc, textoCamada } (texto vazio = PDF só de imagem, precisa de OCR). */
export async function abrirPdf(bytes) {
  iniciarPdfJs();
  const doc = await globalThis.pdfjsLib.getDocument({ data: bytes.slice(0) }).promise;
  let texto = '';
  for (let p = 1; p <= Math.min(doc.numPages, 3); p++) {
    const pg = await doc.getPage(p);
    texto += linhasDaPagina((await pg.getTextContent()).items) + '\n';
  }
  return { doc, textoCamada: texto.trim(), numPages: doc.numPages };
}

/** Renderiza a página de um PDF em canvas (largura alvo em px; padrão ~200 dpi de A4). */
export async function renderizarPagina(doc, numero = 1, larguraAlvo = 1700) {
  const pg = await doc.getPage(numero);
  const base = pg.getViewport({ scale: 1 });
  const escala = Math.min(4, larguraAlvo / base.width);
  const vp = pg.getViewport({ scale: escala });
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(vp.width);
  canvas.height = Math.round(vp.height);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  await pg.render({ canvasContext: ctx, viewport: vp }).promise;
  return canvas;
}
