// Gerador de PDF mínimo: embute JPEGs diretamente (DCTDecode), uma página A4 por imagem.
// Sem bibliotecas; funciona no navegador e no Node.

const A4_SHORT = 595, A4_LONG = 842;

const ascii = (s) => String(s ?? '')
  .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  .replace(/[^\x20-\x7E]/g, '').replace(/([()\\])/g, '\\$1');

const p2 = (n) => String(n).padStart(2, '0');

/**
 * @param pages [{ jpeg: Uint8Array, width: number, height: number }]
 * @returns Uint8Array com o PDF
 */
export function buildPdf(pages, { title = '', creator = 'ITAESBRA SCAN', date = new Date() } = {}) {
  if (!pages.length) throw new Error('Nenhuma página para gerar o PDF');
  const enc = new TextEncoder();
  const chunks = [];
  let pos = 0;
  const push = (u8) => { chunks.push(u8); pos += u8.length; };
  const txt = (s) => push(enc.encode(s));
  const n = pages.length;
  const total = 3 + 3 * n; // catálogo, páginas, info + 3 objetos por página
  const infoObj = total;
  const offsets = new Array(total);

  push(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x34, 0x0a, 0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a])); // %PDF-1.4 + marca binária
  offsets[0] = pos;
  txt('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
  offsets[1] = pos;
  const kids = pages.map((_, i) => `${5 + 3 * i} 0 R`).join(' ');
  txt(`2 0 obj\n<< /Type /Pages /Kids [${kids}] /Count ${n} >>\nendobj\n`);

  pages.forEach((pg, i) => {
    const imgObj = 3 + 3 * i, contentObj = 4 + 3 * i, pageObj = 5 + 3 * i;
    offsets[imgObj - 1] = pos;
    txt(`${imgObj} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${pg.width} /Height ${pg.height} ` +
      `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${pg.jpeg.length} >>\nstream\n`);
    push(pg.jpeg);
    txt('\nendstream\nendobj\n');

    const landscape = pg.width > pg.height;
    const pw = landscape ? A4_LONG : A4_SHORT, ph = landscape ? A4_SHORT : A4_LONG;
    const scale = Math.min(pw / pg.width, ph / pg.height);
    const dw = pg.width * scale, dh = pg.height * scale;
    const content = `q\n${dw.toFixed(3)} 0 0 ${dh.toFixed(3)} ${((pw - dw) / 2).toFixed(3)} ${((ph - dh) / 2).toFixed(3)} cm\n/Im0 Do\nQ\n`;
    offsets[contentObj - 1] = pos;
    txt(`${contentObj} 0 obj\n<< /Length ${content.length} >>\nstream\n${content}endstream\nendobj\n`);
    offsets[pageObj - 1] = pos;
    txt(`${pageObj} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] ` +
      `/Resources << /XObject << /Im0 ${imgObj} 0 R >> >> /Contents ${contentObj} 0 R >>\nendobj\n`);
  });

  const d = date;
  const stamp = `D:${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}`;
  offsets[infoObj - 1] = pos;
  txt(`${infoObj} 0 obj\n<< /Title (${ascii(title)}) /Creator (${ascii(creator)}) /Producer (${ascii(creator)}) /CreationDate (${stamp}) >>\nendobj\n`);

  const xrefPos = pos;
  let xref = `xref\n0 ${total + 1}\n0000000000 65535 f \n`;
  for (const off of offsets) xref += `${String(off).padStart(10, '0')} 00000 n \n`;
  xref += `trailer\n<< /Size ${total + 1} /Root 1 0 R /Info ${infoObj} 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`;
  txt(xref);

  const out = new Uint8Array(pos);
  let o = 0;
  for (const c of chunks) { out.set(c, o); o += c.length; }
  return out;
}
