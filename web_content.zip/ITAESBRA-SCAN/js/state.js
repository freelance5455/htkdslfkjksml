import { mesclarConfig } from './config.js';

export const bus = new EventTarget();
export const emit = (nome, detalhe) => bus.dispatchEvent(new CustomEvent(nome, { detail: detalhe }));
export const on = (nome, fn) => bus.addEventListener(nome, fn);

export const app = {
  repo: null,            // Repo da pasta de rede (null = ainda não conectada)
  pastaNome: '',
  conectada: false,      // permissão de leitura/gravação concedida nesta sessão
  entrada: null,         // handle da pasta de entrada (PDFs vindos do scanner)
  config: mesclarConfig(),
  registros: [],         // base de O.S. carregada
  baseInfo: { carregadoEm: null, erros: [] },
  jobs: [],
  sessaoPaginas: [],     // páginas do documento em andamento (Modo B)
  quem: localStorage.getItem('osscan.quem') || '',
  categoriaId: localStorage.getItem('osscan.categoria') || 'os',
  modo: localStorage.getItem('osscan.modo') || 'A',
};

export const categoria = (id = app.categoriaId) =>
  app.config.categorias.find((c) => c.id === id) || app.config.categorias[0];

export function lembrar(chave, valor) {
  localStorage.setItem(`osscan.${chave}`, valor);
}
