# Servidor local mínimo para o ITAESBRA SCAN (somente neste computador, porta 8080 por padrão).
# O navegador exige "http://localhost" (e não um arquivo aberto direto) para liberar câmera, OCR e acesso a pastas.
param([int]$Porta = 8080)

$raiz = (Split-Path -Parent $MyInvocation.MyCommand.Path)
$mime = @{
  '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.mjs' = 'text/javascript; charset=utf-8'
  '.css' = 'text/css; charset=utf-8'; '.json' = 'application/json; charset=utf-8'; '.wasm' = 'application/wasm'
  '.gz' = 'application/gzip'; '.png' = 'image/png'; '.svg' = 'image/svg+xml'; '.ico' = 'image/x-icon'
  '.txt' = 'text/plain; charset=utf-8'; '.md' = 'text/plain; charset=utf-8'
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$Porta/")
try { $listener.Start() }
catch {
  Write-Host "Nao foi possivel abrir a porta $Porta (talvez ja esteja em uso). Tente: INICIAR.bat com outra porta." -ForegroundColor Red
  exit 1
}
Write-Host "ITAESBRA SCAN rodando em http://localhost:$Porta/  (feche esta janela para encerrar)" -ForegroundColor Green
Start-Process "http://localhost:$Porta/"

while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  $res = $ctx.Response
  try {
    $rel = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
    if ([string]::IsNullOrEmpty($rel)) { $rel = 'index.html' }
    $caminho = [IO.Path]::GetFullPath((Join-Path $raiz $rel))
    $dentro = $caminho.StartsWith($raiz, [StringComparison]::OrdinalIgnoreCase)
    if (-not $dentro -or -not (Test-Path -LiteralPath $caminho -PathType Leaf)) {
      $res.StatusCode = 404
      $b = [Text.Encoding]::UTF8.GetBytes('Nao encontrado')
      $res.OutputStream.Write($b, 0, $b.Length)
    } else {
      $ext = [IO.Path]::GetExtension($caminho).ToLower()
      $res.ContentType = if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' }
      $res.Headers.Add('Cache-Control', 'no-cache')
      $bytes = [IO.File]::ReadAllBytes($caminho)
      $res.ContentLength64 = $bytes.Length
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
    }
  } catch { } finally { try { $res.OutputStream.Close() } catch { } }
}
