#!/usr/bin/env python3
"""
Android Kivy Application for PMD Reader & DOCX Converter (v2 Fixed File Chooser)
Fixes:
1. Requests Android runtime storage permissions on startup (`READ_EXTERNAL_STORAGE` / `WRITE_EXTERNAL_STORAGE`).
2. Uses native Android System File Picker (`Intent.ACTION_OPEN_DOCUMENT`) when running on Android 10-15
   so scoped storage never blocks or hides files.
3. Removes restrictive file extension filters in the fallback Kivy FileChooser so `.pmd` files are always visible.
"""
import os
import re
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from kivy.app import App
from kivy.clock import Clock
from kivy.utils import platform
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup


def extract_pmd_blocks(raw_bytes: bytes, encoding: str = "cp1252") -> list[str]:
    pattern = re.compile(rb"[\x09\x0a\x0d\x20-\x7e\xa0-\xff]{6,}")
    blocks = []
    seen = set()
    for match in pattern.finditer(raw_bytes):
        decoded = match.group(0).decode(encoding, errors="ignore")
        decoded = decoded.replace("\r\n", "\n").replace("\r", "\n")
        for line in decoded.split("\n"):
            cleaned = line.strip()
            if len(cleaned) >= 4 and cleaned not in seen:
                alnum = sum(c.isalnum() or c in " .,;:'\"?!-()[]{}/&$%@#+" for c in cleaned)
                if alnum / len(cleaned) >= 0.72:
                    seen.add(cleaned)
                    blocks.append(cleaned)
    return blocks


def write_pure_python_docx(output_path: str, title: str, paragraphs: list[str]):
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""

    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

    body_xml = "".join(
        f'<w:p><w:r><w:t xml:space="preserve">{escape(p)}</w:t></w:r></w:p>'
        for p in paragraphs
    )
    document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p><w:r><w:rPr><w:b/><w:sz w:val="32"/></w:rPr><w:t>{escape(title)}</w:t></w:r></w:p>
    {body_xml}
  </w:body>
</w:document>"""

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("word/document.xml", document_xml)


class PMDAndroidApp(App):
    def build(self):
        self.current_file = None
        self.current_filename = "converted_document"

        if platform == "android":
            self.request_android_permissions()

        root = BoxLayout(orientation="vertical", padding=12, spacing=10)

        header = Label(
            text="PMD Reader & DOCX Converter (v2)",
            size_hint_y=None,
            height=48,
            bold=True,
            font_size="18sp",
        )
        root.add_widget(header)

        top_bar = BoxLayout(size_hint_y=None, height=50, spacing=8)
        btn_open = Button(text="Choose .PMD File", background_color=(0.15, 0.39, 0.92, 1))
        btn_open.bind(on_release=self.open_file_dialog)

        self.enc_spinner = Spinner(
            text="cp1252",
            values=("cp1252", "mac_roman", "latin1", "utf-8"),
            size_hint_x=0.42,
        )
        self.enc_spinner.bind(text=self.on_encoding_change)

        top_bar.add_widget(btn_open)
        top_bar.add_widget(self.enc_spinner)
        root.add_widget(top_bar)

        self.status_lbl = Label(
            text="Tap 'Choose .PMD File' to browse your phone storage.",
            size_hint_y=None,
            height=36,
        )
        root.add_widget(self.status_lbl)

        self.editor = TextInput(
            hint_text="Extracted PageMaker text will appear here...",
            multiline=True,
        )
        root.add_widget(self.editor)

        btn_save = Button(
            text="Convert & Save as .DOCX in Downloads",
            size_hint_y=None,
            height=52,
            background_color=(0.09, 0.64, 0.29, 1),
        )
        btn_save.bind(on_release=self.export_docx)
        root.add_widget(btn_save)

        return root

    def request_android_permissions(self):
        try:
            from android.permissions import request_permissions, Permission
            request_permissions([
                Permission.READ_EXTERNAL_STORAGE,
                Permission.WRITE_EXTERNAL_STORAGE,
            ])
        except Exception:
            pass

    def open_file_dialog(self, *args):
        # On Android, first try native Android SAF Intent chooser so Android 11-15 Scoped Storage works without issues
        if platform == "android":
            try:
                from jnius import autoclass
                from android import activity

                Intent = autoclass("android.content.Intent")
                PythonActivity = autoclass("org.kivy.android.PythonActivity")

                intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
                intent.addCategory(Intent.CATEGORY_OPENABLE)
                intent.setType("*/*")

                activity.bind(on_activity_result=self._on_android_file_result)
                PythonActivity.mActivity.startActivityForResult(intent, 4201)
                return
            except Exception:
                pass

        # Fallback Kivy FileChooser (with NO restrictive filter so all files & folders show up)
        self.show_fallback_file_chooser()

    def _on_android_file_result(self, request_code, result_code, intent):
        if request_code != 4201 or intent is None:
            return
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            uri = intent.getData()
            if uri is None:
                return

            resolver = PythonActivity.mActivity.getContentResolver()
            inp = resolver.openInputStream(uri)

            # Read bytes via Java byte array chunks
            chunks = bytearray()
            buf = bytearray(8192)
            while True:
                b = inp.read()
                if b == -1:
                    break
                chunks.append(b)
            inp.close()

            raw_bytes = bytes(chunks)
            Clock.schedule_once(lambda dt: self.load_raw_bytes(raw_bytes, "selected_document.pmd"), 0)
        except Exception as e:
            Clock.schedule_once(lambda dt: setattr(self.status_lbl, "text", f"Picker error: {e}"), 0)

    def show_fallback_file_chooser(self):
        content = BoxLayout(orientation="vertical", spacing=8, padding=6)
        start_dir = "/storage/emulated/0/Download" if os.path.exists("/storage/emulated/0/Download") else (
            "/storage/emulated/0" if os.path.exists("/storage/emulated/0") else os.path.expanduser("~")
        )
        # Note: No restrictive extension filter so Android never hides .pmd files
        chooser = FileChooserListView(path=start_dir)
        content.add_widget(chooser)

        btn_row = BoxLayout(size_hint_y=None, height=48, spacing=8)
        btn_select = Button(text="Open Selected File", background_color=(0.15, 0.39, 0.92, 1))
        btn_cancel = Button(text="Cancel")
        btn_row.add_widget(btn_select)
        btn_row.add_widget(btn_cancel)
        content.add_widget(btn_row)

        popup = Popup(title="Select PageMaker (.pmd / .p65) File", content=content, size_hint=(0.96, 0.92))

        def load_selection(*_):
            if chooser.selection:
                self.load_pmd(chooser.selection[0])
                popup.dismiss()

        btn_select.bind(on_release=load_selection)
        btn_cancel.bind(on_release=popup.dismiss)
        popup.open()

    def on_encoding_change(self, spinner, text):
        if self.current_file and os.path.exists(self.current_file):
            self.load_pmd(self.current_file)

    def load_raw_bytes(self, raw_bytes: bytes, filename: str):
        self.current_filename = Path(filename).stem
        blocks = extract_pmd_blocks(raw_bytes, encoding=self.enc_spinner.text)
        self.editor.text = "\n\n".join(blocks)
        self.status_lbl.text = f"Loaded {filename} ({len(blocks)} blocks)"

    def load_pmd(self, filepath: str):
        try:
            self.current_file = filepath
            self.current_filename = Path(filepath).stem
            raw = Path(filepath).read_bytes()
            blocks = extract_pmd_blocks(raw, encoding=self.enc_spinner.text)
            self.editor.text = "\n\n".join(blocks)
            self.status_lbl.text = f"Loaded {Path(filepath).name} ({len(blocks)} blocks)"
        except Exception as e:
            self.status_lbl.text = f"Error: {e}"

    def export_docx(self, *args):
        text = self.editor.text.strip()
        if not text:
            self.status_lbl.text = "Nothing to export! Load a .pmd file first."
            return

        dl_dir = "/storage/emulated/0/Download" if os.path.exists("/storage/emulated/0/Download") else os.path.expanduser("~")
        out_path = os.path.join(dl_dir, f"{self.current_filename}.docx")
        try:
            paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
            write_pure_python_docx(out_path, self.current_filename, paragraphs)
            self.status_lbl.text = f"Saved: {out_path}"
        except Exception as e:
            self.status_lbl.text = f"Save failed: {e}"


if __name__ == "__main__":
    PMDAndroidApp().run()
