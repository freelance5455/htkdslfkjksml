OBRA IA v2 — versión avanzada

CORRECCIÓN DE ESTA VERSIÓN
- EPP tiene módulo independiente y ya no aparece dentro de Actividades.
- ATS, IPERC y Permisos de trabajo tienen módulo independiente y ya no aparecen dentro de Actividades.
- Actividades conserva únicamente datos propios de la ejecución: personal, habilidades, ubicación, herramientas, equipos, materiales, prioridad, duración, fecha, notas y cierre.
- Las ventanas de edición ahora ocupan toda la pantalla.
- La aplicación y sus módulos utilizan todo el ancho disponible.

El proyecto es una PWA local. Los datos se guardan en el dispositivo mediante localStorage. El ZIP no es un APK compilado.
