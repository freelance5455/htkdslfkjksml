GOLF BUDDY — FOUR-COURSE + HANDICAP EDITION v7
======================================

FILES
- index.html: the app
- manifest.json: web-app metadata
- sw.js: offline caching for HTTPS-hosted/PWA use

FEATURES
- Simplified professional forest-green and lime interface with automatic light/dark theme
- Cleaner flat surfaces, consistent spacing, reduced decoration and clearer buttons
- Larger text and tap-friendly controls
- Clubhouse home dashboard with recent rounds and personal bests
- Bottom navigation: Home, Play, Stats, History
- Multiple players and 9/18-hole scoring
- Full hole-by-hole scorecard grid; tap a hole to jump to it
- Hole pars, score versus par and colour-coded score badges
- Built-in dropdown presets for Meyerton Golf Club, Maccauvlei Golf Club, Riviera on Vaal Country Club and Heron Banks Golf Course
- Each preset loads all 18 hole pars and white/men tee lengths in metres into the scorecard grid
- Course name appears in the top-right header while playing; choose another course from Setup
- Distances are sourced from published scorecards and converted to metres where needed; tee sets differ, so confirm the active tee and current club scorecard before play
- Hole-by-hole putts, fairways, greens in regulation and penalty tracking
- Nearby course finder using phone location and public OpenStreetMap/Overpass data
- Handicap tracker: save a starting handicap for each player; the app estimates an updated handicap after 3 complete 18-hole rounds using better score-to-par rounds
- Handicap data is stored locally and included in JSON backup/restore
- Round history, personal bests, local storage and JSON backup/restore
- Offline score entry after the app is loaded; course search requires internet

HTML-TO-APK NOTES
1. Use the converter's ZIP File to APK option and select the ZIP that contains
   index.html at the top level.
2. Set the app start page to index.html if asked.
3. Give location permission only if you want to use Find nearby.
4. If the converter has a setting for Internet access, enable it for course search.

LIMITATIONS
- Nearby course results depend on public OpenStreetMap data and service availability.
- Nearby course pars may be missing or incorrect; check them before playing. Built-in course presets use the listed white/men tee data, which can differ from current club scorecards or tee configurations.
- Round data is saved locally on this device/browser. Export a JSON backup regularly.
- The service worker generally works only when hosted over HTTPS. Some APK converters
  bundle the HTML locally and do not support service workers; local score saving still
  uses browser localStorage, but test offline behaviour on the installed APK.
- Handicap estimate is not an official WHS Handicap Index; it does not use course rating, slope rating or WHS score differentials. Nine-hole rounds are not used in the estimate.
- This is a web app project, not a prebuilt APK. It has not been tested on your phone.
