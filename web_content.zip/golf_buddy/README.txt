# Golf Buddy — polished phone-friendly scorecard

## Features
- A refreshed, mobile-first golf scorecard interface.
- Multiple players, with add, rename, and remove controls.
- 9-hole or 18-hole rounds, with par selection for each hole.
- Simple plus/minus stroke controls for each player on each hole.
- Saves completed rounds and lets you view or delete saved scorecards.
- Nearby golf-course popup uses phone location to list courses within 30 km.
- Selecting a course fills its name and available hole count, and imports hole pars when reliable OpenStreetMap data exists. Missing pars default to 4 and can be edited manually.
- Can be added to the Android home screen when hosted over HTTPS.

## Location use
The app does not track distance to the hole and has no map or pin feature. The optional **Find nearby** course picker requests browser location only when you tap it, to search for golf courses within 30 km. Allow location access and use an HTTPS-hosted version. Course names and pars are sourced from OpenStreetMap; hole-by-hole par data may be missing or incomplete, so review the scorecard before playing.

## Important limitations
- This is a web app prototype, not a native Android APK or a Google Play Store release.
- Saved rounds are stored locally in the browser on this device. Clearing browser data may erase them.
- The app interface and score features work offline once the page has been loaded, but initial hosting/install setup requires internet access.

## Try it on your Android phone
1. Download and unzip `golf_buddy_prototype.zip`.
2. For a quick preview, open `index.html` in a browser or HTML preview app. The nearby-course search needs an HTTPS-hosted version and internet access.
3. For a home-screen app experience, publish the files to an HTTPS static host such as GitHub Pages using your phone browser.
4. Open the hosted page in Chrome, open the ⋮ menu, then choose **Add to Home screen** or **Install app** if offered.

## Basic use
1. Open **Players & setup** to rename Player 1 or add your playing partners.
2. Choose 9 or 18 holes and enter an optional course name.
3. Tap **Start new round**.
4. On **Play round**, use + and − to record each player's strokes, select the hole, and adjust par as needed.
5. Tap **Save / finish round** to save the scorecard.
