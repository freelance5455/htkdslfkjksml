plugins {
    id("com.android.application")
}

android {
    namespace = "com.flappy.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.flappy.game"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
