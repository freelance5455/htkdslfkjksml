VICHIKA LAUNCHER — សេចក្ដីណែនាំ (ភាសាខ្មែរ)

អ្វីដែលមានក្នុង Project
- Mods: បន្ថែមឈ្មោះ Mod, ពណ៌នា និងតំណទាញយក។
- Servers: រក្សាទុកឈ្មោះ, Address និង Port។
- Download: បើកតំណ HTTP/HTTPS ក្នុង Browser របស់ Android។
- Custom UI: ផ្ទាំងពណ៌បែប Minecraft និងរចនាសម្រាប់ទូរស័ព្ទ។
- ទិន្នន័យ Mods/Servers រក្សាទុកក្នុងទូរស័ព្ទនេះ (localStorage)។

ចំណាំសំខាន់
នេះជាគម្រោង Android app ពិតប្រាកដដែលមាន WebView UI។ វាមិនមែនជា Minecraft launcher ដែលបើក/ដំណើរការ Minecraft ឬប្ដូរកំណែហ្គេមដោយស្វ័យប្រវត្តិទេ។ វាមិនមាន Mod download link ឬ Server ពិតជាមុនទេ ព្រោះអ្នកមិនទាន់ផ្ដល់តំណ/ព័ត៌មានទាំងនោះ។ បន្ថែមតែតំណដែលអ្នកទុកចិត្ត។ មិនមាន APK ដែលបាន build រួចនៅក្នុង ZIP នេះទេ។

របៀប Build APK លើកុំព្យូទ័រ (Android Studio)
1. Extract ZIP។
2. បើក Android Studio → Open → ជ្រើសថត VichikaLauncher។
3. រង់ចាំ Gradle Sync និងអនុញ្ញាតឱ្យទាញយក Android Gradle Plugin/SDK ប្រសិនបើសួរ។
4. ជ្រើស Build → Build Bundle(s) / APK(s) → Build APK(s)។
5. APK សាកល្បងស្ថិតនៅ app/build/outputs/apk/debug/app-debug.apk។

របៀបសាកល្បងលើ Android Phone
- AndroidIDE ចាស់ត្រូវបាន Archive ហើយលែងថែទាំ ដូច្នេះមិនណែនាំឱ្យប្រើជាជម្រើសសំខាន់ទេ។
- អ្នកអាចសាកល្បង IDE លើ Android ដែលគាំទ្រ Gradle project ប៉ុន្តែភាពឆបគ្នាអាស្រ័យលើកំណែ JDK, Gradle និង Android SDK។
- បើ Build error សូមផ្ញើរូប Screenshot នៃ error និងឈ្មោះកម្មវិធី IDE ដែលអ្នកប្រើ។

ការប្រើប្រាស់
1. បើក Vichika Launcher។
2. ចូល Mods → Add Mod → បញ្ចូលឈ្មោះ និង URL (បើមាន) → Save។
3. ចូល Servers → Add Server → បញ្ចូលឈ្មោះ, Address និង Port → Save។
4. ចូល Download → បញ្ចូលតំណ HTTPS/HTTP → Open Download Link។
5. បើបានឯកសារ .mcpack/.mcaddon សូមបើកឯកសារនោះ ហើយជ្រើស Minecraft ប្រសិនបើ Android បង្ហាញជម្រើស។

Project settings
- Package: com.vichika.launcher
- Minimum Android: 6.0 (API 23)
- Compile SDK: 35
- Version: 1.0
