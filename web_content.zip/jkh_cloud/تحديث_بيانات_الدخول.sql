-- نفّذ هذا الأمر مرة واحدة من Supabase > SQL Editor لتغيير حساب المدير الحالي
-- سيصبح اسم المستخدم AhmedYosf وكلمة المرور 8910
update public.staff_users
set username = 'AhmedYosf',
    password_hash = encode(extensions.digest('8910', 'sha256'), 'hex')
where username = 'admin';

-- تحقق من تغيير اسم المستخدم دون إظهار كلمة المرور
select name, username, role, active from public.staff_users where username = 'AhmedYosf';
