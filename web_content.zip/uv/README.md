# Unusual Vogues: shop + owner admin

Two things in one project:

1. **The shop** (`/`): built from your prototype screens. Splash, Shop, Product, Build Your Own, My Bag, Checkout, Payment Successful, Dashboard. Phone layout matches the prototype; on a laptop it becomes a full website.
2. **Your owner admin** (`/admin`): add any wear you design, set the price you want, upload photos. It appears on the shop immediately. Every order shows up here live and can also be sent to your phone.

## Run it on your computer
1. Install Node.js 18 or newer (nodejs.org).
2. In this folder run: `node server.js`
3. Shop: http://localhost:3000 · Admin: http://localhost:3000/admin
4. The first time you open `/admin`, choose your owner password.

No `npm install` needed. There are no dependencies.

## Put it online so customers can use it
Use any host that runs Node and keeps a disk: Railway, Render (paid disk), Fly.io, or a VPS.
* Start command: `node server.js`
* Set the `DATA_DIR` environment variable to a folder on a **persistent volume**. Your products, photos and orders live there. Without it they are lost on redeploy.
* Back up that folder from time to time.

## Get every order on your phone
Open `/admin` > Settings > "Order alerts". Turn on any you like and press **Send test alert**.
* **In the admin page**: live pop-up, sound and a red counter while the page is open (add it to your phone's home screen).
* **Telegram** (best): free and instant even when the app is closed.
* **WhatsApp**: free via CallMeBot, one-time activation.
* **Email**: via Resend.
* **Webhook**: for Zapier or Make.

## Get paid
* **Cards**: create a Paystack account and paste the public and secret keys in Settings > Getting paid. Payments are verified on the server before an order is marked "Paid online".
* **Bank transfer**: fill in your account details. Customers see them after ordering.
* Until a Paystack key is added, card choices place the order as "Awaiting payment". Nothing is charged.

## Notes
* Prices are always recalculated on the server, so customers cannot change them.
* The product photos were cut from your prototype video, so they are small. Upload the original photos in Admin > My wear > Edit to make the shop sharp.
* Delivery fees, the custom-piece price and promo codes are in Settings. Starting values are ₦3,000 standard, ₦6,000 express, ₦45,000 custom. Change them to yours.
* Customer details, bag and wishlist are stored in the customer's browser. Orders are stored on your server.
