(() => {
'use strict';

/* ---------------------------------------------------------------- utils */
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (n) => '₦' + Number(n || 0).toLocaleString('en-NG');
const uid = () => Math.random().toString(36).slice(2, 10);
const LS = {
  get(k, d) { try { const v = JSON.parse(localStorage.getItem('uv:' + k)); return v == null ? d : v; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('uv:' + k, JSON.stringify(v)); } catch { toast('Storage is full. Clear some saved designs.', { bad: true }); } },
};
const ICONS = {
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  bag: '<path d="M6 8h12l-1 12H7L6 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
  home: '<path d="M3 11 12 3l9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
  back: '<path d="M19 12H5m6-6-6 6 6 6"/>',
  heart: '<path d="M12 20s-7-4.4-9-9.3C1.6 7 4 4 7 4c2 0 3.5 1 5 3 1.5-2 3-3 5-3 3 0 5.4 3 4 6.7C19 15.6 12 20 12 20Z"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z"/>',
  pin: '<path d="M12 21s7-6 7-12a7 7 0 0 0-14 0c0 6 7 12 7 12Z"/><circle cx="12" cy="9" r="2.5"/>',
  dots: '<circle cx="12" cy="5" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="12" cy="19" r="1.3"/>',
  box: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.2-2.5 1.6-2.5H17a4 4 0 0 0 4-4C21 6.5 17 3 12 3Z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>',
  bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4l2-2Z"/><path d="M10 21h4"/>',
  gear: '<path d="M12.2 2h-.4a2 2 0 0 0-2 2v.2a2 2 0 0 1-1 1.7l-.4.3a2 2 0 0 1-2 0l-.2-.1a2 2 0 0 0-2.7.8l-.2.4a2 2 0 0 0 .7 2.7l.2.1a2 2 0 0 1 1 1.7v.5a2 2 0 0 1-1 1.8l-.2.1a2 2 0 0 0-.7 2.7l.2.4a2 2 0 0 0 2.7.7l.2-.1a2 2 0 0 1 2 0l.4.3a2 2 0 0 1 1 1.7v.2a2 2 0 0 0 2 2h.4a2 2 0 0 0 2-2v-.2a2 2 0 0 1 1-1.7l.4-.3a2 2 0 0 1 2 0l.2.1a2 2 0 0 0 2.7-.7l.2-.4a2 2 0 0 0-.7-2.7l-.2-.1a2 2 0 0 1-1-1.8v-.5a2 2 0 0 1 1-1.7l.2-.1a2 2 0 0 0 .7-2.7l-.2-.4a2 2 0 0 0-2.7-.8l-.2.1a2 2 0 0 1-2 0l-.4-.3a2 2 0 0 1-1-1.7V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  chev: '<path d="m9 6 6 6-6 6"/>',
  arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
  cardcheck: '<rect x="2.5" y="5" width="19" height="13" rx="2"/><path d="M2.5 10h19"/><circle cx="8" cy="17" r="4.2" fill="#C8FF00"/><path d="m6 17 1.5 1.5L10.2 15.6"/>',
  person: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
  upload: '<path d="M12 16V4m-5 5 5-5 5 5M4 20h16"/>',
};
const ic = (n, cls = '') => `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;
const money = fmt;

async function api(path, opts = {}) {
  const r = await fetch(path, { method: opts.method || (opts.body ? 'POST' : 'GET'), headers: opts.body ? { 'Content-Type': 'application/json' } : undefined, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Something went wrong. Try again.');
  return j;
}

/* ---------------------------------------------------------------- state */
const S = {
  products: null, config: null,
  bag: LS.get('bag', []), wish: LS.get('wish', []), profile: LS.get('profile', null),
  orders: LS.get('orders', []), customs: LS.get('customs', []),
  cat: 'All', q: '', promo: '', discount: 0, delivery: 'standard', pay: 'visa',
  sel: {}, build: { base: 'Black', print: '/assets/prints/print1.jpg', imageData: null, text: '', position: 'Front', size: '' },
};
const save = {
  bag: () => LS.set('bag', S.bag), wish: () => LS.set('wish', S.wish), profile: () => LS.set('profile', S.profile),
  orders: () => LS.set('orders', S.orders), customs: () => LS.set('customs', S.customs),
};
const CUSTOM_HEX = { Black: '#000000', Olive: '#6b7020', Lime: '#C8FF00' };
const PRINTS = ['/assets/prints/print1.jpg', '/assets/prints/print2.jpg', '/assets/prints/print3.jpg', '/assets/prints/print4.jpg'];
const bagCount = () => S.bag.reduce((n, i) => n + i.qty, 0);
const prod = (id) => (S.products || []).find((p) => p.id === id);
const app = $('#app');

/* ---------------------------------------------------------------- ui helpers */
let toastT;
function toast(msg, o = {}) {
  document.querySelectorAll('.toast').forEach((t) => t.remove());
  const el = document.createElement('div'); el.className = 'toast' + (o.bad ? ' bad' : ''); el.setAttribute('role', 'status'); el.dataset.t = Date.now();
  el.innerHTML = `<span>${esc(msg)}</span>` + (o.action ? `<button>${esc(o.action.label)}</button>` : '');
  if (o.action) el.querySelector('button').onclick = () => { o.action.fn(); el.remove(); };
  document.body.appendChild(el); clearTimeout(toastT); toastT = setTimeout(() => el.remove(), o.ms || 3200);
}
function modal(html) {
  closeModal();
  const s = document.createElement('div'); s.className = 'scrim'; s.id = 'scrim';
  s.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
  s.addEventListener('click', (e) => { if (e.target === s) closeModal(); });
  document.body.appendChild(s); const f = s.querySelector('input,textarea,select'); if (f) f.focus();
  return s;
}
const closeModal = () => { const s = $('#scrim'); if (s) s.remove(); const d = $('.drawer'); if (d) d.remove(); };
const goBack = () => { if (history.length > 1) history.back(); else location.hash = '#/shop'; };
const dots = (p) => `<div class="dots">${(p.colors || []).slice(0, 3).map((c) => `<span class="dot" style="background:${esc(c.hex)}" title="${esc(c.name)}"></span>`).join('')}</div>`;

function topbar(active, opts = {}) {
  const nav = [['#/shop', 'Shop', 'shop'], ['#/build', 'Build your own', 'build'], ['#/orders', 'My orders', 'orders'], ['#/profile', 'Profile', 'profile']];
  const name = (S.config && S.config.store.name) || 'Unusual Vogues';
  const lead = opts.back ? `<button class="icon-btn ring menu-btn" data-act="back" aria-label="Back">${ic('back')}</button>` : `<button class="icon-btn menu-btn" data-act="menu" aria-label="Open menu">${ic('menu')}</button>`;
  return `<header class="top ${opts.back ? 'minimal' : ''}">
    ${lead}
    <a class="logo" href="#/shop" aria-label="${esc(name)} home"><img src="/assets/logo.png" alt=""><span>${esc(name)}</span></a>
    <nav class="nav" aria-label="Main">${nav.map((n) => `<a href="${n[0]}" class="${active === n[2] ? 'on' : ''}">${n[1]}</a>`).join('')}</nav>
    <div class="acts"><a class="icon-btn" href="#/search" aria-label="Search">${ic('search')}</a>
    <a class="icon-btn" href="#/bag" aria-label="Bag, ${bagCount()} items">${ic('bag')}${bagCount() ? `<span class="badge">${bagCount()}</span>` : ''}</a></div></header>`;
}
const pageHead = (title, right = '') => `<div class="page-head"><button class="icon-btn ring" data-act="back" aria-label="Back">${ic('back')}</button><h1>${esc(title)}</h1>${right || '<span></span>'}</div>`;
function tabbar(active) {
  const t = (h, k, icon, label, extra = '') => `<a class="tab ${active === k ? 'on' : ''} ${k === 'build' ? 'cust' : ''}" href="${h}">${k === 'build' ? `<span class="plus">${ic('plus')}</span>` : ic(icon)}<span>${label}</span>${extra}</a>`;
  return `<nav class="tabbar" aria-label="Main">${t('#/shop', 'shop', 'home', 'Home')}${t('#/search', 'search', 'search', 'Search')}${t('#/build', 'build', 'plus', 'Customs')}${t('#/bag', 'bag', 'bag', 'Bag', bagCount() ? `<span class="badge">${bagCount()}</span>` : '')}${t('#/profile', 'profile', 'user', 'Profile')}</nav>`;
}
function productCard(p) {
  return `<a class="pcard" href="#/product/${esc(p.id)}"><div class="ph"><img src="${esc(p.images[0])}" alt="${esc(p.name)}" loading="lazy">${p.soldOut ? '<span class="sold">Sold out</span>' : ''}</div>
    <div class="meta"><h3>${esc(p.name)}</h3><div class="price">${fmt(p.price)}</div>${dots(p)}</div></a>`;
}

/* ---------------------------------------------------------------- views */
function viewSplash() {
  const c = S.config.store;
  return { tabs: false, html: `<section class="splash"><img class="mark" src="/assets/logo.png" alt="UV"><h1>${esc(c.name).replace(' ', '<br>')}</h1><p>${esc(c.tagline)}</p><div class="art" role="img" aria-label="Model in a black hoodie"></div>
    <div class="go"><button class="btn" data-act="enter">Enter The Drop ${ic('arrow')}</button></div></section>` };
}
function viewShop() {
  const list = S.products || [];
  const cats = ['All', ...new Set(list.map((p) => p.category))];
  if (!cats.includes(S.cat)) S.cat = 'All';
  const shown = S.cat === 'All' ? list : list.filter((p) => p.category === S.cat);
  return { tabs: 'shop', html: `${topbar('shop')}<div class="chips" role="tablist">${cats.map((c) => `<button class="chip ${c === S.cat ? 'on' : ''}" data-act="cat" data-v="${esc(c)}">${esc(c)}</button>`).join('')}<a class="chip" href="#/build">Custom</a></div>
    ${shown.length ? `<div class="grid">${shown.map(productCard).join('')}</div>` : `<div class="empty"><h2>New drop loading</h2><p>Nothing here yet. Check back soon.</p></div>`}` };
}
function viewSearch() {
  const q = S.q.trim().toLowerCase();
  const res = (S.products || []).filter((p) => !q || p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
  return { tabs: 'search', html: `${topbar('search')}<div class="search-in">${ic('search')}<input class="field" id="q" type="search" placeholder="Search hoodies, pants, tees" value="${esc(S.q)}" aria-label="Search products"></div>
    <div id="results">${resultsHtml(res)}</div>` };
}
const resultsHtml = (res) => res.length ? `<div class="grid">${res.map(productCard).join('')}</div>` : `<div class="empty"><h2>No match</h2><p>Try another word, like hoodie or cargo.</p></div>`;

function viewProduct(id) {
  const p = prod(id);
  if (!p) return { tabs: false, html: `${pageHead('Not found')}<div class="empty"><h2>Gone</h2><p>This piece is no longer available.</p><p><a class="link" href="#/shop">Back to shop</a></p></div>` };
  if (!S.sel.id || S.sel.id !== id) S.sel = { id, size: p.sizes.includes('M') ? 'M' : p.sizes[0], color: p.colors[0] ? p.colors[0].name : '', i: 0 };
  const liked = S.wish.includes(id);
  return { tabs: false, html: `<div class="pd"><div class="hero"><div class="over"><button class="icon-btn" data-act="back" aria-label="Back">${ic('back')}</button><button class="icon-btn heart ${liked ? 'on' : ''}" data-act="wish" data-v="${esc(id)}" aria-label="Save to wishlist" aria-pressed="${liked}">${ic('heart')}</button></div>
    <div class="slides" id="slides">${p.images.map((u) => `<img src="${esc(u)}" alt="${esc(p.name)}">`).join('')}</div>
    ${p.images.length > 1 ? `<div class="pager" id="pager">${p.images.map((_, i) => `<i class="${i === 0 ? 'on' : ''}"></i>`).join('')}</div>` : ''}</div>
    <div class="sheet"><div class="tt"><h1>${esc(p.name)}</h1><span class="pr">${fmt(p.price)}</span></div>
    <p class="desc">${esc(p.description)}</p>
    <h3>Size</h3><div class="sizes" role="radiogroup" aria-label="Size">${p.sizes.map((s) => `<button class="size ${s === S.sel.size ? 'on' : ''}" data-act="size" data-v="${esc(s)}" role="radio" aria-checked="${s === S.sel.size}">${esc(s)}</button>`).join('')}</div>
    ${p.colors.length ? `<h3>Color</h3><div class="colors" role="radiogroup" aria-label="Color">${p.colors.map((c) => `<button class="colopt ${c.name === S.sel.color ? 'on' : ''}" data-act="color" data-v="${esc(c.name)}" role="radio" aria-checked="${c.name === S.sel.color}"><i style="background:${esc(c.hex)}"></i>${esc(c.name)}</button>`).join('')}</div>` : ''}
    <div class="cta-bar"><button class="btn" data-act="addbag" data-v="${esc(id)}" ${p.soldOut ? 'disabled' : ''}>${p.soldOut ? 'Sold out' : 'Add to Bag'}</button></div></div></div>` };
}

function viewBuild() {
  const b = S.build; const cfg = S.config;
  const thumb = (src, on, extra = '') => `<button class="print ${on ? 'on' : ''}" data-act="print" data-v="${esc(src)}" aria-label="Choose graphic" aria-pressed="${on}"><img src="${esc(src)}" alt="${extra}"></button>`;
  const pv = b.imageData || b.print;
  return { tabs: false, html: `${topbar('build', { back: true })}<div class="build"><h2 class="t">Build your own</h2><p class="sub">Create something different</p>
    <h3>1. Base Color</h3><div class="swatches" role="radiogroup" aria-label="Base color">${Object.entries(CUSTOM_HEX).map(([n, h]) => `<button class="sw ${n === b.base ? 'on' : ''}" style="background:${h}" data-act="base" data-v="${n}" role="radio" aria-checked="${n === b.base}" aria-label="${n}"></button>`).join('')}</div>
    <h3>2. Print / Graphic</h3><p class="label2">Upload Your Design</p>
    <div class="prints"><button class="print up ${b.imageData ? 'on' : ''}" data-act="upload" aria-label="Upload your own design">${b.imageData ? `<img src="${esc(b.imageData)}" alt="Your upload">` : `${ic('upload')}<span>Upload</span>`}</button>${PRINTS.map((p) => thumb(p, !b.imageData && b.print === p)).join('')}</div>
    <input type="file" id="file" accept="image/png,image/jpeg,image/webp" hidden>
    <h3>3. Add Custom Text</h3><div class="inwrap"><input class="field" id="btext" maxlength="20" placeholder="Enter your text..." value="${esc(b.text)}" aria-label="Custom text"><small id="cnt">${b.text.length}/20</small></div>
    <h3>4. Patch Position</h3><div class="radios" role="radiogroup" aria-label="Patch position">${['Front', 'Back'].map((p) => `<button class="radio ${b.position === p ? 'on' : ''}" data-act="pos" data-v="${p}" role="radio" aria-checked="${b.position === p}"><span>${p}</span></button>`).join('')}</div>
    <h3>5. Size</h3><div class="sizes" role="radiogroup" aria-label="Size">${cfg.sizes.map((s) => `<button class="size ${b.size === s ? 'on' : ''}" data-act="bsize" data-v="${s}" role="radio" aria-checked="${b.size === s}">${s}</button>`).join('')}</div>
    <div class="preview"><div class="pv" style="background:${CUSTOM_HEX[b.base]}"><img src="${esc(pv)}" alt=""></div><div><b>Custom UV Piece &middot; ${fmt(cfg.customPrice)}</b><span>${b.base}, ${b.position.toLowerCase()} patch${b.text ? `, “${esc(b.text)}”` : ''}</span></div></div>
    <div class="cta-bar"><button class="btn" data-act="savecustom">Save Custom</button></div></div>` };
}

function syncBag() {
  if (!S.products) return;
  let changed = false;
  S.bag = S.bag.filter((i) => { if (i.type === 'custom') return true; const p = prod(i.productId); if (!p || p.soldOut) { changed = true; return false; } if (p.price !== i.price) { i.price = p.price; changed = true; } return true; });
  if (changed) { save.bag(); toast('Some items were updated or are no longer available.'); }
}
const variantText = (i) => i.type === 'custom' ? `${i.base} / ${i.size} · ${i.position}${i.text ? ` · “${esc(i.text)}”` : ''}` : `${esc(i.color)} / ${esc(i.size)}`;
const subtotal = () => S.bag.reduce((s, i) => s + i.price * i.qty, 0);
function viewBag() {
  syncBag();
  const sub = subtotal(); const total = Math.max(0, sub - S.discount);
  if (!S.bag.length) return { tabs: false, html: `${pageHead('My Bag')}<div class="empty"><h2>Your bag is empty</h2><p>Pick something unusual.</p><p style="margin-top:18px"><a class="btn" href="#/shop" style="max-width:260px;margin:auto">Shop the drop</a></p></div>` };
  return { tabs: false, html: `${pageHead('My Bag', `<button class="icon-btn" data-act="clearbag" aria-label="Empty bag">${ic('trash')}</button>`)}
    <div class="bag-items">${S.bag.map((i) => `<div class="bitem"><img src="${esc(i.image || '/assets/logo.png')}" alt="" style="${i.type === 'custom' ? 'background:' + CUSTOM_HEX[i.base] + ';object-fit:contain;padding:14%' : ''}"><h3>${esc(i.name)}</h3><div class="v">${variantText(i)}</div><div class="pp">${fmt(i.price)}</div>
      <div class="qty"><button data-act="qty" data-id="${i.id}" data-d="-1" aria-label="Less">−</button><b>${i.qty}</b><button data-act="qty" data-id="${i.id}" data-d="1" aria-label="More">+</button><button class="rm" data-act="rm" data-id="${i.id}" style="border:0;width:auto;height:auto;display:block">Remove</button></div></div>`).join('')}</div>
    <div class="sum"><div class="row"><span>Subtotal</span><span>${fmt(sub)}</span></div>
      <div class="row"><span>Shipping</span><span class="mut" style="font-size:15px">Chosen at checkout</span></div>
      ${S.discount ? `<div class="row"><span>Promo ${esc(S.promo)}</span><span style="color:var(--lime)">−${fmt(S.discount)}</span></div>` : ''}
      <div><div class="row" style="margin-bottom:8px"><span>Promo Code</span></div><div class="promo"><input id="promo" placeholder="Enter code" value="${esc(S.promo)}" aria-label="Promo code" autocapitalize="characters"><button class="btn ghost" data-act="applypromo">Apply</button></div><div class="msg" id="pmsg"></div></div>
      <div class="row big"><span>Total</span><b>${fmt(total)}</b></div></div>
    <div class="pad"><div class="cta-bar sticky-d" style="position:static;padding:18px 0 0;background:none"><a class="btn" href="#/checkout">Proceed to Checkout ${ic('arrow')}</a></div></div>` };
}

function profileComplete() { const p = S.profile; return !!(p && p.name && p.phone && p.address); }
function totals() {
  const sub = subtotal(); const ship = S.config.shipping[S.delivery]; const fee = ship ? ship.fee : 0;
  return { sub, fee, total: Math.max(0, sub - S.discount) + fee };
}
function viewCheckout() {
  if (!S.bag.length) { location.replace('#/bag'); return { tabs: false, html: '' }; }
  const p = S.profile || {}; const t = totals(); const cfg = S.config;
  const pm = (k, inner, label) => `<button class="pm ${S.pay === k ? 'on' : ''}" data-act="pay" data-v="${k}" role="radio" aria-checked="${S.pay === k}" aria-label="${label}">${inner}</button>`;
  return { tabs: false, html: `${pageHead('Checkout', `<button class="icon-btn" data-act="clearbag" aria-label="Empty bag">${ic('trash')}</button>`)}
    <div class="sec"><h2>${ic('person')} Shipping Information</h2>
      ${profileComplete() ? `<div class="ship"><span>${ic('phone')}</span><div><div class="n">${esc(p.name)}<br>${esc(p.phone)}</div></div><button class="icon-btn" data-act="editprofile" aria-label="Edit shipping details">${ic('dots')}</button>
        <span>${ic('pin')}</span><div class="a">${esc(p.address)}${p.city ? '<br>' + esc(p.city) : ''}</div><span></span></div>`
        : `<button class="btn ghost" data-act="editprofile" style="width:100%">Add delivery details</button>`}</div>
    <div class="sec"><h2>Delivery Options</h2><div class="deliv" role="radiogroup" aria-label="Delivery">${['standard', 'express'].map((k) => `<button class="dopt ${S.delivery === k ? 'on' : ''}" data-act="deliv" data-v="${k}" role="radio" aria-checked="${S.delivery === k}"><span class="rd"></span><span><b>${esc(cfg.shipping[k].label)}</b><small>${esc(cfg.shipping[k].days)}</small></span><em>${fmt(cfg.shipping[k].fee)}</em></button>`).join('')}</div></div>
    <div class="sec"><h2>Payment Method</h2><div class="pay" role="radiogroup" aria-label="Payment method">
      ${pm('apple', 'Apple Pay', 'Apple Pay')}${pm('visa', '<span class="visa">VISA</span>', 'Visa')}${pm('mastercard', '<span class="mc"><i></i><i></i></span>', 'Mastercard')}${pm('transfer', 'Bank transfer', 'Bank transfer')}</div>
      <p class="note">${S.pay === 'transfer' ? 'You will see our account details after you place the order.' : cfg.paystackKey ? 'You will pay securely with your card in the next step.' : 'Card payment is not switched on yet. Your order is held until payment is confirmed.'}</p></div>
    <div class="sec"><div class="sum" style="margin:0;border:0;padding:0"><div class="row"><span>Subtotal</span><span>${fmt(t.sub)}</span></div>${S.discount ? `<div class="row"><span>Promo</span><span style="color:var(--lime)">−${fmt(S.discount)}</span></div>` : ''}<div class="row"><span>Delivery</span><span>${fmt(t.fee)}</span></div><div class="row big"><span>Total</span><b>${fmt(t.total)}</b></div></div></div>
    <div class="pad"><div class="cta-bar" style="position:static;padding:18px 0 0;background:none"><button class="btn" id="placeBtn" data-act="place">Proceed to Checkout ${ic('arrow')}</button></div></div>` };
}

function viewSuccess() {
  const last = LS.get('last', null); const paid = last && /^Paid/.test(last.paymentStatus);
  if (!last) { location.replace('#/shop'); return { tabs: false, html: '' }; }
  const bank = last.bank && (last.bank.accountNumber || last.bank.bankName);
  const transferNoDetails = last.bank && !bank;
  return { tabs: false, html: `<div class="page-head"><button class="icon-btn ring" data-act="back" aria-label="Back">${ic('back')}</button><span></span><span></span></div>
    <div class="done"><div class="ico">${ic('cardcheck')}</div><h1>${paid ? 'Payment Successful!' : 'Order Received!'}</h1>
    <p>${paid ? 'Your payment has been processed successfully.' : 'We have your order and the team has been notified.'}</p><span class="oid">${esc(last.id)}</span>
    <p class="small">Thank you for your purchase!<br>${paid ? 'Your order is now being prepared.' : bank ? 'Pay by transfer so we can start preparing it.' : transferNoDetails ? 'We will contact you shortly with our account details.' : 'We will confirm payment and start preparing it.'}</p>
    ${bank ? `<div class="bankbox"><div>Amount: <b>${fmt(last.total)}</b></div><div>Bank: <b>${esc(last.bank.bankName)}</b></div><div>Account name: <b>${esc(last.bank.accountName)}</b></div><div>Account number: <b>${esc(last.bank.accountNumber)}</b></div><div class="mut">${esc(last.bank.note || '')}</div></div>` : ''}
    ${last.whatsapp ? `<p style="margin-top:20px"><a class="link" href="https://wa.me/${esc(String(last.whatsapp).replace(/\D/g, ''))}?text=${encodeURIComponent('Hi, my order ID is ' + last.id)}" target="_blank" rel="noopener">Message us on WhatsApp</a></p>` : ''}
    <a class="btn" href="#/shop">Home</a></div>` };
}

function initials(n) { return (n || 'UV').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase(); }
function viewProfile() {
  const p = S.profile; const row = (h, icon, label, cls = '') => `<a class="mrow ${cls}" href="${h}">${ic(icon)}<span>${label}</span>${ic('chev')}</a>`;
  return { tabs: 'profile', html: `${pageHead('Dashboard', `<a class="icon-btn" href="#/settings" aria-label="Settings">${ic('gear')}</a>`).replace(/<button class="icon-btn ring"[\s\S]*?<\/button>/, '<span></span>')}
    <div class="who"><div class="avatar" aria-hidden="true">${esc(initials(p && p.name))}</div><div><h2>${esc((p && p.name) || 'Guest')}</h2><div class="st">${p ? 'Active' : 'Not signed in'}</div></div></div>
    <div class="stats"><div><b>${S.orders.length}</b><span>Orders</span></div><div><b>${S.wish.length}</b><span>Wishlist</span></div><div><b>${S.customs.length}</b><span>Custom Drops</span></div></div>
    <div class="menu">${row('#/orders', 'box', 'My Orders')}${row('#/customs', 'palette', 'My Custom Designs')}${row('#/wishlist', 'heart', 'Wishlist')}${row('#/addresses', 'pin', 'Addresses')}${row('#/notifications', 'bell', 'Notifications')}${row('#/settings', 'gear', 'Settings')}
    <button class="mrow out" data-act="logout">${ic('out')}<span>Logout</span>${ic('chev')}</button></div>` };
}
const subHead = (t) => pageHead(t);
function viewWishlist() {
  const list = (S.products || []).filter((p) => S.wish.includes(p.id));
  return { tabs: false, html: `${subHead('Wishlist')}${list.length ? `<div class="grid" style="margin-top:12px">${list.map(productCard).join('')}</div>` : `<div class="empty"><h2>Nothing saved</h2><p>Tap the heart on a piece to save it here.</p></div>`}` };
}
function viewCustoms() {
  return { tabs: false, html: `${subHead('My Custom Designs')}${S.customs.length ? `<div class="list">${S.customs.map((c) => `<div class="ocard"><div class="ccard"><div class="pv" style="background:${CUSTOM_HEX[c.base]}"><img src="${esc(c.imageData || c.print)}" alt=""></div><div class="x"><b>Custom UV Piece</b><div class="mut">${esc(c.base)} · ${esc(c.position)} patch · ${esc(c.size)}${c.text ? ` · “${esc(c.text)}”` : ''}</div><div class="price" style="color:var(--lime)">${fmt(S.config.customPrice)}</div></div></div>
    <div style="display:flex;gap:12px;align-items:center"><button class="btn ghost" data-act="addcustom" data-id="${c.id}">Add to bag</button><button class="link" data-act="delcustom" data-id="${c.id}" style="color:var(--mut)">Delete</button></div></div>`).join('')}</div>` : `<div class="empty"><h2>No designs yet</h2><p>Build your own piece and it will be saved here.</p><p style="margin-top:18px"><a class="btn" href="#/build" style="max-width:260px;margin:auto">Build your own</a></p></div>`}` };
}
function viewAddresses() {
  const p = S.profile;
  return { tabs: false, html: `${subHead('Addresses')}<div class="list">${profileComplete() ? `<div class="ocard"><b>${esc(p.name)}</b><div>${esc(p.address)}${p.city ? ', ' + esc(p.city) : ''}</div><div class="mut">${esc(p.phone)}${p.email ? ' · ' + esc(p.email) : ''}</div><div><button class="link" data-act="editprofile">Edit</button></div></div>` : `<div class="empty"><h2>No address</h2><p>Add where we should deliver.</p><p style="margin-top:18px"><button class="btn" data-act="editprofile" style="max-width:260px;margin:auto">Add address</button></p></div>`}</div>` };
}
function viewSettings() {
  const p = S.profile || {}; const w = S.config.store.whatsapp;
  return { tabs: false, html: `${subHead('Settings')}<div class="list"><div class="ocard"><b>Your details</b><div class="mut">${p.name ? esc(p.name) + ' · ' + esc(p.phone || '') : 'Not set yet'}</div><div><button class="link" data-act="editprofile">Edit details</button></div></div>
    ${w ? `<div class="ocard"><b>Need help?</b><div class="mut">Chat with us about orders and sizing.</div><div><a class="link" href="https://wa.me/${esc(w.replace(/\D/g, ''))}" target="_blank" rel="noopener">Open WhatsApp</a></div></div>` : ''}
    <div class="ocard"><b>Saved on this device</b><div class="mut">Your bag, wishlist, designs and details are stored in this browser.</div><div><button class="link" data-act="logout" style="color:var(--red)">Clear everything</button></div></div></div>` };
}

async function viewOrders() {
  if (!S.orders.length) return { tabs: false, html: `${subHead('My Orders')}<div class="empty"><h2>No orders yet</h2><p>Your orders will show up here.</p></div>` };
  app.innerHTML = `${subHead('My Orders')}<div class="loading">Loading your orders…</div>`;
  const list = await fetchOrders();
  return { tabs: false, html: `${subHead('My Orders')}<div class="list">${list.length ? list.map((o) => `<div class="ocard"><div class="h"><b>${esc(o.id)}</b><span class="pill ${o.status === 'Delivered' ? 'lime' : ''}">${esc(o.status)}</span></div>
    ${o.items.map((i) => `<div class="oi">${i.image ? `<img src="${esc(i.image)}" alt="">` : ''}<span>${i.qty}× ${esc(i.name)} <span class="mut">(${esc([i.size, i.color].filter(Boolean).join(', '))})</span></span></div>`).join('')}
    <div class="h"><span class="mut">${new Date(o.createdAt).toLocaleDateString('en-NG', { day: 'numeric', month: 'short', year: 'numeric' })} · ${esc(o.delivery)}</span><b>${fmt(o.total)}</b></div><span class="pill ${/^Paid/.test(o.paymentStatus) ? 'lime' : 'warn'}" style="justify-self:start">${esc(o.paymentStatus)}</span></div>`).join('') : '<div class="empty"><p>We could not find your orders. Check your phone number in Settings.</p></div>'}</div>` };
}
async function fetchOrders() {
  const byPhone = {}; S.orders.forEach((o) => { (byPhone[o.phone] = byPhone[o.phone] || []).push(o.id); });
  const out = [];
  for (const [phone, ids] of Object.entries(byPhone)) { try { out.push(...await api('/api/orders/lookup', { body: { ids, phone } })); } catch { /* offline */ } }
  return out.sort((a, b) => b.createdAt - a.createdAt);
}
async function viewNotifications() {
  app.innerHTML = `${subHead('Notifications')}<div class="loading">Checking for updates…</div>`;
  const list = S.orders.length ? await fetchOrders() : [];
  const msg = { New: 'was received', Confirmed: 'is confirmed', Packed: 'is packed', Shipped: 'is on the way', Delivered: 'was delivered', Cancelled: 'was cancelled' };
  return { tabs: false, html: `${subHead('Notifications')}${list.length ? `<div class="list">${list.map((o) => `<div class="ocard"><div class="h"><b>Order ${esc(o.id)} ${msg[o.status] || ''}</b></div><div class="mut">${esc(o.status)} · ${fmt(o.total)}</div></div>`).join('')}</div>` : `<div class="empty"><h2>All quiet</h2><p>Order updates will appear here.</p></div>`}` };
}

/* ---------------------------------------------------------------- router */
let renderToken = 0;
async function render() {
  const token = ++renderToken;
  closeModal();
  document.querySelectorAll('.toast').forEach((t) => { if (Date.now() - Number(t.dataset.t) > 700) t.remove(); });
  const h = location.hash.replace(/^#\/?/, ''); const [page, arg] = h.split('/');
  let v;
  try {
    if (!S.config) {
      app.innerHTML = '<div class="loading">Loading…</div>';
      const [config, products] = await Promise.all([api('/api/config'), api('/api/products')]);
      S.config = config; S.products = products;
    }
    switch (page || '') {
      case '': v = sessionStorage.getItem('uv:entered') ? viewShop() : viewSplash(); break;
      case 'shop': v = viewShop(); break;
      case 'search': v = viewSearch(); break;
      case 'build': v = viewBuild(); break;
      case 'product': v = viewProduct(arg); break;
      case 'bag': v = viewBag(); break;
      case 'checkout': v = viewCheckout(); break;
      case 'success': v = viewSuccess(); break;
      case 'profile': v = viewProfile(); break;
      case 'orders': v = await viewOrders(); break;
      case 'customs': v = viewCustoms(); break;
      case 'wishlist': v = viewWishlist(); break;
      case 'addresses': v = viewAddresses(); break;
      case 'notifications': v = await viewNotifications(); break;
      case 'settings': v = viewSettings(); break;
      default: v = viewShop();
    }
  } catch (e) {
    app.innerHTML = `<div class="empty"><h2>Offline</h2><p>${esc(e.message)}</p><p style="margin-top:16px"><button class="btn" onclick="location.reload()" style="max-width:220px;margin:auto">Try again</button></p></div>`; return;
  }
  if (token !== renderToken) return;
  app.className = v.tabs ? 'has-tabs' : '';
  app.innerHTML = v.html + (v.tabs ? tabbar(v.tabs) : '');
  window.scrollTo(0, 0);
  if (page === 'product') bindSlides();
  document.title = (S.config.store.name || 'Unusual Vogues') + (page === 'bag' ? ' · Bag' : '');
  if (['', 'shop', 'search'].includes(page || '') && !(page === '' && !sessionStorage.getItem('uv:entered'))) refreshProducts();
}
async function refreshProducts() {
  try {
    const fresh = await api('/api/products');
    if (JSON.stringify(fresh) !== JSON.stringify(S.products)) {
      S.products = fresh;
      const g = $('.grid'); if (g && !$('#q')) { const h = location.hash; if (!h.startsWith('#/product')) render(); }
    }
  } catch { /* keep cached */ }
}
function bindSlides() {
  const s = $('#slides'), pg = $('#pager'); if (!s || !pg) return;
  s.addEventListener('scroll', () => { const i = Math.round(s.scrollLeft / s.clientWidth); [...pg.children].forEach((d, n) => d.classList.toggle('on', n === i)); }, { passive: true });
}

/* ---------------------------------------------------------------- actions */
function addToBag(item) {
  const same = S.bag.find((i) => i.type === 'product' && item.type === 'product' && i.productId === item.productId && i.size === item.size && i.color === item.color);
  if (same) same.qty = Math.min(20, same.qty + 1); else S.bag.push(item);
  S.discount = 0; save.bag();
}
function profileForm() {
  const p = S.profile || {};
  const f = (id, label, val, type = 'text', ph = '') => `<label class="label2" for="${id}" style="display:block">${label}</label><input class="field" id="${id}" type="${type}" value="${esc(val || '')}" placeholder="${ph}" autocomplete="${id.replace('pf-', '')}">`;
  return modal(`<h2>Delivery details</h2><div class="grid2">${f('pf-name', 'Full name', p.name, 'text', 'Jane D.')}${f('pf-tel', 'Phone number', p.phone, 'tel', '0811 345 6789')}${f('pf-email', 'Email (for receipts)', p.email, 'email', 'you@email.com')}
    <label class="label2" for="pf-address" style="display:block">Delivery address</label><textarea class="field" id="pf-address" placeholder="House number, street, area">${esc(p.address || '')}</textarea>${f('pf-city', 'City / State', p.city, 'text', 'Lagos, Nigeria')}</div>
    <div style="margin-top:16px;display:grid;gap:10px"><button class="btn" data-act="saveprofile">Save details</button><button class="link" data-act="close" style="padding:8px">Cancel</button></div>`);
}
function resizeImage(file, max = 900) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onerror = () => reject(new Error('Could not read that file'));
    r.onload = () => { const img = new Image(); img.onerror = () => reject(new Error('That file is not a valid image')); img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      let out = file.type === 'image/png' ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', 0.86);
      if (out.length > 1.6e6) out = c.toDataURL('image/jpeg', 0.82); resolve(out);
    }; img.src = r.result; };
    r.readAsDataURL(file);
  });
}
const payloadItems = () => S.bag.map((i) => i.type === 'custom'
  ? { type: 'custom', base: i.base, print: i.imageData ? '' : i.print, imageData: i.imageData || undefined, text: i.text, position: i.position, size: i.size, qty: i.qty }
  : { type: 'product', productId: i.productId, size: i.size, color: i.color, qty: i.qty });

function loadPaystack() {
  return new Promise((res, rej) => { if (window.PaystackPop) return res(); const s = document.createElement('script'); s.src = 'https://js.paystack.co/v1/inline.js'; s.onload = res; s.onerror = () => rej(new Error('Could not load the payment window. Check your connection.')); document.head.appendChild(s); });
}
async function placeOrder() {
  const btn = $('#placeBtn');
  if (!profileComplete()) { toast('Add your delivery details first', { bad: true }); profileForm(); return; }
  const card = S.pay !== 'transfer' && S.config.paystackKey;
  if (card && !S.profile.email) { toast('Add an email so we can send your payment receipt', { bad: true }); profileForm(); return; }
  const unlock = () => { if (btn) { btn.disabled = false; btn.innerHTML = `Proceed to Checkout ${ic('arrow')}`; } };
  if (btn) { btn.disabled = true; btn.textContent = 'Please wait…'; }
  try {
    const items = payloadItems();
    const quote = await api('/api/quote', { body: { items, delivery: S.delivery, promo: S.promo } });
    const submit = async (reference) => {
      const r = await api('/api/orders', { body: { customer: S.profile, delivery: S.delivery, promo: S.promo, items, payment: { method: S.pay, reference } } });
      S.orders.unshift({ id: r.order.id, phone: S.profile.phone }); save.orders();
      LS.set('last', { id: r.order.id, total: r.order.total, paymentStatus: r.order.paymentStatus, bank: r.bank, whatsapp: r.whatsapp });
      S.bag = []; S.promo = ''; S.discount = 0; save.bag();
      location.hash = '#/success/' + r.order.id;
    };
    if (card) {
      await loadPaystack();
      const ref = 'UV' + Date.now() + uid();
      window.PaystackPop.setup({
        key: S.config.paystackKey, email: S.profile.email, amount: quote.total * 100, currency: 'NGN', ref,
        metadata: { custom_fields: [{ display_name: 'Customer', variable_name: 'customer', value: S.profile.name }] },
        callback: function (resp) { submit(resp.reference).catch((e) => { toast(e.message, { bad: true, ms: 6000 }); unlock(); }); },
        onClose: function () { unlock(); },
      }).openIframe();
    } else await submit('');
  } catch (e) { toast(e.message, { bad: true, ms: 5000 }); unlock(); }
}

const actions = {
  enter() { sessionStorage.setItem('uv:entered', '1'); location.hash = '#/shop'; },
  back: goBack, close: closeModal,
  menu() {
    const w = S.config.store.whatsapp; const d = document.createElement('div'); d.className = 'drawer';
    d.innerHTML = `<nav aria-label="Menu"><div class="brand">${esc(S.config.store.name)}</div><a href="#/shop">Shop</a><a href="#/build">Build your own</a><a href="#/orders">My orders</a><a href="#/wishlist">Wishlist</a><a href="#/profile">Profile</a>${w ? `<a href="https://wa.me/${esc(w.replace(/\D/g, ''))}" target="_blank" rel="noopener">Chat on WhatsApp</a>` : ''}</nav>`;
    d.addEventListener('click', (e) => { if (e.target === d || e.target.closest('a')) d.remove(); }); document.body.appendChild(d);
  },
  cat(t) { S.cat = t.dataset.v; render(); },
  wish(t) { const id = t.dataset.v; S.wish = S.wish.includes(id) ? S.wish.filter((x) => x !== id) : [...S.wish, id]; save.wish(); t.classList.toggle('on', S.wish.includes(id)); t.setAttribute('aria-pressed', S.wish.includes(id)); toast(S.wish.includes(id) ? 'Saved to wishlist' : 'Removed from wishlist'); },
  size(t) { S.sel.size = t.dataset.v; document.querySelectorAll('.pd .size').forEach((b) => { const on = b === t; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); }); },
  color(t) { S.sel.color = t.dataset.v; document.querySelectorAll('.colopt').forEach((b) => { const on = b === t; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); }); },
  addbag(t) {
    const p = prod(t.dataset.v); if (!p) return;
    addToBag({ id: uid(), type: 'product', productId: p.id, name: p.name, price: p.price, size: S.sel.size, color: S.sel.color, image: p.images[0], qty: 1 });
    toast('Added to bag', { action: { label: 'View bag', fn: () => { location.hash = '#/bag'; } } });
    location.hash = '#/shop';
  },
  qty(t) { const i = S.bag.find((x) => x.id === t.dataset.id); if (!i) return; i.qty = Math.min(20, Math.max(1, i.qty + Number(t.dataset.d))); S.discount = 0; save.bag(); render(); },
  rm(t) { S.bag = S.bag.filter((x) => x.id !== t.dataset.id); S.discount = 0; save.bag(); render(); },
  clearbag() { if (confirm('Remove everything from your bag?')) { S.bag = []; S.discount = 0; S.promo = ''; save.bag(); location.hash = '#/bag'; render(); } },
  async applypromo() {
    const code = ($('#promo').value || '').trim(); const msg = $('#pmsg');
    if (!code) { S.promo = ''; S.discount = 0; render(); return; }
    try { const q = await api('/api/quote', { body: { items: payloadItems(), delivery: S.delivery, promo: code } }); S.promo = q.promo; S.discount = q.discount; render(); toast('Promo applied'); }
    catch (e) { msg.className = 'msg bad'; msg.textContent = e.message; }
  },
  deliv(t) { S.delivery = t.dataset.v; render(); }, pay(t) { S.pay = t.dataset.v; render(); },
  editprofile: profileForm,
  saveprofile() {
    const v = (id) => ($(id).value || '').trim();
    const p = { name: v('#pf-name'), phone: v('#pf-tel'), email: v('#pf-email'), address: v('#pf-address'), city: v('#pf-city') };
    if (!p.name || p.phone.replace(/\D/g, '').length < 7 || !p.address) { toast('Name, phone number and address are required', { bad: true }); return; }
    S.profile = p; save.profile(); closeModal(); render();
  },
  place: placeOrder,
  logout() { if (confirm('This clears your saved details, bag, wishlist and designs from this device. Continue?')) { Object.keys(localStorage).filter((k) => k.startsWith('uv:')).forEach((k) => localStorage.removeItem(k)); S.bag = []; S.wish = []; S.profile = null; S.orders = []; S.customs = []; S.promo = ''; S.discount = 0; location.hash = '#/shop'; render(); } },
  base(t) { S.build.base = t.dataset.v; render(); },
  print(t) { S.build.print = t.dataset.v; S.build.imageData = null; render(); },
  upload() { $('#file').click(); },
  pos(t) { S.build.position = t.dataset.v; render(); },
  bsize(t) { S.build.size = t.dataset.v; render(); },
  savecustom() {
    const b = S.build; if (!b.size) { toast('Pick a size first', { bad: true }); return; }
    const d = { id: uid(), base: b.base, print: b.print, imageData: b.imageData, text: b.text, position: b.position, size: b.size, createdAt: Date.now() };
    S.customs.unshift(d); save.customs(); location.hash = '#/customs';
    toast('Saved to My Custom Designs', { action: { label: 'Add to bag', fn: () => actions.addcustom({ dataset: { id: d.id } }) } });
  },
  addcustom(t) {
    const c = S.customs.find((x) => x.id === t.dataset.id); if (!c) return;
    S.bag.push({ id: uid(), type: 'custom', name: 'Custom UV Piece', price: S.config.customPrice, base: c.base, print: c.print, imageData: c.imageData, text: c.text, position: c.position, size: c.size, image: c.imageData || c.print, qty: 1 });
    S.discount = 0; save.bag(); toast('Added to bag', { action: { label: 'View bag', fn: () => { location.hash = '#/bag'; } } });
  },
  delcustom(t) { S.customs = S.customs.filter((x) => x.id !== t.dataset.id); save.customs(); render(); },
};
document.addEventListener('click', (e) => { const t = e.target.closest('[data-act]'); if (!t) return; const fn = actions[t.dataset.act]; if (fn) { e.preventDefault(); fn(t, e); } });
document.addEventListener('input', (e) => {
  if (e.target.id === 'q') { S.q = e.target.value; const q = S.q.trim().toLowerCase(); $('#results').innerHTML = resultsHtml((S.products || []).filter((p) => !q || p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q))); }
  if (e.target.id === 'btext') { S.build.text = e.target.value.slice(0, 20); $('#cnt').textContent = S.build.text.length + '/20'; const sp = $('.preview span'); if (sp) sp.textContent = `${S.build.base}, ${S.build.position.toLowerCase()} patch${S.build.text ? ', “' + S.build.text + '”' : ''}`; }
});
document.addEventListener('change', async (e) => {
  if (e.target.id === 'file' && e.target.files[0]) {
    try { S.build.imageData = await resizeImage(e.target.files[0]); render(); } catch (err) { toast(err.message, { bad: true }); }
  }
});
window.addEventListener('hashchange', render);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
render();
})();
