(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (n) => '₦' + Number(n || 0).toLocaleString('en-NG');
const root = $('#root');
const ALL_SIZES = ['S', 'M', 'L', 'XL', 'XXL'];
const STATUSES = ['New', 'Confirmed', 'Packed', 'Shipped', 'Delivered', 'Cancelled'];
const PAY_STATUSES = ['Awaiting payment', 'Awaiting bank transfer', 'Paid online', 'Paid (transfer)', 'Paid (cash)'];
const CUSTOM_HEX = { Black: '#000', Olive: '#6b7020', Lime: '#C8FF00' };

const S = { tab: 'orders', orders: [], products: [], settings: null, filter: 'All', open: null, editing: null, sound: localStorage.getItem('uv:sound') !== '0' };

async function api(path, o = {}) {
  const r = await fetch(path, { method: o.method || (o.body ? 'POST' : 'GET'), headers: o.body ? { 'Content-Type': 'application/json' } : undefined, body: o.body ? JSON.stringify(o.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && !o.quiet) { showAuth(); throw new Error('Please sign in'); }
  if (!r.ok) throw new Error(j.error || 'Something went wrong');
  return j;
}
let tt;
function toast(msg, bad) { document.querySelectorAll('.toast').forEach((e) => e.remove()); const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg; t.setAttribute('role', 'status'); document.body.appendChild(t); clearTimeout(tt); tt = setTimeout(() => t.remove(), 3500); }
const when = (ts) => new Date(ts).toLocaleString('en-NG', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });

/* ------------------------------------------------------------ auth */
async function boot() {
  const me = await api('/api/admin/me', { quiet: true });
  if (!me.signedIn) return showAuth(me.setup);
  await start();
}
function showAuth(setup) {
  if (setup === undefined) setup = true;
  root.innerHTML = `<div class="auth"><img src="/assets/logo.png" alt="UV"><h1>${setup ? 'Owner sign in' : 'Create your password'}</h1>
    <p>${setup ? 'Manage your wears, prices and orders.' : 'This is your first time here. Choose a password for the owner dashboard (at least 8 characters).'}</p>
    <form id="af"><label class="f">Password<input class="in" type="password" id="pw" autocomplete="${setup ? 'current-password' : 'new-password'}" required minlength="${setup ? 1 : 8}"></label>
    <div class="err" id="err" role="alert"></div><button class="btn full">${setup ? 'Sign in' : 'Create password and enter'}</button></form></div>`;
  $('#af').onsubmit = async (e) => {
    e.preventDefault();
    try { await api(setup ? '/api/admin/login' : '/api/admin/setup', { body: { password: $('#pw').value }, quiet: true }); await start(); }
    catch (er) { $('#err').textContent = er.message; }
  };
}
async function start() {
  const [orders, products, settings] = await Promise.all([api('/api/admin/orders'), api('/api/admin/products'), api('/api/admin/settings')]);
  S.orders = orders; S.products = products; S.settings = settings;
  render(); connect(); setInterval(pollOrders, 30000);
}

/* ------------------------------------------------------------ live alerts */
let audio;
function beep() {
  if (!S.sound) return;
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)();
    [0, 0.22, 0.44].forEach((d, i) => { const o = audio.createOscillator(), g = audio.createGain(); o.type = 'sine'; o.frequency.value = [880, 1175, 1568][i]; g.gain.setValueAtTime(0.0001, audio.currentTime + d); g.gain.exponentialRampToValueAtTime(0.3, audio.currentTime + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + d + 0.3); o.connect(g).connect(audio.destination); o.start(audio.currentTime + d); o.stop(audio.currentTime + d + 0.32); });
  } catch { /* audio blocked until a tap */ }
}
function unreadCount() { return S.orders.filter((o) => !o.seen).length; }
function updateTitle() { document.title = (unreadCount() ? `(${unreadCount()}) ` : '') + 'Unusual Vogues · Owner admin'; }
function newOrderAlert(o) {
  beep();
  const a = document.createElement('div'); a.className = 'alert'; a.setAttribute('role', 'alert');
  a.innerHTML = `<b>New order ${esc(o.id)} · ${fmt(o.total)}</b>${esc(o.customer.name)} · ${esc(o.items.reduce((n, i) => n + i.qty, 0))} item(s)`;
  a.onclick = () => { a.remove(); S.tab = 'orders'; S.open = o.id; render(); };
  document.body.appendChild(a); setTimeout(() => a.remove(), 9000);
  if ('Notification' in window && Notification.permission === 'granted') {
    try { new Notification(`New order ${o.id} · ${fmt(o.total)}`, { body: `${o.customer.name} · ${o.items.map((i) => i.qty + '× ' + i.name).join(', ')}`, icon: '/assets/logo.png', tag: o.id }); } catch { /* ignore */ }
  }
}
let es;
function connect() {
  if (es) es.close();
  es = new EventSource('/api/admin/events');
  es.addEventListener('order', (e) => {
    const o = JSON.parse(e.data);
    if (!S.orders.find((x) => x.id === o.id)) { S.orders.unshift(o); newOrderAlert(o); render(); }
  });
}
async function pollOrders() {
  try {
    const fresh = await api('/api/admin/orders', { quiet: true });
    const known = new Set(S.orders.map((o) => o.id)); const added = fresh.filter((o) => !known.has(o.id));
    S.orders = fresh; added.forEach(newOrderAlert); if (added.length || S.tab === 'orders') render();
  } catch { /* offline */ }
}

/* ------------------------------------------------------------ shell */
function render() {
  const u = unreadCount(); updateTitle();
  const tabs = [['orders', 'Orders'], ['wear', 'My wear'], ['settings', 'Settings']];
  root.innerHTML = `<div class="bar"><div class="in"><img src="/assets/logo.png" alt=""><h1>Unusual Vogues</h1><a class="out" href="/" target="_blank" rel="noopener">View shop</a><button class="out" data-a="logout">Sign out</button></div></div>
  <main class="wrap"><div class="tabs" role="tablist">${tabs.map(([k, l]) => `<button class="tab ${S.tab === k ? 'on' : ''}" data-a="tab" data-v="${k}" role="tab" aria-selected="${S.tab === k}">${l}${k === 'orders' && u ? `<span class="n">${u}</span>` : ''}</button>`).join('')}</div>
  <div id="pane">${S.tab === 'orders' ? ordersView() : S.tab === 'wear' ? wearView() : settingsView()}</div></main>`;
}

/* ------------------------------------------------------------ orders */
function ordersView() {
  const list = S.filter === 'All' ? S.orders : S.orders.filter((o) => o.status === S.filter);
  const perm = 'Notification' in window ? Notification.permission : 'denied';
  const revenue = S.orders.filter((o) => /^Paid/.test(o.paymentStatus) && o.status !== 'Cancelled').reduce((s, o) => s + o.total, 0);
  return `<div class="banner"><span class="sp"><b>Order alerts on this device</b><div class="mut">Sound and pop-up alerts work while this page is open. For alerts when it is closed, set up Telegram, WhatsApp or email in Settings.</div></div>
    ${perm === 'default' ? '<button class="btn sm" data-a="notifperm">Turn on pop-ups</button>' : ''}<button class="btn sm ghost" data-a="sound">${S.sound ? 'Sound on' : 'Sound off'}</button><button class="btn sm ghost" data-a="testsound">Test</button></div>
    <div class="row" style="margin:14px 0 4px"><div class="chipset sp">${['All', ...STATUSES].map((s) => `<button class="chip ${S.filter === s ? 'on' : ''}" data-a="filter" data-v="${s}">${s}</button>`).join('')}</div>${unreadCount() ? '<button class="btn sm ghost" data-a="seenall">Mark all seen</button>' : ''}</div>
    <p class="mut" style="margin-bottom:10px">${S.orders.length} order(s) · Paid so far ${fmt(revenue)}</p>
    <div class="stack">${list.length ? list.map(orderCard).join('') : `<div class="empty"><h2>No orders yet</h2><p>New orders from your shop show up here the moment they are placed.</p></div>`}</div>`;
}
function orderCard(o) {
  const open = S.open === o.id; const wa = o.customer.phone.replace(/\D/g, '').replace(/^0/, '234');
  const pcls = /^Paid/.test(o.paymentStatus) ? 'lime' : 'warn'; const scls = o.status === 'Cancelled' ? 'red' : o.status === 'Delivered' ? 'lime' : '';
  return `<article class="card order"><button class="head" data-a="open" data-v="${o.id}" aria-expanded="${open}"><span class="dot ${o.seen ? 'off' : ''}" title="${o.seen ? 'Seen' : 'New'}"></span>
    <span><b>${esc(o.id)}</b> · ${esc(o.customer.name)}<div class="mut">${when(o.createdAt)} · ${o.items.reduce((n, i) => n + i.qty, 0)} item(s)</div></span>
    <span style="text-align:right"><b class="lime">${fmt(o.total)}</b><div><span class="pill ${scls}">${esc(o.status)}</span></div></span></button>
    ${open ? `<div class="body"><div class="stack" style="margin-top:14px">${o.items.map((i) => `<div class="item">${i.type === 'custom' ? `<div class="cv" style="background:${CUSTOM_HEX[i.color] || '#000'}">${i.image ? `<img src="${esc(i.image)}" alt="">` : ''}</div>` : `<img src="${esc(i.image)}" alt="">`}
      <div class="sp"><b>${i.qty}× ${esc(i.name)}</b><div class="mut">${esc([i.size, i.color].filter(Boolean).join(' · '))}${i.type === 'custom' ? ` · ${esc(i.position)} patch${i.text ? ` · text “${esc(i.text)}”` : ''}` : ''}</div>${i.type === 'custom' && i.image ? `<a class="lime" style="font-size:13px;font-weight:800" href="${esc(i.image)}" target="_blank" rel="noopener">Open print file</a>` : ''}</div><b>${fmt(i.unit * i.qty)}</b></div>`).join('')}</div>
      <dl class="kv"><dt>Customer</dt><dd>${esc(o.customer.name)}</dd><dt>Phone</dt><dd><a href="tel:${esc(o.customer.phone)}">${esc(o.customer.phone)}</a> · <a class="lime" href="https://wa.me/${esc(wa)}" target="_blank" rel="noopener">WhatsApp</a></dd>${o.customer.email ? `<dt>Email</dt><dd>${esc(o.customer.email)}</dd>` : ''}<dt>Address</dt><dd>${esc(o.customer.address)}${o.customer.city ? ', ' + esc(o.customer.city) : ''}</dd><dt>Delivery</dt><dd>${esc(o.delivery.label)} (${esc(o.delivery.days)}) · ${fmt(o.delivery.fee)}</dd><dt>Payment</dt><dd><span class="pill ${pcls}">${esc(o.paymentStatus)}</span> via ${esc(o.payment.method)}${o.payment.reference ? ` · ref ${esc(o.payment.reference)}` : ''}</dd>${o.promo ? `<dt>Promo</dt><dd>${esc(o.promo)} (−${fmt(o.discount)})</dd>` : ''}</dl>
      <div class="total"><span>Total</span><span class="lime">${fmt(o.total)}</span></div>
      <div class="grid2"><label class="f">Order status<select class="in" data-a="setstatus" data-id="${o.id}">${STATUSES.map((s) => `<option ${s === o.status ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
      <label class="f">Payment<select class="in" data-a="setpay" data-id="${o.id}">${PAY_STATUSES.map((s) => `<option ${s === o.paymentStatus ? 'selected' : ''}>${s}</option>`).join('')}</select></label></div></div>` : ''}</article>`;
}

/* ------------------------------------------------------------ wear */
function wearView() {
  return `<div class="row" style="margin-top:12px"><div class="sp"><b style="font-size:18px">Your wears</b><div class="mut">Anything you add here appears on the shop straight away.</div></div><button class="btn" data-a="newwear">+ Add new wear</button></div>
  <div class="pgrid">${S.products.map((p) => `<div class="pc"><img src="${esc(p.images[0])}" alt=""><div class="m"><h3>${esc(p.name)}</h3><div><b class="lime">${fmt(p.price)}</b> <span class="mut">· ${esc(p.category)}</span></div><div class="row">${p.active === false ? '<span class="pill">Hidden</span>' : '<span class="pill lime">Live</span>'}${p.soldOut ? '<span class="pill red">Sold out</span>' : ''}</div></div>
    <div class="acts"><button class="btn sm ghost sp" data-a="editwear" data-id="${p.id}">Edit</button><button class="btn sm danger" data-a="delwear" data-id="${p.id}" aria-label="Delete ${esc(p.name)}">Delete</button></div></div>`).join('')}
  <button class="addcard" data-a="newwear"><div><span>+</span><div>Add new wear</div></div></button></div>`;
}
function wearForm(p) {
  const e = S.editing = { id: p ? p.id : null, name: p ? p.name : '', category: p ? p.category : '', price: p ? p.price : '', description: p ? p.description : '', sizes: p ? [...p.sizes] : [...ALL_SIZES], colors: p ? p.colors.map((c) => ({ ...c })) : [{ name: 'Black', hex: '#000000' }], images: p ? [...p.images] : [], active: p ? p.active !== false : true, soldOut: p ? !!p.soldOut : false };
  drawWearForm();
}
function drawWearForm() {
  const e = S.editing; const cats = [...new Set(S.products.map((p) => p.category))];
  const html = `<div class="modal" role="dialog" aria-modal="true" aria-label="Wear details"><h2>${e.id ? 'Edit wear' : 'Add new wear'}</h2><div class="stack">
    <div><div class="mut" style="margin-bottom:6px;font-weight:700">Photos (first photo is the cover)</div><div class="photos">${e.images.map((u, i) => `<div class="ph ${i === 0 ? 'cover' : ''}"><img src="${esc(u)}" alt="">${i === 0 ? '<span class="tag">Cover</span>' : ''}<button data-a="rmphoto" data-i="${i}" aria-label="Remove photo">×</button></div>`).join('')}<button class="ph add" data-a="addphoto">+ Photo</button></div><input type="file" id="pfile" accept="image/*" multiple hidden></div>
    <label class="f">Name<input class="in" id="w-name" value="${esc(e.name)}" placeholder="Rogue Hoodie" maxlength="80"></label>
    <div class="grid2"><label class="f">Price (₦)<input class="in" id="w-price" type="number" inputmode="numeric" min="0" step="500" value="${esc(e.price)}" placeholder="40000"></label>
    <label class="f">Category<input class="in" id="w-cat" list="cats" value="${esc(e.category)}" placeholder="Hoodies" maxlength="30"><datalist id="cats">${[...new Set([...cats, 'Hoodies', 'Cargo Pants', 'Tees', 'Jackets', 'Caps', 'Accessories'])].map((c) => `<option value="${esc(c)}">`).join('')}</datalist></label></div>
    <label class="f">Description<textarea class="in" id="w-desc" maxlength="600" placeholder="Oversized fit. Premium heavyweight cotton.">${esc(e.description)}</textarea></label>
    <div><div class="mut" style="margin-bottom:6px;font-weight:700">Sizes available</div><div class="chipset">${ALL_SIZES.map((s) => `<button class="chip ${e.sizes.includes(s) ? 'on' : ''}" data-a="togsize" data-v="${s}" aria-pressed="${e.sizes.includes(s)}">${s}</button>`).join('')}<button class="chip" data-a="onesize">One size</button></div></div>
    <div><div class="mut" style="margin-bottom:6px;font-weight:700">Colors</div><div class="stack">${e.colors.map((c, i) => `<div class="colrow"><input type="color" value="${esc(c.hex)}" data-a="colhex" data-i="${i}" aria-label="Color swatch"><input class="in" value="${esc(c.name)}" data-a="colname" data-i="${i}" placeholder="Color name" maxlength="24"><button class="btn sm danger" data-a="rmcolor" data-i="${i}" aria-label="Remove color">×</button></div>`).join('')}<button class="btn sm ghost" data-a="addcolor" style="justify-self:start">+ Add color</button></div></div>
    <label class="switch"><input type="checkbox" id="w-active" ${e.active ? 'checked' : ''}> Show on the shop</label>
    <label class="switch"><input type="checkbox" id="w-sold" ${e.soldOut ? 'checked' : ''}> Mark as sold out</label>
    <div class="err" id="werr" role="alert"></div>
    <div class="row"><button class="btn sp" data-a="savewear">${e.id ? 'Save changes' : 'Add to shop'}</button><button class="btn ghost" data-a="closemodal">Cancel</button></div></div></div>`;
  let s = $('#scrim'); const keep = s ? s.firstElementChild.scrollTop : 0;
  if (!s) { s = document.createElement('div'); s.className = 'scrim'; s.id = 'scrim'; s.addEventListener('click', (ev) => { if (ev.target === s) closeModal(); }); document.body.appendChild(s); }
  s.innerHTML = html; s.firstElementChild.scrollTop = keep;
}
const closeModal = () => { const s = $('#scrim'); if (s) s.remove(); S.editing = null; };
function syncForm() {
  const e = S.editing; if (!e || !$('#w-name')) return;
  e.name = $('#w-name').value; e.price = $('#w-price').value; e.category = $('#w-cat').value; e.description = $('#w-desc').value; e.active = $('#w-active').checked; e.soldOut = $('#w-sold').checked;
}
function resizeImage(file, max = 1400) {
  return new Promise((resolve, reject) => {
    const r = new FileReader(); r.onerror = () => reject(new Error('Could not read the photo'));
    r.onload = () => { const img = new Image(); img.onerror = () => reject(new Error('That file is not an image')); img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height); resolve(c.toDataURL('image/jpeg', 0.86));
    }; img.src = r.result; }; r.readAsDataURL(file);
  });
}

/* ------------------------------------------------------------ settings */
function settingsView() {
  const s = S.settings; const n = s.notify;
  const f = (id, label, val, type = 'text', ph = '', extra = '') => `<label class="f">${label}<input class="in" id="${id}" type="${type}" value="${esc(val)}" placeholder="${esc(ph)}" ${extra} autocomplete="off"></label>`;
  return `<div class="stack" style="margin-top:12px">
    <section class="card sect"><h2>Order alerts to your phone</h2><p class="help">Every new order sends a message with the customer, items, address and total. Turn on any channel you like, then press “Send test alert”.</p>
      <div class="sect"><b>Telegram (free, instant, recommended)</b><p class="help">In Telegram, open @BotFather, send /newbot, and copy the bot token. Then open your new bot and press Start. Message @userinfobot to get your chat ID.</p>
      <div class="grid2">${f('n-tg-token', 'Bot token', n.telegram.token, 'password')}${f('n-tg-chat', 'Chat ID', n.telegram.chatId)}</div></div>
      <div class="sect"><b>WhatsApp (free via CallMeBot)</b><p class="help">Follow the one-time steps at callmebot.com/blog/free-api-whatsapp-messages to get your API key, then enter your number with country code.</p>
      <div class="grid2">${f('n-wa-phone', 'Your WhatsApp number', n.whatsapp.phone, 'tel', '+2348012345678')}${f('n-wa-key', 'API key', n.whatsapp.apikey, 'password')}</div></div>
      <div class="sect"><b>Email (via Resend)</b><p class="help">Create a free account at resend.com and paste an API key. Until you verify your own domain, Resend only delivers to the email you signed up with.</p>
      <div class="grid2">${f('n-em-key', 'Resend API key', n.email.resendKey, 'password')}${f('n-em-to', 'Send alerts to', n.email.to, 'email')}</div>${f('n-em-from', 'From', n.email.from)}</div>
      ${f('n-hook', 'Webhook URL (optional, for Zapier or Make)', n.webhook, 'url')}
      <div class="row"><button class="btn sp" data-a="savesettings">Save settings</button><button class="btn ghost" data-a="testnotify">Send test alert</button></div></section>
    <section class="card sect"><h2>Store details</h2><div class="grid2">${f('s-name', 'Brand name', s.store.name)}${f('s-tag', 'Tagline', s.store.tagline)}${f('s-wa', 'Customer WhatsApp number', s.store.whatsapp, 'tel', '2348012345678')}${f('s-mail', 'Public email', s.store.email, 'email')}</div></section>
    <section class="card sect"><h2>Delivery and custom pieces</h2><div class="grid2">${f('d1-label', 'Standard name', s.shipping.standard.label)}${f('d1-days', 'Standard time', s.shipping.standard.days)}${f('d1-fee', 'Standard fee (₦)', s.shipping.standard.fee, 'number', '', 'min="0"')}<span></span>${f('d2-label', 'Express name', s.shipping.express.label)}${f('d2-days', 'Express time', s.shipping.express.days)}${f('d2-fee', 'Express fee (₦)', s.shipping.express.fee, 'number', '', 'min="0"')}<span></span>${f('s-custom', 'Price of a custom piece (₦)', s.customPrice, 'number', '', 'min="0"')}</div></section>
    <section class="card sect"><h2>Promo codes</h2><p class="help">One per line, like <b>UNUSUAL10 10</b> (code, then percent off).</p><textarea class="in" id="s-promos" placeholder="UNUSUAL10 10">${esc((s.promos || []).map((p) => `${p.code} ${p.percent}`).join('\n'))}</textarea></section>
    <section class="card sect"><h2>Getting paid</h2><p class="help"><b>Card payments:</b> create a Paystack account (paystack.com), then paste your public and secret keys. Customers then pay by card on the checkout, and each payment is verified on the server before the order is marked paid.</p>
      <div class="grid2">${f('p-pub', 'Paystack public key', s.paystack.publicKey, 'text', 'pk_live_...')}${f('p-sec', 'Paystack secret key', s.paystack.secretKey, 'password', 'sk_live_...')}</div>
      <p class="help"><b>Bank transfer details</b> (shown to customers who choose transfer):</p><div class="grid2">${f('b-bank', 'Bank', s.bank.bankName)}${f('b-name', 'Account name', s.bank.accountName)}${f('b-num', 'Account number', s.bank.accountNumber)}${f('b-note', 'Note to customer', s.bank.note)}</div></section>
    <section class="card sect"><h2>Change password</h2><div class="grid2">${f('pw-cur', 'Current password', '', 'password')}${f('pw-new', 'New password (8+ characters)', '', 'password')}</div><button class="btn ghost" data-a="changepw" style="justify-self:start">Change password</button></section>
    <button class="btn full" data-a="savesettings">Save settings</button></div>`;
}
function collectSettings() {
  const v = (id) => ($('#' + id) ? $('#' + id).value.trim() : '');
  const promos = v('s-promos').split('\n').map((l) => l.trim().split(/\s+/)).filter((p) => p[0] && Number(p[1])).map((p) => ({ code: p[0], percent: Number(p[1]) }));
  return {
    store: { name: v('s-name'), tagline: v('s-tag'), whatsapp: v('s-wa'), email: v('s-mail') },
    shipping: { standard: { label: v('d1-label'), days: v('d1-days'), fee: v('d1-fee') }, express: { label: v('d2-label'), days: v('d2-days'), fee: v('d2-fee') } },
    customPrice: v('s-custom'), promos,
    paystack: { publicKey: v('p-pub'), secretKey: v('p-sec') },
    bank: { bankName: v('b-bank'), accountName: v('b-name'), accountNumber: v('b-num'), note: v('b-note') },
    notify: { telegram: { token: v('n-tg-token'), chatId: v('n-tg-chat') }, whatsapp: { phone: v('n-wa-phone'), apikey: v('n-wa-key') }, email: { resendKey: v('n-em-key'), from: v('n-em-from'), to: v('n-em-to') }, webhook: v('n-hook') },
  };
}

/* ------------------------------------------------------------ actions */
const A = {
  tab(t) { S.tab = t.dataset.v; render(); },
  filter(t) { S.filter = t.dataset.v; render(); },
  async open(t) {
    const id = t.dataset.v; S.open = S.open === id ? null : id;
    const o = S.orders.find((x) => x.id === id);
    if (S.open && o && !o.seen) { o.seen = true; api('/api/admin/orders/' + id, { method: 'PATCH', body: { seen: true } }).catch(() => {}); }
    render();
  },
  async seenall() { await api('/api/admin/orders/seen', { method: 'POST', body: {} }); S.orders.forEach((o) => { o.seen = true; }); render(); },
  sound() { S.sound = !S.sound; localStorage.setItem('uv:sound', S.sound ? '1' : '0'); if (S.sound) beep(); render(); },
  testsound() { const was = S.sound; S.sound = true; beep(); S.sound = was; },
  async notifperm() { try { await Notification.requestPermission(); } catch { /* ignore */ } render(); },
  async logout() { await api('/api/admin/logout', { method: 'POST', body: {} }); location.reload(); },
  newwear() { wearForm(null); },
  editwear(t) { wearForm(S.products.find((p) => p.id === t.dataset.id)); },
  async delwear(t) {
    const p = S.products.find((x) => x.id === t.dataset.id);
    if (!confirm(`Delete “${p.name}” from the shop? This cannot be undone.`)) return;
    try { await api('/api/admin/products/' + p.id, { method: 'DELETE' }); S.products = S.products.filter((x) => x !== p); render(); toast('Deleted'); } catch (e) { toast(e.message, true); }
  },
  closemodal: closeModal,
  addphoto() { syncForm(); $('#pfile').click(); },
  rmphoto(t) { syncForm(); S.editing.images.splice(Number(t.dataset.i), 1); drawWearForm(); },
  togsize(t) { syncForm(); const e = S.editing; const s = t.dataset.v; e.sizes = e.sizes.includes(s) ? e.sizes.filter((x) => x !== s) : ALL_SIZES.filter((x) => e.sizes.includes(x) || x === s); drawWearForm(); },
  onesize() { syncForm(); S.editing.sizes = ['One size']; drawWearForm(); },
  addcolor() { syncForm(); S.editing.colors.push({ name: '', hex: '#ffffff' }); drawWearForm(); },
  rmcolor(t) { syncForm(); S.editing.colors.splice(Number(t.dataset.i), 1); drawWearForm(); },
  async savewear(t) {
    syncForm(); const e = S.editing; const err = $('#werr');
    if (!e.name.trim()) return (err.textContent = 'Give the wear a name.');
    if (e.price === '' || Number(e.price) < 0) return (err.textContent = 'Enter the price you want to sell it for.');
    if (!e.images.length) return (err.textContent = 'Add at least one photo.');
    if (!e.sizes.length) return (err.textContent = 'Pick at least one size.');
    t.disabled = true; t.textContent = 'Saving…';
    try {
      const body = { name: e.name, category: e.category, price: Number(e.price), description: e.description, sizes: e.sizes, colors: e.colors.filter((c) => c.name.trim()), images: e.images, active: e.active, soldOut: e.soldOut };
      const saved = await api(e.id ? '/api/admin/products/' + e.id : '/api/admin/products', { method: e.id ? 'PUT' : 'POST', body });
      S.products = e.id ? S.products.map((p) => (p.id === saved.id ? saved : p)) : [saved, ...S.products];
      closeModal(); render(); toast(e.id ? 'Changes saved' : 'Added to the shop. Customers can see it now.');
    } catch (er) { err.textContent = er.message; t.disabled = false; t.textContent = e.id ? 'Save changes' : 'Add to shop'; }
  },
  async savesettings() {
    try { S.settings = await api('/api/admin/settings', { method: 'PUT', body: collectSettings() }); toast('Settings saved'); } catch (e) { toast(e.message, true); }
  },
  async testnotify() {
    try {
      S.settings = await api('/api/admin/settings', { method: 'PUT', body: collectSettings() });
      const r = await api('/api/admin/test-notify', { method: 'POST', body: {} });
      if (!r.results.length) return toast('Turn on at least one channel first', true);
      const bad = r.results.filter((x) => !x.ok);
      if (bad.length) toast(`${bad.map((b) => b.channel).join(', ')} failed: ${bad[0].error}`.slice(0, 160), true); else toast('Test sent via ' + r.results.map((x) => x.channel).join(', '));
    } catch (e) { toast(e.message, true); }
  },
  async changepw() {
    try { await api('/api/admin/password', { method: 'POST', body: { current: $('#pw-cur').value, next: $('#pw-new').value } }); $('#pw-cur').value = ''; $('#pw-new').value = ''; toast('Password changed'); } catch (e) { toast(e.message, true); }
  },
};
document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-a]'); if (!t || ['SELECT', 'INPUT'].includes(t.tagName)) return;
  if (A[t.dataset.a]) { e.preventDefault(); A[t.dataset.a](t); }
});
document.addEventListener('input', (e) => {
  const t = e.target; if (!S.editing) return;
  if (t.dataset.a === 'colname') S.editing.colors[Number(t.dataset.i)].name = t.value;
  if (t.dataset.a === 'colhex') S.editing.colors[Number(t.dataset.i)].hex = t.value;
});
document.addEventListener('change', async (e) => {
  const t = e.target;
  if (t.id === 'pfile' && t.files.length) {
    try { for (const f of [...t.files].slice(0, 8 - S.editing.images.length)) S.editing.images.push(await resizeImage(f)); drawWearForm(); } catch (er) { toast(er.message, true); }
  }
  if (t.dataset.a === 'setstatus' || t.dataset.a === 'setpay') {
    const o = S.orders.find((x) => x.id === t.dataset.id);
    try { const up = await api('/api/admin/orders/' + o.id, { method: 'PATCH', body: t.dataset.a === 'setstatus' ? { status: t.value } : { paymentStatus: t.value } }); Object.assign(o, up); render(); toast('Order updated'); } catch (er) { toast(er.message, true); render(); }
  }
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
boot().catch(() => showAuth());
})();
