'use strict';
/**
 * UNUSUAL VOGUES — store + admin server (no npm packages needed, Node 18+).
 *   node server.js
 * Storefront:  http://localhost:3000
 * Owner admin: http://localhost:3000/admin
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const UPLOADS = path.join(DATA_DIR, 'uploads');
for (const d of [DATA_DIR, UPLOADS, path.join(UPLOADS, 'products'), path.join(UPLOADS, 'custom')]) fs.mkdirSync(d, { recursive: true });

/* ------------------------------------------------------------------ storage */
const F = { db: path.join(DATA_DIR, 'db.json'), settings: path.join(DATA_DIR, 'settings.json'), auth: path.join(DATA_DIR, 'auth.json') };
const readJSON = (f, fallback) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fallback; } };
const writeJSON = (f, obj) => { const tmp = f + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(obj, null, 2)); fs.renameSync(tmp, f); };

const DEFAULT_SETTINGS = {
  store: { name: 'Unusual Vogues', tagline: 'Dress Unusual.', whatsapp: '', email: '' },
  shipping: {
    standard: { label: 'Standard Delivery', days: '3-5 business days', fee: 3000 },
    express: { label: 'Express Delivery', days: '1-2 business days', fee: 6000 },
  },
  customPrice: 45000,
  promos: [],
  paystack: { publicKey: '', secretKey: '' },
  bank: { bankName: '', accountName: '', accountNumber: '', note: 'Send your payment proof on WhatsApp with your order ID.' },
  notify: {
    telegram: { token: '', chatId: '' },
    whatsapp: { phone: '', apikey: '' },
    email: { resendKey: '', from: 'Unusual Vogues <onboarding@resend.dev>', to: '' },
    webhook: '',
  },
};
const merge = (base, over) => {
  if (Array.isArray(base) || typeof base !== 'object' || base === null) return over === undefined ? base : over;
  const out = {};
  for (const k of Object.keys(base)) out[k] = merge(base[k], over && typeof over === 'object' ? over[k] : undefined);
  return out;
};
let settings = merge(DEFAULT_SETTINGS, readJSON(F.settings, {}));
if (!fs.existsSync(F.settings)) writeJSON(F.settings, settings);

let db = readJSON(F.db, null);
if (!db) {
  const seed = readJSON(path.join(ROOT, 'seed', 'products.json'), []);
  db = { products: seed, orders: [], counters: { order: 1000 } };
  writeJSON(F.db, db);
}
const saveDB = () => writeJSON(F.db, db);
let auth = readJSON(F.auth, { salt: '', hash: '', sessions: {} });
const saveAuth = () => writeJSON(F.auth, auth);

/* ------------------------------------------------------------------ helpers */
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
const send = (res, code, obj, headers = {}) => {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
};
const fail = (status, message) => Object.assign(new Error(message), { status });
const readBody = (req, limit = 30 * 1024 * 1024) => new Promise((resolve, reject) => {
  let size = 0; const chunks = [];
  req.on('data', (c) => { size += c.length; if (size > limit) { reject(fail(413, 'Request too large')); req.destroy(); } else chunks.push(c); });
  req.on('end', () => { if (!chunks.length) return resolve({}); try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(fail(400, 'Invalid JSON')); } });
  req.on('error', reject);
});
const cookies = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((s) => s.trim().split('=')).filter((p) => p[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
const clientIP = (req) => (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
const baseUrl = (req) => `${req.headers['x-forwarded-proto'] || 'http'}://${req.headers.host}`;
const str = (v, max = 200) => String(v == null ? '' : v).trim().slice(0, max);
const money = (n) => '₦' + Number(n).toLocaleString('en-NG');

const hits = new Map();
const rateLimit = (key, max, windowMs) => {
  const now = Date.now(); const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) return false; arr.push(now); hits.set(key, arr); return true;
};

function saveDataUrl(dataUrl, sub, maxBytes = 4 * 1024 * 1024) {
  const m = /^data:image\/(png|jpe?g|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '');
  if (!m) throw fail(400, 'Unsupported image');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > maxBytes) throw fail(413, 'Image too large');
  const ext = m[1] === 'jpeg' ? 'jpg' : m[1].replace('jpeg', 'jpg');
  const name = crypto.randomBytes(9).toString('hex') + '.' + ext;
  fs.writeFileSync(path.join(UPLOADS, sub, name), buf);
  return `/uploads/${sub}/${name}`;
}
const removeUpload = (url) => {
  if (typeof url !== 'string' || !url.startsWith('/uploads/')) return;
  const p = path.normalize(path.join(DATA_DIR, url));
  if (p.startsWith(UPLOADS)) fs.unlink(p, () => {});
};

/* ------------------------------------------------------------------ auth */
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
function newSession(res, req) {
  const token = crypto.randomBytes(32).toString('hex');
  auth.sessions[token] = Date.now() + 30 * 24 * 3600 * 1000;
  for (const [t, exp] of Object.entries(auth.sessions)) if (exp < Date.now()) delete auth.sessions[t];
  saveAuth();
  const secure = (req.headers['x-forwarded-proto'] || '') === 'https' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `uvsid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${30 * 24 * 3600}${secure}`);
}
const isAdmin = (req) => { const t = cookies(req).uvsid; return !!(t && auth.sessions[t] && auth.sessions[t] > Date.now()); };
const requireAdmin = (req) => { if (!isAdmin(req)) throw fail(401, 'Please sign in'); };

/* ------------------------------------------------------------------ catalogue */
const SIZES = ['S', 'M', 'L', 'XL', 'XXL'];
const CUSTOM_COLORS = ['Black', 'Olive', 'Lime'];
const publicProduct = (p) => ({ id: p.id, name: p.name, category: p.category, price: p.price, description: p.description, sizes: p.sizes, colors: p.colors, images: p.images, soldOut: !!p.soldOut, createdAt: p.createdAt });

function cleanProduct(body, existing) {
  const name = str(body.name, 80); if (!name) throw fail(400, 'Give the wear a name');
  const price = Math.round(Number(body.price)); if (!(price >= 0)) throw fail(400, 'Enter a valid price');
  const colors = (Array.isArray(body.colors) ? body.colors : []).map((c) => ({ name: str(c.name, 24), hex: /^#[0-9a-f]{6}$/i.test(c.hex) ? c.hex : '#000000' })).filter((c) => c.name).slice(0, 12);
  const sizes = (Array.isArray(body.sizes) ? body.sizes : []).map((s) => str(s, 8)).filter(Boolean).slice(0, 12);
  const images = [];
  for (const img of (Array.isArray(body.images) ? body.images : []).slice(0, 8)) {
    if (typeof img !== 'string') continue;
    if (img.startsWith('data:')) images.push(saveDataUrl(img, 'products'));
    else if (img.startsWith('/uploads/products/') || img.startsWith('/assets/products/')) images.push(img);
  }
  if (!images.length) throw fail(400, 'Add at least one photo');
  if (existing) for (const old of existing.images) if (!images.includes(old)) removeUpload(old);
  return { name, category: str(body.category, 30) || 'Other', price, description: str(body.description, 600), sizes: sizes.length ? sizes : SIZES, colors, images, active: body.active !== false, soldOut: !!body.soldOut };
}

/* ------------------------------------------------------------------ pricing */
function priceOrder(input) {
  const items = Array.isArray(input.items) ? input.items : [];
  if (!items.length) throw fail(400, 'Your bag is empty');
  if (items.length > 30) throw fail(400, 'Too many items');
  const lines = [];
  for (const it of items) {
    const qty = Math.min(20, Math.max(1, parseInt(it.qty, 10) || 1));
    if (it.type === 'custom') {
      const base = str(it.base, 20); const size = str(it.size, 8); const position = str(it.position, 8);
      if (!CUSTOM_COLORS.includes(base)) throw fail(400, 'Invalid custom colour');
      if (!SIZES.includes(size)) throw fail(400, 'Pick a size for your custom piece');
      if (!['Front', 'Back'].includes(position)) throw fail(400, 'Invalid patch position');
      lines.push({ type: 'custom', name: 'Custom UV Piece', unit: settings.customPrice, qty, size, color: base, text: str(it.text, 20), position, print: str(it.print, 60), hasUpload: !!it.imageData, imageData: it.imageData });
    } else {
      const p = db.products.find((x) => x.id === it.productId && x.active !== false);
      if (!p) throw fail(400, 'An item in your bag is no longer available');
      if (p.soldOut) throw fail(400, `${p.name} is sold out`);
      const size = str(it.size, 8); const color = str(it.color, 24);
      if (p.sizes.length && !p.sizes.includes(size)) throw fail(400, `Pick a size for ${p.name}`);
      if (p.colors.length && !p.colors.some((c) => c.name === color)) throw fail(400, `Pick a colour for ${p.name}`);
      lines.push({ type: 'product', productId: p.id, name: p.name, unit: p.price, qty, size, color, image: p.images[0] });
    }
  }
  const subtotal = lines.reduce((s, l) => s + l.unit * l.qty, 0);
  let discount = 0; let promo = null;
  const code = str(input.promo, 30).toUpperCase();
  if (code) {
    const hit = (settings.promos || []).find((p) => p.code.toUpperCase() === code);
    if (!hit) throw fail(400, 'That promo code is not valid');
    promo = hit.code; discount = Math.round((subtotal * hit.percent) / 100);
  }
  const ship = settings.shipping[input.delivery] || null;
  const shipping = ship ? ship.fee : 0;
  return { lines, subtotal, discount, promo, shipping, total: subtotal - discount + shipping, deliveryKey: ship ? input.delivery : null };
}

/* ------------------------------------------------------------------ notifications */
const sseClients = new Set();
const broadcast = (event, data) => { for (const c of sseClients) c.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); };

function orderMessage(o, admin) {
  const items = o.items.map((i) => `• ${i.qty}× ${i.name} (${[i.size, i.color].filter(Boolean).join(', ')}${i.text ? `, text "${i.text}"` : ''}${i.type === 'custom' ? `, ${i.position}` : ''}) — ${money(i.unit * i.qty)}`).join('\n');
  return [`🛒 NEW ORDER ${o.id}`, `Total: ${money(o.total)} — ${o.paymentStatus}`, `Customer: ${o.customer.name} · ${o.customer.phone}`, `Address: ${o.customer.address}${o.customer.city ? ', ' + o.customer.city : ''}`, `Delivery: ${o.delivery.label} (${o.delivery.days})`, 'Items:', items, `Open: ${admin}`].join('\n');
}
async function post(url, body, headers = {}) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error(`${url.split('/')[2]} replied ${r.status}: ${(await r.text()).slice(0, 160)}`);
}
async function notifyOwner(text, subject) {
  const n = settings.notify; const results = [];
  const run = async (label, enabled, fn) => { if (!enabled) return; try { await fn(); results.push({ channel: label, ok: true }); } catch (e) { console.error(`[notify:${label}]`, e.message); results.push({ channel: label, ok: false, error: e.message }); } };
  await Promise.all([
    run('telegram', n.telegram.token && n.telegram.chatId, () => post(`https://api.telegram.org/bot${n.telegram.token}/sendMessage`, { chat_id: n.telegram.chatId, text })),
    run('whatsapp', n.whatsapp.phone && n.whatsapp.apikey, async () => {
      const u = `https://api.callmebot.com/whatsapp.php?phone=${encodeURIComponent(n.whatsapp.phone.replace(/[^\d+]/g, ''))}&text=${encodeURIComponent(text)}&apikey=${encodeURIComponent(n.whatsapp.apikey)}`;
      const r = await fetch(u, { signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error('CallMeBot replied ' + r.status);
    }),
    run('email', n.email.resendKey && n.email.to, () => post('https://api.resend.com/emails', { from: n.email.from, to: [n.email.to], subject, text }, { Authorization: `Bearer ${n.email.resendKey}` })),
    run('webhook', n.webhook, () => post(n.webhook, { subject, text })),
  ]);
  return results;
}

/* ------------------------------------------------------------------ payments */
async function verifyPaystack(reference, expectedTotal) {
  const secret = settings.paystack.secretKey;
  if (!secret) throw fail(400, 'Online payment is not set up yet');
  const r = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, { headers: { Authorization: `Bearer ${secret}` }, signal: AbortSignal.timeout(15000) });
  const j = await r.json().catch(() => ({}));
  if (!j.status || !j.data || j.data.status !== 'success') throw fail(402, 'We could not confirm your payment');
  if (j.data.amount < expectedTotal * 100) throw fail(402, 'Payment amount does not match your order');
  if (db.orders.some((o) => o.payment.reference === reference)) throw fail(409, 'This payment was already used for an order');
}

/* ------------------------------------------------------------------ routes */
async function handleApi(req, res, url) {
  const route = `${req.method} ${url.pathname}`;
  const json = (c, o) => send(res, c, o);

  /* ---- public ---- */
  if (route === 'GET /api/config') {
    return json(200, { store: settings.store, shipping: settings.shipping, customPrice: settings.customPrice, paystackKey: settings.paystack.publicKey || '', sizes: SIZES, customColors: CUSTOM_COLORS });
  }
  if (route === 'GET /api/products') {
    return json(200, db.products.filter((p) => p.active !== false).sort((a, b) => b.createdAt - a.createdAt).map(publicProduct));
  }
  if (route === 'POST /api/quote') {
    const b = await readBody(req, 2 * 1024 * 1024);
    const q = priceOrder(b);
    return json(200, { subtotal: q.subtotal, discount: q.discount, promo: q.promo, shipping: q.shipping, total: q.total });
  }
  if (route === 'POST /api/orders') {
    if (!rateLimit('order:' + clientIP(req), 15, 3600e3)) throw fail(429, 'Too many orders from this device. Try again later.');
    const b = await readBody(req, 12 * 1024 * 1024);
    const c = b.customer || {};
    const customer = { name: str(c.name, 80), phone: str(c.phone, 25), email: str(c.email, 120), address: str(c.address, 240), city: str(c.city, 60) };
    if (!customer.name || !customer.address || customer.phone.replace(/\D/g, '').length < 7) throw fail(400, 'Add your name, phone number and delivery address');
    if (!settings.shipping[b.delivery]) throw fail(400, 'Choose a delivery option');
    const q = priceOrder(b);
    const method = ['apple', 'visa', 'mastercard', 'transfer'].includes(b.payment && b.payment.method) ? b.payment.method : 'transfer';
    let paymentStatus = 'Awaiting payment'; let reference = '';
    if (method !== 'transfer' && b.payment.reference) {
      reference = str(b.payment.reference, 80);
      await verifyPaystack(reference, q.total);
      paymentStatus = 'Paid online';
    } else if (method === 'transfer') paymentStatus = 'Awaiting bank transfer';
    if (q.lines.filter((l) => l.type === 'custom' && l.imageData).length > 6) throw fail(400, 'Too many custom uploads in one order');
    const items = q.lines.map((l) => {
      const out = { type: l.type, name: l.name, unit: l.unit, qty: l.qty, size: l.size, color: l.color };
      if (l.type === 'product') { out.productId = l.productId; out.image = l.image; }
      else {
        out.text = l.text; out.position = l.position;
        out.image = l.imageData ? saveDataUrl(l.imageData, 'custom', 3 * 1024 * 1024) : (l.print.startsWith('/assets/prints/') ? l.print : '');
      }
      return out;
    });
    db.counters.order += 1;
    const ship = settings.shipping[b.delivery];
    const order = {
      id: 'UV-' + db.counters.order, createdAt: Date.now(), status: 'New', seen: false, customer, items,
      subtotal: q.subtotal, discount: q.discount, promo: q.promo, shipping: q.shipping, total: q.total,
      delivery: { key: b.delivery, label: ship.label, days: ship.days, fee: ship.fee },
      payment: { method, reference }, paymentStatus,
    };
    db.orders.unshift(order); saveDB();
    broadcast('order', order);
    notifyOwner(orderMessage(order, baseUrl(req) + '/admin'), `New order ${order.id} — ${money(order.total)}`).catch(() => {});
    return json(201, { ok: true, order: { id: order.id, total: order.total, paymentStatus, status: order.status }, bank: method === 'transfer' ? settings.bank : null, whatsapp: settings.store.whatsapp });
  }
  if (route === 'POST /api/orders/lookup') {
    const b = await readBody(req, 100 * 1024);
    const tail = str(b.phone, 25).replace(/\D/g, '').slice(-8);
    const ids = Array.isArray(b.ids) ? b.ids.slice(0, 50) : [];
    const found = db.orders.filter((o) => ids.includes(o.id) && tail && o.customer.phone.replace(/\D/g, '').endsWith(tail));
    return json(200, found.map((o) => ({ id: o.id, createdAt: o.createdAt, status: o.status, paymentStatus: o.paymentStatus, total: o.total, delivery: o.delivery.label, items: o.items.map((i) => ({ name: i.name, qty: i.qty, size: i.size, color: i.color, image: i.image })) })));
  }

  /* ---- admin auth ---- */
  if (route === 'GET /api/admin/me') return json(200, { setup: !!auth.hash, signedIn: isAdmin(req) });
  if (route === 'POST /api/admin/setup') {
    if (auth.hash) throw fail(403, 'Password already set');
    const b = await readBody(req, 10 * 1024);
    if (str(b.password, 100).length < 8) throw fail(400, 'Use at least 8 characters');
    auth.salt = crypto.randomBytes(16).toString('hex'); auth.hash = hashPw(b.password, auth.salt);
    newSession(res, req); return json(200, { ok: true });
  }
  if (route === 'POST /api/admin/login') {
    if (!rateLimit('login:' + clientIP(req), 8, 10 * 60e3)) throw fail(429, 'Too many attempts. Wait a few minutes.');
    const b = await readBody(req, 10 * 1024);
    const ok = auth.hash && crypto.timingSafeEqual(Buffer.from(hashPw(String(b.password || ''), auth.salt), 'hex'), Buffer.from(auth.hash, 'hex'));
    if (!ok) throw fail(401, 'Wrong password');
    newSession(res, req); return json(200, { ok: true });
  }
  if (route === 'POST /api/admin/logout') {
    const t = cookies(req).uvsid; if (t) { delete auth.sessions[t]; saveAuth(); }
    res.setHeader('Set-Cookie', 'uvsid=; HttpOnly; Path=/; Max-Age=0'); return json(200, { ok: true });
  }

  /* ---- admin (signed in) ---- */
  if (url.pathname.startsWith('/api/admin/')) {
    requireAdmin(req);
    if (route === 'GET /api/admin/events') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
      res.write('retry: 4000\n\n'); sseClients.add(res);
      const beat = setInterval(() => res.write(': ping\n\n'), 25000);
      req.on('close', () => { clearInterval(beat); sseClients.delete(res); });
      return;
    }
    if (route === 'GET /api/admin/products') return json(200, db.products.slice().sort((a, b) => b.createdAt - a.createdAt));
    if (route === 'POST /api/admin/products') {
      const b = await readBody(req);
      const p = { id: crypto.randomBytes(5).toString('hex'), createdAt: Date.now(), ...cleanProduct(b) };
      db.products.push(p); saveDB(); return json(201, p);
    }
    let m = /^\/api\/admin\/products\/([\w-]+)$/.exec(url.pathname);
    if (m) {
      const p = db.products.find((x) => x.id === m[1]); if (!p) throw fail(404, 'Not found');
      if (req.method === 'PUT') { Object.assign(p, cleanProduct(await readBody(req), p)); saveDB(); return json(200, p); }
      if (req.method === 'DELETE') { p.images.forEach(removeUpload); db.products = db.products.filter((x) => x !== p); saveDB(); return json(200, { ok: true }); }
    }
    if (route === 'GET /api/admin/orders') return json(200, db.orders);
    m = /^\/api\/admin\/orders\/([\w-]+)$/.exec(url.pathname);
    if (m && req.method === 'PATCH') {
      const o = db.orders.find((x) => x.id === m[1]); if (!o) throw fail(404, 'Not found');
      const b = await readBody(req, 10 * 1024);
      if (b.status !== undefined) { if (!['New', 'Confirmed', 'Packed', 'Shipped', 'Delivered', 'Cancelled'].includes(b.status)) throw fail(400, 'Bad status'); o.status = b.status; }
      if (b.paymentStatus !== undefined) { if (!['Paid online', 'Paid (transfer)', 'Paid (cash)', 'Awaiting payment', 'Awaiting bank transfer'].includes(b.paymentStatus)) throw fail(400, 'Bad payment status'); o.paymentStatus = b.paymentStatus; }
      if (b.seen !== undefined) o.seen = !!b.seen;
      saveDB(); return json(200, o);
    }
    if (route === 'POST /api/admin/orders/seen') { db.orders.forEach((o) => { o.seen = true; }); saveDB(); return json(200, { ok: true }); }
    if (route === 'GET /api/admin/settings') return json(200, settings);
    if (route === 'PUT /api/admin/settings') {
      const b = await readBody(req, 200 * 1024);
      const next = merge(DEFAULT_SETTINGS, b);
      next.customPrice = Math.max(0, Math.round(Number(next.customPrice) || 0));
      for (const k of ['standard', 'express']) { next.shipping[k].fee = Math.max(0, Math.round(Number(next.shipping[k].fee) || 0)); next.shipping[k].label = str(next.shipping[k].label, 40) || DEFAULT_SETTINGS.shipping[k].label; next.shipping[k].days = str(next.shipping[k].days, 40); }
      next.promos = (Array.isArray(b.promos) ? b.promos : []).map((p) => ({ code: str(p.code, 24).toUpperCase(), percent: Math.min(100, Math.max(1, Math.round(Number(p.percent) || 0))) })).filter((p) => p.code && p.percent);
      settings = next; writeJSON(F.settings, settings); return json(200, settings);
    }
    if (route === 'POST /api/admin/test-notify') {
      const r = await notifyOwner('✅ Test from Unusual Vogues. Order alerts will reach you here.', 'Unusual Vogues test alert');
      return json(200, { results: r });
    }
    if (route === 'POST /api/admin/password') {
      const b = await readBody(req, 10 * 1024);
      if (hashPw(String(b.current || ''), auth.salt) !== auth.hash) throw fail(401, 'Current password is wrong');
      if (str(b.next, 100).length < 8) throw fail(400, 'Use at least 8 characters');
      auth.salt = crypto.randomBytes(16).toString('hex'); auth.hash = hashPw(b.next, auth.salt); auth.sessions = {}; saveAuth();
      newSession(res, req); return json(200, { ok: true });
    }
  }
  throw fail(404, 'Not found');
}

function serveFile(req, res, file) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    const isImg = /\.(jpe?g|png|webp)$/.test(ext);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': isImg ? 'public, max-age=604800' : 'no-cache' });
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) {
      if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && req.headers['content-length'] !== '0' && req.headers['content-length'] && !String(req.headers['content-type'] || '').includes('application/json')) throw fail(415, 'JSON only');
      return await handleApi(req, res, url);
    }
    let p = decodeURIComponent(url.pathname);
    if (p.startsWith('/uploads/')) {
      const f = path.normalize(path.join(DATA_DIR, p)); if (!f.startsWith(UPLOADS)) throw fail(403, 'Forbidden');
      return serveFile(req, res, f);
    }
    if (p === '/admin' || p === '/admin/') p = '/admin/index.html';
    if (p.endsWith('/')) p += 'index.html';
    const f = path.normalize(path.join(PUBLIC, p)); if (!f.startsWith(PUBLIC)) throw fail(403, 'Forbidden');
    return serveFile(req, res, f);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (!e.status) console.error(e);
    send(res, e.status || 500, { error: e.status ? e.message : 'Something went wrong on our side' });
  }
});
server.listen(PORT, () => console.log(`Unusual Vogues running → store: http://localhost:${PORT}  admin: http://localhost:${PORT}/admin`));
