# مذاكرتي — مشروع APK (Capacitor)

## المطلوب على الكمبيوتر (مرة واحدة)
1. Node.js (النسخة LTS): https://nodejs.org
2. Android Studio: https://developer.android.com/studio  (بيثبّت معاه Android SDK وJava)

## الخطوات
افتح الـ Terminal جوه فولدر المشروع ونفّذ:

    npm install
    npx cap add android
    npx cap sync android

### الطريقة 1: من Android Studio
    npx cap open android
ثم من القايمة: Build > Build Bundle(s) / APK(s) > Build APK(s)

### الطريقة 2: من الـ Terminal
    cd android
    ./gradlew assembleDebug        (على ويندوز: gradlew.bat assembleDebug)

الملف بيطلع في:
    android/app/build/outputs/apk/debug/app-debug.apk

انقله للموبايل وثبّته (فعّل «التثبيت من مصادر غير معروفة»).

## تعديل التطبيق بعد كده
عدّل الملف www/index.html ثم نفّذ: npx cap sync android وابنِ الـ APK تاني.

## ملاحظات
- بياناتك (مهام، إنجازات...) بتتخزن جوه التطبيق وهتبدأ فاضية في الـ APK.
- خط Cairo بيتحمّل من الإنترنت؛ من غير نت هيظهر خط النظام.
- قفل التطبيق بيقفل التطبيق نفسه بس، مش الموبايل.
- التنبيهات لسه بتعتمد على المتصفح. لتنبيهات أصلية أضف الإضافة @capacitor/local-notifications.
- ملف debug للتجربة الشخصية. للنشر على Google Play لازم توقّع APK/AAB بمفتاح خاص.
