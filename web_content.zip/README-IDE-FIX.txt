blure Stage 3 IDE maintenance
- Editor recognizes graphical UI, modules, components and OS window commands.
- Service worker cache includes blure-ui.js?v=0930 and has new version.
- Offline status gives actionable failure notice.
- Preserve existing workspace data; back up before deployment.
- Hard-refresh the IDE after upload.
