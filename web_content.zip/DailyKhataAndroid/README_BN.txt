দৈনিক খরচার খাতা — Android APK Project (V4 Data Protection)
==========================================================

এই ZIP-এ Android Studio-তে খোলার মতো Java + AndroidX WebView প্রজেক্ট আছে।
মূল HTML অ্যাপটি app/src/main/assets/index.html-এ আছে।

ডেটা সংরক্ষণের ব্যবস্থা
----------------------
1. অ্যাপের localStorage-এর প্রতিটি setItem/removeItem/clear পরিবর্তন Android private SQLite database-এ লেখা হয়।
2. অ্যাপ চালুর আগে SQLite-র ডেটা localStorage-এ ফিরিয়ে আনা হয়।
3. SQLite write-ahead logging (WAL) চালু; অ্যাপ pause/stop হলে checkpoint করা হয়।
4. Settings-এর Backup/Restore থেকে JSON ফাইল ফোনের পছন্দের ফোল্ডারে Export/Import করা যায়। Export-এ সব localStorage key এবং Future Planner ডেটা অন্তর্ভুক্ত।
5. Android Auto Backup এবং device-to-device transfer rules-এ database, shared preferences ও app files অন্তর্ভুক্ত করা হয়েছে (Android-এর backup service, account, device ও নেটওয়ার্ক সেটিংসের ওপর নির্ভরশীল)।
6. অ্যাপের মূল হিসাব অফলাইনে কাজ করে। Gemini AI-তে ইন্টারনেট ও API key লাগতে পারে।

অত্যন্ত গুরুত্বপূর্ণ সীমাবদ্ধতা
----------------------------
কোনো local-only ব্যবস্থা আজীবন ডেটা থাকার ১০০% নিশ্চয়তা দেয় না। অ্যাপ uninstall, Settings থেকে Clear storage/data, factory reset, ফোন নষ্ট/হারানো বা স্টোরেজ ক্ষতিগ্রস্ত হলে ডেটা হারাতে পারে। Android Auto Backup সব ডিভাইসে/সব সময় নাও চলতে পারে। তাই Settings > সম্পূর্ণ ব্যাকআপ ও রিস্টোর > ব্যাকআপ ডাউনলোড করুন ব্যবহার করে নিয়মিত JSON ব্যাকআপ তৈরি করুন এবং Google Drive/কম্পিউটার/অন্য নিরাপদ স্থানে আলাদা কপি রাখুন।

এই সংস্করণে Export সম্পূর্ণ localStorage key অন্তর্ভুক্ত করে; Restore বর্তমান ডেটার পরিবর্তে ব্যাকআপের ডেটা বসায়। Restore করার আগে বর্তমান ডেটারও ব্যাকআপ নিন।

APK তৈরি
--------
1. ZIP Extract করুন।
2. Android Studio-তে DailyKhataAndroid ফোল্ডার Open করুন।
3. Gradle Sync সম্পূর্ণ হতে দিন। প্রথমবার Android SDK/Gradle ডাউনলোডে ইন্টারনেট লাগবে।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK ইনস্টল করে প্রথমে একটি test entry যোগ করুন, অ্যাপ বন্ধ করে আবার খুলে দেখুন, তারপর Backup Export এবং test restore করুন।

প্রযুক্তিগত তথ্য
---------------
Package: com.papai.dailykhata
Language: Java
Minimum Android: 6.0 (API 23)
Database: SQLite (app-private internal storage)
Web content: bundled local HTML in Android WebView
Data protection: SQLite persistence + JSON export/import + Android Auto Backup rules

নোট: এই পরিবেশে Android SDK/Gradle build এবং বাস্তব ফোনে পরীক্ষা চালানো হয়নি। এটি source project ZIP, তৈরি APK নয়।
