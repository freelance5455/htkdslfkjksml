package com.papai.dailykhata;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import androidx.webkit.WebViewAssetLoader;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.provider.OpenableColumns;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP = 7101, OPEN_BACKUP = 7102;
    private WebView webView;
    private VaultDb vaultDb;
    private WebViewAssetLoader assetLoader;
    private String pendingBackup = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        vaultDb = new VaultDb(this);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF060913);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                return handleExternalUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUrl(Uri.parse(url));
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidVault(), "AndroidVault");
        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private boolean handleExternalUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
        if ("https".equals(scheme) && "appassets.androidplatform.net".equals(host)) return false;
        if ("upi".equals(scheme) || "https".equals(scheme) || "http".equals(scheme) || "tel".equals(scheme) || "mailto".equals(scheme)) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "এই লিংক খোলার উপযুক্ত অ্যাপ পাওয়া যায়নি", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        return true;
    }

    public class AndroidVault {
        @JavascriptInterface public String loadAll() { return vaultDb.readAll().toString(); }
        @JavascriptInterface public void put(String key, String value) { vaultDb.put(key, value); }
        @JavascriptInterface public void remove(String key) { vaultDb.remove(key); }
        @JavascriptInterface public void clearAll() { vaultDb.clear(); }
        @JavascriptInterface public void exportBackup(String json) {
            runOnUiThread(() -> {
                pendingBackup = json;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "daily-khata-backup.json");
                startActivityForResult(i, CREATE_BACKUP);
            });
        }
        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, OPEN_BACKUP);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == CREATE_BACKUP) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8)); out.flush();
                }
                Toast.makeText(this, "ব্যাকআপ ফাইলে সেভ হয়েছে", Toast.LENGTH_LONG).show();
            } else if (requestCode == OPEN_BACKUP) {
                StringBuilder b = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) b.append(new String(buf, 0, n, StandardCharsets.UTF_8));
                }
                JSONObject payload = new JSONObject(b.toString());
                JSONObject values = payload.optJSONObject("localStorage");
                if (values == null) throw new Exception("No localStorage data");
                vaultDb.clear();
                java.util.Iterator<String> keys = values.keys();
                while (keys.hasNext()) { String k = keys.next(); vaultDb.put(k, values.optString(k, "")); }
                final String raw = JSONObject.quote(payload.toString());
                webView.post(() -> webView.evaluateJavascript("window.restoreNativeBackup && window.restoreNativeBackup(" + raw + ")", null));
            }
        } catch (Exception e) {
            Toast.makeText(this, "ফাইলটি পড়া/লেখা যায়নি: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (vaultDb != null) vaultDb.checkpoint();
    }

    @Override protected void onStop() {
        super.onStop();
        if (vaultDb != null) vaultDb.checkpoint();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    static class VaultDb extends SQLiteOpenHelper {
        VaultDb(Activity c) { super(c, "daily_khata_vault.db", null, 1); }
        @Override public void onConfigure(SQLiteDatabase db) {
            super.onConfigure(db);
            db.setForeignKeyConstraintsEnabled(true);
            db.enableWriteAheadLogging();
        }
        @Override public void onCreate(SQLiteDatabase db) { db.execSQL("CREATE TABLE kv (k TEXT PRIMARY KEY NOT NULL, v TEXT NOT NULL)"); }
        @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) { }
        synchronized void checkpoint() {
            try (Cursor c = getWritableDatabase().rawQuery("PRAGMA wal_checkpoint(FULL)", null)) { while (c.moveToNext()) { /* consume result */ } }
            catch (Exception ignored) { }
        }
        synchronized void put(String k, String v) {
            ContentValues cv = new ContentValues(); cv.put("k", k); cv.put("v", v);
            getWritableDatabase().insertWithOnConflict("kv", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        }
        synchronized void remove(String k) { getWritableDatabase().delete("kv", "k=?", new String[]{k}); }
        synchronized void clear() { getWritableDatabase().delete("kv", null, null); }
        synchronized JSONObject readAll() {
            JSONObject out = new JSONObject();
            try (Cursor c = getReadableDatabase().rawQuery("SELECT k,v FROM kv", null)) {
                while (c.moveToNext()) out.put(c.getString(0), c.getString(1));
            } catch (Exception ignored) { }
            return out;
        }
    }
}
