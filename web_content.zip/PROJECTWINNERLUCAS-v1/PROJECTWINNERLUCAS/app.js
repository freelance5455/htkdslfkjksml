const KEY='pwl-v1';
const defaults=[
 ['Acordar no horário','disciplina'],['Arrumar a cama','disciplina'],['Higiene pessoal','corpo'],['Beber água ao longo do dia','corpo'],['Estudar eletromecânica','formacao'],['Treino ou movimento leve','corpo'],['Comparecer ao SENAI','formacao'],['Revisar uma aula','formacao'],['Fazer pausas do celular','disciplina'],['Skincare da manhã','corpo'],['Skincare da noite','corpo'],['Preparar o dia seguinte','disciplina']
];
const pillars=[['Formação','formacao'],['Corpo & saúde','corpo'],['CNH','cnh'],['Primeira moto','moto'],['Disciplina','disciplina']];
let data=load();
function load(){try{return JSON.parse(localStorage.getItem(KEY))||{}}catch{return {}}}
function save(){localStorage.setItem(KEY,JSON.stringify(data));render()}
function day(){return new Date().toLocaleDateString('en-CA')}
function ensure(){data.days??={};data.days[day()]??={habits:{},water:0};data.habits??=defaults.map((x,i)=>({id:'h'+i,name:x[0],pillar:x[1],enabled:true}));data.studies??=[];data.workouts??=[];data.money??=[];data.sleep??=[];data.waterGoal??=2000;data.wakeGoal??='08:00';data.goals??={cnh:0,moto:0,gear:0,docs:0};}
ensure();
const $=id=>document.getElementById(id), money=n=>(Number(n)||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
function toast(t){$('toast').textContent=t;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),1800)}
function render(){
 ensure();let d=data.days[day()],active=data.habits.filter(h=>h.enabled),done=active.filter(h=>d.habits[h.id]).length,pct=active.length?Math.round(done/active.length*100):0;
 $('today').textContent=new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 $('percent').textContent=pct+'%';$('ring').style.background=`conic-gradient(var(--accent) ${pct*3.6}deg,transparent 0)`;$('points').textContent=done*10;$('doneCount').textContent=done+'/'+active.length;
 $('streak').textContent=streak()+' dias';$('pillarGrid').innerHTML=pillars.map(([name,key])=>{let hs=active.filter(h=>h.pillar===key),n=hs.filter(h=>d.habits[h.id]).length;return `<div class="pillar"><b>${name}</b><small>${n}/${hs.length||0} ações concluídas</small><div class="bar"><i style="width:${hs.length?n/hs.length*100:0}%"></i></div></div>`}).join('');
 $('todayFocus').innerHTML=active.filter(h=>!d.habits[h.id]).slice(0,3).map(h=>`<p>• ${esc(h.name)}</p>`).join('')||'<p>Você concluiu todos os hábitos ativos. Excelente — respeite seu descanso.</p>';
 $('habitList').innerHTML=active.map(h=>`<label class="habit ${d.habits[h.id]?'done':''}"><input type="checkbox" data-habit="${h.id}" ${d.habits[h.id]?'checked':''}><span>${esc(h.name)}<small>${pillarName(h.pillar)}</small></span><button class="smallbtn" data-edit="${h.id}">Editar</button></label>`).join('');
 $('waterNow').textContent=d.water;$('waterGoal').value=data.waterGoal;$('waterBar').style.width=Math.min(100,d.water/data.waterGoal*100)+'%';$('wakeGoal').value=data.wakeGoal;
 let mins=data.studies.reduce((s,x)=>s+x.minutes,0);$('studyTotal').textContent=mins+' min';$('studySessions').textContent=data.studies.length;
 $('studyHistory').innerHTML=data.studies.slice().reverse().slice(0,12).map(x=>item(`${esc(x.subject)} · ${x.minutes} min`,x.date,esc(x.note||'Sem observações'))).join('')||empty('Nenhum estudo registrado ainda.');
 $('workoutHistory').innerHTML=data.workouts.slice().reverse().slice(0,8).map(x=>item('Treino em casa',x.date,'Atividade registrada')).join('')||'<p class="muted">Ainda sem registros.</p>';
 $('skinProducts').value=data.skinProducts||'';$('hairDays').value=data.hairDays||'';$('hairProducts').value=data.hairProducts||'';$('foodNote').value=data.foodNote||'';
 for(let k of ['cnh','moto','gear','docs'])$('goal'+k[0].toUpperCase()+k.slice(1)).value=data.goals[k]||0;
 let balance=data.money.reduce((s,x)=>s+(x.type==='entrada'?x.value:-x.value),0);$('balance').textContent=money(balance);
 $('moneyProgress').innerHTML=Object.entries(data.goals).map(([k,v])=>{let label={cnh:'CNH',moto:'Moto',gear:'Equipamentos',docs:'Documentação/manutenção'}[k];return `<p>${label}: meta ${money(v)}</p><div class="bar"><i style="width:${v?Math.max(0,Math.min(100,balance/v*100)):0}%"></i></div>`}).join('');
 $('moneyHistory').innerHTML=data.money.slice().reverse().slice(0,8).map(x=>item(`${x.type==='entrada'?'+':'−'} ${money(x.value)} · ${esc(x.desc)}`,x.date,'')).join('')||'';
 $('bikeNotes').value=data.bikeNotes||'';
 $('totalPoints').textContent=allPoints();$('activeDays').textContent=Object.keys(data.days).filter(k=>Object.values(data.days[k].habits||{}).some(Boolean)).length;
 $('achievements').innerHTML=[['Primeiro passo',allPoints()>=10],['Constância em construção',streak()>=3],['Estudante ativo',data.studies.length>=5],['Movimento iniciado',data.workouts.length>=1],['Planejador financeiro',data.money.length>=1]].map(([t,ok])=>`<div class="historyitem">${ok?'🏅':'🔒'} <b>${t}</b><small> ${ok?'Desbloqueada':'Continue no seu ritmo'}</small></div>`).join('');
 $('history').innerHTML=Object.entries(data.days).sort((a,b)=>b[0].localeCompare(a[0])).slice(0,7).map(([date,v])=>item(date,Object.values(v.habits||{}).filter(Boolean).length+' hábitos concluídos',`${v.water||0} ml de água`)).join('');
}
function item(t,s,n){return `<div class="historyitem"><b>${t}</b><br><small>${s||''} ${n?'· '+n:''}</small></div>`}
function empty(t){return `<div class="historyitem muted">${t}</div>`}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function pillarName(k){return ({formacao:'Formação',corpo:'Corpo & saúde',cnh:'CNH',moto:'Primeira moto',disciplina:'Disciplina'})[k]||k}
function streak(){let n=0,d=new Date();for(let i=0;i<365;i++){let k=new Date(d);k.setDate(k.getDate()-i);let key=k.toLocaleDateString('en-CA'),v=data.days[key];if(v&&Object.values(v.habits||{}).some(Boolean))n++;else if(i>0)break;}return n}
function allPoints(){return Object.values(data.days).reduce((s,v)=>s+Object.values(v.habits||{}).filter(Boolean).length*10,0)}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));b.classList.add('active');$(b.dataset.tab).classList.add('active')});
document.querySelectorAll('[data-sub]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-sub]').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.subpage').forEach(x=>x.classList.remove('active'));b.classList.add('active');$(b.dataset.sub).classList.add('active')});
document.addEventListener('change',e=>{if(e.target.dataset.habit){data.days[day()].habits[e.target.dataset.habit]=e.target.checked;save()}});
document.addEventListener('click',e=>{if(e.target.dataset.water){data.days[day()].water+=Number(e.target.dataset.water);save()}if(e.target.dataset.edit){let h=data.habits.find(x=>x.id===e.target.dataset.edit),v=prompt('Nome do hábito:',h.name);if(v===null)return;if(v.trim())h.name=v.trim();else h.enabled=false;save()}});
$('addHabit').onclick=()=>{let name=prompt('Qual hábito deseja acompanhar?');if(name?.trim()){data.habits.push({id:'h'+Date.now(),name:name.trim(),pillar:'disciplina',enabled:true});save()}};
$('waterGoal').onchange=e=>{data.waterGoal=Math.max(500,Math.min(5000,Number(e.target.value)||2000));save()};
$('wakeGoal').onchange=e=>{data.wakeGoal=e.target.value;save()};
$('waterCustom').onclick=()=>{let n=Number(prompt('Quantos ml?'));if(n>0&&n<=1000){data.days[day()].water+=n;save()}};
$('saveStudy').onclick=()=>{let subject=$('subject').value.trim(),minutes=Number($('studyMinutes').value);if(!subject||minutes<5)return toast('Informe matéria e duração válida.');data.studies.push({subject,minutes,note:$('studyNote').value,date:day()});$('subject').value='';$('studyNote').value='';save();toast('Estudo registrado!')};
$('logWorkout').onclick=()=>{data.workouts.push({date:day()});save();toast('Atividade registrada!')};
$('logSkincare').onclick=()=>{let d=data.days[day()];data.habits.filter(h=>/skincare/i.test(h.name)).forEach(h=>d.habits[h.id]=true);save();toast('Cuidados registrados.');};
$('saveSkin').onclick=()=>{data.skinProducts=$('skinProducts').value;save();toast('Produtos salvos.')};
$('saveHair').onclick=()=>{data.hairDays=$('hairDays').value;data.hairProducts=$('hairProducts').value;save();toast('Rotina capilar salva.')};
$('saveSleep').onclick=()=>{let a=$('sleepStart').value,b=$('sleepEnd').value;if(!a||!b)return toast('Preencha os dois horários.');let [ah,am]=a.split(':').map(Number),[bh,bm]=b.split(':').map(Number),m=(bh*60+bm)-(ah*60+am);if(m<0)m+=1440;data.sleep.push({date:day(),minutes:m,start:a,end:b});$('sleepResult').textContent=`Duração registrada: ${Math.floor(m/60)}h ${m%60}min`;save()};
$('saveFood').onclick=()=>{data.foodNote=$('foodNote').value;save();toast('Notas salvas.')};
$('saveGoals').onclick=()=>{data.goals={cnh:Number($('goalCnh').value),moto:Number($('goalMoto').value),gear:Number($('goalGear').value),docs:Number($('goalDocs').value)};save();toast('Metas salvas.')};
$('saveMoney').onclick=()=>{let value=Number($('moneyValue').value);if(value<=0)return toast('Informe um valor maior que zero.');data.money.push({type:$('moneyType').value,value,desc:$('moneyDesc').value||'Sem descrição',date:day()});$('moneyValue').value='';$('moneyDesc').value='';save();toast('Movimentação registrada.')};
$('saveBike').onclick=()=>{data.bikeNotes=$('bikeNotes').value;save();toast('Pesquisa salva.')};
$('themeBtn').onclick=()=>{document.body.classList.toggle('light');localStorage.setItem('pwl-theme',document.body.classList.contains('light')?'light':'dark')};
if(localStorage.getItem('pwl-theme')==='light')document.body.classList.add('light');
render();
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));

$('exportData').onclick=()=>{let blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='projectwinnerlucas-backup-'+day()+'.json';a.click();URL.revokeObjectURL(url);toast('Backup exportado.')};
$('importDataBtn').onclick=()=>$('importData').click();
$('importData').onchange=async e=>{let f=e.target.files[0];if(!f)return;try{let parsed=JSON.parse(await f.text());if(!parsed||typeof parsed!=='object'||!parsed.days)throw Error();if(!confirm('Importar substituirá os dados atuais deste navegador. Continuar?'))return;data=parsed;ensure();save();toast('Backup importado.')}catch{toast('Arquivo de backup inválido.')}e.target.value=''};
