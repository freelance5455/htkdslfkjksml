(() => {
  const $ = id => document.getElementById(id);
  const status = $('status'), orb = $('orb'), startBtn = $('start'), stopBtn = $('stop');
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null, active = false, speaking = false, restartTimer = null;
  const memoryKey = 'veed_voice_memory_v1';

  function setStatus(text, mode='') {
    status.textContent = text;
    orb.classList.remove('listening','speaking');
    if (mode) orb.classList.add(mode);
  }
  function getMemory() {
    if (!$('memoryOn').checked) return [];
    try { return JSON.parse(localStorage.getItem(memoryKey) || '[]'); } catch { return []; }
  }
  function saveMemory(text) {
    if (!$('memoryOn').checked || !text) return;
    const items = getMemory();
    items.push({text, at: new Date().toISOString()});
    localStorage.setItem(memoryKey, JSON.stringify(items.slice(-40)));
  }
  function clean(s) { return (s || '').toLowerCase().replace(/[؟?!،,.؛:]/g,' ').replace(/\s+/g,' ').trim(); }

  function chooseVoice() {
    const voices = speechSynthesis.getVoices();
    const selected = $('voice').value;
    return voices.find(v => v.name === selected) ||
      voices.find(v => (v.lang || '').toLowerCase().startsWith('fa')) ||
      voices.find(v => (v.lang || '').toLowerCase().startsWith('en')) || null;
  }
  function loadVoices() {
    if (!('speechSynthesis' in window)) return;
    const select = $('voice'), old = select.value;
    const voices = speechSynthesis.getVoices();
    select.innerHTML = '<option value="">صدای فارسی پیش‌فرض</option>';
    voices.forEach(v => {
      const opt = document.createElement('option'); opt.value = v.name;
      opt.textContent = `${v.name} (${v.lang})`; select.appendChild(opt);
    });
    if (old) select.value = old;
  }
  if ('speechSynthesis' in window) {
    loadVoices();
    speechSynthesis.onvoiceschanged = loadVoices;
  }

  function speak(text) {
    if (!('speechSynthesis' in window)) { setStatus(text); return; }
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    const v = chooseVoice();
    if (v) u.voice = v;
    u.lang = v?.lang || 'fa-IR'; u.rate = 1; u.pitch = 1;
    u.onstart = () => { speaking = true; setStatus('VEED در حال صحبت است…','speaking'); };
    u.onend = () => {
      speaking = false;
      if (active && $('autoListen').checked) startListening();
      else setStatus('آماده‌ام؛ برای ادامه دکمه میکروفون را بزن');
    };
    u.onerror = () => {
      speaking = false;
      if (active && $('autoListen').checked) startListening();
      else setStatus('آماده');
    };
    speechSynthesis.speak(u);
  }

  function answer(raw) {
    const t = clean(raw);
    saveMemory(raw);
    if (!t) return 'صدات رو واضح نشنیدم؛ دوباره بگو.';
    if (t.includes('سلام') || t.includes('درود')) return 'سلام امیر! من وید هستم، گوشم با توئه.';
    if (t.includes('اسمت') || t.includes('کی هستی')) return 'من وید هستم، دستیار صوتی تو.';
    if (t.includes('خوبی') || t.includes('حالت چطوره')) return 'خوبم رفیق، آماده‌ام کمکت کنم.';
    if (t.includes('چه چیز') && t.includes('یادته')) {
      const m = getMemory();
      return m.length ? `آخرین چیزی که از حرف‌هات روی این دستگاه ذخیره شده اینه: ${m[m.length-1].text}` : 'هنوز چیزی در حافظه محلی ذخیره نشده.';
    }
    if (t.includes('حافظه') && (t.includes('پاک') || t.includes('حذف'))) {
      localStorage.removeItem(memoryKey); return 'حافظه محلی پاک شد.';
    }
    if (t.includes('توقف') || t.includes('ساکت شو')) { active = false; return 'باشه، گوش دادن رو متوقف می‌کنم.'; }
    if (t.includes('خداحافظ') || t.includes('فعلا')) { active = false; return 'فعلاً امیر، هر وقت خواستی برگرد.'; }
    if (t.includes('یاد بگیر') || t.includes('یادت باشه')) {
      const note = raw.replace(/.*?(یاد بگیر|یادت باشه)/i,'').trim();
      if (note) { saveMemory('یادداشت: ' + note); return 'باشه، این مورد روی همین دستگاه ذخیره شد.'; }
      return 'بگو دقیقاً چی رو ذخیره کنم.';
    }
    if (t.includes('ساعت')) return 'برای اعلام ساعت دقیق باید به سرویس زمان متصل باشم.';
    return 'حرفت رو شنیدم. برای جواب دادن به سؤال‌های آزاد، باید سرویس هوش مصنوعی آنلاین به این پروژه وصل بشه؛ این نسخه هنوز به API متصل نیست.';
  }

  function startListening() {
    if (!active || !recognition || speaking) return;
    clearTimeout(restartTimer);
    try { recognition.start(); setStatus('گوش می‌دم…','listening'); }
    catch { setStatus('میکروفون در حال آماده شدن است…'); }
  }
  if (!Recognition) {
    startBtn.disabled = true;
    setStatus('این مرورگر تشخیص گفتار را پشتیبانی نمی‌کند؛ Chrome را امتحان کن.');
  } else {
    recognition = new Recognition();
    recognition.lang = 'fa-IR'; recognition.continuous = false;
    recognition.interimResults = false; recognition.maxAlternatives = 1;
    recognition.onresult = e => {
      const heard = e.results?.[0]?.[0]?.transcript || '';
      speak(answer(heard));
    };
    recognition.onerror = e => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        active = false; setStatus('اجازه میکروفون را از تنظیمات مرورگر فعال کن.');
      } else if (e.error === 'network') {
        setStatus('سرویس تشخیص گفتار در دسترس نیست؛ اتصال اینترنت را بررسی کن.');
      } else if (active && !speaking) setStatus('صدا دریافت نشد؛ دوباره تلاش کن.');
    };
    recognition.onend = () => {
      if (active && !speaking && $('autoListen').checked) {
        restartTimer = setTimeout(startListening, 450);
      } else if (!active && !speaking) setStatus('گفت‌وگو متوقف است.');
    };
  }

  startBtn.addEventListener('click', () => {
    if (!recognition) return;
    active = true; startListening();
  });
  stopBtn.addEventListener('click', () => {
    active = false; clearTimeout(restartTimer);
    try { recognition?.stop(); } catch {}
    if ('speechSynthesis' in window) speechSynthesis.cancel();
    speaking = false; setStatus('متوقف شد.');
  });
  $('clearMemory').addEventListener('click', () => {
    localStorage.removeItem(memoryKey);
    setStatus('حافظه محلی پاک شد.');
  });
})();