TestTJ — версияи ислоҳшуда

index.html дар app/src/main/assets/index.html ҷойгир шудааст.
MainActivity онро бо file:///android_asset/index.html мекушояд.
Агар APK-созанда папкаи web/html талаб кунад, web/index.html низ дохил шудааст.
