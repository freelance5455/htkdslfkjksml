import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from "./config.js";

const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
const $ = (s) => document.querySelector(s);
const grid = $("#mangaGrid");
let allManga = [];
let activeGenre = "";
let currentManga = null;
let selectedChapterFiles = [];

function safe(v="") { return String(v).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function listVal(v) { return Array.isArray(v) ? v : []; }
function showMessage(el, msg, error=false) { el.textContent = msg; el.className = "message " + (error ? "error" : "success"); }

async function loadManga() {
  grid.innerHTML = '<div class="empty">جارٍ تحميل المكتبة...</div>';
  const { data, error } = await supabase.from("manga").select("*").eq("is_published", true).order("created_at", {ascending:false});
  if (error) { grid.innerHTML = `<div class="empty">تعذر تحميل المكتبة: ${safe(error.message)}</div>`; return; }
  allManga = data || [];
  renderManga();
}
function renderManga() {
  const q = $("#searchInput").value.trim().toLowerCase();
  const rows = allManga.filter(m => (!activeGenre || listVal(m.genres).includes(activeGenre)) &&
    (!q || (m.title||"").toLowerCase().includes(q) || (m.description||"").toLowerCase().includes(q)));
  $("#resultCount").textContent = `${rows.length} عمل`;
  grid.classList.remove("hidden");
  grid.innerHTML = rows.length ? rows.map(m => `
    <article class="manga-card" data-id="${m.id}">
      <button class="cover-button" data-open="${m.id}">
        ${m.cover_url ? `<img src="${safe(m.cover_url)}" alt="غلاف ${safe(m.title)}" loading="lazy">` : `<div class="cover-placeholder">漫画</div>`}
        ${m.is_featured ? '<span class="featured">مميز</span>' : ''}
      </button>
      <div class="card-info"><h3>${safe(m.title)}</h3><p>${safe(listVal(m.genres).join(" • ") || "مانهوا")}</p>
      <button class="text-button" data-open="${m.id}">عرض التفاصيل ←</button></div>
    </article>`).join("") : '<div class="empty">لا توجد نتائج. جرّبي كلمة أو تصنيفاً آخر.</div>';
}
async function openDetail(id) {
  const m = allManga.find(x => x.id === id); if (!m) return;
  currentManga = m;
  $("#mangaGrid").classList.add("hidden"); $("#readerView").classList.add("hidden");
  const {data: chapters, error} = await supabase.from("chapters").select("*").eq("manga_id", id).eq("is_published", true).order("chapter_number", {ascending:true});
  $("#detailView").classList.remove("hidden");
  $("#detailView").innerHTML = `
    <button class="back" id="backLibrary">← العودة للمكتبة</button>
    <div class="detail-head">${m.cover_url ? `<img src="${safe(m.cover_url)}" alt="">` : '<div class="cover-placeholder large">漫画</div>'}
      <div><p class="eyebrow">تفاصيل العمل</p><h2>${safe(m.title)}</h2><p class="muted">${safe(listVal(m.genres).join(" • "))}</p><p>${safe(m.description||"لا يوجد وصف بعد.")}</p>
      <button class="primary small" id="favoriteCurrent">♡ أضيفي للمفضلة</button></div></div>
    <h3 class="chapter-heading">الفصول</h3>
    ${error ? `<p class="message error">${safe(error.message)}</p>` : ""}
    <div class="chapter-list">${(chapters||[]).length ? chapters.map(c=>`<button class="chapter-row" data-chapter="${c.id}"><span>الفصل ${safe(c.chapter_number)}${c.title ? " — "+safe(c.title):""}</span><span>اقرئي ←</span></button>`).join("") : '<p class="empty">لا توجد فصول منشورة بعد.</p>'}</div>`;
  $("#backLibrary").onclick = backLibrary;
  $("#favoriteCurrent").onclick = () => toggleFavorite(m.id);
  $("#detailView").querySelectorAll("[data-chapter]").forEach(b => b.onclick = () => openChapter(b.dataset.chapter));
}
function backLibrary(){ $("#detailView").classList.add("hidden"); $("#readerView").classList.add("hidden"); $("#mangaGrid").classList.remove("hidden"); }
function getFavorites(){ try{return JSON.parse(localStorage.getItem("mangahub_favorites")||"[]")}catch{return []} }
function toggleFavorite(id){ let f=getFavorites(); f=f.includes(id)?f.filter(x=>x!==id):[...f,id]; localStorage.setItem("mangahub_favorites",JSON.stringify(f)); alert(f.includes(id)?"أضيفت إلى المفضلة":"حُذفت من المفضلة"); }
async function renderPdfAsPages(url, container) {
  const status = document.createElement("p");
  status.className = "pdf-loading";
  status.textContent = "جارٍ تجهيز صفحات PDF...";
  container.append(status);
  try {
    const pdfjs = await import("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs");
    pdfjs.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs";
    const pdf = await pdfjs.getDocument({ url }).promise;
    status.remove();

    const pageNodes = [];
    for (let n = 1; n <= pdf.numPages; n++) {
      const page = await pdf.getPage(n);
      const baseViewport = page.getViewport({ scale: 1 });
      const targetWidth = Math.max(280, Math.min(container.clientWidth || window.innerWidth, 900));
      const cssScale = targetWidth / baseViewport.width;
      const cssViewport = page.getViewport({ scale: cssScale });
      const holder = document.createElement("section");
      holder.className = "reader-page";
      holder.setAttribute("aria-label", `صفحة ${n}`);
      holder.style.aspectRatio = `${baseViewport.width} / ${baseViewport.height}`;
      const canvas = document.createElement("canvas");
      canvas.className = "pdf-page-canvas";
      canvas.width = Math.round(cssViewport.width * Math.min(window.devicePixelRatio || 1, 2));
      canvas.height = Math.round(cssViewport.height * Math.min(window.devicePixelRatio || 1, 2));
      canvas.style.aspectRatio = `${baseViewport.width} / ${baseViewport.height}`;
      holder.append(canvas);
      container.append(holder);
      pageNodes.push({ page, canvas, cssViewport });
    }

    const renderOne = async item => {
      if (item.done) return;
      item.done = true;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const viewport = item.page.getViewport({ scale: item.cssViewport.scale * dpr });
      await item.page.render({ canvas: item.canvas, viewport }).promise;
    };

    if ("IntersectionObserver" in window) {
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (!entry.isIntersecting) return;
          const index = Number(entry.target.dataset.pageIndex);
          renderOne(pageNodes[index]).catch(err => {
            entry.target.textContent = "تعذر عرض هذه الصفحة.";
            console.error(err);
          });
          observer.unobserve(entry.target);
        });
      }, { rootMargin: "900px 0px" });
      pageNodes.forEach((item, index) => {
        item.canvas.parentElement.dataset.pageIndex = index;
        observer.observe(item.canvas.parentElement);
      });
    } else {
      for (const item of pageNodes) await renderOne(item);
    }
  } catch (err) {
    console.error("PDF rendering error:", err);
    status.textContent = "تعذر عرض ملف PDF. تحققي من اتصال الإنترنت أو جرّبي ملفاً آخر.";
    status.classList.add("error");
  }
}

async function openChapter(id) {
  const {data:c,error}=await supabase.from("chapters").select("*").eq("id",id).single();
  if(error){alert(error.message);return;}
  $("#detailView").classList.add("hidden");
  $("#readerView").classList.remove("hidden");
  let urls = [];
  try { const parsed=JSON.parse(c.pdf_url); if(Array.isArray(parsed)) urls=parsed; else if(typeof parsed==="string") urls=[parsed]; } catch { if(c.pdf_url) urls=[c.pdf_url]; }

  const isPdf = urls.length === 1 && /\.pdf(?:$|[?#])/i.test(decodeURIComponent(urls[0]));
  const content = isPdf
    ? '<div class="pages pdf-pages" id="pdfPages"><p class="pdf-loading">جارٍ فتح ملف PDF...</p></div>'
    : urls.length
      ? `<div class="pages">${urls.map((u,i)=>`<section class="reader-page"><img src="${safe(u)}" alt="صفحة ${i+1}" loading="lazy"></section>`).join("")}</div>`
      : '<p class="empty">لا يوجد ملف لهذا الفصل.</p>';

  $("#readerView").innerHTML=`<div class="reader-shell"><div class="reader-bar"><button class="back" id="backDetail">← تفاصيل المانهوا</button><strong>${safe(currentManga?.title||"القراءة")} — الفصل ${safe(c.chapter_number)}</strong></div><main class="reader-pages">${content}</main></div>`;
  $("#backDetail").onclick=()=>{ $("#readerView").classList.add("hidden"); $("#detailView").classList.remove("hidden"); };
  if (isPdf) await renderPdfAsPages(urls[0], $("#pdfPages"));
}

$("#searchInput").addEventListener("input", renderManga);
$("#genreChips").addEventListener("click",e=>{const b=e.target.closest("[data-genre]");if(!b)return;activeGenre=b.dataset.genre;$("#genreChips").querySelectorAll(".chip").forEach(x=>x.classList.toggle("active",x===b));renderManga();});
document.addEventListener("click",e=>{const b=e.target.closest("[data-open]");if(b)openDetail(b.dataset.open);});
$("#homeBtn").onclick=e=>{e.preventDefault();backLibrary();};
$("#favoritesBtn").onclick=()=>{const f=getFavorites();const rows=allManga.filter(m=>f.includes(m.id));grid.classList.remove("hidden");$("#detailView").classList.add("hidden");$("#readerView").classList.add("hidden");grid.innerHTML=rows.length?rows.map(m=>`<article class="manga-card"><button class="cover-button" data-open="${m.id}">${m.cover_url?`<img src="${safe(m.cover_url)}" alt="">`:'<div class="cover-placeholder">漫画</div>'}</button><div class="card-info"><h3>${safe(m.title)}</h3><button class="text-button" data-open="${m.id}">عرض التفاصيل ←</button></div></article>`).join(""):'<div class="empty">لم تضيفي أعمالاً إلى المفضلة بعد.</div>';};
const dialog=$("#publisherDialog");
$("#publisherOpen").onclick=()=>dialog.showModal();
$("#loginForm").addEventListener("submit",async e=>{
  e.preventDefault(); const msg=$("#loginMessage"); showMessage(msg,"جارٍ التحقق...");
  const {data,error}=await supabase.auth.signInWithPassword({email:$("#email").value.trim(),password:$("#password").value});
  if(error){showMessage(msg,error.message,true);return;}
  // نتحقق عبر الدالة الآمنة is_publisher بدلاً من قراءة جدول الصلاحيات مباشرة.
  const {data:isPublisher,error:roleErr}=await supabase.rpc("is_publisher");
  if(roleErr || isPublisher !== true){
    await supabase.auth.signOut();showMessage(msg,"هذا الحساب ليس لديه صلاحية ناشر.",true);return;
  }
  $("#authPanel").classList.add("hidden");$("#adminPanel").classList.remove("hidden");await refreshAdmin();
});
$("#logoutBtn").onclick=async()=>{await supabase.auth.signOut();$("#adminPanel").classList.add("hidden");$("#authPanel").classList.remove("hidden");$("#loginForm").reset();};
document.querySelector(".admin-tabs").addEventListener("click",e=>{const b=e.target.closest("[data-tab]");if(!b)return;document.querySelectorAll(".admin-tabs .chip").forEach(x=>x.classList.toggle("active",x===b));["addManga","addChapter","manage"].forEach(t=>$("#tab-"+t).classList.toggle("hidden",t!==b.dataset.tab));if(b.dataset.tab==="manage")renderManage();});
async function refreshAdmin(){const {data}=await supabase.from("manga").select("id,title").order("created_at",{ascending:false});$("#chapterManga").innerHTML=(data||[]).map(m=>`<option value="${m.id}">${safe(m.title)}</option>`).join("");}
async function uploadFile(bucket,file,path){const {error}=await supabase.storage.from(bucket).upload(path,file,{upsert:false,contentType:file.type||undefined});if(error)throw error;const {data}=supabase.storage.from(bucket).getPublicUrl(path);return data.publicUrl;}
$("#mangaForm").onsubmit=async e=>{
 e.preventDefault();const msg=$("#mangaMessage");showMessage(msg,"جارٍ حفظ المانهوا...");
 try{
  const title=$("#mTitle").value.trim();let cover_url=null;const f=$("#mCover").files[0];
  if(f)cover_url=await uploadFile("manga-covers",f,`${crypto.randomUUID()}-${f.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`);
  const genres=$("#mGenres").value.split(/[,،]/).map(x=>x.trim()).filter(Boolean);
  const tags=$("#mTags").value.split(/[,،]/).map(x=>x.trim()).filter(Boolean);
  const {error}=await supabase.from("manga").insert({title,description:$("#mDescription").value.trim(),genres,tags,cover_url,is_featured:$("#mFeatured").checked,is_published:true});
  if(error)throw error;showMessage(msg,"تم نشر المانهوا بنجاح.");$("#mangaForm").reset();await loadManga();await refreshAdmin();
 }catch(err){showMessage(msg,err.message||"حدث خطأ أثناء الحفظ.",true);}
};
// Add files in separate picker sessions without losing earlier selections.
$("#chapterFiles").addEventListener("change", () => {
  for (const file of [...$("#chapterFiles").files]) {
    const duplicate = selectedChapterFiles.some(x => x.name === file.name && x.size === file.size && x.lastModified === file.lastModified);
    if (!duplicate) selectedChapterFiles.push(file);
  }
  $("#chapterFiles").value = "";
  renderSelectedChapterFiles();
});
function renderSelectedChapterFiles() {
  const list = $("#selectedChapterFiles");
  list.innerHTML = selectedChapterFiles.length
    ? `<strong>الملفات المختارة (${selectedChapterFiles.length}):</strong><ol>${selectedChapterFiles.map((f,i)=>`<li>${safe(f.name)} <button type="button" class="text-button" data-remove-file="${i}">إزالة</button></li>`).join("")}</ol>`
    : "لم تتم إضافة ملفات بعد.";
}
$("#selectedChapterFiles").addEventListener("click", e => {
  const b = e.target.closest("[data-remove-file]");
  if (!b) return;
  selectedChapterFiles.splice(Number(b.dataset.removeFile), 1);
  renderSelectedChapterFiles();
});
$("#chapterForm").onsubmit=async e=>{
 e.preventDefault();const msg=$("#chapterMessage");showMessage(msg,"جارٍ رفع الفصل...");
 try{
  const mangaId=$("#chapterManga").value;const files=[...selectedChapterFiles];if(!files.length)throw new Error("أضيفي ملفاً واحداً على الأقل.");
  if(files.some(f=>f.type==="application/pdf") && files.length>1) throw new Error("ملف PDF يكون وحده في الفصل، أو اختاري عدة صور.");
  if(files.length>1 && files.some(f=>!f.type.startsWith("image/"))) throw new Error("عند اختيار عدة ملفات، يجب أن تكون كلها صوراً.");
  const urls=[];
  for(let i=0;i<files.length;i++){const f=files[i];const path=`${mangaId}/${crypto.randomUUID()}-${f.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;urls.push(await uploadFile("manga-chapters",f,path));}
  const {error}=await supabase.from("chapters").insert({manga_id:mangaId,chapter_number:Number($("#chapterNumber").value),title:$("#chapterTitle").value.trim(),pdf_url:JSON.stringify(urls),is_published:true});
  if(error)throw error;showMessage(msg,"تم رفع الفصل ونشره.");$("#chapterForm").reset();selectedChapterFiles=[];renderSelectedChapterFiles();
 }catch(err){showMessage(msg,err.message||"تعذر رفع الفصل.",true);}
};
async function renderManage(){
 const box=$("#manageList");box.innerHTML="جارٍ التحميل...";
 const {data,error}=await supabase.from("manga").select("*").order("created_at",{ascending:false});
 if(error){box.textContent=error.message;return;}
 box.innerHTML=(data||[]).map(m=>`<div class="manage-row"><span>${safe(m.title)}</span><button class="danger" data-delete="${m.id}">حذف</button></div>`).join("")||"لا توجد أعمال.";
 box.querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{if(!confirm("هل تريدين حذف هذه المانهوا؟"))return;const {error}=await supabase.from("manga").delete().eq("id",b.dataset.delete);if(error)alert(error.message);else{await loadManga();renderManage();await refreshAdmin();}});
}
loadManga();
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
