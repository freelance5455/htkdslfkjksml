// إعدادات الاتصال العامة فقط. Publishable key مصمم للاستخدام في تطبيقات الواجهة.
// لا تضعي أبداً Secret key أو service_role هنا.
export const SUPABASE_URL = "https://exbxztysdzlftmgaiawe.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_fe3134tvTe0mT3LOtU3Ekw_8yPL5x9a";
