GARAGEM KIDS - PROJETO HTML PARA CONVERSOR HTML -> APK

Abra o ZIP no aplicativo HTML to APK Builder e importe a pasta/projeto.
Arquivo inicial: index.html
Aplicativo: Garagem Kids
Funcionamento: offline; dados salvos localmente no aparelho.
