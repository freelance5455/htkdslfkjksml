package com.kimax.aemobile;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.view.View;
import android.graphics.Color;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 4102;
    private WebView web;
    private File mediaDir;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10, 12, 20));
        getWindow().setNavigationBarColor(Color.rgb(10, 12, 20));
        mediaDir = new File(getFilesDir(), "media");
        if (!mediaDir.exists()) mediaDir.mkdirs();

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(10, 12, 20));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new EditorBridge(), "AEMobile");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class EditorBridge {
        @JavascriptInterface public void importMedia() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "image/*", "video/*", "audio/*"
                });
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, PICK_MEDIA);
            });
        }

        @JavascriptInterface public void saveProject(String json) {
            try {
                File file = new File(getFilesDir(), "ae_mobile_project.json");
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(json.getBytes("UTF-8"));
                }
                runOnUiThread(() -> web.evaluateJavascript(
                    "window.onNativeSave && window.onNativeSave(true)", null));
            } catch (Exception e) {
                runOnUiThread(() -> web.evaluateJavascript(
                    "window.onNativeSave && window.onNativeSave(false)", null));
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_MEDIA && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            new Thread(() -> {
                try {
                    String mime = getContentResolver().getType(uri);
                    String name = getDisplayName(uri);
                    String ext = "";
                    int dot = name.lastIndexOf('.');
                    if (dot >= 0) ext = name.substring(dot);
                    String safeName = UUID.randomUUID().toString() + ext;
                    File target = new File(mediaDir, safeName);
                    try (InputStream in = getContentResolver().openInputStream(uri);
                         FileOutputStream out = new FileOutputStream(target)) {
                        byte[] buffer = new byte[8192];
                        int n;
                        while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                    }
                    String fileUrl = "file://" + target.getAbsolutePath();
                    String js = "window.onMediaImported && window.onMediaImported(" +
                        JSONObjectQuote(name) + "," + JSONObjectQuote(mime == null ? "application/octet-stream" : mime) +
                        "," + JSONObjectQuote(fileUrl) + ")";
                    runOnUiThread(() -> web.evaluateJavascript(js, null));
                } catch (Exception e) {
                    runOnUiThread(() -> web.evaluateJavascript(
                        "window.onMediaImportError && window.onMediaImportError()", null));
                }
            }).start();
        }
    }

    private String getDisplayName(Uri uri) {
        String result = "media";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) result = c.getString(i);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private String JSONObjectQuote(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"")
            .replace("\n", "\\n").replace("\r", "\\r") + "\"";
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
