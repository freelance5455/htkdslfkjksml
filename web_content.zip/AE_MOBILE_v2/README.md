# AE MOBILE - Etapa 2

Projeto Android evoluído com importação de mídia real e persistência local.

## Novidades desta etapa
- Importar imagens, vídeos e áudios pelo seletor nativo de arquivos Android.
- Copiar os arquivos selecionados para o armazenamento privado do app.
- Exibir imagem e reproduzir vídeo no preview do editor.
- Criar automaticamente uma camada a partir da mídia importada.
- Biblioteca de mídia do projeto com nomes dos arquivos.
- Salvar o estado do projeto em `localStorage` e em `files/ae_mobile_project.json` no armazenamento privado do aplicativo.
- Guardar camadas, marcadores, preferências de FPS e dados dos keyframes.
- Efeitos de preview demonstrativos aplicados a imagem/vídeo: shake, blur/motion blur, glow/flash e vibrance. São efeitos de visualização, ainda não renderizados no arquivo final.

## Como abrir e gerar APK
1. Extraia o ZIP.
2. Abra a pasta `AE_MOBILE_v2` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se necessário, instale o Android SDK 35 e a plataforma Build Tools compatível.
5. Use **Build > Build APK(s)**.
6. O APK de debug será gerado em `app/build/outputs/apk/debug/`.

## Estado real do projeto
Esta etapa já faz importação nativa de mídia e preview de imagem/vídeo. O projeto ainda NÃO é um editor de vídeo completo: não há composição simultânea de várias faixas no preview, interpolação temporal de keyframes, chroma key por pixel, efeitos aplicados ao render final, mixagem de áudio ou exportação MP4. Os controles de exportação guardam as preferências, mas não geram o vídeo.

## Próxima etapa técnica
Implementar a linha do tempo com duração/início/fim por clipe, sincronização de várias faixas, interpolação de keyframes, pipeline de composição GPU e renderização MP4 via MediaCodec/MediaMuxer.
