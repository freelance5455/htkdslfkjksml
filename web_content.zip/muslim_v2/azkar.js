const status=document.getElementById('status'),list=document.getElementById('list'),search=document.getElementById('search');
const data=[
['أذكار الصباح','أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.'],
['أذكار الصباح','اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور.'],
['أذكار الصباح','رضيت بالله رباً، وبالإسلام ديناً، وبمحمد صلى الله عليه وسلم نبياً.'],
['أذكار الصباح','اللهم إني أصبحت أشهدك وأشهد حملة عرشك وملائكتك وجميع خلقك أنك أنت الله لا إله إلا أنت وحدك لا شريك لك.'],
['أذكار الصباح','حسبي الله لا إله إلا هو عليه توكلت وهو رب العرش العظيم.'],
['أذكار المساء','أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.'],
['أذكار المساء','اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير.'],
['أذكار المساء','أعوذ بكلمات الله التامات من شر ما خلق.'],
['أذكار المساء','رضيت بالله رباً، وبالإسلام ديناً، وبمحمد صلى الله عليه وسلم نبياً.'],
['بعد الصلاة','أستغفر الله، أستغفر الله، أستغفر الله.'],
['بعد الصلاة','اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام.'],
['بعد الصلاة','لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.'],
['بعد الصلاة','سبحان الله، والحمد لله، والله أكبر.'],
['قبل النوم','باسمك اللهم أموت وأحيا.'],
['قبل النوم','اللهم قني عذابك يوم تبعث عبادك.'],
['قبل النوم','آية الكرسي: الله لا إله إلا هو الحي القيوم، لا تأخذه سنة ولا نوم، له ما في السماوات وما في الأرض...'],
['الاستيقاظ','الحمد لله الذي أحيانا بعدما أماتنا وإليه النشور.'],
['دخول المنزل','بسم الله ولجنا، وبسم الله خرجنا، وعلى ربنا توكلنا.'],
['الخروج من المنزل','بسم الله، توكلت على الله، ولا حول ولا قوة إلا بالله.'],
['دخول المسجد','اللهم افتح لي أبواب رحمتك.'],
['الخروج من المسجد','اللهم إني أسألك من فضلك.'],
['دخول الخلاء','اللهم إني أعوذ بك من الخبث والخبائث.'],
['الخروج من الخلاء','غفرانك.'],
['عند الطعام','بسم الله.'],
['بعد الطعام','الحمد لله الذي أطعمني هذا ورزقنيه من غير حول مني ولا قوة.'],
['عند العطاس','الحمد لله.'],
['للعاطس','يرحمك الله.'],
['عند الغضب','أعوذ بالله من الشيطان الرجيم.'],
['دعاء عام','ربنا آتنا في الدنيا حسنة وفي الآخرة حسنة وقنا عذاب النار.'],
['دعاء عام','رب اغفر لي وتب علي إنك أنت التواب الرحيم.'],
['دعاء عام','اللهم إنك عفو تحب العفو فاعف عني.'],
['دعاء عام','اللهم أعني على ذكرك وشكرك وحسن عبادتك.'],
['دعاء عام','يا مقلب القلوب ثبت قلبي على دينك.'],
['دعاء عام','رب اشرح لي صدري ويسر لي أمري.'],
['دعاء عام','حسبي الله ونعم الوكيل.'],
['الصلاة على النبي','اللهم صل وسلم وبارك على نبينا محمد.']
].map(x=>({category:x[0],content:x[1],count:1}));
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
let all=data;
function render(){const q=(search.value||'').trim();const cats=[...new Set(all.map(x=>x.category))];let html='<div class="chips"><button class="chip active" data-c="">الكل</button>'+cats.map(c=>`<button class="chip" data-c="${esc(c)}">${esc(c)}</button>`).join('')+'</div>';const arr=all.filter(x=>!q||x.content.includes(q)||x.category.includes(q));html+=arr.map((x,i)=>`<article class="card"><div class="muted">${esc(x.category)}</div><div class="zekr">${esc(x.content)}</div><div class="row"><span>التكرار: ${x.count}</span><button class="small" onclick="speak(${i})">🔊 استماع</button></div></article>`).join('');list.innerHTML=html||'<div class="notice">لا توجد نتائج.</div>';document.querySelectorAll('.chip').forEach(b=>b.onclick=()=>{document.querySelectorAll('.chip').forEach(z=>z.classList.remove('active'));b.classList.add('active');const c=b.dataset.c;const old=search.value;search.value=c;render();search.value=old;});}
window.speak=i=>{
 const x=all[i];
 const old=document.getElementById('azkarAudio'); if(old){old.pause();old.remove();}
 const a=document.createElement('audio'); a.id='azkarAudio'; a.controls=true; a.preload='auto'; a.style.cssText='width:100%;margin:12px 0;';
 a.src='https://translate.google.com/translate_tts?ie=UTF-8&tl=ar&client=tw-ob&q='+encodeURIComponent(x.content);
 document.body.appendChild(a);
 a.play().catch(()=>{ alert('اضغط تشغيل ▶️ من مشغل الصوت الظاهر أسفل الشاشة.'); });
};
status.textContent='الأذكار جاهزة بدون إنترنت.';status.className='notice ok';render();search.addEventListener('input',render);
