# Bhagi Nayla + 99 CLUB — Android Demo Project

Virtual-coin/demo app packaged as a native Android WebView project.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync/download Android Gradle Plugin 8.7.3 and dependencies.
3. Select Build > Build APK(s).
4. The debug APK will be under `app/build/outputs/apk/debug/`.

This project is intentionally demo/virtual-coin only. It does not implement real-money deposits, withdrawals, UPI betting, or gambling payments.
