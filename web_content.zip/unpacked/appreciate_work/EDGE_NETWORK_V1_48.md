# APPRECIATE OS v1.48 — Edge Network + Mobile Node Coordination

## Release scope
This release upgrades the v1.47 mobile-node prototype into a coordinated, opt-in edge network for heterogeneous devices. It includes a PostgreSQL-backed coordinator in APPRECIATE CLOUD, an Android/Node.js edge agent, per-device credentials, heartbeat/resource reporting, an owner dashboard, node pause/revoke, a bounded task queue, and optional independent local-model inference on eligible nodes.

## Architecture
- **Control plane:** existing APPRECIATE CLOUD / `cloud-control` service.
- **Persistence:** `edge_nodes` and `edge_tasks` tables in the existing `appreciate_cloud` PostgreSQL database.
- **Device plane:** Node.js agent on Termux/Android or another Node.js host.
- **Communication:** devices initiate outbound HTTPS requests; no inbound phone ports or port forwarding.
- **Credentials:** one-time enrollment key creates a unique 256-bit node token; only its SHA-256 hash is stored server-side. The agent saves the returned token in a local JSON file with mode 0600 where supported.
- **Tasks:** allowlisted `health_report` and `ai_generate`; no arbitrary code, shell, file browsing or remote install.
- **AI:** `ai_generate` is executed by the node's own optional Ollama runtime; it is not a distributed single-model tensor-parallel system.

## Start on a phone without paid hosting
The package also includes `mobile-nodes/local-coordinator.js`, a small built-in-Node.js coordinator with a local JSON store and a local dashboard. It can run on the first Android phone over a trusted private hotspot/LAN without Docker or PostgreSQL. Start it with `bash mobile-nodes/run-coordinator.sh` after configuring the mobile-nodes `.env`; open `http://127.0.0.1:3211/`. For peer devices on the same private hotspot, use the coordinator phone's private IP and explicitly enable `APPRECIATE_ALLOW_INSECURE_LAN=true` on peers. This HTTP exception is for trusted LAN only, never public Wi-Fi or the internet. This phone-hosted mode is a bootstrap/test setup, not a hardened public cloud.

## Enable the PostgreSQL-backed coordinator
1. Run `cloud-control/scripts/generate-secrets.sh` to create `.env` with unique secrets. If `.env` already exists, add a unique `EDGE_ENROLLMENT_KEY` of at least 32 characters and keep it private.
2. Configure APP_BASE_URL / CORS and HTTPS reverse proxy as documented in `app/docs/DEPLOYMENT.md`.
3. Start the normal stack: `docker compose up -d --build`.
4. Check `https://YOUR_CLOUD_HOST/api/v1/edge/health`.
5. Open APPRECIATE CLOUD, connect using `CLOUD_ADMIN_KEY`, and select **APPRECIATE EDGE**.

## Enroll a phone
1. Install Termux from its official F-Droid or GitHub distribution.
2. Copy `mobile-nodes/` into Termux storage and run `bash termux-install.sh`.
3. Copy `.env.example` to `.env`, set coordinator HTTPS URL, enrollment key, device label, and opt in with `APPRECIATE_NODE_ENABLED=true`.
4. Run `set -a; . ./.env; set +a; node node-agent.js`.
5. The phone appears in the owner dashboard after successful enrollment/heartbeat. The enrollment secret is exchanged for a unique node token; keep `.appreciate-node.json` private.

## Optional local AI on a node
A device must independently run a compatible Ollama endpoint and set `APPRECIATE_NODE_OLLAMA_URL` before it advertises `local-ai`. Install a model suited to that device's RAM and thermal limits, then set `APPRECIATE_NODE_AI_MODEL`. The starter `qwen2.5:0.5b` is a small model choice, not a guarantee of acceptable speed or output quality on every phone. Do not advertise local AI on a device that cannot run it comfortably.

## Admin API
All management routes use `Authorization: Bearer $CLOUD_ADMIN_KEY`:
- `GET /api/v1/edge/nodes`
- `PATCH /api/v1/edge/nodes/:id` with status `active`, `paused` or `revoked`
- `DELETE /api/v1/edge/nodes/:id` to revoke
- `POST /api/v1/edge/tasks` with task type `health_report` or `ai_generate`
- `GET /api/v1/edge/tasks`

Enrollment route: `POST /api/v1/edge/enroll`, protected by the separate `EDGE_ENROLLMENT_KEY`.

## Honest limitations / next production gates
- A phone can be a useful opportunistic edge node, but Android background execution, battery, heat, storage, network availability and device policies constrain uptime.
- Phones do not pool their physical RAM into one shared memory space. Work is distributed as independent tasks. Model partitioning, federated learning and tensor-parallel inference across devices are not included.
- The coordinator needs a stable, secured host for continuous availability. The user's phone can be the first enrolled node and development host; it is not automatically a resilient public production server.
- Task queue currently uses a five-minute stale-task retry and basic bounded JSON results. Production needs richer retry/dead-letter policy, task leases, quotas, abuse controls, per-tenant permissions and monitoring.
- AI inference tasks are opt-in but the dashboard owner must ensure prompts contain no confidential customer, identity, payment or rights evidence.
- Public HTTPS routing, live server deployment, real Android installation, multi-device interoperability and end-to-end inference have not been verified in this build environment.
