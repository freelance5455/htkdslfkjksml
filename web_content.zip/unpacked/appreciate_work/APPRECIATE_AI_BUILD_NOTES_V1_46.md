# APPRECIATE AI build notes — v1.46.1

Added an optional self-hosted AI gateway and Ollama runtime under `appreciate-ai/`.

- No OpenAI API dependency or API key.
- Bearer-key protected `/v1/chat` endpoint; unauthenticated `/health` endpoint.
- Request size and message validation; upstream timeout; no conversation persistence.
- Ollama model storage uses a separate persistent Docker volume.
- AI containers are opt-in under the `ai` Compose profile; an initializer automatically downloads the configured model into persistent storage. The gateway host port binds to loopback.
- Health reports ready only when the configured model is actually installed. The request timeout covers the complete upstream response.
- Four automated gateway tests pass: readiness failure, bearer-key enforcement, request validation and unknown-route handling.

Still not delivered: persistent memory, APPRECIATE knowledge retrieval, app UI/API integration, multi-user access controls, public HTTPS routing, model licence review, load/security testing and production deployment. A running Docker host with adequate compute and disk is required to run inference. No live server activation is claimed by this source build.
