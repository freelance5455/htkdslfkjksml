# APPRECIATE OS — Ownership and Control Charter

**Project owner:** Bongani Magagula  
**Public/creative identity:** Appreciate Absalom  
**Project:** APPRECIATE OS / APPRECIATE CLOUD  
**Status:** Engineering principles and release gates; not a legal ownership certificate.

## 1. The ownership objective

APPRECIATE is intended to become an independently governed South African technology ecosystem. A hosting provider, app store, payment provider, AI vendor, or social platform may supply a service, but must not become the owner of APPRECIATE or the sole gatekeeper of its customers, source code, data, or business relationships.

## 2. Non-negotiable control principles

1. **Founder decision authority:** Product direction, branding, governance, budgets, strategic partnerships and release approval remain with the project owner. Technical contributors do not acquire ownership merely by contributing code.
2. **Source portability:** Maintain the source code, build instructions, database schema and migration history in owner-controlled repositories. Releases must be exportable without a proprietary hosting dashboard.
3. **Data portability:** Customer and business records must use documented schemas and supported export/backup procedures. No provider lock-in by design. Customer data remains subject to privacy law, consent and access controls; ownership of the platform does not mean ownership of customers' personal data.
4. **Infrastructure independence:** APPRECIATE CLOUD is the intended control plane. Third-party hosting may be used as temporary compute, but deployments must remain containerised and migratable to another compliant host or APPRECIATE-operated infrastructure.
5. **Secrets stay under owner control:** Production credentials, signing keys, database passwords, domain registrar access and payment-provider credentials are held in owner-controlled secret storage. They must never be committed to source control, embedded in APKs or exposed to customers.
6. **Open interfaces:** APIs, data formats, import/export paths and integration contracts should be documented. External providers are replaceable adapters, not the centre of the platform.
7. **Transparent economics:** Advertising, commerce, music-rights and creator programmes must show gross amounts, fees, deductions, revenue shares, outstanding balances and payment evidence. Estimates and unverified statements must be labelled.
8. **Consent and agency:** Creators, sellers, customers and edge-node participants choose whether to connect accounts, share data or contribute computing resources. Connections must be revocable; no forced device participation.
9. **Security before scale:** Tenant isolation, least privilege, audit trails, backups, restore tests, incident response and independent security review are release gates before public production use.
10. **No false claims:** A source feature is not a live integration. A deployment request is not a running service. A recorded payment is not a settled payment. A passing unit test is not proof of production readiness.

## 3. APPRECIATE ecosystem sequence

- **APPRECIATE CLOUD:** First priority. Owner-controlled source, builds, deployment, databases, monitoring, backups, secrets and customer hosting.
- **APPRECIATE OS:** Customer experience and business modules connected to APPRECIATE CLOUD through documented APIs.
- **APPRECIATE AI:** Optional, replaceable inference service. Local/open models are preferred where practical; external AI providers require explicit configuration and data safeguards.
- **APPRECIATE EDGE:** Voluntary enrolled devices with scoped credentials and limited allowlisted tasks. It is not a pooled-memory supercomputer and must not expose remote shell or unrestricted device access.
- **APPRECIATE BANK / ATM / corporate and tax systems:** Later phases only, subject to licensing, regulated-partner requirements, security certification and lawful authorisation. Software development alone does not make APPRECIATE a bank, payment institution or tax authority.

## 4. Hosting-provider rule

A provider such as Render can be used to test or temporarily host the customer web/API service. It is not APPRECIATE CLOUD and does not satisfy the long-term infrastructure-ownership objective. Before choosing any provider, record cost, data region, backup/export route, service limits, exit procedure and who controls the domain and credentials.

## 5. Production release gates

A public customer release is blocked until all applicable gates are evidenced:

- Owner controls the domain, source repository, production credentials and deployment approvals.
- HTTPS customer URL serves the APPRECIATE frontend and same-origin API.
- PostgreSQL is private, backed up, and a restore has been tested.
- Registration, login, logout, session expiry and account recovery are tested.
- Tenant and role access tests pass for customer, creator, seller, company and administrator roles.
- Uploads use private storage, malware controls and retention rules.
- Payment and royalty states are provider-verified or clearly labelled manual/unverified.
- Privacy notice, terms, consent records, data export/deletion workflows and incident contact are published.
- Android APK is built from the approved hosted frontend and tested on a separate device.

## 6. Current technical truth

The v1.48 source package contains an APPRECIATE application API/frontend, a separate APPRECIATE CLOUD control-plane service, PostgreSQL-based persistence, Docker deployment definitions, and an optional AI gateway. The source can be self-hosted on suitable infrastructure. The control plane is an early owner-operated release: managed public HTTPS routing, per-project database provisioning, tenant isolation, secrets vault, production backups/restore automation and independent security testing remain incomplete. A phone-hosted Termux service is local development/edge infrastructure, not a reliable public production host.

This charter records engineering intent. It does not replace company registration, shareholder agreements, IP assignments, trademarks, contracts, POPIA compliance work or regulatory approvals.
