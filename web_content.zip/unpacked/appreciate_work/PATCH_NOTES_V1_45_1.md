# APPRECIATE v1.45.1 — deployment connection repair

## Change
The APPRECIATE application API now has a separate private cloud-control URL setting. In the Docker Compose deployment, API-to-cloud health checks use `http://cloud-control:3100` on the private Compose network, while `APPRECIATE_CLOUD_URL` remains the public HTTPS address returned to the owner browser.

## Why
The previous configuration used the public cloud URL for both server-to-server checks and browser navigation. That can fail when public DNS, TLS routing, or reverse-proxy hairpin access is not configured, even when both containers share a working private network.

## Verification boundary
Source tests and syntax checks can be run in this workspace. Live PostgreSQL connectivity, Docker image builds, container startup, public DNS/HTTPS and Android APK installation still require a real deployment environment and have not been claimed as completed.
