# APPRECIATE CLOUD v1.3 — native installation

## Included services

- **APPRECIATE CODE:** private bare Git repositories stored on the persistent cloud data volume. The portal creates repositories and accepts ZIP source uploads, committing uploaded files into the repository's `main` branch.
- **APPRECIATE BUILD:** clones a local APPRECIATE CODE repository and builds a Docker image from its Dockerfile.
- **APPRECIATE DEPLOY:** starts and restarts built containers through Docker Engine.
- **APPRECIATE DATABASE:** PostgreSQL stores APPRECIATE application and cloud control-plane records.
- **APPRECIATE CLOUD:** owner portal, API, status checks and audit log.

No GitLab, Render, Forgejo or Coolify account, API, token or service is used.

## Requirements

Use a Linux server you control with Docker Engine and the Compose plugin. A small test environment should have at least 2 CPU cores, 4 GB RAM and enough disk for source repositories, images, application data and database backups; production capacity depends on workloads. A public service also needs a reachable server, DNS and HTTPS reverse proxy. The source archive does not provision a server or internet connectivity.

## Install

1. Copy `.env.example` to `.env` and generate unique strong values for `POSTGRES_PASSWORD`, `APP_SECRET`, `VOUCHER_CODE_PEPPER` and `CLOUD_ADMIN_KEY`.
2. Set `APP_BASE_URL`, `CORS_ORIGIN` and `APPRECIATE_CLOUD_URL` to the real HTTPS addresses. Keep database ports private. The Compose file binds both the app and cloud-control host ports to `127.0.0.1` by default; keep this setting until a reviewed HTTPS reverse proxy is configured. Do not change the cloud-control binding to `0.0.0.0`.
3. Start the stack with `docker compose up -d --build`.
4. Check `docker compose ps` and `docker compose logs --tail=100 cloud-control database app`.
5. From the server itself, open the cloud portal at `http://127.0.0.1:3100` (or use an SSH tunnel from your device). Do not publish port 3100. The public app should be routed through an HTTPS reverse proxy; the owner-only cloud portal should remain restricted to an administrator VPN or SSH tunnel.
6. Create an APPRECIATE CODE project. Upload a ZIP containing application source and a Dockerfile. Run BUILD and copy the returned image tag into DEPLOY.

The database init script creates `appreciate_cloud` only when the PostgreSQL data volume is first initialised. If reusing a volume from an earlier version, check that database exists before starting cloud-control; do not delete the existing database volume to force initialisation.

## Native API workflow

- `POST /api/v1/repositories` with `{ "name": "my-project" }` creates a private local bare Git repository.
- `POST /api/v1/repositories/:name/source` with `Content-Type: application/zip` uploads and commits a ZIP source archive.
- `POST /api/v1/builds` with `{ "repository": "my-project", "branch": "main" }` builds the project's Dockerfile and returns an image tag.
- `POST /api/v1/deployments` with `{ "name": "my-project", "image": "appreciate/my-project:<build-id>", "container_port": 3000, "host_port": 0 }` starts the application container. Host port `0` asks Docker to allocate a port.
- `GET /api/v1/applications`, `/deployments`, `/repositories`, `/databases` list current resources.

All `/api/v1` routes require the owner bearer key. The ZIP upload endpoint accepts up to 25 MB and rejects path traversal entries.

## Security — read before exposure

The cloud-control container mounts the Docker socket. Docker socket access is effectively host-root access. Anyone who steals the owner API key may control workloads and potentially the host. Do not expose this owner-only release to customers or the public internet without additional security engineering. Use HTTPS, firewall restrictions, strong unique secrets and backups. Compose now binds the app and cloud-control ports to loopback by default. This is intentional: a reverse proxy on the same host can reach them, while direct public access is blocked. Keep cloud-control private even when the app is public. Do not put the owner key in public frontend code.

## Not yet complete

This is an early owner-operated implementation, not a mature public hosting service. It does not yet provide Git-over-SSH/HTTP push and clone, customer accounts, multi-tenant isolation, per-project database provisioning, resource quotas, build queue/workers, build cancellation, deployment rollback, automatic domain/TLS, streaming logs, backup/restore automation, malware scanning, image signing, or independent penetration testing. It builds Dockerfile-based projects only. Do not treat a successful source test as proof of a live cloud deployment.
