# APPRECIATE application integration

The in-app Cloud Services section checks the independent APPRECIATE CLOUD control plane using `APPRECIATE_CLOUD_URL` and `APPRECIATE_CLOUD_API_KEY`. It opens the APPRECIATE CLOUD owner portal.

APPRECIATE CLOUD v1.3 runs its own repository, build and container deployment workflows. Existing APPRECIATE app project/deployment request records remain in the APPRECIATE application database and are not automatically deployed. Use the CLOUD portal to create a repository, upload source, build and deploy.
