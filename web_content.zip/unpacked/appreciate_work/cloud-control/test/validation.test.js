'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { safeEqual, safeProviderBaseUrl, validRepositoryName, validBranch, validResourceUuid, validDatabaseName } = require('../lib/validation');
test('API key comparison accepts equal values', () => assert.equal(safeEqual('secret-key', 'secret-key'), true));
test('API key comparison rejects unequal values and lengths', () => { assert.equal(safeEqual('secret-key', 'secret-key2'), false); assert.equal(safeEqual('a', 'longer'), false); });
test('repository names accept safe names', () => { assert.equal(validRepositoryName('appreciate-main'), true); assert.equal(validRepositoryName('v1.2_test'), true); });
test('repository names reject path and injection characters', () => { assert.equal(validRepositoryName('../secret'), false); assert.equal(validRepositoryName('repo/name'), false); assert.equal(validRepositoryName(''), false); });
test('branch names accept ordinary branches', () => { assert.equal(validBranch('main'), true); assert.equal(validBranch('feature/cloud-api'), true); });
test('branch names reject traversal and malformed paths', () => { for (const value of ['../main', 'main..x', '/main', 'main/', 'main.lock', 'a'.repeat(161)]) assert.equal(validBranch(value), false, value); });
test('resource UUID validation rejects empty and malformed values', () => { assert.equal(validResourceUuid('d7fbdd97-6cb8-4e74-8a18-19c222c16ce7'), true); assert.equal(validResourceUuid('x'), false); });
test('database names accept bounded names and reject unsafe input', () => { assert.equal(validDatabaseName('appreciate_prod'), true); assert.equal(validDatabaseName('x; DROP TABLE users'), false); assert.equal(validDatabaseName('a'), false); });

test('provider API base URLs require HTTPS except for localhost or explicitly allowed internal services', () => { assert.equal(safeProviderBaseUrl('https://git.example.com/path'),'https://git.example.com'); assert.equal(safeProviderBaseUrl('http://localhost:3000'),'http://localhost:3000'); assert.equal(safeProviderBaseUrl('http://forgejo:3000'),null); assert.equal(safeProviderBaseUrl('http://forgejo:3000',true),'http://forgejo:3000'); assert.equal(safeProviderBaseUrl('http://example.com'),null); assert.equal(safeProviderBaseUrl('https://user:pass@git.example.com'),null); assert.equal(safeProviderBaseUrl('https://git.example.com?token=x'),null); });
