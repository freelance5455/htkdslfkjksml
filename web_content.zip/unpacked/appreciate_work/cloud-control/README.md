# APPRECIATE CLOUD native control plane

APPRECIATE CLOUD provides native APPRECIATE CODE (Git repository storage), APPRECIATE BUILD (Dockerfile build runner), and APPRECIATE DEPLOY (container runner). It uses PostgreSQL for metadata and Docker Engine as the low-level container runtime. No external Git hosting or deployment control plane is required.

See `docs/INSTALLATION.md`. This release is owner-operated and not yet a public multi-tenant hosting product.
