'use strict';
// APPRECIATE Edge Coordinator: outbound-only enrolled nodes; no remote shell or arbitrary code.
const crypto = require('node:crypto');
const express = require('express');
const { Pool } = require('pg');
const { safeEqual } = require('./lib/validation');
const router = express.Router();
const route = handler => (req,res,next) => Promise.resolve(handler(req,res,next)).catch(next);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 5 });
const adminKey = process.env.CLOUD_ADMIN_KEY || '';
const enrollKey = process.env.EDGE_ENROLLMENT_KEY || '';
if (enrollKey.length < 32 || /replace|change_me/i.test(enrollKey)) throw new Error('EDGE_ENROLLMENT_KEY must be a unique secret of at least 32 characters.');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const tokenFrom = req => (req.get('authorization') || '').replace(/^Bearer\s+/i, '');
function admin(req,res,next){ if(!safeEqual(tokenFrom(req),adminKey)) return res.status(401).json({error:'unauthorized'}); next(); }
async function nodeAuth(req,res,next){
  const id = String(req.get('x-appreciate-node-id') || '');
  const token = tokenFrom(req);
  if(!id || !token) return res.status(401).json({error:'node_auth_required'});
  const r = await pool.query('SELECT id,status FROM edge_nodes WHERE id=$1 AND token_hash=$2',[id,hash(token)]);
  if(!r.rowCount || r.rows[0].status !== 'active') return res.status(401).json({error:'node_not_authorized'});
  req.edgeNode = r.rows[0]; next();
}
router.post('/enroll', route(async(req,res)=>{
  if(!safeEqual(tokenFrom(req),enrollKey)) return res.status(401).json({error:'invalid_enrollment_key'});
  const label = String(req.body?.label || 'APPRECIATE device').trim().slice(0,80);
  const platform = String(req.body?.platform || 'unknown').slice(0,40);
  const arch = String(req.body?.architecture || 'unknown').slice(0,40);
  const deviceClass = ['phone','tablet','laptop','workstation','server'].includes(req.body?.device_class) ? req.body.device_class : 'phone';
  const capabilities = Array.isArray(req.body?.capabilities) ? req.body.capabilities.filter(x=>['health-report','resource-report','local-ai'].includes(x)).slice(0,8) : ['health-report','resource-report'];
  const id = crypto.randomUUID(); const token = crypto.randomBytes(32).toString('base64url');
  await pool.query(`INSERT INTO edge_nodes(id,label,device_class,platform,architecture,capabilities,token_hash,status,last_seen_at)
    VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,'active',NOW())`,[id,label,deviceClass,platform,arch,JSON.stringify(capabilities),hash(token)]);
  await pool.query("INSERT INTO cloud_audit_events(event_type,provider,resource_name,resource_id,detail) VALUES('edge.node.enrolled','appreciate', $1,$2,$3::jsonb)",[label,id,JSON.stringify({device_class:deviceClass,platform,architecture:arch})]);
  res.status(201).json({node_id:id,node_token:token,warning:'Save this token securely. It is shown only once.'});
}));
router.post('/heartbeat',route(nodeAuth),route(async(req,res)=>{
  const cpu = Math.max(0,Math.min(100,Number(req.body?.cpu_percent)||0));
  const memory = Math.max(0,Number(req.body?.free_memory_bytes)||0);
  const battery = req.body?.battery_percent == null ? null : Math.max(0,Math.min(100,Number(req.body.battery_percent)||0));
  const charging = typeof req.body?.charging === 'boolean' ? req.body.charging : null;
  await pool.query(`UPDATE edge_nodes SET last_seen_at=NOW(),cpu_percent=$2,free_memory_bytes=$3,battery_percent=$4,charging=$5,metadata=$6::jsonb,capabilities=$7::jsonb WHERE id=$1`,[req.edgeNode.id,cpu,memory,battery,charging,JSON.stringify({app_version:String(req.body?.agent_version||'1').slice(0,20)}),JSON.stringify(Array.isArray(req.body?.capabilities)?req.body.capabilities.filter(x=>['health-report','resource-report','local-ai'].includes(x)).slice(0,8):['health-report','resource-report'])]);
  res.json({ok:true,server_time:new Date().toISOString(),poll_after_seconds:30});
}));
router.get('/nodes',admin,route(async(_req,res)=>{const r=await pool.query(`SELECT id,label,device_class,platform,architecture,capabilities,status,last_seen_at,cpu_percent,free_memory_bytes,battery_percent,charging,created_at FROM edge_nodes ORDER BY created_at DESC`);res.json({nodes:r.rows});}));
router.patch('/nodes/:id',admin,route(async(req,res)=>{const status=req.body?.status;if(!['active','paused','revoked'].includes(status))return res.status(400).json({error:'status_must_be_active_paused_or_revoked'});const r=await pool.query('UPDATE edge_nodes SET status=$2 WHERE id=$1 RETURNING id,status',[req.params.id,status]);if(!r.rowCount)return res.status(404).json({error:'node_not_found'});res.json({node:r.rows[0]});}));
router.delete('/nodes/:id',admin,route(async(req,res)=>{const r=await pool.query("UPDATE edge_nodes SET status='revoked' WHERE id=$1 RETURNING id",[req.params.id]);if(!r.rowCount)return res.status(404).json({error:'node_not_found'});res.json({ok:true,revoked:true});}));
router.post('/tasks',admin,route(async(req,res)=>{const allowed=new Set(['health_report','ai_generate']);const type=String(req.body?.type||'');const payload=req.body?.payload||{};if(!allowed.has(type))return res.status(400).json({error:'unsupported_task_type'});if(type==='ai_generate'&&(typeof payload.prompt!=='string'||!payload.prompt.trim()||payload.prompt.length>6000))return res.status(400).json({error:'prompt_required_max_6000_chars'});const id=crypto.randomUUID();const r=await pool.query(`INSERT INTO edge_tasks(id,task_type,payload,status,created_at) VALUES($1,$2,$3::jsonb,'queued',NOW()) RETURNING id,task_type,status,created_at`,[id,type,JSON.stringify(type==='ai_generate'?{prompt:payload.prompt,model:String(payload.model||'').slice(0,80)}:{})]);res.status(201).json({task:r.rows[0]});}));
router.get('/tasks/claim',route(nodeAuth),route(async(req,res)=>{const client=await pool.connect();try{await client.query('BEGIN');await client.query("UPDATE edge_tasks SET status='queued',node_id=NULL,started_at=NULL WHERE status='running' AND started_at < NOW() - INTERVAL '5 minutes'");const r=await client.query(`SELECT t.id,t.task_type,t.payload FROM edge_tasks t WHERE t.status='queued' AND (t.target_node_id IS NULL OR t.target_node_id=$1) AND (t.task_type='health_report' OR (t.task_type='ai_generate' AND EXISTS(SELECT 1 FROM edge_nodes n WHERE n.id=$1 AND n.capabilities @> '["local-ai"]'::jsonb))) ORDER BY t.created_at FOR UPDATE SKIP LOCKED LIMIT 1`,[req.edgeNode.id]);if(!r.rowCount){await client.query('COMMIT');return res.json({task:null,poll_after_seconds:30});}const t=r.rows[0];await client.query("UPDATE edge_tasks SET status='running',node_id=$2,started_at=NOW() WHERE id=$1",[t.id,req.edgeNode.id]);await client.query('COMMIT');res.json({task:{id:t.id,type:t.task_type,payload:t.payload}});}catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}}));
router.post('/tasks/:id/result',route(nodeAuth),route(async(req,res)=>{const result=JSON.stringify(req.body?.result??{});if(Buffer.byteLength(result)>20000)return res.status(413).json({error:'result_too_large'});const r=await pool.query(`UPDATE edge_tasks SET status='completed',result=$3::jsonb,completed_at=NOW() WHERE id=$1 AND node_id=$2 AND status='running' RETURNING id,status`,[req.params.id,req.edgeNode.id,result]);if(!r.rowCount)return res.status(404).json({error:'task_not_found_or_not_owned'});res.json({task:r.rows[0]});}));
router.get('/tasks',admin,route(async(_req,res)=>{const r=await pool.query('SELECT id,task_type,status,node_id,created_at,started_at,completed_at,result FROM edge_tasks ORDER BY created_at DESC LIMIT 100');res.json({tasks:r.rows});}));
router.get('/health',async(_req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true,service:'APPRECIATE Edge Coordinator',database:'connected',task_types:['health_report','ai_generate'],remote_shell:false});}catch{res.status(503).json({ok:false,database:'disconnected'});}});
async function init(){await pool.query(`CREATE TABLE IF NOT EXISTS edge_nodes(id UUID PRIMARY KEY,label TEXT NOT NULL,device_class TEXT NOT NULL,platform TEXT NOT NULL,architecture TEXT NOT NULL,capabilities JSONB NOT NULL DEFAULT '[]'::jsonb,token_hash TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',last_seen_at TIMESTAMPTZ,cpu_percent REAL NOT NULL DEFAULT 0,free_memory_bytes BIGINT NOT NULL DEFAULT 0,battery_percent REAL,charging BOOLEAN,metadata JSONB NOT NULL DEFAULT '{}'::jsonb,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()); CREATE TABLE IF NOT EXISTS edge_tasks(id UUID PRIMARY KEY,task_type TEXT NOT NULL,payload JSONB NOT NULL DEFAULT '{}'::jsonb,status TEXT NOT NULL DEFAULT 'queued',target_node_id UUID REFERENCES edge_nodes(id),node_id UUID REFERENCES edge_nodes(id),result JSONB,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),started_at TIMESTAMPTZ,completed_at TIMESTAMPTZ); CREATE INDEX IF NOT EXISTS edge_tasks_queue_idx ON edge_tasks(status,created_at);`);}
module.exports={router,init};
