# APPRECIATE Corporate Acquisition & Consumer Growth Strategy
**Bongani Magagula / Appreciate Absalom**  
**Prepared:** 13 November 2026  
**For:** APPRECIATE platform and Appreciate Absalom Artist Development & Management

## 1. Executive direction

APPRECIATE should operate as a two-sided growth platform:

- **Consumers** discover creators, music, products, services and local offers; follow creators; buy safely; share recommendations; and return for new releases and deals.
- **Companies** discover creators, publish campaign briefs, invite talent, sponsor projects, buy content and services, and receive measurable campaign reports.
- **Creators and sellers** build public portfolios, apply for opportunities, sell products and music, and show verified performance evidence.
- **Appreciate Absalom Artist Development & Management** develops talent, qualifies opportunities, coordinates proposals and agreements, manages delivery and reporting, and earns transparent contracted service fees.

The first commercial objective is not to sell a vague “new social network”. It is to sell a **measurable creator-content and community activation service**, using APPRECIATE as the discovery, workflow and reporting platform. Start with one artist and a small, clearly scoped pilot. Expand the roster only when there are signed creator agreements and enough delivery capacity.

## 2. What we sell to companies

### Core offer
1. **Creator-led content:** short-form video, photography, product demonstrations, interviews and behind-the-scenes content.
2. **Local community activation:** Mamelodi/Tshwane stories, small showcases, product demonstrations and local merchant promotions.
3. **Artist development partnership:** support for recording, production, mentorship, content, release campaigns and performance opportunities.
4. **Creator-to-commerce campaigns:** trackable links, QR codes, promo codes, product pages and conversion reporting where the merchant/provider supports tracking.
5. **Campaign administration:** creator selection, briefs, contracts, approvals, delivery evidence, invoices and post-campaign reports.

### What we must never promise without evidence
- Guaranteed views, sales, followers, reach or press coverage.
- A large creator roster when only contracted creators are available.
- Automatic publishing to every social network.
- Live royalty, platform analytics or payment data before the relevant provider has approved and connected the integration.
- A sponsorship result simply because a company has been contacted.

If historical audience data is small or unavailable, lead with **content production quality, local relevance, reliable delivery and measurable links/codes**, not inflated reach claims.

## 3. Corporate acquisition: target accounts and routes

Research checked on 13 November 2026. A listed programme or contact route is not a promise of funding or acceptance. Re-check eligibility and application windows before sending.

| Priority | Target / route | Evidence-based fit | Recommended approach |
|---|---|---|---|
| A1 | **Absa — commercial sponsorship**. `sponsorships@absa.co.za`; community sponsorship: `citizenship@absa.co.za`. [Criteria](https://www.absa.co.za/about-us/sponsorship/sponsorship-criteria/) | Absa lists arts and culture, including popular culture and entertainment, among its sponsorship areas. It describes sponsorship as acquiring brand-association rights that deliver measurable benefits. Individual sponsorship is by exception; events starting within two months are excluded. | Pitch a structured **Mamelodi Creative Enterprise & Digital Culture Pilot**, not a personal donation or an individual-artist request. Show brand rights, target community, schedule, safeguarding, budget and measurable deliverables. Ask whether an early-stage independent project needs an eligible implementation partner. |
| A2 | **Standard Bank — Arts & Culture sponsorship**. `Sponsorships@standardbank.co.za`; +27 11 636 1061. [Sponsorship portfolio](https://sponsorships.standardbank.com/sbgs/sponsorship) · [Contact](https://sponsorships.standardbank.com/sbgs/sponsorship/contact-us) | Standard Bank publicly documents long-running investment in arts and culture, including Joy of Jazz, Young Artist Awards, the National Arts Festival and Art Lab. | Propose an emerging Gauteng artist-development and digital-documentation pathway, with a modest pilot or partnership component. Do not imply that the bank has an open grant window unless confirmed. |
| A3 | **MTN / MTN One TV — story and content development**. [MTN One TV announcement](https://www.mtn.com/mtn-one-tv-launches-search-for-bold-african-stories/) | On 16 September 2026 MTN One TV announced a search for authentic, commercially compelling African stories, with pitching opportunities connected to Durban FilmMart and MIP Africa. | Develop a concise story treatment such as **From Mamelodi to Market**: artist journeys, local enterprise and culture. Monitor official pitch opportunities; the announcement is not proof of a permanently open application or guaranteed commission. |
| B1 | **Unilever U-Creators — creator programme**. [Apply / programme](https://u-creators.community.humanz.com/) | The official programme invites South African creators aged 18+ and states there is no minimum follower count; accepted creators can access campaigns, product experiences, rewards and learning. | Help eligible creators apply individually with a complete profile and sample content. This is a creator opportunity channel, not a confirmed corporate sponsorship for APPRECIATE. |
| B2 | **L’Oréalistar — beauty creator community**. [Apply](https://lorealistar.community.humanz.com/) | South African, 18+ beauty-focused creator community; selection is reviewed by a human and opportunities are offered through the community. | Use only for roster members whose actual content fits beauty, hair or skincare. Do not send a hip-hop-only profile as if it were a beauty creator. |
| B2 | **Mr Mattress — UGC creator programme**. `headoffice@mrmattress.co.za`. [Programme page](https://www.mrmattress.co.za/pages/partner-with-us-ugc-creators) | Its programme page describes creator content, unique discount codes, tracked sales and commission, and says there is no minimum follower count. Confirm that the programme and terms remain active before applying. | Offer one honest product-content pilot or apply as an individual creator. Agree commission, tracking, content usage, return rules and payment dates in writing. |
| B2 | **TRENZY Spaces — creator / artist collaborations**. `collabs@trenzyspaces.co.za`. [Collab programme](https://trenzyspaces.co.za/pages/trenzy-creator-partnerships) | The Johannesburg-rooted interiors brand describes affiliate links, product gifting, paid collaborations, co-created work and possible ambassador relationships. | Approach with a visual artist, photographer, stylist or lifestyle creator whose work genuinely fits interiors/design. Do not force-fit a music-only act. |
| B3 | **Sun International — supplier route**. [Supplier registration](https://corporate.suninternational.com/procurement) | Sun International invites prospective suppliers to register on its B1SA-administered supplier database and explains its procurement process. | Treat this as **procurement**, not sponsorship. Once the contracting entity and supplier documents are ready, register for relevant content, event, production or marketing services. |
| B3 | **Capitec — supplier registration**. [Supplier page](https://www.capitecbank.co.za/procurement/) | Capitec provides a potential-supplier registration form. This is a supplier route, not a published sponsorship offer. | Use only if the business can describe a real service that fits the procurement categories. Do not send a generic artist-funding request to procurement. |
| B3 | **Mamelodi / Tshwane SMEs and venues** | Local merchants can test content, product promotions and community discovery faster than a national sponsorship process. | Build the first case study with one willing local retailer, salon, fashion seller, food business, venue or service provider. Ask for a small paid pilot or clearly valued in-kind support. |

### Creator networks and market references

- **DALI** ([creator network](https://www.dali.africa/)) and **iAgency** ([creator network](https://iagency.co.za/creators/)) are potential channels for suitable creators to apply for external briefs. They are not corporate sponsors.
- **Plug Central** ([platform](https://www.plugcentral.co.za/)) is a relevant South African creator-commerce benchmark: creator storefronts, product links and tracked sales. Treat it as a competitor/reference, not a sponsor prospect. APPRECIATE should differentiate through artist development, music/rights records, local business campaigns and end-to-end corporate workflow.
- **Retail Assistants** ([creator network](https://retailassistants.co.za/creators)) is another possible route for creators interested in live commerce and UGC. Check each opportunity's terms before accepting outside work.

## 4. Sponsorship and partnership packages

These are **proposed pilot planning bands**, not published industry rates or guaranteed market prices. Confirm production costs, creator fees, transport, data, editing, rights, taxes and the company's budget before issuing a quote.

### Package 1 — Local UGC pilot
**Planning range: R2,500–R4,500**

- One contracted creator.
- One 30–45 second vertical video plus two short cut-downs or story frames.
- One product/service link or QR code where tracking is supported.
- One round of factual corrections.
- A short delivery report with links and actual platform metrics supplied by the creator.
- Paid-media usage, whitelisting, exclusivity and extended licensing priced separately.

Best first offer for a local SME or a brand testing creator content. Do not promise sales or reach.

### Package 2 — Creator conversion campaign
**Planning range: R7,500–R15,000**

- Two or three suitably matched, contracted creators (only once the roster exists).
- Three to five vertical videos and agreed story/post assets.
- APPRECIATE campaign page or announcement, product links and unique codes/QRs.
- Agreed publication window and a simple conversion/reporting review.
- Brand approval, disclosure and content-usage terms.

### Package 3 — Community activation / showcase
**Planning range: R15,000–R35,000**

- Small Mamelodi/Tshwane activation or showcase.
- Three to five contracted creators/artists, venue and production partners.
- Event coverage, short-form content, QR sign-up or offer, and sponsor acknowledgement.
- Attendance and delivery evidence; no inflated attendance or audience claims.
- Venue, security, equipment and travel costs explicitly budgeted.

### Package 4 — Three-month artist-development partner
**Planning range: R30,000–R75,000 cash or valued in-kind support**

- A defined development plan for a small, contracted group of emerging artists.
- Mentorship, content production, release support, equipment/data access or performance opportunities.
- Milestones, safeguarding, rights ownership and quarterly reporting.
- Only pitch after an implementation partner, creator roster, budget and delivery capacity are confirmed.

### In-kind partner option
For an early-stage project, ask for specific support: camera/audio equipment, studio hours, data, transport, venue access, editing time or product samples. Record the fair value, what the partner receives, who owns the equipment, the duration and the return/maintenance terms. In-kind support is not cash income.

## 5. How creators attract companies

Each creator should have a public, shareable **creator media kit** containing:

- Name/creator brand, location, languages, content categories and a short biography.
- Three to five strong work samples and links to published content.
- Audience size, engagement and demographics only when sourced, dated and authorised.
- Production skills, available formats, turnaround time and collaboration preferences.
- Previous campaigns with clear permission to show the work.
- Contact / enquiry link and a downloadable one-page profile.
- Rate card or “request a quote” option; never show a fake rate or fake audience figure.

Creators should pitch a brand fit, not just their follower count. A small local creator can offer authentic product demonstration, local language/context, UGC production or a trusted niche audience even before they have a large following.

### Company acquisition routine

1. Identify 10 companies whose customers, product and values fit the creator.
2. Research the brand's current campaigns, target customers and existing creator work.
3. Prepare a one-page idea: problem, audience, creative concept, deliverables, budget and measurement.
4. Send a tailored message to the correct marketing, sponsorship, partnerships or procurement route.
5. Follow up once after five business days; once more after another seven business days, then close the lead politely.
6. Record every interaction in APPRECIATE's corporate pipeline.
7. Never send mass spam, scrape personal contact details or claim a relationship that does not exist.

## 6. How APPRECIATE attracts consumers across income groups

The 2026 Online Retail in South Africa research reports that 79.1% of adults were online, while 34.2% shopped online in 2025. It identifies delivery costs, payment security, data costs and trust as barriers; smartphones are a major shopping device. This supports a mobile-first, low-friction strategy rather than assuming every user has unlimited data or a premium phone. Source: [World Wide Worx — Online Retail in South Africa 2026](https://www.worldwideworx.com/onlineretailsa2026-retails-next-big-market/).

### Consumer growth loops

**Discover → follow → share → buy → return**
- Keep basic discovery and public creator pages free.
- Use compressed previews, fast-loading pages and text-first product details.
- Let users browse before requiring an account; ask for registration when they follow, save or buy.
- Make product and creator pages easy to share on WhatsApp and other social channels.
- Use clear ZAR pricing, delivery costs, returns and seller identity before checkout.
- Offer free discovery, affordable entry-level products, bundles and occasional merchant-funded offers.
- Provide collection/local fulfilment options where the seller can genuinely support them.
- Use reviews only after a real transaction or verified service.
- Make receipts, delivery tracking, proof of delivery and dispute handling visible.

**Referral loop**
- Give each creator, seller and customer a unique referral link or QR code.
- Attribute a referral only after a verified registration plus a defined qualifying action (for example, a settled first purchase).
- Show the reward terms, expiry and payout status clearly.
- Prevent self-referrals, duplicate accounts, fake orders and reward farming.
- Do not pay referral rewards from uncollected or refunded transactions.

**Community loop**
- Spotlight local creators and businesses.
- Run weekly local themes: new music, fashion finds, food, skills, events and small-business stories.
- Let businesses share their APPRECIATE page QR code at a physical shop or event.
- Build creator-led guides and recommendations, with paid relationships disclosed.

## 7. How announcements and corporate campaigns should work in APPRECIATE

### Corporate workflow
Company registration → business verification → campaign brief and budget → creator discovery → invitation/application → proposal → negotiation → agreement and signatures → invoice/payment status → content approval → delivery evidence → campaign report → renewal.

### Creator workflow
Profile → media kit → discover opportunities → apply or receive invitation → accept brief → sign terms → create content → submit proof → publish/share → report results → receive verified payment status.

### Announcement workflow
Draft → internal review → approved → scheduled → published inside APPRECIATE → manually shared externally until an official API integration is approved → capture publication links and evidence → report.

### Current source-package reality
The audited APPRECIATE source already includes corporate enquiries, proposals, agreements, in-app signatures, deliverables, reports and sponsorship/service invoices, plus campaign drafts and in-app announcements. The next growth-focused software increment should add:

1. Public creator media kits and shareable storefront/profile pages.
2. A company campaign/opportunity board with creator filters and invitations.
3. Unique referral links, QR codes and a fraud-resistant reward ledger.
4. Consumer coupons, loyalty and local merchant offers.
5. Trackable campaign links and creator attribution reporting.
6. A company dashboard for campaign briefs, shortlists, approvals and results.
7. Announcement scheduling and platform-specific publishing adapters after API approval.

Do not label external social publishing, royalty feeds, payment rails or automated payouts “live” until provider approval, credentials, signed tests and real production events exist.

## 8. 90-day execution plan

| Period | Actions | Evidence of progress |
|---|---|---|
| Days 1–14 | Confirm contracting entity and CIPC status; prepare one-page profile, founder/artist bio, sample portfolio, service list, draft rate card, budget template and standard contract. Build a list of 20 qualified leads. | Accurate company/individual status; complete proposal pack; 20 researched leads; no invented metrics. |
| Days 15–30 | Approach 10 local SMEs; submit 2 carefully tailored sponsor enquiries (Absa and Standard Bank); apply suitable creators to Unilever U-Creators / relevant networks; ask one local business for a paid or valued in-kind pilot. | Contact log; replies; meetings; one scoped pilot proposal. |
| Days 31–60 | Deliver one small pilot; document every deliverable; collect permitted platform analytics, tracked clicks/codes and customer feedback; publish a case study with approval. | Signed brief; proof of delivery; actual results; client testimonial if granted. |
| Days 61–90 | Use the case study to approach the next 10–15 brands; pitch a larger creator conversion campaign or community activation; recruit additional creators only with signed terms and verified profiles. | Repeat proposal pipeline; renewal discussion; measured campaign economics; signed creator agreements. |

## 9. Outreach templates

### A. Absa sponsorship enquiry

**Subject:** Sponsorship proposal enquiry — Mamelodi Creative Enterprise & Digital Culture Pilot

Hello Absa Sponsorship Team,

I am preparing a Mamelodi-based creative initiative through Appreciate Absalom Artist Development & Management, supported by the APPRECIATE platform. The proposed pilot will help emerging creators develop professional content, build brand-ready profiles and participate in a measured community-facing campaign.

I have reviewed Absa's published arts and culture sponsorship criteria. I would like to confirm whether a structured pilot of this type is within scope and what eligibility, contracting-entity and proposal requirements apply.

The proposal will set out the target community, schedule, budget, sponsor rights, deliverables, safeguarding, content approvals and post-campaign reporting. We will not present unverified audience figures or promise sales that cannot be substantiated.

Please advise the correct application route and whether an early-stage independent project should work with an eligible implementation partner.

Kind regards,  
**Bongani Magagula**  
Appreciate Absalom Artist Development & Management

### B. Standard Bank arts partnership enquiry

**Subject:** Emerging Gauteng creator-development partnership enquiry

Hello Standard Bank Sponsorship Team,

I am developing a practical artist-development and digital-content pilot based in Mamelodi, Pretoria. The concept is to support emerging talent with professional content, audience development, responsible brand partnerships and documented campaign outcomes.

Given Standard Bank's established arts and culture work, I would appreciate guidance on the appropriate route for a small emerging-artist initiative or a partnership linked to an existing arts programme.

I can provide a concise concept note, proposed budget, artist profile, sample content, delivery schedule and measurable sponsor benefits. Please let me know whether there is a relevant current programme or future application window.

Kind regards,  
**Bongani Magagula**  
Appreciate Absalom Artist Development & Management

### C. Brand / UGC collaboration enquiry

**Subject:** South African creator-content pilot proposal

Hello Partnerships Team,

I represent Appreciate Absalom Artist Development & Management and am building APPRECIATE, a platform for creators, products and business partnerships.

I would like to explore a small content or affiliate pilot that fits your brand. We would agree the creator, product, content format, tracking link/code, usage rights, disclosure wording, approval process and payment/commission terms before any content is published.

Could you confirm whether your creator programme is currently accepting applications and share the current requirements and commercial terms?

Kind regards,  
**Bongani Magagula**  
Appreciate Absalom Artist Development & Management

### D. Local SME pilot invitation

**Subject:** A small creator-content pilot for [Business Name]

Hello [Name],

I am building a local creator and business-development service through Appreciate Absalom Artist Development & Management and APPRECIATE.

I would like to propose a small pilot to help [Business Name] show one product or service through authentic short-form content and a shareable business page. We can agree the deliverables, budget or in-kind exchange, publication dates and how results will be measured before starting.

Would you be open to a short discussion this week?

Kind regards,  
**Bongani Magagula**

### Follow-up
Send one short follow-up after five business days: “I am following up on the proposal below. If this is not the correct team, would you please direct me to the person responsible for sponsorships, creator partnerships or marketing procurement?”

## 10. Readiness, compliance and trust

Before accepting a corporate contract or supplier registration:

- Confirm the legal contracting party and current CIPC status. Do not describe an entity as active if its status has not been verified.
- Keep identity, banking, tax and business details accurate. Use an appropriate written agreement and invoice process.
- For government procurement, the National Treasury CSD is the central supplier database; registration requires accurate supplier identity, contact, bank, tax and other details. It is not a blanket prerequisite for every private-sector sponsorship.
- Confirm creator permission for every use of their image, music, voice, name and content. Define platforms, territory, duration, paid-media rights, exclusivity and editing rights.
- Use clear `#Ad`, `#Sponsored` or other applicable disclosure on paid or gifted promotional content and follow the current Advertising Regulatory Board Code.
- Obtain consent before using creator audience information or sending direct marketing. Keep an auditable consent and unsubscribe process under POPIA.
- Keep contracts, invoices, receipts, bank statements, sponsorship/affiliate statements and proof of gifted goods/services. SARS guidance says relevant influencer/content-creation records should generally be retained for at least five years.
- Do not store bank passwords, PINs or OTPs. Payments become “paid” only after a trusted provider confirmation or validated internal voucher event.
- Keep a record of complaints, cancellations, refunds, disputes and campaign corrections.

## 11. Dashboard metrics

**Corporate pipeline:** researched leads, first contacts, response rate, meetings, proposals, proposal value, wins, time-to-close and renewals.

**Creator performance:** accepted briefs, on-time delivery, approved content, verified views/engagement where available, link clicks, code redemptions, creator earnings and repeat bookings.

**Consumer growth:** visitor-to-registration rate, active users, follows, shares, product-page visits, checkout starts, paid orders, repeat purchases, refunds and referral conversions.

**Financial control:** invoiced, pending, provider-confirmed, refunded, creator payable, management fee and settled cash. Never merge estimates with confirmed receipts.

## 12. Source register

1. [Absa sponsorship criteria and application route](https://www.absa.co.za/about-us/sponsorship/sponsorship-criteria/)
2. [Standard Bank sponsorship portfolio](https://sponsorships.standardbank.com/sbgs/sponsorship)
3. [Standard Bank sponsorship contact](https://sponsorships.standardbank.com/sbgs/sponsorship/contact-us)
4. [MTN One TV African stories announcement, 16 September 2026](https://www.mtn.com/mtn-one-tv-launches-search-for-bold-african-stories/)
5. [Unilever U-Creators](https://u-creators.community.humanz.com/)
6. [L'Oréalistar South Africa](https://lorealistar.community.humanz.com/)
7. [Mr Mattress UGC creator programme](https://www.mrmattress.co.za/pages/partner-with-us-ugc-creators)
8. [TRENZY Spaces creator collaborations](https://trenzyspaces.co.za/pages/trenzy-creator-partnerships)
9. [Sun International supplier registration](https://corporate.suninternational.com/procurement)
10. [Capitec supplier registration](https://www.capitecbank.co.za/procurement/)
11. [DALI creator network](https://www.dali.africa/)
12. [iAgency creator network](https://iagency.co.za/creators/)
13. [Plug Central creator commerce](https://www.plugcentral.co.za/)
14. [World Wide Worx — Online Retail in South Africa 2026](https://www.worldwideworx.com/onlineretailsa2026-retails-next-big-market/)
15. [National Treasury Central Supplier Database — how to register](https://secure.csd.gov.za/Account/_RegistrationProcess)
16. [Information Regulator — POPIA direct-marketing guidance](https://inforegulator.org.za/wp-content/uploads/2020/07/GUIDANCE-NOTE-ON-DIRECT-MARKETING-IN-TERMS-OF-THE-PROTECTION-OF-PERSONAL-INFORMATION-ACT-4-OF-2013-POPIA.pdf)
17. [Advertising Regulatory Board — Social Media Appendix](https://www.arb.org.za/code-file-downloads/lappendix-k_social-media.pdf)
18. [SARS — Social media influencers and content creators](https://www.sars.gov.za/businesses-and-employers/small-businesses-taxpayers/social-media-influencers-and-content-creators/)

**Important:** This is a researched acquisition plan and proposal framework, not a guarantee that any named company will fund or contract the project. Verify current programme terms, legal readiness and every proposed deliverable before making an offer.
