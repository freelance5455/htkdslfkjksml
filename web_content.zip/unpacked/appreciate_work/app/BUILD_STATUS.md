# APPRECIATE v1.40 — build status

## Implemented in source
- APPRECIATE Cloud Services section inside the existing app, sharing account authentication; owner-scoped project records, APPRECIATE CODE HTTPS repository URL validation, framework/region selection and deployment request ledger with branch validation. Requests remain explicitly `awaiting_provider_setup` until a real provider integration is configured.
- Single-page responsive PWA with monochrome / black-white-grey 3D-inspired design and original APPRECIATE brand assets.
- Self-hosted Express API and PostgreSQL schema; no Supabase dependency in this build.
- Account registration/login, bcrypt hashing, expiring server-side sessions, HttpOnly cookie session, CSRF token check, rate-limited auth/payment routes and role-gated management endpoints.
- Profile records, marketplace product listings, order creation, payment transaction records and user order history.
- Client booking request flow for artist performances/appearances, consultations, artist development, music production, video/content and brand campaigns. Managers can accept with a quote or decline; accepted bookings generate invoices that use the existing checkout flow; clients can cancel and void unpaid invoices.
- Voucher issue/redeem code paths with HMAC-hashed voucher codes, balance locking and one-time display of the voucher code.
- PayPal REST checkout, capture and webhook verification code, disabled by default until merchant credentials and webhook registration are configured.
- Bank-channel records for Capitec, FNB, TymeBank, Standard Bank and Absa, plus a provider adapter contract that fails closed when no contracted PSP adapter is installed.
- Artist profile applications, dashboard aggregates, management commissions, payout records and refund-request records.
- Corporate enquiries, proposal response, agreement creation, in-app party signatures, deliverables, reports and sponsorship/service invoices.
- Campaign drafts, destination status records, in-app announcements and social connection request status.
- Rights partner directory, artist consent/authorisation records, admin verification controls, one-off batch request preparation and verified-source reporting schema. Partner cards switch from monochrome to active state only after all verification gates pass; current cards use neutral marks rather than official trademark artwork.
- Music release metadata, rights declaration, paid music entitlement records and offline play-event sync logging.
- Manual shipment lifecycle, proof-of-delivery requirement, buyer delivery confirmation and delivery dispute records.

## Not live / not yet implemented
- APPRECIATE CLOUD v1.3 now implements owner-operated native Git repository creation, ZIP source intake, Dockerfile image builds and container deployment. The in-app cloud project request ledger is still separate and does not itself deploy code. Git push/clone transport, customer database provisioning, cloud billing/quotas, backups, monitoring, custom domains and SSL automation remain incomplete.
- Booking calendar synchronisation, automatic availability conflict detection, email/SMS/WhatsApp reminders, and automated staff scheduling are not implemented.
- No server or PostgreSQL database has been deployed for the owner.
- No APK is built in this package. The PWA can be hosted and wrapped by an HTML-to-APK builder after the backend is deployed.
- No real merchant accounts, PayPal keys, bank PSP/aggregator agreement, API keys or webhook secrets are included. Payment and payout source paths have not passed sandbox or settlement end-to-end tests.
- No bank checkout can run until a specific PSP is selected, its provider adapter is implemented from official docs, merchant onboarding is complete, and sandbox/live webhooks are tested.
- PayPal is not enabled until PayPal merchant credentials, webhook ID and sandbox/live end-to-end tests are supplied.
- Email verification, password recovery and MFA are not implemented. v1.40 adds private evidence upload/storage and human-review queues for identity and recording ownership; actual KYC/AML decisions still require qualified human review and configured private storage.
- No OAuth app approval or live social publishing/analytics from YouTube, TikTok, Instagram, Facebook, X, Pinterest, LinkedIn or messaging platforms.
- No SAMRO, SAMPRA, YouTube/Content ID, Spotify/distributor, TikTok, Meta, label or publisher report feed is connected. The generic HMAC receiver is only a server-side intake contract; no provider-specific OAuth, request dispatcher, payload mapper, partner agreement, credential or real report exists. No royalty amount is fabricated.
- No private media storage or signed audio download service is installed; offline play-event sync is a log only and does not create streaming royalties. Product stock is checked when an order is created but is not yet reserved/decremented transactionally, so inventory control needs a follow-up implementation.
- No courier API, automatic courier assignment, live tracking webhook or courier proof-of-delivery integration. Shipment records are manual until a courier partner is contracted.
- No automated bank payouts or automatic refunds. Payout and refund records require human/provider action.
- No production penetration test, POPIA/legal review, load test, disaster recovery test or Android device test has been completed. The visual treatment is 3D-inspired; there is no production interactive 3D engine or advertising renderer.

## Verification in this package
- JavaScript syntax checks are run by `npm run check` (Node.js 20+).
- PostgreSQL schema is reviewed for object order and referenced table/column consistency. A live PostgreSQL server is required for actual schema execution; this build environment did not include PostgreSQL.
- ZIP integrity is checked after packaging. This is packaging/source verification, not production certification.

## Release rule
Never show a connection as active, a post as published, a royalty as received, a payment as paid or a payout as sent unless a trusted provider event or verified operator action supports it.


## Additional reporting-source work (8 November 2026 review)
- Added explicit, versioned and revocable artist consent history; identity/recording human-review endpoints; signed partner report ingestion with timestamp, nonce, HMAC, delivery idempotency, ISRC/consent attribution and audit events; separate reporting dashboard aggregates; and paid-amount settlement evidence checks.
- Added Node built-in unit tests for signature, replay-window, payload and paid-evidence validation (6 tests passed). These source changes are not production-tested and do not create partner approval or real feeds. The PostgreSQL migration has not been executed against a live PostgreSQL server.

- A stored partner connection-test reference is an operator audit record, not independent proof of a provider's approval. It must be backed by real provider documentation and a successful test before any partner is activated.


## Partner activation and dispatch hardening (9 November 2026)
- Added `server/partner-connectors.js` to load only partner-code-specific server adapters from `integrations/providers/rights/`.
- Removed administrator ability to mark an endpoint active/verified by entering a free-text test reference. A partner must pass the new provider-specific live test route before activation.
- One-off report requests now invoke the installed partner adapter and record `submitted` only after a provider-issued request reference is returned. Missing adapters are recorded as not dispatched/manual follow-up.
- No provider adapters are installed in this package; no provider has supplied an agreement, credential, test response or statement feed. The network is still not live.


## External artist authorisation separation (10 November 2026)
- Added a distinct external partner-side artist mandate table and event history. APPRECIATE's own consent is no longer treated as proof of a YouTube/Content ID, distributor, TikTok, Meta, label, publisher, SAMRO or SAMPRA authorisation.
- Report requests and report-row attribution now require an independently reviewed, current external authorisation record as well as active APPRECIATE consent, verified artist identity, verified ISRC ownership, approved partner agreement and active provider connection.
- Added artist submission and administrator evidence-review routes for external mandates. Private object storage must be configured before evidence submissions are accepted; no OAuth or provider-side mandate has been obtained by this source change.
- Partner adapter receipts now include raw provider response bytes/text and the server recomputes SHA-256 before accepting the receipt. This detects digest mismatch but does not replace provider-specific signature verification or an actual provider connection.
- Source-level unit tests cover the separate mandate gate. No real external mandate, live partner feed or deployed database was available in this run.


## v1.36 main display update — 10 November 2026
- Updated the existing Discover screen with a premium dark/gold visual system and mobile-first editorial discovery cards.
- Added local category filters for For you, Music, Creators, Shop and Business. Cards link to existing app sections; no synthetic engagement data is shown.
- Refined sidebar, mobile navigation, forms, panels, cards, buttons, and PWA theme colours.
- Updated service-worker cache key to appreciate-shell-v1-40.
- Existing server, database, account, commerce, rights, artist and corporate modules were retained unchanged.
- Source checks: npm run check, npm test (15/15), npm run verify — PASS.
- No live backend, payment, social OAuth, rights partner, courier, media storage or Android APK verification was performed.


## v1.40 private evidence upload work — 11 November 2026
- Added an S3-compatible SigV4 server-side PUT, HEAD and short-lived GET requests.
- Added owner-bound upload intents for identity, recording-rights and partner-authorisation evidence, fixed file-type allowlist, 10 MB cap, server-side object verification and one-time attachment.
- Admin review now refuses evidence records without an attached upload and a current object check; admin view links expire after 60 seconds and are audited.
- Added migration 008 and unit tests for URL signing and fail-closed configuration.
- Requires a private S3-compatible bucket, credentials and private-bucket default encryption. This environment did not have those credentials, so no live upload was tested.


## Music audio upload and playback source update (11 November 2026)
- Added artist-owned release audio upload intent, browser-to-private-S3 PUT, server-side HEAD verification and database storage-key update.
- Added an artist's own-release list and HTML audio playback using short-lived signed private-object URLs.
- Accepted audio types: MP3, M4A, WAV, OGG and FLAC; maximum 50 MB.
- Upload requires `MEDIA_STORAGE_DRIVER=s3` plus a private S3-compatible bucket, endpoint, region and credentials. Bucket CORS must allow the APPRECIATE app origin to PUT objects with the `Content-Type` header.
- This is source implementation only. It is not live until private storage is configured, database is deployed, the app is redeployed, and a real Android upload/playback test succeeds. No royalty or streaming income is created by local playback.


## v1.41.2 Music interface correction (11 November 2026)
- Combined release metadata and audio file selection into one user-facing form; no manual release ID entry is required.
- The release ID is created by the API and passed directly to the secure upload workflow.
- Existing My uploaded tracks HTML audio controls remain the playback interface.
- Live upload/playback still depends on configured private S3-compatible storage and a deployed backend.
