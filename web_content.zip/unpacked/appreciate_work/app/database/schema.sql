-- APPRECIATE v1.32 — self-hosted PostgreSQL schema.
-- Apply once to a new database. Run with a least-privilege application DB role.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  account_type TEXT NOT NULL DEFAULT 'member'
    CHECK (account_type IN ('member','creator','artist','seller','company','manager','admin')),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_login_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS profiles (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL DEFAULT 'APPRECIATE member',
  username TEXT UNIQUE,
  bio TEXT NOT NULL DEFAULT '',
  avatar_storage_key TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS auth_sessions (
  session_id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS auth_sessions_user_idx ON auth_sessions(user_id, expires_at DESC);

CREATE TABLE IF NOT EXISTS artist_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  stage_name TEXT NOT NULL,
  genre TEXT NOT NULL DEFAULT '',
  biography TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','suspended')),
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS artist_identity_verifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  evidence_storage_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected','needs_resubmission')),
  reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  review_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS artist_identity_latest_idx ON artist_identity_verifications(artist_id, created_at DESC);

CREATE TABLE IF NOT EXISTS company_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  company_name TEXT NOT NULL,
  contact_name TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected','suspended')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  kind TEXT NOT NULL CHECK (kind IN ('physical','service','music','digital')),
  category TEXT NOT NULL DEFAULT 'Other',
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 2 AND 120),
  description TEXT NOT NULL DEFAULT '',
  price_minor BIGINT NOT NULL CHECK (price_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  stock_quantity INTEGER CHECK (stock_quantity IS NULL OR stock_quantity >= 0),
  image_storage_key TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS products_public_idx ON products(status, created_at DESC);
CREATE INDEX IF NOT EXISTS products_seller_idx ON products(seller_id, created_at DESC);

CREATE TABLE IF NOT EXISTS music_releases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  product_id UUID UNIQUE REFERENCES products(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  artist_display_name TEXT NOT NULL,
  isrc TEXT,
  upc TEXT,
  ownership_declaration TEXT NOT NULL,
  rights_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
  artwork_storage_key TEXT,
  audio_storage_key TEXT,
  duration_seconds INTEGER CHECK (duration_seconds IS NULL OR duration_seconds > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS music_play_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  release_id UUID NOT NULL REFERENCES music_releases(id) ON DELETE CASCADE,
  offline_event_id TEXT NOT NULL,
  played_at TIMESTAMPTZ NOT NULL,
  synced_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(buyer_id, offline_event_id)
);

CREATE TABLE IF NOT EXISTS release_splits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  release_id UUID NOT NULL REFERENCES music_releases(id) ON DELETE CASCADE,
  contributor_name TEXT NOT NULL,
  contributor_email TEXT,
  role TEXT NOT NULL,
  split_basis_points INTEGER NOT NULL CHECK (split_basis_points BETWEEN 0 AND 10000),
  accepted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  state TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','paid','fulfilled','cancelled','refunded')),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  total_minor BIGINT NOT NULL CHECK (total_minor > 0),
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  seller_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  product_kind TEXT NOT NULL,
  title_snapshot TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price_minor BIGINT NOT NULL CHECK (unit_price_minor > 0),
  line_total_minor BIGINT NOT NULL CHECK (line_total_minor > 0)
);

CREATE TABLE IF NOT EXISTS music_entitlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  release_id UUID NOT NULL REFERENCES music_releases(id) ON DELETE CASCADE,
  order_item_id UUID NOT NULL UNIQUE REFERENCES order_items(id) ON DELETE CASCADE,
  granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(buyer_id, release_id)
);

CREATE TABLE IF NOT EXISTS payment_invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agreement_id UUID,
  bill_to_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  payee_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  reference TEXT NOT NULL UNIQUE,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','void','overdue')),
  due_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS client_bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference TEXT NOT NULL UNIQUE,
  client_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  service_type TEXT NOT NULL CHECK (service_type IN ('artist_performance','artist_appearance','artist_consultation','artist_development','music_production','video_content','brand_campaign','other')),
  booking_date DATE NOT NULL,
  start_time TIME NOT NULL,
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes BETWEEN 15 AND 1440),
  location TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','accepted_pending_payment','confirmed','declined','cancelled','completed')),
  amount_minor BIGINT CHECK (amount_minor IS NULL OR amount_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  invoice_id UUID REFERENCES payment_invoices(id) ON DELETE SET NULL,
  reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS client_bookings_client_idx ON client_bookings(client_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS client_bookings_schedule_idx ON client_bookings(booking_date, start_time, status);

CREATE TABLE IF NOT EXISTS payment_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES orders(id) ON DELETE RESTRICT,
  invoice_id UUID REFERENCES payment_invoices(id) ON DELETE RESTRICT,
  reference TEXT NOT NULL UNIQUE,
  customer_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL,
  method TEXT NOT NULL CHECK (method IN ('paypal','voucher','capitec','fnb','tymebank','standard_bank','absa')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','requires_provider_setup','requires_provider_adapter','paid','failed','refunded','cancelled')),
  provider TEXT,
  provider_reference TEXT,
  description TEXT NOT NULL DEFAULT 'APPRECIATE payment',
  provider_payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  paid_at TIMESTAMPTZ,
  CHECK ((order_id IS NOT NULL AND invoice_id IS NULL) OR (order_id IS NULL AND invoice_id IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS payment_transactions_status_idx ON payment_transactions(status, created_at DESC);
CREATE INDEX IF NOT EXISTS payment_transactions_customer_idx ON payment_transactions(customer_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS payment_provider_reference_unique ON payment_transactions(provider, provider_reference) WHERE provider_reference IS NOT NULL;

CREATE TABLE IF NOT EXISTS ledger_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID REFERENCES payment_transactions(id) ON DELETE SET NULL,
  invoice_id UUID REFERENCES payment_invoices(id) ON DELETE SET NULL,
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  entry_type TEXT NOT NULL,
  amount_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL,
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ledger_owner_idx ON ledger_entries(owner_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS vouchers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code_hash TEXT NOT NULL UNIQUE,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  balance_minor BIGINT NOT NULL CHECK (balance_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','redeemed','cancelled','expired')),
  expires_at TIMESTAMPTZ,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS voucher_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  voucher_id UUID NOT NULL REFERENCES vouchers(id),
  customer_id UUID NOT NULL REFERENCES users(id),
  order_id UUID REFERENCES orders(id),
  invoice_id UUID REFERENCES payment_invoices(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  reference TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK ((order_id IS NOT NULL AND invoice_id IS NULL) OR (order_id IS NULL AND invoice_id IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS shipments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  seller_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  buyer_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  courier_provider TEXT,
  courier_reference TEXT,
  tracking_url TEXT,
  delivery_contact_name TEXT,
  delivery_contact_phone TEXT,
  status TEXT NOT NULL DEFAULT 'awaiting_dispatch' CHECK (status IN ('awaiting_dispatch','dispatched','in_transit','out_for_delivery','delivered','failed','returned','disputed')),
  proof_storage_key TEXT,
  proof_url TEXT,
  dispatched_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  buyer_confirmed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(order_id,seller_id)
);

CREATE TABLE IF NOT EXISTS shipment_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id UUID NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('manual','courier_webhook','system')),
  note TEXT NOT NULL DEFAULT '',
  proof_storage_key TEXT,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS delivery_disputes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id UUID NOT NULL REFERENCES shipments(id) ON DELETE RESTRICT,
  opened_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','investigating','resolved_buyer','resolved_seller','closed')),
  resolution TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS artist_payouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  reference TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','processing','paid','failed','cancelled')),
  payout_provider TEXT,
  provider_reference TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  paid_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  caption TEXT NOT NULL DEFAULT '',
  product_id UUID REFERENCES products(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','prepared','scheduled','published','failed')),
  scheduled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS campaign_destinations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  platform TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'awaiting_oauth' CHECK (status IN ('draft','awaiting_oauth','queued','published','failed','unsupported')),
  external_post_id TEXT,
  response_note TEXT,
  published_at TIMESTAMPTZ,
  UNIQUE(campaign_id, platform)
);

CREATE TABLE IF NOT EXISTS announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  audience TEXT NOT NULL DEFAULT 'public' CHECK (audience IN ('public','creators','artists','partners','internal')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  publish_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS social_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'not_connected' CHECK (status IN ('not_connected','pending_approval','connected','permission_limited','expired','revoked','failed')),
  scopes TEXT[] NOT NULL DEFAULT '{}',
  external_account_ref TEXT,
  token_secret_ref TEXT,
  connected_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, platform)
);

CREATE TABLE IF NOT EXISTS reporting_partners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  partner_type TEXT NOT NULL CHECK (partner_type IN ('platform','content_id_partner','distributor','label','publisher','collecting_society','rights_admin','other')),
  intake_mode TEXT NOT NULL CHECK (intake_mode IN ('oauth_api','partner_api','signed_webhook','sftp_statement','secure_manual_statement','other')),
  agreement_status TEXT NOT NULL DEFAULT 'not_contacted' CHECK (agreement_status IN ('not_contacted','contacted','under_review','approved','rejected','suspended')),
  endpoint_status TEXT NOT NULL DEFAULT 'not_configured' CHECK (endpoint_status IN ('not_configured','testing','active','paused','failed')),
  connection_verified BOOLEAN NOT NULL DEFAULT FALSE,
  documentation_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE reporting_partners
  ADD COLUMN IF NOT EXISTS connection_test_reference TEXT,
  ADD COLUMN IF NOT EXISTS connection_tested_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS connection_tested_by UUID REFERENCES users(id) ON DELETE SET NULL;
UPDATE reporting_partners SET connection_verified=FALSE,connection_test_reference=NULL,connection_tested_at=NULL,connection_tested_by=NULL
WHERE connection_verified=TRUE AND (agreement_status<>'approved' OR endpoint_status<>'active' OR connection_test_reference IS NULL OR connection_tested_at IS NULL);
ALTER TABLE reporting_partners DROP CONSTRAINT IF EXISTS reporting_partner_verified_connection_check;
ALTER TABLE reporting_partners ADD CONSTRAINT reporting_partner_verified_connection_check
  CHECK (NOT connection_verified OR (agreement_status='approved' AND endpoint_status='active' AND connection_test_reference IS NOT NULL AND connection_tested_at IS NOT NULL));

CREATE TABLE IF NOT EXISTS artist_partner_authorisations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner_id UUID NOT NULL REFERENCES reporting_partners(id),
  scope TEXT[] NOT NULL DEFAULT '{}',
  authorisation_method TEXT NOT NULL CHECK (authorisation_method IN ('oauth','signed_mandate','partner_portal','contract','manual_verified')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','expired','revoked','rejected','action_required')),
  external_account_ref TEXT,
  evidence_storage_key TEXT,
  granted_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(artist_id, partner_id)
);

ALTER TABLE artist_partner_authorisations
  ADD COLUMN IF NOT EXISTS consent_version TEXT,
  ADD COLUMN IF NOT EXISTS consent_text TEXT,
  ADD COLUMN IF NOT EXISTS consent_sha256 TEXT,
  ADD COLUMN IF NOT EXISTS consent_granted_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS consent_ip_hash TEXT;

ALTER TABLE artist_partner_authorisations DROP CONSTRAINT IF EXISTS artist_partner_authorisations_authorisation_method_check;
ALTER TABLE artist_partner_authorisations ADD CONSTRAINT artist_partner_authorisations_authorisation_method_check
  CHECK (authorisation_method IN ('oauth','signed_mandate','partner_portal','contract','manual_verified','appreciate_consent'));

CREATE TABLE IF NOT EXISTS artist_partner_authorisation_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  authorisation_id UUID NOT NULL REFERENCES artist_partner_authorisations(id) ON DELETE CASCADE,
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner_id UUID NOT NULL REFERENCES reporting_partners(id),
  event_type TEXT NOT NULL CHECK (event_type IN ('consent_granted','consent_updated','consent_revoked','admin_rejected','admin_flagged','expired')),
  scope TEXT[] NOT NULL DEFAULT '{}',
  consent_version TEXT NOT NULL,
  consent_sha256 TEXT NOT NULL,
  method TEXT NOT NULL,
  ip_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS artist_partner_auth_events_idx ON artist_partner_authorisation_events(artist_id, partner_id, created_at DESC);


-- External partner-side artist mandate is separate from APPRECIATE's own consent.
-- An artist's click inside APPRECIATE never substitutes for OAuth, a partner portal mandate or a signed authorisation.
CREATE TABLE IF NOT EXISTS artist_partner_external_authorisations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner_id UUID NOT NULL REFERENCES reporting_partners(id) ON DELETE CASCADE,
  authorisation_method TEXT NOT NULL CHECK (authorisation_method IN ('oauth','signed_mandate','partner_portal','contract')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected','expired','revoked','action_required')),
  external_account_ref TEXT,
  external_authorisation_reference TEXT,
  external_scope TEXT[] NOT NULL DEFAULT '{}',
  evidence_storage_key TEXT NOT NULL,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  verified_by UUID REFERENCES users(id) ON DELETE SET NULL,
  verified_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  review_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(artist_id, partner_id),
  CHECK (status <> 'verified' OR (external_authorisation_reference IS NOT NULL AND verified_by IS NOT NULL AND verified_at IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS artist_partner_external_auth_current_idx
  ON artist_partner_external_authorisations(artist_id, partner_id, status, expires_at);

CREATE TABLE IF NOT EXISTS artist_partner_external_authorisation_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  external_authorisation_id UUID NOT NULL REFERENCES artist_partner_external_authorisations(id) ON DELETE CASCADE,
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner_id UUID NOT NULL REFERENCES reporting_partners(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL CHECK (event_type IN ('submitted','verified','rejected','expired','revoked','action_required','replaced')),
  actor_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS artist_partner_external_auth_events_idx
  ON artist_partner_external_authorisation_events(artist_id, partner_id, created_at DESC);

CREATE TABLE IF NOT EXISTS artist_recordings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  isrc TEXT,
  upc TEXT,
  iswc TEXT,
  ownership_role TEXT,
  ownership_share NUMERIC(7,4) CHECK (ownership_share IS NULL OR ownership_share BETWEEN 0 AND 100),
  evidence_storage_key TEXT,
  verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending','verified','disputed','rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS artist_recordings_isrc_idx ON artist_recordings(isrc);

CREATE TABLE IF NOT EXISTS partner_report_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id UUID NOT NULL REFERENCES reporting_partners(id),
  partner_delivery_id TEXT NOT NULL,
  payload_sha256 TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reporting_period_start DATE,
  reporting_period_end DATE,
  currency CHAR(3),
  status TEXT NOT NULL DEFAULT 'received' CHECK (status IN ('received','validated','processing','processed','rejected','duplicate','needs_review')),
  rejection_reason TEXT,
  UNIQUE(partner_id, partner_delivery_id)
);

CREATE TABLE IF NOT EXISTS partner_webhook_nonces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id UUID NOT NULL REFERENCES reporting_partners(id) ON DELETE CASCADE,
  nonce TEXT NOT NULL,
  signed_timestamp BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(partner_id, nonce)
);
CREATE INDEX IF NOT EXISTS partner_webhook_nonces_created_idx ON partner_webhook_nonces(created_at);

CREATE TABLE IF NOT EXISTS partner_usage_royalty_rows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_id UUID NOT NULL REFERENCES partner_report_deliveries(id) ON DELETE CASCADE,
  artist_id UUID REFERENCES users(id),
  recording_id UUID REFERENCES artist_recordings(id),
  external_asset_ref TEXT,
  isrc TEXT,
  usage_type TEXT NOT NULL,
  territory TEXT,
  usage_count BIGINT,
  gross_amount_minor BIGINT,
  net_amount_minor BIGINT,
  currency CHAR(3),
  amount_status TEXT NOT NULL DEFAULT 'reported' CHECK (amount_status IN ('reported','estimated','adjusted','paid','reversed','unknown')),
  usage_period_start DATE,
  usage_period_end DATE,
  match_status TEXT NOT NULL DEFAULT 'unmatched' CHECK (match_status IN ('unmatched','matched','ambiguous','disputed')),
  source_row_ref TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE partner_usage_royalty_rows
  ADD COLUMN IF NOT EXISTS settlement_reference TEXT,
  ADD COLUMN IF NOT EXISTS payment_confirmed_at TIMESTAMPTZ;
UPDATE partner_usage_royalty_rows SET amount_status='unknown'
WHERE amount_status='paid' AND (settlement_reference IS NULL OR payment_confirmed_at IS NULL OR net_amount_minor IS NULL);
ALTER TABLE partner_usage_royalty_rows DROP CONSTRAINT IF EXISTS partner_usage_royalty_paid_evidence_check;
ALTER TABLE partner_usage_royalty_rows ADD CONSTRAINT partner_usage_royalty_paid_evidence_check
  CHECK (amount_status<>'paid' OR (settlement_reference IS NOT NULL AND payment_confirmed_at IS NOT NULL AND net_amount_minor IS NOT NULL));

CREATE INDEX IF NOT EXISTS partner_rows_artist_period_idx ON partner_usage_royalty_rows(artist_id, usage_period_end);
CREATE INDEX IF NOT EXISTS partner_rows_isrc_idx ON partner_usage_royalty_rows(isrc);

CREATE TABLE IF NOT EXISTS artist_reporting_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner_id UUID NOT NULL REFERENCES reporting_partners(id),
  request_type TEXT NOT NULL DEFAULT 'monetisation_and_reporting_access',
  submitted_at TIMESTAMPTZ,
  external_case_ref TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','ready','submitted','acknowledged','under_review','approved','declined','follow_up_due','closed')),
  last_response_at TIMESTAMPTZ,
  next_follow_up_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE artist_reporting_requests
  ADD COLUMN IF NOT EXISTS reporting_period_start DATE,
  ADD COLUMN IF NOT EXISTS reporting_period_end DATE,
  ADD COLUMN IF NOT EXISTS batch_reference TEXT,
  ADD COLUMN IF NOT EXISTS dispatch_status TEXT NOT NULL DEFAULT 'prepared'
    CHECK (dispatch_status IN ('prepared','submitted','acknowledged','failed','manual_follow_up'));
CREATE UNIQUE INDEX IF NOT EXISTS artist_reporting_request_period_unique
  ON artist_reporting_requests(artist_id, partner_id, reporting_period_start, reporting_period_end)
  WHERE reporting_period_start IS NOT NULL AND reporting_period_end IS NOT NULL;

CREATE TABLE IF NOT EXISTS corporate_enquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  artist_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  subject TEXT NOT NULL,
  brief TEXT NOT NULL,
  budget_minor BIGINT CHECK (budget_minor IS NULL OR budget_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','reviewing','proposal_sent','negotiating','accepted','declined','closed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS proposals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  enquiry_id UUID NOT NULL REFERENCES corporate_enquiries(id) ON DELETE CASCADE,
  created_by UUID NOT NULL REFERENCES users(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  terms TEXT NOT NULL,
  valid_until DATE,
  status TEXT NOT NULL DEFAULT 'sent' CHECK (status IN ('draft','sent','accepted','rejected','expired','withdrawn')),
  responded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS agreements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  proposal_id UUID UNIQUE REFERENCES proposals(id) ON DELETE SET NULL,
  agreement_type TEXT NOT NULL CHECK (agreement_type IN ('sponsorship','artist_management','booking','partnership','service')),
  reference TEXT NOT NULL UNIQUE,
  company_user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
  artist_user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
  manager_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  terms TEXT NOT NULL,
  commission_rate_bps INTEGER NOT NULL DEFAULT 0 CHECK (commission_rate_bps BETWEEN 0 AND 10000),
  status TEXT NOT NULL DEFAULT 'awaiting_signatures' CHECK (status IN ('draft','awaiting_signatures','active','completed','terminated')),
  starts_on DATE,
  ends_on DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  activated_at TIMESTAMPTZ
);

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'payment_invoices_agreement_fk') THEN
    ALTER TABLE payment_invoices ADD CONSTRAINT payment_invoices_agreement_fk
      FOREIGN KEY (agreement_id) REFERENCES agreements(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS agreement_signatures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agreement_id UUID NOT NULL REFERENCES agreements(id) ON DELETE CASCADE,
  signer_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  signer_role TEXT NOT NULL CHECK (signer_role IN ('company','artist','manager')),
  signature_name TEXT NOT NULL,
  signed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(agreement_id, signer_user_id)
);

CREATE TABLE IF NOT EXISTS deliverables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agreement_id UUID NOT NULL REFERENCES agreements(id) ON DELETE CASCADE,
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  due_at DATE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','in_progress','submitted','accepted','rejected','overdue')),
  proof_url TEXT,
  submitted_at TIMESTAMPTZ,
  accepted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS agreement_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agreement_id UUID NOT NULL REFERENCES agreements(id) ON DELETE CASCADE,
  created_by UUID NOT NULL REFERENCES users(id),
  report_type TEXT NOT NULL,
  period_start DATE,
  period_end DATE,
  report_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','issued','acknowledged')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS management_commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  agreement_id UUID NOT NULL REFERENCES agreements(id) ON DELETE RESTRICT,
  order_item_id UUID UNIQUE REFERENCES order_items(id) ON DELETE RESTRICT,
  gross_amount_minor BIGINT NOT NULL CHECK (gross_amount_minor >= 0),
  commission_rate_bps INTEGER NOT NULL CHECK (commission_rate_bps BETWEEN 0 AND 10000),
  commission_amount_minor BIGINT NOT NULL CHECK (commission_amount_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS webhook_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  payload JSONB NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(provider, provider_event_id)
);

CREATE TABLE IF NOT EXISTS refund_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  requested_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','approved','rejected','submitted_to_provider','refunded','failed')),
  provider_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Prospective directory only. All providers start unapproved and inactive.
INSERT INTO reporting_partners(code,display_name,partner_type,intake_mode)
VALUES
 ('youtube','YouTube','platform','oauth_api'),
 ('youtube_content_id_partner','YouTube Content ID partners','content_id_partner','partner_api'),
 ('spotify','Spotify','platform','oauth_api'),
 ('music_distributor','Music distributors','distributor','sftp_statement'),
 ('tiktok','TikTok','platform','oauth_api'),
 ('meta','Meta (Instagram / Facebook)','platform','oauth_api'),
 ('record_label','Record labels','label','secure_manual_statement'),
 ('music_publisher','Music publishers','publisher','secure_manual_statement'),
 ('samro','SAMRO','collecting_society','secure_manual_statement'),
 ('sampra','SAMPRA','collecting_society','secure_manual_statement'),
 ('capasso','CAPASSO','collecting_society','secure_manual_statement'),
 ('risa','RISA','other','other'),
 ('apple_music','Apple Music','platform','oauth_api')
ON CONFLICT (code) DO NOTHING;


-- APPRECIATE v1.38: private cloud project workspace and deployment request ledger.
CREATE TABLE IF NOT EXISTS cloud_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  name TEXT NOT NULL CHECK (char_length(name) BETWEEN 2 AND 80),
  repository_url TEXT,
  framework TEXT NOT NULL CHECK (framework IN ('node','static','react','nextjs','python','php','other')),
  region TEXT NOT NULL DEFAULT 'za' CHECK (region IN ('za','eu','us')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cloud_projects_owner_idx ON cloud_projects(owner_user_id,updated_at DESC);

CREATE TABLE IF NOT EXISTS cloud_deployment_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES cloud_projects(id) ON DELETE CASCADE,
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  branch TEXT NOT NULL DEFAULT 'main',
  provider TEXT NOT NULL DEFAULT 'appreciate_cloud' CHECK (provider IN ('appreciate_cloud')),
  status TEXT NOT NULL DEFAULT 'awaiting_provider_setup' CHECK (status IN ('awaiting_provider_setup','queued','building','live','failed','cancelled')) ,
  provider_deployment_id TEXT,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cloud_deployments_project_idx ON cloud_deployment_requests(project_id,created_at DESC);
CREATE INDEX IF NOT EXISTS cloud_deployments_owner_idx ON cloud_deployment_requests(owner_user_id,created_at DESC);


-- APPRECIATE v1.40: private evidence upload intents backed by an S3-compatible private bucket.
CREATE TABLE IF NOT EXISTS private_evidence_uploads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  evidence_type TEXT NOT NULL CHECK (evidence_type IN ('identity','recording_rights','partner_authorisation')),
  object_key TEXT NOT NULL UNIQUE,
  content_type TEXT NOT NULL CHECK (content_type IN ('application/pdf','image/jpeg','image/png')),
  expected_size_bytes BIGINT NOT NULL CHECK (expected_size_bytes BETWEEN 1 AND 10485760),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','uploaded','attached','rejected','expired')),
  expires_at TIMESTAMPTZ NOT NULL,
  uploaded_at TIMESTAMPTZ,
  attached_at TIMESTAMPTZ,
  last_verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (status NOT IN ('uploaded','attached') OR uploaded_at IS NOT NULL),
  CHECK (status <> 'attached' OR attached_at IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS private_evidence_owner_idx ON private_evidence_uploads(owner_user_id,evidence_type,status,created_at DESC);
ALTER TABLE artist_identity_verifications ADD COLUMN IF NOT EXISTS evidence_upload_id UUID UNIQUE REFERENCES private_evidence_uploads(id) ON DELETE RESTRICT;
ALTER TABLE artist_recordings ADD COLUMN IF NOT EXISTS evidence_upload_id UUID UNIQUE REFERENCES private_evidence_uploads(id) ON DELETE RESTRICT;
ALTER TABLE artist_partner_external_authorisations ADD COLUMN IF NOT EXISTS evidence_upload_id UUID UNIQUE REFERENCES private_evidence_uploads(id) ON DELETE RESTRICT;
CREATE INDEX IF NOT EXISTS artist_identity_evidence_upload_idx ON artist_identity_verifications(evidence_upload_id);
CREATE INDEX IF NOT EXISTS artist_recording_evidence_upload_idx ON artist_recordings(evidence_upload_id);
CREATE INDEX IF NOT EXISTS artist_partner_external_evidence_upload_idx ON artist_partner_external_authorisations(evidence_upload_id);
