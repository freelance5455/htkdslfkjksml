-- APPRECIATE v1.33 reporting ingestion and consent hardening. Apply to an existing v1.32 database after the base schema is present. Fresh databases already receive these objects from database/schema.sql.
CREATE TABLE IF NOT EXISTS artist_identity_verifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  evidence_storage_key TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected','needs_resubmission')),
  reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL, reviewed_at TIMESTAMPTZ, review_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS artist_identity_latest_idx ON artist_identity_verifications(artist_id, created_at DESC);
ALTER TABLE artist_partner_authorisations ADD COLUMN IF NOT EXISTS consent_version TEXT, ADD COLUMN IF NOT EXISTS consent_text TEXT, ADD COLUMN IF NOT EXISTS consent_sha256 TEXT, ADD COLUMN IF NOT EXISTS consent_granted_at TIMESTAMPTZ, ADD COLUMN IF NOT EXISTS consent_ip_hash TEXT;
ALTER TABLE artist_partner_authorisations DROP CONSTRAINT IF EXISTS artist_partner_authorisations_authorisation_method_check;
ALTER TABLE artist_partner_authorisations ADD CONSTRAINT artist_partner_authorisations_authorisation_method_check CHECK (authorisation_method IN ('oauth','signed_mandate','partner_portal','contract','manual_verified','appreciate_consent'));
CREATE TABLE IF NOT EXISTS artist_partner_authorisation_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), authorisation_id UUID NOT NULL REFERENCES artist_partner_authorisations(id) ON DELETE CASCADE,
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, partner_id UUID NOT NULL REFERENCES reporting_partners(id),
  event_type TEXT NOT NULL CHECK (event_type IN ('consent_granted','consent_updated','consent_revoked','admin_rejected','admin_flagged','expired')),
  scope TEXT[] NOT NULL DEFAULT '{}', consent_version TEXT NOT NULL, consent_sha256 TEXT NOT NULL, method TEXT NOT NULL, ip_hash TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS artist_partner_auth_events_idx ON artist_partner_authorisation_events(artist_id, partner_id, created_at DESC);
CREATE TABLE IF NOT EXISTS partner_webhook_nonces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), partner_id UUID NOT NULL REFERENCES reporting_partners(id) ON DELETE CASCADE, nonce TEXT NOT NULL,
  signed_timestamp BIGINT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), UNIQUE(partner_id, nonce)
);
CREATE INDEX IF NOT EXISTS partner_webhook_nonces_created_idx ON partner_webhook_nonces(created_at);
ALTER TABLE partner_usage_royalty_rows ADD COLUMN IF NOT EXISTS settlement_reference TEXT, ADD COLUMN IF NOT EXISTS payment_confirmed_at TIMESTAMPTZ;
UPDATE partner_usage_royalty_rows SET amount_status='unknown' WHERE amount_status='paid' AND (settlement_reference IS NULL OR payment_confirmed_at IS NULL OR net_amount_minor IS NULL);
ALTER TABLE partner_usage_royalty_rows DROP CONSTRAINT IF EXISTS partner_usage_royalty_paid_evidence_check;
ALTER TABLE partner_usage_royalty_rows ADD CONSTRAINT partner_usage_royalty_paid_evidence_check CHECK (amount_status<>'paid' OR (settlement_reference IS NOT NULL AND payment_confirmed_at IS NOT NULL AND net_amount_minor IS NOT NULL));
ALTER TABLE artist_reporting_requests ADD COLUMN IF NOT EXISTS reporting_period_start DATE, ADD COLUMN IF NOT EXISTS reporting_period_end DATE, ADD COLUMN IF NOT EXISTS batch_reference TEXT, ADD COLUMN IF NOT EXISTS dispatch_status TEXT NOT NULL DEFAULT 'prepared' CHECK (dispatch_status IN ('prepared','submitted','acknowledged','failed','manual_follow_up'));
CREATE UNIQUE INDEX IF NOT EXISTS artist_reporting_request_period_unique ON artist_reporting_requests(artist_id, partner_id, reporting_period_start, reporting_period_end) WHERE reporting_period_start IS NOT NULL AND reporting_period_end IS NOT NULL;
ALTER TABLE reporting_partners ADD COLUMN IF NOT EXISTS connection_test_reference TEXT, ADD COLUMN IF NOT EXISTS connection_tested_at TIMESTAMPTZ, ADD COLUMN IF NOT EXISTS connection_tested_by UUID REFERENCES users(id) ON DELETE SET NULL;
UPDATE reporting_partners SET connection_verified=FALSE,connection_test_reference=NULL,connection_tested_at=NULL,connection_tested_by=NULL WHERE connection_verified=TRUE AND (agreement_status<>'approved' OR endpoint_status<>'active' OR connection_test_reference IS NULL OR connection_tested_at IS NULL);
ALTER TABLE reporting_partners DROP CONSTRAINT IF EXISTS reporting_partner_verified_connection_check;
ALTER TABLE reporting_partners ADD CONSTRAINT reporting_partner_verified_connection_check CHECK (NOT connection_verified OR (agreement_status='approved' AND endpoint_status='active' AND connection_test_reference IS NOT NULL AND connection_tested_at IS NOT NULL));
