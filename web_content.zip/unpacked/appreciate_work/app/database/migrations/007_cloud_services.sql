-- APPRECIATE v1.38: private cloud project workspace and deployment request ledger.
CREATE TABLE IF NOT EXISTS cloud_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  name TEXT NOT NULL CHECK (char_length(name) BETWEEN 2 AND 80),
  repository_url TEXT,
  framework TEXT NOT NULL CHECK (framework IN ('node','static','react','nextjs','python','php','other')),
  region TEXT NOT NULL DEFAULT 'za' CHECK (region IN ('za','eu','us')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cloud_projects_owner_idx ON cloud_projects(owner_user_id,updated_at DESC);

CREATE TABLE IF NOT EXISTS cloud_deployment_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES cloud_projects(id) ON DELETE CASCADE,
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  branch TEXT NOT NULL DEFAULT 'main',
  provider TEXT NOT NULL DEFAULT 'render' CHECK (provider IN ('render')),
  status TEXT NOT NULL DEFAULT 'awaiting_provider_setup' CHECK (status IN ('awaiting_provider_setup','queued','building','live','failed','cancelled')) ,
  provider_deployment_id TEXT,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cloud_deployments_project_idx ON cloud_deployment_requests(project_id,created_at DESC);
CREATE INDEX IF NOT EXISTS cloud_deployments_owner_idx ON cloud_deployment_requests(owner_user_id,created_at DESC);
