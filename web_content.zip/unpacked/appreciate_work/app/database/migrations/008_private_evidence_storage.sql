-- APPRECIATE v1.40: private evidence upload intents backed by an S3-compatible private bucket.
CREATE TABLE IF NOT EXISTS private_evidence_uploads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  evidence_type TEXT NOT NULL CHECK (evidence_type IN ('identity','recording_rights','partner_authorisation')),
  object_key TEXT NOT NULL UNIQUE,
  content_type TEXT NOT NULL CHECK (content_type IN ('application/pdf','image/jpeg','image/png')),
  expected_size_bytes BIGINT NOT NULL CHECK (expected_size_bytes BETWEEN 1 AND 10485760),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','uploaded','attached','rejected','expired')),
  expires_at TIMESTAMPTZ NOT NULL,
  uploaded_at TIMESTAMPTZ,
  attached_at TIMESTAMPTZ,
  last_verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (status NOT IN ('uploaded','attached') OR uploaded_at IS NOT NULL),
  CHECK (status <> 'attached' OR attached_at IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS private_evidence_owner_idx ON private_evidence_uploads(owner_user_id,evidence_type,status,created_at DESC);
ALTER TABLE artist_identity_verifications ADD COLUMN IF NOT EXISTS evidence_upload_id UUID UNIQUE REFERENCES private_evidence_uploads(id) ON DELETE RESTRICT;
ALTER TABLE artist_recordings ADD COLUMN IF NOT EXISTS evidence_upload_id UUID UNIQUE REFERENCES private_evidence_uploads(id) ON DELETE RESTRICT;
ALTER TABLE artist_partner_external_authorisations ADD COLUMN IF NOT EXISTS evidence_upload_id UUID UNIQUE REFERENCES private_evidence_uploads(id) ON DELETE RESTRICT;
CREATE INDEX IF NOT EXISTS artist_identity_evidence_upload_idx ON artist_identity_verifications(evidence_upload_id);
CREATE INDEX IF NOT EXISTS artist_recording_evidence_upload_idx ON artist_recordings(evidence_upload_id);
CREATE INDEX IF NOT EXISTS artist_partner_external_evidence_upload_idx ON artist_partner_external_authorisations(evidence_upload_id);
