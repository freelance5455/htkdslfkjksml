-- APPRECIATE v1.42: deployment request records belong to APPRECIATE CLOUD.
-- This records the intended control plane; it does not imply that a deployment ran.
ALTER TABLE cloud_deployment_requests
  DROP CONSTRAINT IF EXISTS cloud_deployment_requests_provider_check;
ALTER TABLE cloud_deployment_requests
  ALTER COLUMN provider SET DEFAULT 'appreciate_cloud';
ALTER TABLE cloud_deployment_requests
  ADD CONSTRAINT cloud_deployment_requests_provider_check
  CHECK (provider IN ('appreciate_cloud'));
UPDATE cloud_deployment_requests SET provider='appreciate_cloud' WHERE provider='render';
