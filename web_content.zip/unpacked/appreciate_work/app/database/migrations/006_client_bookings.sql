-- APPRECIATE v1.37: client booking requests and invoice-backed acceptance.
CREATE TABLE IF NOT EXISTS client_bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference TEXT NOT NULL UNIQUE,
  client_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  service_type TEXT NOT NULL CHECK (service_type IN ('artist_performance','artist_appearance','artist_consultation','artist_development','music_production','video_content','brand_campaign','other')),
  booking_date DATE NOT NULL,
  start_time TIME NOT NULL,
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes BETWEEN 15 AND 1440),
  location TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','accepted_pending_payment','confirmed','declined','cancelled','completed')),
  amount_minor BIGINT CHECK (amount_minor IS NULL OR amount_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'ZAR',
  invoice_id UUID REFERENCES payment_invoices(id) ON DELETE SET NULL,
  reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS client_bookings_client_idx ON client_bookings(client_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS client_bookings_schedule_idx ON client_bookings(booking_date, start_time, status);
