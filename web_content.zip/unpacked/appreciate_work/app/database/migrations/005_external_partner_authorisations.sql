-- APPRECIATE v1.35: separate internal consent from the external partner-side artist mandate.
-- Apply after database/schema.sql and migrations 001-004.
CREATE TABLE IF NOT EXISTS artist_partner_external_authorisations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner_id UUID NOT NULL REFERENCES reporting_partners(id) ON DELETE CASCADE,
  authorisation_method TEXT NOT NULL CHECK (authorisation_method IN ('oauth','signed_mandate','partner_portal','contract')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected','expired','revoked','action_required')),
  external_account_ref TEXT,
  external_authorisation_reference TEXT,
  external_scope TEXT[] NOT NULL DEFAULT '{}',
  evidence_storage_key TEXT NOT NULL,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  verified_by UUID REFERENCES users(id) ON DELETE SET NULL,
  verified_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  review_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(artist_id, partner_id),
  CHECK (status <> 'verified' OR (external_authorisation_reference IS NOT NULL AND verified_by IS NOT NULL AND verified_at IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS artist_partner_external_auth_current_idx
  ON artist_partner_external_authorisations(artist_id, partner_id, status, expires_at);
CREATE TABLE IF NOT EXISTS artist_partner_external_authorisation_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  external_authorisation_id UUID NOT NULL REFERENCES artist_partner_external_authorisations(id) ON DELETE CASCADE,
  artist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner_id UUID NOT NULL REFERENCES reporting_partners(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL CHECK (event_type IN ('submitted','verified','rejected','expired','revoked','action_required','replaced')),
  actor_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS artist_partner_external_auth_events_idx
  ON artist_partner_external_authorisation_events(artist_id, partner_id, created_at DESC);
