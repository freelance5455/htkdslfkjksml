# APPRECIATE release completion gates

Status reviewed: 10 November 2026. This is a development candidate, not a release.

| Required capability | Source state | Live evidence still required | Release result |
|---|---|---|---|
| Secure artist registration | Password hashing, sessions, HttpOnly cookies, CSRF and role checks exist. | Email verification, recovery/MFA, production configuration and HTTP integration tests. | Partial |
| Artist identity verification | Human-review routes and status records exist. | Private evidence upload/storage, secure reviewer access, actual identity checks and deployed database. | Partial |
| Recording ownership | ISRC/ownership claims and admin review routes exist. | Private evidence storage, rights-document review, split/co-owner validation and deployed database. | Partial |
| One-time partner-specific artist consent | Versioned, hashed, revocable APPRECIATE consent exists per partner. | Where required, the partner's own OAuth/portal mandate or signed external authorisation and approved scopes. | Partial |
| YouTube / eligible Content ID partners | Directory and signed intake contract exist; no provider-specific adapter is installed. | Content-owner/partner approval, credentials, provider-specific request/test adapter, signed feed or statement route, and real received report. | Blocked |
| Spotify via distributors/labels | Directory and generic intake contract exist; no royalty-statement adapter is installed. | Authorised distributor/label agreement, artist mandate, statement delivery route, provider-specific adapter and real received statement. | Blocked |
| TikTok | Directory and generic intake contract exist; no approved reporting adapter/feed is installed. | Developer/app approval, permitted reporting access, partner-specific adapter and real received report. | Blocked |
| Meta | Directory and generic intake contract exist; no approved reporting adapter/feed is installed. | App review, permitted account permissions, partner-specific adapter and real received report. | Blocked |
| Labels and publishers | Directory and secure-manual-statement design exist. | Signed agreements, approved secure delivery route, provider-specific intake mapping and real statements. | Blocked |
| SAMRO and SAMPRA | Directory and generic signed intake exist; no approved feed/adapter is installed. | Written data route/mandate, contract or approved access, provider-specific mapping and real statements. | Blocked |
| Secure report ingestion and audit | HMAC signature, timestamp window, nonce/replay protection, delivery idempotency, ISRC/consent matching and audit source exist. | Live deployment, secret rotation, database migration, partner security test, actual feed delivery and restore/retention tests. | Partial |
| Artist reporting dashboard | Usage, estimated, reported and settlement-confirmed totals are separate in source. | Live PostgreSQL queries against actual partner reports and end-to-end artist account tests. | Partial |
| Payments and settlement | Voucher and PayPal/bank PSP code paths exist; payment records and ledger settlement source exist. | Merchant onboarding, real PSP adapter, sandbox/live checkout, signed webhook, refunds, settlement and payout end-to-end tests. | Partial |
| Android application | Responsive PWA and wrapper guidance exist. | Flutter/Android build, APK signing, install and device testing. | Not ready |
| 3D and social features | 3D-inspired styling, campaigns and announcements exist. | Production 3D renderer/ad backgrounds and a real social feed with media storage/moderation. | Partial |
| Production operations | PostgreSQL schema, deployment docs and security controls exist. | Live Neon/hosted DB connection, secrets, private object storage, backups, monitoring, POPIA review, penetration/load testing. | Not ready |

## Verification boundary

A partner directory entry, a manual status edit, an APPRECIATE consent record, a generated test fixture, a public metadata API, or a generic HMAC receiver is not proof of a partner agreement or royalty-report feed. A partner is marked active only after a provider-specific server adapter performs a live test and returns provider-issued references plus a response digest. A report request is marked submitted only after the provider acknowledges it with its own request reference and response digest. A royalty is marked paid only when the report includes settlement evidence and the dashboard can trace it to the source delivery.

The package's 15 unit tests exercise local validation, external-mandate gates and adapter receipt checks. They do not simulate or certify any real partner, database, payment or settlement workflow.


## Additional gate added 10 November 2026
An APPRECIATE in-app consent record is not an external partner mandate. Each artist/partner pair must also have a separate, current external authorisation record, with a partner-issued reference and private evidence reviewed by an administrator. Report requests, report attribution and dashboard visibility are blocked without it. The new source routes and schema are not a substitute for OAuth approval or a real signed mandate from the partner.

| External partner-side artist mandate | Separate table, submission route, admin review, expiry and scope gates exist in source. | Real partner-issued OAuth/portal/signed mandate, private evidence object, human review and live database verification. | Blocked |


## v1.40 evidence-storage update — 11 November 2026
| Required capability | Source state | Live evidence still required | Release result |
|---|---|---|---|
| Private identity/rights/mandate evidence | S3-compatible authenticated server-side upload intents, fixed type/MIME/size gates, server-side HEAD verification, one-time attachment and short-lived audited admin view links implemented in source. | Configure a private bucket and credentials, apply migration 008, test upload/view/rejection flows against the actual provider, scan files for malware and complete human identity/rights review. | Partial |

The new source prevents administrator review of evidence that has no attached upload record or whose object fails a fresh private-storage HEAD check. It does not perform identity/KYC verification or prove a recording-rights claim by itself.
