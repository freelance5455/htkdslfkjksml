const crypto = require('crypto');
const db = require('./db');
const badRequest = (message) => { const error = new Error(message); error.status = 400; return error; };

function hashVoucher(code) {
  const pepper = process.env.VOUCHER_CODE_PEPPER;
  if (!pepper || pepper.length < 32 || pepper.includes('REPLACE') || pepper.includes('change_me')) throw new Error('VOUCHER_CODE_PEPPER must be replaced with a unique secret of at least 32 characters.');
  return crypto.createHmac('sha256', pepper).update(String(code).trim().toUpperCase()).digest('hex');
}

function makeVoucherCode() {
  return `AP-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
}

async function issueVoucher({ amount, currency = 'ZAR', expiresAt = null, createdBy }) {
  const value = Number(amount);
  if (!Number.isFinite(value) || value <= 0 || value > 1000000) throw badRequest('Voucher amount must be positive and within the permitted limit.');
  const code = makeVoucherCode();
  const result = await db.query(
    `INSERT INTO vouchers(code_hash,amount_minor,balance_minor,currency,expires_at,created_by)
     VALUES($1,$2,$2,$3,$4,$5)
     RETURNING id,amount_minor,balance_minor,currency,expires_at,status,created_at`,
    [hashVoucher(code), Math.round(value * 100), currency, expiresAt, createdBy]
  );
  return { voucher: result.rows[0], code };
}

async function redeemVoucherInTransaction(client, { code, amountMinor, currency, customerId, orderId = null, invoiceId = null, reference }) {
  if (!code || !Number.isInteger(Number(amountMinor)) || Number(amountMinor) <= 0) throw badRequest('Voucher code and valid amount are required.');
  const found = await client.query('SELECT * FROM vouchers WHERE code_hash=$1 FOR UPDATE', [hashVoucher(code)]);
  if (!found.rowCount) throw badRequest('Voucher not found.');
  const voucher = found.rows[0];
  if (voucher.status !== 'active') throw badRequest('Voucher is not active.');
  if (voucher.expires_at && new Date(voucher.expires_at) < new Date()) throw badRequest('Voucher has expired.');
  if (voucher.currency !== currency) throw badRequest('Voucher currency does not match this payment.');
  if (Number(voucher.balance_minor) < Number(amountMinor)) throw badRequest('Voucher balance is insufficient for this payment.');
  const updated = await client.query(
    `UPDATE vouchers SET balance_minor=balance_minor-$1,
       status=CASE WHEN balance_minor-$1=0 THEN 'redeemed' ELSE 'active' END
     WHERE id=$2 RETURNING balance_minor,status`,
    [amountMinor, voucher.id]
  );
  await client.query(
    `INSERT INTO voucher_transactions(voucher_id,customer_id,order_id,invoice_id,amount_minor,reference)
     VALUES($1,$2,$3,$4,$5,$6)`,
    [voucher.id, customerId, orderId, invoiceId, amountMinor, reference]
  );
  return { voucherId: voucher.id, remainingBalanceMinor: Number(updated.rows[0].balance_minor), status: updated.rows[0].status };
}

module.exports = { hashVoucher, makeVoucherCode, issueVoucher, redeemVoucherInTransaction };
