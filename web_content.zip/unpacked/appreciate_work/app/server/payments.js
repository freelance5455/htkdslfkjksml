const crypto = require('crypto');
const db = require('./db');
const paypal = require('./paypal');
const bankProvider = require('./bank-provider');
const { redeemVoucherInTransaction } = require('./vouchers');

const BANK_METHODS = new Set(['capitec', 'fnb', 'tymebank', 'standard_bank', 'absa']);
const CURRENCIES = new Set(['ZAR', 'USD', 'EUR', 'GBP']);
const money = (minor) => (Number(minor) / 100).toFixed(2);
const badRequest = (message) => { const error = new Error(message); error.status = 400; return error; };

async function loadTarget(client, userId, orderId, invoiceId, lock = true) {
  if (!!orderId === !!invoiceId) throw badRequest('Provide exactly one orderId or invoiceId.');
  const suffix = lock ? ' FOR UPDATE' : '';
  if (orderId) {
    const result = await client.query(`SELECT * FROM orders WHERE id=$1 AND buyer_id=$2${suffix}`, [orderId, userId]);
    if (!result.rowCount) throw badRequest('Order not found for this account.');
    const target = result.rows[0];
    if (target.state !== 'pending') throw badRequest('Only pending orders can be paid.');
    return { type: 'order', id: target.id, amountMinor: Number(target.total_minor), currency: target.currency, description: `APPRECIATE order ${target.id}` };
  }
  const result = await client.query(`SELECT * FROM payment_invoices WHERE id=$1 AND bill_to_user_id=$2${suffix}`, [invoiceId, userId]);
  if (!result.rowCount) throw badRequest('Invoice not found for this account.');
  const target = result.rows[0];
  if (target.status !== 'pending') throw badRequest('Only pending invoices can be paid.');
  return { type: 'invoice', id: target.id, amountMinor: Number(target.amount_minor), currency: target.currency, description: target.description };
}

async function settleTarget(client, payment, target) {
  if (target.type === 'order') {
    await client.query("UPDATE orders SET state='paid',paid_at=NOW() WHERE id=$1 AND state='pending'", [target.id]);
    const items = await client.query('SELECT * FROM order_items WHERE order_id=$1', [target.id]);
    for (const item of items.rows) {
      const agreement = await client.query(
        `SELECT id,manager_user_id,commission_rate_bps FROM agreements
         WHERE artist_user_id=$1 AND agreement_type='artist_management' AND status='active'
         ORDER BY activated_at DESC NULLS LAST LIMIT 1`,
        [item.seller_id]
      );
      let commissionMinor = 0;
      if (agreement.rowCount && Number(agreement.rows[0].commission_rate_bps) > 0) {
        const a = agreement.rows[0];
        commissionMinor = Math.round(Number(item.line_total_minor) * Number(a.commission_rate_bps) / 10000);
        await client.query(
          `INSERT INTO management_commissions(artist_id,agreement_id,order_item_id,gross_amount_minor,commission_rate_bps,commission_amount_minor,currency)
           VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(order_item_id) DO NOTHING`,
          [item.seller_id, a.id, item.id, item.line_total_minor, a.commission_rate_bps, commissionMinor, payment.currency]
        );
        await client.query(
          `INSERT INTO ledger_entries(transaction_id,owner_user_id,entry_type,amount_minor,currency,description)
           VALUES($1,$2,'management_commission',$3,$4,$5)`,
          [payment.id, a.manager_user_id, commissionMinor, payment.currency, `Management commission for order item ${item.id}`]
        );
      }
      const sellerNet = Number(item.line_total_minor) - commissionMinor;
      await client.query(
        `INSERT INTO ledger_entries(transaction_id,owner_user_id,entry_type,amount_minor,currency,description)
         VALUES($1,$2,'seller_net_sale',$3,$4,$5)`,
        [payment.id, item.seller_id, sellerNet, payment.currency, `Verified sale: ${item.title_snapshot}`]
      );
      if (item.product_kind === 'music') {
        const release = await client.query('SELECT id FROM music_releases WHERE product_id=$1', [item.product_id]);
        if (release.rowCount) {
          await client.query(
            `INSERT INTO music_entitlements(buyer_id,release_id,order_item_id)
             VALUES($1,$2,$3) ON CONFLICT DO NOTHING`,
            [payment.customer_id, release.rows[0].id, item.id]
          );
        }
      }
    }
  } else {
    const invoice = await client.query("UPDATE payment_invoices SET status='paid',paid_at=NOW() WHERE id=$1 AND status='pending' RETURNING payee_user_id,reference", [target.id]);
    if (invoice.rowCount) {
      await client.query(
        `INSERT INTO ledger_entries(transaction_id,invoice_id,owner_user_id,entry_type,amount_minor,currency,description)
         VALUES($1,$2,$3,'sponsorship_or_service_payment',$4,$5,$6)`,
        [payment.id, target.id, invoice.rows[0].payee_user_id, payment.amount_minor, payment.currency, `Paid invoice ${invoice.rows[0].reference}`]
      );
    }
    await client.query("UPDATE client_bookings SET status='confirmed',updated_at=NOW() WHERE invoice_id=$1 AND status='accepted_pending_payment'", [target.id]);
  }
  await client.query(
    `INSERT INTO audit_log(actor_user_id,event_type,entity_type,entity_id,details)
     VALUES($1,'payment_verified','payment_transaction',$2,$3::jsonb)`,
    [payment.customer_id, payment.id, JSON.stringify({ reference: payment.reference, provider: payment.provider, targetType: target.type, targetId: target.id })]
  );
}

async function createPayment({ userId, orderId = null, invoiceId = null, method, voucherCode = null, bankChannel = null, returnUrl, cancelUrl }) {
  if (!['paypal', 'voucher', ...BANK_METHODS].includes(method)) throw badRequest('Unsupported payment method.');
  const client = await db.pool.connect();
  const reference = `APP-${crypto.randomUUID()}`;
  try {
    await client.query('BEGIN');
    const target = await loadTarget(client, userId, orderId, invoiceId, true);
    if (!CURRENCIES.has(target.currency)) throw badRequest('Unsupported payment currency.');
    if (method === 'voucher') {
      const paymentInsert = await client.query(
        `INSERT INTO payment_transactions(order_id,invoice_id,reference,customer_id,amount_minor,currency,method,status,provider,description)
         VALUES($1,$2,$3,$4,$5,$6,'voucher','pending','appreciate_voucher',$7) RETURNING *`,
        [orderId, invoiceId, reference, userId, target.amountMinor, target.currency, target.description]
      );
      await redeemVoucherInTransaction(client, {
        code: voucherCode, amountMinor: target.amountMinor, currency: target.currency,
        customerId: userId, orderId, invoiceId, reference
      });
      await client.query("UPDATE payment_transactions SET status='paid',paid_at=NOW() WHERE id=$1", [paymentInsert.rows[0].id]);
      const payment = { ...paymentInsert.rows[0], status: 'paid', paid_at: new Date() };
      await settleTarget(client, payment, target);
      await client.query('COMMIT');
      return { reference, status: 'paid', method: 'voucher', amount: money(target.amountMinor), currency: target.currency, message: 'Voucher payment verified and recorded.' };
    }

    const inserted = await client.query(
      `INSERT INTO payment_transactions(order_id,invoice_id,reference,customer_id,amount_minor,currency,method,status,description)
       VALUES($1,$2,$3,$4,$5,$6,$7,'pending',$8) RETURNING id,reference,amount_minor,currency,method,status`,
      [orderId, invoiceId, reference, userId, target.amountMinor, target.currency, method, target.description]
    );
    await client.query('COMMIT');

    if (method === 'paypal') {
      const ready = process.env.PAYMENT_PAYPAL_AUTHORISED === 'true' && process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET && process.env.PAYPAL_WEBHOOK_ID;
      if (!ready) {
        await db.query("UPDATE payment_transactions SET status='requires_provider_setup' WHERE id=$1", [inserted.rows[0].id]);
        return { ...inserted.rows[0], status: 'requires_provider_setup', message: 'PayPal sandbox/live credentials and verified webhook setup are required.' };
      }
      try {
        const order = await paypal.createOrder({
          amountMinor: target.amountMinor, currency: target.currency, reference,
          returnUrl: `${String(process.env.APP_BASE_URL || 'http://localhost:8080').replace(/\/$/, '')}/?payment=return&reference=${encodeURIComponent(reference)}`,
          cancelUrl: `${String(process.env.APP_BASE_URL || 'http://localhost:8080').replace(/\/$/, '')}/?payment=cancel&reference=${encodeURIComponent(reference)}`
        });
        const approval = order.links?.find((link) => link.rel === 'approve')?.href;
        if (!approval) throw new Error('PayPal did not return an approval URL.');
        await db.query(
          'UPDATE payment_transactions SET provider=$1,provider_reference=$2,provider_payload=$3 WHERE id=$4',
          ['paypal', order.id, JSON.stringify({ id: order.id, status: order.status }), inserted.rows[0].id]
        );
        return { ...inserted.rows[0], provider: 'paypal', providerReference: order.id, checkoutUrl: approval };
      } catch (error) {
        await db.query("UPDATE payment_transactions SET status='requires_provider_setup' WHERE id=$1", [inserted.rows[0].id]);
        return { ...inserted.rows[0], status: 'requires_provider_setup', message: error.message };
      }
    }

    const bank = bankProvider.readiness(method);
    if (!bank.ready) {
      await db.query("UPDATE payment_transactions SET status='requires_provider_setup' WHERE id=$1", [inserted.rows[0].id]);
      return { ...inserted.rows[0], status: 'requires_provider_setup', bankChannel: method, message: bank.reason };
    }
    try {
      const checkout = await bankProvider.createCheckout({
        reference, amountMinor: target.amountMinor, currency: target.currency,
        bankChannel: method, customerId: userId, description: target.description
      });
      if (!checkout?.checkoutUrl || !checkout?.providerReference) throw new Error('PSP adapter did not return a valid checkout response.');
      await db.query(
        'UPDATE payment_transactions SET provider=$1,provider_reference=$2,provider_payload=$3 WHERE id=$4',
        [process.env.BANK_PAYMENT_PROVIDER, checkout.providerReference, JSON.stringify(checkout.safeMetadata || {}), inserted.rows[0].id]
      );
      return { ...inserted.rows[0], checkoutUrl: checkout.checkoutUrl, provider: process.env.BANK_PAYMENT_PROVIDER };
    } catch (error) {
      await db.query("UPDATE payment_transactions SET status='requires_provider_adapter' WHERE id=$1", [inserted.rows[0].id]);
      return { ...inserted.rows[0], status: 'requires_provider_adapter', bankChannel: method, message: error.message };
    }
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

async function recordVerifiedPayment({ reference = null, provider, providerReference, amountMinor, currency, rawEvent, providerEventId = null, eventType = 'payment.completed' }) {
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const lookup = reference
      ? await client.query('SELECT * FROM payment_transactions WHERE reference=$1 FOR UPDATE', [reference])
      : await client.query('SELECT * FROM payment_transactions WHERE provider=$1 AND provider_reference=$2 FOR UPDATE', [provider, providerReference]);
    if (!lookup.rowCount) throw badRequest('Payment transaction not found.');
    const payment = lookup.rows[0];
    if (payment.provider && payment.provider !== provider) throw badRequest('Payment provider mismatch.');
    if (payment.provider_reference && providerReference && payment.provider_reference !== providerReference) throw badRequest('Provider reference mismatch.');
    if (Number(payment.amount_minor) !== Number(amountMinor) || payment.currency !== currency) throw badRequest('Payment amount or currency mismatch.');
    if (providerEventId) {
      const event = await client.query(
        `INSERT INTO webhook_events(provider,provider_event_id,event_type,verified,payload)
         VALUES($1,$2,$3,TRUE,$4::jsonb) ON CONFLICT(provider,provider_event_id) DO NOTHING RETURNING id`,
        [provider, providerEventId, eventType, JSON.stringify(rawEvent || {})]
      );
      if (!event.rowCount) {
        await client.query('COMMIT');
        return { reference: payment.reference, status: payment.status, duplicateEvent: true };
      }
    }
    if (payment.status === 'paid') {
      await client.query('COMMIT');
      return { reference: payment.reference, status: 'paid', duplicate: true };
    }
    if (!['pending','requires_provider_setup','requires_provider_adapter'].includes(payment.status)) throw badRequest('This payment is not eligible for confirmation.');
    await client.query(
      `UPDATE payment_transactions SET status='paid',provider=$1,provider_reference=COALESCE(provider_reference,$2),paid_at=NOW(),provider_payload=$3
       WHERE id=$4`,
      [provider, providerReference || null, JSON.stringify(rawEvent || {}), payment.id]
    );
    const target = payment.order_id
      ? { type: 'order', id: payment.order_id }
      : { type: 'invoice', id: payment.invoice_id };
    await settleTarget(client, { ...payment, status: 'paid', provider }, target);
    await client.query('COMMIT');
    return { reference: payment.reference, status: 'paid' };
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

module.exports = { createPayment, recordVerifiedPayment, BANK_METHODS, money };
