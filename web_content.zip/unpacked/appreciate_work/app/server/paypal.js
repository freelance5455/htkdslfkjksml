const API = () => process.env.PAYPAL_MODE === 'live'
  ? 'https://api-m.paypal.com'
  : 'https://api-m.sandbox.paypal.com';

async function paypalFetch(path, options = {}) {
  const response = await fetch(`${API()}${path}`, { ...options, signal: AbortSignal.timeout(20000) });
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: 'Provider returned a non-JSON response.' }; }
  if (!response.ok) throw new Error(data.message || data.error_description || `PayPal request failed (${response.status})`);
  return data;
}

async function accessToken() {
  const id = process.env.PAYPAL_CLIENT_ID;
  const secret = process.env.PAYPAL_CLIENT_SECRET;
  if (!id || !secret) throw new Error('PayPal credentials are not configured.');
  const basic = Buffer.from(`${id}:${secret}`).toString('base64');
  const response = await paypalFetch('/v1/oauth2/token', {
    method: 'POST',
    headers: { Authorization: `Basic ${basic}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials'
  });
  if (!response.access_token) throw new Error('PayPal did not issue an access token.');
  return response.access_token;
}

async function createOrder({ amountMinor, currency, reference, returnUrl, cancelUrl }) {
  const token = await accessToken();
  const value = (Number(amountMinor) / 100).toFixed(2);
  const data = await paypalFetch('/v2/checkout/orders', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      intent: 'CAPTURE',
      purchase_units: [{
        reference_id: reference,
        custom_id: reference,
        invoice_id: reference,
        amount: { currency_code: currency, value }
      }],
      application_context: {
        return_url: returnUrl,
        cancel_url: cancelUrl,
        shipping_preference: 'NO_SHIPPING',
        user_action: 'PAY_NOW'
      }
    })
  });
  return data;
}

async function captureOrder(orderId) {
  const token = await accessToken();
  return paypalFetch(`/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }
  });
}

async function verifyWebhook(headers, event) {
  const webhookId = process.env.PAYPAL_WEBHOOK_ID;
  if (!webhookId) throw new Error('PAYPAL_WEBHOOK_ID is not configured.');
  const token = await accessToken();
  const data = await paypalFetch('/v1/notifications/verify-webhook-signature', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      auth_algo: headers['paypal-auth-algo'],
      cert_url: headers['paypal-cert-url'],
      transmission_id: headers['paypal-transmission-id'],
      transmission_sig: headers['paypal-transmission-sig'],
      transmission_time: headers['paypal-transmission-time'],
      webhook_id: webhookId,
      webhook_event: event
    })
  });
  return data.verification_status === 'SUCCESS';
}

module.exports = { createOrder, captureOrder, verifyWebhook };
