require('dotenv').config();
const db = require('./db');
(async () => {
  const email = String(process.argv[2] || '').trim().toLowerCase();
  if (!email || !email.includes('@')) throw new Error('Usage: npm run promote-admin -- owner@example.com');
  const result = await db.query("UPDATE users SET account_type='admin' WHERE email=$1 RETURNING id,email,account_type", [email]);
  if (!result.rowCount) throw new Error('No user exists with that email. Register the owner account first.');
  console.log(`Promoted ${result.rows[0].email} to admin. Sign out and sign in again to refresh the session.`);
})().catch((error) => { console.error(error.message); process.exitCode = 1; }).finally(() => db.pool.end());
