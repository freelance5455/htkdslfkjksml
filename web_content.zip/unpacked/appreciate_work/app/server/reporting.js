const crypto = require('crypto');

const MAX_CLOCK_SKEW_SECONDS = 300;
const ALLOWED_AMOUNT_STATUS = new Set(['reported', 'estimated', 'adjusted', 'paid', 'reversed', 'unknown']);
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function partnerSecretEnvName(code) {
  const raw = String(code || '').toLowerCase();
  if (!/^[a-z0-9_]{2,80}$/.test(raw)) throw new Error('Invalid partner code.');
  const safe = raw.toUpperCase();
  return `PARTNER_WEBHOOK_SECRET_${safe}`;
}

function verifyReportSignature({ secret, timestamp, rawBody, signature, nowSeconds = Math.floor(Date.now() / 1000) }) {
  if (!secret || Buffer.byteLength(secret) < 32 || !Buffer.isBuffer(rawBody)) return false;
  if (!/^\d{10}$/.test(String(timestamp || ''))) return false;
  const sentAt = Number(timestamp);
  if (!Number.isSafeInteger(sentAt) || Math.abs(nowSeconds - sentAt) > MAX_CLOCK_SKEW_SECONDS) return false;
  const match = /^sha256=([a-f0-9]{64})$/i.exec(String(signature || ''));
  if (!match) return false;
  const expected = crypto.createHmac('sha256', secret).update(String(timestamp)).update('.').update(rawBody).digest();
  const received = Buffer.from(match[1], 'hex');
  return received.length === expected.length && crypto.timingSafeEqual(received, expected);
}

function isValidDate(value) {
  if (typeof value !== 'string' || !DATE_PATTERN.test(value)) return false;
  const d = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

function validatePartnerReport(payload) {
  const errors = [];
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return { ok: false, errors: ['Payload must be a JSON object.'] };
  if (typeof payload.deliveryId !== 'string' || payload.deliveryId.trim().length < 1 || payload.deliveryId.length > 200) errors.push('deliveryId is required and must be at most 200 characters.');
  if (!isValidDate(payload.periodStart) || !isValidDate(payload.periodEnd) || payload.periodStart > payload.periodEnd) errors.push('A valid reporting period is required.');
  if (typeof payload.currency !== 'string' || !/^[A-Z]{3}$/.test(payload.currency)) errors.push('currency must be a three-letter uppercase code.');
  if (!Array.isArray(payload.rows) || payload.rows.length < 1 || payload.rows.length > 1000) errors.push('rows must contain between 1 and 1000 records.');
  if (Array.isArray(payload.rows)) {
    payload.rows.forEach((row, i) => {
      const prefix = `rows[${i}]`;
      if (!row || typeof row !== 'object' || Array.isArray(row)) { errors.push(`${prefix} must be an object.`); return; }
      if (typeof row.isrc !== 'string' || !/^[A-Z]{2}[A-Z0-9]{3}\d{7}$/.test(row.isrc.toUpperCase())) errors.push(`${prefix}.isrc is invalid or missing.`);
      if (typeof row.usageType !== 'string' || row.usageType.trim().length < 1 || row.usageType.length > 80) errors.push(`${prefix}.usageType is required (max 80 characters).`);
      if (row.usageCount != null && (!Number.isSafeInteger(row.usageCount) || row.usageCount < 0)) errors.push(`${prefix}.usageCount must be a non-negative safe integer.`);
      for (const key of ['grossAmountMinor', 'netAmountMinor']) {
        if (row[key] != null && (!Number.isSafeInteger(row[key]) || Math.abs(row[key]) > 9000000000000000)) errors.push(`${prefix}.${key} must be a safe integer in minor units.`);
      }
      if (row.amountStatus != null && !ALLOWED_AMOUNT_STATUS.has(row.amountStatus)) errors.push(`${prefix}.amountStatus is invalid.`);
      if (row.amountStatus === 'paid') {
        if (!Number.isSafeInteger(row.netAmountMinor)) errors.push(`${prefix}.netAmountMinor is required for paid amounts.`);
        if (typeof row.settlementReference !== 'string' || row.settlementReference.trim().length < 3 || row.settlementReference.length > 200) errors.push(`${prefix}.settlementReference is required for paid amounts.`);
        if (typeof row.paymentConfirmedAt !== 'string' || !Number.isFinite(Date.parse(row.paymentConfirmedAt))) errors.push(`${prefix}.paymentConfirmedAt is required for paid amounts.`);
      }
      if (row.usagePeriodStart != null && !isValidDate(row.usagePeriodStart)) errors.push(`${prefix}.usagePeriodStart is invalid.`);
      if (row.usagePeriodEnd != null && !isValidDate(row.usagePeriodEnd)) errors.push(`${prefix}.usagePeriodEnd is invalid.`);
      if (row.usagePeriodStart && row.usagePeriodEnd && row.usagePeriodStart > row.usagePeriodEnd) errors.push(`${prefix} usage period start must not be after its end.`);
      if (row.sourceRowRef != null && (typeof row.sourceRowRef !== 'string' || row.sourceRowRef.length > 200)) errors.push(`${prefix}.sourceRowRef is invalid.`);
    });
  }
  return { ok: errors.length === 0, errors };
}

module.exports = { MAX_CLOCK_SKEW_SECONDS, partnerSecretEnvName, verifyReportSignature, validatePartnerReport, isValidDate };
