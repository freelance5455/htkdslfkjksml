const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('./db');

const COOKIE_NAME = 'ap_session';
const CSRF_COOKIE = 'ap_csrf';
const ISSUER = 'appreciate-auth';
const AUDIENCE = 'appreciate-api';

function sessionHours() {
  const configured = Number(process.env.SESSION_HOURS || 8);
  return Number.isFinite(configured) ? Math.min(Math.max(Math.floor(configured), 1), 24) : 8;
}

function cookieOptions() {
  const secure = process.env.COOKIE_SECURE === 'true' || process.env.NODE_ENV === 'production';
  return { httpOnly: true, secure, sameSite: 'lax', path: '/', maxAge: sessionHours() * 60 * 60 * 1000 };
}

async function createSession(user, res, clientType = 'web') {
  const sessionId = crypto.randomUUID();
  const hours = sessionHours();
  const expiresAt = new Date(Date.now() + hours * 60 * 60 * 1000);
  const token = jwt.sign(
    { sub: user.id, sid: sessionId, iss: ISSUER, aud: AUDIENCE },
    process.env.APP_SECRET,
    { algorithm: 'HS256', expiresIn: `${hours}h`, jwtid: sessionId }
  );
  await db.query('INSERT INTO auth_sessions(session_id,user_id,expires_at) VALUES($1,$2,$3)', [sessionId, user.id, expiresAt]);
  res.cookie(COOKIE_NAME, token, cookieOptions());
  const csrf = crypto.randomBytes(24).toString('hex');
  res.cookie(CSRF_COOKIE, csrf, { ...cookieOptions(), httpOnly: false });
  return clientType === 'mobile' ? token : undefined;
}

async function requireAuth(req, res, next) {
  try {
    const bearer = req.get('authorization');
    const token = bearer && /^Bearer\s+/i.test(bearer)
      ? bearer.replace(/^Bearer\s+/i, '')
      : req.cookies?.[COOKIE_NAME];
    if (!token) return res.status(401).json({ error: 'Sign in is required.' });
    const claims = jwt.verify(token, process.env.APP_SECRET, {
      algorithms: ['HS256'], issuer: ISSUER, audience: AUDIENCE,
      clockTolerance: 5
    });
    if (!claims.sid || !claims.sub) return res.status(401).json({ error: 'Invalid session.' });
    const result = await db.query(
      `SELECT u.id,u.email,u.account_type,u.is_active,p.display_name,p.username,p.bio
       FROM auth_sessions s JOIN users u ON u.id=s.user_id
       LEFT JOIN profiles p ON p.user_id=u.id
       WHERE s.session_id=$1 AND s.user_id=$2 AND s.revoked_at IS NULL AND s.expires_at>NOW()`,
      [claims.sid, claims.sub]
    );
    if (!result.rowCount || !result.rows[0].is_active) return res.status(401).json({ error: 'Session expired or account disabled.' });
    req.user = result.rows[0];
    req.sessionId = claims.sid;
    req.authMethod = bearer ? 'bearer' : 'cookie';
    next();
  } catch (_error) {
    return res.status(401).json({ error: 'Invalid or expired session.' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.account_type)) {
      return res.status(403).json({ error: 'This account does not have permission for that action.' });
    }
    next();
  };
}

function requireCsrf(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method) || req.path.startsWith('/webhooks/') || /^\/partners\/[a-z0-9_]+\/reports$/.test(req.path)) return next();
  if (req.get('authorization')) return next();
  const sessionCookie = req.cookies?.[COOKIE_NAME];
  if (!sessionCookie) return next();
  const cookieToken = req.cookies?.[CSRF_COOKIE];
  const headerToken = req.get('x-csrf-token');
  if (!cookieToken || !headerToken || cookieToken.length !== headerToken.length || !crypto.timingSafeEqual(Buffer.from(cookieToken), Buffer.from(headerToken))) {
    return res.status(403).json({ error: 'CSRF check failed. Refresh the page and try again.' });
  }
  next();
}

async function revokeSession(req, res) {
  if (req.sessionId) await db.query('UPDATE auth_sessions SET revoked_at=NOW() WHERE session_id=$1', [req.sessionId]);
  res.clearCookie(COOKIE_NAME, { ...cookieOptions(), maxAge: undefined });
  res.clearCookie(CSRF_COOKIE, { ...cookieOptions(), httpOnly: false, maxAge: undefined });
}

module.exports = { createSession, requireAuth, requireRole, requireCsrf, revokeSession };
