const path = require('path');
const crypto = require('crypto');
const { isCurrentExternalAuthorisation } = require('./partner-authorisation');

const PARTNER_CODE = /^[a-z0-9_]{2,80}$/;
const PROVIDER_DIR = path.resolve(__dirname, '..', 'integrations', 'providers', 'rights');

function loadAdapter(code) {
  const safeCode = String(code || '').toLowerCase();
  if (!PARTNER_CODE.test(safeCode)) throw new Error('Invalid partner code.');
  const file = path.resolve(PROVIDER_DIR, `${safeCode}.js`);
  if (!file.startsWith(`${PROVIDER_DIR}${path.sep}`)) throw new Error('Invalid partner adapter path.');
  try {
    return require(file);
  } catch (error) {
    if (error.code === 'MODULE_NOT_FOUND' && String(error.message).includes(file)) return null;
    throw error;
  }
}

function digestMatchesReceipt(receipt) {
  const raw = receipt?.rawResponse;
  if (!(typeof raw === 'string' || Buffer.isBuffer(raw))) return false;
  const expected = crypto.createHash('sha256').update(raw).digest('hex');
  return expected === String(receipt.responseSha256 || '').toLowerCase();
}

function validateConnectionReceipt(receipt) {
  if (!receipt || typeof receipt !== 'object' || receipt.ok !== true) {
    return { ok: false, reason: 'The provider did not confirm a successful connection test.' };
  }
  const providerApprovalReference = String(receipt.providerApprovalReference || '').trim();
  const externalTestReference = String(receipt.externalTestReference || '').trim();
  const responseSha256 = String(receipt.responseSha256 || '').toLowerCase();
  if (providerApprovalReference.length < 5 || providerApprovalReference.length > 200) {
    return { ok: false, reason: 'A provider-issued approval/agreement reference is required.' };
  }
  if (externalTestReference.length < 5 || externalTestReference.length > 200) {
    return { ok: false, reason: 'A provider-issued connection-test reference is required.' };
  }
  if (!/^[a-f0-9]{64}$/.test(responseSha256) || !digestMatchesReceipt(receipt)) {
    return { ok: false, reason: 'A SHA-256 digest matching the actual provider test response is required.' };
  }
  return { ok: true, providerApprovalReference, externalTestReference, responseSha256 };
}

function validateDispatchReceipt(receipt) {
  if (!receipt || typeof receipt !== 'object' || receipt.accepted !== true) {
    return { ok: false, reason: 'The provider did not acknowledge the report request.' };
  }
  const externalRequestReference = String(receipt.externalRequestReference || '').trim();
  const responseSha256 = String(receipt.responseSha256 || '').toLowerCase();
  if (externalRequestReference.length < 3 || externalRequestReference.length > 200) {
    return { ok: false, reason: 'A provider-issued request reference is required.' };
  }
  if (!/^[a-f0-9]{64}$/.test(responseSha256) || !digestMatchesReceipt(receipt)) {
    return { ok: false, reason: 'A SHA-256 digest matching the actual provider acknowledgement is required.' };
  }
  return { ok: true, externalRequestReference, responseSha256 };
}

function createPartnerConnectorService({ adapterResolver = loadAdapter } = {}) {
  async function testConnection(code, context = {}) {
    const adapter = adapterResolver(code);
    if (!adapter || typeof adapter.testConnection !== 'function' || typeof adapter.requestOneOffReport !== 'function') {
      return { ok: false, reason: 'No complete provider-specific adapter is installed. The partner cannot be activated.' };
    }
    const receipt = await adapter.testConnection(context);
    return validateConnectionReceipt(receipt);
  }

  async function requestReport(code, context = {}) {
    if (!isCurrentExternalAuthorisation(context.externalAuthorisation)) {
      return { ok: false, dispatchStatus: 'manual_follow_up', reason: 'A separately verified partner-side artist authorisation is required. APPRECIATE consent alone is not sufficient; nothing was sent.' };
    }
    const adapter = adapterResolver(code);
    if (!adapter || typeof adapter.requestOneOffReport !== 'function') {
      return { ok: false, dispatchStatus: 'manual_follow_up', reason: 'No provider-specific report-request adapter is installed. Nothing was sent.' };
    }
    const receipt = await adapter.requestOneOffReport(context);
    const validated = validateDispatchReceipt(receipt);
    if (!validated.ok) return { ...validated, dispatchStatus: 'failed' };
    return { ...validated, dispatchStatus: 'submitted' };
  }

  return { testConnection, requestReport };
}

const service = createPartnerConnectorService();
module.exports = { ...service, createPartnerConnectorService, validateConnectionReceipt, validateDispatchReceipt, digestMatchesReceipt, loadAdapter };
