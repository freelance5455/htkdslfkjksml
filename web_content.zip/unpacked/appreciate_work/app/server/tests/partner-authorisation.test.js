const test = require('node:test');
const assert = require('node:assert/strict');
const { isCurrentExternalAuthorisation } = require('../partner-authorisation');

const now = Date.parse('2026-11-10T10:00:00Z');
const valid = () => ({
  status:'verified', authorisation_method:'signed_mandate',
  external_authorisation_reference:'MANDATE-2026-11-10',
  evidence_storage_key:'private/partner-authorisations/artist-1/samro/mandate.pdf',
  external_scope:['usage_reports','royalty_statements'],
  verified_at:'2026-11-09T10:00:00Z', expires_at:'2026-12-09T10:00:00Z'
});

test('a separate verified partner-side mandate is required', () => {
  assert.equal(isCurrentExternalAuthorisation(valid(), now), true);
  assert.equal(isCurrentExternalAuthorisation({ ...valid(), status:'pending' }, now), false);
  assert.equal(isCurrentExternalAuthorisation({ ...valid(), status:'not_authorised' }, now), false);
});

test('APPRECIATE consent or an unreviewed external reference cannot satisfy the gate', () => {
  assert.equal(isCurrentExternalAuthorisation({ status:'active', authorisation_method:'appreciate_consent' }, now), false);
  assert.equal(isCurrentExternalAuthorisation({ ...valid(), external_authorisation_reference:null }, now), false);
  assert.equal(isCurrentExternalAuthorisation({ ...valid(), evidence_storage_key:'public/mandate.pdf' }, now), false);
  assert.equal(isCurrentExternalAuthorisation({ ...valid(), verified_at:null }, now), false);
  assert.equal(isCurrentExternalAuthorisation({ ...valid(), external_scope:['admin_access'] }, now), false);
});

test('expired or invalid external authorisation cannot be used', () => {
  assert.equal(isCurrentExternalAuthorisation({ ...valid(), expires_at:'2026-11-10T09:59:59Z' }, now), false);
  assert.equal(isCurrentExternalAuthorisation({ ...valid(), expires_at:'not-a-date' }, now), false);
});
