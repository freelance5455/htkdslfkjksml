'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { storageConfig, objectPath, presignRequest, createSignedPutRequest, putObject, createDownloadUrl, headObject } = require('../private-storage');

const env = {
  MEDIA_STORAGE_DRIVER: 's3',
  MEDIA_STORAGE_BUCKET: 'appreciate-private',
  MEDIA_STORAGE_ENDPOINT: 'https://account.r2.cloudflarestorage.com',
  MEDIA_STORAGE_REGION: 'auto',
  MEDIA_STORAGE_ACCESS_KEY: 'ACCESSKEYEXAMPLE',
  MEDIA_STORAGE_SECRET_KEY: 'secret-example-that-is-not-real'
};
const fixedNow = new Date('2026-11-11T10:00:00.000Z');

test('private storage fails closed unless an S3-compatible bucket and credentials are configured', () => {
  assert.equal(storageConfig({ ...env, MEDIA_STORAGE_DRIVER:'disabled' }), null);
  assert.equal(storageConfig({ ...env, MEDIA_STORAGE_SECRET_KEY:'' }), null);
  assert.equal(storageConfig({ ...env, MEDIA_STORAGE_ENDPOINT:'file:///tmp' }), null);
  assert.equal(storageConfig({ ...env, MEDIA_STORAGE_ENDPOINT:'http://public.example.com' }), null);
  assert.ok(storageConfig(env));
});

test('object keys are constrained to private paths and reject traversal', () => {
  const config = storageConfig(env);
  assert.equal(objectPath(config,'private/identity/artist-1/document.pdf'), '/appreciate-private/private/identity/artist-1/document.pdf');
  assert.throws(() => objectPath(config,'public/document.pdf'));
  assert.throws(() => objectPath(config,'private/identity/../document.pdf'));
  assert.throws(() => objectPath(config,'/private/document.pdf'));
});

test('server-side evidence PUT signs exact bytes and content length', () => {
  const body = Buffer.from('private evidence bytes');
  const result = createSignedPutRequest('private/identity/artist-1/evidence.pdf',body,'application/pdf',env,fixedNow);
  const url = new URL(result.url);
  assert.equal(url.pathname,'/appreciate-private/private/identity/artist-1/evidence.pdf');
  assert.equal(result.headers['Content-Length'],String(body.length));
  assert.equal(result.headers['Content-Type'],'application/pdf');
  assert.match(result.headers.Authorization,/^AWS4-HMAC-SHA256 Credential=ACCESSKEYEXAMPLE\//);
  assert.match(result.payloadHash,/^[a-f0-9]{64}$/);
  assert.throws(() => createSignedPutRequest('private/identity/artist-1/evidence.pdf',Buffer.alloc(0),'application/pdf',env,fixedNow));
  assert.throws(() => createSignedPutRequest('private/identity/artist-1/evidence.pdf',body,'text/html',env,fixedNow));
});

test('server-side storage client uploads bytes and verifies object metadata over HTTP', async () => {
  const body = Buffer.from('private evidence test');
  let received = Buffer.alloc(0);
  const server = http.createServer((req,res) => {
    if (req.method === 'PUT') {
      const chunks=[];
      req.on('data',(chunk)=>chunks.push(chunk));
      req.on('end',()=>{received=Buffer.concat(chunks);res.writeHead(200,{ETag:'"local-etag"'});res.end();});
      return;
    }
    if (req.method === 'HEAD') {
      res.writeHead(200,{'Content-Length':String(body.length),'Content-Type':'application/pdf','ETag':'"local-etag"'});
      res.end();
      return;
    }
    res.writeHead(405);res.end();
  });
  await new Promise((resolve)=>server.listen(0,'127.0.0.1',resolve));
  try {
    const localEnv={...env,MEDIA_STORAGE_ENDPOINT:`http://127.0.0.1:${server.address().port}`};
    const uploaded=await putObject('private/identity/artist-1/evidence.pdf',body,'application/pdf',localEnv);
    assert.equal(received.toString(),body.toString());
    assert.equal(uploaded.etag,'local-etag');
    const head=await headObject('private/identity/artist-1/evidence.pdf',localEnv);
    assert.equal(head.sizeBytes,body.length);
    assert.equal(head.contentType,'application/pdf');
    assert.equal(head.etag,'local-etag');
  } finally {
    await new Promise((resolve)=>server.close(resolve));
  }
});

test('admin download links use short-lived GET requests and private object paths', () => {
  const result = createDownloadUrl('private/recording-rights/artist-1/file.png',env,fixedNow);
  const url = new URL(result.url);
  assert.equal(url.searchParams.get('X-Amz-SignedHeaders'),'host');
  assert.equal(url.searchParams.get('X-Amz-Expires'),'60');
  assert.equal(result.headers && Object.keys(result.headers).length,0);
  assert.equal(result.expiresAt,'2026-11-11T10:01:00.000Z');
});
