const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { partnerSecretEnvName, verifyReportSignature, validatePartnerReport } = require('../reporting');

const secret = 's'.repeat(40);
const validPayload = () => ({
  deliveryId: 'partner-batch-2026-11', periodStart: '2026-10-01', periodEnd: '2026-10-31', currency: 'ZAR',
  rows: [{ isrc: 'ZAABC2612345', usageType: 'digital_stream', usageCount: 25, grossAmountMinor: 1000, netAmountMinor: 800, amountStatus: 'reported', usagePeriodStart: '2026-10-01', usagePeriodEnd: '2026-10-31', sourceRowRef: 'row-1' }]
});

test('partner secret environment variable is derived safely', () => {
  assert.equal(partnerSecretEnvName('youtube_content_id_partner'), 'PARTNER_WEBHOOK_SECRET_YOUTUBE_CONTENT_ID_PARTNER');
  assert.throws(() => partnerSecretEnvName('../x'));
});

test('valid signed body is accepted within the five-minute window', () => {
  const now = 1794000000;
  const timestamp = String(now);
  const body = Buffer.from(JSON.stringify(validPayload()));
  const sig = crypto.createHmac('sha256', secret).update(timestamp).update('.').update(body).digest('hex');
  assert.equal(verifyReportSignature({ secret, timestamp, rawBody: body, signature: `sha256=${sig}`, nowSeconds: now }), true);
});

test('bad signature and stale timestamp are rejected', () => {
  const body = Buffer.from('{}');
  assert.equal(verifyReportSignature({ secret, timestamp: '1794000000', rawBody: body, signature: `sha256=${'0'.repeat(64)}`, nowSeconds: 1794000000 }), false);
  assert.equal(verifyReportSignature({ secret, timestamp: '1793999000', rawBody: body, signature: `sha256=${'0'.repeat(64)}`, nowSeconds: 1794000000 }), false);
});

test('well-formed partner report passes validation', () => {
  assert.deepEqual(validatePartnerReport(validPayload()), { ok: true, errors: [] });
});

test('paid amount cannot pass without settlement evidence', () => {
  const p = validPayload();
  p.rows[0].amountStatus = 'paid';
  p.rows[0].netAmountMinor = null;
  const result = validatePartnerReport(p);
  assert.equal(result.ok, false);
  assert.ok(result.errors.some(x => x.includes('netAmountMinor')));
  assert.ok(result.errors.some(x => x.includes('settlementReference')));
  assert.ok(result.errors.some(x => x.includes('paymentConfirmedAt')));
});

test('invalid ISRC, date, and money types are rejected', () => {
  const p = validPayload();
  p.periodEnd = '2026-02-31';
  p.rows[0].isrc = 'not-an-isrc';
  p.rows[0].netAmountMinor = '100';
  const result = validatePartnerReport(p);
  assert.equal(result.ok, false);
  assert.ok(result.errors.length >= 3);
});
