const test = require('node:test');
const assert = require('node:assert/strict');
const {
  createPartnerConnectorService,
  validateConnectionReceipt,
  validateDispatchReceipt
} = require('../partner-connectors');

const rawResponse = '{"ok":true,"reference":"provider-test-1"}';
const digest = require('node:crypto').createHash('sha256').update(rawResponse).digest('hex');
const externalAuthorisation = { status:'verified', authorisation_method:'signed_mandate', external_authorisation_reference:'MANDATE-2026-01', evidence_storage_key:'private/partner-authorisations/artist-1/samro/mandate.pdf', external_scope:['usage_reports','royalty_statements'], verified_at:new Date().toISOString(), expires_at:null };

test('connection activation requires provider approval, provider test reference and response digest', () => {
  assert.equal(validateConnectionReceipt({
    ok:true,
    providerApprovalReference:'AGREEMENT-2026-01',
    externalTestReference:'TEST-REQUEST-01',
    responseSha256:digest, rawResponse
  }).ok, true);
  assert.equal(validateConnectionReceipt({ ok:true, externalTestReference:'TEST-REQUEST-01', responseSha256:digest, rawResponse }).ok, false);
  assert.equal(validateConnectionReceipt({ ok:true, providerApprovalReference:'AGREEMENT-2026-01', externalTestReference:'TEST-REQUEST-01', responseSha256:'nope', rawResponse }).ok, false);
});

test('report dispatch is not successful without a provider-issued request reference', () => {
  assert.equal(validateDispatchReceipt({ accepted:true, externalRequestReference:'CASE-9876', responseSha256:digest, rawResponse }).ok, true);
  assert.equal(validateDispatchReceipt({ accepted:true }).ok, false);
  assert.equal(validateDispatchReceipt({ accepted:false, externalRequestReference:'CASE-9876', responseSha256:digest, rawResponse }).ok, false);
});

test('missing partner adapter cannot activate a partner or claim a report request was sent', async () => {
  const service = createPartnerConnectorService({ adapterResolver: () => null });
  const testResult = await service.testConnection('samro', {});
  const dispatchResult = await service.requestReport('samro', { externalAuthorisation });
  assert.equal(testResult.ok, false);
  assert.equal(dispatchResult.ok, false);
  assert.equal(dispatchResult.dispatchStatus, 'manual_follow_up');
  assert.match(dispatchResult.reason, /Nothing was sent/);
});

test('a provider adapter must expose both live test and one-off request methods', async () => {
  const service = createPartnerConnectorService({ adapterResolver: () => ({ testConnection: async () => ({ ok:true, providerApprovalReference:'AGREEMENT-2026-01', externalTestReference:'TEST-REQUEST-01', responseSha256:digest }) }) });
  const result = await service.testConnection('samro', {});
  assert.equal(result.ok, false);
  assert.match(result.reason, /cannot be activated/);
});

test('APPRECIATE consent alone cannot dispatch a report without a verified external mandate', async () => {
  const service = createPartnerConnectorService({ adapterResolver: () => ({ requestOneOffReport: async () => ({ accepted:true, externalRequestReference:'CASE-9876', responseSha256:digest, rawResponse }) }) });
  const result = await service.requestReport('samro', { artistId:'artist-1' });
  assert.equal(result.ok, false);
  assert.equal(result.dispatchStatus, 'manual_follow_up');
  assert.match(result.reason, /APPRECIATE consent alone is not sufficient/);
});

test('valid adapter receipts are returned only after provider acknowledgement and external mandate', async () => {
  const service = createPartnerConnectorService({ adapterResolver: () => ({
    testConnection: async () => ({ ok:true, providerApprovalReference:'AGREEMENT-2026-01', externalTestReference:'TEST-REQUEST-01', responseSha256:digest, rawResponse }),
    requestOneOffReport: async () => ({ accepted:true, externalRequestReference:'CASE-9876', responseSha256:digest, rawResponse })
  }) });
  const tested = await service.testConnection('samro', { partner:{ code:'samro' } });
  const dispatched = await service.requestReport('samro', { artistId:'artist-1', externalAuthorisation });
  assert.equal(tested.ok, true);
  assert.equal(dispatched.ok, true);
  assert.equal(dispatched.dispatchStatus, 'submitted');
  assert.equal(dispatched.externalRequestReference, 'CASE-9876');
});
