const path = require('path');
const BANK_CHANNELS = new Set(['capitec','fnb','tymebank','standard_bank','absa']);

function configuredAdapter() {
  const name = String(process.env.BANK_PAYMENT_PROVIDER || '').toLowerCase();
  if (!name || name === 'unconfigured' || !/^[a-z0-9_-]{2,40}$/.test(name)) return null;
  try {
    const adapterPath = path.join(__dirname, '..', 'integrations', 'providers', `${name}.js`);
    // Provider adapters are server-side code installed by the deployment operator.
    return require(adapterPath);
  } catch {
    return null;
  }
}

function readiness(channel) {
  if (!BANK_CHANNELS.has(channel)) return { ready: false, reason: 'Unsupported bank channel.' };
  if (process.env[`PAYMENT_${channel.toUpperCase()}_AUTHORISED`] !== 'true') return { ready: false, reason: 'Merchant/provider approval has not been recorded.' };
  if (process.env.BANK_PROVIDER_ADAPTER_READY !== 'true') return { ready: false, reason: 'The provider-specific adapter has not passed deployment tests.' };
  if (!process.env.BANK_PROVIDER_API_BASE || !process.env.BANK_PROVIDER_API_KEY || !process.env.BANK_PROVIDER_WEBHOOK_SECRET) {
    return { ready: false, reason: 'Provider API and webhook credentials are incomplete.' };
  }
  const adapter = configuredAdapter();
  if (!adapter || typeof adapter.createCheckout !== 'function' || typeof adapter.verifyWebhook !== 'function') {
    return { ready: false, reason: 'No valid provider adapter is installed under integrations/providers/.' };
  }
  return { ready: true, reason: 'Provider adapter is installed. Run sandbox and live end-to-end approval tests before enabling customers.' };
}

async function createCheckout(input) {
  const adapter = configuredAdapter();
  if (!adapter || typeof adapter.createCheckout !== 'function') {
    throw new Error('No bank PSP adapter is installed. Use integrations/bank-psp-adapter.template.js as the provider contract.');
  }
  return adapter.createCheckout(input);
}

async function verifyWebhook(headers, body) {
  const adapter = configuredAdapter();
  if (!adapter || typeof adapter.verifyWebhook !== 'function') return null;
  return adapter.verifyWebhook(headers, body);
}

module.exports = { BANK_CHANNELS, readiness, createCheckout, verifyWebhook };
