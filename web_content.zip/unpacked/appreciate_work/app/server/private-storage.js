'use strict';

const crypto = require('node:crypto');

function awsEncode(value) {
  return encodeURIComponent(String(value)).replace(/[!'()*]/g, (char) => `%${char.charCodeAt(0).toString(16).toUpperCase()}`);
}

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function hmac(key, value, encoding) {
  return crypto.createHmac('sha256', key).update(value).digest(encoding);
}

function storageConfig(env = process.env) {
  if (String(env.MEDIA_STORAGE_DRIVER || 'disabled') !== 's3') return null;
  const endpointValue = String(env.MEDIA_STORAGE_ENDPOINT || '').trim();
  const bucket = String(env.MEDIA_STORAGE_BUCKET || '').trim();
  const accessKey = String(env.MEDIA_STORAGE_ACCESS_KEY || '').trim();
  const secretKey = String(env.MEDIA_STORAGE_SECRET_KEY || '').trim();
  const region = String(env.MEDIA_STORAGE_REGION || 'auto').trim();
  if (!endpointValue || !bucket || !accessKey || !secretKey || !region) return null;
  let endpoint;
  try { endpoint = new URL(endpointValue); } catch { return null; }
  if (!['https:', 'http:'].includes(endpoint.protocol) || endpoint.username || endpoint.password || endpoint.search || endpoint.hash) return null;
  if (endpoint.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(endpoint.hostname)) return null;
  if (!/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/i.test(bucket)) return null;
  if (/[\r\n]/.test(accessKey + secretKey + region)) return null;
  return { endpoint, bucket, accessKey, secretKey, region };
}

function signingKey(secretKey, dateStamp, region) {
  const dateKey = hmac(`AWS4${secretKey}`, dateStamp);
  const regionKey = hmac(dateKey, region);
  const serviceKey = hmac(regionKey, 's3');
  return hmac(serviceKey, 'aws4_request');
}

function objectPath(config, key) {
  const value = String(key || '');
  if (!value.startsWith('private/') || value.includes('..') || value.startsWith('/') || value.length > 900) {
    throw new Error('Private object key is invalid.');
  }
  const prefix = config.endpoint.pathname.replace(/\/+$/, '');
  return `${prefix}/${awsEncode(config.bucket)}/${value.split('/').map(awsEncode).join('/')}`;
}

function presignRequest({ method, key, expiresSeconds = 600, contentType = null, env = process.env, now = new Date() }) {
  const config = storageConfig(env);
  if (!config) { const error = new Error('Private S3-compatible object storage is not configured.'); error.status = 503; throw error; }
  const verb = String(method || '').toUpperCase();
  if (!['GET', 'PUT', 'HEAD', 'DELETE'].includes(verb)) throw new Error('Unsupported private storage operation.');
  const expires = Number(expiresSeconds);
  if (!Number.isInteger(expires) || expires < 1 || expires > 900) throw new Error('Presigned URL expiry must be between 1 and 900 seconds.');
  const date = new Date(now);
  if (!Number.isFinite(date.getTime())) throw new Error('Signing time is invalid.');
  const amzDate = date.toISOString().replace(/[:-]|\.\d{3}/g, '');
  const dateStamp = amzDate.slice(0, 8);
  const scope = `${dateStamp}/${config.region}/s3/aws4_request`;
  const uri = objectPath(config, key);
  const signedHeaders = contentType && verb === 'PUT' ? 'content-type;host' : 'host';
  const headers = signedHeaders === 'host'
    ? `host:${config.endpoint.host}\n`
    : `content-type:${String(contentType).trim()}\nhost:${config.endpoint.host}\n`;
  const params = {
    'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
    'X-Amz-Credential': `${config.accessKey}/${scope}`,
    'X-Amz-Date': amzDate,
    'X-Amz-Expires': String(expires),
    'X-Amz-SignedHeaders': signedHeaders
  };
  const canonicalQuery = Object.keys(params).sort().map((name) => `${awsEncode(name)}=${awsEncode(params[name])}`).join('&');
  const canonicalRequest = `${verb}\n${uri}\n${canonicalQuery}\n${headers}\n${signedHeaders}\nUNSIGNED-PAYLOAD`;
  const stringToSign = `AWS4-HMAC-SHA256\n${amzDate}\n${scope}\n${sha256(canonicalRequest)}`;
  const signature = hmac(signingKey(config.secretKey, dateStamp, config.region), stringToSign, 'hex');
  const url = `${config.endpoint.origin}${uri}?${canonicalQuery}&X-Amz-Signature=${signature}`;
  return { url, headers: contentType && verb === 'PUT' ? { 'Content-Type': String(contentType).trim() } : {}, expiresAt: new Date(date.getTime() + expires * 1000).toISOString() };
}

function createSignedPutRequest(key, body, contentType, env = process.env, now = new Date()) {
  const config = storageConfig(env);
  if (!config) { const error = new Error('Private S3-compatible object storage is not configured.'); error.status = 503; throw error; }
  if (!Buffer.isBuffer(body) || body.length < 1 || body.length > 10 * 1024 * 1024) throw new Error('Private evidence body must be between 1 byte and 10 MB.');
  const mime = String(contentType || '').trim().toLowerCase();
  if (!['application/pdf','image/jpeg','image/png'].includes(mime)) throw new Error('Private evidence content type is not allowed.');
  const date = new Date(now);
  if (!Number.isFinite(date.getTime())) throw new Error('Signing time is invalid.');
  const amzDate = date.toISOString().replace(/[:-]|\.\d{3}/g, '');
  const dateStamp = amzDate.slice(0, 8);
  const scope = `${dateStamp}/${config.region}/s3/aws4_request`;
  const uri = objectPath(config, key);
  const payloadHash = sha256(body);
  const headers = {
    'content-length': String(body.length),
    'content-type': mime,
    host: config.endpoint.host,
    'x-amz-content-sha256': payloadHash,
    'x-amz-date': amzDate
  };
  const signedHeaders = Object.keys(headers).sort().join(';');
  const canonicalHeaders = Object.keys(headers).sort().map((name) => `${name}:${headers[name]}\n`).join('');
  const canonicalRequest = `PUT\n${uri}\n\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;
  const stringToSign = `AWS4-HMAC-SHA256\n${amzDate}\n${scope}\n${sha256(canonicalRequest)}`;
  const signature = hmac(signingKey(config.secretKey,dateStamp,config.region),stringToSign,'hex');
  const authorization = `AWS4-HMAC-SHA256 Credential=${config.accessKey}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
  const requestHeaders = { 'Content-Type':mime, 'Content-Length':String(body.length), 'x-amz-content-sha256':payloadHash, 'x-amz-date':amzDate, Authorization:authorization };
  return { url:`${config.endpoint.origin}${uri}`, headers:requestHeaders, payloadHash };
}

async function putObject(key, body, contentType, env = process.env) {
  const signed = createSignedPutRequest(key,body,contentType,env);
  let response;
  try { response = await fetch(signed.url,{method:'PUT',headers:signed.headers,body,signal:AbortSignal.timeout(15000)}); }
  catch (cause) { const error = new Error('Private evidence storage is unavailable.'); error.status = 503; error.cause = cause; throw error; }
  if (!response.ok) {
    const error = new Error(`Private evidence storage rejected the upload (${response.status}).`);
    error.status = response.status >= 500 ? 503 : 502;
    throw error;
  }
  return { etag:String(response.headers.get('etag')||'').replace(/^\"|\"$/g,''), payloadHash:signed.payloadHash };
}

function createDownloadUrl(key, env = process.env, now = new Date()) {
  return presignRequest({ method: 'GET', key, expiresSeconds: 60, env, now });
}

async function headObject(key, env = process.env) {
  const signed = presignRequest({ method: 'HEAD', key, expiresSeconds: 60, env });
  const response = await fetch(signed.url, { method: 'HEAD', signal: AbortSignal.timeout(8000) });
  if (!response.ok) {
    const error = new Error(response.status === 404 ? 'Uploaded evidence object was not found.' : `Private storage object verification failed (${response.status}).`);
    error.status = response.status === 404 ? 404 : 503;
    throw error;
  }
  const size = Number(response.headers.get('content-length'));
  return {
    sizeBytes: Number.isSafeInteger(size) && size >= 0 ? size : null,
    contentType: String(response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase(),
    etag: String(response.headers.get('etag') || '').replace(/^"|"$/g, '')
  };
}

module.exports = { storageConfig, objectPath, presignRequest, createSignedPutRequest, putObject, createDownloadUrl, headObject, awsEncode };
