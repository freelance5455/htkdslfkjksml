const ALLOWED_EXTERNAL_METHODS = new Set(['oauth', 'signed_mandate', 'partner_portal', 'contract']);
const ALLOWED_REPORT_SCOPES = new Set(['usage_reports', 'royalty_statements']);

function isCurrentExternalAuthorisation(record, now = Date.now()) {
  if (!record || record.status !== 'verified') return false;
  if (!ALLOWED_EXTERNAL_METHODS.has(String(record.authorisation_method || ''))) return false;
  if (typeof record.external_authorisation_reference !== 'string' || record.external_authorisation_reference.trim().length < 3) return false;
  if (typeof record.evidence_storage_key !== 'string' || !record.evidence_storage_key.startsWith('private/partner-authorisations/')) return false;
  if (!record.verified_at || !Number.isFinite(Date.parse(record.verified_at))) return false;
  if (!Array.isArray(record.external_scope) || !record.external_scope.length || record.external_scope.some((scope) => !ALLOWED_REPORT_SCOPES.has(scope))) return false;
  if (record.expires_at) {
    const expiry = Date.parse(record.expires_at);
    if (!Number.isFinite(expiry) || expiry <= now) return false;
  }
  return true;
}

module.exports = { ALLOWED_EXTERNAL_METHODS, ALLOWED_REPORT_SCOPES, isCurrentExternalAuthorisation };
