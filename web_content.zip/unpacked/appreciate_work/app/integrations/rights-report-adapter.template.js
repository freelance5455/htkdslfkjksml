/**
 * Copy this file to integrations/providers/rights/<partner-code>.js only after the
 * partner has approved APPRECIATE and supplied its official API/feed specification.
 * This template intentionally contains no invented endpoint, credential, or payload.
 */
async function testConnection({ partner }) {
  if (!partner?.code || partner.agreement_status !== 'approved') {
    throw new Error('A documented and approved partner agreement is required.');
  }
  // 1. Call the provider's official health, token, or feed-test endpoint server-side.
  // 2. Verify the provider's response using its documented signature/TLS/auth method.
  // 3. Return provider-issued references, the raw provider response as `rawResponse`, and its SHA-256 digest. The APPRECIATE server recomputes the digest and rejects mismatches.
  // 4. Never return credentials or artist data to the browser.
  throw new Error('Implement the live test from the approved partner specification.');
}

async function requestOneOffReport({ artistId, partnerCode, reportType, consentRecordId, scopes, reportingPeriod, recordings }) {
  if (!artistId || !partnerCode || !consentRecordId || !Array.isArray(scopes) || !reportingPeriod?.start || !reportingPeriod?.end || !Array.isArray(recordings)) {
    throw new Error('A verified artist, partner consent, reporting period and verified catalogue are required.');
  }
  // Resolve only the provider-specific, server-side credential reference.
  // Submit one report request using the approved provider route and requested scopes.
  // Return { accepted: true, externalRequestReference: '<provider-issued reference>', rawResponse: '<actual response text or Buffer>', responseSha256: '<SHA-256 of rawResponse>' }
  // only after the provider acknowledges the request.
  void reportType;
  throw new Error('Implement the provider-approved one-off report request.');
}

module.exports = { testConnection, requestOneOffReport };
