/** Provider-neutral contract only. Implement from the chosen platform's official docs. */
async function buildAuthorisationUrl({ userId, redirectUri, state, scopes }) {
  if (!userId || !redirectUri || !state) throw new Error('Missing OAuth request context.');
  // Validate redirect URI against a fixed allow-list; generate PKCE where supported.
  // Never accept a caller-supplied arbitrary redirect or return provider secrets to the client.
  void scopes;
  throw new Error('Register and approve the provider app, then implement its official OAuth flow.');
}
async function exchangeCodeAndStoreTokens({ code, state }) {
  if (!code || !state) throw new Error('OAuth callback is incomplete.');
  // Verify one-time state, exchange code server-side, encrypt tokens at rest and audit scopes.
  throw new Error('Provider-specific token exchange and encrypted token store are required.');
}
module.exports = { buildAuthorisationUrl, exchangeCodeAndStoreTokens };
