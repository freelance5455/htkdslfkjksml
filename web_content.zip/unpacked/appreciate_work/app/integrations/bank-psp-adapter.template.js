/**
 * Copy this file to integrations/providers/<your-provider-key>.js only after signing
 * a merchant agreement and reviewing that provider's official API documentation.
 * The example intentionally contains no made-up URLs, payload fields or signatures.
 */
async function createCheckout({ reference, amountMinor, currency, bankChannel, customerId, description }) {
  if (!reference || !Number.isInteger(amountMinor) || !currency || !bankChannel || !customerId) {
    throw new Error('Invalid checkout input.');
  }
  // 1. Call the provider's documented server-to-server checkout API.
  // 2. Use BANK_PROVIDER_API_BASE and BANK_PROVIDER_API_KEY only on this server.
  // 3. Send the selected bankChannel only if the contracted provider supports it.
  // 4. Return only a hosted checkout URL and provider reference; never return secrets.
  // 5. Never request or store a customer's bank password, PIN or online-banking login.
  throw new Error('Implement this function from the contracted PSP official API documentation.');
}

async function verifyWebhook(headers, body) {
  // Verify the provider's signature, timestamp and replay protection exactly as documented.
  // Return null for invalid/unrecognised events. Never trust a browser redirect as proof.
  // A verified event must return:
  // { reference, providerReference, amountMinor, currency, eventId, eventType, rawEvent }
  void headers; void body;
  return null;
}

module.exports = { createCheckout, verifyWebhook };
