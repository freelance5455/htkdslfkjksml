# APPRECIATE v1.40 — verification record (historical sections retained)

Date: 8 November 2026

## Passed source/package checks

- `npm run check` — passed for server, browser, service-worker, adapter-template and verification JavaScript files.
- `npm run verify` — passed JSON parsing, HTML ID checks, one-HTML-entry check, static DOM references, local asset references, schema foreign-key target/order checks and checks that no `.env` or `node_modules` folder is included.
- Additional static scan — 44 PostgreSQL tables found; all declared foreign-key targets exist before use; all server query table references resolve to declared schema tables (the scanner's only extra word matches were natural-language strings, not table references).
- HTML parser — passed; 176 IDs and no duplicate IDs at the time of check.
- Static SQL table scan — 44 declared tables; no server query table names missing from the schema.
- Local image assets — all referenced files exist.

## Not executed in this environment

- PostgreSQL schema was not applied to a live server: no `psql`, PostgreSQL server, `initdb` or container runtime was available.
- npm dependencies were not installed in this environment, so the Express API was not started with installed packages.
- No PayPal sandbox account, PSP merchant account, bank adapter credentials, OAuth app approvals, rights-partner agreements or courier credentials were supplied.
- No Android SDK / Flutter toolchain was available; no APK was built.
- No live security penetration test, POPIA/legal review, load test or production restore test was performed.

## Result

The source folder and archive are package-verified. They are not a deployed production system, a live payment service or an APK. Follow `START_HERE.txt`, `docs/DEPLOYMENT.md` and `docs/INTEGRATION_STATUS.md` to complete the external setup and live tests.

## Additional source checks on 8 November 2026

- `npm run check` — passed, including new reporting module and test syntax.
- `npm test` — 6/6 Node built-in reporting tests passed (HMAC, timestamp window, payload validation, paid-evidence requirement).
- `npm run verify` — passed after the new artist reporting UI and routes were added.
- These checks do not run PostgreSQL queries, HTTP route integration, real partner feeds, merchant checkout, payouts or Android builds.


## Additional source checks — 9 November 2026
- `npm run check` — passed after adding the partner connector module and tests.
- `npm run verify` — passed after extending the source verification list.
- `npm test` — 11/11 Node unit tests passed (report signature/payload validation plus provider adapter activation and dispatch gates).
- These tests use injected adapters only to test validation logic; they do not represent any live partner connection or report.
- No PostgreSQL, SMTP, object storage, payment-provider credentials, partner adapter files, Flutter SDK or Android SDK were available in this execution environment.


## Additional source checks — 10 November 2026 (v1.35)
- Added a separate per-artist/per-partner external mandate record and immutable event history. APPRECIATE in-app consent alone no longer satisfies the report dispatch, ingestion-attribution or dashboard gates.
- Added external mandate submission and administrator review API routes, status display and review UI. These routes still depend on an externally configured private evidence store; no object upload or file inspection is implemented.
- Added scope intersection: reporting requests and dashboard categories are limited to the scopes recorded in both APPRECIATE consent and the reviewed external mandate.
- Partner adapter response digests are now recomputed from the raw response supplied by the adapter rather than accepting an unchecked digest string.
- `npm run check` — passed.
- `npm test` — 15/15 Node built-in unit tests passed, including external mandate expiry, evidence reference, scope and dispatch-gate checks.
- `npm run verify` — passed.
- PostgreSQL migrations, Express HTTP routes, object storage, real provider adapters/feeds, merchant sandbox/settlement, Android/Flutter builds, deployment and production security tests were not run. This remains a working source candidate, not a complete or production-ready platform.


## v1.36 display update — 10 November 2026
- `npm run check` — passed after Discover category-filter code and service-worker cache update.
- `npm test` — 15/15 Node unit tests passed.
- `npm run verify` — passed HTML IDs, DOM references, local assets, package JSON, manifest, schema and source checks.
- Manual live-browser and Android-device visual QA were not available in this build session.


## v1.37 client booking and payment update — 10 November 2026

- `npm run check` — passed.
- `npm run verify` — passed, including booking UI/API/schema/migration presence checks.
- `npm test` — 15/15 existing Node tests passed.
- Added `client_bookings` to the new-install schema and migration `006_client_bookings.sql` for existing databases.
- Added client request form, manager accept/decline queue, quote-to-invoice workflow, cancellation and payment-verification transition to confirmed booking.
- Not tested against a live PostgreSQL database, browser/device, live PayPal merchant account or South African PSP. Booking calendar conflict checking and notifications are not implemented.


## v1.38 APPRECIATE Cloud Services workspace — 10 November 2026

- Added Cloud Services navigation, project creation form, owner-scoped project list and deployment request UI inside the existing PWA.
- Added authenticated API routes for project creation/listing and deployment request recording; repository URLs are restricted to GitLab.com HTTPS project URLs and branch names are validated.
- Added PostgreSQL migration `007_cloud_services.sql` and new-install schema definitions.
- `npm run check` — passed.
- `npm run verify` — passed, including Cloud Services UI/API/schema/migration presence checks.
- `npm test` — 15/15 existing Node tests passed.
- Not connected to live APPRECIATE CODE/APPRECIATE DEPLOY APIs. No repository clone, code build, live deployment, customer database provisioning, billing, or live PostgreSQL migration test was performed.


## v1.40 private evidence storage verification — 11 November 2026
- `npm run check`: PASS.
- `npm run verify`: PASS, including migration/route/UI checks.
- `npm test`: PASS (19/19 Node built-in tests).
- Private storage signing, fail-closed configuration, path validation and 10 MB upload signing unit tests: PASS.
- Live S3/R2 upload and object verification: NOT RUN (no bucket credentials).
- Live PostgreSQL migration, partner APIs, payments, Android APK and device tests: NOT RUN.
