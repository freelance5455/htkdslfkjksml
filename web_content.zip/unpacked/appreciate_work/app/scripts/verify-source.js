const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const root = path.resolve(__dirname, '..');
const failures = [];
const check = (condition, message) => { if (!condition) failures.push(message); else console.log(`PASS ${message}`); };

const jsFiles = [
  'server/index.js','server/auth.js','server/payments.js','server/paypal.js',
  'server/vouchers.js','server/bank-provider.js','server/promote-admin.js','server/reporting.js','server/partner-connectors.js','server/partner-authorisation.js','server/private-storage.js','server/tests/private-storage.test.js',
  'public/app.js','public/sw.js','integrations/bank-psp-adapter.template.js',
  'integrations/social-oauth-adapter.template.js','integrations/rights-report-adapter.template.js','scripts/verify-source.js','server/tests/reporting.test.js','server/tests/partner-connectors.test.js','server/tests/partner-authorisation.test.js'
];
for (const file of jsFiles) {
  const result = spawnSync(process.execPath, ['--check', path.join(root,file)], { encoding:'utf8' });
  check(result.status === 0, `JavaScript syntax: ${file}`);
  if (result.status !== 0) process.stderr.write(result.stderr || result.stdout);
}
for (const file of ['package.json','config/integration-registry.json','config/permissions-and-reporting.json','public/manifest.webmanifest']) {
  try { JSON.parse(fs.readFileSync(path.join(root,file),'utf8')); check(true, `JSON parse: ${file}`); }
  catch (error) { check(false, `JSON parse: ${file} (${error.message})`); }
}
const html = fs.readFileSync(path.join(root,'public/index.html'),'utf8');
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map((m)=>m[1]);
const duplicates = ids.filter((id,index)=>ids.indexOf(id)!==index);
check(duplicates.length===0, `HTML has no duplicate IDs${duplicates.length?`: ${duplicates.join(', ')}`:''}`);
const js = fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const staticIds = [...new Set([...js.matchAll(/\$\('([^']+)'\)/g)].map((m)=>m[1]))];
const missingIds = staticIds.filter((id)=>!ids.includes(id));
check(missingIds.length===0, `Static JavaScript element references exist${missingIds.length?`: ${missingIds.join(', ')}`:''}`);
const htmlFiles = fs.readdirSync(path.join(root,'public')).filter((f)=>f.endsWith('.html'));
check(htmlFiles.length===1 && htmlFiles[0]==='index.html', 'PWA uses one HTML entry point');
const assetRefs = [...html.matchAll(/(?:src|href)=["']\.\/([^"']+)["']/g)].map((m)=>m[1]).filter((x)=>!x.endsWith('.css')&&!x.endsWith('.js')&&!x.endsWith('.webmanifest'));
const missingAssets = assetRefs.filter((ref)=>!fs.existsSync(path.join(root,'public',ref)));
check(missingAssets.length===0, `Referenced local image/icon assets exist${missingAssets.length?`: ${missingAssets.join(', ')}`:''}`);
const sql = fs.readFileSync(path.join(root,'database/schema.sql'),'utf8');
const tableMatches = [...sql.matchAll(/CREATE TABLE IF NOT EXISTS\s+(\w+)\s*\(/ig)];
const tablePositions = new Map(tableMatches.map((m)=>[m[1].toLowerCase(),m.index]));
const badReferences = [...sql.matchAll(/REFERENCES\s+(\w+)\s*\(/ig)].filter((m)=>!tablePositions.has(m[1].toLowerCase()) || tablePositions.get(m[1].toLowerCase())>m.index).map((m)=>m[1]);
check(badReferences.length===0, `Schema foreign-key targets exist before use${badReferences.length?`: ${badReferences.join(', ')}`:''}`);
const cloudHtml = html.includes('id="cloud"') && html.includes('id="cloudProjectForm"') && html.includes('data-view="cloud"');
check(cloudHtml, 'APPRECIATE Cloud Services navigation and project form exist');
check(html.includes('id="identityEvidenceForm"') && html.includes('id="recordingEvidenceForm"') && html.includes('id="externalMandateEvidenceFile"'), 'Artist identity, recording ownership and external mandate upload forms exist');
check(js.includes('uploadEvidenceFile') && js.includes('/api/v1/artists/me/evidence-uploads/'), 'Artist evidence upload UI uses authenticated upload and completion routes');
check(html.includes('id="identityReviewQueue"') && html.includes('id="recordingReviewQueue"') && js.includes('loadAdminEvidenceQueues'), 'Administrator identity and recording evidence review queues exist');
check(js.includes('/api/v1/cloud/projects') && js.includes('data-cloud-deploy'), 'Cloud project and deployment request UI is connected to API');
check(fs.existsSync(path.join(root,'database/migrations/007_cloud_services.sql')), 'Cloud Services database migration exists');
check(fs.existsSync(path.join(root,'database/migrations/008_private_evidence_storage.sql')), 'Private evidence storage migration exists');
check(sql.includes('CREATE TABLE IF NOT EXISTS private_evidence_uploads') && js.includes('/api/v1/artists/me/evidence-uploads') && js.includes('/api/v1/admin/evidence-uploads/'), 'Private evidence upload, completion and review-view routes exist');
check(sql.includes('CREATE TABLE IF NOT EXISTS cloud_projects') && sql.includes('CREATE TABLE IF NOT EXISTS cloud_deployment_requests'), 'New database schema includes Cloud Services tables');
const bookingHtml = html.includes('id=\"bookingForm\"') && html.includes('id=\"bookingManagerPanel\"');
check(bookingHtml, 'Client booking form and manager review panel exist');
check(js.includes('/api/v1/bookings') && js.includes('data-pay-booking'), 'Booking requests connect to invoice checkout UI');
check(fs.existsSync(path.join(root,'database/migrations/006_client_bookings.sql')), 'Client booking database migration exists');
check(sql.includes('CREATE TABLE IF NOT EXISTS client_bookings'), 'New database schema includes client bookings');
check(!fs.existsSync(path.join(root,'.env')), 'No private .env file included');
check(!fs.existsSync(path.join(root,'node_modules')), 'No node_modules included');
if (failures.length) {
  console.error(`\n${failures.length} verification failure(s):\n- ${failures.join('\n- ')}`);
  process.exit(1);
}
console.log('\nAll source-level checks passed. This does not replace a live PostgreSQL, PSP, OAuth or Android test.');
