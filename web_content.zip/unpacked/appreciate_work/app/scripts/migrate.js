require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { Pool } = require('pg');
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required.');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: true } : undefined });
(async () => {
  const client = await pool.connect();
  try {
    await client.query(fs.readFileSync(path.join(__dirname,'../database/schema.sql'),'utf8'));
    const dir = path.join(__dirname,'../database/migrations');
    const files = fs.readdirSync(dir).filter(f=>/^\d+.*\.sql$/.test(f)).sort();
    for (const file of files) {
      // The release migrations use idempotent DDL; schema.sql is the canonical fresh-install schema.
      await client.query(fs.readFileSync(path.join(dir,file),'utf8'));
      process.stdout.write(`Applied/verified ${file}\n`);
    }
    process.stdout.write('APPRECIATE database schema ready.\n');
  } finally { client.release(); await pool.end(); }
})().catch(async e=>{ console.error(`APPRECIATE migration failed: ${e.message}`); await pool.end(); process.exit(1); });
