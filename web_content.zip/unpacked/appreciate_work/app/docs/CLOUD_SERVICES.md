# APPRECIATE CLOUD connection

APPRECIATE connects to the independently running APPRECIATE CLOUD control plane using `APPRECIATE_CLOUD_URL` and `APPRECIATE_CLOUD_API_KEY` configured on the APPRECIATE server. The Cloud Services page reports whether the control plane is reachable and links to its owner portal.

APPRECIATE CLOUD v1.3 includes native APPRECIATE CODE repository creation, ZIP source upload, Dockerfile builds, and container deployment. It does not depend on GitLab, Render, Forgejo or Coolify.

The APPRECIATE application project/deployment records are not automatically converted into cloud deployments in this release. Use the APPRECIATE CLOUD portal to create a CODE project, upload source, build and deploy. The in-app project request remains a planning/request record, not proof that a container is running.

This is an owner-operated early release. Customer accounts, tenant isolation, Git push/clone transport, build queues, database provisioning per project, domain/TLS automation, backup/restore, quotas, and independent security testing remain incomplete. Do not expose the owner API key to customers.


## Private service connection

When deployed with the root Docker Compose stack, the APPRECIATE API checks the cloud-control service over the private Docker network using `APPRECIATE_CLOUD_INTERNAL_URL=http://cloud-control:3100`. `APPRECIATE_CLOUD_URL` remains the public HTTPS address used by the owner browser. This prevents the API health check from depending on public DNS or routing back into the same server. The owner API key remains server-side.
