# API overview and smoke-test plan

All application endpoints use `/api/v1`. Authenticated browser calls use the secure session cookie and CSRF token. Native clients may use bearer sessions over HTTPS.

## Core route groups

- Accounts: `POST /auth/register`, `POST /auth/login`, `POST /auth/logout`, `GET /me`, `PATCH /profile`.
- Marketplace: `GET/POST /products`, `GET/POST /orders`, refund request route.
- Payments: `GET /payment-methods`, `POST /payments`, `POST /payments/:reference/capture`, PayPal and bank webhook routes, admin voucher/payout/transaction routes.
- Creator/artist: artist application, dashboard, music release metadata, paid download entitlement check and offline play-event sync.
- Social: connection status and OAuth request placeholder; no external post is published.
- Campaigns/announcements: create and list campaigns, create announcements, management publish queue.
- Corporate/management: enquiries, proposals, proposal responses, agreements, signatures, deliverables, invoices and reports.
- Rights reporting: partner status, artist authorisation request/review, one-off partner request and one-off batch preparation.
- Delivery: shipment create/status, buyer confirmation, disputes and management dispute review.

## Smoke tests after deployment

1. `GET /health` returns `ok: true` and `database: connected`.
2. Register the configured owner email and confirm it becomes admin; sign out and back in.
3. Register a creator and a company account. Confirm each can access only its own records.
4. Create a product, create an order and confirm the server calculates the total from the database.
5. Confirm all bank methods are disabled until a PSP adapter and approvals are installed.
6. Configure PayPal sandbox credentials and a webhook ID; test create, approve, capture, webhook replay and amount/currency mismatch handling.
7. Issue a voucher from the admin account; redeem it once against an order and confirm the balance cannot be reused.
8. Confirm the order is not marked paid from a browser redirect alone.
9. Submit an artist profile; approve it from management; create and sign a management agreement; confirm commission records are created only on verified sales under an active agreement.
10. Submit a company enquiry; send a proposal; accept it from the company account; create an agreement; sign all parties; assign deliverables; submit proof; issue an invoice and report.
11. Confirm social connections remain pending until an official OAuth callback is implemented.
12. Confirm rights partner marks remain grey until agreement, endpoint, artist authorisation and verified connection are active.
13. Prepare a one-off all-partner request and confirm only currently approved/connected/authorised partners are included.
14. Create a paid order shipment; update status; require proof before delivered; confirm as buyer; open and resolve a dispute.
15. Confirm offline music play events sync only for paid entitlements and do not create royalty rows.
16. Test session expiry, logout, CSRF rejection, rate limiting, mobile viewport, Android WebView navigation and HTTPS checkout return.

## Verification boundary

The source archive includes syntax and static consistency checks. This environment did not provide a running PostgreSQL service or installed npm dependencies, so no live database migration, API integration test, merchant sandbox test or Android APK build is claimed.
