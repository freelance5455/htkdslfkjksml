# APPRECIATE payment methods and money flow

## Customer methods requested

- APPRECIATE vouchers
- PayPal
- Capitec
- FNB
- TymeBank
- Standard Bank
- Absa

The API exposes each method in `GET /api/v1/payment-methods`. A method is enabled only when its server-side readiness checks pass. The supplied configuration leaves PayPal and all bank channels disabled. Voucher redemption is also disabled until a real secret and admin policy are configured.

## How money moves

1. APPRECIATE creates an order or an invoice on the server and calculates the amount from database records.
2. The customer chooses an enabled payment method.
3. APPRECIATE creates a pending payment transaction.
4. PayPal or a contracted PSP processes the payment outside the APPRECIATE client.
5. A verified provider webhook or voucher validation marks the payment as paid.
6. The order/invoice and ledger are updated in one database transaction.
7. Artist net sales and management commission records are created from an active signed management agreement.
8. Artist payout records remain queued until an authorised payout operator/provider confirms the transfer.

## PayPal

`server/paypal.js` implements REST token, order creation, capture and webhook signature verification. Use PayPal sandbox first. The live flag must not be enabled until merchant verification, webhook configuration and end-to-end tests are complete.

## South African banks

APPRECIATE does not connect to customers' online-banking credentials. The five bank names are checkout channels through a contracted PSP/aggregator. Implement that provider's official documented API in `integrations/providers/<provider-key>.js`, following `integrations/bank-psp-adapter.template.js`. Do not invent API URLs or payloads. Set `BANK_PROVIDER_ADAPTER_READY=true` and the relevant `PAYMENT_<BANK>_AUTHORISED=true` flags only after the adapter is reviewed and tested.

## Vouchers

An administrator issues a voucher using `POST /api/v1/admin/vouchers`. The code is returned once. The database stores an HMAC hash, not the clear code. This release requires the voucher to cover the full order or invoice amount; partial voucher plus card/bank split tender is not yet implemented.

## Refunds and payouts

A buyer can submit a refund request. The request is a workflow record, not a refund. A real refund requires the payment provider's refund API, verification and reconciliation. Artist payouts are queued records; this package does not send bank transfers.

## Reconciliation

The ledger records verified customer payments, seller net sales, management commissions and invoice payee credits. Reconciliation must compare those records with provider settlement statements, fees, chargebacks, refunds and actual bank settlements before the platform distributes funds.

For a corporate invoice, the verified payment is credited to the designated invoice payee in the ledger. Multi-party sponsorship allocations (for example, artist share, management commission, tax and campaign costs) must be agreed and recorded in a signed allocation schedule before live distribution; this release does not automatically split a sponsorship invoice among multiple parties.


## Client service bookings (v1.37)
Accepted client bookings create an invoice in ZAR and use the same payment method selector as marketplace orders and corporate invoices. A booking remains `accepted_pending_payment` until the invoice is settled by verified voucher validation or a provider-verified payment event; only then does the booking become `confirmed`. A payment method displayed as setup-required cannot be used for live checkout.
