# APPRECIATE deployment on Render

This project serves the customer-facing PWA and `/api/v1` API from the same HTTPS origin. The frontend uses relative API paths, so it does not need a hard-coded localhost address or a second API URL when deployed this way.

## Required owner actions

1. Push the contents of this `app/` folder to a GitHub repository. Do not upload `.env`, passwords, database dumps, or provider secrets.
2. In Render, create a PostgreSQL database. Choose a plan only after checking the current price, storage limit, and expiry policy shown in your account.
3. Copy the database's **Internal Database URL** from Render. Keep it private.
4. In Render, choose **New → Blueprint**, connect the GitHub repository, and select this `render.yaml` file. The web service is configured to build with the included Dockerfile and check `/health`.
5. In the web service environment, set `DATABASE_URL` to the private Internal Database URL from step 3. The blueprint generates `APP_SECRET` and `VOUCHER_CODE_PEPPER`; do not replace them with public values.
6. Deploy. Wait for the deploy to finish, then open `https://YOUR-SERVICE.onrender.com/health`. Continue only when it returns `ok: true` and `database: connected`.
7. Open the service URL on an Android phone. Test account registration, sign-in, sign-out, and the main screens before using the URL in the HTML-to-APK converter.

## Important safeguards

- The PostgreSQL database is a separate Render resource; the web service cannot work until `DATABASE_URL` points to it.
- Review Render's current database pricing and retention/expiry terms before creating it. Do not assume a free database is permanent.
- Keep `.env`, database URLs, APP_SECRET, payment credentials, and partner credentials out of GitHub and out of the APK.
- Do not promote an administrator account until the service is deployed and owner registration has been tested. Use the trusted server shell for `npm run promote-admin -- owner@example.com`.
- The Dockerfile runs the database migration script on container start. Back up any existing production database before deploying schema changes.
- A successful `/health` response is necessary but not sufficient: test registration and login from a separate device/network before distributing the APK.
