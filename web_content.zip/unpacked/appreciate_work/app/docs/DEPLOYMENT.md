# Deployment checklist

## Server
- Node.js 20+ runtime and PostgreSQL 14+.
- Set a private `.env` file from `.env.example`; use unique secrets.
- Apply `database/schema.sql` to a new empty database.
- Run `npm ci` (after creating a lockfile in your deployment workflow) or `npm install`.
- Start with `npm start` under a process manager/container.
- Put Nginx/Caddy or a managed HTTPS reverse proxy in front.
- Set `NODE_ENV=production`, `COOKIE_SECURE=true`, `APP_BASE_URL=https://your-domain`, `CORS_ORIGIN=https://your-domain`.
- Configure database backups, logs, monitoring, alerting and restore tests.

## Owner account
- Register the owner account, then run `npm run promote-admin -- owner@example.com` from a trusted server shell. Public registration never grants administrator privileges.
- Sign out and sign back in after a role change.
- Keep administrator access restricted and use MFA once implemented.

## Database upgrades
- `database/schema.sql` is for a new database. Do not blindly rerun it over a live database.
- Existing v1.32 databases require a backup followed by migrations `004_reporting_ingestion_and_consent_hardening.sql`, `005_external_partner_authorisations.sql`, `006_client_bookings.sql`, `007_cloud_services.sql` and `008_private_evidence_storage.sql` in numeric order.
- For production changes, create reviewed, numbered migrations and take a backup before applying.

- An existing v1.39 database should be backed up and upgraded by applying only `database/migrations/008_private_evidence_storage.sql`.
