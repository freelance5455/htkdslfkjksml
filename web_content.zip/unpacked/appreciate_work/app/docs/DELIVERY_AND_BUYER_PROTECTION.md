# Trusted delivery and buyer protection

The database and API provide the first manual workflow:

- A seller creates a shipment record for a paid order.
- Shipment status can be updated through awaiting dispatch, dispatched, in transit, out for delivery, delivered, failed or returned.
- A shipment cannot be marked delivered without a proof URL or private proof-storage key.
- Buyers can confirm delivery or open a dispute.
- Management can investigate and resolve disputes.
- Shipment events create an auditable timeline.

Automatic courier allocation, live tracking, courier-signed webhooks, proof-image upload and courier settlement still require a contracted courier partner and a private media-storage service. Manual shipment updates must be labelled as manual, not presented as courier-verified tracking.
