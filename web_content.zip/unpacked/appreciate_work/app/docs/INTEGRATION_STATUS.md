# External integration release gates

The directory below is a list of intended integrations, not proof that the providers have approved APPRECIATE.

| Service / channel | Current source status | What is still required |
|---|---|---|
| APPRECIATE vouchers | Internal issue/redeem code exists | Secure secret, admin controls, operational voucher policy, test and reconciliation |
| PayPal | Checkout, capture and webhook verification code exists; disabled by default | PayPal merchant account, sandbox credentials, webhook registration, end-to-end tests, live approval |
| Capitec | Bank channel is represented; no direct bank API integration | Contracted PSP/aggregator supporting the route, provider-specific adapter, merchant onboarding and signed webhook tests |
| FNB | Bank channel is represented; no direct bank API integration | Same PSP/aggregator requirements; confirm supported payment rail and coverage |
| TymeBank | Bank channel is represented; no direct bank API integration | Same PSP/aggregator requirements; confirm supported payment rail and coverage |
| Standard Bank | Bank channel is represented; no direct bank API integration | Same PSP/aggregator requirements; confirm supported payment rail and coverage |
| Absa | Bank channel is represented; no direct bank API integration | Same PSP/aggregator requirements; confirm supported payment rail and coverage |
| YouTube | Provider-specific adapter framework only; no YouTube adapter or approved report feed installed | Google Cloud app, OAuth verification, approved YouTube API scopes and user consent |
| TikTok | Provider-specific adapter framework only; no TikTok adapter or approved report feed installed | TikTok developer app, Content Posting API eligibility/approval and user consent |
| Instagram / Facebook | Provider-specific adapter framework only; no Meta adapter or approved reporting feed installed | Meta developer app, app review, professional account/Page permissions and user consent |
| X, Pinterest, LinkedIn | Connection request/status scaffolding | Each provider's developer access, app review where applicable, API plan/scopes and consent |
| Spotify / Apple Music | Rights/platform directory records and adapter framework only; no royalty-statement adapter installed | Developer registration, supported APIs, approved scopes and applicable agreements |
| SAMRO / SAMPRA / CAPASSO / RISA | Prospective rights/reporting directory and request records | Written provider-authorised data route, consent/mandate, endpoint or secure statement workflow |
| Labels / distributors / publishers / Content ID partners | Prospective directory records | Direct partner agreement and statement delivery route |
| Courier / delivery | Manual shipment and dispute records | Courier contract, API credentials, tracking webhook, proof-of-delivery flow and operational support |
| Private audio/media storage | Schema fields only | Private object storage, malware scanning, upload limits, signed URL service, retention and access tests |

## Bank-channel architecture

Capitec, FNB, TymeBank, Standard Bank and Absa are not interchangeable direct APIs. APPRECIATE should connect to a South African payment service provider or aggregator that contractually supports the desired rails. The customer chooses a supported bank route at checkout; the PSP performs the bank-facing flow. APPRECIATE receives only a hosted checkout URL, provider reference and verified webhook result. APPRECIATE must never collect a bank password, PIN, one-time password or online-banking login.

## Activation rule

A connector may be shown as active only after:
1. A real provider agreement/app approval is documented.
2. The correct merchant/developer credentials are stored server-side.
3. The artist/account owner has authorised the requested scopes.
4. A provider-specific adapter passes a live test and produces provider-issued references plus a response digest.
5. Data ownership, retention and support processes are agreed.
6. The partner-specific one-off request is acknowledged by the provider before it is recorded as submitted.

A browser redirect or a button click is never proof of a completed connection or payment.

## Partner colour state

Partner marks are monochrome by default. The interface removes the grayscale treatment only when the partner agreement is approved, a provider-specific live test has activated the endpoint, and that artist's own authorisation is active. A user clicking “record permission request” does not turn a partner mark to colour.


## Reporting ingestion hardening added in this source revision

- Signed report receiver verifies a per-partner HMAC-SHA256 secret, five-minute timestamp window, unique nonce, partner approval/connection state and payload hash.
- Delivery IDs are idempotent. ISRC attribution requires verified ownership plus active, unrevoked artist consent for that partner; ambiguous and unmatched rows remain outside artist dashboards and are marked for review.
- Paid rows are rejected unless a settlement reference and payment-confirmation timestamp are supplied. The reporting dashboard separates usage, estimates, reported royalties and confirmed paid amounts.
- Artist identity and recording claims have human-review routes; consent is explicit, versioned, hashed and revocable. Private evidence storage must be configured before these submissions can be accepted.
- These are source-level capabilities only. No external provider has supplied an approved feed, credentials, OAuth grant or signed statement agreement, and no real report has been received. Generic HMAC ingestion is not a provider-specific integration.

- Added administrator queue endpoints for pending identity and recording-ownership review, plus a separate artist dashboard response for usage, estimates, reported royalties and settlement-confirmed payments.
- Evidence submission remains blocked until a real private object-storage service is configured; an object key alone is not document verification.

- The `connection_test_reference` field is only an operator-supplied audit reference. It does not itself prove a real partner test, agreement or approval. Activation remains blocked until supporting evidence and an actual test are verified outside this source-only build.


## Partner connector execution gate (9 November 2026)

- A provider can no longer be marked connection-verified by entering a text reference in the administrator form. Manual status changes always clear the verified flag; `active` is not a manually selectable endpoint state.
- A new server-side connection-test route loads only `integrations/providers/rights/<partner-code>.js`. The adapter must expose both a live `testConnection` method and a one-off `requestOneOffReport` method. Activation requires a provider approval reference, provider-issued test reference and SHA-256 digest of the actual provider response. A report request is recorded as submitted only when the provider returns its own request reference and a SHA-256 digest of its acknowledgement.
- One-off request routes now call the installed partner-specific adapter. They record `submitted` only when the adapter returns a provider-issued request reference; otherwise they record `manual_follow_up` or `failed` and state that nothing was sent.
- The adapter directory is empty in this package. These controls prevent false activation; they do not create partner agreements, OAuth approvals, credentials or feeds.


## External artist mandate is separate from APPRECIATE consent (10 November 2026)
A recorded APPRECIATE consent does not prove that a partner has authorised APPRECIATE to access an artist's reports. The v1.35 source adds a second, per-artist/per-partner external authorisation record. v1.40 adds authenticated private evidence upload and a review queue; the record must contain a partner-issued reference and verified private evidence, then be reviewed and marked verified by an administrator. Report dispatch, ingestion matching and dashboard visibility require both current APPRECIATE consent and a current verified external authorisation. This is an evidence workflow only; partner-specific OAuth, portals, signed mandate contracts and data feeds still need real provider implementation and approval.


## APPRECIATE Cloud Services (v1.43)

- The Cloud Services customer workspace is included inside the existing APPRECIATE app. It stores private, owner-scoped project records and deployment requests.
- APPRECIATE CLOUD v1.3 now has native owner-operated CODE repository creation, ZIP source intake, Dockerfile builds and container deployment through its own control-plane API.
- The in-app project/deployment request ledger is not automatically connected to container deployment. Use the separate APPRECIATE CLOUD portal for source upload, build and deploy.
- Customer accounts, tenant isolation, per-project database provisioning, quotas, backups, monitoring, custom domains, SSL automation and hosting billing are not active.
- Git push/clone over SSH or HTTP, build queues, log streaming and deployment rollback are not yet implemented. This release is not a public multi-tenant hosting provider.


## Private evidence storage (v1.40)
An S3-compatible private bucket can be configured using MEDIA_STORAGE_DRIVER=s3, MEDIA_STORAGE_BUCKET, MEDIA_STORAGE_ENDPOINT, MEDIA_STORAGE_REGION, MEDIA_STORAGE_ACCESS_KEY and MEDIA_STORAGE_SECRET_KEY. The bucket must remain private and should have default encryption enabled. Browser uploads go through the authenticated APPRECIATE API, so the bucket does not need public CORS access. The API issues ten-minute upload intents, accepts the file through an authenticated 10 MB-limited upload route, verifies the completed object server-side, and issues 60-second admin viewing URLs. Configure and test the bucket before enabling identity, recording-rights or external-mandate submissions. No storage credentials are included in this package.
