# Rights, usage and royalty reporting

APPRECIATE keeps four data classes separate:

1. **Usage activity** — plays, views or other usage counts supplied by a source.
2. **Estimated amounts** — estimates clearly labelled as estimates.
3. **Official reported royalties** — amounts present in an authorised partner statement or verified feed.
4. **Confirmed payments** — money reconciled to a payment/provider settlement or artist ledger.

The database contains a prospective reporting-partner directory, artist consent/authorisation records, recording metadata, partner report delivery records, usage/royalty rows, one-off reporting request records and audit events.

The `POST /api/v1/partners/:code/request` endpoint prepares an individual request. The one-off `POST /api/v1/partners/requests/all` endpoint prepares a batch for every partner that is approved, connected and artist-authorised. These endpoints do not dispatch requests or retrieve reports until the relevant partner adapters and approved data routes exist. They do not log into private portals or scrape data. Partner-specific adapters and authorised data routes must be implemented after written approval. Secure manual statements may be entered only by an authorised operator with evidence and audit history.

If no authorised statement has arrived, the dashboard must display **Awaiting authorised report** rather than a fabricated zero. Offline music play-event sync is only a device usage log; it does not automatically generate streaming royalties.


## Signed partner delivery contract (source implementation)

The generic receiver is `POST /api/v1/partners/{partner_code}/reports`. It accepts only partners whose agreement is approved, endpoint is active, connection is verified and a connection-test reference is recorded. The server requires a distinct 32+ byte secret in `PARTNER_WEBHOOK_SECRET_<PARTNER_CODE>` and headers:

- `X-APPRECIATE-Timestamp`: Unix seconds, within five minutes of server time.
- `X-APPRECIATE-Signature`: `sha256=<hex HMAC-SHA256>` over `<timestamp>.<raw HTTP request body>`.
- `X-APPRECIATE-Nonce`: unique 16–120 character nonce for each delivery attempt.

The JSON body contains `deliveryId`, `periodStart`, `periodEnd`, `currency`, and `rows`. Each row contains a valid ISRC, `usageType`, optional usage and amount fields, and an `amountStatus`. A `paid` row must include both `settlementReference` and `paymentConfirmedAt`. Duplicate nonces are rejected; duplicate partner delivery IDs are idempotently acknowledged. The receiver stores a SHA-256 body hash and an audit event, and only attributes rows when one unique artist has a verified ISRC claim and active, unrevoked consent for that partner.

This is a generic secure ingestion contract, not an actual YouTube, Spotify, TikTok, Meta, SAMRO, SAMPRA, label or publisher adapter. No provider-specific payload mapping or live endpoint is approved in this package. Partner must agree to this contract or an adapter must be built to the provider's documented format before any real feed can work.


## Two distinct artist permissions (v1.35)
1. APPRECIATE consent: the artist authorises APPRECIATE to act on their behalf for the named partner and selected reporting scopes. It is versioned and revocable inside APPRECIATE.
2. External partner authorisation: the artist separately obtains the partner's required OAuth grant, portal mandate or signed authorisation. APPRECIATE records the partner-issued reference and private evidence, then requires human review before it is treated as verified.

Neither permission substitutes for the other. A report request, report-row attribution and dashboard visibility require both permissions to be current, plus verified identity/recording ownership and an approved live partner connection. The current source has no external partner grants or feeds configured. Private evidence upload/storage is also not included; a storage object must be supplied through an approved private storage process before review.
