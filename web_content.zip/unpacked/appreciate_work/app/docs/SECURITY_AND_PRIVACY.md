# Security and privacy controls

## Included source controls

- Passwords are hashed with bcrypt (12 rounds); plaintext passwords are never stored.
- Authentication sessions are stored server-side and checked on authenticated API requests.
- Browser session cookies are HttpOnly, SameSite=Lax and Secure in production.
- Browser mutations require a CSRF token; mobile clients can use bearer sessions over HTTPS.
- Auth and payment routes are rate limited.
- Helmet security headers and a same-origin Content Security Policy are configured.
- SQL is parameterised through `pg` query parameters.
- Management/admin endpoints use server-side role checks.
- Payment status is changed only by internal voucher validation or verified provider events.
- Voucher codes are HMAC-hashed with a separate server secret.
- Provider credentials are environment variables and are never served to the browser.

## Required before public launch

- Replace all example secrets; use a secret manager, not a committed `.env` file.
- Use HTTPS only, secure cookies, a restrictive reverse proxy and firewall.
- Configure database least privilege, encrypted backups, restore tests, audit retention and monitoring.
- Add email verification, password reset, MFA, account recovery and abuse monitoring.
- Add POPIA review, privacy notice, consent records, data access/deletion processes, retention policy and operator agreements.
- Add penetration testing, dependency scanning, upload malware scanning, secure private media storage and incident response.
- Review electronic-signature, consumer protection, payment services, tax, AML/KYC and marketplace obligations with qualified South African advisers.
- Never expose `.env`, database credentials, PayPal secrets, PSP secrets, OAuth refresh tokens or admin controls to an APK or HTML builder.

## Explicit exclusions

This package does not store bank login credentials, card PAN/CVV, PayPal passwords or OAuth tokens in the client. It does not claim to be a bank, payment institution, licensed PSP or royalty collecting society.


## Private artist evidence uploads (v1.40)

The artist uploads identity, recording-rights or external partner-mandate evidence through the authenticated APPRECIATE API. The server enforces a 10 MB body limit, exact expected size, a PDF/JPEG/PNG allowlist and a generated private object key, then signs the S3-compatible PUT request server-side. The client never receives storage credentials or a bucket URL. The completion endpoint checks the stored object with a signed HEAD request. An upload can be attached once to the matching evidence workflow. Administrator viewing uses a 60-second signed GET URL and is recorded in the audit log.

Configure `MEDIA_STORAGE_DRIVER=s3`, `MEDIA_STORAGE_BUCKET`, `MEDIA_STORAGE_ENDPOINT`, `MEDIA_STORAGE_REGION`, `MEDIA_STORAGE_ACCESS_KEY` and `MEDIA_STORAGE_SECRET_KEY`. Keep the bucket private and enable default encryption. Do not enable evidence submissions until a live upload, HEAD verification, administrator view, object-retention and access-control test has passed. The application does not scan uploaded files for malware; that remains a production deployment requirement.
