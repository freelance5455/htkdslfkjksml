# Corporate sponsorship and partnership workflow

1. A company registers a company account and submits an enquiry with a subject, brief, target artist (optional) and indicative budget.
2. Appreciate Absalom Artist Development and Management reviews the enquiry.
3. Management creates and sends a proposal with value, scope, fees, terms and expiry.
4. The company accepts or rejects the proposal in its portal.
5. Management creates an agreement from an accepted proposal.
6. Required parties record in-app acceptance. The agreement becomes active only after all required parties sign in the workflow.
7. Management assigns deliverables, owners and due dates.
8. The responsible party submits proof; management or the company reviews and accepts/rejects it.
9. Management issues an invoice against the agreement. Payment remains pending until a payment provider verifies it.
10. Management issues a report with period, deliverables and campaign evidence.

The in-app signature is an acceptance record, not a qualified electronic-signature service or legal advice. Use a qualified signing provider and lawyer-reviewed agreement templates for binding commercial contracts.
