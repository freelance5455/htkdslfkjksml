# Android / HTML-to-APK wrapper

This project has one app HTML entry point: `public/index.html`. The intended Android route is to host the PWA over HTTPS, then point the HTML-to-APK/WebView builder at the hosted app URL.

## Required sequence

1. Deploy the Node API and PostgreSQL database on a trusted HTTPS host.
2. Confirm `/health`, account registration/login, order creation and the enabled payment methods from a real device.
3. Configure the PWA start URL and scope to the deployed domain.
4. In the HTML-to-APK builder, use the HTTPS app URL; do not upload `.env`, Node server code or provider secrets.
5. Enable JavaScript and DOM storage only for the trusted app origin. Restrict navigation to the app domain and approved payment-provider checkout domains.
6. Allow external provider checkout through a secure browser/custom tab; return to the APPRECIATE HTTPS callback.
7. Build a signed release APK and test install, login, session expiry, network loss, checkout return, downloads and logout.

## Important

- The PWA shell may cache for offline opening, but backend features require an internet connection.
- A wrapper does not create a backend, database, payment gateway, OAuth approval or media storage.
- Never embed secrets, database URLs or admin keys in the APK.
- Do not enable broad file access or arbitrary URL navigation in the WebView.
