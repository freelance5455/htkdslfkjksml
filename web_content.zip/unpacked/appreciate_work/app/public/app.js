const $ = (id) => document.getElementById(id);
const BANK_METHODS = new Set(['capitec','fnb','tymebank','standard_bank','absa']);
const CHANNELS = [
  ['youtube','YouTube','▶'],['tiktok','TikTok','♪'],['instagram','Instagram','◎'],['facebook','Facebook','f'],
  ['x','X','𝕏'],['pinterest','Pinterest','P'],['linkedin','LinkedIn','in'],['whatsapp','WhatsApp','◉'],['telegram','Telegram','➤']
];
const PARTNER_MARKS = {youtube:'▶',youtube_content_id_partner:'▶',spotify:'●',music_distributor:'♫',tiktok:'♪',meta:'∞',record_label:'▰',music_publisher:'✦',samro:'S',sampra:'S',capasso:'C',risa:'R',apple_music:'♪'};
let currentUser = null;
let productCache = [];
let paymentMethods = [];
let authMode = 'login';
let pendingPaymentTarget = null;

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
function money(minor, currency = 'ZAR') {
  const amount = Number(minor || 0) / 100;
  try { return new Intl.NumberFormat('en-ZA', { style:'currency', currency }).format(amount); }
  catch { return `${currency} ${amount.toFixed(2)}`; }
}
function toast(message) {
  const element = $('toast');
  element.textContent = message;
  element.style.display = 'block';
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { element.style.display = 'none'; }, 3200);
}
function csrfToken() {
  const match = document.cookie.match(/(?:^|; )ap_csrf=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : '';
}
async function api(url, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  const headers = { ...(options.headers || {}) };
  if (options.body && typeof options.body !== 'string') {
    headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(options.body);
  }
  if (!['GET','HEAD','OPTIONS'].includes(method) && csrfToken()) headers['x-csrf-token'] = csrfToken();
  const response = await fetch(url, { ...options, method, headers, credentials:'include' });
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text || 'Unexpected server response.' }; }
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status}).`);
  return data;
}
function show(view) {
  document.querySelectorAll('.view').forEach((section) => section.classList.toggle('active', section.id === view));
  document.querySelectorAll('.nav').forEach((button) => button.classList.toggle('active', button.dataset.view === view));
  window.scrollTo({ top:0, behavior:'smooth' });
  const loaders = {
    discover: loadDiscover, studio: loadCampaigns, marketplace: loadMarketplace, artist: loadArtist,
    management: loadManagement, corporate: loadCorporate, cloud: loadCloudProjects, announcements: loadAnnouncements,
    rights: loadRights, payments: loadPayments, bookings: loadBookings, account: loadAccount, ai: loadAiStatus
  };
  if (loaders[view]) loaders[view]();
}
document.querySelectorAll('.nav').forEach((button) => button.addEventListener('click', () => show(button.dataset.view)));

// Discover category tabs filter the editorial entry points without fabricating
// user posts, views, likes or creator activity.
document.querySelectorAll('[data-feed-filter]').forEach((button) => {
  button.addEventListener('click', () => {
    const category = button.dataset.feedFilter;
    document.querySelectorAll('[data-feed-filter]').forEach((tab) => {
      const active = tab === button;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-pressed', String(active));
    });
    let visible = 0;
    document.querySelectorAll('[data-feed-category]').forEach((card) => {
      const showCard = category === 'all' || card.dataset.feedCategory === category;
      card.hidden = !showCard;
      if (showCard) visible += 1;
    });
    $('feedEmpty').hidden = visible !== 0;
  });
});
document.querySelectorAll('[data-open]').forEach((button) => button.addEventListener('click', () => show(button.dataset.open)));
document.querySelectorAll('[data-close]').forEach((button) => button.addEventListener('click', () => $(button.dataset.close).close()));

function openAuth(mode = 'login', accountType = 'member') {
  authMode = mode;
  $('authTitle').textContent = mode === 'register' ? 'Create your account' : 'Sign in';
  $('authSubmit').textContent = mode === 'register' ? 'Create account' : 'Sign in';
  $('registerNameWrap').hidden = mode !== 'register';
  $('registerTypeWrap').hidden = mode !== 'register';
  $('registerType').value = accountType;
  $('authPassword').autocomplete = mode === 'register' ? 'new-password' : 'current-password';
  $('toggleAuth').textContent = mode === 'register' ? 'I already have an account' : 'Create a new account';
  $('authDialog').showModal();
}
$('authButton').addEventListener('click', () => openAuth('login'));
$('avatarButton').addEventListener('click', () => show('account'));
$('toggleAuth').addEventListener('click', () => openAuth(authMode === 'register' ? 'login' : 'register'));
$('authForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const body = { email:$('authEmail').value.trim(), password:$('authPassword').value };
  if (authMode === 'register') {
    body.displayName = $('registerName').value.trim();
    body.accountType = $('registerType').value;
  }
  try {
    const result = await api(`/api/v1/auth/${authMode}`, { method:'POST', body });
    currentUser = result.user;
    $('authDialog').close();
    $('authPassword').value = '';
    updateHeader();
    toast(authMode === 'register' ? 'Account created. Welcome to APPRECIATE.' : 'You are signed in.');
    await loadAccount();
    await loadMarketplace();
  } catch (error) { toast(error.message); }
});
function updateHeader() {
  $('userLabel').textContent = currentUser ? `${currentUser.display_name || currentUser.displayName || currentUser.email} · ${currentUser.account_type || currentUser.accountType}` : 'Guest workspace';
  $('authButton').textContent = currentUser ? 'Signed in' : 'Sign in / Register';
  $('avatarButton').textContent = currentUser ? String(currentUser.display_name || currentUser.displayName || currentUser.email || 'A').trim().charAt(0).toUpperCase() : 'A';
  $('workspaceStatus').textContent = currentUser ? 'Account connected' : 'Guest workspace';
}
async function loadMe() {
  try {
    const result = await api('/api/v1/me');
    currentUser = result.user;
  } catch { currentUser = null; }
  updateHeader();
}

async function loadDiscover() {
  try {
    const [products, announcements] = await Promise.all([api('/api/v1/products'), api('/api/v1/announcements')]);
    $('metricProducts').textContent = products.products.length;
    $('discoverAnnouncements').innerHTML = announcements.announcements.length
      ? announcements.announcements.slice(0,3).map(renderAnnouncementCard).join('')
      : '<div class="empty-state">No public announcements have been published yet.</div>';
    if (currentUser) {
      const [campaigns, agreements] = await Promise.all([api('/api/v1/campaigns'), api('/api/v1/agreements')]);
      $('metricCampaigns').textContent = campaigns.campaigns.length;
      $('metricAgreements').textContent = agreements.agreements.filter((x) => x.status !== 'completed' && x.status !== 'terminated').length;
      $('metricEarnings').textContent = 'Open dashboard';
    } else {
      $('metricCampaigns').textContent = '—'; $('metricAgreements').textContent = '—'; $('metricEarnings').textContent = 'Sign in';
    }
  } catch (error) { toast(error.message); }
}
function renderAnnouncementCard(item) {
  return `<article class="announcement-card"><small>${escapeHtml(item.author || 'APPRECIATE')} · ${new Date(item.publish_at || item.created_at).toLocaleDateString()}</small><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.body)}</p></article>`;
}
async function loadAnnouncements() {
  try {
    const result = await api('/api/v1/announcements');
    $('announcementList').innerHTML = result.announcements.length ? result.announcements.map(renderAnnouncementCard).join('') : '<div class="empty-state">No published announcements.</div>';
  } catch (error) { $('announcementList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
  if (currentUser && ['manager','admin'].includes(currentUser.account_type)) {
    $('announcementManagementPanel').hidden = false;
    try {
      const queue = await api('/api/v1/management/announcements');
      $('announcementDraftList').innerHTML = queue.announcements.map((item) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(item.title)}</h3><small>${escapeHtml(item.author)} · ${escapeHtml(item.audience)}</small></div><span class="status-pill">${escapeHtml(item.status)}</span></div><p>${escapeHtml(item.body)}</p>${item.status==='draft' ? `<div class="item-actions"><button class="small-button dark" data-publish-announcement="${item.id}">Publish in APPRECIATE</button></div>` : ''}</article>`).join('') || '<div class="empty-state">No announcement drafts.</div>';
    } catch (error) { $('announcementDraftList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
  } else { $('announcementManagementPanel').hidden = true; }
}
$('announcementDraftList').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-publish-announcement]');
  if (!button) return;
  try { const result = await api(`/api/v1/announcements/${button.dataset.publishAnnouncement}/publish`, { method:'POST', body:{} }); toast(result.message); loadAnnouncements(); }
  catch (error) { toast(error.message); }
});
$('refreshAnnouncements').addEventListener('click', loadAnnouncements);
$('announcementForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api('/api/v1/announcements', { method:'POST', body:{ title:$('announcementTitle').value, body:$('announcementBody').value, audience:$('announcementAudience').value } });
    $('announcementForm').reset();
    toast(result.announcement.status === 'draft' ? 'Announcement saved as a draft.' : 'Announcement saved.');
    loadAnnouncements();
  } catch (error) { toast(error.message); }
});

function renderDestinationChecks() {
  $('destinationChecks').innerHTML = CHANNELS.map(([id,name,mark]) => `<label class="check-option"><input type="checkbox" value="${id}"> ${mark} ${name}</label>`).join('');
}
$('campaignForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const destinations = [...document.querySelectorAll('#destinationChecks input:checked')].map((input) => input.value);
  try {
    const result = await api('/api/v1/campaigns', { method:'POST', body:{ title:$('campaignTitle').value, caption:$('campaignCaption').value, productId:$('campaignProduct').value || null, destinations } });
    $('campaignForm').reset();
    toast(result.message || 'Campaign saved.');
    loadCampaigns();
  } catch (error) { toast(error.message); }
});
async function loadCreatorDashboard() {
  if (!currentUser) {
    $('creatorProducts').textContent='—'; $('creatorCampaigns').textContent='—'; $('creatorOrders').textContent='—'; $('creatorEarnings').textContent='Sign in';
    return;
  }
  try {
    const result = await api('/api/v1/creator/dashboard');
    $('creatorProducts').textContent = result.products;
    $('creatorCampaigns').textContent = result.campaigns;
    $('creatorOrders').textContent = result.paidOrders;
    $('creatorEarnings').textContent = money(result.ledgerMinor,'ZAR');
  } catch (error) { $('creatorEarnings').textContent = error.message; }
}

async function loadChannels() {
  if (!currentUser) { $('channelList').innerHTML = '<div class="empty-state">Sign in to request a social account connection.</div>'; return; }
  try {
    const result = await api('/api/v1/social/connections');
    const statusByPlatform = new Map(result.connections.map((item) => [item.platform,item.status]));
    $('channelList').innerHTML = CHANNELS.map(([id,name,mark]) => {
      const status = statusByPlatform.get(id) || 'not_connected';
      const connected = status === 'connected';
      return `<article class="partner-card ${connected?'active':''}"><div class="partner-mark">${mark}</div><div><h3>${escapeHtml(name)}</h3><p>${escapeHtml(status.replaceAll('_',' '))}</p><button class="small-button" data-connect-channel="${id}">${status==='not_connected'?'Request connection':'View status'}</button></div></article>`;
    }).join('');
  } catch (error) { $('channelList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
$('channelList').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-connect-channel]');
  if (!button) return;
  try {
    const result = await api(`/api/v1/social/connections/${button.dataset.connectChannel}/start`, { method:'POST', body:{} });
    toast(result.message);
    loadChannels();
  } catch (error) { toast(error.message); }
});

async function loadCampaigns() {
  loadChannels();
  loadCreatorDashboard();
  try {
    const result = await api('/api/v1/campaigns');
    $('campaignList').innerHTML = result.campaigns.length ? result.campaigns.map((campaign) => {
      const destinations = Array.isArray(campaign.destinations) ? campaign.destinations : [];
      return `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(campaign.title)}</h3><small>${new Date(campaign.created_at).toLocaleString()}</small></div><span class="status-pill">${escapeHtml(campaign.status)}</span></div><p>${escapeHtml(campaign.caption)}</p><p>${destinations.map((x) => `${escapeHtml(x.platform)}: ${escapeHtml(x.status)}`).join(' · ') || 'No destinations selected'}</p><small>Publishing has not been confirmed by an external platform.</small></article>`;
    }).join('') : '<div class="empty-state">No campaigns saved yet.</div>';
  } catch (error) { $('campaignList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}. Sign in to save campaigns.</div>`; }
  try {
    const products = await api('/api/v1/products');
    $('campaignProduct').innerHTML = '<option value="">No product attached</option>' + products.products.map((p) => `<option value="${p.id}">${escapeHtml(p.title)}</option>`).join('');
  } catch { /* guest can still draft only after sign-in */ }
}

async function loadMarketplace() {
  try {
    const result = await api('/api/v1/products');
    productCache = result.products;
    renderProducts(productCache);
    $('metricProducts').textContent = productCache.length;
    await loadOrders();
  } catch (error) { $('productList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
function renderProducts(products) {
  $('productList').innerHTML = products.length ? products.map((product) => `
    <article class="product-card" data-product-card="${product.id}">
      <div class="product-art">${product.kind === 'music' ? '♫' : product.kind === 'service' ? '✦' : '▦'}</div>
      <div class="product-content"><small>${escapeHtml(product.category)} · ${escapeHtml(product.kind)}</small><h3>${escapeHtml(product.title)}</h3><p>${escapeHtml(product.description)}</p><div class="price">${money(product.price_minor, product.currency)}</div><button class="button button-primary" data-buy="${product.id}">Buy / request checkout</button></div>
    </article>`).join('') : '<div class="empty-state">No published listings are available yet.</div>';
}
$('globalSearch').addEventListener('input', () => {
  const term = $('globalSearch').value.trim().toLowerCase();
  renderProducts(productCache.filter((p) => `${p.title} ${p.description} ${p.category}`.toLowerCase().includes(term)));
});
$('productList').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-buy]');
  if (!button) return;
  if (!currentUser) return openAuth('login');
  try {
    const result = await api('/api/v1/orders', { method:'POST', body:{ items:[{ productId:button.dataset.buy, quantity:1 }] } });
    openPaymentDialog({ orderId:result.order.id });
  } catch (error) { toast(error.message); }
});
$('productForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api('/api/v1/products', { method:'POST', body:{
      title:$('productTitle').value, kind:$('productKind').value, category:$('productCategory').value,
      price:$('productPrice').value, stockQuantity:$('productStock').value, description:$('productDescription').value
    } });
    $('productForm').reset();
    toast(`Listing saved: ${result.product.title}`);
    loadMarketplace();
  } catch (error) { toast(error.message); }
});
$('refreshProducts').addEventListener('click', loadMarketplace);
$('refreshOrders').addEventListener('click', loadOrders);
async function loadOrders() {
  if (!currentUser) { $('orderList').innerHTML = '<div class="empty-state">Sign in to view your orders.</div>'; return; }
  try {
    const result = await api('/api/v1/orders');
    $('orderList').innerHTML = result.orders.length ? result.orders.map((order) => `
      <article class="stack-item"><div class="item-head"><div><h3>Order ${escapeHtml(order.id.slice(0,8))}</h3><small>${new Date(order.created_at).toLocaleString()}</small></div><span class="status-pill ${order.state === 'paid' || order.state === 'fulfilled' ? 'good' : 'pending'}">${escapeHtml(order.state)}</span></div>
      <p>${(order.items || []).map((x) => `${escapeHtml(x.title)} × ${x.quantity}`).join(' · ')}</p><b>${money(order.total_minor, order.currency)}</b>
      ${order.state === 'pending' ? `<div class="item-actions"><button class="small-button dark" data-pay-order="${order.id}">Pay now</button></div>` : ''}
      ${['paid','fulfilled'].includes(order.state) ? `<div class="item-actions"><button class="small-button" data-refund-order="${order.id}">Request refund</button><button class="small-button" data-shipment-view="${order.id}">View delivery</button>${order.items.some((item) => item.sellerId === currentUser.id) ? `<button class="small-button dark" data-shipment-create="${order.id}">Create shipment</button>` : ''}</div><div id="shipments-${order.id}" class="stack-list"></div>` : ''}</article>`).join('') : '<div class="empty-state">No orders yet.</div>';
  } catch (error) { $('orderList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
$('orderList').addEventListener('click', async (event) => {
  const pay = event.target.closest('[data-pay-order]');
  const refund = event.target.closest('[data-refund-order]');
  const shipmentView = event.target.closest('[data-shipment-view]');
  const shipmentCreate = event.target.closest('[data-shipment-create]');
  const shipmentConfirm = event.target.closest('[data-shipment-confirm]');
  const shipmentDispute = event.target.closest('[data-shipment-dispute]');
  const shipmentStatus = event.target.closest('[data-shipment-status]');
  if (pay) openPaymentDialog({ orderId:pay.dataset.payOrder });
  if (refund) {
    const reason = window.prompt('Why are you requesting a refund?');
    if (!reason) return;
    try { await api(`/api/v1/orders/${refund.dataset.refundOrder}/refund-request`, { method:'POST', body:{ reason } }); toast('Refund request recorded. It is not yet a provider-issued refund.'); }
    catch (error) { toast(error.message); }
  }
  if (shipmentView) loadShipments(shipmentView.dataset.shipmentView);
  if (shipmentCreate) {
    const courierProvider = window.prompt('Courier/provider name (optional):') || '';
    const trackingUrl = window.prompt('Tracking URL (optional):') || '';
    try { const result = await api(`/api/v1/orders/${shipmentCreate.dataset.shipmentCreate}/shipments`, { method:'POST', body:{ courierProvider, trackingUrl } }); toast(result.message); loadShipments(shipmentCreate.dataset.shipmentCreate); }
    catch (error) { toast(error.message); }
  }
  if (shipmentConfirm) {
    try { await api(`/api/v1/shipments/${shipmentConfirm.dataset.shipmentConfirm}/confirm`, { method:'POST', body:{} }); toast('Delivery confirmed.'); loadOrders(); }
    catch (error) { toast(error.message); }
  }
  if (shipmentDispute) {
    const reason = window.prompt('Describe the delivery problem:');
    if (!reason) return;
    try { await api(`/api/v1/shipments/${shipmentDispute.dataset.shipmentDispute}/dispute`, { method:'POST', body:{ reason } }); toast('Delivery dispute opened.'); loadOrders(); }
    catch (error) { toast(error.message); }
  }
  if (shipmentStatus) {
    const status = window.prompt('Enter status: dispatched, in_transit, out_for_delivery, delivered, failed or returned');
    if (!status) return;
    const proofUrl = status === 'delivered' ? (window.prompt('Proof-of-delivery URL (required):') || '') : '';
    try { await api(`/api/v1/shipments/${shipmentStatus.dataset.shipmentStatus}/status`, { method:'PATCH', body:{ status, proofUrl } }); toast('Shipment status saved.'); loadOrders(); }
    catch (error) { toast(error.message); }
  }
});

async function loadShipments(orderId) {
  const host = $(`shipments-${orderId}`);
  if (!host) return;
  try {
    const result = await api(`/api/v1/orders/${orderId}/shipments`);
    host.innerHTML = result.shipments.length ? result.shipments.map((shipment) => `<article class="stack-item"><div class="item-head"><div><h3>Delivery ${escapeHtml(shipment.id.slice(0,8))}</h3><small>${escapeHtml(shipment.courier_provider || 'Manual fulfilment')} · ${escapeHtml(shipment.tracking_url || 'No tracking link')}</small></div><span class="status-pill">${escapeHtml(shipment.status)}</span></div><p>${(shipment.events || []).map((e) => `${escapeHtml(e.status)} — ${escapeHtml(e.note || e.source)}`).join('<br>')}</p>${shipment.buyer_id === currentUser.id && shipment.status === 'delivered' && !shipment.buyer_confirmed_at ? `<div class="item-actions"><button class="small-button dark" data-shipment-confirm="${shipment.id}">Confirm delivery</button><button class="small-button" data-shipment-dispute="${shipment.id}">Open dispute</button></div>` : ''}${shipment.seller_id === currentUser.id && shipment.status !== 'delivered' ? `<div class="item-actions"><button class="small-button" data-shipment-status="${shipment.id}">Update status</button></div>` : ''}</article>`).join('') : '<div class="empty-state">No shipment record yet. The seller can create one after payment.</div>';
  } catch (error) { host.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}

$('artistApplyForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api('/api/v1/artist/apply', { method:'POST', body:{ stageName:$('stageName').value, genre:$('artistGenre').value, biography:$('artistBio').value } });
    toast(result.message || 'Artist profile submitted.');
    loadArtist();
  } catch (error) { toast(error.message); }
});
async function uploadReleaseAudio(releaseId, file, status) {
  if (!file) return false;
  if (file.size < 1 || file.size > 50 * 1024 * 1024) throw new Error('Audio must be smaller than 50 MB.');
  status.hidden = false; status.textContent = 'Preparing secure upload…';
  const intent = await api(`/api/v1/music/releases/${encodeURIComponent(releaseId)}/audio-upload`, {method:'POST',body:{fileName:file.name,contentType:file.type || 'application/octet-stream',sizeBytes:file.size}});
  status.textContent = 'Uploading your music securely…';
  const put = await fetch(intent.uploadUrl,{method:'PUT',headers:intent.headers,body:file});
  if (!put.ok) throw new Error(`Storage upload failed (${put.status}). Check the private media storage setup and try again.`);
  const verified = await api(`/api/v1/music/releases/${encodeURIComponent(releaseId)}/audio-upload/complete`,{method:'POST',body:{objectKey:intent.objectKey}});
  status.textContent = verified.message || 'Audio uploaded and verified. Your player is below.';
  return true;
}

$('musicReleaseForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const status = $('audioUploadStatus');
  const file = $('releaseAudioFile').files[0];
  status.hidden = false; status.textContent = 'Saving your release…';
  try {
    const result = await api('/api/v1/music/releases', { method:'POST', body:{
      title:$('releaseTitle').value, artistDisplayName:$('releaseArtistName').value,
      price:$('releasePrice').value, isrc:$('releaseIsrc').value, upc:$('releaseUpc').value,
      ownershipDeclaration:$('releaseDeclaration').value, rightsConfirmed:$('releaseRightsConfirmed').checked
    } });
    if (file) {
      await uploadReleaseAudio(result.release.id, file, status);
      status.textContent += ' Open My uploaded tracks and press Play.';
    } else {
      status.textContent = `${result.message} Release saved. Add an audio file next time to upload it.`;
    }
    $('musicReleaseForm').reset();
    toast(file ? 'Release saved. Audio upload finished.' : 'Release saved.');
    loadMarketplace(); loadMyMusic();
  } catch (error) { status.textContent = error.message; toast(error.message); }
});

$('refreshMyMusic').addEventListener('click', loadMyMusic);
async function loadMyMusic() {
  if (!currentUser) { $('myMusicTracks').innerHTML='<div class="empty-state">Sign in to view your uploaded tracks.</div>'; return; }
  try {
    const result = await api('/api/v1/music/my-releases');
    $('myMusicTracks').innerHTML = result.releases.length ? result.releases.map((track) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(track.title)}</h3><small>${escapeHtml(track.artist_display_name)} · ${track.audio_storage_key ? 'Audio uploaded' : 'Audio not uploaded'}</small></div><span class="status-pill">${track.rights_confirmed ? 'Rights declared' : 'Draft'}</span></div>${track.audio_storage_key ? `<audio controls preload="none" src="/api/v1/music/${encodeURIComponent(track.id)}/play" style="width:100%"></audio>` : '<p class="helper">Save the release ID above and upload its audio file.</p>'}</article>`).join('') : '<div class="empty-state">No releases yet. Save a release above to begin.</div>';
  } catch (error) { $('myMusicTracks').innerHTML=`<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}

async function loadArtist() {
  if (!currentUser) { $('royaltyNotice').textContent = 'Sign in to submit an artist profile and view your dashboard.'; $('artistOrders').textContent='—'; $('artistGross').textContent='—'; $('artistLedger').textContent='—'; $('artistPayouts').textContent='—'; $('artistAgreements').innerHTML='<div class="empty-state">Sign in to view agreements.</div>'; return; }
  try {
    const result = await api('/api/v1/artist/dashboard');
    loadMyMusic();
    $('artistOrders').textContent = result.sales.order_count;
    $('artistGross').textContent = money(result.sales.gross_sales_minor, 'ZAR');
    $('artistLedger').textContent = money(result.ledger.ledger_total_minor, 'ZAR');
    $('artistPayouts').textContent = money(result.queuedPayoutMinor, 'ZAR');
    $('royaltyNotice').textContent = result.royaltyStatus;
    try {
      const reporting = await api('/api/v1/artists/me/reporting/dashboard');
      const totalUsage = reporting.usage.reduce((sum, row) => sum + Number(row.usage_count || 0), 0);
      const moneySummary = (rows) => rows.length ? rows.map((row) => money(row.amount_minor, row.currency)).join(' · ') : '—';
      $('royaltyUsage').textContent = totalUsage.toLocaleString();
      $('royaltyEstimated').textContent = moneySummary(reporting.estimates);
      $('royaltyReported').textContent = moneySummary(reporting.reportedRoyalties);
      $('royaltyConfirmedPaid').textContent = moneySummary(reporting.confirmedPaid);
      $('royaltyNotice').textContent = reporting.status;
    } catch (reportError) {
      $('royaltyUsage').textContent = '—'; $('royaltyEstimated').textContent = '—'; $('royaltyReported').textContent = '—'; $('royaltyConfirmedPaid').textContent = '—';
    }
    if (result.artistProfile) {
      $('stageName').value = result.artistProfile.stage_name;
      $('artistGenre').value = result.artistProfile.genre || '';
      $('artistBio').value = result.artistProfile.biography || '';
      $('royaltyNotice').textContent += ` · Artist application: ${result.artistProfile.status}.`;
    }
    const agreements = await api('/api/v1/agreements');
    $('artistAgreements').innerHTML = agreements.agreements.length ? agreements.agreements.map(renderAgreement).join('') : '<div class="empty-state">No agreements linked to this account.</div>';
  } catch (error) { $('royaltyNotice').textContent = error.message; }
}
$('refreshAgreements').addEventListener('click', loadArtist);
function renderAgreement(agreement) {
  return `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(agreement.reference)} · ${escapeHtml(agreement.agreement_type)}</h3><small>${new Date(agreement.created_at).toLocaleDateString()}</small></div><span class="status-pill">${escapeHtml(agreement.status)}</span></div><p>${escapeHtml(agreement.terms).slice(0,220)}</p><div class="item-actions"><button class="small-button" data-sign-agreement="${agreement.id}">Sign / accept</button><button class="small-button" data-view-deliverables="${agreement.id}">Deliverables</button></div><div class="deliverable-slot" id="deliverables-${agreement.id}"></div></article>`;
}
$('artistAgreements').addEventListener('click', agreementActions);
$('managementAgreements').addEventListener('click', agreementActions);
async function agreementActions(event) {
  const sign = event.target.closest('[data-sign-agreement]');
  const view = event.target.closest('[data-view-deliverables]');
  if (sign) {
    const name = window.prompt('Type the full name of the authorised signer:');
    if (!name) return;
    try { const result = await api(`/api/v1/agreements/${sign.dataset.signAgreement}/sign`, { method:'POST', body:{ signatureName:name } }); toast(`Agreement status: ${result.status}.`); loadArtist(); loadManagement(); }
    catch (error) { toast(error.message); }
  }
  if (view) {
    try {
      const result = await api(`/api/v1/agreements/${view.dataset.viewDeliverables}/deliverables`);
      const slot = $(`deliverables-${view.dataset.viewDeliverables}`);
      slot.innerHTML = result.deliverables.length ? result.deliverables.map((d) => `<p class="muted-line">${escapeHtml(d.title)} · ${escapeHtml(d.status)} · due ${escapeHtml(d.due_at || 'not set')}</p>`).join('') : '<p class="muted-line">No deliverables recorded.</p>';
    } catch (error) { toast(error.message); }
  }
}

$('deliverableForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const id = $('deliverableAgreementId').value.trim();
    const result = await api(`/api/v1/management/agreements/${id}/deliverables`, { method:'POST', body:{
      ownerUserId:$('deliverableOwnerId').value.trim(), title:$('deliverableTitle').value,
      description:$('deliverableDescription').value, dueAt:$('deliverableDue').value || null
    } });
    $('deliverableForm').reset(); toast(`Deliverable assigned: ${result.deliverable.title}`); loadManagement();
  } catch (error) { toast(error.message); }
});
$('invoiceForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const id = $('invoiceAgreementId').value.trim();
    const result = await api(`/api/v1/management/agreements/${id}/invoices`, { method:'POST', body:{ amount:$('invoiceAmount').value, description:$('invoiceDescription').value, dueAt:$('invoiceDue').value || null } });
    $('invoiceForm').reset(); toast(`Invoice created: ${result.invoice.reference}`); loadPayments();
  } catch (error) { toast(error.message); }
});
$('agreementReportForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  let reportData = {};
  try { reportData = $('reportData').value.trim() ? JSON.parse($('reportData').value) : {}; }
  catch { return toast('Report data must be valid JSON.'); }
  try {
    await api(`/api/v1/agreements/${$('reportAgreementId').value.trim()}/reports`, { method:'POST', body:{
      reportType:$('reportType').value, periodStart:$('reportStart').value || null,
      periodEnd:$('reportEnd').value || null, reportData
    } });
    $('agreementReportForm').reset(); toast('Agreement report saved.');
  } catch (error) { toast(error.message); }
});

async function loadManagement() {
  if (!currentUser || !['manager','admin'].includes(currentUser.account_type)) {
    $('managementGate').textContent = 'This area is restricted to authorised management and administrator accounts. Sign in with an approved management account to use these workflows.';
    ['managementArtists','managementEnquiries','managementProposals','managementAgreements','managementDisputes'].forEach((id) => $(id).innerHTML = '<div class="empty-state">Management access required.</div>');
    return;
  }
  $('managementGate').textContent = 'Management access verified for this account.';
  $('roleAssignmentForm').hidden = currentUser.account_type !== 'admin';
  try {
    const result = await api('/api/v1/management/overview');
    $('managementArtists').innerHTML = result.artists.length ? result.artists.map((artist) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(artist.stage_name)}</h3><small>${escapeHtml(artist.email)} · ID ${escapeHtml(artist.user_id)}</small></div><span class="status-pill">${escapeHtml(artist.status)}</span></div><p>${escapeHtml(artist.genre || 'Genre not supplied')} · ${escapeHtml(artist.biography || '')}</p>${artist.status === 'pending' ? `<div class="item-actions"><button class="small-button dark" data-approve-artist="${artist.user_id}">Approve artist</button><button class="small-button" data-reject-artist="${artist.user_id}">Reject</button></div>` : ''}</article>`).join('') : '<div class="empty-state">No artist applications.</div>';
    $('managementEnquiries').innerHTML = result.enquiries.length ? result.enquiries.map((enquiry) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(enquiry.subject)}</h3><small>Enquiry ID ${escapeHtml(enquiry.id)} · ${escapeHtml(enquiry.company_name)}</small></div><span class="status-pill">${escapeHtml(enquiry.status)}</span></div><p>${escapeHtml(enquiry.brief)}</p><b>${enquiry.budget_minor ? money(enquiry.budget_minor,enquiry.currency) : 'Budget not supplied'}</b></article>`).join('') : '<div class="empty-state">No corporate enquiries yet.</div>';
    $('managementProposals').innerHTML = result.proposals.length ? result.proposals.map((proposal) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(proposal.subject)} · ${escapeHtml(proposal.id)}</h3><small>${escapeHtml(proposal.company_name)}</small></div><span class="status-pill">${escapeHtml(proposal.status)}</span></div><b>${money(proposal.amount_minor,proposal.currency)}</b><p>${escapeHtml(proposal.terms)}</p></article>`).join('') : '<div class="empty-state">No proposals yet.</div>';
    $('managementAgreements').innerHTML = result.agreements.length ? result.agreements.map(renderAgreement).join('') : '<div class="empty-state">No agreements yet.</div>';
    const disputes = await api('/api/v1/management/delivery-disputes');
    $('managementDisputes').innerHTML = disputes.disputes.length ? disputes.disputes.map((d) => `<article class="stack-item"><div class="item-head"><div><h3>Dispute ${escapeHtml(d.id.slice(0,8))} · Order ${escapeHtml(d.order_id.slice(0,8))}</h3><small>Shipment ${escapeHtml(d.shipment_id.slice(0,8))}</small></div><span class="status-pill">${escapeHtml(d.status)}</span></div><p>${escapeHtml(d.reason)}</p><div class="item-actions"><button class="small-button" data-review-dispute="${d.id}">Review / resolve</button></div></article>`).join('') : '<div class="empty-state">No delivery disputes.</div>';
  } catch (error) { $('managementGate').textContent = error.message; }
}
$('managementDisputes').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-review-dispute]');
  if (!button) return;
  const status = window.prompt('Status: investigating, resolved_buyer, resolved_seller or closed', 'investigating');
  if (!status) return;
  const resolution = window.prompt('Resolution / review notes (optional):') || '';
  try { await api(`/api/v1/management/delivery-disputes/${button.dataset.reviewDispute}`, { method:'PATCH', body:{ status, resolution } }); toast('Delivery dispute updated.'); loadManagement(); }
  catch (error) { toast(error.message); }
});
$('roleAssignmentForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api(`/api/v1/admin/users/${$('roleUserId').value.trim()}/role`, { method:'PATCH', body:{ accountType:$('roleAccountType').value } });
    $('roleAssignmentForm').reset(); toast(result.message);
  } catch (error) { toast(error.message); }
});
$('refreshManagement').addEventListener('click', loadManagement);
$('managementArtists').addEventListener('click', async (event) => {
  const approve = event.target.closest('[data-approve-artist]');
  const reject = event.target.closest('[data-reject-artist]');
  const button = approve || reject;
  if (!button) return;
  try { await api(`/api/v1/management/artists/${button.dataset.approveArtist || button.dataset.rejectArtist}/approve`, { method:'PATCH', body:{ status:approve?'approved':'rejected' } }); toast(approve?'Artist approved.':'Artist application rejected.'); loadManagement(); }
  catch (error) { toast(error.message); }
});
$('proposalForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await api(`/api/v1/management/enquiries/${$('proposalEnquiry').value.trim()}/proposals`, { method:'POST', body:{ amount:$('proposalAmount').value, terms:$('proposalTerms').value } });
    $('proposalForm').reset(); toast('Proposal sent to the company portal.'); loadManagement();
  } catch (error) { toast(error.message); }
});
$('managementAgreementForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api('/api/v1/management/agreements', { method:'POST', body:{ artistUserId:$('managementArtistId').value.trim(), commissionRateBps:Math.round(Number($('commissionRate').value)*100), terms:$('managementTerms').value } });
    $('managementAgreementForm').reset(); toast(`Agreement ${result.agreement.reference} created for signing.`); loadManagement();
  } catch (error) { toast(error.message); }
});
$('agreementFromProposalForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api(`/api/v1/management/proposals/${$('acceptedProposalId').value.trim()}/agreement`, { method:'POST', body:{} });
    $('agreementFromProposalForm').reset(); toast(`Agreement ${result.agreement.reference} created for signing.`); loadManagement();
  } catch (error) { toast(error.message); }
});

$('corporateEnquiryForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!currentUser) return openAuth('register','company');
  try {
    const result = await api('/api/v1/corporate/enquiries', { method:'POST', body:{ subject:$('companySubject').value, brief:$('companyBrief').value, budget:$('companyBudget').value || null, artistUserId:$('targetArtist').value.trim() || null } });
    $('corporateEnquiryForm').reset(); toast(`Enquiry submitted: ${result.enquiry.id.slice(0,8)}`); loadCorporate();
  } catch (error) { toast(error.message); }
});
async function loadCorporate() {
  if (!currentUser || !['company','manager','admin'].includes(currentUser.account_type)) {
    $('corporateEnquiries').innerHTML = '<div class="empty-state">Sign in or register a company account to submit and track corporate opportunities.</div>';
    $('corporateProposals').innerHTML = '';
    return;
  }
  try {
    const enquiries = await api('/api/v1/corporate/enquiries');
    $('corporateEnquiries').innerHTML = enquiries.enquiries.length ? enquiries.enquiries.map((e) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(e.subject)}</h3><small>Enquiry ${escapeHtml(e.id)}</small></div><span class="status-pill">${escapeHtml(e.status)}</span></div><p>${escapeHtml(e.brief)}</p></article>`).join('') : '<div class="empty-state">No enquiries submitted yet.</div>';
    if (currentUser.account_type === 'company') {
      const proposals = await api('/api/v1/corporate/proposals');
      $('corporateProposals').innerHTML = proposals.proposals.length ? proposals.proposals.map((p) => `<article class="stack-item"><div class="item-head"><div><h3>Proposal ${escapeHtml(p.id.slice(0,8))}</h3><small>${escapeHtml(p.subject)}</small></div><span class="status-pill">${escapeHtml(p.status)}</span></div><b>${money(p.amount_minor,p.currency)}</b><p>${escapeHtml(p.terms)}</p>${p.status === 'sent' ? `<div class="item-actions"><button class="small-button dark" data-proposal-accept="${p.id}">Accept</button><button class="small-button" data-proposal-reject="${p.id}">Reject</button></div>` : ''}</article>`).join('') : '<div class="empty-state">No proposals received yet.</div>';
    }
  } catch (error) { $('corporateEnquiries').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
$('refreshCorporate').addEventListener('click', loadCorporate);
$('corporateProposals').addEventListener('click', async (event) => {
  const accept = event.target.closest('[data-proposal-accept]');
  const reject = event.target.closest('[data-proposal-reject]');
  const button = accept || reject;
  if (!button) return;
  try { await api(`/api/v1/corporate/proposals/${button.dataset.proposalAccept || button.dataset.proposalReject}/respond`, { method:'POST', body:{ decision:accept?'accept':'reject' } }); toast(accept?'Proposal accepted.':'Proposal rejected.'); loadCorporate(); }
  catch (error) { toast(error.message); }
});

async function uploadEvidenceFile(file,evidenceType) {
  if (!file) throw new Error('Choose an evidence file first.');
  const intent = await api('/api/v1/artists/me/evidence-uploads',{method:'POST',body:{evidenceType,contentType:file.type,sizeBytes:file.size}});
  const response = await fetch(intent.upload.path,{method:'PUT',credentials:'include',headers:{'Content-Type':file.type,'x-csrf-token':csrfToken()},body:file});
  const uploadResult = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(uploadResult.error || `Private evidence upload failed (${response.status}).`);
  const completed = await api(`/api/v1/artists/me/evidence-uploads/${encodeURIComponent(intent.upload.id)}/complete`,{method:'POST',body:{}});
  return completed.upload.id;
}

async function loadRights() {
  $('partnerAdminPanel').hidden = !(currentUser && currentUser.account_type === 'admin');
  $('evidenceReviewPanel').hidden = !(currentUser && currentUser.account_type === 'admin');
  $('artistEvidencePanel').hidden = !(currentUser && ['artist','creator'].includes(currentUser.account_type));
  $('requestAllReports').hidden = !(currentUser && ['artist','creator'].includes(currentUser.account_type));
  $('externalMandatePanel').hidden = !(currentUser && ['artist','creator'].includes(currentUser.account_type));
  if (!currentUser) { $('partnerList').innerHTML = '<div class="empty-state">Sign in to view your rights partner permissions.</div>'; return; }
  try {
    const result = await api('/api/v1/partners/status');
    $('externalMandatePartner').innerHTML = result.partners.map((partner) => `<option value="${escapeHtml(partner.code)}">${escapeHtml(partner.name)}</option>`).join('');
    if (currentUser.account_type === 'admin') loadAdminEvidenceQueues();
    $('partnerList').innerHTML = result.partners.map((partner) => {
      const consented = partner.artist_authorisation_status === 'active';
      const externalVerified = partner.external_authorisation_status === 'verified' && (!partner.external_authorisation_expires_at || new Date(partner.external_authorisation_expires_at) > new Date());
      const connectionReady = partner.agreement_status === 'approved' && partner.endpoint_status === 'active' && partner.connection_verified === true;
      const active = connectionReady && consented && externalVerified;
      const pending = partner.agreement_status === 'contacted' || partner.agreement_status === 'under_review';
      const externalStatus = partner.external_authorisation_status || 'not_authorised';
      const status = active ? 'Verified active' : !consented ? (pending ? 'Partner approval pending · APPRECIATE consent not recorded' : 'APPRECIATE permission not recorded') : !externalVerified ? `APPRECIATE consent recorded · external mandate: ${externalStatus.replaceAll('_',' ')}` : 'External mandate verified · partner agreement/connection pending';
      const canRequest = ['artist','creator'].includes(currentUser.account_type);
      const consentButton = consented ? `<button class="small-button" data-revoke-partner="${escapeHtml(partner.code)}">Revoke APPRECIATE permission</button>` : `<button class="small-button" data-authorise-partner="${escapeHtml(partner.code)}">Grant APPRECIATE permission</button>`;
      const requestButton = active ? `<button class="small-button" data-report-request="${escapeHtml(partner.code)}">Prepare report request</button>` : '';
      return `<article class="partner-card ${active?'active':''}"><div class="partner-mark">${PARTNER_MARKS[partner.code] || '•'}</div><div><h3>${escapeHtml(partner.name)}</h3><p>${escapeHtml(partner.partner_type)} · ${status}</p>${canRequest ? `${consentButton}${requestButton}` : ''}</div></article>`;
    }).join('') || '<div class="empty-state">No partners listed.</div>';
  } catch (error) { $('partnerList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
$('partnerList').addEventListener('click', async (event) => {
  const authorise = event.target.closest('[data-authorise-partner]');
  const request = event.target.closest('[data-report-request]');
  const revoke = event.target.closest('[data-revoke-partner]');
  if (authorise) {
    try {
      if (!window.confirm('I authorise APPRECIATE to request usage reports and royalty statements from this named partner on my behalf, only for those scopes and only through an approved partner route. I understand this does not grant APPRECIATE partner access or guarantee a report, and I can revoke this permission at any time.')) return;
      const result = await api(`/api/v1/partners/${authorise.dataset.authorisePartner}/authorisations`, { method:'POST', body:{ consentConfirmed:true, scope:['usage_reports','royalty_statements'], consentVersion:'2026-11-08-v1' } });
      toast(result.message); loadRights();
    } catch (error) { toast(error.message); }
  }
  if (revoke) {
    if (!window.confirm('Revoke APPRECIATE permission to request reports from this partner?')) return;
    try { const result = await api(`/api/v1/partners/${revoke.dataset.revokePartner}/authorisations`, { method:'DELETE' }); toast(result.message); loadRights(); }
    catch (error) { toast(error.message); }
  }
  if (request) {
    try {
      const result = await api(`/api/v1/partners/${request.dataset.reportRequest}/request`, { method:'POST', body:{ notes:'One-off request prepared from the APPRECIATE rights dashboard.' } });
      $('reportRequestStatus').textContent = `${result.message} Request ID: ${result.request.id}`;
      toast('Report request prepared.');
    } catch (error) { toast(error.message); }
  }
});
$('identityEvidenceForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const evidenceUploadId = await uploadEvidenceFile($('identityEvidenceFile').files[0],'identity');
    const result = await api('/api/v1/artists/me/identity-submissions',{method:'POST',body:{evidenceUploadId}});
    toast(result.message); $('identityEvidenceForm').reset();
  } catch (error) { toast(error.message); }
});
$('recordingEvidenceForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const evidenceUploadId = await uploadEvidenceFile($('recordingEvidenceFile').files[0],'recording_rights');
    const shareValue = $('recordingEvidenceShare').value;
    const result = await api('/api/v1/artists/me/recordings',{method:'POST',body:{title:$('recordingEvidenceTitle').value.trim(),isrc:$('recordingEvidenceIsrc').value.trim(),ownershipRole:$('recordingEvidenceRole').value.trim(),ownershipShare:shareValue===''?null:Number(shareValue),evidenceUploadId}});
    toast(result.message); $('recordingEvidenceForm').reset();
  } catch (error) { toast(error.message); }
});
$('externalMandateForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const evidenceUploadId = await uploadEvidenceFile($('externalMandateEvidenceFile').files[0],'partner_authorisation');
    const expiry = $('externalMandateExpiry').value ? new Date(`${$('externalMandateExpiry').value}T23:59:59Z`).toISOString() : null;
    const result = await api(`/api/v1/partners/${encodeURIComponent($('externalMandatePartner').value)}/external-authorisations`, { method:'POST', body:{ method:$('externalMandateMethod').value, externalAuthorisationReference:$('externalMandateReference').value.trim(), externalAccountRef:$('externalMandateAccount').value.trim(), evidenceUploadId, expiresAt:expiry, scope:['usage_reports','royalty_statements'] } });
    toast(result.message); $('externalMandateForm').reset(); loadRights();
  } catch (error) { toast(error.message); }
});

async function loadAdminEvidenceQueues() {
  if (!currentUser || currentUser.account_type !== 'admin') return;
  try {
    const [identity,recordings,mandates] = await Promise.all([
      api('/api/v1/admin/identity-verifications?status=pending'),
      api('/api/v1/admin/recording-ownership?status=pending'),
      api('/api/v1/admin/partner-external-authorisations?status=pending')
    ]);
    $('identityReviewQueue').innerHTML = (identity.verifications||[]).map(x=>`<article class="stack-item"><div class="item-head"><div><b>${escapeHtml(x.display_name||x.email||x.artist_id)}</b><small>${escapeHtml(x.email||'')} · ${escapeHtml(x.id)}</small></div><span class="status-pill pending">pending</span></div><div class="item-actions"><button class="small-button" data-view-evidence="${escapeHtml(x.evidence_upload_id||'')}">View private evidence</button><button class="small-button dark" data-review-identity="${escapeHtml(x.id)}" data-artist-id="${escapeHtml(x.artist_id)}">Verify identity</button><button class="small-button" data-reject-identity="${escapeHtml(x.id)}" data-artist-id="${escapeHtml(x.artist_id)}">Reject</button></div></article>`).join('')||'<div class="empty-state">No pending identity submissions.</div>';
    $('recordingReviewQueue').innerHTML = (recordings.recordings||[]).map(x=>`<article class="stack-item"><div class="item-head"><div><b>${escapeHtml(x.title)}</b><small>${escapeHtml(x.display_name||x.email||x.artist_id)} · ${escapeHtml(x.isrc)}</small></div><span class="status-pill pending">pending</span></div><div class="item-actions"><button class="small-button" data-view-evidence="${escapeHtml(x.evidence_upload_id||'')}">View private evidence</button><button class="small-button dark" data-review-recording="${escapeHtml(x.id)}">Verify ownership</button><button class="small-button" data-reject-recording="${escapeHtml(x.id)}">Reject</button></div></article>`).join('')||'<div class="empty-state">No pending recording claims.</div>';
    $('externalMandateReviewQueue').innerHTML = (mandates.authorisations||[]).map(x=>`<article class="stack-item"><div class="item-head"><div><b>${escapeHtml(x.partner_name)} · ${escapeHtml(x.artist_name||x.email||x.artist_id)}</b><small>${escapeHtml(x.authorisation_method)} · ${escapeHtml(x.external_authorisation_reference)}</small></div><span class="status-pill pending">pending</span></div><div class="item-actions"><button class="small-button" data-view-evidence="${escapeHtml(x.evidence_upload_id||'')}">View private evidence</button><button class="small-button dark" data-review-mandate="${escapeHtml(x.partner_code)}" data-artist-id="${escapeHtml(x.artist_id)}">Verify mandate</button><button class="small-button" data-reject-mandate="${escapeHtml(x.partner_code)}" data-artist-id="${escapeHtml(x.artist_id)}">Reject</button></div></article>`).join('')||'<div class="empty-state">No pending external mandates.</div>';
  } catch(error) { $('identityReviewQueue').innerHTML=`<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
$('refreshEvidenceQueues').addEventListener('click',loadAdminEvidenceQueues);
$('evidenceReviewPanel').addEventListener('click',async(event)=>{
  const view=event.target.closest('[data-view-evidence]');
  const identity=event.target.closest('[data-review-identity],[data-reject-identity]');
  const recording=event.target.closest('[data-review-recording],[data-reject-recording]');
  const mandate=event.target.closest('[data-review-mandate],[data-reject-mandate]');
  try {
    if(view){if(!view.dataset.viewEvidence)throw new Error('Private evidence upload reference is missing.');const result=await api(`/api/v1/admin/evidence-uploads/${encodeURIComponent(view.dataset.viewEvidence)}/view`);window.open(result.url,'_blank','noopener');return;}
    if(identity){const status=identity.hasAttribute('data-review-identity')?'verified':'rejected';await api(`/api/v1/admin/artists/${encodeURIComponent(identity.dataset.artistId)}/identity-verifications/${encodeURIComponent(identity.dataset.reviewIdentity||identity.dataset.rejectIdentity)}`,{method:'PATCH',body:{status,notes:'Reviewed in APPRECIATE admin evidence queue.'}});}
    if(recording){const status=recording.hasAttribute('data-review-recording')?'verified':'rejected';await api(`/api/v1/admin/recordings/${encodeURIComponent(recording.dataset.reviewRecording||recording.dataset.rejectRecording)}/ownership`,{method:'PATCH',body:{status}});}
    if(mandate){const status=mandate.hasAttribute('data-review-mandate')?'verified':'rejected';await api(`/api/v1/admin/partners/${encodeURIComponent(mandate.dataset.reviewMandate||mandate.dataset.rejectMandate)}/external-authorisations/${encodeURIComponent(mandate.dataset.artistId)}`,{method:'PATCH',body:{status,notes:'Reviewed in APPRECIATE admin evidence queue.'}});}
    toast('Evidence review saved.');loadAdminEvidenceQueues();loadRights();
  } catch(error){toast(error.message);}
});
$('requestAllReports').addEventListener('click', async () => {
  try {
    const result = await api('/api/v1/partners/requests/all', { method:'POST', body:{} });
    $('reportRequestStatus').textContent = `${result.message} Batch: ${result.batchReference}. Prepared: ${result.preparedCount}; blocked: ${result.blockedCount}.`;
    toast(`Report request batch prepared: ${result.preparedCount} partner(s).`);
  } catch (error) { toast(error.message); }
});
$('partnerStatusForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await api(`/api/v1/admin/partners/${$('partnerCode').value.trim()}/status`, { method:'PATCH', body:{ agreementStatus:$('partnerAgreementStatus').value, endpointStatus:$('partnerEndpointStatus').value } });
    toast('Agreement/contact status saved. The partner remains inactive until a live provider test passes.'); loadRights();
  } catch (error) { toast(error.message); }
});
$('testPartnerConnection').addEventListener('click', async () => {
  const code = $('partnerCode').value.trim();
  if (!code) { toast('Enter a partner code first.'); return; }
  try {
    const result = await api(`/api/v1/admin/partners/${encodeURIComponent(code)}/test-connection`, { method:'POST', body:{} });
    toast(result.message);
    loadRights();
  } catch (error) { toast(error.message); }
});
$('externalPartnerAuthorisationReviewForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api(`/api/v1/admin/partners/${encodeURIComponent($('externalReviewPartnerCode').value.trim())}/external-authorisations/${encodeURIComponent($('externalReviewArtistId').value.trim())}`, { method:'PATCH', body:{ status:$('externalReviewStatus').value, notes:$('externalReviewNotes').value } });
    toast(result.message); loadRights();
  } catch (error) { toast(error.message); }
});
$('partnerAuthorisationReviewForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await api(`/api/v1/admin/partners/${$('reviewPartnerCode').value.trim()}/authorisations/${$('reviewArtistId').value.trim()}`, { method:'PATCH', body:{ status:$('reviewAuthorisationStatus').value, evidenceStorageKey:$('reviewEvidenceKey').value, externalAccountRef:$('reviewExternalRef').value } });
    toast('Artist permission review saved.'); loadRights();
  } catch (error) { toast(error.message); }
});

const bookingLabels = {artist_performance:'Artist performance',artist_appearance:'Artist appearance',artist_consultation:'Artist consultation',artist_development:'Artist development session',music_production:'Music production / recording',video_content:'Video / content creation',brand_campaign:'Brand / promotional campaign',other:'Other creative service'};
function bookingCard(booking, manager = false) {
  const status = String(booking.status || 'requested');
  const actions = manager && status === 'requested'
    ? `<div class="item-actions"><input aria-label="Quoted amount in rand" type="number" min="0.01" step="0.01" placeholder="Quote in ZAR" data-booking-quote="${booking.id}" style="max-width:130px"><button class="small-button dark" data-booking-decision="accept" data-booking-id="${booking.id}">Accept & invoice</button><button class="small-button" data-booking-decision="decline" data-booking-id="${booking.id}">Decline</button></div>`
    : (!manager && ['requested','confirmed'].includes(status) ? `<div class="item-actions">${booking.invoice_id && booking.invoice_status==='pending' ? `<button class="small-button dark" data-pay-booking="${booking.invoice_id}">Pay invoice</button>`:''}<button class="small-button" data-cancel-booking="${booking.id}">Cancel request</button></div>` : '');
  return `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(bookingLabels[booking.service_type] || booking.service_type)}</h3><small>${escapeHtml(booking.display_name || booking.client_name || 'Client')} · ${escapeHtml(booking.reference)}</small></div><span class="status-pill ${status==='paid'?'good':'pending'}">${escapeHtml(status.replaceAll('_',' '))}</span></div><p>${escapeHtml(booking.booking_date)} at ${escapeHtml(String(booking.start_time).slice(0,5))} · ${Number(booking.duration_minutes)} min<br>${escapeHtml(booking.location)}</p>${booking.notes?`<p>${escapeHtml(booking.notes)}</p>`:''}${booking.amount_minor?`<b>${money(booking.amount_minor,booking.currency || 'ZAR')}</b>`:''}${booking.invoice_reference?`<small>Invoice ${escapeHtml(booking.invoice_reference)} · ${escapeHtml(booking.invoice_status || 'pending')}</small>`:''}${actions}</article>`;
}
async function loadBookings() {
  if (!currentUser) {
    $('myBookingList').innerHTML = '<div class="empty-state">Sign in to request a booking.</div>';
    $('bookingManagerPanel').hidden = true;
    return;
  }
  try {
    const result = await api('/api/v1/bookings');
    $('myBookingList').innerHTML = result.bookings.length ? result.bookings.map((b)=>bookingCard(b)).join('') : '<div class="empty-state">No bookings yet. Use the form to send your first request.</div>';
    const manager = ['admin','manager'].includes(currentUser.account_type);
    $('bookingManagerPanel').hidden = !manager;
    if (manager) $('bookingManagerList').innerHTML = result.allBookings.length ? result.allBookings.map((b)=>bookingCard(b,true)).join('') : '<div class="empty-state">No client booking requests yet.</div>';
  } catch (error) {
    $('myBookingList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
    $('bookingManagerPanel').hidden = true;
  }
}
const bookingDateInput = $('bookingDate');
const localDateParts = new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Johannesburg',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()).reduce((o,p)=>{o[p.type]=p.value;return o;},{});
bookingDateInput.min = `${localDateParts.year}-${localDateParts.month}-${localDateParts.day}`;

$('bookingForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!currentUser) return openAuth('login');
  try {
    const result = await api('/api/v1/bookings', {method:'POST',body:{serviceType:$('bookingService').value,bookingDate:$('bookingDate').value,startTime:$('bookingTime').value,durationMinutes:Number($('bookingDuration').value),location:$('bookingLocation').value.trim(),notes:$('bookingNotes').value.trim()}});
    $('bookingForm').reset();
    toast(`Booking request ${result.booking.reference} sent. No payment has been taken.`);
    await loadBookings();
  } catch (error) { toast(error.message); }
});
$('refreshBookings').addEventListener('click',loadBookings);
$('myBookingList').addEventListener('click',async(event)=>{
  const pay=event.target.closest('[data-pay-booking]');
  const cancel=event.target.closest('[data-cancel-booking]');
  if(pay) return openPaymentDialog({invoiceId:pay.dataset.payBooking});
  if(cancel) { try { await api(`/api/v1/bookings/${cancel.dataset.cancelBooking}/cancel`,{method:'POST',body:{}}); toast('Booking cancellation requested.'); await loadBookings(); } catch(error){toast(error.message);} }
});
$('bookingManagerList').addEventListener('click',async(event)=>{
  const button=event.target.closest('[data-booking-decision]'); if(!button) return;
  const id=button.dataset.bookingId; const decision=button.dataset.bookingDecision;
  const quote=document.querySelector(`[data-booking-quote="${id}"]`);
  if(decision==='accept' && (!quote || !Number(quote.value) || Number(quote.value)<=0)) return toast('Enter the agreed booking price in ZAR first.');
  try { const result=await api(`/api/v1/bookings/${id}/decision`,{method:'PATCH',body:{decision,amount:decision==='accept'?Number(quote.value):null}}); toast(result.message || 'Booking updated.'); await loadBookings(); await loadPayments(); }
  catch(error){toast(error.message);}
});


// --------------------------- APPRECIATE Cloud Services ---------------------------
function cloudProjectCard(project) {
  const status = project.latest_deployment_status || 'not_deployed';
  const canRequest = Boolean(project.repository_url);
  return `<article class="stack-item cloud-project-card"><div class="item-head"><div><h3>${escapeHtml(project.name)}</h3><small>${escapeHtml(project.framework)} · ${escapeHtml(String(project.region || 'za').toUpperCase())}</small></div><span class="status-pill pending">${escapeHtml(status.replaceAll('_',' '))}</span></div>
    <p>${project.repository_url ? `<a href="${escapeHtml(project.repository_url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(project.repository_url)}</a>` : 'No repository linked yet'}</p>
    <small>${Number(project.deployment_count || 0)} deployment request(s) · Created ${new Date(project.created_at).toLocaleDateString()}</small>
    <div class="item-actions">${canRequest ? `<button class="small-button dark" data-cloud-deploy="${project.id}">Record deployment request</button>` : '<span class="muted-line">Upload project source through APPRECIATE CLOUD</span>'}</div>
  </article>`;
}
async function loadCloudProjects() {
  if (!currentUser) {
    $('cloudProjectCount').textContent='—'; $('cloudDeployCount').textContent='—';
    $('cloudProjectList').innerHTML='<div class="empty-state">Sign in to create and view your private cloud projects.</div>';
    return;
  }
  try {
    const [result, platform] = await Promise.all([api('/api/v1/cloud/projects'), api('/api/v1/cloud/platform')]);
    $('cloudProjectCount').textContent = result.projects.length;
    $('cloudDeployCount').textContent = result.projects.reduce((sum,p)=>sum+Number(p.deployment_count||0),0);
    $('cloudProjectList').innerHTML = result.projects.length ? result.projects.map(cloudProjectCard).join('') : '<div class="empty-state">No cloud projects yet. Create your first project using the form.</div>';
    const notice = $('cloudPlatformNotice'); const launch = $('cloudPlatformOpen');
    if (platform.configured && platform.url) { launch.href = platform.url; launch.hidden = false; notice.innerHTML = `<b>APPRECIATE CLOUD: ${platform.connected ? 'Connected' : 'Not responding'}.</b> ${escapeHtml(platform.message)}`; }
    else { launch.hidden = true; notice.innerHTML = '<b>APPRECIATE CLOUD connection: not configured.</b> Add APPRECIATE_CLOUD_URL and APPRECIATE_CLOUD_API_KEY to the APPRECIATE server environment to connect your private cloud control panel.'; }
  } catch (error) { $('cloudProjectList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
$('cloudProjectForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!currentUser) return openAuth('login');
  try {
    const result = await api('/api/v1/cloud/projects', {method:'POST',body:{name:$('cloudProjectName').value.trim(),framework:$('cloudProjectFramework').value,repositoryUrl:$('cloudProjectRepo').value.trim(),region:$('cloudProjectRegion').value}});
    $('cloudProjectForm').reset();
    toast(result.message || 'Cloud project created.');
    await loadCloudProjects();
  } catch (error) { toast(error.message); }
});
$('refreshCloudProjects').addEventListener('click', loadCloudProjects);
$('cloudProjectList').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-cloud-deploy]');
  if (!button) return;
  const branch = window.prompt('Git branch to deploy (default: main):', 'main');
  if (branch === null) return;
  try {
    const result = await api(`/api/v1/cloud/projects/${button.dataset.cloudDeploy}/deployments`, {method:'POST',body:{branch:branch.trim() || 'main'}});
    toast(result.message);
    await loadCloudProjects();
  } catch (error) { toast(error.message); }
});

async function loadPayments() {
  try {
    const result = await api('/api/v1/payment-methods');
    paymentMethods = result.methods;
    $('paymentMethodList').innerHTML = paymentMethods.map((method) => `<article class="payment-card ${method.enabled?'':'disabled'}"><span class="status-pill ${method.enabled?'good':'pending'}">${method.enabled?'Enabled':'Setup required'}</span><b>${escapeHtml(method.name)}</b><p>${escapeHtml(method.reason)}</p></article>`).join('');
    $('paymentDialogNote').textContent = result.note;
  } catch (error) { $('paymentMethodList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
  if (!currentUser) {
    $('adminPaymentTools').hidden = true;
    $('invoiceList').innerHTML = '<div class="empty-state">Sign in to view invoices.</div>';
    $('paymentHistory').innerHTML = '<div class="empty-state">Sign in to view payment history.</div>';
    return;
  }
  try {
    const [invoices,payments] = await Promise.all([api('/api/v1/invoices'),api('/api/v1/payments')]);
    $('invoiceList').innerHTML = invoices.invoices.length ? invoices.invoices.map((invoice) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(invoice.reference)}</h3><small>${escapeHtml(invoice.description)}</small></div><span class="status-pill">${escapeHtml(invoice.status)}</span></div><b>${money(invoice.amount_minor,invoice.currency)}</b>${invoice.status==='pending' && invoice.bill_to_user_id===currentUser.id ? `<div class="item-actions"><button class="small-button dark" data-pay-invoice="${invoice.id}">Pay invoice</button></div>`:''}</article>`).join('') : '<div class="empty-state">No invoices.</div>';
    $('paymentHistory').innerHTML = payments.payments.length ? payments.payments.map((payment) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(payment.reference)}</h3><small>${escapeHtml(payment.method)} · ${new Date(payment.created_at).toLocaleString()}</small></div><span class="status-pill ${payment.status==='paid'?'good':'pending'}">${escapeHtml(payment.status)}</span></div><b>${money(payment.amount_minor,payment.currency)}</b></article>`).join('') : '<div class="empty-state">No payment records.</div>';
  } catch (error) { $('paymentHistory').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
  if (currentUser && ['admin','manager'].includes(currentUser.account_type)) {
    $('adminPaymentTools').hidden = false;
    $('voucherIssueForm').hidden = currentUser.account_type !== 'admin';
    try {
      const admin = await api('/api/v1/admin/transactions');
      $('adminTransactionList').innerHTML = admin.transactions.length ? admin.transactions.map((p) => `<article class="stack-item"><div class="item-head"><div><h3>${escapeHtml(p.reference)}</h3><small>${escapeHtml(p.method)} · ${escapeHtml(p.provider || 'provider pending')}</small></div><span class="status-pill">${escapeHtml(p.status)}</span></div><b>${money(p.amount_minor,p.currency)}</b></article>`).join('') : '<div class="empty-state">No payment transactions.</div>';
    } catch (error) { $('adminTransactionList').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
  } else {
    $('adminPaymentTools').hidden = true;
    $('voucherIssueForm').hidden = true;
  }
}
$('refreshPayments').addEventListener('click', loadPayments);
$('invoiceList').addEventListener('click', (event) => {
  const button = event.target.closest('[data-pay-invoice]');
  if (button) openPaymentDialog({ invoiceId:button.dataset.payInvoice });
});
function openPaymentDialog(target) {
  if (!currentUser) return openAuth('login');
  pendingPaymentTarget = target;
  $('paymentOrderId').value = target.orderId || '';
  $('paymentInvoiceId').value = target.invoiceId || '';
  $('paymentMethod').innerHTML = paymentMethods.map((method) => `<option value="${method.id}" ${method.enabled?'':'disabled'}>${escapeHtml(method.name)}${method.enabled?'':' — setup required'}</option>`).join('');
  $('voucherField').hidden = true;
  $('bankChannelField').hidden = true;
  if (paymentMethods.length && paymentMethods.some((m) => m.enabled)) $('paymentMethod').value = paymentMethods.find((m) => m.enabled).id;
  $('paymentDialog').showModal();
  updatePaymentFields();
}
$('paymentMethod').addEventListener('change', updatePaymentFields);
function updatePaymentFields() {
  const method = $('paymentMethod').value;
  $('voucherField').hidden = method !== 'voucher';
  $('bankChannelField').hidden = !BANK_METHODS.has(method);
}
$('paymentForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const method = $('paymentMethod').value;
  if (!method) return toast('Choose a payment method.');
  try {
    const result = await api('/api/v1/payments', { method:'POST', body:{
      orderId:$('paymentOrderId').value || null,
      invoiceId:$('paymentInvoiceId').value || null,
      method,
      voucherCode:$('voucherCode').value.trim() || null
    } });
    if (result.checkoutUrl) {
      $('paymentDialog').close();
      window.location.href = result.checkoutUrl;
      return;
    }
    $('paymentDialog').close();
    toast(result.message || `Payment status: ${result.status}`);
    loadPayments(); loadOrders(); loadArtist();
  } catch (error) { toast(error.message); }
});

$('voucherIssueForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api('/api/v1/admin/vouchers', { method:'POST', body:{ amount:$('voucherAmount').value, expiresAt:$('voucherExpiry').value || null } });
    $('voucherIssuedCode').textContent = `Voucher code (shown once — store securely): ${result.code}`;
    $('voucherIssueForm').reset();
    toast('Voucher issued. Copy the code now; it cannot be retrieved in clear text later.');
  } catch (error) { toast(error.message); }
});
$('payoutForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const result = await api('/api/v1/admin/payouts', { method:'POST', body:{ artistId:$('payoutArtistId').value.trim(), amount:$('payoutAmount').value, notes:$('payoutNotes').value } });
    $('payoutForm').reset(); toast(`Payout record queued: ${result.payout.reference}. No bank transfer was sent.`);
  } catch (error) { toast(error.message); }
});

async function loadAccount() {
  if (!currentUser) {
    $('accountInfo').innerHTML = '<div class="empty-state">You are not signed in. Register or sign in to sync your account.</div>';
    $('profileName').value = ''; $('profileUsername').value = ''; $('profileBio').value = '';
    return;
  }
  try {
    const result = await api('/api/v1/me');
    currentUser = result.user;
    $('profileName').value = currentUser.display_name || '';
    $('profileUsername').value = currentUser.username || '';
    $('profileBio').value = currentUser.bio || '';
    $('accountInfo').innerHTML = `<div class="profile-meta"><b>Email:</b> ${escapeHtml(currentUser.email)}<br><b>Account type:</b> ${escapeHtml(currentUser.account_type)}<br><b>User ID:</b> ${escapeHtml(currentUser.id)}<br><b>Session:</b> Authenticated<br><b>Storage:</b> Self-hosted PostgreSQL</div>`;
    updateHeader();
  } catch (error) { $('accountInfo').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
$('profileForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try { await api('/api/v1/profile', { method:'PATCH', body:{ displayName:$('profileName').value, username:$('profileUsername').value, bio:$('profileBio').value } }); toast('Profile saved to the APPRECIATE database.'); loadAccount(); }
  catch (error) { toast(error.message); }
});
$('logoutButton').addEventListener('click', async () => {
  if (!currentUser) return openAuth('login');
  try { await api('/api/v1/auth/logout', { method:'POST', body:{} }); currentUser = null; updateHeader(); toast('Signed out.'); loadAccount(); loadMarketplace(); loadPayments(); loadArtist(); loadManagement(); loadCorporate(); loadRights(); loadCampaigns(); loadAnnouncements(); loadDiscover(); }
  catch (error) { toast(error.message); }
});

async function handlePayPalReturn() {
  const params = new URLSearchParams(window.location.search);
  if (params.get('payment') !== 'return' || !params.get('reference')) return;
  try {
    const result = await api(`/api/v1/payments/${encodeURIComponent(params.get('reference'))}/capture`, { method:'POST', body:{} });
    toast(result.payment?.status === 'paid' ? 'PayPal payment verified.' : 'PayPal payment is not yet confirmed.');
  } catch (error) { toast(`PayPal return: ${error.message}`); }
  params.delete('payment'); params.delete('reference');
  const query = params.toString();
  history.replaceState({}, '', `${location.pathname}${query ? `?${query}` : ''}`);
}

renderDestinationChecks();
(async function init() {
  await loadMe();
  await handlePayPalReturn();
  await loadDiscover();
  await loadMarketplace();
  await loadPayments();
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
})();

// APPRECIATE AI chat is proxied through the authenticated platform API.
let aiMessages = [];
async function loadAiStatus() {
  const target = $('aiStatus');
  if (!currentUser) { target.innerHTML = '<b>Sign in required.</b> Create an APPRECIATE account or sign in to use AI.'; return; }
  target.innerHTML = '<b>Checking APPRECIATE AI…</b> Connecting to the private model service.';
  try {
    const status = await api('/api/v1/ai/status');
    target.innerHTML = status.ready ? `<b>APPRECIATE AI is ready.</b> Model: ${escapeHtml(status.model || 'configured model')}.` : '<b>APPRECIATE AI is not online yet.</b> The platform is connected, but the model runtime needs to be started and configured.';
  } catch (error) { target.innerHTML = `<b>AI status unavailable.</b> ${escapeHtml(error.message)}`; }
}
$('aiChatForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!currentUser) { openAuth('login'); return; }
  const prompt = $('aiPrompt').value.trim();
  if (!prompt) return;
  aiMessages.push({ role:'user', content:prompt });
  const conversation = $('aiConversation');
  conversation.innerHTML = aiMessages.map(m => `<div class="stack-item"><b>${m.role === 'user' ? 'You' : 'APPRECIATE AI'}</b><p>${escapeHtml(m.content).replace(/\n/g,'<br>')}</p></div>`).join('');
  $('aiPrompt').value = ''; $('aiSend').disabled = true; $('aiSend').textContent = 'Thinking…';
  try {
    const result = await api('/api/v1/ai/chat', { method:'POST', body:{ messages:aiMessages } });
    aiMessages.push({ role:'assistant', content:result.message || 'No response was returned.' });
    conversation.innerHTML = aiMessages.map(m => `<div class="stack-item"><b>${m.role === 'user' ? 'You' : 'APPRECIATE AI'}</b><p>${escapeHtml(m.content).replace(/\n/g,'<br>')}</p></div>`).join('');
    conversation.scrollTop = conversation.scrollHeight;
  } catch (error) { aiMessages.pop(); toast(error.message); await loadAiStatus(); }
  finally { $('aiSend').disabled = false; $('aiSend').textContent = 'Send message'; }
});
