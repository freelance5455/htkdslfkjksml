# APPRECIATE OS — Native Cloud

APPRECIATE is being developed as its own application infrastructure. The active project does not require GitLab, Render, Forgejo or Coolify.

## Included services

- **APPRECIATE CODE** — local Git repository management and ZIP source ingestion.
- **APPRECIATE BUILD** — Dockerfile-based image builds.
- **APPRECIATE DEPLOY** — container deployment and lifecycle controls.
- **APPRECIATE DATABASE** — PostgreSQL control-plane database.
- **APPRECIATE MONITOR** — runtime status checks and activity records.
- **APPRECIATE CLOUD** — central owner dashboard and API.

## Current release maturity

This is an early owner-operated release. ZIP upload, local Git history, Dockerfile builds and container lifecycle APIs are implemented in source. Git-over-HTTP/SSH, managed public HTTPS routing, per-project databases, private object storage, backups, a secrets vault, tenant isolation and production security hardening remain unfinished. See `RELEASE_STATUS.md`.

## Requirements

- Linux server or dedicated computer with Docker Engine and Docker Compose plugin.
- Node.js 20+ (inside the cloud service image).
- Internet access for downloading base images and application dependencies.
- Persistent disk space and PostgreSQL 16.
- A domain and HTTPS gateway before exposing customer applications publicly.

No third-party hosting platform is built into the Compose architecture. The software still needs physical/cloud computing hardware to run.

## Start

1. Copy `.env.example` to `.env` on the server.
2. Generate unique long random values for all required secrets.
3. Set the real APP and CLOUD URLs after configuring your own domain and HTTPS gateway.
4. Start with `docker compose up -d --build`.
5. Keep the management API private. Do not expose the Docker socket or port 3100 to the public internet.

See `START_HERE.txt` and `cloud-control/docs/INSTALLATION.md`.
