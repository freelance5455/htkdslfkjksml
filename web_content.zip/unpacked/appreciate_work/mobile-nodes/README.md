# APPRECIATE Edge Network — v1.48

## What is implemented
- Central enrollment through APPRECIATE CLOUD's edge coordinator.
- Per-device random bearer credentials; only token hashes are stored centrally; token is returned once and stored locally with restrictive file permissions.
- Outbound heartbeat and capability reporting; no inbound internet port is required on phones.
- Central node inventory with active/pause/revoke controls.
- Task queue with atomic claims (`FOR UPDATE SKIP LOCKED`) and per-node result ownership.
- Strict task allowlist: `health_report` and optional `ai_generate` (only nodes advertising `local-ai`). No remote shell, arbitrary scripts, file-system access, or code deployment.
- `ai_generate` runs only against a node's explicitly configured local Ollama endpoint; no model weights or RAM are magically pooled.
- Pause by stopping the process or `POST /v1/pause`; revoke a node from the central admin API.

## Server configuration
Set `EDGE_ENROLLMENT_KEY` to a unique random secret of at least 32 characters in the server `.env`, then start the existing stack. The coordinator is served by `cloud-control` under `/api/v1/edge`.

All coordinator admin endpoints use `Authorization: Bearer $CLOUD_ADMIN_KEY`. Enrollment uses the separate `EDGE_ENROLLMENT_KEY`.

### Admin API
- `GET /api/v1/edge/health` — coordinator/database health.
- `GET /api/v1/edge/nodes` — list nodes.
- `PATCH /api/v1/edge/nodes/:id` with `{ "status":"paused" }`, `active`, or `revoked`.
- `DELETE /api/v1/edge/nodes/:id` — revoke.
- `POST /api/v1/edge/tasks` with `{ "type":"health_report" }` or `{ "type":"ai_generate", "payload":{"prompt":"..."} }`.
- `GET /api/v1/edge/tasks` — recent task status/results.

### Android / Termux
1. Install Termux from F-Droid or its official GitHub release; do not use obsolete Play Store builds.
2. In Termux: `pkg update && pkg install nodejs-lts git`. Copy this folder to `~/appreciate-mobile-node`.
3. Copy `.env.example` to `.env` and set `APPRECIATE_COORDINATOR_URL`, `APPRECIATE_EDGE_ENROLLMENT_KEY`, label and `APPRECIATE_NODE_ENABLED=true` only after reviewing the permissions.
4. Run `bash run-node.sh` to load `.env` and start the agent.
5. The first connection enrolls the phone and writes `.appreciate-node.json` locally. Protect this file; it contains the node credential. Revoke the device centrally if lost.
6. Local status: `http://127.0.0.1:3210/health`.

## Run the coordinator on your own Android phone (no paid hosting)
This is a **local-network bootstrap mode** for testing and small trusted groups. It runs a lightweight Node.js coordinator with a private JSON data file; it does not need Docker or PostgreSQL. It is not a public production cloud service.

1. On your first Android phone, install Termux and run `bash termux-install.sh`.
2. Run `bash bootstrap-phone.sh`. It creates two separate random secrets, configures the phone as coordinator and first opted-in node, and saves the settings in a private `.env` file. Keep the printed owner and enrollment keys private.
3. Start the coordinator: `bash run-coordinator.sh`. Keep Termux open; Android may stop background processes. `termux-wake-lock` can reduce sleep interruptions but uses battery.
4. Connect other phones/tablets/computers to the same trusted Wi-Fi or your phone's hotspot. Find the coordinator phone's private IPv4 address with `ip -4 addr`; do not guess it.
5. On each peer device, copy `peer-node.env.example` to `.env`, set `APPRECIATE_COORDINATOR_URL=http://COORDINATOR_PRIVATE_IP:3211`, the enrollment key, and a unique label. This example excludes the owner/admin key. `APPRECIATE_ALLOW_INSECURE_LAN=true` is only for a trusted private LAN/hotspot. Do not use it on public Wi-Fi or the internet.
6. On the coordinator phone itself, the node agent can use `APPRECIATE_COORDINATOR_URL=http://127.0.0.1:3211` and `APPRECIATE_ALLOW_INSECURE_LAN=false`; set its node label/class separately.
7. Open `http://127.0.0.1:3211/` on the host phone for the local APPRECIATE EDGE dashboard, or `/health` for its health check.

The local JSON store contains device/task metadata and AI task prompts. Protect the phone with a lock screen and keep the store file private. This mode is not encrypted at rest, does not provide public HTTPS, and should not store confidential business/customer information. If the phone is offline, the whole local coordinator is unavailable. Migrate to the PostgreSQL-backed APPRECIATE CLOUD coordinator before public or corporate production use.

## Other device types
- Linux servers/workstations: install Node.js 20+, copy this folder, configure `.env`, and run `./run-node.sh`. Use a dedicated non-root service account and a service manager for persistent hosting.
- macOS: install a supported Node.js release, configure environment variables, and run `node node-agent.js` from this folder.
- Windows: install Node.js 20+, set the variables from `.env` in PowerShell, then run `node .\node-agent.js`. The agent uses Node.js built-ins only.
- Tablets and Android phones: Termux is the current supported mobile runtime. iOS background compute enrollment is not included; iOS browser/PWA execution cannot provide reliable always-on node service.
- Set `APPRECIATE_NODE_CLASS` to `phone`, `tablet`, `laptop`, `workstation` or `server` to identify the device class.

## Phone safety
- Contribution is opt-in and disabled by default.
- The agent makes outbound requests only; use HTTPS except for explicitly enabled trusted private LAN bootstrap mode.
- It does not expose a public port, execute remote shell commands, install software, inspect private files, or access contacts/photos.
- Avoid running AI tasks on battery power, hot devices, metered networks or low-storage phones. Android may suspend background processes; phones are opportunistic nodes, not guaranteed servers.
- Use only devices you own or have explicit permission to administer. Never enroll corporate devices without written authorisation.

## Scaling model and limits
The network scales by distributing independent, bounded tasks to different devices. It does not combine device RAM into one shared memory pool and cannot make compute literally infinite. AI tasks are independent prompts executed by a local model on a node that explicitly advertises `local-ai`; model splitting across phones is not implemented. Results are stored centrally. Use a stable server for the coordinator and database when moving beyond testing.
