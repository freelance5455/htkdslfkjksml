#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .env ]; then echo 'Copy .env.example to .env and configure it first.' >&2; exit 1; fi
set -a
. ./.env
set +a
exec node node-agent.js
