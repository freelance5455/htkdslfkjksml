#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js is missing. Run: bash termux-install.sh' >&2
  exit 1
fi
if [ -e .env ]; then
  echo 'Existing .env found; refusing to overwrite it.' >&2
  exit 1
fi
cp .env.example .env
ADMIN="$(node -p "require('node:crypto').randomBytes(36).toString('base64url')")"
ENROLL="$(node -p "require('node:crypto').randomBytes(36).toString('base64url')")"
node - "$ADMIN" "$ENROLL" <<'NODE'
const fs=require('node:fs');const [admin,enroll]=process.argv.slice(2);let s=fs.readFileSync('.env','utf8');
const values={APPRECIATE_CLOUD_ADMIN_KEY:admin,APPRECIATE_EDGE_ENROLLMENT_KEY:enroll,APPRECIATE_COORDINATOR_HOST:'0.0.0.0',APPRECIATE_COORDINATOR_URL:'http://127.0.0.1:3211',APPRECIATE_NODE_ENABLED:'true',APPRECIATE_ALLOW_INSECURE_LAN:'false',APPRECIATE_NODE_CLASS:'phone',APPRECIATE_NODE_LABEL:'APPRECIATE Primary Phone'};
for(const [k,v] of Object.entries(values)){const re=new RegExp('^'+k+'=.*$','m');if(re.test(s))s=s.replace(re,`${k}=${v}`);else s+=`\n${k}=${v}\n`;}
fs.writeFileSync('.env',s,{mode:0o600});try{fs.chmodSync('.env',0o600)}catch{}
NODE
chmod 600 .env
echo 'APPRECIATE phone coordinator configured.'
echo 'Owner dashboard key (keep private):'
echo "$ADMIN"
echo 'Enrollment key (share only with devices you approve):'
echo "$ENROLL"
echo 'Next: bash run-coordinator.sh. In a second Termux session, run bash run-node.sh.'
