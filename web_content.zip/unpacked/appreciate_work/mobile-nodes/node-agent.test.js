'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {capabilities,safeEqual}=require('./node-agent');
test('agent exposes truthful platform capabilities without credentials',()=>{const c=capabilities();assert.equal(typeof c.platform,'string');assert.equal(c.execution_policy,'allowlisted-tasks-only-no-shell');assert.ok(!('node_token' in c));});
test('constant-time helper accepts equal and rejects unequal tokens',()=>{assert.equal(safeEqual('abc','abc'),true);assert.equal(safeEqual('abc','abd'),false);assert.equal(safeEqual('',''),false);});
