#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
pkg update -y
pkg install -y nodejs-lts
node --version
echo "APPRECIATE Edge Agent runtime installed. Configure .env before enabling node participation."
