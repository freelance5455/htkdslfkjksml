# APPRECIATE v1.47 — Mobile-to-Corporate Node Roadmap

1. **Local phone node (this release):** install and verify the Node.js agent on one Android device. It reports basic capabilities locally; it is opt-in and private by default.
2. **Secure enrollment:** add a coordinator endpoint, device-specific enrollment codes, revocation and signed heartbeats.
3. **Fleet management:** show online/offline status, available resources, battery/thermal/network constraints, owner consent and pause controls.
4. **Safe task execution:** signed, allowlisted, sandboxed tasks only; quotas, timeouts, audit records and data classification.
5. **AI task routing:** route independent inference/embedding/indexing tasks to compatible devices. Keep model execution local where possible; do not promise pooled RAM or distributed inference until supported by a tested runtime.
6. **Corporate nodes:** add managed servers/workstations with stronger authentication, tenant isolation, admin policies, monitoring and service-level controls.
7. **Scale-out:** coordinator-based scheduling and multiple independent nodes. Capacity grows with actual participating devices; it is not infinite.

The same protocol is designed for phones through corporate servers. Each device contributes only what its hardware and owner permit.
