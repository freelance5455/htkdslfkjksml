'use strict';
const http = require('node:http');
const crypto = require('node:crypto');
const PORT = Number(process.env.PORT || 3200);
const API_KEY = process.env.APPRECIATE_AI_API_KEY || '';
const OLLAMA_URL = (process.env.OLLAMA_URL || 'http://ollama:11434').replace(/\/$/, '');
const MODEL = process.env.APPRECIATE_AI_MODEL || 'qwen2.5:3b';
const MAX_BODY = 64 * 1024;
const REQUEST_TIMEOUT_MS = Number(process.env.APPRECIATE_AI_TIMEOUT_MS || 180000);

function send(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body), 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (Buffer.byteLength(raw) > MAX_BODY) {
        reject(Object.assign(new Error('Request body too large'), { status: 413 }));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(raw || '{}')); }
      catch { reject(Object.assign(new Error('Invalid JSON body'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function safeEqual(a, b) {
  const aa = Buffer.from(a); const bb = Buffer.from(b);
  return aa.length === bb.length && aa.length > 0 && crypto.timingSafeEqual(aa, bb);
}
async function runtimeStatus() {
  try {
    const response = await fetch(`${OLLAMA_URL}/api/tags`, { signal: AbortSignal.timeout(2500) });
    if (!response.ok) return { runtime: 'unavailable', model_ready: false };
    const data = await response.json();
    const models = Array.isArray(data.models) ? data.models : [];
    const ready = models.some(item => item.name === MODEL || item.name?.startsWith(`${MODEL}:`));
    return { runtime: 'online', model_ready: ready };
  } catch { return { runtime: 'unavailable', model_ready: false }; }
}
const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    const state = await runtimeStatus();
    return send(res, state.model_ready ? 200 : 503, { service: 'APPRECIATE AI', status: state.model_ready ? 'ready' : 'not_ready', model: MODEL, ...state, authenticated: Boolean(API_KEY) });
  }
  if (req.method !== 'POST' || req.url !== '/v1/chat') return send(res, 404, { error: 'not_found' });
  if (!API_KEY) return send(res, 503, { error: 'ai_not_configured', message: 'Set APPRECIATE_AI_API_KEY before using this service.' });
  const supplied = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!safeEqual(supplied, API_KEY)) return send(res, 401, { error: 'unauthorized' });
  let controller;
  let timeout;
  try {
    const body = await readBody(req);
    if (!Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 40) return send(res, 400, { error: 'messages_must_be_an_array_of_1_to_40_items' });
    const messages = body.messages.map(m => {
      if (!m || !['system', 'user', 'assistant'].includes(m.role) || typeof m.content !== 'string' || m.content.length > 12000) throw Object.assign(new Error('Each message needs a valid role and content (maximum 12,000 characters).'), { status: 400 });
      return { role: m.role, content: m.content };
    });
    controller = new AbortController();
    timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    const upstream = await fetch(`${OLLAMA_URL}/api/chat`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, signal: controller.signal,
      body: JSON.stringify({ model: MODEL, messages, stream: false })
    });
    if (!upstream.ok) return send(res, 502, { error: 'model_runtime_error', status: upstream.status, message: 'The model runtime did not accept the request. Check that the model is installed and Ollama is running.' });
    const result = await upstream.json();
    return send(res, 200, { id: crypto.randomUUID(), model: result.model || MODEL, message: result.message || null, done: Boolean(result.done), usage: { prompt_tokens: result.prompt_eval_count ?? null, completion_tokens: result.eval_count ?? null } });
  } catch (err) {
    const status = err.status || (err.name === 'AbortError' ? 504 : 500);
    if (!res.headersSent) return send(res, status, { error: status === 400 ? 'bad_request' : status === 413 ? 'payload_too_large' : status === 504 ? 'model_timeout' : 'ai_gateway_error', message: status < 500 ? err.message : 'APPRECIATE AI could not complete the request. Check the model runtime logs.' });
  } finally { if (timeout) clearTimeout(timeout); }
});
server.listen(PORT, '0.0.0.0', () => process.stdout.write(`APPRECIATE AI gateway listening on ${PORT}; model=${MODEL}\n`));
module.exports = { server, safeEqual };
