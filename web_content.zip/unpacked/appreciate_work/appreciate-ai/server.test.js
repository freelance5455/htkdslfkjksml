'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const path = require('node:path');
const root = __dirname;

async function start(env = {}) {
  const port = 33000 + Math.floor(Math.random() * 10000);
  const child = spawn(process.execPath, [path.join(root, 'server.js')], { env: { ...process.env, PORT: String(port), APPRECIATE_AI_API_KEY: 'test-secret', OLLAMA_URL: 'http://127.0.0.1:9', ...env }, stdio: 'ignore' });
  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 50; i++) {
    try { await fetch(`${base}/health`); break; } catch { await new Promise(r => setTimeout(r, 50)); }
  }
  return { child, base, close: () => child.kill('SIGTERM') };
}

test('health reports not-ready when model runtime is unavailable', async () => {
  const s = await start();
  try {
    const r = await fetch(`${s.base}/health`);
    assert.equal(r.status, 503);
    const j = await r.json();
    assert.equal(j.service, 'APPRECIATE AI');
    assert.equal(j.model_ready, false);
  } finally { s.close(); }
});

test('chat rejects missing or incorrect bearer key', async () => {
  const s = await start();
  try {
    const noKey = await fetch(`${s.base}/v1/chat`, { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify({messages:[{role:'user',content:'hi'}]}) });
    assert.equal(noKey.status, 401);
    const badKey = await fetch(`${s.base}/v1/chat`, { method: 'POST', headers: {'content-type':'application/json','authorization':'Bearer wrong'}, body: JSON.stringify({messages:[{role:'user',content:'hi'}]}) });
    assert.equal(badKey.status, 401);
  } finally { s.close(); }
});

test('chat validates message array after authentication', async () => {
  const s = await start();
  try {
    const r = await fetch(`${s.base}/v1/chat`, { method: 'POST', headers: {'content-type':'application/json','authorization':'Bearer test-secret'}, body: JSON.stringify({messages:[]}) });
    assert.equal(r.status, 400);
    assert.equal((await r.json()).error, 'messages_must_be_an_array_of_1_to_40_items');
  } finally { s.close(); }
});

test('unknown route returns 404', async () => {
  const s = await start();
  try { assert.equal((await fetch(`${s.base}/missing`)).status, 404); }
  finally { s.close(); }
});
