# v125 — Dashboard metrics visibility fix

Fixed the v124 dashboard display issue. The FLOAT STATUS and AGENT SERVICING calculations were present in the generated inline JavaScript source, but the actual web and Android app entry-point `index.html` files did not include the metric helper functions or dashboard cards. Both live entry points now include the calculations and render the two cards at the end of the dashboard stats section.

The stats layout now uses responsive auto-fit columns so all dashboard cards flow into additional rows rather than relying on a fixed seven-column layout. Existing metric definitions, same-day-of-month comparison cutoff, and red/green/neutral colors are unchanged. No Supabase SQL migration is required.
