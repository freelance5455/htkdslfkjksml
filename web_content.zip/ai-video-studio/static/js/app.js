/* Aurora Studio — logika frontend (vanilla JS, tanpa dependensi) */
'use strict';

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const state = {
  mode: 'text',
  info: null,
  files: [],           // File objects
  jobId: null,
  polling: null,
  startedAt: 0,
  providers: [],
};

const EXAMPLES = [
  'Senja di pantai berpasir putih, ombak tenang memecah perlahan, lalu kawanan burung terbang melintasi langit jingga',
  'Kota cyberpunk neon di malam hujan, gedung pencakar langit dengan lampu hologram, kendaraan melesat meninggalkan jejak cahaya',
  'Perjalanan luar angkasa melewati nebula ungu, planet bercincin berputar perlahan, lalu hujan meteor membelah kegelapan',
  'Hutan tropis berkabut di pagi hari, kunang-kunang berkelip di antara pohon pinus, sinar matahari menembus dedaunan',
  'Produk minimal di studio putih bersih, bentuk geometris melayang lembut, pencahayaan elegan untuk branding',
  'Musim dingin bersalju di desa pegunungan, kabut tipis menyelimuti pohon pinus, kepingan salju jatuh perlahan',
];

/* -------------------------------------------------- util */
function toast(msg, kind = 'info', ms = 4200) {
  const el = document.createElement('div');
  el.className = 'toast ' + (kind === 'error' ? 'err' : kind === 'ok' ? 'ok' : '');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = '.4s'; }, ms);
  setTimeout(() => el.remove(), ms + 450);
}
const fmtBytes = (b) => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : (b / 1024).toFixed(0) + ' KB';
const fmtDur = (s) => `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}`;

/* -------------------------------------------------- init */
async function init() {
  bindUI();
  const r = await fetch('/api/info');
  state.info = await r.json();
  fillSelects();
  renderChips();
  loadGallery();
}

function fillSelects() {
  const st = $('#style');
  st.innerHTML = '<option value="auto">✨ Auto (AI deteksi mood)</option>' +
    state.info.moods.map(m => `<option value="${m.id}">${m.label}</option>`).join('');
  $('#transition').innerHTML = state.info.transitions
    .map(t => `<option value="${t}"${t === 'fade' ? ' selected' : ''}>${t}</option>`).join('');
  $('#voice').innerHTML = state.info.voices.map(v => `<option value="${v.id}">${v.label}</option>`).join('');
  $('#maxImg').textContent = state.info.limits.max_images;
}

function renderChips() {
  $('#promptChips').innerHTML = EXAMPLES
    .map((e, i) => `<button class="chip" data-i="${i}">“${e.split(',')[0].slice(0, 42)}…”</button>`).join('');
  $$('#promptChips .chip').forEach(c => c.onclick = () => {
    $('#prompt').value = EXAMPLES[+c.dataset.i];
    analyze(true);
  });
}

/* -------------------------------------------------- bindings */
function bindUI() {
  $$('.tab').forEach(t => t.onclick = () => {
    $$('.tab').forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    state.mode = t.dataset.mode;
    $('#promptWrap').classList.toggle('hidden', state.mode === 'image');
    $('#imageWrap').classList.toggle('hidden', state.mode !== 'image');
  });

  const rz = (id, out, fmt) => {
    const el = $(id);
    const upd = () => $(out).textContent = fmt(parseFloat(el.value));
    el.addEventListener('input', upd); upd();
  };
  rz('#duration', '#durationVal', v => `${v} dtk`);
  rz('#scenes', '#scenesVal', v => v);
  rz('#overlap', '#overlapVal', v => v.toFixed(1).replace('.', ',') + ' dtk');
  rz('#motion_speed', '#motionVal', v => v.toFixed(1).replace('.', ',') + '×');
  rz('#grain', '#grainVal', v => v.toFixed(1).replace('.', ',') + '×');
  rz('#bloom', '#bloomVal', v => v.toFixed(1).replace('.', ',') + '×');
  rz('#chroma', '#chromaVal', v => v.toFixed(1).replace('.', ',') + '×');
  rz('#music_volume', '#musicVolVal', v => Math.round(v * 100) + '%');
  rz('#voice_speed', '#voiceSpeedVal', v => v.toFixed(2).replace('.', ',').replace(/0$/, '') + '×');
  rz('#voice_volume', '#voiceVolVal', v => Math.round(v * 100) + '%');

  $('#narration').addEventListener('change', e => {
    $('#voiceRow').style.display = e.target.checked ? 'grid' : 'none';
  });

  $('#style').addEventListener('change', () => analyze(true));
  $('#prompt').addEventListener('input', debounce(() => analyze(true), 650));

  // upload gambar
  const dz = $('#dropzone'), fi = $('#fileInput');
  dz.onclick = () => fi.click();
  dz.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') fi.click(); };
  fi.onchange = () => addFiles([...fi.files]);
  ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('drag'); }));
  dz.addEventListener('drop', e => addFiles([...e.dataTransfer.files]));

  $('#btnGenerate').onclick = generate;
  $('#btnAnalyze').onclick = () => analyze(false);
  $('#btnRefresh').onclick = loadGallery;

  // modal cloud
  $('#btnCloud').onclick = openCloud;
  $('#btnCloseCloud').onclick = () => $('#cloudModal').classList.add('hidden');
  $('#cloudModal').onclick = (e) => { if (e.target.id === 'cloudModal') $('#cloudModal').classList.add('hidden'); };
  $('#btnSaveKeys').onclick = saveKeys;

  // modal kits platform
  $('#btnKits').onclick = () => $('#kitsModal').classList.remove('hidden');
  $('#btnCloseKits').onclick = () => $('#kitsModal').classList.add('hidden');
  $('#kitsModal').onclick = (e) => { if (e.target.id === 'kitsModal') $('#kitsModal').classList.add('hidden'); };

  initPWA();
}

/* -------------------------------------------------- PWA (Android/Windows) */
let deferredInstall = null;
function initPWA() {
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('/sw.js').catch(() => { });
  }
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstall = e;
    $('#btnInstall').classList.remove('hidden');
  });
  window.addEventListener('appinstalled', () => {
    $('#btnInstall').classList.add('hidden');
    toast('Aurora Studio terpasang sebagai aplikasi 🎉', 'ok');
  });
  $('#btnInstall').onclick = async () => {
    if (!deferredInstall) {
      toast('Gunakan menu browser ⋮ → "Add to Home screen" / "Install app".', 'info', 6000);
      return;
    }
    deferredInstall.prompt();
    const r = await deferredInstall.userChoice;
    if (r.outcome === 'accepted') $('#btnInstall').classList.add('hidden');
    deferredInstall = null;
  };
}

function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

function addFiles(files) {
  const max = state.info ? state.info.limits.max_images : 6;
  for (const f of files) {
    if (!f.type.startsWith('image/')) { toast(`“${f.name}” bukan gambar.`, 'error'); continue; }
    if (state.files.length >= max) { toast(`Maksimal ${max} gambar.`, 'error'); break; }
    state.files.push(f);
  }
  renderThumbs();
}
function renderThumbs() {
  const box = $('#thumbs');
  box.innerHTML = '';
  state.files.forEach((f, i) => {
    const d = document.createElement('div');
    d.className = 'thumb';
    const img = document.createElement('img');
    img.src = URL.createObjectURL(f);
    const b = document.createElement('button');
    b.textContent = '✕'; b.title = 'Hapus';
    b.onclick = (e) => { e.stopPropagation(); state.files.splice(i, 1); renderThumbs(); };
    d.append(img, b);
    box.appendChild(d);
  });
}

/* -------------------------------------------------- analisis storyboard */
async function analyze(quiet) {
  const prompt = $('#prompt').value.trim();
  if (!prompt) { $('#storyboard').innerHTML = ''; $('#palettePrev').innerHTML = ''; return; }
  try {
    const r = await fetch('/api/analyze', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, style: $('#style').value, scenes: +$('#scenes').value, duration: +$('#duration').value }),
    });
    const j = await r.json();
    if (!j.ok) return;
    const p = j.plan;
    $('#palettePrev').innerHTML = p.palette.map(c => `<i style="background:${c}"></i>`).join('');
    $('#storyboard').innerHTML =
      `<div class="sb-item"><div class="n">AI</div><div><div class="t"><b>${esc(p.title)}</b></div>` +
      `<div class="m">Mood terdeteksi: ${p.mood_label} · musik: ${p.music_style} · ${p.scenes.length} adegan · ±${Math.round(p.duration)} dtk</div></div></div>` +
      p.scenes.map(s => `<div class="sb-item"><div class="n">${s.index + 1}</div>` +
        `<div><div class="t">${esc(s.caption)}</div>` +
        `<div class="m">${s.duration.toFixed(1)} dtk · kamera ${s.camera.name} · ${s.elements.slice(0, 5).join(', ')}</div></div>` +
        `<div class="sw2">${s.palette.map(c => `<i style="background:${c}"></i>`).join('')}</div></div>`).join('');
    if (!quiet) toast('Storyboard diperbarui sesuai prompt.', 'ok');
  } catch (e) { /* biarkan diam */ }
}
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* -------------------------------------------------- generate */
async function generate() {
  const prompt = $('#prompt').value.trim();
  if (state.mode === 'text' && !prompt) { toast('Tulis prompt dulu ya 🙂', 'error'); $('#prompt').focus(); return; }
  if (state.mode === 'image' && !state.files.length) { toast('Unggah minimal 1 gambar.', 'error'); return; }

  const fd = new FormData();
  fd.append('prompt', prompt);
  fd.append('style', $('#style').value);
  fd.append('transition', $('#transition').value);
  fd.append('aspect', $('#aspect').value);
  fd.append('resolution', $('#resolution').value);
  fd.append('fps', $('#fps').value);
  fd.append('duration', $('#duration').value);
  fd.append('scenes', $('#scenes').value);
  fd.append('overlap', $('#overlap').value);
  fd.append('motion_speed', $('#motion_speed').value);
  fd.append('grain', $('#grain').value);
  fd.append('bloom', $('#bloom').value);
  fd.append('chroma', $('#chroma').value);
  fd.append('music_volume', $('#music_volume').value);
  fd.append('voice_speed', $('#voice_speed').value);
  fd.append('voice_volume', $('#voice_volume').value);
  ['letterbox', 'karaoke', 'narration'].forEach(id => { if ($('#' + id).checked) fd.append(id, 'on'); });
  ['caption', 'subtitle', 'music'].forEach(id => { if (!$('#' + id).checked) fd.append(id, 'off'); });
  if ($('#narration').checked) { fd.append('voice', $('#voice').value); }
  fd.append('provider', $('#cloudProvider').value || 'local');
  state.files.forEach(f => fd.append('images', f, f.name));

  setRendering(true);
  $('#btnGenerate').disabled = true;
  state.startedAt = Date.now();
  try {
    const r = await fetch('/api/generate', { method: 'POST', body: fd });
    const j = await r.json();
    if (!j.ok) { setRendering(false); $('#btnGenerate').disabled = false; toast(j.error || 'Gagal memulai job.', 'error'); return; }
    state.jobId = j.job_id;
    toast('Job render dimulai ✨', 'ok');
    poll();
  } catch (e) {
    setRendering(false); $('#btnGenerate').disabled = false;
    toast('Server tidak merespons: ' + e, 'error');
  }
}

function setRendering(on) {
  $('#rendering').classList.toggle('hidden', !on);
  $('#playerEmpty').classList.toggle('hidden', on);
  $('#video').classList.add('hidden');
  $('#errorBox').classList.add('hidden');
  if (on) { $('#barFill').style.width = '0%'; $('#pctTxt').textContent = '0%'; }
}

function poll() {
  clearInterval(state.polling);
  state.polling = setInterval(async () => {
    if (!state.jobId) return clearInterval(state.polling);
    try {
      const r = await fetch('/api/status/' + state.jobId);
      const j = await r.json();
      if (!j.ok) return;
      const job = j.job;
      const pct = Math.round((job.progress || 0) * 100);
      $('#barFill').style.width = pct + '%';
      $('#pctTxt').textContent = pct + '%';
      $('#stageTxt').textContent = job.stage || 'Memproses…';
      const el = (Date.now() - state.startedAt) / 1000;
      const eta = job.progress > 0.05 ? Math.max(0, el / job.progress - el) : 0;
      $('#etaTxt').textContent = `Berjalan ${fmtDur(el)} · perkiraan sisa ${fmtDur(eta)}`;
      if (job.status === 'done') {
        clearInterval(state.polling);
        onDone(job);
      } else if (job.status === 'error') {
        clearInterval(state.polling);
        onError(job);
      }
    } catch (e) { /* retry */ }
  }, 900);
}

function onDone(job) {
  setRendering(false);
  $('#btnGenerate').disabled = false;
  const v = $('#video');
  v.classList.remove('hidden');
  v.src = '/video/' + state.jobId + '?t=' + Date.now();
  v.poster = '/poster/' + state.jobId;
  v.load();
  const m = job.meta || {};
  const chips = [
    ['🎞️', `${m.width}×${m.height} @ ${m.fps}fps`],
    ['⏱️', `${fmtDur(m.duration || 0)}`],
    ['💾', fmtBytes(m.size || 0)],
    ['🎨', m.mood_label || m.provider || ''],
    ['🎬', `${(m.scenes || []).length} adegan`],
    ['⚡', `${m.elapsed ? m.elapsed + ' dtk render' : ''}`],
    ['🎵', m.music ? 'musik ✓' : 'musik ✗'],
    ['🎙️', m.narration ? 'narasi ✓' : ''],
  ].filter(c => c[1]);
  $('#metaRow').innerHTML = chips.map(c => `<span class="meta">${c[0]} <b>${esc(c[1])}</b></span>`).join('');
  $('#dlRow').classList.remove('hidden');
  $('#dlVideo').href = '/download/' + state.jobId;
  $('#dlBundle').href = '/download/' + state.jobId + '/bundle';
  $('#dlPoster').href = '/download/' + state.jobId + '/poster';
  $('#dlSrt').href = '/download/' + state.jobId + '/srt';
  $('#dlJson').href = '/download/' + state.jobId + '/json';
  toast('Video selesai! Siap diputar & diunduh 🎉', 'ok', 6000);
  loadGallery();
}

function onError(job) {
  setRendering(false);
  $('#btnGenerate').disabled = false;
  $('#errorBox').classList.remove('hidden');
  $('#errorTxt').textContent = (job.error || 'Kesalahan tidak diketahui').slice(0, 2000);
  toast('Render gagal: lihat detail di panel video.', 'error', 8000);
}

/* -------------------------------------------------- galeri */
async function loadGallery() {
  try {
    const r = await fetch('/api/gallery');
    const j = await r.json();
    const box = $('#gallery');
    const items = (j.items || []).filter(i => i.has_video);
    if (!items.length) {
      box.innerHTML = '<div class="g-empty">Belum ada video. Buat yang pertama! ✨</div>';
      return;
    }
    box.innerHTML = items.map(i => `
      <div class="g-card">
        <div class="g-img" data-id="${i.id}">
          <img src="/poster/${i.id}" alt="" loading="lazy" onerror="this.style.display='none'">
          <span class="play">▶</span>
        </div>
        <div class="g-body">
          <h4 title="${esc(i.prompt || '')}">${esc(i.title || 'Video')}</h4>
          <p>${esc(i.mood || '')} · ${fmtDur(i.duration || 0)} · ${fmtBytes(i.size || 0)}</p>
          <div class="g-act">
            <a class="btn tiny" href="/download/${i.id}">⬇ MP4</a>
            <button class="btn tiny" data-open="${i.id}">▶ Putar</button>
            <button class="btn tiny" data-del="${i.id}">🗑</button>
          </div>
        </div>
      </div>`).join('');
    $$('[data-open]').forEach(b => b.onclick = () => openJob(b.dataset.open));
    $$('.g-img').forEach(d => d.onclick = () => openJob(d.dataset.id));
    $$('[data-del]').forEach(b => b.onclick = async () => {
      if (!confirm('Hapus video ini dari galeri?')) return;
      await fetch('/api/gallery/' + b.dataset.del + '/delete', { method: 'POST' });
      loadGallery();
    });
  } catch (e) { /* ignore */ }
}

async function openJob(id) {
  state.jobId = id;
  setRendering(false);
  const v = $('#video');
  v.classList.remove('hidden');
  $('#playerEmpty').classList.add('hidden');
  v.src = '/video/' + id;
  v.poster = '/poster/' + id;
  v.load(); v.play().catch(() => { });
  $('#dlRow').classList.remove('hidden');
  $('#dlVideo').href = '/download/' + id;
  $('#dlBundle').href = '/download/' + id + '/bundle';
  $('#dlPoster').href = '/download/' + id + '/poster';
  $('#dlSrt').href = '/download/' + id + '/srt';
  $('#dlJson').href = '/download/' + id + '/json';
  try {
    const r = await fetch('/video/' + id, { method: 'HEAD' });
    // meta dari server bila ada
  } catch (e) { }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* -------------------------------------------------- cloud */
async function openCloud() {
  $('#cloudModal').classList.remove('hidden');
  const r = await fetch('/api/cloud/status');
  const j = await r.json();
  state.providers = j.providers;
  $('#providerList').innerHTML = j.providers.map(p => `
    <div class="p-row">
      <div class="p-top"><b>${esc(p.name)}</b>
        <span class="p-status ${p.configured ? 'ok' : 'no'}">${p.configured ? '✓ key aktif ' + esc(p.key_preview || '') : 'belum diisi'}</span>
      </div>
      <input type="password" data-key="${p.key_env}" placeholder="${p.key_env}" value="">
      <div class="p-meta">${esc(p.kind)} · model: ${p.models.slice(0, 2).join(', ')} · <a href="${p.docs}" target="_blank" rel="noopener">dokumentasi</a>${p.note ? ' · ' + esc(p.note) : ''}</div>
    </div>`).join('');
  const sel = $('#cloudProvider');
  sel.innerHTML = '<option value="local">⚙️ Engine Lokal (default, tanpa key)</option>' +
    j.providers.filter(p => p.configured).map(p => `<option value="${p.id}">☁️ ${esc(p.name)}</option>`).join('');
  $('#enginePill').textContent = sel.value === 'local' ? '⚙️ Engine Lokal' : '☁️ Cloud';
}

async function saveKeys() {
  const body = {};
  $$('#providerList input[data-key]').forEach(i => { if (i.value.trim()) body[i.dataset.key] = i.value.trim(); });
  const r = await fetch('/api/cloud/keys', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const j = await r.json();
  toast('Key tersimpan di server lokal.', 'ok');
  const sel = $('#cloudProvider');
  const cur = sel.value;
  sel.innerHTML = '<option value="local">⚙️ Engine Lokal (default, tanpa key)</option>' +
    j.providers.filter(p => p.configured).map(p => `<option value="${p.id}">☁️ ${esc(p.name)}</option>`).join('');
  sel.value = cur;
  openCloud();
}

init();
