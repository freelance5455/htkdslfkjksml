import gc
import io
import os
import queue
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Optional

import torch
from PIL import Image, ImageOps
from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from diffusers import WanImageToVideoPipeline, WanPipeline
from diffusers.utils import export_to_video

TOKEN = os.environ["STUDIO_TOKEN"]
T2V_MODEL = os.environ.get("WAN_T2V_MODEL", "Wan-AI/Wan2.1-T2V-1.3B-Diffusers")
# I2V yalnızca 14B modellerle mevcut. GEN_CLASS ile eşleşmeli:
# 480 -> Wan2.1-I2V-14B-480P-Diffusers, 720 -> Wan2.1-I2V-14B-720P-Diffusers
I2V_MODEL = os.environ.get("WAN_I2V_MODEL", "Wan-AI/Wan2.1-I2V-14B-480P-Diffusers")
GEN_CLASS = os.environ.get("GEN_CLASS", "480")  # "480" veya "720"
STEPS = int(os.environ.get("STEPS", "30"))
OFFLOAD = os.environ.get("CPU_OFFLOAD", "1") == "1"
VIDEO_DIR = Path(os.environ.get("VIDEO_DIR", "/data/videos"))
VIDEO_DIR.mkdir(parents=True, exist_ok=True)

FPS = 16
SEG_FRAMES = 81        # Wan'ın yerel uzunluğu (~5 sn @16fps)
TARGET_FRAMES = 160    # 10 sn @16fps
DEFAULT_NEG = "blurry, low quality, distorted, watermark, text, jitter, static"

GEN_SIZES = {
    "480": {"9:16": (480, 848), "1:1": (480, 480), "16:9": (848, 480)},
    "720": {"9:16": (720, 1280), "1:1": (720, 720), "16:9": (1280, 720)},
}
OUT_SIZES = {
    "720p": {"9:16": (720, 1280), "1:1": (720, 720), "16:9": (1280, 720)},
    "1080p": {"9:16": (1080, 1920), "1:1": (1080, 1080), "16:9": (1920, 1080)},
}


class GPUModels:
    """Aynı anda tek model yükler; VRAM'i korumak için değiştirirken boşaltır."""

    def __init__(self):
        self.name = None
        self.pipe = None

    def get(self, name: str):
        if self.name == name:
            return self.pipe
        self.unload()
        if name == "t2v":
            pipe = WanPipeline.from_pretrained(T2V_MODEL, torch_dtype=torch.bfloat16)
        else:
            pipe = WanImageToVideoPipeline.from_pretrained(I2V_MODEL, torch_dtype=torch.bfloat16)
        if hasattr(pipe, "vae"):
            pipe.vae.enable_tiling()
        if OFFLOAD:
            pipe.enable_model_cpu_offload()
        else:
            pipe.to("cuda")
        self.name, self.pipe = name, pipe
        return pipe

    def unload(self):
        self.pipe = None
        self.name = None
        gc.collect()
        torch.cuda.empty_cache()


gpu = GPUModels()


def gen_t2v(prompt, neg, w, h):
    pipe = gpu.get("t2v")
    return pipe(prompt=prompt, negative_prompt=neg, height=h, width=w,
                num_frames=SEG_FRAMES, guidance_scale=5.0,
                num_inference_steps=STEPS, output_type="pil").frames[0]


def gen_i2v(image, prompt, neg, w, h):
    pipe = gpu.get("i2v")
    return pipe(image=image, prompt=prompt, negative_prompt=neg, height=h, width=w,
                num_frames=SEG_FRAMES, guidance_scale=5.0,
                num_inference_steps=STEPS, output_type="pil").frames[0]


def generate_frames(job, gw, gh):
    """İki segment üretip zincirler: 2 x ~5 sn -> 10 sn."""
    p, n = job["prompt"], job["negative"] or DEFAULT_NEG
    if job["mode"] == "i2v":
        start = ImageOps.fit(Image.open(job["image_path"]).convert("RGB"), (gw, gh), Image.LANCZOS)
        seg1 = gen_i2v(start, p, n, gw, gh)
    else:
        job["stage"] = "segment 1/2 (metinden)"
        seg1 = gen_t2v(p, n, gw, gh)
        gpu.unload()  # I2V modeli için VRAM boşalt
    job["stage"] = "segment 2/2 (zincir)"
    seg2 = gen_i2v(seg1[-1], p, n, gw, gh)
    return (seg1 + seg2[1:])[:TARGET_FRAMES]


def finalize(src: Path, dst: Path, w: int, h: int):
    subprocess.run([
        "ffmpeg", "-y", "-loglevel", "error", "-i", str(src),
        "-vf", f"scale={w}:{h}:flags=lanczos",
        "-c:v", "libx264", "-preset", "medium", "-crf", "18",
        "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(dst),
    ], check=True)


JOBS: dict = {}
JOB_Q: "queue.Queue[dict]" = queue.Queue()


def worker():
    while True:
        job = JOB_Q.get()
        try:
            job.update(status="running", stage="üretiliyor")
            gw, gh = GEN_SIZES[GEN_CLASS][job["aspect"]]
            tw, th = OUT_SIZES[job["resolution"]][job["aspect"]]
            frames = generate_frames(job, gw, gh)
            job["stage"] = "kodlanıyor"
            raw = VIDEO_DIR / f"{job['id']}_raw.mp4"
            out = VIDEO_DIR / f"{job['id']}.mp4"
            export_to_video(frames, str(raw), fps=FPS)
            finalize(raw, out, tw, th)
            raw.unlink(missing_ok=True)
            job.update(status="done", stage="tamamlandı", file=str(out))
        except Exception as e:  # noqa: BLE001
            job.update(status="error", error=str(e)[:500])
        finally:
            JOB_Q.task_done()


threading.Thread(target=worker, daemon=True).start()

app = FastAPI(title="AI Video Studio")


def auth(request: Request, token: Optional[str] = Query(None)):
    given = request.headers.get("x-token") or token
    if given != TOKEN:
        raise HTTPException(status_code=401, detail="Yetkisiz")


def public(job: dict) -> dict:
    return {k: v for k, v in job.items() if k not in ("image_path", "file")} | {
        "has_video": job.get("file") is not None and job["status"] == "done"
    }


@app.get("/api/health")
def health():
    return {"ok": True, "cuda": torch.cuda.is_available(), "gen_class": GEN_CLASS}


@app.post("/api/jobs", dependencies=[Depends(auth)])
async def create_job(
    prompt: str = Form(...),
    mode: str = Form("t2v"),
    aspect: str = Form("16:9"),
    resolution: str = Form("720p"),
    negative: str = Form(""),
    image: Optional[UploadFile] = File(None),
):
    if not prompt.strip():
        raise HTTPException(400, "Prompt boş olamaz")
    if mode not in ("t2v", "i2v"):
        raise HTTPException(400, "mode t2v veya i2v olmalı")
    if aspect not in GEN_SIZES[GEN_CLASS]:
        raise HTTPException(400, "Geçersiz format")
    if resolution not in OUT_SIZES:
        raise HTTPException(400, "Geçersiz çözünürlük")

    job_id = uuid.uuid4().hex[:12]
    job = {
        "id": job_id, "prompt": prompt.strip(), "negative": negative.strip(),
        "mode": mode, "aspect": aspect, "resolution": resolution,
        "status": "queued", "stage": "sırada", "error": None, "file": None,
        "image_path": None, "created": time.strftime("%Y-%m-%d %H:%M"),
    }
    if mode == "i2v":
        if image is None:
            raise HTTPException(400, "Fotoğraf gerekli")
        path = VIDEO_DIR / f"{job_id}_in.png"
        try:
            data = await image.read()
            Image.open(io.BytesIO(data)).convert("RGB").save(path)
        except Exception:
            raise HTTPException(400, "Geçersiz görsel dosyası")
        job["image_path"] = str(path)

    JOBS[job_id] = job
    JOB_Q.put(job)
    return public(job)


@app.get("/api/jobs", dependencies=[Depends(auth)])
def list_jobs():
    return [public(j) for j in reversed(list(JOBS.values()))][:50]


@app.get("/api/jobs/{job_id}", dependencies=[Depends(auth)])
def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "İş bulunamadı")
    return public(job)


@app.get("/api/jobs/{job_id}/video", dependencies=[Depends(auth)])
def get_video(job_id: str):
    job = JOBS.get(job_id)
    if not job or job["status"] != "done":
        raise HTTPException(404, "Video hazır değil")
    return FileResponse(job["file"], media_type="video/mp4", filename=f"video_{job_id}.mp4")


@app.delete("/api/jobs/{job_id}", dependencies=[Depends(auth)])
def delete_job(job_id: str):
    job = JOBS.pop(job_id, None)
    if job and job.get("file"):
        Path(job["file"]).unlink(missing_ok=True)
    return {"deleted": bool(job)}


app.mount("/", StaticFiles(directory=Path(__file__).parent / "static", html=True), name="static")
