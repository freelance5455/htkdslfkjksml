package com.personal.videostudio

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("studio", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
                val name = URLUtil.guessFileName(url, contentDisposition, mimetype)
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimetype)
                    .setTitle(name)
                    .addRequestHeader("User-Agent", userAgent)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES, name)
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            }
        }
        setContentView(FrameLayout(this).apply { addView(webView) })

        val saved = prefs.getString("server_url", null)
        if (saved == null) askServerUrl() else webView.loadUrl(saved)
    }

    private fun askServerUrl() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            hint = "https://studio.ornek.com"
            setText(prefs.getString("server_url", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("Sunucu adresi (HTTPS)")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Kaydet") { _, _ ->
                val url = input.text.toString().trim().trimEnd('/')
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    prefs.edit().putString("server_url", url).apply()
                    webView.loadUrl(url)
                } else {
                    askServerUrl()
                }
            }
            .show()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
