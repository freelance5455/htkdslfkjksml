#!/usr/bin/env python3
"""
Aurora Studio — AI Video Generator (Text → Video & Image → Video)
Server Flask: job queue + render + download.

Jalankan:  python3 app.py   (default http://0.0.0.0:8000)
"""
from __future__ import annotations

import io
import json
import os
import shutil
import sys
import threading
import time
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from flask import (Flask, jsonify, render_template, request, send_file,
                   send_from_directory, abort)
from werkzeug.utils import secure_filename

from engine import cloud, encoder, pipeline, planner, tts

ROOT = os.path.dirname(os.path.abspath(__file__))
if getattr(sys, "frozen", False):  # dijalankan sebagai exe PyInstaller
    BASE = os.path.join(os.path.expanduser("~"), "AuroraStudio")
    os.makedirs(BASE, exist_ok=True)
else:
    BASE = ROOT
OUTPUTS = os.path.join(BASE, "outputs")
UPLOADS = os.path.join(BASE, "workspace", "uploads")
JOBS_DIR = os.path.join(BASE, "workspace", "jobs")
os.makedirs(OUTPUTS, exist_ok=True)
os.makedirs(UPLOADS, exist_ok=True)
os.makedirs(JOBS_DIR, exist_ok=True)

ALLOWED_IMG = {"png", "jpg", "jpeg", "webp", "bmp"}
MAX_IMAGES = 6
MAX_UPLOAD_MB = 14

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = (MAX_UPLOAD_MB * MAX_IMAGES + 8) * 1024 * 1024

JOBS: dict[str, dict] = {}
LOCK = threading.Lock()
POOL = ThreadPoolExecutor(max_workers=int(os.environ.get("AURORA_WORKERS", "2")))


# ------------------------------------------------------------------ helpers

def _job_dir(job_id: str) -> str:
    return os.path.join(JOBS_DIR, job_id)


def _set(job_id: str, **kw):
    with LOCK:
        j = JOBS.setdefault(job_id, {})
        j.update(kw)
        j["updated"] = time.time()


def _progress(job_id: str):
    def fn(p: float, msg: str):
        _set(job_id, progress=round(max(0.0, min(1.0, p)), 4), stage=msg)
    return fn


def _run(job_id: str, params: dict):
    wd = os.path.join(_job_dir(job_id), "work")
    od = os.path.join(_job_dir(job_id), "out")
    os.makedirs(wd, exist_ok=True)
    os.makedirs(od, exist_ok=True)
    t0 = time.time()
    try:
        _set(job_id, status="running", started=time.time())
        meta = pipeline.run_job(params, wd, od, progress=_progress(job_id))
        with LOCK:
            JOBS[job_id].update({
                "status": "done", "progress": 1.0, "stage": "Selesai ✅",
                "meta": meta, "elapsed": round(time.time() - t0, 1),
                "size": meta.get("size", 0), "finished": time.time(),
            })
    except Exception as e:  # pragma: no cover
        with LOCK:
            JOBS[job_id].update({
                "status": "error", "error": pipeline.safe_error(e),
                "stage": "Gagal", "elapsed": round(time.time() - t0, 1),
            })
    finally:
        pipeline.cleanup_workdir(wd)
        _save_history()


def _save_history():
    existing = {h["id"]: h for h in _load_history()}
    with LOCK:
        for jid, j in JOBS.items():
            if j.get("status") == "done" and j.get("meta"):
                m = j["meta"]
                existing[jid] = {
                    "id": jid, "created": j.get("created"),
                    "title": m.get("title"), "prompt": m.get("prompt"),
                    "mood": m.get("mood_label"), "duration": m.get("duration"),
                    "size": m.get("size"), "palette": m.get("palette"),
                    "mode": m.get("mode"), "width": m.get("width"), "height": m.get("height"),
                }
    hist = [h for h in existing.values()
            if os.path.exists(os.path.join(_job_dir(h["id"]), "out", "video.mp4"))]
    hist.sort(key=lambda x: -(x.get("created") or 0))
    with open(os.path.join(JOBS_DIR, "history.json"), "w", encoding="utf-8") as f:
        json.dump(hist[:40], f, ensure_ascii=False, indent=2)


def _load_history():
    p = os.path.join(JOBS_DIR, "history.json")
    if not os.path.exists(p):
        return []
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return []


def _params_from_request() -> tuple[dict, list[str]]:
    paths = []
    for i, f in enumerate(request.files.getlist("images")[:MAX_IMAGES]):
        if not f or not f.filename:
            continue
        ext = f.filename.rsplit(".", 1)[-1].lower()
        if ext not in ALLOWED_IMG:
            continue
        name = f"{uuid.uuid4().hex[:10]}_{i}.{ext}"
        p = os.path.join(UPLOADS, name)
        f.save(p)
        paths.append(p)

    def num(key, default, cast=float):
        v = request.form.get(key, None)
        try:
            return cast(v) if v not in (None, "") else default
        except Exception:
            return default

    params = {
        "prompt": (request.form.get("prompt") or "").strip()[:4000],
        "images": paths,
        "style": request.form.get("style") or "auto",
        "motion": request.form.get("motion") or "auto",
        "aspect": request.form.get("aspect") or "16:9",
        "resolution": request.form.get("resolution") or "720p",
        "fps": num("fps", 30, int),
        "duration": num("duration", 12, float),
        "scenes": num("scenes", 4, int),
        "transition": request.form.get("transition") or "fade",
        "overlap": num("overlap", 0.5, float),
        "motion_speed": num("motion_speed", 1.0, float),
        "grain": num("grain", 1.0, float),
        "bloom": num("bloom", 1.0, float),
        "chroma": num("chroma", 0.6, float),
        "letterbox": request.form.get("letterbox") == "on",
        "caption": request.form.get("caption") != "off",
        "subtitle": request.form.get("subtitle") != "off",
        "karaoke": request.form.get("karaoke") == "on",
        "music": request.form.get("music") != "off",
        "music_volume": num("music_volume", 0.34, float),
        "narration": request.form.get("narration") == "on",
        "voice": request.form.get("voice") or tts.DEFAULT_VOICE,
        "voice_speed": num("voice_speed", 1.0, float),
        "voice_volume": num("voice_volume", 1.0, float),
        "provider": request.form.get("provider") or "local",
        "cloud_model": request.form.get("cloud_model") or "",
    }
    params["duration"] = max(3.0, min(60.0, params["duration"]))
    params["fps"] = max(12, min(60, params["fps"]))
    params["scenes"] = max(1, min(8, params["scenes"]))
    return params, paths


# ------------------------------------------------------------------ routes

def _rebuild_history_on_boot():
    """Pulihkan galeri dari disk saat server start (job lama tidak hilang)."""
    existing = {h["id"]: h for h in _load_history()}
    try:
        for jid in os.listdir(JOBS_DIR):
            mp = os.path.join(JOBS_DIR, jid, "out", "meta.json")
            vp = os.path.join(JOBS_DIR, jid, "out", "video.mp4")
            if not (os.path.isfile(mp) and os.path.isfile(vp)):
                continue
            if jid in existing:
                continue
            try:
                m = json.load(open(mp, encoding="utf-8"))
                existing[jid] = {
                    "id": jid, "created": os.path.getmtime(vp),
                    "title": m.get("title"), "prompt": m.get("prompt"),
                    "mood": m.get("mood_label"), "duration": m.get("duration"),
                    "size": m.get("size"), "palette": m.get("palette"),
                    "mode": m.get("mode"), "width": m.get("width"), "height": m.get("height"),
                }
            except Exception:
                continue
        hist = sorted(existing.values(), key=lambda x: -(x.get("created") or 0))[:40]
        with open(os.path.join(JOBS_DIR, "history.json"), "w", encoding="utf-8") as f:
            json.dump(hist, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


_rebuild_history_on_boot()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/info")
def api_info():
    return jsonify({
        "app": "Aurora Studio",
        "version": "1.0.0",
        "ffmpeg": encoder.ffmpeg_exe(),
        "moods": planner.moods_catalog(),
        "voices": tts.voice_catalog(),
        "aspects": list(pipeline.ASPECTS.keys()),
        "resolutions": ["480p", "720p", "1080p"],
        "transitions": pipeline.TRANSITIONS,
        "providers": cloud.status(),
        "history": _load_history()[:12],
        "limits": {"max_images": MAX_IMAGES, "max_upload_mb": MAX_UPLOAD_MB},
    })


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    """Pratinjau storyboard tanpa merender video (cepat)."""
    prompt = (request.form.get("prompt") or request.json.get("prompt", "") if request.is_json
              else request.form.get("prompt") or "")
    if request.is_json:
        prompt = request.json.get("prompt", "")
        style = request.json.get("style", "auto")
        n = int(request.json.get("scenes", 4))
        dur = float(request.json.get("duration", 12))
    else:
        style = request.form.get("style", "auto")
        n = int(request.form.get("scenes", 4))
        dur = float(request.form.get("duration", 12))
    p = planner.plan(prompt, n_scenes=n, duration=dur, style=style)
    return jsonify({"ok": True, "plan": p})


@app.route("/api/generate", methods=["POST"])
def api_generate():
    params, paths = _params_from_request()
    if not params["prompt"] and not params["images"]:
        return jsonify({"ok": False, "error": "Isi prompt teks atau unggah minimal 1 gambar."}), 400

    # mode cloud (opsional, butuh API key)
    if params.get("provider") and params["provider"] not in ("local", "", None):
        if not cloud.is_configured(params["provider"]):
            return jsonify({"ok": False, "error":
                            f"Provider '{params['provider']}' belum dikonfigurasi. "
                            f"Isi API key di menu Cloud AI, atau pilih engine Lokal."}), 400
        job_id = "cloud-" + uuid.uuid4().hex[:10]
        with LOCK:
            JOBS[job_id] = {"id": job_id, "status": "queued", "progress": 0.02,
                            "created": time.time(), "params": {k: v for k, v in params.items()},
                            "stage": f"Mengirim ke {params['provider']}…", "cloud": True}
        POOL.submit(_run_cloud, job_id, params)
        return jsonify({"ok": True, "job_id": job_id, "cloud": True})

    job_id = uuid.uuid4().hex[:12]
    with LOCK:
        JOBS[job_id] = {"id": job_id, "status": "queued", "progress": 0.0,
                        "created": time.time(), "params": {k: v for k, v in params.items()
                                                           if k != "images"},
                        "stage": "Menunggu antrean…", "n_images": len(paths)}
    POOL.submit(_run, job_id, params)
    return jsonify({"ok": True, "job_id": job_id})


def _run_cloud(job_id: str, params: dict):
    od = os.path.join(_job_dir(job_id), "out")
    os.makedirs(od, exist_ok=True)
    try:
        def poll(state, _logs):
            _set(job_id, stage=f"Status provider: {state}", progress=0.5)
        res = cloud.generate(params["provider"], params["prompt"],
                             image_path=(params["images"][0] if params["images"] else None),
                             duration=int(min(10, max(3, params["duration"]))),
                             aspect=params["aspect"], model=params.get("cloud_model") or None,
                             poll=poll)
        _set(job_id, progress=0.9, stage="Mengunduh video hasil…")
        url = res.get("video_url")
        if not url:
            raise RuntimeError("Provider tidak mengembalikan URL video.")
        dest = os.path.join(od, "video.mp4")
        cloud.download(url, dest)
        info = encoder.probe(dest)
        meta = {"mode": "cloud", "provider": params["provider"], "model": res.get("model"),
                "prompt": params["prompt"], "title": planner.make_title(params["prompt"]),
                "duration": info["duration"], "size": info["size"], "cloud": True,
                "source_url": url, "mood_label": f"Cloud: {params['provider']}"}
        with open(os.path.join(od, "meta.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        _set(job_id, status="done", progress=1.0, stage="Selesai ✅", meta=meta,
             size=info["size"])
    except Exception as e:
        _set(job_id, status="error", error=pipeline.safe_error(e), stage="Gagal")
    finally:
        _save_history()


@app.route("/api/status/<job_id>")
def api_status(job_id):
    with LOCK:
        j = JOBS.get(job_id)
        if not j:
            return jsonify({"ok": False, "error": "Job tidak ditemukan"}), 404
        out = {k: v for k, v in j.items() if k not in ("params",)}
    return jsonify({"ok": True, "job": out})


@app.route("/api/gallery")
def api_gallery():
    items = _load_history()
    for it in items:
        it["has_video"] = os.path.exists(os.path.join(_job_dir(it["id"]), "out", "video.mp4"))
    return jsonify({"ok": True, "items": items})


@app.route("/api/gallery/<job_id>/delete", methods=["POST"])
def api_delete(job_id):
    job_id = secure_filename(job_id)
    shutil.rmtree(_job_dir(job_id), ignore_errors=True)
    hist = [h for h in _load_history() if h["id"] != job_id]
    with open(os.path.join(JOBS_DIR, "history.json"), "w", encoding="utf-8") as f:
        json.dump(hist, f, ensure_ascii=False, indent=2)
    with LOCK:
        JOBS.pop(job_id, None)
    return jsonify({"ok": True})


def _resolve(job_id: str, name: str) -> str:
    job_id = secure_filename(job_id)
    p = os.path.join(_job_dir(job_id), "out", name)
    if not os.path.exists(p):
        abort(404)
    return p


@app.route("/video/<job_id>")
def get_video(job_id):
    p = _resolve(job_id, "video.mp4")
    return send_file(p, mimetype="video/mp4", conditional=True)


@app.route("/poster/<job_id>")
def get_poster(job_id):
    p = _resolve(job_id, "poster.jpg")
    return send_file(p, mimetype="image/jpeg", conditional=True)


@app.route("/download/<job_id>")
def download(job_id):
    job_id_s = secure_filename(job_id)
    p = os.path.join(_job_dir(job_id_s), "out", "video.mp4")
    if not os.path.exists(p):
        abort(404)
    with LOCK:
        j = JOBS.get(job_id_s, {})
        meta = j.get("meta") or {}
    if not meta:
        mp = os.path.join(_job_dir(job_id_s), "out", "meta.json")
        if os.path.exists(mp):
            meta = json.load(open(mp, encoding="utf-8"))
    title = (meta.get("title") or "aurora-video").replace(" ", "-")[:40]
    return send_file(p, mimetype="video/mp4", as_attachment=True,
                     download_name=f"{title}-{job_id_s[:6]}.mp4")


@app.route("/download/<job_id>/<kind>")
def download_extra(job_id, kind):
    job_id_s = secure_filename(job_id)
    od = os.path.join(_job_dir(job_id_s), "out")
    mapping = {
        "srt": ("subtitle.srt", "application/x-subrip", "subtitle.srt"),
        "json": ("storyboard.json", "application/json", "storyboard.json"),
        "poster": ("poster.jpg", "image/jpeg", "poster.jpg"),
    }
    if kind not in mapping:
        abort(404)
    fn, mime, dl = mapping[kind]
    p = os.path.join(od, fn)
    if not os.path.exists(p):
        abort(404)
    return send_file(p, mimetype=mime, as_attachment=True, download_name=f"{job_id_s[:8]}-{dl}")


@app.route("/download/<job_id>/bundle")
def download_bundle(job_id):
    """ZIP berisi video + poster + subtitle + storyboard + metadata."""
    job_id_s = secure_filename(job_id)
    od = os.path.join(_job_dir(job_id_s), "out")
    if not os.path.exists(os.path.join(od, "video.mp4")):
        abort(404)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for fn in ("video.mp4", "poster.jpg", "subtitle.srt", "storyboard.json", "meta.json"):
            p = os.path.join(od, fn)
            if os.path.exists(p):
                z.write(p, arcname=fn)
        params = (JOBS.get(job_id_s) or {}).get("params")
        if params:
            z.writestr("pengaturan.json", json.dumps(params, ensure_ascii=False, indent=2))
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"aurora-{job_id_s[:8]}.zip")


@app.route("/sw.js")
def service_worker():
    resp = send_from_directory(os.path.join(ROOT, "static"), "sw.js",
                               mimetype="application/javascript")
    resp.headers["Cache-Control"] = "no-cache"
    resp.headers["Service-Worker-Allowed"] = "/"
    return resp


@app.route("/manifest.webmanifest")
def manifest():
    return send_from_directory(os.path.join(ROOT, "static"), "manifest.webmanifest",
                               mimetype="application/manifest+json")


KITS = {
    "windows": [("Windows", os.path.join(ROOT, "kits", "windows"))],
    "android": [("Android", os.path.join(ROOT, "kits", "android")),
                ("Android/apk-project", os.path.join(ROOT, "kits", "android-apk"))],
    "all": [("Windows", os.path.join(ROOT, "kits", "windows")),
            ("Android", os.path.join(ROOT, "kits", "android")),
            ("Android/apk-project", os.path.join(ROOT, "kits", "android-apk"))],
}


@app.route("/download/kit/<name>")
def download_kit(name: str):
    """ZIP siap pakai per platform: project + skrip platform terkait."""
    if name not in KITS:
        abort(404)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        prefix = "AuroraStudio"
        for base, dirs, files in os.walk(ROOT):
            dirs[:] = [d for d in dirs if d not in
                       ("outputs", "workspace", "__pycache__", ".git", "config", "kits", ".venv")]
            for fn in files:
                if fn.endswith((".pyc", ".log")):
                    continue
                p = os.path.join(base, fn)
                z.write(p, arcname=os.path.join(prefix, os.path.relpath(p, ROOT)))
        for arc_dir, src_dir in KITS[name]:
            if not os.path.isdir(src_dir):
                continue
            for base, dirs, files in os.walk(src_dir):
                for fn in files:
                    p = os.path.join(base, fn)
                    rel = os.path.relpath(p, src_dir)
                    z.write(p, arcname=os.path.join(prefix, arc_dir, rel))
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"AuroraStudio-{name.capitalize()}.zip")


@app.route("/download/source")
def download_source():
    """ZIP seluruh source code aplikasi (siap dijalankan lokal)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for base, dirs, files in os.walk(ROOT):
            dirs[:] = [d for d in dirs if d not in
                       ("outputs", "workspace", "__pycache__", ".git", "config")]
            for fn in files:
                if fn.endswith((".pyc", ".log")):
                    continue
                p = os.path.join(base, fn)
                z.write(p, arcname=os.path.join("ai-video-studio", os.path.relpath(p, ROOT)))
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name="aurora-ai-video-studio-source.zip")


@app.route("/api/cloud/status")
def cloud_status():
    return jsonify({"ok": True, "providers": cloud.status()})


@app.route("/api/cloud/keys", methods=["POST"])
def cloud_keys():
    data = request.get_json(silent=True) or {}
    keys = cloud.load_keys()
    for k, v in data.items():
        if v is None:
            continue
        keys[k] = str(v).strip()
    cloud.save_keys(keys)
    return jsonify({"ok": True, "providers": cloud.status()})


@app.route("/health")
def health():
    return jsonify({"ok": True, "ffmpeg": os.path.exists(encoder.ffmpeg_exe()),
                    "jobs": len(JOBS), "time": datetime.now().isoformat(timespec="seconds")})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    print(f"\n  🎬 Aurora Studio — AI Video Generator")
    print(f"  ➜  http://0.0.0.0:{port}\n")
    app.run(host="0.0.0.0", port=port, threaded=True, debug=False)
