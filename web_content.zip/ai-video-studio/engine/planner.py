"""
planner.py — "Otak" AI dari Aurora Studio.

Mengubah prompt teks bebas (ID/EN) menjadi storyboard:
  - deteksi mood / suasana  -> palet warna + elemen visual + motion
  - pemecahan kalimat       -> adegan (scene) + caption + teks narasi
  - kata kunci objek        -> elemen generatif (gunung, matahari, hujan, partikel, ...)

Semua deterministik (seeded) supaya hasil bisa direproduksi.
"""
from __future__ import annotations

import hashlib
import math
import random
import re
from dataclasses import dataclass, field, asdict
from typing import Any

# ---------------------------------------------------------------- palet mood

MOODS: dict[str, dict[str, Any]] = {
    "senja": {
        "label": "Senja / Sunset",
        "palette": ["#2b1055", "#7597de", "#ff9e6d", "#ffd6a5", "#ff5e62"],
        "sky": "gradient",
        "elements": ["sun", "clouds", "mountains", "birds", "dust"],
        "glow": 0.85, "grain": 0.05, "sat": 1.18, "contrast": 1.06,
        "temp": 12, "motion": "slow", "music": "warm",
    },
    "neon": {
        "label": "Neon / Cyberpunk",
        "palette": ["#05010f", "#1b0b3a", "#ff2bd6", "#00e5ff", "#7b2bff"],
        "sky": "city",
        "elements": ["skyline", "grid", "rain", "streaks", "bokeh"],
        "glow": 1.15, "grain": 0.07, "sat": 1.35, "contrast": 1.12,
        "temp": -8, "motion": "fast", "music": "synthwave",
    },
    "laut": {
        "label": "Laut / Underwater",
        "palette": ["#012a4a", "#01497c", "#2a9d8f", "#7fd1c1", "#e9f5f2"],
        "sky": "gradient",
        "elements": ["waves", "bubbles", "rays", "fish", "dust"],
        "glow": 0.7, "grain": 0.04, "sat": 1.1, "contrast": 1.04,
        "temp": -14, "motion": "slow", "music": "ambient",
    },
    "hutan": {
        "label": "Hutan / Nature",
        "palette": ["#0b2016", "#1b4332", "#2d6a4f", "#74c69d", "#d8f3dc"],
        "sky": "gradient",
        "elements": ["hills", "fog", "fireflies", "leaves", "rays"],
        "glow": 0.65, "grain": 0.05, "sat": 1.12, "contrast": 1.05,
        "temp": -4, "motion": "slow", "music": "ambient",
    },
    "kosmik": {
        "label": "Kosmik / Space",
        "palette": ["#030014", "#1a0b3d", "#5f27cd", "#00d2ff", "#ffffff"],
        "sky": "space",
        "elements": ["stars", "nebula", "planet", "streaks", "dust"],
        "glow": 1.25, "grain": 0.06, "sat": 1.25, "contrast": 1.1,
        "temp": -10, "motion": "medium", "music": "ambient",
    },
    "minimal": {
        "label": "Minimal / Clean",
        "palette": ["#f7f5f2", "#e8e4de", "#c9c2b6", "#4a4a4a", "#111111"],
        "sky": "flat",
        "elements": ["shapes", "dust"],
        "glow": 0.35, "grain": 0.03, "sat": 0.92, "contrast": 1.02,
        "temp": 0, "motion": "slow", "music": "minimal",
    },
    "hujan": {
        "label": "Hujan / Moody",
        "palette": ["#101820", "#1f2d3d", "#3e5c76", "#748cab", "#d9d2c5"],
        "sky": "clouds",
        "elements": ["rain", "fog", "city", "bokeh"],
        "glow": 0.55, "grain": 0.08, "sat": 0.85, "contrast": 1.08,
        "temp": -18, "motion": "medium", "music": "ambient",
    },
    "retro": {
        "label": "Retro / VHS",
        "palette": ["#2d1b4e", "#f2789f", "#ffc857", "#4ecdc4", "#f7fff7"],
        "sky": "gradient",
        "elements": ["sun", "grid", "stripes", "streaks"],
        "glow": 0.9, "grain": 0.12, "sat": 1.3, "contrast": 1.14,
        "temp": 8, "motion": "medium", "music": "synthwave",
    },
    "api": {
        "label": "Api / Dramatis",
        "palette": ["#1a0000", "#6a040f", "#dc2f02", "#f48c06", "#ffba08"],
        "sky": "gradient",
        "elements": ["embers", "smoke", "rays", "streaks"],
        "glow": 1.05, "grain": 0.09, "sat": 1.25, "contrast": 1.16,
        "temp": 18, "motion": "fast", "music": "epic",
    },
    "mimpi": {
        "label": "Mimpi / Dreamy",
        "palette": ["#241b4f", "#6c5ce7", "#fd79a8", "#ffeaa7", "#dff9fb"],
        "sky": "gradient",
        "elements": ["bokeh", "clouds", "petals", "dust", "rays"],
        "glow": 0.95, "grain": 0.04, "sat": 1.15, "contrast": 1.0,
        "temp": 4, "motion": "slow", "music": "dream",
    },
    "salju": {
        "label": "Salju / Winter",
        "palette": ["#1b2a41", "#415a77", "#a8c6e0", "#e0e8f0", "#ffffff"],
        "sky": "gradient",
        "elements": ["snow", "hills", "fog", "pines"],
        "glow": 0.6, "grain": 0.05, "sat": 0.95, "contrast": 1.06,
        "temp": -20, "motion": "slow", "music": "ambient",
    },
    "kota": {
        "label": "Kota / Urban",
        "palette": ["#0d1117", "#22262e", "#4c5b6b", "#f0a202", "#f7f3e3"],
        "sky": "city",
        "elements": ["skyline", "traffic", "bokeh", "streaks", "dust"],
        "glow": 0.8, "grain": 0.06, "sat": 1.05, "contrast": 1.1,
        "temp": -2, "motion": "medium", "music": "synthwave",
    },
}

DEFAULT_MOOD = "senja"

# ------------------------------------------------------- kamus kata kunci ID/EN

MOOD_KEYWORDS: dict[str, list[str]] = {
    "senja": ["senja", "sunset", "matahari terbenam", "golden hour", "maghrib", "dusk",
              "jingga", "orange sky", "twilight", "petang"],
    "neon": ["neon", "cyberpunk", "futuristik", "futuristic", "sci-fi", "scifi", "robot",
             "tokyo", "malam kota", "glow", "hologram", "teknologi", "tech", "ai ",
             "digital", "matrix", "siber", "cyber"],
    "laut": ["laut", "ocean", "sea", "pantai", "beach", "ombak", "wave", "bawah laut",
             "underwater", "ikan", "fish", "biru", "marine", "coral", "terumbu", "diving"],
    "hutan": ["hutan", "forest", "alam", "nature", "pohon", "tree", "daun", "leaf",
              "gunung hijau", "jungle", "tropis", "tropical", "sawah", "kebun", "bambu"],
    "kosmik": ["luar angkasa", "space", "galaksi", "galaxy", "bintang", "star", "nebula",
               "planet", "astronaut", "kosmik", "cosmic", "universe", "semesta", "roket",
               "rocket", "milky way"],
    "minimal": ["minimal", "minimalis", "clean", "sederhana", "simple", "elegan", "elegant",
                "putih", "white", "produk", "product", "branding", "logo", "perusahaan",
                "corporate", "profesional"],
    "hujan": ["hujan", "rain", "mendung", "cloudy", "kelabu", "gray", "galau", "sedih",
              "sad", "melankolis", "kopi", "coffee", "jendela", "window"],
    "retro": ["retro", "80an", "80s", "vhs", "vaporwave", "synthwave", "jadul", "vintage",
              "klasik", "classic", "kaset", "arcade", "pixel"],
    "api": ["api", "fire", "kebakaran", "lava", "gunung berapi", "volcano", "ledakan",
            "explosion", "epic", "dramatis", "dramatic", "perang", "battle", "dragon",
            "naga", "phoenix"],
    "mimpi": ["mimpi", "dream", "fantasi", "fantasy", "khayalan", "magis", "magic",
              "peri", "fairy", "pastel", "lembut", "soft", "bunga", "flower", "sakura"],
    "salju": ["salju", "snow", "musim dingin", "winter", "es", "ice", "dingin", "cold",
              "beku", "frozen", "kutub", "arctic"],
    "kota": ["kota", "city", "urban", "gedung", "building", "skyline", "jalan", "street",
             "lalu lintas", "traffic", "jakarta", "metropolitan", "skyscraper", "kota besar"],
}

# elemen tambahan yang dipicu kata kunci spesifik
EXTRA_ELEMENTS: dict[str, list[str]] = {
    "rain": ["hujan", "rain", "gerimis", "drizzle"],
    "snow": ["salju", "snow"],
    "fireflies": ["kunang", "firefl", "hutan malam"],
    "petals": ["bunga", "flower", "sakura", "kelopak", "petal"],
    "leaves": ["daun", "leaf", "gugur"],
    "bubbles": ["gelembung", "bubble", "air"],
    "fish": ["ikan", "fish"],
    "birds": ["burung", "bird"],
    "stars": ["bintang", "star"],
    "planet": ["planet", "bumi", "earth", "bulan", "moon"],
    "nebula": ["nebula", "galaksi", "galaxy"],
    "sun": ["matahari", "sun", "senja", "sunset"],
    "moon": ["bulan", "moon", "malam"],
    "skyline": ["kota", "city", "gedung", "skyline"],
    "mountains": ["gunung", "mountain", "bukit", "hill", "pegunungan"],
    "waves": ["ombak", "wave", "laut", "ocean"],
    "pines": ["pinus", "pine", "cemara"],
    "embers": ["api", "fire", "bara"],
    "smoke": ["asap", "smoke", "kabut"],
    "fog": ["kabut", "fog", "mist", "berkabut"],
    "grid": ["grid", "retro", "synthwave", "neon"],
    "traffic": ["macet", "traffic", "mobil", "car", "kendaraan"],
    "clouds": ["awan", "cloud"],
    "rays": ["cahaya", "light", "sinar", "ray", "godray"],
    "bokeh": ["bokeh", "lampu", "light", "kemilau"],
    "rings": ["cincin", "ring", "orbit", "lingkaran"],
    "streaks": ["kecepatan", "speed", "vroom", "garis cahaya", "streak"],
}

MOTION_HINT = {
    "slow": ["tenang", "calm", "pelan", "slow", "damai", "peace", "hening", "lembut"],
    "fast": ["cepat", "fast", "energi", "energy", "dinamis", "dynamic", "balap", "race",
             "aksi", "action", "intens"],
}

TITLE_HINT_WORDS = {
    "video", "buat", "buatkan", "tolong", "generate", "buatlah", "cara", "sebuah",
    "yang", "dengan", "untuk", "dan", "atau", "the", "make", "create", "please",
    "a", "an", "of", "in", "on", "with", "tampilkan", "berisi", "tentang",
}

STOPWORDS = set("""yang di ke dari pada dalam dengan untuk dan atau ini itu adalah
sebuah secara akan sudah telah bisa dapat nya para kami saya anda kita agar supaya
ketika saat sambil lalu kemudian video buat buatkan tolong generate tampilkan adegan
scene tentang berdurasi detik menit high quality hd 4k keren bagus indah sekali sangat
the of and to in for with on create make please this that is are be a an""".split())


def _hash_seed(text: str) -> int:
    return int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:12], 16)


def _split_sentences(text: str) -> list[str]:
    """Pecah prompt jadi kalimat/frasa -> kandidat adegan."""
    text = text.strip()
    # pisah: titik, koma, titik-koma, newline, "lalu/kemudian/dan lalu"
    parts = re.split(r"[\n\r]+|[.;]|,\s|\s+[-–—|]\s+|\blalu\b|\bkemudian\b|\bselanjutnya\b|\bthen\b|\bnext\b", text)
    out = []
    for p in parts:
        p = re.sub(r"\s+", " ", p).strip(" .,;:-–—")
        if len(p) >= 3:
            out.append(p)
    return out


def detect_mood(text: str) -> tuple[str, list[tuple[str, int]]]:
    low = text.lower()
    scores: list[tuple[str, int]] = []
    for mood, kws in MOOD_KEYWORDS.items():
        s = 0
        for kw in kws:
            if kw in low:
                s += 2 if len(kw) > 4 else 1
        if s:
            scores.append((mood, s))
    scores.sort(key=lambda x: -x[1])
    return (scores[0][0] if scores else DEFAULT_MOOD), scores


def detect_motion(text: str, base: str) -> str:
    low = text.lower()
    for motion, kws in MOTION_HINT.items():
        if any(k in low for k in kws):
            return motion
    return base


def detect_extra_elements(text: str) -> list[str]:
    low = text.lower()
    found = []
    for el, kws in EXTRA_ELEMENTS.items():
        if any(k in low for k in kws):
            found.append(el)
    return found


def keywords_of(text: str, limit: int = 6) -> list[str]:
    words = re.findall(r"[A-Za-z\u00c0-\u024f']{3,}", text.lower())
    seen, out = set(), []
    for w in words:
        if w in STOPWORDS or w in seen:
            continue
        seen.add(w)
        out.append(w)
        if len(out) >= limit:
            break
    return out


def make_title(text: str) -> str:
    """Judul singkat untuk overlay adegan pembuka."""
    words = [w for w in re.findall(r"[\w'-]+", text) if w.lower() not in TITLE_HINT_WORDS]
    if not words:
        words = text.split()
    title = " ".join(words[:6]).strip()
    return title[:52].title() if title else "Untitled Story"


def wrap_lines(text: str, per_line: int = 34, max_lines: int = 3) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 <= per_line:
            cur = (cur + " " + w).strip()
        else:
            if cur:
                lines.append(cur)
            cur = w
        if len(lines) >= max_lines:
            break
    if cur and len(lines) < max_lines:
        lines.append(cur)
    return lines[:max_lines]


@dataclass
class Scene:
    index: int
    text: str                 # kalimat sumber
    caption: str              # teks overlay (pendek)
    narration: str            # teks untuk TTS / subtitle
    mood: str
    elements: list[str] = field(default_factory=list)
    seed: int = 0
    duration: float = 3.0
    motion: str = "slow"
    camera: dict = field(default_factory=dict)
    palette: list[str] = field(default_factory=list)
    image: str | None = None  # path gambar bila mode image-to-video
    grade: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


CAMERA_MOVES = [
    {"name": "zoom_in",    "z0": 1.00, "z1": 1.22, "px": 0.00, "py": 0.00, "px1": 0.00, "py1": -0.02},
    {"name": "zoom_out",   "z0": 1.24, "z1": 1.00, "px": 0.00, "py": -0.02, "px1": 0.00, "py1": 0.00},
    {"name": "pan_right",  "z0": 1.16, "z1": 1.16, "px": -0.05, "py": 0.00, "px1": 0.05, "py1": 0.00},
    {"name": "pan_left",   "z0": 1.16, "z1": 1.16, "px": 0.05, "py": 0.00, "px1": -0.05, "py1": 0.00},
    {"name": "tilt_up",    "z0": 1.18, "z1": 1.18, "px": 0.00, "py": 0.05, "px1": 0.00, "py1": -0.05},
    {"name": "drift",      "z0": 1.06, "z1": 1.18, "px": -0.03, "py": 0.02, "px1": 0.03, "py1": -0.02},
    {"name": "hold",       "z0": 1.08, "z1": 1.08, "px": 0.00, "py": 0.00, "px1": 0.00, "py1": 0.00},
]


def plan(
    prompt: str,
    *,
    n_scenes: int = 4,
    duration: float = 12.0,
    style: str = "auto",
    motion: str = "auto",
    images: list[str] | None = None,
) -> dict[str, Any]:
    """Bangun storyboard lengkap dari prompt (+opsional gambar)."""
    prompt = (prompt or "").strip() or "Cerita visual sinematik tanpa kata"
    images = images or []
    rng = random.Random(_hash_seed(prompt + style))

    base_mood, mood_hits = detect_mood(prompt)
    if style not in ("auto", "", None) and style in MOODS:
        base_mood = style

    sentences = _split_sentences(prompt)
    img_texts: list[str] = []
    if images:
        # mode image-to-video: 1 adegan per gambar, teks prompt jadi narasi/caption
        chunks = images[:]
        texts = sentences[:] if sentences else ([prompt] if prompt else [])
        n_scenes = max(1, min(len(images), 8))
        if texts:
            per = max(1, math.ceil(len(texts) / max(1, len(chunks))))
            img_texts = [" ".join(texts[i:i + per]) for i in range(0, len(texts), per)]
        while len(img_texts) < len(chunks):
            img_texts.append(prompt or f"Adegan {len(img_texts) + 1}")
    else:
        n_scenes = max(1, min(n_scenes, 8))
        if len(sentences) >= n_scenes:
            # bagi rata kalimat ke n adegan
            per = math.ceil(len(sentences) / n_scenes)
            chunks = [" ".join(sentences[i:i + per]) for i in range(0, len(sentences), per)][:n_scenes]
        else:
            chunks = sentences[:] or [prompt]
        n_scenes = len(chunks)
        while n_scenes < len(chunks):
            n_scenes += 1

    per_scene = max(1.6, duration / max(1, n_scenes))
    title = make_title(prompt)
    extra = detect_extra_elements(prompt)

    base = MOODS[base_mood]
    base_score = dict(mood_hits).get(base_mood, 0)

    scenes: list[Scene] = []
    for i, chunk in enumerate(chunks):
        chunk = chunk.strip()
        if not chunk:
            continue
        mood = base_mood
        if style in ("auto", "", None):
            # variasi mood antar adegan hanya bila sinyal lokal KUAT
            local, local_hits = detect_mood(chunk)
            local_score = dict(local_hits).get(local, 0)
            if local != base_mood and local_score >= 3 and local_score >= base_score:
                mood = local
        m = MOODS[mood]
        elements = list(m["elements"])
        for e in detect_extra_elements(chunk):
            if e not in elements:
                elements.append(e)
        for e in extra:
            if e not in elements:
                elements.append(e)
        low_chunk = chunk.lower()
        if "meteor" in low_chunk:  # "hujan meteor" = streak cahaya, bukan hujan air
            elements = [e for e in elements if e != "rain"]
            for e in ("streaks", "stars"):
                if e not in elements:
                    elements.append(e)

        motion_scene = motion if motion in ("slow", "medium", "fast") else detect_motion(chunk, m["motion"])
        cam = CAMERA_MOVES[rng.randrange(len(CAMERA_MOVES))]
        # adegan pertama & terakhir lebih "tenang"
        if i == 0 and cam["name"] not in ("zoom_in", "drift", "hold"):
            cam = CAMERA_MOVES[0]
        if i == len(chunks) - 1 and cam["name"] in ("pan_right", "pan_left"):
            cam = CAMERA_MOVES[1]

        img = None
        src_text = chunk
        if images:
            img = images[i] if i < len(images) else images[i % len(images)]
            src_text = img_texts[i] if i < len(img_texts) else (prompt or f"Adegan {i + 1}")

        narration = re.sub(r"\s+", " ", src_text)
        caption = narration if len(narration) <= 68 else " ".join(narration.split()[:9]) + "…"
        scenes.append(Scene(
            index=len(scenes),
            text=narration,
            caption=title if (len(scenes) == 0 and not images) else caption,
            narration=narration,
            mood=mood,
            elements=elements[:9],
            seed=_hash_seed(prompt + str(i) + mood),
            duration=round(per_scene, 3),
            motion=motion_scene,
            camera=cam,
            palette=list(m["palette"]),
            image=img,
            grade={
                "glow": m["glow"], "grain": m["grain"], "sat": m["sat"],
                "contrast": m["contrast"], "temp": m["temp"],
            },
        ))

    if not scenes:  # fallback
        scenes.append(Scene(0, prompt, title, prompt, base_mood, list(MOODS[base_mood]["elements"]),
                            _hash_seed(prompt), duration, "slow", CAMERA_MOVES[0],
                            list(MOODS[base_mood]["palette"]), images[0] if images else None,
                            {k: MOODS[base_mood][k] for k in ("glow", "grain", "sat", "contrast", "temp")}))

    # normalisasi durasi agar total = duration
    total = sum(s.duration for s in scenes)
    scale = duration / total if total else 1.0
    for s in scenes:
        s.duration = round(max(1.5, s.duration * scale), 3)

    base = MOODS[base_mood]
    return {
        "prompt": prompt,
        "title": title,
        "mood": base_mood,
        "mood_label": base["label"],
        "mood_scores": [{"mood": m, "score": s} for m, s in mood_hits[:4]],
        "palette": base["palette"],
        "music_style": base["music"],
        "keywords": keywords_of(prompt),
        "scenes": [s.to_dict() for s in scenes],
        "duration": round(sum(s.duration for s in scenes), 3),
    }


def moods_catalog() -> list[dict[str, Any]]:
    return [{"id": k, "label": v["label"], "palette": v["palette"], "elements": v["elements"]}
            for k, v in MOODS.items()]


if __name__ == "__main__":
    import json
    p = plan("Video senja di pantai dengan ombak tenang, lalu burung terbang, kemudian langit berubah ungu",
             n_scenes=3, duration=12)
    print(json.dumps(p, ensure_ascii=False, indent=2)[:2200])
