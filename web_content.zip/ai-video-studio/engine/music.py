"""
music.py — Sintesis musik latar (ambient/cinematic) murni dengan numpy.
Tidak butuh file audio eksternal maupun internet.

Gaya: ambient, warm, synthwave, epic, minimal, dream.
Output: WAV 44.1 kHz stereo.
"""
from __future__ import annotations

import math
import wave

import numpy as np

SR = 44100

# progresi akor (root MIDI, kualitas)
PROGRESSIONS = {
    "ambient":   [(57, "min"), (53, "maj"), (50, "maj"), (55, "min")],
    "warm":      [(52, "maj"), (57, "min"), (61, "maj"), (54, "min")],
    "synthwave": [(45, "min"), (52, "maj"), (48, "maj"), (50, "maj")],
    "epic":      [(40, "min"), (48, "maj"), (45, "min"), (43, "maj")],
    "minimal":   [(55, "maj"), (59, "min"), (52, "maj"), (57, "min")],
    "dream":     [(54, "maj"), (59, "min"), (61, "maj"), (56, "min")],
}

CHORDS = {
    "maj": [0, 4, 7, 11],
    "min": [0, 3, 7, 10],
    "sus": [0, 5, 7, 12],
}


def midi2freq(m: float) -> float:
    return 440.0 * (2 ** ((m - 69) / 12.0))


def _adsr(n: int, a: float, d: float, s: float, r: float) -> np.ndarray:
    env = np.zeros(n, np.float32)
    ai = int(n * a)
    di = int(n * d)
    ri = int(n * r)
    si = max(0, n - ai - di - ri)
    i = 0
    if ai:
        env[i:i + ai] = np.linspace(0, 1, ai)
        i += ai
    if di:
        env[i:i + di] = np.linspace(1, s, di)
        i += di
    if si:
        env[i:i + si] = s
        i += si
    if ri and i < n:
        env[i:n] = np.linspace(s, 0, n - i)
    return env


def _sine(freq: float, dur: float, phase: float = 0.0) -> np.ndarray:
    n = int(SR * dur)
    t = np.arange(n, dtype=np.float32) / SR
    return np.sin(2 * math.pi * freq * t + phase).astype(np.float32)


def _pad(freq: float, dur: float, detune: float = 0.0035, bright: float = 0.5) -> np.ndarray:
    """Pad hangat: beberapa saw/sine terdetune + lowpass sederhana."""
    n = int(SR * dur)
    t = np.arange(n, dtype=np.float32) / SR
    out = np.zeros(n, np.float32)
    for k, amp in ((1, 1.0), (2, 0.32 * bright), (3, 0.12 * bright)):
        for d in (-detune, detune * 1.7):
            ph = float(np.random.random() * 6.28)
            out += amp * 0.5 * np.sin(2 * math.pi * freq * k * t * (1 + d) + ph).astype(np.float32)
    env = _adsr(n, 0.28, 0.12, 0.75, 0.34)
    return (out * env).astype(np.float32)


def _pluck(freq: float, dur: float) -> np.ndarray:
    n = int(SR * dur)
    t = np.arange(n, dtype=np.float32) / SR
    sig = (np.sin(2 * math.pi * freq * t) * 0.7 +
           np.sin(2 * math.pi * freq * 2 * t) * 0.22 +
           np.sin(2 * math.pi * freq * 3.01 * t) * 0.08)
    env = np.exp(-t * 3.2).astype(np.float32)
    return (sig * env).astype(np.float32)


def _kick(dur: float = 0.32) -> np.ndarray:
    n = int(SR * dur)
    t = np.arange(n, dtype=np.float32) / SR
    f = 110 * np.exp(-t * 22) + 44
    ph = 2 * math.pi * np.cumsum(f) / SR
    return (np.sin(ph) * np.exp(-t * 9)).astype(np.float32)


def _hat(dur: float = 0.09, seed: int = 0) -> np.ndarray:
    n = int(SR * dur)
    rng = np.random.default_rng(seed)
    t = np.arange(n, dtype=np.float32) / SR
    noise = rng.standard_normal(n).astype(np.float32)
    # highpass kasar
    hp = noise[1:] - noise[:-1]
    hp = np.concatenate([hp, [0]])
    return (hp * np.exp(-t * 55) * 0.5).astype(np.float32)


def _noise_sweep(dur: float, seed: int = 1) -> np.ndarray:
    n = int(SR * dur)
    rng = np.random.default_rng(seed)
    noise = rng.standard_normal(n).astype(np.float32)
    t = np.linspace(0, 1, n, dtype=np.float32)
    env = np.sin(math.pi * t) ** 2
    # lowpass progresif (moving average yang melebar)
    out = np.copy(noise)
    k = 8
    for _ in range(3):
        out = np.convolve(out, np.ones(k) / k, mode="same")
    return (out * env * 0.28).astype(np.float32)


def _reverb(x: np.ndarray, decay: float = 0.35, taps: int = 9) -> np.ndarray:
    out = np.copy(x)
    n = len(x)
    rng = np.random.default_rng(7)
    for i in range(1, taps + 1):
        delay = int(SR * (0.03 + 0.055 * i + rng.random() * 0.02))
        if delay >= n:
            break
        g = decay ** (i * 0.62)
        out[delay:] += x[:-delay] * g
    peak = np.max(np.abs(out)) or 1.0
    return (out / peak * min(peak, 1.0)).astype(np.float32)


def compose(duration: float, style: str = "ambient", intensity: float = 1.0,
            seed: int = 1234, fade_out: float = 1.4) -> np.ndarray:
    """Buat musik stereo float32 mono-sum, panjang = duration detik."""
    rng = np.random.default_rng(seed)
    style = style if style in PROGRESSIONS else "ambient"
    prog = PROGRESSIONS[style]
    total = int(SR * duration)
    L = np.zeros(total, np.float32)
    R = np.zeros(total, np.float32)

    chord_dur = max(2.0, duration / max(1, len(prog)) * (1.0 if style != "epic" else 1.0))
    # pad akor
    pos = 0
    i = 0
    while pos < total:
        root, qual = prog[i % len(prog)]
        notes = CHORDS[qual]
        seg_n = int(SR * chord_dur)
        seg = np.zeros(seg_n + SR, np.float32)
        for j, iv in enumerate(notes):
            f = midi2freq(root + iv + (12 if j % 2 == 0 else 0))
            p = _pad(f, chord_dur * 1.25, detune=0.003 + 0.001 * j,
                     bright=0.75 if style in ("synthwave", "dream") else 0.4)
            off = int(j * SR * 0.035)
            end = min(len(seg), off + len(p))
            seg[off:end] += p[:end - off] * (0.55 if style == "minimal" else 0.72)
        # bass
        bf = midi2freq(root - 24)
        bass = _sine(bf, chord_dur * 1.1) * _adsr(len(_sine(bf, chord_dur * 1.1)), 0.1, 0.2, 0.8, 0.3)
        seg[:len(bass)] += bass * (0.5 if style in ("epic", "synthwave") else 0.33)
        end = min(total, pos + seg_n)
        L[pos:end] += seg[:end - pos] * 0.92
        R[pos:end] += seg[:end - pos] * 0.92
        # arpeggio / pluck
        if style in ("synthwave", "dream", "minimal", "warm"):
            steps = 8
            for s_i in range(steps):
                tpos = pos + int(s_i * chord_dur * SR / steps)
                if tpos >= total:
                    break
                note = root + 12 + notes[(s_i * 3 + i) % len(notes)]
                pl = _pluck(midi2freq(note), 0.9) * (0.16 * intensity)
                e = min(len(L), tpos + len(pl))
                tgt = R if s_i % 2 else L
                tgt[tpos:e] += pl[:e - tpos]
        pos += seg_n
        i += 1

    # perkusi ringan
    if style in ("synthwave", "epic"):
        bpm = 96 if style == "synthwave" else 74
        beat = 60.0 / bpm
        t = 0.0
        bi = 0
        while t < duration:
            idx = int(t * SR)
            if idx < total:
                if bi % 4 == 0:
                    k = _kick() * (0.55 * intensity)
                    e = min(total, idx + len(k))
                    L[idx:e] += k[:e - idx]
                    R[idx:e] += k[:e - idx]
                if style == "synthwave" and bi % 2 == 1:
                    h = _hat(seed=bi) * (0.16 * intensity)
                    e = min(total, idx + len(h))
                    R[idx:e] += h[:e - idx]
                    L[idx:e] += h[:e - idx] * 0.7
            t += beat / 2
            bi += 1

    # riser / sweep tiap pergantian progresi
    sweep_n = int(SR * min(3.0, duration * 0.35))
    if sweep_n > SR // 4:
        sw = _noise_sweep(sweep_n / SR, seed=int(rng.integers(1e6))) * (0.5 * intensity)
        for k in range(0, total - sweep_n, int(chord_dur * SR * 2)):
            e = min(total, k + sweep_n)
            L[k:e] += sw[:e - k] * 0.5
            R[k:e] += sw[:e - k] * 0.5

    L = _reverb(L, decay=0.42 if style != "minimal" else 0.28)
    R = _reverb(R, decay=0.42 if style != "minimal" else 0.28)

    st = np.stack([L, R], axis=1)
    # fade in/out
    fi = int(SR * min(1.2, duration * 0.12))
    fo = int(SR * min(fade_out, duration * 0.3))
    if fi:
        st[:fi] *= np.linspace(0, 1, fi, dtype=np.float32)[:, None]
    if fo:
        st[-fo:] *= np.linspace(1, 0, fo, dtype=np.float32)[:, None] ** 1.4
    peak = float(np.max(np.abs(st)) or 1.0)
    st = st / peak * 0.82
    return st.astype(np.float32)


def write_wav(path: str, data: np.ndarray, sr: int = SR) -> str:
    if data.ndim == 1:
        data = np.stack([data, data], axis=1)
    pcm = np.clip(data, -1, 1)
    pcm16 = (pcm * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm16.tobytes())
    return path


def generate_music(path: str, duration: float, style: str = "ambient",
                   intensity: float = 1.0, seed: int = 1234) -> str:
    return write_wav(path, compose(duration, style, intensity, seed))


if __name__ == "__main__":
    import sys
    generate_music(sys.argv[1] if len(sys.argv) > 1 else "/tmp/music.wav",
                   float(sys.argv[2]) if len(sys.argv) > 2 else 12.0,
                   sys.argv[3] if len(sys.argv) > 3 else "ambient")
    print("ok")
