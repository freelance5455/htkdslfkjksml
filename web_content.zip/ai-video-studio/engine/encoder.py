"""
encoder.py — Perakitan video: render frame -> pipe ke ffmpeg (H.264/AAC MP4),
transisi antar adegan (xfade), mixing narasi + musik, ekspor poster & SRT.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess
import time
from typing import Callable

import numpy as np
from PIL import Image

from . import music, planner, tts, visual

FFMPEG = None


def _ffmpeg_works(path: str) -> bool:
    try:
        r = subprocess.run([path, "-version"], capture_output=True, timeout=20)
        return r.returncode == 0
    except Exception:
        return False


def ffmpeg_exe() -> str:
    """Cari ffmpeg: env AURORA_FFMPEG -> imageio-ffmpeg -> ffmpeg sistem.

    Fallback ke ffmpeg sistem penting untuk platform di mana binary bundel
    imageio-ffmpeg tidak kompatibel (mis. Android/Termux ARM).
    """
    global FFMPEG
    if FFMPEG:
        return FFMPEG
    env = os.environ.get("AURORA_FFMPEG")
    if env and os.path.exists(env):
        FFMPEG = env
        return FFMPEG
    try:
        import imageio_ffmpeg
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if p and os.path.exists(p) and _ffmpeg_works(p):
            FFMPEG = p
            return FFMPEG
    except Exception:
        pass
    sysff = shutil.which("ffmpeg")
    if sysff and _ffmpeg_works(sysff):
        FFMPEG = sysff
        return FFMPEG
    # upaya terakhir: apa pun yang tersedia
    if env:
        return env
    if sysff:
        return sysff
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        raise RuntimeError("ffmpeg tidak ditemukan. Instal ffmpeg atau pip install imageio-ffmpeg.")


def run(cmd: list[str], timeout: int = 900) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


# ------------------------------------------------------------------ subtitle

def build_srt(scenes: list[dict], overlaps: float, out_path: str) -> list[dict]:
    lines, t = [], 0.0
    timing = []
    for i, sc in enumerate(scenes):
        start = t
        dur = float(sc["duration"])
        timing.append({"index": i, "start": round(start, 3), "end": round(start + dur, 3),
                       "text": sc.get("narration", "")})
        txt = sc.get("narration", "").strip()
        if txt:
            for j, chunk in enumerate(_split_for_srt(txt, 2)):
                cs = start + 0.15 + (dur - 0.3) * (j / max(1, len(_split_for_srt(txt, 2))))
                ce = start + 0.15 + (dur - 0.3) * ((j + 1) / max(1, len(_split_for_srt(txt, 2))))
                lines.append(f"{len(lines) + 1}\n{_ts(cs)} --> {_ts(ce)}\n{chunk}\n")
        t += dur - (overlaps if i < len(scenes) - 1 else 0.0)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return timing


def _split_for_srt(text: str, n: int) -> list[str]:
    words = text.split()
    if len(words) <= n * 5:
        return [" ".join(words)]
    per = int(np.ceil(len(words) / n))
    return [" ".join(words[i:i + per]) for i in range(0, len(words), per)]


def _ts(sec: float) -> str:
    ms = int(round((sec - int(sec)) * 1000))
    s = int(sec) % 60
    m = (int(sec) // 60) % 60
    h = int(sec) // 3600
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


# ------------------------------------------------------------------ rendering

def render_scene_clip(scene: dict, out_mp4: str, W: int, H: int, fps: int,
                      opts: dict, progress: Callable[[float, str], None] | None = None,
                      base_prog: float = 0.0, prog_span: float = 0.1,
                      subtitle_text: str | None = None) -> str:
    dur = float(scene["duration"])
    n_frames = max(1, int(round(dur * fps)))
    renderer = visual.SceneRenderer(
        scene, W, H, fps=fps,
        style_strength=opts.get("motion", 1.0),
        grain=opts.get("grain", 1.0),
        bloom=opts.get("bloom", 1.0),
        ca=opts.get("ca", 1.0),
        letterbox=opts.get("letterbox", False),
    )
    renderer.build_base()

    cmd = [ffmpeg_exe(), "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", f"{W}x{H}", "-r", str(fps), "-i", "-",
           "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", out_mp4]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                            stderr=subprocess.PIPE)
    try:
        for i in range(n_frames):
            t = i / fps
            arr = renderer.render(t)
            if subtitle_text and opts.get("subtitle", False):
                prog = -1.0
                if opts.get("karaoke") and dur > 0:
                    prog = clamp01((t - 0.15) / max(0.1, dur - 0.3))
                arr = visual.burn_subtitle(arr, subtitle_text, H, W, progress=prog)
            proc.stdin.write(arr.tobytes())
            if progress and i % 6 == 0:
                progress(base_prog + prog_span * (i / max(1, n_frames)),
                         f"Merender adegan {scene.get('index', 0) + 1}: frame {i + 1}/{n_frames}")
    finally:
        proc.stdin.close()
        err = proc.stderr.read().decode("utf-8", "ignore")
        proc.wait()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg gagal: {err[-1200:]}")
    return out_mp4


def clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def concat_with_transitions(clips: list[dict], out_mp4: str, W: int, H: int, fps: int,
                            transition: str = "fade", overlap: float = 0.5,
                            fade_edges: bool = True) -> tuple[str, float]:
    """Gabungkan klip dengan xfade. Return (path, durasi_total)."""
    if len(clips) == 1:
        cmd = [ffmpeg_exe(), "-y", "-i", clips[0]["path"], "-c:v", "libx264", "-preset", "veryfast",
               "-crf", "18", "-pix_fmt", "yuv420p", "-an", out_mp4]
        if fade_edges:
            d = clips[0]["duration"]
            cmd = [ffmpeg_exe(), "-y", "-i", clips[0]["path"],
                   "-vf", f"fade=t=in:st=0:d=0.45,fade=t=out:st={max(0, d - 0.55):.3f}:d=0.55",
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                   "-pix_fmt", "yuv420p", "-an", out_mp4]
        r = run(cmd)
        if r.returncode:
            raise RuntimeError(r.stderr[-800:])
        return out_mp4, clips[0]["duration"]

    overlap = min(overlap, min(c["duration"] for c in clips) * 0.45)
    overlap = max(0.12, overlap)
    inputs: list[str] = []
    for c in clips:
        inputs += ["-i", c["path"]]
    filt = []
    prev = "[0:v]"
    offset = clips[0]["duration"] - overlap
    for i in range(1, len(clips)):
        lbl = f"[v{i}]"
        filt.append(f"{prev}[{i}:v]xfade=transition={transition}:duration={overlap:.3f}:"
                    f"offset={offset:.3f}{lbl}")
        prev = lbl
        if i < len(clips) - 1:
            offset += clips[i]["duration"] - overlap
    total = offset + clips[-1]["duration"]
    vf = "".join(filt)
    if fade_edges:
        vf += f";{prev}fade=t=in:st=0:d=0.5,fade=t=out:st={max(0, total - 0.7):.3f}:d=0.7[vout]"
        prev = "[vout]"
    cmd = [ffmpeg_exe(), "-y", *inputs, "-filter_complex", vf, "-map", prev,
           "-r", str(fps), "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-an", out_mp4]
    r = run(cmd, timeout=1800)
    if r.returncode:
        raise RuntimeError(r.stderr[-1200:])
    return out_mp4, total


def mix_audio(video_silent: str, narration: list[dict], music_path: str | None,
              out_mp4: str, total_dur: float, *, music_vol: float = 0.34,
              voice_vol: float = 1.0, duck: bool = True) -> str:
    """Gabung musik + narasi ke video."""
    inputs: list[str] = []
    filt: list[str] = []
    labels: list[str] = []
    idx = 0

    if music_path and os.path.exists(music_path):
        inputs += ["-i", music_path]
        filt.append(f"[{idx}:a]aloop=loop=-1:size=2e9,atrim=0:{total_dur:.3f},"
                    f"volume={music_vol:.3f}[mus0]")
        cur = "[mus0]"
        idx += 1
    else:
        inputs += ["-f", "lavfi", "-i", f"anullsrc=r=44100:cl=stereo"]
        filt.append(f"[{idx}:a]atrim=0:{total_dur:.3f}[mus0]")
        cur = "[mus0]"
        idx += 1

    narr_items = [(n["path"], n["start"]) for n in narration if n.get("path") and os.path.exists(n["path"])]
    for p, st in narr_items:
        inputs += ["-i", p]
        filt.append(f"[{idx}:a]adelay={int(st * 1000)}|{int(st * 1000)},volume={voice_vol:.2f}[n{idx}]")
        labels.append(f"[n{idx}]")
        idx += 1

    if labels:
        mix_in = cur + "".join(labels)
        if duck:
            # sidechain ducking agar musik turun saat ada suara
            filt.append(f"{cur}{''.join(labels[:1])}sidechaincompress=threshold=0.06:ratio=6:"
                        f"attack=12:release=380[ducked]")
            rest = labels[1:]
            mix_in = "[ducked]" + "".join(rest)
            cur = "[ducked]"
            labels = rest
        filt.append(f"{mix_in}amix=inputs={1 + len(labels)}:duration=first:"
                    f"dropout_transition=0:normalize=0,alimiter=limit=0.95[aout]")
    else:
        filt.append(f"{cur}alimiter=limit=0.95[aout]")

    inputs += ["-i", video_silent]
    cmd = [ffmpeg_exe(), "-y", *inputs, "-filter_complex", ";".join(filt),
           "-map", f"{idx}:v", "-map", "[aout]",
           "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
           "-shortest", "-movflags", "+faststart", out_mp4]
    r = run(cmd, timeout=1200)
    if r.returncode:
        # fallback tanpa ducking
        cmd2 = [ffmpeg_exe(), "-y", "-i", video_silent, *(["-i", music_path] if music_path else []),
                "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest", out_mp4]
        r2 = run(cmd2, timeout=1200)
        if r2.returncode:
            # terakhir: video tanpa audio
            run([ffmpeg_exe(), "-y", "-i", video_silent, "-c", "copy", out_mp4])
        return out_mp4
    return out_mp4


def make_poster(scene: dict, path: str, W: int, int_H: int, opts: dict, t: float = 0.45) -> str:
    r = visual.SceneRenderer(scene, W, int_H, fps=24,
                             style_strength=opts.get("motion", 1.0),
                             grain=opts.get("grain", 1.0), bloom=opts.get("bloom", 1.0),
                             letterbox=opts.get("letterbox", False))
    arr = r.render(t)
    Image.fromarray(arr).save(path, quality=90)
    return path


def probe(path: str) -> dict:
    out = run([ffmpeg_exe(), "-i", path])
    err = out.stderr
    dur = 0.0
    m = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", err)
    if m:
        h, mi, s = m.groups()
        dur = int(h) * 3600 + int(mi) * 60 + float(s)
    size = os.path.getsize(path) if os.path.exists(path) else 0
    return {"duration": round(dur, 2), "size": size}
