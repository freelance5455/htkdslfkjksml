"""
pipeline.py — Orkestrasi end-to-end satu job pembuatan video.

Tahap: rencana (AI planner) -> narasi (TTS) -> musik (sintesis)
       -> render adegan -> transisi -> mix audio -> kemas (MP4 + poster + SRT + JSON)
"""
from __future__ import annotations

import json
import os
import time
import traceback
from typing import Any, Callable

import numpy as np
from PIL import Image

from . import encoder, music, planner, tts

ProgressFn = Callable[[float, str], None]

ASPECTS = {
    "16:9": (1280, 720),
    "9:16": (720, 1280),
    "1:1":  (720, 720),
    "4:5":  (720, 900),
    "21:9": (1280, 548),
}
HD_SCALE = {"720p": 1.0, "1080p": 1.5, "480p": 2 / 3}
TRANSITIONS = ["fade", "fadeblack", "dissolve", "smoothleft", "smoothright",
               "circleopen", "circleclose", "wipeleft", "slideleft", "radial", "zoomin"]


def resolve_size(aspect: str, res: str) -> tuple[int, int]:
    w, h = ASPECTS.get(aspect, ASPECTS["16:9"])
    s = HD_SCALE.get(res, 1.0)
    w, h = int(round(w * s / 2) * 2), int(round(h * s / 2) * 2)
    return w, h


def _noop(p: float, msg: str) -> None:
    pass


def fit_durations_to_narration(scenes: list[dict], narr: list[dict],
                               min_dur: float = 2.4, max_dur: float = 14.0) -> list[dict]:
    for i, sc in enumerate(scenes):
        if i < len(narr) and narr[i].get("duration"):
            sc["duration"] = round(min(max_dur, max(min_dur, narr[i]["duration"] + 0.85)), 3)
    return scenes


def run_job(job: dict[str, Any], workdir: str, outdir: str, progress: ProgressFn = _noop) -> dict[str, Any]:
    t0 = time.time()
    os.makedirs(workdir, exist_ok=True)
    os.makedirs(outdir, exist_ok=True)
    FF = encoder.ffmpeg_exe()

    prompt = (job.get("prompt") or "").strip()
    images = job.get("images") or []
    mode = "image2video" if images else "text2video"
    style = job.get("style") or "auto"
    motion = job.get("motion") or "auto"
    fps = int(job.get("fps") or 30)
    n_scenes = int(job.get("scenes") or 4)
    duration = float(job.get("duration") or 12)
    W, H = resolve_size(job.get("aspect") or "16:9", job.get("resolution") or "720p")

    opts = {
        "motion": float(job.get("motion_speed", 1.0)),
        "grain": float(job.get("grain", 1.0)),
        "bloom": float(job.get("bloom", 1.0)),
        "ca": float(job.get("chroma", 0.6)),
        "letterbox": bool(job.get("letterbox", False)),
        "subtitle": bool(job.get("subtitle", True)),
        "karaoke": bool(job.get("karaoke", False)),
        "caption": bool(job.get("caption", True)),
    }
    transition = job.get("transition") or "fade"
    if transition not in TRANSITIONS:
        transition = "fade"
    overlap = float(job.get("overlap", 0.5))
    voice = job.get("voice") or tts.DEFAULT_VOICE
    voice_speed = float(job.get("voice_speed", 1.0))
    music_on = bool(job.get("music", True))
    music_vol = float(job.get("music_volume", 0.34))
    voice_vol = float(job.get("voice_volume", 1.0))
    narration_on = bool(job.get("narration", False))

    # ---------------- 1. rencana AI
    progress(0.04, "Menganalisis prompt: mood, palet warna, storyboard…")
    plan = planner.plan(prompt, n_scenes=n_scenes, duration=duration, style=style,
                        motion=motion, images=images)
    scenes: list[dict] = plan["scenes"]
    if not opts["caption"]:
        for i, s in enumerate(scenes):
            if i > 0:
                s["caption"] = ""
    plan_json = os.path.join(outdir, "storyboard.json")
    with open(plan_json, "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)

    # ---------------- 2. narasi TTS
    narr_clips: list[dict] = []
    if narration_on and (prompt or images):
        progress(0.10, "Membuat narasi suara (text-to-speech)…")
        texts = []
        for i, s in enumerate(scenes):
            texts.append(s.get("narration") or s.get("text") or "")
        raw = []
        for i, txt in enumerate(texts):
            p = os.path.join(workdir, f"narr_{i:02d}.mp3")
            ok = tts.synthesize(txt, p, voice=voice, speed=voice_speed)
            d = tts.probe_duration(p, FF) if ok else 0.0
            raw.append({"path": p if ok else None, "duration": round(d, 3)})
            progress(0.10 + 0.10 * ((i + 1) / max(1, len(texts))),
                     f"Narasi adegan {i + 1}/{len(texts)}…")
        if any(r["duration"] > 0 for r in raw):
            fit_durations_to_narration(scenes, raw)
            plan["scenes"] = scenes
            plan["duration"] = round(sum(s["duration"] for s in scenes), 3)
        else:
            narration_on = False
    total_dur = round(sum(s["duration"] for s in scenes), 3)
    overlap = max(0.12, min(overlap, min(s["duration"] for s in scenes) * 0.4))
    final_dur = total_dur - overlap * (len(scenes) - 1) if len(scenes) > 1 else total_dur

    # ---------------- 3. musik
    music_path = None
    if music_on:
        progress(0.22, f"Menyintesis musik latar ({plan['music_style']})…")
        music_path = os.path.join(workdir, "music.wav")
        try:
            music.generate_music(music_path, final_dur + 0.6, plan["music_style"],
                                 intensity=1.0 if opts["motion"] >= 1 else 0.75,
                                 seed=int(scenes[0]["seed"] % 100000))
        except Exception:
            music_path = None

    # ---------------- 4. render adegan
    clips: list[dict] = []
    span = 0.62 / max(1, len(scenes))
    for i, sc in enumerate(scenes):
        base = 0.26 + span * i
        progress(base, f"Merender adegan {i + 1}/{len(scenes)} ({sc['duration']:.1f}s, {W}x{H})…")
        clip_path = os.path.join(workdir, f"clip_{i:02d}.mp4")
        sub_txt = sc.get("narration") or sc.get("text") or ""
        encoder.render_scene_clip(
            sc, clip_path, W, H, fps, opts,
            progress=progress, base_prog=base, prog_span=span,
            subtitle_text=sub_txt if opts["subtitle"] else None,
        )
        clips.append({"path": clip_path, "duration": sc["duration"]})

    # ---------------- 5. transisi + gabung
    progress(0.90, "Menyambung adegan dengan transisi sinematik…")
    silent = os.path.join(workdir, "video_silent.mp4")
    silent, real_dur = encoder.concat_with_transitions(
        clips, silent, W, H, fps, transition=transition, overlap=overlap, fade_edges=True)

    # ---------------- 6. audio mix
    progress(0.93, "Mencampur musik + narasi…")
    narration_tracks = []
    t_cur = 0.0
    for i, sc in enumerate(scenes):
        if narration_on and i < len(raw) and raw[i].get("path"):
            narration_tracks.append({"path": raw[i]["path"], "start": t_cur + 0.35})
        t_cur += sc["duration"] - (overlap if i < len(scenes) - 1 else 0)

    final_mp4 = os.path.join(outdir, "video.mp4")
    encoder.mix_audio(silent, narration_tracks, music_path, final_mp4, real_dur,
                      music_vol=music_vol, voice_vol=voice_vol, duck=True)

    # ---------------- 7. kemas hasil
    progress(0.96, "Menyimpan poster, subtitle, dan metadata…")
    poster = os.path.join(outdir, "poster.jpg")
    try:
        encoder.make_poster(scenes[0], poster, W, H, opts, t=0.42)
    except Exception:
        poster = None
    srt = os.path.join(outdir, "subtitle.srt")
    timing = encoder.build_srt(scenes, overlap, srt)

    info = encoder.probe(final_mp4)
    meta = {
        "mode": mode,
        "prompt": prompt,
        "title": plan["title"],
        "mood": plan["mood"],
        "mood_label": plan["mood_label"],
        "palette": plan["palette"],
        "music_style": plan["music_style"],
        "keywords": plan["keywords"],
        "scenes": [{"index": s["index"], "caption": s["caption"], "mood": s["mood"],
                    "duration": s["duration"], "camera": s["camera"]["name"],
                    "elements": s["elements"]} for s in scenes],
        "width": W, "height": H, "fps": fps,
        "duration": info.get("duration") or round(real_dur, 2),
        "size": info.get("size", 0),
        "transition": transition, "overlap": overlap,
        "narration": narration_on, "voice": voice if narration_on else None,
        "music": music_on, "subtitle": opts["subtitle"],
        "elapsed": round(time.time() - t0, 1),
        "timing": timing,
        "engine": "Aurora Procedural Cinema Engine v1",
    }
    with open(os.path.join(outdir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    progress(1.0, "Selesai ✅")
    return meta


def cleanup_workdir(workdir: str) -> None:
    try:
        for fn in os.listdir(workdir):
            p = os.path.join(workdir, fn)
            if os.path.isfile(p):
                os.remove(p)
        os.rmdir(workdir)
    except Exception:
        pass


def safe_error(e: Exception) -> str:
    tb = traceback.format_exc(limit=3)
    return f"{type(e).__name__}: {e}\n{tb[-800:]}"
