"""
tts.py — Narasi suara (text-to-speech) memakai Microsoft Edge TTS.
Butuh internet; bila gagal, pipeline tetap jalan tanpa narasi (musik saja).
"""
from __future__ import annotations

import asyncio
import os
import re
import shutil
import subprocess
import tempfile

VOICES = {
    "id_male":   {"id": "id-ID-ArdiNeural",  "label": "Ardi — Pria (ID)"},
    "id_female": {"id": "id-ID-GadisNeural", "label": "Gadis — Wanita (ID)"},
    "en_male":   {"id": "en-US-GuyNeural",   "label": "Guy — Male (US)"},
    "en_female": {"id": "en-US-AriaNeural",  "label": "Aria — Female (US)"},
    "en_uk":     {"id": "en-GB-SoniaNeural", "label": "Sonia — Female (UK)"},
    "jp_female": {"id": "ja-JP-NanamiNeural", "label": "Nanami — 女性 (JP)"},
}

DEFAULT_VOICE = "id_female"


def voice_catalog() -> list[dict]:
    return [{"id": k, "label": v["label"]} for k, v in VOICES.items()]


def rate_for(speed: float) -> str:
    pct = int(round((speed - 1.0) * 100))
    return f"{'+' if pct >= 0 else ''}{pct}%"


def _clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    text = re.sub(r"[#*_`>|]", " ", text)
    return text.strip()


async def _synth(text: str, voice: str, path: str, rate: str, pitch: str = "+0Hz") -> None:
    import edge_tts
    c = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await c.save(path)


def synthesize(text: str, out_path: str, voice: str = DEFAULT_VOICE,
               speed: float = 1.0, timeout: int = 45) -> str | None:
    """Sintesis satu klip. Return path bila sukses, None bila gagal."""
    text = _clean(text)
    if not text:
        return None
    v = VOICES.get(voice, VOICES[DEFAULT_VOICE])["id"]
    try:
        asyncio.run(_synth(text, v["id"] if isinstance(v, dict) else v, out_path, rate_for(speed)))
        if os.path.exists(out_path) and os.path.getsize(out_path) > 800:
            return out_path
    except Exception as e:  # pragma: no cover - jaringan bisa mati
        print(f"[tts] gagal: {e}")
    return None


def probe_duration(path: str, ffmpeg: str) -> float:
    ffprobe = shutil.which("ffprobe")
    try:
        if ffprobe:
            out = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration",
                                  "-of", "default=nw=1:nk=1", path],
                                 capture_output=True, text=True, timeout=20)
            return float(out.stdout.strip() or 0)
    except Exception:
        pass
    try:
        out = subprocess.run([ffmpeg, "-i", path], capture_output=True, text=True, timeout=20)
        m = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", out.stderr)
        if m:
            h, mi, s = m.groups()
            return int(h) * 3600 + int(mi) * 60 + float(s)
    except Exception:
        pass
    return 0.0


def synthesize_scenes(scenes: list[dict], workdir: str, ffmpeg: str,
                      voice: str = DEFAULT_VOICE, speed: float = 1.0) -> list[dict]:
    """Sintesis narasi per adegan; isi durasi audio tiap adegan."""
    results = []
    for i, sc in enumerate(scenes):
        p = os.path.join(workdir, f"narr_{i:02d}.mp3")
        ok = synthesize(sc.get("narration", sc.get("text", "")), p, voice, speed)
        d = probe_duration(p, ffmpeg) if ok else 0.0
        results.append({"path": p if ok else None, "duration": round(d, 3)})
    return results


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as td:
        print(synthesize("Selamat datang di Aurora Studio.", os.path.join(td, "a.mp3")))
