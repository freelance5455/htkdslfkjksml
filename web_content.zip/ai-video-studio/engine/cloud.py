"""
cloud.py — Adapter opsional untuk AI video generatif berbasis API
(Veo / Runway / Luma / Replicate / fal.ai / Stability).

Mode ini butuh API key dari pengguna. Tanpa key, Aurora tetap menghasilkan
video sinematik penuh lewat mesin prosedural lokal (engine lokal = default).

Setiap provider cukup mengimplementasikan:
    generate(prompt, image_path, cfg) -> dict{video_url|video_path, meta}
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any

import urllib.request
import json as _json

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "providers.json")


@dataclass
class ProviderSpec:
    id: str
    name: str
    kind: str            # text2video | image2video | both
    key_env: str
    docs: str
    models: list[str]
    note: str = ""


PROVIDERS = [
    ProviderSpec("veo", "Google Veo 3", "both", "GEMINI_API_KEY",
                 "https://ai.google.dev/gemini-api/docs/video",
                 ["veo-3.0-generate-001", "veo-2.0-generate-001"],
                 "Butuh Google AI Studio API key (Vertex/Gemini)."),
    ProviderSpec("runway", "Runway Gen-4", "both", "RUNWAY_API_KEY",
                 "https://docs.dev.runwayml.com/", ["gen4_turbo", "gen3a_turbo"],
                 "Text/image to video, durasi 5-10 detik."),
    ProviderSpec("luma", "Luma Dream Machine", "both", "LUMA_API_KEY",
                 "https://lumalabs.ai/docs/api", ["ray-2", "ray-1-6"], ""),
    ProviderSpec("replicate", "Replicate (Wan/Kling/MiniMax)", "both", "REPLICATE_API_TOKEN",
                 "https://replicate.com/docs", ["wan-video/wan-2.2-t2v-a14b",
                                                "kwaivgi/kling-v2.1", "minimax/video-01"],
                 "Satu token untuk ratusan model video."),
    ProviderSpec("fal", "fal.ai", "both", "FAL_KEY", "https://fal.ai/models",
                 ["fal-ai/kling-video/v2.1/standard/text-to-video",
                  "fal-ai/wan/v2.2/image-to-video"], ""),
    ProviderSpec("stability", "Stability AI (SVD)", "image2video", "STABILITY_API_KEY",
                 "https://platform.stability.ai/docs", ["stable-video-diffusion"],
                 "Khusus image-to-video."),
]


def load_keys() -> dict[str, str]:
    if not os.path.exists(CONFIG_PATH):
        return {}
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return _json.load(f) or {}
    except Exception:
        return {}


def save_keys(keys: dict[str, str]) -> None:
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        _json.dump(keys, f, ensure_ascii=False, indent=2)
    os.chmod(CONFIG_PATH, 0o600)


def get_key(provider_id: str) -> str | None:
    spec = next((p for p in PROVIDERS if p.id == provider_id), None)
    if not spec:
        return None
    keys = load_keys()
    return (keys.get(spec.key_env) or os.environ.get(spec.key_env) or "").strip() or None


def status() -> list[dict[str, Any]]:
    out = []
    for p in PROVIDERS:
        k = get_key(p.id)
        out.append({
            "id": p.id, "name": p.name, "kind": p.kind, "key_env": p.key_env,
            "docs": p.docs, "models": p.models, "note": p.note,
            "configured": bool(k),
            "key_preview": (k[:6] + "…" + k[-3:]) if k else None,
        })
    return out


def is_configured(provider_id: str) -> bool:
    return bool(get_key(provider_id))


def _post_json(url: str, headers: dict, payload: dict, timeout: int = 120) -> dict:
    data = _json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", **headers},
                                 method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return _json.loads(r.read().decode())


def _get_json(url: str, headers: dict, timeout: int = 120) -> dict:
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return _json.loads(r.read().decode())


def generate(provider_id: str, prompt: str, *, image_path: str | None = None,
             duration: int = 5, aspect: str = "16:9", model: str | None = None,
             poll: Any = None) -> dict[str, Any]:
    """Panggil provider cloud. Return {video_url, provider, model, raw}."""
    key = get_key(provider_id)
    if not key:
        raise RuntimeError(f"API key untuk {provider_id} belum diisi. Buka tab 'Cloud AI' di pengaturan.")
    model = model or (next(p for p in PROVIDERS if p.id == provider_id).models[0])

    if provider_id == "replicate":
        return _replicate(key, model, prompt, image_path, duration, aspect, poll)
    if provider_id == "fal":
        return _fal(key, model, prompt, image_path, duration, aspect, poll)
    if provider_id == "veo":
        return _veo(key, model, prompt, image_path, duration, aspect, poll)
    if provider_id == "luma":
        return _luma(key, model, prompt, image_path, duration, aspect, poll)
    if provider_id == "runway":
        return _runway(key, model, prompt, image_path, duration, aspect, poll)
    raise RuntimeError(f"Provider '{provider_id}' belum punya adapter aktif. "
                       f"Gunakan Replicate/fal/Veo/Luma/Runway, atau engine lokal.")


def _replicate(key, model, prompt, image_path, duration, aspect, poll):
    inp: dict[str, Any] = {"prompt": prompt, "aspect_ratio": aspect, "num_outputs": 1}
    if image_path:
        import base64
        b64 = base64.b64encode(open(image_path, "rb").read()).decode()
        inp["image"] = f"data:image/jpeg;base64,{b64}"
    r = _post_json("https://api.replicate.com/v1/predictions",
                   {"Authorization": f"Bearer {key}"}, {"version": model, "input": inp})
    urls = r.get("urls") or {}
    get_url = urls.get("get") or f"https://api.replicate.com/v1/predictions/{r['id']}"
    for _ in range(240):
        time.sleep(3)
        s = _get_json(get_url, {"Authorization": f"Bearer {key}"})
        if poll:
            poll(s.get("status"), s.get("logs") or "")
        if s.get("status") == "succeeded":
            out = s.get("output")
            url = out[0] if isinstance(out, list) else out
            return {"video_url": url, "provider": "replicate", "model": model, "raw": s}
        if s.get("status") == "failed":
            raise RuntimeError(f"Replicate gagal: {s.get('error')}")
    raise RuntimeError("Replicate: waktu tunggu habis")


def _fal(key, model, prompt, image_path, duration, aspect, poll):
    payload: dict[str, Any] = {"prompt": prompt, "aspect_ratio": aspect, "duration": str(duration)}
    if image_path:
        import base64
        b64 = base64.b64encode(open(image_path, "rb").read()).decode()
        payload["image_url"] = f"data:image/jpeg;base64,{b64}"
    r = _post_json("https://queue.fal.run/" + model, {"Authorization": f"Key {key}"}, payload)
    status_url = r.get("status_url") or r.get("response_url")
    for _ in range(240):
        time.sleep(3)
        s = _get_json(status_url, {"Authorization": f"Key {key}"})
        if poll:
            poll(s.get("status"), "")
        if s.get("status") == "COMPLETED":
            res = _get_json(r["response_url"], {"Authorization": f"Key {key}"})
            vid = res.get("video") or {}
            return {"video_url": vid.get("url"), "provider": "fal", "model": model, "raw": res}
    raise RuntimeError("fal.ai: waktu tunggu habis")


def _veo(key, model, prompt, image_path, duration, aspect, poll):
    base = "https://generativelanguage.googleapis.com/v1beta"
    body: dict[str, Any] = {"instances": [{"prompt": prompt}],
                            "parameters": {"aspectRatio": aspect, "durationSeconds": int(duration)}}
    if image_path:
        import base64
        b64 = base64.b64encode(open(image_path, "rb").read()).decode()
        body["instances"][0]["image"] = {"bytesBase64Encoded": b64, "mimeType": "image/jpeg"}
    r = _post_json(f"{base}/{model}:predictLongRunning?key={key}", {}, body)
    name = r.get("name")
    for _ in range(240):
        time.sleep(4)
        s = _get_json(f"{base}/{name}?key={key}", {})
        if poll:
            poll("PROGRESSING", "")
        if s.get("done"):
            res = s.get("response") or {}
            gens = res.get("generateVideoResponse", {}).get("generatedSamples") or []
            if gens:
                return {"video_url": gens[0].get("videoUri") or gens[0].get("videoUrl"),
                        "provider": "veo", "model": model, "raw": s}
            raise RuntimeError(f"Veo tidak mengembalikan video: {s}")
    raise RuntimeError("Veo: waktu tunggu habis")


def _luma(key, model, prompt, image_path, duration, aspect, poll):
    body: dict[str, Any] = {"model": model, "prompt": prompt, "aspect_ratio": aspect}
    if image_path:
        import base64
        b64 = base64.b64encode(open(image_path, "rb").read()).decode()
        body["keyframes"] = {"frame0": {"type": "image", "url": f"data:image/jpeg;base64,{b64}"}}
    r = _post_json("https://api.lumalabs.ai/dream-machine/v1/generations",
                   {"Authorization": f"Bearer {key}", "accept": "application/json"}, body)
    gid = r.get("id")
    for _ in range(240):
        time.sleep(4)
        s = _get_json(f"https://api.lumalabs.ai/dream-machine/v1/generations/{gid}",
                      {"Authorization": f"Bearer {key}"})
        if poll:
            poll(s.get("state"), "")
        if s.get("state") == "completed":
            return {"video_url": (s.get("assets") or {}).get("video"),
                    "provider": "luma", "model": model, "raw": s}
        if s.get("state") == "failed":
            raise RuntimeError(f"Luma gagal: {s.get('failure_reason')}")
    raise RuntimeError("Luma: waktu tunggu habis")


def _runway(key, model, prompt, image_path, duration, aspect, poll):
    body: dict[str, Any] = {"model": model, "promptText": prompt, "ratio": aspect.replace(":", ""),
                            "duration": int(duration)}
    if image_path:
        import base64
        body["promptImage"] = "data:image/jpeg;base64," + base64.b64encode(open(image_path, "rb").read()).decode()
    r = _post_json("https://api.dev.runwayml.com/v1/image_to_video" if image_path
                   else "https://api.dev.runwayml.com/v1/text_to_video",
                   {"Authorization": f"Bearer {key}", "X-Runway-Version": "2024-11-06"}, body)
    tid = r.get("id")
    for _ in range(240):
        time.sleep(4)
        s = _get_json(f"https://api.dev.runwayml.com/v1/tasks/{tid}",
                      {"Authorization": f"Bearer {key}", "X-Runway-Version": "2024-11-06"})
        if poll:
            poll(s.get("status"), "")
        if s.get("status") == "SUCCEEDED":
            out = s.get("output") or []
            return {"video_url": out[0] if out else None, "provider": "runway",
                    "model": model, "raw": s}
        if s.get("status") == "FAILED":
            raise RuntimeError(f"Runway gagal: {s.get('failure')}")
    raise RuntimeError("Runway: waktu tunggu habis")


def download(url: str, dest: str, timeout: int = 300) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "AuroraStudio/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r, open(dest, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
    return dest
