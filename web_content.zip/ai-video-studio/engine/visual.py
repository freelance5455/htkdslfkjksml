"""
visual.py — Mesin render visual generatif (procedural cinematic engine).

Tanpa model eksternal: setiap adegan digambar dari palet warna + seed, lalu
dianimasikan per-frame (Ken Burns, partikel glow, cahaya, grade sinematik).

Strategi performa:
  * base statis (langit, gunung, kota) digambar SEKALI per adegan via PIL
  * efek per-frame (glow, partikel, kabut) memakai operasi numpy langsung
    pada buffer float32 — tanpa GaussianBlur full-frame per frame
Konvensi warna: C(rgb, alpha) -> RGBA 4-int valid; rgb = 3-tuple hasil hex2rgb/mix.
"""
from __future__ import annotations

import math
import random
from functools import lru_cache

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from . import planner

FONT_DIR = "/usr/share/fonts/truetype/dejavu"
FONT_BOLD = f"{FONT_DIR}/DejaVuSans-Bold.ttf"
FONT_REG = f"{FONT_DIR}/DejaVuSans.ttf"

MOTION_SPEED = {"slow": 0.55, "medium": 1.0, "fast": 1.7}
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


# ------------------------------------------------------------------ warna & util

def hex2rgb(h: str) -> tuple[int, int, int]:
    h = str(h).lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except Exception:
        return (255, 255, 255)


def C(rgb, a: float = 255) -> tuple[int, int, int, int]:
    """RGBA valid untuk ImageDraw; a boleh fraksi 0..1 atau 0..255."""
    if rgb is None:
        rgb = WHITE
    if isinstance(rgb, str):
        rgb = hex2rgb(rgb)
    rgb = tuple(rgb)[:3]
    av = a * 255 if (isinstance(a, float) and a <= 1.0) else a
    return (int(max(0, min(255, rgb[0]))), int(max(0, min(255, rgb[1]))),
            int(max(0, min(255, rgb[2]))), int(max(0, min(255, av))))


def mix(c1, c2, t: float) -> tuple[int, int, int]:
    c1 = hex2rgb(c1) if isinstance(c1, str) else tuple(c1)[:3]
    c2 = hex2rgb(c2) if isinstance(c2, str) else tuple(c2)[:3]
    t = max(0.0, min(1.0, t))
    return tuple(int(round(a + (b - a) * t)) for a, b in zip(c1, c2))


def ease(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 3 * t * t - 2 * t * t * t


def clamp01(t: float) -> float:
    return max(0.0, min(1.0, t))


def smooth_profile(rng: random.Random, n: int, w: int, rough: float = 1.0) -> np.ndarray:
    ctrl = np.array([rng.random() for _ in range(max(3, n))], dtype=np.float32)
    x = np.linspace(0, len(ctrl) - 1, w)
    i0 = np.floor(x).astype(int)
    i1 = np.minimum(i0 + 1, len(ctrl) - 1)
    f = x - i0
    f = f * f * (3 - 2 * f)
    v = ctrl[i0] * (1 - f) + ctrl[i1] * f
    v = (v - v.min()) / (v.max() - v.min() + 1e-6)
    return v ** rough


@lru_cache(maxsize=160)
def font(size: int, bold: bool = True) -> ImageFont.FreeTypeFont:
    size = max(8, int(size))
    try:
        return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size)
    except Exception:
        return ImageFont.load_default()


def add_glow(arr: np.ndarray, cx: float, cy: float, rx: float, ry: float,
             color, alpha: float, power: float = 2.0,
             yfade: tuple[float, float] | None = None) -> None:
    """Komposit radial glow lembut LANGSUNG ke buffer float (H,W,3), in-place.

    cx, cy, rx, ry dalam piksel. alpha 0..1. yfade=(y_start, y_end): alpha
    meluruh linier dari 1 ke 0 antara y_start..y_end (untuk sinar langit).
    """
    H, W = arr.shape[0], arr.shape[1]
    x0 = int(max(0, cx - rx))
    x1 = int(min(W, cx + rx))
    y0 = int(max(0, cy - ry))
    y1 = int(min(H, cy + ry))
    if x1 <= x0 or y1 <= y0 or alpha <= 0.003:
        return
    ys = np.arange(y0, y1, dtype=np.float32)
    xs = np.arange(x0, x1, dtype=np.float32)
    dy = (ys - cy) / max(1e-6, ry)
    dx = (xs - cx) / max(1e-6, rx)
    d2 = dy[:, None] ** 2 + dx[None, :] ** 2
    m = np.clip(1.0 - d2, 0.0, 1.0) ** power
    if yfade is not None:
        fa = np.clip(1.0 - (ys - yfade[0]) / max(1e-6, yfade[1] - yfade[0]), 0.0, 1.0)
        m = m * fa[:, None]
    m = m * alpha
    col = np.asarray(color[:3], np.float32)
    region = arr[y0:y1, x0:x1]
    region *= (1.0 - m[..., None])
    region += m[..., None] * col


def add_line_glow(arr: np.ndarray, x0: float, y0: float, x1: float, y1: float,
                  width: float, color, alpha: float) -> None:
    """Garis cahaya lembut (streak) via jarak titik-garis pada bbox."""
    H, W = arr.shape[0], arr.shape[1]
    pad = width * 3 + 2
    bx0 = int(max(0, min(x0, x1) - pad))
    bx1 = int(min(W, max(x0, x1) + pad))
    by0 = int(max(0, min(y0, y1) - pad))
    by1 = int(min(H, max(y0, y1) + pad))
    if bx1 <= bx0 or by1 <= by0 or alpha <= 0.004:
        return
    ys = np.arange(by0, by1, dtype=np.float32)[:, None]
    xs = np.arange(bx0, bx1, dtype=np.float32)[None, :]
    vx, vy = x1 - x0, y1 - y0
    L2 = vx * vx + vy * vy or 1.0
    t = np.clip(((xs - x0) * vx + (ys - y0) * vy) / L2, 0.0, 1.0)
    px, py = x0 + t * vx, y0 + t * vy
    d = np.sqrt((xs - px) ** 2 + (ys - py) ** 2) / max(1e-6, width)
    m = np.clip(1.0 - d, 0.0, 1.0) ** 2 * alpha
    col = np.asarray(color[:3], np.float32)
    region = arr[by0:by1, bx0:bx1]
    region *= (1.0 - m[..., None])
    region += m[..., None] * col


# ==================================================================
#  RENDERER
# ==================================================================

class SceneRenderer:
    def __init__(self, scene: dict, W: int, H: int, *, fps: int = 30,
                 style_strength: float = 1.0, grain: float = 1.0,
                 bloom: float = 1.0, ca: float = 1.0, letterbox: bool = False,
                 base_scale: float = 1.26):
        self.sc = scene
        self.W, self.H, self.fps = int(W), int(H), int(fps)
        self.dur = max(0.2, float(scene.get("duration", 3.0)))
        seed = int(scene.get("seed", 1))
        self.rng = random.Random(seed)
        self.np_rng = np.random.default_rng(seed)
        hexpal = list(scene.get("palette") or ["#2b1055", "#7597de", "#ff9e6d", "#ffd6a5", "#ff5e62"])
        self.hexpal = hexpal
        self.pal = [hex2rgb(c) for c in hexpal]
        self.speed = MOTION_SPEED.get(scene.get("motion", "slow"), 1.0) * float(style_strength)
        self.g_strength = float(grain)
        self.b_strength = float(bloom)
        self.ca_strength = float(ca)
        self.letterbox = bool(letterbox)
        self.BW = int(self.W * float(base_scale))
        self.BH = int(self.H * float(base_scale))
        self.grade = dict(scene.get("grade") or {})
        self.elements = list(scene.get("elements") or [])
        self._base: Image.Image | None = None
        self._image_layer = self._load_image() if scene.get("image") else None
        self._dyn = random.Random(seed ^ 0x5EED)
        self._init_particles()
        self._init_dynamic()
        self._init_post()

    # --------------------------------------------------------- init

    def _init_post(self):
        w, h = self.W, self.H
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        nx = (xx / max(1, w - 1)) * 2 - 1
        ny = (yy / max(1, h - 1)) * 2 - 1
        r = np.sqrt(nx * nx + ny * ny) / math.sqrt(2)
        self._vig = (1.0 - 0.40 * (r ** 2.3))[..., None].astype(np.float32)
        self._lum = np.array([0.299, 0.587, 0.114], dtype=np.float32)
        self._bar = int(round(h * 0.055)) if self.letterbox else 0
        self._ca_px = int(round(1.2 * self.ca_strength * (w / 1280.0)))
        self._bloom_w = max(8, w // 6)
        self._bloom_h = max(8, h // 6)

    def _init_particles(self):
        rng = self.np_rng
        counts = {"dust": 70, "snow": 170, "rain": 200, "stars": 220, "bokeh": 22,
                  "fireflies": 34, "embers": 100, "bubbles": 50, "petals": 40,
                  "leaves": 28, "smoke": 10}
        kinds = [e for e in self.elements if e in counts]
        if not kinds and self._image_layer is None:
            kinds = ["dust"]
        self.particles = []
        for kind in kinds:
            n = counts[kind]
            self.particles.append({
                "kind": kind, "n": n,
                "x": rng.random(n).astype(np.float32),
                "y": rng.random(n).astype(np.float32),
                "z": (rng.random(n).astype(np.float32) * 0.8 + 0.2),
                "vx": ((rng.random(n).astype(np.float32) - 0.5) * 0.06),
                "ph": (rng.random(n).astype(np.float32) * 6.283),
                "sz": rng.random(n).astype(np.float32),
            })

    def _init_dynamic(self):
        rng = self._dyn
        self.clouds = [{"x": rng.random(), "y": 0.06 + rng.random() * 0.40,
                        "s": 0.25 + rng.random() * 0.55,
                        "v": (0.004 + rng.random() * 0.012) * rng.choice([-1, 1]),
                        "a": 0.06 + rng.random() * 0.11} for _ in range(7)]
        self.rays = [{"ang": -28 + rng.random() * 56,
                      "w": 0.035 + rng.random() * 0.075,
                      "a": 0.05 + rng.random() * 0.09,
                      "v": (rng.random() - 0.5) * 0.6} for _ in range(5)]
        self.birds = [{"x": rng.random(), "y": 0.10 + rng.random() * 0.28,
                       "s": 0.6 + rng.random() * 0.9, "v": 0.02 + rng.random() * 0.05,
                       "ph": rng.random() * 6.28} for _ in range(rng.randint(3, 7))]
        self.fish = [{"x": rng.random(), "y": 0.35 + rng.random() * 0.5,
                      "s": 0.5 + rng.random() * 1.0,
                      "v": (0.01 + rng.random() * 0.03) * rng.choice([-1, 1]),
                      "ph": rng.random() * 6.28} for _ in range(rng.randint(4, 9))]
        self.shapes = [{"x": rng.random(), "y": rng.random(),
                        "r": 0.06 + rng.random() * 0.22,
                        "kind": rng.choice(["ring", "tri", "arc", "dot", "square"]),
                        "rot": rng.random() * 360,
                        "vx": (rng.random() - 0.5) * 0.012, "vy": (rng.random() - 0.5) * 0.012,
                        "a": 0.10 + rng.random() * 0.22,
                        "ci": rng.randrange(max(1, len(self.hexpal) - 1)) + 1}
                       for _ in range(rng.randint(4, 8))]
        self.streaks = [{"x": rng.random(), "y": rng.random(),
                         "len": 0.08 + rng.random() * 0.28,
                         "v": 0.25 + rng.random() * 0.9, "a": 0.22 + rng.random() * 0.45}
                        for _ in range(rng.randint(6, 13))]
        self.profile_seed = rng.randint(0, 10 ** 6)
        self.sun_pos = (0.25 + rng.random() * 0.5, 0.28 + rng.random() * 0.20)

    def _load_image(self):
        try:
            im = Image.open(self.sc["image"]).convert("RGB")
        except Exception:
            return None
        im.thumbnail((3000, 3000), Image.LANCZOS)
        bw, bh = self.BW, self.BH
        scale = max(bw / im.width, bh / im.height)
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))),
                       Image.LANCZOS)
        x0, y0 = (im.width - bw) // 2, (im.height - bh) // 2
        return im.crop((x0, y0, x0 + bw, y0 + bh))

    # --------------------------------------------------------- base statis

    def build_base(self) -> Image.Image:
        BW, BH = self.BW, self.BH
        if self._image_layer is not None:
            self._base = self._image_layer.copy()
            return self._base

        mood = self.sc.get("mood", "senja")
        sky_kind = planner.MOODS.get(mood, {}).get("sky", "gradient")
        img = self._draw_sky(sky_kind)
        d = ImageDraw.Draw(img, "RGBA")
        E = self.elements

        if "nebula" in E:
            img = self._add_nebula(img); d = ImageDraw.Draw(img, "RGBA")
        if "stars" in E:
            img = self._add_static_stars(img); d = ImageDraw.Draw(img, "RGBA")
        if "planet" in E:
            self._draw_planet(d)
        if "sun" in E or "moon" in E:
            only_moon = "moon" in E and "sun" not in E
            img = self._draw_celestial(img, "moon" if only_moon else "sun")
            d = ImageDraw.Draw(img, "RGBA")
        if "grid" in E:
            self._draw_grid(d)
        if "stripes" in E:
            self._draw_stripes(d)
        if "skyline" in E or "city" in E:
            self._draw_skyline(img, d)
        if "pines" in E:
            self._draw_pines(d)
        if "mountains" in E or "hills" in E:
            img = self._draw_ridges(img); d = ImageDraw.Draw(img, "RGBA")
        if "waves" in E:
            img = self._draw_water(img); d = ImageDraw.Draw(img, "RGBA")
        if "fog" in E:
            img = self._add_fog(img, 0.5); d = ImageDraw.Draw(img, "RGBA")
        if "rings" in E:
            self._draw_rings(d)
        if "shapes" in E:
            self._draw_shapes_static(d)
        if "smoke" in E:
            img = self._add_smoke_static(img)
        self._base = img.convert("RGB")
        return self._base

    def _draw_sky(self, kind: str) -> Image.Image:
        BW, BH = self.BW, self.BH
        rng = random.Random(int(self.sc.get("seed", 1)) + 7)
        p = self.pal
        p0, p1, p2, p3 = p[0], p[1 % len(p)], p[2 % len(p)], p[-1]
        if kind == "flat":
            stops = [p0, mix(p0, p1, 0.5), p1, mix(p1, p0, 0.4)]
        elif kind in ("city", "space", "clouds"):
            stops = [p0, p1, mix(p1, p2, 0.6), mix(p0, p1, 0.35)]
        else:
            stops = [p0, p1, p2, p3]
        cols = np.array(stops, np.float32)
        yy = np.linspace(0, 1, BH, dtype=np.float32)
        seg = np.linspace(0, 1, len(cols)).astype(np.float32)
        grad = np.zeros((BH, 3), np.float32)
        for i in range(len(cols) - 1):
            m = (yy >= seg[i]) & (yy <= seg[i + 1])
            t = ((yy[m] - seg[i]) / max(1e-6, seg[i + 1] - seg[i]))[:, None]
            t = t * t * (3 - 2 * t)
            grad[m] = cols[i] * (1 - t) + cols[i + 1] * t
        arr = np.repeat(grad[:, None, :], BW, axis=1)
        for _ in range(4):
            c = p[1 + rng.randrange(max(1, len(p) - 1))]
            add_glow(arr, rng.random() * BW, rng.random() * BH * 0.85,
                     BW * (0.20 + rng.random() * 0.35), BH * (0.15 + rng.random() * 0.30),
                     c, 0.16 + rng.random() * 0.20, power=1.6)
        if kind == "space":
            add_glow(arr, BW * 0.5, BH * 0.45, BW * 0.7, BH * 0.7, mix(p0, BLACK, 0.2), 0.5, power=1.4)
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

    def _add_nebula(self, img):
        BW, BH = self.BW, self.BH
        rng = random.Random(int(self.sc.get("seed", 1)) + 21)
        arr = np.asarray(img).astype(np.float32)
        for _ in range(7):
            c = self.pal[1 + rng.randrange(max(1, len(self.pal) - 1))]
            add_glow(arr, rng.random() * BW, rng.random() * BH,
                     BW * (0.12 + rng.random() * 0.26), BH * (0.10 + rng.random() * 0.22),
                     c, 0.16 + rng.random() * 0.22, power=1.8)
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

    def _add_static_stars(self, img):
        arr = np.asarray(img).astype(np.float32)
        rng = np.random.default_rng(int(self.sc.get("seed", 1)) + 33)
        n = int(self.BW * self.BH / 8000)
        xs = rng.integers(0, self.BW, n)
        ys = rng.integers(0, max(1, int(self.BH * 0.78)), n)
        br = (rng.random(n) * 190 + 60)[:, None]
        arr[ys, xs] = np.clip(arr[ys, xs] + br, 0, 255)
        return Image.fromarray(arr.astype(np.uint8))

    def _draw_celestial(self, img, kind: str = "sun"):
        BW, BH = self.BW, self.BH
        cx, cy = self.sun_pos[0] * BW, self.sun_pos[1] * BH
        arr = np.asarray(img).astype(np.float32)
        if kind == "moon":
            c = self.pal[-1]
            add_glow(arr, cx, cy, BW * 0.16, BH * 0.26, c, 0.34, power=1.7)
            out = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
            d = ImageDraw.Draw(out, "RGBA")
            r = BH * 0.052
            d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=C(mix(c, WHITE, 0.25), 250))
            # bayangan pembentuk sabit: warna diambil dari langit sekitar
            sky = tuple(int(v) for v in np.asarray(out).astype(np.float32)[
                max(0, min(self.BH - 1, int(cy - r * 2.4))),
                max(0, min(self.BW - 1, int(cx)))])
            d.ellipse([cx - r * 0.55, cy - r * 1.02, cx + r * 1.45, cy + r * 0.98],
                      fill=C(sky, 255))
            return out
        core = self.pal[-1]
        warm = self.pal[-2] if len(self.pal) > 2 else core
        add_glow(arr, cx, cy, BW * 0.55, BH * 0.5, warm, 0.16, power=1.5)
        add_glow(arr, cx, cy, BW * 0.26, BH * 0.24, warm, 0.30, power=1.6)
        add_glow(arr, cx, cy, BW * 0.11, BH * 0.10, core, 0.55, power=1.8)
        add_glow(arr, cx, cy, BW * 0.045, BH * 0.042, mix(core, WHITE, 0.75), 0.95, power=2.2)
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

    def _draw_planet(self, d):
        BW, BH = self.BW, self.BH
        rng = random.Random(int(self.sc.get("seed", 1)) + 55)
        cx = rng.uniform(0.15, 0.85) * BW
        cy = rng.uniform(0.14, 0.46) * BH
        r = BH * rng.uniform(0.10, 0.18)
        cc = self.pal[2 % len(self.pal)]
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=C(cc, 235))
        d.ellipse([cx - r * 0.45, cy - r, cx + r * 1.15, cy + r],
                  fill=C(mix(cc, BLACK, 0.6), 160))
        d.ellipse([cx - r * 0.8, cy - r * 0.8, cx + r * 0.2, cy + r * 0.2],
                  fill=C(mix(cc, WHITE, 0.3), 55))
        if rng.random() < 0.6:
            ry = r * rng.uniform(0.22, 0.34)
            d.ellipse([cx - r * 1.85, cy - ry, cx + r * 1.85, cy + ry],
                      outline=C(mix(cc, WHITE, 0.5), 140), width=max(2, int(r * 0.08)))

    def _draw_grid(self, d):
        BW, BH = self.BW, self.BH
        hz = int(BH * 0.62)
        c = self.pal[-2] if len(self.pal) > 2 else self.pal[-1]
        for i in range(-16, 17):
            d.line([BW / 2 + i * BW * 0.006, hz, BW / 2 + i * BW * 0.13, BH * 1.25],
                   fill=C(c, 100), width=2)
        for j in range(1, 17):
            t = j / 17
            y = hz + (BH - hz) * (t ** 2.1)
            d.line([0, y, BW, y], fill=C(c, int(90 * (1 - t * 0.55))), width=2)
        d.line([0, hz, BW, hz], fill=C(self.pal[-1], 200), width=3)

    def _draw_stripes(self, d):
        BW, BH = self.BW, self.BH
        for i in range(1, min(6, len(self.pal))):
            y = BH * (0.40 + i * 0.055)
            d.rectangle([0, y, BW, y + BH * 0.016], fill=C(self.pal[i], max(10, 66 - i * 8)))

    def _draw_ridges(self, img):
        BW, BH = self.BW, self.BH
        rng = random.Random(self.profile_seed)
        horizon_col = mix(self.pal[2 % len(self.pal)], self.pal[1], 0.5)
        out = np.asarray(img).astype(np.float32)
        layers = 4
        for i in range(layers):
            t = i / max(1, layers - 1)
            base_y = BH * (0.52 + 0.13 * i)
            amp = BH * (0.22 - 0.045 * i)
            prof = smooth_profile(rng, 9 + i * 3, BW, rough=1.15 + i * 0.35)
            cc = mix(horizon_col, mix(self.pal[0], BLACK, 0.45), 0.25 + 0.72 * t)
            ys = base_y - prof * amp
            col_arr = np.asarray(cc, np.float32)
            yy = np.arange(BH)[:, None]
            mask = yy >= ys[None, :]
            out = np.where(mask[..., None], col_arr, out)
            # kabut tipis tepat di puncak lapisan
            band = np.exp(-((yy - ys[None, :]) / max(1.0, BH * 0.035)) ** 2)
            mist_col = np.asarray(mix(cc, self.pal[2 % len(self.pal)], 0.6), np.float32)
            a = (band * 0.16)[..., None]
            out = out * (1 - a) + mist_col * a
        return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))

    def _draw_pines(self, d):
        BW, BH = self.BW, self.BH
        rng = random.Random(self.profile_seed + 3)
        cc = mix(self.pal[0], self.pal[1], 0.3)
        ground = int(BH * 0.9)
        for _ in range(30):
            x = rng.uniform(-0.03, 1.03) * BW
            h = BH * rng.uniform(0.06, 0.2)
            w = h * rng.uniform(0.28, 0.42)
            y = ground + rng.uniform(-BH * 0.02, BH * 0.03)
            for k in range(4):
                yy = y - h * (k / 4)
                ww = w * (1 - k * 0.17)
                d.polygon([(x - ww / 2, yy), (x + ww / 2, yy), (x, yy - h * 0.45)],
                          fill=C(mix(cc, BLACK, k * 0.07), 255))

    def _draw_skyline(self, img, d):
        BW, BH = self.BW, self.BH
        rng = random.Random(self.profile_seed + 11)
        horizon = int(BH * 0.84)
        for layer_i in range(3):
            cc = mix(self.pal[0], self.pal[1], 0.10 + layer_i * 0.26)
            x = -BW * 0.05
            while x < BW * 1.05:
                w = BW * rng.uniform(0.03, 0.095)
                h = BH * rng.uniform(0.10, 0.40) * (0.6 + layer_i * 0.26)
                y = horizon - h + layer_i * BH * 0.02
                d.rectangle([x, y, x + w, BH], fill=C(cc, min(255, 205 + layer_i * 20)))
                if layer_i >= 1:
                    wc = self.pal[2 + rng.randrange(max(1, len(self.pal) - 2))]
                    for wy in range(int(y + h * 0.08), horizon - 4, max(7, int(BH * 0.019))):
                        for wx in range(int(x + w * 0.16), int(x + w * 0.86), max(6, int(BW * 0.013))):
                            if rng.random() < 0.33:
                                d.rectangle([wx, wy, wx + max(2, int(BW * 0.0035)),
                                             wy + max(3, int(BH * 0.008))],
                                            fill=C(wc, rng.randint(80, 210)))
                x += w + BW * rng.uniform(0.004, 0.022)

    def _draw_water(self, img):
        BW, BH = self.BW, self.BH
        hz = int(BH * 0.68)
        out = np.asarray(img).astype(np.float32)
        top = np.asarray(mix(self.pal[0], self.pal[2 % len(self.pal)], 0.30), np.float32)
        bot = np.asarray(mix(self.pal[0], BLACK, 0.35), np.float32)
        yy = np.arange(BH, dtype=np.float32)
        t = np.clip((yy - hz) / max(1, BH - hz), 0, 1)
        grad = top[None, :] * (1 - t[:, None]) + bot[None, :] * t[:, None]
        water = yy >= hz
        out = np.where(water[:, None, None], grad[:, None, :], out)
        # riak horizontal halus
        rng = np.random.default_rng(self.profile_seed)
        for i in range(26):
            y = int(hz + (BH - hz) * (rng.random() ** 1.6))
            x0 = rng.random() * BW * 0.8
            ln = BW * (0.04 + rng.random() * 0.22)
            a = 0.05 + 0.10 * rng.random()
            out[y, int(x0):int(x0 + ln)] = out[y, int(x0):int(x0 + ln)] * (1 - a) + \
                np.asarray(mix(self.pal[-1], WHITE, 0.4), np.float32) * a
        # kilau matahari/bulan di air
        cx = self.sun_pos[0] * BW
        for i in range(46):
            y = int(hz + (BH - hz) * ((i / 46) ** 1.5))
            w = BW * 0.006 * (1 + i / 14)
            a = max(0.02, 0.30 - i * 0.006)
            x0, x1 = int(cx - w), int(cx + w)
            if x1 > x0:
                out[y, x0:x1] = out[y, x0:x1] * (1 - a) + \
                    np.asarray(mix(self.pal[-1], WHITE, 0.55), np.float32) * a
        return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))

    def _draw_rings(self, d):
        BW, BH = self.BW, self.BH
        rng = random.Random(self.profile_seed + 17)
        for _ in range(4):
            cx = rng.uniform(0.2, 0.8) * BW
            cy = rng.uniform(0.2, 0.7) * BH
            r = BH * rng.uniform(0.12, 0.30)
            sq = rng.uniform(0.25, 0.6)
            d.ellipse([cx - r, cy - r * sq, cx + r, cy + r * sq],
                      outline=C(self.pal[2 % len(self.pal)], rng.randint(45, 100)),
                      width=max(2, int(BH * 0.004)))

    def _draw_shapes_static(self, d):
        BW, BH = self.BW, self.BH
        for s in self.shapes:
            cx, cy, r = s["x"] * BW, s["y"] * BH, s["r"] * BH
            cc = self.pal[s["ci"] % len(self.pal)]
            a = int(s["a"] * 255)
            k = s["kind"]
            if k == "ring":
                d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=C(cc, a), width=max(2, int(r * 0.06)))
            elif k == "dot":
                d.ellipse([cx - r * .25, cy - r * .25, cx + r * .25, cy + r * .25], fill=C(cc, a))
            elif k == "square":
                d.rectangle([cx - r * .6, cy - r * .6, cx + r * .6, cy + r * .6],
                            outline=C(cc, a), width=max(2, int(r * 0.05)))
            elif k == "tri":
                d.polygon([(cx, cy - r * .7), (cx - r * .65, cy + r * .5), (cx + r * .65, cy + r * .5)],
                          outline=C(cc, a), width=max(2, int(r * 0.05)))
            else:
                d.arc([cx - r, cy - r, cx + r, cy + r], 200, 340, fill=C(cc, a), width=max(2, int(r * 0.06)))

    def _add_fog(self, img, amount: float):
        BW, BH = self.BW, self.BH
        arr = np.asarray(img).astype(np.float32)
        for i in range(3):
            cc = mix(self.pal[-1], self.pal[2 % len(self.pal)], 0.4)
            add_glow(arr, BW * 0.5, BH * (0.58 + i * 0.13), BW * 0.95, BH * (0.09 + i * 0.045),
                     cc, amount * (0.24 - i * 0.06), power=1.5)
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

    def _add_smoke_static(self, img):
        BW, BH = self.BW, self.BH
        rng = random.Random(self.profile_seed + 23)
        arr = np.asarray(img).astype(np.float32)
        for _ in range(6):
            cc = mix(self.pal[1], (115, 108, 100), 0.5)
            add_glow(arr, rng.uniform(0.1, 0.9) * BW, rng.uniform(0.45, 0.95) * BH,
                     BW * 0.16, BH * 0.20, cc, 0.10 + rng.random() * 0.10, power=1.6)
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

    # --------------------------------------------------------- per frame

    def kenburns(self, t: float) -> np.ndarray:
        cam = self.sc.get("camera", {}) or {}
        p = ease(t)
        z = max(1.0, float(cam.get("z0", 1.0)) + (float(cam.get("z1", 1.1)) - float(cam.get("z0", 1.0))) * p)
        px = float(cam.get("px", 0)) + (float(cam.get("px1", 0)) - float(cam.get("px", 0))) * p
        py = float(cam.get("py", 0)) + (float(cam.get("py1", 0)) - float(cam.get("py", 0))) * p
        sw, sh = self.BW / z, self.BH / z
        x0 = (self.BW - sw) / 2 + px * self.BW
        y0 = (self.BH - sh) / 2 + py * self.BH
        box = (max(0, int(x0)), max(0, int(y0)), min(self.BW, int(x0 + sw)), min(self.BH, int(y0 + sh)))
        if box[2] - box[0] < 8 or box[3] - box[1] < 8:
            box = (0, 0, self.BW, self.BH)
        return np.asarray(self._base.crop(box).resize((self.W, self.H), Image.BILINEAR)).astype(np.float32)

    def render(self, t_abs: float) -> np.ndarray:
        t = clamp01(t_abs / self.dur)
        if self._base is None:
            self.build_base()
        arr = self.kenburns(t)
        arr = self._draw_dynamic(arr, t_abs)
        arr = self._post(arr, t_abs)
        img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
        img = self._draw_typography(img, t)
        arr = np.asarray(img).astype(np.float32)
        if self._bar:
            arr[:self._bar] = 0
            arr[-self._bar:] = 0
        return np.clip(arr, 0, 255).astype(np.uint8)

    # --------------------------------------------------------- dinamis

    def _draw_dynamic(self, arr: np.ndarray, T: float) -> np.ndarray:
        W, H = self.W, self.H
        S = self.speed
        E = self.elements

        if "clouds" in E:
            for c in self.clouds:
                x = ((c["x"] + T * c["v"] * S) % 1.35 - 0.17) * W
                y = (c["y"] + math.sin(T * 0.15 + c["x"] * 7) * 0.006) * H
                cc = mix(self.pal[-1], self.pal[2 % len(self.pal)], 0.5)
                add_glow(arr, x, y, c["s"] * W * 0.42, c["s"] * H * 0.10, cc, c["a"], power=1.6)

        if "fog" in E:
            for i in range(2):
                x = (0.5 + math.sin(T * 0.06 * S + i * 2.1) * 0.35) * W
                add_glow(arr, x, H * (0.66 + i * 0.12), W * 0.6, H * 0.085,
                         mix(self.pal[-1], WHITE, 0.3), 0.16, power=1.5)

        if "rays" in E or "sun" in E:
            cx, cy = self.sun_pos[0] * W, self.sun_pos[1] * H
            cc = self.pal[-1]
            yfade = (H * 0.52, H * 0.92)
            for i, r in enumerate(self.rays):
                ang = math.radians(r["ang"] + math.sin(T * 0.1 * S + i) * 5 * r["v"])
                length = H * 1.6
                wpx = r["w"] * W * (0.55 + 0.45 * math.sin(T * 0.25 * S + i * 1.7))
                a = r["a"] * (0.5 + 0.5 * math.sin(T * 0.35 * S + i))
                x2 = cx + math.sin(ang) * length
                y2 = cy + math.cos(ang) * length
                self._line_glow_fade(arr, cx, cy, x2, y2, max(2.0, wpx), cc, a, yfade)

        if "waves" in E:
            overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            d = ImageDraw.Draw(overlay, "RGBA")
            hz = int(H * 0.68)
            cc = mix(self.pal[-1], WHITE, 0.4)
            for i in range(6):
                y0 = hz + (H - hz) * (0.10 + i * 0.15)
                amp = H * (0.004 + i * 0.0024)
                pts = [(x, y0 + math.sin(x * (0.012 - i * 0.0006) + T * (1.1 + i * 0.25) * S + i) * amp)
                       for x in range(0, W + 10, 10)]
                d.line(pts, fill=C(cc, max(8, 62 - i * 8)), width=max(1, int(H * 0.0022)))
            arr = self._overlay(arr, overlay)

        if "birds" in E or "fish" in E or "shapes" in E or "streaks" in E or "traffic" in E:
            overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            d = ImageDraw.Draw(overlay, "RGBA")
            if "birds" in E:
                cbird = mix(self.pal[0], BLACK, 0.4)
                for b in self.birds:
                    x = ((b["x"] + T * b["v"] * S) % 1.25 - 0.12) * W
                    y = (b["y"] + math.sin(T * 0.5 * S + b["ph"]) * 0.02) * H
                    s = b["s"] * H * 0.019
                    flap = math.sin(T * 6 * S + b["ph"]) * 0.65 * s
                    y0 = min(y - flap, y + flap) - s * 0.5
                    y1 = max(y - flap, y + flap) + s * 0.5
                    if y1 <= y0:
                        y1 = y0 + 1
                    wln = max(1, int(s * 0.22))
                    d.arc([x - s, y0, x, y1], 200, 340, fill=C(cbird, 210), width=wln)
                    d.arc([x, y0, x + s, y1], 200, 340, fill=C(cbird, 210), width=wln)
            if "fish" in E:
                for f in self.fish:
                    x = ((f["x"] + T * f["v"] * S) % 1.3 - 0.15) * W
                    y = (f["y"] + math.sin(T * 0.7 * S + f["ph"]) * 0.03) * H
                    s = f["s"] * H * 0.022
                    dx = 1 if f["v"] > 0 else -1
                    cc = mix(self.pal[0], WHITE, 0.3)
                    d.ellipse([x - s, y - s * 0.42, x + s, y + s * 0.42], fill=C(cc, 130))
                    d.polygon([(x - s * dx, y), (x - s * 1.75 * dx, y - s * 0.5),
                               (x - s * 1.75 * dx, y + s * 0.5)], fill=C(cc, 110))
            if "shapes" in E:
                for s in self.shapes:
                    x = ((s["x"] + T * s["vx"] * S) % 1.2 - 0.1) * W
                    y = ((s["y"] + T * s["vy"] * S) % 1.2 - 0.1) * H
                    r = s["r"] * H * (0.85 + 0.15 * math.sin(T * 0.4 * S + s["rot"]))
                    cc = self.pal[s["ci"] % len(self.pal)]
                    a = s["a"] * 255 * (0.6 + 0.4 * math.sin(T * 0.5 * S + s["rot"]))
                    k = s["kind"]
                    if k == "ring":
                        d.ellipse([x - r, y - r, x + r, y + r], outline=C(cc, a), width=max(2, int(r * 0.05)))
                    elif k == "dot":
                        d.ellipse([x - r * .2, y - r * .2, x + r * .2, y + r * .2], fill=C(cc, a))
                    elif k == "square":
                        d.rectangle([x - r * .55, y - r * .55, x + r * .55, y + r * .55],
                                    outline=C(cc, a), width=max(2, int(r * 0.045)))
                    elif k == "tri":
                        d.polygon([(x, y - r * .65), (x - r * .6, y + r * .45), (x + r * .6, y + r * .45)],
                                  outline=C(cc, a), width=max(2, int(r * 0.045)))
                    else:
                        st = (T * 20 * S + s["rot"]) % 360
                        d.arc([x - r, y - r, x + r, y + r], st, (st + 140) % 360,
                              fill=C(cc, a), width=max(2, int(r * 0.05)))
            if "streaks" in E:
                cc = self.pal[-1]
                for s in self.streaks:
                    p = (s["x"] + T * s["v"] * S) % 1.45 - 0.22
                    y = s["y"] * H
                    x0 = p * W
                    d.line([x0, y, x0 + s["len"] * W, y], fill=C(cc, s["a"] * 190),
                           width=max(1, int(H * 0.002)))
            if "traffic" in E:
                for i in range(9):
                    y = H * (0.74 + (i % 4) * 0.045)
                    sp = (0.12 + 0.22 * (i % 3)) * S
                    x = ((i * 0.13 + T * sp) % 1.3 - 0.15) * W
                    cc = self.pal[-1] if i % 2 else self.pal[2 % len(self.pal)]
                    d.ellipse([x, y, x + W * 0.018, y + H * 0.007], fill=C(cc, 150))
            arr = self._overlay(arr, overlay)

        arr = self._draw_particles(arr, T)
        return arr

    def _line_glow_fade(self, arr, x0, y0, x1, y1, width, color, alpha, yfade):
        H, W = arr.shape[0], arr.shape[1]
        pad = width * 3 + 2
        bx0, bx1 = int(max(0, min(x0, x1) - pad)), int(min(W, max(x0, x1) + pad))
        by0, by1 = int(max(0, min(y0, y1) - pad)), int(min(H, max(y0, y1) + pad))
        if bx1 <= bx0 or by1 <= by0 or alpha <= 0.004:
            return
        ys = np.arange(by0, by1, dtype=np.float32)[:, None]
        xs = np.arange(bx0, bx1, dtype=np.float32)[None, :]
        vx, vy = x1 - x0, y1 - y0
        L2 = vx * vx + vy * vy or 1.0
        t = np.clip(((xs - x0) * vx + (ys - y0) * vy) / L2, 0.0, 1.0)
        px, py = x0 + t * vx, y0 + t * vy
        d = np.sqrt((xs - px) ** 2 + (ys - py) ** 2) / max(1e-6, width)
        m = np.clip(1.0 - d, 0.0, 1.0) ** 2
        fa = np.clip(1.0 - (ys[:, 0] - yfade[0]) / max(1e-6, yfade[1] - yfade[0]), 0.0, 1.0)
        m = m * fa[:, None] * alpha
        col = np.asarray(color[:3], np.float32)
        region = arr[by0:by1, bx0:bx1]
        region *= (1.0 - m[..., None])
        region += m[..., None] * col

    def _overlay(self, arr: np.ndarray, overlay: Image.Image) -> np.ndarray:
        ov = np.asarray(overlay).astype(np.float32)
        a = (ov[..., 3:4] / 255.0)
        return arr * (1 - a) + ov[..., :3] * a

    def _draw_particles(self, arr: np.ndarray, T: float) -> np.ndarray:
        W, H = self.W, self.H
        S = self.speed
        sharp: list[tuple] = []  # (jenis, x, y, param...) digambar via PIL sekali jalan
        for p in self.particles:
            kind = p["kind"]
            n = p["n"]
            x, y, z, sz, ph, vx = p["x"], p["y"], p["z"], p["sz"], p["ph"], p["vx"]

            if kind == "rain":
                xx = (x + T * 0.02 * S * z + np.sin(ph) * 0.01) % 1.0
                yy = (y + T * (0.85 + 0.5 * z) * S) % 1.0
                cc = mix(self.pal[-1], WHITE, 0.5)
                ln = H * 0.05
                for i in range(n):
                    sharp.append(("line", float(xx[i]) * W, float(yy[i]) * H,
                                  float(ln * z[i]), C(cc, 60 + 130 * float(z[i]))))

            elif kind == "snow":
                xx = (x + np.sin(T * 0.6 * S + ph * 3) * 0.02 + T * 0.008 * S) % 1.0
                yy = (y + T * (0.06 + 0.08 * z) * S) % 1.0
                self._glow_dots(arr, xx * W, yy * H, (1.1 + 3.2 * z) * (H / 1080) * 2.2,
                                WHITE, 0.28 + 0.5 * z, power=1.7)

            elif kind == "stars":
                tw = 0.5 + 0.5 * np.sin(T * 2.2 * S + ph * 5)
                self._glow_dots(arr, x * W, y * H * 0.85, (0.7 + 1.7 * z) * (H / 1080) * 2.4,
                                WHITE, tw * (0.22 + 0.6 * z), power=1.8)

            elif kind == "dust":
                xx = (x + np.sin(T * 0.25 * S + ph * 2) * 0.015 + T * 0.006 * S * vx) % 1.0
                yy = (y + np.cos(T * 0.2 * S + ph) * 0.012 - T * 0.004 * S) % 1.0
                cc = mix(self.pal[-1], WHITE, 0.5)
                self._glow_dots(arr, xx * W, yy * H, (0.8 + 2.2 * z) * (H / 1080) * 2.6, cc,
                                (0.10 + 0.26 * z) * (0.6 + 0.4 * np.sin(T * 1.3 + ph * 4)), power=1.8)

            elif kind == "bokeh":
                xx = (x + np.sin(T * 0.12 * S + ph) * 0.03) % 1.0
                yy = (y + np.cos(T * 0.1 * S + ph * 1.7) * 0.025) % 1.0
                r = (0.014 + 0.05 * sz) * H
                for i in range(n):
                    cc = self.pal[1 + (i % max(1, len(self.pal) - 1))]
                    a = (0.07 + 0.16 * float(z[i])) * (0.7 + 0.3 * math.sin(T * 0.8 * S + float(ph[i]) * 3))
                    add_glow(arr, float(xx[i]) * W, float(yy[i]) * H, float(r[i]), float(r[i]),
                             cc, a, power=1.35)

            elif kind == "fireflies":
                xx = (x + np.sin(T * 0.4 * S + ph * 3) * 0.05) % 1.0
                yy = (y + np.cos(T * 0.33 * S + ph * 2) * 0.04) % 1.0
                pulse = np.clip(np.sin(T * 2.4 * S + ph * 6) * 0.5 + 0.5, 0, 1) ** 2
                self._glow_dots(arr, xx * W, yy * H, (1.4 + 2.6 * z) * (H / 1080) * 2.6,
                                (255, 240, 150), pulse * 0.8, power=1.6)

            elif kind == "embers":
                yy = (y - T * (0.10 + 0.22 * z) * S) % 1.0
                xx = (x + np.sin(T * 0.9 * S + ph * 4) * 0.03) % 1.0
                fl = 0.5 + 0.5 * np.sin(T * 6 * S + ph * 9)
                cc = mix(self.pal[-1], self.pal[-2] if len(self.pal) > 1 else self.pal[-1], 0.4)
                self._glow_dots(arr, xx * W, (0.30 + yy * 0.75) * H,
                                (0.9 + 2.6 * z) * (H / 1080) * 2.4, cc,
                                (0.16 + 0.5 * fl) * z, power=1.7)

            elif kind == "bubbles":
                yy = (y - T * (0.05 + 0.12 * z) * S) % 1.0
                xx = (x + np.sin(T * 0.8 * S + ph * 3) * 0.012) % 1.0
                r = (1.2 + 4.5 * z) * (H / 1080)
                for i in range(n):
                    sharp.append(("ring", float(xx[i]) * W, float(yy[i]) * H, float(r[i]),
                                  C((230, 250, 255), 60 + 120 * float(z[i]))))

            elif kind == "petals":
                yy = (y + T * (0.05 + 0.09 * z) * S) % 1.0
                xx = (x + np.sin(T * 0.5 * S + ph * 2) * 0.06) % 1.0
                r = (1.6 + 4.0 * z) * (H / 1080)
                cc = self.pal[-2] if len(self.pal) > 1 else self.pal[-1]
                for i in range(n):
                    sharp.append(("ell", float(xx[i]) * W, float(yy[i]) * H, float(r[i]),
                                  C(cc, 110 + 100 * float(z[i]))))

            elif kind == "leaves":
                yy = (y + T * (0.04 + 0.07 * z) * S) % 1.0
                xx = (x + np.sin(T * 0.4 * S + ph * 2) * 0.08) % 1.0
                r = (2.0 + 5.0 * z) * (H / 1080)
                cc = self.pal[2 % len(self.pal)]
                for i in range(n):
                    sharp.append(("ell", float(xx[i]) * W, float(yy[i]) * H, float(r[i]),
                                  C(cc, 130 + 90 * float(z[i]))))

            elif kind == "smoke":
                xx = (x + np.sin(T * 0.1 * S + ph) * 0.04) % 1.0
                yy = (y - T * 0.02 * S) % 1.0
                cc = mix(self.pal[1], (95, 88, 82), 0.6)
                for i in range(n):
                    add_glow(arr, float(xx[i]) * W, (0.4 + float(yy[i]) * 0.62) * H,
                             (0.05 + 0.13 * float(sz[i])) * W, (0.06 + 0.15 * float(sz[i])) * H,
                             cc, 0.05 + 0.09 * float(z[i]), power=1.5)

        if sharp:
            overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            d = ImageDraw.Draw(overlay, "RGBA")
            for item in sharp:
                k, px, py = item[0], item[1], item[2]
                if k == "line":
                    ln, colr = item[3], item[4]
                    d.line([px, py, px - ln * 0.16, py + ln], fill=colr,
                           width=max(1, int(ln * 0.05)))
                elif k == "ring":
                    r, colr = item[3], item[4]
                    d.ellipse([px - r, py - r, px + r, py + r], outline=colr,
                              width=max(1, int(r * 0.28)))
                else:
                    r, colr = item[3], item[4]
                    d.ellipse([px - r, py - r * 0.5, px + r, py + r * 0.5], fill=colr)
            arr = self._overlay(arr, overlay)
        return arr

    def _glow_dots(self, arr, xs, ys, rs, color, alphas, power: float = 1.8):
        """Banyak titik glow kecil: gambar sekaligus di satu buffer lokal."""
        H, W = arr.shape[0], arr.shape[1]
        xs = np.asarray(xs, np.float32)
        ys = np.asarray(ys, np.float32)
        rs = np.asarray(rs, np.float32)
        al = np.clip(np.asarray(alphas, np.float32), 0, 1)
        col = np.asarray(color[:3], np.float32)
        for i in range(len(xs)):
            a = float(al[i])
            r = float(rs[i])
            if a < 0.015 or r < 0.6:
                continue
            add_glow(arr, float(xs[i]), float(ys[i]), r, r, col, a, power=power)

    # --------------------------------------------------------- post FX

    def _post(self, arr: np.ndarray, T: float) -> np.ndarray:
        g = self.grade
        contrast = float(g.get("contrast", 1.0))
        sat = float(g.get("sat", 1.0))
        temp = float(g.get("temp", 0.0)) / 100.0
        glow = float(g.get("glow", 0.0))
        grain = float(g.get("grain", 0.0))

        if abs(contrast - 1.0) > 1e-3:
            arr = (arr - 128.0) * contrast + 128.0
        if abs(sat - 1.0) > 1e-3:
            lum = arr @ self._lum
            arr = lum[..., None] + (arr - lum[..., None]) * sat
        if abs(temp) > 1e-3:
            arr[..., 0] += temp * 24
            arr[..., 2] -= temp * 24
        arr = np.clip(arr, 0, 255)

        if self.b_strength > 0.01 and glow > 0.01:
            small = np.asarray(Image.fromarray(arr.astype(np.uint8)).resize(
                (self._bloom_w, self._bloom_h), Image.BILINEAR)).astype(np.float32)
            lum = small @ self._lum
            m = np.clip((lum - 175) / 80.0, 0, 1) ** 1.7
            bright = small * m[..., None]
            glow_img = Image.fromarray(np.clip(bright, 0, 255).astype(np.uint8)).filter(
                ImageFilter.GaussianBlur(max(2, self._bloom_h // 14)))
            glow_arr = np.asarray(glow_img.resize((self.W, self.H), Image.BILINEAR)).astype(np.float32)
            arr = np.clip(arr + glow_arr * (0.6 * glow * self.b_strength), 0, 255)

        if self._ca_px:
            k = self._ca_px
            arr[..., 0] = np.roll(arr[..., 0], k, axis=1)
            arr[..., 2] = np.roll(arr[..., 2], -k, axis=1)

        arr = arr * (0.66 + 0.34 * self._vig)

        if self.g_strength > 0.01 and grain > 0.005:
            hw, hwid = max(8, self.H // 2), max(8, self.W // 2)
            n = np.random.default_rng(int(T * self.fps) & 0xFFFF).standard_normal(
                (hw, hwid), dtype=np.float32)
            n_full = np.asarray(Image.fromarray(((n + 4) * 30).clip(0, 255).astype(np.uint8))
                                .resize((self.W, self.H), Image.BILINEAR)).astype(np.float32)
            n_full = (n_full - 120.0) / 30.0  # ~ N(0,1)
            arr = arr + n_full[..., None] * (grain * 26.0 * self.g_strength)
        return np.clip(arr, 0, 255)

    # --------------------------------------------------------- tipografi

    def _draw_typography(self, frame, t: float):
        W, H = self.W, self.H
        idx = int(self.sc.get("index", 0))
        cap = (self.sc.get("caption") or "").strip()
        if not cap:
            return frame
        in_a = clamp01((t - 0.05) / 0.18)
        out_a = clamp01((0.97 - t) / 0.18)
        alpha = ease(in_a) * ease(out_a)
        if alpha <= 0.02:
            return frame

        accent = self.pal[-1] if len(self.pal) > 1 else (255, 255, 255)
        dark_bg = (sum(self.pal[0]) / 3) < 140
        txt_col = WHITE if dark_bg else (18, 18, 22)
        is_hero = (idx == 0)
        fnt = font(int(H * (0.066 if is_hero else 0.048)), True)
        per_line = 26 if W >= H else 18
        lines = planner.wrap_lines(cap, per_line=per_line, max_lines=3)
        lh = int(fnt.size * 1.26)
        rise = (1 - ease(in_a)) * H * 0.05

        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(ov, "RGBA")
        total_h = lh * len(lines)
        y = (H * 0.44 if is_hero else H * 0.12) - total_h / 2 + rise

        if is_hero:
            kicker = "AURORA  ·  AI  VIDEO  STUDIO"
            kf = font(int(H * 0.02), True)
            kw = d.textlength(kicker, font=kf)
            ky = y - H * 0.06
            d.rectangle([(W - kw) / 2, ky + kf.size * 1.55,
                         (W + kw) / 2, ky + kf.size * 1.55 + max(2, H * 0.0028)],
                        fill=C(accent, alpha * 185))
            d.text(((W - kw) / 2, ky), kicker, font=kf, fill=C(accent, alpha * 235))

        shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        sd = ImageDraw.Draw(shadow)
        for i, ln in enumerate(lines):
            tw = d.textlength(ln, font=fnt)
            sd.text(((W - tw) / 2 + 2, y + i * lh + 3), ln, font=fnt, fill=C(BLACK, alpha * 160))
        shadow = shadow.filter(ImageFilter.GaussianBlur(max(2, int(H * 0.006))))
        ov = Image.alpha_composite(ov, shadow)
        d = ImageDraw.Draw(ov, "RGBA")
        for i, ln in enumerate(lines):
            tw = d.textlength(ln, font=fnt)
            d.text(((W - tw) / 2, y + i * lh), ln, font=fnt, fill=C(txt_col, alpha * 255))

        return Image.alpha_composite(frame.convert("RGBA"), ov).convert("RGB")


# ==================================================================
#  SUBTITLE
# ==================================================================

def burn_subtitle(arr: np.ndarray, text: str, H: int, W: int,
                  progress: float = -1.0, box: bool = True) -> np.ndarray:
    if not text:
        return arr
    size = max(12, int(H * 0.033))
    f = font(size, True)
    img = Image.fromarray(arr).convert("RGBA")
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov, "RGBA")
    words = text.split()
    if not words:
        return arr
    maxw = W * 0.84
    lines, cur = [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if d.textlength(trial, font=f) > maxw and cur:
            lines.append(cur)
            cur = w
        else:
            cur = trial
    if cur:
        lines.append(cur)
    lines = lines[-2:]
    lh = int(size * 1.4)
    y0 = H - int(H * 0.085) - lh * len(lines)
    if y0 < int(H * 0.55):
        y0 = int(H * 0.55)
    for li, ln in enumerate(lines):
        tw = d.textlength(ln, font=f)
        x = (W - tw) / 2
        y = y0 + li * lh
        if box:
            pad = int(size * 0.5)
            d.rounded_rectangle([x - pad, y - pad * 0.5, x + tw + pad, y + size + pad * 0.55],
                                radius=int(size * 0.4), fill=C((8, 8, 12), 165))
        d.text((x + 2, y + 2), ln, font=f, fill=C(BLACK, 190))
        d.text((x, y), ln, font=f, fill=C(WHITE, 255))
        if progress >= 0:
            lw = ln.split()
            acc = ""
            for wi, w in enumerate(lw):
                if progress >= (wi + 1) / max(1, len(lw)):
                    wx = x + (d.textlength(acc + " ", font=f) if acc else 0)
                    d.text((wx, y), w, font=f, fill=C((255, 224, 130), 255))
                acc = (acc + " " + w).strip()
    return np.asarray(Image.alpha_composite(img, ov).convert("RGB"))
