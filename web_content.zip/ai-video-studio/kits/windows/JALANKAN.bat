@echo off
setlocal EnableExtensions
title Aurora Studio - AI Video Generator
cd /d "%~dp0.."
echo.
echo   ======================================================
echo     AURORA STUDIO  -  AI Video Generator  (Windows)
echo     teks/gambar -^> video sinematik siap unduh
echo   ======================================================
echo.
where python >nul 2>&1
if errorlevel 1 (
  echo [X] Python tidak ditemukan.
  echo     Instal Python 3.10+ dari https://python.org
  echo     dan CENTANG "Add python.exe to PATH" saat instalasi.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Membuat virtualenv ...
  python -m venv .venv || (echo Gagal membuat virtualenv. & pause & exit /b 1)
  echo [2/3] Menginstal dependensi (flask, pillow, numpy, ffmpeg, edge-tts) ...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || (echo Gagal instal dependensi. Periksa koneksi internet. & pause & exit /b 1)
) else (
  echo [OK] Virtualenv sudah tersedia.
)
echo [3/3] Menjalankan server: http://localhost:8000
echo       Browser akan terbuka otomatis. Tekan Ctrl+C untuk berhenti.
echo.
start "" http://localhost:8000
".venv\Scripts\python.exe" app.py
pause
