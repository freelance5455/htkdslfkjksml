# 🪟 Aurora Studio di Windows

## Cara tercepat (one-click)

1. Ekstrak ZIP ini di mana saja, mis. `D:\AuroraStudio`.
2. Dobel-klik **`Windows\JALANKAN.bat`**.
   - Otomatis: membuat virtualenv → install dependensi → menjalankan server → membuka browser.
3. Aplikasi terbuka di `http://localhost:8000`. Render video langsung dari PC Anda.

> Butuh **Python 3.10+** terinstal dengan opsi *“Add python.exe to PATH”* tercentang.
> Semua dependensi lain (termasuk ffmpeg) diunduh otomatis saat pertama kali.

## Mengemas jadi EXE mandiri

Dobel-klik **`Windows\Buat-EXE.bat`** → menghasilkan `dist\AuroraStudio.exe`
(±150 MB karena ffmpeg dibundel). EXE bisa dipindah ke PC lain **tanpa Python**.
Saat dijalankan, exe menyimpan data (video, galeri) di `%USERPROFILE%\AuroraStudio`.

## Akses dari Android / perangkat lain di rumah

Server mendengar di semua interface (`0.0.0.0`). Dari HP Android di Wi-Fi yang sama:

1. Cari IP PC: `ipconfig` → mis. `192.168.1.10`.
2. Buka Chrome di HP: `http://192.168.1.10:8000`.
3. Menu Chrome ⋮ → **Add to Home screen** → aplikasi terpasang seperti native (PWA).

Bila tidak terbuka, izinkan Python melalui Windows Firewall (popup pertama kali)
atau: `netsh advfirewall firewall add rule name="Aurora Studio" dir=in action=allow protocol=TCP localport=8000`.

## Narasi suara (TTS)

Membutuhkan internet saat generate (layanan edge-tts). Tanpa internet, video tetap
jadi lengkap dengan musik — hanya narasi yang dilewati.

## Troubleshooting

| Gejala | Solusi |
|---|---|
| `'python' is not recognized` | Instal ulang Python dengan centang *Add to PATH*, atau ganti `python` di bat dengan path lengkap. |
| Port 8000 terpakai | Set env `PORT=8080` lalu jalankan bat, atau matikan aplikasi lain di port 8000. |
| Render lambat | Pakai resolusi 480p / 24 fps untuk pratinjau; 1080p untuk final. |
| Antivirus memblokir exe PyInstaller | Tambahkan pengecualian folder `dist\`, atau jalankan via `JALANKAN.bat`. |
