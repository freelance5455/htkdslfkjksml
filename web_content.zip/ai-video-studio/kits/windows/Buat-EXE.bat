@echo off
setlocal EnableExtensions
title Aurora Studio - Builder EXE
cd /d "%~dp0.."
echo.
echo   Mengemas Aurora Studio menjadi AuroraStudio.exe (mandiri, sekali klik)
echo.
if not exist ".venv\Scripts\python.exe" (
  echo [!] Virtualenv belum ada. Jalankan JALANKAN.bat sekali dulu, lalu ulangi.
  pause
  exit /b 1
)
echo [1/2] Memastikan PyInstaller terpasang ...
".venv\Scripts\python.exe" -m pip install -q pyinstaller || (echo Gagal instal pyinstaller. & pause & exit /b 1)
echo [2/2] Building ... (butuh beberapa menit, file +- 150 MB karena ffmpeg dibundel)
".venv\Scripts\pyinstaller.exe" --noconfirm --clean --onefile --name AuroraStudio ^
  --add-data "templates;templates" ^
  --add-data "static;static" ^
  --collect-all imageio_ffmpeg ^
  --hidden-import edge_tts ^
  app.py || (echo Build gagal. & pause & exit /b 1)
echo.
echo   SELESAI: dist\AuroraStudio.exe
echo   Saat pertama dijalankan, exe membuat folder data di %%USERPROFILE%%\AuroraStudio
pause
