# 🤖 Aurora Studio di Android

Tiga cara, dari yang paling ringan sampai aplikasi native penuh:

---

## Opsi 1 — Pasang sebagai PWA (paling mudah, 30 detik)

Cocok bila server Aurora berjalan di PC/laptop rumah atau di VPS.

1. Pastikan server jalan di PC: dobel-klik `Windows\JALANKAN.bat` (lihat README-WINDOWS.md).
2. Di HP (Wi-Fi yang sama), buka Chrome → `http://IP-PC:8000` (cek IP PC dengan `ipconfig`).
3. Menu Chrome **⋮ → Add to Home screen** (atau tombol **📱 Pasang Aplikasi** di bilah atas web).
4. Ikon Aurora muncul di home screen; terbuka fullscreen seperti aplikasi native,
   lengkap dengan ikon, splash, dan bisa bekerja offline untuk halaman shell.

---

## Opsi 2 — Engine lengkap BERJALAN DI HP (Termux)

Seluruh mesin render (planner AI, renderer, musik, ffmpeg, TTS) jalan langsung
di perangkat Android — tidak butuh PC sama sekali.

1. Instal **Termux** dari F-Droid (disarankan) atau Play Store.
2. Salin ZIP ini ke HP, lalu di Termux:
   ```bash
   termux-setup-storage          # sekali, beri izin storage
   cp -r /sdcard/Download/AuroraStudio ~
   bash ~/AuroraStudio/Android/termux-install.sh
   bash ~/AuroraStudio/Android/termux-run.sh
   ```
3. Buka Chrome: `http://127.0.0.1:8000` → **⋮ → Add to Home screen**.
4. Optional: `termux-wake-lock` agar render lanjut saat layar mati;
   `termux-boot` (addon) untuk auto-start saat HP dinyalakan.

Catatan performa: render 8 dtk @480p ≈ 20–40 dtk di HP menengah; gunakan 480p/24 fps
untuk pratinjau, 720p untuk final.

---

## Opsi 3 — APK native (WebView wrapper)

Folder **`apk-project/`** adalah proyek Android Studio lengkap yang membungkus
Aurora dalam aplikasi native ber-WebView (ikon sendiri, fullscreen, tombol back
benar, unduhan via DownloadManager).

1. Buka Android Studio → **Open** → pilih folder `apk-project`.
2. Sync Gradle → **Build → Build APK(s)** (atau `./gradlew assembleDebug` bila SDK terpasang).
3. Instal `app/build/outputs/apk/debug/app-debug.apk` ke HP.
4. Saat pertama dibuka, aplikasi menanyakan alamat server Aurora:
   - `http://127.0.0.1:8000` bila engine jalan di Termux HP yang sama (Opsi 2), atau
   - `http://192.168.x.x:8000` bila engine di PC rumah.
   (Bisa diganti kapan pun lewat menu ⋮ → “Ganti server”.)

Butuh JDK 17 + Android SDK (disiapkan otomatis oleh Android Studio).

---

## Perbandingan

| | PWA (Opsi 1) | Termux (Opsi 2) | APK (Opsi 3) |
|---|---|---|---|
| Butuh PC server | ✅ ya | ❌ tidak | tergantung pilihan URL |
| Install di HP | home-screen icon | Termux + PWA | file APK |
| Render di HP | ❌ | ✅ | ❌ (klien saja) |
| Ukuran | ~0 MB | ±350 MB (pkg) | ±4 MB |
