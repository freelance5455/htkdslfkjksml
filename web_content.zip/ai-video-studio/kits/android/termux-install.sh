#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  Aurora Studio — installer Termux (Android)
#  Jalankan:  bash termux-install.sh
# ============================================================
set -e

echo ""
echo "  🎬 Aurora Studio — instalasi Termux (Android)"
echo ""

# 1) paket sistem: python + ffmpeg ARM native + lib gambar
echo "[1/4] Memperbarui paket & menginstal python, ffmpeg, libjpeg, libpng ..."
pkg update -y
pkg install -y python python-pip ffmpeg libjpeg-turbo libpng zlib

# 2) numpy & pillow dari repo Termux (wheel siap pakai, tanpa compile)
echo "[2/4] Menginstal python-numpy & python-pillow ..."
pkg install -y python-numpy python-pillow

# 3) dependensi python murni via pip
echo "[3/4] Menginstal flask & edge-tts ..."
pip install --upgrade pip
pip install flask edge-tts

# 4) verifikasi
echo "[4/4] Verifikasi ..."
python - <<'PY'
import importlib, shutil
for m in ("flask", "PIL", "numpy", "edge_tts"):
    importlib.import_module(m)
    print("   ✓", m)
ff = shutil.which("ffmpeg")
print("   ✓ ffmpeg sistem:", ff)
PY

cat <<'EOF'

  ✅ Instalasi selesai!

  Langkah berikutnya:
    1) Ekstrak/letakkan folder AuroraStudio di Termux, mis:
         cp -r /sdcard/Download/AuroraStudio ~/   (beri izin: termux-setup-storage)
    2) Jalankan:  bash Android/termux-run.sh
    3) Buka Chrome: http://127.0.0.1:8000
    4) Menu ⋮ → "Add to Home screen" supaya jadi aplikasi di home screen.

  Tips: jalankan `termux-wake-lock` agar render tidak dihentikan sistem
  saat layar mati.
EOF
