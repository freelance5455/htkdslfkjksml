#!/data/data/com.termux/files/usr/bin/bash
# Menjalankan Aurora Studio di Termux (Android).
# Pakai ffmpeg sistem Termux (ARM) — imageio-ffmpeg x86_64 tidak kompatibel.
set -e
cd "$(dirname "$0")/.."   # ke root project (folder yang memuat app.py)

if [ ! -f app.py ]; then
  echo "app.py tidak ditemukan di $(pwd)."
  echo "Pastikan struktur folder: <root>/app.py dan <root>/Android/termux-run.sh"
  exit 1
fi

export AURORA_FFMPEG="$(command -v ffmpeg)"
export PORT="${PORT:-8000}"

echo ""
echo "  🎬 Aurora Studio berjalan di Android Anda:"
echo "     → http://127.0.0.1:${PORT}"
echo "     → dari perangkat lain: http://$(ip route get 1 2>/dev/null | awk '{print $7; exit}'):${PORT}"
echo ""
exec python app.py
