# 📱 Membangun APK Aurora Studio (WebView wrapper)

Proyek ini membungkus aplikasi web Aurora Studio menjadi **APK native**:
ikon sendiri, fullscreen, tombol back benar, dan unduhan MP4/ZIP otomatis
masuk folder Downloads via DownloadManager.

## Kebutuhan

- JDK 17
- Android SDK (compileSdk 34) — Android Studio menyiapkannya otomatis
- (Opsional) Gradle 8+ bila build via CLI

## Build via Android Studio (disarankan)

1. **Open** → pilih folder `apk-project` ini.
2. Tunggu Gradle sync selesai.
3. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
4. APK ada di `app/build/outputs/apk/debug/app-debug.apk` — instal ke HP
   (izinkan *install unknown apps* bila diminta).

## Build via CLI

```bash
# sekali: pasang cmdline-tools & platform
sdkmanager "platforms;android-34" "build-tools;34.0.0"

gradle wrapper --gradle-version 8.4   # bila belum ada gradlew
./gradlew assembleDebug
```

## Menghubungkan ke engine

Saat pertama dibuka, aplikasi menanyakan alamat server Aurora:

| Engine berada di | Isi alamat |
|---|---|
| Termux, HP yang sama | `http://127.0.0.1:8000` |
| PC rumah (Wi-Fi sama) | `http://192.168.x.x:8000` (lihat `ipconfig`) |
| VPS / server publik | `https://domain-anda.com` |

Ganti kapan saja lewat menu **⋮ → Ganti server**.

> HTTP polos diizinkan lewat `network_security_config` agar koneksi LAN/Termux
> berfungsi tanpa sertifikat TLS.

## Kustomisasi cepat

- Ikon: ganti `app/src/main/res/mipmap-hdpi/ic_launcher.png`.
- Nama aplikasi: `app/src/main/res/values/strings.xml`.
- Server bawaan: ubah `default_server` di strings.xml.
