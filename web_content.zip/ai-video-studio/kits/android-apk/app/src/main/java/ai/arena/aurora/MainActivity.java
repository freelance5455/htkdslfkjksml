package ai.arena.aurora;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

/**
 * Aurora Studio — wrapper native Android.
 * Membungkus aplikasi web Aurora (engine di Termux/PC/LAN) dalam WebView
 * fullscreen dengan penanganan unduhan (MP4/ZIP) via DownloadManager.
 */
public class MainActivity extends Activity {

    private static final String PREF = "aurora_prefs";
    private static final String KEY_URL = "server_url";
    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setDatabaseEnabled(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        CookieManager.getInstance().setAcceptCookie(true);

        // unduhan video/zip dari aplikasi web -> DownloadManager
        web.setDownloadListener((url, ua, contentDisposition, mimetype, contentLength) -> {
            String name = URLUtil.guessFileName(url, contentDisposition, mimetype);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setMimeType(mimetype);
            req.addRequestHeader("User-Agent", ua);
            req.setTitle(name);
            req.setDescription("Aurora Studio");
            req.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            getSystemService(DownloadManager.class).enqueue(req);
        });

        String url = prefs().getString(KEY_URL, null);
        if (url == null) {
            askServer(true);
        } else {
            web.loadUrl(url);
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREF, MODE_PRIVATE);
    }

    private void askServer(boolean firstRun) {
        final EditText input = new EditText(this);
        input.setHint(R.string.server_hint);
        input.setText(prefs().getString(KEY_URL, getString(R.string.default_server)));
        input.setSingleLine(true);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        new AlertDialog.Builder(this)
                .setTitle(R.string.server_prompt)
                .setView(input)
                .setCancelable(!firstRun)
                .setPositiveButton("Simpan & Buka", (d, w) -> {
                    String url = input.getText().toString().trim();
                    if (url.isEmpty()) url = getString(R.string.default_server);
                    prefs().edit().putString(KEY_URL, url).apply();
                    web.loadUrl(url);
                })
                .setNegativeButton("Batal", (d, w) -> {
                    if (!firstRun) return;
                    String url = getString(R.string.default_server);
                    prefs().edit().putString(KEY_URL, url).apply();
                    web.loadUrl(url);
                })
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, R.string.change_server);
        menu.add(0, 2, 0, "Muat ulang");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) {
            askServer(false);
            return true;
        }
        if (item.getItemId() == 2) {
            web.reload();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
