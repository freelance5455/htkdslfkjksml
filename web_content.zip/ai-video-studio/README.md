# 🎬 Aurora Studio — AI Video Generator

Aplikasi web **text-to-video** dan **image-to-video** yang menghasilkan video sinematik
**siap unduh (MP4 H.264 + AAC)** — lengkap dengan musik latar, narasi suara (TTS),
subtitle, poster, dan berkas storyboard.

Dua mesin render:

| Mesin | Kebutuhan | Keterangan |
|---|---|---|
| ⚙️ **Engine Lokal (default)** | tanpa API key, tanpa GPU | *Procedural Cinema Engine*: AI planner menganalisis prompt (mood, palet warna, elemen visual, gerakan kamera) lalu merender adegan generatif per-frame (gradien langit, siluet gunung/kota, partikel hujan/salju/kunang-kunang, sinar volumetrik, Ken Burns, bloom, grain, vignette, aberasi kromatik) dan menyintesis musik latar secara prosedural. |
| ☁️ **Cloud AI (opsional)** | API key pengguna | Adapter siap pakai untuk **Google Veo, Runway Gen-4, Luma Dream Machine, Replicate, fal.ai, Stability**. Hasil video diunduh otomatis ke galeri yang sama. |

---

## 🚀 Menjalankan

```bash
pip install -r requirements.txt
python3 app.py            # buka http://localhost:8000
```

atau `./run.sh` (membuat virtualenv otomatis bila belum ada).

Kebutuhan: Python 3.10+, ffmpeg disediakan otomatis lewat paket `imageio-ffmpeg`
(tidak perlu install ffmpeg sistem). Narasi TTS (edge-tts) butuh internet;
tanpa internet aplikasi tetap berfungsi penuh tanpa narasi.

## ✨ Fitur

- **Text → Video**: prompt bebas (ID/EN) → storyboard otomatis (1–8 adegan),
  deteksi 12 mood (senja, neon/cyberpunk, laut, hutan, kosmik, minimal, hujan,
  retro, api, mimpi, salju, kota) + palet & elemen visual per mood.
- **Image → Video**: hingga 6 gambar → video Ken Burns sinematik dengan transisi,
  grade warna, partikel, dan musik.
- **Gerakan kamera**: zoom in/out, pan, tilt, drift (dipilih AI per adegan).
- **Transisi**: fade, dissolve, smoothleft, circleopen, wipe, radial, zoomin, dll.
- **Audio**: musik latar tersintesis sesuai mood (ambient/synthwave/epic/dream…),
  narasi TTS 6 suara (ID/EN/JP) + *auto-ducking* musik saat narasi bicara,
  durasi adegan otomatis menyesuaikan panjang narasi.
- **Teks**: judul per adegan, subtitle terbakar (opsi efek karaoke), ekspor `.srt`.
- **Format**: rasio 16:9 / 9:16 / 1:1 / 4:5 / 21:9 · resolusi 480p–1080p · 24/30/60 fps.
- **Unduhan**: MP4, bundle ZIP (video+poster+SRT+storyboard+metadata), poster JPG,
  SRT, JSON storyboard, serta **ZIP seluruh source code** aplikasi.
- **Galeri**: riwayat video dengan poster, putar ulang, unduh, hapus.
- **API REST**: `/api/generate`, `/api/status/<id>`, `/api/analyze`, `/api/gallery`,
  `/video/<id>`, `/download/<id>`, `/api/cloud/*`.

## 🧠 Cara kerja Engine Lokal

1. **Planner** (`engine/planner.py`) — NLP ringan: tokenisasi kalimat → adegan,
   skoring kata kunci mood (ID+EN), ekstraksi elemen (hujan, salju, kunang-kunang,
   skyline, nebula…), pemilihan gerakan kamera & palet warna; semua *seeded*
   sehingga hasil reproducible.
2. **Renderer** (`engine/visual.py`) — menggambar base statis per adegan
   (langit gradien, matahari/bulan, punggung gunung, skyline berjendela, air +
   refleksi) lalu animasi per-frame via numpy (glow partikel, awan, kabut, sinar)
   + grade sinematik (kontras, saturasi, temperatur, bloom, grain, vignette, CA).
3. **Musik** (`engine/music.py`) — sintesis aditif: progresi akor per mood, pad,
   bass, arpeggio, perkusi, riser, reverb sederhana → WAV stereo.
4. **Narasi** (`engine/tts.py`) — edge-tts (Microsoft neural voices).
5. **Encoder** (`engine/encoder.py`) — pipe frame mentah ke ffmpeg (libx264 CRF 18),
   xfade antar adegan, mix audio (sidechain ducking), mux AAC → MP4 faststart.

## 🖥️📱 Menjalankan di Windows & Android

| Platform | Cara | Berkas |
|---|---|---|
| 🪟 Windows | Dobel-klik one-click launcher (venv+dependensi otomatis, buka browser) | `Windows/JALANKAN.bat` di kit ZIP |
| 🪟 Windows (EXE mandiri) | Build `AuroraStudio.exe` via PyInstaller (ffmpeg dibundel) | `Windows/Buat-EXE.bat` |
| 🤖 Android PWA | Chrome → ⋮ → *Add to Home screen* / tombol **📱 Pasang Aplikasi** | manifest + service worker bawaan |
| 🤖 Android engine lokal | Seluruh mesin render jalan di HP via Termux | `Android/termux-install.sh`, `Android/termux-run.sh` |
| 🤖 Android APK native | Proyek Gradle WebView wrapper siap build | `Android/apk-project/` |

Unduh paket siap pakai dari aplikasi: menu **📦 Kit Windows & Android**
(endpoint `/download/kit/windows`, `/download/kit/android`, `/download/kit/all`).
Panduan lengkap: `kits/windows/README-WINDOWS.md` dan `kits/android/README-ANDROID.md`.

## ☁️ Konfigurasi Cloud AI (opsional)

Buka menu **Cloud AI** di aplikasi, tempel key Anda (disimpan lokal di
`config/providers.json`, chmod 600), atau set environment variable:
`GEMINI_API_KEY`, `RUNWAY_API_KEY`, `LUMA_API_KEY`, `REPLICATE_API_TOKEN`,
`FAL_KEY`, `STABILITY_API_KEY`. Pilih provider pada dropdown sebelum generate.

## 🗂️ Struktur

```
ai-video-studio/
├── app.py               # server Flask + job queue + endpoint unduhan
├── engine/
│   ├── planner.py       # AI planner: mood, palet, storyboard
│   ├── visual.py        # renderer visual generatif per-frame
│   ├── music.py         # sintesis musik latar
│   ├── tts.py           # narasi edge-tts
│   ├── encoder.py       # ffmpeg: encode, transisi, mix audio, SRT
│   ├── pipeline.py      # orkestrasi job end-to-end
│   └── cloud.py         # adapter provider AI cloud (opsional)
├── templates/index.html # UI studio
├── static/css, static/js
├── workspace/           # upload + job (runtime)
└── outputs/             # (runtime)
```

## ⚠️ Catatan

- Render 12 dtk @720p/30fps ≈ 40–70 dtk di CPU 2 core; gunakan 480p/24fps untuk pratinjau cepat.
- Server development Flask single-thread untuk render (pool 2 worker); untuk produksi
  jalankan di balik gunicorn/uwsgi dengan worker terpisah.
- Semua hasil render tersimpan di `workspace/jobs/<id>/out/`.
