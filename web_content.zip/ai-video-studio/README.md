# AI Video Studio (kişisel kullanım)

Kişisel, tek kullanıcılı video üretim sistemi. Açık kaynaklı Wan 2.1 modelleriyle
çalışır. Kullanıcı kaydı, üyelik, reklam ve ödeme yoktur.

## Mimari
- `server/`: FastAPI + diffusers (Wan 2.1). Bir GPU sunucusunda çalışır. Web arayüzünü de sunar.
- `android/`: Sunucu arayüzünü açan küçük WebView uygulaması. Video indirmeyi telefonun
  İndirilenler/Filmler klasörüne DownloadManager ile yapar.
- `.github/workflows/build-apk.yml`: APK'yı GitHub'da derler. Bilgisayar gerekmez, telefon
  tarayıcısından GitHub'a girip "Run workflow" deyip artifact'i indirmeniz yeterli.

## Üretim özellikleri
- Metinden video (T2V) ve fotoğraftan video (I2V)
- Süre: 10 sn (iki ~5 sn segment, son kare üzerinden zincirlenir)
- Formatlar: 9:16, 1:1, 16:9
- Çözünürlük: 720p, 1080p (1080p, 720p-sınıfı üretimin ffmpeg Lanczos ile büyütülmesidir)

## Sunucu kurulumu (GPU, 24 GB VRAM önerilir)
```bash
cd server
docker build -t video-studio .
docker run -d --gpus all -p 8000:8000 \
  -e STUDIO_TOKEN="uzun-rastgele-bir-anahtar" \
  -e GEN_CLASS=480 \
  -v $PWD/models:/models -v $PWD/videos:/data/videos \
  --name studio video-studio
```
- `GEN_CLASS=480`: Wan 2.1 1.3B T2V ile hızlı ve ucuz üretim. T2V segmenti için 1.3B yeterlidir.
  I2V segmenti için model yalnızca 14B mevcut, bu yüzden I2V 14B-480P gerekir.
- `GEN_CLASS=720`: T2V için `WAN_T2V_MODEL=Wan-AI/Wan2.1-T2V-14B-Diffusers` ve
  `WAN_I2V_MODEL=Wan-AI/Wan2.1-I2V-14B-720P-Diffusers` kullanın. Kalite daha iyi, ama çok yavaş ve VRAM ihtiyacı büyük.
- Telefondan erişim için HTTPS gerekir (Android düz HTTP'yi varsayılan engeller).
  Cloudflare Tunnel veya Caddy ile reverse proxy kurun.

## Telefon kurulumu
1. GitHub'da bu projeyi açın, Actions > build-apk > Run workflow.
2. Biten çalışmadan `video-studio-apk` artifact'ini indirin.
3. APK'yı kurun (Ayarlar'dan bu kaynağa kuruluma izin verin).
4. Açılışta sunucu adresini girin (ör. https://studio.ornek.com). Değiştirmek için uygulama verisini temizleyin.
5. Erişim anahtarını web arayüzüne girin ve üretin.

## Maliyet (tahmini, ölçülmüş değil)
| Seçenek | Tahmini maliyet | Not |
|---|---|---|
| Kiralık RTX 4090 (saatlik) | ~$0.3–0.6/saat | 1.3B 480 sınıfı, 10 sn video ~3–8 dk. Video başı ~$0.02–0.08 |
| Kiralık A100/L40S 48–80 GB | ~$1–2/saat | 14B 720 sınıfı, 10 sn video ~20–60 dk. Video başı ~$0.3–1.5 |
| Kendi RTX 3090/4090 | 3090 ikinci el ~$700–900, 4090 ~$1800+ | Elektrik ~ $0.05–0.10/saat yük altında. Video başı ~$0.01–0.03 |
| Ücretsiz (Kaggle, Colab, HF ZeroGPU) | $0 | Haftalık/günlük kota ve kesinti var. Sınırsız değil, deneme için uygun |

Gerçek sınırsız üretim = kendi GPU'nuz. Kiralık sunucu her zaman video başına ücret ödersiniz.
Kendi GPU'nuzun yatırımı, aylık yüksek hacimde kiralık maliyetini geçtiğinde anlamlıdır.

## Bilinen sınırlar
- Wan 2.1 yerel olarak ~5 sn üretir. 10 sn zincirleme yaklaşımdır, ikinci segmentte küçük tutarsızlıklar olabilir.
- 16 fps çıkış. Daha akıcı için RIFE gibi ara kare enterpolasyonu eklenebilir.
- Job kayıtları bellekte tutulur. Sunucu yeniden başlarsa liste sıfırlanır, mp4 dosyaları `videos/` klasöründe kalır.
- 1080p çıktı, düşük çözünürlük üretiminin büyütülmesidir. Gerçek 1080p detayı için 720 sınıfı model gerekir.
