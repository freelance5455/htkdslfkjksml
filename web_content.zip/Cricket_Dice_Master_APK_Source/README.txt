Cricket Dice Master - APK source

Main game file: index.html

Upload this ZIP to an HTML-to-APK builder that supports offline HTML/ZIP projects.
App name suggestion: Cricket Dice Master
Package name suggestion: com.cricketdicemaster.game

The game is a self-contained HTML file. Test the generated APK before sharing it.
