(() => {
  'use strict';

  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
  const app = document.getElementById('app');
  const MAX_Z = 190;
  const LANES = [-1, 0, 1];
  const STORAGE = { best: 'tbg-best-score', coins: 'tbg-total-coins', sound: 'tbg-sound', haptic: 'tbg-haptic' };

  const $ = (id) => document.getElementById(id);
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const lerp = (a, b, t) => a + (b - a) * t;
  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = (items) => items[Math.floor(Math.random() * items.length)];
  const fmt = (n) => String(Math.max(0, Math.floor(n))).padStart(6, '0');
  const safeGet = (key, fallback) => { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } };
  const safeSet = (key, value) => { try { localStorage.setItem(key, String(value)); } catch {} };

  let W = 0, H = 0, DPR = 1;
  let last = 0, raf = 0;
  let screenMode = 'menu';
  let toastTimer = 0;

  const audio = {
    context: null,
    master: null,
    enabled: safeGet(STORAGE.sound, '1') !== '0',
    haptic: safeGet(STORAGE.haptic, '1') !== '0',
    unlock() {
      if (!this.context) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        this.context = new AC();
        this.master = this.context.createGain();
        this.master.gain.value = .09;
        this.master.connect(this.context.destination);
      }
      if (this.context.state === 'suspended') this.context.resume();
    },
    tone(frequency, duration, type = 'sine', volume = .5, slide = 0) {
      if (!this.enabled) return;
      this.unlock();
      if (!this.context || !this.master) return;
      const now = this.context.currentTime;
      const osc = this.context.createOscillator();
      const gain = this.context.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(frequency, now);
      if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, frequency + slide), now + duration);
      gain.gain.setValueAtTime(.001, now);
      gain.gain.exponentialRampToValueAtTime(Math.max(.001, volume), now + .012);
      gain.gain.exponentialRampToValueAtTime(.001, now + duration);
      osc.connect(gain).connect(this.master);
      osc.start(now);
      osc.stop(now + duration + .02);
    },
    start() { this.tone(370, .12, 'triangle', .33, 130); setTimeout(() => this.tone(590, .18, 'triangle', .3, 150), 75); },
    coin() { this.tone(720, .09, 'sine', .32, 160); setTimeout(() => this.tone(1040, .11, 'sine', .26, 90), 55); },
    jump() { this.tone(280, .18, 'triangle', .22, 250); },
    slide() { this.tone(160, .12, 'sawtooth', .1, -50); },
    hit() { this.tone(120, .38, 'sawtooth', .42, -80); setTimeout(() => this.tone(76, .3, 'square', .24, -15), 60); }
  };

  const game = {
    state: 'menu',
    lane: 1,
    visualLane: 1,
    jumpY: 0,
    jumpVelocity: 0,
    slideTimer: 0,
    runTime: 0,
    distance: 0,
    score: 0,
    coins: 0,
    speed: 13,
    spawnTimer: .7,
    obstacles: [],
    coinsInWorld: [],
    particles: [],
    scenery: [],
    cityShift: 0,
    shake: 0,
    flash: 0,
    newBest: false,
    best: Number(safeGet(STORAGE.best, 0)) || 0,
    totalCoins: Number(safeGet(STORAGE.coins, 0)) || 0,
    playerSeed: Math.random() * 10,
    reset() {
      this.lane = 1;
      this.visualLane = 1;
      this.jumpY = 0;
      this.jumpVelocity = 0;
      this.slideTimer = 0;
      this.runTime = 0;
      this.distance = 0;
      this.score = 0;
      this.coins = 0;
      this.speed = 13;
      this.spawnTimer = .55;
      this.obstacles = [];
      this.coinsInWorld = [];
      this.particles = [];
      this.shake = 0;
      this.flash = 0;
      this.newBest = false;
      this.playerSeed = Math.random() * 10;
    },
    start() {
      audio.unlock();
      audio.start();
      this.reset();
      this.state = 'playing';
      screenMode = 'playing';
      setScreens('none');
      setGameUI(true);
      showToast('RUN STARTED');
      if (audio.haptic && navigator.vibrate) navigator.vibrate(12);
    },
    pause() {
      if (this.state !== 'playing') return;
      this.state = 'paused';
      screenMode = 'pause';
      setScreens('pause');
      setGameUI(false);
    },
    resume() {
      if (this.state !== 'paused') return;
      audio.unlock();
      this.state = 'playing';
      screenMode = 'playing';
      setScreens('none');
      setGameUI(true);
      last = performance.now();
    },
    restart() { this.start(); },
    toMenu() {
      this.state = 'menu';
      screenMode = 'menu';
      setScreens('title');
      setGameUI(false);
      updateMenuBest();
    },
    gameOver(reason = 'obstacle') {
      if (this.state !== 'playing') return;
      this.state = 'gameover';
      screenMode = 'gameover';
      this.shake = .4;
      this.flash = .45;
      audio.hit();
      if (audio.haptic && navigator.vibrate) navigator.vibrate([35, 40, 80]);
      const previousBest = this.best;
      this.newBest = this.score > previousBest;
      if (this.newBest) {
        this.best = this.score;
        safeSet(STORAGE.best, this.best);
      }
      this.totalCoins += this.coins;
      safeSet(STORAGE.coins, this.totalCoins);
      $('finalScore').textContent = fmt(this.score);
      $('finalCoins').textContent = String(this.coins);
      $('finalBest').textContent = fmt(this.best);
      $('finalDistance').textContent = `${Math.floor(this.distance)} m`;
      $('newBest').style.display = this.newBest ? 'block' : 'none';
      $('gameOverTitle').textContent = reason === 'train' ? 'The express got you.' : reason === 'gate' ? 'Mind the low bridge.' : 'Good run, Bago.';
      setScreens('gameover');
      setGameUI(false);
    },
    move(direction) {
      if (this.state !== 'playing') return;
      audio.unlock();
      const next = clamp(this.lane + direction, 0, 2);
      if (next !== this.lane) {
        this.lane = next;
        if (audio.haptic && navigator.vibrate) navigator.vibrate(8);
      }
    },
    jump() {
      if (this.state !== 'playing' || this.jumpY > .02 || this.slideTimer > 0) return;
      audio.unlock();
      this.jumpVelocity = 7.8;
      this.jumpY = .02;
      audio.jump();
      if (audio.haptic && navigator.vibrate) navigator.vibrate(10);
    },
    slide() {
      if (this.state !== 'playing' || this.jumpY > .22) return;
      audio.unlock();
      this.slideTimer = .72;
      audio.slide();
      if (audio.haptic && navigator.vibrate) navigator.vibrate(8);
    },
    spawn() {
      const lane = Math.floor(Math.random() * 3);
      const difficulty = clamp(this.distance / 900, 0, 1);
      const roll = Math.random();
      const type = roll < .48 ? 'barrier' : roll < .76 ? 'train' : 'gate';
      this.obstacles.push({ lane, type, z: MAX_Z + 8, hit: false, seed: Math.random() * 10 });
      if (Math.random() < (.25 + difficulty * .25)) {
        const second = (lane + (Math.random() < .5 ? 1 : 2)) % 3;
        if (type !== 'train' || Math.random() < .55) this.obstacles.push({ lane: second, type: 'barrier', z: MAX_Z + 8, hit: false, seed: Math.random() * 10 });
      }
      const safeLane = [0, 1, 2].find((n) => n !== lane && !this.obstacles.some((o) => o.lane === n && o.z > MAX_Z - 1));
      const coinLane = Math.random() < .7 ? (safeLane ?? ((lane + 1) % 3)) : Math.floor(Math.random() * 3);
      const high = Math.random() < .28;
      const count = 4 + Math.floor(Math.random() * 3);
      for (let i = 0; i < count; i++) {
        this.coinsInWorld.push({ lane: coinLane, z: MAX_Z + 8 + i * 11, y: high ? .85 + Math.sin(i / (count - 1) * Math.PI) * .8 : .62, spin: Math.random() * Math.PI * 2, collected: false });
      }
      this.spawnTimer = Math.max(.5, 1.08 - this.distance / 2200) + Math.random() * .28;
    },
    update(dt) {
      if (this.state !== 'playing') return;
      this.runTime += dt;
      this.distance += this.speed * dt;
      this.speed = 13 + Math.min(13, this.distance * .024);
      this.score = Math.floor(this.distance * 9 + this.coins * 55);
      this.cityShift = (this.cityShift + this.speed * dt * .009) % 1;
      this.visualLane += (this.lane - this.visualLane) * Math.min(1, dt * 15);
      if (this.jumpY > 0 || this.jumpVelocity > 0) {
        this.jumpVelocity -= 19.5 * dt;
        this.jumpY += this.jumpVelocity * dt;
        if (this.jumpY <= 0) { this.jumpY = 0; this.jumpVelocity = 0; }
      }
      if (this.slideTimer > 0) this.slideTimer = Math.max(0, this.slideTimer - dt);
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) this.spawn();
      for (const item of this.obstacles) item.z -= this.speed * dt;
      for (const item of this.coinsInWorld) { item.z -= this.speed * dt; item.spin += dt * 8; }
      this.checkCollisions();
      this.obstacles = this.obstacles.filter((o) => o.z > -14);
      this.coinsInWorld = this.coinsInWorld.filter((c) => c.z > -12 && !c.collected);
      this.updateParticles(dt);
      this.shake = Math.max(0, this.shake - dt);
      this.flash = Math.max(0, this.flash - dt);
      updateHud(this);
    },
    checkCollisions() {
      for (const o of this.obstacles) {
        if (o.hit || o.z > 12 || o.z < -2 || Math.abs(o.lane - this.visualLane) > .38) continue;
        o.hit = true;
        if (o.type === 'gate') {
          if (this.slideTimer <= 0) { this.gameOver('gate'); return; }
        } else {
          const requiredJump = o.type === 'train' ? 1.45 : .42;
          if (this.jumpY < requiredJump) { this.gameOver(o.type === 'train' ? 'train' : 'obstacle'); return; }
        }
      }
      for (const c of this.coinsInWorld) {
        if (c.collected || c.z > 12 || c.z < -1 || Math.abs(c.lane - this.visualLane) > .43) continue;
        if (Math.abs(this.jumpY + .15 - c.y) < .96) {
          c.collected = true;
          this.coins += 1;
          this.score += 55;
          this.emitCoin(c);
          audio.coin();
          if (audio.haptic && navigator.vibrate) navigator.vibrate(6);
        }
      }
    },
    emitCoin(c) {
      const point = project(c.z);
      const x = laneX(c.lane, point.p);
      for (let i = 0; i < 10; i++) this.particles.push({ x, y: point.y - c.y * point.scale * 22, vx: rand(-42, 42), vy: rand(-95, -25), life: .45 + Math.random() * .25, max: .7, color: i % 2 ? '#ffd878' : '#fff2a8', size: rand(2, 5) });
    },
    updateParticles(dt) {
      for (const p of this.particles) { p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 180 * dt; }
      this.particles = this.particles.filter((p) => p.life > 0);
    }
  };

  function setScreens(active) {
    const screens = { title: $('titleScreen'), pause: $('pauseScreen'), settings: $('settingsScreen'), gameover: $('gameOverScreen') };
    Object.entries(screens).forEach(([name, node]) => node.classList.toggle('active', name === active));
    $('hud').classList.toggle('active', active === 'none');
  }
  function setGameUI(active) { $('mobileControls').classList.toggle('active', active); $('hud').classList.toggle('active', active); }
  function updateMenuBest() { $('menuHighScore').textContent = fmt(game.best); }
  function updateHud(g) {
    $('scoreValue').textContent = fmt(g.score);
    $('coinValue').textContent = String(g.coins);
    $('distanceValue').textContent = `${Math.floor(g.distance)} m`;
    $('speedValue').textContent = `${(g.speed / 13).toFixed(1)}x`;
    $('speedFill').style.width = `${clamp((g.speed - 13) / 13 * 84 + 10, 10, 94)}px`;
  }
  function showToast(text) {
    const node = $('toast'); node.textContent = text; node.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => node.classList.remove('show'), 1000);
  }

  function metrics() {
    const horizon = H * (W > H * 1.1 ? .43 : .39);
    const ground = H * (W > H * 1.1 ? .82 : .84);
    return { horizon, ground, center: W / 2 };
  }
  function project(z) {
    const { horizon, ground } = metrics();
    const p = clamp(1 - z / MAX_Z, 0, 1.05);
    return { p, y: horizon + (ground - horizon) * p, scale: .18 + 1.02 * p };
  }
  function laneX(lane, p) {
    const roadHalf = lerp(Math.max(18, W * .055), W * .58, clamp(p, 0, 1));
    return W / 2 + (lane - 1) * roadHalf * .56;
  }
  function roundRect(c, x, y, w, h, r) {
    const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
    c.beginPath(); c.moveTo(x + rr, y); c.arcTo(x + w, y, x + w, y + h, rr); c.arcTo(x + w, y + h, x, y + h, rr); c.arcTo(x, y + h, x, y, rr); c.arcTo(x, y, x + w, y, rr); c.closePath();
  }
  function poly(points, fill, stroke, width = 1) {
    ctx.beginPath(); ctx.moveTo(points[0][0], points[0][1]); points.slice(1).forEach((p) => ctx.lineTo(p[0], p[1])); ctx.closePath(); if (fill) { ctx.fillStyle = fill; ctx.fill(); } if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = width; ctx.stroke(); }
  }
  function drawBackground(t) {
    const m = metrics();
    const sky = ctx.createLinearGradient(0, 0, 0, m.horizon + 50); sky.addColorStop(0, '#0a2741'); sky.addColorStop(.58, '#196078'); sky.addColorStop(1, '#f4a35c'); ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
    ctx.save();
    ctx.globalAlpha = .8;
    const sunX = W * .78, sunY = m.horizon * .46, sunR = Math.min(W, H) * .11;
    const glow = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, sunR * 2.2); glow.addColorStop(0, 'rgba(255,219,140,.7)'); glow.addColorStop(1, 'rgba(255,196,111,0)'); ctx.fillStyle = glow; ctx.fillRect(sunX - sunR * 2, sunY - sunR * 2, sunR * 4, sunR * 4); ctx.fillStyle = '#ffe2a1'; ctx.beginPath(); ctx.arc(sunX, sunY, sunR, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.globalAlpha = .18;
    poly([[0, m.horizon + 30], [W * .15, m.horizon - 35], [W * .26, m.horizon + 18], [W * .42, m.horizon - 65], [W * .58, m.horizon + 10], [W * .76, m.horizon - 47], [W, m.horizon + 20], [W, m.horizon + 70], [0, m.horizon + 70]], '#0b3a52');
    ctx.restore();
    drawBuildings(t, m);
  }
  function drawBuildings(t, m) {
    const shift = (game.cityShift * 70) % 70;
    for (const b of game.scenery) {
      const x = b.x - shift * b.depth; const y = m.horizon + b.offset;
      const w = b.w; const h = b.h;
      ctx.globalAlpha = b.depth > .7 ? .75 : .42;
      ctx.fillStyle = b.color; ctx.fillRect(x, y - h, w, h);
      ctx.fillStyle = b.roof; poly([[x - 4, y - h], [x + w * .5, y - h - b.roofH], [x + w + 4, y - h]], b.roof);
      ctx.globalAlpha = .45;
      for (let wy = y - h + 12; wy < y - 8; wy += 15) for (let wx = x + 8; wx < x + w - 5; wx += 15) { ctx.fillStyle = b.lit && ((wx + wy) % 3 < 1.6) ? '#ffd77f' : '#8ab7af'; ctx.fillRect(wx, wy, 5, 6); }
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(4,19,28,.52)'; ctx.fillRect(0, m.horizon + 3, W, H - m.horizon);
  }
  function drawRailway(t) {
    const m = metrics();
    const roadTop = Math.max(9, W * .035), roadBottom = W * .68;
    poly([[W / 2 - roadTop, m.horizon], [W / 2 + roadTop, m.horizon], [W / 2 + roadBottom, H + 30], [W / 2 - roadBottom, H + 30]], '#283a3c');
    poly([[W / 2 - roadTop * .72, m.horizon], [W / 2 + roadTop * .72, m.horizon], [W / 2 + roadBottom * .75, H + 30], [W / 2 - roadBottom * .75, H + 30]], '#172b31');
    for (let z = MAX_Z; z > 1; z -= 10) {
      const p = project(z); const y = p.y; const half = lerp(roadTop, roadBottom, p.p);
      ctx.globalAlpha = .1 + p.p * .22; ctx.strokeStyle = '#d5ba8a'; ctx.lineWidth = Math.max(1, p.scale * 2.4);
      ctx.beginPath(); ctx.moveTo(W / 2 - half * .84, y); ctx.lineTo(W / 2 + half * .84, y); ctx.stroke();
    }
    for (const offset of [-.84, .84]) {
      ctx.strokeStyle = '#b7b09a'; ctx.lineWidth = 2; ctx.globalAlpha = .55;
      ctx.beginPath(); ctx.moveTo(W / 2 + offset * roadTop, m.horizon); ctx.lineTo(W / 2 + offset * roadBottom, H + 15); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,230,170,.42)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(W / 2 + offset * roadTop + 3, m.horizon); ctx.lineTo(W / 2 + offset * roadBottom + 5, H + 15); ctx.stroke();
    }
    for (const offset of [-.28, .28]) {
      ctx.strokeStyle = 'rgba(236,183,107,.34)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(W / 2 + offset * roadTop, m.horizon); ctx.lineTo(W / 2 + offset * roadBottom, H + 15); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#273f42';
    ctx.fillRect(0, H * .84, W, H * .16);
  }
  function drawSignals(t) {
    const m = metrics();
    const x = W * .12, base = m.horizon + (m.ground - m.horizon) * .56;
    ctx.strokeStyle = '#183d4b'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x, base); ctx.lineTo(x, base - 100); ctx.stroke();
    ctx.fillStyle = '#0a2435'; roundRect(ctx, x - 13, base - 124, 26, 37, 5); ctx.fill();
    ctx.fillStyle = game.runTime % 1.2 < .6 ? '#ff9d45' : '#39d4c6'; ctx.beginPath(); ctx.arc(x, base - 112, 5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#d3a85e'; ctx.beginPath(); ctx.arc(x + 40, base - 12, 4, 0, Math.PI * 2); ctx.fill();
  }
  function drawObstacle(o) {
    const p = project(o.z), x = laneX(o.lane, p.p), y = p.y, s = p.scale;
    if (o.type === 'barrier') {
      const w = 37 * s, h = 25 * s;
      ctx.save(); ctx.translate(x, y - h * .04); ctx.globalAlpha = .28; ctx.fillStyle = '#030b10'; ctx.beginPath(); ctx.ellipse(0, 6 * s, w * .75, 6 * s, 0, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
      ctx.fillStyle = '#e76e4f'; roundRect(ctx, x - w / 2, y - h, w, h, 4 * s); ctx.fill();
      ctx.fillStyle = '#f9d27c'; for (let i = -1; i <= 1; i++) { ctx.save(); ctx.translate(x + i * 13 * s, y - h / 2); ctx.rotate(-.5); ctx.fillRect(-3 * s, -h * .7, 6 * s, h * 1.4); ctx.restore(); }
      ctx.fillStyle = '#27383b'; ctx.fillRect(x - w * .38, y, 5 * s, 10 * s); ctx.fillRect(x + w * .23, y, 5 * s, 10 * s); ctx.restore();
    } else if (o.type === 'train') {
      const w = 53 * s, h = 106 * s;
      ctx.save(); ctx.globalAlpha = .25; ctx.fillStyle = '#02080c'; ctx.beginPath(); ctx.ellipse(x, y + 7 * s, w * .76, 9 * s, 0, 0, Math.PI * 2); ctx.fill();
      const grad = ctx.createLinearGradient(x - w / 2, 0, x + w / 2, 0); grad.addColorStop(0, '#d24c50'); grad.addColorStop(.5, '#f37a55'); grad.addColorStop(1, '#a63b4b'); ctx.fillStyle = grad; roundRect(ctx, x - w / 2, y - h, w, h, 7 * s); ctx.fill();
      ctx.fillStyle = '#f4ca7b'; ctx.fillRect(x - w / 2, y - h * .34, w, 4 * s); ctx.fillStyle = '#163247'; roundRect(ctx, x - w * .33, y - h * .76, w * .66, h * .22, 3 * s); ctx.fill();
      ctx.fillStyle = '#9ce3d2'; for (let i = -1; i <= 1; i++) { ctx.fillRect(x + i * w * .22 - 2 * s, y - h * .7, 4 * s, 9 * s); }
      ctx.fillStyle = '#ffd98a'; ctx.beginPath(); ctx.arc(x - w * .27, y - h * .18, 4 * s, 0, Math.PI * 2); ctx.arc(x + w * .27, y - h * .18, 4 * s, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#2b3135'; ctx.fillRect(x - w * .32, y - 4 * s, 8 * s, 9 * s); ctx.fillRect(x + w * .17, y - 4 * s, 8 * s, 9 * s); ctx.restore();
    } else {
      const w = 65 * s, h = 85 * s;
      ctx.save(); ctx.globalAlpha = .23; ctx.fillStyle = '#030b10'; ctx.beginPath(); ctx.ellipse(x, y + 5 * s, w * .75, 8 * s, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#d3a55d'; ctx.lineWidth = 5 * s; ctx.beginPath(); ctx.moveTo(x - w / 2, y); ctx.lineTo(x - w / 2, y - h); ctx.lineTo(x + w / 2, y - h); ctx.lineTo(x + w / 2, y); ctx.stroke();
      ctx.strokeStyle = '#ef7356'; ctx.lineWidth = 4 * s; ctx.beginPath(); ctx.moveTo(x - w / 2 + 5 * s, y - h + 7 * s); ctx.lineTo(x + w / 2 - 5 * s, y - h + 7 * s); ctx.stroke();
      ctx.fillStyle = '#ffc967'; ctx.beginPath(); ctx.arc(x - w / 2 - 1 * s, y - h - 2 * s, 4 * s, 0, Math.PI * 2); ctx.arc(x + w / 2 + 1 * s, y - h - 2 * s, 4 * s, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    }
  }
  function drawCoin(c) {
    const p = project(c.z), x = laneX(c.lane, p.p), y = p.y - c.y * p.scale * 24, r = Math.max(2.5, 9 * p.scale);
    ctx.save(); ctx.translate(x, y); ctx.scale(Math.max(.2, Math.abs(Math.cos(c.spin))), 1); ctx.shadowColor = '#ffd45d'; ctx.shadowBlur = 12 * p.scale; ctx.fillStyle = '#ffc34f'; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0; ctx.strokeStyle = '#fff0a1'; ctx.lineWidth = Math.max(1, p.scale * 1.4); ctx.stroke(); ctx.fillStyle = '#ffefad'; ctx.font = `${Math.max(5, r * 1.25)}px Arial`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('✦', 0, 1); ctx.restore();
  }
  function drawPlayer(t) {
    const m = metrics(), x = laneX(game.visualLane, .98), ground = m.ground, jump = game.jumpY;
    const slide = game.slideTimer > 0, bob = slide ? 0 : Math.sin(t * 12 + game.playerSeed) * 2.5, scale = clamp(Math.min(W, H) / 470, .72, 1.35), y = ground - jump * 43 * scale + bob;
    ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale);
    ctx.globalAlpha = .3; ctx.fillStyle = '#020a10'; ctx.beginPath(); ctx.ellipse(0, 9 + jump * 35, slide ? 29 : 19 + jump * 9, slide ? 7 : 7, 0, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
    if (slide) {
      ctx.rotate(-.07); drawRunnerBody(ctx, 0, -27, true); drawRunnerHead(ctx, 13, -52);
    } else {
      const stride = Math.sin(t * 13 + game.playerSeed) * 8;
      drawRunnerLeg(ctx, -7, -4, stride); drawRunnerLeg(ctx, 7, -4, -stride);
      drawRunnerBody(ctx, 0, -28, false); drawRunnerHead(ctx, 0, -61);
      ctx.strokeStyle = '#33d0c4'; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(-13, -36); ctx.lineTo(-23 - stride * .35, -20); ctx.moveTo(13, -36); ctx.lineTo(23 + stride * .35, -20); ctx.stroke();
    }
    ctx.restore();
  }
  function drawRunnerLeg(c, x, y, stride) { c.save(); c.translate(x, y); c.rotate(stride * .025); c.strokeStyle = '#2c4051'; c.lineWidth = 7; c.lineCap = 'round'; c.beginPath(); c.moveTo(0, 0); c.lineTo(stride * .55, 19); c.lineTo(stride + (x > 0 ? 10 : -10), 27); c.stroke(); c.strokeStyle = '#f8c46d'; c.lineWidth = 5; c.beginPath(); c.moveTo(stride + (x > 0 ? 7 : -7), 27); c.lineTo(stride + (x > 0 ? 17 : -17), 27); c.stroke(); c.restore(); }
  function drawRunnerBody(c, x, y, slide) { c.save(); c.translate(x, y); c.fillStyle = '#e67b4f'; c.beginPath(); c.moveTo(-15, 5); c.quadraticCurveTo(-13, -18, 0, -24); c.quadraticCurveTo(15, -18, 16, 5); c.closePath(); c.fill(); c.fillStyle = '#ffc15e'; c.fillRect(-14, -4, 28, 6); c.fillStyle = '#203b4b'; c.beginPath(); c.arc(0, -19, 4, 0, Math.PI * 2); c.fill(); c.restore(); }
  function drawRunnerHead(c, x, y) { c.save(); c.translate(x, y); c.fillStyle = '#a84f3f'; c.beginPath(); c.arc(0, 0, 13, 0, Math.PI * 2); c.fill(); c.fillStyle = '#ffce77'; c.beginPath(); c.arc(0, 3, 9.5, 0, Math.PI * 2); c.fill(); c.fillStyle = '#173449'; c.beginPath(); c.arc(0, -4, 12, Math.PI, Math.PI * 2); c.fill(); c.fillStyle = '#ffb44a'; c.fillRect(-13, -6, 26, 4); c.fillStyle = '#263f4b'; c.beginPath(); c.arc(-3.5, 3, 1.4, 0, Math.PI * 2); c.arc(4, 3, 1.4, 0, Math.PI * 2); c.fill(); c.restore(); }
  function drawParticles() { for (const p of game.particles) { ctx.globalAlpha = clamp(p.life / p.max, 0, 1); ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill(); } ctx.globalAlpha = 1; }
  function render(now) {
    const t = now / 1000;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.save();
    if (game.shake > 0) ctx.translate(rand(-3, 3) * game.shake / .4, rand(-2, 2) * game.shake / .4);
    drawBackground(t); drawRailway(t); drawSignals(t);
    const things = [...game.obstacles.map((o) => ({ z: o.z, kind: 'obstacle', item: o })), ...game.coinsInWorld.map((c) => ({ z: c.z, kind: 'coin', item: c }))].sort((a, b) => b.z - a.z);
    for (const thing of things) thing.kind === 'obstacle' ? drawObstacle(thing.item) : drawCoin(thing.item);
    drawPlayer(t); drawParticles();
    ctx.restore();
    if (game.flash > 0) { ctx.fillStyle = `rgba(255, 120, 91, ${game.flash * .3})`; ctx.fillRect(0, 0, W, H); }
    raf = requestAnimationFrame(render);
  }

  function resize() { DPR = Math.min(2, window.devicePixelRatio || 1); W = window.innerWidth; H = window.innerHeight; canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR); canvas.style.width = `${W}px`; canvas.style.height = `${H}px`; buildScenery(); }
  function buildScenery() {
    const palette = [{ color: '#1c4a5a', roof: '#d07458' }, { color: '#25475a', roof: '#e7a05f' }, { color: '#174052', roof: '#63b8a9' }, { color: '#315065', roof: '#ce6a5e' }];
    game.scenery = [];
    for (let side = 0; side < 2; side++) for (let i = 0; i < 11; i++) { const p = pick(palette); game.scenery.push({ x: side ? W * .55 + i * W * .08 : W * .05 - i * W * .08, w: rand(30, 72), h: rand(32, 118) * (W > H ? .8 : 1), roofH: rand(4, 13), offset: rand(-10, 28), depth: rand(.45, 1), color: p.color, roof: p.roof, lit: Math.random() > .35 }); }
  }

  function setSound(value) { audio.enabled = value; safeSet(STORAGE.sound, value ? '1' : '0'); const b = $('soundToggle'); b.classList.toggle('on', value); b.setAttribute('aria-pressed', String(value)); b.querySelector('b').textContent = value ? 'ON' : 'OFF'; if (value) { audio.unlock(); audio.tone(560, .1, 'sine', .25, 80); } }
  function setHaptic(value) { audio.haptic = value; safeSet(STORAGE.haptic, value ? '1' : '0'); const b = $('hapticToggle'); b.classList.toggle('on', value); b.setAttribute('aria-pressed', String(value)); b.querySelector('b').textContent = value ? 'ON' : 'OFF'; }
  function openSettings() { const fromPause = game.state === 'paused'; $('settingsScreen').dataset.from = fromPause ? 'pause' : 'menu'; setScreens('settings'); setGameUI(false); }
  function closeSettings() { const from = $('settingsScreen').dataset.from; if (from === 'pause' && game.state === 'paused') { setScreens('pause'); } else if (game.state === 'menu') { setScreens('title'); } else if (game.state === 'playing') { setScreens('none'); setGameUI(true); } }
  function action(name) {
    if (name === 'play') game.start();
    else if (name === 'pause') game.pause();
    else if (name === 'resume') game.resume();
    else if (name === 'restart') game.restart();
    else if (name === 'menu') game.toMenu();
    else if (name === 'settings') openSettings();
    else if (name === 'close-settings') closeSettings();
    else if (name === 'toggle-sound') setSound(!audio.enabled);
    else if (name === 'toggle-haptic') setHaptic(!audio.haptic);
  }
  app.addEventListener('click', (e) => { const target = e.target.closest('[data-action]'); if (target) action(target.dataset.action); const control = e.target.closest('[data-control]'); if (control) handleControl(control.dataset.control); });
  document.querySelectorAll('[data-control]').forEach((button) => { button.addEventListener('pointerdown', (e) => { e.preventDefault(); handleControl(button.dataset.control); }); });
  function handleControl(control) { audio.unlock(); if (control === 'left') game.move(-1); else if (control === 'right') game.move(1); else if (control === 'jump') game.jump(); else if (control === 'slide') game.slide(); }
  let gesture = null;
  canvas.addEventListener('pointerdown', (e) => { if (game.state !== 'playing') return; gesture = { x: e.clientX, y: e.clientY, time: performance.now() }; canvas.setPointerCapture?.(e.pointerId); audio.unlock(); });
  canvas.addEventListener('pointerup', (e) => { if (!gesture) return; const dx = e.clientX - gesture.x, dy = e.clientY - gesture.y, distance = Math.hypot(dx, dy); gesture = null; if (distance < 20) return; if (Math.abs(dx) > Math.abs(dy)) game.move(dx > 0 ? 1 : -1); else if (dy < 0) game.jump(); else game.slide(); });
  window.addEventListener('keydown', (e) => { if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' ', 'Escape'].includes(e.key)) e.preventDefault(); if (e.key === 'ArrowLeft' || e.key.toLowerCase() === 'a') game.move(-1); else if (e.key === 'ArrowRight' || e.key.toLowerCase() === 'd') game.move(1); else if (e.key === 'ArrowUp' || e.key.toLowerCase() === 'w' || e.key === ' ') game.jump(); else if (e.key === 'ArrowDown' || e.key.toLowerCase() === 's') game.slide(); else if (e.key === 'Escape') { if (game.state === 'playing') game.pause(); else if (game.state === 'paused') game.resume(); else if (screenMode === 'settings') closeSettings(); } });
  window.addEventListener('resize', resize);
  document.addEventListener('visibilitychange', () => { if (document.hidden && game.state === 'playing') game.pause(); });

  updateMenuBest(); setSound(audio.enabled); setHaptic(audio.haptic); resize(); game.reset();
  window.__game = { game, audio, version: '1.0.0' };
  last = performance.now();
  function loop(now) { const dt = Math.min(.035, Math.max(0, (now - last) / 1000)); last = now; game.update(dt); requestAnimationFrame(loop); }
  requestAnimationFrame(loop); requestAnimationFrame(render);
})();
