# Tando Bago's Game

A complete, lightweight, offline railway endless runner for mobile browsers. The game is inspired by the lane-switching rhythm of endless runners, but all gameplay, characters, railway-city art, effects and audio are original and generated locally in the browser.

## Run it

1. Unzip `TandoBagosGame.zip`.
2. Open `index.html` in Chrome, Edge, Firefox or a modern Android browser.
3. Tap **PLAY RUN**.

No server, account, CDN, external font, external image, or internet connection is required. For the smoothest Android experience, use Chrome and add the page to the home screen after opening it from a local web host or file manager.

## Controls

- Swipe left / right: change railway lane.
- Swipe up: jump over barriers and trains.
- Swipe down: slide under low gates.
- The large bottom buttons provide the same actions.
- Desktop: Arrow keys or A/D to change lanes, W/Space/Arrow Up to jump, S/Arrow Down to slide, Escape to pause.

## Features

- Three running lanes with responsive, low-lag input.
- Progressive speed increase and obstacle difficulty ramp.
- Original procedural railway tracks, colorful trains, city buildings, signals, shadows and lighting.
- Collectible gold coins with sparkle bursts and Web Audio coin chimes.
- Barriers, express trains and low overhead gates with distinct jump/slide rules.
- Collision detection, game-over flow, restart, pause/resume and menu navigation.
- Live score, distance, pace and coin counters.
- High score and lifetime coin total saved with `localStorage`.
- Sound effects and haptic feedback toggles.
- Responsive portrait and landscape layouts with safe-area support.
- No external runtime assets; tiny SVG mark plus procedural canvas visuals.

## Project files

- `index.html` — game shell, menus, HUD and controls.
- `style.css` — responsive visual system and mobile UI.
- `game.js` — canvas renderer, runner physics, spawner, collision logic, scoring, input, audio and save data.
- `assets/tando-mark.svg` — original local brand mark and favicon.

## Resetting saved progress

Open the browser developer console and run:

```js
localStorage.removeItem('tbg-best-score');
localStorage.removeItem('tbg-total-coins');
```

## Development build

The source is also compatible with the included Vite project:

```bash
pnpm install
pnpm build
```

The production output is written to `dist/`. The standalone ZIP is intentionally kept dependency-free so it can be copied to an Android phone and opened offline.

## Credits and license

Created as an original game concept for the Tando Bago's Game brief. No third-party runtime art or audio is required. The code is intended for personal and commercial use in this project.
