# Sen Poulailler EVA PRO — prototype fonctionnel 0.1.0

## Ce que contient cette première version
- Tableau de bord calculé à partir des lots enregistrés.
- Création, consultation, modification et suppression de lots.
- Calcul automatique de l'effectif restant : initial − morts − vendus.
- Recherche par nom, race ou fournisseur.
- Export et restauration d'une sauvegarde JSON.
- Stockage local via IndexedDB et cache PWA pour démarrer hors ligne après la première ouverture.
- Interface adaptée aux téléphones, tablettes et ordinateurs.
- Sélecteur de profils de démonstration pour illustrer les permissions.

## Important : limites de sécurité et synchronisation
Ce prototype n'est pas encore un système multi-utilisateurs sécurisé. Le sélecteur de profil sert uniquement à la démonstration : il ne remplace pas une connexion. Les données restent dans le navigateur/appareil utilisé et ne se synchronisent pas entre appareils. Ne stockez pas de données confidentielles dans cette version. Pour la version de production, il faudra ajouter un serveur/API, une base distante, une authentification, des permissions contrôlées côté serveur, des sauvegardes distantes et une stratégie de synchronisation des changements hors ligne.

## Lancer sur ordinateur
1. Installer Python 3 si nécessaire.
2. Ouvrir un terminal dans ce dossier.
3. Lancer : `python -m http.server 8000`
4. Ouvrir `http://localhost:8000` dans Chrome, Edge ou Firefox.

Le serveur local est conseillé pour que le service worker/PWA fonctionne correctement. Après le premier chargement, l'interface peut être mise en cache et utilisée hors ligne sur le même navigateur.

## Installer sur Android
1. Héberger le dossier sur un site HTTPS ou le servir depuis un ordinateur sur le même réseau local.
2. Ouvrir l'adresse dans Chrome sur Android.
3. Menu ⋮ → « Installer l'application » ou « Ajouter à l'écran d'accueil ».

Un APK Android dédié pourra être préparé plus tard avec une enveloppe Capacitor/TWA. Cette archive n'est pas encore un APK.

## Architecture cible de la version complète
- Client : PWA responsive (éventuellement empaquetée Android).
- API : serveur HTTPS REST.
- Base distante : PostgreSQL.
- Authentification : comptes individuels et rôles RBAC.
- Mode hors ligne : IndexedDB + file de synchronisation et résolution des conflits.
- Modules planifiés : lots, santé/vaccins, alimentation, inventaire, fournisseurs, clients, ventes, dépenses, trésorerie, rapports PDF/CSV, journal d'audit.
- Paiements Wave : non inclus selon le périmètre choisi.

## Données d'un lot
`id`, `name`, `breed`, `date`, `initial`, `cost`, `supplier`, `deaths`, `sold`, `notes`, `createdAt`, `updatedAt`, `updatedBy`.
