(() => {
  'use strict';
  const DB_NAME = 'sen-poulailler-eva-pro';
  const DB_VERSION = 1;
  const STORE = 'lots';
  const $ = (id) => document.getElementById(id);
  let db;
  let lots = [];
  let toastTimer;
  let activeRole = 'admin';
  const roleNames = {admin:'Administrateur', manager:'Gestionnaire', seller:'Vendeur', worker:'Employé'};
  const permissions = {
    admin: ['dashboard','lots','stock','health','sales','finance','reports'],
    manager: ['dashboard','lots','stock','health','sales','finance','reports'],
    seller: ['dashboard','sales'],
    worker: ['dashboard','lots','stock','health']
  };
  const money = (value) => new Intl.NumberFormat('fr-FR').format(Number(value) || 0) + ' FCFA';
  const number = (value) => new Intl.NumberFormat('fr-FR').format(Number(value) || 0);
  const dateLabel = (value) => { if (!value) return '—'; const d = new Date(value + 'T12:00:00'); return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString('fr-FR'); };
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  function openDb() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) { reject(new Error('Ce navigateur ne prend pas en charge IndexedDB.')); return; }
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE)) database.createObjectStore(STORE, {keyPath:'id'});
      };
      request.onsuccess = () => { db = request.result; resolve(db); };
      request.onerror = () => reject(request.error || new Error('Impossible d’ouvrir la base de données locale.'));
    });
  }
  function transact(mode, action) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      const store = tx.objectStore(STORE);
      let request;
      try { request = action(store); } catch (e) { reject(e); return; }
      tx.oncomplete = () => resolve(request ? request.result : undefined);
      tx.onerror = () => reject(tx.error || new Error('Échec de l’enregistrement.'));
      tx.onabort = () => reject(tx.error || new Error('Opération annulée.'));
    });
  }
  const getAll = () => new Promise((resolve, reject) => {
    const req = db.transaction(STORE, 'readonly').objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
  async function refresh() { lots = await getAll(); lots.sort((a,b) => (b.createdAt || '').localeCompare(a.createdAt || '')); renderAll(); }
  function currentCount(lot) { return Math.max(0, Number(lot.initial||0) - Number(lot.deaths||0) - Number(lot.sold||0)); }
  function totals() { return lots.reduce((acc,l) => { acc.initial += Number(l.initial)||0; acc.deaths += Number(l.deaths)||0; acc.sold += Number(l.sold)||0; acc.current += currentCount(l); return acc; }, {initial:0,deaths:0,sold:0,current:0}); }
  function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function empty(message='Aucun lot enregistré pour le moment.') { return `<div class="empty-state"><strong>Votre élevage commence ici</strong>${esc(message)}</div>`; }
  function row(lot, withActions=false) {
    return `<tr><td><div class="lot-name">${esc(lot.name)}</div><div class="subcell">${esc(lot.breed || 'Race non précisée')}</div></td><td>${dateLabel(lot.date)}</td><td>${number(lot.initial)}</td><td>${number(lot.deaths)}</td><td>${number(lot.sold)}</td><td><strong>${number(currentCount(lot))}</strong></td>${withActions ? `<td><div class="row-actions"><button class="mini-btn" data-detail="${esc(lot.id)}">Détails</button><button class="mini-btn" data-edit="${esc(lot.id)}">Modifier</button><button class="mini-btn danger" data-delete="${esc(lot.id)}">Supprimer</button></div></td>` : ''}</tr>`;
  }
  function table(items, withActions=false) {
    if (!items.length) return empty();
    return `<table class="data-table"><thead><tr><th>Lot / race</th><th>Arrivée</th><th>Initial</th><th>Morts</th><th>Vendus</th><th>Restants</th>${withActions ? '<th>Actions</th>' : ''}</tr></thead><tbody>${items.map(l => row(l,withActions)).join('')}</tbody></table>`;
  }
  function renderAll() {
    const t = totals();
    $('statCurrent').textContent = number(t.current); $('statInitial').textContent = number(t.initial); $('statDeaths').textContent = number(t.deaths); $('statSold').textContent = number(t.sold);
    $('mortalityRate').textContent = `${t.initial ? (t.deaths/t.initial*100).toLocaleString('fr-FR',{maximumFractionDigits:1}) : '0'} % de l'effectif initial`;
    $('recentLots').innerHTML = table(lots.slice(0,5));
    renderLotList();
    applyRole();
  }
  function renderLotList() {
    const q = ($('lotSearch').value || '').trim().toLocaleLowerCase('fr');
    const filtered = lots.filter(l => [l.name,l.breed,l.supplier].some(v => String(v||'').toLocaleLowerCase('fr').includes(q)));
    $('allLots').innerHTML = table(filtered,true);
    $('lotCount').textContent = `${filtered.length} lot${filtered.length > 1 ? 's' : ''}`;
  }
  function toast(message) { const el=$('toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),2800); }
  function showView(view) {
    if (view !== 'dashboard' && view !== 'lots' && !(permissions[activeRole]||[]).includes(view)) { toast('Ce profil n’a pas accès à ce module.'); return; }
    document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
    const known = ['dashboard','lots'].includes(view);
    $(known ? `view-${view}` : 'view-placeholder').classList.add('active');
    $('pageTitle').textContent = view === 'dashboard' ? 'Tableau de bord' : view === 'lots' ? 'Lots & effectifs' : (document.querySelector(`[data-view="${view}"]`)?.textContent || 'Module en préparation').replace('À venir','').trim();
    if (!known) $('placeholderTitle').textContent = `${$('pageTitle').textContent} — en préparation`;
    document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
    $('sidebar').classList.remove('open');
  }
  function applyRole() {
    document.querySelectorAll('.nav-item').forEach(b => {
      const view = b.dataset.view;
      const allowed = (permissions[activeRole]||[]).includes(view);
      b.style.display = allowed ? 'flex' : 'none';
      b.classList.toggle('locked', !['dashboard','lots'].includes(view));
    });
    document.querySelectorAll('[data-edit],[data-delete]').forEach(b => b.style.display = ['admin','manager'].includes(activeRole) ? '' : 'none');
    $('addLot').style.display = ['admin','manager','worker'].includes(activeRole) ? '' : 'none';
    $('addLotTop').style.display = ['admin','manager','worker'].includes(activeRole) ? '' : 'none';
  }
  function openNewLot() {
    if (!['admin','manager','worker'].includes(activeRole)) { toast('Votre profil ne peut pas créer de lot.'); return; }
    $('lotForm').reset(); $('lotId').value=''; $('lotDeaths').value='0'; $('lotSold').value='0'; $('lotDate').value=today(); $('dialogTitle').textContent='Nouveau lot'; $('formError').textContent=''; $('lotDialog').showModal();
  }
  function openEditLot(id) {
    if (!['admin','manager'].includes(activeRole)) { toast('Seuls l’administrateur et le gestionnaire peuvent modifier un lot.'); return; }
    const l=lots.find(x=>x.id===id); if(!l)return;
    $('lotId').value=l.id; $('lotName').value=l.name; $('lotBreed').value=l.breed||''; $('lotDate').value=l.date; $('lotInitial').value=l.initial; $('lotCost').value=l.cost||0; $('lotSupplier').value=l.supplier||''; $('lotDeaths').value=l.deaths||0; $('lotSold').value=l.sold||0; $('lotNotes').value=l.notes||''; $('dialogTitle').textContent='Modifier le lot'; $('formError').textContent=''; $('lotDialog').showModal();
  }
  async function saveLot(event) {
    event.preventDefault();
    const initial=Number($('lotInitial').value), deaths=Number($('lotDeaths').value), sold=Number($('lotSold').value), cost=Number($('lotCost').value||0);
    if (!Number.isInteger(initial)||initial<1) { $('formError').textContent='Le nombre initial doit être un entier supérieur à zéro.'; return; }
    if (![deaths,sold,cost].every(n=>Number.isFinite(n)&&n>=0&&Number.isInteger(n))) { $('formError').textContent='Les quantités et le coût doivent être des nombres entiers positifs ou nuls.'; return; }
    if (deaths+sold>initial) { $('formError').textContent='Attention : les morts et les vendus dépassent l’effectif initial.'; return; }
    const id=$('lotId').value || (crypto.randomUUID ? crypto.randomUUID() : `lot-${Date.now()}-${Math.random().toString(16).slice(2)}`);
    const previous=lots.find(l=>l.id===id);
    const lot={id,name:$('lotName').value.trim(),breed:$('lotBreed').value.trim(),date:$('lotDate').value,initial,cost,supplier:$('lotSupplier').value.trim(),deaths,sold,notes:$('lotNotes').value.trim(),createdAt:previous?.createdAt || new Date().toISOString(),updatedAt:new Date().toISOString(),updatedBy:roleNames[activeRole]};
    if(!lot.name||!lot.date){$('formError').textContent='Complétez les champs obligatoires.';return;}
    try { await transact('readwrite',store=>store.put(lot)); $('lotDialog').close(); await refresh(); toast(previous?'Lot mis à jour.':'Lot enregistré sur cet appareil.'); }
    catch(e){$('formError').textContent=`Erreur d’enregistrement : ${e.message||e}`;}
  }
  async function deleteLot(id) {
    if(activeRole!=='admin'){toast('Seul l’administrateur peut supprimer un lot.');return;}
    const l=lots.find(x=>x.id===id); if(!l)return;
    if(!confirm(`Supprimer définitivement le lot « ${l.name} » de cet appareil ? Cette action est irréversible.`))return;
    try{await transact('readwrite',store=>store.delete(id));await refresh();toast('Lot supprimé.');}catch(e){toast('Impossible de supprimer ce lot.');}
  }
  function showDetail(id) {
    const l=lots.find(x=>x.id===id); if(!l)return;
    $('detailContent').innerHTML=`<div class="detail-head"><div><div class="eyebrow">FICHE DU LOT</div><h2>${esc(l.name)}</h2><div class="muted">${esc(l.breed||'Race non précisée')} · Arrivée le ${dateLabel(l.date)}</div></div><button class="icon-button" id="closeDetail" aria-label="Fermer">✕</button></div><div class="detail-grid"><div class="detail-box"><small>Effectif initial</small><strong>${number(l.initial)}</strong></div><div class="detail-box"><small>Effectif restant</small><strong>${number(currentCount(l))}</strong></div><div class="detail-box"><small>Morts</small><strong>${number(l.deaths)}</strong></div><div class="detail-box"><small>Vendus</small><strong>${number(l.sold)}</strong></div><div class="detail-box"><small>Coût d'achat déclaré</small><strong>${money(l.cost)}</strong></div><div class="detail-box"><small>Fournisseur</small><strong>${esc(l.supplier||'—')}</strong></div></div><div class="detail-notes">${esc(l.notes||'Aucune note enregistrée.')}</div><div class="dialog-actions"><button class="secondary" id="detailCloseBottom">Fermer</button>${['admin','manager'].includes(activeRole)?`<button class="primary" id="detailEdit" data-edit="${esc(l.id)}">Modifier</button>`:''}</div>`;
    $('detailDialog').showModal(); $('closeDetail').onclick=()=>$('detailDialog').close(); $('detailCloseBottom').onclick=()=>$('detailDialog').close();
    const edit=$('detailEdit'); if(edit) edit.onclick=()=>{$('detailDialog').close();openEditLot(id);};
  }
  function download(name, content, type) { const blob=new Blob([content],{type}); const url=URL.createObjectURL(blob); const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000); }
  function exportData() { const data={app:'Sen Poulailler EVA PRO',version:'0.1.0',exportedAt:new Date().toISOString(),lots};download(`sen-poulailler-eva-sauvegarde-${today()}.json`,JSON.stringify(data,null,2),'application/json');toast('Sauvegarde exportée. Conservez le fichier en lieu sûr.'); }
  async function importData(file) {
    if(activeRole!=='admin'){toast('Seul l’administrateur peut restaurer une sauvegarde.');return;}
    if(!file)return;
    try { const parsed=JSON.parse(await file.text()); if(parsed.app!=='Sen Poulailler EVA PRO'||!Array.isArray(parsed.lots))throw new Error('Ce fichier ne ressemble pas à une sauvegarde EVA PRO valide.');
      if(!confirm(`Importer ${parsed.lots.length} lot(s) ? Les lots ayant le même identifiant seront remplacés. Exportez d’abord une sauvegarde de sécurité.`))return;
      for(const l of parsed.lots){if(!l.id||!l.name||!Number.isFinite(Number(l.initial))||Number(l.initial)<1||Number(l.deaths||0)+Number(l.sold||0)>Number(l.initial))throw new Error('La sauvegarde contient un lot invalide.');}
      await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');const store=tx.objectStore(STORE);parsed.lots.forEach(l=>store.put(l));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});await refresh();toast('Sauvegarde importée avec succès.');
    } catch(e){alert(`Import impossible : ${e.message||e}`);} finally {$('importFile').value='';}
  }
  document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
  document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.goto)));
  $('addLot').onclick=openNewLot; $('addLotTop').onclick=openNewLot; $('quickAdd').onclick=openNewLot;
  $('closeDialog').onclick=()=>$('lotDialog').close(); $('cancelDialog').onclick=()=>$('lotDialog').close(); $('lotForm').addEventListener('submit',saveLot);
  $('lotSearch').addEventListener('input',renderLotList);
  document.addEventListener('click',e=>{const edit=e.target.closest('[data-edit]');const del=e.target.closest('[data-delete]');const detail=e.target.closest('[data-detail]');if(edit)openEditLot(edit.dataset.edit);else if(del)deleteLot(del.dataset.delete);else if(detail)showDetail(detail.dataset.detail);});
  $('roleSelect').addEventListener('change',e=>{activeRole=e.target.value;applyRole();toast(`Profil de démonstration : ${roleNames[activeRole]}. Ce sélecteur n'est pas une authentification sécurisée.`);});
  $('exportData').onclick=exportData; $('importTrigger').onclick=()=>{if(activeRole!=='admin'){toast('Seul l’administrateur peut restaurer une sauvegarde.');return;}$('importFile').click();}; $('importFile').addEventListener('change',e=>importData(e.target.files[0]));
  $('mobileMenu').onclick=()=>$('sidebar').classList.toggle('open');
  $('year').textContent=new Date().getFullYear();
  function connectionStatus(){const online=navigator.onLine;$('connectionDot').style.background=online?'#71e0a5':'#f3bd56';$('connectionText').textContent=online?'Mode local prêt · Internet disponible':'Mode hors ligne';}
  window.addEventListener('online',connectionStatus);window.addEventListener('offline',connectionStatus);connectionStatus();
  if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost')) navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
  (async()=>{try{await openDb();await refresh();}catch(e){alert(`Initialisation impossible : ${e.message||e}. Ouvrez le projet avec un navigateur récent via localhost ou HTTPS.`);}})();
})();
