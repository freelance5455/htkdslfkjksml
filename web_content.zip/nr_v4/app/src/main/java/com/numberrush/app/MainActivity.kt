package com.numberrush.app

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var web: WebView

    private inner class AppStorage {
        private val prefs = getSharedPreferences("number_rush_data", Context.MODE_PRIVATE)

        @JavascriptInterface
        fun load(): String = prefs.getString("state", "") ?: ""

        @JavascriptInterface
        fun save(value: String) {
            prefs.edit().putString("state", value).apply()
        }

        @JavascriptInterface
        fun clear() {
            prefs.edit().remove("state").apply()
        }
    }

    private fun readAsset(name: String): String {
        assets.open(name).use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                return reader.readText()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AppStorage(), "AndroidStorage")

        // Load the HTML directly from the APK into memory. This avoids
        // appassets.androidplatform.net / file:// routing errors in some
        // Android WebView/build environments.
        val html = readAsset("index.html")
        web.loadDataWithBaseURL(
            "https://numberrush.local/",
            html,
            "text/html",
            "UTF-8",
            null
        )

        setContentView(web)
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }
}
