plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.numberrush.app"; compileSdk = 35
    defaultConfig { applicationId = "com.numberrush.app"; minSdk = 23; targetSdk = 35; versionCode = 4; versionName = "1.0.0" }
}