# NUMBER RUSH — LARGE PROJECT FIXED v4

## Важное исправление загрузки
HTML больше не открывается через `file://` или `appassets.androidplatform.net`.
`MainActivity` читает `index.html` непосредственно из APK и загружает его через `loadDataWithBaseURL`.
Это устраняет `net::ERR_HTTP_RESPONSE_CODE_FAILURE` в сборщиках/Android WebView, которые ломают asset URL.

## Данные
Аккаунты, деньги, XP, уровни и инвентарь сохраняются через Android SharedPreferences (`AndroidStorage`).

## Администратор
Логин: `kerty`
Пароль: `nucio`
ID: `ADMIN-0001`

После установки новой версии протестируй: регистрация/вход → генерация номера → инвентарь → полное закрытие → повторный запуск.

Примечание: это локальная версия приложения. Для настоящей многопользовательской игры с общей админ-панелью нужен сервер/API и база данных.
