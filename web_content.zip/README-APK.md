# ShieldVPN - Android APK & Installation Guide

এই প্রজেক্টটি একটি ফুল-ফিচার্ড ভিপিএন অ্যাপ্লিকেশন। অ্যান্ড্রয়েড ফোনে এটি ব্যবহার বা APK ফাইল পাওয়ার ৩টি উপায় নিচে দেওয়া হলো:

---

### ১. ইনস্ট্যান্ট মোবাইল ইনস্টল (PWA - কোনো APK ডাউনলোড ছাড়াই)
অ্যাপটি প্রোগ্রেসিভ ওয়েব অ্যাপ (PWA) কমপ্লায়েন্ট।
1. আপনার অ্যান্ড্রয়েড ফোনের **Google Chrome** ব্রাউজারে অ্যাপটির লিঙ্ক ওপেন করুন।
2. উপরের ডানদিকের থ্রি-ডট মেনু (⋮) থেকে **"Install app"** বা **"Add to Home screen"** সিলেক্ট করুন।
3. অ্যাপটি সরাসরি আপনার ফোনে নেটিভ অ্যাপ আইকন সহ ইনস্টল হয়ে যাবে এবং ফুলস্ক্রিনে চলবে।

---

### ২. অনলাইন ১-ক্লিক APK জেনারেটর (PWABuilder / Bubblewrap)
মাইক্রোসফট ও গুগলের অফিসিয়াল টুল **PWABuilder** দিয়ে ক্লাউডে সরাসরি এই লাইভ অ্যাপের APK তৈরি করা যায়:
1. ভিজিট করুন: [PWABuilder](https://www.pwabuilder.com)
2. আপনার অ্যাপের লাইভ URL পেস্ট করুন এবং **"Start"** বাটনে চাপুন।
3. **Android** প্যাকেজ সিলেক্ট করে **"Generate APK"** চাপলে সরাসরি ইনস্টলেবল `.apk` ফাইল ডাউনলোড হয়ে যাবে।

---

### ৩. লোকাল মেশিনে Capacitor দিয়ে Android APK বিল্ড
আপনার কম্পিউটার বা ল্যাপটপে Node.js এবং Android Studio থাকলে টার্মিনালে নিচের কমান্ডগুলো চালান:

```bash
# ১. ডিপেনডেন্সি ইনস্টল
npm install @capacitor/core @capacitor/cli @capacitor/android

# ২. ওয়েব বিল্ড
npm run build

# ৩. অ্যান্ড্রয়েড প্রোজেক্ট যুক্ত করা
npx cap init "ShieldVPN" "com.shieldvpn.app" --web-dir dist
npx cap add android

# ৪. প্রোজেক্ট ওপেন করা
npx cap open android
```
এরপর Android Studio তে **Build > Build Bundle(s) / APK(s) > Build APK(s)** চাপলে `app-debug.apk` তৈরি হয়ে যাবে।
