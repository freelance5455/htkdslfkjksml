# طريقة الحصول على ملف APK

## الطريقة الأسهل: PWABuilder (بدون تثبيت أي شيء)

1. ارفع مجلد التطبيق (index.html, manifest.json, sw.js, icon.svg) على استضافة مجانية تدعم HTTPS،
   مثل Netlify Drop (https://app.netlify.com/drop) أو GitHub Pages. اسحب المجلد فقط وسيعطيك رابطاً.
2. افتح https://www.pwabuilder.com والصق الرابط.
3. اضغط Package for stores ثم Android ثم Generate.
4. حمّل الملف المضغوط، وفيه ملف APK جاهز للتثبيت على جوالك (فعّل "التثبيت من مصادر غير معروفة").

ملاحظة: في هذه الطريقة تعمل التنبيهات عبر المتصفح، وقد لا تصل دائماً والتطبيق مغلق.

## الطريقة الأقوى: Capacitor (تنبيهات حقيقية تعمل حتى والتطبيق مغلق)

المتطلبات: Node.js و Android Studio على الكمبيوتر.

```bash
mkdir www
cp index.html manifest.json sw.js icon.svg www/
npm install
npx cap add android
npx cap sync
npx cap open android
```

ثم في Android Studio: Build ثم Build Bundle(s) / APK(s) ثم Build APK(s).
ستجد الملف في: android/app/build/outputs/apk/debug/app-debug.apk

لإضافة إذن التنبيهات الدقيقة، افتح android/app/src/main/AndroidManifest.xml وأضف داخل وسم manifest:

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
```

## الطريقة التلقائية: GitHub Actions (الأسهل بدون كمبيوتر قوي)

1. أنشئ حساباً على github.com ثم مستودعاً جديداً (New repository).
2. ارفع كل ملفات هذا المجلد إليه، بما فيها مجلد `.github` (من الجوال يمكنك استخدام Upload files من المتصفح، وإذا ما ظهر لك المجلد المخفي أنشئ الملف يدوياً بالمسار `.github/workflows/build-apk.yml` وانسخ محتواه).
3. افتح تبويب Actions وانتظر دقائق حتى ينتهي البناء بعلامة خضراء.
4. افتح تبويب Releases (من صفحة المستودع) وحمّل ملف `sadiqi-alqawi.apk` وثبّته على جوالك.

كل تعديل ترفعه بعد ذلك ينتج نسخة APK جديدة تلقائياً.
