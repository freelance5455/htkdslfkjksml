# Meu Orçamento — pacote pronto para gerar APK pelo celular

Este ZIP foi organizado para ser usado como um projeto web/PWA em geradores de APK que aceitam **ZIP com `index.html` na raiz**.

## Arquivo principal
- `index.html` — aplicativo
- `app.js` — lógica e armazenamento local
- `manifest.webmanifest` — configuração PWA/Android
- `sw.js` — funcionamento offline
- `icon-192.png` e `icon-512.png` — ícones Android/PWA

## Uso recomendado
1. No Android, abra o gerador de APK/PWA escolhido no navegador.
2. Se houver opção de enviar um projeto/ZIP, envie este arquivo.
3. Mantenha o modo de aplicativo em tela cheia/standalone, quando disponível.
4. Gere o APK e instale no aparelho.

## Importante
O app foi feito para uso pessoal e **não depende de servidor para guardar seus lançamentos**: os dados ficam no armazenamento local do aplicativo/navegador. Use a função de backup para exportar um JSON periodicamente.

Não há anúncios, login ou publicação na Play Store necessários.
