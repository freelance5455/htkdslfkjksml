# YASH BATTLE ROYALE 3D — Android project

This project wraps the existing offline HTML game in a fullscreen Android WebView.

## Build APK in the cloud (phone-friendly)
1. Sign in to GitHub and create a new repository named `YashBattleRoyale`.
2. Upload the contents of this folder to the repository (not the enclosing folder itself).
3. Open **Actions** → **Build Android APK** → **Run workflow** (or push to `main`).
4. When the workflow finishes, open its run and download the artifact named `YASH-BATTLE-ROYALE-APK`.
5. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone. If prompted, allow installing unknown apps for the app/browser you used.

This produces a debug APK for testing, not a Play Store release-signed APK. For Play Store publication, create a signed Android App Bundle (AAB) and complete Play Console requirements.
