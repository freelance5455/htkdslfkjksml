# Ranking online - ativar (5 minutos, uma vez só)

No Firebase Console (https://console.firebase.google.com) > projeto **eldoria-6720d**:

1. **Build > Firestore Database > Criar banco de dados** (modo produção, qualquer região).
2. Aba **Regras**: cole o conteúdo de `firestore.rules` e clique em **Publicar**.
3. **Build > Authentication > Começar > Método de login > Anônimo > Ativar**.
4. Publique de novo a pasta `www/` (Netlify) ou rode `npm run build` para gerar o APK novo.
   O cache do app foi renomeado para `eldoria-v1.3`, então os aparelhos baixam a versão nova sozinhos.

## Como funciona
- Cada jogador que joga com internet é enviado ao ranking (nome, nível, XP, monstros) a cada ~20 s e ao abrir o Ranking.
- O ranking mostra o top 50 global, ordenado por nível e depois XP. Sem internet, mostra os perfis do aparelho.
- Os saves continuam locais; só nome/nível/XP/abates vão para a nuvem.

## Limites (honestos)
- O jogo roda no aparelho, então as regras barram dados malformados e escrita em documento alheio, mas não impedem
  alguém técnico de enviar um nível falso do próprio perfil. Ranking 100% à prova de trapaça exigiria um servidor.
- Contas são locais: duas pessoas em aparelhos diferentes podem usar o mesmo nome e aparecer duas vezes.
- A apiKey do Firebase pode ficar no código (não é segredo); a proteção é feita pelas regras acima.
