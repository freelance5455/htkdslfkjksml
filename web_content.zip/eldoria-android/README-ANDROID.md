# Legends of Eldoria — Android

Este projeto empacota o jogo web original em um aplicativo Android usando Capacitor.

## Requisitos
- Node.js 22+
- Android Studio com Android SDK
- JDK compatível com a versão do Android Gradle Plugin instalada

## Preparar
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio, execute em um celular/emulador ou use Build > Generate App Bundles or APKs > Generate APKs.

O jogo original está em `www/` e não foi refeito.
