import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.eldoria.rpg',
  appName: 'Legends of Eldoria',
  webDir: 'www',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#0e1420'
  }
};

export default config;
