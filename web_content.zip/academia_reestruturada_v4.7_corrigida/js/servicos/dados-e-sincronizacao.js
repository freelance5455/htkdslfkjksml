// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.services = function () { return {
// <-- VÍRGULA OBRIGATÓRIA AQUI PARA SEPARAR AS FUNÇÕES DO ALPINE

        async syncWithGoogleSheets(isBackground = false) {
            if (!GOOGLE_SCRIPT_URL || this._saveInFlight) return;
            if (isBackground && !this._serverReady) return;
            if (!isBackground) this.isSyncing = true;
            try {
                const res = await fetch(GOOGLE_SCRIPT_URL + "?action=getInitialData&_=" + Date.now(), { cache: 'no-store' });
                if (!res.ok) throw new Error('Não foi possível consultar a planilha.');
                const data = await res.json();
                if (this._saveInFlight) return;

                if (data.students && data.students.length > this.students.length && this.students.length > 0) {
                    const diff = data.students.length - this.students.length;
                    this.addNotification('🥋', `${diff} novo(s) atleta(s) matriculado(s)!`, 'students');
                }
                this.students = this.normalizeStudents(data.students || []);
                this.teachers = (data.teachers || []).map(t => {
                    let workouts = t.teacherWorkouts;
                    if (typeof workouts === 'string') { try { workouts = JSON.parse(workouts); } catch(e) { workouts = []; } }
                    return { ...t, teacherWorkouts: Array.isArray(workouts) ? workouts : [] };
                });
                this.attendanceRecords = Array.isArray(data.attendance) ? data.attendance : [];
                this.attendanceHistory = this.normalizeAttendanceHistory(data.attendanceHistory || []);
                this.plans = Array.isArray(data.plans) ? data.plans : [];
                this.turmas = Array.isArray(data.turmas) ? data.turmas : [];
                if (data.adminProfile && Object.keys(data.adminProfile).length) {
                    this.adminProfileData = typeof data.adminProfile === 'string' ? JSON.parse(data.adminProfile) : data.adminProfile;
                    if (this.adminProfileData.password) this.adminPassword = this.adminProfileData.password;
                }
                if (data.permissions) this.permissions = typeof data.permissions === 'string' ? JSON.parse(data.permissions) : data.permissions;
                if (data.siteSettings && Object.keys(data.siteSettings).length) this.siteSettings = typeof data.siteSettings === 'string' ? JSON.parse(data.siteSettings) : data.siteSettings;
                if (data.scheduledTrainings) this.scheduledTrainings = typeof data.scheduledTrainings === 'string' ? JSON.parse(data.scheduledTrainings) : data.scheduledTrainings;

                if (this.currentUser && this.userRole === 'student') {
                    const current = this.students.find(s => String(s.id) === String(this.currentUser.id));
                    if (current) this.currentUser = current;
                }
                if (this.currentUser && this.userRole === 'teacher') {
                    const current = this.teachers.find(t => String(t.id) === String(this.currentUser.id));
                    if (current && this.adminTab !== 'teacher_profile') this.currentUser = current;
                }

                this._confirmedPayload = JSON.parse(JSON.stringify(this.buildSyncPayload()));
                this._serverReady = true;
                this.isOnline = true;
                this.syncStatus = 'saved';
                this.saveDataLocally();
                if (!isBackground) this.$nextTick(() => lucide.createIcons());
            } catch (e) {
                this.isOnline = false;
                if (!isBackground) this.syncStatus = 'offline';
                console.error('Falha ao carregar dados confirmados do Google Sheets:', e);
            } finally {
                this.isSyncing = false;
            }
        },
saveDataLocally() {
          localStorage.setItem('acad_students', JSON.stringify(this.students));
          localStorage.setItem('acad_teachers', JSON.stringify(this.teachers));
          localStorage.setItem('acad_plans', JSON.stringify(this.plans));
          localStorage.setItem('acad_turmas', JSON.stringify(this.turmas));
          localStorage.setItem('acad_attendance', JSON.stringify(this.attendanceRecords));
          localStorage.setItem('acad_attendance_history', JSON.stringify(this.attendanceHistory));
          localStorage.setItem('acad_notifications', JSON.stringify(this.notifications));
          localStorage.setItem('acad_scheduled_trainings', JSON.stringify(this.scheduledTrainings));
          localStorage.setItem('acad_site_settings', JSON.stringify(this.siteSettings));
          localStorage.setItem('acad_permissions', JSON.stringify(this.permissions));
          localStorage.setItem('acad_admin_pass', this.adminPassword);
          localStorage.setItem('acad_admin_profile', JSON.stringify(this.adminProfileData));
          
          localStorage.setItem('acad_saved_role', this.userRole);
          localStorage.setItem('acad_saved_user', JSON.stringify(this.currentUser));
          localStorage.setItem('acad_saved_admintab', this.adminTab);
        },
buildSyncPayload() {
            const payloadAdmin = { ...this.adminProfileData, password: this.adminPassword };
            // Envia o histórico em ordem cronológica crescente para a planilha.
            // A ordenação é feita em uma cópia para não alterar a ordem usada na tela.
            const attendanceHistoryForSheet = [...(this.attendanceHistory || [])].sort((a, b) => {
                const toTime = (value) => {
                    const raw = String(value || '').trim().split('T')[0];
                    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return new Date(raw + 'T00:00:00').getTime();
                    const br = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
                    if (br) return new Date(`${br[3]}-${br[2]}-${br[1]}T00:00:00`).getTime();
                    const parsed = new Date(value).getTime();
                    return Number.isFinite(parsed) ? parsed : 0;
                };
                return toTime(a.date) - toTime(b.date) || String(a.id || '').localeCompare(String(b.id || ''), undefined, { numeric: true });
            });
            return {
                students: this.students,
                teachers: this.teachers,
                attendance: this.attendanceRecords,
                attendanceHistory: attendanceHistoryForSheet,
                plans: this.plans,
                turmas: this.turmas,
                scheduledTrainings: this.scheduledTrainings,
                siteSettings: this.siteSettings,
                permissions: this.permissions,
                adminProfile: payloadAdmin
            };
        },

        applySyncPayload(payload) {
            if (!payload) return;
            this.students = this.normalizeStudents(payload.students || []);
            this.teachers = (payload.teachers || []).map(t => ({ ...t, teacherWorkouts: Array.isArray(t.teacherWorkouts) ? t.teacherWorkouts : [] }));
            this.attendanceRecords = payload.attendance || [];
            this.attendanceHistory = this.normalizeAttendanceHistory(payload.attendanceHistory || []);
            this.plans = payload.plans || [];
            this.turmas = payload.turmas || [];
            this.scheduledTrainings = payload.scheduledTrainings || {};
            this.siteSettings = payload.siteSettings || {};
            this.permissions = payload.permissions || this.permissions;
            if (payload.adminProfile) {
                this.adminProfileData = payload.adminProfile;
                if (payload.adminProfile.password) this.adminPassword = payload.adminProfile.password;
            }
            if (this.currentUser && this.userRole === 'student') {
                const current = this.students.find(s => String(s.id) === String(this.currentUser.id));
                if (current) this.currentUser = current;
            } else if (this.currentUser && this.userRole === 'teacher') {
                const current = this.teachers.find(t => String(t.id) === String(this.currentUser.id));
                if (current) this.currentUser = current;
            }
        },

        checkServerReceipt(syncId, timeoutMs = 12000) {
            return new Promise((resolve, reject) => {
                const callbackName = '__gymSyncReceiptCallback';
                let finished = false;
                let script;
                const cleanup = () => {
                    if (finished) return;
                    finished = true;
                    if (script && script.parentNode) script.parentNode.removeChild(script);
                    try { delete window[callbackName]; } catch(e) { window[callbackName] = undefined; }
                    clearTimeout(timer);
                };
                const timer = setTimeout(() => { cleanup(); reject(new Error('O servidor não confirmou a gravação dentro do prazo.')); }, timeoutMs);
                window[callbackName] = (receipt) => {
                    if (receipt && receipt.status === 'success' && receipt.id === syncId) {
                        cleanup(); resolve(receipt);
                    } else if (receipt && receipt.status === 'error') {
                        cleanup(); reject(new Error(receipt.message || 'O Google Sheets recusou a gravação.'));
                    } else if (receipt && receipt.status === 'stale') {
                        cleanup(); reject(new Error('Esta alteração ficou desatualizada. Atualize os dados e tente novamente.'));
                    } else {
                        cleanup(); reject(new Error('O servidor não encontrou a confirmação desta gravação.'));
                    }
                };
                script = document.createElement('script');
                script.onerror = () => { cleanup(); reject(new Error('Não foi possível consultar a confirmação do Google Sheets.')); };
                script.src = GOOGLE_SCRIPT_URL + '?action=checkSync&syncId=' + encodeURIComponent(syncId) + '&callback=' + callbackName + '&_=' + Date.now();
                document.head.appendChild(script);
            });
        },

        async flushPendingSync() {
            // Compatibilidade com chamadas antigas: não há fila local considerada como confirmação.
            return this.syncWithGoogleSheets(true);
        },

        async saveDataInBackground() {
            if (!GOOGLE_SCRIPT_URL) throw new Error('Endereço do Google Apps Script não configurado.');
            if (!this._serverReady || !this._confirmedPayload) throw new Error('Aguarde o carregamento dos dados oficiais da planilha.');
            if (this._saveInFlight) throw new Error('Já existe uma gravação em andamento. Aguarde a confirmação.');

            const candidate = JSON.parse(JSON.stringify(this.buildSyncPayload()));
            const previous = JSON.parse(JSON.stringify(this._confirmedPayload));
            const syncId = 'sync_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
            candidate._syncMeta = { id: syncId, createdAt: new Date().toISOString() };

            this._saveInFlight = true;
            this.syncStatus = 'sending';
            this.savingMessage = 'Aguardando confirmação do Google Sheets...';
            this.isSavingData = true;
            // Reverte a alteração visual imediatamente; só reaplica após confirmação do servidor.
            this.applySyncPayload(previous);
            try {
                await fetch(GOOGLE_SCRIPT_URL, {
                    method: 'POST',
                    mode: 'no-cors',
                    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                    body: JSON.stringify(candidate)
                });
                await this.checkServerReceipt(syncId);
                delete candidate._syncMeta;
                this.applySyncPayload(candidate);
                this._confirmedPayload = JSON.parse(JSON.stringify(candidate));
                this.saveDataLocally();
                this.isOnline = true;
                this.syncStatus = 'saved';
                return true;
            } catch (error) {
                this.applySyncPayload(previous);
                this._confirmedPayload = previous;
                this.isOnline = false;
                this.syncStatus = 'error';
                console.error('A gravação não foi confirmada; os dados anteriores foram mantidos:', error);
                throw error;
            } finally {
                this._saveInFlight = false;
                this.isSavingData = false;
            }
        },

async saveAdminProfile() {
          if (this.adminProfileData.name && this.adminPassword) {
            this.adminProfileData.password = this.adminPassword;
            try {
              await this.saveDataInBackground();
              this.currentUser = { name: this.adminProfileData.name };
              alert('✅ Dados do Admin confirmados na planilha!');
            } catch (error) { alert('❌ Não foi possível confirmar o salvamento. Os dados anteriores foram mantidos.'); }
          } else alert('Preencha os campos obrigatórios!');
        },
saveQrCodeLocal() { localStorage.setItem('acad_site_url', this.siteUrlInput); },
async saveSiteSettings() {
          try { await this.saveDataInBackground(); alert('✅ Configurações confirmadas na planilha!'); }
          catch (error) { alert('❌ Não foi possível confirmar o salvamento. As configurações anteriores foram mantidas.'); }
        }
}; };
