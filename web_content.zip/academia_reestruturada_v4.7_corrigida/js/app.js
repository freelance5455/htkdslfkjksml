// Ponto central de inicialização Alpine.js. Preserva descritores de getters/setters e o contexto "this".
(function () {
  const moduleOrder = [
    'core', 'auth', 'students', 'teachers', 'classes', 'plans',
    'attendance', 'calendar', 'dashboard', 'notifications', 'services'
  ];
  window.gymApp = function gymApp() {
    const descriptors = Object.getOwnPropertyDescriptors(window.GYM_STATE ? window.GYM_STATE() : {});
    moduleOrder.forEach((name) => {
      const factory = window.GYM_MODULES && window.GYM_MODULES[name];
      if (typeof factory === 'function') {
        Object.assign(descriptors, Object.getOwnPropertyDescriptors(factory()));
      }
    });
    return Object.defineProperties({}, descriptors);
  };
})();
