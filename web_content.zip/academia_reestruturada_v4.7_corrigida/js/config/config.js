// Configurações centrais do sistema.
window.GYM_CONFIG = Object.freeze({
  GOOGLE_SCRIPT_URL: "https://script.google.com/macros/s/AKfycbxgJMnbJuuZIw9Snxj9aEYEdWxwyOAylU8-s0UO8hGsvJeXqXd9iMrbvp2uQ9RMUVPp/exec"
});
const GOOGLE_SCRIPT_URL = window.GYM_CONFIG.GOOGLE_SCRIPT_URL;
