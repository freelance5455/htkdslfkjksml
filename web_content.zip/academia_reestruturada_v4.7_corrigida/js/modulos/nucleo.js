// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.core = function () { return {
// Certifique-se de que todas as outras variáveis e funções do seu app estão aqui dentro, antes da última chaveta!
        
toggleTheme() {
          this.isDarkMode = !this.isDarkMode;
          localStorage.setItem('acad_dark_mode', this.isDarkMode);
          this.$nextTick(() => lucide.createIcons());
        },
formatDateDisplay(dateStr) {
          if (!dateStr) return 'Não informada';
          try {
            const cleanDate = String(dateStr).split('T')[0];
            const parts = cleanDate.split('-');
            if (parts.length === 3) {
              return `${parts[2]}/${parts[1]}/${parts[0]}`;
            }
          } catch(e) {}
          return dateStr;
        },
calculateGymTime(startDateStr) {
          if (!startDateStr) return 'Início não informado';
          const start = new Date(startDateStr);
          const now = new Date();
          if (isNaN(start.getTime())) return 'Data inválida';

          let years = now.getFullYear() - start.getFullYear();
          let months = now.getMonth() - start.getMonth();

          if (months < 0) {
            years--;
            months += 12;
          }
          if (years < 0) return 'Data futura';

          let res = [];
          if (years > 0) res.push(`${years} ${years === 1 ? 'ano' : 'anos'}`);
          if (months > 0 || years === 0) res.push(`${months} ${months === 1 ? 'mês' : 'meses'}`);
          return res.join(' e ');
        },
initApp() {
            // Os dados de alunos, professores, cobranças e chamadas vêm da planilha.
            // O navegador não é usado como fonte de verdade nem exibe alterações não confirmadas.
            this.$nextTick(() => lucide.createIcons());
            this.syncWithGoogleSheets(false);
            // Atualiza a tela periodicamente com a versão oficial da planilha.
            setInterval(() => this.syncWithGoogleSheets(true), 30000);
        },
generateQrCode() {
          if (!this.siteUrlInput) return;
          this.saveQrCodeLocal();
          const container = document.getElementById('qrcode');
          if (container) {
            container.innerHTML = '';
            new QRCode(container, { text: this.siteUrlInput, width: 160, height: 160, colorDark: "#000000", colorLight: "#ffffff", correctLevel: QRCode.CorrectLevel.H });
            this.showQrCodeBox = true;
          }
        },
changeMonth(dir) { 
          this.currentCalendarDate = new Date(this.currentCalendarDate.getFullYear(), this.currentCalendarDate.getMonth() + dir, 1); 
        },
formatMonthYear() { return this.currentCalendarDate.toLocaleDateString('pt-PT', { month: 'long', year: 'numeric' }); },
changeAdminModalMonth(dir) {
          this.currentAdminModalCalendarDate = new Date(this.currentAdminModalCalendarDate.getFullYear(), this.currentAdminModalCalendarDate.getMonth() + dir, 1);
        },
formatAdminModalMonthYear() { return this.currentAdminModalCalendarDate.toLocaleDateString('pt-PT', { month: 'long', year: 'numeric' }); },
openScheduleModal(dateStr) {
          this.selectedScheduleDate = dateStr;
          this.scheduleInfoText = this.scheduledTrainings[dateStr] || '';
          this.showScheduleModal = true;
        },
handleBannerUpload(e) {
          const file = e.target.files[0];
          if (file) { this.compressImage(file, (url) => { this.siteSettings.bannerPhoto = url; }); }
        },
sendWhatsAppBilling(s) {
          const phone = String(s.phone || '').replace(/\D/g, '');
          
          const mensagem = `Olá ${s.name}, lembramos que sua mensalidade está pendente.
Não fique sem treinar!
Você pode fazer o pagamento pela chave pix abaixo ou pessoalmente pelo cartão ou em dinheiro.
83987186400
Banco INTER 

Esta mensagem é automática.
Qualquer dúvida só falar!
Oss!`;

          window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(mensagem)}`, '_blank');
        },
async searchCep() {
          const cep = String(this.studentForm.cep).replace(/\D/g, '');
          if (cep.length === 8) {
            const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const data = await res.json();
            if (!data.erro) {
              this.studentForm.street = data.logradouro;
              this.studentForm.neighborhood = data.bairro;
              this.studentForm.city = `${data.localidade}/${data.uf}`;
            }
          }
        },
todayAbsenceCount() { return Math.max(0, this.students.filter(s => s.status === 'Ativo').length - this.todayAttendanceCount()); },
openImageModal(url) {
          this.modalImageUrl = url;
          this.showImageModal = true;
        },
handleFileUpload(e, target) {
          const file = e.target.files[0];
          if (file) {
            this.compressImage(file, (url) => {
              if(target === 'student') this.studentForm.photo = url;
              else if(target === 'student_edit') this.studentProfileForm.photo = url;
              else if(target === 'admin_profile') this.adminProfileData.photo = url;
              else if(target === 'teacher_profile') this.teacherProfileForm.photo = url;
              else if(target === 'attendance') this.attendancePhoto = url;
              else if(target === 'history_edit') this.editingHistoryForm.photo = url;
            });
          }
        },
compressImage(fileOrDataUrl, callback, maxWidth = 400, maxHeight = 400) {
          const img = new Image();
          img.onload = () => {
            const canvas = document.createElement('canvas');
            let w = img.width, h = img.height;
            if (w > h) { if (w > maxWidth) { h *= maxWidth / w; w = maxWidth; } }
            else { if (h > maxHeight) { w *= maxHeight / h; h = maxHeight; } }
            canvas.width = w; canvas.height = h;
            canvas.getContext('2d').drawImage(img, 0, 0, w, h);
            callback(canvas.toDataURL('image/jpeg', 0.80));
          };
          if (typeof fileOrDataUrl === 'string') { img.src = fileOrDataUrl; }
          else {
            const reader = new FileReader();
            reader.onload = (e) => { img.src = e.target.result; };
            reader.readAsDataURL(fileOrDataUrl);
          }
        }
}; };
