// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.calendar = function () { return {
async saveScheduleDate() {
          if (this.selectedScheduleDate) {
            if (this.scheduleInfoText) {
              this.scheduledTrainings[this.selectedScheduleDate] = this.scheduleInfoText;
            } else {
              delete this.scheduledTrainings[this.selectedScheduleDate];
            }
            await this.saveDataInBackground();
            alert('✅ Treino/Observação salva com sucesso!');
          }
          this.showScheduleModal = false;
        },
async removeScheduleDate() {
          if (confirm('Deseja realmente remover esta observação?')) {
            if (this.selectedScheduleDate && this.scheduledTrainings[this.selectedScheduleDate]) {
              delete this.scheduledTrainings[this.selectedScheduleDate];
              await this.saveDataInBackground();
            }
            this.showScheduleModal = false;
          }
        },
get calendarDays() {
          const year = this.currentCalendarDate.getFullYear();
          const month = this.currentCalendarDate.getMonth();
          const firstDayIndex = new Date(year, month, 1).getDay();
          const totalDays = new Date(year, month + 1, 0).getDate();
          const days = [];
          for (let i = 0; i < firstDayIndex; i++) { days.push({ dayNumber: '', isCurrentMonth: false, date: '' }); }
          for (let i = 1; i <= totalDays; i++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            const trainingInfo = this.scheduledTrainings[dateStr];
            days.push({ dayNumber: i, isCurrentMonth: true, date: dateStr, hasTraining: !!trainingInfo, trainingInfo: trainingInfo || '' });
          }
          return days;
        },
get adminModalCalendarDays() {
          const year = this.currentAdminModalCalendarDate.getFullYear();
          const month = this.currentAdminModalCalendarDate.getMonth();
          const firstDayIndex = new Date(year, month, 1).getDay();
          const totalDays = new Date(year, month + 1, 0).getDate();
          const days = [];
          const attendanceSet = new Set();

          const targetStudentId = String(this.selectedStudentAttendanceId || (this.selectedStudentAttendance?.id || ''));

          if (targetStudentId) {
            this.attendanceRecords.forEach(r => {
              if (String(r.studentId) === targetStudentId) {
                attendanceSet.add(String(r.date).split('T')[0]);
              }
            });
          }
          for (let i = 0; i < firstDayIndex; i++) { days.push({ dayNumber: '', isCurrentMonth: false }); }
          for (let i = 1; i <= totalDays; i++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            const isPresent = attendanceSet.has(dateStr);
            days.push({ dayNumber: i, isCurrentMonth: true, date: dateStr, isPresent });
          }
          return days;
        }
}; };
