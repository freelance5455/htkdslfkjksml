
// Módulo extraído do código original.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.students = function () { return {

normalizeStudents(list) {
    if (!Array.isArray(list)) return [];
    return list.map(s => {
        let champs = s.championships;

        if (typeof champs === 'string') {
            try {
                champs = JSON.parse(champs);
            } catch(e) {
                champs = champs
                    ? champs.split(',').map(item => item.trim()).filter(Boolean)
                    : [];
            }
        }

        if (!Array.isArray(champs)) champs = [];

        return { ...s, championships: champs };
    });
},

// ==========================================
// CADASTRO DE VISITANTES
// ==========================================

openVisitorModal(visitor = null) {
    this.visitorEditingId = visitor ? String(visitor.id) : null;

    this.visitorForm = {
        name: visitor
            ? String(visitor.name || '').replace(/\s*\(visitante\)\s*$/i, '').trim()
            : '',
        phone: visitor ? (visitor.phone || '') : '',
        belt: visitor ? (visitor.belt || '') : ''
    };

    this.showVisitorModal = true;
},

closeVisitorModal() {
    this.showVisitorModal = false;
    this.visitorEditingId = null;
},

async saveVisitor() {
    const wasEditing = !!this.visitorEditingId;

    const cleanName = String(this.visitorForm?.name || '')
        .replace(/\s*\(visitante\)\s*$/i, '')
        .trim();

    if (!cleanName) {
        alert('Informe o nome do visitante.');
        return;
    }

    const visitorName = `${cleanName} (visitante)`;

    if (wasEditing) {
        const visitor = this.students.find(
            s => String(s.id) === String(this.visitorEditingId)
                && s.personType === 'visitor'
        );

        if (!visitor) {
            alert('Visitante não encontrado.');
            return;
        }

        visitor.name = visitorName;
        visitor.phone = String(this.visitorForm.phone || '').trim();
        visitor.belt = String(this.visitorForm.belt || '').trim();
        visitor.status = 'Visitante';
        visitor.personType = 'visitor';

    } else {
        let newId;

        do {
            newId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        } while (
            this.students.some(s => String(s.id) === newId)
        );

        this.students.push({
            id: newId,
            name: visitorName,
            phone: String(this.visitorForm.phone || '').trim(),
            belt: String(this.visitorForm.belt || '').trim(),
            status: 'Visitante',
            personType: 'visitor'
        });
    }

    try {
        await this.saveDataInBackground();

        this.closeVisitorModal();

        this.addNotification(
            '👤',
            wasEditing
                ? `Visitante atualizado: ${visitorName}`
                : `Visitante cadastrado: ${visitorName}`,
            'students'
        );

        alert(
            wasEditing
                ? 'Visitante atualizado com sucesso!'
                : 'Visitante cadastrado com sucesso!'
        );

    } catch (error) {
        console.error('Erro ao salvar visitante:', error);

        alert(
            'Não foi possível salvar o visitante. Verifique a sincronização e tente novamente.'
        );
    }
},

async deleteVisitor(id) {
    const visitor = this.students.find(
        s => String(s.id) === String(id)
            && s.personType === 'visitor'
    );

    if (!visitor) {
        alert('Visitante não encontrado.');
        return;
    }

    if (!confirm(`Deseja realmente excluir ${visitor.name}?`)) {
        return;
    }

    const previousStudents = this.students.slice();

    this.students = this.students.filter(
        s => !(
            String(s.id) === String(id)
            && s.personType === 'visitor'
        )
    );

    try {
        await this.saveDataInBackground();

        alert('Visitante excluído com sucesso!');

    } catch (error) {
        this.students = previousStudents;

        console.error('Erro ao excluir visitante:', error);

        alert('Não foi possível excluir o visitante. Tente novamente.');
    }
},

// Lista combinada: alunos e visitantes.
// Utilizada na aba administrativa.
get filteredPeople() {
    const regularStudents = this.filteredStudents || [];

    const query = String(this.searchQuery || '')
        .toLowerCase()
        .trim();

    const visitors = this.students.filter(s => {
        if (s.personType !== 'visitor') return false;

        if (!query) return true;

        return String(s.name || '').toLowerCase().includes(query)
            || String(s.phone || '').toLowerCase().includes(query);
    });

    const combined = [...regularStudents, ...visitors];
    const unique = new Map();

    combined.forEach(person => {
        unique.set(String(person.id), person);
    });

    return Array.from(unique.values());
},

// ==========================================
// PERFIL DO ALUNO
// ==========================================

openStudentProfileEdit() {
    if (!this.currentUser) return;

    let formattedDate = '';

    if (this.currentUser.startDate) {
        formattedDate = String(this.currentUser.startDate).split('T')[0];
    }

    this.studentProfileForm = {
        name: this.currentUser.name || '',
        phone: this.currentUser.phone || '',
        startDate: formattedDate,
        password: this.currentUser.password || '123456',
        photo: this.currentUser.photo || ''
    };

    this.showStudentProfileModal = true;
},

async saveStudentProfileEdit() {
    if (!this.currentUser) return;

    this.isSaving = true;
    this.savingMessage = 'A atualizar o seu perfil no servidor...';

    try {
        const idx = this.students.findIndex(
            s => s.id === this.currentUser.id
        );

        if (idx !== -1) {
            this.students[idx].name = this.studentProfileForm.name;
            this.students[idx].phone = this.studentProfileForm.phone;
            this.students[idx].startDate = this.studentProfileForm.startDate;
            this.students[idx].password = this.studentProfileForm.password;
            this.students[idx].photo = this.studentProfileForm.photo;

            this.currentUser = { ...this.students[idx] };

            await this.saveDataInBackground();

            this.showStudentProfileModal = false;

            alert('✅ Perfil atualizado com sucesso!');
        }

    } catch (e) {
        console.error(e);
        alert('Erro ao sincronizar com o servidor.');

    } finally {
        this.isSaving = false;
    }
},

// ==========================================
// PLANO DO ALUNO
// ==========================================

openStudentPlanChangeModal() {
    if (this.currentUser && this.currentUser.planId) {
        this.selectedNewPlanId = String(this.currentUser.planId);
    } else {
        this.selectedNewPlanId = '';
    }

    this.showStudentPlanModal = true;
},

async saveStudentPlanChange() {
    this.lastLocalActionTime = Date.now() + 30000;

    if (!this.currentUser) {
        alert('Erro: Sessão não encontrada.');
        return;
    }

    if (!this.selectedNewPlanId) {
        const selectEl = document.querySelector(
            'select[x-model="selectedNewPlanId"]'
        );

        if (selectEl && selectEl.value) {
            this.selectedNewPlanId = selectEl.value;
        }
    }

    if (
        !this.selectedNewPlanId
        || String(this.selectedNewPlanId).trim() === ''
    ) {
        alert('Por favor, selecione um plano!');
        return;
    }

    const currentUserId = String(this.currentUser.id);

    const idx = this.students.findIndex(
        s => String(s.id) === currentUserId
    );

    if (idx !== -1) {
        const newPlanObj = this.plans.find(
            p =>
                String(p.id) === String(this.selectedNewPlanId)
                || String(p.name) === String(this.selectedNewPlanId)
        );

        if (newPlanObj) {
            this.students[idx].planId = newPlanObj.id || newPlanObj.name;

            if (newPlanObj.modality) {
                this.students[idx].modality = newPlanObj.modality;
            }
        } else {
            this.students[idx].planId = this.selectedNewPlanId;
        }

        this.currentUser = JSON.parse(
            JSON.stringify(this.students[idx])
        );

        if (typeof this.saveDataInBackground === 'function') {
            await this.saveDataInBackground();
        }

        this.showStudentPlanModal = false;

        alert('✅ Plano alterado com sucesso!');

    } else {
        alert('Erro: Aluno não encontrado.');
    }
},

// ==========================================
// OUTRAS OPÇÕES DO ALUNO
// ==========================================

openStudentTrainingDaysModal() {
    this.showStudentTrainingDaysModalBox = true;
},

openStudentEvolutionViewModal() {
    this.showStudentEvolutionModalBox = true;
},

openStudentNotesModal() {
    this.studentNotesText = this.currentUser?.studentNotes || '';
    this.showStudentNotesModalBox = true;
},

async saveStudentNotes() {
    if (!this.currentUser) return;

    const currentUserId = String(this.currentUser.id);

    const idx = this.students.findIndex(
        s => String(s.id) === currentUserId
    );

    if (idx !== -1) {
        this.students[idx].studentNotes = this.studentNotesText;

        this.currentUser = JSON.parse(
            JSON.stringify(this.students[idx])
        );

        if (typeof this.saveDataInBackground === 'function') {
            await this.saveDataInBackground();
        }

        this.showStudentNotesModalBox = false;

        alert('✅ Anotações salvas com sucesso!');
    }
},

openStudentDataModal(s) {
    this.selectedStudentData = s;
    this.showStudentDataModal = true;
},

openMedicalModal(s) {
    this.selectedMedicalStudent = s;
    this.showMedicalModal = true;
},

// ==========================================
// CAMPEONATOS
// ==========================================

openChampionshipsModal(s) {
    this.selectedChampionshipStudent = s;

    let champs = s.championships;

    if (typeof champs === 'string') {
        try {
            champs = JSON.parse(champs);
        } catch(e) {
            champs = champs
                ? champs.split(',').map(i => i.trim()).filter(Boolean)
                : [];
        }
    }

    if (!Array.isArray(champs)) champs = [];

    this.editingChampionshipsList = [...champs];
    this.newChampionshipName = '';
    this.showChampionshipsModal = true;
},

addChampionship() {
    if (!this.newChampionshipName.trim()) return;

    this.editingChampionshipsList.push(
        this.newChampionshipName.trim()
    );

    this.newChampionshipName = '';
},

removeChampionship(index) {
    if (confirm('Remover este campeonato?')) {
        this.editingChampionshipsList.splice(index, 1);
    }
},

async saveChampionships() {
    if (!this.selectedChampionshipStudent) return;

    const idx = this.students.findIndex(
        s => String(s.id) === String(this.selectedChampionshipStudent.id)
    );

    if (idx !== -1) {
        this.students[idx].championships = [
            ...this.editingChampionshipsList
        ];
    }

    await this.saveDataInBackground();

    this.showChampionshipsModal = false;

    alert('✅ Campeonatos salvos com sucesso!');
},

// ==========================================
// GRADUAÇÃO
// ==========================================

openGraduationModal(s) {
    this.selectedGraduationStudent = s;
    this.showGraduationModal = true;
},

async saveGraduation() {
    const idx = this.students.findIndex(
        s => s.id === this.selectedGraduationStudent.id
    );

    if (idx !== -1) {
        this.students[idx].belt = this.selectedGraduationStudent.belt;
        this.students[idx].degrees = Number(
            this.selectedGraduationStudent.degrees
        );
    }

    await this.saveDataInBackground();

    this.showGraduationModal = false;

    alert('✅ Graduação atualizada com sucesso!');
},

// ==========================================
// BUSCA DE NOMES
// ==========================================

getStudentName(id) {
    const s = this.students.find(
        x => String(x.id) === String(id)
    );

    return s ? s.name : 'Atleta';
},

// ==========================================
// EVOLUÇÃO
// ==========================================

openEvolutionModal(s) {
    this.selectedEvolutionStudent = s;
    this.selectedEvolutionStudentText = s.evolutionNotes || '';
    this.showEvolutionModal = true;
},

async saveEvolutionNotes() {
    const idx = this.students.findIndex(
        s => s.id === this.selectedEvolutionStudent.id
    );

    if (idx !== -1) {
        this.students[idx].evolutionNotes = this.selectedEvolutionStudentText;

        await this.saveDataInBackground();

        alert('✅ Evolução salva!');
    }

    this.showEvolutionModal = false;
},

// ==========================================
// CADASTRO NORMAL DE ALUNOS
// ==========================================

async submitStudentRegister() {
    const newStudent = {
        id: String(Date.now()),
        ...this.studentForm,
        dueDay: 10,
        status: 'Ativo',
        paymentStatus: 'Pendente',
        belt: 'Branca',
        degrees: 0,
        championships: [],
        evolutionNotes: ''
    };

    this.students.push(newStudent);

    this.addNotification(
        '🥋',
        `Novo aluno: ${newStudent.name}`,
        'students'
    );

    await this.saveDataInBackground();

    alert('✅ Inscrição realizada com sucesso!');

    this.currentScreen = 'login';
    this.formStep = 1;
},

// ==========================================
// EDIÇÃO NORMAL DE ALUNOS
// ==========================================

openEditStudentModal(student) {
    this.editingStudent = JSON.parse(
        JSON.stringify(student)
    );

    if (this.editingStudent.startDate) {
        this.editingStudent.startDate = String(
            this.editingStudent.startDate
        ).split('T')[0];
    }

    this.showEditStudentModal = true;
},

async saveStudentEdit() {
    const idx = this.students.findIndex(
        s => s.id === this.editingStudent.id
    );

    if (idx !== -1) {
        this.students[idx] = {
            ...this.editingStudent
        };

        await this.saveDataInBackground();

        this.showEditStudentModal = false;

        alert('✅ Aluno atualizado!');
    }
},

async toggleStudentStatus(s) {
    const action = s.status === 'Inativo'
        ? 'reativar'
        : 'inativar';

    if (confirm(`Deseja realmente ${action} o aluno ${s.name}?`)) {
        s.status = s.status === 'Inativo'
            ? 'Ativo'
            : 'Inativo';

        await this.saveDataInBackground();
    }
},

openStudentChampionshipsModal() {
    this.showStudentChampionshipsModalBox = true;
},

async deleteStudent(id) {
    if (
        confirm(
            'Tem certeza absoluta que deseja eliminar este aluno do sistema?'
        )
    ) {
        this.students = this.students.filter(
            s => s.id !== id
        );

        await this.saveDataInBackground();

        alert('✅ Aluno excluído com sucesso!');
    }
},

// ==========================================
// LISTAS E CONTAGENS
// ==========================================

// Somente alunos ativos. Visitantes não entram.
get activeStudents() {
    return this.students.filter(
        s => s.personType !== 'visitor'
            && s.status === 'Ativo'
    );
},

// Somente alunos normais, sem visitantes.
get filteredStudents() {
    const query = String(this.searchQuery || '')
        .trim()
        .toLowerCase();

    const regularStudents = this.students.filter(
        s => s.personType !== 'visitor'
    );

    if (!query) return regularStudents;

    return regularStudents.filter(s => {
        const name = String(s.name || '').toLowerCase();
        const phone = String(s.phone || '').toLowerCase();

        return name.includes(query) || phone.includes(query);
    });
},

// Lista de alunos para vencimentos.
get sortedStudentsByDueDay() {
    if (!Array.isArray(this.students)) return [];

    return this.students
        .filter(s => s.personType !== 'visitor')
        .slice()
        .sort(
            (a, b) =>
                (Number(a.dueDay) || 10)
                - (Number(b.dueDay) || 10)
        );
}

}; };

