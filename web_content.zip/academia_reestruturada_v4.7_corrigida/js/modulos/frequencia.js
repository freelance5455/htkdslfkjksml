
// Módulo extraído do código original.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.attendance = function () {
return {

normalizeAttendanceHistory(list) {
    if (!Array.isArray(list)) return [];

    return list.map(item => {
        let ids = item.studentIds || item.students;

        if (typeof ids === 'string') {
            try {
                ids = JSON.parse(ids);
            } catch (e) {
                ids = ids
                    ? ids.split(',').map(i => i.trim()).filter(Boolean)
                    : [];
            }
        }

        if (!Array.isArray(ids)) ids = [];

        return { ...item, studentIds: ids };
    });
},

openStudentAttendanceModal() {
    this.showStudentAttendanceModalBox = true;
},

openEditAttendanceHistory(item) {
    let studentIds = item.studentIds || [];

    if (typeof studentIds === 'string') {
        try {
            studentIds = JSON.parse(studentIds);
        } catch (error) {
            studentIds = [];
        }
    }

    if (!Array.isArray(studentIds)) {
        studentIds = [];
    }

    const historyId = String(item.id || '').trim();

    const possibleIds = [
        historyId,
        String(item.attendanceId || '').trim()
    ].filter(Boolean);

    const linkedRecords = this.attendanceRecords.filter(record =>
        possibleIds.includes(String(record.attendanceId || '').trim())
    );

    const linkedIds = linkedRecords.map(record =>
        String(record.studentId)
    );

    if (linkedIds.length) {
        studentIds = linkedIds;
    }

    this.editingHistoryItem = {
        ...item,
        attendanceId: linkedRecords.length
            ? String(linkedRecords[0].attendanceId)
            : ''
    };

    this.editingHistoryForm = {
        id: item.id,
        date: item.date,
        turmaId: item.turmaId || '',
        photo: item.photo || '',
        studentIds: [...new Set(studentIds.map(id => String(id)))]
    };

    this.showEditHistoryModal = true;
},

toggleHistoryEditStudent(studentId, checked) {
    const id = String(studentId);

    const selected = this.editingHistoryForm.studentIds || [];

    if (checked) {
        if (!selected.includes(id)) {
            this.editingHistoryForm.studentIds = [...selected, id];
        }
    } else {
        this.editingHistoryForm.studentIds = selected.filter(
            student => String(student) !== id
        );
    }
},

async saveHistoryEdit() {
    const idx = this.attendanceHistory.findIndex(
        h => String(h.id) === String(this.editingHistoryForm.id)
    );

    if (idx === -1) return;

    this.loadingText = 'SALVANDO ALTERAÇÕES...';
    this.isSavingAttendance = true;

    try {
        const historyItem = this.attendanceHistory[idx];

        const historyId = String(historyItem.id || '').trim();

        historyItem.date = this.editingHistoryForm.date;
        historyItem.turmaId = this.editingHistoryForm.turmaId;
        historyItem.photo = this.editingHistoryForm.photo;

        const attendanceId = String(
            historyItem.attendanceId || historyId
        ).trim();

        const hasLinkedRecords = this.attendanceRecords.some(
            record =>
                String(record.attendanceId || '').trim() === attendanceId
        );

        if (hasLinkedRecords) {
            const selectedStudentIds = [
                ...new Set(
                    (this.editingHistoryForm.studentIds || [])
                        .map(id => String(id))
                )
            ];

            historyItem.studentIds = selectedStudentIds;

            const otherRecords = this.attendanceRecords.filter(
                record =>
                    String(record.attendanceId || '').trim() !== attendanceId
            );

            const updatedRecords = selectedStudentIds.map(studentId => ({
                studentId: studentId,
                date: historyItem.date,
                turmaId: historyItem.turmaId,
                attendanceId: attendanceId
            }));

            this.attendanceRecords = [
                ...otherRecords,
                ...updatedRecords
            ];
        }

        await this.saveDataInBackground();

        this.showEditHistoryModal = false;

        alert('✅ Registo de chamada atualizado com sucesso!');

    } catch (error) {
        console.error(error);

        alert(
            '❌ Ocorreu um erro ao atualizar o registo. Os dados anteriores foram mantidos.'
        );

    } finally {
        this.isSavingAttendance = false;
    }
},

async deleteAttendanceHistory(id) {
    if (!confirm(
        'Tem certeza que deseja excluir permanentemente este registo de chamada e respetiva foto?'
    )) {
        return;
    }

    this.loadingText = 'EXCLUINDO A CHAMADA...';
    this.isSavingAttendance = true;

    try {
        const historyItem = this.attendanceHistory.find(
            h => String(h.id) === String(id)
        );

        if (!historyItem) {
            throw new Error('Registo de chamada não encontrado.');
        }

        const historyId = String(historyItem.id || '').trim();

        const possibleIds = [
            historyId,
            String(historyItem.attendanceId || '').trim()
        ].filter(Boolean);

        this.attendanceHistory = this.attendanceHistory.filter(
            h => String(h.id) !== String(id)
        );

        this.attendanceRecords = this.attendanceRecords.filter(
            record =>
                !possibleIds.includes(
                    String(record.attendanceId || '').trim()
                )
        );

        await this.saveDataInBackground();

        alert(
            '✅ Histórico, foto e presenças vinculadas excluídos com sucesso!'
        );

    } catch (error) {
        console.error(error);

        alert(
            '❌ Não foi possível confirmar a exclusão. Os dados anteriores foram mantidos.'
        );

    } finally {
        this.isSavingAttendance = false;
    }
},

cancelAttendanceSelection() {
    this.stopWebcam();

    this.selectedAttendanceStudents = [];
    this.attendancePhoto = null;
    this.selectedAttendanceTurma = '';

    this.showStudentAttendanceModalBox = false;
},

getStudentMonthlyAttendanceStats(studentId, targetDateObj) {
    if (!studentId || !targetDateObj) {
        return {
            attendedCount: 0,
            totalClasses: 0,
            percentage: 0,
            barColor: 'bg-red-500',
            badgeColor: 'text-red-500',
            statusText: 'Sem dados'
        };
    }

    const year = targetDateObj.getFullYear();
    const month = targetDateObj.getMonth();

    const yearMonthStr =
        `${year}-${String(month + 1).padStart(2, '0')}`;

    const studentIdStr = String(studentId);

    const totalClassesSet = new Set();

    this.attendanceRecords.forEach(r => {
        const dateStr = String(r.date || '').split('T')[0];

        if (dateStr.startsWith(yearMonthStr)) {
            totalClassesSet.add(dateStr);
        }
    });

    const attendedClassesSet = new Set();

    this.attendanceRecords.forEach(r => {
        const dateStr = String(r.date || '').split('T')[0];

        if (
            dateStr.startsWith(yearMonthStr) &&
            String(r.studentId) === studentIdStr
        ) {
            attendedClassesSet.add(dateStr);
        }
    });

    const totalClasses = totalClassesSet.size || 1;
    const attendedCount = attendedClassesSet.size;

    const percentage = Math.round(
        (attendedCount / totalClasses) * 100
    );

    let barColor = 'bg-red-500';
    let badgeColor = 'text-red-500';
    let statusText = 'Frequência Baixa (< 50%)';

    if (percentage >= 75) {
        barColor = 'bg-emerald-500';
        badgeColor = 'text-emerald-500';
        statusText = 'Excelente (≥ 75%)';

    } else if (percentage >= 50) {
        barColor = 'bg-amber-500';
        badgeColor = 'text-amber-500';
        statusText = 'Atenção (50% a 74.9%)';
    }

    return {
        attendedCount,
        totalClasses: totalClassesSet.size,
        percentage,
        barColor,
        badgeColor,
        statusText
    };
},

openStudentAttendanceCalendar(student) {
    this.selectedStudentAttendance = student;
    this.selectedStudentAttendanceId = student.id;
    this.showStudentAttendanceCalendarModal = true;
},

// Conta somente alunos, sem incluir visitantes.
todayAttendanceCount() {
    const today = new Date().toISOString().split('T')[0];
    const set = new Set();

    const visitorIds = new Set(
        (this.students || [])
            .filter(s => s && s.personType === 'visitor')
            .map(s => String(s.id))
    );

    this.attendanceRecords.forEach(r => {
        if (
            String(r.date).startsWith(today) &&
            !visitorIds.has(String(r.studentId))
        ) {
            set.add(String(r.studentId));
        }
    });

    return set.size;
},

openAttendanceDashboardModal() {
    const now = new Date();

    this.attendanceDashboardDate = [
        now.getFullYear(),
        String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getDate()).padStart(2, '0')
    ].join('-');

    this.attendanceDashboardTurmaId = 'todas';

    this.showAttendanceDashboardModal = true;

    this.$nextTick(() => {
        if (window.lucide) {
            window.lucide.createIcons();
        }
    });
},

closeAttendanceDashboardModal() {
    this.showAttendanceDashboardModal = false;
},

normalizeDashboardAttendanceDate(value) {
    const raw = String(value || '').trim().split('T')[0];

    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
        return raw;
    }

    const br = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

    if (br) {
        return `${br[3]}-${br[2]}-${br[1]}`;
    }

    return '';
},

get attendanceDashboardTurmas() {
    const selectedDate = this.normalizeDashboardAttendanceDate(
        this.attendanceDashboardDate
    );

    if (!selectedDate) return [];

    const records = Array.isArray(this.attendanceRecords)
        ? this.attendanceRecords
        : [];

    const history = Array.isArray(this.attendanceHistory)
        ? this.attendanceHistory
        : [];

    // Visitantes não participam dos relatórios de alunos.
    const students = Array.isArray(this.students)
        ? this.students.filter(
            student => student && student.personType !== 'visitor'
        )
        : [];

    const turmas = Array.isArray(this.turmas)
        ? this.turmas.filter(Boolean)
        : [];

    const getHistoryStudentIds = item => {
        let ids = item.studentIds || item.students || [];

        if (typeof ids === 'string') {
            try {
                ids = JSON.parse(ids);
            } catch (e) {
                ids = ids
                    .split(',')
                    .map(id => id.trim())
                    .filter(Boolean);
            }
        }

        if (!Array.isArray(ids)) {
            ids = [];
        }

        return ids.map(id => String(id));
    };

    const studentIds = new Set(
        students.map(student => String(student.id))
    );

    const groups = turmas.map(turma => {
        const turmaId = String(turma.id);

        const turmaRecords = records.filter(record =>
            String(record.turmaId || '') === turmaId &&
            this.normalizeDashboardAttendanceDate(
                record.attendanceDate || record.date
            ) === selectedDate &&
            studentIds.has(String(record.studentId))
        );

        const turmaHistory = history.filter(item =>
            String(item.turmaId || '') === turmaId &&
            this.normalizeDashboardAttendanceDate(
                item.attendanceDate || item.date
            ) === selectedDate
        );

        const hasCall =
            turmaRecords.length > 0 ||
            turmaHistory.length > 0;

        const presentIds = new Set(
            turmaRecords.map(record => String(record.studentId))
        );

        turmaHistory.forEach(item => {
            getHistoryStudentIds(item).forEach(id => {
                if (studentIds.has(id)) {
                    presentIds.add(id);
                }
            });
        });

        const turmaStudents = students
            .filter(student =>
                String(student.turmaId || '') === turmaId
            )
            .map(student => ({
                ...student,
                attendanceStatus: presentIds.has(String(student.id))
                    ? 'Presente'
                    : hasCall
                        ? 'Faltou'
                        : 'Sem chamada registrada'
            }))
            .sort((a, b) =>
                String(a.name || '').localeCompare(
                    String(b.name || ''),
                    'pt-BR'
                )
            );

        return {
            id: turma.id,
            name: turma.name || 'Turma sem nome',
            hasCall,
            students: turmaStudents
        };
    });

    const assignedIds = new Set(
        turmas.map(turma => String(turma.id))
    );

    const unassignedStudents = students.filter(student =>
        !assignedIds.has(String(student.turmaId || ''))
    );

    if (unassignedStudents.length) {
        groups.push({
            id: 'sem_turma',
            name: 'Sem turma',
            hasCall: false,
            students: unassignedStudents
                .map(student => ({
                    ...student,
                    attendanceStatus: 'Sem chamada registrada'
                }))
                .sort((a, b) =>
                    String(a.name || '').localeCompare(
                        String(b.name || ''),
                        'pt-BR'
                    )
                )
        });
    }

    if (
        this.attendanceDashboardTurmaId &&
        this.attendanceDashboardTurmaId !== 'todas'
    ) {
        return groups.filter(group =>
            String(group.id) === String(this.attendanceDashboardTurmaId)
        );
    }

    return groups;
},

get attendanceDashboardSummary() {
    const groups = this.attendanceDashboardTurmas;

    let total = 0;
    let present = 0;
    let absent = 0;
    let noCall = 0;

    groups.forEach(group => {
        group.students.forEach(student => {
            total++;

            if (student.attendanceStatus === 'Presente') {
                present++;
            } else if (student.attendanceStatus === 'Faltou') {
                absent++;
            } else {
                noCall++;
            }
        });
    });

    return {
        total,
        present,
        absent,
        noCall
    };
},

toggleAttendanceSelection(studentId) {
    const id = String(studentId);

    if (this.selectedAttendanceStudents.includes(id)) {
        this.selectedAttendanceStudents =
            this.selectedAttendanceStudents.filter(x => x !== id);
    } else {
        this.selectedAttendanceStudents.push(id);
    }
},

// REGISTRA A CHAMADA.
async saveAttendance() {
    if (!this.selectedAttendanceStudents.length) {
        alert('Selecione pelo menos um aluno para confirmar a presença!');
        return;
    }

    if (!confirm(
        `Confirmar presença para a data ${this.attendanceDate}?`
    )) {
        return;
    }

    this.loadingText = 'SALVANDO A CHAMADA...';
    this.isSavingAttendance = true;

    try {
        const chosenDate = String(this.attendanceDate);
        const chosenTurma = String(this.selectedAttendanceTurma || '');

        const historyId =
            'hist_' + Date.now() + '_' +
            Math.random().toString(36).slice(2, 8);

        const attendanceId = this.attendancePhoto
            ? historyId
            : 'att_' + Date.now() + '_' +
                Math.random().toString(36).slice(2, 10);

        const updatedAttendance = [
            ...this.attendanceRecords
        ];

        this.selectedAttendanceStudents.forEach(id => {
            updatedAttendance.push({
                studentId: String(id),
                date: chosenDate,
                turmaId: chosenTurma,
                attendanceId: attendanceId
            });
        });

        this.attendanceRecords = updatedAttendance;

        if (this.attendancePhoto) {
            if (!Array.isArray(this.attendanceHistory)) {
                this.attendanceHistory = [];
            }

            this.attendanceHistory.push({
                id: historyId,
                attendanceId: historyId,
                date: chosenDate,
                turmaId: chosenTurma,
                photo: this.attendancePhoto,
                studentIds: [
                    ...this.selectedAttendanceStudents.map(id => String(id))
                ]
            });
        }

        this.addNotification(
            '📷',
            `Chamada registada (${this.selectedAttendanceStudents.length} alunos) para ${chosenDate}`,
            'attendance'
        );

        await this.saveDataInBackground();

        this.attendancePhoto = null;
        this.selectedAttendanceStudents = [];
        this.selectedAttendanceTurma = '';

        this.showStudentAttendanceModalBox = false;

        alert('✅ Presenças e foto guardadas com sucesso!');

    } catch (error) {
        console.error(error);

        alert(
            '❌ Ocorreu um erro ao salvar a chamada. Os dados anteriores foram mantidos.'
        );

    } finally {
        this.isSavingAttendance = false;
    }
},

openHistoryDetails(item) {
    let ids = item.studentIds || item.students || [];

    if (typeof ids === 'string') {
        try {
            ids = JSON.parse(ids);
        } catch (e) {
            ids = ids
                ? ids.split(',').map(i => i.trim()).filter(Boolean)
                : [];
        }
    }

    if (!Array.isArray(ids)) {
        ids = [];
    }

    const possibleIds = [
        String(item.id || '').trim(),
        String(item.attendanceId || '').trim()
    ].filter(Boolean);

    if (ids.length === 0) {
        ids = this.attendanceRecords
            .filter(record =>
                possibleIds.includes(
                    String(record.attendanceId || '').trim()
                )
            )
            .map(record => String(record.studentId));
    }

    this.selectedHistoryItem = {
        ...item,
        studentIds: ids
    };

    this.showHistoryModal = true;
},

// ALUNOS E VISITANTES DISPONÍVEIS PARA CHAMADA.
get filteredAttendanceStudents() {
    const chosenDate = String(this.attendanceDate);

    const alreadyPresentIds = new Set();

    this.attendanceRecords.forEach(r => {
        const recordDate = String(r.date || '').split('T')[0];

        if (recordDate === chosenDate) {
            alreadyPresentIds.add(String(r.studentId));
        }
    });

    // Inclui alunos ativos e visitantes cadastrados.
    let list = (this.students || []).filter(s =>
        s && (
            s.personType === 'visitor' ||
            s.status === 'Ativo'
        )
    );

    // Visitantes podem participar de qualquer turma.
    if (this.selectedAttendanceTurma) {
        list = list.filter(s =>
            s.personType === 'visitor' ||
            String(s.turmaId) === String(this.selectedAttendanceTurma)
        );
    }

    return list.filter(
        s => !alreadyPresentIds.has(String(s.id))
    );
},

get filteredAttendanceHistory() {
    if (
        !this.attendanceHistory ||
        !Array.isArray(this.attendanceHistory)
    ) {
        return [];
    }

    const targetMonth = String(this.historyFilterMonth || '').trim();
    const targetTurma = String(this.historyFilterTurma || '').trim();

    const filtered = this.attendanceHistory.filter(item => {
        if (!item || !item.date) return false;

        if (targetTurma !== '') {
            const itemTurmaId =
                item.turmaId !== undefined &&
                item.turmaId !== null
                    ? String(item.turmaId)
                    : '';

            if (itemTurmaId !== targetTurma) {
                return false;
            }
        }

        if (targetMonth !== '') {
            const rawDate = String(item.date).trim();
            let matchesMonth = false;

            if (rawDate.includes('-')) {
                matchesMonth = rawDate.startsWith(targetMonth);

            } else if (rawDate.includes('/')) {
                const parts = rawDate.split('/');

                if (parts.length === 3) {
                    const year = parts[2];
                    const month = parts[1].padStart(2, '0');

                    matchesMonth =
                        `${year}-${month}` === targetMonth;
                }
            }

            if (!matchesMonth) return false;
        }

        return true;
    });

    const dateValue = value => {
        const raw = String(value || '').trim().split('T')[0];

        if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
            return new Date(raw + 'T00:00:00').getTime();
        }

        const br = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

        if (br) {
            return new Date(
                `${br[3]}-${br[2]}-${br[1]}T00:00:00`
            ).getTime();
        }

        const parsed = new Date(value).getTime();

        return Number.isFinite(parsed) ? parsed : 0;
    };

    return filtered.sort(
        (a, b) =>
            dateValue(b.date) - dateValue(a.date) ||
            String(b.id || '').localeCompare(
                String(a.id || ''),
                undefined,
                { numeric: true }
            )
    );
},

get studentAttendancePhotosHistory() {
    if (!this.currentUser) return [];

    const studentIdStr = String(this.currentUser.id);
    const studentTurmaId = String(this.currentUser.turmaId || '');

    const filteredAndSorted = this.attendanceHistory
        .filter(h => {
            const itemTurmaId = String(h.turmaId || '');

            if (itemTurmaId && studentTurmaId) {
                return itemTurmaId === studentTurmaId;
            }

            return true;
        })
        .sort((a, b) => new Date(b.date) - new Date(a.date));

    return filteredAndSorted.map(h => {
        const listIds = Array.isArray(h.studentIds)
            ? h.studentIds.map(String)
            : [];

        const isInPhoto = listIds.includes(studentIdStr);

        const hasAttendanceOnDate = this.attendanceRecords.some(r =>
            String(r.studentId) === studentIdStr &&
            String(r.date).split('T')[0] ===
                String(h.date).split('T')[0]
        );

        const isPresent = isInPhoto || hasAttendanceOnDate;

        return { ...h, isPresent };
    });
},

get studentModalAttendanceDays() {
    const year = this.currentCalendarDate.getFullYear();
    const month = this.currentCalendarDate.getMonth();

    const firstDayIndex = new Date(year, month, 1).getDay();
    const totalDays = new Date(year, month + 1, 0).getDate();

    const days = [];
    const attendanceSet = new Set();

    if (this.currentUser) {
        this.attendanceRecords.forEach(r => {
            if (
                String(r.studentId) === String(this.currentUser.id)
            ) {
                attendanceSet.add(
                    String(r.date).split('T')[0]
                );
            }
        });
    }

    for (let i = 0; i < firstDayIndex; i++) {
        days.push({
            dayNumber: '',
            isCurrentMonth: false
        });
    }

    for (let i = 1; i <= totalDays; i++) {
        const dateStr =
            `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;

        const isPresent = attendanceSet.has(dateStr);

        days.push({
            dayNumber: i,
            isCurrentMonth: true,
            date: dateStr,
            isPresent
        });
    }

    return days;
},

async startWebcam(target) {
    this.webcamTarget = target;
    this.showWebcamModal = true;

    try {
        this.webcamStream =
            await navigator.mediaDevices.getUserMedia({
                video: true
            });

        document.getElementById('webcamVideo').srcObject =
            this.webcamStream;

    } catch (e) {
        alert('Não foi possível aceder à câmara.');
        this.showWebcamModal = false;
    }
},

stopWebcam() {
    if (this.webcamStream) {
        this.webcamStream.getTracks().forEach(t => t.stop());
    }

    this.showWebcamModal = false;
},

captureWebcam() {
    const video = document.getElementById('webcamVideo');

    const canvas = document.createElement('canvas');

    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    canvas.getContext('2d').drawImage(video, 0, 0);

    this.compressImage(
        canvas.toDataURL('image/jpeg', 0.8),
        url => {
            if (this.webcamTarget === 'student') {
                this.studentForm.photo = url;
            } else if (this.webcamTarget === 'student_edit') {
                this.studentProfileForm.photo = url;
            } else if (this.webcamTarget === 'admin_profile') {
                this.adminProfileData.photo = url;
            } else if (this.webcamTarget === 'teacher_profile') {
                this.teacherProfileForm.photo = url;
            } else if (this.webcamTarget === 'attendance') {
                this.attendancePhoto = url;
            } else if (this.webcamTarget === 'history_edit') {
                this.editingHistoryForm.photo = url;
            }
        }
    );

    this.stopWebcam();
}

};
};

