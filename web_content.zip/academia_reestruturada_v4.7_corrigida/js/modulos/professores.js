// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.teachers = function () { return {
initTeacherProfile() {
            if (this.currentUser && this.userRole === 'teacher') {
                this.teacherProfileForm = {
                    name: this.currentUser.name || '',
                    phone: this.currentUser.phone || '',
                    email: this.currentUser.email || '',
                    password: this.currentUser.password || '',
                    photo: this.currentUser.photo || '',
                    belt: this.currentUser.belt || '',
                    bio: this.currentUser.bio || '',               // <-- Essencial para a bio carregar
                    specialty: this.currentUser.specialty || ''     // <-- Essencial para a especialidade carregar
                };
            }
        },
async saveTeacherProfile() {
          if (!this.currentUser) return;
          const idx = this.teachers.findIndex(t => String(t.id) === String(this.currentUser.id));
          if (idx !== -1) {
            this.teachers[idx] = { ...this.teachers[idx], ...this.teacherProfileForm };
            this.currentUser = { ...this.teachers[idx] };
            await this.saveDataInBackground();
            alert('✅ Perfil do professor atualizado com sucesso!');
          }
        },
openNewTeacherModal() { 
          this.teacherForm = { id: null, name: '', phone: '', email: '', password: '', photo: '', bio: '', belt: 'Preta', specialty: '' }; 
          this.showTeacherModal = true; 
        },
openEditTeacherModal(t) {
          this.teacherForm = JSON.parse(JSON.stringify(t));
          this.showTeacherModal = true;
        },
async saveTeacher() {
          const teacherObj = {
            id: this.teacherForm.id || ('t_' + Date.now()),
            name: this.teacherForm.name || '',
            phone: this.teacherForm.phone || '',
            email: this.teacherForm.email || '',
            password: this.teacherForm.password || '',
            photo: this.teacherForm.photo || '',
            bio: this.teacherForm.bio || '',
            belt: this.teacherForm.belt || 'Preta',
            specialty: this.teacherForm.specialty || ''
          };

          if (this.teacherForm.id) {
            const idx = this.teachers.findIndex(t => t.id === this.teacherForm.id);
            if (idx !== -1) this.teachers[idx] = teacherObj;
          } else {
            this.teachers.push(teacherObj);
          }
          await this.saveDataInBackground();
          this.showTeacherModal = false;
          alert('✅ Professor guardado com sucesso!');
        },
async deleteTeacher(id) { 
          if (confirm('Tem certeza que deseja excluir este professor?')) {
            this.teachers = this.teachers.filter(t => t.id !== id); 
            await this.saveDataInBackground(); 
            alert('✅ Professor excluído!');
          }
        },
async saveTeacherWorkout() {
          if (!this.currentUser || this.userRole !== 'teacher') return;
          if (!this.newTeacherWorkout.title.trim() || !this.newTeacherWorkout.content.trim()) {
            alert('Preencha o título e o conteúdo do treino!');
            return;
          }

          if (!Array.isArray(this.currentUser.teacherWorkouts)) {
            this.currentUser.teacherWorkouts = [];
          }

          // Adiciona o novo treino no topo da lista
          this.currentUser.teacherWorkouts.unshift({
            id: 'tw_' + Date.now(),
            title: this.newTeacherWorkout.title,
            content: this.newTeacherWorkout.content
          });

          // Atualiza a lista geral de professores
          const idx = this.teachers.findIndex(t => String(t.id) === String(this.currentUser.id));
          if (idx !== -1) {
            this.teachers[idx] = JSON.parse(JSON.stringify(this.currentUser));
          }

          // Limpa o formulário e salva
          this.newTeacherWorkout = { title: '', content: '' };
          await this.saveDataInBackground();
          alert('✅ Plano de treino guardado com sucesso!');
        },
async deleteTeacherWorkout(workoutId) {
          if (!confirm('Deseja excluir este plano de treino?')) return;
          
          this.currentUser.teacherWorkouts = this.currentUser.teacherWorkouts.filter(w => w.id !== workoutId);

          const idx = this.teachers.findIndex(t => String(t.id) === String(this.currentUser.id));
          if (idx !== -1) {
            this.teachers[idx] = JSON.parse(JSON.stringify(this.currentUser));
          }

          await this.saveDataInBackground();
          alert('✅ Plano de treino excluído!');
        }
}; };
