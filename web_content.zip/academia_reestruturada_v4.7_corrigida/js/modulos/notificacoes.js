// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.notifications = function () { return {
addNotification(icon, text, targetTab) {
          const newNotif = { id: Date.now(), icon, text, targetTab, read: false, time: 'Agora' };
          this.notifications.unshift(newNotif);
          this.saveDataLocally();
        },
get unreadNotificationsCount() { return this.notifications.filter(n => !n.read).length; },
markAllNotificationsRead() { this.notifications.forEach(n => n.read = true); this.saveDataLocally(); },
handleNotificationClick(notif) { notif.read = true; this.saveDataLocally(); if (notif.targetTab) { this.adminTab = notif.targetTab; } },
async sendBroadcast() {
          const activesBeforeSync = this.activeStudents;
          if (activesBeforeSync.length === 0) { alert('Nenhum aluno ativo.'); return; }
          if (!confirm(`Deseja disparar esta mensagem via WhatsApp para ${activesBeforeSync.length} alunos ativos?`)) return;

          // Mesmo sendo uma ação externa, só prossegue depois de confirmar que os dados
          // usados para o disparo foram atualizados a partir da planilha.
          this.isSavingData = true;
          this.savingMessage = 'Atualizando os dados antes de continuar...';
          try {
            await this.syncWithGoogleSheets(true);
            if (!this._serverReady || !this.isOnline) {
              throw new Error('Não foi possível confirmar a sincronização com a planilha.');
            }
          } catch (error) {
            console.error(error);
            alert('❌ Não foi possível sincronizar com a planilha. O envio pelo WhatsApp foi cancelado.');
            return;
          } finally {
            this.isSavingData = false;
          }

          const actives = this.activeStudents;
          actives.forEach((s, idx) => {
            const phone = String(s.phone || '').replace(/\D/g, '');
            if (phone) {
              setTimeout(() => {
                window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(this.broadcastMessage)}`, '_blank');
              }, idx * 800);
            }
          });
          alert('✅ Disparos iniciados!');
        }
}; };
