// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.classes = function () { return {
async createTurma() {
          if (!this.newTurmaName) return;
          this.turmas.push({ id: 'turma_' + Date.now(), name: this.newTurmaName });
          this.newTurmaName = '';
          await this.saveDataInBackground();
          alert('✅ Turma criada com sucesso!');
        },
openEditTurmaModal(t) {
          this.turmaForm = JSON.parse(JSON.stringify(t));
          this.showTurmaModal = true;
        },
async saveTurma() {
          if (this.turmaForm.id && this.turmaForm.name) {
            const idx = this.turmas.findIndex(t => t.id === this.turmaForm.id);
            if (idx !== -1) {
              this.turmas[idx].name = this.turmaForm.name;
              await this.saveDataInBackground();
              alert('✅ Turma atualizada com sucesso!');
            }
          }
          this.showTurmaModal = false;
        },
async deleteTurma(id) {
          if (confirm('Tem certeza que deseja excluir esta turma?')) {
            this.turmas = this.turmas.filter(t => t.id !== id);
            await this.saveDataInBackground();
            alert('✅ Turma excluída!');
          }
        },
getTurmaName(id) {
          const t = this.turmas.find(x => x.id === id);
          return t ? t.name : 'Geral';
        },
// Vazio = Todas as turmas

        get safeTurmas() {
            return Array.isArray(this.turmas) ? this.turmas.filter(t => t && t.id) : [];
        }
}; };
