// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.dashboard = function () { return {
// ----------------------------------------------------
        // 2. COMPUTADA PARA O DASHBOARD (GRÁFICOS DEMOGRÁFICOS)
        // ----------------------------------------------------
        get advancedDashboardStats() {
            const students = Array.isArray(this.students) ? this.students.filter(s => s !== null) : [];
            const turmas = Array.isArray(this.turmas) ? this.turmas.filter(t => t !== null) : [];

            // Mapeamento de turmas
            const turmaCounts = {};
            turmas.forEach(t => turmaCounts[t.id] = { name: t.name, count: 0 });
            turmaCounts['sem_turma'] = { name: 'Sem Turma', count: 0 };

            let maleCount = 0;
            let femaleCount = 0;
            const ageGroupsCount = { 'Infantil (< 14)': 0, 'Juvenil (14-17)': 0, 'Adulto (18-35)': 0, 'Master (36+)': 0 };
            const currentYear = new Date().getFullYear();

            students.forEach(s => {
                // Contagem por Turma
                const tId = s.turmaId && turmaCounts[s.turmaId] ? s.turmaId : 'sem_turma';
                turmaCounts[tId].count++;

                // Contagem por Sexo
                const g = String(s.gender || s.sexo || '').toLowerCase();
                if (g.includes('m') || g.includes('masculino')) maleCount++;
                else femaleCount++;

                // Cálculo de Idade
                let age = parseInt(s.age || s.idade || 0);
                if (!age && s.birthDate) {
                    const bYear = new Date(s.birthDate).getFullYear();
                    if (!isNaN(bYear)) age = currentYear - bYear;
                }

                if (age > 0) {
                    if (age < 14) ageGroupsCount['Infantil (< 14)']++;
                    else if (age <= 17) ageGroupsCount['Juvenil (14-17)']++;
                    else if (age <= 35) ageGroupsCount['Adulto (18-35)']++;
                    else ageGroupsCount['Master (36+)']++;
                }
            });

            // Barras de Porcentagem (Turmas)
            const maxTurma = Math.max(...Object.values(turmaCounts).map(i => i.count), 1);
            const turmaBreakdown = Object.values(turmaCounts).map(i => ({
                name: i.name,
                count: i.count,
                percent: Math.round((i.count / maxTurma) * 100)
            }));

            // Barras de Porcentagem (Sexo)
            const totalGen = (maleCount + femaleCount) || 1;
            const genderBreakdown = [
                { label: 'Masculino', count: maleCount, percent: Math.round((maleCount / totalGen) * 100) },
                { label: 'Feminino', count: femaleCount, percent: Math.round((femaleCount / totalGen) * 100) }
            ];

            // Barras de Porcentagem (Idade)
            const totalAge = Object.values(ageGroupsCount).reduce((a, b) => a + b, 0) || 1;
            const ageBreakdown = Object.keys(ageGroupsCount).map(cat => ({
                category: cat,
                count: ageGroupsCount[cat],
                percent: Math.round((ageGroupsCount[cat] / totalAge) * 100)
            }));

            return {
                turmaBreakdown,
                genderBreakdown,
                ageBreakdown
            };
        }
}; };
