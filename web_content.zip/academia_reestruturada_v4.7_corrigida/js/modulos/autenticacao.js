// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.auth = function () { return {
async savePermissions() {
          await this.saveDataInBackground();
          alert('✅ Permissões de acesso atualizadas com sucesso e salvas na coluna A3!');
        },
executeEmailRecovery() {
          const email = String(this.recoveryEmailInput || '').trim().toLowerCase();
          if (!email) return;

          const adminEmail = String(this.adminProfileData.email || '').trim().toLowerCase();
          if (email === adminEmail) {
            this.recoveryResultMsg = `Administrador encontrado! A sua palavra-passe é: ${this.adminPassword}`;
            return;
          }

          const teacher = this.teachers.find(t => String(t.email || '').toLowerCase() === email);
          if (teacher) {
            this.recoveryResultMsg = `Professor encontrado (${teacher.name})! A palavra-passe é: ${teacher.password}`;
            return;
          }

          const student = this.students.find(s => String(s.email || '').toLowerCase() === email);
          if (student) {
            this.recoveryResultMsg = `Atleta encontrado (${student.name})! A palavra-passe é: ${student.password || '123456'}`;
            return;
          }

          this.recoveryResultMsg = 'E-mail não encontrado no sistema.';
        },
executeLogin() {
          this.loginError = false;
          const input = String(this.loginInput || '').trim().toLowerCase();
          const pass = String(this.loginPassword || '').trim();
          if (!input || !pass) { this.loginError = true; return; }

          const adminEmail = String(this.adminProfileData.email || '').trim().toLowerCase();
          if ((input === 'admin' || input === 'master' || input === adminEmail) && pass === String(this.adminPassword).trim()) {
            this.userRole = 'admin';
            this.adminTab = 'dashboard';
            this.currentUser = { name: this.adminProfileData.name };
            this.loginInput = ''; this.loginPassword = '';
            
            return;
          }

          const teacher = this.teachers.find(t => String(t.email || '').toLowerCase() === input && String(t.password || '') === pass);
          if (teacher) {
            this.userRole = 'teacher';
            this.adminTab = 'students';
            this.currentUser = teacher;
            this.initTeacherProfile();
            this.loginInput = ''; this.loginPassword = '';
            
            return;
          }

          const student = this.students.find(s => String(s.email || '').toLowerCase() === input && String(s.password || '123456') === pass);
          if (student) {
            this.userRole = 'student';
            this.currentUser = student;
            this.loginInput = ''; this.loginPassword = '';
            
            return;
          }
          this.loginError = true;
        },
logout() { 
          this.userRole = 'guest'; 
          this.currentUser = null; 
          this.currentScreen = 'login'; 
          localStorage.removeItem('acad_saved_role');
          localStorage.removeItem('acad_saved_user');
          localStorage.removeItem('acad_saved_admintab');
        },
getRoleDescription() { return this.userRole === 'admin' ? 'Painel Admin' : (this.userRole === 'teacher' ? 'Área do Professor' : 'Portal do Atleta'); }
}; };
