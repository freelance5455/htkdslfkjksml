// Módulo extraído do código original. Não alterar a lógica durante a migração.
window.GYM_MODULES = window.GYM_MODULES || {};
window.GYM_MODULES.plans = function () { return {
calculatePaymentStatus(student) {
    const paid = { label: 'MENSALIDADE PAGO', class: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30' };
    const pending = { label: 'MENSALIDADE PENDENTE', class: 'bg-red-500/10 text-red-500 border-red-500/30 animate-pulse' };

    // A cobrança possui somente dois estados: pago ou pendente.
    return student && String(student.paymentStatus || '').trim().toLowerCase() === 'pago'
      ? paid
      : pending;
},
openEditDueDayModal(student) {
          this.editingDueDayStudent = student;
          this.newDueDayValue = student.dueDay || 10;
          this.showDueDayModal = true;
        },
async saveDueDay() {
          if (this.editingDueDayStudent && this.newDueDayValue) {
            const idx = this.students.findIndex(s => s.id === this.editingDueDayStudent.id);
            if (idx !== -1) {
              this.students[idx].dueDay = Number(this.newDueDayValue);
              await this.saveDataInBackground();
              alert('✅ Dia de vencimento atualizado!');
            }
          }
          this.showDueDayModal = false;
        },
async confirmPaymentChange(s) {
    const novoStatus = s.paymentStatus === 'Pago' ? 'Pendente' : 'Pago';
    const labelStatus = novoStatus === 'Pago' ? 'MENSALIDADE PAGO' : 'MENSALIDADE PENDENTE';

    // Pede confirmação antes de alterar
    if (confirm(`Deseja alterar o status de pagamento de ${s.name} para ${labelStatus}?`)) {
        try {
            // A tela global de sincronização bloqueia novas ações até a confirmação.
            // Altera o status temporariamente
            s.paymentStatus = novoStatus;

            // Salva de forma assíncrona na planilha
            await this.saveDataInBackground();

            this.addNotification('💳', `Status de ${s.name} atualizado com sucesso!`, 'payments');
        } catch (error) {
            console.error(error);
            // Reverte o status se der erro ao salvar
            s.paymentStatus = (novoStatus === 'Pago' ? 'Pendente' : 'Pago');
            alert('❌ Ocorreu um erro ao atualizar o status na planilha.');
        } finally {
            // O serviço reaplica os objetos confirmados; localiza novamente o aluno.
            const currentStudent = this.students.find(student => String(student.id) === String(s.id));
            if (currentStudent) delete currentStudent.isUpdating;
        }
    }
},
openNewPlanModal() { 
          this.planForm = { id: null, name: '', price: '', modality: 'Geral' }; 
          this.showPlanModal = true; 
        },
editPlan(p) {
          this.planForm = JSON.parse(JSON.stringify(p));
          this.showPlanModal = true;
        },
async savePlan() {
          if (this.planForm.id) {
            const idx = this.plans.findIndex(p => p.id === this.planForm.id);
            if (idx !== -1) this.plans[idx] = { ...this.planForm };
          } else {
            this.plans.push({ ...this.planForm, id: 'p_' + Date.now() });
          }
          await this.saveDataInBackground();
          this.showPlanModal = false;
          alert('✅ Plano guardado com sucesso!');
        },
async deletePlan(id) { 
          if (confirm('Deseja realmente excluir este plano?')) {
            this.plans = this.plans.filter(p => p.id !== id); 
            await this.saveDataInBackground(); 
            alert('✅ Plano excluído!');
          }
        },
countPendingPayments() { return this.students.filter(s => this.calculatePaymentStatus(s).label === 'MENSALIDADE PENDENTE').length; },
getPlanName(id) {
          if (!id || !Array.isArray(this.plans)) return 'Sem Plano';
          const p = this.plans.find(x => x && (String(x.id) === String(id) || String(x.name) === String(id)));
          return p ? p.name : 'Sem Plano';
        },
getPlanPrice(id) {
          if (!id || !Array.isArray(this.plans)) return 0;
          const p = this.plans.find(x => x && (String(x.id) === String(id) || String(x.name) === String(id)));
          return p ? (p.price || 0) : 0;
        }
}; };
