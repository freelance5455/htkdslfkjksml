# Academia — projeto reestruturado

## Estrutura
- `index.html`: documento principal, telas e ponto central de carregamento.
- `css/style.css`: regra CSS originalmente embutida para `[x-cloak]`.
- `js/app.js`: composição central do objeto `gymApp()` usado pelo Alpine.js.
- `js/config/`: configuração e estado inicial.
- `js/modulos/`: funcionalidades separadas por área.
- `js/servicos/`: persistência e sincronização.
- `assets/`: diretórios preparados para imagens e ícones.

## Como executar
Abra `index.html` por um servidor HTTP/HTTPS ou publique a pasta inteira no mesmo local onde o sistema era hospedado. Não mova apenas o `index.html`: os arquivos CSS e JavaScript externos precisam permanecer nas pastas indicadas.

## Compatibilidade
O HTML das telas foi mantido. Os métodos foram distribuídos em fábricas de módulos e mesclados no `gymApp()` central por descritores de propriedades, preservando getters/setters e o uso de `this` pelo Alpine.js. O código usa bibliotecas CDN como na versão original.

## Observações da migração
- Nenhuma tela ou classe visual do HTML foi redesenhada.
- O método `initApp()` aparecia duas vezes no objeto original; a duplicidade foi mantida dentro do módulo de núcleo, com a mesma regra JavaScript de prevalência da última definição.
- A URL do Google Apps Script foi movida para `js/config/config.js`.
- Recomenda-se testar login, logout, permissões, cadastro/edição, frequência, fotos, modais e sincronização com Google Sheets no ambiente real antes de substituir a versão publicada.


## Salvamento local e sincronização em segundo plano
- `saveDataInBackground()` aguarda a confirmação do servidor antes de considerar a alteração concluída. Durante esse processo, a interface fica bloqueada com uma tela de sincronização; se o servidor não confirmar, os dados anteriores são restaurados.
- A última fotografia completa dos dados fica em `acad_sync_pending` até o navegador concluir o envio.
- Falhas de rede mantêm a pendência e o sistema tenta novamente a cada 5 segundos.
- Enquanto houver pendência local, a leitura periódica da planilha não substitui os dados atuais do navegador.
- O envio atual usa `mode: no-cors`, por compatibilidade com a integração existente. Nesse modo o navegador não permite ler a confirmação do Google Apps Script; portanto, o término do `fetch` indica que o navegador concluiu o envio, mas não comprova que o script gravou tudo. Para confirmação forte de gravação, também será necessário ajustar o projeto Google Apps Script para retornar um identificador/recibo e aceitar esse identificador de forma idempotente.
- O armazenamento local do navegador não substitui backup externo: limpar os dados do navegador, trocar de aparelho ou atingir a cota de armazenamento pode afetar a cópia local.


## Regra de vencimento da mensalidade

Na aba **Cobranças**, existem somente dois estados: **MENSALIDADE PENDENTE** e **MENSALIDADE PAGO**. Qualquer aluno cujo campo `paymentStatus` esteja como `Pago` aparece como pago; os demais aparecem como pendentes.


## Ordem do histórico de chamadas (v3)
- As novas chamadas são acrescentadas ao final da lista interna.
- Antes de enviar o histórico ao Google Sheets, o sistema ordena os registros do mais antigo para o mais recente; assim, a chamada nova aparece abaixo das anteriores.
- Na tela do sistema, o histórico continua exibindo as chamadas mais recentes primeiro.
- Esta alteração não exige mudança no `Code.gs`: a função `saveSheetData()` já grava as linhas na mesma ordem recebida.

## Observação importante sobre confirmação de sincronização
Esta versão corrige a ordem do histórico, mas mantém o mecanismo de sincronização da v2. Como ele usa `fetch` com `mode: 'no-cors'`, o navegador ainda não consegue ler a confirmação de gravação do Apps Script. Portanto, não considere esta atualização como a implementação da confirmação segura de todas as gravações. Para isso, será necessário alterar e testar também a comunicação entre a página publicada e o Web App do Apps Script, antes de substituir a versão atualmente em uso.


## Atualização v4 — gravação confirmada no Google Sheets

- O carregamento inicial passa a usar a planilha como fonte oficial; os dados de negócio não são restaurados do cache do navegador.
- Ao editar, o sistema mantém a versão confirmada visível e só aplica a alteração depois de receber um recibo de sucesso do Apps Script. Em falha ou falta de confirmação, restaura os dados anteriores.
- O envio usa POST `text/plain` e consulta o recibo por JSONP, evitando depender da leitura de uma resposta CORS opaca.
- O Apps Script serializa gravações com `LockService` e registra recibos de sucesso/erro.
- Histórico de chamadas continua sendo gravado em ordem cronológica crescente na planilha e exibido do mais recente para o mais antigo na interface.
- A regra de vencimento permanece: em dia até o próprio vencimento; pendente a partir do dia seguinte; dias 29–31 são ajustados ao último dia válido do mês.

### Instalação obrigatória do backend

1. Abra o projeto do Google Apps Script vinculado à planilha.
2. Substitua todo o conteúdo do arquivo `Code.gs` pelo conteúdo do arquivo `Code.gs.txt` entregue junto deste pacote.
3. Salve e publique uma **nova versão** da implantação do Aplicativo da Web, mantendo as permissões de acesso que já eram usadas pelo sistema.
4. Atualize o site com todos os arquivos desta pasta, não apenas o `index.html`.
5. Teste primeiro com uma alteração simples e confira se ela aparece na planilha antes de continuar usando o sistema.

**Importante:** a confirmação depende de atualizar o Apps Script e o site em conjunto. A validação feita aqui foi de sintaxe dos arquivos JavaScript; não foi possível executar um teste real na sua planilha/implantação. O `LockService` evita gravações simultâneas no servidor, mas o sistema ainda envia o conjunto completo de dados; para vários usuários editando ao mesmo tempo, uma futura evolução para gravações por registro seria mais segura contra sobrescritas entre dispositivos.
