# Quran Recitation — Android APK

**Contact:** Shanavas ch · 9072598909 · Malappuram, Edakkara

## APK ഉണ്ടാക്കാൻ (Android Studio)

1. [Android Studio](https://developer.android.com/studio) ഇൻസ്റ്റാൾ ചെയ്യുക
2. **Open** → ഈ ഫോൾഡർ തിരഞ്ഞെടുക്കുക (`quran-recitation-apk`)
3. `local.properties` ൽ SDK path സെറ്റ് ചെയ്യുക (Studio സാധാരണയായി ഓട്ടോ ചെയ്യും)
4. മുകളിൽ **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK ലൊക്കേഷൻ: `app/build/outputs/apk/debug/app-debug.apk`

### Release APK (പ്ലേ സ്റ്റോർ / ഷെയർ)
**Build → Generate Signed Bundle / APK** → APK → keystore ഉണ്ടാക്കുക

## Requirements
- Android Studio Hedgehog (2023.1+) അല്ലെങ്കിൽ പുതിയത്
- JDK 17
- Internet (ഓഡിയോ + മലയാള അർത്ഥം API-ക്ക്)

## App ID
`com.shanavas.quranrecitation`
