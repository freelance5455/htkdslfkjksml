# Quran Recitation — Android App (v1.1)

**Contact:** Shanavas ch · 9072598909 · Malappuram, Edakkara

## Contents
- Latest web UI (`app/src/main/assets/index.html`)
- Android WebView project ready for Android Studio

## Build APK
1. Install [Android Studio](https://developer.android.com/studio)
2. **Open** this folder (`quran-recitation-apk`)
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. Output: `app/build/outputs/apk/debug/app-debug.apk`

## Features
- Arabic recitation (ayah by ayah · Mishary)
- Malayalam recitation (full surah · male)
- Surah-level progress bar + seek
- Bottom player: ±10s, volume, speed
- Malayalam meaning, word-by-word options

## App ID
`com.shanavas.quranrecitation`
