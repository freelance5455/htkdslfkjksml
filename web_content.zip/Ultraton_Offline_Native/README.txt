ULTRATON — NATIVE OFFLINE AI PROTOTYPE

WHAT IT DOES
- Keeps Divyansh's original Ultraton HTML interface and built-in knowledge/fun commands.
- Adds a native llama.cpp inference engine. ALL normal text questions are sent directly to the on-device model; the old knowledge-book matcher is not used as the chat answer path.
- Blocks WebView network loads and removes the online MobileNet download path.
- The GGUF model is packaged in APK assets, then copied to app-private storage on first launch.
- No internet, API key, account, or model download is required after the APK is built and installed.

MODEL
SmolLM2-360M-Instruct, GGUF Q4_K_M. Published model listing reports about 271 MB.
File expected at: app/src/main/assets/models/model.gguf
On your internet-connected PC, run from this project folder:
    python scripts/download_model.py

The model binary is NOT included in this source ZIP because this build workspace could not connect to Hugging Face to fetch the 271 MB file. Run the script on your PC before building. Once the model is inside assets and the APK is built, the installed app can run without internet.

BUILD ON PC
1. Install Android Studio with Android SDK Platform 35, Android NDK, and CMake 3.22.1.
2. Install Python 3.
3. Run: python scripts/download_model.py
4. Open this folder in Android Studio (the folder containing settings.gradle).
5. Allow Gradle sync. On the first build, CMake fetches llama.cpp source from GitHub. This is build-time only.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Install app/build/outputs/apk/debug/app-debug.apk. Turn on airplane mode and test questions.

PREVIEW NOTE
The HTML file preview is not the Android native runtime. It deliberately shows a clear message instead of answering from the old knowledge book. To test generated answers, build and install the Android APK with model.gguf bundled.

IMPORTANT LIMITS / TEST STATUS
- This is a prototype source project, not a tested APK. This environment has no Android SDK/NDK or Gradle installed, so a real Android build could not be run here.
- Configured for arm64-v8a devices, Android 8.0+. With 4 GB RAM, performance may be slow and Android may close the app under memory pressure.
- 400 MB is a target, not a verified final APK size. The model alone is about 271 MB; native libraries and packaging add more. Check final APK size. If it exceeds 400 MB, use the Q3_K_M model variant and update the filename/download URL.
- Small models can make mistakes and are primarily English-focused. They are much less capable than ChatGPT.
- Live news and cloud-based photo classification are unavailable offline. The original pixel-based photo analysis and local commands remain.

MODEL / RUNTIME REFERENCES
- Model card: https://huggingface.co/bartowski/SmolLM2-360M-Instruct-GGUF
- llama.cpp Android guide: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- Check model and runtime license notices before redistributing a built APK. SmolLM2 is published under Apache-2.0; llama.cpp is MIT licensed.
