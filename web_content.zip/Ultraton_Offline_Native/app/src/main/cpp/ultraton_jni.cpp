#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <android/log.h>
#include "llama.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "UltratonAI", __VA_ARGS__)
static std::mutex g_mutex;
static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static const llama_vocab * g_vocab = nullptr;

static std::string jstr(JNIEnv *env, jstring value) {
    if (!value) return {};
    const char *p = env->GetStringUTFChars(value, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(value, p);
    return out;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_ultraton_app_MainActivity_nativeInit(JNIEnv *env, jobject, jstring modelPath) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx && g_model) return JNI_TRUE;
    std::string path = jstr(env, modelPath);
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0; // CPU path for broad Android compatibility
    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) { LOGE("Could not load model: %s", path.c_str()); return JNI_FALSE; }
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 1024;
    cp.n_batch = 256;
    cp.n_threads = 4;
    cp.n_threads_batch = 4;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { llama_model_free(g_model); g_model = nullptr; return JNI_FALSE; }
    g_vocab = llama_model_get_vocab(g_model);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ultraton_app_MainActivity_nativeGenerate(JNIEnv *env, jobject, jstring promptText) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_ctx || !g_model || !g_vocab) return env->NewStringUTF("Offline AI is not ready yet. Please restart Ultraton.");
    std::string prompt = "<|im_start|>system\nYou are Ultraton, a friendly helpful assistant. Give clear, short, age-appropriate answers. If unsure, say so.\n<|im_end|>\n<|im_start|>user\n" + jstr(env, promptText) + "\n<|im_end|>\n<|im_start|>assistant\n";
    std::vector<llama_token> tokens(prompt.size() + 16);
    int n = llama_tokenize(g_vocab, prompt.c_str(), (int)prompt.size(), tokens.data(), (int)tokens.size(), true, true);
    if (n < 0) { tokens.resize((size_t)(-n)); n = llama_tokenize(g_vocab, prompt.c_str(), (int)prompt.size(), tokens.data(), (int)tokens.size(), true, true); }
    if (n <= 0) return env->NewStringUTF("I couldn't process that question. Try asking it another way.");
    tokens.resize((size_t)n);
    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_batch batch = llama_batch_get_one(tokens.data(), (int)tokens.size());
    if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("I ran out of memory for that question. Try a shorter one.");
    llama_sampler * sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.90f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.70f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    std::string answer;
    for (int i = 0; i < 160; ++i) {
        llama_token tok = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, tok)) break;
        char piece[256];
        int len = llama_token_to_piece(g_vocab, tok, piece, sizeof(piece), 0, true);
        if (len > 0) answer.append(piece, (size_t)len);
        batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
    }
    llama_sampler_free(sampler);
    if (answer.empty()) answer = "I couldn't form an answer. Please try again.";
    return env->NewStringUTF(answer.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_ultraton_app_MainActivity_nativeRelease(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_vocab = nullptr;
}
