package com.ultraton.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private final ExecutorService aiExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean nativeAvailable = false;

    static { try { System.loadLibrary("ultraton_native"); } catch (Throwable ignored) {} }
    private native boolean nativeInit(String modelPath);
    private native String nativeGenerate(String prompt);
    private native void nativeRelease();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBlockNetworkLoads(true);
        webView.addJavascriptInterface(new UltratonBridge(), "UltratonAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return assetLoader.shouldInterceptRequest(r.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        aiExecutor.execute(() -> {
            try {
                File model = new File(getFilesDir(), "model.gguf");
                if (!model.exists() || model.length() < 100_000_000L) {
                    try (InputStream in = getAssets().open("models/model.gguf"); FileOutputStream out = new FileOutputStream(model)) {
                        byte[] buf = new byte[1024 * 1024]; int n;
                        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    }
                }
                nativeAvailable = nativeInit(model.getAbsolutePath());
                runOnUiThread(() -> Toast.makeText(this, nativeAvailable ? "Ultraton offline AI is ready" : "Offline AI could not load", Toast.LENGTH_LONG).show());
            } catch (Throwable e) {
                runOnUiThread(() -> Toast.makeText(this, "Offline model missing. Rebuild with model.gguf included.", Toast.LENGTH_LONG).show());
            }
        });
    }

    private class UltratonBridge {
        @JavascriptInterface public void ask(String prompt, String requestId) {
            aiExecutor.execute(() -> {
                String result;
                try { result = nativeAvailable ? nativeGenerate(prompt) : "Offline AI is still loading. Please wait a moment and try again."; }
                catch (Throwable e) { result = "Sorry, the offline AI had a problem. Try a shorter question."; }
                final String answer = result;
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript("window.onUltratonAIResult && window.onUltratonAIResult(" + org.json.JSONObject.quote(requestId) + "," + org.json.JSONObject.quote(answer) + ")", null);
                });
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("UltratonAndroid"); webView.destroy(); }
        aiExecutor.execute(() -> { try { nativeRelease(); } catch (Throwable ignored) {} });
        aiExecutor.shutdown();
        super.onDestroy();
    }
}
