#!/usr/bin/env python3
"""Download the pinned SmolLM2 GGUF model into the Android assets folder."""
from pathlib import Path
from urllib.request import Request, urlopen

URL = "https://huggingface.co/bartowski/SmolLM2-360M-Instruct-GGUF/resolve/main/SmolLM2-360M-Instruct-Q4_K_M.gguf"
OUT = Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "assets" / "models" / "model.gguf"
OUT.parent.mkdir(parents=True, exist_ok=True)
if OUT.exists() and OUT.stat().st_size > 100_000_000:
    print(f"Model already present: {OUT} ({OUT.stat().st_size:,} bytes)")
    raise SystemExit(0)
print("Downloading model once for APK packaging. Internet is needed only on the build computer.")
req = Request(URL, headers={"User-Agent": "Ultraton-Offline-Builder/1.0"})
with urlopen(req, timeout=60) as response, OUT.open("wb") as f:
    total = int(response.headers.get("Content-Length", "0")); done = 0
    while True:
        chunk = response.read(1024 * 1024)
        if not chunk: break
        f.write(chunk); done += len(chunk)
        if total: print(f"\r{done/total:.1%}", end="", flush=True)
print(f"\nSaved {OUT} ({OUT.stat().st_size:,} bytes)")
