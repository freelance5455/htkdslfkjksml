/* JOSTECH — BADGES DE RÉUSSITE & TÉLÉCHARGEMENT HORS LIGNE */
function computeUserBadges() {
  const done = typeof getCompletedLessons === "function" ? getCompletedLessons() : [];
  const hist = typeof getQuizHistory === "function" ? getQuizHistory() : [];
  const favs = typeof getFavorites === "function" ? getFavorites() : [];
  const labUsed = localStorage.getItem("jostech_lab_used") === "1";
  const avg = typeof getOverallAverage20 === "function" ? Number(getOverallAverage20() || 0) : 0;
  return [
    { icon: "🥉", name: "Premier Pas", ok: done.length >= 1, desc: "Lire 1 leçon" },
    { icon: "📘", name: "Lecteur Assidu", ok: done.length >= 4, desc: "Lire 4 leçons" },
    { icon: "✅", name: "Examen Réussi", ok: hist.some(h => h.score20 >= 10), desc: "Note ≥ 10/20" },
    { icon: "🎓", name: "Excellence", ok: hist.length > 0 && avg >= 16, desc: "Moyenne ≥ 16/20" },
    { icon: "🧪", name: "Praticien Labo", ok: labUsed, desc: "Exécuter du code" },
    { icon: "⭐", name: "Organisé", ok: favs.length >= 1, desc: "1+ favori" }
  ];
}

function renderBadgesHtml() {
  const esc = typeof aiEscape === "function" ? aiEscape : (s => String(s));
  return `<div class="badges-grid">${computeUserBadges().map(b => `<div class="badge-tile ${b.ok ? "unlocked" : ""}"><span class="badge-ico">${b.icon}</span><strong>${esc(b.name)}</strong><small>${b.ok ? "Débloqué !" : esc(b.desc)}</small></div>`).join("")}</div>`;
}

async function downloadAllBooksOffline() {
  if (typeof BOOK_FILES === "undefined") return;
  const st = document.getElementById("offline-status-text");
  if (st) st.textContent = "Téléchargement des manuels en cours...";
  const keys = Object.keys(BOOK_FILES); let okCount = 0; const map = {};
  for (const k of keys) {
    try { const res = await fetch(BOOK_FILES[k] + "?t=" + Date.now()); if (res.ok) { map[k] = await res.text(); okCount++; } } catch (e) {}
  }
  try { localStorage.setItem("jostech_offline_books", JSON.stringify(map)); } catch (e) {}
  if (st) st.textContent = `${okCount}/${keys.length} manuels enregistrés hors connexion !`;
  if (typeof showToast === "function") showToast(`${okCount} manuels prêts hors ligne !`);
}