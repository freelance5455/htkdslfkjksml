let data={sections:[]},filtered=[];
fetch('book.json').then(r=>r.json()).then(x=>{data=x;filtered=x.sections;render()});
const list=document.getElementById('list'),reader=document.getElementById('reader'),title=document.getElementById('title'),text=document.getElementById('text');
function render(){list.innerHTML=filtered.map((s,i)=>`<div class="card" onclick="openPage(${data.sections.indexOf(s)})"><h3>📜 ${s.title}</h3><div>${escape(s.text.slice(0,180))}${s.text.length>180?'…':''}</div></div>`).join('')}
function openPage(i){let s=data.sections[i];title.textContent=s.title;text.innerHTML='<div class="poem">'+escape(s.text)+'</div>';list.hidden=true;reader.hidden=false;scrollTo(0,0)}
function back(){reader.hidden=true;list.hidden=false;scrollTo(0,0)}
function search(){let q=document.getElementById('q').value.trim().toLowerCase();filtered=data.sections.filter(s=>s.text.toLowerCase().includes(q));render()}
function toggleDark(){document.body.classList.toggle('dark');localStorage.dark=document.body.classList.contains('dark')}
if(localStorage.dark==='true')document.body.classList.add('dark')
function escape(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
