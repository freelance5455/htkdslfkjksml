const cv=document.getElementById('c'),g=cv.getContext('2d'),W=960,H=540,GY=430;cv.width=W;cv.height=H;
const K={};let D=null,S,last=0,ac=null,stars=[];
for(let i=0;i<130;i++)stars.push([Math.random()*W,Math.random()*H,Math.random()*1.6+.3,Math.random()*6]);
const NAMES={p:'Sen',elif:'Elif',mehmet:'Mehmet Amca',hasan:'Hasan Abi',kemal:'Usta Kemal',ayse:'Komutan Ayşe',deniz:'Kaptan Deniz',selin:'Dr. Selin',sys:'',tel:'📡 Telsiz'};
const COL={p:'#3b82f6',elif:'#ec4899',mehmet:'#a16207',hasan:'#16a34a',kemal:'#f97316',ayse:'#7c3aed',deniz:'#0ea5e9',selin:'#14b8a6'};
const B=[{id:'kontrol',x:320,w:230,c:'#64748b',n:'KONTROL MERKEZİ'},{id:'atolye',x:820,w:200,c:'#b45309',n:'ATÖLYE'},{id:'kafe',x:1220,w:200,c:'#be123c',n:'KAFE'}];
const N=[{id:'elif',x:560},{id:'mehmet',x:1000}],ROCK=1680,RN={kontrol:'ayse',atolye:'kemal',kafe:'hasan'},SN=[{id:'deniz',x:430},{id:'selin',x:730}];
const RC={kontrol:'#334155',atolye:'#78350f',kafe:'#7f1d1d'};
const cl=(v,a,b)=>Math.max(a,Math.min(b,v));
function reset(){S={sc:'title',f:{},x:150,dir:1,t:0,room:null,ret:0,r:120,a:0,sa:2.2,dock:0,walk:0}}reset();
function initAudio(){try{ac=new (window.AudioContext||window.webkitAudioContext)()}catch(e){}}
function blip(id){if(!ac)return;const o=ac.createOscillator(),v=ac.createGain();o.type='square';o.frequency.value=180+(id.length*37%160)+Math.random()*30;v.gain.value=.025;o.connect(v);v.connect(ac.destination);o.start();o.stop(ac.currentTime+.04)}
const SP={on:false,mute:false,ready:false,vf:null,vm:null,tok:0};
const VP={p:['m',1,1],elif:['f',1.3,1.05],mehmet:['m',.7,.88],hasan:['m',.95,1],kemal:['m',.8,1],ayse:['f',.95,1],deniz:['m',1.05,1],selin:['f',1.08,1.03],tel:['f',.9,1.05],sys:['f',.95,.97]};
const voiceOn=()=>!SP.mute&&(SP.ready||!!SP.au);
function pickVoices(){if(!window.speechSynthesis)return;const vs=speechSynthesis.getVoices().filter(v=>/^tr/i.test(v.lang));SP.ready=vs.length>0;
 const sc=v=>(/natural|neural|online/i.test(v.name)?10:0)+(/google|microsoft|apple/i.test(v.name)?3:0)+(v.localService?0:1);
 const best=a=>a.sort((x,y)=>sc(y)-sc(x))[0]||null;
 SP.vm=best(vs.filter(v=>/ahmet|cem|tolga|bora|erkek|\bmale\b/i.test(v.name)&&!/female/i.test(v.name)));
 SP.vf=best(vs.filter(v=>/emel|yelda|filiz|seda|female|kad[ıi]n|google/i.test(v.name)))||best(vs.filter(v=>v!==SP.vm))||SP.vm}
if(window.speechSynthesis){pickVoices();speechSynthesis.onvoiceschanged=pickVoices}
function stopSpeak(){SP.tok++;SP.on=false;if(SP.au){SP.au.pause();SP.au=null}if(window.speechSynthesis)speechSynthesis.cancel()}
function speakLine(){if(!D)return;const[id,txt]=D.l[D.i];stopSpeak();if(SP.mute)return;const f=window.SES&&SES[id+'|'+txt];
 if(f){const t=++SP.tok,a=new Audio(f);SP.au=a;a.onplaying=()=>{if(t===SP.tok)SP.on=true};a.onended=()=>{if(t===SP.tok){SP.on=false}};a.onerror=()=>{if(t===SP.tok){SP.au=null;tts(id,txt)}};a.play().catch(()=>{});return}
 tts(id,txt)}
function tts(id,txt){if(!SP.ready)return;
 const vp=VP[id]||VP.sys,male=vp[0]==='m',real=male?SP.vm:SP.vf,v=real||SP.vf||SP.vm,t=++SP.tok;
 const u=new SpeechSynthesisUtterance(txt.replace(/[^\p{L}\p{N}\s.,!?'’…:;-]/gu,''));u.lang='tr-TR';if(v)u.voice=v;
 u.pitch=Math.min(2,vp[1]*(male&&!SP.vm?.62:1));u.rate=vp[2];
 u.onstart=()=>{if(t===SP.tok)SP.on=true};u.onend=u.onerror=()=>{if(t===SP.tok)SP.on=false};speechSynthesis.speak(u)}
function say(l,cb){D={l,i:0,n:0,cb};speakLine()}
function advance(){const t=D.l[D.i][1];if(D.n<t.length){D.n=t.length;return}D.i++;D.n=0;if(D.i>=D.l.length){const cb=D.cb;D=null;stopSpeak();cb&&cb()}else speakLine()}
function press(k){if(!ac)initAudio();if(k==='m'){SP.mute=!SP.mute;if(SP.mute)stopSpeak();else if(D)speakLine();return}if(D){if(k==='e'||k===' '||k==='enter')advance();return}
 if(S.sc==='title'){if(k==='e'||k==='enter'||k===' ')start()}
 else if(S.sc==='end'){if(k==='r'||k==='e'||k==='enter'){reset()}}
 else if(k==='e'||k==='enter'){const t=target();t&&t.fn()}}
addEventListener('keydown',e=>{const k=e.key.toLowerCase();K[k]=1;if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(k))e.preventDefault();if(!e.repeat)press(k)});
addEventListener('keyup',e=>K[e.key.toLowerCase()]=0);
cv.addEventListener('pointerdown',()=>{if(!ac)initAudio();if(D)advance()});
document.querySelectorAll('#pad button').forEach(b=>{const k=b.dataset.k;b.addEventListener('pointerdown',e=>{e.preventDefault();K[k]=1;press(k)});['pointerup','pointerleave','pointercancel'].forEach(ev=>b.addEventListener(ev,()=>K[k]=0))});
function start(){say([['sys','Sabah. Baykuş Burnu Fırlatma Üssü’nde güneş yeni doğuyor…'],['sys','Bugün büyük gün: Dünya’nın etrafında dönecek ilk uçuşuna çıkıyorsun.'],['p','Hadi bakalım. Önce üssü gezip herkesle konuşayım.']],()=>{S.sc='town';S.x=150})}
function enter(id){S.ret=S.x;S.room=id;S.sc='room';S.x=140}
function exitRoom(){S.sc='town';S.x=S.ret;S.room=null}
function target(){const x=S.x;
 if(S.sc==='town'){for(const b of B)if(Math.abs(x-b.x)<70)return{l:'Gir',fn:()=>enter(b.id)};
  for(const n of N)if(Math.abs(x-n.x)<80)return{l:'Konuş',fn:()=>talk(n.id)};
  if(Math.abs(x-ROCK)<110)return{l:'Roket',fn:rocket}}
 if(S.sc==='room'){if(x<120)return{l:'Dışarı çık',fn:exitRoom};if(Math.abs(x-640)<100)return{l:'Konuş',fn:()=>talk(RN[S.room])}}
 if(S.sc==='station'){for(const n of SN)if(Math.abs(x-n.x)<90)return{l:'Konuş',fn:()=>talk(n.id)}}
 return null}
function rocket(){const f=S.f;
 if(!f.izin)return say([['sys','Fırlatma rampası kilitli. Önce Komutan Ayşe’den uçuş izni almalısın.']]);
 say([['sys','Roketin kapısı sıkıca kapanıyor. Geri sayım başlıyor…'],['tel','On… dokuz… sekiz… yedi… altı… beş… dört… üç… iki… bir… ATEŞLEME!'],['sys','Gökyüzü yarılıyor. Dünya aşağıda küçülüyor…']],()=>{S.sc='orbit';S.r=120;S.a=0;S.sa=2.2;S.dock=0;
 say([['tel','Uzay İstasyonu “Deniz-1” yörüngede. Alçak yörünge hızlı, yüksek yörünge yavaştır.'],['tel','↑ ↓ ile yüksekliğini ayarla, ← → ile kamerayı çevir. İstasyona yaklaş ve bir süre yanında kal. Kenetlenme otomatik!'],['p','Anlaşıldı. İstasyon, geliyorum!']])})}
function talk(id){const f=S.f;
 if(id==='elif')return say(!f.cay?[['elif','Merhaba! Herkes Dünya’nın etrafında dönecek ilk kozmonot adayının sen olduğunu söylüyor!'],['p','Doğru. Ama önce hazırlıklar lazım.'],['elif','Önce Kafe’de Hasan Abi’ye uğra, sonra Atölye’de Kemal Usta, en son Kontrol Merkezi. Binalara girmek için E’ye bas!']]:!f.izin?[['elif','Henüz izin alamadın mı? Komutan Ayşe çok titizdir ama kalbi altındandır!']]:[['elif','Roketine git, sağda rampada bekliyor! Bana uzaydan el salla olur mu?']]);
 if(id==='mehmet')return say([['mehmet','Evlat, ben bu üssün bekçisiyim. Kırk yıldır gökyüzüne bakarım.'],['mehmet','Bir gece yıldızlar öyle parlak ki “yukarıdan biri bana göz kırptı” dedim. Meğer istasyonmuş!'],['p','Belki o gün bugündür, Mehmet Amca.'],['mehmet','Hadi, hayırlı yolculuklar. Kafede çay iyidir, bir uğra!']]);
 if(id==='hasan'){if(!f.cay)return say([['hasan','Hoş geldin kozmonot! Yeni demlenmiş çay var, yanında da simit.'],['p','Harika kokuyor!'],['hasan','Al şu çayı Kemal Usta’ya götür. Sabahtan beri “çay yok” diye söylenip duruyor.'],['sys','☕ Sıcak çay aldın!']],()=>f.cay=1);
  return say([['hasan','Uzayda çay içmek zordur derler. Sen yine de başarırsın!']])}
 if(id==='kemal'){if(!f.cay)return say([['kemal','Kim o? Çay yoksa konuşmam! Elim titriyor, vidaları sıkamıyorum.'],['p','Hasan Abi’de çay var galiba…']]);
  if(!f.yakit)return say([['p','Usta, Hasan Abi’den sıcak çay getirdim.'],['kemal','Aaah, işte bu! Şimdi dünyam düzeldi.'],['kemal','Al şu yakıt hücresini, roketin kalbi bu. Dikkatli taşı, ayağına düşürme!'],['sys','⚡ Yakıt hücresi aldın!']],()=>{f.yakit=1;f.cay=2});
  return say([['kemal','Roket hazır, motorlar pırıl pırıl. Gözün arkada kalmasın!']])}
 if(id==='ayse'){if(!f.yakit)return say([['ayse','Kozmonot aday, yakıt hücresi olmadan uçuş izni imzalamam. Kural kural!'],['p','Atölyeden alıp geleceğim.']]);
  if(!f.izin)return say([['p','Komutanım, yakıt hücresi hazır.'],['ayse','Mükemmel. Kontrol listesi tamam, hava durumu açık, sen de hazırsın.'],['ayse','Uçuş iznini veriyorum. Unutma: yörüngede acele eden kaybeder, sabırlı olan istasyonu yakalar.'],['sys','📄 Uçuş izni aldın! Roket rampası sağda.']],()=>f.izin=1);
  return say([['ayse','Rampa sağda. Gökyüzü seni bekliyor!']])}
 if(id==='deniz'||id==='selin'){const first=!f[id];f[id]=1;
  const L=id==='deniz'?[['deniz','Hoş geldin! Ben Kaptan Deniz. Yörüngeye ilk kez çıkanlar hep aynı şeyi söyler: “Her şey çok küçük!”'],['p','Dünya şu pencereden bir mavi misket gibi…'],['deniz','Burada gün doğumunu doksan dakikada bir görürüz. Hiç alışılmıyor.']]
  :[['selin','Ben Dr. Selin. Burada bitkilerin uzayda nasıl büyüdüğünü inceliyorum. Bak, domatesim filizlendi!'],['p','Uzayda domates mi?'],['selin','Evet! Ağırlık yok ama tat var. Sen de bir gün tadarsın.']];
  const done=()=>{if(f.deniz&&f.selin)say([['deniz','Dünya’nın etrafında tam bir tur attın, kozmonot!'],['selin','Mavi gezegene bir de buradan bak, bak ve unutma.'],['p','Çay, simit, yakıt, izin… sonunda hepsi buraya çıktı. Teşekkürler herkese!'],['sys','Pencerenin ardında Dünya yavaşça dönüyor. Hikâyen yeni başlıyor…']],()=>S.sc='end')};
  say(L,done)}}
function update(dt){S.t+=dt;
 if(D){const l=D.l[D.i],p=Math.floor(D.n);D.n=Math.min(l[1].length,D.n+dt*(voiceOn()?16:38));if(!voiceOn()&&Math.floor(D.n)>p&&l[0]!=='sys')blip(l[0]);return}
 if(S.sc==='town'||S.sc==='room'||S.sc==='station'){let d=(K.arrowright||K.d?1:0)-(K.arrowleft||K.a?1:0);
  if(d){S.dir=d;S.walk+=dt}S.x+=d*210*dt;S.x=S.sc==='town'?cl(S.x,40,1860):cl(S.x,60,900);
  if(S.sc==='room'&&S.x<=62&&d<0)exitRoom()}
 if(S.sc==='orbit'){if(K.arrowup||K.w)S.r+=55*dt;if(K.arrowdown||K.s)S.r-=55*dt;S.r=cl(S.r,115,250);
  S.a+=1131/Math.pow(S.r,1.5)*dt;S.sa+=0.4*dt;
  const dd=wr(S.sa-S.a),tg=S.a+dd*.5+(S.co||0);if(S.ca===undefined)S.ca=tg;S.ca+=wr(tg-S.ca)*Math.min(1,3*dt);S.cd=440+Math.min(1,Math.abs(dd)/2)*150;
  if(K.arrowleft||K.a)S.co=Math.max(-1.3,(S.co||0)-1.5*dt);if(K.arrowright||K.d)S.co=Math.min(1.3,(S.co||0)+1.5*dt);
  (S.tr=S.tr||[]).push([Math.cos(S.a)*S.r,0,Math.sin(S.a)*S.r]);if(S.tr.length>70)S.tr.shift();
  const rx=Math.cos(S.a)*S.r,ry=Math.sin(S.a)*S.r,sx=Math.cos(S.sa)*200,sy=Math.sin(S.sa)*200;
  if(Math.hypot(rx-sx,ry-sy)<30)S.dock+=dt;else S.dock=Math.max(0,S.dock-dt);
  if(S.dock>2){S.dock=0;say([['sys','Klik! Roket istasyona kenetlendi. Hava kilidi basınçlanıyor…'],['tel','Deniz-1’e hoş geldin! İçeri geç, mürettebat seni bekliyor.']],()=>{S.sc='station';S.x=140})}}}
function wrap(t,mw){const w=t.split(' ');let L=[],c='';for(const x of w){const n=c?c+' '+x:x;if(g.measureText(n).width>mw&&c){L.push(c);c=x}else c=n}L.push(c);return L}
function char(id,x,y,dir,walk,float){const l=D&&D.l[D.i],tk=l&&l[0]===id&&(Math.floor(D.n)<l[1].length||SP.on);
 g.save();g.translate(x+(tk?Math.sin(S.t*40)*2.5:0),y-(float?20+Math.sin(S.t*2+x)*8:0));if(tk)g.rotate(Math.sin(S.t*28)*.07);
 const sw=Math.sin(walk*12)*6;g.fillStyle='#1e293b';g.fillRect(-10,-14,8,14);g.fillRect(2+sw*.3,-14,8,14);
 g.fillStyle=COL[id];g.fillRect(-13,-46,26,34);g.fillStyle='#f1c79a';g.beginPath();g.arc(0,-58,13,0,7);g.fill();
 g.fillStyle=id==='p'?'#e2e8f0':id==='mehmet'?'#9ca3af':'#3b2a1a';g.beginPath();g.arc(0,-61,13,Math.PI,0);g.fill();
 if(id==='p'){g.strokeStyle='#fff';g.lineWidth=2;g.beginPath();g.arc(0,-58,15,0,7);g.stroke()}
 g.fillStyle='#111';g.fillRect(dir*4-1,-60,3,3);g.fillRect(dir*4+5,-60,3,3);
 if(tk&&Math.sin(S.t*30)>0){g.beginPath();g.ellipse(dir*4+3,-52,3,3,0,0,7);g.fill()}else g.fillRect(dir*4,-52,6,1.5);
 g.fillStyle=COL[id];g.fillRect(dir>0?10:-18,-44,8,22+sw*.5);
 if(id!=='p'){g.fillStyle='#fff';g.font='bold 12px sans-serif';g.textAlign='center';g.fillText(NAMES[id],0,-84)}g.restore()}
function prompt(sx){const t=target();if(!t||D)return;g.font='bold 16px sans-serif';g.textAlign='center';const s='[E] '+t.l,w=g.measureText(s).width+18;
 g.fillStyle='#000a';g.fillRect(sx-w/2,GY-150,w,26);g.fillStyle='#fde047';g.fillText(s,sx,GY-132)}
function objective(){const f=S.f;return S.sc==='station'?'Görev: Mürettebatla konuş':!f.cay?'Görev: Kafe’de Hasan Abi ile konuş':!f.yakit?'Görev: Çayı Atölye’de Usta Kemal’e ver':!f.izin?'Görev: Yakıt hücresini Komutan Ayşe’ye götür':'Görev: Roketine git → (sağa)'}
function hud(){g.fillStyle='#000a';g.fillRect(10,10,420,32);g.fillStyle='#fff';g.font='15px sans-serif';g.textAlign='left';g.fillText(objective(),20,32);
 g.fillText((S.f.cay===1?'☕ ':'')+(S.f.yakit?'⚡ ':'')+(S.f.izin?'📄':''),440,32);g.fillStyle='#fff9';g.font='12px sans-serif';g.fillText('← → yürü • E konuş/gir • Boşluk ilerlet • M: ses '+(SP.mute?'kapalı':'açık'),10,H-8)}
function dialog(){if(!D)return;const[w,t]=D.l[D.i];g.fillStyle='#0b1020ee';g.fillRect(30,H-170,W-60,150);g.strokeStyle=COL[w]||'#94a3b8';g.lineWidth=3;g.strokeRect(30,H-170,W-60,150);
 if(NAMES[w]){g.fillStyle=COL[w]||'#475569';g.fillRect(48,H-188,180,30);g.fillStyle='#fff';g.font='bold 17px sans-serif';g.textAlign='left';g.fillText(NAMES[w],58,H-167)}
 g.fillStyle='#fff';g.font='21px sans-serif';g.textAlign='left';wrap(t.slice(0,Math.floor(D.n)),W-120).forEach((s,i)=>g.fillText(s,56,H-125+i*30));
 if(Math.floor(D.n)>=t.length&&Math.sin(S.t*6)>0){g.fillStyle='#fde047';g.fillText('▼',W-70,H-35)}}
function earth(cx,cy,R){const gr=g.createRadialGradient(cx-R*.3,cy-R*.3,R*.1,cx,cy,R);gr.addColorStop(0,'#60a5fa');gr.addColorStop(1,'#1e3a8a');g.fillStyle=gr;g.beginPath();g.arc(cx,cy,R,0,7);g.fill();
 g.save();g.beginPath();g.arc(cx,cy,R,0,7);g.clip();g.fillStyle='#4ade80';for(let i=0;i<6;i++){const bx=((i*97+S.t*10)%(2*R+120))-R-60+cx,by=cy+((i*53)%(R*1.2))-R*.6;g.beginPath();g.ellipse(bx,by,28+i*4,16+i*2,i,0,7);g.fill()}
 g.fillStyle='#0004';g.beginPath();g.arc(cx+R*.5,cy,R,0,7);g.fill();g.restore()}
function sky(){g.fillStyle='#04050f';g.fillRect(0,0,W,H);g.fillStyle='#fff';for(const s of stars){g.globalAlpha=.5+.5*Math.sin(S.t*2+s[3]);g.fillRect(s[0],s[1],s[2],s[2])}g.globalAlpha=1}
function townDraw(){const cx=cl(S.x-W/2,0,1900-W);const gr=g.createLinearGradient(0,0,0,GY);gr.addColorStop(0,'#1e3a8a');gr.addColorStop(1,'#fdba74');g.fillStyle=gr;g.fillRect(0,0,W,H);
 g.fillStyle='#fde68a';g.beginPath();g.arc(780-cx*.1,150,40,0,7);g.fill();g.fillStyle='#7c5a8c';for(let i=0;i<6;i++){g.beginPath();g.moveTo(i*400-cx*.3-100,GY);g.lineTo(i*400-cx*.3+100,GY-130);g.lineTo(i*400-cx*.3+300,GY);g.fill()}
 g.save();g.translate(-cx,0);g.fillStyle='#4d7c0f';g.fillRect(0,GY,1900,H-GY);g.fillStyle='#a8a29e';g.fillRect(0,GY,1900,12);
 for(const b of B){g.fillStyle=b.c;g.fillRect(b.x-b.w/2,GY-170,b.w,170);g.fillStyle='#1f2937';g.fillRect(b.x-b.w/2-8,GY-185,b.w+16,18);g.fillStyle='#fde68a';g.fillRect(b.x-60,GY-120,30,30);g.fillRect(b.x+30,GY-120,30,30);g.fillStyle='#111827';g.fillRect(b.x-22,GY-75,44,75);g.fillStyle='#fff';g.font='bold 14px sans-serif';g.textAlign='center';g.fillText(b.n,b.x,GY-150)}
 g.fillStyle='#57534e';g.fillRect(ROCK-70,GY-14,140,14);g.fillStyle='#e5e7eb';g.fillRect(ROCK-22,GY-200,44,186);g.fillStyle='#ef4444';g.beginPath();g.moveTo(ROCK-22,GY-200);g.lineTo(ROCK,GY-260);g.lineTo(ROCK+22,GY-200);g.fill();g.fillRect(ROCK-40,GY-50,18,36);g.fillRect(ROCK+22,GY-50,18,36);g.fillStyle='#38bdf8';g.beginPath();g.arc(ROCK,GY-150,10,0,7);g.fill();g.fillStyle='#fff';g.font='bold 14px sans-serif';g.fillText('ROKET',ROCK,GY-275);
 for(const n of N)char(n.id,n.x,GY+8,-1,0);char('p',S.x,GY+8,S.dir,S.walk);g.restore();prompt(S.x-cx)}
function roomDraw(){const c=RC[S.room];g.fillStyle=c;g.fillRect(0,0,W,H);g.fillStyle='#0003';g.fillRect(0,GY+8,W,H);g.fillStyle='#111827';g.fillRect(40,GY-90,50,98);g.fillStyle='#fff';g.font='12px sans-serif';g.textAlign='center';g.fillText('ÇIKIŞ',65,GY-98);
 g.fillStyle='#fde68a';g.fillRect(300,100,120,90);g.fillRect(520,100,120,90);g.fillStyle='#0ea5e955';g.fillRect(305,105,110,80);g.fillRect(525,105,110,80);
 g.fillStyle='#fff';g.font='bold 26px sans-serif';g.fillText(B.find(b=>b.id===S.room).n,W/2,60);
 g.fillStyle='#92400e';g.fillRect(560,GY-40,160,12);g.fillRect(570,GY-28,10,36);g.fillRect(700,GY-28,10,36);
 char(RN[S.room],640,GY+8,-1,0);char('p',S.x,GY+8,S.dir,S.walk);prompt(S.x)}
const wr=x=>Math.atan2(Math.sin(x),Math.cos(x)),FOC=720,ER=95,dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],add=(p,v,k=1)=>[p[0]+v[0]*k,p[1]+v[1]*k,p[2]+v[2]*k];
const STARS3=[],BLOBS=[];let CM;
for(let i=0;i<220;i++){const u=Math.random()*2-1,a=Math.random()*6.283,q=Math.sqrt(1-u*u);STARS3.push([q*Math.cos(a),u,q*Math.sin(a),Math.random()*6])}
for(let i=0;i<70;i++){const c=i%7;BLOBS.push([c*.9+Math.random()*.7,(Math.random()-.5)*2*(c%3?.7:1),.08+Math.random()*.12])}
function cam3(th,d){const C=[Math.cos(th)*d,230,Math.sin(th)*d],n=Math.hypot(...C),f=C.map(v=>-v/n);let rt=[-f[2],0,f[0]];const m=Math.hypot(rt[0],rt[2]);rt=[rt[0]/m,0,rt[2]/m];
 return{C,f,rt,up:[rt[1]*f[2]-rt[2]*f[1],rt[2]*f[0]-rt[0]*f[2],rt[0]*f[1]-rt[1]*f[0]]}}
function pj(p){const v=[p[0]-CM.C[0],p[1]-CM.C[1],p[2]-CM.C[2]],z=dot(v,CM.f);return{x:W/2+FOC*dot(v,CM.rt)/z,y:H/2+20-FOC*dot(v,CM.up)/z,z}}
function ln(a,b,w,col){const A=pj(a),B=pj(b);if(A.z<=1||B.z<=1)return;g.strokeStyle=col;g.lineCap='round';g.lineWidth=Math.max(1,w*FOC/((A.z+B.z)/2));g.beginPath();g.moveTo(A.x,A.y);g.lineTo(B.x,B.y);g.stroke()}
function poly(pts,fill,stroke){const q=pts.map(pj);if(q.some(a=>a.z<=1))return;g.beginPath();q.forEach((a,i)=>i?g.lineTo(a.x,a.y):g.moveTo(a.x,a.y));g.closePath();g.fillStyle=fill;g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=1;g.stroke()}}
function earth3(E,rp){const gl=g.createRadialGradient(E.x,E.y,rp*.95,E.x,E.y,rp*1.16);gl.addColorStop(0,'#60a5fa99');gl.addColorStop(1,'#60a5fa00');g.fillStyle=gl;g.beginPath();g.arc(E.x,E.y,rp*1.16,0,7);g.fill();
 const sun=[.8,.3,.5],sx=dot(sun,CM.rt),sy=dot(sun,CM.up),gr=g.createRadialGradient(E.x+sx*rp*.5,E.y-sy*rp*.5,rp*.1,E.x,E.y,rp);gr.addColorStop(0,'#5aa9ff');gr.addColorStop(.6,'#1d4ed8');gr.addColorStop(1,'#0a1440');g.fillStyle=gr;g.beginPath();g.arc(E.x,E.y,rp,0,7);g.fill();
 const cn=Math.hypot(...CM.C);for(const b of BLOBS){const lo=b[0]+S.t*.05,la=b[1],n=[Math.cos(la)*Math.cos(lo),Math.sin(la),Math.cos(la)*Math.sin(lo)],vis=dot(n,CM.C)/cn-ER/cn;if(vis<.04)continue;
  const pr=pj(n.map(v=>v*ER)),rad=FOC*ER*b[2]/pr.z;g.globalAlpha=Math.max(.15,.35+.65*dot(n,sun));g.fillStyle='#3fae5a';g.beginPath();g.ellipse(pr.x,pr.y,rad*Math.min(1,vis*3+.2),rad,Math.atan2(pr.y-E.y,pr.x-E.x),0,7);g.fill()}g.globalAlpha=1}
function orbitDraw(){g.fillStyle='#02030a';g.fillRect(0,0,W,H);CM=cam3(S.ca||0,S.cd||460);
 g.fillStyle='#fff';for(const s of STARS3){const z=dot(s,CM.f);if(z<=.05)continue;g.globalAlpha=.4+.5*Math.sin(S.t*2+s[3]);g.fillRect(W/2+FOC*dot(s,CM.rt)/z,H/2+20-FOC*dot(s,CM.up)/z,1.6,1.6)}g.globalAlpha=1;
 const E=pj([0,0,0]),rp=FOC*ER/Math.sqrt(E.z*E.z-ER*ER),P=[Math.cos(S.a)*S.r,0,Math.sin(S.a)*S.r],Q=[Math.cos(S.sa)*200,0,Math.sin(S.sa)*200],Y=[0,1,0];
 const ring=far=>{for(let i=0;i<90;i+=2){const a=[Math.cos(i/90*6.283)*200,0,Math.sin(i/90*6.283)*200],b=[Math.cos((i+1)/90*6.283)*200,0,Math.sin((i+1)/90*6.283)*200];if((pj(a).z>E.z)===far)ln(a,b,.8,'#ffffff40')}};
 const rocketD=()=>{const tn=[-Math.sin(S.a),0,Math.cos(S.a)];for(let i=0;i+1<(S.tr||[]).length;i++)ln(S.tr[i],S.tr[i+1],2.5,`rgba(255,190,110,${i/S.tr.length*.55})`);
  const tail=add(P,tn,-12),nose=add(P,tn,12);poly([add(tail,tn,8),add(tail,tn,-4),add(tail,Y,12)],'#ef4444');poly([add(tail,tn,8),add(tail,tn,-4),add(tail,Y,-12)],'#ef4444');
  ln(tail,add(tail,tn,-(8+Math.random()*10)),6,'#fb923c');ln(tail,nose,9,'#f1f5f9');ln(add(nose,tn,-2),add(nose,tn,13),6,'#ef4444')};
 const stationD=()=>{const ph=S.t*.6,u=[Math.cos(ph),0,Math.sin(ph)];for(const k of[1,-1])poly([add(add(Q,Y,k*12),u,9),add(add(Q,Y,k*12),u,-9),add(add(Q,Y,k*44),u,-9),add(add(Q,Y,k*44),u,9)],'#2563eb','#bfdbfe');
  ln(add(Q,Y,-44),add(Q,Y,44),2,'#cbd5e1');ln(add(Q,u,-15),add(Q,u,15),11,'#cbd5e1');const A=pj(Q),sc=FOC/A.z;g.fillStyle='#f8fafc';g.beginPath();g.arc(A.x,A.y,12*sc,0,7);g.fill();g.fillStyle='#fde047';g.font='12px sans-serif';g.textAlign='center';g.fillText('İSTASYON',A.x,A.y-52*sc)};
 const far=[],near=[];for(const[p,f]of[[Q,stationD],[P,rocketD]]){const z=pj(p).z;(z>E.z?far:near).push([z,f])}
 ring(true);far.sort((a,b)=>b[0]-a[0]).forEach(o=>o[1]());earth3(E,rp);ring(false);near.sort((a,b)=>b[0]-a[0]).forEach(o=>o[1]());
 const A=pj(Q),dist=Math.hypot(P[0]-Q[0],P[2]-Q[2]),hid=A.z>E.z&&Math.hypot(A.x-E.x,A.y-E.y)<rp;
 if(dist<70&&!hid&&A.z>1){const sc=FOC/A.z;g.strokeStyle='#4ade80';g.lineWidth=2;g.beginPath();g.arc(A.x,A.y,30*sc,0,7);g.stroke();g.lineWidth=5;g.beginPath();g.arc(A.x,A.y,36*sc,-1.57,-1.57+S.dock/2*6.283);g.stroke()}
 if(hid||A.z<=1||A.x<40||A.x>W-40||A.y<60||A.y>H-60){let ix,iy;if(A.z>1){ix=cl(A.x,50,W-50);iy=cl(A.y,70,H-70)}else{let dx=W/2-A.x,dy=H/2-A.y;const k=Math.min((W/2-50)/Math.abs(dx||1),(H/2-70)/Math.abs(dy||1));ix=W/2+dx*k;iy=H/2+dy*k}
  const an=(ix===A.x&&iy===A.y)?1.57:Math.atan2(A.y-iy,A.x-ix);g.save();g.translate(ix,iy);g.rotate(an);g.fillStyle='#fde047';g.beginPath();g.moveTo(14,0);g.lineTo(-8,-9);g.lineTo(-8,9);g.fill();g.restore();g.fillStyle='#fde047';g.font='13px sans-serif';g.textAlign='center';g.fillText('İSTASYON'+(hid?' (Dünya’nın arkasında)':''),ix,iy-16)}
 g.fillStyle='#000a';g.fillRect(10,10,300,82);g.fillStyle='#fff';g.font='15px sans-serif';g.textAlign='left';g.fillText('Yükseklik: '+Math.round((S.r-95)*3.8)+' km',20,32);g.fillText('Mesafe: '+Math.round(dist*3.8)+' km',20,54);g.fillText('Kenetlenme:',20,78);g.fillStyle='#334155';g.fillRect(110,66,180,14);g.fillStyle='#22c55e';g.fillRect(110,66,180*S.dock/2,14);
 g.fillStyle='#fff9';g.font='13px sans-serif';g.fillText('↑ ↓ yükseklik • ← → kamera • alçak = hızlı, yüksek = yavaş',10,H-8)}
function stationDraw(){g.fillStyle='#374151';g.fillRect(0,0,W,H);g.fillStyle='#000';g.beginPath();g.ellipse(480,170,300,110,0,0,7);g.fill();g.save();g.beginPath();g.ellipse(480,170,296,106,0,0,7);g.clip();sky();earth(480,430,300);g.restore();
 g.strokeStyle='#9ca3af';g.lineWidth=6;g.beginPath();g.ellipse(480,170,300,110,0,0,7);g.stroke();g.fillStyle='#1f2937';g.fillRect(0,GY+8,W,H);
 for(const n of SN)char(n.id,n.x,GY+8,-1,0,1);char('p',S.x,GY+8,S.dir,S.walk,1);prompt(S.x)}
function endDraw(){sky();earth(480,300,110);g.fillStyle='#fff';g.textAlign='center';g.font='bold 64px sans-serif';g.fillText('SON',480,110);g.font='22px sans-serif';g.fillText('Dünya’nın etrafında bir tur attın. Tebrikler, kozmonot!',480,470);g.font='16px sans-serif';g.fillStyle='#fde047';g.fillText('Tekrar oynamak için E veya R',480,505)}
function titleDraw(){sky();earth(480,380,170);g.fillStyle='#fff';g.textAlign='center';g.font='bold 72px sans-serif';g.fillText('YÖRÜNGE',480,130);g.font='22px sans-serif';g.fillText('Dünya’nın etrafında bir uzay hikâyesi',480,175);if(Math.sin(S.t*4)>0){g.fillStyle='#fde047';g.fillText('Başlamak için E / Enter / dokun',480,230)}g.fillStyle='#fff9';g.font='14px sans-serif';g.fillText(SP.ready?'Türkçe ses hazır'+(SP.vm?' (kadın + erkek)':' (erkek ses yok, kalın ton kullanılacak)')+' • M: aç/kapat':'Bu cihazda Türkçe ses bulunamadı',480,262)}
function draw(){({title:titleDraw,town:townDraw,room:roomDraw,orbit:orbitDraw,station:stationDraw,end:endDraw})[S.sc]();if(['town','room','station'].includes(S.sc))hud();dialog()}
function loop(t){const dt=Math.min(.05,(t-last)/1000||0);last=t;update(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);
