<?php
/* Legal Agenda Server Backup - PHP 7.4+ / MySQL */
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');
function done(int $s,array $d):void{http_response_code($s);echo json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
if(($_SERVER['REQUEST_METHOD']??'')!=='POST')done(405,['success'=>false,'message'=>'استخدم POST لإنشاء النسخة الاحتياطية.']);
if(!is_file(__DIR__.'/config.php'))done(503,['success'=>false,'message'=>'النظام غير مثبت.']);
define('LEGAL_AGENDA_BOOTSTRAP',true);$cfg=require __DIR__.'/config.php';
if(session_status()!==PHP_SESSION_ACTIVE){session_name('LEGAL_AGENDA_SESSID');session_set_cookie_params(['lifetime'=>2592000,'path'=>'/','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','httponly'=>true,'samesite'=>'Lax']);session_start();}
$raw=file_get_contents('php://input');$in=json_decode($raw?:'',true);if(!is_array($in))$in=[];
try{
 $pdo=new PDO('mysql:host='.$cfg['db_host'].';dbname='.$cfg['db_name'].';charset=utf8mb4',$cfg['db_user'],$cfg['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 $uid=(string)($_SESSION['legal_agenda_uid']??'');if($uid==='')done(403,['success'=>false,'message'=>'سجّل الدخول بحساب المدير أولًا لإنشاء نسخة احتياطية.']);
 $row=$pdo->query('SELECT payload FROM legal_agenda_data WHERE id=1')->fetch();$data=json_decode((string)($row['payload']??''),true);$admin=false;
 foreach(($data['users']??[]) as $u){
  if(!is_array($u))continue;
  $sameId=(string)($u['id']??'')===$uid;
  $active=!array_key_exists('active',$u)||!empty($u['active']);
  $role=strtolower(trim((string)($u['role']??'')));
  if($sameId&&$active&&in_array($role,['admin','administrator','مدير'],true)){$admin=true;break;}
 }
 if(!$admin)done(403,['success'=>false,'message'=>'تعذر إثبات صلاحية المدير من جلسة السيرفر. سجّل الخروج ثم الدخول مجددًا من رابط التطبيق نفسه، وتأكد أن حسابك نشط ودوره admin في قسم المستخدمين. لم يتم إنشاء نسخة احتياطية.']);
 if(!class_exists('ZipArchive'))done(500,['success'=>false,'message'=>'إضافة ZipArchive غير مفعلة على الاستضافة؛ لا يمكن إنشاء ملف ZIP.']);
 $dir=__DIR__.'/backups';if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new RuntimeException('تعذر إنشاء مجلد backups.');
 if(!is_file($dir.'/.htaccess'))file_put_contents($dir.'/.htaccess',"Require all denied\nDeny from all\n");if(!is_file($dir.'/index.html'))file_put_contents($dir.'/index.html','');
 $dt=new DateTimeImmutable('now',new DateTimeZone('Africa/Cairo'));$stamp=$dt->format('Y-m-d_H-i-s');$base='legal_agenda_backup_'.$stamp;$tmp=$dir.'/'.$base.'.tmp.zip';$dest=$dir.'/'.$base.'.zip';
 $sql="-- Legal Agenda database backup\n-- Created: ".$dt->format(DateTimeInterface::ATOM)."\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n";
 $tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_NUM);
 foreach($tables as $tr){$table=(string)$tr[0];if(!preg_match('/^[A-Za-z0-9_]+$/',$table))continue;$q=$pdo->query('SHOW CREATE TABLE `'.$table.'`')->fetch(PDO::FETCH_NUM);$sql.="\nDROP TABLE IF EXISTS `{$table}`;\n".$q[1].";\n";$rows=$pdo->query('SELECT * FROM `'.$table.'`');while($r=$rows->fetch(PDO::FETCH_ASSOC)){$cols=array_map(fn($c)=>'`'.str_replace('`','``',$c).'`',array_keys($r));$vals=[];foreach($r as $v)$vals[]=$v===null?'NULL':$pdo->quote((string)$v);$sql.='INSERT INTO `'.$table.'` ('.implode(',',$cols).') VALUES ('.implode(',',$vals).");\n";}}
 $sql.="SET FOREIGN_KEY_CHECKS=1;\n";$zip=new ZipArchive();if($zip->open($tmp,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('تعذر إنشاء ملف ZIP.');
 $root=realpath(__DIR__);$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));foreach($it as $file){if(!$file->isFile()||$file->isLink())continue;$full=$file->getRealPath();$rel=str_replace('\\','/',substr($full,strlen($root)+1));if($rel==='backups'||strpos($rel,'backups/')===0||strpos($rel,'.tmp')!==false)continue;$zip->addFile($full,'application/'.$rel);}
 $zip->addFromString('database.sql',$sql);$meta=['created_at'=>$dt->format(DateTimeInterface::ATOM),'database'=>$cfg['db_name'],'tables'=>count($tables),'includes'=>['all regular files in application directory except backups folder','database.sql'],'note'=>'احتفظ بهذا الملف في مكان آمن؛ يحتوي على بيانات حساسة وبيانات اتصال قاعدة البيانات.'];$zip->addFromString('backup-info.json',json_encode($meta,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));$zip->close();if(!rename($tmp,$dest))throw new RuntimeException('تعذر حفظ ملف النسخة النهائي.');@chmod($dest,0600);
 done(200,['success'=>true,'message'=>'تم إنشاء النسخة الاحتياطية بنجاح.','filename'=>$base.'.zip','created_at'=>$dt->format('Y-m-d H:i:s'),'size'=>filesize($dest),'tables'=>count($tables)]);
}catch(Throwable $e){if(isset($tmp)&&is_file($tmp))@unlink($tmp);done(500,['success'=>false,'message'=>'فشل إنشاء النسخة الاحتياطية: '.$e->getMessage()]);}
