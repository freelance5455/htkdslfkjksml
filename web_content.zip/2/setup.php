<?php
/* Legal Agenda Installer - PHP 7.4+ / MySQL 5.7+
 * Change INSTALL_SECRET before uploading this file.
 * After successful installation, this installer refuses to run again.
 */
declare(strict_types=1);
const INSTALL_SECRET = 'g9IfXcY2ckiFL0fbu7sSZ7L4wTDJta8QeC1oZmjC_mo';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }
function out(int $status, array $body): void { http_response_code($status); echo json_encode($body, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') out(405, ['success'=>false,'message'=>'استخدم POST لتنفيذ التثبيت.']);
$raw=file_get_contents('php://input');
if ($raw === false || strlen($raw)>32768) out(413,['success'=>false,'message'=>'حجم الطلب غير مسموح.']);
$in=json_decode($raw,true);
if (!is_array($in)) out(400,['success'=>false,'message'=>'بيانات JSON غير صحيحة.']);
if (!hash_equals(INSTALL_SECRET, (string)($in['secret'] ?? ''))) out(403,['success'=>false,'message'=>'مفتاح التثبيت غير صحيح.']);
$dir=__DIR__;
$configFile=$dir.DIRECTORY_SEPARATOR.'config.php';
if (file_exists($configFile)) out(409,['success'=>false,'message'=>'النظام مثبت بالفعل. احذف config.php يدويًا فقط إذا كنت تريد إعادة التثبيت بعد أخذ نسخة احتياطية.']);
$host=trim((string)($in['host']??'')); $database=trim((string)($in['database']??'')); $username=trim((string)($in['username']??'')); $password=(string)($in['password']??'');
$adminName=trim((string)($in['admin_name']??'المدير')); $adminUser=strtolower(trim((string)($in['admin_username']??'admin'))); $adminPass=(string)($in['admin_password']??'');
if ($adminName==='' || !preg_match('/^[a-z0-9._-]{3,30}$/',$adminUser) || strlen($adminPass)<8) out(400,['success'=>false,'message'=>'أدخل اسم المدير، واسم مستخدم من 3 إلى 30 حرفًا إنجليزيًا، وكلمة مرور لا تقل عن 8 أحرف.']);
if ($host==='' || $database==='' || $username==='' || $password==='') out(400,['success'=>false,'message'=>'بيانات MySQL غير مكتملة.']);
if (strlen($host)>190 || strlen($database)>64 || strlen($username)>64 || strlen($password)>1024) out(400,['success'=>false,'message'=>'أحد حقول الاتصال أطول من المسموح.']);
try {
  $pdo=new PDO('mysql:host='.$host.';dbname='.$database.';charset=utf8mb4',$username,$password,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false,PDO::ATTR_TIMEOUT=>10]);
  $pdo->exec("CREATE TABLE IF NOT EXISTS legal_agenda_data (id TINYINT UNSIGNED NOT NULL PRIMARY KEY, payload LONGTEXT NULL, revision BIGINT UNSIGNED NOT NULL DEFAULT 0, updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  // Ensure the singleton row exists before seeding the first administrator.
  // The previous installer created the table but forgot this INSERT, so UPDATE affected 0 rows.
  $pdo->exec("INSERT IGNORE INTO legal_agenda_data (id, payload, revision) VALUES (1, NULL, 0)");
  $salt=bin2hex(random_bytes(24)); $uid=bin2hex(random_bytes(16));
  $hash=$salt.':'.$adminPass; for($i=0;$i<2000;$i++) $hash=hash('sha256',$hash.$salt);
  $payload=['office'=>'Smart Deals','clients'=>[],'cases'=>[],'sessions'=>[],'tasks'=>[],'poas'=>[],'deadlines'=>[],'admin'=>[],'bailiffs'=>[],'profile'=>[],'settings'=>['_portalDefaultsV1'=>true],'banner'=>['on'=>false,'text'=>'','color'=>'#4caf50','img'=>''],'users'=>[['id'=>$uid,'username'=>$adminUser,'name'=>$adminName,'role'=>'admin','salt'=>$salt,'hash'=>$hash,'active'=>true,'dflt'=>false,'created'=>date('Y-m-d')]],'inquiries'=>[['id'=>'q1','title'=>'موقف دعوى','sub'=>'استعلام من موقع وزارة العدل','url'=>'https://moj.gov.eg/ar/Pages/Services/ServicesCatalog.aspx?UserCategory=4','icon'=>'hand'],['id'=>'q2','title'=>'وجود إستئناف','sub'=>'استعلام من موقع وزارة العدل','url'=>'https://moj.gov.eg/ar/Pages/Services/ServicesCatalog.aspx?UserCategory=4','icon'=>'gavel'],['id'=>'q3','title'=>'المنصات الحكومية','sub'=>'كل الجهات والمنصات الرسمية','url'=>'','internal'=>'gov','icon'=>'gov']],'labels'=>[],'portals'=>[['id'=>'g1','name'=>'بوابة خدمات المحاكم الإلكترونية','url'=>'https://moj.gov.eg/ar/Pages/Services/ServicesCatalog.aspx?UserCategory=4','icon'=>'court'],['id'=>'g2','name'=>'منصة مصر الرقمية','url'=>'https://digital.gov.eg','icon'=>'globe'],['id'=>'g3','name'=>'مصلحة الضرائب المصرية','url'=>'https://www.eta.gov.eg','icon'=>'money'],['id'=>'g4','name'=>'خدمات الشهر العقاري والتوثيق','url'=>'https://moj.gov.eg/ar/Pages/Services/ServicesCatalog.aspx?UserCategory=4','icon'=>'scale'],['id'=>'g5','name'=>'نقابة المحامين المصرية','url'=>'https://www.egyls.com','icon'=>'shield'],['id'=>'g6','name'=>'منصة النيابة العامة الرقمية','url'=>'https://www.ppo.gov.eg','icon'=>'gov']],'ocr'=>[],'typo'=>[]];
  $payloadJson=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); if($payloadJson===false) throw new RuntimeException('تعذر تجهيز بيانات المدير الأول.');
  $seed=$pdo->prepare('UPDATE legal_agenda_data SET payload=:payload, revision=1 WHERE id=1 AND payload IS NULL');
  $seed->execute([':payload'=>$payloadJson]);
  if ($seed->rowCount() !== 1) {
    $check=$pdo->query('SELECT payload FROM legal_agenda_data WHERE id=1')->fetchColumn();
    if ($check === false || $check === null || $check === '') throw new RuntimeException('تعذر إنشاء بيانات المدير الأول في قاعدة البيانات.');
    throw new RuntimeException('قاعدة البيانات تحتوي بالفعل على بيانات. لم يتم استبدالها. استخدم قاعدة بيانات فارغة للتثبيت من الصفر.');
  }
  $apiKey=bin2hex(random_bytes(32));
  $config="<?php\ndeclare(strict_types=1);\nif (!defined('LEGAL_AGENDA_BOOTSTRAP')) { http_response_code(404); exit; }\nreturn [\n 'db_host'=>".var_export($host,true).",\n 'db_name'=>".var_export($database,true).",\n 'db_user'=>".var_export($username,true).",\n 'db_pass'=>".var_export($password,true).",\n 'api_key_hash'=>".var_export(hash('sha256',$apiKey),true)."\n];\n";
  $tmp=$configFile.'.tmp';
  if (file_put_contents($tmp,$config,LOCK_EX)===false) throw new RuntimeException('تعذر إنشاء config.php. تأكد من صلاحية الكتابة للمجلد.');
  @chmod($tmp,0600);
  if (!@rename($tmp,$configFile)) { @unlink($tmp); throw new RuntimeException('تعذر تثبيت ملف الإعدادات.'); }
  @chmod($configFile,0600);
  $scheme=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')?'https':'http';
  $httpHost=(string)($_SERVER['HTTP_HOST']??'');
  if (!preg_match('/^[A-Za-z0-9.-]+(?::[0-9]{1,5})?$/',$httpHost)) $httpHost='localhost';
  $path=str_replace('\\','/',dirname((string)($_SERVER['SCRIPT_NAME']??'/setup.php')));
  $path=($path==='/'||$path==='.')?'':rtrim($path,'/');
  out(200,['success'=>true,'message'=>'تم التثبيت بنجاح. احتفظ بمفتاح API في مكان آمن.','api_url'=>$scheme.'://'.$httpHost.$path.'/api.php','api_key'=>$apiKey,'revision'=>1,'admin_username'=>$adminUser]);
} catch (Throwable $e) {
  if (isset($tmp) && is_file($tmp)) @unlink($tmp);
  out(500,['success'=>false,'message'=>'فشل التثبيت: '.$e->getMessage()]);
}
