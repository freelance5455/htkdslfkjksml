<?php
declare(strict_types=1);
if (!defined('LEGAL_AGENDA_BOOTSTRAP')) { http_response_code(404); exit; }
return [
 'db_host'=>'sql104.infinityfree.com',
 'db_name'=>'if0_43284561_test',
 'db_user'=>'if0_43284561',
 'db_pass'=>'147852App',
 'api_key_hash'=>'73c3a64778b544052d9a1d5deb6120c686d309e652f623b79022f0dbfed6bbc6'
];
