<?php
/* Legal Agenda private attachment storage - PHP 7.4+ */
declare(strict_types=1);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Referrer-Policy: no-referrer');
$origin=(string)($_SERVER['HTTP_ORIGIN']??'');
$host=strtolower((string)($_SERVER['HTTP_HOST']??''));
if($origin!==''){
  $oh=strtolower((string)(parse_url($origin,PHP_URL_HOST)??''));
  $rh=preg_replace('/:\\d+$/','',$host);
  if($oh===$rh && $oh!==''){header('Access-Control-Allow-Origin: '.$origin);header('Access-Control-Allow-Credentials: true');}
}
header('Vary: Origin');
function out(int $code,array $data):void{http_response_code($code);header('Content-Type: application/json; charset=utf-8');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
if(($_SERVER['REQUEST_METHOD']??'')==='OPTIONS'){http_response_code(204);exit;}
if(!is_file(__DIR__.'/config.php'))out(503,['success'=>false,'message'=>'النظام غير مثبت على السيرفر']);
// config.php intentionally blocks direct access; match the bootstrap used by api.php.
if (!defined('LEGAL_AGENDA_BOOTSTRAP')) define('LEGAL_AGENDA_BOOTSTRAP', true);
session_name('LEGAL_AGENDA_SESSID');
session_set_cookie_params(['lifetime'=>60*60*24*30,'path'=>'/','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','httponly'=>true,'samesite'=>'Lax']);
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
$uid=(string)($_SESSION['legal_agenda_uid']??'');
if($uid==='')out(401,['success'=>false,'message'=>'يلزم تسجيل الدخول']);
try{
 $cfg=require __DIR__.'/config.php';
 $pdo=new PDO('mysql:host='.$cfg['db_host'].';dbname='.$cfg['db_name'].';charset=utf8mb4',$cfg['db_user'],$cfg['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_TIMEOUT=>10]);
 $row=$pdo->query('SELECT payload FROM legal_agenda_data WHERE id=1')->fetch();
 $data=json_decode((string)($row['payload']??''),true);$active=false;
 foreach(($data['users']??[]) as $u){if(is_array($u)&&(string)($u['id']??'')===$uid&&!empty($u['active'])){$active=true;break;}}
 if(!$active)out(401,['success'=>false,'message'=>'جلسة الدخول غير صالحة']);
}catch(Throwable $e){error_log('Agenda files auth: '.$e->getMessage());out(500,['success'=>false,'message'=>'تعذر التحقق من جلسة المستخدم']);}
$key=(string)($_REQUEST['key']??'');
if($key===''||strlen($key)>191||!preg_match('/^[A-Za-z0-9:_-]+$/',$key))out(400,['success'=>false,'message'=>'معرّف الملف غير صالح']);
$dir=__DIR__.'/uploads/attachments';
if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))out(500,['success'=>false,'message'=>'تعذر إنشاء مجلد المرفقات']);
$base=hash('sha256',$key);$metaFile=$dir.'/'.$base.'.json';
$method=$_SERVER['REQUEST_METHOD']??'GET';
if($method==='POST'){
 if(!isset($_FILES['file']))out(400,['success'=>false,'message'=>'لم يستلم PHP الملف. قد يكون حجم الملف أكبر من حد الرفع المسموح في الاستضافة.']);
 $f=$_FILES['file'];$uploadError=(int)($f['error']??UPLOAD_ERR_OK);if($uploadError!==UPLOAD_ERR_OK){$messages=[UPLOAD_ERR_INI_SIZE=>'حجم الملف أكبر من الحد المسموح به في إعدادات PHP على الاستضافة.',UPLOAD_ERR_FORM_SIZE=>'حجم الملف أكبر من الحد المسموح به في النموذج.',UPLOAD_ERR_PARTIAL=>'وصل جزء فقط من الملف؛ أعد المحاولة.',UPLOAD_ERR_NO_FILE=>'لم يتم اختيار ملف.',UPLOAD_ERR_NO_TMP_DIR=>'مجلد الملفات المؤقتة غير متاح على السيرفر.',UPLOAD_ERR_CANT_WRITE=>'تعذر على السيرفر كتابة الملف على القرص.',UPLOAD_ERR_EXTENSION=>'إضافة PHP منعت رفع الملف.'];out(400,['success'=>false,'message'=>$messages[$uploadError]??('فشل رفع الملف (رمز '.$uploadError.').')]);}
 if(!is_uploaded_file($f['tmp_name']))out(400,['success'=>false,'message'=>'الملف المرفوع غير صالح أو انتهت مهلة الطلب.']);
 if((int)$f['size']>10*1024*1024)out(413,['success'=>false,'message'=>'الحد الأقصى لحجم الملف 10MB']);
 if(!class_exists('finfo'))out(500,['success'=>false,'message'=>'خدمة فحص نوع الملفات غير مفعّلة في PHP على الاستضافة.']);
 $fi=new finfo(FILEINFO_MIME_TYPE);$mime=$fi->file($f['tmp_name']);
 $exts=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','application/pdf'=>'pdf'];
 if(!isset($exts[$mime]))out(415,['success'=>false,'message'=>'نوع الملف غير مسموح؛ استخدم صورة أو PDF']);
 $path=$dir.'/'.$base.'.'.$exts[$mime];
 if(!move_uploaded_file($f['tmp_name'],$path))out(500,['success'=>false,'message'=>'تعذر حفظ الملف على السيرفر']);
 $meta=['uid'=>$uid,'name'=>basename((string)($f['name']??'document')),'type'=>$mime,'size'=>(int)$f['size'],'updated'=>time()];
 file_put_contents($metaFile,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);
 out(200,['success'=>true,'key'=>$key,'name'=>$meta['name'],'type'=>$mime,'size'=>$meta['size']]);
}
if($method==='GET'){
 $meta=is_file($metaFile)?json_decode((string)file_get_contents($metaFile),true):null;
 if(!is_array($meta))out(404,['success'=>false,'message'=>'الملف غير موجود']);
 $ext=$exts=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','application/pdf'=>'pdf'];$path=$dir.'/'.$base.'.'.($exts[$meta['type']??'']??'');
 if(!is_file($path))out(404,['success'=>false,'message'=>'الملف غير موجود على السيرفر']);
 header('Content-Type: '.($meta['type']??'application/octet-stream'));header('Content-Length: '.filesize($path));header('Content-Disposition: inline; filename="'.rawurlencode((string)($meta['name']??'document')).'"');readfile($path);exit;
}
if($method==='DELETE'){
 $meta=is_file($metaFile)?json_decode((string)file_get_contents($metaFile),true):null;
 if(is_array($meta)){$exts=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','application/pdf'=>'pdf'];$path=$dir.'/'.$base.'.'.($exts[$meta['type']??'']??'');if(is_file($path))@unlink($path);@unlink($metaFile);}
 out(200,['success'=>true]);
}
out(405,['success'=>false,'message'=>'Method not allowed']);
