<?php
/* Legal Agenda - Standalone Disaster Recovery
 * Upload this file to the website root even if the application is missing.
 * Before use, set RESTORE_KEY_HASH to SHA-256 of a long private password.
 */
declare(strict_types=1);
const RESTORE_KEY_HASH = 'CHANGE_THIS_TO_SHA256_OF_YOUR_PRIVATE_RECOVERY_PASSWORD';
const MAX_UPLOAD_BYTES = 200 * 1024 * 1024;
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function stopPage(string $msg): void { throw new RuntimeException($msg); }
function splitSqlStatements(string $sql): Generator {
    $buf=''; $quote=''; $escape=false; $lineComment=false; $blockComment=false; $n=strlen($sql);
    for($i=0;$i<$n;$i++){
        $c=$sql[$i]; $next=$i+1<$n?$sql[$i+1]:'';
        if($lineComment){ if($c==="\n"){$lineComment=false;} continue; }
        if($blockComment){ if($c==='*'&&$next==='/'){$blockComment=false;$i++;} continue; }
        if($quote!==''){
            $buf.=$c;
            if($escape){$escape=false;continue;}
            if($c==='\\'){$escape=true;continue;}
            if($c===$quote){ if($next===$quote){$buf.=$next;$i++;} else {$quote='';} }
            continue;
        }
        if(($c==='-'&&$next==='-'&&($i+2>=$n||ctype_space($sql[$i+2])))||$c==='#'){
            $lineComment=true; if($c==='-')$i++; continue;
        }
        if($c==='/'&&$next==='*'){$blockComment=true;$i++;continue;}
        if($c==="'"||$c==='"'||$c==='`'){$quote=$c;$buf.=$c;continue;}
        if($c===';'){ $s=trim($buf); if($s!=='')yield $s; $buf=''; continue; }
        $buf.=$c;
    }
    $s=trim($buf); if($s!=='')yield $s;
}
function decodePhpSingleQuoted(string $value): string {
    if (strlen($value) < 2 || $value[0] !== "'" || substr($value, -1) !== "'") return '';
    return str_replace(["\\\\", "\\'"], ["\\", "'"], substr($value, 1, -1));
}
function readBackupConfig(string $code): array {
    // Parse the installer-generated config as data; never execute PHP from an uploaded ZIP.
    $tokens = token_get_all($code); $out=[]; $n=count($tokens);
    for($i=0;$i<$n-2;$i++){
        $a=$tokens[$i]; $b=$tokens[$i+1]; $c=$tokens[$i+2];
        if(is_array($a)&&$a[0]===T_CONSTANT_ENCAPSED_STRING && is_array($b)&&$b[0]===T_DOUBLE_ARROW && is_array($c)&&$c[0]===T_CONSTANT_ENCAPSED_STRING){
            $key=decodePhpSingleQuoted($a[1]);
            if(in_array($key,['db_host','db_name','db_user','db_pass','api_key_hash'],true)) $out[$key]=decodePhpSingleQuoted($c[1]);
        }
    }
    foreach(['db_host','db_name','db_user','db_pass','api_key_hash'] as $k) if(!array_key_exists($k,$out)) stopPage('تعذر قراءة إعدادات الاتصال من ملف config.php داخل النسخة.');
    return $out;
}
function makeConfig(array $cfg): string {
    return "<?php\ndeclare(strict_types=1);\nif (!defined('LEGAL_AGENDA_BOOTSTRAP')) { http_response_code(404); exit; }\nreturn [\n 'db_host'=>".var_export($cfg['db_host'],true).",\n 'db_name'=>".var_export($cfg['db_name'],true).",\n 'db_user'=>".var_export($cfg['db_user'],true).",\n 'db_pass'=>".var_export($cfg['db_pass'],true).",\n 'api_key_hash'=>".var_export($cfg['api_key_hash'],true)."\n];\n";
}
function safeExtractApplication(ZipArchive $zip, string $dest): array {
    $files=[]; $prefix='application/';
    for($i=0;$i<$zip->numFiles;$i++){
        $name=$zip->getNameIndex($i); if(!is_string($name)||strpos($name,$prefix)!==0)continue;
        $rel=substr($name,strlen($prefix)); if($rel===''||strpos($rel,"\0")!==false)continue;
        $rel=str_replace('\\','/',$rel); $parts=explode('/',$rel);
        if(in_array('..',$parts,true)||$rel[0]==='/')stopPage('الأرشيف يحتوي على مسار ملفات غير آمن.');
        if($rel==='restore.php'||strpos($rel,'backups/')===0||$rel==='backups')continue;
        if(substr($name,-1)==='/')continue;
        $stream=$zip->getStream($name); if(!$stream)stopPage('تعذر قراءة أحد ملفات التطبيق من النسخة.');
        $target=$dest.'/'.$rel; $parent=dirname($target); if(!is_dir($parent)&&!mkdir($parent,0755,true))stopPage('تعذر تجهيز مجلدات الاستعادة.');
        $out=fopen($target,'wb'); if(!$out){fclose($stream);stopPage('تعذر تجهيز ملف للاستعادة: '.h($rel));}
        if(stream_copy_to_stream($stream,$out)===false){fclose($stream);fclose($out);stopPage('تعذر نسخ أحد ملفات التطبيق.');}
        fclose($stream); fclose($out); $files[]=$rel;
    }
    return $files;
}
$message=''; $error=false; $done=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
    if(RESTORE_KEY_HASH==='CHANGE_THIS_TO_SHA256_OF_YOUR_PRIVATE_RECOVERY_PASSWORD')stopPage('لم يتم إعداد كلمة مرور الاستعادة بعد. افتح restore.php وعدّل RESTORE_KEY_HASH كما هو موضح في تعليمات الحزمة.');
    $key=(string)($_POST['recovery_key']??''); if($key===''||!hash_equals(RESTORE_KEY_HASH,hash('sha256',$key)))stopPage('كلمة مرور الاستعادة غير صحيحة.');
    if(empty($_POST['confirm_restore'])||($_POST['confirm_text']??'')!=='استعادة النسخة')stopPage('اكتب عبارة «استعادة النسخة» وفعّل مربع التأكيد للمتابعة.');
    if(!isset($_FILES['backup_zip'])||$_FILES['backup_zip']['error']!==UPLOAD_ERR_OK){ $up=(int)($_FILES['backup_zip']['error']??-1); $why=($up===UPLOAD_ERR_INI_SIZE||$up===UPLOAD_ERR_FORM_SIZE)?'حجم الملف أكبر من حد الرفع المسموح به في PHP.':($up===UPLOAD_ERR_NO_FILE?'لم يتم اختيار ملف ZIP.':'تعذر رفع الملف إلى الخادم (رمز الرفع '.$up.').'); stopPage($why); }
    if($_FILES['backup_zip']['size']>MAX_UPLOAD_BYTES)stopPage('حجم الملف أكبر من الحد المسموح به في صفحة الاستعادة (200 ميجابايت).');
    if(!class_exists('ZipArchive'))stopPage('إضافة ZipArchive غير مفعلة على الاستضافة.');
    $zip=new ZipArchive(); if($zip->open($_FILES['backup_zip']['tmp_name'])!==true)stopPage('تعذر فتح ملف ZIP؛ قد يكون تالفًا.');
    $sqlIndex=false; $cfgIndex=false;
    for($zi=0;$zi<$zip->numFiles;$zi++){
      $entry=str_replace('\\','/',(string)$zip->getNameIndex($zi)); $lower=strtolower($entry);
      if($lower==='database.sql')$sqlIndex=$zi;
      if($lower==='application/config.php')$cfgIndex=$zi;
    }
    if($sqlIndex===false||$cfgIndex===false){$zip->close();stopPage('الملف ليس نسخة احتياطية كاملة صادرة عن الأجندة القانونية؛ ينقصه database.sql أو application/config.php.');}
    $sql=$zip->getFromIndex($sqlIndex); $cfgCode=$zip->getFromIndex($cfgIndex);
    if(!is_string($sql)||$sql===''||!is_string($cfgCode)||$cfgCode===''){$zip->close();stopPage('تعذر قراءة بيانات قاعدة البيانات أو إعداداتها من النسخة.');}
    $archiveCfg=readBackupConfig($cfgCode);
    $mode=(string)($_POST['restore_mode']??'same');
    if($mode==='different'){
      $targetCfg=[
        'db_host'=>trim((string)($_POST['target_db_host']??'')),
        'db_name'=>trim((string)($_POST['target_db_name']??'')),
        'db_user'=>trim((string)($_POST['target_db_user']??'')),
        'db_pass'=>(string)($_POST['target_db_pass']??''),
        'api_key_hash'=>$archiveCfg['api_key_hash']
      ];
      if($targetCfg['db_host']===''||$targetCfg['db_name']===''||$targetCfg['db_user']===''){$zip->close();stopPage('أدخل Host واسم قاعدة البيانات واسم المستخدم لقاعدة البيانات الجديدة.');}
      if(strlen($targetCfg['db_host'])>190||strlen($targetCfg['db_name'])>64||strlen($targetCfg['db_user'])>64||strlen($targetCfg['db_pass'])>1024){$zip->close();stopPage('أحد حقول اتصال قاعدة البيانات الجديدة أطول من المسموح.');}
    } elseif($mode==='same') {
      $targetCfg=$archiveCfg;
    } else {$zip->close();stopPage('اختر طريقة الاستعادة أولًا.');}
    if(!preg_match('/^[A-Za-z0-9_.:-]+$/',$targetCfg['db_host'])){$zip->close();stopPage('صيغة Host غير صحيحة.');}
    $mysqli=@new mysqli($targetCfg['db_host'],$targetCfg['db_user'],$targetCfg['db_pass'],$targetCfg['db_name']);
    if($mysqli->connect_errno){$zip->close();stopPage('تعذر الاتصال بقاعدة البيانات المستهدفة: '.$mysqli->connect_error);}
    if(!$mysqli->set_charset('utf8mb4')){ $mysqli->close();$zip->close();stopPage('تعذر ضبط ترميز قاعدة البيانات.'); }
    // Stage all application files before changing the live database.
    $stage=__DIR__.'/.restore_stage_'.bin2hex(random_bytes(5)); if(!mkdir($stage,0700,true)){$mysqli->close();$zip->close();stopPage('تعذر إنشاء مجلد مؤقت للاستعادة.');}
    try{
      $staged=safeExtractApplication($zip,$stage); if(!$staged){stopPage('النسخة لا تحتوي على ملفات التطبيق.');}
      // Ensure the restored application connects to the selected destination database.
      $stagedConfig=$stage.'/config.php';
      if(file_put_contents($stagedConfig,makeConfig($targetCfg),LOCK_EX)===false)stopPage('تعذر تجهيز config.php لقاعدة البيانات المستهدفة.');
      if(!in_array('config.php',$staged,true))$staged[]='config.php';
      @chmod($stagedConfig,0600);
      $zip->close();
      $count=0; foreach(splitSqlStatements($sql) as $statement){ if(!$mysqli->query($statement))stopPage('فشل استيراد قاعدة البيانات بعد '.$count.' أمرًا: '.$mysqli->error); $count++; }
      $mysqli->close();
      // Copy staged files to web root. Keep this recovery script in place.
      foreach($staged as $rel){$src=$stage.'/'.$rel;$dst=__DIR__.'/'.$rel;$parent=dirname($dst);if(!is_dir($parent)&&!mkdir($parent,0755,true))stopPage('تعذر إنشاء مجلد التطبيق: '.$rel);if(!copy($src,$dst))stopPage('تعذر استعادة ملف التطبيق: '.$rel);}
      $done=true; $message='اكتملت استعادة قاعدة البيانات وملفات التطبيق بنجاح. افتح الصفحة الرئيسية وسجّل الدخول. احتفظ بملف restore.php خارج مجلد الموقع أو احذفه الآن لحماية النظام.';
    } finally {
      if(is_dir($stage)){ $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($stage,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){$f->isDir()?@rmdir($f->getPathname()):@unlink($f->getPathname());}@rmdir($stage); }
    }
 }catch(Throwable $e){$error=true;$message=$e->getMessage();}
}
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>استعادة الأجندة القانونية</title><style>
*{box-sizing:border-box}body{margin:0;background:#f3f5f8;color:#172033;font-family:Tahoma,Arial,sans-serif;line-height:1.7}.wrap{max-width:720px;margin:36px auto;padding:16px}.card{background:#fff;border:1px solid #e1e6ee;border-radius:16px;padding:24px;box-shadow:0 8px 30px #1720330b}h1{font-size:24px;margin:0 0 8px}p{margin:8px 0 16px}.warn{background:#fff6e5;border:1px solid #f0d59b;padding:12px;border-radius:10px;color:#674700;margin:16px 0}.success{background:#eaf8ef;border:1px solid #a8dbb8;padding:14px;border-radius:10px;color:#155b2c}.error{background:#fff0f0;border:1px solid #edb5b5;padding:14px;border-radius:10px;color:#8a2020}.field{margin:16px 0}label{display:block;font-weight:bold;margin-bottom:6px}input[type=password],input[type=file],input[type=text]{width:100%;padding:12px;border:1px solid #cbd3df;border-radius:9px;font:inherit}button{background:#173d70;color:white;border:0;border-radius:9px;padding:13px 20px;font:inherit;font-weight:bold;cursor:pointer;width:100%;margin-top:14px}small{color:#657084}.check{display:flex;gap:9px;align-items:flex-start;font-weight:normal}.check input{margin-top:7px}.choice{display:flex;gap:10px;align-items:flex-start;padding:12px;border:1px solid #d7deea;border-radius:10px;margin:8px 0;font-weight:normal;cursor:pointer}.choice input{margin-top:7px}.choice small,.hint{display:block;color:#657084;font-weight:normal}.target{border:1px solid #b9cbe3;background:#f7faff;padding:14px;border-radius:12px;margin:14px 0}.target h3{margin:0 0 6px;font-size:18px}.target .field{margin:12px 0}
</style></head><body><div class="wrap"><main class="card"><h1>استعادة النسخة الاحتياطية</h1><p>صفحة مستقلة لاستعادة الأجندة القانونية حتى لو كانت ملفات التطبيق غير موجودة.</p>
<?php if($message!==''): ?><div class="<?= $done?'success':($error?'error':'warn') ?>"><?=h($message)?></div><?php endif; ?>
<?php if(!$done): ?><div class="warn"><b>تنبيه مهم:</b> الاستعادة تستبدل بيانات قاعدة البيانات والملفات الحالية بالبيانات الموجودة داخل النسخة. استخدمها فقط إذا كنت متأكدًا، واحتفظ بنسخة من الوضع الحالي أولًا. اختر قاعدة البيانات المستهدفة. في وضع السيرفر المختلف، ارفع صفحة الاستعادة وملف ZIP على السيرفر الجديد أولًا، ثم أدخل بيانات MySQL الجديدة. لا تُرسل بيانات الاتصال إلى أي جهة أخرى.</div>
<form method="post" action="<?=h((string)(parse_url((string)($_SERVER['REQUEST_URI']??$_SERVER['SCRIPT_NAME']), PHP_URL_PATH) ?: (string)($_SERVER['SCRIPT_NAME']??'restore.php')))?>" enctype="multipart/form-data" autocomplete="off">
<div class="field"><label>مكان الاستعادة</label><label class="choice"><input type="radio" name="restore_mode" value="same" checked onchange="toggleTarget(false)"><span><b>نفس السيرفر ونفس قاعدة MySQL</b><small>استخدام بيانات الاتصال المحفوظة داخل النسخة الاحتياطية.</small></span></label><label class="choice"><input type="radio" name="restore_mode" value="different" onchange="toggleTarget(true)"><span><b>سيرفر مختلف وقاعدة MySQL مختلفة</b><small>استخدام بيانات قاعدة البيانات الموجودة على السيرفر الجديد.</small></span></label></div>
<div id="targetDb" class="target" hidden><h3>بيانات قاعدة البيانات الجديدة</h3><p class="hint">أدخل بيانات MySQL التي أنشأتها مسبقًا على السيرفر المستهدف. يجب أن يمتلك المستخدم صلاحية إنشاء الجداول وتعديلها وحذفها.</p><div class="field"><label for="target_host">MySQL Host / Server</label><input id="target_host" name="target_db_host" type="text" placeholder="مثال: sqlXXX.infinityfree.com" autocomplete="off"></div><div class="field"><label for="target_name">اسم قاعدة البيانات</label><input id="target_name" name="target_db_name" type="text" autocomplete="off"></div><div class="field"><label for="target_user">اسم مستخدم MySQL</label><input id="target_user" name="target_db_user" type="text" autocomplete="off"></div><div class="field"><label for="target_pass">كلمة مرور MySQL</label><input id="target_pass" name="target_db_pass" type="password" autocomplete="new-password"><small>سيتم حفظها داخل config.php حتى يستطيع التطبيق الاتصال بقاعدة البيانات الجديدة بعد الاستعادة.</small></div></div>
<div class="field"><label for="key">كلمة مرور الاستعادة</label><input id="key" name="recovery_key" type="password" required autocomplete="off"></div><div class="field"><label for="zip">ملف النسخة الاحتياطية ZIP</label><input id="zip" name="backup_zip" type="file" accept=".zip,application/zip" required><small>الحد الأقصى المبدئي 200 ميجابايت، وقد تفرض الاستضافة حدًا أقل.</small></div><div class="field"><label for="confirm">للتأكيد اكتب: استعادة النسخة</label><input id="confirm" name="confirm_text" type="text" required></div><label class="check"><input type="checkbox" name="confirm_restore" value="1" required><span>أفهم أن العملية ستستبدل قاعدة البيانات المستهدفة وملفات التطبيق في مجلد صفحة الاستعادة.</span></label><button type="submit">بدء الاستعادة</button></form>
<script>function toggleTarget(show){var box=document.getElementById('targetDb');box.hidden=!show;['target_host','target_name','target_user'].forEach(function(id){document.getElementById(id).required=show;});}</script><?php else: ?><p><a href="./">الانتقال إلى التطبيق</a></p><?php endif; ?>
</main></div></body></html>
