/* Fajar QC web app: UI, local storage, sharing, sync. Uses window.FajarCore. */
(function () {
  'use strict';
  var C = window.FajarCore;
  var KEY_R = 'fajarqc.reports.v1';
  var KEY_S = 'fajarqc.settings.v1';
  var DEFAULTS = { name: 'Lab technician', email: '', endpoint: '', autoSend: false, whatsapp: '', gateway: '',
    theme: 'auto', view: 'auto', photo: '', signedIn: true };
  var TITLES = {
    dashboard: ['Dashboard', 'Laboratory activity at a glance'],
    reports: ['Reports', 'Search, review and manage your register'],
    editor: ['Report', 'Fill in the fields and test rows'],
    preview: ['Live Preview', 'A4 fertilizer test report sheet'],
    export: ['Print & Download', 'Export monthly reports and protect local data'],
    settings: ['Account Settings', 'Profile, sync, theme and local data'],
    signin: ['Sign in', 'Continue to the laboratory register']
  };

  var state = {
    reports: [], settings: clone(DEFAULTS), view: 'dashboard', currentId: null, shareId: null,
    query: '', chip: 'all', from: '', to: '', month: C.todayIso().slice(0, 7),
    logo: null, deferredPrompt: null, saveTimer: null
  };

  var h = C.esc;
  function $(s) { return document.querySelector(s); }
  function $$(s) { return Array.prototype.slice.call(document.querySelectorAll(s)); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function setText(sel, t) { var el = $(sel); if (el) el.textContent = t; }

  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._h);
    t._h = setTimeout(function () { t.classList.remove('show'); }, 3800);
  }

  function isWide() {
    if (state.settings.view === 'mobile') return false;
    if (state.settings.view === 'desktop') return true;
    return window.matchMedia('(min-width: 960px)').matches;
  }

  /* ---------- storage ---------- */
  function load() {
    try {
      var r = JSON.parse(localStorage.getItem(KEY_R) || '[]');
      state.reports = Array.isArray(r) ? r.map(C.normalizeReport).filter(Boolean) : [];
    } catch (e) { state.reports = []; toast('Saved reports could not be read. Restore a backup if you have one.'); }
    try {
      var s = JSON.parse(localStorage.getItem(KEY_S) || 'null');
      if (s && typeof s === 'object') state.settings = Object.assign(clone(DEFAULTS), C.pickSettings(s), { signedIn: s.signedIn !== false });
    } catch (e) { /* keep defaults */ }
  }

  function persist() {
    try {
      localStorage.setItem(KEY_R, JSON.stringify(state.reports));
      localStorage.setItem(KEY_S, JSON.stringify(state.settings));
      setText('#saveState', 'Saved on this device ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      return true;
    } catch (e) {
      toast('Device storage is full. Export a backup, then remove old reports.');
      return false;
    }
  }

  function scheduleSave() {
    clearTimeout(state.saveTimer);
    state.saveTimer = setTimeout(persist, 400);
  }

  function current() {
    for (var i = 0; i < state.reports.length; i++) if (state.reports[i].id === state.currentId) return state.reports[i];
    return null;
  }
  function findReport(id) {
    for (var i = 0; i < state.reports.length; i++) if (state.reports[i].id === id) return state.reports[i];
    return null;
  }
  function touch(r) {
    r.updatedAt = new Date().toISOString();
    if (r.status === 'final') r.synced = false;
    scheduleSave();
  }

  /* ---------- navigation ---------- */
  function navKey() { return state.view === 'editor' ? 'reports' : state.view; }

  function go(view) {
    state.view = view;
    closeDrawer();
    render();
    window.scrollTo(0, 0);
  }

  function openDrawer() {
    $('#drawer').classList.add('open');
    $('#drawer').inert = false;
    $('.scrim').hidden = false;
  }
  function closeDrawer() {
    $('#drawer').classList.remove('open');
    $('.scrim').hidden = true;
    syncDrawerInert();
  }
  // A closed off-canvas drawer must not be reachable by keyboard or screen readers (phones only).
  function syncDrawerInert() {
    $('#drawer').inert = !isWide() && !$('#drawer').classList.contains('open');
  }

  function render() {
    document.body.classList.toggle('is-wide', isWide());
    syncDrawerInert();
    document.documentElement.setAttribute('data-theme', state.settings.theme || 'auto');
    var nk = navKey();
    $$('[data-nav]').forEach(function (b) {
      var on = b.getAttribute('data-nav') === nk;
      b.classList.toggle('active', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    $$('main > section').forEach(function (s) { s.hidden = s.getAttribute('data-view') !== state.view; });
    var t = TITLES[state.view] || TITLES.dashboard;
    setText('#pageTitle', t[0]);
    setText('#pageSub', t[1]);
    setText('#drawerName', state.settings.name || 'Lab technician');
    setText('#drawerEmail', state.settings.email || 'No email set');
    $('#avatar').innerHTML = avatarHtml();
    $('#drawerAvatar').innerHTML = avatarHtml();
    var map = {
      dashboard: renderDashboard, reports: renderReports, editor: renderEditor,
      preview: renderPreview, export: renderExport, settings: renderSettings, signin: renderSignin
    };
    if (map[state.view]) map[state.view]();
  }

  function avatarHtml() {
    if (state.settings.photo) return '<img src="' + h(state.settings.photo) + '" alt="">';
    return h((state.settings.name || 'L').trim().charAt(0).toUpperCase() || 'L');
  }

  /* ---------- helpers ---------- */
  function pill(r) {
    if (r.status === 'draft') return '<span class="pill draft">DRAFT</span>';
    var v = C.verdictOf(r).effective;
    return '<span class="pill ' + (v === 'FIT' ? 'fit' : 'unfit') + '">' + v + '</span>';
  }

  function emptyBox(title, text) {
    return '<div class="card empty"><h3>' + h(title) + '</h3><p class="muted">' + h(text) + '</p>' +
      '<button class="btn primary" data-act="new">+ Create report</button></div>';
  }

  function monthsBack(n) {
    var out = [], d = new Date();
    for (var i = n - 1; i >= 0; i--) {
      var x = new Date(d.getFullYear(), d.getMonth() - i, 1);
      out.push(x.getFullYear() + '-' + C.pad2(x.getMonth() + 1));
    }
    return out;
  }

  function shiftMonth(delta) {
    var p = state.month.split('-');
    var d = new Date(+p[0], +p[1] - 1 + delta, 1);
    state.month = d.getFullYear() + '-' + C.pad2(d.getMonth() + 1);
    renderExport();
  }

  function monthlyReports() {
    return state.reports.filter(function (r) { return r.status === 'final' && C.monthKey(r) === state.month; });
  }

  function fileName(r) {
    var safe = function (s) { return String(s || 'NA').replace(/[^A-Za-z0-9_-]+/g, '_').slice(0, 40); };
    return 'FQC_' + safe(r.fields.product) + '_' + safe(r.fields.sampleId) + '_' + C.reportDate(r);
  }

  function requireProduct(r) {
    if (String(r.fields.product || '').trim()) return true;
    toast('Enter the product name first.');
    var f = $('#f-product');
    if (f) f.focus();
    return false;
  }

  /* ---------- dashboard ---------- */
  function renderDashboard() {
    var s = C.stats(state.reports, C.todayIso());
    var pending = state.reports.filter(function (r) { return r.status === 'final' && !r.synced; }).length;
    var months = monthsBack(6);
    var maxM = 1;
    months.forEach(function (m) { maxM = Math.max(maxM, s.byMonth[m] || 0); });
    var bars = months.map(function (m) {
      var c = s.byMonth[m] || 0;
      return '<div class="bar-col"><span class="bar-val">' + c + '</span><div class="bar" style="height:' +
        Math.max(4, Math.round(c / maxM * 100)) + '%"></div><small>' + C.monthLabel(m).slice(0, 3) + '</small></div>';
    }).join('');
    var maxC = Math.max(1, s.byCategory.raw, s.byCategory.batch, s.byCategory.external);
    var cats = Object.keys(C.CATEGORIES).map(function (k) {
      var c = s.byCategory[k];
      return '<div class="hbar"><span>' + C.CATEGORIES[k] + '</span><div class="track"><i style="width:' +
        Math.round(c / maxC * 100) + '%"></i></div><b>' + c + '</b></div>';
    }).join('');
    var recent = state.reports.filter(function (r) { return r.status === 'final'; })
      .sort(function (a, b) { return C.reportDate(b).localeCompare(C.reportDate(a)); }).slice(0, 5);
    var recentHtml = recent.length ? recent.map(function (r) {
      return '<button class="mini" data-act="open" data-id="' + h(r.id) + '"><span><b>' + h(r.fields.product || 'Untitled') +
        '</b><small>' + C.fmtDate(C.reportDate(r)) + ' · ' + C.CATEGORIES[r.category] + '</small></span>' + pill(r) + '</button>';
    }).join('') : '<p class="muted">No submitted reports yet. Drafts stay in Reports and are not counted.</p>';

    var empty = s.total === 0 && state.reports.length === 0;
    $('#view-dashboard').innerHTML =
      '<div class="card conn"><div class="conn-ico">' + (navigator.onLine ? '●' : '○') + '</div><div>' +
      '<b>' + (navigator.onLine ? 'Online' : 'Offline') + '</b><small>' +
      (state.settings.endpoint ? (pending ? pending + ' final report(s) waiting to sync' : 'All final reports synced') :
        'Reports stay on this device until you configure an endpoint.') + '</small></div><span class="tag">LOCAL</span></div>' +
      (empty ? emptyBox('No reports yet', 'Create a report to start tracking fertilizer test results.') : '') +
      '<h2 class="sec">Overview</h2><p class="muted">Submitted reports only</p>' +
      '<div class="stats">' +
      stat('Total reports', s.total) + stat('Company', s.company) + stat('External', s.external) + stat('FIT', s.fit) +
      stat('UNFIT', s.unfit) + stat('Pass rate', s.passRate === null ? '—' : s.passRate + '%') +
      stat('Latest date', s.latest ? C.fmtDate(s.latest) : '—') + stat('This month', s.thisMonth) +
      '</div>' +
      '<div class="two-col"><div class="card"><h3>Reports per month</h3><div class="bars">' + bars + '</div></div>' +
      '<div class="card"><h3>Reports by category</h3>' + cats + '</div></div>' +
      '<h2 class="sec">Recent reports</h2><div class="stack">' + recentHtml + '</div>' +
      (state.deferredPrompt ? '<button class="btn" data-act="install">Install Fajar QC on this device</button>' : '');
  }

  function stat(label, value) {
    return '<div class="stat"><b>' + h(value) + '</b><small>' + h(label) + '</small></div>';
  }

  /* ---------- reports list ---------- */
  function renderReports() {
    $('#view-reports').innerHTML =
      '<div class="card"><label class="field" for="q"><span>Search reports</span>' +
      '<input id="q" type="search" data-search value="' + h(state.query) + '" placeholder="Product, sample ID, batch…"></label>' +
      '<div class="chips" role="group" aria-label="Category filter">' +
      [['all', 'All'], ['company', 'Company'], ['raw', 'Raw'], ['batch', 'Batch'], ['external', 'External']].map(function (c) {
        return '<button class="chip" data-chip="' + c[0] + '" aria-pressed="false">' + c[1] + '</button>';
      }).join('') + '</div>' +
      '<div class="two-col"><label class="field"><span>From date</span><input type="date" data-from value="' + h(state.from) + '"></label>' +
      '<label class="field"><span>To date</span><input type="date" data-to value="' + h(state.to) + '"></label></div></div>' +
      '<h2 class="sec">Report register</h2><p class="muted" id="reportCount"></p><div id="reportList" class="stack"></div>';
    renderReportList();
  }

  function renderReportList() {
    var list = C.filterReports(state.reports, { query: state.query, chip: state.chip, from: state.from, to: state.to });
    var cnt = $('#reportCount');
    if (cnt) cnt.textContent = list.length + ' matching report' + (list.length === 1 ? '' : 's') + ' · newest first';
    var box = $('#reportList');
    if (!box) return;
    if (!list.length) {
      box.innerHTML = state.reports.length ? '<p class="muted card">No reports match these filters.</p>' :
        emptyBox('No reports yet', 'Tap + to create the first fertilizer test report.');
    } else {
      box.innerHTML = list.map(reportCard).join('');
    }
    $$('[data-chip]').forEach(function (b) {
      var on = b.getAttribute('data-chip') === state.chip;
      b.classList.toggle('on', on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }

  function reportCard(r) {
    var id = h(r.id);
    return '<article class="card rcard"><div class="rtop"><div><h3>' + h(r.fields.product || 'Untitled product') + '</h3>' +
      '<p class="muted">' + C.CATEGORIES[r.category] + ' · ' + C.fmtDate(C.reportDate(r)) + '</p></div>' + pill(r) + '</div>' +
      '<div class="rmeta"><span>Sample ID <b>' + h(C.displayValue(r, 'sampleId')) + '</b></span>' +
      '<span>Batch <b>' + h(C.displayValue(r, 'batchNo')) + '</b></span></div>' +
      '<div class="ractions">' +
      '<button class="btn sm" data-act="open" data-id="' + id + '">Open</button>' +
      '<button class="btn sm" data-act="pdf" data-id="' + id + '">PDF</button>' +
      '<button class="btn sm" data-act="share" data-id="' + id + '">Share</button>' +
      '<button class="btn sm danger" data-act="delete" data-id="' + id + '">Delete</button></div></article>';
  }

  /* ---------- editor ---------- */
  function fieldInput(r, key) {
    var v = h(r.fields[key]);
    var id = key === 'product' ? ' id="f-product"' : '';
    if (key === 'sampleSize') {
      return '<select data-field="sampleSize"><option value="">Select</option>' +
        C.SAMPLE_SIZES.map(function (s) { return '<option' + (s === r.fields[key] ? ' selected' : '') + '>' + s + '</option>'; }).join('') +
        '</select>';
    }
    if (C.DATE_KEYS.indexOf(key) >= 0) return '<input type="date" data-field="' + key + '" value="' + v + '">';
    return '<input' + id + ' type="text" data-field="' + key + '" value="' + v + '" maxlength="200">';
  }

  function fieldCell(r, label, key) {
    if (!key) return '<div class="fld blank"></div>';
    return '<label class="fld"><span>' + h(label) + '</span>' + fieldInput(r, key) + '</label>';
  }

  function renderEditor() {
    var r = current();
    var el = $('#view-editor');
    if (!r) { el.innerHTML = '<p class="muted card">No report selected.</p>'; return; }
    var fields = C.PAIRS.map(function (p) { return fieldCell(r, p[0], p[1]) + fieldCell(r, p[2], p[3]); }).join('');
    var extras = r.extras.map(function (e, i) {
      return '<div class="extra"><input data-extra-label data-i="' + i + '" value="' + h(e.label) + '" placeholder="Label" aria-label="Extra field label">' +
        '<input data-extra-value data-i="' + i + '" value="' + h(e.value) + '" placeholder="Value" aria-label="Extra field value">' +
        '<button class="btn sm danger" data-act="extra-del" data-i="' + i + '">Remove</button></div>';
    }).join('');
    var tests = r.tests.map(function (t, i) {
      var cell = function (col, val, label) {
        return '<td><input data-test data-col="' + col + '" data-i="' + i + '" value="' + h(val) + '" aria-label="' + label + '"></td>';
      };
      return '<tr>' + cell('name', t.name, 'Test name') + cell('spec', t.spec, 'Specification') +
        cell('result', t.result, 'Result') + cell('method', t.method, 'Method') + cell('remarks', t.remarks, 'Remarks') +
        '<td><span class="badge none" data-badge="' + i + '">—</span></td>' +
        '<td class="row-tools">' +
        '<button class="btn sm icon" data-act="test-up" data-i="' + i + '" aria-label="Move row up">↑</button>' +
        '<button class="btn sm icon" data-act="test-down" data-i="' + i + '" aria-label="Move row down">↓</button>' +
        '<button class="btn sm icon danger" data-act="test-del" data-i="' + i + '" aria-label="Delete row">✕</button></td></tr>';
    }).join('');
    var remarks = r.remarks.map(function (t, i) {
      return '<label class="fld wide"><span>' + (i + 1) + '.</span><textarea rows="2" data-remark data-i="' + i + '">' + h(t) + '</textarea></label>';
    }).join('');
    var cats = Object.keys(C.CATEGORIES).map(function (k) {
      var on = r.category === k;
      return '<button class="seg" data-cat="' + k + '" aria-pressed="' + on + '">' + C.CATEGORIES[k] + '</button>';
    }).join('');

    el.innerHTML =
      '<div class="card"><div class="rtop"><div><h3>Report details</h3><p class="muted" id="saveState"></p></div>' + pill(r) + '</div>' +
      '<p class="warn" id="productHint" hidden>Enter the product name to enable PDF and finalizing.</p>' +
      '<div class="seg-row" role="group" aria-label="Category">' + cats + '</div>' +
      '<div class="form-grid">' + fields + '</div></div>' +
      '<div class="card"><h3>Extra fields</h3><div class="stack">' + (extras || '<p class="muted">None added.</p>') + '</div>' +
      '<button class="btn" data-act="extra-add">+ Add “Label: value” field</button></div>' +
      '<div class="card"><h3>Tests</h3><p class="muted">Specifications like 40%(+-5), min 40 and 35-45 are checked automatically.</p>' +
      '<div class="table-wrap"><table class="edit"><thead><tr><th>Tests</th><th>Specification</th><th>Results</th><th>Methods</th><th>Remarks</th><th>Check</th><th></th></tr></thead>' +
      '<tbody>' + tests + '</tbody></table></div>' +
      '<button class="btn" data-act="test-add">+ Add test row</button></div>' +
      '<div class="card"><h3>Verdict</h3><div class="verdict-box"><div>Automatic: <b id="verdictAuto"></b></div>' +
      '<div>Printed verdict: <b id="verdictFinal"></b></div></div>' +
      '<label class="field"><span>Override verdict</span><select data-verdict>' +
      '<option value="">Automatic</option>' +
      '<option value="FIT"' + (r.verdictOverride === 'FIT' ? ' selected' : '') + '>FIT</option>' +
      '<option value="UNFIT"' + (r.verdictOverride === 'UNFIT' ? ' selected' : '') + '>UNFIT</option></select></label></div>' +
      '<div class="card"><h3>Overall remarks</h3><div class="form-grid">' + remarks + '</div></div>' +
      '<div class="actions">' +
      '<button class="btn" data-act="save">Save draft</button>' +
      '<button class="btn" data-act="preview">Preview sheet</button>' +
      '<button class="btn" data-act="pdf-current" data-needs-product>Create PDF</button>' +
      (r.status === 'draft' ? '<button class="btn primary" data-act="finalize" data-needs-product>Finalize report</button>' :
        '<button class="btn" data-act="reopen">Reopen as draft</button>') +
      '<button class="btn danger" data-act="delete-current">Delete</button></div>';
    updateComputed();
    setText('#saveState', 'Autosaved on this device');
  }

  function updateComputed() {
    var r = current();
    if (!r) return;
    var v = C.verdictOf(r);
    setText('#verdictAuto', v.auto + ' (' + v.evaluated + ' test' + (v.evaluated === 1 ? '' : 's') + ' checked)');
    setText('#verdictFinal', v.effective);
    $$('[data-badge]').forEach(function (el) {
      var b = v.evals[+el.getAttribute('data-badge')];
      el.textContent = b || '—';
      el.className = 'badge ' + (b ? b.toLowerCase() : 'none');
    });
    var has = !!String(r.fields.product || '').trim();
    var hint = $('#productHint');
    if (hint) hint.hidden = has;
    $$('[data-needs-product]').forEach(function (b) { b.disabled = !has; });
  }

  /* ---------- preview ---------- */
  function renderPreview() {
    var sorted = state.reports.slice().sort(function (a, b) { return C.reportDate(b).localeCompare(C.reportDate(a)); });
    var r = current();
    if (!r && sorted.length) { state.currentId = sorted[0].id; r = sorted[0]; }
    var el = $('#view-preview');
    if (!r) { el.innerHTML = emptyBox('Nothing to preview', 'Create a report first.'); return; }
    var picks = sorted.map(function (x) {
      return '<button class="chip' + (x.id === r.id ? ' on' : '') + '" data-pick="' + h(x.id) + '" aria-pressed="' + (x.id === r.id) + '">' +
        h(x.fields.product || 'Untitled draft') + '</button>';
    }).join('');
    el.innerHTML =
      '<div class="card"><h3>Choose a report</h3><p class="muted">The sheet updates as you edit fields.</p>' +
      '<div class="chips scroll-x">' + picks + '</div></div>' +
      '<div class="sheet-meta"><span>A4 · 210 × 297 mm</span>' + pill(r) + '</div>' +
      '<div class="sheet-scroll" tabindex="0" aria-label="Report sheet preview, scroll sideways if needed">' +
      C.sheetHtml(r, { logoSrc: state.logo ? state.logo.dataUrl : 'assets/fajar-logo.png' }) + '</div>' +
      '<div class="actions"><button class="btn" data-act="edit">Edit report</button>' +
      '<button class="btn primary" data-act="pdf-current" data-needs-product' + (String(r.fields.product || '').trim() ? '' : ' disabled') + '>Create PDF</button>' +
      '<button class="btn" data-act="share-current">Share</button></div>' +
      (String(r.fields.product || '').trim() ? '' : '<p class="warn">Enter a product name in Edit report to enable PDF creation.</p>');
  }

  /* ---------- export ---------- */
  function renderExport() {
    var list = monthlyReports();
    var s = { fit: 0, unfit: 0, ext: 0 };
    list.forEach(function (r) {
      if (C.verdictOf(r).effective === 'FIT') s.fit++; else s.unfit++;
      if (r.category === 'external') s.ext++;
    });
    var none = list.length === 0;
    $('#view-export').innerHTML =
      '<div class="card"><h2 class="card-h">Monthly report</h2><p class="muted">Final reports for the selected month. Drafts are excluded.</p>' +
      '<div class="month-nav"><button class="btn icon" data-act="month-prev" aria-label="Previous month">‹</button>' +
      '<div><b>' + C.monthLabel(state.month) + '</b><small>' + list.length + ' report' + (list.length === 1 ? '' : 's') + '</small></div>' +
      '<button class="btn icon" data-act="month-next" aria-label="Next month">›</button></div>' +
      '<div class="stats three"><div class="stat"><b>' + s.fit + '</b><small>FIT</small></div>' +
      '<div class="stat"><b>' + s.unfit + '</b><small>UNFIT</small></div>' +
      '<div class="stat"><b>' + s.ext + '</b><small>EXTERNAL</small></div></div>' +
      '<div class="stack">' +
      '<button class="btn primary" data-act="export-pdf"' + (none ? ' disabled' : '') + '>Download PDF (summary + every sheet)</button>' +
      '<button class="btn" data-act="export-xml"' + (none ? ' disabled' : '') + '>Excel XML (SpreadsheetML)</button>' +
      '<button class="btn" data-act="export-doc"' + (none ? ' disabled' : '') + '>Word-compatible .doc</button>' +
      '<button class="btn" data-act="import-xml-btn">Import SpreadsheetML XML</button></div>' +
      (none ? '<p class="muted">No finalized reports for this month. Select another month or finalize a draft.</p>' : '') +
      '</div>' +
      '<div class="card"><h2 class="card-h">Local backup</h2><p class="muted">Export or restore reports and settings without a server.</p>' +
      '<p class="notice">Backup files contain report data and account settings. Store them somewhere private.</p>' +
      '<div class="stack">' +
      '<button class="btn primary" data-act="export-json">Export JSON backup</button>' +
      '<button class="btn" data-act="import-json-btn">Import JSON file</button>' +
      '<button class="btn" data-act="copy-json">Copy backup JSON</button>' +
      '<button class="btn" data-act="restore-clip">Restore from clipboard</button>' +
      '<label class="field"><span>Or paste backup text here</span><textarea id="pasteBox" rows="3" placeholder="Paste the JSON backup text"></textarea></label>' +
      '<button class="btn" data-act="restore-paste">Restore pasted text</button></div>' +
      '<p class="muted">Restoring replaces all current local reports and settings after you confirm.</p></div>' +
      '<p class="notice info">PDFs and documents are created on this device. Sharing opens your system chooser; this app never sends email or WhatsApp silently.</p>';
  }

  /* ---------- settings ---------- */
  function renderSettings() {
    var s = state.settings;
    var seg = function (key, opts, cur) {
      return opts.map(function (o) {
        return '<button class="seg' + (cur === o[0] ? ' on' : '') + '" data-' + key + '="' + o[0] + '" aria-pressed="' + (cur === o[0]) + '">' + o[1] + '</button>';
      }).join('');
    };
    var pending = state.reports.filter(function (r) { return r.status === 'final' && !r.synced; }).length;
    $('#view-settings').innerHTML =
      '<div class="card"><h3>Profile</h3><p class="muted">Shown in the navigation drawer. Your profile stays on this device.</p>' +
      '<div class="profile-row"><span class="avatar big">' + avatarHtml() + '</span>' +
      '<label class="btn sm">Change photo<input type="file" accept="image/*" data-photo hidden></label>' +
      (s.photo ? '<button class="btn sm" data-act="remove-photo">Remove</button>' : '') + '</div>' +
      '<label class="field"><span>Name</span><input data-set="name" value="' + h(s.name) + '" placeholder="Your name"></label>' +
      '<label class="field"><span>Email for report storage</span><input type="email" data-set="email" value="' + h(s.email) + '" placeholder="name@example.com"></label></div>' +
      '<div class="card"><h3>Sync &amp; delivery</h3><p class="muted">Local saving always works. Online transfer needs your endpoint.</p>' +
      '<label class="field"><span>Sync endpoint URL (https)</span><input type="url" data-set="endpoint" value="' + h(s.endpoint) + '" placeholder="https://your-service.example/reports"></label>' +
      '<label class="toggle"><input type="checkbox" data-set-bool="autoSend"' + (s.autoSend ? ' checked' : '') + '><span><b>Auto-send finalized reports</b><small>Drafts are never sent. Unsent final reports retry when the device reconnects.</small></span></label>' +
      '<label class="field"><span>WhatsApp number</span><input type="tel" data-set="whatsapp" value="' + h(s.whatsapp) + '" placeholder="Country code + number"></label>' +
      '<label class="field"><span>Optional WhatsApp gateway URL</span><input type="url" data-set="gateway" value="' + h(s.gateway) + '" placeholder="https://gateway.example/send?phone={phone}&amp;text={text}"></label>' +
      '<p class="notice info">Email and WhatsApp are never sent silently. Sharing opens the app you choose.</p>' +
      '<p class="muted">' + (navigator.onLine ? '● Internet connection available' : '○ Offline') + ' · ' + pending + ' final report(s) waiting</p>' +
      '<button class="btn" data-act="sync">Sync pending reports now</button></div>' +
      '<div class="card"><h3>Appearance</h3><p class="muted">Choose a theme and display view.</p>' +
      '<h4>Theme</h4><div class="seg-row">' + seg('theme', [['auto', 'Auto'], ['light', 'Light'], ['dark', 'Dark']], s.theme) + '</div>' +
      '<h4>Display view</h4><div class="seg-row">' + seg('view', [['auto', 'Auto'], ['mobile', 'Mobile'], ['desktop', 'Desktop']], s.view) + '</div></div>' +
      '<div class="card"><h3>Install &amp; device data</h3>' +
      '<p class="muted">' + state.reports.length + ' report(s) stored on this device.</p>' +
      (state.deferredPrompt ? '<button class="btn primary" data-act="install">Install app</button>' :
        '<p class="notice info">To install: open the Chrome menu (⋮) and tap “Install app” or “Add to Home screen”. Works offline after the first load.</p>') +
      '<button class="btn" data-act="sample">Add sample reports</button>' +
      '<button class="btn danger" data-act="clear-all">Delete all local reports</button>' +
      '<p class="notice">Drafts and reports are stored on this device only. Back up from Print &amp; Download before clearing.</p></div>' +
      '<button class="btn danger wide" data-act="signout">Sign out</button>';
  }

  function renderSignin() {
    $('#view-signin').innerHTML =
      '<div class="card signin"><h2 class="card-h">Welcome back</h2><p class="muted">Enter your name to open the register on this device.</p>' +
      '<label class="field"><span>Name</span><input id="signinName" value="' + h(state.settings.name) + '" placeholder="Your name"></label>' +
      '<button class="btn primary" data-act="signin">Sign in</button></div>';
  }

  /* ---------- sharing ---------- */
  function download(blob, name) {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }

  async function shareBlob(blob, name, type, title) {
    var file = new File([blob], name, { type: type });
    if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
      try { await navigator.share({ files: [file], title: title || name }); return true; }
      catch (e) { if (e && e.name === 'AbortError') return false; }
    }
    download(blob, name);
    toast('Sharing is not available here, so the file was downloaded.');
    return false;
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch (e) {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (_) { ok = false; }
      ta.remove();
      return ok;
    }
  }

  function loadLogo() {
    if (state.logo) return Promise.resolve(state.logo);
    return new Promise(function (resolve) {
      var img = new Image();
      img.onload = function () {
        try {
          var W = 240, H = Math.round(240 * img.naturalHeight / img.naturalWidth);
          var cv = document.createElement('canvas');
          cv.width = W; cv.height = H;
          var ctx = cv.getContext('2d');
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, W, H);
          ctx.drawImage(img, 0, 0, W, H);
          var px = ctx.getImageData(0, 0, W, H).data;
          var rgb = new Uint8Array(W * H * 3);
          for (var i = 0, j = 0; i < px.length; i += 4) { rgb[j++] = px[i]; rgb[j++] = px[i + 1]; rgb[j++] = px[i + 2]; }
          state.logo = { width: W, height: H, data: rgb, dataUrl: cv.toDataURL('image/png') };
          resolve(state.logo);
        } catch (e) { resolve(null); }
      };
      img.onerror = function () { resolve(null); };
      img.src = 'assets/fajar-logo.png';
    });
  }

  async function makePdf(r) {
    var logo = await loadLogo();
    var bytes = C.buildPdf(C.buildReportPages(r, !!logo), logo);
    return new Blob([bytes], { type: 'application/pdf' });
  }

  async function pdfForReport(r) {
    if (!requireProduct(r)) return;
    try {
      download(await makePdf(r), fileName(r) + '.pdf');
      toast('PDF created and downloaded.');
    } catch (e) { toast('Could not create the PDF: ' + e.message); }
  }

  function summaryText(r) {
    var v = C.verdictOf(r).effective;
    return ['Fajar Chemicals QC report', 'Product: ' + C.displayValue(r, 'product'), 'Sample ID: ' + C.displayValue(r, 'sampleId'),
      'Batch No.: ' + C.displayValue(r, 'batchNo'), 'Date: ' + C.fmtDate(C.reportDate(r)), 'Category: ' + C.CATEGORIES[r.category],
      'Verdict: ' + v, (state.settings.name ? 'From: ' + state.settings.name : '')].filter(Boolean).join('\n');
  }

  function openShare(id) {
    state.shareId = id;
    var r = findReport(id);
    if (!r) return;
    var dlg = $('#shareDlg');
    var hasWa = !!String(state.settings.whatsapp || '').replace(/\D/g, '');
    var hasGw = !!state.settings.gateway;
    $('#shareBody').innerHTML =
      '<h3>Share “' + h(r.fields.product || 'Untitled') + '”</h3>' +
      '<p class="muted">Sharing happens only when you tap a button.</p>' +
      '<div class="stack">' +
      '<button class="btn primary" data-act="share-pdf">Share PDF file</button>' +
      '<button class="btn" data-act="share-wa">WhatsApp message' + (hasWa ? '' : ' (no number set)') + '</button>' +
      (hasGw ? '<button class="btn" data-act="share-gateway">Open WhatsApp gateway link</button>' : '') +
      '<button class="btn" data-act="share-mail">Email summary</button>' +
      '<button class="btn" data-act="share-copy">Copy summary</button>' +
      '<button class="btn" data-act="share-close">Close</button></div>';
    if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
  }

  function closeShare() {
    var dlg = $('#shareDlg');
    if (dlg.close) dlg.close(); else dlg.removeAttribute('open');
  }

  /* ---------- report actions ---------- */
  function createReport() {
    var r = C.makeReport();
    state.reports.push(r);
    state.currentId = r.id;
    persist();
    go('editor');
  }

  function deleteReport(id) {
    var r = findReport(id);
    if (!r) return;
    if (!confirm('Delete this report from this device? This cannot be undone.')) return;
    state.reports = state.reports.filter(function (x) { return x.id !== id; });
    if (state.currentId === id) state.currentId = null;
    persist();
    toast('Report deleted.');
    render();
  }

  function finalize() {
    var r = current();
    if (!r || !requireProduct(r)) return;
    r.status = 'final';
    r.finalizedAt = new Date().toISOString();
    r.updatedAt = r.finalizedAt;
    r.synced = false;
    persist();
    if (state.settings.autoSend && state.settings.endpoint) syncPending(false);
    toast('Report finalized and saved on this device.');
    go('reports');
  }

  /* ---------- sync ---------- */
  async function syncPending(manual) {
    var s = state.settings;
    if (!s.endpoint) { if (manual) toast('Add a sync endpoint in Settings first.'); return; }
    if (!navigator.onLine) { if (manual) toast('Offline. Pending reports will sync when you are online.'); return; }
    var pending = state.reports.filter(function (r) { return r.status === 'final' && !r.synced; });
    if (!pending.length) { if (manual) toast('Nothing to sync.'); return; }
    var ok = 0, failed = 0;
    for (var i = 0; i < pending.length; i++) {
      var r = pending[i];
      try {
        var res = await fetch(s.endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ report: r, sender: { name: s.name, email: s.email, whatsapp: s.whatsapp } })
        });
        if (res.ok) { r.synced = true; ok++; } else failed++;
      } catch (e) { failed++; }
    }
    persist();
    toast('Synced ' + ok + ' report(s).' + (failed ? ' ' + failed + ' failed and will retry.' : ''));
    render();
  }

  /* ---------- import / backup ---------- */
  function importData(text, kind) {
    var res = kind === 'xml' ? C.parseXml(text) : C.validateBackup(text);
    if (!res.ok) { toast(res.error); return; }
    var n = res.reports.length;
    if (!n && kind === 'xml') { toast('No reports found in that file.'); return; }
    var msg = kind === 'json'
      ? 'Restoring will REPLACE all reports and settings on this device with the ' + n + ' report(s) in this backup. Continue?'
      : 'Import ' + n + ' report(s)? Reports with the same ID will be replaced; others are kept. Continue?';
    if (!confirm(msg)) return;
    if (kind === 'json') {
      state.reports = res.reports;
      if (res.settings) state.settings = Object.assign(clone(DEFAULTS), state.settings, res.settings);
    } else {
      res.reports.forEach(function (nr) {
        var i = state.reports.findIndex(function (x) { return x.id === nr.id; });
        if (i >= 0) state.reports[i] = nr; else state.reports.push(nr);
      });
    }
    state.currentId = null;
    persist();
    toast('Imported ' + n + ' report(s).');
    render();
  }

  async function exportMonthly(kind) {
    var list = monthlyReports();
    if (!list.length) { toast('No finalized reports for this month.'); return; }
    var base = 'Fajar_QC_' + state.month;
    try {
      if (kind === 'pdf') {
        var logo = await loadLogo();
        var bytes = C.buildPdf(C.buildMonthlyPages(list, state.month, !!logo), logo);
        await shareBlob(new Blob([bytes], { type: 'application/pdf' }), base + '.pdf', 'application/pdf', base);
      } else if (kind === 'xml') {
        download(new Blob([C.buildXml(list)], { type: 'application/vnd.ms-excel' }), base + '.xml');
      } else if (kind === 'doc') {
        var lg = await loadLogo();
        var html = C.buildDoc(list, C.monthLabel(state.month), { logoSrc: lg ? lg.dataUrl : '' });
        download(new Blob([html], { type: 'application/msword' }), base + '.doc');
      }
    } catch (e) { toast('Export failed: ' + e.message); }
  }

  /* ---------- photo ---------- */
  function resizePhoto(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onerror = reject;
      reader.onload = function () {
        var img = new Image();
        img.onload = function () {
          var S = 128, cv = document.createElement('canvas');
          cv.width = S; cv.height = S;
          var ctx = cv.getContext('2d');
          var m = Math.min(img.naturalWidth, img.naturalHeight);
          ctx.drawImage(img, (img.naturalWidth - m) / 2, (img.naturalHeight - m) / 2, m, m, 0, 0, S, S);
          resolve(cv.toDataURL('image/jpeg', 0.85));
        };
        img.onerror = reject;
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  /* ---------- event wiring ---------- */
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-act],[data-nav],[data-cat],[data-pick],[data-chip],[data-close],[data-open-drawer],[data-theme],[data-view],[data-set-bool]');
    if (!el) return;
    if (el.hasAttribute('data-open-drawer')) { openDrawer(); return; }
    if (el.hasAttribute('data-close')) { closeDrawer(); return; }
    if (el.hasAttribute('data-nav')) { go(el.getAttribute('data-nav')); return; }
    if (el.hasAttribute('data-cat')) { var rc = current(); if (rc) { rc.category = el.getAttribute('data-cat'); touch(rc); renderEditor(); } return; }
    if (el.hasAttribute('data-pick')) { state.currentId = el.getAttribute('data-pick'); renderPreview(); return; }
    if (el.hasAttribute('data-chip')) { state.chip = el.getAttribute('data-chip'); renderReportList(); return; }
    if (el.hasAttribute('data-theme')) { state.settings.theme = el.getAttribute('data-theme'); persist(); render(); return; }
    if (el.hasAttribute('data-view')) { state.settings.view = el.getAttribute('data-view'); persist(); render(); return; }

    var act = el.getAttribute('data-act');
    var id = el.getAttribute('data-id');
    var i = el.hasAttribute('data-i') ? +el.getAttribute('data-i') : -1;
    var r = current();

    switch (act) {
      case 'new': createReport(); break;
      case 'open': state.currentId = id; go('editor'); break;
      case 'edit': go('editor'); break;
      case 'preview': go('preview'); break;
      case 'pdf': pdfForReport(findReport(id)); break;
      case 'pdf-current': if (r) pdfForReport(r); break;
      case 'share': openShare(id); break;
      case 'share-current': if (r) openShare(r.id); break;
      case 'delete': deleteReport(id); break;
      case 'delete-current': if (r) deleteReport(r.id); break;
      case 'save': scheduleSave(); persist(); toast('Draft saved on this device.'); break;
      case 'finalize': finalize(); break;
      case 'reopen': if (r) { r.status = 'draft'; r.synced = false; persist(); render(); toast('Report reopened as a draft.'); } break;
      case 'test-add': if (r) { r.tests.push(C.blankTest()); touch(r); renderEditor(); } break;
      case 'test-del': if (r && r.tests.length > 1) { r.tests.splice(i, 1); touch(r); renderEditor(); } else toast('Keep at least one test row, or clear its fields.'); break;
      case 'test-up': if (r && i > 0) { var a = r.tests.splice(i, 1)[0]; r.tests.splice(i - 1, 0, a); touch(r); renderEditor(); } break;
      case 'test-down': if (r && i < r.tests.length - 1) { var b = r.tests.splice(i, 1)[0]; r.tests.splice(i + 1, 0, b); touch(r); renderEditor(); } break;
      case 'extra-add': if (r && r.extras.length < 50) { r.extras.push({ label: '', value: '' }); touch(r); renderEditor(); } break;
      case 'extra-del': if (r) { r.extras.splice(i, 1); touch(r); renderEditor(); } break;
      case 'month-prev': shiftMonth(-1); break;
      case 'month-next': shiftMonth(1); break;
      case 'export-pdf': exportMonthly('pdf'); break;
      case 'export-xml': exportMonthly('xml'); break;
      case 'export-doc': exportMonthly('doc'); break;
      case 'import-xml-btn': $('#fileXml').click(); break;
      case 'import-json-btn': $('#fileJson').click(); break;
      case 'export-json':
        download(new Blob([C.buildBackup(state.reports, state.settings)], { type: 'application/json' }),
          'Fajar_QC_backup_' + C.todayIso() + '.json');
        toast('Backup downloaded. Store it privately.');
        break;
      case 'copy-json':
        copyText(C.buildBackup(state.reports, state.settings)).then(function (ok) {
          toast(ok ? 'Backup copied to clipboard.' : 'Copy was blocked. Use Export JSON backup instead.');
        });
        break;
      case 'restore-clip':
        if (!navigator.clipboard || !navigator.clipboard.readText) { toast('Clipboard reading is not available. Paste the text below instead.'); break; }
        navigator.clipboard.readText().then(function (t) { importData(t, 'json'); },
          function () { toast('Allow clipboard access, or paste the text below.'); });
        break;
      case 'restore-paste': importData($('#pasteBox').value, 'json'); break;
      case 'sync': syncPending(true); break;
      case 'sample':
        var added = 0;
        C.sampleReports().forEach(function (sr) {
          if (!findReport(sr.id)) { state.reports.push(sr); added++; }
        });
        persist();
        toast(added ? added + ' sample report(s) added. Delete them any time.' : 'Sample reports are already here.');
        render();
        break;
      case 'clear-all':
        if (!state.reports.length) { toast('No reports to delete.'); break; }
        if (!confirm('Delete ALL reports on this device? Export a backup first. This cannot be undone.')) break;
        state.reports = []; state.currentId = null; persist(); toast('All local reports deleted.'); render();
        break;
      case 'remove-photo': state.settings.photo = ''; persist(); render(); break;
      case 'install':
        if (state.deferredPrompt) {
          state.deferredPrompt.prompt();
          state.deferredPrompt.userChoice.finally(function () { state.deferredPrompt = null; render(); });
        }
        break;
      case 'signout': state.settings.signedIn = false; persist(); closeDrawer(); go('signin'); break;
      case 'signin':
        var nm = $('#signinName').value.trim();
        state.settings.signedIn = true;
        if (nm) state.settings.name = nm.slice(0, 80);
        persist(); go('dashboard'); break;
      case 'share-pdf':
        var sr2 = findReport(state.shareId);
        closeShare();
        if (sr2 && requireProduct(sr2)) makePdf(sr2).then(function (blob) { return shareBlob(blob, fileName(sr2) + '.pdf', 'application/pdf', sr2.fields.product); })
          .catch(function (err) { toast('Could not prepare the PDF: ' + err.message); });
        break;
      case 'share-wa':
        var w = findReport(state.shareId); closeShare();
        if (w) {
          var digits = String(state.settings.whatsapp || '').replace(/\D/g, '');
          var url = 'https://wa.me/' + digits + '?text=' + encodeURIComponent(summaryText(w));
          window.open(url, '_blank', 'noopener');
        }
        break;
      case 'share-gateway':
        var g = findReport(state.shareId); closeShare();
        if (g) {
          var phone = String(state.settings.whatsapp || '').replace(/\D/g, '');
          var gw = state.settings.gateway.split('{phone}').join(encodeURIComponent(phone)).split('{text}').join(encodeURIComponent(summaryText(g)));
          window.open(gw, '_blank', 'noopener');
        }
        break;
      case 'share-mail':
        var m = findReport(state.shareId); closeShare();
        if (m) {
          var subj = 'Fajar QC report: ' + (m.fields.product || 'Untitled');
          location.href = 'mailto:' + encodeURIComponent(state.settings.email || '') + '?subject=' + encodeURIComponent(subj) +
            '&body=' + encodeURIComponent(summaryText(m) + '\n\nAttach the PDF from your Downloads folder if needed.');
        }
        break;
      case 'share-copy':
        var c = findReport(state.shareId); closeShare();
        if (c) copyText(summaryText(c)).then(function (ok) { toast(ok ? 'Summary copied.' : 'Copy was blocked on this device.'); });
        break;
      case 'share-close': closeShare(); break;
      default: break;
    }
  });

  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t.hasAttribute('data-search')) { state.query = t.value; renderReportList(); return; }
    if (t.hasAttribute('data-field')) {
      var r = current(); if (!r) return;
      r.fields[t.getAttribute('data-field')] = t.value;
      touch(r); updateComputed(); return;
    }
    if (t.hasAttribute('data-test')) {
      var r2 = current(); if (!r2) return;
      r2.tests[+t.getAttribute('data-i')][t.getAttribute('data-col')] = t.value;
      touch(r2); updateComputed(); return;
    }
    if (t.hasAttribute('data-remark')) {
      var r3 = current(); if (!r3) return;
      r3.remarks[+t.getAttribute('data-i')] = t.value;
      touch(r3); return;
    }
    if (t.hasAttribute('data-extra-label') || t.hasAttribute('data-extra-value')) {
      var r4 = current(); if (!r4) return;
      var ex = r4.extras[+t.getAttribute('data-i')]; if (!ex) return;
      if (t.hasAttribute('data-extra-label')) ex.label = t.value; else ex.value = t.value;
      touch(r4); return;
    }
    if (t.hasAttribute('data-set')) {
      state.settings[t.getAttribute('data-set')] = t.value;
      persist(); setText('#drawerName', state.settings.name || 'Lab technician');
      setText('#drawerEmail', state.settings.email || 'No email set');
      $('#avatar').innerHTML = avatarHtml(); $('#drawerAvatar').innerHTML = avatarHtml();
    }
  });

  document.addEventListener('change', function (e) {
    var t = e.target;
    if (t.hasAttribute('data-from')) { state.from = t.value; renderReportList(); return; }
    if (t.hasAttribute('data-to')) { state.to = t.value; renderReportList(); return; }
    if (t.hasAttribute('data-verdict')) {
      var r = current(); if (!r) return;
      r.verdictOverride = t.value === 'FIT' || t.value === 'UNFIT' ? t.value : null;
      touch(r); updateComputed(); return;
    }
    if (t.tagName === 'SELECT' && t.hasAttribute('data-field')) {
      var rs = current(); if (!rs) return;
      rs.fields[t.getAttribute('data-field')] = t.value;
      touch(rs); updateComputed(); return;
    }
    if (t.hasAttribute('data-set-bool')) {
      state.settings[t.getAttribute('data-set-bool')] = t.checked;
      persist(); return;
    }
    if (t.hasAttribute('data-photo') && t.files && t.files[0]) {
      resizePhoto(t.files[0]).then(function (url) {
        state.settings.photo = url; persist(); render(); toast('Photo updated.');
      }).catch(function () { toast('That photo could not be read.'); });
      return;
    }
    if (t.id === 'fileJson' && t.files && t.files[0]) {
      readFile(t.files[0], function (txt) { importData(txt, 'json'); }); t.value = ''; return;
    }
    if (t.id === 'fileXml' && t.files && t.files[0]) {
      readFile(t.files[0], function (txt) { importData(txt, 'xml'); }); t.value = ''; return;
    }
  });

  function readFile(file, cb) {
    if (file.size > 20 * 1024 * 1024) { toast('That file is too large to import.'); return; }
    var reader = new FileReader();
    reader.onload = function () { cb(String(reader.result)); };
    reader.onerror = function () { toast('The file could not be read.'); };
    reader.readAsText(file);
  }

  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
      e.preventDefault();
      persist();
      toast('Saved on this device.');
    }
    if (e.key === 'Escape') { closeDrawer(); }
  });

  window.addEventListener('online', function () {
    if (state.view === 'dashboard' || state.view === 'settings') render();
    if (state.settings.autoSend) syncPending(false);
  });
  window.addEventListener('offline', function () { render(); });
  window.matchMedia('(min-width: 960px)').addEventListener('change', render);

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    state.deferredPrompt = e;
    render();
  });
  window.addEventListener('appinstalled', function () { state.deferredPrompt = null; toast('Fajar QC installed.'); render(); });

  function boot() {
    load();
    state.view = state.settings.signedIn === false ? 'signin' : 'dashboard';
    render();
    if ('serviceWorker' in navigator && /^https?:/.test(location.protocol)) {
      navigator.serviceWorker.register('sw.js').catch(function () { /* offline cache optional */ });
    }
    if (!/^https?:/.test(location.protocol)) toast('Open this app from an https link (or localhost) to enable offline use.');
  }

  boot();
})();
