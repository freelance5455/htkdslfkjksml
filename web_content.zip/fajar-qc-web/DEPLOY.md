# Fajar QC Lab — Chrome web app: deploy in 5 minutes

## 1. Put the folder online (free, HTTPS is automatic)
Easiest: **Netlify Drop** — open https://app.netlify.com/drop and drag this whole
`fajar-qc-web` folder onto the page. You get a link like `https://something.netlify.app`.
Alternatives that work the same way: Cloudflare Pages, GitHub Pages, Vercel (upload the folder).

The app must be served over **https** (the host does this for you) — it is required for
install, offline use and sharing.

## 2. Open it in Chrome (Android phone)
1. Open the link in **Chrome**.
2. Tap ⋮ (top right) → **Install app** (or **Add to Home screen**).
3. Open "Fajar QC" from your home screen. It runs full screen, and works offline after the first load.

## 3. Optional: sync to your own server
Settings → "Sync endpoint URL". The app POSTs each finalized report as JSON:
`{ "report": {...}, "sender": { "name", "email", "whatsapp" } }`.
Your server must accept it and return HTTP 2xx, and allow cross-origin requests (CORS).
Drafts are never sent.

## Files
- `index.html`, `styles.css`, `core.js`, `app.js` — the app (no libraries, no CDN)
- `sw.js`, `manifest.webmanifest` — offline cache and install support
- `assets/` — logo and icons
- `tests/test.js` — logic and PDF structure tests (`node tests/test.js`)
