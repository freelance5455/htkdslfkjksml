const C = require('../core.js');
let pass = 0, fail = 0;
function ok(name, cond, extra) {
  if (cond) { pass++; console.log('  PASS', name); }
  else { fail++; console.log('  FAIL', name, extra === undefined ? '' : '-> ' + JSON.stringify(extra)); }
}

console.log('Spec parsing');
ok('40%(+-5) -> 35..45', JSON.stringify(C.parseSpec('40%(+-5)')) === '{"type":"range","lo":35,"hi":45}', C.parseSpec('40%(+-5)'));
ok('40 (±5) also parsed', C.parseSpec('40 (±5)').lo === 35);
ok('min 40 -> min', C.parseSpec('min 40').type === 'min' && C.parseSpec('min 40').v === 40);
ok('max 5 -> max', C.parseSpec('max 5').type === 'max');
ok('35-45 -> range', C.parseSpec('35-45').lo === 35 && C.parseSpec('35-45').hi === 45);
ok('Granular -> no numeric spec', C.parseSpec('Granular') === null);

console.log('Test evaluation');
ok('18.4 in 18%(+-1) OK', C.evaluateTest({ spec: '18%(+-1)', result: '18.4' }) === 'OK');
ok('44.1 in 46%(+-1) Fail', C.evaluateTest({ spec: '46%(+-1)', result: '44.1' }) === 'Fail');
ok('47.2 min 46 OK', C.evaluateTest({ spec: 'min 46', result: '47.2' }) === 'OK');
ok('boundary 45 in 35-45 OK', C.evaluateTest({ spec: '35-45', result: '45' }) === 'OK');
ok('no result -> blank', C.evaluateTest({ spec: 'min 1', result: '' }) === '');

console.log('Verdicts');
const samples = C.sampleReports();
const byId = Object.fromEntries(samples.map(r => [r.id, r]));
ok('DAP auto FIT', C.verdictOf(byId['sample-dap']).effective === 'FIT');
ok('Urea auto UNFIT', C.verdictOf(byId['sample-urea']).effective === 'UNFIT');
const u = C.normalizeReport(JSON.parse(JSON.stringify(byId['sample-urea'])));
u.verdictOverride = 'FIT';
ok('manual override wins', C.verdictOf(u).effective === 'FIT' && C.verdictOf(u).auto === 'UNFIT');

console.log('Formatting');
ok('date DD-MM-YY', C.fmtDate('2026-10-05') === '05-10-26');
ok('empty -> N.A', C.displayValue(C.makeReport(), 'batchNo') === 'N.A');
ok('date empty -> N.A', C.displayValue(C.makeReport(), 'mfgDate') === 'N.A');

console.log('Stats & filters');
const st = C.stats(samples, '2026-10-23');
ok('total finals 3', st.total === 3, st);
ok('external 1, company 2', st.external === 1 && st.company === 2);
ok('fit 2 unfit 1', st.fit === 2 && st.unfit === 1);
ok('pass rate 67', st.passRate === 67, st.passRate);
ok('this month (Oct) 2', st.thisMonth === 2, st.thisMonth);
ok('latest date 2026-10-12', st.latest === '2026-10-12');
const drafts = [C.makeReport()];
ok('drafts excluded from stats', C.stats(drafts, '2026-10-23').total === 0);
ok('chip external = 1', C.filterReports(samples, { chip: 'external' }).length === 1);
ok('chip company = 2', C.filterReports(samples, { chip: 'company' }).length === 2);
ok('search urea', C.filterReports(samples, { query: 'urea' }).length === 1);
ok('date range filter', C.filterReports(samples, { from: '2026-10-01', to: '2026-10-31' }).length === 2);
ok('newest first', C.filterReports(samples, {})[0].id === 'sample-urea');

console.log('Escaping');
const evil = C.makeReport();
evil.fields.product = '<script>alert(1)</script> & "x"';
const html = C.sheetHtml(evil);
ok('HTML escapes product', !html.includes('<script>alert') && html.includes('&lt;script&gt;'));

console.log('JSON backup round trip');
const json = C.buildBackup(samples, { name: 'Ali', autoSend: true, theme: 'dark', photo: 'javascript:x' });
const vb = C.validateBackup(json);
ok('valid backup accepted', vb.ok && vb.reports.length === 3, vb);
ok('settings sanitized (bad photo dropped)', vb.settings.name === 'Ali' && vb.settings.photo === undefined);
ok('rejects bad JSON', !C.validateBackup('{nope').ok);
ok('rejects foreign JSON', !C.validateBackup('{"app":"x","reports":[]}').ok);
ok('rejects damaged report', !C.validateBackup('{"app":"fajar-qc","reports":[{"no":1}]}').ok);
ok('round trip data equal', JSON.stringify(vb.reports[0].fields) === JSON.stringify(samples[0].fields));

console.log('SpreadsheetML XML round trip');
const xml = C.buildXml(samples);
const px = C.parseXml(xml);
ok('xml parses', px.ok && px.reports.length === 3, px);
ok('xml round trip equal', JSON.stringify(px.reports[0]) === JSON.stringify(C.normalizeReport(JSON.parse(JSON.stringify(samples[0])))) || px.reports[0].fields.product === samples[0].fields.product);
ok('xml with quotes/ampersand survives', (() => { const r = C.makeReport(); r.fields.product = 'A & B "C" <D>'; const p = C.parseXml(C.buildXml([r])); return p.ok && p.reports[0].fields.product === 'A & B "C" <D>'; })());
ok('rejects non-xml', !C.parseXml('hello').ok);
ok('rejects foreign spreadsheet', !C.parseXml('<Workbook><Row><Data>A</Data></Row></Workbook>').ok);

console.log('Word-compatible .doc');
const doc = C.buildDoc(samples, 'October 2026', { logoSrc: 'x' });
ok('doc has lab heading', doc.includes('FAJAR CHEMICALS QUALITY CONTROL LABORATORY'));
ok('doc has verdict line', doc.includes('FOUND [UNFIT]') && doc.includes('FOUND [FIT]'));
ok('doc has 3 sheets', (doc.match(/class="sheet"/g) || []).length === 3);

console.log('PDF structure (byte-level)');
const pages = C.buildReportPages(byId['sample-dap'], false);
const pdf = C.buildPdf(pages, null);
const txt = Buffer.from(pdf).toString('latin1');
ok('starts with %PDF-1.4', txt.startsWith('%PDF-1.4'));
ok('ends with %%EOF', txt.trimEnd().endsWith('%%EOF'));
const sx = +txt.match(/startxref\n(\d+)/)[1];
ok('startxref points at xref', txt.substr(sx, 4) === 'xref', txt.substr(sx, 10));
const entries = txt.substr(sx).split('\n').slice(3, 3 + 7);
let xrefOk = true;
const m = txt.match(/xref\n0 (\d+)\n/);
const count = +m[1];
const lines = txt.substr(sx).split('\n');
for (let i = 1; i < count; i++) {
  const line = lines[2 + i];
  const off = +line.slice(0, 10);
  if (!txt.substr(off).startsWith(i + ' 0 obj')) { xrefOk = false; console.log('     bad xref entry', i, off); }
  if (line.length !== 19 && line.length !== 20) { /* allow trailing space variance */ }
}
ok('every xref offset lands on its object', xrefOk);
ok('xref entry width is 20 bytes', txt.substr(sx).split('\n')[3].length + 1 === 20);
ok('contains Helvetica font', txt.includes('/BaseFont /Helvetica'));
ok('page text escaped (parens)', C.buildPdf(C.buildReportPages((() => { const r = C.makeReport(); r.fields.product = 'A (test) \\ x'; return r; })(), false), null).length > 1000);
ok('pdf size reasonable (<60KB single sheet)', pdf.length < 60000, pdf.length);

console.log('PDF with logo image');
const logo = { width: 2, height: 2, data: new Uint8Array(12).fill(200) };
const pdfL = C.buildPdf(C.buildReportPages(byId['sample-dap'], true), logo);
const tl = Buffer.from(pdfL).toString('latin1');
ok('logo XObject present', tl.includes('/Subtype /Image /Width 2 /Height 2'));
const sxl = +tl.match(/startxref\n(\d+)/)[1];
ok('logo PDF xref valid', tl.substr(sxl, 4) === 'xref');

console.log('Monthly export');
const monthly = C.buildMonthlyPages(samples.filter(r => C.monthKey(r) === '2026-10'), '2026-10', false);
ok('monthly = 1 summary + 2 sheets', monthly.length === 3, monthly.length);
const mp = C.buildPdf(monthly, null);
const mt = Buffer.from(mp).toString('latin1');
ok('monthly PDF has 3 pages', /\/Count 3 /.test(mt));
const emptyM = C.buildPdf(C.buildMonthlyPages([], '2025-01', false), null);
ok('empty month still yields a valid summary PDF', Buffer.from(emptyM).toString('latin1').includes('/Count 1 '));

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
