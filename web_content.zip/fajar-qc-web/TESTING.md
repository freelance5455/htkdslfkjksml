# What was tested (and what was not)

## Tested here, automatically
- 57 logic/PDF tests (`node tests/test.js`): specification parsing (40%(+-5), min, max, 35-45),
  OK/Fail and FIT/UNFIT derivation, manual override, date format DD-MM-YY, N.A placeholders,
  stats and filters, HTML escaping, JSON backup validation, SpreadsheetML XML round trip,
  Word .doc content, and PDF byte-level structure (every xref offset checked).
- 59 browser tests in headless Chromium at phone size (402x874) and wide size (1280x800):
  drawer 80% width and closed state, creating/editing/finalizing reports, autosave, Ctrl+S,
  PDF download, filters and search, dashboard stats and charts, JSON/XML/.doc/PDF exports,
  JSON restore (replaces data) and rejection of bad files, no horizontal overflow on each
  screen, 44px touch targets, offline load from the service-worker cache, sign out/in, no JS errors.
- Rendered the generated PDF with poppler and compared it with the template layout.

## Not tested here (needs you)
- A real Android phone and real "Install app" prompt (tested in desktop Chromium).
- Your sync endpoint (no network access in the test environment).
- Opening the .xml file in Excel and the .doc file in Word (both are standard formats; not opened in those programs here).
- WhatsApp/email hand-off (opens the apps on a real phone).

## Known gaps
- Saved product presets are not included yet.
- Extra table columns (beyond the five fixed ones) are not included; extra "Label: value" fields are.
- The on-screen preview is read-only: edit with "Edit report".
