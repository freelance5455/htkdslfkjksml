/* Fajar QC core: data model, specification checks, exports. No DOM access. */
(function (root) {
  'use strict';

  var APP_ID = 'fajar-qc';
  var BACKUP_VERSION = 1;
  var PW = 595, PH = 842;
  var MAX_TEXT = 2000;
  var MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

  var PAIRS = [
    ['Source', 'source', 'Physical State', 'physicalState'],
    ['Name of Product', 'product', 'Product Category', 'productCategory'],
    ['Active Ingredient', 'activeIngredient', 'Active Percentage', 'activePercent'],
    ['Batch No.', 'batchNo', 'Sample Received On', 'receivedOn'],
    ['Date of MFG', 'mfgDate', 'Result Reported On', 'resultOn'],
    ['Date of EXP', 'expDate', 'Sample Received By', 'receivedBy'],
    ['Sample ID', 'sampleId', 'Sample Size', 'sampleSize'],
    ['Q.M No.', 'qmNo', 'Imported by', 'importedBy'],
    ['Manufactured By', 'manufacturedBy', 'Distributer', 'distributer'],
    ['Sample By', 'sampleBy', null, null],
    ['Date of test', 'testDate', 'Temperature C', 'temperature'],
    ['Analysis time', 'analysisTime', 'Humidity%', 'humidity']
  ];
  var FIELD_KEYS = [];
  var LABELS = {};
  PAIRS.forEach(function (p) {
    if (p[1]) { FIELD_KEYS.push(p[1]); LABELS[p[1]] = p[0]; }
    if (p[3]) { FIELD_KEYS.push(p[3]); LABELS[p[3]] = p[2]; }
  });
  var DATE_KEYS = ['mfgDate', 'expDate', 'receivedOn', 'resultOn', 'testDate'];
  var CATEGORIES = { raw: 'RAWMATERIAL', batch: 'BATCHANALYSIS', external: 'EXTERNAL' };
  var SAMPLE_SIZES = ['500g', '1000g'];
  var DEFAULT_REMARKS = [
    'In case sample is provided by customer, the responsibility about the integrity of sample lies with the customer.',
    'The results are reported with a confidence level of 95% (K=2) and pertain to the analyzed sample only.',
    'This test report cannot be reproduced except in full, without written approval of laboratory authority.',
    'If the uncertainty of the sample tested is outside the regulatory limit, the sample will be declared UNFIT.'
  ];
  var TEST_COLS = ['Tests', 'Specification', 'Results', 'Methods', 'Remarks'];
  var VERDICT_FIT = 'REMARKS: THE PRODUCT COMPLIES WITH THE STANDARD LIMITS, FOUND [FIT]';
  var VERDICT_UNFIT = 'REMARKS: THE PRODUCT DOES NOT COMPLY WITH THE STANDARD LIMITS, FOUND [UNFIT]';

  /* ---------- basics ---------- */
  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function unesc(s) {
    return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'").replace(/&apos;/g, "'").replace(/&amp;/g, '&');
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function nowIso() { return new Date().toISOString(); }
  function todayIso() { var d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function newId() { return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function orNA(v) { var s = String(v === null || v === undefined ? '' : v).trim(); return s || 'N.A'; }
  function validDate(s) { return typeof s === 'string' && !isNaN(Date.parse(s)) ? s : null; }
  function str(v, max) { return v === null || v === undefined ? '' : String(v).slice(0, max || MAX_TEXT); }

  function monthLabel(key) {
    var m = /^(\d{4})-(\d{2})$/.exec(key || '');
    return m ? MONTHS[+m[2] - 1] + ' ' + m[1] : String(key || '');
  }

  /* ---------- data model ---------- */
  function blankTest() { return { name: '', spec: '', result: '', method: '', remarks: '' }; }

  function makeReport() {
    var fields = {};
    FIELD_KEYS.forEach(function (k) { fields[k] = ''; });
    var now = nowIso();
    return {
      id: newId(), status: 'draft', category: 'raw', fields: fields,
      tests: [blankTest()], extras: [], verdictOverride: null,
      remarks: DEFAULT_REMARKS.slice(), createdAt: now, updatedAt: now,
      finalizedAt: null, synced: false
    };
  }

  function normalizeReport(raw) {
    if (!raw || typeof raw !== 'object' || typeof raw.id !== 'string' || !raw.id) return null;
    var r = makeReport();
    r.id = raw.id.slice(0, 80);
    r.status = raw.status === 'final' ? 'final' : 'draft';
    r.category = CATEGORIES[raw.category] ? raw.category : 'raw';
    FIELD_KEYS.forEach(function (k) { r.fields[k] = str(raw.fields && raw.fields[k], 200); });
    r.tests = Array.isArray(raw.tests) ? raw.tests.slice(0, 300).map(function (t) {
      t = t || {};
      return { name: str(t.name, 200), spec: str(t.spec, 200), result: str(t.result, 200), method: str(t.method, 200), remarks: str(t.remarks, 300) };
    }) : [];
    if (!r.tests.length) r.tests = [blankTest()];
    r.extras = Array.isArray(raw.extras) ? raw.extras.slice(0, 50).map(function (e) {
      e = e || {};
      return { label: str(e.label, 100), value: str(e.value, 300) };
    }) : [];
    r.verdictOverride = raw.verdictOverride === 'FIT' || raw.verdictOverride === 'UNFIT' ? raw.verdictOverride : null;
    r.remarks = DEFAULT_REMARKS.map(function (d, i) {
      return Array.isArray(raw.remarks) && typeof raw.remarks[i] === 'string' ? str(raw.remarks[i], 400) : d;
    });
    r.createdAt = validDate(raw.createdAt) || nowIso();
    r.updatedAt = validDate(raw.updatedAt) || r.createdAt;
    r.finalizedAt = validDate(raw.finalizedAt);
    r.synced = raw.synced === true;
    return r;
  }

  /* ---------- specification checks ---------- */
  function num(s) {
    var m = String(s === null || s === undefined ? '' : s).match(/-?\d+(?:\.\d+)?/);
    return m ? parseFloat(m[0]) : null;
  }

  // Supports: 40%(+-5), 40 (±5), min 40, max 5, 35-45, 35 to 45
  function parseSpec(spec) {
    var s = String(spec || '').trim();
    if (!s) return null;
    var m = s.match(/(-?\d+(?:\.\d+)?)\s*%?\s*\(\s*(?:\+\s*-|\+\/-|±)\s*(\d+(?:\.\d+)?)\s*%?\s*\)/);
    if (m) return { type: 'range', lo: +m[1] - +m[2], hi: +m[1] + +m[2] };
    m = s.match(/\bmin(?:imum)?\.?\s*(-?\d+(?:\.\d+)?)/i);
    if (m) return { type: 'min', v: +m[1] };
    m = s.match(/\bmax(?:imum)?\.?\s*(-?\d+(?:\.\d+)?)/i);
    if (m) return { type: 'max', v: +m[1] };
    m = s.match(/(-?\d+(?:\.\d+)?)\s*(?:-|–|to)\s*(-?\d+(?:\.\d+)?)/i);
    if (m) return { type: 'range', lo: Math.min(+m[1], +m[2]), hi: Math.max(+m[1], +m[2]) };
    return null;
  }

  function evaluateTest(t) {
    var sp = parseSpec(t.spec);
    var r = num(t.result);
    if (!sp || r === null) return '';
    var ok;
    if (sp.type === 'range') ok = r >= sp.lo && r <= sp.hi;
    else if (sp.type === 'min') ok = r >= sp.v;
    else ok = r <= sp.v;
    return ok ? 'OK' : 'Fail';
  }

  function verdictOf(r) {
    var evals = r.tests.map(evaluateTest);
    var auto = evals.indexOf('Fail') >= 0 ? 'UNFIT' : 'FIT';
    return {
      auto: auto,
      effective: r.verdictOverride || auto,
      evaluated: evals.filter(Boolean).length,
      evals: evals
    };
  }

  function verdictLine(v) { return v === 'FIT' ? VERDICT_FIT : VERDICT_UNFIT; }

  /* ---------- formatting & filtering ---------- */
  function fmtDate(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || ''));
    if (m) return m[3] + '-' + m[2] + '-' + m[1].slice(2);
    return iso ? String(iso) : 'N.A';
  }
  function displayValue(r, key) {
    var raw = r && r.fields ? String(r.fields[key] || '').trim() : '';
    if (!raw) return 'N.A';
    return DATE_KEYS.indexOf(key) >= 0 ? fmtDate(raw) : raw;
  }
  function reportDate(r) {
    var d = r.fields && r.fields.resultOn;
    if (d && /^\d{4}-\d{2}-\d{2}$/.test(d)) return d;
    return (r.finalizedAt || r.updatedAt || r.createdAt || nowIso()).slice(0, 10);
  }
  function monthKey(r) { return reportDate(r).slice(0, 7); }

  function filterReports(reports, f) {
    f = f || {};
    var q = String(f.query || '').trim().toLowerCase();
    return reports.filter(function (r) {
      if (f.chip === 'company') { if (r.category === 'external') return false; }
      else if (f.chip && f.chip !== 'all' && r.category !== f.chip) return false;
      var d = reportDate(r);
      if (f.from && d < f.from) return false;
      if (f.to && d > f.to) return false;
      if (q) {
        var hay = [r.fields.product, r.fields.sampleId, r.fields.batchNo].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return false;
      }
      return true;
    }).sort(function (a, b) {
      return reportDate(b).localeCompare(reportDate(a)) || String(b.updatedAt).localeCompare(String(a.updatedAt));
    });
  }

  function stats(reports, today) {
    var fin = reports.filter(function (r) { return r.status === 'final'; });
    var cur = String(today || todayIso()).slice(0, 7);
    var s = { total: fin.length, company: 0, external: 0, fit: 0, unfit: 0, passRate: null, latest: null,
      thisMonth: 0, byMonth: {}, byCategory: { raw: 0, batch: 0, external: 0 } };
    fin.forEach(function (r) {
      var v = verdictOf(r).effective;
      if (v === 'FIT') s.fit++; else s.unfit++;
      if (r.category === 'external') s.external++; else s.company++;
      s.byCategory[r.category]++;
      var d = reportDate(r);
      if (!s.latest || d > s.latest) s.latest = d;
      var m = d.slice(0, 7);
      s.byMonth[m] = (s.byMonth[m] || 0) + 1;
      if (m === cur) s.thisMonth++;
    });
    s.passRate = s.total ? Math.round(s.fit * 100 / s.total) : null;
    return s;
  }

  /* ---------- backups & XML ---------- */
  function pickSettings(o) {
    var out = {};
    ['name', 'email', 'endpoint', 'whatsapp', 'gateway'].forEach(function (k) {
      if (typeof o[k] === 'string') out[k] = o[k].slice(0, 300);
    });
    if (typeof o.autoSend === 'boolean') out.autoSend = o.autoSend;
    if (['auto', 'light', 'dark'].indexOf(o.theme) >= 0) out.theme = o.theme;
    if (['auto', 'mobile', 'desktop'].indexOf(o.view) >= 0) out.view = o.view;
    if (typeof o.photo === 'string' && o.photo.indexOf('data:image/') === 0 && o.photo.length < 400000) out.photo = o.photo;
    return out;
  }

  function buildBackup(reports, settings) {
    return JSON.stringify({ app: APP_ID, version: BACKUP_VERSION, exportedAt: nowIso(),
      settings: settings || null, reports: reports }, null, 2);
  }

  function validateBackup(text) {
    var obj;
    try { obj = JSON.parse(text); } catch (e) { return { ok: false, error: 'This text is not valid JSON.' }; }
    if (!obj || obj.app !== APP_ID || !Array.isArray(obj.reports)) return { ok: false, error: 'This is not a Fajar QC backup file.' };
    if (obj.version > BACKUP_VERSION) return { ok: false, error: 'This backup was made by a newer version of the app.' };
    if (obj.reports.length > 5000) return { ok: false, error: 'This backup has too many reports.' };
    var seen = {}, reports = [];
    for (var i = 0; i < obj.reports.length; i++) {
      var n = normalizeReport(obj.reports[i]);
      if (!n) return { ok: false, error: 'Report ' + (i + 1) + ' in the backup is damaged. Nothing was changed.' };
      if (seen[n.id]) { reports[seen[n.id] - 1] = n; continue; }
      reports.push(n); seen[n.id] = reports.length;
    }
    return { ok: true, reports: reports, settings: obj.settings && typeof obj.settings === 'object' ? pickSettings(obj.settings) : null };
  }

  var XML_HEAD = '<?xml version="1.0"?>\n<?mso-application progid="Excel.Sheet"?>\n';

  function buildXml(reports) {
    var header = ['ID', 'Status', 'Category', 'Product', 'Sample ID', 'Batch No.', 'Report Date', 'Verdict', 'Data'];
    var rows = [header].concat(reports.map(function (r) {
      return [r.id, r.status, CATEGORIES[r.category], r.fields.product, r.fields.sampleId, r.fields.batchNo,
        reportDate(r), verdictOf(r).effective, JSON.stringify(r)];
    }));
    var body = rows.map(function (row) {
      return '<Row>' + row.map(function (c) { return '<Cell><Data ss:Type="String">' + esc(c) + '</Data></Cell>'; }).join('') + '</Row>';
    }).join('');
    return XML_HEAD + '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' +
      '<Worksheet ss:Name="Reports"><Table>' + body + '</Table></Worksheet></Workbook>';
  }

  function parseXml(text) {
    if (!/<Workbook[\s>]/.test(String(text))) return { ok: false, error: 'This is not a SpreadsheetML XML file.' };
    var rows = String(text).match(/<Row[ >][\s\S]*?<\/Row>/g) || [];
    var table = rows.map(function (row) {
      return (row.match(/<Data[^>]*>[\s\S]*?<\/Data>/g) || []).map(function (c) {
        return unesc(c.replace(/^<Data[^>]*>/, '').replace(/<\/Data>$/, ''));
      });
    });
    if (!table.length) return { ok: false, error: 'The XML file has no rows.' };
    var idx = table[0].indexOf('Data');
    if (idx < 0) return { ok: false, error: 'Only XML files exported by this app can be imported (missing Data column).' };
    var reports = [];
    for (var i = 1; i < table.length; i++) {
      var json = table[i][idx];
      if (!json) continue;
      var obj;
      try { obj = JSON.parse(json); } catch (e) { return { ok: false, error: 'Row ' + (i + 1) + ' is damaged. Nothing was changed.' }; }
      var n = normalizeReport(obj);
      if (!n) return { ok: false, error: 'Row ' + (i + 1) + ' is not a valid report. Nothing was changed.' };
      reports.push(n);
    }
    return { ok: true, reports: reports };
  }

  /* ---------- HTML sheet (preview and Word) ---------- */
  function cellPair(l, v) {
    if (l === null || l === undefined) return '<th></th><td></td>';
    return '<th>' + esc(l) + '</th><td>' + esc(v === null || v === undefined ? '' : v) + '</td>';
  }
  function pairRow(l1, v1, l2, v2) { return '<tr>' + cellPair(l1, v1) + cellPair(l2, v2) + '</tr>'; }

  function sheetHtml(r, opts) {
    opts = opts || {};
    var logo = opts.logoSrc || 'assets/fajar-logo.png';
    var v = verdictOf(r);
    var box = function (key, label) {
      return '<span class="cat">' + esc(label) + ' <span class="box">' + (r.category === key ? 'X' : '&nbsp;') + '</span></span>';
    };
    var grid = PAIRS.map(function (p) {
      return pairRow(p[0], p[1] ? displayValue(r, p[1]) : null, p[2], p[3] ? displayValue(r, p[3]) : null);
    });
    var ex = r.extras || [];
    for (var i = 0; i < ex.length; i += 2) {
      var a = ex[i], b = ex[i + 1];
      grid.push(pairRow(a.label || '', orNA(a.value), b ? (b.label || '') : null, b ? orNA(b.value) : null));
    }
    var tests = r.tests.map(function (t, ti) {
      var rem = [v.evals[ti], t.remarks].filter(Boolean).join(' - ');
      return '<tr><td>' + esc(orNA(t.name)) + '</td><td>' + esc(orNA(t.spec)) + '</td><td>' + esc(orNA(t.result)) +
        '</td><td>' + esc(orNA(t.method)) + '</td><td>' + esc(rem || 'N.A') + '</td></tr>';
    }).join('');
    var rem = r.remarks.map(function (t) { return '<li>' + esc(String(t || '').toUpperCase()) + '</li>'; }).join('');
    return '<div class="sheet">' +
      '<table class="hdr"><tr><td class="logo"><img src="' + esc(logo) + '" alt="Fajar Chemicals"></td>' +
      '<td class="ttl"><b>FAJAR CHEMICALS QUALITY CONTROL LABORATORY</b><br><small>ADDRESS: HAVELI ROADCHOURAST MIAN KHAN TEH DEPALPUR DIST OKARA.</small></td></tr></table>' +
      '<div class="ftitle">FERTILIZER TEST REPORTS</div>' +
      '<div class="cats">' + box('raw', CATEGORIES.raw) + box('batch', CATEGORIES.batch) + box('external', CATEGORIES.external) + '</div>' +
      '<div class="tbl-wrap"><table class="grid">' + grid.join('') + '</table></div>' +
      '<div class="tbl-wrap"><table class="tests"><tr>' + TEST_COLS.map(function (c) { return '<th>' + c + '</th>'; }).join('') + '</tr>' + tests + '</table></div>' +
      '<p class="verdict">' + esc(verdictLine(v.effective)) + '</p>' +
      '<p class="ovr"><b>OVERALL REMARKS:</b></p><ol>' + rem + '</ol>' +
      '<table class="sig"><tr><td>PREPARED BY</td><td>REVIEWED BY</td><td>APPROVED BY</td></tr></table>' +
      '</div>';
  }

  function buildDoc(reports, title, opts) {
    var fin = reports.slice();
    var body = fin.map(function (r) {
      return '<div style="page-break-before:always"></div>' + sheetHtml(r, { logoSrc: opts && opts.logoSrc });
    }).join('');
    return '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">' +
      '<head><meta charset="utf-8"><title>' + esc(title) + '</title><style>' +
      '@page{size:A4;margin:1.2cm} body{font-family:Arial,sans-serif;font-size:9pt;color:#000}' +
      'table{border-collapse:collapse;width:100%} td,th{border:1px solid #000;padding:2px 4px;font-size:8pt;text-align:left;vertical-align:middle}' +
      'th{font-weight:normal} .bar{border:1px solid #000;text-align:center;font-weight:bold;padding:3px} .ttl{text-align:center}' +
      '.verdict{font-weight:bold;font-size:8pt} .ovr{font-size:7pt} ol{font-size:7pt} .sig td{height:40px;text-align:center;font-size:7pt;font-weight:bold}' +
      '</style></head><body><p><b>' + esc(title) + '</b> &mdash; ' + fin.length + ' reports</p>' + body + '</body></html>';
  }

  /* ---------- PDF writer (no libraries) ---------- */
  function n(v) { return String(Math.round(v * 100) / 100); }
  function estWidth(s, size, bold) { return String(s).length * size * (bold ? 0.6 : 0.52); }
  function fitText(s, w, size) {
    s = String(s);
    if (estWidth(s, size) <= w) return s;
    while (s.length > 1 && estWidth(s + '..', size) > w) s = s.slice(0, -1);
    return s + '..';
  }
  function wrapText(s, w, size) {
    var words = String(s).split(/\s+/), lines = [], cur = '';
    words.forEach(function (wd) {
      var t = cur ? cur + ' ' + wd : wd;
      if (estWidth(t, size) > w && cur) { lines.push(cur); cur = wd; } else cur = t;
    });
    if (cur || !lines.length) lines.push(cur);
    return lines;
  }
  function pdfText(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/[\u2013\u2014]/g, '-').replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"')
      .replace(/[^\x20-\x7E]/g, '?').replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
  }

  function Page() { this.ops = []; this.usesLogo = false; }
  Page.prototype.rect = function (x, y, w, h, gray) {
    var g = n(x) + ' ' + n(PH - y - h) + ' ' + n(w) + ' ' + n(h) + ' re';
    if (gray !== undefined && gray !== null) this.ops.push('q ' + n(gray) + ' g 0.5 w ' + g + ' b Q');
    else this.ops.push('0.5 w ' + g + ' S');
  };
  Page.prototype.line = function (x1, y1, x2, y2) {
    this.ops.push('0.6 w ' + n(x1) + ' ' + n(PH - y1) + ' m ' + n(x2) + ' ' + n(PH - y2) + ' l S');
  };
  Page.prototype.text = function (x, y, s, o) {
    o = o || {};
    var size = o.size || 8;
    var w = estWidth(s, size, o.bold);
    var tx = o.align === 'center' ? x - w / 2 : o.align === 'right' ? x - w : x;
    this.ops.push('BT /' + (o.bold ? 'F2' : 'F1') + ' ' + n(size) + ' Tf ' + n(tx) + ' ' + n(PH - y) + ' Td (' + pdfText(s) + ') Tj ET');
  };
  Page.prototype.image = function (x, y, w, h) {
    this.usesLogo = true;
    this.ops.push('q ' + n(w) + ' 0 0 ' + n(h) + ' ' + n(x) + ' ' + n(PH - y - h) + ' cm /Im1 Do Q');
  };

  // logo: {width, height, data: Uint8Array RGB} or null
  function buildPdf(pages, logo) {
    if (!pages.length) throw new Error('No pages to write');
    var imgW = logo ? logo.width : 1, imgH = logo ? logo.height : 1;
    var imgData = logo ? logo.data : new Uint8Array([255, 255, 255]);
    var objs = [];
    objs[1] = { dict: '<< /Type /Catalog /Pages 2 0 R >>' };
    objs[3] = { dict: '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>' };
    objs[4] = { dict: '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>' };
    objs[5] = { dict: '<< /Type /XObject /Subtype /Image /Width ' + imgW + ' /Height ' + imgH + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Length ' + imgData.length + ' >>', stream: imgData };
    var kids = [];
    pages.forEach(function (pg, i) {
      var pid = 6 + i * 2, cid = 7 + i * 2;
      var content = pg.ops.join('\n');
      kids.push(pid + ' 0 R');
      objs[pid] = { dict: '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << /Im1 5 0 R >> >> /Contents ' + cid + ' 0 R >>' };
      objs[cid] = { dict: '<< /Length ' + content.length + ' >>', stream: content };
    });
    objs[2] = { dict: '<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + pages.length + ' >>' };

    var parts = [], len = 0, offs = [];
    function add(p) { parts.push(p); len += p.length; }
    add('%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n');
    for (var i = 1; i < objs.length; i++) {
      if (!objs[i]) continue;
      offs[i] = len;
      add(i + ' 0 obj\n' + objs[i].dict + '\n');
      if (objs[i].stream !== undefined) { add('stream\n'); add(objs[i].stream); add('\nendstream\n'); }
      add('endobj\n');
    }
    var xrefOff = len;
    var xref = 'xref\n0 ' + objs.length + '\n0000000000 65535 f \n';
    for (var j = 1; j < objs.length; j++) {
      xref += ('0000000000' + offs[j]).slice(-10) + ' 00000 n \n';
    }
    add(xref);
    add('trailer\n<< /Size ' + objs.length + ' /Root 1 0 R >>\nstartxref\n' + xrefOff + '\n%%EOF\n');

    var out = new Uint8Array(len), pos = 0;
    parts.forEach(function (p) {
      if (typeof p === 'string') { for (var k = 0; k < p.length; k++) out[pos++] = p.charCodeAt(k) & 255; }
      else { out.set(p, pos); pos += p.length; }
    });
    return out;
  }

  function drawHeader(p, hasLogo) {
    var L = 30, W = 535;
    p.rect(L, 30, W, 62);
    if (hasLogo) p.image(L + 10, 38, 96, 46);
    else p.text(L + 14, 68, 'FAJAR', { size: 13, bold: true });
    p.line(140, 62, 560, 62);
    p.text(350, 52, 'FAJAR CHEMICALS QUALITY CONTROL LABORATORY', { size: 10, bold: true, align: 'center' });
    p.text(350, 80, 'ADDRESS: HAVELI ROADCHOURAST MIAN KHAN TEH DEPALPUR DIST OKARA.', { size: 6.2, align: 'center' });
  }

  function gridCell(p, x, y, LW, VW, label, value) {
    if (label !== null && label !== undefined && label !== '') p.text(x + 3, y + 9.5, fitText(label, LW - 6, 6.4), { size: 6.4 });
    if (value !== null && value !== undefined) p.text(x + LW + 3, y + 9.5, fitText(value, VW - 6, 7), { size: 7 });
  }

  function drawSheet(p, r, hasLogo) {
    var L = 30, W = 535;
    drawHeader(p, hasLogo);
    p.rect(L, 92, W, 18);
    p.text(350, 104, 'FERTILIZER TEST REPORTS', { size: 8, bold: true, align: 'center' });

    var cw = W / 3;
    Object.keys(CATEGORIES).forEach(function (key, i) {
      var x = L + i * cw, label = CATEGORIES[key];
      p.rect(x, 110, cw, 20);
      p.text(x + 10, 123, label, { size: 6.8, bold: true });
      var bx = x + 10 + estWidth(label, 6.8, true) + 8;
      p.rect(bx, 115, 9, 9);
      if (r.category === key) p.text(bx + 4.5, 122, 'X', { size: 7, bold: true, align: 'center' });
    });

    var rows = PAIRS.map(function (pr) {
      return [pr[0], pr[1] ? displayValue(r, pr[1]) : null, pr[2], pr[3] ? displayValue(r, pr[3]) : null];
    });
    var ex = r.extras || [];
    for (var i = 0; i < ex.length; i += 2) {
      var a = ex[i], b = ex[i + 1];
      rows.push([a.label || '', orNA(a.value), b ? (b.label || '') : null, b ? orNA(b.value) : null]);
    }
    var LW = 118, VW = 149.5, MX = L + 267.5, rh = 14, y = 130;
    rows.forEach(function (row) {
      p.rect(L, y, LW, rh); p.rect(L + LW, y, VW, rh);
      p.rect(MX, y, LW, rh); p.rect(MX + LW, y, VW, rh);
      gridCell(p, L, y, LW, VW, row[0], row[1]);
      gridCell(p, MX, y, LW, VW, row[2], row[3]);
      y += rh;
    });

    var ty = y + 8, cols = [130, 110, 100, 115, 80];
    var x = L;
    TEST_COLS.forEach(function (hd, ci) {
      p.rect(x, ty, cols[ci], 13, 0.9);
      p.text(x + cols[ci] / 2, ty + 9, hd, { size: 6.5, bold: true, align: 'center' });
      x += cols[ci];
    });
    var v = verdictOf(r);
    var avail = 556 - (ty + 13);
    var th = Math.max(8, Math.min(13, avail / Math.max(1, r.tests.length)));
    var tyy = ty + 13;
    r.tests.forEach(function (t, ti) {
      var rem = [v.evals[ti], t.remarks].filter(Boolean).join(' - ');
      var cells = [t.name, t.spec, t.result, t.method, rem];
      x = L;
      cells.forEach(function (c, ci) {
        p.rect(x, tyy, cols[ci], th);
        p.text(x + cols[ci] / 2, tyy + th / 2 + 2.2, fitText(orNA(c), cols[ci] - 6, 6.3), { size: 6.3, align: 'center' });
        x += cols[ci];
      });
      tyy += th;
    });

    var ry = tyy + 14;
    p.text(L, ry, verdictLine(v.effective), { size: 6.8, bold: true });
    ry += 14;
    p.text(L, ry, 'OVERALL REMARKS:', { size: 6.4, bold: true });
    ry += 9;
    (r.remarks || []).forEach(function (t, i) {
      if (!String(t || '').trim()) return;
      wrapText((i + 1) + '. ' + String(t).toUpperCase(), 520, 6.2).forEach(function (ln, j) {
        p.text(L + (j ? 8 : 0), ry, ln, { size: 6.2 });
        ry += 8;
      });
    });

    var sy = 775;
    [['PREPARED BY', L], ['REVIEWED BY', L + 185], ['APPROVED BY', L + 370]].forEach(function (s) {
      p.line(s[1], sy, s[1] + 165, sy);
      p.text(s[1] + 82.5, sy + 10, s[0], { size: 6.5, bold: true, align: 'center' });
    });
  }

  function summaryPages(list, key, hasLogo) {
    var fit = 0, unfit = 0, ext = 0;
    list.forEach(function (r) {
      if (verdictOf(r).effective === 'FIT') fit++; else unfit++;
      if (r.category === 'external') ext++;
    });
    var per = 32, pages = [], chunks = [];
    for (var i = 0; i < list.length; i += per) chunks.push(list.slice(i, i + per));
    if (!chunks.length) chunks.push([]);
    var widths = [35, 60, 185, 95, 80, 80], heads = ['No.', 'Date', 'Product', 'Category', 'Sample ID', 'Verdict'];
    chunks.forEach(function (chunk, ci) {
      var p = new Page();
      drawHeader(p, hasLogo);
      p.text(30, 112, 'MONTHLY SUMMARY - ' + monthLabel(key).toUpperCase(), { size: 10, bold: true });
      p.text(30, 126, 'Final reports: ' + list.length + '   FIT: ' + fit + '   UNFIT: ' + unfit + '   External: ' + ext +
        '   Page ' + (ci + 1) + ' of ' + chunks.length, { size: 7.5 });
      var y = 138, x = 30;
      heads.forEach(function (hd, hi) {
        p.rect(x, y, widths[hi], 14, 0.9);
        p.text(x + widths[hi] / 2, y + 10, hd, { size: 6.5, bold: true, align: 'center' });
        x += widths[hi];
      });
      y += 14;
      if (!chunk.length) p.text(30, y + 14, 'No finalized reports for this month.', { size: 8 });
      chunk.forEach(function (r, idx) {
        var vals = [String(ci * per + idx + 1), fmtDate(reportDate(r)), r.fields.product, CATEGORIES[r.category], r.fields.sampleId, verdictOf(r).effective];
        x = 30;
        vals.forEach(function (val, vi) {
          p.rect(x, y, widths[vi], 13);
          p.text(x + 3, y + 9, fitText(orNA(val), widths[vi] - 6, 6.8), { size: 6.8 });
          x += widths[vi];
        });
        y += 13;
      });
      pages.push(p);
    });
    return pages;
  }

  function buildMonthlyPages(list, key, hasLogo) {
    var sorted = list.slice().sort(function (a, b) { return reportDate(a).localeCompare(reportDate(b)); });
    var pages = summaryPages(sorted, key, hasLogo);
    sorted.forEach(function (r) { var p = new Page(); drawSheet(p, r, hasLogo); pages.push(p); });
    return pages;
  }

  function buildReportPages(r, hasLogo) {
    var p = new Page();
    drawSheet(p, r, hasLogo);
    return [p];
  }

  /* ---------- samples ---------- */
  function sampleReports() {
    function mk(o) {
      var r = makeReport();
      Object.keys(o.fields).forEach(function (k) { r.fields[k] = o.fields[k]; });
      r.id = 'sample-' + o.key;
      r.category = o.category;
      r.tests = o.tests.map(function (t) { return Object.assign(blankTest(), t); });
      r.status = 'final';
      r.finalizedAt = o.date + 'T09:00:00.000Z';
      r.updatedAt = r.finalizedAt;
      r.createdAt = r.finalizedAt;
      return r;
    }
    return [
      mk({ key: 'dap', category: 'batch', date: '2026-10-05',
        fields: { source: 'Plant A', physicalState: 'Granular solid', product: 'DAP 18-46-0', productCategory: 'Fertilizer',
          activeIngredient: 'N, P2O5', activePercent: '18 N / 46 P2O5', batchNo: 'DAP-2610', receivedOn: '2026-10-03',
          resultOn: '2026-10-05', mfgDate: '2026-09-01', expDate: '2028-08-31', receivedBy: 'Lab technician',
          sampleId: 'SMP-1001', sampleSize: '500g', qmNo: 'QM-118', manufacturedBy: 'Fajar Chemicals',
          sampleBy: 'Store officer', testDate: '2026-10-04', temperature: '27', analysisTime: '10:30', humidity: '52' },
        tests: [
          { name: 'Total Nitrogen N', spec: '18%(+-1)', result: '18.4', method: 'Kjeldahl' },
          { name: 'Total P2O5', spec: 'min 46', result: '47.2', method: 'Gravimetric' },
          { name: 'Moisture', spec: 'max 2', result: '1.1', method: 'Oven drying' },
          { name: 'Appearance', spec: 'Granular', result: 'Granular', method: 'Visual' }
        ] }),
      mk({ key: 'urea', category: 'external', date: '2026-10-12',
        fields: { product: 'Urea 46% N', productCategory: 'Fertilizer', batchNo: 'UR-0921', receivedOn: '2026-10-10',
          resultOn: '2026-10-12', sampleId: 'SMP-1002', sampleSize: '1000g', importedBy: 'Sample customer',
          testDate: '2026-10-11', temperature: '26', humidity: '55' },
        tests: [
          { name: 'Total Nitrogen', spec: '46%(+-1)', result: '44.1', method: 'Kjeldahl' },
          { name: 'Biuret', spec: 'max 1.0', result: '0.6', method: 'Spectrophotometry' }
        ] }),
      mk({ key: 'rock', category: 'raw', date: '2026-09-28',
        fields: { product: 'Rock Phosphate', productCategory: 'Raw material', batchNo: 'RP-778', receivedOn: '2026-09-25',
          resultOn: '2026-09-28', sampleId: 'SMP-0998', sampleSize: '500g', testDate: '2026-09-26' },
        tests: [{ name: 'Total P2O5', spec: '30-35', result: '33.0', method: 'Gravimetric' }] })
    ];
  }

  var api = {
    APP_ID: APP_ID, PAIRS: PAIRS, FIELD_KEYS: FIELD_KEYS, LABELS: LABELS, DATE_KEYS: DATE_KEYS,
    CATEGORIES: CATEGORIES, SAMPLE_SIZES: SAMPLE_SIZES, DEFAULT_REMARKS: DEFAULT_REMARKS, TEST_COLS: TEST_COLS,
    esc: esc, unesc: unesc, pad2: pad2, nowIso: nowIso, todayIso: todayIso, monthLabel: monthLabel,
    makeReport: makeReport, blankTest: blankTest, normalizeReport: normalizeReport,
    parseSpec: parseSpec, evaluateTest: evaluateTest, verdictOf: verdictOf, verdictLine: verdictLine,
    fmtDate: fmtDate, displayValue: displayValue, orNA: orNA, reportDate: reportDate, monthKey: monthKey,
    filterReports: filterReports, stats: stats, pickSettings: pickSettings,
    buildBackup: buildBackup, validateBackup: validateBackup, buildXml: buildXml, parseXml: parseXml,
    buildDoc: buildDoc, sheetHtml: sheetHtml, sampleReports: sampleReports,
    Page: Page, buildPdf: buildPdf, drawSheet: drawSheet, drawHeader: drawHeader,
    buildMonthlyPages: buildMonthlyPages, buildReportPages: buildReportPages,
    fitText: fitText, wrapText: wrapText, estWidth: estWidth
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.FajarCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
