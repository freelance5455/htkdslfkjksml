package com.rktechhub.tictactoepro

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

class MainActivity : Activity() {
    companion object {
        private const val TAG = "TicTacToeAds"
        private const val BANNER_TEST_AD_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"
        private const val REWARDED_INTERSTITIAL_TEST_AD_UNIT_ID = "ca-app-pub-3940256099942544/5354046379"

        // These exact production IDs are used only when the release build is explicitly
        // created with -PenableProductionAds=true.
        private const val BANNER_AD_UNIT_ID = "ca-app-pub-1496380656721365/7222808419"
        private const val REWARDED_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-1496380656721365/9058634267"
    }

    private lateinit var root: LinearLayout
    private lateinit var webView: WebView
    private lateinit var bannerContainer: LinearLayout
    private var bannerAd: AdView? = null
    private var rewardedAd: RewardedInterstitialAd? = null
    private var sdkReady = false
    private var isLoadingRewardedAd = false
    private var isShowingRewardedAd = false
    private var activityAlive = false

    private val bannerUnitId: String
        get() = if (BuildConfig.USE_PRODUCTION_ADS) BANNER_AD_UNIT_ID else BANNER_TEST_AD_UNIT_ID
    private val rewardedUnitId: String
        get() = if (BuildConfig.USE_PRODUCTION_ADS) REWARDED_INTERSTITIAL_AD_UNIT_ID else REWARDED_INTERSTITIAL_TEST_AD_UNIT_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityAlive = true
        window.statusBarColor = Color.rgb(11, 16, 32)
        window.navigationBarColor = Color.rgb(11, 16, 32)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 16, 32))
        }
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(11, 16, 32))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webChromeClient = WebChromeClient()
            addJavascriptInterface(GameBridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    // Only the packaged local game is allowed in this WebView.
                    return request.url.scheme != "file" && request.url.scheme != "about"
                }
            }
        }
        bannerContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(11, 16, 32))
            visibility = View.GONE
        }
        root.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root.addView(bannerContainer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        setContentView(root)

        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else if (webView.restoreState(savedInstanceState) == null) webView.loadUrl("file:///android_asset/index.html")

        logD("Ads config: ${if (BuildConfig.USE_PRODUCTION_ADS) "PRODUCTION" else "TEST"}; banner=$bannerUnitId; rewarded=$rewardedUnitId")
        // Initialize once per Activity instance, off the main thread as recommended by Google.
        Thread {
            try {
                MobileAds.initialize(applicationContext) {
                    runOnUiThread {
                        if (!activityAlive || isFinishing) return@runOnUiThread
                        sdkReady = true
                        loadBanner()
                        loadRewardedInterstitial()
                    }
                }
            } catch (e: Exception) {
                logE("Mobile Ads SDK initialization failed", e)
                runOnUiThread { if (activityAlive) Toast.makeText(this, "Ads initialize nahi hue; game chalti rahegi.", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    private fun loadBanner() {
        if (!sdkReady || isFinishing) return
        bannerAd?.destroy()
        bannerContainer.removeAllViews()
        val density = resources.displayMetrics.density
        val widthDp = (resources.displayMetrics.widthPixels / density).toInt().coerceAtLeast(1)
        val adView = AdView(this)
        adView.adUnitId = bannerUnitId
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, widthDp))
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() {
                if (!activityAlive) return
                bannerContainer.visibility = View.VISIBLE
                logD("Banner loaded")
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                logE("Banner failed to load: ${error.code} ${error.message}")
                bannerContainer.visibility = View.GONE
                // The WebView occupies the full remaining area; no gameplay is blocked.
            }
        }
        bannerAd = adView
        bannerContainer.addView(adView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        adView.loadAd(AdRequest.Builder().build())
    }

    private fun loadRewardedInterstitial() {
        if (!sdkReady || isLoadingRewardedAd || rewardedAd != null || isFinishing) return
        isLoadingRewardedAd = true
        RewardedInterstitialAd.load(
            this,
            rewardedUnitId,
            AdRequest.Builder().build(),
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    isLoadingRewardedAd = false
                    rewardedAd = ad
                    logD("Rewarded interstitial loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    isLoadingRewardedAd = false
                    rewardedAd = null
                    logE("Rewarded interstitial failed to load: ${error.code} ${error.message}")
                }
            }
        )
    }

    private fun requestRewardedHint() {
        if (isShowingRewardedAd) return
        if (rewardedAd == null) {
            callJs("onAdUnavailable")
            Toast.makeText(this, "Ad abhi ready nahi hai. Thodi der baad try karein.", Toast.LENGTH_SHORT).show()
            loadRewardedInterstitial()
            return
        }
        // Required introductory message + explicit continue/decline choice.
        AlertDialog.Builder(this)
            .setTitle("Optional Hint")
            .setMessage("Ek optional ad dekhein aur is round ke liye ek Tic Tac Toe hint paayein. Aap Not Now chun sakte hain; game bina ad ke bhi chalegi.")
            .setPositiveButton("Continue") { _, _ -> showRewardedInterstitial() }
            .setNegativeButton("Not now", null)
            .setOnCancelListener { /* User declined; do not show an error or grant a reward. */ }
            .show()
    }

    private fun showRewardedInterstitial() {
        val ad = rewardedAd
        if (ad == null || isShowingRewardedAd || isFinishing) {
            callJs("onAdUnavailable")
            loadRewardedInterstitial()
            return
        }
        rewardedAd = null // one-shot object: prevent duplicate show attempts
        isShowingRewardedAd = true
        var rewardEarned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() { logD("Rewarded interstitial shown") }
            override fun onAdImpression() { logD("Rewarded interstitial impression") }
            override fun onAdDismissedFullScreenContent() {
                isShowingRewardedAd = false
                if (rewardEarned) callJs("onAdRewarded") else callJs("onAdDismissedWithoutReward")
                loadRewardedInterstitial()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isShowingRewardedAd = false
                logE("Rewarded interstitial failed to show: ${error.code} ${error.message}")
                callJs("onAdUnavailable")
                loadRewardedInterstitial()
            }
        }
        try {
            ad.show(this) {
                // The ONLY place that marks the reward as earned is the SDK reward callback.
                rewardEarned = true
                logD("SDK reward callback received")
            }
        } catch (e: Exception) {
            isShowingRewardedAd = false
            logE("Could not show rewarded interstitial", e)
            callJs("onAdUnavailable")
            loadRewardedInterstitial()
        }
    }

    private fun callJs(functionName: String) {
        if (!activityAlive || !::webView.isInitialized) return
        runOnUiThread {
            if (activityAlive && !isFinishing) {
                webView.evaluateJavascript("if (typeof window.$functionName === 'function') window.$functionName();", null)
            }
        }
    }

    private inner class GameBridge {
        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread {
                if (activityAlive && !isFinishing) requestRewardedHint()
            }
        }
    }

    private fun logD(message: String) { if (BuildConfig.DEBUG) Log.d(TAG, message) }
    private fun logE(message: String, error: Throwable? = null) {
        if (BuildConfig.DEBUG) {
            if (error == null) Log.e(TAG, message) else Log.e(TAG, message, error)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
        bannerAd?.resume()
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.onPause()
        bannerAd?.pause()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        activityAlive = false
        bannerAd?.destroy()
        bannerAd = null
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("Android")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
