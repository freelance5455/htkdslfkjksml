plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Production ad IDs are enabled only when explicitly requested with:
// ./gradlew assembleRelease -PenableProductionAds=true
val enableProductionAds = providers.gradleProperty("enableProductionAds").orNull == "true"

android {
    namespace = "com.rktechhub.tictactoepro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rktechhub.tictactoepro"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        debug {
            buildConfigField("boolean", "USE_PRODUCTION_ADS", "false")
        }
        release {
            isMinifyEnabled = false
            // Release remains on test ads unless production is explicitly enabled.
            buildConfigField("boolean", "USE_PRODUCTION_ADS", enableProductionAds.toString())
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
