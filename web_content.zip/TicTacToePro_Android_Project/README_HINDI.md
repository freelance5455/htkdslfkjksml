# TIC TAC TOE PRO — Android + AdMob

**Package/Application ID:** `com.rktechhub.tictactoepro`  
**App ID (Manifest):** `ca-app-pub-1496380656721365~3229477100`

## Ad ID configuration

- Debug builds always use Google test IDs.
- Release builds also use test IDs by default.
- Release builds also use test IDs by default. For a deliberate production build, set `enableProductionAds=true` in `gradle.properties` (or pass `-PenableProductionAds=true` in a Gradle command). Debug builds always remain on test IDs.
- Production Banner: `ca-app-pub-1496380656721365/7222808419`
- Production Rewarded Interstitial: `ca-app-pub-1496380656721365/9058634267`
- Banner test: `ca-app-pub-3940256099942544/9214589741`
- Rewarded Interstitial test: `ca-app-pub-3940256099942544/5354046379`

## Build in Android Studio

1. Extract this ZIP.
2. Open the extracted `TicTacToePro_Android_Project` folder in Android Studio.
3. Confirm `app/build.gradle.kts` shows application ID `com.rktechhub.tictactoepro`.
4. Confirm `app/src/main/AndroidManifest.xml` contains the App ID metadata.
5. Keep the normal **debug** variant selected for development. Debug always uses test ad units.
6. Sync Gradle and wait for dependency downloads to finish.
7. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`, then transfer/install it on your Android phone.
9. Test the game without network and with network. Banner may be hidden if it fails; game area expands and stays usable. Rewarded hint is awarded only after the SDK reward callback.

## Production build — only when ready

1. Check your AdMob account/app status, app-ads.txt if applicable, privacy policy, consent requirements, Data safety disclosures, and Play Console declarations.
2. Do not click your own live ads or ask testers to click them.
3. In `gradle.properties`, change `enableProductionAds=false` to `enableProductionAds=true`, then sync Gradle. This is the explicit production switch; debug builds still always use test IDs. If you have a Gradle wrapper set up, the equivalent command is `gradle assembleRelease -PenableProductionAds=true`.
4. Use **Build > Generate Signed Bundle / APK** and choose APK or Android App Bundle. Protect the signing key and passwords; keep backups offline.
5. Before sharing, re-check `enableProductionAds=true` and the two production constants in `MainActivity.kt`. A successful build does not prove that ads will serve or that monetization is enabled.

## Notes

- Native banner is outside the WebView so it does not overlay the game board.
- The hint prompt tells users the reward and provides Continue/Not now choices.
- The WebView bridge exposes only `showRewardedAd()` and loads the bundled local HTML game, not arbitrary remote pages.
- This starter does not implement Google UMP consent collection. Add and test the UMP SDK flow before serving ads in regions where consent is required; also review privacy policy and Google Play Data safety requirements.
- Production ad serving depends on account status, ad unit setup, app review, consent, policy compliance, traffic quality, and Google's systems.
- No APK build or on-device ad test is claimed by this project package.
