# मोबाइल से मुफ्त APK Build — TIC TAC TOE PRO

## जरूरी बात
यह source project है, पहले से बना APK नहीं। GitHub Actions cloud में debug APK build करेगा। Debug build में Google के test ad units ही इस्तेमाल होते हैं।

## GitHub से build
1. https://github.com पर account बनाएं / sign in करें।
2. New repository बनाएं, नाम `TicTacToePro` रखें। निजी source रखना चाहें तो Private चुनें।
3. ZIP को फोन के File Manager या ZArchiver में Extract करें।
4. GitHub repository में `Add file` → `Upload files` चुनें। Extracted project के अंदर की फाइलें और folders upload करें; `.github/workflows/build-apk.yml` सहित hidden `.github` folder भी शामिल होना चाहिए। अगर मोबाइल ब्राउज़र folder upload नहीं करता, Chrome menu में `Desktop site` आजमाएं या files/folders एक-एक करके repository में बनाएं।
5. `Commit changes` दबाएं।
6. Repository में `Actions` tab खोलें और `Build TIC TAC TOE PRO APK` workflow चुनें। अगर workflow अपने-आप शुरू न हो तो `Run workflow` दबाएं।
7. Build पूरा होने पर हरा Success status देखें। Run खोलकर नीचे `Artifacts` में `TIC-TAC-TOE-PRO-debug-APK` डाउनलोड करें। यह ZIP artifact है; इसे extract करें और अंदर की `.apk` फाइल डाउनलोड/खोलें।
8. Android पूछे तो केवल भरोसेमंद build की APK के लिए `Install unknown apps` अनुमति दें। Install के बाद चाहें तो यह अनुमति बंद कर दें।

## अगर build fail हो
Actions run खोलें, लाल failed step का error text कॉपी करें। Error देखे बिना dependency/version बदलने की जरूरत नहीं।

## सुरक्षा
- Workflow केवल `assembleDebug` बनाता है और test ads इस्तेमाल करता है।
- Production ad IDs चालू करके इस workflow से release APK न बनाएं।
- Debug APK Google Play पर publish करने के लिए नहीं है। Release के लिए अलग signing key और release build प्रक्रिया चाहिए।
- किसी signing key, password या AdMob account password को GitHub repository में upload न करें।
