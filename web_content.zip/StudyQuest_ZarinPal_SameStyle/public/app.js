const state=JSON.parse(localStorage.getItem('sq_state')||'{"name":"بازیکن","appName":"Study Quest","level":1,"coins":120,"xp":0,"streak":1,"done":[],"premium":false}');
const quests=[
 {id:1,icon:"📖",title:"۲۰ دقیقه مطالعه",desc:"+۵۰ XP",xp:50},
 {id:2,icon:"🧠",title:"حل ۱۰ تمرین",desc:"+۸۰ XP",xp:80},
 {id:3,icon:"⭐",title:"تکمیل یک درس",desc:"+۱۰۰ XP",xp:100}
];
const API_BASE=(window.STUDY_QUEST_API_BASE||'').replace(/\/$/,'');
function save(){localStorage.setItem('sq_state',JSON.stringify(state))}
function render(){
 document.getElementById('appName').textContent=state.appName;
 document.title=state.appName;
 document.getElementById('level').textContent=state.level;
 document.getElementById('coins').textContent=state.coins;
 document.getElementById('streak').textContent=state.streak;
 document.getElementById('profileLevel').textContent=state.level;
 document.getElementById('xp').textContent=state.xp;
 document.getElementById('playerName').textContent=state.name;
 document.getElementById('nameInput').value=state.name;
 document.getElementById('appNameInput').value=state.appName;
 document.getElementById('premiumStatus').textContent=state.premium?'Premium فعال است 👑':'Premium فعال نیست';
 document.getElementById('quests').innerHTML=quests.map(q=>`<div class="quest ${state.done.includes(q.id)?'done':''}"><div class="qicon">${q.icon}</div><div class="qbody"><h3>${q.title}</h3><p>${q.desc}</p></div><button onclick="completeQuest(${q.id})">${state.done.includes(q.id)?'✓ انجام شد':'شروع'}</button></div>`).join('');
}
function completeQuest(id){if(state.done.includes(id))return;const q=quests.find(x=>x.id===id);state.done.push(id);state.xp+=q.xp;state.coins+=20;if(state.xp>=300){state.level++;state.xp-=300}save();render()}
function showPage(id){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');window.scrollTo(0,0)}
function openSettings(){showPage('settings')}
function saveName(){state.name=document.getElementById('nameInput').value.trim()||'بازیکن';save();render();alert('نام ذخیره شد ✅')}
function saveAppName(){state.appName=document.getElementById('appNameInput').value.trim()||'Study Quest';save();render();alert('نام برنامه ذخیره شد ✅')}
async function startPayment(){
  const btn=document.getElementById('payBtn');
  if(!API_BASE){alert('سرور پرداخت هنوز تنظیم نشده است. در فایل public/config.js آدرس HTTPS سرور خود را وارد کنید و سپس برنامه را دوباره Build کنید.');return}
  btn.disabled=true;btn.textContent='در حال اتصال...';
  try{
    const r=await fetch(API_BASE+'/api/payment/request',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({userId:localStorage.getItem('sq_user_id')||crypto.randomUUID()})});
    const data=await r.json();
    if(!r.ok||!data.url)throw new Error(data.error||'خطا در ساخت تراکنش');
    if(data.orderId)localStorage.setItem('sq_order_id',data.orderId);
    location.href=data.url;
  }catch(e){alert('اتصال به درگاه انجام نشد:\n'+e.message)}finally{btn.disabled=false;btn.textContent='خرید'}
}
async function checkPaymentResult(){
 const p=new URLSearchParams(location.search);const status=p.get('payment');const authority=p.get('Authority');
 if(status==='success'&&authority){
   try{const r=await fetch(API_BASE+'/api/payment/result?authority='+encodeURIComponent(authority));const d=await r.json();if(d.verified){state.premium=true;save();alert('پرداخت با موفقیت تأیید شد و Premium فعال شد 👑')}else alert('پرداخت تأیید نشد.');}catch(e){alert('نتیجه پرداخت دریافت نشد.')}history.replaceState({},'',location.pathname)}
}
render();checkPaymentResult();
