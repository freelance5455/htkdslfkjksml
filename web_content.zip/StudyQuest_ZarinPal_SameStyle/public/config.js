// اگر APK را جدا از سرور اجرا می‌کنید، این مقدار را با آدرس HTTPS سرور خود عوض کنید.
// مثال: window.STUDY_QUEST_API_BASE = 'https://api.example.com';
window.STUDY_QUEST_API_BASE = '';
