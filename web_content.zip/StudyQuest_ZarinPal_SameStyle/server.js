require('dotenv').config();
const express=require('express');
const path=require('path');
const crypto=require('crypto');
const app=express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use((req,res,next)=>{res.header('Access-Control-Allow-Origin','*');res.header('Access-Control-Allow-Headers','Origin, X-Requested-With, Content-Type, Accept');next()});
const orders=new Map();
const PORT=process.env.PORT||3000;
const BASE_URL=(process.env.BASE_URL||`http://localhost:${PORT}`).replace(/\/$/,'');
const MERCHANT=process.env.ZARINPAL_MERCHANT_ID;
const AMOUNT=Number(process.env.PREMIUM_AMOUNT_RIAL||990000);
const REQUEST_URL='https://api.zarinpal.com/pg/v4/payment/request.json';
const VERIFY_URL='https://api.zarinpal.com/pg/v4/payment/verify.json';
function ensure(){if(!MERCHANT)throw new Error('ZARINPAL_MERCHANT_ID تنظیم نشده است')}
app.use(express.static(path.join(__dirname,'public')));
app.post('/api/payment/request',async(req,res)=>{
 try{
  ensure(); const userId=String(req.body.userId||'anonymous'); const orderId=crypto.randomUUID();
  const payload={merchant_id:MERCHANT,amount:AMOUNT,description:'Study Quest Premium',callback_url:`${BASE_URL}/api/payment/callback?orderId=${encodeURIComponent(orderId)}`,metadata:{mobile:'',email:''}};
  const r=await fetch(REQUEST_URL,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(payload)}); const d=await r.json();
  if(!d.data||!d.data.authority) return res.status(502).json({error:'زرین‌پال تراکنش را ایجاد نکرد. کد: '+(d.errors?.code||'unknown')});
  orders.set(orderId,{orderId,userId,authority:d.data.authority,amount:AMOUNT,status:'created'});
  res.json({orderId,url:`https://www.zarinpal.com/pg/StartPay/${d.data.authority}`});
 }catch(e){res.status(500).json({error:e.message})}
});
app.get('/api/payment/callback',async(req,res)=>{
 const order=orders.get(req.query.orderId); if(!order)return res.status(404).send('سفارش پیدا نشد');
 if(req.query.Status!=='OK')return res.redirect('/?payment=failed');
 try{
  const r=await fetch(VERIFY_URL,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({merchant_id:MERCHANT,amount:order.amount,authority:order.authority})});
  const d=await r.json(); const code=d.data?.code;
  if(code===100||code===101){order.status='verified';order.refId=d.data.ref_id;return res.redirect(`/?payment=success&Authority=${encodeURIComponent(order.authority)}`)}
  order.status='failed'; return res.redirect('/?payment=failed');
 }catch(e){order.status='error';return res.redirect('/?payment=error')}
});
app.get('/api/payment/result',(req,res)=>{const order=[...orders.values()].find(x=>x.authority===req.query.authority);res.json({verified:!!order&&order.status==='verified',refId:order?.refId||null})});
app.get('/api/health',(req,res)=>res.json({ok:true,paymentConfigured:!!MERCHANT}));
app.listen(PORT,()=>console.log(`Study Quest server running on ${BASE_URL}`));
