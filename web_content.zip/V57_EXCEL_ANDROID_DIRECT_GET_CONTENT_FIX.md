# V57 Excel Android Direct GET_CONTENT Fix

Built from V56.

- Choose File is a normal button, not an HTML label/file-input activation.
- AndroidDPM.pickImportFile() launches ACTION_GET_CONTENT directly.
- Removed nested Intent.createChooser, EXTRA_MIME_TYPES, and persistable permission flags from the picker path.
- Keeps the existing Android-side XLSX/CSV parsing and Supabase import flow.
- Version 2.23 / versionCode 27.
