# CDG Capital – Inventaire Immo (application Android)

Application d'inventaire du mobilier : plans interactifs, zones, codes-barres (scan caméra), photos par modèle, rapports PDF/Excel à partager (WhatsApp, Outlook…), **inventaire physique** avec écarts.

> L'APK n'a pas pu être compilé dans mon environnement (pas d'Android SDK). Méthode A = la plus simple (rien à installer sur le PC).

## Méthode A – APK construit gratuitement dans le cloud (GitHub Actions)
1. Compte gratuit sur https://github.com, puis un dépôt **privé** (ex. `inventaire-cdg`).
2. Envoyez-y **tout le contenu de ce dossier** (Add file > Upload files), y compris le dossier caché `.github`.
3. Onglet **Actions** > « Construire l'APK Android » > **Run workflow** (≈ 5-8 min).
4. Ouvrez l'exécution terminée > **Artifacts** > téléchargez `InventaireCDG-apk` > extrayez `app-debug.apk`.
5. Installez l'APK sur le téléphone (autorisez « Installer des applications inconnues »).

## Méthode B – Android Studio
`npm install` > `npx cap add android` > `npx capacitor-assets generate --android --assetPath assets` > ajouter la permission CAMERA dans `android/app/src/main/AndroidManifest.xml` > `npx cap sync android` > `npx cap open android` > Build APK.

## Méthode C – sans APK (Chrome Android)
Déposez le dossier `www` sur Netlify Drop (https://app.netlify.com/drop), ouvrez le lien dans Chrome > ⋮ > « Installer l'application ».

## Stockage sur le téléphone
- Les données sont enregistrées dans la mémoire de l'application (stockage interne) **et** copiées automatiquement dans `Android/data/ma.inventaire.cdgmobilier/files/InventaireCDG/sauvegarde_auto.json`.
- Menu ☰ > « Sauvegarde complète » (données + photos + plans) : partager par WhatsApp/Outlook/Drive, ou « Enregistrer dans le téléphone ».
- Si vous désinstallez l'application, les données internes sont perdues : gardez une sauvegarde partagée.

## Partage des rapports
Rapports PDF / Excel (ou Inventaire > Rapport) > **Créer le rapport** > **Partager** : la feuille de partage Android s'ouvre (WhatsApp, Outlook, Gmail, Drive…). « Partager le résumé (texte) » envoie un résumé sans pièce jointe.

## Scanner avec la caméra
Bouton 📷 : la caméra s'ouvre automatiquement. **🎥 Caméra ON/OFF**, **🔦 Flash ON/OFF** (si le téléphone le permet), **Autre caméra**, **Zoom**. Si la caméra ne s'ouvre pas : autorisez-la dans les réglages d'Android, ou utilisez « Photographier le code-barres ».

## Inventaire physique
Onglet **📋 Inventaire** : démarrer (tous les étages / étage / zone) > choisir une zone > scanner les codes (caméra ou saisie) > « Zone terminée » > « Clôturer » > rapport (manquants, hors zone, inconnus) à partager en PDF ou Excel. Les déplacements constatés peuvent être appliqués aux données.

## Plans
Boutons de l'étage : « Ajouter / changer le plan », « Supprimer le plan » (récupérable dans la Corbeille), « + Étage / plan » (nouvel étage).
