# Inventaire CDG – application Android (APK)

Ce dossier contient l'application d'inventaire du mobilier (plans, zones, codes-barres, photos, rapports PDF/Excel) prête à être transformée en **APK Android**.

> Je n'ai pas pu compiler l'APK moi-même (pas d'Android SDK dans mon environnement). Les 3 méthodes ci-dessous sont les méthodes standard ; la méthode A est la plus simple (rien à installer sur votre PC).

## Méthode A – APK construit gratuitement dans le cloud (GitHub Actions)
1. Créez un compte gratuit sur https://github.com puis un nouveau dépôt **privé** (ex. `inventaire-cdg`).
2. Envoyez-y **tout le contenu de ce dossier** (bouton « Add file » > « Upload files »), y compris le dossier caché `.github`.
3. Onglet **Actions** > « Construire l'APK Android » > **Run workflow**. Attendez ~5-8 minutes.
4. Ouvrez l'exécution terminée > section **Artifacts** > téléchargez `InventaireCDG-apk` (zip) > extrayez `app-debug.apk`.
5. Copiez l'APK sur le téléphone et installez-le (autorisez « Installer des applications inconnues »). Si Play Protect avertit, choisissez « Installer quand même » (APK non publié sur le Play Store).

## Méthode B – Android Studio (sur PC)
1. Installez Node.js 20, Java 17 et Android Studio.
2. Dans ce dossier : `npm install`, puis `npx cap add android`.
3. Dans `android/app/src/main/AndroidManifest.xml`, ajoutez sous la ligne INTERNET :
   `<uses-permission android:name="android.permission.CAMERA" />` et
   `<uses-feature android:name="android.hardware.camera" android:required="false" />`
4. `npx cap sync android` puis `npx cap open android` > **Build > Build APK(s)**.

## Méthode C – sans APK : installer comme application depuis Chrome (PWA)
Déposez le dossier `www` sur un hébergement HTTPS (Netlify Drop : https://app.netlify.com/drop – glisser-déposer le dossier `www`), ouvrez le lien dans **Chrome Android** > menu ⋮ > **Installer l'application**. Fonctionne hors-ligne, avec caméra, partage et stockage sur le téléphone.

## Où sont les données ?
- Stockées **dans la mémoire du téléphone** (stockage de l'application : données, photos, plans). Elles restent après fermeture/redémarrage, mais sont effacées si vous désinstallez l'application ou videz ses données.
- Menu ☰ > **Sauvegarde complète** : partagez le fichier JSON (WhatsApp, Outlook, Drive…) ou, sur l'APK, **Enregistrer dans les Documents du téléphone**. Faites-le régulièrement.

## Partager les rapports (WhatsApp, Outlook…)
Bouton **Rapports PDF / Excel** > choisir PDF ou Excel > **Partager** : la feuille de partage Android s'ouvre (WhatsApp, Outlook, Gmail, Drive…). « Télécharger / enregistrer » écrit le fichier dans Documents/InventaireCDG (si Android l'autorise ; sinon la feuille de partage s'ouvre pour l'enregistrer dans Fichiers).

## Scanner avec la caméra
Disponible partout où l'on saisit des codes-barres : fenêtre « Codes-barres » d'une ligne, formulaire « Ajouter du mobilier », et recherche (bouton « Scanner » en haut). Bouton **Flash ON/OFF** et **Autre caméra** dans le scanner (le flash dépend du téléphone/navigateur ; s'il n'est pas disponible, le bouton n'apparaît pas). Vous pouvez toujours saisir ou coller un code manuellement.

## Logo et écran de démarrage
Le dossier `assets/` contient l'icône et l'écran de démarrage (noir / blanc / vert). Ils sont appliqués automatiquement à l'APK (étape `capacitor-assets` du workflow). Méthode B : après `npx cap add android`, lancez `npx capacitor-assets generate --android --assetPath assets`.

## Si le scan caméra ne s'ouvre pas
- Le scan **en direct** exige une page sécurisée : l'APK, ou l'application installée depuis Chrome (HTTPS). Un fichier HTML ouvert depuis le Gestionnaire de fichiers est bloqué par Android.
- Dans tous les cas, le bouton **« Photographier le code-barres »** ouvre l'appareil photo du téléphone et lit le code sur la photo (fonctionne partout).
- Si la caméra est refusée : réglages du navigateur > Autorisations du site > Caméra > Autoriser.
