const chatForm = document.getElementById("chatForm");
const messageInput = document.getElementById("messageInput");
const chatMessages = document.getElementById("chatMessages");

chatForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const messageText = messageInput.value.trim();

    if (messageText === "") {
        return;
    }

    const message = document.createElement("div");
    message.className = "message user-message";

    const text = document.createElement("p");
    text.textContent = messageText;

    const time = document.createElement("span");
    time.className = "message-time";

    time.textContent = new Date().toLocaleTimeString("bn-BD", {
        hour: "2-digit",
        minute: "2-digit"
    });

    message.appendChild(text);
    message.appendChild(time);

    chatMessages.appendChild(message);

    messageInput.value = "";

    chatMessages.scrollIntoView({
        behavior: "smooth",
        block: "end"
    });

    messageInput.focus();
});