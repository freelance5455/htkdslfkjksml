const products = [
  {
    id: 1,
    name: "ট্র্যাডিশনাল শাড়ি",
    category: "ফ্যাশন",
    price: 1500,
    oldPrice: 1900,
    discount: 20,
    rating: 4.8,
    reviews: 120,
    image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=500&q=80"
  },
  {
    id: 2,
    name: "কটন ক্যাজুয়াল শার্ট",
    category: "ফ্যাশন",
    price: 850,
    oldPrice: 1000,
    discount: 15,
    rating: 4.6,
    reviews: 98,
    image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=500&q=80"
  },
  {
    id: 3,
    name: "গোল্ডেন ডিজাইনের কানের দুল",
    category: "জুয়েলারি",
    price: 450,
    oldPrice: 500,
    discount: 10,
    rating: 4.7,
    reviews: 65,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=500&q=80"
  },
  {
    id: 4,
    name: "স্মার্টফোন",
    category: "ইলেকট্রনিক্স",
    price: 22000,
    oldPrice: 25000,
    discount: 12,
    rating: 4.5,
    reviews: 80,
    image: "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=500&q=80"
  },
  {
    id: 5,
    name: "হোম ডেকর সেট",
    category: "হোম",
    price: 1350,
    oldPrice: 1500,
    discount: 10,
    rating: 4.3,
    reviews: 42,
    image: "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=500&q=80"
  },
  {
    id: 6,
    name: "বিউটি কেয়ার সেট",
    category: "বিউটি",
    price: 750,
    oldPrice: 950,
    discount: 21,
    rating: 4.6,
    reviews: 56,
    image: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=500&q=80"
  },
  {
    id: 7,
    name: "উপহারের বিশেষ প্যাক",
    category: "উপহার",
    price: 650,
    oldPrice: 800,
    discount: 19,
    rating: 4.7,
    reviews: 37,
    image: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=500&q=80"
  },
  {
    id: 8,
    name: "নোটবুক ও স্টেশনারি",
    category: "বই",
    price: 350,
    oldPrice: 450,
    discount: 22,
    rating: 4.4,
    reviews: 29,
    image: "https://images.unsplash.com/photo-1531346878377-a5be20888e57?auto=format&fit=crop&w=500&q=80"
  }
];

/* DOM Elements */

const productGrid = document.getElementById("productGrid");
const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const cartCount = document.getElementById("cartCount");
const emptyMessage = document.getElementById("emptyMessage");

/* Application State */

let cart = [];
let favorites = new Set();
let activeCategory = "";

/* Price Formatting */

function formatPrice(price) {
  return "৳ " + price.toLocaleString("en-US");
}

/* Render Products */

function renderProducts(list) {
  productGrid.innerHTML = "";

  emptyMessage.hidden = list.length > 0;

  list.forEach(product => {
    const card = document.createElement("article");
    card.className = "product-card";

    const imageWrap = document.createElement("div");
    imageWrap.className = "product-image-wrap";

    const image = document.createElement("img");
    image.className = "product-image";
    image.src = product.image;
    image.alt = product.name;
    image.loading = "lazy";

    image.onerror = () => {
      image.style.display = "none";

      imageWrap.style.background =
        "linear-gradient(135deg, #e7f3ed, #f5e7d9)";

      imageWrap.style.display = "grid";
      imageWrap.style.placeItems = "center";

      const fallback = document.createElement("span");
      fallback.textContent = "🛍️";
      fallback.style.fontSize = "48px";

      imageWrap.appendChild(fallback);
    };

    const discount = document.createElement("span");
    discount.className = "discount";
    discount.textContent = "-" + product.discount + "%";

    const wishlist = document.createElement("button");
    wishlist.className = "wishlist";
    wishlist.type = "button";

    wishlist.textContent = favorites.has(product.id) ? "♥" : "♡";

    wishlist.classList.toggle(
      "active",
      favorites.has(product.id)
    );

    wishlist.setAttribute(
      "aria-label",
      "পছন্দের তালিকায় যোগ করুন"
    );

    wishlist.addEventListener("click", () => {
      if (favorites.has(product.id)) {
        favorites.delete(product.id);
      } else {
        favorites.add(product.id);
      }

      wishlist.textContent =
        favorites.has(product.id) ? "♥" : "♡";

      wishlist.classList.toggle(
        "active",
        favorites.has(product.id)
      );
    });

    imageWrap.append(image, discount, wishlist);

    const info = document.createElement("div");
    info.className = "product-info";

    const category = document.createElement("p");
    category.className = "product-category";
    category.textContent = product.category;

    const name = document.createElement("h3");
    name.textContent = product.name;

    const rating = document.createElement("p");
    rating.className = "rating";
    rating.textContent = "★ " + product.rating + " ";

    const reviews = document.createElement("span");
    reviews.textContent = "(" + product.reviews + ")";

    rating.appendChild(reviews);

    const price = document.createElement("div");
    price.className = "price";

    const currentPrice = document.createElement("strong");
    currentPrice.textContent = formatPrice(product.price);

    const oldPrice = document.createElement("del");
    oldPrice.textContent = formatPrice(product.oldPrice);

    price.append(currentPrice, oldPrice);

    const addButton = document.createElement("button");
    addButton.className = "add-cart";
    addButton.type = "button";
    addButton.textContent = "🛒 কার্টে যোগ করুন";

    addButton.addEventListener("click", () => {
      cart.push(product.id);
      cartCount.textContent = cart.length;

      addButton.textContent = "✓ কার্টে যোগ হয়েছে";
      addButton.style.background = "#0b9b6c";

      setTimeout(() => {
        addButton.textContent = "🛒 কার্টে যোগ করুন";
        addButton.style.background = "";
      }, 1000);
    });

    info.append(
      category,
      name,
      rating,
      price,
      addButton
    );

    card.append(imageWrap, info);
    productGrid.appendChild(card);
  });
}

/* Product Search and Category Filtering */

function filterProducts() {
  const query = searchInput.value.trim().toLowerCase();

  const filtered = products.filter(product => {
    const matchesSearch =
      product.name.toLowerCase().includes(query) ||
      product.category.toLowerCase().includes(query);

    const matchesCategory =
      !activeCategory ||
      product.category === activeCategory;

    return matchesSearch && matchesCategory;
  });

  renderProducts(filtered);
}

searchForm.addEventListener("submit", event => {
  event.preventDefault();

  filterProducts();

  document.getElementById("products").scrollIntoView({
    behavior: "smooth"
  });
});

searchInput.addEventListener("input", filterProducts);

document.querySelectorAll(".category").forEach(categoryLink => {
  categoryLink.addEventListener("click", () => {
    activeCategory = categoryLink.dataset.category;
    searchInput.value = "";

    filterProducts();
  });
});

document.getElementById("showAll").addEventListener("click", event => {
  event.preventDefault();

  activeCategory = "";
  searchInput.value = "";

  renderProducts(products);
});

/* Help Center */

document.getElementById("helpButton").addEventListener("click", () => {
  alert(
    "BanglaShop সহায়তা কেন্দ্রে স্বাগতম!\nযোগাযোগের তথ্য এখানে যোগ করতে পারো।"
  );
});

/* Back to Top */

const backTop = document.getElementById("backTop");

window.addEventListener("scroll", () => {
  backTop.style.display =
    window.scrollY > 300 ? "block" : "none";
});

backTop.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
});

/* Initial Product Rendering */

renderProducts(products);

/* Product Details, Reviews, Cart and Checkout */

(() => {
  const productOverlay = document.getElementById("productOverlay");
  const cartOverlay = document.getElementById("cartOverlay");
  const checkoutOverlay = document.getElementById("checkoutOverlay");

  if (!productOverlay || !cartOverlay || !checkoutOverlay) {
    console.error(
      "BanglaShop: Required overlay elements were not found."
    );
    return;
  }

  const addedReviews = new Map();
  let selectedProduct = null;

  /* Dialog Helpers */

  function makeDialog(overlay, title) {
    let dialog = overlay.querySelector(".shop-dialog");

    if (!dialog) {
      dialog = document.createElement("div");
      dialog.className = "shop-dialog";

      overlay.appendChild(dialog);
    }

    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-label", title);

    return dialog;
  }

  function openOverlay(overlay) {
    overlay.classList.add("active");
    document.body.style.overflow = "hidden";
  }

  function closeOverlay(overlay) {
    overlay.classList.remove("active");

    if (!document.querySelector(".shop-overlay.active")) {
      document.body.style.overflow = "";
    }
  }

  function addCloseButton(dialog) {
    const close = document.createElement("button");

    close.type = "button";
    close.className = "shop-close";
    close.textContent = "×";

    close.setAttribute("aria-label", "বন্ধ করুন");

    close.addEventListener("click", () => {
      closeOverlay(dialog.closest(".shop-overlay"));
    });

    dialog.appendChild(close);
  }

  /* Overlay Events */

  [
    productOverlay,
    cartOverlay,
    checkoutOverlay
  ].forEach(overlay => {
    overlay.classList.add("shop-overlay");

    overlay.addEventListener("click", event => {
      if (event.target === overlay) {
        closeOverlay(overlay);
      }
    });

    overlay.addEventListener("click", event => {
      const closeButton = event.target.closest(".shop-close");

      if (closeButton && overlay.contains(closeButton)) {
        closeOverlay(overlay);
      }
    });
  });

  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      [
        productOverlay,
        cartOverlay,
        checkoutOverlay
      ].forEach(overlay => {
        if (overlay.classList.contains("active")) {
          closeOverlay(overlay);
        }
      });
    }
  });

  /* Find Product */

  function getProductFromCard(card) {
    const name = card
      .querySelector(".product-info h3")
      ?.textContent.trim();

    return products.find(product => product.name === name);
  }

  /* Render Product Reviews */

  function renderReviews(dialog, product) {
    const reviewList = dialog.querySelector("#shopReviewList");
    const reviews = addedReviews.get(product.id) || [];

    reviewList.replaceChildren();

    if (reviews.length === 0) {
      const message = document.createElement("p");

      message.className = "shop-note";
      message.textContent = "এখনো কোনো নতুন রিভিউ লেখা হয়নি।";

      reviewList.appendChild(message);

      return;
    }

    reviews.forEach(review => {
      const item = document.createElement("div");
      item.className = "shop-review";

      const heading = document.createElement("strong");

      heading.textContent =
        "★".repeat(review.rating) +
        "☆".repeat(5 - review.rating) +
        " — " +
        review.name;

      const content = document.createElement("p");
      content.textContent = review.comment;

      item.append(heading, content);
      reviewList.appendChild(item);
    });
  }

  /* Product Details */

  function showProduct(product) {
    selectedProduct = product;

    const dialog = makeDialog(
      productOverlay,
      "পণ্যের বিস্তারিত"
    );

    dialog.replaceChildren();
    addCloseButton(dialog);

    const heading = document.createElement("h2");
    heading.textContent = product.name;

    const image = document.createElement("img");
    image.className = "shop-product-image";
    image.src = product.image;
    image.alt = product.name;

    const category = document.createElement("p");
    category.textContent = "ক্যাটাগরি: " + product.category;

    const price = document.createElement("p");
    price.className = "shop-price";
    price.textContent = formatPrice(product.price);

    const oldPrice = document.createElement("p");
    oldPrice.className = "shop-note";

    oldPrice.textContent =
      "আগের দাম: " +
      formatPrice(product.oldPrice) +
      " | ছাড়: " +
      product.discount +
      "%";

    const rating = document.createElement("p");
    rating.className = "rating";

    rating.textContent =
      "★ " +
      product.rating +
      " (" +
      product.reviews +
      "টি পুরোনো রিভিউ)";

    const description = document.createElement("p");

    description.textContent =
      "পণ্যটি অর্ডার করার আগে দাম ও বিবরণ দেখে নিন।";

    const addButton = document.createElement("button");

    addButton.type = "button";
    addButton.className = "shop-btn";
    addButton.textContent = "🛒 কার্টে যোগ করুন";

    addButton.addEventListener("click", () => {
      cart.push(product.id);
      cartCount.textContent = cart.length;

      addButton.textContent = "✓ কার্টে যোগ হয়েছে";
    });

    const reviewHeading = document.createElement("h3");
    reviewHeading.textContent = "ক্রেতাদের রিভিউ";

    const reviewList = document.createElement("div");
    reviewList.id = "shopReviewList";

    /* Review Form */

    const reviewForm = document.createElement("form");
    reviewForm.id = "shopReviewForm";

    reviewForm.innerHTML = `
      <h3>নতুন রিভিউ লিখুন</h3>

      <div class="shop-field">
        <label for="shopReviewerName">আপনার নাম</label>
        <input
          id="shopReviewerName"
          name="reviewerName"
          type="text"
          maxlength="60"
          required
        >
      </div>

      <div class="shop-field">
        <label for="shopReviewerRating">রেটিং</label>
        <select
          id="shopReviewerRating"
          name="reviewerRating"
          required
        >
          <option value="5">৫ ★</option>
          <option value="4">৪ ★</option>
          <option value="3">৩ ★</option>
          <option value="2">২ ★</option>
          <option value="1">১ ★</option>
        </select>
      </div>

      <div class="shop-field">
        <label for="shopReviewerComment">আপনার মতামত</label>
        <textarea
          id="shopReviewerComment"
          name="reviewerComment"
          rows="3"
          maxlength="1000"
          required
        ></textarea>
      </div>

      <button class="shop-btn" type="submit">
        রিভিউ জমা দিন
      </button>
    `;

    reviewForm.addEventListener("submit", event => {
      event.preventDefault();

      const name =
        reviewForm.elements.reviewerName.value.trim();

      const comment =
        reviewForm.elements.reviewerComment.value.trim();

      const reviewRating = Number(
        reviewForm.elements.reviewerRating.value
      );

      if (
        !name ||
        !comment ||
        reviewRating < 1 ||
        reviewRating > 5
      ) {
        alert("সব তথ্য সঠিকভাবে পূরণ করুন.");
        return;
      }

      if (!addedReviews.has(product.id)) {
        addedReviews.set(product.id, []);
      }

      addedReviews.get(product.id).push({
        name,
        comment,
        rating: reviewRating
      });

      reviewForm.reset();

      renderReviews(dialog, product);

      alert("আপনার রিভিউ এই সেশনে যোগ হয়েছে।");
    });

    dialog.append(
      heading,
      image,
      category,
      price,
      oldPrice,
      rating,
      description,
      addButton,
      reviewHeading,
      reviewList,
      reviewForm
    );

    renderReviews(dialog, product);
    openOverlay(productOverlay);
  }

  /* Open Product Details */

  productGrid.addEventListener("click", event => {
    if (event.target.closest("button")) return;

    const card = event.target.closest(".product-card");

    if (!card) return;

    const product = getProductFromCard(card);

    if (product) {
      showProduct(product);
    }
  });

  /* Get Cart Items */

  function getCartItems() {
    return cart
      .map(id => products.find(product => product.id === id))
      .filter(Boolean);
  }

  /* Render Shopping Cart */

  function renderCart() {
    const dialog = makeDialog(
      cartOverlay,
      "আপনার কার্ট"
    );

    dialog.replaceChildren();
    addCloseButton(dialog);

    const heading = document.createElement("h2");
    heading.textContent = "🛒 আপনার শপিং কার্ট";

    dialog.appendChild(heading);

    const items = getCartItems();

    if (items.length === 0) {
      const empty = document.createElement("p");

      empty.className = "shop-note";
      empty.textContent = "আপনার কার্ট এখন খালি।";

      dialog.appendChild(empty);
    } else {
      const grouped = new Map();

      items.forEach(product => {
        const entry = grouped.get(product.id) || {
          product,
          quantity: 0
        };

        entry.quantity++;

        grouped.set(product.id, entry);
      });

      grouped.forEach(({ product, quantity }) => {
        const row = document.createElement("div");
        row.className = "shop-cart-row";

        const details = document.createElement("div");

        const name = document.createElement("strong");
        name.textContent = product.name;

        const info = document.createElement("p");

        info.textContent =
          formatPrice(product.price) +
          " × " +
          quantity;

        details.append(name, info);

        const remove = document.createElement("button");

        remove.type = "button";
        remove.textContent = "একটি বাদ দিন";

        remove.addEventListener("click", () => {
          const index = cart.indexOf(product.id);

          if (index !== -1) {
            cart.splice(index, 1);
          }

          cartCount.textContent = cart.length;

          renderCart();
        });

        row.append(details, remove);
        dialog.appendChild(row);
      });

      const total = items.reduce(
        (sum, product) => sum + product.price,
        0
      );

      const totalLine = document.createElement("p");

      totalLine.className = "shop-price";
      totalLine.textContent = "মোট: " + formatPrice(total);

      dialog.appendChild(totalLine);

      const checkoutButton = document.createElement("button");

      checkoutButton.type = "button";
      checkoutButton.className = "shop-btn";
      checkoutButton.textContent = "চেকআউট করুন";

      checkoutButton.addEventListener("click", () => {
        closeOverlay(cartOverlay);
        showCheckout();
      });

      dialog.appendChild(checkoutButton);
    }

    openOverlay(cartOverlay);
  }

  /* Checkout */

  function showCheckout() {
    if (cart.length === 0) {
      alert("চেকআউট করার আগে কার্টে পণ্য যোগ করুন.");
      return;
    }

    const dialog = makeDialog(
      checkoutOverlay,
      "ডেলিভারি তথ্য"
    );

    dialog.replaceChildren();
    addCloseButton(dialog);

    const heading = document.createElement("h2");
    heading.textContent = "ডেলিভারি ও পেমেন্ট";

    const total = getCartItems().reduce(
      (sum, product) => sum + product.price,
      0
    );

    const totalLine = document.createElement("p");

    totalLine.className = "shop-price";
    totalLine.textContent = "মোট মূল্য: " + formatPrice(total);

    /* Checkout Form */

    const form = document.createElement("form");
    form.id = "shopCheckoutForm";

    form.innerHTML = `
      <div class="shop-field">
        <label for="shopCustomerName">আপনার পুরো নাম</label>
        <input
          id="shopCustomerName"
          name="customerName"
          type="text"
          maxlength="100"
          autocomplete="name"
          required
        >
      </div>

      <div class="shop-field">
        <label for="shopDistrict">জেলা</label>
        <input
          id="shopDistrict"
          name="district"
          type="text"
          maxlength="80"
          required
        >
      </div>

      <div class="shop-field">
        <label for="shopUpazila">উপজেলা / থানা</label>
        <input
          id="shopUpazila"
          name="upazila"
          type="text"
          maxlength="80"
          required
        >
      </div>

      <div class="shop-field">
        <label for="shopAddress">
          গ্রাম / এলাকা / সম্পূর্ণ ঠিকানা
        </label>
        <textarea
          id="shopAddress"
          name="address"
          rows="3"
          maxlength="300"
          autocomplete="street-address"
          required
        ></textarea>
      </div>

      <div class="shop-field">
        <label for="shopPhone">মোবাইল নম্বর</label>
        <input
          id="shopPhone"
          name="phone"
          type="tel"
          inputmode="numeric"
          autocomplete="tel"
          pattern="01[3-9][0-9]{8}"
          placeholder="01XXXXXXXXX"
          title="বাংলাদেশের ১১ সংখ্যার বৈধ মোবাইল নম্বর দিন"
          required
        >
      </div>

      <button class="shop-btn" type="submit">
        তথ্য যাচাই করে পেমেন্টে যান
      </button>
    `;

    /* Payment Area */

    const paymentArea = document.createElement("div");

    paymentArea.id = "shopPaymentArea";
    paymentArea.hidden = true;

    const note = document.createElement("p");

    note.className = "shop-note";

    note.textContent =
      "এটি ডেমো পেমেন্ট অপশন। এই পেজ থেকে এখনই টাকা কাটা বা অর্ডার নিশ্চিত হবে না।";

    const paymentButton = document.createElement("button");

    paymentButton.type = "button";
    paymentButton.className = "shop-btn bkash";
    paymentButton.textContent = "বিকাশ পেমেন্ট";

    paymentButton.addEventListener("click", () => {
      alert(
        "বিকাশ পেমেন্টের আসল ব্যবস্থা এখনো সংযুক্ত নেই। " +
        "কোনো টাকা পাঠানো হয়নি এবং অর্ডার নিশ্চিত হয়নি।"
      );
    });

    paymentArea.append(note, paymentButton);

    form.addEventListener("submit", event => {
      event.preventDefault();

      if (!form.reportValidity()) return;

      paymentArea.hidden = false;

      paymentArea.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
      });
    });

    dialog.append(
      heading,
      totalLine,
      form,
      paymentArea
    );

    openOverlay(checkoutOverlay);
  }

  /* Connect Cart Button */

  const cartLink =
    document.getElementById("cartButton") ||
    cartCount?.closest("a") ||
    document.querySelector(
      'a[href="#cart"], a[href="#cartOverlay"], [data-open-cart]'
    );

  if (cartLink) {
    cartLink.addEventListener("click", event => {
      event.preventDefault();
      renderCart();
    });
  }

  /* Expose Functions */

  window.banglaShopOpenCart = renderCart;
  window.banglaShopOpenCheckout = showCheckout;

  /* Synchronize Cart Count */

  cartCount.textContent = cart.length;
})();