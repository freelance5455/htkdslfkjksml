Zain Eleven Android project

This Android Studio project wraps your supplied HTML/JavaScript cricket scorer in an Android WebView.
It enables JavaScript and DOM storage so the app's interactive controls and local saved match history can work.

Build an APK:
1. Install Android Studio on a computer.
2. Extract this project ZIP.
3. In Android Studio, choose Open and select the extracted ZainEleven_Android_Project folder.
4. Allow Gradle sync to finish (internet may be required for Android Gradle Plugin downloads).
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the output location for app-debug.apk.

Important:
- This ZIP is the Android Studio source project, not a compiled APK.
- Test the app on your Android device before using it for real matches.
