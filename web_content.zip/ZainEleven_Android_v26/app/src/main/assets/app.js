
const $=id=>document.getElementById(id);
let game=null, undoStack=[], selectedScoreTeam='A';
function makePlayerInputs(team,box,count=+$('playerCount')?.value||11){$(box).innerHTML='';for(let i=1;i<=count;i++){let row=document.createElement('div');row.className='player-setup-row';let inp=document.createElement('input');inp.id=team+i;inp.value=`Team ${team} Player ${i}`;inp.placeholder=`Player ${i}`;inp.setAttribute('aria-label',`Team ${team} player ${i}`);let role=document.createElement('select');role.id='role'+team+i;role.setAttribute('aria-label',`Team ${team} player ${i} role`);role.innerHTML='<option value="batsman">Batsman</option><option value="bowler">Bowler</option><option value="allrounder" selected>All-rounder</option>';row.append(inp,role);$(box).append(row)}}
function refreshRoleSelectors(){['A','B'].forEach(t=>{['captain','viceCaptain','keeper'].forEach(role=>{let el=$(role+t);if(!el)return;let old=el.value;let count=Math.max(1,Math.min(11,parseInt($('playerCount').value,10)||11));let names=Array.from({length:count},(_,i)=>{let input=$(t+(i+1));return input?(input.value.trim()||`Player ${i+1}`):`Player ${i+1}`});el.innerHTML=names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');if(names.includes(old))el.value=old})})}
function loadPlayerNames(){try{const saved=JSON.parse(localStorage.getItem('zainElevenPlayerNames')||'null');if(!saved)return;if(saved.teamA)$('teamA').value=saved.teamA;if(saved.teamB)$('teamB').value=saved.teamB;if(saved.count){$('playerCount').value=String(Math.max(1,Math.min(11,+saved.count||11)));makePlayerInputs('A','playersA',+$('playerCount').value);makePlayerInputs('B','playersB',+$('playerCount').value)};['A','B'].forEach(t=>(saved[t]||[]).forEach((n,i)=>{const el=$(t+(i+1));if(el)el.value=n}));['A','B'].forEach(t=>(saved['roles'+t]||[]).forEach((r,i)=>{const el=$('role'+t+(i+1));if(el&&['batsman','bowler','allrounder'].includes(r))el.value=r}))}catch(e){console.warn('Could not load saved player names',e)}refreshRoleSelectors()}
function savePlayerNames(){const count=Math.max(1,Math.min(11,parseInt($('playerCount').value,10)||11));const data={teamA:$('teamA').value.trim(),teamB:$('teamB').value.trim(),count,A:Array.from({length:count},(_,i)=>$('A'+(i+1)).value.trim()),B:Array.from({length:count},(_,i)=>$('B'+(i+1)).value.trim()),rolesA:Array.from({length:count},(_,i)=>$('roleA'+(i+1)).value),rolesB:Array.from({length:count},(_,i)=>$('roleB'+(i+1)).value)};try{localStorage.setItem('zainElevenPlayerNames',JSON.stringify(data));$('playersSavedNote').textContent='✓ Player names saved on this device.';return true}catch(e){alert('Could not save names on this device.');return false}}
function updatePlayerInputs(value){let count=Math.max(1,Math.min(11,parseInt(value,10)||11));makePlayerInputs('A','playersA',count);makePlayerInputs('B','playersB',count);$('playersSavedNote').textContent='Player count changed. Save the names again to keep them.';refreshRoleSelectors()}
let audioContext=null;
let batHitAudio=null;
function playBatHit(){
 try{
  if(!batHitAudio){batHitAudio=new Audio('sounds/cricket-bat-hitting-sound.mp3');batHitAudio.preload='auto';}
  batHitAudio.pause();batHitAudio.currentTime=0;
  const clip=batHitAudio.cloneNode();
  clip.volume=0.9;
  clip.play().catch(e=>console.warn('Bat-hit sound unavailable',e));
 }catch(e){console.warn('Bat-hit sound unavailable',e)}
}
function playEffect(kind){
 // Short, louder cricket-style tones as a fallback when spoken audio is unavailable.
 try {
  const Ctx=window.AudioContext||window.webkitAudioContext;
  if(!Ctx)return;
  audioContext=audioContext||new Ctx();
  const ctx=audioContext;
  if(ctx.state==='suspended')ctx.resume();
  const patterns={
   four:[{f:520,t:0,d:.16},{f:690,t:.17,d:.16},{f:880,t:.34,d:.34}],
   six:[{f:520,t:0,d:.12},{f:660,t:.13,d:.12},{f:790,t:.26,d:.12},{f:990,t:.39,d:.16},{f:1180,t:.56,d:.42}],
   wicket:[{f:560,t:0,d:.12},{f:410,t:.14,d:.16},{f:280,t:.32,d:.22},{f:180,t:.56,d:.34}],
   noball:[{f:760,t:0,d:.18},{f:520,t:.20,d:.18},{f:760,t:.40,d:.22}]
  };
  (patterns[kind]||patterns.four).forEach(n=>{
   const o=ctx.createOscillator(),g=ctx.createGain();
   o.type=(kind==='wicket'||kind==='noball')?'sawtooth':'triangle';
   o.frequency.setValueAtTime(n.f,ctx.currentTime+n.t);
   g.gain.setValueAtTime(.0001,ctx.currentTime+n.t);
   g.gain.exponentialRampToValueAtTime(.32,ctx.currentTime+n.t+.02);
   g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+n.t+n.d);
   o.connect(g);g.connect(ctx.destination);o.start(ctx.currentTime+n.t);o.stop(ctx.currentTime+n.t+n.d+.03);
  });
 }catch(e){console.warn('Audio effect unavailable',e)}
}
function announce(text){
 try{
  if(!('speechSynthesis' in window)||typeof SpeechSynthesisUtterance==='undefined')return;
  window.speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.lang='en-GB';u.rate=.88;u.pitch=1.05;u.volume=1;
  const voices=window.speechSynthesis.getVoices();
  const voice=voices.find(v=>/^en(-GB)?$/i.test(v.lang)&&/female|english|uk|british/i.test(v.name))||voices.find(v=>/^en/i.test(v.lang));
  if(voice)u.voice=voice;
  window.speechSynthesis.speak(u);
 }catch(e){console.warn('Speech announcement unavailable',e)}
}

let uiClickContext=null;
function playUiClick(){
 try{
  const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)return;
  uiClickContext=uiClickContext||new Ctx();const ctx=uiClickContext;
  if(ctx.state==='suspended')ctx.resume();
  const osc=ctx.createOscillator(),gain=ctx.createGain();
  osc.type='sine';osc.frequency.setValueAtTime(880,ctx.currentTime);osc.frequency.exponentialRampToValueAtTime(620,ctx.currentTime+.035);
  gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.075,ctx.currentTime+.006);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.045);
  osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.05);
 }catch(e){/* Sound is optional; never block a button action. */}
}
function teamName(t){return game.names[t]}
function players(t){return game.lineups[t]}
function roleFor(t,name){let i=game.lineups[t].indexOf(name);return game.playerRoles?.[t]?.[name]||'allrounder'}
function orderLineupsForRoles(){for(const t of ['A','B']){const original=game.lineups[t];const rolePriority=role=>t===game.bat?(role==='batsman'?0:role==='allrounder'?1:2):(role==='bowler'?0:role==='allrounder'?1:2);original.sort((a,b)=>rolePriority(roleFor(t,a))-rolePriority(roleFor(t,b)))}}
function oversText(b){return Math.floor(b/6)+'.'+(b%6)}
function newStats(names,kind){let o={};names.forEach(n=>o[n]=kind==='bat'?{runs:0,balls:0,fours:0,sixes:0,out:false}:{balls:0,runs:0,wickets:0});return o}
function startMatch(){let a=$('teamA').value.trim(),b=$('teamB').value.trim();if(!a||!b||a===b){alert('Enter two different team names.');return}
let count=Math.max(1,Math.min(11,parseInt($('playerCount').value,10)||11));let overs=Math.max(1,Math.min(1000,parseInt($('overs').value,10)||20));$('overs').value=overs;let la=Array.from({length:count},(item,i)=>$('A'+(i+1)).value.trim()||`Player ${i+1}`),lb=Array.from({length:count},(item,i)=>$('B'+(i+1)).value.trim()||`Player ${i+1}`);
if(new Set(la).size!==la.length||new Set(lb).size!==lb.length){alert('Player names must be unique within each team.');return}
refreshRoleSelectors();const playerRoles={A:{},B:{}};for(const t of ['A','B'])for(let i=0;i<count;i++){const name=(t==='A'?la:lb)[i];playerRoles[t][name]=$('role'+t+(i+1))?.value||'allrounder'}game={names:{A:a,B:b},lineups:{A:la,B:lb},playerRoles,roles:{A:{captain:$('captainA').value,viceCaptain:$('viceCaptainA').value,keeper:$('keeperA').value},B:{captain:$('captainB').value,viceCaptain:$('viceCaptainB').value,keeper:$('keeperB').value}},overs:overs,first:$('first').value,bat:$('first').value,bowl:$('first').value==='A'?'B':'A',inn:1,runs:0,wickets:0,balls:0,extras:0,target:null,si:0,ni:1,next:2,bi:0,batStats:{},bowlStats:{},records:[],finished:false,lastBall:null,bowlerChanges:[],lastCompletedOverBowler:null,overLog:[],currentOver:{bowler:null,runs:0,wickets:0,balls:0,deliveries:0}};
resetInnings();undoStack=[];$('setup').classList.add('hidden');$('resultScreen').classList.add('hidden');$('match').classList.remove('hidden');render()}
function resetInnings(){orderLineupsForRoles();game.runs=0;game.wickets=0;game.balls=0;game.extras=0;game.si=0;game.ni=players(game.bat).length>1?1:0;game.next=players(game.bat).length>1?2:1;game.bi=0;game.lastBall=null;game.bowlerChanges=[];game.lastCompletedOverBowler=null;game.overLog=[];game.currentOver={bowler:null,runs:0,wickets:0,balls:0,deliveries:0};game.batStats=newStats(players(game.bat),'bat');game.bowlStats=newStats(players(game.bowl),'bowl')}
function snap(){undoStack.push(JSON.stringify(game));if(undoStack.length>100)undoStack.shift()}
function currentBatter(){return players(game.bat)[game.si]}
function currentBowler(){return players(game.bowl)[game.bi]}
function over(){return game.balls>=game.overs*6||game.wickets>=10||(game.target!==null&&game.runs>=game.target)}
function ensureLive(){if(game.finished)return false;if(over()){completeInnings();return false}return true}
function rotate(){if(players(game.bat).length>1)[game.si,game.ni]=[game.ni,game.si]}
function addRuns(n){if(!ensureLive())return;snap();playBatHit();let batter=currentBatter(),bowler=currentBowler();game.runs+=n;game.lastBall={text:`${bowler}: ${n} run${n===1?'':'s'}`,bowler,kind:n===4?'FOUR':n===6?'SIX':'Runs',runs:n};game.batStats[batter].runs+=n;if(n===4)game.batStats[batter].fours++;if(n===6)game.batStats[batter].sixes++;game.bowlStats[bowler].runs+=n;legalBall(n,true);noteOver(bowler,n,0,true);afterBall()}
function legalBall(teamRuns,face){let batter=currentBatter(),bowler=currentBowler();if(face)game.batStats[batter].balls++;game.bowlStats[bowler].balls++;game.balls++;if(teamRuns%2)rotate();if(game.balls%6===0){rotate();game.bi=(game.bi+1)%players(game.bowl).length}}
function noteOver(bowler, runs, wickets, legal){if(!game.currentOver)game.currentOver={bowler,runs:0,wickets:0,balls:0,deliveries:0};if(!game.currentOver.bowler)game.currentOver.bowler=bowler;game.currentOver.runs+=runs||0;game.currentOver.wickets+=wickets||0;game.currentOver.deliveries=(game.currentOver.deliveries||0)+1;if(legal)game.currentOver.balls++;if(game.currentOver.balls>=6){game.overLog=game.overLog||[];game.overLog.push({...game.currentOver});game.lastCompletedOverBowler=bowler;game.currentOver={bowler:null,runs:0,wickets:0,balls:0,deliveries:0}}}
function afterBall(){render();if(over())setTimeout(completeInnings,150)}
function extra(type){if(!ensureLive())return;let max=type==='wide'||type==='noball'?7:6;let opts=Array.from({length:max},(_,i)=>i+(type==='wide'||type==='noball'?1:0));let title=type==='noball'?'No-ball total':type==='wide'?'Wide total':type==='bye'?'Bye runs':'Leg-bye runs';openModal(`<h2>${title}</h2><p class="muted">${type==='wide'||type==='noball'?'Total team runs including the 1-run penalty.':'Runs taken as extras.'}</p><div class="buttons">${opts.map(n=>`<button data-call="recordExtra('${type}',${n})">${n}</button>`).join('')}</div><div class="modal-foot"><button data-call="closeModal()">Cancel</button></div>`)}
function recordExtra(type,total){closeModal();if(!ensureLive())return;snap();if(type==='noball'){playEffect('noball');announce('No-ball!')}else{playBatHit()}let bowler=currentBowler();let penalty=(type==='wide'||type==='noball')?1:0;game.lastBall={text:`${bowler}: ${type==='noball'?'No-ball':type==='wide'?'Wide':type==='bye'?'Bye':'Leg bye'} (${total} team run${total===1?'':'s'})`,bowler,kind:type,runs:total};game.runs+=total;game.extras+=total;if(type==='wide'||type==='noball'){game.bowlStats[bowler].runs+=total;game.bowlStats[bowler].runs+=0; if(type==='noball'){let batter=currentBatter();let batRuns=Math.max(0,total-penalty);game.batStats[batter].runs+=batRuns;if(batRuns===4)game.batStats[batter].fours++;if(batRuns===6)game.batStats[batter].sixes++;}if(total%2)rotate()}else{let batter=currentBatter();game.batStats[batter].balls++;game.bowlStats[bowler].balls++;game.balls++;if(total%2)rotate();if(game.balls%6===0){rotate();game.bi=(game.bi+1)%players(game.bowl).length}}noteOver(bowler,total,0,!(type==='wide'||type==='noball'));afterBall()}
function wicket(type){if(!ensureLive())return;let batter=currentBatter(),non=players(game.bat)[game.ni],bowler=currentBowler();if(!type){openModal(`<h2>Choose dismissal</h2><p>Select how the batter was dismissed.</p><div class="buttons" style="grid-template-columns:repeat(2,minmax(0,1fr))"><button data-call="wicket('runout')">Run out</button><button data-call="wicket('stumped')">Stumped</button><button data-call="wicket('caught')">Caught out</button><button data-call="wicket('bowled')">Bowled</button></div><div class="modal-foot"><button data-call="closeModal()">Cancel</button></div>`);return}
let battingPlayers=[batter,non].filter(Boolean);let fielders=players(game.bowl);let fields='';if(type==='runout'){fields=`<label>Which batter was run out?</label><select id="dismissedChoice">${battingPlayers.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')}</select><label>Run out by</label><select id="fielderSelect">${fielders.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')}</select>`}else if(type==='caught'){fields=`<p><b>Batter:</b> ${esc(batter)}</p><label>Caught by</label><select id="fielderSelect">${fielders.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')}</select>`}else if(type==='stumped'){fields=`<p><b>Batter:</b> ${esc(batter)}</p><label>Stumped by (wicketkeeper)</label><select id="fielderSelect"><option value="${esc(game.roles?.[game.bowl]?.keeper||fielders[0])}">${esc(game.roles?.[game.bowl]?.keeper||fielders[0])}</option>${fielders.filter(n=>n!==(game.roles?.[game.bowl]?.keeper||fielders[0])).map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')}</select>`}else{fields=`<p><b>${esc(batter)}</b> is bowled by <b>${esc(bowler)}</b>.</p><p class="muted">Bowled is automatically credited to the current bowler.</p>`}
openModal(`<h2>${({runout:'Run out',stumped:'Stumped',caught:'Caught out',bowled:'Bowled'})[type]}</h2>${fields}<div class="modal-foot"><button class="primary" data-call="confirmWicket('${type}')">Confirm wicket</button><button data-call="closeModal()">Cancel</button></div>`)}
function confirmWicket(type){if(!ensureLive())return;let fielder=$('fielderSelect')?.value||'', dismissed=$('dismissedChoice')?.value||currentBatter();closeModal();snap();playEffect('wicket');announce("That's a wicket! That's out!");let bowler=currentBowler();let batter=dismissed;let batIndex=players(game.bat).indexOf(batter);if(batIndex<0||game.batStats[batter]?.out)return;let labels={caught:`c ${fielder||'—'} b ${bowler}`,bowled:`b ${bowler}`,runout:`run out (${fielder||'—'})`,stumped:`st ${fielder||game.roles?.[game.bowl]?.keeper||'—'} b ${bowler}`};game.batStats[batter].out=true;game.batStats[batter].dismissal={type,text:labels[type],fielder:type==='stumped'?(fielder||game.roles?.[game.bowl]?.keeper||''):fielder,bowler};game.lastBall={text:`${bowler}: WICKET — ${batter} ${labels[type]}`,bowler,kind:'wicket',runs:0};game.batStats[batter].balls++;game.wickets++;if(type!=='runout')game.bowlStats[bowler].wickets++;game.bowlStats[bowler].balls++;game.balls++;if(batIndex===game.si){if(game.wickets<10){let available=players(game.bat).map((n,i)=>({n,i})).filter(x=>x.i!==game.si&&x.i!==game.ni&&!game.batStats[x.n].out&&x.i>=game.next);if(available.length){game.si=available[0].i;game.next=game.si+1}else if(game.wickets<10){game.wickets=10}}}else if(batIndex===game.ni){if(game.wickets<10){let available=players(game.bat).map((n,i)=>({n,i})).filter(x=>x.i!==game.si&&x.i!==game.ni&&!game.batStats[x.n].out&&x.i>=game.next);if(available.length){game.ni=available[0].i;game.next=game.ni+1}else if(game.wickets<10){game.wickets=10}}}if(game.balls%6===0){game.lastCompletedOverBowler=bowler;rotate();game.bi=(game.bi+1)%players(game.bowl).length}noteOver(bowler,0,type==='runout'?0:1,true);afterBall()}
function changeStrike(){if(!game)return;snap();rotate();render()}
function bowlerOptions(){return players(game.bowl).map(n=>`<option ${n===currentBowler()?'selected':''}>${esc(n)}</option>`).join('')}
function openBowlerPicker(){openModal(`<h2>Next bowler</h2><label>Bowler</label><select id="bowlerChoice">${bowlerOptions()}</select><div class="modal-foot"><button class="primary" data-call="applyBowlerChange()">Set next bowler</button><button data-call="closeModal()">Cancel</button></div>`)}
let pendingBowlerChoice=null;
function applyBowlerChange(){let n=$('bowlerChoice').value;closeModal();changeBowler(n)}
function openChangeBowler(){openModal(`<h2>Change bowler</h2><label>Bowler</label><select id="bowlerChoice">${bowlerOptions()}</select><div class="modal-foot"><button class="primary" data-call="applyRestrictedBowlerChange()">Change bowler</button><button data-call="closeModal()">Cancel</button></div>`)}
function applyRestrictedBowlerChange(){let n=$('bowlerChoice').value;closeModal();if(n===currentBowler())return;if((game.currentOver?.deliveries||0)===0){changeBowler(n);return}pendingBowlerChoice=n;openModal(`<h2>Bowler has delivered balls in this over</h2><p>The current bowler has already delivered balls in this over. What would you like to do?</p><div class="modal-foot"><button data-call="continueCurrentBowler()">Continue bowling</button><button class="danger" data-call="resetOverAndChangeBowler()">Reset over record</button></div>`)}
function continueCurrentBowler(){pendingBowlerChoice=null;closeModal()}
function resetOverAndChangeBowler(){let name=pendingBowlerChoice;pendingBowlerChoice=null;closeModal();if(!name)return;/* Reset the entire unfinished over, not just its display record. Restore the snapshot from before the first delivery so runs, wickets, legal balls, batter/bowler figures, extras, dismissal data, and last-ball details are removed everywhere. */let startIndex=-1;for(let i=undoStack.length-1;i>=0;i--){try{let prior=JSON.parse(undoStack[i]);if(prior.inn===game.inn&&(prior.currentOver?.deliveries||0)===0){startIndex=i;break}}catch(e){}}if(startIndex>=0){game=JSON.parse(undoStack[startIndex]);undoStack=undoStack.slice(0,startIndex)}else{alert('Could not safely find the start of this over. No changes were made.');return}let i=players(game.bowl).indexOf(name);if(i<0){render();return}let old=currentBowler();if(old!==name){game.bowlerChanges=game.bowlerChanges||[];game.bowlerChanges.push({from:old,to:name,balls:game.balls,overRecordReset:true})}game.bi=i;game.currentOver={bowler:name,runs:0,wickets:0,balls:0,deliveries:0};render()}
function changeBowlerWithoutSnapshot(name){let i=players(game.bowl).indexOf(name);if(i<0)return;let old=currentBowler();if(old!==name){game.bowlerChanges=game.bowlerChanges||[];game.bowlerChanges.push({from:old,to:name,balls:game.balls,overRecordReset:true})}game.bi=i}
function changeBowler(name){let i=players(game.bowl).indexOf(name);if(i>=0){snap();let old=currentBowler();if(old!==name){game.bowlerChanges=game.bowlerChanges||[];game.bowlerChanges.push({from:old,to:name,balls:game.balls})}game.bi=i;if(game.currentOver&&(game.currentOver.deliveries||0)===0)game.currentOver.bowler=name;render()}}
function openChangeBatter(){let batter=currentBatter(),stats=game.batStats[batter];if(stats.runs!==0||stats.balls!==0){alert('Change batter is only allowed when the current batter has 0 runs and 0 balls. Use Choose next batter for the next batter.');return}let eligible=players(game.bat).map((n,i)=>({n,i})).filter(x=>x.i!==game.si&&x.i!==game.ni&&!game.batStats[x.n].out&&game.batStats[x.n].runs===0&&game.batStats[x.n].balls===0);if(!eligible.length){alert('No unused batter with 0 runs and 0 balls is available to replace the current batter.');return}openModal(`<h2>Change batter</h2><p class="muted">Current batter: ${esc(batter)} · 0 runs · 0 balls</p><label>Replacement batter</label><select id="changeBatterChoice">${eligible.map(x=>`<option value="${x.i}">${esc(x.n)}</option>`).join('')}</select><div class="modal-foot"><button class="primary" data-call="setChangedBatter()">Change batter</button><button data-call="closeModal()">Cancel</button></div>`)}
function setChangedBatter(){let i=+$('changeBatterChoice').value;let name=players(game.bat)[i];if(!name||i===game.ni||game.batStats[currentBatter()].runs!==0||game.batStats[currentBatter()].balls!==0||game.batStats[name].out||game.batStats[name].runs!==0||game.batStats[name].balls!==0){alert('The batter can only be changed while the current batter and replacement have 0 runs and 0 balls.');return}snap();game.si=i;closeModal();render()}
function chooseBatter(){let eligible=players(game.bat).map((n,i)=>({n,i})).filter(x=>x.i!==game.si&&x.i!==game.ni&&!game.batStats[x.n].out&&x.i>=game.next);if(!eligible.length){alert('No eligible batters remain in this lineup.');return}openModal(`<h2>Choose next batter</h2><p class="muted">Batting team: ${esc(teamName(game.bat))}</p><label>Player</label><select id="nextChoice">${eligible.map(x=>`<option value="${x.i}">${esc(x.n)}</option>`).join('')}</select><div class="modal-foot"><button class="primary" data-call="setBatter()">Set next batter</button><button data-call="closeModal()">Cancel</button></div>`)}
function setBatter(){let i=+$('nextChoice').value;let next=Math.min(game.next,players(game.bat).length-1);[players(game.bat)[i],players(game.bat)[next]]=[players(game.bat)[next],players(game.bat)[i]];closeModal();render()}
function addPlayer(){openModal(`<h2>Add player to a team</h2><label>Team</label><select id="addTeam"><option value="${game.bat}">${esc(teamName(game.bat))} (batting)</option><option value="${game.bowl}">${esc(teamName(game.bowl))} (bowling)</option></select><label>Player name</label><input id="newPlayer" placeholder="Enter player name" maxlength="40"><div class="modal-foot"><button class="primary" data-call="savePlayer()">Add player</button><button data-call="closeModal()">Cancel</button></div><p class="muted">A new player joins the chosen team's lineup. To select someone already in the lineup, use Choose next batter.</p>`)}
function savePlayer(){let t=$('addTeam').value,n=$('newPlayer').value.trim();if(!n)return alert('Enter a player name.');if(players(t).includes(n))return alert('That player is already in this team.');players(t).push(n);if(t===game.bat)game.batStats[n]={runs:0,balls:0,fours:0,sixes:0,out:false};else game.bowlStats[n]={balls:0,runs:0,wickets:0};closeModal();render()}
function undo(){if(!undoStack.length)return alert('Nothing to undo.');game=JSON.parse(undoStack.pop());render()}
function endInnings(){if(confirm('End this innings now?'))completeInnings(true)}
function recordInnings(){let bat={},bowl={};players(game.bat).forEach(n=>bat[n]={...game.batStats[n]});players(game.bowl).forEach(n=>bowl[n]={...game.bowlStats[n]});return {innings:game.inn,battingTeam:teamName(game.bat),bowlingTeam:teamName(game.bowl),runs:game.runs,wickets:game.wickets,balls:game.balls,overs:oversText(game.balls),extras:game.extras,batters:bat,bowlers:bowl}}
function completeInnings(manual=false){if(!game||game.finished||game.completing)return;game.completing=true;let rec=recordInnings();if(!game.records.length||game.records[game.records.length-1].innings!==game.inn)game.records.push(rec);if(game.inn===1){game.target=game.runs+1;openModal(`<h2>Innings 1 complete</h2><div class="score"><div class="big">${game.runs}/${game.wickets}</div><div>${esc(rec.battingTeam)} · ${rec.overs} overs · Extras ${rec.extras}</div><div>Target: ${game.target}</div></div>${scorecardHTML(rec)}<button class="primary" data-call="startSecond()">Start second innings</button>`)}else{let first=game.records[0],second=rec;let result=second.runs>=game.target?`${second.battingTeam} won by ${10-second.wickets} wicket(s).`:second.runs===first.runs?'The match is tied.':`${first.battingTeam} won by ${first.runs-second.runs} run(s).`;game.finished=true;let entry={date:new Date().toISOString(),teamA:game.names.A,teamB:game.names.B,overs:game.overs,result,innings:game.records};let hist=historyList();hist.unshift(entry);saveHistoryList(hist);game.completing=false;showFinal(result,entry);return}game.completing=false}

function endMatch(){
 if(!game||game.finished)return;
 if(!confirm('End the match now and save the current result?'))return;
 const rec=recordInnings();
 if(!game.records.length||game.records[game.records.length-1].innings!==game.inn)game.records.push(rec);
 const first=game.records[0];
 let result;
 if(game.inn===2){
  const second=rec;
  result=second.runs>=game.target?`${second.battingTeam} won by ${10-second.wickets} wicket(s).`:second.runs===first.runs?'The match is tied.':`${first.battingTeam} won by ${first.runs-second.runs} run(s).`;
 }else{
  result=`Match ended early. ${rec.battingTeam}: ${rec.runs}/${rec.wickets} (${rec.overs} overs).`;
 }
 game.finished=true;
 const entry={date:new Date().toISOString(),teamA:game.names.A,teamB:game.names.B,overs:game.overs,result,innings:game.records};
 const hist=historyList();hist.unshift(entry);saveHistoryList(hist);showFinal(result,entry);
}

function startSecond(){closeModal();game.inn=2;[game.bat,game.bowl]=[game.bowl,game.bat];resetInnings();undoStack=[];render()}
function scorecardHTML(r){return `<h3>Batting · ${esc(r.battingTeam)}</h3><div style="overflow:auto"><table><tr><th>Batter</th><th>Status</th><th>R</th><th>B</th><th>4s</th><th>6s</th></tr>${Object.entries(r.batters).map(([n,s])=>`<tr><td>${esc(n)}</td><td>${s.out?'Out':'Not out'}</td><td>${s.runs}</td><td>${s.balls}</td><td>${s.fours}</td><td>${s.sixes}</td></tr>`).join('')}</table></div><h3>Bowling · ${esc(r.bowlingTeam)}</h3><div style="overflow:auto"><table><tr><th>Bowler</th><th>Overs</th><th>Runs</th><th>Wkts</th><th>Econ.</th></tr>${Object.entries(r.bowlers).map(([n,s])=>`<tr><td>${esc(n)}</td><td>${oversText(s.balls)}</td><td>${s.runs}</td><td>${s.wickets}</td><td>${s.balls?(s.runs/(s.balls/6)).toFixed(2):'0.00'}</td></tr>`).join('')}</table></div>`}
function showFinal(result,entry){$('match').classList.add('hidden');$('setup').classList.add('hidden');$('resultScreen').classList.remove('hidden');$('resultContent').innerHTML=`<h2>🏆 Final match result</h2><p style="font-size:19px;font-weight:800">${esc(result)}</p><p class="muted">Saved on this phone · ${new Date(entry.date).toLocaleString()}</p>${entry.innings.map(scorecardHTML).join('')}`}
function historyList(){try{return JSON.parse(window.localStorage.getItem('zainElevenResults')||'[]')}catch(e){return []}}
function saveHistoryList(items){try{window.localStorage.setItem('zainElevenResults',JSON.stringify(items));return true}catch(e){console.warn('Local history storage unavailable:',e);return false}}
function showMatchStatistics(){if(!game)return;const live=recordInnings();const first=game.records[0];let targetSummary='';if(game.inn===2&&game.target!==null){const need=Math.max(0,game.target-game.runs);const ballsLeft=Math.max(0,game.overs*6-game.balls);targetSummary=`<p><b>Target:</b> ${game.target} · <b>Need:</b> ${need} runs from ${ballsLeft} balls</p>`}openModal(`<h2>📊 Match statistics · Live</h2><div class="score"><div class="sub">${esc(live.battingTeam)} batting</div><div class="big">${game.runs}/${game.wickets}</div><div class="sub">${oversText(game.balls)} overs · Extras ${game.extras}</div></div>${targetSummary}<p class="muted">Current innings summary as of this ball. You can open this again anytime during the match.</p>${scorecardHTML(live)}${game.inn===2&&first?`<h3>First innings · ${esc(first.battingTeam)}</h3><p><b>${first.runs}/${first.wickets}</b> in ${first.overs} overs · Extras ${first.extras}</p>`:''}<div class="modal-foot"><button class="primary" data-call="closeModal()">Close</button></div>`)}
function showHistory(){let h=historyList();openModal(`<h2>Saved match history</h2><p class="muted">Choose one match to view its scorecard or delete only that match.</p>${h.length?h.map((m,i)=>`<div class="result-item"><strong>${esc(m.teamA)} vs ${esc(m.teamB)}</strong><p>${esc(m.result)}</p><p class="muted">${new Date(m.date).toLocaleString()} · ${m.overs} overs</p><div class="actions"><button data-call="viewHistoryItem(${i})">View scorecard</button><button class="danger" data-call="deleteHistoryItem(${i})">Delete this match</button></div></div>`).join(''):'<p class="muted">No completed matches saved yet.</p>'}<div class="modal-foot"><button data-call="closeModal()">Close</button></div>`)}
function viewHistoryItem(i){let m=historyList()[i];if(!m){showHistory();return}openModal(`<h2>${esc(m.teamA)} vs ${esc(m.teamB)}</h2><p><b>${esc(m.result)}</b></p>${m.innings.map(scorecardHTML).join('')}<div class="modal-foot"><button data-call="showHistory()">Back to history</button><button class="danger" data-call="deleteHistoryItem(${i})">Delete this match</button></div>`)}
function deleteHistoryItem(i){let h=historyList();if(!h[i]){showHistory();return}const m=h[i];if(confirm(`Delete only the saved match ${m.teamA} vs ${m.teamB}?`)){h.splice(i,1);saveHistoryList(h);renderHistoryPreview();showHistory()}}
function backToSetup(){if(confirm('Leave this match and return to setup? Current unfinished match will be discarded.')){game=null;$('match').classList.add('hidden');$('setup').classList.remove('hidden');renderHistoryPreview()}}
function newMatch(){game=null;$('resultScreen').classList.add('hidden');$('setup').classList.remove('hidden');renderHistoryPreview()}
function renderHistoryPreview(){let h=historyList();$('historyPreview').innerHTML=h.length?h.slice(0,3).map(m=>`<div class="result-item"><b>${esc(m.teamA)} vs ${esc(m.teamB)}</b><div>${esc(m.result)}</div><small class="muted">${new Date(m.date).toLocaleDateString()}</small></div>`).join(''):'No completed matches saved yet.'}
let liveTab='bat';
function showTeamScorecard(team){selectedScoreTeam=team;renderLiveScorecard()}
function renderLiveScorecard(){if(!game)return;const live=recordInnings();const innings=[...(game.records||[])];if(!innings.some(r=>r.innings===live.innings))innings.push(live);const battingInn=innings.find(r=>r.battingTeam===teamName(selectedScoreTeam));const bowlingInn=innings.find(r=>r.bowlingTeam===teamName(selectedScoreTeam));$('scoreTeamPickA').textContent=game.names.A;$('scoreTeamPickB').textContent=game.names.B;$('scoreTeamPickA').classList.toggle('selected',selectedScoreTeam==='A');$('scoreTeamPickB').classList.toggle('selected',selectedScoreTeam==='B');$('liveScoreSummary').textContent='Tap a team to view its full scorecard';const batTable=r=>r?`<div class="live-section-title">Batting · ${esc(r.battingTeam)} — ${r.runs}/${r.wickets} (${r.overs} overs)</div><div style="overflow:auto"><table><thead><tr><th>Batter</th><th>R</th><th>B</th><th>4s</th><th>6s</th><th>S/R</th></tr></thead><tbody>${Object.entries(r.batters).map(([n,s])=>`<tr><td class="player-name">${esc(n)}<div class="muted">${s.out?(s.dismissal?esc(s.dismissal.text):'Out'):'Not out'}</div></td><td>${s.runs}</td><td>${s.balls}</td><td>${s.fours}</td><td>${s.sixes}</td><td>${s.balls?(s.runs/s.balls*100).toFixed(2):'0.00'}</td></tr>`).join('')}</tbody></table></div><p class="muted">Extras: ${r.extras} · Team total: ${r.runs}/${r.wickets}</p>`:`<p class="muted">${esc(teamName(selectedScoreTeam))} has not batted yet.</p>`;const bowlTable=r=>r?`<div class="live-section-title">Bowling · ${esc(r.bowlingTeam)} (against ${esc(r.battingTeam)})</div><div style="overflow:auto"><table><thead><tr><th>Bowler</th><th>O</th><th>M</th><th>R</th><th>W</th><th>Econ</th></tr></thead><tbody>${Object.entries(r.bowlers).map(([n,s])=>`<tr><td class="player-name">${esc(n)}${r.innings===live.innings&&n===currentBowler()?' <b>● Current</b>':''}</td><td>${oversText(s.balls)}</td><td>${Math.floor(s.balls/6)}</td><td>${s.runs}</td><td>${s.wickets}</td><td>${s.balls?(s.runs/(s.balls/6)).toFixed(2):'0.00'}</td></tr>`).join('')}</tbody></table></div>`:`<p class="muted">Bowling figures will appear when the opposing team bats.</p>`;$('liveScorecardBody').innerHTML=`<h3>${esc(teamName(selectedScoreTeam))} — full team scorecard</h3>${batTable(battingInn)}${bowlTable(bowlingInn)}`}
function render(){if(!game)return;$('inningsTitle').textContent=`INNINGS ${game.inn} · ${teamName(game.bat)} batting`;$('score').textContent=`${game.runs}/${game.wickets}`;$('oversLine').textContent=`${oversText(game.balls)} / ${game.overs} overs`;$('extrasLine').textContent=`Extras ${game.extras}`;$('targetLine').textContent=game.target?'Target '+game.target:'';$('scoreTeamBat').textContent=teamName(game.bat);$('scoreTeamBowl').textContent=teamName(game.bowl);let previous=game.inn===2?game.records.find(r=>r.battingTeam===teamName(game.bowl)):null;$('bowlTeamScore').textContent=previous?`${previous.runs}/${previous.wickets}`:'—';$('bowlTeamOvers').textContent=previous?`${previous.overs} overs`:'Bowling team';$('batTeamLabel').textContent='BATTING · '+teamName(game.bat);$('bowlTeamLabel').textContent='BOWLING · '+teamName(game.bowl);let s=currentBatter(),n=players(game.bat)[game.ni],b=currentBowler(),ss=game.batStats[s],ns=n?game.batStats[n]:{runs:0,balls:0,fours:0,sixes:0},bs=game.bowlStats[b];$('striker').textContent='★ '+s+(game.roles?.[game.bat]?.captain===s?' (C)':'')+(game.roles?.[game.bat]?.viceCaptain===s?' (VC)':'')+(game.roles?.[game.bat]?.keeper===s?' (WK)':'');$('strikerStats').innerHTML=`${ss.runs} runs · ${ss.balls} balls<br>Fours: ${ss.fours}<br>Sixes: ${ss.sixes}`; $('nonStriker').textContent=(n||'No second batter')+(n&&game.roles?.[game.bat]?.captain===n?' (C)':'')+(n&&game.roles?.[game.bat]?.viceCaptain===n?' (VC)':'')+(n&&game.roles?.[game.bat]?.keeper===n?' (WK)':'');$('nonStrikerStats').innerHTML=`${ns.runs} runs · ${ns.balls} balls<br>Fours: ${ns.fours}<br>Sixes: ${ns.sixes}`;$('bowler').textContent='★ '+b;$('bowlerStats').textContent=`${oversText(bs.balls)} overs · ${bs.runs} runs · ${bs.wickets} wickets`;let changes=game.bowlerChanges||[];let lastChange=changes.length?changes[changes.length-1]:null;let prevName=(lastChange&&lastChange.to===b&&lastChange.from!==b)?lastChange.from:(game.lastCompletedOverBowler&&game.lastCompletedOverBowler!==b?game.lastCompletedOverBowler:null);let prevStats=prevName?game.bowlStats[prevName]:null;$('previousBowlerDetails').innerHTML=prevName&&prevStats?`<span class="previous-bowler-name">${esc(prevName)}</span>Runs: ${prevStats.runs} · Wickets: ${prevStats.wickets} · Overs: ${oversText(prevStats.balls)}`:'<span class="previous-bowler-name">No previous bowler yet</span>Runs: 0 · Wickets: 0 · Overs: 0.0';$('runButtons').innerHTML=[0,1,2,3,4,6].map(n=>`<button data-call="addRuns(${n})">${n}</button>`).join('');renderLiveScorecard();renderHistoryPreview()}
function openModal(html){$('modalBody').innerHTML=html;$('modal').showModal()}function closeModal(){$('modal').close()}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
loadPlayerNames();renderHistoryPreview();


// Delegated handlers: compatible with wrappers that block inline onclick/onchange attributes.
function parseCallArgs(raw, element) {
  if (!raw || !raw.trim()) return [];
  if (raw.trim() === 'this.value') return [element.value];
  const args=[]; let cur='', quote=null, depth=0;
  for (let i=0;i<raw.length;i++) {
    const c=raw[i];
    if (quote) { cur+=c; if(c===quote && raw[i-1] !== '\\') quote=null; continue; }
    if(c==='\'' || c==='"' || c==='`'){quote=c;cur+=c;continue;}
    if(c==='(' || c==='[' || c==='{') depth++;
    if(c===')' || c===']' || c==='}') depth--;
    if(c===',' && depth===0){args.push(cur.trim());cur='';} else cur+=c;
  }
  if(cur.trim()) args.push(cur.trim());
  return args.map(v=>{
    if(v==='this.value') return element.value;
    if((v[0]==='\'' && v[v.length-1]==='\'') || (v[0]==='"' && v[v.length-1]==='"')) return v.slice(1,-1).replace(/\\'/g,"'").replace(/\\\\/g,'\\');
    if(v!=='' && !Number.isNaN(Number(v))) return Number(v);
    return v;
  });
}
function runDelegatedCall(element, attr) {
  const call=element.getAttribute(attr); if(!call) return;
  const match=call.match(/^\s*([A-Za-z_$][\w$]*)\s*\((.*)\)\s*$/s);
  if(!match) return;
  const fn=window[match[1]];
  if(typeof fn!=='function'){console.error('Zain Eleven action not found:',match[1]);return;}
  try { fn(...parseCallArgs(match[2],element)); }
  catch(err){console.error('Zain Eleven action failed:',match[1],err);alert('Could not run '+match[1]+': '+(err && err.message ? err.message : String(err)));}
}
document.addEventListener('click', function(event){
  const button=event.target.closest('button');
  if(button){
    const action=button.getAttribute('data-call')||'';
    // Scoring buttons already play their cricket/bat sound in the action itself.
    if(!/^addRuns\(/.test(action)&&!/^recordExtra\(/.test(action)&&!/^confirmWicket\(/.test(action))playUiClick();
  }
  const el=event.target.closest('[data-call]'); if(!el) return;
  event.preventDefault(); runDelegatedCall(el,'data-call');
});
document.addEventListener('change', function(event){
  const el=event.target.closest('[data-change]'); if(!el) return;
  runDelegatedCall(el,'data-change');
});
