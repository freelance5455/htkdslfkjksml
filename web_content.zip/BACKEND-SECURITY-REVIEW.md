# Backend security review — action required

The v15 pass includes targeted live Supabase updates: the release-sent notification now uses generic release-processing wording, and direct RPC execution of that trigger-only helper is revoked. The previous pass also restricted `can_see_release(uuid)` execution to authenticated users. No broad RLS, authentication, or storage-policy changes were made. A targeted `release_events` INSERT policy now requires the actor to own, administer, or be a member of the band for the referenced release. Ten trigger-only `SECURITY DEFINER` helpers had direct execution revoked from `PUBLIC`, `anon`, and `authenticated`; trigger attachments remain in place.

A previous Supabase advisor review reported the following areas for careful follow-up:

- The latest advisor pass no longer reports anon-executable trigger helpers. Remaining callable `SECURITY DEFINER` functions are app RPCs needed by the current flows (band invite acceptance/creation, invite lookup, profile lookup/discovery, and RLS helper functions). Review their function bodies and `search_path` periodically; do not blanket-revoke them because policies or the frontend depend on them. The public `get_invite(p_code)` is intentionally available before sign-in and should return only the minimum invite fields.
- Multiple permissive RLS policies remain on `earnings`, `profiles`, `release_events`, `release_links`, `release_tracks`, and `releases`. A targeted INSERT policy now prevents activity events being attached to releases the actor cannot access. The remaining overlaps should be evaluated against the intended artist/band/label access model before consolidating them.
- Unused-index warnings were reported. Confirm real query patterns and table size before dropping indexes; low traffic or recently created indexes can appear unused.
- Storage buckets are intended to be private. Verify policies for `artwork`, `audio`, and `documents`, including signed URL lifetimes and whether paths are scoped to the correct user, release, or band.
- Keep the Supabase URL, project reference, and publishable/anon key in the browser if the static app needs them. These are public configuration, not secrets. Never ship a service-role key, database password, or secret API key to the browser.

## Suggested verification order

1. Export/backup the schema and review the current function definitions and grants.
2. Test each affected table as an artist, a band member, a label admin, and a signed-out visitor.
3. Test invite acceptance, profile creation, release submission/status changes, audio/artwork uploads, earnings visibility, and notification access.
4. Make narrowly scoped policy/grant changes in a staging project first.
5. Enable leaked-password protection in Supabase Auth settings when compatible with the intended signup experience.
5. Re-run Supabase Security and Performance advisors after changes.

The static ZIP does not execute database migrations when deployed. See `DATABASE.md` and `CHANGELOG.md` for the live changes made alongside v15.

## Resolved in v23: release status is now enforced by the database (2026-10-18)
Previously `releases` UPDATE/DELETE had no status condition, so a signed-in artist calling the API directly could set their own release to Approved or Live, edit it after submission, or delete a submitted or live release, and could insert a release already marked Live.
Applied (migration `20261018120000_harden_release_status_rules.sql`):
- BEFORE UPDATE trigger `guard_release_update`: non-admins can only edit while the release is Draft or Changes Requested, can only move it between Draft and Submitted, and cannot change `review_note` or `sent_at`. Label admins and direct SQL (no signed-in user) are unrestricted. The function is not executable by anon or authenticated.
- DELETE policy: label admins any release; artists only their own Drafts.
- INSERT policy: artists can only create Drafts.
Verified in a rolled-back transaction as a real artist and a real label account (13 checks: blocked Live insert, blocked Live/Approved updates, submit allowed, Submitted locked, Submitted delete blocked, label free to move status, edit and resubmit after Changes Requested, draft delete allowed, maintenance path unrestricted).
Still open: band members can see band releases but cannot edit them (unchanged, by design).
