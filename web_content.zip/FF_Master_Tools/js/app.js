// FF Master Tools - Main JS

// Splash
window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('splash').classList.add('hide');
    setTimeout(() => {
      document.getElementById('splash').style.display = 'none';
      document.getElementById('app').classList.remove('hidden');
    }, 600);
  }, 2800);
});

// Navigation
function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  window.scrollTo(0, 0);
}

// ========== SENSITIVITY LAB ==========
function generateSensitivity() {
  const ram = document.getElementById('ram').value;
  const hz = parseInt(document.getElementById('hz').value);
  const style = document.getElementById('style').value;

  // Base values (0-200 scale)
  let base = {
    '2-4':  { general: 192, reddot: 185, s2x: 172, s4x: 158, sniper: 105, freelook: 145, fire: 45, dpi: 440 },
    '6-8':  { general: 178, reddot: 168, s2x: 155, s4x: 143, sniper: 95,  freelook: 135, fire: 48, dpi: 420 },
    '12':   { general: 165, reddot: 155, s2x: 145, s4x: 135, sniper: 88,  freelook: 125, fire: 50, dpi: 400 }
  };

  let s = { ...base[ram] };

  // Refresh rate adjust
  if (hz === 60) {
    s.general += 5;
    s.reddot += 4;
  } else if (hz >= 120) {
    s.general -= 5;
    s.reddot -= 4;
    s.s2x -= 3;
  }

  // Play style
  if (style === 'rush') {
    s.general += 4;
    s.reddot += 3;
    s.freelook += 5;
  } else if (style === 'sniper') {
    s.s2x -= 3;
    s.s4x -= 4;
    s.sniper -= 5;
  }

  // Clamp
  Object.keys(s).forEach(k => {
    if (k !== 'fire' && k !== 'dpi') s[k] = Math.min(200, Math.max(50, s[k]));
  });

  // Show
  document.getElementById('s-general').textContent = s.general;
  document.getElementById('s-reddot').textContent = s.reddot;
  document.getElementById('s-2x').textContent = s.s2x;
  document.getElementById('s-4x').textContent = s.s4x;
  document.getElementById('s-sniper').textContent = s.sniper;
  document.getElementById('s-freelook').textContent = s.freelook;
  document.getElementById('s-fire').textContent = s.fire + '%';
  document.getElementById('s-dpi').textContent = s.dpi;

  document.getElementById('sensi-result').classList.remove('hidden');

  // Fake interstitial ad placeholder
  setTimeout(() => {
    // In real app: show AdMob interstitial here
  }, 400);
}

function copySensitivity() {
  const text = `FF Master Tools Sensitivity
General: ${document.getElementById('s-general').textContent}
Red Dot: ${document.getElementById('s-reddot').textContent}
2x Scope: ${document.getElementById('s-2x').textContent}
4x Scope: ${document.getElementById('s-4x').textContent}
Sniper: ${document.getElementById('s-sniper').textContent}
Free Look: ${document.getElementById('s-freelook').textContent}
Fire Button: ${document.getElementById('s-fire').textContent}
DPI: ${document.getElementById('s-dpi').textContent}`;

  navigator.clipboard.writeText(text).then(() => {
    alert('Sensitivity copied!');
  });
}

function saveProfile() {
  const profile = {
    general: document.getElementById('s-general').textContent,
    reddot: document.getElementById('s-reddot').textContent,
    s2x: document.getElementById('s-2x').textContent,
    s4x: document.getElementById('s-4x').textContent,
    sniper: document.getElementById('s-sniper').textContent,
    freelook: document.getElementById('s-freelook').textContent,
    fire: document.getElementById('s-fire').textContent,
    dpi: document.getElementById('s-dpi').textContent,
    time: new Date().toLocaleString()
  };

  let profiles = JSON.parse(localStorage.getItem('ff_profiles') || '[]');
  profiles.unshift(profile);
  if (profiles.length > 10) profiles = profiles.slice(0, 10);
  localStorage.setItem('ff_profiles', JSON.stringify(profiles));
  alert('Profile saved!');
  loadProfiles();
}

// ========== NAME FORGE ==========
let currentStyle = 'pro';

document.querySelectorAll('.style-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.style-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentStyle = btn.dataset.style;
  });
});

const nameStyles = {
  pro: [
    n => `꧁${n}꧂`,
    n => `『${n}』`,
    n => `【${n}】`,
    n => `•${n}•`,
    n => `⚡${n}⚡`,
    n => `†${n}†`,
    n => `✖${n}✖`,
    n => `⟡${n}⟡`
  ],
  aesthetic: [
    n => `♡${n}♡`,
    n => `✦${n}✦`,
    n => `✧${n}✧`,
    n => `⋆${n}⋆`,
    n => `✿${n}✿`,
    n => `❀${n}❀`,
    n => `ꨄ${n}ꨄ`,
    n => `♡︎${n}♡︎`
  ],
  toxic: [
    n => `☠${n}☠`,
    n => `✕${n}✕`,
    n => `‡${n}‡`,
    n => `☢${n}☢`,
    n => `◆${n}◆`,
    n => `✖︎${n}✖︎`,
    n => `††${n}††`,
    n => `🖤${n}🖤`
  ],
  clan: [
    n => `[${n}]`,
    n => `⟦${n}⟧`,
    n => `⟬${n}⟭`,
    n => `⌈${n}⌋`,
    n => `『${n}』CLAN`,
    n => `${n}ᴳᵃⁿᵍ`,
    n => `◈${n}◈`,
    n => `▣${n}▣`
  ]
};

function generateNames() {
  const input = document.getElementById('name-input').value.trim() || 'Player';
  const styles = nameStyles[currentStyle];
  const container = document.getElementById('name-results');
  container.innerHTML = '';

  styles.forEach(fn => {
    const name = fn(input);
    const div = document.createElement('div');
    div.className = 'name-item';
    div.innerHTML = `<span>${name}</span><button onclick="copyText('${name.replace(/'/g, "\\'")}')">Copy</button>`;
    container.appendChild(div);
  });
}

function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    alert('Copied: ' + text);
  });
}

// ========== REACTION TRAINER ==========
let reactionState = 'idle'; // idle | waiting | ready
let startTime = 0;
let timeoutId = null;

function reactionClick() {
  const box = document.getElementById('reaction-box');
  const text = document.getElementById('reaction-text');
  const result = document.getElementById('reaction-result');

  if (reactionState === 'idle') {
    reactionState = 'waiting';
    box.className = 'reaction-box';
    text.textContent = 'Wait for green...';
    result.textContent = '';
    const delay = 1500 + Math.random() * 3000;
    timeoutId = setTimeout(() => {
      reactionState = 'ready';
      startTime = performance.now();
      box.className = 'reaction-box go';
      text.textContent = 'TAP NOW!';
    }, delay);
  } else if (reactionState === 'waiting') {
    // Too early
    clearTimeout(timeoutId);
    reactionState = 'idle';
    box.className = 'reaction-box';
    text.textContent = 'Too early! Tap to retry';
    result.textContent = 'False start';
  } else if (reactionState === 'ready') {
    const time = Math.round(performance.now() - startTime);
    reactionState = 'idle';
    box.className = 'reaction-box ready';
    text.textContent = 'Tap to Start again';
    result.textContent = `Your reaction: ${time} ms`;
  }
}

// ========== PROFILES ==========
function loadProfiles() {
  const container = document.getElementById('saved-profiles');
  const profiles = JSON.parse(localStorage.getItem('ff_profiles') || '[]');

  if (profiles.length === 0) {
    container.innerHTML = '<p class="empty">No saved profiles yet.</p>';
    return;
  }

  container.innerHTML = '';
  profiles.forEach((p, i) => {
    const div = document.createElement('div');
    div.className = 'profile-item';
    div.innerHTML = `
      <h4>Profile ${i + 1}</h4>
      <p>General: ${p.general} | Red Dot: ${p.reddot} | 2x: ${p.s2x}</p>
      <p>4x: ${p.s4x} | Sniper: ${p.sniper} | Fire: ${p.fire}</p>
      <p style="font-size:11px;color:#666">${p.time}</p>
    `;
    container.appendChild(div);
  });
}

// Load profiles on start
loadProfiles();
