FF MASTER TOOLS
===============

This is a working Web App version of FF Master Tools.

HOW TO USE:
1. Open index.html in any modern browser (Chrome / Edge recommended)
2. Or host the folder on any web server

FEATURES:
- Splash screen with your logo
- Sensitivity Lab (working calculator based on RAM + Hz + Play Style)
- Name Forge (Pro / Aesthetic / Toxic / Clan styles)
- HUD Architect
- Meta Center
- Reaction Trainer
- My Profiles (saves in browser localStorage)
- Ad banner placeholders ready for AdMob

IMPORTANT:
- All text inside the app is in English (no Bangla)
- Logo used is the one you provided
- Ready to be converted into Android App using WebView or Flutter WebView

NEXT STEPS FOR PLAY STORE:
1. Convert this into Android App (Android Studio WebView or Flutter)
2. Add real Google AdMob IDs
3. Add Privacy Policy page
4. Generate signed APK / AAB

Created for BF MUSTAKIN LIVE
