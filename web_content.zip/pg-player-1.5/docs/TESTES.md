# Verificação da entrega

## Executado

| Verificação | Resultado | Limite da evidência |
| --- | --- | --- |
| JVM: QueueEngine e ListeningClock reais | 56 asserções passaram | Não executa o MediaPlayer Android, SQLite Android nem serviços. |
| Interface HTML/CSS/JS no Chromium | 35 verificações passaram | Adaptador demonstrativo e ponte nativa substituta. Não toca áudio real. |
| SQLite / contrato de código / manifesto | 21 verificações passaram | SQLite do Python e verificações estáticas, não instrumentação Android. |
| Parser javac | Sintaxe dos 14 arquivos Java aceita | Não resolve tipos, recursos R ou APIs Android. |
| `node --check` | JavaScript aceito | Sintaxe, complementada pelos testes de interface. |
| Build Android | Bloqueado | Android SDK ausente. APK 1.5 não produzido. |
| Instalação, assinatura nova e atualização | Não executadas | Dependem do build. |
| Aparelho físico / emulador | Não executado | Não havia alvo ADB. |

Os logs e capturas reais da interface estão em `evidencias/`. As capturas com músicas e estatísticas usam conteúdo fictício identificado. A captura `inicio-nativo-vazio-interface.png` testa a apresentação vazia com uma ponte substituta; **não é screenshot de Android**.

### Cobertura da lógica JVM

Fila explícita antes da continuação automática, FIFO, repetições deliberadas, arrastar para cima/baixo, entradas inválidas, limpeza de arquivo removido, modos de repetição, aleatório sem repetição imediata, esgotamento do conjunto aleatório, contexto copiado sem alterar a playlist. Contagem por avanço do áudio, buffering, pausa, retomada, âncora após seek, limites de relógio, limiar de escuta e intervalos com fim exclusivo.

### Cobertura da interface

Navegação e apresentação no celular; rótulo de prévia; criação de playlist e rejeição de nome vazio; conservação do rascunho; seleção de faixas e modo; reordenação; busca por faixa e artista; gesto horizontal; reprodutor ampliado; fila por alça; independência da playlist; fechamento de modal; períodos; intervalo inclusivo; seleção de dia; PNG de Stories e quadrado; opção de ocultar artistas; separação de vídeos; cores; ausência de dados fictícios no modo de ponte nativa; envio de ação de importação.

## Reproduzir os testes disponíveis

```bash
./tests/run-core.sh
node --check app/src/main/assets/ui/app.js
python3 tests/storage_contract_tests.py
# Requer pacote Python playwright e Chromium instalado:
python3 tests/ui_tests.py
```

Para o teste de sintaxe Java:

```bash
mkdir -p build/syntax
javac -d build/syntax tests/JavaSyntaxCheck.java
java -cp build/syntax JavaSyntaxCheck app/src/main/java
```

O teste de interface aceita `CHROMIUM_PATH`. Neste ambiente a navegação a URLs foi bloqueada, então a mesma interface foi carregada como conteúdo local em memória por `page.set_content`, sem acessar serviços externos. Isso não altera a política de conteúdo do aplicativo. No modo prévia, gravação em `localStorage` depende do navegador; os testes não a confundem com persistência nativa Android.

## Roteiro de aceitação Android — pendente

1. **Build e instalação:** resolver quaisquer erros de javac/D8/AAPT2, verificar certificado, instalar em Android e abrir sem crash. Repetir a atualização `-r` sobre 1.1 com acervo de teste e confirmar leitura dos dados antigos.
2. **Áudio local:** importar MP3 e outros formatos suportados, negar/cancelar seleção, arquivos ausentes, ZIP/RAR válidos e corrompidos; conferir capas, metadados e duplicatas por URI. Há deduplicação por referência de arquivo, não identificação acústica de cópias em pastas distintas.
3. **Segundo plano:** tela apagada, sair do aplicativo, notificação, próxima/anterior, fones Bluetooth, remoção dos fones, interrupção por outro áudio/chamada, retomada e limites de bateria do fabricante. Medir consumo; não declarar autonomia garantida sem medição.
4. **Playlists e fila:** criar, escolher capa, reordenar, duplicar presença de faixa entre playlists, enfileirar por gesto, limpar fila, fechar/reabrir sem autoplay; confirmar persistência de posição/contexto e remoção sem apagar a playlist.
5. **Cápsula:** medir com cronômetro 10 s, 31 s e uma faixa completa; pausar 60 s, saltar 90 s e comparar totais. Repetir a faixa e verificar eventos separados. Testar passagem de meia-noite e de mês, alteração de fuso/relógio, interrupção forçada e banco cheio.
6. **Backup:** exportar para provedor de documentos; restaurar em ambiente descartável; restaurar duas vezes; restaurar snapshot mais recente; arquivo incompleto/inválido; perda de permissões e arquivos com URIs diferentes. A restauração não constitui backup dos arquivos de mídia.
7. **Vídeos:** MP4 suportado e não suportado, rotação, voltar ao player, foco de áudio. Confirmar que os minutos de vídeo não entram na Cápsula.
8. **Compartilhamento:** datas longas, nomes/artistas longos, período sem escutas, ambas as dimensões de PNG, seletor Android e abertura do URI em aplicativo receptor.

Grandes bibliotecas (por exemplo 10 mil arquivos) e vários anos de histórico ainda precisam de testes de desempenho em aparelho. Não há benchmark Android nesta entrega.
