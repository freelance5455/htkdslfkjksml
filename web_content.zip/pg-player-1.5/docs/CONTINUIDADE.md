# Continuidade — PG Player 1.5

## Decisões preservadas

Versão 1.5. Música fornecida pelo próprio usuário. Playlists manuais. Fila por gesto e persistente. Cápsula com todos os inícios e tempo real, períodos selecionáveis e imagem compartilhável. Estatísticas avançadas. Interface profundamente refeita. Vídeos simples em outra área e sem contabilização musical. Não reinterpretar a conversa como aprovação de recomendações automáticas, modo DJ, letras ou equalizador novo.

## Arquitetura implementada

`PlaybackService` conserva MediaPlayer, MediaSession, audio focus, reprodução em serviço foreground e a importação original. `QueueEngine` controla o contexto automático e a fila explícita separadamente. `ListeningClock` recebe posições do áudio e relógio monotônico.

`HistoryStore` usa SQLite com tabelas `plays` e `segments`. Os segmentos são divididos por hora para filtrar períodos e dias. Escritas e consultas são serializadas em executor dedicado, evitando aguardar uma consulta histórica longa na thread que recebe controles do player. O início recebe um UUID; segmentos possuem seus próprios UUIDs para restauração idempotente. Snapshot com duração registrada maior pode atualizar um registro já existente.

`MediaLibrary` conserva playlists e vídeos em preferências locais. `MetadataReader` lê arquivos selecionados e gera miniaturas locais. Em API 26, não tenta chamar a API de miniatura escalada introduzida depois; vídeos sem capa podem usar ícone neutro.

`MainActivity` é uma apresentação WebView carregada exclusivamente do conteúdo local interceptado em `https://pg.local`. Essa URL é uma origem interna do app, não um site publicado. A ponte `PGNative.send` aceita ações da interface local. O aplicativo não declara permissão de internet, bloqueia navegação externa e não concede ao WebView acesso genérico a arquivos/content URIs.

`ShareProvider` concede acesso de leitura apenas ao PNG escolhido para compartilhamento. `VideoActivity` é deliberadamente simples, sem `HistoryStore`.

## Próximo passo técnico indispensável

Executar `build.py` em um ambiente com SDK36 + Build-Tools36.0.0 e JDK17/21. Corrigir eventuais erros de tipos/API encontrados e guardar o log. Depois instalar em alvo Android autorizado e seguir `TESTES.md`. Não declarar o aplicativo pronto para uso real só porque a prévia abre ou os testes JVM passaram.

O ambiente desta entrega não possuía o SDK; tentativas de download falharam. Nenhum repositório externo foi alterado e nenhuma chave foi publicada por esta tarefa.

## Limitações importantes

O HTML independente é somente prévia. O áudio real está no código Android. As estatísticas não importam escutas de outros players nem reconstruem uso anterior à implementação. Backups não contêm mídias/capas/fila; permissões precisam ser conferidas em outro aparelho. Eventos podem perder os últimos segundos em encerramento abrupto. A identificação de duplicatas é por URI, não hash do conteúdo de cada áudio. Suporte a codec depende do aparelho. A versão mínima declarada não dispensa um WebView que entenda os recursos JavaScript/CSS utilizados. Migração, codecs, background e desempenho ainda não foram validados em Android.

## Chave original

O arquivo privado de assinatura original foi preservado no pacote particular para permitir continuidade. Não criar uma nova chave com o mesmo nome e dizer que é a assinatura anterior. Não publicar a chave ou o ZIP privado em repositório público. `build.py` falha quando a chave esperada não existe.
