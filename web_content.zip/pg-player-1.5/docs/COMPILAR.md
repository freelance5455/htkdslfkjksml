# Compilação local do PG Player 1.5

## Estado desta entrega

O código está preparado para compilação, mas o **build Android ainda não foi executado com sucesso**. O erro observado neste ambiente está em `evidencias/tentativa-build.txt`. Eventuais erros de tipos/API ou integração deverão ser corrigidos no primeiro build; os testes de sintaxe não os excluem.

## Requisitos

Use Python 3.9 ou superior, JDK 17 ou 21 e Android SDK contendo `platforms/android-36/android.jar` e `build-tools/36.0.0`. O JDK precisa incluir `javac`, não apenas a máquina virtual `java`. O build usa os JARs já incluídos em `libs/`; não baixa músicas, bibliotecas ou ferramentas durante a execução.

No Android Studio, abra **SDK Manager**. Em SDK Platforms, instale Android API 36. Em SDK Tools, habilite a visualização de detalhes e instale Android SDK Build-Tools 36.0.0. Revise os termos do SDK antes de aceitar. Não é necessário criar um projeto Compose ou adicionar dependências Gradle.

Alternativamente, com `sdkmanager` já configurado e as licenças aceitas pelo proprietário do ambiente:

```text
sdkmanager "platforms;android-36" "build-tools;36.0.0"
```

## Windows

Extraia o projeto inteiro, incluindo `libs`, `app` e a chave privada. Instale Python 3 e o JDK. O script procura o SDK em `%LOCALAPPDATA%\Android\Sdk` e o JDK em `JAVA_HOME`, no `jbr` da instalação padrão do Android Studio ou no `PATH`.

Execute `build.cmd`. Para usar caminhos diferentes, no PowerShell:

```powershell
$env:ANDROID_SDK_ROOT = "$env:LOCALAPPDATA\Android\Sdk"
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
py -3 build.py
```

O caminho de `JAVA_HOME` acima é um exemplo para a instalação padrão; ajuste somente se a instalação estiver em outro local.

## Linux / macOS

```bash
export ANDROID_SDK_ROOT="$HOME/Android/Sdk"  # Linux; ajuste se necessário
# macOS costuma usar: "$HOME/Library/Android/sdk"
./build.sh
```

Variáveis opcionais: `PG_ANDROID_JAR`, `PG_ANDROID_BUILD_TOOLS`, `PG_SIGNING_KEYSTORE`, `PG_SIGNING_ALIAS`, `PG_SIGNING_PASSWORD`.

## Assinatura e atualização

O padrão utiliza a chave original em `signing/pg-player.jks`, alias `pgplayer`. A senha local original acompanha a configuração herdada no build. A chave deve permanecer privada. O script **não cria outra chave quando a original estiver ausente**, pois uma nova assinatura não seria equivalente à atualização do aplicativo existente.

A compilação executa AAPT2, javac, D8, zipalign e apksigner; inclui explicitamente `assets/ui`; verifica a assinatura, o alinhamento e a presença dos arquivos fundamentais; gera o SHA-256 do APK. Somente depois dessas etapas a mensagem de sucesso é emitida.

Saída esperada:

```text
dist/PG-Player-1.5.apk
dist/PG-Player-1.5.apk.sha256
```

Esse caminho é uma saída **futura do build**, não uma afirmação de que o APK está presente no ZIP recebido.

## Teste Android necessário

Com um aparelho de testes autorizado, depuração USB e `adb` configurados:

```bash
adb devices
adb install -r dist/PG-Player-1.5.apk
adb shell am start -n br.com.adno.pgplayer/.MainActivity
adb logcat -b crash -d
```

Não rode `adb uninstall` como parte de uma atualização. Erro de assinatura, pacote ou versão deve ser investigado sem apagar o app antigo.

O roteiro detalhado está em `TESTES.md`: primeiro uma instalação limpa e depois uma atualização sobre 1.1 com cópia segura dos arquivos. Não use os únicos dados importantes do usuário como ambiente descartável de testes.
