# Dados locais e privacidade

A implementação não contém login, anúncios, telemetria, pesquisa de músicas na internet ou integração com Spotify. Não declara permissão de internet nem de microfone. A ponte visual local não deve carregar páginas externas.

O histórico musical contém título, artista, álbum, referência do arquivo, horário de início/fim e tempo ouvido. Ele permanece no banco privado do aplicativo e não possui expiração automática. Isso não significa que seja impossível perder dados: desinstalar, limpar os dados do app, perder o aparelho ou falha de armazenamento pode removê-los. A opção de backup explícito foi implementada para reduzir esse risco.

Compartilhar uma Cápsula envia somente o PNG produzido e um texto de acompanhamento para o aplicativo escolhido pelo usuário. As imagens de compartilhamento ficam temporariamente no cache; imagens desse cache com mais de sete dias podem ser limpas em compartilhamentos posteriores. Essa limpeza não apaga o histórico musical.

O backup exportado é JSON **não criptografado**. Pode revelar preferências musicais e horários; guarde-o em local confiável. Ele inclui referências de arquivos, não os áudios, vídeos nem imagens de capa. A restauração é de mesclagem, sem apagar todo o histórico anterior, mas playlists com o mesmo identificador são atualizadas pelo snapshot importado.

Remover da biblioteca uma música importada de ZIP/RAR pode apagar a cópia interna extraída pelo PG Player. O arquivo original selecionado no armazenamento ou o arquivo ZIP/RAR de origem não é apagado. O diário histórico permanece.

A prévia HTML traz músicas e números fictícios identificados e não constitui dado pessoal real do usuário. Dados de demonstração são desativados quando a ponte Android está presente. Os testes de interface verificam essa separação, mas não substituem um teste do APK final.
