#!/usr/bin/env python3
"""Build local do PG Player 1.5. Não baixa ferramentas nem altera o SDK instalado.
Requisitos: Python 3.9+, JDK 17 ou 21, Android SDK Platform 36, Build-Tools 36.0.0.
"""
from __future__ import annotations
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'build' / 'android'
DIST = ROOT / 'dist'
IS_WIN = os.name == 'nt'
DEPS = [ROOT / 'libs' / name for name in (
    'junrar-8.1.1.jar', 'slf4j-api-2.0.17.jar', 'slf4j-nop-2.0.17.jar')]

def fail(message: str) -> None:
    raise RuntimeError(message)

def find_sdk() -> Path:
    options = [os.environ.get('ANDROID_SDK_ROOT'), os.environ.get('ANDROID_HOME')]
    if IS_WIN:
        options += [str(Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Android' / 'Sdk')]
    elif sys.platform == 'darwin':
        options += [str(Path.home() / 'Library' / 'Android' / 'sdk')]
    else:
        options += [str(Path.home() / 'Android' / 'Sdk'), '/opt/android-sdk']
    for option in options:
        if option and Path(option).is_dir():
            return Path(option)
    fail('Android SDK não encontrado. Instale Platform 36 e Build-Tools 36.0.0 pelo SDK Manager e defina ANDROID_SDK_ROOT. Nenhum APK foi gerado.')

def java_tool(name: str) -> str:
    suffix = '.exe' if IS_WIN else ''
    homes = [os.environ.get('JAVA_HOME')]
    if IS_WIN:
        homes += [str(Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'Android' / 'Android Studio' / 'jbr')]
    for home in homes:
        if home:
            tool = Path(home) / 'bin' / (name + suffix)
            if tool.is_file():
                return str(tool)
    found = shutil.which(name)
    if found:
        return found
    fail(f'{name} não encontrado. Instale um JDK 17/21 ou defina JAVA_HOME para o jbr do Android Studio.')

def android_tool(folder: Path, name: str) -> str:
    suffix = '.bat' if IS_WIN and name in ('d8', 'apksigner') else '.exe' if IS_WIN else ''
    tool = folder / (name + suffix)
    if not tool.is_file():
        fail(f'Ferramenta ausente: {tool}. Instale Android Build-Tools 36.0.0.')
    return str(tool)

def run(*args: object) -> None:
    command = [str(x) for x in args]
    # Passwords are supplied through environment variables, not echoed to logs.
    print('+ ' + ' '.join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)

def main() -> None:
    sdk = find_sdk()
    android_jar = Path(os.environ.get('PG_ANDROID_JAR', str(sdk / 'platforms' / 'android-36' / 'android.jar')))
    tools = Path(os.environ.get('PG_ANDROID_BUILD_TOOLS', str(sdk / 'build-tools' / '36.0.0')))
    if not android_jar.is_file():
        fail(f'Platform 36 não encontrada: {android_jar}')
    javac = java_tool('javac')
    aapt2, d8, align, signer = [android_tool(tools, n) for n in ('aapt2', 'd8', 'zipalign', 'apksigner')]
    key = Path(os.environ.get('PG_SIGNING_KEYSTORE', str(ROOT / 'signing' / 'pg-player.jks')))
    if not key.is_file():
        fail('Chave original ausente. Restaure signing/pg-player.jks do seu projeto 1.1. Não será criada outra chave silenciosamente.')
    for dep in DEPS:
        if not dep.is_file():
            fail(f'Dependência ausente: {dep.name}')
    OUT.mkdir(parents=True, exist_ok=True)
    DIST.mkdir(exist_ok=True)
    for name in ('classes', 'generated', 'dex'):
        path = OUT / name
        if path.exists():
            shutil.rmtree(path)
        path.mkdir()
    for name in ('resources.zip', 'base.apk', 'unsigned.apk', 'aligned.apk', 'classes.jar'):
        (OUT / name).unlink(missing_ok=True)
    run(aapt2, 'compile', '--dir', ROOT/'app/src/main/res', '-o', OUT/'resources.zip')
    run(aapt2, 'link', '-o', OUT/'base.apk', '-I', android_jar,
        '--manifest', ROOT/'app/src/main/AndroidManifest.xml', '--java', OUT/'generated',
        '--auto-add-overlay', '-A', ROOT/'app/src/main/assets', OUT/'resources.zip')
    sources = sorted((ROOT/'app/src/main/java').rglob('*.java')) + sorted((OUT/'generated').rglob('*.java'))
    # javac argument file handles spaces in paths, with a slash form also accepted on Windows.
    argfile = OUT/'sources.txt'
    argfile.write_text('\n'.join('"'+p.as_posix()+'"' for p in sources), encoding='utf-8')
    classpath = os.pathsep.join(str(p) for p in [android_jar] + DEPS)
    run(javac, '-source', '8', '-target', '8', '-encoding', 'UTF-8', '-proc:none',
        '-classpath', classpath, '-d', OUT/'classes', '@'+str(argfile))
    with zipfile.ZipFile(OUT/'classes.jar', 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in sorted((OUT/'classes').rglob('*.class')):
            archive.write(file, file.relative_to(OUT/'classes').as_posix())
    run(d8, '--lib', android_jar, '--min-api', '26', '--output', OUT/'dex', OUT/'classes.jar', *DEPS)
    shutil.copyfile(OUT/'base.apk', OUT/'unsigned.apk')
    with zipfile.ZipFile(OUT/'unsigned.apk', 'a', zipfile.ZIP_DEFLATED) as archive:
        for file in sorted((OUT/'dex').glob('*.dex')):
            archive.write(file, file.name)
        for name in ('JUNRAR-LICENSE.txt', 'SLF4J-LICENSE.txt'):
            archive.write(ROOT/'libs'/name, 'assets/licenses/'+name)
        for dep in DEPS[1:]:
            with zipfile.ZipFile(dep) as dependency:
                for name in dependency.namelist():
                    if name.startswith('META-INF/services/') and not name.endswith('/'):
                        archive.writestr(name, dependency.read(name))
    run(align, '-f', '-p', '4', OUT/'unsigned.apk', OUT/'aligned.apk')
    os.environ.setdefault('PG_SIGNING_PASSWORD', 'pgplayer-local-build')
    apk = DIST/'PG-Player-1.5.apk'
    run(signer, 'sign', '--ks', key, '--ks-key-alias', os.environ.get('PG_SIGNING_ALIAS', 'pgplayer'),
        '--ks-pass', 'env:PG_SIGNING_PASSWORD', '--key-pass', 'env:PG_SIGNING_PASSWORD',
        '--out', apk, OUT/'aligned.apk')
    run(signer, 'verify', '--verbose', '--print-certs', apk)
    run(align, '-c', '-p', '4', apk)
    with zipfile.ZipFile(apk) as archive:
        for required in ('classes.dex', 'AndroidManifest.xml', 'assets/ui/index.html', 'assets/ui/app.js', 'assets/ui/style.css'):
            if required not in archive.namelist():
                fail(f'APK incompleto: falta {required}')
    sha = hashlib.sha256(apk.read_bytes()).hexdigest()
    (DIST/'PG-Player-1.5.apk.sha256').write_text(sha+'  '+apk.name+'\n', encoding='ascii')
    print(f'\nAPK compilado e assinatura verificada: {apk}\nAinda requer teste em Android real/emulador.')

if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.CalledProcessError) as error:
        print(f'\nERRO: {error}', file=sys.stderr)
        sys.exit(1)
