@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 build.py
) else (
  python build.py
)
set "result=%errorlevel%"
echo.
if not "%result%"=="0" echo Leia a mensagem acima e docs\COMPILAR.md. Nenhum APK novo foi confirmado.
pause
exit /b %result%
