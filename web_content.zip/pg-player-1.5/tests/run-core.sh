#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/build/core-tests"
mkdir -p "$OUT"
javac -encoding UTF-8 -d "$OUT" "$ROOT/app/src/main/java/br/com/adno/pgplayer/QueueEngine.java" "$ROOT/app/src/main/java/br/com/adno/pgplayer/ListeningClock.java" "$ROOT/tests/CoreTests.java"
java -cp "$OUT" br.com.adno.pgplayer.CoreTests
