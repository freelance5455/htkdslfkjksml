"""SQLite schema/query contract checks. Python SQLite, not Android instrumentation."""
import json, pathlib, re, sqlite3, xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parents[1]
source=(ROOT/'app/src/main/java/br/com/adno/pgplayer/HistoryStore.java').read_text()
checks=[]
def check(condition,name):
    assert condition,name
    checks.append(name)
db=sqlite3.connect(':memory:')
statements=re.findall(r'db\.execSQL\("(CREATE [^"]+)"\)',source)
for sql in statements: db.execute(sql)
check(len(statements)==5,'production SQL schema creates tables and indexes')
# A play crossing midnight, one short start, one zero-second attempt.
for row in [('p1','u1','Music A','Artist A','Album',1000,11000,180000,10000,11000,'concluída'),('p2','u2','Music B','Artist B','Album',30000,31000,180000,1000,31000,'trocada'),('p3','u3','Music C','Artist C','Album',40000,40000,180000,0,40000,'trocada')]:
    db.execute('INSERT INTO plays VALUES (?,?,?,?,?,?,?,?,?,?,?)',row)
for row in [('s1','p1',1000,6000,5000),('s2','p1',6000,11000,5000),('s3','p2',30000,31000,1000)]:
    db.execute('INSERT INTO segments VALUES (?,?,?,?,?)',row)
queries=re.findall(r'db\.rawQuery\("(SELECT s\.play_id[^"]+)"',source)
check(len(queries)==1,'statistics uses production overlap query')
query=queries[0]
rows=db.execute(query,(6000,0)).fetchall()
check(len(rows)==1 and rows[0][0]=='p1','range end is exclusive')
rows2=db.execute(query,(12000,6000)).fetchall()
check(len(rows2)==1 and rows2[0][1]==6000,'adjacent period does not double count prior segment')
rows=db.execute(query,(50000,0)).fetchall()
check(sum(r[3] for r in rows)==11000,'aggregate comes from actual recorded milliseconds')
starts=db.execute('SELECT id FROM plays WHERE started>=? AND started<?',(0,50000)).fetchall()
check(len(starts)==3,'zero-duration attempt remains in reproduction history')
check(db.execute('SELECT COUNT(DISTINCT play_id) FROM segments').fetchone()[0]==2,'one playback spanning segments not multiple plays')
# Simulate additive backup duplicate behavior on the same production primary keys.
original=db.execute('SELECT COUNT(*) FROM plays').fetchone()[0]
db.execute("INSERT OR IGNORE INTO plays SELECT * FROM plays WHERE id='p1'")
check(db.execute('SELECT COUNT(*) FROM plays').fetchone()[0]==original,'primary key permits idempotent backup restoration')
# Index selection checked at the engine, not just presence in source.
plan=db.execute('EXPLAIN QUERY PLAN SELECT * FROM segments WHERE play_id=? AND start_ms>=?',('p1',0)).fetchall()
check(any('segment_play' in p[-1] for p in plan),'play-specific query uses segment index')
manifest=ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
a='{http://schemas.android.com/apk/res/android}'
check(manifest.attrib['package']=='br.com.adno.pgplayer','application identifier preserved')
check(manifest.attrib[a+'versionName']=='1.5' and manifest.attrib[a+'versionCode']=='15','version 1.5 declared')
permissions={p.attrib[a+'name'] for p in manifest.findall('uses-permission')}
check('android.permission.INTERNET' not in permissions,'no Internet permission')
check('android.permission.RECORD_AUDIO' not in permissions,'no microphone permission')
application=manifest.find('application')
check(application.attrib[a+'allowBackup']=='false','automatic OS backup disabled; explicit export only')
services={s.attrib[a+'name']:s.attrib for s in application.findall('service')}
check(services['.PlaybackService'][a+'foregroundServiceType']=='mediaPlayback','native foreground playback service declared')
check(all(s[a+'exported']=='false' for s in services.values()),'services not externally exported')
video=(ROOT/'app/src/main/java/br/com/adno/pgplayer/VideoActivity.java').read_text()
check('HistoryStore.get(' not in video,'video playback not wired into musical history')
player=(ROOT/'app/src/main/java/br/com/adno/pgplayer/PlaybackService.java').read_text()
check('"queue15"' in player and '"context15"' in player and '"cursor15"' in player,'queue persistence fields in native implementation')
check('getSharedPreferences("player"' in player and '"tracks"' in player,'legacy preferences names preserved')
check('Executors.newSingleThreadExecutor()' in source,'history IO serialized outside UI thread')
check('insertOrThrow' in source and 'incoming>previous' in source,'restore validates inserts and accepts more complete snapshots')
result={'passed':len(checks),'checks':checks,'scope':'Production SQL schema/query exercised with Python SQLite and static source/manifest contracts. Android DB integration NOT executed.'}
(ROOT/'docs/evidencias/testes-contratos.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print('PASS:',len(checks),'storage and source contract checks; not Android instrumentation.')
