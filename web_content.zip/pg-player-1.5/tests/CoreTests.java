package br.com.adno.pgplayer;

import java.util.*;
/** Plain JVM tests of the actual production queue/clock classes, not copies. */
public final class CoreTests {
    private static int assertions;
    private static void eq(Object expected,Object actual,String name){
        assertions++;if(!Objects.equals(expected,actual))throw new AssertionError(name+": expected="+expected+", actual="+actual);
    }
    private static QueueEngine queue(){QueueEngine q=new QueueEngine(new Random(42));q.setContext(Arrays.asList("a","b","c"),"a");return q;}
    public static void main(String[] args){
        QueueEngine q=queue();
        eq("b",q.next(true,"a"),"sequential next");
        eq("c",q.next(true,"b"),"sequential end");
        eq("a",q.next(true,"c"),"repeat context");
        q.repeat=0;q.cursor=2;eq(null,q.next(true,"c"),"automatic stop at end");
        eq("a",q.next(false,"c"),"manual next wraps");
        q=queue();q.enqueue("x");q.enqueue("y");
        eq("x",q.next(true,"a"),"explicit queue before context");
        eq(0,q.cursor,"queued item does not move context cursor");
        eq("y",q.next(true,"x"),"FIFO queue");
        eq("b",q.next(true,"y"),"resume context after explicit queue");
        eq(Arrays.asList("a","b","c"),q.context,"playlist unchanged");
        q=queue();q.repeat=2;eq("a",q.next(true,"a"),"repeat one automatic");
        eq("b",q.next(false,"a"),"manual skip ignores repeat one");
        q.enqueue("x");eq("x",q.next(true,"b"),"explicit choice overrides repeat one");
        q=queue();q.enqueue("a");q.enqueue("a");eq(2,q.pending.size(),"allow deliberate queue repetitions");
        eq("a",q.next(true,"a"),"first repeat queued");eq("a",q.next(true,"a"),"second repeat queued");
        q.enqueue(null);q.enqueue("");eq(0,q.pending.size(),"reject blank queue entries");
        q.enqueue("x");q.enqueue("y");q.enqueue("z");q.move(0,2);
        eq(Arrays.asList("y","z","x"),q.pending,"drag down");q.move(2,0);
        eq(Arrays.asList("x","y","z"),q.pending,"drag up");
        q.move(-1,1);q.move(2,9);eq(Arrays.asList("x","y","z"),q.pending,"ignore invalid reorder");
        q=queue();q.cursor=2;q.enqueue("b");q.enqueue("b");q.remove("b");
        eq(Arrays.asList("a","c"),q.context,"removed file cleaned from context");
        eq(Collections.emptyList(),q.pending,"removed file cleaned from all pending occurrences");
        eq(1,q.cursor,"cursor adjusted after removal");eq("a",q.previous(),"previous context");
        q=new QueueEngine();eq(null,q.next(true,null),"empty context next");eq(null,q.previous(),"empty context previous");
        q=queue();q.shuffle=true;q.repeat=0;String first=q.next(true,"a"),second=q.next(true,first);
        eq(true,!first.equals("a"),"shuffle does not immediately repeat");
        eq(true,!second.equals(first)&&!second.equals("a"),"shuffle bag no repeats");
        eq(null,q.next(true,second),"shuffle off-repeat exhaustion stops");
        q.repeat=1;eq(true,q.next(true,second)!=null,"shuffle repeats new round");
        q=new QueueEngine();q.setContext(Collections.singletonList("a"),"a");q.shuffle=true;q.repeat=0;
        eq(null,q.next(true,"a"),"single shuffled track off repeat");q.repeat=1;
        eq("a",q.next(true,"a"),"single shuffled track repeat");
        q=queue();ArrayList<String> source=new ArrayList<>(Arrays.asList("a","b"));q.setContext(source,"a");source.clear();
        eq(Arrays.asList("a","b"),q.context,"context copies user playlist input");
        ListeningClock c=new ListeningClock();
        eq(0L,c.sample(1000,2000),"first sample only anchors");
        eq(5000L,c.sample(6000,7000),"normal advancing audio");
        eq(0L,c.sample(11000,7000),"buffering is not listening");
        eq(1000L,c.sample(16000,8000),"partial advance not full wall time");
        c.clear();eq(0L,c.sample(90000,8000),"pause or stop resets anchor");
        eq(500L,c.sample(90500,8500),"resumed audio");
        c.reset(100000,180000);eq(5000L,c.sample(105000,185000),"explicit seek reset excludes skipped section");
        c.reset(200000,5000);eq(5000L,c.sample(205000,10000),"backwards seek with anchor");
        eq(0L,c.sample(206000,0),"backwards position never negative");
        eq(0L,c.sample(205000,1000),"backwards clock never negative");
        c.reset(0,0);eq(100L,c.sample(100,100000),"clock cannot count more than elapsed time");
        eq(30000L,ListeningClock.qualificationThreshold(240000),"long-track threshold");
        eq(10000L,ListeningClock.qualificationThreshold(20000),"short-track half duration");
        eq(30000L,ListeningClock.qualificationThreshold(0),"unknown duration threshold");
        eq(1L,ListeningClock.qualificationThreshold(1),"tiny duration threshold");
        eq(10001L,ListeningClock.qualificationThreshold(20001),"half duration rounds upward");
        eq(5000L,ListeningClock.overlap(10000,20000,15000,25000),"clip at range start");
        eq(5000L,ListeningClock.overlap(10000,20000,5000,15000),"clip at range end");
        eq(0L,ListeningClock.overlap(10000,20000,20000,25000),"exclusive end does not double count midnight");
        eq(10000L,ListeningClock.overlap(10000,20000,0,30000),"full contained segment");
        eq(2000L,ListeningClock.overlap(10000,20000,14000,16000),"range inside segment");
        eq(0L,ListeningClock.overlap(10000,20000,0,9000),"disjoint interval");
        eq(0L,ListeningClock.overlap(10000,20000,15000,15000),"empty period");
        System.out.println("PASS: "+assertions+" assertions; production QueueEngine + ListeningClock. No Android device used.");
    }
}
