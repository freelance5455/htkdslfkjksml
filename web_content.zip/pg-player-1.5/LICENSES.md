# Componentes e licenças

O pacote preserva os JARs e avisos de Junrar 8.1.1 e SLF4J 2.0.17 existentes no projeto 1.1. Leia `libs/JUNRAR-LICENSE.txt`, `libs/SLF4J-LICENSE.txt` e o POM incluído. O código-fonte Junrar recebido também permanece em `libs/junrar-8.1.1-sources.jar`.

O build incorpora os avisos de licença no APK quando a compilação é concluída. Este pacote não inclui Android SDK, fontes tipográficas comerciais, músicas ou vídeos de terceiros. Ícones da nova interface são desenhos vetoriais por código; a prévia usa nomes e dados fictícios.

A interface Android depende do WebView fornecido/instalado no aparelho. As licenças dos componentes de terceiros não são substituídas por uma declaração genérica sobre o código próprio do PG Player.
