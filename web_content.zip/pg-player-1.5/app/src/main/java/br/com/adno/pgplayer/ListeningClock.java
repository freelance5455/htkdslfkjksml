package br.com.adno.pgplayer;

/** Counts advancing audio, not paused time, buffering or seek jumps. Unit tested on JVM. */
public final class ListeningClock {
    private long lastElapsed=-1, lastPosition;
    public void reset(long elapsed,long position) { lastElapsed=elapsed; lastPosition=position; }
    public void clear() { lastElapsed=-1; }
    public long sample(long elapsed,long position) {
        if(lastElapsed<0) { reset(elapsed,position); return 0; }
        long wall=Math.max(0,elapsed-lastElapsed), advance=Math.max(0,position-lastPosition);
        reset(elapsed,position);
        return Math.min(wall,advance);
    }
    public static long qualificationThreshold(long duration) {
        return duration>0 ? Math.min(30000,Math.max(1,(duration+1)/2)) : 30000;
    }
    public static long overlap(long start,long end,long from,long to) {
        return Math.max(0,Math.min(end,to)-Math.max(start,from));
    }
}
