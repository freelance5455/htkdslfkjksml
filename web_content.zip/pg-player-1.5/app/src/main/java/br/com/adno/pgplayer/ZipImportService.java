package br.com.adno.pgplayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Keeps ZIP/RAR import alive when the user leaves the activity. No internet is used. */
public final class ZipImportService extends Service {
    private static final String CHANNEL = "zip_import";
    private static final int NOTIFICATION_ID = 42;
    private static final String CANCEL = "br.com.adno.pgplayer.CANCEL_IMPORT";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean cancelled = new AtomicBoolean();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private boolean importing;
    private Uri source;

    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Importação de músicas", NotificationManager.IMPORTANCE_LOW);
        channel.setSound(null, null);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && CANCEL.equals(intent.getAction())) {
            cancelled.set(true);
            return START_NOT_STICKY;
        }
        if (importing) {
            Toast.makeText(this, "Um arquivo já está sendo importado.", Toast.LENGTH_SHORT).show();
            return START_NOT_STICKY;
        }
        if (intent == null || intent.getData() == null) { stopSelf(); return START_NOT_STICKY; }
        source = intent.getData();
        importing = true;
        Notification notification = progressNotification(0);
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(NOTIFICATION_ID, notification);
        final File destination = new File(getFilesDir(), "imported/" + UUID.randomUUID());
        worker.execute(() -> {
            try {
                List<ZipExtractor.ImportedAudio> extracted;
                try (InputStream input = getContentResolver().openInputStream(source)) {
                    if (input == null) throw new java.io.IOException("Não foi possível abrir o arquivo.");
                    extracted = ArchiveImporter.extract(input, destination, getCacheDir(), new ZipExtractor.Progress() {
                        private long lastUpdate;
                        @Override public boolean cancelled() { return cancelled.get(); }
                        @Override public void onTrack(int count) {
                            long now = android.os.SystemClock.elapsedRealtime();
                            if (now - lastUpdate > 300) {
                                getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, progressNotification(count));
                                lastUpdate = now;
                            }
                        }
                    });
                }
                ArrayList<Track> tracks = new ArrayList<>();
                for (ZipExtractor.ImportedAudio audio : extracted)
                    tracks.add(MetadataReader.read(this,new Track(Uri.fromFile(audio.file).toString(), audio.title),false));
                handler.post(() -> commit(tracks, destination));
            } catch (Exception e) {
                ZipExtractor.deleteDirectory(destination);
                String message = e instanceof java.util.zip.ZipException
                        ? "Este ZIP está protegido ou danificado. Use um ZIP válido e sem senha."
                        : e instanceof java.io.IOException ? e.getMessage() : "Não foi possível ler o arquivo. Use um ZIP ou RAR válido e sem senha.";
                handler.post(() -> finishImport(message == null ? "Não foi possível importar o arquivo." : message, false));
            }
        });
        return START_NOT_STICKY;
    }

    private void commit(ArrayList<Track> tracks, File destination) {
        if (cancelled.get()) {
            ZipExtractor.deleteDirectory(destination);
            finishImport("Importação cancelada.", false);
            return;
        }
        ServiceConnection connection = new ServiceConnection() {
            @Override public void onServiceConnected(ComponentName name, IBinder binder) {
                ((PlaybackService.LocalBinder) binder).getService().addTracks(tracks);
                unbindService(this);
                finishImport(tracks.size() + (tracks.size() == 1 ? " música importada." : " músicas importadas."), true);
            }
            @Override public void onServiceDisconnected(ComponentName name) {}
        };
        if (!bindService(new Intent(this, PlaybackService.class), connection, Context.BIND_AUTO_CREATE)) {
            ZipExtractor.deleteDirectory(destination);
            finishImport("Não foi possível salvar as músicas. Tente novamente.", false);
        }
    }

    private Notification progressNotification(int count) {
        PendingIntent cancel = PendingIntent.getService(this, 42, new Intent(this, ZipImportService.class).setAction(CANCEL), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_music)
                .setContentTitle("Importando músicas de ZIP / RAR")
                .setContentText(count == 0 ? "Abrindo o arquivo…" : count + " músicas encontradas")
                .setProgress(0, 0, true).setOngoing(true).setOnlyAlertOnce(true)
                .setContentIntent(openApp())
                .addAction(new Notification.Action.Builder(R.drawable.ic_close, "Cancelar", cancel).build()).build();
    }
    private PendingIntent openApp() {
        return PendingIntent.getActivity(this, 42, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
    private void finishImport(String message, boolean success) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        stopForeground(STOP_FOREGROUND_REMOVE);
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID,
                new Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_music)
                        .setContentTitle(success ? "Músicas prontas para tocar" : "Importação de músicas")
                        .setContentText(message).setStyle(new Notification.BigTextStyle().bigText(message))
                        .setContentIntent(openApp()).setAutoCancel(true).build());
        if (source != null) {
            try { getContentResolver().releasePersistableUriPermission(source, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (SecurityException ignored) {}
        }
        importing = false;
        stopSelf();
    }
    @Override public void onTimeout(int startId, int fgsType) {
        cancelled.set(true);
        finishImport("Importação interrompida pelo Android. Tente um arquivo menor.", false);
    }
    @Override public void onDestroy() {
        cancelled.set(true);
        worker.shutdownNow();
        super.onDestroy();
    }
}
