package br.com.adno.pgplayer;

import com.github.junrar.Archive;
import com.github.junrar.ArchiveOptions;
import com.github.junrar.rarfile.FileHeader;
import com.github.junrar.exception.RarException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** RAR4/RAR5 extraction to generated file names; archives cannot supply output paths. */
public final class RarExtractor {
    public static List<ZipExtractor.ImportedAudio> extract(File input, File destination, ZipExtractor.Progress progress) throws IOException {
        if (!destination.isDirectory() && !destination.mkdirs()) throw new IOException("Não foi possível criar a pasta de músicas.");
        ArrayList<ZipExtractor.ImportedAudio> tracks = new ArrayList<>();
        final long[] total = {0};
        final long limit = Math.min(5L * 1024 * 1024 * 1024, destination.getUsableSpace() - 100L * 1024 * 1024);
        if (limit <= 0) throw new IOException("Libere espaço no celular antes de importar este RAR.");
        // Limit decompressor memory for Android; common RAR4/5 dictionaries fit this budget.
        ArchiveOptions options = ArchiveOptions.builder().maxDictionarySize(64L * 1024 * 1024).build();
        try (Archive archive = new Archive(input, options)) {
            if (archive.isPasswordProtected()) throw new IOException("Escolha um RAR sem senha para importar as músicas.");
            List<FileHeader> headers = archive.getFileHeaders();
            if (headers.size() > 10000) throw new IOException("Este RAR tem arquivos demais. Divida-o em arquivos menores.");
            for (FileHeader header : headers) {
                if (progress.cancelled()) throw new IOException("Importação cancelada.");
                if (header.isDirectory()) continue;
                String path = header.getFileName().replace('\\', '/');
                String filename = path.substring(path.lastIndexOf('/') + 1);
                if (filename.startsWith("._") || path.startsWith("__MACOSX/")) continue;
                int dot = filename.lastIndexOf('.');
                if (dot < 0) continue;
                String extension = filename.substring(dot + 1).toLowerCase(Locale.ROOT);
                if (!ZipExtractor.isAudio(extension)) continue;
                if (header.isEncrypted()) throw new IOException("Escolha um RAR sem senha para importar as músicas.");
                if (header.isSplitBefore() || header.isSplitAfter()) throw new IOException("Use um RAR único, sem divisão em partes.");
                if (header.getFullUnpackSize() > 512L * 1024 * 1024)
                    throw new IOException("Uma música deste RAR é grande demais. Use arquivos menores que 512 MB.");
                if (header.getRedirection() != null) continue; // Ignore RAR5 links; import actual audio data only.
                File target = new File(destination, String.format(Locale.ROOT, "%05d.%s", tracks.size() + 1, extension));
                try (FileOutputStream file = new FileOutputStream(target)) {
                    OutputStream bounded = new OutputStream() {
                        private long written;
                        @Override public void write(int value) throws IOException { byte[] one = {(byte) value}; write(one, 0, 1); }
                        @Override public void write(byte[] bytes, int offset, int length) throws IOException {
                            if (progress.cancelled() || Thread.currentThread().isInterrupted()) throw new IOException("Importação cancelada.");
                            written += length;
                            total[0] += length;
                            if (written > 512L * 1024 * 1024 || total[0] > limit)
                                throw new IOException("O RAR excede o espaço ou o limite de importação. Divida-o em arquivos menores.");
                            file.write(bytes, offset, length);
                        }
                    };
                    archive.extractFile(header, bounded);
                }
                if (target.length() == 0) { target.delete(); continue; }
                String title = filename.substring(0, dot).replaceAll("[\\p{Cntrl}]", "").trim();
                if (title.isEmpty()) title = "Música " + (tracks.size() + 1);
                tracks.add(new ZipExtractor.ImportedAudio(target, title));
                progress.onTrack(tracks.size());
            }
            if (tracks.isEmpty()) throw new IOException("Nenhum MP3 ou áudio compatível foi encontrado no RAR.");
            return tracks;
        } catch (RarException e) {
            ZipExtractor.deleteDirectory(destination);
            if (progress.cancelled()) throw new IOException("Importação cancelada.", e);
            throw new IOException("Não foi possível extrair o RAR. Use um arquivo único, válido, sem senha e com dicionário de até 64 MB.", e);
        } catch (IOException | RuntimeException e) {
            ZipExtractor.deleteDirectory(destination);
            throw e;
        }
    }
    private RarExtractor() {}
}
