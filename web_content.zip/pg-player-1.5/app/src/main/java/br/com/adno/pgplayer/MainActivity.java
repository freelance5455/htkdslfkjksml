package br.com.adno.pgplayer;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.media.AudioManager;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.util.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Local-only presentation. Playback and history remain in native Android services/SQLite. */
public final class MainActivity extends Activity implements PlaybackService.Listener {
    private static final int AUDIO=10,ARCHIVE=12,VIDEO=13,COVER=14,EXPORT=15,RESTORE=16;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayList<Track> pendingTracks=new ArrayList<>();
    private PlaybackService service;
    private MediaLibrary library;
    private WebView web;
    private boolean bound,ready,destroyed;
    private int revision=-1;
    private String coverTarget="",backupMetadata="";
    private final ServiceConnection connection=new ServiceConnection(){
        @Override public void onServiceConnected(ComponentName n,IBinder b){
            service=((PlaybackService.LocalBinder)b).getService();service.addListener(MainActivity.this);
            if(!pendingTracks.isEmpty()){service.addTracks(pendingTracks);pendingTracks.clear();}
            sendLibrary();sendState();
        }
        @Override public void onServiceDisconnected(ComponentName n){service=null;}
    };
    private final Runnable ticker=new Runnable(){@Override public void run(){sendState();handler.postDelayed(this,1000);}};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);library=MediaLibrary.get(this);setVolumeControlStream(AudioManager.STREAM_MUSIC);
        getWindow().setStatusBarColor(Color.rgb(12,12,16));getWindow().setNavigationBarColor(Color.rgb(12,12,16));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(12,12,16));setContentView(root);
        root.setOnApplyWindowInsetsListener((view,insets)->{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets.consumeSystemWindowInsets();});root.requestApplyInsets();
        web=new WebView(this);web.setBackgroundColor(Color.rgb(12,12,16));root.addView(web,new LinearLayout.LayoutParams(-1,-1));
        WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setMediaPlaybackRequiresUserGesture(true);settings.setSupportMultipleWindows(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !local(request.getUrl());}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
                Uri uri=request.getUrl();if(!local(uri))return response("text/plain",new ByteArrayInputStream(new byte[0]));
                String path=uri.getPath();try{
                    if(path!=null && path.startsWith("/art/")) {
                        String filename=path.substring(5);if(!filename.matches("[a-zA-Z0-9_-]+\\.(jpg|png)"))throw new IOException("Invalid art");
                        return response(filename.endsWith("png")?"image/png":"image/jpeg",new FileInputStream(new File(getFilesDir(),"art/"+filename)));
                    }
                    String name="/".equals(path)?"index.html":path==null?"index.html":path.substring(1);
                    if(!Arrays.asList("index.html","style.css","app.js").contains(name))throw new IOException("Invalid asset");
                    return response(name.endsWith("css")?"text/css":name.endsWith("js")?"application/javascript":"text/html",getAssets().open("ui/"+name));
                }catch(Exception e){return response("text/plain",new ByteArrayInputStream(new byte[0]));}
            }
            @Override public void onPageFinished(WebView view,String url){ready=true;revision=-1;sendLibrary();sendState();}
            @Override public void onReceivedSslError(WebView view,android.webkit.SslErrorHandler handler,android.net.http.SslError error){handler.cancel();}
        });
        web.addJavascriptInterface(new Bridge(),"PGNative");web.loadUrl("https://pg.local/index.html");
    }
    private boolean local(Uri uri){return "https".equals(uri.getScheme())&&"pg.local".equals(uri.getHost());}
    private WebResourceResponse response(String mime,InputStream stream){
        HashMap<String,String> headers=new HashMap<>();headers.put("Cache-Control","no-store");headers.put("X-Content-Type-Options","nosniff");
        return new WebResourceResponse(mime,"UTF-8",200,"OK",headers,stream);
    }
    public final class Bridge {
        @JavascriptInterface public void send(String json){
            if(json==null||json.length()>8500000)return;
            handler.post(()->{if(destroyed)return;try{dispatch(new JSONObject(json));}catch(Exception e){error(e.getMessage()==null?"Não foi possível concluir a ação.":e.getMessage());}});
        }
    }
    private void dispatch(JSONObject j)throws Exception {
        String action=j.optString("action");
        switch(action){
            case "ready":revision=-1;sendLibrary();sendState();break;
            case "importAudio":pick(AUDIO,"audio/*",true);break;
            case "importArchive":pick(ARCHIVE,"*/*",false);break;
            case "importVideo":pick(VIDEO,"video/mp4",true);break;
            case "pickCover":coverTarget=j.optString("id");pick(COVER,"image/*",false);break;
            case "play":if(service!=null){notifications();JSONArray a=j.optJSONArray("context");ArrayList<String> list=new ArrayList<>();if(a!=null)for(int n=0;n<a.length();n++)list.add(a.optString(n));if(list.isEmpty())for(Track t:service.getTracks())list.add(t.uri);if(j.has("shuffle"))service.setModes(j.optBoolean("shuffle"),j.optInt("repeat",1));service.selectContext(list,j.getString("uri"));}break;
            case "toggle":if(service!=null){notifications();service.toggle();}break;
            case "next":if(service!=null)service.next(false);break;
            case "previous":if(service!=null)service.previous();break;
            case "seek":if(service!=null)service.seek(j.optInt("position",0));break;
            case "shuffle":if(service!=null)service.toggleShuffle();break;
            case "repeat":if(service!=null)service.cycleRepeat();break;
            case "enqueue":if(service!=null){service.enqueue(j.getString("uri"));notice("Adicionada à fila");}break;
            case "moveQueue":if(service!=null)service.moveQueue(j.optInt("from"),j.optInt("to"));break;
            case "removeQueue":if(service!=null)service.removeQueued(j.optInt("index"));break;
            case "clearQueue":if(service!=null)service.clearQueue();break;
            case "favorite":if(service!=null)service.setFavorite(j.getString("uri"),j.optBoolean("value"));break;
            case "savePlaylist":library.savePlaylist(j.getJSONObject("playlist"));sendLibrary();notice("Playlist salva");break;
            case "deletePlaylist":library.deletePlaylist(j.getString("id"));sendLibrary();notice("Playlist excluída. As músicas continuam na biblioteca.");break;
            case "removeTrack":if(service!=null){List<Track> ts=service.getTracks();for(int n=0;n<ts.size();n++)if(ts.get(n).uri.equals(j.optString("uri"))){service.removeTrack(n);break;}}break;
            case "stats":{
                if(service!=null)service.flushHistory();long from=j.getLong("from"),to=j.getLong("to");String request=j.optString("request");
                worker.execute(()->{try{JSONObject result=HistoryStore.get(this).stats(from,to);emit(new JSONObject().put("type","stats").put("request",request).put("data",result));}catch(Exception e){error("Falha ao consultar a Cápsula: "+e.getMessage());}});break;
            }
            case "history":{
                if(service!=null)service.flushHistory();long from=j.getLong("from"),to=j.getLong("to");int offset=j.optInt("offset");String request=j.optString("request");
                worker.execute(()->{try{emit(new JSONObject().put("type","history").put("request",request).put("offset",offset).put("data",HistoryStore.get(this).history(from,to,offset)));}catch(Exception e){error("Não foi possível abrir o histórico.");}});break;
            }
            case "accent":library.accent(j.optString("color"));library.dynamic(j.optBoolean("dynamic"));sendLibrary();break;
            case "boost":if(service!=null)service.setBoostDb(j.optInt("db"));break;
            case "volume":{AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);audio.setStreamVolume(AudioManager.STREAM_MUSIC,Math.max(0,Math.min(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),j.optInt("value"))),0);sendState();break;}
            case "openVideo":if(service!=null)service.pause();startActivity(new Intent(this,VideoActivity.class).setData(Uri.parse(j.getString("uri"))).putExtra("title",j.optString("title")));break;
            case "removeVideo":library.removeVideo(j.getString("uri"));sendLibrary();break;
            case "share":share(j.getString("png"));break;
            case "exportBackup":prepareBackup();break;
            case "importBackup":new AlertDialog.Builder(this).setTitle("Restaurar backup").setMessage("O histórico e as playlists serão mesclados, sem apagar os atuais. O backup não contém músicas, vídeos nem capas. Em outro celular, será preciso selecionar os arquivos novamente.").setPositiveButton("Escolher backup",(d,w)->pick(RESTORE,"application/json",false)).setNegativeButton("Cancelar",null).show();break;
            case "refreshMetadata":refreshMetadata();break;
            default:throw new IllegalArgumentException("Ação não reconhecida.");
        }
    }
    private void emit(JSONObject json){
        handler.post(()->{if(!ready||destroyed||web==null)return;String data=json.toString().replace("\u2028","\\u2028").replace("\u2029","\\u2029");web.evaluateJavascript("window.PG&&window.PG.receive("+data+")",null);});
    }
    private void notice(String message){try{emit(new JSONObject().put("type","notice").put("message",message));}catch(Exception ignored){}}
    private void error(String message){try{emit(new JSONObject().put("type","error").put("message",message));}catch(Exception ignored){}}
    private void sendLibrary(){
        if(service==null||!ready)return;try{
            JSONArray tracks=new JSONArray();for(Track t:service.getTracks())tracks.put(t.toJson());
            emit(new JSONObject().put("type","library").put("tracks",tracks).put("playlists",library.playlists()).put("videos",library.videos()).put("accent",library.accent()).put("dynamic",library.dynamic()));revision=service.getLibraryRevision();
        }catch(Exception e){error("Falha ao carregar a biblioteca.");}
    }
    private void sendState(){
        if(service==null||!ready)return;try{
            Track current=service.getCurrentTrack();AudioManager a=(AudioManager)getSystemService(AUDIO_SERVICE);QueueEngine queue=service.getQueue();
            // Only a short automatic continuation is needed by the UI; the entire queue stays native.
            int nextStart=Math.min(queue.context.size(),Math.max(0,queue.cursor+1));
            List<String> continuation=queue.context.subList(nextStart,Math.min(queue.context.size(),nextStart+30));
            emit(new JSONObject().put("type","state").put("playing",service.isPlaying()).put("preparing",service.isPreparing()).put("current",current==null?JSONObject.NULL:current.toJson())
                .put("position",service.getPosition()).put("duration",service.getDuration()).put("shuffle",service.isShuffle()).put("repeat",service.getRepeatMode()).put("queue",new JSONArray(queue.pending))
                .put("context",new JSONArray(continuation)).put("cursor",-1).put("boost",service.getBoostDb()).put("boostSupported",service.isEffectSupported())
                .put("volume",a.getStreamVolume(AudioManager.STREAM_MUSIC)).put("maxVolume",a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).put("error",service.getError()==null?HistoryStore.get(this).getWriteError():service.getError()));
        }catch(Exception e){Log.w("PGPlayer","UI state",e);}
    }
    @Override public void onPlayerChanged(){if(service!=null&&revision!=service.getLibraryRevision())sendLibrary();sendState();}
    @Override protected void onStart(){super.onStart();bound=bindService(new Intent(this,PlaybackService.class),connection,Context.BIND_AUTO_CREATE);handler.post(ticker);}
    @Override protected void onStop(){handler.removeCallbacks(ticker);if(service!=null){service.removeListener(this);service=null;}if(bound){unbindService(connection);bound=false;}super.onStop();}
    @Override protected void onDestroy(){destroyed=true;worker.shutdown();if(web!=null){web.removeJavascriptInterface("PGNative");web.destroy();web=null;}super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.PG&&window.PG.back()",result->{if("false".equals(result))moveTaskToBack(true);});else super.onBackPressed();}
    private void notifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},11);}
    private void pick(int request,String type,boolean multiple){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType(type).addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_ALLOW_MULTIPLE,multiple).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(intent,request);}catch(ActivityNotFoundException e){error("Nenhum seletor de arquivos disponível no aparelho.");}
    }
    private String filename(Uri uri){
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "Sem título";
    }
    private void persist(Uri uri,Intent result){try{getContentResolver().takePersistableUriPermission(uri,result.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}}
    @Override protected void onActivityResult(int request,int resultCode,Intent result){
        super.onActivityResult(request,resultCode,result);if(resultCode!=RESULT_OK||result==null)return;
        if(request==EXPORT){if(result.getData()!=null)writeBackup(result.getData());return;}
        if(request==RESTORE){if(result.getData()!=null)readBackup(result.getData());return;}
        if(request==COVER){if(result.getData()!=null)readCover(result.getData(),coverTarget);return;}
        if(request==ARCHIVE){if(result.getData()!=null){persist(result.getData(),result);notifications();startForegroundService(new Intent(this,ZipImportService.class).setData(result.getData()));notice("Importação iniciada. Acompanhe pela notificação.");}return;}
        if(request!=AUDIO&&request!=VIDEO)return;
        ArrayList<Uri> uris=new ArrayList<>();ClipData clips=result.getClipData();if(clips!=null){for(int n=0;n<clips.getItemCount();n++)uris.add(clips.getItemAt(n).getUri());}else if(result.getData()!=null)uris.add(result.getData());
        for(Uri uri:uris)persist(uri,result);notice("Lendo "+uris.size()+" arquivo(s)…");
        worker.execute(()->{
            ArrayList<Track> tracks=new ArrayList<>();for(Uri uri:uris)tracks.add(MetadataReader.read(this,new Track(uri.toString(),filename(uri).replaceFirst("(?i)\\.(mp3|m4a|aac|wav|ogg|flac|mp4)$","")),request==VIDEO));
            handler.post(()->{try{if(request==VIDEO){library.addVideos(tracks);sendLibrary();}else if(service!=null)service.addTracks(tracks);else pendingTracks.addAll(tracks);notice(tracks.size()+" arquivo(s) adicionado(s)");}catch(Exception e){error("Não foi possível salvar a importação.");}});
        });
    }
    private void refreshMetadata(){
        if(service==null)return;List<Track> tracks=service.getTracks();notice("Atualizando títulos, artistas e capas…");
        worker.execute(()->{ArrayList<Track> updated=new ArrayList<>();for(Track t:tracks)updated.add(MetadataReader.read(this,t,false));handler.post(()->{if(service!=null){service.updateMetadataBatch(updated);notice("Metadados atualizados");}else notice("Abra o app e atualize os metadados novamente.");});});
    }
    private void readCover(Uri uri,String id){worker.execute(()->{try{
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,opts);}
        if(opts.outWidth<=0||opts.outHeight<=0)throw new IOException("Imagem inválida.");opts.inSampleSize=Math.max(1,Math.max(opts.outWidth,opts.outHeight)/720);opts.inJustDecodeBounds=false;
        Bitmap bitmap;try(InputStream in=getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(in,null,opts);}if(bitmap==null)throw new IOException("Imagem inválida.");
        File dir=new File(getFilesDir(),"art");dir.mkdirs();String name="pl_"+UUID.randomUUID()+".jpg";try(OutputStream out=new FileOutputStream(new File(dir,name))){bitmap.compress(Bitmap.CompressFormat.JPEG,90,out);}finally{bitmap.recycle();}
        emit(new JSONObject().put("type","cover").put("id",id).put("cover",name));
    }catch(Exception e){error("Não foi possível usar essa capa.");}});}
    private void share(String encoded){
        worker.execute(()->{try{
            if(!encoded.startsWith("data:image/png;base64,"))throw new IOException("Imagem inválida.");
            byte[] bytes=android.util.Base64.decode(encoded.substring(encoded.indexOf(',')+1),android.util.Base64.DEFAULT);if(bytes.length>6000000)throw new IOException("Imagem muito grande.");
            BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);if(opts.outWidth<1||opts.outWidth>2160||opts.outHeight>3840)throw new IOException("Dimensões inválidas.");
            File dir=new File(getCacheDir(),"share");dir.mkdirs();File[] old=dir.listFiles();if(old!=null)for(File f:old)if(System.currentTimeMillis()-f.lastModified()>604800000L)f.delete();
            File file=new File(dir,"capsula_"+System.currentTimeMillis()+".png");try(OutputStream out=new FileOutputStream(file)){out.write(bytes);}
            Uri uri=Uri.parse("content://"+getPackageName()+".share/"+file.getName());handler.post(()->{
                Intent intent=new Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM,uri).putExtra(Intent.EXTRA_TEXT,"Minha Cápsula Sonora • PG Player 1.5").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.setClipData(ClipData.newRawUri("Cápsula Sonora",uri));try{startActivity(Intent.createChooser(intent,"Compartilhar Cápsula Sonora"));}catch(ActivityNotFoundException e){error("Nenhum aplicativo disponível para compartilhar.");}
            });
        }catch(Exception e){error("Não foi possível compartilhar: "+e.getMessage());}});
    }
    private void prepareBackup()throws JSONException{
        if(service==null)return;service.flushHistory();JSONArray tracks=new JSONArray();for(Track t:service.getTracks())tracks.put(t.toJson());
        backupMetadata=new JSONObject().put("tracks",tracks).put("library",library.exportData()).toString();
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"PG-Player-backup-"+new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())+".json");startActivityForResult(i,EXPORT);
    }
    private void writeBackup(Uri uri){String metadata=backupMetadata;worker.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
        if(out==null)throw new IOException("Destino indisponível.");JsonWriter w=new JsonWriter(new OutputStreamWriter(out,"UTF-8"));w.beginObject().name("format").value("PGPlayerBackup").name("version").value(1).name("metadata").value(metadata).name("history");HistoryStore.get(this).exportHistory(w);w.endObject();w.flush();notice("Backup salvo: histórico, playlists e referências. Não inclui os arquivos de mídia.");
    }catch(Exception e){error("Falha ao salvar o backup: "+e.getMessage());}});}
    private void readBackup(Uri uri){worker.execute(()->{try(InputStream in=getContentResolver().openInputStream(uri)){
        if(in==null)throw new IOException("Arquivo indisponível.");JsonReader r=new JsonReader(new InputStreamReader(in,"UTF-8"));boolean format=false;String metadata=null;
        r.beginObject();while(r.hasNext()){String key=r.nextName();if("format".equals(key)){format="PGPlayerBackup".equals(r.nextString());if(!format)throw new IOException("Este não é um backup do PG Player.");}else if("version".equals(key)){if(r.nextInt()!=1)throw new IOException("Versão de backup não suportada.");}else if("metadata".equals(key))metadata=r.nextString();else if("history".equals(key)){if(!format)throw new IOException("Cabeçalho ausente.");HistoryStore.get(this).importHistory(r);}else r.skipValue();}r.endObject();
        if(!format||metadata==null)throw new IOException("Backup incompleto.");JSONObject m=new JSONObject(metadata);library.mergeData(m.getJSONObject("library"));JSONArray array=m.getJSONArray("tracks");ArrayList<Track> tracks=new ArrayList<>();for(int i=0;i<array.length();i++)tracks.add(Track.fromJson(array.getJSONObject(i)));
        handler.post(()->{if(service!=null)service.addTracks(tracks);else pendingTracks.addAll(tracks);sendLibrary();notice("Backup mesclado. Confira o acesso às músicas neste aparelho.");});
    }catch(Exception e){error("Não foi possível restaurar: "+e.getMessage());}});}
}
