package br.com.adno.pgplayer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Streaming ZIP extraction: never loads songs into RAM or trusts archive paths. */
public final class ZipExtractor {
    public interface Progress {
        boolean cancelled();
        void onTrack(int count);
    }
    public static final class ImportedAudio {
        public final File file;
        public final String title;
        ImportedAudio(File file, String title) { this.file = file; this.title = title; }
    }

    public static List<ImportedAudio> extract(InputStream input, File destination, Progress progress) throws IOException {
        if (!destination.isDirectory() && !destination.mkdirs()) throw new IOException("Não foi possível criar a pasta de músicas.");
        ArrayList<ImportedAudio> result = new ArrayList<>();
        byte[] buffer = new byte[65536];
        long total = 0;
        long limit = Math.min(5L * 1024 * 1024 * 1024, destination.getUsableSpace() - 100L * 1024 * 1024);
        if (limit <= 0) throw new IOException("Libere espaço no celular antes de importar este ZIP.");
        int entries = 0;
        // CP437 handles older Windows archives; the ZIP UTF-8 flag takes precedence.
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(input), Charset.forName("CP437"))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (progress.cancelled()) throw new IOException("Importação cancelada.");
                if (++entries > 10000) throw new IOException("Este ZIP tem arquivos demais. Divida-o em arquivos menores.");
                String path = entry.getName().replace('\\', '/');
                String filename = path.substring(path.lastIndexOf('/') + 1);
                if (entry.isDirectory() || filename.startsWith("._") || path.startsWith("__MACOSX/")) continue;
                int dot = filename.lastIndexOf('.');
                if (dot < 0) continue;
                String extension = filename.substring(dot + 1).toLowerCase(Locale.ROOT);
                if (!isAudio(extension)) continue;
                // Generated flat names prevent traversal and preserve duplicate track names.
                File target = new File(destination, String.format(Locale.ROOT, "%05d.%s", result.size() + 1, extension));
                long fileBytes = 0;
                try (FileOutputStream out = new FileOutputStream(target)) {
                    int read;
                    while ((read = zip.read(buffer)) != -1) {
                        if (progress.cancelled() || Thread.currentThread().isInterrupted()) throw new IOException("Importação cancelada.");
                        fileBytes += read;
                        total += read;
                        if (fileBytes > 512L * 1024 * 1024 || total > limit)
                            throw new IOException("O ZIP excede o espaço ou o limite de importação. Divida-o em arquivos menores.");
                        out.write(buffer, 0, read);
                    }
                }
                if (fileBytes == 0) { target.delete(); continue; }
                String title = filename.substring(0, dot).replaceAll("[\\p{Cntrl}]", "").trim();
                if (title.isEmpty()) title = "Música " + (result.size() + 1);
                result.add(new ImportedAudio(target, title));
                progress.onTrack(result.size());
            }
        } catch (IOException | RuntimeException e) {
            deleteDirectory(destination);
            throw e;
        }
        if (result.isEmpty()) {
            deleteDirectory(destination);
            throw new IOException("Nenhum MP3 ou arquivo de áudio compatível foi encontrado no ZIP.");
        }
        return result;
    }

    static boolean isAudio(String extension) {
        return extension.equals("mp3") || extension.equals("m4a") || extension.equals("aac")
                || extension.equals("wav") || extension.equals("ogg") || extension.equals("flac");
    }
    public static void deleteDirectory(File directory) {
        File[] children = directory.listFiles();
        if (children != null) for (File file : children) {
            if (file.isDirectory()) deleteDirectory(file); else file.delete();
        }
        directory.delete();
    }
    private ZipExtractor() {}
}
