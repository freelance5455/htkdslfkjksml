package br.com.adno.pgplayer;

import org.json.JSONException;
import org.json.JSONObject;

/** Backwards-compatible with the two-field tracks saved by PG Player 1.1. */
public final class Track {
    public final String uri, title, artist, album, art;
    public final long duration;
    public final boolean favorite;
    public Track(String uri, String title) { this(uri,title,"Artista desconhecido","","",0,false); }
    public Track(String uri,String title,String artist,String album,String art,long duration,boolean favorite) {
        this.uri=uri; this.title=title; this.artist=artist; this.album=album;
        this.art=art; this.duration=Math.max(0,duration); this.favorite=favorite;
    }
    public Track favorite(boolean value) { return new Track(uri,title,artist,album,art,duration,value); }
    public JSONObject toJson() throws JSONException {
        return new JSONObject().put("uri",uri).put("title",title).put("artist",artist)
            .put("album",album).put("art",art).put("duration",duration).put("favorite",favorite);
    }
    public static Track fromJson(JSONObject j) throws JSONException {
        return new Track(j.getString("uri"),j.optString("title","Sem título"),
            j.optString("artist","Artista desconhecido"),j.optString("album",""),
            j.optString("art",""),j.optLong("duration",0),j.optBoolean("favorite",false));
    }
}
