package br.com.adno.pgplayer;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.util.JsonReader;
import android.util.JsonWriter;
import org.json.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import android.util.Log;

/** Permanent local history. Every start is kept; rankings distinguish valid listening. */
public final class HistoryStore extends SQLiteOpenHelper {
    private static HistoryStore instance;
    // The player never waits for a years-long statistical query on the UI/audio-control thread.
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private volatile String writeError="";
    public String getWriteError(){return writeError;}
    private void write(Runnable task){io.execute(()->{try{task.run();}catch(RuntimeException e){writeError="Não foi possível salvar a Cápsula. Confira o espaço disponível e faça um backup.";Log.e("PGHistory",writeError,e);}});}
    private <T> T call(Callable<T> task){
        try{return io.submit(task).get();}
        catch(InterruptedException e){Thread.currentThread().interrupt();throw new IllegalStateException("Operação interrompida",e);}
        catch(ExecutionException e){throw new IllegalStateException(e.getCause()==null?e.getMessage():e.getCause().getMessage(),e.getCause());}
    }
    public String start(Track t,long duration,long now){String id=UUID.randomUUID().toString();write(()->startNow(id,t,duration,now));return id;}
    public void append(String id,long end,long listened){if(id!=null&&listened>0)write(()->appendNow(id,end,listened));}
    public void finish(String id,long now,String reason){if(id!=null)write(()->finishNow(id,now,reason));}
    // Call the following blocking methods from a worker, never the Android UI thread.
    public JSONObject stats(long from,long to)throws JSONException{return call(()->statsNow(from,to));}
    public JSONArray history(long from,long to,int offset)throws JSONException{return call(()->historyNow(from,to,offset));}
    public void exportHistory(JsonWriter writer)throws IOException{call(()->{exportNow(writer);return null;});}
    public void importHistory(JsonReader reader)throws IOException{call(()->{importNow(reader);return null;});}
    public static synchronized HistoryStore get(Context c) {
        if(instance==null)instance=new HistoryStore(c.getApplicationContext());return instance;
    }
    private HistoryStore(Context c) {
        super(c,"capsula15.db",null,1);setWriteAheadLoggingEnabled(true);
        write(()->getWritableDatabase().execSQL("UPDATE plays SET ended=last,reason='interrompida' WHERE ended=0"));
    }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE plays(id TEXT PRIMARY KEY,uri TEXT NOT NULL,title TEXT NOT NULL,artist TEXT NOT NULL,album TEXT NOT NULL,started INTEGER NOT NULL,last INTEGER NOT NULL,duration INTEGER NOT NULL,listened INTEGER NOT NULL DEFAULT 0,ended INTEGER NOT NULL DEFAULT 0,reason TEXT NOT NULL DEFAULT '')");
        db.execSQL("CREATE TABLE segments(id TEXT PRIMARY KEY,play_id TEXT NOT NULL,start_ms INTEGER NOT NULL,end_ms INTEGER NOT NULL,listened_ms INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX segment_time ON segments(start_ms,end_ms)");
        db.execSQL("CREATE INDEX segment_play ON segments(play_id,start_ms)");
        db.execSQL("CREATE INDEX play_started ON plays(started)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int old,int version){throw new IllegalStateException("Migração desconhecida; dados preservados.");}
    private void startNow(String id,Track t,long duration,long now) {
        ContentValues v=new ContentValues();v.put("id",id);v.put("uri",t.uri);v.put("title",t.title);v.put("artist",t.artist);v.put("album",t.album);v.put("started",now);v.put("last",now);v.put("duration",duration);
        getWritableDatabase().insertOrThrow("plays",null,v);
    }
    private void appendNow(String id,long end,long listened) {
        if(id==null||listened<=0)return;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            long start=end-listened;
            // Split at local hour boundaries. Midnight/month/year filters do not attribute a whole play to its starting day.
            while(start<end){Calendar cal=Calendar.getInstance();cal.setTimeInMillis(start);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long hourStart=cal.getTimeInMillis();cal.add(Calendar.HOUR_OF_DAY,1);long until=Math.min(end,cal.getTimeInMillis());
                String previous=null;long previousEnd=0;
                try(Cursor c=db.rawQuery("SELECT id,end_ms FROM segments WHERE play_id=? AND start_ms>=? ORDER BY start_ms DESC LIMIT 1",new String[]{id,""+hourStart})){
                    if(c.moveToFirst()){previous=c.getString(0);previousEnd=c.getLong(1);}
                }
                if(previous!=null && start>=previousEnd && start-previousEnd<=100){
                    db.execSQL("UPDATE segments SET end_ms=?,listened_ms=listened_ms+? WHERE id=?",new Object[]{until,until-start,previous});
                }else{ContentValues v=new ContentValues();v.put("id",UUID.randomUUID().toString());v.put("play_id",id);v.put("start_ms",start);v.put("end_ms",until);v.put("listened_ms",until-start);db.insertOrThrow("segments",null,v);}
                start=until;
            }
            db.execSQL("UPDATE plays SET listened=listened+?,last=? WHERE id=?",new Object[]{listened,end,id});db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    private void finishNow(String id,long now,String reason) {
        if(id!=null)getWritableDatabase().execSQL("UPDATE plays SET ended=?,reason=? WHERE id=?",new Object[]{now,reason,id});
    }
    private static final class Count {
        String id,uri,title,artist;long ms,valid,starts,duration;
        JSONObject json() throws JSONException {return new JSONObject().put("id",id).put("uri",uri).put("title",title).put("artist",artist).put("ms",ms).put("plays",starts).put("valid",valid);}
    }
    private static long clipped(long start,long end,long ms,long from,long to) {
        long overlap=ListeningClock.overlap(start,end,from,to);
        return end>start?Math.min(ms,Math.round(overlap*(double)ms/(end-start))):0;
    }
    private JSONObject statsNow(long from,long to) throws JSONException {
        if(from<0||to<=from)throw new JSONException("Período inválido.");
        SQLiteDatabase db=getReadableDatabase();HashMap<String,Count> plays=new HashMap<>();
        TreeMap<String,Long> days=new TreeMap<>();long[] hours=new long[24],weekdays=new long[7];
        SimpleDateFormat dayFormat=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        try(Cursor c=db.rawQuery("SELECT s.play_id,s.start_ms,s.end_ms,s.listened_ms,p.uri,p.title,p.artist,p.duration FROM segments s JOIN plays p ON p.id=s.play_id WHERE s.start_ms<? AND s.end_ms>? ORDER BY s.start_ms",new String[]{""+to,""+from})) {
            while(c.moveToNext()) {
                long start=c.getLong(1),end=c.getLong(2),ms=clipped(start,end,c.getLong(3),from,to);if(ms<=0)continue;
                String id=c.getString(0);Count p=plays.get(id);if(p==null){p=new Count();p.id=id;p.uri=c.getString(4);p.title=c.getString(5);p.artist=c.getString(6);p.duration=c.getLong(7);plays.put(id,p);}p.ms+=ms;
                // A stored segment is at most one local hour; proportional clipping preserves actual listened milliseconds.
                Calendar cal=Calendar.getInstance();cal.setTimeInMillis(Math.max(start,from));String day=dayFormat.format(cal.getTime());
                days.put(day,days.containsKey(day)?days.get(day)+ms:ms);hours[cal.get(Calendar.HOUR_OF_DAY)]+=ms;weekdays[(cal.get(Calendar.DAY_OF_WEEK)+5)%7]+=ms;
            }
        }
        // Keep even a just-started track in the reproduction count without inventing listened time.
        try(Cursor c=db.rawQuery("SELECT id,uri,title,artist,duration FROM plays WHERE started>=? AND started<?",new String[]{""+from,""+to})) {
            while(c.moveToNext())if(!plays.containsKey(c.getString(0))){Count p=new Count();p.id=c.getString(0);p.uri=c.getString(1);p.title=c.getString(2);p.artist=c.getString(3);p.duration=c.getLong(4);plays.put(p.id,p);}
        }
        HashMap<String,Count> tracks=new HashMap<>(),artists=new HashMap<>();long total=0,valid=0;
        for(Count p:plays.values()){
            total+=p.ms;boolean qualified=p.ms>=ListeningClock.qualificationThreshold(p.duration);if(qualified)valid++;
            Count t=tracks.get(p.uri);if(t==null){t=new Count();t.id=t.uri=p.uri;t.title=p.title;t.artist=p.artist;tracks.put(t.uri,t);}t.ms+=p.ms;t.starts++;if(qualified)t.valid++;
            Count a=artists.get(p.artist);if(a==null){a=new Count();a.id=a.title=a.artist=p.artist;a.uri="";artists.put(p.artist,a);}a.ms+=p.ms;a.starts++;if(qualified)a.valid++;
        }
        JSONArray daily=new JSONArray();String bestDay="";long bestMs=0;int streak=0,bestStreak=0;Calendar prev=null;
        for(Map.Entry<String,Long> entry:days.entrySet()) {
            daily.put(new JSONObject().put("date",entry.getKey()).put("ms",entry.getValue()));
            if(entry.getValue()>bestMs){bestMs=entry.getValue();bestDay=entry.getKey();}
            try{Calendar today=Calendar.getInstance();today.setTime(dayFormat.parse(entry.getKey()));if(prev!=null){prev.add(Calendar.DATE,1);streak=dayFormat.format(prev.getTime()).equals(entry.getKey())?streak+1:1;}else streak=1;prev=today;bestStreak=Math.max(bestStreak,streak);}catch(Exception ignored){}
        }
        int bestHour=0;for(int i=1;i<24;i++)if(hours[i]>hours[bestHour])bestHour=i;
        return new JSONObject().put("from",from).put("to",to).put("totalMs",total).put("plays",plays.size()).put("qualifiedPlays",valid)
            .put("uniqueTracks",tracks.size()).put("uniqueArtists",artists.size()).put("days",days.size()).put("topTracks",rank(tracks)).put("topArtists",rank(artists))
            .put("daily",daily).put("hourly",new JSONArray(hours)).put("weekdays",new JSONArray(weekdays)).put("bestDay",bestDay).put("bestDayMs",bestMs).put("bestHour",bestHour).put("streak",bestStreak);
    }
    private JSONArray rank(Map<String,Count> map)throws JSONException {
        ArrayList<Count> sorted=new ArrayList<>(map.values());Collections.sort(sorted,(a,b)->{int result=Long.compare(b.ms,a.ms);return result!=0?result:a.title.compareToIgnoreCase(b.title);});
        JSONArray out=new JSONArray();for(int i=0;i<Math.min(50,sorted.size());i++)out.put(sorted.get(i).json());return out;
    }
    private JSONArray historyNow(long from,long to,int offset) throws JSONException {
        JSONArray out=new JSONArray();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT p.id,p.uri,p.title,p.artist,p.started,p.last,p.listened,p.duration,p.reason FROM plays p WHERE (p.started>=? AND p.started<?) OR EXISTS(SELECT 1 FROM segments s WHERE s.play_id=p.id AND s.start_ms<? AND s.end_ms>?) ORDER BY p.started DESC LIMIT 100 OFFSET ?",new String[]{""+from,""+to,""+to,""+from,""+Math.max(0,offset)})) {
            while(c.moveToNext())out.put(new JSONObject().put("id",c.getString(0)).put("uri",c.getString(1)).put("title",c.getString(2)).put("artist",c.getString(3)).put("started",c.getLong(4)).put("last",c.getLong(5)).put("ms",c.getLong(6)).put("duration",c.getLong(7)).put("reason",c.getString(8)).put("valid",c.getLong(6)>=ListeningClock.qualificationThreshold(c.getLong(7))));
        }return out;
    }
    /** Streaming backup: no years-long JSONArray in RAM. */
    private void exportNow(JsonWriter w) throws IOException {
        SQLiteDatabase db=getReadableDatabase();w.beginObject();
        for(String table:new String[]{"plays","segments"}) {
            w.name(table).beginArray();try(Cursor c=db.rawQuery("SELECT * FROM "+table,null)) {
                while(c.moveToNext()){w.beginObject();for(int i=0;i<c.getColumnCount();i++){w.name(c.getColumnName(i));if(c.getType(i)==Cursor.FIELD_TYPE_INTEGER)w.value(c.getLong(i));else w.value(c.getString(i));}w.endObject();}
            }w.endArray();
        }w.endObject();
    }
    /** Additive/idempotent restore, transactional; does not erase existing history. */
    private void importNow(JsonReader r) throws IOException {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            r.beginObject();while(r.hasNext()) {
                String table=r.nextName();boolean known="plays".equals(table)||"segments".equals(table);if(!known){r.skipValue();continue;}
                Set<String> numeric=new HashSet<>(Arrays.asList("started","last","duration","listened","ended","start_ms","end_ms","listened_ms"));
                Set<String> allowed=new HashSet<>(Arrays.asList("plays".equals(table)?new String[]{"id","uri","title","artist","album","started","last","duration","listened","ended","reason"}:new String[]{"id","play_id","start_ms","end_ms","listened_ms"}));
                r.beginArray();while(r.hasNext()){
                    ContentValues v=new ContentValues();r.beginObject();while(r.hasNext()){String key=r.nextName();if(!allowed.contains(key)){r.skipValue();continue;}if(numeric.contains(key)){long n=r.nextLong();if(n<0)throw new IOException("Histórico inválido.");v.put(key,n);}else{String s=r.nextString();if(s.length()>16384)throw new IOException("Campo muito grande.");v.put(key,s);}}r.endObject();
                    if(!v.containsKey("id")||v.getAsString("id").isEmpty())throw new IOException("Registro sem identificador.");
                    String[] required="plays".equals(table)?new String[]{"uri","title","artist","album","started","last","duration"}:new String[]{"play_id","start_ms","end_ms","listened_ms"};
                    for(String key:required)if(!v.containsKey(key))throw new IOException("Registro incompleto: "+key);
                    if("segments".equals(table)&&(v.getAsLong("end_ms")<v.getAsLong("start_ms")||v.getAsLong("listened_ms")>v.getAsLong("end_ms")-v.getAsLong("start_ms")))throw new IOException("Intervalo de escuta inválido.");
                    String metric="plays".equals(table)?"listened":"listened_ms";long incoming=v.containsKey(metric)?v.getAsLong(metric):0;
                    boolean exists=false;long previous=0;
                    try(Cursor existing=db.query(table,new String[]{metric},"id=?",new String[]{v.getAsString("id")},null,null,null)){if(existing.moveToFirst()){exists=true;previous=existing.getLong(0);}}
                    if(!exists)db.insertOrThrow(table,null,v);
                    else if(incoming>previous)db.update(table,v,"id=?",new String[]{v.getAsString("id")});
                }r.endArray();
            }r.endObject();db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
}
