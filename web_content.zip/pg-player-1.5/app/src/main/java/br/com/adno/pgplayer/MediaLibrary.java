package br.com.adno.pgplayer;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.util.*;

/** User-curated playlists and a video catalog independent of listening history. */
public final class MediaLibrary {
    private static MediaLibrary instance;
    public static synchronized MediaLibrary get(Context c){if(instance==null)instance=new MediaLibrary(c.getApplicationContext());return instance;}
    private final SharedPreferences prefs;
    private MediaLibrary(Context c) { prefs=c.getSharedPreferences("library15",Context.MODE_PRIVATE); }
    public synchronized JSONArray playlists() { return array("playlists"); }
    public synchronized JSONArray videos() { return array("videos"); }
    private JSONArray array(String key) { try {return new JSONArray(prefs.getString(key,"[]"));} catch(Exception e){return new JSONArray();} }
    public synchronized JSONObject savePlaylist(JSONObject input) throws JSONException {
        String name=input.optString("name","").trim();
        if(name.isEmpty() || name.length()>120) throw new JSONException("Use um nome de 1 a 120 caracteres.");
        String id=input.optString("id",""); if(id.isEmpty())id=UUID.randomUUID().toString();
        JSONObject safe=new JSONObject().put("id",id).put("name",name)
            .put("description",input.optString("description","")).put("cover",input.optString("cover",""))
            .put("color",input.optString("color","#ff5265"))
            .put("shuffle",input.optBoolean("shuffle",false)).put("repeat",Math.max(0,Math.min(2,input.optInt("repeat",1))));
        JSONArray uris=new JSONArray(), provided=input.optJSONArray("uris"); HashSet<String> seen=new HashSet<>();
        if(provided!=null)for(int i=0;i<provided.length();i++) {String u=provided.optString(i);if(!u.isEmpty()&&seen.add(u))uris.put(u);}
        safe.put("uris",uris);
        JSONArray result=new JSONArray(); boolean replaced=false; JSONArray old=playlists();
        for(int i=0;i<old.length();i++){JSONObject p=old.getJSONObject(i);if(id.equals(p.optString("id"))){result.put(safe);replaced=true;}else result.put(p);}
        if(!replaced)result.put(safe);
        prefs.edit().putString("playlists",result.toString()).apply(); return safe;
    }
    public synchronized void deletePlaylist(String id) throws JSONException {
        JSONArray out=new JSONArray(),old=playlists();for(int i=0;i<old.length();i++)if(!id.equals(old.getJSONObject(i).optString("id")))out.put(old.get(i));
        prefs.edit().putString("playlists",out.toString()).apply();
    }
    public synchronized void removeTrack(String uri) throws JSONException {
        JSONArray all=playlists();
        for(int i=0;i<all.length();i++){JSONObject p=all.getJSONObject(i);JSONArray in=p.getJSONArray("uris"),out=new JSONArray();for(int n=0;n<in.length();n++)if(!uri.equals(in.optString(n)))out.put(in.get(n));p.put("uris",out);}
        prefs.edit().putString("playlists",all.toString()).apply();
    }
    public synchronized void addVideos(List<Track> items) throws JSONException {
        JSONArray all=videos();HashSet<String> seen=new HashSet<>();for(int i=0;i<all.length();i++)seen.add(all.getJSONObject(i).getString("uri"));
        for(Track t:items)if(seen.add(t.uri))all.put(t.toJson());prefs.edit().putString("videos",all.toString()).apply();
    }
    public synchronized void removeVideo(String uri) throws JSONException {
        JSONArray out=new JSONArray(),all=videos();for(int i=0;i<all.length();i++)if(!uri.equals(all.getJSONObject(i).getString("uri")))out.put(all.get(i));
        prefs.edit().putString("videos",out.toString()).apply();
    }
    public String accent(){return prefs.getString("accent","#ff5265");}
    public void accent(String color){if(color.matches("#[0-9a-fA-F]{6}"))prefs.edit().putString("accent",color).apply();}
    public boolean dynamic(){return prefs.getBoolean("dynamic",false);}
    public void dynamic(boolean b){prefs.edit().putBoolean("dynamic",b).apply();}
    public synchronized JSONObject exportData() throws JSONException {
        return new JSONObject().put("playlists",playlists()).put("videos",videos()).put("accent",accent()).put("dynamic",dynamic());
    }
    public synchronized void mergeData(JSONObject in) throws JSONException {
        JSONArray ps=in.optJSONArray("playlists");if(ps!=null)for(int i=0;i<ps.length();i++)savePlaylist(ps.getJSONObject(i));
        JSONArray vs=in.optJSONArray("videos");ArrayList<Track> videos=new ArrayList<>();if(vs!=null)for(int i=0;i<vs.length();i++)videos.add(Track.fromJson(vs.getJSONObject(i)));addVideos(videos);
        accent(in.optString("accent",accent()));dynamic(in.optBoolean("dynamic",dynamic()));
    }
}
