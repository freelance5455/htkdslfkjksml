package br.com.adno.pgplayer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/** Detects archive bytes rather than trusting the provider's name or MIME type. */
public final class ArchiveImporter {
    public static List<ZipExtractor.ImportedAudio> extract(InputStream source, File destination, File cache, ZipExtractor.Progress progress) throws IOException {
        BufferedInputStream input = new BufferedInputStream(source);
        input.mark(16);
        byte[] magic = new byte[8];
        int read = 0;
        while (read < magic.length) {
            int n = input.read(magic, read, magic.length - read);
            if (n < 0) break;
            read += n;
        }
        input.reset();
        if (read >= 4 && magic[0] == 'P' && magic[1] == 'K')
            return ZipExtractor.extract(input, destination, progress);
        if (read < 4 || magic[0] != 'R' || magic[1] != 'a' || magic[2] != 'r' || magic[3] != '!')
            throw new IOException("Escolha um arquivo ZIP ou RAR válido.");

        if (!cache.isDirectory() && !cache.mkdirs()) throw new IOException("Não foi possível preparar a importação.");
        File staging = File.createTempFile("pg-import-", ".rar", cache);
        try {
            long limit = Math.min(5L * 1024 * 1024 * 1024, cache.getUsableSpace() - 100L * 1024 * 1024);
            long copied = 0;
            byte[] bytes = new byte[65536];
            try (FileOutputStream output = new FileOutputStream(staging)) {
                int n;
                while ((n = input.read(bytes)) != -1) {
                    if (progress.cancelled() || Thread.currentThread().isInterrupted()) throw new IOException("Importação cancelada.");
                    copied += n;
                    if (copied > limit) throw new IOException("Libere espaço no celular ou divida o RAR em arquivos menores.");
                    output.write(bytes, 0, n);
                }
            }
            return RarExtractor.extract(staging, destination, progress);
        } finally { staging.delete(); }
    }
    private ArchiveImporter() {}
}
