package br.com.adno.pgplayer;
import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.graphics.*;
import java.io.*;
import java.security.MessageDigest;

public final class MetadataReader {
    public static String key(String uri) {
        try {byte[] hash=MessageDigest.getInstance("SHA-256").digest(uri.getBytes("UTF-8"));StringBuilder b=new StringBuilder();for(byte v:hash)b.append(String.format(java.util.Locale.US,"%02x",v&255));return b.toString();}
        catch(Exception e){throw new IllegalStateException(e);}
    }
    public static Track read(Context c,Track old,boolean video) {
        MediaMetadataRetriever r=new MediaMetadataRetriever();
        try {
            r.setDataSource(c,Uri.parse(old.uri));
            String title=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),artist=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),album=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            long duration=0;try{duration=Long.parseLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));}catch(Exception ignored){}
            String art=""; Bitmap bitmap=null;
            byte[] bytes=r.getEmbeddedPicture();
            if(bytes!=null && bytes.length<16000000) {
                BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);
                opts.inSampleSize=Math.max(1,Math.max(opts.outWidth,opts.outHeight)/640);opts.inJustDecodeBounds=false;
                bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);
            }
            if(video && bitmap==null && android.os.Build.VERSION.SDK_INT>=27)
                try{bitmap=r.getScaledFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,480,270);}catch(RuntimeException ignored){}
            // API 26 keeps the neutral video thumbnail instead of decoding a full-resolution frame.
            if(bitmap!=null) {
                File dir=new File(c.getFilesDir(),"art");dir.mkdirs(); art=key(old.uri)+".jpg";
                try(OutputStream out=new FileOutputStream(new File(dir,art))){bitmap.compress(Bitmap.CompressFormat.JPEG,85,out);}finally{bitmap.recycle();}
            }
            return new Track(old.uri,blank(title)?old.title:title,blank(artist)?old.artist:artist,blank(album)?old.album:album,art,duration,old.favorite);
        }catch(Exception ignored){return old;}finally{try{r.release();}catch(Exception ignored){}}
    }
    private static boolean blank(String s){return s==null||s.trim().isEmpty();}
}
