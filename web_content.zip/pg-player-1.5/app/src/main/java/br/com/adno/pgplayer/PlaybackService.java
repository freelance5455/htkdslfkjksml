package br.com.adno.pgplayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.audiofx.LoudnessEnhancer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.HashMap;
import java.util.HashSet;

/** Owns playback independently of the activity, including when its task is dismissed. */
public final class PlaybackService extends Service {
    private static final String TAG = "PGPlayer";
    private static final String CHANNEL = "playback";
    private static final int NOTIFICATION_ID = 41;
    public static final String ACTION_TOGGLE = "br.com.adno.pgplayer.TOGGLE";
    public static final String ACTION_NEXT = "br.com.adno.pgplayer.NEXT";
    public static final String ACTION_PREVIOUS = "br.com.adno.pgplayer.PREVIOUS";
    public static final String ACTION_STOP = "br.com.adno.pgplayer.STOP";
    public static final String ACTION_PLAY = "br.com.adno.pgplayer.PLAY";

    public interface Listener { void onPlayerChanged(); }
    public final class LocalBinder extends Binder {
        public PlaybackService getService() { return PlaybackService.this; }
    }

    private final LocalBinder binder = new LocalBinder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<Track> tracks = new ArrayList<>();
    private final ArrayList<Listener> listeners = new ArrayList<>();
    private final Random random = new Random();
    private MediaPlayer player;
    private MediaSession session;
    private LoudnessEnhancer enhancer;
    private AudioManager audio;
    private AudioFocusRequest focusRequest;
    private SharedPreferences prefs;
    private final QueueEngine queue = new QueueEngine();
    private final ListeningClock listeningClock = new ListeningClock();
    private HistoryStore history;
    private String playId;
    private boolean tracking, seeking;
    private boolean tracksDirty, queueDirty;
    private int libraryRevision=1;
    private Bitmap albumArt;
    private int index = -1;
    private int savedPosition;
    private int boostDb;
    private int repeatMode = 1; // 0: off, 1: playlist, 2: track
    private boolean shuffle;
    private boolean shuffleInitialized;
    private final ArrayList<Integer> shuffleRemaining = new ArrayList<>();
    private boolean prepared;
    private boolean preparing;
    private boolean playWhenReady;
    private boolean foreground;
    private boolean hasFocus;
    private boolean resumeAfterFocus;
    private boolean ducked;
    private boolean effectSupported = true;
    private String error;

    private final Runnable checkpoint = new Runnable() {
        @Override public void run() {
            if (player != null && prepared) {
                captureListening(false);
                savedPosition = getPosition();
                saveState();
            }
            if (foreground) handler.postDelayed(this, 5000);
        }
    };

    private final BroadcastReceiver noisyReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())) pause();
        }
    };

    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (change == AudioManager.AUDIOFOCUS_GAIN) {
            hasFocus = true;
            ducked = false;
            applyPlayerVolume();
            if (resumeAfterFocus) {
                resumeAfterFocus = false;
                play();
            }
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            ducked = true;
            applyPlayerVolume();
        } else {
            boolean shouldResume = change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT
                    && (isPlaying() || playWhenReady);
            pauseInternal(false, shouldResume);
            hasFocus = false;
            resumeAfterFocus = shouldResume;
            if (change == AudioManager.AUDIOFOCUS_LOSS) abandonFocus();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("player", MODE_PRIVATE);
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        history = HistoryStore.get(this);
        restoreState();
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Reprodução de música", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Controles para música em segundo plano");
        channel.setSound(null, null);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);

        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attributes).setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener(focusListener, handler).build();

        albumArt = createAlbumArt();
        session = new MediaSession(this, "PG Player");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setSessionActivity(activityIntent());
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { play(); }
            @Override public void onPause() { pause(); }
            @Override public void onStop() { stopPlayback(); }
            @Override public void onSkipToNext() { next(false); }
            @Override public void onSkipToPrevious() { previous(); }
            @Override public void onSeekTo(long pos) { seek((int) Math.min(Integer.MAX_VALUE, pos)); }
        }, handler);
        IntentFilter filter = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(noisyReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(noisyReceiver, filter);
        updateSession();
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_STOP.equals(action)) stopPlayback();
            else if (ACTION_NEXT.equals(action)) next(false);
            else if (ACTION_PREVIOUS.equals(action)) previous();
            else if (ACTION_PLAY.equals(action)) play();
            else if (ACTION_TOGGLE.equals(action)) toggle();
        }
        // Process recreation restores the list and position without unexpected auto-play.
        return START_NOT_STICKY;
    }

    public void addListener(Listener listener) {
        if (!listeners.contains(listener)) listeners.add(listener);
    }
    public void removeListener(Listener listener) { listeners.remove(listener); }
    public List<Track> getTracks() { return new ArrayList<>(tracks); }
    public int getIndex() { return index; }
    public int getLibraryRevision() { return libraryRevision; }
    public QueueEngine getQueue() { return queue; }
    public Track findTrack(String uri) { for(Track t:tracks) if(t.uri.equals(uri))return t;return null; }
    public void enqueue(String uri) { if(findTrack(uri)!=null){queue.enqueue(uri);queueDirty=true;saveState();changed();} }
    public void moveQueue(int from,int to){queue.move(from,to);queueDirty=true;saveState();changed();}
    public void removeQueued(int n){if(n>=0 && n<queue.pending.size()){queue.pending.remove(n);queueDirty=true;saveState();changed();}}
    public void clearQueue(){queue.pending.clear();queueDirty=true;saveState();changed();}
    public void setFavorite(String uri,boolean value){for(int n=0;n<tracks.size();n++)if(tracks.get(n).uri.equals(uri)){tracks.set(n,tracks.get(n).favorite(value));tracksDirty=true;libraryRevision++;saveState();changed();return;}}
    public void updateMetadata(Track track){for(int n=0;n<tracks.size();n++)if(tracks.get(n).uri.equals(track.uri)){tracks.set(n,track.favorite(tracks.get(n).favorite));tracksDirty=true;libraryRevision++;saveState();changed();return;}}
    public void updateMetadataBatch(List<Track> updated){
        HashMap<String,Track> incoming=new HashMap<>();for(Track t:updated)incoming.put(t.uri,t);
        for(int n=0;n<tracks.size();n++){Track old=tracks.get(n),fresh=incoming.get(old.uri);if(fresh!=null)tracks.set(n,fresh.favorite(old.favorite));}
        tracksDirty=true;libraryRevision++;saveState();changed();
    }
    public void setModes(boolean shuffled,int repeat){shuffle=shuffled;repeatMode=Math.max(0,Math.min(2,repeat));queue.shuffle=shuffle;queue.repeat=repeatMode;queue.resetBag();queueDirty=true;saveState();changed();}
    public void selectContext(List<String> uris,String selected){
        HashSet<String> known=new HashSet<>();for(Track t:tracks)known.add(t.uri);
        ArrayList<String> valid=new ArrayList<>();for(String uri:uris)if(known.contains(uri))valid.add(uri);
        if(!valid.contains(selected)||findTrack(selected)==null)return;
        queue.setContext(valid,selected);queueDirty=true;switchTo(selected,true);
    }
    private void switchTo(String uri,boolean start){
        Track t=findTrack(uri);if(t==null)return;
        releasePlayer(); index=tracks.indexOf(t); savedPosition=0;error=null;queueDirty=true;saveState();
        if(start)play();else changed();
    }
    private void beginListening(){
        if(!prepared||player==null||seeking)return;
        if(playId==null && getCurrentTrack()!=null)playId=history.start(getCurrentTrack(),getDuration(),System.currentTimeMillis());
        listeningClock.reset(SystemClock.elapsedRealtime(),getPosition());tracking=true;
    }
    private void captureListening(boolean completed){
        if(!tracking||playId==null)return;
        int pos=completed?Math.max(getPosition(),getDuration()):getPosition();
        long ms=listeningClock.sample(SystemClock.elapsedRealtime(),pos);
        if(ms>0)history.append(playId,System.currentTimeMillis(),ms);
    }
    private void freezeListening(){captureListening(false);tracking=false;listeningClock.clear();}
    private void endListening(String reason,boolean completed){
        captureListening(completed);if(playId!=null)history.finish(playId,System.currentTimeMillis(),reason);
        playId=null;tracking=false;listeningClock.clear();
    }
    public void flushHistory(){captureListening(false);}

    public Track getCurrentTrack() { return index >= 0 && index < tracks.size() ? tracks.get(index) : null; }
    public int getBoostDb() { return boostDb; }
    public int getRepeatMode() { return repeatMode; }
    public boolean isShuffle() { return shuffle; }
    public boolean isPreparing() { return preparing; }
    public boolean isEffectSupported() { return effectSupported; }
    public String getError() { return error; }

    public boolean isPlaying() {
        try { return prepared && player != null && player.isPlaying(); }
        catch (IllegalStateException e) { return false; }
    }
    public int getDuration() {
        try { return prepared && player != null ? player.getDuration() : 0; }
        catch (IllegalStateException e) { return 0; }
    }
    public int getPosition() {
        try { return prepared && player != null ? player.getCurrentPosition() : savedPosition; }
        catch (IllegalStateException e) { return savedPosition; }
    }

    public void addTracks(List<Track> incoming) {
        HashSet<String> known=new HashSet<>();for(Track t:tracks)known.add(t.uri);
        for (Track track : incoming) {
            if (known.add(track.uri)) {tracks.add(track);tracksDirty=true;libraryRevision++;}
        }
        if (index < 0 && !tracks.isEmpty()) index = 0;
        if(queue.context.isEmpty()){ArrayList<String> all=new ArrayList<>();for(Track t:tracks)all.add(t.uri);queue.setContext(all,getCurrentTrack()==null?"":getCurrentTrack().uri);queueDirty=true;}
        resetShuffle();
        error = null;
        saveState();
        changed();
    }

    public void removeTrack(int removeIndex) {
        if (removeIndex < 0 || removeIndex >= tracks.size()) return;
        boolean wasCurrent = removeIndex == index;
        boolean continuePlaying = isPlaying() || playWhenReady;
        if (wasCurrent) releasePlayer();
        Track removed = tracks.remove(removeIndex);
        queue.remove(removed.uri);queueDirty=true;tracksDirty=true;libraryRevision++;
        try{MediaLibrary.get(this).removeTrack(removed.uri);}catch(Exception ignored){}
        releaseImportedCopy(removed);
        resetShuffle();
        if (tracks.isEmpty()) {
            index = -1;
            stopPlayback();
        } else {
            if (removeIndex < index) index--;
            else if (index >= tracks.size()) index = 0;
            if (wasCurrent) {
                savedPosition = 0;
                if (continuePlaying) play();
                else demoteForeground();
            }
        }
        saveState();
        changed();
    }

    public void select(int trackIndex) {
        if(trackIndex<0||trackIndex>=tracks.size())return;
        ArrayList<String> all=new ArrayList<>();for(Track t:tracks)all.add(t.uri);
        selectContext(all,tracks.get(trackIndex).uri);
    }

    public void toggle() {
        if (isPlaying() || (preparing && playWhenReady)) pause();
        else play();
    }

    public void play() {
        if (tracks.isEmpty()) {
            showError("Adicione um MP3 para começar.");
            demoteForeground();
            stopSelf();
            return;
        }
        if (index < 0 || index >= tracks.size()) index = 0;
        resumeAfterFocus = false;
        error = null;
        // Start and promote before requesting focus (required for background on API 35+).
        startService(new Intent(this, PlaybackService.class));
        promoteForeground();
        if (!requestFocus()) {
            showError("Não foi possível iniciar o áudio agora. Tente novamente.");
            demoteForeground();
            stopSelf();
            return;
        }
        playWhenReady = true;
        session.setActive(true);
        if (preparing) { changed(); return; }
        if (prepared && player != null) {
            try {
                player.start();
                beginListening();
                applyPlayerVolume();
                handler.removeCallbacks(checkpoint);
                handler.post(checkpoint);
                changed();
            } catch (RuntimeException e) { fail("Não foi possível reproduzir este arquivo.", e); }
            return;
        }
        prepareCurrent();
    }

    private void prepareCurrent() {
        releasePlayer();
        preparing = true;
        playWhenReady = true;
        final MediaPlayer pending = new MediaPlayer();
        player = pending;
        try {
            pending.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            pending.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            pending.setDataSource(this, Uri.parse(tracks.get(index).uri));
            pending.setOnPreparedListener(mp -> {
                if (player != mp) return;
                preparing = false;
                prepared = true;
                attachEnhancer(mp.getAudioSessionId());
                if (savedPosition > 0) {seeking=true;mp.seekTo(Math.min(savedPosition, Math.max(0, mp.getDuration() - 1)));}
                applyPlayerVolume();
                if (playWhenReady && hasFocus) {
                    mp.start();
                    beginListening();
                    handler.removeCallbacks(checkpoint);
                    handler.post(checkpoint);
                }
                changed();
            });
            pending.setOnSeekCompleteListener(mp -> {if(player!=mp)return;seeking=false;if(isPlaying())beginListening();});
            pending.setOnCompletionListener(mp -> {
                if (player != mp) return;
                endListening("concluída",true);
                next(true);
            });
            pending.setOnErrorListener((mp, what, extra) -> {
                if (player == mp) fail("Este arquivo não pôde ser aberto. Adicione o MP3 novamente.", null);
                return true;
            });
            pending.prepareAsync();
            changed();
        } catch (Exception e) {
            fail("Não foi possível abrir o arquivo. Adicione o MP3 novamente.", e);
        }
    }

    public void pause() { pauseInternal(true, false); }

    private void pauseInternal(boolean releaseFocus, boolean retainForeground) {
        freezeListening();
        resumeAfterFocus = false;
        playWhenReady = false;
        if (isPlaying()) {
            savedPosition = getPosition();
            player.pause();
        }
        handler.removeCallbacks(checkpoint);
        saveState();
        if (releaseFocus) abandonFocus();
        if (!retainForeground) { demoteForeground(); stopSelf(); }
        changed();
    }

    public void stopPlayback() {
        endListening("parada",false);
        playWhenReady = false;
        resumeAfterFocus = false;
        releasePlayer();
        savedPosition = 0;
        error = null;
        abandonFocus();
        handler.removeCallbacks(checkpoint);
        demoteForeground();
        session.setActive(false);
        getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);
        saveState();
        stopSelf();
        changed(false);
    }

    public void next(boolean automatic) {
        if(tracks.isEmpty()){stopPlayback();return;}
        queue.shuffle=shuffle;queue.repeat=repeatMode;
        String next=queue.next(automatic,getCurrentTrack()==null?null:getCurrentTrack().uri);
        queueDirty=true;
        if(next==null){stopPlayback();return;}
        boolean start=automatic||isPlaying()||playWhenReady;
        switchTo(next,start);
    }
    public void previous() {
        if(tracks.isEmpty())return;
        if(getPosition()>3000 && prepared){seek(0);return;}
        String previous=queue.previous();queueDirty=true;
        if(previous!=null)switchTo(previous,isPlaying()||playWhenReady);
    }

    public void seek(int position) {
        freezeListening();
        savedPosition = Math.max(0, position);
        if (prepared && player != null) {
            savedPosition = Math.min(savedPosition, Math.max(0, getDuration() - 1));
            seeking=true;
            player.seekTo(savedPosition);
        }
        saveState();
        changed();
    }

    public void setBoostDb(int db) {
        boostDb = Math.max(0, Math.min(12, db));
        applyBoost();
        saveState();
        changed();
    }

    public void cycleRepeat() { repeatMode = (repeatMode + 1) % 3; queue.repeat=repeatMode;saveState(); changed(); }
    public void toggleShuffle() { shuffle = !shuffle; resetShuffle(); saveState(); changed(); }
    private void resetShuffle() { shuffleRemaining.clear(); shuffleInitialized = false; queue.shuffle=shuffle;queue.repeat=repeatMode;queue.resetBag();queueDirty=true; }

    private boolean requestFocus() {
        if (hasFocus) return true;
        hasFocus = audio.requestAudioFocus(focusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        return hasFocus;
    }
    private void abandonFocus() {
        audio.abandonAudioFocusRequest(focusRequest);
        hasFocus = false;
        ducked = false;
    }
    private void applyPlayerVolume() {
        if (player != null && prepared) {
            float volume = ducked ? 0.2f : 1f;
            player.setVolume(volume, volume);
            // Do not let amplification undo ducking for voice prompts.
            applyBoost();
        }
    }
    private void attachEnhancer(int audioSession) {
        releaseEnhancer();
        try {
            enhancer = new LoudnessEnhancer(audioSession);
            effectSupported = true;
            applyBoost();
        } catch (RuntimeException e) {
            effectSupported = false;
            Log.i(TAG, "Amplification is unavailable on this audio route.");
        }
    }
    private void applyBoost() {
        if (enhancer != null) {
            try {
                enhancer.setTargetGain(boostDb * 100);
                enhancer.setEnabled(boostDb > 0 && !ducked);
            } catch (RuntimeException e) {
                effectSupported = false;
                releaseEnhancer();
            }
        }
    }
    private void releaseEnhancer() {
        if (enhancer != null) { try { enhancer.release(); } catch (RuntimeException ignored) {} enhancer = null; }
    }
    private void releasePlayer() {
        endListening("trocada",false);
        seeking=false;
        releaseEnhancer();
        if (player != null) { player.reset(); player.release(); player = null; }
        prepared = false;
        preparing = false;
        playWhenReady = false;
    }

    private void releaseImportedCopy(Track track) {
        Uri uri = Uri.parse(track.uri);
        if ("file".equals(uri.getScheme())) {
            try {
                File importedRoot = new File(getFilesDir(), "imported");
                File file = new File(uri.getPath());
                if (file.getCanonicalPath().startsWith(importedRoot.getCanonicalPath() + File.separator)) {
                    file.delete();
                    File parent = file.getParentFile();
                    String[] remaining = parent.list();
                    if (remaining != null && remaining.length == 0) parent.delete();
                }
            } catch (Exception ignored) {}
        } else if ("content".equals(uri.getScheme())) {
            try { getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (SecurityException ignored) {}
        }
    }

    private void promoteForeground() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NOTIFICATION_ID, notification);
        foreground = true;
    }
    private void demoteForeground() {
        if (foreground) { stopForeground(STOP_FOREGROUND_DETACH); foreground = false; }
    }

    private PendingIntent activityIntent() {
        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private PendingIntent actionIntent(String action, int code) {
        Intent intent = new Intent(this, PlaybackService.class).setAction(action);
        // Actions can be sent from the notification with the activity closed.
        if (ACTION_PLAY.equals(action) || ACTION_TOGGLE.equals(action))
            return PendingIntent.getForegroundService(this, code, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return PendingIntent.getService(this, code, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildNotification() {
        Track track = getCurrentTrack();
        boolean playing = isPlaying() || (preparing && playWhenReady);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_music)
                .setLargeIcon(albumArt)
                .setContentTitle(track == null ? "PG Player" : track.title)
                .setContentText(preparing ? "Preparando áudio…" : playing ? "Tocando em segundo plano" : "Pausado")
                .setContentIntent(activityIntent())
                .setDeleteIntent(actionIntent(ACTION_STOP, 5))
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setOngoing(playing)
                .addAction(new Notification.Action.Builder(R.drawable.ic_previous, "Anterior", actionIntent(ACTION_PREVIOUS, 1)).build())
                .addAction(new Notification.Action.Builder(playing ? R.drawable.ic_pause : R.drawable.ic_play,
                        playing ? "Pausar" : "Reproduzir", actionIntent(ACTION_TOGGLE, 2)).build())
                .addAction(new Notification.Action.Builder(R.drawable.ic_next, "Próxima", actionIntent(ACTION_NEXT, 3)).build())
                .addAction(new Notification.Action.Builder(R.drawable.ic_stop, "Parar", actionIntent(ACTION_STOP, 4)).build())
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2))
                .build();
    }

    private void updateSession() {
        Track track = getCurrentTrack();
        if (track != null) session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, track.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, track.artist)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, getDuration())
                .putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, albumArt).build());
        else session.setMetadata(null);
        int state = preparing ? PlaybackState.STATE_BUFFERING : isPlaying() ? PlaybackState.STATE_PLAYING
                : track != null ? PlaybackState.STATE_PAUSED : PlaybackState.STATE_STOPPED;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                        | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP)
                .setState(state, getPosition(), isPlaying() ? 1f : 0f, SystemClock.elapsedRealtime()).build());
    }

    private void changed() { changed(true); }
    private void changed(boolean notification) {
        updateSession();
        if (notification && (foreground || session.isActive()))
            getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, buildNotification());
        for (Listener listener : new ArrayList<>(listeners)) listener.onPlayerChanged();
    }

    private void showError(String message) {
        error = message;
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        changed();
    }
    private void fail(String message, Exception exception) {
        if (exception != null) Log.w(TAG, "Playback failed", exception);
        releasePlayer();
        abandonFocus();
        demoteForeground();
        handler.removeCallbacks(checkpoint);
        session.setActive(false);
        getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);
        stopSelf();
        showError(message);
    }

    private void restoreState() {
        try {
            JSONArray array = new JSONArray(prefs.getString("tracks", "[]"));
            for (int n = 0; n < array.length(); n++) tracks.add(Track.fromJson(array.getJSONObject(n)));
        } catch (Exception e) { Log.w(TAG, "Could not restore the playlist", e); }
        index = tracks.isEmpty() ? -1 : Math.max(0, Math.min(tracks.size() - 1, prefs.getInt("index", 0)));
        savedPosition = prefs.getInt("position", 0);
        boostDb = Math.max(0, Math.min(12, prefs.getInt("boost", 0)));
        shuffle = prefs.getBoolean("shuffle", false);
        repeatMode = Math.max(0,Math.min(2,prefs.getInt("repeat", 1)));
        queue.shuffle=shuffle;queue.repeat=repeatMode;
        try{
            JSONArray context=new JSONArray(prefs.getString("context15","[]"));
            for(int n=0;n<context.length();n++)if(findTrack(context.optString(n))!=null)queue.context.add(context.optString(n));
            if(queue.context.isEmpty())for(Track t:tracks)queue.context.add(t.uri);
            queue.cursor=Math.max(-1,Math.min(queue.context.size()-1,prefs.getInt("cursor15",queue.context.indexOf(getCurrentTrack()==null?"":getCurrentTrack().uri))));
            JSONArray pending=new JSONArray(prefs.getString("queue15","[]"));for(int n=0;n<pending.length();n++)if(findTrack(pending.optString(n))!=null)queue.pending.add(pending.optString(n));
        }catch(Exception e){Log.w(TAG,"Fila não restaurada",e);}

    }
    private void saveState() {
        try {
            SharedPreferences.Editor edit=prefs.edit().putInt("index",index).putInt("position",savedPosition).putInt("boost",boostDb)
                .putBoolean("shuffle",shuffle).putInt("repeat",repeatMode);
            if(tracksDirty){JSONArray array=new JSONArray();for(Track t:tracks)array.put(t.toJson());edit.putString("tracks",array.toString());tracksDirty=false;}
            if(queueDirty){edit.putString("queue15",new JSONArray(queue.pending).toString()).putString("context15",new JSONArray(queue.context).toString()).putInt("cursor15",queue.cursor);queueDirty=false;}
            edit.apply();
        }catch(Exception e){Log.w(TAG,"Could not store player state",e);}
    }

    private Bitmap createAlbumArt() {
        Bitmap bitmap = Bitmap.createBitmap(320, 320, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.rgb(25, 25, 40));
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(255, 82, 101));
        canvas.drawCircle(160, 160, 116, paint);
        paint.setColor(Color.rgb(40, 22, 28));
        canvas.drawCircle(160, 160, 87, paint);
        paint.setColor(Color.rgb(255, 82, 101));
        paint.setTextSize(64);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("PG", 160, 184, paint);
        return bitmap;
    }

    @Override protected void dump(FileDescriptor fd, PrintWriter writer, String[] args) {
        writer.println("PG Player playback diagnostics");
        writer.println("playing=" + isPlaying() + " preparing=" + preparing + " foreground=" + foreground);
        writer.println("positionMs=" + getPosition() + " durationMs=" + getDuration());
        writer.println("trackIndex=" + index + " trackCount=" + tracks.size());
        writer.println("boostDb=" + boostDb + " effectSupported=" + effectSupported);
        if (enhancer != null) {
            try { writer.println("effectEnabled=" + enhancer.getEnabled() + " targetGainMb=" + enhancer.getTargetGain()); }
            catch (RuntimeException ignored) {}
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        if (!isPlaying() && !preparing) stopSelf();
        super.onTaskRemoved(rootIntent);
    }
    @Override public void onDestroy() {
        endListening("encerrada",false);
        savedPosition = getPosition();
        saveState();
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        abandonFocus();
        session.setActive(false);
        session.release();
        unregisterReceiver(noisyReceiver);
        listeners.clear();
        super.onDestroy();
    }
}
