package br.com.adno.pgplayer;
import java.util.*;

/** No Android dependencies: the explicit queue never mutates a playlist. */
public final class QueueEngine {
    public final ArrayList<String> context = new ArrayList<>();
    public final ArrayList<String> pending = new ArrayList<>();
    private final ArrayList<String> bag = new ArrayList<>();
    public int cursor=-1;
    public boolean shuffle;
    public int repeat=1;
    private boolean bagReady;
    private final Random random;
    public QueueEngine() { this(new Random()); }
    public QueueEngine(Random random) { this.random=random; }
    public void setContext(List<String> uris, String selected) {
        context.clear(); context.addAll(uris); cursor=context.indexOf(selected); resetBag();
    }
    public void resetBag() { bag.clear(); bagReady=false; }
    public void enqueue(String uri) { if(uri!=null && !uri.isEmpty()) pending.add(uri); }
    public void move(int from,int to) {
        if(from<0||to<0||from>=pending.size()||to>=pending.size()) return;
        pending.add(to,pending.remove(from));
    }
    public void remove(String uri) {
        pending.removeAll(Collections.singleton(uri));
        for(int i=context.size()-1;i>=0;i--) if(context.get(i).equals(uri)) {
            context.remove(i); if(i<=cursor) cursor--;
        }
        resetBag();
    }
    public String next(boolean automatic,String current) {
        if(!pending.isEmpty()) return pending.remove(0);
        if(context.isEmpty()) return null;
        if(automatic && repeat==2 && current!=null) return current;
        if(shuffle) {
            if(!bagReady || bag.isEmpty()) {
                if(bagReady && automatic && repeat==0) return null;
                bag.clear(); bag.addAll(context); bag.remove(current); bagReady=true;
                if(bag.isEmpty()) return automatic && repeat==0 ? null : context.get(0);
            }
            String next=bag.remove(random.nextInt(bag.size())); cursor=context.indexOf(next); return next;
        }
        int next=cursor+1;
        if(next>=context.size()) { if(automatic && repeat==0) return null; next=0; }
        cursor=next; return context.get(cursor);
    }
    public String previous() {
        if(context.isEmpty()) return null;
        cursor=(cursor-1+context.size())%context.size(); resetBag(); return context.get(cursor);
    }
}
