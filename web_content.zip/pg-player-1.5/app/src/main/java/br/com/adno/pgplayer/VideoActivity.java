package br.com.adno.pgplayer;
import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
/** Intentionally simple. Video never uses PlaybackService or HistoryStore. */
public final class VideoActivity extends Activity {
    private VideoView video;private int position;private boolean resume=true;
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if(state!=null){position=state.getInt("position");resume=state.getBoolean("playing",true);}
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);setContentView(root);
        video=new VideoView(this);FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);root.addView(video,p);
        MediaController controls=new MediaController(this);controls.setAnchorView(video);video.setMediaController(controls);
        video.setOnPreparedListener(mp->{if(position>0)video.seekTo(position);if(resume)video.start();});
        video.setOnErrorListener((mp,what,extra)->{new AlertDialog.Builder(this).setTitle("Não foi possível abrir o vídeo").setMessage("Confira se o arquivo ainda existe e se o formato de áudio e vídeo é suportado pelo aparelho.").setPositiveButton("Voltar",(d,w)->finish()).show();return true;});
        video.setVideoURI(getIntent().getData());
        TextView back=new TextView(this);back.setText("‹  Voltar");back.setTextColor(Color.WHITE);back.setTextSize(17);back.setPadding(24,20,24,20);back.setBackgroundColor(0x77000000);root.addView(back,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.START));back.setOnClickListener(v->finish());
    }
    @Override protected void onPause(){position=video.getCurrentPosition();resume=video.isPlaying();video.pause();super.onPause();}
    @Override protected void onResume(){super.onResume();if(video!=null&&resume&&position>0){video.seekTo(position);video.start();}}
    @Override public void onSaveInstanceState(Bundle out){out.putInt("position",video.getCurrentPosition());out.putBoolean("playing",video.isPlaying());super.onSaveInstanceState(out);}
    @Override protected void onDestroy(){video.stopPlayback();super.onDestroy();}
}
