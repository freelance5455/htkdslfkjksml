# PG Player 1.5

**Entrega de desenvolvimento: código Android + interface + testes + prévia interativa. Não contém um APK 1.5 compilado.**

O projeto foi atualizado a partir do ZIP editável real do PG Player 1.1 fornecido na biblioteca do usuário. O identificador `br.com.adno.pgplayer` foi mantido. O manifesto declara versão `1.5`, código `15`, Android mínimo API 26 e alvo API 36. A atualização instalada sobre a versão 1.1 ainda precisa ser compilada e testada.

## O que foi implementado no código

| Área | Implementação |
| --- | --- |
| Biblioteca local | Seleção múltipla de áudios, importação ZIP/RAR herdada, metadados e capas incorporadas, busca por título/artista/álbum, favoritos e ordenação. Sem baixar músicas da internet. |
| Playlists manuais | Criar, renomear, descrição, capa própria ou cor, selecionar músicas, remover e reorganizar, modos de repetição e aleatório por playlist. |
| Fila independente | Deslizar a música para a direita para adicionar; arrastar pela alça; alternativa por botões; remover; manter a fila e o contexto nos dados locais. Não reordena a playlist original. |
| Cápsula Sonora | Um registro por início de reprodução, tempo efetivamente avançado, repetições, escutas interrompidas, filtros de dia/semana/mês/ano/intervalo inclusivo, calendário e diário paginado. |
| Estatísticas | Tempo, reproduções iniciadas e qualificadas, faixas/artistas distintos, rankings por tempo, distribuição por hora, dia recordista, sequência de dias e média por dia ativo. |
| Compartilhamento | Cartão PNG vertical 1080×1920 ou quadrado 1080×1080, cores e seleção de informações, compartilhamento pelo Android. |
| MP4 | Catálogo separado e reprodução básica de vídeos, controles nativos e tela cheia. Não alimenta a Cápsula Sonora. |
| Interface | Início, Biblioteca, Cápsula e Vídeos; tema escuro, cinco cores de destaque, opção de cor extraída da capa, miniplayer e reprodutor ampliado. |
| Segurança dos dados | Banco SQLite local, histórico sem limpeza automática, exportação/restauração explícita de metadados e histórico. |

As playlists são criadas pelo usuário. Não foram incluídas recomendações automáticas nem playlists inteligentes como uma exigência supostamente aprovada. Equalizador novo, letras, modo DJ, crossfade e widget também não fazem parte desta implementação.

## Arquivos principais

- `app/src/main/java/br/com/adno/pgplayer/`: player e serviços Android, fila, relógio de escuta, SQLite, importação e compartilhamento.
- `app/src/main/assets/ui/`: interface local HTML/CSS/JavaScript usada pelo WebView do Android. O áudio não é tocado pelo navegador.
- `PREVIA.html`: a mesma apresentação, com um adaptador de demonstração. **Dados fictícios, sem reprodução de áudio, sem importação nativa. Não substitui o APK.**
- `build.py`, `build.sh`, `build.cmd`: compilação local com o SDK, sem depender de Gradle e sem downloads escondidos.
- `tests/`: testes executáveis e verificações de contrato.
- `docs/`: instruções, limitações, evidências e roteiro para o teste Android.
- `libs/`: dependências e licenças preservadas do projeto original.

## Situação real da verificação

Foram executadas **56 asserções JVM** sobre as classes reais de fila e contagem, **35 verificações da interface no Chromium** e **21 verificações de contratos SQLite/manifesto/código**. A sintaxe dos 14 arquivos Java foi analisada. O JavaScript passou por `node --check`.

**Isso não comprova a compilação Android.** A análise Java feita aqui verifica sintaxe, não a resolução dos tipos/APIs do Android. A interface foi renderizada com dados demonstrativos e com uma ponte nativa substituta para testes, não em um APK.

A tentativa de build parou porque o ambiente não contém Android SDK, `android.jar`, `aapt2`, `d8` e `apksigner`. As tentativas de obter o SDK não foram concluídas. Não havia emulador nem aparelho ADB disponível. **Não há garantia de ausência de erros de compilação ou integração até executar o build e os testes Android.**

Os resultados e o comando que falhou estão em `docs/evidencias/`. Nenhum APK antigo foi renomeado para 1.5.

## Compilar

No Windows, instale os requisitos descritos em `docs/COMPILAR.md` e execute `build.cmd`. No Linux/macOS, execute `./build.sh`. A saída esperada de uma compilação bem-sucedida será `dist/PG-Player-1.5.apk`, com verificação de assinatura e SHA-256.

**Pacote privado:** `signing/pg-player.jks` é a chave encontrada no projeto original 1.1, preservada para a continuidade da assinatura. Não publique este ZIP inteiro, a pasta `signing` nem suas senhas. O `.gitignore` protege o fluxo usual de Git, mas não protege upload manual de arquivos ZIP. Leia `signing/LEIA-ME.txt`.

## Antes de instalar a atualização

Não desinstale o PG Player 1.1 para tentar corrigir uma instalação que falhou: isso pode remover os dados privados do aplicativo. Compile com a mesma chave, confira o certificado e teste a atualização. A leitura dos nomes de preferências antigos foi mantida no código; a migração real ainda não foi validada em aparelho.

A Cápsula começa a registrar após o uso da nova implementação. Ela não consegue reconstruir escutas que a versão anterior nunca registrou. Não registra outros aplicativos.

## Regras da escuta e do backup

Cada música iniciada, troca ou repetição automática gera um evento. Pausar e continuar ou deslocar a barra dentro da mesma reprodução não cria uma nova música artificialmente. Os milissegundos só são somados quando a posição do áudio avança, limitados pelo relógio monotônico. O aplicativo separa o total de inícios da classificação de escuta válida: **30 segundos ou metade da duração, o que ocorrer primeiro**. Mesmo uma tentativa curta permanece no diário.

A persistência é periódica, aproximadamente a cada cinco segundos, e também nas transições. Encerramento abrupto, falta de espaço ou falhas de armazenamento podem perder a cauda ainda não gravada. Não é possível prometer perda zero em desligamento forçado.

O backup contém histórico, playlists, favoritos, configurações selecionadas e referências aos arquivos. **Não contém os áudios, vídeos, imagens de capa nem a fila atual.** A fila é salva localmente pelo player, separada do backup exportável. Em outro aparelho, as permissões e URIs antigas podem não funcionar; não existe remapeamento automático universal. Preserve também suas pastas de música.

## Referências técnicas

A implementação usa documentação oficial, sem integração com a conta do Spotify:

- Foreground service de reprodução: https://developer.android.com/develop/background-work/services/fgs/service-types
- Foco de áudio: https://developer.android.com/media/optimize/audio-focus
- Seletor de documentos e permissões persistentes: https://developer.android.com/training/data-storage/shared/documents-files
- Android SDK / SDK Manager: https://developer.android.com/studio e https://developer.android.com/tools/sdkmanager

As referências orientam o código; não substituem a execução dos testes no aparelho.
