# پروژه اندروید املاک عمارت

این پروژه فایل HTML ارائه‌شده را داخل یک اپلیکیشن اندرویدی با WebView اجرا می‌کند.

## ساخت APK با Android Studio
1. Android Studio را نصب کنید و Android SDK Platform 35 را دریافت کنید.
2. پوشه `EmaratAndroid` را در Android Studio باز کنید.
3. منتظر بمانید Gradle Sync کامل شود.
4. از منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** گزینه ساخت APK را بزنید.
5. فایل خروجی معمولاً در مسیر `app/build/outputs/apk/debug/app-debug.apk` قرار می‌گیرد.

## نکته‌ها
- نام برنامه: املاک عمارت
- شناسه برنامه: `com.emarat.amlak`
- حداقل نسخه اندروید: Android 6.0 (API 23)
- برای دریافت فونت Vazirmatn از Google Fonts و هر قابلیت متکی به اینترنت، اتصال اینترنت لازم است.
- این بسته سورس پروژه است، نه فایل APK از پیش کامپایل‌شده. برای ساخت APK به Android SDK و ابزار ساخت Android نیاز دارید.
