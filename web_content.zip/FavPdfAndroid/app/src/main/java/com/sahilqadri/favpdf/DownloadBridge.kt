package com.sahilqadri.favpdf

import android.app.Activity
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Receives finished files from the web page and saves them to the device's Downloads folder.
 * Called from JavaScript on a background thread, so file work is done directly here.
 */
class DownloadBridge(private val activity: Activity) {

    private val pending = HashMap<String, File>()

    @JavascriptInterface
    fun begin(id: String) {
        val file = File(activity.cacheDir, "dl_$id.part")
        file.delete()
        file.createNewFile()
        synchronized(pending) { pending[id] = file }
    }

    @JavascriptInterface
    fun append(id: String, base64Chunk: String) {
        val file = synchronized(pending) { pending[id] } ?: return
        val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
        FileOutputStream(file, true).use { it.write(bytes) }
    }

    @JavascriptInterface
    fun finish(id: String, name: String, mime: String) {
        val file = synchronized(pending) { pending.remove(id) } ?: return
        try {
            saveToDownloads(file, name, mime)
            toast("Saved to Downloads: $name")
        } catch (e: Exception) {
            toast("Could not save $name")
        } finally {
            file.delete()
        }
    }

    @JavascriptInterface
    fun error(message: String) {
        toast("Could not download the file: $message")
    }

    private fun saveToDownloads(file: File, name: String, mime: String) {
        val resolver = activity.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Could not create the file in Downloads")

        val output = resolver.openOutputStream(uri) ?: throw IOException("Could not open the file for writing")
        output.use { out -> file.inputStream().use { it.copyTo(out) } }

        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }

    private fun toast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
        }
    }
}
