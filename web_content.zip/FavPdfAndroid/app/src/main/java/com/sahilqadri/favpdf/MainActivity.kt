package com.sahilqadri.favpdf

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.FileNotFoundException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    companion object {
        private const val APP_URL = "https://appassets.androidplatform.net/assets/index.html"
        private const val APP_HOST = "appassets.androidplatform.net"
        private const val CDN_HOST = "cdnjs.cloudflare.com"
    }

    private lateinit var webView: WebView

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    // File chooser state (for <input type="file">)
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    private val fileChooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = filePathCallback
        val camera = cameraUri
        filePathCallback = null
        cameraUri = null
        if (callback == null) return@registerForActivityResult

        val data = result.data
        val uris: Array<Uri>? = when {
            result.resultCode != RESULT_OK -> null
            data?.clipData != null -> {
                val clip = data.clipData!!
                Array(clip.itemCount) { clip.getItemAt(it).uri }
            }
            data?.data != null -> arrayOf(data.data!!)
            camera != null -> arrayOf(camera)
            else -> null
        }
        callback.onReceiveValue(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Draw behind the status and navigation bars; we pad the WebView ourselves below.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        webView = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            addJavascriptInterface(DownloadBridge(this@MainActivity), "FavPdfNative")
            webViewClient = AppWebViewClient()
            webChromeClient = AppChromeClient()
        }

        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }

        setContentView(webView)

        // Back button steps back through tool selections (the app uses URL hashes), then exits.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.loadUrl(APP_URL)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    /** Serves the app from assets, and serves CDN libraries from assets/lib when they are present. */
    private inner class AppWebViewClient : WebViewClient() {

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val url = request.url
            if (url.host == CDN_HOST) {
                val name = url.lastPathSegment
                if (name != null) localLibrary(name)?.let { return it }
            }
            return assetLoader.shouldInterceptRequest(url)
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url
            if (url.host == APP_HOST) return false
            // Any external link opens in the browser, not inside the app.
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, url))
                true
            } catch (e: ActivityNotFoundException) {
                false
            }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            // Routes the app's blob downloads through the native bridge (see DownloadBridge).
            view.evaluateJavascript(DOWNLOAD_SHIM, null)
        }
    }

    private fun localLibrary(name: String): WebResourceResponse? {
        return try {
            val mime = if (name.endsWith(".js")) "application/javascript" else "application/octet-stream"
            WebResourceResponse(mime, "UTF-8", assets.open("lib/$name"))
        } catch (e: FileNotFoundException) {
            null
        }
    }

    private inner class AppChromeClient : WebChromeClient() {

        override fun onShowFileChooser(
            webView: WebView,
            callback: ValueCallback<Array<Uri>>,
            params: WebChromeClient.FileChooserParams
        ): Boolean {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = callback
            cameraUri = null

            val intent: Intent? = if (params.isCaptureEnabled) {
                buildCameraIntent()
            } else {
                buildPickerIntent(params)
            }

            if (intent == null) {
                filePathCallback = null
                return false
            }

            return try {
                fileChooser.launch(intent)
                true
            } catch (e: ActivityNotFoundException) {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = null
                cameraUri = null
                Toast.makeText(this@MainActivity, "No app found to handle this", Toast.LENGTH_SHORT).show()
                false
            }
        }
    }

    private fun buildPickerIntent(params: WebChromeClient.FileChooserParams): Intent {
        val accept = params.acceptTypes.filter { it.isNotBlank() }
        val type = when {
            accept.any { it.startsWith("image/") } -> "image/*"
            accept.any { it.contains("pdf") } -> "application/pdf"
            else -> "*/*"
        }
        return Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            setType(type)
            putExtra(
                Intent.EXTRA_ALLOW_MULTIPLE,
                params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE
            )
        }
    }

    /** Used by the Camera Scan tool's "Take a photo" button (an input with capture="environment"). */
    private fun buildCameraIntent(): Intent? {
        return try {
            val dir = File(cacheDir, "images").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir, "scan_$stamp.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            cameraUri = uri
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Injected into the page. The web app saves files by clicking a temporary <a download>
     * link on a blob: URL, which Android WebView cannot download on its own. This reads the
     * blob in 1 MB chunks and hands it to Kotlin, which writes it to Downloads.
     */
    private val DOWNLOAD_SHIM = """
        (function () {
          if (window.__favpdfShim || !window.FavPdfNative) return;
          window.__favpdfShim = true;
          var native = window.FavPdfNative;
          var originalClick = HTMLAnchorElement.prototype.click;

          HTMLAnchorElement.prototype.click = function () {
            if (this.download && this.href && this.href.indexOf('blob:') === 0) {
              saveBlob(this.href, this.download);
              return;
            }
            return originalClick.call(this);
          };

          function readBase64(blob) {
            return new Promise(function (resolve, reject) {
              var reader = new FileReader();
              reader.onload = function () {
                var s = reader.result;
                resolve(s.substring(s.indexOf(',') + 1));
              };
              reader.onerror = reject;
              reader.readAsDataURL(blob);
            });
          }

          async function saveBlob(url, name) {
            try {
              var blob = await (await fetch(url)).blob();
              var id = Date.now().toString(36) + Math.random().toString(36).slice(2);
              var CHUNK = 1024 * 1024;
              native.begin(id);
              for (var off = 0; off < blob.size; off += CHUNK) {
                var part = blob.slice(off, Math.min(off + CHUNK, blob.size));
                native.append(id, await readBase64(part));
              }
              native.finish(id, name, blob.type || 'application/octet-stream');
            } catch (e) {
              native.error(String(e && e.message ? e.message : e));
            }
          }
        })();
    """.trimIndent()
}
