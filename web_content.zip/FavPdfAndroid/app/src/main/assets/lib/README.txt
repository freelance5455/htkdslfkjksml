Optional: offline copies of the PDF libraries.

By default the app loads these from the CDN (needs internet). If you put the
files below in this folder, the app uses these local copies instead, so PDF
tools work offline. Download them from the same URLs listed here:

  pdf-lib.min.js   https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js
  pdf.min.js       https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js
  jszip.min.js     https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js
  pdf.worker.min.js (optional) https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js

The file names must match exactly. Google Fonts (Archivo, DM Mono) still need
internet; without it the app falls back to Helvetica/Arial and keeps working.
