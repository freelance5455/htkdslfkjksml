STAFF & STORE MANAGER — SOURCE PACKAGE
=====================================

Files
-----
index.html
  The complete standalone offline app source (HTML, CSS and JavaScript).

HOW TO USE ON ANDROID
---------------------
1. Extract this ZIP using your phone's Files app.
2. Open index.html in Chrome to test the app.
3. To make an APK, use a trusted HTML-to-APK builder that bundles the HTML file locally.
4. Test the generated APK before entering real business records.

FEATURES
--------
- First-run administrator registration and login
- Additional staff/admin user accounts
- Staff directory (add/edit/search; admin can delete)
- Store inventory (products, SKU, quantities, prices, reorder thresholds)
- Stock-in and stock-out movements
- Dashboard and low-stock alerts
- JSON backup/restore and CSV exports
- Local browser storage for one-device offline use

IMPORTANT LIMITATIONS
---------------------
- This is a starter prototype, not a security-audited production application.
- Data is stored in local browser storage. Clearing app/browser data can erase records.
- Export backups regularly and keep them in a safe location.
- Password hashing depends on browser crypto support; the app has not undergone a security audit.
- Do not use for sensitive or regulated employee data until professionally reviewed.
- A standalone HTML app is source code, not an APK. An APK must be built separately.
