D.I.G FUND MANAGEMENT — GHAZIPUR UNIT
Supabase Connected • Ad-Free • Offline Cache + Sync

Includes:
- Supabase Auth email/password login
- Members, Jama, Kharch, History and Reports
- Admin/operator write access; viewer read-only through RLS
- Central Supabase database for multiple devices
- Local cache for offline viewing
- Offline new entries are queued and synced when internet returns
- Automatic cloud refresh every 20 seconds while online
- JSON local backup
- No ads or ad SDK

Supabase Project URL:
https://igmjsmrcfppyenvkvqvx.supabase.co

The client uses the project's publishable key. Do NOT put an sb_secret_ or service_role key into this app.

FIRST LOGIN:
Use the Auth user already created in the Supabase dashboard.

APK:
Unzip this package and upload index.html to an HTML-to-APK/PWA wrapper that supports external HTTPS scripts. Build the APK, install it, and log in while online once.

NOTE:
For additional operators/viewers, create their Auth users in Supabase Dashboard. Their profile is created by the existing trigger. Set their role through the secure admin process already configured; do not expose a secret key in the app.
