import { createServer } from 'node:http';

type Rates = { date: string; rates: Record<string,number> };
let cached: Rates | null = null;
let cachedAt = 0;
const allowed = ['EUR','GBP','CAD','TRY','JPY','CHF','INR','AUD'];
const apiUrl = 'https://api.frankfurter.app/latest?from=USD&to=' + allowed.join(',');
const server = createServer(async (req,res) => {
  if (req.method !== 'GET' || req.url !== '/api/rates') {
    res.writeHead(404, {'Content-Type':'application/json; charset=utf-8'});
    res.end(JSON.stringify({error:'Not found'}));
    return;
  }
  try {
    if (!cached || Date.now()-cachedAt > 60*60*1000) {
      const response = await fetch(apiUrl,{signal:AbortSignal.timeout(8000)});
      if (!response.ok) throw new Error(`Exchange rate provider returned ${response.status}`);
      const payload = await response.json() as Rates;
      if (!payload.rates?.EUR || !payload.date) throw new Error('Invalid exchange rate response');
      cached = {date:payload.date,rates:{USD:1,...payload.rates}};
      cachedAt=Date.now();
    }
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=300'});
    res.end(JSON.stringify(cached));
  } catch (error) {
    console.error('GET /api/rates failed:',error);
    res.writeHead(503,{'Content-Type':'application/json; charset=utf-8'});
    res.end(JSON.stringify({error:'Exchange rates are temporarily unavailable'}));
  }
});
server.listen(Number(process.env.PORT),()=>console.log('Calculator rates service ready'));
