/**
 * Sign in with Bazaar Studio — written by the platform, do not edit.
 *
 * The site's management panel is opened by the owner and the people they
 * added in Studio (Settings → Team), each with their own Studio login. No
 * password lives in this app.
 *
 * Use it like this:
 *
 *   import { requireStudioAdmin } from './lib/studio-admin.js';
 *
 *   // first line of every admin API route:
 *   const admin = await requireStudioAdmin(req, res);              // anyone on the team
 *   if (!admin) return;
 *   const manager = await requireStudioAdmin(req, res, { manager: true }); // owner/manager only
 *   if (!manager) return;
 *
 * The panel page calls GET /api/_studio-admin/me: 200 { admin } when signed
 * in, 401 { loginUrl } when not — then shows one button that goes to loginUrl.
 * Sign out: POST /api/_studio-admin/logout.
 *
 * Importing this file mounts /api/_studio-admin/* ahead of the app's own
 * routes (like server/lib/payments.ts). A viewer may look; only an owner or a
 * manager may change anything.
 */

import { Server, type IncomingMessage, type ServerResponse } from 'node:http';
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

const BASE = process.env.PLATFORM_SERVICES_URL;
const TOKEN = process.env.PLATFORM_SERVICE_TOKEN;
// ⚠️ Sessions are signed with this, never with TOKEN: the service token also
// ships in the site's browser bundle and in every APK, so anything keyed on it
// can be forged by whoever unpacks the app (security review, 2026-11-18). The
// platform gives this to the SERVER only. Without it nobody signs in.
const SESSION_SECRET = process.env.STUDIO_ADMIN_SESSION_SECRET;
// ⚠️ `__Host-` on HTTPS (admin-panel review, 2026-11-19): every customer
// site shares bazaar-apps.com, which is not on the Public Suffix List, so a
// neighbouring site can set cookies for the whole domain. A `__Host-` cookie
// can only be set by this host. Plain names on http (local dev only).
const STATE_COOKIE = 'studio_admin_state';
const COOKIE = 'studio_admin';
const sessionCookie = (req: IncomingMessage) => (isHttps(req) ? '__Host-' + COOKIE : COOKIE);
const stateCookie = (req: IncomingMessage) => (isHttps(req) ? '__Host-' + STATE_COOKIE : STATE_COOKIE);
const PREFIX = '/api/_studio-admin/';
/** Re-ask Studio whether this person is still on the team this often (the override exists for the platform's tests). */
const RECHECK_SECONDS = Number(process.env.STUDIO_ADMIN_RECHECK_SECONDS) > 0 ? Number(process.env.STUDIO_ADMIN_RECHECK_SECONDS) : 60;
/** If Studio cannot be reached, keep a recently checked session this long (short: a removed admin must not keep going). */
const RECHECK_GRACE_SECONDS = 600;
const SESSION_SECONDS = 7 * 24 * 3600;

export type StudioAdminRole = 'owner' | 'manager' | 'viewer';

export interface StudioAdmin {
  userId: string;
  name: string | null;
  /** Masked, e.g. 0912•••2233. */
  phone: string | null;
  role: StudioAdminRole;
}

interface SessionPayload extends StudioAdmin {
  /** When the session was issued, and when membership was last confirmed (unix seconds). */
  iat: number;
  chk: number;
}

const now = () => Math.floor(Date.now() / 1000);

function signingKey(): Buffer {
  return createHmac('sha256', 'studio-admin-session').update(SESSION_SECRET ?? '').digest();
}

function sealSession(p: SessionPayload): string {
  const body = Buffer.from(JSON.stringify(p)).toString('base64url');
  const mac = createHmac('sha256', signingKey()).update(body).digest('base64url');
  return body + '.' + mac;
}

function openSession(value: string | undefined): SessionPayload | null {
  if (!value || !SESSION_SECRET) return null;
  const dot = value.indexOf('.');
  if (dot < 1) return null;
  const body = value.slice(0, dot);
  const mac = Buffer.from(value.slice(dot + 1));
  const want = Buffer.from(createHmac('sha256', signingKey()).update(body).digest('base64url'));
  if (mac.length !== want.length || !timingSafeEqual(mac, want)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as SessionPayload;
    if (typeof p.userId !== 'string' || typeof p.iat !== 'number' || typeof p.chk !== 'number') return null;
    if (now() - p.iat > SESSION_SECONDS) return null;
    // A time in the future would skip the re-check forever.
    if (p.iat > now() + 60 || p.chk > now() + 60) return null;
    return p;
  } catch {
    return null;
  }
}

/** The cookie's value — undefined when absent, or sent more than once (a planted copy). */
function readCookie(req: IncomingMessage, name: string): string | undefined {
  const raw = req.headers.cookie;
  if (!raw) return undefined;
  const found: string[] = [];
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) found.push(part.slice(i + 1).trim());
  }
  if (found.length !== 1) return undefined;
  // A malformed cookie must never throw: one bad header would crash the backend.
  try { return decodeURIComponent(found[0]); } catch { return undefined; }
}

function headerSaysHttps(req: IncomingMessage): boolean {
  const xf = String(req.headers['x-forwarded-proto'] ?? '').split(',')[0].trim();
  return xf ? xf === 'https' : !!(req.socket as { encrypted?: boolean }).encrypted;
}

// ⚠️ On a customer's own domain the CDN reaches this server over plain http,
// so the header says http while the visitor's browser is on https (ticket
// f18bd583, 2026-11-21): the return address went out as http:// and Studio
// refused it, and every admin change failed the same-origin check. So when
// the header does not say https, ask the PLATFORM — it knows whether this
// host has a certificate — and remember the answer for a while. Resolved once
// per request by learnScheme(); isHttps() only reads the result.
const httpsOf = new WeakMap<IncomingMessage, boolean>();
const hostAnswers = new Map<string, { https: boolean; at: number }>();
const HOST_ANSWER_MS = 10 * 60 * 1000;

function requestHost(req: IncomingMessage): string {
  return String(req.headers['x-forwarded-host'] ?? req.headers.host ?? '').split(',')[0].trim().toLowerCase();
}

async function learnScheme(req: IncomingMessage): Promise<void> {
  if (httpsOf.has(req)) return;
  if (headerSaysHttps(req) || isLocalHost(req)) {
    httpsOf.set(req, headerSaysHttps(req));
    return;
  }
  const host = requestHost(req);
  const known = hostAnswers.get(host);
  if (known && Date.now() - known.at < HOST_ANSWER_MS) {
    httpsOf.set(req, known.https);
    return;
  }
  const r = await platform('site', { host });
  // No answer means "not https", which is how this file behaved before it
  // asked. Any reply short of a server error is remembered (an older platform
  // answers 404 here), so a site never calls the platform on every request.
  const https = !!(r && r.status === 200 && r.json.https === true);
  if (r && r.status < 500) {
    if (hostAnswers.size > 50) hostAnswers.clear();
    hostAnswers.set(host, { https, at: Date.now() });
  }
  httpsOf.set(req, https);
}

function isHttps(req: IncomingMessage): boolean {
  const learned = httpsOf.get(req);
  return learned === undefined ? headerSaysHttps(req) : learned;
}

/** Not a local dev server: password sign-in needs HTTPS everywhere else. */
function isLocalHost(req: IncomingMessage): boolean {
  const host = String(req.headers['x-forwarded-host'] ?? req.headers.host ?? '').split(',')[0].trim().replace(/:\d+$/, '');
  return host === 'localhost' || host === '127.0.0.1';
}

/** A request this site's own pages made (sign-in CSRF guard). Unknown → allowed only without a cross-site signal. */
function sameOrigin(req: IncomingMessage): boolean {
  const sfs = String(req.headers['sec-fetch-site'] ?? '');
  if (sfs && sfs !== 'same-origin' && sfs !== 'none') return false;
  const origin = String(req.headers.origin ?? '');
  return !origin || origin === siteOrigin(req);
}

function siteOrigin(req: IncomingMessage): string {
  const host = String(req.headers['x-forwarded-host'] ?? req.headers.host ?? '').split(',')[0].trim();
  return (isHttps(req) ? 'https://' : 'http://') + host;
}

function addSetCookie(res: ServerResponse, cookie: string): void {
  const prev = res.getHeader('Set-Cookie');
  const list = prev === undefined ? [] : Array.isArray(prev) ? prev.map(String) : [String(prev)];
  const name = cookie.slice(0, cookie.indexOf('=') + 1);
  res.setHeader('Set-Cookie', [...list.filter((c) => !c.startsWith(name)), cookie]);
}

function setSession(req: IncomingMessage, res: ServerResponse, p: SessionPayload): void {
  addSetCookie(res, sessionCookie(req) + '=' + encodeURIComponent(sealSession(p)) + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' + SESSION_SECONDS + (isHttps(req) ? '; Secure' : ''));
  // A session from before the __Host- name: replaced by the one above.
  if (isHttps(req) && readCookie(req, COOKIE) !== undefined) addSetCookie(res, COOKIE + '=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0; Secure');
}

function clearSession(req: IncomingMessage, res: ServerResponse): void {
  addSetCookie(res, sessionCookie(req) + '=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0' + (isHttps(req) ? '; Secure' : ''));
  if (isHttps(req)) addSetCookie(res, COOKIE + '=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0; Secure');
}

/**
 * The session cookie's value. On HTTPS a session signed in before the
 * __Host- name (2026-11-19) is still read once — it is signed, so a planted
 * copy cannot pass — and moved to the new name by the next setSession.
 */
function readSession(req: IncomingMessage): { value: string | undefined; legacy: boolean } {
  const value = readCookie(req, sessionCookie(req));
  if (value !== undefined || !isHttps(req)) return { value, legacy: false };
  const old = readCookie(req, COOKIE);
  return { value: old, legacy: old !== undefined };
}

async function platform(action: string, body: unknown): Promise<{ status: number; json: Record<string, unknown> } | null> {
  if (!BASE || !TOKEN) return null;
  try {
    const r = await fetch(BASE + '/admin-auth/' + action, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + TOKEN },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(10_000),
    });
    return { status: r.status, json: (await r.json().catch(() => ({}))) as Record<string, unknown> };
  } catch (err) {
    console.error('[studio-admin] platform call failed:', action, err);
    return null;
  }
}

function asPerson(v: unknown): StudioAdmin | null {
  const p = v as Partial<StudioAdmin> | null;
  if (!p || typeof p.userId !== 'string' || (p.role !== 'owner' && p.role !== 'manager' && p.role !== 'viewer')) return null;
  return { userId: p.userId, name: p.name ?? null, phone: p.phone ?? null, role: p.role };
}

/**
 * The signed-in team member, or null. Re-confirms membership with Studio every
 * few minutes, so someone the owner removed loses access within that time.
 * Pass `res` so a refreshed or ended session is written back to the browser.
 */
export async function getStudioAdmin(req: IncomingMessage, res?: ServerResponse): Promise<StudioAdmin | null> {
  await learnScheme(req);
  const cookie = readSession(req);
  const s = openSession(cookie.value);
  if (!s) return null;
  if (cookie.legacy && res) setSession(req, res, s);
  if (now() - s.chk < RECHECK_SECONDS) return { userId: s.userId, name: s.name, phone: s.phone, role: s.role };
  const r = await platform('check', { userId: s.userId });
  if (!r || r.status >= 500) {
    // Studio unreachable: a session confirmed within the grace window holds,
    // so a platform blip does not lock the owner out of their own panel.
    return now() - s.chk < RECHECK_GRACE_SECONDS ? { userId: s.userId, name: s.name, phone: s.phone, role: s.role } : null;
  }
  const person = r.status === 200 ? asPerson(r.json.person) : null;
  if (!person) {
    if (res) clearSession(req, res);
    return null;
  }
  if (res) setSession(req, res, { ...person, iat: s.iat, chk: now() });
  return person;
}

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  if (res.headersSent) return;
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

export function studioAdminLoginUrl(next = '/admin'): string {
  return PREFIX + 'login?next=' + encodeURIComponent(next);
}

/**
 * Guard for every admin API route. Answers 401 (not signed in) or 403 (a
 * viewer trying to change something, or a request from another site) itself
 * and returns null; returns the person otherwise.
 *
 * ⚠️ Admin-panel review (2026-11-19), so no agent-written route can get these
 * wrong:
 *   - a request that is not GET/HEAD must come from this site's own pages.
 *     Customer sites are one "site" to the browser (bazaar-apps.com is not on
 *     the Public Suffix List), so the SameSite=Lax session cookie rode along
 *     on a post from ANOTHER customer's page — that page could change data
 *     in this panel as whoever had it open;
 *   - a request that is not GET/HEAD needs a manager unless the route passes
 *     `allowViewer: true`. It used to need `manager: true` on every change
 *     route; one forgotten option let a viewer change data.
 */
export async function requireStudioAdmin(
  req: IncomingMessage,
  res: ServerResponse,
  opts: { manager?: boolean; allowViewer?: boolean } = {},
): Promise<StudioAdmin | null> {
  const method = (req.method ?? 'GET').toUpperCase();
  const changes = method !== 'GET' && method !== 'HEAD' && method !== 'OPTIONS';
  await learnScheme(req);
  if (changes && !sameOrigin(req)) {
    sendJson(res, 403, { error: 'cross_site' });
    return null;
  }
  const admin = await getStudioAdmin(req, res);
  if (!admin) {
    sendJson(res, 401, { error: 'signed_out', loginUrl: studioAdminLoginUrl() });
    return null;
  }
  const managerOnly = opts.manager ?? (changes && !opts.allowViewer);
  if (managerOnly && admin.role === 'viewer') {
    sendJson(res, 403, { error: 'viewer_cannot_change' });
    return null;
  }
  return admin;
}

function safeNext(next: string | null): string {
  if (!next || !next.startsWith('/') || next.startsWith('//') || next.includes('\\') || /[\u0000-\u001f]/.test(next) || next.length > 500) return '/admin';
  return next;
}

function redirect(res: ServerResponse, to: string): void {
  res.statusCode = 302;
  res.setHeader('Location', to);
  res.setHeader('Cache-Control', 'no-store');
  res.end();
}

function failPage(res: ServerResponse, next: string): void {
  res.statusCode = 401;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:Vazirmatn,Tahoma,sans-serif;max-width:28rem;margin:4rem auto;padding:0 1rem;line-height:1.9"><p>ورود انجام نشد. ممکن است لینک ورود منقضی شده باشد یا دسترسی شما برداشته شده باشد.</p><p><a href="' + studioAdminLoginUrl(next).replace(/"/g, '&quot;') + '">دوباره امتحان کنید</a></p></body></html>');
}

function httpsRequiredPage(res: ServerResponse): void {
  res.statusCode = 403;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:Vazirmatn,Tahoma,sans-serif;max-width:28rem;margin:4rem auto;padding:0 1rem;line-height:1.9"><p>ورود به پنل مدیریت فقط روی نشانی امن (https) ممکن است و این دامنه هنوز گواهی امنیتی ندارد.</p><p>صاحب سایت می‌تواند در بازار استودیو، در بخش دامنه‌ی سایت، وضعیت اتصال امن را ببیند.</p></body></html>');
}

async function readBody(req: IncomingMessage): Promise<string> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const c of req) {
    const b = Buffer.isBuffer(c) ? c : Buffer.from(c);
    size += b.length;
    if (size > 8192) break;
    chunks.push(b);
  }
  return Buffer.concat(chunks).toString('utf8');
}

const esc = (v: string) => v.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** The platform's own login page: Studio sign-in first (recommended), then the owner's username+password logins. */
function loginPage(res: ServerResponse, studioUrl: string, next: string, error: string, status = 200): void {
  res.statusCode = status;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Frame-Options', 'DENY');
  res.end('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود به پنل مدیریت</title>'
    + '<body style="font-family:Vazirmatn,Tahoma,sans-serif;max-width:24rem;margin:3rem auto;padding:0 1rem;line-height:1.9;color:#111">'
    + '<h1 style="font-size:1.25rem">ورود به پنل مدیریت</h1>'
    + '<a href="' + esc(studioUrl) + '" style="display:block;text-align:center;background:#0b8a4c;color:#fff;border-radius:12px;padding:.75rem;text-decoration:none;font-weight:700">ورود با بازار استودیو</a>'
    + '<p style="text-align:center;color:#666;font-size:.85rem;margin:1rem 0">یا با نام کاربری و رمزی که مالک سایت برایتان ساخته</p>'
    + (error ? '<p role="alert" style="color:#b42318;font-size:.9rem">' + esc(error) + '</p>' : '')
    + '<form method="post" action="' + PREFIX + 'password" style="display:grid;gap:.6rem">'
    + '<input type="hidden" name="next" value="' + esc(next) + '">'
    + '<input name="username" autocomplete="username" required placeholder="نام کاربری" dir="ltr" style="padding:.7rem;border:1px solid #ccc;border-radius:10px;font:inherit">'
    + '<input name="password" type="password" autocomplete="current-password" required placeholder="رمز" dir="ltr" style="padding:.7rem;border:1px solid #ccc;border-radius:10px;font:inherit">'
    + '<button type="submit" style="padding:.7rem;border:0;border-radius:10px;background:#222;color:#fff;font:inherit;font-weight:700">ورود</button>'
    + '</form></body></html>');
}

/** Handles /api/_studio-admin/*. Returns true when it answered. */
export async function handleStudioAdminRequest(req: IncomingMessage, res: ServerResponse): Promise<boolean> {
  const rawUrl = (req as IncomingMessage & { originalUrl?: string }).originalUrl ?? req.url ?? '';
  if (!rawUrl.startsWith(PREFIX)) return false;
  const url = new URL(rawUrl, 'http://localhost');
  const route = url.pathname.slice(PREFIX.length).replace(/\/+$/, '');
  const method = (req.method ?? 'GET').toUpperCase();
  await learnScheme(req);
  try {
    if (route === 'login' && method === 'GET') {
      if (!SESSION_SECRET) return sendJson(res, 503, { error: 'Sign-in is not set up on this server yet. Publish the site again.' }), true;
      const next = safeNext(url.searchParams.get('next'));
      // One-time state, checked at /callback: nobody can sign this browser in to THEIR session.
      const state = randomBytes(18).toString('base64url');
      addSetCookie(res, stateCookie(req) + '=' + state + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=600' + (isHttps(req) ? '; Secure' : ''));
      const callback = siteOrigin(req) + PREFIX + 'callback?next=' + encodeURIComponent(next) + '&state=' + state;
      const r = await platform('login-url', { return: callback });
      // A domain without a certificate: Studio never sends a login code to a plain-http address.
      if (r && r.status === 409 && r.json.code === 'https_required') return httpsRequiredPage(res), true;
      const to = r && r.status === 200 && typeof r.json.url === 'string' ? r.json.url : null;
      if (!to) return sendJson(res, 503, { error: 'Sign-in with Bazaar Studio is not available right now.' }), true;
      // The owner created username+password logins: offer both, Studio first.
      if (r && r.json.passwords === true) return loginPage(res, to, next, ''), true;
      return redirect(res, to), true;
    }
    if (route === 'password' && method === 'POST') {
      if (!SESSION_SECRET) return sendJson(res, 503, { error: 'Sign-in is not set up on this server yet. Publish the site again.' }), true;
      if (!sameOrigin(req)) return sendJson(res, 403, { error: 'cross_site' }), true;
      // A password never travels in the clear (a custom domain without HTTPS).
      if (!isHttps(req) && !isLocalHost(req)) return sendJson(res, 403, { error: 'Password sign-in needs HTTPS.' }), true;
      const form = new URLSearchParams(await readBody(req));
      const next = safeNext(form.get('next'));
      const r = await platform('password', { username: form.get('username') ?? '', password: form.get('password') ?? '' });
      const person = r && r.status === 200 ? asPerson(r.json.person) : null;
      if (!person) {
        // One message for a wrong password and a lock: a different one would tell which usernames exist.
        const msg = 'نام کاربری یا رمز درست نیست، یا ورود به‌خاطر تلاش‌های ناموفق زیاد چند دقیقه بسته است.';
        const state = randomBytes(18).toString('base64url');
        addSetCookie(res, stateCookie(req) + '=' + state + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=600' + (isHttps(req) ? '; Secure' : ''));
        const studio = await platform('login-url', { return: siteOrigin(req) + PREFIX + 'callback?next=' + encodeURIComponent(next) + '&state=' + state });
        return loginPage(res, studio && typeof studio.json.url === 'string' ? studio.json.url : studioAdminLoginUrl(next), next, msg, 401), true;
      }
      const t = now();
      setSession(req, res, { ...person, iat: t, chk: t });
      return redirect(res, next), true;
    }
    if (route === 'callback' && method === 'GET') {
      const next = safeNext(url.searchParams.get('next'));
      if (!SESSION_SECRET) return failPage(res, next), true;
      const want = readCookie(req, stateCookie(req)) ?? '';
      const got = url.searchParams.get('state') ?? '';
      addSetCookie(res, stateCookie(req) + '=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0' + (isHttps(req) ? '; Secure' : ''));
      if (!want || want.length !== got.length || !timingSafeEqual(Buffer.from(want), Buffer.from(got))) return failPage(res, next), true;
      const r = await platform('exchange', { code: url.searchParams.get('code') ?? '' });
      const person = r && r.status === 200 ? asPerson(r.json.person) : null;
      if (!person) return failPage(res, next), true;
      const t = now();
      setSession(req, res, { ...person, iat: t, chk: t });
      return redirect(res, next), true;
    }
    if (route === 'me' && method === 'GET') {
      const admin = await getStudioAdmin(req, res);
      return admin ? sendJson(res, 200, { admin }) : sendJson(res, 401, { error: 'signed_out', loginUrl: studioAdminLoginUrl(safeNext(url.searchParams.get('next'))) }), true;
    }
    if (route === 'logout' && (method === 'POST' || method === 'GET')) {
      // Another site must not be able to sign people out with a link or an image.
      if (!sameOrigin(req)) return sendJson(res, 403, { error: 'cross_site' }), true;
      clearSession(req, res);
      return method === 'GET' ? (redirect(res, '/'), true) : (sendJson(res, 200, { ok: true }), true);
    }
    return sendJson(res, 404, { error: 'not found' }), true;
  } catch (err) {
    console.error('[studio-admin] request failed', rawUrl, err);
    return sendJson(res, 500, { error: 'internal error' }), true;
  }
}

// Mounted ahead of the app's own routes, whatever framework it uses.
const HOOK = Symbol.for('platform.studioAdmin.hook');
const hookHost = globalThis as typeof globalThis & { [HOOK]?: true };
if (!hookHost[HOOK] && typeof Server === 'function') {
  hookHost[HOOK] = true;
  const emit = Server.prototype.emit;
  Server.prototype.emit = function (this: Server, event: string | symbol, ...args: unknown[]): boolean {
    if (event === 'request') {
      const req = args[0] as IncomingMessage;
      if ((req.url ?? '').startsWith(PREFIX)) {
        handleStudioAdminRequest(req, args[1] as ServerResponse).catch((err) => console.error('[studio-admin]', err));
        return true;
      }
    }
    return (emit as (...a: unknown[]) => boolean).apply(this, [event, ...args]);
  } as typeof Server.prototype.emit;
}
