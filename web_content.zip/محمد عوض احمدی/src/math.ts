export type CalcResult = { value: number; steps: string[] };
export type AngleMode = 'deg' | 'rad';
const faDigits = '۰۱۲۳۴۵۶۷۸۹';
export const normalizeDigits = (s: string) => s.replace(/[۰-۹]/g, c => String(faDigits.indexOf(c))).replace(/[٠-٩]/g, c => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/٫/g, '.').replace(/٬/g, '').replace(/×/g, '*').replace(/÷/g, '/').replace(/[−–]/g, '-').replace(/π/g, 'pi').replace(/√/g, 'sqrt');
export const prettyNumber = (n: number, locale = 'fa') => !Number.isFinite(n) ? 'خطا' : new Intl.NumberFormat(locale === 'en' ? 'en-US' : 'fa-IR', { maximumFractionDigits: 10 }).format(Number(n.toPrecision(12)));
const label = (n: number) => Number(n.toPrecision(12)).toString();
export function evaluate(raw: string, angle: AngleMode = 'deg'): CalcResult {
  const input = normalizeDigits(raw).replace(/\s/g, '').toLowerCase();
  if (!input) throw new Error('عبارتی وارد نشده است.');
  const tokens = input.match(/asin|acos|atan|sqrt|sin|cos|tan|log|ln|abs|pi|e|\d*\.\d+|\d+\.?\d*|[()+\-*/^%!]/g) || [];
  if (tokens.join('') !== input) throw new Error('عبارت شامل نویسهٔ نامعتبر است.');
  let i = 0;
  const steps: string[] = [];
  const peek = () => tokens[i];
  const eat = (t: string) => { if (peek() === t) { i++; return true; } return false; };
  const checked = (v: number) => { if (!Number.isFinite(v)) throw new Error('نتیجه تعریف‌نشده یا خارج از محدوده است.'); return v; };
  function expression(): number {
    let a = term();
    while (peek() === '+' || peek() === '-') { const op = tokens[i++]; const b = term(); const v = checked(op === '+' ? a + b : a - b); steps.push(`${label(a)} ${op} ${label(b)} = ${label(v)}`); a = v; }
    return a;
  }
  function term(): number {
    let a = unary();
    while (peek() === '*' || peek() === '/' || (peek() && (peek() === '(' || /^[a-z\d.]/.test(peek())))) {
      const op = peek() === '*' || peek() === '/' ? tokens[i++] : '*';
      const b = unary();
      if (op === '/' && b === 0) throw new Error('تقسیم بر صفر امکان‌پذیر نیست.');
      const v = checked(op === '*' ? a * b : a / b); steps.push(`${label(a)} ${op} ${label(b)} = ${label(v)}`); a = v;
    }
    return a;
  }
  function unary(): number { if (eat('+')) return unary(); if (eat('-')) return -unary(); return power(); }
  function power(): number { let a = postfix(); if (eat('^')) { const b = unary(); const v = checked(Math.pow(a, b)); steps.push(`${label(a)} ^ ${label(b)} = ${label(v)}`); a = v; } return a; }
  function postfix(): number { let a = atom(); while (peek() === '%' || peek() === '!') { const op = tokens[i++]; if (op === '%') { a /= 100; steps.push(`درصد = ${label(a)}`); } else { if (!Number.isInteger(a) || a < 0 || a > 170) throw new Error('فاکتوریل فقط برای عدد صحیح بین صفر و ۱۷۰ است.'); const x = a; let v = 1; for (let j = 2; j <= a; j++) v *= j; a = v; steps.push(`${label(x)}! = ${label(a)}`); } } return a; }
  function atom(): number {
    if (eat('(')) { const a = expression(); if (!eat(')')) throw new Error('پرانتز بسته نشده است.'); return a; }
    const t = tokens[i++];
    if (!t) throw new Error('عبارت ناقص است.');
    if (t === 'pi') return Math.PI;
    if (t === 'e') return Math.E;
    if (/^\d/.test(t) || t.startsWith('.')) return Number(t);
    if (['sin','cos','tan','asin','acos','atan','sqrt','log','ln','abs'].includes(t)) {
      if (!eat('(')) throw new Error('بعد از تابع پرانتز باز بگذارید.');
      const a = expression(); if (!eat(')')) throw new Error('پرانتز تابع بسته نشده است.');
      const rad = angle === 'deg' ? a * Math.PI / 180 : a;
      const fn: Record<string, () => number> = { sin: () => Math.sin(rad), cos: () => Math.cos(rad), tan: () => { if (Math.abs(Math.cos(rad)) < 1e-12) throw new Error('تانژانت این زاویه تعریف نشده است.'); return Math.tan(rad); }, asin: () => Math.asin(a), acos: () => Math.acos(a), atan: () => Math.atan(a), sqrt: () => Math.sqrt(a), log: () => Math.log10(a), ln: () => Math.log(a), abs: () => Math.abs(a) };
      let v = checked(fn[t]());
      if (['asin','acos','atan'].includes(t) && angle === 'deg') v *= 180 / Math.PI;
      steps.push(`${t}(${label(a)}) = ${label(v)}`); return v;
    }
    throw new Error('عبارت نامعتبر است.');
  }
  const value = checked(expression());
  if (i !== tokens.length) throw new Error('ترتیب عملگرها یا پرانتزها درست نیست.');
  return { value, steps: steps.length ? steps : [`نتیجه = ${label(value)}`] };
}
