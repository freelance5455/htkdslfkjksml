import { normalizeDigits } from './math';
export type ToolKey = 'percent'|'discount'|'tax'|'profit'|'loan'|'date'|'average'|'ratio'|'linear'|'quadratic'|'fraction'|'power';
export type Field = { key: string; label: string; placeholder?: string };
export const toolList: { key: ToolKey; title: string; icon: string; fields: Field[]; hint: string }[] = [
  { key:'percent', title:'درصد', icon:'%', fields:[{key:'part',label:'مقدار'},{key:'total',label:'کل'}], hint:'مقدار چند درصد از کل است؟' },
  { key:'discount', title:'تخفیف', icon:'٪', fields:[{key:'price',label:'قیمت اولیه'},{key:'rate',label:'درصد تخفیف'}], hint:'قیمت نهایی پس از تخفیف' },
  { key:'tax', title:'مالیات', icon:'+', fields:[{key:'price',label:'مبلغ پایه'},{key:'rate',label:'نرخ مالیات (درصد)'}], hint:'مالیات و مبلغ نهایی' },
  { key:'profit', title:'سود و زیان', icon:'↗', fields:[{key:'cost',label:'قیمت خرید'},{key:'sale',label:'قیمت فروش'}], hint:'مبلغ و درصد سود یا زیان' },
  { key:'loan', title:'قسط و بهره', icon:'≋', fields:[{key:'principal',label:'اصل وام'},{key:'rate',label:'بهره سالانه (درصد)'},{key:'months',label:'تعداد ماه'}], hint:'قسط ماهانه با نرخ بهره ثابت' },
  { key:'date', title:'تاریخ و زمان', icon:'◷', fields:[{key:'start',label:'تاریخ آغاز',placeholder:'2026-01-01'},{key:'startTime',label:'ساعت آغاز (اختیاری)',placeholder:'08:30'},{key:'end',label:'تاریخ پایان',placeholder:'2026-12-31'},{key:'endTime',label:'ساعت پایان (اختیاری)',placeholder:'17:00'}], hint:'فاصلهٔ دو تاریخ و ساعت میلادی' },
  { key:'average', title:'میانگین', icon:'∑', fields:[{key:'items',label:'اعداد (با ویرگول جدا کنید)',placeholder:'12, 18, 25'}], hint:'میانگین و مجموع اعداد' },
  { key:'ratio', title:'نسبت و تناسب', icon:'∶', fields:[{key:'a',label:'عدد اول (a)'},{key:'b',label:'عدد دوم (b)'},{key:'c',label:'عدد سوم (c)'}], hint:'حل تناسب a : b = c : x' },
  { key:'linear', title:'معادله درجه اول', icon:'x', fields:[{key:'a',label:'ضریب x'},{key:'b',label:'عدد ثابت'}], hint:'حل ax + b = 0' },
  { key:'quadratic', title:'معادله درجه دوم', icon:'x²', fields:[{key:'a',label:'ضریب x²'},{key:'b',label:'ضریب x'},{key:'c',label:'عدد ثابت'}], hint:'حل ax² + bx + c = 0' },
  { key:'fraction', title:'کسرها', icon:'½', fields:[{key:'a',label:'صورت اول'},{key:'b',label:'مخرج اول'},{key:'c',label:'صورت دوم'},{key:'d',label:'مخرج دوم'}], hint:'جمع، تفریق، ضرب و تقسیم دو کسر' },
  { key:'power', title:'توان و رادیکال', icon:'√', fields:[{key:'base',label:'عدد پایه'},{key:'exponent',label:'توان یا درجه ریشه'}], hint:'توان و ریشهٔ nام' },
];
export type Output = { title: string; value: number | string; detail?: string };
const gcd = (a: number,b: number): number => b === 0 ? Math.abs(a) : gcd(b,a%b);
export function calculateTool(key: ToolKey, input: Record<string,string>): Output[] {
  const num = (k: string) => { const s = normalizeDigits(input[k] || '').replace(/,/g,'').trim(); if (!s || !Number.isFinite(Number(s))) throw new Error('لطفاً همهٔ مقدارها را درست وارد کنید.'); return Number(s); };
  const nonzero = (n: number) => { if (n === 0) throw new Error('مخرج یا مقدار کل نمی‌تواند صفر باشد.'); return n; };
  let v: Output[] = [];
  switch(key) {
    case 'percent': { const p=num('part'), t=nonzero(num('total')); v=[{title:'درصد',value:p/t*100,detail:`(${p} ÷ ${t}) × ۱۰۰` }]; break; }
    case 'discount': { const p=num('price'),r=num('rate'); if(r<0||r>100) throw new Error('درصد تخفیف باید بین صفر و صد باشد.'); v=[{title:'قیمت نهایی',value:p*(1-r/100),detail:`${p} × (۱ − ${r} ÷ ۱۰۰)`},{title:'مبلغ تخفیف',value:p*r/100}]; break; }
    case 'tax': { const p=num('price'),r=num('rate'); v=[{title:'مبلغ با مالیات',value:p*(1+r/100),detail:`${p} × (۱ + ${r} ÷ ۱۰۰)`},{title:'مبلغ مالیات',value:p*r/100}]; break; }
    case 'profit': { const c=nonzero(num('cost')), s=num('sale'), d=s-c; v=[{title:d>=0?'سود':'زیان',value:Math.abs(d),detail:`قیمت فروش − قیمت خرید = ${d}`},{title:'درصد تغییر',value:d/c*100}]; break; }
    case 'loan': { const p=num('principal'), annual=num('rate'),m=num('months'); if(m<=0||!Number.isInteger(m)||annual<0||p<0) throw new Error('تعداد ماه باید عدد صحیح مثبت و بهره نامنفی باشد.'); const r=annual/1200, pay=r===0?p/m:p*r/(1-Math.pow(1+r,-m)); v=[{title:'قسط ماهانه',value:pay,detail:r===0?'اصل وام ÷ تعداد ماه':'P × r ÷ (۱ − (۱+r)^−n)'},{title:'کل بازپرداخت',value:pay*m},{title:'کل بهره',value:pay*m-p}]; break; }
    case 'date': { const parse=(s:string,t:string)=>{ const str=normalizeDigits(s).trim(), time=normalizeDigits(t||'00:00').trim(); if(!/^\d{4}-\d{2}-\d{2}$/.test(str)) throw new Error('تاریخ را به شکل YYYY-MM-DD وارد کنید.'); if(!/^\d{1,2}:\d{2}$/.test(time)) throw new Error('ساعت را به شکل HH:MM وارد کنید.'); const [h,min]=time.split(':').map(Number); if(h>23||min>59) throw new Error('ساعت واردشده معتبر نیست.'); const [y,m,d]=str.split('-').map(Number); const date=new Date(Date.UTC(y,m-1,d,h,min)); if(date.getUTCFullYear()!==y||date.getUTCMonth()!==m-1||date.getUTCDate()!==d) throw new Error('تاریخ واردشده معتبر نیست.'); return date.getTime(); }; const hours=Math.abs(parse(input.end,input.endTime)-parse(input.start,input.startTime))/3600000; v=[{title:'فاصلهٔ روزها',value:hours/24,detail:'اختلاف تاریخ و ساعت پایان و آغاز'},{title:'فاصلهٔ ساعت‌ها',value:hours},{title:'فاصلهٔ دقیقه‌ها',value:hours*60}]; break; }
    case 'average': { const arr=normalizeDigits(input.items||'').split(/[,،\s]+/).filter(Boolean).map(Number); if(!arr.length||arr.some(x=>!Number.isFinite(x))) throw new Error('اعداد را با ویرگول از هم جدا کنید.'); const total=arr.reduce((a,b)=>a+b,0); v=[{title:'میانگین',value:total/arr.length,detail:`مجموع ÷ ${arr.length}`},{title:'مجموع',value:total},{title:'تعداد',value:arr.length}]; break; }
    case 'ratio': { const a=nonzero(num('a')),b=num('b'),c=num('c'); v=[{title:'مقدار x',value:b*c/a,detail:`${b} × ${c} ÷ ${a}`}]; break; }
    case 'linear': { const a=num('a'),b=num('b'); if(a===0) { v=[{title:'نتیجه',value:b===0?'بی‌نهایت جواب':'بدون جواب'}]; break; } v=[{title:'x',value:-b/a,detail:'x = −b ÷ a'}]; break; }
    case 'quadratic': { const a=num('a'),b=num('b'),c=num('c'); if(a===0) throw new Error('ضریب x² نباید صفر باشد؛ از معادله درجه اول استفاده کنید.'); const delta=b*b-4*a*c; v=[{title:'دلتا (Δ)',value:delta,detail:'b² − ۴ac'}]; if(delta<0) v.push({title:'ریشه‌ها',value:'ریشهٔ حقیقی ندارد'}); else { v.push({title:'ریشهٔ اول',value:(-b+Math.sqrt(delta))/(2*a),detail:'(−b + √Δ) ÷ ۲a'}); if(delta>0)v.push({title:'ریشهٔ دوم',value:(-b-Math.sqrt(delta))/(2*a),detail:'(−b − √Δ) ÷ ۲a'}); } break; }
    case 'fraction': { const a=num('a'),b=nonzero(num('b')),c=num('c'),d=nonzero(num('d')); if (![a,b,c,d].every(Number.isInteger)) throw new Error('صورت و مخرج کسر باید عدد صحیح باشند.'); const fraction=(n:number,den:number) => { if(den===0) return 'تعریف‌نشده'; const g=gcd(n,den); return `${den<0?-n/g:n/g}/${Math.abs(den)/g}`; }; v=[{title:'جمع',value:fraction(a*d+c*b,b*d)},{title:'تفریق',value:fraction(a*d-c*b,b*d)},{title:'ضرب',value:fraction(a*c,b*d)},{title:'تقسیم',value:fraction(a*d,b*c)}]; break; }
    case 'power': { const a=num('base'),n=nonzero(num('exponent')); const pow=Math.pow(a,n); let root=a<0&&Number.isInteger(n)&&Math.abs(n)%2===1 ? -Math.pow(-a,1/n) : Math.pow(a,1/n); if(!Number.isFinite(pow)||!Number.isFinite(root)) throw new Error('توان یا ریشه در اعداد حقیقی تعریف نشده است.'); v=[{title:'توان',value:pow,detail:'پایه به توان مقدار واردشده'},{title:'ریشه',value:root,detail:'ریشهٔ nام پایه'}]; break; }
  }
  return v;
}
export type UnitGroup = { title: string; units: { name: string; factor: number }[] };
export const unitGroups: Record<string,UnitGroup> = {
  length:{title:'طول',units:[{name:'متر',factor:1},{name:'کیلومتر',factor:1000},{name:'سانتی‌متر',factor:.01},{name:'میلی‌متر',factor:.001},{name:'مایل',factor:1609.344},{name:'فوت',factor:.3048},{name:'اینچ',factor:.0254}]},
  mass:{title:'وزن',units:[{name:'کیلوگرم',factor:1},{name:'گرم',factor:.001},{name:'تن',factor:1000},{name:'پوند',factor:.45359237},{name:'اونس',factor:.028349523125}]},
  volume:{title:'حجم',units:[{name:'لیتر',factor:1},{name:'میلی‌لیتر',factor:.001},{name:'متر مکعب',factor:1000},{name:'گالن آمریکا',factor:3.785411784}]},
  speed:{title:'سرعت',units:[{name:'متر بر ثانیه',factor:1},{name:'کیلومتر بر ساعت',factor:1/3.6},{name:'مایل بر ساعت',factor:.44704},{name:'گره',factor:.514444}]},
  area:{title:'مساحت',units:[{name:'متر مربع',factor:1},{name:'کیلومتر مربع',factor:1e6},{name:'سانتی‌متر مربع',factor:.0001},{name:'هکتار',factor:10000},{name:'فوت مربع',factor:.09290304},{name:'جریب',factor:4046.8564224}]},
  time:{title:'زمان',units:[{name:'ثانیه',factor:1},{name:'دقیقه',factor:60},{name:'ساعت',factor:3600},{name:'روز',factor:86400},{name:'هفته',factor:604800}]},
  pressure:{title:'فشار',units:[{name:'پاسکال',factor:1},{name:'کیلوپاسکال',factor:1000},{name:'بار',factor:100000},{name:'اتمسفر',factor:101325},{name:'PSI',factor:6894.757293}]},
  energy:{title:'انرژی',units:[{name:'ژول',factor:1},{name:'کیلوژول',factor:1000},{name:'کیلوکالری',factor:4184},{name:'کیلووات ساعت',factor:3600000}]},
  data:{title:'داده دیجیتال',units:[{name:'بایت',factor:1},{name:'کیلوبایت',factor:1024},{name:'مگابایت',factor:1024**2},{name:'گیگابایت',factor:1024**3},{name:'ترابایت',factor:1024**4},{name:'بیت',factor:1/8}]},
  temp:{title:'دما',units:[{name:'سلسیوس',factor:1},{name:'فارنهایت',factor:1},{name:'کلوین',factor:1}]},
};
export function convertUnit(group:string, value:number, from:string, to:string):number {
  if(!Number.isFinite(value)) throw new Error('مقدار معتبر وارد کنید.');
  if(group==='temp') { const c=from==='فارنهایت'?(value-32)*5/9:from==='کلوین'?value-273.15:value; return to==='فارنهایت'?c*9/5+32:to==='کلوین'?c+273.15:c; }
  const units=unitGroups[group]?.units; const a=units?.find(u=>u.name===from),b=units?.find(u=>u.name===to); if(!a||!b)throw new Error('واحد انتخاب‌شده معتبر نیست.'); return value*a.factor/b.factor;
}
