FLAG ARENA - Android App (WebView)
==================================

Ye project game ko ek Android app ki tarah chalata hai. Game ki file
app/src/main/assets/flag-arena.html mein hai.

APK banane ke steps (Android Studio)
------------------------------------
1. Android Studio kholiye (https://developer.android.com/studio).
2. File > Open > is folder (FlagArena) ko chuniye.
3. Gradle sync hone dijiye. Pehli baar Android Studio khud Gradle
   download karega, isme kuch minute lag sakte hain.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) dabayein.
5. APK yahan milega:
   app/build/outputs/apk/debug/app-debug.apk
6. Ye APK phone par install karein (Settings mein "Unknown sources"
   ya "Install unknown apps" allow karna padega).

Zaroori baatein
---------------
- Game ko Matter.js (physics) internet se load karta hai, isliye
  phone par internet chahiye.
- Full screen button ke liye app mein screen par tap karke browser
  ka button dabaiye, ya seedha game ka button use kijiye.
- App portrait mode mein chalegi aur screen on rahegi (stream ke liye).
- Release APK (Play Store ke liye) banane ke liye Android Studio mein
  Build > Generate Signed Bundle / APK use kijiye.

Agar game nahi khule
--------------------
- Ye version file ko assets se seedha padhta hai (koi URL routing nahi).
- Check kijiye ki flag-arena.html is path par ho:
  app/src/main/assets/flag-arena.html
- Phone par internet on hona chahiye (Matter.js CDN se aata hai).
