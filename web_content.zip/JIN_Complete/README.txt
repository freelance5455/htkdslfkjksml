JIN — MADE BY AZAN | v1.1
Open index.html in a modern browser. On Android Chrome, use menu > Add to Home screen.

New in v1.1: customization screen with accent colours, dashboard density, card corner radius, personalized greeting, background glow and widget visibility; expanded discipline analytics with daily score, weekly average, consistency, XP levels and score history.

Also includes JIN Coins, habit tracker, focus timer, fitness logs, manual PKR finance tracker, journal, educational trading journal, Mojin local coaching prompts, theme store, analytics and JSON backup/restore. Data is stored locally in this browser.

Limitations: this is an offline-first browser app, not a native app or hosted multi-user service. Live AI, cloud sync, accounts, push notifications, bank integrations and native packaging require additional backend/build infrastructure. Trading journal is for simulated/educational records only.
