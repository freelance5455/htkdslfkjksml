STEP 22 – Header + Einkauf kompakt

Änderungen:
- Header-Art wieder korrekt referenziert, damit das App-Logo/Artwork auf den Tabs sichtbar ist.
- Einkauf auf Mobile deutlich kompakter gestaltet.
- Eingabebereich auf zwei Reihen reduziert.
- Offene Einkaufspositionen kompakter und ohne unnötige große Kartenhöhe.
- Funktionalität und Datenmodell unverändert.
Basis: STEP 21.
