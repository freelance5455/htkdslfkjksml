/// <reference lib="webworker" />
/**
 * Media worker: all heavy per-file work happens here, off the UI thread.
 *  - import: read slice → AES-GCM encrypt → batched IndexedDB writes (one ~1 MiB chunk in
 *    flight + one read-ahead), MIME sniffing and thumbnail generation.
 *  - preview: small preview images for the "add" screen.
 *  - downscale: display-size versions of very large photos for the viewer.
 */
import { openDB, type IDBPDatabase } from 'idb';
import { seal } from '../lib/crypto';
import { aad } from '../lib/aad';
import { resolveMime } from '../lib/sniff';
import { downscale, renderThumb } from '../lib/thumbcore';
import type { FromWorker, ImportJob, ToWorker } from './protocol';

declare const self: DedicatedWorkerGlobalScope;

const THUMB_SHORT_SIDE = 440;
const BATCH_BYTES = 8 * 1024 * 1024;
const cancelled = new Set<number>();
const dbs = new Map<string, Promise<IDBPDatabase>>();

const post = (m: FromWorker) => self.postMessage(m);
const db = (name: string) => {
  let p = dbs.get(name);
  if (!p) {
    p = openDB(name);
    dbs.set(name, p);
  }
  return p;
};

self.onmessage = (e: MessageEvent<ToWorker>) => {
  const m = e.data;
  if (m.type === 'cancel') cancelled.add(m.job);
  else if (m.type === 'import') void runImport(m);
  else if (m.type === 'preview') {
    void (async () => {
      try {
        const head = new Uint8Array(await m.file.slice(0, 256 * 1024).arrayBuffer());
        const t = await renderThumb(m.file, m.size, head, 'image/webp', 0.72);
        post({ type: 'blob', job: m.job, blob: new Blob([t.bytes], { type: 'image/webp' }) });
      } catch (err) {
        post({ type: 'error', job: m.job, error: String(err) });
      }
    })();
  } else if (m.type === 'downscale') {
    void (async () => {
      try {
        const head = new Uint8Array(await m.file.slice(0, 256 * 1024).arrayBuffer());
        post({ type: 'blob', job: m.job, blob: await downscale(m.file, m.maxSide, head) });
      } catch (err) {
        post({ type: 'error', job: m.job, error: String(err) });
      }
    })();
  }
};

async function runImport(j: ImportJob) {
  const { job, id, key, file, chunkSize } = j;
  const total = Math.max(1, Math.ceil(file.size / chunkSize));
  const read = (i: number) => file.slice(i * chunkSize, Math.min(file.size, (i + 1) * chunkSize)).arrayBuffer();
  let d: IDBPDatabase | null = null;
  try {
    d = await db(j.dbName);
    let head = new Uint8Array(0);
    let batch: { id: string; idx: number; iv: Uint8Array; ct: Uint8Array }[] = [];
    let batchBytes = 0;
    let batchPlain = 0;
    let written = 0; // plaintext bytes durably handed to IndexedDB: this is what the progress shows
    let lastPost = 0;
    const report = (force = false) => {
      const now = Date.now();
      if (force || now - lastPost > 60) {
        lastPost = now;
        post({ type: 'progress', job, done: written });
      }
    };
    // Writes are pipelined: while one batch is being committed the next one is read and
    // encrypted. "relaxed" durability skips the per-transaction fsync (the final projection
    // write on the main thread is a normal, durable commit), which is the main cost on phones.
    const inflight: Promise<void>[] = [];
    const flush = () => {
      if (!batch.length) return;
      const rows = batch;
      const plain = batchPlain;
      batch = [];
      batchBytes = 0;
      batchPlain = 0;
      const tx = d!.transaction('chunks', 'readwrite', { durability: 'relaxed' });
      const store = tx.objectStore('chunks');
      const p = Promise.all([...rows.map((r) => store.put(r)), tx.done]).then(() => {
        written += plain;
        report();
      });
      inflight.push(p);
    };
    const reads: Promise<ArrayBuffer>[] = [];
    const READ_AHEAD = 2;
    for (let k = 0; k < Math.min(READ_AHEAD, total); k++) reads.push(read(k));
    for (let i = 0; i < total; i++) {
      if (cancelled.has(job)) throw new Error('CANCELLED');
      const buf = new Uint8Array(await reads.shift()!);
      if (i + READ_AHEAD < total) {
        const r = read(i + READ_AHEAD); // disk / content-provider IO overlaps with encryption
        r.catch(() => undefined);
        reads.push(r);
      }
      if (i === 0) head = buf.slice(0, 256 * 1024);
      const s = await seal(key, buf, aad.chunk(id, i));
      batch.push({ id, idx: i, iv: s.iv, ct: s.ct });
      batchBytes += s.ct.length;
      batchPlain += buf.length;
      if (batchBytes >= BATCH_BYTES) {
        flush();
        // at most 2 batches waiting for the database: bounded RAM (~2 × 8 MiB)
        if (inflight.length >= 2) await inflight.shift();
      }
    }
    flush();
    await Promise.all(inflight);
    if (cancelled.has(job)) throw new Error('CANCELLED');
    const mime = resolveMime(head, extOf(file.name), file.type);
    let thumb = false;
    let width: number | undefined;
    let height: number | undefined;
    if (j.kind === 'image' || mime.startsWith('image/')) {
      try {
        const t = await renderThumb(file, THUMB_SHORT_SIDE, head);
        const s = await seal(key, t.bytes, aad.thumb(id));
        await d.put('thumbs', { id, iv: s.iv, ct: s.ct });
        thumb = true;
        width = t.width;
        height = t.height;
      } catch {
        /* undecodable image (e.g. HEIC on older WebViews): stored without thumbnail */
      }
    }
    report(true);
    post({ type: 'done', job, meta: { mime, chunks: total, thumb, width, height } });
  } catch (err) {
    const wasCancelled = cancelled.has(job) || (err as Error)?.message === 'CANCELLED';
    if (d) {
      try {
        const tx = d.transaction(['chunks', 'thumbs'], 'readwrite');
        await Promise.all([tx.objectStore('chunks').delete(IDBKeyRange.bound([id, 0], [id, Number.MAX_SAFE_INTEGER])), tx.objectStore('thumbs').delete(id), tx.done]);
      } catch {
        /* the next unlock's garbage collection removes leftovers */
      }
    }
    post({ type: 'error', job, error: String((err as Error)?.message ?? err), cancelled: wasCancelled });
  } finally {
    cancelled.delete(job);
  }
}

function extOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i > 0 && name.length - i <= 10 ? name.slice(i + 1).toLowerCase() : '';
}
