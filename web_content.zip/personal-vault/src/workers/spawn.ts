/** Creates a media worker (bundled by Vite as a separate module). Returns null if unsupported. */
export function spawnMediaWorker(): Worker | null {
  try {
    return new Worker(new URL('./media.worker.ts', import.meta.url), { type: 'module', name: 'pv-media' });
  } catch {
    return null;
  }
}
