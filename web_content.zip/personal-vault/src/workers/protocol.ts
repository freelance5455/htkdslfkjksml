/** Messages exchanged with the media worker (lib/importer.ts, lib/previewThumbs.ts). */
export interface ImportJob {
  type: 'import';
  job: number;
  id: string;
  key: CryptoKey;
  dbName: string;
  file: File;
  kind: 'file' | 'image';
  chunkSize: number;
}
export interface PreviewJob {
  type: 'preview';
  job: number;
  file: Blob;
  size: number;
}
export interface DownscaleJob {
  type: 'downscale';
  job: number;
  file: Blob;
  maxSide: number;
}
export interface CancelMsg {
  type: 'cancel';
  job: number;
}
export type ToWorker = ImportJob | PreviewJob | DownscaleJob | CancelMsg;

export interface ImportMeta {
  mime: string;
  chunks: number;
  thumb: boolean;
  width?: number;
  height?: number;
}
export type FromWorker =
  | { type: 'progress'; job: number; done: number }
  | { type: 'done'; job: number; meta: ImportMeta }
  | { type: 'blob'; job: number; blob: Blob }
  | { type: 'error'; job: number; error: string; cancelled?: boolean };
