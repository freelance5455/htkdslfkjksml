import { useEffect } from 'react';
import { App as CapApp } from '@capacitor/app';
import { useSession } from './store/session';
import { navBack, useNav, type Route, type Tab } from './store/nav';
import { usePrefs } from './store/prefs';
import { confirmDialog, useUi } from './store/ui';
import { BackPriority, dispatchBack, registerBack } from './lib/back';
import { isNative, setSecureScreen } from './lib/native';
import { useApplyTheme } from './theme';
import { syncUninstallGuard } from './lib/uninstallGuard';
import { BottomNav, DialogHost, Drawer, ProgressOverlay, Toasts } from './components/Chrome';
import { Spinner } from './components/ui';
import { Dashboard } from './screens/Dashboard';
import { Collection } from './screens/Collection';
import { Settings, SecurityScreen, BackupScreen } from './screens/Settings';
import { AddItems } from './screens/AddItems';
import { TextEdit, TextView } from './screens/Texts';
import { Viewer } from './screens/Viewer';
import { FilePreview } from './screens/FilePreview';
import { Appearance } from './screens/Appearance';
import { LockedRoot, Setup, AppMark } from './screens/Lock';

function exitApp() {
  if (isNative) void CapApp.exitApp();
}

function renderTab(t: Tab) {
  switch (t) {
    case 'dashboard': return <Dashboard />;
    case 'files': return <Collection mode="file" />;
    case 'texts': return <Collection mode="text" />;
    case 'images': return <Collection mode="image" />;
    case 'settings': return <Settings />;
  }
}

function renderRoute(r: Route) {
  switch (r.name) {
    case 'addFiles': return <AddItems kind="file" />;
    case 'addImages': return <AddItems kind="image" />;
    case 'textEdit': return <TextEdit id={r.id} />;
    case 'textView': return <TextView id={r.id} />;
    case 'viewer': return <Viewer ids={r.ids} index={r.index} />;
    case 'preview': return <FilePreview id={r.id} info={r.info} />;
    case 'all': return <Collection mode="all" asRoute />;
    case 'trash': return <Collection mode="trash" asRoute />;
    case 'appearance': return <Appearance />;
    case 'backup': return <BackupScreen />;
    case 'security': return <SecurityScreen />;
  }
}

function Shell() {
  const { tab, visited, stack } = useNav();
  const navHidden = useUi((s) => s.navHidden);
  // overflow:hidden containers can still be scrolled by focus(); keep the shell pinned
  const pin = (e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    if (el.scrollTop || el.scrollLeft) el.scrollTo(0, 0);
  };
  return (
    <div className="shell" onScroll={pin}>
      <div className={`tabs-layer${stack.length ? ' covered' : ''}`}>
        {visited.map((t) => (
          <div key={t} className={`tab-pane${t === tab ? ' active' : ''}`}>{renderTab(t)}</div>
        ))}
      </div>
      {stack.map((r, i) => (
        <div key={`${i}:${r.name}`} className={`route-layer${r.name === 'viewer' ? ' dark' : ''}${i === stack.length - 1 ? ' top' : ' below'}`} aria-hidden={i !== stack.length - 1}>
          {renderRoute(r)}
        </div>
      ))}
      <BottomNav hidden={navHidden || stack.length > 0} />
      <Drawer />
    </div>
  );
}

/** Session auto-lock: inactivity timer + background lock (suspended while a system picker is open). */
function useAutoLock() {
  const status = useSession((s) => s.status);
  const lock = useSession((s) => s.lock);
  const autoLockMin = usePrefs((s) => s.autoLockMin);
  const bgLockSec = usePrefs((s) => s.bgLockSec);
  useEffect(() => {
    if (status !== 'unlocked') return;
    let last = Date.now();
    let hiddenAt = 0;
    const bump = () => (last = Date.now());
    const pickerActive = () => useUi.getState().pickerActiveUntil > Date.now() || !!useUi.getState().progress;
    // audio/video playback counts as activity (no inactivity lock in the middle of a film)
    const playing = () => useUi.getState().mediaActive > 0;
    const onVis = () => {
      if (document.hidden) {
        hiddenAt = Date.now();
        if (bgLockSec === 0 && !pickerActive()) lock();
      } else {
        const away = hiddenAt ? Date.now() - hiddenAt : 0;
        hiddenAt = 0;
        if (bgLockSec >= 0 && away >= bgLockSec * 1000 && !pickerActive()) lock();
        else bump();
      }
    };
    const iv = window.setInterval(() => {
      if (playing()) bump();
      else if (autoLockMin > 0 && !pickerActive() && Date.now() - last > autoLockMin * 60_000) lock();
    }, 5000);
    const evs = ['pointerdown', 'keydown', 'scroll', 'touchstart'] as const;
    evs.forEach((e) => window.addEventListener(e, bump, { passive: true, capture: true }));
    document.addEventListener('visibilitychange', onVis);
    return () => {
      clearInterval(iv);
      evs.forEach((e) => window.removeEventListener(e, bump, { capture: true }));
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [status, lock, autoLockMin, bgLockSec]);
}

export function App() {
  const status = useSession((s) => s.status);
  const boot = useSession((s) => s.boot);
  const secure = usePrefs((s) => s.secureScreen);
  useApplyTheme();
  useAutoLock();

  useEffect(() => {
    void boot();
  }, [boot]);

  useEffect(() => setSecureScreen(secure), [secure]);

  // uninstall protection mirrors the real Device Admin state (it can be changed in system Settings)
  useEffect(() => {
    void syncUninstallGuard();
    const onVis = () => {
      if (!document.hidden) void syncUninstallGuard();
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  // Root of the Android back stack: route stack → tab → exit only at the true root.
  // Dialogs, sheets, the drawer, selection mode and unsaved-changes guards all register with a
  // higher priority, so they always consume Back before this handler runs.
  useEffect(() => {
    let asking = false;
    return registerBack(BackPriority.root, () => {
      const unlocked = useSession.getState().status === 'unlocked';
      if (unlocked && navBack()) return;
      // Real exit intent: unlocked vault, dashboard tab, no route open. Confirm if enabled.
      if (unlocked && usePrefs.getState().confirmExit) {
        if (asking) return;
        asking = true;
        void confirmDialog({ title: 'خروج از برنامه', message: 'آیا می‌خواهید از برنامه خارج شوید؟', confirmText: 'خروج', cancelText: 'انصراف', icon: 'exit' }).then((ok) => {
          asking = false;
          if (ok) exitApp();
        });
        return;
      }
      exitApp();
    });
  }, []);

  useEffect(() => {
    let remove: (() => void) | undefined;
    if (isNative) {
      void CapApp.addListener('backButton', () => {
        dispatchBack();
      }).then((h) => (remove = () => void h.remove()));
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') dispatchBack();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      remove?.();
      window.removeEventListener('keydown', onKey);
    };
  }, []);

  return (
    <>
      {status === 'boot' && (
        <div className="auth"><div className="auth-card splash"><AppMark /><Spinner /></div></div>
      )}
      {status === 'setup' && <Setup />}
      {status === 'locked' && <LockedRoot />}
      {status === 'unlocked' && <Shell />}
      <DialogHost />
      <ProgressOverlay />
      <Toasts />
    </>
  );
}
