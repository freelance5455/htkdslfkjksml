import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { IconButton } from '../components/ui';

/**
 * Shared "tap to show / tap to hide" behaviour of every viewer (images, video, PDF), with
 * optional auto-hide (video while playing). Transitions are pure CSS (opacity/transform).
 */
export function useChrome(autoHideMs = 0, active = true) {
  const [shown, setShown] = useState(true);
  const timer = useRef(0);
  const arm = useCallback(() => {
    window.clearTimeout(timer.current);
    if (autoHideMs > 0 && active) timer.current = window.setTimeout(() => setShown(false), autoHideMs);
  }, [autoHideMs, active]);
  useEffect(() => {
    if (shown) arm();
    else window.clearTimeout(timer.current);
    return () => window.clearTimeout(timer.current);
  }, [shown, arm]);
  const toggle = useCallback(() => setShown((s) => !s), []);
  const poke = useCallback(() => {
    setShown(true);
    arm();
  }, [arm]);
  return { shown, toggle, poke, setShown };
}

/** Distinguishes single tap from double tap (same timing as the image viewer). */
export function useTaps(onSingle: (x: number, y: number) => void, onDouble: (x: number, y: number) => void, delay = 260) {
  const last = useRef<{ t: number; x: number; y: number } | null>(null);
  const timer = useRef(0);
  useEffect(() => () => window.clearTimeout(timer.current), []);
  return (x: number, y: number) => {
    const now = Date.now();
    const l = last.current;
    if (l && now - l.t < delay && Math.abs(l.x - x) < 60 && Math.abs(l.y - y) < 60) {
      window.clearTimeout(timer.current);
      last.current = null;
      onDouble(x, y);
      return;
    }
    last.current = { t: now, x, y };
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      last.current = null;
      onSingle(x, y);
    }, delay);
  };
}

export function ViewerTop({ title, subtitle, onBack, children }: { title: string; subtitle?: ReactNode; onBack: () => void; children?: ReactNode }) {
  return (
    <header className="vw-top">
      <IconButton icon="back" label="بازگشت" variant="glass" onClick={onBack} />
      <div className="vw-title">
        <b dir="auto">{title}</b>
        {subtitle && <small>{subtitle}</small>}
      </div>
      <div className="vw-actions">{children}</div>
    </header>
  );
}
