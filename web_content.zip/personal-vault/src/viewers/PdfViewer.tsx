import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from '../components/Icon';
import { IconButton, Spinner } from '../components/ui';
import { VirtualList } from '../components/VirtualList';
import { promptDialog } from '../store/ui';
import { fromB64 } from '../lib/crypto';
import { faNum } from '../lib/format';
import { pdf, viewerNative } from '../lib/native';
import { useChrome, useTaps, ViewerTop } from './chrome';

type Size = { w: number; h: number };
type PageRow = { key: string; index: number };
const GAP = 12;
const HEAD = 64; // space under the overlay top bar
const MIN_Z = 1;
const MAX_Z = 5;

/** Page bitmaps rendered natively on demand; a small LRU keeps memory bounded. */
const pageCache = new Map<string, string>();
const PAGE_CACHE = 12;
function cachePage(k: string, u: string) {
  pageCache.set(k, u);
  while (pageCache.size > PAGE_CACHE) {
    const [ok, ou] = pageCache.entries().next().value as [string, string];
    pageCache.delete(ok);
    URL.revokeObjectURL(ou);
  }
}
let renderChain: Promise<unknown> = Promise.resolve();
let renderGen = 0;

/**
 * Native PDF reader. The document is opened through a seekable stream over the encrypted
 * file: PdfRenderer only reads (and we only decrypt) the parts it needs for the visible pages,
 * so an 800 MB PDF opens in about the time of a small one.
 *  - pinch (two fingers) / double tap to zoom, one finger to scroll and pan
 *  - tap to show/hide the controls, page indicator with "go to page", landscape lock
 */
export function PdfViewer({ handle, count, first, title, subtitle, onBack, onMenu }: { handle: string; count: number; first: Size; title: string; subtitle?: string; onBack: () => void; onMenu: () => void }) {
  const [zoom, setZoom] = useState(1);
  const [sizes, setSizes] = useState<Map<number, Size>>(() => new Map());
  const [page, setPage] = useState(0);
  const [landscape, setLandscape] = useState(false);
  const scroller = useRef<HTMLDivElement | null>(null);
  const chrome = useChrome(0);
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;
  const pinch = useRef<{ d0: number; z0: number; mx: number; my: number; sl: number; st: number } | null>(null);
  const [pinchScale, setPinchScale] = useState(1);

  useEffect(() => {
    renderGen++;
    return () => {
      renderGen++;
      for (const u of pageCache.values()) URL.revokeObjectURL(u);
      pageCache.clear();
      void viewerNative.orientation('auto');
      void viewerNative.immersive(false);
    };
  }, [handle]);
  useEffect(() => {
    void viewerNative.orientation(landscape ? 'landscape' : 'auto');
    void viewerNative.immersive(landscape);
  }, [landscape]);

  const rows = useMemo<PageRow[]>(() => Array.from({ length: count }, (_, i) => ({ key: `p${i}`, index: i })), [count]);
  const sizeOf = useCallback((i: number) => sizes.get(i) ?? first, [sizes, first]);
  const pageW = (w: number, z: number) => Math.max(40, Math.round((w - 24) * z));
  const height = useCallback((r: PageRow, w: number) => {
    const s = sizeOf(r.index);
    return Math.round(pageW(w, zoom) * (s.h / s.w)) + GAP;
  }, [sizeOf, zoom]);
  const onSize = useCallback((i: number, s: Size) => {
    setSizes((m) => {
      const cur = m.get(i) ?? first;
      if (Math.abs(cur.h / cur.w - s.h / s.w) < 0.002) return m;
      const n = new Map(m);
      n.set(i, s);
      return n;
    });
  }, [first]);

  // current page from the scroll position (rows are variable height: walk the layout)
  const onScrollPos = useCallback((top: number, vh: number) => {
    const w = scroller.current?.clientWidth ?? 360;
    const mid = top + vh / 3;
    let y = HEAD;
    for (let i = 0; i < count; i++) {
      const s = sizes.get(i) ?? first;
      y += Math.round(pageW(w, zoomRef.current) * (s.h / s.w)) + GAP;
      if (y > mid) return setPage(i);
    }
    setPage(count - 1);
  }, [count, sizes, first]);

  const commitZoom = (z: number, fx: number, fy: number) => {
    const el = scroller.current;
    const nz = Math.max(MIN_Z, Math.min(MAX_Z, z));
    const k = nz / zoomRef.current;
    if (!el || Math.abs(k - 1) < 0.01) return;
    // keep the point under the fingers where it was
    const nl = (el.scrollLeft + fx) * k - fx;
    const nt = (el.scrollTop + fy - HEAD) * k - fy + HEAD;
    setZoom(nz);
    requestAnimationFrame(() => {
      el.scrollLeft = Math.max(0, nl);
      el.scrollTop = Math.max(0, nt);
    });
  };

  // two-finger pinch: live CSS scale while pinching, real re-render at the new zoom on release
  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const dist = (t: TouchList) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    const onStart = (e: TouchEvent) => {
      if (e.touches.length !== 2) return;
      const r = el.getBoundingClientRect();
      pinch.current = { d0: dist(e.touches), z0: zoomRef.current, mx: (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left, my: (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top, sl: el.scrollLeft, st: el.scrollTop };
    };
    const onMove = (e: TouchEvent) => {
      const p = pinch.current;
      if (!p || e.touches.length !== 2) return;
      e.preventDefault();
      const s = Math.max(MIN_Z / p.z0, Math.min(MAX_Z / p.z0, dist(e.touches) / p.d0));
      setPinchScale(s);
    };
    const onEnd = (e: TouchEvent) => {
      const p = pinch.current;
      if (!p || e.touches.length >= 2) return;
      pinch.current = null;
      setPinchScale((s) => {
        commitZoom(p.z0 * s, p.mx, p.my);
        return 1;
      });
    };
    el.addEventListener('touchstart', onStart, { passive: true });
    el.addEventListener('touchmove', onMove, { passive: false });
    el.addEventListener('touchend', onEnd);
    el.addEventListener('touchcancel', onEnd);
    return () => {
      el.removeEventListener('touchstart', onStart);
      el.removeEventListener('touchmove', onMove);
      el.removeEventListener('touchend', onEnd);
      el.removeEventListener('touchcancel', onEnd);
    };
  }); // re-bound each render: handlers read fresh state through refs

  const onTap = useTaps(
    () => chrome.toggle(),
    (x, y) => commitZoom(zoomRef.current > 1.05 ? 1 : 2.5, x, y),
  );
  const down = useRef<{ x: number; y: number; t: number } | null>(null);

  const goTo = async () => {
    const v = await promptDialog({ title: 'رفتن به صفحه', message: `شماره صفحه (۱ تا ${faNum(count)})`, value: String(page + 1), confirmText: 'برو', maxLength: 6 });
    if (!v) return;
    const n = Number(v.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))));
    if (!Number.isFinite(n)) return;
    const idx = Math.max(0, Math.min(count - 1, Math.round(n) - 1));
    const el = scroller.current;
    if (!el) return;
    let y = HEAD - 8;
    for (let i = 0; i < idx; i++) {
      const s = sizes.get(i) ?? first;
      y += Math.round(pageW(el.clientWidth, zoom) * (s.h / s.w)) + GAP;
    }
    el.scrollTop = y;
  };

  return (
    <div className={`vw vw-pdf${chrome.shown ? '' : ' ui-off'}`}>
      <div
        className="pdf-stage"
        onPointerDown={(e) => (down.current = { x: e.clientX, y: e.clientY, t: Date.now() })}
        onPointerUp={(e) => {
          const d = down.current;
          down.current = null;
          if (!d || pinch.current || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 10 || Date.now() - d.t > 400) return;
          const r = scroller.current!.getBoundingClientRect();
          onTap(e.clientX - r.left, e.clientY - r.top);
        }}
      >
        <VirtualList
          rows={rows}
          height={height}
          className="pdf-list"
          spaceClassName={pinchScale !== 1 ? 'pinching' : ''}
          spaceStyle={pinchScale !== 1 && pinch.current ? { transformOrigin: `${pinch.current.mx + pinch.current.sl}px ${pinch.current.my + pinch.current.st - HEAD}px`, transform: `scale(${pinchScale})` } : undefined}
          scrollerRef={scroller}
          onScrollPos={onScrollPos}
          footerSpace={96}
          header={<div style={{ height: HEAD }} />}
          render={(r, w) => {
            const s = sizeOf(r.index);
            return <PdfPage handle={handle} index={r.index} width={pageW(w, zoom)} ratio={s.h / s.w} onSize={onSize} />;
          }}
        />
      </div>

      <ViewerTop title={title} subtitle={subtitle} onBack={onBack}>
        <IconButton icon="rotate" label={landscape ? 'حالت خودکار' : 'نمایش افقی'} variant="glass" onClick={() => setLandscape((l) => !l)} />
        <IconButton icon="more" label="گزینه‌ها" variant="glass" onClick={onMenu} />
      </ViewerTop>

      <div className="pdf-bar vw-bottom-pill">
        <button type="button" className="pdf-page-btn num" onClick={goTo} aria-label="رفتن به صفحه">{faNum(page + 1)} / {faNum(count)}</button>
        <button type="button" onClick={() => commitZoom(zoom - 0.5, (scroller.current?.clientWidth ?? 0) / 2, (scroller.current?.clientHeight ?? 0) / 2)} disabled={zoom <= MIN_Z} aria-label="کوچک‌نمایی"><Icon name="zoomOut" size={20} /></button>
        <b className="num" onClick={() => commitZoom(1, 0, 0)}>{faNum(Math.round(zoom * 100))}٪</b>
        <button type="button" onClick={() => commitZoom(zoom + 0.5, (scroller.current?.clientWidth ?? 0) / 2, (scroller.current?.clientHeight ?? 0) / 2)} disabled={zoom >= MAX_Z} aria-label="بزرگ‌نمایی"><Icon name="zoom" size={20} /></button>
      </div>
    </div>
  );
}

const PdfPage = memo(function PdfPage({ handle, index, width, ratio, onSize }: { handle: string; index: number; width: number; ratio: number; onSize: (i: number, s: Size) => void }) {
  // render resolution follows zoom × device pixels, capped to keep each bitmap small
  const px = Math.min(2048, Math.round(width * Math.min(2, window.devicePixelRatio || 1)));
  const bucket = Math.ceil(px / 256) * 256; // avoid re-rendering for tiny width changes
  const key = `${handle}:${index}:${bucket}`;
  const [url, setUrl] = useState<string | null>(() => pageCache.get(key) ?? null);
  useEffect(() => {
    const hit = pageCache.get(key);
    if (hit) return setUrl(hit);
    let alive = true;
    const gen = renderGen;
    // pages that fly past during a fast scroll are never rendered
    const t = setTimeout(() => {
      renderChain = renderChain
        .then(async () => {
          if (!alive || gen !== renderGen) return;
          const r = await pdf.render(handle, index, bucket);
          if (gen !== renderGen) return;
          const u = URL.createObjectURL(new Blob([fromB64(r.data)], { type: 'image/jpeg' }));
          cachePage(key, u);
          onSize(index, { w: r.w, h: r.h });
          if (alive) setUrl(u);
        })
        .catch(() => undefined);
    }, 80);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [key, handle, index, bucket, onSize]);
  return (
    <div className="pdf-page" style={{ width, height: Math.round(width * ratio) }}>
      {url ? <img src={url} alt={`صفحه ${index + 1}`} draggable={false} /> : <Spinner size={22} />}
    </div>
  );
});

/** Opens a PDF for the native viewer: seekable stream first, private temp file as fallback (Android < 8). */
export async function openNativePdf(token: string | null, fallbackTempId: () => Promise<string>): Promise<{ handle: string; count: number; first: Size }> {
  if (token) {
    try {
      const d = await pdf.openStream(token);
      return { handle: d.handle, count: d.count, first: { w: d.w, h: d.h } };
    } catch (e) {
      if (!String((e as Error)?.message ?? e).includes('UNSUPPORTED')) throw e;
    }
  }
  const id = await fallbackTempId();
  const d = await pdf.open(id);
  return { handle: d.handle, count: d.count, first: d.pages[0] ?? { w: 612, h: 792 } };
}
