import { useEffect, useRef, useState } from 'react';
import { Icon } from '../components/Icon';
import { IconButton, Sheet, SheetItem, Spinner } from '../components/ui';
import { mediaHold } from '../store/ui';
import { isNative, viewerNative } from '../lib/native';
import { toFaDigits } from '../lib/calc';
import { faNum } from '../lib/format';
import { useChrome, useTaps, ViewerTop } from './chrome';

export const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5, 3];
const two = (n: number) => String(n).padStart(2, '0');
export const fmtTime = (s: number) => {
  if (!Number.isFinite(s) || s < 0) return '--:--';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return toFaDigits(h ? `${h}:${two(m)}:${two(sec)}` : `${m}:${two(sec)}`);
};
const speedLabel = (v: number) => `${toFaDigits(String(v))}×`;

type Hud = { kind: 'bright' | 'volume' | 'seek' | 'skip'; text: string; value?: number; side?: 'l' | 'r' } | null;

const ERR: Record<number, string> = {
  1: 'پخش متوقف شد',
  2: 'خواندن فایل در حین پخش ممکن نشد',
  3: 'رمزگشایی تصویر ویدیو (Decode) ممکن نشد',
  4: 'قالب یا کدک این ویدیو توسط موتور نمایش گوشی پشتیبانی نمی‌شود',
};

/**
 * Full-screen video player.
 *  - streams straight from the encrypted store (only the chunks being played/seeked are decrypted)
 *  - tap: show/hide controls · double tap left/right: −10 / +10 s
 *  - vertical swipe, left half: brightness · right half: volume · horizontal swipe: precise seek
 *  - speed 0.25×–3×, landscape lock, fit/fill, loop
 */
export function VideoViewer({ url, title, subtitle, onBack, onError, extraSheet }: { url: string; title: string; subtitle?: string; onBack: () => void; onError: (msg: string) => void; extraSheet?: (close: () => void) => React.ReactNode }) {
  const v = useRef<HTMLVideoElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [dur, setDur] = useState(NaN);
  const [buffering, setBuffering] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [loop, setLoop] = useState(false);
  const [fill, setFill] = useState(false);
  const [landscape, setLandscape] = useState(false);
  const [sheet, setSheet] = useState<'speed' | 'more' | null>(null);
  const [hud, setHud] = useState<Hud>(null);
  const [bright, setBright] = useState(0.5); // 0..1
  const [webBright, setWebBright] = useState(1);
  const scrubbing = useRef(false);
  const chrome = useChrome(3200, playing && !sheet);
  const hudTimer = useRef(0);

  const showHud = (h: Hud, ms = 650) => {
    setHud(h);
    window.clearTimeout(hudTimer.current);
    hudTimer.current = window.setTimeout(() => setHud(null), ms);
  };

  // media element lifecycle: attach, observe, and fully release on close
  useEffect(() => {
    const el = v.current;
    if (!el) return;
    if (el.getAttribute('src') !== url) {
      el.setAttribute('src', url);
      el.load();
    }
    let held = false;
    let raf = 0;
    const hold = (on: boolean) => {
      if (on === held) return;
      held = on;
      mediaHold(on);
      void viewerNative.keepAwake(on);
    };
    const tick = () => {
      if (!scrubbing.current) setTime(el.currentTime);
      raf = requestAnimationFrame(tick);
    };
    const onPlay = () => {
      setPlaying(true);
      hold(true);
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(tick);
    };
    const onPause = () => {
      setPlaying(false);
      hold(false);
      cancelAnimationFrame(raf);
      setTime(el.currentTime);
    };
    const onMeta = () => {
      setDur(el.duration);
      setBuffering(false);
      void el.play().catch(() => undefined);
    };
    const onWait = () => setBuffering(true);
    const onCan = () => setBuffering(false);
    const onErr = () => onError(ERR[el.error?.code ?? 4] ?? ERR[4]);
    el.addEventListener('play', onPlay);
    el.addEventListener('pause', onPause);
    el.addEventListener('ended', onPause);
    el.addEventListener('loadedmetadata', onMeta);
    el.addEventListener('durationchange', () => setDur(el.duration));
    el.addEventListener('waiting', onWait);
    el.addEventListener('seeking', onWait);
    el.addEventListener('canplay', onCan);
    el.addEventListener('playing', onCan);
    el.addEventListener('seeked', onCan);
    el.addEventListener('error', onErr);
    return () => {
      cancelAnimationFrame(raf);
      hold(false);
      el.removeEventListener('play', onPlay);
      el.removeEventListener('pause', onPause);
      el.removeEventListener('ended', onPause);
      el.removeEventListener('loadedmetadata', onMeta);
      el.removeEventListener('waiting', onWait);
      el.removeEventListener('seeking', onWait);
      el.removeEventListener('canplay', onCan);
      el.removeEventListener('playing', onCan);
      el.removeEventListener('seeked', onCan);
      el.removeEventListener('error', onErr);
      el.pause();
      el.removeAttribute('src');
      el.load();
    };
  }, [url]); // eslint-disable-line react-hooks/exhaustive-deps

  // restore system state when the player closes
  useEffect(() => {
    void viewerNative.getBrightness().then((b) => b !== null && b >= 0 && setBright(b));
    return () => {
      void viewerNative.setBrightness(-1);
      void viewerNative.orientation('auto');
      void viewerNative.immersive(false);
      window.clearTimeout(hudTimer.current);
    };
  }, []);

  useEffect(() => {
    void viewerNative.orientation(landscape ? 'landscape' : 'auto');
    void viewerNative.immersive(landscape);
  }, [landscape]);

  const el = () => v.current;
  const toggle = () => {
    const m = el();
    if (!m) return;
    if (m.paused) void m.play().catch(() => undefined);
    else m.pause();
    chrome.poke();
  };
  const skip = (d: number, side?: 'l' | 'r') => {
    const m = el();
    if (!m || !Number.isFinite(m.duration)) return;
    m.currentTime = Math.max(0, Math.min(m.duration, m.currentTime + d));
    setTime(m.currentTime);
    showHud({ kind: 'skip', text: `${d > 0 ? '+' : '−'}${faNum(Math.abs(d))} ثانیه`, side });
  };
  const setRate = (r: number) => {
    setSpeed(r);
    if (v.current) {
      v.current.playbackRate = r;
      v.current.defaultPlaybackRate = r;
    }
  };

  const onTap = useTaps(
    () => chrome.toggle(),
    (x) => {
      const w = stage.current?.clientWidth ?? 1;
      if (x < w * 0.38) skip(-10, 'l');
      else if (x > w * 0.62) skip(10, 'r');
      else toggle();
    },
  );

  // ---- gestures
  const g = useRef<{ x: number; y: number; mode: null | 'bright' | 'volume' | 'seek'; start: number; t0: number; id: number } | null>(null);
  const applyBright = (b: number) => {
    setBright(b);
    void viewerNative.setBrightness(Math.max(0.01, b));
    setWebBright(0.4 + b * 1.2);
  };
  const onDown = (e: React.PointerEvent) => {
    if (g.current) return;
    g.current = { x: e.clientX, y: e.clientY, mode: null, start: 0, t0: v.current?.currentTime ?? 0, id: e.pointerId };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onMove = (e: React.PointerEvent) => {
    const s = g.current;
    const box = stage.current;
    if (!s || !box || e.pointerId !== s.id) return;
    const dx = e.clientX - s.x;
    const dy = e.clientY - s.y;
    if (!s.mode) {
      if (Math.abs(dy) > 14 && Math.abs(dy) > Math.abs(dx) * 1.3) {
        const rect = box.getBoundingClientRect();
        s.mode = s.x - rect.left < rect.width / 2 ? 'bright' : 'volume';
        s.start = s.mode === 'bright' ? bright : v.current?.volume ?? 1;
      } else if (Math.abs(dx) > 16 && Math.abs(dx) > Math.abs(dy) * 1.3 && Number.isFinite(dur)) {
        s.mode = 'seek';
        scrubbing.current = true;
      } else return;
    }
    if (s.mode === 'bright' || s.mode === 'volume') {
      const val = Math.max(0, Math.min(1, s.start - (dy / box.clientHeight) * 1.25));
      if (s.mode === 'bright') applyBright(val);
      else if (v.current) v.current.volume = val;
      showHud({ kind: s.mode, value: val, text: `${faNum(Math.round(val * 100))}٪` }, 900);
    } else if (s.mode === 'seek' && v.current) {
      const span = Math.min(dur, 180); // full width = 3 minutes (or the whole video if shorter)
      const target = Math.max(0, Math.min(dur, s.t0 + (dx / box.clientWidth) * span));
      setTime(target);
      const delta = target - s.t0;
      showHud({ kind: 'seek', text: `${delta >= 0 ? '+' : '−'}${fmtTime(Math.abs(delta))}  ·  ${fmtTime(target)}` }, 900);
    }
  };
  const onUp = (e: React.PointerEvent) => {
    const s = g.current;
    g.current = null;
    if (!s || e.pointerId !== s.id) return;
    if (s.mode === 'seek' && v.current) {
      scrubbing.current = false;
      v.current.currentTime = time;
    }
    if (!s.mode && e.type === 'pointerup') {
      const rect = stage.current!.getBoundingClientRect();
      onTap(e.clientX - rect.left, e.clientY - rect.top);
    }
  };

  const pct = Number.isFinite(dur) && dur > 0 ? (time / dur) * 100 : 0;

  return (
    <div className={`vw vw-video${chrome.shown ? '' : ' ui-off'}`}>
      <div className="vv-stage" ref={stage} onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
        <video ref={v} playsInline preload="auto" disablePictureInPicture controlsList="nodownload noremoteplayback" loop={loop} style={{ objectFit: fill ? 'cover' : 'contain', filter: !isNative && webBright !== 1 ? `brightness(${webBright})` : undefined }} />
        {buffering && <span className="vv-buffer"><Spinner size={38} /></span>}
        {hud && (
          <div className={`vv-hud ${hud.kind}${hud.side ? ` side-${hud.side}` : ''}`}>
            {hud.kind !== 'seek' && hud.kind !== 'skip' && <Icon name={hud.kind === 'bright' ? 'sun' : 'volume'} size={22} />}
            {hud.kind === 'skip' && <Icon name={hud.side === 'l' ? 'rewind10' : 'forward10'} size={22} />}
            <span className="num">{hud.text}</span>
            {hud.value !== undefined && <i className="vv-meter"><b style={{ height: `${Math.round(hud.value * 100)}%` }} /></i>}
          </div>
        )}
      </div>

      <ViewerTop title={title} subtitle={subtitle} onBack={onBack}>
        <button type="button" className="vw-chip num" onClick={() => setSheet('speed')} aria-label="سرعت پخش">{speedLabel(speed)}</button>
        <IconButton icon="rotate" label={landscape ? 'حالت عمودی' : 'حالت افقی'} variant="glass" onClick={() => setLandscape((l) => !l)} />
        <IconButton icon="more" label="تنظیمات" variant="glass" onClick={() => setSheet('more')} />
      </ViewerTop>

      <div className="vv-center" dir="ltr">
        <button type="button" className="vv-skip" onClick={() => skip(-10)} aria-label="۱۰ ثانیه عقب"><Icon name="rewind10" size={26} /></button>
        <button type="button" className="vv-play" onClick={toggle} aria-label={playing ? 'توقف' : 'پخش'}><Icon name={playing ? 'pause' : 'play'} size={34} stroke={2.2} /></button>
        <button type="button" className="vv-skip" onClick={() => skip(10)} aria-label="۱۰ ثانیه جلو"><Icon name="forward10" size={26} /></button>
      </div>

      <footer className="vv-bottom" dir="ltr">
        <span className="num">{fmtTime(time)}</span>
        <input
          type="range"
          min={0}
          max={Number.isFinite(dur) ? dur : 0}
          step="any"
          value={Math.min(time, Number.isFinite(dur) ? dur : 0)}
          style={{ ['--p' as string]: `${pct}%` }}
          aria-label="موقعیت پخش"
          onPointerDown={() => {
            scrubbing.current = true;
            chrome.poke();
          }}
          onPointerUp={() => (scrubbing.current = false)}
          onChange={(e) => {
            const t = Number(e.target.value);
            setTime(t);
            if (v.current) v.current.currentTime = t;
            chrome.poke();
          }}
        />
        <span className="num">{fmtTime(dur)}</span>
      </footer>

      <Sheet open={sheet === 'speed'} onClose={() => setSheet(null)} title="سرعت پخش">
        <div className="speed-grid">
          {SPEEDS.map((r) => (
            <button key={r} type="button" className={`speed-opt num${r === speed ? ' on' : ''}`} onClick={() => { setRate(r); setSheet(null); }}>{speedLabel(r)}</button>
          ))}
        </div>
      </Sheet>
      <Sheet open={sheet === 'more'} onClose={() => setSheet(null)} title="تنظیمات پخش">
        <SheetItem icon="rotate" label={landscape ? 'بازگشت به حالت خودکار' : 'نمایش افقی (Landscape)'} onClick={() => { setLandscape((l) => !l); setSheet(null); }} />
        <SheetItem icon="expand" label={fill ? 'نمایش کامل تصویر (Fit)' : 'پر کردن صفحه (Fill)'} onClick={() => { setFill((f) => !f); setSheet(null); }} />
        <SheetItem icon="repeat" label="تکرار ویدیو" active={loop} onClick={() => setLoop((l) => !l)} />
        <SheetItem icon="timer" label={`سرعت پخش: ${speedLabel(speed)}`} onClick={() => setSheet('speed')} />
        {extraSheet?.(() => setSheet(null))}
      </Sheet>
    </div>
  );
}

