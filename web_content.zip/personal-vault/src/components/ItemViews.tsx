import { memo } from 'react';
import { Icon } from './Icon';
import { usePress } from './usePress';
import type { Item } from '../lib/types';
import { useThumb } from '../lib/media';
import { fileVisual, formatDate, formatSize } from '../lib/format';

export interface TileProps {
  item: Item;
  selecting: boolean;
  selected: boolean;
  trash?: boolean;
  onOpen: (it: Item) => void;
  onToggle: (it: Item) => void;
  onLongPress: (it: Item) => void;
  onQuick: (it: Item) => void;
}

function useTilePress(p: TileProps) {
  return usePress(
    () => (p.selecting ? p.onToggle(p.item) : p.onOpen(p.item)),
    () => p.onLongPress(p.item),
  );
}

function SelectMark({ on }: { on: boolean }) {
  return (
    <span className={`sel-mark${on ? ' on' : ''}`}>
      <Icon name="check" size={15} stroke={3} />
    </span>
  );
}

function QuickButton({ icon, label, onClick }: { icon: 'download' | 'copy' | 'restore'; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      className="quick"
      aria-label={label}
      onPointerDown={(e) => e.stopPropagation()}
      onPointerUp={(e) => e.stopPropagation()}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
    >
      <Icon name={icon} size={19} />
    </button>
  );
}

export const ImageTile = memo(function ImageTile(p: TileProps) {
  const press = useTilePress(p);
  const url = useThumb(p.item.id, !!p.item.thumb);
  return (
    <div className={`img-tile${p.selected ? ' selected' : ''}${p.selecting ? ' selecting' : ''}`} {...press} role="button" aria-label={p.item.name}>
      <div className="img-inner">
        {url ? <img src={url} alt="" decoding="async" draggable={false} /> : <div className="img-ph"><Icon name="image" size={28} stroke={1.5} /></div>}
        <div className="img-shade" />
        <span className="img-name">{p.item.name}</span>
        {!p.selecting && <QuickButton icon={p.trash ? 'restore' : 'download'} label={p.trash ? 'بازیابی' : 'دانلود'} onClick={() => p.onQuick(p.item)} />}
      </div>
      {p.selecting && <SelectMark on={p.selected} />}
    </div>
  );
});

export const FileRow = memo(function FileRow(p: TileProps) {
  const press = useTilePress(p);
  const v = fileVisual(p.item.ext, p.item.mime);
  const thumb = useThumb(p.item.id, !!p.item.thumb);
  return (
    <div className={`row-card${p.selected ? ' selected' : ''}`} {...press} role="button">
      {p.selecting && <SelectMark on={p.selected} />}
      <span className={`file-badge hue-${v.hue}${thumb ? ' has-thumb' : ''}`}>
        {thumb ? <img src={thumb} alt="" decoding="async" draggable={false} /> : <Icon name={v.icon} size={22} />}
        <i>{v.label}</i>
      </span>
      <span className="row-main">
        <b>{p.item.name}</b>
        <small>
          <span className="num">{formatSize(p.item.size)}</span> · {formatDate(p.trash && p.item.deletedAt ? p.item.deletedAt : p.item.createdAt)}
        </small>
      </span>
      {!p.selecting && <QuickButton icon={p.trash ? 'restore' : 'download'} label={p.trash ? 'بازیابی' : 'دانلود'} onClick={() => p.onQuick(p.item)} />}
    </div>
  );
});

export const TextRow = memo(function TextRow(p: TileProps) {
  const press = useTilePress(p);
  return (
    <div className={`row-card text${p.selected ? ' selected' : ''}`} {...press} role="button">
      {p.selecting && <SelectMark on={p.selected} />}
      <span className="file-badge hue-emerald">
        <Icon name="texts" size={22} />
      </span>
      <span className="row-main">
        <b>{p.item.name}</b>
        <span className="snippet">{p.item.snippet || 'بدون محتوا'}</span>
        <small>{formatDate(p.trash && p.item.deletedAt ? p.item.deletedAt : p.item.updatedAt)}</small>
      </span>
      {!p.selecting && <QuickButton icon={p.trash ? 'restore' : 'copy'} label={p.trash ? 'بازیابی' : 'رونوشت'} onClick={() => p.onQuick(p.item)} />}
    </div>
  );
});
