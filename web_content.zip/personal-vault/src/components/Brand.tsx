import { memo, useId } from 'react';

/**
 * Brand marks (same artwork as the Android launcher icons in android-res/):
 *  - VaultMark: obsidian squircle + vault-door glyph, tinted with the current accent colour.
 *  - CalcMark:  the disguise icon. Same squircle, grid and stroke weight, calculator keys.
 * Both are drawn on the same 64-unit grid (glyph box 14..50) so they read as one family.
 */
export const VaultMark = memo(function VaultMark({ size = 64, accent }: { size?: number; accent?: string }) {
  const id = useId().replace(/:/g, '');
  const acc = accent ?? 'var(--acc, #10b981)';
  return (
    <svg className="brand-mark" width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <linearGradient id={`${id}bg`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1d2433" />
          <stop offset="1" stopColor="#0b0e15" />
        </linearGradient>
        <linearGradient id={`${id}gl`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.16" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <radialGradient id={`${id}glow`} cx="0.5" cy="0.45" r="0.55">
          <stop offset="0" style={{ stopColor: acc }} stopOpacity="0.35" />
          <stop offset="1" style={{ stopColor: acc }} stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="64" height="64" rx="18" fill={`url(#${id}bg)`} />
      <rect width="64" height="64" rx="18" fill={`url(#${id}glow)`} />
      <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" fill={`url(#${id}gl)`} stroke="#fff" strokeOpacity="0.08" strokeWidth="1.5" />
      <g fill="none" style={{ stroke: acc }} strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="14" y="15" width="36" height="34" rx="9" style={{ fill: acc }} fillOpacity="0.1" />
        <circle cx="35" cy="32" r="8.5" />
        <path d="M35 21.5v2.5M35 40v2.5M24.5 32H27M43 32h2.5" strokeWidth="2.6" />
        <path d="M21 26v12" />
      </g>
      <circle cx="35" cy="32" r="2.6" style={{ fill: acc }} />
    </svg>
  );
});

export const CalcMark = memo(function CalcMark({ size = 64, accent = '#f59e0b' }: { size?: number; accent?: string }) {
  const id = useId().replace(/:/g, '');
  return (
    <svg className="brand-mark" width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <linearGradient id={`${id}bg`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1d2433" />
          <stop offset="1" stopColor="#0b0e15" />
        </linearGradient>
        <linearGradient id={`${id}gl`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.16" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="18" fill={`url(#${id}bg)`} />
      <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="17.25" fill={`url(#${id}gl)`} stroke="#fff" strokeOpacity="0.08" strokeWidth="1.5" />
      <rect x="14" y="14" width="16" height="16" rx="5" fill="#2c3445" />
      <rect x="34" y="14" width="16" height="16" rx="5" fill="#2c3445" />
      <rect x="14" y="34" width="16" height="16" rx="5" fill="#2c3445" />
      <rect x="34" y="34" width="16" height="16" rx="5" fill={accent} />
      <g fill="none" stroke="#e8ebf2" strokeWidth="2.8" strokeLinecap="round">
        <path d="M22 18.5v7M18.5 22h7" />
        <path d="M38.5 22h7" />
        <path d="m19 39 6 6M25 39l-6 6" />
      </g>
      <path d="M38.5 40h7M38.5 44.5h7" fill="none" stroke="#1a1204" strokeWidth="2.8" strokeLinecap="round" />
    </svg>
  );
});
