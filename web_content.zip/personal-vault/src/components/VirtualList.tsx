import { type ReactNode, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';

/**
 * Windowed list with variable (but computable) row heights. Only rows inside the viewport
 * (+ overscan) are mounted, so thousands of items keep the DOM and image decoding small.
 */
export function VirtualList<R extends { key: string }>({ rows, height, render, header, footerSpace = 120, className = '', onScrollPos, scrollerRef, spaceClassName = '', spaceStyle }: { rows: R[]; height: (r: R, width: number) => number; render: (r: R, width: number) => ReactNode; header?: ReactNode; footerSpace?: number; className?: string; onScrollPos?: (top: number, viewportH: number) => void; scrollerRef?: React.MutableRefObject<HTMLDivElement | null>; spaceClassName?: string; spaceStyle?: React.CSSProperties }) {
  const scroller = useRef<HTMLDivElement>(null);
  const posRef = useRef(onScrollPos);
  posRef.current = onScrollPos;
  const headRef = useRef<HTMLDivElement>(null);
  const [vp, setVp] = useState({ top: 0, h: 800, w: 360, head: 0 });

  useLayoutEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const measure = () => setVp((v) => ({ ...v, h: el.clientHeight, w: el.clientWidth, head: headRef.current?.offsetHeight ?? 0 }));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    if (headRef.current) ro.observe(headRef.current);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        posRef.current?.(el.scrollTop, el.clientHeight);
        setVp((v) => (Math.abs(v.top - el.scrollTop) < 40 ? v : { ...v, top: el.scrollTop }));
      });
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      el.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  const layout = useMemo(() => {
    const offs = new Array<number>(rows.length);
    let y = 0;
    for (let i = 0; i < rows.length; i++) {
      offs[i] = y;
      y += height(rows[i], vp.w);
    }
    return { offs, total: y };
  }, [rows, vp.w, height]);

  const overscan = vp.h * 0.9;
  const from = vp.top - vp.head - overscan;
  const to = vp.top - vp.head + vp.h + overscan;
  let lo = 0;
  let hi = rows.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (layout.offs[mid] + height(rows[mid], vp.w) < from) lo = mid + 1;
    else hi = mid;
  }
  const visible: ReactNode[] = [];
  for (let i = lo; i < rows.length && layout.offs[i] < to; i++) {
    visible.push(
      <div key={rows[i].key} className="vrow" style={{ transform: `translateY(${layout.offs[i]}px)`, height: height(rows[i], vp.w) }}>
        {render(rows[i], vp.w)}
      </div>,
    );
  }

  return (
    <div
      ref={(el) => {
        (scroller as React.MutableRefObject<HTMLDivElement | null>).current = el;
        if (scrollerRef) scrollerRef.current = el;
      }}
      className={`vscroll ${className}`}
    >
      <div ref={headRef}>{header}</div>
      <div className={`vspace ${spaceClassName}`} style={{ ...spaceStyle, height: layout.total + footerSpace }}>
        {visible}
      </div>
    </div>
  );
}
