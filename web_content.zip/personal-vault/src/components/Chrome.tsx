import { setDisguise } from '../lib/disguise';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon, type IconName } from './Icon';
import { Button, PasswordInput, Spinner, Switch } from './ui';
import { useNav, type Tab } from '../store/nav';
import { useUi } from '../store/ui';
import { usePrefs } from '../store/prefs';
import { useSession } from '../store/session';
import { BackPriority, useBack } from '../lib/back';
import { PASSWORD_MAX } from '../lib/crypto';
import { faNum } from '../lib/format';
import { AppMark } from '../screens/Lock';

const TABS: { tab: Tab; icon: IconName; label: string }[] = [
  { tab: 'dashboard', icon: 'dashboard', label: 'داشبورد' },
  { tab: 'files', icon: 'files', label: 'فایل‌ها' },
  { tab: 'texts', icon: 'texts', label: 'متن‌ها' },
  { tab: 'images', icon: 'images', label: 'تصاویر' },
  { tab: 'settings', icon: 'settings', label: 'تنظیمات' },
];

export function BottomNav({ hidden }: { hidden: boolean }) {
  const tab = useNav((s) => s.tab);
  const setTab = useNav((s) => s.setTab);
  return (
    <nav className={`bottom-nav${hidden ? ' hidden' : ''}`} aria-label="ناوبری اصلی">
      {TABS.map((t) => (
        <button key={t.tab} type="button" className={`nav-item${t.tab === tab ? ' on' : ''}`} onClick={() => setTab(t.tab)} aria-label={t.label} aria-current={t.tab === tab ? 'page' : undefined}>
          <span className="nav-sq">
            <Icon name={t.icon} size={22} stroke={t.tab === tab ? 2.1 : 1.8} />
          </span>
          <span className="nav-label">{t.label}</span>
        </button>
      ))}
    </nav>
  );
}

function DrawerItem({ icon, label, count, onClick, hue, active }: { icon: IconName; label: string; count?: number; onClick: () => void; hue: string; active?: boolean }) {
  return (
    <button type="button" className={`drawer-item${active ? ' active' : ''}`} onClick={onClick}>
      <span className={`di-ic hue-${hue}`}><Icon name={icon} size={20} /></span>
      <span className="di-label">{label}</span>
      {count !== undefined && count > 0 && <em className="num">{faNum(count)}</em>}
    </button>
  );
}

/** Three-line menu: content sections first (same icons & colours as the dashboard), then tools. */
export function Drawer() {
  const open = useUi((s) => s.drawerOpen);
  const setDrawer = useUi((s) => s.setDrawer);
  const appName = usePrefs((s) => s.appName);
  const disguise = usePrefs((s) => s.disguise);
  const tab = useNav((s) => s.tab);
  const lock = useSession((s) => s.lock);
  const items = useSession((s) => s.items);
  useBack(open, BackPriority.drawer, () => setDrawer(false));
  const c = useMemo(() => {
    const r = { trash: 0, texts: 0, files: 0, images: 0, all: 0 };
    if (!open) return r;
    for (const i of items.values()) {
      if (i.deletedAt) r.trash++;
      else {
        r.all++;
        if (i.kind === 'text') r.texts++;
        else if (i.kind === 'image') r.images++;
        else r.files++;
      }
    }
    return r;
  }, [items, open]);
  const nav = useNav.getState();
  const go = (fn: () => void) => {
    setDrawer(false);
    setTimeout(fn, 60);
  };
  return (
    <div className={`drawer-layer${open ? ' open' : ''}`} aria-hidden={!open}>
      <div className="scrim" onClick={() => setDrawer(false)} />
      <aside className="drawer">
        <div className="drawer-head">
          <AppMark size={52} />
          <div>
            <b>{appName}</b>
            <small dir="ltr">AES-256 ENCRYPTED</small>
          </div>
        </div>
        <div className="drawer-list">
          <span className="drawer-sec">محتوای گاوصندوق</span>
          <DrawerItem icon="layers" hue="slate" label="همه موارد" count={c.all} onClick={() => go(() => nav.push({ name: 'all' }))} />
          <DrawerItem icon="files" hue="violet" label="فایل‌ها" count={c.files} active={tab === 'files'} onClick={() => go(() => nav.setTab('files'))} />
          <DrawerItem icon="images" hue="cyan" label="تصاویر" count={c.images} active={tab === 'images'} onClick={() => go(() => nav.setTab('images'))} />
          <DrawerItem icon="texts" hue="emerald" label="متن‌ها" count={c.texts} active={tab === 'texts'} onClick={() => go(() => nav.setTab('texts'))} />
          <DrawerItem icon="trash" hue="rose" label="سطل زباله" count={c.trash} onClick={() => go(() => nav.push({ name: 'trash' }))} />
          <span className="drawer-sec">ابزارها</span>
          <DrawerItem icon="backup" hue="cyan" label="پشتیبان‌گیری و بازیابی" onClick={() => go(() => nav.push({ name: 'backup' }))} />
          <DrawerItem icon="palette" hue="amber" label="ظاهر برنامه" onClick={() => go(() => nav.push({ name: 'appearance' }))} />
          <DrawerItem icon="settings" hue="slate" label="تنظیمات" active={tab === 'settings'} onClick={() => go(() => nav.setTab('settings'))} />
          <div className="drawer-item">
            <span className="di-ic hue-amber"><Icon name="calc" size={20} /></span>
            <span className="di-label">استتار ماشین‌حساب</span>
            <Switch checked={disguise} onChange={(v) => void setDisguise(v)} label="استتار ماشین‌حساب" />
          </div>
        </div>
        <Button variant="danger" icon="lock" block onClick={() => { setDrawer(false); lock(); }}>قفل کردن فوری</Button>
      </aside>
    </div>
  );
}

export function Toasts() {
  const toasts = useUi((s) => s.toasts);
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast ${t.kind}`}>
          <Icon name={t.kind === 'err' ? 'alert' : t.kind === 'info' ? 'info' : 'check'} size={18} />
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

export function ProgressOverlay() {
  const p = useUi((s) => s.progress);
  useBack(!!p, BackPriority.dialog + 10, () => undefined); // block back while working
  if (!p) return null;
  const pct = Math.round(Math.max(0, Math.min(1, p.value)) * 100);
  return (
    <div className="modal-layer shown">
      <div className="scrim" />
      <div className="dialog progress-dialog">
        <div className="pd-ring">{p.value < 0 ? <Spinner size={34} /> : <b className="num">{faNum(pct)}٪</b>}</div>
        <h3>{p.title}</h3>
        {p.detail && <p className="pd-detail">{p.detail}</p>}
        {p.value >= 0 && <div className="bar"><i style={{ width: `${pct}%` }} /></div>}
        {p.onCancel && <Button variant="ghost" className="small pd-cancel" icon="close" onClick={p.onCancel}>{p.cancelLabel ?? 'لغو'}</Button>}
      </div>
    </div>
  );
}

export function DialogHost() {
  const d = useUi((s) => s.dialog);
  const close = useUi((s) => s.closeDialog);
  const [value, setValue] = useState('');
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (d?.type === 'prompt') {
      setValue(d.value);
      setTimeout(() => ref.current?.select(), 200);
    } else setValue('');
  }, [d]);

  const cancel = () => {
    if (!d) return;
    if (d.type === 'confirm') d.resolve(false);
    else d.resolve(null);
    close();
  };
  const ok = () => {
    if (!d) return;
    if (d.type === 'confirm') d.resolve(true);
    else if (d.type === 'password') {
      if (!value) return;
      d.resolve(value);
    } else {
      // read the DOM value: an Android keyboard may still be composing the last word, and the
      // committed text would otherwise be missing from the saved name
      d.resolve(ref.current?.value ?? value);
    }
    close();
  };
  useBack(!!d, BackPriority.dialog, cancel);
  if (!d) return null;
  const danger = d.type === 'confirm' && d.danger;
  return (
    <div className="modal-layer shown">
      <div className="scrim" onClick={cancel} />
      <div className="dialog" role="alertdialog" aria-modal="true">
        {d.type === 'confirm' && d.icon && (
          <span className={`dialog-ic${danger ? ' danger' : ''}`}><Icon name={d.icon as IconName} size={26} /></span>
        )}
        <h3>{d.title}</h3>
        {d.message && <p>{d.message}</p>}
        {d.type === 'prompt' && (
          <input ref={ref} className="input" value={value} placeholder={d.placeholder} maxLength={d.maxLength} type={d.secret ? 'password' : 'text'} inputMode={d.numeric ? 'numeric' : undefined} autoComplete="off" onChange={(e) => setValue(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && !e.nativeEvent.isComposing && ok()} autoFocus dir={d.numeric ? 'ltr' : 'auto'} />
        )}
        {d.type === 'password' && <PasswordInput value={value} onChange={setValue} maxLength={PASSWORD_MAX} autoFocus onEnter={ok} />}
        <div className="dialog-actions">
          <Button variant="ghost" onClick={cancel}>{d.type === 'confirm' && d.cancelText ? d.cancelText : 'انصراف'}</Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={ok}>{d.confirmText ?? 'تأیید'}</Button>
        </div>
      </div>
    </div>
  );
}
