import { type ReactNode, useEffect, useRef, useState } from 'react';
import { Icon, type IconName } from './Icon';
import { BackPriority, useBack } from '../lib/back';

export function IconButton({ icon, label, onClick, variant = 'ghost', size = 22, className = '', disabled }: { icon: IconName; label: string; onClick?: (e: React.MouseEvent) => void; variant?: 'ghost' | 'tonal' | 'glass' | 'solid'; size?: number; className?: string; disabled?: boolean }) {
  return (
    <button type="button" className={`icon-btn ${variant} ${className}`} aria-label={label} title={label} onClick={onClick} disabled={disabled}>
      <Icon name={icon} size={size} />
    </button>
  );
}

export function Button({ children, icon, onClick, variant = 'primary', block, disabled, type = 'button', className = '' }: { children: ReactNode; icon?: IconName; onClick?: () => void; variant?: 'primary' | 'tonal' | 'ghost' | 'danger' | 'outline'; block?: boolean; disabled?: boolean; type?: 'button' | 'submit'; className?: string }) {
  return (
    <button type={type} className={`btn ${variant}${block ? ' block' : ''} ${className}`} onClick={onClick} disabled={disabled}>
      {icon && <Icon name={icon} size={20} />}
      <span>{children}</span>
    </button>
  );
}

export function TopBar({ title, subtitle, onBack, onMenu, actions, transparent }: { title: ReactNode; subtitle?: ReactNode; onBack?: () => void; onMenu?: () => void; actions?: ReactNode; transparent?: boolean }) {
  return (
    <header className={`topbar${transparent ? ' transparent' : ''}`}>
      {onBack && <IconButton icon="back" label="بازگشت" onClick={onBack} />}
      {onMenu && <IconButton icon="menu" label="منو" onClick={onMenu} />}
      <div className="topbar-title">
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
      <div className="topbar-actions">{actions}</div>
    </header>
  );
}

export function SearchField({ value, onChange, placeholder = 'جستجو...' }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="search-field">
      <Icon name="search" size={20} />
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} enterKeyHint="search" autoComplete="off" spellCheck={false} />
      {value && (
        <button type="button" className="clear" aria-label="پاک کردن" onClick={() => onChange('')}>
          <Icon name="close" size={16} />
        </button>
      )}
    </label>
  );
}

export function Chips<T extends string>({ options, value, onChange }: { options: { value: T; label: string; icon?: IconName; count?: number }[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="chips" role="tablist">
      {options.map((o) => (
        <button key={o.value} type="button" role="tab" aria-selected={o.value === value} className={`chip${o.value === value ? ' on' : ''}`} onClick={() => onChange(o.value)}>
          {o.icon && <Icon name={o.icon} size={16} />}
          <span>{o.label}</span>
          {o.count !== undefined && <em>{o.count.toLocaleString('fa-IR')}</em>}
        </button>
      ))}
    </div>
  );
}

export function Segmented<T extends string>({ options, value, onChange }: { options: { value: T; label: string; icon?: IconName }[]; value: T; onChange: (v: T) => void }) {
  const idx = Math.max(0, options.findIndex((o) => o.value === value));
  return (
    <div className="segmented" style={{ ['--n' as string]: options.length, ['--i' as string]: idx }}>
      <span className="seg-thumb" />
      {options.map((o) => (
        <button key={o.value} type="button" className={o.value === value ? 'on' : ''} onClick={() => onChange(o.value)}>
          {o.icon && <Icon name={o.icon} size={17} />}
          <span>{o.label}</span>
        </button>
      ))}
    </div>
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`switch${checked ? ' on' : ''}`} onClick={() => onChange(!checked)}>
      <span />
    </button>
  );
}

export function Empty({ icon, title, text, action }: { icon: IconName; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="empty">
      <div className="empty-art">
        <Icon name={icon} size={34} stroke={1.6} />
      </div>
      <h3>{title}</h3>
      {text && <p>{text}</p>}
      {action}
    </div>
  );
}

export function Spinner({ size = 22 }: { size?: number }) {
  return <span className="spinner" style={{ width: size, height: size }} />;
}

/** Bottom sheet with scrim, drag-safe animation and back-button support. */
export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title?: string; children: ReactNode }) {
  const [mounted, setMounted] = useState(open);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    if (open) {
      setMounted(true);
      const r = requestAnimationFrame(() => requestAnimationFrame(() => setShown(true)));
      return () => cancelAnimationFrame(r);
    }
    setShown(false);
    const t = setTimeout(() => setMounted(false), 240);
    return () => clearTimeout(t);
  }, [open]);
  useBack(open, BackPriority.sheet, onClose);
  if (!mounted) return null;
  return (
    <div className={`sheet-layer${shown ? ' shown' : ''}`}>
      <div className="scrim" onClick={onClose} />
      <div className="sheet" role="dialog" aria-modal="true">
        <div className="sheet-grip" />
        {title && <h3 className="sheet-title">{title}</h3>}
        {children}
      </div>
    </div>
  );
}

export function SheetItem({ icon, label, hint, onClick, danger, active }: { icon: IconName; label: string; hint?: string; onClick: () => void; danger?: boolean; active?: boolean }) {
  return (
    <button type="button" className={`sheet-item${danger ? ' danger' : ''}${active ? ' active' : ''}`} onClick={onClick}>
      <span className="si-icon">
        <Icon name={icon} size={20} />
      </span>
      <span className="si-text">
        <b>{label}</b>
        {hint && <small>{hint}</small>}
      </span>
      {active && <Icon name="check" size={20} className="si-check" />}
    </button>
  );
}

export function Card({ children, className = '', onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return onClick ? (
    <button type="button" className={`card tappable ${className}`} onClick={onClick}>
      {children}
    </button>
  ) : (
    <div className={`card ${className}`}>{children}</div>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
      {hint && <span className="field-hint">{hint}</span>}
    </label>
  );
}

export function PasswordInput({ value, onChange, placeholder, autoFocus, onEnter, maxLength }: { value: string; onChange: (v: string) => void; placeholder?: string; autoFocus?: boolean; onEnter?: () => void; maxLength: number }) {
  const [show, setShow] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (autoFocus) setTimeout(() => ref.current?.focus(), 250);
  }, [autoFocus]);
  return (
    <div className="pw-input">
      <Icon name="key" size={20} />
      <input
        ref={ref}
        type={show ? 'text' : 'password'}
        value={value}
        maxLength={maxLength}
        onChange={(e) => onChange([...e.target.value].slice(0, maxLength).join(''))}
        onKeyDown={(e) => e.key === 'Enter' && onEnter?.()}
        placeholder={placeholder}
        autoComplete="off"
        autoCapitalize="off"
        autoCorrect="off"
        spellCheck={false}
        dir="ltr"
      />
      <span className="pw-count">{[...value].length.toLocaleString('fa-IR')}/{maxLength.toLocaleString('fa-IR')}</span>
      <button type="button" className="pw-eye" aria-label={show ? 'پنهان کردن' : 'نمایش'} onClick={() => setShow(!show)}>
        <Icon name={show ? 'eyeOff' : 'eye'} size={20} />
      </button>
    </div>
  );
}
