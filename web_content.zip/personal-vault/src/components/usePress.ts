import { useRef } from 'react';
import { haptic } from '../lib/native';

/** Tap vs long-press detection with movement tolerance (for multi-select). */
export function usePress(onTap: () => void, onLong?: () => void, delay = 420) {
  const t = useRef<number | null>(null);
  const start = useRef<{ x: number; y: number } | null>(null);
  const fired = useRef(false);
  const clear = () => {
    if (t.current) window.clearTimeout(t.current);
    t.current = null;
  };
  return {
    onPointerDown: (e: React.PointerEvent) => {
      if (e.button !== 0) return;
      fired.current = false;
      start.current = { x: e.clientX, y: e.clientY };
      if (onLong)
        t.current = window.setTimeout(() => {
          fired.current = true;
          haptic(12);
          onLong();
        }, delay);
    },
    onPointerMove: (e: React.PointerEvent) => {
      if (!start.current) return;
      if (Math.abs(e.clientX - start.current.x) > 10 || Math.abs(e.clientY - start.current.y) > 10) {
        clear();
        start.current = null;
      }
    },
    onPointerUp: () => {
      clear();
      if (start.current && !fired.current) onTap();
      start.current = null;
    },
    onPointerCancel: () => {
      clear();
      start.current = null;
    },
    onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
  };
}
