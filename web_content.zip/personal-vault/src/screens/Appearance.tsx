import { setDisguise } from '../lib/disguise';
import { useEffect, useRef, useState } from 'react';
import { Icon, type IconName } from '../components/Icon';
import { CalcMark, VaultMark } from '../components/Brand';
import { Button, Field, Segmented, Switch, TopBar } from '../components/ui';
import { ACCENTS, DEFAULT_APP_NAME, DEFAULT_CALC_NAME, usePrefs, type Accent, type CalcStyle, type Surface, type ThemeMode } from '../store/prefs';
import { useNav } from '../store/nav';
import { useSession } from '../store/session';
import { openPicker, pickerDone, toast } from '../store/ui';
import { Calculator } from './Calculator';
import { squareIcon } from '../lib/thumbs';
import { getLauncherAlias, isNative, pinShortcut, setLauncherAlias } from '../lib/native';
import { faNum } from '../lib/format';
import { useResolvedTheme } from '../theme';

type Section = 'main' | 'calc' | 'identity';

function AccentPicker({ value, onChange }: { value: Accent; onChange: (a: Accent) => void }) {
  return (
    <div className="swatches">
      {(Object.keys(ACCENTS) as Accent[]).map((a) => (
        <button key={a} type="button" className={`swatch${a === value ? ' on' : ''}`} style={{ ['--sw' as string]: ACCENTS[a].dark }} onClick={() => onChange(a)} aria-label={ACCENTS[a].label}>
          {a === value && <Icon name="check" size={16} stroke={3} />}
          <span>{ACCENTS[a].label}</span>
        </button>
      ))}
    </div>
  );
}

const PREVIEW_NAV: { icon: IconName; label: string }[] = [
  { icon: 'dashboard', label: 'داشبورد' },
  { icon: 'files', label: 'فایل‌ها' },
  { icon: 'texts', label: 'متن‌ها' },
  { icon: 'images', label: 'تصاویر' },
  { icon: 'settings', label: 'تنظیمات' },
];

/** Scoped live preview of the main vault UI, rendered with the draft theme tokens. */
function VaultPreview({ name, mode, accent, surface }: { name: string; mode: 'dark' | 'light'; accent: Accent; surface: Surface }) {
  const items = useSession((s) => s.items);
  let f = 0, im = 0, t = 0;
  for (const i of items.values()) if (!i.deletedAt) i.kind === 'file' ? f++ : i.kind === 'image' ? im++ : t++;
  return (
    <div className="phone">
      <div className="phone-screen" data-theme={mode} data-accent={accent} data-surface={surface}>
        <div className="pv-top">
          <Icon name="menu" size={14} />
          <b>{name || DEFAULT_APP_NAME}</b>
          <Icon name="lock" size={14} />
        </div>
        <div className="pv-hero">
          <Icon name="shield" size={16} />
          <span>گاوصندوق باز و محافظت‌شده</span>
        </div>
        <div className="pv-cats">
          <span><Icon name="files" size={13} /><b>{faNum(f)}</b></span>
          <span><Icon name="images" size={13} /><b>{faNum(im)}</b></span>
          <span><Icon name="texts" size={13} /><b>{faNum(t)}</b></span>
        </div>
        <div className="pv-grid"><i /><i /><i /><i /></div>
        <div className="pv-nav">
          {PREVIEW_NAV.map((n, i) => (
            <span key={n.label} className={i === 0 ? 'on' : ''}>
              <i><Icon name={n.icon} size={13} /></i>
              <em>{n.label}</em>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function MainSection() {
  const p = usePrefs();
  const resolved = useResolvedTheme();
  const [name, setName] = useState(p.appName);
  const [mode, setMode] = useState<ThemeMode>(p.themeMode);
  const [accent, setAccent] = useState<Accent>(p.accent);
  const [surface, setSurface] = useState<Surface>(p.surface);
  const previewMode = mode === 'system' ? resolved : mode;
  const dirty = name !== p.appName || mode !== p.themeMode || accent !== p.accent || surface !== p.surface;
  return (
    <div className="ap-section">
      <div className="preview-stage"><VaultPreview name={name} mode={previewMode} accent={accent} surface={surface} /></div>
      <Field label="نام برنامه" hint="در سربرگ، صفحه قفل، منو و عنوان پنجره نمایش داده می‌شود.">
        <input className="input" value={name} maxLength={32} onChange={(e) => setName(e.target.value)} placeholder={DEFAULT_APP_NAME} />
      </Field>
      <Field label="حالت نمایش">
        <Segmented<ThemeMode> value={mode} onChange={setMode} options={[{ value: 'dark', label: 'تیره', icon: 'moon' }, { value: 'light', label: 'روشن', icon: 'sun' }, { value: 'system', label: 'سیستم', icon: 'monitor' }]} />
      </Field>
      <Field label="رنگ اصلی"><AccentPicker value={accent} onChange={setAccent} /></Field>
      <Field label="سبک سطوح">
        <Segmented<Surface> value={surface} onChange={setSurface} options={[{ value: 'glass', label: 'شیشه‌ای', icon: 'layers' }, { value: 'solid', label: 'یکدست', icon: 'appWindow' }]} />
      </Field>
      <div className="ap-actions">
        <Button variant="ghost" icon="refresh" onClick={() => { setName(DEFAULT_APP_NAME); setMode('dark'); setAccent('emerald'); setSurface('glass'); }}>پیش‌فرض</Button>
        <Button icon="check" disabled={!dirty} onClick={() => { p.set({ appName: name.trim() || p.appName, themeMode: mode, accent, surface }); toast('ظاهر برنامه اصلی اعمال شد'); }}>اعمال تغییرات</Button>
      </div>
    </div>
  );
}

const CALC_STYLES: { value: CalcStyle; label: string }[] = [
  { value: 'obsidian', label: 'ابسیدین' },
  { value: 'classic', label: 'کلاسیک' },
  { value: 'minimal', label: 'مینیمال' },
];

function CalcSection() {
  const p = usePrefs();
  const [name, setName] = useState(p.calcName);
  const [style, setStyle] = useState<CalcStyle>(p.calcStyle);
  const [accent, setAccent] = useState<Accent>(p.calcAccent);
  const dirty = name !== p.calcName || style !== p.calcStyle || accent !== p.calcAccent;
  return (
    <div className="ap-section">
      <div className="preview-stage">
        <div className="phone calc-phone">
          <div className="phone-screen calc-host">
            <Calculator preview name={name || DEFAULT_CALC_NAME} styleKey={style} accent={accent} />
          </div>
        </div>
        <p className="preview-hint"><Icon name="info" size={14} /> پیش‌نمایش واقعی است؛ می‌توانید محاسبه کنید. در حالت واقعی، ورود فقط با زدن رمز و سپس = انجام می‌شود.</p>
      </div>
      <Field label="نام ماشین‌حساب">
        <input className="input" value={name} maxLength={24} onChange={(e) => setName(e.target.value)} placeholder={DEFAULT_CALC_NAME} />
      </Field>
      <Field label="ظاهر ماشین‌حساب">
        <Segmented<CalcStyle> value={style} onChange={setStyle} options={CALC_STYLES} />
      </Field>
      <Field label="رنگ کلیدهای عملگر"><AccentPicker value={accent} onChange={setAccent} /></Field>
      <div className="toggle-card">
        <span className="toggle-mark"><CalcMark size={42} accent={ACCENTS[accent].dark} /></span>
        <span className="set-text">
          <b>باز شدن برنامه با ماشین‌حساب</b>
          <small>ورود به گاوصندوق: رمز را در ماشین‌حساب بزنید و سپس =</small>
        </span>
        <Switch checked={p.disguise} onChange={(v) => void setDisguise(v)} label="استتار" />
      </div>
      <div className="ap-actions">
        <Button variant="ghost" icon="refresh" onClick={() => { setName(DEFAULT_CALC_NAME); setStyle('obsidian'); setAccent('amber'); }}>پیش‌فرض</Button>
        <Button icon="check" disabled={!dirty} onClick={() => { p.set({ calcName: name.trim() || p.calcName, calcStyle: style, calcAccent: accent }); toast('ظاهر ماشین‌حساب اعمال شد'); }}>اعمال تغییرات</Button>
      </div>
    </div>
  );
}

function IdentitySection() {
  const p = usePrefs();
  const input = useRef<HTMLInputElement>(null);
  const [icon, setIcon] = useState<string | null>(p.iconDataUrl);
  const [name, setName] = useState('');
  const [alias, setAlias] = useState<'default' | 'calculator'>('default');
  const shownName = name.trim() || p.appName;

  useEffect(() => {
    void getLauncherAlias().then(setAlias);
  }, []);

  const onPick = async (file?: File) => {
    pickerDone();
    if (!file) return;
    try {
      setIcon(await squareIcon(file, 256));
    } catch {
      toast('این تصویر قابل استفاده نیست', 'err');
    }
  };

  const save = () => {
    p.set({ iconDataUrl: icon, appName: name.trim() ? name.trim() : p.appName });
    setName('');
    toast('نام و آیکون ذخیره شد');
  };

  const pin = async () => {
    if (!icon) return toast('ابتدا یک تصویر انتخاب کنید', 'info');
    try {
      const ok = await pinShortcut(shownName, icon);
      toast(ok ? 'درخواست افزودن به صفحه اصلی ارسال شد' : 'لانچر گوشی از افزودن میان‌بر پشتیبانی نمی‌کند', ok ? 'ok' : 'err');
    } catch {
      toast('افزودن میان‌بر ممکن نشد', 'err');
    }
  };

  const switchAlias = async (a: 'default' | 'calculator') => {
    try {
      await setLauncherAlias(a);
      setAlias(a);
      toast(a === 'calculator' ? 'آیکون لانچر به ماشین‌حساب تغییر کرد' : 'آیکون اصلی برنامه برگشت');
    } catch {
      toast('تغییر آیکون لانچر ممکن نشد', 'err');
    }
  };

  return (
    <div className="ap-section">
      <input ref={input} type="file" hidden accept="image/*" onChange={(e) => onPick(e.target.files?.[0])} />
      <div className="preview-stage">
        <div className="home-preview">
          <div className="hp-grid">
            <span className="hp-app ghost" /><span className="hp-app ghost" />
            <span className="hp-app main">
              <span className="hp-icon">{icon ? <img src={icon} alt="" /> : alias === 'calculator' ? <CalcMark size={58} /> : <VaultMark size={58} accent="#10b981" />}</span>
              <span className="hp-label">{alias === 'calculator' && !icon ? DEFAULT_CALC_NAME : shownName}</span>
            </span>
            <span className="hp-app ghost" />
          </div>
          <div className="hp-dock"><i /><i /><i /><i /></div>
        </div>
      </div>
      <div className="identity-row">
        <button type="button" className="icon-pick" onClick={() => openPicker(input.current)}>
          <span className="ip-img">{icon ? <img src={icon} alt="" /> : <Icon name="imagePlus" size={26} />}</span>
          <span><b>انتخاب از گالری</b><small>تصویر به‌صورت مربعی برش می‌خورد</small></span>
        </button>
        {icon && <Button variant="ghost" icon="trash" onClick={() => setIcon(null)}>حذف</Button>}
      </div>
      <Field label="نام جدید برنامه (اختیاری)" hint={`اگر خالی بماند، نام فعلی «${p.appName}» حفظ می‌شود.`}>
        <input className="input" value={name} maxLength={32} onChange={(e) => setName(e.target.value)} placeholder={p.appName} />
      </Field>
      <div className="ap-actions">
        <Button icon="check" block onClick={save} disabled={!name.trim() && icon === p.iconDataUrl}>ذخیره نام و آیکون</Button>
      </div>

      <div className="set-group">
        <h4>صفحه اصلی گوشی</h4>
        <button type="button" className="set-row" onClick={pin} disabled={!isNative}>
          <span className="set-ic hue-cyan"><Icon name="shortcut" size={20} /></span>
          <span className="set-text">
            <b>افزودن میان‌بر با این آیکون و نام</b>
            <small>{isNative ? 'میان‌بر واقعی Android (Pinned Shortcut) با تصویر و نام دلخواه' : 'فقط در نسخه Android'}</small>
          </span>
        </button>
        <div className="set-row">
          <span className="set-ic hue-amber"><Icon name="calc" size={20} /></span>
          <span className="set-text">
            <b>آیکون لانچر: ماشین‌حساب</b>
            <small>آیکون و نام اصلی برنامه در لانچر به «ماشین‌حساب» تغییر می‌کند</small>
          </span>
          <Switch checked={alias === 'calculator'} onChange={(v) => switchAlias(v ? 'calculator' : 'default')} label="آیکون ماشین‌حساب" />
        </div>
        <p className="field-hint">اندروید اجازه نمی‌دهد آیکون اصلی نصب‌شده در زمان اجرا با یک عکس دلخواه عوض شود؛ به همین دلیل تصویر دلخواه از طریق میان‌بر رسمی صفحه اصلی اعمال می‌شود و آیکون اصلی بین حالت «گاوصندوق» و «ماشین‌حساب» جابه‌جا می‌شود.</p>
      </div>
    </div>
  );
}

export function Appearance() {
  const nav = useNav.getState();
  const [sec, setSec] = useState<Section>('main');
  return (
    <div className="screen">
      <TopBar title="ظاهر برنامه" onBack={nav.pop} />
      <div className="ap-tabs">
        <Segmented<Section>
          value={sec}
          onChange={setSec}
          options={[
            { value: 'main', label: 'برنامه اصلی', icon: 'palette' },
            { value: 'calc', label: 'ماشین‌حساب', icon: 'calc' },
            { value: 'identity', label: 'نام و آیکون', icon: 'appWindow' },
          ]}
        />
      </div>
      <div className="scroll pad" key={sec}>
        <div className="fade-in">
          {sec === 'main' ? <MainSection /> : sec === 'calc' ? <CalcSection /> : <IdentitySection />}
        </div>
      </div>
    </div>
  );
}
