import { copyItemText, downloadItems, restoreFromTrash } from '../lib/actions';
import type { Item } from '../lib/types';
import { useNav } from '../store/nav';

/**
 * Opens an item inside the app:
 *  - images → swipeable viewer over the images of the current context
 *  - texts  → reader
 *  - files  → in-app preview (type detected from the file's bytes; images, PDF, audio,
 *             video, text, ZIP listing, or "open with" for everything else)
 */
export function openItem(item: Item, context: Item[]) {
  const nav = useNav.getState();
  if (item.kind === 'image') {
    const ids = context.filter((i) => i.kind === 'image' && !i.deletedAt).map((i) => i.id);
    if (!ids.includes(item.id)) ids.unshift(item.id);
    nav.push({ name: 'viewer', ids, index: Math.max(0, ids.indexOf(item.id)) });
  } else if (item.kind === 'text') nav.push({ name: 'textView', id: item.id });
  else nav.push({ name: 'preview', id: item.id });
}

export function quickAction(item: Item) {
  if (item.deletedAt) return void restoreFromTrash([item.id]);
  if (item.kind === 'text') return void copyItemText(item.id);
  return void downloadItems([item.id]);
}
