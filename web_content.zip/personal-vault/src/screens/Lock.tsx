import { useEffect, useState } from 'react';
import { Icon } from '../components/Icon';
import { Button, PasswordInput } from '../components/ui';
import { useSession, unlockDelayMs } from '../store/session';
import { usePrefs } from '../store/prefs';
import { PASSWORD_MAX, PASSWORD_MIN, PBKDF2_ITERATIONS, passwordStrength, validatePassword } from '../lib/crypto';
import { faNum } from '../lib/format';
import { Calculator } from './Calculator';
import { VaultMark } from '../components/Brand';
import { BackPriority, useBack } from '../lib/back';

export function AppMark({ size = 76 }: { size?: number }) {
  const icon = usePrefs((s) => s.iconDataUrl);
  return (
    <span className={`app-mark${icon ? ' custom' : ''}`} style={{ width: size, height: size }}>
      {icon ? <img src={icon} alt="" /> : <VaultMark size={size} />}
    </span>
  );
}

export function Setup() {
  const setup = useSession((s) => s.setup);
  const appName = usePrefs((s) => s.appName);
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const strength = passwordStrength(pw);

  const submit = async () => {
    const v = validatePassword(pw);
    if (v) return setErr(v);
    if (pw !== pw2) return setErr('تکرار رمز عبور مطابقت ندارد');
    setErr('');
    setBusy(true);
    try {
      await setup(pw);
    } catch (e) {
      setErr((e as Error).message || 'ساخت گاوصندوق ممکن نشد');
      setBusy(false);
    }
  };

  return (
    <div className="auth">
      <div className="auth-glow" />
      <div className="auth-card">
        <AppMark />
        <h1>{appName}</h1>
        <p className="auth-sub">یک رمز عبور برای گاوصندوق خود بسازید</p>
        <div className="auth-fields">
          <PasswordInput value={pw} onChange={setPw} placeholder="رمز عبور" maxLength={PASSWORD_MAX} autoFocus />
          <div className="strength" data-s={strength}>
            <i /><i /><i /><i />
            <span>{['خیلی ضعیف', 'ضعیف', 'متوسط', 'خوب', 'قوی'][strength]}</span>
          </div>
          <PasswordInput value={pw2} onChange={setPw2} placeholder="تکرار رمز عبور" maxLength={PASSWORD_MAX} onEnter={submit} />
          {err && <p className="auth-err">{err}</p>}
        </div>
        <Button icon="shield" block onClick={submit} disabled={busy}>
          {busy ? 'در حال ساخت کلیدهای رمزنگاری...' : 'ساخت گاوصندوق'}
        </Button>
        <ul className="auth-notes">
          <li><Icon name="key" size={16} /> رمز {faNum(PASSWORD_MIN)} تا {faNum(PASSWORD_MAX)} کاراکتر؛ هیچ‌جا ذخیره نمی‌شود</li>
          <li><Icon name="shield" size={16} /> AES-256-GCM + PBKDF2 با {faNum(PBKDF2_ITERATIONS)} تکرار</li>
          <li><Icon name="alert" size={16} /> رمز فراموش‌شده قابل بازیابی نیست؛ حتماً پشتیبان بگیرید</li>
        </ul>
      </div>
    </div>
  );
}

export function Unlock({ onBack }: { onBack?: () => void }) {
  const unlock = useSession((s) => s.unlock);
  const appName = usePrefs((s) => s.appName);
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [shake, setShake] = useState(0);
  const [wait, setWait] = useState(unlockDelayMs());
  useBack(!!onBack, BackPriority.route, () => onBack?.());

  useEffect(() => {
    if (wait <= 0) return;
    const t = setInterval(() => setWait(unlockDelayMs()), 1000);
    return () => clearInterval(t);
  }, [wait]);

  const submit = async () => {
    if (!pw || busy) return;
    setBusy(true);
    setErr('');
    try {
      await unlock(pw);
    } catch (e) {
      setErr((e as Error).message);
      setShake((s) => s + 1);
      setPw('');
      setWait(unlockDelayMs());
      setBusy(false);
    }
  };

  return (
    <div className="auth">
      <div className="auth-glow" />
      {onBack && (
        <button type="button" className="auth-back icon-btn ghost" aria-label="بازگشت" onClick={onBack}>
          <Icon name="back" size={22} />
        </button>
      )}
      <div className="auth-card" key={shake} data-shake={shake > 0}>
        <AppMark />
        <h1>{appName}</h1>
        <p className="auth-sub">
          <Icon name="lock" size={15} /> گاوصندوق قفل است
        </p>
        <div className="auth-fields">
          <PasswordInput value={pw} onChange={setPw} placeholder="رمز عبور" maxLength={PASSWORD_MAX} autoFocus onEnter={submit} />
          {err && <p className="auth-err">{err}</p>}
          {wait > 0 && <p className="auth-err">تا {faNum(Math.ceil(wait / 1000))} ثانیه دیگر امکان تلاش نیست</p>}
        </div>
        <Button icon="unlock" block onClick={submit} disabled={busy || !pw || wait > 0}>
          {busy ? 'در حال رمزگشایی...' : 'باز کردن قفل'}
        </Button>
      </div>
    </div>
  );
}

/** Locked root: either the calculator disguise or the password screen. */
export function LockedRoot() {
  const p = usePrefs();
  const unlockSilent = useSession((s) => s.unlockSilent);
  if (p.disguise && p.disguiseReady)
    return (
      <div className="calc-screen">
        <Calculator name={p.calcName} styleKey={p.calcStyle} accent={p.calcAccent} onSecret={(c) => void unlockSilent(c)} />
      </div>
    );
  return <Unlock />;
}
