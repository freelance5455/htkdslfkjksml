import { useRef, useState } from 'react';
import { Icon, type IconName } from '../components/Icon';
import { Button, Field, PasswordInput, Segmented, Sheet, SheetItem, Switch, TopBar } from '../components/ui';
import { usePrefs, type ThemeMode } from '../store/prefs';
import { useNav } from '../store/nav';
import { useSession, requireDek } from '../store/session';
import { confirmDialog, openPicker, passwordDialog, pickerDone, toast, useUi } from '../store/ui';
import { PASSWORD_MAX, PBKDF2_ITERATIONS, rewrapHeader, validatePassword, WrongPasswordError } from '../lib/crypto';
import { readHeader, writeHeader } from '../lib/db';
import { checkDisguiseAfterKeyChange, setDisguise } from '../lib/disguise';
import { setUninstallGuard } from '../lib/uninstallGuard';
import { faNum } from '../lib/format';
import { BackupError, backupFileName, createBackupStream, inspectBackup, restoreBackup } from '../lib/backup';
import { isNative, saveStream } from '../lib/native';
import { AppMark } from './Lock';
import { CalcMark } from '../components/Brand';

function Row({ icon, title, hint, onClick, right, hue = 'emerald' }: { icon: IconName; title: string; hint?: string; onClick?: () => void; right?: React.ReactNode; hue?: string }) {
  const inner = (
    <>
      <span className={`set-ic hue-${hue}`}><Icon name={icon} size={20} /></span>
      <span className="set-text">
        <b>{title}</b>
        {hint && <small>{hint}</small>}
      </span>
      {right ?? (onClick && <Icon name="chevron" size={18} className="set-chev" />)}
    </>
  );
  return onClick ? <button type="button" className="set-row" onClick={onClick}>{inner}</button> : <div className="set-row">{inner}</div>;
}

const AUTO_LOCK: { v: number; label: string }[] = [
  { v: 1, label: '۱ دقیقه' }, { v: 2, label: '۲ دقیقه' }, { v: 5, label: '۵ دقیقه' }, { v: 10, label: '۱۰ دقیقه' }, { v: 30, label: '۳۰ دقیقه' }, { v: 0, label: 'هرگز' },
];
const BG_LOCK: { v: number; label: string }[] = [
  { v: 0, label: 'بلافاصله' }, { v: 30, label: '۳۰ ثانیه' }, { v: 60, label: '۱ دقیقه' }, { v: 300, label: '۵ دقیقه' }, { v: -1, label: 'هرگز' },
];

export function Settings() {
  const p = usePrefs();
  const nav = useNav.getState();
  const lock = useSession((s) => s.lock);
  const count = useSession((s) => {
    let n = 0;
    for (const i of s.items.values()) if (!i.deletedAt) n++;
    return n;
  });
  const [sheet, setSheet] = useState<'auto' | 'bg' | null>(null);

  return (
    <div className="screen">
      <TopBar title="تنظیمات" onMenu={() => useUi.getState().setDrawer(true)} />
      <div className="scroll pad settings">
        <button type="button" className="appearance-card" onClick={() => nav.push({ name: 'appearance' })}>
          <div className="ap-previews">
            <span className="ap-mini vault"><AppMark size={46} /></span>
            <span className="ap-mini calc"><CalcMark size={46} /></span>
          </div>
          <div className="ap-text">
            <b>ظاهر برنامه</b>
            <small>برنامه اصلی، ماشین‌حساب، نام و آیکون</small>
          </div>
          <Icon name="chevron" size={20} />
        </button>

        <div className="set-group">
          <h4>حالت نمایش</h4>
          <Segmented<ThemeMode>
            value={p.themeMode}
            onChange={(themeMode) => p.set({ themeMode })}
            options={[
              { value: 'dark', label: 'تیره', icon: 'moon' },
              { value: 'light', label: 'روشن', icon: 'sun' },
              { value: 'system', label: 'سیستم', icon: 'monitor' },
            ]}
          />
        </div>

        <div className="set-group">
          <h4>امنیت</h4>
          <Row icon="timer" title="قفل خودکار پس از عدم فعالیت" hint={AUTO_LOCK.find((a) => a.v === p.autoLockMin)?.label} hue="cyan" onClick={() => setSheet('auto')} />
          <Row icon="lock" title="قفل هنگام رفتن به پس‌زمینه" hint={BG_LOCK.find((a) => a.v === p.bgLockSec)?.label} hue="violet" onClick={() => setSheet('bg')} />
          <Row icon="phoneOff" title="جلوگیری از اسکرین‌شات" hint="محتوا در Recent apps و اسکرین‌شات دیده نمی‌شود" hue="slate" right={<Switch checked={p.secureScreen} onChange={(v) => p.set({ secureScreen: v })} label="جلوگیری از اسکرین‌شات" />} />
          <Row icon="key" title="تغییر رمز عبور" hint="کلید داده‌ها (DEK) با رمز جدید دوباره Wrap می‌شود" onClick={() => nav.push({ name: 'security' })} />
          <Row icon="calc" title="استتار ماشین‌حساب" hint={p.disguise ? 'فعال: برنامه با ماشین‌حساب باز می‌شود' : 'غیرفعال'} hue="amber" right={<Switch checked={p.disguise} onChange={(v) => void setDisguise(v)} label="استتار ماشین‌حساب" />} />
          <Row icon="exit" title="تأیید پیش از خروج" hint={p.confirmExit ? 'فعال: خروج با دکمه بازگشت نیاز به تأیید دارد' : 'غیرفعال: خروج مستقیم با دکمه بازگشت'} hue="rose" right={<Switch checked={p.confirmExit} onChange={(v) => p.set({ confirmExit: v })} label="تأیید پیش از خروج" />} />
          <Row icon="shieldApp" title="محافظت در برابر حذف برنامه" hint={p.uninstallGuard ? 'فعال: حذف برنامه تا خاموش کردن این گزینه ممکن نیست' : 'غیرفعال: حذف برنامه مثل حالت عادی'} hue="emerald" right={<Switch checked={p.uninstallGuard} onChange={(v) => void setUninstallGuard(v)} label="محافظت در برابر حذف برنامه" />} />
        </div>

        <div className="set-group">
          <h4>داده‌ها</h4>
          <Row icon="layers" title="همه موارد" hint={`${faNum(count)} مورد`} hue="violet" onClick={() => nav.push({ name: 'all' })} />
          <Row icon="backup" title="پشتیبان‌گیری و بازیابی" hint="فایل رمزنگاری‌شده .pvault" hue="cyan" onClick={() => nav.push({ name: 'backup' })} />
          <Row icon="trash" title="سطل زباله" hue="rose" onClick={() => nav.push({ name: 'trash' })} />
        </div>

        <div className="set-group">
          <h4>درباره</h4>
          <Row icon="shield" title="رمزنگاری" hint={`AES-GCM 256 · PBKDF2-SHA256 × ${faNum(PBKDF2_ITERATIONS)} · DEK Wrapping`} />
          <Row icon="info" title="نسخه" hint="Personal Vault 2.2.0 · Local-first، بدون ارسال داده" hue="slate" />
        </div>

        <Button variant="tonal" icon="lock" block onClick={lock}>قفل کردن فوری</Button>
      </div>

      <Sheet open={sheet === 'auto'} onClose={() => setSheet(null)} title="قفل خودکار پس از عدم فعالیت">
        {AUTO_LOCK.map((a) => <SheetItem key={a.v} icon="timer" label={a.label} active={p.autoLockMin === a.v} onClick={() => { p.set({ autoLockMin: a.v }); setSheet(null); }} />)}
      </Sheet>
      <Sheet open={sheet === 'bg'} onClose={() => setSheet(null)} title="قفل هنگام خروج از برنامه">
        {BG_LOCK.map((a) => <SheetItem key={a.v} icon="lock" label={a.label} active={p.bgLockSec === a.v} onClick={() => { p.set({ bgLockSec: a.v }); setSheet(null); }} />)}
      </Sheet>
    </div>
  );
}

export function SecurityScreen() {
  const nav = useNav.getState();
  const [oldPw, setOld] = useState('');
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    const v = validatePassword(pw);
    if (v) return setErr(v);
    if (pw !== pw2) return setErr('تکرار رمز جدید مطابقت ندارد');
    setBusy(true);
    setErr('');
    try {
      const h = await readHeader();
      if (!h) throw new Error('گاوصندوق پیدا نشد');
      const nh = await rewrapHeader(h, oldPw, pw);
      await writeHeader(nh);
      toast('رمز عبور تغییر کرد');
      checkDisguiseAfterKeyChange(pw, !!nh.calc);
      nav.pop();
    } catch (e) {
      setErr(e instanceof WrongPasswordError ? 'رمز فعلی نادرست است' : (e as Error).message);
      setBusy(false);
    }
  };
  return (
    <div className="screen">
      <TopBar title="تغییر رمز عبور" onBack={nav.pop} />
      <div className="scroll pad form">
        <div className="info-banner">
          <Icon name="info" size={20} />
          <p>داده‌ها دوباره رمزنگاری نمی‌شوند؛ فقط کلید داده‌ها (DEK) با کلید مشتق‌شده از رمز جدید Wrap می‌شود. پشتیبان‌های قبلی همچنان با رمز قبلی باز می‌شوند.</p>
        </div>
        <Field label="رمز فعلی"><PasswordInput value={oldPw} onChange={setOld} maxLength={PASSWORD_MAX} autoFocus /></Field>
        <Field label="رمز جدید"><PasswordInput value={pw} onChange={setPw} maxLength={PASSWORD_MAX} /></Field>
        <Field label="تکرار رمز جدید"><PasswordInput value={pw2} onChange={setPw2} maxLength={PASSWORD_MAX} onEnter={submit} /></Field>
        {err && <p className="auth-err">{err}</p>}
        <Button icon="key" block onClick={submit} disabled={busy || !oldPw || !pw}>{busy ? 'در حال مشتق‌سازی کلید...' : 'تغییر رمز'}</Button>
      </div>
    </div>
  );
}

export function BackupScreen() {
  const nav = useNav.getState();
  const appName = usePrefs((s) => s.appName);
  const input = useRef<HTMLInputElement>(null);
  const lock = useSession((s) => s.lock);
  const items = useSession((s) => s.items.size);
  const ui = useUi();
  const [last, setLast] = useState<string | null>(null);

  const doBackup = async () => {
    const dek = requireDek();
    const name = backupFileName(appName);
    ui.setProgress({ title: 'ساخت پشتیبان رمزنگاری‌شده', detail: name, value: 0 });
    try {
      const path = await saveStream(name, 'application/octet-stream', createBackupStream(dek, (f) => useUi.getState().setProgress({ title: 'ساخت پشتیبان رمزنگاری‌شده', detail: name, value: f })));
      setLast(path);
      toast('پشتیبان در Download/PersonalVault ذخیره شد');
    } catch (e) {
      toast(e instanceof BackupError ? e.message : 'ساخت پشتیبان ناموفق بود', 'err');
    } finally {
      ui.setProgress(null);
    }
  };

  const onFile = async (file: File | undefined) => {
    pickerDone();
    if (!file) return;
    const pw = await passwordDialog({ title: 'رمز عبور پشتیبان', message: 'رمزی که هنگام ساخت این پشتیبان روی گاوصندوق فعال بود را وارد کنید.', confirmText: 'بررسی پشتیبان' });
    if (!pw) return;
    ui.setProgress({ title: 'بررسی اعتبار پشتیبان', detail: file.name, value: -1 });
    let inspected: Awaited<ReturnType<typeof inspectBackup>>;
    try {
      inspected = await inspectBackup(file, pw);
    } catch (e) {
      ui.setProgress(null);
      toast(e instanceof BackupError ? e.message : 'فایل پشتیبان معتبر نیست', 'err');
      return;
    }
    ui.setProgress(null);
    const c = inspected.info.manifest.counts;
    const ok = await confirmDialog({
      title: 'جایگزینی داده‌های فعلی',
      message: `پشتیبان معتبر است (${faNum(c.items)} مورد). داده‌های فعلی (${faNum(items)} مورد) با محتوای پشتیبان جایگزین می‌شوند و رمز گاوصندوق همان رمز پشتیبان خواهد شد. داده‌های فعلی تنها پس از تأیید کامل پشتیبان حذف می‌شوند.`,
      confirmText: 'بازیابی',
      danger: true,
      icon: 'restore',
    });
    if (!ok) return;
    try {
      const r = await restoreBackup(file, inspected.info, inspected.dek, (f, phase) => useUi.getState().setProgress({ title: phase, detail: file.name, value: f }));
      ui.setProgress(null);
      toast(`${faNum(r.items)} مورد بازیابی شد؛ با رمز پشتیبان وارد شوید`);
      checkDisguiseAfterKeyChange(pw, false);
      lock();
    } catch (e) {
      ui.setProgress(null);
      toast(e instanceof BackupError ? `${e.message}؛ داده‌های فعلی دست نخورد` : 'بازیابی ناموفق بود؛ داده‌های فعلی دست نخورد', 'err');
    }
  };

  return (
    <div className="screen">
      <TopBar title="پشتیبان‌گیری و بازیابی" onBack={nav.pop} />
      <input ref={input} type="file" hidden accept=".pvault,application/octet-stream,*/*" onChange={(e) => onFile(e.target.files?.[0])} />
      <div className="scroll pad form">
        <div className="backup-hero">
          <span className="bh-ic"><Icon name="backup" size={30} /></span>
          <h2>پشتیبان رمزنگاری‌شده</h2>
          <p>تمام داده‌ها به‌صورت رمزنگاری‌شده و بدون رمزگشایی کپی می‌شوند. هر رکورد با SHA-256 و فهرست احراز‌هویت‌شده (AES-GCM) بررسی می‌شود.</p>
        </div>
        <Button icon="download" block onClick={doBackup}>ساخت فایل پشتیبان</Button>
        {last && <p className="field-hint center-text">آخرین پشتیبان: <span dir="ltr">{last}</span></p>}
        <Button icon="upload" variant="tonal" block onClick={() => openPicker(input.current)}>بازیابی از فایل پشتیبان</Button>
        <ul className="auth-notes">
          <li><Icon name="shield" size={16} /> فایل خراب، ناقص یا دستکاری‌شده رد می‌شود و بازیابی متوقف می‌شود.</li>
          <li><Icon name="layers" size={16} /> بازیابی ابتدا در یک پایگاه موقت انجام می‌شود؛ داده‌های فعلی تا تأیید کامل دست نمی‌خورند.</li>
          <li><Icon name="key" size={16} /> برای بازیابی، رمز زمان ساخت پشتیبان لازم است.</li>
          {!isNative && <li><Icon name="info" size={16} /> در مرورگر، فایل در پوشه دانلود مرورگر ذخیره می‌شود.</li>}
        </ul>
      </div>
    </div>
  );
}

