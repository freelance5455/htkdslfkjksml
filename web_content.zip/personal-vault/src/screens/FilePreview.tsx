import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon, type IconName } from '../components/Icon';
import { Button, Empty, IconButton, Sheet, SheetItem, Spinner, TopBar } from '../components/ui';
import { VirtualList } from '../components/VirtualList';
import { useNav } from '../store/nav';
import { useSession } from '../store/session';
import { confirmDialog, mediaHold, promptDialog, toast, useUi } from '../store/ui';
import { detectType, listZip, prepareTemp, readTextPreview, TEXT_PREVIEW_LIMIT, type ZipEntry, type ZipListing } from '../lib/preview';
import { isWebImage, kindLabel, type PreviewKind } from '../lib/sniff';
import { isNative, openExternal, pdf, type TempFile } from '../lib/native';
import { openStream, type StreamHandle } from '../lib/stream';
import { VideoViewer, fmtTime, SPEEDS } from '../viewers/VideoViewer';
import { PdfViewer, openNativePdf } from '../viewers/PdfViewer';
import { downloadItems, moveToTrash, renameItem } from '../lib/actions';
import { faNum, fileVisual, formatDateTime, formatSize } from '../lib/format';
import type { Item } from '../lib/types';

type Detected = { mime: string; kind: PreviewKind };

const KIND_ICON: Record<PreviewKind, IconName> = {
  image: 'image', pdf: 'fileText', audio: 'audio', video: 'video', text: 'fileText', archive: 'archive', document: 'fileText', other: 'file',
};

/** Items the preview must never try to render internally (always "open with" / download). */
const ZIP_LISTABLE = new Set(['application/zip', 'application/java-archive']);

// ---------------------------------------------------------------- open with (Android chooser)

async function openWithOtherApp(item: Item, mime: string) {
  if (!isNative) {
    toast('باز کردن با برنامه دیگر فقط در نسخه Android در دسترس است', 'info');
    return;
  }
  const ui = useUi.getState();
  const signal = { cancelled: false };
  const title = 'آماده‌سازی امن برای برنامه دیگر';
  ui.setProgress({ title, detail: item.name, value: 0, onCancel: () => (signal.cancelled = true), cancelLabel: 'لغو' });
  let temp: TempFile | null = null;
  try {
    temp = await prepareTemp(item, mime, {
      shared: true,
      signal,
      onProgress: (f) => ui.setProgress({ title, detail: item.name, value: f, onCancel: () => (signal.cancelled = true), cancelLabel: 'لغو' }),
    });
    ui.setProgress(null);
    // keep the auto-lock from wiping the copy while the chooser is shown
    useUi.setState({ pickerActiveUntil: Date.now() + 5_000 });
    const opened = await openExternal(temp.id, mime, item.name);
    if (!opened) {
      toast('برنامه‌ای برای باز کردن این نوع فایل روی گوشی پیدا نشد', 'err');
      await temp.release();
    }
  } catch (e) {
    ui.setProgress(null);
    await temp?.release();
    if ((e as Error)?.message !== 'CANCELLED') toast('آماده‌سازی فایل ممکن نشد', 'err');
  }
}

// ---------------------------------------------------------------- streaming hook (video, audio, pdf, images)

type StreamState = { phase: 'open' } | { phase: 'ready'; s: StreamHandle } | { phase: 'error' };

/**
 * Opens an on-demand decryption stream for the file: nothing is decrypted up-front, the player
 * pulls (and we decrypt) only the chunks it actually reads. Closed when the viewer closes.
 */
function useStream(item: Item, mime: string): StreamState {
  const [st, setSt] = useState<StreamState>({ phase: 'open' });
  useEffect(() => {
    let alive = true;
    let h: StreamHandle | null = null;
    openStream(item, playableMime(mime))
      .then((s) => {
        if (!s) throw new Error('NO_STREAM');
        h = s;
        if (alive) setSt({ phase: 'ready', s });
        else s.close();
      })
      .catch(() => alive && setSt({ phase: 'error' }));
    return () => {
      alive = false;
      h?.close();
    };
  }, [item.id, item.chunks, item.size, mime]); // eslint-disable-line react-hooks/exhaustive-deps
  return st;
}

/** Container labels the WebView media stack accepts for the same bytes. */
function playableMime(m: string): string {
  if (m === 'video/quicktime') return 'video/mp4';
  if (m === 'video/x-matroska') return 'video/webm';
  if (m === 'audio/x-matroska') return 'audio/webm';
  return m;
}

function Preparing({ f, item, label }: { f: number; item: Item; label: string }) {
  const pct = Math.round(Math.max(0, Math.min(1, f)) * 100);
  return (
    <div className="pv-center">
      <div className="pv-prep">
        <div className="pd-ring"><b className="num">{faNum(pct)}٪</b></div>
        <h3>{label}</h3>
        <p>رمزگشایی امن در حافظه موقت برنامه · {formatSize(item.size)}</p>
        <div className="bar"><i style={{ width: `${pct}%` }} /></div>
      </div>
    </div>
  );
}

function Failure({ item, mime, text }: { item: Item; mime: string; text: string }) {
  return (
    <div className="pv-center">
      <Empty icon="alert" title={text} text="می‌توانید فایل را با برنامه دیگری باز کنید یا آن را دانلود کنید." action={<FallbackActions item={item} mime={mime} />} />
    </div>
  );
}

function FallbackActions({ item, mime }: { item: Item; mime: string }) {
  return (
    <div className="pv-actions">
      {isNative && <Button icon="shortcut" onClick={() => void openWithOtherApp(item, mime)}>باز کردن با برنامه دیگر</Button>}
      <Button icon="download" variant="tonal" onClick={() => void downloadItems([item.id])}>دانلود</Button>
    </div>
  );
}

// ---------------------------------------------------------------- media hold (inactivity lock)

function useMediaHold(ref: React.RefObject<HTMLMediaElement | null>, url: string) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // (re)attach the source: a previous cleanup detaches it to free the decoder/file handle
    if (el.getAttribute('src') !== url) {
      el.setAttribute('src', url);
      el.load();
    }
    let held = false;
    const on = () => {
      if (!held) (held = true), mediaHold(true);
    };
    const off = () => {
      if (held) (held = false), mediaHold(false);
    };
    el.addEventListener('playing', on);
    el.addEventListener('pause', off);
    el.addEventListener('ended', off);
    el.addEventListener('error', off);
    return () => {
      off();
      el.removeEventListener('playing', on);
      el.removeEventListener('pause', off);
      el.removeEventListener('ended', off);
      el.removeEventListener('error', off);
      // release the decoder and the file handle immediately
      el.pause();
      el.removeAttribute('src');
      el.load();
    };
  }, [ref, url]);
}

// ---------------------------------------------------------------- video

function VideoPreview({ item, mime, onBack, extraSheet }: { item: Item; mime: string; onBack: () => void; extraSheet: (close: () => void) => React.ReactNode }) {
  const st = useStream(item, mime);
  const [err, setErr] = useState<string | null>(null);
  const subtitle = `${kindLabel('video', mime)} · ${formatSize(item.size)}`;
  if (st.phase === 'error' || err)
    return (
      <div className="screen preview-screen media">
        <TopBar title={item.name} subtitle={subtitle} onBack={onBack} />
        <div className="pv-body"><Failure item={item} mime={mime} text={err ?? 'باز کردن ویدیو ممکن نشد'} /></div>
      </div>
    );
  if (st.phase === 'open') return <div className="vw vw-video"><span className="vv-buffer"><Spinner size={38} /></span></div>;
  return <VideoViewer url={st.s.url} title={item.name} subtitle={subtitle} onBack={onBack} onError={setErr} extraSheet={extraSheet} />;
}

// ---------------------------------------------------------------- audio

function AudioPreview({ item, mime }: { item: Item; mime: string }) {
  const st = useStream(item, mime);
  if (st.phase === 'open') return <div className="pv-center"><Spinner size={30} /></div>;
  if (st.phase === 'error') return <Failure item={item} mime={mime} text="باز کردن فایل صوتی ممکن نشد" />;
  return <AudioPlayer url={st.s.url} item={item} mime={mime} />;
}

function AudioPlayer({ url, item, mime }: { url: string; item: Item; mime: string }) {
  const ref = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [dur, setDur] = useState(NaN);
  const [buffering, setBuffering] = useState(true);
  const [err, setErr] = useState(false);
  const [speed, setSpeed] = useState(3); // index of 1× in SPEEDS
  const [loop, setLoop] = useState(false);
  const seeking = useRef(false);
  useMediaHold(ref, url);

  useEffect(() => {
    const a = ref.current;
    if (!a) return;
    let raf = 0;
    const tick = () => {
      if (!seeking.current) setTime(a.currentTime);
      raf = requestAnimationFrame(tick);
    };
    const onPlay = () => {
      setPlaying(true);
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(tick);
    };
    const onPause = () => {
      setPlaying(false);
      cancelAnimationFrame(raf);
      setTime(a.currentTime);
    };
    const onMeta = () => {
      setDur(a.duration);
      setBuffering(false);
    };
    const onWait = () => setBuffering(true);
    const onCan = () => setBuffering(false);
    a.addEventListener('play', onPlay);
    a.addEventListener('pause', onPause);
    a.addEventListener('ended', onPause);
    a.addEventListener('loadedmetadata', onMeta);
    a.addEventListener('durationchange', onMeta);
    a.addEventListener('waiting', onWait);
    a.addEventListener('canplay', onCan);
    return () => {
      cancelAnimationFrame(raf);
      a.removeEventListener('play', onPlay);
      a.removeEventListener('pause', onPause);
      a.removeEventListener('ended', onPause);
      a.removeEventListener('loadedmetadata', onMeta);
      a.removeEventListener('durationchange', onMeta);
      a.removeEventListener('waiting', onWait);
      a.removeEventListener('canplay', onCan);
    };
  }, []);

  const toggle = () => {
    const a = ref.current;
    if (!a) return;
    if (a.paused) void a.play().catch(() => setErr(true));
    else a.pause();
  };
  const skip = (d: number) => {
    const a = ref.current;
    if (!a || !Number.isFinite(a.duration)) return;
    a.currentTime = Math.max(0, Math.min(a.duration, a.currentTime + d));
    setTime(a.currentTime);
  };
  const cycleSpeed = () => {
    const n = (speed + 1) % SPEEDS.length;
    setSpeed(n);
    if (ref.current) ref.current.playbackRate = SPEEDS[n];
  };
  const toggleLoop = () => {
    setLoop(!loop);
    if (ref.current) ref.current.loop = !loop;
  };

  if (err) return <Failure item={item} mime={mime} text="این قالب صوتی در برنامه پشتیبانی نمی‌شود" />;
  const pct = Number.isFinite(dur) && dur > 0 ? (time / dur) * 100 : 0;
  return (
    <div className="pv-audio">
      <audio ref={ref} src={url} preload="metadata" onError={() => setErr(true)} />
      <div className={`ap-art${playing ? ' playing' : ''}`}>
        <span className="ap-ring r1" />
        <span className="ap-ring r2" />
        <span className="ap-disc"><Icon name="music" size={46} stroke={1.6} /></span>
      </div>
      <div className="ap-meta">
        <b>{item.name}</b>
        <small>{kindLabel('audio', mime)} · {item.ext ? item.ext.toUpperCase() : mime.split('/')[1]?.toUpperCase()} · <span className="num">{formatSize(item.size)}</span></small>
      </div>
      <div className="ap-seek" dir="ltr">
        <input
          type="range"
          min={0}
          max={Number.isFinite(dur) ? dur : 0}
          step="any"
          value={Math.min(time, Number.isFinite(dur) ? dur : 0)}
          style={{ ['--p' as string]: `${pct}%` }}
          aria-label="موقعیت پخش"
          onPointerDown={() => (seeking.current = true)}
          onPointerUp={() => (seeking.current = false)}
          onChange={(e) => {
            const v = Number(e.target.value);
            setTime(v);
            if (ref.current) ref.current.currentTime = v;
          }}
        />
        <div className="ap-times num"><span>{fmtTime(time)}</span><span>{fmtTime(dur)}</span></div>
      </div>
      <div className="ap-controls" dir="ltr">
        <button type="button" className="ap-small" onClick={toggleLoop} aria-label="تکرار" aria-pressed={loop}><Icon name="repeat" size={20} className={loop ? 'on' : ''} /></button>
        <button type="button" className="ap-btn" onClick={() => skip(-10)} aria-label="۱۰ ثانیه عقب"><Icon name="rewind10" size={26} /></button>
        <button type="button" className="ap-play" onClick={toggle} aria-label={playing ? 'توقف' : 'پخش'}>
          {buffering && !playing && !Number.isFinite(dur) ? <Spinner size={28} /> : <Icon name={playing ? 'pause' : 'play'} size={32} stroke={2.2} />}
        </button>
        <button type="button" className="ap-btn" onClick={() => skip(10)} aria-label="۱۰ ثانیه جلو"><Icon name="forward10" size={26} /></button>
        <button type="button" className="ap-small speed num" onClick={cycleSpeed} aria-label="سرعت پخش">{SPEEDS[speed]}×</button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- pdf

type PdfState = { phase: 'open' } | { phase: 'native'; handle: string; count: number; first: { w: number; h: number } } | { phase: 'web'; url: string } | { phase: 'prep'; f: number } | { phase: 'error' };

function PdfPreview({ item, mime, onBack, onMenu }: { item: Item; mime: string; onBack: () => void; onMenu: () => void }) {
  const [st, setSt] = useState<PdfState>({ phase: 'open' });
  useEffect(() => {
    let alive = true;
    let stream: StreamHandle | null = null;
    let temp: TempFile | null = null;
    let handle: string | null = null;
    (async () => {
      stream = await openStream(item, 'application/pdf');
      if (!isNative) {
        if (!stream) throw new Error('NO_STREAM');
        if (alive) setSt({ phase: 'web', url: stream.url });
        return;
      }
      const d = await openNativePdf(stream?.token ?? null, async () => {
        // Android 7 and older have no seekable proxy descriptors: private temp copy instead
        temp = await prepareTemp(item, mime, { onProgress: (f) => alive && setSt({ phase: 'prep', f }) });
        return temp.id;
      });
      handle = d.handle;
      if (alive) setSt({ phase: 'native', ...d });
      else void pdf.close(d.handle);
    })().catch(() => alive && setSt({ phase: 'error' }));
    return () => {
      alive = false;
      if (handle) void pdf.close(handle);
      stream?.close();
      void temp?.release();
    };
  }, [item.id, item.chunks, item.size]); // eslint-disable-line react-hooks/exhaustive-deps
  const subtitle = `${kindLabel('pdf', mime)} · ${formatSize(item.size)}`;
  if (st.phase === 'native') return <PdfViewer handle={st.handle} count={st.count} first={st.first} title={item.name} subtitle={subtitle} onBack={onBack} onMenu={onMenu} />;
  const body =
    st.phase === 'web' ? <iframe className="pv-frame" src={st.url} title={item.name} /> :
    st.phase === 'prep' ? <Preparing f={st.f} item={item} label="آماده‌سازی سند PDF" /> :
    st.phase === 'error' ? <Failure item={item} mime={mime} text="این سند PDF قابل نمایش نیست (ممکن است رمزدار یا خراب باشد)" /> :
    <div className="pv-center"><Spinner size={30} /></div>;
  return (
    <div className="screen preview-screen">
      <TopBar title={item.name} subtitle={subtitle} onBack={onBack} actions={<IconButton icon="more" label="گزینه‌ها" onClick={onMenu} />} />
      <div className="pv-body">{body}</div>
    </div>
  );
}

// ---------------------------------------------------------------- text

function TextPreview({ item, mime }: { item: Item; mime: string }) {
  const [st, setSt] = useState<{ text: string; truncated: boolean } | null>(null);
  const [err, setErr] = useState(false);
  const [wrap, setWrap] = useState(true);
  useEffect(() => {
    let alive = true;
    readTextPreview(item)
      .then((r) => alive && setSt(r))
      .catch(() => alive && setErr(true));
    return () => {
      alive = false;
    };
  }, [item.id, item.chunks]); // eslint-disable-line react-hooks/exhaustive-deps
  // split into blocks so the browser can skip layout of off-screen parts (content-visibility)
  const blocks = useMemo(() => {
    if (!st) return [];
    const lines = st.text.split('\n');
    const out: string[] = [];
    for (let i = 0; i < lines.length; i += 120) out.push(lines.slice(i, i + 120).join('\n'));
    return out;
  }, [st]);
  if (err) return <Failure item={item} mime={mime} text="خواندن متن ممکن نشد" />;
  if (!st) return <div className="pv-center"><Spinner size={30} /></div>;
  const code = mime !== 'text/plain' && mime !== 'text/markdown';
  return (
    <div className="scroll pv-text-wrap">
      <div className="pv-text-tools">
        <span>{kindLabel('text', mime)} · <span className="num">{formatSize(item.size)}</span></span>
        <button type="button" className={`tool${wrap ? ' on' : ''}`} onClick={() => setWrap(!wrap)}><Icon name="text" size={16} /> شکستن خطوط</button>
      </div>
      {st.truncated && (
        <div className="info-banner"><Icon name="info" size={18} /><p>فقط {formatSize(TEXT_PREVIEW_LIMIT)} ابتدای فایل نمایش داده می‌شود. برای مشاهده کامل، فایل را با برنامه دیگری باز کنید.</p></div>
      )}
      <div className={`pv-text${wrap ? ' wrap' : ''}${code ? ' code' : ''}`} dir="auto">
        {blocks.length === 0 || (blocks.length === 1 && !blocks[0]) ? <span className="pv-muted">فایل خالی است</span> : blocks.map((b, i) => <pre key={i} dir="auto">{b}</pre>)}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- zip

function ZipPreview({ item, mime }: { item: Item; mime: string }) {
  const [z, setZ] = useState<ZipListing | null>(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    let alive = true;
    listZip(item)
      .then((r) => alive && setZ(r))
      .catch(() => alive && setErr(true));
    return () => {
      alive = false;
    };
  }, [item.id, item.chunks]); // eslint-disable-line react-hooks/exhaustive-deps
  const rows = useMemo(() => (z ? z.entries.map((e, i) => ({ key: `z${i}`, e })) : []), [z]);
  if (err) return <InfoPanel item={item} mime={mime} kind="archive" note="فهرست محتوای این فایل فشرده خوانده نشد (ممکن است ناقص یا از نوع دیگری باشد)." />;
  if (!z) return <div className="pv-center"><Spinner size={30} /></div>;
  const files = z.entries.filter((e) => !e.dir).length;
  const header = (
    <div className="zip-head">
      <div className="zip-card">
        <span className="file-badge big hue-amber"><Icon name="archive" size={28} /><i>ZIP</i></span>
        <div>
          <b>{faNum(files)} فایل{z.entries.length > files ? ` · ${faNum(z.entries.length - files)} پوشه` : ''}</b>
          <small>حجم فشرده <span className="num">{formatSize(item.size)}</span> · حجم باز شده <span className="num">{formatSize(z.unpacked)}</span></small>
        </div>
      </div>
      <div className="info-banner"><Icon name="info" size={18} /><p>محتوای فایل فشرده فقط فهرست می‌شود و هیچ فایلی از آن استخراج نمی‌شود. برای استخراج، آن را با برنامه مدیریت فایل باز کنید یا دانلود کنید.</p></div>
      <FallbackActions item={item} mime={mime} />
      {z.truncated && <p className="field-hint">فقط {faNum(z.entries.length)} مورد اول از {faNum(z.total)} نمایش داده شده است.</p>}
    </div>
  );
  return <VirtualList rows={rows} height={zipRowH} render={(r) => <ZipRow e={r.e} />} header={header} footerSpace={40} />;
}
const zipRowH = () => 62;
function ZipRow({ e }: { e: ZipEntry }) {
  const parts = e.name.replace(/\/$/, '').split('/');
  const name = parts.pop() || e.name;
  const dir = parts.join('/');
  const v = fileVisual(name.includes('.') ? name.split('.').pop()! : '', '');
  return (
    <div className="zip-row">
      <span className={`zr-ic hue-${e.dir ? 'amber' : v.hue}`}><Icon name={e.dir ? 'files' : v.icon} size={18} /></span>
      <span className="row-main">
        <b dir="auto">{name}</b>
        <small dir="auto">{e.dir ? 'پوشه' : formatSize(e.size)}{dir ? ` · ${dir}` : ''}{e.encrypted ? ' · رمزدار' : ''}</small>
      </span>
    </div>
  );
}

// ---------------------------------------------------------------- generic info

function InfoPanel({ item, mime, kind, note }: { item: Item; mime: string; kind: PreviewKind; note?: string }) {
  const v = fileVisual(item.ext, mime);
  const hint =
    note ??
    (kind === 'archive'
      ? 'فایل‌های فشرده داخل برنامه باز نمی‌شوند؛ برای استخراج از برنامه مدیریت فایل استفاده کنید.'
      : kind === 'document'
        ? 'این سند برای نمایش به برنامه تخصصی (مثل Word، Excel یا PowerPoint) نیاز دارد.'
        : kind === 'image'
          ? 'این قالب تصویر توسط نمایشگر داخلی پشتیبانی نمی‌شود.'
          : 'پیش‌نمایش داخلی برای این نوع فایل در دسترس نیست.');
  return (
    <div className="scroll pad">
      <div className="pv-info">
        <span className={`file-badge xl hue-${v.hue}`}><Icon name={KIND_ICON[kind]} size={40} stroke={1.6} /><i>{v.label}</i></span>
        <h2 dir="auto">{item.name}</h2>
        <p>{kindLabel(kind, mime)} · <span className="num">{formatSize(item.size)}</span></p>
        <div className="info-grid pv-grid">
          <span>نوع واقعی</span><b dir="ltr">{mime}</b>
          {item.declaredMime && item.declaredMime !== mime && <><span>نوع اعلام‌شده</span><b dir="ltr">{item.declaredMime}</b></>}
          <span>افزوده‌شده</span><b>{formatDateTime(item.createdAt)}</b>
          <span>رمزنگاری</span><b>AES-256-GCM · {faNum(item.chunks)} بخش</b>
        </div>
        <p className="pv-note"><Icon name="info" size={16} /> {hint}</p>
        <FallbackActions item={item} mime={mime} />
        {isNative && <p className="field-hint center-text">برای باز کردن با برنامه دیگر، یک نسخه موقت در حافظه خصوصی برنامه ساخته می‌شود و هنگام قفل شدن گاوصندوق پاک می‌شود.</p>}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- screen

export function FilePreview({ id, info }: { id: string; info?: boolean }) {
  const nav = useNav.getState();
  const item = useSession((s) => s.items.get(id));
  const [type, setType] = useState<Detected | null>(null);
  const [err, setErr] = useState(false);
  const [menu, setMenu] = useState(false);
  const itemRef = useRef(item);
  itemRef.current = item;

  useEffect(() => {
    const it = itemRef.current;
    if (!it) return;
    let alive = true;
    detectType(it)
      .then((t) => {
        if (!alive) return;
        if (!info && t.kind === 'image' && isWebImage(t.mime)) nav.replace({ name: 'viewer', ids: [id], index: 0 });
        else setType(t);
      })
      .catch(() => alive && setErr(true));
    return () => {
      alive = false;
    };
  }, [id, info]); // eslint-disable-line react-hooks/exhaustive-deps

  // moved to trash / deleted from another screen: leave the preview
  useEffect(() => {
    if (!item || item.deletedAt) {
      const t = setTimeout(() => nav.pop(), 0);
      return () => clearTimeout(t);
    }
  }, [item?.deletedAt, !item]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!item) return <div className="screen"><TopBar title="فایل" onBack={nav.pop} /><Empty icon="file" title="این فایل دیگر وجود ندارد" /></div>;

  const mime = type?.mime ?? item.mime;
  const kind = type?.kind ?? 'other';
  const dark = !!type && (kind === 'video' || kind === 'audio');

  const del = async () => {
    setMenu(false);
    if (await confirmDialog({ title: 'حذف فایل', message: `«${item.name}» به سطل زباله منتقل می‌شود.`, confirmText: 'حذف', danger: true, icon: 'trash' })) await moveToTrash([item.id]);
  };
  const rename = async () => {
    setMenu(false);
    const n = await promptDialog({ title: 'تغییر نام', value: item.name, placeholder: item.name, confirmText: 'ذخیره' });
    if (n?.trim()) await renameItem(item.id, n);
  };
  const actions = (close: () => void) => (
    <>
      {isNative && <SheetItem icon="shortcut" label="باز کردن با برنامه دیگر" hint="با برنامه‌های نصب‌شده روی گوشی" onClick={() => { close(); void openWithOtherApp(item, mime); }} />}
      <SheetItem icon="download" label="دانلود" hint="ذخیره در Download/PersonalVault" onClick={() => { close(); void downloadItems([item.id]); }} />
      <SheetItem icon="edit" label="تغییر نام" onClick={() => { close(); void rename(); }} />
      <SheetItem icon="trash" label="حذف" danger onClick={() => { close(); void del(); }} />
    </>
  );
  const menuSheet = (
    <Sheet open={menu} onClose={() => setMenu(false)} title={item.name}>
      {actions(() => setMenu(false))}
    </Sheet>
  );

  // full-screen viewers (own overlay controls, tap to show/hide)
  if (type && !err && !info && kind === 'video') return <VideoPreview item={item} mime={mime} onBack={nav.pop} extraSheet={actions} />;
  if (type && !err && !info && kind === 'pdf')
    return (
      <>
        <PdfPreview item={item} mime={mime} onBack={nav.pop} onMenu={() => setMenu(true)} />
        {menuSheet}
      </>
    );

  let body: React.ReactNode;
  if (err) body = <Failure item={item} mime={mime} text="خواندن فایل ممکن نشد" />;
  else if (!type) body = <div className="pv-center"><Spinner size={30} /></div>;
  else if (info) body = <InfoPanel item={item} mime={mime} kind={kind} />;
  else if (kind === 'audio') body = <AudioPreview item={item} mime={mime} />;
  else if (kind === 'text' && mime !== 'image/svg+xml') body = <TextPreview item={item} mime={mime} />;
  else if (kind === 'archive' && ZIP_LISTABLE.has(mime)) body = <ZipPreview item={item} mime={mime} />;
  else body = <InfoPanel item={item} mime={mime} kind={kind} />;

  return (
    <div className={`screen preview-screen${dark ? ' media' : ''}`}>
      <TopBar
        title={item.name}
        subtitle={type ? `${kindLabel(kind, mime)} · ${formatSize(item.size)}` : formatSize(item.size)}
        onBack={nav.pop}
        actions={
          <>
            {isNative && type && <IconButton icon="shortcut" label="باز کردن با برنامه دیگر" onClick={() => void openWithOtherApp(item, mime)} />}
            <IconButton icon="more" label="گزینه‌ها" onClick={() => setMenu(true)} />
          </>
        }
      />
      <div className="pv-body">{body}</div>
      {menuSheet}
    </div>
  );
}
