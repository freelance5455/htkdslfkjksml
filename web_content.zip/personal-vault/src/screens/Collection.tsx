import { useCallback, useDeferredValue, useEffect, useMemo, useState } from 'react';
import { Chips, Empty, IconButton, SearchField, Sheet, SheetItem, TopBar } from '../components/ui';
import { Icon, type IconName } from '../components/Icon';
import { VirtualList } from '../components/VirtualList';
import { FileRow, ImageTile, TextRow, type TileProps } from '../components/ItemViews';
import { buildRows, rowHeight, type Row } from '../lib/layout';
import { makeMatcher, sortItems, SORT_LABELS } from '../lib/search';
import type { Item, Kind, ListMode, SortKey } from '../lib/types';
import { useSession } from '../store/session';
import { usePrefs } from '../store/prefs';
import { useNav } from '../store/nav';
import { confirmDialog, promptDialog, useUi } from '../store/ui';
import { BackPriority, useBack } from '../lib/back';
import { deleteForever, downloadItems, moveToTrash, renameItem, restoreFromTrash } from '../lib/actions';
import { openItem, quickAction } from './itemNav';
import { faNum, fileVisual, formatDateTime, formatSize } from '../lib/format';

type Filter = 'all' | Kind;

const META: Record<ListMode, { title: string; icon: IconName; empty: string; emptyText: string }> = {
  file: { title: 'فایل‌ها', icon: 'files', empty: 'هنوز فایلی اضافه نشده', emptyText: 'اسناد، قراردادها و هر فایلی را به‌صورت رمزنگاری‌شده نگه دارید.' },
  image: { title: 'تصاویر', icon: 'images', empty: 'گالری امن خالی است', emptyText: 'عکس‌ها فقط داخل گاوصندوق و به‌صورت رمزنگاری‌شده ذخیره می‌شوند.' },
  text: { title: 'متن‌ها', icon: 'texts', empty: 'هنوز متنی ننوشته‌اید', emptyText: 'رمزها، یادداشت‌ها و عبارات بازیابی را امن نگه دارید.' },
  all: { title: 'همه موارد', icon: 'all', empty: 'گاوصندوق خالی است', emptyText: 'فایل، تصویر یا متن اضافه کنید.' },
  trash: { title: 'سطل زباله', icon: 'trash', empty: 'سطل زباله خالی است', emptyText: 'موارد حذف‌شده تا زمان حذف دائمی اینجا می‌مانند.' },
};

export function Collection({ mode, asRoute }: { mode: ListMode; asRoute?: boolean }) {
  const items = useSession((s) => s.items);
  const sort = usePrefs((s) => s.sorts[mode] ?? 'new');
  const setPrefs = usePrefs((s) => s.set);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [selecting, setSelecting] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [sortOpen, setSortOpen] = useState(false);
  const [details, setDetails] = useState<Item | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const nav = useNav.getState();
  const meta = META[mode];
  const trash = mode === 'trash';
  const multiType = mode === 'all' || mode === 'trash';

  const scoped = useMemo(() => {
    const out: Item[] = [];
    for (const it of items.values()) {
      if (trash ? it.deletedAt === null : it.deletedAt !== null) continue;
      if (!multiType && it.kind !== mode) continue;
      out.push(it);
    }
    return out;
  }, [items, mode, trash, multiType]);

  const counts = useMemo(() => {
    const c = { all: scoped.length, file: 0, image: 0, text: 0 };
    for (const i of scoped) c[i.kind]++;
    return c;
  }, [scoped]);

  // typing stays instant: filtering a very large list is deferred to a non-blocking render
  const deferredQuery = useDeferredValue(query);
  const list = useMemo(() => {
    const match = makeMatcher(deferredQuery);
    const f = scoped.filter((i) => (filter === 'all' || i.kind === filter) && match(i));
    return sortItems(f, sort, trash);
  }, [scoped, filter, deferredQuery, sort, trash]);

  const rows = useMemo(() => buildRows(list), [list]);

  // leave selection mode when items disappear
  useEffect(() => {
    if (!selecting) return;
    const valid = new Set(list.map((i) => i.id));
    setSelected((s) => {
      const n = new Set([...s].filter((id) => valid.has(id)));
      return n.size === s.size ? s : n;
    });
  }, [list, selecting]);

  const setNavHidden = useUi((s) => s.setNavHidden);
  useEffect(() => {
    if (asRoute) return;
    setNavHidden(selecting);
    return () => setNavHidden(false);
  }, [selecting, asRoute, setNavHidden]);

  const exitSelect = useCallback(() => {
    setSelecting(false);
    setSelected(new Set());
  }, []);
  useBack(selecting, BackPriority.selection, exitSelect);

  const onToggle = useCallback((it: Item) => {
    setSelected((s) => {
      const n = new Set(s);
      if (n.has(it.id)) n.delete(it.id);
      else n.add(it.id);
      return n;
    });
  }, []);
  const onLongPress = useCallback((it: Item) => {
    setSelecting(true);
    setSelected((s) => new Set(s).add(it.id));
  }, []);
  const onOpen = useCallback(
    (it: Item) => {
      if (trash) setDetails(it);
      else openItem(it, list);
    },
    [list, trash],
  );

  const tileProps = (it: Item): TileProps => ({ item: it, selecting, selected: selected.has(it.id), trash, onOpen, onToggle, onLongPress, onQuick: quickAction });

  const renderRow = (r: Row) => {
    if (r.type === 'pair')
      return (
        <div className="grid2">
          {r.items.map((it) => (
            <ImageTile key={it.id} {...tileProps(it)} />
          ))}
        </div>
      );
    const it = r.item;
    if (it.kind === 'text') return <TextRow {...tileProps(it)} />;
    if (it.kind === 'image') return <ImageTile {...tileProps(it)} />;
    return <FileRow {...tileProps(it)} />;
  };

  const selIds = [...selected];
  const allSelected = selIds.length > 0 && selIds.length === list.length;

  const bulkDelete = async () => {
    if (!selIds.length) return;
    if (trash) {
      const ok = await confirmDialog({ title: 'حذف دائمی', message: `${faNum(selIds.length)} مورد برای همیشه حذف می‌شود و قابل بازگشت نیست.`, confirmText: 'حذف دائمی', danger: true, icon: 'trash' });
      if (!ok) return;
      await deleteForever(selIds);
    } else {
      const ok = await confirmDialog({ title: 'انتقال به سطل زباله', message: `${faNum(selIds.length)} مورد به سطل زباله منتقل می‌شود. می‌توانید بعداً بازیابی کنید.`, confirmText: 'حذف', danger: true, icon: 'trash' });
      if (!ok) return;
      await moveToTrash(selIds);
    }
    exitSelect();
  };

  const emptyTrash = async () => {
    if (!scoped.length) return;
    const ok = await confirmDialog({ title: 'خالی کردن سطل زباله', message: `همه ${faNum(scoped.length)} مورد برای همیشه حذف می‌شوند.`, confirmText: 'خالی کن', danger: true, icon: 'broom' });
    if (ok) await deleteForever(scoped.map((i) => i.id));
  };

  const onFab = () => {
    if (mode === 'file') nav.push({ name: 'addFiles' });
    else if (mode === 'image') nav.push({ name: 'addImages' });
    else if (mode === 'text') nav.push({ name: 'textEdit' });
    else setAddOpen(true);
  };

  const header = (
    <div className="list-head">
      <SearchField value={query} onChange={setQuery} placeholder={`جستجو در ${meta.title}...`} />
      {multiType && (
        <Chips<Filter>
          value={filter}
          onChange={setFilter}
          options={[
            { value: 'all', label: 'همه', icon: 'dashboard', count: counts.all },
            { value: 'text', label: 'متن‌ها', icon: 'texts', count: counts.text },
            { value: 'image', label: 'تصاویر', icon: 'images', count: counts.image },
            { value: 'file', label: 'فایل‌ها', icon: 'files', count: counts.file },
          ]}
        />
      )}
      <div className="list-tools">
        <span className="count">{query ? `${faNum(list.length)} نتیجه` : `${faNum(list.length)} مورد`}</span>
        <button type="button" className="tool" onClick={() => setSortOpen(true)}>
          <Icon name="sort" size={17} />
          {SORT_LABELS[sort]}
        </button>
        {list.length > 0 && (
          <button type="button" className={`tool${selecting ? ' on' : ''}`} onClick={() => (selecting ? exitSelect() : setSelecting(true))}>
            <Icon name="select" size={17} />
            {selecting ? 'لغو انتخاب' : 'انتخاب'}
          </button>
        )}
      </div>
    </div>
  );

  return (
    <div className="screen">
      {selecting ? (
        <header className="topbar select-bar">
          <IconButton icon="close" label="لغو" onClick={exitSelect} />
          <div className="topbar-title">
            <h1>{faNum(selIds.length)} انتخاب شد</h1>
          </div>
          <button type="button" className="tool" onClick={() => setSelected(allSelected ? new Set() : new Set(list.map((i) => i.id)))}>
            <Icon name="checkAll" size={18} />
            {allSelected ? 'هیچ‌کدام' : 'همه'}
          </button>
        </header>
      ) : (
        <TopBar
          title={meta.title}
          onBack={asRoute ? () => nav.pop() : undefined}
          onMenu={asRoute ? undefined : () => useUi.getState().setDrawer(true)}
          actions={trash && scoped.length > 0 ? <IconButton icon="broom" label="خالی کردن سطل زباله" onClick={emptyTrash} /> : undefined}
        />
      )}

      {list.length === 0 ? (
        <div className="scroll pad">
          {header}
          {query || filter !== 'all' ? <Empty icon="search" title="نتیجه‌ای پیدا نشد" text="عبارت دیگری را امتحان کنید." /> : <Empty icon={meta.icon} title={meta.empty} text={meta.emptyText} />}
        </div>
      ) : (
        <VirtualList rows={rows} height={rowHeight} render={renderRow} header={header} className={selecting ? 'selecting' : ''} />
      )}

      {!trash && !selecting && (
        <button type="button" className={`fab${asRoute ? ' low' : ''}`} aria-label="افزودن" onClick={onFab}>
          <Icon name="plus" size={26} stroke={2.2} />
        </button>
      )}

      <div className={`action-bar${selecting ? ' shown' : ''}${asRoute ? ' low' : ''}`}>
        {trash ? (
          <>
            <ActionBtn icon="restore" label="بازیابی" disabled={!selIds.length} onClick={async () => { await restoreFromTrash(selIds); exitSelect(); }} />
            <ActionBtn icon="trash" label="حذف دائمی" danger disabled={!selIds.length} onClick={bulkDelete} />
          </>
        ) : (
          <>
            <ActionBtn icon="download" label="دانلود" disabled={!selIds.length} onClick={async () => { await downloadItems(selIds); exitSelect(); }} />
            <ActionBtn icon="trash" label="حذف گروهی" danger disabled={!selIds.length} onClick={bulkDelete} />
          </>
        )}
      </div>

      <Sheet open={sortOpen} onClose={() => setSortOpen(false)} title="مرتب‌سازی">
        {(Object.keys(SORT_LABELS) as SortKey[]).map((k) => (
          <SheetItem key={k} icon="sort" label={SORT_LABELS[k]} active={k === sort} onClick={() => { setPrefs({ sorts: { ...usePrefs.getState().sorts, [mode]: k } }); setSortOpen(false); }} />
        ))}
      </Sheet>

      <Sheet open={addOpen} onClose={() => setAddOpen(false)} title="افزودن به گاوصندوق">
        <SheetItem icon="filePlus" label="افزودن فایل" hint="اسناد، آرشیو، صوت و ویدیو" onClick={() => { setAddOpen(false); nav.push({ name: 'addFiles' }); }} />
        <SheetItem icon="imagePlus" label="افزودن تصویر" hint="یک یا چند عکس از گالری" onClick={() => { setAddOpen(false); nav.push({ name: 'addImages' }); }} />
        <SheetItem icon="notePlus" label="متن جدید" hint="یادداشت، رمز یا عبارت بازیابی" onClick={() => { setAddOpen(false); nav.push({ name: 'textEdit' }); }} />
      </Sheet>

      <ItemDetails item={details} onClose={() => setDetails(null)} context={list} />
    </div>
  );
}

function ActionBtn({ icon, label, onClick, danger, disabled }: { icon: IconName; label: string; onClick: () => void; danger?: boolean; disabled?: boolean }) {
  return (
    <button type="button" className={`action${danger ? ' danger' : ''}`} onClick={onClick} disabled={disabled}>
      <Icon name={icon} size={22} />
      <span>{label}</span>
    </button>
  );
}

export function ItemDetails({ item, onClose, context }: { item: Item | null; onClose: () => void; context: Item[] }) {
  const live = useSession((s) => (item ? s.items.get(item.id) ?? null : null));
  const it = live ?? item;
  const v = it ? fileVisual(it.ext, it.mime) : null;
  const trash = !!it?.deletedAt;
  return (
    <Sheet open={!!item} onClose={onClose}>
      {it && v && (
        <>
          <div className="details-head">
            <span className={`file-badge big hue-${it.kind === 'text' ? 'emerald' : v.hue}`}>
              <Icon name={it.kind === 'text' ? 'texts' : it.kind === 'image' ? 'image' : v.icon} size={28} />
            </span>
            <div>
              <h3>{it.name}</h3>
              <p>
                <span className="num">{formatSize(it.size)}</span>
                {it.ext && <> · {it.ext.toUpperCase()}</>}
              </p>
              <p>{formatDateTime(it.createdAt)}</p>
            </div>
          </div>
          <div className="lock-note">
            <Icon name="shield" size={16} /> رمزنگاری‌شده با AES-256-GCM{it.chunks > 1 && <> · {faNum(it.chunks)} بخش</>}
          </div>
          {trash ? (
            <>
              <SheetItem icon="restore" label="بازیابی" onClick={() => { void restoreFromTrash([it.id]); onClose(); }} />
              <SheetItem icon="trash" label="حذف دائمی" danger onClick={async () => { onClose(); if (await confirmDialog({ title: 'حذف دائمی', message: `«${it.name}» برای همیشه حذف می‌شود.`, confirmText: 'حذف دائمی', danger: true, icon: 'trash' })) await deleteForever([it.id]); }} />
            </>
          ) : (
            <>
              <SheetItem icon="eye" label="باز کردن" hint={it.kind === 'file' ? 'نمایش امن داخل برنامه' : undefined} onClick={() => { onClose(); openItem(it, context); }} />
              <SheetItem icon="download" label="دانلود" hint="ذخیره در Download/PersonalVault" onClick={() => { onClose(); void downloadItems([it.id]); }} />
              <SheetItem icon="edit" label="تغییر نام" onClick={async () => { onClose(); const n = await promptDialog({ title: 'تغییر نام', value: it.name, placeholder: it.name, confirmText: 'ذخیره' }); if (n?.trim()) await renameItem(it.id, n); }} />
              <SheetItem icon="trash" label="حذف" danger onClick={async () => { onClose(); if (await confirmDialog({ title: 'حذف مورد', message: `«${it.name}» به سطل زباله منتقل می‌شود.`, confirmText: 'حذف', danger: true, icon: 'trash' })) await moveToTrash([it.id]); }} />
            </>
          )}
        </>
      )}
    </Sheet>
  );
}
