import { useEffect, useRef, useState } from 'react';
import { Icon } from '../components/Icon';
import { Button, Empty, IconButton, Spinner, TopBar } from '../components/ui';
import { useNav } from '../store/nav';
import { requireDek, useSession } from '../store/session';
import { confirmDialog, toast } from '../store/ui';
import { firstLine, readText } from '../lib/vault';
import { copyToClipboard } from '../lib/native';
import { downloadItems, moveToTrash, upsertText } from '../lib/actions';
import { faNum, formatDateTime } from '../lib/format';
import { BackPriority, useBack } from '../lib/back';

function useTextBody(id?: string) {
  const [state, setState] = useState<{ loading: boolean; body: string; error: boolean }>({ loading: !!id, body: '', error: false });
  useEffect(() => {
    if (!id) return;
    let alive = true;
    readText(requireDek(), id)
      .then((body) => alive && setState({ loading: false, body, error: false }))
      .catch(() => alive && setState({ loading: false, body: '', error: true }));
    return () => {
      alive = false;
    };
  }, [id]);
  return state;
}

export function TextView({ id }: { id: string }) {
  const nav = useNav.getState();
  const item = useSession((s) => s.items.get(id));
  const { loading, body, error } = useTextBody(id);
  const [copied, setCopied] = useState(false);

  if (!item) return <div className="screen"><TopBar title="متن" onBack={nav.pop} /><Empty icon="texts" title="این متن دیگر وجود ندارد" /></div>;

  const copy = async () => {
    const ok = await copyToClipboard(body);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
    toast(ok ? 'متن رونوشت شد' : 'رونوشت انجام نشد', ok ? 'ok' : 'err');
  };

  const del = async () => {
    if (await confirmDialog({ title: 'حذف متن', message: `«${item.name}» به سطل زباله منتقل می‌شود.`, confirmText: 'حذف', danger: true, icon: 'trash' })) {
      await moveToTrash([item.id]);
      nav.pop();
    }
  };

  const words = body.trim() ? body.trim().split(/\s+/).length : 0;

  return (
    <div className="screen">
      <TopBar
        title={item.name}
        onBack={nav.pop}
        actions={
          <>
            <IconButton icon="edit" label="ویرایش" onClick={() => nav.push({ name: 'textEdit', id })} />
            <IconButton icon="download" label="دانلود" onClick={() => downloadItems([id])} />
            <IconButton icon="trash" label="حذف" onClick={del} />
          </>
        }
      />
      <div className="scroll reader">
        <article className="reader-card">
          <h2>{item.name}</h2>
          <p className="reader-meta">
            {formatDateTime(item.updatedAt)} · {faNum(words)} کلمه
          </p>
          {loading ? (
            <div className="center"><Spinner /></div>
          ) : error ? (
            <Empty icon="alert" title="رمزگشایی متن ممکن نشد" />
          ) : (
            <div className="reader-body" dir="auto">{body}</div>
          )}
        </article>
      </div>
      <div className="bottom-cta">
        <Button icon={copied ? 'check' : 'copy'} block onClick={copy} disabled={loading || error}>
          {copied ? 'رونوشت شد' : 'رونوشت'}
        </Button>
      </div>
    </div>
  );
}

export function TextEdit({ id }: { id?: string }) {
  const nav = useNav.getState();
  const existing = useSession((s) => (id ? s.items.get(id) ?? null : null));
  const { loading, body: original } = useTextBody(id);
  // an auto-named text (name taken from its first line) opens with an empty title field, so
  // the old first line is never frozen into an explicit, possibly shortened, title
  const isAuto = (it: typeof existing, text: string | null) => !!it && (it.autoName === true || (it.autoName === undefined && text !== null && it.name === firstLine(text)));
  const initialTitle = useRef(existing && !isAuto(existing, null) ? existing.name : '');
  const [title, setTitle] = useState(initialTitle.current);
  const [body, setBody] = useState('');
  const [saving, setSaving] = useState(false);
  const loaded = useRef(!id);
  const area = useRef<HTMLTextAreaElement>(null);
  const titleEl = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (id && !loading && !loaded.current) {
      loaded.current = true;
      if (existing && isAuto(existing, original)) {
        initialTitle.current = '';
        setTitle('');
      }
      setBody(original);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, loading, original]);

  useEffect(() => {
    if (!id) setTimeout(() => area.current?.focus(), 300);
  }, [id]);

  const dirty = loaded.current && (body !== (id ? original : '') || title !== initialTitle.current);

  const leave = async () => {
    if (!dirty || (await confirmDialog({ title: 'تغییرات ذخیره نشده', message: 'بدون ذخیره خارج می‌شوید؟', confirmText: 'خروج بدون ذخیره', danger: true }))) nav.pop();
  };
  useBack(dirty, BackPriority.route + 1, leave);

  const save = async () => {
    if (saving) return;
    // read from the DOM: the keyboard may still be composing the last word
    const t = titleEl.current?.value ?? title;
    const b = area.current?.value ?? body;
    if (!b.trim() && !t.trim()) {
      toast('متن خالی است', 'info');
      return;
    }
    setSaving(true);
    try {
      const it = await upsertText(existing, t, b);
      toast('متن رمزنگاری و ذخیره شد');
      if (id) nav.pop();
      else nav.replace({ name: 'textView', id: it.id });
    } catch {
      toast('ذخیره متن ممکن نشد', 'err');
      setSaving(false);
    }
  };

  return (
    <div className="screen">
      <TopBar
        title={id ? 'ویرایش متن' : 'متن جدید'}
        subtitle={`${faNum([...body].length)} نویسه`}
        onBack={leave}
        actions={<Button icon="check" onClick={save} disabled={saving || loading} className="small">ذخیره</Button>}
      />
      <div className="scroll editor">
        {loading ? (
          <div className="center"><Spinner /></div>
        ) : (
          <>
            <input ref={titleEl} className="editor-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={existing && !initialTitle.current ? existing.name : 'عنوان (اختیاری)'} dir="auto" />
            <textarea ref={area} className="editor-body" value={body} onChange={(e) => setBody(e.target.value)} placeholder="متن خود را بنویسید... همه‌چیز پیش از ذخیره رمزنگاری می‌شود." dir="auto" />
            <div className="editor-foot">
              <Icon name="shield" size={15} /> محتوا با کلید اختصاصی گاوصندوق (DEK) رمزنگاری می‌شود
            </div>
          </>
        )}
      </div>
    </div>
  );
}
