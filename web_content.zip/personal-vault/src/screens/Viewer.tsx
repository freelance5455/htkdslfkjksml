import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from '../components/Icon';
import { IconButton, Sheet, SheetItem } from '../components/ui';
import { useNav } from '../store/nav';
import { requireDek, useSession } from '../store/session';
import { confirmDialog, promptDialog } from '../store/ui';
import { readBlob } from '../lib/vault';
import { openStream } from '../lib/stream';
import { runImageTask } from '../lib/workerTasks';
import { useThumb } from '../lib/media';
import { downloadItems, moveToTrash, renameItem } from '../lib/actions';
import { faNum, formatDateTime, formatSize } from '../lib/format';
import type { Item } from '../lib/types';

/**
 * Full-resolution sources limited to the current image and its neighbours. Normal images are
 * streamed straight from the encrypted store (decrypted chunk by chunk while the image loads,
 * no extra copy in JS memory); only huge photos go through an off-thread downscale.
 */
type Src = { url: string; release: () => void };
const full = new Map<string, Src>();
const loading = new Map<string, Promise<string>>();
let generation = 0; // bumped when the viewer closes: late results are discarded, never leaked
const HUGE_PIXELS = 24_000_000;
const HUGE_BYTES = 40 * 1024 * 1024;

function loadFull(item: Item): Promise<string> {
  const hit = full.get(item.id);
  if (hit) return Promise.resolve(hit.url);
  const p = loading.get(item.id);
  if (p) return p;
  const gen = generation;
  const job = (async () => {
    let src: Src;
    const huge = (item.width ?? 0) * (item.height ?? 0) > HUGE_PIXELS || item.size > HUGE_BYTES;
    const stream = huge ? null : await openStream(item, item.mime).catch(() => null);
    if (stream) src = { url: stream.url, release: stream.close };
    else {
      let blob = await readBlob(requireDek(), item);
      // very large photos are decoded at display size (max 4096 px) off the UI thread,
      // so a 100 MP image cannot exhaust the WebView's memory
      if (huge) {
        const small = await runImageTask({ type: 'downscale', file: blob, maxSide: 4096 }).promise;
        if (small) blob = small;
      }
      const u = URL.createObjectURL(blob);
      src = { url: u, release: () => URL.revokeObjectURL(u) };
    }
    if (gen !== generation) {
      src.release();
      throw new Error('STALE');
    }
    full.set(item.id, src);
    return src.url;
  })().finally(() => loading.delete(item.id));
  loading.set(item.id, job);
  return job;
}

function keepOnly(ids: Set<string>) {
  for (const [id, s] of full) {
    if (!ids.has(id)) {
      s.release();
      full.delete(id);
    }
  }
}

function Slide({ item, active, zoom, pan }: { item: Item; active: boolean; zoom: number; pan: { x: number; y: number } }) {
  const thumb = useThumb(item.id, !!item.thumb);
  const [src, setSrc] = useState<string | null>(full.get(item.id)?.url ?? null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    let alive = true;
    loadFull(item)
      .then((u) => alive && setSrc(u))
      .catch(() => alive && setErr(true));
    return () => {
      alive = false;
    };
  }, [item.id, item.chunks]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="slide">
      {err ? (
        <div className="slide-err">
          <Icon name="alert" size={30} />
          <span>این تصویر در برنامه قابل نمایش نیست</span>
          <button type="button" className="btn tonal small" onPointerDown={(e) => e.stopPropagation()} onPointerUp={(e) => e.stopPropagation()} onClick={() => useNav.getState().push({ name: 'preview', id: item.id, info: true })}>
            <Icon name="shortcut" size={18} />
            <span>گزینه‌های باز کردن</span>
          </button>
        </div>
      ) : (
        <>
          {!src && thumb && <img className="slide-img blur" src={thumb} alt="" />}
          {src && (
            <img
              className="slide-img"
              src={src}
              alt={item.name}
              draggable={false}
              decoding="async"
              style={active ? { transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` } : undefined}
              onError={() => setErr(true)}
            />
          )}
          {!src && <span className="spinner slide-spin" />}
        </>
      )}
    </div>
  );
}

export function Viewer({ ids, index: startIndex }: { ids: string[]; index: number }) {
  const nav = useNav.getState();
  const itemsMap = useSession((s) => s.items);
  const list = useMemo(() => ids.map((id) => itemsMap.get(id)).filter((i): i is Item => !!i && !i.deletedAt), [ids, itemsMap]);
  const [index, setIndex] = useState(Math.min(startIndex, Math.max(0, list.length - 1)));
  const [dx, setDx] = useState(0);
  const [animating, setAnimating] = useState(false);
  const [chrome, setChrome] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [info, setInfo] = useState(false);
  const drag = useRef<{ x: number; y: number; t: number; px: number; py: number; moved: boolean } | null>(null);
  const lastTap = useRef(0);
  const width = typeof window !== 'undefined' ? window.innerWidth : 400;

  useEffect(() => {
    if (index > list.length - 1) setIndex(Math.max(0, list.length - 1));
    if (!list.length) nav.pop();
  }, [list.length, index]);

  const cur = list[index];
  useEffect(() => {
    keepOnly(new Set([list[index - 1]?.id, list[index]?.id, list[index + 1]?.id].filter(Boolean) as string[]));
  }, [index, list]);
  useEffect(
    () => () => {
      generation++;
      loading.clear();
      keepOnly(new Set());
    },
    [],
  );

  const go = useCallback(
    (dir: 1 | -1) => {
      const next = index + dir;
      if (next < 0 || next >= list.length) {
        setAnimating(true);
        setDx(0);
        return;
      }
      setAnimating(true);
      // RTL: the next image sits on the left; dragging right reveals it
      setDx(dir === 1 ? width : -width);
      setTimeout(() => {
        setAnimating(false);
        setDx(0);
        setIndex(next);
        setZoom(1);
        setPan({ x: 0, y: 0 });
      }, 220);
    },
    [index, list.length, width],
  );

  // ---- gestures: one finger swipes (or pans when zoomed), two fingers pinch-zoom around their midpoint
  const stageRef = useRef<HTMLDivElement>(null);
  const pts = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef<{ d0: number; z0: number; px: number; py: number; mx: number; my: number } | null>(null);
  const [gesturing, setGesturing] = useState(false);
  const center = () => {
    const r = stageRef.current!.getBoundingClientRect();
    return { cx: r.left + r.width / 2, cy: r.top + r.height / 2, w: r.width, h: r.height };
  };
  const clampPan = (p: { x: number; y: number }, z: number) => {
    const { w, h } = center();
    const mx = ((z - 1) * w) / 2;
    const my = ((z - 1) * h) / 2;
    return { x: Math.max(-mx, Math.min(mx, p.x)), y: Math.max(-my, Math.min(my, p.y)) };
  };
  const startPinch = () => {
    const [a, b] = [...pts.current.values()];
    const { cx, cy } = center();
    pinch.current = { d0: Math.max(1, Math.hypot(a.x - b.x, a.y - b.y)), z0: zoom, px: pan.x, py: pan.y, mx: (a.x + b.x) / 2 - cx, my: (a.y + b.y) / 2 - cy };
    drag.current = null;
    setDx(0);
    setGesturing(true);
  };
  const onDown = (e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    pts.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    setAnimating(false);
    if (pts.current.size === 2) return startPinch();
    if (pts.current.size === 1) {
      drag.current = { x: e.clientX, y: e.clientY, t: Date.now(), px: pan.x, py: pan.y, moved: false };
      if (zoom > 1) setGesturing(true);
    }
  };
  const onMove = (e: React.PointerEvent) => {
    if (!pts.current.has(e.pointerId)) return;
    pts.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const pz = pinch.current;
    if (pz && pts.current.size >= 2) {
      const [a, b] = [...pts.current.values()];
      const { cx, cy } = center();
      const z = Math.max(1, Math.min(5, (pz.z0 * Math.hypot(a.x - b.x, a.y - b.y)) / pz.d0));
      const mx = (a.x + b.x) / 2 - cx;
      const my = (a.y + b.y) / 2 - cy;
      // keep the image point that was under the fingers' midpoint under it
      const qx = (pz.mx - pz.px) / pz.z0;
      const qy = (pz.my - pz.py) / pz.z0;
      setZoom(z);
      setPan(clampPan({ x: mx - qx * z, y: my - qy * z }, z));
      return;
    }
    const d = drag.current;
    if (!d) return;
    const mx = e.clientX - d.x;
    const my = e.clientY - d.y;
    if (Math.abs(mx) > 6 || Math.abs(my) > 6) d.moved = true;
    if (zoom > 1) setPan(clampPan({ x: d.px + mx, y: d.py + my }, zoom));
    else if (Math.abs(mx) > Math.abs(my)) setDx(mx);
  };
  const onUp = (e: React.PointerEvent) => {
    if (!pts.current.delete(e.pointerId)) return;
    if (pinch.current) {
      if (pts.current.size < 2) {
        pinch.current = null;
        if (zoom < 1.05) {
          setZoom(1);
          setPan({ x: 0, y: 0 });
        }
        // continue panning with the finger that stays down
        const rest = [...pts.current.values()][0];
        drag.current = rest ? { x: rest.x, y: rest.y, t: Date.now(), px: pan.x, py: pan.y, moved: true } : null;
        if (!rest) setGesturing(false);
      }
      return;
    }
    setGesturing(false);
    const d = drag.current;
    drag.current = null;
    if (!d) return;
    const mx = e.clientX - d.x;
    if (!d.moved && e.type === 'pointerup') {
      const now = Date.now();
      if (now - lastTap.current < 280) {
        lastTap.current = 0;
        if (zoom > 1) {
          setZoom(1);
          setPan({ x: 0, y: 0 });
        } else {
          const { cx, cy } = center();
          const z = 2.5;
          setZoom(z);
          setPan(clampPan({ x: (e.clientX - cx) * (1 - z), y: (e.clientY - cy) * (1 - z) }, z));
        }
        return;
      }
      lastTap.current = now;
      setTimeout(() => lastTap.current && Date.now() - lastTap.current >= 270 && setChrome((c) => !c), 290);
      return;
    }
    if (zoom > 1) return;
    const fast = Math.abs(mx) / Math.max(1, Date.now() - d.t) > 0.5;
    if (Math.abs(mx) > width * 0.22 || (fast && Math.abs(mx) > 30)) go(mx > 0 ? 1 : -1);
    else {
      setAnimating(true);
      setDx(0);
    }
  };

  if (!cur) return <div className="viewer" />;

  const slides = [-1, 0, 1]
    .map((o) => ({ o, it: list[index + o] }))
    .filter((s): s is { o: number; it: Item } => !!s.it);

  const del = async () => {
    if (await confirmDialog({ title: 'حذف تصویر', message: `«${cur.name}» به سطل زباله منتقل می‌شود.`, confirmText: 'حذف', danger: true, icon: 'trash' })) await moveToTrash([cur.id]);
  };
  const rename = async () => {
    const n = await promptDialog({ title: 'تغییر نام تصویر', value: cur.name, placeholder: cur.name, confirmText: 'ذخیره' });
    if (n?.trim()) await renameItem(cur.id, n);
  };

  return (
    <div className={`viewer${chrome ? '' : ' immersive'}`}>
      <div className={`viewer-stage${gesturing ? ' gesturing' : ''}`} ref={stageRef} onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
        {slides.map(({ o, it }) => (
          <div key={it.id} className={`slide-wrap${animating ? ' anim' : ''}`} style={{ transform: `translateX(${-o * width + dx}px)` }}>
            <Slide item={it} active={o === 0} zoom={o === 0 ? zoom : 1} pan={o === 0 ? pan : { x: 0, y: 0 }} />
          </div>
        ))}
      </div>

      <header className="viewer-top">
        <IconButton icon="back" label="بازگشت" variant="glass" onClick={nav.pop} />
        <div className="viewer-title">
          <b>{cur.name}</b>
          <small className="num">{faNum(index + 1)} از {faNum(list.length)}</small>
        </div>
        <IconButton icon="info" label="اطلاعات" variant="glass" onClick={() => setInfo(true)} />
      </header>

      <div className="viewer-strip">
        {list.slice(Math.max(0, index - 6), index + 7).map((it) => (
          <StripThumb key={it.id} item={it} active={it.id === cur.id} onClick={() => { setIndex(list.indexOf(it)); setZoom(1); setPan({ x: 0, y: 0 }); }} />
        ))}
      </div>

      <footer className="viewer-bar">
        <button type="button" onClick={() => go(-1)} disabled={index === 0} aria-label="قبلی"><Icon name="back" size={22} /></button>
        <button type="button" onClick={() => downloadItems([cur.id])}><Icon name="download" size={22} /><span>دانلود</span></button>
        <button type="button" onClick={rename}><Icon name="edit" size={22} /><span>نام</span></button>
        <button type="button" onClick={() => { setZoom(zoom > 1 ? 1 : 2.5); setPan({ x: 0, y: 0 }); }}><Icon name={zoom > 1 ? 'zoomOut' : 'zoom'} size={22} /><span>{zoom > 1 ? 'اندازه اصلی' : 'بزرگ‌نمایی'}</span></button>
        <button type="button" className="danger" onClick={del}><Icon name="trash" size={22} /><span>حذف</span></button>
        <button type="button" onClick={() => go(1)} disabled={index === list.length - 1} aria-label="بعدی"><Icon name="forward" size={22} /></button>
      </footer>

      <Sheet open={info} onClose={() => setInfo(false)} title="جزئیات تصویر">
        <div className="info-grid">
          <span>نام</span><b>{cur.name}</b>
          <span>حجم</span><b className="num">{formatSize(cur.size)}</b>
          {cur.width && <><span>ابعاد</span><b className="num" dir="ltr">{cur.width} × {cur.height}</b></>}
          <span>نوع</span><b dir="ltr">{cur.mime}</b>
          <span>افزوده‌شده</span><b>{formatDateTime(cur.createdAt)}</b>
          <span>رمزنگاری</span><b>AES-256-GCM · {faNum(cur.chunks)} بخش</b>
        </div>
        <SheetItem icon="download" label="دانلود نسخه اصلی" onClick={() => { setInfo(false); void downloadItems([cur.id]); }} />
      </Sheet>
    </div>
  );
}

function StripThumb({ item, active, onClick }: { item: Item; active: boolean; onClick: () => void }) {
  const url = useThumb(item.id, !!item.thumb);
  return (
    <button type="button" className={`strip-thumb${active ? ' on' : ''}`} onClick={onClick} aria-label={item.name}>
      {url ? <img src={url} alt="" /> : <Icon name="image" size={16} />}
    </button>
  );
}
