import { useCallback, useEffect, useRef, useState } from 'react';
import { Icon } from '../components/Icon';
import { groupDigits, initialCalc, preview, press, toFaDigits, type CalcState } from '../lib/calc';
import type { Accent, CalcStyle } from '../store/prefs';
import { ACCENTS } from '../store/prefs';
import { haptic } from '../lib/native';

const KEYS: { k: string; label?: string; cls: string }[] = [
  { k: 'C', cls: 'fn' }, { k: '±', cls: 'fn' }, { k: '%', cls: 'fn' }, { k: '÷', cls: 'op' },
  { k: '7', cls: 'num' }, { k: '8', cls: 'num' }, { k: '9', cls: 'num' }, { k: '×', cls: 'op' },
  { k: '4', cls: 'num' }, { k: '5', cls: 'num' }, { k: '6', cls: 'num' }, { k: '−', cls: 'op' },
  { k: '1', cls: 'num' }, { k: '2', cls: 'num' }, { k: '3', cls: 'num' }, { k: '+', cls: 'op' },
  { k: '⌫', cls: 'fn' }, { k: '0', cls: 'num' }, { k: '.', label: '٫', cls: 'num' }, { k: '=', cls: 'eq' },
];

const display = (s: string) => toFaDigits(groupDigits(s)).replace(/,/g, '٬');

export function Calculator({ name, styleKey, accent, onSecret, preview: isPreview }: { name: string; styleKey: CalcStyle; accent: Accent; onSecret?: (digits: string) => void; preview?: boolean }) {
  const [st, setSt] = useState<CalcState>(initialCalc);
  const stRef = useRef(st);
  stRef.current = st;
  const secretRef = useRef(onSecret);
  secretRef.current = onSecret;

  // "=" behaves exactly like a normal calculator. If the expression is a plain
  // run of digits we additionally hand it to onSecret, silently: nothing about
  // the display or the UI ever depends on whether it matched.
  const apply = useCallback((k: string) => {
    const cur = stRef.current;
    if (k === '=' && cur.result === null && !cur.error && /^[0-9]{4,15}$/.test(cur.expr)) {
      const code = cur.expr;
      queueMicrotask(() => secretRef.current?.(code));
    }
    setSt((s) => press(s, k));
  }, []);

  const tap = (k: string) => {
    haptic(5);
    apply(k);
  };

  useEffect(() => {
    if (isPreview) return;
    const onKey = (e: KeyboardEvent) => {
      const map: Record<string, string> = { '*': '×', '/': '÷', '-': '−', '+': '+', Enter: '=', '=': '=', Backspace: '⌫', Escape: 'C', '%': '%', '.': '.' };
      const k = /^[0-9]$/.test(e.key) ? e.key : map[e.key];
      if (k) apply(k);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isPreview, apply]);

  const live = st.result === null ? preview(st.expr) : null;
  const main = st.error ? 'خطا' : st.result !== null ? display(st.result) : display(st.expr || '0');
  const sub = st.result !== null ? display(st.expr) + ' =' : live ? display(live) : '';
  const a = ACCENTS[accent];

  return (
    <div className={`calc calc-${styleKey}${isPreview ? ' is-preview' : ''}`} style={{ ['--calc-acc' as string]: a.dark, ['--calc-acc-rgb' as string]: a.rgbDark }}>
      <header className="calc-top">
        <span className="calc-name">{name}</span>
      </header>
      <div className="calc-display" dir="ltr">
        <div className="calc-sub">{sub}</div>
        <div className={`calc-main${main.length > 12 ? ' small' : ''}${main.length > 18 ? ' xsmall' : ''}`}>{main}</div>
      </div>
      <div className="calc-keys" dir="ltr">
        {KEYS.map((key) => (
          <button key={key.k} type="button" className={`ck ${key.cls}`} onClick={() => tap(key.k)}>
            {key.k === '⌫' ? <Icon name="erase" size={24} /> : key.label ?? (key.cls === 'num' ? toFaDigits(key.k) : key.k)}
          </button>
        ))}
      </div>
    </div>
  );
}
