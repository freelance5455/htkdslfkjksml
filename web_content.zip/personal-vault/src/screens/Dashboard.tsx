import { useEffect, useMemo, useState } from 'react';
import { Icon, type IconName } from '../components/Icon';
import { IconButton, TopBar } from '../components/ui';
import { FileRow, ImageTile, TextRow, type TileProps } from '../components/ItemViews';
import { useSession } from '../store/session';
import { usePrefs } from '../store/prefs';
import { useNav, type Tab } from '../store/nav';
import { useUi } from '../store/ui';
import { buildRows } from '../lib/layout';
import { faNum, formatSize } from '../lib/format';
import type { Item } from '../lib/types';
import { openItem, quickAction } from './itemNav';
import { PBKDF2_ITERATIONS } from '../lib/crypto';

export function Dashboard() {
  const items = useSession((s) => s.items);
  const lock = useSession((s) => s.lock);
  const appName = usePrefs((s) => s.appName);
  const nav = useNav.getState();
  const [usage, setUsage] = useState<number | null>(null);

  const stats = useMemo(() => {
    const s = { file: 0, image: 0, text: 0, bytes: 0, trash: 0 };
    const live: Item[] = [];
    for (const i of items.values()) {
      if (i.deletedAt) {
        s.trash++;
        continue;
      }
      s[i.kind]++;
      s.bytes += i.size;
      live.push(i);
    }
    live.sort((a, b) => b.createdAt - a.createdAt);
    return { ...s, recent: live.slice(0, 8) };
  }, [items]);

  // storage estimate is debounced: during a bulk import the item map changes many times
  useEffect(() => {
    const t = setTimeout(() => {
      navigator.storage?.estimate?.().then((e) => setUsage(e.usage ?? null)).catch(() => undefined);
    }, 700);
    return () => clearTimeout(t);
  }, [items]);

  const rows = useMemo(() => buildRows(stats.recent), [stats.recent]);
  const tp = (it: Item): TileProps => ({
    item: it,
    selecting: false,
    selected: false,
    onOpen: (x) => openItem(x, stats.recent),
    onToggle: () => undefined,
    onLongPress: () => nav.push({ name: 'all' }),
    onQuick: quickAction,
  });

  const cats: { tab: Tab; icon: IconName; label: string; count: number; hue: string; hint: string }[] = [
    { tab: 'files', icon: 'files', label: 'فایل‌ها', count: stats.file, hue: 'violet', hint: 'اسناد و قراردادها' },
    { tab: 'images', icon: 'images', label: 'تصاویر', count: stats.image, hue: 'cyan', hint: 'گالری رمزنگاری‌شده' },
    { tab: 'texts', icon: 'texts', label: 'متن‌ها', count: stats.text, hue: 'emerald', hint: 'یادداشت و رمزها' },
  ];

  return (
    <div className="screen">
      <TopBar title={appName} onMenu={() => useUi.getState().setDrawer(true)} actions={<IconButton icon="lock" label="قفل کردن" onClick={lock} variant="tonal" />} />
      <div className="scroll pad dash">
        <section className="hero">
          <div className="hero-glow" />
          <div className="hero-top">
            <span className="hero-badge">
              <Icon name="shield" size={26} />
            </span>
            <div className="hero-title">
              <h2>گاوصندوق باز و محافظت‌شده</h2>
              <p><span className="hero-dot" />AES-GCM 256 · PBKDF2 × {faNum(PBKDF2_ITERATIONS)}</p>
            </div>
          </div>
          <div className="hero-stats">
            <div>
              <b className="num">{faNum(stats.file + stats.image + stats.text)}</b>
              <span>مورد امن</span>
            </div>
            <div>
              <b className="num">{formatSize(stats.bytes)}</b>
              <span>حجم محتوا</span>
            </div>
            <div>
              <b className="num">{usage === null ? '—' : formatSize(usage)}</b>
              <span>فضای اشغال‌شده</span>
            </div>
          </div>
        </section>

        <div className="quick-add">
          <button type="button" onClick={() => nav.push({ name: 'addFiles' })}>
            <span className="qa-ic hue-violet"><Icon name="filePlus" size={24} /></span>
            افزودن فایل
          </button>
          <button type="button" onClick={() => nav.push({ name: 'addImages' })}>
            <span className="qa-ic hue-cyan"><Icon name="imagePlus" size={24} /></span>
            افزودن تصویر
          </button>
          <button type="button" onClick={() => nav.push({ name: 'textEdit' })}>
            <span className="qa-ic hue-emerald"><Icon name="notePlus" size={24} /></span>
            متن جدید
          </button>
        </div>

        <div className="section-head">
          <h3>دسته‌بندی‌های حفاظت‌شده</h3>
          <button type="button" className="link" onClick={() => nav.push({ name: 'all' })}>
            همه موارد <Icon name="chevron" size={16} />
          </button>
        </div>
        <div className="cats">
          {cats.map((c) => (
            <button key={c.tab} type="button" className="cat" onClick={() => nav.setTab(c.tab)}>
              <span className={`cat-ic hue-${c.hue}`}><Icon name={c.icon} size={24} /></span>
              <b className="num">{faNum(c.count)}</b>
              <span>{c.label}</span>
              <small>{c.hint}</small>
            </button>
          ))}
        </div>

        <div className="section-head">
          <h3>اخیراً اضافه‌شده</h3>
          {stats.trash > 0 && (
            <button type="button" className="link" onClick={() => nav.push({ name: 'trash' })}>
              سطل زباله ({faNum(stats.trash)})
            </button>
          )}
        </div>
        {rows.length === 0 ? (
          <div className="dash-empty">
            <Icon name="sparkles" size={22} />
            <span>اولین فایل، تصویر یا متن خود را اضافه کنید؛ همه‌چیز پیش از ذخیره رمزنگاری می‌شود.</span>
          </div>
        ) : (
          <div className="recent">
            {rows.map((r) =>
              r.type === 'pair' ? (
                <div key={r.key} className="grid2 static">
                  {r.items.map((it) => <ImageTile key={it.id} {...tp(it)} />)}
                </div>
              ) : r.item.kind === 'text' ? (
                <TextRow key={r.key} {...tp(r.item)} />
              ) : (
                <FileRow key={r.key} {...tp(r.item)} />
              ),
            )}
          </div>
        )}
      </div>
    </div>
  );
}
