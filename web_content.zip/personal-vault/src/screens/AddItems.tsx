import { memo, useCallback, useMemo, useRef, useState } from 'react';
import { Icon, type IconName } from '../components/Icon';
import { Button, IconButton, TopBar } from '../components/ui';
import { useNav } from '../store/nav';
import { confirmDialog, openPicker, pickerDone, promptDialog, toast } from '../store/ui';
import { importPicked, type PickedFile } from '../lib/actions';
import { faNum, fileVisual, formatSize } from '../lib/format';
import { splitName } from '../lib/vault';
import { randomId } from '../lib/crypto';
import { BackPriority, useBack } from '../lib/back';
import { usePickPreview } from '../lib/workerTasks';

interface Option {
  key: string;
  icon: IconName;
  title: string;
  hint: string;
  accept: string;
  hue: string;
}

const FILE_OPTIONS: Option[] = [
  { key: 'any', icon: 'files', title: 'فایل', hint: 'انتخاب هر نوع فایل (یک یا چند مورد)', accept: '*/*', hue: 'violet' },
  { key: 'docs', icon: 'fileText', title: 'اسناد', hint: 'PDF، Word، Excel، PowerPoint، متن', accept: '.pdf,.doc,.docx,.xls,.xlsx,.csv,.ppt,.pptx,.txt,.rtf,.odt,.ods,.md,application/pdf,text/*', hue: 'cyan' },
  { key: 'media', icon: 'video', title: 'صوت و ویدیو', hint: 'موسیقی، ضبط صدا و فیلم', accept: 'audio/*,video/*', hue: 'rose' },
  { key: 'archive', icon: 'archive', title: 'فایل فشرده', hint: 'ZIP، RAR، 7z و APK', accept: '.zip,.rar,.7z,.tar,.gz,.apk,application/zip', hue: 'amber' },
];

const IMAGE_OPTIONS: Option[] = [
  { key: 'gallery', icon: 'gallery', title: 'گالری تصاویر', hint: 'انتخاب یک یا چند عکس به‌صورت هم‌زمان', accept: 'image/*', hue: 'cyan' },
  { key: 'files', icon: 'image', title: 'فایل‌های تصویری', hint: 'JPG، PNG، WEBP، GIF، HEIC از حافظه', accept: '.jpg,.jpeg,.png,.webp,.gif,.heic,.heif,.bmp,.avif', hue: 'violet' },
];

type Picked = PickedFile;

/** Picked image tile: its small preview is generated off-thread only when it scrolls into view. */
const PickImage = memo(function PickImage({ p, onRemove, onRename }: { p: Picked; onRemove: (p: Picked) => void; onRename: (p: Picked) => void }) {
  const [ref, url] = usePickPreview(p.file);
  return (
    <div className="pick-card">
      <div className="pick-img" ref={ref}>
        {url ? <img src={url} alt="" decoding="async" draggable={false} /> : <span className="pick-ph"><Icon name="image" size={26} stroke={1.5} /></span>}
        <IconButton icon="close" label="حذف از انتخاب" variant="glass" size={16} className="pick-x" onClick={() => onRemove(p)} />
      </div>
      <div className="pick-meta">
        <span className="pick-name">
          <b>{p.name || splitName(p.file.name).base}</b>
          <small className="num">{formatSize(p.file.size)}</small>
        </span>
        <IconButton icon="edit" label="ویرایش نام" variant="tonal" size={17} onClick={() => onRename(p)} />
      </div>
    </div>
  );
});

function useDiscardGuard(dirty: boolean) {
  const nav = useNav.getState();
  useBack(dirty, BackPriority.route + 1, async () => {
    if (await confirmDialog({ title: 'انصراف از افزودن؟', message: 'موارد انتخاب‌شده ذخیره نشده‌اند.', confirmText: 'انصراف', danger: true })) nav.pop();
  });
  return async () => {
    if (!dirty || (await confirmDialog({ title: 'انصراف از افزودن؟', message: 'موارد انتخاب‌شده ذخیره نشده‌اند.', confirmText: 'انصراف', danger: true }))) nav.pop();
  };
}

export function AddItems({ kind }: { kind: 'file' | 'image' }) {
  const nav = useNav.getState();
  const input = useRef<HTMLInputElement>(null);
  const [accept, setAccept] = useState('*/*');
  const [picked, setPicked] = useState<Picked[]>([]);
  const [busy, setBusy] = useState(false);
  const options = kind === 'file' ? FILE_OPTIONS : IMAGE_OPTIONS;
  const back = useDiscardGuard(picked.length > 0 && !busy);

  const choose = (o: Option) => {
    setAccept(o.accept);
    setTimeout(() => openPicker(input.current), 0);
  };

  const onFiles = (files: FileList | null) => {
    pickerDone();
    if (!files?.length) return;
    let list = Array.from(files);
    if (kind === 'image') {
      const bad = list.filter((f) => f.type && !f.type.startsWith('image/'));
      list = list.filter((f) => !f.type || f.type.startsWith('image/'));
      if (bad.length) toast(`${faNum(bad.length)} فایل تصویر نبود و کنار گذاشته شد`, 'info');
    }
    setPicked((prev) => [
      ...prev,
      ...list.map((file) => ({ key: randomId(), file, name: '' })),
    ]);
  };

  const rename = useCallback(async (p: Picked) => {
    const base = splitName(p.file.name).base;
    const v = await promptDialog({ title: kind === 'image' ? 'نام تصویر' : 'نام فایل', message: 'اختیاری است؛ اگر خالی بماند نام اصلی حفظ می‌شود.', value: p.name, placeholder: base, confirmText: 'تأیید' });
    if (v === null) return;
    setPicked((list) => list.map((x) => (x.key === p.key ? { ...x, name: v.trim() } : x)));
  }, [kind]);

  const remove = useCallback((p: Picked) => {
    setPicked((list) => list.filter((x) => x.key !== p.key));
  }, []);

  const save = async () => {
    if (!picked.length || busy) return;
    setBusy(true);
    try {
      const done = await importPicked(picked, kind);
      if (done.length) {
        setPicked([]);
        nav.setTab(kind === 'image' ? 'images' : 'files');
      }
    } finally {
      setBusy(false);
    }
  };

  const total = useMemo(() => picked.reduce((a, p) => a + p.file.size, 0), [picked]);

  return (
    <div className="screen">
      <TopBar title={kind === 'image' ? 'افزودن تصویر' : 'افزودن فایل'} subtitle={picked.length ? `${faNum(picked.length)} مورد · ${formatSize(total)}` : 'ابتدا منبع را انتخاب کنید'} onBack={back} />
      <input ref={input} type="file" hidden multiple accept={accept} onChange={(e) => onFiles(e.target.files)} />
      <div className="scroll pad add-screen">
        <div className={`add-options${picked.length ? ' compact' : ''}`}>
          {options.map((o) => (
            <button key={o.key} type="button" className="add-option" onClick={() => choose(o)}>
              <span className={`ao-ic hue-${o.hue}`}>
                <Icon name={o.icon} size={26} />
              </span>
              <span className="ao-text">
                <b>{o.title}</b>
                <small>{o.hint}</small>
              </span>
              <Icon name="chevron" size={18} className="ao-chev" />
            </button>
          ))}
        </div>

        {picked.length === 0 ? (
          <div className="add-hint">
            <Icon name="shield" size={20} />
            <p>
              {kind === 'image' ? 'تصاویر' : 'فایل‌ها'} پیش از ذخیره، روی همین دستگاه با AES-256-GCM رمزنگاری و در بخش‌های ۱ مگابایتی نگهداری می‌شوند؛ پردازش در پس‌زمینه انجام می‌شود و فایل‌های حجیم هرگز کامل در حافظه بارگذاری نمی‌شوند. نسخه اصلی در گالری/حافظه دست نمی‌خورد.
            </p>
          </div>
        ) : kind === 'image' ? (
          <>
            <div className="section-head">
              <h3>تصاویر انتخاب‌شده</h3>
              <button type="button" className="link" onClick={() => choose(options[0])}>
                <Icon name="plus" size={16} /> افزودن بیشتر
              </button>
            </div>
            <div className="pick-grid">
              {picked.map((p) => (
                <PickImage key={p.key} p={p} onRemove={remove} onRename={rename} />
              ))}
            </div>
          </>
        ) : (
          <>
            <div className="section-head">
              <h3>فایل‌های انتخاب‌شده</h3>
              <button type="button" className="link" onClick={() => choose(options[0])}>
                <Icon name="plus" size={16} /> افزودن بیشتر
              </button>
            </div>
            <div className="pick-list">
              {picked.map((p) => {
                const { base, ext } = splitName(p.file.name);
                const v = fileVisual(ext, p.file.type);
                return (
                  <div key={p.key} className="row-card static">
                    <span className={`file-badge hue-${v.hue}`}>
                      <Icon name={v.icon} size={22} />
                      <i>{v.label}</i>
                    </span>
                    <span className="row-main">
                      <b>{p.name || base}</b>
                      <small>
                        <span className="num">{formatSize(p.file.size)}</span>
                        {p.name && <> · اصلی: {p.file.name}</>}
                      </small>
                    </span>
                    <IconButton icon="edit" label="تغییر نام" variant="tonal" size={18} onClick={() => rename(p)} />
                    <IconButton icon="close" label="حذف از انتخاب" size={18} onClick={() => remove(p)} />
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>
      {picked.length > 0 && (
        <div className="bottom-cta">
          <Button icon="lock" block onClick={save} disabled={busy}>
            {busy ? 'در حال رمزنگاری...' : `افزودن ${faNum(picked.length)} ${kind === 'image' ? 'تصویر' : 'فایل'} به گاوصندوق`}
          </Button>
        </div>
      )}
    </div>
  );
}
