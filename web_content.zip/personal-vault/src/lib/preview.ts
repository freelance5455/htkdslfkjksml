import { requireDek, useSession } from '../store/session';
import { iterateChunks, readRange, saveProjections } from './vault';
import { previewKind, resolveMime, type PreviewKind } from './sniff';
import { writeTemp, type TempFile } from './native';
import type { Item } from './types';

const HEAD_BYTES = 256 * 1024;

/**
 * Returns the real content type of a stored file. Items imported by v2.1+ were sniffed at
 * import time; older items are sniffed now (only the first 256 KiB is decrypted) and the
 * result is persisted in the encrypted projection.
 */
export async function detectType(item: Item): Promise<{ mime: string; kind: PreviewKind }> {
  if (item.sniffed) return { mime: item.mime, kind: previewKind(item.mime) };
  const dek = requireDek();
  const head = await readRange(dek, item, 0, HEAD_BYTES);
  const mime = resolveMime(head, item.ext, item.declaredMime ?? item.mime);
  const updated: Item = { ...item, mime, sniffed: true, declaredMime: item.declaredMime ?? item.mime };
  try {
    await saveProjections(dek, [updated]);
    useSession.getState().upsert([updated]);
  } catch {
    /* detection still valid for this session */
  }
  return { mime, kind: previewKind(mime) };
}

const extFor = (item: Item, mime: string) => {
  if (item.ext) return item.ext.replace(/[^a-z0-9]/gi, '').slice(0, 8) || 'bin';
  const sub = mime.split('/')[1] ?? 'bin';
  return sub.replace(/^x-/, '').replace(/[^a-z0-9]/gi, '').slice(0, 8) || 'bin';
};

/** Decrypts a stored file into a private temporary copy (streamed, constant RAM). */
export function prepareTemp(item: Item, mime: string, o: { shared?: boolean; onProgress?: (f: number) => void; signal?: { cancelled: boolean } } = {}): Promise<TempFile> {
  const dek = requireDek();
  return writeTemp({
    ext: extFor(item, mime),
    mime,
    shared: o.shared,
    name: o.shared ? displayFileName(item, mime) : undefined,
    chunks: iterateChunks(dek, item),
    onProgress: (b) => o.onProgress?.(item.size ? b / item.size : 1),
    signal: o.signal,
  });
}

function displayFileName(item: Item, mime: string): string {
  const clean = item.name.replace(/[\\/:*?"<>|\x00-\x1f]+/g, '_').trim().slice(0, 100) || 'file';
  const ext = extFor(item, mime);
  return clean.toLowerCase().endsWith(`.${ext}`) ? clean : `${clean}.${ext}`;
}

// ---------------------------------------------------------------- text

export const TEXT_PREVIEW_LIMIT = 1024 * 1024;

export async function readTextPreview(item: Item): Promise<{ text: string; truncated: boolean }> {
  const bytes = await readRange(requireDek(), item, 0, TEXT_PREVIEW_LIMIT);
  let enc = 'utf-8';
  let start = 0;
  if (bytes[0] === 0xff && bytes[1] === 0xfe) (enc = 'utf-16le'), (start = 2);
  else if (bytes[0] === 0xfe && bytes[1] === 0xff) (enc = 'utf-16be'), (start = 2);
  else if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) start = 3;
  const text = new TextDecoder(enc, { fatal: false }).decode(bytes.subarray(start));
  return { text, truncated: item.size > TEXT_PREVIEW_LIMIT };
}

// ---------------------------------------------------------------- zip listing (no extraction)

export interface ZipEntry {
  name: string;
  size: number;
  compressed: number;
  dir: boolean;
  encrypted: boolean;
}
export interface ZipListing {
  entries: ZipEntry[];
  total: number;
  truncated: boolean;
  unpacked: number;
}

const MAX_CD_BYTES = 8 * 1024 * 1024;
const MAX_ENTRIES = 20_000;

/** Reads only the ZIP central directory (end of file) to list the archive. Nothing is extracted. */
export async function listZip(item: Item): Promise<ZipListing> {
  const dek = requireDek();
  const size = item.size;
  const tailLen = Math.min(size, 65_557 + 20);
  const tail = await readRange(dek, item, size - tailLen, size);
  const dv = new DataView(tail.buffer, tail.byteOffset, tail.byteLength);
  let eocd = -1;
  for (let i = tail.length - 22; i >= 0; i--) {
    if (dv.getUint32(i, true) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error('NOT_ZIP');
  let total = dv.getUint16(eocd + 10, true);
  let cdSize = dv.getUint32(eocd + 12, true);
  let cdOff = dv.getUint32(eocd + 16, true);
  if ((total === 0xffff || cdSize === 0xffffffff || cdOff === 0xffffffff) && eocd >= 20 && dv.getUint32(eocd - 20, true) === 0x07064b50) {
    const z64 = Number(dv.getBigUint64(eocd - 20 + 8, true));
    const rec = await readRange(dek, item, z64, z64 + 56);
    const rv = new DataView(rec.buffer, rec.byteOffset, rec.byteLength);
    if (rv.getUint32(0, true) === 0x06064b50) {
      total = Number(rv.getBigUint64(32, true));
      cdSize = Number(rv.getBigUint64(40, true));
      cdOff = Number(rv.getBigUint64(48, true));
    }
  }
  const readLen = Math.min(cdSize, MAX_CD_BYTES);
  const cd = await readRange(dek, item, cdOff, cdOff + readLen);
  const cv = new DataView(cd.buffer, cd.byteOffset, cd.byteLength);
  const td = new TextDecoder('utf-8', { fatal: false });
  const entries: ZipEntry[] = [];
  let unpacked = 0;
  let o = 0;
  while (o + 46 <= cd.length && entries.length < MAX_ENTRIES) {
    if (cv.getUint32(o, true) !== 0x02014b50) break;
    const flags = cv.getUint16(o + 8, true);
    let comp = cv.getUint32(o + 20, true);
    let usize = cv.getUint32(o + 24, true);
    const nLen = cv.getUint16(o + 28, true);
    const xLen = cv.getUint16(o + 30, true);
    const cLen = cv.getUint16(o + 32, true);
    if (o + 46 + nLen > cd.length) break;
    const name = td.decode(cd.subarray(o + 46, o + 46 + nLen));
    // zip64 extra field
    let x = o + 46 + nLen;
    const xEnd = Math.min(cd.length, x + xLen);
    while (x + 4 <= xEnd) {
      const tag = cv.getUint16(x, true);
      const len = cv.getUint16(x + 2, true);
      if (tag === 0x0001) {
        let p = x + 4;
        if (usize === 0xffffffff && p + 8 <= xEnd) (usize = Number(cv.getBigUint64(p, true))), (p += 8);
        if (comp === 0xffffffff && p + 8 <= xEnd) comp = Number(cv.getBigUint64(p, true));
      }
      x += 4 + len;
    }
    const dir = name.endsWith('/');
    entries.push({ name, size: usize, compressed: comp, dir, encrypted: (flags & 1) === 1 });
    if (!dir) unpacked += usize;
    o += 46 + nLen + xLen + cLen;
  }
  return { entries, total, truncated: entries.length < total, unpacked };
}
