import { randomId, toB64 } from './crypto';
import { chunkSizeOf, readChunk } from './vault';
import { isNative, nativeStream } from './native';
import type { Item } from './types';
import { requireDek } from '../store/session';

/**
 * On-demand decryption streaming ("partial decryption") for large files.
 *
 * Instead of decrypting a whole file into a temporary copy before it can be viewed, a file is
 * exposed to the player / PDF renderer as a virtual, seekable resource:
 *   Android: <localUrl>/_pv_stream/<token> served by PvWebViewClient (HTTP Range), and a seekable
 *            proxy file descriptor for PdfRenderer. Native code pulls chunks from here on demand.
 *   Web:     the same URL served by a Service Worker (public/pv-sw.js).
 * Only the chunks that are actually read are decrypted: opening an 800 MB PDF or seeking to the
 * end of a 4 GB video touches a few MiB. Plaintext never touches disk and is only kept in a small
 * bounded RAM cache (per stream) that is wiped on close and on lock.
 */

// Android keeps its own LRU + read-ahead next to the reader (PvStreams.java): here only a tiny
// cache is needed, otherwise every chunk would sit in RAM twice.
const CACHE_CHUNKS = isNative ? 2 : 6;
const READ_AHEAD = isNative ? 0 : 2;

interface Session {
  token: string;
  item: Item;
  cache: Map<number, Promise<Uint8Array>>;
  refs: number;
  url: string;
}

const sessions = new Map<string, Session>();
const byItem = new Map<string, string>(); // item id → token (one stream per item, shared by viewers)
let epoch = 0;

function getChunk(s: Session, idx: number, prefetch = true): Promise<Uint8Array> {
  let p = s.cache.get(idx);
  if (p) {
    s.cache.delete(idx);
    s.cache.set(idx, p); // LRU touch
  } else {
    const my = epoch;
    p = readChunk(requireDek(), s.item, idx).then((c) => {
      if (my !== epoch) throw new Error('LOCKED');
      return c;
    });
    p.catch(() => s.cache.delete(idx));
    s.cache.set(idx, p);
    while (s.cache.size > CACHE_CHUNKS + READ_AHEAD) s.cache.delete(s.cache.keys().next().value as number);
  }
  if (prefetch) for (let k = 1; k <= READ_AHEAD; k++) if (idx + k < s.item.chunks && !s.cache.has(idx + k)) void getChunk(s, idx + k, false).catch(() => undefined);
  return p;
}

/** Answers a chunk request coming from the native layer / service worker. */
export async function serveChunk(token: string, idx: number): Promise<Uint8Array> {
  const s = sessions.get(token);
  if (!s || idx < 0 || idx >= s.item.chunks) throw new Error('NO_STREAM');
  return getChunk(s, idx);
}

export interface StreamHandle {
  token: string;
  url: string;
  close: () => void;
}

let swReady: Promise<ServiceWorker | null> | null = null;

/** Web only: registers the streaming service worker once and wires its chunk requests. */
export function initWebStreaming(): Promise<ServiceWorker | null> {
  if (swReady) return swReady;
  swReady = (async () => {
    if (isNative || !('serviceWorker' in navigator)) return null;
    try {
      navigator.serviceWorker.addEventListener('message', (e: MessageEvent) => {
        const m = e.data;
        if (!m || m.type !== 'need') return;
        const sw = navigator.serviceWorker.controller;
        serveChunk(m.token, m.idx)
          .then((c) => {
            const copy = c.slice(); // the cached chunk must stay intact: transfer a copy
            sw?.postMessage({ type: 'chunk', req: m.req, data: copy.buffer }, [copy.buffer]);
          })
          .catch(() => sw?.postMessage({ type: 'chunk', req: m.req, error: true }));
      });
      await navigator.serviceWorker.register('./pv-sw.js', { scope: './' });
      await navigator.serviceWorker.ready;
      if (!navigator.serviceWorker.controller) {
        await new Promise<void>((r) => {
          navigator.serviceWorker.addEventListener('controllerchange', () => r(), { once: true });
          setTimeout(r, 3000);
        });
      }
      return navigator.serviceWorker.controller;
    } catch {
      return null;
    }
  })();
  return swReady;
}

/** Native only: chunk requests from PvWebViewClient / the PDF proxy descriptor. */
let nativeWired = false;
function wireNative() {
  if (nativeWired || !isNative) return;
  nativeWired = true;
  void nativeStream.onRequest(({ token, idx, req }) => {
    serveChunk(token, idx)
      .then((c) => nativeStream.supply(req, toB64(c)))
      .catch(() => nativeStream.fail(req));
  });
}

export function canStream(): boolean {
  return isNative || (!!swReady && 'serviceWorker' in navigator);
}

/** Opens (or re-uses) a streaming session for a stored file. Returns null if streaming is unavailable. */
export async function openStream(item: Item, mime: string): Promise<StreamHandle | null> {
  const existing = byItem.get(item.id);
  let s = existing ? sessions.get(existing) : undefined;
  if (s && (s.item.chunks !== item.chunks || s.item.size !== item.size)) s = undefined;
  if (!s) {
    let url: string;
    const token = randomId() + randomId();
    s = { token, item, cache: new Map(), refs: 0, url: '' };
    if (isNative) {
      wireNative();
      url = (await nativeStream.open({ token, size: item.size, mime, chunkSize: chunkSizeOf(item), chunks: item.chunks })).url;
    } else {
      const sw = await initWebStreaming();
      if (!sw) return null;
      await new Promise<void>((resolve) => {
        const ch = new MessageChannel();
        ch.port1.onmessage = () => resolve();
        sw.postMessage({ type: 'open', token, size: item.size, mime, chunkSize: chunkSizeOf(item) }, [ch.port2]);
        setTimeout(resolve, 1500);
      });
      url = new URL(`_pv_stream/${token}`, document.baseURI).href;
    }
    s.url = url;
    sessions.set(token, s);
    byItem.set(item.id, token);
  }
  const sess = s;
  sess.refs++;
  let closed = false;
  return {
    token: sess.token,
    url: sess.url,
    close: () => {
      if (closed) return;
      closed = true;
      if (--sess.refs <= 0) closeSession(sess.token);
    },
  };
}

function closeSession(token: string) {
  const s = sessions.get(token);
  if (!s) return;
  sessions.delete(token);
  if (byItem.get(s.item.id) === token) byItem.delete(s.item.id);
  s.cache.clear();
  if (isNative) void nativeStream.close(token);
  else navigator.serviceWorker?.controller?.postMessage({ type: 'close', token });
}

/** Lock: every stream dies immediately, caches are wiped, late decryptions are discarded. */
export function closeAllStreams() {
  epoch++;
  for (const t of [...sessions.keys()]) closeSession(t);
  if (isNative) void nativeStream.closeAll();
  else navigator.serviceWorker?.controller?.postMessage({ type: 'closeAll' });
}
