import { requireDek, useSession } from '../store/session';
import { toast, useUi } from '../store/ui';
import { activeDbName } from './db';
import { randomId } from './crypto';
import { CHUNK_SIZE, cleanName, clearInflight, importBlob, markInflight, saveProjections, splitName } from './vault';
import { faNum } from './format';
import type { Item, Kind } from './types';
import { spawnMediaWorker } from '../workers/spawn';
import type { FromWorker, ImportMeta } from '../workers/protocol';

export interface PickedFile {
  key: string;
  file: File;
  name: string; // optional custom name ('' = keep original)
}

/**
 * Bulk import pipeline.
 *  - Encryption / IndexedDB writes / thumbnails run in 1–2 media workers (never on the UI thread).
 *  - Files are streamed chunk-by-chunk: a file is never fully loaded in RAM, whatever its size.
 *  - Finished items are committed in batches (one projection transaction + one store update per
 *    batch) instead of one re-render per file, so importing thousands of files stays smooth.
 *  - Progress is byte-accurate and throttled; the whole run can be cancelled.
 */
export async function importFiles(list: PickedFile[], kind: Exclude<Kind, 'text'>): Promise<Item[]> {
  if (!list.length) return [];
  const dek = requireDek();
  const ui = useUi.getState();
  const totalBytes = list.reduce((a, p) => a + Math.max(1, p.file.size), 0);
  const perJob = new Map<number, number>();
  let finishedBytes = 0;
  let finishedCount = 0;
  let cancelled = false;
  let aborted = false; // vault got locked
  const saved: Item[] = [];
  const failed: string[] = [];
  let pending: Item[] = [];
  let flushTimer = 0;
  let flushing: Promise<void> = Promise.resolve();
  let current = list[0];

  const report = () => {
    let inFlight = 0;
    for (const v of perJob.values()) inFlight += v;
    const label = `${faNum(Math.min(list.length, finishedCount + 1))} از ${faNum(list.length)} - ${current.name || current.file.name}`;
    ui.setProgress({ title: 'رمزنگاری و ذخیره‌سازی', detail: label, value: Math.min(1, (finishedBytes + inFlight) / totalBytes), onCancel: cancel, cancelLabel: 'توقف' });
  };

  const flush = () => {
    window.clearTimeout(flushTimer);
    flushTimer = 0;
    const batch = pending;
    pending = [];
    if (!batch.length) return flushing;
    flushing = flushing.then(async () => {
      if (aborted) return;
      try {
        await saveProjections(dek, batch);
        saved.push(...batch);
        useSession.getState().upsert(batch);
      } catch {
        failed.push(...batch.map((b) => b.name));
      } finally {
        batch.forEach((b) => clearInflight(b.id));
      }
    });
    return flushing;
  };
  const commit = (it: Item) => {
    pending.push(it);
    if (pending.length >= 32) void flush();
    else if (!flushTimer) flushTimer = window.setTimeout(() => void flush(), 400);
  };

  const buildItem = (p: PickedFile, id: string, meta: ImportMeta): Item => {
    const { base, ext } = splitName(p.file.name || 'file');
    const now = Date.now();
    return {
      id,
      kind,
      name: cleanName(p.name) || cleanName(base) || cleanName(p.file.name) || 'file',
      ext,
      mime: meta.mime,
      declaredMime: p.file.type || undefined,
      sniffed: true,
      size: p.file.size,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
      chunks: meta.chunks,
      chunkSize: CHUNK_SIZE,
      thumb: meta.thumb || undefined,
      width: meta.width,
      height: meta.height,
    };
  };

  const hc = navigator.hardwareConcurrency || 2;
  const poolSize = list.length > 1 && hc >= 4 ? 2 : 1;
  const workers: Worker[] = [];
  for (let i = 0; i < poolSize; i++) {
    const w = spawnMediaWorker();
    if (w) workers.push(w);
  }
  const activeJobs = new Map<number, { w: Worker; resolve: () => void }>();
  let jobSeq = 0;

  function cancel() {
    if (cancelled) return;
    cancelled = true;
    ui.setProgress({ title: 'در حال توقف...', detail: 'موارد تکمیل‌شده حفظ می‌شوند', value: -1 });
    for (const [job, j] of activeJobs) j.w.postMessage({ type: 'cancel', job });
  }

  // Locking the vault mid-import stops everything immediately (nothing more is written).
  const unsub = useSession.subscribe((s) => {
    if (s.status !== 'unlocked' && !aborted) {
      aborted = true;
      cancelled = true;
      workers.forEach((w) => w.terminate());
      for (const j of activeJobs.values()) j.resolve();
      activeJobs.clear();
    }
  });

  report();
  let next = 0;
  try {
    if (!workers.length) {
      // Fallback: main-thread streaming import (one chunk in memory at a time).
      for (const p of list) {
        if (cancelled) break;
        current = p;
        try {
          const it = await importBlob(dek, p.file, {
            kind,
            name: p.name,
            signal: { get cancelled() { return cancelled; } } as { cancelled: boolean },
            onProgress: (f) => {
              perJob.set(0, f * Math.max(1, p.file.size));
              report();
            },
          });
          saved.push(it);
          useSession.getState().upsert([it]);
        } catch (e) {
          if ((e as Error).message !== 'CANCELLED') failed.push(p.file.name);
        }
        perJob.delete(0);
        finishedBytes += Math.max(1, p.file.size);
        finishedCount++;
      }
    } else {
      const runOn = (w: Worker): Promise<void> =>
        new Promise<void>((resolveLane) => {
          const step = () => {
            if (cancelled || next >= list.length) return resolveLane();
            const p = list[next++];
            current = p;
            const job = ++jobSeq;
            const id = randomId();
            markInflight(id);
            perJob.set(job, 0);
            const onMsg = (e: MessageEvent<FromWorker>) => {
              const m = e.data;
              if (m.job !== job) return;
              if (m.type === 'progress') {
                perJob.set(job, m.done);
                report();
                return;
              }
              w.removeEventListener('message', onMsg);
              activeJobs.delete(job);
              perJob.delete(job);
              finishedBytes += Math.max(1, p.file.size);
              finishedCount++;
              if (m.type === 'done') commit(buildItem(p, id, m.meta));
              else {
                clearInflight(id);
                if (!(m.type === 'error' && m.cancelled)) failed.push(p.file.name);
              }
              report();
              step();
            };
            w.addEventListener('message', onMsg);
            activeJobs.set(job, {
              w,
              resolve: () => {
                w.removeEventListener('message', onMsg);
                clearInflight(id);
                resolveLane();
              },
            });
            w.postMessage({ type: 'import', job, id, key: dek, dbName: activeDbName(), file: p.file, kind, chunkSize: CHUNK_SIZE });
          };
          step();
        });
      await Promise.all(workers.map(runOn));
    }
    await flush();
  } finally {
    unsub();
    workers.forEach((w) => w.terminate());
    ui.setProgress(null);
  }
  if (aborted) return [];
  const skipped = list.length - saved.length - failed.length;
  if (failed.length) toast(`${faNum(failed.length)} مورد ذخیره نشد`, 'err');
  if (cancelled && skipped > 0) toast(`${faNum(saved.length)} مورد ذخیره شد؛ ${faNum(skipped)} مورد لغو شد`, 'info');
  else if (saved.length) toast(`${faNum(saved.length)} مورد رمزنگاری و ذخیره شد`);
  return saved;
}
