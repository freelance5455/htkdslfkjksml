import { unlockDek } from './crypto';
import { readHeader } from './db';
import { isNative, uninstallGuard } from './native';
import { usePrefs } from '../store/prefs';
import { passwordDialog, toast, useUi } from '../store/ui';

/**
 * Uninstall protection = Android Device Administrator.
 * While the app is an active device admin, Android refuses to uninstall it until the admin is
 * deactivated. Deactivating from inside the app needs the vault password; deactivating from
 * system Settings first locks the phone (device PIN/pattern/biometric needed to continue).
 * The pref only mirrors the real system state, which is re-read on every resume.
 */
export async function syncUninstallGuard() {
  if (!isNative) return;
  try {
    const s = await uninstallGuard.status();
    const p = usePrefs.getState();
    if (p.uninstallGuard !== s.active) p.set({ uninstallGuard: s.active });
  } catch {
    /* plugin missing: leave as is */
  }
}

export async function setUninstallGuard(on: boolean): Promise<boolean> {
  const prefs = usePrefs.getState();
  if (!isNative) {
    toast('این قابلیت فقط در نسخه اندروید برنامه در دسترس است', 'info');
    return false;
  }
  if (on) {
    useUi.setState({ pickerActiveUntil: Date.now() + 5 * 60_000 });
    try {
      const r = await uninstallGuard.enable('با فعال بودن این گزینه، حذف Personal Vault تا زمانی که محافظت را از داخل برنامه (با رمز گاوصندوق) خاموش نکنید ممکن نیست. غیرفعال‌سازی از تنظیمات گوشی نیز ابتدا قفل صفحه گوشی را فعال می‌کند.');
      prefs.set({ uninstallGuard: r.active });
      toast(r.active ? 'محافظت در برابر حذف فعال شد' : 'فعال‌سازی لغو شد', r.active ? 'ok' : 'info');
      return r.active;
    } catch {
      toast('فعال‌سازی محافظت ممکن نشد', 'err');
      return false;
    } finally {
      useUi.setState({ pickerActiveUntil: Date.now() + 1500 });
    }
  }
  const pw = await passwordDialog({ title: 'غیرفعال کردن محافظت', message: 'برای خاموش کردن محافظت در برابر حذف، رمز گاوصندوق را وارد کنید.', confirmText: 'غیرفعال کردن' });
  if (!pw) return prefs.uninstallGuard;
  const h = await readHeader();
  if (!h) return prefs.uninstallGuard;
  const ui = useUi.getState();
  ui.setProgress({ title: 'بررسی رمز عبور', value: -1 });
  const ok = await unlockDek(h, pw).then(() => true, () => false);
  ui.setProgress(null);
  if (!ok) {
    toast('رمز عبور نادرست است', 'err');
    return true;
  }
  try {
    const r = await uninstallGuard.disable();
    prefs.set({ uninstallGuard: r.active });
    toast('محافظت غیرفعال شد؛ حذف برنامه مثل حالت عادی اندروید است');
    return r.active;
  } catch {
    toast('غیرفعال‌سازی ممکن نشد', 'err');
    return true;
  }
}
