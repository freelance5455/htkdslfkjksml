import { requireDek, useSession } from '../store/session';
import { toast, useUi } from '../store/ui';
import { copyToClipboard, saveStream } from './native';
import type { Item, Kind } from './types';
import { downloadName, iterateChunks, purge, readText, saveProjections, saveText, cleanName } from './vault';
import { importFiles, type PickedFile } from './importer';
import { forgetThumb } from './media';
import { faNum } from './format';

const items = () => useSession.getState().items;

export type { PickedFile } from './importer';

export function importPicked(list: PickedFile[], kind: Exclude<Kind, 'text'>): Promise<Item[]> {
  return importFiles(list, kind);
}

async function mutate(ids: string[], fn: (i: Item) => Item) {
  const dek = requireDek();
  const list = ids.map((id) => items().get(id)).filter((x): x is Item => !!x).map(fn);
  await saveProjections(dek, list);
  useSession.getState().upsert(list);
  return list.length;
}

export async function moveToTrash(ids: string[]) {
  const now = Date.now();
  const n = await mutate(ids, (i) => ({ ...i, deletedAt: now }));
  toast(`${faNum(n)} مورد به سطل زباله منتقل شد`);
}

export async function restoreFromTrash(ids: string[]) {
  const n = await mutate(ids, (i) => ({ ...i, deletedAt: null }));
  toast(`${faNum(n)} مورد بازیابی شد`);
}

export async function deleteForever(ids: string[]) {
  await purge(ids);
  ids.forEach(forgetThumb);
  useSession.getState().drop(ids);
  toast(`${faNum(ids.length)} مورد برای همیشه حذف شد`);
}

export async function renameItem(id: string, name: string) {
  const clean = cleanName(name);
  if (!clean) return;
  await mutate([id], (i) => ({ ...i, name: clean, updatedAt: Date.now() }));
  toast('نام تغییر کرد');
}

export async function upsertText(existing: Item | null, title: string, body: string): Promise<Item> {
  const item = await saveText(requireDek(), existing, title, body);
  useSession.getState().upsert([item]);
  return item;
}

export async function copyItemText(id: string) {
  try {
    const text = await readText(requireDek(), id);
    const ok = await copyToClipboard(text);
    toast(ok ? 'متن رونوشت شد' : 'رونوشت انجام نشد', ok ? 'ok' : 'err');
  } catch {
    toast('خواندن متن ممکن نشد', 'err');
  }
}

export async function downloadItems(ids: string[]) {
  const dek = requireDek();
  const list = ids.map((id) => items().get(id)).filter((x): x is Item => !!x);
  if (!list.length) return;
  const ui = useUi.getState();
  const totalBytes = list.reduce((a, i) => a + Math.max(1, i.size), 0);
  let doneBytes = 0;
  let ok = 0;
  let cancelled = false;
  const cancel = () => {
    cancelled = true;
  };
  try {
    for (let n = 0; n < list.length && !cancelled; n++) {
      const it = list[n];
      const detail = `${faNum(n + 1)} از ${faNum(list.length)} - ${it.name}`;
      const base = doneBytes;
      ui.setProgress({ title: 'رمزگشایی و ذخیره در دانلودها', detail, value: base / totalBytes, onCancel: cancel, cancelLabel: 'توقف' });
      try {
        let source: AsyncIterable<Uint8Array>;
        if (it.kind === 'text') {
          const text = await readText(dek, it.id);
          source = (async function* () {
            yield new TextEncoder().encode(text);
          })();
        } else source = iterateChunks(dek, it);
        let written = 0;
        const tracked = (async function* () {
          for await (const c of source) {
            if (cancelled) throw new Error('CANCELLED');
            written += c.length;
            ui.setProgress({ title: 'رمزگشایی و ذخیره در دانلودها', detail, value: Math.min(1, (base + written) / totalBytes), onCancel: cancel, cancelLabel: 'توقف' });
            yield c;
          }
        })();
        await saveStream(downloadName(it), it.kind === 'text' ? 'text/plain' : it.mime, tracked);
        ok++;
      } catch {
        /* reported below */
      }
      doneBytes += Math.max(1, it.size);
    }
  } finally {
    ui.setProgress(null);
  }
  if (cancelled) toast(`${faNum(ok)} مورد ذخیره شد؛ بقیه لغو شد`, 'info');
  else if (ok === list.length) toast(list.length === 1 ? 'در پوشه Download/PersonalVault ذخیره شد' : `${faNum(ok)} مورد در Download/PersonalVault ذخیره شد`);
  else toast(`${faNum(list.length - ok)} مورد ذخیره نشد`, 'err');
}
