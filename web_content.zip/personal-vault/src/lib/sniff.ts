/**
 * Content-type detection from the file's own bytes (magic numbers), used before any
 * preview decision. The extension is only a tie-breaker when the bytes are inconclusive.
 * Pure functions: safe to use from the main thread and from workers.
 */

export type PreviewKind = 'image' | 'pdf' | 'audio' | 'video' | 'text' | 'archive' | 'document' | 'other';

const ascii = (b: Uint8Array, o: number, n: number) => {
  let s = '';
  for (let i = o; i < o + n && i < b.length; i++) s += String.fromCharCode(b[i]);
  return s;
};
const starts = (b: Uint8Array, sig: number[], o = 0) => sig.every((v, i) => b[o + i] === v);

const TEXT_EXT = new Set([
  'txt', 'md', 'markdown', 'csv', 'tsv', 'log', 'json', 'xml', 'yml', 'yaml', 'ini', 'conf', 'cfg', 'toml', 'env', 'properties',
  'js', 'mjs', 'cjs', 'ts', 'tsx', 'jsx', 'css', 'scss', 'less', 'html', 'htm', 'svg', 'py', 'java', 'kt', 'kts', 'c', 'h', 'cpp', 'hpp',
  'cs', 'go', 'rs', 'rb', 'php', 'sh', 'bat', 'ps1', 'sql', 'swift', 'dart', 'lua', 'r', 'srt', 'vtt', 'gradle', 'tex', 'rtf',
]);

/** Detects the real MIME type from the first bytes of a file (at least 4 KiB recommended). */
export function sniffMime(head: Uint8Array, ext = ''): string | null {
  const b = head;
  const e = ext.toLowerCase();
  if (b.length < 4) return b.length === 0 ? 'application/x-empty' : null;

  // documents
  if (ascii(b, 0, 5) === '%PDF-') return 'application/pdf';
  if (starts(b, [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1])) {
    if (e === 'xls') return 'application/vnd.ms-excel';
    if (e === 'ppt') return 'application/vnd.ms-powerpoint';
    if (e === 'msg') return 'application/vnd.ms-outlook';
    return 'application/msword';
  }
  if (ascii(b, 0, 5) === '{\\rtf') return 'application/rtf';

  // images
  if (starts(b, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return 'image/png';
  if (starts(b, [0xff, 0xd8, 0xff])) return 'image/jpeg';
  if (ascii(b, 0, 6) === 'GIF87a' || ascii(b, 0, 6) === 'GIF89a') return 'image/gif';
  if (ascii(b, 0, 4) === 'RIFF' && ascii(b, 8, 4) === 'WEBP') return 'image/webp';
  if (ascii(b, 0, 2) === 'BM' && b.length > 14 && (b[14] === 12 || b[14] === 40 || b[14] === 56 || b[14] === 108 || b[14] === 124)) return 'image/bmp';
  if (starts(b, [0x00, 0x00, 0x01, 0x00]) && b[4] > 0 && b[5] === 0) return 'image/x-icon';
  if (starts(b, [0x49, 0x49, 0x2a, 0x00]) || starts(b, [0x4d, 0x4d, 0x00, 0x2a])) return 'image/tiff';

  // ISO-BMFF (mp4 / mov / m4a / heic / avif / 3gp)
  if (ascii(b, 4, 4) === 'ftyp') {
    const brand = ascii(b, 8, 4).toLowerCase();
    const size = Math.min(b.length, ((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]) >>> 0 || 32);
    const brands = [brand];
    for (let o = 16; o + 4 <= size; o += 4) brands.push(ascii(b, o, 4).toLowerCase());
    if (brands.includes('avif') || brands.includes('avis')) return 'image/avif';
    if (['heic', 'heix', 'heim', 'heis', 'hevc', 'hevx', 'mif1', 'msf1'].some((x) => brands.includes(x)) && !brands.includes('iso4')) return brand === 'mif1' || brand === 'msf1' ? 'image/heif' : 'image/heic';
    if (brand === 'm4a ' || brand === 'm4b ' || brand === 'm4p ' || (brand === 'mp42' && e === 'm4a')) return 'audio/mp4';
    if (brand === 'qt  ') return 'video/quicktime';
    if (brand.startsWith('3g2')) return 'video/3gpp2';
    if (brand.startsWith('3gp')) return e === 'm4a' || e === '3ga' ? 'audio/3gpp' : 'video/3gpp';
    if (e === 'm4a' || e === 'aac') return 'audio/mp4';
    return 'video/mp4';
  }
  if (starts(b, [0x1a, 0x45, 0xdf, 0xa3])) {
    const s = ascii(b, 0, Math.min(b.length, 64));
    if (s.includes('webm')) return e === 'weba' ? 'audio/webm' : 'video/webm';
    return e === 'mka' ? 'audio/x-matroska' : 'video/x-matroska';
  }
  if (ascii(b, 0, 4) === 'RIFF') {
    const t = ascii(b, 8, 4);
    if (t === 'WAVE') return 'audio/wav';
    if (t === 'AVI ') return 'video/x-msvideo';
  }
  if (ascii(b, 0, 4) === 'OggS') {
    const s = ascii(b, 0, Math.min(b.length, 128));
    if (s.includes('theora')) return 'video/ogg';
    if (s.includes('OpusHead')) return 'audio/ogg';
    return 'audio/ogg';
  }
  if (ascii(b, 0, 4) === 'fLaC') return 'audio/flac';
  if (ascii(b, 0, 3) === 'ID3') return 'audio/mpeg';
  if (ascii(b, 0, 5) === '#!AMR') return 'audio/amr';
  if (ascii(b, 0, 4) === 'MThd') return 'audio/midi';
  if (b[0] === 0xff && (b[1] & 0xf6) === 0xf0) return 'audio/aac'; // ADTS
  if (b[0] === 0xff && (b[1] & 0xe0) === 0xe0 && (b[1] & 0x06) !== 0) return 'audio/mpeg'; // MPEG audio frame sync
  if (b[0] === 0x47 && b.length > 188 && b[188] === 0x47) return 'video/mp2t';
  if (starts(b, [0x00, 0x00, 0x01, 0xba])) return 'video/mpeg';
  if (starts(b, [0x30, 0x26, 0xb2, 0x75, 0x8e, 0x66, 0xcf, 0x11])) return e === 'wma' ? 'audio/x-ms-wma' : 'video/x-ms-wmv';
  if (ascii(b, 0, 3) === 'FLV') return 'video/x-flv';

  // archives & containers
  if (starts(b, [0x50, 0x4b, 0x03, 0x04]) || starts(b, [0x50, 0x4b, 0x05, 0x06]) || starts(b, [0x50, 0x4b, 0x07, 0x08])) return zipFlavour(b, e);
  if (ascii(b, 0, 7) === 'Rar!\x1a\x07\x00' || ascii(b, 0, 8) === 'Rar!\x1a\x07\x01\x00') return 'application/vnd.rar';
  if (starts(b, [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c])) return 'application/x-7z-compressed';
  if (starts(b, [0x1f, 0x8b])) return 'application/gzip';
  if (ascii(b, 0, 3) === 'BZh') return 'application/x-bzip2';
  if (starts(b, [0xfd, 0x37, 0x7a, 0x58, 0x5a, 0x00])) return 'application/x-xz';
  if (starts(b, [0x28, 0xb5, 0x2f, 0xfd])) return 'application/zstd';
  if (b.length > 262 && ascii(b, 257, 5) === 'ustar') return 'application/x-tar';

  // binaries
  if (ascii(b, 0, 16) === 'SQLite format 3\x00') return 'application/vnd.sqlite3';
  if (ascii(b, 0, 2) === 'MZ') return 'application/vnd.microsoft.portable-executable';
  if (starts(b, [0x7f, 0x45, 0x4c, 0x46])) return 'application/x-elf';
  if (ascii(b, 0, 4) === 'dex\n') return 'application/x-dex';
  if (ascii(b, 0, 4) === 'wOFF' || ascii(b, 0, 4) === 'wOF2') return 'font/woff';
  if (starts(b, [0x00, 0x01, 0x00, 0x00, 0x00]) || ascii(b, 0, 4) === 'OTTO') return 'font/ttf';

  // text-like
  return sniffText(b, e);
}

function zipFlavour(b: Uint8Array, e: string): string {
  // first local header file name: offset 30, length at 26
  const nameLen = b[26] | (b[27] << 8);
  const name = ascii(b, 30, Math.min(nameLen, 120));
  if (name === 'mimetype') {
    const extra = b[28] | (b[29] << 8);
    const m = ascii(b, 30 + nameLen + extra, 60).replace(/[^\x20-\x7e].*$/, '');
    if (m.startsWith('application/')) return m;
  }
  const all = ascii(b, 0, Math.min(b.length, 8192));
  if (all.includes('AndroidManifest.xml') || all.includes('classes.dex') || e === 'apk') return 'application/vnd.android.package-archive';
  if (all.includes('[Content_Types].xml') || all.includes('word/') || all.includes('xl/') || all.includes('ppt/')) {
    if (all.includes('word/') || e === 'docx') return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    if (all.includes('xl/') || e === 'xlsx') return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    if (all.includes('ppt/') || e === 'pptx') return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
  }
  if (e === 'jar') return 'application/java-archive';
  return 'application/zip';
}

function sniffText(b: Uint8Array, e: string): string | null {
  if (starts(b, [0xef, 0xbb, 0xbf]) || starts(b, [0xff, 0xfe]) || starts(b, [0xfe, 0xff])) return textMimeFor(e, b);
  const n = Math.min(b.length, 4096);
  let ctrl = 0;
  for (let i = 0; i < n; i++) {
    const c = b[i];
    if (c === 0) return null; // binary
    if (c < 9 || (c > 13 && c < 32 && c !== 27)) ctrl++;
  }
  if (ctrl > n * 0.02) return null;
  // must decode as UTF-8 (allowing a truncated trailing sequence)
  try {
    new TextDecoder('utf-8', { fatal: true }).decode(b.subarray(0, trimUtf8(b, n)));
  } catch {
    return null;
  }
  return textMimeFor(e, b);
}

function trimUtf8(b: Uint8Array, n: number): number {
  let end = n;
  for (let k = 1; k <= 3 && end - k >= 0; k++) {
    const c = b[end - k];
    if ((c & 0xc0) === 0x80) continue;
    if ((c & 0xc0) === 0xc0) end = end - k;
    break;
  }
  return end;
}

function textMimeFor(e: string, b: Uint8Array): string {
  const s = ascii(b, 0, 256).trimStart().toLowerCase();
  if (s.startsWith('<svg') || (s.startsWith('<?xml') && ascii(b, 0, 1024).includes('<svg'))) return 'image/svg+xml';
  if (s.startsWith('<!doctype html') || s.startsWith('<html')) return 'text/html';
  if (s.startsWith('<?xml')) return 'text/xml';
  if (e === 'json' || ((s.startsWith('{') || s.startsWith('[')) && e !== 'txt')) return 'application/json';
  if (e === 'csv') return 'text/csv';
  if (e === 'md' || e === 'markdown') return 'text/markdown';
  if (e === 'srt' || e === 'vtt') return 'text/vtt';
  return 'text/plain';
}

/** Best-effort MIME from the extension alone (used only when the bytes are inconclusive). */
export function mimeFromExt(ext: string): string | null {
  const e = ext.toLowerCase();
  const map: Record<string, string> = {
    mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', flac: 'audio/flac', amr: 'audio/amr',
    mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', mkv: 'video/x-matroska', '3gp': 'video/3gpp', avi: 'video/x-msvideo',
    jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp', heic: 'image/heic', heif: 'image/heif', avif: 'image/avif', svg: 'image/svg+xml',
    pdf: 'application/pdf', zip: 'application/zip', rar: 'application/vnd.rar', '7z': 'application/x-7z-compressed', gz: 'application/gzip', tar: 'application/x-tar',
    apk: 'application/vnd.android.package-archive', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ppt: 'application/vnd.ms-powerpoint',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', odt: 'application/vnd.oasis.opendocument.text', epub: 'application/epub+zip',
  };
  if (map[e]) return map[e];
  if (TEXT_EXT.has(e)) return 'text/plain';
  return null;
}

/** Final type: sniffed bytes first; the extension / declared type only when bytes say nothing. */
export function resolveMime(head: Uint8Array, ext: string, declared: string): string {
  const s = sniffMime(head, ext);
  if (s && s !== 'text/plain') return s;
  if (s === 'text/plain') {
    // plain text with a code/text extension stays text; an mp3 without ID3 may look like nothing
    return 'text/plain';
  }
  // Bytes inconclusive: only trust hints that do not enable rich rendering of arbitrary bytes.
  const byExt = mimeFromExt(ext);
  if (byExt && (byExt.startsWith('audio/') || byExt.startsWith('video/'))) return byExt; // the media element validates it
  if (declared && (declared.startsWith('audio/') || declared.startsWith('video/'))) return declared;
  return 'application/octet-stream';
}

export function previewKind(mime: string): PreviewKind {
  const m = mime.toLowerCase();
  if (m === 'application/pdf') return 'pdf';
  if (m.startsWith('image/')) return 'image';
  if (m.startsWith('audio/')) return 'audio';
  if (m.startsWith('video/')) return 'video';
  if (m.startsWith('text/') || m === 'application/json' || m === 'application/x-empty') return 'text';
  if (['application/zip', 'application/java-archive', 'application/vnd.rar', 'application/x-7z-compressed', 'application/gzip', 'application/x-bzip2', 'application/x-xz', 'application/zstd', 'application/x-tar', 'application/vnd.android.package-archive'].includes(m)) return 'archive';
  if (m.includes('officedocument') || m.includes('opendocument') || m.includes('msword') || m.includes('ms-excel') || m.includes('ms-powerpoint') || m === 'application/rtf' || m === 'application/epub+zip') return 'document';
  return 'other';
}

/** Images the WebView can decode directly (HEIC/TIFF are not reliably supported). */
export function isWebImage(mime: string): boolean {
  return ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp', 'image/avif', 'image/x-icon', 'image/svg+xml'].includes(mime);
}

/** Reads pixel dimensions from an image header without decoding it (JPEG/PNG/GIF/WEBP/BMP). */
export function imageSize(b: Uint8Array): { width: number; height: number } | null {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  try {
    if (starts(b, [0x89, 0x50, 0x4e, 0x47])) return { width: dv.getUint32(16), height: dv.getUint32(20) };
    if (ascii(b, 0, 3) === 'GIF') return { width: dv.getUint16(6, true), height: dv.getUint16(8, true) };
    if (ascii(b, 0, 2) === 'BM') return { width: Math.abs(dv.getInt32(18, true)), height: Math.abs(dv.getInt32(22, true)) };
    if (ascii(b, 0, 4) === 'RIFF' && ascii(b, 8, 4) === 'WEBP') {
      const f = ascii(b, 12, 4);
      if (f === 'VP8X') return { width: 1 + (b[24] | (b[25] << 8) | (b[26] << 16)), height: 1 + (b[27] | (b[28] << 8) | (b[29] << 16)) };
      if (f === 'VP8 ') return { width: dv.getUint16(26, true) & 0x3fff, height: dv.getUint16(28, true) & 0x3fff };
      if (f === 'VP8L') {
        const v = dv.getUint32(21, true);
        return { width: (v & 0x3fff) + 1, height: ((v >> 14) & 0x3fff) + 1 };
      }
    }
    if (starts(b, [0xff, 0xd8])) {
      let o = 2;
      let orient = 1;
      while (o + 9 < b.length) {
        if (b[o] !== 0xff) { o++; continue; }
        const marker = b[o + 1];
        if (marker === 0xd8 || (marker >= 0xd0 && marker <= 0xd7) || marker === 0x01 || marker === 0xff) { o += marker === 0xff ? 1 : 2; continue; }
        const len = dv.getUint16(o + 2);
        if (marker === 0xe1 && ascii(b, o + 4, 4) === 'Exif') orient = exifOrientation(b, o + 10) ?? 1;
        if ((marker >= 0xc0 && marker <= 0xc3) || (marker >= 0xc5 && marker <= 0xc7) || (marker >= 0xc9 && marker <= 0xcb) || (marker >= 0xcd && marker <= 0xcf)) {
          const h = dv.getUint16(o + 5);
          const w = dv.getUint16(o + 7);
          return orient >= 5 ? { width: h, height: w } : { width: w, height: h };
        }
        o += 2 + len;
      }
    }
  } catch {
    return null;
  }
  return null;
}

function exifOrientation(b: Uint8Array, tiff: number): number | null {
  if (tiff + 8 > b.length) return null;
  const le = b[tiff] === 0x49;
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  const ifd = tiff + dv.getUint32(tiff + 4, le);
  if (ifd + 2 > b.length) return null;
  const n = dv.getUint16(ifd, le);
  for (let i = 0; i < n; i++) {
    const e = ifd + 2 + i * 12;
    if (e + 12 > b.length) return null;
    if (dv.getUint16(e, le) === 0x0112) return dv.getUint16(e + 8, le);
  }
  return null;
}

/** Human label for a MIME type (Persian UI). */
export function kindLabel(kind: PreviewKind, mime: string): string {
  switch (kind) {
    case 'image': return 'تصویر';
    case 'pdf': return 'سند PDF';
    case 'audio': return 'فایل صوتی';
    case 'video': return 'ویدیو';
    case 'text': return mime === 'application/json' ? 'JSON' : 'فایل متنی';
    case 'archive': return mime === 'application/vnd.android.package-archive' ? 'بسته نصبی Android' : 'فایل فشرده';
    case 'document': return 'سند اداری';
    default: return 'فایل';
  }
}
