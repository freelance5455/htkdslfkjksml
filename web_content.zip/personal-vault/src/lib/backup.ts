import { deflateSync, inflateSync, strFromU8, strToU8 } from 'fflate';
import { equalBytes, fromB64, open, randomId, seal, sha256, toB64, unlockDek, utf8, type VaultHeader, WrongPasswordError } from './crypto';
import { getDb, openVaultDb, deleteDb, switchActiveDb, readHeader } from './db';
import { decryptProjection } from './vault';
import type { Item } from './types';

/**
 * .pvault backup container (streamable, verifiable):
 *
 *   "PVBAK1\n" | u32 headerLen | header JSON (KDF params + wrapped DEK; already safe to expose)
 *   frames*    | u32 frameLen | frame
 *   manifest   | u32 len | AES-GCM(DEK, deflate(JSON{counts, sha256 of header & every frame}))
 *   trailer    | u32 manifestOffsetLo | u32 manifestOffsetHi | "PVEND1"
 *
 * frame = u8 store | u16 idLen | id | u32 idx | u8 ivLen | iv | u32 ctLen | ct
 * Records are copied as ciphertext: the backup is exactly as secret as the vault.
 * Restore never touches the live database until the whole file has been verified and
 * imported into a staging database; then the active pointer is switched atomically.
 */

const MAGIC = utf8('PVBAK1\n');
const END = utf8('PVEND1');
const STORES = ['items', 'chunks', 'bodies', 'thumbs'] as const;
type StoreName = (typeof STORES)[number];
const MANIFEST_AAD = 'pv:backup:manifest:v1';

interface HeaderJson {
  format: 'personal-vault-backup';
  version: 1;
  createdAt: number;
  vault: { v: 1; kdf: 'PBKDF2-SHA256'; iterations: number; salt: string; wrapIv: string; wrappedDek: string; createdAt: number; updatedAt: number };
}
interface Manifest {
  format: 'personal-vault-backup';
  version: 1;
  headerHash: string;
  counts: Record<StoreName, number>;
  frames: string[];
}

const u32 = (n: number) => {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setUint32(0, n, true);
  return b;
};

function encodeFrame(store: number, id: string, idx: number, iv: Uint8Array, ct: Uint8Array): Uint8Array {
  const idB = utf8(id);
  const out = new Uint8Array(1 + 2 + idB.length + 4 + 1 + iv.length + 4 + ct.length);
  const dv = new DataView(out.buffer);
  let o = 0;
  out[o++] = store;
  dv.setUint16(o, idB.length, true); o += 2;
  out.set(idB, o); o += idB.length;
  dv.setUint32(o, idx, true); o += 4;
  out[o++] = iv.length;
  out.set(iv, o); o += iv.length;
  dv.setUint32(o, ct.length, true); o += 4;
  out.set(ct, o);
  return out;
}

function decodeFrame(b: Uint8Array) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  let o = 0;
  const need = (n: number) => {
    if (o + n > b.length) throw new BackupError('ساختار رکورد پشتیبان نامعتبر است');
  };
  need(3);
  const store = b[o++];
  const idLen = dv.getUint16(o, true); o += 2;
  need(idLen + 5);
  const id = strFromU8(b.subarray(o, o + idLen)); o += idLen;
  const idx = dv.getUint32(o, true); o += 4;
  const ivLen = b[o++];
  need(ivLen + 4);
  const iv = b.slice(o, o + ivLen); o += ivLen;
  const ctLen = dv.getUint32(o, true); o += 4;
  need(ctLen);
  if (o + ctLen !== b.length) throw new BackupError('ساختار رکورد پشتیبان نامعتبر است');
  const ct = b.slice(o, o + ctLen);
  if (store < 1 || store > 4 || ivLen !== 12 || !/^[0-9a-f]{32}$/.test(id)) throw new BackupError('رکورد ناشناخته در فایل پشتیبان');
  return { store: STORES[store - 1], id, idx, iv, ct };
}

export class BackupError extends Error {}

// ---------------------------------------------------------------- export

export async function* createBackupStream(dek: CryptoKey, onProgress?: (f: number) => void): AsyncGenerator<Uint8Array> {
  const h = await readHeader();
  if (!h) throw new BackupError('گاوصندوق پیدا نشد');
  const header: HeaderJson = {
    format: 'personal-vault-backup',
    version: 1,
    createdAt: Date.now(),
    vault: { v: 1, kdf: h.kdf, iterations: h.iterations, salt: toB64(h.salt), wrapIv: toB64(h.wrapIv), wrappedDek: toB64(h.wrappedDek), createdAt: h.createdAt, updatedAt: h.updatedAt },
  };
  const headerBytes = strToU8(JSON.stringify(header));
  const frames: string[] = [];
  const counts: Record<StoreName, number> = { items: 0, chunks: 0, bodies: 0, thumbs: 0 };
  let offset = 0;
  const emit = (b: Uint8Array) => {
    offset += b.length;
    return b;
  };
  yield emit(MAGIC);
  yield emit(u32(headerBytes.length));
  yield emit(headerBytes);

  const db = await getDb();
  const itemRows = await db.getAll('items'); // projections are small
  const [bodyKeys, thumbKeys, chunkKeys] = await Promise.all([db.getAllKeys('bodies'), db.getAllKeys('thumbs'), db.getAllKeys('chunks')]);
  const total = itemRows.length + bodyKeys.length + thumbKeys.length + chunkKeys.length || 1;
  let done = 0;

  const writeFrame = async (store: StoreName, id: string, idx: number, iv: Uint8Array, ct: Uint8Array) => {
    const f = encodeFrame(STORES.indexOf(store) + 1, id, idx, iv, ct);
    frames.push(toB64(await sha256(f)));
    counts[store]++;
    done++;
    onProgress?.(done / total);
    return [u32(f.length), f];
  };

  for (const r of itemRows) for (const p of await writeFrame('items', r.id, 0, r.iv, r.ct)) yield emit(p);
  for (const k of bodyKeys) {
    const r = await db.get('bodies', k);
    if (r) for (const p of await writeFrame('bodies', r.id, 0, r.iv, r.ct)) yield emit(p);
  }
  for (const k of thumbKeys) {
    const r = await db.get('thumbs', k);
    if (r) for (const p of await writeFrame('thumbs', r.id, 0, r.iv, r.ct)) yield emit(p);
  }
  for (const k of chunkKeys) {
    const r = await db.get('chunks', k); // one chunk in memory at a time
    if (r) for (const p of await writeFrame('chunks', r.id, r.idx, r.iv, r.ct)) yield emit(p);
  }

  const manifest: Manifest = { format: 'personal-vault-backup', version: 1, headerHash: toB64(await sha256(headerBytes)), counts, frames };
  const sealed = await seal(dek, deflateSync(strToU8(JSON.stringify(manifest))), MANIFEST_AAD);
  const mBytes = new Uint8Array(12 + sealed.ct.length);
  mBytes.set(sealed.iv, 0);
  mBytes.set(sealed.ct, 12);
  const manifestOffset = offset;
  yield emit(u32(mBytes.length));
  yield emit(mBytes);
  yield emit(u32(manifestOffset % 2 ** 32));
  yield emit(u32(Math.floor(manifestOffset / 2 ** 32)));
  yield emit(END);
}

// ---------------------------------------------------------------- restore

class Reader {
  private buf = new Uint8Array(0);
  private bufStart = 0;
  constructor(private file: Blob, public pos = 0) {}
  async read(n: number): Promise<Uint8Array> {
    if (this.pos + n > this.file.size) throw new BackupError('فایل پشتیبان ناقص است');
    const rel = this.pos - this.bufStart;
    if (rel < 0 || rel + n > this.buf.length) {
      const size = Math.max(n, 4 * 1024 * 1024);
      this.buf = new Uint8Array(await this.file.slice(this.pos, Math.min(this.file.size, this.pos + size)).arrayBuffer());
      this.bufStart = this.pos;
    }
    const s = this.pos - this.bufStart;
    this.pos += n;
    return this.buf.subarray(s, s + n);
  }
  async u32(): Promise<number> {
    const b = await this.read(4);
    return new DataView(b.buffer, b.byteOffset, 4).getUint32(0, true);
  }
}

export interface RestoreInfo {
  header: VaultHeader;
  manifest: Manifest;
  headerBytes: Uint8Array;
  framesStart: number;
  manifestOffset: number;
}

/** Step 1: checks structure, password and manifest authenticity. Nothing is written. */
export async function inspectBackup(file: Blob, password: string): Promise<{ info: RestoreInfo; dek: CryptoKey }> {
  if (file.size < MAGIC.length + 4 + 18) throw new BackupError('فایل انتخاب‌شده پشتیبان معتبر نیست');
  const r = new Reader(file);
  if (!equalBytes(await r.read(MAGIC.length), MAGIC)) throw new BackupError('این فایل پشتیبان Personal Vault نیست');
  const hLen = await r.u32();
  if (hLen > 64 * 1024) throw new BackupError('سربرگ پشتیبان نامعتبر است');
  const headerBytes = (await r.read(hLen)).slice();
  let hj: HeaderJson;
  try {
    hj = JSON.parse(strFromU8(headerBytes)) as HeaderJson;
  } catch {
    throw new BackupError('سربرگ پشتیبان خراب است');
  }
  if (hj.format !== 'personal-vault-backup' || hj.version !== 1 || hj.vault?.kdf !== 'PBKDF2-SHA256') throw new BackupError('نسخه یا قالب پشتیبان پشتیبانی نمی‌شود');
  const framesStart = r.pos;

  const tail = new Reader(file, file.size - 14);
  const lo = await tail.u32();
  const hi = await tail.u32();
  if (!equalBytes(await tail.read(6), END)) throw new BackupError('فایل پشتیبان ناقص است (پایان فایل پیدا نشد)');
  const manifestOffset = hi * 2 ** 32 + lo;
  if (manifestOffset < framesStart || manifestOffset > file.size - 18) throw new BackupError('فهرست پشتیبان نامعتبر است');

  const header: VaultHeader = {
    v: 1,
    kdf: 'PBKDF2-SHA256',
    iterations: hj.vault.iterations,
    salt: fromB64(hj.vault.salt),
    wrapIv: fromB64(hj.vault.wrapIv),
    wrappedDek: fromB64(hj.vault.wrappedDek),
    createdAt: hj.vault.createdAt,
    updatedAt: hj.vault.updatedAt,
  };
  if (!(header.iterations >= 100_000 && header.iterations <= 10_000_000) || header.salt.length < 16 || header.wrapIv.length !== 12)
    throw new BackupError('پارامترهای کلید پشتیبان نامعتبر است');

  let dek: CryptoKey;
  try {
    dek = await unlockDek(header, password);
  } catch (e) {
    if (e instanceof WrongPasswordError) throw new BackupError('رمز عبور این پشتیبان نادرست است');
    throw e;
  }

  const mr = new Reader(file, manifestOffset);
  const mLen = await mr.u32();
  if (manifestOffset + 4 + mLen !== file.size - 14) throw new BackupError('فهرست پشتیبان نامعتبر است');
  const mBytes = await mr.read(mLen);
  let manifest: Manifest;
  try {
    const pt = await open(dek, { iv: mBytes.slice(0, 12), ct: mBytes.slice(12) }, MANIFEST_AAD);
    manifest = JSON.parse(strFromU8(inflateSync(pt))) as Manifest;
  } catch {
    throw new BackupError('فهرست پشتیبان دستکاری شده یا خراب است');
  }
  if (manifest.format !== 'personal-vault-backup' || !Array.isArray(manifest.frames)) throw new BackupError('فهرست پشتیبان نامعتبر است');
  if (!equalBytes(fromB64(manifest.headerHash), await sha256(headerBytes))) throw new BackupError('سربرگ پشتیبان با فهرست آن مطابقت ندارد');
  const sum = STORES.reduce((a, s) => a + (manifest.counts?.[s] ?? 0), 0);
  if (sum !== manifest.frames.length) throw new BackupError('شمارش رکوردهای پشتیبان ناسازگار است');
  return { info: { header, manifest, headerBytes, framesStart, manifestOffset }, dek };
}

/**
 * Step 2: streams every frame, verifies its SHA-256 against the authenticated manifest,
 * decrypts every projection, checks that every item has all of its payload, and writes
 * into a fresh staging database. Only if everything passes is the staging DB activated.
 */
export async function restoreBackup(file: Blob, info: RestoreInfo, dek: CryptoKey, onProgress?: (f: number, phase: string) => void): Promise<{ items: number }> {
  const stagingName = `pv-staging-${randomId().slice(0, 12)}`;
  const staging = await openVaultDb(stagingName);
  let success = false;
  try {
    await staging.put('meta', info.header, 'vault');
    const r = new Reader(file, info.framesStart);
    const counts: Record<StoreName, number> = { items: 0, chunks: 0, bodies: 0, thumbs: 0 };
    const projections: Item[] = [];
    const chunkSeen = new Map<string, Set<number>>();
    const bodies = new Set<string>();
    const total = info.manifest.frames.length || 1;
    let batch: { store: StoreName; value: { id: string; idx?: number; iv: Uint8Array; ct: Uint8Array } }[] = [];
    let batchBytes = 0;
    const flush = async () => {
      if (!batch.length) return;
      const tx = staging.transaction(['items', 'chunks', 'bodies', 'thumbs'], 'readwrite');
      const ops: Promise<unknown>[] = batch.map((b) => {
        if (b.store === 'chunks') return tx.objectStore('chunks').put({ id: b.value.id, idx: b.value.idx ?? 0, iv: b.value.iv, ct: b.value.ct });
        return tx.objectStore(b.store).put({ id: b.value.id, iv: b.value.iv, ct: b.value.ct });
      });
      await Promise.all([...ops, tx.done]);
      batch = [];
      batchBytes = 0;
    };

    for (let i = 0; i < info.manifest.frames.length; i++) {
      if (r.pos >= info.manifestOffset) throw new BackupError('تعداد رکوردهای پشتیبان کمتر از فهرست است');
      const len = await r.u32();
      if (len > 64 * 1024 * 1024) throw new BackupError('رکورد پشتیبان بیش از حد بزرگ است');
      const frame = await r.read(len);
      if (toB64(await sha256(frame)) !== info.manifest.frames[i]) throw new BackupError('یکپارچگی فایل پشتیبان تأیید نشد (فایل خراب است)');
      const f = decodeFrame(frame);
      counts[f.store]++;
      if (f.store === 'items') {
        try {
          projections.push(await decryptProjection(dek, { id: f.id, iv: f.iv, ct: f.ct }));
        } catch {
          throw new BackupError('یکی از آیتم‌های پشتیبان قابل رمزگشایی نیست');
        }
      } else if (f.store === 'chunks') {
        if (!chunkSeen.has(f.id)) chunkSeen.set(f.id, new Set());
        chunkSeen.get(f.id)!.add(f.idx);
      } else if (f.store === 'bodies') bodies.add(f.id);
      batch.push({ store: f.store, value: { id: f.id, idx: f.idx, iv: f.iv, ct: f.ct } });
      batchBytes += f.ct.length;
      if (batch.length >= 200 || batchBytes > 8 * 1024 * 1024) await flush();
      onProgress?.((i + 1) / total, 'بررسی و بازیابی');
    }
    await flush();
    if (r.pos !== info.manifestOffset) throw new BackupError('داده اضافی ناشناخته در فایل پشتیبان');
    for (const s of STORES) if (counts[s] !== info.manifest.counts[s]) throw new BackupError('شمارش رکوردها با فهرست مطابقت ندارد');
    for (const it of projections) {
      if (it.kind === 'text') {
        if (!bodies.has(it.id)) throw new BackupError(`متن «${it.name}» در پشتیبان ناقص است`);
      } else {
        const seen = chunkSeen.get(it.id);
        for (let c = 0; c < it.chunks; c++) if (!seen?.has(c)) throw new BackupError(`فایل «${it.name}» در پشتیبان ناقص است`);
      }
    }
    staging.close();
    success = true;
    await switchActiveDb(stagingName);
    return { items: projections.length };
  } finally {
    if (!success) {
      staging.close();
      await deleteDb(stagingName);
    }
  }
}

export function backupFileName(appName: string): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  const safe = appName.replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '') || 'PersonalVault';
  return `${safe}-backup-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.pvault`;
}
