import { useEffect, useState } from 'react';
import { readThumb } from './vault';

/**
 * Thumbnail cache: bounded LRU of object URLs + a concurrency-limited, cancellable LIFO
 * decrypt queue. While scrolling fast, tiles that already left the screen are dropped from the
 * queue before they are decrypted, and the newest (visible) tiles are served first.
 */
const MAX = 240;
const CONCURRENCY = 3;
const urls = new Map<string, string>();
const waiters = new Map<string, Set<(u: string | null) => void>>();
const queued: string[] = [];
let active = 0;
let epoch = 0; // bumped on lock: results of in-flight jobs from the previous session are discarded
let keyRef: (() => CryptoKey | null) | null = null;

export function bindKeyProvider(fn: () => CryptoKey | null) {
  keyRef = fn;
}

function touch(id: string, url: string) {
  urls.delete(id);
  urls.set(id, url);
  while (urls.size > MAX) {
    const [k, u] = urls.entries().next().value as [string, string];
    urls.delete(k);
    URL.revokeObjectURL(u);
  }
}

function settle(id: string, u: string | null) {
  const w = waiters.get(id);
  waiters.delete(id);
  w?.forEach((fn) => fn(u));
}

function pump() {
  while (active < CONCURRENCY && queued.length) {
    const id = queued.pop()!; // LIFO: most recently requested (visible) first
    if (!waiters.get(id)?.size) {
      waiters.delete(id);
      continue;
    }
    active++;
    const my = epoch;
    const key = keyRef?.();
    (key ? readThumb(key, id) : Promise.resolve(null))
      .then((blob) => {
        if (my !== epoch || !blob) return settle(id, null);
        const u = URL.createObjectURL(blob);
        touch(id, u);
        settle(id, u);
      })
      .catch(() => settle(id, null))
      .finally(() => {
        active--;
        pump();
      });
  }
}

/** Subscribes to a thumbnail; returns an unsubscribe function (drops the job if nobody waits). */
export function requestThumb(id: string, cb: (u: string | null) => void): () => void {
  const hit = urls.get(id);
  if (hit) {
    touch(id, hit);
    cb(hit);
    return () => undefined;
  }
  let set = waiters.get(id);
  if (!set) {
    set = new Set();
    waiters.set(id, set);
    queued.push(id);
  }
  set.add(cb);
  pump();
  return () => {
    const s = waiters.get(id);
    s?.delete(cb);
  };
}

export function getThumbUrl(id: string): Promise<string | null> {
  return new Promise((resolve) => requestThumb(id, resolve));
}

export function forgetThumb(id: string) {
  const u = urls.get(id);
  if (u) URL.revokeObjectURL(u);
  urls.delete(id);
}

export function clearMediaCache() {
  epoch++;
  for (const u of urls.values()) URL.revokeObjectURL(u);
  urls.clear();
  queued.length = 0;
  for (const id of [...waiters.keys()]) settle(id, null);
}

export function useThumb(id: string, enabled = true): string | null {
  const [url, setUrl] = useState<string | null>(() => (enabled ? urls.get(id) ?? null : null));
  useEffect(() => {
    if (!enabled) {
      setUrl(null);
      return;
    }
    const cached = urls.get(id);
    if (cached) {
      setUrl(cached);
      return;
    }
    let alive = true;
    const off = requestThumb(id, (u) => alive && setUrl(u));
    return () => {
      alive = false;
      off();
    };
  }, [id, enabled]);
  return url;
}
