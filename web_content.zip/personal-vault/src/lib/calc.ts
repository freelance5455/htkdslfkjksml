/** Real calculator engine: + − × ÷ with correct precedence, percent, sign toggle, decimals. */
export type Op = '+' | '−' | '×' | '÷';
export const OPS: Op[] = ['+', '−', '×', '÷'];

export interface CalcState {
  expr: string; // e.g. "12+3×4"
  result: string | null; // shown after "="
  error: boolean;
}

export const initialCalc: CalcState = { expr: '', result: null, error: false };

const isOp = (c: string): c is Op => (OPS as string[]).includes(c);

function tokenize(expr: string): (number | Op)[] {
  const out: (number | Op)[] = [];
  let num = '';
  for (let i = 0; i < expr.length; i++) {
    const c = expr[i];
    const unaryMinus = c === '−' && (i === 0 || isOp(expr[i - 1])) && num === '';
    if (!isOp(c) || unaryMinus) {
      num += c === '−' ? '-' : c;
      continue;
    }
    if (num === '' || num === '-') throw new Error('SYNTAX');
    out.push(parseNum(num));
    num = '';
    out.push(c);
  }
  if (num === '' || num === '-') throw new Error('SYNTAX');
  out.push(parseNum(num));
  return out;
}

function parseNum(s: string): number {
  const pct = s.endsWith('%');
  const v = Number(pct ? s.slice(0, -1) : s);
  if (!Number.isFinite(v)) throw new Error('SYNTAX');
  return pct ? v / 100 : v;
}

export function evaluate(expr: string): number {
  const t = tokenize(expr);
  // pass 1: × ÷
  const stack: (number | Op)[] = [t[0]];
  for (let i = 1; i < t.length; i += 2) {
    const op = t[i] as Op;
    const n = t[i + 1] as number;
    if (op === '×' || op === '÷') {
      const prev = stack.pop() as number;
      if (op === '÷' && n === 0) throw new Error('DIV0');
      stack.push(op === '×' ? prev * n : prev / n);
    } else stack.push(op, n);
  }
  // pass 2: + −
  let acc = stack[0] as number;
  for (let i = 1; i < stack.length; i += 2) {
    const op = stack[i] as Op;
    const n = stack[i + 1] as number;
    acc = op === '+' ? acc + n : acc - n;
  }
  return acc;
}

export function formatNumber(v: number): string {
  if (!Number.isFinite(v)) throw new Error('OVERFLOW');
  const r = Number.parseFloat(v.toPrecision(12));
  if (Math.abs(r) >= 1e15 || (Math.abs(r) < 1e-9 && r !== 0)) return r.toExponential(6).replace('e+', 'e');
  return String(r);
}

function lastNumber(expr: string): string {
  const m = expr.match(/(^−)?[0-9.%]*$/);
  return m ? m[0] : '';
}

export function press(s: CalcState, key: string): CalcState {
  if (key === 'C') return initialCalc;
  let expr = s.error ? '' : s.result !== null ? (/[0-9.]/.test(key) ? '' : s.result.replace('-', '−')) : s.expr;
  if (key === '⌫') return { expr: s.result !== null ? '' : expr.slice(0, -1), result: null, error: false };
  if (key === '=') {
    if (!expr) return s;
    try {
      const trimmed = isOp(expr.slice(-1)) ? expr.slice(0, -1) : expr;
      return { expr: trimmed, result: formatNumber(evaluate(trimmed)), error: false };
    } catch {
      return { expr, result: null, error: true };
    }
  }
  if (isOp(key)) {
    if (!expr) return key === '−' ? { expr: '−', result: null, error: false } : s;
    if (isOp(expr.slice(-1))) expr = expr.slice(0, -1);
    if (!expr) return initialCalc;
    return { expr: expr + key, result: null, error: false };
  }
  if (key === '.') {
    const n = lastNumber(expr);
    if (n.includes('.') || n.includes('%')) return { ...s, expr, result: null };
    return { expr: expr + (n === '' || n === '−' ? '0.' : '.'), result: null, error: false };
  }
  if (key === '%') {
    const n = lastNumber(expr);
    if (!n || n.includes('%') || n === '−') return { ...s, expr, result: null };
    return { expr: expr + '%', result: null, error: false };
  }
  if (key === '±') {
    const n = lastNumber(expr);
    if (!n) return { expr: expr + '−', result: null, error: false };
    const head = expr.slice(0, expr.length - n.length);
    const toggled = n.startsWith('−') ? n.slice(1) : '−' + n;
    return { expr: head + toggled, result: null, error: false };
  }
  if (/^[0-9]$/.test(key)) {
    const n = lastNumber(expr);
    if (n.endsWith('%')) return { ...s, expr, result: null };
    if (n === '0' || n === '−0') expr = expr.slice(0, -1);
    if (expr.length > 40) return s;
    return { expr: expr + key, result: null, error: false };
  }
  return s;
}

/** Live preview result while typing (null when incomplete). */
export function preview(expr: string): string | null {
  if (!expr || !OPS.some((o) => expr.slice(1).includes(o))) return null;
  try {
    const t = isOp(expr.slice(-1)) ? expr.slice(0, -1) : expr;
    return formatNumber(evaluate(t));
  } catch {
    return null;
  }
}

const FA = '۰۱۲۳۴۵۶۷۸۹';
export function toFaDigits(s: string): string {
  return s.replace(/[0-9]/g, (d) => FA[Number(d)]).replace(/\./g, '٫');
}

export function groupDigits(s: string): string {
  return s.replace(/(^|[^0-9.])(\d{4,})/g, (_m, p: string, n: string) => p + n.replace(/\B(?=(\d{3})+(?!\d))/g, ','));
}
