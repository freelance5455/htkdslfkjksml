import { Capacitor, registerPlugin } from '@capacitor/core';
import { toB64 } from './crypto';

/** Custom Android plugin (android-native/.../VaultNativePlugin.java). */
interface VaultNativePlugin {
  beginSave(o: { name: string; mime: string }): Promise<{ id: string }>;
  appendChunk(o: { id: string; data: string }): Promise<void>;
  finishSave(o: { id: string }): Promise<{ path: string }>;
  abortSave(o: { id: string }): Promise<void>;
  setLauncherAlias(o: { alias: 'default' | 'calculator' }): Promise<void>;
  getLauncherAlias(): Promise<{ alias: 'default' | 'calculator' }>;
  pinShortcut(o: { label: string; icon: string }): Promise<{ requested: boolean }>;
  setSecure(o: { enabled: boolean }): Promise<void>;
  setSystemBars(o: { color: string; light: boolean }): Promise<void>;
  // private, app-only temporary plaintext files for preview / playback / "open with"
  tempBegin(o: { ext: string; shared: boolean; name?: string }): Promise<{ id: string }>;
  tempAppend(o: { id: string; offset: number; data: string }): Promise<void>;
  tempFinish(o: { id: string; mime: string }): Promise<{ url: string }>;
  tempRelease(o: { id: string }): Promise<void>;
  tempClear(o: { keepSharedMs: number }): Promise<void>;
  openExternal(o: { id: string; mime: string; title: string }): Promise<{ opened: boolean }>;
  pdfOpen(o: { id: string }): Promise<{ handle: string; count: number; pages: { w: number; h: number }[] }>;
  pdfRender(o: { handle: string; index: number; width: number }): Promise<{ data: string; w: number; h: number }>;
  pdfClose(o: { handle: string }): Promise<void>;
  // on-demand streaming (partial decryption, no plaintext on disk)
  streamOpen(o: { token: string; size: number; mime: string; chunkSize: number; chunks: number }): Promise<{ url: string }>;
  streamSupply(o: { req: string; data: string }): Promise<void>;
  streamFail(o: { req: string }): Promise<void>;
  streamClose(o: { token: string }): Promise<void>;
  streamCloseAll(): Promise<void>;
  pdfOpenStream(o: { token: string }): Promise<{ handle: string; count: number; w: number; h: number }>;
  pdfPageSize(o: { handle: string; index: number }): Promise<{ w: number; h: number }>;
  // viewer helpers
  setOrientation(o: { mode: 'landscape' | 'portrait' | 'auto' }): Promise<void>;
  setImmersive(o: { enabled: boolean }): Promise<void>;
  setKeepAwake(o: { enabled: boolean }): Promise<void>;
  getBrightness(): Promise<{ value: number }>;
  setBrightness(o: { value: number }): Promise<void>;
  // uninstall protection (Device Admin)
  adminStatus(): Promise<{ active: boolean; supported: boolean }>;
  adminEnable(o: { explanation: string }): Promise<{ active: boolean }>;
  adminDisable(): Promise<{ active: boolean }>;
  addListener(ev: 'streamRequest', fn: (d: { token: string; idx: number; req: string }) => void): Promise<{ remove: () => Promise<void> }>;
}

const VaultNative = registerPlugin<VaultNativePlugin>('VaultNative');
export const isNative = Capacitor.isNativePlatform();
const BRIDGE_SLICE = 512 * 1024;

/**
 * Saves a stream of chunks to the public Downloads/PersonalVault folder.
 * On Android the data is streamed chunk-by-chunk to native code (MediaStore), so a
 * multi-GB file never needs to fit in memory. On the web a Blob download is used.
 */
export async function saveStream(name: string, mime: string, chunks: AsyncIterable<Uint8Array>): Promise<string> {
  if (isNative) {
    const { id } = await VaultNative.beginSave({ name, mime });
    try {
      for await (const c of chunks) {
        for (let o = 0; o < c.length; o += BRIDGE_SLICE) {
          await VaultNative.appendChunk({ id, data: toB64(c.subarray(o, o + BRIDGE_SLICE)) });
        }
      }
      const r = await VaultNative.finishSave({ id });
      return r.path;
    } catch (e) {
      await VaultNative.abortSave({ id }).catch(() => undefined);
      throw e;
    }
  }
  const parts: BlobPart[] = [];
  for await (const c of chunks) parts.push(c);
  const url = URL.createObjectURL(new Blob(parts, { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
  return `Downloads/${name}`;
}

// ---------------------------------------------------------------- temporary plaintext copies

export interface TempFile {
  /** URL usable by <video>/<audio>/<img>/<iframe>. On Android it is an in-app, range-capable, token URL. */
  url: string;
  id: string;
  native: boolean;
  release: () => Promise<void>;
}

/**
 * Writes decrypted chunks to a private temporary file for preview/playback:
 *  - Android: app cache dir (never public storage, excluded from backups), served to the WebView
 *    only through a random, revocable token URL with HTTP Range support (seek without loading
 *    the file in RAM). Deleted on release, on lock and on every app start.
 *  - Web: an in-memory Blob URL (revoked on release).
 */
export async function writeTemp(o: { ext: string; mime: string; shared?: boolean; name?: string; chunks: AsyncIterable<Uint8Array>; onProgress?: (bytes: number) => void; signal?: { cancelled: boolean } }): Promise<TempFile> {
  if (isNative) {
    const { id } = await VaultNative.tempBegin({ ext: o.ext, shared: !!o.shared, name: o.name });
    try {
      let offset = 0;
      const queue: Promise<void>[] = [];
      for await (const c of o.chunks) {
        if (o.signal?.cancelled) throw new Error('CANCELLED');
        for (let s = 0; s < c.length; s += BRIDGE_SLICE) {
          const part = c.subarray(s, s + BRIDGE_SLICE);
          queue.push(VaultNative.tempAppend({ id, offset, data: toB64(part) }));
          offset += part.length;
          if (queue.length >= 3) await queue.shift();
        }
        o.onProgress?.(offset);
      }
      await Promise.all(queue);
      const { url } = await VaultNative.tempFinish({ id, mime: o.mime });
      let released = false;
      return {
        url,
        id,
        native: true,
        release: async () => {
          if (released) return;
          released = true;
          await VaultNative.tempRelease({ id }).catch(() => undefined);
        },
      };
    } catch (e) {
      await VaultNative.tempRelease({ id }).catch(() => undefined);
      throw e;
    }
  }
  const parts: BlobPart[] = [];
  let bytes = 0;
  for await (const c of o.chunks) {
    if (o.signal?.cancelled) throw new Error('CANCELLED');
    parts.push(c);
    bytes += c.length;
    o.onProgress?.(bytes);
  }
  const url = URL.createObjectURL(new Blob(parts, { type: o.mime }));
  let released = false;
  return {
    url,
    id: url,
    native: false,
    release: async () => {
      if (released) return;
      released = true;
      URL.revokeObjectURL(url);
    },
  };
}

/** Deletes every temporary preview file (lock / boot). Shared copies younger than `keepSharedMs` survive briefly. */
export function clearTempFiles(keepSharedMs = 0) {
  if (isNative) VaultNative.tempClear({ keepSharedMs }).catch(() => undefined);
}

/** Hands a shared temp file to another app (Android chooser, read-only content:// grant). */
export async function openExternal(id: string, mime: string, title: string): Promise<boolean> {
  if (!isNative) return false;
  return (await VaultNative.openExternal({ id, mime, title })).opened;
}

export const nativeStream = {
  open: (o: { token: string; size: number; mime: string; chunkSize: number; chunks: number }) => VaultNative.streamOpen(o),
  supply: (req: string, data: string) => VaultNative.streamSupply({ req, data }).catch(() => undefined),
  fail: (req: string) => VaultNative.streamFail({ req }).catch(() => undefined),
  close: (token: string) => VaultNative.streamClose({ token }).catch(() => undefined),
  closeAll: () => VaultNative.streamCloseAll().catch(() => undefined),
  onRequest: (fn: (d: { token: string; idx: number; req: string }) => void) => VaultNative.addListener('streamRequest', fn),
};

/** Viewer helpers. All are no-ops on the web. */
export const viewerNative = {
  orientation: (mode: 'landscape' | 'portrait' | 'auto') => (isNative ? VaultNative.setOrientation({ mode }).catch(() => undefined) : webOrientation(mode)),
  immersive: (enabled: boolean) => (isNative ? VaultNative.setImmersive({ enabled }).catch(() => undefined) : Promise.resolve()),
  keepAwake: (enabled: boolean) => (isNative ? VaultNative.setKeepAwake({ enabled }).catch(() => undefined) : Promise.resolve()),
  getBrightness: async (): Promise<number | null> => (isNative ? (await VaultNative.getBrightness().catch(() => ({ value: -1 }))).value : null),
  setBrightness: (value: number) => (isNative ? VaultNative.setBrightness({ value }).catch(() => undefined) : Promise.resolve()),
};

async function webOrientation(mode: 'landscape' | 'portrait' | 'auto') {
  const o = screen.orientation as ScreenOrientation & { lock?: (m: string) => Promise<void>; unlock?: () => void };
  try {
    if (mode === 'auto') o.unlock?.();
    else await o.lock?.(mode);
  } catch {
    /* browsers only allow this in fullscreen: ignore */
  }
}

export const uninstallGuard = {
  status: async () => (isNative ? VaultNative.adminStatus() : { active: false, supported: false }),
  enable: (explanation: string) => VaultNative.adminEnable({ explanation }),
  disable: () => VaultNative.adminDisable(),
};

export const pdf = {
  openStream: (token: string) => VaultNative.pdfOpenStream({ token }),
  pageSize: (handle: string, index: number) => VaultNative.pdfPageSize({ handle, index }),
  open: (id: string) => VaultNative.pdfOpen({ id }),
  render: (handle: string, index: number, width: number) => VaultNative.pdfRender({ handle, index, width }),
  close: (handle: string) => VaultNative.pdfClose({ handle }).catch(() => undefined),
};

// ---------------------------------------------------------------- misc

export async function setLauncherAlias(alias: 'default' | 'calculator'): Promise<boolean> {
  if (!isNative) return false;
  await VaultNative.setLauncherAlias({ alias });
  return true;
}

export async function getLauncherAlias(): Promise<'default' | 'calculator'> {
  if (!isNative) return 'default';
  try {
    return (await VaultNative.getLauncherAlias()).alias;
  } catch {
    return 'default';
  }
}

export async function pinShortcut(label: string, iconDataUrl: string): Promise<boolean> {
  if (!isNative) return false;
  const r = await VaultNative.pinShortcut({ label, icon: iconDataUrl.replace(/^data:[^,]+,/, '') });
  return r.requested;
}

export function setSecureScreen(enabled: boolean) {
  if (isNative) VaultNative.setSecure({ enabled }).catch(() => undefined);
}

export function setSystemBars(color: string, light: boolean) {
  if (isNative) VaultNative.setSystemBars({ color, light }).catch(() => undefined);
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

export function haptic(ms = 8) {
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* ignore */
  }
}
