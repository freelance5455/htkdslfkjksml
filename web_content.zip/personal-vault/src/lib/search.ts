import type { Item, SortKey } from './types';

const MAP: Record<string, string> = {
  'ي': 'ی', 'ى': 'ی', 'ئ': 'ی', 'ك': 'ک', 'ة': 'ه', 'ۀ': 'ه', 'ە': 'ه',
  'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ؤ': 'و',
};
const DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

/** Normalizes Persian/Arabic variants, digits, diacritics and zero-width chars for matching. */
export function normalizeFa(input: string): string {
  let out = '';
  for (const ch of input.toLowerCase()) {
    if (MAP[ch]) out += MAP[ch];
    else if (DIGITS.includes(ch)) out += String(DIGITS.indexOf(ch));
    else if (AR_DIGITS.includes(ch)) out += String(AR_DIGITS.indexOf(ch));
    else if (/[\u064B-\u065F\u0670\u0640]/.test(ch)) continue;
    else if (/[\u200C\u200D\u200E\u200F_\-.]/.test(ch)) out += ' ';
    else out += ch;
  }
  return out.replace(/\s+/g, ' ').trim();
}

const cache = new Map<string, { u: number; s: string }>();

function haystack(it: Item): string {
  const c = cache.get(it.id);
  const u = it.updatedAt + it.name.length;
  if (c && c.u === u) return c.s;
  const s = normalizeFa(`${it.name} ${it.ext} ${it.snippet ?? ''}`);
  cache.set(it.id, { u, s });
  return s;
}

export function clearSearchCache() {
  cache.clear();
}

/** Builds a matcher once per query (the query is normalized once, not once per item). */
export function makeMatcher(query: string): (it: Item) => boolean {
  const q = normalizeFa(query);
  if (!q) return () => true;
  const terms = q.split(' ');
  return (it) => {
    const h = haystack(it);
    if (terms.every((t) => h.includes(t))) return true;
    const hNoSpace = h.replace(/ /g, '');
    return terms.every((t) => h.includes(t) || hNoSpace.includes(t));
  };
}

export function matches(it: Item, query: string): boolean {
  return makeMatcher(query)(it);
}

const collator = new Intl.Collator('fa', { numeric: true, sensitivity: 'base' });

export function sortItems(list: Item[], key: SortKey, byDeleted = false): Item[] {
  const arr = list.slice();
  const t = (i: Item) => (byDeleted ? i.deletedAt ?? 0 : i.createdAt);
  switch (key) {
    case 'new':
      return arr.sort((a, b) => t(b) - t(a));
    case 'old':
      return arr.sort((a, b) => t(a) - t(b));
    case 'name':
      return arr.sort((a, b) => collator.compare(a.name, b.name));
    case 'size':
      return arr.sort((a, b) => b.size - a.size);
  }
}

export const SORT_LABELS: Record<SortKey, string> = {
  new: 'جدیدترین',
  old: 'قدیمی‌ترین',
  name: 'نام (الفبا)',
  size: 'حجم (بزرگ‌ترین)',
};
