export type Kind = 'file' | 'image' | 'text';

/** Decrypted projection: the small, searchable part of an item that lives in memory while unlocked. */
export interface Item {
  id: string;
  kind: Kind;
  name: string;
  ext: string;
  /** MIME type. For items imported by v2.1+ this is the *sniffed* (magic-byte) type when detectable. */
  mime: string;
  size: number;
  createdAt: number;
  updatedAt: number;
  deletedAt: number | null;
  chunks: number;
  /** Plaintext bytes per chunk (older items: 512 KiB). */
  chunkSize?: number;
  /** MIME reported by the system picker at import time (kept for reference only). */
  declaredMime?: string;
  /** true once the real content type has been detected from the file's bytes. */
  sniffed?: boolean;
  snippet?: string;
  width?: number;
  height?: number;
  thumb?: boolean;
  /** Texts only: the name was derived from the first line (no explicit title was given). */
  autoName?: boolean;
}

export type SortKey = 'new' | 'old' | 'name' | 'size';
export type ListMode = Kind | 'all' | 'trash';
