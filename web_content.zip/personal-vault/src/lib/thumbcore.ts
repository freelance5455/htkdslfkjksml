import { imageSize } from './sniff';

/**
 * Thumbnail rendering shared by the import worker, the preview worker and the main-thread
 * fallback. Decodes at reduced size when the header dimensions are known (much less RAM for
 * 50+ MP photos) and releases the bitmap immediately.
 */
export interface ThumbResult {
  bytes: Uint8Array;
  width: number;
  height: number;
}

export async function renderThumb(blob: Blob, shortSide: number, head?: Uint8Array, type = 'image/webp', quality = 0.8): Promise<ThumbResult> {
  const dims = head ? imageSize(head) : null;
  let bmp: ImageBitmap;
  if (dims && dims.width > 0 && dims.height > 0) {
    const scale = Math.min(1, shortSide / Math.min(dims.width, dims.height));
    const rw = Math.max(1, Math.round(dims.width * scale));
    try {
      bmp = scale < 1 ? await createImageBitmap(blob, { resizeWidth: rw, resizeQuality: 'medium' }) : await createImageBitmap(blob);
    } catch {
      bmp = await createImageBitmap(blob);
    }
  } else {
    bmp = await createImageBitmap(blob);
  }
  try {
    const width = dims?.width || bmp.width;
    const height = dims?.height || bmp.height;
    const s = Math.min(1, shortSide / Math.min(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * s));
    const h = Math.max(1, Math.round(bmp.height * s));
    const out = await encode(bmp, w, h, type, quality);
    return { bytes: new Uint8Array(await out.arrayBuffer()), width, height };
  } finally {
    bmp.close();
  }
}

/** Downscales an image so that its longest side is at most `maxSide` (for huge photos in the viewer). */
export async function downscale(blob: Blob, maxSide: number, head?: Uint8Array): Promise<Blob> {
  const dims = head ? imageSize(head) : null;
  let bmp: ImageBitmap;
  if (dims && Math.max(dims.width, dims.height) > maxSide) {
    const scale = maxSide / Math.max(dims.width, dims.height);
    bmp = await createImageBitmap(blob, { resizeWidth: Math.max(1, Math.round(dims.width * scale)), resizeQuality: 'high' }).catch(() => createImageBitmap(blob));
  } else bmp = await createImageBitmap(blob);
  try {
    const s = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    return await encode(bmp, Math.round(bmp.width * s), Math.round(bmp.height * s), 'image/jpeg', 0.92);
  } finally {
    bmp.close();
  }
}

async function encode(bmp: ImageBitmap, w: number, h: number, type: string, quality: number): Promise<Blob> {
  if (typeof OffscreenCanvas !== 'undefined') {
    const c = new OffscreenCanvas(w, h);
    const ctx = c.getContext('2d');
    if (!ctx) throw new Error('NO_CANVAS');
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(bmp, 0, 0, w, h);
    const b = await c.convertToBlob({ type, quality });
    c.width = c.height = 0;
    return b;
  }
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('NO_CANVAS');
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(bmp, 0, 0, w, h);
  const blob = await new Promise<Blob | null>((r) => canvas.toBlob(r, type, quality));
  canvas.width = canvas.height = 0;
  if (!blob) throw new Error('ENCODE_FAILED');
  return blob;
}
