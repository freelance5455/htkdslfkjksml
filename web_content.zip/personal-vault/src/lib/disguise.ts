import { isCalcTypeable, unlockDek, withCalcWrap } from './crypto';
import { readHeader, writeHeader } from './db';
import { usePrefs } from '../store/prefs';
import { passwordDialog, promptDialog, toast, useUi } from '../store/ui';

const toLatinDigits = (s: string) => s.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).trim();

/**
 * Turns the calculator disguise on/off.
 * On: the vault password is verified. If it can be typed on a calculator (4–15 digits) it is
 * the entry code; otherwise the user defines a digits-only calculator code, stored as a second
 * wrap of the data key (the vault data itself is untouched). Entry is then: code → "=".
 * Off: the extra wrap (if any) is removed.
 */
export async function setDisguise(on: boolean): Promise<boolean> {
  const prefs = usePrefs.getState();
  if (!on) {
    prefs.set({ disguise: false });
    const h = await readHeader();
    if (h?.calc) {
      const { calc: _c, ...rest } = h;
      void _c;
      await writeHeader({ ...rest, updatedAt: Date.now() });
    }
    toast('استتار ماشین‌حساب غیرفعال شد');
    return false;
  }
  const pw = await passwordDialog({ title: 'فعال‌سازی استتار ماشین‌حساب', message: 'برای تأیید، رمز گاوصندوق را وارد کنید. پس از فعال‌سازی، برنامه به شکل یک ماشین‌حساب معمولی باز می‌شود و ورود فقط با وارد کردن رمز در ماشین‌حساب و زدن = انجام می‌شود.', confirmText: 'ادامه' });
  if (!pw) return false;
  const ui = useUi.getState();
  const h = await readHeader();
  if (!h) return false;
  ui.setProgress({ title: 'بررسی رمز عبور', value: -1 });
  const ok = await unlockDek(h, pw).then(() => true, () => false);
  ui.setProgress(null);
  if (!ok) {
    toast('رمز عبور نادرست است', 'err');
    return false;
  }
  if (isCalcTypeable(pw)) {
    if (h.calc) {
      const { calc: _c, ...rest } = h;
      void _c;
      await writeHeader({ ...rest, updatedAt: Date.now() });
    }
    prefs.set({ disguise: true, disguiseReady: true });
    toast('استتار فعال شد؛ برای ورود، رمز را در ماشین‌حساب بزنید و سپس =');
    return true;
  }
  const code = await promptDialog({ title: 'کد ورود از ماشین‌حساب', message: 'رمز شما شامل حروف یا نمادهایی است که در ماشین‌حساب تایپ نمی‌شوند. یک کد فقط‌عددی (۴ تا ۱۵ رقم) تعیین کنید؛ ورود با زدن همین کد و سپس = انجام می‌شود. کد را مثل رمز عبور محرمانه نگه دارید و از کدهای ساده مثل ۱۲۳۴ استفاده نکنید.', placeholder: 'کد عددی', maxLength: 15, numeric: true, secret: true, confirmText: 'ادامه' });
  if (code === null) return false;
  const c1 = toLatinDigits(code);
  if (!isCalcTypeable(c1)) {
    toast('کد باید فقط شامل ۴ تا ۱۵ رقم باشد', 'err');
    return false;
  }
  const again = await promptDialog({ title: 'تکرار کد ماشین‌حساب', placeholder: 'کد عددی', maxLength: 15, numeric: true, secret: true, confirmText: 'فعال‌سازی' });
  if (again === null) return false;
  if (toLatinDigits(again) !== c1) {
    toast('تکرار کد مطابقت ندارد', 'err');
    return false;
  }
  ui.setProgress({ title: 'ساخت کلید ورود ماشین‌حساب', value: -1 });
  try {
    await writeHeader(await withCalcWrap(h, pw, c1));
  } catch {
    ui.setProgress(null);
    toast('فعال‌سازی ممکن نشد', 'err');
    return false;
  }
  ui.setProgress(null);
  prefs.set({ disguise: true, disguiseReady: true });
  toast('استتار فعال شد؛ برای ورود، کد را در ماشین‌حساب بزنید و سپس =');
  return true;
}

/** After a password change / restore: keep the disguise only if the entry still works. */
export function checkDisguiseAfterKeyChange(newPassword: string, hasCalcWrap: boolean) {
  const p = usePrefs.getState();
  if (p.disguise && !hasCalcWrap && !isCalcTypeable(newPassword)) {
    p.set({ disguise: false });
    toast('استتار ماشین‌حساب غیرفعال شد؛ رمز جدید در ماشین‌حساب قابل تایپ نیست. می‌توانید دوباره فعالش کنید.', 'info');
  }
}
