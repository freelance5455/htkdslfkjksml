import { deflateSync, inflateSync, strFromU8, strToU8 } from 'fflate';
import { open, randomId, seal } from './crypto';
import { getDb, type SealedRow } from './db';
import type { Item, Kind } from './types';
import { makeThumbnail } from './thumbs';
import { resolveMime } from './sniff';
import { aad } from './aad';

/** Chunk size used by v1 imports (items without `chunkSize`). */
export const LEGACY_CHUNK_SIZE = 512 * 1024;
/** Chunk size for new imports (2 MiB): fewer IndexedDB records / blob files / bridge calls, still small in RAM. */
export const CHUNK_SIZE = 2 * 1024 * 1024;
const SNIPPET_LEN = 280;

export const chunkSizeOf = (it: Item) => it.chunkSize ?? LEGACY_CHUNK_SIZE;

/** Ids whose payload is being written right now: garbage collection must never touch them. */
const inflight = new Set<string>();
export const markInflight = (id: string) => inflight.add(id);
export const clearInflight = (id: string) => inflight.delete(id);

export { aad };

const packJson = (o: unknown) => deflateSync(strToU8(JSON.stringify(o)), { level: 6 });
const unpackJson = <T>(b: Uint8Array): T => JSON.parse(strFromU8(inflateSync(b))) as T;

/** Longest name kept (in characters, not UTF-16 units). Matches common filesystem limits. */
export const NAME_MAX = 255;

/** Normalises a user-given name without cutting meaningful text: only surrounding whitespace
 *  and control characters go; the length cap counts real characters (Persian, emoji, digits). */
export function cleanName(name: string): string {
  const s = name.replace(/[\x00-\x1f\x7f]+/g, ' ').trim();
  const cps = [...s];
  return cps.length > NAME_MAX ? cps.slice(0, NAME_MAX).join('').trim() : s;
}

/**
 * Splits "report.final.pdf" → { base: "report.final", ext: "pdf" }.
 * An extension is 1–8 ASCII letters/digits with at least one letter, so names such as
 * "جلسه 1404.05.12" or "v2.10" are kept whole instead of losing their last part.
 */
export function splitName(fileName: string): { base: string; ext: string } {
  const i = fileName.lastIndexOf('.');
  if (i <= 0 || i === fileName.length - 1) return { base: fileName, ext: '' };
  const ext = fileName.slice(i + 1);
  if (!/^[a-z0-9]{1,8}$/i.test(ext) || !/[a-z]/i.test(ext)) return { base: fileName, ext: '' };
  return { base: fileName.slice(0, i), ext: ext.toLowerCase() };
}

export function downloadName(item: Item): string {
  const clean = item.name.replace(/[\\/:*?"<>|]+/g, '_').trim() || 'item';
  if (item.kind === 'text') return clean.endsWith('.txt') ? clean : `${clean}.txt`;
  if (!item.ext || clean.toLowerCase().endsWith(`.${item.ext}`)) return clean;
  return `${clean}.${item.ext}`;
}

// ---------------------------------------------------------------- projections

export async function saveProjection(dek: CryptoKey, item: Item): Promise<void> {
  const s = await seal(dek, packJson(item), aad.proj(item.id));
  const db = await getDb();
  await db.put('items', { id: item.id, ...s });
}

export async function saveProjections(dek: CryptoKey, items: Item[]): Promise<void> {
  const rows = await Promise.all(items.map(async (it) => ({ id: it.id, ...(await seal(dek, packJson(it), aad.proj(it.id))) })));
  const db = await getDb();
  // durable commit: this is the point where imported chunks (written with relaxed durability) become visible
  const tx = db.transaction('items', 'readwrite', { durability: 'strict' });
  await Promise.all([...rows.map((r) => tx.store.put(r)), tx.done]);
}

export async function decryptProjection(dek: CryptoKey, row: { id: string; iv: Uint8Array; ct: Uint8Array }): Promise<Item> {
  const item = unpackJson<Item>(await open(dek, row, aad.proj(row.id)));
  if (item.id !== row.id) throw new Error('PROJECTION_ID_MISMATCH');
  return item;
}

/** Loads and decrypts every projection in batches. Corrupt rows are reported, never silently dropped from disk. */
export async function loadProjections(dek: CryptoKey): Promise<{ items: Item[]; corrupt: number }> {
  const db = await getDb();
  const rows = await db.getAll('items');
  const items: Item[] = [];
  let corrupt = 0;
  const BATCH = 128;
  for (let i = 0; i < rows.length; i += BATCH) {
    const res = await Promise.allSettled(rows.slice(i, i + BATCH).map((r: SealedRow) => decryptProjection(dek, r)));
    for (const r of res) {
      if (r.status === 'fulfilled') items.push(r.value);
      else corrupt++;
    }
    // let the UI breathe between batches on very large vaults
    if (i % (BATCH * 8) === 0) await new Promise((r) => setTimeout(r, 0));
  }
  return { items, corrupt };
}

// ---------------------------------------------------------------- blobs (files & images)

export interface ImportOptions {
  kind: Exclude<Kind, 'text'>;
  name?: string;
  onProgress?: (fraction: number) => void;
  signal?: { cancelled: boolean };
}

/**
 * Main-thread import (fallback when Web Workers are unavailable). The worker path in
 * lib/importer.ts is used normally. Only one chunk is held in memory at a time, and chunks
 * are written in small batched transactions.
 */
export async function importBlob(dek: CryptoKey, file: File, opts: ImportOptions): Promise<Item> {
  const id = randomId();
  markInflight(id);
  const { base, ext } = splitName(file.name || 'file');
  const chosen = opts.name?.trim();
  const now = Date.now();
  const total = Math.max(1, Math.ceil(file.size / CHUNK_SIZE));
  const db = await getDb();
  let head: Uint8Array = new Uint8Array(0);
  try {
    let batch: { id: string; idx: number; iv: Uint8Array; ct: Uint8Array }[] = [];
    let batchBytes = 0;
    const flush = async () => {
      if (!batch.length) return;
      const tx = db.transaction('chunks', 'readwrite');
      await Promise.all([...batch.map((r) => tx.store.put(r)), tx.done]);
      batch = [];
      batchBytes = 0;
    };
    for (let i = 0; i < total; i++) {
      if (opts.signal?.cancelled) throw new Error('CANCELLED');
      const buf = new Uint8Array(await file.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE).arrayBuffer());
      if (i === 0) head = buf.slice(0, 8192);
      const s = await seal(dek, buf, aad.chunk(id, i));
      batch.push({ id, idx: i, ...s });
      batchBytes += buf.length;
      if (batchBytes >= 4 * CHUNK_SIZE) await flush();
      opts.onProgress?.(((i + 1) / total) * (opts.kind === 'image' ? 0.9 : 1));
    }
    await flush();
    const declared = file.type || '';
    const item: Item = {
      id,
      kind: opts.kind,
      name: chosen || base || file.name,
      ext,
      mime: resolveMime(head, ext, declared),
      declaredMime: declared || undefined,
      sniffed: true,
      size: file.size,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
      chunks: total,
      chunkSize: CHUNK_SIZE,
    };
    if (opts.kind === 'image') {
      const t = await makeThumbnail(file).catch(() => null);
      if (t) {
        const s = await seal(dek, t.bytes, aad.thumb(id));
        await db.put('thumbs', { id, ...s });
        item.thumb = true;
        item.width = t.width;
        item.height = t.height;
      }
      opts.onProgress?.(1);
    }
    // The projection is written last: an interrupted import leaves only orphan chunks, cleaned on next unlock.
    await saveProjection(dek, item);
    return item;
  } catch (e) {
    await deletePayload([id]).catch(() => undefined);
    throw e;
  } finally {
    clearInflight(id);
  }
}

export async function readChunk(dek: CryptoKey, item: Item, i: number): Promise<Uint8Array> {
  const db = await getDb();
  const row = await db.get('chunks', [item.id, i]);
  if (!row) throw new Error('CHUNK_MISSING');
  return open(dek, row, aad.chunk(item.id, i));
}

/**
 * Streams decrypted chunks in order. The next chunk is fetched and decrypted while the
 * consumer is still busy with the current one (read-ahead of 1), so RAM stays flat
 * (~2 chunks) even for multi-GB files, and IO/crypto overlap with the consumer.
 */
export async function* iterateChunks(dek: CryptoKey, item: Item, from = 0, to = item.chunks): AsyncGenerator<Uint8Array> {
  let next: Promise<Uint8Array> | null = from < to ? readChunk(dek, item, from) : null;
  for (let i = from; i < to; i++) {
    const cur = next!;
    next = i + 1 < to ? readChunk(dek, item, i + 1) : null;
    // avoid an unhandled rejection on the read-ahead if the consumer stops early
    next?.catch(() => undefined);
    yield await cur;
  }
}

/** Decrypts only the chunks needed for bytes [start, end) of a stored file. */
export async function readRange(dek: CryptoKey, item: Item, start: number, end: number): Promise<Uint8Array> {
  const cs = chunkSizeOf(item);
  const s = Math.max(0, Math.min(start, item.size));
  const e = Math.max(s, Math.min(end, item.size));
  const out = new Uint8Array(e - s);
  if (e === s) return out;
  const first = Math.floor(s / cs);
  const last = Math.floor((e - 1) / cs);
  let o = 0;
  for (let i = first; i <= last; i++) {
    const c = await readChunk(dek, item, i);
    const cStart = i * cs;
    const a = Math.max(s, cStart) - cStart;
    const b = Math.min(e, cStart + c.length) - cStart;
    out.set(c.subarray(a, b), o);
    o += b - a;
  }
  return o === out.length ? out : out.subarray(0, o);
}

export async function readBlob(dek: CryptoKey, item: Item): Promise<Blob> {
  const parts: BlobPart[] = [];
  for await (const c of iterateChunks(dek, item)) parts.push(c);
  return new Blob(parts, { type: item.mime });
}

export async function readThumb(dek: CryptoKey, id: string): Promise<Blob | null> {
  const db = await getDb();
  const row = await db.get('thumbs', id);
  if (!row) return null;
  return new Blob([await open(dek, row, aad.thumb(id))], { type: 'image/webp' });
}

// ---------------------------------------------------------------- texts

export async function saveText(dek: CryptoKey, existing: Item | null, title: string, body: string): Promise<Item> {
  const id = existing?.id ?? randomId();
  const now = Date.now();
  const bytes = strToU8(body);
  const s = await seal(dek, deflateSync(bytes, { level: 6 }), aad.body(id));
  const db = await getDb();
  await db.put('bodies', { id, ...s });
  const explicit = cleanName(title);
  const item: Item = {
    id,
    kind: 'text',
    name: explicit || firstLine(body) || 'متن بدون عنوان',
    autoName: !explicit,
    ext: 'txt',
    mime: 'text/plain;charset=utf-8',
    size: bytes.length,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    deletedAt: existing?.deletedAt ?? null,
    chunks: 0,
    snippet: body.replace(/\s+/g, ' ').trim().slice(0, SNIPPET_LEN),
  };
  await saveProjection(dek, item);
  return item;
}

export function firstLine(body: string): string {
  return cleanName([...(body.split('\n').find((l) => l.trim()) ?? '').trim()].slice(0, 120).join(''));
}

export async function readText(dek: CryptoKey, id: string): Promise<string> {
  const db = await getDb();
  const row = await db.get('bodies', id);
  if (!row) throw new Error('BODY_MISSING');
  return strFromU8(inflateSync(await open(dek, row, aad.body(id))));
}

// ---------------------------------------------------------------- deletion & maintenance

export async function deletePayload(ids: string[]): Promise<void> {
  const db = await getDb();
  const tx = db.transaction(['chunks', 'bodies', 'thumbs'], 'readwrite');
  const ops: Promise<unknown>[] = [];
  for (const id of ids) {
    ops.push(tx.objectStore('chunks').delete(IDBKeyRange.bound([id, 0], [id, Number.MAX_SAFE_INTEGER])));
    ops.push(tx.objectStore('bodies').delete(id));
    ops.push(tx.objectStore('thumbs').delete(id));
  }
  await Promise.all([...ops, tx.done]);
}

/** Permanently deletes items in one atomic transaction. */
export async function purge(ids: string[]): Promise<void> {
  if (!ids.length) return;
  const db = await getDb();
  const tx = db.transaction(['items', 'chunks', 'bodies', 'thumbs'], 'readwrite');
  const ops: Promise<unknown>[] = [];
  for (const id of ids) {
    ops.push(tx.objectStore('items').delete(id));
    ops.push(tx.objectStore('chunks').delete(IDBKeyRange.bound([id, 0], [id, Number.MAX_SAFE_INTEGER])));
    ops.push(tx.objectStore('bodies').delete(id));
    ops.push(tx.objectStore('thumbs').delete(id));
  }
  await Promise.all([...ops, tx.done]);
}

/** Removes payload rows whose projection no longer exists (e.g. an import killed mid-way). */
export async function collectGarbage(validIds: Set<string>): Promise<number> {
  const db = await getDb();
  const [chunkKeys, bodyKeys, thumbKeys, itemKeys] = await Promise.all([
    db.getAllKeys('chunks'),
    db.getAllKeys('bodies'),
    db.getAllKeys('thumbs'),
    db.getAllKeys('items'),
  ]);
  const known = new Set<string>([...validIds, ...itemKeys, ...inflight]);
  const orphan = new Set<string>();
  for (const k of chunkKeys) if (!known.has(k[0])) orphan.add(k[0]);
  for (const k of bodyKeys) if (!known.has(k)) orphan.add(k);
  for (const k of thumbKeys) if (!known.has(k)) orphan.add(k);
  for (const id of inflight) orphan.delete(id); // an import may have started meanwhile
  if (orphan.size) await deletePayload([...orphan]);
  return orphan.size;
}
