import { useEffect, useRef, useState } from 'react';
import { spawnMediaWorker } from '../workers/spawn';
import type { FromWorker } from '../workers/protocol';
import { downscale, renderThumb } from './thumbcore';

/**
 * Small image jobs (pick-screen previews, display-size versions of huge photos) run on a shared
 * media worker with a LIFO, cancellable queue. The worker is terminated after 20 s idle.
 */
type TaskMsg = { type: 'preview'; file: Blob; size: number } | { type: 'downscale'; file: Blob; maxSide: number };
type Task = { msg: TaskMsg; resolve: (b: Blob | null) => void; cancelled: boolean };

let worker: Worker | null | undefined;
let idleTimer = 0;
let seq = 0;
let running = 0;
const MAX_RUNNING = 2;
const queue: Task[] = [];
const waiting = new Map<number, Task>();

function getWorker(): Worker | null {
  if (worker === undefined) {
    worker = spawnMediaWorker();
    worker?.addEventListener('message', (e: MessageEvent<FromWorker>) => {
      const t = waiting.get(e.data.job);
      if (!t) return;
      waiting.delete(e.data.job);
      t.resolve(e.data.type === 'blob' ? e.data.blob : null);
    });
  }
  return worker;
}

function scheduleIdle() {
  clearTimeout(idleTimer);
  idleTimer = window.setTimeout(() => {
    if (running || queue.length) return;
    worker?.terminate();
    worker = undefined;
  }, 20_000);
}

async function runOnMain(t: Task): Promise<Blob | null> {
  try {
    const f = t.msg.file;
    const head = new Uint8Array(await f.slice(0, 256 * 1024).arrayBuffer());
    if (t.msg.type === 'preview') return new Blob([(await renderThumb(f, t.msg.size, head, 'image/webp', 0.72)).bytes], { type: 'image/webp' });
    return await downscale(f, t.msg.maxSide, head);
  } catch {
    return null;
  }
}

function pump() {
  while (running < MAX_RUNNING && queue.length) {
    const t = queue.pop()!;
    if (t.cancelled) {
      t.resolve(null);
      continue;
    }
    running++;
    const done = (b: Blob | null) => {
      running--;
      t.resolve(b);
      pump();
      scheduleIdle();
    };
    const w = getWorker();
    if (!w) {
      void runOnMain(t).then(done);
      continue;
    }
    const job = ++seq;
    waiting.set(job, { ...t, resolve: done });
    w.postMessage({ ...t.msg, job });
  }
}

export function runImageTask(msg: Task['msg']): { promise: Promise<Blob | null>; cancel: () => void } {
  let task!: Task;
  const promise = new Promise<Blob | null>((resolve) => {
    task = { msg, resolve, cancelled: false };
  });
  queue.push(task);
  pump();
  return { promise, cancel: () => (task.cancelled = true) };
}

/** Lazy preview of a picked (not yet imported) image: generated only once the tile is on screen. */
export function usePickPreview(file: File, size = 320): [React.RefObject<HTMLDivElement>, string | null] {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === 'undefined') {
      setVisible(true);
      return;
    }
    const io = new IntersectionObserver((es) => es.some((e) => e.isIntersecting) && setVisible(true), { rootMargin: '400px 0px' });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  useEffect(() => {
    if (!visible) return;
    let alive = true;
    let u: string | null = null;
    const t = runImageTask({ type: 'preview', file, size });
    void t.promise.then((b) => {
      if (!b) return;
      u = URL.createObjectURL(b);
      if (alive) setUrl(u);
      else URL.revokeObjectURL(u);
    });
    return () => {
      alive = false;
      t.cancel();
      if (u) URL.revokeObjectURL(u);
    };
  }, [visible, file, size]);
  return [ref, url];
}
