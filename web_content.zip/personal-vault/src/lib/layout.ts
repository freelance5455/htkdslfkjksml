import type { Item } from './types';

export type Row = { key: string; type: 'pair'; items: Item[] } | { key: string; type: 'item'; item: Item };

/**
 * Builds a dynamic layout: consecutive images are packed two per row as squares.
 * A file/text breaks the run, so a lone image keeps half the width (never stretches).
 */
export function buildRows(items: Item[]): Row[] {
  const rows: Row[] = [];
  let pair: Item[] = [];
  const flush = () => {
    if (pair.length) rows.push({ key: `p:${pair[0].id}`, type: 'pair', items: pair });
    pair = [];
  };
  for (const it of items) {
    if (it.kind === 'image') {
      pair.push(it);
      if (pair.length === 2) flush();
    } else {
      flush();
      rows.push({ key: `i:${it.id}`, type: 'item', item: it });
    }
  }
  flush();
  return rows;
}

export const GRID = { pad: 16, gap: 12, fileH: 76, textH: 104 };

export function rowHeight(r: Row, width: number): number {
  if (r.type === 'pair') return Math.floor((width - GRID.pad * 2 - GRID.gap) / 2) + GRID.gap;
  return (r.item.kind === 'text' ? GRID.textH : GRID.fileH) + GRID.gap;
}
