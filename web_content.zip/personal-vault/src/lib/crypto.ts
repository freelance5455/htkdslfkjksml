/**
 * Cryptographic core of Personal Vault.
 *  - Key derivation: PBKDF2-HMAC-SHA256, 600,000 iterations, 32-byte random salt.
 *  - Data encryption key (DEK): random AES-GCM-256, never stored in plaintext.
 *  - DEK is wrapped with the password-derived KEK (AES-GCM, authenticated, AAD-bound).
 *  - Every record is encrypted with AES-GCM using a fresh 96-bit IV and an AAD that binds
 *    the ciphertext to its record identity (prevents swapping / replaying records).
 */

export const PBKDF2_ITERATIONS = 600_000;
export const PASSWORD_MIN = 4;
export const PASSWORD_MAX = 15;
const DEK_AAD = 'pv:dek:v1';

const te = new TextEncoder();
const td = new TextDecoder();

export const utf8 = (s: string): Uint8Array => te.encode(s);
export const fromUtf8 = (b: Uint8Array): string => td.decode(b);

export function randomBytes(n: number): Uint8Array {
  const b = new Uint8Array(n);
  crypto.getRandomValues(b);
  return b;
}

export function randomId(): string {
  const b = randomBytes(16);
  return Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
}

export interface VaultHeader {
  v: 1;
  kdf: 'PBKDF2-SHA256';
  iterations: number;
  salt: Uint8Array;
  wrapIv: Uint8Array;
  wrappedDek: Uint8Array;
  createdAt: number;
  updatedAt: number;
  /**
   * Optional second wrap of the same DEK with a digits-only "calculator code" (only created when
   * the vault password itself cannot be typed on a calculator). Same KDF and cost.
   */
  calc?: { salt: Uint8Array; wrapIv: Uint8Array; wrappedDek: Uint8Array; iterations: number };
}

export interface Sealed {
  iv: Uint8Array;
  ct: Uint8Array;
}

export class WrongPasswordError extends Error {
  constructor() {
    super('WRONG_PASSWORD');
  }
}

export function validatePassword(pw: string): string | null {
  const len = [...pw].length;
  if (len < PASSWORD_MIN) return `رمز عبور باید حداقل ${PASSWORD_MIN.toLocaleString('fa-IR')} کاراکتر باشد`;
  if (len > PASSWORD_MAX) return `رمز عبور حداکثر ${PASSWORD_MAX.toLocaleString('fa-IR')} کاراکتر است`;
  return null;
}

async function deriveKek(password: string, salt: Uint8Array, iterations: number): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey('raw', utf8(password.normalize('NFC')), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt, iterations },
    base,
    { name: 'AES-GCM', length: 256 },
    false,
    ['wrapKey', 'unwrapKey'],
  );
}

async function wrapWith(dek: CryptoKey, password: string, iterations: number) {
  const salt = randomBytes(32);
  const wrapIv = randomBytes(12);
  const kek = await deriveKek(password, salt, iterations);
  const wrapped = await crypto.subtle.wrapKey('raw', dek, kek, { name: 'AES-GCM', iv: wrapIv, additionalData: utf8(DEK_AAD) });
  return { salt, wrapIv, wrappedDek: new Uint8Array(wrapped) };
}

async function unwrapInternal(header: VaultHeader, password: string, extractable: boolean): Promise<CryptoKey> {
  const kek = await deriveKek(password, header.salt, header.iterations);
  try {
    return await crypto.subtle.unwrapKey(
      'raw',
      header.wrappedDek,
      kek,
      { name: 'AES-GCM', iv: header.wrapIv, additionalData: utf8(DEK_AAD) },
      { name: 'AES-GCM', length: 256 },
      extractable,
      ['encrypt', 'decrypt'],
    );
  } catch {
    throw new WrongPasswordError();
  }
}

/** Creates a brand-new vault header and returns the (non-extractable) DEK. */
export async function createVaultKeys(password: string): Promise<{ header: VaultHeader; dek: CryptoKey }> {
  const temp = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
  const w = await wrapWith(temp, password, PBKDF2_ITERATIONS);
  const now = Date.now();
  const header: VaultHeader = { v: 1, kdf: 'PBKDF2-SHA256', iterations: PBKDF2_ITERATIONS, ...w, createdAt: now, updatedAt: now };
  // Re-import through unwrap so the in-memory key is NOT extractable.
  const dek = await unwrapInternal(header, password, false);
  return { header, dek };
}

/** Unwraps the DEK. Throws WrongPasswordError on a bad password or a tampered header. */
export function unlockDek(header: VaultHeader, password: string): Promise<CryptoKey> {
  return unwrapInternal(header, password, false);
}

/** Unwraps the DEK with the calculator code wrap. Throws WrongPasswordError when it does not match. */
export async function unlockDekWithCalc(header: VaultHeader, code: string): Promise<CryptoKey> {
  if (!header.calc) throw new WrongPasswordError();
  const c = header.calc;
  return unwrapInternal({ ...header, salt: c.salt, wrapIv: c.wrapIv, wrappedDek: c.wrappedDek, iterations: c.iterations }, code, false);
}

/** Adds (or replaces) the calculator-code wrap. Requires the vault password. */
export async function withCalcWrap(header: VaultHeader, password: string, code: string): Promise<VaultHeader> {
  const dek = await unwrapInternal(header, password, true);
  const iterations = Math.max(header.iterations, PBKDF2_ITERATIONS);
  const w = await wrapWith(dek, code, iterations);
  return { ...header, calc: { ...w, iterations }, updatedAt: Date.now() };
}

export const isCalcTypeable = (s: string) => /^[0-9]{4,15}$/.test(s);

/** Re-wraps the same DEK with a new password (data does not need re-encryption). */
export async function rewrapHeader(header: VaultHeader, oldPw: string, newPw: string): Promise<VaultHeader> {
  const dek = await unwrapInternal(header, oldPw, true);
  const w = await wrapWith(dek, newPw, Math.max(header.iterations, PBKDF2_ITERATIONS));
  return { ...header, ...w, iterations: Math.max(header.iterations, PBKDF2_ITERATIONS), updatedAt: Date.now() };
}

export async function seal(key: CryptoKey, data: Uint8Array, aad: string): Promise<Sealed> {
  const iv = randomBytes(12);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: utf8(aad) }, key, data);
  return { iv, ct: new Uint8Array(ct) };
}

export async function open(key: CryptoKey, s: Sealed, aad: string): Promise<Uint8Array> {
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: s.iv, additionalData: utf8(aad) }, key, s.ct);
  return new Uint8Array(pt);
}

export async function sha256(data: Uint8Array): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', data));
}

export function toB64(bytes: Uint8Array): string {
  let s = '';
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) {
    s += String.fromCharCode.apply(null, bytes.subarray(i, i + step) as unknown as number[]);
  }
  return btoa(s);
}

export function fromB64(b64: string): Uint8Array {
  const s = atob(b64);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

export function equalBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
  return d === 0;
}

/** Password strength 0..4 (length + character classes). */
export function passwordStrength(pw: string): number {
  if (!pw) return 0;
  let score = 0;
  const len = [...pw].length;
  if (len >= 6) score++;
  if (len >= 10) score++;
  const classes = [/[a-z]/, /[A-Z]/, /[0-9۰-۹]/, /[^A-Za-z0-9۰-۹]/].filter((r) => r.test(pw)).length;
  if (classes >= 2) score++;
  if (classes >= 3) score++;
  return Math.min(4, score);
}
