import { useEffect, useRef } from 'react';

/**
 * Android back-button dispatcher. Handlers are ordered by priority (dialogs > sheets >
 * drawer > selection > routes); among equal priorities the latest registered wins.
 */
export const BackPriority = { root: 0, route: 10, selection: 50, drawer: 80, sheet: 100, viewer: 60, dialog: 200 } as const;

interface Entry {
  id: number;
  priority: number;
  fn: () => void;
}
let seq = 0;
const entries: Entry[] = [];

export function registerBack(priority: number, fn: () => void): () => void {
  const e = { id: ++seq, priority, fn };
  entries.push(e);
  return () => {
    const i = entries.indexOf(e);
    if (i >= 0) entries.splice(i, 1);
  };
}

/** Returns true when something consumed the back press. */
export function dispatchBack(): boolean {
  if (!entries.length) return false;
  const top = entries.reduce((a, b) => (b.priority > a.priority || (b.priority === a.priority && b.id > a.id) ? b : a));
  top.fn();
  return true;
}

export function useBack(active: boolean, priority: number, fn: () => void) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    if (!active) return;
    return registerBack(priority, () => ref.current());
  }, [active, priority]);
}
