import { openDB, type DBSchema, type IDBPDatabase } from 'idb';
import type { Sealed, VaultHeader } from './crypto';

/**
 * Storage layout (every value except the KDF header is AES-GCM ciphertext):
 *  meta    'vault'      -> VaultHeader (salt, iterations, wrapped DEK)
 *  items   id           -> encrypted projection (name, kind, size, dates, snippet...)
 *  chunks  [id, index]  -> encrypted 512 KiB slices of file / image payloads
 *  bodies  id           -> encrypted, deflated text body
 *  thumbs  id           -> encrypted image thumbnail
 * Only opaque random ids and ciphertext sizes are visible without the password.
 */

export interface SealedRow extends Sealed {
  id: string;
}
export interface ChunkRow extends Sealed {
  id: string;
  idx: number;
}

export interface PVSchema extends DBSchema {
  meta: { key: string; value: VaultHeader };
  items: { key: string; value: SealedRow };
  chunks: { key: [string, number]; value: ChunkRow };
  bodies: { key: string; value: SealedRow };
  thumbs: { key: string; value: SealedRow };
}

export type PVDB = IDBPDatabase<PVSchema>;
export const STORE_NAMES = ['meta', 'items', 'chunks', 'bodies', 'thumbs'] as const;

const DEFAULT_DB = 'personal-vault';
const POINTER_KEY = 'pv.activeDb';
const DB_VERSION = 1;

export function activeDbName(): string {
  return localStorage.getItem(POINTER_KEY) || DEFAULT_DB;
}

export function openVaultDb(name: string): Promise<PVDB> {
  return openDB<PVSchema>(name, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta');
      if (!db.objectStoreNames.contains('items')) db.createObjectStore('items', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('chunks')) db.createObjectStore('chunks', { keyPath: ['id', 'idx'] });
      if (!db.objectStoreNames.contains('bodies')) db.createObjectStore('bodies', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('thumbs')) db.createObjectStore('thumbs', { keyPath: 'id' });
    },
    blocked() {
      /* another tab holds an old version: nothing to do on Android */
    },
  });
}

let dbPromise: Promise<PVDB> | null = null;

export function getDb(): Promise<PVDB> {
  if (!dbPromise) dbPromise = openVaultDb(activeDbName());
  return dbPromise;
}

export async function closeDb(): Promise<void> {
  if (dbPromise) {
    const db = await dbPromise.catch(() => null);
    db?.close();
    dbPromise = null;
  }
}

/** Atomically switches the active database (used by Restore). The old DB is removed afterwards. */
export async function switchActiveDb(newName: string): Promise<void> {
  const old = activeDbName();
  await closeDb();
  localStorage.setItem(POINTER_KEY, newName);
  if (old !== newName) await deleteDb(old);
}

export function deleteDb(name: string): Promise<void> {
  return new Promise((resolve) => {
    const req = indexedDB.deleteDatabase(name);
    req.onsuccess = () => resolve();
    req.onerror = () => resolve();
    req.onblocked = () => resolve();
  });
}

/** Removes half-written staging databases left behind by an interrupted restore. */
export async function cleanupStaleDbs(): Promise<void> {
  const idb = indexedDB as IDBFactory & { databases?: () => Promise<{ name?: string }[]> };
  if (!idb.databases) return;
  const active = activeDbName();
  const list = await idb.databases().catch(() => []);
  await Promise.all(
    list.filter((d) => d.name && d.name.startsWith('pv-staging-') && d.name !== active).map((d) => deleteDb(d.name!)),
  );
}

export async function readHeader(): Promise<VaultHeader | undefined> {
  const db = await getDb();
  return db.get('meta', 'vault');
}

export async function writeHeader(h: VaultHeader): Promise<void> {
  const db = await getDb();
  await db.put('meta', h, 'vault');
}

export async function requestPersistence(): Promise<void> {
  try {
    if (navigator.storage?.persist) await navigator.storage.persist();
  } catch {
    /* ignore */
  }
}
