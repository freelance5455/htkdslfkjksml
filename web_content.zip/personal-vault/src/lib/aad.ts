/** Additional-authenticated-data labels: bind every ciphertext to its record identity. */
export const aad = {
  proj: (id: string) => `pv:proj:v1:${id}`,
  chunk: (id: string, i: number) => `pv:chunk:v1:${id}:${i}`,
  body: (id: string) => `pv:body:v1:${id}`,
  thumb: (id: string) => `pv:thumb:v1:${id}`,
};
