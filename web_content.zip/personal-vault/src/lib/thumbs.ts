import { renderThumb } from './thumbcore';

/** Main-thread thumbnail generation (fallback only): one image decoded at a time. */
const SHORT_SIDE = 440;
let chain: Promise<unknown> = Promise.resolve();

export function makeThumbnail(file: Blob): Promise<{ bytes: Uint8Array; width: number; height: number }> {
  const run = chain.then(async () => renderThumb(file, SHORT_SIDE, new Uint8Array(await file.slice(0, 256 * 1024).arrayBuffer())));
  chain = run.catch(() => undefined);
  return run;
}

/** Center-crops an image to a square PNG data URL (used for custom app icons). */
export async function squareIcon(file: Blob, size = 256): Promise<string> {
  const bmp = await createImageBitmap(file);
  try {
    const s = Math.min(bmp.width, bmp.height);
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, size, size);
    const url = canvas.toDataURL('image/png');
    canvas.width = canvas.height = 0;
    return url;
  } finally {
    bmp.close();
  }
}
