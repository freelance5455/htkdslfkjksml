const nf = new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 1 });
export const faNum = (n: number) => new Intl.NumberFormat('fa-IR').format(n);

export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${faNum(bytes)} B`;
  const u = ['KB', 'MB', 'GB', 'TB'];
  let v = bytes / 1024;
  let i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return `${nf.format(v)} ${u[i]}`;
}

const dateFmt = new Intl.DateTimeFormat('fa-IR', { day: 'numeric', month: 'long', year: 'numeric' });
const timeFmt = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit' });

export function formatDate(ts: number): string {
  const d = new Date(ts);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return `امروز، ${timeFmt.format(d)}`;
  const y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return `دیروز، ${timeFmt.format(d)}`;
  return dateFmt.format(d);
}

export function formatDateTime(ts: number): string {
  return `${dateFmt.format(new Date(ts))} - ${timeFmt.format(new Date(ts))}`;
}

export type FileVisual = { icon: 'file' | 'fileText' | 'archive' | 'audio' | 'video' | 'code' | 'sheet' | 'image'; hue: string; label: string };

export function fileVisual(ext: string, mime: string): FileVisual {
  const e = ext.toLowerCase();
  const label = (e || 'file').slice(0, 4).toUpperCase();
  if (mime.startsWith('image/')) return { icon: 'image', hue: 'cyan', label };
  if (mime.startsWith('video/') || ['mp4', 'mkv', 'mov', 'avi', 'webm'].includes(e)) return { icon: 'video', hue: 'rose', label };
  if (mime.startsWith('audio/') || ['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'].includes(e)) return { icon: 'audio', hue: 'amber', label };
  if (['zip', 'rar', '7z', 'tar', 'gz', 'apk'].includes(e)) return { icon: 'archive', hue: 'amber', label };
  if (['xls', 'xlsx', 'csv', 'ods'].includes(e)) return { icon: 'sheet', hue: 'emerald', label };
  if (['js', 'ts', 'json', 'html', 'css', 'py', 'java', 'kt', 'xml'].includes(e)) return { icon: 'code', hue: 'cyan', label };
  if (['pdf', 'doc', 'docx', 'txt', 'rtf', 'odt', 'md', 'ppt', 'pptx'].includes(e) || mime.startsWith('text/')) return { icon: 'fileText', hue: 'violet', label };
  return { icon: 'file', hue: 'violet', label };
}
