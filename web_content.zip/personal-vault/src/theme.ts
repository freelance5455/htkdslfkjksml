import { useEffect, useState } from 'react';
import { usePrefs } from './store/prefs';
import { setSystemBars } from './lib/native';

const mq = () => window.matchMedia('(prefers-color-scheme: light)');

export function useResolvedTheme(): 'dark' | 'light' {
  const mode = usePrefs((s) => s.themeMode);
  const [sys, setSys] = useState<'dark' | 'light'>(() => (mq().matches ? 'light' : 'dark'));
  useEffect(() => {
    const m = mq();
    const on = () => setSys(m.matches ? 'light' : 'dark');
    m.addEventListener('change', on);
    return () => m.removeEventListener('change', on);
  }, []);
  return mode === 'system' ? sys : mode;
}

/** Applies theme tokens to <html>, the window title and the Android system bars. */
export function useApplyTheme() {
  const theme = useResolvedTheme();
  const accent = usePrefs((s) => s.accent);
  const surface = usePrefs((s) => s.surface);
  const appName = usePrefs((s) => s.appName);
  useEffect(() => {
    const el = document.documentElement;
    el.dataset.theme = theme;
    el.dataset.accent = accent;
    el.dataset.surface = surface;
    const bg = theme === 'dark' ? '#0c0e14' : '#f8fafc';
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', bg);
    setSystemBars(bg, theme === 'light');
  }, [theme, accent, surface]);
  useEffect(() => {
    document.title = appName;
  }, [appName]);
}
