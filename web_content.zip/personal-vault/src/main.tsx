import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/vazirmatn/400.css';
import '@fontsource/vazirmatn/500.css';
import '@fontsource/vazirmatn/700.css';
import './styles.css';
import { App } from './App';
import { bindKeyProvider } from './lib/media';
import { useSession } from './store/session';
import { initWebStreaming } from './lib/stream';

bindKeyProvider(() => useSession.getState().dek);
// web builds: range-capable streaming of vault files through a service worker (Android uses native code)
void initWebStreaming();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
