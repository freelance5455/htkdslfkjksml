import { create } from 'zustand';

export type Tab = 'dashboard' | 'files' | 'texts' | 'images' | 'settings';

export type Route =
  | { name: 'addFiles' }
  | { name: 'addImages' }
  | { name: 'textEdit'; id?: string }
  | { name: 'textView'; id: string }
  | { name: 'viewer'; ids: string[]; index: number }
  | { name: 'preview'; id: string; info?: boolean }
  | { name: 'all' }
  | { name: 'trash' }
  | { name: 'appearance' }
  | { name: 'backup' }
  | { name: 'security' };

interface NavStore {
  tab: Tab;
  stack: Route[];
  visited: Tab[];
  setTab: (t: Tab) => void;
  push: (r: Route) => void;
  replace: (r: Route) => void;
  pop: () => void;
  reset: () => void;
}

export const useNav = create<NavStore>((set, get) => ({
  tab: 'dashboard',
  stack: [],
  visited: ['dashboard'],
  setTab: (tab) => {
    const visited = get().visited.includes(tab) ? get().visited : [...get().visited, tab];
    if (tab === get().tab && !get().stack.length) return;
    set({ tab, visited, stack: [] });
  },
  push: (r) => set({ stack: [...get().stack, r] }),
  replace: (r) => set({ stack: [...get().stack.slice(0, -1), r] }),
  pop: () => set({ stack: get().stack.slice(0, -1) }),
  reset: () => set({ tab: 'dashboard', stack: [], visited: ['dashboard'] }),
}));

/** Root back behaviour: route stack → non-dashboard tab → dashboard. Returns false at the true root. */
export function navBack(): boolean {
  const n = useNav.getState();
  if (n.stack.length) {
    n.pop();
    return true;
  }
  if (n.tab !== 'dashboard') {
    n.setTab('dashboard');
    return true;
  }
  return false;
}
