import { create } from 'zustand';
import { createVaultKeys, isCalcTypeable, unlockDek, unlockDekWithCalc, validatePassword, WrongPasswordError } from '../lib/crypto';
import { cleanupStaleDbs, readHeader, requestPersistence, writeHeader } from '../lib/db';
import { collectGarbage, loadProjections } from '../lib/vault';
import type { Item } from '../lib/types';
import { clearMediaCache } from '../lib/media';
import { clearSearchCache } from '../lib/search';
import { useNav } from './nav';
import { clearTempFiles } from '../lib/native';
import { closeAllStreams } from '../lib/stream';
import { dismissDialogs, useUi } from './ui';

export type Status = 'boot' | 'setup' | 'locked' | 'unlocked';

interface SessionStore {
  status: Status;
  dek: CryptoKey | null;
  items: Map<string, Item>;
  rev: number;
  corrupt: number;
  boot: () => Promise<void>;
  setup: (pw: string) => Promise<void>;
  unlock: (pw: string) => Promise<void>;
  /** Calculator disguise entry: never throws, never reports anything (see LockedRoot). */
  unlockSilent: (code: string) => Promise<boolean>;
  lock: () => void;
  upsert: (items: Item[]) => void;
  drop: (ids: string[]) => void;
}

const FAIL_KEY = 'pv.fail';

/** Brute-force throttling: after 5 failures each further attempt waits progressively longer. */
export function unlockDelayMs(): number {
  try {
    const f = JSON.parse(localStorage.getItem(FAIL_KEY) || '{"n":0,"t":0}') as { n: number; t: number };
    if (f.n < 5) return 0;
    const wait = Math.min(300_000, 15_000 * 2 ** (f.n - 5));
    return Math.max(0, f.t + wait - Date.now());
  } catch {
    return 0;
  }
}
function recordFail() {
  let f = { n: 0, t: 0 };
  try {
    f = JSON.parse(localStorage.getItem(FAIL_KEY) || '{"n":0,"t":0}') as { n: number; t: number };
  } catch {
    /* corrupted counter: start over */
  }
  localStorage.setItem(FAIL_KEY, JSON.stringify({ n: (f.n || 0) + 1, t: Date.now() }));
}

// Silent throttling for the calculator entry: after repeated misses further attempts are
// ignored for a while. Nothing is shown and ordinary calculator use is never affected.
const silentFails: number[] = [];
let silentBusy = false;
function silentThrottled(): boolean {
  const now = Date.now();
  while (silentFails.length && now - silentFails[0] > 60_000) silentFails.shift();
  return silentFails.length >= 6;
}

let finishUnlock: (dek: CryptoKey) => Promise<void> = async () => undefined;

export const useSession = create<SessionStore>((set, get) => {
  finishUnlock = async (dek: CryptoKey) => {
    const { items, corrupt } = await loadProjections(dek);
    const map = new Map(items.map((i) => [i.id, i]));
    useNav.getState().reset();
    set({ status: 'unlocked', dek, items: map, rev: get().rev + 1, corrupt });
    void requestPersistence();
    // background maintenance: remove payloads orphaned by interrupted imports
    setTimeout(() => void collectGarbage(new Set(map.keys())).catch(() => undefined), 1500);
  };
  return {
  status: 'boot',
  dek: null,
  items: new Map(),
  rev: 0,
  corrupt: 0,

  boot: async () => {
    // leftovers of a previous run (crash / force-stop) are removed before anything else
    clearTempFiles(0);
    await cleanupStaleDbs().catch(() => undefined);
    const h = await readHeader();
    set({ status: h ? 'locked' : 'setup' });
  },

  setup: async (pw) => {
    const err = validatePassword(pw);
    if (err) throw new Error(err);
    if (await readHeader()) throw new Error('یک گاوصندوق از قبل وجود دارد');
    const { header, dek } = await createVaultKeys(pw);
    await writeHeader(header);
    await requestPersistence();
    set({ status: 'unlocked', dek, items: new Map(), rev: get().rev + 1 });
  },

  unlock: async (pw) => {
    const wait = unlockDelayMs();
    if (wait > 0) throw new Error(`تلاش‌های ناموفق زیاد؛ ${Math.ceil(wait / 1000).toLocaleString('fa-IR')} ثانیه صبر کنید`);
    const h = await readHeader();
    if (!h) {
      set({ status: 'setup' });
      return;
    }
    let dek: CryptoKey;
    try {
      dek = await unlockDek(h, pw);
    } catch (e) {
      if (e instanceof WrongPasswordError) {
        recordFail();
        throw new Error('رمز عبور نادرست است');
      }
      throw e;
    }
    localStorage.removeItem(FAIL_KEY);
    await finishUnlock(dek);
  },

  unlockSilent: async (code) => {
    if (!isCalcTypeable(code) || silentBusy || silentThrottled()) return false;
    silentBusy = true;
    try {
      const h = await readHeader();
      if (!h || get().status !== 'locked') return false;
      let dek: CryptoKey | null = null;
      if (h.calc) dek = await unlockDekWithCalc(h, code).catch(() => null);
      if (!dek) dek = await unlockDek(h, code).catch(() => null);
      if (!dek) {
        silentFails.push(Date.now());
        return false;
      }
      silentFails.length = 0;
      if (get().status !== 'locked') return false;
      await finishUnlock(dek);
      return true;
    } catch {
      return false;
    } finally {
      silentBusy = false;
    }
  },

  lock: () => {
    if (get().status !== 'unlocked') return;
    // status flips first so every in-flight operation (imports, previews) sees the lock
    set({ status: 'locked', dek: null, items: new Map(), rev: get().rev + 1 });
    clearMediaCache();
    closeAllStreams();
    clearSearchCache();
    dismissDialogs();
    useUi.setState({ drawerOpen: false, navHidden: false, mediaActive: 0 });
    useUi.getState().setProgress(null);
    useNav.getState().reset();
    // decrypted preview copies are deleted (a copy just handed to another app survives 2 min)
    clearTempFiles(120_000);
  },

  upsert: (list) => {
    const items = new Map(get().items);
    for (const it of list) items.set(it.id, it);
    set({ items, rev: get().rev + 1 });
  },

  drop: (ids) => {
    const items = new Map(get().items);
    for (const id of ids) items.delete(id);
    set({ items, rev: get().rev + 1 });
  },
};
});

export function requireDek(): CryptoKey {
  const k = useSession.getState().dek;
  if (!k) throw new Error('LOCKED');
  return k;
}
