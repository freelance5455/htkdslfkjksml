import { create } from 'zustand';
import type { SortKey } from '../lib/types';

export type ThemeMode = 'dark' | 'light' | 'system';
export type Accent = 'emerald' | 'cyan' | 'violet' | 'amber' | 'rose';
export type Surface = 'glass' | 'solid';
export type CalcStyle = 'obsidian' | 'classic' | 'minimal';

/** Non-secret UI preferences. Never contains passwords, keys or vault content. */
export interface Prefs {
  appName: string;
  themeMode: ThemeMode;
  accent: Accent;
  surface: Surface;
  calcName: string;
  calcStyle: CalcStyle;
  calcAccent: Accent;
  disguise: boolean;
  /** true once disguise was enabled with a calculator-typeable password or code (v2.2+). */
  disguiseReady: boolean;
  /** Uninstall protection (Device Admin) requested by the user; the real state is read from Android. */
  uninstallGuard: boolean;
  /** Ask before leaving the app with the Back button on the dashboard. */
  confirmExit: boolean;
  autoLockMin: number; // 0 = never
  bgLockSec: number; // -1 = never, 0 = immediately
  secureScreen: boolean;
  iconDataUrl: string | null;
  sorts: Partial<Record<string, SortKey>>;
}

export const DEFAULT_APP_NAME = 'Personal Vault';
export const DEFAULT_CALC_NAME = 'ماشین‌حساب';

const DEFAULTS: Prefs = {
  appName: DEFAULT_APP_NAME,
  themeMode: 'dark',
  accent: 'emerald',
  surface: 'glass',
  calcName: DEFAULT_CALC_NAME,
  calcStyle: 'obsidian',
  calcAccent: 'amber',
  disguise: false,
  disguiseReady: false,
  uninstallGuard: false,
  confirmExit: false,
  autoLockMin: 5,
  bgLockSec: 30,
  secureScreen: true,
  iconDataUrl: null,
  sorts: {},
};

const KEY = 'pv.prefs.v1';

function load(): Prefs {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULTS;
    const p = { ...DEFAULTS, ...(JSON.parse(raw) as Partial<Prefs>) };
    // v2.2: the calculator has no menu any more; entry is only possible with a typeable code.
    // A disguise enabled by an older version (possibly with a non-numeric password) is turned
    // off instead of locking the owner out; it can be re-enabled from Settings.
    if (p.disguise && !p.disguiseReady) p.disguise = false;
    return p;
  } catch {
    return DEFAULTS;
  }
}

interface PrefsStore extends Prefs {
  set: (p: Partial<Prefs>) => void;
}

export const usePrefs = create<PrefsStore>((set, get) => ({
  ...load(),
  set: (p) => {
    set(p);
    const { set: _s, ...rest } = get();
    void _s;
    try {
      localStorage.setItem(KEY, JSON.stringify(rest));
    } catch {
      /* quota: ignore */
    }
  },
}));

export const ACCENTS: Record<Accent, { label: string; dark: string; light: string; rgbDark: string; rgbLight: string }> = {
  emerald: { label: 'زمردی', dark: '#10b981', light: '#059669', rgbDark: '16,185,129', rgbLight: '5,150,105' },
  cyan: { label: 'فیروزه‌ای', dark: '#06b6d4', light: '#0891b2', rgbDark: '6,182,212', rgbLight: '8,145,178' },
  violet: { label: 'بنفش', dark: '#8b5cf6', light: '#7c3aed', rgbDark: '139,92,246', rgbLight: '124,58,237' },
  amber: { label: 'کهربایی', dark: '#f59e0b', light: '#d97706', rgbDark: '245,158,11', rgbLight: '217,119,6' },
  rose: { label: 'سرخابی', dark: '#f43f5e', light: '#e11d48', rgbDark: '244,63,94', rgbLight: '225,29,72' },
};
