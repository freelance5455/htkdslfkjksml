import { create } from 'zustand';

export type DialogReq =
  | { type: 'confirm'; title: string; message?: string; confirmText?: string; cancelText?: string; danger?: boolean; icon?: string; resolve: (v: boolean) => void }
  | { type: 'prompt'; title: string; message?: string; value: string; placeholder?: string; confirmText?: string; maxLength?: number; numeric?: boolean; secret?: boolean; resolve: (v: string | null) => void }
  | { type: 'password'; title: string; message?: string; confirmText?: string; resolve: (v: string | null) => void };

export interface Toast {
  id: number;
  msg: string;
  kind: 'ok' | 'err' | 'info';
}

export interface Progress {
  title: string;
  detail?: string;
  value: number; // 0..1, <0 = indeterminate
  onCancel?: () => void;
  cancelLabel?: string;
}

interface UiStore {
  toasts: Toast[];
  dialog: DialogReq | null;
  progress: Progress | null;
  navHidden: boolean;
  drawerOpen: boolean;
  pickerActiveUntil: number;
  /** >0 while audio/video is playing: counts as user activity for the inactivity lock. */
  mediaActive: number;
  toast: (msg: string, kind?: Toast['kind']) => void;
  setProgress: (p: Progress | null) => void;
  setNavHidden: (v: boolean) => void;
  setDrawer: (v: boolean) => void;
  closeDialog: () => void;
}

let tid = 0;
// Progress updates can arrive thousands of times per second (per chunk / per record):
// coalesce them so the overlay re-renders at most ~12 times per second.
let pendingProgress: Progress | null = null;
let progressTimer = 0;

export const useUi = create<UiStore>((set, get) => ({
  toasts: [],
  dialog: null,
  progress: null,
  navHidden: false,
  drawerOpen: false,
  pickerActiveUntil: 0,
  mediaActive: 0,
  toast: (msg, kind = 'ok') => {
    const id = ++tid;
    set({ toasts: [...get().toasts.slice(-2), { id, msg, kind }] });
    setTimeout(() => set({ toasts: get().toasts.filter((t) => t.id !== id) }), 2600);
  },
  setProgress: (p) => {
    if (!p) {
      pendingProgress = null;
      if (progressTimer) clearTimeout(progressTimer);
      progressTimer = 0;
      if (get().progress) set({ progress: null });
      return;
    }
    // first frame (and structural changes) show immediately
    const cur = get().progress;
    if (!cur || cur.title !== p.title || cur.onCancel !== p.onCancel) {
      pendingProgress = null;
      set({ progress: p });
      return;
    }
    pendingProgress = p;
    if (!progressTimer)
      progressTimer = window.setTimeout(() => {
        progressTimer = 0;
        if (pendingProgress && get().progress) set({ progress: pendingProgress });
        pendingProgress = null;
      }, 80);
  },
  setNavHidden: (navHidden) => set({ navHidden }),
  setDrawer: (drawerOpen) => set({ drawerOpen }),
  closeDialog: () => set({ dialog: null }),
}));

export const toast = (msg: string, kind?: Toast['kind']) => useUi.getState().toast(msg, kind);

/** A new dialog replaces an open one; the replaced dialog resolves as "cancelled" (never hangs). */
function showDialog(d: DialogReq) {
  const prev = useUi.getState().dialog;
  if (prev) {
    if (prev.type === 'confirm') prev.resolve(false);
    else prev.resolve(null);
  }
  useUi.setState({ dialog: d });
}

export function confirmDialog(o: { title: string; message?: string; confirmText?: string; cancelText?: string; danger?: boolean; icon?: string }): Promise<boolean> {
  return new Promise((resolve) => showDialog({ type: 'confirm', ...o, resolve }));
}

export function promptDialog(o: { title: string; message?: string; value?: string; placeholder?: string; confirmText?: string; maxLength?: number; numeric?: boolean; secret?: boolean }): Promise<string | null> {
  return new Promise((resolve) => showDialog({ type: 'prompt', value: '', ...o, resolve }));
}

export function passwordDialog(o: { title: string; message?: string; confirmText?: string }): Promise<string | null> {
  return new Promise((resolve) => showDialog({ type: 'password', ...o, resolve }));
}

/** Dismisses any open dialog as cancelled (used when the vault locks). */
export function dismissDialogs() {
  const d = useUi.getState().dialog;
  if (!d) return;
  if (d.type === 'confirm') d.resolve(false);
  else d.resolve(null);
  useUi.setState({ dialog: null });
}

/** Opens a system picker without triggering the background auto-lock. */
export function openPicker(input: HTMLInputElement | null) {
  if (!input) return;
  useUi.setState({ pickerActiveUntil: Date.now() + 10 * 60_000 });
  input.value = '';
  // A dismissed picker never fires "change": end the auto-lock suspension when the user
  // returns to the app (or when the browser reports the cancel), not after 10 minutes.
  const onBack = () => {
    if (document.hidden) return;
    document.removeEventListener('visibilitychange', onBack);
    window.removeEventListener('focus', onBack);
    setTimeout(pickerDone, 0);
  };
  input.addEventListener('cancel', () => pickerDone(), { once: true });
  setTimeout(() => {
    document.addEventListener('visibilitychange', onBack);
    window.addEventListener('focus', onBack);
  }, 400);
  input.click();
}

export function pickerDone() {
  useUi.setState({ pickerActiveUntil: Date.now() + 1500 });
}

export function mediaHold(on: boolean) {
  useUi.setState((s) => ({ mediaActive: Math.max(0, s.mediaActive + (on ? 1 : -1)) }));
}
