#!/usr/bin/env node
/**
 * One-command APK build:  npm run android:apk            (debug APK)
 *                         npm run android:apk -- --release (release APK; signed if keystore/ is set up)
 */
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const release = process.argv.includes('--release');
const run = (cmd, cwd = root) => {
  console.log(`\n▶ ${cmd}`);
  execSync(cmd, { cwd, stdio: 'inherit' });
};

run('npm run build');
if (!fs.existsSync(path.join(root, 'android'))) run('npx cap add android');
run('npx cap sync android');
run('node scripts/patch-android.mjs');
const gradlew = process.platform === 'win32' ? 'gradlew.bat' : './gradlew';
if (process.platform !== 'win32') fs.chmodSync(path.join(root, 'android', 'gradlew'), 0o755);
run(`${gradlew} ${release ? 'assembleRelease' : 'assembleDebug'}`, path.join(root, 'android'));
const out = path.join(root, 'android', 'app', 'build', 'outputs', 'apk', release ? 'release' : 'debug');
const apks = fs.existsSync(out) ? fs.readdirSync(out).filter((f) => f.endsWith('.apk')) : [];
fs.mkdirSync(path.join(root, 'dist-apk'), { recursive: true });
for (const a of apks) fs.copyFileSync(path.join(out, a), path.join(root, 'dist-apk', a));
console.log(`\n✔ APK: ${apks.map((a) => 'dist-apk/' + a).join(', ') || '(not found, see Gradle output)'}`);
