#!/usr/bin/env node
/**
 * Applies Personal Vault's native layer to the Capacitor Android project (android/).
 * Idempotent: safe to run after every `npx cap add android` / `npx cap sync android`.
 *  - copies the native plugin + range-capable WebViewClient, registers the plugin in MainActivity
 *  - launcher activity-aliases (vault / calculator disguise) + icons
 *  - FileProvider restricted to temporary "open with" copies, <queries> for ACTION_VIEW
 *  - device-admin receiver for the optional uninstall protection
 *  - allowBackup=false, legacy storage permission (Android 9 and below only)
 *  - optional release signing from keystore/keystore.properties
 */
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const android = path.join(root, 'android');
const app = path.join(android, 'app');
const main = path.join(app, 'src', 'main');
const pkg = 'com.personalvault.app';
const javaDir = path.join(main, 'java', ...pkg.split('.'));

function fail(msg) {
  console.error(`✖ ${msg}`);
  process.exit(1);
}
if (!fs.existsSync(main)) fail('android/ not found. Run "npx cap add android" first (npm run android:apk does it for you).');

const read = (p) => fs.readFileSync(p, 'utf8');
const write = (p, s) => {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, s);
};
function copyDir(src, dst) {
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name);
    const d = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(s, d);
    else {
      fs.mkdirSync(dst, { recursive: true });
      fs.copyFileSync(s, d);
    }
  }
}

// 1. Java sources
for (const f of fs.readdirSync(path.join(root, 'android-native'))) {
  if (f.endsWith('.java')) fs.copyFileSync(path.join(root, 'android-native', f), path.join(javaDir, f));
}
write(
  path.join(javaDir, 'MainActivity.java'),
  `package ${pkg};

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(VaultNativePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`,
);

// 2. resources (icons, file provider paths)
copyDir(path.join(root, 'android-res', 'res'), path.join(main, 'res'));
// Capacitor's template foreground PNGs are no longer referenced
for (const d of fs.readdirSync(path.join(main, 'res'))) {
  const f = path.join(main, 'res', d, 'ic_launcher_foreground.png');
  if (fs.existsSync(f)) fs.rmSync(f);
}
const stringsPath = path.join(main, 'res', 'values', 'strings.xml');
let strings = read(stringsPath);
if (!strings.includes('name="calc_label"')) strings = strings.replace('</resources>', '    <string name="calc_label">ماشین‌حساب</string>\n</resources>');
write(stringsPath, strings);

// 3. manifest
const manifestPath = path.join(main, 'AndroidManifest.xml');
let m = read(manifestPath);
m = m.replace(/android:allowBackup="true"/, 'android:allowBackup="false"');
if (!m.includes('android:fullBackupContent')) m = m.replace('android:allowBackup="false"', 'android:allowBackup="false"\n        android:fullBackupContent="false"\n        android:largeHeap="true"');
// the launcher entry moves to activity-aliases
{
  const a = m.indexOf('android:name=".MainActivity"');
  const b = m.indexOf('</activity>', a);
  if (a >= 0 && b > a) {
    const block = m.slice(a, b).replace(/<intent-filter>\s*<action android:name="android.intent.action.MAIN"\s*\/>\s*<category android:name="android.intent.category.LAUNCHER"\s*\/>\s*<\/intent-filter>\s*/, '');
    m = m.slice(0, a) + block + m.slice(b);
  }
}
if (!m.includes('.LauncherVault')) {
  const aliases = `
        <activity-alias
            android:name=".LauncherVault"
            android:enabled="true"
            android:exported="true"
            android:icon="@mipmap/ic_launcher"
            android:roundIcon="@mipmap/ic_launcher_round"
            android:label="@string/app_name"
            android:targetActivity=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity-alias>

        <activity-alias
            android:name=".LauncherCalc"
            android:enabled="false"
            android:exported="true"
            android:icon="@mipmap/ic_launcher_calc"
            android:roundIcon="@mipmap/ic_launcher_calc_round"
            android:label="@string/calc_label"
            android:targetActivity=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity-alias>
`;
  m = m.replace(/(<\/activity>)/, `$1\n${aliases}`);
}
if (!m.includes('<queries>')) {
  m = m.replace(
    /(<application)/,
    `<queries>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:mimeType="*/*" />
        </intent>
    </queries>

    $1`,
  );
}
if (!m.includes('WRITE_EXTERNAL_STORAGE')) {
  m = m.replace(/(<uses-permission android:name="android.permission.INTERNET"\s*\/>)/, `$1\n    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />`);
}
// uninstall protection: device-admin receiver (only the force-lock policy)
if (!m.includes('.PvAdminReceiver')) {
  m = m.replace(
    /(<\/application>)/,
    `    <receiver
            android:name=".PvAdminReceiver"
            android:exported="true"
            android:label="@string/app_name"
            android:permission="android.permission.BIND_DEVICE_ADMIN">
            <meta-data android:name="android.app.device_admin" android:resource="@xml/pv_device_admin" />
            <intent-filter>
                <action android:name="android.app.action.DEVICE_ADMIN_ENABLED" />
            </intent-filter>
        </receiver>
    $1`,
  );
}
if (!m.includes('androidx.core.content.FileProvider')) {
  m = m.replace(
    /(<\/application>)/,
    `    <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths" />
        </provider>
    $1`,
  );
}
write(manifestPath, m);

// 4. release signing (optional): keystore/keystore.properties with storeFile, storePassword, keyAlias, keyPassword
const gradlePath = path.join(app, 'build.gradle');
let g = read(gradlePath);
if (!g.includes('pvKeystoreProps')) {
  g = g.replace(
    /android\s*\{/,
    `def pvKeystoreProps = new Properties()
def pvKeystoreFile = rootProject.file("../keystore/keystore.properties")
if (pvKeystoreFile.exists()) { pvKeystoreProps.load(new FileInputStream(pvKeystoreFile)) }

android {
    signingConfigs {
        if (pvKeystoreFile.exists()) {
            release {
                storeFile rootProject.file("../keystore/" + pvKeystoreProps['storeFile'])
                storePassword pvKeystoreProps['storePassword']
                keyAlias pvKeystoreProps['keyAlias']
                keyPassword pvKeystoreProps['keyPassword']
            }
        }
    }`,
  );
  g = g.replace(/(buildTypes\s*\{\s*release\s*\{)/, `$1\n            if (pvKeystoreFile.exists()) { signingConfig signingConfigs.release }`);
  write(gradlePath, g);
}

console.log('✔ Android project patched (plugin, launcher aliases, icons, file provider, manifest hardening)');
