import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.personalvault.app',
  appName: 'Personal Vault',
  webDir: 'dist',
  backgroundColor: '#0c0e14',
  server: {
    // in-app media/preview URLs (https://localhost/_pv_media/<token>) are served by PvWebViewClient
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
    webContentsDebuggingEnabled: false,
    captureInput: true,
  },
};

export default config;
