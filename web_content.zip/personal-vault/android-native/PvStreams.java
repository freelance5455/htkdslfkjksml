package com.personalvault.app;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * On-demand decrypted streams: the plaintext of a vault item is never written to disk.
 * A reader (WebView media request, PdfRenderer through a proxy file descriptor) asks for byte
 * ranges; the missing chunks are requested from JavaScript (which decrypts exactly those
 * chunks with the in-memory key) and kept in a small per-stream LRU. Sequential readers get a
 * short read-ahead so playback never waits on a chunk boundary.
 */
final class PvStreams {

    /** Emits a chunk request to JavaScript. Must not block. */
    interface Requester {
        void request(String token, int idx, String reqId);
    }

    static final Map<String, Stream> STREAMS = new ConcurrentHashMap<>();
    private static final Map<String, Pending> PENDING = new ConcurrentHashMap<>();
    private static final AtomicLong SEQ = new AtomicLong();
    private static final long WAIT_MS = 45_000;
    static volatile Requester requester;

    private static final class Pending {
        final Stream stream;
        final int idx;
        final CountDownLatch done = new CountDownLatch(1);
        volatile byte[] data;
        volatile boolean failed;

        Pending(Stream s, int idx) {
            this.stream = s;
            this.idx = idx;
        }
    }

    static final class Stream {
        final String token;
        final long size;
        final String mime;
        final int chunkSize;
        final int chunks;
        final int cacheMax;
        volatile boolean closed;
        private final LinkedHashMap<Integer, byte[]> cache = new LinkedHashMap<>(16, 0.75f, true);
        private final Map<Integer, Pending> inflight = new ConcurrentHashMap<>();

        Stream(String token, long size, String mime, int chunkSize, int chunks) {
            this.token = token;
            this.size = size;
            this.mime = mime;
            this.chunkSize = Math.max(1, chunkSize);
            this.chunks = chunks;
            // ~16 MB of plaintext at most per stream, never fewer than 3 chunks
            this.cacheMax = Math.max(3, (16 * 1024 * 1024) / this.chunkSize);
        }

        private byte[] cached(int idx) {
            synchronized (cache) {
                return cache.get(idx);
            }
        }

        private void put(int idx, byte[] b) {
            synchronized (cache) {
                cache.put(idx, b);
                while (cache.size() > cacheMax) {
                    Iterator<Integer> it = cache.keySet().iterator();
                    it.next();
                    it.remove();
                }
            }
        }

        /** Starts fetching a chunk if it is neither cached nor already requested. */
        private Pending ensure(int idx) {
            Pending p = inflight.get(idx);
            if (p != null) return p;
            synchronized (inflight) {
                p = inflight.get(idx);
                if (p != null) return p;
                p = new Pending(this, idx);
                inflight.put(idx, p);
            }
            String req = token + ":" + idx + ":" + SEQ.incrementAndGet();
            PENDING.put(req, p);
            Requester r = requester;
            if (r == null || closed) {
                PENDING.remove(req);
                finish(p, null);
            } else r.request(token, idx, req);
            return p;
        }

        private void finish(Pending p, byte[] data) {
            if (data != null) {
                p.data = data;
                put(p.idx, data);
            } else p.failed = true;
            inflight.remove(p.idx);
            p.done.countDown();
        }

        /** Blocking: returns chunk idx (plaintext) or throws. Never call on the plugin thread. */
        byte[] chunk(int idx, int readAhead) throws IOException {
            if (closed) throw new IOException("closed");
            if (idx < 0 || idx >= chunks) throw new IOException("range");
            for (int i = 1; i <= readAhead && idx + i < chunks; i++) if (cached(idx + i) == null) ensure(idx + i);
            byte[] hit = cached(idx);
            if (hit != null) return hit;
            Pending p = ensure(idx);
            try {
                if (!p.done.await(WAIT_MS, TimeUnit.MILLISECONDS)) throw new IOException("timeout");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("interrupted");
            }
            if (p.failed || p.data == null) throw new IOException("chunk failed");
            return p.data;
        }

        /** Random-access read, used by the PDF proxy descriptor. */
        int read(long offset, int len, byte[] out) throws IOException {
            if (offset >= size) return 0;
            int n = (int) Math.min(len, size - offset);
            int done = 0;
            while (done < n) {
                long pos = offset + done;
                int idx = (int) (pos / chunkSize);
                int within = (int) (pos - (long) idx * chunkSize);
                byte[] c = chunk(idx, 1);
                int take = Math.min(n - done, c.length - within);
                if (take <= 0) throw new IOException("short chunk");
                System.arraycopy(c, within, out, done, take);
                done += take;
            }
            return done;
        }

        void close() {
            closed = true;
            List<Pending> list = new ArrayList<>(inflight.values());
            for (Pending p : list) finish(p, null);
            synchronized (cache) {
                cache.clear();
            }
        }
    }

    static Stream open(String token, long size, String mime, int chunkSize, int chunks) {
        Stream s = new Stream(token, size, mime, chunkSize, chunks);
        Stream old = STREAMS.put(token, s);
        if (old != null) old.close();
        return s;
    }

    static void close(String token) {
        Stream s = STREAMS.remove(token);
        if (s != null) s.close();
        for (Iterator<Map.Entry<String, Pending>> it = PENDING.entrySet().iterator(); it.hasNext(); ) {
            if (it.next().getValue().stream == s) it.remove();
        }
    }

    static void closeAll() {
        for (Stream s : STREAMS.values()) s.close();
        STREAMS.clear();
        PENDING.clear();
    }

    /** Called with a decrypted chunk from JavaScript. Never blocks. */
    static void supply(String req, byte[] data) {
        Pending p = PENDING.remove(req);
        if (p == null || p.stream.closed) return;
        p.stream.finish(p, data);
    }

    static void fail(String req) {
        Pending p = PENDING.remove(req);
        if (p != null) p.stream.finish(p, null);
    }

    /** Sequential InputStream over [start, start+len) for the WebView. */
    static final class RangeInput extends InputStream {
        private final Stream s;
        private long pos;
        private long remaining;
        private byte[] cur;
        private int curIdx = -1;

        RangeInput(Stream s, long start, long len) {
            this.s = s;
            this.pos = start;
            this.remaining = len;
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];
            int r = read(one, 0, 1);
            return r <= 0 ? -1 : one[0] & 0xff;
        }

        @Override
        public int read(byte[] buf, int off, int n) throws IOException {
            if (remaining <= 0) return -1;
            int idx = (int) (pos / s.chunkSize);
            if (idx != curIdx) {
                cur = s.chunk(idx, 2);
                curIdx = idx;
            }
            int within = (int) (pos - (long) idx * s.chunkSize);
            int take = (int) Math.min(Math.min(n, remaining), cur.length - within);
            if (take <= 0) throw new IOException("short chunk");
            System.arraycopy(cur, within, buf, off, take);
            pos += take;
            remaining -= take;
            return take;
        }

        @Override
        public int available() {
            if (cur == null || remaining <= 0) return 0;
            int within = (int) (pos - (long) curIdx * s.chunkSize);
            return (int) Math.max(0, Math.min(remaining, cur.length - within));
        }

        @Override
        public void close() {
            cur = null;
        }
    }
}
