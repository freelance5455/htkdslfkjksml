package com.personalvault.app;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.pm.ActivityInfo;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ProxyFileDescriptorCallback;
import android.os.storage.StorageManager;
import android.provider.Settings;
import android.system.ErrnoException;
import android.system.OsConstants;
import androidx.activity.result.ActivityResult;
import androidx.core.view.WindowInsetsCompat;
import com.getcapacitor.annotation.ActivityCallback;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.content.FileProvider;
import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.drawable.IconCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Native side of Personal Vault.
 *  - Streaming export to Download/PersonalVault (MediaStore on Android 10+, never whole-file in RAM)
 *  - Launcher alias switch (vault / calculator disguise) and pinned shortcuts
 *  - FLAG_SECURE and system-bar colours
 *  - Private temporary plaintext copies for in-app preview/playback. They live only in the app's
 *    cache dir (not public storage, not backed up), are served to the WebView through random,
 *    revocable token URLs with HTTP Range support (PvWebViewClient), and are deleted on release,
 *    on lock and on every start.
 *  - "Open with": read-only FileProvider grant of a shared temp copy to an app chosen by the user
 *  - PDF page rendering with the platform PdfRenderer (no third-party library). Large PDFs are
 *    opened through a seekable proxy file descriptor over a decrypted-on-demand stream
 *    (Android 8+), so only the pages that are shown are ever read and decrypted.
 *  - On-demand decrypted streams for audio/video/images/PDF (PvStreams + PvWebViewClient)
 *  - Viewer helpers: orientation, immersive mode, keep-awake, window brightness
 *  - Uninstall protection through Device Admin (PvAdminReceiver)
 *
 * Threading: plugin methods run on Capacitor's plugin thread. Anything that can wait for a
 * stream chunk (PdfRenderer) runs on {@link #pdfExec}; streamSupply/streamFail never block, so a
 * chunk answer can always get through while a render is waiting for it.
 */
@CapacitorPlugin(
    name = "VaultNative",
    permissions = { @Permission(strings = { Manifest.permission.WRITE_EXTERNAL_STORAGE }, alias = "storage") }
)
public class VaultNativePlugin extends Plugin {

    static final String TEMP_DIR = "pv-preview";
    static final String SHARED_DIR = "shared";
    private static final long SHARED_MAX_AGE_MS = 10 * 60 * 1000L;

    /** A private temporary file. Also read by PvWebViewClient through its token. */
    static final class TempEntry {
        final String id;
        final File file;
        final boolean shared;
        final long created = System.currentTimeMillis();
        RandomAccessFile raf;
        volatile String mime = "application/octet-stream";
        volatile String token;

        TempEntry(String id, File file, boolean shared) {
            this.id = id;
            this.file = file;
            this.shared = shared;
        }
    }

    private static final class SaveSession {
        OutputStream out;
        Uri uri; // Android 10+
        File file; // Android 9 and below
        String name;
    }

    private static final class PdfSession {
        ParcelFileDescriptor fd;
        PdfRenderer renderer;
        String streamToken;
    }

    static final Map<String, TempEntry> TOKENS = new ConcurrentHashMap<>();
    private final Map<String, TempEntry> temps = new ConcurrentHashMap<>();
    private final Map<String, SaveSession> saves = new ConcurrentHashMap<>();
    private final Map<String, PdfSession> pdfs = new ConcurrentHashMap<>();
    private final SecureRandom rnd = new SecureRandom();
    private final ExecutorService pdfExec = Executors.newSingleThreadExecutor();
    private HandlerThread proxyThread;
    private Handler proxyHandler;

    @Override
    public void load() {
        PvStreams.requester = (token, idx, req) -> {
            JSObject o = new JSObject();
            o.put("token", token);
            o.put("idx", idx);
            o.put("req", req);
            notifyListeners("streamRequest", o);
        };
        // leftovers of a crash / force-stop never survive a new start
        deleteRecursive(tempRoot(), false);
        getActivity().runOnUiThread(() -> bridge.setWebViewClient(new PvWebViewClient(bridge)));
    }

    @Override
    protected void handleOnDestroy() {
        PvStreams.requester = null;
        PvStreams.closeAll();
        closeAllPdfs();
        pdfExec.shutdownNow();
        if (proxyThread != null) proxyThread.quitSafely();
        for (TempEntry e : temps.values()) releaseEntry(e);
        temps.clear();
        TOKENS.clear();
        super.handleOnDestroy();
    }

    // ------------------------------------------------------------ helpers

    private String randomId() {
        byte[] b = new byte[16];
        rnd.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private File tempRoot() {
        return new File(getContext().getCacheDir(), TEMP_DIR);
    }

    private static String safeName(String name, String fallback) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]+", "_").trim();
        if (n.isEmpty() || n.equals(".") || n.equals("..")) n = fallback;
        return n.length() > 120 ? n.substring(n.length() - 120) : n;
    }

    private static void deleteRecursive(File f, boolean self) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k, true);
        if (self) //noinspection ResultOfMethodCallIgnored
            f.delete();
    }

    private void releaseEntry(TempEntry e) {
        if (e.token != null) TOKENS.remove(e.token);
        synchronized (e) {
            if (e.raf != null) {
                try { e.raf.close(); } catch (IOException ignored) { }
                e.raf = null;
            }
        }
        //noinspection ResultOfMethodCallIgnored
        e.file.delete();
        if (e.shared) {
            File parent = e.file.getParentFile();
            if (parent != null) //noinspection ResultOfMethodCallIgnored
                parent.delete();
        }
    }

    private void purgeOldShared(long maxAgeMs) {
        long now = System.currentTimeMillis();
        for (Iterator<Map.Entry<String, TempEntry>> it = temps.entrySet().iterator(); it.hasNext(); ) {
            TempEntry e = it.next().getValue();
            if (e.shared && now - e.created > maxAgeMs) {
                releaseEntry(e);
                it.remove();
            }
        }
        File[] dirs = new File(tempRoot(), SHARED_DIR).listFiles();
        if (dirs != null) for (File d : dirs) if (now - d.lastModified() > maxAgeMs) deleteRecursive(d, true);
    }

    private void closeAllPdfs() {
        for (PdfSession s : pdfs.values()) closePdf(s);
        pdfs.clear();
    }

    private static void closePdf(PdfSession s) {
        synchronized (s) {
            try { s.renderer.close(); } catch (Exception ignored) { }
            try { s.fd.close(); } catch (Exception ignored) { }
        }
    }

    // ------------------------------------------------------------ export to Downloads

    @PluginMethod
    public void beginSave(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && getPermissionState("storage") != PermissionState.GRANTED) {
            requestPermissionForAlias("storage", call, "storagePermCallback");
            return;
        }
        doBeginSave(call);
    }

    @PermissionCallback
    private void storagePermCallback(PluginCall call) {
        if (getPermissionState("storage") == PermissionState.GRANTED) doBeginSave(call);
        else call.reject("STORAGE_PERMISSION_DENIED");
    }

    private void doBeginSave(PluginCall call) {
        String name = safeName(call.getString("name"), "file");
        String mime = call.getString("mime", "application/octet-stream");
        SaveSession s = new SaveSession();
        s.name = name;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver r = getContext().getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PersonalVault");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                s.uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (s.uri == null) throw new IOException("INSERT_FAILED");
                s.out = r.openOutputStream(s.uri, "w");
                if (s.out == null) throw new IOException("OPEN_FAILED");
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "PersonalVault");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("MKDIR_FAILED");
                File f = new File(dir, name);
                int dot = name.lastIndexOf('.');
                String base = dot > 0 ? name.substring(0, dot) : name;
                String ext = dot > 0 ? name.substring(dot) : "";
                for (int i = 1; f.exists(); i++) f = new File(dir, base + " (" + i + ")" + ext);
                s.file = f;
                s.name = f.getName();
                s.out = new FileOutputStream(f);
            }
            String id = randomId();
            saves.put(id, s);
            JSObject ret = new JSObject();
            ret.put("id", id);
            call.resolve(ret);
        } catch (Exception e) {
            abort(s);
            call.reject("SAVE_BEGIN_FAILED", e);
        }
    }

    @PluginMethod
    public void appendChunk(PluginCall call) {
        SaveSession s = saves.get(call.getString("id", ""));
        if (s == null) { call.reject("NO_SESSION"); return; }
        try {
            s.out.write(Base64.decode(call.getString("data", ""), Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject("WRITE_FAILED", e);
        }
    }

    @PluginMethod
    public void finishSave(PluginCall call) {
        SaveSession s = saves.remove(call.getString("id", ""));
        if (s == null) { call.reject("NO_SESSION"); return; }
        try {
            s.out.flush();
            s.out.close();
            if (s.uri != null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContext().getContentResolver().update(s.uri, v, null, null);
            }
            JSObject ret = new JSObject();
            ret.put("path", "Download/PersonalVault/" + s.name);
            call.resolve(ret);
        } catch (Exception e) {
            abort(s);
            call.reject("SAVE_FINISH_FAILED", e);
        }
    }

    @PluginMethod
    public void abortSave(PluginCall call) {
        SaveSession s = saves.remove(call.getString("id", ""));
        if (s != null) abort(s);
        call.resolve();
    }

    private void abort(SaveSession s) {
        try { if (s.out != null) s.out.close(); } catch (Exception ignored) { }
        try { if (s.uri != null) getContext().getContentResolver().delete(s.uri, null, null); } catch (Exception ignored) { }
        if (s.file != null) //noinspection ResultOfMethodCallIgnored
            s.file.delete();
    }

    // ------------------------------------------------------------ launcher & window

    @PluginMethod
    public void setLauncherAlias(PluginCall call) {
        boolean calc = "calculator".equals(call.getString("alias"));
        Context ctx = getContext();
        PackageManager pm = ctx.getPackageManager();
        String pkg = ctx.getPackageName();
        ComponentName vault = new ComponentName(pkg, pkg + ".LauncherVault");
        ComponentName calcAlias = new ComponentName(pkg, pkg + ".LauncherCalc");
        try {
            // enable the new entry first so the app never has zero launcher entries
            pm.setComponentEnabledSetting(calc ? calcAlias : vault, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            pm.setComponentEnabledSetting(calc ? vault : calcAlias, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            call.resolve();
        } catch (Exception e) {
            call.reject("ALIAS_FAILED", e);
        }
    }

    @PluginMethod
    public void getLauncherAlias(PluginCall call) {
        Context ctx = getContext();
        String pkg = ctx.getPackageName();
        int st = ctx.getPackageManager().getComponentEnabledSetting(new ComponentName(pkg, pkg + ".LauncherCalc"));
        JSObject ret = new JSObject();
        ret.put("alias", st == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ? "calculator" : "default");
        call.resolve(ret);
    }

    @PluginMethod
    public void pinShortcut(PluginCall call) {
        Context ctx = getContext();
        JSObject ret = new JSObject();
        try {
            if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
                ret.put("requested", false);
                call.resolve(ret);
                return;
            }
            byte[] png = Base64.decode(call.getString("icon", ""), Base64.DEFAULT);
            Bitmap bmp = BitmapFactory.decodeByteArray(png, 0, png.length);
            if (bmp == null) { call.reject("BAD_ICON"); return; }
            Intent launch = new Intent(ctx, MainActivity.class);
            launch.setAction(Intent.ACTION_MAIN);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            String label = call.getString("label", "Personal Vault");
            ShortcutInfoCompat info = new ShortcutInfoCompat.Builder(ctx, "pv-custom-" + System.currentTimeMillis())
                .setShortLabel(label)
                .setIcon(IconCompat.createWithBitmap(bmp))
                .setIntent(launch)
                .build();
            ret.put("requested", ShortcutManagerCompat.requestPinShortcut(ctx, info, null));
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("SHORTCUT_FAILED", e);
        }
    }

    @PluginMethod
    public void setSecure(PluginCall call) {
        boolean on = Boolean.TRUE.equals(call.getBoolean("enabled", true));
        getActivity().runOnUiThread(() -> {
            Window w = getActivity().getWindow();
            if (on) w.addFlags(WindowManager.LayoutParams.FLAG_SECURE);
            else w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            call.resolve();
        });
    }

    @PluginMethod
    public void setSystemBars(PluginCall call) {
        String color = call.getString("color", "#0c0e14");
        boolean light = Boolean.TRUE.equals(call.getBoolean("light", false));
        getActivity().runOnUiThread(() -> {
            try {
                Window w = getActivity().getWindow();
                int c = Color.parseColor(color);
                w.setStatusBarColor(c);
                w.setNavigationBarColor(c);
                WindowInsetsControllerCompat ic = WindowCompat.getInsetsController(w, w.getDecorView());
                ic.setAppearanceLightStatusBars(light);
                ic.setAppearanceLightNavigationBars(light);
                call.resolve();
            } catch (Exception e) {
                call.reject("BARS_FAILED", e);
            }
        });
    }

    // ------------------------------------------------------------ private temp files

    @PluginMethod
    public void tempBegin(PluginCall call) {
        boolean shared = Boolean.TRUE.equals(call.getBoolean("shared", false));
        String ext = call.getString("ext", "bin").replaceAll("[^A-Za-z0-9]", "");
        if (ext.isEmpty()) ext = "bin";
        String id = randomId();
        try {
            File dir;
            File f;
            if (shared) {
                purgeOldShared(SHARED_MAX_AGE_MS);
                dir = new File(new File(tempRoot(), SHARED_DIR), randomId());
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("MKDIR_FAILED");
                f = new File(dir, safeName(call.getString("name"), "file." + ext));
            } else {
                dir = tempRoot();
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("MKDIR_FAILED");
                f = new File(dir, id + "." + ext);
            }
            TempEntry e = new TempEntry(id, f, shared);
            e.raf = new RandomAccessFile(f, "rw");
            e.raf.setLength(0);
            temps.put(id, e);
            JSObject ret = new JSObject();
            ret.put("id", id);
            call.resolve(ret);
        } catch (Exception ex) {
            call.reject("TEMP_BEGIN_FAILED", ex);
        }
    }

    @PluginMethod
    public void tempAppend(PluginCall call) {
        TempEntry e = temps.get(call.getString("id", ""));
        if (e == null) { call.reject("NO_TEMP"); return; }
        try {
            byte[] data = Base64.decode(call.getString("data", ""), Base64.DEFAULT);
            long offset = call.getData().optLong("offset", -1);
            synchronized (e) {
                if (e.raf == null) throw new IOException("CLOSED");
                e.raf.seek(offset >= 0 ? offset : e.raf.length());
                e.raf.write(data);
            }
            call.resolve();
        } catch (Exception ex) {
            call.reject("TEMP_WRITE_FAILED", ex);
        }
    }

    @PluginMethod
    public void tempFinish(PluginCall call) {
        TempEntry e = temps.get(call.getString("id", ""));
        if (e == null) { call.reject("NO_TEMP"); return; }
        try {
            synchronized (e) {
                if (e.raf != null) {
                    e.raf.getFD().sync();
                    e.raf.close();
                    e.raf = null;
                }
            }
            e.mime = call.getString("mime", "application/octet-stream");
            e.token = randomId() + randomId();
            TOKENS.put(e.token, e);
            JSObject ret = new JSObject();
            ret.put("url", bridge.getLocalUrl() + PvWebViewClient.PREFIX + e.token);
            call.resolve(ret);
        } catch (Exception ex) {
            call.reject("TEMP_FINISH_FAILED", ex);
        }
    }

    @PluginMethod
    public void tempRelease(PluginCall call) {
        TempEntry e = temps.remove(call.getString("id", ""));
        if (e != null) releaseEntry(e);
        call.resolve();
    }

    @PluginMethod
    public void tempClear(PluginCall call) {
        long keep = call.getData().optLong("keepSharedMs", 0);
        closeAllPdfs();
        for (Iterator<Map.Entry<String, TempEntry>> it = temps.entrySet().iterator(); it.hasNext(); ) {
            TempEntry e = it.next().getValue();
            if (!e.shared || keep <= 0) {
                releaseEntry(e);
                it.remove();
            } else if (e.token != null) {
                TOKENS.remove(e.token); // the WebView can no longer read it; the other app still can
                e.token = null;
            }
        }
        if (keep > 0) purgeOldShared(keep);
        File[] files = tempRoot().listFiles();
        if (files != null) for (File f : files) {
            if (f.getName().equals(SHARED_DIR) && keep > 0) continue;
            boolean tracked = false;
            for (TempEntry e : temps.values()) if (e.file.equals(f)) { tracked = true; break; }
            if (!tracked) deleteRecursive(f, true);
        }
        call.resolve();
    }

    @PluginMethod
    public void openExternal(PluginCall call) {
        TempEntry e = temps.get(call.getString("id", ""));
        if (e == null || !e.shared) { call.reject("NO_TEMP"); return; }
        String mime = call.getString("mime", "application/octet-stream");
        String title = call.getString("title", "");
        try {
            Context ctx = getContext();
            Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", e.file);
            Intent view = new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri, mime);
            view.setClipData(ClipData.newRawUri(title, uri));
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            JSObject ret = new JSObject();
            if (ctx.getPackageManager().queryIntentActivities(view, 0).isEmpty()) {
                // nothing handles the exact type: let the user pick any viewer
                view.setDataAndType(uri, "*/*");
                if (ctx.getPackageManager().queryIntentActivities(view, 0).isEmpty()) {
                    ret.put("opened", false);
                    call.resolve(ret);
                    return;
                }
            }
            Intent chooser = Intent.createChooser(view, title);
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            ret.put("opened", true);
            call.resolve(ret);
        } catch (ActivityNotFoundException ex) {
            JSObject ret = new JSObject();
            ret.put("opened", false);
            call.resolve(ret);
        } catch (Exception ex) {
            call.reject("OPEN_FAILED", ex);
        }
    }

    // ------------------------------------------------------------ PDF

    @PluginMethod
    public void pdfOpen(PluginCall call) {
        TempEntry e = temps.get(call.getString("id", ""));
        if (e == null) { call.reject("NO_TEMP"); return; }
        pdfExec.execute(() -> {
            PdfSession s = new PdfSession();
            try {
                s.fd = ParcelFileDescriptor.open(e.file, ParcelFileDescriptor.MODE_READ_ONLY);
                s.renderer = new PdfRenderer(s.fd);
                int[] wh = firstPage(s.renderer);
                JSObject first = new JSObject();
                first.put("w", wh[0]);
                first.put("h", wh[1]);
                String handle = randomId();
                pdfs.put(handle, s);
                JSArray pages = new JSArray();
                pages.put(first);
                JSObject ret = new JSObject();
                ret.put("handle", handle);
                ret.put("count", s.renderer.getPageCount());
                ret.put("pages", pages); // only page 1; other sizes are read lazily (pdfPageSize)
                call.resolve(ret);
            } catch (Exception ex) {
                if (s.fd != null) try { s.fd.close(); } catch (IOException ignored) { }
                call.reject("PDF_OPEN_FAILED", ex);
            }
        });
    }

    private static int[] firstPage(PdfRenderer r) {
        if (r.getPageCount() == 0) return new int[] { 612, 792 };
        PdfRenderer.Page p = r.openPage(0);
        int[] wh = { p.getWidth(), p.getHeight() };
        p.close();
        return wh;
    }

    private synchronized Handler proxyHandler() {
        if (proxyHandler == null) {
            proxyThread = new HandlerThread("pv-pdf-proxy");
            proxyThread.start();
            proxyHandler = new Handler(proxyThread.getLooper());
        }
        return proxyHandler;
    }

    /** Opens a PDF straight from an encrypted stream: PdfRenderer reads through a proxy fd. */
    @PluginMethod
    public void pdfOpenStream(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) { call.reject("UNSUPPORTED"); return; }
        String token = call.getString("token", "");
        PvStreams.Stream st = PvStreams.STREAMS.get(token);
        if (st == null) { call.reject("NO_STREAM"); return; }
        Handler handler = proxyHandler();
        pdfExec.execute(() -> {
            PdfSession s = new PdfSession();
            s.streamToken = token;
            try {
                StorageManager sm = (StorageManager) getContext().getSystemService(Context.STORAGE_SERVICE);
                s.fd = sm.openProxyFileDescriptor(ParcelFileDescriptor.MODE_READ_ONLY, new ProxyFileDescriptorCallback() {
                    @Override
                    public long onGetSize() {
                        return st.size;
                    }

                    @Override
                    public int onRead(long offset, int size, byte[] data) throws ErrnoException {
                        try {
                            return st.read(offset, size, data);
                        } catch (IOException ex) {
                            throw new ErrnoException("onRead", OsConstants.EIO);
                        }
                    }

                    @Override
                    public void onRelease() { }
                }, handler);
                s.renderer = new PdfRenderer(s.fd);
                int[] wh = firstPage(s.renderer);
                String handle = randomId();
                pdfs.put(handle, s);
                JSObject ret = new JSObject();
                ret.put("handle", handle);
                ret.put("count", s.renderer.getPageCount());
                ret.put("w", wh[0]);
                ret.put("h", wh[1]);
                call.resolve(ret);
            } catch (Exception ex) {
                if (s.fd != null) try { s.fd.close(); } catch (IOException ignored) { }
                call.reject("PDF_OPEN_FAILED", ex);
            }
        });
    }

    @PluginMethod
    public void pdfPageSize(PluginCall call) {
        PdfSession s = pdfs.get(call.getString("handle", ""));
        if (s == null) { call.reject("NO_PDF"); return; }
        int index = call.getInt("index", 0);
        pdfExec.execute(() -> {
            synchronized (s) {
                try {
                    PdfRenderer.Page p = s.renderer.openPage(index);
                    JSObject o = new JSObject();
                    o.put("w", p.getWidth());
                    o.put("h", p.getHeight());
                    p.close();
                    call.resolve(o);
                } catch (Exception ex) {
                    call.reject("PDF_PAGE_FAILED", ex);
                }
            }
        });
    }

    @PluginMethod
    public void pdfRender(PluginCall call) {
        PdfSession s = pdfs.get(call.getString("handle", ""));
        if (s == null) { call.reject("NO_PDF"); return; }
        int index = call.getInt("index", 0);
        int width = Math.max(64, Math.min(2400, call.getInt("width", 1080)));
        pdfExec.execute(() -> {
            synchronized (s) {
                Bitmap bmp = null;
                try {
                    PdfRenderer.Page p = s.renderer.openPage(index);
                    int h = Math.max(1, Math.round(width * (p.getHeight() / (float) p.getWidth())));
                    // keep a single page bitmap bounded (~24 MB) even for very tall pages
                    int w = width;
                    long px = (long) w * h;
                    if (px > 6_000_000L) {
                        double k = Math.sqrt(6_000_000.0 / px);
                        w = Math.max(64, (int) (w * k));
                        h = Math.max(1, (int) (h * k));
                    }
                    bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    bmp.eraseColor(Color.WHITE);
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    p.close();
                    ByteArrayOutputStream out = new ByteArrayOutputStream(w * h / 4);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 86, out);
                    JSObject ret = new JSObject();
                    ret.put("data", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
                    ret.put("w", w);
                    ret.put("h", h);
                    call.resolve(ret);
                } catch (Exception ex) {
                    call.reject("PDF_RENDER_FAILED", ex);
                } finally {
                    if (bmp != null) bmp.recycle();
                }
            }
        });
    }

    @PluginMethod
    public void pdfClose(PluginCall call) {
        PdfSession s = pdfs.remove(call.getString("handle", ""));
        if (s != null) pdfExec.execute(() -> closePdf(s));
        call.resolve();
    }

    // ------------------------------------------------------------ decrypted streams

    @PluginMethod
    public void streamOpen(PluginCall call) {
        String token = call.getString("token", "");
        if (token.length() < 16) { call.reject("BAD_TOKEN"); return; }
        long size = call.getData().optLong("size", 0);
        int chunkSize = call.getInt("chunkSize", 512 * 1024);
        int chunks = call.getInt("chunks", 0);
        String mime = call.getString("mime", "application/octet-stream");
        PvStreams.open(token, size, mime, chunkSize, chunks);
        JSObject ret = new JSObject();
        ret.put("url", bridge.getLocalUrl() + PvWebViewClient.STREAM_PREFIX + token);
        call.resolve(ret);
    }

    @PluginMethod
    public void streamSupply(PluginCall call) {
        String req = call.getString("req", "");
        String data = call.getString("data", "");
        try {
            PvStreams.supply(req, Base64.decode(data, Base64.NO_WRAP));
        } catch (IllegalArgumentException ex) {
            PvStreams.fail(req);
        }
        call.resolve();
    }

    @PluginMethod
    public void streamFail(PluginCall call) {
        PvStreams.fail(call.getString("req", ""));
        call.resolve();
    }

    @PluginMethod
    public void streamClose(PluginCall call) {
        String token = call.getString("token", "");
        // a PDF reading this stream is closed first so its proxy fd never waits on a dead stream
        for (Iterator<Map.Entry<String, PdfSession>> it = pdfs.entrySet().iterator(); it.hasNext(); ) {
            PdfSession s = it.next().getValue();
            if (token.equals(s.streamToken)) {
                it.remove();
                pdfExec.execute(() -> closePdf(s));
            }
        }
        PvStreams.close(token);
        call.resolve();
    }

    @PluginMethod
    public void streamCloseAll(PluginCall call) {
        PvStreams.closeAll();
        for (PdfSession s : pdfs.values()) if (s.streamToken != null) pdfExec.execute(() -> closePdf(s));
        pdfs.values().removeIf(s -> s.streamToken != null);
        call.resolve();
    }

    // ------------------------------------------------------------ viewer helpers

    @PluginMethod
    public void setOrientation(PluginCall call) {
        String mode = call.getString("mode", "auto");
        Activity a = getActivity();
        a.runOnUiThread(() -> {
            if ("landscape".equals(mode)) a.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            else if ("portrait".equals(mode)) a.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            else a.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            call.resolve();
        });
    }

    @PluginMethod
    public void setImmersive(PluginCall call) {
        boolean on = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        Activity a = getActivity();
        a.runOnUiThread(() -> {
            Window w = a.getWindow();
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
            if (on) {
                c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsetsCompat.Type.systemBars());
            } else c.show(WindowInsetsCompat.Type.systemBars());
            call.resolve();
        });
    }

    @PluginMethod
    public void setKeepAwake(PluginCall call) {
        boolean on = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        Activity a = getActivity();
        a.runOnUiThread(() -> {
            if (on) a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else a.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            call.resolve();
        });
    }

    /** Current brightness 0..1 (window override, or the system level as a starting point). */
    @PluginMethod
    public void getBrightness(PluginCall call) {
        Activity a = getActivity();
        a.runOnUiThread(() -> {
            float v = a.getWindow().getAttributes().screenBrightness;
            if (v < 0) {
                try {
                    v = Settings.System.getInt(a.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS) / 255f;
                } catch (Settings.SettingNotFoundException ex) {
                    v = 0.5f;
                }
            }
            JSObject o = new JSObject();
            o.put("value", Math.max(0f, Math.min(1f, v)));
            call.resolve(o);
        });
    }

    /** Window-only brightness (no system permission needed); value < 0 restores the system level. */
    @PluginMethod
    public void setBrightness(PluginCall call) {
        double value = call.getData().optDouble("value", -1);
        Activity a = getActivity();
        a.runOnUiThread(() -> {
            WindowManager.LayoutParams lp = a.getWindow().getAttributes();
            lp.screenBrightness = value < 0 ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : (float) Math.max(0.01, Math.min(1.0, value));
            a.getWindow().setAttributes(lp);
            call.resolve();
        });
    }

    // ------------------------------------------------------------ uninstall protection

    private DevicePolicyManager dpm() {
        return (DevicePolicyManager) getContext().getSystemService(Context.DEVICE_POLICY_SERVICE);
    }

    private boolean adminActive() {
        DevicePolicyManager d = dpm();
        return d != null && d.isAdminActive(PvAdminReceiver.component(getContext()));
    }

    @PluginMethod
    public void adminStatus(PluginCall call) {
        JSObject o = new JSObject();
        o.put("active", adminActive());
        o.put("supported", getContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN));
        call.resolve(o);
    }

    @PluginMethod
    public void adminEnable(PluginCall call) {
        if (adminActive()) {
            JSObject o = new JSObject();
            o.put("active", true);
            call.resolve(o);
            return;
        }
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, PvAdminReceiver.component(getContext()));
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, call.getString("explanation", ""));
        try {
            startActivityForResult(call, i, "adminResult");
        } catch (ActivityNotFoundException ex) {
            call.reject("UNSUPPORTED");
        }
    }

    @ActivityCallback
    private void adminResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSObject o = new JSObject();
        o.put("active", adminActive());
        call.resolve(o);
    }

    /** Called only after the vault password was verified in JavaScript. */
    @PluginMethod
    public void adminDisable(PluginCall call) {
        DevicePolicyManager d = dpm();
        if (d != null && adminActive()) d.removeActiveAdmin(PvAdminReceiver.component(getContext()));
        JSObject o = new JSObject();
        o.put("active", false);
        call.resolve(o);
    }
}
