package com.personalvault.app;

import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeWebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.HashMap;
import java.util.Map;

/**
 * Serves private preview files to the WebView at  <localUrl>/_pv_media/<token>  with full
 * HTTP Range support (long offsets, so multi-GB videos can seek). Only files registered by
 * VaultNativePlugin.tempFinish() are reachable, and a token dies when the file is released.
 * Everything else is handled by Capacitor as usual.
 */
public class PvWebViewClient extends BridgeWebViewClient {
    static final String PREFIX = "/_pv_media/";
    static final String STREAM_PREFIX = "/_pv_stream/";

    public PvWebViewClient(Bridge bridge) {
        super(bridge);
    }

    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        Uri url = request.getUrl();
        String path = url.getPath();
        if (path != null && path.startsWith(STREAM_PREFIX)) {
            PvStreams.Stream st = PvStreams.STREAMS.get(path.substring(STREAM_PREFIX.length()));
            if (st == null || st.closed) return status(404, "Not Found");
            return serveStream(st, header(request.getRequestHeaders(), "Range"));
        }
        if (path != null && path.startsWith(PREFIX)) {
            VaultNativePlugin.TempEntry e = VaultNativePlugin.TOKENS.get(path.substring(PREFIX.length()));
            if (e == null || !e.file.exists()) return status(404, "Not Found");
            try {
                return serve(e, header(request.getRequestHeaders(), "Range"));
            } catch (IOException ex) {
                return status(500, "Server Error");
            }
        }
        return super.shouldInterceptRequest(view, request);
    }

    private static String header(Map<String, String> h, String name) {
        if (h == null) return null;
        for (Map.Entry<String, String> x : h.entrySet()) if (x.getKey() != null && x.getKey().equalsIgnoreCase(name)) return x.getValue();
        return null;
    }

    private static WebResourceResponse status(int code, String reason) {
        return new WebResourceResponse("text/plain", "utf-8", code, reason, new HashMap<>(), new ByteArrayInputStream(new byte[0]));
    }

    private static WebResourceResponse serve(VaultNativePlugin.TempEntry e, String range) throws IOException {
        long total = e.file.length();
        long start = 0;
        long end = total - 1;
        boolean partial = false;
        if (range != null && range.startsWith("bytes=")) {
            String spec = range.substring(6).split(",")[0].trim();
            int dash = spec.indexOf('-');
            try {
                if (dash == 0) { // suffix: last N bytes
                    long n = Long.parseLong(spec.substring(1));
                    start = Math.max(0, total - n);
                } else if (dash > 0) {
                    start = Long.parseLong(spec.substring(0, dash));
                    if (dash < spec.length() - 1) end = Math.min(total - 1, Long.parseLong(spec.substring(dash + 1)));
                }
                partial = true;
            } catch (NumberFormatException ignored) {
                start = 0;
                end = total - 1;
            }
            if (start >= total || start > end) {
                Map<String, String> h = new HashMap<>();
                h.put("Content-Range", "bytes */" + total);
                return new WebResourceResponse(e.mime, null, 416, "Range Not Satisfiable", h, new ByteArrayInputStream(new byte[0]));
            }
        }
        long len = Math.max(0, end - start + 1);
        RandomAccessFile raf = new RandomAccessFile(e.file, "r");
        raf.seek(start);
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Content-Length", String.valueOf(len));
        h.put("Cache-Control", "no-store");
        if (partial) h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
        return new WebResourceResponse(e.mime, null, partial ? 206 : 200, partial ? "Partial Content" : "OK", h, new RangeStream(raf, len));
    }

    /** [start, end] of a Range header, or null for "whole file"; {-1,-1} when unsatisfiable. */
    private static long[] parseRange(String range, long total) {
        if (range == null || !range.startsWith("bytes=")) return null;
        long start = 0, end = total - 1;
        String spec = range.substring(6).split(",")[0].trim();
        int dash = spec.indexOf('-');
        try {
            if (dash == 0) start = Math.max(0, total - Long.parseLong(spec.substring(1)));
            else if (dash > 0) {
                start = Long.parseLong(spec.substring(0, dash));
                if (dash < spec.length() - 1) end = Math.min(total - 1, Long.parseLong(spec.substring(dash + 1)));
            } else return null;
        } catch (NumberFormatException e) {
            return null;
        }
        if (start >= total || start > end) return new long[] { -1, -1 };
        return new long[] { start, end };
    }

    /**
     * Decrypted-on-demand stream: only the chunks covering the requested range are decrypted
     * (in JavaScript, with the in-memory key) and nothing touches the disk. Responses are capped
     * so a player that asks for "bytes=0-" does not pull the whole file before it can seek.
     */
    private static WebResourceResponse serveStream(PvStreams.Stream st, String range) {
        long total = st.size;
        long[] r = parseRange(range, total);
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Cache-Control", "no-store");
        if (r != null && r[0] < 0) {
            h.put("Content-Range", "bytes */" + total);
            return new WebResourceResponse(st.mime, null, 416, "Range Not Satisfiable", h, new ByteArrayInputStream(new byte[0]));
        }
        long start = r == null ? 0 : r[0];
        long end = r == null ? total - 1 : r[1];
        boolean partial = r != null;
        if (partial) {
            long cap = Math.max(4L * st.chunkSize, 8L * 1024 * 1024);
            end = Math.min(end, start + cap - 1);
            h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
        }
        long len = Math.max(0, end - start + 1);
        h.put("Content-Length", String.valueOf(len));
        return new WebResourceResponse(st.mime, null, partial ? 206 : 200, partial ? "Partial Content" : "OK", h, new PvStreams.RangeInput(st, start, len));
    }

    /** Streams exactly `remaining` bytes from the current position, closing the file at the end. */
    private static final class RangeStream extends InputStream {
        private final RandomAccessFile raf;
        private long remaining;

        RangeStream(RandomAccessFile raf, long remaining) {
            this.raf = raf;
            this.remaining = remaining;
        }

        @Override
        public int read() throws IOException {
            if (remaining <= 0) return -1;
            int b = raf.read();
            if (b >= 0) remaining--;
            return b;
        }

        @Override
        public int read(byte[] buf, int off, int n) throws IOException {
            if (remaining <= 0) return -1;
            int r = raf.read(buf, off, (int) Math.min(n, remaining));
            if (r > 0) remaining -= r;
            return r;
        }

        @Override
        public int available() {
            return (int) Math.min(Integer.MAX_VALUE, remaining);
        }

        @Override
        public void close() throws IOException {
            raf.close();
        }
    }
}
