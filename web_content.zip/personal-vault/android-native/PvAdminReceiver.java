package com.personalvault.app;

import android.app.KeyguardManager;
import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Uninstall protection ("\u0645\u062d\u0627\u0641\u0638\u062a \u062f\u0631 \u0628\u0631\u0627\u0628\u0631 \u062d\u0630\u0641 \u0628\u0631\u0646\u0627\u0645\u0647").
 * While this receiver is an active device administrator, Android does not let the app be
 * uninstalled: the system first asks for the administrator to be deactivated.
 *  - Inside the app, deactivation requires the vault password (VaultNativePlugin.adminDisable).
 *  - From system Settings, a deactivation request immediately locks the phone, so the device
 *    PIN / pattern / biometric is needed before the confirmation can be accepted.
 */
public class PvAdminReceiver extends DeviceAdminReceiver {

    static ComponentName component(Context ctx) {
        return new ComponentName(ctx.getApplicationContext(), PvAdminReceiver.class);
    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        try {
            KeyguardManager km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
            boolean secure = km != null && (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? km.isDeviceSecure() : km.isKeyguardSecure());
            DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (secure && dpm != null && dpm.isAdminActive(component(context))) dpm.lockNow();
        } catch (SecurityException ignored) {
            // policy not granted: nothing to do, the warning below is still shown
        }
        return "\u0628\u0627 \u063a\u06cc\u0631\u0641\u0639\u0627\u0644 \u06a9\u0631\u062f\u0646 \u0627\u06cc\u0646 \u06af\u0632\u06cc\u0646\u0647\u060c \u0645\u062d\u0627\u0641\u0638\u062a Personal Vault \u062f\u0631 \u0628\u0631\u0627\u0628\u0631 \u062d\u0630\u0641 \u0628\u0631\u062f\u0627\u0634\u062a\u0647 \u0645\u06cc\u200c\u0634\u0648\u062f.";
    }
}
