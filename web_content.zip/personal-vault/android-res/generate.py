"""Regenerates the launcher icon resources (vault + calculator disguise) from one geometry.
   Run: python3 android-res/generate.py   (needs cairosvg). Output: android-res/res/"""
import os, math, cairosvg
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'res')
EM, AMBER = '#10B981', '#F59E0B'

def rrect(x, y, w, h, r):
    return f"M{x+r},{y} H{x+w-r} A{r},{r} 0 0 1 {x+w},{y+r} V{y+h-r} A{r},{r} 0 0 1 {x+w-r},{y+h} H{x+r} A{r},{r} 0 0 1 {x},{y+h-r} V{y+r} A{r},{r} 0 0 1 {x+r},{y} Z"
def circle(cx, cy, r):
    return f"M{cx-r},{cy} A{r},{r} 0 1 0 {cx+r},{cy} A{r},{r} 0 1 0 {cx-r},{cy} Z"

# glyph layers on the 64-unit grid: (pathData, fill, fillAlpha, stroke, strokeWidth)
VAULT = [
    (rrect(14, 15, 36, 34, 9), EM, 0.12, EM, 3.2),
    (circle(35, 32, 8.5), None, 0, EM, 3.2),
    ("M35,21.5 V24 M35,40 V42.5 M24.5,32 H27 M43,32 H45.5", None, 0, EM, 2.6),
    ("M21,26 V38", None, 0, EM, 3.2),
    (circle(35, 32, 2.6), EM, 1, None, 0),
]
CALC = [
    (rrect(14, 14, 16, 16, 5), '#2C3445', 1, None, 0),
    (rrect(34, 14, 16, 16, 5), '#2C3445', 1, None, 0),
    (rrect(14, 34, 16, 16, 5), '#2C3445', 1, None, 0),
    (rrect(34, 34, 16, 16, 5), AMBER, 1, None, 0),
    ("M22,18.5 V25.5 M18.5,22 H25.5 M38.5,22 H45.5 M19,39 L25,45 M25,39 L19,45", None, 0, '#E8EBF2', 2.8),
    ("M38.5,40 H45.5 M38.5,44.5 H45.5", None, 0, '#1A1204', 2.8),
]

def svg(layers, shape='squircle', size=64):
    clip = f'<rect width="64" height="64" rx="18"/>' if shape == 'squircle' else '<circle cx="32" cy="32" r="32"/>'
    body = ''.join(
        f'<path d="{d}" fill="{f or "none"}" fill-opacity="{fa}" stroke="{s or "none"}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"/>'
        for d, f, fa, s, sw in layers)
    glow = '<radialGradient id="gw" cx="0.5" cy="0.45" r="0.55"><stop offset="0" stop-color="#10B981" stop-opacity="0.32"/><stop offset="1" stop-color="#10B981" stop-opacity="0"/></radialGradient>' if layers is VAULT else ''
    glowRect = '<rect width="64" height="64" fill="url(#gw)"/>' if layers is VAULT else ''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 64 64"><defs><clipPath id="c">{clip}</clipPath>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1D2433"/><stop offset="1" stop-color="#0B0E15"/></linearGradient>
<linearGradient id="gl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0.16"/><stop offset="0.5" stop-color="#fff" stop-opacity="0"/></linearGradient>{glow}</defs>
<g clip-path="url(#c)"><rect width="64" height="64" fill="url(#bg)"/>{glowRect}<rect width="64" height="64" fill="url(#gl)"/></g>{body}</svg>'''

def vector_fg(layers):
    paths = []
    for d, f, fa, s, sw in layers:
        a = [f'android:pathData="{d}"']
        if f: a.append(f'android:fillColor="{f}"'); a.append(f'android:fillAlpha="{fa}"')
        if s: a += [f'android:strokeColor="{s}"', f'android:strokeWidth="{sw}"', 'android:strokeLineCap="round"', 'android:strokeLineJoin="round"']
        paths.append('        <path ' + ' '.join(a) + ' />')
    # glyph box 14..50 scaled x1.25 and centred on 54 (inside the 66dp adaptive safe zone)
    return ('<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android"\n    android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">\n'
            '    <group android:scaleX="1.25" android:scaleY="1.25" android:translateX="14" android:translateY="14">\n' + '\n'.join(paths) + '\n    </group>\n</vector>\n')

BG = '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android" xmlns:aapt="http://schemas.android.com/aapt"
    android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:pathData="M0,0h108v108h-108z">
        <aapt:attr name="android:fillColor">
            <gradient android:type="linear" android:startX="0" android:startY="0" android:endX="108" android:endY="108"
                android:startColor="#1D2433" android:endColor="#0B0E15" />
        </aapt:attr>
    </path>
</vector>
'''
ADAPTIVE = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/pv_icon_bg" />
    <foreground android:drawable="@drawable/{fg}" />
    <monochrome android:drawable="@drawable/{fg}" />
</adaptive-icon>
'''
def w(p, s, mode='w'):
    p = os.path.join(OUT, p); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, mode).write(s)

w('drawable/pv_icon_bg.xml', BG)
w('drawable/pv_vault_fg.xml', vector_fg(VAULT))
w('drawable/pv_calc_fg.xml', vector_fg(CALC))
for name, fg in [('ic_launcher', 'pv_vault_fg'), ('ic_launcher_round', 'pv_vault_fg'), ('ic_launcher_calc', 'pv_calc_fg'), ('ic_launcher_calc_round', 'pv_calc_fg')]:
    w(f'mipmap-anydpi-v26/{name}.xml', ADAPTIVE.format(fg=fg))
for dpi, px in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
    for name, layers, shape in [('ic_launcher', VAULT, 'squircle'), ('ic_launcher_round', VAULT, 'circle'), ('ic_launcher_calc', CALC, 'squircle'), ('ic_launcher_calc_round', CALC, 'circle')]:
        p = os.path.join(OUT, f'mipmap-{dpi}', f'{name}.png'); os.makedirs(os.path.dirname(p), exist_ok=True)
        cairosvg.svg2png(bytestring=svg(layers, shape).encode(), write_to=p, output_width=px, output_height=px)
w('xml/file_paths.xml', '''<?xml version="1.0" encoding="utf-8"?>
<!-- Only the temporary "open with" copies are shareable; nothing else of the app is exposed. -->
<paths>
    <cache-path name="pv_shared" path="pv-preview/shared/" />
</paths>
''')
open(os.path.join(HERE, 'icon-vault.svg'), 'w').write(svg(VAULT, size=512))
open(os.path.join(HERE, 'icon-calculator.svg'), 'w').write(svg(CALC, size=512))
cairosvg.svg2png(bytestring=svg(VAULT, size=512).encode(), write_to=os.path.join(HERE, 'icon-vault-512.png'))
cairosvg.svg2png(bytestring=svg(CALC, size=512).encode(), write_to=os.path.join(HERE, 'icon-calculator-512.png'))
print('icons generated')
