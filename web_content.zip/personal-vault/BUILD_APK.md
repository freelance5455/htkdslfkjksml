# Personal Vault 2.1: building the APK

## Requirements
- Node.js 18+ and npm
- Android Studio (Android SDK, API 34 recommended) with `ANDROID_HOME` set
- JDK 17 (bundled with Android Studio)
- Python 3 + `cairosvg`: only needed to regenerate icons (`npm run android:icons`); the generated files are already included

## One-command build
```bash
npm install
npm run android:apk              # debug APK   -> dist-apk/app-debug.apk
npm run android:apk -- --release # release APK -> dist-apk/app-release(-unsigned).apk
```
`build-apk.mjs` does everything in order: `vite build` → `npx cap add android` (first time only) → `npx cap sync android` → `scripts/patch-android.mjs` → Gradle.

## What the patch step adds to `android/`
- `VaultNativePlugin.java` + `PvWebViewClient.java` (from `android-native/`), registered in `MainActivity`
- Launcher entries `.LauncherVault` / `.LauncherCalc` (activity-alias) with the new icons from `android-res/res`
- FileProvider limited to `cache/pv-preview/shared/` (temporary "open with" copies only)
- `<queries>` for ACTION_VIEW, `allowBackup=false`, `WRITE_EXTERNAL_STORAGE` only for Android 9 and below
The script can be re-run safely (it is idempotent). After every `npx cap sync android`, run `npm run android:patch` again (or just use `npm run android:sync`).

## Release signing (optional)
Create `keystore/keystore.properties` (the `keystore/` folder is git-ignored):
```
storeFile=release.jks
storePassword=...
keyAlias=...
keyPassword=...
```
and put `release.jks` in the same folder. The patch step picks it up automatically.

## Opening in Android Studio
```bash
npm run android:sync
npx cap open android
```

## Troubleshooting
- **"android/ not found"**: run `npm run android:add` once.
- **Gradle fails after a Capacitor update**: delete `android/`, then run `npm run android:apk` again (everything is regenerated and re-patched).
- **Logs**: `adb logcat | grep -i -E "Capacitor|VaultNative"`
