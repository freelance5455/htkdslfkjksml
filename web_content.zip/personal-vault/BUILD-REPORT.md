# 📦 گزارش کامل ساخت APK — Personal Vault 2.1.0

تاریخ ساخت: 2026-09-30 · محیط: Linux x64 · Node 20.20.2 · JDK 17 (Temurin) · Android SDK 34 · Gradle 8.2.1 · AGP 8.2.x

---

## ✅ خروجی‌های نهایی (در پوشه `dist-apk/`)

| فایل | نوع | حجم | SHA-256 |
|---|---|---|---|
| **`Personal-Vault-2.1.0-release.apk`** ⭐ | Release — امضاشده، قابل نصب | 3,516,332 بایت | `e9fe5af2ac7edacc0d28bdd988598183fc10f7671e805654c8b30a5cf76b301e` |
| `Personal-Vault-2.1.0-debug.apk` | Debug — امضاشده با کلید debug، قابل نصب | 4,329,478 بایت | `cadf09b71d16eeb5b989f935874b5e161ff448934ca5191538ad6e6824750a19` |

**هر دو مستقیماً روی گوشی اندروید قابل نصب هستند** (Android 5.1 به بالا — minSdk 22).

## 🔧 زنجیره build (دقیقاً طبق `BUILD_APK.md` خود پروژه)

```
npm install
npm run build                    ← tsc --noEmit && vite build
npx cap add android              ← تولید پروژه اندروید Capacitor
npx cap sync android             ← کپی خروجی وب (dist) + capacitor.config.json
node scripts/patch-android.mjs   ← پلاگین native، لانچرها، FileProvider، سخت‌سازی مانیفست، امضای release
./gradlew assembleDebug / assembleRelease
```

## 🩹 دو اصلاح جزئی که برای موفقیت build لازم شد (بدون تغییر رفتار برنامه)

1. **`package.json`** — نسخه `@types/react` از `^18.3.12` به `18.3.12` و `@types/react-dom` از `^18.3.1` به `18.3.1` قفل شد.
   علت: فایل `package-lock.json` در سورس نبود و npm جدیدترین تایپ‌ها را نصب می‌کرد که با کد سازگار نبود.
2. **`src/lib/workerTasks.ts` خط ۹۰** — در annotation تایپ، `React.RefObject<HTMLDivElement | null>` به `React.RefObject<HTMLDivElement>` تغییر کرد
   (در تایپ‌های React 18، «current» خودش `T | null` است؛ فقط یک توکن annotation بود، هیچ کد اجرایی عوض نشد).

3. **`android/app/build.gradle`** (پروژه تولیدشده — هر بار با `cap add` از نو ساخته می‌شود):
   `versionName "1.0"` پیش‌فرض قالب به `versionName "2.1.0"` تغییر کرد تا با نسخه برنامه هم‌خوان باشد (versionCode = 1).

## 🔍 راستی‌آزمایی‌های انجام‌شده

- ✅ `tsc --noEmit` بدون خطا؛ Vite build موفق (JS اصلی 322KB + media.worker 15.8KB + فونت وزیرمتن)
- ✅ BUILD SUCCESSFUL — Gradle (108/252 تسک، بدون خطا)
- ✅ پکیج: `com.personalvault.app` · versionName **2.1.0** · versionCode 1 · minSdk 22 · targetSdk 34
- ✅ **دو لانچر (activity-alias)**: `LauncherVault` (فعال — آیکون گاوصندوق) و `LauncherCalc` (غیرفعال به‌صورت پیش‌فرض — آیکون/عنوان «ماشین‌حساب» برای جعل هویت؛ از داخل برنامه قابل تغییر است)
- ✅ `VaultNativePlugin` + `PvWebViewClient` کامپایل و ثبت شدند؛ MainActivity از `BridgeActivity`
- ✅ FileProvider با authority `com.personalvault.app.fileprovider` و محدود به `cache/pv-preview/shared/` (`@xml/file_paths`)
- ✅ سخت‌سازی مانیفست: `allowBackup=false`، `fullBackupContent=false`، `largeHeap=true`، `WRITE_EXTERNAL_STORAGE` فقط تا Android 9 (maxSdkVersion=28)، `<queries>` برای ACTION_VIEW
- ✅ آیکون‌ها داخل APK تأیید شد: `mipmap/ic_launcher*` در ۵ تراکم + `mipmap-anydpi-v26` (adaptive) + `drawable/pv_vault_fg` و `pv_calc_fg` + رشته `calc_label` («ماشین‌حساب»)
- ✅ دارایی‌های وب داخل APK: `assets/public/index.html` + `index-*.js` + `media.worker-*.js` + فونت‌ها + `capacitor.config.json`
- ✅ امضا با `apksigner` تأیید شد (Release: گواهی CN=Personal Vault — scheme v2/v3؛ Debug: کلید debug اندروید)

## 🔑 امضای Release (مهم — برای به‌روزرسانی‌های بعدی)

- کلید: `keystore/release.jks` — alias: `personalvault` — اعتبار: ۱۰٬۰۰۰ روز
- رمزها در `keystore/keystore.properties` ذخیره شده‌اند (همان ساختاری که `patch-android.mjs` انتظار دارد).
- ⚠️ **این پوشه را از دست ندهید**: هر APK آینده باید با همین کلید امضا شود وگرنه اندروید به‌روزرسانی روی نصب قبلی را نمی‌پذیرد.

## 📲 نصب روی گوشی

1. فایل APK را به گوشی منتقل کنید (دانلود از همین صفحه).
2. روی فایل بزنید؛ اگر پیام «نصب از منابع ناشناس» آمد، برای مرورگر/فایل‌منیجر خود اجازه دهید.
3. آیکون «Personal Vault» (شکل گاوصندوق) در لانچر ظاهر می‌شود؛ از Settings → Calculator disguise می‌توانید آن را به «ماشین‌حساب» تبدیل کنید.

> نکته: badging ابزار aapt2 خط `launchable-activity` نشان نمی‌دهد چون نقطه ورود از نوع `activity-alias` است؛ اندروید به‌طور عادی alias را در لانچر نمایش می‌دهد (در مانیفست داخل APK تأیید شد).

## 🗂 وضعیت فعلی فضای کار

- `personal-vault/` — سورس کامل + `dist-apk/` + `keystore/`
- `personal-vault.zip` — آرشیو خام ۹۵ فایل دریافتی از لینک Samsung (بدون تغییر)
- `MANIFEST.md` — نگاشت فایل‌های لینک به ساختار پروژه
- پوشه `android/` تولیدشده در زمان build حذف شد (طبق `.gitignore` خود پروژه) — با `npm run android:apk` از نو ساخته می‌شود.
