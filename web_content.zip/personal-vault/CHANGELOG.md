# 2.2.0

- باز شدن فایل‌های حجیم با Streaming و رمزگشایی جزئی (فقط Chunkهای لازم)، بدون فایل موقت و بدون بارگذاری کامل در RAM؛ PDF از طریق Proxy File Descriptor (اندروید ۸+)
- ذخیره سریع‌تر: Chunk دو مگابایتی، نوشتن دسته‌ای و Pipeline در Worker، Progress بر اساس بایت واقعی نوشته‌شده
- Video Player جدید: سرعت ۰.۲۵x تا ۳x، افقی، Seek دقیق، ±۱۰ ثانیه، ژست روشنایی (نیمه چپ) و صدا (نیمه راست)
- PDF Viewer جدید: Pinch Zoom، رندر فقط صفحات لازم، رفتن به صفحه، افقی
- Pinch Zoom و Pan برای تصاویر؛ کنترل‌های یکسان در همه Viewerها (یک لمس نمایش/مخفی)
- حذف منوی سه‌نقطه در ماشین‌حساب؛ ورود فقط با رمز + «=» بدون هیچ واکنش قابل مشاهده
- رفع ثبت ناقص نام‌ها (IME، maxLength، تشخیص اشتباه پسوند، عنوان خودکار متن‌ها)
- «محافظت در برابر حذف برنامه» با Device Admin رسمی اندروید

# 2.1.0

## Performance & stability
- Encryption, IndexedDB writes, MIME detection and thumbnails run in 1–2 Web Workers (`src/workers/media.worker.ts`); the UI thread only shows progress.
- Files are streamed in 1 MiB chunks with read-ahead and batched transactions; no file is ever fully loaded in RAM. Finished items are committed in batches, so 1000+ files do not cause 1000+ re-renders.
- Byte-accurate, throttled progress with a Stop button (imports and downloads). Locking the vault mid-import stops the workers immediately.
- Thumbnails: cancellable LIFO queue (tiles that scroll off-screen are never decrypted), header-based reduced-size decoding for large photos, huge photos downscaled for the viewer.
- Previews of picked images are generated lazily off-thread (previously every picked photo was decoded at full resolution).
- Deferred search, a query normalized once per search instead of once per item, fewer whole-store subscriptions.
- Fixed: dialogs replaced by a new dialog never resolved (a flow could hang); auto-lock stayed off for 10 minutes after a cancelled file picker; decrypted thumbnails could be cached after lock; garbage collection could delete an import in progress; object URLs from the image viewer could leak.

## In-app file viewer (`src/screens/FilePreview.tsx`)
- Real type detection from the file's bytes (`src/lib/sniff.ts`); the extension is only a fallback. Older items are detected on first open and the result is saved.
- Audio player (play/pause, seek, ±, speed, repeat), video player (native controls, seek), PDF (PdfRenderer on Android, rendered page by page on demand), text/code (first 1 MB), images → image viewer, ZIP → contents list only (nothing extracted), everything else → info card + "open with another app" + download.
- Security: decrypted copies live only in the app's private cache and are served to the WebView through random, revocable token URLs (Range support for seeking in large videos). They are deleted on close, on lock and on every app start. "Open with" copies are shared read-only via FileProvider and removed on lock (a 2-minute grace period for the receiving app) / after 10 minutes.
- Playing media counts as activity for the inactivity lock.

## UI
- New "Confirm before exit" setting (under calculator disguise): confirmation only on Back from the dashboard; internal Back navigation is unchanged.
- Dashboard "Vault unlocked and protected" card no longer gets clipped.
- Three-line menu rebuilt: Files and Images added, content/tools sections, consistent 42 px icon tiles.
- Labels for the five navigation icons in the appearance preview, plus a label for the Settings tab.
- New vault and calculator icons (in-app + Android adaptive/legacy launcher icons, `android-res/`).

## Build
- Added the missing native layer (`android-native/`), `scripts/patch-android.mjs`, `scripts/build-apk.mjs`, and icon resources.
