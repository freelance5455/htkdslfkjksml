/* Personal Vault streaming service worker (web builds only; Android uses PvWebViewClient).
 * Serves  <scope>/_pv_stream/<token>  with HTTP Range support. The bytes are pulled chunk by
 * chunk from the page that opened the stream (which decrypts only the requested chunks), so a
 * large file is never decrypted as a whole and never stored anywhere. Nothing is cached here. */
const streams = new Map(); // token -> { size, mime, chunkSize, clientId }
const waiting = new Map(); // req -> { resolve, reject }
let seq = 0;

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

self.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.type === 'open') {
    streams.set(m.token, { size: m.size, mime: m.mime, chunkSize: m.chunkSize, clientId: e.source && e.source.id });
    if (e.ports[0]) e.ports[0].postMessage('ok');
  } else if (m.type === 'close') streams.delete(m.token);
  else if (m.type === 'closeAll') {
    streams.clear();
    for (const w of waiting.values()) w.reject(new Error('closed'));
    waiting.clear();
  } else if (m.type === 'chunk') {
    const w = waiting.get(m.req);
    if (!w) return;
    waiting.delete(m.req);
    if (m.error) w.reject(new Error('chunk'));
    else w.resolve(new Uint8Array(m.data));
  }
});

async function pull(s, token, idx) {
  const client = await self.clients.get(s.clientId);
  if (!client) throw new Error('client gone');
  const req = 'r' + ++seq;
  const p = new Promise((resolve, reject) => {
    waiting.set(req, { resolve, reject });
    setTimeout(() => waiting.has(req) && (waiting.delete(req), reject(new Error('timeout'))), 30000);
  });
  client.postMessage({ type: 'need', token, idx, req });
  return p;
}

function parseRange(h, size) {
  const m = /^bytes=(\d*)-(\d*)/.exec(h || '');
  if (!m) return null;
  let start, end;
  if (m[1] === '') { start = Math.max(0, size - Number(m[2])); end = size - 1; }
  else { start = Number(m[1]); end = m[2] === '' ? size - 1 : Math.min(size - 1, Number(m[2])); }
  return start <= end && start < size ? { start, end } : { invalid: true };
}

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  const i = url.pathname.indexOf('/_pv_stream/');
  if (i < 0) return;
  const token = url.pathname.slice(i + 12);
  e.respondWith(serve(token, e.request));
});

function serve(token, request) {
  const s = streams.get(token);
  if (!s) return new Response('', { status: 404 });
  const r = request.headers.get('range');
  const range = r ? parseRange(r, s.size) : null;
  if (range && range.invalid) return new Response('', { status: 416, headers: { 'Content-Range': `bytes */${s.size}` } });
  const start = range ? range.start : 0;
  const end = range ? range.end : s.size - 1;
  let pos = start;
  const body = new ReadableStream({
    async pull(ctrl) {
      if (pos > end) return ctrl.close();
      const idx = Math.floor(pos / s.chunkSize);
      try {
        const c = await pull(s, token, idx);
        const from = pos - idx * s.chunkSize;
        const to = Math.min(c.length, end - idx * s.chunkSize + 1);
        ctrl.enqueue(c.subarray(from, to));
        pos += to - from;
        if (to <= from) ctrl.close();
      } catch (err) {
        ctrl.error(err);
      }
    },
  }, { highWaterMark: 2 });
  const headers = { 'Content-Type': s.mime, 'Accept-Ranges': 'bytes', 'Content-Length': String(end - start + 1), 'Cache-Control': 'no-store' };
  if (range) headers['Content-Range'] = `bytes ${start}-${end}/${s.size}`;
  return new Response(body, { status: range ? 206 : 200, headers });
}
