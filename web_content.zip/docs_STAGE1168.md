# CPLS Stage 1168 — Security Test Harness

## Scope
Adds a deterministic client-side security self-test harness for critical CPLS policy invariants.

## Checks
- Reward claim intent requires backend authorization.
- Client does not select an authoritative reward amount.
- Client signing and broadcast remain disabled.
- Sepolia chain ID remains 11155111.
- Duplicate claim nonce is rejected by the local idempotency guard.
- EVM address validation rejects malformed addresses.
- CPLS contract interface remains read-only.
- transfer/approve/mint/burn/signing/broadcast remain unavailable.
- Mainnet remains disabled.

## Important security boundary
This harness is a policy/invariant check only. It is not proof of device integrity, cryptographic attestation, backend authorization, or production security. Backend replay protection, authorization, audit logging, and independent security testing remain mandatory.

## Live-test limitation
No Android SDK/build toolchain or live Sepolia network test is claimed in this stage.
