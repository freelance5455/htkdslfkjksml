# ZEIN Supabase setup

This migration is designed for a **new, dedicated ZEIN Supabase project only**. Do not apply it to the existing HANIMEX project.

The schema provides profiles, personal/business workspaces, memberships, contacts, channel metadata, normalized conversations/messages, activity, RLS policies, and a signup trigger that creates a profile plus a personal workspace.

Before production:
- Review RLS with Supabase Security Advisors.
- Test two separate accounts and verify cross-workspace reads/writes are denied.
- Add a controlled business workspace creation flow.
- Keep OAuth refresh/access tokens in a private server-side store; never expose them to Android clients.
- Provider webhooks must verify signatures and deduplicate provider event IDs.
- Add explicit role-based write restrictions for business admins/members before enabling team invitations.
