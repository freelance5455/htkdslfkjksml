import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: cors });
  }

  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, {
      status: 405, headers: cors
    });
  }

  try {
    const { username, password } = await req.json();

    if (
      typeof username !== "string" ||
      !/^[a-z0-9_.]{3,24}$/i.test(username) ||
      typeof password !== "string" ||
      password.length < 1 || password.length > 256
    ) {
      return Response.json({ error: "Invalid username or password." }, {
        status: 400, headers: cors
      });
    }

    const url = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ??
                    Deno.env.get("SUPABASE_PUBLISHABLE_KEY");

    if (!url || !serviceKey || !anonKey) {
      return Response.json({ error: "Function configuration incomplete." }, {
        status: 500, headers: cors
      });
    }

    const admin = createClient(url, serviceKey, {
      auth: { persistSession: false }
    });

    const authClient = createClient(url, anonKey, {
      auth: { persistSession: false }
    });

    const { data: profile, error: lookupError } = await admin
      .from("profiles")
      .select("email")
      .ilike("username", username.toLowerCase())
      .maybeSingle();

    if (lookupError || !profile?.email) {
      return Response.json({ error: "Invalid username or password." }, {
        status: 401, headers: cors
      });
    }

    const { data, error } = await authClient.auth.signInWithPassword({
      email: profile.email,
      password
    });

    if (error || !data.session) {
      return Response.json({ error: "Invalid username or password." }, {
        status: 401, headers: cors
      });
    }

    return Response.json({ session: data.session }, { headers: cors });

  } catch (_error) {
    return Response.json({ error: "Unable to sign in." }, {
      status: 400, headers: cors
    });
  }
});
