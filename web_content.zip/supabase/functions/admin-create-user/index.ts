import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
Deno.serve(async (req) => {
  const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Content-Type":"application/json"};
  if (req.method === "OPTIONS") return new Response("ok", {headers:cors});
  try {
    const auth = req.headers.get("Authorization") || "";
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return new Response(JSON.stringify({error:"Unauthorized"}), {status:401,headers:cors});
    const { data: me } = await supabase.from("profiles").select("role,disabled").eq("id",user.id).single();
    if (!me || me.role !== "admin" || me.disabled) return new Response(JSON.stringify({error:"Administrator access required"}), {status:403,headers:cors});
    const body = await req.json();
    if (!body.email || !body.password || !body.full_name) return new Response(JSON.stringify({error:"Email, password and full name are required"}), {status:400,headers:cors});
    if (body.password.length < 8) return new Response(JSON.stringify({error:"Password must be at least 8 characters"}), {status:400,headers:cors});
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data, error } = await admin.auth.admin.createUser({email:body.email,password:body.password,email_confirm:true,user_metadata:{full_name:body.full_name}});
    if (error) throw error;
    if (body.role === "admin") await admin.from("profiles").update({role:"admin",full_name:body.full_name}).eq("id",data.user.id);
    else await admin.from("profiles").update({role:"agent",full_name:body.full_name}).eq("id",data.user.id);
    return new Response(JSON.stringify({ok:true,user_id:data.user.id}),{headers:cors});
  } catch(e) { return new Response(JSON.stringify({error:String(e?.message||e)}),{status:400,headers:cors}); }
});
