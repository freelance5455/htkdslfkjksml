import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {'Access-Control-Allow-Origin': Deno.env.get('APP_ORIGIN') || '*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS'};
const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,'Content-Type':'application/json'}});

Deno.serve(async req=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
  try{
    const auth=req.headers.get('Authorization'); if(!auth)return json({error:'Authorization required'},401);
    const url=Deno.env.get('SUPABASE_URL')!, anon=Deno.env.get('SUPABASE_ANON_KEY')!, service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
    const {data:{user}}=await userClient.auth.getUser(); if(!user)return json({error:'Unauthenticated'},401);
    const {data:profile}=await userClient.from('profiles').select('role,is_active').eq('id',user.id).maybeSingle();
    if(!profile||profile.is_active===false||profile.role!=='Développeur')return json({error:'Seul le Développeur peut gérer les utilisateurs.'},403);
    const body=await req.json();
    if(body.action!=='invite')return json({error:'Action invalide.'},400);
    const name=String(body.name||'').trim(), email=String(body.email||'').trim().toLowerCase(), role=String(body.role||'');
    if(!name||!email||!/^\S+@\S+\.\S+$/.test(email))return json({error:'Nom ou e-mail invalide.'},400);
    if(!['Agent','Superviseur','Développeur'].includes(role))return json({error:'Rôle invalide.'},400);
    const admin=createClient(url,service);
    const {data:inv,error:inviteError}=await admin.auth.admin.inviteUserByEmail(email,{data:{full_name:name}});
    if(inviteError) return json({error:inviteError.message},400);
    const {error:profileError}=await admin.from('profiles').upsert({id:inv.user.id,name,full_name:name,role,active:true,is_active:true},{onConflict:'id'});
    if(profileError){
      try{ await admin.auth.admin.deleteUser(inv.user.id); }catch(_){}
      return json({error:'Compte Auth créé mais profil impossible à enregistrer: '+profileError.message},500);
    }
    await admin.from('audit_logs').insert({id:'AUD-'+crypto.randomUUID().replaceAll('-',''),user_id:user.id,action:'user.invited',metadata:{target_user_id:inv.user.id,email,role},created_at:new Date().toISOString()});
    return json({ok:true,userId:inv.user.id});
  }catch(e){return json({error:e instanceof Error?e.message:String(e)},500)}
});
