import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
  };

  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: cors });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: cors,
    });
  }

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Authorization required" }), {
        status: 401,
        headers: cors,
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!serviceRoleKey) {
      return new Response(
        JSON.stringify({ error: "Supabase service role is not configured" }),
        { status: 500, headers: cors },
      );
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: authData, error: authError } = await userClient.auth.getUser();
    if (authError || !authData.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: cors,
      });
    }

    const adminId = authData.user.id;
    const { data: me, error: meError } = await userClient
      .from("profiles")
      .select("role,disabled")
      .eq("id", adminId)
      .single();

    if (meError || !me || me.role !== "admin" || me.disabled) {
      return new Response(
        JSON.stringify({ error: "Administrator access required" }),
        { status: 403, headers: cors },
      );
    }

    let body: { user_id?: string; password?: string } = {};
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON request body" }), {
        status: 400,
        headers: cors,
      });
    }

    const userId = String(body.user_id || "").trim();
    const password = String(body.password || "");

    if (!userId) {
      return new Response(JSON.stringify({ error: "user_id is required" }), {
        status: 400,
        headers: cors,
      });
    }

    if (userId === adminId) {
      return new Response(
        JSON.stringify({
          error: "Use your own account settings to change the administrator password",
        }),
        { status: 400, headers: cors },
      );
    }

    if (password.length < 8) {
      return new Response(
        JSON.stringify({ error: "Password must be at least 8 characters" }),
        { status: 400, headers: cors },
      );
    }

    const admin = createClient(supabaseUrl, serviceRoleKey);

    const { data: target, error: targetError } =
      await admin.auth.admin.getUserById(userId);

    if (targetError || !target.user) {
      return new Response(JSON.stringify({ error: "User account not found" }), {
        status: 404,
        headers: cors,
      });
    }

    const { error: updateError } = await admin.auth.admin.updateUserById(
      userId,
      { password },
    );

    if (updateError) {
      return new Response(JSON.stringify({ error: updateError.message }), {
        status: 400,
        headers: cors,
      });
    }

    return new Response(
      JSON.stringify({ ok: true, user_id: userId }),
      { status: 200, headers: cors },
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : String(e) }),
      { status: 500, headers: cors },
    );
  }
});
