import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': Deno.env.get('APP_ORIGIN') || '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

const esc = (v: unknown) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const csvCell = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const auth = req.headers.get('Authorization');
    if (!auth) return new Response(JSON.stringify({error:'Authorization required'}), {status:401, headers:{...cors,'Content-Type':'application/json'}});

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const adminClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await adminClient.auth.getUser();
    if (!user) return new Response(JSON.stringify({error:'Unauthenticated'}), {status:401, headers:{...cors,'Content-Type':'application/json'}});

    const { data: profile, error: profileError } = await adminClient.from('profiles').select('role,is_active').eq('id', user.id).maybeSingle();
    if (profileError || !profile || profile.is_active === false || !['Superviseur','Développeur'].includes(profile.role)) {
      return new Response(JSON.stringify({error:'Forbidden'}), {status:403, headers:{...cors,'Content-Type':'application/json'}});
    }

    const body = await req.json();
    const report = body.report ?? {};
    const rows: unknown[][] = Array.isArray(body.rows) ? body.rows : [];
    const to = String(body.to || Deno.env.get('REPORT_TO_EMAIL') || '').trim();
    if (!to) throw new Error('REPORT_TO_EMAIL is not configured');

    const clientId = Deno.env.get('GMAIL_CLIENT_ID');
    const clientSecret = Deno.env.get('GMAIL_CLIENT_SECRET');
    const refreshToken = Deno.env.get('GMAIL_REFRESH_TOKEN');
    if (!clientId || !clientSecret || !refreshToken) throw new Error('Gmail secrets are not configured');

    const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
      method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:new URLSearchParams({client_id:clientId, client_secret:clientSecret, refresh_token:refreshToken, grant_type:'refresh_token'})
    });
    const token = await tokenResp.json();
    if (!token.access_token) throw new Error(`Gmail OAuth failed: ${token.error_description || token.error || 'unknown error'}`);

    const csv = rows.map(r => r.map(csvCell).join(',')).join('\r\n');
    const summary = report.summary || {};
    const subject = `WONDER SHIFT — Rapport ${esc(report.period || 'période')}`;
    const html = `<div style="font-family:Arial,sans-serif"><h2>WONDER SHIFT</h2><p>Rapport : <b>${esc(report.period)}</b></p><p>Période : ${esc(report.start)} → ${esc(report.end)}</p><ul><li>Recettes : ${esc(summary.recettes)}</li><li>Dépenses : ${esc(summary.depenses)}</li><li>Solde : ${esc(summary.solde)}</li><li>Opérations : ${esc(summary.operations)}</li></ul><p>Généré le ${new Date().toLocaleString('fr-FR')}</p></div>`;
    const boundary = `ws_${crypto.randomUUID().replaceAll('-','')}`;
    const filename = `wonder-shift-${String(report.period || 'rapport').replace(/[^a-z0-9_-]/gi,'_')}.csv`;
    const mime = [
      `From: ${Deno.env.get('GMAIL_FROM_EMAIL') || user.email}`,
      `To: ${to}`,
      `Subject: =?UTF-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,
      `MIME-Version: 1.0`,
      `Content-Type: multipart/mixed; boundary="${boundary}"`, '',
      `--${boundary}`,
      `Content-Type: text/html; charset="UTF-8"`,
      `Content-Transfer-Encoding: 8bit`, '', html, '',
      `--${boundary}`,
      `Content-Type: text/csv; name="${filename}"`,
      `Content-Disposition: attachment; filename="${filename}"`,
      `Content-Transfer-Encoding: base64`, '',
      btoa(unescape(encodeURIComponent(csv))), '',
      `--${boundary}--`
    ].join('\r\n');
    const raw = btoa(unescape(encodeURIComponent(mime))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
    const sendResp = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method:'POST', headers:{Authorization:`Bearer ${token.access_token}`,'Content-Type':'application/json'},
      body:JSON.stringify({raw})
    });
    const sent = await sendResp.json();
    if (!sendResp.ok) throw new Error(`Gmail send failed: ${sent.error?.message || 'unknown error'}`);

    await adminClient.from('audit_logs').insert({id:`AUD-${crypto.randomUUID().replaceAll('-','')}`, user_id:user.id, action:'report.email_sent', metadata:{to, format:'html+csv', period:report.period, row_count:rows.length}, created_at:new Date().toISOString()});
    return new Response(JSON.stringify({ok:true,messageId:sent.id}), {headers:{...cors,'Content-Type':'application/json'}});
  } catch (e) {
    return new Response(JSON.stringify({error:e instanceof Error ? e.message : String(e)}), {status:500,headers:{...cors,'Content-Type':'application/json'}});
  }
});
