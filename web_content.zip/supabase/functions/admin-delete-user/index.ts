import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
  };

  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    const auth = req.headers.get("Authorization") || "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: cors });
    }

    const { data: me, error: meError } = await supabase
      .from("profiles")
      .select("role,disabled")
      .eq("id", user.id)
      .single();

    if (meError || !me || me.role !== "admin" || me.disabled) {
      return new Response(JSON.stringify({ error: "Administrator access required" }), { status: 403, headers: cors });
    }

    const body = await req.json();
    const userId = String(body.user_id || "").trim();
    if (!userId) {
      return new Response(JSON.stringify({ error: "user_id is required" }), { status: 400, headers: cors });
    }
    if (userId === user.id) {
      return new Response(JSON.stringify({ error: "You cannot delete your own administrator account" }), { status: 400, headers: cors });
    }

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { error } = await admin.auth.admin.deleteUser(userId);
    if (error) throw error;

    return new Response(JSON.stringify({ ok: true, user_id: userId }), { headers: cors });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e?.message || e) }), { status: 400, headers: cors });
  }
});
