// @ts-nocheck
function createApp(db, ADMIN_HASH) {
var V = 4;
var state = null, dirty = false;
var NUM = "unitId propertyId tenantId rent deposit leaseMonths beds baths sqft marketRent amount cost hourlyRate rating avgResponseHrs purchasePrice landValue mortgageBalance mortgageRate mortgagePayment amountFc income".split(" ");
var LINES = [["advertising", "Advertising", 5], ["auto", "Auto and travel", 6], ["cleaning", "Cleaning and maintenance", 7], ["commissions", "Commissions", 8], ["insurance", "Insurance", 9], ["legal", "Legal and professional fees", 10], ["management", "Management fees", 11], ["mortgage_interest", "Mortgage interest", 12], ["repairs", "Repairs", 14], ["supplies", "Supplies", 15], ["taxes", "Taxes", 16], ["utilities", "Utilities", 17], ["depreciation", "Depreciation", 18], ["other", "Other", 19]].map(function (x) { return { key: x[0], label: x[1], line: x[2] }; });
var CH = [{ key: "zillow", name: "Zillow" }, { key: "apartments", name: "Apartments.com" }, { key: "facebook", name: "Facebook Marketplace" }, { key: "immo", name: "Immo RDC" }];
var BANKS = [{ key: "rawbank", name: "Rawbank", cities: ["Butembo", "Beni"] }, { key: "equitybcdc", name: "Equity BCDC", cities: ["Butembo", "Beni"] }, { key: "tmb", name: "TMB", cities: ["Butembo", "Beni"] }];
var TYPES = { apartment: "Apartment", house: "Single-family house", commercial: "Commercial", multi: "Multi-family", land: "Land" };
function $(x) { return Math.round(x * 100) / 100; }
function td() { return new Date().toISOString().slice(0, 10); }
function addD(d, n) { var x = new Date(d + "T00:00:00Z"); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); }
function addM(d, n) { var x = new Date(d + "T00:00:00Z"); x.setUTCMonth(x.getUTCMonth() + n); return x.toISOString().slice(0, 10); }
function bizD(d, n) { var x = new Date(d + "T00:00:00Z"); while (n > 0) { x.setUTCDate(x.getUTCDate() + 1); var w = x.getUTCDay(); if (w && w < 6) n--; } return x.toISOString().slice(0, 10); }
function nid() { return ++state.seq; }
function ref(p) { return p + Math.random().toString(36).slice(2, 8).toUpperCase(); }
function by(a, id) { return a.filter(function (x) { return String(x.id) === String(id); })[0]; }
function sum(a, f) { return a.reduce(function (s, x) { return s + (f ? f(x) : x); }, 0); }
function err(m, s) { return new Response(JSON.stringify({ message: m }), { status: s || 400, headers: { "Content-Type": "application/json" } }); }
function json(o, s) { return new Response(JSON.stringify(o), { status: s || 200, headers: { "Content-Type": "application/json" } }); }
function months(n) { var r = [], d = new Date(); d.setUTCDate(1); for (var i = n - 1; i >= 0; i--) { var x = new Date(d); x.setUTCMonth(x.getUTCMonth() - i); r.push(x.toISOString().slice(0, 7)); } return r; }
function seed() {
var s = { v: V, seq: 1000, admin: { login: "admin", hash: ADMIN_HASH, mustChange: true }, settings: { achSettleBusinessDays: 3, graceDays: 5, lateFeeFlat: 50, cardPct: 2.9, cardFixed: 0.3, achLandlordCost: 0.8, autoReconcileThreshold: 0.9, suggestThreshold: 0.6 },
fx: { cdfPerUsd: 2800, buy: 2780, sell: 2820, date: td(), source: "BCC", auto: true, lastSyncAt: null, lastSyncOk: true, log: [] },
payout: { mpesa: { number: "+243810000000", name: "Keystone SARL" }, orange_money: { number: "", name: "" }, airtel_money: { number: "", name: "" }, banks: [{ bank: "Equity BCDC", accountName: "Keystone SARL", accountNumber: "00112233445", currency: "USD" }] },
properties: [{ id: 1, name: "Résidence Les Palmiers", address: "12 avenue de la Paix", city: "Kinshasa", state: "KN", zip: "00000", typeCode: "apartment", purchasePrice: 450000, landValue: 90000, placedInService: "2022-03-01", mortgageBalance: 280000, mortgageRate: 6.5, mortgagePayment: 2100 }, { id: 2, name: "Villa Gombe", address: "4 rue du Fleuve", city: "Kinshasa", state: "KN", zip: "00000", typeCode: "house", purchasePrice: 320000, landValue: 70000, placedInService: "2023-06-01", mortgageBalance: 0, mortgageRate: 0, mortgagePayment: 0 }],
units: [{ id: 1, propertyId: 1, label: "A1", beds: 2, baths: 1, sqft: 850, marketRent: 850, status: "leased" }, { id: 2, propertyId: 1, label: "A2", beds: 1, baths: 1, sqft: 620, marketRent: 700, status: "vacant" }, { id: 3, propertyId: 1, label: "B1", beds: 3, baths: 2, sqft: 1100, marketRent: 1100, status: "leased" }, { id: 4, propertyId: 2, label: "Villa", beds: 4, baths: 3, sqft: 2200, marketRent: 1800, status: "leased" }],
tenants: [{ id: 1, name: "Jean Mukendi", phone: "+243810000001", email: "jean@example.com", unitId: 1, leaseStart: addM(td(), -8).slice(0, 8) + "01", leaseMonths: 12, rent: 800, deposit: 800, payMethod: "ach", autopay: true, active: true }, { id: 2, name: "Aline Kabeya", phone: "+243820000002", email: "aline@example.com", unitId: 3, leaseStart: addM(td(), -5).slice(0, 8) + "01", leaseMonths: 12, rent: 1050, deposit: 1050, payMethod: "mpesa", mobileNumber: "+243820000002", autopay: false, active: true }, { id: 3, name: "Patrick Ilunga", phone: "+243830000003", email: "patrick@example.com", unitId: 4, leaseStart: addM(td(), -3).slice(0, 8) + "01", leaseMonths: 12, rent: 1700, deposit: 3400, payMethod: "bank_transfer", autopay: false, active: true }],
ledger: [], expenses: [], messages: [], files: [], access: [], txns: [],
vendors: [{ id: 1, name: "Plomberie Express", contact: "Marc", trade: "plumbing", phone: "+243800000010", email: "plomb@example.com", hourlyRate: 35, rating: 4.7, avgResponseHrs: 3, insuredUntil: addM(td(), 8), w9OnFile: true, active: true }, { id: 2, name: "ElectroPro", contact: "Sarah", trade: "electrical", phone: "+243800000011", email: "elec@example.com", hourlyRate: 40, rating: 4.5, avgResponseHrs: 5, insuredUntil: addM(td(), -1), w9OnFile: true, active: true }, { id: 3, name: "Clim Service", contact: "David", trade: "hvac", phone: "+243800000012", email: "clim@example.com", hourlyRate: 45, rating: 4.2, avgResponseHrs: 8, insuredUntil: addM(td(), 5), w9OnFile: false, active: true }],
"work-orders": [], applications: [{ id: 1, unitId: 2, name: "Marie Tshimanga", email: "marie@example.com", phone: "+243840000004", income: 2600, occupants: 2, status: "new", at: td() }], listings: [{ id: 1, unitId: 2, headline: "", description: "", status: "draft", channels: [] }] };
s.tenants.forEach(function (t) {
var st = t.leaseStart.slice(0, 7), ms = months(7).filter(function (m) { return m >= st; });
ms.forEach(function (m, i) {
s.ledger.push({ id: ++s.seq, tenantId: t.id, kind: "charge", category: "rent", date: m + "-01", amount: t.rent, status: "posted", memo: "" });
if (i === ms.length - 1 && t.id !== 1) return;
s.ledger.push({ id: ++s.seq, tenantId: t.id, kind: "payment", method: t.payMethod, date: m + "-0" + (2 + t.id), amount: t.rent, currency: "USD", status: "settled", reference: ref("PMT-"), memo: "" });
});
});
months(7).forEach(function (m, i) {
s.expenses.push({ id: ++s.seq, propertyId: 1, category: "utilities", payee: "SNEL", amount: 180 + i * 5, date: m + "-10", memo: "Électricité parties communes" });
s.expenses.push({ id: ++s.seq, propertyId: 2, category: "insurance", payee: "Sonas", amount: 120, date: m + "-15", memo: "Assurance" });
if (i % 2) s.expenses.push({ id: ++s.seq, propertyId: 1, category: "repairs", payee: "Plomberie Express", amount: 240, date: m + "-20", memo: "Réparation fuite" });
});
return s;
}
function save() { dirty = true; }
function counts(l) { return l.status === "settled" || (l.status === "pending" && l.method !== "bank_transfer"); }
function openCharges(tid) {
var ch = state.ledger.filter(function (l) { return l.tenantId === tid && l.kind === "charge"; }).sort(function (a, b) { return a.date < b.date ? -1 : 1; });
var paid = sum(state.ledger.filter(function (l) { return l.tenantId === tid && l.kind === "payment" && counts(l); }), function (l) { return l.amount; });
return ch.map(function (c) { var a = Math.min(c.amount, Math.max(0, paid)); paid -= a; return { date: c.date, amount: $(c.amount - a), category: c.category }; }).filter(function (c) { return c.amount > 0.005; });
}
function tenantView(t) {
var u = by(state.units, t.unitId) || {}, p = by(state.properties, u.propertyId) || {}, oc = openCharges(t.id), g = state.settings.graceDays;
return Object.assign({}, t, { unitLabel: u.label, propertyId: u.propertyId, propertyName: p.name, leaseEnd: addD(addM(t.leaseStart, t.leaseMonths || 12), -1), balance: $(sum(oc, function (c) { return c.amount; })), pastDue: $(sum(oc.filter(function (c) { return c.date <= addD(td(), -g); }), function (c) { return c.amount; })), unit: u.label });
}
function payView(l) { var t = by(state.tenants, l.tenantId) || {}, u = by(state.units, t.unitId) || {}, p = by(state.properties, u.propertyId) || {}; return Object.assign({}, l, { tenantName: t.name, unitLabel: u.label, unit: u.label, propertyName: p.name }); }
function unitView(u) { var t = state.tenants.filter(function (x) { return x.unitId === u.id && x.active !== false; })[0], p = by(state.properties, u.propertyId) || {}; return Object.assign({}, u, { status: t ? "leased" : (u.status === "leased" ? "vacant" : u.status), tenant: t ? tenantView(t) : null, propertyName: p.name }); }
function woView(w) { var u = by(state.units, w.unitId) || {}, p = by(state.properties, u.propertyId) || {}, t = by(state.tenants, w.tenantId) || {}, v = by(state.vendors, w.vendorId) || {}; return Object.assign({}, w, { unitLabel: u.label, propertyId: u.propertyId, propertyName: p.name, tenantName: t.name, vendorName: v.name }); }
function vendorView(v) {
var wos = state["work-orders"].filter(function (w) { return w.vendorId === v.id; }), y = String(new Date().getUTCFullYear());
var paid = sum(wos.filter(function (w) { return w.status === "completed" && (w.closedAt || "").slice(0, 4) === y; }), function (w) { return +w.cost || 0; }) + sum(state.expenses.filter(function (e) { return e.payee === v.name && e.date.slice(0, 4) === y; }), function (e) { return e.amount; });
return Object.assign({}, v, { compliant: !!(v.active && v.w9OnFile && v.insuredUntil && v.insuredUntil >= td()), w9: v.w9OnFile, openJobs: wos.filter(function (w) { return w.status !== "completed" && w.status !== "cancelled"; }).length, completedJobs: wos.filter(function (w) { return w.status === "completed"; }).length, ytdPaid: $(paid), total: $(paid), reportable: paid >= 600 });
}
function pick(w) { return state.vendors.map(vendorView).filter(function (v) { return v.active && v.compliant && (v.trade === w.category || w.category === "other"); }).sort(function (a, b) { return b.rating - a.rating; }); }
function tick() { var ch = false; state.ledger.forEach(function (l) { if (l.kind === "payment" && l.status === "pending" && l.method === "ach" && l.settlesOn && l.settlesOn <= td()) { l.status = "settled"; ch = true; } }); if (ch) save(); }
function income(f) { return sum(state.ledger.filter(function (l) { return l.kind === "payment" && l.status === "settled" && f(l); }), function (l) { return l.amount; }); }
function propOf(l) { var t = by(state.tenants, l.tenantId) || {}, u = by(state.units, t.unitId) || {}; return u.propertyId; }
function expSum(f) { return sum(state.expenses.filter(f), function (e) { return e.amount; }); }
function dashboard() {
var ms = months(6), t0 = td(), cm = t0.slice(0, 7), tv = state.tenants.filter(function (t) { return t.active !== false; }).map(tenantView), n = state.units.length, occ = tv.length, ytd = t0.slice(0, 4);
var ds = sum(state.properties, function (p) { return +p.mortgagePayment || 0; });
var series = ms.map(function (m) { var inc = income(function (l) { return l.date.slice(0, 7) === m; }), ox = expSum(function (e) { return e.date.slice(0, 7) === m; }); return { month: m, income: $(inc), opex: $(ox), debtService: ds, cashFlow: $(inc - ox - ds) }; });
var due = sum(state.ledger.filter(function (l) { return l.kind === "charge" && l.category === "rent" && l.date.slice(0, 7) === cm; }), function (l) { return l.amount; }), col = income(function (l) { return l.date.slice(0, 7) === cm; });
var aging = { current: 0, d30: 0, d60: 0, d90: 0 };
tv.forEach(function (t) { openCharges(t.id).forEach(function (c) { var age = Math.round((new Date(t0) - new Date(c.date)) / 864e5), k = age <= 30 ? "current" : age <= 60 ? "d30" : age <= 90 ? "d60" : "d90"; aging[k] += c.amount; }); });
var del = tv.filter(function (t) { return t.pastDue > 0; }), yi = income(function (l) { return l.date.slice(0, 4) === ytd; }), yo = expSum(function (e) { return e.date.slice(0, 4) === ytd; });
var acts = [];
del.forEach(function (t) { acts.push({ text: t.name + " : solde en retard de " + t.pastDue + " $", href: "#/payments", tone: "danger" }); });
state.ledger.filter(function (l) { return l.status === "pending" && l.method === "bank_transfer"; }).forEach(function (l) { acts.push({ text: "Virement à confirmer : " + (payView(l).tenantName || ""), href: "#/payments", tone: "warn" }); });
state["work-orders"].filter(function (w) { return w.status === "new"; }).forEach(function (w) { acts.push({ text: "Ordre de travail à traiter : " + w.title, href: "#/maintenance", tone: "warn" }); });
state.txns.filter(function (x) { return x.status === "unmatched" || x.status === "suggested"; }).forEach(function (x) { acts.push({ text: "Transaction bancaire à revoir : " + x.description, href: "#/banking", tone: "info" }); });
var le = tv.filter(function (t) { return t.leaseEnd <= addD(t0, 90) && t.leaseEnd >= t0; }).map(function (t) { return { id: t.id, name: t.name, unit: t.unitLabel, leaseEnd: t.leaseEnd, days: Math.round((new Date(t.leaseEnd) - new Date(t0)) / 864e5) }; });
var act = state.ledger.filter(function (l) { return l.kind === "payment"; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }).slice(0, 8).map(function (l) { return { id: l.id, at: l.date, text: (payView(l).tenantName || "") + " · paiement de " + l.amount + " $ (" + l.method + ")" }; });
return { kpis: { units: n, occupied: occ, occupancy: n ? $(occ / n * 100) : 0, rentDue: $(due), collected: $(col), collectionRate: due ? $(Math.min(100, col / due * 100)) : 0, outstandingTotal: $(aging.current + aging.d30 + aging.d60 + aging.d90), delinquentCount: del.length, delinquentTotal: $(sum(del, function (t) { return t.pastDue; })), inGrace: tv.filter(function (t) { return t.balance > 0 && t.pastDue === 0; }).length, openWorkOrders: state["work-orders"].filter(function (w) { return w.status !== "completed" && w.status !== "cancelled"; }).length, autopayRate: occ ? $(tv.filter(function (t) { return t.autopay; }).length / occ * 100) : 0, ytdIncome: $(yi), ytdNoi: $(yi - yo) },
series: series, aging: aging, actions: acts, activity: act, leaseExpirations: le,
byProperty: state.properties.map(function (p) { var us = state.units.filter(function (u) { return u.propertyId === p.id; }), oc = us.filter(function (u) { return unitView(u).tenant; }).length, pi = income(function (l) { return propOf(l) === p.id && l.date.slice(0, 4) === ytd; }), noi = $(pi - expSum(function (e) { return e.propertyId === p.id && e.date.slice(0, 4) === ytd; })); return { id: p.id, name: p.name, units: us.length, occupied: oc, noi: noi, capRate: p.purchasePrice ? $(noi / (new Date().getUTCMonth() + 1) * 12 / p.purchasePrice * 100) : 0 }; }) };
}
function expView(e) { return Object.assign({}, e, { propertyName: (by(state.properties, e.propertyId) || {}).name }); }
function reports(p, q) {
var y = String(q.get("year") || new Date().getUTCFullYear()), pid = q.get("propertyId");
if (p[1] === "1099") return state.vendors.map(vendorView);
if (p[1] === "pnl") {
var ms = []; for (var i = 1; i <= 12; i++) ms.push(y + "-" + (i < 10 ? "0" : "") + i);
var ok = function (id) { return !pid || pid === "all" || String(id) === pid; };
var rows = LINES.map(function (L) { return { key: L.key, label: L.label, values: ms.map(function (m) { return $(expSum(function (e) { return e.category === L.key && e.date.slice(0, 7) === m && ok(e.propertyId); })); }) }; }).filter(function (r) { return sum(r.values) > 0; });
return { months: ms, income: { rent: ms.map(function (m) { return $(income(function (l) { return l.date.slice(0, 7) === m && ok(propOf(l)); })); }), fees: ms.map(function (m) { return $(sum(state.ledger.filter(function (l) { return l.kind === "charge" && l.category === "late_fee" && l.date.slice(0, 7) === m && ok(propOf(l)); }), function (l) { return l.amount; })); }) }, expenseRows: rows, expenses: state.expenses.filter(function (e) { return e.date.slice(0, 4) === y && ok(e.propertyId); }).map(expView) };
}
var cols = state.properties.map(function (pr) {
var rents = $(income(function (l) { return l.date.slice(0, 4) === y && propOf(l) === pr.id; })), lines = {};
LINES.forEach(function (L) { lines[L.key] = $(expSum(function (e) { return e.propertyId === pr.id && e.category === L.key && e.date.slice(0, 4) === y; })); });
if (pr.purchasePrice) lines.depreciation = $((pr.purchasePrice - (pr.landValue || 0)) / 27.5 + lines.depreciation);
if (pr.mortgageBalance && !lines.mortgage_interest) lines.mortgage_interest = $(pr.mortgageBalance * (pr.mortgageRate || 0) / 100);
var l20 = $(sum(Object.keys(lines), function (k) { return lines[k]; }));
return { id: pr.id, name: pr.name, address: pr.address + ", " + pr.city, typeCode: pr.typeCode, fairRentalDays: 365, personalUseDays: 0, lines: lines, line3: rents, line12: lines.mortgage_interest, line18: lines.depreciation, line20: l20, line21: $(rents - l20) };
});
var T = function (k) { return $(sum(cols, function (c) { return c[k]; })); };
return { year: +y, columns: cols, expenseRows: state.expenses.filter(function (e) { return e.date.slice(0, 4) === y; }).map(expView), totals: { line3: T("line3"), line20: T("line20"), line21: T("line21"), line23a: T("line3"), line23c: T("line12"), line23d: T("line18"), line23e: T("line20"), line24: $(sum(cols, function (c) { return Math.max(0, c.line21); })), line25: $(sum(cols, function (c) { return Math.min(0, c.line21); })), line26: T("line21") } };
}
function syncBank() {
var linked = {}; state.txns.forEach(function (x) { if (x.ledgerId) linked["l" + x.ledgerId] = 1; if (x.expenseId) linked["e" + x.expenseId] = 1; }); var added = 0, auto = 0, sug = 0;
state.ledger.filter(function (l) { return l.kind === "payment" && l.status === "settled" && !linked["l" + l.id]; }).forEach(function (l) { state.txns.push({ id: nid(), accountId: 1, date: l.date, amount: l.amount, description: "VIREMENT " + (payView(l).tenantName || "").toUpperCase() + " " + (l.reference || ""), status: "matched", matchReason: "Montant exact + locataire", confidence: 0.98, ledgerId: l.id }); added++; auto++; });
state.expenses.filter(function (e) { return !linked["e" + e.id]; }).forEach(function (e) { state.txns.push({ id: nid(), accountId: 1, date: e.date, amount: -e.amount, description: (e.payee || "").toUpperCase() + " " + (e.memo || ""), status: "matched", matchReason: "Dépense enregistrée", confidence: 0.95, expenseId: e.id }); added++; auto++; });
if (!state.txns.some(function (x) { return x.demo; })) { state.txns.push({ id: nid(), accountId: 1, date: td(), amount: -86.4, description: "HOME DEPOT KINSHASA", status: "suggested", matchReason: "Fournisseur de fournitures", confidence: 0.72, suggestedCategory: "supplies", suggestedPropertyId: 1, demo: true }, { id: nid(), accountId: 1, date: td(), amount: -45, description: "PAIEMENT INCONNU 7731", status: "unmatched", matchReason: "", confidence: 0, demo: true }); added += 2; sug++; }
return { added: added, auto: auto, suggested: sug };
}
function bank() {
var tx = state.txns.slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; }), c = { matched: 0, suggested: 0, unmatched: 0, excluded: 0 };
tx.forEach(function (x) { c[x.status] = (c[x.status] || 0) + 1; });
return { accounts: [{ id: 1, institution: "Equity BCDC", mask: "4821", balance: $(25000 + sum(tx.filter(function (x) { return x.status !== "excluded"; }), function (x) { return x.amount; })), lastSync: state.bankSync || null }], txns: tx, counts: c, matched: c.matched, suggested: c.suggested, unmatched: c.unmatched, autoRate: tx.length ? $(c.matched / tx.length * 100) : 0, lastSync: state.bankSync || null };
}
function threads() {
var out = [];
function add(type, o, sub) { var m = state.messages.filter(function (x) { return x.partyType === type && x.partyId === o.id; }).sort(function (a, b) { return a.at < b.at ? -1 : 1; }), last = m[m.length - 1]; out.push({ partyType: type, partyId: o.id, name: o.name, sub: sub, unread: m.filter(function (x) { return x.sender !== "admin" && !x.readAdmin; }).length, lastAt: last ? last.at : null, lastBody: last ? last.body : "", lastSender: last ? last.sender : null, lastHasFiles: !!(last && last.fileIds && last.fileIds.length), photoFileId: null }); }
state.tenants.forEach(function (t) { var v = tenantView(t); add("tenant", t, (v.unitLabel || "") + " · " + (v.propertyName || "")); });
state.vendors.forEach(function (v) { add("vendor", v, v.trade); });
return out.sort(function (a, b) { return (b.lastAt || "") > (a.lastAt || "") ? 1 : -1; });
}
function unreadFor(type, id, viewer) { return state.messages.filter(function (x) { return x.partyType === type && String(x.partyId) === String(id) && x.sender !== viewer && !(viewer === "admin" ? x.readAdmin : x.readParty); }).length; }
function pass() { return Math.random().toString(36).slice(2, 6) + Math.random().toString(36).slice(2, 6); }
var enc = new TextEncoder();
function b64(buf) { var a = new Uint8Array(buf), s2 = ""; for (var i = 0; i < a.length; i++) s2 += String.fromCharCode(a[i]); return btoa(s2); }
function unb64(t) { var r = atob(t), a = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) a[i] = r.charCodeAt(i); return a; }
async function derive(pw, salt, it) { var k = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]); return b64(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: salt, iterations: it }, k, 256)); }
async function hashPw(pw) { var salt = crypto.getRandomValues(new Uint8Array(16)); return "pbkdf2$100000$" + b64(salt) + "$" + await derive(pw, salt, 100000); }
async function checkPw(pw, h) { if (!h) return false; var p = h.split("$"); return (await derive(pw, unb64(p[2]), +p[1])) === p[3]; }
async function login(b) {
var l = String(b.login || "").trim().toLowerCase(), pw = String(b.password || ""); state.fails = state.fails || {};
var f = state.fails[l]; if (f && f.until && f.until > Date.now()) return { locked: true };
var usr = null;
if (l === state.admin.login && await checkPw(pw, state.admin.hash)) usr = { role: "admin", id: 0, name: "Administrateur", login: l, partyId: null, mustChange: !!state.admin.mustChange };
else { var a = state.access.filter(function (x) { return x.login.toLowerCase() === l; })[0]; if (a && await checkPw(pw, a.hash)) { var party = by(a.role === "tenant" ? state.tenants : state.vendors, a.partyId) || {}; a.lastLoginAt = new Date().toISOString(); usr = { role: a.role, id: a.id, name: party.name, login: a.login, partyId: a.partyId, mustChange: !!a.mustChange }; } }
if (!usr) { var n = ((f && f.n) || 0) + 1; state.fails[l] = { n: n, until: n >= 8 ? Date.now() + 600000 : 0 }; save(); return null; }
if (state.fails[l]) { delete state.fails[l]; save(); }
return usr;
}
function coerce(b) { var o = Object.assign({}, b); NUM.forEach(function (k) { if (o[k] !== undefined && o[k] !== "" && o[k] !== null && !isNaN(o[k])) o[k] = +o[k]; }); return o; }
function removeUnit(id) { state.tenants = state.tenants.filter(function (t) { return t.unitId !== id; }); state.listings = state.listings.filter(function (l) { return l.unitId !== id; }); state.units = state.units.filter(function (u) { return u.id !== id; }); }
function adminSave(method, res, id, b) {
var coll = state[res]; if (!coll) return err("Ressource inconnue", 404); b = coerce(b);
if (method === "DELETE") {
if (res === "properties") { state.units.filter(function (u) { return u.propertyId === +id; }).forEach(function (u) { removeUnit(u.id); }); state.expenses = state.expenses.filter(function (e) { return e.propertyId !== +id; }); }
if (res === "units") removeUnit(+id);
if (res === "tenants") { state.ledger = state.ledger.filter(function (l) { return l.tenantId !== +id; }); state.access = state.access.filter(function (a) { return !(a.role === "tenant" && a.partyId === +id); }); }
if (res === "vendors") state["work-orders"].forEach(function (w) { if (w.vendorId === +id) w.vendorId = null; });
state[res] = state[res].filter(function (x) { return String(x.id) !== String(id); }); save(); return json({ ok: true });
}
if (res === "ledger" && b.amountFc !== undefined) b.amount = $(b.amountFc / (b.fxRate || state.fx.cdfPerUsd));
if (res === "tenants" && b.unitId) { var busy = state.tenants.filter(function (t) { return t.unitId === b.unitId && t.active !== false && String(t.id) !== String(id); })[0]; if (busy) return err("Cette unité est déjà louée."); }
if (!id) {
var it = Object.assign({ id: nid() }, b);
if (res === "tenants") { it.leaseStart = it.leaseStart || td(); it.leaseMonths = it.leaseMonths || 12; it.active = it.active !== false; }
if (res === "applications") { it.status = "new"; it.at = td(); } if (res === "listings") it.status = "draft"; if (res === "units") it.status = it.status || "vacant";
coll.push(it); save(); return json(it);
}
var cur = by(coll, id); if (!cur) return err("Introuvable", 404); Object.assign(cur, b); if (res === "ledger" && b.currency === "CDF") cur.fxRate = cur.fxRate || state.fx.cdfPerUsd; save(); return json(cur);
}
function addPayment(b, manual) {
var t = by(state.tenants, b.tenantId); if (!t) return err("Locataire introuvable", 404);
var cur = b.currency || "USD", rate = state.fx.cdfPerUsd, amt = +b.amount; if (!(amt > 0)) return err("Montant invalide");
var m = b.method || "ach", st = manual ? "settled" : (m === "card" || /money|mpesa/.test(m)) ? "settled" : "pending";
var p = { id: nid(), tenantId: t.id, kind: "payment", method: m, date: b.date || td(), amount: cur === "CDF" ? $(amt / rate) : amt, currency: cur, status: st, reference: b.reference || ref("PMT-"), memo: b.memo || "" };
if (cur === "CDF") { p.amountFc = amt; p.fxRate = rate; }
if (!manual && m === "ach") p.settlesOn = bizD(td(), state.settings.achSettleBusinessDays);
state.ledger.push(p); save(); return json({ payment: p, settlesOn: p.settlesOn || p.date });
}
function rentRun() {
var cm = td().slice(0, 7), c = 0, i = 0;
state.tenants.filter(function (t) { return t.active !== false && t.leaseStart.slice(0, 7) <= cm; }).forEach(function (t) {
if (state.ledger.some(function (l) { return l.tenantId === t.id && l.kind === "charge" && l.category === "rent" && l.date.slice(0, 7) === cm; })) return;
state.ledger.push({ id: nid(), tenantId: t.id, kind: "charge", category: "rent", date: cm + "-01", amount: t.rent, status: "posted", memo: "" }); c++;
if (t.autopay && t.payMethod) { state.ledger.push({ id: nid(), tenantId: t.id, kind: "payment", method: t.payMethod, date: td(), amount: t.rent, currency: "USD", status: t.payMethod === "ach" ? "pending" : "settled", settlesOn: bizD(td(), state.settings.achSettleBusinessDays), reference: ref("AUTO-"), memo: "Prélèvement automatique" }); i++; }
});
save(); return { charged: c, initiated: i };
}
function lateFees() {
var cm = td().slice(0, 7), n = 0;
state.tenants.filter(function (t) { return t.active !== false; }).forEach(function (t) { if (tenantView(t).pastDue > 0 && !state.ledger.some(function (l) { return l.tenantId === t.id && l.category === "late_fee" && l.date.slice(0, 7) === cm; })) { state.ledger.push({ id: nid(), tenantId: t.id, kind: "charge", category: "late_fee", date: td(), amount: state.settings.lateFeeFlat, status: "posted", memo: "Frais de retard" }); n++; } });
save(); return { count: n, message: n + " frais de retard appliqués" };
}
function appView(a) { var u = by(state.units, a.unitId) || {}, p = by(state.properties, u.propertyId) || {}; return Object.assign({}, a, { unitLabel: u.label, propertyName: p.name, rent: u.marketRent }); }
function listView(l) { var u = unitView(by(state.units, l.unitId) || {}), p = by(state.properties, u.propertyId) || {}; return Object.assign({}, l, { unit: u, headline: l.headline || l.title || "", description: l.description || "", rent: l.rent !== undefined ? l.rent : (u.marketRent || 0), petsAllowed: !!l.petsAllowed, amenities: l.amenities || [], channels: l.channels || [], status: u.tenant ? "leased" : (l.status === "live" ? "active" : l.status), label: u.label, beds: u.beds, baths: u.baths, sqft: u.sqft, marketRent: u.marketRent, propertyName: p.name }); }
function propView(x) { return Object.assign({}, x, { units: state.units.filter(function (u) { return u.propertyId === x.id; }).map(unitView) }); }
async function fileUrls(ids) { var m = {}; if (!ids.length) return m; var rows = await db.getFiles(ids); rows.forEach(function (r) { m[r.id] = r.data_url; }); return m; }
async function handle(method, url, req) {
var u = new URL(url), p = u.pathname.replace(/^.*?\/api\//, "").split("/").filter(Boolean), q = u.searchParams, b = {}, h = req.headers || {};
var hd = p[0], id = p[1], sub = p[2];
var tk = (h.Authorization || h.authorization || "").replace(/^Bearer /, ""), me = tk ? await db.getSession(tk) : null;
if (req.body && typeof req.body === "string") { try { b = JSON.parse(req.body); } catch (e) {} }
tick();
if (hd === "health") return json({ ok: true, units: state.units.length });
if (hd === "auth") {
if (id === "login") { var usr = await login(b); if (usr && usr.locked) return err("Trop de tentatives. Réessayez dans 10 minutes.", 429); if (!usr) return err("Identifiant ou mot de passe incorrect", 401); var tok = crypto.randomUUID() + crypto.randomUUID(); await db.putSession(tok, usr); return json({ token: tok, user: usr }); }
if (id === "me") return me ? json({ user: me }) : err("Non connecté", 401);
if (id === "logout") { if (tk) await db.delSession(tk); return json({ ok: true }); }
if (id === "password") {
if (!me) return err("Non connecté", 401); if (!b.next || String(b.next).length < 8) return err("Le nouveau mot de passe doit contenir au moins 8 caractères");
if (me.role === "admin") { if (!(await checkPw(b.current || "", state.admin.hash))) return err("Mot de passe actuel incorrect"); state.admin.hash = await hashPw(b.next); state.admin.mustChange = false; }
else { var a0 = state.access.filter(function (x) { return x.login === me.login; })[0]; if (!a0 || !(await checkPw(b.current || "", a0.hash))) return err("Mot de passe actuel incorrect"); a0.hash = await hashPw(b.next); a0.mustChange = false; }
me.mustChange = false; await db.putSession(tk, me); save(); return json({ ok: true });
}
}
if (!me) return err("Non connecté", 401);
if (hd === "meta") return json({ today: td(), cdfPerUsd: state.fx.cdfPerUsd, settings: state.settings, scheduleELines: LINES, propertyTypes: TYPES, channels: CH, banks: BANKS });
if (hd === "dashboard") return json(dashboard());
if (hd === "fx") {
if (method === "PUT") { var nb = coerce(b); if (nb.cdfPerUsd) { state.fx.cdfPerUsd = +nb.cdfPerUsd; state.fx.date = td(); } if (nb.auto !== undefined) state.fx.auto = !!nb.auto; save(); }
if (id === "sync") { state.fx.lastSyncAt = new Date().toISOString(); state.fx.lastSyncOk = true; state.fx.log.unshift({ at: state.fx.lastSyncAt, ok: true, rate: state.fx.cdfPerUsd, message: "Synchronisation simulée (taux conservé)" }); state.fx.log = state.fx.log.slice(0, 20); save(); }
return json(Object.assign({ rate: state.fx.cdfPerUsd, updatedAt: state.fx.date }, state.fx));
}
if (hd === "payout") { if (method === "PUT") { state.payout = Object.assign(state.payout, b.payout || b); save(); } return json({ payout: state.payout, banks: BANKS }); }
if (hd === "integrations") return json([["payments","Stripe (ACH + cartes)"],["mobile_money","Mobile money (M-Pesa, Orange, Airtel)"],["bank_transfer","Virement bancaire"],["bank","Flux bancaire (Plaid)"],["screening","Dépistage des candidats"],["ai","Assistant IA"],["syndication","Syndication des annonces"]].map(function (x) { return { key: x[0], name: x[1], provider: x[1], mode: "sandbox", detail: "Adaptateur de démonstration" }; }));
if (hd === "demo") { state = seed(); save(); return json({ ok: true }); }
if (hd === "lease-end") return json({ leaseEnd: addD(addM(q.get("start"), +q.get("months") || 12), -1), factors: {} });
if (hd === "reports") return json(reports(p, q));
if (hd === "admin") return adminSave(method, id, sub, b);
if (hd === "rent") return json(id === "run" ? rentRun() : lateFees());
if (hd === "access") {
if (method === "GET") return json(state.access.map(function (a) { return { role: a.role, partyId: a.partyId, login: a.login, lastLoginAt: a.lastLoginAt, mustChange: a.mustChange }; }));
if (method === "POST") { var party = by(b.role === "tenant" ? state.tenants : state.vendors, b.partyId); if (!party) return err("Introuvable", 404); var ex = state.access.filter(function (a) { return a.role === b.role && a.partyId === +b.partyId; })[0], pw = pass(), was = !!ex; if (ex) { ex.hash = await hashPw(pw); ex.mustChange = true; } else { ex = { id: nid(), role: b.role, partyId: +b.partyId, login: party.email || party.phone || b.role + party.id, hash: await hashPw(pw), mustChange: true }; state.access.push(ex); } save(); return json({ login: ex.login, password: pw, reset: was }); }
if (method === "DELETE") { state.access = state.access.filter(function (a) { return !(a.role === id && String(a.partyId) === sub); }); save(); return json({ ok: true }); }
}
if (hd === "tenants") {
if (!id) return json(state.tenants.map(tenantView));
var t = by(state.tenants, id); if (!t) return err("Introuvable", 404);
if (sub === "charge") { state.ledger.push({ id: nid(), tenantId: t.id, kind: "charge", category: b.category || b.kind || "other", date: b.date || td(), amount: +b.amount, status: "posted", memo: b.memo || b.note || "" }); save(); return json(tenantView(t)); }
if (sub === "autopay") { Object.assign(t, { autopay: !!b.autopay }, b.payMethod ? { payMethod: b.payMethod } : {}, b.mobileNumber ? { mobileNumber: b.mobileNumber } : {}, b.bankName ? { bankName: b.bankName } : {}); save(); return json(tenantView(t)); }
if (sub === "profile") { Object.assign(t, coerce(b)); save(); return json(tenantView(t)); }
var run = 0, led = state.ledger.filter(function (l) { return l.tenantId === t.id; }).sort(function (a, c) { return a.date === c.date ? a.id - c.id : a.date < c.date ? -1 : 1; }).map(function (l) { if (l.kind === "charge") run += l.amount; else if (counts(l)) run -= l.amount; return Object.assign({}, l, { running: $(run) }); }).reverse();
return json({ tenant: tenantView(t), ledger: led, payments: led.filter(function (l) { return l.kind === "payment"; }), workOrders: state["work-orders"].filter(function (w) { return w.tenantId === t.id; }).map(woView), awaitingConfirmation: led.filter(function (l) { return l.status === "pending" && l.method === "bank_transfer"; }), settings: state.settings });
}
if (hd === "payments") {
if (id === "manual") return addPayment(b, true);
if (id && sub === "confirm") { var pm = by(state.ledger, id); if (!pm) return err("Introuvable", 404); pm.status = b.reject ? "failed" : "settled"; save(); return json(payView(pm)); }
if (method === "POST") return addPayment(b, false);
return json(state.ledger.filter(function (l) { return l.kind === "payment"; }).sort(function (a, c) { return a.date < c.date ? 1 : -1; }).map(payView));
}
if (hd === "properties") { if (!id) return json(state.properties.map(propView)); var pr = by(state.properties, id); return pr ? json(propView(pr)) : err("Introuvable", 404); }
if (hd === "units") return json(state.units.map(unitView));
if (hd === "vendors") { if (id && method === "PATCH") { var vv = by(state.vendors, id); Object.assign(vv, coerce(b)); save(); return json(vendorView(vv)); } return json(state.vendors.map(vendorView)); }
if (hd === "expenses") { if (method === "POST") return adminSave("POST", "expenses", null, b); var yr = q.get("year"); return json(state.expenses.filter(function (e) { return !yr || e.date.slice(0, 4) === yr; }).sort(function (a, c) { return a.date < c.date ? 1 : -1; }).map(expView)); }
if (hd === "work-orders") {
if (!id) {
if (method === "POST") { b = coerce(b); var tn = by(state.tenants, b.tenantId) || state.tenants.filter(function (x) { return x.unitId === b.unitId; })[0]; var w = { id: nid(), unitId: b.unitId, tenantId: tn && tn.id, title: b.title || "Demande", description: b.description || "", category: b.category || "other", priority: b.priority || "normal", status: "new", cost: 0, at: td(), timeline: [{ at: new Date().toISOString(), text: "Demande créée" }] }; state["work-orders"].push(w); var cand = pick(w), disp = null; if (cand[0]) { w.vendorId = cand[0].id; w.status = "dispatched"; w.timeline.push({ at: new Date().toISOString(), text: "Envoyé à " + cand[0].name }); disp = cand[0].name; } save(); return json({ workOrder: woView(w), triage: { category: w.category, priority: w.priority }, dispatchedTo: disp }); }
return json(state["work-orders"].map(woView));
}
var wo = by(state["work-orders"], id); if (!wo) return err("Introuvable", 404);
if (sub === "candidates") return json(pick(wo).map(function (v, i) { return Object.assign({}, v, { score: Math.round(v.rating * 20 - i) }); }));
if (sub === "action") { var ac = b.action, now = new Date().toISOString(); if (ac === "auto_dispatch") { var c2 = pick(wo)[0]; if (!c2) return err("Aucun prestataire conforme disponible"); wo.vendorId = c2.id; wo.status = "dispatched"; wo.timeline.push({ at: now, text: "Envoyé à " + c2.name }); } else if (ac === "dispatch") { wo.vendorId = +b.vendorId; wo.status = "dispatched"; if (b.scheduledFor) wo.scheduledFor = b.scheduledFor; wo.timeline.push({ at: now, text: "Envoyé au prestataire" }); } else if (ac === "close") { wo.status = "completed"; wo.closedAt = td(); if (b.cost !== undefined) wo.cost = +b.cost; wo.timeline.push({ at: now, text: "Clôturé" }); } else if (ac === "reopen") { wo.status = "new"; wo.timeline.push({ at: now, text: "Rouvert" }); } else if (ac === "note") wo.timeline.push({ at: now, text: b.note || b.text || "" }); save(); return json(woView(wo)); }
return json(woView(wo));
}
if (hd === "applications") {
if (!id) return method === "POST" ? adminSave("POST", "applications", null, b) : json(state.applications.map(appView));
var ap = by(state.applications, id); if (!ap) return err("Introuvable", 404);
if (sub === "screen") { var un2 = by(state.units, ap.unitId) || {}, ratio = (+ap.income || 0) / (un2.marketRent || 1), sc = Math.max(300, Math.min(850, Math.round(450 + ratio * 70))); ap.score = sc; ap.screening = { creditScore: sc, incomeRatio: $(ratio), evictions: 0, criminal: "clear" }; ap.status = "screened"; save(); }
if (sub === "decision") { ap.status = b.decision === "approved" ? "approved" : b.decision === "declined" ? "declined" : "conditional"; ap.decision = b.decision; save(); }
return json(appView(ap));
}
if (hd === "listings") {
if (!id) { if (method === "POST") { var l0 = Object.assign({ id: nid(), status: "draft" }, coerce(b)); state.listings.push(l0); save(); return json(listView(l0)); } return json(state.listings.map(listView)); }
var ls = by(state.listings, id); if (!ls) return err("Introuvable", 404); var un3 = by(state.units, ls.unitId) || {}, pp = by(state.properties, un3.propertyId) || {};
if (sub === "generate") { ls.headline = un3.beds + " ch. · " + un3.baths + " sdb · " + pp.name; ls.description = "Logement de " + un3.beds + " chambres et " + un3.baths + " salles de bain (" + un3.sqft + " pi²) à " + pp.city + ". Loyer : " + un3.marketRent + " $/mois."; }
else if (sub === "publish") { var ks = (b.channels && b.channels.length) ? b.channels : CH.map(function (c) { return c.key; }); ls.status = "active"; ls.channels = CH.filter(function (c) { return ks.indexOf(c.key) >= 0; }).map(function (c) { return { key: c.key, name: c.name, postedAt: new Date().toISOString(), views: Math.floor(Math.random() * 40), leads: Math.floor(Math.random() * 4) }; }); } else if (sub === "unpublish") { ls.status = "paused"; ls.channels = (ls.channels || []).map(function (c) { return Object.assign({}, c, { postedAt: null }); }); } else if (method === "PATCH") Object.assign(ls, coerce(b)); else if (method === "DELETE") state.listings = state.listings.filter(function (x) { return x !== ls; });
save(); return json(listView(ls));
}
if (hd === "bank") {
if (id === "sync") { var r = syncBank(); state.bankSync = new Date().toISOString(); save(); return json(r); }
if (id === "reconcile") { var au = 0; state.txns.forEach(function (x) { if (x.status !== "unmatched") return; var m = state.ledger.filter(function (l) { return l.kind === "payment" && l.amount === x.amount && !state.txns.some(function (y) { return y.ledgerId === l.id; }); })[0]; if (m) { x.status = "matched"; x.ledgerId = m.id; x.confidence = 0.9; au++; } }); save(); return json({ auto: au, suggested: 0 }); }
if (id === "txns") { var tx = by(state.txns, sub), op = p[3]; if (!tx) return err("Introuvable", 404); if (op === "confirm") { tx.status = "matched"; if (tx.suggestedCategory && !tx.expenseId) { var e2 = { id: nid(), propertyId: +(b.propertyId || tx.suggestedPropertyId) || 1, category: b.category || tx.suggestedCategory, payee: tx.description, amount: Math.abs(tx.amount), date: tx.date, memo: "Rapprochement bancaire" }; state.expenses.push(e2); tx.expenseId = e2.id; } } else if (op === "exclude") tx.status = "excluded"; else if (op === "unmatch") tx.status = "unmatched"; save(); return json(tx); }
return json(bank());
}
if (hd === "threads") return json(threads());
if (hd === "unread") { var n = me.role === "admin" ? threads().reduce(function (s, t2) { return s + t2.unread; }, 0) : unreadFor(me.role, me.partyId, me.role); return json({ unread: n, count: n, total: n }); }
if (hd === "conversations") {
var ty = id, pid = sub, vwr = q.get("viewer") || "admin";
if (p[3] === "unread") return json({ unread: unreadFor(ty, pid, vwr) });
if (p[3] === "messages") { var snd = b.sender || vwr, m0 = { id: nid(), partyType: ty, partyId: +pid, sender: snd, body: b.body || "", at: new Date().toISOString(), fileIds: b.fileIds || [], readAdmin: snd === "admin", readParty: snd !== "admin" }; state.messages.push(m0); save(); return json(m0); }
var ms2 = state.messages.filter(function (x) { return x.partyType === ty && String(x.partyId) === String(pid); }).sort(function (a, c) { return a.at < c.at ? -1 : 1; });
ms2.forEach(function (x) { if (vwr === "admin") x.readAdmin = true; else x.readParty = true; }); save();
var fl = {}; ms2.forEach(function (x) { (x.fileIds || []).forEach(function (f) { fl[f] = 1; }); }); var um = await fileUrls(Object.keys(fl).map(Number)); return json({ messages: ms2.map(function (x) { return Object.assign({}, x, { files: (x.fileIds || []).map(function (f) { var m = by(state.files, f); return m ? Object.assign({}, m, { url: um[m.id] || "" }) : null; }).filter(Boolean) }); }) });
}
if (hd === "messages" && method === "DELETE") { state.messages = state.messages.filter(function (x) { return String(x.id) !== id; }); save(); return json({ ok: true }); }
if (hd === "files") {
if (method === "GET") { var fs = state.files.filter(function (f) { return f.ownerType === q.get("ownerType") && String(f.ownerId) === q.get("ownerId"); }); var um2 = await fileUrls(fs.map(function (f) { return f.id; })); return json(fs.map(function (f) { return Object.assign({}, f, { url: um2[f.id] || "" }); })); }
if (method === "DELETE") { state.files = state.files.filter(function (f) { return String(f.id) !== id; }); await db.delFile(+id); save(); return json({ ok: true }); }
if (method === "POST") {
var ct = h["Content-Type"] || "application/octet-stream", buf = new Uint8Array(req.body), bin = ""; for (var i = 0; i < buf.length; i += 8192) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 8192));
var url2 = "data:" + ct + ";base64," + btoa(bin); if (url2.length > 400000) return err("Fichier trop volumineux (max. environ 250 Ko)", 413);
var fm = { id: nid(), ownerType: q.get("ownerType"), ownerId: +q.get("ownerId"), name: q.get("name") || "photo.jpg", mime: ct, size: buf.length, by: q.get("by") || "admin", caption: q.get("caption") || "", at: new Date().toISOString() };
await db.putFile(fm.id, url2); state.files.push(fm); save(); return json(Object.assign({}, fm, { url: url2 }));
}
}
return json(method === "GET" ? [] : { ok: true });
}
async function run(request) {
var ct = request.headers.get("content-type") || "", raw = request.method === "GET" || request.method === "HEAD" || request.method === "DELETE" ? undefined : (/json|text/.test(ct) ? await request.text() : await request.arrayBuffer());
var headers = { Authorization: request.headers.get("authorization") || "", "Content-Type": ct };
for (var attempt = 0; attempt < 4; attempt++) {
var st = await db.getState(); if (!st) { state = seed(); dirty = false; await db.insertState(state); st = await db.getState(); }
state = st.data; dirty = false; var res;
try { res = await handle(request.method, request.url, { body: raw, headers: headers }); } catch (e) { return err(String(e && e.message || e), 500); }
if (!dirty) return res;
if (await db.putState(state, st.version)) return res;
}
return err("Conflit d'écriture, réessayez", 409);
}
return { run: run };
}
const SB = Deno.env.get("SUPABASE_URL"), KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
const HD = { apikey: KEY, Authorization: "Bearer " + KEY, "Content-Type": "application/json" };
async function rest(path, init = {}) {
const r = await fetch(SB + "/rest/v1/" + path, { ...init, headers: { ...HD, ...(init.headers || {}) } });
if (!r.ok) throw new Error("db " + r.status + " " + (await r.text()));
const t = await r.text(); return t ? JSON.parse(t) : null;
}
const up = { Prefer: "resolution=merge-duplicates,return=minimal" };
const db = {
async getState() { const r = await rest("app_state?id=eq.main&select=data,version"); return r && r[0] ? r[0] : null; },
async insertState(d) { await rest("app_state", { method: "POST", headers: { Prefer: "resolution=ignore-duplicates,return=minimal" }, body: JSON.stringify({ id: "main", data: d }) }); },
async putState(d, v) { const r = await rest("app_state?id=eq.main&version=eq." + v, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ data: d, version: v + 1, updated_at: new Date().toISOString() }) }); return !!(r && r.length); },
async getSession(t) { const r = await rest("app_sessions?token=eq." + encodeURIComponent(t) + "&expires_at=gt." + encodeURIComponent(new Date().toISOString()) + "&select=user_data"); return r && r[0] ? r[0].user_data : null; },
async putSession(t, u) { await rest("app_sessions", { method: "POST", headers: up, body: JSON.stringify({ token: t, user_data: u }) }); },
async delSession(t) { await rest("app_sessions?token=eq." + encodeURIComponent(t), { method: "DELETE" }); },
async getFiles(ids) { return await rest("app_files?id=in.(" + ids.join(",") + ")&select=id,data_url"); },
async putFile(id, u) { await rest("app_files", { method: "POST", headers: up, body: JSON.stringify({ id: id, data_url: u }) }); },
async delFile(id) { await rest("app_files?id=eq." + id, { method: "DELETE" }); }
};
const app = createApp(db, "pbkdf2$100000$NUL6OGHWeQCTXa009hfd7Q==$smW5YrhBQ4aH58mP79GOcar5gS5PaaM9jvuz6S+FBJg=");
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type, x-client-info, apikey", "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS", "Access-Control-Max-Age": "86400" };
let chain = Promise.resolve();
Deno.serve((req) => {
if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
const p = chain.then(() => app.run(req)); chain = p.catch(() => {});
return p.then((r) => { const h = new Headers(r.headers); for (const k in CORS) h.set(k, CORS[k]); return new Response(r.body, { status: r.status, headers: h }); });
});
