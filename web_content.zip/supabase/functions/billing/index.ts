// @ts-nocheck
import { PDFDocument, StandardFonts, rgb } from "npm:pdf-lib@1.17.1";
function createBilling(db, env, fetchImpl, PDF) {
var PDFDocument = PDF.PDFDocument, StandardFonts = PDF.StandardFonts, rgb = PDF.rgb;
var enc = new TextEncoder();
var MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
function J(o, s) { return new Response(JSON.stringify(o), { status: s || 200, headers: { "Content-Type": "application/json" } }); }
function E(m, s) { return J({ message: m }, s || 400); }
function td() { return new Date().toISOString().slice(0, 10); }
function addD(d, n) { var x = new Date(d + "T00:00:00Z"); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); }
function addM(d, n) { var x = new Date(d + "T00:00:00Z"); x.setUTCMonth(x.getUTCMonth() + n); return x.toISOString().slice(0, 10); }
function by(a, id) { return a.filter(function (x) { return String(x.id) === String(id); })[0]; }
function sum(a, f) { return a.reduce(function (s, x) { return s + (f ? f(x) : x); }, 0); }
function r2(x) { return Math.round(x * 100) / 100; }
function counts(l) { return l.status === "settled" || (l.status === "pending" && l.method !== "bank_transfer"); }
function money(x) { return "$" + Number(x).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " "); }
function clean(s) { return String(s == null ? "" : s).replace(/—/g, "-").replace(/[’‘]/g, "'").replace(/[“”]/g, '"').replace(/[^\x20-\x7E\u00A0-\u00FF€]/g, "?"); }
function frDate(d) { if (!d) return "-"; var p = String(d).slice(0, 10).split("-"); return p[2] + "/" + p[1] + "/" + p[0]; }
/* ---------- calculs financiers (identiques à l'API principale) ---------- */
function openCharges(st, tid) {
var ch = st.ledger.filter(function (l) { return l.tenantId === tid && l.kind === "charge"; }).sort(function (a, b) { return a.date < b.date ? -1 : 1; });
var paid = sum(st.ledger.filter(function (l) { return l.tenantId === tid && l.kind === "payment" && counts(l); }), function (l) { return l.amount; });
return ch.map(function (c) { var a = Math.min(c.amount, Math.max(0, paid)); paid -= a; return { date: c.date, amount: r2(c.amount - a) }; }).filter(function (c) { return c.amount > 0.005; });
}
function tenantRow(st, t) {
var u = by(st.units, t.unitId) || {}, p = by(st.properties, u.propertyId) || {}, oc = openCharges(st, t.id), g = (st.settings && st.settings.graceDays) || 5;
var balance = r2(sum(oc, function (c) { return c.amount; })), pastDue = r2(sum(oc.filter(function (c) { return c.date <= addD(td(), -g); }), function (c) { return c.amount; }));
var pays = st.ledger.filter(function (l) { return l.tenantId === t.id && l.kind === "payment" && l.status === "settled"; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
var paidThisMonth = pays.some(function (l) { return l.date.slice(0, 7) === td().slice(0, 7); });
var status = pastDue > 0 ? "En retard" : (balance <= 0 && paidThisMonth ? "Payé" : "À jour");
return { id: t.id, name: t.name, email: t.email || "", property: p.name || "", address: p.address ? p.address + ", " + (p.city || "") : "", unit: u.label || "", rent: t.rent, balance: balance, pastDue: pastDue, status: status, lastPaymentDate: pays[0] ? pays[0].date : null, active: t.active !== false };
}
/* ---------- accès : sessions créées par la fonction api ---------- */
async function authOf(request) {
var tk = (request.headers.get("authorization") || "").replace(/^Bearer /, ""); return tk ? await db.getSession(tk) : null;
}
async function mutate(fn) { // écriture avec contrôle de version (4 tentatives)
for (var i = 0; i < 4; i++) {
var s = await db.getState(); if (!s) return { error: "Application non initialisée" };
var out = fn(s.data); if (out && out.skip) return out;
if (await db.putState(s.data, s.version)) return out || { ok: true };
}
return { error: "Conflit d'écriture" };
}
/* ---------- Stripe ---------- */
function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
function safeEq(a, b) { if (a.length !== b.length) return false; var r = 0; for (var i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
async function verifySignature(raw, header, secret) {
if (!header || !secret) return false;
var parts = header.split(","), t = null, v1 = [];
parts.forEach(function (p) { var kv = p.split("="); if (kv[0] === "t") t = kv[1]; if (kv[0] === "v1") v1.push(kv[1]); });
if (!t || !v1.length || Math.abs(Date.now() / 1000 - Number(t)) > 300) return false;
var key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
var sig = hex(await crypto.subtle.sign("HMAC", key, enc.encode(t + "." + raw)));
return v1.some(function (v) { return safeEq(v, sig); });
}
function allowedReturn(url, request) {
try {
var o = new URL(url).origin, list = (env.APP_URL || "").split(",").map(function (x) { return x.trim().replace(/\/$/, ""); }).filter(Boolean);
return list.length ? list.indexOf(o) >= 0 : o === request.headers.get("origin");
} catch (e) { return false; }
}
async function checkout(request, me, b) {
if (!env.STRIPE_SECRET_KEY) return E("Stripe n'est pas configuré (STRIPE_SECRET_KEY manquante côté serveur).", 503);
var s = await db.getState(); if (!s) return E("Application non initialisée", 500); var st = s.data;
if (st.billing && st.billing.enabled === false) return E("Le paiement par Stripe est désactivé.", 403);
var tid = me.role === "tenant" ? me.partyId : Number(b.tenantId);
if (me.role !== "tenant" && me.role !== "admin") return E("Accès refusé", 403);
var t = by(st.tenants, tid); if (!t) return E("Locataire introuvable", 404);
var row = tenantRow(st, t), amount = row.balance;
if (!(amount > 0)) return E("Aucun solde à payer pour le moment.");
var cents = Math.round(amount * 100); if (cents < 50) return E("Montant inférieur au minimum Stripe (0,50 $).");
if (!allowedReturn(b.returnUrl, request)) return E("URL de retour non autorisée", 400);
var ret = String(b.returnUrl).split("#")[0].split("?")[0];
var f = new URLSearchParams();
f.set("mode", "payment"); f.set("client_reference_id", String(t.id));
f.set("success_url", ret + "?stripe=success&session_id={CHECKOUT_SESSION_ID}"); f.set("cancel_url", ret + "?stripe=cancel");
f.set("line_items[0][quantity]", "1"); f.set("line_items[0][price_data][currency]", "usd"); f.set("line_items[0][price_data][unit_amount]", String(cents));
f.set("line_items[0][price_data][product_data][name]", clean("Loyer - " + t.name + (row.unit ? " (" + row.property + " " + row.unit + ")" : "")));
f.set("metadata[tenant_id]", String(t.id)); f.set("metadata[purpose]", "rent"); f.set("payment_intent_data[metadata][tenant_id]", String(t.id));
if (t.email) f.set("customer_email", t.email);
var r = await fetchImpl("https://api.stripe.com/v1/checkout/sessions", { method: "POST", headers: { Authorization: "Bearer " + env.STRIPE_SECRET_KEY, "Content-Type": "application/x-www-form-urlencoded" }, body: f.toString() });
var d = await r.json(); if (!r.ok) return E("Stripe : " + ((d.error && d.error.message) || "erreur"), 502);
return J({ url: d.url, sessionId: d.id, amount: amount });
}
async function webhook(raw, request) {
if (!env.STRIPE_WEBHOOK_SECRET) return E("Webhook non configuré", 503);
if (!(await verifySignature(raw, request.headers.get("stripe-signature"), env.STRIPE_WEBHOOK_SECRET))) return E("Signature invalide", 400);
var ev; try { ev = JSON.parse(raw); } catch (e) { return E("JSON invalide"); }
if (ev.type !== "checkout.session.completed" && ev.type !== "checkout.session.async_payment_succeeded") return J({ received: true, ignored: ev.type });
var s = ev.data.object; if (s.payment_status !== "paid") return J({ received: true, pending: true });
var tid = Number(s.metadata && s.metadata.tenant_id || s.client_reference_id); if (!tid) return J({ received: true, ignored: "no tenant" });
var out = await mutate(function (st) {
var t = by(st.tenants, tid); if (!t) return { skip: true, reason: "tenant" };
if (st.ledger.some(function (l) { return l.reference === s.id; })) return { skip: true, reason: "duplicate" };
st.seq = (st.seq || 1000) + 1;
st.ledger.push({ id: st.seq, tenantId: tid, kind: "payment", method: "card", date: td(), amount: r2((s.amount_total || 0) / 100), currency: String(s.currency || "usd").toUpperCase(), status: "settled", reference: s.id, memo: "Paiement Stripe", provider: "stripe", paidAt: new Date().toISOString() });
return { ok: true };
});
if (out.error) return E(out.error, 500);
return J({ received: true, result: out.reason || "recorded" });
}
/* ---------- PDF ---------- */
async function reportPdf(st) {
var rows = st.tenants.filter(function (t) { return t.active !== false; }).map(function (t) { return tenantRow(st, t); });
var doc = await PDFDocument.create(), font = await doc.embedFont(StandardFonts.Helvetica), bold = await doc.embedFont(StandardFonts.HelveticaBold);
var W = 842, H = 595, M = 40, ROW = 20, cols = [["Locataire", 40, 130], ["Logement", 175, 190], ["Loyer", 370, 60], ["Solde dû", 435, 70], ["Statut", 510, 70], ["Dernier paiement", 585, 95]], pages = [], page, y;
var totalRent = sum(rows, function (r) { return r.rent || 0; }), totalBal = sum(rows, function (r) { return r.balance; }), late = rows.filter(function (r) { return r.status === "En retard"; }).length;
function newPage(first) {
page = doc.addPage([W, H]); pages.push(page); y = H - M;
if (first) {
page.drawText("Rapport global des locataires", { x: M, y: y - 14, size: 18, font: bold, color: rgb(0.1, 0.1, 0.15) }); y -= 34;
page.drawText(clean("Généré le " + frDate(td()) + "  |  " + rows.length + " locataires  |  Loyers mensuels : " + money(totalRent) + "  |  Soldes dus : " + money(totalBal) + "  |  En retard : " + late), { x: M, y: y, size: 9, font: font, color: rgb(0.35, 0.35, 0.4) }); y -= 22;
}
page.drawRectangle({ x: M - 4, y: y - 5, width: W - 2 * M + 8, height: ROW, color: rgb(0.93, 0.94, 0.96) });
cols.forEach(function (c) { page.drawText(c[0], { x: c[1], y: y, size: 9, font: bold, color: rgb(0.1, 0.1, 0.15) }); }); y -= ROW;
}
function trunc(s, w, sz, f) { s = clean(s); while (s.length > 1 && f.widthOfTextAtSize(s, sz) > w) s = s.slice(0, -1); return s; }
newPage(true);
rows.forEach(function (r, i) {
if (y < M + 30) newPage(false);
if (i % 2) page.drawRectangle({ x: M - 4, y: y - 5, width: W - 2 * M + 8, height: ROW, color: rgb(0.98, 0.98, 0.99) });
var col = r.status === "En retard" ? rgb(0.75, 0.1, 0.1) : r.status === "Payé" ? rgb(0.05, 0.5, 0.25) : rgb(0.15, 0.35, 0.7);
var vals = [r.name, (r.property + (r.unit ? " - " + r.unit : "")), money(r.rent || 0), money(r.balance), r.status, frDate(r.lastPaymentDate)];
cols.forEach(function (c, k) { var isS = k === 4; page.drawText(trunc(vals[k], c[2] - 6, 9, isS ? bold : font), { x: c[1], y: y, size: 9, font: isS ? bold : font, color: isS ? col : rgb(0.1, 0.1, 0.15) }); }); y -= ROW;
});
if (!rows.length) page.drawText("Aucun locataire.", { x: M, y: y, size: 10, font: font });
pages.forEach(function (p, i) { p.drawText("Page " + (i + 1) + " / " + pages.length, { x: W - M - 60, y: 20, size: 8, font: font, color: rgb(0.5, 0.5, 0.55) }); });
return await doc.save();
}
async function receiptPdf(st, pay) {
var t = by(st.tenants, pay.tenantId) || {}, row = tenantRow(st, t), d = pay.date || td(), month = MONTHS[Number(d.slice(5, 7)) - 1] + " " + d.slice(0, 4);
var landlord = (st.payout && st.payout.banks && st.payout.banks[0] && st.payout.banks[0].accountName) || "Le bailleur", no = "Q-" + d.slice(0, 4) + "-" + pay.id;
var doc = await PDFDocument.create(), page = doc.addPage([595, 842]), font = await doc.embedFont(StandardFonts.Helvetica), bold = await doc.embedFont(StandardFonts.HelveticaBold), ink = rgb(0.1, 0.1, 0.15), mute = rgb(0.4, 0.4, 0.45);
page.drawRectangle({ x: 0, y: 782, width: 595, height: 60, color: rgb(0.1, 0.2, 0.4) });
page.drawText("QUITTANCE DE LOYER", { x: 40, y: 805, size: 20, font: bold, color: rgb(1, 1, 1) });
page.drawText(clean("N° " + no), { x: 430, y: 805, size: 11, font: font, color: rgb(1, 1, 1) });
var y = 735;
function line(label, value) { page.drawText(clean(label), { x: 40, y: y, size: 10, font: font, color: mute }); page.drawText(clean(value), { x: 190, y: y, size: 11, font: bold, color: ink }); y -= 26; }
line("Bailleur", landlord); line("Locataire", t.name || ""); line("Logement", (row.property || "") + (row.unit ? " - " + row.unit : "")); if (row.address) line("Adresse", row.address);
line("Période", month); line("Date du paiement", frDate(d)); line("Mode de paiement", pay.method === "card" ? "Carte bancaire (Stripe)" : String(pay.method || "")); line("Référence", String(pay.reference || "").slice(0, 40));
y -= 6; page.drawRectangle({ x: 40, y: y - 40, width: 515, height: 56, color: rgb(0.94, 0.96, 0.99) });
page.drawText("Montant reçu", { x: 55, y: y - 12, size: 10, font: font, color: mute }); page.drawText(money(pay.amount), { x: 55, y: y - 34, size: 22, font: bold, color: rgb(0.05, 0.4, 0.2) }); y -= 80;
var txt = clean("Je soussigné(e), " + landlord + ", reconnais avoir reçu de " + (t.name || "") + " la somme de " + money(pay.amount) + " au titre du loyer de " + month + ", et lui en donne quittance, sous réserve de tous mes droits.");
var words = txt.split(" "), cur = ""; words.forEach(function (w) { var n = cur ? cur + " " + w : w; if (font.widthOfTextAtSize(n, 10) > 515) { page.drawText(cur, { x: 40, y: y, size: 10, font: font, color: ink }); y -= 16; cur = w; } else cur = n; }); if (cur) { page.drawText(cur, { x: 40, y: y, size: 10, font: font, color: ink }); y -= 16; }
page.drawText(clean("Document généré automatiquement le " + frDate(td()) + " - valable sans signature."), { x: 40, y: 40, size: 8, font: font, color: mute });
return { bytes: await doc.save(), no: no };
}
function pdfRes(bytes, name) { return new Response(bytes, { status: 200, headers: { "Content-Type": "application/pdf", "Content-Disposition": 'attachment; filename="' + name + '"', "Cache-Control": "no-store" } }); }
/* ---------- Mobile Money via pawaPay (agrégateur RDC : Airtel, Orange, Vodacom M-Pesa) ---------- */
var OPS = { airtel: { provider: "AIRTEL_COD", method: "airtel_money", label: "Airtel Money" }, orange: { provider: "ORANGE_COD", method: "orange_money", label: "Orange Money" }, mpesa: { provider: "VODACOM_MPESA_COD", method: "mpesa", label: "M-Pesa" } };
function msisdn(p) { var d = String(p || "").replace(/\D/g, ""); if (d.indexOf("243") === 0) return d; if (d.charAt(0) === "0") return "243" + d.slice(1); return d.length === 9 ? "243" + d : d; }
function pawaBase() { return env.PAWAPAY_ENV === "live" ? "https://api.pawapay.io" : "https://api.sandbox.pawapay.io"; }
async function pawa(path, method, body) {
var r = await fetchImpl(pawaBase() + path, { method: method || "GET", headers: { Authorization: "Bearer " + env.PAWAPAY_API_TOKEN, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
var d = {}; try { d = await r.json(); } catch (e) {} return { ok: r.ok, d: d };
}
function mobileCfg(st) { var m = (st.billing && st.billing.mobile) || {}; return { enabled: m.enabled !== false, operators: Object.assign({ airtel: true, orange: true, mpesa: true }, m.operators || {}), currencies: m.currencies && m.currencies.length ? m.currencies : ["USD", "CDF"] }; }
async function mobileInit(me, b) {
if (!env.PAWAPAY_API_TOKEN) return E("Mobile Money n'est pas configuré (PAWAPAY_API_TOKEN manquant côté serveur).", 503);
var s = await db.getState(); if (!s) return E("Application non initialisée", 500); var st = s.data, cfg = mobileCfg(st);
if (!cfg.enabled) return E("Le paiement Mobile Money est désactivé.", 403);
var tid = me.role === "tenant" ? me.partyId : Number(b.tenantId), t = by(st.tenants, tid); if (!t) return E("Locataire introuvable", 404);
if (t.active === false) return E("Locataire inactif : paiement impossible.", 409);
var op = OPS[b.operator]; if (!op || !cfg.operators[b.operator]) return E("Opérateur non disponible.");
var cur = String(b.currency || "USD").toUpperCase(); if (cfg.currencies.indexOf(cur) < 0) return E("Devise non disponible.");
var phone = msisdn(b.phone); if (!/^243\d{9}$/.test(phone)) return E("Numéro invalide : utilisez le format 0XXXXXXXXX ou 243XXXXXXXXX.");
var row = tenantRow(st, t), usd = row.balance; if (!(usd > 0)) return E("Aucun solde à payer pour le moment.");
var fx = (st.fx && st.fx.cdfPerUsd) || 2800, local = cur === "CDF" ? Math.round(usd * fx) : usd, amountStr = cur === "CDF" ? String(local) : local.toFixed(2);
var id = crypto.randomUUID(), ym = td().slice(0, 7).replace("-", "");
var r = await pawa("/v2/deposits", "POST", { depositId: id, amount: amountStr, currency: cur, payer: { type: "MMO", accountDetails: { phoneNumber: phone, provider: op.provider } }, clientReferenceId: "RENT-" + t.id + "-" + ym, customerMessage: "Loyer Keystone" });
if (!r.ok || r.d.status !== "ACCEPTED") return E("pawaPay : " + ((r.d.failureReason && (r.d.failureReason.failureMessage || r.d.failureReason.failureCode)) || "demande refusée"), 502);
var res = await mutate(function (x) { x.deposits = x.deposits || {}; x.deposits[id] = { tenantId: t.id, usd: usd, amount: local, currency: cur, fx: fx, operator: b.operator, method: op.method, phone: "***" + phone.slice(-4), status: "PENDING", createdAt: new Date().toISOString() }; });
if (res.error) return E(res.error, 500);
return J({ depositId: id, status: "PENDING", operator: op.label, message: "Validez le paiement sur votre téléphone (code secret " + op.label + ")." });
}
async function mobileSettle(id) { // ne fait JAMAIS confiance au callback : le statut est relu chez pawaPay
var s = await db.getState(); var rec = s && s.data.deposits && s.data.deposits[id]; if (!rec) return { status: "UNKNOWN" };
if (rec.status !== "PENDING") return { status: rec.status, reason: rec.reason };
if (!env.PAWAPAY_API_TOKEN) return { status: "PENDING" };
var r = await pawa("/v2/deposits/" + encodeURIComponent(id)); var data = r.ok && r.d.status === "FOUND" ? r.d.data : null; if (!data) return { status: "PENDING" };
if (data.status === "COMPLETED") {
if (data.currency !== rec.currency || Math.abs(Number(data.amount) - Number(rec.amount)) > 0.01) { await mutate(function (x) { x.deposits[id].status = "FAILED"; x.deposits[id].reason = "Montant ou devise différent de la demande"; }); return { status: "FAILED", reason: "Montant incohérent" }; }
await mutate(function (x) {
var d = x.deposits[id]; if (d.status === "COMPLETED") return { skip: true };
if (!x.ledger.some(function (l) { return l.reference === id; })) { x.seq = (x.seq || 1000) + 1; var p = { id: x.seq, tenantId: d.tenantId, kind: "payment", method: d.method, date: td(), amount: d.usd, currency: d.currency, status: "settled", reference: id, memo: "Mobile Money (pawaPay)", provider: "pawapay", paidAt: new Date().toISOString() }; if (d.currency === "CDF") { p.amountFc = d.amount; p.fxRate = d.fx; } x.ledger.push(p); }
d.status = "COMPLETED";
});
return { status: "COMPLETED" };
}
if (data.status === "FAILED" || data.status === "REJECTED") { var why = (data.failureReason && (data.failureReason.failureMessage || data.failureReason.failureCode)) || "Paiement refusé ou expiré"; await mutate(function (x) { x.deposits[id].status = "FAILED"; x.deposits[id].reason = why; }); return { status: "FAILED", reason: why }; }
return { status: "PENDING" };
}
/* ---------- mots de passe + réinitialisation par e-mail (Resend) ---------- */
function b64(buf) { var a = new Uint8Array(buf), t = ""; for (var i = 0; i < a.length; i++) t += String.fromCharCode(a[i]); return btoa(t); }
async function hashPw(pw) { var salt = crypto.getRandomValues(new Uint8Array(16)), k = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]); return "pbkdf2$100000$" + b64(salt) + "$" + b64(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: salt, iterations: 100000 }, k, 256)); }
async function sha256(t) { return hex(await crypto.subtle.digest("SHA-256", enc.encode(t))); }
function appBase(request) { var l = (env.APP_URL || "").split(",").map(function (x) { return x.trim().replace(/\/$/, ""); }).filter(Boolean); return l[0] || ""; }
async function sendMail(to, subject, html, text) {
if (!env.RESEND_API_KEY || !env.RESEND_FROM) return { ok: false, reason: "Resend non configuré" };
var r = await fetchImpl("https://api.resend.com/emails", { method: "POST", headers: { Authorization: "Bearer " + env.RESEND_API_KEY, "Content-Type": "application/json" }, body: JSON.stringify({ from: env.RESEND_FROM, to: [to], subject: subject, html: html, text: text }) });
return { ok: r.ok };
}
function findAccount(st, ident) {
var l = String(ident || "").trim().toLowerCase(); if (!l) return null;
var adminEmail = (st.admin.email || env.ADMIN_EMAIL || "").toLowerCase();
if (l === String(st.admin.login).toLowerCase() || (adminEmail && l === adminEmail)) return adminEmail ? { kind: "admin", login: st.admin.login, email: adminEmail, name: "Administrateur" } : null;
var a = (st.access || []).filter(function (x) { var party = by(x.role === "tenant" ? st.tenants : st.vendors, x.partyId) || {}; return x.login.toLowerCase() === l || (party.email || "").toLowerCase() === l; })[0]; if (!a) return null;
var p = by(a.role === "tenant" ? st.tenants : st.vendors, a.partyId) || {}; if (a.role === "tenant" && p.active === false) return null;
return p.email ? { kind: "access", login: a.login, email: p.email, name: p.name } : null;
}
async function forgot(request, b) {
var generic = J({ ok: true, message: "Si ce compte existe et possède une adresse e-mail, un lien de réinitialisation vient d'être envoyé." });
var base = appBase(request); if (!base || !env.RESEND_API_KEY) return E("La réinitialisation par e-mail n'est pas encore configurée. Contactez le gestionnaire.", 503);
var s = await db.getState(); if (!s) return generic; var acc = findAccount(s.data, b.login || b.email); if (!acc) return generic;
var token = hex(crypto.getRandomValues(new Uint8Array(32))), h = await sha256(token), now = Date.now(), blocked = false;
var res = await mutate(function (st) {
st.resets = st.resets || {}; Object.keys(st.resets).forEach(function (k) { if (st.resets[k].exp < now) delete st.resets[k]; });
if (Object.keys(st.resets).filter(function (k) { return st.resets[k].login === acc.login && st.resets[k].exp - 3600000 > now - 3600000; }).length >= 3) { blocked = true; return { skip: true }; }
st.resets[h] = { kind: acc.kind, login: acc.login, exp: now + 3600000 };
});
if (blocked || res.error) return generic;
var link = base + "/?reset=" + token;
var html = '<div style="font-family:Arial,sans-serif;max-width:480px"><h2>Réinitialisation de votre mot de passe</h2><p>Bonjour ' + clean(acc.name) + ',</p><p>Vous avez demandé à réinitialiser votre mot de passe Keystone. Ce lien est valable <b>1 heure</b> et ne peut être utilisé qu\'une seule fois.</p><p><a href="' + link + '" style="background:#1d4ed8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block">Choisir un nouveau mot de passe</a></p><p style="color:#666;font-size:12px">Si vous n\'êtes pas à l\'origine de cette demande, ignorez ce message : votre mot de passe reste inchangé.</p></div>';
await sendMail(acc.email, "Réinitialisation de votre mot de passe Keystone", html, "Pour choisir un nouveau mot de passe (valable 1 heure) : " + link);
return generic;
}
async function resetPassword(b) {
var token = String(b.token || ""), pw = String(b.password || ""); if (pw.length < 8) return E("Le mot de passe doit contenir au moins 8 caractères.");
if (!/^[0-9a-f]{64}$/.test(token)) return E("Lien invalide ou expiré.", 400);
var h = await sha256(token), hashed = await hashPw(pw), login = null, bad = false;
var res = await mutate(function (st) {
var r = st.resets && st.resets[h]; if (!r || r.exp < Date.now()) { bad = true; return { skip: true }; }
if (r.kind === "admin") { st.admin.hash = hashed; st.admin.mustChange = false; } else { var a = (st.access || []).filter(function (x) { return x.login === r.login; })[0]; if (!a) { bad = true; return { skip: true }; } a.hash = hashed; a.mustChange = false; }
if (st.fails) delete st.fails[String(r.login).toLowerCase()]; delete st.resets[h]; login = r.login;
});
if (bad || res.error) return E("Lien invalide ou expiré.", 400);
await db.delSessionsByLogin(login); return J({ ok: true });
}
/* ---------- cycle de vie des locataires : départ, retour, remplacement ---------- */
function logHist(st, e) { st.history = st.history || []; st.seq = (st.seq || 1000) + 1; st.history.push(Object.assign({ id: st.seq, at: new Date().toISOString() }, e)); }
function moveOut(st, t, date, reason) {
t.active = false; t.moveOutDate = date || td(); t.moveOutReason = String(reason || "").slice(0, 200);
var i = (st.access || []).findIndex(function (a) { return a.role === "tenant" && a.partyId === t.id; });
if (i >= 0) { t.savedAccess = st.access[i]; st.access.splice(i, 1); }
logHist(st, { type: "move_out", tenantId: t.id, unitId: t.unitId, date: t.moveOutDate, reason: t.moveOutReason, balance: tenantRow(st, Object.assign({}, t, { active: true })).balance });
}
async function tenantsAll() {
var s = await db.getState(), st = s.data;
return st.tenants.map(function (t) { var r = tenantRow(st, Object.assign({}, t, { active: true })), u = by(st.units, t.unitId) || {}; return { id: t.id, name: t.name, email: t.email || "", phone: t.phone || "", unitId: t.unitId, unit: u.label || "", property: r.property, rent: t.rent, active: t.active !== false, leaseStart: t.leaseStart, moveOutDate: t.moveOutDate || null, moveOutReason: t.moveOutReason || "", balance: r.balance, payments: st.ledger.filter(function (l) { return l.tenantId === t.id && l.kind === "payment" && l.status === "settled"; }).length }; });
}
async function deactivate(id, b) {
var out = { err: null, balance: 0 }; var res = await mutate(function (st) {
var t = by(st.tenants, id); if (!t) { out.err = ["Locataire introuvable", 404]; return { skip: true }; } if (t.active === false) { out.err = ["Ce locataire est déjà inactif.", 409]; return { skip: true }; }
out.balance = tenantRow(st, t).balance; moveOut(st, t, b.moveOutDate, b.reason);
});
if (out.err) return E(out.err[0], out.err[1]); if (res.error) return E(res.error, 500);
var s = await db.getState(), t = by(s.data.tenants, id); if (t.savedAccess) await db.delSessionsByLogin(t.savedAccess.login);
return J({ ok: true, balanceDue: out.balance });
}
async function reactivate(id, b) {
var err = null; var res = await mutate(function (st) {
var t = by(st.tenants, id); if (!t) { err = ["Locataire introuvable", 404]; return { skip: true }; } if (t.active !== false) { err = ["Ce locataire est déjà actif.", 409]; return { skip: true }; }
var uid = Number(b.unitId) || t.unitId, u = by(st.units, uid); if (!u) { err = ["Unité introuvable", 404]; return { skip: true }; }
if (st.tenants.some(function (x) { return x.id !== t.id && x.unitId === uid && x.active !== false; })) { err = ["Cette unité est occupée : choisissez une autre unité ou désactivez le locataire actuel.", 409]; return { skip: true }; }
t.active = true; t.unitId = uid; t.leaseStart = b.leaseStart || td(); t.leaseMonths = Number(b.leaseMonths) || t.leaseMonths || 12; delete t.moveOutDate; delete t.moveOutReason;
if (t.savedAccess) { st.access = st.access || []; st.access.push(t.savedAccess); delete t.savedAccess; }
logHist(st, { type: "reactivated", tenantId: t.id, unitId: uid, date: td() });
});
if (err) return E(err[0], err[1]); if (res.error) return E(res.error, 500); return J({ ok: true });
}
async function replaceTenant(unitId, b) {
var err = null, created = null, outgoing = null; var nt = b.newTenant || {};
var res = await mutate(function (st) {
var u = by(st.units, unitId); if (!u) { err = ["Unité introuvable", 404]; return { skip: true }; }
if (!String(nt.name || "").trim()) { err = ["Le nom du nouveau locataire est requis."]; return { skip: true }; }
var cur = st.tenants.filter(function (x) { return x.unitId === u.id && x.active !== false; })[0];
if (cur) { moveOut(st, cur, b.moveOutDate, b.reason || "Remplacé par un nouveau locataire"); outgoing = cur.id; }
st.seq = (st.seq || 1000) + 1; created = { id: st.seq, name: String(nt.name).trim(), phone: nt.phone || "", email: nt.email || "", unitId: u.id, leaseStart: nt.leaseStart || td(), leaseMonths: Number(nt.leaseMonths) || 12, rent: Number(nt.rent) || u.marketRent || 0, deposit: Number(nt.deposit) || 0, payMethod: nt.payMethod || "mpesa", autopay: false, active: true };
st.tenants.push(created); logHist(st, { type: "move_in", tenantId: created.id, unitId: u.id, date: created.leaseStart, replaced: outgoing });
});
if (err) return E(err[0], err[1] || 400); if (res.error) return E(res.error, 500);
if (outgoing) { var s = await db.getState(), o = by(s.data.tenants, outgoing); if (o && o.savedAccess) await db.delSessionsByLogin(o.savedAccess.login); }
return J({ ok: true, outgoing: outgoing, incoming: created.id });
}
/* ---------- routeur ---------- */
async function run(request) {
var u = new URL(request.url), p = u.pathname.replace(/^.*?\/billing\/?/, "").split("/").filter(Boolean), m = request.method, route = p[0] || "", sub = p[1] || "";
if (route === "webhook" && m === "POST") return webhook(await request.text(), request);
if (route === "pay" && sub === "callback" && m === "POST") { var cb = {}; try { cb = await request.json(); } catch (e) {} if (cb.depositId) await mobileSettle(String(cb.depositId)); return J({ received: true }); }
if (route === "auth" && m === "POST") { var ab = {}; try { ab = await request.json(); } catch (e) {} if (sub === "forgot") return forgot(request, ab); if (sub === "reset") return resetPassword(ab); }
var me = await authOf(request); if (!me) return E("Non connecté", 401);
var admin = me.role === "admin";
if (route === "checkout" && m === "POST") { var b = {}; try { b = await request.json(); } catch (e) {} return checkout(request, me, b); }
if (route === "pay") {
if (sub === "options" && m === "GET") { var so = await db.getState(), mc = mobileCfg(so.data); return J({ stripe: !!env.STRIPE_SECRET_KEY && !(so.data.billing && so.data.billing.enabled === false), mobile: !!env.PAWAPAY_API_TOKEN && mc.enabled, operators: Object.keys(OPS).filter(function (k) { return mc.operators[k]; }).map(function (k) { return { key: k, label: OPS[k].label }; }), currencies: mc.currencies }); }
if (sub === "mobile" && m === "POST") { var mb = {}; try { mb = await request.json(); } catch (e) {} return mobileInit(me, mb); }
if (sub === "status" && m === "GET") { var did = p[2] || "", sd = await db.getState(), rec = sd.data.deposits && sd.data.deposits[did]; if (!rec) return E("Paiement introuvable", 404); if (!admin && !(me.role === "tenant" && me.partyId === rec.tenantId)) return E("Accès refusé", 403); return J(await mobileSettle(did)); }
}
if (route === "documents" && m === "GET") {
var s0 = await db.getState(), tid = admin ? Number(u.searchParams.get("tenantId")) : me.role === "tenant" ? me.partyId : 0; if (!tid) return J([]);
var t0 = by(s0.data.tenants, tid); if (!t0 || t0.active === false) return J([]);
return J(s0.data.ledger.filter(function (l) { return l.tenantId === tid && l.kind === "payment" && l.status === "settled"; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }).map(function (l) { return { id: l.id, date: l.date, amount: l.amount, method: l.method, reference: l.reference, number: "Q-" + l.date.slice(0, 4) + "-" + l.id, label: "Quittance de loyer - " + MONTHS[Number(l.date.slice(5, 7)) - 1] + " " + l.date.slice(0, 4) }; }));
}
if (route === "receipt" && m === "GET") {
var s1 = await db.getState(), pay = by(s1.data.ledger.filter(function (l) { return l.kind === "payment"; }), String(p[1] || "").replace(/\.pdf$/, ""));
if (!pay || pay.status !== "settled") return E("Quittance introuvable", 404);
var ptn = by(s1.data.tenants, pay.tenantId); if (!ptn || ptn.active === false) return E("Impression désactivée : locataire inactif.", 409);
if (!admin && !(me.role === "tenant" && me.partyId === pay.tenantId)) return E("Accès refusé", 403);
var rc = await receiptPdf(s1.data, pay); return pdfRes(rc.bytes, rc.no + ".pdf");
}
if (!admin) return E("Réservé à l'administrateur", 403);
var body = {}; if (m === "POST" || m === "PUT") { try { body = await request.json(); } catch (e) {} }
if (route === "config") {
if (m === "PUT") { var res = await mutate(function (st) { var mo = body.mobile || {}; st.billing = Object.assign({ enabled: true, currency: "usd" }, st.billing || {}, { enabled: body.enabled !== false, label: String(body.label || "").slice(0, 80), notes: String(body.notes || "").slice(0, 300), mobile: { enabled: mo.enabled !== false, operators: { airtel: !mo.operators || mo.operators.airtel !== false, orange: !mo.operators || mo.operators.orange !== false, mpesa: !mo.operators || mo.operators.mpesa !== false }, currencies: (mo.currencies || ["USD", "CDF"]).filter(function (c) { return c === "USD" || c === "CDF"; }) } }); if (typeof body.adminEmail === "string") { var em = body.adminEmail.trim(); if (em && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return { skip: true, bad: true }; st.admin.email = em; } }); if (res.bad) return E("Adresse e-mail invalide."); if (res.error) return E(res.error, 500); }
var s2 = await db.getState(), st2 = s2.data, base = u.origin + u.pathname.replace(/\/billing.*$/, "/billing"), mc2 = mobileCfg(st2);
return J({ enabled: !st2.billing || st2.billing.enabled !== false, label: (st2.billing && st2.billing.label) || "", notes: (st2.billing && st2.billing.notes) || "", currency: "usd", webhookUrl: base + "/webhook", events: ["checkout.session.completed", "checkout.session.async_payment_succeeded"], adminEmail: st2.admin.email || "", mobile: { enabled: mc2.enabled, operators: mc2.operators, currencies: mc2.currencies, callbackUrl: base + "/pay/callback", env: env.PAWAPAY_ENV === "live" ? "live" : "sandbox" }, secrets: { STRIPE_SECRET_KEY: !!env.STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET: !!env.STRIPE_WEBHOOK_SECRET, APP_URL: !!env.APP_URL, PAWAPAY_API_TOKEN: !!env.PAWAPAY_API_TOKEN, RESEND_API_KEY: !!env.RESEND_API_KEY, RESEND_FROM: !!env.RESEND_FROM } });
}
if (route === "status" && m === "GET") { var s3 = await db.getState(); var rows = s3.data.tenants.filter(function (t) { return t.active !== false; }).map(function (t) { return tenantRow(s3.data, t); }); return J({ rows: rows, totals: { tenants: rows.length, paid: rows.filter(function (r) { return r.status === "Payé"; }).length, upToDate: rows.filter(function (r) { return r.status === "À jour"; }).length, late: rows.filter(function (r) { return r.status === "En retard"; }).length, balance: r2(sum(rows, function (r) { return r.balance; })) } }); }
if (route === "report.pdf" && m === "GET") { var s4 = await db.getState(); return pdfRes(await reportPdf(s4.data), "rapport-locataires-" + td() + ".pdf"); }
if (route === "tenants" && m === "GET" && sub === "all") return J(await tenantsAll());
if (route === "tenants" && m === "GET" && sub === "history") { var s5 = await db.getState(); return J((s5.data.history || []).slice().reverse().map(function (h) { var t = by(s5.data.tenants, h.tenantId) || {}, u2 = by(s5.data.units, h.unitId) || {}, p2 = by(s5.data.properties, u2.propertyId) || {}; return Object.assign({}, h, { tenant: t.name || "?", unit: u2.label || "", property: p2.name || "" }); })); }
if (route === "tenants" && m === "POST" && p[2] === "deactivate") return deactivate(Number(sub), body);
if (route === "tenants" && m === "POST" && p[2] === "reactivate") return reactivate(Number(sub), body);
if (route === "units" && m === "POST" && p[2] === "replace-tenant") return replaceTenant(Number(sub), body);
return E("Route inconnue", 404);
}
return { run: run, verifySignature: verifySignature };
}
const SB = Deno.env.get("SUPABASE_URL"), KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
const HD = { apikey: KEY, Authorization: "Bearer " + KEY, "Content-Type": "application/json" };
async function rest(path, init = {}) {
const r = await fetch(SB + "/rest/v1/" + path, { ...init, headers: { ...HD, ...(init.headers || {}) } });
if (!r.ok) throw new Error("db " + r.status + " " + (await r.text()));
const t = await r.text(); return t ? JSON.parse(t) : null;
}
const db = {
async getState() { const r = await rest("app_state?id=eq.main&select=data,version"); return r && r[0] ? r[0] : null; },
async putState(d, v) { const r = await rest("app_state?id=eq.main&version=eq." + v, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ data: d, version: v + 1, updated_at: new Date().toISOString() }) }); return !!(r && r.length); },
async delSessionsByLogin(l) { await rest("app_sessions?user_data-%3E%3Elogin=eq." + encodeURIComponent(l), { method: "DELETE" }); },
async getSession(t) { const r = await rest("app_sessions?token=eq." + encodeURIComponent(t) + "&expires_at=gt." + encodeURIComponent(new Date().toISOString()) + "&select=user_data"); return r && r[0] ? r[0].user_data : null; }
};
const env = { STRIPE_SECRET_KEY: Deno.env.get("STRIPE_SECRET_KEY"), STRIPE_WEBHOOK_SECRET: Deno.env.get("STRIPE_WEBHOOK_SECRET"), APP_URL: Deno.env.get("APP_URL"), PAWAPAY_API_TOKEN: Deno.env.get("PAWAPAY_API_TOKEN"), PAWAPAY_ENV: Deno.env.get("PAWAPAY_ENV"), RESEND_API_KEY: Deno.env.get("RESEND_API_KEY"), RESEND_FROM: Deno.env.get("RESEND_FROM"), ADMIN_EMAIL: Deno.env.get("ADMIN_EMAIL") };
const billing = createBilling(db, env, fetch, { PDFDocument, StandardFonts, rgb });
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type, x-client-info, apikey, stripe-signature", "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS", "Access-Control-Expose-Headers": "Content-Disposition", "Access-Control-Max-Age": "86400" };
Deno.serve(async (req) => {
if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
let r; try { r = await billing.run(req); } catch (e) { r = new Response(JSON.stringify({ message: String(e && e.message || e) }), { status: 500, headers: { "Content-Type": "application/json" } }); }
const h = new Headers(r.headers); for (const k in CORS) h.set(k, CORS[k]);
return new Response(r.body, { status: r.status, headers: h });
});
