// Supabase Edge Function: nexora-admin-users
// Deploy as: supabase/functions/nexora-admin-users/index.ts
// Required function secrets: SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status,
      headers: { ...cors, "Content-Type": "application/json" },
    });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (!token) return json({ error: "Unauthorized" }, 401);

    const url = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    if (!url || !anonKey || !serviceKey) {
      return json({ error: "Function secrets are not configured" }, 500);
    }

    const userClient = createClient(url, anonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } },
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: authData, error: authError } = await userClient.auth.getUser(token);
    if (authError || !authData.user) return json({ error: "Invalid session" }, 401);

    const { data: admin, error: adminError } = await userClient
      .from("nexora_admins")
      .select("user_id")
      .eq("user_id", authData.user.id)
      .maybeSingle();
    if (adminError) return json({ error: "Could not verify admin access" }, 403);
    if (!admin) return json({ error: "Forbidden" }, 403);

    const adminClient = createClient(url, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const users: Array<Record<string, unknown>> = [];
    for (let page = 1; page <= 10; page++) {
      const { data, error } = await adminClient.auth.admin.listUsers({
        page,
        perPage: 100,
      });
      if (error) return json({ error: "Could not load registered accounts" }, 500);
      users.push(...data.users.map((u) => ({
        id: u.id,
        email: u.email ?? null,
        created_at: u.created_at,
        last_sign_in_at: u.last_sign_in_at ?? null,
      })));
      if (data.users.length < 100) break;
    }

    users.sort((a, b) =>
      String(b.created_at || "").localeCompare(String(a.created_at || ""))
    );
    return json({ total: users.length, users });
  } catch (_error) {
    return json({ error: "Unexpected server error" }, 500);
  }
});
