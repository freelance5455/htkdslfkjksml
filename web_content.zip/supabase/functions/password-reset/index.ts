Deno.serve(async (req) => {
  const url = new URL(req.url);
  const tokenHash = url.searchParams.get('token_hash');
  const type = url.searchParams.get('type') || 'recovery';

  if (!tokenHash) {
    return new Response(
      'Missing password reset token. Please request a new password reset email.',
      {
        status: 400,
        headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
      },
    );
  }

  const deepLink = `dpm://reset-password?token_hash=${encodeURIComponent(tokenHash)}&type=${encodeURIComponent(type)}`;

  return Response.redirect(deepLink, 302);
});
