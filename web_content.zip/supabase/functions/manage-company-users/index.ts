import { createClient } from "npm:@supabase/supabase-js@2"
import { corsHeaders } from "jsr:@supabase/supabase-js@2/cors"

const URL = Deno.env.get("SUPABASE_URL") ?? ""
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
const admin = createClient(URL, SERVICE, { auth: { persistSession: false, autoRefreshToken: false } })
const headers = { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" }
const dbRoles = new Set(["OWNER","ADMIN","FINANCE","ACCOUNTANT","SALES","PURCHASE","CASHIER","WAREHOUSE","AUDITOR","VIEWER"])
const validEmail = (e:string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)
const validPassword = (p:unknown) => typeof p === "string" && p.length >= 8 && /[A-Za-z]/.test(p) && /[0-9]/.test(p)

async function currentUser(req:Request){
  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i,"")
  if(!token) throw new Error("نشست کاربر پیدا نشد")
  const {data,error} = await admin.auth.getUser(token)
  if(error || !data.user) throw new Error("نشست احراز هویت معتبر نیست")
  return data.user
}

async function profile(companyId:string,userId:string){
  const {data,error}=await admin.from("company_user_profiles").select("*").eq("company_id",companyId).eq("user_id",userId).maybeSingle()
  if(error) throw error
  return data
}

async function requireManager(companyId:string,userId:string){
  const {data:member,error}=await admin.from("company_members").select("*").eq("company_id",companyId).eq("user_id",userId).maybeSingle()
  if(error) throw error
  if(!member?.is_active) throw new Error("حساب کاربر غیرفعال است")
  if(["OWNER","ADMIN"].includes(member.role)) return member
  const p=await profile(companyId,userId)
  const perms=Array.isArray(p?.permission_keys)?p.permission_keys:[]
  if(perms.includes("us")) return member
  throw new Error("فقط مدیر سیستم یا کاربر دارای دسترسی «کاربران و دسترسی‌ها» مجاز است")
}

async function audit(userId:string,companyId:string,action:string,targetId:string|null,oldData:unknown,newData:unknown){
  const {data:device}=await admin.from("devices").select("id").eq("company_id",companyId).eq("user_id",userId).eq("is_active",true).order("last_seen_at",{ascending:false}).limit(1).maybeSingle()
  const {error}=await admin.from("audit_logs").insert({
    company_id:companyId,user_id:userId,device_id:device?.id??null,action,
    table_name:"company_user_profiles",record_id:targetId,
    old_data:oldData??null,new_data:newData??null,reason:"مدیریت کاربر از داخل اپلیکیشن"
  })
  if(error) console.warn("audit:",error.message)
}

async function listUsers(companyId:string){
  const {data:members,error}=await admin.from("company_members").select("id,user_id,role,is_active,created_at").eq("company_id",companyId).order("created_at",{ascending:true})
  if(error) throw error
  const out=[]
  for(const m of members??[]){
    const [{data:auth,error:ae},{data:p,error:pe}]=await Promise.all([
      admin.auth.admin.getUserById(m.user_id),
      admin.from("company_user_profiles").select("*").eq("company_id",companyId).eq("user_id",m.user_id).maybeSingle()
    ])
    if(ae) throw ae
    if(pe) throw pe
    const u=auth?.user
    out.push({
      member_id:m.id,user_id:m.user_id,email:u?.email??"",email_confirmed:!!u?.email_confirmed_at,
      last_sign_in_at:u?.last_sign_in_at??null,role:m.role,is_active:m.is_active,created_at:m.created_at,
      name:p?.display_name??u?.user_metadata?.name??u?.email??"",job_title:p?.job_title??"",
      role_key:p?.role_key??"ناظر",permission_keys:Array.isArray(p?.permission_keys)?p.permission_keys:[],
      force_password_change:u?.user_metadata?.mrk_force_password_change===true
    })
  }
  return out
}

Deno.serve(async(req:Request)=>{
  if(req.method==="OPTIONS") return new Response("ok",{headers})
  try{
    const me=await currentUser(req)
    const body=await req.json().catch(()=>({}))
    const companyId=String(body.companyId??"")
    if(!companyId) throw new Error("شناسه شرکت الزامی است")
    await requireManager(companyId,me.id)
    const action=String(body.action??"")

    if(action==="list") return new Response(JSON.stringify({ok:true,users:await listUsers(companyId)}),{status:200,headers})

    if(action==="create"){
      const email=String(body.email??"").trim().toLowerCase()
      const password=String(body.password??"")
      const name=String(body.name??"").trim()
      const jobTitle=String(body.jobTitle??"").trim()
      const roleKey=String(body.roleKey??"ناظر")
      const permissions=Array.isArray(body.permissionKeys)?body.permissionKeys.filter((x:unknown)=>typeof x==="string"):[]
      const requestedDbRole=String(body.dbRole??"VIEWER")
      const dbRole=dbRoles.has(requestedDbRole)?requestedDbRole:"VIEWER"
      const isActive=body.isActive===undefined?true:!!body.isActive
      if(!validEmail(email)) throw new Error("ایمیل معتبر نیست")
      if(!validPassword(password)) throw new Error("رمز باید حداقل ۸ کاراکتر و شامل حرف و عدد باشد")
      if(!name) throw new Error("نام کاربر الزامی است")
      const cu=await admin.auth.admin.createUser({
        email,password,email_confirm:true,ban_duration:isActive?"none":"876000h",
        user_metadata:{name,mrk_password_initialized:false,mrk_force_password_change:true}
      })
      if(cu.error||!cu.data.user) throw cu.error??new Error("ساخت حساب ابری ناموفق بود")
      const target=cu.data.user
      const {error:meErr}=await admin.from("company_members").insert({company_id:companyId,user_id:target.id,role:dbRole,is_active:isActive})
      if(meErr){await admin.auth.admin.deleteUser(target.id);throw meErr}
      const {error:peErr}=await admin.from("company_user_profiles").insert({
        company_id:companyId,user_id:target.id,display_name:name,job_title:jobTitle,role_key:roleKey,permission_keys:permissions,is_active:isActive
      })
      if(peErr){await admin.from("company_members").delete().eq("company_id",companyId).eq("user_id",target.id);await admin.auth.admin.deleteUser(target.id);throw peErr}
      await audit(me.id,companyId,"ایجاد کاربر",target.id,null,{email,name,jobTitle,roleKey,dbRole,is_active:isActive})
      return new Response(JSON.stringify({ok:true,user:(await listUsers(companyId)).find(x=>x.user_id===target.id),temporary_password:password}),{status:200,headers})
    }

    if(action==="update"){
      const targetId=String(body.userId??"")
      if(!targetId) throw new Error("شناسه کاربر الزامی است")
      const {data:member,error:meErr}=await admin.from("company_members").select("*").eq("company_id",companyId).eq("user_id",targetId).maybeSingle()
      if(meErr) throw meErr
      if(!member) throw new Error("کاربر عضو شرکت نیست")
      const before=await profile(companyId,targetId)
      const authR=await admin.auth.admin.getUserById(targetId)
      if(authR.error||!authR.data.user) throw authR.error??new Error("حساب Auth پیدا نشد")
      const existingMd=authR.data.user.user_metadata??{}
      const email=body.email===undefined?undefined:String(body.email).trim().toLowerCase()
      const password=body.password===undefined?undefined:String(body.password)
      const name=body.name===undefined?undefined:String(body.name).trim()
      const jobTitle=body.jobTitle===undefined?undefined:String(body.jobTitle).trim()
      const roleKey=body.roleKey===undefined?undefined:String(body.roleKey)
      const permissions=body.permissionKeys===undefined?undefined:(Array.isArray(body.permissionKeys)?body.permissionKeys.filter((x:unknown)=>typeof x==="string"):[])
      const isActive=body.isActive===undefined?member.is_active:!!body.isActive
      const requestedDb=body.dbRole===undefined?member.role:String(body.dbRole)
      const dbRole=requestedDb==="OWNER" ? "OWNER" : (dbRoles.has(requestedDb)?requestedDb:member.role)
      if(email!==undefined && !validEmail(email)) throw new Error("ایمیل معتبر نیست")
      if(password!==undefined && password!=="" && !validPassword(password)) throw new Error("رمز باید حداقل ۸ کاراکتر و شامل حرف و عدد باشد")
      if(name!==undefined && !name) throw new Error("نام کاربر نمی‌تواند خالی باشد")
      if(targetId===me.id && member.role==="OWNER" && dbRole!=="OWNER") throw new Error("نقش مدیر اصلی حساب جاری را نمی‌توان کاهش داد")
      if(targetId===me.id && ["OWNER","ADMIN"].includes(member.role) && !isActive) throw new Error("حساب مدیریتی جاری را نمی‌توان غیرفعال کرد")
      if(targetId===me.id && ["OWNER","ADMIN"].includes(member.role) && permissions!==undefined && !permissions.includes("us")) throw new Error("مدیر جاری نمی‌تواند دسترسی «کاربران و دسترسی‌ها» را از حساب خودش حذف کند")
      if(targetId===me.id && member.role==="OWNER" && roleKey!==undefined && roleKey!=="مدیر سیستم") throw new Error("مدیر اصلی باید نقش «مدیر سیستم» خود را حفظ کند")
      if(member.role==="OWNER" && dbRole!=="OWNER"){
        const {count}=await admin.from("company_members").select("user_id",{count:"exact",head:true}).eq("company_id",companyId).eq("role","OWNER").eq("is_active",true)
        if((count??0)<=1) throw new Error("حداقل یک مدیر سیستم فعال باید باقی بماند")
      }
      const patch:any={user_metadata:{...existingMd}}
      if(email!==undefined) patch.email=email
      if(name!==undefined) patch.user_metadata.name=name
      if(password) { patch.password=password;patch.user_metadata.mrk_password_initialized=false;patch.user_metadata.mrk_force_password_change=true }
      patch.ban_duration=isActive?"none":"876000h"
      const au=await admin.auth.admin.updateUserById(targetId,patch)
      if(au.error) throw au.error
      const {error:memberUpdateErr}=await admin.from("company_members").update({role:dbRole,is_active:isActive}).eq("company_id",companyId).eq("user_id",targetId)
      if(memberUpdateErr) throw memberUpdateErr
      const current=before??{}
      const {error:profileErr}=await admin.from("company_user_profiles").upsert({
        company_id:companyId,user_id:targetId,
        display_name:name??current.display_name??au.data.user?.email??email??"",
        job_title:jobTitle??current.job_title??"",
        role_key:roleKey??current.role_key??"ناظر",
        permission_keys:permissions??current.permission_keys??[],
        is_active:isActive
      },{onConflict:"company_id,user_id"})
      if(profileErr) throw profileErr
      const after=await profile(companyId,targetId)
      await audit(me.id,companyId,password?"تغییر مشخصات و رمز کاربر":"ویرایش کاربر",targetId,before,{email:au.data.user?.email,name:after?.display_name,jobTitle:after?.job_title,roleKey:after?.role_key,dbRole,isActive,password_changed:!!password})
      return new Response(JSON.stringify({ok:true,user:(await listUsers(companyId)).find(x=>x.user_id===targetId),temporary_password:password||null}),{status:200,headers})
    }

    if(action==="remove"){
      const targetId=String(body.userId??"")
      if(!targetId||targetId===me.id) throw new Error("حساب جاری را نمی‌توان حذف کرد")
      const {data:member,error}=await admin.from("company_members").select("*").eq("company_id",companyId).eq("user_id",targetId).maybeSingle()
      if(error) throw error
      if(!member) throw new Error("کاربر عضو شرکت نیست")
      if(member.role==="OWNER") throw new Error("مدیر سیستم را حذف نکنید")
      const before=await profile(companyId,targetId)
      const {error:mr}=await admin.from("company_members").delete().eq("company_id",companyId).eq("user_id",targetId)
      if(mr) throw mr
      await admin.from("company_user_profiles").delete().eq("company_id",companyId).eq("user_id",targetId)
      await audit(me.id,companyId,"حذف دسترسی شرکت",targetId,before,null)
      return new Response(JSON.stringify({ok:true}),{status:200,headers})
    }

    throw new Error("عملیات مدیریت کاربران شناخته نشد")
  }catch(e){
    return new Response(JSON.stringify({ok:false,error:e?.message??"خطای نامشخص"}),{status:400,headers})
  }
})
