-- Hallway database schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null,
  school_code text not null,
  bio text default '',
  avatar_url text,
  created_at timestamptz default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  media_url text,
  created_at timestamptz default now()
);

create table if not exists public.likes (
  post_id uuid references public.posts(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key(post_id,user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references public.posts(id) on delete cascade,
  author_id uuid references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid references public.conversations(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  primary key(conversation_id,user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references public.conversations(id) on delete cascade,
  sender_id uuid references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz default now()
);

create table if not exists public.follows (
  follower_id uuid references public.profiles(id) on delete cascade,
  following_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key(follower_id,following_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references public.profiles(id) on delete cascade,
  target_type text not null,
  target_id uuid,
  reason text not null,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.follows enable row level security;
alter table public.reports enable row level security;

-- School-code isolation. For production, replace this simple policy with
-- a server-side school membership verification tied to your actual roster.
create policy "profiles same school" on public.profiles for select using (
  school_code = (select school_code from public.profiles where id = auth.uid())
);
create policy "own profile insert" on public.profiles for insert with check (id = auth.uid());
create policy "own profile update" on public.profiles for update using (id = auth.uid());

create policy "school posts read" on public.posts for select using (
  exists (select 1 from public.profiles p where p.id = posts.author_id
    and p.school_code = (select school_code from public.profiles where id = auth.uid()))
);
create policy "own posts insert" on public.posts for insert with check (author_id = auth.uid());
create policy "own posts delete" on public.posts for delete using (author_id = auth.uid());

create policy "likes read" on public.likes for select using (true);
create policy "own likes" on public.likes for all using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "school comments read" on public.comments for select using (
  exists (select 1 from public.posts po join public.profiles p on p.id=po.author_id
    where po.id=comments.post_id and p.school_code=(select school_code from public.profiles where id=auth.uid()))
);
create policy "own comments" on public.comments for all using (author_id=auth.uid()) with check (author_id=auth.uid());

create policy "own membership" on public.conversation_members for select using (user_id=auth.uid());
create policy "own membership insert" on public.conversation_members for insert with check (user_id=auth.uid());
create policy "members messages read" on public.messages for select using (
  exists(select 1 from public.conversation_members cm where cm.conversation_id=messages.conversation_id and cm.user_id=auth.uid())
);
create policy "members messages insert" on public.messages for insert with check (
  sender_id=auth.uid() and exists(select 1 from public.conversation_members cm where cm.conversation_id=messages.conversation_id and cm.user_id=auth.uid())
);

create policy "follows read" on public.follows for select using (true);
create policy "own follows" on public.follows for all using (follower_id=auth.uid()) with check (follower_id=auth.uid());

create policy "own reports insert" on public.reports for insert with check (reporter_id=auth.uid());

-- Create a profile automatically after email signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles (id,username,display_name,school_code)
  values (
    new.id,
    coalesce(split_part(new.email,'@',1),'student') || '_' || substr(new.id::text,1,5),
    coalesce(split_part(new.email,'@',1),'Student'),
    '21511'
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();