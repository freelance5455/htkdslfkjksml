create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default 'مستخدم جديد',
  bio text default '',
  avatar_url text default '',
  role text not null default 'user' check (role in ('user','admin')),
  is_banned boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_url text not null,
  thumbnail_url text default '',
  caption text default '',
  status text not null default 'published' check (status in ('published','hidden','removed','pending')),
  views bigint not null default 0,
  likes_count bigint not null default 0,
  comments_count bigint not null default 0,
  shares_count bigint not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  user_id uuid references public.profiles(id) on delete cascade,
  video_id uuid references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, video_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  status text not null default 'published' check (status in ('published','hidden','removed')),
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid references public.profiles(id) on delete cascade,
  following_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id, following_id),
  check(follower_id <> following_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references public.profiles(id) on delete set null,
  video_id uuid references public.videos(id) on delete cascade,
  comment_id uuid references public.comments(id) on delete cascade,
  reason text not null,
  status text not null default 'open' check(status in ('open','reviewed','dismissed','actioned')),
  created_at timestamptz not null default now()
);

create table if not exists public.live_sessions (
  id uuid primary key default gen_random_uuid(),
  host_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  status text not null default 'live' check(status in ('live','ended','blocked')),
  provider text default 'livekit',
  room_name text unique,
  viewer_count bigint not null default 0,
  created_at timestamptz not null default now(),
  ended_at timestamptz
);

create index if not exists videos_created_idx on public.videos(created_at desc);
create index if not exists videos_status_idx on public.videos(status);
create index if not exists reports_status_idx on public.reports(status);

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.reports enable row level security;
alter table public.live_sessions enable row level security;

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and is_banned=false);
$$;

create policy "profiles public read" on public.profiles for select using (true);
create policy "profiles own insert" on public.profiles for insert with check (id=auth.uid());
create policy "profiles own update" on public.profiles for update using (id=auth.uid() or public.is_admin());
create policy "profiles admin" on public.profiles for all using (public.is_admin()) with check (public.is_admin());

create policy "published videos read" on public.videos for select using (status='published' or user_id=auth.uid() or public.is_admin());
create policy "own videos insert" on public.videos for insert with check (user_id=auth.uid());
create policy "own/admin videos update" on public.videos for update using (user_id=auth.uid() or public.is_admin()) with check (user_id=auth.uid() or public.is_admin());
create policy "own/admin videos delete" on public.videos for delete using (user_id=auth.uid() or public.is_admin());

create policy "likes read" on public.likes for select using (true);
create policy "likes own write" on public.likes for all using (user_id=auth.uid()) with check (user_id=auth.uid());

create policy "comments read" on public.comments for select using (status='published' or user_id=auth.uid() or public.is_admin());
create policy "comments own insert" on public.comments for insert with check (user_id=auth.uid());
create policy "comments own/admin update" on public.comments for update using (user_id=auth.uid() or public.is_admin());
create policy "comments own/admin delete" on public.comments for delete using (user_id=auth.uid() or public.is_admin());

create policy "follows read" on public.follows for select using (true);
create policy "follows own write" on public.follows for all using (follower_id=auth.uid()) with check (follower_id=auth.uid());

create policy "reports own/admin" on public.reports for insert with check (reporter_id=auth.uid());
create policy "reports admin read" on public.reports for select using (public.is_admin());
create policy "reports admin update" on public.reports for update using (public.is_admin());

create policy "live public read" on public.live_sessions for select using (status='live' or host_id=auth.uid() or public.is_admin());
create policy "live own insert" on public.live_sessions for insert with check (host_id=auth.uid());
create policy "live own/admin update" on public.live_sessions for update using (host_id=auth.uid() or public.is_admin());

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id, username, display_name) values(new.id, coalesce(nullif(new.raw_user_meta_data->>'username',''), 'user_'||substr(new.id::text,1,8)), coalesce(nullif(new.raw_user_meta_data->>'display_name',''), 'مستخدم جديد'));
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();


-- Storage: video/avatar buckets and RLS policies
insert into storage.buckets (id, name, public) values ('videos','videos',true)
on conflict (id) do update set public=true;
insert into storage.buckets (id, name, public) values ('avatars','avatars',true)
on conflict (id) do update set public=true;

create policy "public read videos" on storage.objects for select using (bucket_id='videos');
create policy "users upload own videos" on storage.objects for insert with check (bucket_id='videos' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "users update own videos" on storage.objects for update using (bucket_id='videos' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "users delete own videos" on storage.objects for delete using (bucket_id='videos' and (auth.uid()::text = (storage.foldername(name))[1] or public.is_admin()));
create policy "public read avatars" on storage.objects for select using (bucket_id='avatars');
create policy "users upload own avatars" on storage.objects for insert with check (bucket_id='avatars' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "users update own avatars" on storage.objects for update using (bucket_id='avatars' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "users delete own avatars" on storage.objects for delete using (bucket_id='avatars' and (auth.uid()::text = (storage.foldername(name))[1] or public.is_admin()));

-- Safe counter helpers
create or replace function public.increment_video_view(video_uuid uuid) returns void
language sql security definer set search_path=public as $$
  update public.videos set views=views+1 where id=video_uuid and status='published';
$$;

create or replace function public.increment_share(video_uuid uuid) returns void
language sql security definer set search_path=public as $$
  update public.videos set shares_count=shares_count+1 where id=video_uuid and status='published';
$$;


-- ============================================================
-- Fideo production extensions
-- ============================================================

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  type text not null check (type in ('like','comment','follow','live','system')),
  video_id uuid references public.videos(id) on delete cascade,
  body text not null default '',
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  token text not null,
  platform text not null default 'android',
  created_at timestamptz not null default now(),
  unique(user_id, token)
);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(blocker_id, blocked_id),
  check(blocker_id <> blocked_id)
);

create index if not exists notifications_user_idx
  on public.notifications(user_id, created_at desc);
create index if not exists device_tokens_user_idx
  on public.device_tokens(user_id);

alter table public.notifications enable row level security;
alter table public.device_tokens enable row level security;
alter table public.blocks enable row level security;

create policy "notifications own read" on public.notifications
  for select using (user_id=auth.uid() or public.is_admin());
create policy "notifications own update" on public.notifications
  for update using (user_id=auth.uid() or public.is_admin());
create policy "notifications admin insert" on public.notifications
  for insert with check (public.is_admin());

create policy "device tokens own" on public.device_tokens
  for all using (user_id=auth.uid() or public.is_admin())
  with check (user_id=auth.uid() or public.is_admin());

create policy "blocks own" on public.blocks
  for all using (blocker_id=auth.uid() or public.is_admin())
  with check (blocker_id=auth.uid() or public.is_admin());

-- Keep denormalized counters correct.
create or replace function public.sync_video_like_count()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if tg_op='INSERT' then
    update public.videos set likes_count=likes_count+1 where id=new.video_id;
  elsif tg_op='DELETE' then
    update public.videos set likes_count=greatest(0,likes_count-1) where id=old.video_id;
  end if;
  return coalesce(new,old);
end; $$;

drop trigger if exists likes_counter_trigger on public.likes;
create trigger likes_counter_trigger
after insert or delete on public.likes
for each row execute function public.sync_video_like_count();

create or replace function public.sync_comment_count()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if tg_op='INSERT' then
    update public.videos set comments_count=comments_count+1 where id=new.video_id;
  elsif tg_op='DELETE' then
    update public.videos set comments_count=greatest(0,comments_count-1) where id=old.video_id;
  end if;
  return coalesce(new,old);
end; $$;

drop trigger if exists comments_counter_trigger on public.comments;
create trigger comments_counter_trigger
after insert or delete on public.comments
for each row execute function public.sync_comment_count();

-- Automatic in-app notifications.
create or replace function public.notify_like()
returns trigger language plpgsql security definer set search_path=public as $$
declare owner_id uuid;
begin
  select user_id into owner_id from public.videos where id=new.video_id;
  if owner_id is not null and owner_id <> new.user_id then
    insert into public.notifications(user_id,actor_id,type,video_id,body)
    values(owner_id,new.user_id,'like',new.video_id,'أعجب شخص بفيديوك');
  end if;
  return new;
end; $$;

drop trigger if exists likes_notification_trigger on public.likes;
create trigger likes_notification_trigger
after insert on public.likes
for each row execute function public.notify_like();

create or replace function public.notify_follow()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.notifications(user_id,actor_id,type,body)
  values(new.following_id,new.follower_id,'follow','بدأ شخص بمتابعتك');
  return new;
end; $$;

drop trigger if exists follows_notification_trigger on public.follows;
create trigger follows_notification_trigger
after insert on public.follows
for each row execute function public.notify_follow();

create or replace function public.mark_video_view(video_uuid uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  update public.videos
  set views=views+1
  where id=video_uuid and status='published';
end; $$;

grant execute on function public.mark_video_view(uuid) to anon, authenticated;
grant execute on function public.increment_video_view(uuid) to anon, authenticated;
grant execute on function public.increment_share(uuid) to anon, authenticated;
