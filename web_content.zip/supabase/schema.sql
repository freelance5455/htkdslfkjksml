
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text default '',
 role text not null default 'user' check(role in ('user','admin'))
);
create table if not exists public.content_items (
 id uuid primary key default gen_random_uuid(),
 category text not null check(category in ('lesson','sermon','fatwa','lecture','excerpt')),
 title text not null, description text not null default '',
 media_url text not null default '', thumbnail_url text not null default '',
 published boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.fatwa_requests (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id) on delete set null,
 name text not null default '', question text not null,
 category text not null default 'عام',
 status text not null default 'pending' check(status in ('pending','reviewing','answered','closed')),
 admin_response text not null default '',
 created_at timestamptz not null default now()
);
create table if not exists public.favorites (
 user_id uuid not null references auth.users(id) on delete cascade,
 content_id uuid not null references public.content_items(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(user_id,content_id)
);
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;
alter table public.profiles enable row level security;
alter table public.content_items enable row level security;
alter table public.fatwa_requests enable row level security;
alter table public.favorites enable row level security;
create policy "profile self read" on public.profiles for select using(id=auth.uid() or public.is_admin());
create policy "profile self update" on public.profiles for update using(id=auth.uid()) with check((id=auth.uid() and role='user') or public.is_admin());
create policy "published content read" on public.content_items for select using(published=true or public.is_admin());
create policy "admin content all" on public.content_items for all using(public.is_admin()) with check(public.is_admin());
create policy "submit fatwa" on public.fatwa_requests for insert with check(user_id=auth.uid() or user_id is null);
create policy "read own fatwa" on public.fatwa_requests for select using(user_id=auth.uid() or public.is_admin());
create policy "admin update fatwa" on public.fatwa_requests for update using(public.is_admin()) with check(public.is_admin());
create policy "own favorites" on public.favorites for all using(user_id=auth.uid()) with check(user_id=auth.uid());
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,display_name,role) values(new.id,coalesce(new.raw_user_meta_data->>'name',''),'user') on conflict(id) do nothing;
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
