-- Universal AI 2.0 schema
-- Run in Supabase SQL Editor. Backend uses SERVICE_ROLE_KEY only; never put it in the browser.
create extension if not exists pgcrypto;

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  owner_uid text not null,
  role text not null check (role in ('user','assistant','system')),
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists conversations_owner_created_idx on public.conversations(owner_uid,created_at desc);

create table if not exists public.knowledge_documents (
  id uuid primary key default gen_random_uuid(),
  owner_uid text,
  title text not null,
  content text not null,
  source text,
  tags text not null default '',
  search_vector tsvector generated always as (
    setweight(to_tsvector('simple',coalesce(title,'')),'A') ||
    setweight(to_tsvector('simple',coalesce(tags,'')),'B') ||
    setweight(to_tsvector('simple',coalesce(content,'')),'C')
  ) stored,
  created_at timestamptz not null default now()
);
create index if not exists knowledge_search_idx on public.knowledge_documents using gin(search_vector);
create index if not exists knowledge_owner_idx on public.knowledge_documents(owner_uid,created_at desc);

create or replace function public.search_knowledge(query_text text, match_owner text, result_limit integer default 6)
returns table(id uuid,title text,content text,source text,rank real)
language sql stable security definer set search_path=public
as $$
  select d.id,d.title,d.content,d.source,
    ts_rank(d.search_vector,websearch_to_tsquery('simple',query_text)) as rank
  from public.knowledge_documents d
  where (d.owner_uid is null or d.owner_uid=match_owner)
    and d.search_vector @@ websearch_to_tsquery('simple',query_text)
  order by rank desc, d.created_at desc
  limit greatest(1,least(result_limit,20));
$$;

create table if not exists public.chrome_pair_codes (
  id uuid primary key default gen_random_uuid(),
  owner_uid text not null,
  code_hash text not null unique,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists chrome_pair_codes_expiry_idx on public.chrome_pair_codes(expires_at);

create table if not exists public.chrome_tokens (
  id uuid primary key default gen_random_uuid(),
  owner_uid text not null,
  token_hash text not null unique,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index if not exists chrome_tokens_owner_idx on public.chrome_tokens(owner_uid);

-- Lock down direct client access. Only the backend's service role should access these tables.
alter table public.conversations enable row level security;
alter table public.knowledge_documents enable row level security;
alter table public.chrome_pair_codes enable row level security;
alter table public.chrome_tokens enable row level security;
revoke all on public.conversations,public.knowledge_documents,public.chrome_pair_codes,public.chrome_tokens from anon,authenticated;
grant all on public.conversations,public.knowledge_documents,public.chrome_pair_codes,public.chrome_tokens to service_role;
revoke all on function public.search_knowledge(text,text,integer) from public,anon,authenticated;
grant execute on function public.search_knowledge(text,text,integer) to service_role;
