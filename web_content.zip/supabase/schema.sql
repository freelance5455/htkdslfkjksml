-- SafarSaathi MVP starter schema for Supabase PostgreSQL.
-- Run in Supabase SQL Editor only after reviewing and adapting for your launch.
create extension if not exists pgcrypto;

create type public.app_role as enum ('passenger', 'driver', 'admin');
create type public.vehicle_type as enum ('car', 'bike');
create type public.ride_status as enum ('published', 'started', 'completed', 'cancelled');
create type public.booking_status as enum ('requested', 'accepted', 'rejected', 'cancelled', 'completed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  avatar_url text,
  phone text,
  preferred_language text not null default 'en' check (preferred_language in ('en','hi','hinglish')),
  role public.app_role not null default 'passenger',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  type public.vehicle_type not null,
  make text not null,
  model text not null,
  registration_last4 text,
  registration_private text,
  helmet_available boolean,
  verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected')),
  created_at timestamptz not null default now()
);

create table public.rides (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles(id) on delete restrict,
  vehicle_id uuid not null references public.vehicles(id) on delete restrict,
  origin text not null,
  destination text not null,
  departure_at timestamptz not null,
  estimated_arrival_at timestamptz,
  seats_total int not null check (seats_total between 1 and 8),
  seats_available int not null check (seats_available between 0 and 8),
  price_inr int not null check (price_inr > 0),
  instant_booking boolean not null default false,
  status public.ride_status not null default 'published',
  preferences jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  check (lower(origin) <> lower(destination))
);

create index rides_route_departure_idx on public.rides (lower(origin), lower(destination), departure_at) where status = 'published';
create index rides_driver_idx on public.rides (driver_id, departure_at desc);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null references public.rides(id) on delete restrict,
  passenger_id uuid not null references public.profiles(id) on delete restrict,
  seats int not null check (seats between 1 and 8),
  base_fare_inr int not null check (base_fare_inr >= 0),
  platform_fee_inr int not null default 0 check (platform_fee_inr >= 0),
  tax_inr int not null default 0 check (tax_inr >= 0),
  total_inr int not null check (total_inr >= 0),
  status public.booking_status not null default 'requested',
  booking_expires_at timestamptz,
  created_at timestamptz not null default now(),
  unique (ride_id, passenger_id, status)
);

create index bookings_passenger_idx on public.bookings (passenger_id, created_at desc);
create index bookings_ride_idx on public.bookings (ride_id, status);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  reviewer_id uuid not null references public.profiles(id) on delete restrict,
  reviewee_id uuid not null references public.profiles(id) on delete restrict,
  stars int not null check (stars between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique (booking_id, reviewer_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete restrict,
  reported_user_id uuid references public.profiles(id) on delete set null,
  ride_id uuid references public.rides(id) on delete set null,
  category text not null,
  details text not null,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create table public.admin_actions (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid not null references public.profiles(id) on delete restrict,
  action text not null,
  target_type text not null,
  target_id uuid,
  reason text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.rides enable row level security;
alter table public.bookings enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;
alter table public.admin_actions enable row level security;

-- Starter policies. Review carefully before production; admin access should be enforced
-- through trusted server-side claims/functions, never by trusting client-submitted role values.
create policy "Profiles readable by authenticated users" on public.profiles
  for select to authenticated using (true);
create policy "Users can insert own profile" on public.profiles
  for insert to authenticated with check (auth.uid() = id);
create policy "Users can update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "Verified/public vehicle basics readable" on public.vehicles
  for select to authenticated using (verification_status = 'verified' or owner_id = auth.uid());
create policy "Owners manage own vehicles" on public.vehicles
  for insert to authenticated with check (owner_id = auth.uid());
create policy "Owners update own vehicles" on public.vehicles
  for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "Published rides readable" on public.rides
  for select to authenticated using (status = 'published' or driver_id = auth.uid());
create policy "Drivers create own rides" on public.rides
  for insert to authenticated with check (driver_id = auth.uid());
create policy "Drivers update own rides" on public.rides
  for update to authenticated using (driver_id = auth.uid()) with check (driver_id = auth.uid());

create policy "Passengers and ride drivers can view bookings" on public.bookings
  for select to authenticated using (
    passenger_id = auth.uid() or exists (
      select 1 from public.rides r where r.id = ride_id and r.driver_id = auth.uid()
    )
  );
create policy "Passengers create own bookings" on public.bookings
  for insert to authenticated with check (passenger_id = auth.uid());
create policy "Passenger can cancel own booking" on public.bookings
  for update to authenticated using (passenger_id = auth.uid()) with check (passenger_id = auth.uid());

create policy "Reviews visible to authenticated users" on public.reviews
  for select to authenticated using (true);
create policy "Reviewer creates own review" on public.reviews
  for insert to authenticated with check (reviewer_id = auth.uid());

create policy "Users can create reports" on public.reports
  for insert to authenticated with check (reporter_id = auth.uid());
create policy "Reporter sees own reports" on public.reports
  for select to authenticated using (reporter_id = auth.uid());

-- Do not expose admin_actions to regular clients. Use a protected server-side admin API.
