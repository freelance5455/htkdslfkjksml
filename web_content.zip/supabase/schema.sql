-- ============================================================
-- SCHEMA COMPLET SUPABASE POUR "CŒUR RÉGULÉ"
-- ============================================================
-- Exécutez ce script dans le Supabase SQL Editor de votre projet.

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. TABLE PROFILES
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT,
    full_name TEXT,
    language TEXT NOT NULL DEFAULT 'fr',
    avatar_url TEXT,
    role TEXT DEFAULT 'user',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 3. TABLE SESSIONS (Exercices de régulation réalisés)
CREATE TABLE IF NOT EXISTS public.sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    space_type TEXT NOT NULL CHECK (space_type IN ('adult', 'parents')),
    tool_id TEXT NOT NULL,
    tool_title TEXT NOT NULL,
    version TEXT NOT NULL CHECK (version IN ('short', 'full')),
    duration_seconds INTEGER NOT NULL DEFAULT 0,
    rating_before INTEGER CHECK (rating_before >= 0 AND rating_before <= 10),
    rating_after INTEGER CHECK (rating_after >= 0 AND rating_after <= 10),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 4. TABLE EMOTIONAL_LOGS (Journal des états émotionnels)
CREATE TABLE IF NOT EXISTS public.emotional_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    primary_emotion TEXT NOT NULL,
    intensity_before INTEGER NOT NULL CHECK (intensity_before >= 0 AND intensity_before <= 10),
    intensity_after INTEGER NOT NULL CHECK (intensity_after >= 0 AND intensity_after <= 10),
    context TEXT NOT NULL CHECK (context IN ('adult', 'parent')),
    trigger_description TEXT,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 5. TABLE PARENT_SESSIONS (Spécifique aux interventions parent-enfant)
CREATE TABLE IF NOT EXISTS public.parent_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    child_age_range TEXT,
    crisis_type TEXT NOT NULL,
    technique_used TEXT NOT NULL,
    success_rating INTEGER CHECK (success_rating >= 0 AND success_rating <= 10),
    parent_stress_before INTEGER CHECK (parent_stress_before >= 0 AND parent_stress_before <= 10),
    parent_stress_after INTEGER CHECK (parent_stress_after >= 0 AND parent_stress_after <= 10),
    de_escalation_time_min INTEGER,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 6. TABLE FAVORITE_TOOLS (Outils favoris de l'utilisateur)
CREATE TABLE IF NOT EXISTS public.favorite_tools (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    tool_id TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(user_id, tool_id)
);

-- 7. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.emotional_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parent_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorite_tools ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can view and update their own profile
CREATE POLICY "Users can read their own profile"
    ON public.profiles FOR SELECT
    USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
    ON public.profiles FOR UPDATE
    USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
    ON public.profiles FOR INSERT
    WITH CHECK (auth.uid() = id);

-- Sessions: Users can CRUD their own sessions
CREATE POLICY "Users can manage their sessions"
    ON public.sessions FOR ALL
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- Emotional logs: Users can CRUD their own emotional logs
CREATE POLICY "Users can manage their emotional logs"
    ON public.emotional_logs FOR ALL
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- Parent sessions: Users can CRUD their own parent sessions
CREATE POLICY "Users can manage their parent sessions"
    ON public.parent_sessions FOR ALL
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- Favorite tools: Users can CRUD their own favorite tools
CREATE POLICY "Users can manage their favorite tools"
    ON public.favorite_tools FOR ALL
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- 8. TRIGGER POUR CRÉATION AUTOMATIQUE DU PROFIL LORS DE L'INSCRIPTION
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name, language)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
        COALESCE(NEW.raw_user_meta_data->>'language', 'fr')
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- 9. INDICES DE PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON public.sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_emotional_logs_user_id ON public.emotional_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_parent_sessions_user_id ON public.parent_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_favorite_tools_user_id ON public.favorite_tools(user_id);
