-- ConnectMe starter schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null default 'ConnectMe user',
 phone text unique,
 avatar_url text,
 about text default '',
 created_at timestamptz not null default now()
);
create table if not exists public.chats (
 id uuid primary key default gen_random_uuid(),
 name text,
 is_group boolean not null default false,
 created_by uuid references auth.users(id) on delete set null,
 updated_at timestamptz not null default now(),
 created_at timestamptz not null default now()
);
create table if not exists public.chat_members (
 chat_id uuid references public.chats(id) on delete cascade,
 user_id uuid references auth.users(id) on delete cascade,
 role text not null default 'member',
 joined_at timestamptz not null default now(),
 primary key(chat_id,user_id)
);
create table if not exists public.messages (
 id uuid primary key default gen_random_uuid(),
 chat_id uuid not null references public.chats(id) on delete cascade,
 sender_id uuid not null references auth.users(id) on delete cascade,
 body text not null default '',
 media_url text,
 media_type text,
 created_at timestamptz not null default now(),
 edited_at timestamptz
);
create index if not exists messages_chat_created_idx on public.messages(chat_id,created_at);
create table if not exists public.statuses (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 body text not null default '',
 media_url text,
 expires_at timestamptz not null,
 created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.chats enable row level security;
alter table public.chat_members enable row level security;
alter table public.messages enable row level security;
alter table public.statuses enable row level security;

-- Profiles are searchable only by authenticated users; phone numbers are never returned by the client UI except to the owner.
create policy "profiles readable to signed-in users" on public.profiles for select to authenticated using (true);
create policy "users insert own profile" on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);

create or replace function public.is_chat_member(target_chat uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.chat_members where chat_id=target_chat and user_id=auth.uid()) $$;
revoke all on function public.is_chat_member(uuid) from public;
grant execute on function public.is_chat_member(uuid) to authenticated;

create policy "members can read their chats" on public.chats for select to authenticated
 using (public.is_chat_member(id));
create policy "signed-in users create chats" on public.chats for insert to authenticated with check (created_by=auth.uid());
create policy "members can read memberships" on public.chat_members for select to authenticated
 using (public.is_chat_member(chat_id));
create policy "users can join as themselves" on public.chat_members for insert to authenticated with check (user_id=auth.uid());
create policy "members can read messages" on public.messages for select to authenticated
 using (public.is_chat_member(messages.chat_id));
create policy "members can send messages" on public.messages for insert to authenticated
 with check (sender_id=auth.uid() and public.is_chat_member(messages.chat_id));
create policy "authors can edit own messages" on public.messages for update to authenticated
 using (sender_id=auth.uid()) with check (sender_id=auth.uid());
create policy "authors can delete own messages" on public.messages for delete to authenticated using (sender_id=auth.uid());
create policy "statuses visible to signed in users" on public.statuses for select to authenticated using (expires_at>now());
create policy "users manage own statuses" on public.statuses for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

-- Secure RPC: lookup exact phone number and return only the minimal profile fields.
create or replace function public.find_registered_user(phone_input text)
returns table(id uuid,display_name text,phone text)
language sql security definer set search_path=public
as $$ select p.id,p.display_name,null::text from profiles p where p.phone=phone_input and p.id<>auth.uid() limit 10 $$;
revoke all on function public.find_registered_user(text) from public;
grant execute on function public.find_registered_user(text) to authenticated;

-- Create or reuse a direct chat; caller must be authenticated.
create or replace function public.get_or_create_direct_chat(other_user uuid)
returns uuid language plpgsql security definer set search_path=public
as $$
declare existing_id uuid; new_id uuid;
begin
 if auth.uid() is null or other_user=auth.uid() then raise exception 'Invalid user'; end if;
 if not exists(select 1 from profiles where id=other_user) then raise exception 'User not found'; end if;
 select c.id into existing_id from chats c
 where c.is_group=false
 and exists(select 1 from chat_members a where a.chat_id=c.id and a.user_id=auth.uid())
 and exists(select 1 from chat_members b where b.chat_id=c.id and b.user_id=other_user)
 and (select count(*) from chat_members x where x.chat_id=c.id)=2 limit 1;
 if existing_id is not null then return existing_id; end if;
 insert into chats(created_by,is_group) values(auth.uid(),false) returning id into new_id;
 insert into chat_members(chat_id,user_id) values(new_id,auth.uid()),(new_id,other_user);
 return new_id;
end $$;
revoke all on function public.get_or_create_direct_chat(uuid) from public;
grant execute on function public.get_or_create_direct_chat(uuid) to authenticated;

-- Realtime for live incoming messages
alter publication supabase_realtime add table public.messages;

-- Storage bucket for audio/media. Use private bucket and signed URLs in production.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('chat-media','chat-media',false,52428800,array['audio/webm','audio/ogg','image/jpeg','image/png','video/mp4','application/pdf'])
on conflict(id) do nothing;
create policy "authenticated upload own media" on storage.objects for insert to authenticated
with check(bucket_id='chat-media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "authenticated read media" on storage.objects for select to authenticated
using(bucket_id='chat-media' and (storage.foldername(name))[1]=auth.uid()::text);
