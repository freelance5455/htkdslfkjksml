insert into public.company_members(company_id,user_id,role,is_active)
select c.id,u.id,
       case when lower(u.email)='alijim88887777@gmail.com' then 'OWNER'
            else 'ACCOUNTANT' end,
       true
from public.companies c
join auth.users u on lower(u.email) in (
  'alijim88887777@gmail.com',
  'parimarzban8888@gmail.com',
  'shahiakhtarian8888@gmail.com'
)
where c.id='c74889aa-321f-42e6-8cad-856d84cd415a'
on conflict (company_id,user_id) do update
set role=excluded.role,is_active=true;

insert into public.company_user_profiles(company_id,user_id,display_name,job_title,role_key,permission_keys,is_active)
select c.id,u.id,
       case lower(u.email)
         when 'alijim88887777@gmail.com' then 'mr,khorasani'
         when 'parimarzban8888@gmail.com' then 'Pari'
         when 'shahiakhtarian8888@gmail.com' then 'shahi'
         else coalesce(u.email,'کاربر')
       end,
       case when lower(u.email)='alijim88887777@gmail.com' then 'مدیر سیستم' else 'حسابدار' end,
       case when lower(u.email)='alijim88887777@gmail.com' then 'مدیر سیستم' else 'حسابدار' end,
       '[]'::jsonb,true
from public.companies c
join auth.users u on lower(u.email) in (
  'alijim88887777@gmail.com',
  'parimarzban8888@gmail.com',
  'shahiakhtarian8888@gmail.com'
)
where c.id='c74889aa-321f-42e6-8cad-856d84cd415a'
on conflict (company_id,user_id) do update
set display_name=excluded.display_name,
    job_title=excluded.job_title,
    role_key=excluded.role_key,
    is_active=true,
    updated_at=now();


-- Initial login credentials (Auth only; never stored in application profile tables).
-- These values are intended for the first login after applying this migration.
-- The application marks the accounts for mandatory password change after first login.
update auth.users
set encrypted_password = crypt(case lower(email)
  when 'alijim88887777@gmail.com' then 'Mr1405!'
  when 'parimarzban8888@gmail.com' then 'Pa1405!'
  when 'shahiakhtarian8888@gmail.com' then 'Sh1405!'
end, gen_salt('bf')),
    email_confirmed_at = coalesce(email_confirmed_at, now()),
    raw_user_meta_data = coalesce(raw_user_meta_data, '{}'::jsonb)
      || jsonb_build_object('mrk_password_initialized', false, 'mrk_force_password_change', true)
where lower(email) in (
  'alijim88887777@gmail.com',
  'parimarzban8888@gmail.com',
  'shahiakhtarian8888@gmail.com'
);
