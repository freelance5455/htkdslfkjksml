create table public.app_state (id text primary key, data jsonb not null, version integer not null default 1, updated_at timestamptz not null default now());
create table public.app_files (id bigint primary key, data_url text not null, created_at timestamptz not null default now());
create table public.app_sessions (token text primary key, user_data jsonb not null, created_at timestamptz not null default now(), expires_at timestamptz not null default (now() + interval '7 days'));
alter table public.app_state enable row level security;
alter table public.app_files enable row level security;
alter table public.app_sessions enable row level security;
revoke all on public.app_state, public.app_files, public.app_sessions from anon, authenticated;
