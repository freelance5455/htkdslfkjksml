-- ZEIN isolated foundation schema
-- Apply only to a NEW, dedicated ZEIN Supabase project.
-- Does not modify HANIMEX tables.

create extension if not exists pgcrypto;

create table if not exists public.zein_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.zein_workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  workspace_type text not null check (workspace_type in ('personal','business')),
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.zein_memberships (
  workspace_id uuid not null references public.zein_workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member','viewer')),
  created_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create table if not exists public.zein_contacts (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.zein_workspaces(id) on delete cascade,
  display_name text not null,
  email text,
  phone text,
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.zein_channels (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.zein_workspaces(id) on delete cascade,
  provider text not null check (provider in ('whatsapp_business','telegram','instagram','messenger','facebook','gmail','discord','x','manual')),
  label text not null,
  connection_status text not null default 'not_connected' check (connection_status in ('not_connected','pending','connected','expired','error','manual')),
  external_account_id text,
  scopes text[] not null default '{}',
  connected_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.zein_conversations (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.zein_workspaces(id) on delete cascade,
  channel_id uuid references public.zein_channels(id) on delete set null,
  contact_id uuid references public.zein_contacts(id) on delete set null,
  subject text,
  provider_conversation_id text,
  conversation_status text not null default 'open' check (conversation_status in ('open','pending','closed','archived')),
  last_message_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.zein_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.zein_conversations(id) on delete cascade,
  provider_message_id text,
  sender_user_id uuid references auth.users(id) on delete set null,
  direction text not null check (direction in ('inbound','outbound','internal')),
  message_type text not null default 'text' check (message_type in ('text','image','video','audio','file','location','system')),
  body text,
  attachment_path text,
  delivery_status text not null default 'received' check (delivery_status in ('queued','sent','delivered','read','failed','received')),
  sent_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.zein_activity (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.zein_workspaces(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  entity_type text,
  entity_id uuid,
  details jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index if not exists zein_memberships_user_idx on public.zein_memberships(user_id);
create index if not exists zein_contacts_workspace_idx on public.zein_contacts(workspace_id);
create index if not exists zein_channels_workspace_idx on public.zein_channels(workspace_id);
create index if not exists zein_conversations_workspace_last_idx on public.zein_conversations(workspace_id,last_message_at desc);
create index if not exists zein_messages_conversation_created_idx on public.zein_messages(conversation_id,created_at);
create index if not exists zein_activity_workspace_created_idx on public.zein_activity(workspace_id,created_at desc);

-- Membership visibility is limited to the signed-in user's own memberships.
alter table public.zein_profiles enable row level security;
alter table public.zein_workspaces enable row level security;
alter table public.zein_memberships enable row level security;
alter table public.zein_contacts enable row level security;
alter table public.zein_channels enable row level security;
alter table public.zein_conversations enable row level security;
alter table public.zein_messages enable row level security;
alter table public.zein_activity enable row level security;

create policy "zein_profiles_select_own" on public.zein_profiles
for select to authenticated using (id = (select auth.uid()));
create policy "zein_profiles_insert_own" on public.zein_profiles
for insert to authenticated with check (id = (select auth.uid()));
create policy "zein_profiles_update_own" on public.zein_profiles
for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

create policy "zein_workspaces_select_member" on public.zein_workspaces
for select to authenticated using (
  owner_id = (select auth.uid()) or exists (
    select 1 from public.zein_memberships m
    where m.workspace_id = id and m.user_id = (select auth.uid())
  )
);
create policy "zein_workspaces_insert_owner" on public.zein_workspaces
for insert to authenticated with check (owner_id = (select auth.uid()));
create policy "zein_workspaces_update_owner" on public.zein_workspaces
for update to authenticated using (owner_id = (select auth.uid()))
with check (owner_id = (select auth.uid()));

create policy "zein_memberships_select_self_or_owner" on public.zein_memberships
for select to authenticated using (
  user_id = (select auth.uid()) or exists (
    select 1 from public.zein_workspaces w
    where w.id = workspace_id and w.owner_id = (select auth.uid())
  )
);
create policy "zein_memberships_owner_insert" on public.zein_memberships
for insert to authenticated with check (
  exists (select 1 from public.zein_workspaces w
          where w.id = workspace_id and w.owner_id = (select auth.uid()))
);
create policy "zein_memberships_owner_update" on public.zein_memberships
for update to authenticated using (
  exists (select 1 from public.zein_workspaces w
          where w.id = workspace_id and w.owner_id = (select auth.uid()))
) with check (
  exists (select 1 from public.zein_workspaces w
          where w.id = workspace_id and w.owner_id = (select auth.uid()))
);
create policy "zein_memberships_owner_delete" on public.zein_memberships
for delete to authenticated using (
  exists (select 1 from public.zein_workspaces w
          where w.id = workspace_id and w.owner_id = (select auth.uid()))
);

create policy "zein_contacts_member_all" on public.zein_contacts
for all to authenticated using (
  exists (select 1 from public.zein_memberships m
          where m.workspace_id = workspace_id and m.user_id = (select auth.uid()))
) with check (
  exists (select 1 from public.zein_memberships m
          where m.workspace_id = workspace_id and m.user_id = (select auth.uid()))
);
create policy "zein_channels_member_all" on public.zein_channels
for all to authenticated using (
  exists (select 1 from public.zein_memberships m
          where m.workspace_id = workspace_id and m.user_id = (select auth.uid()))
) with check (
  exists (select 1 from public.zein_memberships m
          where m.workspace_id = workspace_id and m.user_id = (select auth.uid()))
);
create policy "zein_conversations_member_all" on public.zein_conversations
for all to authenticated using (
  exists (select 1 from public.zein_memberships m
          where m.workspace_id = workspace_id and m.user_id = (select auth.uid()))
) with check (
  exists (select 1 from public.zein_memberships m
          where m.workspace_id = workspace_id and m.user_id = (select auth.uid()))
);
create policy "zein_messages_member_all" on public.zein_messages
for all to authenticated using (
  exists (
    select 1 from public.zein_conversations c
    join public.zein_memberships m on m.workspace_id = c.workspace_id
    where c.id = conversation_id and m.user_id = (select auth.uid())
  )
) with check (
  exists (
    select 1 from public.zein_conversations c
    join public.zein_memberships m on m.workspace_id = c.workspace_id
    where c.id = conversation_id and m.user_id = (select auth.uid())
  )
);
create policy "zein_activity_member_select" on public.zein_activity
for select to authenticated using (
  exists (select 1 from public.zein_memberships m
          where m.workspace_id = workspace_id and m.user_id = (select auth.uid()))
);
create policy "zein_activity_member_insert" on public.zein_activity
for insert to authenticated with check (
  actor_id = (select auth.uid()) and exists (
    select 1 from public.zein_memberships m
    where m.workspace_id = workspace_id and m.user_id = (select auth.uid())
  )
);

-- Authenticated users can access the exposed tables; RLS is the row boundary.
grant select, insert, update, delete on
  public.zein_profiles, public.zein_workspaces, public.zein_memberships,
  public.zein_contacts, public.zein_channels, public.zein_conversations,
  public.zein_messages, public.zein_activity to authenticated;

-- Create a profile and private workspace for every new account.
create or replace function public.zein_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_workspace_id uuid;
  display_name_value text;
begin
  display_name_value := coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1), 'ZEIN User');

  insert into public.zein_profiles(id, display_name)
  values (new.id, display_name_value)
  on conflict (id) do nothing;

  insert into public.zein_workspaces(name, workspace_type, owner_id)
  values ('شخصي', 'personal', new.id)
  returning id into new_workspace_id;

  insert into public.zein_memberships(workspace_id, user_id, role)
  values (new_workspace_id, new.id, 'owner')
  on conflict do nothing;

  return new;
end;
$$;

revoke all on function public.zein_handle_new_user() from public, anon, authenticated;

drop trigger if exists zein_on_auth_user_created on auth.users;
create trigger zein_on_auth_user_created
after insert on auth.users
for each row execute function public.zein_handle_new_user();

-- Do not store provider access tokens in client-readable tables.
comment on table public.zein_channels is
'Provider connection metadata only. OAuth tokens and secrets must be stored server-side in a private vault or backend secret store.';
comment on table public.zein_messages is
'Unified message metadata. Respect each provider API permissions, retention rules, and user consent.';
