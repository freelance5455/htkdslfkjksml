create table if not exists public.company_user_profiles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  job_title text,
  role_key text not null default 'حسابدار',
  permission_keys jsonb not null default '[]'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id,user_id)
);

alter table public.company_user_profiles enable row level security;

create policy "user_profiles_select" on public.company_user_profiles
for select to authenticated
using ((user_id = (select auth.uid())) or app.can_manage_users(company_id));

create policy "user_profiles_insert" on public.company_user_profiles
for insert to authenticated
with check (app.can_manage_users(company_id));

create policy "user_profiles_update" on public.company_user_profiles
for update to authenticated
using (app.can_manage_users(company_id))
with check (app.can_manage_users(company_id));

create policy "user_profiles_delete" on public.company_user_profiles
for delete to authenticated
using (app.can_manage_users(company_id));

create index if not exists company_user_profiles_company_idx
on public.company_user_profiles(company_id);

create index if not exists company_user_profiles_user_idx
on public.company_user_profiles(user_id);

insert into public.company_user_profiles(company_id,user_id,display_name,job_title,role_key,permission_keys,is_active)
select cm.company_id,cm.user_id,
       coalesce(nullif(au.raw_user_meta_data->>'name',''),au.email),
       case cm.role when 'OWNER' then 'مدیر سیستم' when 'FINANCE' then 'مدیر مالی' when 'ADMIN' then 'مدیر عامل' when 'ACCOUNTANT' then 'حسابدار' when 'SALES' then 'کاربر فروش' when 'PURCHASE' then 'خرید' when 'CASHIER' then 'صندوقدار' when 'WAREHOUSE' then 'مدیر انبار' when 'AUDITOR' then 'حسابرس' else 'ناظر' end,
       case cm.role when 'OWNER' then 'مدیر سیستم' when 'FINANCE' then 'مدیر مالی' when 'ADMIN' then 'مدیر عامل' when 'ACCOUNTANT' then 'حسابدار' when 'SALES' then 'کاربر فروش' when 'PURCHASE' then 'خرید' when 'CASHIER' then 'صندوقدار' when 'WAREHOUSE' then 'مدیر انبار' when 'AUDITOR' then 'حسابرس' else 'ناظر' end,
       '[]'::jsonb,cm.is_active
from public.company_members cm
join auth.users au on au.id=cm.user_id
on conflict (company_id,user_id) do update
set display_name=excluded.display_name,
    job_title=coalesce(public.company_user_profiles.job_title,excluded.job_title),
    role_key=excluded.role_key,
    is_active=excluded.is_active,
    updated_at=now();
