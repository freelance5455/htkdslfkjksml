revoke execute on function public.ensure_my_company_membership(uuid) from anon, authenticated;
