-- ====================================================================
-- 3D CHESS PRODUCTION SUPABASE SCHEMA & ROW LEVEL SECURITY POLICIES
-- ====================================================================

-- 1. PROFILES TABLE
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  avatar text default '👑',
  rating integer default 1200 check (rating >= 100),
  total_games integer default 0 check (total_games >= 0),
  wins integer default 0 check (wins >= 0),
  losses integer default 0 check (losses >= 0),
  draws integer default 0 check (draws >= 0),
  title text default 'Beginner',
  online_status text default 'offline' check (online_status in ('online', 'in-game', 'offline')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 2. MATCHMAKING QUEUE TABLE
create table if not exists public.matchmaking_queue (
  id uuid primary key default gen_random_uuid(),
  player_id uuid references public.profiles(id) on delete cascade not null,
  player_name text not null,
  player_avatar text not null,
  player_rating integer not null,
  time_control text not null,
  initial_seconds integer not null,
  increment_seconds integer not null default 0,
  status text not null default 'waiting' check (status in ('waiting', 'matched', 'cancelled')),
  matched_game_id text,
  created_at timestamptz default now()
);

-- 3. GAME ROOMS TABLE (Private Rooms)
create table if not exists public.game_rooms (
  id text primary key, -- e.g. 'CHESS-9821'
  host_id uuid references public.profiles(id) on delete cascade not null,
  host_name text not null,
  guest_id uuid references public.profiles(id) on delete set null,
  guest_name text,
  time_control text not null default '10+0',
  initial_seconds integer not null default 600,
  increment_seconds integer not null default 0,
  status text not null default 'waiting' check (status in ('waiting', 'full', 'active', 'finished')),
  game_id text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 4. GAMES TABLE (Authoritative Match State)
create table if not exists public.games (
  id text primary key,
  room_id text,
  white_id uuid references public.profiles(id) not null,
  white_name text not null,
  white_avatar text default '👑',
  white_rating integer not null,
  black_id uuid references public.profiles(id) not null,
  black_name text not null,
  black_avatar text default '👤',
  black_rating integer not null,
  fen text not null default 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  pgn text default '',
  turn text not null default 'w' check (turn in ('w', 'b')),
  white_time integer not null,
  black_time integer not null,
  increment_seconds integer not null default 0,
  time_control text not null,
  status text not null default 'active' check (status in ('active', 'checkmate', 'stalemate', 'timeout', 'resignation', 'draw_agreement', 'repetition', 'insufficient_material', 'abandoned')),
  winner text check (winner in ('w', 'b', 'draw', null)),
  draw_offered_by text check (draw_offered_by in ('w', 'b', null)),
  move_count integer default 0 check (move_count >= 0),
  is_rated boolean default true,
  last_move_at timestamptz default now(),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 5. GAME MOVES TABLE (Move-by-Move Audit Trail)
create table if not exists public.game_moves (
  id uuid primary key default gen_random_uuid(),
  game_id text references public.games(id) on delete cascade not null,
  move_number integer not null,
  san text not null,
  uci text not null,
  from_square text not null,
  to_square text not null,
  piece text not null,
  color text not null check (color in ('w', 'b')),
  captured text,
  promotion text,
  fen_after text not null,
  white_time_left integer,
  black_time_left integer,
  created_at timestamptz default now()
);

-- 6. GAME RESULTS & ELO HISTORY TABLE
create table if not exists public.game_results (
  id uuid primary key default gen_random_uuid(),
  game_id text references public.games(id) on delete cascade not null unique,
  white_id uuid references public.profiles(id) not null,
  black_id uuid references public.profiles(id) not null,
  winner text not null check (winner in ('w', 'b', 'draw')),
  reason text not null,
  white_rating_change integer not null,
  black_rating_change integer not null,
  white_new_rating integer not null,
  black_new_rating integer not null,
  created_at timestamptz default now()
);

-- 7. RATING HISTORY TABLE
create table if not exists public.rating_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade not null,
  rating integer not null,
  game_id text references public.games(id),
  created_at timestamptz default now()
);

-- 8. FRIENDSHIPS & REQUESTS
create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade not null,
  friend_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now(),
  unique (user_id, friend_id)
);

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid references public.profiles(id) on delete cascade not null,
  receiver_id uuid references public.profiles(id) on delete cascade not null,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'rejected')),
  created_at timestamptz default now(),
  unique (sender_id, receiver_id)
);

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ====================================================================

alter table public.profiles enable row level security;
alter table public.matchmaking_queue enable row level security;
alter table public.game_rooms enable row level security;
alter table public.games enable row level security;
alter table public.game_moves enable row level security;
alter table public.game_results enable row level security;
alter table public.rating_history enable row level security;
alter table public.friendships enable row level security;
alter table public.friend_requests enable row level security;

-- Profiles: Public read, self update
create policy "Profiles are viewable by everyone"
  on public.profiles for select using (true);

create policy "Users can update their own profile"
  on public.profiles for update using (auth.uid() = id);

create policy "Users can insert their own profile"
  on public.profiles for insert with check (auth.uid() = id);

-- Games: Public read (spectator & players), participant update
create policy "Games are viewable by everyone"
  on public.games for select using (true);

create policy "Participants can update active games"
  on public.games for update using (
    auth.uid() = white_id or auth.uid() = black_id
  );

create policy "Authenticated users can create games"
  on public.games for insert with check (
    auth.uid() = white_id or auth.uid() = black_id
  );

-- Game Moves: Read all, insert if participant
create policy "Game moves are viewable by everyone"
  on public.game_moves for select using (true);

create policy "Participants can insert moves"
  on public.game_moves for insert with check (
    exists (
      select 1 from public.games
      where games.id = game_moves.game_id
      and (games.white_id = auth.uid() or games.black_id = auth.uid())
    )
  );

-- Matchmaking Queue: Read own or waiting, insert own, delete own
create policy "View matchmaking queue"
  on public.matchmaking_queue for select using (true);

create policy "Insert into matchmaking queue"
  on public.matchmaking_queue for insert with check (auth.uid() = player_id);

create policy "Delete from matchmaking queue"
  on public.matchmaking_queue for delete using (auth.uid() = player_id);

-- Game Rooms: Read all, host creates, guest or host updates
create policy "Game rooms viewable by everyone"
  on public.game_rooms for select using (true);

create policy "Host creates rooms"
  on public.game_rooms for insert with check (auth.uid() = host_id);

create policy "Host or guest updates rooms"
  on public.game_rooms for update using (auth.uid() = host_id or auth.uid() = guest_id);

-- Game Results & Rating History: Read by all
create policy "Game results viewable by everyone"
  on public.game_results for select using (true);

create policy "Rating history viewable by everyone"
  on public.rating_history for select using (true);

-- ====================================================================
-- ELO RATING CALCULATION FUNCTION
-- ====================================================================

create or replace function calculate_elo(
  winner text,
  white_rating int,
  black_rating int,
  k_factor int default 32
) returns table (white_change int, black_change int) as $$
declare
  expected_white float;
  expected_black float;
  actual_white float;
  actual_black float;
begin
  expected_white := 1.0 / (1.0 + pow(10.0, (black_rating - white_rating) / 400.0));
  expected_black := 1.0 - expected_white;

  if winner = 'w' then
    actual_white := 1.0;
    actual_black := 0.0;
  elsif winner = 'b' then
    actual_white := 0.0;
    actual_black := 1.0;
  else
    actual_white := 0.5;
    actual_black := 0.5;
  end if;

  white_change := round(k_factor * (actual_white - expected_white));
  black_change := round(k_factor * (actual_black - expected_black));
  return next;
end;
$$ language plpgsql;
