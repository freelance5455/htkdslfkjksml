-- Additive migration: optional portal UI language preference.
-- Applied to the live project zoezvthpzbeeklfjwhko on 2026-10-17; do not rerun on that project.
-- Nullable to preserve existing rows and allow browser-only preference before login.
ALTER TABLE public.profiles
  ADD COLUMN preferred_language text NULL;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_preferred_language_check
  CHECK (preferred_language IS NULL OR preferred_language IN ('en', 'es', 'fr', 'de', 'pt', 'pl'));

COMMENT ON COLUMN public.profiles.preferred_language IS
  'Optional portal interface language preference; does not affect release metadata.';
