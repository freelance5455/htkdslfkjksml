-- ====================================================================
-- 3D CHESS PRODUCTION SUPABASE MIGRATION: COMPETITIVE ECOSYSTEM
-- Version: 20261018000000
-- Stage: Prompts 1-5 Comprehensive Competitive Architecture
-- ====================================================================

-- 1. EXTEND PROFILES WITH SEPARATE TIME-CONTROL RATINGS & XP
alter table if exists public.profiles 
  add column if not exists rating_bullet integer default 1200 check (rating_bullet >= 100),
  add column if not exists rating_blitz integer default 1200 check (rating_blitz >= 100),
  add column if not exists rating_rapid integer default 1200 check (rating_rapid >= 100),
  add column if not exists rating_puzzle integer default 1200 check (rating_puzzle >= 100),
  add column if not exists xp integer default 0 check (xp >= 0),
  add column if not exists level integer default 1 check (level >= 1),
  add column if not exists country text default 'US',
  add column if not exists current_streak integer default 0 check (current_streak >= 0),
  add column if not exists max_streak integer default 0 check (max_streak >= 0),
  add column if not exists role text default 'player' check (role in ('player', 'organizer', 'moderator', 'admin')),
  add column if not exists unlocked_themes text[] default array['classic_wood', 'onyx_gold'],
  add column if not exists active_theme text default 'classic_wood',
  add column if not exists active_piece_style text default 'classic';

-- 2. TOURNAMENTS TABLE
create table if not exists public.tournaments (
  id text primary key,
  title text not null,
  description text default '',
  banner_url text,
  format text not null check (format in ('swiss', 'arena', 'single_elimination', 'double_elimination')),
  organizer_id uuid references public.profiles(id) on delete set null,
  organizer_name text not null,
  time_control_type text not null check (time_control_type in ('bullet', 'blitz', 'rapid', 'custom')),
  initial_seconds integer not null default 300,
  increment_seconds integer not null default 0,
  max_participants integer not null default 64 check (max_participants >= 2),
  min_rating integer default 0,
  max_rating integer default 3000,
  is_rated boolean default true,
  is_private boolean default false,
  access_code text,
  rules_description text default 'Standard FIDE tournament rules apply. No external engine assistance.',
  total_rounds integer not null default 5 check (total_rounds >= 1),
  current_round integer not null default 0 check (current_round >= 0),
  duration_minutes integer default 60, -- for Arena tournaments
  registration_start_at timestamptz not null default now(),
  registration_end_at timestamptz not null default now() + interval '2 hours',
  scheduled_start_at timestamptz not null default now() + interval '2 hours',
  actual_start_at timestamptz,
  completed_at timestamptz,
  status text not null default 'registration' check (status in ('registration', 'waiting', 'live', 'completed', 'cancelled')),
  winner_id uuid references public.profiles(id) on delete set null,
  winner_name text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 3. TOURNAMENT PARTICIPANTS
create table if not exists public.tournament_participants (
  id uuid primary key default gen_random_uuid(),
  tournament_id text references public.tournaments(id) on delete cascade not null,
  player_id uuid references public.profiles(id) on delete cascade not null,
  player_name text not null,
  player_rating integer not null default 1200,
  seed integer default 1,
  checked_in boolean default false,
  checked_in_at timestamptz,
  score numeric(6, 2) default 0.0 check (score >= 0.0),
  tie_break_buchholz numeric(6, 2) default 0.0,
  tie_break_sonneborn_berger numeric(6, 2) default 0.0,
  wins integer default 0,
  draws integer default 0,
  losses integer default 0,
  streak integer default 0,
  is_eliminated boolean default false,
  withdrawn boolean default false,
  withdrawn_at timestamptz,
  registered_at timestamptz default now(),
  unique (tournament_id, player_id)
);

-- 4. TOURNAMENT ROUNDS
create table if not exists public.tournament_rounds (
  id text primary key, -- e.g. 'TOUR-101_R1'
  tournament_id text references public.tournaments(id) on delete cascade not null,
  round_number integer not null check (round_number >= 1),
  status text not null default 'pending' check (status in ('pending', 'active', 'completed')),
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz default now(),
  unique (tournament_id, round_number)
);

-- 5. TOURNAMENT PAIRINGS & RESULTS
create table if not exists public.tournament_pairings (
  id text primary key, -- e.g. 'PAIR-101-R1-B1'
  tournament_id text references public.tournaments(id) on delete cascade not null,
  round_number integer not null,
  board_number integer not null,
  white_id uuid references public.profiles(id) on delete set null,
  white_name text not null,
  white_rating integer not null,
  black_id uuid references public.profiles(id) on delete set null,
  black_name text, -- null if bye
  black_rating integer,
  is_bye boolean default false,
  game_id text references public.games(id) on delete set null,
  result text default 'pending' check (result in ('pending', '1-0', '0-1', '1/2-1/2', 'bye', 'white_forfeit', 'black_forfeit', 'double_forfeit')),
  white_score numeric(3, 1) default 0.0,
  black_score numeric(3, 1) default 0.0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 6. DAILY CHALLENGES TABLE
create table if not exists public.daily_challenges (
  id text primary key, -- e.g. 'CHALLENGE-2026-10-18'
  challenge_date date not null unique,
  title text not null,
  category text not null check (category in ('tactics', 'mate_in_2', 'endgame', 'opening_quiz', 'best_move', 'find_defence')),
  difficulty text not null check (difficulty in ('Easy', 'Medium', 'Hard')),
  fen text not null,
  solution_moves text[] not null,
  explanation text not null,
  reward_xp integer not null default 50,
  reward_title text,
  attempts_allowed integer not null default 3,
  is_active boolean default true,
  created_at timestamptz default now()
);

-- 7. CHALLENGE ATTEMPTS & COMPLETIONS
create table if not exists public.challenge_completions (
  id uuid primary key default gen_random_uuid(),
  challenge_id text references public.daily_challenges(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  completed boolean not null default false,
  attempts_count integer default 1,
  time_seconds integer default 0,
  xp_awarded integer default 0,
  completed_at timestamptz default now(),
  unique (challenge_id, user_id)
);

-- 8. ACHIEVEMENTS CATALOG
create table if not exists public.achievements (
  id text primary key,
  name text not null,
  description text not null,
  category text not null check (category in ('combat', 'progression', 'tournaments', 'tactics', 'mastery')),
  icon text not null default '🏆',
  reward_xp integer default 100,
  reward_badge text,
  target_count integer default 1
);

-- 9. PLAYER ACHIEVEMENTS (Unlocked & Progress)
create table if not exists public.player_achievements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade not null,
  achievement_id text references public.achievements(id) on delete cascade not null,
  progress integer default 0,
  is_unlocked boolean default false,
  unlocked_at timestamptz,
  created_at timestamptz default now(),
  unique (user_id, achievement_id)
);

-- 10. FAIR PLAY FLAGS & REVIEWS
create table if not exists public.fair_play_flags (
  id uuid primary key default gen_random_uuid(),
  game_id text references public.games(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  acpl numeric(5, 2), -- Average Centipawn Loss
  engine_similarity numeric(5, 2), -- 0 - 100%
  blunder_count integer default 0,
  move_time_variance numeric(8, 2),
  risk_level text not null default 'low' check (risk_level in ('low', 'medium', 'high', 'critical')),
  flag_reasons text[] default array[]::text[],
  is_reviewed boolean default false,
  created_at timestamptz default now()
);

-- 11. USER REPORTS
create table if not exists public.user_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references public.profiles(id) on delete cascade not null,
  reported_id uuid references public.profiles(id) on delete cascade not null,
  game_id text references public.games(id) on delete set null,
  category text not null check (category in ('suspected_engine', 'stalling', 'abandonment', 'harassment', 'other')),
  notes text default '',
  status text not null default 'pending' check (status in ('pending', 'investigating', 'resolved', 'dismissed')),
  reviewed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 12. MODERATION ACTIONS
create table if not exists public.moderation_actions (
  id uuid primary key default gen_random_uuid(),
  target_user_id uuid references public.profiles(id) on delete cascade not null,
  action_type text not null check (action_type in ('warning', 'temporary_ban', 'permanent_ban', 'rating_adjustment', 'unban')),
  reason text not null,
  expires_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz default now()
);

-- 13. NOTIFICATIONS TABLE
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade not null,
  type text not null check (type in ('tournament_pairing', 'tournament_start', 'match_invite', 'daily_challenge', 'achievement_unlocked', 'moderation_notice', 'friend_request')),
  title text not null,
  message text not null,
  data jsonb default '{}'::jsonb,
  is_read boolean default false,
  created_at timestamptz default now()
);

-- 14. AUDIT LOGS
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_entity text not null,
  target_id text not null,
  details jsonb default '{}'::jsonb,
  ip_hash text,
  created_at timestamptz default now()
);

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES FOR COMPETITIVE SYSTEM
-- ====================================================================

alter table public.tournaments enable row level security;
alter table public.tournament_participants enable row level security;
alter table public.tournament_rounds enable row level security;
alter table public.tournament_pairings enable row level security;
alter table public.daily_challenges enable row level security;
alter table public.challenge_completions enable row level security;
alter table public.achievements enable row level security;
alter table public.player_achievements enable row level security;
alter table public.fair_play_flags enable row level security;
alter table public.user_reports enable row level security;
alter table public.moderation_actions enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;

-- Tournaments
create policy "Tournaments are viewable by everyone"
  on public.tournaments for select using (true);

create policy "Organizers and admins can create tournaments"
  on public.tournaments for insert with check (
    auth.uid() = organizer_id or exists (
      select 1 from public.profiles where id = auth.uid() and role in ('organizer', 'admin')
    )
  );

create policy "Organizers and admins can update their tournaments"
  on public.tournaments for update using (
    auth.uid() = organizer_id or exists (
      select 1 from public.profiles where id = auth.uid() and role in ('admin')
    )
  );

-- Tournament Participants
create policy "Tournament participants viewable by all"
  on public.tournament_participants for select using (true);

create policy "Users can register themselves for tournaments"
  on public.tournament_participants for insert with check (auth.uid() = player_id);

create policy "Users or organizers can update participant record"
  on public.tournament_participants for update using (
    auth.uid() = player_id or exists (
      select 1 from public.tournaments t where t.id = tournament_id and t.organizer_id = auth.uid()
    )
  );

-- Tournament Pairings
create policy "Tournament pairings viewable by all"
  on public.tournament_pairings for select using (true);

-- Daily Challenges
create policy "Daily challenges viewable by all"
  on public.daily_challenges for select using (true);

-- Challenge Completions
create policy "Challenge completions viewable by user"
  on public.challenge_completions for select using (auth.uid() = user_id);

create policy "Users record their challenge completions"
  on public.challenge_completions for insert with check (auth.uid() = user_id);

-- Achievements & Player Achievements
create policy "Achievements viewable by all"
  on public.achievements for select using (true);

create policy "Player achievements viewable by all"
  on public.player_achievements for select using (true);

create policy "Player achievements upsertable by user"
  on public.player_achievements for insert with check (auth.uid() = user_id);

-- Notifications
create policy "Users can view their own notifications"
  on public.notifications for select using (auth.uid() = user_id);

create policy "Users can update their own notifications"
  on public.notifications for update using (auth.uid() = user_id);

-- User Reports
create policy "Users can create reports"
  on public.user_reports for insert with check (auth.uid() = reporter_id);

create policy "Users can view reports they created"
  on public.user_reports for select using (
    auth.uid() = reporter_id or exists (
      select 1 from public.profiles where id = auth.uid() and role in ('moderator', 'admin')
    )
  );

-- Fair Play Flags & Moderation Actions (Staff only)
create policy "Fair play flags viewable by staff only"
  on public.fair_play_flags for select using (
    exists (
      select 1 from public.profiles where id = auth.uid() and role in ('moderator', 'admin')
    )
  );

create policy "Moderation actions viewable by affected user or staff"
  on public.moderation_actions for select using (
    auth.uid() = target_user_id or exists (
      select 1 from public.profiles where id = auth.uid() and role in ('moderator', 'admin')
    )
  );
