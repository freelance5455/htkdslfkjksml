-- Not yet applied. Apply with the v24 migration before deploying v26.
alter table public.releases add column if not exists upc text;
