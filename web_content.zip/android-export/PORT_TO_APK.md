# Porting Sector 04: Bodycam to an Android APK

This project is already configured for Android APK packaging (`base: './'` in `vite.config.ts`, multi-touch mobile controls, and `viewport-fit=cover` in `index.html`).

---

## Option A — Capacitor (Recommended, Fastest)

Requires **Node.js 18+** and **Android Studio** (or Android SDK + JDK 17).

1. **Build the production web bundle:**
   ```bash
   npm install
   npm run build
   ```
2. **Install Capacitor & add the Android platform:**
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   cp android-export/capacitor.config.json ./capacitor.config.json
   npx cap add android
   npx cap sync android
   ```
3. **Lock orientation to Landscape & ensure hardware acceleration:**
   - Open `android/app/src/main/AndroidManifest.xml`
   - Add `android:screenOrientation="sensorLandscape"` and `android:hardwareAccelerated="true"` to `<activity>`.
4. **Build the APK:**
   - Open in Android Studio:
     ```bash
     npx cap open android
     ```
     Then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   - Or build directly via Gradle CLI:
     ```bash
     cd android && ./gradlew assembleDebug
     ```
     Output APK: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## Option B — Native Android Studio WebView Wrapper (Zero Capacitor)

If you prefer a pure Android Studio Kotlin project:

1. Create a new **Empty Views Activity** project in Android Studio with package name `com.sector04.bodycam` (Min SDK 24+).
2. Add the AndroidX WebKit dependency in `app/build.gradle.kts`:
   ```kotlin
   implementation("androidx.webkit:webkit:1.11.0")
   ```
3. Run `npm run build` in this web project and copy the entire `dist/` contents into:
   ```
   app/src/main/assets/www/
   ```
   (So `app/src/main/assets/www/index.html` exists.)
4. Replace `MainActivity.kt` and `AndroidManifest.xml` with the ready-made files in `android-export/`.
5. Click **Build → Build APK(s)** in Android Studio.
