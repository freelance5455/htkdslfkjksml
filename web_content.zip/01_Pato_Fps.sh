#!/bin/bash
# Pato +Fps - Comandos limpos com 2>/dev/null || true
echo "Aplicando Pato +Fps..."

# Força 120 FPS por app (exemplo genérico - o original faz loop em todos os packages)
settings put secure custom_app_interface_fps_com.dts.freefireth 120 2>/dev/null || true
settings put secure custom_app_interface_fps_com.dts.freefiremax 120 2>/dev/null || true
settings put secure custom_app_interface_fps_com.garena.game.codm 120 2>/dev/null || true
settings put global custom_game_hardware_com.dts.freefireth SM8550-AC 2>/dev/null || true
settings put global custom_android_gpu_vendorcom.dts.freefireth Qualcomm 2>/dev/null || true
settings put global custom_android_cpu_vendorcom.dts.freefireth Qualcomm 2>/dev/null || true

# FPS geral
settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system min_refresh_rate 120 2>/dev/null || true

echo "Pato +Fps aplicado!"
