STITCH AI SENSI — PROYECTO ANDROID

IMPORTANTE: Este ZIP contiene el PROYECTO FUENTE Android, no un APK/AAB ya compilado.
La app es una primera aplicación Android instalable con interfaz integrada. El generador actual usa reglas locales de demostración y el chat es un asistente local con respuestas predefinidas. Aún NO hay IA generativa conectada, aprendizaje automático real, servidor ni base de datos remota. No se debe anunciar como IA real hasta completar esas partes y probarlas.

REQUISITOS PARA COMPILAR
- Android Studio actualizado.
- JDK 17.
- Android SDK Platform 36 instalado.
- Conexión a Internet para que Gradle descargue las dependencias del plugin.

CÓMO CREAR APK/AAB
1. Descomprime STITCH_AI_SENSI_ANDROID.zip en una computadora.
2. Abre Android Studio > Open y selecciona la carpeta STITCH_AI_SENSI_ANDROID.
3. Espera a que termine Gradle Sync. Instala Android SDK 36 si Android Studio lo solicita.
4. Para probar en un Android: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Para Play Store: Build > Generate Signed Bundle / APK > Android App Bundle.
6. Crea y guarda tu clave de firma (keystore) en un lugar seguro; no la compartas ni la pierdas.
7. El archivo AAB se genera dentro de app/build/outputs/bundle/release/.

REQUISITO ACTUAL DE GOOGLE PLAY
A 31-oct-2026, las aplicaciones nuevas deben apuntar a Android 16 / API 36 o superior. Este proyecto declara compileSdk 36 y targetSdk 36. Verifica los requisitos de Google Play antes de enviar.

PUBLICACIÓN
Google Play Console exige que quien registre la cuenta de desarrollador tenga 18 años o más. Si el desarrollador es menor, la cuenta y publicación deben ser gestionadas por un adulto responsable, sin falsear edad ni identidad. También habrá que completar las declaraciones de datos, clasificación de contenido, ficha de tienda, política de privacidad si corresponde, pruebas y revisión de Google.

COMPATIBILIDAD
minSdk 23 permite una amplia gama de Android, pero la compatibilidad real depende del modelo, versión Android, memoria y pruebas. No es posible garantizar todos los teléfonos.

La aplicación no modifica Free Fire ni automatiza disparos. No está afiliada a Garena.
