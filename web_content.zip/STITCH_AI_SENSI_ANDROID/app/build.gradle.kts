plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.stitchaisensi.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.stitchaisensi.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }
}
