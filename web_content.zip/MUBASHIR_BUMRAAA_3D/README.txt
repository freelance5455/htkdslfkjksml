MUBASHIR BUMRAAA — 3D-STYLE BROWSER GAME

HOW TO PLAY
1. Extract the ZIP.
2. Open index.html in Chrome (or another modern browser).
3. Enter a name and tap ENTER THE ARENA.
4. Use the arrows and FIRE button. On computer, use arrow keys/WASD and Space.

IMPORTANT ABOUT PLAYING WITH A FRIEND
This package is a self-contained browser game with practice mode, so the name/OK screen works on another phone too. It is NOT yet live online multiplayer: live multiplayer needs a shared server hosted on the internet. Sending only the ZIP to a friend cannot create that server automatically. This build includes no login, no tracking, and no external libraries.
