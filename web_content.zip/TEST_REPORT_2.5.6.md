# ANONYMOUX STUDIO 2.5.6 — Test Report

## Passed in this build environment
- PHP syntax: all 81 PHP files passed `php -l`.
- JavaScript syntax: all JavaScript files under `assets/` passed `node --check`.
- Existing Python contract/regression suites passed: billing source checks, SQLite billing contract (3 tests), branding/voice integration, resource admin regression, resource migration, voice dashboard follow-up, voice flow repair, and voice idempotency migration.
- New Fish Audio Agent contract test passed: documented route allowlist, SDK session-token handoff, measured provider duration and configurable billing conversion.
- New image assets were verified as WebP and all Explore thumbnail references resolve to files in the package.

## Environment limitations
- PHP PDO is present but has no installed PDO drivers; PDO_SQLITE and PDO_MYSQL are unavailable.
- PHP cURL is not installed in this build runtime.
- Therefore PHP database execution, migrations through PDO, Flutterwave API calls, Fish Audio authentication/agent creation/publishing, LiveKit WebRTC/microphone, and real provider usage settlement could not be run here.
- No real Fish Audio or Flutterwave credentials were supplied. Live integration tests remain pending on the deployment's staging host.

## Production acceptance still required
1. Run the additive migrations on a backed-up staging database.
2. Verify a real Fish Audio API key in Admin → Voice AI.
3. Create, edit, publish, text-test and voice-test an agent over HTTPS.
4. End the session and verify provider-reported `duration_seconds` and any `billable_cost_usd` records.
5. Configure the administrator's current USD-to-NGN conversion and agreed markup before enabling Agent wallet deductions.
6. Test Flutterwave checkout, signature-verified webhook, exact amount/currency checks, duplicate webhook handling and wallet ledger idempotency in test mode.
7. Perform mobile and desktop acceptance on the actual shared host.

No live provider or payment test is represented as passed.
