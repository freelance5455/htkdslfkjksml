package com.parsamehr.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/index.html";
    private static final int REQ_FILE = 101, REQ_PERM = 102;

    private WebView webView;
    private ValueCallback<Uri[]> fileCb;
    private WebChromeClient.FileChooserParams fileParams;
    private Uri camUri;
    private File camFile;
    private boolean pendingFile = false;
    private PermissionRequest pendingPerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u);   // tel: ، wa.me ، t.me ، mailto: و ...
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                fileParams = p;
                boolean cap = p.isCaptureEnabled() && acceptsImage(p);
                if (cap && !hasCam()) {
                    pendingFile = true;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERM);
                    return true;
                }
                startFileChooser(cap);
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> {
                    if (!HOST.equals(r.getOrigin().getHost())) { r.deny(); return; }
                    boolean video = false;
                    for (String x : r.getResources())
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x)) video = true;
                    if (!video) { r.deny(); return; }
                    if (hasCam()) {
                        r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingPerm = r;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERM);
                    }
                });
            }
        });

        webView.addJavascriptInterface(new PMNative(this), "PMNative");
        webView.loadUrl(START);
    }

    private boolean hasCam() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private static boolean acceptsImage(WebChromeClient.FileChooserParams p) {
        String[] t = p.getAcceptTypes();
        if (t == null) return false;
        for (String x : t) if (x != null && x.startsWith("image")) return true;
        return false;
    }

    private void startFileChooser(boolean withCamera) {
        try {
            Intent chooser = new Intent(Intent.ACTION_CHOOSER);
            chooser.putExtra(Intent.EXTRA_INTENT, fileParams.createIntent());
            chooser.putExtra(Intent.EXTRA_TITLE, "انتخاب فایل");
            camUri = null;
            camFile = null;
            if (withCamera) {
                File dir = new File(getCacheDir(), "share");
                if (!dir.exists()) dir.mkdirs();
                camFile = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
                camUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", camFile);
                Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cam.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    for (ResolveInfo ri : getPackageManager().queryIntentActivities(cam, PackageManager.MATCH_DEFAULT_ONLY))
                        grantUriPermission(ri.activityInfo.packageName, camUri,
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Throwable ignore) { }
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
            }
            startActivityForResult(chooser, REQ_FILE);
        } catch (Throwable e) {
            finishFile(null);
        }
    }

    private void finishFile(Uri[] r) {
        if (fileCb != null) {
            fileCb.onReceiveValue(r);
            fileCb = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE) return;
        Uri[] out = null;
        if (res == RESULT_OK) {
            if (data != null && (data.getData() != null || data.getClipData() != null)) {
                out = WebChromeClient.FileChooserParams.parseResult(res, data);
            } else if (camUri != null && camFile != null && camFile.length() > 0) {
                out = new Uri[]{camUri};
            }
        }
        finishFile(out);
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(rc, perms, grants);
        if (rc != REQ_PERM) return;
        boolean ok = grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED;
        if (pendingFile) {
            pendingFile = false;
            if (fileCb != null) startFileChooser(ok);
        }
        if (pendingPerm != null) {
            PermissionRequest r = pendingPerm;
            pendingPerm = null;
            if (ok) r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else r.deny();
        }
    }

    private void openExternal(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable ignore) { }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("PMNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
