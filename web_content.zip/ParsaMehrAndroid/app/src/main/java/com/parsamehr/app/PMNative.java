package com.parsamehr.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * پل Native پارسامهر. در WebView با نام «PMNative» ثبت می‌شود.
 * قرارداد با جاوااسکریپت: همهٔ متدها رشته برمی‌گردانند؛ موفقیت = با «ok» شروع شود.
 */
public class PMNative {
    private static final String TAG = "PMNative";
    private final Activity act;
    private final Context ctx;

    public PMNative(Activity activity) {
        this.act = activity;
        this.ctx = activity.getApplicationContext();
    }

    // ---------- اشتراک‌گذاری ----------

    @JavascriptInterface
    public String shareFile(String b64, String name, String mime, String title) {
        try {
            File f = writeCache(b64, name);
            Uri u = FileProvider.getUriForFile(ctx, authority(), f);
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType(mimeOf(mime, name));
            s.putExtra(Intent.EXTRA_STREAM, u);
            s.setClipData(ClipData.newRawUri(f.getName(), u));
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            List<Uri> l = new ArrayList<>();
            l.add(u);
            launchChooser(s, l, title);
            return "ok";
        } catch (Throwable e) {
            return fail("shareFile", e);
        }
    }

    /** json = [{"b64":"...","name":"a.png","mime":"image/png"}, ...] */
    @JavascriptInterface
    public String shareFiles(String json, String title) {
        try {
            JSONArray a = new JSONArray(json);
            ArrayList<Uri> uris = new ArrayList<>();
            String common = null;
            boolean same = true;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                File f = writeCache(o.getString("b64"), o.optString("name", "file"));
                uris.add(FileProvider.getUriForFile(ctx, authority(), f));
                String m = mimeOf(o.optString("mime", ""), f.getName());
                if (common == null) common = m;
                else if (!common.equals(m)) same = false;
            }
            if (uris.isEmpty()) return "err: empty";
            Intent s;
            if (uris.size() == 1) {
                s = new Intent(Intent.ACTION_SEND);
                s.putExtra(Intent.EXTRA_STREAM, uris.get(0));
            } else {
                s = new Intent(Intent.ACTION_SEND_MULTIPLE);
                s.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            }
            s.setType(same ? common : "*/*");
            ClipData cd = ClipData.newRawUri("parsamehr", uris.get(0));
            for (int i = 1; i < uris.size(); i++) cd.addItem(new ClipData.Item(uris.get(i)));
            s.setClipData(cd);
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            launchChooser(s, uris, title);
            return "ok";
        } catch (Throwable e) {
            return fail("shareFiles", e);
        }
    }

    @JavascriptInterface
    public String shareText(String text, String title) {
        try {
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
            launchChooser(s, new ArrayList<Uri>(), title);
            return "ok";
        } catch (Throwable e) {
            return fail("shareText", e);
        }
    }

    // ---------- ذخیره ----------

    @JavascriptInterface
    public String saveImage(String b64, String name, String mime) {
        return saveMedia(b64, name, mimeOf(mime, name), true);
    }

    @JavascriptInterface
    public String saveFile(String b64, String name, String mime) {
        return saveMedia(b64, name, mimeOf(mime, name), false);
    }

    @JavascriptInterface
    public String openFile(String b64, String name, String mime) {
        try {
            File f = writeCache(b64, name);
            Uri u = FileProvider.getUriForFile(ctx, authority(), f);
            Intent v = new Intent(Intent.ACTION_VIEW);
            v.setDataAndType(u, mimeOf(mime, name));
            v.setClipData(ClipData.newRawUri(f.getName(), u));
            v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            List<Uri> l = new ArrayList<>();
            l.add(u);
            launchChooser(v, l, "باز کردن با…");
            return "ok";
        } catch (Throwable e) {
            return fail("openFile", e);
        }
    }

    @JavascriptInterface
    public String copyImage(String b64, String name, String mime) {
        try {
            final Uri u = FileProvider.getUriForFile(ctx, authority(), writeCache(b64, name));
            act.runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newUri(ctx.getContentResolver(), "parsamehr", u));
            });
            return "ok";
        } catch (Throwable e) {
            return fail("copyImage", e);
        }
    }

    @JavascriptInterface
    public String printPdf(String b64, String name) {
        try {
            final File f = writeCache(b64, name);
            final String job = f.getName();
            act.runOnUiThread(() -> {
                PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                pm.print(job, new PdfAdapter(f, job), null);
            });
            return "ok";
        } catch (Throwable e) {
            return fail("printPdf", e);
        }
    }

    // ---------- کمکی‌ها ----------

    private String authority() {
        return ctx.getPackageName() + ".fileprovider"; // باید با Manifest یکی باشد
    }

    private void launchChooser(Intent target, List<Uri> uris, String title) {
        final Intent ch = Intent.createChooser(target,
                (title == null || title.isEmpty()) ? "ارسال" : title);
        ch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        // سازگاری با نسخه‌های قدیمی: مجوز خواندن به برنامه‌های مقصد
        try {
            if (!uris.isEmpty()) {
                for (ResolveInfo ri : ctx.getPackageManager()
                        .queryIntentActivities(target, PackageManager.MATCH_DEFAULT_ONLY)) {
                    for (Uri u : uris) {
                        ctx.grantUriPermission(ri.activityInfo.packageName, u,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    }
                }
            }
        } catch (Throwable ignore) { }
        act.runOnUiThread(() -> act.startActivity(ch));
    }

    private File writeCache(String b64, String name) throws Exception {
        File dir = new File(ctx.getCacheDir(), "share");
        if (!dir.exists()) dir.mkdirs();
        long old = System.currentTimeMillis() - 24L * 3600 * 1000;
        File[] ex = dir.listFiles();
        if (ex != null) for (File x : ex) if (x.lastModified() < old) x.delete();
        File f = new File(dir, safeName(name));
        byte[] data = Base64.decode(b64, Base64.DEFAULT);
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
        return f;
    }

    private static String safeName(String n) {
        if (n == null || n.trim().isEmpty()) n = "parsamehr_file";
        n = n.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        return n.length() > 120 ? n.substring(n.length() - 120) : n;
    }

    private static String mimeOf(String mime, String name) {
        if (mime != null && mime.matches("[\\w.+-]+/[\\w.+-]+")) return mime;
        String n = name == null ? "" : name.toLowerCase();
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".csv")) return "text/csv";
        if (n.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        return "application/octet-stream";
    }

    private String saveMedia(String b64, String name, String mime, boolean image) {
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            String nm = safeName(name);
            String sub = (image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/parsamehr";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = ctx.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, nm);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, sub);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri col = image
                        ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri u = cr.insert(col, v);
                if (u == null) return "err: insert failed";
                try (OutputStream o = cr.openOutputStream(u)) { o.write(data); }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(u, v, null, null);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS), "parsamehr");
                if (!dir.exists() && !dir.mkdirs()) return "err: mkdirs failed (WRITE_EXTERNAL_STORAGE?)";
                File f = new File(dir, nm);
                try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
                MediaScannerConnection.scanFile(ctx, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
            }
            return "ok " + sub + "/";
        } catch (Throwable e) {
            return fail("saveMedia", e);
        }
    }

    private static String fail(String where, Throwable e) {
        Log.e(TAG, where, e);
        return "err: " + where + ": " + e;
    }

    private static class PdfAdapter extends PrintDocumentAdapter {
        private final File f;
        private final String name;
        PdfAdapter(File f, String name) { this.f = f; this.name = name; }

        @Override
        public void onLayout(PrintAttributes o, PrintAttributes n, CancellationSignal c,
                             LayoutResultCallback cb, android.os.Bundle b) {
            if (c.isCanceled()) { cb.onLayoutCancelled(); return; }
            cb.onLayoutFinished(new PrintDocumentInfo.Builder(name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(), true);
        }

        @Override
        public void onWrite(PageRange[] p, ParcelFileDescriptor d, CancellationSignal c, WriteResultCallback cb) {
            try (InputStream in = new FileInputStream(f);
                 OutputStream out = new FileOutputStream(d.getFileDescriptor())) {
                byte[] buf = new byte[16384];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (Exception e) {
                cb.onWriteFailed(e.toString());
            }
        }
    }
}
