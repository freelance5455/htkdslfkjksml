# OPUX 2.3 status
Version 2.3.3 (versionCode 10). Browser-tested with headless Chromium. **No APK has been built or tested.** See `QA/TEST_REPORT_2_3_3.md` (swipe/tab-transition glitch fixes).

## 2.3.1 bug-fix pass (2026-11-27)
- Fixed theme CSS selector leakage: palette cards carry `data-t` attributes, so unscoped theme selectors were applying each palette's app-wide surface/text variables to its own card. Theme selectors are now scoped to the document root.
- All 10 palettes are available in both Dark and Light modes. Palette cards use a consistent mode-appropriate surface and readable text; each card displays its own palette-specific gradient preview.
- Fixed swipe hand-off ordering: the destination page is rendered while the outgoing app panel remains translated, then the swipe layers/transforms are cleaned up. This prevents a one-frame return to the old page and delayed-looking top intro/summary content.
- Existing swipe gesture behavior, page destinations, and data model remain intact.

## Validation
- JavaScript syntax check: PASS.
- Existing swipe/motion/RDBD/colour/branch regression suite: 39/39 PASS.
- Theme + swipe hand-off suite: 84/84 PASS, including all 10 palettes in both modes.
- Midnight/data regression suite: 56/56 PASS across UTC, New York, Karachi, and London.
- Total targeted browser checks: 179/179 PASS.
- Screenshots of Light and Dark appearance previews are in `QA/`.
- Android Gradle build, APK installation, and physical-device testing remain unverified. No Gradle wrapper or installed Gradle executable was available in this environment; headless Chromium tests do not replace Android WebView/device testing.
