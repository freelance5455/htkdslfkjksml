# OPUX v1.4 — status

Base: the supplied project is the "24H TRACKER" v1.2 WebView app (LocalStorage key `h24v1`). The tracker engine (48-token canvas liquid-ball board, tilt/drag, timers, calculations) and the original data model are unchanged. New data lives in an optional `ext` field inside the same object, so old backups import unchanged and new exports still contain every original field.

## Implemented and tested (headless Chromium 390x800, touch events, seeded old-format backup; 0 JS errors)
- Navigation: 5 docked tabs, sliding indicator, directional transitions, swipe between tabs (not on canvas/charts/inputs), app-level Back (side panel -> dialog -> nested page -> Home -> exit), visible back buttons.
- Home: identity + device date, Settings gear, Quick-actions side panel (left), prominent live Tracker widget, Branch Library preview, Today's progress, RDBD card (today's quote + season), rearrangeable widgets (Branch / Progress / RDBD).
- Tracker: original spherical board preserved; History day page uses the same board read-only.
- Stats: Daily/Weekly/Monthly/All Time (Weekly merged in), original Insights kept, graph library: line, bar, stacked area, doughnut, calendar heatmap, scatter, histogram, radar. Period + activity filters, tap-to-inspect, expand. Charts show a message instead of fake data when data is insufficient.
- History: dedicated read-only day page (total, breakdown, timeline, board, prev/next, notes/records/milestones for the day).
- Records: Achievement cards + Trophy cabinet, all calculated from stored data (best study/productive/sleep/entertainment days, activity types, least untracked, longest streak >=20 h, per-activity bests), labelled "Calculated"; user-defined milestones labelled "Manual".
- Branch workspace: multiple branches, blank or template (placeholder labels), add/rename/delete nodes, sub-branches, cross-links, collapse/expand, image + file attachments, links, drag, pan, pinch/wheel zoom, Radial / Tree / Mind-map layouts, animated growth, line reveal, tween on relayout, selected-node focus, persistent.
- RDBD: season (name/start/length, computed day count), quote carousel (auto 7 s, swipe, arrows, dots), daily quote, notes, add/edit/delete. No invented content.
- Side panels: left (quick actions), right (node/branch details); visible close, swipe-to-close, scrim, Back support.
- Themes: Graphite, Midnight (dark), Daylight, Paper (light) + the 6 original themes kept. Coordinated bg/surface/border/accent/text variables. Activity colours unaffected.
- Sounds: master switch, volume, per-category enable (tap, navigation, timer, success, error), 5 built-in sounds per category with preview, imported audio (<=~500 KB) with preview/assign/remove, generated ambient (rain, rumble), pauses when app hidden.
- Dates `DD MON YYYY`; separate 12h/24h clock setting; durations unaffected.
- Backup: old backup loads; export -> import round trip (including branches, RDBD, sounds) verified; hostile/invalid `ext` data is sanitised on import.
- Fixed original bug: line chart label "... to undefined".

## Written but NOT compiled or run on a device (no Android SDK/Gradle here)
MainActivity.java: JS-aware Back, file chooser (original had none, so Import could not open), export and attachment saving via system file saver, external links opened outside the WebView. Tilt sensor, audio output, file pickers and WebView rendering are untested on Android.

## Limits / not done
- No APK built. Build: JDK 17, SDK 35, `gradle assembleDebug`, then test on a phone.
- Attachments/images/sounds are stored in LocalStorage (~5 MB total); the app warns if storage is full. Images are downscaled; files limited to 400 KB, sounds to ~500 KB.
- Branch workspace tested up to small trees only; no large-tree performance test. Branch Library card shows names and counts, not a drawn preview.
- Notifications: original checkbox behaviour only (Android WebView may not support the Notification API).
- Visual design follows the brief (flat, restrained) but was not matched pixel-for-pixel to the concept image; the legacy 6 themes keep their old palettes.

## v1.4 design + motion pass (tested: regression suite, 254-tap random "monkey" run over 12 screens, 0 JS errors)
- Design system: type scale (uppercase overline section titles, 26 px headings), tonal card surfaces with subtle top highlight, 16 px radii, restrained accent tint behind the header, Material-3-style pill nav indicator, icon tiles in More, light/dark safe.
- Motion (M3 emphasized-decelerate easing): shared-axis page slide + fade, staggered card entrance, nav pill + icon transition, press scale feedback, progress segments sweep, charts draw/grow in, Home ring fill, count-up totals, sheet/panel slide, FAB pop, toast. Everything is disabled under prefers-reduced-motion.
- New: Home ring widget with greeting, daily productive-goal setting + progress, haptic feedback setting (Android bridge), toasts for saves.
- Bugs fixed: swiping on an open side panel changed tabs underneath it; count-up showed fractional minutes.
- Not verified: Android haptic bridge and all Java code (uncompiled), real-device frame rate, exact match to the two concept images (patterns adopted, not pixel-copied).

## OPUX 2.0 design transformation pass (source updated; Android build not verified)

### Implemented
- Home now has a live-data spatial hero with a dimensional orbit motif, actual tracked-time percentage, and retained Tracker / compact Branch / Progress / RDBD widgets. Branch Library and More also have redesigned spatial/editorial directory layouts with their existing actions preserved.
- Bundled Lato Regular/Bold/Heavy and DejaVu Serif display fonts with license files. Latin UI uses the bundled faces; unsupported scripts fall back to Android/system fonts.
- Branch workspace now opens in presentation-first View Mode. Node details are read-only until explicit edit. Edit Mode exposes node/layout controls; Save commits and Cancel restores a pre-edit snapshot. Storage writes are deferred while the Branch edit session is active.
- RDBD now opens presentation-first, with a daily editorial quote panel, progress indicator, swipe/arrows, automatic 7-second progression that restarts after each slide, and interaction/visibility/reduced-motion interruption. Entry and season management are behind Edit RDBD.
- Date format defaults to `October 30, 2026 (Fri)` and can be switched to `30 OCT 2026`; weekday is computed by JavaScript Date. Existing 12/24-hour time selection remains.
- Splash palette updated to the dark OPUX visual language.
- Design research PDF and evidence notes added under `DESIGN_RESEARCH/`, outside runtime assets.
- Android project version metadata advanced to 2.0.0 (versionCode 5).

### Three.js decision
- Inspected supplied Three.js 0.187.0 archive. It contains the module/core builds and MIT license but not the addons/examples tree. It was not integrated because the existing app runs from `file:///android_asset/` and has no AndroidX WebKit asset-loader setup for safe local ES-module imports. The current spatial branch implementation retains the existing SVG graph and adds a more dimensional presentation layer; no unused Three.js payload is shipped.

### Verification performed
- Node.js JavaScript syntax check: passed.
- Headless Chromium synthetic-data test at 390 × 844: Home hero rendered; Branch View/Edit state toggled; Cancel restored the edited node title; date-format setting toggled; RDBD presentation/edit states toggled; zero page errors and zero console errors.
- Home, Branch and RDBD screenshots inspected.

### Not verified / remaining work
- Android Gradle build and APK: not performed (no Android SDK, Gradle executable or wrapper available in this environment).
- No real Android phone/WebView verification of native bridge, file picker, file export, haptics, sensors, audio, keyboard resize, Bangla glyph fallback or lower-end GPU performance.
- The remaining secondary screens received the shared typography/surface system but have not each received a full bespoke visual redesign.
- Branch remains an interactive SVG spatial graph, not a Three.js 3D scene. Large graph performance and accessibility review remain outstanding.
- Research PDF pages 10–11 contain links to interface galleries/screenshots rather than embedded screenshot images. The project notes this limitation; no fictional screenshots were created or presented as real.

## OPUX 2.1 — time awareness and Home spatial interaction

### Implemented
- Home live clock uses the Android device's local time through JavaScript `Date`; it respects the existing 12/24-hour preference.
- Check-in reminder is local and foreground-only. Default interval is 60 minutes; Settings supports 45, 60, 90 or 120 minutes.
- The reminder asks what activity occupied the elapsed interval. User selects the activity, can edit hours/minutes and add a note, then explicitly saves. It does not auto-classify or silently write records.
- Suggested elapsed duration is capped at 12 hours and clearly described as an estimate, not phone-usage history. Remind-me-later snoozes for 30 minutes; Not now snoozes for 60 minutes.
- Existing Tracker add/edit sheet now accepts hours and minutes as well as quick duration chips. Stored records remain in minutes, preserving the original `h24v1` model.
- Home orbit has pointer/touch parallax, 3D CSS transforms, glow/breathing and pulsing nodes; reduced-motion preference disables continuous animation.
- Secondary screens (Tracker, Statistics, History, Records, Sounds, Themes and Settings) now receive consistent editorial screen intros and refined surfaces; Settings includes check-in controls.

### Verification performed
- `node --check` on the complete application script: passed.
- Headless Chromium seeded-data screen sweep for Tracker, Stats, History, Records, More, Settings, Sounds, Themes and Branch Library: all rendered; zero page errors and zero console errors.
- Existing OPUX 2.0 regression suite: Branch View/Edit, Save/Cancel, date preference, RDBD edit and 7-second quote progression passed; original tracker total remained 640 minutes in the seeded test.
- Check-in feature test: Home clock/card rendered; 90-minute check-in saved; manual 2h 15m entry converted to 135 minutes; no page errors.
- Overdue reminder test: 75-minute overdue prompt appeared; Remind me later snoozed it; Settings interval changed to 90 minutes; no page errors.

### Not verified / limitations
- No APK built; Android SDK/Gradle remain unavailable in the authoring environment. No real-device WebView testing performed.
- Check-in is based on elapsed time since the last in-app check-in, not Android Digital Wellbeing, screen-time history, notification history or activity recognition. It runs while the app is open/active; no background notification permission or native alarm service was added.
- The original data model stores activity durations rather than true timestamped start/end intervals. Check-in entries therefore add confirmed durations to the selected day; they do not create precise event timestamps.
- Home 3D effect is CSS/pointer parallax, not a Three.js/WebGL scene. Three.js remains intentionally unbundled due to the existing local-file WebView module-origin constraints.
- The original project has no separate Work, Intelligence, Music or Utilities destinations/data models. These were not fabricated as placeholder screens.
