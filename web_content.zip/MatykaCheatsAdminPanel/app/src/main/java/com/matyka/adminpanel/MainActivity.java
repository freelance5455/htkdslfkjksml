package com.matyka.adminpanel;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(23,13,18));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,13,16));
        WebView view = new WebView(this);
        view.setBackgroundColor(android.graphics.Color.rgb(16,13,16));
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        view.setWebViewClient(new WebViewClient());
        view.loadUrl("file:///android_asset/index.html");
        setContentView(view);
    }
    @Override public void onBackPressed() { super.onBackPressed(); }
}