MATYKA CHEATS ADMIN PANEL v4 — PROJETO ANDROID

Este ZIP contém o projeto-fonte Android Studio, não um APK já compilado.
Para gerar o APK:
1. Instale o Android Studio em um computador.
2. Abra a pasta MatykaCheatsAdminPanel no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação do Android SDK 35.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de depuração ficará em app/build/outputs/apk/debug/app-debug.apk.

O painel funciona localmente e não precisa de conta ou servidor. As Keys são demonstrativas:
não validam nem ativam nenhum aplicativo ou jogo externo. Os dados são guardados no armazenamento
local do WebView e podem ser apagados ao limpar os dados do aplicativo.
