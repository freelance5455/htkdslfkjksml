R K CONSULTANCY MOBILE V33.0 PRELOADED
=====================================

This ZIP contains the mobile web/PWA project based on the supplied Python V32.7 database snapshot and the discussed interface changes.

Navigation: Dashboard | Invoice | Task | Utility | Setting.
Dashboard links to FY-wise ITR, Other Services and GST.
Client lists display sequence number and name (GST also displays GSTIN), with View / Edit for details.
Search is available. Each ITR, Other Services and GST page has one Invoice button at the top and selection checkboxes. A single selected record opens the normal invoice flow; multiple selections ask for a Master Client / Party name and open the invoice form.
The ITR taxpayer picker in the invoice form is a searchable checkbox list, not a permanently open multi-select list. Invoice numbers are auto-suggested and duplicates are rejected.

SOURCE DATA SNAPSHOT
- Snapshot is embedded in preloaded-data.js and loaded on first launch.
- Source tables are retained in db.sourceData for reference.
- Supplied source database snapshot: 124 ITR clients, 127 ITR year records, 20 Other Services records, 2 financial-year entries in each FY table, and 0 GST clients / 0 tasks / 0 reminders / 0 documents at snapshot time.
- Passwords are only present where the source database had a saved value. No missing password is invented.
- Sensitive client information is included. Keep this ZIP private and use a backup before testing.

IMPORTANT LIMITATIONS
- This is a mobile web/PWA project, not a compiled Android APK.
- PDF utility menu is included, but conversion engines are NOT bundled; merge/OCR/Word/image/Excel conversions do not yet execute in this package.
- It is not a fully verified feature-for-feature clone of every Windows screen. Source tables are retained, but some source records need dedicated UI screens to be actionable.
- No cloud sync or Windows sync is configured. Data is stored locally in browser storage. Export backups regularly.
- Bank account details and genuine QR must be entered in Setting; no real QR is fabricated.

OPENING
Extract the ZIP and open index.html for a local preview. Browser restrictions may vary for local file access and printing. For phone installation, package the project with a trusted PWA/HTML wrapper.
