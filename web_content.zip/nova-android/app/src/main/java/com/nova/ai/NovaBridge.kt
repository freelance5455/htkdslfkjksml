package com.nova.ai

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.JavascriptInterface
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import android.content.ContentValues
import android.util.Base64
import java.io.File
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

/** JS ↔ Android bridge. JS এ NovaNative নামে পাওয়া যায়। */
class NovaBridge(private val act: MainActivity) {

    private val handler = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var wantOn = false
    private var live = false
    private var lang = "hi-IN"

    // ---------- helpers ----------
    fun js(code: String) {
        act.runOnUiThread { act.web.evaluateJavascript(code, null) }
    }

    private fun ui(block: () -> Unit) = act.runOnUiThread(block)

    private fun has(p: String) = act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String) = js("toast(" + JSONObject.quote(msg) + ")")

    private fun start(i: Intent): Boolean = try {
        act.startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    fun statusJson(): String {
        val o = JSONObject()
        o.put("mic", has(Manifest.permission.RECORD_AUDIO))
        o.put("cam", has(Manifest.permission.CAMERA))
        o.put("contacts", has(Manifest.permission.READ_CONTACTS))
        o.put("call", has(Manifest.permission.CALL_PHONE))
        o.put("loc", has(Manifest.permission.ACCESS_FINE_LOCATION))
        o.put(
            "notif",
            if (Build.VERSION.SDK_INT >= 33) has(Manifest.permission.POST_NOTIFICATIONS) else true
        )
        return o.toString()
    }

    fun shutdown() {
        wantOn = false
        stopRec()
        try {
            engine?.stop()
            engine?.shutdown()
        } catch (e: Exception) {
        }
        engine = null
        engineReady = false
    }

    // ---------- permissions ----------
    @JavascriptInterface
    fun isNative(): Boolean = true

    @JavascriptInterface
    fun status(): String = statusJson()

    @JavascriptInterface
    fun perms() {
        ui {
            val l = arrayListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
            act.requestPermissions(l.toTypedArray(), 1)
        }
    }

    @JavascriptInterface
    fun settings(panel: String) {
        ui {
            val pkg = Uri.parse("package:" + act.packageName)
            val i = when (panel.lowercase()) {
                "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
                "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
                "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                "overlay" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)
                "battery" -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                "app" -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
                else -> Intent(Settings.ACTION_SETTINGS)
            }
            if (!start(i)) toast("Settings খোলা গেল না")
        }
    }

    // ---------- voice recognition (WebView এ Web Speech নেই, তাই native) ----------
    @JavascriptInterface
    fun ear(cmd: String, l: String, lv: Boolean) {
        ui {
            if (cmd == "start") {
                wantOn = true
                live = lv
                if (l.isNotEmpty()) lang = l
                startRec()
            } else {
                wantOn = false
                stopRec()
            }
        }
    }

    private fun startRec() {
        if (!SpeechRecognizer.isRecognitionAvailable(act)) {
            js("window.__ear&&__ear('error','unavailable')")
            return
        }
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            js("window.__ear&&__ear('error','perm')")
            return
        }
        stopRec()
        val r = SpeechRecognizer.createSpeechRecognizer(act)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {
                js("window.__ear&&__ear('listening','')")
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(a: Int, b: Bundle?) {}

            override fun onError(e: Int) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    wantOn = false
                    js("window.__ear&&__ear('error','perm')")
                    return
                }
                if (live && wantOn) {
                    restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 350)
                } else {
                    js("window.__ear&&__ear('end','')")
                }
            }

            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotBlank()) js("window.__ear&&__ear('final'," + JSONObject.quote(t) + ")")
                if (live && wantOn) restart(250) else js("window.__ear&&__ear('end','')")
            }

            override fun onPartialResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotBlank()) js("window.__ear&&__ear('partial'," + JSONObject.quote(t) + ")")
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(i)
    }

    private fun restart(ms: Long) {
        handler.postDelayed({ if (wantOn) startRec() }, ms)
    }

    private fun stopRec() {
        sr?.let {
            try {
                it.cancel()
                it.destroy()
            } catch (e: Exception) {
            }
        }
        sr = null
    }

    // ---------- background service + floating orb ----------
    @JavascriptInterface
    fun svc(on: Boolean, overlay: Boolean, wake: Boolean, lang: String) {
        ui {
            val i = Intent(act, NovaService::class.java).putExtra("ovl", overlay).putExtra("wake", wake).putExtra("lang", lang)
            try {
                if (on) {
                    if (has(Manifest.permission.RECORD_AUDIO)) act.startForegroundService(i)
                } else {
                    act.stopService(i)
                }
            } catch (e: Exception) {
                toast("Background service চালু করা গেল না")
            }
        }
    }

    @JavascriptInterface
    fun toBack() {
        ui { act.moveTaskToBack(true) }
    }

    // ---------- phone control ----------
    private val known = mapOf(
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "chrome" to "com.android.chrome",
        "facebook" to "com.facebook.katana",
        "spotify" to "com.spotify.music",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "telegram" to "org.telegram.messenger"
    )

    @JavascriptInterface
    fun open(name: String): String {
        val n = name.lowercase().trim()
        var result = "notfound"
        ui {
            val pm = act.packageManager
            var intent: Intent? = known.entries.firstOrNull { n.contains(it.key) }
                ?.let { pm.getLaunchIntentForPackage(it.value) }
            if (intent == null) {
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                @Suppress("DEPRECATION")
                val m = pm.queryIntentActivities(q, 0)
                    .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
                intent = m?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            }
            if (intent == null) {
                intent = when {
                    n.contains("camera") || n.contains("ক্যামেরা") || n.contains("कैमरा") ->
                        Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    n.contains("setting") -> Intent(Settings.ACTION_SETTINGS)
                    n.contains("dial") || n.contains("phone") -> Intent(Intent.ACTION_DIAL)
                    else -> null
                }
            }
            if (intent != null && start(intent)) result = "ok" else toast("'$name' app পাওয়া গেল না")
        }
        return result
    }

    private fun resolveNumber(q: String): String? {
        if (q.count { it.isDigit() } >= 5) return q.filter { it.isDigit() || it == '+' }
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val c = act.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$q%"), null
        )
        c?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    @JavascriptInterface
    fun call(target: String) {
        ui {
            val num = resolveNumber(target)
            if (num == null) {
                toast("'$target' এর number পাওয়া গেল না (Contacts permission দিয়েছ?)")
                return@ui
            }
            val uri = Uri.parse("tel:" + Uri.encode(num))
            val i = if (has(Manifest.permission.CALL_PHONE)) Intent(Intent.ACTION_CALL, uri)
            else Intent(Intent.ACTION_DIAL, uri)
            start(i)
        }
    }

    @JavascriptInterface
    fun sms(target: String, body: String) {
        ui {
            val num = resolveNumber(target)
            if (num == null) {
                toast("'$target' এর number নেই")
                return@ui
            }
            start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))).putExtra("sms_body", body))
        }
    }

    @JavascriptInterface
    fun whatsapp(target: String, text: String) {
        ui {
            val num = resolveNumber(target)?.filter { it.isDigit() }
            if (num == null) {
                toast("'$target' এর number নেই")
                return@ui
            }
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=" + Uri.encode(text))))
        }
    }

    @JavascriptInterface
    fun torch(on: Boolean) {
        ui {
            try {
                val cm = act.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                if (id != null) cm.setTorchMode(id, on) else toast("Flash নেই")
            } catch (e: Exception) {
                toast("Torch চালানো গেল না")
            }
        }
    }

    @JavascriptInterface
    fun volume(arg: String) {
        ui {
            val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val st = AudioManager.STREAM_MUSIC
            val max = am.getStreamMaxVolume(st)
            when {
                arg == "up" -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                arg == "down" -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                arg == "mute" -> am.setStreamVolume(st, 0, AudioManager.FLAG_SHOW_UI)
                arg.toIntOrNull() != null ->
                    am.setStreamVolume(st, (arg.toInt().coerceIn(0, 100) * max / 100), AudioManager.FLAG_SHOW_UI)
            }
        }
    }

    @JavascriptInterface
    fun alarm(h: Int, m: Int, label: String) {
        ui {
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            if (!start(i)) toast("Alarm app পাওয়া গেল না")
        }
    }

    @JavascriptInterface
    fun timer(seconds: Int, label: String) {
        ui {
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            if (!start(i)) toast("Timer app পাওয়া গেল না")
        }
    }

    @JavascriptInterface
    fun maps(q: String) {
        ui { start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q)))) }
    }

    @JavascriptInterface
    fun music(q: String) {
        ui {
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .putExtra(android.app.SearchManager.QUERY, q)
            if (!start(i)) {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("https://m.youtube.com/results?search_query=" + Uri.encode(q))))
            }
        }
    }

    @JavascriptInterface
    fun web(url: String) {
        ui { start(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    @JavascriptInterface
    fun media(cmd: String) {
        ui {
            val code = when (cmd) {
                "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
                else -> KeyEvent.KEYCODE_MEDIA_PAUSE
            }
            val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
    }

    @JavascriptInterface
    fun battery(): String {
        val bm = act.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).toString()
    }

    @JavascriptInterface
    fun share(text: String) {
        ui {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            start(Intent.createChooser(i, "Share"))
        }
    }

    @JavascriptInterface
    fun copy(text: String) {
        ui {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("nova", text))
        }
    }

    // ---------- Google sign-in (native, returns an ID token to JS) ----------
    @JavascriptInterface
    fun googleSignIn(clientId: String) {
        ui {
            try {
                val cm = CredentialManager.create(act)
                val opt = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(clientId)
                    .setAutoSelectEnabled(false)
                    .build()
                val req = GetCredentialRequest.Builder().addCredentialOption(opt).build()
                cm.getCredentialAsync(act, req, null, ContextCompat.getMainExecutor(act),
                    object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                        override fun onResult(result: GetCredentialResponse) {
                            val c = result.credential
                            if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                val t = GoogleIdTokenCredential.createFrom(c.data).idToken
                                js("window.__gid&&__gid(" + JSONObject.quote(t) + ",'')")
                            } else {
                                js("window.__gid&&__gid('','unexpected credential type')")
                            }
                        }

                        override fun onError(e: GetCredentialException) {
                            js("window.__gid&&__gid(''," + JSONObject.quote(e.type + ": " + (e.message ?: "")) + ")")
                        }
                    })
            } catch (e: Exception) {
                js("window.__gid&&__gid(''," + JSONObject.quote(e.toString()) + ")")
            }
        }
    }

    // ---------- save a generated file into Downloads ----------
    @JavascriptInterface
    fun saveFile(name: String, b64: String, mime: String): Boolean {
        return try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Downloads.DISPLAY_NAME, name)
                v.put(MediaStore.Downloads.MIME_TYPE, mime)
                v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/NOVA")
                val u = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return false
                act.contentResolver.openOutputStream(u)?.use { it.write(bytes) }
            } else {
                val d = act.getExternalFilesDir(null) ?: return false
                File(d, name).writeBytes(bytes)
            }
            toast("Saved: Download/NOVA/" + name)
            true
        } catch (e: Exception) {
            toast("Save failed: " + (e.message ?: ""))
            false
        }
    }

    // ---------- device voice (always-works fallback) ----------
    private var engine: TextToSpeech? = null
    private var engineReady = false
    private var voiceName: String? = null
    private val pending = ArrayList<() -> Unit>()

    private fun withEngine(block: () -> Unit) {
        if (engineReady) {
            block()
            return
        }
        pending.add(block)
        if (engine != null) return
        engine = TextToSpeech(act) { st ->
            if (st == TextToSpeech.SUCCESS) {
                engineReady = true
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) {
                        js("window.__ttsEnd&&__ttsEnd('')")
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        js("window.__ttsEnd&&__ttsEnd('error')")
                    }
                })
                val run = ArrayList(pending)
                pending.clear()
                run.forEach { it() }
            } else {
                pending.clear()
                engine = null
                js("window.__ttsEnd&&__ttsEnd('engine init failed')")
            }
        }
    }

    @JavascriptInterface
    fun tts(text: String, l: String, pitch: Float, rate: Float) {
        ui {
            withEngine {
                val t = engine
                if (t != null) {
                    val res = t.setLanguage(Locale.forLanguageTag(l))
                    if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                        js("window.__ttsEnd&&__ttsEnd('language not installed')")
                    } else {
                        val n = voiceName
                        if (n != null) {
                            val v = t.voices?.firstOrNull { it.name == n }
                            if (v != null) t.voice = v
                        }
                        t.setPitch(pitch)
                        t.setSpeechRate(rate)
                        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova")
                    }
                }
            }
        }
    }

    @JavascriptInterface
    fun ttsVoices(l: String): String {
        ui { withEngine { } }
        val arr = org.json.JSONArray()
        try {
            val lang = Locale.forLanguageTag(l).language
            engine?.voices?.filter { it.locale.language == lang }
                ?.sortedByDescending { it.quality }
                ?.forEach { arr.put(it.name) }
        } catch (e: Exception) {
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun ttsVoice(name: String) {
        voiceName = if (name.isEmpty()) null else name
    }

    @JavascriptInterface
    fun ttsStop() {
        ui { engine?.stop() }
    }

    // ---------- more phone actions ----------
    @JavascriptInterface
    fun email(to: String, subject: String, body: String) {
        ui {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                .putExtra(Intent.EXTRA_EMAIL, if (to.contains("@")) arrayOf(to) else arrayOf<String>())
                .putExtra(Intent.EXTRA_SUBJECT, subject)
                .putExtra(Intent.EXTRA_TEXT, body)
            if (!start(i)) toast("No email app found")
        }
    }

    @JavascriptInterface
    fun event(title: String, startTime: String, durMin: Int) {
        ui {
            val parsed: Long? = try {
                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(startTime.trim())?.time
            } catch (e: Exception) {
                null
            }
            val ms: Long = parsed ?: (System.currentTimeMillis() + 3600_000L)
            val i = Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, ms)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, ms + durMin * 60_000L)
            if (!start(i)) toast("No calendar app found")
        }
    }

    @JavascriptInterface
    fun navigate(q: String) {
        ui {
            if (!start(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q))))) {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))
            }
        }
    }

    @JavascriptInterface
    fun keepScreen(on: Boolean) {
        ui {
            if (on) act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
}
