package com.nova.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.sin

/**
 * Foreground service: call/hands-free চলার সময় process কে জীবিত রাখে
 * আর অন্য app এর উপর ছোট গোল floating orb দেখায়। Orb এ ট্যাপ = NOVA খোলে ও call শুরু।
 */
class NovaService : Service() {

    private var wm: WindowManager? = null
    private var orb: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val n = buildNotif()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.getBooleanExtra("ovl", false) == true) showOrb() else hideOrb()
        return START_STICKY
    }

    override fun onDestroy() {
        hideOrb()
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("nova", "NOVA background", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotif(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, "nova")
            .setContentTitle("NOVA চালু আছে")
            .setContentText("Call / Hands-free সক্রিয়")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun showOrb() {
        if (orb != null || !Settings.canDrawOverlays(this)) return
        val d = resources.displayMetrics.density
        val size = (64 * d).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (12 * d).toInt()
        lp.y = (220 * d).toInt()

        val v = OrbView(this)
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = ox + dx.toInt()
                    lp.y = oy + dy.toInt()
                    try { wm?.updateViewLayout(v, lp) } catch (ex: Exception) { }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    startActivity(
                        Intent(this, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            .putExtra("listen", true)
                    )
                }
            }
            true
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try {
            wm?.addView(v, lp)
            orb = v
        } catch (e: Exception) {
        }
    }

    private fun hideOrb() {
        orb?.let {
            try { wm?.removeView(it) } catch (e: Exception) { }
        }
        orb = null
    }

    private class OrbView(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            color = Color.parseColor("#FF4DA6")
        }

        override fun onDraw(c: Canvas) {
            val t = System.currentTimeMillis() / 500.0
            val pulse = (1.0 + 0.06 * sin(t)).toFloat()
            val cx = width / 2f
            val cy = height / 2f
            val r = width / 2f * 0.82f * pulse
            p.shader = RadialGradient(
                cx, cy * 0.9f, r,
                intArrayOf(Color.parseColor("#FFB3D9"), Color.parseColor("#8A6BFF"), Color.parseColor("#090C1A")),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(cx, cy, r, p)
            c.drawCircle(cx, cy, r, ring)
            postInvalidateOnAnimation()
        }
    }
}
