# NOVA AI: Android প্রজেক্ট

`app/src/main/assets/index.html` হলো পুরো NOVA UI/AI। বাকি Kotlin কোড সেটাকে Android এর সাথে জুড়ে দেয় (phone control, background call, floating orb)।

## ফোন থেকে APK বানানো (Termux + GitHub)

1. https://github.com এ account খুলে একটা **private** repo বানাও (নাম: nova)।
2. Settings → Developer settings → Personal access tokens → একটা token বানাও (repo permission)।
3. Termux এ (ফোল্ডারের ভেতরে এসে):
```
pkg install git -y
git init && git branch -M main
git add . && git commit -m "NOVA"
git remote add origin https://github.com/ইউজারনেম/nova.git
git push -u origin main
```
(password চাইলে token বসাও)
4. GitHub repo → **Actions** → "Build NOVA APK" → Run workflow।
5. ৫-১০ মিনিট পর run এর নিচে **nova-debug-apk** artifact ডাউনলোড করে install করো।
6. Build fail করলে Actions এর লাল step এর error লেখা কপি করে আমাকে দাও।

## Play Store এর জন্য (পরে)
- Release signing keystore বানাতে হবে (হারালে app update করা যাবে না!)।
- `gradle :app:bundleRelease` দিয়ে .aab বানাতে হবে।
- Play Console এ targetSdk এর সর্বশেষ নিয়ম, Privacy Policy, আর sensitive permission declaration (Mic, Overlay, Foreground service, Call) লাগবে।

## API key
Key গুলো কোডে নেই। অ্যাপ খুলে Setup wizard এ বসাও।
