package com.example.kalkulyator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import javax.script.ScriptEngineManager

class MainActivity : Activity() {
    private lateinit var display: TextView
    private var expression = ""
    private var justCalculated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 20, 29)
        window.navigationBarColor = Color.rgb(18, 20, 29)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 28, 18, 18)
            setBackgroundColor(Color.rgb(18, 20, 29))
        }
        display = TextView(this).apply {
            text = "0"
            textSize = 42f
            setTextColor(Color.WHITE)
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(8, 20, 8, 20)
            maxLines = 2
        }
        page.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))

        val keys = arrayOf(
            arrayOf("AC", "⌫", "%", "÷"),
            arrayOf("7", "8", "9", "×"),
            arrayOf("4", "5", "6", "−"),
            arrayOf("1", "2", "3", "+"),
            arrayOf("±", "0", ".", "=")
        )
        val grid = GridLayout(this).apply {
            columnCount = 4
            rowCount = 5
            useDefaultMargins = true
        }
        keys.forEach { row ->
            row.forEach { key ->
                val b = Button(this).apply {
                    text = key
                    textSize = 23f
                    isAllCaps = false
                    setTextColor(Color.WHITE)
                    setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        when (key) {
                            "=" -> Color.rgb(35, 150, 120)
                            "÷", "×", "−", "+", "%" -> Color.rgb(63, 91, 145)
                            "AC", "⌫", "±" -> Color.rgb(75, 79, 94)
                            else -> Color.rgb(39, 43, 57)
                        }
                    ))
                    setOnClickListener { press(key) }
                }
                val lp = GridLayout.LayoutParams().apply {
                    width = 0
                    height = 76
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(4, 4, 4, 4)
                }
                grid.addView(b, lp)
            }
        }
        page.addView(grid, LinearLayout.LayoutParams(-1, -2))
        setContentView(page)
    }

    private fun press(key: String) {
        when (key) {
            "AC" -> { expression = ""; justCalculated = false }
            "⌫" -> { expression = expression.dropLast(1); justCalculated = false }
            "=" -> {
                try {
                    val result = evaluate(expression)
                    expression = BigDecimal(result).stripTrailingZeros().toPlainString()
                    justCalculated = true
                } catch (_: Exception) {
                    display.text = "Ошибка"
                    expression = ""
                    return
                }
            }
            "±" -> {
                if (expression.isNotEmpty()) {
                    expression = if (expression.startsWith("-")) expression.drop(1) else "-$expression"
                }
            }
            else -> {
                if (justCalculated && key.firstOrNull()?.isDigit() == true) expression = ""
                justCalculated = false
                expression += when (key) { "×" -> "*"; "÷" -> "/"; "−" -> "-"; else -> key }
            }
        }
        display.text = expression.replace("*", "×").replace("/", "÷").replace("-", "−").ifEmpty { "0" }
    }

    private fun evaluate(input: String): Double {
        if (input.isBlank()) return 0.0
        val normalized = input.replace("%", "/100")
        val engine = ScriptEngineManager().getEngineByName("rhino")
            ?: ScriptEngineManager().getEngineByName("javascript")
            ?: throw IllegalArgumentException("Нет вычислителя")
        val value = engine.eval(normalized).toString().toDouble()
        if (!value.isFinite()) throw ArithmeticException()
        return value
    }
}
