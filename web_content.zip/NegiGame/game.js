import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const container = document.getElementById('game-container');

// 1. Cena e Renderizador PS1
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1a232a);
scene.fog = new THREE.FogExp2(0x1a232a, 0.015);

const camera = new THREE.PerspectiveCamera(55, container.clientWidth / container.clientHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: false }); // Antialias desligado para preservar estética PS1
renderer.setPixelRatio(1);
renderer.setSize(container.clientWidth, container.clientHeight);
container.appendChild(renderer.domElement);

// Redimensionamento dinâmico para telas mobile / rotações
window.addEventListener('resize', () => {
    const width = container.clientWidth;
    const height = container.clientHeight;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
});

// Grupos das Seções
const section1Group = new THREE.Group();
const section2Group = new THREE.Group();
const section3Group = new THREE.Group();
scene.add(section1Group);
scene.add(section2Group);
scene.add(section3Group);

section2Group.visible = false;
section3Group.visible = false;

// Luzes
const ambientLight = new THREE.AmbientLight(0xddeeff, 0.6);
scene.add(ambientLight);

const sunLight = new THREE.DirectionalLight(0xffeedd, 0.7);
sunLight.position.set(20, 40, 20);
scene.add(sunLight);

// Lanterna do Jogador
const flashlight = new THREE.SpotLight(0xffffff, 25, 35, Math.PI / 4, 0.5, 1);
flashlight.visible = false;
scene.add(flashlight);
scene.add(flashlight.target);

// Helper de Setas 3D PS1
function createArrowMesh(scale = 1) {
    const mesh = new THREE.Mesh(
        new THREE.ConeGeometry(0.4 * scale, 1.0 * scale, 4),
        new THREE.MeshStandardMaterial({ color: 0xffcc00, emissive: 0xffaa00, flatShading: true })
    );
    mesh.rotation.x = Math.PI;
    return mesh;
}

// Setas de Objetivo
const npcArrow = createArrowMesh();
section2Group.add(npcArrow);

const windowArrow = createArrowMesh(0.8);
windowArrow.position.set(0, 2.5, -3.2);
section3Group.add(windowArrow);

const exitGateArrow = createArrowMesh(1.5);
section2Group.add(exitGateArrow);

// Sistema de Colisões
let currentColliders = [];
let section1Colliders = [];
let section2Colliders = [];
let section3Colliders = [];

function addBox(colliders, x, y, z, w, h, d) {
    const box = new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(x, y, z), new THREE.Vector3(w, h, d));
    colliders.push(box);
}

// ==========================================
// SEÇÃO 1: ESTRADA E MONTANHAS
// ==========================================
const baseGround1 = new THREE.Mesh(
    new THREE.PlaneGeometry(100, 100),
    new THREE.MeshStandardMaterial({ color: 0x22381b, roughness: 0.9, flatShading: true })
);
baseGround1.rotation.x = -Math.PI / 2;
section1Group.add(baseGround1);

const road = new THREE.Mesh(
    new THREE.BoxGeometry(40, 0.1, 5),
    new THREE.MeshStandardMaterial({ color: 0x3d3d3d, roughness: 0.8, flatShading: true })
);
road.position.set(12, 0.05, 0);
section1Group.add(road);

addBox(section1Colliders, 12, 5, -5, 60, 10, 4); 
addBox(section1Colliders, 12, 5, 5, 60, 10, 4);  

for (let i = -10; i <= 35; i += 8) {
    const hill = new THREE.Mesh(
        new THREE.ConeGeometry(7, 6, 5),
        new THREE.MeshStandardMaterial({ color: 0x1c2b17, flatShading: true })
    );
    hill.position.set(i, 3, -8);
    section1Group.add(hill);
}

for (let x = -2; x <= 24; x += 2.5) {
    const fencePost = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.4, 0.2), new THREE.MeshStandardMaterial({ color: 0x4a321a }));
    fencePost.position.set(x, 0.7, 2.8);
    section1Group.add(fencePost);
}

const stonePath = new THREE.Mesh(
    new THREE.BoxGeometry(6, 0.1, 22),
    new THREE.MeshStandardMaterial({ color: 0x555555, roughness: 0.9, flatShading: true })
);
stonePath.position.set(25, 0.05, -12);
section1Group.add(stonePath);


// ==========================================
// SEÇÃO 2: VILA & FUGA
// ==========================================
const villageFloor = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), new THREE.MeshStandardMaterial({ color: 0x1b2b17, flatShading: true }));
villageFloor.rotation.x = -Math.PI / 2;
villageFloor.position.set(50, 0, -40);
section2Group.add(villageFloor);

// Portão de Fuga
const exitGatePos = new THREE.Vector3(85, 0, -55);
const gateMesh = new THREE.Mesh(
    new THREE.BoxGeometry(6, 3.5, 0.4),
    new THREE.MeshStandardMaterial({ color: 0x664422, flatShading: true })
);
gateMesh.position.set(exitGatePos.x, 1.75, exitGatePos.z);
section2Group.add(gateMesh);

// Limites da Vila
addBox(section2Colliders, 50, 2, -100, 120, 10, 2);
addBox(section2Colliders, 50, 2, 20, 120, 10, 2);
addBox(section2Colliders, -10, 2, -40, 2, 10, 120);
addBox(section2Colliders, 110, 2, -40, 2, 10, 120);

const houses = [];
function createHouse(x, z, isGuestHouse) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);

    const houseMesh = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 8), new THREE.MeshStandardMaterial({ color: 0x5a3d23, flatShading: true }));
    houseMesh.position.y = 2; group.add(houseMesh);

    const roof = new THREE.Mesh(new THREE.ConeGeometry(6.5, 2.5, 4), new THREE.MeshStandardMaterial({ color: 0x38190c, flatShading: true }));
    roof.position.y = 5.25; roof.rotation.y = Math.PI / 4; group.add(roof);

    const door = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.8, 0.2), new THREE.MeshStandardMaterial({ color: 0x241105 }));
    door.position.set(0, 1.4, 4.05); group.add(door);

    section2Group.add(group);
    addBox(section2Colliders, x, 2, z, 8.2, 4, 8.2);

    houses.push({ x, z, doorPos: new THREE.Vector3(x, 0, z + 4.5), isGuestHouse });
}

createHouse(45, -25, false);
createHouse(65, -25, false);
createHouse(55, -45, true); // Casa 3

// Garota (NPC)
const girlNPCGroup = new THREE.Group();
const girlBody = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 1.2), new THREE.MeshStandardMaterial({ color: 0xcc3333, flatShading: true }));
girlBody.position.y = 0.6;
const girlHead = new THREE.Mesh(new THREE.SphereGeometry(0.3), new THREE.MeshStandardMaterial({ color: 0xffccaa, flatShading: true }));
girlHead.position.y = 1.3;
girlNPCGroup.add(girlBody, girlHead);
girlNPCGroup.position.set(38, 0, -20);
section2Group.add(girlNPCGroup);

// Monstro Perseguidor PS1
const enemyGroup = new THREE.Group();
const enemyBody = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.5, 2.0, 6), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.2, flatShading: true }));
enemyBody.position.y = 1.0;
const enemyEyes = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.15, 0.2), new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0xff0000 }));
enemyEyes.position.set(0, 1.6, 0.3);
enemyGroup.add(enemyBody, enemyEyes);
enemyGroup.position.set(30, 0, -15);
enemyGroup.visible = false;
section2Group.add(enemyGroup);

// Amuletos
const amulets = [
    { pos: new THREE.Vector3(38, 0.5, -20), collected: false, mesh: null, arrow: null },
    { pos: new THREE.Vector3(68, 0.5, -40), collected: false, mesh: null, arrow: null },
    { pos: new THREE.Vector3(48, 0.5, -55), collected: false, mesh: null, arrow: null }
];

amulets.forEach(a => {
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.35), new THREE.MeshStandardMaterial({ color: 0x00ffff, emissive: 0x00aaaa, flatShading: true }));
    gem.position.copy(a.pos);
    section2Group.add(gem);
    a.mesh = gem;

    const arrow = createArrowMesh(0.7);
    arrow.position.set(a.pos.x, a.pos.y + 1.8, a.pos.z);
    arrow.visible = false;
    section2Group.add(arrow);
    a.arrow = arrow;
});

// ==========================================
// SEÇÃO 3: INTERIOR DO QUARTO
// ==========================================
const roomFloor = new THREE.Mesh(new THREE.PlaneGeometry(8, 8), new THREE.MeshStandardMaterial({ color: 0x3d2715, flatShading: true }));
roomFloor.rotation.x = -Math.PI / 2;
section3Group.add(roomFloor);

const intWallMat = new THREE.MeshStandardMaterial({ color: 0x593e25, flatShading: true });
const wB = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 0.3), intWallMat); wB.position.set(0, 2, -4); section3Group.add(wB);
const wF = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 0.3), intWallMat); wF.position.set(0, 2, 4); section3Group.add(wF);
const wL = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4, 8), intWallMat); wL.position.set(-4, 2, 0); section3Group.add(wL);
const wR = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4, 8), intWallMat); wR.position.set(4, 2, 0); section3Group.add(wR);

// Cama no quarto
const bedGroup = new THREE.Group();
const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.5, 3.2), new THREE.MeshStandardMaterial({ color: 0x4a2a12, flatShading: true }));
bedFrame.position.y = 0.25;
const mattress = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.4, 3.0), new THREE.MeshStandardMaterial({ color: 0xeeeeee, flatShading: true }));
mattress.position.y = 0.6;
const pillow = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.2, 0.8), new THREE.MeshStandardMaterial({ color: 0xcc3333, flatShading: true }));
pillow.position.set(0, 0.8, -1.0);

bedGroup.add(bedFrame, mattress, pillow);
bedGroup.position.set(-2.5, 0, 1.5);
section3Group.add(bedGroup);
addBox(section3Colliders, -2.5, 0.5, 1.5, 2.4, 1.0, 3.4);

// Janela
const windowGlass = new THREE.Mesh(new THREE.BoxGeometry(2, 2, 0.05), new THREE.MeshStandardMaterial({ color: 0x4477aa, emissive: 0x112233 }));
windowGlass.position.set(0, 2, -3.8);
section3Group.add(windowGlass);

addBox(section3Colliders, 0, 2, -4, 8, 4, 0.6);
addBox(section3Colliders, 0, 2, 4, 8, 4, 0.6);
addBox(section3Colliders, -4, 2, 0, 0.6, 4, 8);
addBox(section3Colliders, 4, 2, 0, 0.6, 4, 8);

// ==========================================
// JOGADOR & FLUXO DE JOGO
// ==========================================
let negiPlayer = null;
const loader = new GLTFLoader();
loader.load('character.glb', (gltf) => {
    negiPlayer = gltf.scene;
    negiPlayer.position.set(0, 0, 0);
    negiPlayer.scale.set(2.5, 2.5, 2.5);
    scene.add(negiPlayer);
}, undefined, () => {
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.8, 0.6), new THREE.MeshStandardMaterial({ color: 0x0088ff, flatShading: true }));
    body.position.y = 0.9; group.add(body);
    negiPlayer = group; negiPlayer.position.set(0, 0, 0);
    scene.add(negiPlayer);
});

let gameState = "MENU";
let currentSection = 1;
currentColliders = section1Colliders;
let firstPersonYaw = Math.PI;

const ui = document.getElementById('ui');
const speaker = document.getElementById('speaker');
const dialogText = document.getElementById('dialog-text');
const nextBtn = document.getElementById('next-btn');

function showDialog(who, text) {
    ui.style.display = 'block';
    speaker.innerText = who + ":";
    dialogText.innerText = text;
}

function loadSection(sectionNum) {
    section1Group.visible = (sectionNum === 1);
    section2Group.visible = (sectionNum === 2);
    section3Group.visible = (sectionNum === 3);
    currentSection = sectionNum;

    if (sectionNum === 1) currentColliders = section1Colliders;
    if (sectionNum === 2) currentColliders = section2Colliders;
    if (sectionNum === 3) currentColliders = section3Colliders;
}

// LÓGICA DAS CONFIGURAÇÕES GRÁFICAS PS1
function applyGraphicsSettings(quality) {
    if (quality === 'low') {
        renderer.shadowMap.enabled = false;
        renderer.setPixelRatio(0.65); // Pixelado raiz estilo PS1
        scene.fog.density = 0.025;
    } else if (quality === 'medium') {
        renderer.shadowMap.enabled = false;
        renderer.setPixelRatio(1.0);
        scene.fog.density = 0.015;
    } else if (quality === 'high') {
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
        scene.fog.density = 0.010;
        sunLight.castShadow = true;
        flashlight.castShadow = true;
    }
}

// BOTÃO START MENU
document.getElementById('start-game-btn').onclick = function() {
    const quality = document.getElementById('graphics-select').value;
    applyGraphicsSettings(quality);
    document.getElementById('main-menu').style.display = 'none';
    gameState = "SECTION_1_2D";
};

// AVANÇAR DIÁLOGOS
nextBtn.onclick = function(e) {
    e.preventDefault();
    ui.style.display = 'none';

    if (gameState === "TALK_ROAD") {
        gameState = "DESCENDING";
    } else if (gameState === "TALK_GIRL") {
        gameState = "EXPLORE_VILLAGE";
    } else if (gameState === "LOOK_WINDOW_DIALOG") {
        loadSection(2);

        if (negiPlayer) {
            negiPlayer.visible = true;
            negiPlayer.position.set(55, 0, -35);
            negiPlayer.rotation.y = 0;
        }

        gameState = "NIGHT_ESCAPE";

        scene.background = new THREE.Color(0x0a0f1d);
        scene.fog = new THREE.FogExp2(0x0a0f1d, 0.02);
        ambientLight.color = new THREE.Color(0x445577);
        ambientLight.intensity = 0.5;
        flashlight.visible = true;

        girlNPCGroup.visible = false;
        npcArrow.visible = false;
        
        enemyGroup.visible = true;
        enemyGroup.position.set(30, 0, -15);

        amulets.forEach(a => { if(!a.collected) a.arrow.visible = true; });
        exitGateArrow.visible = true;

        const inv = document.getElementById('inventory');
        if (inv) inv.style.display = 'block';

        const title = document.getElementById('chapter-title');
        if (title) title.innerText = "CAPITULO 2: A FUGA";

        camTarget.set(49, 8, -27);
        camLook.set(55, 1, -35);
        camera.position.copy(camTarget);
        camera.lookAt(camLook);
    }
};

// Controles do Joystick
const joystickZone = document.getElementById('joystick-zone');
const joystickKnob = document.getElementById('joystick-knob');
let joystickInput = { x: 0, y: 0 };
let joystickActive = false;

function handleJoystick(evt) {
    if (!joystickActive) return;
    const touch = evt.touches ? evt.touches[0] : evt;
    const rect = joystickZone.getBoundingClientRect();
    let dx = touch.clientX - (rect.left + rect.width / 2);
    let dy = touch.clientY - (rect.top + rect.height / 2);
    const dist = Math.hypot(dx, dy);
    const maxR = 35;
    if (dist > maxR) { dx = (dx / dist) * maxR; dy = (dy / dist) * maxR; }
    joystickKnob.style.transform = `translate(${dx}px, ${dy}px)`;
    joystickInput = dist < 5 ? { x: 0, y: 0 } : { x: dx / maxR, y: dy / maxR };
}

joystickZone.addEventListener('pointerdown', (e) => { joystickActive = true; handleJoystick(e); });
window.addEventListener('pointermove', handleJoystick);
window.addEventListener('pointerup', () => { joystickActive = false; joystickKnob.style.transform = 'translate(0,0)'; joystickInput = { x: 0, y: 0 }; });

document.getElementById('action-btn').addEventListener('click', () => {
    if (!negiPlayer) return;

    if (currentSection === 2 && gameState === "EXPLORE_VILLAGE") {
        if (negiPlayer.position.distanceTo(girlNPCGroup.position) < 3.5) {
            gameState = "TALK_GIRL";
            showDialog("Garota", "Podes descansar no casarão do fundo (Casa 3). Vai lá!");
            return;
        }

        const guestHouse = houses.find(h => h.isGuestHouse);
        if (negiPlayer.position.distanceTo(guestHouse.doorPos) < 3.5) {
            loadSection(3);
            negiPlayer.position.set(0, 0, 2);
            firstPersonYaw = Math.PI;
            if (negiPlayer) negiPlayer.visible = false;

            gameState = "INSIDE_HOUSE";
            showDialog("Negi", "Entrei no quarto. Que barulho estranho é esse lá fora? Vou olhar pela janela!");
            return;
        }
    }

    if (currentSection === 3 && gameState === "INSIDE_HOUSE") {
        if (negiPlayer.position.distanceTo(new THREE.Vector3(0, 0, -3.5)) < 3.0) {
            gameState = "LOOK_WINDOW_DIALOG";
            showDialog("Negi", "O QUE?! Estao fazendo um ritual! A garota me viu! PRECISO FUGIR E ACHAR OS AMULETOS!");
            return;
        }
    }
});

function canMoveTo(newPos) {
    const pBox = new THREE.Box3().setFromCenterAndSize(newPos, new THREE.Vector3(0.7, 1.8, 0.7));
    for (let box of currentColliders) {
        if (box.intersectsBox(pBox)) return false;
    }
    return true;
}

// TELA DE GAME OVER ESTILO PS1
function triggerGameOver() {
    gameState = "GAME_OVER";
    if (document.getElementById('game-over-screen')) return;

    const gameOverOverlay = document.createElement('div');
    gameOverOverlay.id = 'game-over-screen';
    gameOverOverlay.style.cssText = `
        position: absolute; top: 0; left: 0; width: 100%; height: 100%;
        background: radial-gradient(circle, #330000 0%, #050000 95%);
        display: flex; flex-direction: column; justify-content: center; align-items: center;
        z-index: 9999; color: white; font-family: 'Press Start 2P', monospace; text-align: center;
    `;
    gameOverOverlay.innerHTML = `
        <div class="ps1-border" style="border-color: #ff0000; box-shadow: inset 0 0 20px #ff0000;">
            <h1 style="color: #ff0000; font-size: 1.5rem; text-shadow: 4px 4px 0px #550000; margin-bottom: 20px;">VOCE MORREU</h1>
            <p style="color: #aaa; font-size: 0.55rem; line-height: 1.6; margin-bottom: 30px;">O RITUAL FOI CONCLUIDO E SUA ALMA FOI PRESA NA VILA.</p>
            <button id="restart-btn" class="ps1-btn">CONTINUAR</button>
        </div>
    `;
    container.appendChild(gameOverOverlay);
    document.getElementById('restart-btn').onclick = () => location.reload();
}

// TELA DE VITÓRIA ESTILO PS1
function triggerVictory() {
    gameState = "VICTORY";
    if (document.getElementById('victory-screen')) return;

    const winOverlay = document.createElement('div');
    winOverlay.id = 'victory-screen';
    winOverlay.style.cssText = `
        position: absolute; top: 0; left: 0; width: 100%; height: 100%;
        background: radial-gradient(circle, #002200 0%, #000500 95%);
        display: flex; flex-direction: column; justify-content: center; align-items: center;
        z-index: 9999; color: white; font-family: 'Press Start 2P', monospace; text-align: center;
    `;
    winOverlay.innerHTML = `
        <div class="ps1-border" style="border-color: #00ff00; box-shadow: inset 0 0 20px #00ff00;">
            <h1 style="color: #00ff00; font-size: 1.3rem; text-shadow: 4px 4px 0px #005500; margin-bottom: 20px;">VOCE ESCAPOU!</h1>
            <p style="color: #aaa; font-size: 0.55rem; line-height: 1.6; margin-bottom: 30px;">NEGI CONSEGUIU QUEBRAR O SELLO E ESCAPAR COM VIDA.</p>
            <button id="win-restart-btn" class="ps1-btn" style="background: #008800; border-color: #00ff00;">MENU PRINCIPAL</button>
        </div>
    `;
    container.appendChild(winOverlay);
    document.getElementById('win-restart-btn').onclick = () => location.reload();
}

// LOOP PRINCIPAL
let camTarget = new THREE.Vector3();
let camLook = new THREE.Vector3();

function animate() {
    requestAnimationFrame(animate);
    const time = Date.now() * 0.005;

    if (negiPlayer && gameState !== "GAME_OVER" && gameState !== "VICTORY" && gameState !== "MENU") {

        // --- SEÇÃO 1 ---
        if (gameState === "SECTION_1_2D") {
            if (Math.abs(joystickInput.x) > 0.1) {
                const nextX = negiPlayer.position.x + joystickInput.x * 0.14;
                if (canMoveTo(new THREE.Vector3(nextX, 0, 0))) {
                    negiPlayer.position.x = nextX;
                    negiPlayer.rotation.y = joystickInput.x > 0 ? Math.PI / 2 : -Math.PI / 2;
                }
            }
            camTarget.set(negiPlayer.position.x, 3, 10);
            camLook.set(negiPlayer.position.x, 1.5, 0);

            if (negiPlayer.position.x >= 24) {
                gameState = "TALK_ROAD";
                showDialog("Negi", "A estrada principal esta bloqueada... vou ter que descer por esse caminho de pedras!");
            }
        }
        else if (gameState === "DESCENDING") {
            negiPlayer.position.z -= 0.12;
            negiPlayer.rotation.y = Math.PI;
            if (negiPlayer.position.z <= -10) {
                loadSection(2);
                negiPlayer.position.set(30, 0, -15);
                gameState = "EXPLORE_VILLAGE";
            }
        }

        // --- SEÇÃO 2 (VILA & FUGA) ---
        else if ((gameState === "EXPLORE_VILLAGE" || gameState === "NIGHT_ESCAPE") && currentSection === 2) {
            if (Math.abs(joystickInput.x) > 0.05 || Math.abs(joystickInput.y) > 0.05) {
                const angle = -Math.PI / 4;
                const mx = joystickInput.x * Math.cos(angle) - joystickInput.y * Math.sin(angle);
                const mz = joystickInput.x * Math.sin(angle) + joystickInput.y * Math.cos(angle);

                const nextPos = negiPlayer.position.clone().add(new THREE.Vector3(mx * 0.14, 0, mz * 0.14));

                if (canMoveTo(nextPos)) {
                    negiPlayer.position.copy(nextPos);
                    negiPlayer.rotation.y = Math.atan2(mx, mz);
                }
            }

            if (gameState === "EXPLORE_VILLAGE") {
                npcArrow.visible = true;
                npcArrow.position.set(girlNPCGroup.position.x, 2.2 + Math.sin(time) * 0.2, girlNPCGroup.position.z);
                npcArrow.rotation.y += 0.03;
            }
        }

        // --- SEÇÃO 3 (QUARTO) ---
        else if (currentSection === 3 && gameState === "INSIDE_HOUSE") {
            firstPersonYaw -= joystickInput.x * 0.04;

            windowArrow.position.y = 2.4 + Math.sin(time) * 0.15;
            windowArrow.rotation.y += 0.03;

            if (Math.abs(joystickInput.y) > 0.1) {
                const moveSpeed = -joystickInput.y * 0.08;
                const forwardX = Math.sin(firstPersonYaw) * moveSpeed;
                const forwardZ = Math.cos(firstPersonYaw) * moveSpeed;

                const nextPos = negiPlayer.position.clone().add(new THREE.Vector3(forwardX, 0, forwardZ));
                if (canMoveTo(nextPos)) {
                    negiPlayer.position.copy(nextPos);
                }
            }
        }

        // --- LÓGICA DE FUGA NOTURNA ---
        if (gameState === "NIGHT_ESCAPE") {
            const dir = new THREE.Vector3().subVectors(negiPlayer.position, enemyGroup.position).normalize();
            enemyGroup.position.add(dir.multiplyScalar(0.045));
            enemyGroup.lookAt(negiPlayer.position);

            exitGateArrow.position.set(exitGatePos.x, 4.5 + Math.sin(time) * 0.3, exitGatePos.z);
            exitGateArrow.rotation.y += 0.03;

            let collectedCount = 0;
            amulets.forEach(a => {
                if (!a.collected) {
                    a.arrow.position.y = a.pos.y + 1.8 + Math.sin(time) * 0.15;
                    a.arrow.rotation.y += 0.03;

                    if (negiPlayer.position.distanceTo(a.pos) < 2.0) {
                        a.collected = true;
                        a.mesh.visible = false;
                        a.arrow.visible = false;
                    }
                } else {
                    collectedCount++;
                }
            });

            const countElem = document.getElementById('amulet-count');
            if (countElem) countElem.innerText = `${collectedCount}`;

            if (collectedCount === 3 && negiPlayer.position.distanceTo(exitGatePos) < 3.5) {
                triggerVictory();
            }

            if (enemyGroup.position.distanceTo(negiPlayer.position) < 1.3) {
                triggerGameOver();
            }
        }

        // Câmera
        if (currentSection === 1 || currentSection === 2) {
            if (gameState !== "SECTION_1_2D") {
                camTarget.set(negiPlayer.position.x - 6, negiPlayer.position.y + 8, negiPlayer.position.z + 8);
                camLook.set(negiPlayer.position.x, negiPlayer.position.y + 1, negiPlayer.position.z);
            }
            camera.position.lerp(camTarget, 0.1);
            camera.lookAt(camLook);
        } 
        else if (currentSection === 3) {
            camera.position.set(negiPlayer.position.x, 1.6, negiPlayer.position.z);
            const lookDir = new THREE.Vector3(
                negiPlayer.position.x + Math.sin(firstPersonYaw),
                1.6,
                negiPlayer.position.z + Math.cos(firstPersonYaw)
            );
            camera.lookAt(lookDir);
        }

        flashlight.position.set(negiPlayer.position.x, negiPlayer.position.y + 1.8, negiPlayer.position.z);
        const forward = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), negiPlayer.rotation.y);
        flashlight.target.position.copy(negiPlayer.position).add(forward.multiplyScalar(10));
    }

    renderer.render(scene, camera);
}

animate();