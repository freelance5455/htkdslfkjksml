SUPER LEAGUE - پروژه اندروید

این پوشه یک پروژه Android Studio است و APK آماده نیست.

ساخت APK:
1) Android Studio را نصب کنید.
2) پوشه SuperLeagueAndroid را از File > Open باز کنید.
3) صبر کنید Gradle Sync کامل شود (این مرحله به اینترنت نیاز دارد تا افزونه اندروید دریافت شود).
4) از منوی Build گزینه Build Bundle(s) / APK(s) و سپس Build APK(s) را انتخاب کنید.
5) پس از ساخت، روی اعلان locate کلیک کنید. فایل معمولاً در app/build/outputs/apk/debug/app-debug.apk است.

برنامه به اینترنت نیاز ندارد. تیم‌ها و نتایج با ذخیره‌سازی داخلی WebView روی همان گوشی نگهداری می‌شوند.
