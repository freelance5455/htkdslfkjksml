const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const db = require("./db");

let SECRET = process.env.JWT_SECRET;
const PORT = process.env.PORT || 3000;

const app = express();
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.set({
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Strict-Transport-Security": "max-age=31536000",
    "Permissions-Policy": "geolocation=(self), microphone=(self), camera=()",
    "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
  });
  next();
});
// Simple rate limiter: returns true when a key has made more than max requests in ms.
const hits = new Map();
function limit(key, max, ms) {
  const now = Date.now(), h = (hits.get(key) || []).filter((t) => now - t < ms);
  h.push(now);
  hits.set(key, h);
  return h.length > max;
}
setInterval(() => { const now = Date.now(); for (const [k, h] of hits) if (now - h[h.length - 1] > 3600e3) hits.delete(k); }, 600e3).unref();
const ipOf = (req) => req.headers["cf-connecting-ip"] || req.socket.remoteAddress;
const isLocal = (req) => !req.headers["cf-connecting-ip"] && ["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(req.socket.remoteAddress);
const okUrl = (u) => /^\/files\/[\w-]+\.?\w{0,10}$/.test(String(u));
const server = http.createServer(app);
const io = new Server(server);

app.use((req, res, next) => (req.path === "/api/upload" ? next() : express.json()(req, res, next)));
const fs = require("fs");
const path = require("path");
const upDir = process.env.UPLOAD_DIR || path.join(__dirname, "data", "uploads");
fs.mkdirSync(upDir, { recursive: true });
if (!SECRET) { // no JWT_SECRET given: create a strong random one once and keep it
  const f = path.join(db.dir, "jwt-secret.txt");
  try { SECRET = fs.readFileSync(f, "utf8").trim(); }
  catch (e) { SECRET = crypto.randomBytes(48).toString("hex"); fs.writeFileSync(f, SECRET, { mode: 0o600 }); }
}
app.use("/files", express.static(upDir, { setHeaders: (r) => r.set("Content-Security-Policy", "sandbox") }));
app.post("/api/upload", auth, (req, res, next) => (limit("up:" + req.userId, 60, 3600e3) ? res.status(429).json({ error: "Too many uploads, try later" }) : next()), express.raw({ type: "*/*", limit: "15mb" }), (req, res) => {
  const name = path.basename(decodeURIComponent(req.headers["x-filename"] || "file")).slice(0, 100);
  const id = crypto.randomUUID() + path.extname(name).replace(/[^\w.]/g, "").slice(0, 10);
  fs.writeFileSync(path.join(upDir, id), Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0));
  res.json({ url: "/files/" + id, name, type: req.headers["content-type"] || "" });
});
app.use("/.well-known", express.static(path.join(__dirname, "public", ".well-known"), { dotfiles: "allow" })); // for the Android app (assetlinks.json)
app.use(express.static("public"));

// ---------- helpers ----------
const online = new Map(); // userId -> number of open sockets
const isOnline = (id) => (online.get(id) || 0) > 0;
const shown = (u) => u.displayName || u.username;
const publicUser = (u) => ({ id: u.id, username: shown(u), online: isOnline(u.id), owner: !!u.isOwner, avatar: u.avatar || null, lastSeen: u.lastSeen || null });
const self = (u) => ({ ...publicUser(u), login: u.username, blocked: u.blocked || [], ttl: u.ttl || {} });
const sign = (u) => jwt.sign({ id: u.id, v: u.tv || 0 }, SECRET, { expiresIn: "30d" });
function validUser(p) { // token must belong to an existing, not banned user, and not be logged out
  const u = db.users.find((x) => x.id === p.id);
  return u && !u.banned && (u.tv || 0) === (p.v || 0);
}

function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace("Bearer ", "");
  try {
    const p = jwt.verify(token, SECRET);
    if (!validUser(p)) throw new Error("removed");
    req.userId = p.id;
    next();
  } catch (e) {
    res.status(401).json({ error: "Not logged in" });
  }
}

// ---------- push notifications (work over https; need: npm install) ----------
let webpush = null, vapid = null;
try { webpush = require("web-push"); } catch (e) { console.log("Notifications while the app is closed are off. Run 'npm install' to turn them on."); }
if (webpush) {
  const f = path.join(db.dir, "vapid.json");
  try { vapid = JSON.parse(fs.readFileSync(f, "utf8")); }
  catch (e) { vapid = webpush.generateVAPIDKeys(); fs.writeFileSync(f, JSON.stringify(vapid), { mode: 0o600 }); }
  webpush.setVapidDetails(process.env.PUSH_CONTACT || "mailto:admin@example.com", vapid.publicKey, vapid.privateKey);
}
function pushTo(userId, payload) {
  const u = db.users.find((x) => x.id === userId);
  if (!webpush || !u || !(u.push || []).length || isOnline(userId)) return;
  const body = JSON.stringify(payload);
  u.push.forEach((s) => webpush.sendNotification(s, body).catch((e) => {
    if (e.statusCode === 404 || e.statusCode === 410) { u.push = u.push.filter((x) => x.endpoint !== s.endpoint); db.saveUsers(); }
  }));
}

// ---------- accounts ----------
// The first account becomes the owner and needs no invite code. From another device it needs the setup code printed in the server window.
const setupCode = db.users.length ? null : crypto.randomBytes(4).toString("hex");
if (setupCode) console.log("No owner account yet. Create it on this device at http://localhost:3000 (no code needed), or from another device with the setup code: " + setupCode);
app.get("/api/setup", (req, res) => res.json({ first: db.users.length === 0, local: isLocal(req) }));
app.post("/api/register", async (req, res) => {
  if (limit("reg:" + ipOf(req), 5, 3600e3)) return res.status(429).json({ error: "Too many attempts, try later" });
  // The very first account becomes the owner and needs no code. Everyone else needs a one-time code from the owner.
  const first = db.users.length === 0;
  if (first && !isLocal(req) && String(req.body.code || "").trim().toLowerCase() !== setupCode)
    return res.status(403).json({ error: "Create the owner account on the device that runs the server (open http://localhost:3000 there), or enter the setup code shown in the server window." });
  const inv = first ? null : db.invites.find((i) => !i.used && i.code === String(req.body.code || "").trim().toLowerCase());
  if (!first && !inv) return res.status(403).json({ error: "A valid access code is required. Ask the owner for one." });
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username))
    return res.status(400).json({ error: "Username: 3-20 letters, numbers or _" });
  if (password.length < 8)
    return res.status(400).json({ error: "Password must be at least 8 characters" });
  if (db.users.find((u) => u.username.toLowerCase() === username.toLowerCase()))
    return res.status(409).json({ error: "That username is taken" });

  const user = {
    id: crypto.randomUUID(),
    username,
    passwordHash: await bcrypt.hash(password, 12),
    createdAt: Date.now(),
    isOwner: first
  };
  if (inv && inv.used) return res.status(403).json({ error: "That code was just used" });
  if (inv) { inv.used = true; inv.usedBy = username; db.saveInvites(); }
  db.users.push(user);
  db.saveUsers();
  res.json({ token: sign(user), user: self(user) });
});

app.post("/api/login", async (req, res) => {
  if (limit("login:" + ipOf(req), 20, 900e3)) return res.status(429).json({ error: "Too many attempts, try again in 15 minutes" });
  const username = String(req.body.username || "").trim().toLowerCase();
  if (limit("loginu:" + username, 8, 900e3)) return res.status(429).json({ error: "Too many attempts, try again in 15 minutes" });
  const user = db.users.find((u) => u.username.toLowerCase() === username);
  if (!user || !(await bcrypt.compare(String(req.body.password || ""), user.passwordHash)))
    return res.status(401).json({ error: "Wrong username or password" });
  if (user.banned) return res.status(403).json({ error: "This account is suspended" });
  res.json({ token: sign(user), user: self(user) });
});

// ---------- data ----------
app.get("/api/me", auth, (req, res) => {
  const me = db.users.find((u) => u.id === req.userId);
  if (!me) return res.status(401).json({ error: "Unknown user" });
  res.json(self(me));
});

app.get("/api/users", auth, (req, res) => {
  res.json(db.users.filter((u) => u.id !== req.userId).map(publicUser));
});

app.get("/api/messages/:peerId", auth, (req, res) => {
  const peer = req.params.peerId;
  const _json = res.json.bind(res);
  const before = +req.query.before || Infinity; // pages of 50, newest first
  res.json = (arr) => _json(arr.filter((m) => !(m.hidden || []).includes(req.userId) && m.time < before).slice(-50).map(pub));
  const g = groupOf(peer);
  if (g) return res.json(g.members.includes(req.userId) && (!g.hidden || isUnlocked(req.userId, peer)) ? db.messages.filter((m) => m.to === peer) : []);
  res.json(
    db.messages.filter(
      (m) => (m.from === req.userId && m.to === peer) || (m.from === peer && m.to === req.userId)
    )
  );
});

// ---------- vault (password check, the password itself is never stored) ----------
const pub = ({ hidden, ...x }) => (x.once && x.file ? { ...x, file: { type: x.file.type, once: true } } : x); // never send the address of a view-once file
app.get("/api/vault", auth, (req, res) => res.json(db.users.find((u) => u.id === req.userId).vault || null));
app.post("/api/vault", auth, (req, res) => {
  const u = db.users.find((x) => x.id === req.userId);
  if (u.vault) return res.status(409).json({ error: "Password already set" });
  u.vault = String(req.body.check || "").slice(0, 400);
  db.saveUsers();
  res.json({ ok: true });
});

// ---------- owner: one-time invite codes ----------
if (db.users.length && !db.users.some((u) => u.isOwner)) { db.users[0].isOwner = true; db.saveUsers(); }
function ownerOnly(req, res, next) {
  const u = db.users.find((x) => x.id === req.userId);
  if (u && u.isOwner) return next();
  res.status(403).json({ error: "Owner only" });
}
const VERSION = require("./package.json").version + "-" + Math.floor(Math.max(...["app.js", "index.html", "style.css", "sw.js"].map((f) => fs.statSync(path.join(__dirname, "public", f)).mtimeMs)) / 1000);
app.get("/api/version", (req, res) => res.json({ version: VERSION }));
app.get("/api/members", auth, ownerOnly, (req, res) => res.json(db.users.filter((u) => u.id !== req.userId).map((u) => ({ ...publicUser(u), login: u.username, banned: !!u.banned }))));
app.post("/api/users/:id/reset", auth, ownerOnly, async (req, res) => {
  const u = db.users.find((x) => x.id === req.params.id), p = String(req.body.password || "");
  if (!u || p.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });
  u.passwordHash = await bcrypt.hash(p, 12);
  u.tv = (u.tv || 0) + 1;
  db.saveUsers();
  res.json({ ok: true });
});
app.delete("/api/users/:id", auth, ownerOnly, (req, res) => {
  const id = req.params.id, u = db.users.find((x) => x.id === id);
  if (!u || u.isOwner) return res.status(400).json({ error: "Cannot remove this user" });
  db.users = db.users.filter((x) => x.id !== id);
  db.groups.forEach((g) => { g.members = g.members.filter((m) => m !== id); g.admins = (g.admins || []).filter((m) => m !== id); });
  db.messages = db.messages.filter((m) => m.from !== id && m.to !== id);
  db.statuses = db.statuses.filter((s) => s.from !== id);
  db.saveUsers(); db.saveGroups(); db.saveMessages(); db.saveStatuses();
  io.in("user:" + id).disconnectSockets(true);
  io.emit("user-removed", { id });
  res.json({ ok: true });
});
app.post("/api/profile", auth, (req, res) => {
  const u = db.users.find((x) => x.id === req.userId);
  let name = req.body.username !== undefined ? String(req.body.username).trim() : u.username;
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(name)) return res.status(400).json({ error: "Username: 3-20 letters, numbers or _" });
  if (db.users.some((x) => x.id !== u.id && x.username.toLowerCase() === name.toLowerCase())) return res.status(409).json({ error: "That username is taken" });
  u.username = name;
  if (req.body.displayName !== undefined) u.displayName = String(req.body.displayName).trim().slice(0, 30);
  if (req.body.avatar !== undefined && okUrl(req.body.avatar)) u.avatar = req.body.avatar;
  db.saveUsers();
  io.emit("profile", publicUser(u));
  res.json(self(u));
});
app.post("/api/block", auth, (req, res) => {
  const u = db.users.find((x) => x.id === req.userId), id = String(req.body.id);
  u.blocked = (u.blocked || []).filter((x) => x !== id);
  if (req.body.block) u.blocked.push(id);
  db.saveUsers();
  res.json(self(u));
});
app.post("/api/password", auth, async (req, res) => {
  if (limit("pw:" + req.userId, 5, 900e3)) return res.status(429).json({ error: "Too many attempts, try later" });
  const u = db.users.find((x) => x.id === req.userId), n = String(req.body.new || "");
  if (!(await bcrypt.compare(String(req.body.old || ""), u.passwordHash))) return res.status(401).json({ error: "Current password is wrong" });
  if (n.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });
  u.passwordHash = await bcrypt.hash(n, 12);
  u.tv = (u.tv || 0) + 1; // signs out other devices
  db.saveUsers();
  res.json({ ok: true, token: sign(u) });
});
app.post("/api/invites", auth, ownerOnly, (req, res) => {
  const inv = { id: crypto.randomUUID(), code: crypto.randomBytes(5).toString("hex"), note: String(req.body.note || "").trim().slice(0, 40), used: false, createdAt: Date.now() };
  db.invites.push(inv);
  db.saveInvites();
  res.json(inv);
});
app.get("/api/invites", auth, ownerOnly, (req, res) => res.json(db.invites));
app.delete("/api/invites/:id", auth, ownerOnly, (req, res) => {
  db.invites = db.invites.filter((i) => i.id !== req.params.id || i.used);
  db.saveInvites();
  res.json({ ok: true });
});

// ---------- unread, clear chat, moderation, account tools ----------
const cleanupFile = (m) => { if (m.file) fs.unlink(path.join(upDir, path.basename(m.file.url)), () => {}); };
function removeUser(id) {
  db.messages.filter((m) => m.from === id).forEach(cleanupFile);
  db.users = db.users.filter((x) => x.id !== id);
  db.groups.forEach((g) => { g.members = g.members.filter((m) => m !== id); g.admins = (g.admins || []).filter((m) => m !== id); });
  db.messages = db.messages.filter((m) => m.from !== id && m.to !== id);
  db.statuses = db.statuses.filter((s) => s.from !== id);
  db.saveUsers(); db.saveGroups(); db.saveMessages(); db.saveStatuses();
  io.in("user:" + id).disconnectSockets(true);
  io.emit("user-removed", { id });
}
app.get("/api/health", (req, res) => res.json({ ok: true, version: VERSION, users: db.users.length }));
app.get("/api/unread", auth, (req, res) => {
  const u = db.users.find((x) => x.id === req.userId), out = {}, reads = u.reads || {};
  const mine = new Set(db.groups.filter((g) => g.members.includes(u.id) && (!g.hidden || isUnlocked(u.id, g.id))).map((g) => g.id));
  for (const m of db.messages) {
    if (m.from === u.id || m.deleted || m.system || (m.hidden || []).includes(u.id)) continue;
    if (mine.has(m.to)) { if (m.time > (reads[m.to] || 0)) out[m.to] = (out[m.to] || 0) + 1; }
    else if (m.to === u.id && m.status !== "read") out[m.from] = (out[m.from] || 0) + 1;
  }
  res.json(out);
});
app.post("/api/read", auth, (req, res) => {
  const u = db.users.find((x) => x.id === req.userId);
  u.reads = u.reads || {};
  u.reads[String(req.body.chat)] = Date.now();
  db.saveUsers();
  res.json({ ok: true });
});
app.post("/api/clear", auth, (req, res) => {
  const chat = String(req.body.chat), me = req.userId, g = groupOf(chat);
  db.messages.forEach((m) => {
    const inChat = g ? m.to === chat && g.members.includes(me) : (m.from === me && m.to === chat) || (m.from === chat && m.to === me);
    if (inChat && !(m.hidden || []).includes(me)) (m.hidden = m.hidden || []).push(me);
  });
  db.saveMessages();
  res.json({ ok: true });
});
app.get("/api/push-key", auth, (req, res) => res.json({ key: vapid ? vapid.publicKey : null }));
app.post("/api/push", auth, (req, res) => {
  const u = db.users.find((x) => x.id === req.userId), s = req.body.subscription;
  if (!vapid || !s || !/^https:\/\//.test(String(s.endpoint))) return res.status(400).json({ error: "Push unavailable" });
  u.push = (u.push || []).filter((x) => x.endpoint !== s.endpoint).concat([s]).slice(-5);
  db.saveUsers();
  res.json({ ok: true });
});
app.post("/api/report", auth, (req, res) => {
  if (limit("rep:" + req.userId, 10, 3600e3)) return res.status(429).json({ error: "Too many reports, try later" });
  const fb = req.body.feedback !== undefined, m = db.messages.find((x) => x.id === String(req.body.messageId));
  if (!fb && (!m || m.from === req.userId)) return res.status(400).json({ error: "Nothing to report" });
  db.reports.push({
    id: crypto.randomUUID(), by: req.userId, time: Date.now(), type: fb ? "feedback" : "message",
    text: fb ? String(req.body.feedback).slice(0, 1000) : m.enc ? "(locked message)" : String(m.text || (m.file ? m.file.name : "location")).slice(0, 300),
    target: fb ? null : m.from, msgId: fb ? null : m.id
  });
  db.saveReports();
  res.json({ ok: true });
});
const nameOf = (id) => shown(db.users.find((u) => u.id === id) || {}) || "?";
app.get("/api/reports", auth, ownerOnly, (req, res) => res.json(db.reports.slice(-50).reverse().map((r) => ({ ...r, byName: nameOf(r.by), targetName: r.target ? nameOf(r.target) : null }))));
app.delete("/api/reports/:id", auth, ownerOnly, (req, res) => { db.reports = db.reports.filter((r) => r.id !== req.params.id); db.saveReports(); res.json({ ok: true }); });
app.post("/api/users/:id/ban", auth, ownerOnly, (req, res) => {
  const u = db.users.find((x) => x.id === req.params.id);
  if (!u || u.isOwner) return res.status(400).json({ error: "Cannot ban this user" });
  u.banned = !!req.body.banned;
  db.saveUsers();
  if (u.banned) io.in("user:" + u.id).disconnectSockets(true);
  res.json({ ok: true });
});
app.post("/api/logout-all", auth, (req, res) => {
  const u = db.users.find((x) => x.id === req.userId);
  u.tv = (u.tv || 0) + 1; u.push = [];
  db.saveUsers();
  io.in("user:" + u.id).disconnectSockets(true);
  res.json({ ok: true });
});
app.get("/api/export", auth, (req, res) => {
  const u = db.users.find((x) => x.id === req.userId);
  const msgs = db.messages.filter((m) => !(m.hidden || []).includes(u.id) && (m.from === u.id || m.to === u.id || (groupOf(m.to) && groupOf(m.to).members.includes(u.id)))).map(pub);
  res.setHeader("Content-Disposition", 'attachment; filename="shadow-export.json"');
  res.json({ profile: self(u), messages: msgs });
});
app.post("/api/account/delete", auth, async (req, res) => {
  const u = db.users.find((x) => x.id === req.userId);
  if (u.isOwner) return res.status(400).json({ error: "The owner account cannot be deleted" });
  if (!(await bcrypt.compare(String(req.body.password || ""), u.passwordHash))) return res.status(401).json({ error: "Wrong password" });
  removeUser(u.id);
  res.json({ ok: true });
});

// ---------- groups ----------
const groupOf = (id) => db.groups.find((g) => g.id === id);
app.post("/api/groups", auth, (req, res) => {
  const name = String(req.body.name || "").trim().slice(0, 40);
  const names = (req.body.members || []).map((s) => String(s).trim().toLowerCase());
  const members = [req.userId, ...db.users.filter((u) => names.includes(u.username.toLowerCase()) && u.id !== req.userId).map((u) => u.id)];
  if (!name || (members.length < 2 && req.body.type !== "channel")) return res.status(400).json({ error: "Give a name and at least one valid username" });
  const g = { id: crypto.randomUUID(), name, members, admins: [req.userId], type: req.body.type === "channel" ? "channel" : "group", invite: crypto.randomBytes(6).toString("hex"), theme: "pine", group: true };
  db.groups.push(g);
  db.saveGroups();
  members.forEach((id) => io.to("user:" + id).emit("group", g));
  res.json(g);
});
app.get("/api/groups", auth, (req, res) => res.json(db.groups.filter((g) => g.members.includes(req.userId) && (!g.hidden || isUnlocked(req.userId, g.id))).map(safe)));

// ---------- secret groups, admin tools, invites ----------
const unlocked = new Map();
const isUnlocked = (u, id) => (unlocked.get(u) || new Set()).has(id);
const safe = ({ pass, ...g }) => g;
const tell = (g, ev, data) => g.members.forEach((id) => io.to("user:" + id).emit(ev, data));
function adminOf(req, res) {
  const g = groupOf(req.params.id);
  if (!g || !(g.admins || []).includes(req.userId)) { res.status(403).json({ error: "Admins only" }); return null; }
  return g;
}
app.post("/api/groups/:id/members", auth, (req, res) => {
  const g = adminOf(req, res); if (!g) return;
  const names = (req.body.members || []).map((s) => String(s).trim().toLowerCase());
  db.users.filter((u) => names.includes(u.username.toLowerCase()) && !g.members.includes(u.id)).forEach((u) => g.members.push(u.id));
  db.saveGroups();
  if (!g.hidden) tell(g, "group", safe(g));
  res.json({ ok: true });
});
app.post("/api/groups/:id/theme", auth, (req, res) => {
  const g = adminOf(req, res); if (!g) return;
  if (req.body.theme !== undefined) g.theme = String(req.body.theme || "pine").slice(0, 20);
  if (req.body.bg !== undefined) g.bg = okUrl(req.body.bg) ? req.body.bg : undefined;
  db.saveGroups();
  if (!g.hidden) tell(g, "group", safe(g));
  res.json({ ok: true });
});
app.post("/api/groups/:id/hide", auth, async (req, res) => {
  const g = adminOf(req, res); if (!g) return;
  const pw = String(req.body.password || "");
  if (g.hidden) {
    if (!(await bcrypt.compare(pw, g.pass))) return res.status(401).json({ error: "Wrong password" });
    g.hidden = false; delete g.pass; db.saveGroups();
    tell(g, "group", safe(g));
    return res.json({ hidden: false });
  }
  if (pw.length < 4) return res.status(400).json({ error: "Password needs at least 4 characters" });
  g.pass = await bcrypt.hash(pw, 10); g.hidden = true; db.saveGroups();
  g.members.forEach((id) => { if (unlocked.get(id)) unlocked.get(id).delete(g.id); });
  tell(g, "gone-group", { id: g.id });
  res.json({ hidden: true });
});
app.post("/api/secret/open", auth, async (req, res) => {
  const pw = String(req.body.password || ""), found = [];
  for (const g of db.groups) {
    if (g.hidden && g.members.includes(req.userId) && (await bcrypt.compare(pw, g.pass))) {
      if (!unlocked.has(req.userId)) unlocked.set(req.userId, new Set());
      unlocked.get(req.userId).add(g.id);
      found.push(safe(g));
    }
  }
  found.length ? res.json(found) : res.status(401).json({ error: "No secret group opens with that password" });
});
app.post("/api/join/:code", auth, (req, res) => {
  const g = db.groups.find((x) => x.invite === req.params.code && !x.hidden);
  if (!g) return res.status(404).json({ error: "Invalid or expired link" });
  if (!g.members.includes(req.userId)) { g.members.push(req.userId); db.saveGroups(); tell(g, "group", safe(g)); }
  res.json(safe(g));
});

// ---------- group members ----------
function dropMember(g, id) {
  g.members = g.members.filter((x) => x !== id);
  g.admins = (g.admins || []).filter((x) => x !== id);
  io.to("user:" + id).emit("gone-group", { id: g.id });
  if (!g.members.length) {
    db.messages.filter((m) => m.to === g.id).forEach(cleanupFile);
    db.messages = db.messages.filter((m) => m.to !== g.id);
    db.groups = db.groups.filter((x) => x.id !== g.id);
    db.saveMessages();
  } else {
    if (!g.admins.length) g.admins.push(g.members[0]);
    if (!g.hidden) tell(g, "group", safe(g));
  }
  db.saveGroups();
}
app.get("/api/groups/:id/members", auth, (req, res) => {
  const g = groupOf(req.params.id);
  if (!g || !g.members.includes(req.userId)) return res.status(403).json({ error: "Not a member" });
  res.json(g.members.map((id) => ({ id, name: nameOf(id), admin: (g.admins || []).includes(id) })));
});
app.post("/api/groups/:id/leave", auth, (req, res) => {
  const g = groupOf(req.params.id);
  if (!g || !g.members.includes(req.userId)) return res.status(400).json({ error: "Not a member" });
  dropMember(g, req.userId);
  res.json({ ok: true });
});
app.post("/api/groups/:id/remove", auth, (req, res) => {
  const g = adminOf(req, res); if (!g) return;
  const id = String(req.body.userId);
  if (!g.members.includes(id)) return res.status(400).json({ error: "Not a member" });
  dropMember(g, id);
  res.json({ ok: true });
});
app.post("/api/groups/:id/admin", auth, (req, res) => {
  const g = adminOf(req, res); if (!g) return;
  const id = String(req.body.userId);
  if (!g.members.includes(id)) return res.status(400).json({ error: "Not a member" });
  g.admins = (g.admins || []).filter((x) => x !== id);
  if (req.body.admin) g.admins.push(id);
  if (!g.admins.length) g.admins.push(req.userId);
  db.saveGroups();
  if (!g.hidden) tell(g, "group", safe(g));
  res.json({ ok: true });
});

// ---------- status (disappears after 24 hours) ----------
const DAY = 864e5;
app.post("/api/status", auth, (req, res) => {
  const text = String(req.body.text || "").slice(0, 500), f = req.body.file;
  const file = f && okUrl(f.url) ? { url: String(f.url), type: String(f.type) } : null;
  if (!text && !file) return res.status(400).json({ error: "Empty status" });
  db.statuses.push({ id: crypto.randomUUID(), from: req.userId, text, file, color: /^#[0-9a-f]{6}$/i.test(String(req.body.color)) ? req.body.color : "#2f5d50", time: Date.now() });
  db.saveStatuses();
  io.emit("status-update");
  res.json({ ok: true });
});
app.get("/api/status", auth, (req, res) => {
  const now = Date.now(), old = db.statuses.filter((s) => now - s.time >= DAY);
  if (old.length) {
    old.forEach((s) => s.file && fs.unlink(path.join(upDir, path.basename(s.file.url)), () => {}));
    db.statuses = db.statuses.filter((s) => now - s.time < DAY);
    db.saveStatuses();
  }
  res.json(db.statuses.map(({ views, ...s }) => ({ ...s, name: shown(db.users.find((u) => u.id === s.from) || {}), viewers: s.from === req.userId ? Object.entries(views || {}).map(([id, time]) => ({ name: shown(db.users.find((u) => u.id === id) || {}), time })) : undefined })));
});

app.post("/api/status/:id/react", auth, (req, res) => {
  const s = db.statuses.find((x) => x.id === req.params.id);
  if (!s) return res.status(404).json({ error: "Status expired" });
  s.likes = s.likes || {};
  const e = String(req.body.emoji || "\u2764\uFE0F").slice(0, 8);
  if (s.likes[req.userId] === e) delete s.likes[req.userId]; else s.likes[req.userId] = e;
  db.saveStatuses();
  res.json({ ok: true });
});
app.post("/api/status/:id/comment", auth, (req, res) => {
  const s = db.statuses.find((x) => x.id === req.params.id);
  const text = String(req.body.text || "").trim().slice(0, 300);
  if (!s || !text) return res.status(400).json({ error: "Nothing to post" });
  const u = db.users.find((x) => x.id === req.userId);
  (s.comments = s.comments || []).push({ id: crypto.randomUUID(), from: u.id, name: shown(u), text, time: Date.now() });
  db.saveStatuses();
  res.json({ ok: true });
});

// ---------- real time ----------
io.use((socket, next) => {
  try {
    const p = jwt.verify(socket.handshake.auth.token, SECRET);
    if (!validUser(p)) throw new Error("removed");
    socket.userId = p.id;
    next();
  } catch (e) {
    next(new Error("unauthorized"));
  }
});

io.on("connection", (socket) => {
  const me = socket.userId;
  socket.join("user:" + me);
  online.set(me, (online.get(me) || 0) + 1);
  io.emit("presence", { userId: me, online: true });

  // Messages sent while I was offline are now "delivered".
  const pending = db.messages.filter((m) => m.to === me && m.status === "sent");
  if (pending.length) {
    pending.forEach((m) => (m.status = "delivered"));
    db.saveMessages();
    const bySender = {};
    pending.forEach((m) => (bySender[m.from] = bySender[m.from] || []).push(m.id));
    Object.keys(bySender).forEach((sender) =>
      io.to("user:" + sender).emit("status", { ids: bySender[sender], status: "delivered" })
    );
  }

  socket.on("private message", (data, ack) => {
    if (limit("msg:" + me, 40, 10e3)) return;
    const text = String((data && data.text) || "").trim().slice(0, 4000);
    const to = data && data.to;
    const g = groupOf(to);
    const rc = !g && db.users.find((u) => u.id === to), meU = db.users.find((u) => u.id === me);
    if (rc && ((rc.blocked || []).includes(me) || (meU.blocked || []).includes(to))) return; // blocked
    const f = data && data.file && okUrl(data.file.url) ? data.file : null;
    const loc = data && data.loc && isFinite(data.loc.lat) && isFinite(data.loc.lng) ? { lat: +data.loc.lat, lng: +data.loc.lng, acc: +data.loc.acc || null, live: !!data.loc.live, until: data.loc.live ? Math.min(+data.loc.until || 0, Date.now() + 8.5 * 3600e3) : undefined, at: Date.now() } : null;
    if ((!text && !f && !loc) || (g ? !g.members.includes(me) || (g.hidden && !isUnlocked(me, g.id)) || (g.type === "channel" && !(g.admins || []).includes(me)) : !db.users.find((u) => u.id === to))) return;

    const chatTtl = g ? g.ttl : (meU.ttl || {})[to];
    const ttl = data.ttlMin !== undefined ? Math.max(0, Math.min(+data.ttlMin || 0, 43200)) * 60e3 : chatTtl; // sender can choose a time for one message
    const once = !g && f && data.once && (/^(image|video)\//.test(String(f.type)) || /\.(jpe?g|png|gif|webp|mp4|webm|mov|3gp)$/i.test(String(f.url)));
    const msg = {
      expires: ttl ? Date.now() + ttl : undefined,
      id: crypto.randomUUID(),
      from: me,
      to,
      text,
      file: f && { url: String(f.url), name: String(f.name).slice(0, 100), type: String(f.type) },
      loc,
      replyTo: typeof data.replyTo === "string" ? data.replyTo : null,
      cid: typeof data.cid === "string" ? data.cid.slice(0, 40) : undefined,
      once: once || undefined,
      time: Date.now(),
      status: !g && isOnline(to) ? "delivered" : "sent"
    };
    db.messages.push(msg);
    db.saveMessages();
    (g ? g.members : [to, me]).forEach((id) => io.to("user:" + id).emit("private message", pub(msg)));
    const quiet = g && g.hidden;
    const preview = quiet ? "New message" : msg.text ? msg.text.slice(0, 100) : msg.file ? "Sent a file" : msg.loc ? "Shared a location" : "New message";
    (g ? g.members : [to]).filter((id) => id !== me).forEach((id) => pushTo(id, { title: quiet ? "Shadow" : (g ? g.name + ": " : "") + shown(meU), body: preview, chat: g ? g.id : me }));
    if (typeof ack === "function") ack(msg.id);
  });

  socket.on("delete", ({ id }) => {
    const m = db.messages.find((x) => x.id === id && x.from === me);
    if (!m) return;
    m.deleted = true; m.text = ""; m.file = null;
    db.saveMessages();
    const g = groupOf(m.to);
    (g ? g.members : [m.to, me]).forEach((u) => io.to("user:" + u).emit("deleted", { id }));
  });

  const audience = (m) => { const g = groupOf(m.to); return g ? g.members : [m.from, m.to]; };
  const cleanup = (m) => { if (m.file) fs.unlink(path.join(upDir, path.basename(m.file.url)), () => {}); };

  socket.on("update", ({ id, text, file, enc, dec }) => {
    const m = db.messages.find((x) => x.id === id && x.from === me && !x.deleted);
    if (!m || (m.enc && !enc && !dec)) return;
    if (typeof text === "string") { m.text = text.slice(0, 8000); if (!enc && !dec) m.edited = true; }
    if (file && okUrl(file.url)) {
      cleanup(m);
      m.file = { url: String(file.url), name: String(file.name).slice(0, 100), type: String(file.type), ot: file.ot ? String(file.ot).slice(0, 100) : undefined };
    }
    if (enc) m.enc = true;
    if (dec) m.enc = false;
    db.saveMessages();
    audience(m).forEach((u) => io.to("user:" + u).emit("updated", pub(m)));
  });

  const myLive = (id) => db.messages.find((x) => x.id === id && x.from === me && x.loc && x.loc.live);
  socket.on("live", ({ id, lat, lng, acc }) => {
    const m = myLive(id);
    if (!m || Date.now() > m.loc.until || !isFinite(lat) || !isFinite(lng) || limit("live:" + me, 30, 60e3)) return;
    Object.assign(m.loc, { lat: +lat, lng: +lng, acc: +acc || null, at: Date.now() });
    db.saveMessages();
    audience(m).forEach((u) => io.to("user:" + u).emit("updated", pub(m)));
  });
  socket.on("live-stop", ({ id }) => {
    const m = myLive(id);
    if (!m) return;
    m.loc.live = false;
    db.saveMessages();
    audience(m).forEach((u) => io.to("user:" + u).emit("updated", pub(m)));
  });

  socket.on("react", ({ id, emoji }) => {
    const m = db.messages.find((x) => x.id === id);
    if (!m || !audience(m).includes(me)) return;
    m.reactions = m.reactions || {};
    if (m.reactions[me] === emoji) delete m.reactions[me]; else m.reactions[me] = String(emoji).slice(0, 8);
    db.saveMessages();
    audience(m).forEach((u) => io.to("user:" + u).emit("updated", pub(m)));
  });

  socket.on("purge", ({ id }) => {
    const m = db.messages.find((x) => x.id === id);
    if (!m || !audience(m).includes(me)) return;
    if (m.from === me) {
      cleanup(m);
      Object.assign(m, { deleted: true, text: "", file: null, loc: null, enc: false, reactions: {} });
      db.saveMessages();
      audience(m).forEach((u) => io.to("user:" + u).emit("deleted", { id }));
    } else {
      (m.hidden = m.hidden || []).push(me);
      db.saveMessages();
      io.to("user:" + me).emit("gone", { id });
    }
  });

  socket.on("typing", ({ to }) => {
    io.to("user:" + to).emit("typing", { from: me });
  });

  socket.on("read", ({ from }) => {
    const unread = db.messages.filter((m) => m.from === from && m.to === me && m.status !== "read");
    if (!unread.length) return;
    unread.forEach((m) => (m.status = "read"));
    db.saveMessages();
    io.to("user:" + from).emit("status", { ids: unread.map((m) => m.id), status: "read" });
  });

  socket.on("call:offer", ({ to, sdp, video, callId }) => {
    const meU = db.users.find((u) => u.id === me), peer = db.users.find((u) => u.id === to);
    if (!peer || groupOf(to) || typeof callId !== "string" || !sdp || limit("call:" + me, 10, 60e3)) return;
    if ((peer.blocked || []).includes(me) || (meU.blocked || []).includes(to) || peer.banned) return socket.emit("call:end", { callId, reason: "unavailable" });
    if (!isOnline(to)) {
      pushTo(to, { title: shown(meU), body: video ? "Missed video call" : "Missed voice call", chat: me });
      logCall(me, to, video, "missed", 0);
      return socket.emit("call:end", { callId, reason: "offline" });
    }
    if ([...calls.values()].some((c) => [c.a, c.b].includes(to) || [c.a, c.b].includes(me))) return socket.emit("call:end", { callId, reason: "busy" });
    calls.set(callId, { a: me, b: to, video: !!video, t0: 0 });
    io.to("user:" + to).emit("call:offer", { from: me, name: shown(meU), sdp, video: !!video, callId });
    setTimeout(() => { const c = calls.get(callId); if (c && !c.t0) endCall(callId, "server", "noanswer"); }, 45e3).unref();
  });
  socket.on("call:answer", ({ callId, sdp }) => {
    const c = calls.get(callId);
    if (!c || c.b !== me) return;
    c.t0 = Date.now();
    io.to("user:" + c.a).emit("call:answer", { callId, sdp });
  });
  socket.on("call:ice", ({ callId, candidate }) => {
    const c = calls.get(callId);
    if (!c || ![c.a, c.b].includes(me)) return;
    io.to("user:" + (c.a === me ? c.b : c.a)).emit("call:ice", { callId, candidate });
  });
  socket.on("call:end", ({ callId, reason }) => endCall(callId, me, ["busy"].includes(reason) ? "busy" : "ended"));

  socket.on("disconnect", () => {
    const n = (online.get(me) || 1) - 1;
    if (n <= 0) {
      endCallsOf(me);
      online.delete(me);
      const uu = db.users.find((x) => x.id === me);
      if (uu) { uu.lastSeen = Date.now(); db.saveUsers(); }
      io.emit("presence", { userId: me, online: false, lastSeen: Date.now() });
    } else online.set(me, n);
  });
});

// ---------- voice and video calls (WebRTC signalling) ----------
const calls = new Map(); // callId -> { a: caller, b: callee, video, t0 (when answered) }
function logCall(a, b, video, result, secs) {
  const sm = { id: crypto.randomUUID(), from: a, to: b, system: true, sys: { type: "call", video: !!video, result, secs }, text: "", time: Date.now(), status: "read" };
  db.messages.push(sm);
  db.saveMessages();
  [a, b].forEach((u) => io.to("user:" + u).emit("private message", pub(sm)));
}
function endCall(callId, by, reason) {
  const c = calls.get(callId);
  if (!c) return;
  calls.delete(callId);
  (by === "server" ? [c.a, c.b] : [c.a === by ? c.b : c.a]).forEach((u) => io.to("user:" + u).emit("call:end", { callId, reason }));
  logCall(c.a, c.b, c.video, c.t0 ? "ended" : by === c.b ? "declined" : "missed", c.t0 ? Math.round((Date.now() - c.t0) / 1000) : 0);
}
function endCallsOf(id) { for (const [callId, c] of calls) if (c.a === id || c.b === id) endCall(callId, id, "ended"); }
app.get("/api/ice", auth, (req, res) => {
  const servers = [{ urls: "stun:stun.l.google.com:19302" }], urls = (process.env.TURN_URLS || "").split(",").map((s) => s.trim()).filter(Boolean);
  if (urls.length) {
    let username = process.env.TURN_USER, credential = process.env.TURN_PASS;
    if (process.env.TURN_SECRET) { // time-limited credentials for coturn
      username = Math.floor(Date.now() / 1000) + 86400 + ":" + req.userId;
      credential = crypto.createHmac("sha1", process.env.TURN_SECRET).update(username).digest("base64");
    }
    servers.push({ urls, username, credential });
  }
  res.json({ iceServers: servers });
});
app.post("/api/ttl", auth, (req, res) => {
  const chat = String(req.body.chat), min = Math.max(0, Math.min(+req.body.minutes || 0, 43200)), ms = min * 60e3, g = groupOf(chat);
  const a = db.users.find((u) => u.id === req.userId);
  if (g) {
    if (!(g.admins || []).includes(req.userId)) return res.status(403).json({ error: "Admins only" });
    g.ttl = ms || undefined;
    db.saveGroups();
    if (!g.hidden) tell(g, "group", safe(g));
  } else {
    const b = db.users.find((u) => u.id === chat);
    if (!b) return res.status(400).json({ error: "Unknown chat" });
    [[a, chat], [b, req.userId]].forEach(([u, other]) => { u.ttl = u.ttl || {}; if (ms) u.ttl[other] = ms; else delete u.ttl[other]; });
    db.saveUsers();
  }
  // a notice inside the chat so everyone can see the timer was switched on or off
  const sm = { id: crypto.randomUUID(), from: req.userId, to: chat, system: true, sys: { type: "ttl", min }, text: "", time: Date.now(), status: "read" };
  db.messages.push(sm);
  db.saveMessages();
  (g ? g.members : [req.userId, chat]).forEach((u) => io.to("user:" + u).emit("private message", pub(sm)));
  res.json(self(a));
});
// view-once photos and videos
function finishOnce(m) {
  if (!m.file) return;
  cleanupFile(m);
  m.file = null;
  db.saveMessages();
  [m.from, m.to].forEach((u) => io.to("user:" + u).emit("updated", pub(m)));
}
app.post("/api/once/:id/open", auth, (req, res) => {
  const m = db.messages.find((x) => x.id === req.params.id);
  if (!m || !m.once || m.opened || m.to !== req.userId || !m.file) return res.status(403).json({ error: "This can only be opened once" });
  m.opened = true;
  m.openedAt = Date.now();
  db.saveMessages();
  setTimeout(() => finishOnce(m), 120e3).unref();
  [m.from, m.to].forEach((u) => io.to("user:" + u).emit("updated", pub(m)));
  res.json({ url: m.file.url, type: m.file.type });
});
app.post("/api/once/:id/done", auth, (req, res) => {
  const m = db.messages.find((x) => x.id === req.params.id);
  if (m && m.once && m.opened && m.to === req.userId) finishOnce(m);
  res.json({ ok: true });
});
db.messages.filter((m) => m.once && m.opened && m.file).forEach(finishOnce);
app.post("/api/status/:id/seen", auth, (req, res) => {
  const s = db.statuses.find((x) => x.id === req.params.id);
  if (s && s.from !== req.userId) {
    s.views = s.views || {};
    if (!s.views[req.userId]) { s.views[req.userId] = Date.now(); db.saveStatuses(); }
  }
  res.json({ ok: true });
});
// remove disappearing messages when their time is up
setInterval(() => {
  const now = Date.now(), gone = db.messages.filter((m) => m.expires && m.expires < now);
  if (!gone.length) return;
  gone.forEach(cleanupFile);
  db.messages = db.messages.filter((m) => !(m.expires && m.expires < now));
  db.saveMessages();
  gone.forEach((m) => { const g = groupOf(m.to); (g ? g.members : [m.from, m.to]).forEach((u) => io.to("user:" + u).emit("gone", { id: m.id })); });
}, 60e3).unref();
app.get("/api/last", auth, (req, res) => {
  const me = req.userId, out = {}, gs = new Map(db.groups.filter((g) => g.members.includes(me) && (!g.hidden || isUnlocked(me, g.id))).map((g) => [g.id, g]));
  for (const m of db.messages) {
    if ((m.hidden || []).includes(me) || m.system) continue;
    const chat = gs.has(m.to) ? m.to : m.from === me ? m.to : m.to === me ? m.from : null;
    if (!chat) continue;
    out[chat] = { time: m.time, mine: m.from === me, kind: m.deleted ? "deleted" : m.enc ? "enc" : m.text ? "text" : m.file ? "file" : m.loc ? "loc" : "text", text: m.deleted || m.enc ? "" : String(m.text || "").slice(0, 60) };
  }
  res.json(out);
});
app.delete("/api/status/:id", auth, (req, res) => {
  const s = db.statuses.find((x) => x.id === req.params.id && x.from === req.userId);
  if (!s) return res.status(404).json({ error: "Not found" });
  cleanupFile(s);
  db.statuses = db.statuses.filter((x) => x !== s);
  db.saveStatuses();
  io.emit("status-update");
  res.json({ ok: true });
});
app.use((err, req, res, next) => res.status(err.status || 500).json({ error: err.type === "entity.too.large" ? "File is too large" : "Server error" }));
db.init()
  .then(() => server.listen(PORT, process.env.HOST || "127.0.0.1", () => console.log("Shadow " + VERSION + " running on port " + PORT + ". Folder: " + __dirname + ". Sign-up needs an invite code from the owner.")))
  .catch((e) => { console.error(e.message); process.exit(1); });

process.on("uncaughtException", (e) => console.error("Error:", e));
