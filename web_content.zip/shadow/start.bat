@echo off
cd /d "%~dp0"
if not exist node_modules call npm install
:run
node --disable-warning=ExperimentalWarning server.js
echo Server stopped. Restarting in 5 seconds... (close this window to stop)
timeout /t 5 >nul
goto run
