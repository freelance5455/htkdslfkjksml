# Shadow

Real-time chat: accounts, one-to-one messages, saved history, online status,
typing indicator, sent / delivered / read ticks, unread counters.

## Run it (Windows)

1. Install Node.js from https://nodejs.org (LTS version).
2. Open cmd in this folder and run:

       npm install
       node server.js

   (or just double-click start.bat)
3. Open http://localhost:3000
4. To test, open a second browser window (or a private window), create another
   account, and chat between the two.

## Files

- server.js      - Express + Socket.IO server, auth (bcrypt + JWT), message logic
- db.js          - JSON-file storage in data/ (swap for PostgreSQL later)
- public/        - the browser app (index.html, style.css, app.js)

## Next steps

Group chats, images/files, message replies and reactions, push notifications,
then PostgreSQL, then end-to-end encryption and calls.
Set JWT_SECRET as an environment variable before putting it online.

## Added in this version
Groups (New group button), photo and file sharing, delete for everyone, installable phone app (PWA).
On a phone, "Add to Home Screen" needs HTTPS, so deploy it (Render, Railway) or use a tunnel such as ngrok.
