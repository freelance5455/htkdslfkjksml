// Lists users, or sets a new password. STOP the server first, then run:
//   node --disable-warning=ExperimentalWarning reset-password.js USERNAME NEWPASSWORD
const bcrypt = require("bcryptjs");
const db = require("./db");
const [name, pw] = process.argv.slice(2);
if (!name) {
  console.log("Users: " + (db.users.map((u) => u.username + (u.isOwner ? " (owner)" : "")).join(", ") || "none yet"));
  console.log("To set a new password: node --disable-warning=ExperimentalWarning reset-password.js USERNAME NEWPASSWORD");
  process.exit(0);
}
const u = db.users.find((x) => x.username.toLowerCase() === name.toLowerCase());
if (!u) { console.log("No user called " + name + ". Users: " + db.users.map((x) => x.username).join(", ")); process.exit(1); }
if (!pw || pw.length < 8) { console.log("The new password needs 8 or more characters."); process.exit(1); }
u.passwordHash = bcrypt.hashSync(pw, 12);
u.tokenVersion = (u.tokenVersion || 0) + 1;
u.banned = false;
db.saveUsers();
setTimeout(() => { db.flushAll(); console.log("Password changed for " + u.username + ". Start the server and sign in."); process.exit(0); }, 300);
