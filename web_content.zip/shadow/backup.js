// Makes a safe copy of the database in data/backups and keeps the newest 14.
const { DatabaseSync } = require("node:sqlite");
const path = require("path");
const fs = require("fs");
const dir = process.env.DATA_DIR || path.join(__dirname, "data");
const out = path.join(dir, "backups");
fs.mkdirSync(out, { recursive: true });
const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 16);
const dest = path.join(out, "shadow-" + stamp + ".db");
const sql = new DatabaseSync(path.join(dir, "shadow.db"));
sql.exec("VACUUM INTO '" + dest.replace(/'/g, "''") + "'");
fs.readdirSync(out).filter((f) => f.endsWith(".db")).sort().reverse().slice(14).forEach((f) => fs.unlinkSync(path.join(out, f)));
console.log("Backup saved: " + dest + "\nAlso copy the data\\uploads folder to keep photos and files.");
