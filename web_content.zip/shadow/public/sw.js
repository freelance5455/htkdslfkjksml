const C = "shadow-v20"; // change this number every time you release an update
self.addEventListener("install", (e) => e.waitUntil(caches.open(C).then((c) => c.addAll(["/", "/style.css", "/app.js", "/icon-192.png"]))));
self.addEventListener("activate", (e) => e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== C).map((k) => caches.delete(k))))));
self.addEventListener("message", (e) => { if (e.data === "skip") self.skipWaiting(); });
self.addEventListener("fetch", (e) => {
  const u = e.request.url;
  if (e.request.method !== "GET" || u.includes("/api/") || u.includes("/socket.io/") || u.includes("/files/")) return;
  e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
});

self.addEventListener("push", (e) => {
  let d = {};
  try { d = e.data.json(); } catch (x) {}
  e.waitUntil(self.registration.showNotification(d.title || "Shadow", { body: d.body || "New message", icon: "/icon-192.png", badge: "/icon-192.png", tag: d.chat || "shadow", data: { chat: d.chat } }));
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  e.waitUntil(clients.matchAll({ type: "window", includeUncontrolled: true }).then((l) => (l.length ? l[0].focus() : clients.openWindow("/"))));
});
