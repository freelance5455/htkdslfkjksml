if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js").then((reg) => {
    const watch = (w) => w.addEventListener("statechange", () => { if (w.state === "installed" && navigator.serviceWorker.controller) showUpdate(w); });
    if (reg.waiting && navigator.serviceWorker.controller) showUpdate(reg.waiting);
    reg.addEventListener("updatefound", () => watch(reg.installing));
    setInterval(() => reg.update(), 3600000);
  });
  navigator.serviceWorker.addEventListener("controllerchange", () => location.reload());
}
function showUpdate(w) {
  document.getElementById("update").classList.remove("hidden");
  document.getElementById("update-btn").onclick = () => w.postMessage("skip");
}
