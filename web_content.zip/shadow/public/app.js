const $ = (id) => document.getElementById(id);
const state = { token: null, me: null, users: [], groups: [], active: null, more: {}, messages: {}, unread: {}, last: {}, socket: null, typingTimer: null };

// ---------- auth ----------
async function authRequest(path) {
  $("auth-error").textContent = "";
  const res = await fetch("/api/" + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: $("username").value, password: $("password").value, code: $("code").value })
  });
  const data = await res.json();
  if (!res.ok) { $("auth-error").textContent = data.error; return; }
  localStorage.setItem("token", data.token);
  start(data.token, data.user);
}
$("btn-login").onclick = () => authRequest("login");
$("btn-register").onclick = () => authRequest("register");
["username", "password", "code"].forEach((id) => $(id).addEventListener("keydown", (e) => { if (e.key === "Enter") authRequest($("auth").classList.contains("up") ? "register" : "login"); }));
function setMode(up) {
  $("auth").classList.toggle("up", up); $("auth").classList.toggle("in", !up);
  $("tab-in").classList.toggle("on", !up); $("tab-up").classList.toggle("on", up);
  $("password").autocomplete = up ? "new-password" : "current-password";
  $("auth-error").textContent = "";
}
$("tab-in").onclick = () => setMode(false);
$("tab-up").onclick = () => setMode(true);
$("eye").onclick = () => { $("password").type = $("password").type === "password" ? "text" : "password"; };
document.documentElement.dataset.theme = localStorage.getItem("mode") || "dark";
function applyAccent(v) { // a ready-made colour, or "custom:#rrggbb"
  const r = document.documentElement;
  ["--pine", "--pine-dark", "--pine-rgb", "--a2-rgb", "--a3-rgb", "--acc2", "--grad", "--glow", "--blob1", "--blob2", "--blob3", "--hero-a", "--hero-b"].forEach((x) => r.style.removeProperty(x));
  if (v && v.startsWith("custom:") && /^#[0-9a-f]{6}$/i.test(v.slice(7))) {
    const hex = v.slice(7), [h, s, l] = hexHsl(hex), c1 = hslHex(h - 35, s, Math.min(l + 0.1, 0.7)), c3 = hslHex(h + 45, s, Math.max(l - 0.05, 0.3)), rgb = (x) => hexRgb(x).join(", "), set = (k, val) => r.style.setProperty(k, val);
    set("--pine", hex); set("--pine-dark", hslHex(h, s, Math.max(l - 0.1, 0.2))); set("--pine-rgb", rgb(hex)); set("--a2-rgb", rgb(c1)); set("--a3-rgb", rgb(c3)); set("--acc2", c3);
    set("--grad", "linear-gradient(135deg," + c1 + " 0%," + hex + " 52%," + c3 + " 100%)"); set("--glow", "0 10px 32px rgba(" + rgb(hex) + ", .42)");
    set("--blob1", hex); set("--blob2", c1); set("--blob3", c3); set("--hero-a", tint(c1, 0.55)); set("--hero-b", tint(c3, 0.55));
    r.dataset.accent = "custom";
  } else r.dataset.accent = GRADS_KEYS.includes(v) ? v : "emerald";
}
const GRADS_KEYS = ["emerald", "ocean", "violet", "aurora", "sunset", "rose"];
applyAccent(localStorage.getItem("accent"));
$("btn-logout").onclick = () => { localStorage.removeItem("token"); location.reload(); };

async function api(path) {
  const res = await fetch("/api/" + path, { headers: { Authorization: "Bearer " + state.token } });
  if (!res.ok) throw new Error("request failed");
  return res.json();
}

// ---------- start ----------
async function start(token, user) {
  state.token = token;
  state.me = user;
  $("auth").classList.add("hidden");
  $("app").classList.remove("hidden");
  $("me-name").textContent = user.username;
  paintMe();
  $("btn-invites").classList.toggle("hidden", !user.owner);

  state.socket = io({ auth: { token } });
  wrapEmit(state.socket);
  bindSocket();
  if (!localStorage.getItem("perm")) $("perm").showModal();
  await loadUsers();
  loadStories();
  loadUnread();
  setupPush();
  const jm = location.hash.match(/^#join=(\w+)/);
  if (jm) {
    const g = await post("join/" + jm[1], {});
    history.replaceState(null, "", "/");
    if (g) { await loadUsers(); alert(t("Joined") + ": " + g.name); }
  }
}

async function loadUsers() {
  state.users = await api("users");
  state.groups = await api("groups");
  try { state.last = await api("last"); } catch (e) {}
  renderContacts();
}

function renderContacts() {
  const total = Object.values(state.unread).reduce((a, b) => a + b, 0);
  document.title = (total ? "(" + total + ") " : "") + "Shadow";
  $("btn-archive").classList.toggle("hidden", !archived().length && !state.showArchived);
  $("btn-archive").classList.toggle("on", !!state.showArchived);
  const ul = $("contacts");
  ul.innerHTML = "";
  $("no-contacts").classList.toggle("hidden", state.users.length > 0);
  const q = ($("search").value || "").toLowerCase();
  allChats().filter((u) => u.username.toLowerCase().includes(q) && archived().includes(u.id) === !!state.showArchived).forEach((u) => {
    const li = document.createElement("li");
    li.className = "contact" + (state.active === u.id ? " active" : "") + (state.unread[u.id] ? " unread" : "");
    const unread = state.unread[u.id] || 0;
    const l = state.last[u.id];
    li.innerHTML =
      '<div class="avatar" style="' + (u.avatar ? "" : "background:" + avBg(u.username)) + '">' + (u.avatar ? '<img src="' + esc(u.avatar) + '" alt="">' : esc(u.username[0].toUpperCase())) + (u.group ? "" : '<span class="dot' + (u.online ? " on" : "") + '"></span>') + "</div>" +
      '<div class="c-main"><div class="c-top"><span class="c-name">' + (pinned().includes(u.id) ? "\u{1F4CC} " : "") + esc(u.username) + '</span><span class="c-time">' + (l ? fmtTime(l.time) : "") + "</span></div>" +
      '<div class="c-bot"><span class="c-prev">' + esc(preview(l)) + "</span>" + (unread ? '<span class="badge">' + unread + "</span>" : "") + "</div></div>";
    li.onclick = () => openChat(u.id);
    ul.appendChild(li);
  });
}

// ---------- chat ----------
async function openChat(id) {
  state.active = id;
  state.filter = "";
  recReset();
  state.unread[id] = 0;
  const peer = allChats().find((u) => u.id === id);
  $("placeholder").classList.add("hidden");
  $("chat-pane").classList.remove("hidden");
  $("app").classList.add("in-chat");
  $("peer-name").textContent = peer.username;
  $("peer-av").style.background = peer.avatar ? "" : avBg(peer.username);
  $("peer-av").innerHTML = peer.avatar ? '<img src="' + esc(peer.avatar) + '" alt="">' : esc(peer.username[0].toUpperCase());
  applyTheme();
  updateTtlNote();
  const gg = state.groups.find((x) => x.id === id);
  $("btn-call").classList.toggle("hidden", !!gg);
  $("btn-vcall").classList.toggle("hidden", !!gg);
  document.querySelector(".composer").classList.toggle("hidden", !!gg && gg.type === "channel" && !(gg.admins || []).includes(state.me.id));
  updatePeerStatus();
  state.messages[id] = await api("messages/" + id);
  renderMessages();
  renderContacts();
  state.socket.emit("read", { from: id });
  markRead(id);
  state.more[id] = state.messages[id].length >= 50;
  restoreDraft(id);
  $("text").focus();
}
$("btn-back").onclick = () => { state.active = null; $("app").classList.remove("in-chat"); renderContacts(); };

function updatePeerStatus(typing) {
  const peer = state.users.find((u) => u.id === state.active);
  if (!peer) { $("peer-status").textContent = "group"; return; }
  $("peer-status").textContent = typing ? t("typing...") : peer.online ? t("online") : peer.lastSeen ? t("last seen") + " " + new Date(peer.lastSeen).toLocaleString([], { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" }) : t("offline");
}

function tick(m) {
  if (m.from !== state.me.id) return "";
  if (m.pending) return ' <span class="tick">&#128339;</span>';
  if (m.status === "read") return ' <span class="tick read">&#10003;&#10003;</span>';
  if (m.status === "delivered") return " <span class=\"tick\">&#10003;&#10003;</span>";
  return ' <span class="tick">&#10003;</span>';
}

function bubble(m) {
  if (m.system) { const n = document.createElement("div"); n.className = "sysmsg"; n.dataset.id = m.id; n.textContent = sysText(m); return n; }
  const d = document.createElement("div");
  d.className = "msg" + (m.from === state.me.id ? " mine" : "");
  d.dataset.id = m.id;
  const t = new Date(m.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const inGroup = state.groups.some((g) => g.id === m.to);
  const who = inGroup && m.from !== state.me.id ? "<b>" + esc((state.users.find((u) => u.id === m.from) || {}).username || "?") + "</b><br>" : "";
  const q = m.replyTo && (state.messages[state.active] || []).find((x) => x.id === m.replyTo);
  let body = q ? '<span class="quote">' + esc(q.deleted ? "Deleted message" : q.enc ? "Locked message" : q.text || (q.file ? q.file.name : "Location")) + "</span>" : "";
  body += m.deleted ? "<i>Message deleted</i>" : m.enc ? (m.text ? "<i>&#128274; Encrypted message</i>" : "") : esc(m.text).replace(/@(\w{3,20})/g, '<b class="mention">@$1</b>');
  if (m.once) body += "<br>" + onceHtml(m);
  if (m.file && !m.once) {
    const u = esc(m.file.url), ty = m.file.type;
    body += m.enc ? "<br><i>&#128274; Encrypted file</i>"
      : kind(m.file) === "image" ? '<br><img src="' + u + '" alt="">'
      : ty.startsWith("audio/") ? '<br><audio controls src="' + u + '"></audio>'
      : kind(m.file) === "video" ? '<br><video controls src="' + u + '"></video>'
      : '<br><a href="' + u + '" target="_blank">' + esc(m.file.name) + "</a>";
  }
  if (m.loc) body += locHtml(m);
  const rx = Object.values(m.reactions || {}).join("");
  d.innerHTML = who + body + (rx ? '<span class="rx">' + rx + "</span>" : "") + '<span class="meta">' + (stars().includes(m.id) ? "\u2B50 " : "") + (m.expires ? "\u23F3 " : "") + (m.edited ? "edited " : "") + t + (inGroup ? "" : tick(m)) + "</span>";
  return d;
}

function renderMessages() {
  const box = $("messages");
  box.innerHTML = "";
  let lastDay = "";
  (state.messages[state.active] || []).filter((m) => (!state.starOnly || stars().includes(m.id)) && (!state.filter || (!m.enc && (m.text || "").toLowerCase().includes(state.filter)))).forEach((m) => {
    const day = new Date(m.time).toDateString();
    if (day !== lastDay) { lastDay = day; const sep = document.createElement("div"); sep.className = "daysep"; sep.textContent = dayLabel(m.time); box.appendChild(sep); }
    box.appendChild(bubble(m));
  });
  box.scrollTop = box.scrollHeight;
}
function dayLabel(ts) {
  const d = new Date(ts), n = new Date(), y = new Date(Date.now() - 864e5);
  return d.toDateString() === n.toDateString() ? t("Today") : d.toDateString() === y.toDateString() ? t("Yesterday") : d.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" });
}

function send() {
  const input = $("text"), text = input.value.trim();
  if (!text || !state.active) return;
  const to = state.active, cid = "c" + Date.now() + Math.random().toString(36).slice(2, 8);
  const pm = { id: cid, cid, from: state.me.id, to, text, time: Date.now(), status: "sent", pending: true, replyTo: state.replyTo || null };
  (state.messages[to] = state.messages[to] || []).push(pm); // shows at once with a clock until the server confirms
  const box = $("messages");
  touchLast(to, pm);
  box.appendChild(bubble(pm));
  box.scrollTop = box.scrollHeight;
  state.socket.emit("private message", { to, text, replyTo: state.replyTo, cid });
  clearReply();
  input.value = "";
  saveDraft();
}
$("btn-send").onclick = send;
$("text").addEventListener("keydown", (e) => { if (e.key === "Enter") send(); });
$("text").addEventListener("input", () => {
  if (state.active) state.socket.emit("typing", { to: state.active });
});

// ---------- socket events ----------
function bindSocket() {
  const s = state.socket;

  s.on("private message", (m) => {
    const peerId = m.from === state.me.id || state.groups.some((g) => g.id === m.to) ? m.to : m.from;
    (state.messages[peerId] = state.messages[peerId] || []);
    const pi = m.cid ? state.messages[peerId].findIndex((x) => x.pending && x.cid === m.cid) : -1;
    if (pi > -1) { // my own message confirmed by the server
      state.messages[peerId][pi] = m;
      const el = document.querySelector('.msg[data-id="' + m.cid + '"]');
      if (el) el.replaceWith(bubble(m));
      return;
    }
    if (state.messages[peerId].some((x) => x.id === m.id)) return;
    if (m.from !== state.me.id && !m.system) setArchived(peerId, false);
    state.messages[peerId].push(m);
    if (m.system) onSystem(peerId, m); else touchLast(peerId, m);
    if (!m.system && m.from !== state.me.id && document.hidden && window.Notification && Notification.permission === "granted" && !JSON.parse(localStorage.getItem("mutes") || "[]").includes(peerId))
      new Notification("Shadow", { body: m.text && !m.enc ? m.text : "New message" });

    if (peerId === state.active) {
      const box = $("messages");
      box.appendChild(bubble(m));
      box.scrollTop = box.scrollHeight;
      if (m.from !== state.me.id) { s.emit("read", { from: peerId }); markRead(peerId); }
    } else if (m.from !== state.me.id && !m.system) {
      state.unread[peerId] = (state.unread[peerId] || 0) + 1;
      renderContacts();
    }
  });

  s.on("status", ({ ids, status }) => {
    Object.values(state.messages).forEach((list) =>
      list.forEach((m) => { if (ids.includes(m.id)) m.status = status; })
    );
    if (state.active) renderMessages();
  });

  s.on("presence", async ({ userId, online, lastSeen }) => {
    const u = state.users.find((x) => x.id === userId);
    if (u) { u.online = online; if (lastSeen) u.lastSeen = lastSeen; renderContacts(); updatePeerStatus(); }
    else if (userId !== state.me.id) await loadUsers(); // a brand new user appeared
  });

  s.on("deleted", ({ id }) => {
    Object.values(state.messages).forEach((list) => list.forEach((m) => { if (m.id === id) { m.deleted = true; m.text = ""; m.file = null; } }));
    if (state.active) renderMessages();
  });

  s.on("group", (g) => {
    const i = state.groups.findIndex((x) => x.id === g.id);
    if (i > -1) state.groups[i] = g; else state.groups.push(g);
    renderContacts();
    if (state.active === g.id) { applyTheme(); updateTtlNote(); }
  });

  s.on("updated", (m) => {
    Object.values(state.messages).forEach((l) => { const i = l.findIndex((x) => x.id === m.id); if (i > -1) l[i] = m; });
    const el = document.querySelector('.msg[data-id="' + m.id + '"]');
    if (el) el.replaceWith(bubble(m)); else if (state.active) renderMessages();
  });
  s.on("gone", ({ id }) => {
    Object.keys(state.messages).forEach((k) => (state.messages[k] = state.messages[k].filter((x) => x.id !== id)));
    if (state.active) renderMessages();
  });

  s.on("gone-group", ({ id }) => {
    state.groups = state.groups.filter((g) => g.id !== id);
    if (state.active === id) { state.active = null; $("chat-pane").classList.add("hidden"); $("placeholder").classList.remove("hidden"); $("app").classList.remove("in-chat"); }
    renderContacts();
  });

  s.on("status-update", () => loadStories());
  s.on("profile", (u) => {
    if (u.id === state.me.id) { state.me = { ...state.me, ...u }; $("me-name").textContent = u.username; paintMe(); }
    else { const i = state.users.findIndex((x) => x.id === u.id); if (i > -1) state.users[i] = { ...state.users[i], ...u }; else state.users.push(u); }
    if (state.active === u.id) $("peer-name").textContent = u.username;
    renderContacts(); loadStories();
    if (state.active) renderMessages();
  });
  s.on("user-removed", async () => {
    await loadUsers();
    if (state.active && !allChats().some((c) => c.id === state.active)) { state.active = null; $("chat-pane").classList.add("hidden"); $("placeholder").classList.remove("hidden"); $("app").classList.remove("in-chat"); }
    loadStories();
  });

  s.on("call:offer", ({ from, name, sdp, video, callId }) => {
    if (call.id) return s.emit("call:end", { callId, reason: "busy" });
    Object.assign(call, { id: callId, peer: from, video, incoming: sdp, queue: [] });
    showCall(t(video ? "Incoming video call" : "Incoming voice call"), name, true);
    startRing();
    if (document.hidden && window.Notification && Notification.permission === "granted") new Notification(name, { body: t(video ? "Incoming video call" : "Incoming voice call") });
  });
  s.on("call:answer", async ({ callId, sdp }) => {
    if (callId !== call.id || !call.pc) return;
    await call.pc.setRemoteDescription(sdp);
    for (const c of call.queue) await call.pc.addIceCandidate(c).catch(() => {});
    call.queue = [];
  });
  s.on("call:ice", ({ callId, candidate }) => {
    if (callId !== call.id) return;
    if (call.pc && call.pc.remoteDescription) call.pc.addIceCandidate(candidate).catch(() => {}); else call.queue.push(candidate);
  });
  s.on("call:end", ({ callId, reason }) => { if (callId === call.id) endCall(true, reason); });

  s.on("typing", ({ from }) => {
    if (from !== state.active) return;
    updatePeerStatus(true);
    clearTimeout(state.typingTimer);
    state.typingTimer = setTimeout(() => updatePeerStatus(false), 1500);
  });
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ---------- groups, files, delete ----------
function allChats() {
  return [...state.groups.map((g) => ({ id: g.id, username: (g.hidden ? "\u{1F512} " : g.type === "channel" ? "\u{1F4E2} " : "") + g.name, group: true })), ...state.users].sort((a, b) => (pinned().includes(b.id) - pinned().includes(a.id)) || ((state.last[b.id] || {}).time || 0) - ((state.last[a.id] || {}).time || 0));
}
$("btn-group").onclick = async () => {
  const name = prompt("Group name");
  if (!name) return;
  const members = prompt("Usernames to add, separated by commas");
  if (!members) return;
  const res = await fetch("/api/groups", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + state.token },
    body: JSON.stringify({ name, members: members.split(",") })
  });
  if (!res.ok) alert((await res.json()).error);
};
$("btn-attach").onclick = () => $("file").click();
const isMedia = (f) => ["image", "video"].includes(kind(f));
function askOnce() { // resolves true (view once), false (normal) or null (cancelled)
  return new Promise((res) => {
    showMenu([
      ["\u{1F441} " + t("View once (opens one time, then deleted)"), () => res(true)],
      ["\u{1F4F7} " + t("Send normally"), () => res(false)]
    ]);
    $("menu").addEventListener("close", () => res(null), { once: true });
  });
}
$("file").onchange = async () => {
  const files = [...$("file").files], to = state.active;
  $("file").value = "";
  if (!files.length || !to) return;
  let once = false;
  if (!state.groups.some((g) => g.id === to) && files.some((f) => isMedia({ type: f.type, name: f.name }))) {
    once = await askOnce();
    if (once === null) return;
  }
  for (const f of files) {
    toast(t("Sending") + " " + f.name + "...");
    const r = await upload(f, f.name, f.type);
    toast("");
    if (r) state.socket.emit("private message", { to, text: files.length === 1 ? $("text").value.trim() : "", file: r, once: once && isMedia(r) });
  }
  $("text").value = "";
};
$("messages").addEventListener("click", (e) => {
  const a = e.target.closest(".del");
  if (a) { e.preventDefault(); state.socket.emit("delete", { id: a.dataset.id }); }
});

// ---------- crypto (AES-GCM, key from password via PBKDF2) ----------
const b64 = (u) => btoa(String.fromCharCode(...u));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function deriveKey(pw, salt) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(pw), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: 200000, hash: "SHA-256" }, k, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}
async function enc(pw, bytes) {
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const c = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await deriveKey(pw, salt), bytes));
  const out = new Uint8Array(28 + c.length);
  out.set(salt); out.set(iv, 16); out.set(c, 28);
  return out;
}
async function dec(pw, bytes) {
  bytes = new Uint8Array(bytes);
  return new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: bytes.slice(16, 28) }, await deriveKey(pw, bytes.slice(0, 16)), bytes.slice(28)));
}

let vaultCheck;
async function askPassword() {
  if (vaultCheck === undefined) vaultCheck = await api("vault");
  if (!vaultCheck) {
    const p1 = prompt("Create your Shadow password. It protects delete, download and encrypt, and it cannot be recovered if you forget it.");
    if (!p1) return null;
    if (p1.length < 6) { alert("Use at least 6 characters"); return null; }
    if (prompt("Type the password again") !== p1) { alert("Passwords do not match"); return null; }
    const check = b64(await enc(p1, new TextEncoder().encode("shadow-ok")));
    await fetch("/api/vault", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + state.token }, body: JSON.stringify({ check }) });
    vaultCheck = check;
    return p1;
  }
  for (let i = 0; i < 3; i++) {
    const p = prompt(i ? "Wrong password. Try again" : "Enter your Shadow password");
    if (!p) return null;
    try { await dec(p, unb64(vaultCheck)); return p; } catch (e) {}
  }
  alert("Too many wrong attempts");
  return null;
}
async function protect(fn) {
  if (!window.crypto || !crypto.subtle) return alert(t("Encryption needs a secure connection (https or localhost). Open Shadow through your https address."));
  let pw;
  try { pw = await askPassword(); } catch (e) { return alert("Could not check your password: " + e.message); }
  if (!pw) return;
  try { await fn(pw); } catch (e) { alert("Failed: " + e.message + ". If this was encrypted, it may use a different password."); }
}
async function upload(body, name, type) {
  if (typeof File !== "undefined" && body instanceof File) { body = await prepImage(body); name = body.name; type = body.type; }
  const res = await fetch("/api/upload", { method: "POST", headers: { Authorization: "Bearer " + state.token, "x-filename": encodeURIComponent(name), "Content-Type": type || "application/octet-stream" }, body });
  if (!res.ok) { let e = ""; try { e = (await res.json()).error; } catch (x) {} alert("Upload failed (" + res.status + ")" + (e ? ": " + e : "")); return null; }
  return res.json();
}
const fetchBytes = async (url) => new Uint8Array(await (await fetch(url)).arrayBuffer());

async function download(m, pw) {
  let blob, name = "message.txt";
  if (m.file) {
    const bytes = await fetchBytes(m.file.url);
    name = m.file.name;
    if (m.enc) { blob = new Blob([await unlockBytes(pw, bytes)]); name = name.replace(/\.enc$/, ""); }
    else blob = new Blob([bytes], { type: m.file.type });
  } else {
    blob = new Blob([m.enc ? new TextDecoder().decode(await unlockBytes(pw, unb64(m.text))) : m.text], { type: "text/plain" });
  }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
async function encryptMsg(m, pw) {
  const out = { id: m.id, enc: true };
  if (m.text) out.text = b64(await enc(pw, new TextEncoder().encode(m.text)));
  if (m.file) {
    out.file = await upload(await enc(pw, await fetchBytes(m.file.url)), m.file.name + ".enc", "application/octet-stream");
    if (!out.file) return;
    out.file.ot = m.file.type;
  }
  state.socket.emit("update", out);
}

// ---------- message menu (tap a message 3 times, or right-click) ----------
function findMsg(id) { for (const l of Object.values(state.messages)) { const m = l.find((x) => x.id === id); if (m) return m; } }
function openMenu(id) {
  const m = findMsg(id);
  if (!m || m.deleted || m.pending) return;
  const mine = m.from === state.me.id, box = $("menu-items");
  box.innerHTML = "";
  const add = (label, fn) => { const b = document.createElement("button"); b.textContent = label; b.onclick = () => { $("menu").close(); fn(); }; box.appendChild(b); };
  const row = document.createElement("div");
  row.className = "rxrow";
  ["\u{1F44D}", "\u2764\uFE0F", "\u{1F602}", "\u{1F62E}", "\u{1F622}", "\u{1F64F}"].forEach((e) => {
    const b = document.createElement("button"); b.className = "ghost"; b.textContent = e;
    b.onclick = () => { $("menu").close(); state.socket.emit("react", { id, emoji: e }); };
    row.appendChild(b);
  });
  box.appendChild(row);
  add(t("Reply"), () => { state.replyTo = id; showReply(m); $("text").focus(); });
  if (mine && m.text && !m.enc && !m.file) add(t("Edit"), () => { const t = prompt("Edit message", m.text); if (t && t.trim()) state.socket.emit("update", { id, text: t.trim() }); });
  if ((m.text || m.file || m.loc) && !m.enc) add(t("Forward"), () => showMenu(allChats().map((c) => [c.username, () => state.socket.emit("private message", { to: c.id, text: m.text || "", file: m.file || undefined, loc: m.loc ? { lat: m.loc.lat, lng: m.loc.lng, acc: m.loc.acc } : undefined })])));
  if (m.text && !m.enc) add(t("Copy"), () => navigator.clipboard && navigator.clipboard.writeText(m.text));
  add(t(stars().includes(id) ? "Unstar" : "Star"), () => {
    const st = new Set(stars()); st.has(id) ? st.delete(id) : st.add(id);
    localStorage.setItem("stars", JSON.stringify([...st]));
    const el = document.querySelector('.msg[data-id="' + id + '"]'); if (el) el.replaceWith(bubble(m));
  });
  if (!mine) add(t("Report"), async () => { if (confirm(t("Report this message to the owner?")) && await post("report", { messageId: id })) alert(t("Reported. Thank you.")); });
  if (m.text || m.file) add(t("Download"), () => protect((pw) => download(m, pw)));
  if (m.enc) add(t("Decrypt"), () => protect((pw) => decryptMsg(m, pw)));
  if (mine && !m.enc && (m.text || m.file)) add(t("Encrypt"), () => protect((pw) => encryptMsg(m, pw)));
  add(t("Delete permanently"), () => { if (confirm("Delete this permanently? This cannot be undone.")) state.socket.emit("purge", { id }); });
  $("menu").showModal();
}
$("menu-close").onclick = () => $("menu").close();
let taps = { id: null, n: 0, t: 0 };
$("messages").addEventListener("click", (e) => {
  const ob = e.target.closest(".once-btn");
  if (ob) { openOnce(ob.dataset.id); return; }
  const im = e.target.closest(".msg img");
  if (im) { $("viewer-img").src = im.src; $("viewer").showModal(); return; }
  if (e.target.closest("a,audio,video")) return;
  const el = e.target.closest(".msg");
  if (!el) return;
  const now = Date.now();
  taps = taps.id === el.dataset.id && now - taps.t < 700 ? { id: taps.id, n: taps.n + 1, t: now } : { id: el.dataset.id, n: 1, t: now };
  if (taps.n >= 3) { taps.n = 0; openMenu(el.dataset.id); }
});
$("messages").addEventListener("contextmenu", (e) => {
  const el = e.target.closest(".msg");
  if (el) { e.preventDefault(); openMenu(el.dataset.id); }
});
function showReply(m) {
  $("reply-text").textContent = "Replying to: " + (m.enc ? "locked message" : m.text || (m.file ? m.file.name : "location"));
  $("reply-bar").classList.remove("hidden");
}
function clearReply() { state.replyTo = null; $("reply-bar").classList.add("hidden"); }
$("reply-x").onclick = clearReply;

// ---------- voice notes, location, permissions ----------
let rec = null, recChunks = [], recBlob = null, recTimer = null, recStart = 0, recStream = null;
function recReset() {
  clearInterval(recTimer);
  if (rec && rec.state !== "inactive") { rec.onstop = null; rec.stop(); }
  if (recStream) recStream.getTracks().forEach((x) => x.stop());
  rec = recStream = recBlob = null; recChunks = [];
  $("rec-bar").classList.add("hidden");
  $("rec-audio").classList.add("hidden"); $("rec-audio").removeAttribute("src");
  ["rec-dot", "rec-time", "rec-stop"].forEach((id) => $(id).classList.remove("hidden"));
  $("rec-send").classList.add("hidden");
  $("rec-time").textContent = "0:00";
}
$("btn-voice").onclick = async () => {
  if (!state.active || rec || recBlob) return;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return alert(t("Voice recording needs a secure connection (https or localhost)."));
  try {
    recStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    rec = new MediaRecorder(recStream);
    rec.ondataavailable = (e) => { if (e.data.size) recChunks.push(e.data); };
    rec.onstop = () => {
      clearInterval(recTimer);
      recStream.getTracks().forEach((x) => x.stop());
      recBlob = new Blob(recChunks, { type: rec.mimeType || "audio/webm" });
      $("rec-audio").src = URL.createObjectURL(recBlob);
      ["rec-audio", "rec-send"].forEach((id) => $(id).classList.remove("hidden"));
      ["rec-dot", "rec-time", "rec-stop"].forEach((id) => $(id).classList.add("hidden"));
    };
    rec.start();
    recStart = Date.now();
    $("rec-bar").classList.remove("hidden");
    recTimer = setInterval(() => { const n = Math.floor((Date.now() - recStart) / 1000); $("rec-time").textContent = Math.floor(n / 60) + ":" + String(n % 60).padStart(2, "0"); }, 250);
  } catch (e) { recReset(); alert(t("Allow the microphone to record voice notes (needs HTTPS).")); }
};
$("rec-stop").onclick = () => { if (rec && rec.state !== "inactive") rec.stop(); };
$("rec-cancel").onclick = recReset;
$("rec-send").onclick = async () => {
  if (!recBlob) return;
  const type = recBlob.type, f = await upload(recBlob, "voice." + (type.includes("mp4") ? "m4a" : "webm"), type);
  if (f) state.socket.emit("private message", { to: state.active, text: "", file: f });
  recReset();
};
function toast(t) { $("toast").textContent = t; $("toast").classList.toggle("hidden", !t); }
// Waits for the best position (no popups). quick = use the first reading.
function locFix(done, ms, quick) {
  let best = null, over = false, w, tm;
  const end = () => { if (over) return; over = true; navigator.geolocation.clearWatch(w); clearTimeout(tm); toast(""); $("toast").onclick = null; done(best); };
  w = navigator.geolocation.watchPosition((p) => {
    if (!best || p.coords.accuracy < best.accuracy) best = p.coords;
    toast(t("Finding your location") + ": \u00B1" + Math.round(best.accuracy) + " m. " + t("Tap to send now."));
    $("toast").onclick = end;
    if (quick || best.accuracy <= 5) end();
  }, (err) => {
    if (over) return;
    over = true; clearTimeout(tm); navigator.geolocation.clearWatch(w); toast("");
    alert(t("Allow location access (needs HTTPS or localhost)") + ": " + err.message);
  }, { enableHighAccuracy: true, maximumAge: 0, timeout: 20000 });
  tm = setTimeout(end, ms);
}
let live = null;
function startLive(minutes) {
  if (live) stopLive();
  const to = state.active, until = Date.now() + minutes * 60000;
  locFix((c) => {
    if (!c) return alert(t("Could not get your location"));
    live = { until, last: 0, id: null };
    state.socket.emit("private message", { to, text: "", loc: { lat: c.latitude, lng: c.longitude, acc: c.accuracy, live: true, until } }, (id) => { if (live) live.id = id; });
    live.watch = navigator.geolocation.watchPosition((p) => {
      if (!live || !live.id || Date.now() - live.last < 5000) return;
      live.last = Date.now();
      state.socket.emit("live", { id: live.id, lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy });
    }, () => {}, { enableHighAccuracy: true, maximumAge: 0 });
    live.timer = setTimeout(stopLive, minutes * 60000);
    $("live-bar").textContent = t("Sharing live location. Tap to stop.");
    $("live-bar").classList.remove("hidden");
  }, 15000, true);
}
function stopLive() {
  if (!live) return;
  navigator.geolocation.clearWatch(live.watch); clearTimeout(live.timer);
  if (live.id) state.socket.emit("live-stop", { id: live.id });
  live = null;
  $("live-bar").classList.add("hidden");
}
$("live-bar").onclick = stopLive;
$("btn-loc").onclick = () => {
  if (!state.active) return;
  if (!navigator.geolocation) return alert(t("Location is not available on this device"));
  const items = [
    [t("Send current location"), () => locFix((c) => {
      if (!c) return alert(t("Could not get your location"));
      if (c.accuracy > 1000 && !confirm(t("Your device could only find your approximate area") + " (\u00B1" + Math.round(c.accuracy / 1000) + " km). " + t("Without a GPS signal this can be far from where you are. Use a phone outdoors with precise location on. Send anyway?"))) return;
      state.socket.emit("private message", { to: state.active, text: "", loc: { lat: c.latitude, lng: c.longitude, acc: c.accuracy } });
    }, 12000)],
    [t("Share live location for 15 minutes"), () => startLive(15)],
    [t("Share live location for 1 hour"), () => startLive(60)],
    [t("Share live location for 8 hours"), () => startLive(480)]
  ];
  if (live) items.push([t("Stop live location"), stopLive]);
  showMenu(items);
};
$("perm-ok").onclick = async () => {
  localStorage.setItem("perm", "1"); $("perm").close();
  try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (e) {}
  try { if (window.Notification) await Notification.requestPermission(); } catch (e) {}
  setupPush();
};
$("perm-no").onclick = () => $("perm").close();

// ---------- decrypt ----------
async function unlockBytes(pw, bytes) {
  try { return await dec(pw, bytes); }
  catch (e) {
    const p = prompt(t("Enter the password used to encrypt this"));
    if (!p) throw new Error("cancelled");
    return dec(p, bytes);
  }
}
async function decryptMsg(m, pw) {
  if (m.from !== state.me.id) { // recipients get a decrypted copy on their own device
    if (m.file) return download(m, pw);
    return alert(new TextDecoder().decode(await unlockBytes(pw, unb64(m.text))));
  }
  const out = { id: m.id, dec: true };
  if (m.text) out.text = new TextDecoder().decode(await unlockBytes(pw, unb64(m.text)));
  if (m.file) {
    const bytes = await unlockBytes(pw, await fetchBytes(m.file.url));
    out.file = await upload(bytes, m.file.name.replace(/\.enc$/, ""), m.file.ot || "application/octet-stream");
    if (!out.file) return;
  }
  state.socket.emit("update", out);
}

// ---------- helpers, menus, themes ----------
async function post(path, body) {
  const r = await fetch("/api/" + path, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + state.token }, body: JSON.stringify(body) });
  const d = await r.json();
  if (!r.ok) { alert(d.error); return null; }
  return d;
}
function showMenu(items) {
  const box = $("menu-items");
  box.innerHTML = "";
  items.forEach(([label, fn]) => { const b = document.createElement("button"); b.textContent = label; b.onclick = () => { $("menu").close(); fn(); }; box.appendChild(b); });
  $("menu").showModal();
}
const THEMES = { pine: ["#7c6cff", "#eef0fb"], ocean: ["#1e90ff", "#e7f2fc"], plum: ["#c04cf0", "#f6eafd"], ember: ["#ff7a45", "#fdf0e7"], night: ["#5865f2", "#1c2033"] };
const THEME_LABEL = { pine: "App color", ocean: "Ocean", plum: "Orchid", ember: "Sunset", night: "Midnight" };
function applyTheme() {
  const g = state.groups.find((x) => x.id === state.active);
  const k = (g ? g.theme : localStorage.getItem("theme:" + state.active)) || "pine";
  const [mine, wall] = THEMES[k] || THEMES.pine;
  if (k === "pine") { $("chat-pane").style.removeProperty("--mine"); $("chat-pane").style.removeProperty("--wall"); } // follows the app colour
  else { $("chat-pane").style.setProperty("--mine", mine); $("chat-pane").style.setProperty("--wall", wall); }
  const bg = g ? g.bg : localStorage.getItem("bg:" + state.active), p = $("chat-pane");
  p.style.backgroundImage = bg ? 'linear-gradient(rgba(8,10,22,.38),rgba(8,10,22,.38)), url("' + bg + '")' : "";
  p.style.backgroundSize = "cover";
  p.style.backgroundPosition = "center";
}
$("btn-opts").onclick = () => {
  const g = state.groups.find((x) => x.id === state.active), admin = g && (g.admins || []).includes(state.me.id);
  const items = [[t("Theme"), () => {
    if (g && !admin) return alert(t("Only admins can change the group theme"));
    showMenu([[t("Photo background"), () => $("bgfile").click()], [t("Remove photo background"), () => setBg("")], ...Object.keys(THEMES).map((k) => [THEME_LABEL[k] || k, async () => {
      if (g) await post("groups/" + g.id + "/theme", { theme: k });
      else { localStorage.setItem("theme:" + state.active, k); applyTheme(); }
    }])]);
  }]];
  const cid = state.active, pins = pinned(), mutes = JSON.parse(localStorage.getItem("mutes") || "[]");
  const toggle = (key, arr) => { const s = new Set(arr); s.has(cid) ? s.delete(cid) : s.add(cid); localStorage.setItem(key, JSON.stringify([...s])); renderContacts(); };
  items.unshift([t(pins.includes(cid) ? "Unpin chat" : "Pin chat"), () => toggle("pins", pins)]);
  items.unshift([t(mutes.includes(cid) ? "Unmute" : "Mute"), () => toggle("mutes", mutes)]);
  items.unshift([t("Search in chat"), () => { state.filter = (prompt(t("Search this chat (leave empty to clear)")) || "").toLowerCase(); renderMessages(); }]);
  items.push([t(archived().includes(cid) ? "Unarchive chat" : "Archive chat"), () => toggle("archived", archived())]);
  items.push([t(state.starOnly ? "Show all messages" : "Show starred messages"), () => { state.starOnly = !state.starOnly; renderMessages(); }]);
  items.push([t("Disappearing messages"), () => showMenu([[t("Off"), 0], [ttlLabel(60), 60], [ttlLabel(1440), 1440], [ttlLabel(10080), 10080]].map(([label, m]) => [label, async () => { const r = await post("ttl", { chat: cid, minutes: m }); if (r) { state.me = { ...state.me, ...r }; updateTtlNote(); } }]))]);
  items.push([t("Clear chat"), async () => { if (confirm(t("Clear this chat for you?")) && await post("clear", { chat: cid })) { state.messages[cid] = []; renderMessages(); } }]);
  if (!g) { const blocked = (state.me.blocked || []).includes(cid); items.push([t(blocked ? "Unblock" : "Block"), async () => { const r = await post("block", { id: cid, block: !blocked }); if (r) state.me = { ...state.me, ...r }; }]); }
  if (g) {
    items.push([t("Members"), () => openGroupMembers(g, admin)]);
    items.push([t("Leave group"), async () => { if (confirm(t("Leave this group?"))) await post("groups/" + g.id + "/leave", {}); }]);
    items.push([t("Copy invite link"), () => {
      const l = location.origin + "/#join=" + g.invite;
      (navigator.clipboard ? navigator.clipboard.writeText(l).then(() => alert(t("Link copied"))) : Promise.reject()).catch(() => prompt("Invite link", l));
    }]);
    if (admin) {
      items.push([t("Add members"), () => { const x = prompt(t("Usernames to add, separated by commas")); if (x) post("groups/" + g.id + "/members", { members: x.split(",") }); }]);
      items.push([g.hidden ? t("Make visible again") : t("Make secret"), async () => {
        const pw = prompt(g.hidden ? t("Enter the group's secret password") : t("Set a secret password. Members will need it to open this group."));
        if (pw) await post("groups/" + g.id + "/hide", { password: pw });
      }]);
    }
  }
  showMenu(items);
};
$("btn-secret").onclick = async () => {
  const pw = prompt(t("Secret group password"));
  if (!pw) return;
  const r = await post("secret/open", { password: pw });
  if (!r) return;
  r.forEach((g) => { const i = state.groups.findIndex((x) => x.id === g.id); if (i > -1) state.groups[i] = g; else state.groups.push(g); });
  renderContacts();
};
$("btn-channel").onclick = async () => {
  const name = prompt(t("Channel name"));
  if (name && await post("groups", { name, members: [], type: "channel" })) alert(t("Channel created. Share its invite link from Options."));
};

// ---------- owner: invite codes ----------
$("btn-invites").onclick = async () => {
  const list = await api("invites");
  const items = [[t("New invite code"), async () => {
    const note = prompt(t("Who is this code for? (a name to help you remember)"));
    if (note === null) return;
    const inv = await post("invites", { note });
    if (inv) { try { await navigator.clipboard.writeText(inv.code); } catch (e) {} prompt(t("Give this one-time code to the new user"), inv.code); }
  }]];
  list.slice().reverse().forEach((i) => items.push([(i.note || "-") + " \u00B7 " + i.code + " \u00B7 " + (i.used ? "used by " + i.usedBy : "unused"), () => {
    if (i.used) return;
    showMenu([
      ["Copy code", () => navigator.clipboard && navigator.clipboard.writeText(i.code)],
      ["Delete code", () => fetch("/api/invites/" + i.id, { method: "DELETE", headers: { Authorization: "Bearer " + state.token } })]
    ]);
  }]));
  items.splice(1, 0, ["Members", openMembers], ["Reports", openReports]);
  showMenu(items);
};

// ---------- profile, members, search, update check ----------
$("search").oninput = renderContacts;
$("btn-profile").onclick = () => showMenu([
  [t("Change display name"), async () => { const v = prompt(t("New display name"), state.me.username); if (v !== null) { const r = await post("profile", { displayName: v }); if (r) state.me = { ...state.me, ...r }; } }],
  [t("Change username"), async () => { const v = prompt(t("New username (used to sign in)"), state.me.login || ""); if (v) { const r = await post("profile", { username: v }); if (r) state.me = { ...state.me, ...r }; } }],
  [t("Send feedback"), async () => { const x = prompt(t("Describe the problem or idea")); if (x && await post("report", { feedback: x })) alert(t("Thank you!")); }],
  [t("Export my data"), exportData],
  [t("Log out of all devices"), async () => { if (confirm(t("Log out of every device?")) && await post("logout-all", {})) { localStorage.removeItem("token"); location.reload(); } }],
  [t("Delete my account"), async () => {
    const pw = prompt(t("Type your password to delete your account permanently"));
    if (pw && confirm(t("This cannot be undone. Delete your account and messages?")) && await post("account/delete", { password: pw })) { localStorage.removeItem("token"); location.reload(); }
  }],
  [t("Change photo"), () => $("pfile").click()],
  [t("App color"), openColors],
  [t("Dark mode"), () => { const d = document.documentElement.dataset.theme === "dark"; document.documentElement.dataset.theme = d ? "light" : "dark"; localStorage.setItem("mode", d ? "light" : "dark"); }],
  [t("Change password"), async () => { const old = prompt(t("Current password")); if (!old) return; const nw = prompt(t("New password (8+ characters)")); if (!nw) return; const r = await post("password", { old, new: nw }); if (r) { state.token = r.token; localStorage.setItem("token", r.token); state.socket.auth.token = r.token; alert(t("Password changed")); } }]
]);
const pinned = () => JSON.parse(localStorage.getItem("pins") || "[]");
$("pfile").onchange = async () => {
  const f = $("pfile").files[0]; $("pfile").value = "";
  if (!f) return;
  const r = await upload(f, f.name, f.type);
  if (r) { const p = await post("profile", { avatar: r.url }); if (p) state.me = { ...state.me, ...p }; }
};
async function openMembers() {
  const users = await api("members");
  showMenu(users.length ? users.map((u) => [u.username + " (@" + u.login + ")" + (u.online ? " \u2022 online" : "") + (u.banned ? " (banned)" : ""), () => showMenu([[u.banned ? "Restore " + u.username : "Ban " + u.username, () => post("users/" + u.id + "/ban", { banned: !u.banned })], ["Set new password", async () => {
    const p = prompt("New password for " + u.username + " (8+ characters)");
    if (p && await post("users/" + u.id + "/reset", { password: p })) alert("Password changed. Tell " + u.username + " privately.");
  }], [
    "Remove " + u.username,
    async () => {
      if (!confirm("Remove " + u.username + " and delete their messages? This cannot be undone.")) return;
      await fetch("/api/users/" + u.id, { method: "DELETE", headers: { Authorization: "Bearer " + state.token } });
    }
  ]])]) : [["No other members yet", () => {}]]);
}
function kind(f) {
  const ty = f.type || "", n = (f.name || f.url || "").toLowerCase();
  if (ty.startsWith("image/") || /\.(jpe?g|png|gif|webp|bmp)$/.test(n)) return "image";
  if (ty.startsWith("video/") || /\.(mp4|webm|mov|3gp|mkv)$/.test(n)) return "video";
  return "file";
}
function face(s, name) {
  if (!s) return esc((name || "?")[0].toUpperCase());
  if (s.file) {
    const k = kind(s.file);
    if (k === "image") return '<img src="' + esc(s.file.url) + '" alt="">';
    if (k === "video") return '<video src="' + esc(s.file.url) + '#t=0.1" muted playsinline preload="metadata"></video>';
  }
  return esc(s.text.slice(0, 16)) || "&#128206;";
}
async function prepImage(f) { // shrink big phone photos before uploading
  if (!f.type.startsWith("image/") || /gif|svg/.test(f.type)) return f;
  try {
    const bmp = await createImageBitmap(f), k = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas");
    c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    const b = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.82));
    return b && b.size < f.size ? new File([b], f.name.replace(/\.\w+$/, "") + ".jpg", { type: "image/jpeg" }) : f;
  } catch (e) { return f; }
}
function locHtml(m) {
  const l = m.loc, at = l.at || m.time, on = l.live && Date.now() < l.until && Date.now() - at < 120000;
  const acc = l.acc ? " \u00B1" + (l.acc > 1000 ? Math.round(l.acc / 1000) + " km (approximate)" : Math.round(l.acc) + " m") : "";
  return "<br><b>" + (on ? "&#128308; Live location" : "&#128205; Location") + "</b>" + acc + "<br><small>" + new Date(at).toLocaleTimeString() + "</small><br>" +
    '<a href="https://www.openstreetmap.org/?mlat=' + l.lat + "&mlon=" + l.lng + "#map=18/" + l.lat + "/" + l.lng + '" target="_blank" rel="noopener">OpenStreetMap</a> &middot; ' +
    '<a href="https://www.google.com/maps?q=' + l.lat + "," + l.lng + '" target="_blank" rel="noopener">Google Maps</a>';
}
let loadedVersion = null;
async function checkVersion() {
  try {
    const v = (await (await fetch("/api/version", { cache: "no-store" })).json()).version;
    document.querySelectorAll(".ver").forEach((e) => (e.textContent = "Shadow v" + v.split("-")[0]));
    if (loadedVersion && v !== loadedVersion) {
      $("update").classList.remove("hidden");
      $("update-btn").onclick = async () => {
        try { (await caches.keys()).forEach((k) => caches.delete(k)); (await navigator.serviceWorker.getRegistrations()).forEach((r) => r.unregister()); } catch (e) {}
        location.reload();
      };
    }
    loadedVersion = loadedVersion || v;
  } catch (e) {}
}
checkVersion();
setInterval(checkVersion, 60000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) checkVersion(); });

// ---------- reliability, groups, moderation, extras ----------
const authHdr = () => ({ Authorization: "Bearer " + state.token });
const archived = () => JSON.parse(localStorage.getItem("archived") || "[]");
const stars = () => JSON.parse(localStorage.getItem("stars") || "[]");
function setArchived(id, on) {
  const s = new Set(archived()); on ? s.add(id) : s.delete(id);
  localStorage.setItem("archived", JSON.stringify([...s]));
}
$("btn-archive").onclick = () => { state.showArchived = !state.showArchived; renderContacts(); };
async function loadUnread() { try { state.unread = await api("unread"); renderContacts(); } catch (e) {} }
function markRead(id) { fetch("/api/read", { method: "POST", headers: { ...authHdr(), "Content-Type": "application/json" }, body: JSON.stringify({ chat: id }) }).catch(() => {}); }
const saveDraft = () => { if (state.active) localStorage.setItem("draft:" + state.active, $("text").value); };
const restoreDraft = (id) => { $("text").value = localStorage.getItem("draft:" + id) || ""; };
$("text").addEventListener("input", saveDraft);
$("messages").addEventListener("scroll", async (e) => { // load older messages when scrolling to the top
  const box = e.target, id = state.active;
  if (box.scrollTop > 40 || !id || !state.more[id] || state.loadingMore) return;
  state.loadingMore = true;
  try {
    const first = (state.messages[id] || [])[0];
    const older = await api("messages/" + id + "?before=" + (first ? first.time : Date.now()));
    state.more[id] = older.length >= 50;
    if (older.length && state.active === id) {
      const prev = box.scrollHeight;
      state.messages[id] = [...older, ...state.messages[id]];
      renderMessages();
      box.scrollTop = box.scrollHeight - prev;
    }
  } catch (x) {}
  state.loadingMore = false;
});
async function setupPush() { // notifications while the app is closed (https only)
  try {
    if (!state.token || !("serviceWorker" in navigator) || !("PushManager" in window) || !window.isSecureContext || !window.Notification || Notification.permission !== "granted") return;
    const { key } = await api("push-key");
    if (!key) return;
    const reg = await navigator.serviceWorker.ready;
    let sub = await reg.pushManager.getSubscription();
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: Uint8Array.from(atob(key.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0)) });
    await fetch("/api/push", { method: "POST", headers: { ...authHdr(), "Content-Type": "application/json" }, body: JSON.stringify({ subscription: sub.toJSON() }) });
  } catch (e) {}
}
async function openGroupMembers(g, admin) {
  const list = await api("groups/" + g.id + "/members");
  showMenu(list.map((u) => [u.name + (u.admin ? " (admin)" : ""), () => {
    if (!admin || u.id === state.me.id) return;
    showMenu([
      [u.admin ? "Remove admin" : "Make admin", () => post("groups/" + g.id + "/admin", { userId: u.id, admin: !u.admin })],
      ["Remove from group", () => { if (confirm("Remove " + u.name + " from the group?")) post("groups/" + g.id + "/remove", { userId: u.id }); }]
    ]);
  }]));
}
async function openReports() {
  const list = await api("reports"), del = (r) => fetch("/api/reports/" + r.id, { method: "DELETE", headers: authHdr() });
  showMenu(list.length ? list.map((r) => [(r.type === "feedback" ? "Feedback" : "Report") + " from " + r.byName + (r.targetName ? " about " + r.targetName : "") + ": " + r.text.slice(0, 60), () => showMenu([
    ...(r.target ? [["Ban " + r.targetName, async () => { if (confirm("Ban " + r.targetName + "?")) { await post("users/" + r.target + "/ban", { banned: true }); del(r); } }]] : []),
    ["Dismiss", () => del(r)]
  ])]) : [["No reports", () => {}]]);
}
async function exportData() {
  const r = await fetch("/api/export", { headers: authHdr() });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(await r.blob()); a.download = "shadow-export.json"; a.click();
}
const EMOJIS = Array.from("\u{1F600}\u{1F601}\u{1F602}\u{1F923}\u{1F60A}\u{1F607}\u{1F609}\u{1F60D}\u{1F618}\u{1F60B}\u{1F61B}\u{1F914}\u{1F610}\u{1F644}\u{1F60F}\u{1F62E}\u{1F622}\u{1F62D}\u{1F620}\u{1F621}\u{1F631}\u{1F634}\u{1F912}\u{1F637}\u{1F44D}\u{1F44E}\u{1F44F}\u{1F64F}\u{1F4AA}\u{1F44B}\u{1F91D}\u270C\uFE0F\u{1F44C}\u2764\uFE0F\u{1F494}\u{1F525}\u2728\u{1F389}\u{1F38A}\u{1F381}\u2B50\u{1F4AF}\u2705\u274C\u{1F440}\u{1F680}\u{1F31F}\u{1F338}\u{1F355}\u2615\u26BD\u{1F3B5}\u{1F4F7}\u{1F4A1}\u{1F4CC}");
$("emoji-grid").innerHTML = EMOJIS.map((e) => '<button class="ghost">' + e + "</button>").join("");
$("btn-emoji").onclick = () => $("emoji").showModal();
$("emoji-close").onclick = () => $("emoji").close();
$("emoji-grid").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const i = $("text"); i.setRangeText(b.textContent, i.selectionStart, i.selectionEnd, "end"); i.focus(); saveDraft();
});
$("viewer-close").onclick = () => $("viewer").close();

// ---------- status ----------
const EMO = ["\u2764\uFE0F", "\u{1F44D}", "\u{1F602}", "\u{1F62E}", "\u{1F622}", "\u{1F64F}"];
function card(s) {
  const counts = {}, likes = s.likes || {}, mine = likes[state.me.id];
  Object.values(likes).forEach((e) => (counts[e] = (counts[e] || 0) + 1));
  const media = s.file ? (kind(s.file) === "video" ? '<video controls playsinline src="' + esc(s.file.url) + '"></video>' : '<img src="' + esc(s.file.url) + '" alt="">') : "";
  return '<div class="st" style="background:' + esc(s.color) + '"><b>' + esc(s.name || "?") + "</b> <small>" + new Date(s.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + "</small><br>" + esc(s.text) + media +
    '<div class="strx">' + EMO.map((e) => '<button class="rxb' + (mine === e ? " on" : "") + '" data-sid="' + s.id + '" data-e="' + e + '">' + e + (counts[e] ? " " + counts[e] : "") + "</button>").join("") + "</div>" +
    '<div class="cm">' + (s.comments || []).map((c) => "<p><b>" + esc(c.name) + ":</b> " + esc(c.text) + "</p>").join("") + "</div>" +
    '<input class="cin" data-sid="' + s.id + '" placeholder="' + t("Add a comment") + '"></div>';
}
async function openStatus(uid) {
  state.viewing = uid || state.viewing || state.me.id;
  const all = await api("status"), list = all.filter((s) => s.from === state.viewing);
  list.forEach((s) => state.seen.add(s.id));
  localStorage.setItem("seen", JSON.stringify([...state.seen]));
  $("status-list").innerHTML = list.length ? list.map(card).join("") : "<p>" + t("No statuses in the last 24 hours") + "</p>";
  if (!$("status").open) $("status").showModal();
  renderStories(all);
}
state.seen = new Set(JSON.parse(localStorage.getItem("seen") || "[]"));
async function loadStories() { try { renderStories(await api("status")); } catch (e) {} }
function renderStories(all) {
  const by = {};
  all.forEach((s) => (by[s.from] = by[s.from] || []).push(s));
  const ids = [state.me.id, ...Object.keys(by).filter((id) => id !== state.me.id)];
  $("stories").innerHTML = ids.map((id) => {
    const list = by[id] || [], mine = id === state.me.id, name = mine ? t("Your status") : list[0].name;
    const latest = list[list.length - 1];
    const cls = !mine && list.some((s) => !state.seen.has(s.id)) ? " new" : list.length ? " seen" : "";
    return '<button class="bub" data-uid="' + id + '"><span class="ring' + cls + '"><span class="face" style="background:' + esc(latest ? latest.color : "#2f5d50") + '">' + face(latest, name) + "</span></span>" + (mine ? '<i class="plus">+</i>' : "") + "<small>" + esc(name) + "</small></button>";
  }).join("");
}
$("stories").onclick = (e) => { if (e.target.closest(".plus")) return openStatus(state.me.id); const b = e.target.closest(".bub"); if (b) openStory(b.dataset.uid); };
$("status-list").addEventListener("click", async (e) => {
  const b = e.target.closest(".rxb");
  if (b && await post("status/" + b.dataset.sid + "/react", { emoji: b.dataset.e })) openStatus();
});
$("status-list").addEventListener("keydown", async (e) => {
  if (e.key !== "Enter" || !e.target.classList.contains("cin") || !e.target.value.trim()) return;
  if (await post("status/" + e.target.dataset.sid + "/comment", { text: e.target.value })) openStatus();
});
const postStatus = (b) => post("status", { ...b, color: Object.values(THEMES)[Math.floor(Math.random() * 5)][0] });
$("status-close").onclick = () => $("status").close();
$("status-text").onclick = async () => { const x = prompt(t("Write your status")); if (x) { await postStatus({ text: x }); openStatus(state.me.id); } };
$("status-file").onclick = () => $("sfile").click();
$("sfile").onchange = async () => {
  const f = $("sfile").files[0]; $("sfile").value = "";
  if (!f) return;
  const r = await upload(f, f.name, f.type);
  if (r) { await postStatus({ text: "", file: r }); openStatus(state.me.id); }
};

// ---------- languages ----------
const L = {
  ar: { "Sign in": "تسجيل الدخول", "Create account": "إنشاء حساب", Username: "اسم المستخدم", Password: "كلمة المرور", "Sign out": "تسجيل الخروج", "New group": "مجموعة جديدة", "New channel": "قناة جديدة", Status: "الحالة", Secret: "سري", Attach: "إرفاق", Voice: "صوت", Location: "الموقع", Send: "إرسال", "Type a message": "اكتب رسالة", Cancel: "إلغاء", Back: "رجوع", "Pick a contact to start a conversation.": "اختر جهة اتصال لبدء المحادثة.", Options: "خيارات", Allow: "سماح", "Not now": "ليس الآن", Reply: "رد", Edit: "تعديل", Download: "تنزيل", Encrypt: "تشفير", Decrypt: "فك التشفير", "Delete permanently": "حذف نهائي", Theme: "السمة", "New version available": "يتوفر إصدار جديد", Update: "تحديث", "Add members": "إضافة أعضاء", "Copy invite link": "نسخ رابط الدعوة", "Text status": "حالة نصية", "Photo or video": "صورة أو فيديو", Close: "إغلاق", "Make secret": "جعلها سرية", "Make visible again": "إظهارها من جديد" },
  fr: { "Sign in": "Se connecter", "Create account": "Créer un compte", Username: "Nom d'utilisateur", Password: "Mot de passe", "Sign out": "Se déconnecter", "New group": "Nouveau groupe", "New channel": "Nouvelle chaîne", Status: "Statut", Secret: "Secret", Attach: "Joindre", Voice: "Vocal", Location: "Position", Send: "Envoyer", "Type a message": "Écrire un message", Cancel: "Annuler", Back: "Retour", "Pick a contact to start a conversation.": "Choisissez un contact pour commencer.", Options: "Options", Allow: "Autoriser", "Not now": "Plus tard", Reply: "Répondre", Edit: "Modifier", Download: "Télécharger", Encrypt: "Chiffrer", Decrypt: "Déchiffrer", "Delete permanently": "Supprimer définitivement", Theme: "Thème", "New version available": "Nouvelle version disponible", Update: "Mettre à jour", "Add members": "Ajouter des membres", "Copy invite link": "Copier le lien d'invitation", "Text status": "Statut texte", "Photo or video": "Photo ou vidéo", Close: "Fermer", "Make secret": "Rendre secret", "Make visible again": "Rendre visible" },
  es: { "Sign in": "Iniciar sesión", "Create account": "Crear cuenta", Username: "Usuario", Password: "Contraseña", "Sign out": "Cerrar sesión", "New group": "Nuevo grupo", "New channel": "Nuevo canal", Status: "Estado", Secret: "Secreto", Attach: "Adjuntar", Voice: "Voz", Location: "Ubicación", Send: "Enviar", "Type a message": "Escribe un mensaje", Cancel: "Cancelar", Back: "Atrás", "Pick a contact to start a conversation.": "Elige un contacto para empezar.", Options: "Opciones", Allow: "Permitir", "Not now": "Ahora no", Reply: "Responder", Edit: "Editar", Download: "Descargar", Encrypt: "Cifrar", Decrypt: "Descifrar", "Delete permanently": "Eliminar para siempre", Theme: "Tema", "New version available": "Nueva versión disponible", Update: "Actualizar", "Add members": "Añadir miembros", "Copy invite link": "Copiar enlace de invitación", "Text status": "Estado de texto", "Photo or video": "Foto o vídeo", Close: "Cerrar", "Make secret": "Hacer secreto", "Make visible again": "Hacer visible" }
};
Object.assign(L.ar, { "Your status": "حالتك", "Add a comment": "أضف تعليقاً" });
Object.assign(L.fr, { "Your status": "Votre statut", "Add a comment": "Ajouter un commentaire" });
Object.assign(L.es, { "Your status": "Tu estado", "Add a comment": "Añadir un comentario" });
Object.assign(L.ar, { Manage: "إدارة", Profile: "الملف الشخصي", "Search chats": "بحث في المحادثات" });
Object.assign(L.fr, { Manage: "Gérer", Profile: "Profil", "Search chats": "Rechercher" });
Object.assign(L.es, { Manage: "Administrar", Profile: "Perfil", "Search chats": "Buscar chats" });
Object.assign(L.ar, { Forward: "إعادة توجيه", "Pin chat": "تثبيت المحادثة", "Unpin chat": "إلغاء التثبيت", Mute: "كتم", Unmute: "إلغاء الكتم", "Search in chat": "بحث في المحادثة", Block: "حظر", Unblock: "إلغاء الحظر", "Change photo": "تغيير الصورة", "Dark mode": "الوضع الداكن", "Change display name": "تغيير الاسم المعروض", "Change username": "تغيير اسم المستخدم", "Change password": "تغيير كلمة المرور", "Access code": "رمز الدخول", "Private, fast messaging for your community.": "مراسلة سريعة وخاصة لمجتمعك." });
Object.assign(L.fr, { Forward: "Transférer", "Pin chat": "Épingler", "Unpin chat": "Désépingler", Mute: "Muet", Unmute: "Réactiver le son", "Search in chat": "Rechercher dans la discussion", Block: "Bloquer", Unblock: "Débloquer", "Change photo": "Changer la photo", "Dark mode": "Mode sombre", "Change display name": "Changer le nom affiché", "Change username": "Changer le nom d'utilisateur", "Change password": "Changer le mot de passe", "Access code": "Code d'accès", "Private, fast messaging for your community.": "Une messagerie privée et rapide pour votre communauté." });
Object.assign(L.es, { Forward: "Reenviar", "Pin chat": "Fijar chat", "Unpin chat": "Desfijar", Mute: "Silenciar", Unmute: "Activar sonido", "Search in chat": "Buscar en el chat", Block: "Bloquear", Unblock: "Desbloquear", "Change photo": "Cambiar foto", "Dark mode": "Modo oscuro", "Change display name": "Cambiar nombre visible", "Change username": "Cambiar usuario", "Change password": "Cambiar contraseña", "Access code": "Código de acceso", "Private, fast messaging for your community.": "Mensajería privada y rápida para tu comunidad." });
Object.assign(L.ar, { Delete: "حذف", Stop: "إيقاف", "Send current location": "إرسال الموقع الحالي", "Share live location for 15 minutes": "مشاركة الموقع المباشر لمدة 15 دقيقة", "Share live location for 1 hour": "مشاركة الموقع المباشر لمدة ساعة", "Share live location for 8 hours": "مشاركة الموقع المباشر لمدة 8 ساعات", "Stop live location": "إيقاف الموقع المباشر", "Sharing live location. Tap to stop.": "تتم مشاركة موقعك المباشر. اضغط للإيقاف." });
Object.assign(L.fr, { Delete: "Supprimer", Stop: "Arrêter", "Send current location": "Envoyer la position actuelle", "Share live location for 15 minutes": "Partager la position en direct (15 min)", "Share live location for 1 hour": "Partager la position en direct (1 h)", "Share live location for 8 hours": "Partager la position en direct (8 h)", "Stop live location": "Arrêter la position en direct", "Sharing live location. Tap to stop.": "Position en direct partagée. Touchez pour arrêter." });
Object.assign(L.es, { Delete: "Eliminar", Stop: "Detener", "Send current location": "Enviar ubicación actual", "Share live location for 15 minutes": "Compartir ubicación en vivo (15 min)", "Share live location for 1 hour": "Compartir ubicación en vivo (1 h)", "Share live location for 8 hours": "Compartir ubicación en vivo (8 h)", "Stop live location": "Detener ubicación en vivo", "Sharing live location. Tap to stop.": "Compartiendo ubicación en vivo. Toca para detener." });
Object.assign(L.ar, { Members: "الأعضاء", "Leave group": "مغادرة المجموعة", Copy: "نسخ", Star: "تمييز بنجمة", Unstar: "إزالة النجمة", Report: "إبلاغ", "Clear chat": "مسح المحادثة", "Archive chat": "أرشفة المحادثة", "Unarchive chat": "إلغاء الأرشفة", Archived: "المؤرشف", "Show starred messages": "عرض الرسائل المميزة", "Show all messages": "عرض كل الرسائل", "Send feedback": "إرسال ملاحظات", "Export my data": "تصدير بياناتي", "Log out of all devices": "تسجيل الخروج من كل الأجهزة", "Delete my account": "حذف حسابي", Reports: "البلاغات" });
Object.assign(L.fr, { Members: "Membres", "Leave group": "Quitter le groupe", Copy: "Copier", Star: "Ajouter une étoile", Unstar: "Retirer l'étoile", Report: "Signaler", "Clear chat": "Vider la discussion", "Archive chat": "Archiver", "Unarchive chat": "Désarchiver", Archived: "Archivées", "Show starred messages": "Messages favoris", "Show all messages": "Tous les messages", "Send feedback": "Envoyer un avis", "Export my data": "Exporter mes données", "Log out of all devices": "Se déconnecter partout", "Delete my account": "Supprimer mon compte", Reports: "Signalements" });
Object.assign(L.es, { Members: "Miembros", "Leave group": "Salir del grupo", Copy: "Copiar", Star: "Destacar", Unstar: "Quitar destacado", Report: "Denunciar", "Clear chat": "Vaciar chat", "Archive chat": "Archivar", "Unarchive chat": "Desarchivar", Archived: "Archivados", "Show starred messages": "Ver destacados", "Show all messages": "Ver todos", "Send feedback": "Enviar comentarios", "Export my data": "Exportar mis datos", "Log out of all devices": "Cerrar sesión en todos", "Delete my account": "Eliminar mi cuenta", Reports: "Denuncias" });
Object.assign(L.ar, { "Disappearing messages": "رسائل مؤقتة", Off: "إيقاف", "24 hours": "24 ساعة", "7 days": "7 أيام" });
Object.assign(L.fr, { "Disappearing messages": "Messages éphémères", Off: "Désactivé", "24 hours": "24 heures", "7 days": "7 jours" });
Object.assign(L.es, { "Disappearing messages": "Mensajes temporales", Off: "Desactivado", "24 hours": "24 horas", "7 days": "7 días" });
Object.assign(L.ar, { "Welcome back": "مرحباً بعودتك", "Sign in to continue to Shadow": "سجّل الدخول للمتابعة إلى Shadow", "Create your account": "أنشئ حسابك", "Use the one-time code you got from the owner": "استخدم رمز الدعوة لمرة واحدة من المالك", "expires in": "تنتهي خلال", You: "أنت", File: "ملف", "Locked message": "رسالة مقفلة", "Delete this status?": "حذف هذه الحالة؟" });
Object.assign(L.fr, { "Welcome back": "Content de vous revoir", "Sign in to continue to Shadow": "Connectez-vous pour continuer sur Shadow", "Create your account": "Créez votre compte", "Use the one-time code you got from the owner": "Utilisez le code à usage unique du propriétaire", "expires in": "expire dans", You: "Vous", File: "Fichier", "Locked message": "Message verrouillé", "Delete this status?": "Supprimer ce statut ?" });
Object.assign(L.es, { "Welcome back": "Bienvenido de nuevo", "Sign in to continue to Shadow": "Inicia sesión para continuar en Shadow", "Create your account": "Crea tu cuenta", "Use the one-time code you got from the owner": "Usa el código de un solo uso del propietario", "expires in": "caduca en", You: "Tú", File: "Archivo", "Locked message": "Mensaje bloqueado", "Delete this status?": "¿Eliminar este estado?" });
Object.assign(L.ar, { "Photo background": "خلفية بصورة", "Remove photo background": "إزالة صورة الخلفية", "View once for the next photo or video": "عرض مرة واحدة للصورة أو الفيديو القادم", "Disappear after": "تختفي بعد", "chat default": "إعداد المحادثة", "Tap to view once": "اضغط للعرض مرة واحدة", Opened: "تم الفتح", "not opened yet": "لم تُفتح بعد", "View once": "عرض لمرة واحدة", Photo: "صورة", Video: "فيديو", "turned on disappearing messages": "فعّل الرسائل المؤقتة", "turned off disappearing messages": "أوقف الرسائل المؤقتة", min: "د", h: "س", days: "أيام", "No views yet": "لا مشاهدات بعد" });
Object.assign(L.fr, { "Photo background": "Photo en arrière-plan", "Remove photo background": "Retirer la photo", "View once for the next photo or video": "Vue unique pour la prochaine photo ou vidéo", "Disappear after": "Disparaît après", "chat default": "réglage du chat", "Tap to view once": "Touchez pour voir une fois", Opened: "Ouvert", "not opened yet": "pas encore ouvert", "View once": "Vue unique", Photo: "Photo", Video: "Vidéo", "turned on disappearing messages": "a activé les messages éphémères", "turned off disappearing messages": "a désactivé les messages éphémères", days: "jours", "No views yet": "Aucune vue" });
Object.assign(L.es, { "Photo background": "Foto de fondo", "Remove photo background": "Quitar foto de fondo", "View once for the next photo or video": "Ver una vez la próxima foto o vídeo", "Disappear after": "Desaparece tras", "chat default": "ajuste del chat", "Tap to view once": "Toca para ver una vez", Opened: "Abierto", "not opened yet": "aún sin abrir", "View once": "Ver una vez", Photo: "Foto", Video: "Vídeo", "turned on disappearing messages": "activó los mensajes temporales", "turned off disappearing messages": "desactivó los mensajes temporales", days: "días", "No views yet": "Aún sin vistas" });
Object.assign(L.ar, { Today: "اليوم", Yesterday: "أمس", "View once (opens one time, then deleted)": "عرض لمرة واحدة (تُحذف بعد فتحها)", "Send normally": "إرسال عادي" });
Object.assign(L.fr, { Today: "Aujourd'hui", Yesterday: "Hier", "View once (opens one time, then deleted)": "Vue unique (supprimé après ouverture)", "Send normally": "Envoyer normalement" });
Object.assign(L.es, { Today: "Hoy", Yesterday: "Ayer", "View once (opens one time, then deleted)": "Ver una vez (se borra al abrirlo)", "Send normally": "Enviar normal" });
Object.assign(L.ar, { "Voice call": "مكالمة صوتية", "Video call": "مكالمة فيديو", Outgoing: "صادرة", Incoming: "واردة", Missed: "فائتة", Declined: "مرفوضة", "Calling...": "جارٍ الاتصال...", "Connecting...": "جارٍ الاتصال...", "Incoming voice call": "مكالمة صوتية واردة", "Incoming video call": "مكالمة فيديو واردة", "No answer": "لا يوجد رد", "User is busy": "المستخدم مشغول", "User is offline": "المستخدم غير متصل", "Call not possible": "تعذر الاتصال" });
Object.assign(L.fr, { "Voice call": "Appel vocal", "Video call": "Appel vidéo", Outgoing: "Sortant", Incoming: "Entrant", Missed: "Manqué", Declined: "Refusé", "Calling...": "Appel en cours...", "Connecting...": "Connexion...", "Incoming voice call": "Appel vocal entrant", "Incoming video call": "Appel vidéo entrant", "No answer": "Pas de réponse", "User is busy": "Occupé", "User is offline": "Hors ligne", "Call not possible": "Appel impossible" });
Object.assign(L.es, { "Voice call": "Llamada de voz", "Video call": "Videollamada", Outgoing: "Saliente", Incoming: "Entrante", Missed: "Perdida", Declined: "Rechazada", "Calling...": "Llamando...", "Connecting...": "Conectando...", "Incoming voice call": "Llamada de voz entrante", "Incoming video call": "Videollamada entrante", "No answer": "Sin respuesta", "User is busy": "Ocupado", "User is offline": "Sin conexión", "Call not possible": "Llamada no posible" });
Object.assign(L.ar, { "You are the first user. This account becomes the owner and needs no access code.": "أنت أول مستخدم. سيصبح هذا الحساب حساب المالك ولا يحتاج إلى رمز دخول.", "No owner yet. Enter the setup code shown in the server window.": "لا يوجد مالك بعد. أدخل رمز الإعداد الظاهر في نافذة الخادم." });
Object.assign(L.fr, { "You are the first user. This account becomes the owner and needs no access code.": "Vous êtes le premier utilisateur. Ce compte devient propriétaire, sans code d'accès.", "No owner yet. Enter the setup code shown in the server window.": "Pas encore de propriétaire. Entrez le code d'installation affiché dans la fenêtre du serveur." });
Object.assign(L.es, { "You are the first user. This account becomes the owner and needs no access code.": "Eres el primer usuario. Esta cuenta será la propietaria y no necesita código.", "No owner yet. Enter the setup code shown in the server window.": "Aún no hay propietario. Introduce el código de configuración que aparece en el servidor." });
Object.assign(L.ar, { "App color": "لون التطبيق", Emerald: "زمردي", Ocean: "محيط", Violet: "بنفسجي", Aurora: "شفق", Sunset: "غروب", Rose: "وردي" });
Object.assign(L.fr, { "App color": "Couleur de l'application", Emerald: "Émeraude", Ocean: "Océan", Violet: "Violet", Aurora: "Aurore", Sunset: "Coucher de soleil", Rose: "Rose" });
Object.assign(L.es, { "App color": "Color de la app", Emerald: "Esmeralda", Ocean: "Océano", Violet: "Violeta", Aurora: "Aurora", Sunset: "Atardecer", Rose: "Rosa" });
Object.assign(L.ar, { "Custom color": "لون مخصص" });
Object.assign(L.fr, { "Custom color": "Couleur personnalisée" });
Object.assign(L.es, { "Custom color": "Color personalizado" });
let lang = localStorage.getItem("lang") || "en";
function t(s) { return (L[lang] && L[lang][s]) || s; }
function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("button, h1, h2, .placeholder, #update span, .sub, .tag, .auth-sub").forEach((el) => {
    if (el.children.length) return;
    el.dataset.en = el.dataset.en || el.textContent;
    el.textContent = t(el.dataset.en);
  });
  document.querySelectorAll("input[placeholder]").forEach((el) => { el.dataset.en = el.dataset.en || el.placeholder; el.placeholder = t(el.dataset.en); });
}
document.querySelectorAll(".lang").forEach((sel) => {
  sel.innerHTML = '<option value="en">English</option><option value="ar">العربية</option><option value="fr">Français</option><option value="es">Español</option>';
  sel.value = lang;
  sel.onchange = () => { lang = sel.value; localStorage.setItem("lang", lang); document.querySelectorAll(".lang").forEach((x) => (x.value = lang)); applyLang(); };
});
applyLang();

// ---------- redesign helpers: chat previews and the status viewer ----------
function avBg(n) { // a different colour for each person, like Telegram
  let h = 0;
  for (const c of String(n)) h = (h * 31 + c.codePointAt(0)) % 360;
  return "linear-gradient(135deg,hsl(" + h + " 75% 58%),hsl(" + ((h + 45) % 360) + " 80% 52%))";
}
function fmtTime(ts) {
  const d = new Date(ts), n = new Date();
  return d.toDateString() === n.toDateString() ? d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : d.toLocaleDateString([], { day: "numeric", month: "short" });
}
function fmtAgo(ms) {
  const m = Math.max(0, Math.round(ms / 60000));
  if (m < 1) return "<1m";
  return m < 60 ? m + "m" : Math.floor(m / 60) + "h" + (m % 60 ? " " + (m % 60) + "m" : "");
}
function preview(l) {
  if (!l) return "";
  const body = l.kind === "text" ? l.text : l.kind === "enc" ? "\u{1F512} " + t("Locked message") : l.kind === "file" ? "\u{1F4CE} " + t("File") : l.kind === "loc" ? "\u{1F4CD} " + t("Location") : l.kind === "deleted" ? t("Message deleted") : "";
  return (l.mine ? t("You") + ": " : "") + body;
}
function touchLast(chat, m) {
  state.last[chat] = { time: m.time, mine: m.from === state.me.id, kind: m.deleted ? "deleted" : m.enc ? "enc" : m.text ? "text" : m.file ? "file" : m.loc ? "loc" : "text", text: (m.text || "").slice(0, 60) };
  renderContacts();
}
function paintMe() {
  const u = state.me;
  $("me-av").style.background = u.avatar ? "" : avBg(u.username || "?");
  $("me-av").innerHTML = u.avatar ? '<img src="' + esc(u.avatar) + '" alt="">' : esc((u.username || "?")[0].toUpperCase());
}

const story = { users: [], ui: 0, i: 0, elapsed: 0, dur: 5000, press: false, typing: false, raf: 0, last: 0, hold: 0 };
const cur = () => story.users[story.ui].items[story.i];
async function openStory(uid) {
  const all = await api("status"), by = {};
  all.forEach((s) => (by[s.from] = by[s.from] || []).push(s));
  if (!by[uid]) { if (uid === state.me.id) openStatus(uid); return; }
  const order = [state.me.id, ...Object.keys(by).filter((id) => id !== state.me.id)].filter((id) => by[id]);
  story.users = order.map((id) => ({ id, items: by[id] }));
  story.ui = order.indexOf(uid);
  const fresh = by[uid].findIndex((s) => !state.seen.has(s.id));
  story.i = fresh > -1 ? fresh : 0;
  $("story").classList.remove("hidden");
  showStory();
}
function showStory() {
  const u = story.users[story.ui], s = cur();
  state.seen.add(s.id);
  localStorage.setItem("seen", JSON.stringify([...state.seen]));
  $("story-bars").innerHTML = u.items.map((x, k) => '<div class="bar"><div class="fill" style="width:' + (k < story.i ? 100 : 0) + '%"></div></div>').join("");
  $("story-name").textContent = s.name || "?";
  $("story-time").textContent = fmtTime(s.time) + " \u00B7 " + t("expires in") + " " + fmtAgo(24 * 3600e3 - (Date.now() - s.time));
  $("story-del").classList.toggle("hidden", s.from !== state.me.id);
  $("story-views").classList.toggle("hidden", s.from !== state.me.id);
  if (s.from === state.me.id) $("story-views").textContent = "\u{1F441} " + (s.viewers || []).length;
  else if (!state.viewed.has(s.id)) { // tell the owner that I saw it
    state.viewed.add(s.id);
    fetch("/api/status/" + s.id + "/seen", { method: "POST", headers: { Authorization: "Bearer " + state.token } }).catch(() => {});
  }
  const k = s.file ? kind(s.file) : "text";
  $("story-body").innerHTML = k === "image" ? '<img src="' + esc(s.file.url) + '" alt="">'
    : k === "video" ? '<video id="story-vid" src="' + esc(s.file.url) + '" autoplay playsinline></video>'
    : k === "file" ? '<div class="story-text">&#128206;</div>'
    : '<div class="story-text" style="background:' + esc(s.color) + '">' + esc(s.text) + "</div>";
  story.elapsed = 0; story.dur = 5000; story.last = 0;
  const v = $("story-vid");
  if (v) v.onloadedmetadata = () => { story.dur = Math.min(Math.max(v.duration * 1000, 3000), 30000); };
  renderStoryFoot(s);
  cancelAnimationFrame(story.raf);
  story.raf = requestAnimationFrame(storyTick);
}
function storyTick(now) {
  const dt = story.last ? Math.min(now - story.last, 100) : 0;
  story.last = now;
  if (!story.press && !story.typing) story.elapsed += dt;
  const bar = $("story-bars").children[story.i];
  if (bar) bar.firstChild.style.width = Math.min(100, (story.elapsed / story.dur) * 100) + "%";
  if (story.elapsed >= story.dur) return storyNext();
  story.raf = requestAnimationFrame(storyTick);
}
function storyNext() {
  const u = story.users[story.ui];
  if (story.i < u.items.length - 1) { story.i++; showStory(); }
  else if (story.ui < story.users.length - 1) { story.ui++; story.i = 0; showStory(); }
  else closeStory();
}
function storyPrev() {
  if (story.i > 0) { story.i--; showStory(); }
  else if (story.ui > 0) { story.ui--; story.i = 0; showStory(); }
  else showStory();
}
function closeStory() {
  cancelAnimationFrame(story.raf);
  $("story").classList.add("hidden");
  $("story-body").innerHTML = "";
  loadStories();
}
function holdStory(on) { story.press = on; const v = $("story-vid"); if (v) on ? v.pause() : v.play().catch(() => {}); }
function renderStoryFoot(s) {
  const likes = s.likes || {}, mine = likes[state.me.id], counts = {};
  Object.values(likes).forEach((e) => (counts[e] = (counts[e] || 0) + 1));
  $("story-rx").innerHTML = EMO.map((e) => '<button data-e="' + e + '" class="' + (mine === e ? "on" : "") + '">' + e + (counts[e] ? " " + counts[e] : "") + "</button>").join("");
  $("story-cms").innerHTML = (s.comments || []).slice(-4).map((c) => "<p><b>" + esc(c.name) + ":</b> " + esc(c.text) + "</p>").join("");
}
async function refreshStory() {
  const fresh = (await api("status")).find((x) => x.id === cur().id);
  if (fresh) { story.users[story.ui].items[story.i] = fresh; renderStoryFoot(fresh); }
}
["story-prev", "story-next"].forEach((id) => {
  const b = $(id);
  b.onpointerdown = () => { story.hold = Date.now(); holdStory(true); };
  b.onpointerup = b.onpointerleave = b.onpointercancel = () => holdStory(false);
  b.onclick = () => { if (Date.now() - story.hold > 300) return; id === "story-next" ? storyNext() : storyPrev(); };
});
$("story-close").onclick = closeStory;
$("story-rx").onclick = async (e) => {
  const b = e.target.closest("button");
  if (b && await post("status/" + cur().id + "/react", { emoji: b.dataset.e })) refreshStory();
};
$("story-cm").onfocus = () => { story.typing = true; const v = $("story-vid"); if (v) v.pause(); };
$("story-cm").onblur = () => { story.typing = false; const v = $("story-vid"); if (v) v.play().catch(() => {}); };
$("story-cm").onkeydown = async (e) => {
  if (e.key !== "Enter" || !e.target.value.trim()) return;
  if (await post("status/" + cur().id + "/comment", { text: e.target.value })) { e.target.value = ""; refreshStory(); }
};
$("story-del").onclick = async () => {
  if (!confirm(t("Delete this status?"))) return;
  await fetch("/api/status/" + cur().id, { method: "DELETE", headers: { Authorization: "Bearer " + state.token } });
  const u = story.users[story.ui];
  u.items.splice(story.i, 1);
  if (!u.items.length) { story.users.splice(story.ui, 1); story.ui = Math.max(0, Math.min(story.ui, story.users.length - 1)); story.i = 0; }
  else story.i = Math.min(story.i, u.items.length - 1);
  if (!story.users.length) return closeStory();
  showStory();
};
document.addEventListener("keydown", (e) => {
  if ($("story").classList.contains("hidden")) return;
  if (e.target.id === "story-cm") { if (e.key === "Escape") e.target.blur(); return; }
  if (e.key === "Escape") closeStory();
  else if (e.key === "ArrowRight") storyNext();
  else if (e.key === "ArrowLeft") storyPrev();
});

// ---------- disappearing notice, view once, photo background, status viewers ----------
state.viewed = new Set();
function ttlLabel(min) {
  if (!min) return t("Off");
  if (min < 60) return min + " " + t("min");
  return min < 1440 ? Math.round(min / 60) + " " + t("h") : Math.round(min / 1440) + " " + t("days");
}
function updateTtlNote() {
  const g = state.groups.find((x) => x.id === state.active), ms = g ? g.ttl : (state.me.ttl || {})[state.active], n = $("ttl-note");
  n.textContent = ms ? "\u23F3 " + t("Disappearing messages") + ": " + ttlLabel(Math.round(ms / 60000)) : "";
  n.classList.toggle("hidden", !ms);
}
function fmtDur(n) { return Math.floor(n / 60) + ":" + String(n % 60).padStart(2, "0"); }
function sysText(m) {
  if (m.sys && m.sys.type === "call") return (m.sys.video ? "\u{1F4F9} " + t("Video call") : "\u{1F4DE} " + t("Voice call")) + " \u00B7 " + (m.from === state.me.id ? t("Outgoing") : t("Incoming")) + " \u00B7 " + (m.sys.secs ? fmtDur(m.sys.secs) : t(m.sys.result === "declined" ? "Declined" : "Missed"));
  const who = m.from === state.me.id ? t("You") : ((state.users.find((u) => u.id === m.from) || {}).username || "?"), min = m.sys && m.sys.min;
  return who + " " + (min ? t("turned on disappearing messages") + " (" + ttlLabel(min) + ")" : t("turned off disappearing messages"));
}
function onSystem(peerId, m) {
  if (m.sys && m.sys.type === "ttl" && !state.groups.some((g) => g.id === peerId)) {
    state.me.ttl = { ...(state.me.ttl || {}) };
    if (m.sys.min) state.me.ttl[peerId] = m.sys.min * 60000; else delete state.me.ttl[peerId];
  }
  if (peerId === state.active) updateTtlNote();
}
function onceHtml(m) {
  const label = m.file ? (kind(m.file) === "video" ? "\u{1F3AC} " + t("Video") : "\u{1F4F7} " + t("Photo")) : "\u{1F4F7} " + t("Photo or video");
  if (m.opened) return "&#128065; " + esc(label) + " &middot; " + t("Opened");
  if (m.from === state.me.id) return "&#128065; " + esc(label) + " &middot; " + t("View once") + " &middot; " + t("not opened yet");
  return '<button class="once-btn" data-id="' + m.id + '">&#128065; ' + esc(label) + " &middot; " + t("Tap to view once") + "</button>";
}
async function openOnce(id) {
  const m = findMsg(id);
  if (!m || m.from === state.me.id) return;
  const r = await post("once/" + id + "/open", {});
  if (!r) return;
  $("once-body").innerHTML = kind(r) === "video"
    ? '<video src="' + esc(r.url) + '" controls autoplay playsinline controlslist="nodownload" disablepictureinpicture></video>'
    : '<img src="' + esc(r.url) + '" alt="" draggable="false">';
  $("once").dataset.id = id;
  $("once").classList.remove("hidden");
}
$("once").oncontextmenu = (e) => e.preventDefault();
$("once-close").onclick = async () => {
  const id = $("once").dataset.id;
  $("once").classList.add("hidden");
  $("once-body").innerHTML = "";
  $("once").dataset.id = "";
  if (id) await post("once/" + id + "/done", {});
};
function paintSend() { $("btn-sendopts").classList.toggle("on", !!(state.once || state.sendTtl)); }
$("btn-sendopts").onclick = () => showMenu([
  [(state.once ? "\u2714 " : "") + t("View once for the next photo or video"), () => { state.once = !state.once; paintSend(); }],
  [(state.sendTtl ? "" : "\u2714 ") + t("Disappear after") + ": " + t("chat default"), () => { state.sendTtl = undefined; paintSend(); }],
  ...[1, 60, 1440, 10080].map((m) => [(state.sendTtl === m ? "\u2714 " : "") + t("Disappear after") + ": " + ttlLabel(m), () => { state.sendTtl = m; paintSend(); }])
]);
function wrapEmit(sock) { // adds the timer and view-once choices to the next message
  const raw = sock.emit.bind(sock);
  sock.emit = (ev, data, ...rest) => {
    if (ev === "private message" && data && data.to === state.active) {
      if (state.sendTtl !== undefined && data.ttlMin === undefined) data.ttlMin = state.sendTtl;
      if (state.once && data.file && data.once === undefined && ["image", "video"].includes(kind(data.file))) { data.once = true; state.once = false; }
      state.sendTtl = undefined;
      paintSend();
    }
    return raw(ev, data, ...rest);
  };
}
async function setBg(url) {
  const g = state.groups.find((x) => x.id === state.active);
  if (g) await post("groups/" + g.id + "/theme", { bg: url });
  else { if (url) localStorage.setItem("bg:" + state.active, url); else localStorage.removeItem("bg:" + state.active); applyTheme(); }
}
$("bgfile").onchange = async () => {
  const f = $("bgfile").files[0];
  $("bgfile").value = "";
  if (!f) return;
  const r = await upload(f, f.name, f.type);
  if (r) setBg(r.url);
};
$("story-views").onclick = async () => {
  story.press = true;
  await refreshStory();
  const v = cur().viewers || [];
  $("story-views").textContent = "\u{1F441} " + v.length;
  $("menu").addEventListener("close", () => { story.press = false; }, { once: true });
  showMenu(v.length ? v.map((x) => [x.name + " \u00B7 " + fmtTime(x.time), () => {}]) : [[t("No views yet"), () => {}]]);
};

// ---------- voice and video calls ----------
const call = { id: null, peer: null, video: false, pc: null, stream: null, queue: [], incoming: null, t0: 0, tick: 0, ring: null, facing: "user", ctx: null };
async function iceConfig() { try { return await api("ice"); } catch (e) { return { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] }; } }
function setCallButtons(incoming) {
  $("call-accept").classList.toggle("hidden", !incoming);
  ["call-mute", "call-cam", "call-flip"].forEach((id) => $(id).classList.toggle("hidden", incoming || (id !== "call-mute" && !call.video)));
}
function showCall(text, name, incoming) {
  const p = state.users.find((u) => u.id === call.peer) || {}, nm = name || p.username || "?";
  $("call-name").textContent = nm;
  $("call-state").textContent = text;
  $("call-av").style.background = p.avatar ? "" : avBg(nm);
  $("call-av").innerHTML = p.avatar ? '<img src="' + esc(p.avatar) + '" alt="">' : esc(nm[0].toUpperCase());
  $("call").classList.toggle("audio", !call.video);
  $("call").classList.remove("hidden");
  setCallButtons(!!incoming);
}
async function makePc() {
  const pc = (call.pc = new RTCPeerConnection(await iceConfig()));
  call.stream.getTracks().forEach((tr) => pc.addTrack(tr, call.stream));
  pc.onicecandidate = (e) => { if (e.candidate) state.socket.emit("call:ice", { callId: call.id, candidate: e.candidate }); };
  pc.ontrack = (e) => { $("call-remote").srcObject = e.streams[0]; };
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === "connected") callConnected();
    else if (["failed", "closed"].includes(pc.connectionState)) endCall(false);
  };
  $("call-local").srcObject = call.stream;
}
function callConnected() {
  if (call.t0) return;
  call.t0 = Date.now();
  call.tick = setInterval(() => { $("call-state").textContent = fmtDur(Math.floor((Date.now() - call.t0) / 1000)); }, 500);
}
async function startCall(video) {
  const peer = state.active;
  if (!peer || state.groups.some((g) => g.id === peer)) return;
  if (call.id) return alert(t("You are already in a call"));
  if (!window.RTCPeerConnection || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return alert(t("Calls need a secure connection (https or localhost)."));
  try { call.stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: video ? { facingMode: "user" } : false }); }
  catch (e) { return alert(t("Allow the microphone and camera to make calls.")); }
  Object.assign(call, { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8), peer, video, incoming: null, queue: [], t0: 0 });
  showCall(t("Calling..."));
  await makePc();
  const offer = await call.pc.createOffer();
  await call.pc.setLocalDescription(offer);
  state.socket.emit("call:offer", { to: peer, callId: call.id, video, sdp: call.pc.localDescription });
}
function endCall(remote, reason) {
  if (!call.id) return;
  if (!remote) state.socket.emit("call:end", { callId: call.id, reason: "ended" });
  stopRing();
  clearInterval(call.tick);
  const pc = call.pc;
  call.pc = null;
  if (pc) { pc.onconnectionstatechange = null; pc.close(); }
  if (call.stream) call.stream.getTracks().forEach((x) => x.stop());
  $("call-remote").srcObject = null;
  $("call-local").srcObject = null;
  $("call").classList.add("hidden");
  const note = { busy: "User is busy", offline: "User is offline", unavailable: "Call not possible", noanswer: "No answer" }[reason];
  Object.assign(call, { id: null, stream: null, incoming: null, queue: [], t0: 0 });
  if (note) alert(t(note));
}
function startRing() {
  try {
    const ctx = (call.ctx = call.ctx || new (window.AudioContext || window.webkitAudioContext)());
    const beep = () => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = 880; g.gain.value = 0.15; o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.4); };
    beep();
    call.ring = setInterval(() => { beep(); if (navigator.vibrate) navigator.vibrate(300); }, 1500);
  } catch (e) {}
}
function stopRing() { clearInterval(call.ring); call.ring = null; }
$("btn-call").onclick = () => startCall(false);
$("btn-vcall").onclick = () => startCall(true);
$("call-end").onclick = () => endCall(false);
$("call-accept").onclick = async () => {
  stopRing();
  try { call.stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: call.video ? { facingMode: "user" } : false }); }
  catch (e) { alert(t("Allow the microphone and camera to make calls.")); return endCall(false); }
  setCallButtons(false);
  $("call-state").textContent = t("Connecting...");
  await makePc();
  await call.pc.setRemoteDescription(call.incoming);
  call.incoming = null;
  for (const c of call.queue) await call.pc.addIceCandidate(c).catch(() => {});
  call.queue = [];
  const ans = await call.pc.createAnswer();
  await call.pc.setLocalDescription(ans);
  state.socket.emit("call:answer", { callId: call.id, sdp: call.pc.localDescription });
};
$("call-mute").onclick = () => { const on = call.stream.getAudioTracks().some((x) => x.enabled); call.stream.getAudioTracks().forEach((x) => (x.enabled = !on)); $("call-mute").classList.toggle("off", on); };
$("call-cam").onclick = () => { const on = call.stream.getVideoTracks().some((x) => x.enabled); call.stream.getVideoTracks().forEach((x) => (x.enabled = !on)); $("call-cam").classList.toggle("off", on); };
$("call-flip").onclick = async () => {
  if (!call.stream || !call.video || !call.pc) return;
  call.facing = call.facing === "user" ? "environment" : "user";
  try {
    const nt = (await navigator.mediaDevices.getUserMedia({ video: { facingMode: call.facing } })).getVideoTracks()[0];
    const sender = call.pc.getSenders().find((x) => x.track && x.track.kind === "video");
    if (sender) await sender.replaceTrack(nt);
    call.stream.getVideoTracks().forEach((x) => { x.stop(); call.stream.removeTrack(x); });
    call.stream.addTrack(nt);
    $("call-local").srcObject = call.stream;
  } catch (e) {}
};

// ---------- first run: the owner needs no access code ----------
(async () => {
  try {
    const s = await (await fetch("/api/setup")).json();
    if (!s.first) return;
    setMode(true);
    const msg = s.local ? "You are the first user. This account becomes the owner and needs no access code." : "No owner yet. Enter the setup code shown in the server window.";
    const n = $("auth-note");
    n.dataset.en = msg; n.textContent = t(msg); n.classList.remove("hidden");
    if (s.local) $("code").parentElement.classList.add("hidden");
    else $("code").placeholder = t("Setup code");
  } catch (e) {}
})();

// ---------- app colour ----------
const GRADS = { emerald: ["#12c08b", "#0891b2", "#2563eb"], ocean: ["#06b6d4", "#1d7cf2", "#6d5ae6"], violet: ["#a855f7", "#7c3aed", "#4f46e5"], aurora: ["#00c2ff", "#6c63ff", "#ff4fa3"], sunset: ["#ffa634", "#f2603f", "#d946ef"], rose: ["#f472b6", "#e11d74", "#8b5cf6"] };
function hexRgb(h) { return [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)); }
function rgbHex(r, g, b) { return "#" + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join(""); }
function hslHex(h, s, l) { h = ((h % 360) + 360) % 360; const a = s * Math.min(l, 1 - l), f = (n) => { const k = (n + h / 30) % 12; return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); }; return rgbHex(f(0) * 255, f(8) * 255, f(4) * 255); }
function hexHsl(hex) {
  const [r, g, b] = hexRgb(hex).map((v) => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
  let h = 0, s = 0;
  if (d) { s = d / (1 - Math.abs(2 * l - 1)); h = (mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4) * 60; }
  return [h, s, l];
}
function tint(hex, k) { const [r, g, b] = hexRgb(hex); return rgbHex(r + (255 - r) * k, g + (255 - g) * k, b + (255 - b) * k); }
function setAccent(v) { localStorage.setItem("accent", v); applyAccent(v); renderSwatches(); }
function renderSwatches() {
  const cur = localStorage.getItem("accent") || "emerald";
  $("swatches").innerHTML = Object.entries(GRADS).map(([k, g]) => '<button class="sw' + (cur === k ? " on" : "") + '" data-k="' + k + '" style="background:linear-gradient(135deg,' + g.join(",") + ')" aria-label="' + k + '"></button>').join("") +
    (cur.startsWith("custom:") ? '<button class="sw on" data-k="' + esc(cur) + '" style="background:' + esc(cur.slice(7)) + '" aria-label="custom"></button>' : "");
}
function openColors() { renderSwatches(); $("colors").showModal(); }
$("swatches").onclick = (e) => { const b = e.target.closest(".sw"); if (b) setAccent(b.dataset.k); };
$("colors-custom").onclick = () => $("accentpick").click();
$("accentpick").oninput = () => setAccent("custom:" + $("accentpick").value);
$("colors-close").onclick = () => $("colors").close();

// ---------- auto login ----------
(async () => {
  const token = localStorage.getItem("token");
  if (!token) return;
  try {
    state.token = token;
    const me = await api("me");
    start(token, me);
  } catch (e) { localStorage.removeItem("token"); }
})();
