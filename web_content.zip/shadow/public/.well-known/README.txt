Put assetlinks.json (from PWABuilder) in this folder. It makes the Android app open without a browser bar.
