// Lists accounts, or resets the owner's password.
// Stop the server first. Usage:
//   node reset-owner.js                      (shows the accounts in this database)
//   node reset-owner.js NewPassword123       (sets a new owner password, 8+ characters)
const bcrypt = require("bcryptjs");
const db = require("./db");
const pw = process.argv[2];

if (!db.users.length) {
  console.log("This database has no accounts yet.\nStart the server and create the first account at http://localhost:3000 - no access code is needed for it.");
  process.exit(0);
}
if (!pw || pw.length < 8) {
  console.log("Accounts in this database:");
  db.users.forEach((u) => console.log(" - " + u.username + (u.isOwner ? "  (owner)" : "") + (u.banned ? "  (suspended)" : "")));
  console.log("\nTo set a new owner password run:\n  node reset-owner.js NewPassword123     (8 or more characters)");
  process.exit(0);
}
const u = db.users.find((x) => x.isOwner) || db.users[0];
u.isOwner = true;
u.banned = false;
u.passwordHash = bcrypt.hashSync(pw, 12);
u.tokenVersion = (u.tokenVersion || 0) + 1;
db.flushAll();
db.saveUsers();
db.flushAll();
console.log('Done. Sign in as "' + u.username + '" with the new password.');
process.exit(0);
