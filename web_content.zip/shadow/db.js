// SQLite storage using Node's built-in sqlite (needs Node 22.13 or newer, no extra install).
// Data is kept in memory for speed and every change is written to data/shadow.db.
const { DatabaseSync } = require("node:sqlite");
const path = require("path");
const fs = require("fs");

const dir = process.env.DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(dir, { recursive: true });
const sql = new DatabaseSync(path.join(dir, "shadow.db"));
sql.exec("PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL;");

const NAMES = ["users", "messages", "groups", "statuses", "invites", "reports"];
const db = { dir };
const seen = {}; // last saved JSON per row, so only changed rows are written
const timers = {};

NAMES.forEach((n) => {
  sql.exec(`CREATE TABLE IF NOT EXISTS ${n} (seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, data TEXT NOT NULL)`);
  const rows = sql.prepare(`SELECT data FROM ${n} ORDER BY seq`).all();
  db[n] = rows.map((r) => JSON.parse(r.data));
  seen[n] = new Map(db[n].map((x, i) => [x.id, rows[i].data]));
});

function flush(n) {
  const map = seen[n], live = new Set(), changed = [];
  for (const item of db[n]) {
    live.add(item.id);
    const j = JSON.stringify(item);
    if (map.get(item.id) !== j) changed.push([item.id, j]);
  }
  const gone = [...map.keys()].filter((id) => !live.has(id));
  if (!changed.length && !gone.length) return;
  try {
    sql.exec("BEGIN");
    const up = sql.prepare(`INSERT INTO ${n} (id, data) VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET data = excluded.data`);
    changed.forEach(([id, j]) => up.run(id, j));
    const del = sql.prepare(`DELETE FROM ${n} WHERE id = ?`);
    gone.forEach((id) => del.run(id));
    sql.exec("COMMIT");
    changed.forEach(([id, j]) => map.set(id, j));
    gone.forEach((id) => map.delete(id));
  } catch (e) {
    try { sql.exec("ROLLBACK"); } catch (x) {}
    console.error("Database save failed for " + n + ": " + e.message);
  }
}
function schedule(n) {
  if (timers[n]) return;
  timers[n] = setTimeout(() => { timers[n] = null; flush(n); }, 100);
}
db.init = async () => {};
db.saveUsers = () => schedule("users");
db.saveMessages = () => schedule("messages");
db.saveGroups = () => schedule("groups");
db.saveStatuses = () => schedule("statuses");
db.saveInvites = () => schedule("invites");
db.saveReports = () => schedule("reports");
db.flushAll = () => NAMES.forEach(flush);
// Automatic daily backup in data/backups (keeps the newest 14)
db.backup = () => {
  try {
    const out = path.join(dir, "backups");
    fs.mkdirSync(out, { recursive: true });
    const dest = path.join(out, "auto-" + new Date().toISOString().slice(0, 10) + ".db");
    if (fs.existsSync(dest)) return;
    sql.exec("VACUUM INTO '" + dest.replace(/'/g, "''") + "'");
    fs.readdirSync(out).filter((f) => f.startsWith("auto-")).sort().reverse().slice(14).forEach((f) => fs.unlinkSync(path.join(out, f)));
  } catch (e) { console.error("Backup failed:", e.message); }
};
db.backup();
setInterval(db.backup, 6 * 3600e3).unref();
["SIGINT", "SIGTERM"].forEach((s) => process.on(s, () => { db.flushAll(); process.exit(0); }));

module.exports = db;
