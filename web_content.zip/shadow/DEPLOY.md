# Run Shadow on your PC with Cloudflare Tunnel

Needs: Node.js 22.13 or newer, a free Cloudflare account, a domain on Cloudflare DNS.

1. Double-click start.bat . It listens only on this PC.
2. Install cloudflared (winget install Cloudflare.cloudflared), then in cmd:
     cloudflared tunnel login
     cloudflared tunnel create shadow
     cloudflared tunnel route dns shadow chat.YOURDOMAIN.com
3. Create %USERPROFILE%\.cloudflared\config.yml:
     tunnel: shadow
     credentials-file: C:\Users\YOU\.cloudflared\<TUNNEL-ID>.json
     ingress:
       - hostname: chat.YOURDOMAIN.com
         service: http://localhost:3000
       - service: http_status:404
4. Run: cloudflared tunnel run shadow      (or install as a service, as admin: cloudflared service install)
5. Open https://chat.YOURDOMAIN.com and create the FIRST account (leave the code empty): it becomes the owner.
   Then use the 'Invite codes' button to create a one-time code for each new user.
6. Daily backup at 03:00 (cmd as admin):
     schtasks /create /sc daily /tn ShadowBackup /st 03:00 /tr "C:\path\to\shadow\backup.bat"
   Copy data\backups and data\uploads to another drive or cloud regularly.
7. In Windows power settings set "Sleep: Never" so the PC stays on.
8. Then make the APK with pwabuilder.com using your https address (see earlier steps).

9. Create the FIRST (owner) account on the server device itself at http://localhost:3000. Others need one-time codes.

## Voice and video calls
Calls need https (or localhost). By default they use a public STUN server, which works for many Wi-Fi users
but not all mobile networks. For reliable calls set up a TURN server (for example coturn) and set:
  TURN_URLS=turn:turn.yourdomain.com:3478,turns:turn.yourdomain.com:5349
  TURN_SECRET=your-coturn-static-auth-secret        (or TURN_USER and TURN_PASS)
