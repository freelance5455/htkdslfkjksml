#!/data/data/com.termux/files/usr/bin/bash
# Updates Shadow from the newest shadow*.zip in your Download folder, keeps your data, and starts it.
ZIPDIR="${ZIPDIR:-/storage/emulated/0/Download}"
APP="${APP:-$HOME/shadow-app}"
command -v pkg >/dev/null && pkg install -y unzip procps >/dev/null 2>&1
pkill -f "^node .*server.js" 2>/dev/null; sleep 1
if [ -n "$SRCDIR" ]; then
  SRV=$(find "$SRCDIR" -name server.js -not -path "*/node_modules/*" | head -1)
else
  ZIP="${ZIP:-$(ls -t "$ZIPDIR"/shadow*.zip 2>/dev/null | head -1)}"
  [ -z "$ZIP" ] && ZIP=$(find /storage/emulated/0 -maxdepth 6 -iname "shadow*.zip" -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)
  if [ -z "$ZIP" ]; then echo "No shadow zip found. Download shadow.zip first, or give the unzipped folder: SRCDIR=/path/to/folder bash update-termux.sh"; exit 1; fi
  echo "Using zip: $ZIP"
  TMP="$HOME/shadow-unzip"; rm -rf "$TMP"; mkdir -p "$TMP"; unzip -q -o "$ZIP" -d "$TMP"
  SRV=$(find "$TMP" -name server.js -not -path "*/node_modules/*" | head -1)
fi
if [ -z "$SRV" ]; then echo "server.js not found in the zip or folder you gave"; exit 1; fi
SRC=$(dirname "$SRV")
echo "New files from: $SRC"
# find your existing data (accounts, messages, photos) from any older install
OLD=""
for d in "$APP/data" "$HOME/shadow/data" "$HOME/shadow/shadow/data"; do
  if [ -f "$d/shadow.db" ]; then OLD="$d"; break; fi
done
if [ -n "$OLD" ] && [ "$OLD" != "$APP/data" ]; then mkdir -p "$HOME/shadow-data-backup" && cp -r "$OLD"/. "$HOME/shadow-data-backup"/; fi
mkdir -p "$APP"
[ -d "$APP/data" ] && mv "$APP/data" "$HOME/.shadow-keep-data"
find "$APP" -mindepth 1 -maxdepth 1 ! -name node_modules -exec rm -rf {} +
cp -r "$SRC"/. "$APP"/
rm -rf "$APP/data"
if [ -d "$HOME/.shadow-keep-data" ]; then mv "$HOME/.shadow-keep-data" "$APP/data"
elif [ -n "$OLD" ]; then cp -r "$OLD" "$APP/data"; fi
cd "$APP" || exit 1
[ -z "$NOINSTALL" ] && npm install --no-audit --no-fund
echo
echo "Installed version: $(grep '"version"' package.json | tr -d ' ,')"
echo "Wi-Fi address(es):"; (ip -4 addr show wlan0 2>/dev/null || ifconfig 2>/dev/null) | grep -o 'inet [0-9.]*' | head -2
echo "Open http://localhost:3000 on this phone (the login page shows the version at the bottom)."
[ -n "$NOSTART" ] && exit 0
command -v termux-wake-lock >/dev/null && termux-wake-lock
HOST=0.0.0.0 exec node --disable-warning=ExperimentalWarning server.js
