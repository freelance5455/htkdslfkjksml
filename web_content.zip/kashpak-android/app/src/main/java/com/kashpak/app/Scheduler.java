package com.kashpak.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Schedules the alarms and reminders sent by the page with AlarmManager. */
final class Scheduler {

    static final String PREFS = "kashpak_sched";
    private static final int MAX_ITEMS = 200;
    private static final int TEST_CODE = 9999;

    private Scheduler() { }

    static synchronized void schedule(Context ctx, String json) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        // Cancel everything scheduled last time.
        int old = prefs.getInt("count", 0);
        for (int i = 0; i < old; i++) {
            Intent in = new Intent(ctx, AlarmReceiver.class);
            PendingIntent existing = PendingIntent.getBroadcast(
                    ctx, i, in, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (existing != null) {
                am.cancel(existing);
                existing.cancel();
            }
        }

        int n = 0;
        long next = 0;
        try {
            JSONArray arr = new JSONArray(json);
            long now = System.currentTimeMillis();
            for (int i = 0; i < arr.length() && n < MAX_ITEMS; i++) {
                JSONObject o = arr.getJSONObject(i);
                long at = o.getLong("at");
                if (at <= now + 1000) continue;

                Intent in = new Intent(ctx, AlarmReceiver.class);
                in.putExtra("title", o.optString("title", "Kashpak"));
                in.putExtra("body", o.optString("body", ""));
                in.putExtra("at", at);
                PendingIntent op = PendingIntent.getBroadcast(
                        ctx, n, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                PendingIntent show = PendingIntent.getActivity(
                        ctx, 1000 + n, new Intent(ctx, MainActivity.class),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), op);
                if (next == 0 || at < next) next = at;
                n++;
            }
        } catch (Exception ignored) {
            // A bad payload schedules nothing.
        }
        prefs.edit().putInt("count", n).putLong("next", next).putString("json", json).apply();
    }

    /** One test alarm, kept apart from the page's schedule so a sync never cancels it. */
    static void scheduleTest(Context ctx, int seconds) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = System.currentTimeMillis() + Math.max(5, seconds) * 1000L;
        Intent in = new Intent(ctx, AlarmReceiver.class);
        in.putExtra("title", "Kashpak test");
        in.putExtra("body", "Background alarms are working.");
        in.putExtra("at", at);
        PendingIntent op = PendingIntent.getBroadcast(
                ctx, TEST_CODE, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent show = PendingIntent.getActivity(
                ctx, 1999, new Intent(ctx, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), op);
    }

    static void rescheduleSaved(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = prefs.getString("json", null);
        if (json != null) schedule(ctx, json);
    }
}
