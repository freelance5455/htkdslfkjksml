package com.kashpak.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.util.ArrayList;

/** Exposed to the page as window.KashpakNative. */
public class NativeBridge {

    private final Context ctx;

    NativeBridge(Context context) {
        this.ctx = context.getApplicationContext();
    }

    /** json: [{"at": epochMillis, "title": "...", "body": "..."}, ...] */
    @JavascriptInterface
    public void sync(String json) {
        Scheduler.schedule(ctx, json);
    }

    /** Rings a test notification after the given number of seconds. */
    @JavascriptInterface
    public void test(int seconds) {
        Scheduler.scheduleTest(ctx, seconds);
    }

    /** Reports what Android allows, as JSON. */
    @JavascriptInterface
    public String status() {
        try {
            JSONObject o = new JSONObject();
            NotificationManager nm =
                    (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            o.put("notifications", nm != null && nm.areNotificationsEnabled());
            int importance = -1;
            if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                NotificationChannel ch = nm.getNotificationChannel("kashpak_alarm");
                if (ch != null) importance = ch.getImportance();
            }
            o.put("channelImportance", importance);
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            o.put("batteryUnrestricted",
                    pm != null && pm.isIgnoringBatteryOptimizations(ctx.getPackageName()));
            SharedPreferences p = ctx.getSharedPreferences(Scheduler.PREFS, Context.MODE_PRIVATE);
            o.put("scheduled", p.getInt("count", 0));
            o.put("next", p.getLong("next", 0));
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    /**
     * Adds an alarm to the phone's own Clock app. The Clock app keeps ringing even when the phone
     * stops Kashpak. days: comma separated, 0 = Sunday ... 6 = Saturday, empty = rings once.
     */
    @JavascriptInterface
    public void setClockAlarm(int hour, int minute, String label, String days) {
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label == null ? "Kashpak" : label)
                .putExtra(AlarmClock.EXTRA_VIBRATE, true)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        if (days != null && days.trim().length() > 0) {
            ArrayList<Integer> list = new ArrayList<>();
            for (String d : days.split(",")) {
                try {
                    list.add(Integer.parseInt(d.trim()) + 1); // Calendar.SUNDAY is 1
                } catch (NumberFormatException ignored) {
                    // Skip anything that is not a number.
                }
            }
            if (!list.isEmpty()) i.putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS, list);
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
        } catch (Exception ignored) {
            // No Clock app can handle this.
        }
    }

    /** which: "notifications", "battery" or "app". */
    @JavascriptInterface
    public void openSettings(String which) {
        String pkg = ctx.getPackageName();
        Intent i;
        if ("battery".equals(which)) {
            i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + pkg));
        } else if ("notifications".equals(which) && Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + pkg));
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(fallback);
            } catch (Exception ignored) {
                // Nothing more to try.
            }
        }
    }
}
