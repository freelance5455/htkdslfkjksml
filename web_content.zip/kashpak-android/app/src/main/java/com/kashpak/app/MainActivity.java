package com.kashpak.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    /** True while the app is on screen. The alarm receiver reads this. */
    static volatile boolean foreground = false;

    private static final int REQ_FILE = 1;
    private static final int REQ_NOTIFY = 2;
    private WebView web;
    private ValueCallback<Uri[]> pendingChooser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep the screen on while Kashpak is open.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Android 13 and newer need permission to show alarm notifications.
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIFY);
        }

        AlarmReceiver.ensureChannel(getApplicationContext());

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new NativeBridge(this), "KashpakNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (ActivityNotFoundException ignored) { }
                    return true;
                }
                return false;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (pendingChooser != null) {
                    pendingChooser.onReceiveValue(null);
                }
                pendingChooser = callback;

                Intent intent;
                boolean wantsAudio = false;
                for (String t : params.getAcceptTypes()) {
                    if (t != null && t.startsWith("audio")) wantsAudio = true;
                }
                if (params.isCaptureEnabled() && wantsAudio) {
                    // The page's Record button: open the phone's voice recorder.
                    intent = new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION);
                } else {
                    intent = params.createIntent();
                }
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    pendingChooser = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && pendingChooser != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            pendingChooser.onReceiveValue(result);
            pendingChooser = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        foreground = false;
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        foreground = true;
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        foreground = false;
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
