# Kashpak for Android

A small Android app that shows the Kashpak page full screen and rings your alarms and reminders when the app is closed.

## Build the APK
1. Install Android Studio (https://developer.android.com/studio) on a computer.
2. Choose File > Open and select this folder. Let Gradle sync finish.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio shows a "locate" link. Copy app-debug.apk to your phone and open it.
   You may need to allow "Install unknown apps" for the app you open it from.

## First run on the phone
- Allow notifications when asked. Without this, alarms cannot ring while the app is closed.
- Open Kashpak once after you add or change alarms so they are scheduled.

## Check that background ringing works
Open the Alarms tab and find the Background alarms card. It shows whether notifications are allowed, whether battery use is unrestricted, and what is scheduled. Tap Test in 1 minute, press Home, and wait. Fix any red item, then test again.

## Alarms that survive the phone's battery manager
Some phones stop an app's alarms after a few hours or when the app is swiped away. On each alarm, tap Clock to also add it to the phone's Clock app, which keeps ringing. If you turn the alarm off or delete it in Kashpak, delete it in the Clock app too.

## How ringing works
- Alarms and reminders are handed to Android's alarm clock, so they ring when the app is closed or the phone is locked.
- Each ring is a notification with the alarm sound that repeats for up to a minute. Tap it to open Kashpak.
- Alarms are planned 14 days ahead and reminders 48 hours ahead. Opening the app refreshes them.
- After a restart, the saved schedule is set again.
- Force-stopping the app from Settings cancels its alarms until you open it again.

## Other notes
- The Record button opens your phone's voice recorder.
- Fonts and the Excel reader load from the internet, so Excel import needs a connection.
- The screen stays on while the app is open.
- The Speak and Dictate buttons are not available in the app.
