package com.capri.mobile;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static MainActivity self;
    // Served over https so the camera/mic (getUserMedia) and the tracker library work reliably.
    static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    final Handler ui = new Handler(Looper.getMainLooper());
    WebView web;
    SpeechRecognizer sr;
    TextToSpeech tts;
    PermissionRequest pendingPerm;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        self = this;
        getWindow().setStatusBarColor(0xff08050b);
        getWindow().setNavigationBarColor(0xff08050b);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/web/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web = new WebView(this);
        web.setBackgroundColor(0xff08050b);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setAllowFileAccess(false);
        web.addJavascriptInterface(new Bridge(), "Capri");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        web.setWebChromeClient(chrome());
        // Keep the page clear of the status bar, nav bar and keyboard (Android 15 draws edge-to-edge).
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xff08050b);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(
                    ins.getSystemWindowInsetLeft(),
                    ins.getSystemWindowInsetTop(),
                    ins.getSystemWindowInsetRight(),
                    ins.getSystemWindowInsetBottom());
            return ins.consumeSystemWindowInsets();
        });
        setContentView(root);
        web.loadUrl(HOME);
        tts = new TextToSpeech(this, s -> {
            if (s == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault());
        });
    }

    // ---------- Camera / microphone permission for the in-app camera ----------
    WebChromeClient chrome() {
        return new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> handlePerm(r));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest r) {
                if (pendingPerm == r) pendingPerm = null;
            }
        };
    }

    void handlePerm(PermissionRequest r) {
        ArrayList<String> need = new ArrayList<>();
        for (String res : r.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)
                    && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
                need.add("android.permission.CAMERA");
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)
                    && checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                need.add("android.permission.RECORD_AUDIO");
            }
        }
        if (need.isEmpty()) {
            r.grant(r.getResources());
            return;
        }
        if (pendingPerm != null) pendingPerm.deny();
        pendingPerm = r;
        requestPermissions(need.toArray(new String[0]), 8);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] g) {
        super.onRequestPermissionsResult(code, p, g);
        boolean ok = g.length > 0;
        for (int x : g) if (x != PackageManager.PERMISSION_GRANTED) ok = false;
        if (code == 8 && pendingPerm != null) {
            PermissionRequest r = pendingPerm;
            pendingPerm = null;
            if (ok) r.grant(r.getResources());
            else r.deny();
        } else if (code == 7) {
            if (ok) startSpeech();
            else result("Microphone permission is needed for voice input.");
        }
    }

    // ---------- Launching / switching apps ----------
    static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");
    }

    boolean startSafely(final Intent i) {
        ui.post(() -> {
            try {
                startActivity(i);
            } catch (Exception e) {
                result("Couldn't open that app.");
            }
        });
        return true;
    }

    boolean launchPackage(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return startSafely(i);
    }

    // Finds the best installed launcher app for a spoken/typed name and opens it.
    boolean launchByName(String name) {
        String q = norm(name);
        if (q.isEmpty()) return false;
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        String best = null;
        int bestScore = 0, bestLen = Integer.MAX_VALUE;
        for (ResolveInfo x : pm.queryIntentActivities(main, 0)) {
            String pkg = x.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            String l = norm(x.loadLabel(pm).toString());
            if (l.isEmpty()) continue;
            int score = l.equals(q) ? 4
                    : l.startsWith(q) ? 3
                    : l.contains(q) ? 2
                    : (l.length() >= 3 && q.contains(l)) ? 1 : 0;
            if (score > bestScore || (score == bestScore && score > 0 && l.length() < bestLen)) {
                best = pkg;
                bestScore = score;
                bestLen = l.length();
            }
        }
        if (best != null) return launchPackage(best);
        return launchAlias(q);
    }

    // Friendly names that don't match an app label on every phone (e.g. "browser", "settings").
    boolean launchAlias(String q) {
        Intent i = null;
        String cat = null;
        switch (q) {
            case "settings":
            case "androidsettings":
            case "phonesettings":
                i = new Intent(Settings.ACTION_SETTINGS);
                break;
            case "wifi":
            case "wifisettings":
                i = new Intent(Settings.ACTION_WIFI_SETTINGS);
                break;
            case "bluetooth":
            case "bluetoothsettings":
                i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                break;
            case "camera":
            case "cameraapp":
                i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                break;
            case "phone":
            case "dialer":
            case "calls":
                i = new Intent(Intent.ACTION_DIAL);
                break;
            case "browser":
            case "internet":
            case "web":
            case "webbrowser":
                cat = Intent.CATEGORY_APP_BROWSER;
                break;
            case "gallery":
            case "photos":
            case "pictures":
                cat = Intent.CATEGORY_APP_GALLERY;
                break;
            case "messages":
            case "messaging":
            case "texts":
            case "sms":
                cat = Intent.CATEGORY_APP_MESSAGING;
                break;
            case "maps":
            case "map":
                cat = Intent.CATEGORY_APP_MAPS;
                break;
            case "email":
            case "mail":
                cat = Intent.CATEGORY_APP_EMAIL;
                break;
            case "calendar":
                cat = Intent.CATEGORY_APP_CALENDAR;
                break;
            case "music":
                cat = Intent.CATEGORY_APP_MUSIC;
                break;
            case "spotify":
            case "spotifyapp":
                if (launchPackage("com.spotify.music")) return true;
                i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/"));
                break;
            case "clock":
            case "alarms":
            case "alarm":
                i = new Intent("android.intent.action.SHOW_ALARMS");
                break;
            case "contacts":
                cat = Intent.CATEGORY_APP_CONTACTS;
                break;
            case "calculator":
                cat = Intent.CATEGORY_APP_CALCULATOR;
                break;
            default:
                break;
        }
        if (cat != null) i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return startSafely(i);
    }

    class Bridge {
        @JavascriptInterface
        public boolean openApp(String n) {
            return launchByName(n);
        }

        @JavascriptInterface
        public boolean openPackage(String p) {
            return launchPackage(p);
        }

        @JavascriptInterface
        public void listApps() {
            new Thread(() -> {
                try {
                    PackageManager pm = getPackageManager();
                    Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
                    ArrayList<String[]> apps = new ArrayList<>();
                    HashSet<String> seen = new HashSet<>();
                    for (ResolveInfo x : list) {
                        String pkg = x.activityInfo.packageName;
                        if (!seen.add(pkg)) continue;
                        apps.add(new String[]{x.loadLabel(pm).toString(), pkg});
                    }
                    Collections.sort(apps, (a, c) -> a[0].compareToIgnoreCase(c[0]));
                    JSONArray arr = new JSONArray();
                    for (String[] a : apps) {
                        JSONObject o = new JSONObject();
                        o.put("label", a[0]);
                        o.put("packageName", a[1]);
                        arr.put(o);
                    }
                    final String json = arr.toString();
                    ui.post(() -> web.evaluateJavascript("capriAppsResult(" + JSONObject.quote(json) + ")", null));
                } catch (Exception e) {
                    result("Unable to list apps.");
                }
            }).start();
        }

        // Capri steps aside (back to the app you were just in), then types into that app's text field.
        @JavascriptInterface
        public boolean openWeb(final String url) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (Exception e) {
                result("No browser is available to open that link.");
                return false;
            }
        }

        @JavascriptInterface
        public boolean typeText(final String s) {
            final CapriAccessibilityService svc = CapriAccessibilityService.live;
            if (svc == null) return false;
            ui.post(() -> {
                moveTaskToBack(true);
                ui.postDelayed(() -> svc.typeIntoOtherApp(s), 1000);
            });
            return true;
        }

        @JavascriptInterface
        public void globalAction(final String s) {
            if ("switch".equals(s)) {
                ui.post(() -> moveTaskToBack(true));
                return;
            }
            final CapriAccessibilityService svc = CapriAccessibilityService.live;
            if (svc == null) {
                result("Enable Capri App Control in Accessibility settings.");
                return;
            }
            if ("back".equals(s)) {
                ui.post(() -> {
                    moveTaskToBack(true);
                    ui.postDelayed(() -> svc.global("back"), 900);
                });
                return;
            }
            svc.global(s);
        }

        @JavascriptInterface
        public void takeScreenshot() {
            final CapriAccessibilityService svc = CapriAccessibilityService.live;
            if (svc == null) {
                result("Enable Capri App Control in Accessibility settings.");
                return;
            }
            ui.post(() -> {
                moveTaskToBack(true);
                ui.postDelayed(() -> svc.screenshot(), 1000);
            });
        }

        @JavascriptInterface
        public void speak(final String s) {
            ui.post(() -> {
                if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "capri");
            });
        }

        @JavascriptInterface
        public void listen() {
            ui.post(() -> startSpeech());
        }

        /** Show or hide the floating ✦ overlay that sits over any app (needs Accessibility). */
        @JavascriptInterface
        public void setFloater(final boolean on) {
            ui.post(() -> {
                CapriAccessibilityService svc = CapriAccessibilityService.live;
                if (svc == null) {
                    if (on) {
                        result("Enable Capri App Control in Accessibility settings so the floating Capri can sit over other apps.");
                    }
                    return;
                }
                svc.setFloaterVisible(on);
                result(on
                        ? "Floating Capri is on — it can sit over any app. Drag to move, tap to return."
                        : "Floating Capri hidden.");
            });
        }
    }

    // ---------- Voice input ----------
    void startSpeech() {
        if (checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 7);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            result("Speech recognition is unavailable on this phone.");
            return;
        }
        if (sr != null) sr.destroy();
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float f) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}

            public void onError(int e) {
                if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    result("I didn't catch that. Tap the mic and try again.");
                } else if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    result("Microphone permission is needed for voice input.");
                } else {
                    result("Voice input failed (code " + e + "). Try again.");
                }
            }

            public void onResults(Bundle b) {
                ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (a != null && !a.isEmpty()) {
                    web.evaluateJavascript("capriVoiceResult(" + JSONObject.quote(a.get(0)) + ")", null);
                }
            }

            public void onPartialResults(Bundle b) {}
            public void onEvent(int e, Bundle b) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        sr.startListening(i);
    }

    static void result(final String s) {
        final MainActivity a = self;
        if (a != null) {
            a.runOnUiThread(() -> a.web.evaluateJavascript("capriActionResult(" + JSONObject.quote(s) + ")", null));
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.capriBack?window.capriBack():false)", v -> {
            if ("true".equals(v)) return;
            if (web.canGoBack()) web.goBack();
            else finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (sr != null) sr.destroy();
        if (tts != null) tts.shutdown();
        if (self == this) self = null;
        super.onDestroy();
    }
}
