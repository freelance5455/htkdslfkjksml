package com.capri.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.ScreenshotResult;
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;

public class CapriAccessibilityService extends AccessibilityService {
    public static CapriAccessibilityService live;
    WindowManager wm;
    View floater;
    WindowManager.LayoutParams floaterParams;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        live = this;
        showCapriFloater();
    }

    void showCapriFloater() {
        if (floater != null) return;
        try {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            TextView face = new TextView(this);
            face.setText("✦");
            face.setTextColor(Color.BLACK);
            face.setTextSize(29);
            face.setGravity(Gravity.CENTER);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(0xfffff329);
            bg.setStroke(dp(3), 0xffff174f);
            face.setBackground(bg);
            face.setElevation(dp(12));
            face.setContentDescription("Capri floating assistant — drag to move, tap to open");
            floaterParams = new WindowManager.LayoutParams(
                    dp(62), dp(62),
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            floaterParams.gravity = Gravity.TOP | Gravity.END;
            floaterParams.x = dp(12);
            floaterParams.y = dp(190);
            face.setOnTouchListener(new View.OnTouchListener() {
                float sx, sy;
                int ox, oy;
                boolean moved;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = e.getRawX();
                            sy = e.getRawY();
                            ox = floaterParams.x;
                            oy = floaterParams.y;
                            moved = false;
                            return true;
                        case MotionEvent.ACTION_MOVE: {
                            float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                            if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                            floaterParams.x = Math.max(0, ox - (int) dx);
                            floaterParams.y = Math.max(0, oy + (int) dy);
                            wm.updateViewLayout(floater, floaterParams);
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                            if (!moved) openCapri();
                            return true;
                        default:
                            return true;
                    }
                }
            });
            floater = face;
            wm.addView(floater, floaterParams);
        } catch (Exception ignored) {
            floater = null;
        }
    }

    void openCapri() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(i);
    }

    public void setFloaterVisible(boolean on) {
        if (on) {
            showCapriFloater();
        } else {
            try {
                if (wm != null && floater != null) wm.removeView(floater);
            } catch (Exception ignored) {
            }
            floater = null;
        }
    }

    int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        try {
            if (wm != null && floater != null) wm.removeView(floater);
        } catch (Exception ignored) {
        }
        floater = null;
        if (live == this) live = null;
        super.onDestroy();
    }

    void say(String msg) {
        try {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {
        }
        MainActivity.result(msg);
    }

    AccessibilityNodeInfo firstEditable(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isEditable() && n.isVisibleToUser()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = firstEditable(n.getChild(i));
            if (r != null) return r;
        }
        return null;
    }

    // Called after Capri has stepped aside: types into the text box of whatever app is now in front.
    public void typeIntoOtherApp(String s) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            say("I couldn't read the screen. Try again.");
            return;
        }
        CharSequence pkg = root.getPackageName();
        if (pkg != null && pkg.toString().equals(getPackageName())) {
            say("No other app was in front. Open an app and tap its text box first, then ask me again.");
            return;
        }
        AccessibilityNodeInfo n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (n == null || !n.isEditable()) n = firstEditable(root);
        if (n == null) {
            say("I couldn't find a text box in that app. Tap one first, then ask again.");
            return;
        }
        CharSequence cur = (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText()) ? null : n.getText();
        String base = cur == null ? "" : cur.toString();
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + s);
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        say(n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b) ? "Typed it." : "That app blocked typing.");
    }

    public void global(String s) {
        if ("back".equals(s)) performGlobalAction(GLOBAL_ACTION_BACK);
        else if ("home".equals(s)) performGlobalAction(GLOBAL_ACTION_HOME);
        else if ("recents".equals(s)) performGlobalAction(GLOBAL_ACTION_RECENTS);
    }

    public void screenshot() {
        if (Build.VERSION.SDK_INT < 30) {
            say("Screenshots need Android 11+.");
            return;
        }
        takeScreenshot(0, getMainExecutor(), new TakeScreenshotCallback() {
            @Override
            public void onFailure(int errorCode) {
                say("Screenshot failed. Check Accessibility permission.");
            }

            @Override
            public void onSuccess(ScreenshotResult r) {
                try {
                    HardwareBuffer hb = r.getHardwareBuffer();
                    Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                    if (hw == null) throw new Exception("no bitmap");
                    Bitmap b = hw.copy(Bitmap.Config.ARGB_8888, false);
                    hw.recycle();
                    hb.close();
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Images.Media.DISPLAY_NAME, "Capri-" + System.currentTimeMillis() + ".png");
                    v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Capri");
                    Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    if (u == null) throw new Exception("no uri");
                    OutputStream o = getContentResolver().openOutputStream(u);
                    if (o == null) throw new Exception("no stream");
                    b.compress(Bitmap.CompressFormat.PNG, 100, o);
                    o.close();
                    b.recycle();
                    say("Screenshot saved in Pictures/Capri.");
                } catch (Exception e) {
                    say("Could not save screenshot.");
                }
            }
        });
    }
}
