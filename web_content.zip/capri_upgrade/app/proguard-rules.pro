# Capri Mobile – keep JS bridge and accessibility entry points
-keepclassmembers class com.capri.mobile.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.capri.mobile.CapriAccessibilityService { *; }
