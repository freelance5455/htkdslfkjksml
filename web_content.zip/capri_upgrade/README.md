# Capri Mobile 2.4 — Local app control

Pink/red, yellow, neon green, black and purple character-inspired interface. **No cloud AI is bundled** — replies are local templates and device actions only.

## Commands
- `open YouTube` / `switch to Maps` — launch a matching installed app (loose name match + common aliases).
- `show apps` — browse installed launcher apps.
- `type Hello there` — type into the currently focused text field in another app.
- `take a screenshot` — save to Pictures/Capri (Android 11+).
- `go back`, `go home`, `recent apps`, `last app`.
- Tap the microphone for Android speech recognition; replies can be spoken aloud (variety of local lines).

## Tools tab (no AI)
- **Camera** — photos, video, filters (pixelated low-quality, mono, warm and cool), dog-ear/tongue overlay, hand tracking, detailed face mesh and full-body pose tracking. First-time tracking downloads MediaPipe models and requires internet.
- Screenshot, Open apps, Last app, Home, Recents.
- Focus timer (local 25‑minute countdown).
- Device help.
- Local Notes, Calendar events, Clock, Timer and To-do Lists (saved on this phone).
- Spotify shortcut: opens the installed Spotify app or falls back to the Spotify web player.

## Floating Capri (hover over any app)
Enable **Capri App Control** in Android Settings → Accessibility. A yellow ✦ overlay sits above other apps: drag to move, tap to return to Capri. Toggle it in **Settings → Floating Capri**.

## Enable cross-app control
Settings → Accessibility → Capri App Control. Capri asks for confirmation before typing, launching an app, or capturing a screenshot. Focus the destination text field yourself before `type`.

## Build
Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17.

```bash
# From project root (or open in Android Studio)
./gradlew assembleDebug
# APK → app/build/outputs/apk/debug/app-debug.apk
```

This source ZIP intentionally includes a GitHub Actions workflow that downloads Gradle 8.9 and builds the APK in the cloud. If building locally and the Gradle wrapper jar is missing, generate it with:
```bash
gradle wrapper --gradle-version 8.9
```

## Limits
Camera filters are previewed live and applied to saved photos; video recording may retain the unfiltered camera stream on some Android/WebView versions. Dog-ear/tongue effects require face-mesh tracking to be switched on. Full-body pose tracking is CPU intensive and works best with the whole person visible and good lighting. Spotify playback/account controls are handled by Spotify itself, not embedded into Capri.


Launches launcher-visible apps and types into focused editable fields when Accessibility is enabled. Some apps block text injection; secure fields are not bypassed. Screenshots need Android 11+ and Accessibility. Camera frames and MediaPipe models stay on-device after first download. No AI backend, code generation, or web research is included.
