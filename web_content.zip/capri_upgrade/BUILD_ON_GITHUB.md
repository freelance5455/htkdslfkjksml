# Build Capri 2.4 from an Android phone

1. Download `Capri_2.4_Android_Project.zip` and extract it.
2. In your GitHub repository, upload the **contents** of the extracted folder (not the ZIP itself). Make sure `.github/workflows/android.yml` is included. GitHub may hide `.github`; use the repository's web editor or upload the folder from a browser that supports hidden folders.
3. Commit the upload to `main` (or `master`).
4. Open the repository's **Actions** tab.
5. Select **Build Capri Android APK**, then open the newest run.
6. Wait for the green check mark. Open the run's **Artifacts** section and download `Capri-2.4-debug-apk`.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. If Android blocks installation, allow your browser or Files app to install unknown apps.

The workflow downloads Gradle 8.9, installs Android SDK platform 35/build tools, builds the APK, and uploads it as a downloadable Actions artifact. The first camera-tracking launch downloads MediaPipe model files, so connect to Wi-Fi and allow camera access.
