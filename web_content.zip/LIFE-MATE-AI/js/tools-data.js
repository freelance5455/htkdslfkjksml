window.LM_TOOLS = [
  {
    "id": 1,
    "name": "AI Prompt Builder",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 2,
    "name": "Blog Outline Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 3,
    "name": "Article Outline Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 4,
    "name": "Email Writer Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 5,
    "name": "Professional Email Rewriter",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 6,
    "name": "Social Caption Writer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 7,
    "name": "YouTube Description Builder",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 8,
    "name": "TikTok Hook Ideas",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 9,
    "name": "Instagram Bio Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 10,
    "name": "Product Description Writer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 11,
    "name": "Business Name Ideas",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 12,
    "name": "Brand Slogan Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 13,
    "name": "Story Idea Generator",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 14,
    "name": "Speech Outline Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 15,
    "name": "Essay Planner",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 16,
    "name": "Summary Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 17,
    "name": "Text Simplifier",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 18,
    "name": "Tone Changer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 19,
    "name": "Grammar Checklist",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 20,
    "name": "Ad Copy Framework",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 21,
    "name": "Marketing Plan Outline",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 22,
    "name": "Content Calendar Builder",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 23,
    "name": "Video Script Planner",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 24,
    "name": "Reel Script Planner",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 25,
    "name": "Hashtag Suggestion Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 26,
    "name": "Call To Action Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 27,
    "name": "FAQ Generator",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 28,
    "name": "Customer Reply Templates",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 29,
    "name": "Job Cover Letter Builder",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 30,
    "name": "CV Bullet Improver",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 31,
    "name": "Meeting Agenda Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 32,
    "name": "Meeting Minutes Formatter",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 33,
    "name": "Study Notes Organizer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 34,
    "name": "Flashcard Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 35,
    "name": "Quiz Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 36,
    "name": "Prompt Enhancer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 37,
    "name": "Image Prompt Builder",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 38,
    "name": "Video Prompt Builder",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 39,
    "name": "Character Profile Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 40,
    "name": "Worldbuilding Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 41,
    "name": "Poem Starter",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 42,
    "name": "Urdu Caption Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 43,
    "name": "WhatsApp Message Writer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 44,
    "name": "Announcement Writer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 45,
    "name": "Thank You Message Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 46,
    "name": "Invitation Writer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 47,
    "name": "Complaint Letter Builder",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 48,
    "name": "Proposal Outline Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 49,
    "name": "Press Release Outline",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 50,
    "name": "Newsletter Planner",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 51,
    "name": "Landing Page Copy Planner",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 52,
    "name": "SEO Title Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 53,
    "name": "Meta Description Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 54,
    "name": "Keyword Brainstormer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 55,
    "name": "Tagline Variations",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 56,
    "name": "Brand Voice Guide",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 57,
    "name": "Story Hook Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 58,
    "name": "Podcast Outline Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 59,
    "name": "Course Outline Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 60,
    "name": "Lesson Plan Builder",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 61,
    "name": "Product Listing Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 62,
    "name": "Shorten Text",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 63,
    "name": "Expand Outline",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 64,
    "name": "Bullet Point Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 65,
    "name": "Paragraph Formatter",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 66,
    "name": "Headline Variations",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 67,
    "name": "Name Generator",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 68,
    "name": "Username Ideas",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 69,
    "name": "Bio Shortener",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 70,
    "name": "Content Repurposing Planner",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 71,
    "name": "Ad Headline Maker",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 72,
    "name": "Sales Pitch Outline",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 73,
    "name": "Cold Message Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 74,
    "name": "Customer Support Reply",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 75,
    "name": "Business About Us Writer",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 76,
    "name": "Portfolio Bio Helper",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 77,
    "name": "Creator Media Kit Outline",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 78,
    "name": "Video Chapter Planner",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 79,
    "name": "YouTube Pinned Comment",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 80,
    "name": "Comment Reply Ideas",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 81,
    "name": "Urdu-English Caption Formatter",
    "category": "AI & Writing",
    "op": "template"
  },
  {
    "id": 82,
    "name": "Profit Calculator",
    "category": "Business & Finance",
    "op": "profit"
  },
  {
    "id": 83,
    "name": "Profit Margin Calculator",
    "category": "Business & Finance",
    "op": "margin"
  },
  {
    "id": 84,
    "name": "Markup Calculator",
    "category": "Business & Finance",
    "op": "markup"
  },
  {
    "id": 85,
    "name": "Discount Calculator",
    "category": "Business & Finance",
    "op": "discount"
  },
  {
    "id": 86,
    "name": "Sales Tax Calculator",
    "category": "Business & Finance",
    "op": "tax"
  },
  {
    "id": 87,
    "name": "VAT Calculator",
    "category": "Business & Finance",
    "op": "tax"
  },
  {
    "id": 88,
    "name": "Invoice Total Calculator",
    "category": "Business & Finance",
    "op": "invoice"
  },
  {
    "id": 89,
    "name": "Invoice Number Generator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 90,
    "name": "Receipt Maker",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 91,
    "name": "Commission Calculator",
    "category": "Business & Finance",
    "op": "commission"
  },
  {
    "id": 92,
    "name": "Break-even Calculator",
    "category": "Business & Finance",
    "op": "breakeven"
  },
  {
    "id": 93,
    "name": "Loan Payment Estimator",
    "category": "Business & Finance",
    "op": "loan"
  },
  {
    "id": 94,
    "name": "Simple Interest Calculator",
    "category": "Business & Finance",
    "op": "interest"
  },
  {
    "id": 95,
    "name": "Compound Interest Calculator",
    "category": "Business & Finance",
    "op": "compound"
  },
  {
    "id": 96,
    "name": "Savings Goal Calculator",
    "category": "Business & Finance",
    "op": "savings"
  },
  {
    "id": 97,
    "name": "Budget Planner",
    "category": "Business & Finance",
    "op": "budget"
  },
  {
    "id": 98,
    "name": "Monthly Expense Splitter",
    "category": "Business & Finance",
    "op": "splitbill"
  },
  {
    "id": 99,
    "name": "Weekly Budget Splitter",
    "category": "Business & Finance",
    "op": "splitbill"
  },
  {
    "id": 100,
    "name": "Bill Splitter",
    "category": "Business & Finance",
    "op": "splitbill"
  },
  {
    "id": 101,
    "name": "Tip Calculator",
    "category": "Business & Finance",
    "op": "tip"
  },
  {
    "id": 102,
    "name": "Cash Change Calculator",
    "category": "Business & Finance",
    "op": "change"
  },
  {
    "id": 103,
    "name": "Hourly Pay Calculator",
    "category": "Business & Finance",
    "op": "hourly"
  },
  {
    "id": 104,
    "name": "Overtime Pay Calculator",
    "category": "Business & Finance",
    "op": "overtime"
  },
  {
    "id": 105,
    "name": "Salary Annualizer",
    "category": "Business & Finance",
    "op": "annualpay"
  },
  {
    "id": 106,
    "name": "Salary Monthly Calculator",
    "category": "Business & Finance",
    "op": "monthlypay"
  },
  {
    "id": 107,
    "name": "Unit Price Comparator",
    "category": "Business & Finance",
    "op": "unitprice"
  },
  {
    "id": 108,
    "name": "Inventory Value Calculator",
    "category": "Business & Finance",
    "op": "inventory"
  },
  {
    "id": 109,
    "name": "Stock Reorder Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 110,
    "name": "Fuel Cost Calculator",
    "category": "Business & Finance",
    "op": "fuelcost"
  },
  {
    "id": 111,
    "name": "Installment Calculator",
    "category": "Business & Finance",
    "op": "installment"
  },
  {
    "id": 112,
    "name": "Business Days Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 113,
    "name": "Sales Target Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 114,
    "name": "Revenue Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 115,
    "name": "Cost Per Unit Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 116,
    "name": "Gross Margin Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 117,
    "name": "Net Profit Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 118,
    "name": "Tax Inclusive Price",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 119,
    "name": "Tax Exclusive Price",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 120,
    "name": "Discounted Price Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 121,
    "name": "Price Increase Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 122,
    "name": "Price Decrease Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 123,
    "name": "Commission Splitter",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 124,
    "name": "Rent Split Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 125,
    "name": "Savings Progress Tracker",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 126,
    "name": "Loan Affordability Helper",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 127,
    "name": "Investment Growth Estimator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 128,
    "name": "Currency Amount Formatter",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 129,
    "name": "Invoice Text Builder",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 130,
    "name": "Purchase Order Template",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 131,
    "name": "Quotation Template",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 132,
    "name": "Payment Reminder Writer",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 133,
    "name": "Customer Record Formatter",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 134,
    "name": "Daily Sales Sheet Maker",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 135,
    "name": "Cashbook Entry Formatter",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 136,
    "name": "Expense Report Maker",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 137,
    "name": "Profit Sharing Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 138,
    "name": "Retail Price Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 139,
    "name": "Wholesale Price Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 140,
    "name": "Product Bundle Price Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 141,
    "name": "Break-even Units Calculator",
    "category": "Business & Finance",
    "op": "template"
  },
  {
    "id": 142,
    "name": "JSON Formatter",
    "category": "Developer & Web",
    "op": "jsonformat"
  },
  {
    "id": 143,
    "name": "JSON Validator",
    "category": "Developer & Web",
    "op": "jsonvalid"
  },
  {
    "id": 144,
    "name": "JSON Minifier",
    "category": "Developer & Web",
    "op": "jsonmin"
  },
  {
    "id": 145,
    "name": "JSON to CSV",
    "category": "Developer & Web",
    "op": "jsoncsv"
  },
  {
    "id": 146,
    "name": "CSV to JSON",
    "category": "Developer & Web",
    "op": "csvjson"
  },
  {
    "id": 147,
    "name": "Base64 Encoder",
    "category": "Developer & Web",
    "op": "b64encode"
  },
  {
    "id": 148,
    "name": "Base64 Decoder",
    "category": "Developer & Web",
    "op": "b64decode"
  },
  {
    "id": 149,
    "name": "URL Encoder",
    "category": "Developer & Web",
    "op": "urlencode"
  },
  {
    "id": 150,
    "name": "URL Decoder",
    "category": "Developer & Web",
    "op": "urldecode"
  },
  {
    "id": 151,
    "name": "HTML Escape",
    "category": "Developer & Web",
    "op": "htmlescape"
  },
  {
    "id": 152,
    "name": "HTML Unescape",
    "category": "Developer & Web",
    "op": "htmlunescape"
  },
  {
    "id": 153,
    "name": "HTML Tag Stripper",
    "category": "Developer & Web",
    "op": "striphtml"
  },
  {
    "id": 154,
    "name": "CSS Minifier",
    "category": "Developer & Web",
    "op": "minify"
  },
  {
    "id": 155,
    "name": "JavaScript Minifier",
    "category": "Developer & Web",
    "op": "minify"
  },
  {
    "id": 156,
    "name": "Regex Tester",
    "category": "Developer & Web",
    "op": "regex"
  },
  {
    "id": 157,
    "name": "Regex Escape",
    "category": "Developer & Web",
    "op": "regexescape"
  },
  {
    "id": 158,
    "name": "UUID Generator",
    "category": "Developer & Web",
    "op": "uuid"
  },
  {
    "id": 159,
    "name": "Password Generator",
    "category": "Developer & Web",
    "op": "password"
  },
  {
    "id": 160,
    "name": "SHA-256 Hash",
    "category": "Developer & Web",
    "op": "sha256"
  },
  {
    "id": 161,
    "name": "HEX to RGB",
    "category": "Developer & Web",
    "op": "hextorgb"
  },
  {
    "id": 162,
    "name": "RGB to HEX",
    "category": "Developer & Web",
    "op": "rgbtohex"
  },
  {
    "id": 163,
    "name": "Color Contrast Checker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 164,
    "name": "CSS Gradient Maker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 165,
    "name": "CSS Box Shadow Maker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 166,
    "name": "CSS Button Generator",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 167,
    "name": "CSS Glass Card Generator",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 168,
    "name": "CSS Neon Text Generator",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 169,
    "name": "CSS Flexbox Snippet",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 170,
    "name": "CSS Grid Snippet",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 171,
    "name": "CSS Media Query Maker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 172,
    "name": "HTML Boilerplate",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 173,
    "name": "HTML Form Generator",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 174,
    "name": "Meta Tag Generator",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 175,
    "name": "Open Graph Tags",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 176,
    "name": "Robots.txt Generator",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 177,
    "name": "Markdown Table Maker",
    "category": "Developer & Web",
    "op": "mdtable"
  },
  {
    "id": 178,
    "name": "Markdown Link Maker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 179,
    "name": "SQL Insert Builder",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 180,
    "name": "SQL String Escaper",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 181,
    "name": "XML Escape",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 182,
    "name": "JSON String Escape",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 183,
    "name": "Unix Timestamp Converter",
    "category": "Developer & Web",
    "op": "timestamp"
  },
  {
    "id": 184,
    "name": "Epoch Date Converter",
    "category": "Developer & Web",
    "op": "timestamp"
  },
  {
    "id": 185,
    "name": "Binary to Decimal",
    "category": "Developer & Web",
    "op": "bindec"
  },
  {
    "id": 186,
    "name": "Decimal to Binary",
    "category": "Developer & Web",
    "op": "decbin"
  },
  {
    "id": 187,
    "name": "Hex to Decimal",
    "category": "Developer & Web",
    "op": "hexdec"
  },
  {
    "id": 188,
    "name": "Decimal to Hex",
    "category": "Developer & Web",
    "op": "dechex"
  },
  {
    "id": 189,
    "name": "Text to Binary",
    "category": "Developer & Web",
    "op": "textbin"
  },
  {
    "id": 190,
    "name": "Binary to Text",
    "category": "Developer & Web",
    "op": "bintxt"
  },
  {
    "id": 191,
    "name": "ROT13 Encoder",
    "category": "Developer & Web",
    "op": "rot13"
  },
  {
    "id": 192,
    "name": "Caesar Cipher",
    "category": "Developer & Web",
    "op": "caesar"
  },
  {
    "id": 193,
    "name": "IPv4 Format Checker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 194,
    "name": "Email Format Checker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 195,
    "name": "URL Format Checker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 196,
    "name": "Slug Generator",
    "category": "Developer & Web",
    "op": "slug"
  },
  {
    "id": 197,
    "name": "Query String Parser",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 198,
    "name": "HTML Table Generator",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 199,
    "name": "CSS Clamp Generator",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 200,
    "name": "CSS Centering Helper",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 201,
    "name": "CSS Border Radius Maker",
    "category": "Developer & Web",
    "op": "template"
  },
  {
    "id": 202,
    "name": "Age Calculator",
    "category": "Daily Life & Utility",
    "op": "age"
  },
  {
    "id": 203,
    "name": "Date Difference Calculator",
    "category": "Daily Life & Utility",
    "op": "datediff"
  },
  {
    "id": 204,
    "name": "Countdown Calculator",
    "category": "Daily Life & Utility",
    "op": "countdown"
  },
  {
    "id": 205,
    "name": "Add Days to Date",
    "category": "Daily Life & Utility",
    "op": "adddays"
  },
  {
    "id": 206,
    "name": "Subtract Days from Date",
    "category": "Daily Life & Utility",
    "op": "subdays"
  },
  {
    "id": 207,
    "name": "Leap Year Checker",
    "category": "Daily Life & Utility",
    "op": "leap"
  },
  {
    "id": 208,
    "name": "Week Number Finder",
    "category": "Daily Life & Utility",
    "op": "week"
  },
  {
    "id": 209,
    "name": "Random Number Generator",
    "category": "Daily Life & Utility",
    "op": "random"
  },
  {
    "id": 210,
    "name": "Coin Toss",
    "category": "Daily Life & Utility",
    "op": "coin"
  },
  {
    "id": 211,
    "name": "Dice Roller",
    "category": "Daily Life & Utility",
    "op": "dice"
  },
  {
    "id": 212,
    "name": "Decision Picker",
    "category": "Daily Life & Utility",
    "op": "decision"
  },
  {
    "id": 213,
    "name": "Random Name Picker",
    "category": "Daily Life & Utility",
    "op": "decision"
  },
  {
    "id": 214,
    "name": "Random Team Maker",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 215,
    "name": "Shopping List Maker",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 216,
    "name": "Packing Checklist",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 217,
    "name": "Daily Planner",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 218,
    "name": "Weekly Planner",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 219,
    "name": "Habit Tracker",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 220,
    "name": "Habit Streak Counter",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 221,
    "name": "Goal Planner",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 222,
    "name": "Task Breakdown Helper",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 223,
    "name": "Reminder Message Builder",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 224,
    "name": "Meeting Agenda",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 225,
    "name": "Pomodoro Planner",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 226,
    "name": "Study Timer Planner",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 227,
    "name": "Reading Time Calculator",
    "category": "Daily Life & Utility",
    "op": "reading"
  },
  {
    "id": 228,
    "name": "Word Counter",
    "category": "Daily Life & Utility",
    "op": "wordcount"
  },
  {
    "id": 229,
    "name": "Character Counter",
    "category": "Daily Life & Utility",
    "op": "charcount"
  },
  {
    "id": 230,
    "name": "Line Counter",
    "category": "Daily Life & Utility",
    "op": "linecount"
  },
  {
    "id": 231,
    "name": "Sentence Counter",
    "category": "Daily Life & Utility",
    "op": "sentencecount"
  },
  {
    "id": 232,
    "name": "Text Case Converter",
    "category": "Daily Life & Utility",
    "op": "case"
  },
  {
    "id": 233,
    "name": "Title Case Converter",
    "category": "Daily Life & Utility",
    "op": "titlecase"
  },
  {
    "id": 234,
    "name": "Reverse Text",
    "category": "Daily Life & Utility",
    "op": "reverse"
  },
  {
    "id": 235,
    "name": "Remove Extra Spaces",
    "category": "Daily Life & Utility",
    "op": "spaces"
  },
  {
    "id": 236,
    "name": "Remove Duplicate Lines",
    "category": "Daily Life & Utility",
    "op": "dedupe"
  },
  {
    "id": 237,
    "name": "Sort Lines A-Z",
    "category": "Daily Life & Utility",
    "op": "sort"
  },
  {
    "id": 238,
    "name": "Text Joiner",
    "category": "Daily Life & Utility",
    "op": "join"
  },
  {
    "id": 239,
    "name": "Text Splitter",
    "category": "Daily Life & Utility",
    "op": "split"
  },
  {
    "id": 240,
    "name": "Find and Replace",
    "category": "Daily Life & Utility",
    "op": "replace"
  },
  {
    "id": 241,
    "name": "Text Repeater",
    "category": "Daily Life & Utility",
    "op": "repeat"
  },
  {
    "id": 242,
    "name": "Add Line Numbers",
    "category": "Daily Life & Utility",
    "op": "lineno"
  },
  {
    "id": 243,
    "name": "BMI Calculator",
    "category": "Daily Life & Utility",
    "op": "bmi"
  },
  {
    "id": 244,
    "name": "Water Intake Planner",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 245,
    "name": "Step Goal Planner",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 246,
    "name": "Sleep Duration Calculator",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 247,
    "name": "Workout Interval Planner",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 248,
    "name": "Running Pace Calculator",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 249,
    "name": "Distance Converter",
    "category": "Daily Life & Utility",
    "op": "distance"
  },
  {
    "id": 250,
    "name": "Weight Converter",
    "category": "Daily Life & Utility",
    "op": "weight"
  },
  {
    "id": 251,
    "name": "Height Converter",
    "category": "Daily Life & Utility",
    "op": "height"
  },
  {
    "id": 252,
    "name": "Temperature Converter",
    "category": "Daily Life & Utility",
    "op": "temperature"
  },
  {
    "id": 253,
    "name": "Volume Converter",
    "category": "Daily Life & Utility",
    "op": "volume"
  },
  {
    "id": 254,
    "name": "Speed Converter",
    "category": "Daily Life & Utility",
    "op": "speed"
  },
  {
    "id": 255,
    "name": "Time Duration Calculator",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 256,
    "name": "Phone Number Cleaner",
    "category": "Daily Life & Utility",
    "op": "phoneclean"
  },
  {
    "id": 257,
    "name": "Email Masker",
    "category": "Daily Life & Utility",
    "op": "maskemail"
  },
  {
    "id": 258,
    "name": "Phone Number Masker",
    "category": "Daily Life & Utility",
    "op": "maskphone"
  },
  {
    "id": 259,
    "name": "Password Strength Checker",
    "category": "Daily Life & Utility",
    "op": "strength"
  },
  {
    "id": 260,
    "name": "PIN Generator",
    "category": "Daily Life & Utility",
    "op": "pin"
  },
  {
    "id": 261,
    "name": "QR Text Payload Maker",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 262,
    "name": "Contact Card Text Builder",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 263,
    "name": "VCard Text Builder",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 264,
    "name": "Travel Budget Splitter",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 265,
    "name": "Trip Day Counter",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 266,
    "name": "Fuel Cost Per Trip",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 267,
    "name": "Recipe Portion Scaler",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 268,
    "name": "Meal Picker",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 269,
    "name": "Workout Picker",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 270,
    "name": "Calendar Month Viewer",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 271,
    "name": "Stopwatch Notes",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 272,
    "name": "Emergency Info Card",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 273,
    "name": "Address Formatter",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 274,
    "name": "Unit Converter",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 275,
    "name": "Measurement Converter",
    "category": "Daily Life & Utility",
    "op": "template"
  },
  {
    "id": 276,
    "name": "Aspect Ratio Calculator",
    "category": "Daily Life & Utility",
    "op": "aspect"
  },
  {
    "id": 277,
    "name": "Word Frequency Counter",
    "category": "Text & Social Media",
    "op": "wordfreq"
  },
  {
    "id": 278,
    "name": "Character Frequency Counter",
    "category": "Text & Social Media",
    "op": "charfreq"
  },
  {
    "id": 279,
    "name": "Text Statistics",
    "category": "Text & Social Media",
    "op": "stats"
  },
  {
    "id": 280,
    "name": "Palindrome Checker",
    "category": "Text & Social Media",
    "op": "palindrome"
  },
  {
    "id": 281,
    "name": "Reading Pace Estimator",
    "category": "Text & Social Media",
    "op": "reading"
  },
  {
    "id": 282,
    "name": "Initials Maker",
    "category": "Text & Social Media",
    "op": "initials"
  },
  {
    "id": 283,
    "name": "Remove Punctuation",
    "category": "Text & Social Media",
    "op": "punct"
  },
  {
    "id": 284,
    "name": "Keep Numbers Only",
    "category": "Text & Social Media",
    "op": "digits"
  },
  {
    "id": 285,
    "name": "Remove Numbers",
    "category": "Text & Social Media",
    "op": "nonumbers"
  },
  {
    "id": 286,
    "name": "Text Truncator",
    "category": "Text & Social Media",
    "op": "truncate"
  },
  {
    "id": 287,
    "name": "Line Wrapper",
    "category": "Text & Social Media",
    "op": "wrap"
  },
  {
    "id": 288,
    "name": "List Shuffler",
    "category": "Text & Social Media",
    "op": "shuffle"
  },
  {
    "id": 289,
    "name": "List Reverser",
    "category": "Text & Social Media",
    "op": "reverse"
  },
  {
    "id": 290,
    "name": "Word Extractor",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 291,
    "name": "URL Extractor",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 292,
    "name": "Email Extractor",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 293,
    "name": "Phone Extractor",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 294,
    "name": "Hashtag Counter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 295,
    "name": "Mention Counter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 296,
    "name": "TikTok Caption Counter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 297,
    "name": "Instagram Bio Counter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 298,
    "name": "YouTube Title Counter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 299,
    "name": "Hashtag Cleaner",
    "category": "Text & Social Media",
    "op": "dedupe"
  },
  {
    "id": 300,
    "name": "Caption Line Breaker",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 301,
    "name": "Post Idea Planner",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 302,
    "name": "Content Calendar Rows",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 303,
    "name": "Channel Name Ideas",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 304,
    "name": "Thumbnail Text Shortener",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 305,
    "name": "Pinned Comment Maker",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 306,
    "name": "Video Chapter Maker",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 307,
    "name": "Shorts Script Outline",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 308,
    "name": "Tag List Cleaner",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 309,
    "name": "Social Bio Formatter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 310,
    "name": "WhatsApp Message Formatter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 311,
    "name": "Morse Code Encoder",
    "category": "Text & Social Media",
    "op": "morse"
  },
  {
    "id": 312,
    "name": "Morse Code Decoder",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 313,
    "name": "NATO Alphabet Converter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 314,
    "name": "Unicode Code Point Viewer",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 315,
    "name": "Emoji Counter",
    "category": "Text & Social Media",
    "op": "emojicount"
  },
  {
    "id": 316,
    "name": "Vowel Counter",
    "category": "Text & Social Media",
    "op": "vowels"
  },
  {
    "id": 317,
    "name": "Consonant Counter",
    "category": "Text & Social Media",
    "op": "consonants"
  },
  {
    "id": 318,
    "name": "Urdu Text Counter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 319,
    "name": "Arabic Text Counter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 320,
    "name": "Text Direction Helper",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 321,
    "name": "Arabic Diacritics Cleaner",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 322,
    "name": "Morse Code Reference",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 323,
    "name": "Sentence Case Converter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 324,
    "name": "Alternating Case Converter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 325,
    "name": "Text Comparator",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 326,
    "name": "Text Cleaner",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 327,
    "name": "Markdown to Plain Text",
    "category": "Text & Social Media",
    "op": "striphtml"
  },
  {
    "id": 328,
    "name": "CSV Row Counter",
    "category": "Text & Social Media",
    "op": "csvrows"
  },
  {
    "id": 329,
    "name": "CSV Column Counter",
    "category": "Text & Social Media",
    "op": "csvcols"
  },
  {
    "id": 330,
    "name": "Data Deduplicator",
    "category": "Text & Social Media",
    "op": "dedupe"
  },
  {
    "id": 331,
    "name": "Text to CSV Rows",
    "category": "Text & Social Media",
    "op": "textcsv"
  },
  {
    "id": 332,
    "name": "CSV Delimiter Helper",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 333,
    "name": "List to JSON Array",
    "category": "Text & Social Media",
    "op": "listjson"
  },
  {
    "id": 334,
    "name": "JSON Array to List",
    "category": "Text & Social Media",
    "op": "jsonlist"
  },
  {
    "id": 335,
    "name": "Data Size Estimator",
    "category": "Text & Social Media",
    "op": "datasize"
  },
  {
    "id": 336,
    "name": "Contact Message Formatter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 337,
    "name": "Bio Ideas",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 338,
    "name": "Caption Ideas",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 339,
    "name": "Reel Hook Ideas",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 340,
    "name": "Comment Reply Helper",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 341,
    "name": "Customer Review Reply",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 342,
    "name": "Short Message Maker",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 343,
    "name": "Professional Bio Formatter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 344,
    "name": "Quote Formatter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 345,
    "name": "Bullet List Formatter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 346,
    "name": "Numbered List Formatter",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 347,
    "name": "Lorem Ipsum Generator",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 348,
    "name": "Random Paragraph Maker",
    "category": "Text & Social Media",
    "op": "template"
  },
  {
    "id": 349,
    "name": "Text to Uppercase",
    "category": "More Tools",
    "op": "upper"
  },
  {
    "id": 350,
    "name": "Text to Lowercase",
    "category": "More Tools",
    "op": "lower"
  },
  {
    "id": 351,
    "name": "Trim Each Line",
    "category": "More Tools",
    "op": "trimlines"
  },
  {
    "id": 352,
    "name": "Remove Blank Lines",
    "category": "More Tools",
    "op": "blanklines"
  },
  {
    "id": 353,
    "name": "Prefix Each Line",
    "category": "More Tools",
    "op": "prefix"
  },
  {
    "id": 354,
    "name": "Suffix Each Line",
    "category": "More Tools",
    "op": "suffix"
  },
  {
    "id": 355,
    "name": "Word Sorter",
    "category": "More Tools",
    "op": "sortwords"
  },
  {
    "id": 356,
    "name": "Count Unique Words",
    "category": "More Tools",
    "op": "uniquewords"
  },
  {
    "id": 357,
    "name": "Text to Slug",
    "category": "More Tools",
    "op": "slug"
  },
  {
    "id": 358,
    "name": "Slug to Text",
    "category": "More Tools",
    "op": "slugtext"
  },
  {
    "id": 359,
    "name": "HTML Entity Encoder",
    "category": "More Tools",
    "op": "htmlescape"
  },
  {
    "id": 360,
    "name": "HTML Entity Decoder",
    "category": "More Tools",
    "op": "htmlunescape"
  },
  {
    "id": 361,
    "name": "CSV to Markdown Table",
    "category": "More Tools",
    "op": "mdtable"
  },
  {
    "id": 362,
    "name": "JSON Keys Viewer",
    "category": "More Tools",
    "op": "jsonkeys"
  },
  {
    "id": 363,
    "name": "JSON Array Length",
    "category": "More Tools",
    "op": "jsonlength"
  },
  {
    "id": 364,
    "name": "Percentage Calculator",
    "category": "More Tools",
    "op": "percent"
  },
  {
    "id": 365,
    "name": "Average Calculator",
    "category": "More Tools",
    "op": "average"
  },
  {
    "id": 366,
    "name": "Median Calculator",
    "category": "More Tools",
    "op": "median"
  },
  {
    "id": 367,
    "name": "Standard Deviation Calculator",
    "category": "More Tools",
    "op": "stddev"
  },
  {
    "id": 368,
    "name": "Ratio Simplifier",
    "category": "More Tools",
    "op": "ratio"
  },
  {
    "id": 369,
    "name": "Circle Area Calculator",
    "category": "More Tools",
    "op": "circle"
  },
  {
    "id": 370,
    "name": "Rectangle Area Calculator",
    "category": "More Tools",
    "op": "rectangle"
  },
  {
    "id": 371,
    "name": "Factorial Calculator",
    "category": "More Tools",
    "op": "factorial"
  },
  {
    "id": 372,
    "name": "Prime Number Tester",
    "category": "More Tools",
    "op": "prime"
  },
  {
    "id": 373,
    "name": "Multiplication Table Generator",
    "category": "More Tools",
    "op": "table"
  },
  {
    "id": 374,
    "name": "Date Formatter",
    "category": "More Tools",
    "op": "dateformat"
  },
  {
    "id": 375,
    "name": "Business Days Counter",
    "category": "More Tools",
    "op": "businessdays"
  },
  {
    "id": 376,
    "name": "Time Duration Calculator",
    "category": "More Tools",
    "op": "duration"
  },
  {
    "id": 377,
    "name": "Random Date Picker",
    "category": "More Tools",
    "op": "randomdate"
  },
  {
    "id": 378,
    "name": "Work Hours Calculator",
    "category": "More Tools",
    "op": "workhours"
  },
  {
    "id": 379,
    "name": "Savings Progress Calculator",
    "category": "More Tools",
    "op": "savings"
  },
  {
    "id": 380,
    "name": "Revenue Calculator",
    "category": "More Tools",
    "op": "revenue"
  },
  {
    "id": 381,
    "name": "Cost Per Unit Calculator",
    "category": "More Tools",
    "op": "unitcost"
  },
  {
    "id": 382,
    "name": "Gross Margin Calculator",
    "category": "More Tools",
    "op": "margin"
  },
  {
    "id": 383,
    "name": "Net Profit Calculator",
    "category": "More Tools",
    "op": "profit"
  },
  {
    "id": 384,
    "name": "Sales Target Calculator",
    "category": "More Tools",
    "op": "sales"
  },
  {
    "id": 385,
    "name": "Cashbook Entry Formatter",
    "category": "More Tools",
    "op": "cashbook"
  },
  {
    "id": 386,
    "name": "Purchase Order Template",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 387,
    "name": "Quotation Template",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 388,
    "name": "Payment Reminder Writer",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 389,
    "name": "Customer Record Formatter",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 390,
    "name": "Daily Sales Sheet Maker",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 391,
    "name": "Expense Report Maker",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 392,
    "name": "Product Bundle Price Calculator",
    "category": "More Tools",
    "op": "bundle"
  },
  {
    "id": 393,
    "name": "Retail Price Calculator",
    "category": "More Tools",
    "op": "markup"
  },
  {
    "id": 394,
    "name": "Wholesale Price Calculator",
    "category": "More Tools",
    "op": "markup"
  },
  {
    "id": 395,
    "name": "Random Team Generator",
    "category": "More Tools",
    "op": "teams"
  },
  {
    "id": 396,
    "name": "Random Meal Picker",
    "category": "More Tools",
    "op": "decision"
  },
  {
    "id": 397,
    "name": "Random Workout Picker",
    "category": "More Tools",
    "op": "decision"
  },
  {
    "id": 398,
    "name": "Shopping List Formatter",
    "category": "More Tools",
    "op": "bullets"
  },
  {
    "id": 399,
    "name": "Packing List Formatter",
    "category": "More Tools",
    "op": "bullets"
  },
  {
    "id": 400,
    "name": "Daily Checklist Maker",
    "category": "More Tools",
    "op": "bullets"
  },
  {
    "id": 401,
    "name": "Weekly Checklist Maker",
    "category": "More Tools",
    "op": "bullets"
  },
  {
    "id": 402,
    "name": "Goal Milestone Planner",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 403,
    "name": "Meeting Minutes Formatter",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 404,
    "name": "Project Task Splitter",
    "category": "More Tools",
    "op": "bullets"
  },
  {
    "id": 405,
    "name": "Bug Report Formatter",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 406,
    "name": "Support Ticket Formatter",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 407,
    "name": "Feedback Message Builder",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 408,
    "name": "Contact Message Builder",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 409,
    "name": "FAQ Formatter",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 410,
    "name": "Privacy Policy Outline",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 411,
    "name": "Terms Text Outline",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 412,
    "name": "Email Signature Builder",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 413,
    "name": "VCard Text Builder",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 414,
    "name": "Country Code Notes",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 415,
    "name": "Postal Code Cleaner",
    "category": "More Tools",
    "op": "spaces"
  },
  {
    "id": 416,
    "name": "Address Formatter",
    "category": "More Tools",
    "op": "trimlines"
  },
  {
    "id": 417,
    "name": "Unicode Inspector",
    "category": "More Tools",
    "op": "codepoints"
  },
  {
    "id": 418,
    "name": "English Alphabet Counter",
    "category": "More Tools",
    "op": "alphabet"
  },
  {
    "id": 419,
    "name": "Arabic Text Counter",
    "category": "More Tools",
    "op": "wordcount"
  },
  {
    "id": 420,
    "name": "Urdu Character Counter",
    "category": "More Tools",
    "op": "charcount"
  },
  {
    "id": 421,
    "name": "Text Direction Helper",
    "category": "More Tools",
    "op": "direction"
  },
  {
    "id": 422,
    "name": "Arabic Diacritics Cleaner",
    "category": "More Tools",
    "op": "diacritics"
  },
  {
    "id": 423,
    "name": "Text Privacy Masker",
    "category": "More Tools",
    "op": "redact"
  },
  {
    "id": 424,
    "name": "Secret Key Generator",
    "category": "More Tools",
    "op": "token"
  },
  {
    "id": 425,
    "name": "Random Passphrase Generator",
    "category": "More Tools",
    "op": "passphrase"
  },
  {
    "id": 426,
    "name": "Secure Token Maker",
    "category": "More Tools",
    "op": "token"
  },
  {
    "id": 427,
    "name": "CSS Gradient Preset Maker",
    "category": "More Tools",
    "op": "gradient"
  },
  {
    "id": 428,
    "name": "CSS Box Shadow Snippet",
    "category": "More Tools",
    "op": "shadow"
  },
  {
    "id": 429,
    "name": "CSS Button Style Snippet",
    "category": "More Tools",
    "op": "button"
  },
  {
    "id": 430,
    "name": "CSS Flexbox Template",
    "category": "More Tools",
    "op": "flex"
  },
  {
    "id": 431,
    "name": "CSS Grid Template",
    "category": "More Tools",
    "op": "grid"
  },
  {
    "id": 432,
    "name": "CSS Media Query Snippet",
    "category": "More Tools",
    "op": "media"
  },
  {
    "id": 433,
    "name": "CSS Clamp Snippet",
    "category": "More Tools",
    "op": "clamp"
  },
  {
    "id": 434,
    "name": "CSS Centering Snippet",
    "category": "More Tools",
    "op": "center"
  },
  {
    "id": 435,
    "name": "CSS Border Radius Snippet",
    "category": "More Tools",
    "op": "radius"
  },
  {
    "id": 436,
    "name": "HTML Page Starter",
    "category": "More Tools",
    "op": "boilerplate"
  },
  {
    "id": 437,
    "name": "HTML Form Starter",
    "category": "More Tools",
    "op": "form"
  },
  {
    "id": 438,
    "name": "Open Graph Meta Tags",
    "category": "More Tools",
    "op": "metatags"
  },
  {
    "id": 439,
    "name": "Robots Meta Helper",
    "category": "More Tools",
    "op": "robots"
  },
  {
    "id": 440,
    "name": "Markdown Checklist Maker",
    "category": "More Tools",
    "op": "checklist"
  },
  {
    "id": 441,
    "name": "Markdown Code Block Maker",
    "category": "More Tools",
    "op": "codeblock"
  },
  {
    "id": 442,
    "name": "URL Query Parser",
    "category": "More Tools",
    "op": "query"
  },
  {
    "id": 443,
    "name": "Domain Cleaner",
    "category": "More Tools",
    "op": "domain"
  },
  {
    "id": 444,
    "name": "Email Validator",
    "category": "More Tools",
    "op": "emailvalid"
  },
  {
    "id": 445,
    "name": "URL Validator",
    "category": "More Tools",
    "op": "urlvalid"
  },
  {
    "id": 446,
    "name": "IPv4 Validator",
    "category": "More Tools",
    "op": "ipvalid"
  },
  {
    "id": 447,
    "name": "XML Escape Helper",
    "category": "More Tools",
    "op": "htmlescape"
  },
  {
    "id": 448,
    "name": "SQL String Escape Helper",
    "category": "More Tools",
    "op": "sqlescape"
  },
  {
    "id": 449,
    "name": "Image Dimension Notes",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 450,
    "name": "Video Bitrate Estimator",
    "category": "More Tools",
    "op": "bitrate"
  },
  {
    "id": 451,
    "name": "Subtitle Line Breaker",
    "category": "More Tools",
    "op": "wrap"
  },
  {
    "id": 452,
    "name": "SRT Timestamp Helper",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 453,
    "name": "Travel Packing Planner",
    "category": "More Tools",
    "op": "bullets"
  },
  {
    "id": 454,
    "name": "Trip Cost Splitter",
    "category": "More Tools",
    "op": "splitbill"
  },
  {
    "id": 455,
    "name": "Recipe Portion Scaler",
    "category": "More Tools",
    "op": "recipe"
  },
  {
    "id": 456,
    "name": "Water Goal Planner",
    "category": "More Tools",
    "op": "water"
  },
  {
    "id": 457,
    "name": "Sleep Time Calculator",
    "category": "More Tools",
    "op": "sleep"
  },
  {
    "id": 458,
    "name": "Workout Interval Planner Plus",
    "category": "More Tools",
    "op": "interval"
  },
  {
    "id": 459,
    "name": "Walking Pace Calculator",
    "category": "More Tools",
    "op": "pace"
  },
  {
    "id": 460,
    "name": "Step Goal Progress",
    "category": "More Tools",
    "op": "steps"
  },
  {
    "id": 461,
    "name": "Habit Streak Counter Plus",
    "category": "More Tools",
    "op": "streak"
  },
  {
    "id": 462,
    "name": "Emergency Contact Card",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 463,
    "name": "Phone Digits Cleaner",
    "category": "More Tools",
    "op": "phoneclean"
  },
  {
    "id": 464,
    "name": "Name Initials Formatter",
    "category": "More Tools",
    "op": "initials"
  },
  {
    "id": 465,
    "name": "Quote Formatter",
    "category": "More Tools",
    "op": "quote"
  },
  {
    "id": 466,
    "name": "Bullet Point Formatter",
    "category": "More Tools",
    "op": "bullets"
  },
  {
    "id": 467,
    "name": "Numbered List Formatter",
    "category": "More Tools",
    "op": "numbered"
  },
  {
    "id": 468,
    "name": "Lorem Ipsum Text Maker",
    "category": "More Tools",
    "op": "lorem"
  },
  {
    "id": 469,
    "name": "Random Paragraph Maker",
    "category": "More Tools",
    "op": "paragraph"
  },
  {
    "id": 470,
    "name": "Bio Draft Helper",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 471,
    "name": "Caption Draft Helper",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 472,
    "name": "Ad Headline Variations",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 473,
    "name": "Sales Pitch Outline",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 474,
    "name": "Business About Us Draft",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 475,
    "name": "Portfolio Bio Draft",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 476,
    "name": "Creator Media Kit Outline",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 477,
    "name": "Podcast Outline Maker",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 478,
    "name": "Course Outline Maker",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 479,
    "name": "Lesson Plan Builder",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 480,
    "name": "SEO Title Helper",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 481,
    "name": "Meta Description Helper",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 482,
    "name": "Keyword Brainstorming List",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 483,
    "name": "Brand Voice Guide",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 484,
    "name": "Content Repurposing Planner",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 485,
    "name": "Customer Review Reply",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 486,
    "name": "Short Message Maker",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 487,
    "name": "Professional Bio Formatter",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 488,
    "name": "Social Media CTA Builder",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 489,
    "name": "YouTube Pinned Comment Maker",
    "category": "More Tools",
    "op": "template"
  },
  {
    "id": 490,
    "name": "Video Hook Brainstormer",
    "category": "More Tools",
    "op": "template"
  }
];
