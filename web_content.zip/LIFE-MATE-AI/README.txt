LIFE MATE AI — COMPLETE PROJECT
================================

HOW TO OPEN
1. Extract this ZIP file.
2. In SPCK Editor, open/import the extracted LIFE-MATE-AI folder.
3. Open the root file: index.html
4. Preview index.html in SPCK/browser.

IMPORTANT STRUCTURE
- Keep css/, js/, tools/, and pages/ folders beside index.html.
- Do not move individual tool folders out of tools/.
- The homepage includes direct links to all 8 included tools.
- Search and category filters work on the homepage.

INCLUDED TOOLS
1. Country Code Finder
2. Currency Converter (sample offline rates; not live FX)
3. Text Tools
4. Image Studio
5. Smart Calculator
6. Study Helper
7. Business Toolkit (localStorage on this device/browser)
8. Security Kit

HELP PAGES
About, Help Center, FAQs, Contact, Report a Problem.

LIMITATIONS
- This is a static, browser-based project. No backend, server, user accounts, cloud sync, or real AI API is connected.
- Contact and report forms prepare/copy a message; they do not send it automatically.
- Currency rates are illustrative sample rates.
- Business records remain in the current browser's local storage.
- Clipboard access may depend on browser permissions.
- Google Fonts may require internet; the website falls back to local system fonts.

The ZIP is a reconstructed, integrated working package based on the LIFE MATE AI project requirements and available project context. It may not be byte-for-byte identical to earlier code versions.
