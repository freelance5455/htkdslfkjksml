LIFE MATE AI — VIP EDITION
BY RAMZAN BUKHARI

ZIP میں شامل:
- 300+ listed tools in 5 main areas plus More Tools
- Search, category filters, favorites
- Dark / White / AMOLED / Purple / Emerald themes
- Tool workspace, result copy, Help & FAQ, email and WhatsApp contact
- Responsive mobile-first layout

SPCK پر چلانے کا طریقہ:
1. ZIP extract کریں۔
2. SPCK Editor میں LIFE-MATE-AI-VIP فولڈر open کریں۔
3. index.html کھول کر Preview / Run کریں۔
4. Categories میں سے AI & Writing, Business & Finance, Developer & Web, Daily Life & Utility یا Text & Social Media منتخب کریں۔
5. Theme بٹن دبانے سے themes ایک ایک کرکے بدلیں۔

اہم وضاحت:
- کئی ٹولز مکمل طور پر browser میں چلتے ہیں، جیسے calculators, text tools, converters, JSON/CSV helpers وغیرہ۔
- AI & Writing سیکشن کے کچھ ٹولز offline templates/prompts ہیں۔ اصل generative AI چلانے کے لیے AI provider کی API key اور internet connection درکار ہے۔
- اس ویب ایپ میں کوئی سرور یا API key شامل نہیں۔
- Google Fonts صرف انٹرنیٹ ہونے پر لوڈ ہوں گے؛ بنیادی ڈیزائن local CSS پر ہے۔
- رابطہ: ramzanbukhari778@gmail.com
- WhatsApp: +92 313 6110313
