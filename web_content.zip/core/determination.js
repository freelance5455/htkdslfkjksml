/* ============================================================
   PENGGILAS — DETERMINATION / ADJUDICATION + VERIFICATION LAYER
   Version: DET-CONTRACT-1.4

   Scope:
     B/C adjudication only. Foundation A, MASTER_RESULT public fields,
     and result-template presentation remain untouched.

   Pipeline:
     CLASSICAL RULE -> RULE CONDITION -> ACTUAL CHART EVIDENCE
     -> CONDITION EVALUATION -> RULE RESULT -> CHALLENGE / COUNTER-EVIDENCE
     -> ADJUDICATION -> CLAIM -> CROSS-CHECK -> CONFIDENCE

   The chain is assembled from the existing rule registry, Core B/C evidence,
   and existing determination results. It does not introduce a second formula.

   Important:
     FINAL means a final determination can be negative (e.g. a pattern is
     not formed). It does NOT mean every candidate is confirmed positively.
   ============================================================ */
(function (global) {
    "use strict";

    const VERSION = "DET-CONTRACT-1.13-TRACEABLE-CHAIN";

    const CLASSICAL_SOURCE_LIBRARY = {
        ZPZQ_GEJU: {
            id: "ZPZQ_CHART_PATTERN_SOURCE",
            title: "Zi Ping Zhen Quan — 论用神成败救应 / 阳刃",
            role: "Yang Ren formation, breaking and rescue; Month Command pattern logic",
            url: "https://shuyuan.zhiming.life/read/%E5%AD%90%E5%B9%B3%E7%9C%9F%E8%AF%A0/13"
        },
        ZPZQ_POSITION: {
            id: "ZPZQ_POSITIONAL_SEPARATION_SOURCE",
            title: "Zi Ping Zhen Quan Ping Zhu — 十干配合 / positional separation",
            role: "Exact positional example: 癸年 戊午 丙日 甲午; 甲隔开戊癸，戊癸不能合",
            url: "https://www.scribd.com/document/674658851/%E5%AD%90%E5%B9%B3%E7%9C%9F%E8%AF%A0%E8%AF%84%E8%AF%81"
        },
        DTT_BING: {
            id: "DI_TIAN_SUI_BING_FIRE_SOURCE",
            title: "Di Tian Sui — 丙火",
            role: "丙火 strength/seasonal character; water as control of excessive fire",
            url: "https://zh.wikisource.org/zh-hans/%E6%BB%B4%E5%A4%A9%E9%AB%93/02"
        },
        QTBJ_BING_WU: {
            id: "QIONG_TONG_BAO_JIAN_BING_WU_MONTH_SOURCE",
            title: "Qiong Tong Bao Jian — 三夏丙火",
            role: "Source-specific May 丙火 rule: 五月亦专用壬",
            url: "https://zh.wikisource.org/zh-hans/%E7%A9%B7%E9%80%9A%E5%AE%9D%E9%91%91"
        }
    };

    // Chart-specific applicability: source records must not be emitted as
    // claim evidence unless the source profile actually applies to this chart.
    // Internal source IDs remain engine/audit identifiers only.
    function applicableVerificationSources(profile) {
        return Array.isArray(profile) ? profile : [];
    }

    function makeExternalEvidence(id, claimId, field, detail, applicable, sources) {
        if (!applicable) return null;
        return makeEvidence(id, claimId, "CLASSICAL_EXTERNAL_SOURCE", field, detail, "INTERNAL_SOURCE_PROFILE_CROSS_CHECKED", applicableVerificationSources(sources));
    }

    function semanticSourceList(profile) {
        return applicableVerificationSources(profile).map(function (s) {
            return { title: s.title, role: s.role, url: s.url };
        });
    }

    function hasAnyApplicableExternalSource(items) {
        return Array.isArray(items) && items.length > 0;
    }

    function hasText(value, pattern) {
        const s = value == null ? "" : String(value);
        return pattern.test(s);
    }

    function makeEvidence(id, claimId, source, field, detail, status, verification) {
        return { id, claimId, source, field, detail, status: status || "AVAILABLE", verification: verification || null };
    }

    function hasUsableEvidenceValue(value) {
        if (value === null || value === undefined) return false;
        if (typeof value === "string") {
            const text = value.trim();
            if (!text || /^(NOT DETERMINED|NOT AVAILABLE|UNRESOLVED|NOT EXECUTED|null|undefined)$/i.test(text)) return false;
            return true;
        }
        if (Array.isArray(value)) return value.length > 0;
        if (typeof value === "object") return Object.keys(value).length > 0;
        return true;
    }

    function usableEvidenceRecords(records) {
        return (Array.isArray(records) ? records : []).filter(function (record) {
            return record && hasUsableEvidenceValue(record.detail);
        });
    }

    function makeClaim(id, claim, scope, dependency, status, outcome, evidenceIds, blocking, challenge) {
        return {
            claimId: id,
            claim,
            scope,
            dependency,
            status,
            outcome: outcome || null,
            evidenceIds: evidenceIds || [],
            blockingConditions: blocking || [],
            challenge: challenge || []
        };
    }

    function auditState(ok, detail, checks) {
        return { status: ok ? "PASS" : "CONDITIONAL", detail: detail, checks: checks || [] };
    }

    function ruleTraceFor(master) {
        const trace = master && master._ruleTrace ? master._ruleTrace : {};
        const all = [];
        Object.keys(trace).forEach(function (section) {
            const rows = Array.isArray(trace[section]) ? trace[section] : [];
            rows.forEach(function (row) { all.push(Object.assign({ section: section }, row)); });
        });
        return { raw: trace, all: all };
    }

    function rulesForSections(master, sections) {
        const wanted = Array.isArray(sections) ? sections : [];
        return ruleTraceFor(master).all.filter(function (row) { return wanted.indexOf(row.section) !== -1; });
    }

    function buildRuleLinks(master, item, ruleSections) {
        const rules = rulesForSections(master, ruleSections);
        const evidence = Array.isArray(item.evidence) ? item.evidence : [];
        const claim = item.claim || {};
        const uniqueRules = [];
        const seenRuleIds = {};
        rules.forEach(function (row) {
            const key = String(row.ruleId || row.ruleKey || "");
            if (!key || seenRuleIds[key]) return;
            seenRuleIds[key] = true;
            uniqueRules.push(row);
        });
        return uniqueRules.map(function (row) {
            const sectionEvidence = evidence.filter(function (ev) {
                const source = ev && ev.source != null ? String(ev.source) : "";
                return source === String(row.section) || source.indexOf(String(row.section) + ".") === 0;
            });
            const actualEvidence = (sectionEvidence.length ? sectionEvidence : evidence).map(function (ev) {
                return {
                    id: ev.id,
                    source: ev.source,
                    field: ev.field,
                    detail: ev.detail,
                    status: ev.status
                };
            });
            const hasActualEvidence = usableEvidenceRecords(actualEvidence).length > 0;
            const ruleReported = row.executionStatus !== "RULE-MISSING" && row.executionStatus !== "NOT_EXECUTED";
            const definition = global.PENGGILAS_DETERMINATION_RULES && global.PENGGILAS_DETERMINATION_RULES.rules
                ? global.PENGGILAS_DETERMINATION_RULES.rules[claim.claimId]
                : null;
            const conditionContext = definition && claim.claimId === "USEFUL_ELEMENT"
                ? Object.assign({}, master, { B13: master && master.B13_2 ? master.B13_2 : undefined })
                : master;
            const conditionChecks = (definition && Array.isArray(definition.conditionChecks)) ? definition.conditionChecks.map(function (check) {
                const value = getPath(conditionContext, check.path);
                const present = value != null && String(value) !== "";
                const rawStatus = String(value == null ? "" : value).toUpperCase();
                const closed = rawStatus === "RESOLVED" || rawStatus === "FINAL";
                const reported = present && rawStatus !== "NOT DETERMINED" && rawStatus !== "UNRESOLVED" && rawStatus !== "NOT EXECUTED";
                const passed = check.test === "present" ? present
                    : (check.test === "reported" ? reported
                        : (check.test === "closed" ? closed : false));
                return { name: check.name, path: check.path, status: passed ? "PASS" : "OPEN", observed: value == null ? null : value };
            }) : [];
            const failedChecks = conditionChecks.filter(function (check) { return check.status !== "PASS"; });
            const conditionEvaluation = !ruleReported
                ? { status: "NOT_EVALUATED", checks: conditionChecks, basis: "The configured Classical rule was not executed/reported by the existing Core result." }
                : (!conditionChecks.length
                    ? { status: hasActualEvidence ? "EVIDENCE_REPORTED_NO_MACHINE_CONDITION" : "NOT_EVALUATED", checks: [], basis: "The registry has no machine-readable condition checks; the Classical prose condition is preserved as source context and is not guessed." }
                    : (failedChecks.length === 0
                        ? { status: "SUPPORTED", checks: conditionChecks, basis: "Every declared condition check is supported by an existing Core B/C field; this evaluates evidence availability, not the Classical conclusion itself." }
                        : { status: "NOT_CLOSED", checks: conditionChecks, basis: "One or more declared condition checks remain open; no closure is inferred." }));
            const ruleResult = {
                status: claim.status || "UNRESOLVED",
                outcome: claim.outcome || null,
                basis: "Existing determination result"
            };
            const challenges = [].concat(claim.challenge || [], claim.blockingConditions || []);
            const counterEvidence = [];
            conditionChecks.forEach(function (check) {
                if (check.status !== "PASS") {
                    counterEvidence.push({
                        type: "condition-gap",
                        name: check.name,
                        path: check.path,
                        observed: check.observed
                    });
                }
            });
            const adjudication = (conditionEvaluation.status === "NOT_CLOSED" || conditionEvaluation.status === "NOT_EVALUATED")
                ? { status: "OPEN", outcome: "Condition/evidence gate is not closed; no rule closure is inferred." }
                : (claim.status === "CONFLICT"
                    ? { status: "CONFLICT", outcome: "Authoritative Core evidence reports a conflict; no silent winner is selected." }
                    : (claim.status === "FINAL" && challenges.length === 0
                        ? { status: "CLOSED", outcome: claim.outcome || "Final determination recorded by the existing authority." }
                        : { status: "OPEN", outcome: "Existing determination remains conditional or challenged; no closure is inferred." }));
            return {
                section: row.section,
                ruleKey: row.ruleKey,
                ruleId: row.ruleId,
                semanticName: (global.PENGGILAS_CLASSICAL_RULE_EVALUATOR && global.PENGGILAS_CLASSICAL_RULE_EVALUATOR.rule(row.ruleKey) && (global.PENGGILAS_CLASSICAL_RULE_EVALUATOR.rule(row.ruleKey).english || global.PENGGILAS_CLASSICAL_RULE_EVALUATOR.rule(row.ruleKey).hanzi)) || row.english || row.ruleKey,
                hanzi: (global.PENGGILAS_CLASSICAL_RULE_EVALUATOR && global.PENGGILAS_CLASSICAL_RULE_EVALUATOR.rule(row.ruleKey) && global.PENGGILAS_CLASSICAL_RULE_EVALUATOR.rule(row.ruleKey).hanzi) || row.hanzi || "",
                sourceIds: Array.isArray(row.sources) ? row.sources.slice() : [],
                executionStatus: row.executionStatus,
                condition: row.condition || null,
                conditionEvaluation: conditionEvaluation,
                actualChartEvidence: actualEvidence,
                ruleResult: ruleResult,
                challenge: {
                    status: challenges.length || counterEvidence.length ? "ACTIVE" : "CLEAR",
                    counterEvidence: counterEvidence,
                    statements: challenges
                },
                adjudication: adjudication,
                claim: { claimId: claim.claimId, status: claim.status },
                crossCheck: null,
                confidence: null,
                linkBasis: "SECTION_RULE_TRACE_PLUS_EXISTING_DETERMINATION"
            };
        });
    }

    function finalizeRuleChain(ruleLinks, crossCheck, confidence) {
        return (ruleLinks || []).map(function (link) {
            const out = Object.assign({}, link);
            out.crossCheck = {
                status: crossCheck && crossCheck.status ? crossCheck.status : "NOT_VERIFIED",
                detail: crossCheck && crossCheck.detail ? crossCheck.detail : "Cross-check not closed."
            };
            out.confidence = {
                level: confidence && confidence.level ? confidence.level : "UNRESOLVED",
                basis: confidence && confidence.basis ? confidence.basis : "Confidence gate not closed."
            };
            return out;
        });
    }

    function auditEvidenceChain(master, item, ruleSections) {
        const evidence = Array.isArray(item.evidence) ? item.evidence : [];
        const evidenceIds = evidence.map(function (x) { return x && x.id; }).filter(Boolean);
        const usableEvidence = usableEvidenceRecords(evidence);
        const claimEvidenceIds = Array.isArray(item.claim.evidenceIds) ? item.claim.evidenceIds : [];
        const missingClaimEvidence = claimEvidenceIds.filter(function (id) { return evidenceIds.indexOf(id) === -1; });
        const orphanEvidence = evidence.filter(function (x) { return x.claimId !== item.claim.claimId; }).map(function (x) { return x.id; });
        const rules = rulesForSections(master, ruleSections);
        const ruleIds = rules.map(function (x) { return x.ruleId || x.ruleKey; }).filter(Boolean);
        const missingRules = rules.filter(function (x) { return x.executionStatus === "RULE-MISSING"; }).map(function (x) { return x.ruleKey; });
        const notExecuted = rules.filter(function (x) { return x.executionStatus === "NOT_EXECUTED"; }).map(function (x) { return x.ruleKey; });
        const noRuleTrace = rules.length === 0;
        const checks = [
            { check: "CLAIM_EVIDENCE_LINK", status: missingClaimEvidence.length ? "FAIL" : "PASS", detail: missingClaimEvidence.length ? "Missing evidence records: " + missingClaimEvidence.join(", ") : "Every claim evidenceId resolves to an evidence record." },
            { check: "EVIDENCE_OWNERSHIP", status: orphanEvidence.length ? "FAIL" : "PASS", detail: orphanEvidence.length ? "Evidence belongs to another claim: " + orphanEvidence.join(", ") : "Evidence records belong to the current claim." },
            { check: "RULE_TRACE", status: (noRuleTrace || missingRules.length || notExecuted.length) ? "FAIL" : "PASS", detail: noRuleTrace ? "No configured Classical rule trace is connected to this determination." : (missingRules.length ? "Missing configured rule definitions: " + missingRules.join(", ") : (notExecuted.length ? "Configured rules are not executed/reported: " + notExecuted.join(", ") : "Configured Classical rule trace is present and reported.")) },
            { check: "RULE_EVIDENCE_LINK", status: (noRuleTrace || missingRules.length) ? "FAIL" : "PASS", detail: (noRuleTrace || missingRules.length) ? "A complete Claim-to-Rule connection cannot be established until the configured rule definitions exist." : "Claim is linked to the configured rule trace for its declared sections; this link does not by itself prove the rule outcome." }
        ];
        const ok = checks.every(function (x) { return x.status === "PASS"; });
        return auditState(ok, ok ? "Claim, evidence ownership, and configured Classical rule trace are connected; rule linkage is provenance, not a new determination formula." : "Evidence-chain audit is not closed; missing links are preserved rather than inferred.", checks);
    }

    function crossCheckFromRuleTrace(master, item, ruleSections) {
        const rules = rulesForSections(master, ruleSections);
        const missing = rules.filter(function (x) { return x.executionStatus === "RULE-MISSING"; });
        const reported = rules.filter(function (x) { return x.executionStatus !== "NOT_EXECUTED" && x.executionStatus !== "RULE-MISSING"; });
        if (missing.length || !reported.length) {
            return { status: "NOT_VERIFIED", detail: "Configured Classical rule trace is incomplete for this determination; no closure is inferred.", ruleTrace: rules };
        }
        if (item.crossCheck && item.crossCheck.status === "INTERNAL_SOURCE_PROFILE_CROSS_CHECKED") {
            return { status: "INTERNAL_SOURCE_PROFILE_CROSS_CHECKED", detail: item.crossCheck.detail, ruleTrace: rules };
        }
        return { status: "NOT_VERIFIED", detail: "Classical rule trace is connected to the determination, but independent cross-source verification is not established by internal rule execution alone.", ruleTrace: rules };
    }

    function normalizeMonthBranch(value) {
        const s = value == null ? "" : String(value);
        const m = s.match(/[子丑寅卯辰巳午未申酉戌亥]/);
        return m ? m[0] : s.trim();
    }

    function chartSignature(master) {
        const p = master && master.A15 && master.A15.fourPillars ? String(master.A15.fourPillars).replace(/\s/g, "") : "";
        const a7 = master && master.A7 ? master.A7 : {};
        const dm = master && master.A15 && master.A15.dayMaster ? String(master.A15.dayMaster) : "";
        return {
            fourPillars: p,
            dayMaster: dm,
            monthBranch: normalizeMonthBranch(a7.monthBranch),
            monthBranchRaw: a7.monthBranch || ""
        };
    }

    /* ----------------------------------------------------------
       GENERIC DETERMINATION RESOLVER
       Rule definitions live in data/determination-rules.js. This layer
       evaluates those declarative conditions against evidence already
       produced by Core B/C. It does not own a second BaZi formula engine.
       ---------------------------------------------------------- */
    function getPath(obj, path) {
        return String(path || "").split(".").reduce(function (cur, key) {
            return cur == null ? undefined : cur[key];
        }, obj);
    }

    function testCondition(condition, context) {
        if (!condition) return true;
        if (condition.all) return condition.all.every(function (c) { return testCondition(c, context); });
        if (condition.any) return condition.any.some(function (c) { return testCondition(c, context); });
        const value = getPath(context, condition.path);
        if (condition.equals !== undefined) return value === condition.equals;
        if (condition.notEquals !== undefined) return value !== condition.notEquals;
        if (condition.matches) return condition.matches.test ? condition.matches.test(String(value == null ? "" : value)) : new RegExp(condition.matches, "i").test(String(value == null ? "" : value));
        if (condition.gte !== undefined) return Number(value) >= Number(condition.gte);
        if (condition.gt !== undefined) return Number(value) > Number(condition.gt);
        if (condition.lte !== undefined) return Number(value) <= Number(condition.lte);
        if (condition.lt !== undefined) return Number(value) < Number(condition.lt);
        if (condition.present === true) return value != null && String(value) !== "";
        return false;
    }

    function normalizeExistingStatus(value) {
        const raw = String(value == null ? "" : value).toUpperCase();
        if (["FINAL", "PROVISIONAL", "CANDIDATE", "UNRESOLVED", "MULTI_METHOD", "CONFLICT"].indexOf(raw) !== -1) return raw;
        if (raw === "RESOLVED") return "FINAL";
        return "UNRESOLVED";
    }

    function evidenceAvailability(definition, context) {
        const refs = Array.isArray(definition && definition.evidence) ? definition.evidence : [];
        return refs.length > 0 && refs.some(function (e) {
            const value = getPath(context, e.path);
            return value != null && String(value) !== "" && !/^(NOT DETERMINED|UNRESOLVED|NOT EXECUTED|null|undefined)$/i.test(String(value));
        });
    }

    function resolveDeterminationRule(definition, context) {
        const statusValue = definition.statusPath ? getPath(context, definition.statusPath) : null;
        const existingStatus = normalizeExistingStatus(statusValue);
        const applicable = definition.applicability ? testCondition(definition.applicability, context) : true;
        const closureChecks = Array.isArray(definition.closureChecks) ? definition.closureChecks.map(function (check) {
            const passed = check && check.condition ? testCondition(check.condition, context) : false;
            return { name: check.name, status: passed ? "PASS" : "OPEN" };
        }) : [];
        const closureOpen = closureChecks.filter(function (check) { return check.status !== "PASS"; });
        // Four-stage determination chain (explicit contract):
        // EVIDENCE -> RULE APPLICATION -> ADJUDICATION -> DETERMINATION.
        // The determination layer must never invent a new BaZi formula: it
        // adjudicates the authoritative section state produced under the
        // configured rule, and may only preserve or weaken that state.
        const evidenceGate = {
            status: evidenceAvailability(definition, context) ? "AVAILABLE" : "INSUFFICIENT",
            basis: "Declared claim evidence was read from the authoritative Core B/C result."
        };
        const ruleApplication = {
            status: applicable ? "APPLICABLE" : "NOT_APPLICABLE",
            ruleId: definition.claimId,
            basis: "Configured determination rule definition evaluated against the chart-specific context."
        };
        const adjudicationStatus = applicable
            ? ((existingStatus === "FINAL" && closureOpen.length) ? "OPEN" : existingStatus)
            : "OPEN";
        const adjudication = {
            status: adjudicationStatus,
            sourceStatus: existingStatus,
            closure: closureOpen.length ? "OPEN" : "CLOSED",
            basis: "Authoritative section result reconciled against the configured closure conditions; no new Classical formula is introduced.",
            mayStrengthenSourceState: false
        };
        const status = applicable
            ? ((adjudicationStatus === "FINAL" && closureOpen.length) ? "UNRESOLVED" : existingStatus)
            : "UNRESOLVED";
        const closed = status === "FINAL";
        const challenge = [];
        closureOpen.forEach(function (check) {
            challenge.push("Closure gate open: " + check.name);
        });
        (definition.challenges || []).forEach(function (item) {
            if (!testCondition(item.when, context)) return;
            challenge.push(item.text);
        });
        if (!applicable && definition.notApplicableChallenge) challenge.push(definition.notApplicableChallenge);
        const evidence = (definition.evidence || []).map(function (e) {
            const value = getPath(context, e.path);
            return makeEvidence(e.id, definition.claimId, e.section, e.field, e.format ? e.format(value, context) : value, "AVAILABLE");
        });
        const external = definition.external && applicable
            ? makeExternalEvidence(definition.external.id, definition.claimId, definition.external.field, definition.external.detail, true, definition.external.sources.map(function (key) { return CLASSICAL_SOURCE_LIBRARY[key]; }).filter(Boolean))
            : null;
        if (external) evidence.push(external);
        const sourceEvidence = applicable && definition.external ? definition.external.sources.map(function (key) { return CLASSICAL_SOURCE_LIBRARY[key]; }).filter(Boolean) : [];
        const resultValue = definition.outcome !== undefined ? definition.outcome : (definition.outcomePath ? getPath(context, definition.outcomePath) : null);
        const result = resultValue == null ? null : resultValue;
        const claim = makeClaim(
            definition.claimId,
            definition.title,
            definition.conditionDescription,
            definition.inputs || [],
            status,
            result,
            evidence.map(function (x) { return x.id; }),
            closed ? [] : [definition.blockingCondition || "Configured source/contract conditions are not fully satisfied."],
            challenge
        );
        if (definition.resolvedValue && closed) claim.resolvedValue = definition.resolvedValue;
        return {
            claim: claim,
            evidence: evidence,
            evidenceGate: evidenceGate,
            ruleApplication: ruleApplication,
            adjudication: adjudication,
            determination: {
                status: status,
                outcome: result,
                basis: closed ? "Adjudication closed under the configured source/profile rule." : "Determination remains open because the authoritative rule/closure state did not close.",
                failClosed: !closed
            },
            closureGate: {
                status: closureOpen.length ? "OPEN" : "CLOSED",
                checks: closureChecks,
                detail: closureOpen.length ? "Configured closure conditions remain open; no FINAL status is inferred." : "All configured closure conditions are satisfied."
            },
            audit: auditState(true, definition.auditDetail || "Determination resolved from existing Core B/C evidence under the configured rule definition."),
            crossCheck: {
                status: closed && sourceEvidence.length ? "INTERNAL_SOURCE_PROFILE_CROSS_CHECKED" : "NOT_VERIFIED",
                detail: closed && sourceEvidence.length ? definition.crossCheckVerified : "Independent source check not closed."
            },
            verification: closed && sourceEvidence.length
                ? { status: "EXTERNAL_INDEPENDENT_VERIFICATION_NOT_ESTABLISHED", scope: "Chart-specific external Classical source profile is available, but independent external verification is not established by this determination path.", sources: semanticSourceList(sourceEvidence) }
                : { status: "NOT_VERIFIED", scope: applicable ? "Chart-specific external Classical source profile not closed" : "No applicable chart-specific external source profile", sources: [] }
        };
    }

    function determinationContext(A, B) {
        const sig = chartSignature(A);
        const b1 = B && B.B1 ? B.B1 : {};
        const b3 = B && B.B3 ? B.B3 : {};
        const b8 = B && B.B8 ? B.B8 : {};
        const b13 = B && B.B13_2 ? B.B13_2 : {};
        return {
            chart: sig,
            B1: b1, B3: b3, B8: b8, B13: b13,
            dayMasterStrength: null, chartPattern: null, transformationFollowing: null,
            upstream: {}
        };
    }

    function confidenceFor(claim, evidenceCount, audit, crossCheck, ruleLinks) {
        const blockers = claim.blockingConditions.length;
        const challenged = claim.challenge.length;
        const connectedRules = Array.isArray(ruleLinks) && ruleLinks.length > 0;
        const traceReady = audit && audit.status === "PASS" && connectedRules && evidenceCount > 0;
        if (claim.status === "FINAL" && blockers === 0 && traceReady && crossCheck.status === "INTERNAL_SOURCE_PROFILE_CROSS_CHECKED") {
            return { level: "HIGH", basis: "Final determination gate, non-empty claim evidence, and executed supporting rule trace are all closed; independent external verification is not claimed unless separately recorded." };
        }
        if (evidenceCount > 0 && traceReady) {
            return { level: (challenged > 1 || claim.status === "UNRESOLVED" || claim.status === "MULTI_METHOD" || claim.status === "CONFLICT") ? "LIMITED" : "MODERATE", basis: blockers ? blockers + " blocking condition(s) remain open." : "Evidence and supporting rule trace available; " + challenged + " challenge condition(s) remain." };
        }
        return { level: "UNRESOLVED", basis: "Evidence and/or supporting rule trace is insufficient for a stronger statement." };
    }

    function reconcileAuthority(context, definition, claim) {
        const sourceStatus = normalizeExistingStatus(definition.statusPath ? getPath(context, definition.statusPath) : null);
        const sourceOutcome = definition.outcomePath ? getPath(context, definition.outcomePath) : null;
        const statusAligned = claim.status === sourceStatus || (sourceStatus === "FINAL" && claim.status === "UNRESOLVED");
        const outcomeAligned = sourceOutcome == null || claim.outcome == null || String(sourceOutcome) === String(claim.outcome);
        return {
            authority: "DETERMINATION_CHAIN",
            precedence: "Section B/C state supplies the source state; closure gates may only preserve or weaken it, never strengthen it.",
            source_status: sourceStatus,
            chain_status: claim.status,
            source_outcome: sourceOutcome == null ? null : sourceOutcome,
            chain_outcome: claim.outcome == null ? null : claim.outcome,
            status: statusAligned && outcomeAligned ? "RECONCILED" : "CONFLICT",
            detail: statusAligned && outcomeAligned
                ? "Determination chain is reconciled with the authoritative section result under the explicit precedence rule."
                : "Section result and determination chain diverge beyond the allowed weakening from FINAL to UNRESOLVED; no final conclusion is permitted."
        };
    }

    function build(master) {
        const A = master || {};
        const B = A;
        const context = determinationContext(A, B);
        const defs = global.PENGGILAS_DETERMINATION_RULES;
        if (!defs) throw new Error("[PenggilasDetermination] determination-rules.js is not loaded.");
        const items = [];
        defs.order.forEach(function (claimId) {
            const definition = defs.rules[claimId];
            const item = resolveDeterminationRule(definition, context);
            context[definition.contextKey] = item;
            context.upstream[claimId] = item.claim;
            items.push(item);
        });
        const claims = {};
        const evidence = [];
        const audits = {};
        const crossChecks = {};
        const confidence = {};
        const verificationDetails = {};

        const RULE_SECTIONS = {
            DAY_MASTER_STRENGTH: ["B1", "B2"],
            CHART_PATTERN: ["B3", "B9"],
            TRANSFORMATION_FOLLOWING: ["B8", "B3"],
            USEFUL_ELEMENT: ["B13", "B3", "B1"]
        };

        items.forEach(function (item) {
            const claimId = item.claim.claimId;
            const definition = defs.rules[claimId];
            const ruleSections = RULE_SECTIONS[claimId] || [];
            let ruleLinks = buildRuleLinks(master, item, ruleSections);
            const audit = auditEvidenceChain(master, item, ruleSections);
            const crossCheck = crossCheckFromRuleTrace(master, item, ruleSections);
            const authorityReconciliation = reconcileAuthority(context, definition, item.claim);
            item.claim.authorityReconciliation = authorityReconciliation;
            if (authorityReconciliation.status === "CONFLICT") {
                item.claim.status = "UNRESOLVED";
                item.claim.outcome = null;
                item.claim.blockingConditions.push("Section result and determination chain are not reconciled.");
            }
            item.claim.ruleLinks = ruleLinks;
            // A determination cannot close when its evidence-chain audit is open.
            // This is a connection/gate correction only; it does not introduce a new BaZi formula.
            if (item.claim.status === "FINAL" && audit.status !== "PASS") {
                item.claim.status = "UNRESOLVED";
                item.claim.outcome = null;
                if (item.claim.blockingConditions.indexOf("Evidence-chain audit is not closed.") === -1) {
                    item.claim.blockingConditions.push("Evidence-chain audit is not closed.");
                }
            }
            claims[claimId] = item.claim;
            evidence.push.apply(evidence, item.evidence);
            audits[claimId] = audit;
            crossChecks[claimId] = crossCheck;
            const usableEvidenceCount = usableEvidenceRecords(item.evidence).length;
            confidence[claimId] = confidenceFor(item.claim, usableEvidenceCount, audit, crossCheck, ruleLinks);
            confidence[claimId].ruleLinkStatus = ruleLinks.length ? "CONNECTED" : "NOT_CONNECTED";
            item.claim.confidence = confidence[claimId].level;
            ruleLinks = finalizeRuleChain(ruleLinks, crossCheck, confidence[claimId]);
            item.claim.ruleLinks = ruleLinks;
            item.claim.ruleChain = ruleLinks;
            const verificationStatus = crossCheck && crossCheck.status === "INTERNAL_SOURCE_PROFILE_CROSS_CHECKED"
                ? "INTERNALLY_CROSS_CHECKED"
                : (item.verification && item.verification.status ? item.verification.status : "NOT_VERIFIED");
            item.claim.verificationStatus = verificationStatus;
            const rawComputationStatuses = ruleLinks.map(function (link) {
                return link && (link.computationStatus || link.computation_status || link.sourceComputationStatus);
            }).filter(Boolean);
            item.claim.computationStatus = rawComputationStatuses.length ? rawComputationStatuses[0] : null;
            verificationDetails[claimId] = Object.assign({}, item.verification || {}, { status: verificationStatus });
        });

        const stateBuckets = {
            FINAL: [],
            UNRESOLVED: [],
            MULTI_METHOD: [],
            CONFLICT: [],
            PROVISIONAL: [],
            CANDIDATE: []
        };
        const closureRecords = {};
        items.forEach(function (x) {
            const claim = x.claim;
            const status = String(claim.status || "").toUpperCase();
            if (stateBuckets[status]) stateBuckets[status].push(claim.claimId);
            const closed = status === "FINAL";
            let reason = closed
                ? "Authoritative determination is closed under the configured source/contract."
                : "Authoritative determination remains open under the configured source/contract.";
            if (status === "MULTI_METHOD") reason = "Multiple method-specific routes remain active without a source-specific unique closure.";
            if (status === "CONFLICT") reason = "Materially inconsistent authoritative evidence/determinations remain unresolved.";
            if (status === "PROVISIONAL") reason = "The supplied determination is conditional or incomplete and is not closed as FINAL.";
            if (status === "CANDIDATE") reason = "The supplied value is a candidate and has not been accepted as an authoritative fact.";
            if (status === "UNRESOLVED") reason = "The determination gate is open because the configured source-profile conditions are not fully satisfied or closed.";
            closureRecords[claim.claimId] = {
                claim_id: claim.claimId,
                status: status,
                closed: closed,
                reason: reason,
                blocking_conditions: closed ? [] : (claim.blockingConditions || []).slice(),
                required_for_closure: closed ? [] : (claim.blockingConditions || []).slice(),
                authority: "DETERMINATION_CHAIN",
                authority_reconciliation: claim.authorityReconciliation || null,
                llm_may_close: false
            };
        });
        const unresolved = stateBuckets.UNRESOLVED.slice();
        const openDeterminationIds = items.filter(function (x) { return x.claim.status !== "FINAL"; }).map(function (x) { return x.claim.claimId; });
        const challengeCount = items.reduce(function (n, x) { return n + x.claim.challenge.length; }, 0);
        const allInternallyClosed = items.every(function (x) { return x.claim.status === "FINAL"; });
        const hasOpenDeterminations = openDeterminationIds.length > 0;
        const synthesisStatus = hasOpenDeterminations ? "CONDITION-DEPENDENT" : "INTERNALLY-DETERMINED";
        const allClaimsTraceable = items.every(function (x) {
            const claimId = x.claim.claimId;
            const audit = audits[claimId];
            const ruleLinks = x.claim.ruleLinks || [];
            return audit && audit.status === "PASS" && ruleLinks.length > 0 && usableEvidenceRecords(x.evidence).length > 0;
        });
        const answerStatus = allInternallyClosed && allClaimsTraceable ? "FINAL-INTERNAL" : "PROVISIONAL";
        const executionEvidenceSignature = global.PENGGILAS_CLASSICAL_EXECUTION_SIGNATURE
            ? global.PENGGILAS_CLASSICAL_EXECUTION_SIGNATURE.bindAll(A)
            : { version: "NOT_LOADED", status: "ENGINE_RULE_GAP" };

        const answer = allInternallyClosed
            ? "B/C adjudication is FINAL-INTERNAL within the configured source profile. Negative determinations remain valid final outcomes; independent external verification remains a separate gate and is not claimed here."
            : (openDeterminationIds.length
                ? "Interpretive answer remains condition-dependent; open determination gates: " + openDeterminationIds.join(", ") + ". Their distinct source-owned states are preserved in determination_state and closureRecords."
                : "Interpretive answer is internally determined under the configured rule profile; external verification remains incomplete.");

        return {
            version: VERSION,
            executionEvidenceSignature: executionEvidenceSignature,
            statusVocabulary: ["CALCULATED", "DERIVED", "SCREENED", "PROVISIONAL", "FINAL", "UNRESOLVED", "MULTI_METHOD", "CONFLICT", "CANDIDATE", "INTERNAL_SOURCE_PROFILE_CROSS_CHECKED", "INTERNALLY_CROSS_CHECKED", "EXTERNAL_INDEPENDENT_VERIFICATION_NOT_ESTABLISHED", "EXTERNALLY_VERIFIED", "NOT_VERIFIED", "HUMAN_INTERPRETER_REQUIRED"],
            pipeline: ["CLASSICAL_RULE", "RULE_CONDITION", "ACTUAL_CHART_EVIDENCE", "CONDITION_EVALUATION", "RULE_RESULT", "CHALLENGE_COUNTER_EVIDENCE", "ADJUDICATION", "CLAIM", "CROSS_CHECK", "CONFIDENCE"],
            profile: {
                fourPillars: chartSignature(A).fourPillars,
                dayMaster: chartSignature(A).dayMaster,
                monthBranch: chartSignature(A).monthBranch,
                scope: "Chart-specific source-profile adjudication; not a universal Classical formula for all charts."
            },
            claims: claims,
            evidence: evidence,
            authority: {
                owner: "DETERMINATION_CHAIN",
                precedence: "Section B/C result → closure gate → determination claim. A closure gate may weaken an open/ambiguous result but may never strengthen it.",
                reconciliation: Object.keys(claims).reduce(function (acc, id) { acc[id] = claims[id].authorityReconciliation || null; return acc; }, {})
            },
            evidence: evidence,
            audits: audits,
            crossCheck: crossChecks,
            challenge: {
                status: challengeCount ? "ACTIVE" : "CLEAR",
                count: challengeCount,
                unresolvedClaimIds: unresolved,
                unresolvedClaimIdsMeaning: "UNRESOLVED state only; use openDeterminationIds for every non-FINAL determination.",
                openDeterminationIds: openDeterminationIds,
                stateBuckets: stateBuckets
            },
            determination_state: {
                open: openDeterminationIds,
                closed: items.filter(function (x) { return x.claim.status === "FINAL"; }).map(function (x) { return x.claim.claimId; }),
                stateBuckets: stateBuckets,
                closureRecords: closureRecords,
                rule: "OPEN is a legitimate determination state, not an execution error. Closure is source/contract-owned and cannot be created by the interpreter."
            },
            synthesis: {
                status: synthesisStatus,
                inputs: ["DAY_MASTER_STRENGTH", "CHART_PATTERN", "TRANSFORMATION_FOLLOWING", "USEFUL_ELEMENT"],
                finalClaimIds: stateBuckets.FINAL.slice(),
                unresolvedClaimIds: unresolved,
                multiMethodClaimIds: stateBuckets.MULTI_METHOD.slice(),
                conflictClaimIds: stateBuckets.CONFLICT.slice(),
                provisionalClaimIds: stateBuckets.PROVISIONAL.slice(),
                candidateClaimIds: stateBuckets.CANDIDATE.slice(),
                unresolvedClaimIdsMeaning: "UNRESOLVED state only; use openDeterminationIds for every non-FINAL determination.",
                openDeterminationIds: openDeterminationIds,
                stateBuckets: stateBuckets,
                rule: "Synthesis preserves distinct upstream states. It must not collapse MULTI_METHOD, CONFLICT, PROVISIONAL, or CANDIDATE into UNRESOLVED. It cannot upgrade an open state into FINAL."
            },
            confidence: confidence,
            answer: {
                status: answerStatus,
                text: answer,
                confidence: (allInternallyClosed && allClaimsTraceable) ? "HIGH" : "LIMITED",
                gate: (allInternallyClosed && allClaimsTraceable) ? "FINAL-INTERNAL + TRACEABLE_EVIDENCE_AND_RULES; EXTERNAL_INDEPENDENT_VERIFICATION_NOT_ESTABLISHED" : "CONFIDENCE-GATED — claim evidence/rule trace or determination closure remains incomplete"
            },
            verification: {
                status: items.length && items.every(function (x) { return x.claim.verificationStatus === "EXTERNALLY_VERIFIED"; }) ? "EXTERNALLY_VERIFIED" : "NOT_VERIFIED",
                scope: "Chart-specific external Classical cross-source verification",
                sources: items.reduce(function (acc, x) {
                    const list = x.verification && Array.isArray(x.verification.sources) ? x.verification.sources : [];
                    list.forEach(function (src) {
                        if (!acc.some(function (existing) { return existing.title === src.title; })) acc.push(src);
                    });
                    return acc;
                }, []),
                note: allInternallyClosed ? "All determinations are closed within the configured source profile; this does not establish independent external Classical verification." : "Verification remains incomplete or not applicable for one or more determinations."
            },
            verificationGate: {
                status: "EXTERNAL_INDEPENDENT_VERIFICATION_NOT_ESTABLISHED",
                rule: "Independent verification requires a source external to the engine's declarative registry to be checked against the same chart claim and recorded with claim-level evidence; source listing alone is insufficient.",
                engineAction: "Do not convert web/source availability into VERIFIED. Preserve the gate as explicit provenance debt until an external audit record is attached.",
                requiredEvidence: ["external source excerpt or stable source record", "claim-level mapping", "chart applicability check", "counter-source/challenge check", "review date"],
                currentStatus: "SOURCE REFERENCES AVAILABLE; INDEPENDENT CLAIM-LEVEL VERIFICATION NOT ESTABLISHED"
            }
        };
    }

    global.PenggilasDetermination = {
        version: VERSION,
        build: build,
        calculate: function () {
            if (!global.masterResult) throw new Error("[PenggilasDetermination] masterResult belum tersedia.");
            const contract = build(global.masterResult);
            global.masterResult._determinationContract = contract;

            // Determination owns the authoritative A12.8 projection. The public
            // field is a projection of the same determination contract; app.js
            // must not adjudicate or patch it after the engine stage.
            const usefulElementClaim = contract && contract.claims && contract.claims["USEFUL_ELEMENT"];
            const resolved = usefulElementClaim && usefulElementClaim.status === "FINAL"
                ? usefulElementClaim.resolvedValue
                : null;
            global.masterResult.A12_8 = {
                yongshen: resolved && resolved.label ? resolved.label : "NOT DETERMINED",
                xishen: "NOT DETERMINED",
                jishen: "NOT DETERMINED",
                _source: "_determinationContract.USEFUL_ELEMENT",
                _status: usefulElementClaim ? usefulElementClaim.status : "NOT DETERMINED"
            };

            return contract;
        }
    };
})(window);
