package main
import "fmt"
func main(){hp,s,a,p:=100,0,5,2;for hp>0{hp-=50;s++};for p>0&&a<14{a++;p--};n:=min(30,90);fmt.Printf("shots=%d alive=%d mag=%d res=%d\n",s,a,n,90-n)}
