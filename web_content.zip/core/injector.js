(() => {
  if (window.__micMaxInjectorReady) return;
  window.__micMaxInjectorReady = true;

  // Omni Messenger Lord v4 — Studio HD default profile (loud + clean).
  // Developer: Mahir. Clamps keep every control recoverable.
  const DEFAULTS = {
    enabled: true,
    gainDb: 48,
    thresholdDb: -42,
    knee: 30,
    ratio: 10,
    attack: 0.003,
    release: 0.12,
    lowShelfDb: 2,
    presenceDb: 6,
    highShelfDb: 4,
    limiterDb: -1.5,
    drive: 0.6,
    loudness: 6,
    maxBoost: 2000,
    sustain: true,
    sustainTargetDb: -10,
    sustainMaxGain: 10,
    forceRawMic: true,
    noiseGate: true,
    gateThresholdDb: -50,
    deEsserDb: -3,
    mudCutDb: -3
  };
  const MSG_CFG = 'MIC_MAXIMIZER_CONFIG';
  const AUDIO_SEND_MAX_BITRATE = 510000;
  const state = {
    config: { ...DEFAULTS },
    origMD: null,
    origLegacy: null,
    pipelines: new Set(),
    trackMap: new WeakMap(),
    processedTracks: new WeakSet(),
    processedMeta: new WeakMap(),
    senderWatchTracks: new WeakSet(),
    peerConnections: new Set(),
    senderRecords: new Set(),
    senderBySender: new WeakMap(),
    refreshingSenders: new WeakSet(),
    recoverTimers: new Set(),
    sourceTracks: new Set(),
    origApplyConstraints: null,
    lastAudioConstraints: { audio: true }
  };
  const clamp = (value, min, max) => Math.min(max, Math.max(min, Number.isFinite(Number(value)) ? Number(value) : min));
  const dbToLinear = (db) => Math.pow(10, db / 20);

  function cfg(input = state.config) {
    const merged = { ...DEFAULTS, ...(input || {}) };
    merged.enabled = Boolean(merged.enabled);
    merged.maxBoost = clamp(merged.maxBoost, 1, 5000);
    merged.loudness = clamp(merged.loudness, 0.5, merged.maxBoost);
    merged.gainDb = clamp(merged.gainDb, 0, 120);
    merged.drive = clamp(merged.drive, 0, 10);
    merged.thresholdDb = clamp(merged.thresholdDb, -100, 0);
    merged.knee = clamp(merged.knee, 0, 40);
    // DynamicsCompressorNode.ratio has a nominal browser range of [1, 20].
    // Values above 20 trigger Quetta/Chromium extension errors/warnings at setTargetAtTime.
    merged.ratio = clamp(merged.ratio, 1, 20);
    merged.attack = clamp(merged.attack, 0.0001, 1);
    merged.release = clamp(merged.release, 0.01, 1);
    merged.lowShelfDb = clamp(merged.lowShelfDb, -24, 24);
    merged.presenceDb = clamp(merged.presenceDb, -24, 24);
    merged.highShelfDb = clamp(merged.highShelfDb, -24, 24);
    merged.limiterDb = clamp(merged.limiterDb, -24, 0);
    merged.sustain = Boolean(merged.sustain);
    merged.sustainTargetDb = clamp(merged.sustainTargetDb, -24, -1);
    merged.sustainMaxGain = clamp(merged.sustainMaxGain, 1, 64);
    merged.forceRawMic = Boolean(merged.forceRawMic);
    merged.noiseGate = Boolean(merged.noiseGate);
    merged.gateThresholdDb = clamp(merged.gateThresholdDb, -80, -20);
    merged.deEsserDb = clamp(merged.deEsserDb, -12, 0);
    merged.mudCutDb = clamp(merged.mudCutDb, -12, 0);
    return merged;
  }

  function makeSaturationCurve(amount = 0.5) {
    const k = Math.max(0.0001, amount * 100);
    const n = 4096;
    const curve = new Float32Array(n);
    for (let i = 0; i < n; i += 1) {
      const x = (i * 2) / n - 1;
      curve[i] = ((Math.PI + k) * x) / (Math.PI + k * Math.abs(x));
    }
    return curve;
  }

  function setParam(param, value, ctx) {
    if (!param) return;
    const safeValue = clamp(value, param.minValue ?? -Infinity, param.maxValue ?? Infinity);
    const now = ctx?.currentTime || 0;
    try {
      if (typeof param.cancelScheduledValues === 'function') param.cancelScheduledValues(now);
      if (typeof param.setTargetAtTime === 'function') param.setTargetAtTime(safeValue, now, 0.005);
      else param.value = safeValue;
    } catch (_) {
      try { param.value = safeValue; } catch (_) {}
    }
  }

  function applyPipeline(pipeline, inputConfig = state.config) {
    const raw = cfg(inputConfig);
    const c = raw.enabled ? raw : {
      ...raw,
      lowShelfDb: 0,
      presenceDb: 0,
      highShelfDb: 0,
      thresholdDb: -6,
      knee: 0,
      ratio: 1,
      loudness: 1,
      gainDb: 0,
      drive: 0,
      limiterDb: -0.5,
      noiseGate: false,
      deEsserDb: 0,
      mudCutDb: 0
    };
    const { ctx, nodes } = pipeline;
    pipeline.live = c;
    setParam(nodes.mud.gain, c.mudCutDb, ctx);
    setParam(nodes.low.gain, c.lowShelfDb, ctx);
    setParam(nodes.pres.gain, c.presenceDb, ctx);
    setParam(nodes.high.gain, c.highShelfDb, ctx);
    setParam(nodes.comp1.threshold, c.thresholdDb, ctx);
    setParam(nodes.comp1.knee, c.knee, ctx);
    setParam(nodes.comp1.ratio, c.ratio, ctx);
    setParam(nodes.comp1.attack, c.attack, ctx);
    setParam(nodes.comp1.release, c.release, ctx);
    setParam(nodes.loudness.gain, c.loudness, ctx);
    setParam(nodes.gain.gain, dbToLinear(c.gainDb), ctx);
    nodes.saturator.curve = makeSaturationCurve(c.drive);
    if (nodes.sustain && !c.sustain) setParam(nodes.sustain.gain, 1, ctx);
    setParam(nodes.limiter.threshold, c.limiterDb, ctx);
  }

  function updateAllPipelines(inputConfig = state.config) {
    for (const pipeline of state.pipelines) applyPipeline(pipeline, inputConfig);
  }

  function resumePipeline(pipeline) {
    const ctx = pipeline?.ctx;
    if (!ctx || ctx.state === 'closed' || typeof ctx.resume !== 'function') return;
    if (ctx.state !== 'running') ctx.resume().catch(() => {});
  }

  function resumeAllPipelines() {
    for (const pipeline of state.pipelines) resumePipeline(pipeline);
  }

  function rmsDbFromAnalyser(analyser, buffer) {
    analyser.getByteTimeDomainData(buffer);
    let sum = 0;
    for (let i = 0; i < buffer.length; i += 1) {
      const sample = (buffer[i] - 128) / 128;
      sum += sample * sample;
    }
    const rms = Math.sqrt(sum / buffer.length);
    return 20 * Math.log10(Math.max(rms, 0.000001));
  }

  function rmsDbFloat(analyser, buffer) {
    analyser.getFloatTimeDomainData(buffer);
    let sum = 0;
    for (let i = 0; i < buffer.length; i += 1) sum += buffer[i] * buffer[i];
    return 10 * Math.log10(Math.max(sum / buffer.length, 1e-12));
  }

  // Noise gate + dynamic de-esser. Reads the clean (pre-boost) signal, so the
  // thresholds are in raw-mic dBFS and do not move when Gain / Loudness change.
  function startVoiceController(pipeline) {
    const { ctx, nodes } = pipeline;
    if (!nodes.rawMeter || !nodes.sibMeter) return;
    const rawBuf = new Float32Array(nodes.rawMeter.fftSize);
    const sibBuf = new Float32Array(nodes.sibMeter.fftSize);
    let gateOpen = true;
    let holdUntil = 0;
    let deessAmount = 0;
    pipeline.gateClosed = false;
    pipeline.voiceTimer = setInterval(() => {
      if (ctx.state === 'closed') return;
      const c = pipeline.live || cfg();
      const now = performance.now();

      // Background tabs throttle timers: never leave the gate shut, use a fixed gentle de-ess.
      if (document.hidden || ctx.state !== 'running') {
        gateOpen = true;
        pipeline.gateClosed = false;
        setParam(nodes.gate.gain, 1, ctx);
        setParam(nodes.deess.gain, c.deEsserDb * 0.4, ctx);
        return;
      }

      const fullDb = rmsDbFloat(nodes.rawMeter, rawBuf);

      if (c.noiseGate) {
        if (fullDb > c.gateThresholdDb) {
          gateOpen = true;
          holdUntil = now + 280;
        } else if (gateOpen && fullDb < c.gateThresholdDb - 4 && now > holdUntil) {
          gateOpen = false;
        }
      } else {
        gateOpen = true;
      }
      pipeline.gateClosed = !gateOpen;
      const gateTarget = gateOpen ? 1 : 0.06;
      try {
        nodes.gate.gain.cancelScheduledValues(ctx.currentTime);
        nodes.gate.gain.setTargetAtTime(gateTarget, ctx.currentTime, gateOpen ? 0.008 : 0.07);
      } catch (_) {
        nodes.gate.gain.value = gateTarget;
      }

      // De-esser: sibilant band (5-9 kHz) dominating the full signal => pull the cut in.
      let wanted = 0;
      if (c.deEsserDb < 0 && gateOpen && fullDb > c.gateThresholdDb - 6) {
        const sibDb = rmsDbFloat(nodes.sibMeter, sibBuf);
        const ratio = sibDb - fullDb; // ~0 dB when it is all "sss", < -15 dB for vowels
        wanted = Math.min(1, Math.max(0, (ratio + 14) / 8));
      }
      deessAmount += (wanted - deessAmount) * (wanted > deessAmount ? 0.7 : 0.25);
      setParam(nodes.deess.gain, c.deEsserDb * deessAmount, ctx);
    }, 30);
  }

  function startSustainController(pipeline) {
    const { ctx, nodes } = pipeline;
    if (!nodes.meter || !nodes.sustain) return;
    const buffer = new Uint8Array(nodes.meter.fftSize);
    let currentGain = 1;
    pipeline.sustainTimer = setInterval(() => {
      const c = cfg();
      if (!c.enabled || !c.sustain || ctx.state === 'closed') {
        currentGain = 1;
        setParam(nodes.sustain.gain, 1, ctx);
        return;
      }
      resumePipeline(pipeline);
      // Gate shut = silence between words: do not lift the noise floor back up.
      if (pipeline.gateClosed) {
        currentGain = Math.max(1, currentGain * 0.7);
        setParam(nodes.sustain.gain, currentGain, ctx);
        return;
      }
      const db = rmsDbFromAnalyser(nodes.meter, buffer);
      const target = c.sustainTargetDb;
      if (db < target) {
        const lift = 1 + Math.min(1.2, Math.max(0.02, (target - db) * 0.035));
        currentGain = Math.min(c.sustainMaxGain, currentGain * lift);
      } else {
        currentGain = Math.max(1, currentGain * 0.82);
      }
      setParam(nodes.sustain.gain, currentGain, ctx);
    }, 120);
  }

  function createAudioContext() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try {
      return new AC({ latencyHint: 'interactive', sampleRate: 48000 });
    } catch (_) {
      return new AC({ latencyHint: 'interactive' });
    }
  }

  function build(stream, inputConfig) {
    const ctx = createAudioContext();
    if (!ctx || !stream.getAudioTracks().length) return stream;
    stream.getAudioTracks().forEach(enforceRawMicTrack);

    const source = ctx.createMediaStreamSource(stream);
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 75;
    hp.Q.value = 0.7;

    // v4 voice clarity: gate (driven by the raw meter), mud cut, dynamic de-esser.
    const gate = ctx.createGain();
    const rawMeter = ctx.createAnalyser();
    rawMeter.fftSize = 1024;
    rawMeter.smoothingTimeConstant = 0;
    const sibBand = ctx.createBiquadFilter();
    sibBand.type = 'bandpass';
    sibBand.frequency.value = 7000;
    sibBand.Q.value = 1.1;
    const sibMeter = ctx.createAnalyser();
    sibMeter.fftSize = 1024;
    sibMeter.smoothingTimeConstant = 0;

    const mud = ctx.createBiquadFilter();
    mud.type = 'peaking';
    mud.frequency.value = 260;
    mud.Q.value = 1.0;

    const deess = ctx.createBiquadFilter();
    deess.type = 'peaking';
    deess.frequency.value = 6800;
    deess.Q.value = 2.2;

    const low = ctx.createBiquadFilter();
    low.type = 'lowshelf';
    low.frequency.value = 200;

    const pres = ctx.createBiquadFilter();
    pres.type = 'peaking';
    pres.frequency.value = 3200;
    pres.Q.value = 1.5;

    const high = ctx.createBiquadFilter();
    high.type = 'highshelf';
    high.frequency.value = 6000;

    const comp1 = ctx.createDynamicsCompressor();
    const comp2 = ctx.createDynamicsCompressor();
    comp2.threshold.value = -10;
    comp2.knee.value = 5;
    comp2.ratio.value = 12;
    comp2.attack.value = 0.001;
    comp2.release.value = 0.05;

    const loudness = ctx.createGain();
    const gain = ctx.createGain();
    const saturator = ctx.createWaveShaper();
    saturator.oversample = '4x';
    const sustain = ctx.createGain();
    sustain.gain.value = 1;

    const limiter = ctx.createDynamicsCompressor();
    limiter.knee.value = 0;
    limiter.ratio.value = 20;
    limiter.attack.value = 0.0001;
    limiter.release.value = 0.01;

    const meter = ctx.createAnalyser();
    meter.fftSize = 1024;
    meter.smoothingTimeConstant = 0.18;

    const dst = ctx.createMediaStreamDestination();
    source.connect(hp);
    hp.connect(rawMeter);
    hp.connect(sibBand);
    sibBand.connect(sibMeter);
    hp.connect(gate);
    gate.connect(mud);
    mud.connect(deess);
    deess.connect(low);
    low.connect(pres);
    pres.connect(high);
    high.connect(comp1);
    comp1.connect(comp2);
    comp2.connect(loudness);
    loudness.connect(gain);
    gain.connect(saturator);
    saturator.connect(sustain);
    sustain.connect(limiter);
    limiter.connect(meter);
    meter.connect(dst);

    const pipeline = {
      ctx,
      nodes: { gate, rawMeter, sibMeter, mud, deess, low, pres, high, comp1, loudness, gain, saturator, sustain, limiter, meter },
      sustainTimer: null,
      voiceTimer: null,
      gateClosed: false,
      live: null
    };
    applyPipeline(pipeline, inputConfig);
    state.pipelines.add(pipeline);
    startVoiceController(pipeline);
    startSustainController(pipeline);
    resumePipeline(pipeline);

    const outAudioTracks = dst.stream.getAudioTracks();
    outAudioTracks.forEach((track) => {
      state.processedTracks.add(track);
      state.processedMeta.set(track, { source: stream, pipeline });
    });

    const out = new MediaStream([
      ...outAudioTracks,
      ...stream.getTracks().filter((track) => track.kind !== 'audio')
    ]);

    const stop = () => {
      state.pipelines.delete(pipeline);
      if (pipeline.sustainTimer) clearInterval(pipeline.sustainTimer);
      if (pipeline.voiceTimer) clearInterval(pipeline.voiceTimer);
      stream.getAudioTracks().forEach((track) => state.sourceTracks.delete(track));
      try { ctx.close(); } catch (_) {}
    };
    stream.getTracks().forEach((track) => track.addEventListener('ended', stop, { once: true }));
    return out;
  }

  function rawMicAudioConstraints(audio = {}) {
    const base = audio && typeof audio === 'object' ? audio : {};
    return {
      ...base,
      echoCancellation: false,
      noiseSuppression: false,
      autoGainControl: false,
      googAutoGainControl: false,
      googNoiseSuppression: false,
      googHighpassFilter: false,
      googEchoCancellation: false,
      googEchoCancellation2: false,
      googDAEchoCancellation: false,
      googTypingNoiseDetection: false,
      googAudioMirroring: false,
      channelCount: { ideal: 1 },
      sampleRate: { ideal: 48000 },
      sampleSize: { ideal: 16 }
    };
  }

  function enforceRawMicTrack(track) {
    if (!track || track.kind !== 'audio' || !cfg().forceRawMic) return;
    state.sourceTracks.add(track);
    try { track.contentHint = 'speech'; } catch (_) {}
    if (typeof track.applyConstraints === 'function') {
      try { track.applyConstraints(rawMicAudioConstraints()).catch(() => {}); } catch (_) {}
    }
  }

  function enforceAllSourceConstraints() {
    for (const track of [...state.sourceTracks]) {
      if (!track || track.readyState === 'ended') {
        state.sourceTracks.delete(track);
        continue;
      }
      enforceRawMicTrack(track);
    }
  }

  function patchTrackConstraints() {
    const proto = window.MediaStreamTrack?.prototype;
    if (!proto || proto.__micMaxTrackPatched || typeof proto.applyConstraints !== 'function') return;
    state.origApplyConstraints = proto.applyConstraints;
    proto.applyConstraints = function applyConstraints(constraints = {}) {
      const next = cfg().enabled && cfg().forceRawMic && this.kind === 'audio'
        ? rawMicAudioConstraints(constraints)
        : constraints;
      return state.origApplyConstraints.call(this, next);
    };
    proto.__micMaxTrackPatched = true;
  }

  function normalizeConstraints(constraints) {
    if (constraints === true) constraints = { audio: true };
    if (!constraints || typeof constraints !== 'object') return constraints;
    const next = { ...constraints };
    if (next.audio === true) next.audio = {};
    if (typeof next.audio === 'object') next.audio = rawMicAudioConstraints(next.audio);
    return next;
  }

  function wantsAudio(constraints) {
    if (constraints === true) return true;
    if (!constraints || typeof constraints !== 'object') return false;
    return 'audio' in constraints ? Boolean(constraints.audio) : true;
  }

  function processedStreamFor(originalStream, rawTrack, processedTrack) {
    if (!originalStream || typeof originalStream.getTracks !== 'function') return new MediaStream([processedTrack]);
    return new MediaStream(originalStream.getTracks().map((track) => (track === rawTrack ? processedTrack : track)));
  }

  function liveAudioTrack(stream) {
    if (!stream || typeof stream.getAudioTracks !== 'function') return null;
    return stream.getAudioTracks().find((track) => track.readyState !== 'ended') || null;
  }

  function processedSourceIsLive(track) {
    if (!track || !state.processedTracks.has(track)) return true;
    const meta = state.processedMeta.get(track);
    if (!meta) return true;
    resumePipeline(meta.pipeline);
    return Boolean(liveAudioTrack(meta.source));
  }

  function trackNeedsRefresh(track) {
    if (!track || track.kind !== 'audio') return true;
    if (track.readyState === 'ended') return true;
    if (!state.processedTracks.has(track)) return true;
    return !processedSourceIsLive(track);
  }

  function rebuildProcessedTrack(track) {
    const meta = state.processedMeta.get(track);
    const sourceTrack = liveAudioTrack(meta?.source);
    if (!sourceTrack) return track;
    try {
      const rebuiltStream = build(new MediaStream([sourceTrack]), state.config);
      return liveAudioTrack(rebuiltStream) || track;
    } catch (_) {
      return track;
    }
  }

  function cloneForSender(track) {
    const liveTrack = track?.readyState === 'ended' ? rebuildProcessedTrack(track) : track;
    if (!liveTrack || liveTrack.readyState === 'ended' || typeof liveTrack.clone !== 'function') return liveTrack;
    try {
      const clone = liveTrack.clone();
      state.processedTracks.add(clone);
      const meta = state.processedMeta.get(liveTrack);
      if (meta) state.processedMeta.set(clone, meta);
      return clone;
    } catch (_) {
      return liveTrack;
    }
  }

  function processAudioTrack(track, forSender = false) {
    if (!track || track.kind !== 'audio') return track;
    if (state.processedTracks.has(track)) {
      const nextTrack = track.readyState === 'ended' ? rebuildProcessedTrack(track) : track;
      return forSender ? cloneForSender(nextTrack) : nextTrack;
    }

    const existing = state.trackMap.get(track);
    if (existing) {
      const nextTrack = existing.readyState === 'ended' ? rebuildProcessedTrack(existing) : existing;
      if (nextTrack && nextTrack !== existing && nextTrack.readyState !== 'ended') state.trackMap.set(track, nextTrack);
      if (nextTrack && nextTrack.readyState !== 'ended') return forSender ? cloneForSender(nextTrack) : nextTrack;
    }

    const processedStream = build(new MediaStream([track]), state.config);
    const processedTrack = liveAudioTrack(processedStream) || track;
    if (processedTrack !== track) {
      state.processedTracks.add(processedTrack);
      state.trackMap.set(track, processedTrack);
      track.addEventListener('ended', () => {
        try { processedTrack.stop(); } catch (_) {}
      }, { once: true });
    }
    return forSender ? cloneForSender(processedTrack) : processedTrack;
  }

  function tuneAudioSender(sender) {
    if (!sender || typeof sender.getParameters !== 'function' || typeof sender.setParameters !== 'function') return;
    try {
      const params = sender.getParameters() || {};
      const encodings = Array.isArray(params.encodings) && params.encodings.length ? params.encodings : [{}];
      params.encodings = encodings.map((encoding) => ({
        ...encoding,
        active: encoding.active !== false,
        dtx: false,
        maxBitrate: Math.max(Number(encoding.maxBitrate) || 0, AUDIO_SEND_MAX_BITRATE),
        networkPriority: 'high',
        priority: 'high'
      }));
      sender.setParameters(params).catch(() => {});
    } catch (_) {}
  }

  function rememberPeerConnection(pc) {
    if (!pc || state.peerConnections.has(pc)) return;
    state.peerConnections.add(pc);
    if (typeof pc.addEventListener === 'function') {
      pc.addEventListener('connectionstatechange', () => {
        if (['closed', 'failed'].includes(pc.connectionState)) state.peerConnections.delete(pc);
      });
    }
  }

  function rememberSender(sender, track, pc = null) {
    if (!sender) return null;
    let record = state.senderBySender.get(sender);
    if (!record) {
      record = { sender, track: null, pc: null };
      state.senderBySender.set(sender, record);
      state.senderRecords.add(record);
    }
    if (track) record.track = track;
    if (pc) record.pc = pc;
    return record;
  }

  function recordIsClosed(record) {
    const pc = record?.pc;
    if (!pc) return false;
    return ['closed', 'failed'].includes(pc.connectionState || pc.iceConnectionState || '');
  }

  async function reacquireProcessedTrackForSender() {
    if (!state.origMD) return null;
    try {
      const constraints = normalizeConstraints(state.lastAudioConstraints || { audio: true });
      const stream = await state.origMD(constraints);
      const rawTrack = liveAudioTrack(stream);
      if (!rawTrack) return null;
      return processAudioTrack(rawTrack, true);
    } catch (_) {
      return null;
    }
  }

  async function replaceSenderTrack(sender, track) {
    if (!sender || typeof sender.replaceTrack !== 'function') return null;
    rememberSender(sender, track);
    const current = track || sender.track;
    let replacement = null;

    if (current && current.kind === 'audio' && !trackNeedsRefresh(current)) {
      replacement = current;
    } else if (current && current.kind === 'audio' && current.readyState !== 'ended' && !state.processedTracks.has(current)) {
      replacement = processAudioTrack(current, true);
    }

    if (!replacement || trackNeedsRefresh(replacement)) replacement = await reacquireProcessedTrackForSender();
    if (!replacement || replacement.readyState === 'ended') return null;

    try {
      await sender.replaceTrack(replacement);
      tuneAudioSender(sender);
      rememberSender(sender, replacement);
      watchSenderTrack(sender, replacement);
      return replacement;
    } catch (_) {
      return null;
    }
  }

  function queueSenderRefresh(sender, track) {
    resumeAllPipelines();
    if (!sender || state.refreshingSenders.has(sender)) return;
    state.refreshingSenders.add(sender);
    setTimeout(() => {
      replaceSenderTrack(sender, track).finally(() => state.refreshingSenders.delete(sender));
    }, 50);
  }

  function watchSenderTrack(sender, track) {
    if (!sender || !track || track.kind !== 'audio') return;
    rememberSender(sender, track);
    if (!state.processedTracks.has(track) || state.senderWatchTracks.has(track)) return;
    state.senderWatchTracks.add(track);
    track.addEventListener('ended', () => queueSenderRefresh(sender, track), { once: true });
  }

  function scheduleRecoveryPasses() {
    for (const timer of state.recoverTimers) clearTimeout(timer);
    state.recoverTimers.clear();
    [0, 150, 500, 1200, 2500, 5000, 9000].forEach((delay) => {
      const timer = setTimeout(() => {
        state.recoverTimers.delete(timer);
        resumeAllPipelines();
        reconcileLiveSenders();
      }, delay);
      state.recoverTimers.add(timer);
    });
  }

  function reconcileLiveSenders() {
    if (!cfg().enabled) return;
    resumeAllPipelines();
    for (const pc of [...state.peerConnections]) {
      if (typeof pc.getSenders !== 'function') continue;
      try {
        for (const sender of pc.getSenders()) {
          const track = sender?.track;
          if (track?.kind === 'audio') rememberSender(sender, track);
        }
      } catch (_) {}
    }

    for (const record of [...state.senderRecords]) {
      if (recordIsClosed(record)) {
        state.senderRecords.delete(record);
        continue;
      }
      const sender = record.sender;
      const track = sender?.track || record.track;
      if (!sender || !track || track.kind !== 'audio') continue;
      if (trackNeedsRefresh(track)) queueSenderRefresh(sender, track);
      else {
        tuneAudioSender(sender);
        watchSenderTrack(sender, track);
      }
    }
  }

  function patchPeerConnectionPaths() {
    const PC = window.RTCPeerConnection || window.webkitRTCPeerConnection;
    if (PC?.prototype && !PC.prototype.__micMaxPcPatched) {
      const originalAddTrack = PC.prototype.addTrack;
      if (typeof originalAddTrack === 'function') {
        PC.prototype.addTrack = function addTrack(track, ...streams) {
          rememberPeerConnection(this);
          if (cfg().enabled && track?.kind === 'audio') {
            const processedTrack = processAudioTrack(track, true);
            const patchedStreams = streams.length
              ? streams.map((stream) => processedStreamFor(stream, track, processedTrack))
              : [new MediaStream([processedTrack])];
            const sender = originalAddTrack.call(this, processedTrack, ...patchedStreams);
            tuneAudioSender(sender);
            rememberSender(sender, processedTrack, this);
            if (typeof sender?.replaceTrack === 'function') watchSenderTrack(sender, processedTrack);
            return sender;
          }
          return originalAddTrack.call(this, track, ...streams);
        };
      }

      const originalAddTransceiver = PC.prototype.addTransceiver;
      if (typeof originalAddTransceiver === 'function') {
        PC.prototype.addTransceiver = function addTransceiver(trackOrKind, init = undefined) {
          rememberPeerConnection(this);
          if (cfg().enabled && trackOrKind?.kind === 'audio') {
            const processedTrack = processAudioTrack(trackOrKind, true);
            const patchedInit = init?.streams
              ? { ...init, streams: init.streams.map((stream) => processedStreamFor(stream, trackOrKind, processedTrack)) }
              : init;
            const transceiver = originalAddTransceiver.call(this, processedTrack, patchedInit);
            tuneAudioSender(transceiver?.sender);
            rememberSender(transceiver?.sender, processedTrack, this);
            if (typeof transceiver?.sender?.replaceTrack === 'function') watchSenderTrack(transceiver.sender, processedTrack);
            return transceiver;
          }
          return originalAddTransceiver.call(this, trackOrKind, init);
        };
      }
      PC.prototype.__micMaxPcPatched = true;
    }

    const Sender = window.RTCRtpSender;
    if (Sender?.prototype && !Sender.prototype.__micMaxSenderPatched) {
      const originalReplaceTrack = Sender.prototype.replaceTrack;
      if (typeof originalReplaceTrack === 'function') {
        Sender.prototype.replaceTrack = function replaceTrack(track) {
          const nextTrack = cfg().enabled && track?.kind === 'audio' ? processAudioTrack(track, true) : track;
          const result = originalReplaceTrack.call(this, nextTrack);
          if (nextTrack?.kind === 'audio') {
            rememberSender(this, nextTrack);
            Promise.resolve(result).then(() => {
              tuneAudioSender(this);
              watchSenderTrack(this, nextTrack);
            }).catch(() => {});
          }
          return result;
        };
      }
      Sender.prototype.__micMaxSenderPatched = true;
    }
  }

  async function getStreamWithFallback(orig, constraints, ctx) {
    try {
      return await orig.call(ctx, normalizeConstraints(constraints));
    } catch (_) {
      return orig.call(ctx, constraints);
    }
  }

  async function wrapped(orig, constraints, ctx) {
    if (wantsAudio(constraints)) state.lastAudioConstraints = constraints || { audio: true };
    const stream = await getStreamWithFallback(orig, constraints, ctx);
    if (!cfg().enabled || !wantsAudio(constraints)) return stream;
    try {
      return build(stream, state.config);
    } catch (_) {
      return stream;
    }
  }

  patchPeerConnectionPaths();
  patchTrackConstraints();

  if (navigator.mediaDevices?.getUserMedia) {
    state.origMD = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = (constraints) => wrapped(state.origMD, constraints, navigator.mediaDevices);
  }

  if (navigator.getUserMedia) {
    state.origLegacy = navigator.getUserMedia.bind(navigator);
    navigator.getUserMedia = (constraints, ok, fail) => {
      wrapped(state.origLegacy, constraints, navigator).then(ok).catch((err) => fail && fail(err));
    };
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.type !== MSG_CFG) return;
    state.config = cfg(event.data.payload);
    updateAllPipelines(state.config);
    scheduleRecoveryPasses();
  });

  ['focus', 'pageshow', 'online', 'pointerdown', 'touchstart'].forEach((type) => {
    window.addEventListener(type, scheduleRecoveryPasses, { passive: true });
  });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) scheduleRecoveryPasses();
  });

  setInterval(() => {
    enforceAllSourceConstraints();
    resumeAllPipelines();
    reconcileLiveSenders();
  }, 1000);
  window.postMessage({ type: 'MIC_MAXIMIZER_READY' }, '*');
})();
