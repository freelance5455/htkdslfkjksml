# PENGGILAS — AI JSON Contract (Current)

## Purpose
This document defines the contract between the read-only `MASTER RESULT`, the template-bound JSON mapper, and the external LLM interpreter. It replaces the earlier semantic-record / primitive-oriented contract.

## Source of truth
`MASTER RESULT` is the only analytical source of truth. The mapper projects supplied values into the AI-facing template. It does not calculate, adjudicate, select winners, or modify the source result.

### Authority boundary
The authority chain is deliberately one-way:

```text
MASTER RESULT
    │
    ├──→ Human HTML presentation
    │
    └──→ JSON Mapper → AI Result JSON → AI Interpreter
```

The Human HTML and AI Result JSON are **projections of the same MasterResult**, not alternative analytical results. The external AI Interpreter does **not** consume `MasterResult` directly; it consumes the AI Result JSON produced by the mapper. The AI Result JSON is therefore the interpreter's source payload, while `MasterResult` remains the underlying analytical authority.

The AI Interpreter may explain and synthesize only what is supplied in that AI-facing projection. It must never become a second BaZi engine or an alternative authority.

```text
MASTER RESULT
     ↓
json-mapper.js
     ↓
AI RESULT JSON
     +
AI INSTRUCTION
     ↓
LLM INTERPRETER
```

HTML/PDF is a human presentation layer and is not scraped to create the AI JSON.

## BAZI DATA TREE
The AI-facing payload follows the classification already established by the template. The order is preserved exactly: `A1 → A17 → B1 → B17 → C1 → C7`.

```text
BAZI CHART DATA
│
├── A. FOUNDATION MASTER
│   └── What is here?
│
├── B. PROFILE & STRUCTURE / GE JU
│   └── What structure does it form?
│
└── C. TEMPORAL DYNAMICS
    └── How does it respond over time?
```

The semantic relationship is:

> **A builds foundational facts → B builds structural interpretation from those facts → C applies temporal dynamics to that established structure.**

A establishes chart facts and classical/derived foundation. B interprets the structural configuration formed from A. C describes temporal interaction with that established structure. C is not an alternate engine for rewriting B.

Internal table identifiers are implementation metadata and are not part of the AI vocabulary.

## State boundaries
The payload may carry three conceptually separate state dimensions when supplied by the source result:

- **Determination state:** `FINAL`, `PROVISIONAL`, `CANDIDATE`, `UNRESOLVED`, `MULTI_METHOD`, `CONFLICT`.
- **Computation state:** `CALCULATED`.
- **Verification state:** `INTERNALLY_CROSS_CHECKED`, `EXTERNALLY_VERIFIED`, `NOT_VERIFIED`, or `EXTERNAL_INDEPENDENT_VERIFICATION_NOT_ESTABLISHED`, only within the explicitly supplied verification scope.

The following distinctions are mandatory:

```text
UNRESOLVED   ≠ FINAL
MULTI_METHOD ≠ UNRESOLVED
CONFLICT     ≠ CONFIRMED
PROVISIONAL  ≠ FINAL
CANDIDATE    ≠ FACT
CALCULATED   ≠ verification
INTERNALLY_CROSS_CHECKED ≠ independent / cross-source Classical verification
EXTERNALLY_VERIFIED = independent verification only when an explicit claim-level external record is supplied
```

The mapper preserves supplied state. It never upgrades a state because a value exists, because another section contains a related value, or because the model could reason to a preferred answer.

## Null semantics
`null` means that the source supplied no value for that field. It does not automatically mean unresolved, not applicable, false, or verified. The LLM must not fill nulls by inference.

## Evidence boundary
Evidence, source, basis, qualification, condition, relationship, and verification scope remain source-owned. The mapper may separate supplied information into the appropriate existing template fields, but it must not manufacture missing evidence or turn processing notes into Classical evidence.

## Scope boundary
Section placement is analytical context. A natal structural finding in B and a temporal finding in C can both be valid without being competing claims. The LLM must not treat temporal context as permission to rewrite the natal structural result.

## Conflict and open determination
An open determination is a legitimate source-owned state, not an execution failure. `MULTI_METHOD` and `CONFLICT` must remain distinct. The LLM may explain supplied alternatives and their scope, but may not choose a winner, invent precedence, or close an open determination.

## Verification boundary
Verification is claim-scoped. Internal calculation, screening, or consistency checking does not become external Classical verification merely because it passed. A claim without non-empty evidence and an executed supporting rule trace must not be represented as FINAL or HIGH. Overall verification must be reconciled from the claim-level verification states and must not be stronger than them.

## LLM boundary
The external LLM receives the **AI Result JSON and its instruction only**. It does not read the HTML presentation layer and does not act on the raw `MasterResult` object as a second analytical interface.

The AI Result JSON is a semantic projection of `MasterResult`; it is not a competing source of truth. The LLM may interpret, explain, and synthesize source-owned results in natural, standard BaZi terminology. It may not recalculate BaZi, reconstruct missing evidence, adjudicate conflicts, promote candidates, invent confidence, or replace a source-owned determination.

Accordingly:

- `MasterResult` = **analytical authority**;
- `AI Result JSON` = **AI-facing representation/projection** of that authority;
- `AI Interpreter` = **interpretation and explanation layer**, not an analytical authority.

## Prohibited AI-facing vocabulary
The AI-facing payload must not expose implementation handles as semantic concepts, including:

- table IDs or binding IDs
- audit IDs
- internal source-record IDs
- engine object identifiers
- `semantic_records` / `canonical_nodes` legacy structures
- project-only abbreviations or internal rule codes

These may exist internally where required by the implementation, but they are not part of the LLM interpretation language.

## Maintenance
If the template classification changes, update this contract deliberately and rerun the field-by-field mapper audit. Do not modify Core A/B/C calculation logic merely to satisfy the AI projection layer.

## Determination Chain

The AI projection may include `determination_chain`. It is a semantic projection of the existing determination contract and follows:

Classical Rule → Rule Condition → Actual Chart Evidence → Condition Evaluation → Rule Result → Challenge / Counter-Evidence → Adjudication → Claim → Cross-Check → Confidence.

Internal rule IDs, evidence IDs, binding IDs, section coordinates, and source-record IDs are not part of the AI interpretation language. Classical source names are preserved semantically when provenance is available. The chain does not perform new BaZi calculation or determination.


## Claim Traceability and Authority

Each analytical claim is traceable through:

`claim → evidence → supporting rule → audit → cross-check → verification → synthesis → overall answer`

The determination chain is the single adjudication authority. Section B/C results supply the source state; a closure gate may preserve or weaken that state, but may never strengthen an open result into FINAL.

`evidence_records` must contain only non-empty evidence. `supported_by_rules` must contain at least one executed supporting rule for a claim to be eligible for closure. FINAL and HIGH are forbidden when either condition is missing.

Claim and evidence identifiers are provenance metadata only. They are not BaZi terminology and must not be exposed as interpretation language. URLs are provenance metadata and must not participate in terminology normalization.

Empty values, null placeholders, duplicate semantic entries, and internal engine names are omitted from the semantic AI projection.
