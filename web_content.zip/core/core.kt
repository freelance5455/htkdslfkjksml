fun main(){var hp=100;var s=0;while(hp>0){hp-=50;s++};var a=5;var p=2;while(p>0&&a<14){a++;p--};val n=minOf(30,90);println("shots=$s alive=$a mag=$n res=${90-n}")}
