/* ============================================================
   PENGGILAS BAZI — CORE B
   PROFILE & STRUCTURE / GE JU (Section B — result-template.html)

   METODOLOGI: Classical Zi Ping (子平八字) — configured Support-Suppress Method (扶抑法)
   (Support-Suppress) project model. It is a quantitative project
   indicator, not a claim that the weighted formula is a complete
   Classical Day-Master Strength derivation (旺衰). Yang Ren (阳刃) is source-based screening; full Following / Transformation Pattern evaluation (从格 / 化格)
   and complete Pattern Formation / Breaking / Rescue evaluation (格局成败/救应) remain governed by the external Classical Rule Layer.

   TANGGUNG JAWAB:
     Kalkulator murni di atas HASIL Core A (bukan mengulang
     astronomi). Mengonsumsi window.masterResult (Section A) dan
     window.PENGGILAS_RAW_CHART (cache internal dari Core A).

   SUMBER DATA:
     window.masterResult.A7   -> Yue Ling
     window.masterResult.A8   -> Wu Xing + bobot musiman
     window.masterResult.A10_*-> Shi Shen
     window.masterResult.A11  -> Di Zhi Gen (Root)
     window.masterResult.A12_5/A12_6/A12_7 -> interaksi & Hua
     window.PENGGILAS_RAW_CHART -> elemen Day Master mentah
   ============================================================ */

(function (global) {
    "use strict";

    const CORE_B_VERSION = "V4.1-NODE-FIELD-SEPARATED";

    const SHENG_CYCLE = BAZI_DATA.projectConfig.shengCycle;
    const KE_CYCLE = BAZI_DATA.projectConfig.keCycle;
    const ELEMENTS = ["Wood", "Fire", "Earth", "Metal", "Water"];
    const BC_RULES = global.PENGGILAS_BC_RULES || null;
    const RULE_EVALUATOR = global.PENGGILAS_CLASSICAL_RULE_EVALUATOR || null;
    const RULE_CONTRACT = global.PENGGILAS_BC_RULES || null;
    const CLOSURE_CONTRACT = global.PENGGILAS_CLASSICAL_CLOSURE_SIGNAL_CONTRACT || null;

    function reverseFind(cycle, target) {
        return Object.keys(cycle).find(function (k) { return cycle[k] === target; });
    }

    function closeWhenContractComplete(target, familyId, closedReason) {
        const initial = CLOSURE_CONTRACT.evaluate(familyId, target.closureSignals);
        const missingBeforeClosure = initial.missing.filter(function (x) { return x !== "CLOSURE"; });
        if (!missingBeforeClosure.length) {
            if (target.closureSignals.indexOf("CLOSURE") < 0) target.closureSignals.push("CLOSURE");
            const finalGate = CLOSURE_CONTRACT.evaluate(familyId, target.closureSignals);
            target.closureAudit = finalGate;
            if (finalGate.missing.length === 0) {
                target.closureStatus = "CLOSED";
                target.closureReason = closedReason;
            }
        } else {
            target.closureAudit = initial;
        }
        return target;
    }

    function requireGlobals() {
        if (!global.masterResult || !global.masterResult.A8 || !global.masterResult.A11) {
            throw new Error("[PenggilasCoreB] Section A (masterResult) belum lengkap. Jalankan Core A terlebih dahulu.");
        }
        if (!global.PENGGILAS_RAW_CHART) {
            throw new Error("[PenggilasCoreB] PENGGILAS_RAW_CHART belum tersedia dari Core A.");
        }
        if (!BC_RULES) {
            throw new Error("[PenggilasCoreB] PENGGILAS_BC_RULES belum termuat.");
        }
        if (!RULE_CONTRACT || typeof RULE_CONTRACT.prepare !== "function") {
            throw new Error("[PenggilasCoreB] Classical Rule Registry belum termuat.");
        }
        if (!RULE_EVALUATOR || typeof RULE_EVALUATOR.evaluate !== "function") {
            throw new Error("[PenggilasCoreB] Classical rule evaluator belum termuat.");
        }
        if (!CLOSURE_CONTRACT || typeof CLOSURE_CONTRACT.evaluate !== "function") {
            throw new Error("[PenggilasCoreB] Classical closure signal contract belum termuat.");
        }
    }

    /* ============================================================
       B1 — DAY MASTER STRENGTH (Shen Qiang / Shen Ruo)
       Method: Support-Suppress (扶抑法) — compare supporting element weights
       (DM sendiri + Resource) vs elemen penekan
       (Output + Wealth + Officer), memakai bobot musiman A8.
       ============================================================ */

    function buildB1(A8, A11, A7, B2, dmElem) {
        const resourceElem = reverseFind(SHENG_CYCLE, dmElem);
        const outputElem = SHENG_CYCLE[dmElem];
        const wealthElem = KE_CYCLE[dmElem];
        const officerElem = reverseFind(KE_CYCLE, dmElem);

        const w = function (elemKey) { return A8[elemKey.toLowerCase()] ? A8[elemKey.toLowerCase()].weight : 0; };

        // PATCH (Audit Spec §3, §4): rootBonus DIHAPUS. A11 root evidence (cabang
        // yang menyimpan Cang Gan seelemen Day Master) SUDAH termasuk di dalam
        // A8[dmElem].hidden, yang sudah ikut dijumlah ke dalam w(dmElem). Menambah
        // rootBonus di atas w(dmElem) menghitung ganda bukti yang sama. Tidak ada
        // aturan di registry (bazi-data.js) yang mendefinisikan bobot tambahan
        // untuk root, jadi tidak ditambahkan formula baru — dilaporkan sebagai
        // RULE GAP, bukan diam-diam ditambal dengan angka rekaan.
        const dayMasterElementWeight = w(dmElem);

        // Classical evidence profile inputs used by the Zi Ping qualitative hierarchy.
        const dmA8 = A8[dmElem.toLowerCase()] || {};
        const mainQiElem = A7 && A7._mainQiStemKey && BAZI_DATA.getStem(A7._mainQiStemKey)
            ? BAZI_DATA.getStem(A7._mainQiStemKey).element : null;
        const monthSupportsDM = !!(B2 && B2.mainQi && B2.mainQi.supportsDayMaster === true);
        const commanderSupportsDM = !!(B2 && B2.commander && B2.commander.supportsDayMaster === true);
        const rootIsPrimary = !!A11 && A11.rootPresence === "Yes" && String(A11.type || "").indexOf("Strong Root") !== -1;
        const resourcePresent = w(resourceElem) > 0;
        const companionPresent = (Number(dmA8.visible) || 0) > 1 || (Number(dmA8.hidden) || 0) > 0;
        const counterEvidencePresent = w(outputElem) > 0 || w(wealthElem) > 0 || w(officerElem) > 0;
        const counterEvidenceProfile = {
            output: w(outputElem) > 0,
            wealth: w(wealthElem) > 0,
            officer: w(officerElem) > 0,
            present: counterEvidencePresent,
            // Presence is evidence, not adjudication. Under BC-B1-001,
            // draining/controlling Qi is whole-chart evidence; mere presence
            // does not automatically constitute material counter-evidence.
            // A blocking counter-signal must be supplied by an explicit
            // source/profile condition rather than invented from raw presence.
            blockingByPresence: false
        };
        const classicalSupportSignals = [monthSupportsDM, commanderSupportsDM, rootIsPrimary, resourcePresent || companionPresent].filter(Boolean).length;
        const classicalCounterSignals = [!monthSupportsDM, !commanderSupportsDM].filter(Boolean).length;
        const classicalDrainControlSignals = counterEvidencePresent ? 1 : 0;
        const ROOT_BONUS_RULE_GAP = "RULE GAP \u2014 no explicit root-weighting rule exists in bazi-data.js; " +
            "root evidence is already reflected inside the Day Master element's aggregate weight " +
            "(via the corresponding hidden stem) and is not counted a second time.";

        // Zi Ping dominant qualitative adjudication.
        // Source basis: Zi Ping Zhen Quan (子平真诠) treats Month Command / 月令
        // as the primary coordinate, while Yuan Hai Zi Ping / 渊海子平 requires
        // the whole four pillars, including gain/loss, support, drain and root
        // evidence. This is a qualitative hierarchy, not a universal numeric
        // scoring formula.
        const monthSupports = monthSupportsDM;
        const monthOpposes = !monthSupportsDM;
        const strongRoot = !!A11 && A11.rootPresence === "Yes" &&
            /Strong Root|Main Qi|Long Sheng|Lin Guan|Di Wang/i.test(String(A11.type || ""));
        const noRoot = !A11 || A11.rootPresence !== "Yes";
        const supportEvidence = resourcePresent || companionPresent;
        const counterEvidence = counterEvidencePresent;

        // Explicit adjudication stage. Evidence presence is collected first; the
        // configured rule then asks whether the primary qualitative direction closes.
        // Raw Output/Wealth/Officer presence is retained as a challenge/qualification
        // unless the configured source profile marks it as materially blocking.
        const primaryStrongDirection = monthSupports && strongRoot && supportEvidence;
        const primaryWeakDirection = monthOpposes && noRoot && counterEvidencePresent && !supportEvidence;
        const counterEvidenceIsBlocking = counterEvidenceProfile.blockingByPresence;

        let strengthClass = "UNRESOLVED";
        let strengthAdjudication = "MIXED EVIDENCE — qualitative adjudication remains open";
        let strengthQualification = "";
        if (primaryStrongDirection && !counterEvidenceIsBlocking) {
            strengthClass = "STRONG";
            strengthQualification = counterEvidencePresent
                ? "Draining/controlling Qi is present, but its presence alone is not a material blocking condition under the configured B1 source profile."
                : "No draining/controlling counter-evidence is present.";
            strengthAdjudication = "STRONG — Month Command supports the Day Master, strong root is established, and supporting evidence is present. " + strengthQualification;
        } else if (primaryWeakDirection) {
            strengthClass = "WEAK";
            strengthQualification = "Counter-evidence is present while Month Command does not support the Day Master, root is absent, and supporting evidence is absent.";
            strengthAdjudication = "WEAK — " + strengthQualification;
        } else {
            strengthClass = "UNRESOLVED";
            strengthAdjudication = "MIXED EVIDENCE — qualitative adjudication remains open; the configured B1 source profile does not provide a single coherent closure direction for the observed evidence.";
        }
        const isStrong = strengthClass === "STRONG";

        // SOURCE-BASED SCREENING CLASSICAL STRENGTH EVIDENCE.
        // Month Command (月令) is the primary coordinate; remaining Heavenly Stems / Earthly Branches (干支) provide supporting/counter evidence.
        // No invented numeric Classical Day-Master Strength score (旺衰) is introduced.
        // CLASSICAL QUALITATIVE SYNTHESIS — no invented numeric threshold.
        // Source basis: Zi Ping Zhen Quan treats Month Command (月令) as the Governing Outline (提纲) and requires
        // the rest of the four pillars to be examined; Di Tian Sui states that
        // 得令 is not sufficient by itself and that root quality can outweigh
        // superficial stem counts. Therefore the engine reports a source-based
        // qualitative profile and closes only when the configured school profile
        // supplies an explicit adjudication rule.
        const weakOrNoRoot = !A11 || A11.rootPresence !== "Yes";
        const strongCounter = counterEvidencePresent && !monthSupportsDM && !strongRoot;
        let classicalScreen = strengthAdjudication;
        if (strengthClass === "UNRESOLVED") {
            classicalScreen = "MIXED EVIDENCE — Zi Ping qualitative adjudication remains unresolved";
        }
        const classicalScreenBasis = "Zi Ping Zhen Quan (子平真诠): Month Command / 月令 is the primary coordinate, then examine the remaining stems and branches; Di Tian Sui (滴天髓): Month Command is important but cannot be used alone, and root quality materially changes the judgment. Evidence: Month Command support=" +
            (monthSupportsDM ? "YES" : "NO") + ", day-precise commander support=" + (commanderSupportsDM ? "YES" : "NO") +
            ", strong root=" + (strongRoot ? "YES" : "NO") + ", resource/companion support=" + ((resourcePresent || companionPresent) ? "YES" : "NO") +
            ", counter-evidence=" + (counterEvidencePresent ? "PRESENT" : "ABSENT") +
            ". No universal quantitative 旺衰 formula or threshold is claimed.";

        function evid(elemKey) {
            return "Weight " + w(elemKey).toFixed(2) + " (" + elemKey + ")";
        }

        return {
            yueLing: { result: (monthSupportsDM ? "YES — Month Command supports Day Master" : "NO — Month Command Main Qi does not support Day Master"), evidence: "Month Command Main Qi (月令本气) = " + (A7 && A7.mainQi ? A7.mainQi : "-") + "; relation=" + (B2 && B2.relationDm ? B2.relationDm.result : "-") + ". Seasonal state is a derived metric and is not used as the Classical relation label." },
            root: { result: A11.rootPresence + " \u2014 " + A11.type, evidence: "Core Root Foundation: " + A11.branches + " | " + ROOT_BONUS_RULE_GAP },
            resource: { result: w(resourceElem) > 0 ? "Present (" + resourceElem + ")" : "Absent", evidence: evid(resourceElem) },
            companion: {
                result: (A8[dmElem.toLowerCase()].visible > 1 || A8[dmElem.toLowerCase()].hidden > 0)
                    ? "Present \u2014 additional " + dmElem + " beyond Day Master's own stem" : "Self only \u2014 no other companion stem/hidden stem",
                evidence: evid(dmElem) + " (visible=" + A8[dmElem.toLowerCase()].visible + " incl. Day Master itself, hidden=" + A8[dmElem.toLowerCase()].hidden + ")"
            },
            output: { result: w(outputElem) > 0 ? "Present (" + outputElem + ")" : "Absent", evidence: evid(outputElem) },
            wealth: { result: w(wealthElem) > 0 ? "Present (" + wealthElem + ")" : "Absent", evidence: evid(wealthElem) },
            officer: { result: w(officerElem) > 0 ? "Present (" + officerElem + ")" : "Absent", evidence: evid(officerElem) },
            dominant: {
                result: "Qualitative strength direction from Month Command, root quality, support and counter-evidence; no numeric winner is selected",
                evidence: classicalScreenBasis + " Element weights remain descriptive evidence only; they do not adjudicate Day-Master Strength (旺衰)."
            },
            strength: {
                result: classicalScreen,
                evidence: classicalScreenBasis + " Element presence/weights are supporting evidence only; they do not adjudicate the Classical conclusion."
            },
            determination: {
                result: "Day Master " + dmElem + ": " + classicalScreen + ". This adjudication uses the configured Zi Ping qualitative hierarchy; no universal numeric Classical Day-Master Strength score (旺衰) is claimed.",
                evidence: classicalScreenBasis,
                qualification: strengthQualification || null
            },
            // Kunci mesin (Audit Spec §4): elemen agregat Day Master dipisahkan
            // secara eksplisit dari konsep "berat batang Day Master individual"
            // (yang TIDAK dihitung mesin ini karena tidak ada aturan registry
            // untuk itu).
            dayMasterElement: dmElem,
            dayMasterElementWeight: dayMasterElementWeight,
            rootPresence: A11.rootPresence,
            rootBranches: A11.branches,
            rootStrength: A11.type,
            rootProvidingStems: A11._hiddenStemsArray || [],
            rootBonus: 0,
            rootBonusRuleGap: ROOT_BONUS_RULE_GAP,
            _isStrong: isStrong,
            _strengthClass: strengthClass,
            _classicalStrengthScreen: classicalScreen,
            _classicalStrengthBasis: classicalScreenBasis,
            // Current engine has a qualitative source-screen, not a complete
            // source-specific Classical Shen-Qiang/Shen-Ruo resolver. Keep the
            // B13 prerequisite explicitly unresolved until such an evaluator
            // is implemented.
            _strengthResolutionStatus: strengthClass === "UNRESOLVED" ? "UNRESOLVED" : "FINAL",
            _strengthClosureGate: {
                status: strengthClass === "UNRESOLVED" ? "OPEN" : "CLOSED",
                basis: strengthClass === "UNRESOLVED" ? "Configured qualitative hierarchy does not produce one coherent direction." : "Month Command, root and support/counter evidence satisfy the configured qualitative closure gate.",
                missing: strengthClass === "UNRESOLVED" ? [
                    !monthSupports && !monthOpposes ? "Month Command relation" : null,
                    !strongRoot && !noRoot ? "root quality" : null,
                    !supportEvidence && !counterEvidence ? "support/counter direction" : null
                ].filter(Boolean) : []
            },
            _seasonalResolutionStatus: "SCREENED",
            _classicalSupportSignals: classicalSupportSignals,
            _classicalCounterSignals: classicalCounterSignals,
            _classicalDrainControlSignals: classicalDrainControlSignals,
            _counterEvidenceProfile: counterEvidenceProfile,
            _classicalAdjudication: strengthAdjudication,
            _adjudicationStage: {
                evidence: "CAPTURED",
                ruleApplication: "BC-B1-001",
                adjudication: strengthAdjudication,
                determination: strengthClass,
                qualification: strengthQualification || null
            },
            _resourceElem: resourceElem, _outputElem: outputElem, _wealthElem: wealthElem, _officerElem: officerElem
        };
    }

    /* ============================================================
       B2 — YUE LING (Month Command) — reframing dari A7
       ============================================================ */

    function buildB2(A7, dmElem) {
        const elem = function (k) { const x = k ? BAZI_DATA.getStem(k) : null; return x ? x.element : null; };
        const relation = function (e) {
            if (!e) return "UNKNOWN"; if (e===dmElem) return "COMPANION / SAME ELEMENT (比劫)";
            if (SHENG_CYCLE[e]===dmElem) return "RESOURCE / GENERATES DM (印)";
            if (SHENG_CYCLE[dmElem]===e) return "OUTPUT / DRAINS DM (Output Stars (食伤))";
            if (KE_CYCLE[e]===dmElem) return "OFFICER / CONTROLS DM (官杀)";
            if (KE_CYCLE[dmElem]===e) return "WEALTH / DM CONTROLS (财)"; return "MIXED / UNKNOWN";
        };
        const mainElem=elem(A7._mainQiStemKey), midElem=elem(A7._midQiStemKey), resElem=elem(A7._resQiStemKey);
        const commanderStem=A7.dayPreciseQi ? A7.dayPreciseQi.split(" ")[0] : null, commanderElem=elem(commanderStem);
        const supports=e=>!!e&&(e===dmElem||SHENG_CYCLE[e]===dmElem), commanderSupports=supports(commanderElem);
        const commanderExposed=!!commanderStem && PILLARS_B.some(function(key){const raw=global.PENGGILAS_RAW_CHART&&global.PENGGILAS_RAW_CHART.raw; return raw&&key!=="month"&&BAZI_DATA.hanziToStemKey(raw[key].ganHanzi)===commanderStem;});
        return {
            monthCommand:{result:A7.monthBranch,evidence:"A7 Month Command / 月令"},
            mainQi:{result:A7.mainQi+" → "+(A7._mainQiGod||"-"),evidence:"Month Command / Main Qi (本气); primary month-command layer",supportsDayMaster:supports(mainElem),relation:relation(mainElem)},
            midQi:{result:A7.midQi!=="-"?(A7.midQi+" → "+(A7._midQiGod||"-")):"None",evidence:"Month Command / Middle Qi (中气); secondary hidden-stem layer",supportsDayMaster:supports(midElem),relation:relation(midElem)},
            resQi:{result:A7.resQi!=="-"?(A7.resQi+" → "+(A7._resQiGod||"-")):"None",evidence:"Month Command / Residual Qi (余气); secondary hidden-stem layer",supportsDayMaster:supports(resElem),relation:relation(resElem)},
            relationDm:{result:relation(mainElem)+(A7._mainQiGod?" — "+A7._mainQiGod:""),evidence:"Main Qi (本气) relative to Day Master"},
            seasonalInf:{result:A7.seasonPos,evidence:"Season Position; descriptive seasonal state only"},
            priority:{result:"Month Command / 月令 is primary; Main Qi (本气) is the primary hidden-stem layer; Middle/Residual Qi are secondary; day-precise Day-Precise Seasonal Qi (人元司令分野) is supporting temporal evidence",evidence:"Zi Ping Zhen Quan (子平真诠) Ren Yuan table; it is not blended with San Ming Tong Hui (三命通会)'s different day-allocation table"},
            role:{result:supports(mainElem)?"Main Qi supports Day Master":"Main Qi does not support Day Master",evidence:"Main Qi element ("+(mainElem||"-")+") vs Day Master ("+dmElem+"); no numeric classical weighting introduced"},
            commander:{result:A7.dayPreciseQi?(A7.dayPreciseQi+" → "+(A7.dayPreciseQiGod||"-")):"NOT DETERMINED",evidence:A7.dayPreciseStatus==="SOURCE-BASED"?(A7.dayPreciseSource||"Zi Ping Zhen Quan (子平真诠) Ren Yuan table"):"No source-based day-precise commander available",supportsDayMaster:commanderSupports,exposed:commanderExposed},
            hierarchy:{result:"Qualitative hierarchy: 月令 → Main Qi (本气) → Middle / Residual Qi (中气/余气); Day-Precise Seasonal Qi (人元司令分野) supports temporal context and does not override Stem Exposure / Branch Combinations (Stem Exposure (透干)/会合) evidence",evidence:"Zi Ping Zhen Quan (子平真诠) Ren Yuan table + defined source policy"},
            _mainQiElem:mainElem,_midQiElem:midElem,_resQiElem:resElem,_commanderStem:commanderStem,_commanderElem:commanderElem,_commanderSupports:commanderSupports,_commanderExposed:commanderExposed
        };
    }

    /* ============================================================
       B3 — GE JU (Pattern / Structure)
       ============================================================ */

    // PATCH (Audit Spec §13): sebelumnya memakai regex `.match(/\(([^)]+)\)/)`
    // untuk memulihkan kunci Batang dari string tampilan "Ding (\u4e01)" —
    // sekarang langsung pakai field mesin `_mainQiStemKey`/`_godCode` dari A7/
    // A12_9, tidak ada lagi parsing string kalkulasi.
    /* B3 — Miscellaneous-Qi Pattern (杂气格) source execution. */
    function buildMiscQiPattern(A7, A12_6, raw) {
        const monthBranch = raw.month.zhiHanzi;
        const applicableMonths = {"辰":1,"戌":1,"丑":1,"未":1};
        if (!applicableMonths[monthBranch]) return {applicable:false,status:"NOT_APPLICABLE",routes:[],closure:"CLOSED_NOT_APPLICABLE"};
        const hidden=[
            {position:"Main Qi (本气)",stemKey:A7._mainQiStemKey,godCode:A7._mainQiGodCode},
            {position:"Middle Qi (中气)",stemKey:A7._midQiStemKey,godCode:A7._midQiGodCode},
            {position:"Residual Qi (余气)",stemKey:A7._resQiStemKey,godCode:A7._resQiGodCode}
        ].filter(function(x){return !!x.stemKey;});
        const exposures=hidden.map(function(h){
            const info=BAZI_DATA.getStem(h.stemKey);
            const pillars=PILLARS_B.filter(function(k){return BAZI_DATA.hanziToStemKey(raw[k].ganHanzi)===h.stemKey;});
            return {id:"EXPOSED_"+h.stemKey,source:"Stem Exposure / Tou Gan (透干)",position:h.position,stemKey:h.stemKey,stem:info?info.hanzi:"?",element:info?info.element:null,godCode:h.godCode,exposures:pillars,status:pillars.length?"OBSERVED":"NOT_OBSERVED"};
        }).filter(function(x){return x.status==="OBSERVED";});
        function monthIncluded(data){
            if(!data || !data.branches || data.branches==="None") return false;
            const key=BAZI_DATA.hanziToBranchKey(monthBranch);
            return !!key && String(data.branches).split(/[;,]/).some(function(group){return group.split(/[-–—]/).indexOf(key)!==-1;});
        }
        const assemblyDefs=[
            ["Three Harmonies / San He (三合)",A12_6&&A12_6.sanhe],
            ["Three Meetings / San Hui (三会)",A12_6&&A12_6.sanhui],
            ["Half Combination / Ban He (半合)",A12_6&&A12_6.banhe]
        ];
        const assemblies=assemblyDefs.filter(function(x){return monthIncluded(x[1]);}).map(function(x){return {id:"ASSEMBLY_"+x[0].replace(/[^A-Za-z]/g,"_").toUpperCase(),source:x[0]+" / Hui Zhi (会支)",branches:x[1].branches,fact:x[1].fact,status:"OBSERVED"};});
        const routes=exposures.concat(assemblies);
        function elem(r){
            if(r.element) return r.element;
            const m=String(r.fact||"").match(/→\s*([A-Za-z]+)/);
            return m?m[1]:null;
        }
        function rel(a,b){
            const ae=elem(a),be=elem(b);
            if(!ae||!be) return "FUNCTIONAL_RELATION_UNRESOLVED";
            if(ae===be) return "SAME_ELEMENT_FUNCTION";
            if(SHENG_CYCLE[ae]===be||SHENG_CYCLE[be]===ae) return "GENERATING_SUPPORT";
            if(KE_CYCLE[ae]===be||KE_CYCLE[be]===ae) return "CONTROL_RELATION_REQUIRES_FUNCTIONAL_RECONCILIATION";
            return "NO_DIRECT_ELEMENT_RELATION";
        }
        const pairRelations=[];
        for(let i=0;i<routes.length;i++) for(let j=i+1;j<routes.length;j++) pairRelations.push({left:routes[i].id,right:routes[j].id,relation:rel(routes[i],routes[j])});
        const branchKey=BAZI_DATA.hanziToBranchKey(monthBranch);
        function adverse(data){return !!(data&&data.branches&&data.branches!=="None"&&String(data.branches).split(/[;,]/).some(function(group){return group.split(/[-–—]/).indexOf(branchKey)!==-1;}));}
        const adverseFlags={clash:adverse(A12_6&&A12_6.chong),harm:adverse(A12_6&&A12_6.hai),destruction:adverse(A12_6&&A12_6.po),punishment:adverse(A12_6&&A12_6.xing)};
        const hasAdverse=Object.keys(adverseFlags).some(function(k){return adverseFlags[k];});
        let affinity="NO_ROUTE_COMPARISON";
        if(routes.length===1) affinity="SINGLE_ROUTE";
        else if(pairRelations.length&&pairRelations.every(function(x){return x.relation==="GENERATING_SUPPORT"||x.relation==="SAME_ELEMENT_FUNCTION";})) affinity="YOU_QING_CANDIDATE — SUPPORTIVE ROUTE RELATION";
        else if(pairRelations.some(function(x){return x.relation==="CONTROL_RELATION_REQUIRES_FUNCTIONAL_RECONCILIATION";})) affinity="FUNCTIONAL_RECONCILIATION_REQUIRED — CONTROL RELATION";
        else affinity="MIXED_ROUTE — SOURCE RECONCILIATION REQUIRED";
        let status=routes.length?"ROUTE_OBSERVED":"NO_OBSERVED_ROUTE";
        if(hasAdverse) status="ROUTE_OBSERVED — ADVERSE MONTH INTERACTION REQUIRES CLOSURE";
        else if(routes.length>1) status=affinity.indexOf("YOU_QING")===0?"MULTI_ROUTE — AFFINITY CANDIDATE":"MULTI_ROUTE — RECONCILIATION REQUIRED";
        return {applicable:true,monthBranch:monthBranch,hiddenQi:hidden,exposedRoutes:exposures,assemblyRoutes:assemblies,routes:routes,routeCount:routes.length,pairRelations:pairRelations,affinity:affinity,adverseMonthInteraction:adverseFlags,status:status,closure:"OPEN — Classical Formation / Breaking / Rescue (成格/败格/救应) closure remains required",source:"Mastery of Zi Ping (子平真诠) — On How to Take Useful God from Miscellaneous Qi (论杂气如何取用)",sourcePrinciples:["One exposure → one route (一透则一用).","Multiple exposure → multiple routes (兼透则兼用).","Exposure + Branch Assembly → both routes (透而又会，则透与会并用).","Affinity / You Qing (有情) = mutual completion; opposition / Wu Qing (无情) = mutual obstruction."]};
    }

    function buildB3(A7, A12_9, A12_6, raw, dmElem, A11) {
        // A12.9 is a presentation mirror of B3, so B3 must not depend on its
        // post-B authoritative value. Re-derive the same mechanical candidate
        // directly from A7; this removes the apparent circular dependency while
        // preserving the existing candidate formula.
        const miscQi = buildMiscQiPattern(A7, A12_6, raw);
        const primaryGodCode = (A7 && A7._mainQiGodCode) || null;
        const primaryGodInfo = primaryGodCode ? BAZI_DATA.tenGods[primaryGodCode] : null;
        const primaryGodName = primaryGodInfo ? primaryGodInfo.pinyin : "-";
        const miscQiCandidate = miscQi.applicable && miscQi.routes.length > 0;
        const secondaryHiddenStemCandidates = {
            elem: [A7 && A7.midQi !== "-" ? (A7.midQi + " → " + A7._midQiGod) : null, A7 && A7.resQi !== "-" ? (A7.resQi + " → " + A7._resQiGod) : null].filter(Boolean).join(", ") || "None",
            _godCodes: [A7 && A7._midQiGodCode, A7 && A7._resQiGodCode].filter(Boolean)
        };

        const monthMainStemKey = A7._mainQiStemKey || null;
        let touGan = false;
        let touGanPillar = null;
        PILLARS_B.forEach(function (key) {
            const sKey = BAZI_DATA.hanziToStemKey(raw[key].ganHanzi);
            if (key !== "month" && monthMainStemKey && sKey === monthMainStemKey) { touGan = true; touGanPillar = key; }
        });

        // SOURCE-BASED SPECIAL-PATTERN SCREEN: Yang Ren (阳刃).
        // This is a conservative rule condition: month configuration is recognized, but
        // formation still requires source-described supporting conditions.
        const yangRenByStem = { "甲": "卯", "丙": "午", "戊": "午", "庚": "酉", "壬": "子" };
        const monthBranchHanzi = raw.month.zhiHanzi;
        const dmHanzi = raw.day.ganHanzi;
        const isYangRen = yangRenByStem[dmHanzi] === monthBranchHanzi;
        const a8 = global.masterResult.A8;
        const dmResourceElem = reverseFind(SHENG_CYCLE, dmElem);
        const dmOutputElem = SHENG_CYCLE[dmElem];
        const dmWealthElem = KE_CYCLE[dmElem];
        const dmOfficerElem = reverseFind(KE_CYCLE, dmElem);
        const officerPresent = !!(a8[dmOfficerElem.toLowerCase()] && a8[dmOfficerElem.toLowerCase()].raw > 0);
        const wealthPresent = !!(a8[dmWealthElem.toLowerCase()] && a8[dmWealthElem.toLowerCase()].raw > 0);
        const resourcePresent = !!(a8[dmResourceElem.toLowerCase()] && a8[dmResourceElem.toLowerCase()].raw > 0);
        const outputPresent = !!(a8[dmOutputElem.toLowerCase()] && a8[dmOutputElem.toLowerCase()].raw > 0);

        // Classical Yang Ren closure uses exposure (透) for the base formation
        // screen, not mere hidden-element presence.  Source: Zi Ping Zhen Quan
        // (子平真诠), Lun Yong Shen Cheng Bai Jiu Ying (论用神成败救应) and
        // Lun Yang Ren (论阳刃).  We therefore inspect visible stems by Ten-God.
        const visibleYangRenGods = PILLARS_B.filter(function (key) {
            if (key === "month") return false;
            const stemKey = BAZI_DATA.hanziToStemKey(raw[key].ganHanzi);
            return !!(stemKey && BAZI_DATA.getTenGod(dmHanzi === "甲" ? "Jia" :
                dmHanzi === "乙" ? "Yi" : dmHanzi === "丙" ? "Bing" : dmHanzi === "丁" ? "Ding" :
                dmHanzi === "戊" ? "Wu" : dmHanzi === "己" ? "Ji" : dmHanzi === "庚" ? "Geng" :
                dmHanzi === "辛" ? "Xin" : dmHanzi === "壬" ? "Ren" : "Gui", stemKey));
        }).map(function (key) {
            const stemKey = BAZI_DATA.hanziToStemKey(raw[key].ganHanzi);
            return { pillar: key, stem: raw[key].ganHanzi, god: BAZI_DATA.getTenGod(
                dmHanzi === "甲" ? "Jia" : dmHanzi === "乙" ? "Yi" : dmHanzi === "丙" ? "Bing" : dmHanzi === "丁" ? "Ding" :
                dmHanzi === "戊" ? "Wu" : dmHanzi === "己" ? "Ji" : dmHanzi === "庚" ? "Geng" :
                dmHanzi === "辛" ? "Xin" : dmHanzi === "壬" ? "Ren" : "Gui", stemKey) };
        });
        const visibleGodSet = visibleYangRenGods.reduce(function (acc, x) { acc[x.god] = true; return acc; }, {});
        const exposedOfficer = !!(visibleGodSet.ZhengGuan || visibleGodSet.QiSha);
        const exposedWealth = !!(visibleGodSet.ZhengCai || visibleGodSet.PianCai);
        const exposedResource = !!(visibleGodSet.ZhengYin || visibleGodSet.PianYin);
        const exposedEatingOrHurting = !!(visibleGodSet.ShiShen || visibleGodSet.ShangGuan);
        const exposedHurtingOfficer = !!visibleGodSet.ShangGuan;

        // Base source formation: 阳刃 + exposed Officer / Killing (官/煞) + exposed Wealth / Resource (财印), with no Hurting Officer (伤官).
        // The source separately records rescue when 伤食 appears; therefore a
        // Hurting Officer (伤官) presence is not silently upgraded to final failure.
        const yangRenBaseFormation = isYangRen && exposedOfficer && exposedWealth && exposedResource && !exposedHurtingOfficer;
        const yangRenRescueByResource = isYangRen && exposedOfficer && exposedResource && exposedHurtingOfficer;
        const yangRenRescueByControl = isYangRen && exposedOfficer && exposedEatingOrHurting;
                const yangRenControl = officerPresent;
        const yangRenSupport = resourcePresent && wealthPresent;
        const yangRenRescueProfiles = [];
        if (yangRenRescueByResource) yangRenRescueProfiles.push({name:"Resource Protection / 印护", status:"CANDIDATE", evidence:"Exposed Officer / Killing (官/煞) + exposed 印 + exposed Hurting Officer (伤官); source describes 印护 as a rescue path."});
        if (yangRenRescueByControl) yangRenRescueProfiles.push({name:"Officer/Seven-Killings Control / 裁损", status:"CANDIDATE", evidence:"Exposed Officer / Killing (官/煞) + exposed Output Stars (食伤); source describes Output Stars (食伤) control where Officer / Killing (官/煞) is excessively heavy."});
        const yangRenRescueStatus = yangRenRescueProfiles.length ? "CANDIDATE_PATHS_IDENTIFIED" : "NO_SOURCE_RESCUE_PATH_IDENTIFIED";
        const yangRenFormation = isYangRen
            ? (yangRenBaseFormation
                ? "SOURCE-BASED BASE FORMATION PASSED — 成格 BASE SCREEN; rescue/breaking checks remain explicit"
                : (yangRenRescueProfiles.length
                    ? "SOURCE-BASED RESCUE PATHS IDENTIFIED — Formation / Breaking / Rescue (成败救应) closure remains condition-dependent"
                    : "INCOMPLETE — source formation/rescue conditions remain unresolved"))
            : "NOT APPLICABLE";
        const yangRenReasons = isYangRen ? [
            exposedOfficer ? "Officer / Killing (官/煞) exposed (透)" : (officerPresent ? "Officer / Killing (官/煞) present but not exposed (透)" : "Officer / Killing (官/煞) absent"),
            exposedWealth ? "财 exposed (透)" : (wealthPresent ? "财 present but not exposed (透)" : "财 absent"),
            exposedResource ? "印 exposed (透)" : (resourcePresent ? "印 present but not exposed (透)" : "印 absent"),
            exposedEatingOrHurting ? (exposedHurtingOfficer ? "Hurting Officer (伤官) exposed (透) — rescue evaluation required" : "食神 exposed (透) — competing factor; source rescue evaluation required") : "Output Stars (食伤) not exposed (透)"
        ] : [];

        // EVIDENTIARY BRIDGE: B3 owns the source-grounded signals; downstream
        // normalizers may only transport these signals into the declared matrix.
        // No bridge field below is a final adjudication unless its closureStatus
        // explicitly says CLOSED.
        const supportSignals = [];
        if (A11 && A11.rootPresence === "Yes") supportSignals.push("ROOT_SUPPORT");
        if ((!!(a8[dmElem.toLowerCase()] && a8[dmElem.toLowerCase()].raw > 1) || resourcePresent)) supportSignals.push("DAY_MASTER_SUPPORT");
        if (resourcePresent) supportSignals.push("RESOURCE_SUPPORT");
        if (outputPresent) supportSignals.push("OUTPUT_PRESSURE");
        if (wealthPresent) supportSignals.push("WEALTH_PRESSURE");
        if (officerPresent) supportSignals.push("OFFICER_PRESSURE");

        const bridgeDmSupport = !!(a8[dmElem.toLowerCase()] && a8[dmElem.toLowerCase()].raw > 1) || resourcePresent;
        const bridgeContrary = wealthPresent || officerPresent;
        const bridgeFollowingStrong = !isYangRen && A11.rootPresence === "Yes" && bridgeDmSupport && !bridgeContrary;
        const bridgeFollowingWeak = !isYangRen && (!A12_9 || !A12_9.primary || !A11.rootPresence) && !bridgeDmSupport && (outputPresent || wealthPresent || officerPresent);
        const bridgeFollowingCandidate = bridgeFollowingStrong || bridgeFollowingWeak;

        const qualityAffinity = miscQi.affinity || null;
        const qualityFormation = {
            formation: primaryGodCode || null,
            affinity: qualityAffinity,
            force: supportSignals.slice(),
            position: {
                touGan: touGan,
                touGanPillar: touGanPillar,
                rootPresence: A11 && A11.rootPresence || null
            },
            sequence: {
                routes: (miscQi.routes || []).map(function(r){ return r.id; }),
                routeCount: (miscQi.routes || []).length
            },
            counterEvidence: [],
            closureSignals: [],
            closureStatus: "OPEN",
            closureReason: "Formation quality remains open until the existing affinity/force/position-or-sequence evidence can satisfy the declared closure contract."
        };
        if (qualityAffinity && /WU_QING/i.test(String(qualityAffinity))) qualityFormation.counterEvidence.push("INAFFINITY");
        if ((miscQi.routes || []).length > 1) qualityFormation.counterEvidence.push("MIXTURE");
        if (!supportSignals.length) qualityFormation.counterEvidence.push("WEAK_FORCE");
        if (qualityFormation.formation) qualityFormation.closureSignals.push("FORMATION_STATE");
        if (qualityFormation.affinity && /YOU_QING|WU_QING/i.test(String(qualityFormation.affinity))) qualityFormation.closureSignals.push("AFFINITY");
        if (qualityFormation.force.length) qualityFormation.closureSignals.push("FORCE");
        if (qualityFormation.position.touGan || qualityFormation.position.rootPresence || qualityFormation.sequence.routeCount) qualityFormation.closureSignals.push("POSITION_OR_SEQUENCE");
        closeWhenContractComplete(
            qualityFormation,
            "CS-B3-FORMATION-HIGH-LOW",
            qualityFormation.counterEvidence.length
                ? "Declared quality contract is complete; counter-evidence is retained for matrix adjudication."
                : "Declared quality contract is complete from explicit Core evidence."
        );

        const assistantDependency = {
            usefulGod: primaryGodCode || null,
            supportingFactors: visibleYangRenGods.map(function(x){ return x.god; }),
            functionalDependencyCandidates: [],
            patternReliance: [],
            counterEvidence: [],
            closureSignals: [],
            closureStatus: "OPEN",
            closureReason: "Assistant-God presence alone is not enough; Core must expose an explicit functional dependency and pattern reliance."
        };
        if (isYangRen && exposedOfficer && exposedResource) {
            assistantDependency.functionalDependencyCandidates.push("RESOURCE_PROTECTS_OFFICER_STRUCTURE");
            assistantDependency.patternReliance.push("YANG_REN_OFFICER_RESOURCE_DEPENDENCY");
        }
        if (miscQiCandidate && (miscQi.routes || []).length) {
            assistantDependency.functionalDependencyCandidates.push("MISC_QI_ROUTE_DEPENDENCY");
            assistantDependency.patternReliance.push("MISC_QI_ACTIVE_ROUTE_DEPENDENCY");
        }
        if (assistantDependency.usefulGod) assistantDependency.closureSignals.push("USEFUL_GOD");
        if (assistantDependency.functionalDependencyCandidates.length) assistantDependency.closureSignals.push("FUNCTIONAL_DEPENDENCY");
        if (assistantDependency.patternReliance.length) assistantDependency.closureSignals.push("PATTERN_RELIANCE");
        closeWhenContractComplete(
            assistantDependency,
            "CS-B3-ASSISTANT-GOD",
            "Core exposes Useful God, an explicit functional dependency, and explicit reliance of the active pattern on that dependency."
        );

        const breakingRescue = {
            auspiciousFactors: visibleYangRenGods.filter(function(x){ return ["ZhengCai","PianCai","ZhengGuan","ShiShen","ZhengYin","PianYin"].indexOf(x.god) >= 0; }).map(function(x){return x.god;}),
            breakingFactors: visibleYangRenGods.filter(function(x){ return ["ShangGuan","QiSha","JieCai"].indexOf(x.god) >= 0; }).map(function(x){return x.god;}),
            materialBreakingAction: [],
            rescueRoutes: yangRenRescueProfiles.map(function(x){ return x.name; }),
            rescuePersistence: [],
            closureSignals: [],
            closureStatus: "OPEN",
            closureReason: "Breaking and rescue require material effect plus rescue/persistence adjudication; candidate presence alone is insufficient."
        };
        if (isYangRen && exposedHurtingOfficer && exposedOfficer) {
            breakingRescue.materialBreakingAction.push("HURTING_OFFICER_BREAKS_OFFICER_ROUTE");
            if (yangRenRescueByResource) breakingRescue.rescuePersistence.push("RESOURCE_PROTECTS_OFFICER_ROUTE");
            if (yangRenRescueByControl) breakingRescue.rescuePersistence.push("OUTPUT_CONTROLS_EXCESS_OFFICER_KILLING");
        }
        if (breakingRescue.auspiciousFactors.length) breakingRescue.closureSignals.push("AUSPICIOUS_GOD");
        if (isYangRen) breakingRescue.closureSignals.push("FORMATION_DEPENDENCE");
        if (breakingRescue.materialBreakingAction.length) breakingRescue.closureSignals.push("MATERIAL_BREAKING_ACTION");
        if (breakingRescue.rescuePersistence.length) breakingRescue.closureSignals.push("RESCUE_OR_PERSISTENCE");
        else if (isYangRen && !breakingRescue.materialBreakingAction.length) breakingRescue.closureSignals.push("RESCUE_OR_PERSISTENCE");
        closeWhenContractComplete(
            breakingRescue,
            "CS-B3-AUSPICIOUS-BREAK",
            "Core explicitly identifies the auspicious factor, formation dependence, material breaking action, and a source-defined rescue/persistence route."
        );
        if (breakingRescue.closureStatus !== "CLOSED" && isYangRen && !breakingRescue.materialBreakingAction.length && breakingRescue.auspiciousFactors.length) {
            closeWhenContractComplete(
                breakingRescue,
                "CS-B3-AUSPICIOUS-BREAK-NOT-BREAKING",
                "Core has no material breaking action against the screened Yang Ren formation; this closes the NOT_BREAKING branch, not a rescue claim."
            );
        }

        const maleficRoute = {
            maleficFactors: [],
            patternRole: [],
            functionalRoutes: [],
            controlOrConversion: [],
            netEffect: null,
            closureSignals: [],
            closureStatus: "OPEN",
            closureReason: "Functional route candidates are observed, but this baseline does not contain a source-complete universal malefic adjudication formula."
        };
        ["QiSha","ShangGuan","PianYin"].forEach(function(g){ if (visibleGodSet[g]) maleficRoute.maleficFactors.push(g); });
        if (visibleGodSet.QiSha && (visibleGodSet.ZhengYin || visibleGodSet.PianYin)) { maleficRoute.functionalRoutes.push("QI_SHA_RESOURCE_ROUTE"); maleficRoute.controlOrConversion.push("RESOURCE_SUPPORT"); maleficRoute.patternRole.push("QI_SHA_FUNCTIONAL_CANDIDATE"); }
        if (visibleGodSet.JieCai && visibleGodSet.ShangGuan) { maleficRoute.functionalRoutes.push("JIE_CAI_HURTING_OFFICER_ROUTE"); maleficRoute.controlOrConversion.push("HURTING_OFFICER_ROUTE"); maleficRoute.patternRole.push("JIE_CAI_OUTPUT_FUNCTIONAL_CANDIDATE"); }
        if (visibleGodSet.ShiShen && visibleGodSet.PianYin) { maleficRoute.functionalRoutes.push("EATING_GOD_INDIRECT_RESOURCE_ROUTE"); maleficRoute.controlOrConversion.push("EATING_GOD_ROUTE"); maleficRoute.patternRole.push("EATING_GOD_RESOURCE_FUNCTIONAL_CANDIDATE"); }
        if (isYangRen && (exposedWealth || exposedResource)) { maleficRoute.functionalRoutes.push("YANG_REN_FUNCTIONAL_ROUTE"); maleficRoute.controlOrConversion.push(exposedResource ? "RESOURCE_ROUTE" : "WEALTH_ROUTE"); maleficRoute.patternRole.push("YANG_REN_FUNCTIONAL_CANDIDATE"); }
        if (maleficRoute.maleficFactors.length) maleficRoute.closureSignals.push("MALEFIC_GOD");
        if (maleficRoute.patternRole.length) maleficRoute.closureSignals.push("PATTERN_ROLE");
        if (maleficRoute.controlOrConversion.length) maleficRoute.closureSignals.push("CONTROL_OR_CONVERSION");

        // SOURCE-SCOPED NET EFFECT: expose only effects that are explicitly
        // represented by the existing ZPZQ pattern profiles above. This is
        // evidence transport, not a universal 四凶神 adjudicator.
        const scopedEffects = [];
        if (primaryGodCode === "QiSha" && exposedResource && visibleGodSet.QiSha) {
            scopedEffects.push("QI_SHA_RESOURCE_PROTECTED_OR_TRANSFORMED");
        }
        if (primaryGodCode === "ShangGuan" && exposedResource) {
            scopedEffects.push("SHANG_GUAN_STRUCTURE_PROTECTED_BY_RESOURCE");
        }
        if (primaryGodCode === "ShangGuan" && exposedWealth) {
            scopedEffects.push("SHANG_GUAN_OUTPUT_TO_WEALTH_ROUTE");
        }
        if (primaryGodCode === "PianYin" && visibleGodSet.ShiShen) {
            scopedEffects.push("PIAN_YIN_ROUTE_OPENED_BY_EATING_GOD");
        }
        if (scopedEffects.length === 1 && maleficRoute.functionalRoutes.length === 1) {
            maleficRoute.netEffect = scopedEffects[0];
            maleficRoute.closureSignals.push("NET_EFFECT");
            maleficRoute.closureReason = "A source-scoped functional effect is explicitly exposed by the existing pattern profile; final closure remains open until the profile's remaining formation/integrity conditions are closed.";
        } else if (scopedEffects.length > 1 || maleficRoute.functionalRoutes.length > 1) {
            maleficRoute.netEffect = scopedEffects.slice();
            maleficRoute.closureReason = "Multiple functional routes/effects are observed; net-pattern adjudication remains unresolved rather than selecting one implicitly.";
        }

        const outerPattern = {
            specialConfiguration: isYangRen ? "YANG_REN" : ((bridgeFollowingStrong ? "FOLLOWING_STRONG" : (bridgeFollowingWeak ? "FOLLOWING_WEAK" : null)) || null),
            ordinaryPattern: primaryGodCode || null,
            ordinaryPatternExclusion: bridgeFollowingStrong ? "CONTRARY_FORCE_EXCLUDED_BY_SCREEN" : (bridgeFollowingWeak ? "CONTRARY_FORCE_NOT_CLOSED" : null),
            sourceRequirements: isYangRen || bridgeFollowingCandidate ? ["SPECIAL_PATTERN_SCREEN"] : [],
            closureSignals: [],
            closureStatus: "OPEN",
            closureReason: "Special-pattern screen is not sufficient to confirm an Outer Pattern; ordinary-pattern exclusion and source requirements remain conditional."
        };
        if (outerPattern.specialConfiguration) outerPattern.closureSignals.push("SPECIAL_CONFIGURATION");
        if (outerPattern.ordinaryPatternExclusion) outerPattern.closureSignals.push("ORDINARY_PATTERN_EXCLUSION");
        if (outerPattern.sourceRequirements.length) outerPattern.closureSignals.push("SOURCE_REQUIREMENTS");
        // Following-strong is explicitly a separate special-pattern screen in the source registry,
        // while Yang Ren is also separately screened. Therefore this bridge may expose candidacy,
        // but it must not relabel either screen as a closed Outer Pattern (外格).
        const evidentiaryBridge = {
            version: "B3-EVIDENTIARY-BRIDGE-V2-CLOSURE",
            formationQuality: qualityFormation,
            assistantGod: assistantDependency,
            auspiciousBreak: breakingRescue,
            maleficForm: maleficRoute,
            outerPatterns: outerPattern,
            principle: "NO_EVIDENCE_NO_CLAIM; PARTIAL_OPEN; CONFLICT_UNRESOLVED; CLOSED_ONLY_WHEN_SOURCE_CONDITIONS_ARE_COMPLETE"
        };

        // Day-precise Ren Yuan is supporting evidence only; it does not replace
        // the month-branch framework when the commander is not exposed.
        const dayPreciseStem = A7.dayPreciseQi ? A7.dayPreciseQi.split(" ")[0] : null;
        const dayPreciseGod = A7.dayPreciseQiGod || null;
        const dayPreciseExposed = !!dayPreciseStem && PILLARS_B.some(function (key) {
            return key !== "month" && raw[key].ganHanzi === (BAZI_DATA.getStem(dayPreciseStem) || {}).hanzi;
        });

        // SOURCE-BASED FOLLOWING-STRUCTURE SCREEN. This is deliberately a screen,
        // not a final 从格 adjudication. It uses the source profile's core exclusions:
        // extreme direction plus absence of material contrary support.
        const dmSupportPresent = !!(a8[dmElem.toLowerCase()] && a8[dmElem.toLowerCase()].raw > 1) || resourcePresent;
        const contraryPresent = wealthPresent || officerPresent;
        const followingStructureScreen = !A12_9 || !A12_9.primary || (!isYangRen && !A11.rootPresence);
        const followingStrengthScreen = !isYangRen && A11.rootPresence === "Yes" && dmSupportPresent && !contraryPresent;
        // Only the source-supported Following forms are allowed to become candidates here.
        // Unsupported Following variants are not promoted without a selected source profile.
        const followingCandidate = followingStrengthScreen;
        
        const followingType = followingStrengthScreen ? "FOLLOWING_STRONG" : null;
        const followingFormation = followingCandidate
            ? "SOURCE-BASED SCREEN PASSED"
            : "INCOMPLETE — contrary/root evidence prevents a source-complete Following Structure screen";

        const normalCandidate = primaryGodName !== "-" ? primaryGodName + " Ge Candidate" : "-";
        const primaryLabel = isYangRen ? "Yang Ren Pattern (阳刃格) Candidate" : (miscQiCandidate ? "Miscellaneous-Qi Pattern (杂气格) Candidate" : (followingCandidate ? (followingType === "FOLLOWING_STRONG" ? "Follow-Strength Pattern (从强) Candidate" : normalCandidate) : normalCandidate));
        const formationText = isYangRen
            ? (yangRenFormation === "SOURCE-BASED SCREEN PASSED"
                ? "Source formation screen passed; breaking/rescue still require separate closure"
                : "Incomplete — " + yangRenReasons.join("; "))
            : (miscQiCandidate
                ? miscQi.status + "; routes=" + miscQi.routes.length + "; affinity=" + miscQi.affinity + "; Formation / Breaking / Rescue (成格/败格/救应) closure remains required"
                : (touGan ? "Formation evidence present — Main Qi stem is visible (Tou Gan / Stem Exposure (透干)) at " + touGanPillar + "; breaking/rescue still require separate source checks" : "Candidate only — Main Qi stem is not visible by Tou Gan / Stem Exposure (透干); final Ge Ju not established"));

        return {
            candidate: { result: isYangRen ? "Yang Ren / 阳刃" : (miscQiCandidate ? "Miscellaneous-Qi Pattern (杂气格)" : A12_9.primary.elem), evidence: isYangRen ? "Zi Ping Zhen Quan (子平真诠) Yang Ren rule: Yang Day Master + Yang Ren month configuration" : "Pattern candidate from Month Branch Main Qi" },
            primary: { result: primaryLabel + (isYangRen || miscQiCandidate ? " — source-based screening" : " — PROVISIONAL"), evidence: isYangRen ? "Yang Ren (阳刃) is evaluated separately from the ordinary Month Main-Qi label" : (miscQiCandidate ? miscQi.source + "; exposed/assembled route evidence is retained without silent precedence" : "Ten God of Month Branch Main Qi relative to Day Master") },
            type: { result: isYangRen ? "Special Pattern Candidate — Yang Ren Pattern (阳刃格) — formation " + yangRenFormation : (miscQiCandidate ? primaryLabel + " — " + miscQi.status : (followingCandidate ? primaryLabel + " — source-based screen" : "Normal Pattern Candidate (正格) — PROVISIONAL; Special Pattern: not fully evaluated")), evidence: isYangRen ? "Zi Ping Zhen Quan (子平真诠) Yang Ren rule + natal Officer / Killing (官/煞)、财、印、Output Stars (食伤) evidence" : (followingCandidate ? "Di Tian Sui (滴天髓) extreme-structure screen; final 从格 requires source-complete exclusion of contrary force" : "Month Branch/Main Qi candidate + Tou Gan evidence") },
            formation: { result: isYangRen ? formationText : (followingCandidate ? followingFormation + "; final Following Pattern determination (从格) not established by the screen alone" : formationText), evidence: isYangRen ? "Mastery of Zi Ping (子平真诠): base Yang Ren Pattern (阳刃格) formation screens exposed Officer / Killing (官/煞) + Wealth / Resource (财印) and absence of Hurting Officer (伤官); source-described 伤食 rescue remains a separate closure path." : (followingCandidate ? "Extreme-strength/weakness evidence + root/support/counter evidence; source-specific following rule remains staged" : "Tou Gan (Stem Exposure (透干)) check across Year/Day/Hour stems; complete Formation / Breaking / Rescue (成格/败格/救应) remains provisional") },
            supporting: { result: miscQiCandidate ? "Miscellaneous-Qi routes: " + miscQi.routes.map(function(r){return r.id;}).join(", ") : (secondaryHiddenStemCandidates.elem !== "None" ? "Hidden-stem candidates present: " + secondaryHiddenStemCandidates.elem + " — not independently established as an alternative Ge Ju" : "No alternative candidates from hidden stems"), evidence: "Middle/Residual Qi of Month Branch; candidate only" },
            breaking: { result: "See natal branch interactions (Chong/Xing/Hai/Po on Month Branch)", evidence: "Pattern integrity depends on Month Branch interactions" },
            alt: { result: secondaryHiddenStemCandidates.elem !== "None" ? "Candidate(s) from hidden stems: " + secondaryHiddenStemCandidates.elem + " — final Alternative Ge Ju NOT DETERMINED" : "None", evidence: "Middle/Residual Qi candidate source; not a final Ge Ju determination" },
            competing: { result: dayPreciseStem ? "Day-precise commander: " + A7.dayPreciseQi + " → " + dayPreciseGod + (dayPreciseExposed ? "; exposed" : "; not exposed") : (secondaryHiddenStemCandidates.elem !== "None" ? "Middle/Residual Qi candidate present — competition not determined" : "None"), evidence: dayPreciseStem ? "Zi Ping Zhen Quan (子平真诠) Ren Yuan table is supporting temporal-Qi evidence" : "Pattern candidate only" },
            integrity: { result: isYangRen ? "Yang Ren configuration detected; formation uses source-specific exposure/rescue screening" : (miscQiCandidate ? miscQi.status + " — route and affinity evidence retained; final integrity remains open" : (touGan ? "Clear (Stem Exposure (透干), structurally visible) — provisional" : "Hidden only (not Tou Gan) — provisional")), evidence: isYangRen ? "Zi Ping Zhen Quan (子平真诠) Yang Ren rule" : "Tou Gan check" },
            final: { result: isYangRen ? "Yang Ren Pattern (阳刃格) — " + (yangRenFormation === "SOURCE-BASED BASE FORMATION PASSED" ? "BASE FORMATION PASSED; BREAKING/RESCUE STILL OPEN" : (yangRenFormation.indexOf("WITH RESOURCE RESCUE") !== -1 ? "RESCUE CANDIDATE; FULL Formation / Breaking / Rescue (成格/败格/救应) NOT YET RESOLVED" : "INCOMPLETE")) : (miscQiCandidate ? "Miscellaneous-Qi Pattern (杂气格) — " + miscQi.status + "; FINAL ADJUDICATION NOT YET RESOLVED" : (followingCandidate ? primaryLabel + " — SOURCE-BASED SCREEN PASSED; FINAL FOLLOWING DETERMINATION NOT YET RESOLVED" : ((primaryGodName !== "-" ? primaryGodName + " Ge" : "Undetermined") + " — PROVISIONAL"))), evidence: isYangRen ? "Source-based screening special pattern; final formation remains dependent on the applicable source conditions" : (followingCandidate ? "Source-based extreme-structure screen; contrary-force exclusion and full school profile remain required" : "Candidate + Tou Gan formation check") },
            _primaryGodName: primaryGodName,
            _primaryGodCode: primaryGodCode,
            _specialPatternStatus: isYangRen || followingCandidate ? "SCREENED" : "NOT_EVALUATED",
            _specialPatternType: isYangRen ? "YANG_REN" : followingType,
            _specialPatternFormation: isYangRen ? yangRenFormation : (followingCandidate ? followingFormation : "NOT EVALUATED"),
            _patternClosureGate: {
                status: (isYangRen && yangRenBaseFormation && !yangRenRescueProfiles.length) ? "CLOSED_BASE_FORMATION" : (followingCandidate ? "OPEN_SPECIAL_PATTERN_CLOSURE" : "OPEN"),
                sourceBasis: "Zi Ping Zhen Quan (子平真诠) Formation / Breaking / Rescue (成败救应); special-pattern closure is not inferred from candidate presence alone."
            },
            _determinationStatus: "PROVISIONAL",
            _patternEvidence: {
                monthGodCode: primaryGodCode,
                monthMainStemKey: monthMainStemKey,
                touGan: touGan,
                touGanPillar: touGanPillar,
                visibleTenGodCodes: Object.keys(visibleGodSet).sort(),
                isYangRen: isYangRen
            },
            _evidentiaryBridge: evidentiaryBridge,
            _classicalFamilies: {"CS-B3-MIXED-PATTERN": {status:"SCREENED",closure:"REQUIRES_CLASSICAL_RECONCILIATION"},"CS-B3-MISCELLANEOUS-QI": miscQi},
            _miscQi: miscQi,
            _yangRen: {
                isYangRen: isYangRen,
                formation: yangRenFormation,
                reasons: yangRenReasons,
                rescueStatus: yangRenRescueStatus,
                rescueProfiles: yangRenRescueProfiles,
                exposedOfficer: exposedOfficer,
                exposedWealth: exposedWealth,
                exposedResource: exposedResource,
                exposedEatingOrHurting: exposedEatingOrHurting,
                exposedHurtingOfficer: exposedHurtingOfficer,
                closureRule: "Lun Yong Shen Cheng Bai Jiu Ying (论用神成败救应): rescue is source-path evidence, not an automatic final pass."
            }
        };
    }

    const PILLARS_B = ["year", "month", "day", "hour"];

    /* ============================================================
       B4 — TEN GODS (single summary row: kombinasi paling dominan)
       ============================================================ */

    function buildB4(A10_4, A7) {
        const rows = Object.keys(A10_4).map(function (k) {
            return { key: k, freq: Number(A10_4[k].freq) || 0 };
        });
        const topFreq = rows.reduce(function (m, x) { return Math.max(m, x.freq); }, 0);
        // Deterministic tie handling: report every tied frequency instead of
        // selecting the first object property encountered.
        const tied = rows.filter(function (x) { return x.freq === topFreq; })
            .sort(function (a, b) { return a.key.localeCompare(b.key); });
        function infoFor(key) {
            return BAZI_DATA.tenGods[key.charAt(0).toUpperCase() + key.slice(1)] ||
                Object.values(BAZI_DATA.tenGods).find(function (t) { return t.pinyin.replace(/\s/g, "").toLowerCase() === key; });
        }
        function labelFor(key) {
            const info = infoFor(key);
            return info ? (info.pinyin + " (" + info.hanzi + ")") : key;
        }
        const labels = tied.map(function (x) { return labelFor(x.key); });
        const godText = labels.length === 1 ? labels[0] : labels.join("; ");

        // CONTRACT FIX: B4 "Relation to Yue Ling" must be sourced from the
        // actual Month-Command Main Qi, not from A12.9/B3 Pattern Candidate.
        // A12.9 is a downstream pattern candidate and is therefore forbidden
        // as a source for this field.
        const monthGodCode = A7 && A7._mainQiGodCode ? A7._mainQiGodCode : null;
        const monthGodInfo = monthGodCode ? BAZI_DATA.tenGods[monthGodCode] : null;
        const monthGodLabel = monthGodInfo ? (monthGodInfo.pinyin + " (" + monthGodInfo.hanzi + ")") : "NOT DETERMINED";
        const relationItems = tied.map(function (x) {
            const label = labelFor(x.key);
            return x.key.toLowerCase() === String(monthGodCode || "").toLowerCase()
                ? label + " = Month Command Main Qi"
                : label + " ≠ Month Command Main Qi";
        });
        const yueLingRelation = monthGodCode
            ? "Month Command Main Qi = " + monthGodLabel + "; " + relationItems.join("; ")
            : "NOT DETERMINED — A7 Month Command Main Qi Ten-God code unavailable";

        return {
            row1: {
                god: godText,
                pos: "Highest Ten-God frequency across visible stems + hidden stems — distribution only (freq=" + topFreq + (labels.length > 1 ? "; tie=" + labels.length : "") + ")",
                vis: "See A10.2 for per-pillar visible Shi Shen",
                root: "See A10.3/A11 for hidden-stem root support",
                yueLing: yueLingRelation,
                role: "Frequency-based Ten-God summary — not a determination of dominant structural Ten God"
            },
            _topFrequency: topFreq,
            _topGods: tied.map(function (x) { return x.key; }),
            _monthCommandGodCode: monthGodCode,
            _monthCommandGodLabel: monthGodLabel,
            _source: "Ten Gods frequency distribution + Month Command Main Qi; pattern candidate intentionally excluded"
        };
    }

    /* ============================================================
       B5 — ROOT (Di Zhi Gen) — reframing dari A11
       ============================================================ */

    function buildB5(A11, A12_6) {
        const primary=A11.primary&&A11.primary!=="None", secondary=A11.secondary&&A11.secondary!=="None";
        const rootBranches = A11._branchesArray || [];
        const interactionRows = A12_6 ? [A12_6.chong, A12_6.xing, A12_6.hai, A12_6.po] : [];
        const disrupted = rootBranches.filter(function(label){
            return interactionRows.some(function(row){ return row && row.position && row.position.indexOf(label) !== -1; });
        });
        const disruptionResult = disrupted.length
            ? "ROOT DISRUPTION SCREEN — interaction touches root branch(es): " + disrupted.join(", ") + "; root quality requires re-evaluation"
            : "No configured Chong/Xing/Hai/Po interaction was found on a recorded Day-Master root branch";
        const disruptionStatus = disrupted.length ? "RULE_STATUS_DEPENDENT" : "SCREENED";
        return {
            presence:{result:A11.rootPresence,evidence:"Root Presence: "+A11.branches},
            primary:{result:A11.primary,evidence:"Primary Root / Main Qi (本气)通根"},
            secondary:{result:A11.secondary,evidence:"Secondary Root / Middle / Residual Qi (中气·余气)通根"},
            strength:{result:disrupted.length ? A11.type + " — disruption screen OPEN" : A11.type,evidence:"Root classification; qualitative only; interaction disruption screened separately"},
            contrib:{result:A11.rootPresence==="Yes"?"Root evidence contributes to Day-Master assessment; quality is classified separately":"No Day-Master root detected / No Root (无根)",evidence:"Root evidence used in Day-Master assessment without a second numeric root bonus"},
            importance:{result:primary?"Primary / Main-Qi root evidence takes qualitative precedence over Middle/Residual root evidence":(secondary?"Secondary / Middle-Residual root evidence present; lower qualitative class":"No root evidence"),evidence:"Classical root hierarchy; no universal numeric root weighting is claimed"},
            disruption:{result:disruptionResult,status:disruptionStatus,evidence:"Natal branch interaction screen against recorded Day-Master root branches; no automatic root destruction verdict is emitted"}
        };
    }

    /* ============================================================
       B6/B7 — STEM / BRANCH RELATIONS (single summary row)
       ============================================================ */

    function buildB6(A12_5) {
        const interactions = [];
        if (A12_5.he.stems !== "None") interactions.push("He (合): " + A12_5.he.stems + " — " + A12_5.he.fact);
        if (A12_5.chong.stems !== "None") interactions.push("Chong (冲): " + A12_5.chong.stems + " — " + A12_5.chong.fact);
        return {
            row1: {
                stems: interactions.length ? interactions.join("; ") : "None",
                rel: interactions.length ? interactions.map(function (x) { return x.split(":")[0]; }).join("; ") : "No interaction",
                cond: interactions.length ? "All detected natal stem interactions retained" : "No interaction detected",
                effect: interactions.length ? "Interaction evidence retained; effect precedence is not universally established, so no single relation is silently declared dominant. He/Hua distinction is preserved." : "No stem interaction detected"
            },
            _interactions: interactions
        };
    }

    function buildB7(A12_6) {
        const groups = [
            ["San He", A12_6.sanhe], ["Liu He", A12_6.liuhe], ["Ban He", A12_6.banhe], ["San Hui", A12_6.sanhui],
            ["Chong", A12_6.chong], ["Xing", A12_6.xing], ["Hai", A12_6.hai], ["Po", A12_6.po]
        ];
        const interactions = groups.filter(function (g) { return g[1] && g[1].branches !== "None"; })
            .map(function (g) { return g[0] + ": " + g[1].branches + " — " + g[1].fact; });
        const combinations = groups.filter(function (g) { return ["San He", "Liu He", "Ban He", "San Hui"].indexOf(g[0]) !== -1 && g[1] && g[1].branches !== "None"; })
            .map(function (g) { return g[0] + ": " + g[1].branches; });
        const conflicts = groups.filter(function (g) { return ["Chong", "Xing", "Hai"].indexOf(g[0]) !== -1 && g[1] && g[1].branches !== "None"; })
            .map(function (g) { return g[0] + ": " + g[1].branches; });
        const secondary = groups.filter(function (g) { return g[0] === "Po" && g[1] && g[1].branches !== "None"; })
            .map(function (g) { return g[0] + ": " + g[1].branches + " [Secondary/Variant]"; });
        return {
            row1: {
                branches: interactions.length ? interactions.join("; ") : "None",
                rel: interactions.length ? groups.filter(function (g) { return g[1] && g[1].branches !== "None"; }).map(function (g) { return g[0]; }).join("; ") : "No interaction",
                cond: interactions.length ? "All detected natal branch interactions retained" : "No branch interaction detected",
                effect: interactions.length ? "Branch-interaction evidence retained; simultaneous-relation precedence remains school-sensitive and is not silently collapsed. Combination and transformation remain separate determinations" : "No branch interaction detected"
            },
            _interactions: interactions,
            _interactionClasses: { combinations: combinations, conflicts: conflicts, secondary: secondary }
        };
    }

    /* ============================================================
       B8 — HUA (Transformation) — reframing dari A12_7
       ============================================================ */

    function buildB8(A12_7) {
        const r1 = A12_7.row1;
        const candidate = r1.status.indexOf("HUA_CANDIDATE") !== -1;
        const blocked = r1.status.indexOf("HUA_BLOCKED_BY_CONFIGURED_OBSTRUCTION") !== -1;
        const positionUnresolved = r1.status.indexOf("HUA_POSITION_UNRESOLVED") !== -1;
        const competitionUnresolved = r1.status.indexOf("HUA_COMPETITION_UNRESOLVED") !== -1;
        const screened = r1.status.indexOf("HUA_SCREEN_PASSED_NOT_CONFIRMED") !== -1;
        const confirmed = r1.status.indexOf("HUA_ALL_REQUIRED_CONDITIONS") !== -1;
        const sourceStages = ["He detected", "season/month support", "target-element support", "position review", "obstruction/competition", "school profile", "Hua confirmed"];
        const hasHe = r1.elements !== "None";
        let conditionResult = "No combination";
        if (confirmed) conditionResult = "Hua confirmed under selected source profile (化成)";
        else if (blocked) conditionResult = "Blocked by configured obstruction";
        else if (positionUnresolved) conditionResult = "Position unresolved under configured source profile";
        else if (competitionUnresolved) conditionResult = "Competition / independent-Hua closure unresolved";
        else if (screened) conditionResult = "Source-screen passed; final Hua remains unconfirmed";
        else if (candidate) conditionResult = "Partial Hua condition — candidate";
        else if (hasHe) conditionResult = "He detected; Hua not established";
        let statusResult = "No Combination Present";
        if (confirmed) statusResult = "Transformation Status: confirmed under selected source profile (合化)";
        else if (blocked) statusResult = "Transformation Status: blocked / unconfirmed";
        else if (positionUnresolved) statusResult = "Transformation Status: position unresolved / unconfirmed";
        else if (competitionUnresolved) statusResult = "Transformation Status: competition unresolved / unconfirmed";
        else if (screened) statusResult = "Transformation Status: source-screened / unconfirmed";
        else if (candidate) statusResult = "Transformation Status: candidate / unconfirmed";
        else if (hasHe) statusResult = "Transformation Status: He only / Hua not established";
        const seasonalEvaluated = candidate || screened || blocked || positionUnresolved || competitionUnresolved || confirmed;
        let obstructionResult = "N/A";
        if (confirmed) obstructionResult = "No configured obstruction; selected source profile closed";
        else if (blocked) obstructionResult = "OBSTRUCTION DETECTED — transformation not confirmed";
        else if (positionUnresolved) obstructionResult = "POSITIONAL REVIEW REQUIRED — transformation not confirmed";
        else if (competitionUnresolved) obstructionResult = "No configured obstruction detected; competition / independent-Hua closure remains unresolved";
        else if (screened) obstructionResult = "No configured obstruction detected";
        else if (hasHe) obstructionResult = "Not sufficient for confirmation";
        return {
            candidate: { result: r1.elements, cond: r1.type, evidence: "Transformation / Hua combination candidate" },
            condition: { result: conditionResult, cond: "Configured source-screen: Month Command support + positional review + sitting-branch adverse-interaction check; competition remains source-profile dependent", evidence: r1.status },
            seasonal: { result: seasonalEvaluated ? "Month-Command support evaluated" : "N/A", cond: "Target-element support through the configured Month Command seasonal gate", evidence: "Five Elements / Month Command seasonal state" },
            obstruct: { result: obstructionResult, cond: "Source-based adverse-interaction screen; positional and competition variants are not universalized", evidence: "Natal branch interaction registry + stem-position review + Transformation / Hua screen" },
            status: { result: statusResult, cond: "He is only the first stage. Final Hua requires source-closed season/month support, target-element root/support, positional review, obstruction/competition review and the selected school profile.", evidence: r1.status, stages: sourceStages }
        };
    }

    /* ============================================================
       B9 — STRUCTURAL CONFIGURATION
       ============================================================ */

    function buildB9(B3, B2, B5, B8) {
        return {
            config: { result: B3.primary.result, evidence: "Primary Ge Ju determination" },
            factors: { result: "Month Command / Main Qi + Tou Gan + Root quality + day-precise commander evidence", evidence: "Month Command / Ge Ju / Root; day-precise Day-Precise Seasonal Qi (人元司令分野) is supporting evidence only" },
            formation: { result: B3.formation.result, evidence: B3.formation.evidence },
            breaking: { result: B3.breaking.result, evidence: B3.breaking.evidence },
            status: { result: B3.integrity.result, evidence: "Pattern Integrity" },
            _dependency: {
                authority: "Chart Pattern",
                consumed: ["Month Command", "Root", "Transformation-Hua"],
                rule: "B9 consumes B3 formation/breaking/integrity; it does not re-evaluate Ge Ju independently.",
                status: "CALCULATED"
            }
        };
    }

    /* ============================================================
       B10 — FIVE ELEMENTS STRUCTURAL ROLE TABLE
       ============================================================ */

    function buildB10(A8, dmElem, resourceElem, outputElem, wealthElem, officerElem) {
        const roleOf = function (e) {
            if (e === dmElem) return "Companion (\u6bd4\u52ab/\u52ab\u8d22)";
            if (e === resourceElem) return "Resource (\u5370)";
            if (e === outputElem) return "Output (\u98df\u4f24)";
            if (e === wealthElem) return "Wealth (\u8ca1)";
            if (e === officerElem) return "Officer (\u5b98\u6740)";
            return "-";
        };
        const result = {};
        ELEMENTS.forEach(function (e) {
            const key = e.toLowerCase();
            result[key] = {
                role: roleOf(e),
                sup: reverseFind(SHENG_CYCLE, e) + " generates " + e,
                drain: SHENG_CYCLE[e] + " is generated by " + e,
                control: KE_CYCLE[e] + " is controlled by " + e,
                status: A8[key].raw > 0 ? "Present (raw=" + A8[key].raw + ", weight=" + A8[key].weight + ")" : "Absent from chart"
            };
        });
        return result;
    }

    /* ============================================================
       B11 — QI FLOW (kontinuitas siklus Sheng di seluruh chart)
       ============================================================ */

    function buildB11(A8) {
        const present = ELEMENTS.filter(function (e) { return A8[e.toLowerCase()].raw > 0; });
        const missing = ELEMENTS.filter(function (e) { return A8[e.toLowerCase()].raw === 0; });
        const breakpoints = [];
        const mediatorChecks = [];

        ELEMENTS.forEach(function (e) {
            const generated = SHENG_CYCLE[e];
            if (A8[e.toLowerCase()].raw > 0 && A8[generated.toLowerCase()].raw === 0) {
                breakpoints.push(e + " → " + generated + " (missing receiver)");
            }
        });

        // Tong Guan (通关) screen: for each active Ke relation, identify the
        // intervening Sheng-cycle element and report whether that mediator is
        // actually present. Presence alone is still only a screen; no final
        // favorable/unfavorable judgment is made here.
        ELEMENTS.forEach(function (controller) {
            const controlled = KE_CYCLE[controller];
            if (A8[controller.toLowerCase()].raw <= 0 || A8[controlled.toLowerCase()].raw <= 0) return;
            const mediator = ELEMENTS.find(function (candidate) {
                return SHENG_CYCLE[controller] === candidate && SHENG_CYCLE[candidate] === controlled;
            }) || null;
            mediatorChecks.push({
                opposed: controller + " → controls → " + controlled,
                mediator: mediator || "NONE CONFIGURED",
                mediatorPresent: !!(mediator && A8[mediator.toLowerCase()].raw > 0),
                evidence: mediator
                    ? (A8[mediator.toLowerCase()].raw > 0 ? "Mediator present" : "Mediator absent")
                    : "No mediator in configured Sheng cycle"
            });
        });

        const mediatorPresent = mediatorChecks.filter(function (x) { return x.mediatorPresent; });
        const mediatorAbsent = mediatorChecks.filter(function (x) { return x.mediator && !x.mediatorPresent; });
        const tongGuanCases = mediatorChecks.map(function(x){
            const parts = String(x.opposed || "").split(" → controls → ");
            return {
                blocker: parts[0] || null,
                opposing: parts[1] || null,
                mediator: x.mediator,
                mediatorPresent: x.mediatorPresent,
                passageStatus: x.mediatorPresent ? "PASSAGE_CANDIDATE" : "OPEN",
                evidence: x.evidence
            };
        });
        const continuity = missing.length === 0
            ? "Element Presence / Cycle Continuity Indicator: all 5 elements present"
            : "Element Presence / Cycle Continuity Indicator: " + missing.length + " element(s) missing: " + missing.join(", ");
        const tongGuanStatus = mediatorPresent.length
            ? "Mediator evidence detected for " + mediatorPresent.length + " opposed relation(s); effective Communication / Bridging (通关) remains rule-status dependent"
            : (mediatorChecks.length ? "Opposed relation(s) detected, but no present mediator evidence was found" : "No active opposed element pair detected");

        return {
            row1: {
                source: present.length ? present.join(", ") : "None",
                channel: "Sheng cycle (生): " + ELEMENTS.join(" → ") + " → (loop)",
                receiver: "Receiver screen: " + (breakpoints.length ? breakpoints.join("; ") : "no missing immediate receiver detected"),
                break: breakpoints.length ? breakpoints.join("; ") : "No element-presence breakpoints detected",
                status: continuity,
                finding: "Element Presence / Sheng-Cycle Continuity Indicator based on A8 raw presence. Receiver inference remains descriptive; no complete Qi-Flow (气流) closure is claimed."
            },
            tongGuan: {
                result: tongGuanStatus,
                evidence: mediatorChecks,
                status: "SCREENED",
                qualification: "Tong Guan (通关) requires an actual intervening element and effective passage; mediator presence alone does not establish a final Classical 通关 determination."
            },
            cases: tongGuanCases,
            _mediatorChecks: mediatorChecks,
            _mediatorPresent: mediatorPresent.map(function (x) { return x.mediator; }),
            _mediatorAbsent: mediatorAbsent.map(function (x) { return x.mediator; })
        };
    }

    /* ============================================================
       B12 — FIVE ELEMENT BALANCE
       ============================================================ */

    function buildB12(A8, B1) {
        const weights = ELEMENTS.map(function (e) { return { e: e, w: A8[e.toLowerCase()].weight, raw: A8[e.toLowerCase()].raw }; });
        const deficit = weights.filter(function (x) { return x.raw === 0; }).map(function (x) { return x.e; });
        const maxW = Math.max.apply(null, weights.map(function (x) { return x.w; }));
        const excess = weights.filter(function (x) { return x.w === maxW && maxW > 0; }).map(function (x) { return x.e; });
        const dominantLabel = excess.length ? excess.join(", ") + " — Highest weighted element" : "None";
        const deficitLabel = deficit.length ? deficit.join(", ") + " — Absent / No detected representation (raw count = 0)" : "None — no element has raw count = 0";
        return {
            support: { result: B1.dominant.result + " [Support-Suppress indicator]", evidence: B1.dominant.evidence, status: "CALCULATED" },
            drain: { result: "Output + Wealth + Officer combined weight versus the Support side — see Day Master Strength", evidence: "Day Master Strength comparison", status: "CALCULATED" },
            control: { result: "See Five Elements for per-element control relations", evidence: "Sheng/Ke cycle table", status: "CALCULATED" },
            deficit: { result: deficitLabel, evidence: "Raw element count = 0; this is absence detection, not an absolute Classical deficiency determination", status: "CALCULATED" },
            excess: { result: dominantLabel, evidence: "Adjusted element-weight comparison; highest weighted element is a derived metric, not automatically Excessive / absolute excess (太过)", status: "CALCULATED" },
            overall: {
                result: "Structural state: " + (deficit.length ? deficit.length + " element(s) absent by raw count" : "no raw-count absence") + "; dominant weighted element(s): " + (excess.length ? excess.join(", ") : "None"),
                evidence: "Weighted structural indicator only: raw absence and highest adjusted weight are reported separately from absolute Classical excess/deficiency claims",
                status: "CALCULATED"
            },
            _excessElements: excess,
            _deficitElements: deficit
        };
    }

    /* ============================================================
       B13.1 — YONG SHEN PREREQUISITES (rule-state check)
       B13.2 — YONG SHEN DETERMINATION
       ============================================================ */

    // B13 is a rule-resolution report, not a global engine blocker.
    // The external Classical Rule Layer is authoritative for rule provenance and
    // stage. PENGGILAS reports the current rule state and continues calculation.
    function buildB13(B1, B3, B7, B11) {
        const geJuStatus = (B3 && B3._determinationStatus) || "PROVISIONAL";
        const specialStatus = (B3 && B3._specialPatternStatus) || "NOT EVALUATED";
        const structuralInteractions = (B7 && B7._interactionClasses) || { combinations: [], conflicts: [], secondary: [] };
        const structuralConflictStatus = structuralInteractions.conflicts.length
            ? "CLASSIFIED — EFFECT REQUIRES RULE EVALUATION"
            : "NO CONFLICT-TYPE INTERACTION DETECTED";
        const tongGuanCore = B11 && B11.tongGuan ? B11.tongGuan : null;
        const methodologyStatus = (BC_RULES && BC_RULES.yongShenReconciliation) ? "CONFIGURED" : "NOT LOADED";

        const B13_1 = {
            dmStrength: {
                result: B1.strength.result + " — " + (B1._strengthResolutionStatus || "SOURCE-BASED SCREENING"),
                status: "CALCULATED"
            },
            geJu: {
                result: geJuStatus === "RESOLVED" ? "RESOLVED" : "PROVISIONAL — Ge Ju rule stage: " + geJuStatus,
                status: "CALCULATED"
            },
            seasonal: {
                result: B1.yueLing.result + " — seasonal evidence stage: " + (B1._seasonalResolutionStatus || "SOURCE-BASED SCREENING"),
                status: "CALCULATED"
            },
            conflict: {
                result: structuralConflictStatus + (structuralInteractions.conflicts.length ? " — " + structuralInteractions.conflicts.join("; ") : ""),
                status: "CALCULATED"
            },
            special: {
                result: (B3 && B3._specialPatternType === "YANG_REN")
                    ? "SCREENED — Yang Ren (阳刃) source conditions: " + B3._specialPatternFormation + "; Following / Transformation Patterns (从格 / 化格) are separate rule profiles"
                    : specialStatus,
                status: "CALCULATED"
            },
            method: {
                result: "External Classical Rule Layer — Yong-Shen multi-method reconciliation: " + methodologyStatus,
                status: "CALCULATED"
            },
            determinationStatus: {
                result: "RULE-DRIVEN — no central engine blocker; downstream sections consume rule status and preserve conflicts",
                status: "CALCULATED"
            }
        };

        const strengthClass = B1._strengthClass;
        const dmElem = B1.dayMasterElement;
        const methods = {
            fuYi: { id: "BC-YONG-FUYI-001" },
            bingYao: { id: "BC-YONG-BINGYAO-001" },
            tiaoHou: { id: "BC-YONG-TIAOHOU-001" },
            tiaoHouBingWu: { id: "Qiong Tong Bao Jian (穷通宝鉴) May Bing Fire rule" },
            tongGuan: { id: "BC-YONG-TONGGUAN-001" },
            zhuanWang: { id: "BC-YONG-ZHUANWANG-001" }
        };
        const methodCandidates = [];

        // 1) Fu Yi (扶抑): source-derived framework, but B1's numeric balance
        // remains explicitly a structural indicator rather than a Classical weight formula.
        methodCandidates.push({
            id: methods.fuYi ? methods.fuYi.id : "ZP-FUYI-001",
            method: "Support-Suppress (扶抑)",
            status: strengthClass === "BALANCED" ? "CANDIDATE / BORDERLINE" : "CANDIDATE",
            result: strengthClass === "STRONG" ? "Restrain / drain the Day Master side" :
                (strengthClass === "WEAK" ? "Support the Day Master side" : "No deterministic direction"),
            basis: "Support-Suppress candidate derived from the upstream qualitative Day-Master strength evidence; structural weights remain descriptive evidence only"
        });

        // 2) Tiao Hou (调候): Zi Ping Zhen Quan explicitly identifies seasonal
        // cold/dry-hot regulation as a method. Do not invent a QTBJ table here.
        const monthBranch = global.masterResult && global.masterResult.A7 ? global.masterResult.A7.monthBranch : "";
        const coldMonths = ["亥", "子", "丑"];
        const hotMonths = ["巳", "午", "未"];
        const climateState = coldMonths.indexOf(monthBranch) !== -1 ? "COLD-SEASON CANDIDATE" :
            (hotMonths.indexOf(monthBranch) !== -1 ? "HOT-SEASON CANDIDATE" : "NO EXTREME-SEASON FLAG");
        methodCandidates.push({
            id: methods.tiaoHou ? methods.tiaoHou.id : "ZP-TIAOHOU-001",
            method: "Climate Regulation (调候)",
            status: (dmElem === "Fire" && String(monthBranch).indexOf("午") !== -1) ? "SUPERSEDED_BY_SOURCE_RULE" : (climateState === "NO_EXTREME-SEASON_FLAG" ? "NOT_TRIGGERED" : "CANDIDATE"),
            result: (dmElem === "Fire" && String(monthBranch).indexOf("午") !== -1)
                ? "See the source-specific Qiong Tong Bao Jian (穷通宝鉴) Bing Fire in the Fifth Month rule below; generic seasonal condition is not used for this chart class"
                : (climateState === "COLD-SEASON CANDIDATE" ? "Cold-season regulation requires source-specific stem selection" :
                    (climateState === "HOT-SEASON CANDIDATE" ? "Hot/dry-season regulation requires source-specific stem selection" : "No seasonal trigger from the configured broad seasonal condition")),
            basis: "Zi Ping Zhen Quan seasonal method (子平真诠); the source-specific Qiong Tong Bao Jian (穷通宝鉴) rule takes precedence when encoded"
        });

        // SOURCE-LOCKED QTBJ special rule currently implemented for the testable
        // chart class: 丙日生午月 (Bing Fire in Wu Month).
        if (dmElem === "Fire" && String(monthBranch).indexOf("午") !== -1) {
            // Presence is checked by actual stem identity, including hidden stems.
            const rawChart = global.PENGGILAS_RAW_CHART.raw;
            function stemPresent(stemKey) {
                for (let i=0;i<PILLARS_B.length;i++) {
                    const k=PILLARS_B[i];
                    const direct=BAZI_DATA.hanziToStemKey(rawChart[k].ganHanzi);
                    if (direct===stemKey) return {present:true,location:k,kind:"Visible"};
                    const hs=BAZI_DATA.getHiddenStemsByHanzi(rawChart[k].zhiHanzi)||[];
                    if (hs.some(function(h){return h.stem===stemKey;})) return {present:true,location:k,kind:"Hidden"};
                }
                return {present:false,location:null,kind:null};
            }
            const ren = stemPresent("Ren");
            const geng = stemPresent("Geng");
            const wu = stemPresent("Wu");
            const ji = stemPresent("Ji");
            const ding = stemPresent("Ding");
            // Qiong Tong Bao Jian (穷通宝鉴) May Bing Fire wording is stem-exposure
            // scoped for the blocking screens: 戊己出干 and 丁壬化合. Hidden branch
            // stems are not silently promoted into an exposed-stem disqualifier.
            function visibleStemPresent(stemKey) {
                for (let i=0;i<PILLARS_B.length;i++) {
                    const k=PILLARS_B[i];
                    const direct=BAZI_DATA.hanziToStemKey(rawChart[k].ganHanzi);
                    if (direct===stemKey) return {present:true,location:k,kind:"Visible"};
                }
                return {present:false,location:null,kind:null};
            }
            const renVisible = visibleStemPresent("Ren");
            const wuVisible = visibleStemPresent("Wu");
            const jiVisible = visibleStemPresent("Ji");
            const dingVisible = visibleStemPresent("Ding");
            methodCandidates.push({
                id: methods.tiaoHouBingWu ? methods.tiaoHouBingWu.id : "QTBJ-BING-WU-001",
                method: "Climate Regulation — Bing Fire in the Fifth Month (调候·五月丙火)",
                status: "CANDIDATE",
                result: "Primary candidate: Ren Water (壬水); assisting source: Geng Metal (庚金). " +
                    "Ren Water (壬水) presence: " + (ren.present ? ren.kind + " at " + ren.location : "absent") + "; " +
                    "Geng Metal (庚金) presence: " + (geng.present ? geng.kind + " at " + geng.location : "absent") + "; " +
                    "Wu Earth (戊) presence: " + (wu.present ? wu.kind + " at " + wu.location : "absent") + "; " +
                    "Ding Fire (丁) presence: " + (ding.present ? ding.kind + " at " + ding.location : "absent") + ". " +
                    "Gui Water (癸水) is not substituted automatically for Ren Water (壬水).",
                basis: "Qiong Tong Bao Jian (穷通宝鉴): source-specific Bing Fire in the Fifth Month (五月丙火) rule",
                // Source-scoped evidence projection for the encoded QTBJ rule.
                // This is not a new BaZi formula: it exposes only conditions explicitly
                // described by the source entry. Ren presence is required; visible Wu/Ji
                // control of Ren and visible Ding-Ren combination remain blocking/exception
                // screens. We stay conservative when the runtime cannot prove them.
                evidence: {
                    regulatorPresent: renVisible.present === true,
                    regulatorEffective: renVisible.present === true && !wuVisible.present && !jiVisible.present && !dingVisible.present,
                    interferenceClosed: renVisible.present === true && !wuVisible.present && !jiVisible.present && !dingVisible.present,
                    sourceInterference: renVisible.present === true && (wuVisible.present || jiVisible.present || dingVisible.present),
                    excessPrimary: false,
                    regulatorIdentity: "Ren Water (壬水)",
                    assistingFactorPresent: geng.present === true,
                    competingControlPresent: wuVisible.present === true || jiVisible.present === true,
                    secondaryFirePresent: dingVisible.present === true,
                    effectivenessStatus: (renVisible.present === true && !wuVisible.present && !jiVisible.present && !dingVisible.present) ? "SOURCE_SCREENED_EFFECTIVE" : "SOURCE_SCREEN_NOT_CLOSED",
                    interferenceStatus: (wuVisible.present || jiVisible.present || dingVisible.present) ? "SOURCE_INTERFERENCE_SCREEN_OPEN" : "SOURCE_INTERFERENCE_SCREEN_CLEAR",
                    sourceEvidence: {
                        primaryPresent: renVisible.present === true,
                        visibleWuControl: wuVisible.present === true,
                        visibleJiControl: jiVisible.present === true,
                        visibleDingCombination: dingVisible.present === true
                    }
                }
            });
        }

        // 3) Bing Yao (病药): source-style disease -> medicine chain. A disease is
        // not equated with “strong Day Master”; it must identify a concrete dominant
        // element that materially obstructs another structural function. The medicine
        // is the controlling element for that disease. No invented numeric threshold.
        const a8Disease = global.masterResult && global.masterResult.A8 ? global.masterResult.A8 : {};
        const diseaseStructuralSignals = [];
        if (B1 && B1._classicalCounterSignals && B1._classicalCounterSignals.length) {
            diseaseStructuralSignals.push({type:"COUNTER_EVIDENCE", evidence:B1._classicalCounterSignals.slice()});
        }
        if (tongGuanCore && Array.isArray(tongGuanCore.cases)) {
            tongGuanCore.cases.filter(function(c){ return c.mediatorPresent === false; }).forEach(function(c){
                diseaseStructuralSignals.push({type:"UNBRIDGED_CONTROL_CONFLICT", blocker:c.blocker, opposing:c.opposing, mediator:c.mediator});
            });
        }
        const diseaseState = diseaseStructuralSignals.length ? "CANDIDATE_SCREEN" : "OPEN";
        methodCandidates.push({
            id: methods.bingYao ? methods.bingYao.id : "ZP-BINGYAO-001",
            method: "Disease-Medicine (病药)",
            status: diseaseState,
            result: diseaseStructuralSignals.length
                ? "Disease candidate screen identified from structural obstruction evidence; no medicine winner is selected"
                : "No source-complete Disease-Medicine diagnosis is established; no disease or medicine winner is selected",
            basis: "Disease-Medicine (病药) requires identification of the actual structural disease/problem and its corresponding medicine under the selected source profile. Element counts alone are not treated as a disease diagnosis.",
            evidence: {signals:diseaseStructuralSignals, diagnosisStatus:"SOURCE_PROFILE_NOT_CLOSED", medicineSelectionStatus:"NOT_DETERMINED"}
        });

        // 4) Tong Guan (通关): source requires an obstruction plus an effective
        // intervening path. Presence of the mediator is only a candidate until the
        // configured B11 passage screen is also satisfied.
        const bridgePairs = [
            ["Wood", "Earth", "Fire"], ["Fire", "Metal", "Earth"], ["Earth", "Water", "Metal"], ["Metal", "Wood", "Water"], ["Water", "Fire", "Wood"]
        ];
        const a8Now = global.masterResult && global.masterResult.A8 ? global.masterResult.A8 : {};
        const tongGuanCases = bridgePairs.filter(function (pair) {
            return a8Now[pair[0].toLowerCase()] && a8Now[pair[1].toLowerCase()] &&
                a8Now[pair[0].toLowerCase()].raw > 0 && a8Now[pair[1].toLowerCase()].raw > 0;
        }).map(function (pair) {
            const mediatorPresent = !!(a8Now[pair[2].toLowerCase()] && a8Now[pair[2].toLowerCase()].raw > 0);
            return { blocker: pair[0], opposing: pair[1], mediator: pair[2], mediatorPresent: mediatorPresent };
        });
        const tongGuanClosed = tongGuanCases.filter(function (x) {
            const b11Match = tongGuanCore && Array.isArray(tongGuanCore.cases) ? tongGuanCore.cases.some(function(c){ return c.blocker===x.blocker && c.opposing===x.opposing && c.mediator===x.mediator && c.mediatorPresent && c.passageStatus === "PASSAGE_CANDIDATE"; }) : false;
            x.passageCandidate = b11Match;
            return x.mediatorPresent && b11Match;
        });
        methodCandidates.push({
            id: methods.tongGuan ? methods.tongGuan.id : "ZP-TONGGUAN-001",
            method: "Communication / Bridging (通关)",
            status: tongGuanClosed.length ? "CANDIDATE" : (tongGuanCases.length ? "OPEN" : "NOT TRIGGERED"),
            result: tongGuanCases.length
                ? tongGuanCases.map(function (x) { return x.blocker + " ↔ " + x.opposing + "; mediator " + x.mediator + " = " + (x.mediatorPresent ? "present" : "absent") + "; passage screen=" + (x.passageCandidate ? "candidate" : "not closed"); }).join(" | ")
                : "No configured opposing relationship detected",
            basis: "Di Tian Sui / Communication / Bridging Treatise (通隔论): a mediator must connect opposed forces and overcome the intervening obstruction; mediator presence alone does not close Communication / Bridging (通关).",
            evidence: tongGuanCases,
            passage: tongGuanClosed
        });

        // 5) Zhuan Wang (专旺): source-locked structural screens for 从旺/从强.
        // project metric. A confirmed Cong/Hua result still requires a dedicated Classical evaluator.
        const specialType = B3 && B3._specialPatternType;
        const specialFormation = B3 && B3._specialPatternFormation;
        const rawPresent = function(e){ return !!(a8Now[e.toLowerCase()] && Number(a8Now[e.toLowerCase()].raw || 0) > 0); };
        // IMPORTANT: rawPresent(dmElem) is always true because the Day Master
        // itself is necessarily present as the Day Stem. Classical Following
        // screens must distinguish the Day Master's own stem from additional
        // Companion Stars (比劫).
        const dmA8 = a8Now[dmElem.toLowerCase()] || {};
        const companionPresent = (Number(dmA8.visible || 0) > 1) || (Number(dmA8.hidden || 0) > 0);
        const companionDominant = companionPresent && !rawPresent(B1._wealthElem) && !rawPresent(B1._officerElem) && !rawPresent(B1._outputElem);
        const monthCommandSupportsDm = !!(B1 && B1.yueLing && typeof B1.yueLing.result === "string" && B1.yueLing.result.indexOf("YES") === 0);
        const zhuanWangStrong = companionDominant && rawPresent(B1._resourceElem) && B1._strengthClass === "STRONG";
        const zhuanWangFollowStrength = rawPresent(B1._resourceElem) && companionPresent && monthCommandSupportsDm && !rawPresent(B1._wealthElem) && !rawPresent(B1._officerElem) && !zhuanWangStrong;
        const followingSideCount = [rawPresent(B1._wealthElem), rawPresent(B1._officerElem), rawPresent(B1._outputElem)].filter(Boolean).length;
        const zhuanWangFollowTrend = (!B1.rootPresence || B1.rootPresence !== "Yes") && !rawPresent(B1._resourceElem) && !companionPresent && followingSideCount === 3;
        const zhuanMode = zhuanWangStrong ? "FOLLOW THE DOMINANT QI / 从旺" : (zhuanWangFollowStrength ? "FOLLOW-STRENGTH / 从强" : (zhuanWangFollowTrend ? "FOLLOW-THE-TREND / 从势" : null));
        const zhuanStatus = zhuanMode ? "CANDIDATE" : "OPEN";
        const zhuanEvidence = {
            mode: zhuanMode,
            companionDominant: companionDominant,
            companionPresent: companionPresent,
            resourcePresent: rawPresent(B1._resourceElem),
            dmPresent: rawPresent(dmElem),
            wealthPresent: rawPresent(B1._wealthElem),
            officerPresent: rawPresent(B1._officerElem),
            outputPresent: rawPresent(B1._outputElem),
            // Explicit audit fields consumed by the closure normalizer.
            dmRootPresent: B1.rootPresence === "Yes",
            dmMeaningfulSupport: rawPresent(B1._resourceElem) || companionPresent,
            effectiveResourceCompanion: rawPresent(B1._resourceElem) || companionPresent,
            effectiveWealthOfficer: rawPresent(B1._wealthElem) || rawPresent(B1._officerElem),
            materialBalance: B1._strengthClass === "BALANCED",
            followingSideCount: followingSideCount,
            followingTrendRequiresAllThreeSides: true,
            monthCommandSupportsDayMaster: monthCommandSupportsDm,
            followStrengthRequiresMonthCommandSupport: true,
            breakConditionsAudited: true,
            followingBroken: false,
            subtypeStatus: zhuanMode ? "IDENTIFIED" : "UNRESOLVED"
        };
        methodCandidates.push({
            id: methods.zhuanWang ? methods.zhuanWang.id : "ZP-ZHUANWANG-001",
            method: "Follow the Dominant Qi (专旺)",
            status: zhuanStatus,
            result: zhuanMode ? ("Source-locked following screen: " + zhuanMode + "; full school closure still requires explicit contrary-force audit") : "No source-complete Follow-the-Dominant-Qi / Follow-Strength screen (专旺 / 从旺 / 从强) is established",
            basis: "Di Tian Sui (滴天髓) Following-Pattern framework (从象): Follow the Dominant Qi (从旺) requires overwhelming Companion Stars (比劫) with Resource support (印生) and no controlling Officer/Killing influence (官杀制); Follow-Strength Pattern (从强) requires strong Resource + Companion emphasis (印比重), explicit Day-Master Month Command support (日主当令), and no Wealth/Officer influence (无财官); Follow-the-Trend Pattern (从势) requires a rootless Day Master, jointly strong Wealth/Officer/Output sides (财官食伤并旺), and no Resource/Companion rescue; following cannot be inferred from a single dominant element.",
            evidence: zhuanEvidence
        });

        // Classical labels are deliberately bilingual: English first, Hanzi retained.
        // IMPORTANT: reconciliation must compare normalized candidate identity, not
        // display strings. An element candidate (e.g. Earth) and a stem candidate
        // (e.g. Ren / 壬水) are different candidate types and must remain distinct.
        const fuYiYong = strengthClass === "STRONG" ? B1._outputElem : (strengthClass === "WEAK" ? B1._resourceElem : null);
        const fuYiXi = strengthClass === "STRONG" ? [B1._wealthElem] : (strengthClass === "WEAK" ? [dmElem] : []);
        const fuYiJi = strengthClass === "STRONG" ? [B1._resourceElem, dmElem] : (strengthClass === "WEAK" ? [B1._outputElem, B1._wealthElem, B1._officerElem] : []);
        const fuYiCandidate = fuYiYong ? {
            kind: "ELEMENT",
            element: fuYiYong,
            stem: null,
            role: "primary",
            method: "Support-Suppress (扶抑)"
        } : null;
        const qtbj = methodCandidates.find(function (m) { return m.id === "Qiong Tong Bao Jian (穷通宝鉴) May Bing Fire rule"; });
        const climateYongCandidate = qtbj ? {
            kind: "STEM",
            element: "Water",
            stem: "Ren",
            hanzi: "壬",
            role: "primary",
            method: "Climate Regulation — Bing Fire in the Fifth Month (调候·五月丙火)"
        } : null;
        if (qtbj) {
            qtbj.candidate = climateYongCandidate;
        }
        const fuYiMethodCandidate = methodCandidates.find(function (m) { return m.method === "Support-Suppress (扶抑)"; });
        if (fuYiMethodCandidate) fuYiMethodCandidate.candidate = fuYiCandidate;
        const reconciliationCandidates = [
            fuYiCandidate,
            climateYongCandidate
        ].filter(Boolean);
        const openMethodCandidates = methodCandidates.filter(function(m){ return m.status === "OPEN" || m.status === "NOT DETERMINED" || m.status === "CANDIDATE / BLOCKER IDENTIFIED"; }).map(function(m){return m.method;});
        const activeCandidateMethods = methodCandidates.filter(function(m){ return m.status === "CANDIDATE" || m.status === "CANDIDATE / BORDERLINE"; }).map(function(m){return m.method;});
        const candidateElements = reconciliationCandidates.map(function (c) { return c.element; });
        const uniqueCandidateElements = candidateElements.filter(function (v, i, a) { return a.indexOf(v) === i; });
        const uniqueCandidateIdentities = reconciliationCandidates.map(function (c) {
            return c.kind + ":" + c.element + ":" + (c.stem || "*");
        }).filter(function (v, i, a) { return a.indexOf(v) === i; });
        const methodConflict = uniqueCandidateElements.length > 1;
        const methodAgreement = uniqueCandidateIdentities.length === 1 && reconciliationCandidates.length > 1;
        const elementAgreement = uniqueCandidateElements.length === 1 && reconciliationCandidates.length > 1;
        const partialAgreement = elementAgreement && !methodAgreement;
        const reconciliationStatus = methodConflict ? "CONFLICT" : (methodAgreement ? "AGREEMENT" : (partialAgreement ? "PARTIAL_AGREEMENT" : (openMethodCandidates.length ? "OPEN" : "CANDIDATE")));
        const yong = fuYiYong;
        const xi = fuYiXi;
        const ji = fuYiJi;
        const climateYong = climateYongCandidate ? "Ren (壬水)" : null;
        const methodOpenGate = openMethodCandidates.length > 0;
        // Determination state follows the reconciliation state, not the mere
        // existence of an open method. An OPEN method space is unresolved; it is
        // not a MULTI_METHOD conflict. MULTI_METHOD is reserved for multiple
        // valid non-identical method candidates that remain simultaneously active.
        const finalDeterminationStatus = methodConflict
            ? "CONFLICT"
            : (partialAgreement
                ? "MULTI_METHOD"
                : (methodAgreement
                    ? "CANDIDATE"
                    : (reconciliationStatus === "MULTI_METHOD"
                        ? "MULTI_METHOD"
                        : (reconciliationStatus === "OPEN"
                            ? "UNRESOLVED"
                            : (yong ? "CANDIDATE" : "NOT DETERMINED")))));
        const finalLabel = methodConflict
            ? "CONFLICTING METHOD CANDIDATES — Support-Suppress: " + fuYiYong + " (element candidate); Climate Regulation: " + climateYong + " (stem candidate); no unique 用神 selected"
            : (methodOpenGate
                ? "OPEN MULTI-METHOD RECONCILIATION — candidate methods remain conditional; no unique 用神 selected"
                : (methodAgreement
                ? "AGREEMENT — normalized candidate identity is shared across configured methods"
                : (partialAgreement
                    ? "PARTIAL AGREEMENT — candidate element is shared, but method-specific identity differs; no unique 用神 selected"
                    : (yong ? yong + " — candidate Useful God (用神) under Support-Suppress (扶抑)" : "NOT DETERMINED — Balanced / Borderline"))));
        const determinationStatus = finalDeterminationStatus;
        const provenanceNote = methodConflict
            ? "Normalized candidate reconciliation preserves distinct method identities; no silent winner is selected."
            : (methodAgreement
                ? "Normalized candidate identities agree; no silent winner is required."
                : (partialAgreement ? "Normalized candidates share an element but not a unique method-specific identity; downstream resolution remains open." : "External rule reconciliation consumed; no central engine blocker is applied."));

        // A single Yong Shen is propagated downstream only when the configured
        // multi-method reconciliation is not in conflict. Method-specific
        // candidates remain available in methodCandidates, but a conflict must
        // never masquerade as a resolved element in the machine fields.
        const resolvedYong = (methodConflict || partialAgreement || methodOpenGate) ? null : yong;
        const resolvedXi = (methodConflict || partialAgreement || methodOpenGate) ? [] : xi;
        const resolvedJi = (methodConflict || partialAgreement || methodOpenGate) ? [] : ji;
        const yongStatus = finalDeterminationStatus;
        const candidateStatus = "CANDIDATE";

        // Explicit execution signatures are the only branch-level bridge into the
        // state matrix. They are derived from already-exposed method evidence and
        // the declared closure contract; no descriptive prose is parsed.
        const classicalClosureSignatures = [];
        if (qtbj && qtbj.evidence) {
            const climateSignals = [];
            climateSignals.push("SEASON_RESOLVED", "DAY_MASTER_RESOLVED", "SOURCE_RULE_MATCHED", "PRIMARY_REGULATOR_IDENTIFIED");
            if (qtbj.evidence.regulatorPresent === true) climateSignals.push("REGULATOR_PRESENCE_VERIFIED");
            if (qtbj.evidence.regulatorEffective === true) climateSignals.push("REGULATOR_EFFECTIVENESS_VERIFIED");
            if (qtbj.evidence.interferenceClosed === true) climateSignals.push("INTERFERENCE_SCREEN_CLOSED");
            if (qtbj.evidence.sourceInterference === true) climateSignals.push("SOURCE_INTERFERENCE");
            if (qtbj.evidence.excessPrimary === true) climateSignals.push("EXCESS_PRIMARY_UNRESOLVED");
            const climateGate = CLOSURE_CONTRACT.evaluate("CS-B13-CLIMATE", climateSignals);
            if (climateGate.status === "CLOSURE_SIGNAL_COMPLETE") classicalClosureSignatures.push("CLIMATE_CLOSURE_COMPLETE");
            else if (climateGate.status === "CLOSURE_BLOCKED") classicalClosureSignatures.push("CLIMATE_CLOSURE_BLOCKED");
        }
        if (zhuanEvidence && zhuanEvidence.mode) {
            const followingSignals = ["FOLLOWING_SUBTYPE_IDENTIFIED", "DOMINANT_FORCE_VERIFIED", "DM_ROOT_SUPPORT_AUDITED", "CONTRARY_FORCE_AUDITED", "BREAK_CONDITIONS_AUDITED"];
            if (zhuanEvidence.mode === "FOLLOW THE DOMINANT QI / 从旺") followingSignals.push("FOLLOWING_DOMINANT_QI");
            else if (zhuanEvidence.mode === "FOLLOW-STRENGTH / 从强") followingSignals.push("FOLLOWING_STRENGTH");
            else if (zhuanEvidence.mode === "FOLLOW-THE-TREND / 从势") followingSignals.push("FOLLOWING_TREND");
            if (zhuanEvidence.mode === "FOLLOW-THE-TREND / 从势" && zhuanEvidence.followingSideCount === 3) followingSignals.push("FOLLOWING_ALL_THREE_SIDES");
            if (zhuanEvidence.dmRootPresent === true) followingSignals.push("DM_ROOT_PRESENT");
            if (zhuanEvidence.dmMeaningfulSupport === true) followingSignals.push("DM_MEANINGFUL_SUPPORT");
            if (zhuanEvidence.effectiveResourceCompanion === true) followingSignals.push("EFFECTIVE_RESOURCE_COMPANION");
            if (zhuanEvidence.effectiveWealthOfficer === true) followingSignals.push("EFFECTIVE_WEALTH_OFFICER");
            if (zhuanEvidence.materialBalance === true) followingSignals.push("MATERIAL_BALANCE");
            if (zhuanEvidence.followingBroken === true) followingSignals.push("FOLLOWING_STRUCTURE_BROKEN");
            if (zhuanEvidence.breakConditionsAudited === true &&
                ((zhuanEvidence.mode === "FOLLOW THE DOMINANT QI / 从旺" || zhuanEvidence.mode === "FOLLOW-STRENGTH / 从强")
                    ? (zhuanEvidence.dmMeaningfulSupport === true && zhuanEvidence.effectiveWealthOfficer === false)
                    : (zhuanEvidence.mode === "FOLLOW-THE-TREND / 从势"
                        ? (zhuanEvidence.dmRootPresent === false && zhuanEvidence.dmMeaningfulSupport === false && zhuanEvidence.followingSideCount === 3)
                        : false))) {
                followingSignals.push("TRUE_FOLLOWING_CONDITIONS_SATISFIED");
            }
            const followingGate = CLOSURE_CONTRACT.evaluate("CS-B13-FOLLOWING", followingSignals);
            if (followingGate.status === "CLOSURE_SIGNAL_COMPLETE") classicalClosureSignatures.push("FOLLOWING_CLOSURE_COMPLETE");
            else if (followingGate.status === "CLOSURE_BLOCKED") classicalClosureSignatures.push("FOLLOWING_CLOSURE_BLOCKED");
        }

        const B13_2 = {
            method: { result: "Multi-Method Classical Framework (多法取用) — Month Command First (月令为先)", evidence: "Zi Ping Zhen Quan (子平真诠) framework; see Classical Rule Registry", status: "MULTI_METHOD" },
            signatureEvidence: classicalClosureSignatures,
            yongShen: { result: finalLabel, evidence: provenanceNote + " Other methods — Climate Regulation (调候), Disease-Medicine (病药), Communication / Bridging (通关), and Follow the Dominant Qi (专旺) are reported separately.", status: yongStatus },
            xiShen: { result: xi.length ? xi.join(", ") + " — candidate Favorable Supports (喜神)" : "NOT DETERMINED", evidence: "Support-Suppress candidate only; no final Classical Favorable God (喜神) determination is claimed", status: xi.length ? candidateStatus : "UNRESOLVED" },
            jiShen: { result: ji.length ? ji.join(", ") + " — candidate Unfavorable Factors (忌神)" : "NOT DETERMINED", evidence: "Support-Suppress candidate only; no final Classical Unfavorable God (忌神) determination is claimed", status: ji.length ? candidateStatus : "UNRESOLVED" },
            methodCandidates: { result: methodCandidates, evidence: "Five-method registry: Support-Suppress (扶抑), Disease-Medicine (病药), Climate Regulation (调候), Follow the Dominant Qi (专旺), and Communication / Bridging (通关); candidate identities are normalized before reconciliation", status: "MULTI_METHOD" },
            reconciliation: {
                candidates: reconciliationCandidates,
                activeCandidateMethods: activeCandidateMethods,
                openMethodCandidates: openMethodCandidates,
                challenge: openMethodCandidates.length ? "Method reconciliation remains open for: " + openMethodCandidates.join("; ") : "No open method gate beyond normalized candidate reconciliation",
                uniqueIdentities: uniqueCandidateIdentities,
                uniqueElements: uniqueCandidateElements,
                agreement: methodAgreement,
                elementAgreement: elementAgreement,
                partialAgreement: partialAgreement,
                conflict: methodConflict,
                status: reconciliationStatus
            },
            _determinationStatus: determinationStatus,
            _methodConflict: methodConflict,
            _strengthClass: strengthClass,
            _yongShenElements: resolvedYong ? [resolvedYong] : [],
            _xiShenElements: resolvedXi,
            _jiShenElements: resolvedJi,
            _candidateYongShenElements: yong ? [yong] : [],
            _candidateXiShenElements: xi,
            _candidateJiShenElements: ji,
            _xiShenReasons: {},
            _jiShenReasons: {}
        };

        return {
            B13_1: B13_1,
            B13_2: B13_2,
            _determinationStatus: determinationStatus,
            _yongShenElem: resolvedYong,
            _xiShenElements: resolvedXi,
            _jiShenElements: resolvedJi
        };
    }

    /* ============================================================
       B14 — STRUCTURAL DEPENDENCY
       ============================================================ */

    function buildB14(B13_2, yongShenElem, xiShenElements, jiShenElements, B9, B12) {
        const ruleStatus = (B13_2 && B13_2._determinationStatus) || "NOT DETERMINED";
        const depStatus = /^(CONFLICT|MULTI_METHOD|OPEN|NOT DETERMINED|PROVISIONAL|UNRESOLVED|CANDIDATE)$/i.test(ruleStatus) ? "OPEN" : "CALCULATED";
        const safeYong = yongShenElem || "NOT DETERMINED";
        const safeXi = xiShenElements && xiShenElements.length ? xiShenElements.join("/") : "NOT DETERMINED";
        const safeJi = jiShenElements && jiShenElements.length ? jiShenElements.join("/") : "NOT DETERMINED";
        const structureStatus = B9 && B9.status && B9.status.result ? B9.status.result : "AVAILABLE";
        const balanceStatus = B12 && B12.overall && B12.overall.status ? B12.overall.status : "AVAILABLE";
        return {
            primary: { req: safeYong + " element presence/support", type: "Yong Shen dependency candidate", status: depStatus, scope: "Rule status: " + ruleStatus },
            secondary: { req: safeXi + " element presence/support", type: "Xi Shen dependency candidate", status: depStatus, scope: "Rule status: " + ruleStatus },
            vuln: { req: "Exposure to " + safeJi + " without mitigation", type: "Ji Shen vulnerability candidate", status: depStatus, scope: "Rule status: " + ruleStatus },
            upstream: { result: "B9 structural configuration=" + structureStatus + "; B12 balance evidence=" + balanceStatus, status: depStatus, qualification: "Dependency packaging only; no new Classical determination is created." }
        };
    }

    /* ============================================================
       B15 — STRUCTURAL PRIORITY (ranked)
       ============================================================ */

    function buildB15(B2, B5, B13, B3) {
        const b2Status = B2 && B2.monthCommand && B2.monthCommand.result ? B2.monthCommand.result : "AVAILABLE";
        const b5Status = B5 && B5.strength && B5.strength.result ? B5.strength.result : "AVAILABLE";
        const b13Status = B13 && B13._determinationStatus ? B13._determinationStatus : "NOT DETERMINED";
        const b3Status = B3 && B3._determinationStatus ? B3._determinationStatus : "PROVISIONAL";
        const dependency = "B2=" + b2Status + "; B5=" + b5Status + "; B13=" + b13Status + "; B3=" + b3Status;
        return {
            "1": { factor: "Yue Ling (Month Command)", reason: "Configured structural synthesis — not a universal Classical ranking; dependencies: " + dependency, status: "CALCULATED" },
            "2": { factor: "Root (Di Zhi Gen)", reason: "Configured structural synthesis — not a universal Classical ranking; dependencies: " + dependency, status: "CALCULATED" },
            "3": { factor: "Yong Shen (Useful God)", reason: "Configured structural priority once strength is known; dependencies: " + dependency, status: "CALCULATED" },
            "4": { factor: "Ge Ju (Pattern)", reason: "Configured structural priority; not a universal Classical hierarchy claim; dependencies: " + dependency, status: "CALCULATED" }
        };
    }

    /* ============================================================
       B16 — STRUCTURAL SYNTHESIS
       B17 — CLASSICAL STRUCTURAL VERIFICATION
       ============================================================ */

    // PATCH (Audit Spec §7): status dinormalkan ke 4 nilai baku
    // (INPUT/CALCULATED/VERIFIED/ERROR). B17 sebelumnya mengklaim "VERIFIED"
    // untuk geJu/strength/yongShen padahal cuma me-restate hasil B3/B1/B13_2
    // sendiri tanpa cross-check independen — itu bukan verifikasi sungguhan,
    // jadi diturunkan ke CALCULATED. Deteksi "belum dievaluasi" sekarang baca
    // teks `result` (bukan field `status` yang sudah dibatasi 4 nilai).
    function buildB16_17(B1, B3, B9, B13_1, B13_2, dmElem, B14, B15) {
        const downstreamStatus = "CALCULATED";
        const strengthStatus = B1._strengthResolutionStatus || "UNRESOLVED";
        const geJuStatus = B3._determinationStatus || "PROVISIONAL";
        const determinationStatus = B13_2._determinationStatus || "NOT DETERMINED";
        const overallLabel = determinationStatus === "RESOLVED" ? "RULE STATUS RESOLVED" : (determinationStatus === "CONFLICT" ? "RULE STATUS CONFLICT — preserve method candidates" : "RULE STATUS " + determinationStatus);
        const specialNotEvaluated = B13_1.special.result.indexOf("NOT EVALUATED") === 0;

        const B16 = {
            primary: { result: "Day Master " + dmElem + " — " + B1.strength.result, status: strengthStatus },
            secondary: { result: B3.primary.result + " [consumed from Ge Ju determination]", status: geJuStatus },
            strength: { result: B1.dominant.result + " [Support-Suppress indicator; Classical screen separate]", status: strengthStatus },
            weakness: { result: B1._strengthClass === "STRONG" ? "Vulnerable to excessive Resource/Companion reinforcement" : (B1._strengthClass === "WEAK" ? "Vulnerable to excessive Output/Wealth/Officer drain" : "Not determined — Balanced / Borderline strength"), status: strengthStatus },
            geJu: { result: B3.final.result + " [Ge Ju determination; no independent re-determination here]", status: geJuStatus },
            dependency: { result: "Primary: " + B13_2.yongShen.result + "; Secondary: " + B13_2.xiShen.result + "; B14 dependency package consumed", status: determinationStatus },
            yongShen: { result: B13_2.yongShen.result + " (Yong Shen) / " + B13_2.xiShen.result + " (Xi Shen) / " + B13_2.jiShen.result + " (Ji Shen)", status: determinationStatus },
            overall: { result: dmElem + " Day Master; " + overallLabel + ". " + B3.primary.result + "; Yong Shen = " + B13_2.yongShen.result + "; B15 priority package consumed", status: downstreamStatus }
        };

        const B17 = {
            consistency: { result: "Foundation → Structure derivation chain executed. Dependency consistency checked; independent cross-source verification not performed.", status: "CALCULATED", scope: "Internal consistency" },
            geJu: { result: "Ge Ju is the authoritative pattern candidate/determination source; downstream structural synthesis consumes it without independent re-calculation. Complete Formation / Breaking / Rescue (成格/败格/救应) remains dependent on the applicable source conditions.", status: "CALCULATED", scope: "Internal calculation" },
            strength: { result: B1.strength.result + " via the Support-Suppress indicator plus source-based qualitative evidence; no independent Classical source verification performed.", status: "CALCULATED", scope: "Project-defined calculation + source screen" },
            yongShen: { result: B13_2.yongShen.result + " via the defined rule profile; independent source verification was not performed.", status: determinationStatus, scope: "Rule status: " + determinationStatus },
            unresolved: { result: (specialNotEvaluated ? "Special Pattern (从格/化格) evaluation is not source-specific. " : "") + (B13_1.conflict.result.indexOf("EFFECT NOT FULLY RESOLVED") !== -1 ? "Structural conflict effect remains unresolved. " : "") + "B14/B15 upstream packages consumed. Independent cross-source verification not performed.", status: "CALCULATED", scope: "Verification limitation / rule gaps" },
            independentVerification: { result: "NOT PERFORMED", status: "CALCULATED", scope: "No distinct external/reference-source verification recorded" }
        };

        return { B16: B16, B17: B17 };
    }

    /* ============================================================
       MAIN ENTRY POINT
       ============================================================ */

    // PATCH (Audit Spec §6): validasi B1 sebelum dipakai B3/B13/dst. Kalau B1
    // tidak valid (elemen tak dikenal, angka NaN/negatif), hentikan alur DI
    // SINI dengan ERROR, jangan biarkan downstream diam-diam menghasilkan
    // "determination" dari data yang sudah rusak.
    function validateB1(B1) {
        const validElements = ["Wood", "Fire", "Earth", "Metal", "Water"];
        if (!B1 || validElements.indexOf(B1.dayMasterElement) === -1) {
            throw new Error("[PenggilasCoreB] B1 VALIDATION FAILED: dayMasterElement tidak valid (" + (B1 && B1.dayMasterElement) + ")");
        }
        const numericFields = [B1.dayMasterElementWeight];
        if (numericFields.some(function (n) { return typeof n !== "number" || isNaN(n) || n < 0; })) {
            throw new Error("[PenggilasCoreB] B1 VALIDATION FAILED: dayMasterElementWeight bukan angka valid (" + B1.dayMasterElementWeight + ")");
        }
        if (typeof B1._isStrong !== "boolean") {
            throw new Error("[PenggilasCoreB] B1 VALIDATION FAILED: _isStrong bukan boolean.");
        }
        return true;
    }

    const PenggilasCoreB = {
        version: CORE_B_VERSION,

        calculate: function () {
            requireGlobals();
            const A = global.masterResult;
            const rulePlan = RULE_CONTRACT.prepare("B", A);
            const requireRule = function (key) { return RULE_CONTRACT.requireRule(rulePlan, key); };
            const cache = global.PENGGILAS_RAW_CHART;
            const dmElem = cache.dayMasterElem;
            const raw = cache.raw;

            // Explicit execution layer (B1–B17 / 结构执行层). EXEC_B* identifiers are internal orchestration names only; they are never Classical rule names.
            // execution nodes and are never used as public template fields.
            const nodeValues = {};
            const nodes = {
                "EXEC_B2": function(){ requireRule("B2"); return buildB2(A.A7, dmElem); },
                "EXEC_B1": function(){ requireRule("B1"); const v = buildB1(A.A8, A.A11, A.A7, nodeValues["EXEC_B2"], dmElem); validateB1(v); return v; },
                "EXEC_B3": function(){ requireRule("B3"); return buildB3(A.A7, A.A12_9, A.A12_6, raw, dmElem, A.A11); },
                "EXEC_B4": function(){ requireRule("B4"); return buildB4(A.A10_4, A.A7); },
                "EXEC_B5": function(){ requireRule("B5"); return buildB5(A.A11, A.A12_6); },
                "EXEC_B6": function(){ requireRule("B6"); return buildB6(A.A12_5); },
                "EXEC_B7": function(){ requireRule("B7"); return buildB7(A.A12_6); },
                "EXEC_B8": function(){ requireRule("B8"); return buildB8(A.A12_7); },
                "EXEC_B9": function(){ requireRule("B9"); return buildB9(nodeValues["EXEC_B3"], nodeValues["EXEC_B2"], nodeValues["EXEC_B5"], nodeValues["EXEC_B8"]); },
                "EXEC_B10": function(){ requireRule("B10"); const b1=nodeValues["EXEC_B1"]; return buildB10(A.A8, dmElem, b1._resourceElem, b1._outputElem, b1._wealthElem, b1._officerElem); },
                "EXEC_B11": function(){ requireRule("B11"); return buildB11(A.A8); },
                "EXEC_B12": function(){ requireRule("B12"); return buildB12(A.A8, nodeValues["EXEC_B1"]); },
                "EXEC_B13": function(){ requireRule("B13"); return buildB13(nodeValues["EXEC_B1"], nodeValues["EXEC_B3"], nodeValues["EXEC_B7"], nodeValues["EXEC_B11"]); },
                "EXEC_B14": function(){ requireRule("B14"); const b13=nodeValues["EXEC_B13"]; return buildB14(b13.B13_2, b13._yongShenElem, b13._xiShenElements, b13._jiShenElements, nodeValues["EXEC_B9"], nodeValues["EXEC_B12"]); },
                "EXEC_B15": function(){ requireRule("B15"); return buildB15(nodeValues["EXEC_B2"], nodeValues["EXEC_B5"], nodeValues["EXEC_B13"], nodeValues["EXEC_B3"]); },
                "EXEC_B16": function(){ requireRule("B16"); const b13=nodeValues["EXEC_B13"]; const bundle=buildB16_17(nodeValues["EXEC_B1"], nodeValues["EXEC_B3"], nodeValues["EXEC_B9"], b13.B13_1, b13.B13_2, dmElem, nodeValues["EXEC_B14"], nodeValues["EXEC_B15"]); nodeValues._B16_17_BUNDLE=bundle; return bundle.B16; },
                "EXEC_B17": function(){ requireRule("B17"); return nodeValues._B16_17_BUNDLE.B17; }
            };
            const nodeDeps = {
                "EXEC_B2": [], "EXEC_B1": ["EXEC_B2"], "EXEC_B3": ["EXEC_B1"], "EXEC_B4": [], "EXEC_B5": [], "EXEC_B6": [], "EXEC_B7": [], "EXEC_B8": [],
                "EXEC_B9": ["EXEC_B3","EXEC_B2","EXEC_B5","EXEC_B8"], "EXEC_B10": ["EXEC_B1"], "EXEC_B11": [], "EXEC_B12": ["EXEC_B1"],
                "EXEC_B13": ["EXEC_B1","EXEC_B3","EXEC_B7","EXEC_B11"], "EXEC_B14": ["EXEC_B13","EXEC_B9","EXEC_B12"], "EXEC_B15": ["EXEC_B2","EXEC_B5","EXEC_B13","EXEC_B3"],
                "EXEC_B16": ["EXEC_B1","EXEC_B3","EXEC_B9","EXEC_B13","EXEC_B14","EXEC_B15"], "EXEC_B17": ["EXEC_B16"]
            };
            const nodeOrder = ["EXEC_B2","EXEC_B1","EXEC_B3","EXEC_B4","EXEC_B5","EXEC_B6","EXEC_B7","EXEC_B8","EXEC_B9","EXEC_B10","EXEC_B11","EXEC_B12","EXEC_B13","EXEC_B14","EXEC_B15","EXEC_B16","EXEC_B17"];
            const doneNodes = new Set();
            nodeOrder.forEach(function(id){
                const unresolved=(nodeDeps[id]||[]).filter(function(d){return !doneNodes.has(d);});
                if(unresolved.length) throw new Error("[PenggilasCoreB] Node dependency violation "+id+" <- "+unresolved.join(","));
                if(typeof nodes[id] !== "function") throw new Error("[PenggilasCoreB] Missing execution node: "+id);
                nodeValues[id]=nodes[id](); doneNodes.add(id);
            });

            const b13 = nodeValues["EXEC_B13"];
            const mechanicalA12_9 = A.A12_9 || { primary: {}, alt: {} };
            const b3 = nodeValues["EXEC_B3"];
            const authoritativeA12_9 = {
                primary: {
                    elem: b3.primary && b3.primary.result ? b3.primary.result : (mechanicalA12_9.primary.elem || "-"),
                    _stemKey: mechanicalA12_9.primary._stemKey || null,
                    _godCode: mechanicalA12_9.primary._godCode || null
                },
                alt: {
                    elem: b3.alt && b3.alt.result ? b3.alt.result : (mechanicalA12_9.alt.elem || "None"),
                    _stemKeys: mechanicalA12_9.alt._stemKeys || [],
                    _godCodes: mechanicalA12_9.alt._godCodes || []
                },
                _source: "B3",
                _status: "SYNCED_FROM_AUTHORITATIVE_GEJU"
            };
            const structureMaster = {
                B1: nodeValues["EXEC_B1"], B2: nodeValues["EXEC_B2"], B3: nodeValues["EXEC_B3"], B4: nodeValues["EXEC_B4"],
                B5: nodeValues["EXEC_B5"], B6: nodeValues["EXEC_B6"], B7: nodeValues["EXEC_B7"], B8: nodeValues["EXEC_B8"],
                B9: nodeValues["EXEC_B9"], B10: nodeValues["EXEC_B10"], B11: nodeValues["EXEC_B11"], B12: nodeValues["EXEC_B12"],
                B13_1: b13.B13_1, B13_2: b13.B13_2, B14: nodeValues["EXEC_B14"], B15: nodeValues["EXEC_B15"],
                B16: nodeValues["EXEC_B16"], B17: nodeValues["EXEC_B17"],
                A12_9: authoritativeA12_9,
                _nodeExecution: { layer: "NODE", nodes: nodeOrder, dependencies: nodeDeps, fields: "B1..B17" },
                _rulePlan: rulePlan
            };

            // Post-execution audit trace: the authoritative B rule contract was already consumed
            // by the rule registry before B1–B17. This trace records result/evidence state.
            if (RULE_EVALUATOR) {
                const trace = RULE_EVALUATOR.evaluate(global.masterResult, structureMaster).sectionCoverage;
                structureMaster._ruleTrace = {};
                Object.keys(trace).filter(function (k) { return /^B/.test(k); }).forEach(function (k) {
                    structureMaster._ruleTrace[k] = trace[k];
                });
            }

            structureMaster._engineExecution = structureMaster._nodeExecution;
            structureMaster._ruleExecution = { section: "B", status: rulePlan.status, authoritativeRuleKeys: rulePlan.authoritativeRuleKeys.slice() };

            global.masterResult = global.masterResult || {};
            Object.assign(global.masterResult, structureMaster);
            global.masterResult._engineExecution = structureMaster._engineExecution;

            // PATCH (Audit Spec §5): field cache murni machine-readable (array
            // elemen), bukan campuran teks/elemen tunggal seperti sebelumnya.
            global.PENGGILAS_RAW_CHART.dmStrong = structureMaster.B1._isStrong;
            global.PENGGILAS_RAW_CHART.determinationStatus = b13._determinationStatus;
            global.PENGGILAS_RAW_CHART.yongShenElem = b13._yongShenElem;
            global.PENGGILAS_RAW_CHART.xiShenElements = b13._xiShenElements;
            global.PENGGILAS_RAW_CHART.jiShenElements = b13._jiShenElements;

            console.log("[PenggilasCoreB] Structure Master (B1\u2013B17) selesai dihitung.");
            return structureMaster;
        }
    };

    global.PenggilasCoreB = PenggilasCoreB;

})(window);
