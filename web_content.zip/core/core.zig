const std = @import("std");
pub fn main() void {
    var hp: i32 = 100;
    var s: i32 = 0;
    while (hp > 0) : (hp -= 50) s += 1;
    var a: i32 = 5;
    var p: i32 = 2;
    while (p > 0 and a < 14) : (p -= 1) a += 1;
    const n: i32 = @min(30, 90);
    std.debug.print("shots={d} alive={d} mag={d} res={d}\n", .{ s, a, n, 90 - n });
}
