let hp:number=100,s:number=0;while(hp>0){hp-=50;s++}let a:number=5,p:number=2;while(p>0&&a<14){a++;p--}const n:number=Math.min(30,90);console.log(`shots=${s} alive=${a} mag=${n} res=${90-n}`);
