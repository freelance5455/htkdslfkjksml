main = let s = length (takeWhile (>0) (iterate (subtract 50) 100)); a = min 14 (5+2); n = min 30 90 in putStrLn ("shots="++show s++" alive="++show a++" mag="++show n++" res="++show (90-n))
