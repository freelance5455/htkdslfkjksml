hp, s, a, p = 100, 0, 5, 2
while hp > 0:
    hp -= 50; s += 1
while p > 0 and a < 14:
    a += 1; p -= 1
n = min(30, 90)
print(f"shots={s} alive={a} mag={n} res={90-n}")
