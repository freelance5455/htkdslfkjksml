extends SceneTree
func _init():
    var hp := 100
    var s := 0
    while hp > 0:
        hp -= 50
        s += 1
    var a := 5
    var p := 2
    while p > 0 and a < 14:
        a += 1
        p -= 1
    var n := mini(30, 90)
    print("shots=%d alive=%d mag=%d res=%d" % [s, a, n, 90 - n])
    quit()
