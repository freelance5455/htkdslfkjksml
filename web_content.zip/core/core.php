<?php $hp=100;$s=0;while($hp>0){$hp-=50;$s++;}$a=5;$p=2;while($p>0&&$a<14){$a++;$p--;}$n=min(30,90);echo "shots=$s alive=$a mag=$n res=".(90-$n)."\n";
