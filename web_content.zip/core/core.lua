local hp,s,a,p=100,0,5,2 while hp>0 do hp=hp-50 s=s+1 end while p>0 and a<14 do a=a+1 p=p-1 end local n=math.min(30,90) print(("shots=%d alive=%d mag=%d res=%d"):format(s,a,n,90-n))
