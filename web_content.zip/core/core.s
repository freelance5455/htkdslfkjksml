.globl _start
_start:
    mov $100,%eax
    xor %edi,%edi
1:  sub $50,%eax
    inc %edi
    test %eax,%eax
    jg 1b
    mov $60,%eax
    syscall
