/* ============================================================
   PENGGILAS BAZI — CORE C
   TEMPORAL DYNAMICS (Section C — result-template.html)

   METODOLOGI: Classical Zi Ping (子平八字)
   TANGGUNG JAWAB:
     Menganalisis bagaimana Da Yun (大运, periode 10-tahunan) yang
     SEDANG AKTIF SEKARANG (dari jam sistem saat laporan dibuka)
     berinteraksi dengan chart natal (Section A) dan struktur
     (Section B). Liu Nian (tahun berjalan) disebutkan sebagai
     konteks tambahan di dalam narasi, bukan field terpisah
     (template tidak menyediakan field Liu Nian sendiri).

   SUMBER DATA:
     window.masterResult.A4/A8/A11/A12_5/A12_6 -> chart natal
     window.masterResult.A14_2 -> daftar 8 pilar Da Yun
     window.masterResult.B1/B12/B13_2 -> kekuatan DM & Yong Shen
     window.PENGGILAS_RAW_CHART -> elemen Day Master, Yong/Xi/Ji Shen
     explicit calculation asOf -> penentu Da Yun/Liu Nian aktif
   ============================================================ */

(function (global) {
    "use strict";

    const CORE_C_VERSION = "V4.2-NODE-FIELD-SEPARATED-AUTHORITY-BOUNDARY";
    const PILLAR_LABEL = BAZI_DATA.projectConfig.pillarLabels;
    const PILLARS = BAZI_DATA.projectConfig.pillarKeys;
    const SHENG_CYCLE = BAZI_DATA.projectConfig.shengCycle;
    const KE_CYCLE = BAZI_DATA.projectConfig.keCycle;
    const RULE_EVALUATOR = global.PENGGILAS_CLASSICAL_RULE_EVALUATOR || null;
    const RULE_CONTRACT = global.PENGGILAS_BC_RULES || null;

    // Authority boundary: Core C must consume the determination contract for
    // Useful Element status/value. B13_2 remains a method/candidate layer and
    // is never used here as a fallback authority. If the determination is not
    // FINAL, C keeps Yong/Xi/Ji unresolved rather than upgrading a candidate.
    function getAuthoritativeUsefulElement() {
        const contract = global.masterResult && global.masterResult._determinationContract;
        const claim = contract && contract.claims ? contract.claims["USEFUL_ELEMENT"] : null;
        if (!claim || claim.status !== "FINAL" || !claim.resolvedValue) {
            return { status: claim && claim.status ? claim.status : "NOT DETERMINED", final: false, element: null, xi: [], ji: [] };
        }
        return {
            status: "FINAL",
            final: true,
            element: claim.resolvedValue.element || null,
            label: claim.resolvedValue.label || null,
            xi: [],
            ji: []
        };
    }

    function requireGlobals() {
        if (!global.masterResult || !global.masterResult.A14_2 || !global.masterResult.B1) {
            throw new Error("[PenggilasCoreC] Section A & B (masterResult) belum lengkap. Jalankan Core A dan Core B terlebih dahulu.");
        }
        if (!global.PENGGILAS_RAW_CHART) {
            throw new Error("[PenggilasCoreC] PENGGILAS_RAW_CHART belum tersedia.");
        }
        if (typeof global.Solar === "undefined") {
            throw new Error("[PenggilasCoreC] Modul Solar (lunar-javascript) belum termuat.");
        }
        if (!RULE_CONTRACT || typeof RULE_CONTRACT.prepare !== "function") {
            throw new Error("[PenggilasCoreC] Classical Rule Registry belum termuat.");
        }
        if (!RULE_EVALUATOR || typeof RULE_EVALUATOR.evaluate !== "function") {
            throw new Error("[PenggilasCoreC] Classical rule evaluator belum termuat.");
        }
        if (!global.masterResult._determinationContract) {
            throw new Error("[PenggilasCoreC] Determination contract belum tersedia. Jalankan Core B → Determination terlebih dahulu.");
        }
    }

    /* ============================================================
       IDENTIFIKASI DA YUN & LIU NIAN AKTIF (berbasis calculation asOf)
       ============================================================ */

    // PATCH (Audit Spec §14): sekarang memakai perbandingan datetime PRESISI
    // (currentDateTime >= periodStart && currentDateTime < periodEnd), bukan
    // cuma currentYear >= startYear yang bisa salah di sekitar tanggal transisi
    // sebenarnya (mis. Da Yun bisa mulai di pertengahan tahun, bukan 1 Januari).
    function findActiveDaYun(A14_2, now) {
        const nowMs = now.getTime();
        const keys = Object.keys(A14_2).sort(function (a, b) { return Number(a) - Number(b); });
        let active = null, note = "";

        keys.forEach(function (k) {
            const p = A14_2[k];
            const startMs = new Date(p._startDateTimeISO).getTime();
            const endMs = new Date(p._endDateTimeISO).getTime();
            if (nowMs >= startMs && nowMs < endMs) active = { no: k, pillar: p };
        });

        if (!active) {
            const first = A14_2[keys[0]];
            const last = A14_2[keys[keys.length - 1]];
            if (nowMs < new Date(first._startDateTimeISO).getTime()) {
                active = { no: keys[0], pillar: first };
                note = "Current date is before the first Da Yun period starts \u2014 showing first period as reference (chart is still in pre-Da-Yun childhood phase).";
            } else {
                active = { no: keys[keys.length - 1], pillar: last };
                note = "Current date is beyond the last calculated Da Yun period (age " + last.endAge + ") \u2014 showing last period as reference; a further period would need re-calculation.";
            }
        }
        return { active: active, note: note };
    }

    function getLiuNian(now) {
        const solar = global.Solar.fromYmdHms(now.getFullYear(), now.getMonth() + 1, now.getDate(), now.getHours(), now.getMinutes(), now.getSeconds());
        const ec = solar.getLunar().getEightChar();
        return { ganHanzi: ec.getYearGan(), zhiHanzi: ec.getYearZhi() };
    }

    /* ============================================================
       DETEKSI INTERAKSI (He/Chong/Xing/Hai/Po/San He/Ban He/San Hui)
       ------------------------------------------------------------
       Fungsi privat modul ini — SALINAN YANG SAMA juga ada di
       core/coreA.js (dipakai untuk A12.5/A12.6/A14.3). Ini duplikasi
       yang disengaja: Core C tidak boleh bergantung pada internal
       Core A atau file "engine" terpisah di luar A/B/C. Aturan (mode,
       minMembers, dsb) tetap dibaca dari bazi-data.js — fungsi ini
       murni memproses data registry, bukan menyimpan aturan sendiri.
       Kalau logika ini perlu ditambal, tambal juga salinannya di
       core/coreA.js supaya kedua Core tetap konsisten.
       ============================================================ */

    function uniqueBy(arr, keyFn) {
        const seen = new Set();
        const out = [];
        arr.forEach(function (item) {
            const k = keyFn(item);
            if (!seen.has(k)) { seen.add(k); out.push(item); }
        });
        return out;
    }

    function scanStems(entries) {
        const he = [], chong = [];
        for (let i = 0; i < entries.length; i++) {
            for (let j = i + 1; j < entries.length; j++) {
                const a = entries[i], b = entries[j];
                BAZI_DATA.wuHePairs.forEach(function (p) {
                    if ((a.key === p.pair[0] && b.key === p.pair[1]) || (a.key === p.pair[1] && b.key === p.pair[0])) {
                        he.push({ members: [a, b], element: p.element });
                    }
                });
                BAZI_DATA.stemChongPairs.forEach(function (p) {
                    if ((a.key === p[0] && b.key === p[1]) || (a.key === p[1] && b.key === p[0])) {
                        chong.push({ members: [a, b] });
                    }
                });
            }
        }
        return { he: he, chong: chong };
    }

    function scanBranches(entries) {
        const liuHe = [], sanHe = [], banHe = [], sanHui = [], chong = [], hai = [], po = [], xing = [];

        for (let i = 0; i < entries.length; i++) {
            for (let j = i + 1; j < entries.length; j++) {
                const a = entries[i], b = entries[j];
                BAZI_DATA.liuHePairs.forEach(function (p) {
                    if ((a.key === p.pair[0] && b.key === p.pair[1]) || (a.key === p.pair[1] && b.key === p.pair[0])) {
                        liuHe.push({ members: [a, b], element: p.element });
                    }
                });
                BAZI_DATA.chongPairs.forEach(function (p) {
                    if ((a.key === p[0] && b.key === p[1]) || (a.key === p[1] && b.key === p[0])) {
                        chong.push({ members: [a, b] });
                    }
                });
                BAZI_DATA.haiPairs.forEach(function (p) {
                    if ((a.key === p[0] && b.key === p[1]) || (a.key === p[1] && b.key === p[0])) {
                        hai.push({ members: [a, b] });
                    }
                });
                BAZI_DATA.poPairs.forEach(function (p) {
                    if ((a.key === p[0] && b.key === p[1]) || (a.key === p[1] && b.key === p[0])) {
                        po.push({ members: [a, b], relationClass: "SECONDARY_VARIANT" });
                    }
                });
            }
        }

        BAZI_DATA.sanHeGroups.forEach(function (group) {
            const present = entries.filter(function (e) { return group.branches.indexOf(e.key) !== -1; });
            const uniqueMembers = uniqueBy(present, function (e) { return e.key; });
            const fullCount = group.branches.length;
            if (uniqueMembers.length === fullCount) {
                sanHe.push({ members: present, uniqueKeys: uniqueMembers.map(function (m) { return m.key; }), element: group.element });
            } else if (uniqueMembers.length === fullCount - 1) {
                banHe.push({ members: present, uniqueKeys: uniqueMembers.map(function (m) { return m.key; }), element: group.element });
            }
        });

        BAZI_DATA.sanHuiGroups.forEach(function (group) {
            const present = entries.filter(function (e) { return group.branches.indexOf(e.key) !== -1; });
            const uniqueMembers = uniqueBy(present, function (e) { return e.key; });
            if (uniqueMembers.length === group.branches.length) {
                sanHui.push({ members: present, uniqueKeys: uniqueMembers.map(function (m) { return m.key; }), element: group.element });
            }
        });

        Object.keys(BAZI_DATA.xingGroups).forEach(function (groupKey) {
            const group = BAZI_DATA.xingGroups[groupKey];
            const minMembers = group.minMembers || 2;

            if (group.mode === "repetition") {
                group.branches.forEach(function (branchKey) {
                    const occurrences = entries.filter(function (e) { return e.key === branchKey; });
                    if (occurrences.length >= minMembers) {
                        xing.push({ groupKey: groupKey, name: group.name, members: occurrences, uniqueKeys: [branchKey] });
                    }
                });
                return;
            }

            const present = entries.filter(function (e) { return group.branches.indexOf(e.key) !== -1; });
            const uniqueMembers = uniqueBy(present, function (e) { return e.key; });
            if (uniqueMembers.length >= minMembers) {
                xing.push({ groupKey: groupKey, name: group.name, members: present, uniqueKeys: uniqueMembers.map(function (m) { return m.key; }) });
            }
        });

        return { liuHe: liuHe, sanHe: sanHe, banHe: banHe, sanHui: sanHui, chong: chong, hai: hai, po: po, xing: xing };
    }

    /* ============================================================
       C1 — TEMPORAL INTERACTION
       ============================================================ */

    function buildC1(dyStemHanzi, dyBranchHanzi, dmElem, dmHanzi, A, dyLabel) {
        const stemInfo = BAZI_DATA.getStemByHanzi(dyStemHanzi);
        const branchInfo = BAZI_DATA.getBranchByHanzi(dyBranchHanzi);
        const stemGodCode = BAZI_DATA.getTenGodByHanzi(dmHanzi, dyStemHanzi);
        const stemGodInfo = stemGodCode ? BAZI_DATA.tenGods[stemGodCode] : null;
        const stemGodLabel = stemGodInfo ? (stemGodInfo.pinyin + " (" + stemGodInfo.hanzi + ")") : "-";

        const hidden = BAZI_DATA.getHiddenStemsByHanzi(dyBranchHanzi);
        const mainQi = hidden[0];
        const mainQiGodCode = mainQi ? BAZI_DATA.getTenGod(BAZI_DATA.hanziToStemKey(dmHanzi), mainQi.stem) : null;
        const mainQiGodInfo = mainQiGodCode ? BAZI_DATA.tenGods[mainQiGodCode] : null;

        const touQing = stemInfo && mainQi && stemInfo.element === mainQi.element;

        return {
            stemDynamics: dyLabel + " Stem " + (stemInfo ? stemInfo.pinyin : "?") + " (" + dyStemHanzi + ", " + (stemInfo ? stemInfo.element : "-") + ") \u2192 " + stemGodLabel + " relative to Day Master " + dmElem,
            branchDynamics: dyLabel + " Branch " + (branchInfo ? branchInfo.pinyin : "?") + " (" + dyBranchHanzi + ", " + (branchInfo ? branchInfo.element : "-") + "), Main Qi " + (mainQi ? mainQi.stem : "-") + " \u2192 " + (mainQiGodInfo ? (mainQiGodInfo.pinyin + " (" + mainQiGodInfo.hanzi + ")") : "-"),
            godDynamics: "Stem brings " + stemGodLabel + "; Branch Main Qi brings " + (mainQiGodInfo ? (mainQiGodInfo.pinyin + " (" + mainQiGodInfo.hanzi + ")") : "-") + (stemGodCode === mainQiGodCode ? " \u2014 consistent/reinforcing" : " \u2014 mixed influence"),
            touQing: touQing ? "Stem/Branch element alignment detected — 透清 indicator only; no Classical 透清 confirmation" : "No configured elemental alignment detected; Classical 透清 not established"
        };
    }

    /* ============================================================
       C2 — COMBINATION & CONFLICT (Da Yun stem/branch vs Natal)
       ============================================================ */

    // Memakai scanStems()/scanBranches() yang sama dengan A12.5/A12.6/A14.3
    // (salinan identik, lihat catatan di atas). Field `_clashHits`/
    // `_monthClashed` disediakan sebagai DATA
    // TERSTRUKTUR untuk dipakai C4/C5, supaya mereka tidak perlu mencari
    // substring "Month" di dalam teks tampilan `clash`.
    function buildC2(dyStemHanzi, dyBranchHanzi, raw, A12_7) {
        const DY = "DaYun";
        const dyStemKey = BAZI_DATA.hanziToStemKey(dyStemHanzi);
        const dyBranchKey = BAZI_DATA.hanziToBranchKey(dyBranchHanzi);
        const natalStems = PILLARS.map(function (k) { return { pillar: PILLAR_LABEL[k], key: BAZI_DATA.hanziToStemKey(raw[k].ganHanzi) }; });
        const natalBranches = PILLARS.map(function (k) { return { pillar: PILLAR_LABEL[k], key: BAZI_DATA.hanziToBranchKey(raw[k].zhiHanzi) }; });

        const stemEntries = natalStems.concat([{ pillar: DY, key: dyStemKey }]);
        const branchEntries = natalBranches.concat([{ pillar: DY, key: dyBranchKey }]);

        const stemScan = scanStems(stemEntries);
        const branchScan = scanBranches(branchEntries);

        function involvesDaYun(hit) { return hit.members.some(function (m) { return m.pillar === DY; }); }
        function otherLabel(hit) { const o = hit.members.find(function (m) { return m.pillar !== DY; }); return o ? o.pillar : "?"; }

        const combos = [];
        const transformationCandidates = [];
        const heHits = stemScan.he.filter(involvesDaYun);
        heHits.forEach(function (h) {
            combos.push("Stem He: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ") \u2192 " + h.element);
            transformationCandidates.push(h.members[0].key + "+" + h.members[1].key + " — Candidate / Unconfirmed");
        });
        const liuHeHits = branchScan.liuHe.filter(involvesDaYun);
        liuHeHits.forEach(function (h) {
            combos.push("Branch Liu He: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ") \u2192 " + h.element);
            transformationCandidates.push(h.members[0].key + "+" + h.members[1].key + " — Candidate / Unconfirmed");
        });
        const sanHeHits = branchScan.sanHe.filter(function (h) { return h.members.some(function (m) { return m.pillar === DY; }); });
        sanHeHits.forEach(function (h) {
            combos.push("Branch San He: " + h.uniqueKeys.join("\u2013") + " (full triplet, incl. Da Yun) \u2192 " + h.element);
        });
        const banHeHits = branchScan.banHe.filter(function (h) { return h.members.some(function (m) { return m.pillar === DY; }); });
        banHeHits.forEach(function (h) {
            combos.push("Branch Ban He: " + h.uniqueKeys.join("\u2013") + " (partial, incl. Da Yun) \u2192 " + h.element);
        });
        const sanHuiHits = branchScan.sanHui.filter(function (h) { return h.members.some(function (m) { return m.pillar === DY; }); });
        sanHuiHits.forEach(function (h) {
            combos.push("Branch San Hui: " + h.uniqueKeys.join("\u2013") + " (full seasonal assembly, incl. Da Yun) \u2192 " + h.element);
        });

        const stemChongHits = stemScan.chong.filter(involvesDaYun);
        const branchChongHits = branchScan.chong.filter(involvesDaYun);
        const clashHits = stemChongHits.concat(branchChongHits);
        const clashes = [];
        stemChongHits.forEach(function (h) { clashes.push("Stem Chong: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ")"); });
        branchChongHits.forEach(function (h) { clashes.push("Branch Chong: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ")"); });

        const haiHits = branchScan.hai.filter(involvesDaYun);
        const poHits = branchScan.po.filter(involvesDaYun);
        const xingHits = branchScan.xing.filter(function (h) { return h.members.some(function (m) { return m.pillar === DY; }); });
        const punishHarm = [];
        haiHits.forEach(function (h) { punishHarm.push("Hai: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ")"); });
        poHits.forEach(function (h) { punishHarm.push("Po [Secondary/Variant]: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ")"); });
        xingHits.forEach(function (h) { punishHarm.push("Xing: " + h.uniqueKeys.join("\u2013") + " (" + Array.from(new Set(h.members.map(function (m) { return m.pillar; }))).join(", ") + ") \u2014 " + h.name); });

        const conflicts = [];
        const totalConflictCount = clashHits.length + haiHits.length + xingHits.length;
        if (totalConflictCount > 0) {
            conflicts.push("Da Yun introduces " + totalConflictCount + " conflict-type interaction(s) with the natal chart \u2014 conflict-type interaction detected; no outcome inference is made");
        }

        const huaStatus = A12_7 && A12_7.row1 ? A12_7.row1.status : "A12.7 status unavailable";
        const transformationText = transformationCandidates.length
            ? "Natal Hua (化) status carried from the established Transformation / Hua assessment: " + huaStatus + ". Da Yun interaction candidate(s): " + transformationCandidates.join("; ") + ". No unsupported temporal transformation is produced by C2."
            : (huaStatus && huaStatus !== "A12.7 status unavailable"
                ? "Natal Hua (化) status carried from the established Transformation / Hua assessment: " + huaStatus + ". No Da Yun He requiring additional temporal transformation review."
                : "Transformation Status: None established — no Da Yun He requiring Hua review");

        return {
            combination: combos.length ? combos.join("; ") : "None detected",
            transformation: transformationText,
            clash: clashes.length ? clashes.join("; ") : "None detected",
            punishHarm: punishHarm.length ? punishHarm.join("; ") : "None detected",
            conflict: conflicts.length ? conflicts.join("; ") : "No significant conflict/competition detected between Da Yun and natal chart",
            // Field mesin (Audit Spec §13) — dipakai C4/C5, bukan parsing teks di atas.
            _clashHits: clashHits,
            _monthClashed: clashHits.some(function (h) { return otherLabel(h) === "Month"; })
        };
    }

    /* ============================================================
       C3 — QI & STRUCTURAL RESPONSE
       ============================================================ */

    function buildC3(dyStemHanzi, dyBranchHanzi, dmElem, A, cache) {
        const stemInfo = BAZI_DATA.getStemByHanzi(dyStemHanzi);
        const dyElem = stemInfo ? stemInfo.element : "-";

        let sxk;
        if (dyElem === dmElem) sxk = "Same element (\u6bd4/\u52ab) \u2014 reinforces Day Master directly";
        else if (SHENG_CYCLE[dyElem] === dmElem) sxk = "Sheng (\u751f) \u2014 Da Yun element generates/supports Day Master";
        else if (SHENG_CYCLE[dmElem] === dyElem) sxk = "Xie (\u6cc4) \u2014 Day Master generates/drains into Da Yun element";
        else if (KE_CYCLE[dyElem] === dmElem) sxk = "Ke (\u514b) \u2014 Da Yun element controls/pressures Day Master";
        else sxk = "Ke (\u514b) \u2014 Day Master controls Da Yun element (Wealth-type drain)";

        const hidden = BAZI_DATA.getHiddenStemsByHanzi(dyBranchHanzi);
        const rootAdded = hidden.some(function (hs) { return hs.element === dmElem; });

        const A8 = A.A8;
        const missingElems = ["Wood", "Fire", "Earth", "Metal", "Water"].filter(function (e) { return A8[e.toLowerCase()].raw === 0; });
        const branchInfo = BAZI_DATA.getBranchByHanzi(dyBranchHanzi);
        const fillsGap = missingElems.indexOf(dyElem) !== -1 || (branchInfo && missingElems.indexOf(branchInfo.element) !== -1);

        const usefulElement = getAuthoritativeUsefulElement();
        const determinationStatus = usefulElement.status;
        const isResolved = usefulElement.final;
        const isYongShen = isResolved && dyElem === usefulElement.element;
        const isXiShen = false;
        const isJiShen = false;

        return {
            shengXieKe: sxk,
            genQi: rootAdded ? "Yes \u2014 Da Yun branch's hidden stem(s) include " + dmElem + ", adding temporal root support" : "No \u2014 Da Yun branch does not add root support for Day Master",
            qiLiu: fillsGap ? "Structural presence-gap overlap detected for " + dyElem + " — this is NOT a complete 气流 receiver/blockage determination" : "No structural-absence overlap detected for " + dyElem + " — full 气流 remains unevaluated",
            dependency: determinationStatus === "CONFLICT" ? "Yong/Xi/Ji temporal dependency CONFLICT — method-specific candidates preserved" : (!isResolved ? "Yong/Xi/Ji temporal dependency NOT DETERMINED — rule status is " + determinationStatus : (isYongShen ? "Matches Yong Shen (用神) — directly supports the chart's configured core need" : (isXiShen ? "Matches Xi Shen (喜神) — secondary favorable support" : (isJiShen ? "Matches Ji Shen (忌神) — unfavorable under the configured method" : "Neutral — does not directly match Yong/Xi/Ji Shen")))),
            activation: rootAdded ? "Temporal root-support evidence detected for the Day Master" : (fillsGap ? "Temporal element matches an A8 structural-absence flag" : "No new root or absence-overlap evidence detected")
        };
    }

    /* ============================================================
       C4 — STRUCTURAL CHANGE
       ============================================================ */

    function buildC4(dyStemHanzi, dyBranchHanzi, A, cache, C2) {
        const B3 = A.B3;
        const stemInfo = BAZI_DATA.getStemByHanzi(dyStemHanzi);
        const dyElem = stemInfo ? stemInfo.element : "-";
        const geJuGodName = B3._primaryGodName;
        const geJuGodCode = B3._primaryGodCode;

        const stemGodCode = BAZI_DATA.getTenGodByHanzi(cache.raw.day.ganHanzi, dyStemHanzi);
        const reinforcesGeJu = !!(stemGodCode && geJuGodCode && stemGodCode === geJuGodCode);

        const monthClashed = C2._monthClashed;

        const usefulElement = getAuthoritativeUsefulElement();
        const determinationStatus = usefulElement.status;
        const isResolved = usefulElement.final;
        const isYongShen = isResolved && dyElem === usefulElement.element;
        const isXiShen = false;
        const isJiShen = false;

        const natalFormation = String(B3.formation && B3.formation.result || "");
        const natalStageClosed = B3._determinationStatus === "RESOLVED";
        // Registry C4_CHENG requires an explicit temporal missing-formation
        // condition. The current source profile does not expose such a condition
        // as machine-readable evidence, so Ten-God matching is retained as
        // reinforcement/Tou-Qing evidence only and MUST NOT be promoted to Cheng Ge.
        const temporalMissingCondition = null;
        const temporalFormationEvidence = !!(reinforcesGeJu && !monthClashed && temporalMissingCondition);
        const temporalReinforcementOnly = reinforcesGeJu && !monthClashed;
        const temporalDisruptionEvidence = monthClashed;

        return {
            activation: temporalReinforcementOnly ? "Structural reinforcement screen — Da Yun Stem matches the natal pattern's Month-Qi Ten-God candidate (" + geJuGodName + "); this is not sufficient for temporal Cheng Ge" : "No direct natal Ge Ju Ten-God reinforcement detected",
            chengGe: temporalFormationEvidence
                ? (natalStageClosed ? "Temporal Cheng Ge support detected after explicit missing-condition closure" : "Temporal Cheng Ge candidate — natal formation stage remains open")
                : (temporalReinforcementOnly ? "PROVISIONAL — temporal reinforcement detected, but the required temporal missing-formation condition is not configured; Cheng Ge is not established" : "NOT DETERMINED — current evidence does not establish the complete source-specific formation conditions"),
            bianGe: temporalDisruptionEvidence ? "Temporal pattern-disruption candidate — Da Yun clashes the Month Command; Bian Ge requires prior structure, disrupting/transforming factor, resulting structure and stability/continuity" : "No Month-Command clash detected; Bian Ge not established",
            shift: temporalDisruptionEvidence ? "Pattern-disruption evidence from Month Command clash; full Bian Ge conditions remain source-dependent" : (temporalReinforcementOnly ? "Structural reinforcement evidence only; no independent temporal pattern transformation is inferred" : "No significant temporal structural shift detected"),
            yongShen: determinationStatus === "CONFLICT" ? "CONFLICT — method-specific Yong Shen candidates preserved" : (!isResolved ? "NOT DETERMINED — rule status: " + determinationStatus : (isYongShen ? "Configured Yong Shen relation — DETERMINED" : "Da Yun element (" + dyElem + ") does not match configured Yong Shen")),
            xiJiShen: determinationStatus === "CONFLICT" ? "CONFLICT — Xi/Ji method-specific candidates preserved" : (!isResolved ? "NOT DETERMINED — rule status: " + determinationStatus : (isXiShen ? "Configured Xi relation — DETERMINED" : (isJiShen ? "Configured Ji relation — DETERMINED" : "Neutral / Mixed configured relation"))),
            evidence: { natalFormation: natalFormation, natalPatternResolved: natalStageClosed, temporalReinforcementOnly: temporalReinforcementOnly, temporalMissingFormationCondition: temporalMissingCondition, temporalFormationEvidence: temporalFormationEvidence, temporalDisruptionEvidence: temporalDisruptionEvidence, sourceBoundary: "Temporal evidence supplements natal pattern rules; it does not replace the natal formation/breaking/rescue profile." }
        };
    }

    /* ============================================================
       C5 — TEMPORAL BALANCE
       ============================================================ */

    function buildC5(dyStemHanzi, dyBranchHanzi, A, cache, C2) {
        const stemInfo = BAZI_DATA.getStemByHanzi(dyStemHanzi);
        const branchInfo = BAZI_DATA.getBranchByHanzi(dyBranchHanzi);
        const dyStemElem = stemInfo ? stemInfo.element : "-";
        const dmElem = cache.dayMasterElem;
        const hidden = BAZI_DATA.getHiddenStemsByHanzi(dyBranchHanzi) || [];
        const temporalElements = [dyStemElem, branchInfo ? branchInfo.element : "-"].concat(hidden.map(function (h) { return h.element; })).filter(function (e) { return e !== "-"; });
        const temporalElementCounts = temporalElements.reduce(function (acc, e) { acc[e] = (acc[e] || 0) + 1; return acc; }, {});
        const supports = temporalElements.filter(function (e) { return e === dmElem || SHENG_CYCLE[e] === dmElem; });
        const drainsOrControls = temporalElements.filter(function (e) { return SHENG_CYCLE[dmElem] === e || KE_CYCLE[dmElem] === e || KE_CYCLE[e] === dmElem; });
        const strengthClass = A.B1._strengthClass || "UNRESOLVED";
        const strengthBasis = A.B1._strengthResolutionStatus || "UNKNOWN";
        const isStrong = strengthClass === "STRONG";
        let supportResult;
        if (strengthClass === "BALANCED") supportResult = "Balanced / borderline natal strength — temporal influence is reported without Strong/Weak bias";
        else if (isStrong && supports.length && !drainsOrControls.length) supportResult = "Obstruction — temporal Gan/Zhi/Hidden Stems add support-side influence to the natal strength indicator";
        else if (isStrong && drainsOrControls.length) supportResult = "Mixed — temporal composition contains both support-side and drain/control-side elements for the configured natal strength indicator";
        else if (strengthClass === "WEAK" && supports.length) supportResult = "Support — temporal Gan/Zhi/Hidden Stems include support-side influence for the natal strength indicator";
        else if (strengthClass === "WEAK" && drainsOrControls.length) supportResult = "Obstruction — temporal Gan/Zhi includes drain/control influences for the natal strength indicator";
        else supportResult = "Neutral / insufficient elemental relation detected";

        const B12 = A.B12;
        const excessElems = B12._excessElements || [];
        const repeated = temporalElements.some(function (e) { return excessElems.indexOf(e) !== -1; });
        const usefulElement = getAuthoritativeUsefulElement();
        const determinationStatus = usefulElement.status;
        const isResolved = usefulElement.final;
        const yong = isResolved ? usefulElement.element : null;
        const xi = usefulElement.xi;
        const ji = usefulElement.ji;
        const yongMatch = isResolved && temporalElements.indexOf(yong) !== -1;
        const xiMatches = isResolved ? temporalElements.filter(function (e) { return xi.indexOf(e) !== -1; }) : [];
        const jiMatches = isResolved ? temporalElements.filter(function (e) { return ji.indexOf(e) !== -1; }) : [];

        const directional = supports.length && drainsOrControls.length ? "MIXED" : (supports.length ? "SUPPORT-SIDE INDICATOR" : (drainsOrControls.length ? "DRAIN/CONTROL-SIDE INDICATOR" : "NO CLEAR DIRECTION"));
        return {
            support: supportResult + ". Evidence: Da Yun Gan + Zhi + Hidden Stems; presence-based temporal screen only; natal strength basis=" + strengthBasis + ".",
            balance: supports.length && drainsOrControls.length ? "Mixed temporal influence — both support and drain/control evidence are present" : (supports.length ? "Temporal influence leans toward support" : (drainsOrControls.length ? "Temporal influence leans toward drain/control" : "No strong directional elemental relation detected")),
            dominant: directional + " — NOT a weighted temporal 旺衰 ranking",
            composition: "Da Yun Gan: " + dyStemElem + " / Zhi: " + (branchInfo ? branchInfo.element : "-") + " / Hidden Stems: " + (hidden.length ? hidden.map(function (h) { return h.element; }).join(", ") : "None") + " / Counts: " + Object.keys(temporalElementCounts).map(function (e) { return e + "=" + temporalElementCounts[e]; }).join(", "),
            repeated: repeated ? "Yes — temporal elements include an element marked as the natal B12 highest weighted element [structural indicator only]" : "No — no temporal element matches the natal B12 highest project weight",
            evidence: {
                temporalElements: temporalElements,
                temporalElementCounts: temporalElementCounts,
                natalInteractions: C2 || null,
                determinationStatus: determinationStatus,
                yongShen: { match: isResolved ? yongMatch : null, element: isResolved ? yong : null },
                xiShen: { matches: isResolved ? xiMatches : null },
                jiShen: { matches: isResolved ? jiMatches : null }
            }
        };
    }

    /* ============================================================
       C6 — TEMPORAL DETERMINATION
       ============================================================ */

    function buildC6(C4, C5) {
        // C6 consumes the authoritative B13 rule-resolution status directly.
        // No central engine blocker is used; unresolved/conflicting rule states are reported.
        const contract = global.masterResult && global.masterResult._determinationContract;
        const usefulElement = contract && contract.claims ? contract.claims["USEFUL_ELEMENT"] : null;
        const determinationStatus = usefulElement ? usefulElement.status : "NOT DETERMINED";
        // Contract fix: C6 is a FINAL_RULE_STATUS section, so expose the
        // machine-readable adjudication state explicitly instead of requiring
        // downstream consumers to parse prose fields.
        const ruleStatus = (determinationStatus === "RESOLVED" &&
            C4 && String(C4.chengGe || "").indexOf("PROVISIONAL") !== 0 &&
            C4 && String(C4.bianGe || "").indexOf("candidate") === -1)
            ? "RESOLVED"
            : (determinationStatus === "CONFLICT" ? "CONFLICT" :
               (determinationStatus === "MULTI_METHOD" ? "MULTI_METHOD" : "PROVISIONAL"));
        const finalYong = usefulElement && usefulElement.status === "FINAL" ? usefulElement.outcome : null;
        const xiJi = usefulElement && usefulElement.status === "FINAL"
            ? "FINAL — " + (finalYong || "Yong Shen adjudicated")
            : (determinationStatus === "CONFLICT" || determinationStatus === "MULTI_METHOD"
                ? "CONFLICT — method-specific Yong/Xi/Ji candidates are preserved"
                : (determinationStatus !== "RESOLVED" && determinationStatus !== "CANDIDATE"
                    ? "NOT DETERMINED — rule status: " + determinationStatus
                    : (C4.xiJiShen.indexOf("Xi") === 0 ? "Xi (喜) — configured favorable relation" :
                      (C4.xiJiShen.indexOf("Ji") === 0 ? "Ji (忌) — configured unfavorable relation" : "Neutral / Mixed relation"))));
        return {
            status: ruleStatus,
            xiJi: xiJi,
            chengGe: C4.chengGe,
            bianGe: C4.bianGe,
            overall: "Evidence: " + xiJi + "; Structural Effect: " + C5.support + "; Assessment: " + C4.shift + ". No deterministic life prediction is generated by Core C.",
            evidence: {
                evidence: C5.evidence || null,
                structuralEffect: C4,
                determinationStatus: determinationStatus,
                adjudication: usefulElement || null,
                assessment: "Derived temporal assessment; interpretation/NLG layer remains responsible for readable narrative."
            }
        };
    }

    /* ============================================================
       C7 — EVIDENCE & VERIFICATION
       ============================================================ */

    function buildC7(dyLabel, activeInfo, note) {
        // Contract fix: C7 is a PROVENANCE section. Every evidence row now
        // carries an explicit provenance class so downstream audit consumers do
        // not need to infer it from narrative text. No row claims independent
        // external verification unless such verification is actually present.
        return {
            row1: { status: "CALCULATED", evidence: "Active Da Yun identified: " + dyLabel, finding: "Derived from Da Yun transition timestamps and current date/time; period-membership check executed", source: "Da Yun transition timing + current date/time" },
            row2: { status: "CALCULATED", evidence: "Stem/Branch dynamics computed", finding: "Derived from the reference data; Tou Qing is only an elemental-alignment indicator", source: "Stem/Branch dynamics / reference data" },
            row3: { status: "RULE_SCREENED", evidence: "Combination/Conflict scan", finding: "Natal Hua status is carried from the established Transformation / Hua assessment; temporal He candidates remain separate and Hua status follows the defined rule layer", source: "Natal interactions / Transformation-Hua / defined rules" },
            row4: { status: "RULE_SCREENED", evidence: "Qi & Structural Response computed", finding: "Temporal rule response; Cheng Ge/Bian Ge remain provisional unless complete source-specific conditions are satisfied", source: "Qi & Structural Response / Day Master and Yong Shen determinations" },
            row5: { status: "RULE_SCREENED", evidence: "Temporal Balance & Determination", finding: "Yong/Xi/Ji relations use the established Yong Shen determination; conflicts and unresolved states are preserved explicitly", source: "Temporal Balance / Temporal Determination / Five Element Balance / Yong Shen determination" },
            provenance: { independentVerification: "NOT_PERFORMED", note: "No external independent verification is claimed by Core C7." }
        };
    }

    /* ============================================================
       EXEC_C0 — TEMPORAL INPUT RESOLUTION
       Execution node only; it is not a template field.
       ============================================================ */
    function resolveTemporalInput(A, now) {
        const found = findActiveDaYun(A.A14_2, now);
        const activePillar = found.active.pillar;
        return {
            activeInfo: found,
            activePillar: activePillar,
            dyLabel: "Da Yun #" + found.active.no + " (" + activePillar.ganZhi + ", age " + activePillar.startAge + "–" + activePillar.endAge + ")",
            dyStemHanzi: activePillar._stemHanzi,
            dyBranchHanzi: activePillar._branchHanzi,
            liuNian: getLiuNian(now),
            asOf: now.toISOString()
        };
    }

    /* ============================================================
       MAIN ENTRY POINT
       ============================================================ */

    const PenggilasCoreC = {
        version: CORE_C_VERSION,

        calculate: function (asOfInput) {
            requireGlobals();

            if (asOfInput === undefined || asOfInput === null || asOfInput === "") {
                throw new Error("[PenggilasCoreC] Explicit temporal asOf timestamp is required.");
            }

            const A = global.masterResult;
            const rulePlan = RULE_CONTRACT.prepare("C", A);
            const requireRule = function (key) { return RULE_CONTRACT.requireRule(rulePlan, key); };
            const cache = global.PENGGILAS_RAW_CHART;
            const raw = cache.raw;
            const dmHanzi = raw.day.ganHanzi;

            const now = asOfInput instanceof Date
                ? new Date(asOfInput.getTime())
                : new Date(asOfInput);

            if (Number.isNaN(now.getTime())) {
                throw new Error("[PenggilasCoreC] Invalid temporal asOf timestamp.");
            }

            const temporalInput = resolveTemporalInput(A, now);
            const nodeValues = { "EXEC_C0": temporalInput };
            requireRule("C1");
            nodeValues["EXEC_C1"] = buildC1(temporalInput.dyStemHanzi, temporalInput.dyBranchHanzi, cache.dayMasterElem, dmHanzi, A, temporalInput.dyLabel);
            requireRule("C2");
            nodeValues["EXEC_C2"] = buildC2(temporalInput.dyStemHanzi, temporalInput.dyBranchHanzi, raw, A.A12_7);
            requireRule("C3");
            nodeValues["EXEC_C3"] = buildC3(temporalInput.dyStemHanzi, temporalInput.dyBranchHanzi, cache.dayMasterElem, A, cache);
            requireRule("C4");
            nodeValues["EXEC_C4"] = buildC4(temporalInput.dyStemHanzi, temporalInput.dyBranchHanzi, A, cache, nodeValues["EXEC_C2"]);
            requireRule("C5");
            nodeValues["EXEC_C5"] = buildC5(temporalInput.dyStemHanzi, temporalInput.dyBranchHanzi, A, cache, nodeValues["EXEC_C2"]);
            requireRule("C6");
            nodeValues["EXEC_C6"] = buildC6(nodeValues["EXEC_C4"], nodeValues["EXEC_C5"]);
            requireRule("C7");
            nodeValues["EXEC_C7"] = buildC7(temporalInput.dyLabel, temporalInput.activeInfo, temporalInput.activeInfo.note);
            const nodeDeps = {
                "EXEC_C0": [],
                "EXEC_C1": ["EXEC_C0"],
                "EXEC_C2": ["EXEC_C1"],
                "EXEC_C3": ["EXEC_C2"],
                "EXEC_C4": ["EXEC_C2","EXEC_C3"],
                "EXEC_C5": ["EXEC_C2","EXEC_C3"],
                "EXEC_C6": ["EXEC_C4","EXEC_C5"],
                "EXEC_C7": ["EXEC_C6"]
            };
            const nodeOrder = ["EXEC_C0","EXEC_C1","EXEC_C2","EXEC_C3","EXEC_C4","EXEC_C5","EXEC_C6","EXEC_C7"];
            const nodeDone = new Set();
            nodeOrder.forEach(function(id){
                const deps=(nodeDeps[id]||[]).filter(function(d){return !nodeDone.has(d);});
                if(deps.length) throw new Error("[PenggilasCoreC] Node dependency violation "+id+" <- "+deps.join(","));
                nodeDone.add(id);
            });
            const temporalMaster = {
                C1: nodeValues["EXEC_C1"], C2: nodeValues["EXEC_C2"], C3: nodeValues["EXEC_C3"], C4: nodeValues["EXEC_C4"],
                C5: nodeValues["EXEC_C5"], C6: nodeValues["EXEC_C6"], C7: nodeValues["EXEC_C7"],
                _nodeExecution: { layer: "NODE", nodes: nodeOrder, dependencies: nodeDeps, fields: "C1..C7", temporalInput: temporalInput },
                _rulePlan: rulePlan
            };
            const liuNian = temporalInput.liuNian;
            const liuNianStemInfo = BAZI_DATA.getStemByHanzi(liuNian.ganHanzi);
            const liuNianBranchInfo = BAZI_DATA.getBranchByHanzi(liuNian.zhiHanzi);
            temporalMaster.C1.stemDynamics += ". Current Liu Nian (solar-term year): " +
                (liuNianStemInfo ? liuNianStemInfo.pinyin : "?") + " " + (liuNianBranchInfo ? liuNianBranchInfo.pinyin : "?") +
                " (" + liuNian.ganHanzi + liuNian.zhiHanzi + ")";

            // Post-execution audit trace: the authoritative C rule contract was already consumed
            // by the rule registry before C1–C7. This trace records the result/evidence state.
            if (RULE_EVALUATOR) {
                const trace = RULE_EVALUATOR.evaluate(global.masterResult, temporalMaster).sectionCoverage;
                temporalMaster._ruleTrace = Object.assign({}, (global.masterResult && global.masterResult._ruleTrace) || {});
                Object.keys(trace).filter(function (k) { return /^C/.test(k); }).forEach(function (k) {
                    temporalMaster._ruleTrace[k] = trace[k];
                });
            }

            temporalMaster._engineExecution = temporalMaster._nodeExecution;
            temporalMaster._ruleExecution = { section: "C", status: rulePlan.status, authoritativeRuleKeys: rulePlan.authoritativeRuleKeys.slice() };

            global.masterResult = global.masterResult || {};
            Object.assign(global.masterResult, temporalMaster);
            global.masterResult._engineExecution = temporalMaster._engineExecution;

            // Refresh the existing read-only execution evidence signature after
            // C1–C7 exists. Determination creates the first signature before C;
            // this re-binds the same masterResult and does not recalculate BaZi.
            if (global.PENGGILAS_CLASSICAL_EXECUTION_SIGNATURE && global.masterResult._determinationContract) {
                global.masterResult._determinationContract.executionEvidenceSignature =
                    global.PENGGILAS_CLASSICAL_EXECUTION_SIGNATURE.bindAll(global.masterResult);
            }

            console.log("[PenggilasCoreC] Temporal Master (C1–C7) selesai dihitung — " + temporalInput.dyLabel);
            return temporalMaster;
        }
    };

    global.PenggilasCoreC = PenggilasCoreC;

})(window);
