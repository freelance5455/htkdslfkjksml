fn main(){let(mut hp,mut s,mut a,mut p)=(100,0,5,2);while hp>0{hp-=50;s+=1}while p>0&&a<14{a+=1;p-=1}let n=std::cmp::min(30,90);println!("shots={} alive={} mag={} res={}",s,a,n,90-n);}
