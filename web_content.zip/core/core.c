#include <stdio.h>
int main(){int hp=100,s=0;while(hp>0){hp-=50;s++;}int a=5,p=2;while(p>0&&a<14){a++;p--;}int n=30<90?30:90;printf("shots=%d alive=%d mag=%d res=%d\n",s,a,n,90-n);}
