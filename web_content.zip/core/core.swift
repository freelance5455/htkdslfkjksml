var hp=100,s=0;while hp>0{hp-=50;s+=1};var a=5,p=2;while p>0&&a<14{a+=1;p-=1};let n=min(30,90);print("shots=\(s) alive=\(a) mag=\(n) res=\(90-n)")
