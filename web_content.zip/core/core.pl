my($hp,$s,$a,$p)=(100,0,5,2);while($hp>0){$hp-=50;$s++}while($p>0&&$a<14){$a++;$p--}my $n=30<90?30:90;print "shots=$s alive=$a mag=$n res=",90-$n,"\n";
