hp=100;s=0;while hp>0 do hp-=50;s+=1 end
a=5;p=2;while p>0&&a<14 do a+=1;p-=1 end
n=[30,90].min;puts "shots=#{s} alive=#{a} mag=#{n} res=#{90-n}"
