let hp=100,s=0;while(hp>0){hp-=50;s++}let a=5,p=2;while(p>0&&a<14){a++;p--}const n=Math.min(30,90);console.log(`shots=${s} alive=${a} mag=${n} res=${90-n}`);
