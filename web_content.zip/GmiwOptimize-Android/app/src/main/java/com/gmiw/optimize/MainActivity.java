package com.gmiw.optimize;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(8, 8, 10));
        w.setNavigationBarColor(Color.rgb(8, 8, 10));
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON == 0 ? 0 : 0);

        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8, 8, 10));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        super.onBackPressed();
    }
}
