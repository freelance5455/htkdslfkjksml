GMIW OPTIMIZE - Android Studio project (prototype)
=================================================

Target: Android 8.0+ (minSdk 26), RAM 3 GB+ as intended device class.
Game focus: Free Fire.
Package: com.gmiw.optimize

PENTING:
- Ini adalah prototype UI Android dengan pengaturan lokal yang tersimpan.
- Belum merupakan APK siap-install.
- FPS Unlock tidak mem-bypass pembatasan FPS Free Fire/perangkat.
- RAM/GPU boost, touch sensitivity, refresh rate, dan anti-frame-drop tidak
  dapat dijamin oleh aplikasi biasa tanpa API/izin khusus dari produsen atau game.
- Tidak ada klaim anti-ban atau jaminan FPS.

Cara membuat APK:
1. Install Android Studio versi terbaru.
2. Buka folder GmiwOptimize sebagai project.
3. Tunggu Gradle Sync dan install Android SDK Platform 35 jika diminta.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.

Untuk APK rilis, gunakan Build > Generate Signed Bundle / APK dan buat keystore
milik sendiri. Jangan bagikan keystore atau password.
