WIFI SCANNER ANDROID — SOURCE PROJECT
=====================================

What this project is
- An Android app with a modern HTML/WebView interface.
- It probes addresses on the phone's current Wi-Fi subnet.
- It attempts to read the Android ARP cache for MAC addresses.
- It does not upload scan results to a server.

Important limitations
- This is a best-effort LAN discovery tool, not a guaranteed complete router client list.
- Android versions and phone manufacturers may restrict subnet details or /proc/net/arp.
- Many devices ignore reachability probes, so they may not appear.
- MAC addresses can be missing. Android does not generally allow an ordinary app to read the phone's Wi-Fi MAC address.
- For the authoritative connected-device list, use your router's app/admin page.
- Only scan networks you own or have permission to test.

Build notes
- Open this folder in Android Studio on a computer, sync Gradle, then Build > Build APK(s).
- Android Studio/Gradle may need an internet connection to download the Android Gradle Plugin and SDK components the first time.
- This ZIP contains project source, not a compiled APK.
- The app uses Android WebView and Java. It targets API 28 to avoid forcing newer permission prompts, but modern Android may still limit network discovery.

Files
- app/src/main/assets/index.html: UI
- app/src/main/java/com/example/wifiscanner/MainActivity.java: native scanner bridge
- app/src/main/AndroidManifest.xml: app permissions/config
