package com.example.wifiscanner;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiInfo;
import android.content.Context;
import android.text.format.Formatter;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService scanner = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidScanner");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface
        public void scanNetwork() {
            scanner.execute(() -> {
                JSONObject result = scanLocalSubnet();
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onNativeScanResults(" + result.toString() + ")", null));
            });
        }
    }

    private JSONObject scanLocalSubnet() {
        JSONObject out = new JSONObject();
        JSONArray devices = new JSONArray();
        String localIp = "";
        String subnet = "";
        int found = 0;
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null || !wm.isWifiEnabled()) {
                out.put("ok", false);
                out.put("message", "Wi‑Fi is off. Connect to your Wi‑Fi network and try again.");
                out.put("devices", devices);
                return out;
            }

            // Android can restrict details in newer versions. This works on many, but not all, devices.
            android.net.DhcpInfo dhcp = wm.getDhcpInfo();
            if (dhcp == null || dhcp.ipAddress == 0 || dhcp.netmask == 0) {
                out.put("ok", false);
                out.put("message", "Android did not provide the local subnet. Check Wi‑Fi and retry.");
                out.put("devices", devices);
                return out;
            }

            localIp = intToIp(dhcp.ipAddress);
            int mask = dhcp.netmask;
            int network = dhcp.ipAddress & mask;
            int broadcast = network | ~mask;
            long hosts = (broadcast & 0xffffffffL) - (network & 0xffffffffL) - 1;
            if (hosts < 1 || hosts > 1022) {
                out.put("ok", false);
                out.put("message", "This network has an unsupported subnet size (" + hosts + " possible hosts).");
                out.put("devices", devices);
                return out;
            }

            // Include the phone itself.
            JSONObject self = new JSONObject();
            self.put("ip", localIp);
            self.put("mac", "Unavailable to this app");
            self.put("name", "This phone");
            self.put("kind", "Local device");
            self.put("self", true);
            devices.put(self);

            // Probe other addresses concurrently. Some devices/firewalls ignore these probes.
            ExecutorService pool = Executors.newFixedThreadPool(32);
            AtomicInteger active = new AtomicInteger(0);
            for (int i = 1; i <= hosts; i++) {
                final int candidate = network + i;
                final String ip = intToIp(candidate);
                if (ip.equals(localIp)) continue;
                pool.submit(() -> {
                    try {
                        InetAddress address = InetAddress.getByName(ip);
                        if (address.isReachable(650)) {
                            active.incrementAndGet();
                            JSONObject d = new JSONObject();
                            d.put("ip", ip);
                            d.put("mac", "Checking ARP cache…");
                            d.put("name", "Network device");
                            d.put("kind", "Responded to reachability probe");
                            d.put("self", false);
                            synchronized (devices) { devices.put(d); }
                        }
                    } catch (Exception ignored) { }
                });
            }
            pool.shutdown();
            pool.awaitTermination(18, TimeUnit.SECONDS);

            // Read ARP cache if Android exposes it. This is best-effort and may be blocked.
            try (BufferedReader br = new BufferedReader(new FileReader("/proc/net/arp"))) {
                String line;
                br.readLine();
                while ((line = br.readLine()) != null) {
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length >= 4 && parts[0].matches("\\\\d+\\\\.\\\\d+\\\\.\\\\d+\\\\.\\\\d+")) {
                        String ip = parts[0], mac = parts[3];
                        if (mac.matches("(?i)[0-9a-f]{2}(:[0-9a-f]{2}){5}") && !mac.equals("00:00:00:00:00:00")) {
                            for (int j = 0; j < devices.length(); j++) {
                                JSONObject d = devices.optJSONObject(j);
                                if (d != null && ip.equals(d.optString("ip"))) d.put("mac", mac.toUpperCase());
                            }
                        }
                    }
                }
            } catch (Exception ignored) { }

            found = devices.length();
            out.put("ok", true);
            out.put("message", "Scan finished. Results depend on device and router restrictions.");
            out.put("localIp", localIp);
            out.put("subnet", intToIp(network) + " / " + Integer.bitCount(mask));
            out.put("devices", devices);
            out.put("count", found);
            return out;
        } catch (Exception e) {
            try {
                out.put("ok", false);
                out.put("message", "Scan failed: " + e.getClass().getSimpleName());
                out.put("devices", devices);
            } catch (Exception ignored) { }
            return out;
        }
    }

    private static String intToIp(int value) {
        return (value & 0xff) + "." + ((value >> 8) & 0xff) + "." + ((value >> 16) & 0xff) + "." + ((value >> 24) & 0xff);
    }

    @Override
    protected void onDestroy() {
        scanner.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
