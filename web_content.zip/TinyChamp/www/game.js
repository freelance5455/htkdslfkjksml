const worlds = [
 {id:0,name:"Animal Safari",emoji:"🦁",desc:"Meet friendly animal pals",color:"#c6f3d8"},
 {id:1,name:"Number Planet",emoji:"🚀",desc:"Count, spot and explore",color:"#ffedaa"},
 {id:2,name:"Alphabet Adventure",emoji:"🔤",desc:"Letters are everywhere",color:"#d9d0ff"},
 {id:3,name:"Puzzle Paradise",emoji:"🧩",desc:"Shapes and clever matches",color:"#ffcce3"},
 {id:4,name:"Ocean Explorer",emoji:"🐬",desc:"Dive into a blue world",color:"#bdeaff"},
 {id:5,name:"Magic Kingdom",emoji:"🏰",desc:"A kingdom of surprises",color:"#e8d0ff"}
];
const animals=[["🐶","Dog"],["🐱","Cat"],["🐮","Cow"],["🐸","Frog"],["🐵","Monkey"],["🐘","Elephant"],["🦁","Lion"],["🐰","Rabbit"],["🐼","Panda"],["🦒","Giraffe"],["🐻","Bear"],["🐧","Penguin"]];
const letters=[["🍎","A"],["⚽","B"],["🐱","C"],["🐶","D"],["🥚","E"],["🐟","F"],["🍇","G"],["🏠","H"],["🍦","I"],["🧃","J"],["🪁","K"],["🦁","L"],["🌙","M"],["🥜","N"],["🐙","O"],["🐼","P"],["👑","Q"],["🌈","R"],["⭐","S"],["🐢","T"],["☂️","U"],["🎻","V"],["🍉","W"],["❌","X"],["🧶","Y"],["🦓","Z"]];
const shapes=[["🔴","Circle"],["🟦","Square"],["🔺","Triangle"],["⭐","Star"],["❤️","Heart"],["⬭","Oval"]];
const sea=[["🐠","Fish"],["🐬","Dolphin"],["🐢","Turtle"],["🦀","Crab"],["🐙","Octopus"],["🦈","Shark"],["🐳","Whale"],["🪼","Jellyfish"]];
const magic=[["🪄","Magic wand"],["👑","Crown"],["🦄","Unicorn"],["🏰","Castle"],["💎","Gem"],["🧚","Fairy"],["🐉","Dragon"],["🌟","Magic star"]];
let state={stars:0,done:[],world:null,level:null,question:null,age:"3-5",sound:true};
const saved=JSON.parse(localStorage.getItem("tinyChampSave")||"null");
if(saved) state={...state,...saved};
const app=document.querySelector("#app");
const save=()=>{localStorage.setItem("tinyChampSave",JSON.stringify({stars:state.stars,done:state.done,age:state.age,sound:state.sound}));document.querySelector("#starCount").textContent=state.stars};
const speak=(txt)=>{if(!state.sound||!("speechSynthesis" in window))return; speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(txt);u.rate=.85;u.pitch=1.15;speechSynthesis.speak(u)};
function beep(ok=true){if(!state.sound)return;try{let c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.frequency.value=ok?660:190;g.gain.setValueAtTime(.08,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.22);o.start();o.stop(c.currentTime+.22)}catch(e){}}
function toast(t){let el=document.querySelector("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),1600)}
function completed(id,l){return state.done.includes(id*100+l)}
function worldCount(id){return Array.from({length:worlds[id].count||17},(_,i)=>i+1).filter(l=>completed(id,l)).length}
worlds.forEach((w,i)=>w.count=i<4?17:16);
function home(){
 state.world=null;state.level=null;
 app.innerHTML=`<section class="hero"><div class="mascot">🐼</div><h1>Hey, Tiny Champ!</h1><p>Ready for a happy little adventure?</p><button class="primary" id="explore">LET'S PLAY! ⭐</button></section><h2 class="section-title">🌈 Pick your adventure</h2><div class="world-grid">${worlds.map(w=>`<button class="world-card" data-world="${w.id}"><span class="emoji">${w.emoji}</span><strong>${w.name}</strong><small>${state.done.filter(x=>Math.floor(x/100)===w.id).length}/${w.count} levels</small></button>`).join("")}</div>`;
 document.querySelector("#explore").onclick=()=>document.querySelector(".world-grid").scrollIntoView({behavior:"smooth"});
 document.querySelectorAll("[data-world]").forEach(b=>b.onclick=()=>levels(+b.dataset.world));
 save();
}
function levels(id){
 state.world=id;let w=worlds[id],count=w.count;
 app.innerHTML=`<div class="back-row"><button class="back" id="back">← Home</button><h2>${w.emoji} ${w.name}</h2></div><div class="panel"><div style="font-size:62px">${w.emoji}</div><h2>${w.desc}</h2><p>Choose a level and let's have fun!</p><div class="progress"><span style="width:${state.done.filter(x=>Math.floor(x/100)===id).length/count*100}%"></span></div><div class="level-grid">${Array.from({length:count},(_,i)=>{let n=i+1,unlocked=n===1||completed(id,n-1);return `<button class="level ${completed(id,n)?"done":""} ${unlocked?"":"locked"}" data-level="${n}" ${unlocked?"":"disabled"}>${completed(id,n)?"⭐":unlocked?n:"🔒"}</button>`}).join("")}</div></div>`;
 document.querySelector("#back").onclick=home;
 document.querySelectorAll("[data-level]").forEach(b=>b.onclick=()=>startLevel(id,+b.dataset.level));
}
function pick(arr,exclude){let opts=arr.filter(x=>x[1]!==exclude);return opts[Math.floor(Math.random()*opts.length)]}
function makeQuestion(id,l){
 let data,answer,emoji,prompt,options;
 if(id===0){data=animals;let item=data[(l-1)%data.length];answer=item[1];emoji=item[0];prompt=`Which animal is this?`;options=[answer,pick(data,answer)[1],pick(data,answer)[1],pick(data,answer)[1]]}
 if(id===1){let n=(l%8)+1;answer=String(n);emoji=["🍓","⭐","🦋","🍪","🐥","🍎","🎈","🐠","🌼"][n];prompt=`How many ${emoji} do you see?`;emoji=Array(n).fill(emoji).join(" ");options=[String(n),String(n+1),String(Math.max(1,n-1)),String(n+2)]}
 if(id===2){data=letters;let item=data[(l-1)%data.length];answer=item[1];emoji=item[0];prompt=`Which letter does this picture start with?`;options=[answer,...[pick(data,answer)[1],pick(data,answer)[1],pick(data,answer)[1]]]}
 if(id===3){data=shapes;let item=data[(l-1)%data.length];answer=item[1];emoji=item[0];prompt=`What shape is this?`;options=[answer,...[pick(data,answer)[1],pick(data,answer)[1],pick(data,answer)[1]]]}
 if(id===4){data=sea;let item=data[(l-1)%data.length];answer=item[1];emoji=item[0];prompt=`Who is swimming here?`;options=[answer,...[pick(data,answer)[1],pick(data,answer)[1],pick(data,answer)[1]]]}
 if(id===5){data=magic;let item=data[(l-1)%data.length];answer=item[1];emoji=item[0];prompt=`What magical thing can you see?`;options=[answer,...[pick(data,answer)[1],pick(data,answer)[1],pick(data,answer)[1]]]}
 options=[...new Set(options)];while(options.length<4)options.push(pick(id===2?letters:id===3?shapes:id===4?sea:id===5?magic:animals,answer)[1]);options.sort(()=>Math.random()-.5);
 return {answer,emoji,prompt,options};
}
function startLevel(id,l){state.world=id;state.level=l;state.question=makeQuestion(id,l);renderQuestion()}
function renderQuestion(){
 let q=state.question;
 app.innerHTML=`<div class="back-row"><button class="back" id="quit">← Levels</button><strong>${worlds[state.world].emoji} Level ${state.level}</strong><span style="margin-left:auto">⭐ ${state.stars}</span></div><div class="panel"><div class="progress"><span style="width:${(state.level/worlds[state.world].count)*100}%"></span></div><div class="question-emoji">${q.emoji}</div><div class="question">${q.prompt}</div><div class="choices">${q.options.map((o,i)=>`<button class="choice" data-answer="${o}">${o}</button>`).join("")}</div><div class="feedback" id="feedback">You can do it! 🌟</div></div>`;
 document.querySelector("#quit").onclick=()=>levels(state.world);
 document.querySelectorAll("[data-answer]").forEach(b=>b.onclick=()=>answer(b.dataset.answer,b));
 speak(q.prompt);
}
function answer(value,btn){
 if(document.querySelector(".choice:disabled"))return;
 if(value===state.question.answer){
  document.querySelectorAll(".choice").forEach(b=>{b.disabled=true;if(b.dataset.answer===value)b.classList.add("correct")});
  beep(true);state.stars+=1;let key=state.world*100+state.level;if(!state.done.includes(key))state.done.push(key);save();
  document.querySelector("#feedback").textContent=["Brilliant! ⭐","You did it! 🎉","Super champ! 🌈","Wonderful work! 🏆"][Math.floor(Math.random()*4)];
  speak("Amazing! You did it!");
  setTimeout(()=>successScreen(),900);
 }else{
  btn.classList.add("wrong");beep(false);document.querySelector("#feedback").textContent="Good try! Have another go 💛";speak("Good try. Have another go.");
  setTimeout(()=>btn.classList.remove("wrong"),500);
 }
}
function successScreen(){
 let last=state.level===worlds[state.world].count;
 app.innerHTML=`<div class="panel"><div class="reward">🏆</div><h1>SUPER CHAMP!</h1><p class="question">You earned a star!</p><div style="font-size:48px">⭐ 🎉 ⭐</div><p>${last?"You finished this whole world! Amazing!":"Ready for another little challenge?"}</p><button class="primary" id="next">${last?"BACK TO WORLDS":"NEXT LEVEL ➜"}</button><p><button class="back" id="levels">See all levels</button></p></div>`;
 document.querySelector("#next").onclick=()=>last?home():startLevel(state.world,state.level+1);
 document.querySelector("#levels").onclick=()=>levels(state.world);
}
function parentArea(){
 let a=Math.floor(Math.random()*5)+2,b=Math.floor(Math.random()*5)+1,answer=a+b;
 app.innerHTML=`<div class="back-row"><button class="back" id="back">← Back</button><h2>Grown-up corner</h2></div><div class="panel"><div style="font-size:55px">🧑‍🧑‍🧒</div><h2>Ask a grown-up to help</h2><p>To open this area, solve: ${a} + ${b} = ?</p><div class="choices">${[answer,answer+1,Math.max(1,answer-1)].sort(()=>Math.random()-.5).map(n=>`<button class="choice" data-parent="${n}">${n}</button>`).join("")}</div><div id="parentContent"></div></div>`;
 document.querySelector("#back").onclick=home;
 document.querySelectorAll("[data-parent]").forEach(btn=>btn.onclick=()=>{if(+btn.dataset.parent!==answer){toast("Try again with a grown-up");return}
 document.querySelector("#parentContent").innerHTML=`<div class="toggle-row"><span>Sound effects</span><button class="back" id="sound">${state.sound?"ON 🔊":"OFF 🔇"}</button></div><div class="toggle-row"><span>Age group</span><select id="age"><option ${state.age==="3-5"?"selected":""}>3-5</option><option ${state.age==="6-8"?"selected":""}>6-8</option></select></div><p class="parent-note">Tiny Champ stores game progress only on this device. It has no ads, chat, account sign-in or in-app purchases. Please supervise play and take breaks.</p><button class="secondary" id="reset">Reset game progress</button><p class="parent-note">Privacy: no personal information is requested by this starter game. Review the final app and privacy disclosures before publishing.</p>`;
 document.querySelector("#sound").onclick=()=>{state.sound=!state.sound;save();parentArea()};
 document.querySelector("#age").onchange=e=>{state.age=e.target.value;save();toast("Age setting saved")};
 document.querySelector("#reset").onclick=()=>{if(confirm("Reset all stars and completed levels on this device?")){state.stars=0;state.done=[];save();parentArea();toast("Progress reset")}};
 });
}
document.querySelector("#parentBtn").onclick=parentArea;
document.querySelector("#homeBtn").onclick=home;
home();
