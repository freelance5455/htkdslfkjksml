POKEMON HUMAN ENCYCLOPEDIA V2 — STARTER

Isi:
- index.html: aplikasi ensiklopedia offline.
- images/: folder untuk file portrait karakter.

CATATAN PENTING:
Paket ini BELUM menyertakan foto/portrait asli. Gambar hanya akan tampil jika
kamu menambahkan file JPG sendiri ke folder images dengan nama file berikut:
Ash Ketchum -> ash-ketchum.jpg
Misty -> misty.jpg
Professor Oak -> professor-oak.jpg

Database berisi karakter starter dan belum mencakup seluruh karakter Pokémon.
Untuk membuat APK, impor ZIP ini ke HTML-to-APK Builder yang kamu pakai.
Pastikan folder images ikut terpaket setelah aset gambar ditambahkan.
