import { jsxDEV } from "react/jsx-dev-runtime";
function Footer({ lang, t }) {
  return /* @__PURE__ */ jsxDEV("footer", { className: "footer", dir: lang === "fa" ? "rtl" : "ltr", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "footer-grid", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { children: t.footerAddress }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 217
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "foot-icon", children: "\u2316" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1,
            columnNumber: 246
          }, this),
          t.address
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 243
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 212
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { children: t.footerPhone }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 308
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "foot-icon", children: "\u260E" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1,
            columnNumber: 335
          }, this),
          t.phone
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 332
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 303
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { children: t.footerEmail }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 395
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "foot-icon", children: "\u2709" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1,
            columnNumber: 422
          }, this),
          t.emailText
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 419
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 390
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { children: t.footerHours }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 486
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "foot-icon", children: "\u25F7" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1,
            columnNumber: 513
          }, this),
          t.hours
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 1,
          columnNumber: 510
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1,
        columnNumber: 481
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 1,
      columnNumber: 183
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "footer-note", children: t.videoNote }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 1,
      columnNumber: 574
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "copyright", children: t.copyright }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 1,
      columnNumber: 618
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 1,
    columnNumber: 126
  }, this);
}
export {
  Footer as default
};
