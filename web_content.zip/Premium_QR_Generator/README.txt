Premium QR Generator — starter project

- index.html: single amount field; fixed UPI ID is set in one line in the script.
- Configured ID: 9783097192@nyes (space removed from the value provided by user).
- UPI ID validity has NOT been verified. Confirm the exact ID in the receiving UPI app and test the QR before use.
- QR library is loaded from a CDN, so internet access is needed.
- This is a web starter project, NOT a compiled Android APK.
- A QR does not prove payment was received; check the bank/UPI app.
- Fixed ID in client-side code is not tamper-proof and can be discovered by inspecting the code.
