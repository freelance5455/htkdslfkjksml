document.addEventListener('DOMContentLoaded', () => {

    // AUDIO SYNTHESIZER FOR MECHANICAL KEYBOARD CLICK SOUND
    let audioCtx = null;

    function playMechanicalSound() {
        try {
            if (!audioCtx) {
                audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            }
            if (audioCtx.state === 'suspended') {
                audioCtx.resume();
            }

            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();

            // Mechanical switch thock / click frequency profile
            osc.type = 'sine';
            osc.frequency.setValueAtTime(600, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(120, audioCtx.currentTime + 0.04);

            gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.04);

            osc.connect(gain);
            gain.connect(audioCtx.destination);

            osc.start();
            osc.stop(audioCtx.currentTime + 0.04);
        } catch(e) {}
    }

    // ATTACH MECHANICAL SOUND TO ALL CLICKABLE ELEMENTS & SOUND-CLICK CLASS
    document.addEventListener('click', (e) => {
        const target = e.target.closest('button, .glass-btn, .mini-glass-btn, .feature-btn, .segment-btn, .tab-btn, .game-card, li, .theme-select-btn, .sound-click');
        if (target) {
            playMechanicalSound();
        }
    });

    // LOGIN LOGIC
    const loginBtn = document.getElementById('login-btn');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginError = document.getElementById('login-error');
    const loginScreen = document.getElementById('login-screen');
    const appScreen = document.getElementById('app-screen');

    loginBtn.addEventListener('click', () => {
        const u = usernameInput.value.trim();
        const p = passwordInput.value.trim();

        if (u === 'apisss' && p === 'apisss15') {
            loginScreen.classList.remove('active');
            appScreen.classList.add('active');
            showToast('Login Berhasil! Selamat datang Apisss');
        } else {
            loginError.textContent = 'Username atau Password salah!';
        }
    });

    // SIDEBAR TOGGLE
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    const closeSidebar = document.getElementById('close-sidebar');

    function toggleSidebar() {
        sidebar.classList.toggle('open');
        sidebarOverlay.classList.toggle('active');
    }

    menuToggle.addEventListener('click', toggleSidebar);
    closeSidebar.addEventListener('click', toggleSidebar);
    sidebarOverlay.addEventListener('click', toggleSidebar);

    // LOGOUT LOGIC
    function performLogout() {
        appScreen.classList.remove('active');
        loginScreen.classList.add('active');
        usernameInput.value = 'apisss';
        passwordInput.value = '';
        showToast('Berhasil Logout');
    }

    document.getElementById('logout-btn').addEventListener('click', () => { toggleSidebar(); performLogout(); });
    document.getElementById('logout-top-btn').addEventListener('click', performLogout);
    document.getElementById('btn-logout-action').addEventListener('click', performLogout);

    // PROFILE PHOTO / BANNER CHANGE
    const avatarInput = document.getElementById('avatar-input');
    const bannerImg = document.getElementById('banner-img');

    function triggerPhotoUpload() {
        avatarInput.click();
    }

    document.getElementById('ganti-foto-top-btn').addEventListener('click', triggerPhotoUpload);
    document.getElementById('ganti-foto-menu-btn').addEventListener('click', () => { toggleSidebar(); triggerPhotoUpload(); });
    document.getElementById('btn-ganti-foto-action').addEventListener('click', triggerPhotoUpload);

    avatarInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                bannerImg.src = event.target.result;
                showToast('Foto Banner Berhasil Diganti!');
            };
            reader.readAsDataURL(file);
        }
    });

    // DEVELOPER MODAL
    const devModal = document.getElementById('developer-modal');
    function openDevModal() {
        devModal.classList.add('active');
    }

    document.getElementById('dev-modal-btn').addEventListener('click', openDevModal);
    document.getElementById('dev-menu-btn').addEventListener('click', () => { toggleSidebar(); openDevModal(); });
    document.getElementById('btn-developer-action').addEventListener('click', openDevModal);

    // THEME SWITCHER SYSTEM (3 THEMES)
    window.setAppTheme = function(theme) {
        document.body.className = '';
        if (theme === 'glass-white') {
            document.body.classList.add('theme-glass-white');
            showToast('Tema diubah ke: Liquid Glass White');
        } else if (theme === 'retro') {
            document.body.classList.add('theme-retro');
            showToast('Tema diubah ke: Retro Cyber Grid');
        } else {
            document.body.classList.add('theme-glass-black');
            showToast('Tema diubah ke: Liquid Glass Black');
        }
        document.getElementById('theme-modal').classList.remove('active');
    };

    // SLIDE TABS (3 SLIDES)
    const tabBtns = document.querySelectorAll('.tab-btn');
    const slides = document.querySelectorAll('.slide');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const index = btn.getAttribute('data-slide');
            tabBtns.forEach(b => b.classList.remove('active'));
            slides.forEach(s => s.classList.remove('active'));
            btn.classList.add('active');
            slides[index].classList.add('active');
        });
    });

    // PILIH TUJUAN (NOMOR / GRUP)
    const segmentBtns = document.querySelectorAll('.segment-btn');
    segmentBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            segmentBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            showToast(`Tujuan dipilih: ${btn.textContent}`);
        });
    });

    // FEATURE BUG TOGGLES (EXACT 8 REQUESTED FEATURES)
    const featureBtns = document.querySelectorAll('.feature-btn');
    featureBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            btn.classList.toggle('active');
            const featName = btn.getAttribute('data-feature');
            if (btn.classList.contains('active')) {
                showToast(`Fitur [${featName}] Aktif!`);
            } else {
                showToast(`Fitur [${featName}] Non-Aktif`);
            }
        });
    });

    // BUTTON MULAI
    document.getElementById('btn-mulai').addEventListener('click', () => {
        const targetNum = document.getElementById('target-number').value.trim();
        const activeSegment = document.querySelector('.segment-btn.active').textContent;

        if (!targetNum) {
            showToast('Harap isi Target Number!');
            return;
        }

        showToast(`Memproses ${activeSegment}: ${targetNum}...`);
    });

    // GLOBAL CHAT SYSTEM (SLIDE 3)
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const sendChatBtn = document.getElementById('send-chat-btn');

    function sendChatMessage() {
        const text = chatInput.value.trim();
        if (!text) return;

        const msgDiv = document.createElement('div');
        msgDiv.className = 'chat-msg self';
        msgDiv.innerHTML = `<span class="sender">Apisss (Anda)</span><p>${escapeHtml(text)}</p>`;
        chatMessages.appendChild(msgDiv);
        chatInput.value = '';
        chatMessages.scrollTop = chatMessages.scrollHeight;
        showToast('Pesan terkirim ke Global Chat');

        setTimeout(() => {
            const replyDiv = document.createElement('div');
            replyDiv.className = 'chat-msg';
            replyDiv.innerHTML = `<span class="sender">User_Global99</span><p>Mantap bro, panelnya work banget!</p>`;
            chatMessages.appendChild(replyDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 1500);
    }

    sendChatBtn.addEventListener('click', sendChatMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendChatMessage();
    });

    function escapeHtml(str) {
        return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    // MODALS CLOSE GENERAL
    const modals = document.querySelectorAll('.modal');
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            modals.forEach(m => m.classList.remove('active'));
        });
    });

    document.querySelectorAll('.sidebar-menu li[data-modal]').forEach(item => {
        item.addEventListener('click', () => {
            toggleSidebar();
            const mId = item.getAttribute('data-modal');
            document.getElementById(mId).classList.add('active');
        });
    });

    // AUDIO PLAYER LOGIC WITH SYNTHESIZER / SOUND ENGINE
    let isPlaying = false;
    let songOscillator = null;
    let songGainNode = null;

    const playSongBtn = document.getElementById('play-song');
    const playIcon = document.getElementById('play-icon');
    const songTitle = document.getElementById('song-title');
    const playlistItems = document.querySelectorAll('.playlist-item');

    playlistItems.forEach(item => {
        item.addEventListener('click', () => {
            playlistItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            songTitle.textContent = item.getAttribute('data-name');
            if (isPlaying) { stopAudioSound(); startAudioSound(item.getAttribute('data-type')); }
            showToast(`Lagu diputar: ${songTitle.textContent}`);
        });
    });

    playSongBtn.addEventListener('click', () => {
        const currentActive = document.querySelector('.playlist-item.active');
        const songType = currentActive ? currentActive.getAttribute('data-type') : 'synth';

        if (!isPlaying) {
            startAudioSound(songType);
            playIcon.className = 'fa-solid fa-pause';
            isPlaying = true;
            showToast('Memutar Audio Musikal...');
        } else {
            stopAudioSound();
            playIcon.className = 'fa-solid fa-play';
            isPlaying = false;
            showToast('Audio Dijeda');
        }
    });

    function startAudioSound(type) {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (songOscillator) stopAudioSound();

        songOscillator = audioCtx.createOscillator();
        songGainNode = audioCtx.createGain();

        let freq = 440;
        if (type === 'cyber') { songOscillator.type = 'sawtooth'; freq = 320; }
        else if (type === 'chill') { songOscillator.type = 'sine'; freq = 520; }
        else { songOscillator.type = 'triangle'; freq = 440; }

        songOscillator.frequency.setValueAtTime(freq, audioCtx.currentTime);
        songGainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);

        songOscillator.connect(songGainNode);
        songGainNode.connect(audioCtx.destination);
        songOscillator.start();
    }

    function stopAudioSound() {
        if (songOscillator) {
            songOscillator.stop();
            songOscillator.disconnect();
            songOscillator = null;
        }
    }

    // SHOP CLAIM (SENDER GLOBAL IDR 5000K BERBAYAR)
    window.buyItem = function(name) {
        if (name.includes('5000K')) {
            showToast(`Menuju gerbang pembayaran IDR 5.000.000 untuk [${name}]...`);
        } else {
            showToast(`Item [${name}] Berhasil Diproses!`);
        }
    };

    // TOAST HELPER
    window.showToast = function(msg) {
        const toast = document.getElementById('toast');
        toast.textContent = msg;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2800);
    };
});

// SYSTEM 10 MINIGAMES
const gameModal = document.getElementById('game-modal');
const gameTitleHeader = document.getElementById('game-title-header');
const gameBody = document.getElementById('game-body');

window.openGame = function(type) {
    gameModal.classList.add('active');
    gameBody.innerHTML = '';

    if (type === 'clicker') {
        gameTitleHeader.textContent = '1. Tap Booster';
        let score = 0, time = 10, timer = null;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Klik tombol sebanyak mungkin dalam 10 detik!</p>
            <h1 id="score-display" style="color:#38bdf8; font-size:2.5rem;">0</h1>
            <p id="time-display" style="font-size:0.8rem;">Sisa Waktu: 10s</p>
            <button id="tap-act-btn" class="glass-btn primary-btn sound-click" style="padding:15px 30px;">TAP DISINI!</button>
        `;
        const btn = document.getElementById('tap-act-btn');
        btn.onclick = () => {
            if (!timer) {
                timer = setInterval(() => {
                    time--;
                    document.getElementById('time-display').textContent = `Sisa Waktu: ${time}s`;
                    if (time <= 0) {
                        clearInterval(timer);
                        btn.disabled = true;
                        showToast(`Game Selesai! Skor: ${score}`);
                    }
                }, 1000);
            }
            if (time > 0) { score++; document.getElementById('score-display').textContent = score; }
        };

    } else if (type === 'reaction') {
        gameTitleHeader.textContent = '2. Refleks Cepat';
        gameBody.innerHTML = `
            <div id="react-box" class="glass-card sound-click" style="padding:30px; background:rgba(239,68,68,0.3); cursor:pointer;">
                <h3 id="react-txt">Tunggu warna hijau...</h3>
            </div>
        `;
        const box = document.getElementById('react-box');
        const txt = document.getElementById('react-txt');
        let start = 0, ready = false;
        const tout = setTimeout(() => {
            ready = true;
            box.style.background = 'rgba(16,185,129,0.4)';
            txt.textContent = 'KLIK SEKARANG!';
            start = Date.now();
        }, Math.random() * 2000 + 1500);

        box.onclick = () => {
            if (!ready) {
                clearTimeout(tout);
                txt.textContent = 'Terlalu cepat! Coba lagi.';
            } else {
                const diff = Date.now() - start;
                txt.textContent = `Waktu Reaksi: ${diff} ms!`;
                showToast(`Waktu Reaksi: ${diff} ms`);
            }
        };

    } else if (type === 'guess') {
        gameTitleHeader.textContent = '3. Tebak Angka';
        const target = Math.floor(Math.random() * 100) + 1;
        let count = 0;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Tebak angka rahasia (1 - 100)</p>
            <input type="number" id="num-guess" class="segment-btn" placeholder="Input angka..." style="width:80%; text-align:center;">
            <button id="btn-guess" class="glass-btn primary-btn sound-click" style="padding:8px 20px;">Tebak</button>
            <p id="guess-res" style="color:#38bdf8; font-size:0.8rem;"></p>
        `;
        document.getElementById('btn-guess').onclick = () => {
            const val = parseInt(document.getElementById('num-guess').value);
            if (!val) return;
            count++;
            const res = document.getElementById('guess-res');
            if (val === target) { res.textContent = `🎉 Benar! (${count}x coba)`; showToast('Tebakan Benar!'); }
            else if (val < target) { res.textContent = 'Terlalu KECIL!'; }
            else { res.textContent = 'Terlalu BESAR!'; }
        };

    } else if (type === 'tictactoe') {
        gameTitleHeader.textContent = '4. Tic Tac Toe';
        let b = ['', '', '', '', '', '', '', '', ''], p = 'X';
        let grid = '<div style="display:grid; grid-template-columns:repeat(3,55px); gap:6px;">';
        for(let i=0; i<9; i++) grid += `<button class="glass-btn tcell sound-click" data-i="${i}" style="height:55px; font-size:1.2rem;"></button>`;
        grid += '</div><p id="ttt-st" style="font-size:0.8rem;">Giliran: X</p>';
        gameBody.innerHTML = grid;

        document.querySelectorAll('.tcell').forEach(c => {
            c.onclick = () => {
                const i = c.getAttribute('data-i');
                if (b[i] !== '') return;
                b[i] = p; c.textContent = p;
                p = p === 'X' ? 'O' : 'X';
                document.getElementById('ttt-st').textContent = `Giliran: ${p}`;
            };
        });

    } else if (type === 'memory') {
        gameTitleHeader.textContent = '5. Memory Match';
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Uji daya ingat emoji!</p>
            <h2 style="color:#38bdf8;">🔥 💎 ⚡ 👑</h2>
            <button class="glass-btn primary-btn sound-click" onclick="openGame('memory')">Acak Ulang</button>
        `;

    } else if (type === 'math') {
        gameTitleHeader.textContent = '6. Math Speed';
        const n1 = Math.floor(Math.random()*25)+1, n2 = Math.floor(Math.random()*25)+1;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Hitung Cepat:</p>
            <h2>${n1} + ${n2} = ?</h2>
            <input type="number" id="math-ans" class="segment-btn" style="width:70%; text-align:center;">
            <button id="math-btn" class="glass-btn primary-btn sound-click" style="padding:8px 20px;">Jawab</button>
        `;
        document.getElementById('math-btn').onclick = () => {
            const ans = parseInt(document.getElementById('math-ans').value);
            if (ans === (n1+n2)) { showToast('Jawaban Benar!'); openGame('math'); }
            else { showToast('Salah! Coba lagi'); }
        };

    } else if (type === 'coin') {
        gameTitleHeader.textContent = '7. Lempar Koin';
        gameBody.innerHTML = `
            <div id="coin-res" style="font-size:3rem; color:#f59e0b;"><i class="fa-solid fa-coins"></i></div>
            <button id="flip-btn" class="glass-btn primary-btn sound-click" style="padding:10px 25px;">Lempar Koin</button>
        `;
        document.getElementById('flip-btn').onclick = () => {
            const res = Math.random() > 0.5 ? 'ANGKA' : 'GAMBAR';
            document.getElementById('coin-res').textContent = res;
            showToast(`Hasil Koin: ${res}`);
        };

    } else if (type === 'rps') {
        gameTitleHeader.textContent = '8. Suwit Bot';
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Pilih Pilihan Anda:</p>
            <div style="display:flex; gap:10px;">
                <button class="glass-btn sound-click" onclick="playRPS('Batu')">✊ Batu</button>
                <button class="glass-btn sound-click" onclick="playRPS('Gunting')">✌️ Gunting</button>
                <button class="glass-btn sound-click" onclick="playRPS('Kertas')">✋ Kertas</button>
            </div>
            <p id="rps-status" style="margin-top:10px; font-size:0.85rem; color:#38bdf8;"></p>
        `;

    } else if (type === 'dice') {
        gameTitleHeader.textContent = '9. Dadu Keberuntungan';
        gameBody.innerHTML = `
            <div id="dice-num" style="font-size:3.5rem; color:#38bdf8;">🎲</div>
            <button id="roll-dice-btn" class="glass-btn primary-btn sound-click" style="padding:10px 25px;">Lempar Dadu</button>
        `;
        document.getElementById('roll-dice-btn').onclick = () => {
            const num = Math.floor(Math.random() * 6) + 1;
            document.getElementById('dice-num').textContent = num;
            showToast(`Dadu Muncul Angka: ${num}`);
        };

    } else if (type === 'simon') {
        gameTitleHeader.textContent = '10. Color Pattern';
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Ikuti Urutan Warna Berkedip</p>
            <div style="display:grid; grid-template-columns:repeat(2,60px); gap:10px;">
                <div class="glass-btn sound-click" style="background:#ef4444; height:60px;" onclick="showToast('Merah Terpilih')"></div>
                <div class="glass-btn sound-click" style="background:#3b82f6; height:60px;" onclick="showToast('Biru Terpilih')"></div>
                <div class="glass-btn sound-click" style="background:#10b981; height:60px;" onclick="showToast('Hijau Terpilih')"></div>
                <div class="glass-btn sound-click" style="background:#f59e0b; height:60px;" onclick="showToast('Kuning Terpilih')"></div>
            </div>
        `;
    }
};

window.playRPS = function(user) {
    const opts = ['Batu', 'Gunting', 'Kertas'];
    const bot = opts[Math.floor(Math.random() * 3)];
    let res = '';
    if (user === bot) res = 'Seri!';
    else if ((user==='Batu'&&bot==='Gunting') || (user==='Gunting'&&bot==='Kertas') || (user==='Kertas'&&bot==='Batu')) res = 'Anda Menang! 🎉';
    else res = 'Bot Menang!';
    document.getElementById('rps-status').textContent = `Anda: ${user} vs Bot: ${bot} -> ${res}`;
};

window.closeGameModal = function() { gameModal.classList.remove('active'); };
