import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

enum PlantStatus { healthy, needsWater, overdue }

enum BookingStatus { pending, confirmed, completed, cancelled }

class StatusBadgeWidget extends StatelessWidget {
  final String label;
  final Color backgroundColor;
  final Color textColor;
  final IconData? icon;

  const StatusBadgeWidget({
    required this.label,
    required this.backgroundColor,
    required this.textColor,
    this.icon,
    super.key,
  });

  factory StatusBadgeWidget.plantStatus(PlantStatus status) {
    switch (status) {
      case PlantStatus.healthy:
        return StatusBadgeWidget(
          label: 'Saudável',
          backgroundColor: AppTheme.success.withAlpha(38),
          textColor: AppTheme.success,
          icon: Icons.favorite_rounded,
        );
      case PlantStatus.needsWater:
        return StatusBadgeWidget(
          label: 'Regar hoje',
          backgroundColor: AppTheme.warning.withAlpha(38),
          textColor: AppTheme.warning,
          icon: Icons.water_drop_outlined,
        );
      case PlantStatus.overdue:
        return StatusBadgeWidget(
          label: 'Atrasado',
          backgroundColor: AppTheme.error.withAlpha(31),
          textColor: AppTheme.error,
          icon: Icons.warning_amber_rounded,
        );
    }
  }

  factory StatusBadgeWidget.bookingStatus(BookingStatus status) {
    switch (status) {
      case BookingStatus.pending:
        return StatusBadgeWidget(
          label: 'Pendente',
          backgroundColor: AppTheme.warning.withAlpha(38),
          textColor: AppTheme.warning,
        );
      case BookingStatus.confirmed:
        return StatusBadgeWidget(
          label: 'Confirmado',
          backgroundColor: AppTheme.success.withAlpha(38),
          textColor: AppTheme.success,
        );
      case BookingStatus.completed:
        return StatusBadgeWidget(
          label: 'Concluído',
          backgroundColor: const Color(0xFFE8F5EE),
          textColor: AppTheme.primary,
        );
      case BookingStatus.cancelled:
        return StatusBadgeWidget(
          label: 'Cancelado',
          backgroundColor: AppTheme.error.withAlpha(26),
          textColor: AppTheme.error,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 11, color: textColor),
            const SizedBox(width: 3),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: textColor,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }
}
