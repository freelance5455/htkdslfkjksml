import 'package:flutter/material.dart';
import '../plant_care_screen.dart';
import '../../../theme/app_theme.dart';

class AddPlantBottomSheet extends StatefulWidget {
  final void Function(PlantModel plant) onAdd;

  const AddPlantBottomSheet({required this.onAdd, super.key});

  @override
  State<AddPlantBottomSheet> createState() => _AddPlantBottomSheetState();
}

class _AddPlantBottomSheetState extends State<AddPlantBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _speciesCtrl = TextEditingController();
  int _wateringDays = 3;
  String _selectedEmoji = '🌿';

  static const _emojis = [
    '🌿',
    '🌸',
    '🌱',
    '🍃',
    '🌵',
    '🌺',
    '🌻',
    '🎋',
    '🍀',
    '🌹',
  ];

  @override
  void dispose() {
    _nameCtrl.dispose();
    _speciesCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    final plant = PlantModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameCtrl.text.trim(),
      species: _speciesCtrl.text.trim().isEmpty
          ? 'Espécie não informada'
          : _speciesCtrl.text.trim(),
      emoji: _selectedEmoji,
      lastWatered: DateTime.now(),
      wateringIntervalDays: _wateringDays,
      addedDate: DateTime.now(),
      growthLogs: [],
      imageUrl: '',
      semanticLabel: 'Plant emoji representing ${_nameCtrl.text.trim()}',
    );

    widget.onAdd(plant);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: 24,
        right: 24,
        top: 24,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Handle
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFDCEDE3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Adicionar Planta',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Color(0xFF1A2E1F),
              ),
            ),
            const SizedBox(height: 20),
            // Emoji picker
            const Text(
              'Ícone',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Color(0xFF5A7A65),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 48,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _emojis.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) {
                  final e = _emojis[i];
                  final isSelected = e == _selectedEmoji;
                  return GestureDetector(
                    onTap: () => setState(() => _selectedEmoji = e),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppTheme.primaryContainer
                            : const Color(0xFFF0F7F2),
                        borderRadius: BorderRadius.circular(12),
                        border: isSelected
                            ? Border.all(color: AppTheme.primary, width: 2)
                            : null,
                      ),
                      child: Center(
                        child: Text(e, style: const TextStyle(fontSize: 22)),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
            // Name field
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Nome da planta *',
                prefixIcon: Icon(
                  Icons.eco_rounded,
                  color: AppTheme.primary,
                  size: 20,
                ),
              ),
              textCapitalization: TextCapitalization.words,
              validator: (v) => v == null || v.trim().isEmpty
                  ? 'Informe o nome da planta'
                  : null,
            ),
            const SizedBox(height: 12),
            // Species field
            TextFormField(
              controller: _speciesCtrl,
              decoration: const InputDecoration(
                labelText: 'Espécie (opcional)',
                prefixIcon: Icon(
                  Icons.science_rounded,
                  color: AppTheme.primary,
                  size: 20,
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Watering interval
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Regar a cada',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF1A2E1F),
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color(0xFFB0C4B8),
                      width: 1.5,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          if (_wateringDays > 1) {
                            setState(() => _wateringDays--);
                          }
                        },
                        icon: const Icon(Icons.remove_rounded, size: 18),
                        color: AppTheme.primary,
                        constraints: const BoxConstraints(
                          minWidth: 36,
                          minHeight: 36,
                        ),
                        padding: EdgeInsets.zero,
                      ),
                      SizedBox(
                        width: 40,
                        child: Text(
                          '$_wateringDays dia${_wateringDays > 1 ? 's' : ''}',
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF1A2E1F),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          if (_wateringDays < 30) {
                            setState(() => _wateringDays++);
                          }
                        },
                        icon: const Icon(Icons.add_rounded, size: 18),
                        color: AppTheme.primary,
                        constraints: const BoxConstraints(
                          minWidth: 36,
                          minHeight: 36,
                        ),
                        padding: EdgeInsets.zero,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submit,
                child: const Text('Adicionar Planta'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
