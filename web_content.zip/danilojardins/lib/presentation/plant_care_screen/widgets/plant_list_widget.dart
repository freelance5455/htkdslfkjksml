import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../plant_care_screen.dart';
import './plant_card_widget.dart';

class PlantListWidget extends StatefulWidget {
  final List<PlantModel> plants;
  final void Function(String id) onWater;
  final void Function(String id) onDelete;

  const PlantListWidget({
    required this.plants,
    required this.onWater,
    required this.onDelete,
    super.key,
  });

  @override
  State<PlantListWidget> createState() => _PlantListWidgetState();
}

class _PlantListWidgetState extends State<PlantListWidget> {
  String? _expandedId;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
      itemCount: widget.plants.length,
      itemBuilder: (context, index) {
        final plant = widget.plants[index];
        return _AnimatedPlantItem(
          index: index,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Dismissible(
              key: Key(plant.id),
              direction: DismissDirection.horizontal,
              background: _buildSwipeBackground(
                alignment: Alignment.centerLeft,
                color: AppTheme.success,
                icon: Icons.water_drop_rounded,
                label: 'Regar',
              ),
              secondaryBackground: _buildSwipeBackground(
                alignment: Alignment.centerRight,
                color: AppTheme.error,
                icon: Icons.delete_rounded,
                label: 'Excluir',
              ),
              confirmDismiss: (direction) async {
                if (direction == DismissDirection.startToEnd) {
                  widget.onWater(plant.id);
                  return false;
                } else {
                  return await _confirmDelete(context);
                }
              },
              onDismissed: (_) => widget.onDelete(plant.id),
              child: PlantCardWidget(
                plant: plant,
                isExpanded: _expandedId == plant.id,
                onTap: () => setState(() {
                  _expandedId = _expandedId == plant.id ? null : plant.id;
                }),
                onWater: () => widget.onWater(plant.id),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSwipeBackground({
    required Alignment alignment,
    required Color color,
    required IconData icon,
    required String label,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(16),
      ),
      alignment: alignment,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.white, size: 24),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirmDelete(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: const Text('Excluir planta?'),
            content: const Text('Esta ação não pode ser desfeita.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancelar'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: FilledButton.styleFrom(backgroundColor: AppTheme.error),
                child: const Text('Excluir'),
              ),
            ],
          ),
        ) ??
        false;
  }
}

class _AnimatedPlantItem extends StatefulWidget {
  final int index;
  final Widget child;

  const _AnimatedPlantItem({required this.index, required this.child});

  @override
  State<_AnimatedPlantItem> createState() => _AnimatedPlantItemState();
}

class _AnimatedPlantItemState extends State<_AnimatedPlantItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    final delay = (widget.index * 60).clamp(0, 400);
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));

    Future.delayed(Duration(milliseconds: delay), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}

// Import AppTheme
