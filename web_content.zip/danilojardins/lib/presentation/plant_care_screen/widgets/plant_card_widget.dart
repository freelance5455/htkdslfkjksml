import 'package:fl_chart/fl_chart.dart';

import '../../../core/app_export.dart';
import '../../../widgets/status_badge_widget.dart';
import '../plant_care_screen.dart';

class PlantCardWidget extends StatelessWidget {
  final PlantModel plant;
  final bool isExpanded;
  final VoidCallback onTap;
  final VoidCallback onWater;

  const PlantCardWidget({
    required this.plant,
    required this.isExpanded,
    required this.onTap,
    required this.onWater,
    super.key,
  });

  Color get _accentColor {
    if (plant.isOverdue) return AppTheme.error;
    if (plant.needsWater) return AppTheme.warning;
    return AppTheme.primary;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border(left: BorderSide(color: _accentColor, width: 4)),
        boxShadow: [
          BoxShadow(
            color: _accentColor.withAlpha(26),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          splashColor: _accentColor.withAlpha(15),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    // Plant image or emoji
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: plant.imageUrl.isNotEmpty
                          ? CustomImageWidget(
                              imageUrl: plant.imageUrl,
                              width: 56,
                              height: 56,
                              fit: BoxFit.cover,
                              semanticLabel: plant.semanticLabel,
                            )
                          : Container(
                              width: 56,
                              height: 56,
                              color: AppTheme.primaryContainer.withAlpha(102),
                              child: Center(
                                child: Text(
                                  plant.emoji,
                                  style: const TextStyle(fontSize: 28),
                                ),
                              ),
                            ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            plant.name,
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF1A2E1F),
                            ),
                          ),
                          Text(
                            plant.species,
                            style: const TextStyle(
                              fontSize: 11,
                              color: Color(0xFF5A7A65),
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              if (plant.isOverdue)
                                StatusBadgeWidget.plantStatus(
                                  PlantStatus.overdue,
                                )
                              else if (plant.needsWater)
                                StatusBadgeWidget.plantStatus(
                                  PlantStatus.needsWater,
                                )
                              else
                                StatusBadgeWidget.plantStatus(
                                  PlantStatus.healthy,
                                ),
                              const SizedBox(width: 8),
                              Text(
                                plant.wateringStatus,
                                style: const TextStyle(
                                  fontSize: 10,
                                  color: Color(0xFF8AAA95),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        if (plant.needsWater || plant.isOverdue)
                          GestureDetector(
                            onTap: onWater,
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: AppTheme.primary.withAlpha(26),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(
                                Icons.water_drop_rounded,
                                color: AppTheme.primary,
                                size: 18,
                              ),
                            ),
                          ),
                        const SizedBox(height: 6),
                        AnimatedRotation(
                          turns: isExpanded ? 0.5 : 0,
                          duration: const Duration(milliseconds: 250),
                          child: const Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: Color(0xFF8AAA95),
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // Expanded growth chart
              AnimatedSize(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOutCubic,
                child: isExpanded
                    ? _buildGrowthChart()
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGrowthChart() {
    final spots = plant.growthLogs.asMap().entries.map((e) {
      return FlSpot(e.key.toDouble(), (e.value['heightCm'] as num).toDouble());
    }).toList();

    final maxY = spots.map((s) => s.y).reduce((a, b) => a > b ? a : b) + 5;
    final minY = spots.map((s) => s.y).reduce((a, b) => a < b ? a : b) - 5;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Divider(height: 1),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(
                Icons.show_chart_rounded,
                color: AppTheme.primary,
                size: 16,
              ),
              const SizedBox(width: 6),
              const Text(
                'Crescimento (cm)',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF1A2E1F),
                ),
              ),
              const Spacer(),
              Text(
                'Atual: ${spots.last.y.toStringAsFixed(1)} cm',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.primary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 120,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  drawVerticalLine: false,
                  horizontalInterval: 5,
                  getDrawingHorizontalLine: (_) => FlLine(
                    color: AppTheme.primaryContainer.withAlpha(128),
                    strokeWidth: 1,
                    dashArray: [4, 4],
                  ),
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 32,
                      getTitlesWidget: (v, _) => Text(
                        '${v.toInt()}',
                        style: const TextStyle(
                          fontSize: 9,
                          color: Color(0xFF8AAA95),
                        ),
                      ),
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (v, _) {
                        final labels = ['M-3', 'M-2', 'M-1', 'Hoje'];
                        final i = v.toInt();
                        if (i >= 0 && i < labels.length) {
                          return Text(
                            labels[i],
                            style: const TextStyle(
                              fontSize: 9,
                              color: Color(0xFF8AAA95),
                            ),
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                minY: minY,
                maxY: maxY,
                lineBarsData: [
                  LineChartBarData(
                    spots: spots,
                    isCurved: true,
                    curveSmoothness: 0.35,
                    color: AppTheme.primary,
                    barWidth: 2.5,
                    dotData: FlDotData(
                      getDotPainter: (spot, _, __, ___) => FlDotCirclePainter(
                        radius: 4,
                        color: AppTheme.primary,
                        strokeColor: Colors.white,
                        strokeWidth: 2,
                      ),
                    ),
                    belowBarData: BarAreaData(
                      show: true,
                      gradient: LinearGradient(
                        colors: [
                          AppTheme.primary.withAlpha(51),
                          AppTheme.primary.withAlpha(0),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ],
                lineTouchData: LineTouchData(
                  touchTooltipData: LineTouchTooltipData(
                    tooltipBgColor: const Color(0xFF1B4332),
                    tooltipRoundedRadius: 8,
                    getTooltipItems: (spots) => spots.map((s) {
                      return LineTooltipItem(
                        '${s.y.toStringAsFixed(1)} cm',
                        const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
