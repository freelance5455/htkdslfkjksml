import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import '../../widgets/empty_state_widget.dart';
import './widgets/add_plant_bottom_sheet.dart';
import './widgets/plant_care_header_widget.dart';
import './widgets/plant_list_widget.dart';

class PlantModel {
  final String id;
  final String name;
  final String species;
  final String emoji;
  final DateTime lastWatered;
  final int wateringIntervalDays;
  final DateTime addedDate;
  final List<Map<String, dynamic>> growthLogs;
  final String imageUrl;
  final String semanticLabel;

  PlantModel({
    required this.id,
    required this.name,
    required this.species,
    required this.emoji,
    required this.lastWatered,
    required this.wateringIntervalDays,
    required this.addedDate,
    required this.growthLogs,
    required this.imageUrl,
    required this.semanticLabel,
  });

  bool get needsWater {
    final daysSince = DateTime.now().difference(lastWatered).inDays;
    return daysSince >= wateringIntervalDays &&
        daysSince < wateringIntervalDays + 2;
  }

  bool get isOverdue {
    final daysSince = DateTime.now().difference(lastWatered).inDays;
    return daysSince >= wateringIntervalDays + 2;
  }

  bool get isHealthy => !needsWater && !isOverdue;

  String get wateringStatus {
    final daysSince = DateTime.now().difference(lastWatered).inDays;
    if (daysSince == 0) return 'Regada hoje';
    if (daysSince == 1) return 'Regada ontem';
    return 'Há $daysSince dias';
  }

  factory PlantModel.fromMap(Map<String, dynamic> map) {
    return PlantModel(
      id: map['id'] as String,
      name: map['name'] as String,
      species: map['species'] as String,
      emoji: map['emoji'] as String,
      lastWatered: DateTime.parse(map['lastWatered'] as String),
      wateringIntervalDays: map['wateringIntervalDays'] as int,
      addedDate: DateTime.parse(map['addedDate'] as String),
      growthLogs: (map['growthLogs'] as List).cast<Map<String, dynamic>>(),
      imageUrl: map['imageUrl'] as String,
      semanticLabel: map['semanticLabel'] as String,
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'species': species,
    'emoji': emoji,
    'lastWatered': lastWatered.toIso8601String(),
    'wateringIntervalDays': wateringIntervalDays,
    'addedDate': addedDate.toIso8601String(),
    'growthLogs': growthLogs,
    'imageUrl': imageUrl,
    'semanticLabel': semanticLabel,
  };

  PlantModel copyWith({DateTime? lastWatered}) {
    return PlantModel(
      id: id,
      name: name,
      species: species,
      emoji: emoji,
      lastWatered: lastWatered ?? this.lastWatered,
      wateringIntervalDays: wateringIntervalDays,
      addedDate: addedDate,
      growthLogs: growthLogs,
      imageUrl: imageUrl,
      semanticLabel: semanticLabel,
    );
  }
}

class PlantCareScreen extends StatefulWidget {
  const PlantCareScreen({super.key});

  @override
  State<PlantCareScreen> createState() => _PlantCareScreenState();
}

class _PlantCareScreenState extends State<PlantCareScreen> {
  // TODO: Replace with [Riverpod/Bloc] for production
  late List<PlantModel> _plants;

  final List<Map<String, dynamic>> _plantMaps = [
    {
      'id': 'p1',
      'name': 'Samambaia',
      'species': 'Nephrolepis exaltata',
      'emoji': '🌿',
      'lastWatered': DateTime.now()
          .subtract(const Duration(days: 2))
          .toIso8601String(),
      'wateringIntervalDays': 2,
      'addedDate': DateTime.now()
          .subtract(const Duration(days: 45))
          .toIso8601String(),
      'imageUrl':
          'https://images.unsplash.com/photo-1662825351106-e5da30abcedd',
      'semanticLabel':
          'Lush green fern plant with arching fronds in a terracotta pot',
      'growthLogs': [
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 30))
              .toIso8601String(),
          'heightCm': 18.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 20))
              .toIso8601String(),
          'heightCm': 22.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 10))
              .toIso8601String(),
          'heightCm': 25.5,
        },
        {'date': DateTime.now().toIso8601String(), 'heightCm': 28.0},
      ],
    },
    {
      'id': 'p2',
      'name': 'Orquídea Rosa',
      'species': 'Phalaenopsis sp.',
      'emoji': '🌸',
      'lastWatered': DateTime.now()
          .subtract(const Duration(days: 8))
          .toIso8601String(),
      'wateringIntervalDays': 5,
      'addedDate': DateTime.now()
          .subtract(const Duration(days: 90))
          .toIso8601String(),
      'imageUrl':
          'https://images.unsplash.com/photo-1690909955458-47a7a6424a27',
      'semanticLabel':
          'Pink orchid flowers in full bloom with white and pink petals',
      'growthLogs': [
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 60))
              .toIso8601String(),
          'heightCm': 30.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 40))
              .toIso8601String(),
          'heightCm': 32.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 20))
              .toIso8601String(),
          'heightCm': 35.0,
        },
        {'date': DateTime.now().toIso8601String(), 'heightCm': 38.5},
      ],
    },
    {
      'id': 'p3',
      'name': 'Espada de São Jorge',
      'species': 'Sansevieria trifasciata',
      'emoji': '🌱',
      'lastWatered': DateTime.now()
          .subtract(const Duration(days: 1))
          .toIso8601String(),
      'wateringIntervalDays': 7,
      'addedDate': DateTime.now()
          .subtract(const Duration(days: 120))
          .toIso8601String(),
      'imageUrl':
          'https://images.unsplash.com/photo-1599224473524-8bfa5928ba5b',
      'semanticLabel':
          'Tall snake plant with upright striped green and yellow leaves',
      'growthLogs': [
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 90))
              .toIso8601String(),
          'heightCm': 40.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 60))
              .toIso8601String(),
          'heightCm': 44.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 30))
              .toIso8601String(),
          'heightCm': 47.0,
        },
        {'date': DateTime.now().toIso8601String(), 'heightCm': 50.0},
      ],
    },
    {
      'id': 'p4',
      'name': 'Pothos',
      'species': 'Epipremnum aureum',
      'emoji': '🍃',
      'lastWatered': DateTime.now()
          .subtract(const Duration(days: 3))
          .toIso8601String(),
      'wateringIntervalDays': 4,
      'addedDate': DateTime.now()
          .subtract(const Duration(days: 60))
          .toIso8601String(),
      'imageUrl':
          'https://images.unsplash.com/photo-1674482918961-57a3a0484bf3',
      'semanticLabel':
          'Trailing pothos plant with heart-shaped variegated green and yellow leaves',
      'growthLogs': [
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 40))
              .toIso8601String(),
          'heightCm': 15.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 25))
              .toIso8601String(),
          'heightCm': 22.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 10))
              .toIso8601String(),
          'heightCm': 30.0,
        },
        {'date': DateTime.now().toIso8601String(), 'heightCm': 38.0},
      ],
    },
    {
      'id': 'p5',
      'name': 'Cacto Coluna',
      'species': 'Cereus jamacaru',
      'emoji': '🌵',
      'lastWatered': DateTime.now()
          .subtract(const Duration(days: 0))
          .toIso8601String(),
      'wateringIntervalDays': 14,
      'addedDate': DateTime.now()
          .subtract(const Duration(days: 200))
          .toIso8601String(),
      'imageUrl':
          'https://images.unsplash.com/photo-1661630778692-3db93e446ab5',
      'semanticLabel':
          'Tall columnar cactus with green ribbed stem and spines in desert setting',
      'growthLogs': [
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 150))
              .toIso8601String(),
          'heightCm': 25.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 100))
              .toIso8601String(),
          'heightCm': 28.0,
        },
        {
          'date': DateTime.now()
              .subtract(const Duration(days: 50))
              .toIso8601String(),
          'heightCm': 31.0,
        },
        {'date': DateTime.now().toIso8601String(), 'heightCm': 34.0},
      ],
    },
  ];

  @override
  void initState() {
    super.initState();
    _plants = _plantMaps.map(PlantModel.fromMap).toList();
  }

  void _waterPlant(String id) {
    setState(() {
      _plants = _plants.map((p) {
        if (p.id == id) return p.copyWith(lastWatered: DateTime.now());
        return p;
      }).toList();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Planta regada! 💧'),
        backgroundColor: AppTheme.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _deletePlant(String id) {
    setState(() {
      _plants = _plants.where((p) => p.id != id).toList();
    });
  }

  void _showAddPlant() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddPlantBottomSheet(
        onAdd: (plant) {
          setState(() => _plants.insert(0, plant));
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final needsWater = _plants.where((p) => p.needsWater).length;
    final overdue = _plants.where((p) => p.isOverdue).length;
    final healthy = _plants.where((p) => p.isHealthy).length;

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: SafeArea(
        child: Column(
          children: [
            PlantCareHeaderWidget(
              totalPlants: _plants.length,
              needsWater: needsWater,
              overdue: overdue,
              healthy: healthy,
            ),
            Expanded(
              child: _plants.isEmpty
                  ? EmptyStateWidget(
                      icon: Icons.eco_rounded,
                      title: 'Nenhuma planta ainda',
                      description:
                          'Adicione suas plantas para acompanhar os cuidados e o crescimento.',
                      ctaLabel: 'Adicionar Planta',
                      onCta: _showAddPlant,
                    )
                  : PlantListWidget(
                      plants: _plants,
                      onWater: _waterPlant,
                      onDelete: _deletePlant,
                    ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddPlant,
        icon: const Icon(Icons.add_rounded),
        label: const Text(
          'Nova Planta',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
      ),
    );
  }
}
