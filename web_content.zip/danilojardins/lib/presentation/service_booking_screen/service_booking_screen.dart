import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import './widgets/booking_confirmation_widget.dart';
import './widgets/booking_contact_step_widget.dart';
import './widgets/booking_date_step_widget.dart';
import './widgets/booking_service_step_widget.dart';
import './widgets/booking_step_indicator_widget.dart';

class ServiceBookingScreen extends StatefulWidget {
  const ServiceBookingScreen({super.key});

  @override
  State<ServiceBookingScreen> createState() => _ServiceBookingScreenState();
}

class _ServiceBookingScreenState extends State<ServiceBookingScreen> {
  // TODO: Replace with [Riverpod/Bloc] for production
  int _currentStep = 0;
  String? _selectedService;
  String _customerName = '';
  String _customerPhone = '';
  String _customerAddress = '';
  DateTime? _selectedDate;
  String _notes = '';

  final List<String> _stepTitles = [
    'Serviço',
    'Contato',
    'Data',
    'Confirmação',
  ];

  void _nextStep() {
    if (_currentStep < 3) {
      setState(() => _currentStep++);
    }
  }

  void _prevStep() {
    if (_currentStep > 0) {
      setState(() => _currentStep--);
    }
  }

  void _onServiceSelected(String service) {
    setState(() => _selectedService = service);
  }

  void _onContactFilled({
    required String name,
    required String phone,
    required String address,
    required String notes,
  }) {
    setState(() {
      _customerName = name;
      _customerPhone = phone;
      _customerAddress = address;
      _notes = notes;
    });
    _nextStep();
  }

  void _onDateSelected(DateTime date) {
    setState(() => _selectedDate = date);
    _nextStep();
  }

  void _submitBooking() {
    // TODO: Replace with real API call to booking backend
    _showSuccessSheet();
  }

  void _showSuccessSheet() {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      backgroundColor: Colors.transparent,
      builder: (_) => _SuccessBottomSheet(
        serviceName: _selectedService ?? '',
        customerName: _customerName,
        date: _selectedDate,
        onDone: () {
          Navigator.pop(context);
          setState(() {
            _currentStep = 0;
            _selectedService = null;
            _customerName = '';
            _customerPhone = '';
            _customerAddress = '';
            _selectedDate = null;
            _notes = '';
          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF1B4332), Color(0xFF2D6A4F)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(28),
                  bottomRight: Radius.circular(28),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_currentStep > 0)
                    GestureDetector(
                      onTap: _prevStep,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(38),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.arrow_back_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  if (_currentStep > 0) const SizedBox(height: 12),
                  const Text(
                    'Agendar Serviço',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _stepTitles[_currentStep],
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.white70,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 16),
                  BookingStepIndicatorWidget(
                    currentStep: _currentStep,
                    totalSteps: _stepTitles.length,
                    stepLabels: _stepTitles,
                  ),
                ],
              ),
            ),
            // Step content
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 280),
                transitionBuilder: (child, animation) => FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position:
                        Tween<Offset>(
                          begin: const Offset(0.04, 0),
                          end: Offset.zero,
                        ).animate(
                          CurvedAnimation(
                            parent: animation,
                            curve: Curves.easeOutCubic,
                          ),
                        ),
                    child: child,
                  ),
                ),
                child: _buildStep(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStep() {
    switch (_currentStep) {
      case 0:
        return BookingServiceStepWidget(
          key: const ValueKey('step0'),
          selectedService: _selectedService,
          onServiceSelected: _onServiceSelected,
          onNext: _selectedService != null ? _nextStep : null,
        );
      case 1:
        return BookingContactStepWidget(
          key: const ValueKey('step1'),
          initialName: _customerName,
          initialPhone: _customerPhone,
          initialAddress: _customerAddress,
          initialNotes: _notes,
          onSubmit: _onContactFilled,
        );
      case 2:
        return BookingDateStepWidget(
          key: const ValueKey('step2'),
          selectedDate: _selectedDate,
          onDateSelected: _onDateSelected,
        );
      case 3:
        return BookingConfirmationWidget(
          key: const ValueKey('step3'),
          serviceName: _selectedService ?? '',
          customerName: _customerName,
          customerPhone: _customerPhone,
          customerAddress: _customerAddress,
          selectedDate: _selectedDate,
          notes: _notes,
          onConfirm: _submitBooking,
          onEdit: () => setState(() => _currentStep = 0),
        );
      default:
        return const SizedBox.shrink();
    }
  }
}

class _SuccessBottomSheet extends StatelessWidget {
  final String serviceName;
  final String customerName;
  final DateTime? date;
  final VoidCallback onDone;

  const _SuccessBottomSheet({
    required this.serviceName,
    required this.customerName,
    required this.date,
    required this.onDone,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: AppTheme.success.withAlpha(38),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.check_rounded,
              color: AppTheme.success,
              size: 40,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Solicitação Enviada!',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF1A2E1F),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Olá, $customerName! Sua solicitação de "$serviceName" foi recebida. '
            'O Danilo entrará em contato para confirmar o agendamento.',
            style: const TextStyle(
              fontSize: 14,
              color: Color(0xFF5A7A65),
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.backgroundLight,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.phone_rounded,
                  color: AppTheme.primary,
                  size: 16,
                ),
                const SizedBox(width: 8),
                const Text(
                  '(21) 98904-6824',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.primary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onDone,
              child: const Text('Feito!'),
            ),
          ),
        ],
      ),
    );
  }
}
