import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

class BookingStepIndicatorWidget extends StatelessWidget {
  final int currentStep;
  final int totalSteps;
  final List<String> stepLabels;

  const BookingStepIndicatorWidget({
    required this.currentStep,
    required this.totalSteps,
    required this.stepLabels,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(totalSteps, (i) {
        final isCompleted = i < currentStep;
        final isActive = i == currentStep;

        return Expanded(
          child: Row(
            children: [
              Expanded(
                child: Column(
                  children: [
                    Row(
                      children: [
                        if (i > 0)
                          Expanded(
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              height: 2,
                              color: isCompleted || isActive
                                  ? Colors.white
                                  : Colors.white.withAlpha(77),
                            ),
                          ),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          width: isActive ? 28 : 22,
                          height: isActive ? 28 : 22,
                          decoration: BoxDecoration(
                            color: isCompleted
                                ? Colors.white
                                : isActive
                                ? Colors.white
                                : Colors.white.withAlpha(64),
                            shape: BoxShape.circle,
                            border: isActive
                                ? Border.all(color: Colors.white, width: 2)
                                : null,
                          ),
                          child: Center(
                            child: isCompleted
                                ? Icon(
                                    Icons.check_rounded,
                                    color: AppTheme.primary,
                                    size: 14,
                                  )
                                : Text(
                                    '${i + 1}',
                                    style: TextStyle(
                                      fontSize: isActive ? 13 : 11,
                                      fontWeight: FontWeight.w700,
                                      color: isActive || isCompleted
                                          ? AppTheme.primary
                                          : Colors.white.withAlpha(179),
                                    ),
                                  ),
                          ),
                        ),
                        if (i < totalSteps - 1)
                          Expanded(
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              height: 2,
                              color: i < currentStep
                                  ? Colors.white
                                  : Colors.white.withAlpha(77),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      stepLabels[i],
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: isActive
                            ? FontWeight.w700
                            : FontWeight.w500,
                        color: isActive
                            ? Colors.white
                            : Colors.white.withAlpha(153),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
