import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

class BookingContactStepWidget extends StatefulWidget {
  final String initialName;
  final String initialPhone;
  final String initialAddress;
  final String initialNotes;
  final void Function({
    required String name,
    required String phone,
    required String address,
    required String notes,
  })
  onSubmit;

  const BookingContactStepWidget({
    required this.initialName,
    required this.initialPhone,
    required this.initialAddress,
    required this.initialNotes,
    required this.onSubmit,
    super.key,
  });

  @override
  State<BookingContactStepWidget> createState() =>
      _BookingContactStepWidgetState();
}

class _BookingContactStepWidgetState extends State<BookingContactStepWidget> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameCtrl;
  late final TextEditingController _phoneCtrl;
  late final TextEditingController _addressCtrl;
  late final TextEditingController _notesCtrl;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.initialName);
    _phoneCtrl = TextEditingController(text: widget.initialPhone);
    _addressCtrl = TextEditingController(text: widget.initialAddress);
    _notesCtrl = TextEditingController(text: widget.initialNotes);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    widget.onSubmit(
      name: _nameCtrl.text.trim(),
      phone: _phoneCtrl.text.trim(),
      address: _addressCtrl.text.trim(),
      notes: _notesCtrl.text.trim(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Seus dados de contato',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1A2E1F),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Precisamos de algumas informações para confirmar o agendamento',
                    style: TextStyle(fontSize: 13, color: Color(0xFF5A7A65)),
                  ),
                  const SizedBox(height: 24),
                  // Name
                  TextFormField(
                    controller: _nameCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Nome completo *',
                      prefixIcon: Icon(
                        Icons.person_rounded,
                        color: AppTheme.primary,
                        size: 20,
                      ),
                      helperText: 'Como prefere ser chamado(a)',
                    ),
                    textCapitalization: TextCapitalization.words,
                    validator: (v) => v == null || v.trim().isEmpty
                        ? 'Informe seu nome'
                        : null,
                  ),
                  const SizedBox(height: 16),
                  // Phone
                  TextFormField(
                    controller: _phoneCtrl,
                    decoration: const InputDecoration(
                      labelText: 'WhatsApp / Telefone *',
                      prefixIcon: Icon(
                        Icons.phone_rounded,
                        color: AppTheme.primary,
                        size: 20,
                      ),
                      helperText: 'Ex: (21) 98000-0000',
                    ),
                    keyboardType: TextInputType.phone,
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) {
                        return 'Informe seu telefone';
                      }
                      if (v.trim().length < 10) return 'Número inválido';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  // Address
                  TextFormField(
                    controller: _addressCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Endereço completo *',
                      prefixIcon: Icon(
                        Icons.location_on_rounded,
                        color: AppTheme.primary,
                        size: 20,
                      ),
                      helperText:
                          'Rua, número, bairro — Rio de Janeiro e região',
                    ),
                    textCapitalization: TextCapitalization.sentences,
                    maxLines: 2,
                    validator: (v) => v == null || v.trim().isEmpty
                        ? 'Informe o endereço'
                        : null,
                  ),
                  const SizedBox(height: 16),
                  // Notes
                  TextFormField(
                    controller: _notesCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Observações (opcional)',
                      prefixIcon: Icon(
                        Icons.notes_rounded,
                        color: AppTheme.primary,
                        size: 20,
                      ),
                      helperText: 'Descreva o espaço, tamanho do jardim, etc.',
                      alignLabelWithHint: true,
                    ),
                    maxLines: 3,
                    textCapitalization: TextCapitalization.sentences,
                  ),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _submit,
              child: const Text('Continuar'),
            ),
          ),
        ),
      ],
    );
  }
}
