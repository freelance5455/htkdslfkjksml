import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

class BookingDateStepWidget extends StatefulWidget {
  final DateTime? selectedDate;
  final void Function(DateTime) onDateSelected;

  const BookingDateStepWidget({
    required this.selectedDate,
    required this.onDateSelected,
    super.key,
  });

  @override
  State<BookingDateStepWidget> createState() => _BookingDateStepWidgetState();
}

class _BookingDateStepWidgetState extends State<BookingDateStepWidget> {
  // TODO: Replace with [Riverpod/Bloc] for production
  DateTime? _selected;
  String _selectedPeriod = 'Manhã';

  static const _periods = ['Manhã', 'Tarde', 'Qualquer'];

  @override
  void initState() {
    super.initState();
    _selected = widget.selectedDate;
  }

  List<DateTime> _getAvailableDates() {
    final now = DateTime.now();
    final dates = <DateTime>[];
    var d = now.add(const Duration(days: 1));
    while (dates.length < 21) {
      if (d.weekday != DateTime.sunday) {
        dates.add(d);
      }
      d = d.add(const Duration(days: 1));
    }
    return dates;
  }

  String _formatDay(DateTime d) {
    const days = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    return days[d.weekday - 1];
  }

  String _formatMonth(DateTime d) {
    const months = [
      'Jan',
      'Fev',
      'Mar',
      'Abr',
      'Mai',
      'Jun',
      'Jul',
      'Ago',
      'Set',
      'Out',
      'Nov',
      'Dez',
    ];
    return months[d.month - 1];
  }

  @override
  Widget build(BuildContext context) {
    final dates = _getAvailableDates();
    final canContinue = _selected != null;

    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Escolha uma data',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1A2E1F),
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Atendemos de segunda a sábado no Rio de Janeiro e região',
                  style: TextStyle(fontSize: 13, color: Color(0xFF5A7A65)),
                ),
                const SizedBox(height: 20),
                // Date picker
                SizedBox(
                  height: 90,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: dates.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) {
                      final d = dates[i];
                      final isSelected =
                          _selected != null &&
                          _selected!.day == d.day &&
                          _selected!.month == d.month;
                      return GestureDetector(
                        onTap: () => setState(() => _selected = d),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 60,
                          decoration: BoxDecoration(
                            color: isSelected ? AppTheme.primary : Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isSelected
                                  ? AppTheme.primary
                                  : const Color(0xFFDCEDE3),
                              width: isSelected ? 2 : 1,
                            ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: AppTheme.primary.withAlpha(64),
                                      blurRadius: 10,
                                      offset: const Offset(0, 4),
                                    ),
                                  ]
                                : null,
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                _formatDay(d),
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: isSelected
                                      ? Colors.white70
                                      : const Color(0xFF8AAA95),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${d.day}',
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  color: isSelected
                                      ? Colors.white
                                      : const Color(0xFF1A2E1F),
                                ),
                              ),
                              Text(
                                _formatMonth(d),
                                style: TextStyle(
                                  fontSize: 10,
                                  color: isSelected
                                      ? Colors.white70
                                      : const Color(0xFF8AAA95),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 24),
                // Period selection
                const Text(
                  'Período preferido',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1A2E1F),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: _periods.map((p) {
                    final isActive = _selectedPeriod == p;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _selectedPeriod = p),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: EdgeInsets.only(
                            right: p != _periods.last ? 8 : 0,
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: isActive ? AppTheme.primary : Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isActive
                                  ? AppTheme.primary
                                  : const Color(0xFFDCEDE3),
                            ),
                          ),
                          child: Column(
                            children: [
                              Icon(
                                p == 'Manhã'
                                    ? Icons.wb_sunny_rounded
                                    : p == 'Tarde'
                                    ? Icons.wb_twilight_rounded
                                    : Icons.access_time_rounded,
                                color: isActive
                                    ? Colors.white
                                    : AppTheme.primary,
                                size: 22,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                p,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: isActive
                                      ? Colors.white
                                      : const Color(0xFF1A2E1F),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                if (_selected != null) ...[
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryContainer.withAlpha(102),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.primaryContainer),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.event_available_rounded,
                          color: AppTheme.primary,
                          size: 18,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Data selecionada: ${_selected!.day.toString().padLeft(2, '0')}/'
                            '${_selected!.month.toString().padLeft(2, '0')}/'
                            '${_selected!.year} — $_selectedPeriod',
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.primary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: canContinue
                  ? () => widget.onDateSelected(_selected!)
                  : null,
              child: const Text('Continuar'),
            ),
          ),
        ),
      ],
    );
  }
}
