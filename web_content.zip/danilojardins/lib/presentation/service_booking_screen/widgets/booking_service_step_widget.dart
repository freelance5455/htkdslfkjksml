import '../../../core/app_export.dart';

class _ServiceOption {
  final String id;
  final String title;
  final String description;
  final String detail;
  final IconData icon;
  final Color color;
  final String imageUrl;
  final String semanticLabel;

  const _ServiceOption({
    required this.id,
    required this.title,
    required this.description,
    required this.detail,
    required this.icon,
    required this.color,
    required this.imageUrl,
    required this.semanticLabel,
  });
}

class BookingServiceStepWidget extends StatelessWidget {
  final String? selectedService;
  final void Function(String) onServiceSelected;
  final VoidCallback? onNext;

  const BookingServiceStepWidget({
    required this.selectedService,
    required this.onServiceSelected,
    required this.onNext,
    super.key,
  });

  static const List<_ServiceOption> _options = [
    _ServiceOption(
      id: 'Paisagismo',
      title: 'Paisagismo',
      description: 'Projeto e execução completa de jardins',
      detail:
          'Criação de projetos paisagísticos, seleção e plantio de espécies adequadas para seu espaço.',
      icon: Icons.park_rounded,
      color: Color(0xFF2D6A4F),
      imageUrl:
          'https://images.pexels.com/photos/1105019/pexels-photo-1105019.jpeg?auto=compress&cs=tinysrgb&w=400',
      semanticLabel:
          'Beautiful landscaped garden with lush green plants and stone pathway',
    ),
    _ServiceOption(
      id: 'Corte de Grama',
      title: 'Corte de Grama',
      description: 'Manutenção e corte de gramados',
      detail:
          'Corte regular, bordas definidas e limpeza completa para manter seu gramado impecável.',
      icon: Icons.grass_rounded,
      color: Color(0xFF40916C),
      imageUrl:
          'https://images.pixabay.com/photo/2016/11/29/04/20/lawn-1867570_640.jpg',
      semanticLabel: 'Freshly mowed lawn with perfectly uniform green grass',
    ),
    _ServiceOption(
      id: 'Poda',
      title: 'Poda',
      description: 'Poda técnica de árvores e arbustos',
      detail:
          'Poda corretiva e estética de árvores, arbustos, cercas vivas e plantas ornamentais.',
      icon: Icons.content_cut_rounded,
      color: Color(0xFF1B4332),
      imageUrl:
          'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&q=80',
      semanticLabel:
          'Precisely pruned hedge forming a neat geometric shape in a garden',
    ),
    _ServiceOption(
      id: 'Manutenção Geral',
      title: 'Manutenção Geral',
      description: 'Pacote completo de cuidados do jardim',
      detail:
          'Serviço completo incluindo corte, poda, limpeza e adubação para manutenção periódica.',
      icon: Icons.handyman_rounded,
      color: Color(0xFF74C69D),
      imageUrl:
          'https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=400',
      semanticLabel:
          'Gardener maintaining a beautiful garden with tools and equipment',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Qual serviço você precisa?',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1A2E1F),
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Selecione um serviço para continuar',
                  style: TextStyle(fontSize: 13, color: Color(0xFF5A7A65)),
                ),
                const SizedBox(height: 20),
                ..._options.map(
                  (opt) => _ServiceOptionCard(
                    option: opt,
                    isSelected: selectedService == opt.id,
                    onTap: () => onServiceSelected(opt.id),
                  ),
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onNext,
              child: const Text('Continuar'),
            ),
          ),
        ),
      ],
    );
  }
}

class _ServiceOptionCard extends StatelessWidget {
  final _ServiceOption option;
  final bool isSelected;
  final VoidCallback onTap;

  const _ServiceOptionCard({
    required this.option,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? option.color : Colors.transparent,
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: option.color.withOpacity(isSelected ? 0.15 : 0.06),
              blurRadius: isSelected ? 16 : 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(14),
              ),
              child: Stack(
                children: [
                  CustomImageWidget(
                    imageUrl: option.imageUrl,
                    width: double.infinity,
                    height: 110,
                    fit: BoxFit.cover,
                    semanticLabel: option.semanticLabel,
                  ),
                  if (isSelected)
                    Positioned(
                      top: 10,
                      right: 10,
                      child: Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: option.color,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check_rounded,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                    ),
                  Container(
                    width: double.infinity,
                    height: 110,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          option.color.withAlpha(0),
                          option.color.withAlpha(153),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: option.color.withAlpha(26),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(option.icon, color: option.color, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          option.title,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF1A2E1F),
                          ),
                        ),
                        Text(
                          option.description,
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFF5A7A65),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
