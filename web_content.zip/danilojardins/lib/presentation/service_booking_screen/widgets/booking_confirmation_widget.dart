import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/status_badge_widget.dart';

class BookingConfirmationWidget extends StatelessWidget {
  final String serviceName;
  final String customerName;
  final String customerPhone;
  final String customerAddress;
  final DateTime? selectedDate;
  final String notes;
  final VoidCallback onConfirm;
  final VoidCallback onEdit;

  const BookingConfirmationWidget({
    required this.serviceName,
    required this.customerName,
    required this.customerPhone,
    required this.customerAddress,
    required this.selectedDate,
    required this.notes,
    required this.onConfirm,
    required this.onEdit,
    super.key,
  });

  String _formatDate(DateTime? d) {
    if (d == null) return '—';
    const months = [
      'janeiro',
      'fevereiro',
      'março',
      'abril',
      'maio',
      'junho',
      'julho',
      'agosto',
      'setembro',
      'outubro',
      'novembro',
      'dezembro',
    ];
    return '${d.day} de ${months[d.month - 1]} de ${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Confirme seu agendamento',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1A2E1F),
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Revise as informações antes de enviar',
                  style: TextStyle(fontSize: 13, color: Color(0xFF5A7A65)),
                ),
                const SizedBox(height: 20),
                // Summary card
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border(
                      left: BorderSide(color: AppTheme.primary, width: 4),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.primary.withAlpha(20),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _ConfirmRow(
                          icon: Icons.handyman_rounded,
                          label: 'Serviço',
                          value: serviceName,
                          highlight: true,
                        ),
                        const SizedBox(height: 12),
                        _ConfirmRow(
                          icon: Icons.person_rounded,
                          label: 'Nome',
                          value: customerName,
                        ),
                        const SizedBox(height: 12),
                        _ConfirmRow(
                          icon: Icons.phone_rounded,
                          label: 'Telefone',
                          value: customerPhone,
                        ),
                        const SizedBox(height: 12),
                        _ConfirmRow(
                          icon: Icons.location_on_rounded,
                          label: 'Endereço',
                          value: customerAddress,
                        ),
                        const SizedBox(height: 12),
                        _ConfirmRow(
                          icon: Icons.calendar_today_rounded,
                          label: 'Data',
                          value: _formatDate(selectedDate),
                        ),
                        if (notes.isNotEmpty) ...[
                          const SizedBox(height: 12),
                          _ConfirmRow(
                            icon: Icons.notes_rounded,
                            label: 'Observações',
                            value: notes,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Info box
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryContainer.withAlpha(89),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.info_outline_rounded,
                        color: AppTheme.primary,
                        size: 18,
                      ),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text(
                          'Após o envio, o Danilo entrará em contato pelo WhatsApp para confirmar o horário e detalhes do serviço.',
                          style: TextStyle(
                            fontSize: 12,
                            color: Color(0xFF2D6A4F),
                            height: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Contact reference
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1B4332), Color(0xFF2D6A4F)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.storefront_rounded,
                        color: Colors.white70,
                        size: 18,
                      ),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Danilo Jardins',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              'Rio de Janeiro e região • @danilo_jardins',
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.white70,
                              ),
                            ),
                          ],
                        ),
                      ),
                      StatusBadgeWidget(
                        label: 'Ativo',
                        backgroundColor: Colors.white.withAlpha(38),
                        textColor: Colors.white,
                        icon: Icons.check_circle_rounded,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Column(
            children: [
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: onConfirm,
                  icon: const Icon(Icons.send_rounded, size: 18),
                  label: const Text('Enviar Solicitação'),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: onEdit,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.primary,
                    side: const BorderSide(color: AppTheme.primary, width: 1.5),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text(
                    'Editar informações',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ConfirmRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final bool highlight;

  const _ConfirmRow({
    required this.icon,
    required this.label,
    required this.value,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: AppTheme.primaryContainer.withAlpha(102),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: AppTheme.primary, size: 16),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF8AAA95),
                  letterSpacing: 0.3,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: highlight ? FontWeight.w800 : FontWeight.w600,
                  color: highlight ? AppTheme.primary : const Color(0xFF1A2E1F),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
