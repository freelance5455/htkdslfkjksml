import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../../theme/app_theme.dart';

class HomeContactWidget extends StatelessWidget {
  const HomeContactWidget({super.key});

  void _copyToClipboard(String value, String label) {
    Clipboard.setData(ClipboardData(text: value));
    Fluttertoast.showToast(
      msg: '$label copiado!',
      backgroundColor: AppTheme.primary,
      textColor: Colors.white,
      toastLength: Toast.LENGTH_SHORT,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1B4332), Color(0xFF2D6A4F)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withAlpha(77),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Entre em Contato',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Atendemos no Rio de Janeiro e região',
            style: TextStyle(fontSize: 12, color: Colors.white70),
          ),
          const SizedBox(height: 16),
          _ContactRow(
            icon: Icons.camera_alt_rounded,
            label: '@danilo_jardins',
            onTap: () => _copyToClipboard('@danilo_jardins', 'Instagram'),
            iconColor: const Color(0xFFE1306C),
          ),
          const SizedBox(height: 10),
          _ContactRow(
            icon: Icons.email_rounded,
            label: 'danilocordeirojardim@gmail.com',
            onTap: () =>
                _copyToClipboard('danilocordeirojardim@gmail.com', 'E-mail'),
            iconColor: const Color(0xFF52B788),
          ),
          const SizedBox(height: 10),
          _ContactRow(
            icon: Icons.phone_rounded,
            label: '(21) 98904-6824',
            onTap: () => _copyToClipboard('(21) 98904-6824', 'Telefone'),
            iconColor: const Color(0xFF25D366),
          ),
          const SizedBox(height: 10),
          _ContactRow(
            icon: Icons.phone_rounded,
            label: '(21) 97738-7388',
            onTap: () => _copyToClipboard('(21) 97738-7388', 'Telefone'),
            iconColor: const Color(0xFF25D366),
          ),
        ],
      ),
    );
  }
}

class _ContactRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color iconColor;

  const _ContactRow({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      splashColor: Colors.white.withAlpha(26),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(26),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withAlpha(38)),
        ),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: iconColor.withAlpha(51),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: iconColor, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 13,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const Icon(Icons.copy_rounded, color: Colors.white38, size: 14),
          ],
        ),
      ),
    );
  }
}
