import '../../../core/app_export.dart';

class _ServiceItem {
  final String title;
  final String description;
  final IconData icon;
  final Color accentColor;
  final String imageUrl;
  final String semanticLabel;

  const _ServiceItem({
    required this.title,
    required this.description,
    required this.icon,
    required this.accentColor,
    required this.imageUrl,
    required this.semanticLabel,
  });
}

class HomeServicesWidget extends StatelessWidget {
  final VoidCallback onBookTap;

  const HomeServicesWidget({required this.onBookTap, super.key});

  static const List<_ServiceItem> _services = [
    _ServiceItem(
      title: 'Paisagismo',
      description: 'Projeto e execução de jardins e áreas verdes',
      icon: Icons.park_rounded,
      accentColor: Color(0xFF2D6A4F),
      imageUrl:
          'https://images.pexels.com/photos/1105019/pexels-photo-1105019.jpeg?auto=compress&cs=tinysrgb&w=400',
      semanticLabel:
          'Beautiful green landscaped garden with trimmed bushes and colorful flowers',
    ),
    _ServiceItem(
      title: 'Corte de Grama',
      description: 'Manutenção e corte de gramados residenciais',
      icon: Icons.grass_rounded,
      accentColor: Color(0xFF40916C),
      imageUrl:
          'https://images.pixabay.com/photo/2017/08/01/11/48/blue-2564660_640.jpg',
      semanticLabel:
          'Freshly cut green lawn with clean edges in residential garden',
    ),
    _ServiceItem(
      title: 'Poda',
      description: 'Poda técnica de árvores, arbustos e cercas vivas',
      icon: Icons.content_cut_rounded,
      accentColor: Color(0xFF1B4332),
      imageUrl:
          'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&q=80',
      semanticLabel:
          'Professional pruning of hedges and shrubs with clean geometric shapes',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Nossos Serviços',
              style: theme.textTheme.titleLarge?.copyWith(
                color: const Color(0xFF1A2E1F),
                fontWeight: FontWeight.w800,
              ),
            ),
            TextButton(
              onPressed: onBookTap,
              child: Text(
                'Agendar',
                style: TextStyle(
                  color: AppTheme.primary,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Column(
          children: _services
              .map((s) => _ServiceCard(service: s, onBookTap: onBookTap))
              .toList(),
        ),
      ],
    );
  }
}

class _ServiceCard extends StatelessWidget {
  final _ServiceItem service;
  final VoidCallback onBookTap;

  const _ServiceCard({required this.service, required this.onBookTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border(left: BorderSide(color: service.accentColor, width: 4)),
        boxShadow: [
          BoxShadow(
            color: service.accentColor.withAlpha(20),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onBookTap,
          borderRadius: BorderRadius.circular(16),
          splashColor: service.accentColor.withAlpha(20),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: CustomImageWidget(
                    imageUrl: service.imageUrl,
                    width: 64,
                    height: 64,
                    fit: BoxFit.cover,
                    semanticLabel: service.semanticLabel,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        service.title,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1A2E1F),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        service.description,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xFF5A7A65),
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: service.accentColor.withAlpha(26),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    Icons.arrow_forward_rounded,
                    color: service.accentColor,
                    size: 16,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
