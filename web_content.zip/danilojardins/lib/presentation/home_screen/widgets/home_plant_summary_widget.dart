import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/status_badge_widget.dart';

class HomePlantSummaryWidget extends StatelessWidget {
  final VoidCallback onViewAll;

  const HomePlantSummaryWidget({required this.onViewAll, super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Minhas Plantas',
              style: theme.textTheme.titleLarge?.copyWith(
                color: const Color(0xFF1A2E1F),
                fontWeight: FontWeight.w800,
              ),
            ),
            TextButton(
              onPressed: onViewAll,
              child: Text(
                'Ver todas',
                style: TextStyle(
                  color: AppTheme.primary,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        // Summary row
        Row(
          children: [
            _SummaryChip(
              count: 2,
              label: 'Regar hoje',
              color: AppTheme.warning,
              icon: Icons.water_drop_rounded,
            ),
            const SizedBox(width: 8),
            _SummaryChip(
              count: 5,
              label: 'Saudáveis',
              color: AppTheme.success,
              icon: Icons.favorite_rounded,
            ),
            const SizedBox(width: 8),
            _SummaryChip(
              count: 1,
              label: 'Atrasado',
              color: AppTheme.error,
              icon: Icons.warning_amber_rounded,
            ),
          ],
        ),
        const SizedBox(height: 14),
        // Quick plant cards
        _PlantQuickCard(
          name: 'Samambaia',
          species: 'Nephrolepis exaltata',
          status: PlantStatus.needsWater,
          lastWatered: 'Há 2 dias',
          emoji: '🌿',
        ),
        const SizedBox(height: 8),
        _PlantQuickCard(
          name: 'Orquídea Rosa',
          species: 'Phalaenopsis sp.',
          status: PlantStatus.overdue,
          lastWatered: 'Há 5 dias',
          emoji: '🌸',
        ),
        const SizedBox(height: 8),
        _PlantQuickCard(
          name: 'Espada de São Jorge',
          species: 'Sansevieria trifasciata',
          status: PlantStatus.healthy,
          lastWatered: 'Ontem',
          emoji: '🌱',
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: onViewAll,
            icon: const Icon(Icons.eco_rounded, size: 16),
            label: const Text('Gerenciar Plantas'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppTheme.primary,
              side: const BorderSide(color: AppTheme.primary, width: 1.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
      ],
    );
  }
}

class _SummaryChip extends StatelessWidget {
  final int count;
  final String label;
  final Color color;
  final IconData icon;

  const _SummaryChip({
    required this.count,
    required this.label,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: color.withAlpha(26),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withAlpha(51)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(height: 4),
            Text(
              '$count',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: color,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: color.withAlpha(204),
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
            ),
          ],
        ),
      ),
    );
  }
}

class _PlantQuickCard extends StatelessWidget {
  final String name;
  final String species;
  final PlantStatus status;
  final String lastWatered;
  final String emoji;

  const _PlantQuickCard({
    required this.name,
    required this.species,
    required this.status,
    required this.lastWatered,
    required this.emoji,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withAlpha(15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.primaryContainer.withAlpha(102),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(emoji, style: const TextStyle(fontSize: 20)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1A2E1F),
                  ),
                ),
                Text(
                  species,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF5A7A65),
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              StatusBadgeWidget.plantStatus(status),
              const SizedBox(height: 3),
              Text(
                lastWatered,
                style: const TextStyle(fontSize: 10, color: Color(0xFF8AAA95)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
