import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';
import './widgets/home_contact_widget.dart';
import './widgets/home_hero_widget.dart';
import './widgets/home_plant_summary_widget.dart';
import './widgets/home_services_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // TODO: Replace with [Riverpod/Bloc] for production

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: HomeHeroWidget()),
          SliverToBoxAdapter(
            child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 24),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: HomeServicesWidget(
            onBookTap: () => context.go(AppRoutes.serviceBookingScreen),
          ),
        ),
        const SizedBox(height: 24),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: HomePlantSummaryWidget(
            onViewAll: () => context.go(AppRoutes.plantCareScreen),
          ),
        ),
        const SizedBox(height: 24),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: const HomeContactWidget(),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 6,
            child: Column(
              children: [
                HomeServicesWidget(
                  onBookTap: () => context.go(AppRoutes.serviceBookingScreen),
                ),
                const SizedBox(height: 24),
                const HomeContactWidget(),
              ],
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            flex: 4,
            child: HomePlantSummaryWidget(
              onViewAll: () => context.go(AppRoutes.plantCareScreen),
            ),
          ),
        ],
      ),
    );
  }
}
