مشروع تطبيق جرد محل الموبايلات لنظام Android

هذا مشروع Android Studio يحتوي على نسخة HTML داخل التطبيق، وليس ملف APK مبنيًا بعد.

لإنشاء APK:
1) فك ضغط الملف ZIP.
2) افتح Android Studio واختر Open ثم مجلد JardMobileAPK.
3) انتظر انتهاء Gradle Sync وتنزيل مكونات Android المطلوبة.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف غالبًا في app/build/outputs/apk/debug/app-debug.apk.

ملاحظة الحفظ: الجرد محفوظ محليًا داخل بيانات التطبيق/المتصفح. حذف التطبيق أو بياناته قد يمسح الجرد؛ استخدم تصدير CSV للاحتفاظ بنسخة احتياطية.
