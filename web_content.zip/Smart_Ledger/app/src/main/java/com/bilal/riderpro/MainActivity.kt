package com.bilal.riderpro

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.util.Base64

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 9, 11)
        window.navigationBarColor = android.graphics.Color.rgb(8, 9, 11)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun authenticateBiometric(accountId: String) {
            runOnUiThread {
                val manager = BiometricManager.from(this@MainActivity)
                val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
                if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
                    webView.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false, ${org.json.JSONObject.quote(accountId)})", null)
                    Toast.makeText(this@MainActivity, "Set up fingerprint or device screen lock first", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                val prompt = BiometricPrompt(this@MainActivity, ContextCompat.getMainExecutor(this@MainActivity), object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { super.onAuthenticationSucceeded(result); webView.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(true, ${org.json.JSONObject.quote(accountId)})", null) }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { super.onAuthenticationError(errorCode, errString); webView.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false, ${org.json.JSONObject.quote(accountId)})", null) }
                })
                val info = BiometricPrompt.PromptInfo.Builder().setTitle("Smart Ledger").setSubtitle("Verify to unlock your private account").setAllowedAuthenticators(authenticators).build()
                prompt.authenticate(info)
            }
        }
        private fun decode(dataUrl: String): ByteArray {
            val encoded = dataUrl.substringAfter(",", "")
            return if (Build.VERSION.SDK_INT >= 26) Base64.getDecoder().decode(encoded)
                   else android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
        }

        @JavascriptInterface
        fun saveImage(dataUrl: String) {
            try {
                val bytes = decode(dataUrl)
                val name = "Bilal-Rider-Pro-${System.currentTimeMillis()}.png"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Smart Ledger")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                runOnUiThread { Toast.makeText(this@MainActivity, if (uri != null) "Receipt saved in Gallery / Pictures" else "Could not save image", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Image save failed", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface
        fun shareImage(dataUrl: String) {
            try {
                val bytes = decode(dataUrl)
                val file = File(cacheDir, "Bilal-Rider-Pro-Receipt.png")
                FileOutputStream(file).use { it.write(bytes) }
                val uri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TITLE, "Smart Ledger Receipt")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { startActivity(Intent.createChooser(intent, "Share receipt")) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Could not share receipt", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
