/* ================== config.js — الإعدادات العامة والأدوات ==================
   كل ملفات اللعبة تتشارك كائناً واحداً اسمه G                              */
window.G={};
(function(G){
'use strict';

G.W=320; G.H=180;      // دقة اللعبة الداخلية (بكسل)
G.GY=150;              // مستوى الأرض
G.GRAV=700;            // الجاذبية

// أرقام تقدر تعدلها بسهولة لتغيير صعوبة اللعبة واقتصادها
G.CFG={
  playerHp:100,        // صحة اللاعب الأساسية
  hpPerLevel:8,        // صحة إضافية لكل مستوى شخصية
  dmgPerLevel:0.03,    // ضرر إضافي (3%) لكل مستوى شخصية
  maxLevel:25,         // أعلى مستوى للشخصية (يتغير الشكل كل 5 مستويات)
  wpnUpDmg:0.10,       // ضرر إضافي (10%) لكل مستوى سلاح
  wpnMaxLv:10,         // أعلى مستوى للسلاح
  playerSpeed:95, jumpPower:235,
  flasks:3, flaskHeal:40,
  energyMax:100,       // حجم شريط الطاقة الخاصة
  critChance:0.12,     // احتمال الضربة الحرجة
  critMul:1.6,         // مضاعف الضربة الحرجة
  bossHp:1.4,          // مضاعف صحة كل الزعماء (كبّره لتطول المواجهات)
  bossHpGrow:0.08,     // زيادة إضافية في الصحة لكل زعيم تالٍ (8%)
  stages:7,            // عدد مراحل المغامرة قبل كل زعيم
  reviveCost:5,        // ثمن الإحياء بالكريستال
  adReward:3,          // كريستال مقابل مشاهدة إعلان
  testMode:true        // وضع تجريبي: الإعلانات والشراء وهمية (غيّرها إلى false عند ربط متجر حقيقي)
};

// ألوان العناصر: [غامق، أساسي، فاتح، لمعة]
G.ELEM={
  fire:  ['#7a2a0a','#c2410c','#ffb347','#fff2c0'],
  ice:   ['#12406a','#2a7fc0','#8fd8ff','#ffffff'],
  poison:['#12400a','#2f8a1c','#9be04a','#f0ffc0'],
  dark:  ['#2a0a4a','#6a1cb0','#c07aff','#ffffff'],
  blood: ['#4a0008','#a0101c','#ff4a4a','#ffd0d0'],
  bolt:  ['#4a4a0a','#c0b01c','#ffe866','#ffffff']
};

// حالة اللعبة العامة
G.S={game:'menu',   // menu | play | dead | win
     mode:'boss',   // boss = قتال زعيم · stage = مرحلة مغامرة
     boss:0,        // رقم الفصل/الزعيم الحالي
     node:0,        // 0..6 مرحلة مغامرة · 7 الزعيم
     time:0, elapsed:0, shake:0, freeze:0, flash:0, slow:0, deadT:0, msgAt:0,
     gotCoins:0, gotCrys:0, viewChar:0};

// القوائم المشتركة
G.parts=[]; G.fx=[]; G.ghosts=[]; G.shots=[];
G.flames=[]; G.waves=[]; G.eshots=[]; G.drops=[];
G.enemies=[]; G.picks=[];
G.keys={l:false,r:false}; G.kb={l:false,r:false};
G.buf={jump:0,atk:0,dodge:0,heal:0,sp:0,skill:0};
G.P=null; G.B=null; G.room=null;
G.L=null;              // المرحلة الحالية (null في قتال الزعيم)
G.cam={x:0};           // الكاميرا
G.worldW=()=>G.L?G.L.w:G.W;

// أدوات
G.$=id=>document.getElementById(id);
G.R=(a,b)=>a+Math.random()*(b-a);
G.clamp=(v,a,b)=>v<a?a:v>b?b:v;
let seed=7;
G.seed=v=>{seed=v;};
G.rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
G.fmt=t=>{const m=Math.floor(t/60), s=Math.floor(t%60);return m+':'+(s<10?'0':'')+s;};

})(window.G);
