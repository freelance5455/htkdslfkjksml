/* ================== weapons.js — الأسلحة وضرباتها الخاصة ==================
   لكل سلاح: ضربة عادية + ضربة خاصة مختلفة (تُفعَّل عند امتلاء شريط الطاقة)        */
(function(G){
'use strict';
const W=G.W, GY=G.GY, R=G.R, clamp=G.clamp, r=G.r, pl=G.pl;
const shots=G.shots, S=G.S;

// price=الثمن بالذهب · dmg=الضرر · dur=مدة الضربة · hits=نوافذ الإصابة [بداية،نهاية] · reach=المدى · en=الطاقة المكتسبة
G.WEAPONS=[
  {id:'sword', name:'سيف',   sp:'هلال النور',   price:0,   dmg:12,dur:0.30,hits:[[0.06,0.20]],reach:27,en:9, col:'#dfe9ff'},
  {id:'dual',  name:'سيفان', sp:'عاصفة النصال', price:300, dmg:7, dur:0.34,hits:[[0.03,0.13],[0.17,0.29]],reach:25,en:6,col:'#ff8ad0'},
  {id:'axe',   name:'فأس',   sp:'الزلزال',      price:500, dmg:30,dur:0.62,hits:[[0.30,0.44]],reach:26,en:18,col:'#ffb347',heavy:true,slow:0},
  {id:'spear', name:'رمح',   sp:'الاختراق',     price:400, dmg:14,dur:0.40,hits:[[0.12,0.26]],reach:44,en:10,col:'#7fd4ff'},
  {id:'scythe',name:'منجل',  sp:'دوامة الموت',  price:1500, dmg:20,dur:0.50,hits:[[0.20,0.36]],reach:36,back:12,en:14,col:'#b6ff7a',leech:2,slow:12},
  {id:'chain', name:'زنجير', sp:'قيد البرق',    price:1200, dmg:10,dur:0.44,hits:[[0.16,0.32]],reach:64,en:9, col:'#ffe066',slow:10},
  {id:'bow',   name:'قوس',   sp:'وابل السهام',  price:600, dmg:9, dur:0.42,fire:0.22,ranged:true,en:7,col:'#9be07a'},
  {id:'ninja', name:'نينجا', sp:'ظل القاتل',    price:800, dmg:6, dur:0.20,fire:0.05,ranged:true,en:5,col:'#c08cff'},
  {id:'staff', name:'عصا سحرية',sp:'النيزك',     price:0,   dmg:11,dur:0.38,fire:0.16,ranged:true,en:8,col:'#ff9a4a'},
  {id:'hammer',name:'مطرقة', sp:'مطرقة الرعد',  price:0,   dmg:34,dur:0.72,hits:[[0.36,0.50]],reach:28,en:20,col:'#8fd8ff',heavy:true,slow:0}
];
// سلاح اللاعب = سلاح شخصيته المختارة
G.syncWeapon=function(){
  const c=G.char();
  G.save.wpn=Math.max(0,G.WEAPONS.findIndex(w=>w.id===c.wpn));
};
const WEAPONS=G.WEAPONS;
G.syncWeapon();

/* ---------- الأهداف: الزعيم + وحوش المرحلة ---------- */
function open(t){return t.isEnemy?(t.state!=='dead'&&t.al>0.5):G.bossOpen(t);}
function box(t){return G.bossBox(t);}
G.targets=function(){
  const a=[];
  if(G.B&&open(G.B))a.push(G.B);
  for(const e of G.enemies)if(open(e))a.push(e);
  return a;
};
// هل الهدف داخل مدى الضربة؟
G.inRangeT=function(t,front,back){
  const p=G.P, hw=t.def.hw;
  const x0=p.x-p.f*(back||0), x1=p.x+p.f*front;
  const a=Math.min(x0,x1), b=Math.max(x0,x1), bx=box(t);
  return b>t.x-hw&&a<t.x+hw&&bx.bot>p.y-46&&bx.top<p.y+4;
};
function hitY(t){const b=box(t);return clamp(G.P.y-14,b.top+4,b.bot-3);}
function hitX(t,reach){const p=G.P;return clamp(p.x+p.f*(reach-7),t.x-t.def.hw+1,t.x+t.def.hw-1);}
// أقرب هدف (face=true: أمام اللاعب فقط)
function nearest(maxD,face){
  const p=G.P; let best=null, bd=maxD;
  for(const t of G.targets()){
    const dx=t.x-p.x, d=Math.abs(dx);
    if(face&&dx*p.f<0&&d>t.def.hw+12)continue;
    if(d<bd){bd=d;best=t;}
  }
  return best;
}

/* ---------- إصابة هدف ---------- */
G.hitT=function(t,base,x,y,en,heavy,col,canCrit){
  const p=G.P;
  if(t.state==='dead')return;
  const crit=canCrit&&Math.random()<G.critChance();
  let d=Math.max(1,Math.round(base*G.dmgMul()*G.wpnMul(WEAPONS[p.aw].id)*(crit?G.CFG.critMul:1)));
  // المدرّع يصدّ الضربات الخفيفة من الأمام
  let blocked=false;
  if(t.isEnemy&&t.shield&&!heavy&&!p.pierce&&t.stun<=0&&(p.x-t.x)*t.f>0){d=Math.max(1,Math.round(d*0.4));blocked=true;}
  p.combo=(p.comboT>0?p.combo:0)+1; p.comboT=2.2;
  if(en){
    const was=p.en, max=G.CFG.energyMax;
    p.en=Math.min(max,p.en+en*G.enMul()*(1+Math.min(p.combo,10)*0.05));
    if(was<max&&p.en>=max){G.snd('energy');G.ring(p.x,p.y-12,24,'#ffd76a',0.4);}
  }
  t.hp-=d; t.flash=heavy?0.16:0.1;
  if(p.rage>0&&p.hp>0)p.hp=Math.min(G.maxHp(),p.hp+Math.max(1,Math.round(d*0.06)));   // الهيجان يمتص الصحة
  if(G.save.char==='reaper'&&p.hp>0)p.hp=Math.min(G.maxHp(),p.hp+Math.max(1,Math.round(d*0.04)));   // ظمأ الحاصد
  if(G.save.char==='warden'&&t.isEnemy&&t.hp>0&&Math.random()<0.15)G.stunEnemy(t,0.8);            // قبضة السجّان
  if(!t.isEnemy&&G.bossNote)G.bossNote('hit');
  const big=heavy||crit;
  S.freeze=Math.max(S.freeze,heavy?0.11:(crit?0.08:0.05));
  S.shake=Math.max(S.shake,heavy?5:(crit?4:2.5));
  // تأثير الضربة: شرر + نجمة ارتطام + حلقة + خط قطع + رقم الضرر
  G.spark(x,y,'#fff2c0',big?14:7,big?150:110);
  G.spark(x,y,col,big?8:4,90);
  if(!blocked){G.spark(x,y,t.def.blood||'#b3202e',big?6:3,70);G.blood(x,y,t.def.blood||'#b3202e',big?5:2);}   // قطرات تترك بقعاً على الأرض
  G.fxAdd({k:'star',x,y,max:0.16,s:big?13:8});
  G.ring(x,y,big?26:15,col,0.25);
  G.fxAdd({k:'cut',x,y,max:0.2,a:R(-0.9,0.9),s:big?22:14});
  G.fxAdd({k:'num',x:x+R(-6,6),y:y-8,max:crit?0.9:0.7,v:crit?d+'!':d,big:big,c:blocked?'#8a93a6':(crit?'#ff5a4a':null)});
  if(blocked)G.snd('clang');
  if(crit){G.snd('crit');S.flash=Math.max(S.flash,0.08);}
  if(heavy){G.snd('heavy');G.buzz(30);}
  else{G.snd('hit');G.sfx(300+Math.min(p.combo,12)*35,0.05,'triangle',0.03);}
  if(t.hp<=0){t.hp=0;if(t.isEnemy)G.killEnemy(t);else G.killBoss();}
  else if(t.isEnemy)G.staggerEnemy(t,big);
};

/* ---------- الضرر المستمر: نزيف، سم، حرق ---------- */
G.addDot=function(t,d,n,c){t.dot={d:d,n:n,t:0.5,c:c};};
G.updDots=function(dt){
  for(const t of G.targets()){
    const o=t.dot; if(!o)continue;
    o.t-=dt;
    if(o.t<=0){
      o.t=0.5; o.n--;
      const bx=box(t), d=Math.max(1,Math.round(o.d*G.dmgMul()));
      t.hp-=d; t.flash=0.05;
      G.fxAdd({k:'num',x:t.x+R(-6,6),y:bx.top+6,v:d,c:o.c,max:0.6});
      G.spark(t.x+R(-4,4),R(bx.top,bx.bot),o.c,2,40);
      if(o.n<=0)t.dot=null;
      if(t.hp<=0){t.hp=0;t.dot=null;if(t.isEnemy)G.killEnemy(t);else G.killBoss();}
    }
  }
};

/* ---------- المقذوفات: سهام، نجوم نينجا، موجة الطاقة ---------- */
G.fireShot=function(w,fan){
  const p=G.P, m=G.rangedMul()*(p.fin?1.6:1), n=fan?3:1;
  for(let i=0;i<n;i++){
    const a=(i-(n-1)/2)*0.16;
    if(w.id==='staff')
      shots.push({k:'orb',x:p.x+p.f*9,y:p.y-15,vx:p.f*230*Math.cos(a),vy:230*Math.sin(a),g:0,life:0.8,dmg:w.dmg*(p.fin?1.6:1),en:w.en,c:w.col,rot:0,crit:true,burn:fan});
    else if(w.id==='bow')
      shots.push({k:'arrow',x:p.x+p.f*9,y:p.y-13,vx:p.f*340*Math.cos(a),vy:-16+340*Math.sin(a),g:60,life:1.3,dmg:w.dmg*m,en:w.en,c:w.col,rot:0,crit:true});
    else
      shots.push({k:'star',x:p.x+p.f*7,y:p.y-13,vx:p.f*270*Math.cos(a),vy:270*Math.sin(a),g:0,life:0.5,dmg:w.dmg*m,en:w.en,c:w.col,rot:0,crit:true,poison:fan});
  }
  G.snd(w.id==='bow'?'arrow':(w.id==='staff'?'bolt':'sw_ninja'));
};
function p0(){return G.P;}
// المقذوف يظهر خارجاً من يد الشخصية أو رأس سلاحها، ثم ينزل بنعومة إلى مساره الحقيقي
// (مسار الإصابة لا يتغير، فالسهام والكرات تصيب الوحوش القصيرة كما كانت)
function initShot(s){
  if(s.init)return; s.init=1;
  if(s.k!=='arrow'&&s.k!=='orb'&&s.k!=='star')return;
  const p=G.P, h=p&&G.spriteHand&&G.spriteHand(p);
  if(!h||Math.abs(s.x-p.x)>16||Math.abs(s.y-p.y)>24)return;
  s.ox=p.x+p.f*h[0]-s.x; s.oy=p.y+h[1]-s.y;
}
function hitsWall(s){
  const L=G.L; if(!L)return false;
  for(const g of L.gates)if(!g.open&&Math.abs(s.x-g.x)<5)return true;
  for(const w of L.walls)if(s.x>w.x0&&s.x<w.x1&&s.y>w.top)return true;
  return false;
}
// السهام والنجوم تنغرز في الأرض أو الجدار، وكرات النار تترك أثر حرق
function landShot(s,wall){
  const m=Math.hypot(s.vx,s.vy)||1;
  if(s.k==='arrow'||s.k==='rainA'||s.k==='star')G.stick(s.x,s.y,s.vx/m,s.vy/m,s.k==='star'?'star':'arrow',wall);
  else if(s.k==='orb'&&!wall)G.scorch(s.x);
}
G.updShots=function(dt){
  const cx=G.cam.x;
  for(let i=shots.length-1;i>=0;i--){
    const s=shots[i];
    initShot(s);
    if(s.hom){          // الأرواح تلاحق أقرب عدو
      let best=null, bd=260;
      for(const t of G.targets()){const d=Math.abs(t.x-s.x);if(d<bd){bd=d;best=t;}}
      if(best){
        const bx=box(best), dx=best.x-s.x, dy=(bx.top+bx.bot)/2-s.y, m=Math.hypot(dx,dy)||1;
        s.vx+=dx/m*s.hom*dt; s.vy+=dy/m*s.hom*dt;
        const v=Math.hypot(s.vx,s.vy); if(v>190){s.vx*=190/v;s.vy*=190/v;}
      }
      if(Math.random()<0.6)G.puff(s.x,s.y,'#8affc0');
    }
    s.life-=dt; s.vy+=s.g*dt; s.x+=s.vx*dt; s.y+=s.vy*dt; s.rot+=dt*28;
    if(s.ox||s.oy){const f=Math.max(0,1-dt*11);s.ox*=f;s.oy*=f;if(Math.abs(s.ox)<0.4&&Math.abs(s.oy)<0.4)s.ox=s.oy=0;}
    const wave=s.k==='wave', met=s.k==='meteor';
    if(met&&Math.random()<0.8)G.spark(s.x,s.y-6,'#ffb347',1,40);
    if(wave&&Math.random()<0.9)G.spark(s.x,GY-R(0,40),s.c,1,50);
    let gone=false;
    for(const t of G.targets()){
      if(s.hitL&&s.hitL.indexOf(t)>=0)continue;
      const bx=box(t), hw=t.def.hw;
      const hit=wave?(Math.abs(s.x-t.x)<hw+6&&bx.bot>GY-34)
                    :(Math.abs(s.x-t.x)<hw+(met?10:1)&&s.y>bx.top&&s.y<=bx.bot+2);
      if(!hit)continue;
      if(wave){
        S.flash=0.3; if(!t.isEnemy)S.slow=0.35;
        G.ring(s.x,s.y-10,t.isEnemy?40:70,s.c,0.45);
        for(let j=0;j<(t.isEnemy?6:16);j++)G.spark(t.x+R(-8,8),R(bx.top,bx.bot),'#fff2c0',1,160);
      }
      G.hitT(t,s.dmg,clamp(s.x,t.x-hw+1,t.x+hw-1),wave?(bx.top+bx.bot)/2:s.y,s.en,wave||met,s.c,s.crit);
      if(s.burn&&t.hp>0)G.addDot(t,3,5,'#ffb347');
      if(s.k==='soul'&&p0().hp>0){p0().hp=Math.min(G.maxHp(),p0().hp+4);G.puff(p0().x,p0().y-20,'#4fd08a');}
      if(met){G.ring(s.x,s.y,24,'#ffb347',0.3);S.shake=Math.max(S.shake,4);G.snd('thud');}
      if(s.poison&&t.hp>0)G.addDot(t,2,6,'#9be04a');
      if((wave||s.k==='cres')&&t.isEnemy){(s.hitL=s.hitL||[]).push(t);}   // الموجة تخترق الوحوش
      else{gone=true;break;}
    }
    if(!gone&&G.L&&G.levelShot(s)){gone=true;if(hitsWall(s))landShot(s,true);}
    if(gone){shots.splice(i,1);continue;}
    if(met&&s.y>=GY){G.ring(s.x,GY-2,22,'#ffb347',0.3);G.spark(s.x,GY-3,'#ffb347',10,110);S.shake=Math.max(S.shake,3);G.snd('thud');}
    const onFloor=!wave&&!met&&s.y>=GY&&(!G.L||G.hasSupport(s.x,GY));
    if(onFloor||s.life<=0||s.x<cx-4||s.x>cx+W+4||s.y>=GY+(G.L&&!met?40:0)){
      if(onFloor){s.y=GY;landShot(s,false);}
      if(!wave&&s.y<GY+4)G.spark(s.x,Math.min(s.y,GY-1),'#8f8468',2,40);
      shots.splice(i,1);
    }
  }
};
G.drawShots=function(){
  for(const s0 of shots){
    initShot(s0);
    const s=(s0.ox||s0.oy)?Object.assign({},s0,{x:s0.x+(s0.ox||0),y:s0.y+(s0.oy||0)}):s0;
    const d=s.vx>=0?1:-1;
    if(s.k==='orb'||s.k==='soul'){          // كرة العصا / روح الحاصد
      const c2=s.k==='soul'?'#8affc0':s.c, fl=(S.time*20|0)%2;
      G.glow(c2,s.x,s.y,0.9,0.6);
      r(s.x-3,s.y-2,6,4,c2); r(s.x-2,s.y-3,4,6,c2); r(s.x-1,s.y-1,2,2,'#ffffff');
      G.alpha(0.5); r(s.x-d*7-fl,s.y-1,4,2,c2); r(s.x-d*11,s.y,3,1,c2); G.alpha(1);
      if(s.k==='soul'){r(s.x-2,s.y-1,1,1,'#081410');r(s.x+1,s.y-1,1,1,'#081410');}
    }else if(s.k==='meteor'){
      G.glow('#ff7a2a',s.x,s.y,1,1);
      for(let i=1;i<=5;i++){G.alpha(0.6-i*0.1);r(s.x-3+i*0.4-s.vx*0.01*i,s.y-i*6,6-i,5,i%2?'#ffb347':'#c2410c');}
      G.alpha(1);
      r(s.x-4,s.y-3,8,6,'#7a2a0a'); r(s.x-3,s.y-4,6,8,'#c2410c'); r(s.x-2,s.y-2,4,4,'#ffb347'); r(s.x-1,s.y-1,2,2,'#fff2c0');
    }else if(s.k==='cres'){       // هلال صغير (خاتمة كومبو السيف)
      for(let i=0;i<=8;i++){const c=Math.sin(i/8*Math.PI);G.alpha(0.9);r(s.x+d*c*5-1,s.y-12+i*3,3,3,i%2?s.c:'#ffffff');}
      G.alpha(1); G.glow('#dfe9ff',s.x,s.y,0.6,0.6);
    }else if(s.k==='arrow'||s.k==='rainA'){
      const m=Math.hypot(s.vx,s.vy)||1, ux=s.vx/m, uy=s.vy/m;
      pl(s.x-ux*9,s.y-uy*9,s.x,s.y,'#b08a55');
      r(s.x-1,s.y-1,3,3,'#dfe6f5'); r(s.x,s.y,1,1,'#ffffff');
      r(s.x-ux*9-1,s.y-uy*9-1,3,2,'#9b2335');
      G.alpha(0.35); pl(s.x-ux*20,s.y-uy*20,s.x-ux*10,s.y-uy*10,s.k==='rainA'?s.c:'#ffffff'); G.alpha(1);
    }else if(s.k==='star'){
      const ca=Math.cos(s.rot)*3, sa=Math.sin(s.rot)*3;
      pl(s.x-ca,s.y-sa,s.x+ca,s.y+sa,'#dfe6f5');
      pl(s.x+sa,s.y-ca,s.x-sa,s.y+ca,'#dfe6f5');
      r(s.x,s.y,1,1,'#3a3346');
      G.alpha(0.3); r(s.x-d*10,s.y,8,1,s.c); G.alpha(1);
    }else{
      // موجة الطاقة (هلال كبير)
      G.glow('#ffe6a0',s.x,GY-24,1); G.glow('#ffe6a0',s.x,GY-2,1);
      for(let i=0;i<=15;i++){
        const yy=GY-3-i*3, c=Math.sin(i/15*Math.PI), xx=s.x+d*c*11;
        G.alpha(0.5); r(xx-d*9-3,yy,7,3,s.c);
        G.alpha(1);   r(xx-d*4-2,yy,5,3,s.c);
        r(xx-1,yy,3,3,'#ffffff');
      }
    }
  }
};

/* ---------- الضربة العادية + الكومبو ----------
   ثلاث ضربات متتالية: الثالثة «خاتمة» أقوى ولها تأثير خاص بكل سلاح.
   وبعد أي ضربة خاصة، أول ضربة عادية تكون خاتمة مباشرة (كومبو الضربة الخاصة).   */
G.FIN_NAMES={sword:'هلال قاطع',dual:'نزيف',axe:'صدمة أرضية تشلّ',spear:'طعنة تخترق الدروع',scythe:'جذب وامتصاص',chain:'برق متسلسل',bow:'ثلاثة سهام',ninja:'نجوم مسمومة',staff:'ثلاث كرات حارقة',hammer:'دكّة تشلّ طويلاً'};
G.startAttack=function(p){
  p.cs=p.csT>0?(p.cs+1)%3:0;
  p.fin=p.cs===2;
  p.state='attack'; p.t=0; p.hn=0; p.sw=0; p.hit=false; p.thud=false; p.aw=p.w; p.hitL=[]; p.struck=false; p.finDone=false;
  p.pierce=p.fin&&WEAPONS[p.aw].id==='spear';
  G.snd('sw_'+WEAPONS[p.aw].id);
  if(p.fin){G.sfx(880,0.1,'triangle',0.04,440);G.ring(p.x,p.y-12,16,WEAPONS[p.aw].col,0.2);}
};
// تأثير الخاتمة العام (مرة واحدة عند بدء نافذة الإصابة)
function finisher(p,w){
  const id=w.id, col=w.col;
  G.fxAdd({k:'arc',x:p.x+p.f*6,y:p.y-13,s:w.reach*0.7,a0:1.7,a1:-1.5,d:p.f,c:col,max:0.22});
  S.shake=Math.max(S.shake,3);
  if(id==='sword'){
    shots.push({k:'cres',x:p.x+p.f*12,y:p.y-13,vx:p.f*260,vy:0,g:0,life:0.45,dmg:10,en:3,c:'#dfe9ff',rot:0});
  }else if(id==='axe'){
    G.snd('quake'); S.shake=6;
    for(let i=1;i<=4;i++)G.fxAdd({k:'spike',x:p.x+p.f*(14+i*11),s:20-i*3,c:'#ffb347',max:0.4,t:-i*0.03});
    for(const t of G.targets()){
      if(G.inRangeT(t,62,0)&&box(t).bot>GY-20){spHit(t,12,true);if(t.isEnemy)G.stunEnemy(t,0.9);}
    }
  }else if(id==='hammer'){
    G.snd('quake'); S.shake=8;
    G.ring(p.x+p.f*22,GY-2,40,'#8fd8ff',0.35);
    for(let i=1;i<=5;i++)G.fxAdd({k:'spike',x:p.x+p.f*(12+i*11),s:24-i*3,c:'#8fd8ff',max:0.4,t:-i*0.03});
    for(const t of G.targets()){
      if(G.inRangeT(t,74,6)&&box(t).bot>GY-20){spHit(t,14,true);if(t.isEnemy)G.stunEnemy(t,1.5);}
    }
  }else if(id==='scythe'){
    for(const t of G.targets())if(t.isEnemy&&Math.abs(t.x-p.x)<70&&!t.fly){
      t.x=clamp(t.x+(p.x>t.x?1:-1)*22,t.minX,t.maxX); G.puff(t.x,t.y-10,'#b6ff7a');
    }
    p.hp=Math.min(G.maxHp(),p.hp+5); G.puff(p.x,p.y-20,'#4fd08a');
  }
}
// تأثير الخاتمة على كل هدف تصيبه
function finHit(p,w,t){
  const id=w.id;
  if(id==='dual'&&t.hp>0)G.addDot(t,3,6,'#ff4a4a');
  else if(id==='chain'){
    // البرق يقفز إلى هدفين قريبين (أو يضرب الزعيم مرة ثانية)
    const bx0=box(t); let n=0, from=t;
    for(const o of G.targets()){
      if(o===t||n>=2||Math.abs(o.x-t.x)>90)continue;
      const bo=box(o);
      G.fxAdd({k:'bolt',x:from.x,y:(bx0.top+bx0.bot)/2,x2:o.x,y2:(bo.top+bo.bot)/2,c:'#ffe066',max:0.25});
      spHit(o,8,false,o.x,(bo.top+bo.bot)/2); from=o; n++;
    }
    if(!n&&t.hp>0){G.fxAdd({k:'bolt',x:t.x,y:0,x2:t.x,y2:(bx0.top+bx0.bot)/2,c:'#ffe066',max:0.25});spHit(t,8,false,t.x,(bx0.top+bx0.bot)/2);}
    G.snd('thunder');
  }
}
G.updAttack=function(p,dt){
  const w=WEAPONS[p.aw], fin=p.fin;
  p.t+=dt*(p.rage>0?1.35:1);
  // قوة الضربة: الثانية أقوى قليلاً، والخاتمة أقوى بكثير (وأقوى بعد الضربة الخاصة)
  const mul=fin?(p.spChain?2.1:1.6):(p.cs===1?1.1:1);
  if(w.ranged){
    if(!p.hit&&p.t>=w.fire){p.hit=true;G.fireShot(w,fin);if(fin)G.fxAdd({k:'num',x:p.x,y:p.y-32,v:'x3',big:true,c:w.col,max:0.6});}
  }else{
    const h=w.hits[p.hn];
    if(h&&p.t>h[0]){
      if(p.t<h[1]){
        if(fin&&!p.finDone){p.finDone=true;finisher(p,w);}
        // الضربة تصيب كل من في مداها
        for(const t of G.targets()){
          if(p.hitL.indexOf(t)>=0||!G.inRangeT(t,w.reach+(fin?4:0)+G.reachBonus(),w.back))continue;
          p.hitL.push(t);
          G.hitT(t,w.dmg*mul,hitX(t,w.reach),hitY(t),w.en*(fin?1.5:1),w.heavy||fin,w.col,true);
          if(fin)finHit(p,w,t);
          if(w.leech&&p.hp>0){p.hp=Math.min(G.maxHp(),p.hp+w.leech);G.puff(p.x,p.y-18,'#4fd08a');}
        }
        // وتضرب الأجراس والمصابيح والصناديق في المراحل
        if(!p.struck&&G.L){
          const x0=p.x-p.f*(w.back||0), x1=p.x+p.f*w.reach;
          p.struck=G.levelStrike(Math.min(x0,x1),Math.max(x0,x1),p.y);
        }
      }else{p.hn++;p.hitL=[];p.struck=false;}
    }
    // صوت الضربة الثانية للسيفين
    if(w.hits[1]&&!p.sw&&p.t>=w.hits[1][0]){p.sw=1;G.snd('sw_dual');}
  }
  // ارتطام الفأس أو المطرقة بالأرض
  if((w.id==='axe'||w.id==='hammer')&&!p.thud&&p.t>=w.hits[0][1]){
    p.thud=true; S.shake=Math.max(S.shake,3);
    for(let i=0;i<6;i++)G.puff(p.x+p.f*18+R(-6,6),p.y-1,'#5a564c');
    G.debris(p.x+p.f*18,p.y-2,'#5a564c',3);
    G.snd('thud');
  }
  if(p.t>=w.dur){
    p.state='idle';
    p.csT=fin?0:0.5; p.spChain=false; p.pierce=false;
    if(fin)p.cs=-1;
  }
};

/* ================== الضربات الخاصة (واحدة لكل سلاح) ================== */
function spHit(t,d,heavy,x,y){
  const p=G.P, bx=box(t);
  G.hitT(t,d,x==null?clamp(p.x,t.x-t.def.hw+1,t.x+t.def.hw-1):x,y==null?R(bx.top+4,bx.bot-3):y,0,heavy,WEAPONS[p.aw].col,false);
}
// يضرب كل الأهداف داخل المدى ويرجع عددها
function hitAll(front,back,d,heavy){
  let n=0;
  for(const t of G.targets())if(G.inRangeT(t,front,back)){spHit(t,d,heavy);n++;}
  return n;
}
const SP={
  // السيف: هلال من النور يعبر الساحة
  sword:{dur:0.5,upd(p,s){
    if(Math.random()<0.8)G.puff(p.x+R(-8,8),p.y-R(0,26),'#ffd76a');
    if(!s.f&&p.t>=0.22){
      s.f=1;
      shots.push({k:'wave',x:p.x+p.f*10,y:GY-20,vx:p.f*300,vy:0,g:0,life:1.3,dmg:72,en:0,c:'#dfe9ff',rot:0});
      S.shake=7; S.flash=0.22; G.ring(p.x,p.y-12,60,'#ffd76a',0.4); G.snd('wave'); G.buzz(80);
    }
  }},
  // السيفان: عاصفة من ثماني ضربات سريعة ثم ضربة متقاطعة
  dual:{dur:1.05,upd(p,s,dt){
    p.vx=p.f*50;
    s.n-=dt;
    if(s.n<=0&&p.t<0.85){
      s.n=0.1; s.c=(s.c||0)+1;
      G.snd('sw_dual');
      G.fxAdd({k:'arc',x:p.x+p.f*8,y:p.y-13+R(-6,6),s:R(14,22),a0:s.c%2?1.6:-1.6,a1:s.c%2?-1.4:1.4,d:p.f,c:s.c%2?'#ff8ad0':'#ffffff',max:0.16});
      G.ghosts.push({x:p.x,y:p.y,life:0.15,c:'#ff8ad0'});
      hitAll(36,14,10,false);
    }
    if(!s.f&&p.t>=0.92){
      s.f=1; G.snd('heavy'); S.shake=6;
      const x=p.x+p.f*16, y=p.y-14;
      G.fxAdd({k:'cut',x,y,max:0.3,a:0.8,s:30,c:'#ff8ad0'}); G.fxAdd({k:'cut',x,y,max:0.3,a:-0.8,s:30,c:'#ffffff'});
      hitAll(42,14,24,true);
    }
  }},
  // الفأس: قفزة عالية ثم زلزال يشق الأرض
  axe:{dur:1.5,start(p){p.vy=-285;p.ground=false;G.snd('leap');},
    upd(p,s){
    if(!s.f){
      if(p.vy>0)p.vy+=900*0.016;
      if(p.ground&&p.t>0.15){
        s.f=1; s.end=p.t+0.4;
        S.shake=10; S.flash=0.25; S.slow=0.25; G.snd('quake'); G.buzz(120);
        G.ring(p.x,p.y-2,80,'#ffb347',0.5);
        G.debris(p.x,p.y-2,'#5a564c',12);
        for(let i=1;i<=8;i++)for(const d of [-1,1])G.fxAdd({k:'spike',x:p.x+d*i*13,s:30-i*2.5,c:'#ffb347',max:0.5,t:-i*0.035});
        for(let i=0;i<20;i++)G.puff(p.x+R(-90,90),GY-1,'#5a564c');
        for(const t of G.targets()){
          if(box(t).bot<=GY-30)continue;
          const dx=Math.abs(t.x-p.x)-t.def.hw;
          if(dx<60)spHit(t,88,true); else if(dx<115)spHit(t,46,true);
        }
      }
    }else if(p.t>=s.end)return true;
  }},
  // الرمح: اندفاعة خاطفة تخترق كل من في طريقها
  spear:{dur:0.75,upd(p,s){
    if(p.t<0.22){p.vx=-p.f*18; if(Math.random()<0.7)G.puff(p.x+R(-6,6),p.y-R(4,20),'#7fd4ff');}
    else if(p.t<0.52){
      if(!s.g){s.g=1;G.snd('whoosh');S.shake=4;s.hl=[];}
      p.vx=p.f*520;
      G.ghosts.push({x:p.x,y:p.y,life:0.25,c:'#7fd4ff'});
      G.spark(p.x-p.f*6,p.y-12,'#7fd4ff',1,40);
      for(const t of G.targets())if(s.hl.indexOf(t)<0&&G.inRangeT(t,30,10)){
        s.hl.push(t); S.slow=0.3; S.flash=0.2; spHit(t,80,true); G.snd('thunder');
      }
    }else p.vx=0;
  }},
  // المنجل: دوامة تحصد وتمتص الصحة
  scythe:{dur:1.3,upd(p,s,dt,dir){
    p.vx=dir*50;
    s.n-=dt;
    if(Math.random()<0.6)G.spark(p.x+R(-40,40),p.y-R(0,30),'#b6ff7a',1,40);
    if(s.n<=0){
      s.n=0.14; G.snd('sw_scythe');
      for(const t of G.targets()){
        if(Math.abs(t.x-p.x)<46+t.def.hw&&box(t).bot>p.y-50){
          spHit(t,11,false,clamp(p.x,t.x-t.def.hw,t.x+t.def.hw));
          p.hp=Math.min(G.maxHp(),p.hp+3);
          G.puff(p.x+R(-4,4),p.y-20,'#4fd08a');
        }
      }
    }
  }},
  // الزنجير: صاعقة تشلّ الهدف ثم تسحبك نحوه
  chain:{dur:0.85,upd(p,s,dt){
    if(!s.f&&p.t>=0.18){
      s.f=1;
      let t=nearest(G.B?999:190,true);
      if(t&&G.blockedBetween&&G.blockedBetween(p.x,t.x))t=null;
      if(t){
        s.hit=1; s.tg=t;
        const bx=box(t), by=(bx.top+bx.bot)/2;
        G.fxAdd({k:'bolt',x:p.x+p.f*6,y:p.y-13,x2:t.x,y2:by,c:'#ffe066',max:0.4});
        G.fxAdd({k:'bolt',x:t.x,y:0,x2:t.x,y2:by,c:'#ffe066',max:0.35});
        S.flash=0.25; S.shake=7; G.snd('thunder'); G.buzz(80);
        spHit(t,45,true,t.x,by);
        if(t.isEnemy)G.stunEnemy(t,2.2); else G.stunBoss(1.6);
        s.tx=clamp(t.x-p.f*(t.def.hw+14),10,G.worldW()-10);
      }else{
        p.en=G.CFG.energyMax*0.6;      // أخطأت الهدف: تستعيد جزءاً من الطاقة
        G.fxAdd({k:'num',x:p.x,y:p.y-30,v:'x',max:0.6});
      }
    }
    if(s.hit){
      if(p.t>0.3&&p.t<0.52&&p.ground){
        const nx=p.x+(s.tx-p.x)*Math.min(1,dt*14);
        p.x=G.L?G.moveX(p,nx,dt):nx;
        G.ghosts.push({x:p.x,y:p.y,life:0.15,c:'#ffe066'});
      }
      if(!s.g&&p.t>=0.55){s.g=1;hitAll(40,14,28,true);G.snd('heavy');}
    }else if(s.f&&p.t>0.45)return true;
  }},
  // القوس: وابل من السهام يهطل فوق الهدف
  bow:{dur:0.6,upd(p,s){
    if(!s.f&&p.t>=0.2){
      s.f=1; G.snd('arrow'); G.snd('whoosh');
      const t=nearest(G.B?999:200,true);
      const tx=t?t.x:clamp(p.x+p.f*90,20,G.worldW()-20);
      for(let i=0;i<14;i++){
        shots.push({k:'rainA',x:tx+R(-26,26),y:-12-i*26,vx:R(-8,8),vy:400,g:0,life:3,dmg:8*G.rangedMul(),en:0,c:'#9be07a',rot:0});
      }
      for(let i=0;i<3;i++)G.fxAdd({k:'cut',x:p.x+p.f*(4+i*4),y:p.y-30-i*6,a:-1.2*p.f,s:10,c:'#9be07a',max:0.3});
    }
  }},
  // العصا: نيازك تهوي على العدو وتحرقه
  staff:{dur:0.7,upd(p,s){
    if(Math.random()<0.7)G.puff(p.x+R(-8,8),p.y-R(10,34),'#ffb347');
    if(!s.f&&p.t>=0.25){
      s.f=1; G.snd('cast'); G.snd('whoosh'); S.shake=4;
      const t=nearest(G.B?999:210,true);
      const tx=t?t.x:clamp(p.x+p.f*90,20,G.worldW()-20);
      for(let i=0;i<4;i++)shots.push({k:'meteor',x:tx+R(-24,24),y:-20-i*46,vx:R(-12,12),vy:330,g:0,life:3,dmg:26,en:0,c:'#ff9a4a',rot:0,burn:true});
    }
  }},
  // المطرقة: صواعق تنزل على كل الأعداء القريبين وتشلّهم
  hammer:{dur:0.9,upd(p,s){
    if(!s.f&&p.t>=0.3){
      s.f=1;
      S.shake=10; S.flash=0.3; G.snd('quake'); G.snd('thunder'); G.buzz(120);
      G.ring(p.x,GY-2,90,'#8fd8ff',0.5); G.debris(p.x+p.f*14,GY-2,'#5a564c',10);
      for(const t of G.targets()){
        if(Math.abs(t.x-p.x)>150||(G.blockedBetween&&G.blockedBetween(p.x,t.x)))continue;
        const bx=box(t), by=(bx.top+bx.bot)/2;
        G.fxAdd({k:'bolt',x:t.x+R(-10,10),y:0,x2:t.x,y2:by,c:'#8fd8ff',max:0.4});
        spHit(t,58,true,t.x,by);
        if(t.isEnemy)G.stunEnemy(t,1.6); else G.stunBoss(1.2);
      }
    }
  }},
  // النينجا: يختفي ويظهر خلف الهدف بسبع طعنات
  ninja:{dur:1.0,upd(p,s,dt){
    if(!s.f&&p.t>=0.12){
      s.f=1; G.snd('shadow');
      for(let i=0;i<10;i++)G.puff(p.x+R(-6,6),p.y-R(0,24),'#3a2a55');
      G.ghosts.push({x:p.x,y:p.y,life:0.5,c:'#c08cff'});
      const t=nearest(G.B?999:200,false);
      if(t&&box(t).bot>GY-20&&!(G.blockedBetween&&G.blockedBetween(p.x,t.x))){
        p.x=clamp(t.x-t.f*(t.def.hw+14),10,G.worldW()-10);
        p.y=GY; p.vy=0; p.ground=true;
        p.f=t.x>=p.x?1:-1;
      }
      for(let i=0;i<10;i++)G.puff(p.x+R(-6,6),p.y-R(0,24),'#c08cff');
    }
    if(s.f&&p.t<0.8){
      s.n-=dt;
      if(s.n<=0){
        s.n=0.09; G.snd('sw_ninja');
        for(const t of G.targets())if(G.inRangeT(t,42,20)){
          const bx=box(t);
          G.fxAdd({k:'cut',x:t.x+R(-6,6),y:R(bx.top+4,bx.bot-3),a:R(-1.4,1.4),s:R(16,28),c:'#c08cff',max:0.22});
          spHit(t,11,false);
        }
      }
    }
    if(!s.g&&p.t>=0.85){
      s.g=1;
      if(hitAll(44,20,22,true))S.slow=0.3;
    }
  }}
};
G.startSpecial=function(p,dir){
  if(dir)p.f=dir;
  const id=WEAPONS[p.w].id;
  p.state='special'; p.t=0; p.sp={n:0}; p.en=0; p.aw=p.w;
  p.inv=SP[id].dur+0.25;
  S.freeze=0.1; S.flash=0.15;
  G.ring(p.x,p.y-12,30,'#ffffff');
  G.ring(p.x,p.y-12,46,WEAPONS[p.w].col,0.4);
  G.snd('special');
  if(G.bossNote)G.bossNote('special');
  if(SP[id].start)SP[id].start(p);
};
// ترجع true عند انتهاء الضربة الخاصة
G.updSpecial=function(p,dt,dir){
  const D=SP[WEAPONS[p.aw].id];
  p.t+=dt; p.vx=0;
  const done=D.upd(p,p.sp,dt,dir)===true||p.t>=D.dur;
  if(done){p.cs=1;p.csT=0.7;p.spChain=true;}     // بعدها: ضربة عادية = خاتمة كومبو
  return done;
};

/* ================== رسم الأسلحة (داخل إحداثيات الشخصية) ================== */
function arcTrail(hx,hy,a,rad,amax,col){
  for(let i=1;i<=10;i++){
    const aa=a+i*0.13;
    if(aa>amax)break;
    G.alpha(0.75*(1-i/11));
    r(hx+Math.cos(aa)*rad,hy-Math.sin(aa)*rad,2,2,col);
    r(hx+Math.cos(aa)*(rad-3),hy-Math.sin(aa)*(rad-3),2,2,col);
    r(hx+Math.cos(aa)*(rad-6),hy-Math.sin(aa)*(rad-6),1,1,'#ffffff');
  }
  G.alpha(1);
}
const TIP={x:0,y:0};
function blade(hx,hy,a,len,c){
  const ca=Math.cos(a), sa=-Math.sin(a);
  TIP.x=hx+ca*len; TIP.y=hy+sa*len;
  pl(hx,hy,hx+ca*len,hy+sa*len,c||'#dfe6f5');
  pl(hx,hy,hx+ca*2,hy+sa*2,'#c9a03c');
  r(hx+ca*len,hy+sa*len,1,1,'#ffffff');
}
function drawWeaponBase(p,hx,hy){
  const atk=p.state==='attack', sp=p.state==='special';
  const w=WEAPONS[(atk||sp)?p.aw:p.w], t=p.t, id=w.id, time=S.time;

  if(id==='sword'){
    let a=-0.6;
    if(sp)a=1.45;
    if(atk){a=2.0-clamp(t/0.16,0,1)*2.9; if(t<0.24)arcTrail(hx,hy,a,15,2.1,'#dfe9ff');}
    blade(hx,hy,a,14);
    if(sp){G.alpha(0.6);pl(hx+1,hy,hx+3,hy-15,'#ffd76a');G.alpha(1);}
  }else if(id==='dual'){
    let a1=-0.6, a2=-1.0;
    if(atk){
      a1=2.0-clamp(t/0.11,0,1)*2.9;
      a2=t<0.15?2.2:2.2-clamp((t-0.15)/0.11,0,1)*3.0;
      if(t<0.15)arcTrail(hx,hy,a1,14,2.1,'#ff8ad0'); else if(t<0.3)arcTrail(hx-5,hy+1,a2,14,2.3,'#ffffff');
    }
    if(sp){a1=Math.sin(t*42)*1.7;a2=Math.cos(t*42)*1.7;}
    blade(hx-5,hy+1,a2,13,'#b8c0d4');
    blade(hx,hy,a1,13);
  }else if(id==='axe'){
    let a=1.0;
    if(sp)a=p.sp.f?-0.8:1.7;
    if(atk){
      if(t<0.3)a=1.0+1.5*(t/0.3);
      else{a=2.5-clamp((t-0.3)/0.12,0,1)*3.3; if(t<0.52)arcTrail(hx,hy,a,17,2.6,'#ffb347');}
    }
    const ca=Math.cos(a), sa=-Math.sin(a);
    pl(hx,hy,hx+ca*15,hy+sa*15,'#6b4a2a');
    const tx=hx+ca*14, ty=hy+sa*14;
    TIP.x=tx; TIP.y=ty;
    r(tx-3,ty-3,7,7,'#8a93a6'); r(tx-2,ty-2,5,5,'#c8d0e0');
    r(tx-3,ty-3,7,1,'#ffffff'); r(tx,ty,1,1,'#6b4a2a');
  }else if(id==='spear'){
    let a=0.35, off=-6;
    if(sp){a=0;off=t<0.22?-10:12;}
    if(atk){
      a=0;
      if(t<0.12)off=-6-6*(t/0.12);
      else if(t<0.26)off=12;
      else off=12-18*clamp((t-0.26)/0.14,0,1);
    }
    if((atk&&t>0.12&&t<0.26)||(sp&&t>0.22&&t<0.52)){
      G.alpha(0.6);
      r(hx+10,hy-2,26,1,'#7fd4ff'); r(hx+6,hy+2,28,1,'#7fd4ff'); r(hx+16,hy,24,1,'#ffffff');
      G.alpha(1);
    }
    const ca=Math.cos(a), sa=-Math.sin(a), bx=hx+ca*off, by=hy+sa*off;
    pl(bx,by,bx+ca*24,by+sa*24,'#7a5a34');
    pl(bx+ca*24,by+sa*24,bx+ca*31,by+sa*31,'#dfe6f5');
    r(bx+ca*23-1,by+sa*23-1,2,3,'#9b2335');
    r(bx+ca*31,by+sa*31,1,1,'#ffffff');
    TIP.x=bx+ca*29; TIP.y=by+sa*29;
  }else if(id==='scythe'){
    let a=1.15;
    if(sp)a=-t*24;
    if(atk){
      if(t<0.2)a=1.15+1.3*(t/0.2);
      else{a=2.45-clamp((t-0.2)/0.15,0,1)*3.6; if(t<0.44)arcTrail(hx,hy,a,22,2.5,'#b6ff7a');}
    }
    const ca=Math.cos(a), sa=-Math.sin(a), nx=-sa, ny=ca;
    pl(hx-ca*5,hy-sa*5,hx+ca*18,hy+sa*18,'#5a4630');
    const tx=hx+ca*18, ty=hy+sa*18;
    TIP.x=tx+nx*8-ca*3; TIP.y=ty+ny*8-sa*3;
    pl(tx,ty,tx+nx*6-ca,ty+ny*6-sa,'#dfe6f5',2);
    pl(tx+nx*6-ca,ty+ny*6-sa,tx+nx*11-ca*5,ty+ny*11-sa*5,'#dfe6f5',2);
    pl(tx+nx*11-ca*5,ty+ny*11-sa*5,tx+nx*13-ca*10,ty+ny*13-sa*10,'#b6ff7a');
    r(tx-1,ty-1,2,2,'#8a93a6');
  }else if(id==='chain'){
    if(atk){
      const e=t<0.16?t/0.16*0.25:(t<0.32?0.25+0.75*((t-0.16)/0.16):1-(t-0.32)/0.12);
      const L=Math.max(4,(w.reach-6)*clamp(e,0,1));
      for(let i=0;i<=L;i+=3){
        const y=hy+Math.sin(i*0.35+t*30)*2.5*(1-i/L);
        r(hx+i,y,2,1,(i%6)?'#8a93a6':'#dfe6f5');
      }
      r(hx+L-1,hy-2,5,5,'#c8d0e0'); r(hx+L,hy-1,3,3,'#ffe066');
      r(hx+L+4,hy,1,1,'#ffffff'); r(hx+L+1,hy-3,1,1,'#ffffff'); r(hx+L+1,hy+3,1,1,'#ffffff');
      TIP.x=hx+L+1; TIP.y=hy;
    }else{
      const up=sp?-1:1;
      for(let i=0;i<5;i++)r(hx+1+Math.round(Math.sin(time*3+i*0.8)*(i*0.5)),hy+up*(1+i*2),1,2,i%2?'#8a93a6':'#dfe6f5');
      r(hx-1+Math.round(Math.sin(time*3+4)*2),hy+up*11-1,4,4,'#c8d0e0');
      r(hx+Math.round(Math.sin(time*3+4)*2),hy+up*11,2,2,'#ffe066');
      TIP.x=hx+1; TIP.y=hy+up*11;
    }
  }else if(id==='bow'){
    const pull=sp?clamp(t/0.2,0,1)*(t<0.2?1:0):((atk&&t<w.fire)?t/w.fire:0);
    const bx=hx+5;
    pl(bx,hy-8,bx+3,hy-4,'#8a5a2a'); pl(bx+3,hy-4,bx+3,hy+4,'#8a5a2a'); pl(bx+3,hy+4,bx,hy+8,'#8a5a2a');
    r(bx+3,hy-1,1,3,'#c9a03c');
    const sx=bx-pull*6;
    pl(bx,hy-8,sx,hy,'#d8cfa8'); pl(sx,hy,bx,hy+8,'#d8cfa8');
    if(pull>0){pl(sx,hy,sx+11,hy,'#b08a55'); r(sx+11,hy-1,2,3,'#dfe6f5');}
    TIP.x=bx+3; TIP.y=hy;
  }else if(id==='staff'){
    let a=1.15;
    if(sp)a=1.5;
    if(atk)a=1.15-Math.sin(clamp(t/w.dur,0,1)*Math.PI)*0.9;
    const ca=Math.cos(a), sa=-Math.sin(a), tx=hx+ca*15, ty=hy+sa*15, fl=(time*12|0)%2;
    pl(hx-ca*7,hy-sa*7,tx,ty,'#6b4a2a'); r(hx-ca*7,hy-sa*7,1,1,'#c9a03c');
    r(tx-2,ty-3,5,5,'#c2410c'); r(tx-1,ty-2,3,3,'#ffb347'); r(tx,ty-1,1,1,'#ffffff');
    r(tx-1+fl,ty-5-fl,2,2,'#ff9a4a');
    G.glow('#ff7a2a',tx,ty-1,(atk||sp)?0.9:0.5,(atk||sp)?0.7:0.4);
    TIP.x=tx; TIP.y=ty-1;
  }else if(id==='hammer'){
    let a=1.0;
    if(sp)a=t<0.3?1.0+1.6*(t/0.3):-0.9;
    if(atk){
      if(t<0.36)a=1.0+1.6*(t/0.36);
      else{a=2.6-clamp((t-0.36)/0.12,0,1)*3.5; if(t<0.6)arcTrail(hx,hy,a,19,2.7,'#8fd8ff');}
    }
    const ca=Math.cos(a), sa=-Math.sin(a), tx=hx+ca*16, ty=hy+sa*16;
    pl(hx-ca*2,hy-sa*2,tx,ty,'#6b4a2a',2);
    r(tx-5,ty-4,10,8,'#6d7587'); r(tx-4,ty-3,8,6,'#a9b2c4'); r(tx-5,ty-4,10,1,'#ffffff'); r(tx-5,ty+3,10,1,'#4a5060'); r(tx-1,ty-1,2,2,'#8fd8ff');
    TIP.x=tx; TIP.y=ty;
  }else{
    // أسلحة النينجا: كوناي في اليد + رمي نجوم
    let a=-0.3;
    if(atk)a=1.6-clamp(t/0.1,0,1)*2.0;
    if(sp)a=Math.sin(t*50)*1.6;
    const ca=Math.cos(a), sa=-Math.sin(a);
    pl(hx,hy,hx+ca*3,hy+sa*3,'#3a3346');
    pl(hx+ca*3,hy+sa*3,hx+ca*8,hy+sa*8,'#c8d0e0');
    r(hx-1,hy-1,2,2,'#c08cff');
    if(atk&&t<0.12){G.alpha(0.5); r(hx+4,hy-1,10,1,'#c08cff'); G.alpha(1);}
    TIP.x=hx+ca*8; TIP.y=hy+sa*8;
  }
}
/* شكل السلاح يتطور مع مستواه:
   م1-3 عادي · م4-6 جوهرة ولمعة · م7-9 حدّ ملوّن متوهج · م10 هالة وتأثير خاص بكل سلاح */
G.wpnTier=function(lv){return lv>=10?3:(lv>=7?2:(lv>=4?1:0));};
G.drawWeapon=function(p,hx,hy){
  drawWeaponBase(p,hx,hy);
  const w=WEAPONS[(p.state==='attack'||p.state==='special')?p.aw:p.w], id=w.id, col=w.col, time=S.time;
  const wt=G.wpnTier(p.wl==null?G.wlvOf(id):p.wl);
  if(!wt)return;
  const tx=TIP.x, ty=TIP.y, k=G.ctx, a0=k.globalAlpha;
  r(hx-1,hy,2,2,col); r(tx,ty,1,1,'#ffffff');                       // جوهرة المقبض ولمعة الرأس
  if(wt>=2){
    k.globalAlpha=a0*0.55; pl(hx,hy,tx,ty,col); k.globalAlpha=a0;
    G.glow(col,tx,ty,wt>=3?0.9:0.55,wt>=3?0.7:0.45);
  }
  if(wt>=3){
    // هالة تدور حول رأس السلاح + تأثير خاص
    for(let i=0;i<3;i++){const a=time*5+i*2.09;r(tx+Math.cos(a)*5,ty+Math.sin(a)*5,1,1,'#ffffff');}
    G.glow(col,hx,hy,0.5,0.4);
    const fl=(time*14|0)%3;
    if(id==='sword'){k.globalAlpha=a0*0.7;pl(tx,ty,tx+(tx-hx)*0.35,ty+(ty-hy)*0.35,'#ffffff');k.globalAlpha=a0;}
    else if(id==='dual'){G.glow(col,hx-5+(tx-hx)*0.9,ty+1,0.6,0.5);}
    else if(id==='axe'){r(tx-2+fl,ty-6-fl,2,3,'#ffb347');r(tx+1-fl,ty-7,1,2,'#fff2c0');r(tx-3,ty-5,1,2,'#ff7a2a');}
    else if(id==='spear'){for(let i=1;i<=3;i++)r(tx-i*4,ty-1+((i+fl)%3)-1,2,1,'#bfeaff');}
    else if(id==='scythe'){for(let i=0;i<3;i++)r(tx+Math.sin(time*3+i*2)*4,ty-3-((time*10+i*5)%9),1,2,'#b6ff7a');}
    else if(id==='chain'){for(let i=0;i<3;i++)r(tx+R(-5,5),ty+R(-5,5),1,1,'#ffffff');}
    else if(id==='bow'){k.globalAlpha=a0*0.8;pl(tx-3,ty-8,tx-3,ty+8,'#bfffb0');k.globalAlpha=a0;}
    else if(id==='staff'){for(let i=0;i<4;i++)r(tx-3+i*2,ty-5-((time*10+i*4)%8),2,2,i%2?'#ffb347':'#fff2c0');}
    else if(id==='hammer'){for(let i=0;i<3;i++)r(tx+R(-7,7),ty+R(-6,6),1,1,'#ffffff');r(tx-6,ty,12,1,'#bfeaff');}
    else{for(let i=0;i<3;i++)r(tx-2+i*2,ty-2-((time*8+i*3)%7),2,2,'#6a3aa0');}
  }
};

// مؤثرات الضربة الخاصة حول اللاعب (بإحداثيات الساحة)
G.drawSpecialFx=function(p){
  if(p.state!=='special')return;
  const id=WEAPONS[p.aw].id, t=p.t;
  if(id==='scythe'){
    for(let k=0;k<3;k++){
      const a0=t*20+k*2.09;
      for(let i=0;i<14;i++){
        const a=a0-i*0.09;
        G.alpha(0.8*(1-i/14));
        r(p.x+Math.cos(a)*42,p.y-12+Math.sin(a)*15,3,2,i<3?'#ffffff':'#b6ff7a');
        r(p.x+Math.cos(a)*34,p.y-12+Math.sin(a)*12,2,1,'#4fd08a');
      }
    }
    G.alpha(1);
    G.glow('#7aff6a',p.x,p.y-12,0.6,1.5);
  }else if(id==='axe'&&!p.sp.f){
    G.glow('#ffb347',p.x,p.y-14,0.9);
    G.alpha(0.5); r(p.x-1,p.y-4,2,Math.max(0,Math.min(60,GY-p.y)),'#ffb347'); G.alpha(1);
  }else if(id==='chain'&&p.sp.hit&&t<0.55&&p.sp.tg){
    const tg=p.sp.tg, bx=G.bossBox(tg), by=(bx.top+bx.bot)/2, x0=p.x+p.f*5, y0=p.y-13;
    const n=Math.max(2,(Math.hypot(tg.x-x0,by-y0)/4)|0);
    for(let i=0;i<=n;i++)r(x0+(tg.x-x0)*i/n,y0+(by-y0)*i/n+Math.sin(i+t*40),2,1,i%2?'#8a93a6':'#ffe066');
  }else if(id==='sword'&&t<0.25){
    G.glow('#ffe6a0',p.x,p.y-20,1,1.2);
  }
};

})(window.G);
