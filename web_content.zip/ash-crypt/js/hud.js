/* ================== hud.js — أشرطة الصحة والطاقة والعملات ================== */
(function(G){
'use strict';
const r=G.r, clamp=G.clamp, S=G.S;

function num(n,x,y,c){const s=''+n;G.txt(s,x+s.length*2.5,y,c);}

G.drawHud=function(){
  if(S.game==='menu')return;
  const P=G.P, B=G.B, t=S.time, mh=G.maxHp(), em=G.CFG.energyMax;
  // صحة اللاعب
  r(5,5,72,7,'#000000'); r(6,6,70,5,'#2a0d10');
  r(6,6,Math.round(70*clamp(P.lag/mh,0,1)),5,'#d8cfa8');
  r(6,6,Math.round(70*P.hp/mh),5,'#b3202e');
  r(6,6,Math.round(70*P.hp/mh),1,'#e0525f');
  // شريط الطاقة الخاصة
  const ef=clamp(P.en/em,0,1), full=ef>=1;
  r(5,13,72,5,'#000000'); r(6,14,70,3,'#141a2a');
  r(6,14,Math.round(70*ef),3,full?(((t*8|0)%2)?'#fff2c0':'#ffd76a'):'#4aa3ff');
  if(!full)r(6,14,Math.round(70*ef),1,'#8cc8ff');
  // قوارير العلاج
  for(let i=0;i<G.maxFlasks();i++){
    const on=i<P.flasks;
    r(6+i*8,21,5,6,'#000000'); r(7+i*8,22,3,4,on?'#4fd08a':'#1c2a24'); r(8+i*8,20,1,1,on?'#d8cfa8':'#333333');
  }
  // لون السلاح الحالي (مربع صغير)
  r(68,21,9,6,'#000000'); r(69,22,7,4,G.WEAPONS[P.w].col);
  // الذهب والكريستال
  r(6,31,5,5,'#c9a03c'); r(7,32,3,3,'#ffd76a'); num(G.save.coins,13,34,'#ffd76a');
  r(45,31,5,5,'#2a7fc0'); r(46,32,3,3,'#7fd4ff'); r(47,32,1,2,'#ffffff'); num(G.save.crystals,52,34,'#7fd4ff');
  // عدّاد الضربات المتتالية
  if(P.combo>1)G.txt('x'+P.combo,92,11,P.combo>=5?'#ffb347':'#ffd76a',P.combo>=5);
  // صحة الزعيم مع علامات المراحل
  if(B&&B.state!=='intro'){
    const c=G.ELEM[B.def.elem], n=B.def.phases||2;
    r(109,5,202,6,'#000000'); r(110,6,200,4,'#1a1420');
    r(110,6,Math.round(200*clamp(B.lag/B.max,0,1)),4,'#d8cfa8');
    r(110,6,Math.round(200*B.hp/B.max),4,B.phase>=2?c[1]:'#8a5a9a');
    r(110,6,Math.round(200*B.hp/B.max),1,B.phase>=2?c[2]:'#b78ac8');
    for(let i=1;i<n;i++)r(110+Math.round(200*i/n)-1,5,1,6,'#000000');
  }
  // شريط التقدّم في المرحلة
  if(G.L){
    const L=G.L, u=clamp(P.x/L.portal.x,0,1);
    r(110,7,200,2,'#000000'); r(110,7,Math.round(200*u),2,'#7fd4ff');
    r(110+Math.round(200*u)-1,5,3,6,'#ffffff'); r(308,5,3,6,'#c07aff');
  }
};

})(window.G);
