/* ================== rooms.js — الغرف (لكل زعيم غرفة بشكل مختلف) ==================
   لإضافة غرفة جديدة: أضف دالة داخل THEMES ثم اكتب اسمها في خانة room عند الزعيم   */
(function(G){
'use strict';
const W=G.W, H=G.H, GY=G.GY, R=G.R, r=G.r;

const THEMES={

  /* 1) الضريح القوطي */
  crypt(o,T,q,g){
    T.bricks('#09080d','#110f17','#16141d','#0d0b12','#1b1823');
    T.window(160,28,22,'#13203a','#1c2f52','#07060a');
    T.moonBeam(160,52,'120,150,220');
    T.banner(64,'#4a1320','#3a0f18','#c9a03c'); T.banner(256,'#4a1320','#3a0f18','#c9a03c');
    T.chain(118,34); T.chain(202,34);
    T.pillars([28,100,220,292],['#18161d','#211f27','#2a2731','#35313d','#3d3946','#35313d','#2a2731','#211f27','#1b1920','#15131a']);
    // المذبح الحجري
    q(140,GY-22,44,22,'#201d27'); q(137,GY-26,50,4,'#2e2a36'); q(137,GY-26,50,1,'#3d3946');
    q(151,GY-26,22,12,'#3a1620'); q(151,GY-15,22,1,'#5a2230'); q(160,GY-14,4,4,'#15131a');
    T.floor('#12110f',['#2e2c27','#262521','#1d1c19'],'#3c3a33');
    [86,236,304,12].forEach(x=>T.skull(x));
    [[52,4],[57,5],[126,4],[197,4],[202,5],[262,4]].forEach(c=>T.candle(c[0],c[1]));
    T.stand(72,40); T.stand(248,40); T.candle(143,30,true); T.candle(181,30,true);
  },

  /* 2) قاعة السلاح */
  hall(o,T,q,g){
    T.bricks('#0a0c12','#141822','#1a2030','#10131b','#232a3c');
    // بوابة مقوّسة كبيرة
    for(let i=0;i<30;i++){const hw=Math.round(Math.sqrt(900-(30-i)*(30-i)));q(160-hw,40+i,hw*2,1,'#050608');}
    q(130,70,60,GY-70,'#050608');
    for(let x=134;x<190;x+=8)q(x,44,2,GY-44,'#1a1d28');
    q(130,96,60,2,'#1a1d28'); q(126,40,2,GY-40,'#2a3044'); q(192,40,2,GY-40,'#2a3044');
    // دروع وسيوف متقاطعة على الجدار
    [70,250].forEach(x=>{
      for(let i=-12;i<=12;i++){q(x+i,58+i,2,2,'#8a93a6');q(x-i,58+i,2,2,'#8a93a6');}
      q(x-7,50,15,14,'#5a1020'); q(x-6,64,13,3,'#5a1020'); q(x-4,67,9,2,'#5a1020'); q(x-2,69,5,2,'#5a1020');
      q(x-7,50,15,1,'#c9a03c'); T.crescent(x,59,4,'#c9a03c');
    });
    T.banner(110,'#1f3a6b','#172c52','#c8d0e0'); T.banner(210,'#1f3a6b','#172c52','#c8d0e0');
    T.pillars([24,296],['#161a24','#1e2432','#273042','#313c52','#3a465e','#313c52','#273042','#1e2432','#181c28','#12151e']);
    T.floor('#0e1016','#262b38 #1f2430 #181c26'.split(' '),'#3a4258');
    q(96,GY+2,128,5,'#5a1020'); q(88,GY+8,144,8,'#4a0c1a'); q(76,GY+17,168,13,'#3a0914');
    q(96,GY+2,128,1,'#c9a03c');
    o.lightC='#ffa040';
    [44,96,224,276].forEach(x=>T.torch(x,70));
    // حامل أسلحة
    q(8,GY-20,2,20,'#3a2a1a'); q(4,GY-20,10,2,'#3a2a1a'); q(6,GY-34,1,34,'#8a93a6'); q(11,GY-30,1,30,'#8a93a6'); q(4,GY-36,5,4,'#c8d0e0');
  },

  /* 3) عشّ العناكب */
  nest(o,T,q,g,rnd){
    q(0,0,W,GY,'#0a0907');
    for(let i=0;i<260;i++){const x=rnd()*W,y=rnd()*GY,s=3+rnd()*9;q(x,y,s,s*0.6,rnd()<0.5?'#14110d':'#0f0d0a');}
    for(let i=0;i<40;i++)q(rnd()*W,rnd()*GY,2,1,'#1f1a14');
    // صواعد ونوازل
    for(let x=4;x<W;x+=9+rnd()*14){const h=6+rnd()*26;for(let i=0;i<h;i++){const w=Math.max(1,Math.round((1-i/h)*5));q(x-w,i,w*2,1,i%4?'#1a1611':'#221d16');}}
    // شبكات العنكبوت
    const web=(cx,cy,rad,a0,a1)=>{
      g.strokeStyle='rgba(200,200,190,0.28)'; g.lineWidth=1;
      for(let i=0;i<=6;i++){const a=a0+(a1-a0)*i/6;g.beginPath();g.moveTo(cx,cy);g.lineTo(cx+Math.cos(a)*rad,cy+Math.sin(a)*rad);g.stroke();}
      for(let k=1;k<=4;k++){g.beginPath();g.arc(cx,cy,rad*k/4.4,a0,a1);g.stroke();}
    };
    web(0,0,80,0,Math.PI/2); web(W,0,90,Math.PI/2,Math.PI); web(160,0,46,0.2,Math.PI-0.2);
    // شرانق معلّقة
    [[90,48],[232,40],[190,62]].forEach(c=>{
      q(c[0],0,1,c[1],'#8a8676'); for(let y=-7;y<=7;y++){const hw=Math.round(4*Math.sqrt(1-y*y/49));q(c[0]-hw,c[1]+7+y,hw*2+1,1,y%3?'#b9b3a0':'#8a8676');}
    });
    T.floor('#0c0a08',['#241f17','#1c1812','#15120d'],'#2e281e');
    // بيض العنكبوت
    [30,44,270,284,300].forEach((x,i)=>{for(let y=-4;y<=0;y++){const hw=Math.round(5*Math.sqrt(1-y*y/16));q(x-hw,GY+y-1,hw*2,1,'#c9c3ae');}q(x-2,GY-4,2,1,'#ffffff');});
    // فطر مضيء
    o.lightC='#7aff6a'; o.flameC=['#9be04a','#f0ffc0']; o.ember='#9be04a'; o.mist='#6a9a5a';
    [[16,2],[66,3],[118,2],[214,3],[250,2],[310,3]].forEach(c=>{q(c[0],GY-c[1]-1,1,c[1]+1,'#c9c3ae');q(c[0]-2,GY-c[1]-3,5,2,'#2f8a1c');q(c[0]-1,GY-c[1]-4,3,1,'#9be04a');o.lights.push([c[0],GY-c[1]-3]);});
    o.noFlame=true;
  },

  /* 4) كهف الجليد */
  ice(o,T,q,g,rnd){
    T.bricks('#060c14','#0c1826','#102236','#0a1420','#1c3852',10,20);
    // شفق قطبي من فتحة في الكهف
    for(let i=0;i<34;i++){const hw=Math.round(Math.sqrt(34*34-(34-i)*(34-i))*1.3);q(160-hw,16+i,hw*2,1,'#0a1a30');}
    q(116,50,88,40,'#0a1a30');
    for(let x=118;x<202;x+=2){const h=10+Math.sin(x*0.2)*6+rnd()*6;g.fillStyle='rgba(90,230,200,0.18)';g.fillRect(x,30+Math.sin(x*0.11)*6,2,h);g.fillStyle='rgba(120,160,255,0.12)';g.fillRect(x,38+Math.sin(x*0.13)*5,2,h);}
    for(let i=0;i<16;i++)q(120+rnd()*80,22+rnd()*50,1,1,'#dff4ff');
    T.moonBeam(160,60,'140,220,255');
    // نوازل جليدية
    for(let x=2;x<W;x+=7+rnd()*10){const h=5+rnd()*22;for(let i=0;i<h;i++){const w=Math.max(1,Math.round((1-i/h)*3));q(x-w,i,w*2,1,i%3?'#3a7ab0':'#8fd8ff');}}
    T.pillars([36,284],['#0e2236','#143250','#1c446a','#2a5c88','#3a78a8','#2a5c88','#1c446a','#143250','#0e2236','#0a1826']);
    T.floor('#081220',['#1c3a58','#16304a','#10263c'],'#6ab8e8');
    for(let i=0;i<30;i++)q(rnd()*W,GY+2+rnd()*26,2+rnd()*5,1,'#3a78a8');
    // بلّورات مضيئة
    o.lightC='#6ac8ff'; o.flameC=['#8fd8ff','#ffffff']; o.ember='#e8f6ff'; o.emberDir=1; o.mist='#8fc8ff'; o.noFlame=true;
    [[60,16],[78,10],[244,18],[262,9],[140,8],[186,12]].forEach(c=>{
      for(let i=0;i<c[1];i++){const w=Math.max(1,Math.round((1-i/c[1])*3));q(c[0]-w,GY-i-1,w*2,1,i%2?'#2a7fc0':'#8fd8ff');}
      q(c[0],GY-c[1],1,3,'#ffffff'); o.lights.push([c[0],GY-c[1]+2]);
    });
  },

  /* 5) المصهر */
  forge(o,T,q,g,rnd){
    T.bricks('#0c0605','#1a0d0a','#22110c','#140a08','#2e1810');
    // الفرن الكبير
    q(120,40,80,GY-40,'#1c1412'); q(116,36,88,6,'#2e221e'); q(116,36,88,1,'#4a3830');
    for(let i=0;i<24;i++){const hw=Math.round(Math.sqrt(576-(24-i)*(24-i)));q(160-hw,80+i,hw*2,1,'#3a0c04');}
    q(136,104,48,GY-104,'#3a0c04');
    for(let i=0;i<18;i++){const hw=Math.round(Math.sqrt(324-(18-i)*(18-i)));q(160-hw,90+i,hw*2,1,'#c2410c');}
    q(142,108,36,GY-108,'#c2410c'); q(148,112,24,GY-112,'#ffb347'); q(154,122,12,GY-122,'#fff2c0');
    for(let x=138;x<184;x+=6)q(x,100,2,GY-100,'#140a08');
    q(152,10,16,30,'#2e221e'); q(150,10,20,3,'#4a3830');
    // أنابيب وسلاسل
    q(0,22,120,4,'#2a2420'); q(0,22,120,1,'#4a403a'); q(200,30,120,4,'#2a2420'); q(200,30,120,1,'#4a403a');
    [40,84,236,280].forEach(x=>q(x,18,5,12,'#3a322c'));
    T.chain(60,50); T.chain(100,36); T.chain(226,44); T.chain(268,58);
    q(57,50,7,7,'#3a322c'); q(265,58,7,9,'#3a322c');
    T.pillars([18,302],['#1a100c','#241610','#2e1c14','#3a2418','#44291c','#3a2418','#2e1c14','#241610','#1c120e','#140c0a']);
    T.floor('#0e0806',['#2a1e18','#221812','#1a120e'],'#4a3024');
    // سندان
    q(76,GY-10,18,3,'#3a3a44'); q(72,GY-13,26,3,'#55555f'); q(72,GY-13,26,1,'#8a8a96'); q(80,GY-7,10,7,'#2a2a32'); q(76,GY-2,18,2,'#3a3a44');
    // قنوات الحمم في الأرض
    o.lava=[[0,GY+10,70,4],[250,GY+10,70,4],[100,GY+20,120,5]];
    o.lightC='#ff7a2a'; o.ember='#ffb347'; o.emberN=46; o.mist='#b05a3a';
    o.lights.push([160,112],[148,120],[172,120]); o.bigLights=[[160,110]]; o.noFlame=true;
    T.torch(44,74); T.torch(276,74);
  },

  /* 6) قاعة الدم */
  chapel(o,T,q,g){
    T.bricks('#0b060d','#150c18','#1c1020','#100913','#281830');
    [84,160,236].forEach((x,i)=>{
      T.window(x,i===1?18:30,i===1?20:15,'#3a0a14','#7a1422','#07060a');
      T.moonBeam(x,i===1?44:50,'200,40,60');
    });
    // قمر دموي داخل النافذة الوسطى
    for(let y=-6;y<=6;y++){const hw=Math.round(Math.sqrt(36-y*y));q(160-hw,34+y,hw*2,1,'#c0283a');}
    q(158,31,3,2,'#e0525f');
    T.banner(46,'#3a0a14','#2a060e','#c9a03c'); T.banner(274,'#3a0a14','#2a060e','#c9a03c');
    T.pillars([20,122,198,300],['#15101a','#1d1624','#261d2e','#30263a','#3a2e46','#30263a','#261d2e','#1d1624','#17121c','#110d15']);
    // تابوت قائم
    q(152,GY-44,16,44,'#1a0e0c'); q(150,GY-38,20,30,'#1a0e0c'); q(153,GY-42,14,40,'#2e1814'); T.crescent(160,GY-30,5,'#c9a03c');
    T.floor('#0d080f',['#28202e','#201a26','#18131d'],'#3a2e46');
    q(60,GY+2,200,5,'#5a0c18'); q(50,GY+8,220,8,'#48081a'); q(36,GY+17,248,13,'#380612');
    o.lightC='#ff5a4a'; o.flameC=['#ff8a6a','#ffe0d0']; o.ember='#ff4a4a'; o.mist='#a05a9a';
    T.stand(62,44); T.stand(100,36); T.stand(220,36); T.stand(258,44);
    [[140,4],[145,6],[176,6],[181,4]].forEach(c=>T.candle(c[0],c[1]));
  },

  /* 7) غابة القمر */
  forest(o,T,q,g,rnd){
    T.sky('#050d14','#0c2230');
    // البدر
    for(let y=-20;y<=20;y++){const hw=Math.round(Math.sqrt(400-y*y));q(226-hw,44+y,hw*2,1,'#d8e8d8');}
    q(216,36,6,4,'#b8ccb8'); q(232,48,8,5,'#b8ccb8'); q(222,54,4,3,'#b8ccb8');
    T.radial(226,44,90,'rgba(190,230,210,0.22)');
    for(let i=0;i<40;i++)q(rnd()*W,rnd()*70,1,1,'#9ab8c8');
    // ثلاث طبقات من الأشجار
    const trees=(n,c,base,hmin,hmax,wd)=>{
      for(let i=0;i<n;i++){
        const x=(i+rnd()*0.8)*(W/n), h=hmin+rnd()*(hmax-hmin);
        q(x-wd/2,base-h*0.4,wd,h*0.4,c);
        for(let j=0;j<h*0.75;j++){const w=Math.round((j/(h*0.75))*wd*3.2*(0.7+((j%7)/7)*0.5));q(x-w,base-h+j,w*2+1,1,c);}
      }
    };
    trees(14,'#081a22',GY,60,100,3); trees(10,'#06131a',GY,70,120,4); trees(6,'#040c11',GY,90,140,6);
    // جذوع قريبة على الأطراف
    [10,306].forEach(x=>{q(x-8,0,16,GY,'#03080b');q(x-8,0,2,GY,'#0a161c');for(let y=10;y<GY;y+=14)q(x-4+((y*3)%7),y,1,6,'#0a161c');});
    T.ground('#0a140c',['#16281a','#102014','#0b170e'],'#2a4a2a');
    for(let x=0;x<W;x+=3){const h=1+((x*7)%4);q(x,GY-h,1,h,(x%2)?'#1c3a20':'#2a4a2a');}
    // شجيرات وصخور
    [50,130,200,270].forEach(x=>{for(let y=-6;y<=0;y++){const hw=Math.round(9*Math.sqrt(1-y*y/36));q(x-hw,GY+y,hw*2,1,y%2?'#0e2414':'#143018');}});
    q(90,GY-4,10,4,'#2a3238'); q(92,GY-6,6,2,'#3a444c');
    o.lightC='#c8ff8a'; o.ember='#d8ff8a'; o.emberN=18; o.mist='#7aa8a0'; o.noFlame=true;
    o.bigLights=[[226,44]];
  },

  /* 8) المقبرة */
  grave(o,T,q,g,rnd){
    T.sky('#0a0812','#1c1630');
    // هلال
    for(let y=-12;y<=12;y++){const hw=Math.round(Math.sqrt(144-y*y));q(70-hw,36+y,hw*2,1,'#cfc8e0');}
    for(let y=-11;y<=11;y++){const hw=Math.round(Math.sqrt(121-y*y));q(76-hw,33+y,hw*2,1,'#14102a');}
    T.radial(70,36,70,'rgba(180,170,230,0.16)');
    // غيوم
    for(let i=0;i<9;i++){const x=rnd()*W,y=10+rnd()*50;for(let j=0;j<5;j++)q(x+j*8-rnd()*6,y+rnd()*5,18,4,'rgba(60,52,90,0.5)');}
    // تلّ بعيد وبرج قديم
    for(let x=0;x<W;x++){const h=18+Math.sin(x*0.02)*8+Math.sin(x*0.07)*3;q(x,GY-h,1,h,'#0e0b18');}
    q(236,GY-58,18,40,'#0e0b18'); for(let i=0;i<14;i++)q(245-i*0.7,GY-72+i,1+i*1.4,1,'#0e0b18'); T.crescent(245,GY-79,5,'#3a3460'); q(243,GY-50,4,7,'#4a3a14');
    // أشجار ميتة
    const dead=(x,h)=>{const b=(x0,y0,a,l,w)=>{if(l<4)return;const x1=x0+Math.cos(a)*l,y1=y0-Math.sin(a)*l;g.strokeStyle='#07060c';g.lineWidth=w;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();b(x1,y1,a+0.5+rnd()*0.3,l*0.66,Math.max(1,w-1));b(x1,y1,a-0.5-rnd()*0.3,l*0.66,Math.max(1,w-1));};b(x,GY,Math.PI/2,h,4);};
    dead(26,34); dead(298,40); dead(150,26);
    // سياج حديدي
    for(let x=0;x<W;x+=6){q(x,GY-22,1,22,'#15121f');q(x-1,GY-24,3,2,'#15121f');}
    q(0,GY-18,W,1,'#15121f'); q(0,GY-6,W,1,'#15121f');
    T.ground('#0c0a10',['#221c26','#1a161e','#131016'],'#3a3244');
    // شواهد القبور
    [[52,16,0],[92,12,1],[124,18,0],[196,14,1],[226,18,0],[274,12,1]].forEach(s=>{
      const x=s[0],h=s[1];
      if(s[2]){q(x-3,GY-h,6,h,'#3a3644');q(x-3,GY-h,1,h,'#55506a');q(x-4,GY-h-1,8,2,'#3a3644');T.crescent(x,GY-h-6,4,'#6a6488');}
      else{q(x-6,GY-h,12,h,'#34303e');q(x-5,GY-h-2,10,2,'#34303e');q(x-3,GY-h-3,6,1,'#34303e');q(x-6,GY-h,1,h,'#4c4660');q(x-3,GY-h+4,6,1,'#1c1924');q(x-2,GY-h+7,4,1,'#1c1924');}
      q(x-8,GY-2,16,2,'#1a161e');
    });
    o.lightC='#8affc0'; o.flameC=['#8affc0','#eafff4']; o.ember='#8affc0'; o.emberN=14; o.mist='#9a90c0'; o.mistN=5;
    [[38,20],[170,22],[250,20]].forEach(c=>{q(c[0],GY-c[1],1,c[1],'#15121f');q(c[0]-2,GY-c[1]-5,5,5,'#2a2634');o.lights.push([c[0],GY-c[1]-3]);});
    o.storm=true;
  },

  /* 9) عرين التنين */
  lair(o,T,q,g,rnd){
    q(0,0,W,GY,'#0a0605');
    for(let i=0;i<300;i++){const x=rnd()*W,y=rnd()*GY,s=4+rnd()*12;q(x,y,s,s*0.5,rnd()<0.5?'#150c09':'#100807');}
    T.grad(0,GY-70,W,70,'rgba(255,90,20,0)','rgba(255,90,20,0.22)');
    // أضلاع وحش عملاق في الخلفية
    g.strokeStyle='#3a3228'; g.lineWidth=3;
    for(let i=0;i<7;i++){g.beginPath();g.arc(60+i*34,GY+10,74-Math.abs(i-3)*7,Math.PI*1.08,Math.PI*1.92);g.stroke();}
    g.strokeStyle='#4c4234'; g.lineWidth=1;
    for(let i=0;i<7;i++){g.beginPath();g.arc(60+i*34,GY+10,75-Math.abs(i-3)*7,Math.PI*1.1,Math.PI*1.9);g.stroke();}
    q(30,GY-70,260,3,'#3a3228');
    for(let x=6;x<W;x+=10+rnd()*16){const h=6+rnd()*22;for(let i=0;i<h;i++){const w=Math.max(1,Math.round((1-i/h)*5));q(x-w,i,w*2,1,'#1c110c');}}
    // شلالات حمم على الجانبين
    o.falls=[14,300];
    T.floor('#0c0705',['#2a1a12','#20140e','#170e0a'],'#4a2a18');
    // كنوز وعظام
    [[40,7],[70,4],[262,8],[288,5]].forEach(c=>{for(let y=-c[1];y<=0;y++){const hw=Math.round(c[1]*2.2*Math.sqrt(1-y*y/(c[1]*c[1])));q(c[0]-hw,GY+y,hw*2,1,y%2?'#8a6a2a':'#c9a03c');}for(let i=0;i<6;i++)q(c[0]-10+rnd()*20,GY-rnd()*c[1],1,1,'#fff2c0');});
    [110,150,214].forEach(x=>{T.skull(x);q(x+6,GY-1,7,1,'#8f8468');q(x-8,GY-2,6,1,'#8f8468');});
    o.lava=[[60,GY+12,60,4],[190,GY+20,90,5]];
    o.lightC='#ff7a2a'; o.ember='#ffb347'; o.emberN=50; o.mist='#c06a3a'; o.noFlame=true;
    o.bigLights=[[14,90],[300,90]];
  },

  /* 10) الهاوية */
  void(o,T,q,g,rnd){
    T.sky('#030208','#0c0620');
    T.radial(90,50,110,'rgba(120,40,200,0.20)'); T.radial(250,80,90,'rgba(40,80,200,0.14)'); T.radial(170,20,70,'rgba(200,40,140,0.10)');
    for(let i=0;i<110;i++){const v=rnd();q(rnd()*W,rnd()*GY,v>0.92?2:1,1,v>0.6?'#ffffff':(v>0.3?'#c07aff':'#6a8aff'));}
    // صخور طافية
    [[40,60,14],[110,36,8],[232,48,12],[290,84,9],[180,96,6]].forEach(c=>{
      for(let y=0;y<c[2];y++){const w=Math.round((1-y/c[2])*c[2]*1.3);q(c[0]-w,c[1]+y,w*2,1,y?'#140c22':'#3a2a5a');}
      q(c[0]-c[2],c[1]-1,c[2]*2,1,'#4c3a70');
    });
    // أعمدة محطمة
    [[60,54],[262,70]].forEach(c=>{q(c[0]-7,GY-c[1],14,c[1],'#120a1e');q(c[0]-7,GY-c[1],2,c[1],'#2a1c40');q(c[0]-9,GY-4,18,4,'#1a1028');for(let i=0;i<5;i++)q(c[0]-7+i*3,GY-c[1]-2-((i*5)%4),2,4,'#120a1e');});
    T.floor('#07040e',['#1a1028','#140c20','#0e0818'],'#6a1cb0');
    o.rune=true;
    o.lightC='#c07aff'; o.ember='#c07aff'; o.emberN=36; o.mist='#7a4ac0'; o.noFlame=true;
    o.lights.push([60,GY-58],[262,GY-74]);
  },

  /* 11) قاعة العرش */
  throne(o,T,q,g){
    T.bricks('#0c0906','#17120b','#1e1810','#120e08','#2c2416');
    [70,250].forEach(x=>{T.window(x,20,16,'#5a1a06','#a03810','#07060a');T.moonBeam(x,40,'255,120,40');});
    // رايات ذهبية كبيرة
    [116,204].forEach(bx=>{
      q(bx-10,4,20,2,'#8a6a2a');
      for(let y=6;y<78;y++){const w=y<66?8:Math.max(1,8-((y-66)>>1));q(bx-w,y,w*2,1,y%8<1?'#0a0806':'#15110c');}
      q(bx-8,6,1,60,'#c9a03c'); q(bx+7,6,1,60,'#c9a03c');
      q(bx-3,26,7,2,'#c9a03c'); q(bx-4,22,2,4,'#c9a03c'); q(bx,20,2,6,'#c9a03c'); q(bx+3,22,2,4,'#c9a03c');
    });
    T.pillars([24,296],['#1c160c','#261e10','#322814','#3e321a','#4a3c20','#3e321a','#322814','#261e10','#1e180e','#16120a'],'#c9a03c');
    // العرش والدرجات
    q(118,GY-8,84,8,'#221a10'); q(126,GY-16,68,8,'#2a2014'); q(118,GY-8,84,1,'#4a3c20'); q(126,GY-16,68,1,'#4a3c20');
    q(142,GY-76,36,60,'#1a1410'); q(140,GY-80,40,6,'#2e2416');
    for(let i=0;i<5;i++){q(141+i*9,GY-88+Math.abs(i-2)*3,3,10-Math.abs(i-2)*3,'#c9a03c');}
    q(146,GY-72,28,40,'#4a0c14'); q(146,GY-72,28,1,'#7a1c2a'); q(140,GY-36,8,20,'#2e2416'); q(172,GY-36,8,20,'#2e2416');
    q(146,GY-32,28,4,'#5a1018'); q(140,GY-80,40,1,'#c9a03c'); q(159,GY-70,3,3,'#ffb347');
    T.floor('#0e0b07',['#2c2416','#241d12','#1b160d'],'#c9a03c');
    q(110,GY+2,100,5,'#5a0c18'); q(98,GY+8,124,8,'#48081a'); q(80,GY+17,160,13,'#380612'); q(110,GY+2,100,1,'#c9a03c');
    // مواقد النار
    o.lightC='#ff8a30'; o.ember='#ffb347'; o.emberN=40;
    [56,104,216,264].forEach(x=>{q(x-1,GY-26,3,26,'#3e321a');q(x-6,GY-30,13,4,'#4a3c20');q(x-6,GY-30,13,1,'#c9a03c');q(x-4,GY-2,9,2,'#3e321a');o.lights.push([x,GY-34]);});
    o.bigLights=[[56,GY-36],[104,GY-36],[216,GY-36],[264,GY-36]]; o.brazier=true;
  }
};

/* ---------- بناء الغرفة (تُرسم خلفيتها مرة واحدة) ---------- */
G.buildRoom=function(id){
  G.seed(7+id.length*977+id.charCodeAt(0)*131);
  const rnd=G.rnd;
  const bg=document.createElement('canvas'); bg.width=W; bg.height=H;
  const g=bg.getContext('2d');
  const q=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
  const o={id,bg,lights:[],bigLights:[],lightC:'#ff9a40',flameC:['#ffcf6a','#fff2c0'],
           ember:'#ff8a3a',emberDir:-1,emberN:26,mist:'#9696b9',mistN:3,embers:[]};
  // أدوات مشتركة لرسم الغرف
  const T={
    bricks(mortar,a,b,c,hi,bh,bw){
      bh=bh||8; bw=bw||16;
      q(0,0,W,H,mortar);
      for(let y=0,row=0;y<GY;y+=bh,row++)for(let x=(row%2)*-(bw/2);x<W;x+=bw){
        const v=rnd();
        q(x+1,y+1,bw-1,bh-1,v<0.2?b:(v<0.28?c:a));
        if(v>0.9)q(x+3,y+3,4,1,hi);
        if(v<0.04){q(x+4,y+2,1,bh-3,mortar);q(x+5,y+4,3,1,mortar);}   // شقوق
      }
    },
    sky(c0,c1){const gr=g.createLinearGradient(0,0,0,GY);gr.addColorStop(0,c0);gr.addColorStop(1,c1);g.fillStyle=gr;g.fillRect(0,0,W,H);},
    grad(x,y,w,h,c0,c1){const gr=g.createLinearGradient(0,y,0,y+h);gr.addColorStop(0,c0);gr.addColorStop(1,c1);g.fillStyle=gr;g.fillRect(x,y,w,h);},
    radial(x,y,rad,c){const gr=g.createRadialGradient(x,y,2,x,y,rad);gr.addColorStop(0,c);gr.addColorStop(1,c.replace(/[\d.]+\)$/,'0)'));g.fillStyle=gr;g.fillRect(x-rad,y-rad,rad*2,rad*2);},
    floor(base,rows,edge){
      q(0,GY,W,H-GY,base);
      [[GY+1,6],[GY+8,8],[GY+17,13]].forEach((rw,i)=>{
        let x=-(rnd()*8|0);
        while(x<W){
          const w=10+(rnd()*13|0);
          q(x,rw[0],w-1,rw[1],rows[i]);
          if(rnd()<0.35)q(x+2+(rnd()*(w-5)|0),rw[0]+1,1,rw[1]-2,base);
          x+=w;
        }
      });
      q(0,GY,W,1,edge);
    },
    ground(base,rows,edge){
      q(0,GY,W,H-GY,base);
      q(0,GY+1,W,7,rows[0]); q(0,GY+8,W,9,rows[1]); q(0,GY+17,W,13,rows[2]);
      for(let i=0;i<90;i++)q(rnd()*W,GY+2+rnd()*27,1+rnd()*3,1,rnd()<0.5?base:edge);
      q(0,GY,W,1,edge);
    },
    pillars(xs,cols,trim){
      xs.forEach(cx=>{
        for(let i=0;i<20;i++)q(cx-10+i,0,1,GY,cols[(i/2)|0]);
        for(let y=14;y<GY-10;y+=22)q(cx-10,y,20,1,cols[9]);
        q(cx-4,40+((cx*7)%50),1,9,cols[9]); q(cx+3,70+((cx*3)%40),1,6,cols[9]);
        q(cx-12,0,24,5,cols[3]); q(cx-11,5,22,2,cols[8]);
        q(cx-13,GY-11,26,7,cols[2]); q(cx-15,GY-4,30,4,cols[3]); q(cx-13,GY-11,26,1,trim||cols[4]);
        if(trim){q(cx-12,4,24,1,trim);q(cx-10,60,20,1,trim);}
      });
    },
    window(cx,top,rad,glass,pane,bar){
      for(let i=0;i<rad;i++){const half=Math.round(Math.sqrt(rad*rad-(rad-i)*(rad-i))*0.8);q(cx-half,top+i,half*2,1,glass);}
      const hw=Math.round(rad*0.8), bh=Math.round(rad*2.5);
      q(cx-hw,top+rad,hw*2,bh,glass);
      q(cx-hw+3,top+8,6,5,pane); q(cx+3,top+rad+6,6,5,pane); q(cx-hw+4,top+rad+20,5,7,pane); q(cx+4,top+rad+36,5,7,pane);
      const v3=Math.round(hw/3); q(cx-v3-1,top+3,1,rad+bh-3,bar); q(cx+v3,top+3,1,rad+bh-3,bar);
      for(let yy=top+rad+6;yy<top+rad+bh-4;yy+=12)q(cx-hw,yy,hw*2,1,bar);
      T.radial(cx,top+rad+8,rad*3.4,'rgba(120,130,190,0.10)');
    },
    moonBeam(cx,y0,rgb){
      const sh=g.createLinearGradient(0,y0,0,GY);
      sh.addColorStop(0,'rgba('+rgb+',0.14)'); sh.addColorStop(1,'rgba('+rgb+',0)');
      g.fillStyle=sh; g.beginPath();
      g.moveTo(cx-14,y0); g.lineTo(cx+14,y0); g.lineTo(cx+56,GY); g.lineTo(cx-56,GY); g.closePath(); g.fill();
      g.fillStyle='rgba('+rgb+',0.05)'; g.fillRect(cx-46,GY+1,92,6);
    },
    banner(bx,c,d,sym){
      q(bx-9,8,18,2,'#3a3642');
      for(let y=10;y<54;y++){const w=y<44?7:Math.max(1,7-((y-44)>>1)-((y*bx)%3));q(bx-w,y,w*2,1,y%6<1?d:c);}
      q(bx-7,10,1,34,'rgba(255,255,255,0.12)'); q(bx+6,10,1,34,'rgba(0,0,0,0.35)');
      T.crescent(bx,25,5,sym);
    },
    // هلال بالبكسل
    crescent(cx,cy,rad,c){
      for(let y=-rad;y<=rad;y++)for(let x=-rad;x<=rad;x++){
        if(x*x+y*y<=rad*rad&&(x-rad*0.5)*(x-rad*0.5)+y*y>rad*rad*0.72)q(cx+x,cy+y,1,1,c);
      }
    },
    chain(cx,len){for(let y=0;y<len;y+=3)q(cx,y,1,2,'#3a3642');q(cx-1,len,3,2,'#55505f');},
    skull(x){q(x,GY-3,4,3,'#b9ad8c');q(x,GY-2,1,1,'#0a0a0f');q(x+2,GY-2,1,1,'#0a0a0f');},
    candle(x,h,short){q(x,GY-h+1,1,short?3:h-1,'#d8cfa8');o.lights.push([x,GY-h]);},
    stand(x,h){q(x,GY-h+2,1,h-2,'#8a6a2a');q(x-2,GY-2,5,2,'#8a6a2a');q(x-1,GY-h+1,3,1,'#c9a03c');o.lights.push([x,GY-h]);},
    torch(x,y){q(x-1,y,3,8,'#3a2a1a');q(x-2,y,5,2,'#55505f');q(x-3,y+8,7,1,'#55505f');o.lights.push([x,y-2]);}
  };
  THEMES[id](o,T,q,g,rnd);
  // جمر / ثلج / يراعات تطفو في الهواء
  for(let i=0;i<o.emberN;i++)o.embers.push({x:R(0,W),y:R(0,GY),s:R(4,12),p:R(0,6)});
  return o;
};

/* ---------- رسم الغرفة (الخلفية + العناصر المتحركة) ---------- */
G.drawRoomBack=function(){
  const o=G.room, k=G.ctx, t=G.S.time;
  k.drawImage(o.bg,0,0);
  // برق المقبرة
  if(o.storm){
    const c=t%9;
    if(c<0.12||(c>0.2&&c<0.26)){G.alpha(0.22);r(0,0,W,GY,'#c8c0ff');G.alpha(1);}
  }
  // الحمم المتوهجة
  if(o.lava)o.lava.forEach((l,i)=>{
    r(l[0],l[1],l[2],l[3],'#c2410c');
    for(let x=l[0];x<l[0]+l[2];x+=4){const v=Math.sin(x*0.3+t*3+i);r(x,l[1]+(v>0?0:1),4,l[3]-2,v>0.3?'#ffb347':'#ff7a2a');}
    r(l[0],l[1],l[2],1,'#7a2a0a');
    G.glow('#ff5a1a',l[0]+l[2]/2,l[1],0.45+0.15*Math.sin(t*2+i),l[2]/40);
  });
  if(o.falls)o.falls.forEach((x,i)=>{
    for(let y=0;y<GY;y+=4){const v=Math.sin(y*0.4-t*9+i*2);r(x-3,y,7,4,'#c2410c');r(x-2+(v>0?1:0),y,4,4,v>0.2?'#ffb347':'#ff7a2a');r(x,y,1,4,v>0.7?'#fff2c0':'#ffb347');}
    G.glow('#ff5a1a',x,GY-6,0.8,1.2);
  });
  // دائرة الرموز في الهاوية
  if(o.rune){
    G.alpha(0.35+0.25*Math.sin(t*2));
    for(let i=0;i<40;i++){const a=i/40*Math.PI*2+t*0.3;r(160+Math.cos(a)*70,GY+14+Math.sin(a)*9,2,1,'#c07aff');}
    for(let i=0;i<24;i++){const a=i/24*Math.PI*2-t*0.5;r(160+Math.cos(a)*44,GY+14+Math.sin(a)*6,1,1,'#ffffff');}
    G.alpha(1);
  }
  // جمر/ثلج متطاير
  for(const e of o.embers){
    const y=((e.y+o.emberDir*t*e.s*(o.emberDir>0?2.5:1))%GY+GY)%GY;
    G.alpha(0.3+0.25*Math.sin(t*2+e.p));
    r(e.x+Math.sin(t+e.p)*4,y,1,1,o.ember);
  }
  G.alpha(1);
  // توهج الأضواء + ألسنة اللهب
  o.lights.forEach((l,i)=>{
    const f=0.75+0.25*Math.sin(t*9+i*2.3)*Math.sin(t*5.1+i);
    G.glow(o.lightC,l[0],l[1],f);
  });
  o.bigLights.forEach((l,i)=>G.glow(o.lightC,l[0],l[1],0.7+0.2*Math.sin(t*4+i),2));
  if(!o.noFlame)o.lights.forEach((l,i)=>{
    const up=(Math.sin(t*11+i*3)>0.3)?1:0;
    r(l[0],l[1]-up,1,1+up,o.flameC[0]); r(l[0],l[1],1,1,o.flameC[1]);
  });
  if(o.brazier)o.bigLights.forEach((l,i)=>{
    for(let j=0;j<5;j++){const h=3+((Math.sin(t*13+i*2+j*1.7)*3)|0)+(j===2?3:0);r(l[0]-5+j*2,l[1]+6-h,2,h,j%2?'#ffb347':'#c2410c');}
    r(l[0]-1,l[1]+2,2,3,'#fff2c0');
  });
  // ضباب خلفي
  const m=G.mistOf(o.mist);
  for(let i=0;i<o.mistN;i++){
    const x=((i*131+t*(5+i*2))%(W+96))-96;
    k.drawImage(m,x,GY-24+Math.sin(t*0.7+i)*3);
  }
};
G.drawRoomFront=function(){
  const o=G.room, k=G.ctx, t=G.S.time, m=G.mistOf(o.mist);
  for(let i=0;i<o.mistN;i++){
    const x=W-(((i*97+t*(9+i*3))%(W+96)));
    k.drawImage(m,x,GY-10+Math.sin(t*0.9+i*2)*2);
  }
};

})(window.G);
