/* ================== level.js — مراحل المغامرة والباركور والألغاز ==================
   كل مرحلة تُبنى تلقائياً من مقاطع (segments) حسب رقم الفصل والمرحلة:
     fight  قتال وحوش · spikes أشواك · pits حُفر · plats منصات فوق هاوية
     saws   مناشير دوّارة · pad منصة قفز · chest صندوق يحرسه وحش قوي
   والألغاز أربعة أنواع تتبدل بين الفصول وتصعب مع التقدم:
     stone  أحجار تُدفع إلى البلاطات أو تُستعمل درجةً لتسلّق جدار
     notes  لحن يُعاد على الأجراس (ثم أجراس مبعثرة، ثم لحن معكوس)
     lights مصابيح: ضرب المصباح يقلبه هو وجاريه، والمطلوب إضاءتها كلها
     runes  أعمدة رموز تُضبط مثل النقش الموجود في أول المرحلة (ثم بترتيب معكوس)
   الصعوبة diff = رقم الفصل × 7 + رقم المرحلة، وكل شيء يزداد معها.                */
(function(G){
'use strict';
const W=G.W, H=G.H, GY=G.GY, R=G.R, clamp=G.clamp, r=G.r, pl=G.pl, S=G.S;
const NOTE_F=[392,494,587,784], NOTE_C=['#ff5a4a','#ffe066','#4fd08a','#7fd4ff'];
const RUNE_C=['#ffe066','#7fd4ff','#ff8ad0','#9be07a','#ffb347'];
const PUZ=['stone','notes','lights','runes'];
const WALL_H=44;

function mkRng(s){return ()=>{s=(s*16807)%2147483647;return s/2147483647;};}
// أي لغز في هذه المرحلة؟
function puzzleFor(c,idx){
  if(idx===2)return PUZ[(c*2)%4];
  if(idx===4)return PUZ[(c*2+1)%4];
  if(idx===6&&c>=2)return PUZ[(c*2+2)%4];
  return null;
}

/* ================== بناء المرحلة ================== */
G.buildLevel=function(c,idx){
  const d=c*7+idx, rnd=mkRng(4000+c*977+idx*131);
  const ri=(a,b)=>a+Math.floor(rnd()*(b-a+1));
  const L={c,idx,diff:d,w:0,pits:[],plats:[],spikes:[],saws:[],pads:[],coins:[],chests:[],
           stones:[],plates:[],gates:[],walls:[],bells:[],song:null,tablet:null,
           lamps:[],lights:null,runes:null,mural:null,portal:null,spawn:[],
           dmg:1+d*0.02,hpMul:1+d*0.05,safeX:40,hint:'',t:0};
  let x=150;
  // أنواع الوحوش: العامة تُفتح تدريجياً، ووحش الفصل الخاص يظهر كثيراً
  const types=['sword']; if(d>=2)types.push('archer'); if(d>=5)types.push('armor'); if(d>=8)types.push('mage');
  const theme=G.THEME_FOE[c];
  if(d>=1){types.push(theme);types.push(theme);}
  const foe=(fx,x0,x1,elite,type)=>L.spawn.push({type:type||types[ri(0,types.length-1)],race:rnd()<0.5?'beast':'ifrit',x:fx,minX:x0,maxX:x1,elite:!!elite});
  const arc=(cx,wd,ht)=>{for(let i=0;i<5;i++){const u=i/4;L.coins.push({x:cx-wd/2+wd*u,y:GY-10-Math.sin(u*Math.PI)*ht});}};

  const SEG={
    fight(){
      const n=Math.min(4,1+Math.floor(d/14)+(rnd()<0.5?1:0)), w=170+n*26;
      for(let i=0;i<n;i++)foe(x+60+i*((w-80)/n)+ri(0,14),x+14,x+w-14);
      for(let i=0;i<3;i++)L.coins.push({x:x+30+i*12,y:GY-10});
      return w;
    },
    spikes(){
      const k=2+ri(0,1)+(d>30?1:0); let cur=x+44;
      for(let i=0;i<k;i++){
        const sw=Math.min(28,10+ri(0,2)*6+(d>40?6:0));
        L.spikes.push({x:cur,w:sw}); arc(cur+sw/2,sw+26,26);
        cur+=sw+50+ri(0,18);
      }
      return cur-x;
    },
    pits(){
      const k=2+(d>20?1:0); let cur=x+44;
      for(let i=0;i<k;i++){
        const pw=Math.min(48,30+ri(0,10)+Math.floor(d/8));
        L.pits.push({x0:cur,x1:cur+pw}); arc(cur+pw/2,pw+20,28);
        if(d>24&&i===1&&rnd()<0.6)L.spikes.push({x:cur+pw+8,w:10});
        cur+=pw+50+ri(0,18);
      }
      return cur-x;
    },
    plats(){
      const pw=140+ri(0,26), x0=x+34, n=2;
      L.pits.push({x0:x0,x1:x0+pw});
      for(let i=0;i<n;i++){
        const px=x0+(i+1)*pw/(n+1)-18, py=GY-14-(i%2?10:0)-ri(0,6);
        L.plats.push({x:px,y:py,w:36});
        L.coins.push({x:px+18,y:py-12});
      }
      return pw+70;
    },
    saws(){
      const k=2+(d>25?1:0); let cur=x+54;
      for(let i=0;i<k;i++){
        if(d>12&&rnd()<0.4)L.saws.push({x:cur,y:GY-6,ax:22,ay:0,sp:1.6+rnd()*0.8+d*0.01,ph:rnd()*6,r:7});
        else L.saws.push({x:cur,y:GY-34,ax:0,ay:24,sp:1.8+rnd()+d*0.012,ph:rnd()*6,r:7});
        L.coins.push({x:cur+26,y:GY-10});
        cur+=52+ri(0,14);
      }
      return cur-x;
    },
    pad(){
      L.pads.push({x:x+40});
      L.plats.push({x:x+66,y:GY-68,w:60});
      for(let i=0;i<4;i++)L.coins.push({x:x+74+i*14,y:GY-80});
      if(rnd()<0.5+idx*0.05)L.chests.push({x:x+116,y:GY-68,open:false,crys:rnd()<0.3?1:0});
      L.spikes.push({x:x+84,w:22});
      return 170;
    },
    chest(){
      L.chests.push({x:x+150,y:GY,open:false,crys:1+(d>30?1:0)});
      foe(x+110,x+14,x+190,true);
      if(d>20)foe(x+60,x+14,x+190);
      return 210;
    },

    /* ---------- لغز الأحجار (5 مستويات) ---------- */
    stone(){
      const v=d>=50?4:(d>=36?3:(d>=22?2:(d>=10?1:0)));
      const gate={x:0,open:false,o:0,need:[]};
      const plate=px=>{const pt={x:px,on:false};L.plates.push(pt);gate.need.push(pt);};
      const stone=(sx,lo,hi)=>L.stones.push({x:sx,home:sx,min:lo,max:hi});
      const wall=wx=>L.walls.push({x0:wx,x1:wx+24,top:GY-WALL_H});
      let end;
      if(v===0){            // ادفع الحجر يميناً إلى البلاطة
        end=x+178; plate(x+122); stone(x+50,x+14,end-16); gate.x=end; L.gates.push(gate);
        L.hint='ادفع الحجر فوق البلاطة ليُفتح الباب';
      }else if(v===1){      // البلاطة خلف الحجر: اقفز فوقه وادفعه يساراً
        end=x+182; plate(x+46); stone(x+128,x+14,end-16); gate.x=end; L.gates.push(gate);
        L.hint='البلاطة خلف الحجر: اقفز فوقه وادفعه إليها';
      }else if(v===2){      // جدار عالٍ: اجعل الحجر درجة
        const wx=x+150; wall(wx); stone(x+50,x+14,wx-8); end=wx+24;
        L.hint='الجدار أعلى من قفزتك: ادفع الحجر إليه واصعد عليه';
      }else if(v===3){      // حجران: واحد للبلاطة وواحد للجدار، والترتيب مهم
        const wx=x+214; plate(x+92); stone(x+44,x+14,x+110); stone(x+150,x+124,wx-8); wall(wx);
        end=wx+70; gate.x=end; L.gates.push(gate);
        L.hint='حجران: واحد يفتح الباب والآخر درجة للجدار';
      }else{                // الأول يُدفع يساراً إلى البلاطة، والثاني يميناً إلى الجدار
        const wx=x+236; plate(x+40); stone(x+96,x+14,x+124); stone(x+150,x+140,wx-8); wall(wx);
        end=wx+70; gate.x=end; L.gates.push(gate);
        L.hint='فكّر قبل الدفع: أي حجر للبلاطة وأيّ حجر للجدار؟';
      }
      return end-x+34;
    },

    /* ---------- لغز النوتات ---------- */
    notes(){
      const n=3+(d>=14?1:0)+(d>=35?1:0)+(d>=60?1:0), seq=[];
      for(let i=0;i<n;i++){let v;do{v=ri(0,3);}while(i&&v===seq[i-1]);seq.push(v);}
      const gate={x:x+218,open:false,o:0,need:null};
      L.gates.push(gate);
      L.tablet={x:x+28,glow:0};
      // من الصعوبة 25: الأجراس ليست مرتبة حسب نغمتها
      const order=[0,1,2,3];
      if(d>=25)for(let i=3;i>0;i--){const j=ri(0,i),t=order[i];order[i]=order[j];order[j]=t;}
      for(let i=0;i<4;i++)L.bells.push({x:x+70+i*32,y:GY-36,n:order[i],lit:0,sw:0});
      const rev=d>=45;       // من الصعوبة 45: يجب عزف اللحن معكوساً
      L.song={seq:seq,want:rev?seq.slice().reverse():seq,rev:rev,pos:0,gate:gate,demo:-1,dt:0,heard:false,wait:0};
      L.hint=rev?'استمع للحن ثم اعزفه معكوساً (من آخره إلى أوله)':'اضرب اللوح لتسمع اللحن، ثم اضرب الأجراس بالترتيب نفسه';
      return 252;
    },

    /* ---------- لغز المصابيح: ضرب المصباح يقلبه هو وجاريه ---------- */
    lights(){
      const n=d>=55?6:(d>=35?5:(d>=15?4:3));
      const gate={x:x+60+n*30+24,open:false,o:0,need:null};
      L.gates.push(gate);
      const st=[]; for(let i=0;i<n;i++)st.push(true);
      const flip=i=>{for(let j=i-1;j<=i+1;j++)if(j>=0&&j<n)st[j]=!st[j];};
      // نبدأ من الحل ونقلب عشوائياً: فاللغز له حل دائماً
      let tries=0;
      do{const k=2+ri(0,n);for(let i=0;i<k;i++)flip(ri(0,n-1));tries++;}while(st.every(v=>v)&&tries<20);
      if(st.every(v=>v))flip(0);
      for(let i=0;i<n;i++)L.lamps.push({x:x+60+i*30,on:st[i],cd:0});
      L.lights={gate:gate};
      L.hint='أضئ كل المصابيح: ضرب المصباح يقلبه هو والمصباحين المجاورين';
      return gate.x-x+34;
    },

    /* ---------- لغز الرموز: اضبط الأعمدة مثل النقش في أول المرحلة ---------- */
    runes(){
      const n=d>=30?4:3, k=d>=30?5:4, target=[];
      for(let i=0;i<n;i++)target.push(ri(0,k-1));
      const gate={x:x+60+n*32+24,open:false,o:0,need:null};
      L.gates.push(gate);
      const cols=[];
      for(let i=0;i<n;i++){let v;do{v=ri(0,k-1);}while(v===target[i]);cols.push({x:x+60+i*32,v:v,cd:0});}
      const rev=d>=45;
      L.runes={cols:cols,target:target,k:k,gate:gate,rev:rev};
      L.mural={x:96,sym:rev?target.slice().reverse():target,rev:rev};
      L.hint=rev?'النقش في أول المرحلة مكتوب معكوساً: اضبط الأعمدة بعكس ترتيبه':'تذكّر رموز النقش في أول المرحلة واضبط الأعمدة مثلها';
      return gate.x-x+34;
    }
  };

  // ترتيب المقاطع (المراحل تطول مع التقدم)
  let list=[];
  if(d===0)list=['fight','spikes','pits','fight','spikes'];
  else{
    const n=5+Math.min(4,Math.floor(d/11))+(idx>=5?1:0);
    const pool=['fight','fight','spikes','pits'];
    if(d>=1)pool.push('plats'); if(d>=3)pool.push('saws'); if(d>=2)pool.push('pad');
    let last='';
    for(let i=0;i<n;i++){let s;do{s=pool[ri(0,pool.length-1)];}while(s===last);list.push(s);last=s;}
    if(list.indexOf('fight')<0)list[0]='fight';
    const pz=puzzleFor(c,idx);
    if(pz)list.splice(Math.floor(list.length/2),0,pz);
    if(idx===6||idx===3)list.push('chest');
  }
  for(const s of list)x+=SEG[s]()+34;
  L.portal={x:x+70};
  L.w=x+150;
  return L;
};

/* ================== التصادم مع العالم ================== */
function pitAt(x){
  const L=G.L; if(!L)return null;
  for(const p of L.pits)if(x>p.x0&&x<p.x1)return p;
  return null;
}
// أعلى سطح يهبط عليه اللاعب بين الارتفاعين y0 و y1 (أو null)
G.landY=function(x,y0,y1){
  const L=G.L; let best=null;
  const tryS=s=>{if(y0<=s+0.5&&y1>=s&&(best===null||s<best))best=s;};
  if(!pitAt(x))tryS(GY);
  if(L){
    for(const p of L.plats)if(x>p.x-2&&x<p.x+p.w+2)tryS(p.y);
    for(const s of L.stones)if(Math.abs(x-s.x)<10)tryS(GY-14);
    for(const w of L.walls)if(x>w.x0-3&&x<w.x1+3)tryS(w.top);
  }
  return best;
};
G.hasSupport=function(x,y){
  const L=G.L;
  if(Math.abs(y-GY)<1&&!pitAt(x))return true;
  if(L){
    for(const p of L.plats)if(Math.abs(y-p.y)<1&&x>p.x-2&&x<p.x+p.w+2)return true;
    for(const s of L.stones)if(Math.abs(y-(GY-14))<1&&Math.abs(x-s.x)<10)return true;
    for(const w of L.walls)if(Math.abs(y-w.top)<1&&x>w.x0-3&&x<w.x1+3)return true;
  }
  return false;
};
// هل بين النقطتين باب مغلق أو جدار؟ (يمنع القفز السحري فوق الألغاز)
G.blockedBetween=function(a,b){
  const L=G.L; if(!L)return false;
  const lo=Math.min(a,b), hi=Math.max(a,b);
  for(const g of L.gates)if(!g.open&&g.x>lo&&g.x<hi)return true;
  for(const w of L.walls)if(w.x0<hi&&w.x1>lo)return true;
  return false;
};
function moveStone(s,m){
  const L=G.L;
  let nx=clamp(s.x+m,s.min,s.max);
  for(const o of L.stones)if(o!==s){
    if(m>0&&o.x>s.x)nx=Math.min(nx,o.x-17);
    if(m<0&&o.x<s.x)nx=Math.max(nx,o.x+17);
  }
  const moved=nx-s.x;
  if(Math.abs(moved)>0.01){
    s.x=nx; s.sc=(s.sc||0)-Math.abs(moved);
    if(s.sc<=0){s.sc=7;G.snd('scrape');G.puff(s.x-Math.sign(m)*8,GY-1,'#5a564c');}
  }
  return moved;
}
// الحركة الأفقية مع الأبواب والأحجار والجدران وحواف الحُفر
G.moveX=function(p,nx,dt){
  const L=G.L;
  if(p.y>GY+1){const pit=pitAt(p.x);if(pit)return clamp(nx,pit.x0+4,pit.x1-4);return nx;}
  for(const g of L.gates)if(!g.open){
    if(p.x<=g.x-7&&nx>g.x-7)nx=g.x-7;
    if(p.x>=g.x+7&&nx<g.x+7)nx=g.x+7;
  }
  for(const w of L.walls)if(p.y>w.top+1){
    if(p.x<=w.x0-5&&nx>w.x0-5)nx=w.x0-5;
    if(p.x>=w.x1+5&&nx<w.x1+5)nx=w.x1+5;
  }
  if(p.y>GY-13)for(const s of L.stones){
    const l=s.x-12, rt=s.x+12;
    if(p.x<=l+0.5&&nx>l){nx=l+(p.ground?moveStone(s,Math.min(nx-l,38*dt)):0);}
    else if(p.x>=rt-0.5&&nx<rt){nx=rt+(p.ground?moveStone(s,Math.max(nx-rt,-38*dt)):0);}
  }
  return nx;
};

/* ================== التفاعل: الأجراس، اللوح، المصابيح، الأعمدة، الصناديق ================== */
function openGate(g){
  g.open=true; G.snd('solved'); G.snd('gate'); S.shake=4;
  G.fxAdd({k:'num',x:g.x,y:GY-86,v:'OK',big:true,c:'#4fd08a',max:1});
}
function openChest(c){
  c.open=true;
  G.snd('chest'); G.ring(c.x,c.y-6,26,'#ffd76a',0.4);
  G.spark(c.x,c.y-6,'#ffd76a',14,120);
  G.dropLoot(c.x,c.y-8,10+Math.floor(G.L.diff/3),c.crys);
}
function ringBell(b){
  const L=G.L, sg=L.song;
  b.lit=0.5; b.sw=1;
  G.note(NOTE_F[b.n]); G.ring(b.x,b.y+6,14,NOTE_C[b.n],0.3);
  if(!sg||sg.gate.open||sg.demo>=0)return;
  if(sg.want[sg.pos]===b.n){
    sg.pos++;
    if(sg.pos>=sg.want.length)openGate(sg.gate);
  }else{
    sg.pos=0; sg.wait=0.7; G.snd('wrong'); S.shake=3;
    G.fxAdd({k:'num',x:b.x,y:b.y-10,v:'x',big:true,c:'#ff5a4a',max:0.7});
  }
}
function playSong(){const sg=G.L.song;if(sg&&!sg.gate.open){sg.demo=0;sg.dt=0.35;sg.pos=0;sg.heard=true;}}
function hitLamp(i){
  const L=G.L, a=L.lamps;
  if(L.lights.gate.open||a[i].cd>0)return;
  for(let j=i-1;j<=i+1;j++)if(j>=0&&j<a.length){a[j].on=!a[j].on;a[j].cd=0.3;G.ring(a[j].x,GY-22,10,a[j].on?'#ffe066':'#55505f',0.25);}
  G.note(a[i].on?660:330);
  if(a.every(l=>l.on))openGate(L.lights.gate);
}
function hitRune(c){
  const ru=G.L.runes;
  if(ru.gate.open||c.cd>0)return;
  c.v=(c.v+1)%ru.k; c.cd=0.3;
  G.note(330+c.v*70); G.ring(c.x,GY-30,12,RUNE_C[c.v],0.25);
  if(ru.cols.every((q,i)=>q.v===ru.target[i]))openGate(ru.gate);
}
// ضربة سلاح بين x0 و x1 — ترجع true إذا أصابت شيئاً
G.levelStrike=function(x0,x1,py){
  const L=G.L; if(!L)return false;
  let hit=false;
  for(const c of L.chests)if(!c.open&&c.x>x0-6&&c.x<x1+6&&Math.abs(c.y-py)<30){openChest(c);hit=true;}
  if(py>GY-60){
    for(const b of L.bells)if(b.x>x0-7&&b.x<x1+7&&b.lit<=0.3){ringBell(b);hit=true;break;}
    if(L.tablet&&L.tablet.x>x0-7&&L.tablet.x<x1+7&&L.song.demo<0){playSong();G.snd('click');hit=true;}
    // نضرب أقرب مصباح/عمود فقط حتى لا تُقلب عدة مصابيح بضربة واحدة
    const mid=G.P.x, near=(arr)=>{let b=null,bd=1e9;arr.forEach((o,i)=>{if(o.x>x0-7&&o.x<x1+7&&Math.abs(o.x-mid)<bd){bd=Math.abs(o.x-mid);b=i;}});return b;};
    if(L.lamps.length){const i=near(L.lamps);if(i!==null&&L.lamps[i].cd<=0){hitLamp(i);hit=true;}}
    if(L.runes){const i=near(L.runes.cols);if(i!==null&&L.runes.cols[i].cd<=0){hitRune(L.runes.cols[i]);hit=true;}}
  }
  return hit;
};
// مقذوف اللاعب: يرنّ الجرس أو يقلب المصباح أو يفتح الصندوق أو يصطدم بالباب — ترجع true إذا توقف
G.levelShot=function(s){
  const L=G.L; if(!L)return false;
  for(const g of L.gates)if(!g.open&&Math.abs(s.x-g.x)<5)return true;
  for(const w of L.walls)if(s.x>w.x0&&s.x<w.x1&&s.y>w.top)return true;
  if(s.k==='wave'||s.k==='cres')return false;
  for(const b of L.bells)if(Math.abs(s.x-b.x)<6&&s.y>b.y-2&&s.y<b.y+26&&b.lit<=0.3){ringBell(b);return true;}
  for(let i=0;i<L.lamps.length;i++){const l=L.lamps[i];if(Math.abs(s.x-l.x)<5&&s.y>GY-32&&l.cd<=0){hitLamp(i);return true;}}
  if(L.runes)for(const c of L.runes.cols)if(Math.abs(s.x-c.x)<6&&s.y>GY-44&&c.cd<=0){hitRune(c);return true;}
  for(const c of L.chests)if(!c.open&&Math.abs(s.x-c.x)<7&&s.y>c.y-12&&s.y<=c.y){openChest(c);return true;}
  return false;
};

/* ================== الغنائم المتساقطة ================== */
G.dropLoot=function(x,y,coins,crys){
  for(let i=0;i<coins;i++)G.picks.push({k:'coin',x:x,y:y,vx:R(-60,60),vy:R(-170,-60),t:0});
  for(let i=0;i<(crys||0);i++)G.picks.push({k:'crystal',x:x,y:y,vx:R(-30,30),vy:R(-200,-120),t:0});
};
function take(k,x,y){
  if(k==='coin'){S.gotCoins++;G.addCoins(1);G.snd('coin');G.spark(x,y,'#ffd76a',3,50);}
  else{S.gotCrys++;G.addCrystals(1);G.snd('crystal');G.spark(x,y,'#7fd4ff',10,90);G.ring(x,y,16,'#7fd4ff',0.3);
       G.fxAdd({k:'num',x:x,y:y-8,v:'+1',big:true,c:'#7fd4ff',max:0.8});}
}
G.updPicks=function(dt){
  const P=G.P, a=G.picks;
  for(let i=a.length-1;i>=0;i--){
    const c=a[i]; c.t+=dt;
    const dx=P.x-c.x, dy=(P.y-12)-c.y, m=Math.hypot(dx,dy)||1;
    if(c.t>0.35&&m<46&&P.state!=='dead'){c.vx=dx/m*190;c.vy=dy/m*190;}   // مغناطيس
    else{
      c.vy+=500*dt; c.vx*=0.985;
      if(c.y>=GY-3&&c.vy>0&&!pitAt(c.x)){c.y=GY-3;c.vy*=-0.4;c.vx*=0.7;}
    }
    c.x+=c.vx*dt; c.y+=c.vy*dt;
    if(c.t>0.2&&m<11&&P.state!=='dead'){take(c.k,c.x,c.y);a.splice(i,1);}
    else if(c.y>H+20||c.t>25){
      // ما سقط في الحفرة أو تُرك طويلاً يُحتسب للاعب حتى لا يضيع
      if(c.y>H+20)take(c.k,P.x,P.y-12);
      a.splice(i,1);
    }
  }
};
G.drawPicks=function(){
  const t=S.time;
  for(const c of G.picks){
    if(c.k==='coin')coin(c.x,c.y,t+c.x);
    else crystal(c.x,c.y,t);
  }
};
function coin(x,y,t){
  const w=Math.abs(Math.cos(t*5))*2.5+0.5;
  r(x-w,y-3,w*2,6,'#c9a03c'); r(x-w+0.5,y-2,Math.max(1,w*2-1),4,'#ffd76a');
  if(w>1.5)r(x-1,y-2,1,3,'#fff2c0');
}
function crystal(x,y,t){
  G.glow('#7fd4ff',x,y,0.7+0.2*Math.sin(t*6),0.5);
  r(x-1,y-5,3,1,'#bfeaff'); r(x-2,y-4,5,2,'#7fd4ff'); r(x-3,y-2,7,3,'#4aa3ff'); r(x-2,y+1,5,2,'#2a7fc0'); r(x-1,y+3,3,1,'#2a7fc0');
  r(x-1,y-4,1,4,'#ffffff');
}
G.drawCoinIcon=coin; G.drawCrystalIcon=crystal;

/* ================== تحديث المرحلة ================== */
G.updLevel=function(dt){
  const L=G.L, P=G.P; if(!L)return;
  L.t+=dt;
  const alive=P.state!=='dead';
  // آخر مكان آمن (للعودة إليه بعد السقوط)
  if(alive&&P.ground&&P.y===GY&&P.state!=='hurt'){
    let ok=true;
    for(const s of L.spikes)if(P.x>s.x-14&&P.x<s.x+s.w+14)ok=false;
    if(ok)L.safeX=P.x;
  }
  // السقوط في الحفرة
  if(P.y>H+26){
    if(alive){
      const d=Math.round(G.maxHp()*0.15);
      P.hp-=d; G.snd('fall');
      if(P.hp<=0){P.hp=0;P.state='dead';S.deadT=0.4;G.save.deaths++;G.snd('die');}
      else{
        P.x=L.safeX; P.y=GY; P.vx=P.vy=0; P.ground=true; P.state='idle'; P.inv=1.2;
        P.combo=0; S.flash=0.2;
        G.ring(P.x,P.y-12,24,'#ffffff',0.4);
        G.fxAdd({k:'num',x:P.x,y:P.y-28,v:'-'+d,c:'#ff5a4a',max:0.7});
      }
    }else P.y=H+26;
  }
  if(alive){
    // الأشواك
    for(const s of L.spikes)if(P.x>s.x-2&&P.x<s.x+s.w+2&&P.y>GY-6){if(G.trapHit(12,s.x+s.w/2))G.snd('spike');}
    // المناشير
    for(const w of L.saws){
      const sx=w.x+Math.sin(L.t*w.sp+w.ph)*w.ax, sy=w.y+Math.sin(L.t*w.sp+w.ph)*w.ay;
      if(Math.hypot(P.x-sx,(P.y-11)-sy)<w.r+6){if(G.trapHit(14,sx))G.snd('saw');}
    }
    // منصات القفز
    for(const pd of L.pads)if(P.ground&&Math.abs(P.x-pd.x)<9&&P.y===GY&&P.state!=='dodge'){
      P.vy=-385; P.ground=false; pd.t=0.25; G.snd('pad');
      G.ring(pd.x,GY-2,18,'#ffe066',0.3); for(let i=0;i<6;i++)G.puff(pd.x+R(-6,6),GY-1,'#ffe066');
    }
    // العملات الثابتة
    for(const c of L.coins)if(!c.got&&Math.abs(P.x-c.x)<9&&Math.abs((P.y-11)-c.y)<15){c.got=true;take('coin',c.x,c.y);}
    // الصناديق تُفتح باللمس أيضاً
    for(const c of L.chests)if(!c.open&&Math.abs(P.x-c.x)<8&&Math.abs(P.y-c.y)<4)openChest(c);
    // بوابة النهاية
    if(Math.abs(P.x-L.portal.x)<9&&P.ground&&S.game==='play'){G.stageClear();return;}
  }
  for(const pd of L.pads)if(pd.t>0)pd.t-=dt;
  // البلاطات والأبواب
  for(const pt of L.plates){
    let on=false;
    for(const s of L.stones)if(Math.abs(s.x-pt.x)<6)on=true;
    if(on&&!pt.on){G.snd('plate');G.ring(pt.x,GY-2,16,'#4fd08a',0.3);}
    pt.on=on;
  }
  for(const g of L.gates){
    if(g.need&&!g.open&&g.need.every(p=>p.on)){g.open=true;G.snd('solved');G.snd('gate');S.shake=4;}
    if(g.open&&g.o<1)g.o=Math.min(1,g.o+dt*1.6);
  }
  // الأجراس واللحن والمصابيح والأعمدة
  for(const b of L.bells){if(b.lit>0)b.lit-=dt;if(b.sw>0)b.sw-=dt*1.5;}
  for(const l of L.lamps)if(l.cd>0)l.cd-=dt;
  if(L.runes)for(const c of L.runes.cols)if(c.cd>0)c.cd-=dt;
  const sg=L.song;
  if(sg){
    if(!sg.heard&&alive&&P.x>L.tablet.x-26)playSong();
    if(sg.wait>0){sg.wait-=dt;if(sg.wait<=0)playSong();}
    if(sg.demo>=0){
      sg.dt-=dt;
      if(sg.dt<=0){
        if(sg.demo>=sg.seq.length)sg.demo=-1;
        else{
          const v=sg.seq[sg.demo], b=L.bells.find(q=>q.n===v);
          b.lit=0.45; b.sw=1; G.note(NOTE_F[b.n]); G.ring(b.x,b.y+6,14,NOTE_C[b.n],0.3);
          sg.demo++; sg.dt=0.55;
        }
      }
    }
    if(L.tablet)L.tablet.glow=sg.demo>=0?1:Math.max(0,L.tablet.glow-dt*2);
  }
};

/* ================== الرسم ================== */
// الرموز الخمسة: هلال · حلقة · مثلث · معيّن · ثلاثة خطوط
function glyph(v,x,y,c){
  if(v===0){for(let j=-3;j<=3;j++)for(let i=-3;i<=3;i++)if(i*i+j*j<=10&&(i-1.6)*(i-1.6)+j*j>6.5)r(x+i,y+j,1,1,c);}
  else if(v===1){for(let j=-3;j<=3;j++)for(let i=-3;i<=3;i++){const q=i*i+j*j;if(q<=10&&q>=4)r(x+i,y+j,1,1,c);}}
  else if(v===2){for(let j=0;j<6;j++)r(x-j*0.6,y-3+j,Math.round(j*1.2)+1,1,c);}
  else if(v===3){for(let j=-3;j<=3;j++)r(x-(3-Math.abs(j)),y+j,(3-Math.abs(j))*2+1,1,c);}
  else{r(x-3,y-3,7,1,c);r(x-3,y,7,1,c);r(x-3,y+3,7,1,c);}
}
G.drawLevelBack=function(){
  const L=G.L, t=S.time, cx=G.cam.x, vis=(x,m)=>x>cx-(m||30)&&x<cx+W+(m||30);
  // الحُفر
  for(const p of L.pits)if(vis((p.x0+p.x1)/2,90)){
    const w=p.x1-p.x0;
    r(p.x0,GY,w,H-GY,'#000000');
    r(p.x0,GY,2,H-GY,'#1a1820'); r(p.x1-2,GY,2,H-GY,'#1a1820');
    r(p.x0-1,GY,1,3,'#55505f'); r(p.x1,GY,1,3,'#55505f');
    G.alpha(0.25); r(p.x0+2,GY,w-4,4,'#2a2634'); G.alpha(1);
  }
  // المنصات
  for(const p of L.plats)if(vis(p.x+p.w/2,60)){
    r(p.x,p.y,p.w,5,'#3a3644'); r(p.x,p.y,p.w,1,'#7a7488'); r(p.x+1,p.y+5,p.w-2,2,'#22202a');
    for(let i=4;i<p.w-2;i+=9)r(p.x+i,p.y+2,1,3,'#2a2634');
    r(p.x+2,p.y+7,2,3,'#22202a'); r(p.x+p.w-4,p.y+7,2,3,'#22202a');
  }
  // البلاطات
  for(const pt of L.plates){
    r(pt.x-8,GY-2,16,2,pt.on?'#4fd08a':'#8a6a2a'); r(pt.x-8,GY-2,16,1,pt.on?'#c0ffd8':'#c9a03c');
    if(!pt.on&&(t*2|0)%2){r(pt.x-1,GY-12,2,5,'#c9a03c');r(pt.x-3,GY-8,6,1,'#c9a03c');r(pt.x-2,GY-7,4,1,'#c9a03c');r(pt.x-1,GY-6,2,1,'#c9a03c');}
    if(pt.on)G.glow('#4fd08a',pt.x,GY-2,0.7,0.6);
  }
  // الأبواب
  for(const g of L.gates)if(vis(g.x)){
    const lift=Math.round(g.o*64);
    r(g.x-7,GY-78,14,6,'#2e2a36'); r(g.x-7,GY-78,14,1,'#55505f');
    for(let i=-1;i<=1;i++){r(g.x+i*4-1,GY-72-lift,2,72,'#55505f');r(g.x+i*4-1,GY-72-lift,1,72,'#8a8496');}
    for(let y=GY-60;y<GY;y+=18)r(g.x-6,y-lift,12,2,'#3a3644');
  }
  // لوح اللحن والأجراس
  if(L.tablet&&vis(L.tablet.x)){
    const x=L.tablet.x;
    r(x-7,GY-22,14,22,'#34303e'); r(x-6,GY-24,12,2,'#34303e'); r(x-7,GY-22,1,22,'#55506a');
    const c=L.tablet.glow>0?'#fff2c0':'#c9a03c';
    r(x+1,GY-18,1,8,c); r(x-2,GY-12,4,3,c); r(x+2,GY-18,3,2,c);
    if(L.tablet.glow>0)G.glow('#ffd76a',x,GY-14,L.tablet.glow,0.7);
  }
  for(const b of L.bells)if(vis(b.x)){
    const sw=Math.sin(t*20)*b.sw*3, c=NOTE_C[b.n], lit=b.lit>0;
    for(let y=0;y<b.y;y+=3)r(b.x,y,1,2,'#3a3642');
    r(b.x-2+sw,b.y,5,2,'#8a6a2a'); r(b.x-4+sw,b.y+2,9,6,lit?'#ffffff':c); r(b.x-5+sw,b.y+8,11,2,lit?'#ffffff':c);
    r(b.x-1+sw*1.5,b.y+10,2,3,'#d8cfa8');
    for(let i=0;i<=b.n;i++)r(b.x-b.n*2+i*4-1,b.y+15,2,2,c);     // عدد النقاط = رقم الجرس
    if(lit)G.glow(c,b.x,b.y+5,1,0.9);
  }
  const sg=L.song;
  if(sg&&!sg.gate.open&&vis(sg.gate.x,120)){
    for(let i=0;i<sg.seq.length;i++)r(sg.gate.x-sg.seq.length*3+i*6,GY-92,4,4,i<sg.pos?'#4fd08a':'#3a3644');
    if(sg.rev&&L.tablet){const x=L.tablet.x;pl(x-5,GY-30,x+5,GY-30,'#ff8ad0');pl(x-5,GY-30,x-2,GY-33,'#ff8ad0');pl(x-5,GY-30,x-2,GY-27,'#ff8ad0');}
  }
  // الجدران العالية
  for(const w of L.walls)if(vis((w.x0+w.x1)/2,60)){
    const ww=w.x1-w.x0, hh=GY-w.top;
    r(w.x0,w.top,ww,hh,'#34303e'); r(w.x0,w.top,ww,2,'#7a7488'); r(w.x0,w.top,2,hh,'#55506a'); r(w.x1-2,w.top,2,hh,'#1c1924');
    for(let y=w.top+8;y<GY;y+=9){r(w.x0,y,ww,1,'#1c1924');r(w.x0+((y/9|0)%2?8:16),y-8,1,8,'#1c1924');}
  }
  // نقش الرموز في أول المرحلة
  if(L.mural&&vis(L.mural.x,90)){
    const m=L.mural, n=m.sym.length, ww=n*14+8, x0=m.x-ww/2, y0=GY-78;
    r(x0-2,y0-2,ww+4,22,'#8a6a2a'); r(x0,y0,ww,18,'#1a1420'); r(x0,y0,ww,1,'#c9a03c');
    for(let i=0;i<n;i++)glyph(m.sym[i],x0+11+i*14,y0+9,RUNE_C[m.sym[i]]);
    if(m.rev){pl(x0+4,y0+24,x0+ww-4,y0+24,'#ff8ad0');pl(x0+4,y0+24,x0+8,y0+21,'#ff8ad0');pl(x0+4,y0+24,x0+8,y0+27,'#ff8ad0');}
    G.glow('#c9a03c',m.x,y0+9,0.4+0.15*Math.sin(t*3),1.2);
  }
  // أعمدة الرموز
  if(L.runes)for(const c of L.runes.cols)if(vis(c.x)){
    r(c.x-7,GY-4,14,4,'#2e2a36'); r(c.x-5,GY-40,10,36,'#3a3644'); r(c.x-5,GY-40,1,36,'#6a6478'); r(c.x+4,GY-40,1,36,'#22202a');
    r(c.x-7,GY-44,14,4,'#55505f'); r(c.x-7,GY-44,14,1,'#8a8496');
    r(c.x-5,GY-38,10,13,'#1a1420');
    glyph(c.v,c.x,GY-31-(c.cd>0?1:0),RUNE_C[c.v]);
    G.glow(RUNE_C[c.v],c.x,GY-31,0.45,0.6);
  }
  // المصابيح
  for(let i=0;i<L.lamps.length;i++){
    const l=L.lamps[i]; if(!vis(l.x))continue;
    if(i)for(let xx=L.lamps[i-1].x+7;xx<l.x-6;xx+=4)r(xx,GY-3,2,1,'#55505f');     // رابط بين الجارين
    r(l.x-5,GY-3,10,3,'#2e2a36'); r(l.x-1,GY-18,2,15,'#55505f'); r(l.x-4,GY-20,8,2,'#55505f');
    const c=l.on?'#ffe066':'#2a2634';
    r(l.x-3,GY-27,6,7,c); r(l.x-2,GY-29,4,2,c); r(l.x-1,GY-30,2,1,c);
    if(l.on){r(l.x-1,GY-26,2,4,'#ffffff');G.glow('#ffd76a',l.x,GY-24,0.9+0.1*Math.sin(t*8+i),0.9);}
    else r(l.x-3,GY-27,1,7,'#3a3644');
  }
  // منصات القفز
  for(const pd of L.pads)if(vis(pd.x)){
    const up=pd.t>0?4:0;
    r(pd.x-8,GY-3-up,16,3,'#c9a03c'); r(pd.x-8,GY-3-up,16,1,'#ffe066'); r(pd.x-5,GY-up,10,up,'#8a6a2a');
    const a=(t*3)%1;
    G.alpha(1-a); for(let i=0;i<3;i++)r(pd.x-2+i-1,GY-8-a*10-i,5-i*2,1,'#ffe066'); G.alpha(1);
  }
  // الصناديق
  for(const c of L.chests)if(vis(c.x)){
    const y=c.y;
    r(c.x-7,y-9,14,9,'#6b4a2a'); r(c.x-7,y-9,14,1,'#8a6a3a'); r(c.x-7,y-5,14,1,'#c9a03c'); r(c.x-7,y-9,1,9,'#c9a03c'); r(c.x+6,y-9,1,9,'#c9a03c');
    if(c.open){r(c.x-7,y-13,14,4,'#3a2a1a');r(c.x-6,y-9,12,2,'#1a120a');}
    else{r(c.x-1,y-6,2,3,'#ffd76a');if(c.crys)G.glow('#7fd4ff',c.x,y-6,0.5+0.3*Math.sin(t*4),0.6);else G.glow('#ffd76a',c.x,y-6,0.35+0.2*Math.sin(t*4),0.5);}
  }
  // العملات
  for(const c of L.coins)if(!c.got&&vis(c.x))coin(c.x,c.y+Math.sin(t*3+c.x*0.1)*1.5,t+c.x*0.05);
  // بوابة النهاية
  const po=L.portal;
  if(vis(po.x,60)){
    r(po.x-13,GY-40,4,40,'#3a3644'); r(po.x+9,GY-40,4,40,'#3a3644'); r(po.x-13,GY-44,26,5,'#55505f'); r(po.x-13,GY-44,26,1,'#8a8496');
    for(let y=0;y<38;y+=2){const w=8+Math.sin(y*0.5+t*6)*1.5;G.alpha(0.55);r(po.x-w,GY-38+y,w*2,2,y%4?'#7fd4ff':'#c07aff');}
    G.alpha(1);
    for(let i=0;i<6;i++){const a=t*3+i*1.05;r(po.x+Math.cos(a)*6,GY-20+Math.sin(a)*14,1,1,'#ffffff');}
    G.glow('#7fd4ff',po.x,GY-20,0.9,1.3);
  }
};
G.drawLevelMid=function(){
  const L=G.L, t=S.time, cx=G.cam.x;
  // الأحجار
  for(const s of L.stones){
    r(s.x-8,GY-14,16,14,'#4a4654'); r(s.x-8,GY-14,16,1,'#8a8496'); r(s.x-8,GY-14,1,14,'#6a6478'); r(s.x+7,GY-14,1,14,'#2a2634'); r(s.x-8,GY-1,16,1,'#2a2634');
    for(let y=-3;y<=3;y++)for(let x=-3;x<=3;x++)if(x*x+y*y<=9&&(x-1.5)*(x-1.5)+y*y>6.5)r(s.x+x,GY-7+y,1,1,'#c9a03c');
  }
  // الأشواك
  for(const s of L.spikes)if(s.x>cx-40&&s.x<cx+W+10){
    for(let x=s.x;x<s.x+s.w;x+=6){
      for(let i=0;i<7;i++){const w=Math.max(1,6-i);r(x+(6-w)/2,GY-1-i,w,1,i>4?'#ffffff':(i%2?'#8a93a6':'#c8d0e0'));}
    }
    r(s.x-1,GY-1,s.w+2,1,'#3a3644');
  }
};
G.drawLevelFront=function(){
  const L=G.L, t=S.time, cx=G.cam.x;
  // المناشير
  for(const w of L.saws)if(w.x>cx-50&&w.x<cx+W+50){
    const sx=w.x+Math.sin(L.t*w.sp+w.ph)*w.ax, sy=w.y+Math.sin(L.t*w.sp+w.ph)*w.ay;
    G.alpha(0.25);
    if(w.ay)r(w.x,w.y-w.ay,1,w.ay*2,'#8a93a6'); else r(w.x-w.ax,w.y,w.ax*2,1,'#8a93a6');
    G.alpha(1);
    for(let i=0;i<8;i++){const a=t*14+i*0.785;r(sx+Math.cos(a)*(w.r+1)-1,sy+Math.sin(a)*(w.r+1)-1,3,3,'#dfe6f5');}
    G.ell(sx,sy,w.r,w.r,'#8a93a6'); G.ell(sx,sy,w.r-2,w.r-2,'#c8d0e0'); G.ell(sx,sy,2,2,'#3a3346');
    r(sx-w.r+2,sy-1,3,1,'#ffffff');
  }
};

})(window.G);
