/* ================== draw.js — أدوات الرسم بالبكسل ================== */
(function(G){
'use strict';
const W=G.W, H=G.H;
const cv=G.$('c'); cv.width=W; cv.height=H;
G.cv=cv;
G.mainCtx=cv.getContext('2d');
G.ctx=G.mainCtx;
// تغيير لوحة الرسم (تُستخدم لرسم الشخصيات داخل القائمة)
G.setCtx=function(c){G.ctx=c||G.mainCtx;};

G.r=function(x,y,w,h,c){
  const k=G.ctx; k.fillStyle=c; k.fillRect(Math.round(x),Math.round(y),w,h);
};
// خط بالبكسل
G.pl=function(x0,y0,x1,y1,c,th){
  th=th||1;
  const k=G.ctx, n=Math.max(Math.abs(x1-x0),Math.abs(y1-y0))|0;
  k.fillStyle=c;
  for(let i=0;i<=n;i++){
    const t=n?i/n:0;
    k.fillRect(Math.round(x0+(x1-x0)*t),Math.round(y0+(y1-y0)*t),th,th);
  }
};
// شكل بيضاوي مصمت
G.ell=function(cx,cy,rx,ry,c){
  const k=G.ctx; k.fillStyle=c;
  for(let y=-ry;y<=ry;y++){
    const hw=Math.round(rx*Math.sqrt(Math.max(0,1-(y*y)/(ry*ry))));
    if(hw>0)k.fillRect(Math.round(cx-hw),Math.round(cy+y),hw*2,1);
  }
};
G.ringPx=function(x,y,rad,c){
  const k=G.ctx, n=Math.max(10,(rad*2.2)|0);
  k.fillStyle=c;
  for(let i=0;i<n;i++){
    const a=i/n*Math.PI*2;
    k.fillRect(Math.round(x+Math.cos(a)*rad),Math.round(y+Math.sin(a)*rad*0.8),1,1);
  }
};
G.txt=function(s,x,y,c,big){
  const k=G.ctx;
  k.font='bold '+(big?11:8)+'px monospace';
  k.textAlign='center'; k.textBaseline='middle';
  k.fillStyle='#000000'; k.fillText(s,Math.round(x)+1,Math.round(y)+1);
  k.fillStyle=c; k.fillText(s,Math.round(x),Math.round(y));
};
G.alpha=function(a){G.ctx.globalAlpha=a;};
G.add=function(on){G.ctx.globalCompositeOperation=on?'lighter':'source-over';};

/* ---------- التوهجات (تُصنع مرة واحدة لكل لون) ---------- */
const glows={};
function rgb(hex){
  const n=parseInt(hex.slice(1),16);
  return [(n>>16)&255,(n>>8)&255,n&255];
}
G.glowOf=function(hex){
  if(glows[hex])return glows[hex];
  const c=document.createElement('canvas'); c.width=c.height=64;
  const g=c.getContext('2d'), v=rgb(hex), s=v[0]+','+v[1]+','+v[2];
  const gr=g.createRadialGradient(32,32,1,32,32,32);
  gr.addColorStop(0,'rgba('+s+',0.55)'); gr.addColorStop(0.4,'rgba('+s+',0.16)'); gr.addColorStop(1,'rgba('+s+',0)');
  g.fillStyle=gr; g.fillRect(0,0,64,64);
  return (glows[hex]=c);
};
// رسم توهج في المكان x,y · a=الشفافية · s=الحجم
G.glow=function(hex,x,y,a,s){
  const k=G.ctx, z=64*(s||1), pa=k.globalAlpha;
  k.globalCompositeOperation='lighter';
  k.globalAlpha=pa*(a==null?1:a);
  k.drawImage(G.glowOf(hex),Math.round(x-z/2),Math.round(y-z/2),z,z);
  k.globalAlpha=pa; k.globalCompositeOperation='source-over';
};

/* ---------- الضباب ---------- */
const mists={};
G.mistOf=function(hex){
  if(mists[hex])return mists[hex];
  const c=document.createElement('canvas'); c.width=96; c.height=28;
  const g=c.getContext('2d'), v=rgb(hex), s=v[0]+','+v[1]+','+v[2];
  g.save(); g.scale(1,28/96);
  const gr=g.createRadialGradient(48,48,2,48,48,48);
  gr.addColorStop(0,'rgba('+s+',0.20)'); gr.addColorStop(1,'rgba('+s+',0)');
  g.fillStyle=gr; g.fillRect(0,0,96,96);
  g.restore();
  return (mists[hex]=c);
};

/* ---------- تعتيم الأطراف ---------- */
G.vig=document.createElement('canvas'); G.vig.width=W; G.vig.height=H;
(function(){
  const g=G.vig.getContext('2d');
  const gr=g.createRadialGradient(W/2,H/2+10,60,W/2,H/2+10,210);
  gr.addColorStop(0,'rgba(0,0,0,0)'); gr.addColorStop(1,'rgba(0,0,0,0.85)');
  g.fillStyle=gr; g.fillRect(0,0,W,H);
})();

})(window.G);
