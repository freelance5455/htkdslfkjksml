/* ================== enemies.js — وحوش وعفاريت المراحل ==================
   الأنواع العامة: sword سيّاف · armor مدرّع (يصدّ من الأمام) · archer رامٍ · mage ساحر
   ولكل فصل وحش خاص يناسب زعيمه (G.THEME_FOE بالترتيب):
     skeleton هيكل عظمي ينهض بعد موته · blade سيف مسكون ينقضّ · spiderling عنكبوت قافز
     wisp روح جليد تبطّئك · imp عفريت حمم ينفجر · bat خفاش دم · wolf ذئب مندفع
     ghost شبح يختفي · whelp تنين صغير ينفث · watcher عين طافية · guard حارس ملكي
   القوي (elite) أكبر وأخطر ويُسقط كريستالاً.                                         */
(function(G){
'use strict';
const W=G.W, GY=G.GY, R=G.R, clamp=G.clamp, r=G.r, pl=G.pl, ell=G.ell, S=G.S;

// ai=طريقة التصرف · hp=الصحة · spd=السرعة · dmg=الضرر · tel=مدة التحذير · coins=الذهب عند الموت
const TYPES={
  sword: {ai:'melee',hp:36, hw:6,h:22,spd:50,dmg:10,tel:0.38,coins:3,reach:24},
  armor: {ai:'melee',hp:85, hw:7,h:23,spd:24,dmg:16,tel:0.62,coins:6,reach:24,shield:true,slam:true},
  archer:{ai:'shoot',hp:26, hw:6,h:22,spd:42,dmg:8, tel:0.45,coins:4},
  mage:  {ai:'cast', hp:30, hw:6,h:24,spd:30,dmg:10,tel:0.60,coins:5},
  // ---- وحوش الفصول ----
  skeleton:  {ai:'melee',  hp:40, hw:6,h:22,spd:44,dmg:11,tel:0.40,coins:5,reach:25,revive:true,el:'fire',blood:'#d8cfa8'},
  blade:     {ai:'charge', hp:38, hw:5,h:20,hov:8, fly:true,spd:34,dmg:13,tel:0.50,coins:5,el:'blood',blood:'#c8d0e0'},
  spiderling:{ai:'leap',   hp:22, hw:7,h:9, spd:62,dmg:8, tel:0.28,coins:3,el:'poison',blood:'#9be04a'},
  wisp:      {ai:'flyshoot',hp:28,hw:6,h:12,hov:16,fly:true,spd:28,dmg:8, tel:0.50,coins:5,el:'ice',blood:'#8fd8ff',slow:true},
  imp:       {ai:'melee',  hp:34, hw:6,h:16,spd:58,dmg:10,tel:0.32,coins:5,reach:20,boom:true,el:'fire',blood:'#ffb347'},
  bat:       {ai:'dive',   hp:24, hw:7,h:9, hov:30,fly:true,spd:52,dmg:9, tel:0.38,coins:4,leech:true,el:'blood',blood:'#ff4a4a'},
  wolf:      {ai:'charge', hp:44, hw:9,h:14,spd:60,dmg:12,tel:0.40,coins:5,el:'bolt',blood:'#b3202e'},
  ghost:     {ai:'dive',   hp:34, hw:6,h:18,hov:12,fly:true,spd:36,dmg:11,tel:0.50,coins:6,fade:true,el:'dark',blood:'#8affc0'},
  whelp:     {ai:'breath', hp:62, hw:9,h:15,spd:32,dmg:9, tel:0.60,coins:7,el:'fire',blood:'#cfc8b0'},
  watcher:   {ai:'flyshoot',hp:42,hw:7,h:14,hov:20,fly:true,spd:24,dmg:12,tel:0.65,coins:7,el:'dark',blood:'#c07aff',fast:true},
  guard:     {ai:'melee',  hp:120,hw:7,h:26,spd:36,dmg:18,tel:0.50,coins:10,reach:38,shield:true,el:'fire',blood:'#ffd76a'}
};
G.THEME_FOE=['skeleton','blade','spiderling','wisp','imp','bat','wolf','ghost','whelp','watcher','guard'];
const RACE={
  beast:{sk:'#6a5a80',dk:'#3e3450',el:'dark',  blood:'#8a4ac0'},
  ifrit:{sk:'#c2410c',dk:'#7a2a0a',el:'fire',  blood:'#ffb347'}
};
function diff(){return G.L?G.L.diff:70;}

// إضافة وحش (تُستخدم في المراحل، وكذلك حين يستدعي الزعيم حرّاسه)
G.addEnemy=function(s,hpMul){
  const T=TYPES[s.type], sc=s.elite?1.45:1, RC=RACE[s.race]||RACE.beast;
  const hp=Math.round(T.hp*(hpMul||1)*(s.elite?3.2:1));
  const e={isEnemy:true,type:s.type,race:s.race||'beast',elite:!!s.elite,sc:sc,ai:T.ai,
    x:s.x,y:GY,f:-1,hp:hp,max:hp,state:'idle',t:0,cd:R(0.4,1.2),bcd:0,stun:0,
    minX:s.minX,maxX:s.maxX,al:1,flash:0,mv:false,shield:!!T.shield,fly:!!T.fly,
    hov0:(T.hov||0)*sc,lt:0,sx:0,tx:0,fadeT:R(1,3),revived:false,noLoot:!!s.noLoot,
    el:T.el||RC.el,
    def:{hw:T.hw*sc,h:T.h*sc,hov:(T.hov||0)*sc,blood:T.blood||RC.blood}};
  G.enemies.push(e);
  return e;
};
G.spawnEnemies=function(L){
  G.enemies.length=0;
  for(const s of L.spawn)G.addEnemy(s,L.hpMul);
};
G.staggerEnemy=function(e,big){
  if(e.state==='dead'||e.state==='bones')return;
  const P=G.P;
  if(e.shield&&!big&&!P.pierce&&e.stun<=0&&(P.x-e.x)*e.f>0)e.blockT=0.3;     // صدّ بالدرع (يظهر في صورته)
  if((e.elite||e.shield)&&!big)return;
  if(e.state==='leap'||e.state==='dive'||e.state==='dash'){if(!big)return;e.y=GY;e.def.hov=e.hov0;}
  e.state='hurt'; e.t=big?0.3:0.18;
  e.x=clamp(e.x+(e.x>=G.P.x?1:-1)*(big?8:3),e.minX,e.maxX);
};
G.stunEnemy=function(e,d){
  if(e.state==='dead'||e.state==='bones')return;
  e.stun=d; e.state='idle'; e.y=GY; e.def.hov=e.hov0; G.snd('stun');
};
G.killEnemy=function(e){
  const T=TYPES[e.type], d=diff();
  // الهيكل العظمي يتفكك ثم ينهض مرة واحدة
  if(T.revive&&!e.revived){
    e.revived=true; e.state='bones'; e.t=2.4; e.al=0.45; e.hp=1; e.dot=null;
    G.snd('efall'); G.debris(e.x,e.y-12,'#d8cfa8',6);
    return;
  }
  const spr=G.FOE_SPRITES&&G.FOE_SPRITES[e.type];
  e.state='dead'; e.t=spr&&spr.ok?0.9:0.5; e.dot=null;     // وقت أطول ليظهر سقوطه إن كانت له صورة
  G.snd('efall');
  const cy=e.y-e.def.hov-e.def.h/2;
  G.spark(e.x,cy,e.def.blood,e.elite?24:12,120);
  G.ring(e.x,cy,e.elite?34:18,e.def.blood,0.3);
  // عفريت الحمم ينفجر عموداً من النار
  if(T.boom){G.flames.push({x:e.x,warn:0.45,act:0.35,on:false,el:'fire'});G.snd('cast');}
  // الغنيمة: ذهب دائماً، وكريستال من الوحوش القوية
  if(!e.noLoot)G.dropLoot(e.x,cy,T.coins+Math.floor(d/10)+(e.elite?12:0),e.elite?(1+(d>35?1:0)):0);
  if(e.elite){S.slow=0.4;S.shake=7;G.debris(e.x,cy,e.def.blood,8);}
};

function hitP(e,d){
  const ok=G.bossHit(d*(e.elite?1.5:1)*(G.B?0.7:1),e.x);
  if(ok&&TYPES[e.type].leech){e.hp=Math.min(e.max,e.hp+8);G.puff(e.x,e.y-e.def.hov-4,'#ff4a4a');}
  return ok;
}
function melee(e,T,reach){
  const P=G.P;
  G.snd(T.slam?'slam':'sw_sword');
  G.fxAdd({k:'arc',x:e.x+e.f*4,y:e.y-12*e.sc,s:reach*0.55,a0:1.4,a1:-1.2,d:e.f,c:'#ffffff',max:0.16});
  const lo=Math.min(e.x,e.x+e.f*reach), hi=Math.max(e.x,e.x+e.f*reach);
  if(P.x>lo-4&&P.x<hi+4&&Math.abs(P.y-e.y)<26)hitP(e,T.dmg);
}
function touch(e){
  const P=G.P, b=G.bossBox(e);
  return Math.abs(P.x-e.x)<e.def.hw+5&&P.y>b.top&&P.y-22<b.bot;
}

G.updEnemies=function(dt){
  const P=G.P, a=G.enemies, d=diff();
  const quick=Math.max(0.6,1-d*0.004);       // الأعداء أسرع مع تقدّم المراحل
  for(let i=a.length-1;i>=0;i--){
    const e=a[i], T=TYPES[e.type], EL=G.ELEM[e.el];
    e.flash=Math.max(0,e.flash-dt); e.mv=false; if(e.blockT>0)e.blockT-=dt; if(e.vanT>0)e.vanT-=dt;
    if(e.state==='dead'){
      e.t-=dt; e.al=clamp(e.t/0.5,0,1);
      if(e.t<=0)a.splice(i,1);
      continue;
    }
    if(e.state==='bones'){
      e.t-=dt;
      if(e.t<0.5&&Math.random()<0.5)G.spark(e.x+R(-5,5),e.y-R(0,14),'#d8cfa8',1,40);
      if(e.t<=0){e.state='idle';e.al=1;e.hp=Math.round(e.max*0.5);e.cd=0.6;G.ring(e.x,e.y-12,18,'#d8cfa8',0.3);G.sfx(160,0.25,'sawtooth',0.04,120);}
      continue;
    }
    if(e.stun>0){e.stun-=dt;continue;}
    if(e.state==='hurt'){e.t-=dt;if(e.t<=0){e.state='idle';e.cd=Math.max(e.cd,0.25);}continue;}
    const dx=P.x-e.x, dist=Math.abs(dx);
    const see=dist<150&&Math.abs(P.y-e.y)<70&&P.state!=='dead'&&e.x>G.cam.x-20&&e.x<G.cam.x+W+20;
    e.cd-=dt; e.bcd-=dt;
    const sp=T.spd*(1+d*0.004);
    const walk=(dir,v)=>{const nx=clamp(e.x+dir*v*dt,e.minX,e.maxX);if(Math.abs(nx-e.x)>0.01){e.x=nx;e.mv=true;}return e.mv;};
    const rest=(lo,hi)=>{e.state='idle';e.cd=R(lo,hi)*quick;};

    // الشبح يختفي ويظهر (لا يُصاب وهو مختفٍ)
    if(T.fade&&e.state==='idle'){
      e.fadeT-=dt;
      if(e.fadeT<=0){e.hid=!e.hid;e.fadeT=e.hid?R(1.2,2):R(2,3.2);}
      e.al+=((e.hid?0.2:1)-e.al)*Math.min(1,dt*5);
    }else if(T.fade)e.al=Math.min(1,e.al+dt*5);

    /* ---------- تنفيذ الهجمات ---------- */
    if(e.state==='tel'){
      e.t-=dt;
      if(e.ai==='charge')walk(-e.f,20);
      if(e.t>0)continue;
      if(e.ai==='melee'){
        e.state='act'; e.t=0.2; melee(e,T,T.reach*e.sc);
        if(T.slam){S.shake=Math.max(S.shake,3);for(let j=0;j<5;j++)G.puff(e.x+e.f*14+R(-6,6),GY-1,'#5a564c');}
      }else if(e.ai==='shoot'){
        e.state='act'; e.t=0.2;
        const n=e.elite?3:1;
        const hd=G.foeHand&&G.foeHand(e), hx=hd?hd[0]:8, hy=hd?-hd[1]:13;    // يخرج السهم من القوس
        for(let j=0;j<n;j++)G.eshots.push({x:e.x+e.f*hx*e.sc,y:e.y-hy*e.sc-(j-(n-1)/2)*7,vx:e.f*(170+d),vy:(j-(n-1)/2)*-14,hom:0,sp:170,life:1.7,
                                            el:e.el,d:T.dmg*(e.elite?1.4:1),arrow:true});
        G.snd('arrow');
      }else if(e.ai==='cast'){
        e.state='act'; e.t=0.2;
        if(Math.random()<0.5){
          const hd=G.foeHand&&G.foeHand(e);           // تخرج الكرة من كفه
          G.eshots.push({x:e.x+e.f*(hd?hd[0]:6)*e.sc,y:e.y-(hd?-hd[1]:20)*e.sc,vx:e.f*60,vy:-30,hom:210,sp:88+d*0.5,life:3,el:e.el,d:T.dmg,big:e.elite});
          G.snd('bolt');
        }else{
          const n=e.elite?3:1;
          for(let j=0;j<n;j++)G.flames.push({x:clamp(P.x+P.vx*0.3+(j-(n-1)/2)*30,e.minX-30,e.maxX+30),warn:0.7+j*0.15,act:0.3,on:false,el:e.el});
          G.snd('cast');
        }
      }else if(e.ai==='flyshoot'){
        e.state='act'; e.t=0.25;
        const ox=e.x+e.f*5, oy=e.y-e.def.hov-e.def.h/2, v=T.fast?215:125+d*0.4;
        const an=Math.atan2((P.y-12)-oy,P.x-ox), n=e.elite?3:1;
        for(let j=0;j<n;j++){
          const aa=an+(j-(n-1)/2)*0.3;
          G.eshots.push({x:ox,y:oy,vx:Math.cos(aa)*v,vy:Math.sin(aa)*v,hom:0,sp:v,life:2.4,el:e.el,d:T.dmg,slow:!!T.slow,big:!!T.fast});
        }
        G.snd(T.fast?'beam':'bolt');
      }else if(e.ai==='leap'){
        e.state='leap'; e.lt=0; e.sx=e.x; e.tx=clamp(P.x+P.vx*0.2,e.minX,e.maxX); G.snd('jump');
      }else if(e.ai==='charge'){
        e.state='dash'; e.t=0.55; e.hitD=false; G.snd('charge');
      }else if(e.ai==='dive'){
        e.state='dive'; e.lt=0; e.sx=e.x; e.tx=clamp(P.x+P.vx*0.25,e.minX,e.maxX); e.hitD=false; G.snd('whoosh');
      }else if(e.ai==='breath'){
        e.state='breath'; e.t=0.75; G.snd('breath');
      }
      continue;
    }
    if(e.state==='act'){
      e.t-=dt;
      if(e.t<=0)rest.apply(null,({melee:[0.6,1.2],shoot:[1.3,1.9],cast:[2.0,2.8],flyshoot:[1.6,2.4]})[e.ai]||[1,1.5]);
      continue;
    }
    if(e.state==='leap'){               // قفزة العنكبوت
      e.lt+=dt/0.45;
      const u=Math.min(1,e.lt);
      e.x=e.sx+(e.tx-e.sx)*u; e.y=GY-Math.sin(Math.PI*u)*26*e.sc; e.mv=true;
      if(u>0.5&&touch(e)&&!e.hitD){e.hitD=true;hitP(e,T.dmg);}
      if(u>=1){e.y=GY;e.hitD=false;rest(0.7,1.2);}
      continue;
    }
    if(e.state==='dash'){               // انقضاض الذئب والسيف المسكون
      e.t-=dt;
      const moved=walk(e.f,240);
      if(Math.random()<0.6)G.puff(e.x-e.f*6,e.y-e.def.hov-R(0,8),'#3c3447');
      if(!e.hitD&&touch(e)){e.hitD=true;hitP(e,T.dmg);}
      if(e.t<=0||!moved)rest(0.9,1.5);
      continue;
    }
    if(e.state==='dive'){               // انقضاض الخفاش والشبح من الأعلى
      e.lt+=dt/0.7;
      const u=Math.min(1,e.lt);
      e.x=e.sx+(e.tx-e.sx)*Math.min(1,u*1.6); e.mv=true;
      e.def.hov=e.hov0*(1-Math.sin(Math.PI*u))+2*Math.sin(Math.PI*u);
      if(!e.hitD&&touch(e)){e.hitD=true;hitP(e,T.dmg);}
      if(u>=1){e.def.hov=e.hov0;rest(1.0,1.8);}
      continue;
    }
    if(e.state==='breath'){             // نَفَس التنين الصغير
      e.t-=dt;
      const range=58*e.sc, dd=(P.x-e.x)*e.f;
      if(Math.random()<0.7)G.spark(e.x+e.f*R(12,range),GY-R(2,16),EL[2],1,40);
      if(dd>4&&dd<range&&P.y>GY-26)hitP(e,T.dmg);
      if(e.t<=0)rest(1.4,2.2);
      continue;
    }

    /* ---------- الحالة العادية ---------- */
    if(!see){
      if(!walk(e.f,10))e.f=-e.f;        // دورية هادئة
      continue;
    }
    e.f=dx>=0?1:-1;
    const tel=()=>{e.state='tel';e.t=T.tel*quick;};
    if(e.ai==='melee'){
      const stop=(T.reach-6)*e.sc;
      if(dist>stop)walk(e.f,sp);
      else if(e.cd<=0){tel();G.sfx(T.slam?120:420,0.12,'triangle',0.03,100);}
    }else if(e.ai==='shoot'){
      if(dist<55)walk(-e.f,sp);
      else if(dist>120)walk(e.f,sp*0.7);
      if(e.cd<=0){tel();G.snd('sw_bow');}
    }else if(e.ai==='cast'){
      if(dist<34&&e.bcd<=0){
        // يختفي ويظهر بعيداً
        e.bcd=3.2;
        for(let j=0;j<8;j++)G.puff(e.x+R(-5,5),e.y-R(0,22),EL[2]);
        e.x=(P.x-e.minX>e.maxX-P.x)?e.minX+6:e.maxX-6; e.vanT=0.4;     // يظهر من الدخان (في صورته)
        for(let j=0;j<8;j++)G.puff(e.x+R(-5,5),e.y-R(0,22),EL[2]);
        G.snd('vanish');
      }else if(dist<60)walk(-e.f,sp);
      if(e.cd<=0){tel();G.snd('cast');}
    }else if(e.ai==='flyshoot'){
      if(dist<60)walk(-e.f,sp); else if(dist>115)walk(e.f,sp);
      if(e.cd<=0&&e.al>0.6){tel();G.snd('cast');}
    }else if(e.ai==='leap'){
      if(dist>70)walk(e.f,sp);
      else if(e.cd<=0)tel();
      else if(dist<24)walk(-e.f,sp*0.6);
    }else if(e.ai==='charge'){
      if(dist>120)walk(e.f,sp);
      else if(e.cd<=0){tel();G.snd('tel');}
      else if(dist<40)walk(-e.f,sp*0.7);
    }else if(e.ai==='dive'){
      if(dist>46)walk(e.f,sp);
      else if(e.cd<=0&&!e.hid){tel();}
    }else if(e.ai==='breath'){
      if(dist>44*e.sc)walk(e.f,sp);
      else if(e.cd<=0){tel();G.snd('tel');}
    }
  }
};

/* ================== الرسم ================== */
// الأنواع الأربعة العامة (وحش أو عفريت)
function drawFoe(e,C,t){
  const RC=RACE[e.race], ty=e.type, tel=e.state==='tel', act=e.state==='act';
  const st=e.mv?((t*8|0)%2):0, bob=e.mv?st:0;
  const eye=tel?'#ffffff':(e.race==='ifrit'?'#ffe066':'#ff5a4a');
  const elc=G.ELEM[RC.el];
  if(ty==='mage'){
    for(let i=0;i<14;i+=2){const w=3+Math.round(i*0.22);r(-w,-14+i+bob,w*2,2,C(i%6?'#3a2a5a':'#2a1c44'));}
    r(-4,-16+bob,8,3,C('#4a3870')); r(-1,-12+bob,2,8,C(elc[1]));
  }else{
    if(st){r(-4,-6,2,5,C(RC.dk)); r(2,-6,2,6,C(RC.sk));}
    else{r(-3,-6,2,6,C(RC.dk)); r(1,-6,2,6,C(RC.sk));}
    r(-4+st,-1,3,1,C('#1a1820')); r(1,-1,3,1,C('#1a1820'));
    if(ty==='armor'){r(-5,-16+bob,10,10,C('#6d7587')); r(-5,-16+bob,10,1,C('#a9b2c4')); r(-5,-16+bob,2,10,C('#4a5060')); r(-5,-8+bob,10,2,C('#3a3d4a'));}
    else if(ty==='archer'){r(-4,-15+bob,8,9,C('#3a5a34')); r(-4,-15+bob,2,9,C('#2a4226')); r(-4,-9+bob,8,1,C('#6b4a2a')); pl(-3,-15+bob,3,-8+bob,C('#6b4a2a'));}
    else{r(-4,-15+bob,8,9,C('#5a3a2a')); r(-4,-15+bob,2,9,C('#3e2a1e')); r(-4,-9+bob,8,1,C('#c9a03c')); r(-2,-13+bob,4,4,C(RC.sk));}
  }
  const hy=-21+bob;
  r(-3,hy,7,6,C(RC.sk)); r(-3,hy,2,6,C(RC.dk));
  r(1,hy+2,2,1,eye); r(4,hy+2,1,1,eye);
  if(e.race==='beast'){
    pl(-3,hy,-5,hy-3,C(RC.dk),2); pl(3,hy,5,hy-3,C(RC.sk),2);
    r(2,hy+4,1,2,'#ffffff'); r(4,hy+4,1,2,'#ffffff'); r(1,hy+5,4,1,C(RC.dk));
  }else{
    pl(-2,hy,-4,hy-4,C('#e8e0d0')); pl(3,hy,5,hy-4,C('#e8e0d0'));
    const fl=(t*12|0)%2;
    r(-1,hy-2-fl,3,2+fl,'#ffb347'); r(0,hy-3-fl,1,1,'#fff2c0');
    r(1,hy+4,3,1,'#3a0c04');
  }
  if(ty==='sword'){
    const a=tel?2.1:(act?-1.0:-0.5), ca=Math.cos(a), sa=-Math.sin(a), hx=4, hyy=-12+bob;
    pl(hx,hyy,hx+ca*11,hyy+sa*11,C('#dfe6f5'),2); pl(hx+ca*8,hyy+sa*8,hx+ca*12-sa*2,hyy+sa*12+ca*2,C('#ffffff'));
    r(hx-1,hyy-1,3,3,C('#8a6a2a'));
  }else if(ty==='armor'){
    r(-4,hy-1,9,4,C('#6d7587')); r(-4,hy-1,9,1,C('#a9b2c4')); r(1,hy+2,3,1,eye);
    const sx=tel?1:(act?7:4);
    r(sx,-17+bob,4,13,C('#4a5060')); r(sx,-17+bob,4,1,C('#a9b2c4')); r(sx+3,-17+bob,1,13,C('#8a93a6')); r(sx+1,-12+bob,2,3,C('#c9a03c'));
    if(tel){pl(-3,-14+bob,-6,-24+bob,C('#6b4a2a'),2); r(-9,-28+bob,6,5,C('#8a93a6'));}
    else if(act){pl(2,-12+bob,10,-6+bob,C('#6b4a2a'),2); r(9,-8+bob,6,5,C('#8a93a6'));}
  }else if(ty==='archer'){
    r(-4,hy-1,8,3,C('#2a4226')); r(-5,hy+1,2,4,C('#2a4226'));
    const bx=6, pull=tel?3:0;
    pl(bx,-20+bob,bx+3,-16+bob,C('#8a5a2a')); pl(bx+3,-16+bob,bx+3,-9+bob,C('#8a5a2a')); pl(bx+3,-9+bob,bx,-5+bob,C('#8a5a2a'));
    pl(bx,-20+bob,bx-pull,-12+bob,C('#d8cfa8')); pl(bx-pull,-12+bob,bx,-5+bob,C('#d8cfa8'));
    if(tel){r(bx-pull,-13+bob,10,1,C('#b08a55')); r(bx-pull+10,-14+bob,2,3,'#ffffff');}
  }else{
    for(let i=0;i<6;i++)r(-4+Math.round(i*0.6),hy-1-i,8-i,1,C(i%3?'#3a2a5a':'#4a3870'));
    r(-5,hy,10,1,C('#2a1c44'));
    const up=tel?-4:0;
    pl(6,-24+bob+up,6,-1,C('#6b4a2a')); r(4,-28+bob+up,5,5,C(elc[1])); r(5,-27+bob+up,3,3,C(elc[2])); r(6,-26+bob+up,1,1,'#ffffff');
    G.glow(elc[2],6,-26+bob+up,tel?1:0.4,tel?0.8:0.4);
  }
}
// وحوش الفصول (كل واحد برسمه)
const DRAW={
  skeleton(e,C,t){
    if(e.state==='bones'){      // كومة عظام
      r(-7,-2,14,2,C('#b9ad8c')); r(-4,-4,5,2,C('#d8cfa8')); r(2,-5,5,4,C('#d8cfa8')); r(3,-4,1,1,'#0a0a0f'); r(5,-4,1,1,'#0a0a0f'); pl(-8,-1,-2,-5,C('#8f8468'));
      return;
    }
    const st=e.mv?((t*8|0)%2):0, tel=e.state==='tel', act=e.state==='act';
    pl(-2,-7,-3+st,0,C('#d8cfa8')); pl(2,-7,3-st,0,C('#b9ad8c'));
    r(-3,-9,6,2,C('#b9ad8c')); r(0,-16,1,8,C('#d8cfa8'));
    for(let i=0;i<3;i++)r(-3,-15+i*2,7,1,C(i%2?'#b9ad8c':'#d8cfa8'));
    r(-3,-22,7,6,C('#e8e0c8')); r(-3,-22,2,6,C('#b9ad8c')); r(-1,-17,4,2,C('#d8cfa8'));
    r(0,-20,2,2,'#0a0a0f'); r(3,-20,1,2,'#0a0a0f'); r(0,-20,1,1,tel?'#ffffff':'#ffb14a');
    const a=tel?2.1:(act?-1.0:-0.4), ca=Math.cos(a), sa=-Math.sin(a);
    pl(3,-14,3+ca*5,-14+sa*5,C('#b9ad8c'));
    pl(3+ca*5,-14+sa*5,3+ca*16,-14+sa*16,C('#8a7a5a'),2); pl(3+ca*7,-14+sa*7,3+ca*16,-14+sa*16,C('#b08a55'));
  },
  blade(e,C,t){
    const sp=e.state==='dash', tel=e.state==='tel';
    const a=sp?0:(tel?0.5:-1.57+Math.sin(t*3)*0.15), ca=Math.cos(a), sa=-Math.sin(a), cy=-10;
    G.glow('#ff4a4a',0,cy,tel?1:0.5,0.7);
    pl(-ca*9,cy-sa*9,ca*11,cy+sa*11,C('#c8d0e0'),2); pl(-ca*4,cy-sa*4,ca*11,cy+sa*11,C('#ffffff'));
    pl(-ca*6+sa*4,cy-sa*6-ca*4,-ca*6-sa*4,cy-sa*6+ca*4,C('#8a6a2a'),2);
    r(-ca*6-1,cy-sa*6-1,2,2,tel?'#ffffff':'#ff3b2f');
    for(let i=0;i<3;i++){G.alpha(G.ctx.globalAlpha*0.5);r(-ca*8+Math.sin(t*5+i)*3,cy-sa*8-i*2,2,2,'#7a1c2a');}
  },
  spiderling(e,C,t){
    const mv=e.mv?2:0.4;
    for(let i=0;i<3;i++){const s=Math.sin(t*14+i*2)*mv;
      pl(2,-5,5+i*2,-9,C('#2a1f2e')); pl(5+i*2,-9,8+i*2+s,0,C('#3a2b40'));
      pl(-2,-5,-5-i*2,-9,C('#2a1f2e')); pl(-5-i*2,-9,-8-i*2-s,0,C('#3a2b40'));}
    ell(-3,-6,5,4,C('#1e1624')); r(-5,-8,3,1,C('#c0283a')); ell(4,-5,3,3,C('#3a2b40'));
    const ey=e.state==='tel'?'#ffffff':'#ff4a4a'; r(5,-7,1,1,ey); r(6,-5,1,1,ey);
  },
  wisp(e,C,t){
    const tel=e.state==='tel', fl=Math.round(Math.sin(t*10)*1.5);
    G.glow('#6ac8ff',0,-7,tel?1:0.7,0.8);
    for(let i=0;i<5;i++)r(-1+Math.sin(t*6+i)*2,-14-i*2+fl,2,2,C(i%2?'#8fd8ff':'#2a7fc0'));
    ell(0,-7,6,6,C('#2a7fc0')); ell(0,-7,4,4,C('#8fd8ff')); ell(0,-8,2,2,'#ffffff');
    r(1,-8,1,2,'#081420'); r(4,-8,1,2,'#081420');
    for(let i=0;i<3;i++)r(-4+i*4,-1+((t*8+i*3)%4),1,2,C('#8fd8ff'));
  },
  imp(e,C,t){
    const st=e.mv?((t*10|0)%2):0, tel=e.state==='tel', lv=(t*8|0)%2?'#ffb347':'#ff7a2a';
    r(-3+st,-4,2,4,C('#7a2a0a')); r(1-st,-4,2,4,C('#c2410c'));
    ell(0,-9,5,5,C('#7a2a0a')); ell(0,-10,4,4,C('#c2410c')); pl(-2,-12,1,-8,lv); r(-1,-9,2,2,lv);
    r(-3,-16,6,4,C('#c2410c')); pl(-3,-16,-5,-19,C('#e8e0d0')); pl(2,-16,4,-19,C('#e8e0d0'));
    r(0,-15,2,1,tel?'#ffffff':'#ffe066'); r(-1,-18,2,2,lv);
    const a=tel?2:(e.state==='act'?-0.8:0), ca=Math.cos(a), sa=-Math.sin(a);
    pl(3,-10,3+ca*6,-10+sa*6,C('#c2410c'),2); r(3+ca*6,-10+sa*6,2,2,'#fff2c0');
    pl(-4,-6,-8,-8+Math.sin(t*6)*2,C('#7a2a0a'));
    G.glow('#ff5a1a',0,-9,0.5,0.5);
  },
  bat(e,C,t){
    const fl=Math.sin(t*(e.state==='dive'?30:16)), w=Math.round(fl*5);
    pl(-2,-5,-10,-7-w,C('#3a0a14'),2); pl(-10,-7-w,-6,-2,C('#5a0c18')); pl(-6,-2,-2,-4,C('#5a0c18'));
    pl(2,-5,10,-7-w,C('#3a0a14'),2); pl(10,-7-w,6,-2,C('#5a0c18')); pl(6,-2,2,-4,C('#5a0c18'));
    ell(0,-5,3,4,C('#2a060e')); r(-2,-10,1,2,C('#2a060e')); r(2,-10,1,2,C('#2a060e'));
    const ey=e.state==='tel'?'#ffffff':'#ff3b2f'; r(-1,-7,1,1,ey); r(2,-7,1,1,ey); r(0,-4,1,2,'#ffffff');
  },
  wolf(e,C,t){
    const run=e.mv, st=run?Math.round(Math.sin(t*26)*3):0, tel=e.state==='tel';
    for(let i=0;i<6;i++)r(-10-i*1.3,-11+i*0.7+Math.sin(t*6+i)*1.5,3,2,C('#2a2630'));
    pl(-6,-8,-7+st,0,C('#2a2630'),2); pl(-3,-8,-2-st,0,C('#3a3644'),2);
    pl(4,-8,5-st,0,C('#2a2630'),2); pl(7,-8,8+st,0,C('#3a3644'),2);
    ell(0,-10,9,4,C('#3a3644')); ell(1,-11,7,3,C('#4a4656'));
    r(6,-15-(tel?1:0),6,6,C('#3a3644')); r(11,-12,5,3,C('#4a4656')); r(15,-12,1,1,'#0a0a0f');
    pl(7,-15,6,-18,C('#2a2630')); pl(10,-15,11,-18,C('#2a2630'));
    r(9,-13,1,1,tel?'#ffffff':'#ffe066'); r(12,-9,1,1,'#ffffff'); r(14,-9,1,1,'#ffffff');
  },
  ghost(e,C,t){
    const tel=e.state==='tel';
    G.glow('#8affc0',0,-9,0.5,0.8);
    for(let i=0;i<18;i+=2){const w=i<6?3+i*0.5:6, s=Math.round(Math.sin(t*4+i*0.4)*(i>10?1.5:0));r(-w+s,-18+i,w*2,2,C(i%4?'#b8d8cc':'#d8f4ea'));}
    for(let i=0;i<4;i++)r(-6+i*3+Math.round(Math.sin(t*5+i)),0,2,2+(i%2),C('#b8d8cc'));
    r(-3,-13,2,3,'#081410'); r(1,-13,2,3,'#081410'); r(-3,-13,1,1,tel?'#ffffff':'#8affc0'); r(1,-13,1,1,tel?'#ffffff':'#8affc0');
    r(-1,-8,3,tel?3:1,'#081410');
    pl(5,-10,9,-12+Math.sin(t*4)*2,C('#b8d8cc')); pl(-5,-10,-9,-8,C('#b8d8cc'));
  },
  whelp(e,C,t){
    const st=e.mv?Math.round(Math.sin(t*14)*2):0, br=e.state==='breath', tel=e.state==='tel';
    for(let i=0;i<7;i++)r(-9-i*2,-6+Math.sin(t*4+i*0.6)*2+i*0.5,3,2,C(i%2?'#cfc8b0':'#8f8468'));
    pl(-5,-6,-6+st,0,C('#8f8468'),2); pl(4,-6,5-st,0,C('#cfc8b0'),2);
    ell(-1,-9,8,5,C('#8f8468')); for(let i=0;i<4;i++)r(-6+i*3,-13,1,8,C('#cfc8b0'));
    const wf=Math.sin(t*6)*3; pl(-3,-13,-9,-20+wf,C('#cfc8b0')); pl(-9,-20+wf,-13,-12+wf,C('#8f8468')); pl(-9,-20+wf,-5,-12,C('#8f8468'));
    const hy=-15-(tel?2:0);
    pl(5,-11,9,hy+2,C('#cfc8b0'),2); r(8,hy-2,7,5,C('#cfc8b0')); r(14,hy,3,3,C('#8f8468')); pl(9,hy-2,6,hy-6,C('#cfc8b0'));
    r(11,hy-1,1,1,tel?'#ffffff':'#ffb347');
    if(br||tel){r(13,hy+3,4,2,'#7a2a0a');r(14,hy+3,2,1,'#ffb347');}
    if(br){
      const k=G.ctx, a0=k.globalAlpha;
      for(let i=0;i<44;i+=3){const u=i/44, w=2+u*9;k.globalAlpha=a0*(1-u*0.6);r(17+i,hy+3+u*(12-hy-15)*0.6-w/2+Math.sin(i+t*40)*1.5,3,w,i%2?'#ffb347':'#c2410c');}
      k.globalAlpha=a0;
    }
  },
  watcher(e,C,t){
    const tel=e.state==='tel';
    for(let k=0;k<4;k++)for(let i=0;i<7;i++)r(-5+k*3+Math.sin(t*4+k+i*0.5)*(i*0.3),-2+i,1,1,C(i%3?'#3a1a5a':'#6a1cb0'));
    ell(0,-8,7,7,C('#2a0a4a')); ell(0,-8,5,5,C('#e8e0f0'));
    ell(2,-8,3,3,C('#8a2be2')); r(2,-10,tel?2:1,4,tel?'#ffffff':'#050408'); r(0,-10,1,1,'#ffffff');
    G.glow('#c07aff',2,-8,tel?1:0.4,tel?0.9:0.5);
  },
  guard(e,C,t){
    const st=e.mv?((t*8|0)%2):0, bob=st, tel=e.state==='tel', act=e.state==='act';
    r(-3-st,-7,3,7,C('#2a241c')); r(1+st,-7,3,7,C('#3a3226')); r(-4,-1,4,1,C('#1a1610')); r(1,-1,4,1,C('#1a1610'));
    r(-5,-19+bob,10,12,C('#3a3226')); r(-5,-19+bob,2,12,C('#2a241c')); r(-5,-19+bob,10,1,C('#c9a03c')); r(-5,-9+bob,10,2,C('#c9a03c')); r(-1,-16+bob,2,6,C('#ffb347'));
    r(-7,-21+bob,4,4,C('#55493a')); r(4,-21+bob,4,4,C('#55493a')); r(-7,-21+bob,4,1,C('#c9a03c')); r(4,-21+bob,4,1,C('#c9a03c'));
    for(let i=0;i<10;i+=2)r(-8-i*0.2+Math.sin(t*4)*(i/10),-18+i+bob,3,2,C(i%4?'#4a0c14':'#2a0a0a'));
    r(-3,-26+bob,7,7,C('#2a241c')); r(-3,-26+bob,7,1,C('#c9a03c')); r(0,-23+bob,4,1,tel?'#ffffff':'#ffb347'); r(1,-22+bob,1,3,C('#0a0605'));
    r(-1,-29+bob,3,3,C('#c9a03c')); r(0,-30+bob,1,1,'#ff3b2f');
    const sx=tel?0:(act?6:3);
    r(sx+1,-20+bob,5,14,C('#55493a')); r(sx+1,-20+bob,5,1,C('#c9a03c')); r(sx+1,-7+bob,5,1,C('#c9a03c')); r(sx+3,-15+bob,1,4,C('#ffb347'));
    const off=tel?-8:(act?12:0);
    pl(-6+off,-13+bob,22+off,-13+bob,C('#6b4a2a')); pl(22+off,-13+bob,29+off,-13+bob,C('#dfe6f5'),1); r(21+off,-14+bob,2,3,C('#c9a03c')); r(29+off,-13+bob,1,1,'#ffffff');
  }
};
G.drawEnemies=function(){
  const k=G.ctx, t=S.time, cx=G.cam.x;
  for(const e of G.enemies){
    if(e.x<cx-40||e.x>cx+W+40)continue;
    const cy=e.y-e.def.hov-e.def.h/2;
    if(e.elite&&e.state!=='dead')G.glow(e.def.blood,e.x,cy,0.5+0.2*Math.sin(t*5),1.1);
    G.alpha(0.3*e.al); r(e.x-e.def.hw,GY,e.def.hw*2,2,'#000000'); G.alpha(1);
    k.save();
    k.globalAlpha=e.al;
    k.translate(Math.round(e.x+(e.stun>0?Math.sin(t*30):0)),Math.round(e.y-e.def.hov+(e.fly?Math.sin(t*3+e.minX)*2:0)+(e.state==='dead'?(1-e.al)*4:0)));
    k.scale(e.f*e.sc,e.sc);
    if(e.state==='hurt')k.translate(-1,0);
    const fl=e.flash>0, C=c=>fl?'#ffffff':c;
    // إن كانت للوحش صورة (sprites.js) يُرسم منها، وإلا يُرسم بالكود
    if(!(G.drawSpriteFoe&&G.drawSpriteFoe(e,fl))){if(DRAW[e.type])DRAW[e.type](e,C,t); else drawFoe(e,C,t);}
    k.restore();
    G.alpha(1);
    if(e.state==='dead'||e.state==='bones')continue;
    const top=e.y-e.def.hov-e.def.h;
    // شريط الصحة + علامة التحذير + نجوم الشلل + تاج القوي + أثر النزيف/السم
    if(e.hp<e.max){r(e.x-8,top-6,16,3,'#000000');r(e.x-7,top-5,Math.round(14*e.hp/e.max),1,e.elite?'#ffb347':'#e0525f');}
    if(e.elite){r(e.x-3,top-11,7,2,'#ffd76a');r(e.x-3,top-13,1,2,'#ffd76a');r(e.x,top-14,1,3,'#ffd76a');r(e.x+3,top-13,1,2,'#ffd76a');}
    if(e.state==='tel'&&(t*12|0)%2)G.txt('!',e.x,top-(e.elite?20:12),'#ff5a4a',e.elite);
    if(e.stun>0)for(let i=0;i<3;i++){const a=t*6+i*2.09;r(e.x+Math.cos(a)*7-1,top-5+Math.sin(a)*2,2,2,'#ffe066');}
    if(e.dot)r(e.x-1,top-9,3,3,e.dot.c);
  }
};

})(window.G);
