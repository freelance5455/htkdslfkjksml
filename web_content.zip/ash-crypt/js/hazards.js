/* ================== hazards.js — أخطار الزعماء: أعمدة، موجات، كرات، مقذوفات ساقطة ================== */
(function(G){
'use strict';
const W=G.W, GY=G.GY, R=G.R, r=G.r, S=G.S;
const flames=G.flames, waves=G.waves, eshots=G.eshots, drops=G.drops;

// ضرر من الزعيم إلى اللاعب (يطبّق مضاعف ضرر الزعيم وامتصاص الصحة)
G.bossHit=function(d,fromX){
  const b=G.B;
  // في المراحل يُضرب الضرر بمضاعف صعوبة المرحلة
  const ok=G.hurtP(Math.round(d*(b?(b.def.dmg||1):(G.L?G.L.dmg:1))),fromX);
  if(ok&&b&&b.def.leech&&b.state!=='dead'){
    b.hp=Math.min(b.max,b.hp+b.def.leech);
    G.fxAdd({k:'num',x:b.x,y:G.bossBox().top-4,v:'+'+b.def.leech,c:'#ff4a4a',max:0.8});
    G.snd('leech');
  }
  return ok;
};

G.clearHazards=function(){flames.length=0;waves.length=0;eshots.length=0;drops.length=0;};

G.updHazards=function(dt){
  const P=G.P;
  // أعمدة تخرج من الأرض
  for(let i=flames.length-1;i>=0;i--){
    const f=flames[i];
    if(f.warn>0){
      f.warn-=dt;
      if(f.warn<=0){f.on=true;S.shake=Math.max(S.shake,2);G.snd('pillar');}
    }else{
      f.act-=dt;
      if(Math.abs(P.x-f.x)<9)G.bossHit(15,f.x);
      if(Math.random()<0.6)G.spark(f.x+R(-5,5),GY-R(0,40),G.ELEM[f.el][2],1,40);
      if(f.act<=0)flames.splice(i,1);
    }
  }
  // موجات الصدمة الأرضية (اقفز فوقها)
  for(let i=waves.length-1;i>=0;i--){
    const w=waves[i];
    w.x+=w.vx*dt; w.life-=dt;
    if(Math.random()<0.5)G.spark(w.x,GY-2,G.ELEM[w.el][2],1,30);
    if(Math.abs(P.x-w.x)<6&&P.y>GY-9)G.bossHit(15,w.x-Math.sign(w.vx)*4);
    if(w.life<=0||w.x<4||w.x>G.worldW()-4)waves.splice(i,1);
  }
  // كرات الطاقة (بعضها يلاحق اللاعب)
  for(let i=eshots.length-1;i>=0;i--){
    const s=eshots[i];
    s.life-=dt;
    if(s.hom){
      const dx=P.x-s.x, dy=(P.y-12)-s.y, m=Math.hypot(dx,dy)||1;
      s.vx+=dx/m*s.hom*dt; s.vy+=dy/m*s.hom*dt;
      const v=Math.hypot(s.vx,s.vy), mx=s.sp;
      if(v>mx){s.vx*=mx/v;s.vy*=mx/v;}
    }
    s.x+=s.vx*dt; s.y+=s.vy*dt;
    if(!s.arrow&&Math.random()<0.5)G.parts.push({x:s.x,y:s.y,vx:R(-8,8),vy:R(-8,8),life:0.3,max:0.3,c:G.ELEM[s.el][2],g:0});
    const rad=s.big?9:6;
    if(Math.abs(P.x-s.x)<rad&&s.y>P.y-24-(s.big?3:0)&&s.y<P.y+2){
      const ok=G.bossHit(s.d,s.x-Math.sign(s.vx)*4);
      if(ok&&s.slow){P.slowT=2.2;G.fxAdd({k:'num',x:P.x,y:P.y-34,v:'~',big:true,c:'#8fd8ff',max:0.7});}   // الجليد يبطّئ اللاعب
      if(ok||P.inv<=0){boom(s);eshots.splice(i,1);continue;}
    }
    if(s.life<=0||s.x<G.cam.x-30||s.x>G.cam.x+W+30||s.y<-20||s.y>=GY){boom(s);eshots.splice(i,1);}
  }
  // مقذوفات تسقط من الأعلى
  for(let i=drops.length-1;i>=0;i--){
    const d=drops[i];
    if(d.warn>0){d.warn-=dt;continue;}
    d.y+=280*dt;
    if(Math.abs(P.x-d.x)<7&&d.y>P.y-24&&d.y<P.y+4)G.bossHit(d.d,d.x);
    if(d.y>=GY){
      G.spark(d.x,GY-2,G.ELEM[d.el][2],6,80); G.ring(d.x,GY-2,10,G.ELEM[d.el][2],0.2);
      G.snd('drop'); drops.splice(i,1);
    }
  }
};
function boom(s){
  const c=G.ELEM[s.el];
  G.spark(s.x,Math.min(s.y,GY-1),c[2],s.big?12:5,s.big?110:70);
  if(s.big){G.ring(s.x,Math.min(s.y,GY-2),18,c[2],0.25);S.shake=Math.max(S.shake,3);G.snd('thud');}
}

/* ---------- الرسم ---------- */
G.drawHazardsBack=function(){
  const t=S.time;
  for(const f of flames){
    const c=G.ELEM[f.el];
    if(!f.on){
      // علامة تحذير على الأرض
      if((t*14|0)%2)r(f.x-6,GY,12,1,c[2]);
      r(f.x,GY-2-((t*60)%30),1,2,c[2]);
      r(f.x-4,GY-2-((t*60+11)%30),1,1,c[1]);
      r(f.x+4,GY-2-((t*60+21)%30),1,1,c[1]);
      G.alpha(0.5); G.ringPx(f.x,GY,5+((t*20)%4),c[1]); G.alpha(1);
    }else if(f.el==='ice'){
      // أشواك جليدية
      for(let y=0;y<56;y++){const w=Math.max(1,Math.round((1-y/56)*6));r(f.x-w,GY-y,w*2,1,y%5<2?c[3]:(y%2?c[1]:c[2]));}
      for(const d of [-8,8])for(let y=0;y<26;y++){const w=Math.max(1,Math.round((1-y/26)*3));r(f.x+d-w,GY-y,w*2,1,y%2?c[1]:c[2]);}
      G.glow(c[2],f.x,GY-24,1);
    }else{
      for(let y=0;y<GY;y+=4){
        const w=5+((Math.sin(y*0.9+t*40)*2)|0);
        r(f.x-w-1,y,w*2+2,4,c[0]); r(f.x-w,y,w*2,4,c[1]);
        r(f.x-w+2,y,w*2-4,4,c[2]); r(f.x-1,y,3,4,c[3]);
      }
      G.glow(c[2],f.x,GY-8,1); G.glow(c[2],f.x,GY-58,1); G.glow(c[2],f.x,GY-108,1);
    }
  }
  for(const d of drops){
    const c=G.ELEM[d.el];
    // ظل التحذير
    G.alpha(0.5+0.4*Math.sin(t*30)); r(d.x-5,GY,10,1,c[2]); r(d.x-2,GY+1,4,1,c[1]); G.alpha(1);
    if(d.warn<=0){
      r(d.x-2,d.y-6,5,6,c[1]); r(d.x-1,d.y-4,3,5,c[2]); r(d.x,d.y-1,1,2,c[3]);
      G.alpha(0.4); r(d.x,d.y-18,1,12,c[2]); G.alpha(1);
      G.glow(c[2],d.x,d.y-3,0.7,0.6);
    }
  }
};
G.drawHazardsFront=function(){
  const t=S.time;
  for(const w of waves){
    const c=G.ELEM[w.el], h=7+((t*30|0)%3);
    r(w.x-3,GY-h+2,6,h-2,c[0]);
    r(w.x-2,GY-h,4,h,c[1]); r(w.x-1,GY-h+2,2,h-2,c[2]);
    r(w.x-Math.sign(w.vx)*4,GY-3,2,3,c[0]);
    r(w.x-Math.sign(w.vx)*7,GY-2,2,2,c[0]);
  }
  for(const s of eshots){
    if(s.arrow){      // سهم الرامي
      const d=s.vx>=0?1:-1;
      r(s.x-d*9,s.y,9,1,'#b08a55'); r(s.x-1,s.y-1,3,3,'#dfe6f5'); r(s.x-d*10,s.y-1,2,3,'#9b2335');
      G.alpha(0.3); r(s.x-d*20,s.y,10,1,'#ffffff'); G.alpha(1);
      continue;
    }
    const c=G.ELEM[s.el], z=s.big?3:2, p=((t*20|0)%2);
    G.glow(c[2],s.x,s.y,0.9,s.big?1:0.6);
    r(s.x-z-1,s.y-z,z*2+2,z*2,c[1]); r(s.x-z,s.y-z-1,z*2,z*2+2,c[1]);
    r(s.x-z+1,s.y-z+1,z*2-2,z*2-2,c[2]); r(s.x-1+p,s.y-1,2,2,c[3]);
    if(s.hom){r(s.x-z-3,s.y-1-p,2,2,c[1]);r(s.x+z+1,s.y-1+p,2,2,c[1]);}   // أجنحة خفاش/روح
  }
};

})(window.G);
