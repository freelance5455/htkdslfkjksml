/* ================== effects.js — الجزيئات والمؤثرات القتالية ================== */
(function(G){
'use strict';
const R=G.R, clamp=G.clamp, GY=G.GY, r=G.r, pl=G.pl;
const parts=G.parts, fx=G.fx, ghosts=G.ghosts;

// شرر متطاير
G.spark=function(x,y,c,n,sp){
  for(let i=0;i<n;i++){
    const a=R(0,Math.PI*2), s=R(sp*0.3,sp);
    parts.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-20,life:R(0.2,0.5),max:0.5,c,g:260});
  }
};
// نفثة غبار/دخان
G.puff=function(x,y,c){
  parts.push({x,y,vx:R(-12,12),vy:R(-30,-8),life:R(0.3,0.7),max:0.7,c,g:0});
};
// شظايا كبيرة (حطام)
G.debris=function(x,y,c,n){
  for(let i=0;i<n;i++){
    parts.push({x,y,vx:R(-70,70),vy:R(-170,-60),life:R(0.5,0.9),max:0.9,c,g:520,s:2});
  }
};
// إضافة مؤثر: ring | star | cut | num | arc | bolt | spike
G.fxAdd=function(o){if(o.t==null)o.t=0;fx.push(o);return o;};
G.ring=function(x,y,s,c,max){fx.push({k:'ring',x,y,s,c,t:0,max:max||0.3});};

G.updParts=function(dt){
  if(parts.length>700)parts.splice(0,parts.length-700);
  for(let i=parts.length-1;i>=0;i--){
    const p=parts[i];
    p.life-=dt; p.vy+=p.g*dt; p.x+=p.vx*dt; p.y+=p.vy*dt;
    if(p.y>GY){p.y=GY;p.vy*=-0.3;p.vx*=0.6;if(p.stain&&!p.st){p.st=1;G.addStain(p.x,p.c);}}
    if(p.life<=0)parts.splice(i,1);
  }
};
G.updFx=function(dt){
  for(let i=fx.length-1;i>=0;i--){
    fx[i].t+=dt;
    if(fx[i].t>=fx[i].max)fx.splice(i,1);
  }
  for(let i=decals.length-1;i>=0;i--){
    decals[i].t+=dt;
    if(decals[i].t>=decals[i].max)decals.splice(i,1);
  }
  for(let i=ghosts.length-1;i>=0;i--){
    ghosts[i].life-=dt;
    if(ghosts[i].life<=0)ghosts.splice(i,1);
  }
};
/* ================== لمسات واقعية ================== */
const decals=[];          // آثار على الأرض: بقع دم، حروق، سهام مغروزة
G.decals=decals;
function floorOk(x){return !G.L||(G.hasSupport&&G.hasSupport(x,GY));}
function addDecal(o){o.t=0;decals.push(o);if(decals.length>90)decals.shift();}
// قطرات دم تسقط وتترك بقعة حيث تقع
G.blood=function(x,y,c,n){
  for(let i=0;i<n;i++)parts.push({x,y,vx:R(-55,55),vy:R(-120,-30),life:R(0.6,1),max:1,c,g:440,stain:1});
};
G.addStain=function(x,c){
  if(!floorOk(x))return;
  addDecal({k:'stain',x:Math.round(x),w:R(0,2)|0,c,max:R(6,9)});
};
// سهم أو نجمة تنغرز في الأرض أو الجدار
G.stick=function(x,y,ux,uy,kind,wall){
  if(!wall&&!floorOk(x))return;
  addDecal({k:kind,x,y,ux,uy,max:2.6,wall:!!wall});
  G.spark(x,y-1,'#8f8468',3,40);
  G.sfx(kind==='star'?1400:500,0.04,'triangle',0.02,-200);
};
// أثر حرق مكان سقوط كرة النار
G.scorch=function(x){
  if(!floorOk(x))return;
  addDecal({k:'scorch',x:Math.round(x),max:3.5});
  for(let i=0;i<4;i++)G.puff(x+R(-4,4),GY-2,'#3a3530');
};
G.drawDecals=function(){
  for(const d of decals){
    const k=d.t/d.max, a=k<0.7?1:1-(k-0.7)/0.3;
    if(d.k==='stain'){
      G.alpha(0.75*a); r(d.x-d.w-1,GY,d.w*2+3,1,d.c); G.alpha(0.45*a); r(d.x-d.w,GY+1,d.w*2+1,1,d.c);
    }else if(d.k==='scorch'){
      G.alpha(0.6*a); r(d.x-6,GY,12,1,'#140f0b'); r(d.x-4,GY+1,8,1,'#140f0b');
      if(k<0.4){G.alpha(0.5*(1-k/0.4)); r(d.x-2,GY-1,4,1,'#ff8a3a');}
    }else if(d.k==='arrow'){         // السهم: ذيل بريش أحمر ظاهر ورأسه داخل الأرض/الجدار
      G.alpha(a);
      pl(d.x-d.ux*8,d.y-d.uy*8,d.x,d.y,'#b08a55');
      r(d.x-d.ux*8-1,d.y-d.uy*8-1,3,2,'#9b2335');
    }else if(d.k==='star'){          // نصف نجمة ظاهر
      G.alpha(a);
      pl(d.x-3,d.y-2,d.x+3,d.y-2,'#dfe6f5'); pl(d.x,d.y-4,d.x,d.y,'#dfe6f5'); r(d.x,d.y-2,1,1,'#3a3346');
    }
  }
  G.alpha(1);
};
// ظل ناعم تحت اللاعب يصغر ويخفت كلما ارتفع في الهواء
G.drawHeroShadow=function(p){
  if(!p||p.state==='dead'&&p.y>GY+5)return;
  let fy=p.ground?p.y:(G.L?G.landY(p.x,p.y,p.y+300):GY);
  if(fy==null)return;
  const k=Math.max(0.3,1-(fy-p.y)/90), w=Math.max(3,Math.round(9*k));
  G.alpha(0.34*k); r(p.x-w,fy,w*2,2,'#000000');
  G.alpha(0.16*k); r(p.x-w-3,fy,w*2+6,1,'#000000'); r(p.x-w+2,fy-1,w*2-4,1,'#000000');
  G.alpha(1);
};
// غبار الخطوات وصوتها، الانزلاق عند تغيير الاتجاه، وغبار المراوغة
let stepT=0, lastDir=0, wasDodge=false;
G.realTick=function(dt){
  const p=G.P; if(!p||p.state==='dead')return;
  const moving=p.ground&&Math.abs(p.vx)>40;
  const dodge=p.state==='dodge'||p.state==='dash'||p.state==='vault';
  if(moving&&!dodge&&p.state!=='attack'){
    stepT-=dt;
    if(stepT<=0){
      stepT=0.27;
      G.puff(p.x-p.f*4,p.y-1,'#5a5348');
      G.snd('step');                                      // وقع القدم (ملف snd/step.mp3 إن وُجد)
    }
  }else stepT=0.05;
  const dir=Math.sign(p.vx);
  if(p.ground&&dir&&lastDir&&dir!==lastDir&&Math.abs(p.vx)>60){   // انزلاق عند الالتفاف
    for(let i=0;i<4;i++)G.puff(p.x+dir*R(2,6),p.y-1,'#5a5348');
    G.noise(0.06,0.02,1200,300);
  }
  if(dir)lastDir=dir;
  if(dodge&&!wasDodge&&p.ground){                         // غبار عند بداية المراوغة
    for(let i=0;i<7;i++)G.puff(p.x+R(-7,7),p.y-1,'#5a5348');
  }
  wasDodge=dodge;
};

G.drawParts=function(){
  for(const p of parts){
    G.alpha(clamp(p.life/p.max,0,1));
    r(p.x,p.y,p.s||1,p.s||1,p.c);
  }
  G.alpha(1);
};
G.drawFx=function(){
  for(const f of fx){
    if(f.t<0)continue;          // مؤثر مؤجَّل لم يبدأ بعد
    const k=f.t/f.max;
    if(f.k==='ring'){
      G.alpha(1-k);
      G.ringPx(f.x,f.y,2+f.s*k,f.c);
      if(f.s<40)G.ringPx(f.x,f.y,1+f.s*k*0.7,'#ffffff');
    }else if(f.k==='star'){          // نجمة الارتطام
      G.alpha(1-k*0.5);
      const L=f.s*(1-k*0.6);
      pl(f.x-L,f.y,f.x+L,f.y,'#ffffff'); pl(f.x,f.y-L,f.x,f.y+L,'#ffffff');
      const d=L*0.55;
      pl(f.x-d,f.y-d,f.x+d,f.y+d,'#fff2c0'); pl(f.x-d,f.y+d,f.x+d,f.y-d,'#fff2c0');
      r(f.x-2,f.y-2,4,4,'#ffffff');
    }else if(f.k==='cut'){           // خط القطع
      G.alpha(1-k);
      const L=f.s*(0.5+k*0.8), ca=Math.cos(f.a), sa=Math.sin(f.a);
      pl(f.x-ca*L,f.y-sa*L,f.x+ca*L,f.y+sa*L,f.c||'#ffffff',k<0.4?2:1);
    }else if(f.k==='num'){           // رقم الضرر
      G.alpha(k<0.7?1:1-(k-0.7)/0.3);
      G.txt(''+f.v,f.x,f.y-k*14,f.c||(f.big?'#ffb347':'#fff2c0'),f.big);
    }else if(f.k==='arc'){           // هلال الضربة
      G.alpha(1-k);
      const n=Math.max(6,(f.s*0.9)|0);
      for(let i=0;i<=n;i++){
        const a=f.a0+(f.a1-f.a0)*(i/n)*(0.4+k*0.6), w=Math.sin(i/n*Math.PI);
        const rr=f.s+k*4;
        r(f.x+Math.cos(a)*rr*f.d,f.y-Math.sin(a)*rr,2,2,f.c);
        if(w>0.5)r(f.x+Math.cos(a)*(rr-2)*f.d,f.y-Math.sin(a)*(rr-2),1,1,'#ffffff');
      }
    }else if(f.k==='bolt'){          // صاعقة متعرجة
      G.alpha(1-k*0.7);
      let px=f.x, py=f.y;
      for(let i=1;i<=7;i++){
        const u=i/7;
        const nx=f.x+(f.x2-f.x)*u+(i<7?R(-5,5):0), ny=f.y+(f.y2-f.y)*u+(i<7?R(-5,5):0);
        pl(px,py,nx,ny,f.c,2); pl(px,py,nx,ny,'#ffffff');
        px=nx; py=ny;
      }
    }else if(f.k==='spike'){         // شوكة تخرج من الأرض
      const h=Math.round(f.s*Math.sin(Math.min(1,k*1.6)*Math.PI*0.5)*(k>0.7?(1-k)/0.3:1));
      for(let i=0;i<h;i++){
        const w=Math.max(1,Math.round((1-i/h)*4));
        r(f.x-w,GY-i,w*2,1,i%3?f.c:'#ffffff');
      }
    }
  }
  G.alpha(1);
};

})(window.G);
