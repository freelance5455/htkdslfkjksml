/* ================== sprites.js — شخصيات مرسومة من صور (Sprite Sheets) ==================
   الصور في مجلد img. كل صورة شبكة من الإطارات بحجم واحد (cw × ch)، والشخصية تنظر لليمين
   وقدماها عند أسفل الإطار في منتصفه.
   لإضافة شخصية جديدة من صورة: ضع الصورة في img وأضف سطراً هنا باسم الشخصية (id من save.js).
   كل حركة = قائمة إطارات [الصف، العمود]. إن لم تُحمَّل الصورة تُرسم الشخصية بالكود كالسابق.
   hand = مكان خروج المقذوف [أفقي، رأسي] من القدمين (للساحرة والصيّادة والنينجا). */
(function(G){
'use strict';
const S=G.S;
function row(r,a,b){const o=[];for(let i=a;i<=b;i++)o.push([r,i]);return o;}

G.SPRITES={
  // الفارس: 8 صفوف × 8 أعمدة، كل إطار 64×46
  knight:{src:'img/knight.png',cw:64,ch:46,
    anims:{
      idle:row(0,0,5), walk:row(1,0,7),
      atk1:row(2,0,4),                           // الضربة الأولى
      atk2:[[3,0],[3,1],[3,3],[3,2]],            // الضربة الثانية
      fin:row(4,0,5),                            // الخاتمة
      jump:[[5,1]], roll:row(5,3,5),             // القفز والمراوغة
      defend:row(6,0,3), guard:[[6,2]],
      hurt:[[6,4],[6,5]], heal:[[6,6],[6,7]],
      death:row(7,0,7),
      ready:[[0,0]], windup:[[3,0]], special:[[4,4]]
    }},
  // الفارسة: 8 صفوف × 8 أعمدة، كل إطار 64×46 (سيفان)
  lady:{src:'img/lady.png',cw:64,ch:46,
    anims:{
      idle:row(0,0,4), walk:row(1,0,7),
      atk1:row(2,0,4),                           // طعنة بالسيف الأيمن
      atk2:row(3,0,4),                           // ضربة من الأعلى
      fin:row(4,0,5),                            // دوران بالسيفين
      jump:[[5,1],[5,2]],                        // صعود ثم هبوط
      roll:row(5,3,5),                           // المراوغة
      dash:[[6,0],[6,1]],                        // مهارة الاندفاعة
      hurt:[[6,3],[6,4]], heal:[[6,5],[6,6]],
      death:row(7,2,7),
      guard:[[4,0]], ready:[[0,0]], windup:[[4,0]], special:[[6,2]]
    }},
  // حاصد الأرواح: 8 صفوف × 8 أعمدة، كل إطار 80×46 (أعرض بسبب طول المنجل)
  reaper:{src:'img/reaper.png',cw:80,ch:46,
    anims:{
      idle:row(0,0,5), walk:row(1,0,7),
      atk1:row(2,0,5),                           // حصدة أفقية
      atk2:row(3,0,5),                           // حصدة صاعدة
      fin:[[4,0],[4,1],[4,2],[4,4],[4,5],[4,3]], // رفع المنجل ثم ضربة للأرض
      jump:[[5,0],[5,2]],                        // صعود ثم هبوط
      roll:row(5,3,5),                           // المراوغة الشبحية
      cast:[[6,0],[6,1]],                        // مهارة الأرواح
      hurt:[[6,3]], heal:[[6,4],[6,5]],
      death:row(7,0,6),
      guard:[[0,0]], ready:[[0,0]], windup:[[4,0]], special:[[6,2]]
    }},
  // السجّان: 6 صفوف × 9 أعمدة، كل إطار 88×46 (أعرض بسبب طول السلسلة)
  // الرقم الثالث في الإطار = إزاحة أفقية بالبكسل للإطارات التي سلسلتها ممدودة
  warden:{src:'img/warden.png',cw:88,ch:46,
    anims:{
      idle:row(0,0,5), walk:row(1,0,7),
      atk1:[[2,0],[2,2,6],[2,3,14],[2,2,6]],     // جلدة أفقية
      atk2:[[2,4],[2,5],[2,6]],                  // جلدة من الأعلى
      fin:[[3,0],[3,1],[3,2],[3,3]],             // تدوير السلسلة ثم ضرب الأرض
      jump:[[3,5],[3,6]],                        // صعود ثم هبوط
      roll:[[3,7],[3,8]],                        // المراوغة
      cast:[[4,0,22],[4,1]],                     // مهارة السحب
      hurt:[[4,3],[4,4]], heal:[[4,5],[4,6]],
      death:row(5,0,7),
      guard:[[0,0]], ready:[[0,0]], windup:[[3,0]], special:[[4,2]]
    }},
  // البربري: 6 صفوف × 10 أعمدة، كل إطار 64×46
  berserk:{src:'img/berserk.png',cw:64,ch:46,
    anims:{
      idle:row(0,0,5), walk:row(1,6,9),
      atk1:[[2,6],[2,0],[2,3],[2,9]],            // ضربة من الأعلى للأمام
      atk2:[[5,1],[5,2],[2,7],[2,8]],            // ضربة صاعدة
      fin:[[4,3],[3,3],[3,4],[3,4]],             // قفزة ثم ضرب الأرض
      jump:[[3,2],[4,4]],                        // صعود ثم هبوط
      roll:[[3,4]],                              // المراوغة (انحناءة)
      cast:[[2,8],[2,6]],                        // مهارة الهياج
      hurt:[[3,5]], heal:[[3,6],[3,7]],
      death:[[3,4],[5,3],[5,4],[5,5]],
      guard:[[0,0]], ready:[[0,0]], windup:[[2,6]], special:[[2,9]]
    }},
  // حامل المطرقة: 8 صفوف × 8 أعمدة، كل إطار 72×46
  smith:{src:'img/smith.png',cw:72,ch:46,
    anims:{
      idle:row(0,0,5), walk:row(1,0,7),
      atk1:[[2,3],[2,4],[3,2],[3,1]],            // ضربة جانبية
      atk2:[[3,0],[3,2],[3,3],[3,4]],            // ضربة صاعدة
      fin:[[4,0],[4,2],[4,3],[4,4],[4,5],[4,5]], // رفع المطرقة ثم سحق الأرض
      jump:[[5,0],[5,1]],                        // صعود ثم هبوط
      roll:row(5,4,6),                           // الدحرجة
      cast:[[6,0],[6,1]],                        // مهارة دكّ الأرض
      hurt:[[6,4],[6,5]], heal:[[6,6]],
      death:row(7,2,7),
      guard:[[0,0]], ready:[[0,0]], windup:[[4,0]], special:[[6,3]]
    }},
  // النينجا: 8 صفوف × 8 أعمدة، كل إطار 80×52 (أطول قليلاً لأن ذراعيه ترتفعان عند رمي النجوم)
  ninja:{src:'img/ninja.png',cw:80,ch:52,hand:[16,-27],
    anims:{
      idle:[[0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],[1,0],[1,1],[1,2],[1,3]],
      walk:[[1,4],[1,5],[1,6],[1,7],[2,0],[2,1],[2,2],[2,3],[2,4],[2,5]],   // الركض
      atk1:[[3,0],[3,1],[3,2],[3,3]],            // رفع النجمة ثم رميها للأمام
      atk2:[[3,5],[3,6],[3,7],[4,0]],            // طعنة بالكوناي
      fin:[[4,3],[4,1],[4,2],[4,2]],             // ضربة المروحة الحديدية
      jump:[[4,6],[5,0]],                        // صعود ثم هبوط
      flip:[[5,1]],                              // شقلبة القفزة الثانية في الهواء
      roll:[[4,5],[5,1],[4,7]],                  // المراوغة
      dash:[[5,6]],                              // مهارة الوميض: اندفاعة كالظل
      hurt:[[6,1]], heal:[[6,2],[6,3],[6,4]],    // الشرب من القارورة
      death:[[6,5],[6,6],[6,7],[7,0],[7,1],[7,2],[7,3],[7,4]],
      guard:[[4,4]],                             // يحتمي بالمروحة
      ready:[[0,0]], windup:[[5,5]], special:[[6,0]]   // ختم اليدين ثم انفجار النجوم
    }},
  // الساحرة: 5 صفوف × 8 أعمدة، كل إطار 100×54 (أعرض بسبب العصا ونار الخاتمة)
  mage:{src:'img/mage.png',cw:100,ch:54,hand:[30,-26],
    anims:{
      idle:row(0,0,5),
      walk:[[0,6],[0,7],[1,0],[1,1],[1,2],[1,3]],   // الركض
      atk1:row(1,4,7),                           // تمدّ العصا وتطلق كرة النار
      atk2:row(2,0,4),                           // ضربة هلالية من الأعلى
      fin:[[3,6],[3,7],[4,0],[4,1]],             // ترفع العصا ثم تضرب الأرض فتشتعل النار
      jump:[[3,3],[3,2]],                        // صعود ثم هبوط
      roll:[[3,4],[3,5]],                        // المراوغة
      cast:[[2,5],[2,6]],                        // مهارة انفجار اللهب
      hurt:[[2,7]], heal:[[3,0],[3,1]],          // الشرب من القارورة
      death:row(4,2,6),
      guard:[[0,0]], ready:[[0,0]], windup:[[3,6]], special:[[2,6]]
    }},
  // الرمّاح: 4 صفوف × 8 أعمدة، كل إطار 112×58 (عريض وطويل بسبب طول الرمح)
  lancer:{src:'img/lancer.png',cw:112,ch:58,
    anims:{
      idle:row(0,0,3),
      walk:row(0,4,6),                           // الركض والرمح للأمام
      atk1:[[0,7],[1,0],[1,1]],                  // طعنة مستقيمة
      atk2:row(1,2,5),                           // تدوير الرمح وضربة من الأعلى
      fin:[[2,5],[2,6],[2,6]],                   // طعنة تخترق الدروع مع خط الضوء
      jump:[[1,6],[1,7]],                        // صعود ثم هبوط
      roll:[[2,0]],                              // المراوغة (انحناءة سريعة)
      vault:row(2,0,2),                          // مهارة الوثبة: انخفاض ثم وثبة ثم طعنة
      hurt:[[2,3]], heal:[[2,4]],
      death:[[2,3],[2,7],[3,0]],
      guard:[[0,0]], ready:[[0,0]], windup:[[2,5]], special:[[2,6]]
    }},
  // الصيّادة: 4 صفوف × 8 أعمدة، كل إطار 76×50
  ranger:{src:'img/ranger.png',cw:76,ch:50,hand:[16,-26],
    anims:{
      idle:row(0,0,3),                           // وقفة اليد على الخصر
      walk:row(0,4,7),
      atk1:row(1,0,2),                           // تشدّ القوس ثم تطلق
      atk2:[[1,3],[1,4]],                        // رمية سريعة
      fin:row(1,5,7),                            // ثلاثة سهام متوهجة ثم ارتداد
      jump:[[2,1],[2,0]],                        // صعود ثم هبوط
      roll:[[2,1],[2,3]],                        // المراوغة
      backflip:row(2,1,3),                       // مهارة القفزة الخلفية: قفزة، رمية وهي مقلوبة، هبوط على ركبة
      hurt:[[2,6]], heal:[[2,4],[2,5]],
      death:[[2,7],[3,0],[3,1]],
      guard:[[0,0]], ready:[[0,0]], windup:[[1,5]], special:[[1,6]]
    }}
};
for(const id in G.SPRITES){
  const sp=G.SPRITES[id];
  sp.ok=false; sp.img=new Image();
  sp.img.onload=()=>{sp.ok=true;};
  sp.img.src=sp.src;
}

// مكان خروج المقذوف من يد الشخصية أو سلاحها (أو null إن لم يكن لها صورة)
G.spriteHand=function(p){
  const sp=G.SPRITES[p.ch||'knight'];
  return sp&&sp.ok&&sp.hand?sp.hand:null;
};

// ترسم الشخصية من صورتها (عند نقطة الأصل = القدمين). ترجع false إن لم تكن لها صورة جاهزة.
G.drawSpriteHero=function(p){
  const sp=G.SPRITES[p.ch||'knight'];
  if(!sp||!sp.ok)return false;
  const A=sp.anims, t=S.time, k=G.ctx;
  let fr, alpha=1, unspin=false;
  const pick=(a,u)=>a[Math.min(a.length-1,Math.max(0,Math.floor(u*a.length)))];
  const loop=(a,fps)=>a[Math.floor(t*fps)%a.length];
  const st=p.state;
  if(st==='dead')fr=pick(A.death,p===G.P?(1.5-S.deadT)/1.1:1);
  else if(st==='hurt')fr=pick(A.hurt,1-p.t/0.25);
  else if(st==='dash'&&A.dash){fr=loop(A.dash,12);alpha=0.9;}
  else if(st==='dodge'||st==='dash'){fr=A.roll?loop(A.roll,14):A.jump[0];alpha=0.85;}
  else if(st==='cast'&&A.cast)fr=pick(A.cast,1-p.t/0.3);
  else if(st==='special')fr=p.t<0.15?A.windup[0]:A.special[0];
  else if(st==='vault'&&A.vault)fr=pick(A.vault,1-p.t/0.45);     // وثبة الرمّاح
  else if(st==='flip'&&A.backflip){fr=pick(A.backflip,1-p.t/0.4);unspin=true;}   // قفزة الصيّادة مرسومة في الصورة
  else if(st==='heal')fr=pick(A.heal,1-p.t/0.6);
  else if(p.guard>0)fr=A.guard[0];
  else if(st==='attack'){
    const w=G.WEAPONS[p.aw], a=p.fin?A.fin:(p.cs===1?A.atk2:A.atk1);
    fr=pick(a,p.t/w.dur);
  }
  else if(!p.ground&&p.airJ&&A.flip&&p.vy<0)fr=A.flip[0];    // القفزة الثانية
  else if(!p.ground)fr=A.jump[A.jump.length>1&&p.vy>0?1:0];
  else if(Math.abs(p.vx)>30)fr=loop(A.walk,12);
  else fr=loop(A.idle,6);
  const a0=k.globalAlpha;
  k.globalAlpha=a0*alpha;
  k.imageSmoothingEnabled=false;
  // اللعبة تدوّر الشخصية في القفزة الخلفية؛ نلغي الدوران لأن الحركة مرسومة في الصورة
  if(unspin){k.save();k.translate(0,-12);k.rotate((0.4-p.t)/0.4*Math.PI*2);k.translate(0,12);}
  k.drawImage(sp.img,fr[1]*sp.cw,fr[0]*sp.ch,sp.cw,sp.ch,-sp.cw/2+(fr[2]||0),-sp.ch+1,sp.cw,sp.ch);
  if(unspin)k.restore();
  k.globalAlpha=a0;
  return true;
};

/* ================== صور الزعماء ==================
   كل زعيم له صورة إطارات بنفس الطريقة، والحركات مربوطة بحالاته في boss-ai.js:
   idle وقوف · walk مشي · slamTel/slamAct رفع السلاح ثم الضرب · chargeTel/chargeAct تحفّز ثم اندفاع
   castTel/castAct تحضير السحر ثم إطلاقه · leapTel/leapUp/leapDown/land القفزة · backstep قفزة للخلف
   roar زئير · hurt إصابة · stun دوخة · death موت. الحركة الناقصة يُستعمل بدلها أقرب حركة.
   ويمكن إعطاء أي هجمة حركة خاصة باسمها: مثلاً boltsTel/boltsAct لبصق السم.
   الزعيم الذي ليست له صورة يُرسم بالكود كالسابق. */
G.BOSS_SPRITES={
  // 1) حارس الضريح: 5 صفوف × 8 أعمدة، كل إطار 150×100
  warden:{src:'img/boss_warden.png',cw:150,ch:100,
    anims:{
      idle:row(0,0,5),
      walk:[[0,6],[0,7],[1,0],[1,1],[1,2],[1,3]],
      slamTel:[[1,4],[1,5],[1,6]],               // يرفع الهراوة فوق رأسه
      slamAct:[[1,7],[2,0]],                     // يهوي بها على الأرض مع الغبار
      chargeTel:[[2,1],[2,2]],                   // يتحفّز للاندفاع
      chargeAct:[[2,3],[2,4]],                   // يندفع راكضاً
      castTel:[[2,5],[2,6]],                     // النار في يده
      castAct:[[2,7],[3,0]],                     // يضرب الأرض فتخرج أعمدة النار
      roar:[[3,1],[3,2],[3,3]],
      hurt:[[3,4],[3,5]], stun:[[3,6],[3,7]],
      death:row(4,0,5)
    }},
  // 2) الفارس الساقط: 5 صفوف × 8 أعمدة، كل إطار 120×80
  knight:{src:'img/boss_knight.png',cw:120,ch:80,
    anims:{
      idle:row(0,0,4),
      walk:[[0,5],[0,6],[0,7],[1,0],[1,1]],
      slamTel:[[1,3],[1,4]],                     // يرفع السيف فوق كتفه
      slamAct:[[1,5],[1,6]],                     // يضرب من الأعلى للأسفل (مرتين)
      chargeTel:[[2,2],[1,7]],                   // ينحني ويتحفّز
      chargeAct:[[2,0],[2,1]],                   // يندفع والعباءة خلفه
      leapTel:[[2,2],[2,3]],                     // ينخفض ثم يرفع السيف
      leapUp:[[2,4]], leapDown:[[2,5]],          // صعود ثم هبوط والسيف للأسفل
      land:[[2,6]],                              // يغرس السيف في الأرض مع الغبار
      backstep:[[2,7]],                          // قفزة للخلف
      roar:[[3,3],[3,0],[3,1]],
      hurt:[[3,4]], stun:[[3,5],[3,6]],          // يتكئ على سيفه
      death:[[3,7],[4,0],[4,1],[4,2],[4,3]]
    }},
  // 3) ملكة العناكب: 5 صفوف × 8 أعمدة، كل إطار 96×56 (عريضة ومنخفضة)
  spider:{src:'img/boss_spider.png',cw:96,ch:56,
    anims:{
      idle:row(0,0,5),
      walk:[[0,6],[0,7],[1,0],[1,1],[1,2],[1,3]],
      slamTel:[[1,4],[1,5]],                     // ترفع رجليها الأماميتين
      slamAct:[[1,6],[1,7]],                     // تطعن الأرض أمامها
      leapTel:[[2,0]], leapUp:[[2,1]], leapDown:[[2,2]], land:[[2,3]],
      boltsTel:[[2,4]], boltsAct:[[2,5],[2,6]],  // بصق السم
      castTel:[[2,7]], castAct:[[3,0],[3,1]],    // أشواك السم ومطر السم (توهج أخضر)
      roar:[[3,2],[3,3],[3,4],[3,5]],
      hurt:[[3,6]], stun:[[3,7],[4,0]],          // تنهار على بطنها
      death:row(4,1,6)                           // تنقلب على ظهرها
    }},
  // 4) ساحر الصقيع: 5 صفوف × 8 أعمدة، كل إطار 130×76 (يطفو، وأسفل الإطار نهاية الضباب)
  lich:{src:'img/boss_lich.png',cw:130,ch:76,
    anims:{
      idle:row(0,0,5),
      walk:[[0,6],[0,7],[1,0],[1,1]],            // ينزلق في الهواء
      teleportTel:[[1,2],[1,3],[1,4]],           // يتفتت إلى ضباب ويختفي
      teleportAct:[[1,5],[1,6]],                 // يظهر خلفك ثم يطعن بالعصا
      boltsTel:[[1,7]], boltsAct:[[2,0],[2,1]],  // قذائف الجليد
      castTel:[[2,2],[2,3]], castAct:[[2,4]],    // أشواك الجليد
      rainTel:[[2,5]], rainAct:[[2,6]],          // مطر الجليد: العصا نحو السقف
      roar:[[2,7],[3,0],[3,1]],                  // العاصفة الثلجية حوله
      hurt:[[3,2],[3,3]], stun:[[3,4],[3,5],[3,6]],
      death:[[3,7],[4,0],[4,1],[4,2],[4,3]]      // يتشقق وينكسر ويسقط الرداء
    }},
  // 5) غول المصهر: 6 صفوف × 8 أعمدة، كل إطار 130×96 (ضخم)
  golem:{src:'img/boss_golem.png',cw:130,ch:96,
    anims:{
      idle:row(0,0,3),
      walk:row(1,0,5),                           // خطوات ثقيلة
      slamTel:[[0,4],[0,5],[0,6]],               // يرفع القبضتين فوق رأسه
      slamAct:[[0,7],[2,1]],                     // يهوي بهما على الأرض
      leapTel:[[2,2],[2,3]], leapUp:[[2,4]], leapDown:[[2,4]], land:[[2,5]],
      castTel:[[2,6]], castAct:[[2,7],[3,0],[3,1]],   // أعمدة الحمم
      rainTel:[[3,2],[3,3]], rainAct:[[3,4]],    // مطر الحمم: ذراعاه نحو السقف
      burstTel:[[3,5]], burstAct:[[3,6],[3,7]],  // الدفعة الصادمة: يدكّ الأرض بقدمه
      roar:[[4,0],[4,1],[4,2]],                  // يخرج اللهب من فمه
      hurt:[[4,3],[4,4]], stun:[[4,5],[4,6],[4,7]],   // يجثو والحمم تخفت
      death:row(5,0,4)                           // يبرد ويتحول إلى كومة صخور
    }},
  // 6) سيد الدماء: 5 صفوف × 8 أعمدة، كل إطار 124×90 (العباءة تنفرد كأجنحة)
  vampire:{src:'img/boss_vampire.png',cw:124,ch:90,
    anims:{
      idle:row(0,0,4),                           // يداه خلف ظهره
      walk:[[0,5],[0,6],[0,7],[1,0],[1,1],[1,2],[1,3],[1,4]],
      slamTel:[[1,5]], slamAct:[[1,6]],          // ضربة المخالب مع أثر أحمر
      chargeTel:[[1,7]], chargeAct:[[1,7],[2,0]],   // يندفع كالسهم والعباءة خلفه
      teleportTel:[[2,4],[2,3],[2,2]],           // يتحول إلى سرب خفافيش
      teleportAct:[[2,5],[2,6]],                 // يظهر ثم ينقضّ
      boltsTel:[[2,7],[3,0]], boltsAct:[[3,1],[3,2]],   // كرة الدم في كفه ثم يرميها
      roar:[[3,3],[3,4],[3,5]],                  // يفرد العباءة كأجنحة خفاش
      hurt:[[3,6],[3,7]], stun:[[4,0],[4,1],[4,2]],
      death:row(4,3,6)                           // يتفتت إلى رماد وخفافيش
    }},
  // 7) الذئب الأسود: 5 صفوف × 8 أعمدة، كل إطار 124×64 (جسم طويل على أربع)
  wolf:{src:'img/boss_wolf.png',cw:124,ch:64,
    anims:{
      idle:row(0,0,4),                           // يزمجر والبرق يومض على ظهره
      walk:[[0,5],[0,6],[0,7],[1,0],[1,1]],      // ركض الذئاب
      slamTel:[[1,2]], slamAct:[[1,3],[1,4]],    // مخلب ثم عضّة
      chargeTel:[[1,5]], chargeAct:[[1,6],[1,7]],   // ينطلق كالبرق
      leapTel:[[2,0]], leapUp:[[2,1]], leapDown:[[2,2]], land:[[2,2]],
      spinTel:[[2,3]], spinAct:[[2,3],[2,4],[2,5],[2,6]],   // دوّامة البرق
      backstep:[[2,7],[3,0]],
      roar:[[3,1],[3,2],[3,3],[3,4]],            // العواء نحو القمر
      hurt:[[3,5]], stun:[[3,6],[3,7]],
      death:row(4,0,3)
    }},
  // 8) الحاصد: 5 صفوف × 8 أعمدة، كل إطار 124×76 (يطفو، والمنجل طويل)
  reaper:{src:'img/boss_reaper.png',cw:124,ch:76,
    anims:{
      idle:row(0,0,4),                           // المنجل على كتفه والأرواح حوله
      walk:row(0,5,7),                           // ينزلق في الهواء
      slamTel:[[1,0],[1,1]], slamAct:[[1,2]],    // يرفع المنجل ثم يحصد بأثر أخضر
      spinTel:[[1,0]], spinAct:[[1,3]],          // المنجل يدور حوله
      teleportTel:[[1,4],[1,5]],                 // يذوب في دخان أسود
      teleportAct:[[1,6],[1,7]],                 // يخرج من الدخان ويحصد أفقياً
      boltsTel:[[2,0]], boltsAct:[[2,1]],        // يفتح كتابه ثم يشير بإصبعه
      beamTel:[[2,2],[2,4]], beamAct:[[2,3]],    // شعاع الموت: يرفع المنجل المشتعل ثم يغرسه
      roar:row(2,5,7),
      hurt:[[3,0],[3,1]], stun:row(3,2,4),       // يتكئ على المنجل
      death:[[3,5],[3,6],[3,7],[4,0],[4,1]]      // تخرج الأرواح ويسقط الرداء والمنجل
    }},
  // 9) التنين العظمي: 4 صفوف × 8 أعمدة، كل إطار 150×92 (عريض جداً)
  dragon:{src:'img/boss_dragon.png',cw:150,ch:92,
    anims:{
      idle:row(0,0,5),
      walk:[[0,6],[0,7],[1,0],[1,1],[1,2]],
      breathTel:[[1,3],[1,4]], breathAct:[[1,5]],   // النار تتجمع في حلقه ثم يمد رقبته (النار من فمه)
      slamTel:[[1,6]], slamAct:[[1,7]],          // يرفع مخلبه ثم يضرب الأرض
      leapTel:[[2,0]], leapUp:[[2,1]], leapDown:[[2,2]], land:[[2,2]],
      rainTel:[[2,0]], rainAct:[[2,3]],          // يفرد جناحيه ويرفع رأسه للسماء
      boltsTel:[[2,5],[2,6]], boltsAct:[[2,4]],  // كرة النار في فمه ثم يقذفها
      burstTel:[[3,1]], burstAct:[[2,7]],        // يضرب الأرض بذيله
      roar:[[3,1],[3,0],[3,1]],
      hurt:[[3,2]], stun:[[3,3]],
      death:row(3,4,7)                           // تنطفئ النار وتتفكك العظام
    }},
  // 10) عين الهاوية: 6 صفوف × 8 أعمدة، كل إطار 110×68 (تطفو، وأسفل الإطار نهاية المجسات)
  eye:{src:'img/boss_eye.png',cw:110,ch:68,
    anims:{
      idle:row(0,0,5),
      walk:[[0,6],[0,7],[1,0],[1,1]],            // تنزلق والمجسات للخلف
      beamTel:[[1,2],[1,3]], beamAct:[[1,4]],    // تضيق العين ثم تتوهج بالشعاع
      boltsTel:[[1,5],[1,6]], boltsAct:[[1,7]],  // تفتح المجسات كالمروحة ثم تندفع
      rainTel:[[2,0]], rainAct:[[2,1]],          // المجسات نحو السقف
      teleportTel:[[2,2],[2,3],[2,4]],           // تُغمض وتتلاشى في دوامة
      teleportAct:[[2,5],[3,1]],                 // تظهر ثم تضرب بمجساتها
      castTel:[[3,2],[3,3]], castAct:[[3,4],[3,5]],   // تغرس المجسات في الأرض (الأعمدة)
      roar:[[3,6],[3,7],[4,0]],                  // تنفتح كفم مرعب
      hurt:[[4,5],[4,1]], stun:[[4,2],[4,3]],    // البؤبؤ يدور كالدوامة
      death:row(5,1,5)                           // تتشقق ثم تذوب في بركة
    }},
  // 11) ملك الرماد: 7 صفوف × 8 أعمدة، كل إطار 172×100 (الزعيم الأخير، 11 هجمة)
  king:{src:'img/boss_king.png',cw:172,ch:100,
    anims:{
      idle:row(0,0,5),
      walk:[[0,6],[0,7],[1,0]],
      slamTel:[[1,1]], slamAct:[[1,2],[1,3]],    // ضربة من الأعلى ثم أفقية
      chargeTel:[[1,4]], chargeAct:[[1,5],[1,6]],   // يندفع والعباءة مشتعلة
      leapTel:[[1,7]], leapUp:[[2,0]], leapDown:[[2,0]], land:[[2,1]],
      castTel:[[2,2],[2,3]], castAct:[[2,4]],    // سحر النار (الأعمدة)
      rainTel:[[2,2]], rainAct:[[2,3]],          // كرة النار في يده المرفوعة
      teleportTel:[[2,7],[2,6],[2,5]],           // يتفتت إلى رماد وجمر
      teleportAct:[[3,0],[3,2]],                 // يظهر ثم يضرب أفقياً
      spinTel:[[3,5]], spinAct:[[3,3],[3,4]],    // دوّامة السيف المشتعل
      breathTel:[[3,6],[3,7]], breathAct:[[3,7]],   // النار في صدره وفمه
      boltsTel:[[3,7]], boltsAct:[[4,0]],        // يقذف كرة النار من فمه
      beamTel:[[4,2],[4,3]], beamAct:[[4,1]],    // يغرس السيف والتاج يتوهج
      summonTel:[[4,2]], summonAct:[[4,1]],
      roar:[[4,4],[4,5],[4,6]],
      hurt:[[4,7],[5,0]], stun:row(5,1,3),       // يجثو ويتكئ على سيفه
      death:[[5,4],[5,5],[5,6],[5,7],[6,0]]      // يتحول إلى رماد ويبقى التاج والسيف
    }}
};
// نسخة بيضاء من الصورة لوميض الإصابة، وحمراء لغضب المرحلة الثانية
function tinted(img,c){
  const cv=document.createElement('canvas'); cv.width=img.width; cv.height=img.height;
  const x=cv.getContext('2d'); x.drawImage(img,0,0);
  x.globalCompositeOperation='source-in'; x.fillStyle=c; x.fillRect(0,0,cv.width,cv.height);
  return cv;
}
for(const id in G.BOSS_SPRITES){
  const sp=G.BOSS_SPRITES[id];
  sp.ok=false; sp.img=new Image();
  sp.img.onload=()=>{try{sp.white=tinted(sp.img,'#ffffff');sp.red=tinted(sp.img,'#ff2a14');}catch(e){} sp.ok=true;};
  sp.img.src=sp.src;
}
// ترسم الزعيم من صورته (الأصل عند قدميه، متجه لليمين). ترجع false إن لم تكن له صورة.
G.drawSpriteBoss=function(b,flash){
  const sp=G.BOSS_SPRITES[b.def.id];
  if(!sp||!sp.ok)return false;
  const A0=sp.anims, t=S.time, k=G.ctx;
  // إن لم تكن للزعيم حركة معيّنة يُستعمل أقرب بديل لها
  const ALT={slamTel:'idle',slamAct:'idle',chargeTel:'slamTel',chargeAct:'walk',castTel:'slamTel',castAct:'slamAct',
             leapTel:'chargeTel',leapUp:'chargeAct',leapDown:'chargeAct',land:'slamAct',backstep:'walk',stun:'hurt'};
  const A=new Proxy(A0,{get:(o,n)=>o[n]||(ALT[n]&&(o[ALT[n]]||o[ALT[ALT[n]]]))||o.idle});
  const pick=(a,u)=>a[Math.min(a.length-1,Math.max(0,Math.floor(u*a.length)))];
  const loop=(a,fps)=>a[Math.floor(t*fps)%a.length];
  // متى بدأت الحالة الحالية؟ (لمعرفة تقدّم الحركة)
  const key=b.state+'|'+(b.sub||'')+'|'+(b.mv?b.mv.m:'');
  if(b._key!==key){b._key=key;b._t0=Math.max(b.t,0.001);b._ts=t;}
  const e=t-b._ts, u=Math.min(1,Math.max(0,1-b.t/b._t0));
  // هل يمشي؟
  if(b._lx===undefined)b._lx=b.x;
  if(Math.abs(b.x-b._lx)>0.05)b._mvT=t;
  b._lx=b.x;
  const walking=b._mvT!==undefined&&t-b._mvT<0.12;
  const st=b.state, mv=b.mv?b.mv.m:'', act=b.sub==='act';
  let fr;
  if(st==='dead')fr=pick(A.death,(2.6-b.t)/1.6);
  else if(st==='roar')fr=e<0.15?A.roar[0]:A.roar[1+(Math.floor(t*8)%(A.roar.length-1))];
  else if(st==='stun')fr=loop(A.stun,4);
  else if(st==='move'){
    if(mv==='teleport'&&A0.teleportAct)fr=act?A0.teleportAct[b.cnt?A0.teleportAct.length-1:0]:pick(A0.teleportTel||A0.teleportAct,u);
    else if(mv==='spin'&&A0.spinAct)fr=act?loop(A0.spinAct,14):pick(A0.spinTel||A0.spinAct,u);   // الدوّامة تدور طوال مدتها
    else if(mv!=='slam'&&mv!=='charge'&&A0[mv+'Act'])fr=act?pick(A0[mv+'Act'],e/0.25):pick(A0[mv+'Tel']||A0[mv+'Act'],u);   // حركة خاصة بهذه الهجمة
    else if(mv==='slam')fr=act?pick(A.slamAct,e/0.15):pick(A.slamTel,u);
    else if(mv==='charge')fr=act?loop(A.chargeAct,10):pick(A.chargeTel,u);
    else if(mv==='pillars'||mv==='bolts'||mv==='rain'||mv==='summon')fr=act?pick(A.castAct,e/0.25):pick(A.castTel,u);
    else if(mv==='leap')fr=act?((b.lt||0)<0.5?A.leapUp[0]:A.leapDown[0]):pick(A.leapTel,u);
    else if(mv==='burst')fr=act?A.castAct[A.castAct.length-1]:A.roar[0];
    else if(mv==='backstep')fr=A0.backstep?A.backstep[0]:A.walk[1];
    else fr=act?A.slamAct[0]:A.idle[0];
  }
  else if(st==='recover'&&b.mv&&b.mv.m==='slam'&&e<0.45)fr=A.slamAct[A.slamAct.length-1];   // يبقى منحنياً لحظة بعد الضربة
  else if(st==='recover'&&b.mv&&b.mv.m==='leap'&&e<0.5)fr=A.land[0];                        // بعد هبوط القفزة
  else if(b.flash>0&&(st==='idle'||st==='recover'))fr=A.hurt[0];
  else if(walking)fr=loop(A.walk,7);
  else fr=loop(A.idle,5);
  // الزعيم الطافي يهبط إلى الأرض عند موته
  const sink=st==='dead'&&b.def.hov?b.def.hov*Math.min(1,Math.max(0,(2.6-b.t)/1.6)):0;
  const sx=fr[1]*sp.cw, sy=fr[0]*sp.ch, dx=-sp.cw/2, dy=-sp.ch+1+sink;
  k.imageSmoothingEnabled=false;
  k.drawImage(sp.img,sx,sy,sp.cw,sp.ch,dx,dy,sp.cw,sp.ch);
  const a0=k.globalAlpha;
  if(b.phase>=2&&st!=='dead'&&sp.red){          // غضب المرحلة الثانية: نبض أحمر خفيف
    k.globalAlpha=a0*(0.12+0.08*Math.sin(t*7));
    k.drawImage(sp.red,sx,sy,sp.cw,sp.ch,dx,dy,sp.cw,sp.ch);
  }
  if(flash&&sp.white){                          // وميض أبيض عند الإصابة
    k.globalAlpha=a0*0.8;
    k.drawImage(sp.white,sx,sy,sp.cw,sp.ch,dx,dy,sp.cw,sp.ch);
  }
  k.globalAlpha=a0;
  return true;
};


/* ================== صور الوحوش ==================
   كل وحش صورة إطارات. النصف العلوي للوحش البنفسجي، والنصف السفلي (race = عدد صفوفه) لنسخة العفريت الناري.
   الحركات: idle وقوف · walk مشي · tel تحضير الضربة (تحذير) · act الضربة · hurt إصابة · death موت
   · block صدّ (للوحوش ذات الدرع).
   الوحش الذي ليست له صورة يُرسم بالكود كالسابق. */
G.FOE_SPRITES={
  // 1) السيّاف: 3 صفوف × 8 أعمدة لكل شكل، كل إطار 60×38
  sword:{src:'img/foe_sword.png',cw:60,ch:38,race:3,
    anims:{
      idle:row(0,0,2),
      walk:[[0,6],[0,7],[1,0],[1,1],[1,2],[1,3]],
      tel:[[0,4],[0,5]],                         // يرفع السيف فوق كتفه
      act:[[1,4],[1,5],[1,6]],                   // يضرب من الأعلى للأسفل
      hurt:[[1,7],[2,0]],
      death:row(2,1,3)
    }},
  // 2) المدرّع: 3 صفوف × 8 أعمدة لكل شكل (النسخة النارية نحاسية)، كل إطار 60×38
  armor:{src:'img/foe_armor.png',cw:60,ch:38,race:3,
    anims:{
      idle:row(0,0,3),                           // خلف درعه
      walk:[[0,4],[0,5],[0,6],[0,7],[1,0],[1,1]],
      tel:[[1,2],[1,3]],                         // يرفع المطرقة فوق رأسه
      act:row(1,4,6),                            // يهوي بها على الأرض
      block:[[1,7]],                             // يصدّ ضربتك بالدرع
      hurt:[[2,0],[2,1]],
      death:row(2,2,6)                           // يسقط الدرع ثم ينهار
    }},
  // 3) الرامي: 3 صفوف × 8 أعمدة لكل شكل، كل إطار 60×38 · hand = مكان خروج السهم من القوس
  archer:{src:'img/foe_archer.png',cw:60,ch:38,race:3,hand:[16,-21],
    anims:{
      idle:row(0,0,3),
      walk:[[0,4],[0,5]],
      tel:[[0,7],[1,0],[1,1]],                   // يسحب السهم ثم يشد الوتر
      act:[[1,2],[1,3]],                         // يطلق السهم
      hurt:[[1,4],[1,5]],
      death:[[1,6],[1,7],[2,0]]                  // يسقط على ظهره
    }},
  // 4) الساحر: 3 صفوف × 8 أعمدة لكل شكل، كل إطار 60×42 · hand = مكان خروج الكرة السحرية من كفه
  mage:{src:'img/foe_mage.png',cw:60,ch:42,race:3,hand:[12,-22],
    anims:{
      idle:[[0,1],[0,2],[0,3]],                  // متكئ على عصا البلورة
      walk:row(0,4,7),
      tel:[[1,1],[1,2]],                         // السحر يتجمع في كفه
      act:[[1,3],[1,4]],                         // يقذف الكرة
      vanish:[[1,5],[1,6],[1,7]],                // يتلاشى في دخان (يُعرض معكوساً حين يظهر)
      hurt:[[2,0],[2,1]],
      death:row(2,2,6)                           // يسقط والعصا بجانبه
    }},
  // 5) الهيكل العظمي (الفصل 1): 3 صفوف × 8 أعمدة، كل إطار 60×40، شكل واحد
  skeleton:{src:'img/foe_skeleton.png',cw:60,ch:40,
    anims:{
      idle:row(0,0,3),
      walk:[[1,0],[1,1],[1,2],[1,3],[1,4],[0,4],[0,5]],
      tel:[[1,5],[0,6]],                         // يرفع السيف
      act:[[1,6],[0,7]],                         // يضرب
      hurt:[[1,7],[2,0]],
      collapse:[[2,4],[2,1]],                    // تنهار عظامه كومة
      rise:[[2,1],[2,2],[2,3]],                  // تتجمع العظام وينهض
      death:row(2,4,6)
    }},
  // 6) السيف المسكون (الفصل 2): صفان × 8 أعمدة، كل إطار 44×20، يطفو
  blade:{src:'img/foe_blade.png',cw:44,ch:20,
    anims:{
      idle:row(0,0,3),
      walk:row(0,4,7),                           // يميل وينزلق
      tel:[[1,0],[1,1]],                         // يرجع للخلف والعين تتوهج
      dash:[[1,2],[1,3]],                        // يندفع أفقياً كالسهم
      hurt:[[1,4],[1,5]],
      death:[[1,5]],                             // يهوي إلى الأرض ويختفي
      fall:true
    }},
  // 7) العنكبوت الصغير (الفصل 3): 3 صفوف × 8 أعمدة، كل إطار 26×16 (صغير جداً)
  spiderling:{src:'img/foe_spider.png',cw:26,ch:16,
    anims:{
      idle:row(0,0,3),
      walk:[[0,4],[0,5],[0,6],[0,7],[1,0],[1,1]],
      tel:[[1,2],[1,3]],                         // ينخفض ويفتح فكيه
      leap:[[1,4],[1,5],[1,6]],                  // يقفز ثم يهبط
      hurt:[[1,7],[2,0]],
      death:row(2,1,3)                           // ينقلب على ظهره
    }},
  // 8) روح الجليد (الفصل 4): 3 صفوف × 8 أعمدة، كل إطار 26×18، تطفو
  wisp:{src:'img/foe_wisp.png',cw:26,ch:18,
    anims:{
      idle:row(0,0,3),
      walk:row(0,4,7),
      tel:[[1,0],[1,1]],                         // كرة الجليد بين يديها
      act:[[1,2],[1,3]],                         // تدفعها للأمام
      hurt:[[1,4],[1,5]],
      death:[[1,6],[1,7],[2,0],[2,1]]            // تتشقق وتنكسر
    }},
  // 9) عفريت الحمم (الفصل 5): 3 صفوف × 8 أعمدة، كل إطار 40×22
  imp:{src:'img/foe_imp.png',cw:40,ch:22,
    anims:{
      idle:row(0,0,3),                           // يقفز في مكانه
      walk:[[0,4],[0,5],[0,6],[0,7],[1,0],[1,1],[1,2]],
      tel:[[1,3],[1,4]],                         // يرفع قبضتيه والحمم تتوهج
      act:[[1,5],[1,6]],
      hurt:[[1,7],[2,0]],
      death:row(2,1,4)                           // ينتفخ ثم ينفجر
    }},
  // 10) خفاش الدم (الفصل 6): 3 صفوف × 8 أعمدة، كل إطار 34×22، يطير
  bat:{src:'img/foe_bat.png',cw:34,ch:22,
    anims:{
      idle:row(0,0,3),                           // يرفرف في مكانه
      walk:row(0,4,7),
      tel:[[1,0],[1,1]],                         // يضم جناحيه ويفتح أنيابه
      dive:[[1,2],[1,3]],                        // ينقضّ
      hurt:[[1,4],[1,5]],
      death:[[1,6],[1,7],[2,0]],                 // يرتخي ويسقط على الأرض
      fall:'drop'
    }},
  // 11) الذئب (الفصل 7): صفان × 8 أعمدة، كل إطار 46×24، على أربع
  wolf:{src:'img/foe_wolf.png',cw:46,ch:24,
    anims:{
      idle:row(0,0,2),                           // يزمجر والشرارة على ظهره
      walk:row(0,3,7),
      tel:[[1,0]],                               // ينخفض ويتحفّز
      dash:[[1,1],[1,2]],                        // ينطلق مع خط البرق
      hurt:[[1,3],[1,4]],
      death:row(1,5,7)                           // يتعثر ويسقط على جنبه
    }},
  // 12) الشبح (الفصل 8): صفان × 8 أعمدة، كل إطار 40×24، يطفو (اللعبة تضيف شفافيته)
  ghost:{src:'img/foe_ghost.png',cw:40,ch:24,
    anims:{
      idle:row(0,0,3),
      walk:[[0,4],[0,5],[0,6]],                  // ينزلق والذيل خلفه
      tel:[[1,0],[1,1]],                         // يرفع ذراعيه ويصرخ
      dive:[[0,7],[1,2]],                        // ينقضّ بمخالبه
      hurt:[[1,3],[1,4]],
      death:[[1,5],[1,6]]                        // يصرخ ثم يتلاشى
    }},
  // 13) التنين الصغير (الفصل 9): 3 صفوف × 8 أعمدة، كل إطار 40×20، على أربع
  whelp:{src:'img/foe_whelp.png',cw:40,ch:20,
    anims:{
      idle:row(0,0,3),
      walk:[[0,4],[0,5],[0,6],[0,7],[1,0],[1,1]],
      tel:[[1,2],[1,3]],                         // النار تتجمع في صدره
      breath:[[1,4],[1,5]],                      // يمد رقبته وينفث (النار ترسمها اللعبة)
      hurt:[[1,6],[1,7]],
      death:row(2,0,4)                           // تنطفئ النار وتتفكك العظام
    }},
  // 14) العين الطافية (الفصل 10): 3 صفوف × 8 أعمدة، كل إطار 24×18، تطفو
  watcher:{src:'img/foe_watcher.png',cw:24,ch:18,
    anims:{
      idle:row(0,0,3),                           // ترفرف وترمش
      walk:row(0,4,7),
      tel:[[1,0],[1,1]],                         // تضيق والشرارة أمام البؤبؤ
      act:[[1,2],[1,3]],                         // تتسع وترمي
      hurt:[[1,4],[1,5]],
      death:[[1,6],[1,7],[2,0],[2,1]],           // تتشقق ثم تسقط وتذوب
      fall:'drop'
    }},
  // 15) الحارس الملكي (الفصل 11): 3 صفوف × 8 أعمدة، كل إطار 72×36، بدرع ورمح طويل
  guard:{src:'img/foe_guard.png',cw:72,ch:36,
    anims:{
      idle:row(0,0,3),                           // الرمح منتصب بجانبه
      walk:[[0,4],[0,5],[0,6],[0,7],[1,0]],
      tel:[[1,1],[1,2]],                         // يرفع الرمح فوق رأسه
      act:[[1,3],[1,4]],                         // يطعن بالرمح الطويل
      block:[[1,5]],                             // يصدّ بالدرع
      hurt:[[1,6],[1,7]],
      death:row(2,0,2)                           // يجثو ثم يتحول إلى رماد
    }}
};
for(const id in G.FOE_SPRITES){
  const sp=G.FOE_SPRITES[id];
  sp.ok=false; sp.img=new Image();
  sp.img.onload=()=>{try{sp.white=tinted(sp.img,'#ffffff');}catch(e){} sp.ok=true;};
  sp.img.src=sp.src;
}
// مكان خروج مقذوف الوحش من سلاحه (أو null)
G.foeHand=function(e){
  const sp=G.FOE_SPRITES[e.type];
  return sp&&sp.ok&&sp.hand?sp.hand:null;
};
// ترسم الوحش من صورته (الأصل عند قدميه، متجه لليمين). ترجع false إن لم تكن له صورة.
G.drawSpriteFoe=function(e,flash){
  const sp=G.FOE_SPRITES[e.type];
  if(!sp||!sp.ok)return false;
  const A=sp.anims, t=S.time, k=G.ctx;
  const pick=(a,u)=>a[Math.min(a.length-1,Math.max(0,Math.floor(u*a.length)))];
  const loop=(a,fps)=>a[Math.floor((t+e.minX*0.01)*fps)%a.length];
  if(e._st!==e.state){e._st=e.state;e._t0=Math.max(e.t||0,0.001);}
  const u=Math.min(1,Math.max(0,1-(e.t||0)/e._t0));
  let fr;
  if(e.state==='bones'&&A.collapse){                  // كومة العظام ثم النهوض
    fr=e.t>0.55?pick(A.collapse,(2.4-e.t)/0.35):pick(A.rise,1-e.t/0.55);
  }
  else if(e.state==='dead')fr=pick(A.death,u*1.8);
  else if(e.state==='hurt'||e.stun>0)fr=e.stun>0?A.hurt[A.hurt.length-1]:pick(A.hurt,u);
  else if(e.state==='tel')fr=pick(A.tel,u);
  else if(e.state==='dash'&&A.dash)fr=loop(A.dash,12);
  else if(e.state==='leap'&&A.leap)fr=pick(A.leap,e.lt||0);
  else if(e.state==='dive'&&A.dive)fr=loop(A.dive,10);
  else if(e.state==='breath'&&A.breath)fr=loop(A.breath,8);
  else if(e.state==='act')fr=pick(A.act,u);
  else if(e.blockT>0&&A.block)fr=A.block[0];      // صدّ الضربة بالدرع
  else if(e.vanT>0&&A.vanish)fr=pick(A.vanish,e.vanT/0.4);   // يتكوّن من الدخان بعد انتقاله
  else if(e.mv)fr=loop(A.walk,10);
  else fr=loop(A.idle,5);
  const ro=(e.race==='ifrit'&&sp.race)?sp.race:0;
  // الوحش الطائر الذي ليس له رسم موت يهوي إلى الأرض مائلاً
  let dy0=0, rot=0;
  if(e.state==='dead'&&A.fall){dy0=e.def.hov*Math.min(1,u*2); rot=A.fall==='drop'?0:Math.min(1,u*2)*0.6;}
  const sx=fr[1]*sp.cw, sy=(fr[0]+ro)*sp.ch, dx=-sp.cw/2, dy=-sp.ch+1+dy0;
  if(rot){k.save();k.translate(0,dy0-sp.ch/2);k.rotate(rot);k.translate(0,-(dy0-sp.ch/2));}
  k.imageSmoothingEnabled=false;
  k.drawImage(sp.img,sx,sy,sp.cw,sp.ch,dx,dy,sp.cw,sp.ch);
  if(flash&&sp.white){const a0=k.globalAlpha;k.globalAlpha=a0*0.8;k.drawImage(sp.white,sx,sy,sp.cw,sp.ch,dx,dy,sp.cw,sp.ch);k.globalAlpha=a0;}
  if(rot)k.restore();
  return true;
};

})(window.G);
