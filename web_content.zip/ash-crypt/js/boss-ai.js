/* ================== boss-ai.js — ذكاء الزعماء وهجماتهم ==================
   كل هجمة لها: tel=مدة التحذير · start=لحظة التنفيذ · act=ما يحدث أثناءها · rec=مدة الاستراحة بعدها */
(function(G){
'use strict';
const W=G.W, GY=G.GY, R=G.R, clamp=G.clamp, r=G.r, S=G.S;
const flames=G.flames, waves=G.waves, eshots=G.eshots, drops=G.drops;

G.makeBoss=function(i){
  const d=G.BOSSES[i];
  const hp=Math.round(d.hp*(G.CFG.bossHp||1)*(1+i*(G.CFG.bossHpGrow||0)));
  return {def:d,idx:i,x:245,y:GY,f:-1,hp:hp,max:hp,lag:hp,state:'intro',t:1.2,sub:'',mv:null,last:null,cnt:0,
          flash:0,phase:1,arm:d.armIdle||-1.2,rt:0,al:1,roar:false,tel:false,spinA:0,lt:0,sx:0,tx:0,
          hits:0,hitT:0,evCd:2,farT:0,punish:false,iq:Math.min(0.9,0.3+i*0.06)};     // iq = ذكاء الزعيم (يزيد مع كل فصل)
};
// صندوق جسم الزعيم (أعلى وأسفل)
G.bossBox=function(t){
  const b=t||G.B, bot=b.y-(b.def.hov||0);
  return {top:bot-b.def.h,bot:bot};
};
G.bossOpen=function(t){
  const b=t||G.B;
  return !!b&&b.state!=='dead'&&b.state!=='intro'&&b.state!=='roar'&&b.al>0.5;
};
function go(s,t){const b=G.B;b.state=s;b.t=t;b.sub='';}
function face(){const b=G.B;b.f=G.P.x>=b.x?1:-1;}
function lim(b){return b.def.hw+19;}
function el(b){return b.def.elem;}
function col(b,i){return G.ELEM[b.def.elem][i==null?2:i];}

function startRoar(d){
  const b=G.B;
  go('roar',d); b.rt=0; b.y=GY; b.al=1; b.mv=null;
  G.roar(d,b.def.id); S.shake=7; G.buzz(Math.round(d*450));
  G.$('bossName').style.display='block';
}
// شلّ حركة الزعيم (ضربة الزنجير الخاصة)
G.stunBoss=function(d){
  const b=G.B;
  if(b.state==='dead'||b.state==='intro'||b.state==='roar')return;
  go('stun',d); b.y=GY; b.al=1; b.mv=null;
  G.snd('stun');
};
G.killBoss=function(){
  const b=G.B, box=G.bossBox(), cy=(box.top+box.bot)/2;
  go('dead',2.6); b.mv=null; b.al=1; b.dot=null;
  G.clearHazards();
  for(const e of G.enemies)if(e.state!=='dead'){e.noLoot=true;e.revived=true;G.killEnemy(e);}     // حرّاسه يسقطون معه
  S.shake=9; S.freeze=0.2; S.flash=0.5; S.slow=0.9;
  G.snd('bossdie'); G.buzz(200);
  G.ring(b.x,cy,110,col(b),0.7); G.ring(b.x,cy,60,'#ffffff',0.5);
  for(let i=0;i<40;i++)G.spark(b.x+R(-10,10),R(box.top,box.bot),col(b),1,150);
  G.debris(b.x,cy,col(b,1),10);
};

/* ================== مكتبة الهجمات ================== */
const M={
  // ضربة أرضية أمام الزعيم
  slam:{tel:0.6,aT:2.0,aA:-1.1,rec:0.85,snd:'tel',
    start(b,m){
      b.t=0.2;
      const reach=m.reach||48, ix=b.x+b.f*reach*0.65;
      S.shake=Math.max(S.shake,6); G.snd('slam');
      for(let i=0;i<14;i++)G.puff(ix+R(-16,16),GY-1,'#5a564c');
      G.spark(ix,GY-2,col(b),10,110); G.ring(ix,GY-2,30,col(b));
      G.debris(ix,GY-2,'#5a564c',4);
      G.fxAdd({k:'arc',x:b.x+b.f*8,y:GY-reach*0.5,s:reach*0.55,a0:1.5,a1:-1.2,d:b.f,c:col(b),max:0.2});
      if(m.waves===true||(m.waves!==false&&b.phase>=2)){
        waves.push({x:ix,vx:130,life:2.2,el:el(b)}); waves.push({x:ix,vx:-130,life:2.2,el:el(b)});
      }
    },
    act(b,m,dt){
      const reach=m.reach||48, P=G.P;
      const lo=Math.min(b.x+b.f*6,b.x+b.f*reach), hi=Math.max(b.x+b.f*6,b.x+b.f*reach);
      if(P.x>lo-4&&P.x<hi+4&&P.y>GY-34)G.bossHit(25,b.x);
      b.t-=dt;
      if(b.t<=0){
        if(m.twice&&b.cnt<1){b.cnt++;b.sub='tel';b.t=0.34;face();G.snd('tel');return false;}
        return true;
      }
    }},
  // اندفاع عبر الساحة (تفاداه بالمراوغة أو القفز فوق الزعماء القصار)
  charge:{tel:0.55,aT:0.4,aA:-0.3,rec:0.9,snd:'tel',
    start(b){b.t=0.95;G.snd('charge');},
    act(b,m,dt){
      const P=G.P, box=G.bossBox();
      b.x+=b.f*(m.sp||240)*dt;
      if(Math.random()<0.8)G.puff(b.x-b.f*8,GY-R(0,b.def.h*0.7),'#3c3447');
      if(Math.random()<0.5)G.spark(b.x-b.f*6,GY-1,col(b),1,60);
      if(Math.abs(P.x-b.x)<b.def.hw+4&&P.y>box.top+6)G.bossHit(20,b.x-b.f*12);
      b.t-=dt;
      if(b.t<=0||b.x<=lim(b)||b.x>=W-lim(b)){
        if(m.twice&&b.cnt<1){b.cnt++;b.x=clamp(b.x,lim(b),W-lim(b));face();b.sub='tel';b.t=0.32;G.snd('tel');return false;}
        return true;
      }
    }},
  // أعمدة تخرج من الأرض تحت اللاعب
  pillars:{tel:0.7,aT:1.5,aA:1.5,rec:0.7,snd:'cast',
    start(b,m){
      const n=(m.cnt||3)+(b.phase-1)*2, P=G.P;
      for(let i=0;i<n;i++){
        flames.push({x:clamp(pred(b,0.5+i*0.1)+(i-(n-1)/2)*34+R(-6,6),14,W-14),warn:0.6+i*0.16,act:0.35,on:false,el:el(b)});
      }
      G.snd('cast');
    },
    act(){return true;}},
  // كرات طاقة نحو اللاعب
  bolts:{tel:0.5,aT:1.6,aA:0.2,rec:0.7,snd:'cast',
    start(b){b.t=0;},
    act(b,m,dt){
      b.t-=dt;
      if(b.t<=0){
        const P=G.P, box=G.bossBox(), n=m.cnt||3, sp=m.sp||150;
        const mo=b.def.mouth, ox=b.x+b.f*(mo?mo[0]:b.def.hw*0.6), oy=mo?b.y+mo[1]:box.top+b.def.h*0.35;
        const aim=Math.atan2((P.y-12)-oy,pred(b,Math.abs(P.x-ox)/sp)-ox);     // يصوّب حيث ستكون
        for(let i=0;i<n;i++){
          const a=aim+(n>1?(i-(n-1)/2)*(m.spread||0.6)/(n-1):0);
          eshots.push({x:ox,y:oy,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,hom:m.hom||0,sp:sp,life:m.hom?3.2:3,
                       el:el(b),d:m.big?20:12,big:!!m.big});
        }
        G.snd('bolt'); G.ring(ox,oy,12,col(b),0.2);
        b.cnt++; b.t=0.32;
        if(b.cnt>=(m.burst||1)+(b.phase>1?1:0))return true;
      }
    }},
  // قفزة تهبط فوق اللاعب
  leap:{tel:0.45,aT:0.6,aA:2.0,rec:0.8,snd:'tel',
    start(b){
      b.sx=b.x; b.tx=clamp(pred(b,0.45),lim(b),W-lim(b)); b.lt=0;
      G.snd('leap'); for(let i=0;i<8;i++)G.puff(b.x+R(-12,12),GY-1,'#5a564c');
    },
    act(b,m,dt){
      b.lt+=dt/0.62;
      const u=Math.min(1,b.lt), P=G.P;
      b.x=b.sx+(b.tx-b.sx)*u; b.y=GY-Math.sin(Math.PI*u)*(m.hgt||70);
      if(u>=1){
        b.y=GY; S.shake=Math.max(S.shake,7); G.snd('slam'); G.buzz(40);
        for(let i=0;i<16;i++)G.puff(b.x+R(-22,22),GY-1,'#5a564c');
        G.ring(b.x,GY-2,36,col(b),0.35); G.debris(b.x,GY-2,'#5a564c',6);
        if(Math.abs(P.x-b.x)<b.def.hw+16&&P.y>GY-12)G.bossHit(24,b.x);
        if(m.waves||b.phase>=2){waves.push({x:b.x,vx:140,life:2.2,el:el(b)});waves.push({x:b.x,vx:-140,life:2.2,el:el(b)});}
        return true;
      }
    }},
  // مطر من المقذوفات
  rain:{tel:0.6,aT:2.4,aA:2.4,rec:0.8,snd:'cast',
    start(b,m){
      const n=(m.cnt||5)+(b.phase-1)*2, P=G.P;
      for(let i=0;i<n;i++){
        drops.push({x:i%2?clamp(pred(b,0.5+i*0.17)+R(-30,30),10,W-10):R(14,W-14),y:-8,warn:0.5+i*0.17,el:el(b),d:14});
      }
      G.snd('cast'); S.shake=Math.max(S.shake,3);
    },
    act(){return true;}},
  // يختفي ويظهر خلف اللاعب ثم يطعن
  teleport:{tel:0.4,aT:1.8,aA:b=>b.cnt?-1.0:2.2,rec:0.6,snd:'vanish',
    telUpd(b){
      b.al=clamp(b.t/0.3,0,1);
      if(Math.random()<0.7)G.puff(b.x+R(-8,8),R(G.bossBox().top,GY),col(b,1));
    },
    start(b){
      const P=G.P, L=lim(b);
      let x=P.x-P.f*34;
      if(x<L||x>W-L)x=P.x+P.f*34;
      b.x=clamp(x,L,W-L); b.al=0; face(); b.t=0.38; b.cnt=0;
      for(let i=0;i<10;i++)G.puff(b.x+R(-8,8),R(G.bossBox().top,GY),col(b,1));
      G.snd('vanish'); G.ring(b.x,GY-20,20,col(b),0.3);
    },
    act(b,m,dt){
      const P=G.P;
      b.al=Math.min(1,b.al+dt*5);
      b.t-=dt;
      if(b.t<=0){
        if(b.cnt)return true;
        b.cnt=1; b.t=0.25;
        const reach=m.reach||42;
        G.snd('sw_scythe'); S.shake=Math.max(S.shake,3);
        G.fxAdd({k:'arc',x:b.x+b.f*6,y:GY-20,s:reach*0.6,a0:1.5,a1:-1.3,d:b.f,c:col(b),max:0.2});
        const lo=Math.min(b.x,b.x+b.f*reach), hi=Math.max(b.x,b.x+b.f*reach);
        if(P.x>lo-4&&P.x<hi+4&&P.y>GY-40)G.bossHit(20,b.x);
      }
    }},
  // دوّامة تلاحق اللاعب
  spin:{tel:0.5,aT:0.2,aA:-0.2,rec:0.95,snd:'tel',
    start(b,m){b.t=m.dur||1.5;G.snd('spin');},
    act(b,m,dt){
      const P=G.P, dx=P.x-b.x;
      b.spinA+=dt*20;
      if(Math.abs(dx)>4)b.x+=Math.sign(dx)*115*dt;
      if(Math.random()<0.6)G.spark(b.x+R(-24,24),GY-R(0,40),col(b),1,60);
      if(Math.abs(dx)<b.def.hw+16&&P.y>G.bossBox().top)G.bossHit(16,b.x);
      b.t-=dt;
      return b.t<=0;
    }},
  // نَفَس ناري أمام الزعيم (ابتعد أو اقفز خلفه بالمراوغة)
  breath:{tel:0.7,aT:1.0,aA:0.3,rec:1.0,snd:'tel',
    start(b){b.t=1.0;G.snd('breath');},
    act(b,m,dt){
      const P=G.P, d=(P.x-b.x)*b.f, range=m.range||112;
      S.shake=Math.max(S.shake,1.5);
      if(Math.random()<0.8)G.spark(b.x+b.f*R(30,range),GY-R(0,20),col(b),1,50);
      if(d>b.def.hw-6&&d<range&&P.y>GY-30)G.bossHit(18,b.x);
      b.t-=dt;
      return b.t<=0;
    }},
  // شعاع يمسح الأرض كلها (اقفز!)
  beam:{tel:0.9,aT:2.2,aA:-0.6,rec:0.9,snd:'warn',
    start(b){b.t=0.4;G.snd('beam');S.shake=6;S.flash=Math.max(S.flash,0.12);},
    act(b,m,dt){
      if(G.P.y>GY-10)G.bossHit(22,b.x);
      for(let i=0;i<3;i++)G.spark(R(0,W),GY-3,col(b),1,70);
      b.t-=dt;
      return b.t<=0;
    }}
};

// --- ردود الفعل الذكية ---
// قفزة سريعة للخلف (لا يُصاب أثناءها)
M.backstep={tel:0.06,aT:0.6,aA:0.6,rec:0.12,
  start(b){
    b.sx=b.x; b.tx=clamp(b.x-b.f*76,lim(b),W-lim(b)); b.lt=0;
    G.snd('dodge'); for(let i=0;i<6;i++)G.puff(b.x+R(-8,8),GY-1,'#5a564c');
  },
  act(b,m,dt){
    b.lt+=dt/0.24;
    const u=Math.min(1,b.lt);
    b.x=b.sx+(b.tx-b.sx)*u; b.y=GY-Math.sin(Math.PI*u)*12; b.al=0.45;
    if(Math.random()<0.6)G.puff(b.x,GY-R(0,b.def.h*0.6),col(b,1));
    if(u>=1){b.punish=true;return true;}
  }};
// دفعة صادمة تُبعد اللاعب
M.burst={tel:0.3,aT:2.4,aA:-1.2,rec:0.35,snd:'tel',
  start(b){
    const P=G.P, box=G.bossBox(), cy=(box.top+box.bot)/2;
    b.t=0.15; S.shake=Math.max(S.shake,7); S.flash=Math.max(S.flash,0.12);
    G.snd('slam'); G.snd('whoosh');
    G.ring(b.x,cy,70,col(b),0.35); G.ring(b.x,cy,46,'#ffffff',0.25);
    for(let i=0;i<14;i++)G.puff(b.x+R(-40,40),GY-1,'#5a564c');
    if(Math.abs(P.x-b.x)<b.def.hw+52&&Math.abs(P.y-GY)<60){
      if(!G.bossHit(12,b.x)&&P.state!=='dead'&&P.guard<=0)P.x=clamp(P.x+(P.x>=b.x?1:-1)*26,10,W-10);
    }
  },
  act(b,m,dt){b.t-=dt;return b.t<=0;}};
// الملك يستدعي حرّاسه
M.summon={tel:0.7,aT:2.5,aA:2.5,rec:0.7,snd:'cast',
  start(b){
    let n=0; for(const e of G.enemies)if(e.state!=='dead')n++;
    for(const x of [30,W-30]){
      if(n>=2)break;
      const e=G.addEnemy({type:'guard',x:x,minX:14,maxX:W-14,noLoot:true},1.3);
      e.cd=1; n++;
      G.ring(x,GY-14,26,col(b),0.4); for(let i=0;i<12;i++)G.puff(x+R(-8,8),GY-R(0,28),col(b,1));
    }
    G.snd('vanish'); S.shake=Math.max(S.shake,4);
  },
  act(){return true;}};

function pred(b,t){      // أين سيكون اللاعب بعد t ثانية؟ (الزعماء الأذكى يتوقعون أدق)
  const P=G.P;
  return clamp(P.x+P.vx*t*Math.min(1,b.iq+0.25),10,W-10);
}
function startMove(b,m){
  const D=M[m.m], k=[1,0.72,0.58,0.5][b.phase-1];
  face();
  b.state='move'; b.mv=m; b.sub='tel'; b.cnt=0; b.al=1; b.y=GY;
  if(b.def.moves.indexOf(m)>=0)b.last=m;
  b.t=(m.tel||D.tel)*k;
  if(D.snd)G.snd(D.snd);
}
// ردّ فعل حين يُحاصَر الزعيم أو حين يبدأ اللاعب ضربته الخاصة
function react(b){
  b.evCd=4.2-b.iq*2.4; b.hits=0;
  const ev=b.def.evade;
  if(ev==='tp'){
    const tp=b.def.moves.find(m=>m.m==='teleport'&&(!m.ph||b.phase>=m.ph));
    if(tp){startMove(b,tp);b.t*=0.5;return;}
  }
  if(ev==='burst'){startMove(b,{m:'burst'});return;}
  // قفزة للخلف، وإن كان ظهره للجدار فدفعة صادمة
  const room=b.f>0?b.x-lim(b):(W-lim(b))-b.x;
  startMove(b,{m:room>40?'backstep':'burst'});
}
// ملاحظات من اللاعب: hit=أصابني · special=بدأ ضربته الخاصة
G.bossNote=function(kind){
  const b=G.B;
  if(!b||b.state==='dead')return;
  if(kind==='hit'){b.hits++;b.hitT=2.4;}
  else if(kind==='special'&&(b.state==='idle'||b.state==='recover')&&b.evCd<=0&&Math.random()<b.iq+0.2)react(b);
};

// اختيار الهجمة التالية حسب المسافة والمرحلة وتصرفات اللاعب
const CLOSER={charge:1,leap:1,teleport:1,bolts:1,beam:1,rain:1,pillars:1};
function choose(b,near){
  const c=[]; let tot=0;
  for(const m of b.def.moves){
    if(m.ph&&b.phase<m.ph)continue;
    let w=(near?m.n:m.f)||0;
    if(m===b.last)w*=0.35;
    // اللاعب يهرب أو يعالج نفسه: يفضّل ما يصل إليه من بعيد
    if(b.punish||b.farT>2.5)w*=CLOSER[m.m]?2.6:0.3;
    if(m.m==='summon'){let n=0;for(const e of G.enemies)if(e.state!=='dead')n++;if(n>=2)w=0;}
    if(w>0){c.push([m,w]);tot+=w;}
  }
  if(!tot)return null;
  let q=Math.random()*tot;
  for(const e of c){q-=e[1];if(q<=0)return e[0];}
  return c[c.length-1][0];
}

G.updBoss=function(dt){
  const b=G.B, p=G.P, d=b.def;
  b.flash=Math.max(0,b.flash-dt);
  b.lag+=(b.hp-b.lag)*Math.min(1,dt*3);
  b.roar=b.state==='roar';
  b.tel=b.state==='move'&&b.sub==='tel';

  if(b.state==='dead'){
    const box=G.bossBox();
    b.t-=dt;
    if(Math.random()<0.8)G.puff(b.x+R(-12,12),R(box.top,box.bot),'#4a4258');
    if(Math.random()<0.25)G.spark(b.x+R(-10,10),R(box.top,box.bot),col(b),2,90);
    if(b.t<=0&&S.game==='play')G.win();
    return;
  }
  // الانتقال للمرحلة التالية (يصرخ من جديد)
  const maxPh=d.phases||2;
  if(b.phase<maxPh&&b.hp<=b.max*(1-b.phase/maxPh)&&b.state!=='intro'){
    b.phase++;
    const box=G.bossBox();
    for(let i=0;i<24;i++)G.spark(b.x+R(-8,8),R(box.top,box.bot),'#ff3b2f',1,140);
    S.flash=0.2;
    startRoar(0.9);
    b.hits=0; b.evCd=1.5;
  }
  const k=[1,0.72,0.58,0.5][b.phase-1];
  const dx=p.x-b.x, dist=Math.abs(dx);
  // ذاكرة قصيرة: كم مرة أُصيب؟ هل اللاعب بعيد منذ مدة؟
  b.evCd-=dt;
  if(b.hitT>0){b.hitT-=dt;if(b.hitT<=0)b.hits=0;}
  b.farT=dist>95?b.farT+dt:0;
  const calm=b.state==='idle'||b.state==='recover';
  if(calm&&b.hits>=5&&b.evCd<=0&&p.state!=='dead'){react(b);}
  let armT=(d.armIdle||-1.2)+Math.sin(S.time*2)*0.04, armS=6;

  switch(b.state){
    case 'intro':
      b.t-=dt; if(b.t<=0)startRoar(1.5);
      break;

    case 'roar':{             // صرخة الزعيم تدفع اللاعب للخلف
      armT=2.5; armS=10;
      b.f=dx>=0?1:-1;
      S.shake=Math.max(S.shake,2.5);
      b.rt-=dt;
      if(b.rt<=0){
        b.rt=0.16;
        G.ring(b.x+b.f*3,G.bossBox().top+10,95,b.phase>=2?'#ff6a4a':'#d8cfa8',0.55);
      }
      if(Math.random()<0.5)G.parts.push({x:R(0,W),y:0,vx:R(-5,5),vy:R(20,60),life:R(0.5,1.1),max:1.1,c:'#5a564c',g:200});
      if(p.state!=='dead'&&p.state!=='dodge')p.x=clamp(p.x+(p.x>=b.x?1:-1)*28*dt,10,W-10);
      b.t-=dt;
      if(b.t<=0)go('idle',0.6);
      break;
    }
    case 'stun':
      armT=-1.5;
      b.t-=dt;
      if(b.t<=0)go('idle',0.3);
      break;

    case 'idle':{
      b.f=dx>=0?1:-1;
      const keep=d.keep||34, sp=d.spd*(1+(b.phase-1)*0.45);
      if(dist>keep+4)b.x+=b.f*sp*dt;
      else if(d.keep&&dist<keep-36)b.x-=b.f*sp*0.8*dt;      // الزعماء بعيدو المدى يبتعدون
      b.t-=dt;
      // يعاقب اللاعب إذا حاول العلاج أمامه
      if(p.state==='heal'&&b.t>0.12&&Math.random()<b.iq*dt*8){b.t=0.1;b.punish=true;}
      if(b.t<=0&&p.state!=='dead'){
        const m=choose(b,dist-d.hw<50);
        b.punish=false;
        if(!m){go('idle',0.3);break;}
        startMove(b,m);
      }
      break;
    }
    case 'move':{
      const m=b.mv, D=M[m.m];
      if(b.sub==='tel'){
        armT=D.aT; armS=8;
        if(D.telUpd)D.telUpd(b,m,dt);
        b.t-=dt;
        if(b.t<=0){b.sub='act';D.start(b,m,k);}
      }else{
        armT=typeof D.aA==='function'?D.aA(b):D.aA; armS=40;
        if(D.act(b,m,dt,k)===true){
          b.al=1; b.y=GY;
          // في المراحل المتقدمة يربط هجمتين متتاليتين بلا استراحة
          const chain=b.phase>=2&&M[m.m].rec>0.2&&Math.random()<b.iq*0.7;
          go('recover',(m.rec||D.rec)*k*(chain?0.25:1));
        }
      }
      break;
    }
    case 'recover':
      b.t-=dt;
      if(b.t<=0)go('idle',R(0.5,1.1)*k*(1-b.iq*0.45));
      break;
  }
  b.x=clamp(b.x,lim(b)-4,W-lim(b)+4);
  b.arm+=(armT-b.arm)*Math.min(1,dt*armS);
};

/* ================== الرسم ================== */
G.drawBoss=function(){
  const b=G.B, k=G.ctx, d=b.def, t=S.time;
  if(b.state==='dead'&&b.t<=0)return;
  const roar=b.state==='roar', mv=b.state==='move'?b.mv.m:'', act=b.sub==='act';
  let al=b.al, ox=0;
  if(b.state==='intro')al=clamp(1-b.t/1.2,0,1);
  if(b.state==='dead')al=clamp(b.t/2.6,0,1);
  const box=G.bossBox(), cy=(box.top+box.bot)/2, c=G.ELEM[d.elem];

  // تحذير الشعاع ثم الشعاع نفسه
  if(mv==='beam'){
    if(!act){
      if((t*16|0)%2){r(0,GY-1,W,2,c[2]);}
      G.alpha(0.25); r(0,GY-9,W,9,c[1]); G.alpha(1);
      for(let x=10;x<W;x+=40)G.txt('!',x+((t*40)%40),GY-14,c[3]);
    }else{
      r(0,GY-10,W,10,c[1]); r(0,GY-8,W,7,c[2]); r(0,GY-6,W,3,c[3]);
      for(let x=0;x<W;x+=6)r(x,GY-12-((Math.sin(x+t*50)*3)|0),3,3,c[2]);
      for(let x=20;x<W;x+=60)G.glow(c[2],x,GY-5,1,1.3);
    }
  }
  // هالة الغضب + توهج الموت
  if((b.phase>=2&&b.state!=='dead')||roar){
    G.glow(b.phase>=3?'#ffb347':'#ff3c28',b.x,cy-d.h*0.2,al*(0.55+0.25*Math.sin(t*7)),Math.max(1,d.h/52));
    G.glow('#ff3c28',b.x,cy+d.h*0.2,al*(0.55+0.25*Math.sin(t*7)),Math.max(1,d.h/52));
  }
  if(b.state==='dead')G.glow(c[2],b.x+R(-8,8),cy+R(-20,20),al);

  k.save();
  k.globalAlpha=al;
  if(mv==='charge')ox=act?4:-4;
  if(mv==='leap'&&!act)ox=-2;
  if(b.flash>0)ox-=2;
  const bob=d.hov?Math.sin(t*2)*3:Math.sin(t*1.6)*1;
  let fx=b.f;
  if(mv==='spin'&&act)fx=Math.sin(b.spinA)>0?1:-1;
  k.translate(Math.round(b.x+(roar?R(-1,1):0)+(b.state==='stun'?Math.sin(t*30):0)),Math.round(b.y-(d.hov||0)+bob+(mv==='leap'&&!act?2:0)));
  k.scale(fx,1);
  k.translate(ox,0);
  const fl=b.flash>0, C=col=>fl?'#ffffff':col;
  const keep=b.al; b.al=al;
  // إن كانت للزعيم صورة (sprites.js) تُرسم منها، وإلا يُرسم بالكود
  if(!(G.drawSpriteBoss&&G.drawSpriteBoss(b,fl)))d.draw(b,C,t);
  b.al=keep;
  k.restore();
  G.alpha(1);

  // علامة التحذير قبل الهجمة
  if(b.tel&&al>0.5&&(t*10|0)%2)G.txt('!',b.x,box.top-8,'#ff5a4a',true);
  // الدوّامة
  if(mv==='spin'){
    const rad=d.hw+18;
    for(let j=0;j<2;j++)for(let i=0;i<16;i++){
      const a=(act?b.spinA:t*6)+j*Math.PI-i*0.12;
      G.alpha((act?0.9:0.35)*(1-i/16));
      r(b.x+Math.cos(a)*rad,cy+Math.sin(a)*rad*0.45,3,2,i<3?c[3]:c[2]);
    }
    G.alpha(1);
  }
  // النَّفَس
  if(mv==='breath'){
    const mo=d.mouth||[d.hw,-d.h*0.6], mx=b.x+b.f*mo[0], my=b.y+mo[1];
    if(!act){G.glow(c[2],mx,my,0.6+0.4*Math.sin(t*30),0.7);}
    else{
      const range=(b.mv.range||112)-mo[0];
      for(let i=0;i<range;i+=3){
        const u=i/range, w=2+u*14, y=my+(GY-8-my)*Math.min(1,u*1.6)+Math.sin(i*0.6+t*40)*2;
        G.alpha(1-u*0.5);
        r(mx+b.f*i-1,y-w/2,4,w,c[1]); r(mx+b.f*i-1,y-w/4,4,w/2,c[2]);
        if(u<0.6)r(mx+b.f*i,y-1,3,2,c[3]);
      }
      G.alpha(1);
      G.glow(c[2],mx+b.f*range*0.5,GY-12,1,1.6);
    }
  }
  // نجوم الشلل
  if(b.state==='stun'){
    for(let i=0;i<3;i++){
      const a=t*6+i*2.09;
      r(b.x+Math.cos(a)*10-1,box.top-6+Math.sin(a)*3-1,3,3,'#ffe066'); r(b.x+Math.cos(a)*10,box.top-6+Math.sin(a)*3,1,1,'#ffffff');
    }
  }
};

// صورة الزعيم داخل القائمة
G.drawBossPortrait=function(cv,i){
  const g=cv.getContext('2d'), d=G.BOSSES[i];
  cv.width=72; cv.height=72;
  g.clearRect(0,0,72,72);
  const b=G.makeBoss(i); b.state='idle'; b.f=1;
  const tall=d.h+(d.hov||0)+14, sc=Math.min(1,64/tall,64/(d.hw*2+44));
  G.setCtx(g);
  g.save();
  g.translate(32,68); g.scale(sc,sc); g.translate(0,-(d.hov||0));
  d.draw(b,c=>c,1.3);
  g.restore();
  G.setCtx(null);
};

})(window.G);
