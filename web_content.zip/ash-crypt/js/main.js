/* ================== main.js — حلقة اللعبة والرسم وضبط الشاشة ================== */
(function(G){
'use strict';
const W=G.W, H=G.H, GY=G.GY, R=G.R, r=G.r, S=G.S, $=G.$, clamp=G.clamp;
const stage=$('stage'), cv=G.cv, bossName=$('bossName'), bSp=$('bSp');
const bSkill=$('bSkill');
let spReady=false, skCd=false;

G.clearAll=function(){
  G.parts.length=0; G.fx.length=0; G.decals.length=0; G.ghosts.length=0; G.shots.length=0;
  G.enemies.length=0; G.picks.length=0;
  G.clearHazards();
  S.shake=0; S.freeze=0; S.flash=0; S.slow=0;
};
// تجهيز قتال زعيم
G.reset=function(){
  G.clearAll();
  G.L=null; G.cam.x=0;
  G.resetPlayer();
  G.B=G.makeBoss(S.boss);
  S.elapsed=0; S.gotCoins=0; S.gotCrys=0;
};
// تجهيز مرحلة مغامرة
G.resetStage=function(c,idx){
  G.clearAll();
  G.B=null;
  G.L=G.buildLevel(c,idx);
  G.resetPlayer(); G.P.x=40;
  G.spawnEnemies(G.L);
  G.cam.x=0;
  S.elapsed=0; S.gotCoins=0; S.gotCrys=0;
};

/* ---------- تحديث اللعبة ---------- */
function step(dt){
  S.time+=dt;
  S.flash=Math.max(0,S.flash-dt);
  G.musicTick(dt);
  if(S.freeze>0){S.freeze-=dt;return;}          // توقف لحظي عند الضربات
  if(S.slow>0){S.slow-=dt;dt*=0.35;}            // حركة بطيئة
  S.shake=Math.max(0,S.shake-dt*18);
  for(const k in G.buf)G.buf[k]=Math.max(0,G.buf[k]-dt);
  if(S.game==='play'){
    if(!G.B||G.B.state!=='dead')S.elapsed+=dt;
    G.updPlayer(dt);
    if(G.B)G.updBoss(dt);
    if(S.game==='play'&&(G.L||G.enemies.length))G.updEnemies(dt);     // وحوش المرحلة أو حرّاس الزعيم
    if(G.L&&S.game==='play')G.updLevel(dt);
    if(S.game==='play'){G.updShots(dt); G.updDots(dt); G.updHazards(dt); G.updPicks(dt); G.realTick(dt);}
    if(S.game==='play'&&G.P.state==='dead'){S.deadT-=dt;if(S.deadT<=0)G.lose();}
  }
  // الكاميرا تتبع اللاعب في المراحل
  if(G.L&&G.P){
    const tx=clamp(G.P.x-W*0.42+G.P.f*18,0,G.L.w-W);
    G.cam.x+=(tx-G.cam.x)*Math.min(1,dt*6);
  }else G.cam.x=0;
  G.updParts(dt); G.updFx(dt);
  const rdy=S.game==='play'&&G.P.en>=G.CFG.energyMax&&G.P.state!=='dead';
  if(rdy!==spReady){spReady=rdy;bSp.classList.toggle('ready',rdy);}
  const cd=G.P.skCd>0;
  if(cd!==skCd){skCd=cd;bSkill.classList.toggle('cd',cd);}
}

/* ---------- رسم المشهد ---------- */
function draw(){
  const k=G.mainCtx, P=G.P, B=G.B, L=G.L, inGame=S.game!=='menu'&&P;
  G.setCtx(null);
  k.setTransform(1,0,0,1,0,0);
  k.globalAlpha=1; k.globalCompositeOperation='source-over';
  const s=S.shake>0.5?S.shake:0;
  const sx=Math.round(R(-s,s)), sy=Math.round(R(-s,s)*0.6);
  const cx=inGame&&L?Math.round(G.cam.x):0;
  // الخلفية: في المراحل تتكرر الغرفة أفقياً مع حركة الكاميرا
  if(cx||(inGame&&L)){
    const off=-(cx%W);
    for(let tx=off;tx<W;tx+=W){k.setTransform(1,0,0,1,sx+tx,sy);G.drawRoomBack();}
  }else{k.translate(sx,sy);G.drawRoomBack();}
  k.setTransform(1,0,0,1,sx-cx,sy);
  if(inGame){
    if(L)G.drawLevelBack();
    G.drawHazardsBack();
    // ظلال تحت الشخصيات
    G.drawDecals();                               // بقع الدم والحروق والسهام المغروزة
    G.drawHeroShadow(P);
    if(B&&B.state!=='dead'){
      const sh=Math.max(4,B.def.hw+3-(GY-B.y)*0.15-(B.def.hov?4:0));
      G.alpha(0.35*B.al); r(B.x-sh,GY,sh*2,2,'#000000');
    }
    G.alpha(1);
    if(L)G.drawLevelMid();
    if(B)G.drawBoss();
    if(L||G.enemies.length)G.drawEnemies();
    G.drawPlayer();
    G.drawShots();
    G.drawHazardsFront();
    G.drawPicks();
    if(L)G.drawLevelFront();
    G.drawParts();
    G.drawFx();
  }
  k.setTransform(1,0,0,1,sx,sy);
  G.drawRoomFront();

  k.setTransform(1,0,0,1,0,0);
  k.drawImage(G.vig,0,0);
  if(inGame&&S.game==='play'){
    if(B&&B.phase>=2&&B.state!=='dead'){G.alpha(0.05+0.03*Math.sin(S.time*3));r(0,0,W,H,'#ff2010');G.alpha(1);}
    if(P.hp<=G.maxHp()*0.3&&P.state!=='dead'){G.alpha(0.12+0.08*Math.sin(S.time*6));r(0,0,W,H,'#7a0010');G.alpha(1);}
  }
  if(S.flash>0){G.alpha(Math.min(0.65,S.flash*2.2));r(0,0,W,H,'#fff2c0');G.alpha(1);}
  if(inGame)G.drawHud();
  if(S.game==='menu')G.drawPreviews();
}

let last=0;
function loop(ts){
  const dt=Math.min(0.033,(ts-last)/1000||0);
  last=ts;
  step(dt); draw();
  requestAnimationFrame(loop);
}
G.step=step; G.draw=draw;   // للاختبار

/* ---------- ضبط حجم الشاشة (أفقي دائماً) ---------- */
G.resize=function(){
  const w=window.innerWidth, h=window.innerHeight;
  G.rot=h>w;                           // الجوال بالطول → ندوّر اللعبة 90 درجة
  const sw=G.rot?h:w, sh=G.rot?w:h;    // أبعاد المسرح بعد التدوير
  stage.style.width=sw+'px'; stage.style.height=sh+'px';
  stage.style.transform=G.rot?('translate('+w+'px,0) rotate(90deg)'):'none';
  stage.style.setProperty('--sw',sw+'px'); stage.style.setProperty('--sh',sh+'px');   // أبعاد المسرح بعد التدوير (لخلفية القائمة)
  const s=Math.min(sw/W,sh/H);
  const cw=W*s, ch=H*s, left=(sw-cw)/2, top=(sh-ch)/2;
  cv.style.width=cw+'px'; cv.style.height=ch+'px';
  cv.style.left=left+'px'; cv.style.top=top+'px';
  bossName.style.left=(left+110*s)+'px'; bossName.style.width=(200*s)+'px';
  bossName.style.top=(top+12*s)+'px'; bossName.style.fontSize=Math.max(9,7*s)+'px';
};
window.addEventListener('resize',G.resize);
window.addEventListener('orientationchange',()=>setTimeout(G.resize,200));

/* ---------- التشغيل ---------- */
G.resize();
G.reset();
G.initUI();
requestAnimationFrame(loop);

})(window.G);
