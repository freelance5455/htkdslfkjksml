/* ================== bosses.js — بيانات الزعماء ورسمهم ==================
   لإضافة زعيم جديد: اكتب دالة رسم ثم أضف سطراً في G.BOSSES في آخر الملف.

   خانات الزعيم:
     hp=الصحة · hw=نصف العرض · h=الارتفاع · hov=ارتفاع الطفو (للزعماء الطائرين)
     spd=سرعة المشي · keep=المسافة التي يحافظ عليها · dmg=مضاعف الضرر
     elem=العنصر (fire, ice, poison, dark, blood, bolt) · room=اسم الغرفة
     moves=قائمة الهجمات: m=اسم الهجمة · n=وزنها قريباً · f=وزنها بعيداً · ph=تظهر من المرحلة كذا
   الهجمات المتاحة (معرّفة في boss-ai.js):
     slam ضربة أرضية · charge اندفاع · pillars أعمدة · bolts كرات · leap قفزة
     rain مطر مقذوفات · teleport انتقال وطعنة · spin دوّامة · breath نَفَس · beam شعاع أرضي · summon استدعاء حرّاس
     evade=ردّ فعله حين تحاصره: burst دفعة صادمة · step قفزة للخلف · tp انتقال
     talk=الحوار القصير عند أول لقاء: b الزعيم · h البطل   */
(function(G){
'use strict';
const r=G.r, pl=G.pl, ell=G.ell, R=G.R;
const cos=Math.cos, sin=Math.sin;

function eyeC(b,base){return b.tel?'#ffffff':(b.phase>=2?'#ff3b2f':base);}
// ذراع تحمل سلاحاً: ترجع موضع اليد والاتجاه
function arm(b,C,sx,sy,len,c,th){
  const ca=cos(b.arm), sa=-sin(b.arm), hx=sx+ca*len, hy=sy+sa*len;
  pl(sx,sy,hx,hy,C(c),th||2);
  return {hx,hy,ca,sa};
}

/* 1) حارس الضريح — هيكل عظمي برداء وهراوة */
function dWarden(b,C,t){
  const roar=b.roar, ex=roar?-1:0, ey=roar?-3:0;
  if(roar){pl(-4,-58,-13,-72,C('#6f6650'),2); pl(-13,-72,-11,-85,C('#6f6650'));
           r(-13,-88,1,3,C('#b9ad8c')); r(-11,-88,1,3,C('#b9ad8c')); r(-9,-87,1,2,C('#b9ad8c'));}
  else{pl(-4,-58,-10,-36,C('#6f6650'),2); pl(-10,-36,-8,-20,C('#6f6650'));}
  for(let i=0;i<60;i+=2){
    const w=Math.round(6+i*0.17), s=Math.round(sin(t*2+i*0.12)*i*0.025);
    r(-w+s,-62+i,w*2,2,C(i%8<2?'#3a3346':'#463e54'));
    r(w+s-2,-62+i,2,2,C('#6a5f80')); r(-w+s,-62+i,1,2,C('#2a2433'));
    if(i>30&&i%10===0)r(-2+s,-62+i,1,6,C('#322b3d'));
  }
  for(let i=-15;i<15;i+=5)r(i+Math.round(sin(t*3+i)),-3,3,3,C('#322b3d'));
  r(-10,-36,20,2,C('#8a6a2a')); r(-1,-37,3,4,C('#b9ad8c')); r(0,-36,1,1,C('#0a0a0f'));
  r(-12,-63,7,4,C('#5a5068')); r(-12,-63,7,1,C('#8a7fa0')); r(-13,-65,2,2,C('#b9ad8c'));
  r(6,-63,7,4,C('#5a5068'));  r(6,-63,7,1,C('#8a7fa0'));  r(12,-65,2,2,C('#b9ad8c'));
  r(-4,-56,9,12,C('#0d0b12'));
  r(-3,-54,7,1,C('#8f8468')); r(-3,-51,7,1,C('#8f8468')); r(-2,-48,6,1,C('#8f8468'));
  r(-7+ex,-76+ey,14,14,C('#322b3d')); r(-8+ex,-72+ey,16,9,C('#322b3d')); r(-7+ex,-63+ey,14,3,C('#3a3346'));
  r(-7+ex,-76+ey,14,1,C('#463e54')); r(-2+ex,-72+ey,8,9,C('#050408'));
  const eye=eyeC(b,'#ffb14a');
  r(0+ex,-69+ey,2,1,eye); r(4+ex,-69+ey,2,1,eye);
  if(roar){r(0+ex,-67+ey,6,4,'#7a0010'); r(1+ex,-66+ey,4,2,'#ff5a3a'); r(2+ex,-66+ey,2,1,'#fff2c0');}
  pl(-5+ex,-76+ey,-8+ex,-83+ey,C('#b9ad8c')); pl(0+ex,-76+ey,0+ex,-85+ey,C('#b9ad8c')); pl(5+ex,-76+ey,9+ex,-83+ey,C('#b9ad8c'));
  // الذراع والهراوة
  const A=arm(b,C,3,-58,26,'#b9ad8c'), tx=3+A.ca*60, ty=-58+A.sa*60;
  pl(A.hx,A.hy,tx,ty,C('#4a3d30'),2);
  r(tx-4,ty-4,9,9,C('#77706a')); r(tx-3,ty-3,7,7,C('#5a544e')); r(tx-4,ty-4,9,1,C('#9a938c'));
  r(tx-6,ty,2,1,C('#b9ad8c')); r(tx+5,ty,2,1,C('#b9ad8c')); r(tx,ty-6,1,2,C('#b9ad8c')); r(tx,ty+5,1,2,C('#b9ad8c'));
  if(b.phase>=2)r(tx-1,ty-1,3,3,'#ff3b2f');
}

/* 2) الفارس الساقط — دروع سوداء وسيف عظيم */
function dKnight(b,C,t){
  const cw=sin(t*4)*2, ey=b.roar?-2:0;
  for(let i=0;i<28;i+=2)r(-9-i*0.15+cw*(i/28),-37+i,7,2,C(i%6<2?'#5a1020':'#7a1c2a'));
  r(-5,-14,4,14,C('#2a2c36')); r(1,-14,4,14,C('#3a3d4a')); r(-6,-2,6,2,C('#1a1b22')); r(1,-2,6,2,C('#1a1b22'));
  r(-5,-8,4,1,C('#55596a')); r(1,-8,4,1,C('#55596a'));
  r(-7,-35,14,21,C('#3a3d4a')); r(-7,-35,3,21,C('#2a2c36')); r(-7,-35,14,1,C('#6a6f80'));
  r(-1,-31,3,11,C('#55596a')); r(-7,-17,14,2,C('#8a6a2a')); r(-1,-18,2,4,C('#c9a03c'));
  r(-11,-38,7,6,C('#55596a')); r(5,-38,7,6,C('#55596a')); r(-11,-38,7,1,C('#8a90a6')); r(5,-38,7,1,C('#8a90a6'));
  r(-12,-40,2,3,C('#8a90a6')); r(11,-40,2,3,C('#8a90a6'));
  r(-4,-46+ey,9,10,C('#3a3d4a')); r(-4,-46+ey,9,1,C('#8a90a6')); r(-4,-46+ey,2,10,C('#2a2c36'));
  r(0,-42+ey,5,1,eyeC(b,'#ff8a3a')); r(2,-41+ey,1,5,C('#14151a'));
  pl(-4,-45+ey,-9,-52+ey,C('#b9ad8c')); pl(4,-45+ey,9,-52+ey,C('#b9ad8c'));
  if(b.roar)r(0,-39+ey,4,2,'#ff5a3a');
  const A=arm(b,C,4,-33,9,'#55596a'), tx=A.hx+A.ca*31, ty=A.hy+A.sa*31;
  pl(A.hx,A.hy,tx,ty,C('#c8d0e0'),2); pl(A.hx+A.ca*4,A.hy+A.sa*4,tx,ty,C('#8a93a6'));
  pl(A.hx-A.sa*4+A.ca*3,A.hy+A.ca*4+A.sa*3,A.hx+A.sa*4+A.ca*3,A.hy-A.ca*4+A.sa*3,C('#8a6a2a'),2);
  if(b.phase>=2){G.alpha(0.6*b.al);pl(A.hx+A.ca*6,A.hy+A.sa*6,tx,ty,'#ff3b2f');G.alpha(b.al);}
}

/* 3) ملكة العناكب — جسم عريض منخفض بثماني أرجل */
function dSpider(b,C,t){
  const mv=(b.state==='idle'||b.state==='move')?2.5:0.6, up=b.tel?5:0;
  for(let i=0;i<4;i++){
    const s=sin(t*10+i*1.6)*mv, kx=7+i*5, ky=-26-i*2;
    pl(4,-12,kx+2,ky-(i===0?up:0),C('#2a1f2e'),2); pl(kx+2,ky-(i===0?up:0),kx+9+s,i===0&&up?-10:0,C('#3a2b40'));
    pl(-6,-12,-kx-4,ky,C('#2a1f2e'),2); pl(-kx-4,ky,-kx-11-s,0,C('#3a2b40'));
  }
  const br=Math.round(sin(t*3));
  ell(-9,-17+br,13,10,C('#1e1624')); ell(-10,-18+br,10,7,C('#2e2236'));
  r(-13,-22+br,5,2,C('#c0283a')); r(-12,-20+br,3,3,C('#c0283a')); r(-13,-17+br,5,2,C('#c0283a'));
  for(let i=0;i<4;i++)r(-18+i*5,-25+br+(i%2),1,2,C('#4a3858'));
  ell(9,-12,8,6,C('#2a1f2e')); ell(9,-13,6,4,C('#3a2b40'));
  const e=eyeC(b,'#ff4a4a');
  r(12,-16,2,2,e); r(15,-14,2,1,e); r(11,-12,1,1,e); r(14,-11,1,1,e); r(9,-17,1,1,e);
  const jaw=b.roar||b.tel?3:0;
  pl(13,-8,15+jaw,-3,C('#d8cfa8')); pl(10,-8,10-jaw*0.5,-3,C('#d8cfa8'));
  if(b.roar)r(11,-8,3,3,'#9be04a');
}

/* 4) ساحر الصقيع — هيكل طافٍ بعصا بلّورية */
function dLich(b,C,t){
  const ey=b.roar?-2:0;
  for(let i=0;i<42;i+=2){
    const w=Math.round(2+i*0.2), s=Math.round(sin(t*2.5+i*0.2)*(42-i)*0.06);
    r(-w+s,-i-2,w*2,2,C(i%8<2?'#1c3852':'#2a5072')); r(w+s-2,-i-2,2,2,C('#4a80a8'));
  }
  r(-11,-46,22,5,C('#3a6a90')); r(-11,-46,22,1,C('#8fd8ff')); r(-12,-44,3,8,C('#2a5072')); r(10,-44,3,8,C('#2a5072'));
  r(-4,-41,9,10,C('#081420')); r(-3,-39,7,1,C('#a8c8d8')); r(-3,-36,7,1,C('#a8c8d8')); r(-2,-33,5,1,C('#a8c8d8'));
  r(-4,-56+ey,9,9,C('#cfe6f5')); r(-4,-56+ey,2,9,C('#a8c8d8')); r(-3,-47+ey,7,2,C('#a8c8d8'));
  const e=eyeC(b,'#5ae0ff');
  r(-1,-53+ey,3,3,C('#081420')); r(3,-53+ey,3,3,C('#081420')); r(0,-52+ey,1,1,e); r(4,-52+ey,1,1,e);
  if(b.roar)r(0,-48+ey,5,3,'#081420');
  pl(-4,-56+ey,-6,-63+ey,C('#8fd8ff')); pl(0,-56+ey,0,-66+ey,C('#ffffff')); pl(4,-56+ey,6,-63+ey,C('#8fd8ff')); pl(-2,-56+ey,-3,-60+ey,C('#8fd8ff')); pl(2,-56+ey,3,-60+ey,C('#8fd8ff'));
  pl(-6,-42,-12,-30,C('#a8c8d8'));
  const A=arm(b,C,5,-42,9,'#a8c8d8',1), tx=A.hx+A.ca*20, ty=A.hy+A.sa*20;
  pl(A.hx-A.ca*14,A.hy-A.sa*14,tx,ty,C('#5a4a6a'));
  r(tx-3,ty-3,6,6,C('#2a7fc0')); r(tx-2,ty-2,4,4,C('#8fd8ff')); r(tx-1,ty-1,2,2,'#ffffff');
  G.glow('#6ac8ff',tx,ty,(b.tel?1:0.5),b.tel?0.9:0.5);
}

/* 5) غول المصهر — صخور وحمم */
function dGolem(b,C,t){
  const lv=sin(t*5)>0?'#ffb347':'#ff7a2a', hot=b.phase>=2||b.tel;
  r(-15,-18,11,18,C('#2a2420')); r(4,-18,11,18,C('#3a322c')); r(-16,-4,13,4,C('#1c1814')); r(3,-4,13,4,C('#1c1814'));
  r(-17,-54,34,38,C('#3a322c')); r(-17,-54,6,38,C('#2a2420')); r(-17,-54,34,2,C('#55493f')); r(12,-52,5,34,C('#4a4038'));
  r(-12,-46,10,8,C('#2a2420')); r(2,-40,9,10,C('#2a2420')); r(-9,-30,12,8,C('#2a2420'));
  // شقوق الحمم
  pl(-10,-50,-4,-40,lv); pl(-4,-40,-8,-30,lv); pl(4,-48,8,-36,lv); pl(8,-36,2,-24,lv); pl(-2,-26,-6,-18,lv);
  r(-3,-38,6,6,C('#c2410c')); r(-2,-37,4,4,lv); if(hot)r(-1,-36,2,2,'#fff2c0');
  r(-24,-58,11,13,C('#3a322c')); r(-24,-58,11,2,C('#55493f')); r(13,-58,11,13,C('#4a4038')); r(13,-58,11,2,C('#6a5c50'));
  const ey=b.roar?-2:0;
  r(-6,-64+ey,12,11,C('#2a2420')); r(-6,-64+ey,12,2,C('#55493f'));
  const e=eyeC(b,'#ffb347'); r(-1,-59+ey,3,2,e); r(4,-59+ey,2,2,e);
  if(b.roar){r(-1,-56+ey,7,3,'#c2410c');r(0,-55+ey,5,1,'#fff2c0');}
  pl(-18,-50,-22,-30,C('#2a2420'),4); r(-27,-30,10,10,C('#2a2420'));
  const A=arm(b,C,16,-50,22,'#4a4038',5);
  r(A.hx-6,A.hy-6,13,13,C('#3a322c')); r(A.hx-6,A.hy-6,13,2,C('#6a5c50')); r(A.hx-3,A.hy-2,7,5,lv);
  G.glow('#ff5a1a',0,-36,hot?0.9:0.4,1);
}

/* 6) سيد الدماء — مصاص دماء بعباءة كالأجنحة */
function dVampire(b,C,t){
  const open=b.tel||b.roar?1:0, ey=b.roar?-1:0, fl=sin(t*5)*1.5;
  for(let i=0;i<36;i+=2){
    const w=Math.round(5+i*(0.22+open*0.3)), s=Math.round(sin(t*3+i*0.2)*i*0.04);
    r(-w+s-2,-42+i,w*2,2,C(i%6<2?'#18080e':'#260c16')); r(-w+s-2,-42+i,2,2,C('#7a1422'));
    if(open&&i>8)r(w+s-4,-42+i,2,2,C('#7a1422'));
  }
  if(open)for(let i=0;i<4;i++){r(-14-i*4,-10+i*2+fl,3,4,C('#18080e'));r(10+i*4,-10+i*2+fl,3,4,C('#18080e'));}
  r(-3,-16,3,16,C('#0e0810')); r(1,-16,3,16,C('#161018')); r(-4,-2,4,2,C('#0a0608')); r(1,-2,5,2,C('#0a0608'));
  r(-5,-40,10,24,C('#1a1018')); r(-1,-38,3,18,C('#7a1422')); r(0,-36,1,1,C('#c9a03c')); r(0,-31,1,1,C('#c9a03c')); r(0,-26,1,1,C('#c9a03c'));
  r(-7,-46,3,8,C('#a0101c')); r(5,-46,3,8,C('#a0101c')); r(-7,-46,3,1,C('#ff4a4a')); r(5,-46,3,1,C('#ff4a4a'));
  r(-3,-50+ey,7,8,C('#d8d0dc')); r(-3,-50+ey,2,8,C('#b0a8b8')); r(-3,-52+ey,7,3,C('#0a0608')); r(-4,-50+ey,2,4,C('#0a0608')); r(1,-50+ey,1,2,C('#0a0608'));
  const e=eyeC(b,'#ff2a2a'); r(0,-47+ey,2,1,e); r(3,-47+ey,1,1,e);
  if(b.roar){r(0,-45+ey,4,3,'#4a0008');r(0,-45+ey,1,2,'#ffffff');r(3,-45+ey,1,2,'#ffffff');}
  else r(1,-44+ey,2,1,C('#7a1422'));
  const A=arm(b,C,4,-38,10,'#1a1018'), A2={x:A.hx+cos(b.arm-0.6)*9,y:A.hy-sin(b.arm-0.6)*9};
  pl(A.hx,A.hy,A2.x,A2.y,C('#d8d0dc'));
  for(let i=-1;i<=1;i++)pl(A2.x,A2.y,A2.x+cos(b.arm-0.6+i*0.4)*5,A2.y-sin(b.arm-0.6+i*0.4)*5,C('#ffffff'));
}

/* 7) الذئب الأسود — منحنٍ وسريع بمخالب */
function dWolf(b,C,t){
  const run=b.state==='move'&&!b.tel, st=run?Math.round(sin(t*24)*3):0, br=Math.round(sin(t*4));
  // الذيل
  for(let i=0;i<10;i++)r(-12-i*1.4,-20+i*0.8+sin(t*6+i*0.5)*2,4,3,C(i%3?'#2a2630':'#3a3644'));
  // الأرجل الخلفية
  pl(-6,-16,-10+st,-8,C('#2a2630'),4); pl(-10+st,-8,-6+st,0,C('#22202a'),3); r(-7+st,-2,6,2,C('#1a1820'));
  pl(-2,-16,2-st,-8,C('#3a3644'),4); pl(2-st,-8,4-st,0,C('#2a2630'),3); r(3-st,-2,6,2,C('#1a1820'));
  // الجسم المنحني
  ell(-2,-24+br,10,10,C('#2a2630')); ell(3,-30+br,9,8,C('#3a3644')); ell(4,-31+br,6,5,C('#4a4656'));
  for(let i=0;i<6;i++)pl(-8+i*3,-33+br+Math.abs(i-2),-10+i*3,-37+br+Math.abs(i-2),C('#1a1820'));
  r(0,-26+br,6,6,C('#55505f'));
  // الرأس والخطم
  const hy=-38+br+(b.roar?-3:0);
  r(5,hy,9,8,C('#3a3644')); r(12,hy+3,8,4,C('#4a4656')); r(19,hy+3,2,2,C('#0a0a0f'));
  pl(6,hy,5,hy-6,C('#2a2630'),2); pl(10,hy,11,hy-6,C('#2a2630'),2);
  r(10,hy+2,2,2,eyeC(b,'#ffe066'));
  if(b.roar||b.tel){r(12,hy+7,7,3,'#4a0008');r(13,hy+7,1,2,'#ffffff');r(16,hy+7,1,2,'#ffffff');r(18,hy+7,1,1,'#ffffff');}
  else{r(13,hy+7,1,1,'#ffffff');r(16,hy+7,1,1,'#ffffff');}
  // الذراع والمخالب
  const A=arm(b,C,7,-29+br,10,'#2a2630',3), a2=b.arm-0.5, x2=A.hx+cos(a2)*10, y2=A.hy-sin(a2)*10;
  pl(A.hx,A.hy,x2,y2,C('#3a3644'),3);
  for(let i=-1;i<=1;i++)pl(x2+1,y2+1,x2+1+cos(a2+i*0.5)*6,y2+1-sin(a2+i*0.5)*6,C('#e8e0d0'));
}

/* 8) الحاصد — شبح بمنجل هائل */
function dReaper(b,C,t){
  const ey=b.roar?-2:0;
  for(let i=0;i<48;i+=2){
    const w=Math.round(3+i*0.2+(i<10?0:0)), s=Math.round(sin(t*2.2+i*0.18)*(48-i)*0.07);
    r(-w+s,-i-2,w*2,2,C(i%10<2?'#0e0c14':'#16131e')); r(-w+s,-i-2,1,2,C('#2a2440'));
    if(i<8)r(-w+s+((i*3)%5),-i,2,3,C('#0e0c14'));
  }
  r(-11,-52,22,5,C('#1c1828')); r(-11,-52,22,1,C('#3a3258'));
  r(-4,-48,9,12,C('#050408')); r(-3,-46,7,1,C('#6f6a5a')); r(-3,-43,7,1,C('#6f6a5a')); r(-2,-40,5,1,C('#6f6a5a'));
  r(-7,-64+ey,14,13,C('#16131e')); r(-8,-60+ey,16,8,C('#16131e')); r(-7,-64+ey,14,1,C('#3a3258')); pl(-6,-64+ey,0,-69+ey,C('#16131e'),2);
  r(-2,-60+ey,8,9,C('#050408'));
  r(-1,-59+ey,6,6,C('#cfc8b0')); r(0,-53+ey,4,2,C('#cfc8b0'));
  const e=eyeC(b,'#8affc0'); r(0,-57+ey,2,2,'#050408'); r(3,-57+ey,2,2,'#050408'); r(0,-57+ey,1,1,e); r(3,-57+ey,1,1,e);
  if(b.roar)r(0,-53+ey,4,3,'#050408');
  pl(-7,-48,-13,-34,C('#6f6a5a'));
  // المنجل
  const A=arm(b,C,5,-48,10,'#6f6a5a',1), u={x:A.ca,y:A.sa}, n={x:-A.sa,y:A.ca};
  const bx=A.hx-u.x*18, by=A.hy-u.y*18, tx=A.hx+u.x*30, ty=A.hy+u.y*30;
  pl(bx,by,tx,ty,C('#3a2e22'),2);
  const P=(a,c)=>[tx+n.x*a-u.x*c,ty+n.y*a-u.y*c];
  const p1=P(9,1), p2=P(17,7), p3=P(21,16);
  pl(tx,ty,p1[0],p1[1],C('#c8d0e0'),3); pl(p1[0],p1[1],p2[0],p2[1],C('#c8d0e0'),3); pl(p2[0],p2[1],p3[0],p3[1],C('#ffffff'),2);
  pl(tx,ty,p1[0],p1[1],C('#8affc0'));
  r(tx-2,ty-2,4,4,C('#55505f'));
}

/* 9) التنين العظمي — هيكل تنين ينفث اللهب */
function dDragon(b,C,t){
  const bone='#cfc8b0', boneD='#8f8468', up=b.tel?-5:(b.roar?-8:0), br=Math.round(sin(t*2.5)*1.5);
  // الذيل
  for(let i=0;i<12;i++){const y=-14+sin(t*3+i*0.5)*3+i*0.9;r(-16-i*3,y,4,3-(i>8?1:0),C(i%2?bone:boneD));}
  // الجناح العظمي
  const wf=sin(t*3)*4+(b.roar?-8:0);
  pl(-6,-34,-20,-56+wf,C(boneD),2); pl(-20,-56+wf,-36,-40+wf,C(bone)); pl(-20,-56+wf,-26,-30+wf*0.5,C(bone)); pl(-20,-56+wf,-12,-38,C(bone));
  G.alpha(0.35*b.al); for(let i=0;i<5;i++)pl(-20,-56+wf,-36+i*6,-38+wf*0.6+i,C('#4a2a1a')); G.alpha(b.al);
  // الأرجل
  pl(-10,-20,-14,-8,C(boneD),3); pl(-14,-8,-10,0,C(bone),2); r(-12,-2,8,2,C(bone));
  pl(6,-20,10,-8,C(bone),3); pl(10,-8,8,0,C(bone),2); r(7,-2,9,2,C(bone)); r(15,-1,2,1,'#ffffff');
  // القفص الصدري
  ell(-2,-24+br,15,10,C('#1a100c'));
  for(let i=0;i<6;i++){const x=-13+i*5;pl(x,-33+br+Math.abs(i-2.5),x+1,-16+br-Math.abs(i-2.5),C(i%2?bone:boneD),2);}
  r(-16,-34+br,30,2,C(bone));
  r(-4,-27+br,6,6,C('#c2410c')); r(-3,-26+br,4,4,b.phase>=2?'#fff2c0':'#ffb347'); G.glow('#ff5a1a',-1,-24+br,0.7,0.8);
  // الرقبة والجمجمة
  const hx=24, hy=-42+up+br;
  for(let i=0;i<=6;i++){const u=i/6;r(12+u*(hx-14)-2,-32+br+u*(hy+34-br)-sin(u*Math.PI)*6,5,4,C(i%2?bone:boneD));}
  r(hx-4,hy-5,12,8,C(bone)); r(hx+6,hy-3,10,5,C(bone)); r(hx+14,hy-3,2,2,C(boneD));
  pl(hx-3,hy-5,hx-10,hy-12,C(bone),2); pl(hx+1,hy-5,hx-4,hy-13,C(boneD),2);
  r(hx+1,hy-3,4,3,'#0a0605'); r(hx+2,hy-2,2,1,eyeC(b,'#ffb347'));
  const jaw=(b.roar||b.tel||(b.mv&&b.mv.m==='breath'&&b.sub==='act'))?5:1;
  r(hx-1,hy+3+jaw,15,3,C(boneD));
  for(let i=0;i<4;i++){r(hx+3+i*3,hy+2,1,2,'#ffffff');r(hx+4+i*3,hy+2+jaw,1,1,'#ffffff');}
  if(jaw>1){r(hx+3,hy+3,10,jaw-1,'#7a2a0a');r(hx+6,hy+4,5,Math.max(1,jaw-3),'#ffb347');}
}

/* 10) عين الهاوية — عين عملاقة بمجسّات */
function dEye(b,C,t){
  const shut=b.state==='stun', wide=b.roar?2:0;
  // المجسّات
  for(let k=0;k<6;k++){
    const x0=-12+k*5;
    for(let i=0;i<14;i++){r(x0+sin(t*3+k+i*0.4)*(i*0.35),-8+i*0.9-(b.tel?i*0.3:0),2,2,C(i%4?'#3a1a5a':'#6a1cb0'));}
  }
  ell(0,-24,17,17,C('#2a0a4a')); ell(0,-24,15,15,C('#4a1a7a'));
  for(let i=0;i<5;i++)pl(cos(i*1.3)*16,-24+sin(i*1.3)*16,cos(i*1.3)*22,-24+sin(i*1.3)*22+sin(t*2+i)*2,C('#3a1a5a'),2);
  if(shut){r(-12,-25,24,3,C('#2a0a4a'));r(-12,-24,24,1,C('#c07aff'));return;}
  ell(1,-24,12,11+wide,C('#e8e0f0')); ell(1,-24,12,3,C('#f8f4ff'));
  pl(-10,-28,-4,-26,C('#c0283a')); pl(-9,-19,-4,-21,C('#c0283a')); pl(10,-30,7,-27,C('#c0283a'));
  const ix=5+Math.round(sin(t*1.3)), iy=-24+Math.round(cos(t*1.7));
  ell(ix,iy,6,7,C(b.phase>=2?'#c0283a':'#8a2be2')); ell(ix,iy,4,5,C(b.phase>=2?'#ff4a4a':'#c07aff'));
  r(ix-1,iy-5,b.tel?3:2,10,b.tel?'#ffffff':'#050408');
  r(ix-3,iy-4,2,2,'#ffffff');
  G.glow(b.phase>=2?'#ff4a4a':'#c07aff',ix,iy,b.tel?1:0.5,0.8);
}

/* 11) ملك الرماد — الزعيم الأخير بسيف ملتهب */
function dKing(b,C,t){
  const cw=sin(t*3)*2.5, ey=b.roar?-3:0, lv=sin(t*8)>0?'#ffb347':'#ff7a2a';
  for(let i=0;i<54;i+=2){const w=Math.round(8+i*0.2);r(-w-3+cw*(i/54),-58+i,w*2,2,C(i%8<2?'#2a0a0a':'#4a0c14'));r(-w-3+cw*(i/54),-58+i,2,2,C('#c9a03c'));}
  r(-8,-22,7,22,C('#2a241c')); r(2,-22,7,22,C('#3a3226')); r(-9,-3,9,3,C('#1a1610')); r(2,-3,9,3,C('#1a1610'));
  r(-8,-12,7,2,C('#c9a03c')); r(2,-12,7,2,C('#c9a03c'));
  r(-11,-56,22,34,C('#3a3226')); r(-11,-56,4,34,C('#2a241c')); r(-11,-56,22,1,C('#6a5c44'));
  r(-2,-52,5,20,C('#55493a')); r(-11,-26,22,3,C('#c9a03c')); r(-2,-27,5,6,C('#ffb347'));
  pl(-7,-50,-3,-40,lv); pl(6,-48,3,-36,lv); r(-1,-46,3,3,lv);
  r(-17,-62,10,10,C('#55493a')); r(8,-62,10,10,C('#55493a')); r(-17,-62,10,2,C('#c9a03c')); r(8,-62,10,2,C('#c9a03c'));
  pl(-14,-62,-18,-70,C('#c9a03c'),2); pl(14,-62,19,-70,C('#c9a03c'),2);
  r(-6,-70+ey,12,13,C('#2a241c')); r(-6,-70+ey,12,1,C('#6a5c44')); r(-3,-66+ey,9,7,C('#0a0605'));
  const e=eyeC(b,'#ffb347'); r(-1,-64+ey,3,2,e); r(4,-64+ey,2,2,e);
  if(b.roar){r(-1,-61+ey,7,3,'#c2410c');r(0,-60+ey,5,1,'#fff2c0');}
  // التاج
  r(-7,-73+ey,14,3,C('#c9a03c')); for(let i=0;i<5;i++)r(-7+i*3,-77+ey-(i%2?0:2),2,4+(i%2?0:2),C('#ffd76a')); r(-1,-72+ey,2,2,'#ff3b2f');
  pl(-12,-54,-18,-36,C('#3a3226'),4); r(-21,-36,7,7,C('#55493a'));
  // السيف الملتهب
  const A=arm(b,C,10,-54,12,'#55493a',4), tx=A.hx+A.ca*44, ty=A.hy+A.sa*44;
  pl(A.hx-A.ca*5,A.hy-A.sa*5,A.hx,A.hy,C('#6b4a2a'),2);
  pl(A.hx-A.sa*6+A.ca*2,A.hy+A.ca*6+A.sa*2,A.hx+A.sa*6+A.ca*2,A.hy-A.ca*6+A.sa*2,C('#c9a03c'),3);
  pl(A.hx,A.hy,tx,ty,C('#c2410c'),4); pl(A.hx+A.ca*2,A.hy+A.sa*2,tx,ty,C('#ffb347'),2); pl(A.hx+A.ca*4,A.hy+A.sa*4,tx,ty,'#fff2c0');
  for(let i=0;i<6;i++){const u=0.2+i*0.14,f=sin(t*20+i*2)*3;r(A.hx+A.ca*44*u-A.sa*f,A.hy+A.sa*44*u+A.ca*f-2,2,2,lv);}
  G.glow('#ff7a2a',A.hx+A.ca*26,A.hy+A.sa*26,0.8,1.1);
}

/* ================== قائمة الزعماء (بالترتيب) ================== */
G.BOSSES=[
  {id:'warden', name:'حارس الضريح', draw:dWarden, evade:'burst',
   talk:[['b', 'من يجرؤ على إيقاظ الموتى؟'], ['h', 'جئتُ لأطفئ نار هذا الضريح.'], ['b', 'إذن ستُدفن فيه.']],
   room:'crypt', elem:'fire',
   hp:900, hw:11, h:76, spd:22, dmg:1,
   moves:[{m:'slam',n:6,f:0},{m:'charge',n:2.2,f:3.5},{m:'pillars',n:1.8,f:5,cnt:3}]},

  {id:'knight', name:'الفارس الساقط', draw:dKnight, evade:'step',
   talk:[['b', 'كنتُ مثلك يوماً... أحمل سيفاً وأملاً.'], ['h', 'وما الذي أسقطك؟'], ['b', 'سترى بنفسك حين تسقط.']],
   room:'hall', elem:'blood', pitch:1.3,
   hp:1050, hw:9, h:46, spd:42, dmg:1.05,
   moves:[{m:'slam',n:6,f:0,reach:42,tel:0.45,twice:true,rec:0.7},{m:'charge',n:2,f:4,sp:270},{m:'leap',n:1,f:3}]},

  {id:'spider', name:'ملكة العناكب', draw:dSpider, evade:'step',
   talk:[['b', 'ذبابة جديدة في شبكتي... وصغاري جائعون.'], ['h', 'لن أكون وجبة أحد.']],
   room:'nest', elem:'poison', pitch:1.9, blood:'#9be04a',
   hp:1150, hw:20, h:30, spd:46, dmg:1.05,
   moves:[{m:'slam',n:5,f:0,reach:36,tel:0.4,waves:false,rec:0.6},{m:'leap',n:3,f:4,hgt:80},
          {m:'bolts',n:1.5,f:4,cnt:3,spread:0.5,sp:150},{m:'pillars',n:1,f:2,cnt:3},{m:'rain',n:1,f:3,cnt:5,ph:2}]},

  {id:'lich', name:'ساحر الصقيع', draw:dLich, evade:'tp',
   talk:[['b', 'الدفء الذي فيك يزعجني. سأجمّده إلى الأبد.'], ['h', 'جرّب، فقد أذبتُ ما هو أبرد منك.']],
   room:'ice', elem:'ice', pitch:1.5, blood:'#8fd8ff',
   hp:1100, hw:9, h:58, hov:8, spd:30, keep:95, armIdle:1.25, dmg:1.1,
   moves:[{m:'teleport',n:5,f:1,reach:40},{m:'bolts',n:2,f:4,cnt:5,spread:0.9,sp:140},
          {m:'pillars',n:2,f:4,cnt:4},{m:'rain',n:1,f:3,cnt:6}]},

  {id:'golem', name:'غول المصهر', draw:dGolem, evade:'burst',
   talk:[['b', 'صُنعتُ... لأسحق.'], ['h', 'وأنا صُنعتُ لأكسر الصخر.']],
   room:'forge', elem:'fire', pitch:0.6, blood:'#ffb347',
   hp:1700, hw:18, h:66, spd:15, keep:44, dmg:1.2,
   moves:[{m:'slam',n:6,f:1,reach:58,waves:true,tel:0.75},{m:'leap',n:1,f:4,waves:true,hgt:60},
          {m:'rain',n:1,f:3,cnt:6},{m:'pillars',n:1,f:3,cnt:4,ph:2}]},

  {id:'vampire', name:'سيد الدماء', draw:dVampire, evade:'tp',
   talk:[['b', 'رائحة دمك شجاعة... سيكون شرابي الليلة.'], ['h', 'سأكسر أنيابك قبل أن تقترب.']],
   room:'chapel', elem:'blood', pitch:1.6,
   hp:1300, hw:8, h:52, spd:52, dmg:1.15, leech:18,
   moves:[{m:'teleport',n:4,f:4,reach:38},{m:'bolts',n:1,f:4,cnt:3,spread:1.2,sp:120,hom:260},
          {m:'charge',n:2,f:3,sp:310,tel:0.45},{m:'slam',n:4,f:0,reach:36,tel:0.35,waves:false,rec:0.55}]},

  {id:'wolf', name:'الذئب الأسود', draw:dWolf, evade:'step',
   talk:[['b', 'الغابة لي... والقمر شاهد.'], ['h', 'الليلة سيشهد القمر سقوطك.']],
   room:'forest', elem:'bolt', pitch:1.15,
   hp:1350, hw:12, h:42, spd:72, dmg:1.2,
   moves:[{m:'slam',n:6,f:0,reach:36,tel:0.3,twice:true,waves:false,rec:0.5},{m:'charge',n:2,f:5,sp:310,tel:0.4,twice:true},
          {m:'leap',n:3,f:4,tel:0.3,hgt:64},{m:'spin',n:2,f:1,ph:2,dur:1.1}]},

  {id:'reaper', name:'الحاصد', draw:dReaper, evade:'tp',
   talk:[['b', 'اسمك مكتوب في دفتري منذ زمن.'], ['h', 'إذن امحُه، فلن أموت اليوم.'], ['b', 'لا أحد يفلت من الحاصد.']],
   room:'grave', elem:'dark', pitch:0.85, blood:'#8affc0',
   hp:1550, hw:10, h:62, hov:9, spd:40, armIdle:1.2, dmg:1.25,
   moves:[{m:'slam',n:4,f:0,reach:54,waves:true},{m:'spin',n:4,f:2},{m:'teleport',n:3,f:3,reach:52},
          {m:'bolts',n:1,f:3,cnt:2,spread:1.4,sp:110,hom:240,burst:2},{m:'beam',n:1,f:2,ph:2}]},

  {id:'dragon', name:'التنين العظمي', draw:dDragon, evade:'burst',
   talk:[['b', 'عظامي أقدم من ممالككم... ونيراني لم تنطفئ.'], ['h', 'كل نار تنطفئ في النهاية.']],
   room:'lair', elem:'fire', pitch:0.7, blood:'#cfc8b0',
   hp:2100, hw:22, h:54, spd:20, keep:46, dmg:1.3, mouth:[36,-38],
   moves:[{m:'breath',n:4,f:3},{m:'slam',n:4,f:0,reach:56,waves:true},{m:'leap',n:1,f:2,waves:true,hgt:56},
          {m:'rain',n:1,f:3,cnt:7},{m:'bolts',n:0,f:3,cnt:1,sp:210,big:true,burst:2}]},

  {id:'eye', name:'عين الهاوية', draw:dEye, evade:'tp',
   talk:[['b', 'أرى كل خوف في داخلك.'], ['h', 'انظر جيداً إذن... لن تجد ما يكفي.']],
   room:'void', elem:'dark', pitch:2.2, blood:'#c07aff',
   hp:1800, hw:15, h:44, hov:14, spd:32, keep:85, dmg:1.3,
   moves:[{m:'beam',n:3,f:3},{m:'bolts',n:2,f:3,cnt:7,spread:1.5,sp:120},{m:'rain',n:2,f:2,cnt:7},
          {m:'teleport',n:3,f:1,reach:44},{m:'pillars',n:1,f:2,cnt:5},{m:'bolts',n:1,f:2,cnt:3,spread:2,sp:110,hom:220,ph:2}]},

  {id:'king', name:'ملك الرماد', draw:dKing, evade:'tp',
   talk:[['b', 'وصلتَ أخيراً. كل من هزمتهم كانوا ظلالي.'], ['h', 'وأنت آخر ظل.'], ['b', 'أنا النار التي أحرقت هذا العالم... وستحترق معه!']],
   room:'throne', elem:'fire', pitch:0.75, phases:4,
   hp:2600, hw:12, h:72, spd:44, dmg:2.0,
   moves:[{m:'slam',n:6,f:0,reach:62,twice:true,waves:true},{m:'charge',n:2,f:3,sp:270},
          {m:'pillars',n:1.5,f:3,cnt:5},{m:'bolts',n:1,f:3,cnt:5,spread:0.8,sp:160,burst:2},
          {m:'leap',n:1,f:3,waves:true},{m:'teleport',n:2,f:2,reach:60,ph:2},{m:'beam',n:1,f:2,ph:3},{m:'rain',n:1,f:2,cnt:8,ph:2},{m:'spin',n:2,f:1,ph:3,dur:1.6},{m:'breath',n:2,f:2,ph:4,range:130},{m:'summon',n:1.2,f:1.5,ph:2}]}
];

})(window.G);
