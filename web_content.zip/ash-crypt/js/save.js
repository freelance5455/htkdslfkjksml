/* ================== save.js — الحفظ المحلي والتقدّم والعملات ================== */
(function(G){
'use strict';
const CFG=G.CFG;

// unlocked = رقم آخر فصل مفتوح · stage = عدد المراحل المنجزة في هذا الفصل (0..7)
// coins = الذهب · crystals = الكريستال · plv = مستوى الشخصية
// own = الأسلحة المملوكة · wlv = مستوى كل سلاح
// char = الشخصية المختارة · chars = الشخصيات المملوكة · met = الزعماء الذين جرى الحوار معهم
G.save={wins:0,deaths:0,wpn:0,gender:'m',unlocked:0,stage:0,done:false,best:{},mute:false,
        coins:0,crystals:0,plv:1,own:{sword:1},wlv:{},char:'',chars:{},met:{}};

/* ---------- الشخصيات العشر: لكل واحدة سلاحها الخاص وميزة دائمة ومهارة (زر المهارة) ----------
   wpn=سلاحها (id من weapons.js) · price=الثمن بالذهب · cd=انتظار المهارة بالثواني
   hp=مضاعف الصحة · spd=مضاعف السرعة                                                        */
G.CHARS=[
  {id:'knight', name:'الفارس',       wpn:'sword',  price:0,    cd:8,  hp:1,    spd:1,
   trait:'درع متين: يتلقى ضرراً أقل 15%', skill:'الصدّ', sdesc:'يصدّ كل الضربات ويردّها'},
  {id:'lady',   name:'الفارسة',      wpn:'dual',   price:0,    cd:6,  hp:1,    spd:1.08,
   trait:'رشيقة: أسرع، وضرباتها الحرجة أكثر', skill:'اندفاعة البرق', sdesc:'تخترق الأعداء بسرعة خاطفة'},
  {id:'ranger', name:'الصيّادة',      wpn:'bow',    price:900,  cd:6,  hp:1,    spd:1.04,
   trait:'عين الصقر: سهامها أقوى 30%', skill:'القفزة الخلفية', sdesc:'تقفز للخلف وتطلق 3 سهام'},
  {id:'lancer', name:'الرمّاح',       wpn:'spear',  price:1200, cd:7,  hp:1,    spd:1.05,
   trait:'ذراع طويلة: مدى رمحه أبعد', skill:'الوثبة', sdesc:'يثب للأمام ويطعن كل من في طريقه'},
  {id:'mage',   name:'الساحرة',      wpn:'staff',  price:1600, cd:9,  hp:0.9,  spd:1,
   trait:'طاقة متدفقة: الشريط الخاص يمتلئ أسرع 35%', skill:'انفجار اللهب', sdesc:'يحرق كل من حولها'},
  {id:'ninja',  name:'النينجا',      wpn:'ninja',  price:2000, cd:6,  hp:0.95, spd:1.1,
   trait:'خفيف: قفزة ثانية في الهواء ومراوغة أسرع', skill:'الوميض', sdesc:'يعبر الأعداء كالظل ويشلّهم'},
  {id:'berserk',name:'البربري',      wpn:'axe',    price:2500, cd:14, hp:1.1,  spd:1,
   trait:'غضب الدم: كلما قلّت صحته زاد ضرره (حتى +45%)', skill:'الهيجان', sdesc:'5 ثوانٍ: هجوم أسرع وامتصاص صحة'},
  {id:'warden', name:'السجّان',       wpn:'chain',  price:2800, cd:9,  hp:1.15, spd:0.97,
   trait:'قبضة حديدية: ضرباته قد تشلّ الوحوش', skill:'السحب', sdesc:'يجرّ كل الأعداء القريبين إليه'},
  {id:'smith',  name:'حامل المطرقة', wpn:'hammer', price:3000, cd:10, hp:1.2,  spd:0.93,
   trait:'راسخ: لا يترنّح ولا يُدفع عند الإصابة', skill:'دكّ الأرض', sdesc:'موجة تضرب وتشلّ من حوله'},
  {id:'reaper', name:'حاصد الأرواح', wpn:'scythe', price:3500, cd:10, hp:0.95, spd:1,
   trait:'ظمأ: كل ضربة تعيد له قليلاً من الصحة', skill:'أرواح هائمة', sdesc:'3 أرواح تلاحق الأعداء وتشفيه'}
];
try{
  let s=JSON.parse(localStorage.getItem('ashcrypt_save3'));
  if(!s){
    // ترحيل التقدّم من النسخة السابقة
    const o=JSON.parse(localStorage.getItem('ashcrypt_save2'));
    if(o)s={wins:o.wins,deaths:o.deaths,gender:o.gender,unlocked:o.unlocked,done:o.done,best:o.best,mute:o.mute};
  }
  if(s)G.save=Object.assign(G.save,s);
}catch(e){}
(function fix(){
  const s=G.save;
  if(s.gender!=='f')s.gender='m';
  if(!s.best)s.best={};
  if(!s.own)s.own={}; s.own.sword=1;
  if(!s.wlv)s.wlv={};
  if(!s.chars)s.chars={}; s.chars.knight=1; s.chars.lady=1;
  if(!s.met)s.met={};
  if(!s.char||!s.chars[s.char])s.char=s.gender==='f'?'lady':'knight';
  s.coins=Math.max(0,s.coins|0); s.crystals=Math.max(0,s.crystals|0);
  s.plv=G.clamp(s.plv|0,1,CFG.maxLevel);
  s.stage=G.clamp(s.stage|0,0,CFG.stages);
  s.unlocked=Math.max(0,s.unlocked|0);
})();

G.doSave=function(){
  try{localStorage.setItem('ashcrypt_save3',JSON.stringify(G.save));}catch(e){}
};

/* ---------- الشخصية ---------- */
G.level=()=>G.save.plv;
G.tier=()=>Math.min(4,Math.floor(G.save.plv/5));          // الشكل يتغير كل 5 مستويات
G.char=()=>G.CHARS.find(c=>c.id===G.save.char)||G.CHARS[0];
G.maxHp=()=>Math.round((CFG.playerHp+(G.save.plv-1)*CFG.hpPerLevel)*G.char().hp);
G.dmgMul=function(){
  let m=1+(G.save.plv-1)*CFG.dmgPerLevel;
  const P=G.P;
  if(P&&G.save.char==='berserk')m*=1+0.45*(1-Math.max(0,P.hp)/G.maxHp());   // غضب الدم
  return m;
};
G.critChance=()=>CFG.critChance+(G.save.char==='lady'?0.10:0);
G.enMul=()=>G.save.char==='mage'?1.35:1;
G.rangedMul=()=>G.save.char==='ranger'?1.3:1;
G.reachBonus=()=>G.save.char==='lancer'?7:0;
G.maxFlasks=()=>CFG.flasks+(G.tier()>=1?1:0)+(G.tier()>=3?1:0);
G.lvCost=()=>Math.round(60*Math.pow(G.save.plv,1.4)/10)*10;  // ثمن ترقية الشخصية بالذهب

/* ---------- الأسلحة ---------- */
G.wlvOf=id=>G.save.wlv[id]||1;
G.wpnMul=id=>1+(G.wlvOf(id)-1)*CFG.wpnUpDmg;
// السلاح مملوك إذا كانت شخصيته مملوكة
G.owns=id=>G.CHARS.some(c=>c.wpn===id&&G.save.chars[c.id]);

/* ---------- العملات ---------- */
G.addCoins=function(n){G.save.coins=Math.max(0,G.save.coins+Math.round(n));if(G.updWallet)G.updWallet();};
G.addCrystals=function(n){G.save.crystals=Math.max(0,G.save.crystals+Math.round(n));if(G.updWallet)G.updWallet();};

})(window.G);
