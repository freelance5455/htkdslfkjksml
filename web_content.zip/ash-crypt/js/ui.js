/* ================== ui.js — القائمة الرئيسية وبدء المراحل ورسائل الفوز والخسارة ================== */
(function(G){
'use strict';
const $=G.$, S=G.S, CFG=G.CFG, NS=CFG.stages;
const stage=$('stage'), menu=$('menu'), msg=$('msg'), bossName=$('bossName'), grid=$('bossGrid'), nodes=$('nodes');
const dlg=$('dlg');
const pvC=$('pvC'), heroPv=$('heroPv');

/* ---------- ما المفتوح؟ ---------- */
// الفصل c مفتوح إذا وصل إليه اللاعب · المرحلة n (0..6) أو الزعيم (7) مفتوحة إذا أنهى ما قبلها
function chapterOpen(c){return c<=G.save.unlocked;}
function nodeOpen(c,n){
  if(c<G.save.unlocked)return true;
  if(c>G.save.unlocked)return false;
  return n<=G.save.stage;
}
function nodeDone(c,n){
  if(n===NS)return G.save.best[c]!=null;
  return c<G.save.unlocked||(c===G.save.unlocked&&n<G.save.stage);
}

/* ---------- صور الأبطال والزعماء في القائمة ---------- */
// صورة الزعيم من صورته الحقيقية (أول إطار وقوف)، وإن لم تُحمَّل بعد يُرسم بالكود
function drawPortrait(cv,i){
  const d=G.BOSSES[i], sp=G.BOSS_SPRITES&&G.BOSS_SPRITES[d.id];
  if(sp&&sp.ok){
    const fr=sp.anims.idle[0];
    cv.width=sp.cw; cv.height=sp.ch;
    const g=cv.getContext('2d'); g.imageSmoothingEnabled=false; g.clearRect(0,0,sp.cw,sp.ch);
    g.drawImage(sp.img,fr[1]*sp.cw,fr[0]*sp.ch,sp.cw,sp.ch,0,0,sp.cw,sp.ch);
    cv._ok=true;
  }else G.drawBossPortrait(cv,i);
}
// البطل يتنفس في مكانه من صورته (القدمان عند أسفل منتصف اللوحة)
function drawHeroPv(cv,id){
  const g=cv.getContext('2d'), W=cv.width, H=cv.height, sp=G.SPRITES[id];
  g.setTransform(1,0,0,1,0,0); g.clearRect(0,0,W,H); g.imageSmoothingEnabled=false;
  if(sp&&sp.ok){
    const A=sp.anims.idle, fr=A[Math.floor(S.time*6)%A.length];
    g.drawImage(sp.img,fr[1]*sp.cw,fr[0]*sp.ch,sp.cw,sp.ch,Math.round(W/2-sp.cw/2+(fr[2]||0)),H-sp.ch,sp.cw,sp.ch);
  }else{
    G.setCtx(g); g.translate(W/2,H-2);
    const C=G.CHARS.find(c=>c.id===id), wi=G.WEAPONS.findIndex(w=>w.id===C.wpn);
    G.drawHero({ch:id,tier:G.tier(),state:'idle',t:0,ground:true,vx:0,f:1,w:wi,aw:wi,sp:{},en:0,guard:0,rage:0});
    G.setCtx(null);
  }
}

/* ---------- التنقل بين شاشات القائمة ---------- */
let scr='title';
function goScr(name){
  scr=name;
  ['Title','Chapters','Heroes'].forEach(n=>{$('scr'+n).style.display=(n.toLowerCase()===name)?(n==='Title'?'block':'flex'):'none';});
  if(name==='heroes')S.viewChar=Math.max(0,G.CHARS.findIndex(c=>c.id===G.save.char));
  refresh();
}
G.menuScreen=goScr;

/* ---------- بناء شبكة الفصول ---------- */
function buildGrid(){
  grid.innerHTML='';
  G.BOSSES.forEach((d,i)=>{
    const el=document.createElement('div');
    el.className='btile'; el.setAttribute('data-i',i);
    el.innerHTML='<canvas class="pt"></canvas><canvas class="mark"></canvas><span></span>';
    grid.appendChild(el);
    drawPortrait(el.querySelector('.pt'),i);
    el.addEventListener('click',()=>{
      if(!chapterOpen(i)){G.snd('deny');return;}
      G.initAudio(); G.snd('select');
      S.boss=i; S.node=i===G.save.unlocked?Math.min(G.save.stage,NS):0;
      G.room=G.buildRoom(d.room);
      refresh();
    });
  });
}
function buildNodes(){
  let h='';
  for(let n=0;n<=NS;n++){
    h+='<div class="node'+(n===NS?' boss':'')+'" data-n="'+n+'">'+(n===NS?'<canvas class="ic" data-ic="skull"></canvas>':(n+1))+
       (n===2?'<i>لغز</i>':(n===4?'<i>لغز</i>':''))+'</div>';
  }
  nodes.innerHTML=h;
  G.drawAllIcons(nodes);
  nodes.querySelectorAll('.node').forEach(el=>el.addEventListener('click',()=>{
    const n=+el.getAttribute('data-n');
    if(!nodeOpen(S.boss,n)){G.snd('deny');return;}
    G.initAudio(); G.snd('select');
    S.node=n; refresh();
  }));
}

/* ---------- تحديث القائمة ---------- */
function refresh(){
  refreshChar();
  let beaten=0;
  grid.querySelectorAll('.btile').forEach(el=>{
    const i=+el.getAttribute('data-i'), lock=!chapterOpen(i), done=G.save.best[i]!=null;
    if(done)beaten++;
    el.classList.toggle('lock',lock);
    el.classList.toggle('sel',i===S.boss);
    el.querySelector('span').textContent=lock?'؟؟؟':(i+1)+'. '+G.BOSSES[i].name;
    const mk=el.querySelector('.mark');
    mk.style.display=(lock||done)?'block':'none';
    if(lock)G.drawIcon(mk,'lock'); else if(done)G.drawIcon(mk,'check');
  });
  nodes.querySelectorAll('.node').forEach(el=>{
    const n=+el.getAttribute('data-n');
    el.classList.toggle('lock',!nodeOpen(S.boss,n));
    el.classList.toggle('done',nodeDone(S.boss,n));
    el.classList.toggle('sel',n===S.node);
  });
  $('bossTitle').textContent='الفصل '+(S.boss+1)+': '+G.BOSSES[S.boss].name+' · 7 مراحل ثم الزعيم';
  const w=G.WEAPONS[G.save.wpn];
  $('stats').innerHTML='المستوى '+G.save.plv+' ('+G.TIER_NAMES[G.tier()]+') · الصحة '+G.maxHp()+' · '+w.name+' م'+G.wlvOf(w.id);
  const num=(c,n)=>'\u2066'+c+'-'+n+'\u2069';          // الرقم يبقى بترتيبه (الفصل-المرحلة) داخل النص العربي
  const lbl=S.node===NS?'قاتل '+G.BOSSES[S.boss].name:'ابدأ '+num(S.boss+1,S.node+1);
  $('mStart').querySelector('span').textContent=lbl;
  $('mGo').querySelector('span').textContent=S.node===NS?'قاتل الزعيم':'ابدأ '+num(S.boss+1,S.node+1);
  let own=0; for(const C of G.CHARS)if(G.save.chars[C.id])own++;
  $('heroCount').textContent=own+' / '+G.CHARS.length;
  G.drawIcon($('icSound'),G.save.mute?'mute':'sound');
  G.updWallet();
}
G.refreshMenu=refresh;

/* ---------- بطاقة الشخصية في القائمة ---------- */
function refreshChar(){
  const C=G.CHARS[S.viewChar], own=!!G.save.chars[C.id];
  $('scrHeroes').classList.toggle('locked',!own);
  $('chName').textContent=C.name+(own?'':' 🔒');
  const W0=G.WEAPONS.find(w=>w.id===C.wpn);
  $('chWpn').textContent='السلاح: '+W0.name;
  $('chTrait').textContent='الميزة: '+C.trait;
  $('chSkill').textContent='المهارة: '+C.skill+' — '+C.sdesc;
  $('stats').style.display=own&&G.save.char===C.id?'block':'none';
  const b=$('chBuy');
  b.style.display=own?'none':'flex';
  $('chSel').textContent=own?'✓ البطل المختار':'';
  if(!own){
    b.innerHTML='<canvas class="ic" data-ic="coin"></canvas><span>اشترِ '+C.price+'</span>';
    b.classList.toggle('no',G.save.coins<C.price);
    G.drawAllIcons(b);
  }
}
function viewChar(step){
  const n=G.CHARS.length;
  S.viewChar=(S.viewChar+step+n)%n;
  const C=G.CHARS[S.viewChar];
  if(G.save.chars[C.id]){G.save.char=C.id;G.syncWeapon();G.doSave();}     // المملوكة تُختار مباشرة (وسلاحها معها)
  G.snd('select'); refresh();
}
// تُستدعى كل إطار والقائمة ظاهرة: البطل يتنفس، وصور الزعماء تُرسم حين تُحمَّل
G.drawPreviews=function(){
  if(scr==='title')drawHeroPv(heroPv,G.save.char);
  else if(scr==='heroes')drawHeroPv(pvC,G.CHARS[S.viewChar].id);
  else if(scr==='chapters')grid.querySelectorAll('canvas.pt').forEach((cv,i)=>{if(!cv._ok)drawPortrait(cv,i);});
};

G.showMenu=function(){
  S.game='menu';
  stage.classList.remove('playing');
  msg.style.display='none'; bossName.style.display='none';
  menu.style.display='flex'; dlg.style.display='none';
  G.clearAll(); G.L=null; G.cam.x=0;
  S.viewChar=Math.max(0,G.CHARS.findIndex(c=>c.id===G.save.char));
  if(S.boss>G.save.unlocked)S.boss=G.save.unlocked;
  if(!nodeOpen(S.boss,S.node))S.node=S.boss===G.save.unlocked?Math.min(G.save.stage,NS):0;
  G.room=G.buildRoom(G.BOSSES[S.boss].room);
  G.doSave();
  goScr('title');
};

/* ---------- محاولة ملء الشاشة وقفل الاتجاه الأفقي ---------- */
function lockLandscape(){
  try{
    const o=screen.orientation;
    if(o&&o.lock){const pr=o.lock('landscape');if(pr&&pr.catch)pr.catch(()=>{});}
  }catch(e){}
  setTimeout(G.resize,300); setTimeout(G.resize,900);
}
function goLandscape(){
  try{
    const el=document.documentElement;
    const fs=el.requestFullscreen||el.webkitRequestFullscreen;
    if(fs&&!document.fullscreenElement&&!document.webkitFullscreenElement){
      const pr=fs.call(el);
      if(pr&&pr.then)pr.then(lockLandscape).catch(()=>{});
      else lockLandscape();
    }else lockLandscape();
  }catch(e){}
}

/* ---------- بدء مرحلة أو قتال زعيم ---------- */
G.startNode=function(c,n){
  if(c!=null)S.boss=c;
  if(n!=null)S.node=n;
  G.initAudio();
  goLandscape();
  const d=G.BOSSES[S.boss];
  if(!G.room||G.room.id!==d.room)G.room=G.buildRoom(d.room);
  S.adRevived=false; S.doubled=false;
  if(S.node>=NS){
    S.mode='boss';
    G.reset();
    bossName.textContent=d.name; bossName.style.display='none';
  }else{
    S.mode='stage';
    G.resetStage(S.boss,S.node);
    bossName.textContent='المرحلة \u2066'+(S.boss+1)+'-'+(S.node+1)+'\u2069'+(G.L.hint?' · '+G.L.hint:'');
    bossName.style.display='block';
  }
  menu.style.display='none'; msg.style.display='none'; dlg.style.display='none';
  G.setAtkIcon();
  for(const k in G.buf)G.buf[k]=0;
  // أول لقاء مع الزعيم: حوار قصير قبل القتال
  if(S.mode==='boss'&&d.talk&&!G.save.met[S.boss]){
    S.game='talk'; talkI=0;
    G.B.t=0.05;                       // يظهر الزعيم كاملاً أثناء الحوار
    stage.classList.remove('playing');
    showLine();
  }else{
    S.game='play';
    stage.classList.add('playing');
  }
};

/* ---------- حوار الزعيم ---------- */
let talkI=0;
function showLine(){
  const d=G.BOSSES[S.boss], ln=d.talk[talkI], boss=ln[0]==='b';
  $('dlgBox').classList.toggle('boss',boss);
  $('dlgWho').textContent=boss?d.name:G.char().name;
  $('dlgTxt').textContent=ln[1];
  dlg.style.display='flex';
  if(boss)G.roar(0.35,d.id); else G.snd('select');
  if(boss)S.shake=3;
}
G.talkNext=function(){
  if(S.game!=='talk')return;
  talkI++;
  if(talkI<G.BOSSES[S.boss].talk.length){showLine();return;}
  dlg.style.display='none';
  G.save.met[S.boss]=1; G.doSave();
  S.game='play';
  stage.classList.add('playing');
};
dlg.addEventListener('click',()=>{G.initAudio();G.talkNext();});
G.startFight=function(i){G.startNode(i,NS);};      // قتال الزعيم مباشرة

function showMsg(html,delay){
  msg.innerHTML=html; msg.style.display='flex';
  G.drawAllIcons(msg);
  S.msgAt=performance.now()+(delay||0);
  stage.classList.remove('playing');
}
function btn(act,icon,label){
  return '<div class="mbtn" data-act="'+act+'"><canvas class="ic" data-ic="'+icon+'"></canvas><span>'+label+'</span></div>';
}
function ci(name){return '<canvas class="ic" data-ic="'+name+'" style="width:5vmin;height:5vmin;display:inline-block;vertical-align:middle"></canvas>';}

/* ---------- إنهاء مرحلة مغامرة ---------- */
let lastBonus=0;
G.stageClear=function(){
  const c=S.boss, n=S.node;
  S.game='win';
  const first=c===G.save.unlocked&&n===G.save.stage;
  if(first)G.save.stage=Math.min(NS,G.save.stage+1);
  const bonus=Math.round((20+G.L.diff*4)*(first?1:0.4));
  lastBonus=bonus;
  G.addCoins(bonus);
  G.doSave();
  G.snd('portal'); G.snd('win');
  bossName.style.display='none';
  const nextBoss=n+1>=NS;
  showMsg('<h1>اكتملت المرحلة \u2066'+(c+1)+'-'+(n+1)+'\u2069</h1>'+
    '<p class="gain">'+ci('coin')+' '+S.gotCoins+' + مكافأة '+bonus+(S.gotCrys?' · '+ci('crystal')+' '+S.gotCrys:'')+'</p>'+
    '<p class="small">الوقت: '+G.fmt(S.elapsed)+'</p>'+
    '<div class="row">'+btn('next','next',nextBoss?'إلى الزعيم':'المرحلة التالية')+
      btn('double','ad','ضاعف الذهب')+btn('shop','shop','المتجر')+btn('retry','retry','إعادة')+btn('menu','home','القائمة')+'</div>',700);
};

/* ---------- الفوز على الزعيم ---------- */
G.win=function(){
  const i=S.boss, d=G.BOSSES[i], last=i===G.BOSSES.length-1;
  S.game='win';
  G.save.wins++;
  const first=G.save.best[i]==null;
  if(first||S.elapsed<G.save.best[i])G.save.best[i]=S.elapsed;
  // الغنيمة: ذهب دائماً، وكريستال عند أول فوز
  const coins=Math.round((150+i*60)*(first?1:0.3)), crys=first?3+Math.floor(i/2):0;
  lastBonus=coins;
  G.addCoins(coins); G.addCrystals(crys);
  if(first){
    if(!last&&i===G.save.unlocked){G.save.unlocked++;G.save.stage=0;}
    if(last)G.save.done=true;
  }
  G.doSave();
  G.snd('win');
  bossName.style.display='none';
  showMsg('<h1>'+(last?'انتصرت على الضريح!':'سقط '+d.name)+'</h1>'+
    '<p>الوقت: '+G.fmt(S.elapsed)+' · أفضل وقت: '+G.fmt(G.save.best[i])+'</p>'+
    '<p class="gain">غنيمة: '+ci('coin')+' '+coins+(crys?' · '+ci('crystal')+' '+crys:'')+
      (first&&!last?' · فُتح الفصل التالي: '+G.BOSSES[i+1].name:'')+'</p>'+
    '<div class="row">'+(last?'':btn('next','next','الفصل التالي'))+btn('double','ad','ضاعف الذهب')+
      btn('shop','shop','المتجر')+btn('retry','retry','إعادة')+btn('menu','home','القائمة')+'</div>',700);
};

/* ---------- الخسارة: إحياء بالكريستال أو بإعلان ---------- */
G.lose=function(){
  S.game='dead';
  G.doSave();
  bossName.style.display='none';
  const where=S.mode==='boss'?G.BOSSES[S.boss].name:'المرحلة \u2066'+(S.boss+1)+'-'+(S.node+1)+'\u2069';
  const can=G.save.crystals>=CFG.reviveCost;
  showMsg('<h1>هلكتَ</h1><p class="small">'+where+' · عدد مرات السقوط: '+G.save.deaths+'</p>'+
    '<div class="row">'+
      '<div class="mbtn'+(can?'':' off')+'" data-act="revive"><canvas class="ic" data-ic="heart"></canvas><span>إحياء '+CFG.reviveCost+'</span><canvas class="ic" data-ic="crystal"></canvas></div>'+
      (S.adRevived?'':btn('adrevive','ad','إحياء بإعلان'))+
      btn('retry','retry','من البداية')+btn('menu','home','القائمة')+'</div>',500);
};
function revive(){
  const P=G.P;
  P.hp=G.maxHp(); P.lag=P.hp; P.state='idle'; P.inv=2.5; P.vx=P.vy=0; P.en=CFG.energyMax;
  if(G.L){P.x=G.L.safeX;}
  P.y=G.GY; P.ground=true;
  G.clearHazards();
  S.game='play'; S.flash=0.4;
  msg.style.display='none';
  bossName.style.display='block';
  stage.classList.add('playing');
  G.ring(P.x,P.y-12,50,'#7fd4ff',0.6);
  G.snd('levelup');
}

/* ---------- الأحداث ---------- */
msg.addEventListener('click',ev=>{
  if(performance.now()<S.msgAt)return;
  const el=ev.target.closest?ev.target.closest('[data-act]'):null;
  if(!el||el.classList.contains('off')){if(el)G.snd('deny');return;}
  const a=el.getAttribute('data-act');
  G.snd('click');
  if(a==='retry')G.startNode(S.boss,S.node);
  else if(a==='next'){
    if(S.node<NS)G.startNode(S.boss,S.node+1);
    else G.startNode(Math.min(S.boss+1,G.save.unlocked),0);
  }
  else if(a==='revive'){
    if(G.save.crystals>=CFG.reviveCost){G.addCrystals(-CFG.reviveCost);G.doSave();revive();}
  }
  else if(a==='adrevive')G.showAd(ok=>{if(ok){S.adRevived=true;revive();}});
  else if(a==='double'){
    if(S.doubled)return;
    G.showAd(ok=>{
      if(!ok)return;
      S.doubled=true;
      G.addCoins(S.gotCoins+lastBonus); G.doSave(); G.snd('buy');
      el.classList.add('off'); el.querySelector('span').textContent='تمت المضاعفة';
    });
  }
  else if(a==='shop')G.openShop();
  else G.showMenu();
});
$('chPrev').addEventListener('click',()=>{G.initAudio();viewChar(-1);});
$('chNext').addEventListener('click',()=>{G.initAudio();viewChar(1);});
$('chBuy').addEventListener('click',()=>{
  const C=G.CHARS[S.viewChar];
  G.initAudio();
  if(G.save.chars[C.id])return;
  if(G.save.coins<C.price){G.snd('deny');return;}
  G.addCoins(-C.price); G.save.chars[C.id]=1; G.save.char=C.id; G.syncWeapon(); G.doSave();
  G.snd('levelup'); refresh();
});
$('mStart').addEventListener('click',()=>{G.initAudio();G.snd('click');G.startNode(S.boss,S.node);});
$('mGo').addEventListener('click',()=>{G.initAudio();G.snd('click');G.startNode(S.boss,S.node);});
$('mChapters').addEventListener('click',()=>{G.initAudio();G.snd('click');goScr('chapters');});
$('mHeroes').addEventListener('click',()=>{G.initAudio();G.snd('click');goScr('heroes');});
document.querySelectorAll('#menu .back').forEach(el=>el.addEventListener('click',()=>{G.snd('click');goScr('title');}));
$('mShop').addEventListener('click',()=>{G.initAudio();G.snd('click');G.openShop();});
$('mSound').addEventListener('click',()=>{G.initAudio();G.setMute(!G.save.mute);G.snd('click');refresh();});

G.initUI=function(){
  G.syncWeapon();
  G.drawAllIcons();
  buildGrid(); buildNodes();
  S.boss=Math.min(G.save.unlocked,G.BOSSES.length-1);
  S.node=Math.min(G.save.stage,NS);
  G.showMenu();
};

})(window.G);
