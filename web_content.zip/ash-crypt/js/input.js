/* ================== input.js — التحكم باللمس ولوحة المفاتيح ================== */
(function(G){
'use strict';
const $=G.$, S=G.S, buf=G.buf, keys=G.keys, kb=G.kb;
G.rot=false;   // هل الشاشة مُدارة برمجياً؟ (تُحدَّث في main.js)

function bindBtn(id,fn){
  const e=$(id);
  e.addEventListener('pointerdown',ev=>{ev.preventDefault();e.classList.add('on');fn();});
  ['pointerup','pointercancel','pointerleave'].forEach(n=>e.addEventListener(n,()=>e.classList.remove('on')));
}
bindBtn('bAtk',()=>{buf.atk=0.15;});
bindBtn('bJump',()=>{buf.jump=0.15;});
bindBtn('bDodge',()=>{buf.dodge=0.15;});
bindBtn('bHeal',()=>{buf.heal=0.15;});
bindBtn('bSp',()=>{buf.sp=0.15;});
bindBtn('bSkill',()=>{buf.skill=0.15;});
bindBtn('bWpn',()=>G.switchWeapon());
bindBtn('bHome',()=>{G.snd('click');G.showMenu();});

/* ---------- أسهم الحركة ---------- */
const pad=$('pad'), padL=$('padL'), padR=$('padR');
let padId=null;
function padSet(ev){
  const b=pad.getBoundingClientRect();
  // عند تدوير الشاشة برمجياً يصبح محور اليمين/اليسار هو المحور العمودي للجوال
  const left=G.rot?(ev.clientY<b.top+b.height/2):(ev.clientX<b.left+b.width/2);
  keys.l=left; keys.r=!left;
  padL.classList.toggle('on',left); padR.classList.toggle('on',!left);
}
function padOff(ev){
  if(padId!==null&&ev.pointerId!==padId)return;
  padId=null; keys.l=keys.r=false;
  padL.classList.remove('on'); padR.classList.remove('on');
}
pad.addEventListener('pointerdown',ev=>{
  ev.preventDefault(); padId=ev.pointerId;
  try{pad.setPointerCapture(ev.pointerId);}catch(e){}
  padSet(ev);
});
pad.addEventListener('pointermove',ev=>{if(ev.pointerId===padId)padSet(ev);});
pad.addEventListener('pointerup',padOff);
pad.addEventListener('pointercancel',padOff);

/* ---------- لوحة المفاتيح (للتجربة على الكمبيوتر) ---------- */
window.addEventListener('keydown',e=>{
  const c=e.code;
  if(c==='ArrowLeft'||c==='KeyA')kb.l=true;
  else if(c==='ArrowRight'||c==='KeyD')kb.r=true;
  else if(c==='Space'||c==='ArrowUp'||c==='KeyW')buf.jump=0.15;
  else if(c==='KeyJ'||c==='KeyX')buf.atk=0.15;
  else if(c==='KeyK'||c==='ShiftLeft'||c==='KeyC')buf.dodge=0.15;
  else if(c==='KeyH'||c==='KeyE')buf.heal=0.15;
  else if(c==='KeyL'||c==='KeyF')buf.sp=0.15;
  else if(c==='KeyU'||c==='KeyR')buf.skill=0.15;
  else if(c==='KeyQ'||c==='Tab'){e.preventDefault();if(!e.repeat)G.switchWeapon();}
  else if(c==='Escape'&&S.game!=='menu')G.showMenu();
  else if(c==='Enter'&&S.game==='talk')G.talkNext();
  else if(c==='Enter'&&S.game!=='play'&&performance.now()>=S.msgAt)G.startNode(S.boss,S.node);
});
window.addEventListener('keyup',e=>{
  const c=e.code;
  if(c==='ArrowLeft'||c==='KeyA')kb.l=false;
  else if(c==='ArrowRight'||c==='KeyD')kb.r=false;
});
window.addEventListener('contextmenu',e=>e.preventDefault());
window.addEventListener('blur',()=>{keys.l=keys.r=kb.l=kb.r=false;});

})(window.G);
