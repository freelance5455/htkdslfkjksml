/* ================== audio.js — الأصوات والموسيقى ==================
   طريقتان معاً:
   1) ملفات صوت حقيقية في مجلد snd (اختيارية): ضع الملف بالاسم المكتوب في SOUND_FILES فيُستعمل تلقائياً.
      يمكن وضع نسختين أو ثلاث لنفس الصوت (hit.mp3 و hit_2.mp3 و hit_3.mp3) فتُختار عشوائياً.
   2) إن لم يوجد الملف يُستعمل الصوت المولّد برمجياً (مع صدى خفيف كأنه داخل ضريح).
   الموسيقى: music_menu · music_stage · music_boss · music_final (تتكرر تلقائياً).      */
(function(G){
'use strict';
let AC=null, master=null, out=null;
const DIR='snd/';
// الأصوات التي يمكن استبدالها بملفات (الاسم = اسم الملف بدون .mp3)
const SOUND_FILES=['hit','heavy','crit','hurt','die','slam','clang','step','jump','land','dodge',
  'sw_sword','sw_dual','sw_axe','sw_spear','sw_scythe','sw_chain','sw_bow','sw_ninja','sw_staff','sw_hammer','arrow',
  'coin','crystal','chest','levelup','win','bossdie','click','select','buy',
  'roar_warden','roar_knight','roar_spider','roar_lich','roar_golem','roar_vampire','roar_wolf','roar_reaper','roar_dragon','roar_eye','roar_king'];
const MUSIC={menu:'music_menu',stage:'music_stage',boss:'music_boss',final:'music_final'};
const VOL={sfx:0.9,music:0.38};

G.initAudio=function(){
  if(!AC){
    try{
      const A=window.AudioContext||window.webkitAudioContext;
      if(A){
        AC=new A(); master=AC.createGain();
        master.gain.value=G.save.mute?0:1; master.connect(AC.destination);
        // مسار الأصوات المولّدة: مباشر + صدى خفيف (كأنه داخل ضريح حجري)
        out=AC.createGain(); out.gain.value=1; out.connect(master);
        try{
          const rv=AC.createConvolver(), len=(AC.sampleRate*1.6)|0, ib=AC.createBuffer(2,len,AC.sampleRate);
          for(let c=0;c<2;c++){const d=ib.getChannelData(c);for(let i=0;i<len;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/len,3.2);}
          rv.buffer=ib;
          const wet=AC.createGain(); wet.gain.value=0.22;
          out.connect(rv); rv.connect(wet); wet.connect(master);
        }catch(e){}
        loadFiles();
      }
    }catch(e){AC=null;}
  }
  if(AC&&AC.state==='suspended'){try{AC.resume();}catch(e){}}
};
G.setMute=function(m){
  G.save.mute=m; G.doSave();
  if(master)master.gain.value=m?0:1;
  for(const k in tracks)tracks[k].muted=m;
};

/* ---------- ملفات الصوت الحقيقية (اختيارية) ---------- */
const BUF={};          // اسم الصوت ← قائمة نسخه المحمّلة
function addBuf(name,item){(BUF[name]=BUF[name]||[]).push(item);}
function loadOne(name,file){
  // محاولة 1: تحميل سريع بلا تأخير (يعمل حين تُفتح اللعبة من خادم أو تطبيق)
  try{
    fetch(DIR+file).then(r=>{if(!r.ok)throw 0;return r.arrayBuffer();})
      .then(ab=>new Promise((ok,no)=>AC.decodeAudioData(ab,ok,no)))
      .then(buf=>addBuf(name,{buf}))
      .catch(()=>viaTag(name,file));
  }catch(e){viaTag(name,file);}
}
// محاولة 2: عنصر صوت عادي (يعمل حتى عند فتح الملف مباشرة من الجهاز)
function viaTag(name,file){
  try{
    const a=new Audio(); a.preload='auto';
    a.addEventListener('canplaythrough',function f(){a.removeEventListener('canplaythrough',f);addBuf(name,{tag:a});},{once:true});
    a.src=DIR+file;
  }catch(e){}
}
function loadFiles(){
  for(const n of SOUND_FILES)for(const v of ['','_2','_3'])loadOne(n,n+v+'.mp3');
}
// يشغّل ملف الصوت إن وُجد؛ يرجع false إن لم يوجد
function playFile(name,vol){
  const L=BUF[name]; if(!L||!L.length||!AC)return false;
  const it=L[(Math.random()*L.length)|0];
  try{
    if(it.buf){
      const s=AC.createBufferSource(), g=AC.createGain();
      s.buffer=it.buf; s.playbackRate.value=0.95+Math.random()*0.1;      // اختلاف بسيط كل مرة
      g.gain.value=(vol||1)*VOL.sfx; s.connect(g); g.connect(master); s.start();
    }else{
      if(G.save.mute)return true;
      const a=it.tag.cloneNode(); a.volume=Math.min(1,(vol||1)*VOL.sfx); a.play().catch(()=>{});
    }
  }catch(e){}
  return true;
}

// للفحص: أي ملفات الصوت والموسيقى وُجدت (اكتب G.soundReport() في وحدة التحكم)
G.soundReport=function(){
  const r={sfx:Object.keys(BUF).map(k=>k+'×'+BUF[k].length),music:{}};
  for(const k in tracks)r.music[k]=tracks[k]?(tracks[k].paused?'جاهزة':'تعمل'):'غير موجودة';
  return r;
};

/* ---------- الموسيقى من ملفات: لكل جو مقطوعة، مع انتقال ناعم ---------- */
const tracks={}; let mood='', musicOn=false;
function track(m){
  if(tracks[m]!==undefined)return tracks[m];
  tracks[m]=null;
  try{
    const a=new Audio(); a.loop=true; a.preload='auto'; a.volume=0; a.muted=!!G.save.mute;
    a.addEventListener('canplaythrough',()=>{tracks[m]=a;},{once:true});
    a.addEventListener('error',()=>{tracks[m]=false;},{once:true});
    a.src=DIR+MUSIC[m]+'.mp3';
  }catch(e){tracks[m]=false;}
  return null;
}
function musicMood(){
  const S=G.S;
  if(S.game==='menu')return 'menu';
  if(G.B)return S.boss===G.BOSSES.length-1?'final':'boss';
  return 'stage';
}
// تُستدعى كل إطار: تشغّل مقطوعة الجو الحالي وتخفت الباقي. ترجع true إن كانت موسيقى الملف تعمل
function musicFiles(dt){
  if(!AC)return false;
  const want=musicMood();
  for(const k in MUSIC)track(k);
  let playing=false;
  for(const k in tracks){
    const a=tracks[k]; if(!a)continue;
    const target=(k===want)?VOL.music*(G.S.game==='dead'?0.4:1):0;
    if(target>0&&a.paused){a.play().catch(()=>{});}
    a.volume=Math.max(0,Math.min(1,a.volume+(target-a.volume)*Math.min(1,dt*2.5)));
    if(target===0&&a.volume<0.01&&!a.paused)a.pause();
    if(k===want)playing=true;
  }
  return playing;
}

// نغمة: f=التردد · d=المدة · v=الارتفاع · slide=انزلاق التردد · delay=تأخير
let VARY=1;          // اختلاف بسيط في الطبقة حتى لا تتشابه الضربات المتكررة
function sfx(f,d,type,v,slide,delay){
  if(!AC)return;
  f*=VARY;
  try{
    const o=AC.createOscillator(), g=AC.createGain(), t=AC.currentTime+(delay||0);
    o.type=type||'square'; o.frequency.setValueAtTime(f,t);
    if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(30,f+slide),t+d);
    g.gain.setValueAtTime(v||0.05,t); g.gain.exponentialRampToValueAtTime(0.001,t+d);
    o.connect(g); g.connect(out); o.start(t); o.stop(t+d);
  }catch(e){}
}
// ضجيج (ارتطام، ريح، نار)
function noise(d,v,f0,f1,delay){
  if(!AC)return;
  try{
    const t=AC.currentTime+(delay||0), n=Math.max(1,(AC.sampleRate*d)|0);
    const b=AC.createBuffer(1,n,AC.sampleRate), ch=b.getChannelData(0);
    for(let i=0;i<n;i++)ch[i]=Math.random()*2-1;
    const s=AC.createBufferSource(); s.buffer=b;
    const fl=AC.createBiquadFilter(); fl.type='lowpass';
    fl.frequency.setValueAtTime(f0,t); fl.frequency.exponentialRampToValueAtTime(Math.max(40,f1),t+d);
    const g=AC.createGain();
    g.gain.setValueAtTime(v,t); g.gain.exponentialRampToValueAtTime(0.001,t+d);
    s.connect(fl); fl.connect(g); g.connect(out); s.start(t);
  }catch(e){}
}
G.sfx=sfx; G.noise=noise;

/* ---------- صرخات الزعماء: لكل زعيم صرخة مركّبة خاصة به ---------- */
// صوت واحد: pts=[[نسبة الزمن، التردد]...] · lfo=سرعة الارتعاش · dep=عمقه
function voice(type,d,vol,pts,lfo,dep,delay){
  try{
    const t=AC.currentTime+(delay||0), o=AC.createOscillator(), g=AC.createGain();
    o.type=type;
    o.frequency.setValueAtTime(pts[0][1],t);
    for(let i=1;i<pts.length;i++)o.frequency.linearRampToValueAtTime(Math.max(20,pts[i][1]),t+d*pts[i][0]);
    if(lfo){
      const l=AC.createOscillator(), lg=AC.createGain();
      l.frequency.value=lfo; lg.gain.value=dep; l.connect(lg); lg.connect(o.frequency);
      l.start(t); l.stop(t+d);
    }
    g.gain.setValueAtTime(0.001,t);
    g.gain.linearRampToValueAtTime(vol,t+Math.min(0.08,d*0.2));
    g.gain.setValueAtTime(vol,t+d*0.7);
    g.gain.exponentialRampToValueAtTime(0.001,t+d);
    o.connect(g); g.connect(out); o.start(t); o.stop(t+d);
  }catch(e){}
}
const ROARS={
  // حارس الضريح: أنين عميق أجوف
  warden(d){voice('sawtooth',d,0.09,[[0,66],[0.25,140],[1,57]],27,11);voice('sawtooth',d,0.05,[[0,100],[0.25,215],[1,86]],27,17);voice('square',d,0.06,[[0,43],[0.3,92],[1,37]],0,0);noise(d,0.07,2400,300);},
  // الفارس الساقط: صيحة حرب معدنية
  knight(d){voice('square',d*0.8,0.08,[[0,180],[0.15,330],[0.6,300],[1,150]],9,14);voice('sawtooth',d*0.8,0.05,[[0,360],[0.15,660],[1,300]],0,0);for(let i=0;i<3;i++)sfx(2200+i*500,0.09,'square',0.03,-400,i*0.07);noise(d*0.6,0.05,5000,1200);},
  // ملكة العناكب: فحيح وطقطقة حادة
  spider(d){for(let i=0;i<Math.floor(d*14);i++)noise(0.04,0.07,7000,3500,i*0.07);voice('sawtooth',d,0.05,[[0,900],[0.5,1500],[1,700]],48,260);voice('square',d,0.03,[[0,420],[1,300]],60,120);},
  // ساحر الصقيع: عويل جليدي عالٍ
  lich(d){voice('sine',d,0.09,[[0,520],[0.3,1250],[0.7,1050],[1,420]],7,38);voice('sine',d,0.05,[[0,780],[0.3,1880],[1,640]],7,50);voice('triangle',d,0.04,[[0,130],[1,95]],0,0);noise(d,0.04,9000,5000);},
  // غول المصهر: هدير منخفض وصخور تتدحرج
  golem(d){voice('sawtooth',d,0.12,[[0,38],[0.4,62],[1,30]],13,7);voice('square',d,0.08,[[0,57],[0.4,90],[1,44]],0,0);noise(d,0.12,600,90);for(let i=0;i<5;i++)noise(0.12,0.08,900,150,i*d/5);},
  // سيد الدماء: صرخة خفاش حادة تهبط
  vampire(d){voice('sawtooth',d*0.7,0.07,[[0,1700],[0.2,2300],[1,500]],32,160);voice('square',d*0.7,0.04,[[0,850],[0.2,1150],[1,250]],0,0);noise(d,0.06,8000,2500);voice('sine',d,0.05,[[0,220],[1,110]],5,12,d*0.15);},
  // الذئب الأسود: عواء طويل
  wolf(d){voice('sine',d*1.2,0.11,[[0,260],[0.35,640],[0.75,600],[1,300]],6,13);voice('triangle',d*1.2,0.06,[[0,520],[0.35,1280],[0.75,1200],[1,600]],6,24);voice('sawtooth',d*0.4,0.05,[[0,110],[1,150]],30,20);noise(d*0.5,0.03,1500,600);},
  // الحاصد: همس جماعي وجرس جنائزي
  reaper(d){voice('sine',d,0.07,[[0,98],[1,82]],3,4);voice('sine',d,0.07,[[0,104],[1,87]],4,5);voice('sine',d,0.06,[[0,147],[1,124]],2,6);noise(d,0.08,1800,500);sfx(196,d*1.3,'sine',0.09,-6);sfx(392,d,'sine',0.04,-10,0.02);sfx(588,d*0.6,'sine',0.02,0,0.02);},
  // التنين العظمي: زئير هائل ممتد
  dragon(d){voice('sawtooth',d*1.2,0.12,[[0,52],[0.2,150],[0.6,120],[1,40]],22,20);voice('sawtooth',d*1.2,0.08,[[0,105],[0.2,300],[1,80]],22,36);voice('square',d*1.2,0.07,[[0,26],[0.2,75],[1,22]],0,0);noise(d*1.2,0.13,3500,200);noise(d*0.5,0.06,7000,1500,d*0.15);},
  // عين الهاوية: ذبذبة غريبة
  eye(d){voice('sine',d,0.09,[[0,300],[0.5,900],[1,180]],58,380);voice('square',d,0.035,[[0,150],[0.5,95],[1,300]],17,70);voice('sine',d,0.05,[[0,1900],[1,2600]],90,500);noise(d,0.03,3000,9000);},
  // ملك الرماد: زئير متعدد الطبقات مع نار
  king(d){voice('sawtooth',d*1.3,0.12,[[0,60],[0.2,170],[0.7,150],[1,45]],18,18);voice('sawtooth',d*1.3,0.08,[[0,90],[0.2,255],[1,68]],25,30);voice('square',d*1.3,0.08,[[0,30],[0.2,85],[1,23]],0,0);voice('sine',d,0.05,[[0,340],[0.3,520],[1,170]],9,22,0.1);noise(d*1.3,0.12,2800,160);for(let i=0;i<8;i++)noise(0.05,0.05,6000,2000,i*d/8);}
};
G.roar=function(d,id){
  if(!AC)return;
  if(playFile('roar_'+id,1))return;
  try{(ROARS[id]||ROARS.warden)(d);}catch(e){}
};
G.buzz=function(ms){try{if(navigator.vibrate)navigator.vibrate(ms);}catch(e){}};

/* ---------- مكتبة الأصوات بالاسم: G.snd('اسم') ---------- */
const SND={
  click(){sfx(520,0.06,'triangle',0.05,200);},
  select(){sfx(420,0.08,'triangle',0.05,300);sfx(840,0.12,'sine',0.03,0,0.05);},
  step(){noise(0.04,0.025,900,300);},
  jump(){sfx(380,0.1,'triangle',0.04,200);noise(0.05,0.02,1500,600);},
  land(){noise(0.09,0.05,700,120);sfx(90,0.08,'sine',0.05,-30);},
  dodge(){sfx(200,0.15,'triangle',0.05,-100);noise(0.12,0.03,1800,400);},
  perfect(){sfx(880,0.1,'sine',0.06,440);sfx(1320,0.25,'sine',0.05,0,0.07);},
  swap(){sfx(520,0.07,'triangle',0.05,260);noise(0.04,0.03,5000,2000);},
  drink(){sfx(300,0.08,'sine',0.04,80);sfx(340,0.08,'sine',0.04,80,0.14);sfx(380,0.08,'sine',0.04,80,0.28);},
  heal(){sfx(520,0.25,'sine',0.06,300);sfx(780,0.3,'sine',0.04,300,0.1);},
  energy(){sfx(660,0.12,'sine',0.06,330);sfx(990,0.3,'sine',0.05,200,0.08);},
  special(){sfx(300,0.3,'sine',0.07,900);noise(0.3,0.05,800,4000);},
  // الضربات: طبقة ارتطام منخفضة + طقطقة حادة + ضجيج قصير
  hit(){sfx(300,0.1,'square',0.045,-140);sfx(95,0.12,'sine',0.08,-40);noise(0.05,0.07,6000,1200);noise(0.1,0.04,1400,300,0.01);},
  heavy(){sfx(120,0.22,'square',0.07,-60);sfx(55,0.3,'sine',0.12,-25);noise(0.06,0.1,5000,900);noise(0.22,0.09,1600,140,0.02);},
  crit(){sfx(1400,0.08,'square',0.04,-600);sfx(700,0.16,'triangle',0.05,-300,0.03);sfx(80,0.2,'sine',0.1,-30);noise(0.08,0.06,8000,2000);},
  hurt(){sfx(160,0.25,'sawtooth',0.06,-90);sfx(70,0.2,'sine',0.09,-30);noise(0.12,0.07,1500,300);},
  die(){sfx(110,0.9,'sawtooth',0.08,-70);sfx(82,1.2,'sine',0.06,-40,0.2);},
  heart(){sfx(60,0.1,'sine',0.09,-15);sfx(55,0.1,'sine',0.07,-15,0.16);},
  // أصوات تلويح الأسلحة
  sw_sword(){sfx(700,0.09,'triangle',0.04,-400);noise(0.07,0.03,5000,1200);},
  sw_dual(){sfx(900,0.06,'triangle',0.035,-500);noise(0.05,0.03,6000,2000);},
  sw_axe(){sfx(260,0.3,'triangle',0.05,-180);noise(0.25,0.03,900,300);},
  sw_spear(){sfx(520,0.12,'triangle',0.04,300);noise(0.08,0.02,4000,2500);},
  sw_scythe(){sfx(340,0.28,'sawtooth',0.03,-200);noise(0.22,0.04,2500,500);},
  sw_chain(){for(let i=0;i<4;i++)sfx(1800+i*220,0.03,'square',0.02,0,i*0.035);noise(0.14,0.03,4500,1500,0.1);},
  sw_bow(){sfx(180,0.2,'triangle',0.03,120);},
  sw_ninja(){sfx(1200,0.06,'triangle',0.04,-500);},
  sw_staff(){sfx(420,0.18,'sine',0.05,500);noise(0.12,0.03,1200,4000);},
  sw_hammer(){sfx(180,0.36,'triangle',0.06,-120);noise(0.3,0.04,700,200);},
  arrow(){sfx(900,0.12,'triangle',0.05,-600);noise(0.06,0.04,4000,1500);},
  thud(){sfx(90,0.15,'square',0.06,-40);noise(0.15,0.07,600,100);},
  wave(){sfx(140,0.5,'sawtooth',0.09,-80);noise(0.4,0.1,3000,200);},
  thunder(){noise(0.5,0.12,5000,150);sfx(2000,0.08,'sawtooth',0.04,-1800);},
  quake(){sfx(60,0.6,'square',0.1,-25);noise(0.6,0.12,900,80);},
  whoosh(){noise(0.25,0.06,600,4500);},
  shadow(){sfx(220,0.2,'sine',0.05,-150);noise(0.15,0.03,3000,800);},
  // أصوات الزعماء والعناصر
  tel(){sfx(140,0.4,'sawtooth',0.05,120);},
  slam(){sfx(80,0.3,'square',0.09,-40);noise(0.25,0.1,1800,150);},
  charge(){sfx(180,0.5,'sawtooth',0.07,-120);noise(0.5,0.05,2500,400);},
  cast(){sfx(240,0.4,'sine',0.06,300);},
  bolt(){sfx(520,0.18,'sawtooth',0.04,-300);noise(0.1,0.03,3500,900);},
  leap(){sfx(120,0.3,'triangle',0.06,260);noise(0.15,0.04,800,2500);},
  vanish(){sfx(600,0.3,'sine',0.05,-500);noise(0.2,0.03,5000,500);},
  spin(){for(let i=0;i<5;i++)noise(0.12,0.04,1200,3500,i*0.22);},
  breath(){noise(1.0,0.09,500,2500);sfx(70,1.0,'sawtooth',0.04,40);},
  beam(){sfx(90,0.5,'sawtooth',0.09,400);sfx(1400,0.5,'square',0.03,-900);noise(0.5,0.08,6000,800);},
  warn(){sfx(880,0.07,'square',0.03);sfx(880,0.07,'square',0.03,0,0.12);},
  pillar(){sfx(120,0.25,'sawtooth',0.05,-60);noise(0.3,0.05,2500,300);},
  drop(){noise(0.08,0.04,2200,400);},
  stun(){sfx(1000,0.1,'sine',0.04,400);sfx(1300,0.1,'sine',0.04,400,0.1);sfx(1600,0.2,'sine',0.04,400,0.2);},
  bossdie(){sfx(90,1.6,'sawtooth',0.09,-55);noise(0.9,0.1,2500,120);},
  win(){[392,494,587,784].forEach((f,i)=>sfx(f,0.35,'triangle',0.06,0,0.5+i*0.16));},
  leech(){sfx(240,0.3,'sine',0.05,240);},
  // أصوات المراحل والمتجر
  coin(){sfx(1320,0.05,'square',0.03);sfx(1760,0.1,'square',0.03,0,0.05);},
  crystal(){sfx(1568,0.1,'sine',0.05);sfx(2093,0.12,'sine',0.05,0,0.08);sfx(2637,0.2,'sine',0.04,0,0.16);},
  chest(){noise(0.1,0.05,900,300);[523,659,784,1047].forEach((f,i)=>sfx(f,0.14,'triangle',0.05,0,0.08+i*0.07));},
  pad(){sfx(220,0.25,'square',0.05,700);},
  spike(){sfx(900,0.06,'sawtooth',0.04,-500);noise(0.08,0.05,3000,800);},
  saw(){noise(0.1,0.03,5000,2500);},
  clang(){sfx(1900,0.08,'square',0.03,-300);sfx(2600,0.12,'triangle',0.03,-600);noise(0.05,0.04,7000,3000);},
  scrape(){noise(0.12,0.035,500,200);},
  plate(){sfx(196,0.2,'triangle',0.06,-40);sfx(392,0.3,'sine',0.04,0,0.1);},
  gate(){noise(0.6,0.07,400,120);sfx(70,0.6,'sawtooth',0.04,30);},
  wrong(){sfx(150,0.25,'sawtooth',0.06,-60);sfx(110,0.3,'sawtooth',0.05,-30,0.12);},
  solved(){[523,659,784,1047,1319].forEach((f,i)=>sfx(f,0.25,'sine',0.05,0,i*0.09));},
  portal(){sfx(200,0.8,'sine',0.06,900);noise(0.6,0.04,500,5000);},
  fall(){sfx(500,0.4,'sine',0.05,-420);},
  buy(){sfx(660,0.08,'triangle',0.05);sfx(880,0.08,'triangle',0.05,0,0.08);sfx(1320,0.2,'triangle',0.05,0,0.16);},
  deny(){sfx(180,0.12,'square',0.04,-40);},
  levelup(){[392,523,659,784,1047].forEach((f,i)=>sfx(f,0.3,'triangle',0.055,0,i*0.08));noise(0.5,0.03,800,6000);},
  efall(){sfx(260,0.25,'sawtooth',0.05,-180);noise(0.15,0.05,1500,200);}
};
const VARIED={hit:1,heavy:1,crit:1,hurt:1,step:1,clang:1,coin:1,arrow:1,sw_sword:1,sw_dual:1,sw_axe:1,sw_spear:1,sw_scythe:1,sw_chain:1,sw_ninja:1,sw_hammer:1,spike:1,thud:1,land:1};
G.snd=function(n){
  if(playFile(n))return;                       // ملف حقيقي إن وُجد
  const f=SND[n]; if(!f)return;
  VARY=VARIED[n]?0.94+Math.random()*0.12:1;
  try{f();}catch(e){}
  VARY=1;
};
// نوتة موسيقية (لغز الأجراس)
G.note=function(f){sfx(f,0.5,'sine',0.09);sfx(f*2,0.3,'triangle',0.03);sfx(f*3,0.15,'sine',0.015);};

/* ---------- موسيقى القتال (تتسارع في المرحلة الثانية) ---------- */
const BASS=[73.4,73.4,87.3,73.4,65.4,65.4,98,82.4];
const LEAD=[293.7,349.2,440,349.2,329.6,261.6,293.7,220];
let mt=0, mi=0;
G.musicTick=function(dt){
  if(!AC)return;
  if(musicFiles(dt))return;                     // موسيقى الملفات تعمل فلا حاجة للمولّدة
  const b=G.B, S=G.S;
  if(S.game!=='play'||G.P.state==='dead'||(b&&(b.state==='intro'||b.state==='dead'))){mt=0;return;}
  mt-=dt; if(mt>0)return;
  const fast=!!b&&b.phase>1;
  mt=fast?0.3:(b?0.4:0.46);
  const i=mi++%16;
  sfx(BASS[(i>>1)%8]*(fast&&i%2?2:1),0.28,'triangle',b?0.045:0.03);
  if(i%4===0)noise(0.12,b?0.05:0.03,300,60);     // طبلة
  if(i%4===2)noise(0.05,0.018,6000,3000);        // صنج
  if(i%2===0)sfx(LEAD[(i>>1)%8]*(b&&b.phase>2?1.5:1),0.22,'sine',0.014);
};

})(window.G);
