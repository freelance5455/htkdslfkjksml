/* ================== player.js — اللاعب: 5 شخصيات، لكل واحدة شكل ومهارة ==================
   بيانات الشخصيات (الاسم، الثمن، الميزة) في save.js داخل G.CHARS.
   شكل كل شخصية يتغير كل 5 مستويات (5 أشكال): ألوان الدروع في TIERS بالأسفل.        */
(function(G){
'use strict';
const W=G.W, H=G.H, GY=G.GY, GRAV=G.GRAV, R=G.R, clamp=G.clamp, r=G.r, pl=G.pl;
const S=G.S, CFG=G.CFG, buf=G.buf, keys=G.keys, kb=G.kb;

// ألوان كل شكل: [الدرع، ظل الدرع، لمعة الدرع، أفتح لمعة، العباءة، ظل العباءة، أغمق ظل، الزينة]
const TIERS={
  knight:[
    ['#8a93a6','#6d7587','#a9b2c4','#dfe6f5','#1f3a6b','#172c52','#122241','#9b2335'],   // 1: حديد
    ['#9aa6bc','#74809a','#c0cadc','#f0f4ff','#7a1c2a','#5a1020','#3a0914','#c9a03c'],   // 2: فولاذ بزينة ذهبية
    ['#5a82b8','#3e5f90','#8ab0e0','#d0e6ff','#e8ecf5','#b8c0d4','#8a93a6','#ffd76a'],   // 3: فارس أزرق
    ['#d9b24a','#a8842e','#f2d47a','#fff6cc','#9b1c2a','#6a1018','#450a10','#ffffff'],   // 4: ذهبي
    ['#f0f4ff','#b8c4e0','#ffffff','#ffffff','#3aa0ff','#2a70d0','#1c4a9a','#ffd76a']    // 5: نوراني
  ],
  lady:[
    ['#b9a3c9','#8f7aa6','#d6c4e6','#f5eaff','#7a1c4a','#5a1238','#420c2a','#c9a03c'],
    ['#c8b8dc','#9a88b4','#e4d8f2','#ffffff','#1c5a6a','#12424e','#0a2e38','#ffd76a'],
    ['#5ab8a8','#3a8a7e','#8ae0d0','#d8fff6','#f0e8f5','#c4b8d0','#9488a4','#ffd76a'],
    ['#e0b85a','#b08a34','#f6dc8a','#fff8d8','#8a1c5a','#5e103e','#3e0a28','#ffffff'],
    ['#f5f0ff','#c4b8e0','#ffffff','#ffffff','#ff7ac0','#d0508f','#9a3068','#ffd76a']
  ],
  ranger:[
    ['#6b5a3a','#4a3e28','#8a7850','#c8b890','#2f5a34','#22422a','#16301c','#c9a03c'],
    ['#7a6844','#56482e','#a08c5c','#dcc8a0','#3a6a8a','#2a4e68','#1c364a','#ffd76a'],
    ['#4a7a6a','#345a4e','#6aa894','#c8f0e0','#1c3a2a','#142a1e','#0c1c14','#ffd76a'],
    ['#c8a850','#96802e','#e8cc7a','#fff4c8','#5a2a6a','#401c4e','#2a1034','#ffffff'],
    ['#e8f4e8','#b0c8b4','#ffffff','#ffffff','#3ad08a','#2aa068','#1c704a','#ffd76a']
  ],
  mage:[
    ['#5a4a8a','#3e3266','#7a68b0','#c8b8f0','#2a2050','#1e163a','#140e28','#c9a03c'],
    ['#3a6a9a','#284c72','#5a90c4','#c0e0ff','#1c2a50','#141e3a','#0c1428','#ffd76a'],
    ['#8a3a7a','#662858','#b458a0','#f0c0e6','#3a1040','#2a0a2e','#1c061e','#ffd76a'],
    ['#c8983a','#967020','#e8c060','#fff0c0','#4a1c6a','#34124e','#220a34','#ffffff'],
    ['#f0ecff','#bcb4e0','#ffffff','#ffffff','#a06aff','#7848d0','#52309a','#ffd76a']
  ],
  berserk:[
    ['#7a5a3a','#56402a','#9a7850','#d0b088','#5a4630','#403222','#2a2016','#9b2335'],
    ['#8a6844','#60482e','#b08c5c','#e0c8a0','#6a2a1c','#4a1c12','#30100a','#c9a03c'],
    ['#5a5a66','#3e3e48','#80808e','#d0d0dc','#2a2a36','#1c1c26','#101018','#ff5a4a'],
    ['#c8a040','#967424','#e8c468','#fff0c0','#6a1c1c','#4a1010','#300808','#ffffff'],
    ['#f0e8e0','#c0b4a8','#ffffff','#ffffff','#ff5a3a','#d03a20','#9a2410','#ffd76a']
  ],
  lancer:[
    ['#7a9aa0','#557378','#a4c4ca','#e0f4f8','#1c5a5a','#124242','#0a2e2e','#c9a03c'],
    ['#8ab0b8','#607e86','#b8dce2','#f0ffff','#7a3a1c','#5a2a12','#3a1a0a','#ffd76a'],
    ['#4a8ac8','#34649a','#7ab4e8','#d0ecff','#e8f0f5','#b8c8d4','#8a9aa6','#ffd76a'],
    ['#d8b850','#a88c30','#f0d880','#fff8d0','#1c6a7a','#124c58','#0a323a','#ffffff'],
    ['#f0fcff','#b8d4e0','#ffffff','#ffffff','#3ad0d0','#2aa0a0','#1c7070','#ffd76a']
  ],
  reaper:[
    ['#3a3a4a','#26262f','#55556a','#a0a0c0','#1c1c26','#12121a','#0a0a10','#8affc0'],
    ['#3a4a44','#26302c','#556a62','#a0c0b4','#14261e','#0c1a14','#06100c','#8affc0'],
    ['#4a3a5a','#30263c','#6a557e','#c0a0e0','#1e1430','#140c22','#0c0616','#c07aff'],
    ['#5a4a2a','#3c301c','#7e6a40','#e0c890','#2a1e0c','#1c1406','#100c02','#ffd76a'],
    ['#e8e8f4','#b0b0c8','#ffffff','#ffffff','#5a3aa0','#3e2678','#281850','#8affc0']
  ],
  ninja:[
    ['#2a2a3a','#1c1c28','#40405a','#8080a8','#2a2a3a','#1c1c28','#101018','#c0283a'],
    ['#2a3a4a','#1c2832','#405a70','#80a8c8','#1c2832','#121c24','#0a1016','#ff7a2a'],
    ['#3a2a4a','#281c32','#5a4070','#a880c8','#281c32','#1c1224','#100a16','#c07aff'],
    ['#4a3a1c','#322812','#70582a','#c8a860','#322812','#241c0c','#161006','#ffd76a'],
    ['#f0f0f8','#b8b8cc','#ffffff','#ffffff','#b8b8cc','#8a8aa0','#606078','#ff3b6a']
  ],
  warden:[
    ['#5a5a66','#3e3e48','#7a7a88','#c0c0d0','#3a3228','#2a241c','#1c1812','#ffb347'],
    ['#6a6470','#48444e','#8c8694','#d0cad8','#4a2a1c','#341c12','#22120a','#ffd76a'],
    ['#4a5a7a','#323e56','#6a7ea4','#b8c8e8','#1c2a4a','#121c34','#0a1222','#7fd4ff'],
    ['#c0a04a','#8e7430','#e0c470','#fff0c0','#4a3a1c','#342812','#221a0a','#ffffff'],
    ['#e8ecf4','#b0b8c8','#ffffff','#ffffff','#7a8ab0','#566488','#3a4460','#ffe066']
  ],
  smith:[
    ['#a08a6a','#74644c','#c4ae8c','#f0e0c0','#6a3a1c','#4a2812','#30180a','#ff7a2a'],
    ['#b09a7a','#807058','#d4be9c','#fff0d0','#7a1c1c','#5a1212','#3a0a0a','#ffd76a'],
    ['#7a8aa0','#566478','#a0b0c8','#e0ecff','#2a3a6a','#1c284e','#121a34','#7fd4ff'],
    ['#d8b040','#a88428','#f0d070','#fff8c8','#8a2a1c','#641c12','#40100a','#ffffff'],
    ['#f4f0e8','#c8c0b0','#ffffff','#ffffff','#ffb347','#d08a2a','#9a601c','#7fd4ff']
  ]
};
const HAIR=[['#e0a23c','#b5782a'],['#e0a23c','#b5782a'],['#f0f0f8','#b8b8cc'],['#c0392b','#8a2418'],['#ffe9a0','#e0b85a']];
G.TIER_NAMES=['حديدي','فولاذي','النخبة','ذهبي','نوراني'];
function look(ch,tier){
  const t=(TIERS[ch]||TIERS.knight)[clamp(tier|0,0,4)], fem=ch==='lady'||ch==='mage'||ch==='reaper'||ch==='ninja';
  return {arm:t[0],armD:t[1],armL:t[2],hi:t[3],cape:t[4],capeD:t[5],capeDD:t[6],trim:t[7],
          leg:fem?'#5a4a66':'#4a5060',legL:fem?'#6f5c7d':'#5b6275',boot:fem?'#3a2433':'#3a2a1a',
          hair:HAIR[tier][0],hairD:HAIR[tier][1],skin:ch==='berserk'?'#d8a078':'#f0c4a4'};
}

G.resetPlayer=function(){
  const hp=G.maxHp();
  G.P={x:60,y:GY,vx:0,vy:0,f:1,hp:hp,lag:hp,flasks:G.maxFlasks(),ch:G.save.char,tier:G.tier(),
       state:'idle',t:0,inv:0,ground:true,hit:false,thud:false,dodgeCd:0,pd:false,
       w:G.save.wpn,aw:G.save.wpn,hn:0,sw:0,hitL:[],struck:false,sp:{},en:0,combo:0,comboT:0,gT:0,stepT:0,beat:0,
       cs:-1,csT:0,fin:false,spChain:false,pierce:false,     // الكومبو
       skCd:0,guard:0,rage:0,slowT:0,dashL:[],airJ:false,blink:false};              // المهارة والحالات
};

/* ---------- إصابة اللاعب (ترجع true إذا تضرر فعلاً) ---------- */
// trap=true للأشواك والمناشير: المراوغة لا تحمي منها
G.hurtP=function(d,fromX,trap){
  const p=G.P;
  if(p.state==='dead'||S.game!=='play')return false;
  // صدّ الفارس: يمنع الضرر ويردّ الضربة على أقرب عدو
  if(p.guard>0&&!trap){
    if(!p.gHit||p.gHit<=0){
      p.gHit=0.25;
      G.snd('clang'); S.shake=Math.max(S.shake,3);
      G.spark(p.x+p.f*8,p.y-14,'#dfe9ff',10,120); G.ring(p.x+p.f*8,p.y-14,18,'#7fd4ff',0.25);
      p.en=Math.min(CFG.energyMax,p.en+8);
      for(const t of G.targets())if(Math.abs(t.x-p.x)<t.def.hw+34){
        const b=G.bossBox(t);G.hitT(t,22,clamp(p.x,t.x-t.def.hw,t.x+t.def.hw),(b.top+b.bot)/2,0,true,'#7fd4ff',false);break;
      }
    }
    return false;
  }
  if(p.inv>0&&!(trap&&p.state==='dodge')){
    // مراوغة مثالية: تفاديت الضربة في آخر لحظة
    if(p.state==='dodge'&&!p.pd&&!trap){
      p.pd=true;
      S.slow=Math.max(S.slow,0.3);
      p.en=Math.min(CFG.energyMax,p.en+15);
      G.fxAdd({k:'num',x:p.x,y:p.y-30,v:'!',big:true,c:'#7fd4ff',max:0.7});
      G.ring(p.x,p.y-12,26,'#7fd4ff',0.35);
      G.snd('perfect');
    }
    return false;
  }
  if(p.ch==='knight')d=Math.max(1,Math.round(d*0.85));      // درع الفارس
  p.hp-=d; p.inv=0.9;
  if(p.ch==='smith'&&p.hp>0&&p.state!=='special'){
    p.inv=0.7;                         // راسخ: لا يترنّح ولا يُدفع
  }else{
    p.state='hurt'; p.t=0.25;
    p.combo=0; p.comboT=0; p.csT=0;
    p.vx=(p.x>=fromX?1:-1)*(trap?70:120); p.vy=-130; p.ground=false;
  }
  S.shake=Math.max(S.shake,5); S.freeze=0.07;
  G.spark(p.x,p.y-12,'#b3202e',10,100);
  G.ring(p.x,p.y-12,18,'#ff3b2f',0.25);
  G.fxAdd({k:'num',x:p.x,y:p.y-28,v:'-'+d,c:'#ff5a4a',max:0.7});
  G.snd('hurt'); G.buzz(60);
  if(p.hp<=0){
    p.hp=0; p.state='dead'; S.deadT=1.5;
    G.save.deaths++; G.doSave();
    G.snd('die');
  }
  return true;
};
G.trapHit=function(d,fromX){
  return G.hurtP(Math.round(d*(G.L?G.L.dmg:1)),fromX,true);
};

// لكل شخصية سلاحها الخاص، فلا تبديل أثناء اللعب
G.switchWeapon=function(){};

/* ================== مهارات الشخصيات ================== */
function useSkill(p,dir){
  const C=G.char();
  if(dir)p.f=dir;
  p.skCd=C.cd;
  G.ring(p.x,p.y-12,22,'#ffffff',0.25);
  if(p.ch==='knight'){            // الصدّ
    p.guard=1.6; G.snd('clang'); G.sfx(300,0.3,'triangle',0.05,200);
  }else if(p.ch==='lady'){        // اندفاعة البرق
    p.state='dash'; p.t=0.22; p.inv=0.34; p.dashL=[];
    G.snd('whoosh'); G.snd('thunder'); S.shake=3;
  }else if(p.ch==='ranger'){      // قفزة خلفية + 3 سهام
    p.state='flip'; p.t=0.4; p.inv=0.42; p.vy=-200; p.ground=false;
    const m=G.rangedMul();
    for(let i=-1;i<=1;i++)G.shots.push({k:'arrow',x:p.x+p.f*9,y:p.y-13,vx:p.f*330,vy:i*50-10,g:40,life:1.2,dmg:10*m,en:4,c:'#9be07a',rot:0,crit:true});
    G.snd('arrow'); G.snd('jump');
  }else if(p.ch==='mage'){        // انفجار اللهب
    p.state='cast'; p.t=0.35; p.inv=0.4; p.vx=0;
    G.snd('pillar'); G.snd('quake'); S.shake=6; S.flash=Math.max(S.flash,0.12);
    G.ring(p.x,p.y-12,70,'#ffb347',0.45); G.ring(p.x,p.y-12,46,'#fff2c0',0.3);
    for(let i=0;i<26;i++)G.spark(p.x+R(-50,50),p.y-R(0,36),i%2?'#ffb347':'#ff7a2a',1,120);
    for(const t of G.targets())if(Math.abs(t.x-p.x)<66+t.def.hw){
      const b=G.bossBox(t);
      G.hitT(t,38,clamp(p.x,t.x-t.def.hw,t.x+t.def.hw),(b.top+b.bot)/2,0,true,'#ffb347',false);
      if(t.hp>0)G.addDot(t,4,6,'#ffb347');
    }
  }else if(p.ch==='lancer'){      // الوثبة
    p.state='vault'; p.t=0.45; p.inv=0.5; p.vy=-215; p.ground=false; p.dashL=[];
    G.snd('leap'); G.snd('whoosh');
  }else if(p.ch==='ninja'){       // الوميض
    p.state='dash'; p.blink=true; p.t=0.14; p.inv=0.75; p.dashL=[];
    G.snd('shadow'); G.snd('vanish');
    for(let i=0;i<10;i++)G.puff(p.x+R(-6,6),p.y-R(0,24),'#3a2a55');
  }else if(p.ch==='warden'){      // السحب
    p.state='cast'; p.t=0.4; p.inv=0.45; p.vx=0;
    G.snd('sw_chain'); G.snd('slam'); S.shake=6;
    G.ring(p.x,p.y-12,90,'#ffe066',0.4);
    for(const t of G.targets()){
      if(Math.abs(t.x-p.x)>125||(G.blockedBetween&&G.blockedBetween(p.x,t.x)))continue;
      const b=G.bossBox(t), by=(b.top+b.bot)/2;
      G.fxAdd({k:'bolt',x:p.x,y:p.y-13,x2:t.x,y2:by,c:'#c8d0e0',max:0.3});
      if(t.isEnemy){
        if(!t.fly)t.x=clamp(p.x+(t.x>=p.x?1:-1)*(16+Math.random()*10),t.minX,t.maxX);
        G.stunEnemy(t,1.0);
        G.hitT(t,16,t.x,by,0,true,'#ffe066',false);
      }else{G.hitT(t,24,clamp(p.x,t.x-t.def.hw,t.x+t.def.hw),by,0,true,'#ffe066',false);G.stunBoss(0.7);}
    }
  }else if(p.ch==='smith'){       // دكّ الأرض
    p.state='cast'; p.t=0.4; p.inv=0.45; p.vx=0;
    G.snd('quake'); S.shake=9; S.flash=Math.max(S.flash,0.1);
    G.ring(p.x,GY-2,70,'#8fd8ff',0.45); G.debris(p.x,GY-2,'#5a564c',10);
    for(let i=1;i<=5;i++)for(const d of [-1,1])G.fxAdd({k:'spike',x:p.x+d*i*12,s:24-i*3,c:'#8fd8ff',max:0.45,t:-i*0.03});
    for(const t of G.targets())if(Math.abs(t.x-p.x)<64+t.def.hw&&G.bossBox(t).bot>GY-24){
      const b=G.bossBox(t);
      G.hitT(t,30,clamp(p.x,t.x-t.def.hw,t.x+t.def.hw),(b.top+b.bot)/2,0,true,'#8fd8ff',false);
      if(t.isEnemy)G.stunEnemy(t,1.5);
    }
  }else if(p.ch==='reaper'){      // أرواح هائمة
    p.state='cast'; p.t=0.3; p.inv=0.35; p.vx=0;
    G.snd('vanish'); G.snd('cast');
    G.ring(p.x,p.y-12,40,'#8affc0',0.4);
    for(let i=0;i<3;i++)G.shots.push({k:'soul',x:p.x,y:p.y-16,vx:p.f*(60+i*40),vy:-120+i*50,g:0,life:2.6,dmg:14,en:3,c:'#8affc0',rot:0,hom:520});
  }else{                          // الهيجان
    p.rage=5;
    G.roar(0.6,'wolf'); S.shake=5; S.flash=Math.max(S.flash,0.1);
    G.ring(p.x,p.y-12,50,'#ff3b2f',0.4);
    for(let i=0;i<16;i++)G.spark(p.x+R(-8,8),p.y-R(0,26),'#ff3b2f',1,110);
  }
}

G.updPlayer=function(dt){
  const p=G.P, WP=G.WEAPONS, L=G.L, C=G.char();
  p.inv=Math.max(0,p.inv-dt);
  p.dodgeCd=Math.max(0,p.dodgeCd-dt);
  p.skCd=Math.max(0,p.skCd-dt); p.guard=Math.max(0,p.guard-dt); p.rage=Math.max(0,p.rage-dt);
  p.slowT=Math.max(0,p.slowT-dt); p.csT=Math.max(0,p.csT-dt);
  if(p.gHit>0)p.gHit-=dt;
  if(p.ground)p.airJ=false;
  p.lag+=(p.hp-p.lag)*Math.min(1,dt*3);
  if(p.comboT>0){p.comboT-=dt;if(p.comboT<=0)p.combo=0;}
  const dir=((keys.r||kb.r)?1:0)-((keys.l||kb.l)?1:0);
  const wasAir=!p.ground, fallV=p.vy;

  // نبض القلب عند انخفاض الصحة
  if(p.state!=='dead'&&p.hp<=G.maxHp()*0.3){
    p.beat-=dt; if(p.beat<=0){p.beat=0.9;G.snd('heart');}
  }
  if(p.rage>0&&Math.random()<0.5)G.puff(p.x+R(-6,6),p.y-R(0,24),'#ff3b2f');

  if(p.state==='dead'){
    p.vx*=0.9;
  }else if(p.state==='hurt'){
    p.t-=dt; if(p.t<=0)p.state='idle';
  }else if(p.state==='dodge'){
    p.t-=dt; p.vx=p.f*175;
    p.gT-=dt;
    if(p.gT<=0){p.gT=0.04;G.ghosts.push({x:p.x,y:p.y,life:0.22});}
    if(Math.random()<0.5&&p.ground)G.puff(p.x-p.f*4,p.y-1,'#3c3a33');
    if(p.t<=0){p.state='idle';p.vx=0;}
  }else if(p.state==='dash'){           // اندفاعة الفارسة
    const bl=p.blink, col=bl?'#c08cff':'#ffe066';
    p.t-=dt; p.vx=p.f*(bl?560:430);
    G.ghosts.push({x:p.x,y:p.y,life:0.2,c:col});
    G.spark(p.x-p.f*6,p.y-R(4,20),col,1,50);
    for(const t of G.targets())if(p.dashL.indexOf(t)<0&&G.inRangeT(t,16,12)){
      p.dashL.push(t);
      const b=G.bossBox(t), hy=clamp(p.y-14,b.top+3,b.bot-3), hx=clamp(p.x,t.x-t.def.hw,t.x+t.def.hw);
      if(bl){                           // وميض النينجا: يشلّ ويجرح قليلاً
        G.hitT(t,12,hx,hy,6,false,col,true);
        if(t.isEnemy&&t.hp>0)G.stunEnemy(t,1.4);
      }else G.hitT(t,28,hx,hy,6,true,col,true);
    }
    if(p.t<=0){p.state='idle';p.vx=0;p.blink=false;}
  }else if(p.state==='vault'){          // وثبة الرمّاح
    p.t-=dt; p.vx=p.f*230;
    G.ghosts.push({x:p.x,y:p.y,life:0.16,c:'#7fd4ff'});
    for(const t of G.targets())if(p.dashL.indexOf(t)<0&&G.inRangeT(t,30,8)){
      p.dashL.push(t);
      const b=G.bossBox(t);
      p.pierce=true;
      G.hitT(t,32,clamp(p.x+p.f*20,t.x-t.def.hw,t.x+t.def.hw),clamp(p.y-14,b.top+3,b.bot-3),6,true,'#7fd4ff',true);
      p.pierce=false;
    }
    if(p.t<=0||(p.ground&&p.t<0.3)){p.state='idle';p.vx=0;}
  }else if(p.state==='flip'){           // قفزة الصيّاد
    p.t-=dt; p.vx=-p.f*150;
    if(Math.random()<0.5)G.ghosts.push({x:p.x,y:p.y,life:0.15,c:'#9be07a'});
    if(p.t<=0){p.state='idle';p.vx=0;}
  }else if(p.state==='cast'){           // انفجار الساحرة
    p.t-=dt; p.vx=0;
    if(p.t<=0)p.state='idle';
  }else if(p.state==='heal'){
    p.t-=dt; p.vx=0;
    if(Math.random()<0.4)G.puff(p.x+R(-5,5),p.y-R(4,20),'#4fd08a');
    if(p.t<=0){
      p.hp=Math.min(G.maxHp(),p.hp+CFG.flaskHeal); p.state='idle';
      G.ring(p.x,p.y-12,20,'#4fd08a',0.35);
      G.fxAdd({k:'num',x:p.x,y:p.y-28,v:'+'+CFG.flaskHeal,c:'#4fd08a',max:0.7});
      G.snd('heal');
    }
  }else if(p.state==='special'){
    if(G.updSpecial(p,dt,dir)){p.state='idle';p.vx=0;}
  }else{
    if(p.state==='attack')G.updAttack(p,dt);
    let sp=CFG.playerSpeed*C.spd;
    if(p.state==='attack'&&p.ground){const s=WP[p.aw].slow;sp=s==null?25:s;}
    if(p.guard>0)sp*=0.4;
    if(p.slowT>0)sp*=0.6;                 // مُجمَّد جزئياً
    p.vx=dir*sp;
    // اندفاعة الرمح
    if(p.state==='attack'&&WP[p.aw].id==='spear'&&p.t>0.12&&p.t<0.2)p.vx+=p.f*90;
    if(dir&&p.state!=='attack')p.f=dir;
    // غبار وصوت الخطوات
    if(dir&&p.ground&&p.state==='idle'){
      if(Math.random()<0.12)G.puff(p.x-p.f*4,p.y-1,'#3c3a33');
      p.stepT-=dt; if(p.stepT<=0){p.stepT=0.26;G.snd('step');}
    }
    if(p.en>=CFG.energyMax&&Math.random()<0.25)G.puff(p.x+R(-6,6),p.y-R(0,24),'#ffd76a');

    if(buf.skill>0&&p.skCd<=0&&p.state==='idle'){
      buf.skill=0; useSkill(p,dir);
    }else if(buf.sp>0&&p.en>=CFG.energyMax&&p.state!=='attack'){
      buf.sp=0; G.startSpecial(p,dir);
    }else if(buf.dodge>0&&p.ground&&p.dodgeCd<=0){
      buf.dodge=0; if(dir)p.f=dir;
      p.state='dodge'; p.t=0.32; p.inv=0.32; p.dodgeCd=p.ch==='ninja'?0.35:0.55; p.gT=0; p.pd=false; p.guard=0;
      G.snd('dodge');
    }else if(buf.atk>0&&p.state!=='attack'){
      buf.atk=0; if(dir)p.f=dir;
      G.startAttack(p);
    }else if(buf.jump>0&&!p.ground&&p.ch==='ninja'&&!p.airJ&&p.state!=='attack'){
      buf.jump=0; p.airJ=true; p.vy=-CFG.jumpPower*0.9;       // القفزة الثانية للنينجا
      G.ring(p.x,p.y-2,10,'#c08cff',0.2); for(let i=0;i<4;i++)G.puff(p.x+R(-5,5),p.y,'#c08cff');
      G.snd('jump');
    }else if(buf.jump>0&&p.ground&&p.state!=='attack'){
      buf.jump=0; p.vy=-CFG.jumpPower; p.ground=false;
      for(let i=0;i<3;i++)G.puff(p.x+R(-4,4),p.y-1,'#3c3a33');
      G.snd('jump');
    }else if(buf.heal>0&&p.ground&&p.state==='idle'&&p.flasks>0&&p.hp<G.maxHp()){
      buf.heal=0; p.flasks--; p.state='heal'; p.t=0.6;
      G.snd('drink');
    }
  }

  /* ---------- الفيزياء (أرض، حُفر، منصات، أحجار، جدران) ---------- */
  let nx=p.x+p.vx*dt;
  if(L)nx=G.moveX(p,nx,dt);
  p.x=clamp(nx,10,G.worldW()-10);
  if(p.ground&&L&&!G.hasSupport(p.x,p.y))p.ground=false;   // مشى خارج الحافة
  if(!p.ground){
    const y0=p.y;
    p.vy+=GRAV*dt;
    p.y+=p.vy*dt;
    if(p.vy>=0){
      const s=L?G.landY(p.x,y0,p.y):(p.y>=GY?GY:null);
      if(s!==null){p.y=s;p.vy=0;p.ground=true;}
    }
  }
  if(wasAir&&p.ground&&fallV>150){
    for(let i=0;i<5;i++)G.puff(p.x+R(-6,6),p.y-1,'#4a463e');
    G.snd('land');
  }
};

/* ---------- رسم جسم الشخصية (عند نقطة الأصل، متجهة لليمين) ---------- */
G.drawHero=function(p){
  // إن كانت للشخصية صورة Sprite Sheet (انظر sprites.js) تُرسم منها بدل الكود
  if(G.drawSpriteHero&&G.drawSpriteHero(p))return;
  const tier=p.tier==null?G.tier():p.tier, ch=p.ch||'knight';
  const L=look(ch,tier), fem=ch==='lady'||ch==='mage', slim=fem||ch==='reaper'||ch==='ninja', time=S.time;
  if(ch==='reaper')L.skin='#e8e0c8';

  if(p.state==='dead'){
    r(-9,-4,15,4,L.armD); r(6,-5,5,5,ch==='knight'?L.armL:L.skin); r(-11,-2,6,2,L.cape); r(8,-3,2,1,'#0a0a0f');
    if(fem)r(4,-6,6,2,L.hair);
    pl(-2,-1,12,-1,'#dfe6f5');
    return;
  }
  if(p.state==='dodge'||p.state==='dash'){
    G.alpha(0.85);
    r(-6,-11,12,11,L.armD); r(-4,-13,8,2,L.arm); r(-8,-8,3,6,L.cape);
    r(-5,-12,10,1,fem?L.hair:L.trim); r(2,-8,3,1,'#0a0a0f');
    r(-14,-9,6,1,'#dfe9ff'); r(-16,-5,7,1,'#dfe9ff');
    G.alpha(1);
    return;
  }

  const run=p.ground&&Math.abs(p.vx)>30;
  const step=run?((time*10|0)%2):0;
  const bob=run?step:(Math.sin(time*3)>0.6?1:0);
  const lean=((p.state==='attack'&&p.t<0.2)||(p.state==='special'&&p.vx*p.f>100))?1:0;
  const cw=Math.round(Math.sin(time*(run?12:3))*1.2);

  // أجنحة النور (الشكل الخامس)
  if(tier>=4){
    const fl=Math.round(Math.sin(time*4)*2);
    G.alpha(0.75);
    for(let i=0;i<4;i++){pl(-5,-16+bob,-11-i*2,-24+i*4+fl+bob,i%2?'#bfeaff':'#ffffff');}
    G.alpha(1);
  }
  // العباءة (تتموج، وتطول مع الأشكال الأعلى) — البربري يلبس فرواً قصيراً
  if(ch==='berserk'){
    r(-7,-18+bob,4,5,'#8a7a66'); r(-8,-14+bob,3,4,'#6a5c4c'); r(-8+cw,-10+bob,2,3,'#5a4e40');
  }else if(ch==='ninja'){          // وشاح يتطاير بدل العباءة
    r(-5,-19+bob,3,2,L.trim); r(-8-(run?2:0)+cw,-19+bob,4,2,L.trim); r(-12-(run?3:0)+cw,-18+bob-cw,4,1,L.trim); r(-15-(run?4:0)+cw,-17+bob,3,1,L.trim);
  }else if(ch==='warden'){         // بلا عباءة: سلاسل على الظهر
    for(let i=0;i<4;i++)r(-6-(i%2),-16+i*3+bob,2,2,i%2?'#8a93a6':'#c8d0e0');
  }else{
    r(-7,-17+bob,3,6,L.cape);
    r(-8-(run?1:0),-12+bob,3,5,L.cape);
    r(-9-(run?2:0)+cw,-8+bob,3,5+step,L.capeD);
    r(-10-(run?3:0)+cw,-4+bob,2,2,L.capeDD);
    if(tier>=2){r(-11-(run?3:0)+cw,-6+bob,2,5,L.capeD); r(-9+cw,-13+bob,1,8,L.trim);}
    if(tier>=3)r(-12-(run?4:0)+cw,-3+bob,2,3,L.capeDD);
  }
  if(ch==='ranger'){r(-7,-20+bob,2,9,'#6b4a2a'); r(-7,-22+bob,1,2,'#dfe6f5'); r(-6,-23+bob,1,3,'#dfe6f5');}   // جعبة السهام
  // الأرجل
  if(!p.ground){
    r(-3,-7,2,5,L.leg); r(1,-8,2,5,L.legL); r(2,-3,3,2,L.legL);
  }else if(run){
    if(step){r(-5,-7,2,6,L.leg); r(3,-7,2,7,L.legL); r(3,-1,3,1,L.boot);}
    else{r(-2,-7,2,7,L.leg); r(0,-7,2,6,L.legL); r(-2,-1,3,1,L.boot);}
  }else{
    r(-3,-7,2,7,L.leg); r(1,-7,2,7,L.legL); r(-3,-1,3,1,L.boot); r(1,-1,3,1,L.boot);
  }
  if(tier>=1&&p.ground&&!run&&ch!=='mage'&&ch!=='reaper'){r(-3,-4,2,1,L.arm); r(1,-4,2,1,L.arm);}     // واقيات الركبة
  // الجسم
  if(ch==='berserk'){
    r(-4+lean,-16+bob,8,9,L.skin); r(-4+lean,-16+bob,2,9,'#b07a58'); r(-4+lean,-9+bob,8,2,L.boot);
    pl(-4+lean,-16+bob,3+lean,-9+bob,L.arm,2); r(0+lean,-9+bob,2,2,L.trim);
    r(1+lean,-13+bob,2,1,L.trim); r(1+lean,-11+bob,2,1,L.trim);                // طلاء الحرب
    r(1+lean,-18+bob,5,3,'#8a7a66'); r(1+lean,-18+bob,5,1,'#b0a08a');
  }else if(slim){
    r(-3+lean,-16+bob,7,9,L.arm); r(-3+lean,-16+bob,2,9,L.armD); r(-3+lean,-10+bob,7,1,L.boot);
    r(-4+lean,-9+bob,9,3,L.cape); r(-4+lean,-7+bob,2,2,L.capeD); r(1+lean,-14+bob,2,3,L.armL);
    r(0+lean,-10+bob,2,1,L.trim);
    r(1+lean,-17+bob,3,3,L.armL); r(1+lean,-17+bob,3,1,L.hi);
    if(ch==='mage'||ch==='reaper'){            // رداء طويل
      r(-4+lean,-7+bob,9,6-bob,L.cape); r(-5+lean,-3,10,2,L.capeD); r(-5+lean,-2,10,1,L.trim); r(0+lean,-9+bob,1,7,L.trim);
    }
  }else{
    r(-4+lean,-16+bob,8,9,L.arm); r(-4+lean,-16+bob,2,9,L.armD); r(-4+lean,-9+bob,8,2,L.boot);
    r(-4+lean,-17+bob,8,2,L.trim); r(1+lean,-14+bob,2,4,L.armL); r(0+lean,-9+bob,2,2,'#c9a03c');
    r(1+lean,-17+bob,4,3,L.armL); r(1+lean,-17+bob,4,1,L.hi);
    if(ch==='ranger')pl(-3+lean,-16+bob,3+lean,-10+bob,'#3a2a1a');             // حزام الجعبة
    if(ch==='warden'){r(-5+lean,-16+bob,1,9,L.armD); for(let i=0;i<4;i++)r(-3+lean+i*2,-15+bob+i*2,2,1,'#c8d0e0'); r(-1+lean,-9+bob,3,2,L.trim);}   // سلاسل على الصدر
    if(ch==='smith'){r(-6+lean,-19+bob,4,4,L.armL); r(-6+lean,-19+bob,4,1,L.hi); r(2+lean,-19+bob,5,4,L.armL); r(2+lean,-19+bob,5,1,L.hi); r(-2+lean,-9+bob,5,5,L.cape); r(-2+lean,-9+bob,5,1,L.trim);}  // كتفان عريضان ومئزر
  }
  if(tier>=1&&ch!=='berserk')r(-1+lean,-13+bob,1,3,L.trim);                    // شارة الصدر
  if(tier>=2){r(1+lean,-19+bob,5,2,L.armL); r(5+lean,-20+bob,1,2,L.hi); r(-5+lean,-18+bob,2,3,L.armD);}  // كتف أكبر
  if(tier>=3){r(-4+lean,-12+bob,8,1,L.trim); r(2+lean,-19+bob,3,1,L.trim);}
  // الرأس
  if(ch==='ranger'){
    r(-2+lean,-22+bob,6,5,L.skin); r(2+lean,-20+bob,1,1,'#2a1a1a'); r(1+lean,-18+bob,2,1,'#b07a58');
    r(-3+lean,-25+bob,7,3,L.cape); r(-4+lean,-24+bob,2,7,L.cape); r(3+lean,-23+bob,1,2,L.cape); r(-3+lean,-25+bob,7,1,L.capeD);
    r(-5+lean-cw,-22+bob,2,3,L.capeD);
    if(tier>=2)r(0+lean,-26+bob,1,2,L.trim);
    if(tier>=3)r(-3+lean,-22+bob,6,1,L.trim);
  }else if(ch==='berserk'){
    r(-3+lean,-22+bob,7,5,L.skin); r(1+lean,-20+bob,2,1,p.rage>0?'#ff3b2f':'#1a0a0a'); r(4+lean,-20+bob,1,1,p.rage>0?'#ff3b2f':'#1a0a0a');
    r(0+lean,-18+bob,5,3,'#5a3a22'); r(1+lean,-15+bob,3,1,'#5a3a22');          // لحية
    r(-3+lean,-25+bob,7,3,L.arm); r(-3+lean,-25+bob,7,1,L.hi);
    pl(-3+lean,-24+bob,-6+lean,-29+bob,'#e8e0d0'); pl(3+lean,-24+bob,6+lean,-29+bob,'#e8e0d0');
    r(-7+lean,-30+bob,1,2,'#ffffff'); r(6+lean,-30+bob,1,2,'#ffffff');
    if(tier>=2)r(0+lean,-27+bob,1,3,L.trim);
  }else if(ch==='lancer'){         // خوذة مفتوحة بريشة طويلة
    r(-2+lean,-22+bob,6,5,L.skin); r(2+lean,-20+bob,1,1,'#2a1a1a'); r(1+lean,-18+bob,2,1,'#b07a58');
    r(-3+lean,-25+bob,7,3,L.armL); r(-3+lean,-25+bob,7,1,L.hi); r(-3+lean,-22+bob,2,4,L.arm); r(3+lean,-22+bob,1,2,L.arm);
    r(-1+lean,-28+bob,2,3,L.trim); r(-4+lean-cw,-29+bob,3,2,L.trim); r(-7+lean-cw,-28+bob,3,2,L.cape); r(-9+lean-cw,-26+bob,2,2,L.capeD);
    if(tier>=3)r(-3+lean,-22+bob,6,1,L.trim);
  }else if(ch==='reaper'){         // قلنسوة ووجه جمجمة
    r(-4+lean,-26+bob,9,4,L.cape); r(-5+lean,-24+bob,3,8,L.cape); r(4+lean,-24+bob,1,3,L.cape); r(-4+lean,-26+bob,9,1,L.capeD); r(-1+lean,-28+bob,3,2,L.cape);
    r(-2+lean,-22+bob,6,5,L.skin); r(-1+lean,-17+bob,4,1,L.skin);
    r(0+lean,-21+bob,2,2,'#0a0a0f'); r(3+lean,-21+bob,1,2,'#0a0a0f'); r(0+lean,-21+bob,1,1,L.trim); r(3+lean,-21+bob,1,1,L.trim);
    if(tier>=2)r(-2+lean,-23+bob,6,1,L.trim);
  }else if(ch==='ninja'){          // لثام لا يظهر منه إلا العينان
    r(-3+lean,-24+bob,7,7,L.cape); r(-3+lean,-24+bob,7,1,L.armL); r(-3+lean,-24+bob,2,7,L.capeD);
    r(0+lean,-21+bob,4,2,L.skin); r(1+lean,-21+bob,1,1,'#0a0a0f'); r(3+lean,-21+bob,1,1,'#0a0a0f');
    r(-3+lean,-22+bob,7,1,L.trim);
    if(tier>=2){r(0+lean,-25+bob,2,1,L.hi);}
    if(tier>=3){r(-4+lean,-25+bob,1,2,L.trim); r(4+lean,-25+bob,1,2,L.trim);}
  }else if(ch==='warden'){         // قناع حديدي بعينين متوهجتين
    r(-3+lean,-24+bob,7,7,L.arm); r(-3+lean,-24+bob,7,1,L.hi); r(-3+lean,-24+bob,2,7,L.armD);
    r(0+lean,-21+bob,2,1,L.trim); r(3+lean,-21+bob,1,1,L.trim); r(1+lean,-19+bob,1,2,'#0a0a0f'); r(3+lean,-19+bob,1,2,'#0a0a0f');
    r(-3+lean,-18+bob,7,1,L.armD); r(-2+lean,-25+bob,1,1,L.hi); r(2+lean,-25+bob,1,1,L.hi);
    if(tier>=2){pl(-3+lean,-24+bob,-5+lean,-27+bob,L.hi); pl(3+lean,-24+bob,5+lean,-27+bob,L.hi);}
  }else if(ch==='smith'){          // خوذة مسطّحة ولحية بيضاء
    r(-2+lean,-22+bob,6,5,L.skin); r(2+lean,-21+bob,1,1,'#2a1a1a');
    r(-1+lean,-19+bob,6,4,'#e8e0d0'); r(0+lean,-15+bob,4,2,'#cfc8b0');
    r(-3+lean,-26+bob,8,4,L.arm); r(-3+lean,-26+bob,8,1,L.hi); r(1+lean,-22+bob,1,2,L.arm);
    if(tier>=2)r(-3+lean,-23+bob,8,1,L.trim);
    if(tier>=3){r(-1+lean,-28+bob,3,2,L.trim);}
  }else if(fem){
    // شعر طويل يتطاير خلفها
    r(-5+lean,-23+bob,4,6,L.hair); r(-6+lean-(run?1:0),-19+bob,3,6,L.hair);
    r(-7+lean-(run?2:0)+cw,-15+bob,3,5,L.hairD); r(-8+lean-(run?3:0)+cw,-11+bob,2,3,L.hairD);
    r(-2+lean,-22+bob,6,5,L.skin); r(-3+lean,-24+bob,7,3,L.hair); r(3+lean,-22+bob,1,2,L.hair);
    r(2+lean,-20+bob,1,1,'#2a1a2a'); r(1+lean,-18+bob,2,1,'#c9705a');
    if(ch==='mage'){            // قبعة الساحرة
      r(-5+lean,-24+bob,11,1,L.capeD);
      for(let i=0;i<7;i++)r(-3+lean+Math.round(i*0.5)-(i>4?i-4:0),-25+bob-i,7-i,1,i%3===1?L.capeD:L.cape);
      r(-3+lean,-25+bob,7,1,L.trim); r(0+lean,-28+bob,1,1,L.hi);
    }else{
      r(-2+lean,-23+bob,6,1,L.trim); r(1+lean,-24+bob,1,1,'#7fd4ff');
      if(tier>=2){r(0+lean,-25+bob,3,1,L.trim); r(1+lean,-26+bob,1,1,L.hi);}
      if(tier>=3){r(-2+lean,-25+bob,1,1,L.trim); r(4+lean,-25+bob,1,1,L.trim);}
    }
  }else{
    r(-3+lean,-23+bob,7,6,L.armL); r(-3+lean,-23+bob,2,6,L.arm); r(1+lean,-21+bob,3,1,'#0a0a0f');
    r(-3+lean,-23+bob,7,1,L.hi);
    r(-1+lean,-26+bob,3,3,L.trim); r(-3+lean-cw,-25+bob,2,2,L.cape); r(-5+lean-cw,-24+bob,2,1,L.cape);
    if(tier>=1){r(-1+lean,-27+bob,2,1,L.trim); r(-6+lean-cw,-25+bob,1,2,L.capeD);}
    if(tier>=2){pl(-3+lean,-23+bob,-5+lean,-27+bob,L.hi); pl(3+lean,-23+bob,5+lean,-27+bob,L.hi);}   // قرنا الخوذة
    if(tier>=3)r(0+lean,-22+bob,1,4,L.trim);
  }
  if(tier>=4){r(-2+lean,-31+bob,6,1,'#ffd76a'); r(-3+lean,-30+bob,1,1,'#ffd76a'); r(4+lean,-30+bob,1,1,'#ffd76a');}  // هالة
  // السلاح أو قارورة العلاج
  const hx=3+lean, hy=-13+bob;
  if(p.state==='heal'){
    r(2,-20+bob,3,4,'#4fd08a'); r(3,-21+bob,1,1,'#d8cfa8');
  }else{
    G.drawWeapon(p,hx,hy);
  }
  r(hx-2,hy-1,3,2,(ch==='knight'||ch==='warden'||ch==='smith'||ch==='ninja')?L.armD:L.skin);
  // درع الصدّ
  if(p.guard>0){
    const a=G.ctx.globalAlpha;
    G.ctx.globalAlpha=a*(0.6+0.3*Math.sin(time*20));
    for(let i=-9;i<=9;i++){const x=9-Math.round(i*i*0.07);r(x,-14+bob+i,2,1,i%3?'#7fd4ff':'#ffffff');}
    G.ctx.globalAlpha=a;
    G.glow('#7fd4ff',8,-14,0.7,0.7);
  }
};

/* ---------- رسم اللاعب في الساحة ---------- */
G.drawPlayer=function(){
  const p=G.P, k=G.ctx;
  // أطياف المراوغة والاندفاع
  for(const g of G.ghosts){
    G.alpha(clamp(g.life/0.22,0,1)*0.45);
    r(g.x-6,g.y-11,12,11,g.c||'#4aa3ff'); r(g.x-4,g.y-13,8,2,g.c||'#7fd4ff'); r(g.x-3,g.y-23,7,10,g.c||'#4aa3ff');
  }
  G.alpha(1);
  if(p.y>H+10)return;
  if(p.inv>0&&['dodge','dead','special','dash','flip','cast','vault'].indexOf(p.state)<0&&((S.time*20|0)%2))return;
  // توهج الطاقة + هالة الشكل الأعلى + الهيجان
  if(p.tier>=4&&p.state!=='dead')G.glow('#bfeaff',p.x,p.y-14,0.3+0.1*Math.sin(S.time*3));
  if(p.rage>0)G.glow('#ff3c28',p.x,p.y-14,0.7+0.2*Math.sin(S.time*14));
  if(p.state==='special'||(p.en>=CFG.energyMax&&p.state!=='dead')){
    G.glow('#ffe6a0',p.x,p.y-14,p.state==='special'?1:0.35+0.2*Math.sin(S.time*8));
  }
  if(p.slowT>0&&p.state!=='dead'){G.alpha(0.5);r(p.x-6,p.y-2,12,2,'#8fd8ff');r(p.x-4,p.y-4,2,2,'#ffffff');r(p.x+2,p.y-5,2,3,'#8fd8ff');G.alpha(1);}
  k.save();
  k.translate(Math.round(p.x),Math.round(p.y));
  k.scale(p.f,1);
  if(p.state==='flip'){k.translate(0,-12);k.rotate(-(0.4-p.t)/0.4*Math.PI*2);k.translate(0,12);}
  G.drawHero(p);
  k.restore();
  G.alpha(1);
  G.drawSpecialFx(p);
  // كلمة «كومبو» عند فرصة الخاتمة بعد الضربة الخاصة
  if(p.spChain&&p.csT>0&&p.state==='idle'&&(S.time*10|0)%2)G.txt('COMBO',p.x,p.y-34,'#ffd76a');
};

})(window.G);
