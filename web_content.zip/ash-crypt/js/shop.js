/* ================== shop.js — المتجر: الأسلحة · ترقية الشخصية · العملات ==================
   الذهب: يُجمع من المراحل والوحوش، ويشتري الشخصيات (من القائمة) وترقية أسلحتها ومستواها.
   الكريستال: من الصناديق والوحوش القوية والزعماء والإعلانات والشراء، ويُستبدل بذهب أو يُحيي اللاعب.

   مهم: الإعلانات والشراء هنا «تجريبية» (CFG.testMode). لربط إعلانات/دفع حقيقي عند تحويل اللعبة
   إلى تطبيق، عدّل الدالتين G.showAd و G.buyPack في آخر هذا الملف فقط.                        */
(function(G){
'use strict';
const $=G.$, CFG=G.CFG;
const shop=$('shop'), body=$('shopBody'), adBox=$('adBox');
const pvA=document.createElement('canvas'), pvB=document.createElement('canvas');
let tab='wpn';

// باقات تبديل الكريستال بالذهب، وباقات شراء الكريستال
const EXCH=[{c:5,g:400},{c:20,g:2000},{c:50,g:6000}];
const PACKS=[{id:'crys_s',c:30,price:'0.99$'},{id:'crys_l',c:200,price:'4.99$'}];

G.wpnUpCost=function(w){return 150*G.wlvOf(w.id);};

G.updWallet=function(){
  document.querySelectorAll('.wCoins').forEach(e=>e.textContent=G.save.coins);
  document.querySelectorAll('.wCrys').forEach(e=>e.textContent=G.save.crystals);
};
function pay(coins){
  if(G.save.coins<coins){G.snd('deny');return false;}
  G.addCoins(-coins); return true;
}
function ic(name,cls){return '<canvas class="ic '+(cls||'')+'" data-ic="'+name+'"></canvas>';}

/* ---------- تبويب الأسلحة: كل سلاح تابع لشخصيته، ويُرقّى إذا كانت الشخصية مملوكة ---------- */
function tabWeapons(){
  body.className='g52';
  body.innerHTML=G.CHARS.map(c=>{
    const i=G.WEAPONS.findIndex(w=>w.id===c.wpn), w=G.WEAPONS[i];
    const own=!!G.save.chars[c.id], lv=G.wlvOf(w.id), max=lv>=CFG.wpnMaxLv, cost=G.wpnUpCost(w);
    const dmg=Math.round(w.dmg*G.wpnMul(w.id)*10)/10;
    let b;
    if(!own)b='<span class="lk">اشترِ «'+c.name+'» من القائمة أولاً</span>';
    else if(max)b='<div class="pbtn max">MAX</div>';
    else b='<div class="pbtn'+(G.save.coins<cost?' no':'')+'" data-up="'+i+'">'+ic('up')+ic('coin')+cost+'</div>';
    return '<div class="card'+(G.save.char===c.id?' sel':'')+(own?'':' locked')+'">'+
      (G.save.char===c.id?'<span class="tag">سلاحك</span>':'')+
      ic(w.id,'big')+'<b>'+w.name+(own?' · م'+lv:'')+'</b>'+
      '<small>'+c.name+' · الضرر '+dmg+'<br>خاصة: '+w.sp+'</small>'+b+'</div>';
  }).join('');
}

/* ---------- تبويب الشخصية ---------- */
function heroPv(cv,tier){
  cv.width=44; cv.height=44;
  const c=cv.getContext('2d');
  c.imageSmoothingEnabled=false;
  G.setCtx(c);
  c.translate(18,39); c.scale(1.45,1.45);
  G.drawHero({ch:G.save.char,tier:tier,state:'idle',t:0,ground:true,vx:0,f:1,w:G.save.wpn,aw:G.save.wpn,sp:{},en:0});
  G.setCtx(null);
}
function tabHero(){
  const lv=G.save.plv, tier=G.tier(), max=lv>=CFG.maxLevel, cost=G.lvCost();
  const nextAt=(tier+1)*5;
  body.className='hero';
  body.innerHTML=
    '<div class="heroBox" id="hbA"><span>شكلك الآن: '+G.TIER_NAMES[tier]+'</span></div>'+
    '<div class="heroInfo"><b>المستوى '+lv+(max?' (الأقصى)':'')+'</b>'+
      '<span>الصحة '+G.maxHp()+(max?'':' ← '+(G.maxHp()+CFG.hpPerLevel))+
      ' · الضرر +'+Math.round((G.dmgMul()-1)*100)+'%'+(max?'':' ← +'+Math.round((G.dmgMul()-1+CFG.dmgPerLevel)*100)+'%')+
      '<br>قوارير العلاج: '+G.maxFlasks()+
      (tier<4?'<br>يتغير شكلك عند المستوى '+nextAt:'<br>وصلت إلى أفضل شكل')+'</span>'+
      (max?'<div class="pbtn max">MAX</div>':'<div class="pbtn'+(G.save.coins<cost?' no':'')+'" data-lv="1">'+ic('up')+'ترقية '+ic('coin')+cost+'</div>')+
    '</div>'+
    (tier<4?'<div class="heroBox next" id="hbB"><span>الشكل التالي: '+G.TIER_NAMES[tier+1]+'</span></div>':'');
  heroPv(pvA,tier); $('hbA').insertBefore(pvA,$('hbA').firstChild);
  if(tier<4){heroPv(pvB,tier+1); $('hbB').insertBefore(pvB,$('hbB').firstChild);}
}

/* ---------- تبويب العملات ---------- */
function tabCurrency(){
  body.className='g32';
  const test=CFG.testMode?'<small>(تجريبي)</small>':'';
  body.innerHTML=
    '<div class="card">'+ic('ad','big')+'<b>شاهد إعلاناً</b><small>واحصل على كريستال مجاناً '+test+'</small>'+
      '<div class="pbtn" data-ad="1">+'+CFG.adReward+' '+ic('crystal')+'</div></div>'+
    EXCH.map((e,i)=>'<div class="card">'+ic('coin','big')+'<b>'+e.g+' ذهب</b><small>بدّل الكريستال بذهب</small>'+
      '<div class="pbtn'+(G.save.crystals<e.c?' no':'')+'" data-ex="'+i+'">'+e.c+' '+ic('crystal')+'</div></div>').join('')+
    PACKS.map((p,i)=>'<div class="card">'+ic('crystal','big')+'<b>'+p.c+' كريستال</b><small>شراء '+test+'</small>'+
      '<div class="pbtn" data-pack="'+i+'">'+p.price+'</div></div>').join('');
}

function render(){
  shop.querySelectorAll('.tab').forEach(t=>t.classList.toggle('sel',t.getAttribute('data-tab')===tab));
  if(tab==='wpn')tabWeapons(); else if(tab==='hero')tabHero(); else tabCurrency();
  G.drawAllIcons(body);
  G.updWallet();
}
G.openShop=function(t){
  if(t)tab=t;
  shop.style.display='flex';
  render();
};
G.closeShop=function(){
  shop.style.display='none';
  G.doSave();
  if(G.refreshMenu)G.refreshMenu();
};

/* ---------- الأحداث ---------- */
shop.addEventListener('click',ev=>{
  const q=a=>{const e=ev.target.closest('['+a+']');return e?e.getAttribute(a):null;};
  let v;
  if((v=q('data-tab'))){tab=v;G.snd('click');render();return;}
  if((v=q('data-up'))!==null){
    const w=G.WEAPONS[+v];
    if(G.wlvOf(w.id)<CFG.wpnMaxLv&&pay(G.wpnUpCost(w))){G.save.wlv[w.id]=G.wlvOf(w.id)+1;G.snd('buy');G.doSave();}
    render(); return;
  }
  if(q('data-lv')){
    if(G.save.plv<CFG.maxLevel&&pay(G.lvCost())){
      const before=G.tier();
      G.save.plv++; G.doSave();
      G.snd(G.tier()>before?'levelup':'buy');
    }
    render(); return;
  }
  if((v=q('data-ex'))!==null){
    const e=EXCH[+v];
    if(G.save.crystals>=e.c){G.addCrystals(-e.c);G.addCoins(e.g);G.snd('buy');G.doSave();}else G.snd('deny');
    render(); return;
  }
  if(q('data-ad')){G.showAd(ok=>{if(ok){G.addCrystals(CFG.adReward);G.snd('crystal');G.doSave();}render();});return;}
  if((v=q('data-pack'))!==null){G.buyPack(PACKS[+v],ok=>{if(ok){G.addCrystals(PACKS[+v].c);G.snd('crystal');G.doSave();}render();});return;}
});
$('shopClose').addEventListener('click',()=>{G.snd('click');G.closeShop();});

/* ================== الإعلانات والشراء ==================
   cb(true) عند نجاح المشاهدة/الشراء و cb(false) عند الفشل.
   في الوضع التجريبي: إعلان وهمي مدته 3 ثوانٍ، والشراء يمنح الكريستال مباشرة دون دفع.
   للربط الحقيقي لاحقاً: عرّف window.AshAds.showRewarded(cb) و window.AshPay.buy(id,cb)
   من كود التطبيق (مثلاً AdMob و Google Play Billing) واجعل testMode=false في config.js. */
let adBusy=false;
G.showAd=function(cb){
  if(adBusy)return;
  if(!CFG.testMode){
    if(window.AshAds&&window.AshAds.showRewarded)window.AshAds.showRewarded(cb);
    else{G.snd('deny');cb(false);}
    return;
  }
  adBusy=true;
  adBox.style.display='flex';
  $('adTxt').textContent='إعلان تجريبي — هنا سيظهر الإعلان الحقيقي';
  const bar=adBox.querySelector('i'), t0=performance.now(), dur=3000;
  (function tick(){
    const u=Math.min(1,(performance.now()-t0)/dur);
    bar.style.width=(u*100)+'%';
    if(u<1)setTimeout(tick,50);
    else{adBox.style.display='none';adBusy=false;cb(true);}
  })();
};
G.buyPack=function(pack,cb){
  if(!CFG.testMode){
    if(window.AshPay&&window.AshPay.buy)window.AshPay.buy(pack.id,cb);
    else{G.snd('deny');cb(false);}
    return;
  }
  cb(true);    // تجريبي: بدون دفع حقيقي
};

})(window.G);
