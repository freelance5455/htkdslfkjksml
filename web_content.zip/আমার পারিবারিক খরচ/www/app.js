const $ = (id) => document.getElementById(id);
const STORE_KEY = 'family-expense-ledger-v1';
const PREF_KEY = 'family-expense-prefs-v1';
let entries = [];
let prefs = {lang:'bn', theme:'normal'};
let editingId = null;
const translations = {
  bn:{appTitle:'আমার পারিবারিক খরচ',tagline:'ব্যক্তিগত ও পরিবারের হিসাব',month:'মাস',themeNormal:'নরমাল',themeBlue:'গাঢ় নীল + লাইট',monthExpense:'এই মাসের মোট ব্যয়',personalExpense:'ব্যক্তিগত ব্যয়',familyExpense:'পারিবারিক ব্যয়',personal:'ব্যক্তিগত',family:'পারিবারিক',addEntry:'নতুন হিসাব যোগ করুন',entryHint:'খরচের পরিমাণ ও প্রয়োজনীয় নোট লিখুন',date:'তারিখ',amount:'টাকার পরিমাণ',accountType:'হিসাবের ধরন',category:'খরচের খাত',food:'বাজার ও খাবার',rent:'বাসা ভাড়া',utility:'বিদ্যুৎ/গ্যাস/পানি',transport:'যাতায়াত',health:'চিকিৎসা',education:'শিক্ষা',shopping:'কেনাকাটা',bills:'মোবাইল/ইন্টারনেট',other:'অন্যান্য',note:'নোট',saveEntry:'＋ হিসাব সংরক্ষণ',monthlyRecords:'মাসের হিসাব',recordsHint:'তারিখ অনুযায়ী সব খরচ ও নোট',noRecords:'এখনো কোনো হিসাব নেই',emptyHint:'উপরের ফর্ম থেকে প্রথম হিসাবটি যোগ করুন',yearlyReport:'বার্ষিক ব্যয়ের হিসাব',yearlyHint:'বছরজুড়ে মোট কত খরচ হয়েছে',yearTotal:'বছরের মোট ব্যয়',privacy:'আপনার হিসাব এই ফোনের অ্যাপ স্টোরেজেই থাকে। কোনো অনলাইন অ্যাকাউন্ট বা সার্ভারে পাঠানো হয় না।',footer:'আমার পারিবারিক খরচ · ব্যক্তিগত হিসাব, আপনার নিয়ন্ত্রণে',settings:'সেটিংস',settingsText:'থিম ও ভাষা উপরের বাটন থেকেও পরিবর্তন করা যাবে।',clearData:'সব হিসাব মুছে ফেলুন',clearWarning:'সতর্কতা: মুছে ফেললে হিসাব আর ফেরত পাওয়া যাবে না।',entries:'টি হিসাব',saved:'হিসাব সংরক্ষণ হয়েছে',updated:'হিসাব আপডেট হয়েছে',deleted:'হিসাব মুছে ফেলা হয়েছে',confirmDelete:'এই হিসাবটি মুছে ফেলবেন?',confirmClear:'সব হিসাব স্থায়ীভাবে মুছে ফেলবেন?',edit:'এডিট',delete:'মুছুন',noNote:'কোনো নোট নেই',monthNames:['জানু','ফেব্রু','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগ','সেপ্টে','অক্টো','নভে','ডিসে'],choose:'নির্বাচন করুন'},
  en:{appTitle:'My Family Expenses',tagline:'Personal and household ledger',month:'Month',themeNormal:'Normal',themeBlue:'Deep blue + light',monthExpense:'Total this month',personalExpense:'Personal expenses',familyExpense:'Family expenses',personal:'Personal',family:'Family',addEntry:'Add a new entry',entryHint:'Enter the amount and a useful note',date:'Date',amount:'Amount',accountType:'Account type',category:'Expense category',food:'Groceries & food',rent:'House rent',utility:'Electricity/gas/water',transport:'Transport',health:'Healthcare',education:'Education',shopping:'Shopping',bills:'Phone/internet',other:'Other',note:'Note',saveEntry:'＋ Save entry',monthlyRecords:'Monthly records',recordsHint:'All expenses and notes by date',noRecords:'No entries yet',emptyHint:'Add your first entry using the form above',yearlyReport:'Yearly expense report',yearlyHint:'Total spending throughout the year',yearTotal:'Total expenses this year',privacy:'Your records stay in this phone app storage. They are not sent to an online account or server.',footer:'My Family Expenses · Your records, under your control',settings:'Settings',settingsText:'You can also change theme and language using the buttons above.',clearData:'Delete all records',clearWarning:'Warning: deleted records cannot be recovered.',entries:'entries',saved:'Entry saved',updated:'Entry updated',deleted:'Entry deleted',confirmDelete:'Delete this entry?',confirmClear:'Permanently delete all records?',edit:'Edit',delete:'Delete',noNote:'No note',monthNames:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],choose:'Select'}
};
function t(key){return (translations[prefs.lang]||translations.bn)[key]||key}
function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function money(n){const locale=prefs.lang==='bn'?'bn-BD':'en-US';return new Intl.NumberFormat(locale,{style:'currency',currency:'BDT',maximumFractionDigits:2}).format(Number(n)||0)}
function load(){try{entries=JSON.parse(localStorage.getItem(STORE_KEY)||'[]')}catch{entries=[]}try{prefs={...prefs,...JSON.parse(localStorage.getItem(PREF_KEY)||'{}')}}catch{}}
function save(){localStorage.setItem(STORE_KEY,JSON.stringify(entries));localStorage.setItem(PREF_KEY,JSON.stringify(prefs))}
function applyPrefs(){
 document.documentElement.lang=prefs.lang;document.body.classList.toggle('theme-blue',prefs.theme==='blue');
 document.querySelectorAll('[data-i18n]').forEach(el=>{const key=el.dataset.i18n;if(translations[prefs.lang][key])el.textContent=t(key)});
 $('langBtn').textContent=prefs.lang==='bn'?'EN':'বাংলা';$('themeBtn').textContent=prefs.theme==='blue'?t('themeBlue'):t('themeNormal');
 document.title=t('appTitle');render();
}
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2100)}
function monthKey(date){return date.slice(0,7)}
function categoryName(cat){return t(cat)}
function render(){
 const selected=$('monthPicker').value||todayISO().slice(0,7);
 const monthly=entries.filter(e=>monthKey(e.date)===selected).sort((a,b)=>b.date.localeCompare(a.date)||b.created-b.created);
 const sum=(arr)=>arr.reduce((s,e)=>s+Number(e.amount),0);
 $('monthTotal').textContent=money(sum(monthly));$('personalTotal').textContent=money(sum(monthly.filter(e=>e.type==='personal')));$('familyTotal').textContent=money(sum(monthly.filter(e=>e.type==='family')));
 $('monthCount').textContent=`${monthly.length} ${t('entries')}`;$('recordCount').textContent=monthly.length;
 $('records').innerHTML=monthly.map(e=>`<article class="record"><div class="record-main"><div class="record-title">${escapeHtml(categoryName(e.category))} · ${escapeHtml(e.type==='personal'?t('personal'):t('family'))}</div><div class="record-meta">${escapeHtml(e.date)}</div><div class="record-note">${escapeHtml(e.note||t('noNote'))}</div></div><div class="record-right"><div class="record-amount">${money(e.amount)}</div><div class="record-actions"><button data-edit="${e.id}">${t('edit')}</button><button data-delete="${e.id}">${t('delete')}</button></div></div></article>`).join('');
 $('emptyState').style.display=monthly.length?'none':'block';
 renderYear();
}
function renderYear(){
 const year=Number($('yearPicker').value)||new Date().getFullYear();
 const yearly=entries.filter(e=>Number(e.date.slice(0,4))===year);
 const sum=(arr)=>arr.reduce((s,e)=>s+Number(e.amount),0);
 $('yearTotal').textContent=money(sum(yearly));$('yearPersonal').textContent=money(sum(yearly.filter(e=>e.type==='personal')));$('yearFamily').textContent=money(sum(yearly.filter(e=>e.type==='family')));
 const monthTotals=Array.from({length:12},(_,i)=>sum(yearly.filter(e=>Number(e.date.slice(5,7))===i+1)));
 const max=Math.max(...monthTotals,1);
 $('yearMonths').innerHTML=monthTotals.map((v,i)=>`<div class="bar-row"><span>${t('monthNames')[i]}</span><div class="bar-track"><div class="bar-fill" style="width:${v/max*100}%"></div></div><span class="bar-value">${money(v)}</span></div>`).join('');
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function initYears(){const y=new Date().getFullYear();$('yearPicker').innerHTML=Array.from({length:11},(_,i)=>`<option value="${y-5+i}">${y-5+i}</option>`).join('');$('yearPicker').value=y}
$('entryForm').addEventListener('submit',e=>{
 e.preventDefault();const amount=Number($('amount').value);if(!Number.isFinite(amount)||amount<=0){toast(t('amount'));return}
 const item={id:editingId||`${Date.now()}-${Math.random().toString(16).slice(2)}`,date:$('entryDate').value,amount,type:$('accountType').value,category:$('category').value,note:$('note').value.trim(),created:Date.now()};
 if(editingId){entries=entries.map(x=>x.id===editingId?item:x);toast(t('updated'))}else{entries.push(item);toast(t('saved'))}
 editingId=null;save();$('entryForm').reset();$('entryDate').value=todayISO();$('monthPicker').value=todayISO().slice(0,7);$('saveEntry').textContent=t('saveEntry');applyPrefs();
});
$('records').addEventListener('click',e=>{
 const edit=e.target.dataset.edit,del=e.target.dataset.delete;
 if(edit){const item=entries.find(x=>x.id===edit);if(!item)return;editingId=item.id;$('entryDate').value=item.date;$('amount').value=item.amount;$('accountType').value=item.type;$('category').value=item.category;$('note').value=item.note;$('saveEntry').textContent=prefs.lang==='bn'?'আপডেট করুন':'Update entry';window.scrollTo({top:0,behavior:'smooth'})}
 if(del&&confirm(t('confirmDelete'))){entries=entries.filter(x=>x.id!==del);save();render();toast(t('deleted'))}
});
$('monthPicker').addEventListener('change',render);$('yearPicker').addEventListener('change',render);
$('langBtn').addEventListener('click',()=>{prefs.lang=prefs.lang==='bn'?'en':'bn';save();applyPrefs()});
$('themeBtn').addEventListener('click',()=>{prefs.theme=prefs.theme==='normal'?'blue':'normal';save();applyPrefs()});
$('settingsBtn').addEventListener('click',()=>$('settingsDialog').showModal());$('closeSettings').addEventListener('click',()=>$('settingsDialog').close());
$('clearData').addEventListener('click',()=>{if(confirm(t('confirmClear'))){entries=[];save();render();$('settingsDialog').close();toast(t('deleted'))}});
load();$('entryDate').value=todayISO();$('monthPicker').value=todayISO().slice(0,7);initYears();applyPrefs();
if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
