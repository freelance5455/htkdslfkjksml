# ANONYMOUX STUDIO 2.5.2 — Source Audit and Repair Report

## Scope and disposition

This is a source-level repair candidate based on the uploaded `ANONYMOUX_STUDIO_2.5.1_SQLITE_PDO_AGENT_CSRF_FIX.zip`. The existing application and workspace files have been retained. This report deliberately distinguishes source inspection and local tests from live provider or shared-host tests.

**This archive is not certified as fully production-ready.** The host used for this audit does not have `pdo_sqlite` or `curl`, so the PHP application could not be booted against its actual PDO SQLite driver, and no live Decart, Fish Audio, Magic Hour, Flutterwave, camera, WebRTC or InfinityFree acceptance tests could be performed. Several requested modules still need further end-to-end validation and repair.

## Original source inventory

- 220 original ZIP entries.
- 80 PHP files.
- 12 JavaScript files.
- 13 CSS files.
- 8 SQL migration files.
- 6 existing Python regression checks.
- Existing app modules include Image, Video, Realtime, Voice, Agent, Lip Sync, Flutterwave, user authentication, admin, resources, notifications and history.

## Confirmed findings

1. `api/image-generate.php` called Decart but had no wallet debit, reservation, ledger entry or refund.
2. `api/video-jobs.php` submitted and polled Decart jobs but had no wallet debit, reservation, ledger entry or refund.
3. The wallet implementation was primarily voice-specific. It was not a shared billing service for Image and Video.
4. Image output handling accepted only PNG even though the Decart image editing documentation demonstrates image output and does not constrain all returned output to PNG in the integration example.
5. Bootstrap used `HTTP_HOST` to construct an HTTPS redirect and trusted `X-Forwarded-Proto` without checking whether the request came from a trusted proxy.
6. Flutterwave checkout redirect construction used the request `HTTP_HOST`.
7. The local PHP CLI has `PDO` but does not list `pdo_sqlite` or `curl`. The existing smoke test correctly fails with the explicit SQLite extension requirement.

## Changes made

### Shared credits

- Added `app/credits.php`.
- Added the SQLite `credit_operations` table with a unique job identifier and constrained states: `reserved`, `settled`, `refunded`.
- Added atomic wallet reservation using SQLite `BEGIN IMMEDIATE`.
- Added conditional debit to prevent negative balances.
- Added ledger entries for reservations and refunds.
- Added idempotent settlement and refund handling.
- Added database-backed Image and Video price settings.
- Added administrator controls in Admin → Models for Image and Video prices.
- New billable Image and Video jobs fail closed until an administrator sets both prices.
- Image jobs settle after a valid output is stored.
- Video jobs remain reserved while processing, settle after valid output storage, and refund on a confirmed provider failure.
- Provider transport errors, 5xx responses, and malformed job acknowledgements are treated as uncertain outcomes; reservations are retained rather than enabling a duplicate paid submission.

### Image Studio

- Added authentication-backed user identity to billing.
- Added wallet reservation before provider submission.
- Added persisted job identity before provider submission.
- Added confirmed 4xx rejection refunds.
- Added uncertain-outcome retention.
- Added valid JPEG, PNG and WebP output recognition and matching file extensions/MIME metadata.
- Added settlement after output and asset persistence.
- Preserved the existing Decart image endpoint and model identifier.

### Video Studio

- Added required non-empty prompt and source video validation.
- Added wallet reservation before provider submission.
- Added local job identity and reservation record before the provider call.
- Added provider rejection refund and upload cleanup.
- Added reservation retention for uncertain provider submission.
- Added confirmed failed/cancelled provider job refunds.
- Added completion settlement only after output storage.
- Added output validation and failure cleanup.
- Preserved the Lucy 2.5 / Lucy 2.6 model choices and existing job-status/content URL pattern.

### Host and redirect hardening

- Added an uncaught-exception handler with a clear PDO SQLite requirement message, including JSON output for API routes.
- Stopped trusting arbitrary `X-Forwarded-Proto`; forwarded protocol is accepted only for configured trusted proxy IPs.
- Stopped deriving HTTPS redirects from `HTTP_HOST`.
- Added `canonical_base_url` and `trusted_proxy_ips` to the example configuration.
- Flutterwave checkout now uses the configured HTTPS canonical URL or validated server name rather than the incoming `HTTP_HOST`.

## Decart documentation check

The current official Decart documentation index was inspected. It lists Lucy 2.5 Realtime, Lucy 2.6 Realtime, Lucy Image 2, the Lucy 2.5 and 2.6 API references, job retrieval/content endpoints, and client-token documentation.

The current Lucy 2.5 API reference confirms `POST /v1/jobs/lucy-2.5`, `x-api-key`, multipart `data`, optional prompt/reference image, seed, `720p`, `enhance_prompt`, and `self_anchor`. The image-editing documentation confirms `POST /v1/generate/lucy-image-2`, `data`, `prompt`, optional `reference_image`, and 480p/720p output options. The current video-editing guide demonstrates queue submission, job polling and content retrieval.

The existing model identifiers and endpoint patterns were retained rather than guessed or silently changed. A successful live API call was not possible in this environment. The exact Lucy 2.6 batch schema and the account-specific model entitlements still require validation with the user's Decart account. References: https://docs.platform.decart.ai/llms.txt ; https://docs.platform.decart.ai/api-reference/lucy-25 ; https://docs.platform.decart.ai/models/image/image-editing ; https://docs.platform.decart.ai/models/video/video-editing

## Files modified or added

Modified:
- `app/bootstrap.php`
- `app/admin.php`
- `app/payments.php`
- `api/image-generate.php`
- `api/video-jobs.php`
- `admin.php`
- `config.local.example.php`

Added:
- `app/credits.php`
- `tests/billing_sqlite_contract_check.py`
- `tests/billing_source_check.py`
- `PRODUCTION_REPAIR_REPORT_2.5.2.md`
- `UPGRADE_2.5.2.md`

No original application files or migrations were removed. The original MySQL compatibility branches and MySQL migration files remain in the source tree; they are not used by the SQLite-only bootstrap, but their removal and a full module-by-module SQLite-only cleanup remain outstanding.

## Automated test results

- PHP syntax: all 81 PHP files in the corrected archive pass `php -l`.
- JavaScript syntax: all 12 JavaScript files pass `node --check`.
- Existing Python regression checks: 6/6 exited successfully.
- New billing source wiring checks: 10/10 assertions passed for reservation-before-provider ordering, settlement, refund branches, uncertain-outcome retention, admin price controls and fail-closed pricing.
- New SQLite billing contract check: 3/3 tests passed using Python's SQLite engine (atomic reserve/refund, duplicate reservation rejection, insufficient-balance rollback, idempotent refund and settled-operation refund rejection).

**Not run successfully:** `tests/smoke.php` requires `pdo_sqlite` and fails on this audit host with the expected message. PHP PDO integration tests, concurrent PHP wallet requests, full auth/session tests, provider mocks through PHP cURL, and all live provider/hosting tests remain unverified.

## Outstanding work before production acceptance

1. Remove MySQL compatibility branches throughout `app/`, not only migration files.
2. Complete a single versioned migration runner and verify upgrades against a copy of a real 2.5.1 database.
3. Add automated PHP PDO tests for wallet concurrency, rollback and idempotency on a PHP runtime with `pdo_sqlite`.
4. Add a durable reconciliation path for image/video reservations where the provider request outcome is uncertain.
5. Validate image and video pricing against actual Decart account pricing and configure the intended 100% markup; no provider costs were assumed in this build.
6. Audit and unify charging for Magic Hour, Fish Audio, agent sessions and any other billable modules; their current billing implementations are not all routed through the new shared Image/Video billing service.
7. Complete the requested Agent ownership/public knowledge-source security audit and upload validation review.
8. Complete Realtime camera/WebRTC session lifecycle tests on supported mobile browsers.
9. Complete Flutterwave webhook and payment verification tests using provider test credentials.
10. Run the full application on the actual target InfinityFree account and verify PHP extensions, writable storage, outbound HTTPS/cURL, upload limits, request size limits, execution time and `.htaccess` behavior.
11. Complete a full source-level security review and cleanup of obsolete/unused files and duplicated logic.

## Deployment warning

Do not overwrite the live `config.local.php`, production SQLite database, encrypted key material, user media or storage directory when upgrading. Back up the database and storage first. Configure `canonical_base_url`, `admin_api_encryption_key`, Decart and other provider credentials privately. Enable PHP `pdo_sqlite`, `fileinfo`, `openssl`, and `curl` where needed. See `UPGRADE_2.5.2.md`.
