# Monstruos de Bolsillo — Supervivencia V2

## Qué cambió
- **Esquiva táctica:** botón circular durante la partida. En PC también funciona con Espacio o Shift. Desplaza rápidamente al personaje, concede una ventana breve de invulnerabilidad y daña una vez a cada enemigo atravesado. Recarga: 3,6 segundos.
- **Racha de derribos:** derrotar enemigos seguidos dentro de una ventana de 4 segundos acumula hasta 10 puntos de racha. Cada punto aumenta el daño un 1,2% (máximo +12%). Si la racha expira, vuelve a cero.
- **HUD de racha y recarga:** comunica los estados con texto y un botón pequeño, sin llenar el campo de círculos o partículas adicionales.
- **Caché PWA mp19:** fuerza la actualización de los archivos guardados por el service worker.
- Conserva los personajes, enemigos, jefes por fases, habilidades, fusiones, progreso y mejoras permanentes existentes.

## Ronda 15 (resumen)
- Oleadas temáticas rotativas, menos jefes antes de la 20 y corrección de los jefes tras la 20. Detalles en CAMBIOS.md. Pruebas: `node tests_ronda15.js`.

## Ronda 16 (resumen)
- Daño de enemigos y jefes sigue escalando tras la 30, tope por golpe del 40% de la vida y etapas de temas cada 10 oleadas. Detalles en CAMBIOS.md. Pruebas: `node tests_ronda16.js`.

## Ronda 17 (resumen)
- Un fondo distinto y más llamativo por cada etapa de 10 oleadas. Detalles en CAMBIOS.md.

## Controles
- **Android:** arrastra sobre el campo de juego para moverte; el personaje ataca automáticamente. Toca **ESQUIVAR** para atravesar una zona peligrosa.
- **Teclado:** WASD o flechas para moverte; Espacio o Shift para esquivar; Escape para pausar.

## Ejecutar
Descomprime el ZIP y abre `index.html` en un navegador moderno. Para instalarlo como PWA y probar el service worker, sírvelo desde un servidor HTTP/HTTPS; abrir el HTML como archivo local puede impedir el funcionamiento de la caché offline.

## Pruebas
- `tests.js`: 153 comprobaciones.
- `tests_reparacion.js`: 18 comprobaciones.
- `tests_ronda10.js`: 18 comprobaciones.
- `tests_ronda11.js`: 27 comprobaciones.
- `tests_ronda12.js`: 11 comprobaciones.
- `tests_ronda13.js`: 74 comprobaciones.
- `tests_ronda14.js`: 6 comprobaciones nuevas de esquiva, racha y caché.

Las suites se ejecutan con Node.js desde esta carpeta, por ejemplo: `node tests_ronda14.js`.
