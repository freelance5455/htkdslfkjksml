NEXUS TAEKWONDO — CUSTOMER PHONE APP (LINKED)

This is the CUSTOMER-ONLY phone app.

To connect it to the PC Staff app:
1. Start the PC Staff app/server first.
2. Put the phone and PC on the same Wi-Fi.
3. Open this index.html on the phone using a local web server/browser method, or use the customer URL served by the PC server.
4. Enter the PC server URL and the 6-digit pairing code.
5. Tap Connect / Sync.
6. Log in using the Customer ID and PIN provided by NEXUS TAEKWONDO staff.

Customer features include membership card, profile, bookings, attendance, payments, support and PIN change.
