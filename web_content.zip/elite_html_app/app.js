const WB=window.WB; const state={active:0, data:JSON.parse(JSON.stringify(WB)), formulaCache:{}};
const $=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>\"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\\':'&#92;'}[m]));
function sheet(n){return state.data.sheets.find(s=>s.name===n)}
function colToNum(c){let n=0;for(const x of c.toUpperCase())n=n*26+x.charCodeAt(0)-64;return n}
function numToCol(n){let s='';while(n){let r=(n-1)%26;s=String.fromCharCode(65+r)+s;n=Math.floor((n-1)/26)}return s}
function addr(r,c){return numToCol(c)+r}
function baseCellRef(tok){tok=tok.replace(/\$/g,'');const m=tok.match(/^([A-Za-z]+)(\d+)$/);return m?{col:colToNum(m[1]),row:+m[2]}:null}
function rawValue(sn,a){const s=sheet(sn||state.data.sheets[state.active].name); if(!s)return ''; return s.values[a]??''}
function setRaw(sn,a,v){const s=sheet(sn);s.values[a]=v;s.cells[a]=v}
function cellVal(sn,a,stack){const s=sheet(sn); if(!s)return '';
  if(s.formulas[a]){const key=sn+'!'+a;if(stack&&stack.has(key))return '';stack=stack||new Set();stack.add(key);try{return evalFormula(s.formulas[a],sn,stack)}catch(e){return ''}finally{stack.delete(key)}}
  return s.values[a]??'';
}
function rangeVals(sn,r1,c1,r2,c2,stack){const out=[];for(let r=r1;r<=r2;r++)for(let c=c1;c<=c2;c++)out.push(cellVal(sn,addr(r,c),stack));return out}
function parseRef(t,curSheet,stack){t=t.trim();let sn=curSheet; if(t.includes('!')){const i=t.lastIndexOf('!');sn=t.slice(0,i).replace(/^'|'$/g,'');t=t.slice(i+1)}t=t.replace(/\$/g,'');if(t.includes(':')){const [a,b]=t.split(':');const x=baseCellRef(a),y=baseCellRef(b);return rangeVals(sn,x.row,x.col,y.row,y.col,stack)}const x=baseCellRef(t);return x?cellVal(sn,addr(x.row,x.col),stack):''}
function tokenize(s){const a=[];let i=0;while(i<s.length){let ch=s[i];if(/\s/.test(ch)){i++;continue}if(ch==='"'){let j=i+1,v='';while(j<s.length){if(s[j]==='"'&&s[j+1]==='"'){v+='"';j+=2;continue}if(s[j]==='"')break;v+=s[j++]}a.push({t:'str',v});i=j+1;continue}if(ch==="'"){let j=i+1,v='';while(j<s.length&&s[j]!=="'")v+=s[j++];if(s[j]==="'")j++;if(s[j]==='!')j++;let k=j;while(k<s.length&&!/[(),+\-*/^&=<>]/.test(s[k]))k++;a.push({t:'ref',v:v+'!'+s.slice(j,k).trim()});i=k;continue}let two=s.slice(i,i+2);if(['<=','>=','<>'].includes(two)){a.push({t:'op',v:two});i+=2;continue}if('(),+-*/^&=<>'.includes(ch)){a.push({t:ch==='('? 'lp':ch===')'?'rp':ch===','?'comma':'op',v:ch});i++;continue}let j=i;while(j<s.length&&!/[\s(),+\-*/^&=<>]/.test(s[j]))j++;let v=s.slice(i,j);if(/^\d+(\.\d+)?$/.test(v))a.push({t:'num',v:+v});else a.push({t:'id',v});i=j}return a}
function evalFormula(f,curSheet,stack){let s=f.replace(/^=/,'');const t=tokenize(s);let p=0;
 function primary(){let x=t[p++];if(!x)return '';if(x.t==='num'||x.t==='str')return x.v;if(x.t==='lp'){let v=expr();p++;return v}if(x.t==='id'||x.t==='ref'){
   if(x.t==='id'&&t[p]&&t[p].t==='lp'){p++;let args=[];if(t[p]&&t[p].t!=='rp'){while(true){args.push(expr());if(t[p]&&t[p].t==='comma'){p++;continue}break}}if(t[p]&&t[p].t==='rp')p++;return fn(x.v.toUpperCase(),args)}
   if(x.t==='id'&&/^(TRUE|FALSE)$/.test(x.v.toUpperCase()))return x.v.toUpperCase()==='TRUE';
   return parseRef(x.v,curSheet,stack)
 }
 function unary(){if(t[p]&&t[p].t==='op'&&(t[p].v==='+'||t[p].v==='-')){let op=t[p++].v,v=unary();return op==='-'?-toNum(v):toNum(v)}return primary()}
 function power(){let v=unary();while(t[p]&&t[p].t==='op'&&t[p].v==='^'){p++;v=Math.pow(toNum(v),toNum(unary()))}return v}
 function term(){let v=power();while(t[p]&&t[p].t==='op'&&['*','/'].includes(t[p].v)){let op=t[p++].v,b=power();if(Array.isArray(v)||Array.isArray(b)){let A=Array.isArray(v)?v:[v],B=Array.isArray(b)?b:[b],n=Math.max(A.length,B.length);v=Array.from({length:n},(_,i)=>op==='*'?toNum(A[i%A.length])*toNum(B[i%B.length]):toNum(A[i%A.length])/toNum(B[i%B.length]||1))}else v=op==='*'?toNum(v)*toNum(b):toNum(v)/toNum(b)}return v}
 function add(){let v=term();while(t[p]&&t[p].t==='op'&&['+','-','&'].includes(t[p].v)){let op=t[p++].v,b=term();if(op==='&')v=String(scalar(v))+String(scalar(b));else v=op==='+'?toNum(v)+toNum(b):toNum(v)-toNum(b)}return v}
 function cmp(){let v=add();while(t[p]&&t[p].t==='op'&&['=','<>','<','>','<=','>='].includes(t[p].v)){let op=t[p++].v,b=add();if(Array.isArray(v)||Array.isArray(b)){let A=Array.isArray(v)?v:[v],B=Array.isArray(b)?b:[b],n=Math.max(A.length,B.length);v=Array.from({length:n},(_,i)=>compare(A[i%A.length],B[i%B.length],op))}else v=compare(v,b,op)}return v}
 function expr(){return cmp()}
 return scalar(expr())}
function scalar(v){return Array.isArray(v)?(v.length?v[0]:''):v}function toNum(v){v=scalar(v);if(v===true)return 1;if(v===false)return 0;let n=Number(v);return isFinite(n)?n:0}function flat(v){return Array.isArray(v)?v.flat(Infinity):[v]}function compare(a,b,op){if(op==='=')return String(a)==String(b);if(op==='<>')return String(a)!=String(b);a=toNum(a);b=toNum(b);return op==='<'?a<b:op==='>'?a>b:op==='<='?a<=b:a>=b}
function fn(n,a){
 try{switch(n){case'IF':return truth(a[0])?scalar(a[1]):scalar(a[2]);case'IFERROR':return a[0];case'N':return toNum(a[0]);case'OR':return a.some(truth);case'AND':return a.every(truth);case'SUM':return flat(a).reduce((x,v)=>x+toNum(v),0);case'COUNT':return flat(a).filter(v=>v!==''&&!isNaN(Number(v))).length;case'COUNTA':return flat(a).filter(v=>v!==''&&v!=null).length;case'MAX':return Math.max(...flat(a).map(toNum));case'MIN':return Math.min(...flat(a).map(toNum));case'ROW':{const m=String(a[0]??'').match(/(\d+)$/);return m?+m[1]:0}case'ISNUMBER':return scalar(a[0])!==''&&!isNaN(Number(scalar(a[0])));case'SEARCH':{const needle=String(scalar(a[0])).toLowerCase(),hay=String(scalar(a[1])).toLowerCase(),idx=hay.indexOf(needle);if(idx<0)throw Error();return idx+1}case'TODAY':return new Date().toISOString().slice(0,10);case'TEXT':{const v=scalar(a[0]),fmt=String(scalar(a[1]));if(fmt==='0')return String(Math.round(toNum(v)));return String(v)}case'INDEX':{const ar=flat(a[0]),row=Math.max(1,toNum(a[1]));if(Array.isArray(a[0]))return ar[row-1]??'';return ''}case'MATCH':{const needle=scalar(a[0]),ar=flat(a[1]);for(let i=0;i<ar.length;i++)if(String(ar[i])===String(needle))return i+1;throw Error()}case'VLOOKUP':{const key=scalar(a[0]),table=a[1],idx=Math.max(1,toNum(a[2]));const rows=to2D(a[1]);for(const r of rows)if(String(r[0])===String(key))return r[idx-1]??'';throw Error()}case'SUMIF':{const crit=scalar(a[1]),c=flat(a[0]),sum=flat(a[2]??a[0]);let z=0;for(let i=0;i<c.length;i++)if(matchCrit(c[i],crit))z+=toNum(sum[i]);return z}case'COUNTIF':{const c=flat(a[0]),crit=scalar(a[1]);return c.filter(v=>matchCrit(v,crit)).length}case'SUMIFS':{const sum=flat(a[0]);let z=0;for(let i=0;i<sum.length;i++){let ok=true;for(let j=1;j<a.length;j+=2){if(!matchCrit(flat(a[j])[i],scalar(a[j+1]))){ok=false;break}}if(ok)z+=toNum(sum[i])}return z}case'SUMPRODUCT':{const arr=a.map(flat),n=Math.max(...arr.map(x=>x.length));let z=0;for(let i=0;i<n;i++){let p=1;for(const ar of arr)p*=toNum(ar[i%ar.length]);z+=p}return z}case'LOOKUP':{const key=scalar(a[0]),v=flat(a[1]),r=flat(a[2]);let best=-1;for(let i=0;i<v.length;i++)if(toNum(v[i])<=toNum(key)||String(v[i])===String(key))best=i;return best>=0?r[best]:''}case'CHOOSE':return a[toNum(a[0])];case'IFERROR':return a[0];case'HYPERLINK':return scalar(a[1]??a[0]);case'DATE':return new Date(toNum(a[0]),toNum(a[1])-1,toNum(a[2])).toISOString().slice(0,10);default:return ''}}
 catch(e){return ''}}
function truth(v){v=scalar(v);return !(v===''||v===false||v===0||v==null)}function matchCrit(v,c){c=String(c);if(c.startsWith('>='))return toNum(v)>=toNum(c.slice(2));if(c.startsWith('<='))return toNum(v)<=toNum(c.slice(2));if(c.startsWith('<>'))return String(v)!==c.slice(2);if(c.startsWith('>'))return toNum(v)>toNum(c.slice(1));if(c.startsWith('<'))return toNum(v)<toNum(c.slice(1));return String(v)===c}
function to2D(v){return Array.isArray(v)?[v]:[[v]]}
function recalc(){for(let pass=0;pass<3;pass++)for(const s of state.data.sheets)for(const [a,f] of Object.entries(s.formulas)){let v;try{v=evalFormula(f,s.name,new Set())}catch(e){v=''}s.values[a]=v}}
function mergedMap(s){const m={};for(const r of s.merged){const x=r.match(/([A-Z]+)(\d+):([A-Z]+)(\d+)/);if(!x)continue;const c1=colToNum(x[1]),r1=+x[2],c2=colToNum(x[3]),r2=+x[4];m[addr(r1,c1)]={rs:r2-r1+1,cs:c2-c1+1};for(let r=r1;r<=r2;r++)for(let c=c1;c<=c2;c++)if(!(r===r1&&c===c1))m[addr(r,c)]={skip:true}}return m}
function render(){
  recalc();
  const tabs=$('tabs'), wrap=$('sheetwrap');
  tabs.innerHTML=''; wrap.innerHTML='';
  state.data.sheets.forEach((s,si)=>{
    const b=document.createElement('button'); b.className='tab'+(si===state.active?' active':''); b.textContent=s.name;
    b.onclick=()=>{state.active=si;render()}; tabs.appendChild(b);
    const div=document.createElement('div'); div.className='sheet'+(si===state.active?' active':''); div.dataset.sheet=s.name;
    const title=(s.values.A1||'').toString();
    if(title) div.innerHTML='<div class="titlebar">'+esc(title)+'</div><div class="note">Formula-driven workbook converted from Excel. Amber cells are editable inputs.</div>';
    const table=document.createElement('table'); table.className='grid';
    const merge=mergedMap(s), colWidths=[];
    for(let c=1;c<=s.maxCol;c++){const w=s.widths[numToCol(c)]||12;colWidths.push(Math.max(55,Math.min(320,w*7)))}
    const thead=document.createElement('thead'), hr=document.createElement('tr');
    for(let c=1;c<=s.maxCol;c++){const th=document.createElement('th');th.textContent=numToCol(c);th.style.width=colWidths[c-1]+'px';if(s.hiddenCols.includes(numToCol(c)))th.style.display='none';hr.appendChild(th)}
    thead.appendChild(hr); table.appendChild(thead);
    const tb=document.createElement('tbody');
    for(let r=1;r<=s.maxRow;r++){
      const tr=document.createElement('tr'); tr.style.height=((s.heights[String(r)]||20))+'px';
      for(let c=1;c<=s.maxCol;c++){
        const a=addr(r,c), mm=merge[a]; if(mm&&mm.skip) continue;
        const td=document.createElement('td'), st=s.styles[a]||{};
        td.style.cssText=(st.css||'')+';width:'+colWidths[c-1]+'px';
        if(s.hiddenCols.includes(numToCol(c)))td.style.display='none';
        if(mm){if(mm.cs>1)td.colSpan=mm.cs;if(mm.rs>1)td.rowSpan=mm.rs}
        const isF=!!s.formulas[a], isAmber=(st.css||'').toUpperCase().includes('#FFF8E7');
        if(isF)td.classList.add('formula');
        if(isAmber&&!isF){
          td.classList.add('amber','editable'); td.contentEditable='true'; td.dataset.addr=a;
          td.addEventListener('blur',()=>{let v=td.textContent.trim();if(v!==''&&!isNaN(Number(v))&&/0\.0|0%|#,##0|0\.00|0\.0/.test(st.fmt||''))v=Number(v);setRaw(s.name,a,v);saveLocal();render()});
        }
        let v=s.values[a]; if(v==null)v='';
        if(typeof v==='number'&&st.fmt&&st.fmt.includes('%'))v=(v*100).toFixed(1)+'%';
        else if(typeof v==='number'&&st.fmt&&/\$|#,##0/.test(st.fmt))v=v.toLocaleString(undefined,{maximumFractionDigits:2});
        td.textContent=String(v); if(mm&&mm.cs>1)td.classList.add('wrap'); tr.appendChild(td);
      }
      tb.appendChild(tr);
    }
    table.appendChild(tb); div.appendChild(table); wrap.appendChild(div);
  });
}

function saveLocal(){localStorage.setItem('elitePortfolioData',JSON.stringify(state.data));$('status').textContent='Saved locally';setTimeout(()=>$('status').textContent='Ready',1200)}function loadLocal(){const x=localStorage.getItem('elitePortfolioData');if(x){try{state.data=JSON.parse(x)}catch(e){}}}}
$('save').onclick=saveLocal;$('reset').onclick=()=>{localStorage.removeItem('elitePortfolioData');state.data=JSON.parse(JSON.stringify(WB));render()};$('search').oninput=e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('.sheet.active tbody tr').forEach(tr=>tr.style.display=!q||tr.textContent.toLowerCase().includes(q)?'':'none')};loadLocal();render();
