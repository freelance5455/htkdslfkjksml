const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getAuth} = require("firebase-admin/auth");
const {getFirestore, FieldValue, Timestamp} = require("firebase-admin/firestore");
const {setGlobalOptions} = require("firebase-functions/v2");
initializeApp();
setGlobalOptions({region:"asia-south1",maxInstances:5});
const db=getFirestore();
async function requireAdmin(request){
 if(!request.auth)throw new HttpsError("unauthenticated","Требуется вход.");
 const snap=await db.doc(`users/${request.auth.uid}`).get();
 if(!snap.exists||snap.data().role!=="admin"||snap.data().active!==true)throw new HttpsError("permission-denied","Только администратор.");
 return request.auth.uid;
}
function str(v,max=120){if(typeof v!=="string"||!v.trim()||v.length>max)throw new HttpsError("invalid-argument","Проверьте текстовые поля.");return v.trim()}
function int(v,min=0,max=1000000){if(!Number.isSafeInteger(v)||v<min||v>max)throw new HttpsError("invalid-argument","Некорректное число.");return v}

exports.createStudent=onCall(async req=>{
 await requireAdmin(req);
 const displayName=str(req.data.displayName,80),email=str(req.data.email,160).toLowerCase(),password=str(req.data.password,128);
 if(password.length<8)throw new HttpsError("invalid-argument","Пароль должен содержать минимум 8 символов.");
 let user;
 try{user=await getAuth().createUser({email,password,displayName, disabled:false})}
 catch(e){throw new HttpsError("already-exists","Не удалось создать аккаунт: проверьте email.")}
 await db.doc(`users/${user.uid}`).set({displayName,email,role:"student",active:true,coins:0,createdAt:FieldValue.serverTimestamp()});
 return {uid:user.uid};
});
exports.adjustCoins=onCall(async req=>{
 await requireAdmin(req);const uid=str(req.data.uid,128),amount=int(req.data.amount,1,1000000),op=req.data.operation;
 if(!["add","subtract"].includes(op))throw new HttpsError("invalid-argument","Неизвестная операция.");
 await db.runTransaction(async tx=>{const ref=db.doc(`users/${uid}`),s=await tx.get(ref);if(!s.exists||s.data().role!=="student")throw new HttpsError("not-found","Ученик не найден.");
 const old=s.data().coins||0,next=op==="add"?old+amount:old-amount;if(next<0)throw new HttpsError("failed-precondition","Недостаточно монет.");tx.update(ref,{coins:next});});
 return {ok:true};
});
exports.setStudentActive=onCall(async req=>{await requireAdmin(req);const uid=str(req.data.uid,128);if(typeof req.data.active!=="boolean")throw new HttpsError("invalid-argument","Некорректный статус.");await db.doc(`users/${uid}`).update({active:req.data.active});return {ok:true}});
exports.createQuest=onCall(async req=>{await requireAdmin(req);const d=req.data;const data={title:str(d.title,100),icon:typeof d.icon==="string"?d.icon.slice(0,8):"⭐",description:String(d.description||"").slice(0,500),reward:int(d.reward,0,100000),active:true,createdAt:FieldValue.serverTimestamp()};const ref=await db.collection("quests").add(data);return {id:ref.id}});
exports.deleteQuest=onCall(async req=>{await requireAdmin(req);await db.doc(`quests/${str(req.data.questId,128)}`).delete();return {ok:true}});
exports.createProduct=onCall(async req=>{await requireAdmin(req);const d=req.data;const data={title:str(d.title,100),icon:typeof d.icon==="string"?d.icon.slice(0,8):"🎁",description:String(d.description||"").slice(0,500),price:int(d.price,0,1000000),discount:int(d.discount,0,100),active:true,createdAt:FieldValue.serverTimestamp()};const ref=await db.collection("products").add(data);return {id:ref.id}});
exports.deleteProduct=onCall(async req=>{await requireAdmin(req);await db.doc(`products/${str(req.data.productId,128)}`).delete();return {ok:true}});
exports.setEventTimer=onCall(async req=>{await requireAdmin(req);if(req.data.enabled===false){await db.doc("settings/eventTimer").set({enabled:false,updatedAt:FieldValue.serverTimestamp()},{merge:true});return {ok:true}}
 const end=new Date(req.data.endAt);if(!Number.isFinite(end.getTime())||end<=new Date())throw new HttpsError("invalid-argument","Время должно быть в будущем.");
 const color=str(req.data.color,7);if(!/^#[0-9a-fA-F]{6}$/.test(color))throw new HttpsError("invalid-argument","Неверный цвет.");
 await db.doc("settings/eventTimer").set({title:str(req.data.title,100),endAt:Timestamp.fromDate(end),color,enabled:true,updatedAt:FieldValue.serverTimestamp()});return {ok:true};
});
exports.purchaseProduct=onCall(async req=>{
 if(!req.auth)throw new HttpsError("unauthenticated","Войдите в аккаунт.");
 const uid=req.auth.uid,productId=str(req.data.productId,128),userRef=db.doc(`users/${uid}`),productRef=db.doc(`products/${productId}`);
 await db.runTransaction(async tx=>{
  const [us,ps]=await Promise.all([tx.get(userRef),tx.get(productRef)]);
  if(!us.exists||us.data().role!=="student"||us.data().active!==true)throw new HttpsError("permission-denied","Аккаунт не активен.");
  if(!ps.exists||ps.data().active!==true)throw new HttpsError("not-found","Товар недоступен.");
  const p=ps.data(),discount=Math.min(100,Math.max(0,p.discount||0)),price=Math.round(p.price*(1-discount/100)),coins=us.data().coins||0;
  if(coins<price)throw new HttpsError("failed-precondition","Недостаточно монет.");
  tx.update(userRef,{coins:coins-price});
  const bagRef=userRef.collection("backpack").doc();
  tx.set(bagRef,{productId,title:p.title,icon:p.icon||"🎁",pricePaid:price,purchasedAt:FieldValue.serverTimestamp()});
  tx.set(db.collection("purchaseLogs").doc(),{uid,productId,title:p.title,price,createdAt:FieldValue.serverTimestamp()});
 });
 return {ok:true};
});
