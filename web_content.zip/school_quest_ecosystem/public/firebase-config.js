// 1) Замените значения на данные своего Firebase-проекта.
// Этот файл не содержит секретов: Firebase web config публичен.
// Защита обеспечивается Firebase Auth, Firestore Rules и Cloud Functions.
export const firebaseConfig = {
  apiKey: "ВСТАВЬТЕ_API_KEY",
  authDomain: "ВАШ-ПРОЕКТ.firebaseapp.com",
  projectId: "ВАШ-ПРОЕКТ",
  storageBucket: "ВАШ-ПРОЕКТ.firebasestorage.app",
  messagingSenderId: "ВСТАВЬТЕ_SENDER_ID",
  appId: "ВСТАВЬТЕ_APP_ID"
};

export const WHATSAPP_REPORT_NUMBER = "7XXXXXXXXXX"; // международный формат без +
