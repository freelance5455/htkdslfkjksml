// ============================================================
// router.js — Minimal hash router. Supports params (:id) and
// integrates with the Telegram back button.
// ============================================================

import { telegramService } from "./telegram/telegramService.js";

const routes = [];
let notFoundHandler = () => {};
let navStack = [];

export function registerRoute(pattern, handler) {
  const paramNames = [];
  const regex = new RegExp(
    "^" +
      pattern.replace(/:[^/]+/g, (m) => {
        paramNames.push(m.slice(1));
        return "([^/]+)";
      }) +
      "$"
  );
  routes.push({ regex, paramNames, handler });
}

export function registerNotFound(handler) {
  notFoundHandler = handler;
}

function currentPath() {
  return (location.hash || "#/home").slice(1) || "/home";
}

export function navigate(path) {
  location.hash = "#" + path;
}

export function goBack() {
  if (navStack.length > 1) {
    navStack.pop();
    location.hash = "#" + navStack[navStack.length - 1];
  } else {
    navigate("/home");
  }
}

function resolve() {
  const path = currentPath();
  if (navStack[navStack.length - 1] !== path) navStack.push(path);

  for (const r of routes) {
    const match = path.match(r.regex);
    if (match) {
      const params = {};
      r.paramNames.forEach((name, i) => (params[name] = decodeURIComponent(match[i + 1])));
      r.handler(params);
      if (path === "/home") telegramService.hideBackButton();
      else telegramService.showBackButton();
      return;
    }
  }
  notFoundHandler(path);
}

export function startRouter() {
  telegramService.enableBackButton(() => goBack());
  window.addEventListener("hashchange", resolve);
  resolve();
}
