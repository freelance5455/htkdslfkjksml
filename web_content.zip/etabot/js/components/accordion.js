// ============================================================
// accordion.js — Simple expand/collapse sections.
// ============================================================

import { icon } from "./icons.js";
import { esc } from "../utils/safeRender.js";

export function renderAccordion(sections) {
  return sections
    .map(
      (s, i) => `
      <div class="accordion__item" data-idx="${i}">
        <button class="accordion__trigger" data-trigger="${i}">
          <span>${esc(s.title)}</span>
          ${icon("chevronRight")}
        </button>
        <div class="accordion__panel" id="acc-panel-${i}">
          <div class="accordion__panel-inner">${esc(s.body)}</div>
        </div>
      </div>`
    )
    .join("");
}

export function bindAccordion(root) {
  root.querySelectorAll("[data-trigger]").forEach((btn) => {
    btn.addEventListener("click", () => {
      btn.closest(".accordion__item").classList.toggle("is-open");
    });
  });
}
