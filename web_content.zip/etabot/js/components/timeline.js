// ============================================================
// timeline.js — Renders a status-history timeline.
//
// Driven entirely by the `statusHistory` array a request actually
// has — never fabricates intermediate dates. Steps with no
// recorded timestamp render as pending/upcoming.
// ============================================================

import { esc } from "../utils/safeRender.js";
import { formatExact } from "../utils/format.js";

/**
 * @param steps  Ordered list of { key, labelKey } describing the
 *               full possible sequence for this request kind.
 * @param history Actual recorded events: [{ status, at }]
 */
export function renderTimeline(steps, history, t, locale) {
  const byStatus = Object.fromEntries((history || []).map((h) => [h.status, h.at]));
  return `
    <div class="timeline">
      ${steps
        .map((step, i) => {
          const at = byStatus[step.key];
          const done = !!at;
          return `
          <div class="timeline__item">
            <div class="timeline__rail">
              <div class="timeline__dot ${done ? "timeline__dot--done" : ""}"></div>
              ${i < steps.length - 1 ? `<div class="timeline__line"></div>` : ""}
            </div>
            <div class="timeline__content">
              <div class="timeline__title">${esc(t(step.labelKey))}</div>
              <div class="timeline__time">${at ? formatExact(at, locale) : t("requests.pendingStep")}</div>
            </div>
          </div>`;
        })
        .join("")}
    </div>
  `;
}
