// ============================================================
// statusBadge.js — Renders a badge from the centralized status
// config (js/models/status.js). Never relies on color alone —
// always pairs an icon + translated label.
// ============================================================

import { statusConfig } from "../models/status.js";
import { icon } from "./icons.js";
import { esc } from "../utils/safeRender.js";

export function statusBadge(status, t) {
  const cfg = statusConfig(status);
  const label = cfg.i18n ? t(cfg.i18n) : status;
  return `<span class="badge badge--${cfg.tone}">${icon(cfg.icon)}${esc(label)}</span>`;
}
