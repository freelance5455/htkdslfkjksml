// ============================================================
// countdown.js — Reusable live countdown.
//
// Renders into a target element and updates every second via
// requestAnimationFrame-safe setInterval. When the countdown
// reaches zero it shows an "ended" state and calls onEnd — it
// never claims the draw/closure has actually happened; that is
// for the backend-driven pool/draw status to confirm.
// ============================================================

import { formatCountdown, remaining } from "../utils/format.js";

const timers = new WeakMap();

export function mountCountdown(el, targetIso, { locale = "en", warningHours = 6, onEnd } = {}) {
  if (!el) return;
  stopCountdown(el);

  function tick() {
    const r = remaining(targetIso);
    if (!r) {
      el.textContent = formatCountdown(targetIso, locale);
      el.classList.add("countdown--ended");
      el.classList.remove("countdown--warning");
      stopCountdown(el);
      onEnd?.();
      return;
    }
    el.textContent = formatCountdown(targetIso, locale);
    el.classList.toggle("countdown--warning", r.hours < warningHours && r.days === 0);
  }

  tick();
  const interval = setInterval(tick, 1000);
  timers.set(el, interval);
}

export function stopCountdown(el) {
  const existing = timers.get(el);
  if (existing) clearInterval(existing);
  timers.delete(el);
}
