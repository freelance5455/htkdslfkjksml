// ============================================================
// cards.js — Shared markup fragments: PoolCard, EntryCard,
// TransactionRow, RequestCard, ParticipantRow, NotificationItem.
// All user-influenced text is escaped via esc().
// ============================================================

import { esc } from "../utils/safeRender.js";
import { formatCurrency, formatRelative } from "../utils/format.js";
import { icon } from "./icons.js";
import { statusBadge } from "./statusBadge.js";
import { poolService } from "../services/poolService.js";

export function poolCard(pool, t, locale) {
  const status = poolService.deriveStatus(pool);
  const pct = pool.capacity ? Math.min(100, Math.round((pool.participantCount / pool.capacity) * 100)) : 0;
  return `
    <button class="card pool-card" data-nav="/pools/${encodeURIComponent(pool.id)}">
      <div class="pool-card__top">
        <div>
          <div class="pool-card__name">${esc(pool.name)}</div>
          <div class="pool-card__id">${esc(pool.id)}</div>
        </div>
        ${statusBadge(status, t)}
      </div>
      <div class="progress"><div class="progress__fill" style="width:${pct}%"></div></div>
      <div class="pool-card__grid">
        <div><div class="pool-card__metric-label">${esc(t("pools.entry"))}</div><div class="pool-card__metric-value currency">${formatCurrency(pool.entryAmount)}</div></div>
        <div><div class="pool-card__metric-label">${esc(t("pools.participants"))}</div><div class="pool-card__metric-value">${pool.participantCount}/${pool.capacity}</div></div>
        <div><div class="pool-card__metric-label">${esc(t("pools.closesIn"))}</div><div class="pool-card__metric-value" data-countdown="${esc(pool.closeAt || "")}">—</div></div>
      </div>
      <div class="pool-card__footer">
        <span class="pool-card__closing">${icon("clock")} ${esc(formatRelative(pool.closeAt, locale))}</span>
        <span class="btn btn--text" style="width:auto">${esc(t("pools.viewPool"))} ${icon("chevronRight")}</span>
      </div>
    </button>
  `;
}

export function entryCard(entry, t, locale) {
  return `
    <div class="card" data-nav="/entries/${encodeURIComponent(entry.id)}">
      <div class="row" style="border:none;padding:0">
        <span class="row__icon">${icon("ticket")}</span>
        <div class="row__body">
          <div class="row__title">${esc(entry.poolName)}</div>
          <div class="row__subtitle">#${esc(entry.entryNumber)} • ${esc(formatRelative(entry.createdAt, locale))}</div>
        </div>
        <div class="row__meta">
          <div class="row__amount currency">${formatCurrency(entry.amount)}</div>
          ${statusBadge(entry.status, t)}
        </div>
      </div>
    </div>
  `;
}

export function transactionRow(tx, t, locale) {
  const positive = tx.amount >= 0;
  const typeLabel = t(`transaction.types.${tx.type}`);
  return `
    <div class="row" data-nav="/wallet/transactions/${encodeURIComponent(tx.id)}">
      <span class="row__icon">${icon(positive ? "arrowDown" : "arrowUp")}</span>
      <div class="row__body">
        <div class="row__title">${esc(typeLabel !== `transaction.types.${tx.type}` ? typeLabel : tx.description)}</div>
        <div class="row__subtitle">${esc(tx.id)}</div>
      </div>
      <div class="row__meta">
        <div class="row__amount currency" style="color:${positive ? "var(--color-success)" : "var(--color-text)"}">${positive ? "+" : ""}${formatCurrency(tx.amount)}</div>
        <div class="row__time">${esc(formatRelative(tx.createdAt, locale))}</div>
      </div>
    </div>
  `;
}

export function requestCard(req, t, locale) {
  return `
    <div class="card" data-nav="/requests/${encodeURIComponent(req.id)}">
      <div class="row" style="border:none;padding:0">
        <span class="row__icon">${icon(req.kind === "funding" ? "wallet" : "arrowUp")}</span>
        <div class="row__body">
          <div class="row__title">${esc(req.id)}</div>
          <div class="row__subtitle">${esc(req.method)} • ${esc(formatRelative(req.createdAt, locale))}</div>
        </div>
        <div class="row__meta">
          <div class="row__amount currency">${formatCurrency(req.amount)}</div>
          ${statusBadge(req.status, t)}
        </div>
      </div>
    </div>
  `;
}

export function participantRow(p, locale) {
  const initials = (p.displayName?.[0] || "?").toUpperCase();
  return `
    <div class="row">
      <span class="avatar avatar--sm">${p.photoUrl ? `<img src="${esc(p.photoUrl)}">` : esc(initials)}</span>
      <div class="row__body">
        <div class="row__title">${esc(p.displayName)} ${p.username ? `<span class="u-muted">@${esc(p.username)}</span>` : ""}</div>
        <div class="row__subtitle">#${esc(p.entryNumber)} • ${esc(formatRelative(p.joinedAt, locale))}</div>
      </div>
    </div>
  `;
}

export function notificationItem(n, t, locale) {
  const iconMap = { draw: "gift", funding: "wallet", withdrawal: "arrowUp", entry: "ticket", system: "info", prize: "gift", security: "shield" };
  return `
    <div class="row ${n.read ? "" : "row--unread"}" data-nav="${n.target ? esc(n.target) : ""}" data-id="${esc(n.id)}">
      <span class="row__icon">${icon(iconMap[n.category] || "info")}</span>
      <div class="row__body"><div class="row__title">${esc(n.title)}</div><div class="row__subtitle">${esc(n.body)}</div></div>
      <div class="row__meta"><div class="row__time">${esc(formatRelative(n.createdAt, locale))}</div></div>
    </div>
  `;
}

export function activityRow(a, t, locale, isLast) {
  const iconMap = { entry: "ticket", deposit: "wallet", withdrawal: "arrowUp", draw: "gift", prize: "gift", notification: "bell", account: "info" };
  return `
    <div class="timeline__item" data-nav="${a.target ? esc(a.target) : ""}">
      <div class="timeline__rail">
        <div class="timeline__dot timeline__dot--done"></div>
        ${!isLast ? `<div class="timeline__line"></div>` : ""}
      </div>
      <div class="timeline__content">
        <div class="timeline__title">${icon(iconMap[a.type] || "info")} ${esc(a.title)}</div>
        <div class="u-secondary">${esc(a.description)}</div>
        <div class="timeline__time">${esc(formatRelative(a.timestamp, locale))}</div>
      </div>
    </div>
  `;
}

export function drawRow(d, t, locale) {
  return `
    <div class="card" data-nav="/draws/${encodeURIComponent(d.id)}">
      <div class="row" style="border:none;padding:0">
        <span class="row__icon">${icon("ticket")}</span>
        <div class="row__body">
          <div class="row__title">${esc(d.poolName)}</div>
          <div class="row__subtitle">${d.winner ? `${esc(d.winner.displayName)} • #${esc(d.winner.entryNumber)}` : "—"}</div>
        </div>
        <div class="row__meta"><div class="row__time">${esc(formatRelative(d.completedAt, locale))}</div></div>
      </div>
    </div>
  `;
}
