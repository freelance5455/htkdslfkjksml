// ============================================================
// ui.js — Toasts, modals, bottom sheets, empty/error/skeleton
// renderers. No browser alert() ever. All user-influenced text
// passed in is expected to already be escaped by the caller via
// safeRender.esc() — this module does not re-escape static markup
// segments, only documents the expectation.
// ============================================================

import { icon } from "./icons.js";
import { esc } from "../utils/safeRender.js";

let toastRoot, sheetRoot, modalRoot;

export function mountUiRoots() {
  toastRoot = document.getElementById("toast-root");
  sheetRoot = document.getElementById("sheet-root");
  modalRoot = document.getElementById("modal-root");
}

export function toast(message, type = "info") {
  const el = document.createElement("div");
  el.className = `toast toast--${type}`;
  const iconName = type === "success" ? "check" : type === "danger" ? "errorIcon" : "info";
  el.innerHTML = `
    ${icon(iconName)}
    <span class="toast__msg">${esc(message)}</span>
    <button class="icon-btn" style="width:28px;height:28px;border:none;background:none" aria-label="Close">${icon("x")}</button>
  `;
  el.querySelector("button").addEventListener("click", () => el.remove());
  toastRoot.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

export function openSheet({ title, contentHtml, onMount }) {
  closeSheet();
  const backdrop = document.createElement("div");
  backdrop.className = "sheet-backdrop";
  const sheet = document.createElement("div");
  sheet.className = "sheet";
  sheet.innerHTML = `
    <div class="sheet__handle"></div>
    ${title ? `<div class="sheet__title">${esc(title)}</div>` : ""}
    <div class="sheet__body">${contentHtml}</div>
  `;
  backdrop.addEventListener("click", closeSheet);
  sheetRoot.append(backdrop, sheet);
  requestAnimationFrame(() => { backdrop.classList.add("is-open"); sheet.classList.add("is-open"); });
  if (onMount) onMount(sheet);
  return sheet;
}

export function closeSheet() {
  sheetRoot?.querySelectorAll(".sheet, .sheet-backdrop").forEach((el) => {
    el.classList.remove("is-open");
    setTimeout(() => el.remove(), 200);
  });
}

export function confirmDialog({ title, body, confirmLabel, cancelLabel, danger = false, onConfirm }) {
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  const modal = document.createElement("div");
  modal.className = "modal";
  modal.innerHTML = `
    <div class="modal__title">${esc(title)}</div>
    <div class="modal__body">${body}</div>
    <div class="modal__actions">
      <button class="btn btn--secondary" data-act="cancel">${esc(cancelLabel || "Cancel")}</button>
      <button class="btn ${danger ? "btn--danger" : "btn--primary"}" data-act="confirm">${esc(confirmLabel || "Confirm")}</button>
    </div>
  `;
  function close() {
    backdrop.classList.remove("is-open");
    modal.classList.remove("is-open");
    setTimeout(() => { backdrop.remove(); modal.remove(); }, 200);
  }
  modal.querySelector('[data-act="cancel"]').addEventListener("click", close);
  modal.querySelector('[data-act="confirm"]').addEventListener("click", () => { close(); onConfirm?.(); });
  backdrop.addEventListener("click", close);
  modalRoot.append(backdrop, modal);
  requestAnimationFrame(() => { backdrop.classList.add("is-open"); modal.classList.add("is-open"); });
}

export function emptyState({ title, desc, iconName = "empty", actionLabel, onAction }) {
  const id = `empty-act-${Math.random().toString(36).slice(2, 8)}`;
  setTimeout(() => { if (onAction) document.getElementById(id)?.addEventListener("click", onAction); });
  return `
    <div class="state-block">
      ${icon(iconName)}
      <div class="state-block__title">${esc(title)}</div>
      ${desc ? `<div class="state-block__desc">${esc(desc)}</div>` : ""}
      ${actionLabel ? `<button id="${id}" class="btn btn--secondary" style="width:auto;display:inline-flex;padding-inline:24px">${esc(actionLabel)}</button>` : ""}
    </div>
  `;
}

export function errorState({ desc, retryLabel = "Try Again", onRetryId = "retry-btn" }) {
  return `
    <div class="state-block">
      ${icon("errorIcon")}
      <div class="state-block__title">${esc(desc?.title || "Something went wrong")}</div>
      <div class="state-block__desc">${esc(desc?.body || "")}</div>
      <button id="${onRetryId}" class="btn btn--secondary" style="width:auto;display:inline-flex;padding-inline:24px">${esc(retryLabel)}</button>
    </div>
  `;
}

export function skeletonCards(n = 3) {
  return Array.from({ length: n }).map(() => `<div class="card skeleton skeleton--card"></div>`).join("");
}

export function skeletonLines(n = 3) {
  return Array.from({ length: n }).map(() => `<div class="skeleton skeleton--line"></div>`).join("");
}

export function monitorConnectivity(offlineText) {
  const banner = document.getElementById("offline-banner");
  if (banner && offlineText) banner.textContent = offlineText;
  const update = () => document.body.classList.toggle("is-offline", !navigator.onLine);
  window.addEventListener("online", update);
  window.addEventListener("offline", update);
  update();
}
