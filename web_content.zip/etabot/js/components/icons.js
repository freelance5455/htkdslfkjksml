// ============================================================
// icons.js — Flat, geometric, monochrome SVG icon system.
// Every icon is a 24x24 viewBox, 1.75px stroke, no fill.
// ============================================================

const S = 'fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"';

export const icons = {
  home: `<svg viewBox="0 0 24 24" ${S}><path d="M4 11.5 12 4l8 7.5"/><path d="M6 10v9h12v-9"/><path d="M10 19v-5h4v5"/></svg>`,
  pools: `<svg viewBox="0 0 24 24" ${S}><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/></svg>`,
  activity: `<svg viewBox="0 0 24 24" ${S}><path d="M3 12h4l2 7 4-14 2 7h6"/></svg>`,
  wallet: `<svg viewBox="0 0 24 24" ${S}><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18"/><circle cx="16.5" cy="14" r="1"/></svg>`,
  profile: `<svg viewBox="0 0 24 24" ${S}><circle cx="12" cy="8" r="3.5"/><path d="M5 20c1.5-4 4.5-6 7-6s5.5 2 7 6"/></svg>`,
  bell: `<svg viewBox="0 0 24 24" ${S}><path d="M6 10a6 6 0 0 1 12 0c0 4 1.5 5.5 1.5 5.5H4.5S6 14 6 10Z"/><path d="M10 19a2 2 0 0 0 4 0"/></svg>`,
  search: `<svg viewBox="0 0 24 24" ${S}><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4-4"/></svg>`,
  filter: `<svg viewBox="0 0 24 24" ${S}><path d="M4 6h16M7 12h10M10 18h4"/></svg>`,
  back: `<svg viewBox="0 0 24 24" ${S}><path d="m14 6-6 6 6 6"/></svg>`,
  chevronRight: `<svg viewBox="0 0 24 24" ${S}><path d="m9 6 6 6-6 6"/></svg>`,
  clock: `<svg viewBox="0 0 24 24" ${S}><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>`,
  users: `<svg viewBox="0 0 24 24" ${S}><circle cx="9" cy="9" r="3"/><path d="M3.5 19c1-3 3-4.5 5.5-4.5s4.5 1.5 5.5 4.5"/><circle cx="17" cy="9.5" r="2.5"/><path d="M15.5 14.5c2 .3 3.5 1.7 4.3 4.5"/></svg>`,
  shield: `<svg viewBox="0 0 24 24" ${S}><path d="M12 3.5 19 6.5v5c0 5-3 8-7 9-4-1-7-4-7-9v-5Z"/><path d="m9 12 2 2 4-4"/></svg>`,
  arrowUp: `<svg viewBox="0 0 24 24" ${S}><path d="M12 19V5"/><path d="m6 11 6-6 6 6"/></svg>`,
  arrowDown: `<svg viewBox="0 0 24 24" ${S}><path d="M12 5v14"/><path d="m18 13-6 6-6-6"/></svg>`,
  plus: `<svg viewBox="0 0 24 24" ${S}><path d="M12 5v14M5 12h14"/></svg>`,
  upload: `<svg viewBox="0 0 24 24" ${S}><path d="M12 16V5"/><path d="m7 9 5-5 5 5"/><path d="M5 19h14"/></svg>`,
  check: `<svg viewBox="0 0 24 24" ${S}><path d="m5 13 4 4 10-10"/></svg>`,
  x: `<svg viewBox="0 0 24 24" ${S}><path d="m6 6 12 12M18 6 6 18"/></svg>`,
  ticket: `<svg viewBox="0 0 24 24" ${S}><path d="M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a1.5 1.5 0 0 0 0 3v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2a1.5 1.5 0 0 0 0-3Z"/><path d="M14 6v12" stroke-dasharray="2 2"/></svg>`,
  gift: `<svg viewBox="0 0 24 24" ${S}><rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M4 13h16"/><path d="M12 9v11"/><path d="M12 9c-1.5-4-6-4-6-1s2.5 1 6 1Z"/><path d="M12 9c1.5-4 6-4 6-1s-2.5 1-6 1Z"/></svg>`,
  info: `<svg viewBox="0 0 24 24" ${S}><circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5"/><circle cx="12" cy="8" r="0.6" fill="currentColor" stroke="none"/></svg>`,
  empty: `<svg viewBox="0 0 24 24" ${S}><rect x="4" y="7" width="16" height="13" rx="2"/><path d="M4 11h16"/><path d="M9 15h6"/></svg>`,
  errorIcon: `<svg viewBox="0 0 24 24" ${S}><circle cx="12" cy="12" r="8.5"/><path d="M12 8v5"/><circle cx="12" cy="16" r="0.6" fill="currentColor" stroke="none"/></svg>`,
  globe: `<svg viewBox="0 0 24 24" ${S}><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.3 3.8 5.3 3.8 8.5s-1.3 6.2-3.8 8.5c-2.5-2.3-3.8-5.3-3.8-8.5S9.5 5.8 12 3.5Z"/></svg>`,
  lock: `<svg viewBox="0 0 24 24" ${S}><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>`,
  dot: `<svg viewBox="0 0 24 24" ${S}><circle cx="12" cy="12" r="4" fill="currentColor" stroke="none"/></svg>`,
  copy: `<svg viewBox="0 0 24 24" ${S}><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>`,
  language: `<svg viewBox="0 0 24 24" ${S}><path d="M4 5h9M8 3v2M11 5c-.5 3.5-2.5 6-5.5 8" /><path d="M6 9c1 1.5 2.5 2.5 4 3" /><path d="M14 21l3.5-9 3.5 9" /><path d="M15 18h5" /></svg>`,
  help: `<svg viewBox="0 0 24 24" ${S}><circle cx="12" cy="12" r="8.5"/><path d="M9.5 9.3a2.5 2.5 0 0 1 4.9.7c0 1.7-2.4 1.9-2.4 3.5"/><circle cx="12" cy="16.6" r="0.6" fill="currentColor" stroke="none"/></svg>`,
};

export function icon(name, cls = "") {
  return `<span class="${cls}" aria-hidden="true">${icons[name] || ""}</span>`;
}
