// ============================================================
// authService.js — Owns the UserIdentity lifecycle.
//
// This is the fix for the identity-architecture problem raised
// in the audit: it is the single place that combines (a) raw
// Telegram profile fields, (b) a Firebase auth session, and (c)
// an eventual backend-verified application user id — and it keeps
// them as distinct fields rather than assuming any one implies
// another. See js/models/models.js: makeUserIdentity.
// ============================================================

import { telegramService } from "../telegram/telegramService.js";
import { ensureFirebaseSession, isDevMode } from "./firebaseClient.js";
import { makeUserIdentity } from "../models/models.js";

let currentIdentity = null;

export const authService = {
  async signIn() {
    const tgUser = telegramService.getUser();
    currentIdentity = makeUserIdentity({
      ...tgUser,
      authenticationState: "authenticating",
      isDevFallback: !!tgUser.__devFallback,
    });

    const session = await ensureFirebaseSession().catch(() => null);

    currentIdentity = makeUserIdentity({
      ...currentIdentity,
      // In dev mode there is no real backend link yet; in production
      // this stays null until a trusted Cloud Function verifies
      // Telegram initData and issues an application user id — the
      // client does not assign this to itself.
      applicationUserId: isDevMode() ? currentIdentity.telegramUserId : null,
      authenticationState: session ? "authenticated" : "unauthenticated",
      verificationState: isDevMode() ? "unverified" : "unverified",
    });

    return currentIdentity;
  },

  getIdentity() {
    return currentIdentity;
  },

  isVerified() {
    return currentIdentity?.verificationState === "verified";
  },
};
