// ============================================================
// firebaseClient.js — Firebase app initialization ONLY.
//
// No screen or service other than the service-layer files in
// js/services/ should import this. It exposes db/storage/auth
// handles and a devMode flag; it never decides what data to show.
// ============================================================

import { APP_CONFIG } from "../config.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

let app = null, db = null, storage = null, auth = null, devMode = true;

export function initFirebase() {
  if (app || devMode === false) return { app, db, storage, auth, devMode };

  const isPlaceholder = APP_CONFIG.firebase.apiKey.startsWith("REPLACE_WITH");
  if (isPlaceholder) {
    devMode = true;
    console.warn("[ETA BOT] Firebase config is a placeholder — running in Development Mode (mock data only).");
    return { app: null, db: null, storage: null, auth: null, devMode: true };
  }

  app = initializeApp(APP_CONFIG.firebase);
  db = getFirestore(app);
  storage = getStorage(app);
  auth = getAuth(app);
  devMode = false;
  return { app, db, storage, auth, devMode };
}

/**
 * Establishes a Firebase Authentication session. This is
 * deliberately NOT the same thing as being a verified Telegram
 * user — see authService.js and models.js:makeUserIdentity. It
 * only gives the client an auth.uid so Firestore rules can scope
 * reads/writes; the backend links auth.uid to a verified Telegram
 * identity in the next integration stage.
 */
export async function ensureFirebaseSession() {
  const { auth, devMode } = initFirebase();
  if (devMode) return { uid: "dev-session", devMode: true };
  if (auth.currentUser) return auth.currentUser;
  const cred = await signInAnonymously(auth);
  return cred.user;
}

export function getDb() { return initFirebase().db; }
export function getStorageClient() { return initFirebase().storage; }
export function isDevMode() { return initFirebase().devMode; }
