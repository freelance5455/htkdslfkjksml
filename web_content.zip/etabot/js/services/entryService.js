// ============================================================
// entryService.js — Participation flow.
//
// Entry creation is a multi-document, must-be-atomic operation
// (create entry + ledger debit + participantCount update). This
// client module never performs that write directly: it calls a
// trusted backend Cloud Function ("createEntry") with a client
// idempotency key so a retried/duplicated tap cannot create two
// entries or debit twice.
// ============================================================

import { isDevMode } from "./firebaseClient.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makeEntry } from "../models/models.js";
import { newIdempotencyKey, withIdempotency } from "../utils/idempotency.js";

export const entryService = {
  async listMyEntries() {
    if (isDevMode()) return mockProvider.entries();
    // Production: query `entries` where userId == current app user id,
    // paginated — wired once Firestore is connected.
    return [];
  },

  async getEntry(id) {
    if (isDevMode()) return mockProvider.entries().find((e) => e.id === id) || null;
    return null;
  },

  async createEntry({ poolId, userId }) {
    const key = newIdempotencyKey(`entry-${poolId}-${userId}`);
    return withIdempotency(key, async () => {
      if (isDevMode()) {
        await new Promise((r) => setTimeout(r, 500));
        return makeEntry({
          id: `dev-entry-${Date.now()}`,
          poolId, userId,
          entryNumber: String(Math.floor(Math.random() * 900) + 100).padStart(5, "0"),
          status: "PENDING",
          createdAt: new Date().toISOString(),
        });
      }
      const { getFunctions, httpsCallable } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-functions.js");
      const fns = getFunctions();
      const createEntryFn = httpsCallable(fns, "createEntry");
      const res = await createEntryFn({ poolId, idempotencyKey: key });
      return makeEntry(res.data);
    });
  },
};
