// ============================================================
// ledgerService.js — Paginated, read-only ledger history.
// The ledger is treated as immutable history on the client:
// no UI path here edits or deletes a transaction record.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { collection, query, where, orderBy, limit as fsLimit, startAfter, getDocs, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makeLedgerTransaction } from "../models/models.js";

const PAGE_SIZE = 20;

export const ledgerService = {
  async listTransactionsPage(userId, { cursor = null } = {}) {
    if (isDevMode()) return { items: mockProvider.ledger(), nextCursor: null };
    const db = getDb();
    const clauses = [where("userId", "==", userId), orderBy("createdAt", "desc"), fsLimit(PAGE_SIZE)];
    if (cursor) clauses.push(startAfter(cursor));
    const snap = await getDocs(query(collection(db, "transactions"), ...clauses));
    const items = snap.docs.map((d) => makeLedgerTransaction({ id: d.id, ...d.data() }));
    const nextCursor = snap.docs.length === PAGE_SIZE ? snap.docs[snap.docs.length - 1] : null;
    return { items, nextCursor };
  },

  async getTransaction(userId, id) {
    if (isDevMode()) return mockProvider.ledger().find((t) => t.id === id) || null;
    const db = getDb();
    const snap = await getDoc(doc(db, "transactions", id));
    if (!snap.exists() || snap.data().userId !== userId) return null;
    return makeLedgerTransaction({ id: snap.id, ...snap.data() });
  },
};
