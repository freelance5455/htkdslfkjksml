// ============================================================
// paymentMethodService.js — Configured funding methods.
//
// AUDIT FINDING (fixed here): the previous FundingService had
// account numbers hard-coded inline as a JS object literal inside
// the funding screen's module. This moves that entirely behind a
// service so the real payment configuration can later be fetched
// from `systemContent` in Firestore without touching any screen.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { mockProvider } from "../mock/mockProvider.js";

export const paymentMethodService = {
  async getActiveMethods() {
    if (isDevMode()) return mockProvider.paymentMethods();
    const db = getDb();
    const snap = await getDoc(doc(db, "systemContent", "paymentMethods"));
    if (!snap.exists()) return [];
    return (snap.data().methods || []).filter((m) => m.active);
  },
};
