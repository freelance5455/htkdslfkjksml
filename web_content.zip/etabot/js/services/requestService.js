// ============================================================
// requestService.js — Funding + withdrawal requests.
//
// AUDIT FINDING (fixed here): the previous version had no
// getRequest(id), so the routes /funding/:id and /withdraw/:id
// were wired to the SAME handler as the request list screen and
// simply re-rendered "My Requests" instead of opening the single
// request. This service now exposes getRequest(id), and the
// request-details screen (js/screens/requestDetails.js) uses it,
// so both routes resolve to the specific record.
//
// The client can only ever create a request in the initial
// SUBMITTED state — approval/rejection/processing transitions are
// backend-only, enforced in firestore.rules.
// ============================================================

import { getDb, getStorageClient, isDevMode } from "./firebaseClient.js";
import { collection, addDoc, doc, getDoc, query, where, orderBy, limit as fsLimit, startAfter, getDocs, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { ref as storageRef, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makeRequest } from "../models/models.js";
import { validateFile } from "../utils/validate.js";
import { newIdempotencyKey, withIdempotency } from "../utils/idempotency.js";

const PAGE_SIZE = 20;
const COLLECTION = { funding: "fundingRequests", withdrawal: "withdrawalRequests" };

export const requestService = {
  async createFundingRequest({ userId, amount, method, reference, note, file }) {
    const key = newIdempotencyKey(`funding-${userId}-${reference}`);
    return withIdempotency(key, async () => {
      if (isDevMode()) {
        await new Promise((r) => setTimeout(r, 600));
        return makeRequest({ id: `dev-fr-${Date.now()}`, kind: "funding", amount, method, reference, note, status: "SUBMITTED", createdAt: new Date().toISOString() });
      }
      const db = getDb();
      let proofUrl = null;
      if (file) {
        const err = validateFile(file);
        if (err) throw new Error(err);
        const path = `fundingProofs/${userId}/${Date.now()}-${file.name}`;
        const sref = storageRef(getStorageClient(), path);
        await uploadBytes(sref, file);
        proofUrl = await getDownloadURL(sref);
      }
      const docRef = await addDoc(collection(db, COLLECTION.funding), {
        userId, amount, method, reference, note: note || "", proofUrl,
        status: "SUBMITTED", createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
      });
      return makeRequest({ id: docRef.id, kind: "funding", amount, method, reference, status: "SUBMITTED" });
    });
  },

  async createWithdrawalRequest({ userId, amount, destinationMethod, destinationReference, note }) {
    const key = newIdempotencyKey(`withdraw-${userId}-${destinationReference}`);
    return withIdempotency(key, async () => {
      if (isDevMode()) {
        await new Promise((r) => setTimeout(r, 600));
        return makeRequest({ id: `dev-wd-${Date.now()}`, kind: "withdrawal", amount, method: destinationMethod, reference: destinationReference, note, status: "SUBMITTED", createdAt: new Date().toISOString() });
      }
      const db = getDb();
      const docRef = await addDoc(collection(db, COLLECTION.withdrawal), {
        userId, amount, destinationMethod, destinationReference, note: note || "",
        status: "SUBMITTED", createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
      });
      return makeRequest({ id: docRef.id, kind: "withdrawal", amount, method: destinationMethod, reference: destinationReference, status: "SUBMITTED" });
    });
  },

  async listRequests(userId) {
    if (isDevMode()) return mockProvider.requests();
    const db = getDb();
    const [funding, withdrawal] = await Promise.all(
      ["funding", "withdrawal"].map(async (kind) => {
        const snap = await getDocs(query(collection(db, COLLECTION[kind]), where("userId", "==", userId), orderBy("createdAt", "desc"), fsLimit(PAGE_SIZE)));
        return snap.docs.map((d) => makeRequest({ id: d.id, kind, ...d.data() }));
      })
    );
    return [...funding, ...withdrawal].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },

  /** Fixes the routing bug: resolves ONE request by id, checking both collections. */
  async getRequest(userId, id) {
    if (isDevMode()) return mockProvider.requests().find((r) => r.id === id) || null;
    const db = getDb();
    for (const kind of ["funding", "withdrawal"]) {
      const snap = await getDoc(doc(db, COLLECTION[kind], id));
      if (snap.exists() && snap.data().userId === userId) {
        return makeRequest({ id: snap.id, kind, ...snap.data() });
      }
    }
    return null;
  },
};
