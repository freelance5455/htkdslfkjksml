// ============================================================
// activityService.js — Chronological account activity.
//
// AUDIT FINDING (fixed here): the previous renderActivity()
// screen imported DEV_ACTIVITY directly and rendered it
// unconditionally, regardless of Firebase connection state. All
// activity now flows through this service, which only returns
// mock data when firebaseClient.isDevMode() is true.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { collection, query, where, orderBy, limit as fsLimit, startAfter, getDocs } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makeActivityItem } from "../models/models.js";

const PAGE_SIZE = 20;

export const activityService = {
  async listActivityPage(userId, { cursor = null } = {}) {
    if (isDevMode()) return { items: mockProvider.activity(), nextCursor: null };
    const db = getDb();
    const clauses = [where("userId", "==", userId), orderBy("timestamp", "desc"), fsLimit(PAGE_SIZE)];
    if (cursor) clauses.push(startAfter(cursor));
    const snap = await getDocs(query(collection(db, "activity"), ...clauses));
    const items = snap.docs.map((d) => makeActivityItem({ id: d.id, ...d.data() }));
    const nextCursor = snap.docs.length === PAGE_SIZE ? snap.docs[snap.docs.length - 1] : null;
    return { items, nextCursor };
  },
};
