// ============================================================
// userService.js — Profile reads and privacy setting writes.
//
// AUDIT FINDING (fixed here): the previous Privacy screen was
// static markup with no persistence path at all. This service
// gives it a real (dev-mode-aware) save path with explicit
// loading/success/failure outcomes, so the screen can stop
// pretending settings are saved when nothing is connected.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makePrivacySettings } from "../models/models.js";

export const userService = {
  async getProfile(identity) {
    if (isDevMode()) {
      const m = mockProvider.user();
      return { ...m, ...identity };
    }
    const db = getDb();
    const ref = doc(db, "users", identity.telegramUserId);
    const snap = await getDoc(ref);
    if (snap.exists()) return snap.data();

    // First launch: create a minimal, non-privileged profile.
    // Balance/status/role are never set from the client.
    const profile = {
      telegramUserId: identity.telegramUserId,
      username: identity.telegramUsername,
      firstName: identity.telegramFirstName,
      lastName: identity.telegramLastName,
      photoUrl: identity.telegramPhotoUrl,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(ref, profile);
    return profile;
  },

  async getPrivacy(identity) {
    if (isDevMode()) return makePrivacySettings(mockProvider.privacy());
    const db = getDb();
    const snap = await getDoc(doc(db, "users", identity.telegramUserId, "settings", "privacy"));
    return makePrivacySettings(snap.exists() ? snap.data() : {});
  },

  async updatePrivacy(identity, partial) {
    if (isDevMode()) {
      await new Promise((r) => setTimeout(r, 400));
      return { ...mockProvider.privacy(), ...partial, __devFallback: true };
    }
    const db = getDb();
    const ref = doc(db, "users", identity.telegramUserId, "settings", "privacy");
    await setDoc(ref, { ...partial, updatedAt: serverTimestamp() }, { merge: true });
    return this.getPrivacy(identity);
  },
};
