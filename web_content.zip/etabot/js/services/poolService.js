// ============================================================
// poolService.js — Pool discovery + participant reads.
// Read-only from the client; participantCount/status/timing are
// authoritative fields written only by trusted backend functions.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { collection, getDocs, doc, getDoc, query, orderBy, limit as fsLimit, where, startAfter } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makePool, makeParticipant } from "../models/models.js";
import { PoolStatus } from "../models/status.js";

const PARTICIPANTS_PAGE_SIZE = 8;

export const poolService = {
  async listPools() {
    if (isDevMode()) return mockProvider.pools();
    const db = getDb();
    const q = query(collection(db, "pools"), orderBy("createdAt", "desc"), fsLimit(50));
    const snap = await getDocs(q);
    return snap.docs.map((d) => makePool({ id: d.id, ...d.data() }));
  },

  async getPool(id) {
    if (isDevMode()) return mockProvider.pools().find((p) => p.id === id) || null;
    const db = getDb();
    const snap = await getDoc(doc(db, "pools", id));
    return snap.exists() ? makePool({ id: snap.id, ...snap.data() }) : null;
  },

  async getParticipantsPage(poolId, { cursor = null } = {}) {
    if (isDevMode()) {
      const page = mockProvider.participantsPage(poolId, cursor);
      return { items: page.items, nextCursor: page.nextCursor };
    }
    const db = getDb();
    const clauses = [where("poolId", "==", poolId), orderBy("joinedAt", "desc"), fsLimit(PARTICIPANTS_PAGE_SIZE)];
    if (cursor) clauses.push(startAfter(cursor));
    const snap = await getDocs(query(collection(db, "participants"), ...clauses));
    const items = snap.docs.map((d) => makeParticipant({ userId: d.id, ...d.data() }));
    const nextCursor = snap.docs.length === PARTICIPANTS_PAGE_SIZE ? snap.docs[snap.docs.length - 1] : null;
    return { items, nextCursor };
  },

  /** Derives the visual status bucket, since "closing soon" is a client-side time window over an OPEN pool, not a distinct backend field in every schema. */
  deriveStatus(pool) {
    if (pool.status === PoolStatus.COMPLETED || pool.status === PoolStatus.CLOSED || pool.status === PoolStatus.DRAWING) return pool.status;
    if (pool.participantCount >= pool.capacity && pool.capacity > 0) return PoolStatus.FULL;
    if (pool.closeAt) {
      const hoursLeft = (new Date(pool.closeAt).getTime() - Date.now()) / 3600000;
      if (hoursLeft <= 6 && hoursLeft > 0) return PoolStatus.CLOSING_SOON;
    }
    return pool.status;
  },

  search(pools, term) {
    const t = term.trim().toLowerCase();
    if (!t) return pools;
    return pools.filter((p) => p.name.toLowerCase().includes(t) || p.id.toLowerCase().includes(t));
  },

  searchParticipants(list, term) {
    const t = term.trim().toLowerCase();
    if (!t) return list;
    return list.filter(
      (p) => p.displayName.toLowerCase().includes(t) || p.username.toLowerCase().includes(t) || p.entryNumber.includes(t)
    );
  },
};
