// ============================================================
// drawService.js — Draw history and results.
//
// The client NEVER selects or submits a winner and never uses
// Math.random() (or anything else) as an authoritative selection
// mechanism. It only displays the trusted draw record written by
// the backend once a draw completes.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { collection, getDocs, doc, getDoc, orderBy, query } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makeDraw } from "../models/models.js";

export const drawService = {
  async listDraws() {
    if (isDevMode()) return mockProvider.draws();
    const db = getDb();
    const snap = await getDocs(query(collection(db, "draws"), orderBy("completedAt", "desc")));
    return snap.docs.map((d) => makeDraw({ id: d.id, ...d.data() }));
  },

  async getDraw(id) {
    if (isDevMode()) return mockProvider.draws().find((d) => d.id === id) || null;
    const db = getDb();
    const snap = await getDoc(doc(db, "draws", id));
    return snap.exists() ? makeDraw({ id: snap.id, ...snap.data() }) : null;
  },
};
