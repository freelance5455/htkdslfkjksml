// ============================================================
// notificationService.js — Notification center backend access.
// Deep-link targets are restricted to a known-safe route prefix
// allow-list inside makeNotification() (see models.js) so a
// notification document can never redirect to an arbitrary path.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { collection, query, where, orderBy, getDocs, doc, updateDoc, writeBatch } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makeNotification } from "../models/models.js";

export const notificationService = {
  async listNotifications(userId) {
    if (isDevMode()) return mockProvider.notifications();
    const db = getDb();
    const snap = await getDocs(query(collection(db, "notifications"), where("userId", "==", userId), orderBy("createdAt", "desc")));
    return snap.docs.map((d) => makeNotification({ id: d.id, ...d.data() }));
  },

  async unreadCount(userId) {
    const items = await this.listNotifications(userId);
    return items.filter((n) => !n.read).length;
  },

  async markRead(userId, id) {
    if (isDevMode()) return true;
    await updateDoc(doc(getDb(), "notifications", id), { read: true });
    return true;
  },

  async markAllRead(userId, ids) {
    if (isDevMode()) return true;
    const db = getDb();
    const batch = writeBatch(db);
    ids.forEach((id) => batch.update(doc(db, "notifications", id), { read: true }));
    await batch.commit();
    return true;
  },
};
