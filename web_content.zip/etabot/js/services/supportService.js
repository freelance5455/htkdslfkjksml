// ============================================================
// supportService.js — Support tickets.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

export const supportService = {
  categories: ["account", "pools", "entries", "funding", "withdrawal", "draw", "technical", "other"],

  async createTicket({ userId, category, message }) {
    if (isDevMode()) {
      await new Promise((r) => setTimeout(r, 400));
      return { id: `dev-ticket-${Date.now()}` };
    }
    const db = getDb();
    const docRef = await addDoc(collection(db, "supportTickets"), { userId, category, message, status: "open", createdAt: serverTimestamp() });
    return { id: docRef.id };
  },
};
