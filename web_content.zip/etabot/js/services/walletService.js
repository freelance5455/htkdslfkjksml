// ============================================================
// walletService.js — Read-only balance access.
// available / locked / pending are computed and written
// exclusively by trusted backend functions in response to
// approved requests, entries, and draw outcomes.
// ============================================================

import { getDb, isDevMode } from "./firebaseClient.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { mockProvider } from "../mock/mockProvider.js";
import { makeWallet } from "../models/models.js";

export const walletService = {
  async getWallet(userId) {
    if (isDevMode()) return mockProvider.wallet();
    const db = getDb();
    const snap = await getDoc(doc(db, "users", userId, "wallet", "summary"));
    return makeWallet(snap.exists() ? snap.data() : {});
  },
};
