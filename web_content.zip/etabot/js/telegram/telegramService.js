// ============================================================
// telegramService.js — The ONLY module allowed to touch
// window.Telegram directly.
//
// AUDIT FINDING (fixed here): the previous telegram.js exported
// loose functions and several screens were tempted to reach into
// window.Telegram directly for one-off things (e.g. main button
// text). Everything now goes through this single service object,
// per spec section 6, so Telegram API usage stays centralized and
// auditable.
//
// This module also never treats Telegram-reported user fields as
// verified identity — see js/models/models.js: makeUserIdentity.
// ============================================================

import { APP_CONFIG } from "../config.js";

let backButtonCallback = null;

function hasTelegram() {
  return typeof window !== "undefined" && !!window.Telegram && !!window.Telegram.WebApp;
}

function tg() {
  return hasTelegram() ? window.Telegram.WebApp : null;
}

export const telegramService = {
  mode: "development", // "telegram" | "development"

  initialize() {
    if (hasTelegram()) {
      tg().ready();
      this.mode = "telegram";
      return { mode: "telegram" };
    }
    if (APP_CONFIG.telegram.requireTelegramContext) {
      throw new Error("Telegram context required but not found.");
    }
    this.mode = "development";
    return { mode: "development" };
  },

  /**
   * Returns raw, UNVERIFIED Telegram profile fields. This is
   * client-reported data only — never treat it as proof of
   * identity. The backend verification stage will confirm it
   * against Telegram's signed initData.
   */
  getUser() {
    if (hasTelegram()) {
      const u = tg().initDataUnsafe?.user;
      if (u) {
        return {
          telegramUserId: String(u.id),
          telegramFirstName: u.first_name || "",
          telegramLastName: u.last_name || "",
          telegramUsername: u.username || "",
          telegramPhotoUrl: u.photo_url || "",
        };
      }
    }
    return {
      telegramUserId: "dev-000000",
      telegramFirstName: "Abebe",
      telegramLastName: "Kebede",
      telegramUsername: "abebe123",
      telegramPhotoUrl: "",
      __devFallback: true,
    };
  },

  /** Raw, unverified Telegram launch parameters (deep-link start payload etc). */
  getLaunchParams() {
    if (!hasTelegram()) return { startParam: null };
    return { startParam: tg().initDataUnsafe?.start_param ?? null };
  },

  getTheme() {
    return hasTelegram() ? tg().themeParams || {} : {};
  },

  getColorScheme() {
    if (hasTelegram()) return tg().colorScheme || "light";
    if (window.matchMedia?.("(prefers-color-scheme: dark)").matches) return "dark";
    return "light";
  },

  expand() {
    tg()?.expand();
  },

  close() {
    tg()?.close();
  },

  enableBackButton(onBack) {
    backButtonCallback = onBack;
    if (hasTelegram()) tg().BackButton.onClick(onBack);
  },

  showBackButton() {
    tg()?.BackButton.show();
  },

  hideBackButton() {
    tg()?.BackButton.hide();
  },

  getBackButtonCallback() {
    return backButtonCallback;
  },

  setMainButton({ text, onClick, visible = true, color, textColor } = {}) {
    const t = tg();
    if (!t) return;
    if (text) t.MainButton.setText(text);
    if (color) t.MainButton.color = color;
    if (textColor) t.MainButton.textColor = textColor;
    if (onClick) t.MainButton.onClick(onClick);
    visible ? t.MainButton.show() : t.MainButton.hide();
  },

  hideMainButton() {
    tg()?.MainButton.hide();
  },

  /** Haptic feedback, safely no-op outside Telegram. */
  haptic(kind = "light") {
    const h = tg()?.HapticFeedback;
    if (!h) return;
    if (kind === "success" || kind === "error" || kind === "warning") h.notificationOccurred(kind);
    else h.impactOccurred(kind);
  },

  isTelegramContext() {
    return hasTelegram();
  },
};
