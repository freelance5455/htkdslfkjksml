// ============================================================
// validate.js — Reusable, inline-first validation.
// Returns a message key (translated by the caller) or null.
// ============================================================

export const MIN_FUNDING_AMOUNT = 50;

export function validateAmount(value, { min = 0, max = Infinity } = {}) {
  if (value === "" || value === null || value === undefined) return "validation.required";
  const n = Number(value);
  if (Number.isNaN(n)) return "validation.invalidAmount";
  if (n <= 0) return "validation.invalidAmount";
  if (min && n < min) return "validation.belowMinimum";
  if (max !== Infinity && n > max) return "validation.aboveAvailable";
  return null;
}

export function validateRequired(value) {
  return value && String(value).trim().length > 0 ? null : "validation.required";
}

export function validateReference(value) {
  if (!value || String(value).trim().length < 3) return "validation.invalidReference";
  return null;
}

const ALLOWED_PROOF_TYPES = ["image/jpeg", "image/png", "application/pdf"];
const MAX_PROOF_SIZE = 8 * 1024 * 1024;

export function validateFile(file) {
  if (!file) return null; // optional at this layer; screens decide if required
  if (!ALLOWED_PROOF_TYPES.includes(file.type)) return "validation.fileType";
  if (file.size > MAX_PROOF_SIZE) return "validation.fileSize";
  return null;
}

/** Runs a map of {field: validator()} and returns {field: messageKey} for failures only. */
export function runValidators(map) {
  const errors = {};
  for (const [field, result] of Object.entries(map)) {
    if (result) errors[field] = result;
  }
  return errors;
}
