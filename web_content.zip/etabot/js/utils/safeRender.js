// ============================================================
// safeRender.js — Escaping utilities.
//
// AUDIT FINDING (fixed here): the previous version interpolated
// values like firstName, username, pool name/description, and
// notes directly into template-literal HTML. Any of those fields
// could contain "<script>" or event-handler attributes once a
// backend is connected and users control that text. Every screen
// now routes user-influenced strings through esc() before they
// touch innerHTML.
// ============================================================

const ESCAPE_MAP = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
};

/** Escape a value for safe insertion into HTML text/attribute context. */
export function esc(value) {
  if (value === null || value === undefined) return "";
  return String(value).replace(/[&<>"']/g, (ch) => ESCAPE_MAP[ch]);
}

/**
 * Tag function: safeHtml`...${userValue}...` escapes every
 * interpolated expression automatically. Use this instead of a
 * raw template literal whenever a user-influenced value (name,
 * username, pool description, note, transaction description...)
 * is interpolated. Static markup segments are left untouched.
 */
export function safeHtml(strings, ...values) {
  return strings.reduce((out, str, i) => out + str + (i < values.length ? esc(values[i]) : ""), "");
}

/** Escape, then allow a short explicit allow-list of safe inline formatting is NOT supported on purpose — plain text only. */
export function escText(value) {
  return esc(value);
}
