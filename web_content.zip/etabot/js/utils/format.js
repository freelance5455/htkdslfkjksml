// ============================================================
// format.js — Currency and date/time formatting.
//
// Money is formatted for display only, from values the backend
// provides. No arithmetic here is treated as authoritative — see
// walletService / ledgerService for that boundary note.
// ============================================================

/** Format an ETB amount consistently, e.g. "1,250.00". Never rounds silently beyond display precision. */
export function formatAmount(amount) {
  const n = Number(amount);
  if (Number.isNaN(n)) return "—";
  return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatCurrency(amount) {
  return `${formatAmount(amount)} ETB`;
}

/** Exact timestamp, e.g. "04 Sep 2026 • 09:14". */
export function formatExact(date, locale = "en") {
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "—";
  const day = String(d.getDate()).padStart(2, "0");
  const months = locale === "am"
    ? ["ጃንዩ", "ፌብሩ", "ማርች", "ኤፕሪ", "ሜይ", "ጁን", "ጁላይ", "ኦገስ", "ሴፕቴ", "ኦክቶ", "ኖቬም", "ዲሴም"]
    : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const month = months[d.getMonth()];
  const year = d.getFullYear();
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${day} ${month} ${year} • ${hh}:${mm}`;
}

/** Relative time, e.g. "2 minutes ago" / "ከ2 ደቂቃ በፊት". */
export function formatRelative(date, locale = "en") {
  const diffMs = Date.now() - new Date(date).getTime();
  const mins = Math.round(diffMs / 60000);
  if (locale === "am") {
    if (mins < 1) return "አሁን";
    if (mins < 60) return `ከ${mins} ደቂቃ በፊት`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return `ከ${hrs} ሰዓት በፊት`;
    return `ከ${Math.round(hrs / 24)} ቀን በፊት`;
  }
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

/** Remaining duration broken into units, for countdowns. Returns null once expired. */
export function remaining(targetIso) {
  const diff = new Date(targetIso).getTime() - Date.now();
  if (diff <= 0) return null;
  const totalSec = Math.floor(diff / 1000);
  return {
    days: Math.floor(totalSec / 86400),
    hours: Math.floor((totalSec % 86400) / 3600),
    minutes: Math.floor((totalSec % 3600) / 60),
    seconds: totalSec % 60,
    totalSec,
  };
}

export function formatCountdown(targetIso, locale = "en") {
  const r = remaining(targetIso);
  if (!r) return locale === "am" ? "ተጠናቅቋል" : "Ended";
  if (r.days > 0) return `${r.days}${locale === "am" ? "ቀ" : "d"} ${r.hours}${locale === "am" ? "ሰ" : "h"}`;
  if (r.hours > 0) return `${r.hours}${locale === "am" ? "ሰ" : "h"} ${r.minutes}${locale === "am" ? "ደ" : "m"}`;
  return `${r.minutes}${locale === "am" ? "ደ" : "m"} ${r.seconds}${locale === "am" ? "ሴ" : "s"}`;
}
