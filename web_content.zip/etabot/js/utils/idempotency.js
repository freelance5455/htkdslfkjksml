// ============================================================
// idempotency.js — Idempotency-aware submission guard.
//
// AUDIT FINDING (fixed here): the previous participation and
// request-submission flows only disabled the button after click,
// which does not protect against retried network requests or a
// user double-tapping before the disabled state paints. This
// wraps an async action so it can only be in flight once per key,
// and reuses the same idempotency key across retries of the SAME
// logical action so a retried request cannot be double-processed
// by the backend either.
// ============================================================

const inFlight = new Map();

export function newIdempotencyKey(prefix = "op") {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

/**
 * Guards `fn` so concurrent calls with the same `key` share one
 * in-flight promise instead of firing twice (e.g. rapid double-tap).
 */
export async function withIdempotency(key, fn) {
  if (inFlight.has(key)) return inFlight.get(key);
  const p = Promise.resolve()
    .then(fn)
    .finally(() => inFlight.delete(key));
  inFlight.set(key, p);
  return p;
}
