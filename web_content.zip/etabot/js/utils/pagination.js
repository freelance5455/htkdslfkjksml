// ============================================================
// pagination.js — Shared cursor-pagination controller.
//
// Wraps any service method with signature
//   fetchPage({ cursor }) => { items, nextCursor }
// and exposes loadMore()/reset() plus current items, so screens
// don't each reinvent "load next page" state.
// ============================================================

export function createPaginator(fetchPage) {
  let items = [];
  let cursor = null;
  let done = false;
  let loading = false;

  return {
    get items() { return items; },
    get done() { return done; },
    get loading() { return loading; },

    async loadMore() {
      if (done || loading) return items;
      loading = true;
      try {
        const page = await fetchPage({ cursor });
        items = items.concat(page.items);
        cursor = page.nextCursor;
        done = !cursor;
        return items;
      } finally {
        loading = false;
      }
    },

    reset() {
      items = [];
      cursor = null;
      done = false;
      loading = false;
    },
  };
}
