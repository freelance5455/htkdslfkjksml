// ============================================================
// models.js — Frontend data model shapes.
//
// These are factory/normalizer functions, not classes with
// behavior — their job is to guarantee every screen and service
// works with the same object shape, whether the data came from
// Firestore or the development mock provider. Fields the client
// must never treat as authoritative are commented inline.
// ============================================================

export function makePool(raw = {}) {
  return {
    id: raw.id ?? raw.poolId ?? "",
    name: raw.name ?? "",
    description: raw.description ?? "",
    entryAmount: Number(raw.entryAmount ?? 0),
    participantCount: Number(raw.participantCount ?? 0), // display only — backend authoritative
    capacity: Number(raw.capacity ?? raw.participantLimit ?? 0),
    status: raw.status ?? "OPEN",
    openAt: raw.openAt ?? null,
    closeAt: raw.closeAt ?? null,
    drawAt: raw.drawAt ?? null,
    rules: raw.rules ?? "",
    createdAt: raw.createdAt ?? null,
    updatedAt: raw.updatedAt ?? null,
  };
}

export function makeParticipant(raw = {}) {
  // Public projection only — never include phone numbers, payment
  // details, or authentication information in this shape.
  return {
    userId: raw.userId ?? raw.id ?? "",
    displayName: raw.displayName ?? `${raw.firstName ?? ""} ${raw.lastName ?? ""}`.trim(),
    username: raw.username ?? "",
    photoUrl: raw.photoUrl ?? "",
    entryNumber: raw.entryNumber ?? "",
    joinedAt: raw.joinedAt ?? null,
  };
}

export function makeEntry(raw = {}) {
  return {
    id: raw.id ?? raw.entryId ?? "",
    poolId: raw.poolId ?? "",
    poolName: raw.poolName ?? "",
    userId: raw.userId ?? "",
    entryNumber: raw.entryNumber ?? "",
    amount: Number(raw.amount ?? 0),
    status: raw.status ?? "PENDING",
    createdAt: raw.createdAt ?? null,
    drawStatus: raw.drawStatus ?? null,
    drawId: raw.drawId ?? null,
  };
}

export function makeWallet(raw = {}) {
  return {
    available: Number(raw.available ?? 0), // backend authoritative
    locked: Number(raw.locked ?? 0),
    pending: Number(raw.pending ?? 0),
    get total() { return this.available + this.locked + this.pending; },
  };
}

export function makeLedgerTransaction(raw = {}) {
  return {
    id: raw.id ?? raw.transactionId ?? "",
    type: raw.type ?? "adjustment", // deposit | entry | prize | withdrawal | adjustment | refund
    amount: Number(raw.amount ?? 0),
    balanceBefore: raw.balanceBefore ?? null,
    balanceAfter: raw.balanceAfter ?? null,
    status: raw.status ?? "COMPLETED",
    reference: raw.reference ?? "",
    description: raw.description ?? "",
    createdAt: raw.createdAt ?? null,
  };
}

export function makeRequest(raw = {}) {
  return {
    id: raw.id ?? raw.requestId ?? "",
    userId: raw.userId ?? "",
    kind: raw.kind ?? "funding", // "funding" | "withdrawal"
    amount: Number(raw.amount ?? 0),
    method: raw.method ?? raw.destinationMethod ?? "",
    reference: raw.reference ?? raw.destinationReference ?? "",
    proofUrl: raw.proofUrl ?? null,
    note: raw.note ?? "",
    status: raw.status ?? "SUBMITTED",
    statusHistory: raw.statusHistory ?? [],
    rejectionReason: raw.rejectionReason ?? null,
    createdAt: raw.createdAt ?? null,
    updatedAt: raw.updatedAt ?? null,
  };
}

export function makeNotification(raw = {}) {
  return {
    id: raw.id ?? "",
    userId: raw.userId ?? "",
    category: raw.category ?? raw.type ?? "system", // system|funding|withdrawal|entry|draw|prize|security
    title: raw.title ?? "",
    body: raw.body ?? "",
    createdAt: raw.createdAt ?? null,
    read: !!raw.read,
    target: normalizeTarget(raw.target),
  };
}

export function makeActivityItem(raw = {}) {
  return {
    id: raw.id ?? "",
    userId: raw.userId ?? "",
    type: raw.type ?? "account",
    title: raw.title ?? "",
    description: raw.description ?? "",
    timestamp: raw.timestamp ?? raw.createdAt ?? null,
    referenceId: raw.referenceId ?? null,
    target: normalizeTarget(raw.target),
    metadata: raw.metadata ?? {},
  };
}

export function makeDraw(raw = {}) {
  return {
    id: raw.id ?? raw.drawId ?? "",
    poolId: raw.poolId ?? "",
    poolName: raw.poolName ?? "",
    status: raw.status ?? "COMPLETED",
    createdAt: raw.createdAt ?? null,
    completedAt: raw.completedAt ?? raw.drawAt ?? null,
    eligibleParticipantCount: Number(raw.eligibleParticipantCount ?? raw.participantCount ?? 0),
    eligibleEntryCount: Number(raw.eligibleEntryCount ?? raw.entryCount ?? 0),
    selectedEntryId: raw.selectedEntryId ?? null,
    // Winner is a display-only projection, never computed client-side.
    winner: raw.winner ? makeParticipant(raw.winner) : null,
    algorithmVersion: raw.algorithmVersion ?? "",
    recordReference: raw.recordReference ?? raw.id ?? raw.drawId ?? "",
  };
}

export function makePrivacySettings(raw = {}) {
  return {
    profileVisible: raw.profileVisible ?? true,
    usernameVisible: raw.usernameVisible ?? true,
    participantListVisible: raw.participantListVisible ?? true,
  };
}

// ---------------- Identity model (see js/telegram/telegramService.js) ----------------

/**
 * UserIdentity keeps four conceptually distinct things apart:
 *  - raw Telegram profile fields (untrusted on the client)
 *  - an application-level user id (assigned once backend-verified)
 *  - authentication state (are we signed in to *something*)
 *  - verification state (has the backend actually confirmed this
 *    is the real Telegram user behind initData)
 *
 * AUDIT FINDING (fixed here): the previous version created a
 * Firestore user doc keyed directly by the client-reported
 * Telegram user id, and separately signed in anonymously to
 * Firebase — with nothing tying those two identifiers together or
 * flagging that neither is verified yet. That conflation is
 * exactly what this model exists to prevent going forward.
 */
export function makeUserIdentity(raw = {}) {
  return {
    telegramUserId: raw.telegramUserId ?? null,
    telegramUsername: raw.telegramUsername ?? "",
    telegramFirstName: raw.telegramFirstName ?? "",
    telegramLastName: raw.telegramLastName ?? "",
    telegramPhotoUrl: raw.telegramPhotoUrl ?? "",

    // Set only once a trusted backend function has linked this
    // Telegram identity to a backend record. Null until then.
    applicationUserId: raw.applicationUserId ?? null,

    // "unauthenticated" | "authenticating" | "authenticated"
    authenticationState: raw.authenticationState ?? "unauthenticated",

    // "unverified" | "verified" — set true ONLY by backend
    // confirmation of Telegram initData, never assumed client-side.
    verificationState: raw.verificationState ?? "unverified",

    isDevFallback: !!raw.isDevFallback,
  };
}

function normalizeTarget(target) {
  // Deep links are restricted to a known-safe allow-list of route
  // prefixes so a notification/activity document can never redirect
  // into an arbitrary or externally-controlled path.
  if (!target || typeof target !== "string") return null;
  const allowed = ["/pools/", "/entries/", "/requests/", "/funding/", "/withdraw/", "/draws/", "/wallet/transactions/"];
  return allowed.some((prefix) => target.startsWith(prefix)) ? target : null;
}
