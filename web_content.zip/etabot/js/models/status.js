// ============================================================
// status.js — Centralized status configuration.
//
// AUDIT FINDING (fixed here): status → color/label mapping was
// previously duplicated and inconsistent across app.js (a single
// ad hoc `statusBadge()` with a partial map). This file is now
// the single source of truth for every status enum in the
// product, each with a translation key, an icon, and a badge tone.
// Never communicate status through color alone — label + icon are
// always paired with the tone.
// ============================================================

export const PoolStatus = Object.freeze({
  OPEN: "OPEN",
  CLOSING_SOON: "CLOSING_SOON",
  FULL: "FULL",
  CLOSED: "CLOSED",
  DRAWING: "DRAWING",
  COMPLETED: "COMPLETED",
});

export const EntryStatus = Object.freeze({
  PENDING: "PENDING",
  ACTIVE: "ACTIVE",
  COMPLETED: "COMPLETED",
  CANCELLED: "CANCELLED",
  INVALID: "INVALID",
});

export const RequestStatus = Object.freeze({
  SUBMITTED: "SUBMITTED",
  UNDER_REVIEW: "UNDER_REVIEW",
  APPROVED: "APPROVED",
  REJECTED: "REJECTED",
  PROCESSING: "PROCESSING",
  COMPLETED: "COMPLETED",
});

export const TransactionStatus = Object.freeze({
  PENDING: "PENDING",
  COMPLETED: "COMPLETED",
  FAILED: "FAILED",
  REVERSED: "REVERSED",
});

const TONE = { positive: "positive", neutral: "neutral", warning: "warning", negative: "negative", info: "info" };

const STATUS_CONFIG = {
  // Pool
  OPEN: { i18n: "status.pool.open", icon: "dot", tone: TONE.positive },
  CLOSING_SOON: { i18n: "status.pool.closingSoon", icon: "clock", tone: TONE.warning },
  FULL: { i18n: "status.pool.full", icon: "users", tone: TONE.info },
  CLOSED: { i18n: "status.pool.closed", icon: "lock", tone: TONE.neutral },
  DRAWING: { i18n: "status.pool.drawing", icon: "ticket", tone: TONE.info },
  // COMPLETED shared below

  // Entry
  PENDING: { i18n: "status.entry.pending", icon: "clock", tone: TONE.warning },
  ACTIVE: { i18n: "status.entry.active", icon: "check", tone: TONE.positive },
  CANCELLED: { i18n: "status.entry.cancelled", icon: "x", tone: TONE.negative },
  INVALID: { i18n: "status.entry.invalid", icon: "errorIcon", tone: TONE.negative },
  COMPLETED: { i18n: "status.completed", icon: "check", tone: TONE.neutral },

  // Request
  SUBMITTED: { i18n: "status.request.submitted", icon: "upload", tone: TONE.info },
  UNDER_REVIEW: { i18n: "status.request.underReview", icon: "clock", tone: TONE.warning },
  APPROVED: { i18n: "status.request.approved", icon: "check", tone: TONE.positive },
  REJECTED: { i18n: "status.request.rejected", icon: "x", tone: TONE.negative },
  PROCESSING: { i18n: "status.request.processing", icon: "clock", tone: TONE.warning },

  // Transaction
  FAILED: { i18n: "status.transaction.failed", icon: "errorIcon", tone: TONE.negative },
  REVERSED: { i18n: "status.transaction.reversed", icon: "arrowUp", tone: TONE.neutral },
};

export function statusConfig(status) {
  return STATUS_CONFIG[status] || { i18n: null, icon: "info", tone: TONE.neutral };
}
