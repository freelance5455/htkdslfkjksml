// ============================================================
// i18n.js — Loads Amharic/English strings.
//
// AUDIT CLEANUP: this module previously duplicated relativeTime()
// and formatCurrency() logic that also existed in utils/format.js.
// Formatting now lives ONLY in utils/format.js; this file is
// responsible for locale loading and key lookup only.
// ============================================================

let dict = {};
let locale = "am";

export async function loadLocale(loc) {
  locale = loc;
  const res = await fetch(`./i18n/${loc}.json`);
  dict = await res.json();
  document.documentElement.lang = loc;
  document.documentElement.dir = "ltr"; // Amharic is LTR
  localStorage.setItem("etabot:locale", loc);
}

function lookup(key) {
  const parts = key.split(".");
  let val = dict;
  for (const p of parts) val = val?.[p];
  return val;
}

/** Returns a translated string, with {var} interpolation. Falls back to the raw key if missing. */
export function t(key, vars = {}) {
  const val = lookup(key);
  if (typeof val !== "string") return key;
  return val.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? ""));
}

/** Returns a translated array (e.g. funding.steps). Falls back to []. */
export function tList(key) {
  const val = lookup(key);
  return Array.isArray(val) ? val : [];
}

export function getLocale() {
  return locale;
}
