// ============================================================
// requests.js — /requests. Unified funding + withdrawal list.
// ============================================================

import { setHeader, viewRoot, bindNavClicks } from "../app/layout.js";
import { requestService } from "../services/requestService.js";
import { esc } from "../utils/safeRender.js";
import { requestCard } from "../components/cards.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";

const STATUS_FILTERS = ["all", "SUBMITTED", "UNDER_REVIEW", "APPROVED", "REJECTED", "COMPLETED"];

export async function renderRequests({ t, locale, identity }) {
  setHeader({ t, title: t("requests.myRequests"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(3)}</div>`;

  let all = [];
  try {
    all = await requestService.listRequests(identity.telegramUserId);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderRequests({ t, locale, identity }));
    return;
  }

  let kind = "all"; // all | funding | withdrawal
  let status = "all";

  function draw() {
    let list = all;
    if (kind !== "all") list = list.filter((r) => r.kind === kind);
    if (status !== "all") list = list.filter((r) => r.status === status);

    root.innerHTML = `
      <div class="view">
        <div class="tabs">
          ${["all", "funding", "withdrawal"].map((k) => `<button class="tabs__item" data-kind="${k}" aria-current="${k === kind}">${esc(k === "all" ? t("requests.all") : t(`requests.${k}`))}</button>`).join("")}
        </div>
        <div style="display:flex;gap:var(--sp-2);overflow-x:auto;padding-bottom:var(--sp-2);margin-bottom:var(--sp-4)">
          ${STATUS_FILTERS.map((s) => `<button class="btn btn--sm ${s === status ? "btn--primary" : "btn--secondary"}" style="width:auto;white-space:nowrap" data-status="${s}">${esc(s === "all" ? t("requests.all") : statusLabel(s, t))}</button>`).join("")}
        </div>
        ${list.length ? list.map((r) => requestCard(r, t, locale)).join("") : emptyState({ title: t("requests.empty"), iconName: "ticket" })}
      </div>
    `;
    bindNavClicks(root);
    root.querySelectorAll("[data-kind]").forEach((b) => b.addEventListener("click", () => { kind = b.dataset.kind; draw(); }));
    root.querySelectorAll("[data-status]").forEach((b) => b.addEventListener("click", () => { status = b.dataset.status; draw(); }));
  }
  draw();
}

function statusLabel(status, t) {
  if (status === "COMPLETED") return t("status.completed");
  const key = { SUBMITTED: "submitted", UNDER_REVIEW: "underReview", APPROVED: "approved", REJECTED: "rejected", PROCESSING: "processing" }[status];
  return key ? t(`status.request.${key}`) : status;
}
