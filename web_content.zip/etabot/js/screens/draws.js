// ============================================================
// draws.js — /draws and /draws/:id.
// Display-only. No Math.random() or any client-side selection
// is used anywhere in this file — see drawService.js for the
// same guarantee at the data layer.
// ============================================================

import { setHeader, viewRoot, bindNavClicks } from "../app/layout.js";
import { drawService } from "../services/drawService.js";
import { esc } from "../utils/safeRender.js";
import { formatExact } from "../utils/format.js";
import { drawRow } from "../components/cards.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";
import { icon } from "../components/icons.js";

export async function renderDraws({ t, locale }) {
  setHeader({ t, title: t("draws.title"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(3)}</div>`;

  let draws = [];
  try {
    draws = await drawService.listDraws();
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderDraws({ t, locale }));
    return;
  }

  root.innerHTML = `<div class="view">${draws.length ? draws.map((d) => drawRow(d, t, locale)).join("") : emptyState({ title: t("draws.empty"), iconName: "ticket" })}</div>`;
  bindNavClicks(root);
}

export async function renderDrawDetails({ id }, { t, locale }) {
  setHeader({ t, title: t("draws.result"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(2)}</div>`;

  let draw;
  try {
    draw = await drawService.getDraw(id);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderDrawDetails({ id }, { t, locale }));
    return;
  }

  if (!draw) {
    root.innerHTML = `<div class="view">${emptyState({ title: t("pools.noResults"), iconName: "ticket" })}</div>`;
    return;
  }

  root.innerHTML = `
    <div class="view">
      <div class="card u-text-center">
        ${draw.winner ? `
          <span class="avatar avatar--lg" style="margin:0 auto var(--sp-3)">${esc((draw.winner.displayName?.[0] || "?").toUpperCase())}</span>
          <div style="font-size:var(--fs-h2);font-weight:700">${esc(draw.winner.displayName)}</div>
          ${draw.winner.username ? `<div class="u-muted">@${esc(draw.winner.username)}</div>` : ""}
          <div class="badge badge--positive" style="margin-top:var(--sp-3)">#${esc(draw.winner.entryNumber)}</div>
        ` : `<div class="u-muted">${esc(t("draws.empty"))}</div>`}
      </div>

      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("draws.record"))}</span></div>
        <div class="list-panel">
          <div class="row"><div class="row__body"><div class="row__title">Draw ID</div></div><div class="row__meta">${esc(draw.id)}</div></div>
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("pools.title"))}</div></div><div class="row__meta" data-nav="/pools/${encodeURIComponent(draw.poolId)}">${esc(draw.poolName)}</div></div>
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("draws.algorithm"))}</div></div><div class="row__meta">${esc(draw.algorithmVersion || "—")}</div></div>
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("draws.eligibleParticipants"))}</div></div><div class="row__meta">${draw.eligibleParticipantCount}</div></div>
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("draws.eligibleEntries"))}</div></div><div class="row__meta">${draw.eligibleEntryCount}</div></div>
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("myEntries.createdAt"))}</div></div><div class="row__meta">${esc(formatExact(draw.completedAt, locale))}</div></div>
        </div>
      </div>

      <div class="notice u-mt-6">${icon("shield")}<span>${esc(t("trust.winnerSelection.body"))}</span></div>
    </div>
  `;
  bindNavClicks(root);
}
