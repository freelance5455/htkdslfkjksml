// ============================================================
// myEntries.js — /entries (list) and /entries/:id (details).
// ============================================================

import { setHeader, setActiveNav, viewRoot, bindNavClicks } from "../app/layout.js";
import { entryService } from "../services/entryService.js";
import { drawService } from "../services/drawService.js";
import { esc } from "../utils/safeRender.js";
import { formatCurrency, formatExact } from "../utils/format.js";
import { statusBadge } from "../components/statusBadge.js";
import { entryCard } from "../components/cards.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";

export async function renderMyEntries({ t, locale }) {
  setHeader({ t, title: t("myEntries.title"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(3)}</div>`;

  let entries = [];
  try {
    entries = await entryService.listMyEntries();
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderMyEntries({ t, locale }));
    return;
  }

  let filter = "all";
  function draw() {
    const list = filter === "all" ? entries : entries.filter((e) => e.status.toLowerCase() === filter);
    root.innerHTML = `
      <div class="view">
        <div class="tabs">
          ${["all", "active", "completed", "cancelled"]
            .map((f) => `<button class="tabs__item" data-filter="${f}" aria-current="${f === filter}">${esc(t(`myEntries.${f}`))}</button>`)
            .join("")}
        </div>
        ${list.length ? list.map((e) => entryCard(e, t, locale)).join("") : emptyState({ title: t("myEntries.empty"), iconName: "ticket" })}
      </div>
    `;
    bindNavClicks(root);
    root.querySelectorAll("[data-filter]").forEach((b) => b.addEventListener("click", () => { filter = b.dataset.filter; draw(); }));
  }
  draw();
}

export async function renderEntryDetails({ id }, { t, locale }) {
  setHeader({ t, title: t("myEntries.title"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(2)}</div>`;

  let entry;
  try {
    entry = await entryService.getEntry(id);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderEntryDetails({ id }, { t, locale }));
    return;
  }

  if (!entry) {
    root.innerHTML = `<div class="view">${emptyState({ title: t("pools.noResults"), iconName: "ticket" })}</div>`;
    return;
  }

  const draw = entry.drawId ? await drawService.getDraw(entry.drawId).catch(() => null) : null;

  root.innerHTML = `
    <div class="view">
      <div class="u-flex-between" style="margin-bottom:var(--sp-4)">
        <div>
          <div style="font-size:var(--fs-h1);font-weight:700">#${esc(entry.entryNumber)}</div>
          <div class="u-muted">${esc(entry.id)}</div>
        </div>
        ${statusBadge(entry.status, t)}
      </div>
      <div class="list-panel">
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("pools.title"))}</div></div><div class="row__meta" data-nav="/pools/${encodeURIComponent(entry.poolId)}">${esc(entry.poolName)}</div></div>
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("pools.entry"))}</div></div><div class="row__meta currency">${formatCurrency(entry.amount)}</div></div>
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("myEntries.createdAt"))}</div></div><div class="row__meta">${esc(formatExact(entry.createdAt, locale))}</div></div>
      </div>
      ${
        draw
          ? `<div class="section">
              <div class="section-header"><span class="section-header__title">${esc(t("draws.result"))}</span></div>
              <button class="card u-flex-between" style="width:100%;text-align:start" data-nav="/draws/${encodeURIComponent(draw.id)}">
                <span>${esc(draw.winner ? `${t("draws.winner")}: ${draw.winner.displayName}` : t("draws.result"))}</span>
              </button>
            </div>`
          : ""
      }
    </div>
  `;
  bindNavClicks(root);
}
