// ============================================================
// wallet.js — /wallet and /wallet/transactions/:id.
// All balances come from walletService; the ledger is treated as
// read-only, paginated history via ledgerService.
// ============================================================

import { setHeader, setActiveNav, viewRoot, bindNavClicks } from "../app/layout.js";
import { walletService } from "../services/walletService.js";
import { ledgerService } from "../services/ledgerService.js";
import { esc } from "../utils/safeRender.js";
import { formatCurrency, formatExact } from "../utils/format.js";
import { transactionRow } from "../components/cards.js";
import { statusBadge } from "../components/statusBadge.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";
import { createPaginator } from "../utils/pagination.js";

export async function renderWallet({ t, locale, identity }) {
  setHeader({ t, title: t("wallet.title") });
  setActiveNav("wallet");
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(2)}</div>`;

  let wallet;
  try {
    wallet = await walletService.getWallet(identity.telegramUserId);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderWallet({ t, locale, identity }));
    return;
  }

  const paginator = createPaginator((opts) => ledgerService.listTransactionsPage(identity.telegramUserId, opts));

  root.innerHTML = `
    <div class="view">
      <div class="list-panel">
        <div class="stat-strip">
          <div class="stat-strip__item"><div class="stat-strip__value currency">${formatCurrency(wallet.available)}</div><div class="stat-strip__label">${esc(t("wallet.available"))}</div></div>
          <div class="stat-strip__item"><div class="stat-strip__value currency">${formatCurrency(wallet.locked)}</div><div class="stat-strip__label">${esc(t("wallet.locked"))}</div></div>
          <div class="stat-strip__item"><div class="stat-strip__value currency">${formatCurrency(wallet.pending)}</div><div class="stat-strip__label">${esc(t("wallet.pending"))}</div></div>
        </div>
      </div>
      <div class="row u-flex-between" style="padding-inline:0;border:none">
        <span class="u-secondary">${esc(t("wallet.total"))}</span>
        <span class="currency" style="font-weight:700;font-size:var(--fs-h3)">${formatCurrency(wallet.total)}</span>
      </div>
      <div style="display:flex;gap:var(--sp-3);margin-top:var(--sp-3)">
        <button class="btn btn--primary" data-nav="/funding">${esc(t("wallet.addFunds"))}</button>
        <button class="btn btn--secondary" data-nav="/withdraw">${esc(t("wallet.withdraw"))}</button>
      </div>
      <div class="section">
        <div class="section-header">
          <span class="section-header__title">${esc(t("wallet.history"))}</span>
          <button class="section-header__action" data-nav="/requests">${esc(t("wallet.requests"))}</button>
        </div>
        <div id="tx-list" class="list-panel"></div>
        <button class="btn btn--secondary u-mt-6" id="load-more" style="display:none">${esc(t("common.loadMore"))}</button>
      </div>
    </div>
  `;
  bindNavClicks(root);

  async function drawTx() {
    await paginator.loadMore();
    const list = root.querySelector("#tx-list");
    list.innerHTML = paginator.items.length ? paginator.items.map((tx) => transactionRow(tx, t, locale)).join("") : emptyState({ title: t("activity.empty"), iconName: "wallet" });
    bindNavClicks(list);
    root.querySelector("#load-more").style.display = paginator.done ? "none" : "block";
  }
  root.querySelector("#load-more").addEventListener("click", drawTx);
  await drawTx();
}

export async function renderTransactionDetails({ id }, { t, locale, identity }) {
  setHeader({ t, title: t("transaction.details"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(1)}</div>`;

  let tx;
  try {
    tx = await ledgerService.getTransaction(identity.telegramUserId, id);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderTransactionDetails({ id }, { t, locale, identity }));
    return;
  }

  if (!tx) {
    root.innerHTML = `<div class="view">${emptyState({ title: t("pools.noResults"), iconName: "wallet" })}</div>`;
    return;
  }

  const typeLabel = t(`transaction.types.${tx.type}`);
  root.innerHTML = `
    <div class="view">
      <div class="u-text-center card">
        <div class="u-muted">${esc(typeLabel !== `transaction.types.${tx.type}` ? typeLabel : tx.type)}</div>
        <div style="font-size:var(--fs-display);font-weight:800;margin:var(--sp-2) 0" class="currency">${tx.amount >= 0 ? "+" : ""}${formatCurrency(tx.amount)}</div>
        ${statusBadge(tx.status, t)}
      </div>
      <div class="list-panel u-mt-6">
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("transaction.id"))}</div></div><div class="row__meta">${esc(tx.id)}</div></div>
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("transaction.reference"))}</div></div><div class="row__meta">${esc(tx.reference || "—")}</div></div>
        ${tx.balanceBefore !== null ? `<div class="row"><div class="row__body"><div class="row__title">${esc(t("transaction.balanceBefore"))}</div></div><div class="row__meta currency">${formatCurrency(tx.balanceBefore)}</div></div>` : ""}
        ${tx.balanceAfter !== null ? `<div class="row"><div class="row__body"><div class="row__title">${esc(t("transaction.balanceAfter"))}</div></div><div class="row__meta currency">${formatCurrency(tx.balanceAfter)}</div></div>` : ""}
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("myEntries.createdAt"))}</div></div><div class="row__meta">${esc(formatExact(tx.createdAt, locale))}</div></div>
      </div>
      <p class="u-secondary u-mt-6">${esc(tx.description || "")}</p>
    </div>
  `;
}
