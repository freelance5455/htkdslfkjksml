// ============================================================
// pools.js — Pool discovery screen: search + status filters.
// ============================================================

import { setHeader, setActiveNav, viewRoot, bindNavClicks } from "../app/layout.js";
import { poolService } from "../services/poolService.js";
import { esc } from "../utils/safeRender.js";
import { poolCard } from "../components/cards.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";
import { icon } from "../components/icons.js";
import { mountCountdown } from "../components/countdown.js";

export async function renderPools({ t, locale }) {
  setHeader({ t, title: t("pools.title") });
  setActiveNav("pools");
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(4)}</div>`;

  let allPools = [];
  try {
    allPools = await poolService.listPools();
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderPools({ t, locale }));
    return;
  }

  let filter = "all";
  let term = "";

  function draw() {
    let list = poolService.search(allPools, term);
    if (filter !== "all") list = list.filter((p) => poolService.deriveStatus(p) === filter);

    const groups = [
      { key: "OPEN", label: t("pools.open") },
      { key: "CLOSING_SOON", label: t("pools.closingSoon") },
      { key: "FULL", label: t("status.pool.full") },
      { key: "COMPLETED", label: t("pools.completed") },
    ];

    root.innerHTML = `
      <div class="view">
        <div class="search-input">${icon("search")}<input class="input" id="pool-search" placeholder="${esc(t("pools.searchPlaceholder"))}" value="${esc(term)}"></div>
        <div class="tabs" style="margin-top:var(--sp-4)">
          ${["all", "OPEN", "CLOSING_SOON", "COMPLETED"]
            .map((f) => {
              const label = f === "all" ? t("pools.title") : f === "OPEN" ? t("pools.open") : f === "CLOSING_SOON" ? t("pools.closingSoon") : t("pools.completed");
              return `<button class="tabs__item" data-filter="${f}" aria-current="${f === filter}">${esc(label)}</button>`;
            })
            .join("")}
        </div>
        ${
          list.length === 0
            ? emptyState({ title: t("pools.noResults"), iconName: "pools" })
            : groups
                .map((g) => {
                  const items = list.filter((p) => poolService.deriveStatus(p) === g.key);
                  if (!items.length) return "";
                  return `<div class="section"><div class="section-header"><span class="section-header__title">${esc(g.label)}</span></div>${items.map((p) => poolCard(p, t, locale)).join("")}</div>`;
                })
                .join("")
        }
      </div>
    `;
    bindNavClicks(root);
    root.querySelectorAll("[data-countdown]").forEach((elm) => { if (elm.dataset.countdown) mountCountdown(elm, elm.dataset.countdown, { locale }); });
    root.querySelector("#pool-search").addEventListener("input", (e) => { term = e.target.value; draw(); });
    root.querySelectorAll("[data-filter]").forEach((b) => b.addEventListener("click", () => { filter = b.dataset.filter; draw(); }));
  }
  draw();
}
