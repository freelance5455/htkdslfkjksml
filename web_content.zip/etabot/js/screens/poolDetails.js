// ============================================================
// poolDetails.js — Pool details + participation flow.
//
// Participation state must clearly change based on whether the
// user already has an active entry in THIS pool — the primary
// action is never a generic "Participate" once that's true, per
// spec section 11 ("Primary Action must clearly change based on
// state") and section 15 (no accidental double participation).
// ============================================================

import { setHeader, setActiveNav, viewRoot, bindNavClicks } from "../app/layout.js";
import { poolService } from "../services/poolService.js";
import { entryService } from "../services/entryService.js";
import { walletService } from "../services/walletService.js";
import { esc } from "../utils/safeRender.js";
import { formatCurrency, formatExact } from "../utils/format.js";
import { statusBadge } from "../components/statusBadge.js";
import { participantRow } from "../components/cards.js";
import { emptyState, errorState, skeletonCards, openSheet, closeSheet, toast } from "../components/ui.js";
import { icon } from "../components/icons.js";
import { mountCountdown } from "../components/countdown.js";
import { navigate } from "../router.js";
import { telegramService } from "../telegram/telegramService.js";

export async function renderPoolDetails({ id }, ctx) {
  const { t, locale, identity } = ctx;
  setHeader({ t, title: t("pools.title"), back: true });
  setActiveNav("pools");
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(2)}</div>`;

  let pool, participantsPage, myEntries;
  try {
    [pool, participantsPage, myEntries] = await Promise.all([
      poolService.getPool(id),
      poolService.getParticipantsPage(id),
      entryService.listMyEntries(),
    ]);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderPoolDetails({ id }, ctx));
    return;
  }

  if (!pool) {
    root.innerHTML = `<div class="view">${emptyState({ title: t("pools.noResults"), iconName: "pools" })}</div>`;
    return;
  }

  const myEntry = myEntries.find((e) => e.poolId === pool.id && e.status !== "CANCELLED");
  const status = poolService.deriveStatus(pool);
  const pct = pool.capacity ? Math.min(100, Math.round((pool.participantCount / pool.capacity) * 100)) : 0;
  const canParticipate = ["OPEN", "CLOSING_SOON"].includes(status) && !myEntry;

  root.innerHTML = `
    <div class="view" style="padding-bottom:calc(var(--nav-height) + var(--safe-bottom) + 84px)">
      <div class="u-flex-between" style="margin-bottom:var(--sp-2)">
        <div>
          <div style="font-size:var(--fs-h1);font-weight:700">${esc(pool.name)}</div>
          <div class="u-muted">${esc(pool.id)}</div>
        </div>
        ${statusBadge(status, t)}
      </div>

      <div class="progress" style="margin-top:var(--sp-4)"><div class="progress__fill" style="width:${pct}%"></div></div>
      <div class="pool-card__grid card">
        <div><div class="pool-card__metric-label">${esc(t("pools.entry"))}</div><div class="pool-card__metric-value currency">${formatCurrency(pool.entryAmount)}</div></div>
        <div><div class="pool-card__metric-label">${esc(t("pools.participants"))}</div><div class="pool-card__metric-value">${pool.participantCount}/${pool.capacity}</div></div>
        <div><div class="pool-card__metric-label">${esc(t("poolDetails.timeRemaining"))}</div><div class="pool-card__metric-value" data-countdown="${esc(pool.closeAt || "")}">—</div></div>
      </div>

      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("poolDetails.about"))}</span></div>
        <p class="u-secondary">${esc(pool.description || pool.rules || "")}</p>
      </div>

      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("pools.yourParticipation"))}</span></div>
        ${
          myEntry
            ? `<div class="list-panel">
                <div class="row"><div class="row__body"><div class="row__title">${esc(t("myEntries.entryNumber"))}</div></div><div class="row__meta">#${esc(myEntry.entryNumber)}</div></div>
                <div class="row"><div class="row__body"><div class="row__title">${esc(t("pools.entry"))}</div></div><div class="row__meta currency">${formatCurrency(myEntry.amount)}</div></div>
                <div class="row"><div class="row__body"><div class="row__title">${esc(t("myEntries.createdAt"))}</div></div><div class="row__meta">${esc(formatExact(myEntry.createdAt, locale))}</div></div>
              </div>`
            : `<div class="notice">${icon("info")}<span>${esc(t("poolDetails.notParticipating"))}</span></div>`
        }
      </div>

      <div class="section">
        <div class="section-header">
          <span class="section-header__title">${esc(t("poolDetails.participants"))}</span>
          <button class="section-header__action" id="see-participants">${esc(t("home.viewAll"))}</button>
        </div>
        <div class="list-panel">${participantsPage.items.slice(0, 4).map((p) => participantRow(p, locale)).join("")}</div>
      </div>

      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("poolDetails.drawInfo"))}</span></div>
        <div class="list-panel">
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("poolDetails.drawDate"))}</div></div><div class="row__meta">${pool.drawAt ? esc(formatExact(pool.drawAt, locale)) : "—"}</div></div>
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("poolDetails.eligibleEntries"))}</div></div><div class="row__meta">${pool.participantCount}</div></div>
        </div>
      </div>

      <div class="section">
        <button class="card u-flex-between" style="width:100%;text-align:start" data-nav="/trust">
          <span>${icon("shield")} &nbsp;${esc(t("poolDetails.transparency"))}</span>${icon("chevronRight")}
        </button>
      </div>
    </div>
    <div style="position:fixed;bottom:calc(var(--nav-height) + var(--safe-bottom));left:50%;transform:translateX(-50%);width:100%;max-width:var(--app-max-width);padding:var(--sp-4);background:var(--color-bg);border-top:1px solid var(--color-border)">
      <button class="btn btn--primary" id="participate-btn" ${!canParticipate ? "disabled" : ""}>
        ${myEntry ? esc(t("poolDetails.alreadyParticipating")) : esc(t("poolDetails.participate"))}
      </button>
    </div>
  `;
  bindNavClicks(root);
  root.querySelectorAll("[data-countdown]").forEach((elm) => { if (elm.dataset.countdown) mountCountdown(elm, elm.dataset.countdown, { locale }); });
  root.querySelector("#see-participants").addEventListener("click", () => openParticipantSheet(pool.id, t, locale));
  if (canParticipate) {
    root.querySelector("#participate-btn").addEventListener("click", () => openParticipateSheet(pool, ctx));
  }
}

async function openParticipantSheet(poolId, t, locale) {
  let page = await poolService.getParticipantsPage(poolId);
  let term = "";
  const sheet = openSheet({
    title: t("poolDetails.participants"),
    contentHtml: `
      <div class="search-input">${icon("search")}<input class="input" id="p-search" placeholder="${esc(t("pools.searchPlaceholder"))}"></div>
      <div id="p-list" class="list-panel" style="margin-top:var(--sp-4)"></div>
      ${page.nextCursor ? `<button class="btn btn--secondary" id="p-more" style="margin-top:var(--sp-3)">${esc(t("common.loadMore"))}</button>` : ""}
    `,
  });
  function draw() {
    const list = poolService.searchParticipants(page.items, term);
    sheet.querySelector("#p-list").innerHTML = list.length ? list.map((p) => participantRow(p, locale)).join("") : emptyState({ title: t("pools.noResults") });
  }
  sheet.querySelector("#p-search").addEventListener("input", (e) => { term = e.target.value; draw(); });
  sheet.querySelector("#p-more")?.addEventListener("click", async (e) => {
    const next = await poolService.getParticipantsPage(poolId, { cursor: page.nextCursor });
    page = { items: [...page.items, ...next.items], nextCursor: next.nextCursor };
    if (!page.nextCursor) e.target.remove();
    draw();
  });
  draw();
}

function openParticipateSheet(pool, ctx) {
  const { t, identity } = ctx;
  walletService.getWallet(identity.telegramUserId).then((wallet) => {
    const after = wallet.available - pool.entryAmount;
    const insufficient = after < 0;
    openSheet({
      title: t("participate.title"),
      contentHtml: `
        <div class="list-panel">
          <div class="row"><div class="row__body"><div class="row__title">${esc(pool.name)}</div></div><div class="row__meta currency">${formatCurrency(pool.entryAmount)}</div></div>
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("participate.availableBalance"))}</div></div><div class="row__meta currency">${formatCurrency(wallet.available)}</div></div>
          <div class="row"><div class="row__body"><div class="row__title">${esc(t("participate.afterEntry"))}</div></div><div class="row__meta currency" style="color:${insufficient ? "var(--color-danger)" : "inherit"}">${formatCurrency(after)}</div></div>
        </div>
        <p class="u-secondary u-mt-6">${esc(t("participate.explain"))}</p>
        ${insufficient ? `<div class="notice" style="background:var(--color-danger-tint);color:var(--color-danger);margin-top:var(--sp-3)">${icon("errorIcon")}<span>${esc(t("participate.insufficientBalance"))}</span></div>` : ""}
        <button class="btn btn--primary u-mt-6" id="confirm-participate" ${insufficient ? "disabled" : ""}>${esc(t("participate.confirm"))}</button>
      `,
      onMount: (sheet) => {
        const btn = sheet.querySelector("#confirm-participate");
        btn.addEventListener("click", async () => {
          btn.disabled = true;
          btn.textContent = t("participate.submitting");
          telegramService.haptic("light");
          try {
            const entry = await entryService.createEntry({ poolId: pool.id, userId: identity.telegramUserId });
            closeSheet();
            telegramService.haptic("success");
            toast(`${t("participate.success")} — #${entry.entryNumber}`, "success");
            navigate("/entries");
          } catch {
            telegramService.haptic("error");
            btn.disabled = false;
            btn.textContent = t("participate.confirm");
            toast(t("errors.requestFailed"), "danger");
          }
        });
      },
    });
  });
}
