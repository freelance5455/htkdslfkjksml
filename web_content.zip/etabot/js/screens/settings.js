// ============================================================
// settings.js — /settings. Language + theme.
// ============================================================

import { setHeader, viewRoot } from "../app/layout.js";
import { loadLocale, getLocale } from "../i18n.js";
import { icon } from "../components/icons.js";
import { esc } from "../utils/safeRender.js";

export async function renderSettings({ t, onLocaleChange }) {
  setHeader({ t, title: t("profile.settings"), back: true });
  const root = document.querySelector("#view-root");
  const locale = getLocale();
  const theme = localStorage.getItem("etabot:theme") || "system";

  root.innerHTML = `
    <div class="view">
      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("profile.language"))}</span></div>
        <div class="list-panel">
          <div class="row"><div class="row__body"><div class="row__title">አማርኛ</div></div>${locale === "am" ? icon("check") : `<button class="btn btn--text" data-lang="am" style="width:auto">${esc(t("common.confirm"))}</button>`}</div>
          <div class="row"><div class="row__body"><div class="row__title">English</div></div>${locale === "en" ? icon("check") : `<button class="btn btn--text" data-lang="en" style="width:auto">${esc(t("common.confirm"))}</button>`}</div>
        </div>
      </div>
      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("profile.theme"))}</span></div>
        <div class="list-panel">
          ${["system", "light", "dark"]
            .map((th) => `<div class="row"><div class="row__body"><div class="row__title" style="text-transform:capitalize">${esc(th)}</div></div><button class="btn btn--text" data-theme="${th}" style="width:auto">${theme === th ? icon("check") : ""}</button></div>`)
            .join("")}
        </div>
      </div>
      <div class="section list-panel">
        <div class="row" data-nav="/notifications"><div class="row__body"><div class="row__title">${esc(t("notifications.title"))}</div></div>${icon("chevronRight")}</div>
        <div class="row" data-nav="/privacy"><div class="row__body"><div class="row__title">${esc(t("profile.privacy"))}</div></div>${icon("chevronRight")}</div>
        <div class="row" data-nav="/support"><div class="row__body"><div class="row__title">${esc(t("profile.support"))}</div></div>${icon("chevronRight")}</div>
      </div>
    </div>
  `;

  root.querySelectorAll("[data-lang]").forEach((b) => b.addEventListener("click", async () => {
    await loadLocale(b.dataset.lang);
    onLocaleChange?.();
  }));
  root.querySelectorAll("[data-theme]").forEach((b) => b.addEventListener("click", () => {
    const v = b.dataset.theme;
    if (v === "system") document.documentElement.removeAttribute("data-theme");
    else document.documentElement.setAttribute("data-theme", v);
    localStorage.setItem("etabot:theme", v);
    renderSettings({ t, onLocaleChange });
  }));
  root.querySelectorAll("[data-nav]").forEach((elm) => elm.addEventListener("click", async () => {
    const { navigate } = await import("../router.js");
    navigate(elm.dataset.nav);
  }));
}
