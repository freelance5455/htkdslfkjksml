// ============================================================
// trust.js — /trust. Compact, accordion-based, no walls of text.
// ============================================================

import { setHeader, viewRoot } from "../app/layout.js";
import { renderAccordion, bindAccordion } from "../components/accordion.js";

const SECTION_KEYS = [
  "howItWorks", "visibility", "entries", "eligibility", "draws",
  "winnerSelection", "records", "review", "wallet", "privacy", "security", "audit",
];

export async function renderTrust({ t }) {
  setHeader({ t, title: t("trust.title"), back: true });
  const root = document.querySelector("#view-root");
  const sections = SECTION_KEYS.map((k) => ({ title: t(`trust.${k}.title`), body: t(`trust.${k}.body`) }));
  root.innerHTML = `<div class="view"><div class="accordion">${renderAccordion(sections)}</div></div>`;
  bindAccordion(root);
}
