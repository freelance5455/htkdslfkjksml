// ============================================================
// requestDetails.js — /requests/:id, /funding/:id, /withdraw/:id
//
// THIS IS THE FIX for the routing bug described in the audit:
// all three routes previously fell through to the request LIST
// screen. They now all resolve here, to requestService.getRequest,
// which returns exactly one record regardless of which collection
// (funding or withdrawal) it lives in.
// ============================================================

import { setHeader, viewRoot } from "../app/layout.js";
import { requestService } from "../services/requestService.js";
import { esc } from "../utils/safeRender.js";
import { formatCurrency, formatExact } from "../utils/format.js";
import { statusBadge } from "../components/statusBadge.js";
import { renderTimeline } from "../components/timeline.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";
import { icon } from "../components/icons.js";

const FUNDING_STEPS = [
  { key: "SUBMITTED", labelKey: "requests.steps.submitted" },
  { key: "UNDER_REVIEW", labelKey: "requests.steps.underReview" },
  { key: "APPROVED", labelKey: "requests.steps.approved" },
  { key: "COMPLETED", labelKey: "requests.steps.updated" },
];

export async function renderRequestDetails({ id }, { t, locale, identity }) {
  setHeader({ t, title: t("requests.myRequests"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(2)}</div>`;

  let req;
  try {
    req = await requestService.getRequest(identity.telegramUserId, id);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderRequestDetails({ id }, { t, locale, identity }));
    return;
  }

  if (!req) {
    root.innerHTML = `<div class="view">${emptyState({ title: t("pools.noResults"), iconName: "ticket" })}</div>`;
    return;
  }

  const history = req.statusHistory?.length
    ? req.statusHistory
    : [{ status: req.status, at: req.createdAt }]; // minimum viable history if backend hasn't populated it yet

  root.innerHTML = `
    <div class="view">
      <div class="u-flex-between" style="margin-bottom:var(--sp-2)">
        <div>
          <div style="font-size:var(--fs-h1);font-weight:700">${esc(req.id)}</div>
          <div class="u-muted">${esc(req.kind === "funding" ? t("requests.funding") : t("requests.withdrawal"))}</div>
        </div>
        ${statusBadge(req.status, t)}
      </div>

      <div class="list-panel u-mt-6">
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("wallet.title"))}</div></div><div class="row__meta currency">${formatCurrency(req.amount)}</div></div>
        <div class="row"><div class="row__body"><div class="row__title">${esc(req.kind === "funding" ? t("funding.chooseMethod") : t("withdraw.destination"))}</div></div><div class="row__meta">${esc(req.method)}</div></div>
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("funding.reference"))}</div></div><div class="row__meta">${esc(req.reference || "—")}</div></div>
        <div class="row"><div class="row__body"><div class="row__title">${esc(t("myEntries.createdAt"))}</div></div><div class="row__meta">${esc(formatExact(req.createdAt, locale))}</div></div>
      </div>

      ${req.proofUrl ? `
      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("funding.proof"))}</span></div>
        <img src="${esc(req.proofUrl)}" alt="" style="width:100%;border-radius:var(--radius-md);border:1px solid var(--color-border)">
      </div>` : ""}

      ${req.note ? `<p class="u-secondary u-mt-6">${esc(req.note)}</p>` : ""}

      ${req.status === "REJECTED" && req.rejectionReason ? `
      <div class="notice u-mt-6" style="background:var(--color-danger-tint);color:var(--color-danger)">
        ${icon("errorIcon")}<span><strong>${esc(t("requests.rejectionReason"))}:</strong> ${esc(req.rejectionReason)}</span>
      </div>` : ""}

      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("requests.timeline"))}</span></div>
        ${renderTimeline(FUNDING_STEPS, history, t, locale)}
      </div>

      <div class="notice u-mt-6">${icon("info")}<span>${esc(t("funding.disclaimer"))}</span></div>
    </div>
  `;
}
