// ============================================================
// home.js — Home screen: balance hero, active pools, my active
// entries, upcoming event, recent activity, recent draws, trust
// shortcut. Uses a stat strip instead of wrapping everything in
// cards, per the "no excessive card UI" direction.
// ============================================================

import { setHeader, setActiveNav, viewRoot, bindNavClicks } from "../app/layout.js";
import { walletService } from "../services/walletService.js";
import { poolService } from "../services/poolService.js";
import { entryService } from "../services/entryService.js";
import { activityService } from "../services/activityService.js";
import { drawService } from "../services/drawService.js";
import { notificationService } from "../services/notificationService.js";
import { esc } from "../utils/safeRender.js";
import { formatCurrency } from "../utils/format.js";
import { poolCard, entryCard, activityRow, drawRow } from "../components/cards.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";
import { icon } from "../components/icons.js";
import { mountCountdown } from "../components/countdown.js";
import { navigate } from "../router.js";

export async function renderHome({ t, locale, identity }) {
  setHeader({ t, identity, showIdentity: true, unreadCount: await notificationService.unreadCount(identity.telegramUserId).catch(() => 0) });
  setActiveNav("home");
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(3)}</div>`;

  try {
    const [wallet, pools, entries, activityPage, draws] = await Promise.all([
      walletService.getWallet(identity.telegramUserId),
      poolService.listPools(),
      entryService.listMyEntries(),
      activityService.listActivityPage(identity.telegramUserId),
      drawService.listDraws(),
    ]);

    const activePools = pools.filter((p) => ["OPEN", "CLOSING_SOON"].includes(poolService.deriveStatus(p))).slice(0, 3);
    const myEntries = entries.filter((e) => e.status === "ACTIVE" || e.status === "PENDING").slice(0, 2);
    const upcoming = [...pools].filter((p) => p.closeAt).sort((a, b) => new Date(a.closeAt) - new Date(b.closeAt))[0];

    root.innerHTML = `
      <div class="view">
        <p style="font-size:var(--fs-h2);font-weight:700;margin-bottom:var(--sp-5)">${esc(t("home.welcome", { name: identity.telegramFirstName }))}</p>

        <div class="list-panel">
          <div class="stat-strip">
            <div class="stat-strip__item"><div class="stat-strip__value currency">${formatCurrency(wallet.available)}</div><div class="stat-strip__label">${esc(t("wallet.available"))}</div></div>
            <div class="stat-strip__item"><div class="stat-strip__value currency">${formatCurrency(wallet.locked)}</div><div class="stat-strip__label">${esc(t("wallet.locked"))}</div></div>
            <div class="stat-strip__item"><div class="stat-strip__value currency">${formatCurrency(wallet.pending)}</div><div class="stat-strip__label">${esc(t("wallet.pending"))}</div></div>
          </div>
        </div>
        <div style="display:flex;gap:var(--sp-3);margin-top:var(--sp-4)">
          <button class="btn btn--primary" data-nav="/funding">${esc(t("wallet.addFunds"))}</button>
          <button class="btn btn--secondary" data-nav="/withdraw">${esc(t("wallet.withdraw"))}</button>
        </div>

        ${upcoming ? `
        <div class="section">
          <div class="section-header"><span class="section-header__title">${esc(t("home.upcomingEvent"))}</span></div>
          <div class="notice">
            ${icon("clock")}
            <span>${esc(upcoming.name)} — <span data-countdown="${esc(upcoming.closeAt)}">—</span></span>
          </div>
        </div>` : ""}

        <div class="section">
          <div class="section-header">
            <span class="section-header__title">${esc(t("home.activePools"))}</span>
            <button class="section-header__action" data-nav="/pools">${esc(t("home.viewAll"))}</button>
          </div>
          ${activePools.length ? activePools.map((p) => poolCard(p, t, locale)).join("") : emptyState({ title: t("pools.noResults"), iconName: "pools" })}
        </div>

        <div class="section">
          <div class="section-header">
            <span class="section-header__title">${esc(t("home.myEntries"))}</span>
            <button class="section-header__action" data-nav="/entries">${esc(t("home.viewAll"))}</button>
          </div>
          ${myEntries.length ? myEntries.map((e) => entryCard(e, t, locale)).join("") : emptyState({ title: t("home.noEntries"), desc: t("home.noEntriesDesc"), iconName: "ticket" })}
        </div>

        <div class="section">
          <div class="section-header"><span class="section-header__title">${esc(t("home.recentActivity"))}</span></div>
          <div class="timeline">
            ${activityPage.items.length ? activityPage.items.slice(0, 3).map((a, i, arr) => activityRow(a, t, locale, i === arr.length - 1)).join("") : emptyState({ title: t("activity.empty"), iconName: "activity" })}
          </div>
        </div>

        <div class="section">
          <div class="section-header">
            <span class="section-header__title">${esc(t("home.recentDraws"))}</span>
            <button class="section-header__action" data-nav="/draws">${esc(t("home.viewAll"))}</button>
          </div>
          ${draws.length ? draws.slice(0, 2).map((d) => drawRow(d, t, locale)).join("") : emptyState({ title: t("draws.empty"), iconName: "ticket" })}
        </div>

        <div class="section">
          <button class="card u-flex-between" style="width:100%;text-align:start" data-nav="/trust">
            <span>${icon("shield")} &nbsp;${esc(t("home.trustShortcut"))}</span>
            ${icon("chevronRight")}
          </button>
        </div>
      </div>
    `;
    bindNavClicks(root);
    root.querySelectorAll("[data-nav]").forEach((elm) => {
      // Rows without a resolvable target (e.g. blank notification/activity target) shouldn't navigate anywhere.
      if (!elm.dataset.nav) elm.removeAttribute("data-nav");
    });
    root.querySelectorAll("[data-countdown]").forEach((elm) => {
      if (elm.dataset.countdown) mountCountdown(elm, elm.dataset.countdown, { locale });
    });
  } catch (e) {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderHome({ t, locale, identity }));
  }
}
