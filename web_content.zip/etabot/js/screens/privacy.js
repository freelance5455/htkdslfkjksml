// ============================================================
// privacy.js — /privacy.
//
// AUDIT FINDING (fixed here): the prior privacy screen was static
// markup describing settings with no persistence path. Every
// toggle here calls userService.updatePrivacy and shows an
// explicit saving/saved/failed state — it never silently claims
// success.
// ============================================================

import { setHeader, viewRoot } from "../app/layout.js";
import { userService } from "../services/userService.js";
import { esc } from "../utils/safeRender.js";
import { toast, skeletonLines, errorState } from "../components/ui.js";

const TOGGLES = [
  { key: "profileVisible", titleKey: "privacy.profileVisible", descKey: "privacy.profileVisibleDesc" },
  { key: "usernameVisible", titleKey: "privacy.usernameVisible", descKey: "privacy.usernameVisibleDesc" },
  { key: "participantListVisible", titleKey: "privacy.participantListVisible", descKey: "privacy.participantListVisibleDesc" },
];

export async function renderPrivacy({ t, identity }) {
  setHeader({ t, title: t("privacy.title"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonLines(4)}</div>`;

  let settings;
  try {
    settings = await userService.getPrivacy(identity);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderPrivacy({ t, identity }));
    return;
  }

  function draw() {
    root.innerHTML = `
      <div class="view">
        <div class="list-panel">
          ${TOGGLES.map((tg) => `
            <div class="row">
              <div class="row__body">
                <div class="row__title">${esc(t(tg.titleKey))}</div>
                <div class="row__subtitle">${esc(t(tg.descKey))}</div>
              </div>
              <button class="btn ${settings[tg.key] ? "btn--primary" : "btn--secondary"} btn--sm" style="width:auto" data-toggle="${tg.key}">
                ${settings[tg.key] ? esc(t("common.confirm")) : esc(t("common.cancel"))}
              </button>
            </div>`).join("")}
        </div>
        <div id="save-state" class="u-muted" style="margin-top:var(--sp-3);font-size:var(--fs-body-sm)"></div>
      </div>
    `;
    root.querySelectorAll("[data-toggle]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const key = btn.dataset.toggle;
        const next = { ...settings, [key]: !settings[key] };
        const stateEl = root.querySelector("#save-state");
        stateEl.textContent = t("privacy.saving");
        btn.disabled = true;
        try {
          settings = await userService.updatePrivacy(identity, { [key]: next[key] });
          stateEl.textContent = t("privacy.saved");
          toast(t("privacy.saved"), "success");
          draw();
        } catch {
          stateEl.textContent = t("privacy.saveFailed");
          toast(t("privacy.saveFailed"), "danger");
          btn.disabled = false;
        }
      });
    });
  }
  draw();
}
