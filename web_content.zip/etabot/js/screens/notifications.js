// ============================================================
// notifications.js — /notifications.
// ============================================================

import { setHeader, viewRoot } from "../app/layout.js";
import { notificationService } from "../services/notificationService.js";
import { notificationItem } from "../components/cards.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";
import { esc } from "../utils/safeRender.js";
import { navigate } from "../router.js";

export async function renderNotifications({ t, locale, identity }) {
  setHeader({ t, title: t("notifications.title"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(3)}</div>`;

  let items = [];
  try {
    items = await notificationService.listNotifications(identity.telegramUserId);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderNotifications({ t, locale, identity }));
    return;
  }

  root.innerHTML = `
    <div class="view">
      <div class="u-flex-between" style="margin-bottom:var(--sp-3)">
        <span></span>
        <button class="btn btn--text" style="width:auto" id="mark-all">${esc(t("notifications.markAllRead"))}</button>
      </div>
      ${items.length ? `<div class="list-panel">${items.map((n) => notificationItem(n, t, locale)).join("")}</div>` : emptyState({ title: t("notifications.empty"), iconName: "empty" })}
    </div>
  `;

  root.querySelectorAll("[data-id]").forEach((rowEl) =>
    rowEl.addEventListener("click", async () => {
      await notificationService.markRead(identity.telegramUserId, rowEl.dataset.id);
      // Deep-link targets are pre-validated against a safe route
      // allow-list in models.js:normalizeTarget — only navigate if
      // one was actually resolved.
      if (rowEl.dataset.nav) navigate(rowEl.dataset.nav);
    })
  );
  root.querySelector("#mark-all")?.addEventListener("click", async () => {
    await notificationService.markAllRead(identity.telegramUserId, items.map((i) => i.id));
    renderNotifications({ t, locale, identity });
  });
}
