// ============================================================
// support.js — /support.
// Contact channel comes from config, never invented on client.
// ============================================================

import { setHeader, viewRoot } from "../app/layout.js";
import { supportService } from "../services/supportService.js";
import { APP_CONFIG } from "../config.js";
import { esc } from "../utils/safeRender.js";
import { toast } from "../components/ui.js";
import { icon } from "../components/icons.js";
import { navigate } from "../router.js";

const HELP_TOPICS = [
  { key: "howItWorks", path: "/trust" },
  { key: "funding", path: "/funding" },
  { key: "withdrawal", path: "/withdraw" },
  { key: "entries", path: "/entries" },
  { key: "draw", path: "/draws" },
  { key: "privacy", path: "/privacy" },
];

export async function renderSupport({ t, identity }) {
  setHeader({ t, title: t("support.title"), back: true });
  const root = viewRoot();

  root.innerHTML = `
    <div class="view">
      <div class="section-header"><span class="section-header__title">${esc(t("support.help"))}</span></div>
      <div class="list-panel">
        ${HELP_TOPICS.map((h) => `<div class="row" data-nav="${h.path}"><div class="row__body"><div class="row__title">${esc(t(`support.categories.${h.key}`) !== `support.categories.${h.key}` ? t(`support.categories.${h.key}`) : t(`trust.${h.key}.title`) )}</div></div>${icon("chevronRight")}</div>`).join("")}
      </div>

      ${APP_CONFIG.support.contactHandle ? `
      <div class="notice u-mt-6">${icon("info")}<span>${esc(APP_CONFIG.support.contactHandle)}</span></div>
      ` : ""}

      <div class="section">
        <div class="section-header"><span class="section-header__title">${esc(t("support.title"))}</span></div>
        <form id="support-form">
          <div class="field">
            <label class="field__label">${esc(t("support.category"))}</label>
            <select class="select" name="category">
              ${supportService.categories.map((c) => `<option value="${esc(c)}">${esc(t(`support.categories.${c}`))}</option>`).join("")}
            </select>
          </div>
          <div class="field">
            <label class="field__label">${esc(t("support.message"))}</label>
            <textarea required class="textarea" name="message"></textarea>
          </div>
          <button class="btn btn--primary" type="submit">${esc(t("support.submit"))}</button>
        </form>
      </div>
    </div>
  `;

  root.querySelectorAll("[data-nav]").forEach((elm) => elm.addEventListener("click", () => navigate(elm.dataset.nav)));

  root.querySelector("#support-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true;
    const fd = new FormData(e.target);
    try {
      await supportService.createTicket({ userId: identity.telegramUserId, category: fd.get("category"), message: fd.get("message") });
      toast(t("support.sent"), "success");
      e.target.reset();
    } catch {
      toast(t("errors.requestFailed"), "danger");
    } finally {
      btn.disabled = false;
    }
  });
}
