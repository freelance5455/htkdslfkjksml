// ============================================================
// profile.js — /profile.
// ============================================================

import { setHeader, setActiveNav, viewRoot, bindNavClicks } from "../app/layout.js";
import { userService } from "../services/userService.js";
import { esc } from "../utils/safeRender.js";
import { formatExact } from "../utils/format.js";
import { icon } from "../components/icons.js";
import { skeletonCards, errorState } from "../components/ui.js";

export async function renderProfile({ t, locale, identity }) {
  setHeader({ t, title: t("profile.title") });
  setActiveNav("profile");
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(2)}</div>`;

  let profile;
  try {
    profile = await userService.getProfile(identity);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderProfile({ t, locale, identity }));
    return;
  }

  const initials = ((identity.telegramFirstName?.[0] || "") + (identity.telegramLastName?.[0] || "")).toUpperCase() || "?";
  const stats = profile.stats || { participations: 0, entries: 0, draws: 0, wins: 0 };
  const links = [
    { label: t("profile.settings"), path: "/settings", i: "profile" },
    { label: t("profile.privacy"), path: "/privacy", i: "lock" },
    { label: t("profile.trust"), path: "/trust", i: "shield" },
    { label: t("profile.support"), path: "/support", i: "help" },
  ];

  root.innerHTML = `
    <div class="view">
      <div class="card u-text-center">
        <span class="avatar avatar--lg" style="margin:0 auto var(--sp-3)">${identity.telegramPhotoUrl ? `<img src="${esc(identity.telegramPhotoUrl)}">` : esc(initials)}</span>
        <div style="font-size:var(--fs-h2);font-weight:700">${esc(identity.telegramFirstName)} ${esc(identity.telegramLastName)}</div>
        ${identity.telegramUsername ? `<div class="u-muted">@${esc(identity.telegramUsername)}</div>` : ""}
        ${profile.memberSince ? `<div class="u-muted" style="margin-top:4px">${esc(t("profile.memberSince"))}: ${esc(formatExact(profile.memberSince, locale))}</div>` : ""}
      </div>

      <div class="list-panel u-mt-6">
        <div class="stat-strip">
          <div class="stat-strip__item"><div class="stat-strip__value">${stats.participations}</div><div class="stat-strip__label">${esc(t("profile.stats.participations"))}</div></div>
          <div class="stat-strip__item"><div class="stat-strip__value">${stats.entries}</div><div class="stat-strip__label">${esc(t("profile.stats.entries"))}</div></div>
          <div class="stat-strip__item"><div class="stat-strip__value">${stats.wins}</div><div class="stat-strip__label">${esc(t("profile.stats.wins"))}</div></div>
        </div>
      </div>

      <div class="section list-panel">
        ${links.map((l) => `<div class="row" data-nav="${l.path}"><span class="row__icon">${icon(l.i)}</span><div class="row__body"><div class="row__title">${esc(l.label)}</div></div>${icon("chevronRight")}</div>`).join("")}
      </div>
    </div>
  `;
  bindNavClicks(root);
}
