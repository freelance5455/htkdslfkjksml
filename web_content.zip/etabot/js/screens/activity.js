// ============================================================
// activity.js — /activity.
// Uses activityService exclusively (never mockProvider directly).
// ============================================================

import { setHeader, setActiveNav, viewRoot, bindNavClicks } from "../app/layout.js";
import { activityService } from "../services/activityService.js";
import { activityRow } from "../components/cards.js";
import { emptyState, errorState, skeletonCards } from "../components/ui.js";
import { esc } from "../utils/safeRender.js";
import { createPaginator } from "../utils/pagination.js";

export async function renderActivity({ t, locale, identity }) {
  setHeader({ t, title: t("activity.title") });
  setActiveNav("activity");
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(3)}</div>`;

  const paginator = createPaginator((opts) => activityService.listActivityPage(identity.telegramUserId, opts));

  try {
    await paginator.loadMore();
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderActivity({ t, locale, identity }));
    return;
  }

  function draw() {
    const items = paginator.items;
    root.innerHTML = `
      <div class="view">
        ${
          items.length
            ? `<div class="timeline">${items.map((a, i) => activityRow(a, t, locale, i === items.length - 1)).join("")}</div>`
            : emptyState({ title: t("activity.empty"), iconName: "activity" })
        }
        ${!paginator.done ? `<button class="btn btn--secondary u-mt-6" id="load-more">${esc(t("common.loadMore"))}</button>` : ""}
      </div>
    `;
    bindNavClicks(root);
    root.querySelector("#load-more")?.addEventListener("click", async () => { await paginator.loadMore(); draw(); });
  }
  draw();
}
