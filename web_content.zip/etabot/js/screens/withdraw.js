// ============================================================
// withdraw.js — /withdraw. Manual withdrawal request only.
// Never claims a payout is completed from the client.
// ============================================================

import { setHeader, viewRoot } from "../app/layout.js";
import { walletService } from "../services/walletService.js";
import { requestService } from "../services/requestService.js";
import { esc } from "../utils/safeRender.js";
import { formatCurrency } from "../utils/format.js";
import { validateAmount, validateRequired } from "../utils/validate.js";
import { toast, confirmDialog, skeletonCards, errorState } from "../components/ui.js";
import { navigate } from "../router.js";

export async function renderWithdraw({ t, locale, identity }) {
  setHeader({ t, title: t("withdraw.title"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(1)}</div>`;

  let wallet;
  try {
    wallet = await walletService.getWallet(identity.telegramUserId);
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderWithdraw({ t, locale, identity }));
    return;
  }

  root.innerHTML = `
    <div class="view">
      <div class="list-panel">
        <div class="stat-strip">
          <div class="stat-strip__item"><div class="stat-strip__value currency">${formatCurrency(wallet.available)}</div><div class="stat-strip__label">${esc(t("wallet.available"))}</div></div>
          <div class="stat-strip__item"><div class="stat-strip__value currency">${formatCurrency(wallet.pending)}</div><div class="stat-strip__label">${esc(t("wallet.pending"))}</div></div>
        </div>
      </div>
      <form id="withdraw-form" class="u-mt-6">
        <div class="field">
          <label class="field__label">${esc(t("withdraw.amount"))}</label>
          <input required type="number" min="1" max="${wallet.available}" step="0.01" class="input" name="amount" id="wd-amount">
          <div class="field__hint" id="amount-err" style="color:var(--color-danger)"></div>
        </div>
        <div class="field">
          <label class="field__label">${esc(t("withdraw.destination"))}</label>
          <select class="select" name="destinationMethod"><option>Telebirr</option><option>CBE Birr</option><option>Bank Transfer</option></select>
        </div>
        <div class="field">
          <label class="field__label">${esc(t("withdraw.destinationRef"))}</label>
          <input required class="input" name="destinationReference" id="wd-ref">
          <div class="field__hint" id="ref-err" style="color:var(--color-danger)"></div>
        </div>
        <div class="field"><label class="field__label">${esc(t("funding.note"))}</label><textarea class="textarea" name="note"></textarea></div>
        <button class="btn btn--primary" type="submit" ${wallet.available <= 0 ? "disabled" : ""}>${esc(t("withdraw.submit"))}</button>
      </form>
    </div>
  `;

  const form = root.querySelector("#withdraw-form");
  const amountInput = form.querySelector("#wd-amount");
  const refInput = form.querySelector("#wd-ref");

  amountInput.addEventListener("input", () => {
    const err = validateAmount(amountInput.value, { max: wallet.available });
    form.querySelector("#amount-err").textContent = err ? t(err) : "";
  });
  refInput.addEventListener("input", () => {
    const err = validateRequired(refInput.value);
    form.querySelector("#ref-err").textContent = err ? t(err) : "";
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const amount = Number(amountInput.value);
    const amountErr = validateAmount(amountInput.value, { max: wallet.available });
    const refErr = validateRequired(refInput.value);
    form.querySelector("#amount-err").textContent = amountErr ? t(amountErr) : "";
    form.querySelector("#ref-err").textContent = refErr ? t(refErr) : "";
    if (amountErr || refErr) return;

    confirmDialog({
      title: t("withdraw.title"),
      body: `${t("withdraw.amount")}: ${formatCurrency(amount)} ETB<br>${t("withdraw.remaining")}: ${formatCurrency(wallet.available - amount)} ETB`,
      confirmLabel: t("common.confirm"),
      cancelLabel: t("common.cancel"),
      onConfirm: async () => {
        const btn = form.querySelector("button[type=submit]");
        btn.disabled = true;
        try {
          const req = await requestService.createWithdrawalRequest({
            userId: identity.telegramUserId, amount,
            destinationMethod: form.destinationMethod.value,
            destinationReference: refInput.value,
            note: form.note.value,
          });
          toast(t("status.request.submitted"), "success");
          navigate(`/requests/${req.id}`);
        } catch {
          toast(t("errors.requestFailed"), "danger");
          btn.disabled = false;
        }
      },
    });
  });
}
