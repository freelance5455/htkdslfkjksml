// ============================================================
// funding.js — /funding. Manual funding only, no payment gateway.
// Payment methods are fetched from paymentMethodService — never
// hard-coded here.
// ============================================================

import { setHeader, viewRoot } from "../app/layout.js";
import { paymentMethodService } from "../services/paymentMethodService.js";
import { requestService } from "../services/requestService.js";
import { esc } from "../utils/safeRender.js";
import { formatCurrency } from "../utils/format.js";
import { validateAmount, validateReference, validateFile, MIN_FUNDING_AMOUNT } from "../utils/validate.js";
import { icon } from "../components/icons.js";
import { toast, skeletonCards, errorState } from "../components/ui.js";
import { navigate } from "../router.js";
import { tList } from "../i18n.js";

export async function renderFunding({ t, locale, identity }) {
  setHeader({ t, title: t("funding.title"), back: true });
  const root = viewRoot();
  root.innerHTML = `<div class="view">${skeletonCards(2)}</div>`;

  let methods = [];
  try {
    methods = await paymentMethodService.getActiveMethods();
  } catch {
    root.innerHTML = `<div class="view">${errorState({ desc: { title: t("errors.generic") }, retryLabel: t("common.retry") })}</div>`;
    document.getElementById("retry-btn")?.addEventListener("click", () => renderFunding({ t, locale, identity }));
    return;
  }

  let selected = methods[0] || null;

  function draw() {
    root.innerHTML = `
      <div class="view">
        <div class="section-header"><span class="section-header__title">${esc(t("funding.chooseMethod"))}</span></div>
        <div class="tabs">
          ${methods.map((m) => `<button class="tabs__item" data-method="${esc(m.id)}" aria-current="${selected?.id === m.id}">${esc(m.name)}</button>`).join("")}
        </div>

        ${selected ? `
        <div class="section-header" style="margin-top:var(--sp-5)"><span class="section-header__title">${esc(t("funding.instructions"))}</span></div>
        <div class="list-panel">
          <div class="row"><div class="row__body"><div class="row__title">${esc(selected.recipient)}</div></div></div>
          <div class="row u-flex-between">
            <div class="row__body"><div class="row__title" id="acct-number">${esc(selected.account)}</div></div>
            <button class="icon-btn" id="copy-acct" aria-label="${esc(t("common.copy"))}">${icon("copy")}</button>
          </div>
          <div class="row"><div class="row__subtitle">${esc(selected.instructions)}</div></div>
        </div>
        <ol style="margin:var(--sp-4) 0;padding-inline-start:var(--sp-5);color:var(--color-text-secondary);font-size:var(--fs-body-sm)">
          ${tList("funding.steps").map((s) => `<li style="margin-bottom:4px">${esc(s)}</li>`).join("")}
        </ol>
        ` : `<p class="u-muted u-mt-6">${esc(t("pools.noResults"))}</p>`}

        <div class="notice u-mt-6">${icon("info")}<span>${esc(t("wallet.minFunding", { amount: formatCurrency(MIN_FUNDING_AMOUNT) }))}</span></div>

        <form id="funding-form" class="u-mt-6">
          <div class="field">
            <label class="field__label">${esc(t("funding.amount"))}</label>
            <input required type="number" min="${MIN_FUNDING_AMOUNT}" step="0.01" class="input" name="amount" id="fund-amount">
            <div class="field__hint" id="amount-err" style="color:var(--color-danger)"></div>
          </div>
          <div class="field">
            <label class="field__label">${esc(t("funding.reference"))}</label>
            <input required class="input" name="reference" id="fund-ref">
            <div class="field__hint" id="ref-err" style="color:var(--color-danger)"></div>
          </div>
          <div class="field">
            <label class="field__label">${esc(t("funding.proof"))}</label>
            <div class="uploader">${icon("upload")}<div>${esc(t("funding.proof"))}</div><input type="file" name="proof" id="fund-proof" accept="image/jpeg,image/png,application/pdf" style="margin-top:var(--sp-2)"></div>
            <div class="field__hint" id="file-err" style="color:var(--color-danger)"></div>
          </div>
          <div class="field"><label class="field__label">${esc(t("funding.note"))}</label><textarea class="textarea" name="note"></textarea></div>
          <p class="u-muted" style="margin-bottom:var(--sp-4)">${icon("info")} ${esc(t("funding.disclaimer"))}</p>
          <button class="btn btn--primary" type="submit" ${selected ? "" : "disabled"}>${esc(t("funding.submit"))}</button>
        </form>
      </div>
    `;

    root.querySelectorAll("[data-method]").forEach((b) => b.addEventListener("click", () => { selected = methods.find((m) => m.id === b.dataset.method); draw(); }));
    root.querySelector("#copy-acct")?.addEventListener("click", () => {
      navigator.clipboard?.writeText(selected.account).then(() => toast(t("common.copied"), "success"));
    });

    const form = root.querySelector("#funding-form");
    const amountInput = form.querySelector("#fund-amount");
    const refInput = form.querySelector("#fund-ref");
    const fileInput = form.querySelector("#fund-proof");

    amountInput.addEventListener("input", () => {
      const err = validateAmount(amountInput.value, { min: MIN_FUNDING_AMOUNT });
      form.querySelector("#amount-err").textContent = err ? t(err) : "";
    });
    refInput.addEventListener("input", () => {
      const err = validateReference(refInput.value);
      form.querySelector("#ref-err").textContent = err ? t(err) : "";
    });
    fileInput.addEventListener("change", () => {
      const err = validateFile(fileInput.files[0]);
      form.querySelector("#file-err").textContent = err ? t(err) : "";
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const amountErr = validateAmount(amountInput.value, { min: MIN_FUNDING_AMOUNT });
      const refErr = validateReference(refInput.value);
      const fileErr = validateFile(fileInput.files[0]);
      form.querySelector("#amount-err").textContent = amountErr ? t(amountErr) : "";
      form.querySelector("#ref-err").textContent = refErr ? t(refErr) : "";
      form.querySelector("#file-err").textContent = fileErr ? t(fileErr) : "";
      if (amountErr || refErr || fileErr) return;

      const btn = form.querySelector("button[type=submit]");
      btn.disabled = true;
      try {
        const req = await requestService.createFundingRequest({
          userId: identity.telegramUserId,
          amount: Number(amountInput.value),
          method: selected.name,
          reference: refInput.value,
          note: form.note.value,
          file: fileInput.files[0] || null,
        });
        toast(t("status.request.submitted"), "success");
        navigate(`/requests/${req.id}`);
      } catch {
        toast(t("errors.requestFailed"), "danger");
        btn.disabled = false;
      }
    });
  }
  draw();
}
