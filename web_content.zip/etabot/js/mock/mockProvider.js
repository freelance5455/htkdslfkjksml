// ============================================================
// mockProvider.js — THE ONLY source of synthetic/demo data in
// this project.
//
// AUDIT FINDING (fixed here): the previous project scattered
// synthetic data across dev-data.js and it was pulled directly
// into app.js's renderActivity() unconditionally — meaning even a
// production build with Firebase connected would still show fake
// activity. Every service now imports from HERE, and only when
// firebaseClient.isDevMode() is true. If you are looking for where
// "fake data" lives, it is nowhere else.
//
// Nothing here is presented to the user as a completed real
// transaction — statuses stay consistent with a believable
// pending/under-review state where that matters.
// ============================================================

import { makePool, makeParticipant, makeEntry, makeWallet, makeLedgerTransaction, makeRequest, makeNotification, makeActivityItem, makeDraw } from "../models/models.js";
import { PoolStatus, EntryStatus, RequestStatus, TransactionStatus } from "../models/status.js";

const now = Date.now();
const past = (days = 0, hours = 0) => new Date(now - days * 86400000 - hours * 3600000).toISOString();
const future = (days = 0, hours = 0) => new Date(now + days * 86400000 + hours * 3600000).toISOString();

export const mockProvider = {
  user() {
    return {
      telegramUserId: "dev-000000",
      telegramFirstName: "Abebe",
      telegramLastName: "Kebede",
      telegramUsername: "abebe123",
      telegramPhotoUrl: "",
      memberSince: past(120),
      stats: { participations: 14, entries: 21, draws: 6, wins: 1 },
    };
  },

  wallet() {
    return makeWallet({ available: 240, locked: 60, pending: 50 });
  },

  privacy() {
    return { profileVisible: true, usernameVisible: true, participantListVisible: true };
  },

  pools() {
    return [
      makePool({ id: "PL-1042", name: "ሳምንታዊ ገንዳ", entryAmount: 50, capacity: 100, participantCount: 72, status: PoolStatus.OPEN, closeAt: future(2, 4), drawAt: future(2, 5) }),
      makePool({ id: "PL-1043", name: "ወርሃዊ ትልቅ ገንዳ", entryAmount: 200, capacity: 500, participantCount: 481, status: PoolStatus.CLOSING_SOON, closeAt: future(0, 3), drawAt: future(0, 4) }),
      makePool({ id: "PL-1030", name: "ፈጣን ገንዳ", entryAmount: 25, capacity: 50, participantCount: 50, status: PoolStatus.COMPLETED, closeAt: past(1), drawAt: past(1) }),
      makePool({ id: "PL-1044", name: "የቅዳሜ ገንዳ", entryAmount: 100, capacity: 150, participantCount: 38, status: PoolStatus.OPEN, closeAt: future(4, 0), drawAt: future(4, 1) }),
      makePool({ id: "PL-1050", name: "አዲስ ገንዳ", entryAmount: 75, capacity: 80, participantCount: 0, status: PoolStatus.OPEN, openAt: future(0, 2), closeAt: future(5, 0), drawAt: future(5, 1) }),
    ];
  },

  participantsPage(poolId, cursor) {
    const names = ["Abebe K.", "Selam T.", "Kalkidan M.", "Mekdes A.", "Yonas B.", "Bethel G."];
    const start = cursor || 0;
    const items = Array.from({ length: 8 }).map((_, i) =>
      makeParticipant({
        userId: `dev-user-${start + i}`,
        displayName: names[(start + i) % names.length],
        username: (start + i) % 3 === 0 ? `user${start + i}` : "",
        entryNumber: String(800 + start + i).padStart(5, "0"),
        joinedAt: past(0, start + i),
      })
    );
    const nextCursor = start + 8 < 24 ? start + 8 : null;
    return { items, nextCursor };
  },

  entries() {
    return [
      makeEntry({ id: "EN-9001", poolId: "PL-1042", poolName: "ሳምንታዊ ገንዳ", entryNumber: "00842", amount: 50, status: EntryStatus.ACTIVE, createdAt: past(0, 1) }),
      makeEntry({ id: "EN-8991", poolId: "PL-1030", poolName: "ፈጣን ገንዳ", entryNumber: "00027", amount: 25, status: EntryStatus.COMPLETED, createdAt: past(1), drawId: "DR-3391" }),
    ];
  },

  ledger() {
    return [
      makeLedgerTransaction({ id: "TX-8841", type: "deposit", amount: 150, balanceBefore: 90, balanceAfter: 240, status: TransactionStatus.COMPLETED, reference: "FR-2201", description: "Funding request approved", createdAt: past(0, 5) }),
      makeLedgerTransaction({ id: "TX-8830", type: "entry", amount: -50, balanceBefore: 140, balanceAfter: 90, status: TransactionStatus.COMPLETED, reference: "EN-9001", description: "Pool entry — ሳምንታዊ ገንዳ", createdAt: past(0, 1) }),
      makeLedgerTransaction({ id: "TX-8801", type: "withdrawal", amount: -100, balanceBefore: 240, balanceAfter: 140, status: TransactionStatus.PENDING, reference: "WD-1091", description: "Withdrawal request submitted", createdAt: past(2) }),
    ];
  },

  requests() {
    return [
      makeRequest({ id: "FR-2201", kind: "funding", amount: 150, method: "Telebirr", reference: "TB998211", status: RequestStatus.APPROVED, createdAt: past(0, 6), updatedAt: past(0, 5),
        statusHistory: [
          { status: RequestStatus.SUBMITTED, at: past(0, 6) },
          { status: RequestStatus.UNDER_REVIEW, at: past(0, 5.5) },
          { status: RequestStatus.APPROVED, at: past(0, 5) },
        ] }),
      makeRequest({ id: "FR-2188", kind: "funding", amount: 300, method: "CBE Birr", reference: "CBE44120", status: RequestStatus.UNDER_REVIEW, createdAt: past(0, 2),
        statusHistory: [
          { status: RequestStatus.SUBMITTED, at: past(0, 2) },
          { status: RequestStatus.UNDER_REVIEW, at: past(0, 1) },
        ] }),
      makeRequest({ id: "WD-1091", kind: "withdrawal", amount: 100, method: "Telebirr", reference: "0911223344", status: RequestStatus.PENDING ?? RequestStatus.SUBMITTED, createdAt: past(2),
        statusHistory: [{ status: RequestStatus.SUBMITTED, at: past(2) }] }),
    ];
  },

  notifications() {
    return [
      makeNotification({ id: "n1", category: "draw", title: "የዕጣ ውጤት ወጥቷል", body: "ፈጣን ገንዳ ውጤት ይመልከቱ", createdAt: past(1), read: false, target: "/draws/DR-3391" }),
      makeNotification({ id: "n2", category: "funding", title: "የገንዘብ ጥያቄ ጸድቋል", body: "150.00 ETB ወደ ቀሪ ሂሳብዎ ታክሏል", createdAt: past(0, 5), read: true, target: "/requests/FR-2201" }),
      makeNotification({ id: "n3", category: "entry", title: "ተሳትፎ ተመዝግቧል", body: "ሳምንታዊ ገንዳ", createdAt: past(0, 1), read: true, target: "/pools/PL-1042" }),
    ];
  },

  activity() {
    return [
      makeActivityItem({ id: "a1", type: "entry", title: "አዲስ ተሳትፎ ተፈጥሯል", description: "ሳምንታዊ ገንዳ • Entry #00842", timestamp: past(0, 1), target: "/entries/EN-9001" }),
      makeActivityItem({ id: "a2", type: "deposit", title: "የገንዘብ ጥያቄ ጸድቋል", description: "150.00 ETB", timestamp: past(0, 5), target: "/requests/FR-2201" }),
      makeActivityItem({ id: "a3", type: "draw", title: "የዕጣ ውጤት ወጥቷል", description: "ፈጣን ገንዳ", timestamp: past(1), target: "/draws/DR-3391" }),
      makeActivityItem({ id: "a4", type: "withdrawal", title: "የማውጣት ጥያቄ ገብቷል", description: "100.00 ETB", timestamp: past(2), target: "/requests/WD-1091" }),
    ];
  },

  draws() {
    return [
      makeDraw({
        id: "DR-3391", poolId: "PL-1030", poolName: "ፈጣን ገንዳ", status: "COMPLETED", completedAt: past(1),
        eligibleParticipantCount: 50, eligibleEntryCount: 50, selectedEntryId: "EN-8991", algorithmVersion: "v1.2",
        winner: { displayName: "Selam T.", username: "selam_t", entryNumber: "00027" },
      }),
    ];
  },

  paymentMethods() {
    return [
      { id: "telebirr", name: "Telebirr", recipient: "ETA BOT", account: "0900000000", instructions: "Send to the Telebirr number above and keep the confirmation SMS as your reference.", active: true },
      { id: "cbe", name: "CBE Birr", recipient: "ETA BOT", account: "1000123456789", instructions: "Transfer to this CBE account and use the transaction reference from your receipt.", active: true },
    ];
  },
};
