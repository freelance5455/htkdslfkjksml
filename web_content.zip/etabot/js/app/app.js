// ============================================================
// app.js — Central application bootstrap.
//
// This is the ONLY place startup sequencing happens. index.html
// stays a thin shell; every actual decision (Telegram init, theme,
// locale, identity, routing) is made here so the sequence is
// auditable in one place.
// ============================================================

import { telegramService } from "../telegram/telegramService.js";
import { initFirebase, isDevMode } from "../services/firebaseClient.js";
import { authService } from "../services/authService.js";
import { loadLocale, t, getLocale } from "../i18n.js";
import { registerRoute, registerNotFound, startRouter, navigate } from "../router.js";
import { mountUiRoots, monitorConnectivity, toast } from "../components/ui.js";
import { renderNav, setActiveNav } from "./layout.js";
import { APP_CONFIG } from "../config.js";
import { notificationService } from "../services/notificationService.js";

import { renderHome } from "../screens/home.js";
import { renderPools } from "../screens/pools.js";
import { renderPoolDetails } from "../screens/poolDetails.js";
import { renderMyEntries, renderEntryDetails } from "../screens/myEntries.js";
import { renderWallet, renderTransactionDetails } from "../screens/wallet.js";
import { renderFunding } from "../screens/funding.js";
import { renderWithdraw } from "../screens/withdraw.js";
import { renderRequests } from "../screens/requests.js";
import { renderRequestDetails } from "../screens/requestDetails.js";
import { renderActivity } from "../screens/activity.js";
import { renderNotifications } from "../screens/notifications.js";
import { renderDraws, renderDrawDetails } from "../screens/draws.js";
import { renderTrust } from "../screens/trust.js";
import { renderProfile } from "../screens/profile.js";
import { renderSettings } from "../screens/settings.js";
import { renderPrivacy } from "../screens/privacy.js";
import { renderSupport } from "../screens/support.js";

let identity = null;

/** Bundles the values every screen needs so screens don't each re-derive them. */
function ctx() {
  return { t, locale: getLocale(), identity };
}

function withCtx(renderFn) {
  return (params = {}) => renderFn(params, ctx());
}

function registerRoutes() {
  registerRoute("/home", () => renderHome(ctx()));
  registerRoute("/pools", () => renderPools(ctx()));
  registerRoute("/pools/:id", withCtx(renderPoolDetails));
  registerRoute("/entries", () => renderMyEntries(ctx()));
  registerRoute("/entries/:id", withCtx(renderEntryDetails));
  registerRoute("/wallet", () => renderWallet(ctx()));
  registerRoute("/wallet/transactions/:id", withCtx(renderTransactionDetails));
  registerRoute("/requests", () => renderRequests(ctx()));
  registerRoute("/requests/:id", withCtx(renderRequestDetails));
  registerRoute("/funding", () => renderFunding(ctx()));
  // Fixed routing bug: these now resolve a SINGLE request, not the list.
  registerRoute("/funding/:id", withCtx(renderRequestDetails));
  registerRoute("/withdraw", () => renderWithdraw(ctx()));
  registerRoute("/withdraw/:id", withCtx(renderRequestDetails));
  registerRoute("/activity", () => renderActivity(ctx()));
  registerRoute("/notifications", () => renderNotifications(ctx()));
  registerRoute("/draws", () => renderDraws(ctx()));
  registerRoute("/draws/:id", withCtx(renderDrawDetails));
  registerRoute("/trust", () => renderTrust(ctx()));
  registerRoute("/profile", () => renderProfile(ctx()));
  registerRoute("/settings", () => renderSettings({ ...ctx(), onLocaleChange: renderChrome }));
  registerRoute("/privacy", () => renderPrivacy(ctx()));
  registerRoute("/support", () => renderSupport(ctx()));
  registerNotFound(() => navigate("/home"));
}

function renderChrome() {
  renderNav(t, currentNavRoute());
  // Re-run whatever route is active so newly loaded locale strings apply immediately.
  window.dispatchEvent(new HashChangeEvent("hashchange"));
}

function currentNavRoute() {
  const path = (location.hash || "#/home").slice(1);
  return path.split("/")[1] || "home";
}

function applyTheme() {
  const saved = localStorage.getItem("etabot:theme");
  if (saved && saved !== "system") {
    document.documentElement.setAttribute("data-theme", saved);
    return;
  }
  // Respect Telegram's reported color scheme when no explicit
  // preference has been set, per spec section 24.
  if (telegramService.getColorScheme() === "dark") {
    document.documentElement.setAttribute("data-theme", "dark");
  }
}

function showOnboardingIfNeeded() {
  if (localStorage.getItem("etabot:onboarded")) return;
  const overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;background:var(--color-bg);z-index:100;display:flex;flex-direction:column;justify-content:center;padding:32px;text-align:center;max-width:var(--app-max-width);margin:0 auto";
  overlay.innerHTML = `
    <div style="font-size:32px;font-weight:800;margin-bottom:12px">${t("onboarding.title")}</div>
    <p class="u-secondary" style="margin-bottom:32px">${t("onboarding.subtitle")}</p>
    <button class="btn btn--primary" id="ob-continue">${t("onboarding.continue")}</button>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector("#ob-continue").addEventListener("click", () => {
    localStorage.setItem("etabot:onboarded", "1");
    overlay.remove();
  });
}

function installGlobalErrorHandling() {
  // A last line of defense so an unexpected exception surfaces as
  // a plain, non-technical toast instead of a frozen/blank screen.
  window.addEventListener("unhandledrejection", (e) => {
    console.error("[ETA BOT] Unhandled rejection:", e.reason);
    toast(t("errors.generic"), "danger");
  });
  window.addEventListener("error", (e) => {
    console.error("[ETA BOT] Uncaught error:", e.error || e.message);
  });
}

async function bootstrap() {
  mountUiRoots();
  installGlobalErrorHandling();

  // 1. Telegram Mini App integration first — theme/viewport/back
  //    button depend on knowing whether we're actually in Telegram.
  telegramService.initialize();
  telegramService.expand();
  applyTheme();

  // 2. Locale next, so every subsequent render already has strings.
  const savedLocale = localStorage.getItem("etabot:locale") || APP_CONFIG.defaultLocale;
  await loadLocale(savedLocale);

  monitorConnectivity(t("common.offline"));

  // 3. Firebase client + identity. In dev mode this never pretends
  //    to be a verified session — see authService.js.
  const fb = initFirebase();
  const devBanner = document.getElementById("dev-banner");
  if (fb.devMode && devBanner) {
    devBanner.style.display = "block";
    devBanner.textContent = t("common.developmentMode");
  }

  identity = await authService.signIn();

  // 4. Routes + chrome, then start the router.
  registerRoutes();
  renderNav(t, currentNavRoute());
  startRouter();

  showOnboardingIfNeeded();
}

bootstrap();
