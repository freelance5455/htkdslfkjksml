// ============================================================
// layout.js — App header + bottom navigation chrome.
// ============================================================

import { icon } from "../components/icons.js";
import { esc } from "../utils/safeRender.js";
import { navigate } from "../router.js";

const el = (sel) => document.querySelector(sel);

export function setHeader({ t, identity, showIdentity = false, title = "", back = false, unreadCount = 0 }) {
  const header = el("#app-header");
  if (showIdentity && identity) {
    const initials = (identity.telegramFirstName?.[0] || "") + (identity.telegramLastName?.[0] || "");
    header.innerHTML = `
      <div class="app-header__identity">
        <span class="avatar avatar--sm">${identity.telegramPhotoUrl ? `<img src="${esc(identity.telegramPhotoUrl)}" alt="">` : esc(initials)}</span>
        <div class="app-header__text">
          <div class="app-header__name">${esc(identity.telegramFirstName || "")}</div>
        </div>
      </div>
      <button class="icon-btn" id="notif-btn" aria-label="${esc(t("notifications.title"))}">
        ${icon("bell")}
        ${unreadCount > 0 ? `<span class="badge-dot">${unreadCount > 9 ? "9+" : unreadCount}</span>` : ""}
      </button>
    `;
    el("#notif-btn")?.addEventListener("click", () => navigate("/notifications"));
  } else {
    header.innerHTML = `
      ${back ? `<button class="app-header__back" id="header-back" aria-label="Back">${icon("back")}</button>` : `<span style="width:36px"></span>`}
      <div class="app-header__text u-text-center" style="flex:1"><div class="app-header__name">${esc(title)}</div></div>
      <span style="width:36px"></span>
    `;
    el("#header-back")?.addEventListener("click", () => window.history.length > 1 ? window.history.back() : navigate("/home"));
  }
}

export function renderNav(t, activeRoute) {
  const nav = el("#bottom-nav");
  const items = [
    { route: "home", path: "/home", icon: "home", label: t("nav.home") },
    { route: "pools", path: "/pools", icon: "pools", label: t("nav.pools") },
    { route: "activity", path: "/activity", icon: "activity", label: t("nav.activity") },
    { route: "wallet", path: "/wallet", icon: "wallet", label: t("nav.wallet") },
    { route: "profile", path: "/profile", icon: "profile", label: t("nav.profile") },
  ];
  nav.innerHTML = items
    .map((i) => `<button class="bottom-nav__item" data-route="${i.route}" data-path="${i.path}" aria-current="${i.route === activeRoute}">${icon(i.icon)}<span>${esc(i.label)}</span></button>`)
    .join("");
  nav.querySelectorAll(".bottom-nav__item").forEach((b) => b.addEventListener("click", () => navigate(b.dataset.path)));
}

export function setActiveNav(route) {
  el("#bottom-nav")?.querySelectorAll(".bottom-nav__item").forEach((b) => {
    b.setAttribute("aria-current", b.dataset.route === route ? "true" : "false");
  });
}

export function bindNavClicks(root) {
  root.querySelectorAll("[data-nav]").forEach((elm) => elm.addEventListener("click", () => navigate(elm.dataset.nav)));
}

export function viewRoot() {
  return el("#view-root");
}
