// ============================================================
// config.js — Centralized, non-secret configuration.
// ============================================================

export const APP_CONFIG = {
  appName: "ETA BOT",
  environment: "development", // "development" | "production"

  firebase: {
    apiKey: "REPLACE_WITH_FIREBASE_API_KEY",
    authDomain: "REPLACE_WITH_PROJECT.firebaseapp.com",
    projectId: "REPLACE_WITH_PROJECT_ID",
    storageBucket: "REPLACE_WITH_PROJECT.appspot.com",
    messagingSenderId: "REPLACE_WITH_SENDER_ID",
    appId: "REPLACE_WITH_APP_ID",
  },

  minFundingAmount: 50,

  featureFlags: {
    withdrawalsEnabled: true,
    fundingEnabled: true,
    supportEnabled: true,
  },

  telegram: {
    requireTelegramContext: false, // false enables the browser dev fallback
  },

  support: {
    // Left null on purpose — a real contact channel is configured
    // by the backend/system, never invented on the client.
    contactHandle: null,
  },

  defaultLocale: "am",
};
