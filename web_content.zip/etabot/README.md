# ETA BOT — Telegram Mini App (User Application)

This is the **user-facing** Telegram Mini App only. There is no admin
panel in this project by design — it is a separate future project that
will talk to the same trusted backend.

This is a **frontend-complete, backend-pending** build: every screen,
route, and service interface described below is implemented and
navigable end-to-end using either real Firebase data (once configured)
or an isolated development mock provider. **Firebase/Cloud Functions
integration is explicitly the next stage** — see "Frontend/backend
boundary" below.

## Core product concept

Users join pools by contributing a fixed entry amount (minimum funding
deposit: **50 ETB**). When a pool closes, eligible entries go into a
draw; one entry is selected as the winner. Funding and withdrawals are
manual, reviewed requests — there is no automatic payment gateway.

## Directory structure

```
index.html                 thin shell — no business logic
css/                        variables, base, components, responsive
i18n/                       am.json, en.json — full terminology map
firebase/                   firestore.rules, storage.rules, indexes.json
js/
  app/
    app.js                  central bootstrap: Telegram, theme, locale,
                             identity, routing, global error handling
    layout.js               header / bottom nav chrome
  telegram/
    telegramService.js      the ONLY module that touches window.Telegram
  services/                 one file per domain — see "Service layer"
  models/
    models.js                data model factories (Pool, Entry, Wallet,
                             LedgerTransaction, Request, Notification,
                             ActivityItem, Draw, PrivacySettings,
                             UserIdentity)
    status.js                centralized status → label/icon/tone config
  utils/
    safeRender.js            esc() — XSS-safe string escaping
    format.js                currency + date/time formatting
    validate.js              form validation (amount, reference, file)
    idempotency.js           double-submit guard
    pagination.js            cursor-pagination controller
  components/                reusable UI: icons, ui (toast/sheet/modal),
                             cards (PoolCard/EntryCard/...), statusBadge,
                             countdown, timeline, accordion
  screens/                   one render function per screen (see Routing)
  mock/
    mockProvider.js          THE ONLY source of synthetic data, used
                             only when firebaseClient.isDevMode() is true
  router.js                  hash router + Telegram back-button integration
  i18n.js                    locale loading + t()/tList()
  config.js                  non-secret configuration
```

## Routing

All routes are registered in `js/app/app.js`:

```
/home
/pools               /pools/:id
/entries             /entries/:id
/wallet              /wallet/transactions/:id
/requests            /requests/:id
/funding             /funding/:id
/withdraw            /withdraw/:id
/activity
/notifications
/draws               /draws/:id
/trust
/profile
/settings
/privacy
/support
```

`/requests/:id`, `/funding/:id`, and `/withdraw/:id` all resolve to the
**same** `requestDetails` screen, which calls
`requestService.getRequest(userId, id)` — a single lookup that checks
both the funding and withdrawal collections and returns exactly one
record. (Earlier drafts of this project had these three routes
accidentally falling through to the request *list* screen instead of
a single record; that bug is fixed at the service layer, not papered
over in the router.)

## Service layer

Screens never talk to Firestore or the mock provider directly — every
data access goes through one of these:

| Service | Responsibility |
|---|---|
| `authService` | Owns the `UserIdentity` lifecycle (see Identity architecture) |
| `userService` | Profile reads, privacy setting reads/writes |
| `poolService` | Pool discovery, participant pages, status derivation |
| `entryService` | Participation flow (idempotent entry creation) |
| `walletService` | Read-only balance access |
| `ledgerService` | Paginated transaction history + single-transaction lookup |
| `requestService` | Funding/withdrawal request creation + single-request lookup |
| `notificationService` | Notification list, unread count, mark read/all-read |
| `drawService` | Draw history + single draw (display-only, never selects a winner) |
| `activityService` | Paginated account activity feed |
| `paymentMethodService` | Configured funding methods (never hard-coded in UI) |
| `supportService` | Support ticket creation |

Every service checks `firebaseClient.isDevMode()` and returns data from
`js/mock/mockProvider.js` when true. **No screen imports
`mockProvider.js` directly** — this was a specific audit fix (the
previous version's Activity screen imported `DEV_ACTIVITY` straight
into the UI layer regardless of whether Firebase was connected).

## Identity architecture

`js/models/models.js:makeUserIdentity` and `js/services/authService.js`
deliberately keep four things separate instead of assuming any one of
them implies another:

- **Telegram-reported fields** (`telegramUserId`, `telegramUsername`, …) —
  client-reported, unverified.
- **Firebase session** — established via anonymous auth in
  `firebaseClient.ensureFirebaseSession()`, gives Firestore rules
  something to scope reads/writes to. Not proof of Telegram identity.
- **`applicationUserId`** — stays `null` until a trusted backend
  function verifies Telegram's signed `initData` and links it to a
  real backend user record. The client does not assign this to itself.
- **`verificationState`** — `"unverified"` until the backend says
  otherwise. Never flipped to `"verified"` client-side.

## Security posture (frontend-enforceable parts)

- **XSS**: every user-influenced string (names, pool text, notes,
  transaction descriptions) is passed through `utils/safeRender.js:esc()`
  before being interpolated into `innerHTML`. See `components/cards.js`
  for the pattern used everywhere.
- **Deep-link safety**: notification/activity `target` fields are
  passed through an allow-list (`models.js:normalizeTarget`) that only
  accepts known-safe route prefixes — a document can't redirect a user
  to an arbitrary path.
- **No client-side draw logic**: nowhere in this codebase is
  `Math.random()` (or anything else) used to pick a winner. Draw
  screens only render whatever `drawService` returns.
- **No optimistic financial claims**: funding/withdrawal submissions
  always end in a `SUBMITTED`/pending state in the UI, never "balance
  updated" or "payment received," until a backend-confirmed status
  says otherwise.
- **Idempotent submissions**: `utils/idempotency.js` wraps entry
  creation and request submission so a double-tap or retried network
  call can't fire the same action twice from the client side.

None of this replaces server-side enforcement — `firebase/firestore.rules`
and `firebase/storage.rules` are the actual trust boundary once
Firebase is connected. The frontend's job is to not make things worse
in the meantime.

## Frontend/backend boundary — what's next

This build is deliberately **not** wired to a real Firebase project
(`js/config.js` ships placeholder values). What's next:

1. Real Firebase project + web config in `js/config.js`.
2. Deploy `firebase/firestore.rules`, `firebase/storage.rules`,
   `firebase/indexes.json`.
3. Backend Cloud Functions this frontend already expects to call:
   - `createEntry(poolId, idempotencyKey)` — atomic entry + ledger debit
     + participantCount update.
   - Funding/withdrawal review functions transitioning
     `SUBMITTED → UNDER_REVIEW → APPROVED/REJECTED → COMPLETED`, writing
     the compensating ledger entry on approval.
   - A draw function that selects a winner via a documented, auditable
     process and writes the `draws/{id}` record.
   - A Telegram `initData` verification function that sets
     `applicationUserId` and `verificationState: "verified"` server-side.
4. Populate `systemContent/paymentMethods` for `paymentMethodService`.
5. Real `entries`, `activity`, `notifications` Firestore collections
   (currently only implemented against the mock provider in dev mode —
   `entryService.listMyEntries()` / `getEntry()` return `[]`/`null` in
   production mode until those collections and queries are wired up).

## Known limitations (frontend-only stage)

- `entryService` has no production Firestore query wired yet (see above).
- Countdown component uses client clock time, not a server-synced
  timestamp — fine for display, not for authoritative closing logic.
- Support contact channel (`config.js: support.contactHandle`) is
  intentionally `null` until a real channel is configured.

## Local development

No build step. Serve the folder statically and open `index.html`:

```
npx serve .
# or
python3 -m http.server 8080
```

With the placeholder Firebase config in `js/config.js`, the app runs
entirely in **Development Mode** (a banner says so) using
`js/mock/mockProvider.js` — safe to explore every screen without a
backend.

## Deployment

Any static host works (the app is plain HTML/CSS/ES modules). Point
Telegram's Mini App URL at wherever `index.html` is served from HTTPS.

## Testing checklist

- [ ] Telegram init in a real Telegram client; browser fallback shows the Development Mode banner
- [ ] Theme: system / light / dark, and Telegram-reported color scheme
- [ ] Locale: Amharic / English switch re-renders the current screen
- [ ] Bottom nav + Telegram back button + browser back all agree
- [ ] Home: balances, active pools, my entries, upcoming countdown, activity, recent draws
- [ ] Pools: search, status filters, sections
- [ ] Pool details: countdown, participants sheet + search + pagination, participation flow (insufficient-balance state, idempotent double-tap guard)
- [ ] My Entries: filters, entry details, linked draw result when completed
- [ ] Wallet: balances, paginated transaction history, transaction details
- [ ] Funding: payment method selection, inline validation (min 50 ETB, reference, file type/size), submission ends in SUBMITTED, not "approved"
- [ ] Withdrawal: confirmation dialog with before/after balance, SUBMITTED state
- [ ] `/requests`, `/requests/:id`, `/funding/:id`, `/withdraw/:id` — all resolve a single record with a data-driven timeline
- [ ] Activity: paginated, service-driven, no DEV_ACTIVITY leakage
- [ ] Notifications: unread badge on header, mark read / mark all read, safe deep links
- [ ] Draw history + details: no fabricated verification claims, no client-side winner selection
- [ ] Trust Center: accordion sections render in both languages
- [ ] Profile, Settings, Privacy (real save states), Support (ticket submission)
- [ ] Offline banner appears when `navigator.onLine` is false
- [ ] Error state + retry button on a forced failure in any screen
