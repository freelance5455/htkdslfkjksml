# Changelog — ETA BOT User Application Rebuild

## Fixed

- **`/funding/:id` and `/withdraw/:id` routing bug**: both previously
  rendered the request *list* instead of a single record. Fixed via
  `requestService.getRequest(userId, id)`, which checks both the
  funding and withdrawal collections and is now shared by
  `/requests/:id`, `/funding/:id`, and `/withdraw/:id` through one
  `requestDetails` screen.
- **`DEV_ACTIVITY` used unconditionally in production paths**: all
  synthetic data is now isolated in `js/mock/mockProvider.js` and only
  ever returned when `firebaseClient.isDevMode()` is true. No screen
  imports the mock provider directly — only services do.
- **Static, non-functional Privacy screen**: privacy toggles now call
  `userService.getPrivacy` / `updatePrivacy` with explicit
  saving/saved/failed states; nothing is claimed saved on failure.
- **Duplicated date/currency formatting logic** between `i18n.js` and a
  separate formatting module: consolidated into `utils/format.js`;
  `i18n.js` now only loads locale JSON and looks up keys.
- **Unescaped user-influenced strings** (names, pool descriptions,
  notes, transaction descriptions) interpolated directly into
  `innerHTML`: every card/row component now routes such values through
  `utils/safeRender.js:esc()`.
- **Conflated Telegram identity / Firebase UID**: `authService.js` +
  `models.js:makeUserIdentity` now track Telegram fields, Firebase
  session, `applicationUserId`, and `verificationState` as four
  distinct fields instead of assuming one implies another.
- **Hard-coded payment account numbers in UI code**: moved entirely
  behind `paymentMethodService.getActiveMethods()`.
- **Notification/activity deep links accepted arbitrary targets**: now
  passed through an allow-list (`models.js:normalizeTarget`) restricted
  to known route prefixes.
- **Router variable shadowing global `history`**: renamed to `navStack`.

## Added — Screens (all implemented, not placeholders)

Pools, Pool Details, My Entries, Entry Details, Wallet, Transaction
Details, Funding, Funding Request Details, Withdraw, Withdrawal
Request Details, Requests (list), Request Details (unified), Activity,
Notifications, Draw History, Draw Details, Trust Center, Profile,
Settings, Privacy, Support. Each has loading, empty, and error states
where applicable, and uses only the service layer for data.

## Added — Architecture

- Directory restructure into `js/{app,telegram,services,models,utils,
  components,screens,mock}/`.
- Full service layer matching the requested interface names:
  `authService`, `userService`, `poolService`, `entryService`,
  `walletService`, `ledgerService`, `requestService`,
  `notificationService`, `drawService`, `activityService`,
  `paymentMethodService`, `supportService`.
- Centralized data models (`models/models.js`) and status configuration
  (`models/status.js`) — every status has one place defining its
  label, icon, and visual tone.
- `utils/pagination.js` cursor-paginator, used by participants,
  transactions, activity.
- `utils/idempotency.js` guard, used by entry creation and funding/
  withdrawal request submission.
- `components/countdown.js` — live, self-updating countdown; never
  claims a pool has closed beyond what its own target time indicates.
- `components/timeline.js` — status-history timeline driven entirely by
  actual recorded `statusHistory` entries, never fabricated dates.
- `components/accordion.js` — used by the Trust Center to avoid a wall
  of text.
- `telegramService` — single module touching `window.Telegram`,
  exposing initialize/getUser/getTheme/expand/close/back-button/
  haptic/main-button, per the requested interface shape.
- `js/app/app.js` — single bootstrap sequence (Telegram → theme →
  locale → Firebase/identity → routes → onboarding) with a global
  `unhandledrejection`/`error` handler.

## UX / i18n

- Expanded Amharic and English locale files to full parity (233 keys
  each), including a consistent terminology map for Pool/Entry/Wallet/
  Request/Draw/Participant/Winner/Transaction/Balance/Funding/
  Withdrawal.
- Wallet balances split into Available / Locked / Pending / Total
  everywhere, never a single ambiguous "Balance."
- Replaced repetitive card-only layouts with a mix of stat strips,
  flat list panels, section headers, and timelines (Home, Wallet,
  Profile, Pool Details).
- Status badges now always pair an icon + translated label with a
  semantic tone — never color alone.

## Security

- XSS: `esc()` applied to all user-influenced interpolations.
- Deep-link target allow-list.
- No `Math.random()` or any client-side selection anywhere in the
  draw-related code path — `drawService` only displays backend records.
- Firestore/Storage rules (`firebase/*.rules`) unchanged in spirit from
  the prior draft: client can create `SUBMITTED`-only requests, cannot
  set balances/status/roles, default-deny on everything else.

## Validation performed before packaging

- `node --check` on every `.js` file — no syntax errors.
- Static analysis confirming every relative `import` path resolves to
  an existing file.
- Static analysis confirming every named import matches an actual
  `export` in its target module.
- JSON validation of both locale files, key-parity check (233/233
  keys match between `am.json` and `en.json`).
- Cross-reference of every statically-analyzable `t()`/`tList()` call
  against `am.json` — one missing key found and fixed
  (`poolDetails.yourParticipation` → corrected to the existing
  `pools.yourParticipation`).
- Cross-reference of every `icon("name")` call against the defined
  icon set — no missing icons.
- CSS brace-balance check on all four stylesheets.

## Remaining for the Firebase/backend integration stage (not in scope here)

- Real Firebase project config, Firestore/Storage rule deployment.
- `createEntry`, request-review, and draw Cloud Functions.
- Telegram `initData` server-side verification function.
- `entries`, `activity`, `notifications` production Firestore queries
  (currently mock-only; production mode returns empty results until
  wired up — this is intentional, not a bug, per the instruction not
  to fake backend completeness).
- `systemContent/paymentMethods` document populated with real payment
  instructions.
- A real support contact channel configured in `config.js`.
