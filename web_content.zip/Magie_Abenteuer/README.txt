MAGIE-ABENTEUER – kleines spielbares Browser-Spiel

So startest du:
1. ZIP-Datei entpacken.
2. Öffne die Datei index.html in einem modernen Browser (Chrome empfohlen).
3. Am Computer: WASD oder Pfeiltasten bewegen, Leertaste springen, E oder Mausklick zaubern.
4. Am Handy: nutze die eingeblendeten Richtungstasten, SPRUNG und ZAUBER.

Wichtig:
- Das ist eine einfache spielbare Prototyp-Version mit einer stilisierten 3D-artigen Perspektive, Bewegung, Sprung, Magie und sammelbaren Kristallen.
- Es ist noch keine APK-Datei. Die ZIP enthält die Quelldateien. Um eine APK zu erstellen, brauchst du eine App/Engine, die HTML-Projekte in Android-Apps verpackt, oder du kannst das Projekt in eine passende Spiel-Engine übertragen.
- Für die erste Ausführung ist keine Installation und keine Internetverbindung nötig.
