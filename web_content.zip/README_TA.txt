PRAGA AI ASSISTANT V2

உள்ளவை: Dark chat design, mobile sidebar, Library/Projects/Remote/Explore/Images/Chat/Search navigation, bottom message box, voice input, send button, Settings modal with API Key and Backend URL.

API இயங்குவதற்கு backend deploy அவசியம்:
- GitHub-ல் ZIP contents upload செய்யவும்.
- Render Web Service: Build Command = npm install; Start Command = npm start.
- Deploy செய்த URL-ஐ app Settings > Backend Server URL-ல் இடவும்.
- API Key-ஐ Settings-ல் உள்ளிடவும். அது sessionStorage-ல் மட்டும் இருக்கும்; app/browser session முடிந்தால் மீண்டும் உள்ளிட வேண்டும்.
- பாதுகாப்பான வழி: Render Environment-ல் OPENAI_API_KEY அமைத்து, app Settings-ல் API Key காலியாக விடலாம்.
- HTTPS பயன்படுத்தவும். API Key-ஐ HTML/JS/APK-க்குள் hard-code செய்ய வேண்டாம்.
- API பயன்பாட்டுக்கு கட்டணம் ஏற்படலாம்; கணக்கு/billing-ஐ பெற்றோர் அல்லது பாதுகாவலருடன் அமைக்கவும்.

APK Builder-ல் JavaScript, Internet, Microphone permissions enable செய்யவும். Backend deploy செய்து browser-ல் முதலில் சோதிக்கவும்.
