WAVE STUDY HUB WEBSITE PROTOTYPE

Open index.html in a browser to preview the responsive website.

IMPORTANT LIMITATIONS
- This is a website prototype, not an Android App Bundle (.aab).
- The email/password form is only a demo. It does not create accounts, save emails, or verify email ownership. Do not enter real passwords.
- Before production, connect a secure authentication service (for example Firebase Authentication), require email verification, configure database rules, and publish a privacy policy.
- Complete Grade 9–12 curriculum content, videos, and authorized entrance-exam papers still need to be added and checked.
- Google Play publishing requires packaging this into an Android app, testing it, signing the release, and exporting an .aab file.
