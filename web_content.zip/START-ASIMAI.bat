@echo off
cd /d "%~dp0"
set PORT=7700
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -m http.server %PORT% --bind 0.0.0.0
) else (
  python -m http.server %PORT% --bind 0.0.0.0
)
pause
