# Android file access and permissions for Fast Brander

Fast Brander uses the Android/browser file picker for files the user explicitly chooses, and browser-managed local storage (IndexedDB/localStorage) for business data. A normal website must not silently read all files on a phone. This is intentional: the user chooses a logo, import file, or backup, and chooses where exported files are saved through the browser/download UI.

## Recommended Android wrapper permissions

For an offline-first WebView wrapper using the Android Storage Access Framework (SAF), **do not request broad storage permissions** just to select logos, import CSV/JSON, or export documents. The system picker grants access to the selected file without `READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE`, or `MANAGE_EXTERNAL_STORAGE`.

A minimal `AndroidManifest.xml` for a fully offline wrapper can be as simple as:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="false"
        android:label="Fast Brander"
        android:usesCleartextTraffic="false">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
```

No Android runtime permission is required for the SAF file picker. Add `android.permission.INTERNET` only if your wrapper loads a hosted URL or needs network features; it is not needed for a fully bundled offline app. Camera, contacts, location, microphone, and media-library permissions are not required by Fast Brander's current features.

## Important WebView integration requirement

A WebView wrapper must implement the native file chooser callback (`WebChromeClient.onShowFileChooser`) to make `<input type="file">` work in the Android app. The HTML page alone cannot grant native Android permissions or force a WebView wrapper to support file picking. Use Android's `ACTION_OPEN_DOCUMENT` / Activity Result API with `image/*` for logos and `text/*` plus `application/json` for imports/backups, then return the chosen `Uri` to the WebView callback. For exports, implement `DownloadListener` or a native save-file flow using `ACTION_CREATE_DOCUMENT` so users can save PDF/PNG/JPEG/JSON/CSV files to Downloads or another chosen folder.

Also configure the wrapper to:

- Keep JavaScript enabled for this bundled app.
- Keep DOM storage and IndexedDB enabled (`WebSettings.setDomStorageEnabled(true)`).
- Keep the WebView profile/data directory persistent across app restarts; do not clear app data on close.
- Bundle all app files locally and use an appropriate secure app origin where supported, so service workers and offline caching work.
- Never grant `file://` universal access or enable `allowUniversalAccessFromFileURLs` just to make file selection work.
- Test file chooser, downloads, app restart persistence, printing, and offline reload on the actual target Android version.

## What changed in v1.0.2

- App requests persistent browser storage when the browser supports `navigator.storage.persist()`; the browser may approve or deny this request.
- Logo upload accepts recognized file extensions when Android's picker returns an empty MIME type, while still validating the image format before storing it.
- Updated service-worker cache version so the new build can replace the old cached app shell.

## Browser permissions and privacy

The app does not need broad access to the phone's files. It can read only files the user selects through the picker. It stores records locally and does not upload company data. Browser downloads may save directly to Downloads or ask where to save, depending on browser settings. A web app cannot override those system settings.
