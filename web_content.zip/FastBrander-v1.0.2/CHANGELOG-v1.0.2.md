# Fast Brander v1.0.2

- Added a best-effort request for persistent browser storage to reduce the risk of locally saved data being evicted.
- Improved logo upload validation for Android file pickers that return an empty MIME type but a valid image extension.
- Bumped the service-worker cache name to ensure the updated app shell is fetched.
- Added `ANDROID-WEBVIEW-FILE-ACCESS.md` with least-privilege Android wrapper permissions, native WebView file chooser/download requirements, and testing guidance.

Note: Android native file access and download behavior depends on the APK wrapper. HTML/JavaScript cannot independently grant Android permissions or implement missing native WebView callbacks.
