# Fast Brander — offline-first business document maker

Fast Brander is a no-sign-up, browser-based document maker. It uses HTML, CSS and plain JavaScript with no remote libraries, external fonts, cloud database, API keys or server-side account system.

## Included features

- Separate company profiles on the same device; each profile has its own logo, contact details, TPIN, payment instructions, theme, currency, document numbering, customer list, catalog and saved documents.
- Company logo upload, optional tagline, contact details, website, TPIN and payment instructions.
- Document types: invoice, quotation, receipt, pro forma invoice, delivery note, purchase order and credit note.
- Automatic per-company, per-type document numbering, dates, references and quotation validity / due dates.
- Saved customer book; select a saved customer or type one-off recipient details.
- Reusable product/service catalog with category, SKU, description, unit, price, ZMW or USD currency, optional stock quantity and low-stock threshold.
- Import products/services and customers from CSV, TSV or JSON. Export catalog/customers to CSV. A CSV template and examples are in `sample-data/`.
- Line-item quantities, unit prices, line discounts, tax percentages, totals, payment received and balance for receipts.
- Color palette, custom accent color, black-and-white output, and modern/classic/minimal layouts.
- Live preview, save/edit/duplicate/delete, quotation-to-invoice conversion, print selected documents, native print / Save as PDF, local PDF export and PNG/JPEG export.
- Local JSON backup and restore for all company workspaces.
- Responsive phone/desktop layout; service-worker and manifest files included for PWA installation and offline app-shell caching.

## Quick start on Windows 11

### Option A — fastest test
1. Extract the ZIP file.
2. Open the `FastBrander` folder.
3. Double-click `index.html` (or right-click it and open with Chrome/Edge).
4. Complete the first company setup. Try creating a quotation, invoice or receipt.

Opening `index.html` directly is useful for a quick preview, but storage and downloads can vary in browsers or app wrappers using `file://`. For a more reliable offline setup with persistent app storage, use Option B or package the whole folder in a WebView wrapper with IndexedDB/local storage enabled. Service-worker installation is restricted to HTTPS or localhost in normal browser use.

### Option B — test the installable/offline PWA shell
1. Install Python 3 if it is not already on the PC.
2. Double-click `start-local.bat` inside this folder.
3. Open `http://localhost:8080` in Chrome or Edge.
4. Keep the local server running for the initial visit. After the page loads and the service worker installs, turn Wi-Fi off and refresh/test the app. Browser PWA installation is supported only in secure contexts such as HTTPS or localhost.

The app's core data and document generation do not call a server. The local Python server only serves the files to the browser during testing. For an online hosted PWA, deploy the folder as static files over HTTPS.

## Turn the files into an Android app

Use an HTML-to-APK wrapper that packages a local website or creates a WebView app, and point it at this folder's `index.html` or package the complete folder. Keep `app.js`, `styles.css`, `manifest.webmanifest`, `sw.js` and `assets/` next to the HTML. The wrapper must allow JavaScript, local storage / IndexedDB, file input, downloads and the print/share intent if you want those functions in the APK. Feature support depends on the converter.

Test storage in the chosen wrapper before entering real records. Web storage is scoped to the app's origin; data in a browser, another origin or a newly installed APK is not automatically shared. Use **Settings & backup → Download backup JSON** and copy the backup into the new app if needed.

## Import format

CSV files need a header row. For the catalog, common headers such as `name`, `kind`, `description`, `category`, `sku`, `unit`, `price`, `currency`, `track_stock`, `stock_qty`, and `low_stock_at` are recognised. For customers, use `name`, `business`, `phone`, `email`, `address`, and `tpin`. JSON is also accepted as an array of objects. Excel workbooks should be exported as CSV before importing.

## PDF and image output

- **Export PDF** produces a local A4-sized PDF. For maximum print sharpness and selectable text, the **Print / Save as PDF** route may be preferable because it uses the browser's print renderer.
- **Export PNG/JPEG** creates a high-resolution image; multi-page documents are combined into one tall image.
- For printing multiple documents, select them in Documents and choose **Print selected**.

## Storage and privacy

Records are stored in IndexedDB with a localStorage fallback. No login is required. There is no cloud sync, and the app does not upload company/customer data. Browser/app storage may be removed when the user clears site data, uninstalls an app or resets a device, so export backups regularly. A backup contains private company and customer information; store it securely.

## Verification

The package includes a checklist in `TEST-REPORT.md`. It records the automated browser smoke tests run on the bundled build and the manual checks still recommended on a real Android wrapper / printer because those depend on the target device.


## Version 1.0.1 update

This update improves logo selection, adds quick mobile navigation, strengthens file-download handling, and distinguishes catalog cost price from customer selling/unit price. See `CHANGELOG-v1.0.1.md`.


## Device files and permissions (v1.0.2)

Logo upload and imports use the device/browser file picker; exports use browser download/save behavior. The app asks the browser for persistent local storage where supported. No broad phone-storage permission is needed for a standard web/PWA installation. For an Android WebView APK, the wrapper must implement the native file chooser and download callbacks; see `ANDROID-WEBVIEW-FILE-ACCESS.md` for the required integration notes and a minimal manifest example.
