# Fast Brander v1.0.1 — fixes from testing

- Improved logo upload handling: broad image file picker support, direct change-event handling, and clear validation.
- Added persistent mobile bottom navigation for Home, Docs, Create, Customers and Items; the sidebar navigation remains available.
- Improved local file downloads by keeping generated Blob URLs alive longer and adding a fallback open action if a download click fails.
- Clarified pricing language: catalog now distinguishes **cost price** (what the business pays) from **selling/unit price** (what the customer is charged); document lines are labelled **selling / ordered unit price**.
- Catalog CSV templates and exports now include `cost_price`; CSV/JSON catalog imports recognize cost price and ordered price aliases.

## Important platform note
Browser and Android WebView download behavior varies by converter. If an embedded app blocks direct downloads, use the browser's print/save-as-PDF option or choose a converter that enables download/file access. This package does not upload files or require an account.
