/* Fast Brander v1.0.2 — offline-first, device-local business document maker. */
(() => {
  'use strict';
  const APP_VERSION = '1.0.2';
  const DB_NAME = 'fast-brander-db';
  const DB_VERSION = 1;
  const STORE_NAME = 'app-state';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const TYPES = {
    invoice: {label:'Invoice', plural:'Invoices', code:'INV', icon:'▤'},
    quotation: {label:'Quotation', plural:'Quotations', code:'QUO', icon:'▧'},
    receipt: {label:'Receipt', plural:'Receipts', code:'REC', icon:'▣'},
    proforma: {label:'Pro forma invoice', plural:'Pro forma invoices', code:'PRO', icon:'▤'},
    delivery: {label:'Delivery note', plural:'Delivery notes', code:'DN', icon:'▥'},
    purchase: {label:'Purchase order', plural:'Purchase orders', code:'PO', icon:'▤'},
    credit: {label:'Credit note', plural:'Credit notes', code:'CN', icon:'↶'}
  };
  const ACCENTS = [
    {name:'Royal blue',value:'#2563eb'},{name:'Navy',value:'#172554'},{name:'Emerald',value:'#0f8a68'},
    {name:'Crimson',value:'#c03443'},{name:'Violet',value:'#7445c8'},{name:'Teal',value:'#0f8390'},
    {name:'Amber',value:'#b96c13'},{name:'Slate',value:'#475569'}
  ];
  const todayISO = () => new Date().toISOString().slice(0,10);
  const addDaysISO = (s, n) => { const d = new Date((s || todayISO()) + 'T12:00:00'); d.setDate(d.getDate()+n); return d.toISOString().slice(0,10); };
  const id = (prefix='id') => `${prefix}-${(crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9))}`;
  const escapeHTML = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const num = (v, d=0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const money = (value, currency='ZMW') => {
    const n = num(value);
    const formatted = n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
    return currency === 'USD' ? `$ ${formatted}` : `K ${formatted}`;
  };
  const currencyName = c => c === 'USD' ? 'USD — US Dollar' : 'ZMW — Zambian Kwacha';
  const formatDate = s => { if(!s) return '—'; const d = new Date(s+'T12:00:00'); return Number.isNaN(d.getTime()) ? s : d.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}); };
  const shortDate = s => s ? formatDate(s) : '—';
  const initials = name => (String(name||'FB').trim().split(/\s+/).slice(0,2).map(x=>x[0]||'').join('').toUpperCase() || 'FB');
  const clone = o => JSON.parse(JSON.stringify(o));
  const defaultCompany = () => ({
    id:id('company'), name:'', address:'', phone:'', email:'', website:'', tpin:'', tagline:'', bankDetails:'', logo:'',
    defaultCurrency:'ZMW', themeMode:'color', themeStyle:'modern', accent:'#2563eb',
    nextNumbers:{invoice:1,quotation:1,receipt:1,proforma:1,delivery:1,purchase:1,credit:1}, customers:[], catalog:[], documents:[]
  });
  const defaultState = () => { const c = defaultCompany(); return {version:APP_VERSION,activeCompanyId:c.id,companies:[c],setupComplete:false,createdAt:new Date().toISOString()}; };
  let state = defaultState();
  let currentPage = 'dashboard';
  let editor = null;
  let modalMode = '';
  let editEntityId = null;
  let importKind = 'catalog';
  let logoTargetCompanyId = null;
  let toastTimer = null;
  let saveTimer = null;
  let docFilter = 'all';
  let docSearch = '';
  let customerSearch = '';
  let catalogSearch = '';
  let catalogCategory = 'all';
  let selectedDocIds = new Set();

  function dbOpen() {
    return new Promise((resolve,reject)=>{
      if(!('indexedDB' in window)) return reject(new Error('IndexedDB unavailable'));
      const req = indexedDB.open(DB_NAME,DB_VERSION);
      req.onupgradeneeded = () => { if(!req.result.objectStoreNames.contains(STORE_NAME)) req.result.createObjectStore(STORE_NAME); };
      req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error || new Error('Database open failed'));
    });
  }
  async function dbGet() {
    const db = await dbOpen();
    return new Promise((resolve,reject)=>{ const tx=db.transaction(STORE_NAME,'readonly'); const req=tx.objectStore(STORE_NAME).get('state'); req.onsuccess=()=>resolve(req.result||null); req.onerror=()=>reject(req.error); });
  }
  async function dbSet(value) {
    const db = await dbOpen();
    return new Promise((resolve,reject)=>{ const tx=db.transaction(STORE_NAME,'readwrite'); tx.objectStore(STORE_NAME).put(value,'state'); tx.oncomplete=()=>resolve(true); tx.onerror=()=>reject(tx.error); tx.onabort=()=>reject(tx.error||new Error('Save aborted')); });
  }
  async function requestPersistentStorage() {
    // Ask the browser to reduce the risk of automatic eviction of locally saved business data.
    // This is a browser-managed request, not broad access to the device filesystem.
    try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (_) {}
  }
  async function loadState() {
    try { const got = await dbGet(); if(got && Array.isArray(got.companies) && got.companies.length){ state=got; return; } } catch(e) { /* local file / private browsing fallback */ }
    try { const raw=localStorage.getItem('fastBranderState'); if(raw){ const got=JSON.parse(raw); if(got && Array.isArray(got.companies) && got.companies.length){state=got; return;} } } catch(e) { /* recover to new state */ }
    state=defaultState();
  }
  async function persistState(showError=false) {
    state.version=APP_VERSION; state.updatedAt=new Date().toISOString();
    let stored=false;
    try { await dbSet(state); stored=true; } catch(e) { /* try local storage next */ }
    try { localStorage.setItem('fastBranderState',JSON.stringify(state)); stored=true; } catch(e) { if(!stored && showError) toast('Your browser storage is full. Export a backup and remove large images or old records.','error'); }
    return stored;
  }
  function schedulePersist() { clearTimeout(saveTimer); saveTimer=setTimeout(()=>persistState(false),180); }
  function company() { return state.companies.find(c=>c.id===state.activeCompanyId) || state.companies[0]; }
  function companyById(cid) { return state.companies.find(c=>c.id===cid) || company(); }
  function activeDocs() { return company()?.documents || []; }
  function ensureCompanyShape(c) {
    c.customers ||= []; c.catalog ||= []; c.documents ||= [];
    c.nextNumbers ||= {}; Object.keys(TYPES).forEach(t=>{if(!Number.isFinite(Number(c.nextNumbers[t])))c.nextNumbers[t]=1;});
    c.defaultCurrency = c.defaultCurrency==='USD'?'USD':'ZMW'; c.themeMode = c.themeMode==='mono'?'mono':'color'; c.themeStyle = ['modern','classic','minimal'].includes(c.themeStyle)?c.themeStyle:'modern'; c.accent = /^#[0-9a-f]{6}$/i.test(String(c.accent||''))?c.accent:'#2563eb'; c.logo ||= '';
    return c;
  }
  function applyAccent() { const c=company(); if(!c)return; document.documentElement.style.setProperty('--accent',c.accent||'#2563eb'); document.documentElement.style.setProperty('--accent-soft',hexToRGBA(c.accent||'#2563eb',.09)); }
  function hexToRGBA(hex,a){const m=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex||'');return m?`rgba(${parseInt(m[1],16)},${parseInt(m[2],16)},${parseInt(m[3],16)},${a})`:'rgba(37,99,235,.09)';}
  function renderCompanySwitcher() {
    const sel=$('#companySwitcher'); if(!sel)return;
    sel.innerHTML=state.companies.map(c=>`<option value="${escapeHTML(c.id)}" ${c.id===state.activeCompanyId?'selected':''}>${escapeHTML(c.name||'New company profile')}</option>`).join('');
    $('#navDocCount').textContent=String(activeDocs().length);
  }
  function updateNetworkStatus() {
    const label=$('#networkLabel'); const dot=$('.local-status .status-dot');
    if(!label)return;
    if(navigator.onLine){label.textContent='Offline-ready workspace';if(dot)dot.style.background='#38c987';}
    else {label.textContent='Working offline';if(dot)dot.style.background='#d99b36';}
  }
  function toast(message,type='') {
    const region=$('#toastRegion'); if(!region)return;
    const node=document.createElement('div');node.className=`toast ${type}`;node.textContent=message;region.appendChild(node);
    setTimeout(()=>{node.style.opacity='0';node.style.transform='translateY(-5px)';setTimeout(()=>node.remove(),180);},3400);
  }
  function pageMeta(page) {
    const m={dashboard:['YOUR WORKSPACE','Overview'],documents:['YOUR RECORDS','Documents'],create:['CREATE SOMETHING','Create document'],customers:['YOUR RELATIONSHIPS','Customers'],catalog:['YOUR OFFERING','Products & services'],company:['BUSINESS IDENTITY','Company profiles'],settings:['PREFERENCES & SAFETY','Settings & backup']};
    return m[page]||m.dashboard;
  }
  function navigate(page) {
    currentPage=page; $$('.nav-item, .mobile-bottom-nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
    const meta=pageMeta(page);$('#pageEyebrow').textContent=meta[0];$('#pageTitle').textContent=meta[1];
    $('#sidebar').classList.remove('open'); renderPage();
  }
  function renderPage() {
    applyAccent();renderCompanySwitcher();
    const root=$('#pageContent'); if(!root)return;
    switch(currentPage){
      case 'dashboard':root.innerHTML=renderDashboard();break;
      case 'documents':root.innerHTML=renderDocuments();break;
      case 'create':if(!editor)editor=makeBlankDoc('invoice');root.innerHTML=renderEditor();break;
      case 'customers':root.innerHTML=renderCustomers();break;
      case 'catalog':root.innerHTML=renderCatalog();break;
      case 'company':root.innerHTML=renderCompanyPage();break;
      case 'settings':root.innerHTML=renderSettings();break;
      default:root.innerHTML=renderDashboard();
    }
  }
  function documentStats(docs=activeDocs()) {
    const open=docs.filter(d=>['invoice','proforma'].includes(d.type) && num(d.amountPaid)<docTotals(d).total-0.005).length;
    const outstanding=docs.filter(d=>['invoice','proforma'].includes(d.type)).reduce((a,d)=>a+Math.max(0,docTotals(d).total-num(d.amountPaid)),0);
    const quotes=docs.filter(d=>d.type==='quotation').length;
    const total=docs.reduce((a,d)=>a+docTotals(d).total,0);
    return {total:docs.length,open,outstanding,quotes,totalValue:total};
  }
  function renderDashboard() {
    const c=company(), docs=[...activeDocs()].sort((a,b)=>(b.updatedAt||b.createdAt||'').localeCompare(a.updatedAt||a.createdAt||''));
    const s=documentStats(docs); const needsSetup=!state.setupComplete || !c.name || !c.phone;
    return `
      <section class="hero-card">
        <div class="hero-copy"><div class="hero-kicker">One workspace. Every business document.</div><h2>${needsSetup?'Welcome to Fast Brander.':'Your business, beautifully presented.'}</h2><p>${needsSetup?'Set up your company identity once, then create polished invoices, quotations, receipts and other business documents. Everything is saved on this device.':'Create, organise and print client-ready documents without subscriptions, sign-ups or a constant internet connection.'}</p><div class="hero-actions"><button class="btn btn-primary" data-action="create">＋ Create a document</button><button class="btn btn-secondary" data-action="go-company">${needsSetup?'Set up company profile':'Manage company profile'} →</button></div></div>
        <div class="hero-mark">FB<span style="font-size:11px;letter-spacing:1px;display:block;text-align:center;margin-top:-20px">FAST BRANDER</span></div>
      </section>
      <section class="metric-grid">
        <div class="metric-card"><div class="metric-head">Documents created <span class="metric-symbol">▤</span></div><div class="metric-number">${s.total}</div><div class="metric-note">Across this company profile</div></div>
        <div class="metric-card"><div class="metric-head">Outstanding invoices <span class="metric-symbol">◷</span></div><div class="metric-number">${s.open}</div><div class="metric-note">Invoices or pro forma invoices unpaid</div></div>
        <div class="metric-card"><div class="metric-head">Outstanding value <span class="metric-symbol">K</span></div><div class="metric-number" style="font-size:22px">${escapeHTML(money(s.outstanding,c.defaultCurrency))}</div><div class="metric-note">Only invoice and pro forma balances</div></div>
        <div class="metric-card"><div class="metric-head">Saved customers <span class="metric-symbol">♙</span></div><div class="metric-number">${c.customers.length}</div><div class="metric-note">Ready for faster document creation</div></div>
      </section>
      ${needsSetup?`<div class="warning-note mb-12"><strong>One quick setup step:</strong> Add your real company name and contact details before printing official documents. Uploading a logo is optional. <button class="btn btn-small btn-secondary" data-action="go-company" style="margin-left:8px">Set up now</button></div>`:''}
      <div class="section-heading"><h3>Quick actions</h3><span>Designed for repeat work</span></div>
      <section class="quick-grid">
        <button class="quick-card" data-action="create-type" data-type="invoice"><span class="quick-symbol">▤</span><span><strong>Create an invoice</strong><small>Bill for supplied goods or services and track the balance.</small></span></button>
        <button class="quick-card" data-action="create-type" data-type="quotation"><span class="quick-symbol">▧</span><span><strong>Prepare a quotation</strong><small>Give a customer a clear estimate before work begins.</small></span></button>
        <button class="quick-card" data-action="create-type" data-type="receipt"><span class="quick-symbol">▣</span><span><strong>Issue a receipt</strong><small>Record a payment and show what was received.</small></span></button>
      </section>
      <div class="section-heading mt-16"><h3>Recent documents</h3><button class="btn btn-plain btn-small" data-action="go-documents">View all documents →</button></div>
      <section class="panel">${docs.length?renderDocTable(docs.slice(0,6),false):`<div class="empty-state"><div class="empty-icon">▤</div><h3>Your first document starts here</h3><p>Build one from your company profile, customer list and saved product or service catalog. It will stay on this device.</p><button class="btn btn-primary" data-action="create">Create your first document</button></div>`}</section>
      <section class="quick-grid"><button class="quick-card" data-action="go-customers"><span class="quick-symbol">♙</span><span><strong>Build your customer list</strong><small>Save names, contact details and customer tax numbers.</small></span></button><button class="quick-card" data-action="go-catalog"><span class="quick-symbol">▣</span><span><strong>Import products & services</strong><small>Use CSV or JSON to speed up repeat quotations and invoices.</small></span></button><button class="quick-card" data-action="go-settings"><span class="quick-symbol">⬇</span><span><strong>Protect your records</strong><small>Export a backup you can move to another device.</small></span></button></section>`;
  }
  function statusFor(d) {
    if(d.type==='quotation') return {label:'Quotation',class:'purple'};
    if(d.type==='receipt') return {label:'Paid / received',class:'success'};
    if(['delivery','purchase','credit'].includes(d.type)) return {label:TYPES[d.type].label,class:''};
    const t=docTotals(d).total, paid=num(d.amountPaid);
    if(paid>=t-0.005 && t>0) return {label:'Paid',class:'success'};
    if(paid>0) return {label:'Part-paid',class:'warning'};
    if(d.dueDate && d.dueDate<todayISO()) return {label:'Overdue',class:'warning'};
    return {label:'Unpaid',class:''};
  }
  function renderDocTable(docs,withSelect=true) {
    if(!docs.length)return `<div class="empty-state"><div class="empty-icon">▤</div><h3>No documents to show</h3><p>Try a different filter or create a new document.</p><button class="btn btn-primary" data-action="create">Create document</button></div>`;
    return `<div class="table-wrap"><table><thead><tr>${withSelect?'<th style="width:36px"><input type="checkbox" id="selectAllDocs" aria-label="Select all documents"></th>':''}<th>Document</th><th>Customer</th><th>Date</th><th>Total</th><th>Status / type</th><th>Actions</th></tr></thead><tbody>${docs.map(d=>{const c=d.companySnapshot||company(),st=statusFor(d),cu=d.currency||c.defaultCurrency||'ZMW';return `<tr>${withSelect?`<td><input type="checkbox" class="doc-select" data-select-doc="${escapeHTML(d.id)}" ${selectedDocIds.has(d.id)?'checked':''} aria-label="Select ${escapeHTML(d.number)}"></td>`:''}<td><span class="table-primary">${escapeHTML(d.number||TYPES[d.type]?.code||'DOC')}</span><span class="table-secondary">${escapeHTML(TYPES[d.type]?.label||d.type)}</span></td><td><span class="table-primary">${escapeHTML(d.customerSnapshot?.name||'Walk-in customer')}</span><span class="table-secondary">${escapeHTML(d.customerSnapshot?.phone||d.customerSnapshot?.email||'No contact saved')}</span></td><td>${escapeHTML(formatDate(d.issueDate||d.createdAt?.slice(0,10)))}</td><td><span class="table-primary">${escapeHTML(money(docTotals(d).total,cu))}</span></td><td><span class="pill ${st.class}">${escapeHTML(st.label)}</span></td><td><div class="action-group"><button class="icon-action" title="Preview" data-action="view-doc" data-id="${escapeHTML(d.id)}">View</button><button class="icon-action" title="Edit" data-action="edit-doc" data-id="${escapeHTML(d.id)}">Edit</button><button class="icon-action" title="More exports" data-action="doc-actions" data-id="${escapeHTML(d.id)}">⋯</button></div></td></tr>`}).join('')}</tbody></table></div>`;
  }
  function renderDocuments() {
    const types=[['all','All documents'],...Object.entries(TYPES).map(([k,v])=>[k,v.plural])];
    let docs=[...activeDocs()].sort((a,b)=>(b.updatedAt||b.createdAt||'').localeCompare(a.updatedAt||a.createdAt||''));
    if(docFilter!=='all')docs=docs.filter(d=>d.type===docFilter);
    if(docSearch.trim()){const q=docSearch.toLowerCase();docs=docs.filter(d=>[d.number,d.customerSnapshot?.name,d.type,d.notes].some(v=>String(v||'').toLowerCase().includes(q)));}
    return `<div class="page-head"><div><h2>Your document library</h2><p>Open, edit, duplicate, print or export the documents stored for <strong>${escapeHTML(company().name||'this company')}</strong>.</p></div><div class="head-actions"><button class="btn btn-secondary" data-action="bulk-print">Print selected</button><button class="btn btn-primary" data-action="create">＋ New document</button></div></div>
      <div class="toolbar"><div class="search-box"><input id="documentSearch" placeholder="Search document number or customer…" value="${escapeHTML(docSearch)}" /></div><select id="documentTypeFilter" class="filter-select">${types.map(([k,label])=>`<option value="${k}" ${docFilter===k?'selected':''}>${escapeHTML(label)}</option>`).join('')}</select><span class="pill">${docs.length} shown</span></div>
      <section class="panel">${renderDocTable(docs,true)}</section>
      <p class="hint mt-12">Tip: select several rows and choose <strong>Print selected</strong> to prepare a combined print packet. PDF and image exports are available from each document's action menu.</p>`;
  }
  function makeBlankDoc(type='invoice') {
    const c=company(), today=todayISO();
    return {id:null,type,number:makeNumber(c,type),currency:c.defaultCurrency||'ZMW',issueDate:today,dueDate:addDaysISO(today,14),validUntil:addDaysISO(today,30),customerId:'',customerSnapshot:{name:'',business:'',phone:'',email:'',address:'',tpin:''},items:[newLine(c)],notes:'',terms:'Payment due by the stated date. Please use the document number as your payment reference.',reference:'',amountPaid:type==='receipt'?0:0,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
  }
  function makeNumber(c,type) { const n=Math.max(1,num(c.nextNumbers?.[type],1));return `${TYPES[type]?.code||'DOC'}-${new Date().getFullYear()}-${String(n).padStart(4,'0')}`; }
  function newLine(c) { return {id:id('line'),catalogId:'',name:'',description:'',category:'',sku:'',qty:1,unit:'unit',price:0,taxRate:0,discountRate:0}; }
  function lineTotals(line) { const raw=Math.max(0,num(line.qty))*Math.max(0,num(line.price));const discount=raw*Math.min(100,Math.max(0,num(line.discountRate)))/100;const net=raw-discount;const tax=net*Math.min(100,Math.max(0,num(line.taxRate)))/100;return {raw,discount,net,tax,total:net+tax}; }
  function docTotals(d) { const lines=(d.items||[]).map(lineTotals);const subtotal=lines.reduce((a,x)=>a+x.raw,0);const discount=lines.reduce((a,x)=>a+x.discount,0);const taxable=lines.reduce((a,x)=>a+x.net,0);const tax=lines.reduce((a,x)=>a+x.tax,0);return {subtotal,discount,taxable,tax,total:taxable+tax,paid:num(d.amountPaid),balance:Math.max(0,taxable+tax-num(d.amountPaid))}; }
  function getCustomerFromSelect() { const c=company(); const selected=c.customers.find(x=>x.id===editor?.customerId);return selected?clone(selected):clone(editor?.customerSnapshot||{}); }
  function syncEditorCompanySnapshot() { if(!editor)return; editor.companySnapshot=makeCompanySnapshot(company()); editor.customerSnapshot=getCustomerFromSelect(); }
  function makeCompanySnapshot(c) { return {id:c.id,name:c.name||'',address:c.address||'',phone:c.phone||'',email:c.email||'',website:c.website||'',tpin:c.tpin||'',tagline:c.tagline||'',bankDetails:c.bankDetails||'',logo:c.logo||'',defaultCurrency:c.defaultCurrency||'ZMW',themeMode:c.themeMode||'color',themeStyle:c.themeStyle||'modern',accent:c.accent||'#2563eb'}; }
  function renderEditor() {
    const c=company(); if(!editor)editor=makeBlankDoc('invoice');
    editor.customerSnapshot ||= {name:'',phone:'',email:'',address:'',tpin:''};editor.items ||= [newLine(c)];
    const typeOptions=Object.entries(TYPES).map(([k,v])=>`<option value="${k}" ${editor.type===k?'selected':''}>${escapeHTML(v.label)}</option>`).join('');
    const custOptions=`<option value="">Enter customer details manually</option>`+c.customers.map(cu=>`<option value="${escapeHTML(cu.id)}" ${editor.customerId===cu.id?'selected':''}>${escapeHTML(cu.name)}${cu.business?' — '+escapeHTML(cu.business):''}</option>`).join('');
    const isFinancial=['invoice','quotation','receipt','proforma','credit'].includes(editor.type);
    const doc=clone(editor); doc.companySnapshot=makeCompanySnapshot(c); doc.customerSnapshot=getCustomerFromSelect();
    return `<div class="page-head"><div><h2>Build a business document</h2><p>Choose a document type, select a customer, add products or services, and preview the branded layout as you work.</p></div><div class="head-actions"><button class="btn btn-secondary" data-action="go-documents">View saved documents</button></div></div>
      <div class="document-layout"><section class="panel doc-form-panel">
        <form id="documentForm" autocomplete="off">
          <div class="form-section"><div class="form-section-title"><div><h3>1. Document details</h3><p>Numbering is automatic for each company and document type.</p></div></div>
            <div class="form-grid"><div class="field"><label for="editType">Document type</label><select id="editType" data-editor-field="type" ${editor.id?'disabled':''}>${typeOptions}</select></div><div class="field"><label for="editNumber">Document number</label><input id="editNumber" value="${escapeHTML(editor.number)}" readonly /></div><div class="field"><label for="editCurrency">Currency</label><select id="editCurrency" data-editor-field="currency"><option value="ZMW" ${editor.currency==='ZMW'?'selected':''}>ZMW — Zambian Kwacha (K)</option><option value="USD" ${editor.currency==='USD'?'selected':''}>USD — US Dollar ($)</option></select></div><div class="field"><label for="editIssueDate">Issue date</label><input id="editIssueDate" type="date" data-editor-field="issueDate" value="${escapeHTML(editor.issueDate||todayISO())}" /></div>${['invoice','proforma','purchase'].includes(editor.type)?`<div class="field"><label for="editDueDate">Due date</label><input id="editDueDate" type="date" data-editor-field="dueDate" value="${escapeHTML(editor.dueDate||'')}" /></div>`:''}${editor.type==='quotation'?`<div class="field"><label for="editValidUntil">Valid until</label><input id="editValidUntil" type="date" data-editor-field="validUntil" value="${escapeHTML(editor.validUntil||'')}" /></div>`:''}<div class="field"><label for="editReference">Reference / order no. <span class="optional">(optional)</span></label><input id="editReference" data-editor-field="reference" value="${escapeHTML(editor.reference||'')}" placeholder="e.g. PO-0092" /></div></div>
          </div>
          <div class="form-section"><div class="form-section-title"><div><h3>2. Customer</h3><p>Pick a saved customer or type a one-off recipient.</p></div><button type="button" class="btn btn-secondary btn-small" data-action="new-customer">＋ Add customer</button></div>
            <div class="field mb-12"><label for="editCustomerSelect">Saved customers</label><select id="editCustomerSelect" data-editor-field="customerId">${custOptions}</select></div>
            <div class="form-grid"><div class="field"><label for="custName">Customer / recipient name</label><input id="custName" data-customer-field="name" value="${escapeHTML(editor.customerSnapshot.name||'')}" placeholder="Customer's name or business" /></div><div class="field"><label for="custBusiness">Business name <span class="optional">(optional)</span></label><input id="custBusiness" data-customer-field="business" value="${escapeHTML(editor.customerSnapshot.business||'')}" placeholder="Company / organisation" /></div><div class="field"><label for="custPhone">Phone</label><input id="custPhone" data-customer-field="phone" value="${escapeHTML(editor.customerSnapshot.phone||'')}" placeholder="+260…" /></div><div class="field"><label for="custEmail">Email</label><input id="custEmail" type="email" data-customer-field="email" value="${escapeHTML(editor.customerSnapshot.email||'')}" placeholder="client@example.com" /></div><div class="field"><label for="custTPIN">Customer TPIN <span class="optional">(optional)</span></label><input id="custTPIN" data-customer-field="tpin" value="${escapeHTML(editor.customerSnapshot.tpin||'')}" /></div><div class="field"><label for="custAddress">Billing / delivery address</label><textarea id="custAddress" data-customer-field="address" rows="2" placeholder="Address">${escapeHTML(editor.customerSnapshot.address||'')}</textarea></div></div>
          </div>
          <div class="form-section"><div class="form-section-title"><div><h3>3. Items, quantities & pricing</h3><p>Catalog items are reusable; line values can still be edited for this document.</p></div></div>
            ${c.catalog.length?`<div class="info-note mb-12">${c.catalog.length} saved catalog item(s) available. Use the product/service selector in a line, or <button type="button" class="btn btn-small btn-secondary" data-action="go-catalog">manage catalog</button>.</div>`:`<div class="info-note mb-12">No catalog items yet. You can type lines manually now, or <button type="button" class="btn btn-small btn-secondary" data-action="go-catalog">add products and services</button> for faster repeat work.</div>`}
            <div class="item-toolbar"><span>${editor.items.length} line item(s)</span><button type="button" class="btn btn-secondary btn-small" data-action="add-line">＋ Add line</button></div>
            <div class="line-items-wrap"><table class="line-items-table"><thead><tr><th style="min-width:155px">Catalog / item</th><th style="min-width:95px">Description</th><th>Qty</th><th>Unit</th><th>Selling / ordered unit price</th><th>Disc %</th><th>Tax %</th><th>Total</th><th></th></tr></thead><tbody>${editor.items.map((ln,i)=>`<tr data-line-row="${i}"><td><select class="item-catalog-select" data-line-index="${i}" data-line-field="catalogId"><option value="">Manual item…</option>${c.catalog.map(p=>`<option value="${escapeHTML(p.id)}" ${ln.catalogId===p.id?'selected':''}>${escapeHTML(p.name)}${p.sku?' · '+escapeHTML(p.sku):''}</option>`).join('')}</select><input class="item-name-input mt-12" data-line-index="${i}" data-line-field="name" value="${escapeHTML(ln.name||'')}" placeholder="Item / service name" /><input class="mt-12" data-line-index="${i}" data-line-field="category" value="${escapeHTML(ln.category||'')}" placeholder="Category (optional)" /></td><td><input data-line-index="${i}" data-line-field="description" value="${escapeHTML(ln.description||'')}" placeholder="Details" /></td><td><input class="tiny-input" type="number" min="0" step="any" data-line-index="${i}" data-line-field="qty" value="${escapeHTML(ln.qty??1)}" /></td><td><input class="tiny-input" data-line-index="${i}" data-line-field="unit" value="${escapeHTML(ln.unit||'unit')}" /></td><td><input type="number" min="0" step="any" data-line-index="${i}" data-line-field="price" value="${escapeHTML(ln.price??0)}" /></td><td><input class="tiny-input" type="number" min="0" max="100" step="any" data-line-index="${i}" data-line-field="discountRate" value="${escapeHTML(ln.discountRate??0)}" /></td><td><input class="tiny-input" type="number" min="0" max="100" step="any" data-line-index="${i}" data-line-field="taxRate" value="${escapeHTML(ln.taxRate??0)}" /></td><td class="nowrap"><strong id="lineTotal${i}">${escapeHTML(money(lineTotals(ln).total,editor.currency))}</strong></td><td><button type="button" class="remove-row" data-action="remove-line" data-index="${i}" title="Remove line">×</button></td></tr>`).join('')}</tbody></table></div>
            <div class="totals-editor" id="editorTotals">${renderTotalsEditor(editor)}</div>
          </div>
          ${editor.type==='receipt'?`<div class="form-section"><div class="form-grid"><div class="field"><label for="amountPaid">Amount received</label><input type="number" min="0" step="any" id="amountPaid" data-editor-field="amountPaid" value="${escapeHTML(editor.amountPaid??0)}" /></div></div></div>`:''}
          <div class="form-section"><div class="form-section-title"><div><h3>4. Notes & payment instructions</h3><p>Keep terms specific to this customer or order.</p></div></div><div class="form-grid"><div class="field"><label for="editNotes">Notes <span class="optional">(optional)</span></label><textarea id="editNotes" data-editor-field="notes" placeholder="Thank you for your business…">${escapeHTML(editor.notes||'')}</textarea></div><div class="field"><label for="editTerms">Terms / payment details <span class="optional">(optional)</span></label><textarea id="editTerms" data-editor-field="terms" placeholder="Payment terms, delivery notes or return policy…">${escapeHTML(editor.terms||'')}</textarea></div></div></div>
          <div class="gap-8 mt-16"><button type="button" class="btn btn-secondary" data-action="preview-modal">Preview full document</button><button type="button" class="btn btn-secondary" data-action="print-draft">Print / Save as PDF</button></div>
          <div class="gap-8 mt-12"><button type="button" class="btn btn-primary" data-action="save-document">✓ Save document</button><button type="button" class="btn btn-secondary" data-action="save-document-new">Save & create another</button><button type="button" class="btn btn-plain" data-action="reset-editor">Clear form</button></div>
        </form>
      </section>
      <section class="doc-preview-panel sticky-panel"><div class="preview-topline"><strong>LIVE DOCUMENT PREVIEW</strong><span>Print-ready layout · A4</span></div><div id="liveDocPreview">${renderDocumentHTML(doc,makeCompanySnapshot(c),doc.customerSnapshot)}</div></section></div>`;
  }
  function renderTotalsEditor(d) { const t=docTotals(d);return `<div class="total-row"><span>Subtotal</span><strong>${escapeHTML(money(t.subtotal,d.currency))}</strong></div>${t.discount?`<div class="total-row"><span>Discount</span><strong>− ${escapeHTML(money(t.discount,d.currency))}</strong></div>`:''}<div class="total-row"><span>Tax</span><strong>${escapeHTML(money(t.tax,d.currency))}</strong></div><div class="total-row final"><span>Total</span><strong>${escapeHTML(money(t.total,d.currency))}</strong></div>${d.type==='receipt'?`<div class="total-row"><span>Balance</span><strong>${escapeHTML(money(Math.max(0,t.total-num(d.amountPaid)),d.currency))}</strong></div>`:''}`; }
  function safeColor(value,fallback='#2563eb'){return /^#[0-9a-f]{6}$/i.test(String(value||''))?String(value):fallback;}
  function renderDocumentHTML(d,cOverride=null,customerOverride=null) {
    const c=cOverride||d.companySnapshot||makeCompanySnapshot(company());
    const cu=customerOverride||d.customerSnapshot||{}; const t=docTotals(d); const mono=c.themeMode==='mono'; const accent=safeColor(c.accent); const items=d.items||[];
    const typeLabel=TYPES[d.type]?.label||'Business document';
    const fields=[['Date issued',formatDate(d.issueDate)],...[(['invoice','proforma','purchase'].includes(d.type)?[['Due date',formatDate(d.dueDate)]]:[]),...(d.type==='quotation'?[['Valid until',formatDate(d.validUntil)]]:[])],...(d.reference?[['Reference',d.reference]]:[]),['Currency',d.currency||c.defaultCurrency||'ZMW']];
    const metaFields=fields.map(([a,b])=>`<div><div class="meta-label">${escapeHTML(a)}</div><div class="meta-value">${escapeHTML(b||'—')}</div></div>`).join('');
    const custName=cu.business||cu.name||'Customer';
    const itemRows=items.map((ln,i)=>{const x=lineTotals(ln);return `<tr><td><span class="item-name">${escapeHTML(ln.name||`Item ${i+1}`)}</span>${ln.sku?`<span class="item-sub">SKU: ${escapeHTML(ln.sku)}</span>`:''}${ln.description?`<span class="item-sub">${escapeHTML(ln.description)}</span>`:''}</td><td>${escapeHTML(ln.qty??1)}</td><td>${escapeHTML(ln.unit||'unit')}</td><td class="text-right">${escapeHTML(money(ln.price,d.currency))}</td><td class="text-right">${escapeHTML(money(x.total,d.currency))}</td></tr>`;}).join('');
    const totalsBlock=['delivery'].includes(d.type)?'':`<div class="doc-total-wrap"><table class="doc-totals"><tbody><tr><td>Subtotal</td><td>${escapeHTML(money(t.subtotal,d.currency))}</td></tr>${t.discount?`<tr><td>Discount</td><td>− ${escapeHTML(money(t.discount,d.currency))}</td></tr>`:''}<tr><td>Tax</td><td>${escapeHTML(money(t.tax,d.currency))}</td></tr><tr class="grand-total"><td>Total</td><td>${escapeHTML(money(t.total,d.currency))}</td></tr>${d.type==='receipt'?`<tr><td>Amount received</td><td>${escapeHTML(money(d.amountPaid,d.currency))}</td></tr><tr><td>Balance</td><td>${escapeHTML(money(Math.max(0,t.total-num(d.amountPaid)),d.currency))}</td></tr>`:''}</tbody></table></div>`;
    const customerLine=[cu.phone,cu.email,cu.tpin?`TPIN: ${cu.tpin}`:''].filter(Boolean).map(escapeHTML).join('<br>');
    const companyLines=[c.address,c.phone,c.email,c.website,c.tpin?`TPIN: ${c.tpin}`:''].filter(Boolean).map(escapeHTML).join('<br>');
    return `<article class="invoice-paper ${mono?'mono':''} theme-${escapeHTML(c.themeStyle||'modern')}" style="--doc-accent:${mono?'#222':accent}"><div class="doc-topline"><div class="doc-brand">${c.logo?`<img class="doc-logo" src="${escapeHTML(c.logo)}" alt="Company logo" />`:`<div class="doc-logo" style="border:1px solid #e3e8f0;border-radius:8px;display:grid;place-items:center;color:${mono?'#222':accent};font-weight:900;font-size:15px">${escapeHTML(initials(c.name||'FB'))}</div>`}<div><div class="doc-company">${escapeHTML(c.name||'Your Company Name')}</div>${c.tagline?`<div class="doc-company-meta"><em>${escapeHTML(c.tagline)}</em></div>`:''}<div class="doc-company-meta">${companyLines||'Add your company contact details in Company profiles.'}</div></div></div><div class="doc-type"><h2>${escapeHTML(typeLabel.toUpperCase())}</h2><div class="doc-type-number">${escapeHTML(d.number||'DRAFT')}</div><div class="doc-type-date">${escapeHTML(formatDate(d.issueDate))}</div></div></div>
      <div class="doc-parties"><div><div class="doc-label">Bill / deliver to</div><div class="doc-party-name">${escapeHTML(custName)}</div><div class="doc-party-lines">${[cu.address,customerLine].filter(Boolean).join('<br>')||'Customer details will appear here.'}</div></div><div><div class="doc-label">Prepared by</div><div class="doc-party-name">${escapeHTML(c.name||'Your Company')}</div><div class="doc-party-lines">${escapeHTML(c.phone||'')}${c.email?`<br>${escapeHTML(c.email)}`:''}${c.tpin?`<br>TPIN: ${escapeHTML(c.tpin)}`:''}</div></div></div>
      <div class="doc-meta-box">${metaFields}</div>
      <table class="doc-items"><thead><tr><th>Item / description</th><th>Qty</th><th>Unit</th><th class="text-right">Unit price</th><th class="text-right">Line total</th></tr></thead><tbody>${itemRows||'<tr><td colspan="5" style="text-align:center;color:#8994a7;padding:20px">Add line items to your document.</td></tr>'}</tbody></table>
      ${totalsBlock}${d.notes?`<div class="doc-note"><div class="doc-note-title">Notes</div><div class="doc-note-content">${escapeHTML(d.notes)}</div></div>`:''}${d.terms?`<div class="doc-note"><div class="doc-note-title">Terms & payment details</div><div class="doc-note-content">${escapeHTML(d.terms)}</div></div>`:''}
      <div class="doc-footer"><div>${escapeHTML(c.bankDetails||'')}<br>${escapeHTML(c.website||'')}</div><div class="doc-thanks">${escapeHTML(c.tagline||'Thank you for your business.')}</div></div></article>`;
  }
  function renderCustomers() {
    const c=company(), q=customerSearch.toLowerCase().trim(); const list=c.customers.filter(x=>!q||[x.name,x.business,x.phone,x.email,x.tpin].some(v=>String(v||'').toLowerCase().includes(q)));
    return `<div class="page-head"><div><h2>Customer book</h2><p>Keep customer details on this device for quick selection when creating documents. Customers stay separate for each company profile.</p></div><div class="head-actions"><button class="btn btn-secondary" data-action="export-customers">Export CSV</button><button class="btn btn-secondary" data-action="import-customers">Import CSV / JSON</button><button class="btn btn-primary" data-action="new-customer">＋ Add customer</button></div></div>
      <div class="toolbar"><div class="search-box"><input id="customerSearch" placeholder="Search by name, phone, email or TPIN…" value="${escapeHTML(customerSearch)}"></div><span class="pill">${c.customers.length} saved</span></div>
      ${list.length?`<div class="customer-card-grid">${list.map(x=>`<article class="entity-card"><div class="entity-card-top"><div class="company-profile-row"><div class="entity-avatar">${escapeHTML(initials(x.business||x.name))}</div><div><div class="entity-name">${escapeHTML(x.business||x.name||'Unnamed customer')}</div><div class="entity-kind">${escapeHTML(x.business&&x.name&&x.name!==x.business?x.name:'Customer')}</div></div></div><span class="pill">${activeDocs().filter(d=>d.customerId===x.id).length} docs</span></div><div class="entity-detail">${x.phone?`☎ ${escapeHTML(x.phone)}<br>`:''}${x.email?`✉ ${escapeHTML(x.email)}<br>`:''}${x.address?`⌖ ${escapeHTML(x.address)}<br>`:''}${x.tpin?`TPIN: ${escapeHTML(x.tpin)}`:''}</div><div class="entity-card-bottom"><span>Saved locally</span><div class="action-group"><button class="icon-action" data-action="edit-customer" data-id="${escapeHTML(x.id)}">Edit</button><button class="icon-action" data-action="delete-customer" data-id="${escapeHTML(x.id)}">Delete</button><button class="icon-action" data-action="customer-quote" data-id="${escapeHTML(x.id)}">＋ Doc</button></div></div></article>`).join('')}</div>`:`<section class="panel"><div class="empty-state"><div class="empty-icon">♙</div><h3>${q?'No matching customers':'Your customer book is empty'}</h3><p>Add customer details once and reuse them on quotations, invoices and receipts. Or import a CSV / JSON customer list.</p><div class="gap-8" style="justify-content:center"><button class="btn btn-primary" data-action="new-customer">＋ Add customer</button><button class="btn btn-secondary" data-action="import-customers">Import list</button></div></div></section>`}`;
  }
  function renderCatalog() {
    const c=company(), categories=[...new Set(c.catalog.map(p=>p.category).filter(Boolean))].sort(); let list=c.catalog;
    if(catalogCategory!=='all')list=list.filter(p=>(p.category||'Uncategorised')===catalogCategory);
    const q=catalogSearch.toLowerCase().trim();if(q)list=list.filter(p=>[p.name,p.description,p.sku,p.category,p.kind].some(v=>String(v||'').toLowerCase().includes(q)));
    const lowCount=c.catalog.filter(p=>p.trackStock && num(p.stockQty)<=num(p.lowStockAt,2)).length;
    return `<div class="page-head"><div><h2>Products & services catalog</h2><p>Build a reusable price list for faster document creation. Each company profile has its own items, categories, prices and optional stock counts.</p></div><div class="head-actions"><button class="btn btn-secondary" data-action="download-catalog-template">Get CSV template</button><button class="btn btn-secondary" data-action="import-catalog">Import CSV / JSON</button><button class="btn btn-primary" data-action="new-product">＋ Add item</button></div></div>
      ${lowCount?`<div class="warning-note mb-12"><strong>${lowCount} item(s) at or below their low-stock level.</strong> Stock figures are manual tracking aids; quantities are not automatically decremented when documents are created.</div>`:''}
      <div class="toolbar"><div class="search-box"><input id="catalogSearch" placeholder="Search item name, category or SKU…" value="${escapeHTML(catalogSearch)}"></div><select id="catalogCategoryFilter" class="filter-select"><option value="all">All categories</option>${categories.map(x=>`<option value="${escapeHTML(x)}" ${catalogCategory===x?'selected':''}>${escapeHTML(x)}</option>`).join('')}<option value="Uncategorised" ${catalogCategory==='Uncategorised'?'selected':''}>Uncategorised</option></select><span class="pill">${c.catalog.length} saved item(s)</span></div>
      ${list.length?`<section class="panel"><div class="table-wrap"><table><thead><tr><th>Item / service</th><th>Category</th><th>SKU</th><th>Unit price</th><th>Stock</th><th>Type</th><th>Actions</th></tr></thead><tbody>${list.map(p=>`<tr><td><span class="table-primary">${escapeHTML(p.name)}</span><span class="table-secondary">${escapeHTML(p.description||'No description')}</span></td><td>${escapeHTML(p.category||'—')}</td><td>${escapeHTML(p.sku||'—')}</td><td><span class="table-primary">${escapeHTML(money(p.price,p.currency||c.defaultCurrency))}</span><span class="table-secondary">${escapeHTML(p.currency||c.defaultCurrency)} / ${escapeHTML(p.unit||'unit')}</span></td><td>${p.trackStock?`<span class="${num(p.stockQty)<=num(p.lowStockAt,2)?'stock-low':''}">${escapeHTML(p.stockQty??0)} ${escapeHTML(p.unit||'units')}</span>`:'<span class="muted">Not tracked</span>'}</td><td><span class="pill ${p.kind==='service'?'purple':''}">${p.kind==='service'?'Service':'Product'}</span></td><td><div class="action-group"><button class="icon-action" data-action="edit-product" data-id="${escapeHTML(p.id)}">Edit</button><button class="icon-action" data-action="delete-product" data-id="${escapeHTML(p.id)}">Delete</button></div></td></tr>`).join('')}</tbody></table></div></section>`:`<section class="panel"><div class="empty-state"><div class="empty-icon">▣</div><h3>${q||catalogCategory!=='all'?'No matching catalog items':'Your catalog is ready to be built'}</h3><p>Add products, services, units, prices, categories and optional stock counts, or import a list from CSV or JSON.</p><div class="gap-8" style="justify-content:center"><button class="btn btn-primary" data-action="new-product">＋ Add item</button><button class="btn btn-secondary" data-action="import-catalog">Import list</button></div></div></section>`}`;
  }
  function renderCompanyPage() {
    const c=company(); const themeMode=c.themeMode||'color';const accent=c.accent||'#2563eb';
    return `<div class="page-head"><div><h2>Company profiles & branding</h2><p>Keep separate company identities on the same device. Every profile has its own logo, contact details, numbering, customers, catalog and documents.</p></div><div class="head-actions"><button class="btn btn-secondary" data-action="add-company">＋ Add company</button><button class="btn btn-primary" data-action="save-company">Save company details</button></div></div>
      <div class="settings-grid"><section class="form-card"><form id="companyForm" autocomplete="off">
        <div class="form-section"><div class="form-section-title"><div><h3>Business information</h3><p>This information appears on documents generated for the selected profile.</p></div></div>
          <div class="form-grid"><div class="field span-2"><label for="companyName">Registered / trading name *</label><input id="companyName" data-company-field="name" value="${escapeHTML(c.name)}" placeholder="Your company name" required /></div><div class="field"><label for="companyPhone">Phone number</label><input id="companyPhone" data-company-field="phone" value="${escapeHTML(c.phone)}" placeholder="+260…" /></div><div class="field"><label for="companyEmail">Business email</label><input id="companyEmail" type="email" data-company-field="email" value="${escapeHTML(c.email)}" placeholder="office@company.com" /></div><div class="field span-2"><label for="companyAddress">Business address</label><textarea id="companyAddress" data-company-field="address" rows="2" placeholder="Street, town, province, Zambia">${escapeHTML(c.address)}</textarea></div><div class="field"><label for="companyTPIN">Company TPIN</label><input id="companyTPIN" data-company-field="tpin" value="${escapeHTML(c.tpin)}" placeholder="Taxpayer identification number" /></div><div class="field"><label for="companyWebsite">Website / social page</label><input id="companyWebsite" data-company-field="website" value="${escapeHTML(c.website)}" placeholder="www.example.com" /></div><div class="field span-2"><label for="companyTagline">Tagline / footer message</label><input id="companyTagline" data-company-field="tagline" value="${escapeHTML(c.tagline)}" placeholder="Thank you for your business." /></div><div class="field span-2"><label for="companyBank">Payment instructions / bank details</label><textarea id="companyBank" data-company-field="bankDetails" rows="2" placeholder="Bank, account name, account number, mobile money details…">${escapeHTML(c.bankDetails)}</textarea></div></div>
        </div>
        <div class="form-section"><div class="form-section-title"><div><h3>Company logo</h3><p>Use a crisp PNG with a transparent background for the cleanest result.</p></div></div><div class="logo-uploader"><div class="logo-preview">${c.logo?`<img src="${escapeHTML(c.logo)}" alt="Company logo preview">`:'Logo preview'}</div><div><div class="logo-actions"><button type="button" class="btn btn-secondary btn-small" data-action="upload-logo">Upload logo</button>${c.logo?`<button type="button" class="btn btn-plain btn-small" data-action="remove-logo">Remove logo</button>`:''}</div><div class="field-help">PNG, JPG, WEBP or SVG. Logo is stored locally with this profile.</div></div></div></div>
        <div class="form-section"><div class="form-section-title"><div><h3>Document look & currency</h3><p>Choose a consistent style. Change this any time without changing old saved documents.</p></div></div>
          <div class="field mb-12"><label>Color treatment</label><div class="color-row"><button type="button" class="theme-option ${themeMode==='color'?'selected':''}" data-action="set-theme-mode" data-value="color">● Color theme</button><button type="button" class="theme-option ${themeMode==='mono'?'selected':''}" data-action="set-theme-mode" data-value="mono">◐ Black & white</button></div></div>
          <div class="field mb-12"><label>Accent color</label><div class="color-row">${ACCENTS.map(a=>`<button type="button" class="theme-option ${accent===a.value?'selected':''}" data-action="set-accent" data-value="${a.value}"><span class="swatch" style="background:${a.value}"></span>${escapeHTML(a.name)}</button>`).join('')}<label class="theme-option" style="display:flex;align-items:center;gap:8px">Custom <input type="color" id="customAccent" value="${escapeHTML(accent)}" style="border:0;background:transparent;width:24px;height:24px;padding:0" aria-label="Choose custom accent color"></label></div></div>
          <div class="form-grid"><div class="field"><label for="themeStyle">Layout style</label><select id="themeStyle" data-company-field="themeStyle"><option value="modern" ${c.themeStyle==='modern'?'selected':''}>Modern corporate</option><option value="classic" ${c.themeStyle==='classic'?'selected':''}>Classic business</option><option value="minimal" ${c.themeStyle==='minimal'?'selected':''}>Minimal clean</option></select></div><div class="field"><label for="defaultCurrency">Default currency</label><select id="defaultCurrency" data-company-field="defaultCurrency"><option value="ZMW" ${c.defaultCurrency==='ZMW'?'selected':''}>ZMW — Zambian Kwacha (K)</option><option value="USD" ${c.defaultCurrency==='USD'?'selected':''}>USD — US Dollar ($)</option></select></div></div>
        </div>
        <div class="gap-8 mt-16"><button type="submit" class="btn btn-primary">Save company details</button><button type="button" class="btn btn-secondary" data-action="preview-company">Preview sample document</button></div>
      </form></section>
      <section><div class="panel"><div class="panel-head"><div><h3>Saved company profiles</h3><p>Switch between separate business workspaces.</p></div><span class="pill">${state.companies.length} profile(s)</span></div><div style="padding:12px">${state.companies.map(x=>`<div class="backup-card" style="${x.id===c.id?'border-color:var(--accent);background:var(--accent-soft)':''}"><div class="company-profile-row">${x.logo?`<img class="company-logo-inline" src="${escapeHTML(x.logo)}" alt="">`:`<div class="entity-avatar">${escapeHTML(initials(x.name||'FB'))}</div>`}<div style="min-width:0;flex:1"><h4 style="margin:0 0 3px;font-size:12px;overflow-wrap:anywhere">${escapeHTML(x.name||'New company profile')}${x.id===c.id?' <span class="pill success">Active</span>':''}</h4><div class="small muted">${escapeHTML(x.phone||x.email||'No contact details yet')}</div><div class="small muted">${x.documents.length} docs · ${x.customers.length} customers · ${x.catalog.length} catalog items</div></div></div><div class="backup-actions mt-12">${x.id!==c.id?`<button class="btn btn-secondary btn-small" data-action="activate-company" data-id="${escapeHTML(x.id)}">Switch to this company</button>`:''}<button class="btn btn-secondary btn-small" data-action="edit-company-profile" data-id="${escapeHTML(x.id)}">Edit profile</button>${state.companies.length>1?`<button class="btn btn-plain btn-small" data-action="delete-company" data-id="${escapeHTML(x.id)}">Remove</button>`:''}</div></div>`).join('')}</div></div><div class="info-note mt-12"><strong>Profile isolation:</strong> saved documents retain a snapshot of the brand and customer information used when they were created. Catalogs and customer lists are separate for each company.</div></section></div>`;
  }
  function renderSettings() {
    return `<div class="page-head"><div><h2>Settings & backup</h2><p>Fast Brander does not require an account or upload your business records to a cloud service. Export a backup regularly so you can restore your data or move it to another device.</p></div></div>
      <div class="settings-grid"><section class="form-card"><div class="form-section-title"><div><h3>Data backup & restore</h3><p>Backup includes all company profiles, logos, customers, catalog items, numbering settings and saved documents.</p></div></div>
        <div class="backup-card"><h4>Export complete backup</h4><p>Download one JSON file containing your Fast Brander data. Store it somewhere safe, such as another device or a USB drive.</p><div class="backup-actions"><button class="btn btn-primary" data-action="export-backup">⬇ Download backup JSON</button></div></div>
        <div class="backup-card"><h4>Restore a backup</h4><p>Import a previous Fast Brander backup. Restore replaces the current local workspace, so export a fresh backup first if you need the current data too.</p><div class="backup-actions"><button class="btn btn-secondary" data-action="import-backup">Choose backup file</button></div></div>
        <div class="backup-card"><h4>Export this company's catalog</h4><p>Save products and services as CSV for editing in Excel or another spreadsheet app. Import CSV or JSON later.</p><div class="backup-actions"><button class="btn btn-secondary" data-action="export-catalog">Export catalog CSV</button><button class="btn btn-secondary" data-action="download-catalog-template">Download CSV template</button></div></div>
        <div class="warning-note"><strong>Important:</strong> local browser data can be lost if you clear browser storage, uninstall the app or remove app data. Keep a separate backup. The app does not sync or recover data from another device automatically.</div>
      </section><section>
        <div class="panel panel-pad"><div class="form-section-title"><div><h3>Offline & privacy</h3><p>Built to work without a login, server or API key.</p></div></div><div class="info-note"><strong>Stored on this device:</strong> company data, logos, customers, catalog entries, numbering sequences and saved documents are stored locally in browser/app storage.</div><div class="info-note mt-12"><strong>Offline support:</strong> the files contain no remote JavaScript libraries, fonts or image services. When installed/served as a PWA, a service worker caches the app shell for offline launching.</div><div class="info-note mt-12"><strong>PDF and image export:</strong> PDFs are generated locally in the browser; PNG/JPEG exports use the local canvas. Print can also open your device/browser's native print dialog.</div><div class="form-section mt-12"><h3 style="margin:0 0 9px;font-size:13px">App information</h3><div class="total-row"><span>Application</span><strong>Fast Brander</strong></div><div class="total-row"><span>Version</span><strong>${APP_VERSION}</strong></div><div class="total-row"><span>Workspace storage</span><strong>Device-local</strong></div><div class="total-row"><span>Document currencies</span><strong>ZMW · USD</strong></div></div></div>
        <div class="panel panel-pad mt-12"><div class="form-section-title"><div><h3>Import your records</h3><p>Products & services and customer lists accept CSV, TSV or JSON.</p></div></div><div class="backup-actions"><button class="btn btn-secondary" data-action="import-catalog">Import products/services</button><button class="btn btn-secondary" data-action="import-customers">Import customers</button></div><p class="hint mt-12">For an Excel workbook, open it in Excel or LibreOffice and save the sheet as CSV first. See the sample-data folder in the download.</p></div>
      </section></div>`;
  }

  function openModal({title,subtitle='',body='',wide=false,foot='',className=''}) {
    $('#modalRoot').innerHTML=`<div class="modal-backdrop" data-modal-backdrop><section class="modal ${wide?'wide':''} ${className}" role="dialog" aria-modal="true" aria-label="${escapeHTML(title)}"><header class="modal-head"><div><h2>${escapeHTML(title)}</h2>${subtitle?`<p>${escapeHTML(subtitle)}</p>`:''}</div><button class="modal-close" data-action="close-modal" aria-label="Close dialog">×</button></header><div class="modal-body">${body}</div>${foot?`<footer class="modal-foot">${foot}</footer>`:''}</section></div>`;
    modalMode='generic';
  }
  function closeModal() { $('#modalRoot').innerHTML='';modalMode='';editEntityId=null; }
  function renderSetupModal() {
    const c=company();modalMode='setup';
    $('#modalRoot').innerHTML=`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-label="Set up Fast Brander"><header class="modal-head"><div class="setup-intro"><div class="brand-mark">FB</div><div><h3>Welcome to Fast Brander</h3><p>Set up your business identity once. You can add more companies later.</p></div></div></header><div class="modal-body"><div class="setup-steps"><span class="setup-step active"></span><span class="setup-step active"></span><span class="setup-step active"></span></div><div class="step-label">STEP 1 OF 1 · COMPANY DETAILS</div><form id="setupForm"><div class="form-grid"><div class="field span-2"><label for="setupName">Company / trading name *</label><input id="setupName" data-company-field="name" value="${escapeHTML(c.name)}" placeholder="e.g. Next Auto Detailing" required autofocus /></div><div class="field"><label for="setupPhone">Phone number</label><input id="setupPhone" data-company-field="phone" value="${escapeHTML(c.phone)}" placeholder="+260…" /></div><div class="field"><label for="setupEmail">Business email</label><input id="setupEmail" data-company-field="email" type="email" value="${escapeHTML(c.email)}" placeholder="office@example.com" /></div><div class="field span-2"><label for="setupAddress">Business address</label><textarea id="setupAddress" data-company-field="address" rows="2" placeholder="Business location">${escapeHTML(c.address)}</textarea></div><div class="field"><label for="setupTPIN">Company TPIN <span class="optional">(optional)</span></label><input id="setupTPIN" data-company-field="tpin" value="${escapeHTML(c.tpin)}" /></div><div class="field"><label for="setupTagline">Tagline <span class="optional">(optional)</span></label><input id="setupTagline" data-company-field="tagline" value="${escapeHTML(c.tagline)}" placeholder="Your business tagline" /></div><div class="field"><label for="setupCurrency">Default currency</label><select id="setupCurrency" data-company-field="defaultCurrency"><option value="ZMW" ${c.defaultCurrency==='ZMW'?'selected':''}>ZMW — Kwacha (K)</option><option value="USD" ${c.defaultCurrency==='USD'?'selected':''}>USD — US Dollar ($)</option></select></div><div class="field"><label for="setupTheme">Document style</label><select id="setupTheme" data-company-field="themeMode"><option value="color" ${c.themeMode==='color'?'selected':''}>Color branded</option><option value="mono" ${c.themeMode==='mono'?'selected':''}>Black & white</option></select></div></div><div class="form-section"><div class="form-section-title"><div><h3>Company logo</h3><p>Optional now; you can upload or replace it later.</p></div></div><div class="logo-uploader"><div class="logo-preview">${c.logo?`<img src="${escapeHTML(c.logo)}" alt="Logo">`:'Logo preview'}</div><div class="logo-actions"><button type="button" class="btn btn-secondary btn-small" data-action="upload-logo">Upload logo</button>${c.logo?`<button type="button" class="btn btn-plain btn-small" data-action="remove-logo">Remove</button>`:''}</div></div></div><div class="info-note mt-12">No account needed. Company records, customer lists and documents stay in local storage on this device. Export backups from Settings & backup.</div><div class="modal-foot" style="margin:20px -22px -22px"><button type="submit" class="btn btn-primary">Save profile & start →</button></div></form></div></section></div>`;
  }
  function customerFormHTML(cu={}) {
    return `<form id="customerEntityForm" autocomplete="off"><div class="form-grid"><div class="field span-2"><label for="entityCustomerName">Customer / contact name *</label><input id="entityCustomerName" name="name" value="${escapeHTML(cu.name||'')}" required placeholder="Full name" /></div><div class="field span-2"><label for="entityCustomerBusiness">Business / organisation</label><input id="entityCustomerBusiness" name="business" value="${escapeHTML(cu.business||'')}" placeholder="Business name, if applicable" /></div><div class="field"><label for="entityCustomerPhone">Phone</label><input id="entityCustomerPhone" name="phone" value="${escapeHTML(cu.phone||'')}" placeholder="+260…" /></div><div class="field"><label for="entityCustomerEmail">Email</label><input id="entityCustomerEmail" type="email" name="email" value="${escapeHTML(cu.email||'')}" placeholder="client@example.com" /></div><div class="field span-2"><label for="entityCustomerAddress">Address</label><textarea id="entityCustomerAddress" name="address" rows="2">${escapeHTML(cu.address||'')}</textarea></div><div class="field span-2"><label for="entityCustomerTPIN">TPIN <span class="optional">(optional)</span></label><input id="entityCustomerTPIN" name="tpin" value="${escapeHTML(cu.tpin||'')}" /></div></div><div class="gap-8 mt-16"><button class="btn btn-primary" type="submit">Save customer</button><button class="btn btn-secondary" type="button" data-action="close-modal">Cancel</button></div></form>`;
  }
  function openCustomerModal(cu=null) {
    editEntityId=cu?.id||null;modalMode='customer';
    openModal({title:cu?'Edit customer':'Add customer',subtitle:'Saved customer details can be reused on every new document for this company.',body:customerFormHTML(cu||{}),className:'customer-modal'});modalMode='customer';editEntityId=cu?.id||null;
  }
  function productFormHTML(p={}) {
    const c=company();return `<form id="productEntityForm" autocomplete="off"><div class="form-grid"><div class="field span-2"><label for="entityProductName">Item / service name *</label><input id="entityProductName" name="name" value="${escapeHTML(p.name||'')}" required placeholder="e.g. Engine detailing" /></div><div class="field"><label for="entityProductKind">Type</label><select id="entityProductKind" name="kind"><option value="product" ${p.kind!=='service'?'selected':''}>Product / goods</option><option value="service" ${p.kind==='service'?'selected':''}>Service</option></select></div><div class="field"><label for="entityProductCategory">Category</label><input id="entityProductCategory" name="category" value="${escapeHTML(p.category||'')}" placeholder="Installation, service, retail…" /></div><div class="field"><label for="entityProductSKU">SKU / item code</label><input id="entityProductSKU" name="sku" value="${escapeHTML(p.sku||'')}" placeholder="Optional code" /></div><div class="field"><label for="entityProductUnit">Unit</label><input id="entityProductUnit" name="unit" value="${escapeHTML(p.unit||'unit')}" placeholder="unit, hour, day, litre…" /></div><div class="field"><label for="entityProductCostPrice">Cost price</label><input id="entityProductCostPrice" name="costPrice" type="number" min="0" step="any" value="${escapeHTML(p.costPrice??0)}" /><div class="field-help">What your business pays to buy or deliver this item.</div></div><div class="field"><label for="entityProductPrice">Selling / unit price *</label><input id="entityProductPrice" name="price" type="number" min="0" step="any" required value="${escapeHTML(p.price??0)}" /><div class="field-help">Price charged to the customer; this is used on orders and documents.</div></div><div class="field"><label for="entityProductCurrency">Price currency</label><select id="entityProductCurrency" name="currency"><option value="ZMW" ${(p.currency||c.defaultCurrency)==='ZMW'?'selected':''}>ZMW — Kwacha</option><option value="USD" ${(p.currency||c.defaultCurrency)==='USD'?'selected':''}>USD — Dollar</option></select></div><div class="field span-2"><label for="entityProductDescription">Description</label><textarea id="entityProductDescription" name="description" rows="2" placeholder="What the product or service includes">${escapeHTML(p.description||'')}</textarea></div><div class="field"><label for="entityProductStock">Stock quantity</label><input id="entityProductStock" name="stockQty" type="number" min="0" step="any" value="${escapeHTML(p.stockQty??0)}" /></div><div class="field"><label for="entityProductLow">Low-stock alert at</label><input id="entityProductLow" name="lowStockAt" type="number" min="0" step="any" value="${escapeHTML(p.lowStockAt??2)}" /></div><div class="field span-2"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" name="trackStock" ${p.trackStock?'checked':''} style="width:auto"> Track stock quantity for this item</label><div class="field-help">Stock is a manual reference indicator. Documents do not automatically change stock.</div></div></div><div class="gap-8 mt-16"><button class="btn btn-primary" type="submit">Save catalog item</button><button class="btn btn-secondary" type="button" data-action="close-modal">Cancel</button></div></form>`;
  }
  function openProductModal(p=null) {
    editEntityId=p?.id||null;modalMode='product';openModal({title:p?'Edit catalog item':'Add product or service',subtitle:'Save this item once to make it available on future documents.',body:productFormHTML(p||{})});modalMode='product';editEntityId=p?.id||null;
  }
  function companyAddModal() {
    openModal({title:'Add another company',subtitle:'Create a separate workspace with its own branding, customers, catalog and documents.',body:`<form id="newCompanyForm"><div class="form-grid"><div class="field span-2"><label for="newCoName">Company name *</label><input id="newCoName" name="name" required placeholder="New company / business name"></div><div class="field"><label for="newCoPhone">Phone</label><input id="newCoPhone" name="phone" placeholder="+260…"></div><div class="field"><label for="newCoEmail">Email</label><input id="newCoEmail" name="email" type="email" placeholder="office@example.com"></div><div class="field span-2"><label for="newCoAddress">Address</label><textarea id="newCoAddress" name="address" rows="2"></textarea></div><div class="field"><label for="newCoCurrency">Default currency</label><select id="newCoCurrency" name="defaultCurrency"><option value="ZMW">ZMW — Kwacha</option><option value="USD">USD — Dollar</option></select></div><div class="field"><label for="newCoMode">Document theme</label><select id="newCoMode" name="themeMode"><option value="color">Color branded</option><option value="mono">Black & white</option></select></div></div><div class="gap-8 mt-16"><button type="submit" class="btn btn-primary">Create company profile</button><button type="button" class="btn btn-secondary" data-action="close-modal">Cancel</button></div></form>`});modalMode='newCompany';
  }
  function setupShow() { renderSetupModal(); }
  function readForm(form) { const fd=new FormData(form); const obj={};for(const [k,v] of fd.entries())obj[k]=typeof v==='string'?v.trim():v;return obj; }

  function saveCompanyFromForm() {
    const form=$('#companyForm'); if(!form)return;
    if(!company().name.trim()){toast('Please enter a company name.','error');$('#companyName')?.focus();return;}
    persistState(true).then(()=>toast('Company profile saved.','success'));
  }
  function saveDocument(createAnother=false) {
    if(!editor)return;
    const c=company();
    editor.items=editor.items.map(ln=>({...ln,qty:Math.max(0,num(ln.qty)),price:Math.max(0,num(ln.price)),taxRate:Math.max(0,Math.min(100,num(ln.taxRate))),discountRate:Math.max(0,Math.min(100,num(ln.discountRate)))}));
    if(editor.type==='receipt' && num(editor.amountPaid)<=0) editor.amountPaid=docTotals(editor).total;
    if(!editor.customerSnapshot?.name?.trim()) { toast('Add the customer or recipient name before saving.','error');$('#custName')?.focus();return; }
    if(!editor.items.some(x=>String(x.name||'').trim())) { toast('Add at least one named product or service.','error');return; }
    const now=new Date().toISOString();const existingIndex=editor.id?c.documents.findIndex(d=>d.id===editor.id):-1;
    if(existingIndex<0){editor.id=id('doc');editor.createdAt=now;c.nextNumbers[editor.type]=Math.max(1,num(c.nextNumbers[editor.type],1))+1;}
    editor.number ||= makeNumber(c,editor.type);editor.updatedAt=now;editor.companySnapshot=makeCompanySnapshot(c);editor.customerSnapshot=clone(editor.customerSnapshot||{});editor.items=editor.items.map(x=>({...x}));
    if(existingIndex>=0)c.documents[existingIndex]=clone(editor);else c.documents.unshift(clone(editor));
    const savedId=editor.id;
    persistState(true).then(()=>{toast(`${TYPES[editor.type].label} ${editor.number} saved on this device.`,'success');selectedDocIds.clear();
      if(createAnother){const nextType=editor.type;editor=makeBlankDoc(nextType);renderPage();}else{navigate('documents');setTimeout(()=>{$(`[data-action="view-doc"][data-id="${CSS.escape(savedId)}"]`)?.focus();},0);}
    });
  }
  function loadDocumentToEditor(docId,duplicate=false) {
    const d=activeDocs().find(x=>x.id===docId);if(!d)return;
    editor=clone(d);if(duplicate){editor.id=null;editor.number=makeNumber(company(),editor.type);editor.createdAt=new Date().toISOString();editor.updatedAt=editor.createdAt;editor.amountPaid=0;}
    editor.companySnapshot=makeCompanySnapshot(company());
    // Snapshot remains attached when editing; the new save stores the profile identity used for the edit.
    navigate('create');
  }
  function newDocument(type='invoice',customerId='') { editor=makeBlankDoc(type);if(customerId){const cu=company().customers.find(x=>x.id===customerId);if(cu){editor.customerId=cu.id;editor.customerSnapshot=clone(cu);}}navigate('create'); }
  function refreshLivePreview() {
    const preview=$('#liveDocPreview');if(!preview||!editor)return;
    if(editor.type==='receipt' && !editor.amountPaidTouched) editor.amountPaid=docTotals(editor).total;
    editor.companySnapshot=makeCompanySnapshot(company());const cust=getCustomerFromSelect();editor.customerSnapshot=clone(cust);
    preview.innerHTML=renderDocumentHTML(editor,makeCompanySnapshot(company()),cust);
    const totals=$('#editorTotals');if(totals)totals.innerHTML=renderTotalsEditor(editor);
    editor.items.forEach((ln,i)=>{const el=$(`#lineTotal${i}`);if(el)el.textContent=money(lineTotals(ln).total,editor.currency);});
  }
  function previewDraftModal() {
    if(!editor)return;editor.companySnapshot=makeCompanySnapshot(company());editor.customerSnapshot=getCustomerFromSelect();
    openModal({title:'Document preview',subtitle:`${TYPES[editor.type]?.label||'Document'} · ${editor.number||'Draft'}`,body:renderDocumentHTML(editor,makeCompanySnapshot(company()),editor.customerSnapshot),wide:true,foot:`<button class="btn btn-secondary" data-action="close-modal">Close</button><button class="btn btn-secondary" data-action="print-draft">Print / Save as PDF</button><button class="btn btn-primary" data-action="save-document">Save document</button>`});
  }
  function viewSavedDoc(docId) {
    const d=activeDocs().find(x=>x.id===docId);if(!d)return;
    openModal({title:`${TYPES[d.type]?.label||'Document'} · ${d.number}`,subtitle:`${d.customerSnapshot?.name||'Customer'} · ${formatDate(d.issueDate)}`,body:renderDocumentHTML(d,d.companySnapshot,d.customerSnapshot),wide:true,foot:`<button class="btn btn-secondary" data-action="close-modal">Close</button><button class="btn btn-secondary" data-action="edit-doc" data-id="${escapeHTML(d.id)}">Edit</button><button class="btn btn-secondary" data-action="export-image" data-id="${escapeHTML(d.id)}">Export image</button><button class="btn btn-secondary" data-action="export-pdf" data-id="${escapeHTML(d.id)}">Export PDF</button><button class="btn btn-primary" data-action="print-doc" data-id="${escapeHTML(d.id)}">Print</button>`});
  }
  function actionDocMenu(docId) {
    const d=activeDocs().find(x=>x.id===docId);if(!d)return;
    openModal({title:`${d.number} · export options`,subtitle:'Choose what to do with this saved document.',body:`<div class="quick-grid" style="grid-template-columns:repeat(2,minmax(0,1fr))"><button class="quick-card" data-action="view-doc" data-id="${escapeHTML(d.id)}"><span class="quick-symbol">◉</span><span><strong>Preview document</strong><small>Open a full-size preview.</small></span></button><button class="quick-card" data-action="print-doc" data-id="${escapeHTML(d.id)}"><span class="quick-symbol">▣</span><span><strong>Print / Save as PDF</strong><small>Use the device print dialog.</small></span></button><button class="quick-card" data-action="export-pdf" data-id="${escapeHTML(d.id)}"><span class="quick-symbol">PDF</span><span><strong>Download PDF</strong><small>Create a local PDF file.</small></span></button><button class="quick-card" data-action="export-image" data-id="${escapeHTML(d.id)}"><span class="quick-symbol">▧</span><span><strong>Download PNG image</strong><small>Export a high-resolution image.</small></span></button><button class="quick-card" data-action="export-jpeg" data-id="${escapeHTML(d.id)}"><span class="quick-symbol">JPG</span><span><strong>Download JPG image</strong><small>Smaller file size for sharing.</small></span></button><button class="quick-card" data-action="edit-doc" data-id="${escapeHTML(d.id)}"><span class="quick-symbol">✎</span><span><strong>Edit document</strong><small>Update details and save.</small></span></button><button class="quick-card" data-action="duplicate-doc" data-id="${escapeHTML(d.id)}"><span class="quick-symbol">⧉</span><span><strong>Duplicate document</strong><small>Create a copy with a fresh number.</small></span></button>${d.type==='quotation'?`<button class="quick-card" data-action="convert-quote" data-id="${escapeHTML(d.id)}"><span class="quick-symbol">↗</span><span><strong>Convert to invoice</strong><small>Carry over the customer and quoted line items.</small></span></button>`:''}</div><div class="gap-8 mt-16"><button class="btn btn-danger" data-action="delete-doc" data-id="${escapeHTML(d.id)}">Delete saved document</button></div>`});
  }

  async function docToCanvasPages(d, opts={}) {
    const c=opts.company||d.companySnapshot||makeCompanySnapshot(company()); const width=1240,height=1754; const maxRows=12;const items=d.items||[];const pageCount=Math.max(1,Math.ceil(items.length/maxRows));const pages=[];
    for(let p=0;p<pageCount;p++){
      const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d');
      const accent=c.themeMode==='mono'?'#202020':(c.accent||'#2563eb');const text='#172033',muted='#647187',line='#e4e9f1',soft=c.themeMode==='mono'?'#f1f1f1':'#f4f7fc';
      ctx.fillStyle='#ffffff';ctx.fillRect(0,0,width,height);ctx.textBaseline='top';
      const margin=86;let y=74;
      if(c.logo){const img=new Image();img.src=c.logo;try{await awaitImageLoaded(img);const ratio=Math.min(145/img.width,120/img.height);ctx.drawImage(img,margin,y,Math.max(1,img.width*ratio),Math.max(1,img.height*ratio));}catch(e){}}
      const tx= c.logo ? margin+170 : margin;
      ctx.fillStyle=text;ctx.font='bold 34px Arial';wrapCanvas(ctx,c.name||'Your Company Name',tx,y+2,540,42,2);
      ctx.fillStyle=accent;ctx.font='bold 17px Arial';if(c.tagline)ctx.fillText(String(c.tagline).slice(0,90),tx,y+44,540);
      ctx.fillStyle=muted;ctx.font='17px Arial';let companyInfo=[c.address,c.phone,c.email,c.website,c.tpin?'TPIN: '+c.tpin:''].filter(Boolean).join('  |  ');wrapCanvas(ctx,companyInfo,tx,y+73,575,25,3);
      const typeText=(TYPES[d.type]?.label||'Business document').toUpperCase();ctx.textAlign='right';ctx.fillStyle=accent;ctx.font='bold 32px Arial';ctx.fillText(typeText,width-margin,y+8,350);ctx.fillStyle=text;ctx.font='bold 21px Arial';ctx.fillText(d.number||'DRAFT',width-margin,y+53,350);ctx.fillStyle=muted;ctx.font='18px Arial';ctx.fillText(formatDate(d.issueDate),width-margin,y+86,350);ctx.textAlign='left';
      y+=158;ctx.strokeStyle=accent;ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(margin,y);ctx.lineTo(width-margin,y);ctx.stroke();y+=32;
      const cu=d.customerSnapshot||{};const x2=width/2+20;
      ctx.fillStyle=muted;ctx.font='bold 16px Arial';ctx.fillText('BILL / DELIVER TO',margin,y);ctx.fillText('PREPARED BY',x2,y);y+=31;
      ctx.fillStyle=text;ctx.font='bold 23px Arial';wrapCanvas(ctx,cu.business||cu.name||'Customer',margin,y,480,29,2);wrapCanvas(ctx,c.name||'Your Company',x2,y,480,29,2);y+=35;
      ctx.fillStyle=muted;ctx.font='17px Arial';let ci=[cu.address,cu.phone,cu.email,cu.tpin?'TPIN: '+cu.tpin:''].filter(Boolean).join('\n');let bi=[c.address,c.phone,c.email,c.tpin?'TPIN: '+c.tpin:''].filter(Boolean).join('\n');const cy=drawWrappedLines(ctx,ci,margin,y,480,26,4);drawWrappedLines(ctx,bi,x2,y,480,26,4);y=Math.max(cy,y+90)+20;
      // Document meta band
      ctx.fillStyle=soft;roundRect(ctx,margin,y,width-margin*2,86,10,true);const meta=[['ISSUED',formatDate(d.issueDate)],...(['invoice','proforma','purchase'].includes(d.type)?[['DUE DATE',formatDate(d.dueDate)]]:[]),...(d.type==='quotation'?[['VALID UNTIL',formatDate(d.validUntil)]]:[]),['CURRENCY',d.currency||c.defaultCurrency||'ZMW'],...(d.reference?[['REFERENCE',d.reference]]:[])];const cell= (width-margin*2)/meta.length;
      meta.forEach((m,i)=>{ctx.fillStyle=muted;ctx.font='bold 14px Arial';ctx.fillText(m[0],margin+i*cell+17,y+15);ctx.fillStyle=text;ctx.font='bold 17px Arial';ctx.fillText(String(m[1]||'—'),margin+i*cell+17,y+43,cell-24);});y+=113;
      // table header
      const cols=[margin,margin+470,margin+600,margin+735,margin+920,width-margin];
      ctx.fillStyle=accent;roundRect(ctx,margin,y,width-margin*2,48,6,true);
      ctx.fillStyle='#fff';ctx.font='bold 15px Arial';ctx.fillText('ITEM / DESCRIPTION',cols[0]+14,y+16);ctx.fillText('QTY',cols[1]+8,y+16);ctx.fillText('UNIT',cols[2]+8,y+16);ctx.textAlign='right';ctx.fillText('UNIT PRICE',cols[4]-12,y+16);ctx.fillText('LINE TOTAL',cols[5]-14,y+16);ctx.textAlign='left';y+=48;
      const pageItems=items.slice(p*maxRows,(p+1)*maxRows);pageItems.forEach((ln,i)=>{const idx=p*maxRows+i;const rowH=67;if(idx%2===1){ctx.fillStyle='#fafbfd';ctx.fillRect(margin,y,width-margin*2,rowH);}ctx.strokeStyle=line;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(margin,y+rowH);ctx.lineTo(width-margin,y+rowH);ctx.stroke();ctx.fillStyle=text;ctx.font='bold 18px Arial';wrapCanvas(ctx,ln.name||`Item ${idx+1}`,cols[0]+14,y+13,430,22,2);if(ln.description){ctx.fillStyle=muted;ctx.font='14px Arial';wrapCanvas(ctx,ln.description,cols[0]+14,y+38,430,17,1);}ctx.fillStyle=text;ctx.font='17px Arial';ctx.fillText(String(ln.qty??1),cols[1]+8,y+20,105);ctx.fillText(String(ln.unit||'unit'),cols[2]+8,y+20,115);ctx.textAlign='right';ctx.fillText(money(ln.price,d.currency),cols[4]-12,y+20,165);ctx.font='bold 17px Arial';ctx.fillText(money(lineTotals(ln).total,d.currency),cols[5]-14,y+20,180);ctx.textAlign='left';y+=rowH;});
      if(p===pageCount-1){y+=25;
        if(d.type!=='delivery'){const t=docTotals(d),rx=width-margin-360;const totalRows=[['Subtotal',money(t.subtotal,d.currency)],...(t.discount?[['Discount','− '+money(t.discount,d.currency)]]:[]),['Tax',money(t.tax,d.currency)],['TOTAL',money(t.total,d.currency)]];if(d.type==='receipt')totalRows.push(['Amount received',money(d.amountPaid,d.currency)],['Balance',money(Math.max(0,t.total-num(d.amountPaid)),d.currency)]);
          totalRows.forEach((r,i)=>{if(i===totalRows.length-1 && r[0]==='TOTAL'){ctx.strokeStyle=line;ctx.beginPath();ctx.moveTo(rx,y);ctx.lineTo(width-margin,y);ctx.stroke();y+=14;}ctx.fillStyle=i===totalRows.length-1&&r[0]==='TOTAL'?accent:muted;ctx.font=i===totalRows.length-1&&r[0]==='TOTAL'?'bold 23px Arial':'18px Arial';ctx.fillText(r[0],rx,y,200);ctx.textAlign='right';ctx.fillStyle=i===totalRows.length-1&&r[0]==='TOTAL'?accent:text;ctx.font=i===totalRows.length-1&&r[0]==='TOTAL'?'bold 25px Arial':'bold 18px Arial';ctx.fillText(r[1],width-margin,y,250);ctx.textAlign='left';y+=36;});
        }
        y+=25;
        if(d.notes){ctx.fillStyle=muted;ctx.font='bold 16px Arial';ctx.fillText('NOTES',margin,y);y+=27;ctx.fillStyle=text;ctx.font='17px Arial';y=drawWrappedLines(ctx,d.notes,margin,y,width-margin*2,25,4)+20;}
        if(d.terms){ctx.fillStyle=muted;ctx.font='bold 16px Arial';ctx.fillText('TERMS & PAYMENT DETAILS',margin,y);y+=27;ctx.fillStyle=text;ctx.font='16px Arial';y=drawWrappedLines(ctx,d.terms,margin,y,width-margin*2,24,5)+15;}
      } else {y+=18;ctx.fillStyle=muted;ctx.font='italic 17px Arial';ctx.fillText('Continued on next page…',margin,y);}
      // Footer is fixed to the bottom so every page feels finished.
      ctx.strokeStyle=line;ctx.beginPath();ctx.moveTo(margin,height-112);ctx.lineTo(width-margin,height-112);ctx.stroke();ctx.fillStyle=muted;ctx.font='15px Arial';wrapCanvas(ctx,c.bankDetails||c.website||'',margin,height-91,780,21,2);ctx.textAlign='right';ctx.fillStyle=accent;ctx.font='bold 17px Arial';ctx.fillText(c.tagline||'Thank you for your business.',width-margin,height-87,460);ctx.fillStyle=muted;ctx.font='13px Arial';ctx.fillText(`Page ${p+1} of ${pageCount}`,width-margin,height-53,220);ctx.textAlign='left';
      pages.push(canvas);
    }
    return pages;
  }
  function awaitImageLoaded(img) { if(img.complete&&img.naturalWidth)return Promise.resolve();return new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;setTimeout(()=>reject(new Error('Image load timed out')),2000);}); }
  function wrapCanvas(ctx,text,x,y,maxWidth,lineHeight,maxLines=4){const words=String(text||'').replace(/\r/g,'').split(/\s+/);let line='',lines=0;for(let n=0;n<words.length;n++){const test=line?line+' '+words[n]:words[n];if(ctx.measureText(test).width>maxWidth&&line){ctx.fillText(line,x,y+lines*lineHeight,maxWidth);lines++;line=words[n];if(lines>=maxLines-1){if(n<words.length-1)line=line.replace(/[.,;:]?$/,'…');break;}}else line=test;}if(line&&lines<maxLines)ctx.fillText(line,x,y+lines*lineHeight,maxWidth);return y+(Math.min(maxLines,lines+1)*lineHeight);}
  function drawWrappedLines(ctx,text,x,y,maxWidth,lineHeight,maxLines=4){const lines=String(text||'').split('\n');let yy=y,count=0;for(const part of lines){const words=part.split(/\s+/);let line='';for(let n=0;n<words.length;n++){const test=line?line+' '+words[n]:words[n];if(ctx.measureText(test).width>maxWidth&&line){ctx.fillText(line,x,yy,maxWidth);yy+=lineHeight;count++;line=words[n];if(count>=maxLines-1)break;}else line=test;}if(line&&count<maxLines){ctx.fillText(line,x,yy,maxWidth);yy+=lineHeight;count++;}if(count>=maxLines)break;}return yy;}
  function roundRect(ctx,x,y,w,h,r,fill){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();if(fill)ctx.fill();}
  function makePdfFromJpegs(jpegUrls) {
    // A self-contained raster PDF writer avoids CDN dependencies and works offline.
    const enc=new TextEncoder();const chunks=[];let length=0;const pushBytes=b=>{chunks.push(b);length+=b.length;};const pushText=s=>pushBytes(enc.encode(s));
    pushText('%PDF-1.4\n% Fast Brander local PDF\n');const offsets=[0];
    const objects=[];
    objects.push('<< /Type /Catalog /Pages 2 0 R >>');
    const pageRefs=jpegUrls.map((_,i)=>`${3+i*3} 0 R`).join(' ');
    objects.push(`<< /Type /Pages /Kids [ ${pageRefs} ] /Count ${jpegUrls.length} >>`);
    jpegUrls.forEach((url,i)=>{
      const idx=3+i*3;const raw=url.split(',')[1];const bin=atob(raw);const imgBytes=new Uint8Array(bin.length);for(let j=0;j<bin.length;j++)imgBytes[j]=bin.charCodeAt(j);
      objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.276 841.89] /Resources << /XObject << /Im${i+1} ${idx+1} 0 R >> >> /Contents ${idx+2} 0 R >>`);
      objects.push({image:true,bytes:imgBytes,objectNumber:idx+1});
      objects.push(`<< /Length ${enc.encode(`q\n595.276 0 0 841.89 0 0 cm\n/Im${i+1} Do\nQ\n`).length} >>\nstream\nq\n595.276 0 0 841.89 0 0 cm\n/Im${i+1} Do\nQ\nendstream`);
    });
    for(let i=0;i<objects.length;i++){
      offsets.push(length);const o=objects[i];pushText(`${i+1} 0 obj\n`);
      if(typeof o==='string')pushText(o+'\nendobj\n');
      else{pushText(`<< /Type /XObject /Subtype /Image /Width 1240 /Height 1754 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${o.bytes.length} >>\nstream\n`);pushBytes(o.bytes);pushText('\nendstream\nendobj\n');}
    }
    const xrefOffset=length;pushText(`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`);for(let i=1;i<offsets.length;i++)pushText(`${String(offsets[i]).padStart(10,'0')} 00000 n \n`);pushText(`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`);
    return new Blob(chunks,{type:'application/pdf'});
  }
  async function exportDocument(docId,kind) {
    const d=docId?activeDocs().find(x=>x.id===docId):clone(editor);if(!d){toast('Document not found.','error');return;}
    if(!docId){d.companySnapshot=makeCompanySnapshot(company());d.customerSnapshot=getCustomerFromSelect();}
    try {
      toast(kind==='pdf'?'Preparing PDF locally…':'Preparing image locally…');
      const pages=await docToCanvasPages(d);const jpg=pages.map(p=>p.toDataURL('image/jpeg',.94));
      const base=safeFilename(`${d.number||TYPES[d.type]?.code||'document'}-${d.customerSnapshot?.name||'customer'}`);
      if(kind==='pdf'){const blob=makePdfFromJpegs(jpg);downloadBlob(blob,base+'.pdf');toast('PDF downloaded.','success');}
      else { // Images are a continuous high-resolution image to keep multi-line documents together.
        const all=document.createElement('canvas');all.width=1240;all.height=1754*pages.length;const ctx=all.getContext('2d');pages.forEach((p,i)=>ctx.drawImage(p,0,i*1754));
        const mime=kind==='jpeg'?'image/jpeg':'image/png';const url=all.toDataURL(mime,kind==='jpeg'?.93:undefined);downloadDataURL(url,base+(kind==='jpeg'?'.jpg':'.png'));toast('Image downloaded.','success');
      }
    } catch(e){console.error(e);toast('Export could not finish in this browser. Try Print / Save as PDF instead.','error');}
  }
  function safeFilename(s){return String(s||'fast-brander-document').normalize('NFKD').replace(/[^a-zA-Z0-9._-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,100)||'fast-brander-document';}
  function downloadBlob(blob,name){
    const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.rel='noopener';a.style.display='none';document.body.appendChild(a);
    try{a.click();}catch(e){window.open(url,'_blank','noopener');}
    setTimeout(()=>{a.remove();URL.revokeObjectURL(url);},60000);
  }
  function downloadDataURL(url,name){
    const a=document.createElement('a');a.href=url;a.download=name;a.rel='noopener';a.style.display='none';document.body.appendChild(a);
    try{a.click();setTimeout(()=>a.remove(),1000);}catch(e){a.remove();window.open(url,'_blank','noopener');}
  }
  function printDocs(docs) {
    if(!docs.length){toast('Select at least one document to print.','error');return;}
    const html=docs.map(d=>renderDocumentHTML(d,d.companySnapshot,d.customerSnapshot)).join('');
    const w=window.open('','_blank');if(!w){openModal({title:'Print preview',subtitle:'Popup was blocked; use your browser menu to print if needed.',body:html,wide:true,foot:'<button class="btn btn-secondary" data-action="close-modal">Close</button>'});toast('Allow pop-ups to open the print dialog.','error');return;}
    w.document.open();w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Fast Brander — Print</title><style>body{margin:0;background:#fff;font-family:Arial,sans-serif}@page{size:A4;margin:0}.invoice-paper{font-size:10px;line-height:1.45;color:#172033;max-width:none!important;min-height:0!important;margin:0!important;padding:15mm!important;box-shadow:none!important;page-break-after:always;break-after:page}.invoice-paper:last-child{page-break-after:auto;break-after:auto}.doc-topline{display:flex;justify-content:space-between;gap:20px;border-bottom:2px solid var(--doc-accent);padding-bottom:20px;margin-bottom:21px}.doc-brand{display:flex;align-items:flex-start;gap:11px}.doc-logo{width:57px;height:57px;object-fit:contain}.doc-company{font-size:16px;font-weight:800}.doc-company-meta{margin-top:6px;color:#6f7888;font-size:9px;line-height:1.6}.doc-type{text-align:right}.doc-type h2{font-size:22px;color:var(--doc-accent);margin:0 0 5px}.doc-type-number{font-weight:800}.doc-type-date,.meta-label{font-size:9px;color:#737e90;margin-top:5px}.doc-parties{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:23px}.doc-label{font-size:8px;letter-spacing:1px;font-weight:800;color:#768198;margin-bottom:6px}.doc-party-name{font-size:12px;font-weight:800}.doc-party-lines{font-size:9px;line-height:1.65;color:#566176;white-space:pre-line}.doc-meta-box{background:#f6f8fb;border-radius:7px;padding:11px 13px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:21px}.meta-value{font-size:9px;font-weight:700}.doc-items{width:100%;border-collapse:collapse;font-size:9px;margin-bottom:16px}.doc-items th{background:var(--doc-accent);color:white;font-size:8px;padding:10px 7px;text-align:left}.doc-items td{padding:10px 7px;border-bottom:1px solid #e9edf3;font-size:9px}.text-right{text-align:right!important}.item-name{font-weight:700;display:block}.item-sub{font-size:8px;color:#8a94a5;display:block;margin-top:3px}.doc-total-wrap{display:flex;justify-content:flex-end;margin-bottom:22px}.doc-totals{width:225px;border-collapse:collapse}.doc-totals td{padding:5px 3px;font-size:9px;color:#606b7c}.doc-totals td:last-child{text-align:right;font-weight:700}.grand-total td{border-top:1px solid #d7deea;padding-top:10px;font-size:13px;font-weight:900;color:var(--doc-accent)}.doc-note{border-top:1px solid #e8ecf3;padding-top:14px;margin-top:5px}.doc-note-title{font-size:8px;letter-spacing:.8px;font-weight:800;color:#768198;margin-bottom:5px}.doc-note-content{font-size:9px;color:#5e697d;line-height:1.6;white-space:pre-line}.doc-footer{border-top:1px solid #e8ecf3;margin-top:23px;padding-top:12px;display:flex;justify-content:space-between;gap:15px;color:#8b95a5;font-size:8px}.doc-thanks{color:var(--doc-accent);font-weight:800;text-align:right}.mono{--doc-accent:#222}.mono .doc-items th{background:#222}</style></head><body>${html}<script>window.onload=()=>{setTimeout(()=>window.print(),250)};<\/script></body></html>`);w.document.close();
  }
  function downloadText(text,name,mime='text/plain;charset=utf-8'){downloadBlob(new Blob([text],{type:mime}),name);}
  function exportBackup(){const filename=`fast-brander-backup-${todayISO()}.json`;downloadText(JSON.stringify(state,null,2),filename,'application/json;charset=utf-8');toast('Backup exported. Keep it somewhere safe.','success');}
  function parseCSV(text) {
    const rows=[];let row=[],field='',q=false;
    for(let i=0;i<text.length;i++){const c=text[i];if(q){if(c==='"'&&text[i+1]==='"'){field+='"';i++;}else if(c==='"')q=false;else field+=c;}else if(c==='"')q=true;else if(c===','){row.push(field);field='';}else if(c==='\n'){row.push(field);rows.push(row);row=[];field='';}else if(c==='\r'){}else field+=c;}
    if(field.length||row.length){row.push(field);rows.push(row);}if(!rows.length)return [];
    const headers=rows.shift().map(h=>h.trim().toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''));
    return rows.filter(r=>r.some(v=>String(v||'').trim())).map(r=>{const o={};headers.forEach((h,i)=>o[h]=String(r[i]??'').trim());return o;});
  }
  function importRecords(kind, file) {
    if(!file)return;
    const reader=new FileReader();reader.onload=async()=>{
      try{
        const txt=String(reader.result||'');let data;
        if(file.name.toLowerCase().endsWith('.json')){data=JSON.parse(txt);if(!Array.isArray(data))data=data[kind]||data.items||data.customers||data.products||[];}
        else if(file.name.toLowerCase().endsWith('.tsv')){const lines=txt.split(/\r?\n/).filter(Boolean).map(l=>l.split('\t'));const headers=(lines.shift()||[]).map(h=>h.trim().toLowerCase().replace(/[^a-z0-9]+/g,'_'));data=lines.map(r=>Object.fromEntries(headers.map((h,i)=>[h,String(r[i]??'').trim()])));}
        else data=parseCSV(txt);
        if(!Array.isArray(data))throw new Error('Expected a list of records.');
        const c=company();let added=0,updated=0;
        if(kind==='catalog'){
          for(const raw of data){const name=pick(raw,['name','item','product','service','item_name','product_name','service_name','description']);if(!name)continue;const sku=pick(raw,['sku','code','item_code','product_code']);const existing=sku?c.catalog.find(x=>x.sku&&x.sku.toLowerCase()===sku.toLowerCase()):null;const item={id:existing?.id||id('item'),name,kind:/service/i.test(pick(raw,['kind','type','item_type']))?'service':'product',description:pick(raw,['description','details','notes']),category:pick(raw,['category','group','department']),sku,unit:pick(raw,['unit','uom','measurement'])||'unit',price:Math.max(0,num(pick(raw,['price','unit_price','rate','selling_price','ordered_price','amount']))),costPrice:Math.max(0,num(pick(raw,['cost_price','costprice','buying_price','purchase_price','unit_cost']))),currency:/^USD$/i.test(pick(raw,['currency']))?'USD':(/ZMW/i.test(pick(raw,['currency']))?'ZMW':c.defaultCurrency),trackStock:/^(true|yes|1)$/i.test(pick(raw,['track_stock','trackstock','stock_tracked'])),stockQty:Math.max(0,num(pick(raw,['stock_qty','stock','quantity_in_stock','qty_in_stock']))),lowStockAt:Math.max(0,num(pick(raw,['low_stock_at','low_stock','reorder_level']),2))};if(existing){Object.assign(existing,item);updated++;}else{c.catalog.push(item);added++;}}
        }else{
          for(const raw of data){const name=pick(raw,['name','customer','customer_name','contact_name','client_name']);if(!name)continue;const email=pick(raw,['email','email_address']),phone=pick(raw,['phone','phone_number','mobile','telephone']);const existing=(email&&c.customers.find(x=>x.email&&x.email.toLowerCase()===email.toLowerCase()))||(phone&&c.customers.find(x=>x.phone===phone));const item={id:existing?.id||id('customer'),name,business:pick(raw,['business','business_name','company','organisation','organization']),phone,email,address:pick(raw,['address','billing_address','location']),tpin:pick(raw,['tpin','tax_id','tax_number'])};if(existing){Object.assign(existing,item);updated++;}else{c.customers.push(item);added++;}}
        }
        if(added+updated===0)throw new Error('No usable rows were found. Check the header names and make sure each row has a name.');
        await persistState(true);closeModal();renderPage();toast(`Import complete: ${added} added, ${updated} updated.`,'success');
      }catch(e){console.error(e);toast(`Import failed: ${e.message||'Check the file format.'}`,'error');}
    };reader.onerror=()=>toast('Could not read that file.','error');reader.readAsText(file);
  }
  function pick(obj, keys){for(const k of keys){if(obj[k]!==undefined&&String(obj[k]).trim()!=='')return String(obj[k]).trim();}return '';}
  function downloadCatalogTemplate(){const csv='name,kind,description,category,sku,unit,cost_price,price,currency,track_stock,stock_qty,low_stock_at\nExample product,product,Short item description,General,ITEM-001,unit,180,250,ZMW,yes,12,3\nExample service,service,Service details,Services,SVC-001,hour,0,350,ZMW,no,0,0\n';downloadText(csv,'fast-brander-catalog-template.csv','text/csv;charset=utf-8');}
  function exportCatalogCSV(){const c=company();const keys=['name','kind','description','category','sku','unit','cost_price','price','currency','track_stock','stock_qty','low_stock_at'];const rows=[keys,...c.catalog.map(p=>[p.name,p.kind,p.description,p.category,p.sku,p.unit,p.costPrice??0,p.price,p.currency,p.trackStock?'yes':'no',p.stockQty,p.lowStockAt])];const csv=rows.map(r=>r.map(v=>`"${String(v??'').replace(/"/g,'""')}"`).join(',')).join('\r\n');downloadText(csv,'fast-brander-catalog.csv','text/csv;charset=utf-8');toast('Catalog exported as CSV.','success');}
  function exportCustomersCSV(){const c=company();const keys=['name','business','phone','email','address','tpin'];const rows=[keys,...c.customers.map(p=>keys.map(k=>p[k]||''))];const csv=rows.map(r=>r.map(v=>`"${String(v??'').replace(/"/g,'""')}"`).join(',')).join('\r\n');downloadText(csv,'fast-brander-customers.csv','text/csv;charset=utf-8');}
  async function importBackup(file) {
    if(!file)return;try{const txt=await file.text();const got=JSON.parse(txt);if(!got||!Array.isArray(got.companies)||!got.companies.length)throw new Error('This file is not a Fast Brander backup.');if(!confirm('Restore this backup? It will replace the current local workspace. Export a backup first if you need to keep current records.'))return;
      got.companies.forEach(ensureCompanyShape);state={...got,version:APP_VERSION,setupComplete:true,activeCompanyId:got.companies.some(c=>c.id===got.activeCompanyId)?got.activeCompanyId:got.companies[0].id};await persistState(true);closeModal();renderPage();toast('Backup restored successfully.','success');
    }catch(e){toast(`Restore failed: ${e.message||'Invalid backup.'}`,'error');}
  }
  async function handleLogo(file) {
    if(!file)return;const ext=(file.name.split('.').pop()||'').toLowerCase();const mime=(file.type||'').toLowerCase();const isSvg=mime==='image/svg+xml'||ext==='svg';const allowed=['png','jpg','jpeg','webp','gif','svg'].includes(ext)||/^image\/(png|jpeg|webp|gif|svg\+xml)$/i.test(mime);if(!allowed){toast('Choose a PNG, JPG, WEBP or SVG logo.','error');return;}const co=companyById(logoTargetCompanyId||state.activeCompanyId);
    try{let data;if(isSvg){if(file.size>500000)throw new Error('SVG file must be under 500 KB.');data=await file.text();if(!/<svg[\s>]/i.test(data)||/<script|onload\s*=|javascript:/i.test(data))throw new Error('This SVG contains unsupported active content. Choose a PNG instead.');data='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(data);}
      else{const src=await fileToDataURL(file);data=await resizeLogo(src);}
      co.logo=data;await persistState(true);renderCompanySwitcher();if(modalMode==='setup'&&!state.setupComplete)renderSetupModal();else if(currentPage==='company')renderPage();toast('Logo added to this company profile.','success');
    }catch(e){toast(e.message||'Could not load that logo.','error');}
  }
  function fileToDataURL(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});}
  function resizeLogo(src){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>{const max=800,scale=Math.min(1,max/Math.max(img.width,img.height));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL('image/png'));};img.onerror=()=>reject(new Error('The image could not be opened.'));img.src=src;});}

  function handleClick(e) {
    const btn=e.target.closest('[data-action]');
    if(btn){e.preventDefault();const action=btn.dataset.action;const did=btn.dataset.id;const val=btn.dataset.value;const type=btn.dataset.type;
      switch(action){
        case 'close-modal':closeModal();return;
        case 'create':newDocument('invoice');return;
        case 'create-type':newDocument(type||'invoice');return;
        case 'go-company':navigate('company');return;case 'go-documents':navigate('documents');return;case 'go-customers':navigate('customers');return;case 'go-catalog':navigate('catalog');return;case 'go-settings':navigate('settings');return;
        case 'new-customer':openCustomerModal();return;
        case 'edit-customer':openCustomerModal(company().customers.find(x=>x.id===did));return;
        case 'delete-customer':if(confirm('Delete this customer from the saved customer list? Existing documents keep their saved customer snapshot.')){company().customers=company().customers.filter(x=>x.id!==did);persistState(true).then(()=>{renderPage();toast('Customer deleted.','success');});}return;
        case 'customer-quote':newDocument('quotation',did);return;
        case 'new-product':openProductModal();return;
        case 'edit-product':openProductModal(company().catalog.find(x=>x.id===did));return;
        case 'delete-product':if(confirm('Delete this catalog item? Existing documents keep their copied line items.')){company().catalog=company().catalog.filter(x=>x.id!==did);persistState(true).then(()=>{renderPage();toast('Catalog item deleted.','success');});}return;
        case 'save-company':saveCompanyFromForm();return;
        case 'add-company':companyAddModal();return;
        case 'activate-company':state.activeCompanyId=did;editor=null;selectedDocIds.clear();persistState(true).then(()=>{navigate('dashboard');toast(`Switched to ${company().name||'company profile'}.`,'success');});return;
        case 'edit-company-profile':state.activeCompanyId=did;editor=null;persistState(true).then(()=>navigate('company'));return;
        case 'delete-company':{const co=companyById(did);if(state.companies.length<=1){toast('Keep at least one company profile.','error');return;}if(confirm(`Remove ${co.name||'this company profile'} and its saved records from this device? Export a backup first if needed.`)){state.companies=state.companies.filter(x=>x.id!==did);if(state.activeCompanyId===did)state.activeCompanyId=state.companies[0].id;editor=null;persistState(true).then(()=>{navigate('company');toast('Company profile removed.','success');});}return;}
        case 'upload-logo':logoTargetCompanyId=company().id;$('#logoInput').click();return;
        case 'remove-logo':company().logo='';persistState(true).then(()=>{if(modalMode==='setup'&&!state.setupComplete)renderSetupModal();else renderPage();toast('Company logo removed.');});return;
        case 'set-theme-mode':company().themeMode=val;persistState(false);renderPage();return;
        case 'set-accent':company().accent=val;persistState(false);renderPage();return;
        case 'preview-company':{const d=makeBlankDoc('invoice');d.customerSnapshot={name:'Example Customer',business:'Customer Business Ltd',phone:'+260 97 000 0000',email:'customer@example.com',address:'Lusaka, Zambia'};d.items=[{name:'Sample service',description:'Illustrative line item',qty:2,unit:'service',price:350,taxRate:0,discountRate:0}];d.companySnapshot=makeCompanySnapshot(company());openModal({title:'Sample document preview',subtitle:'Preview how this company profile appears on a document.',body:renderDocumentHTML(d,d.companySnapshot,d.customerSnapshot),wide:true,foot:'<button class="btn btn-primary" data-action="close-modal">Done</button>'});return;}
        case 'save-document':saveDocument(false);return;case 'save-document-new':saveDocument(true);return;
        case 'add-line':editor.items.push(newLine(company()));renderPage();return;
        case 'remove-line':if(editor.items.length<=1){toast('Keep at least one line item.','error');return;}editor.items.splice(Number(btn.dataset.index),1);renderPage();return;
        case 'reset-editor':if(confirm('Clear this unsaved document form?')){editor=makeBlankDoc('invoice');renderPage();}return;
        case 'preview-modal':previewDraftModal();return;
        case 'print-draft':{closeModal();if(!editor)return;const d=clone(editor);d.companySnapshot=makeCompanySnapshot(company());d.customerSnapshot=getCustomerFromSelect();printDocs([d]);return;}
        case 'view-doc':viewSavedDoc(did);return;
        case 'edit-doc':closeModal();loadDocumentToEditor(did);return;
        case 'duplicate-doc':closeModal();loadDocumentToEditor(did,true);return;
        case 'convert-quote':{const d=activeDocs().find(x=>x.id===did);closeModal();if(d){editor=clone(d);editor.id=null;editor.type='invoice';editor.number=makeNumber(company(),'invoice');editor.amountPaid=0;editor.dueDate=addDaysISO(editor.issueDate||todayISO(),14);editor.createdAt=new Date().toISOString();editor.updatedAt=editor.createdAt;editor.companySnapshot=makeCompanySnapshot(company());navigate('create');toast('Quotation copied into a new invoice. Review it before saving.','success');}return;}
        case 'doc-actions':actionDocMenu(did);return;
        case 'print-doc':{closeModal();const d=activeDocs().find(x=>x.id===did);if(d)printDocs([d]);return;}
        case 'export-pdf':closeModal();exportDocument(did,'pdf');return;
        case 'export-image':closeModal();exportDocument(did,'png');return;
        case 'export-jpeg':closeModal();exportDocument(did,'jpeg');return;
        case 'delete-doc':{const d=activeDocs().find(x=>x.id===did);if(d&&confirm(`Delete ${d.number}? This cannot be undone unless you have a backup.`)){company().documents=activeDocs().filter(x=>x.id!==did);selectedDocIds.delete(did);persistState(true).then(()=>{closeModal();renderPage();toast('Document deleted.','success');});}return;}
        case 'bulk-print':{const docs=activeDocs().filter(d=>selectedDocIds.has(d.id));printDocs(docs);return;}
        case 'preview-company':return;
        case 'import-catalog':importKind='catalog';$('#importInput').click();return;
        case 'import-customers':importKind='customers';$('#importInput').click();return;
        case 'download-catalog-template':downloadCatalogTemplate();return;
        case 'export-catalog':exportCatalogCSV();return;
        case 'export-customers':exportCustomersCSV();return;
        case 'export-backup':exportBackup();return;
        case 'import-backup':$('#backupInput').click();return;
        default:return;
      }
    }
    const nav=e.target.closest('[data-page]');if(nav){if(nav.dataset.page==='create'){newDocument('invoice');}else navigate(nav.dataset.page);return;}
  }
  function onInput(e) {
    const t=e.target;
    if(t.dataset.companyField){company()[t.dataset.companyField]=t.value;schedulePersist();if(t.dataset.companyField==='accent')applyAccent();return;}
    if(t.id==='customAccent'){company().accent=t.value;applyAccent();schedulePersist();$$('[data-action="set-accent"]').forEach(b=>b.classList.remove('selected'));return;}
    if(t.dataset.editorField){if(!editor)return;const k=t.dataset.editorField;editor[k]=t.type==='number'?num(t.value):t.value;if(k==='amountPaid')editor.amountPaidTouched=true;if(k==='type'){editor.number=editor.id?editor.number:makeNumber(company(),editor.type);editor.amountPaid=editor.type==='receipt'?docTotals(editor).total:num(editor.amountPaid);renderPage();return;}if(k==='currency'){refreshLivePreview();renderLineTotals();return;}refreshLivePreview();return;}
    if(t.dataset.customerField){if(!editor)return;editor.customerSnapshot ||= {};editor.customerSnapshot[t.dataset.customerField]=t.value;if(t.dataset.customerField==='name' && editor.customerId){editor.customerId='';const sel=$('#editCustomerSelect');if(sel)sel.value='';}refreshLivePreview();return;}
    if(t.dataset.lineIndex!==undefined&&t.dataset.lineField){if(!editor)return;const i=Number(t.dataset.lineIndex),k=t.dataset.lineField;if(!editor.items[i])return;editor.items[i][k]=t.type==='number'?num(t.value):t.value;if(k==='catalogId'&&t.value){const p=company().catalog.find(x=>x.id===t.value);if(p){editor.items[i]={...editor.items[i],catalogId:p.id,name:p.name,description:p.description||'',category:p.category||'',sku:p.sku||'',unit:p.unit||'unit',price:p.price,currency:p.currency||editor.currency};if(p.currency&&p.currency!==editor.currency)toast(`This catalog item is priced in ${p.currency}; the document currency remains ${editor.currency}.`,'');renderPage();return;}}refreshLivePreview();return;}
    if(t.id==='documentSearch'){docSearch=t.value;const pos=t.selectionStart;renderPage();const n=$('#documentSearch');n?.focus();if(n&&pos!==null)n.setSelectionRange(pos,pos);return;}
    if(t.id==='customerSearch'){customerSearch=t.value;const pos=t.selectionStart;renderPage();const n=$('#customerSearch');n?.focus();if(n&&pos!==null)n.setSelectionRange(pos,pos);return;}
    if(t.id==='catalogSearch'){catalogSearch=t.value;const pos=t.selectionStart;renderPage();const n=$('#catalogSearch');n?.focus();if(n&&pos!==null)n.setSelectionRange(pos,pos);return;}
  }
  function renderLineTotals(){if(!editor)return;editor.items.forEach((ln,i)=>{const el=$(`#lineTotal${i}`);if(el)el.textContent=money(lineTotals(ln).total,editor.currency);});const totals=$('#editorTotals');if(totals)totals.innerHTML=renderTotalsEditor(editor);}
  function onChange(e) {
    const t=e.target;
    if(t.id==='companySwitcher'){state.activeCompanyId=t.value;editor=null;selectedDocIds.clear();persistState(true).then(()=>navigate('dashboard'));return;}
    if(t.id==='editType'){onInput({target:t});return;}
    if(t.id==='editCustomerSelect'){if(!editor)return;editor.customerId=t.value;const cu=company().customers.find(x=>x.id===t.value);editor.customerSnapshot=cu?clone(cu):{name:'',business:'',phone:'',email:'',address:'',tpin:''};renderPage();return;}
    if(t.id==='documentTypeFilter'){docFilter=t.value;renderPage();return;}
    if(t.id==='catalogCategoryFilter'){catalogCategory=t.value;renderPage();return;}
    if(t.dataset.lineIndex!==undefined&&t.dataset.lineField){onInput({target:t});return;}
    if(t.id==='logoInput'){return;}
    if(t.id==='importInput'){importRecords(importKind,t.files?.[0]);t.value='';return;}
    if(t.id==='backupInput'){importBackup(t.files?.[0]);t.value='';return;}
    if(t.id==='selectAllDocs'){const checked=t.checked;$$('[data-select-doc]').forEach(x=>{x.checked=checked;checked?selectedDocIds.add(x.dataset.selectDoc):selectedDocIds.delete(x.dataset.selectDoc);});return;}
    if(t.dataset.selectDoc!==undefined){t.checked?selectedDocIds.add(t.dataset.selectDoc):selectedDocIds.delete(t.dataset.selectDoc);return;}
    if(t.dataset.companyField){company()[t.dataset.companyField]=t.value;schedulePersist();return;}
  }
  async function onSubmit(e) {
    const form=e.target;
    if(form.id==='setupForm'){e.preventDefault();if(!company().name.trim()){toast('Enter your company name to continue.','error');return;}state.setupComplete=true;await persistState(true);closeModal();navigate('dashboard');toast('Company profile saved. Welcome to Fast Brander.','success');return;}
    if(form.id==='companyForm'){e.preventDefault();saveCompanyFromForm();return;}
    if(form.id==='customerEntityForm'){e.preventDefault();const data=readForm(form);if(!data.name){toast('Customer name is required.','error');return;}const c=company();if(editEntityId){const old=c.customers.find(x=>x.id===editEntityId);if(old)Object.assign(old,{...data,id:editEntityId});}else c.customers.push({...data,id:id('customer')});await persistState(true);const saved=editEntityId?c.customers.find(x=>x.id===editEntityId):c.customers[c.customers.length-1];
      // Refresh draft customer selector and select the newly-created record for convenience.
      if(editor && currentPage==='create'){editor.customerId=saved.id;editor.customerSnapshot=clone(saved);closeModal();renderPage();}else{closeModal();renderPage();}toast('Customer saved.','success');return;}
    if(form.id==='productEntityForm'){e.preventDefault();const data=readForm(form);data.trackStock=$('[name="trackStock"]',form).checked;data.price=Math.max(0,num(data.price));data.costPrice=Math.max(0,num(data.costPrice));data.stockQty=Math.max(0,num(data.stockQty));data.lowStockAt=Math.max(0,num(data.lowStockAt));const c=company();if(editEntityId){const old=c.catalog.find(x=>x.id===editEntityId);if(old)Object.assign(old,{...data,id:editEntityId});}else c.catalog.push({...data,id:id('item')});await persistState(true);closeModal();renderPage();toast('Catalog item saved.','success');return;}
    if(form.id==='newCompanyForm'){e.preventDefault();const data=readForm(form);if(!data.name){toast('Company name is required.','error');return;}const c={...defaultCompany(),...data,id:id('company')};c.defaultCurrency=data.defaultCurrency||'ZMW';c.themeMode=data.themeMode||'color';state.companies.push(c);state.activeCompanyId=c.id;editor=null;await persistState(true);closeModal();navigate('company');toast('New company profile created.','success');return;}
  }
  function initEvents() {
    document.addEventListener('click',e=>{const nav=e.target.closest('[data-page]');if(nav){navigate(nav.dataset.page);return;}handleClick(e);});
    document.addEventListener('input',onInput);
    document.addEventListener('change',onChange);
    document.addEventListener('submit',onSubmit);
    $('#topCreate').addEventListener('click',()=>newDocument('invoice'));
    $('#addCompanyShortcut').addEventListener('click',companyAddModal);
    $('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
    $('#logoInput').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];if(f)handleLogo(f);e.target.value='';});
    window.addEventListener('online',updateNetworkStatus);window.addEventListener('offline',updateNetworkStatus);
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#modalRoot').innerHTML&&!(!state.setupComplete&&modalMode==='setup'))closeModal();if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'&&currentPage==='create'){e.preventDefault();saveDocument(false);}});
  }
  async function boot() {
    await requestPersistentStorage();
    await loadState();state.companies.forEach(ensureCompanyShape);if(!state.activeCompanyId||!state.companies.some(c=>c.id===state.activeCompanyId))state.activeCompanyId=state.companies[0].id;
    initEvents();updateNetworkStatus();renderPage();
    if(location.hash==='#customers')navigate('customers');else if(location.hash==='#invoice')newDocument('invoice');
    if(!state.setupComplete || !company().name)renderSetupModal();
    if('serviceWorker' in navigator && ['http:','https:'].includes(location.protocol)){
      navigator.serviceWorker.register('./sw.js').catch(()=>{});
    }
  }
  boot().catch(err=>{console.error(err);$('#pageContent').innerHTML='<section class="panel panel-pad"><h2>Fast Brander could not start</h2><p>Please refresh the page. If you are running inside a converter app, check that app storage is enabled.</p></section>';});
})();
