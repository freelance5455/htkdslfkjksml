# CG System - Android (إصلاح WebView)

هذه النسخة تصلح خطأ **صفحة الويب غير متاحة / ERR_HTTP_RESPONSE_CODE_FAILURE** الذي يظهر عندما يحاول التطبيق فتح مسار غير صحيح مثل `/web/index.html`.

تم إعداد التطبيق باستخدام `WebViewAssetLoader`، والطريقة الصحيحة لتحميل الصفحة المضمنة هي:

`https://appassets.androidplatform.net/assets/index.html`

ويوجد ملف النظام داخل:

`app/src/main/assets/index.html`

## البناء
1. افتح المجلد الرئيسي في Android Studio.
2. انتظر Gradle Sync.
3. اختر **Build > Build APK(s)**.
4. ملف APK التجريبي سيكون داخل `app/build/outputs/apk/debug/`.

لا تحتاج الصفحة المحلية إلى الإنترنت إذا كانت كل ملفاتها مضمنة داخل APK.
