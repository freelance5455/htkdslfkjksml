import os
r='/home/claude/FUT27/'
css=open(r+'css/style.css').read()
js=''.join('/* ---- %s ---- */\n'%f+open(r+'js/'+f).read()+'\n' for f in ['data.js','core.js','world.js','match.js','ui.js','main.js'])
h=open(r+'index.src.html').read()
open('/mnt/user-data/outputs/index.html','w').write(h.replace('<!--CSS-->','<style>\n'+css+'</style>').replace('<!--JS-->','<script>\n'+js+'</script>'))
open(r+'index.html','w').write(h.replace('<!--CSS-->','<link rel="stylesheet" href="css/style.css">').replace('<!--JS-->',''.join('<script src="js/%s"></script>\n'%f for f in ['data.js','core.js','world.js','match.js','ui.js','main.js'])))
open('/home/claude/all.js','w').write(js)
