'use strict';
/* ===== FUT27 · main.js · GameManager (boot + loop) ===== */
const GameManager={
  last:0,
  boot(){SaveManager.load();LANG=SaveManager.data.settings.lang;$('lt').textContent=t('loading');$('tip').textContent=t('tip')+': '+pick(TIPS[LANG]);$('rot').firstElementChild.textContent=t('rotate');
    document.querySelector('#loading .logoWrap').innerHTML=UI.logo.call(UI);
    if(!GraphicsManager.hasWebGL()||typeof THREE==='undefined'){$('nogl').textContent=t('nogl');$('nogl').classList.remove('hidden');$('loading').classList.add('hidden');return;}
    const steps=[()=>GraphicsManager.init($('gl')),()=>PlayerManager.init(),()=>World.init(),()=>BallManager.init(World.scene),()=>{InputManager.init();UI.init();AudioManager.applyVol&&0;},()=>{CameraManager.menu(0);}];
    let i=0;const run=()=>{if(i<steps.length){try{steps[i++]();}catch(e){console.error(e);$('tip').textContent='Erro: '+e.message;return;}$('lbar').style.width=(i/steps.length*100)+'%';setTimeout(run,90);}else this.ready();};setTimeout(run,60);},
  ready(){setTimeout(()=>{const ld=$('loading');ld.classList.remove('in');setTimeout(()=>ld.classList.remove('show'),300);UI.go('menu');
      document.addEventListener('pointerdown',()=>{AudioManager.init();AudioManager.resume();if(this.mus)return;this.mus=1;AudioManager.music('menu');if(InputManager.touch&&document.documentElement.requestFullscreen){document.documentElement.requestFullscreen().then(()=>{if(screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{});}).catch(()=>{});}},{once:true});
      this.last=performance.now();requestAnimationFrame(n=>this.loop(n));},250);},
  loop(now){requestAnimationFrame(n=>this.loop(n));if(!GraphicsManager.shouldRender(now))return;const dt=Math.min(.05,(now-this.last)/1000);this.last=now;
    try{if(MatchManager.active)MatchManager.update(dt);else{CameraManager.menu(dt);World.update(dt,0,0);}}catch(e){console.error(e);if(!this.err){this.err=1;GraphicsManager.dbg.classList.remove('hidden');GraphicsManager.dbg.textContent='ERRO: '+e.message+'\n'+(e.stack||'').split('\n').slice(0,4).join('\n');}}
    GraphicsManager.renderer.render(World.scene,World.cam);GraphicsManager.tick(dt);}
};
window.FUT27={debug:v=>GraphicsManager.setDebug(v===undefined?!GraphicsManager.debug:v),save:()=>SaveManager.save(),game:GameManager};
window.addEventListener('load',()=>GameManager.boot());
