'use strict';
/* ===== FUT27 · ui.js · UIManager, TournamentManager, CareerManager, CardManager ===== */
const $=id=>document.getElementById(id);
const DURS=[3,5,8,10];
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const pois=l=>{const L=Math.exp(-l);let k=0,p=1;do{k++;p*=Math.random();}while(p>L);return k-1;};
const leagueOf=id=>getClub(id).league;
const sq=id=>id===SaveManager.data.myClub?SaveManager.squad():genSquad(id);
const rateOf=id=>teamRating(sq(id));
const shirt=c=>`<i class="shirt" style="background:${c.c1};border-color:${c.c2}"></i>`;

/* ================= TORNEIOS ================= */
function rrFixtures(teams){const n=teams.length,arr=teams.slice(),rounds=[];for(let r=0;r<n-1;r++){const m=[];for(let i=0;i<n/2;i++){const a=arr[i],b=arr[n-1-i];m.push(r%2?[b,a]:[a,b]);}rounds.push(m);arr.splice(1,0,arr.pop());}return rounds;}
const TournamentManager={
  get(k){return SaveManager.data.tour[k]||null;},
  create(k,comp,user){const c=COMP[comp],teams=shuffle(c.teams());const st={key:k,comp,type:c.type,teams:c.teams(),user,round:0,results:[],scorers:{},assists:{},finished:false,champion:null,table:{},pos:0};
    st.teams.forEach(id=>st.table[id]={p:0,w:0,d:0,l:0,gf:0,ga:0,pts:0});
    if(c.type==='league')st.fix=rrFixtures(teams);else st.pairs=this.pair(teams);SaveManager.data.tour[k]=st;SaveManager.save();return st;},
  pair(ids){const p=[];for(let i=0;i<ids.length;i+=2)p.push({h:ids[i],a:ids[i+1]});return p;},
  roundName(st){if(st.type==='league')return t('rounds')+' '+(st.round+1)+'/'+st.fix.length;const n=st.pairs.length*2;return n===2?'FINAL':n===4?'SEMI':n===8?'QUARTAS':'OITAVAS';},
  userFix(st){if(st.finished||!st.user)return null;if(st.type==='league'){const f=st.fix[st.round].find(f=>f[0]===st.user||f[1]===st.user);return f?{h:f[0],a:f[1]}:null;}return st.pairs.find(p=>!p.done&&(p.h===st.user||p.a===st.user))||null;},
  pickScorer(id){const s=sq(id),ids=id===SaveManager.data.myClub?SaveManager.lineupIds():null;const pl=ids?ids.map(i=>s.find(p=>p.id===i)):s.slice(0,11);const W={ST:6,LW:3.5,RW:3.5,CAM:3,LM:2.5,RM:2.5,CM:1.8,CDM:.8,LB:.7,RB:.7,CB:.6,GK:0};const w=pl.map(p=>W[p.pos]*p.ovr/70);let r=Math.random()*w.reduce((a,b)=>a+b,0),i=0;while(r>w[i]&&i<w.length-1){r-=w[i];i++;}return pl[i].name;},
  simGoals(h,a){const rh=rateOf(h),ra=rateOf(a);return[Math.min(7,pois(1.3*Math.pow(rh/ra,2.2)*1.08)),Math.min(7,pois(1.1*Math.pow(ra/rh,2.2)))];},
  record(st,h,a,hs,as,goals,pen){const T=st.table;if(st.type==='league'){T[h].p++;T[a].p++;T[h].gf+=hs;T[h].ga+=as;T[a].gf+=as;T[a].ga+=hs;if(hs>as){T[h].w++;T[h].pts+=3;T[a].l++;}else if(hs<as){T[a].w++;T[a].pts+=3;T[h].l++;}else{T[h].d++;T[a].d++;T[h].pts++;T[a].pts++;}}
    goals.forEach(g=>{const k=g.name+'|'+g.club;st.scorers[k]=(st.scorers[k]||0)+1;if(g.assist){const q=g.assist+'|'+g.club;st.assists[q]=(st.assists[q]||0)+1;}});st.results.push({r:st.round,h,a,hs,as,pen:pen||''});},
  simOne(st,h,a){const[hs,as]=this.simGoals(h,a),goals=[];for(let i=0;i<hs;i++)goals.push({club:h,name:this.pickScorer(h),assist:Math.random()<.65?this.pickScorer(h):''});for(let i=0;i<as;i++)goals.push({club:a,name:this.pickScorer(a),assist:Math.random()<.65?this.pickScorer(a):''});return{hs,as,goals};},
  playRound(st,res){if(st.finished)return;const user=st.user;
    const run=(h,a)=>{const isU=user&&(h===user||a===user);let hs,as,goals;
      if(isU&&res){const uh=h===user,opp=uh?a:h;hs=uh?res.hs:res.as;as=uh?res.as:res.hs;goals=res.log.filter(e=>e.type==='goal').map(e=>({club:e.team===0?user:opp,name:e.name,assist:e.assist}));}else{const s=this.simOne(st,h,a);hs=s.hs;as=s.as;goals=s.goals;}return{hs,as,goals,pw:(isU&&res&&res.penWin!==undefined)?(res.penWin===0?user:(h===user?a:h)):null,pen:isU&&res?res.pen:''};};
    if(st.type==='league'){st.fix[st.round].forEach(f=>{const r=run(f[0],f[1]);this.record(st,f[0],f[1],r.hs,r.as,r.goals);});st.round++;if(st.round>=st.fix.length){st.finished=true;const tb=this.sorted(st);st.champion=tb[0];st.pos=user?tb.indexOf(user)+1:0;this.reward(st);}}
    else{const win=[];st.pairs.forEach(p=>{const r=run(p.h,p.a);let pen='';let w;if(r.hs===r.as&&r.pw){pen=r.pen||'pen';w=r.pw;}else if(r.hs===r.as){const rh=rateOf(p.h),ra=rateOf(p.a);const ph=rh/(rh+ra);let x=0,y=0;for(let i=0;i<5;i++){if(Math.random()<.75)x++;if(Math.random()<.75)y++;}while(x===y){if(Math.random()<.75*(.5+ph/2))x++;if(Math.random()<.75*(1.5-ph/2))y++;}pen=x+'-'+y+' pen';w=x>y?p.h:p.a;}else w=r.hs>r.as?p.h:p.a;this.record(st,p.h,p.a,r.hs,r.as,r.goals,pen);p.done=true;p.hs=r.hs;p.as=r.as;p.pen=pen;p.w=w;win.push(w);});
      st.round++;if(win.length===1){st.finished=true;st.champion=win[0];this.reward(st);}else st.pairs=this.pair(win);}
    SaveManager.save();},
  reward(st){const c=COMP[st.comp],sv=SaveManager.data;if(st.user&&st.champion===st.user){sv.money+=c.prize;st.won=true;}else if(st.type==='league'&&st.user&&st.pos<=4)sv.money+=c.prize*.25;},
  sorted(st){return st.teams.slice().sort((a,b)=>{const x=st.table[a],y=st.table[b];return y.pts-x.pts||(y.gf-y.ga)-(x.gf-x.ga)||y.gf-x.gf;});},
  top(map,n){return Object.keys(map).map(k=>({n:k.split('|')[0],c:k.split('|')[1],v:map[k]})).sort((a,b)=>b.v-a.v).slice(0,n);}
};

/* ================= CARTAS ================= */
const CardManager={
  PACKS:[{n:'Pacote Prata',price:200000,min:60,max:78,leg:0},{n:'Pacote Ouro',price:600000,min:72,max:86,leg:.01},{n:'Pacote Elite',price:2000000,min:80,max:93,leg:.14}],
  open(i){const P=this.PACKS[i],sv=SaveManager.data;if(sv.money<P.price)return null;sv.money-=P.price;const out=[];const squad=SaveManager.squad();
    for(let k=0;k<3;k++){let p;if(Math.random()<P.leg){const idx=Math.floor(Math.random()*LEGENDS.length);p=makeLegend(idx);p.id='LEG'+idx+'_'+Date.now()+k;}else{const club=pick(CLUBS),rng=mulberry(Date.now()+k*977+i);const pos=pick(['GK','CB','CB','LB','RB','CDM','CM','CM','CAM','LM','RM','LW','RW','ST','ST']);const o=Math.round(P.min+Math.pow(Math.random(),1.7)*(P.max-P.min));p=genPlayer(rng,club,pos,o,Math.floor(rnd(2,30)),'C'+Date.now()+'_'+k);p.club=club.id;p.card=true;}
      p.rar=rarityOf(p.ovr);squad.push(p);sv.cards.push(p.id);out.push(p);}
    SaveManager.save();return out;},
  card(p,cls){return`<div class="card r-${p.rar} ${cls||''}"><b class="o">${p.ovr}</b><u>${p.pos}</u><span class="nm">${p.name}</span><em>${p.club==='LEG'?'LENDA':p.club} · ${p.nat}</em><div class="st"><i>PAC ${p.pac}</i><i>SHO ${p.sho}</i><i>PAS ${p.pas}</i><i>DRI ${p.dri}</i><i>DEF ${p.def}</i><i>PHY ${p.phy}</i></div><small>${RAR_NAME[p.rar]}</small></div>`;}
};

/* ================= CARREIRA ================= */
const CareerManager={
  start(clubId){const sv=SaveManager.data;sv.myClub=clubId;sv.squad=null;SaveManager.squad();sv.money=20000000;sv.tour.career=null;const lg=leagueOf(clubId);sv.career={club:clubId,season:1,comp:LEAGUE_COMP[lg],market:[],hist:[]};TournamentManager.create('career',sv.career.comp,clubId);this.genMarket();SaveManager.save();},
  active(){return SaveManager.data.career&&TournamentManager.get('career');},
  wages(){return SaveManager.squad().reduce((s,p)=>s+p.ovr*400,0);},
  genMarket(){const c=SaveManager.data.career;const mine=SaveManager.data.myClub;const out=[];shuffle(CLUBS.filter(x=>x.id!==mine)).slice(0,14).forEach(cl=>{const s=genSquad(cl.id);const p=Object.assign({},pick(s.slice(0,16)));if(p.ovr>=58)out.push(p);});c.market=out.sort((a,b)=>b.ovr-a.ovr).slice(0,10);},
  buy(id,loan){const sv=SaveManager.data,c=sv.career,p=c.market.find(x=>x.id===id);if(!p)return false;const price=loan?Math.round(priceOf(p)*.15):priceOf(p);if(sv.money<price)return false;sv.money-=price;c.market=c.market.filter(x=>x!==p);const np=Object.assign({},p,{club:sv.myClub,loan:!!loan});SaveManager.squad().push(np);SaveManager.save();return true;},
  sell(id){const sv=SaveManager.data,s=SaveManager.squad();if(s.length<=16)return false;const i=s.findIndex(p=>p.id===id);if(i<0)return false;const p=s[i];sv.money+=Math.round(priceOf(p)*(p.loan?0:.7));s.splice(i,1);if(sv.lineup&&sv.lineup.includes(id))sv.lineup=null;SaveManager.save();return true;},
  train(id){const sv=SaveManager.data,p=SaveManager.squad().find(x=>x.id===id);if(!p||sv.money<300000||p.ovr>=94)return false;sv.money-=300000;p.ovr++;['pac','sho','pas','dri','def','phy'].forEach(k=>{if(Math.random()<.6)p[k]=Math.min(97,p[k]+1);});p.rar=rarityOf(p.ovr);SaveManager.save();return true;},
  afterRound(res){const sv=SaveManager.data;sv.money+=(res?(res.hs>res.as?1800000:res.hs===res.as?1300000:1000000):1000000)-this.wages();if(sv.money<0)sv.money=0;this.genMarket();SaveManager.save();},
  newSeason(){const sv=SaveManager.data,c=sv.career,st=TournamentManager.get('career');c.hist.push({season:c.season,pos:st.pos});c.season++;const s=SaveManager.squad();for(let i=s.length-1;i>=0;i--){const p=s[i];if(p.loan){s.splice(i,1);continue;}p.age++;const d=p.age<24?(Math.random()<.6?1:0):p.age>31?-(Math.random()<.6?1:0):0;if(d){p.ovr=clamp(p.ovr+d,40,95);['pac','sho','pas','dri','def','phy'].forEach(k=>p[k]=clamp(p[k]+d,25,97));}}
    sv.lineup=null;TournamentManager.create('career',c.comp,c.club);this.genMarket();SaveManager.save();}
};

/* ================= UI ================= */
const UI={
  cur:null,v:{hl:'BR',home:'RJF',al:'BR',away:'PAU',stad:0,wea:0,diff:1,dur:1,cc:0,cclub:null,tab:'table',carlg:'BR',carclub:'RJF',ctab:'home',sel:null,pv:'main',subOut:null,reveal:null,tacTarget:null,mtab:'squad'},
  pendingEnd:null,hudSet:null,toastT:0,
  init(){this.el=$('ui');LANG=SaveManager.data.settings.lang;
    this.el.addEventListener('click',e=>this.onClick(e));
    document.addEventListener('pointerdown',e=>{AudioManager.init();AudioManager.resume();},{once:true});
    $('bP').addEventListener('click',()=>MatchManager.togglePause());$('skipRp').addEventListener('click',()=>MatchManager.skipReplay());
    this.dragInit();let taps=0,tt=0;document.addEventListener('click',e=>{if(e.target.closest('.logoBig')){taps++;clearTimeout(tt);tt=setTimeout(()=>taps=0,1500);if(taps>=5){taps=0;GraphicsManager.setDebug(!GraphicsManager.debug);}}});},
  snd(n,p){const q=AudioManager.quiet;AudioManager.quiet=false;AudioManager.sfx(n,p);AudioManager.quiet=q;},
  logo(){return`<svg viewBox="0 0 120 120" class="logoSvg"><defs><linearGradient id="gd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset="1" stop-color="#d98e04"/></linearGradient><radialGradient id="bl" cx=".35" cy=".3"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#c3cdc7"/></radialGradient></defs><circle cx="60" cy="78" r="36" fill="url(#bl)" stroke="#07140f" stroke-width="3"/><polygon points="60,62 72,71 67,85 53,85 48,71" fill="#07140f"/><path d="M60 62V46M72 71L86 66M67 85L77 97M53 85L43 97M48 71L34 66" stroke="#07140f" stroke-width="3" stroke-linecap="round"/><path d="M34 46L28 18L46 32L60 12L74 32L92 18L86 46Z" fill="url(#gd)" stroke="#07140f" stroke-width="3" stroke-linejoin="round"/><rect x="34" y="46" width="52" height="7" rx="2" fill="url(#gd)" stroke="#07140f" stroke-width="3"/><circle cx="28" cy="16" r="4" fill="#ffe9a0" stroke="#07140f" stroke-width="2"/><circle cx="60" cy="10" r="4.5" fill="#ffe9a0" stroke="#07140f" stroke-width="2"/><circle cx="92" cy="16" r="4" fill="#ffe9a0" stroke="#07140f" stroke-width="2"/></svg>`;},
  /* ---------- navegação ---------- */
  go(id){if(id===this.cur)return;this.snd('trans');const old=this.cur;this.cur=id;let s=$('s-'+id);if(!s){s=document.createElement('section');s.id='s-'+id;s.className='screen';this.el.appendChild(s);}
    s.innerHTML=this.SCR[id]?this.SCR[id].call(this):'';this.post(id);document.querySelectorAll('#ui .screen.in').forEach(o=>{if(o!==s){o.classList.remove('in');const oo=o;setTimeout(()=>{if(!oo.classList.contains('in'))oo.classList.remove('show');},260);}});
    s.classList.add('show');requestAnimationFrame(()=>requestAnimationFrame(()=>s.classList.add('in')));if(id==='menu'){AudioManager.music('menu');if(!MatchManager.active)this.startDemo();}},
  hideAll(){this.cur=null;document.querySelectorAll('#ui .screen.in').forEach(o=>{o.classList.remove('in');setTimeout(()=>o.classList.remove('show'),260);});},
  rerender(){const s=$('s-'+this.cur);if(!s)return;const sc=s.querySelector('.scroll'),st=sc?sc.scrollTop:0;s.innerHTML=this.SCR[this.cur].call(this);this.post(this.cur);const n=s.querySelector('.scroll');if(n)n.scrollTop=st;},
  startDemo(){const a=pick(CLUBS.slice(0,40)),b=pick(CLUBS.slice(0,40).filter(c=>c!==a));AudioManager.quiet=true;MatchManager.start({home:a.id,away:b.id,stadium:Math.floor(Math.random()*6),weather:pick([0,0,1,3]),diff:1,dur:3,cpuOnly:true,demo:true});MatchManager.state='restart';MatchManager.sel=null;this.hudShow(false);},
  endDemo(){if(MatchManager.cfg&&MatchManager.cfg.demo){MatchManager.quit();}AudioManager.quiet=false;},
  head(title,back){return`<header class="head"><button class="back" data-go="${back||'menu'}">${t('back')}</button><h2>${title}</h2><span class="money">${money(SaveManager.data.money)}</span></header>`;},
  cyc(k,label,text){return`<div class="row"><label>${label}</label><div class="cyc" data-k="${k}"><button data-d="-1">◀</button><span>${text}</span><button data-d="1">▶</button></div></div>`;},
  /* ---------- clique ---------- */
  onClick(e){const el=e.target.closest('[data-go],[data-act],.cyc button,[data-tab]');if(!el)return;AudioManager.init();AudioManager.resume();
    if(el.dataset.go){this.snd(el.dataset.go==='menu'?'back':'click');if(el.dataset.go==='quick'||el.dataset.go==='myteam'||el.dataset.go==='champs'||el.dataset.go==='career'||el.dataset.go==='settings'||el.dataset.go==='cards'||el.dataset.go==='menu')this.endDemoIf(el.dataset.go);this.go(el.dataset.go);}
    else if(el.dataset.tab){this.snd('click');this.v[el.closest('[data-tabs]').dataset.tabs]=el.dataset.tab;this.rerender();}
    else if(el.dataset.act){this.snd('click');this.act(el.dataset.act,el);}
    else if(el.closest('.cyc')){this.snd('click');this.cycle(el.closest('.cyc').dataset.k,+el.dataset.d);}},
  endDemoIf(id){if(id!=='menu')this.endDemo();},
  cyi(i,n,d){return(i+d+n)%n;},
  cycle(k,d){const v=this.v,sv=SaveManager.data,S=sv.settings;
    const clubIdx=(lg,cur)=>{const l=clubsOf(lg);return l[this.cyi(Math.max(0,l.findIndex(c=>c.id===cur)),l.length,d)].id;};
    switch(k){
      case'hl':{const i=this.cyi(LEAGUE_ORDER.indexOf(v.hl),LEAGUE_ORDER.length,d);v.hl=LEAGUE_ORDER[i];v.home=clubsOf(v.hl)[0].id;break;}
      case'al':{const i=this.cyi(LEAGUE_ORDER.indexOf(v.al),LEAGUE_ORDER.length,d);v.al=LEAGUE_ORDER[i];v.away=clubsOf(v.al)[0].id;break;}
      case'home':v.home=clubIdx(v.hl,v.home);break;case'away':v.away=clubIdx(v.al,v.away);break;
      case'stad':v.stad=this.cyi(v.stad,6,d);break;case'wea':v.wea=this.cyi(v.wea,4,d);break;case'diff':v.diff=this.cyi(v.diff,5,d);break;case'dur':v.dur=this.cyi(v.dur,4,d);break;
      case'cc':v.cc=this.cyi(v.cc,COMPS.length,d);v.cclub=null;break;
      case'cclub':{const l=COMPS[v.cc].teams();v.cclub=l[this.cyi(Math.max(0,l.indexOf(v.cclub||sv.myClub)),l.length,d)];break;}
      case'carlg':{const i=this.cyi(CAREER_LEAGUES.indexOf(v.carlg),CAREER_LEAGUES.length,d);v.carlg=CAREER_LEAGUES[i];v.carclub=COMP[LEAGUE_COMP[v.carlg]].teams()[0];break;}
      case'carclub':{const l=COMP[LEAGUE_COMP[v.carlg]].teams();v.carclub=l[this.cyi(Math.max(0,l.indexOf(v.carclub)),l.length,d)];break;}
      case'form':{const T=this.tacTeam();const i=this.cyi(FORM_KEYS.indexOf(T.formation),FORM_KEYS.length,d);if(MatchManager.active&&MatchManager.state!=='none'&&this.cur==='pause'){MatchManager.setFormation(MatchManager.teams[0],FORM_KEYS[i]);if(MatchManager.teams[0].club.id===sv.myClub)sv.formation=FORM_KEYS[i];}else{sv.formation=FORM_KEYS[i];sv.lineup=null;}SaveManager.save();break;}
      case'lang':{const L=['pt','en','es'];S.lang=L[this.cyi(L.indexOf(S.lang),3,d)];LANG=S.lang;break;}
      case'gfx':{const G=['auto','low','medium','high','ultra'];GraphicsManager.setQuality(G[this.cyi(G.indexOf(S.gfx),5,d)]);break;}
      case'fps':S.fps=S.fps===60?30:60;break;case'vib':S.vib=!S.vib;if(S.vib)AudioManager.vib(30);break;
      case'cam':{const C=CameraManager.modes;S.cam=C[this.cyi(C.indexOf(S.cam),4,d)];break;}
      case'ctl':{const C=['auto','on','off'];S.ctl=C[this.cyi(C.indexOf(S.ctl),3,d)];break;}
      case'sdiff':S.diff=this.cyi(S.diff,5,d);break;
      default:if(k.startsWith('vol_')){const n=k.slice(4);S.vol[n]=clamp(Math.round((S.vol[n]+d*.1)*10)/10,0,1);AudioManager.applyVol();}
        else if(k.startsWith('t_')){const n=k.slice(2),T=this.tacObj(),mx=n==='ment'?4:3;T[n]=this.cyi(T[n],mx,d);if(this.cur!=='pause')SaveManager.save();}}
    SaveManager.save();if(k==='lang')this.refreshStatic();this.rerender();},
  tacTeam(){if(this.cur==='pause'&&MatchManager.active)return MatchManager.teams[0];return{formation:SaveManager.data.formation,tac:SaveManager.data.tac};},
  tacObj(){return this.cur==='pause'&&MatchManager.active?MatchManager.teams[0].tac:SaveManager.data.tac;},
  tacRows(){const T=this.tacObj(),o=(n,keys,pre)=>t(pre+keys[T[n]]);return this.cyc('t_ment',t('mentality'),o('ment',MENTS,'m_'))+this.cyc('t_press',t('pressure'),o('press',['low','mid','high'],'l_'))+this.cyc('t_line',t('line'),o('line',['low','mid','high'],'l_'))+this.cyc('t_width',t('width'),o('width',['low','mid','high'],'l_'))+this.cyc('t_att',t('attack'),o('att',['wings','mixed','center'],'a_'))+this.cyc('t_build',t('build'),o('build',['slow','mid','fast'],'b_'))+this.cyc('t_compact',t('compact'),o('compact',['low','mid','high'],'l_'));},
  refreshStatic(){$('rot').firstElementChild.textContent=t('rotate');$('lt').textContent=t('loading');},
  /* ---------- telas ---------- */
  SCR:{
    menu(){const sv=SaveManager.data;return`<div class="menuwrap"><div class="logoBig">${this.logo()}<h1>FUT<span>27</span></h1><p>ULTIMATE FOOTBALL</p></div><nav>${['quick:play','myteam:myteam','champs:champs','career:career','training:training','settings:settings'].map((x,i)=>{const[g,k]=x.split(':');return`<button class="mbtn" style="--i:${i}" data-go="${g==='training'?'':g}" ${g==='training'?'data-act="train"':''}>${t(k)}</button>`;}).join('')}</nav><div class="foot">${money(sv.money)} · v0.1</div></div>`;},
    quick(){const v=this.v,H=getClub(v.home),A=getClub(v.away);const L=k=>`<div class="teamcol"><h3>${shirt(getClub(v[k]))} ${getClub(v[k]).name}</h3><small>OVR ${rateOf(v[k])}</small></div>`;
      return this.head(t('play'))+`<div class="grid2 scroll"><div class="panel"><h4>${t('home')}</h4>${this.cyc('hl',t('league'),LEAGUES[v.hl])}${this.cyc('home',t('club'),H.name)}${L('home')}<h4>${t('away')}</h4>${this.cyc('al',t('league'),LEAGUES[v.al])}${this.cyc('away',t('club'),A.name)}${L('away')}</div><div class="panel">${this.cyc('stad',t('stadium'),STADIUMS[v.stad].name)}${this.cyc('wea',t('weather'),t('w_'+WEATHERS[v.wea]))}${this.cyc('diff',t('diff'),t('d_'+DIFFS[v.diff]))}${this.cyc('dur',t('dur'),DURS[v.dur]+' min')}<button class="btn gold big" data-act="startQuick">${t('start')}</button></div></div>`;},
    myteam(){const sv=SaveManager.data,squad=SaveManager.squad(),ids=SaveManager.lineupIds(),sl=FORMS[sv.formation],club=getClub(sv.myClub);const cap=sv.captain||ids[9];
      const chips=sl.map((s,i)=>{const p=squad.find(x=>x.id===ids[i]);return`<div class="chip r-${p.rar}${this.v.sel===p.id?' sel':''}" data-p="${p.id}" style="left:${s[1]*88+6}%;top:${(s[2]+1)/2*78+10}%"><b>${p.ovr}</b><u>${p.pos}</u><span>${p.name.split(' ').slice(-1)[0]}${cap===p.id?' ©':''}</span></div>`;}).join('');
      const bench=squad.filter(p=>!ids.includes(p.id)).sort((a,b)=>b.ovr-a.ovr).map(p=>`<div class="brow r-${p.rar}${this.v.sel===p.id?' sel':''}" data-p="${p.id}"><b>${p.ovr}</b><u>${p.pos}</u><span>${p.name}</span>${p.card?'<em>★</em>':''}</div>`).join('');
      const sel=squad.find(p=>p.id===this.v.sel)||squad.find(p=>p.id===ids[9]);const bar=(k,v)=>`<div class="bar"><label>${k}</label><i style="--w:${v}%"></i><b>${v}</b></div>`;const a=deriveAttrs(sel);
      return this.head(t('myteam'))+`<div class="mt"><div class="fieldwrap"><div class="field"><div class="fl"></div>${chips}</div></div><div class="side scroll">${this.cyc('form',t('formation'),sv.formation)}<div class="pcard r-${sel.rar}"><h3>#${sel.num} ${sel.name}</h3><small>${sel.pos} · ${sel.club==='LEG'?'LENDA':getClub(sel.club).short} · ${sel.nat} · ${sel.age}a · ${RAR_NAME[sel.rar]}</small><div class="ovr">${sel.ovr}</div>${bar('PAC',sel.pac)}${bar('SHO',sel.sho)}${bar('PAS',sel.pas)}${bar('DRI',sel.dri)}${bar('DEF',sel.def)}${bar('PHY',sel.phy)}<small>RES ${a.stamina} · FIN ${a.finishing} · MAR ${a.marking} · REA ${a.reaction}</small><button class="btn" data-act="captain" data-id="${sel.id}">© ${t('captain')}</button></div><details open><summary>${t('tactics')}</summary>${this.tacRows()}</details><h4>${t('bench')}</h4><div class="bench">${bench}</div><button class="btn gold" data-go="cards">${t('packs')} ★</button><button class="btn" data-act="autoLineup">${t('auto')}</button></div></div>`;},
    cards(){const sv=SaveManager.data,mine=SaveManager.squad().filter(p=>p.card);const packs=CardManager.PACKS.map((p,i)=>`<button class="pack p${i}" data-act="pack" data-i="${i}"><b>${p.n}</b><span>${money(p.price)}</span></button>`).join('');
      return this.head(t('packs'),'myteam')+`<div class="cardscr scroll"><div class="packs">${packs}</div>${this.v.reveal?`<div class="reveal">${this.v.reveal.map((c,i)=>CardManager.card(c,'flip').replace('class="card','style="--d:'+i*.35+'s" class="card')).join('')}</div>`:''}<h4>${t('packs')} (${mine.length})</h4><div class="cardgrid">${mine.map(p=>CardManager.card(p)).join('')||'—'}</div></div>`;},
    champs(){const v=this.v,c=COMPS[v.cc],st=TournamentManager.get(c.id);
      if(!st)return this.head(t('champs'))+`<div class="panel center">${this.cyc('cc',t('champs'),c.name)}${this.cyc('cclub',t('myclub'),getClub(v.cclub||(c.teams().includes(SaveManager.data.myClub)?SaveManager.data.myClub:c.teams()[0])).name)}<small>${c.type==='league'?'Pontos corridos · turno único':'Mata-mata · jogo único'}</small><button class="btn gold big" data-act="tourStart">${t('startcomp')}</button></div>`;
      return this.head(c.name)+this.tourView(st,c,'champs');},
    career(){const sv=SaveManager.data,v=this.v;if(!CareerManager.active()){const l=COMP[LEAGUE_COMP[v.carlg]].teams();return this.head(t('career'))+`<div class="panel center"><h3>${t('pickclub')}</h3>${this.cyc('carlg',t('league'),LEAGUES[v.carlg])}${this.cyc('carclub',t('club'),getClub(v.carclub||l[0]).name)}<small>OVR ${rateOf(v.carclub||l[0])}</small><button class="btn gold big" data-act="careerStart">${t('start')}</button></div>`;}
      const st=TournamentManager.get('career'),c=sv.career,sqd=SaveManager.squad();const tabs=['home','squad','market'].map(k=>`<button class="tab${v.ctab===k?' on':''}" data-tab="${k}">${k==='home'?t('table'):k==='squad'?t('squad'):t('market')}</button>`).join('');let body='';
      if(v.ctab==='home'){body=this.tourView(st,COMP[c.comp],'career');}
      else if(v.ctab==='squad'){body=`<div class="list scroll">${sqd.slice().sort((a,b)=>b.ovr-a.ovr).map(p=>`<div class="lrow r-${p.rar}"><b>${p.ovr}</b><u>${p.pos}</u><span>${p.name} <small>${p.age}a${p.loan?' · loan':''}</small></span><button data-act="train1" data-id="${p.id}">${t('train')}</button><button data-act="sell" data-id="${p.id}">${t('sell')} ${money(Math.round(priceOf(p)*(p.loan?0:.7)))}</button></div>`).join('')}</div>`;}
      else body=`<div class="list scroll">${c.market.map(p=>`<div class="lrow r-${p.rar}"><b>${p.ovr}</b><u>${p.pos}</u><span>${p.name} <small>${getClub(p.club).short} · ${p.age}a</small></span><button data-act="buy" data-id="${p.id}">${t('buy')} ${money(priceOf(p))}</button><button data-act="loan" data-id="${p.id}">${t('loan')} ${money(Math.round(priceOf(p)*.15))}</button></div>`).join('')}</div>`;
      return this.head(getClub(c.club).name+' · '+t('season')+' '+c.season)+`<div class="tabs" data-tabs="ctab">${tabs}</div><div class="small">${t('objective')}: TOP 4 · ${t('budget')}: ${money(sv.money)} · salários/rodada ${money(CareerManager.wages())}</div>${body}`;},
    settings(){const S=SaveManager.data.settings,onoff=b=>b?t('sw_on'):t('sw_off');const vol=n=>Math.round(S.vol[n]*100)+'%';
      return this.head(t('settings'))+`<div class="grid2 scroll"><div class="panel">${this.cyc('lang',t('lang'),{pt:'Português',en:'English',es:'Español'}[S.lang])}${this.cyc('gfx',t('gfx'),t('g_'+S.gfx)+(S.gfx==='auto'?' ('+t('g_'+GraphicsManager.q)+')':''))}${this.cyc('fps',t('fps'),S.fps)}${this.cyc('cam',t('cam'),t('c_'+S.cam))}${this.cyc('sdiff',t('diff'),t('d_'+DIFFS[S.diff]))}${this.cyc('vib',t('vib'),onoff(S.vib))}${this.cyc('ctl',t('ctl'),t('sw_'+S.ctl))}</div><div class="panel">${['music','fx','crowd','voice'].map(n=>this.cyc('vol_'+n,t(n),vol(n))).join('')}<div class="btns"><button class="btn" data-act="save">${t('save')}</button><button class="btn" data-act="load">${t('load')}</button><button class="btn red" data-act="reset">${t('reset')}</button></div></div></div>`;},
    result(){const r=this.res;if(!r)return'';const bar=(k,a,b)=>{const s=a+b||1;return`<div class="sb"><b>${a}</b><div><i style="width:${a/s*100}%"></i></div><b>${b}</b><small>${k}</small></div>`;};const gl=r.log.filter(e=>e.type==='goal');
      return`<div class="resbox"><h2>${t('full')}</h2><div class="big">${r.teams[0]} <b>${r.hs}</b> : <b>${r.as}</b> ${r.teams[1]}</div>${r.pen?`<small>${t('pk')}: ${r.pen}</small>`:''}<div class="goals">${gl.map(e=>`<span class="${e.team?'r':''}">${e.min}' ${e.name}</span>`).join('')||'—'}</div>${bar(t('possession')+' %',r.stats.poss[0],r.stats.poss[1])}${bar(t('shots'),r.stats.shots[0],r.stats.shots[1])}${bar(t('fouls'),r.stats.fouls[0],r.stats.fouls[1])}<button class="btn gold big" data-act="resCont">${t('cont')}</button></div>`;},
    pause(){const pv=this.v.pv;const M=MatchManager,T=M.teams[0];let b='';
      if(pv==='main')b=['resume:cont','form:formation','subs:subs','tac:tactics','set:settings','quit:quit'].map(x=>{const[a,k]=x.split(':');return`<button class="mbtn" data-act="pv_${a}">${k==='cont'?t('cont'):t(k)}</button>`;}).join('');
      else if(pv==='form')b=this.cyc('form',t('formation'),T.formation)+`<button class="btn" data-act="pv_main">${t('back')}</button>`;
      else if(pv==='tac')b=this.tacRows()+`<button class="btn" data-act="pv_main">${t('back')}</button>`;
      else if(pv==='set'){const S=SaveManager.data.settings;b=['music','fx','crowd','voice'].map(n=>this.cyc('vol_'+n,t(n),Math.round(S.vol[n]*100)+'%')).join('')+this.cyc('cam',t('cam'),t('c_'+S.cam))+this.cyc('gfx',t('gfx'),t('g_'+S.gfx))+this.cyc('fps',t('fps'),S.fps)+`<button class="btn" data-act="pv_main">${t('back')}</button>`;}
      else if(pv==='subs'){const on=T.players.filter(p=>!p.sent),so=this.v.subOut;b=`<small>${t('subs')}: ${T.subs}/${T.maxSubs}</small><div class="subs"><div>${on.map(p=>`<div class="brow r-${p.d.rar}${so===p?' sel':''}" data-act="subOut" data-i="${T.players.indexOf(p)}"><b>${Math.round(p.stam)}</b><u>${p.role}</u><span>${p.d.name}</span></div>`).join('')}</div><div>${T.bench.map((p,i)=>`<div class="brow r-${p.rar}" data-act="subIn" data-i="${i}"><b>${p.ovr}</b><u>${p.pos}</u><span>${p.name}</span></div>`).join('')}</div></div><button class="btn" data-act="pv_main">${t('back')}</button>`;}
      else if(pv==='quit')b=`<h3>${t('quit')}?</h3><button class="btn red big" data-act="quitYes">${t('yes')}</button><button class="btn big" data-act="pv_main">${t('no')}</button>`;
      return`<div class="pausebox"><h2>${t('paused')} · ${T.score} - ${M.teams[1].score}</h2><div class="scroll pbody">${b}</div></div>`;}
  },
  tourView(st,c,where){const v=this.v,tabs=(st.type==='league'?['table']:['fixtures']).concat(['results','scorers','assists']).map(k=>`<button class="tab${v.tab===k?' on':''}" data-tab="${k}">${t(k)}</button>`).join('');let tab=v.tab;if(st.type==='league'&&tab==='fixtures')tab='table';if(st.type!=='league'&&tab==='table')tab='fixtures';let body='';const nm=id=>getClub(id).short;
    if(tab==='table'){body=`<table class="tbl"><tr><th>#</th><th></th><th>P</th><th>J</th><th>V</th><th>E</th><th>D</th><th>SG</th></tr>${TournamentManager.sorted(st).map((id,i)=>{const r=st.table[id];return`<tr class="${id===st.user?'me':''}"><td>${i+1}</td><td>${shirt(getClub(id))} ${getClub(id).name}</td><td><b>${r.pts}</b></td><td>${r.p}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td><td>${r.gf-r.ga}</td></tr>`;}).join('')}</table>`;}
    else if(tab==='fixtures'){body=`<h4>${TournamentManager.roundName(st)}</h4>`+(st.finished?'':st.pairs.map(p=>`<div class="fx${p.h===st.user||p.a===st.user?' me':''}">${getClub(p.h).name} <b>x</b> ${getClub(p.a).name}</div>`).join(''));}
    else if(tab==='results')body=st.results.slice().reverse().slice(0,40).map(r=>`<div class="fx${r.h===st.user||r.a===st.user?' me':''}"><small>${r.r+1}</small> ${nm(r.h)} <b>${r.hs} - ${r.as}</b> ${nm(r.a)} <small>${r.pen}</small></div>`).join('')||'—';
    else body=`<table class="tbl">${TournamentManager.top(tab==='scorers'?st.scorers:st.assists,12).map((x,i)=>`<tr><td>${i+1}</td><td>${x.n} <small>${nm(x.c)}</small></td><td><b>${x.v}</b></td></tr>`).join('')||'<tr><td>—</td></tr>'}</table>`;
    const uf=TournamentManager.userFix(st);let act='';
    if(st.finished){act=`<div class="champ">🏆 ${t('champion')}: ${getClub(st.champion).name}</div>`+(where==='career'?`<button class="btn gold big" data-act="newSeason">${t('newseason')}</button>`:`<button class="btn gold" data-act="tourNew" data-k="${st.key}">${t('newcomp')}</button>`);}
    else act=(uf?`<button class="btn gold big" data-act="tourPlay" data-k="${st.key}">${t('playnext')}: ${getClub(uf.h).short} x ${getClub(uf.a).short}</button>`:'')+`<button class="btn" data-act="tourSim" data-k="${st.key}">${t('simround')}</button>`;
    return`<div class="tabs" data-tabs="tab">${tabs}</div><div class="scroll tbody">${body}</div><div class="actbar">${act}</div>`;},
  post(id){},
  /* ---------- ações ---------- */
  act(n,el){const sv=SaveManager.data,v=this.v,d=el.dataset;
    if(n.startsWith('pv_')){v.pv=n.slice(3);if(v.pv==='resume'){MatchManager.togglePause();return;}this.rerender();return;}
    switch(n){
      case'startQuick':this.startMatch({home:v.home,away:v.away,stadium:v.stad,weather:v.wea,diff:v.diff,dur:DURS[v.dur]},res=>{sv.money+=res.hs>res.as?250000:res.hs===res.as?100000:50000;SaveManager.save();this.go('quick');});break;
      case'train':this.startMatch({home:sv.myClub,away:pick(CLUBS.filter(c=>c.id!==sv.myClub)).id,stadium:0,weather:0,diff:0,dur:10,training:true},()=>this.go('menu'));break;
      case'save':this.toast(SaveManager.save()?t('saved'):'ERRO','info');break;
      case'load':if(SaveManager.has()){SaveManager.load();LANG=sv.settings.lang;AudioManager.applyVol();this.toast(t('loaded'),'info');this.rerender();}else this.toast(t('nosave'),'info');break;
      case'reset':SaveManager.reset();LANG='pt';AudioManager.applyVol();this.toast(t('resetd'),'info');this.rerender();break;
      case'captain':sv.captain=d.id;SaveManager.save();this.rerender();break;
      case'autoLineup':sv.lineup=autoLineup(SaveManager.squad(),sv.formation);SaveManager.save();this.rerender();break;
      case'pack':{const out=CardManager.open(+d.i);if(!out){this.toast('R$ ✕','foul');return;}this.snd('card');out.sort((a,b)=>a.ovr-b.ovr);v.reveal=out;this.rerender();break;}
      case'tourStart':{const c=COMPS[v.cc];const u=v.cclub||(c.teams().includes(sv.myClub)?sv.myClub:c.teams()[0]);TournamentManager.create(c.id,c.id,u);this.rerender();break;}
      case'tourNew':{delete sv.tour[d.k];SaveManager.save();this.rerender();break;}
      case'tourSim':{TournamentManager.playRound(TournamentManager.get(d.k),null);if(d.k==='career')CareerManager.afterRound(null);this.rerender();break;}
      case'tourPlay':{const st=TournamentManager.get(d.k),f=TournamentManager.userFix(st);if(!f)return;const opp=f.h===st.user?f.a:f.h;
        const pf=sv.myClub;if(st.user!==sv.myClub){/* usa clube escolhido com elenco gerado */}
        this.startMatch({home:st.user,away:opp,stadium:Math.floor(Math.random()*6),weather:pick([0,0,1,2,3]),diff:sv.settings.diff,dur:sv.settings.dur>=3?sv.settings.dur:5,cup:st.type==='cup'},res=>{TournamentManager.playRound(st,res);if(d.k==='career')CareerManager.afterRound(res);this.go(d.k==='career'?'career':'champs');});break;}
      case'careerStart':CareerManager.start(v.carclub||COMP[LEAGUE_COMP[v.carlg]].teams()[0]);this.rerender();break;
      case'newSeason':CareerManager.newSeason();this.rerender();break;
      case'buy':case'loan':if(!CareerManager.buy(d.id,n==='loan'))this.toast('R$ ✕','foul');this.rerender();break;
      case'sell':if(!CareerManager.sell(d.id))this.toast('≥16','foul');this.rerender();break;
      case'train1':if(!CareerManager.train(d.id))this.toast('R$ ✕','foul');this.rerender();break;
      case'subOut':v.subOut=MatchManager.teams[0].players[+d.i];this.rerender();break;
      case'subIn':{const T=MatchManager.teams[0];if(v.subOut&&!v.subOut.sent){if(MatchManager.substitute(T,v.subOut,T.bench[+d.i]))this.snd('select');v.subOut=null;this.rerender();}break;}
      case'quitYes':v.pv='main';MatchManager.paused=false;this.hidePause(true);MatchManager.quit();this.pendingEnd=null;this.go('menu');break;
      case'resCont':{const cb=this.pendingEnd,res=this.res;this.pendingEnd=null;MatchManager.quit();this.cur=null;this.hudShow(false);if(cb)cb(res);else this.go('menu');break;}
    }},
  /* ---------- partida ---------- */
  startMatch(cfg,onEnd){const sv=SaveManager.data;this.endDemo();this.pendingEnd=onEnd;this.hideAll();const ld=$('loading');$('lt').textContent=t('loading');$('tip').textContent=t('tip')+': '+pick(TIPS[LANG]);$('lbar').style.width='10%';ld.classList.add('show','in');AudioManager.music('off');AudioManager.quiet=false;
    let p=10;const iv=setInterval(()=>{p+=18;$('lbar').style.width=Math.min(p,100)+'%';},120);
    setTimeout(()=>{MatchManager.start(cfg);},300);setTimeout(()=>{clearInterval(iv);$('lbar').style.width='100%';ld.classList.remove('in');setTimeout(()=>ld.classList.remove('show'),300);},1100);},
  showResult(res){const M=MatchManager;if(M.cfg&&M.cfg.cup&&res.hs===res.as){const rh=M.teams[0].rating,ra=M.teams[1].rating;let x=0,y=0;for(let i=0;i<5;i++){if(Math.random()<.76)x++;if(Math.random()<.74)y++;}while(x===y){if(Math.random()<.75*(.5+rh/(rh+ra)/2))x++;if(Math.random()<.75*(1.5-rh/(rh+ra)/2))y++;}res.pen=x+'-'+y;res.penWin=x>y?0:1;
      /* empate em mata-mata: o vencedor nos pênaltis ganha 1 gol simbólico para o registro */ if(res.penWin===0)res.hs+=0;}
    this.res=res;this.hudShow(false);$('hud').classList.add('hidden');this.cur=null;let s=$('s-result');if(!s){s=document.createElement('section');s.id='s-result';s.className='screen';this.el.appendChild(s);}s.innerHTML=this.SCR.result.call(this);s.classList.add('show');requestAnimationFrame(()=>s.classList.add('in'));this.cur='result';this.snd('select');},
  showPause(){this.v.pv='main';this.v.subOut=null;this.cur='pause';let s=$('s-pause');if(!s){s=document.createElement('section');s.id='s-pause';s.className='screen';this.el.appendChild(s);}s.innerHTML=this.SCR.pause.call(this);s.classList.add('show');requestAnimationFrame(()=>s.classList.add('in'));$('touch').classList.add('hidden');},
  hidePause(force){const s=$('s-pause');if(s){s.classList.remove('in');setTimeout(()=>s.classList.remove('show'),250);}this.cur=null;if(MatchManager.active)this.hudShow(true);},
  /* ---------- HUD ---------- */
  hudShow(b){$('hud').classList.toggle('hidden',!b);const S=SaveManager.data.settings;const show=b&&(S.ctl==='on'||(S.ctl==='auto'&&InputManager.touch));$('touch').classList.toggle('hidden',!show);if(!b){$('toast').innerHTML='';$('replay').classList.add('hidden');}},
  hudNames(M){const a=M.teams[0],b=M.teams[1];$('sbH').innerHTML=shirt(a.kit)+a.club.short;$('sbA').innerHTML=b.club.short+shirt(b.kit);},
  hudUpdate(o){if($('sbHs').textContent!=o.hs)$('sbHs').textContent=o.hs;if($('sbAs').textContent!=o.as)$('sbAs').textContent=o.as;$('sbT').textContent=o.time;$('selN').textContent=o.sel;$('stam').firstElementChild.style.width=o.stam+'%';$('stam').firstElementChild.style.background=o.stam<30?'#ff4747':'#35d0ff';$('pow').classList.toggle('on',o.charge>.05);$('pow').firstElementChild.style.width=o.charge*100+'%';
    if(this.mode!==o.mode){this.mode=o.mode;const A=o.mode==='attack';const L=A?[t('pass'),t('shoot'),t('cross'),t('through')]:[t('tackle'),t('slide'),t('press'),t('keeper')];['bA','bB','bC','bD'].forEach((id,i)=>$(id).firstElementChild.textContent=L[i]);}},
  radar(M){const c=$('radar'),g=c.getContext('2d'),w=c.width,h=c.height;g.clearRect(0,0,w,h);g.fillStyle='rgba(6,20,14,.62)';g.fillRect(0,0,w,h);g.strokeStyle='rgba(255,255,255,.5)';g.strokeRect(3,3,w-6,h-6);g.beginPath();g.moveTo(w/2,3);g.lineTo(w/2,h-3);g.stroke();
    const X=x=>(x+HL)/PL*(w-6)+3,Z=z=>(z+HW)/68*(h-6)+3;M.teams.forEach(T=>{g.fillStyle=T.kit.c1;T.players.forEach(p=>{if(p.sent)return;g.beginPath();g.arc(X(p.x),Z(p.z),p===M.sel?3.6:2.4,0,7);g.fill();if(p===M.sel){g.strokeStyle='#35d0ff';g.stroke();}});});g.fillStyle='#fff';g.beginPath();g.arc(X(BallManager.pos.x),Z(BallManager.pos.z),2,0,7);g.fill();},
  toast(text,cls,ms){if(!text||(MatchManager.cfg&&MatchManager.cfg.demo&&MatchManager.active))return;const d=document.createElement('div');d.className='tst '+(cls||'');d.textContent=text;const box=$('toast');box.appendChild(d);if(box.children.length>3)box.removeChild(box.firstChild);setTimeout(()=>d.remove(),ms||1900);},
  goalBanner(name,min,club){if(MatchManager.cfg.demo)return;const d=document.createElement('div');d.className='goalb';d.innerHTML=`<h1>${t('goal')}</h1><p>${name}</p><small>${min}' · ${club}</small>`;$('toast').appendChild(d);setTimeout(()=>d.remove(),3500);},
  hint(txt){const h=$('hint');h.textContent=txt||'';h.classList.toggle('on',!!txt);},
  replayShow(b){if(MatchManager.cfg&&MatchManager.cfg.demo)return;$('replay').classList.toggle('hidden',!b);},
  /* ---------- Meu Time: arrastar jogadores ---------- */
  dragInit(){let src=null,sx=0,sy=0,moved=false,ghost=null;
    this.el.addEventListener('pointerdown',e=>{if(this.cur!=='myteam')return;const p=e.target.closest('[data-p]');if(!p)return;src=p;sx=e.clientX;sy=e.clientY;moved=false;});
    window.addEventListener('pointermove',e=>{if(!src)return;if(!moved&&Math.hypot(e.clientX-sx,e.clientY-sy)>10){moved=true;ghost=src.cloneNode(true);ghost.className+=' ghost';document.body.appendChild(ghost);src.style.opacity=.35;}if(ghost){ghost.style.left=e.clientX+'px';ghost.style.top=e.clientY+'px';}});
    window.addEventListener('pointerup',e=>{if(!src)return;const a=src.dataset.p;if(ghost){ghost.remove();ghost=null;}src.style.opacity='';const s=src;src=null;
      if(!moved){this.v.sel=a;this.snd('select');this.rerender();return;}
      const el=document.elementFromPoint(e.clientX,e.clientY),t2=el&&el.closest('[data-p]');if(t2&&t2.dataset.p!==a){const L=SaveManager.lineupIds(),i=L.indexOf(a),j=L.indexOf(t2.dataset.p);if(i>=0&&j>=0){L[i]=t2.dataset.p;L[j]=a;}else if(i>=0){L[i]=t2.dataset.p;}else if(j>=0){L[j]=a;}SaveManager.data.lineup=L;SaveManager.save();this.snd('select');}this.rerender();});}
};
