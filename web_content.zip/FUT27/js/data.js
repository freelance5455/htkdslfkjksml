'use strict';
/* ===== FUT27 · data.js · utilitários, idiomas, clubes, jogadores, formações ===== */
const clamp=(v,a,b)=>v<a?a:(v>b?b:v),lerp=(a,b,t)=>a+(b-a)*t,rnd=(a,b)=>a+Math.random()*(b-a),pick=a=>a[Math.floor(Math.random()*a.length)];
const wrapA=a=>{while(a>Math.PI)a-=Math.PI*2;while(a<-Math.PI)a+=Math.PI*2;return a;};
const money=v=>'R$ '+(v>=1e6?(v/1e6).toFixed(1)+' mi':Math.round(v/1e3)+' mil');

const I18N={
pt:{play:'JOGAR',myteam:'MEU TIME',champs:'CAMPEONATOS',career:'CARREIRA',training:'TREINO',settings:'CONFIGURAÇÕES',back:'◀ VOLTAR',start:'INICIAR PARTIDA',cont:'CONTINUAR',home:'Mandante',away:'Visitante',league:'Liga',club:'Clube',stadium:'Estádio',weather:'Clima',diff:'Dificuldade',dur:'Duração',formation:'Formação',mentality:'Mentalidade',pressure:'Pressão',line:'Linha defensiva',width:'Largura',attack:'Estilo de ataque',build:'Construção',compact:'Compactação',subs:'Substituições',tactics:'Táticas',quit:'Sair',save:'SALVAR',load:'CARREGAR',reset:'RESETAR DADOS',lang:'Idioma',gfx:'Gráficos',fps:'FPS',music:'Música',fx:'Efeitos',crowd:'Torcida',voice:'Narração',vib:'Vibração',cam:'Câmera',loading:'Carregando...',table:'Tabela',scorers:'Artilharia',assists:'Assistências',results:'Resultados',fixtures:'Jogos',playnext:'JOGAR PRÓXIMA',simround:'SIMULAR RODADA',market:'Mercado',squad:'Elenco',budget:'Caixa',objective:'Objetivo',season:'Temporada',captain:'Capitão',lineup:'Titulares',bench:'Reservas',packs:'Cartas',openpack:'Abrir pacote',auto:'AUTO',goal:'GOL!',half:'INTERVALO',full:'FIM DE JOGO',yellow:'CARTÃO AMARELO',red:'CARTÃO VERMELHO',foul:'FALTA',offside:'IMPEDIMENTO',corner:'ESCANTEIO',goalkick:'TIRO DE META',throwin:'LATERAL',penalty:'PÊNALTI',paused:'PAUSADO',pass:'PASSE',shoot:'CHUTE',cross:'CRUZAR',through:'ENFIADA',sprint:'SPRINT',switch:'TROCAR',tackle:'DESARME',slide:'CARRINHO',press:'PRESSÃO',keeper:'GOLEIRO',champion:'CAMPEÃO',on:'Ligado',off:'Desligado',saved:'Progresso salvo',loaded:'Progresso carregado',resetd:'Dados resetados',nosave:'Nenhum save encontrado',buy:'COMPRAR',sell:'VENDER',loan:'EMPRÉSTIMO',train:'TREINAR +1',newseason:'NOVA TEMPORADA',startcomp:'INICIAR COMPETIÇÃO',newcomp:'NOVA EDIÇÃO',ctl:'Controles na tela',rotate:'Gire o aparelho para o modo horizontal',nogl:'Seu navegador não suporta WebGL. Tente Chrome, Firefox ou Edge atualizados.',m_def:'Defensiva',m_norm:'Normal',m_off:'Ofensiva',m_vof:'Muito ofensiva',d_easy:'Fácil',d_normal:'Normal',d_hard:'Difícil',d_pro:'Profissional',d_legend:'Lenda',w_sunny:'Ensolarado',w_cloudy:'Nublado',w_rain:'Chuva',w_night:'Noite',l_low:'Baixa',l_mid:'Média',l_high:'Alta',a_wings:'Pelas pontas',a_mixed:'Misto',a_center:'Pelo meio',b_slow:'Lenta',b_mid:'Normal',b_fast:'Rápida',c_broadcast:'Transmissão',c_wide:'Aberta',c_dynamic:'Dinâmica',c_player:'Jogador',g_auto:'Automático',g_low:'Baixo',g_medium:'Médio',g_high:'Alto',g_ultra:'Ultra',sw_on:'Ligado',sw_off:'Desligado',sw_auto:'Automático',tip:'Dica',res:'Resultado',pk:'Pênaltis',yes:'SIM',no:'NÃO',rounds:'Rodada',myclub:'Seu clube',pickclub:'Escolher clube',stats:'Estatísticas',possession:'Posse',shots:'Finalizações',fouls:'Faltas',vs:'x'},
en:{play:'PLAY',myteam:'MY TEAM',champs:'TOURNAMENTS',career:'CAREER',training:'TRAINING',settings:'SETTINGS',back:'◀ BACK',start:'KICK OFF',cont:'CONTINUE',home:'Home',away:'Away',league:'League',club:'Club',stadium:'Stadium',weather:'Weather',diff:'Difficulty',dur:'Length',formation:'Formation',mentality:'Mentality',pressure:'Pressing',line:'Defensive line',width:'Width',attack:'Attack style',build:'Build-up',compact:'Compactness',subs:'Substitutions',tactics:'Tactics',quit:'Quit',save:'SAVE',load:'LOAD',reset:'RESET DATA',lang:'Language',gfx:'Graphics',fps:'FPS',music:'Music',fx:'Effects',crowd:'Crowd',voice:'Commentary',vib:'Vibration',cam:'Camera',loading:'Loading...',table:'Table',scorers:'Top scorers',assists:'Assists',results:'Results',fixtures:'Fixtures',playnext:'PLAY NEXT',simround:'SIMULATE ROUND',market:'Market',squad:'Squad',budget:'Budget',objective:'Objective',season:'Season',captain:'Captain',lineup:'Starters',bench:'Bench',packs:'Cards',openpack:'Open pack',auto:'AUTO',goal:'GOAL!',half:'HALF TIME',full:'FULL TIME',yellow:'YELLOW CARD',red:'RED CARD',foul:'FOUL',offside:'OFFSIDE',corner:'CORNER',goalkick:'GOAL KICK',throwin:'THROW-IN',penalty:'PENALTY',paused:'PAUSED',pass:'PASS',shoot:'SHOOT',cross:'CROSS',through:'THROUGH',sprint:'SPRINT',switch:'SWITCH',tackle:'TACKLE',slide:'SLIDE',press:'PRESS',keeper:'KEEPER',champion:'CHAMPION',on:'On',off:'Off',saved:'Progress saved',loaded:'Progress loaded',resetd:'Data reset',nosave:'No save found',buy:'BUY',sell:'SELL',loan:'LOAN',train:'TRAIN +1',newseason:'NEW SEASON',startcomp:'START COMPETITION',newcomp:'NEW EDITION',ctl:'On-screen controls',rotate:'Rotate your device to landscape',nogl:'Your browser does not support WebGL. Try an updated Chrome, Firefox or Edge.',m_def:'Defensive',m_norm:'Normal',m_off:'Attacking',m_vof:'All-out attack',d_easy:'Easy',d_normal:'Normal',d_hard:'Hard',d_pro:'Professional',d_legend:'Legend',w_sunny:'Sunny',w_cloudy:'Cloudy',w_rain:'Rain',w_night:'Night',l_low:'Low',l_mid:'Medium',l_high:'High',a_wings:'Down the wings',a_mixed:'Mixed',a_center:'Through the middle',b_slow:'Slow',b_mid:'Normal',b_fast:'Fast',c_broadcast:'Broadcast',c_wide:'Wide',c_dynamic:'Dynamic',c_player:'Player',g_auto:'Automatic',g_low:'Low',g_medium:'Medium',g_high:'High',g_ultra:'Ultra',sw_on:'On',sw_off:'Off',sw_auto:'Automatic',tip:'Tip',res:'Result',pk:'Penalties',yes:'YES',no:'NO',rounds:'Round',myclub:'Your club',pickclub:'Pick club',stats:'Stats',possession:'Possession',shots:'Shots',fouls:'Fouls',vs:'v'},
es:{play:'JUGAR',myteam:'MI EQUIPO',champs:'TORNEOS',career:'CARRERA',training:'ENTRENO',settings:'AJUSTES',back:'◀ VOLVER',start:'EMPEZAR',cont:'CONTINUAR',home:'Local',away:'Visitante',league:'Liga',club:'Club',stadium:'Estadio',weather:'Clima',diff:'Dificultad',dur:'Duración',formation:'Formación',mentality:'Mentalidad',pressure:'Presión',line:'Línea defensiva',width:'Anchura',attack:'Estilo de ataque',build:'Construcción',compact:'Compactación',subs:'Cambios',tactics:'Tácticas',quit:'Salir',save:'GUARDAR',load:'CARGAR',reset:'BORRAR DATOS',lang:'Idioma',gfx:'Gráficos',fps:'FPS',music:'Música',fx:'Efectos',crowd:'Afición',voice:'Narración',vib:'Vibración',cam:'Cámara',loading:'Cargando...',table:'Tabla',scorers:'Goleadores',assists:'Asistencias',results:'Resultados',fixtures:'Partidos',playnext:'JUGAR SIGUIENTE',simround:'SIMULAR JORNADA',market:'Mercado',squad:'Plantilla',budget:'Caja',objective:'Objetivo',season:'Temporada',captain:'Capitán',lineup:'Titulares',bench:'Suplentes',packs:'Cartas',openpack:'Abrir sobre',auto:'AUTO',goal:'¡GOL!',half:'DESCANSO',full:'FINAL',yellow:'TARJETA AMARILLA',red:'TARJETA ROJA',foul:'FALTA',offside:'FUERA DE JUEGO',corner:'CÓRNER',goalkick:'SAQUE DE META',throwin:'SAQUE DE BANDA',penalty:'PENAL',paused:'PAUSA',pass:'PASE',shoot:'TIRO',cross:'CENTRO',through:'PASE EN PROFUNDIDAD',sprint:'SPRINT',switch:'CAMBIAR',tackle:'ENTRADA',slide:'BARRIDA',press:'PRESIÓN',keeper:'PORTERO',champion:'CAMPEÓN',on:'Sí',off:'No',saved:'Progreso guardado',loaded:'Progreso cargado',resetd:'Datos borrados',nosave:'Sin partida guardada',buy:'COMPRAR',sell:'VENDER',loan:'CESIÓN',train:'ENTRENAR +1',newseason:'NUEVA TEMPORADA',startcomp:'INICIAR COMPETICIÓN',newcomp:'NUEVA EDICIÓN',ctl:'Controles en pantalla',rotate:'Gira el dispositivo a horizontal',nogl:'Tu navegador no soporta WebGL. Prueba Chrome, Firefox o Edge actualizados.',m_def:'Defensiva',m_norm:'Normal',m_off:'Ofensiva',m_vof:'Muy ofensiva',d_easy:'Fácil',d_normal:'Normal',d_hard:'Difícil',d_pro:'Profesional',d_legend:'Leyenda',w_sunny:'Soleado',w_cloudy:'Nublado',w_rain:'Lluvia',w_night:'Noche',l_low:'Baja',l_mid:'Media',l_high:'Alta',a_wings:'Por las bandas',a_mixed:'Mixto',a_center:'Por el centro',b_slow:'Lenta',b_mid:'Normal',b_fast:'Rápida',c_broadcast:'Retransmisión',c_wide:'Abierta',c_dynamic:'Dinámica',c_player:'Jugador',g_auto:'Automático',g_low:'Bajo',g_medium:'Medio',g_high:'Alto',g_ultra:'Ultra',sw_on:'Sí',sw_off:'No',sw_auto:'Automático',tip:'Consejo',res:'Resultado',pk:'Penales',yes:'SÍ',no:'NO',rounds:'Jornada',myclub:'Tu club',pickclub:'Elegir club',stats:'Estadísticas',possession:'Posesión',shots:'Tiros',fouls:'Faltas',vs:'v'}
};
let LANG='pt';
const t=k=>(I18N[LANG]&&I18N[LANG][k])||I18N.pt[k]||k;
const TIPS={pt:['Segure o botão de chute para dar mais força.','Use ENFIADA para achar o atacante nas costas da defesa.','Cuidado com o impedimento: espere o companheiro aparecer.','Pressione o botão PRESSÃO para chamar um companheiro à marcação.','Troque a formação no menu MEU TIME.','Abra pacotes de cartas para reforçar o elenco.','Chuva deixa a bola mais rápida no gramado molhado.'],en:['Hold the shoot button for more power.','Use THROUGH to find the striker behind the defense.','Watch for offside: wait for your teammate to show.','Hit PRESS to call a teammate to close down.','Change formation in MY TEAM.','Open card packs to strengthen your squad.','Rain makes the ball faster on a wet pitch.'],es:['Mantén el botón de tiro para más fuerza.','Usa PASE EN PROFUNDIDAD para encontrar al delantero.','Cuidado con el fuera de juego.','Pulsa PRESIÓN para llamar a un compañero.','Cambia la formación en MI EQUIPO.','Abre sobres de cartas para reforzar tu plantilla.','La lluvia hace la pelota más rápida.']};
const NARR={pt:{goal:['GOL!','É gol!','Gooooool!'],save:['Grande defesa!','Que defesa!'],pass:['Que passe!'],miss:['Ele perdeu!','Passou perto!'],chance:['Que oportunidade!','Perigo!'],post:['Na trave!'],foul:['Falta!'],card:['Cartão!']},en:{goal:['GOAL!','It is a goal!'],save:['Great save!','What a save!'],pass:['What a pass!'],miss:['He missed it!','So close!'],chance:['What a chance!','Danger!'],post:['Off the post!'],foul:['Foul!'],card:['Card!']},es:{goal:['¡GOL!','¡Goooool!'],save:['¡Gran parada!'],pass:['¡Qué pase!'],miss:['¡Lo perdió!','¡Cerca!'],chance:['¡Qué ocasión!','¡Peligro!'],post:['¡Al palo!'],foul:['¡Falta!'],card:['¡Tarjeta!']}};

/* ---------- RNG ---------- */
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let x=Math.imul(a^a>>>15,1|a);x=x+Math.imul(x^x>>>7,61|x)^x;return((x^x>>>14)>>>0)/4294967296;};}
function hashStr(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}

/* ---------- CLUBES (todos fictícios) ---------- */
const LEAGUES={BR:'Brasileirão',SA:'Sul-América',ENG:'Liga Inglesa',ESP:'Liga Espanhola',ITA:'Liga Italiana',GER:'Liga Alemã',FRA:'Liga Francesa',OTH:'Europa'};
const CLUB_RAW={
BR:[['Rio de Janeiro FC','RJF','#d62828','#111111',80],['Paulista FC','PAU','#f4f4f4','#111111',79],['Santos do Brasil','SAN','#eeeeee','#1b1b1b',74],['Minas FC','MIN','#1d4ed8','#ffffff',78],['Porto Alegre FC','POA','#38bdf8','#111111',77],['Bahia Azul','BAH','#2563eb','#dc2626',72],['Pernambuco FC','PER','#b91c1c','#111111',71],['Paraná Clube','PAR','#7f1d1d','#ffffff',70],['Goiás Verde','GOI','#16a34a','#ffffff',69],['Ceará Sporting','CEA','#161616','#ffffff',68],['Curitiba Atlético','CUR','#dc2626','#111111',73],['Belo Horizonte AC','BHA','#facc15','#111111',72],['Fortaleza Leões','FOR','#1e3a8a','#dc2626',70],['Manaus Amazônia','MAN','#15803d','#facc15',66],['Recife Naval','REC','#ef4444','#ffffff',67],['Brasília Capital','BRA','#fbbf24','#1d4ed8',68]],
SA:[['Buenos Aires FC','BUE','#38bdf8','#fde047',76],['Montevideo Celeste','MON','#60a5fa','#111111',70],['Santiago Andes','SCL','#dc2626','#ffffff',68],['Lima Sol','LIM','#f8fafc','#7f1d1d',66],['Bogotá Café','BOG','#7c2d12','#facc15',65],['Quito Altura','UIO','#facc15','#1e3a8a',64],['Asunción Guaraní','ASU','#b91c1c','#ffffff',66],['La Paz Cóndor','LPZ','#16a34a','#ffffff',63]],
ENG:[['Manchester Blue','MCB','#6cb4ee','#ffffff',86],['Manchester Red','MCR','#da291c','#ffffff',84],['London FC','LON','#1e3a8a','#ffffff',83],['Merseyside FC','MER','#c8102e','#ffffff',84],['Tyneside Stripes','TYN','#111111','#ffffff',76],['Birmingham Lions','BIR','#7a003c','#9bd8ff',72],['Leeds Rovers','LEE','#f8fafc','#facc15',71],['Brighton Gulls','BRI','#0057b8','#ffffff',72],['Foxborough City','FOX','#1d4ed8','#ffffff',70],['Northshire Town','NOR','#f97316','#111111',68]],
ESP:[['Madrid Royal','MAD','#f8fafc','#7c3aed',87],['Barcelona Athletic','BAR','#1e3a8a','#b91c1c',85],['Sevilla Nervión','SEV','#ffffff','#dc2626',77],['Valencia Bats','VAL','#f8fafc','#111111',74],['Bilbao Lions','BIL','#dc2626','#ffffff',73],['Atlético Capital','ATC','#dc2626','#1e3a8a',80],['San Sebastián Real','SSE','#2563eb','#ffffff',72],['Castellón Amarillo','CAS','#facc15','#1e3a8a',70],['Andalucía Verde','AND','#16a34a','#ffffff',70],['Zaragoza Rojo','ZAR','#b91c1c','#1e3a8a',66]],
ITA:[['Milan Rossoneri','MIL','#dc2626','#111111',80],['Milano Nerazzurri','NER','#1e3a8a','#111111',81],['Turin FC','TUR','#f8fafc','#111111',80],['Turin Granata','GRA','#7f1d1d','#ffffff',70],['Roma Giallorossi','ROM','#b91c1c','#facc15',76],['Napoli Partenopei','NAP','#38bdf8','#ffffff',78],['Genova Grifone','GEN','#1e3a8a','#dc2626',67],['Firenze Viola','FIR','#7c3aed','#ffffff',71],['Bologna Dotti','BOL','#dc2626','#1e3a8a',69],['Roma Celeste','LAZ','#7dd3fc','#ffffff',74]],
GER:[['Munich Red','MUN','#dc2626','#ffffff',86],['Dortmund Yellow','DOR','#facc15','#111111',80],['Leverkusen Werk','LEV','#111111','#dc2626',79],['Berlin Eisen','BER','#dc2626','#ffffff',72],['Hamburg Nord','HAM','#2563eb','#ffffff',68],['Cologne Goats','COL','#ffffff','#dc2626',68],['Frankfurt Adler','FRK','#111111','#dc2626',73],['Stuttgart Weiss','STU','#ffffff','#dc2626',72],['Wolfsburg Lobos','WOL','#16a34a','#ffffff',69],['Bremen Green','BRM','#15803d','#ffffff',66]],
FRA:[['Paris FC','PSF','#0b2a6f','#dc2626',85],['Marseille Phocéen','MRS','#7dd3fc','#ffffff',74],['Lyon Lion','LYO','#f8fafc','#1e3a8a',75],['Monaco Rock','MCO','#dc2626','#ffffff',76],['Lille Dogues','LIL','#b91c1c','#1e3a8a',72],['Nice Aigles','NIC','#dc2626','#111111',71],['Rennes Rouge','REN','#dc2626','#111111',70],['Lens Sang','LEN','#facc15','#dc2626',69],['Nantes Canari','NAN','#facc15','#16a34a',66],['Bordeaux Marine','BDX','#1e3a8a','#ffffff',65]],
OTH:[['Amsterdam FC','AMS','#f8fafc','#dc2626',77],['Rotterdam Haven','ROT','#dc2626','#ffffff',72],['Lisbon Eagles','LIS','#dc2626','#ffffff',76],['Porto Dragons','POR','#1e3a8a','#ffffff',76],['Brussels Royal','BRU','#7c3aed','#ffffff',68],['Istanbul Galata','IST','#facc15','#dc2626',70]]
};
const CLUBS=[];const CLUB={};
Object.keys(CLUB_RAW).forEach(lg=>CLUB_RAW[lg].forEach((c,i)=>{const o={id:c[1],name:c[0],short:c[1],league:lg,c1:c[2],c2:c[3],rating:c[4],rank:i};CLUBS.push(o);CLUB[o.id]=o;}));
const getClub=id=>CLUB[id];
const clubsOf=lg=>CLUBS.filter(c=>c.league===lg);
const LEAGUE_ORDER=['BR','ENG','ESP','ITA','GER','FRA','SA','OTH'];
const CAREER_LEAGUES=['BR','ENG','ESP','ITA','GER','FRA'];

/* ---------- JOGADORES ---------- */
const NAMES={
BR:[['Rafael','Lucas','Gabriel','Thiago','Matheus','Bruno','Felipe','Diego','Gustavo','Vinícius','Leandro','Caio','Henrique','Rodrigo','André','Marcelo','Daniel','Eduardo','João','Pedro','Carlos','Fábio','Renan','Igor','Murilo','Davi','Samuel','Wesley','Everton','Jonas'],['Silva','Santos','Oliveira','Souza','Lima','Pereira','Costa','Ribeiro','Almeida','Rocha','Barbosa','Carvalho','Gomes','Martins','Araújo','Ferreira','Nunes','Moreira','Teixeira','Cardoso']],
ENG:[['James','Harry','Jack','Oliver','Charlie','Tom','George','Callum','Reece','Mason','Jordan','Declan','Kyle','Ben','Luke'],['Walker','Hughes','Bennett','Foster','Clarke','Turner','Hayes','Murray','Cooper','Ward','Price','Fletcher','Dawson','Barnes','Griffin']],
ES:[['Alejandro','Javier','Sergio','Pablo','Álvaro','Iván','Raúl','Marcos','Adrián','Hugo','Diego','Mateo','Iker','Nacho','Borja'],['García','Martínez','López','Sánchez','Romero','Navarro','Ortega','Delgado','Ramos','Vidal','Herrera','Molina','Castro','Serrano','Cano']],
ITA:[['Marco','Luca','Matteo','Andrea','Federico','Lorenzo','Davide','Simone','Alessio','Gianluca'],['Rossi','Bianchi','Conti','Greco','Ferrari','Bruno','Gallo','Costa','Mancini','Rizzo','Moretti','Barbieri']],
GER:[['Lukas','Jonas','Felix','Leon','Maximilian','Tim','Jan','Niklas','Fabian','Moritz'],['Müller','Schneider','Fischer','Weber','Becker','Hoffmann','Koch','Richter','Wolf','Keller','Lange','Vogel']],
FRA:[['Hugo','Lucas','Théo','Maxime','Antoine','Romain','Julien','Baptiste','Yanis','Matthieu'],['Martin','Bernard','Dubois','Moreau','Laurent','Lefebvre','Girard','Faure','Mercier','Blanc','Roux','Fontaine']]
};
const NAME_KEY={BR:'BR',SA:'ES',ENG:'ENG',ESP:'ES',ITA:'ITA',GER:'GER',FRA:'FRA',OTH:'ENG'};
const NAT={BR:'Brasil',SA:'América do Sul',ENG:'Inglaterra',ESP:'Espanha',ITA:'Itália',GER:'Alemanha',FRA:'França',OTH:'Europa'};
const PROF={GK:[-22,-42,-22,-26,-34,-6],CB:[-10,-30,-12,-18,6,5],LB:[3,-22,-6,-6,-3,-2],RB:[3,-22,-6,-6,-3,-2],CDM:[-8,-18,0,-6,5,6],CM:[-4,-8,5,0,-8,0],CAM:[0,0,7,7,-26,-10],LM:[8,-4,0,7,-28,-10],RM:[8,-4,0,7,-28,-10],LW:[9,-2,0,8,-30,-11],RW:[9,-2,0,8,-30,-11],ST:[4,7,-10,3,-36,3]};
const FAMILY={GK:'G',CB:'D',LB:'D',RB:'D',CDM:'M',CM:'M',CAM:'M',LM:'M',RM:'M',LW:'A',RW:'A',ST:'A'};
const SKIN=['#f1c9a5','#e0ac7d','#c68642','#8d5524','#5c3a1e','#f7d9c4','#d9a273'];
const HAIRC=['#111111','#2b1b10','#5a3a1e','#c9a24a','#8a3b1d','#bdbdbd','#3b2a1a'];
const BOOTS=['#111111','#f5f5f5','#ff4d00','#00c2ff','#ffe600','#7cff00','#ff2bd6'];
const SQUAD_POS=['GK','CB','CB','LB','RB','CDM','CM','CM','LW','RW','ST','GK','CB','CB','RB','CM','CAM','LM','ST'];
const SQUAD_NUM=[1,4,5,3,2,6,8,10,11,7,9,12,13,15,16,14,17,18,19];
const rarityOf=o=>o>=89?'lenda':o>=83?'elite':o>=75?'ouro':o>=65?'prata':'bronze';
const RAR_NAME={bronze:'Bronze',prata:'Prata',ouro:'Ouro',elite:'Elite',lenda:'Lenda'};

function genPlayer(rng,club,pos,ovr,num,id){
  const nk=(rng()<0.12&&club.league!=='BR'&&club.league!=='SA')?'BR':(NAME_KEY[club.league]||'ES');const pool=NAMES[nk];
  const name=pool[0][Math.floor(rng()*pool[0].length)]+' '+pool[1][Math.floor(rng()*pool[1].length)];
  const pr=PROF[pos],st=pr.map(o=>clamp(Math.round(ovr+o+rng()*8-4),25,97));
  const br=(club.league==='BR'||club.league==='SA'),skin=SKIN[Math.floor(rng()*(br?7:6))];
  return {id,name,num,pos,ovr,club:club.id,nat:nk==='BR'?'Brasil':NAT[club.league],age:17+Math.floor(rng()*10+rng()*10),pac:st[0],sho:st[1],pas:st[2],dri:st[3],def:st[4],phy:st[5],
    h:pos==='GK'?1.84+rng()*.1:pos==='CB'?1.80+rng()*.1:1.67+rng()*.2,build:.92+rng()*.22,skin,hairC:HAIRC[Math.floor(rng()*HAIRC.length)],hair:Math.floor(rng()*6),boot:BOOTS[Math.floor(rng()*BOOTS.length)],rar:rarityOf(ovr)};
}
const _sq={};
function genSquad(clubId){
  if(_sq[clubId])return _sq[clubId];const club=CLUB[clubId],rng=mulberry(hashStr(clubId));const arr=[];
  SQUAD_POS.forEach((pos,i)=>{const starter=i<11;const o=clamp(Math.round(club.rating+(rng()+rng()-1)*9-(starter?0:7)),46,93);arr.push(genPlayer(rng,club,pos,o,SQUAD_NUM[i],clubId+i));});
  return _sq[clubId]=arr;
}
function deriveAttrs(p){return{speed:p.pac,accel:Math.round(p.pac*.9+p.phy*.1),stamina:Math.round(p.phy*.7+p.pac*.3),strength:p.phy,balance:Math.round((p.dri+p.phy)/2),control:Math.round(p.dri*.7+p.pas*.3),passing:p.pas,crossing:Math.round(p.pas*.6+p.dri*.4),finishing:p.sho,heading:Math.round((p.phy+p.sho)/2),marking:p.def,tackling:Math.round(p.def*.9+p.phy*.1),positioning:Math.round((p.sho+p.def+p.pas)/3+(p.pos==='ST'?12:0)),reaction:Math.round(p.ovr*.9+p.pac*.1),intelligence:Math.round(p.pas*.4+p.def*.2+p.ovr*.4),aggression:Math.round(p.phy*.5+p.def*.5)};}
const LEGENDS=[['Zé Rei do Gol','ST',94,'Brasil'],['Mestre Armando','CAM',93,'Brasil'],['El Mago Lucero','CAM',93,'Argentina'],['Il Muro Rossi','CB',92,'Itália'],['Der Kaiser Brandt','CB',92,'Alemanha'],['Pantera Negra','LW',92,'Brasil'],['Sir Arthur Vane','CM',91,'Inglaterra'],['El Gato Ibáñez','GK',91,'Espanha'],['Lord Fontaine','ST',90,'França'],['Capitão Duarte','RB',90,'Brasil']];
function makeLegend(i){const L=LEGENDS[i%LEGENDS.length],rng=mulberry(hashStr(L[0])),pr=PROF[L[1]];const st=pr.map(o=>clamp(L[2]+o+Math.round(rng()*4-1),30,99));
  return{id:'LEG'+i,name:L[0],num:10,pos:L[1],ovr:L[2],club:'LEG',nat:L[3],age:34,pac:st[0],sho:st[1],pas:st[2],dri:st[3],def:st[4],phy:st[5],h:1.78,build:1,skin:SKIN[Math.floor(rng()*6)],hairC:'#bdbdbd',hair:1,boot:'#ffe600',rar:'lenda',card:true};}
const teamRating=squad=>Math.round(squad.slice().sort((a,b)=>b.ovr-a.ovr).slice(0,11).reduce((s,p)=>s+p.ovr,0)/11);
const priceOf=p=>p.ovr<60?3e5:Math.round(Math.pow(p.ovr-55,3)*350);

/* ---------- FORMAÇÕES (fx: 0 gol próprio → 1 gol rival; fz: -1 esquerda … 1 direita) ---------- */
const FORMS={
'4-3-3':[['GK',.03,0],['LB',.22,-.82],['CB',.2,-.28],['CB',.2,.28],['RB',.22,.82],['CM',.46,-.42],['CDM',.38,0],['CM',.46,.42],['LW',.74,-.78],['ST',.82,0],['RW',.74,.78]],
'4-4-2':[['GK',.03,0],['LB',.22,-.82],['CB',.2,-.28],['CB',.2,.28],['RB',.22,.82],['LM',.5,-.8],['CM',.44,-.25],['CM',.44,.25],['RM',.5,.8],['ST',.8,-.22],['ST',.8,.22]],
'4-2-3-1':[['GK',.03,0],['LB',.22,-.82],['CB',.2,-.28],['CB',.2,.28],['RB',.22,.82],['CDM',.38,-.25],['CDM',.38,.25],['LW',.62,-.7],['CAM',.62,0],['RW',.62,.7],['ST',.82,0]],
'4-3-1-2':[['GK',.03,0],['LB',.22,-.82],['CB',.2,-.28],['CB',.2,.28],['RB',.22,.82],['CM',.42,-.4],['CDM',.38,0],['CM',.42,.4],['CAM',.62,0],['ST',.8,-.2],['ST',.8,.2]],
'3-5-2':[['GK',.03,0],['CB',.2,-.4],['CB',.18,0],['CB',.2,.4],['LM',.5,-.88],['CM',.44,-.3],['CDM',.38,0],['CM',.44,.3],['RM',.5,.88],['ST',.8,-.2],['ST',.8,.2]],
'3-4-3':[['GK',.03,0],['CB',.2,-.4],['CB',.18,0],['CB',.2,.4],['LM',.48,-.85],['CM',.44,-.2],['CM',.44,.2],['RM',.48,.85],['LW',.76,-.7],['ST',.82,0],['RW',.76,.7]],
'5-3-2':[['GK',.03,0],['LB',.3,-.88],['CB',.2,-.4],['CB',.18,0],['CB',.2,.4],['RB',.3,.88],['CM',.44,-.35],['CDM',.38,0],['CM',.44,.35],['ST',.8,-.2],['ST',.8,.2]]
};
const FORM_KEYS=Object.keys(FORMS);
function fitScore(pos,role){if(pos===role)return 10;if(FAMILY[pos]===FAMILY[role]){const w={LB:'RB',RB:'LB',LW:'RW',RW:'LW',LM:'RM',RM:'LM'};return w[pos]===role?7:(['CM','CDM','CAM'].includes(pos)&&['CM','CDM','CAM'].includes(role)?8:(['LW','RW','LM','RM'].includes(pos)&&['LW','RW','LM','RM'].includes(role)?8:6));}return 1;}
function autoLineup(squad,form){const used=new Set(),ids=[];const sl=FORMS[form];
  sl.forEach(s=>{let best=null,bs=-1;squad.forEach(p=>{if(used.has(p.id))return;const sc=fitScore(p.pos,s[0])*100+p.ovr;if(sc>bs){bs=sc;best=p;}});used.add(best.id);ids.push(best.id);});return ids;}

/* ---------- ESTÁDIOS / CLIMA ---------- */
const STADIUMS=[
{name:'Royal Arena',stand:'#8b929c',crowd:['#d62828','#ffffff','#1d4ed8','#facc15'],roof:true,trim:'#f0b429',ad:0},
{name:'Rio Stadium',stand:'#a0a7ad',crowd:['#16a34a','#facc15','#ffffff','#1d4ed8'],roof:true,trim:'#16a34a',ad:2},
{name:'Capital Arena',stand:'#6b7280',crowd:['#7c3aed','#ffffff','#111111','#f97316'],roof:false,trim:'#7c3aed',ad:4},
{name:'Metropolitan Stadium',stand:'#4b5563',crowd:['#38bdf8','#ffffff','#dc2626','#111111'],roof:true,trim:'#38bdf8',ad:1},
{name:'Liberty Park',stand:'#9ca3af',crowd:['#dc2626','#1e3a8a','#ffffff','#facc15'],roof:false,trim:'#dc2626',ad:3},
{name:'Grand Arena',stand:'#374151',crowd:['#f0b429','#111111','#ffffff','#16a34a'],roof:true,trim:'#f0b429',ad:5}];
const WEATHERS=['sunny','cloudy','rain','night'];
const DIFFS=['easy','normal','hard','pro','legend'];
/* dificuldade: atraso de reação, acerto de decisão, disciplina tática, pressão, qualidade do goleiro, precisão de passe */
const DIFFCFG=[{react:.7,dec:.55,disc:.55,press:.5,gk:-.10,acc:1.5},{react:.5,dec:.7,disc:.7,press:.7,gk:0,acc:1.15},{react:.35,dec:.82,disc:.82,press:.85,gk:.04,acc:1},{react:.22,dec:.92,disc:.92,press:1,gk:.08,acc:.85},{react:.12,dec:1,disc:1,press:1.15,gk:.12,acc:.7}];
const MENTS=['def','norm','off','vof'];

/* ---------- COMPETIÇÕES ---------- */
const ids=(lg,a,b)=>clubsOf(lg).slice(a,b).map(c=>c.id);
const COMPS=[
{id:'bra',name:'Brasileirão',type:'league',teams:()=>ids('BR',0,10),prize:4e6},
{id:'cdb',name:'Copa do Brasil',type:'cup',teams:()=>ids('BR',0,16),prize:3e6},
{id:'lib',name:'Libertadores',type:'cup',teams:()=>[...ids('BR',0,8),...ids('SA',0,8)],prize:5e6},
{id:'ucl',name:'Champions League',type:'cup',teams:()=>[...ids('ENG',0,4),...ids('ESP',0,3),...ids('ITA',0,3),...ids('GER',0,3),...ids('FRA',0,2),'LIS'],prize:8e6},
{id:'uel',name:'Europa League',type:'cup',teams:()=>[...ids('ENG',4,8),...ids('ESP',3,6),...ids('ITA',3,6),...ids('GER',3,5),...ids('FRA',2,4),'AMS'],prize:5e6},
{id:'mun',name:'Mundial de Clubes',type:'cup',teams:()=>['RJF','PAU','BUE','MCB','MAD','MUN','MIL','PSF'],prize:7e6},
{id:'eng',name:'Liga Inglesa',type:'league',teams:()=>ids('ENG',0,10),prize:5e6},
{id:'esp',name:'Liga Espanhola',type:'league',teams:()=>ids('ESP',0,10),prize:5e6},
{id:'ita',name:'Liga Italiana',type:'league',teams:()=>ids('ITA',0,10),prize:5e6},
{id:'ger',name:'Liga Alemã',type:'league',teams:()=>ids('GER',0,10),prize:5e6},
{id:'fra',name:'Liga Francesa',type:'league',teams:()=>ids('FRA',0,10),prize:5e6}];
const COMP={};COMPS.forEach(c=>COMP[c.id]=c);
const LEAGUE_COMP={BR:'bra',ENG:'eng',ESP:'esp',ITA:'ita',GER:'ger',FRA:'fra'};
