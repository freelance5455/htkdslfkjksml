'use strict';
/* ===== FUT27 · match.js · BallManager, TeamManager, AIManager, MatchManager ===== */
const randn=()=>(Math.random()+Math.random()+Math.random()-1.5)*.8;
const BallManager={
  pos:{x:0,y:BRAD,z:0},vel:{x:0,y:0,z:0},spin:0,owner:null,last:null,lastTeam:0,mesh:null,blob:null,shot:null,wet:false,passer:null,passerT:0,px:0,
  init(scene){const c=document.createElement('canvas');c.width=128;c.height=64;const g=c.getContext('2d');g.fillStyle='#f4f4f0';g.fillRect(0,0,128,64);g.fillStyle='#161616';for(let i=0;i<8;i++){const x=i*16+8,y=i%2?20:44;g.beginPath();for(let k=0;k<5;k++){const a=k/5*6.283-1.57;g.lineTo(x+Math.cos(a)*7,y+Math.sin(a)*7);}g.fill();}
    const tx=new THREE.CanvasTexture(c);tx.encoding=THREE.sRGBEncoding;this.mesh=new THREE.Mesh(new THREE.SphereGeometry(BRAD,14,10),new THREE.MeshStandardMaterial({map:tx,roughness:.5}));this.mesh.castShadow=true;scene.add(this.mesh);
    this.blob=new THREE.Mesh(new THREE.CircleGeometry(.3,10),new THREE.MeshBasicMaterial({color:0,transparent:true,opacity:.35,depthWrite:false}));this.blob.rotation.x=-Math.PI/2;scene.add(this.blob);},
  place(x,z){this.pos.x=x;this.pos.y=BRAD;this.pos.z=z;this.vel.x=this.vel.y=this.vel.z=0;this.spin=0;this.owner=null;this.shot=null;this.px=x;},
  step(dt){if(this.owner)return null;const v=this.vel,p=this.pos;let ev=null;this.px=p.x;
    v.y-=9.81*dt;const dr=Math.exp(-.12*dt);v.x*=dr;v.z*=dr;if(this.spin){const ox=v.x;v.x+=-this.spin*v.z*.05*dt;v.z+=this.spin*ox*.05*dt;this.spin*=Math.exp(-.7*dt);}
    p.x+=v.x*dt;p.y+=v.y*dt;p.z+=v.z*dt;
    if(p.y<BRAD){p.y=BRAD;if(v.y<-1.6){const s=Math.min(1,-v.y/10);v.y=-v.y*.6;v.x*=.93;v.z*=.93;AudioManager.sfx('bounce',s);ev='bounce';}else v.y=0;}
    if(p.y<=BRAD+.01&&Math.abs(v.y)<.6){const f=Math.exp(-(this.wet?.42:.55)*dt);v.x*=f;v.z*=f;const s=Math.hypot(v.x,v.z);if(s>0){const d=Math.min(s,.4*dt);v.x-=v.x/s*d;v.z-=v.z/s*d;}}
    for(const s of[-1,1]){const gx=s*HL;
      if(p.y<GHGT+.1)for(const pz of[-GH,GH]){const dx=p.x-gx,dz=p.z-pz,d=Math.hypot(dx,dz);if(d<BRAD+.07&&d>0){const nx=dx/d,nz=dz/d,vn=v.x*nx+v.z*nz;if(vn<0){v.x-=1.65*vn*nx;v.z-=1.65*vn*nz;p.x=gx+nx*(BRAD+.08);p.z=pz+nz*(BRAD+.08);ev='post';}}}
      if(Math.abs(p.z)<GH){const dx=p.x-gx,dy=p.y-GHGT,d=Math.hypot(dx,dy);if(d<BRAD+.07&&d>0){const nx=dx/d,ny=dy/d,vn=v.x*nx+v.y*ny;if(vn<0){v.x-=1.6*vn*nx;v.y-=1.6*vn*ny;p.x=gx+nx*(BRAD+.08);p.y=GHGT+ny*(BRAD+.08);ev='post';}}}
      if(s*p.x>HL&&Math.abs(p.z)<GH+.3&&p.y<GHGT+.4){const f=Math.exp(-3.2*dt);v.x*=f;v.z*=f;if(s*p.x>HL+2.2-BRAD){p.x=s*(HL+2.2-BRAD);v.x*=-.12;if(!this.netT||performance.now()-this.netT>400){AudioManager.sfx('net');this.netT=performance.now();}}if(Math.abs(p.z)>GH-BRAD){p.z=Math.sign(p.z)*(GH-BRAD);v.z*=-.2;}if(p.y>GHGT-BRAD&&p.y<GHGT+.3){p.y=GHGT-BRAD;v.y=-Math.abs(v.y)*.2;}}}
    return ev;},
  sync(dt){const m=this.mesh,p=this.pos;m.position.set(p.x,p.y,p.z);const sp=Math.hypot(this.vel.x,this.vel.z);if(sp>.05&&!this.owner){const a=sp*dt/BRAD;m.rotateOnWorldAxis(new THREE.Vector3(this.vel.z,0,-this.vel.x).normalize(),a);}
    this.blob.position.set(p.x,.03,p.z);this.blob.scale.setScalar(Math.max(.4,1.2-p.y*.12));this.blob.visible=!GraphicsManager.profile().shadow;}
};

const MatchManager={
  active:false,state:'none',cfg:null,teams:[],all:[],gmin:0,clk:0,half:1,t:0,ref:null,paused:false,rs:null,sel:null,ring:null,arrow:null,rec:[],recI:0,recN:0,rp:null,hudT:0,radarT:0,dead:null,off:null,res:null,goalInfo:null,log:[],selT:0,tick:0,coachT:0,hint:0,tmp:{},
  activeCount(){return this.all.length;},
  DC(){return DIFFCFG[this.cfg?this.cfg.diff:1];},
  /* ---------------- criação ---------------- */
  start(cfg){this.cleanup();const sv=SaveManager.data;this.cfg=cfg;LANG=sv.settings.lang;
    this.teams=[this.buildTeam(0,cfg.home),this.buildTeam(1,cfg.away)];
    const t0=this.teams[0],t1=this.teams[1];t1.kit=this.pickKit(t0.kit,getClub(cfg.away));
    this.teams.forEach(T=>{T.players.forEach((p,i)=>this.spawn(p,T,i));});
    World.kitC=[t0.kit.c1,t1.kit.c1];World.applyStadium(cfg.stadium,World.kitC);World.applyWeather(WEATHERS[cfg.weather]);BallManager.wet=WEATHERS[cfg.weather]==='rain';
    this.ref=PlayerManager.build({h:1.75,build:1,skin:'#d9a273',hairC:'#111',hair:1,boot:'#111'},{c1:'#f0e040',c2:'#111111',sock:'#111111'},{ref:true});this.ref.x=0;this.ref.z=10;World.scene.add(this.ref.root);this.ref.root.traverse(m=>{if(m.isMesh)m.castShadow=false;});
    this.ring=new THREE.Mesh(PlayerManager.G.ring,new THREE.MeshBasicMaterial({color:0x35d0ff,side:THREE.DoubleSide,transparent:true,opacity:.9}));this.ring.rotation.x=-Math.PI/2;this.ring.position.y=.06;World.scene.add(this.ring);
    this.arrow=new THREE.Mesh(PlayerManager.G.arrow,new THREE.MeshBasicMaterial({color:0x35d0ff}));this.arrow.rotation.x=Math.PI;World.scene.add(this.arrow);
    this.refreshAll();this.gmin=0;this.clk=0;this.half=1;this.log=[];this.rec=[];this.recI=0;this.recN=0;this.res=null;this.paused=false;this.off=null;this.ending=false;
    this.dur=cfg.training?999:cfg.dur;this.active=true;this.state='intro';this.t=0;this.kickoffTeam=0;this.setupKickoff(0,true);this.state='intro';this.introT=0;this.sel=this.pickSel();
    CameraManager.mode=sv.settings.cam;CameraManager.fx=0;CameraManager.fz=0;CameraManager.snap();
    UI.hudShow(true);UI.hudNames(this);AudioManager.music('off');AudioManager.sfx('trans');this.updateScoreboard();InputManager.clear();},
  buildTeam(idx,clubId){const sv=SaveManager.data,club=getClub(clubId);let squad,ids,form,tac;
    if(clubId===sv.myClub){squad=SaveManager.squad();ids=SaveManager.lineupIds();form=sv.formation;tac=Object.assign({},sv.tac);}
    else{squad=genSquad(clubId);form=pick(['4-3-3','4-4-2','4-2-3-1','4-3-3','3-5-2','4-3-1-2']);ids=autoLineup(squad,form);tac={ment:1,press:club.rating>78?2:1,line:1,width:1,att:1,build:1,compact:1};}
    const starters=ids.map(id=>squad.find(p=>p.id===id));const rest=squad.filter(p=>!ids.includes(p.id)).sort((a,b)=>b.ovr-a.ovr);const gk=rest.find(p=>p.pos==='GK');let bench=rest.filter(p=>p!==gk).slice(0,gk?6:7);if(gk)bench.unshift(gk);
    return{idx,club,kit:{c1:club.c1,c2:club.c2,sock:club.c1},gkc:idx?'#35d0ff':'#f0b429',players:starters.map(d=>({d})),bench,formation:form,tac,dir:idx?-1:1,human:idx===0&&!this.cfg.cpuOnly,score:0,subs:0,maxSubs:5,shots:0,onT:0,fouls:0,yel:0,red:0,corners:0,poss:0,pressCall:0,gkRush:0,off:0,chasers:[],gk:null,coach:{t:0,mode:''},rating:teamRating(squad),captain:idx===0?sv.captain:null};},
  pickKit(k0,club){const dist=(a,b)=>{const A=new THREE.Color(a),B=new THREE.Color(b);return Math.hypot(A.r-B.r,A.g-B.g,A.b-B.b);};let c1=club.c1,c2=club.c2;if(dist(k0.c1,c1)<.55){c1=club.c2;c2=club.c1;if(dist(k0.c1,c1)<.55)c1=dist(k0.c1,'#ffffff')>.6?'#ffffff':'#111111';}return{c1,c2,sock:c1};},
  spawn(slotObj,T,i){const d=slotObj.d,s=FORMS[T.formation][i];Object.assign(slotObj,{team:T,slot:s,role:s[0],x:0,z:0,vx:0,vz:0,yaw:T.dir>0?Math.PI/2:-Math.PI/2,stam:100,cool:0,act:'',actT:0,actD:0,actV:0,ph:Math.random()*6,spdN:0,stun:0,think:Math.random()*.3,tx:0,tz:0,a:deriveAttrs(d),sent:false,yel:0,kq:null,shield:false,lean:0,sprint:false,hold:0,sl:null,lsp:0,gkDive:0});
    const kit=d.pos==='GK'?{c1:T.gkc,c2:'#111111',sock:T.gkc}:T.kit;const b=PlayerManager.build(d,kit);slotObj.mesh=b.root;slotObj.parts=b.parts;World.scene.add(b.root);if(d.pos==='GK'&&slotObj.role==='GK')T.gk=slotObj;},
  refreshAll(){this.all=[];this.teams.forEach(T=>T.players.forEach(p=>{if(!p.sent)this.all.push(p);}));this.rec=[];this.recN=0;},
  cleanup(){if(!World.scene)return;BallManager.place(0,0);BallManager.sync(0);this.teams.forEach(T=>T.players.forEach(p=>{World.scene.remove(p.mesh);}));if(this.ref)World.scene.remove(this.ref.root);if(this.ring)World.scene.remove(this.ring);if(this.arrow)World.scene.remove(this.arrow);this.teams=[];this.all=[];this.ref=null;this.active=false;this.state='none';this.rs=null;this.rp=null;this.sel=null;BallManager.owner=null;BallManager.mesh.visible=true;},
  refreshShadows(){const sh=GraphicsManager.profile().shadow;this.all.forEach(p=>{p.mesh.traverse(m=>{if(m.isMesh&&m!==p.parts.blob)m.castShadow=sh&&GraphicsManager.profile().detail>=1;});p.parts.blob.visible=!sh;});},
  /* ---------------- posicionamento ---------------- */
  ax(T,fx){return T.dir*(-HL+fx*PL);},az(T,fz){return T.dir*fz*HW*.9;},
  setupKickoff(takeIdx,hard){const b=BallManager;this.teams.forEach(T=>{T.players.forEach(p=>{if(p.sent)return;const fx=Math.min(p.slot[1],.47),x=this.ax(T,fx),z=this.az(T,p.slot[2]);p.x=x;p.z=z;p.vx=p.vz=0;p.act='';p.stun=0;p.kq=null;p.sl=null;p.yaw=T.dir>0?Math.PI/2:-Math.PI/2;});});
    const T=this.teams[takeIdx];let tk=null,bd=99;T.players.forEach(p=>{if(p.sent||p.role==='GK')return;const d=Math.hypot(p.x,p.z)-(p.role==='ST'?5:0);if(d<bd){bd=d;tk=p;}});tk.x=-T.dir*.7;tk.z=0;
    {const OT=this.teams[1-takeIdx];OT.players.forEach(p=>{if(p.sent)return;if(Math.hypot(p.x,p.z)<10.5){p.x=-OT.dir*10.8;}});}
    b.place(0,0);this.beginRestart({type:'kickoff',team:takeIdx,x:0,z:0,taker:tk,delay:1.4,hold:true});},
  beginRestart(rs){const b=BallManager,tk=rs.taker;this.rs=rs;rs.t=0;this.state='restart';this.off=null;b.owner=tk;b.last=tk;b.lastTeam=tk.team.idx;b.shot=null;tk.hold=0;tk.cool=0;
    if(rs.type==='throw'){tk.act='throwhold';tk.actD=0;}
    this.pickSelFor(tk.team);if(rs.type==='penalty')this.setupPenalty(rs);else if(rs.type!=='kickoff'){this.clearZone(rs);}
    this.hint=3;UI.hint(this.hintText(rs));},
  hintText(rs){return{kickoff:'',throw:t('throwin'),corner:t('corner'),goalkick:t('goalkick'),freekick:t('foul'),penalty:t('penalty')}[rs.type]||'';},
  clearZone(rs){const opp=this.teams[1-rs.team];opp.players.forEach(p=>{if(p.sent||p.role==='GK'&&rs.type==='goalkick')return;const dx=p.x-rs.x,dz=p.z-rs.z,d=Math.hypot(dx,dz);if(rs.type==='goalkick'){const o=this.teams[rs.team];if(Math.abs(p.x)>HL-17&&Math.abs(p.z)<21&&Math.sign(p.x)===Math.sign(rs.x)){p.x=Math.sign(rs.x)*(HL-22);}return;}if(d<9.4){const a=d>.1?Math.atan2(dz,dx):0;p.x=rs.x+Math.cos(a)*9.6;p.z=rs.z+Math.sin(a)*9.6;}});},
  setupPenalty(rs){const T=this.teams[rs.team],O=this.teams[1-rs.team],gx=T.dir*HL,px=gx-T.dir*11;rs.x=px;rs.z=0;const b=BallManager;b.place(px,0);const tk=rs.taker;tk.x=px-T.dir*1.5;tk.z=0;tk.yaw=T.dir>0?Math.PI/2:-Math.PI/2;b.owner=tk;let i=0;
    this.all.forEach(p=>{if(p===tk||p===O.gk)return;p.x=gx-T.dir*(19+(i%4)*1.1);p.z=(i-5)*3.1;i++;p.vx=p.vz=0;});if(O.gk){O.gk.x=gx;O.gk.z=0;O.gk.vx=O.gk.vz=0;}rs.delay=2;rs.pen=true;},
  /* ---------------- seleção do jogador humano ---------------- */
  pickSel(){return this.pickSelFor(this.teams[0],true);},
  pickSelFor(T,ret){if(!T.human)return null;const b=BallManager;let best=null;
    if(b.owner&&b.owner.team===T)best=b.owner;else{let bd=1e9;T.players.forEach(p=>{if(p.sent||p.role==='GK'&&b.pos.x*T.dir>-HL+20)return;const d=Math.hypot(p.x-b.pos.x-b.vel.x*.4,p.z-b.pos.z-b.vel.z*.4);if(d<bd){bd=d;best=p;}});}
    if(best){this.sel=best;}return best;},
  /* ---------------- UPDATE principal ---------------- */
  update(dt){if(!this.active||this.paused)return;dt=Math.min(dt,.05);this.t+=dt;this.tick++;InputManager.poll();
    if(this.state==='replay'){this.updateReplay(dt);return;}
    const b=BallManager;
    if(this.state==='intro'){this.introT=(this.introT||0)+dt;if(this.introT>2.6){this.introT=0;this.state='restart';AudioManager.sfx('whistle');AudioManager.music('off');UI.hint('');}this.animateAll(dt,true);this.cameraStep(dt,this.introSpecial());this.syncAll(dt);return;}
    if(this.state==='play'||this.state==='restart'){this.clk+=dt;this.gmin=this.clk*(90/(this.dur*60));if(!this.cfg.training){if(this.half===1&&this.gmin>=45)return this.halfTime();if(this.gmin>=90)this.ending=true;}}
    if(this.state==='dead'){this.dead.t-=dt;if(this.dead.t<=0){const f=this.dead.fn;this.dead=null;f();}}
    if(this.state==='goal'){this.goalInfo.t-=dt;if(this.goalInfo.t<=0)this.finishGoal();}
    if(this.state==='halftime'){this.timer-=dt;if(this.timer<=0){this.half=2;this.state='restart';this.setupKickoff(1,true);AudioManager.sfx('whistle');}}
    if(this.state==='full'){this.animateAll(dt,true);this.cameraStep(dt,null);this.syncAll(dt);return;}
    this.snapshotT=(this.snapshotT||0)+dt;if(this.snapshotT>=1/30){this.snapshotT=0;if(this.state==='play')this.snapshot();}
    if(this.state==='play'||this.state==='restart'||this.state==='dead'||this.state==='goal'){this.humanControl(dt);this.aiUpdate(dt);}
    this.movePlayers(dt);
    if(this.state==='restart')this.restartLogic(dt);
    /* bola */
    if(this.state==='play'||this.state==='goal'||this.state==='dead'){const ev=b.step(dt);if(ev==='post'){this.onPost();}
      if(b.owner)this.ballFollow(dt);
      if(this.state==='play'){this.ballControl(dt);this.checkBall();this.possession(dt);}}
    else if(b.owner)this.ballFollow(dt);
    this.updateKicks(dt);this.refUpdate(dt);this.coach(dt);this.hudTick(dt);
    this.animateAll(dt,false);this.cameraStep(dt,this.goalSpecial());this.syncAll(dt);
    World.update(dt,CameraManager.fx,CameraManager.fz);
    if(this.ending&&this.state==='play'&&(!b.owner||Math.abs(b.pos.x)<HL-30||this.clk>this.dur*60*1.03))this.fullTime();},
  possession(dt){const b=BallManager;const i=b.owner?b.owner.team.idx:b.lastTeam;this.teams[i].poss+=dt;},
  /* ---------------- controle humano ---------------- */
  worldDir(ax){const f=CameraManager.fwd,rx=-f.z,rz=f.x;return{x:rx*ax.x+f.x*(-ax.y),z:rz*ax.x+f.z*(-ax.y)};},
  humanControl(dt){const T=this.teams[0];if(!T.human||this.state==='goal'||this.state==='dead'&&false)return;const b=BallManager,I=InputManager;
    if(!this.sel||this.sel.sent)this.pickSelFor(T);
    InputManager.mode=(b.owner&&b.owner.team===T)||(this.state==='restart'&&this.rs&&this.rs.team===0)?'attack':'defend';
    if(b.owner&&b.owner.team===T&&this.sel!==b.owner)this.sel=b.owner;
    else if(!(b.owner&&b.owner.team===T)){this.selT-=dt;if(this.selT<=0){this.selT=.3;const cur=this.sel;let best=null,bd=1e9;T.players.forEach(p=>{if(p.sent||p.role==='GK')return;const d=Math.hypot(p.x-b.pos.x-b.vel.x*.35,p.z-b.pos.z-b.vel.z*.35);if(d<bd){bd=d;best=p;}});if(best&&cur&&best!==cur){const dc=Math.hypot(cur.x-b.pos.x,cur.z-b.pos.z);if(bd<dc-3.5&&this.state==='play')this.sel=best;}}}
    const s=this.sel;if(!s)return;const ax=I.axis(),wd=this.worldDir(ax);
    /* troca */
    if(I.pressed('switch')){let best=null,bd=1e9;T.players.forEach(p=>{if(p===s||p.sent||p.role==='GK')return;const d=Math.hypot(p.x-b.pos.x,p.z-b.pos.z);if(d<bd){bd=d;best=p;}});if(best&&!(b.owner&&b.owner.team===T)){this.sel=best;AudioManager.sfx('select');}}
    if(I.pressed('press')){T.pressCall=this.t+3.5;AudioManager.sfx('click');}
    if(I.pressed('gk')){T.gkRush=this.t+2.5;}
    const sprint=I.held('sprint');s.sprint=sprint&&s.stam>3;
    const busy=s.act==='fall'||s.act==='slide'||s.stun>0||s.kq;
    if(!busy&&!(this.state==='restart'&&this.rs&&this.rs.taker===s)){const sp=this.maxSp(s,s.sprint)*ax.m;this.steer(s,wd.x*sp,wd.z*sp,dt,true);}else if(!s.sl)this.steer(s,0,0,dt,true);
    s.manual=true;
    /* ações ofensivas */
    const owner=b.owner===s;
    if(this.state==='restart'&&this.rs&&this.rs.taker===s&&this.rs.team===0){for(const k of['pass','shoot','cross','through']){const r=I.released(k);if(r>=0){this.execRestart(k,Math.max(.35,r),wd,ax);break;}}return;}
    if(owner&&this.state==='play'){
      if(s.role==='GK'){for(const k of['pass','shoot','cross','through']){const r=I.released(k);if(r>=0){this.gkDistribute(s,false,k==='pass'?'pass':'long',wd,ax);break;}}return;}
      let r;
      if((r=I.released('pass'))>=0){const m=this.bestPass(s,ax.m>.2?wd:null,false);if(m)this.doPass(s,m,'pass',Math.max(.3,r));else this.doPass(s,null,'pass',Math.max(.3,r),wd);}
      else if((r=I.released('through'))>=0){const m=this.bestPass(s,ax.m>.2?wd:null,true);if(m)this.doPass(s,m,'through',Math.max(.35,r));}
      else if((r=I.released('cross'))>=0){this.doCross(s,Math.max(.4,r),wd,ax.m>.2);}
      else if((r=I.released('shoot'))>=0){this.doShot(s,{power:Math.max(.3,r),aimZ:ax.m>.2?wd.z*3.2*s.team.dir*0+wd.z*3.2:undefined,human:true});}}
    else if(this.state==='play'){
      if(I.pressed('tackle')){this.humanTackle(s,false);}
      if(I.pressed('slide')){this.humanTackle(s,true);}
      I.released('pass');I.released('shoot');I.released('cross');I.released('through');}
    I.released('pass');},
  humanTackle(s,slide){const b=BallManager;if(s.cool>0||s.act==='slide'||s.act==='fall')return;const o=b.owner;
    if(slide){const dx=Math.sin(s.yaw),dz=Math.cos(s.yaw);s.sl={t:.55,vx:dx*8.5,vz:dz*8.5};s.act='slide';s.actT=0;s.actD=1;s.cool=1;s.slideTry=true;AudioManager.sfx('tackle');return;}
    if(o&&o.team!==s.team&&Math.hypot(o.x-s.x,o.z-s.z)<2){this.tryTackle(s,o,false);}else{s.cool=.4;s.act='trap';s.actT=0;s.actD=.3;}},
  /* ---------------- movimento ---------------- */
  maxSp(p,sprint){const base=5.6+p.d.pac*.036;return base*(sprint?1.14:.8)*(.82+.18*(p.stam/100));},
  steer(p,wx,wz,dt,direct){const A=9+p.a.accel*.05;if(p.sl){p.sl.t-=dt;if(p.sl.t<=0){p.sl=null;p.stun=Math.max(p.stun,.5);}else{const f=p.sl.t/.55;wx=p.sl.vx*f;wz=p.sl.vz*f;}}
    if(p.stun>0||p.act==='fall'){wx=wz=0;}
    let dx=wx-p.vx,dz=wz-p.vz;const dl=Math.hypot(dx,dz),m=A*dt*(p.sl?2:1);if(dl>m){dx*=m/dl;dz*=m/dl;}p.vx+=dx;p.vz+=dz;},
  movePlayers(dt){const T0=this.teams;for(const p of this.all){if(!p.manual&&!p.aiSet)this.steer(p,0,0,dt);p.manual=false;p.aiSet=false;
      p.x=clamp(p.x+p.vx*dt,-HL-7,HL+7);p.z=clamp(p.z+p.vz*dt,-HW-5,HW+5);const sp=Math.hypot(p.vx,p.vz);
      if(sp>.6&&p.act!=='slide'&&p.act!=='dive'){const tg=Math.atan2(p.vx,p.vz),df=wrapA(tg-p.yaw),rate=(8.5-4*Math.min(1,sp/9))*dt;p.yaw+=clamp(df,-rate,rate);}
      p.stam=clamp(p.stam+(sp>this.maxSp(p,false)*1.03?-(4.5-p.a.stamina*.02):(sp>3?1.2:3.5))*dt,0,100);
      const acc=(sp-p.lsp)/Math.max(dt,.001);p.lsp=sp;p.lean=lerp(p.lean,clamp(acc*.018,-.1,.22),.15);p.ph+=dt*(4.5+sp*.95);p.spdN=lerp(p.spdN,sp/8.4,.25);
      if(p.cool>0)p.cool-=dt;if(p.stun>0)p.stun-=dt;if(p.act){p.actT+=dt;if(p.actD&&p.actT>=p.actD&&p.act!=='celeb'&&p.act!=='throwhold')p.act='';}}
    for(let i=0;i<this.all.length;i++){const a=this.all[i];for(let j=i+1;j<this.all.length;j++){const c=this.all[j],dx=c.x-a.x,dz=c.z-a.z,d=dx*dx+dz*dz;if(d<.64&&d>1e-6){const dd=Math.sqrt(d),push=(.8-dd)*.5,wa=a.a.strength/(a.a.strength+c.a.strength);a.x-=dx/dd*push*(1-wa)*2;a.z-=dz/dd*push*(1-wa)*2;c.x+=dx/dd*push*wa*2;c.z+=dz/dd*push*wa*2;}}}},
  /* ---------------- bola: posse, chutes ---------------- */
  ballFollow(dt){const b=BallManager,o=b.owner;if(!o||o.sent){b.owner=null;return;}const held=this.state==='restart';let fx,fz;
    if(held&&this.rs&&this.rs.type==='throw'){b.pos.x=o.x;b.pos.z=o.z;b.pos.y=2.1;b.vel.x=b.vel.z=0;return;}
    if(held&&this.rs&&(this.rs.pen)){b.pos.x=this.rs.x;b.pos.z=this.rs.z;b.pos.y=BRAD;return;}
    if(o.role==='GK'&&o.act!=='dive'){b.pos.x=o.x+Math.sin(o.yaw)*.3;b.pos.z=o.z+Math.cos(o.yaw)*.3;b.pos.y=.95;b.vel.x=b.vel.z=0;return;}
    const sp=Math.hypot(o.vx,o.vz),w=Math.sin(o.ph*.5)*.12;fx=o.x+Math.sin(o.yaw)*(.5+sp*.035)+Math.cos(o.yaw)*w;fz=o.z+Math.cos(o.yaw)*(.5+sp*.035)-Math.sin(o.yaw)*w;
    const k=1-Math.exp(-dt*20);b.pos.x=lerp(b.pos.x,fx,k);b.pos.z=lerp(b.pos.z,fz,k);b.pos.y=BRAD;b.vel.x=o.vx;b.vel.z=o.vz;b.vel.y=0;
    o.shield=false;let near=99;this.teams[1-o.team.idx].players.forEach(p=>{if(p.sent)return;const d=Math.hypot(p.x-o.x,p.z-o.z);if(d<near)near=d;});o.shield=near<2.2&&sp<2.5;
    /* desarme da IA */
    const O=this.teams[1-o.team.idx];if(this.state==='play'&&!(O.human&&false)){for(const p of O.players){if(p.sent||p.cool>0||p===this.sel||p.role==='GK'||p.stun>0||p.act==='fall')continue;const d=Math.hypot(p.x-o.x,p.z-o.z);if(d<1.15&&Math.random()<dt*(.9+p.a.aggression*.012)*this.DC().press*(O.human?1.5:1)){this.tryTackle(p,o,Math.random()<.08&&p.a.aggression>55);break;}}}},
  ballControl(dt){const b=BallManager;if(b.owner)return;let best=null,bd=9,head=false;
    for(const p of this.all){if(p.cool>0||p.stun>0||p.act==='fall'||p.act==='slide'&&false)continue;const dx=b.pos.x-p.x,dz=b.pos.z-p.z,d=Math.hypot(dx,dz);
      if(p.role==='GK'){const r3=Math.hypot(d,b.pos.y-1.0);if(r3<(1.9+(p.act==='dive'?.9:0))&&Math.abs(b.pos.x)>HL-18&&Math.abs(b.pos.z)<21&&Math.sign(b.pos.x)===-p.team.dir){this.gkReach(p);if(b.owner)return;}continue;}
      if(b.pos.y>1.05){if(b.pos.y<2.3&&d<.9&&b.vel.y<4&&d<bd){best=p;bd=d;head=true;}continue;}
      const reach=.74+p.a.control*.0035+(p.sl?.5:0);if(d<reach&&d<bd){best=p;bd=d;head=false;}}
    if(!best)return;const p=best;
    if(head){this.doHeader(p);return;}
    const rs=Math.hypot(b.vel.x-p.vx,b.vel.z-p.vz);
    if(rs>15&&Math.random()>p.a.control/115+.1){b.vel.x*=.35+Math.random()*.2;b.vel.z*=.35+Math.random()*.2;b.vel.x+=randn()*2;b.vel.z+=randn()*2;p.cool=.4;b.last=p;b.lastTeam=p.team.idx;return;}
    if(this.off&&this.off.set.has(p)&&p.team.idx===this.off.team&&this.t-this.off.t<5){this.offsideCall(p);return;}
    if(this.off&&(p.team.idx!==this.off.team||this.t-this.off.t>=5))this.off=null;
    else if(this.off&&!this.off.set.has(p))this.off=null;
    b.owner=p;b.last=p;b.lastTeam=p.team.idx;b.shot=null;p.hold=0;p.act='trap';p.actT=0;p.actD=.3;if(p.team.human)this.sel=p;},
  gkReach(g){const b=BallManager,T=g.team,spd=Math.hypot(b.vel.x,b.vel.y,b.vel.z),d3=Math.hypot(b.pos.x-g.x,b.pos.y-1,b.pos.z-g.z);const toward=b.vel.x*T.dir<-2;
    if(b.shot&&b.shot.team!==T.idx&&!b.shot.res&&toward){b.shot.res=true;let ps=.86+(g.d.ovr-72)/160-spd/58-d3/6+(T.human?0:this.DC().gk);if(this.rs&&this.rs.pen)ps-=.12;
      if(Math.random()<ps){g.cool=.6;if(spd<17&&Math.random()<.65||spd<9){b.owner=g;g.act='catch';g.actT=0;g.actD=.7;g.hold=0;b.shot=null;}else{b.vel.x=T.dir*rnd(3,8);b.vel.z=rnd(-7,7);b.vel.y=rnd(1,4.5);g.act=g.act||'catch';g.actT=0;g.actD=.6;b.lastTeam=T.idx;b.last=g;}
        b.shot=null;AudioManager.sfx('tackle');AudioManager.say('save');UI.toast('',''); if(spd>19)this.bigEvent('save');this.teams[1-T.idx].saved=(this.teams[1-T.idx].saved||0)+1;}
      return;}
    if(!b.shot||b.shot.res){if(spd<16&&g.cool<=0){b.owner=g;g.act='catch';g.actT=0;g.actD=.6;g.hold=0;b.last=g;b.lastTeam=T.idx;b.shot=null;this.off=null;if(T.human)this.sel=g;}}},
  doHeader(p){const b=BallManager,T=p.team,gx=T.dir*HL,dg=Math.hypot(gx-p.x,p.z);p.act='head';p.actT=0;p.actD=.55;p.cool=.7;b.last=p;b.lastTeam=T.idx;b.shot=null;
    if(dg<20&&Math.random()<.6+p.a.heading/300){const tz=rnd(-3,3),dx=gx-p.x,dz=tz-p.z,dd=Math.hypot(dx,dz),sp=11+p.a.heading*.07;b.vel.x=dx/dd*sp;b.vel.z=dz/dd*sp;b.vel.y=rnd(-1.5,.5);b.shot={team:T.idx,res:false};T.shots++;T.onT++;AudioManager.sfx('pass',.6);this.hintChance();}
    else{const m=this.bestPass(p,null,false)||null;const ang=m?Math.atan2(m.x-p.x,m.z-p.z):(T.dir>0?Math.PI/2:-Math.PI/2);const sp=rnd(8,13);b.vel.x=Math.sin(ang)*sp;b.vel.z=Math.cos(ang)*sp;b.vel.y=rnd(3,6);AudioManager.sfx('pass',.4);}},
  queueKick(p,vx,vy,vz,spin,act,kind,o){p.kq=Object.assign({t:act==='throw'?.35:.13,vx,vy,vz,spin,kind},o||{});p.act=act==='throw'?'throw':act;p.actT=0;p.actD=act==='throw'?.7:.45;p.actV=Math.random()<.8?1:-1;},
  updateKicks(dt){for(const p of this.all){const q=p.kq;if(!q)continue;q.t-=dt;if(q.t>0)continue;p.kq=null;const b=BallManager;if(b.owner!==p&&!(this.state==='restart'))continue;
      b.owner=null;b.pos.x=p.x+Math.sin(p.yaw)*.45;b.pos.z=p.z+Math.cos(p.yaw)*.45;b.pos.y=q.y||BRAD+.02;b.vel.x=q.vx;b.vel.y=q.vy;b.vel.z=q.vz;b.spin=q.spin||0;b.last=p;b.lastTeam=p.team.idx;p.cool=.45;b.px=b.pos.x;
      AudioManager.sfx(q.kind==='shot'?'kick':'pass',q.pow||.5);AudioManager.vib(q.kind==='shot'?25:8);if(q.kind==='shot'){b.shot={team:p.team.idx,res:false};p.team.shots++;if(q.onT)p.team.onT++;AudioManager.crowd(.5);World.cheer(.25);World.part.emit(p.x,.1,p.z,6,2,2,['#3a7a35','#4a8a3a'],.6);if(Math.random()<.35)AudioManager.say('chance');}
      if(q.kind==='pass'||q.kind==='long'||q.kind==='cross'||q.kind==='through'){b.passer=p;b.passerT=this.t;if(q.off)this.off={team:p.team.idx,set:q.off,t:this.t};}
      if(this.state==='restart'){this.state='play';this.rs=null;UI.hint('');}}},
  /* alvo do passe */
  bestPass(p,stick,fwd){const T=p.team,O=this.teams[1-T.idx],dir=T.dir;let best=null,bs=-1e9;
    for(const m of T.players){if(m===p||m.sent)continue;const dx=m.x-p.x,dz=m.z-p.z,d=Math.hypot(dx,dz);if(d<4||d>48)continue;
      let open=8;for(const o of O.players){if(o.sent)continue;const t=clamp(((o.x-p.x)*dx+(o.z-p.z)*dz)/(d*d),0,1),px=p.x+dx*t,pz=p.z+dz*t,od=Math.hypot(o.x-px,o.z-pz);if(od<open)open=od;}
      const ahead=(m.x-p.x)*dir;let sc;
      if(stick){const dot=(dx*stick.x+dz*stick.z)/d;if(dot<.45)continue;sc=dot*7+open*.5-d*.03;}
      else{sc=open*.9+ahead*(fwd?.22:.07)-Math.abs(d-(fwd?24:17))*.05+(m.role==='GK'?-6:0)+(Math.random()-.5)*(1-this.DC().dec)*8;}
      if(m.x*dir>T.off+.2&&m.x*dir>p.x*dir&&!(fwd&&false))sc-=(p.team.human?0:12)+3;
      if(sc>bs){bs=sc;best=m;}}
    return best;},
  offsideSet(p,kind){const T=p.team,O=this.teams[1-T.idx],dir=T.dir;const xs=O.players.filter(o=>!o.sent).map(o=>o.x*dir).sort((a,b)=>b-a);const line=Math.max(0,xs[1]!==undefined?xs[1]:0);const set=new Set();T.players.forEach(m=>{if(m===p||m.sent)return;const mx=m.x*dir;if(mx>line+.2&&mx>p.x*dir+.2&&mx>0)set.add(m);});return set.size?set:null;},
  doPass(p,m,kind,power,fdir){const T=p.team,b=BallManager,dir=T.dir;let tx,tz,d;
    if(!m){const f=fdir||{x:dir,z:0};const l=Math.hypot(f.x,f.z)||1;tx=p.x+f.x/l*14*power;tz=p.z+f.z/l*14*power;}else{tx=m.x;tz=m.z;d=Math.hypot(tx-p.x,tz-p.z);
      if(kind==='through'){const lead=clamp(d*.45,5,14);tx=m.x+dir*lead+m.vx*.6;tz=m.z+m.vz*.4;}else{const f=clamp(d/16,0,1.1)*.7;tx+=m.vx*f;tz+=m.vz*f;}}
    let dx=tx-p.x,dz=tz-p.z;d=Math.hypot(dx,dz)||1;const lob=kind==='lob'||kind==='long'||kind==='cross';let sp,vy=0;
    if(lob){const Tm=.8+d/28;sp=d/Tm;vy=9.81*Tm/2;}else{sp=clamp(d*.62+4.5,8,29)*(.78+.45*power)*(kind==='through'?1.12:1);}
    const sig=(1-p.a.passing/105)*.075*(.7+power*.7)*(T.human?1:this.DC().acc)*(1+(p.stam<30?.4:0));const ang=Math.atan2(dx,dz)+randn()*sig;
    const off=(kind==='pass'||kind==='through'||kind==='long')?this.offsideSet(p,kind):null;
    this.queueKick(p,Math.sin(ang)*sp,vy,Math.cos(ang)*sp,0,lob?'cross':'pass',kind,{pow:power,off});if(m&&kind==='through')AudioManager.say('pass');},
  doCross(p,power,wd,stick){const T=p.team,dir=T.dir;let best=null,bs=-1e9;T.players.forEach(m=>{if(m===p||m.sent||m.role==='GK')return;const inbox=(m.x*dir>HL-24&&Math.abs(m.z)<15);let sc=(inbox?10:0)-Math.hypot(m.x-(dir*(HL-9)),m.z)*.3;if(stick){const dx=m.x-p.x,dz=m.z-p.z,d=Math.hypot(dx,dz)||1;sc+=((dx*wd.x+dz*wd.z)/d)*5;}if(sc>bs){bs=sc;best=m;}});
    if(best)this.doPass(p,best,'cross',power);else this.doPass(p,null,'long',power,wd);},
  doShot(p,o){const T=p.team,b=BallManager,gx=T.dir*HL,dist=Math.hypot(gx-p.x,p.z),O=this.teams[1-T.idx];const power=o.power!==undefined?o.power:.55+Math.random()*.4;
    let aimZ=o.aimZ;if(aimZ===undefined){const g=O.gk;aimZ=(g&&g.z>0?-1:1)*rnd(1.4,3.1);}aimZ=clamp(aimZ,-3.4,3.4);
    const sig=((1-p.a.finishing/105)*1.25+power*.55)*(.55+dist/30)*(T.human?1:this.DC().acc*.9+.1)*(p.stam<25?1.3:1);const tz=aimZ+randn()*sig,ty=clamp(rnd(.25,1.9)+(power>.85?randn()*.9:0),0,3.6);
    const speed=17+power*17+p.a.finishing*.03;const dx=gx-p.x,dz=tz-p.z,dd=Math.hypot(dx,dz)||1,tt=dd/speed;const vy=Math.max(-1,(ty-BRAD-.1)/tt+4.905*tt);
    const spin=o.human?0:randn()*1.2+ (dist>14?(tz>p.z?-1:1)*.8:0);
    this.queueKick(p,dx/dd*speed,vy,dz/dd*speed,spin,'shoot','shot',{pow:power,onT:ty<GHGT&&Math.abs(tz)<GH});
    if(this.rs&&this.rs.pen){const O2=this.teams[1-T.idx].gk;if(O2){O2.pdive=Math.random()<.5?-1:1;O2.pdt=Math.abs(tz)>2.2&&Math.sign(tz)===O2.pdive?1:0;}}},
  hintChance(){},
  /* ---------------- desarme e faltas ---------------- */
  tryTackle(d,o,slide){if(d.cool>0)return;d.cool=slide?.9:.6;const b=BallManager;
    const pw=clamp(.36+(d.a.tackling-(o.a.control*.6+o.d.dri*.4))/150+(slide?.1:0)-(o.shield?.08:0)+(d.team.human?.04:0),.12,.82);
    if(slide){d.sl={t:.55,vx:Math.sin(d.yaw)*8,vz:Math.cos(d.yaw)*8};d.act='slide';d.actT=0;d.actD=1;}
    if(Math.random()<pw){b.owner=null;const ang=d.yaw+randn()*.8;b.vel.x=Math.sin(ang)*5;b.vel.z=Math.cos(ang)*5;b.vel.y=1;b.last=d;b.lastTeam=d.team.idx;o.stun=.4;o.cool=.6;AudioManager.sfx('tackle');World.part.emit(o.x,.3,o.z,5,2,2,['#3a7a35'],.5);}
    else{const fp=(slide?.42:.1)*(1+d.a.aggression/160)*(d.team.human?.8:1);if(Math.random()<fp)this.foul(d,o,slide);else if(!slide){o.act='trap';}}},
  foul(off,vic,severe){if(this.state!=='play')return;AudioManager.sfx('whistle');AudioManager.say('foul');const T=off.team,V=vic.team;T.fouls++;vic.act='fall';vic.actT=0;vic.actD=1.9;vic.stun=1.5;vic.sl=null;
    const r=Math.random();let card='';if(severe&&r<.06)card='red';else if(r<(severe?.45:.09)+off.a.aggression*.0006)card=off.yel>=1?'red':'yellow';
    BallManager.owner=null;BallManager.vel.x=BallManager.vel.z=0;BallManager.vel.y=0;const x=clamp(vic.x,-HL+1,HL-1),z=clamp(vic.z,-HW+1,HW-1);BallManager.place(x,z);
    UI.toast(t('foul'),'foul');if(card)this.giveCard(off,card);
    const inBox=Math.abs(x)>HL-16.5&&Math.abs(z)<20.16&&Math.sign(x)===V.dir;
    this.stopPlay(1.9,()=>{const tk=this.pickTaker(V,inBox?'penalty':'freekick',x,z);this.beginRestart({type:inBox?'penalty':'freekick',team:V.idx,x,z,taker:tk,delay:1.6});if(inBox){}else{BallManager.place(x,z);tk.x=x-V.dir*1.2;tk.z=z;BallManager.owner=tk;}});},
  giveCard(p,c){const T=p.team;AudioManager.sfx('card');if(c==='yellow'){p.yel++;T.yel++;UI.toast(t('yellow')+' · '+p.d.name,'yellow');}else{T.red++;p.sent=true;p.mesh.visible=false;UI.toast(t('red')+' · '+p.d.name,'red');if(T.gk===p)T.gk=T.players.find(q=>!q.sent&&q.d.pos==='GK')||null;this.refreshAll();}
    this.log.push({type:c,name:p.d.name,team:T.idx,min:Math.ceil(this.gmin)});AudioManager.say('card');World.cheer(.5);},
  offsideCall(p){AudioManager.sfx('whistle');UI.toast(t('offside'),'foul');const V=this.teams[1-p.team.idx];BallManager.place(clamp(p.x,-HL+1,HL-1),clamp(p.z,-HW+1,HW-1));BallManager.owner=null;this.off=null;const x=BallManager.pos.x,z=BallManager.pos.z;this.stopPlay(1.6,()=>{const tk=this.pickTaker(V,'freekick',x,z);this.beginRestart({type:'freekick',team:V.idx,x,z,taker:tk,delay:1.4,indirect:true});BallManager.place(x,z);tk.x=x-V.dir*1.2;tk.z=z;BallManager.owner=tk;});},
  stopPlay(delay,fn){this.state='dead';this.dead={t:delay,fn};this.replayCheck=false;},
  pickTaker(T,type,x,z){let best=null,bs=-1e9;T.players.forEach(p=>{if(p.sent)return;const gk=p.role==='GK';let sc;if(type==='goalkick')sc=gk?100:-100;else if(gk)return;else if(type==='penalty')sc=p.a.finishing;else if(type==='corner')sc=p.a.crossing*1+(p.role==='LM'||p.role==='RM'||p.role==='LW'||p.role==='RW'?5:0)-Math.hypot(p.x-x,p.z-z)*.05;else if(type==='freekick'){const dg=Math.hypot(T.dir*HL-x,z);sc=dg<32?p.a.finishing*.6+p.a.passing*.4-Math.hypot(p.x-x,p.z-z)*.1:-Math.hypot(p.x-x,p.z-z)+(p.role!=='ST'?3:0);}else sc=-Math.hypot(p.x-x,p.z-z);if(sc>bs){bs=sc;best=p;}});return best;},
  /* ---------------- bola fora / gol ---------------- */
  checkBall(){const b=BallManager,p=b.pos;
    if(Math.abs(p.x)>HL+.05&&Math.abs(b.px)<=HL+.05){const s=Math.sign(p.x);if(Math.abs(p.z)<GH&&p.y<GHGT+.02){return this.goal(s>0?0:1);}
      const def=this.teams.find(T=>T.dir===-s);const lt=b.lastTeam;if(lt===def.idx){this.out('corner',1-def.idx,s*(HL-.3),Math.sign(p.z||1)*(HW-.3));}else this.out('goalkick',def.idx,s*(HL-5.5),0);return;}
    if(Math.abs(p.x)>HL+1&&Math.abs(p.z)<GH+.6&&p.y<GHGT+.5)return;
    if(Math.abs(p.z)>HW+.05){const lt=b.lastTeam;this.out('throw',1-lt,clamp(p.x,-HL+2,HL-2),Math.sign(p.z)*(HW+.05));}},
  out(type,teamIdx,x,z){if(this.state!=='play')return;const b=BallManager,T=this.teams[teamIdx];AudioManager.sfx('whistle',.3);b.owner=null;b.vel.x=b.vel.y=b.vel.z=0;UI.toast(t(type==='throw'?'throwin':type),'info');if(type==='corner')T.corners++;if(type==='goalkick')AudioManager.say('miss');
    this.stopPlay(1.1,()=>{b.place(x,z);const tk=this.pickTaker(T,type,x,z);if(type==='throw'){tk.x=x;tk.z=z+Math.sign(z)*.7;}else if(type==='goalkick'){tk.x=x+T.dir*-0*1;tk.z=z;tk.x=x-T.dir*1;}else{tk.x=x-Math.sign(x)*1;tk.z=z+Math.sign(z)*1;}
      this.beginRestart({type,team:teamIdx,x,z,taker:tk,delay:1.6});if(type==='throw')b.pos.y=2.1;});},
  goal(scIdx){const b=BallManager,T=this.teams[scIdx],O=this.teams[1-scIdx];T.score++;this.state='goal';const sc=b.last&&b.last.team===T?b.last:(T.players.filter(p=>!p.sent&&p.role!=='GK').sort((a,c)=>Math.hypot(a.x-b.pos.x,a.z-b.pos.z)-Math.hypot(c.x-b.pos.x,c.z-b.pos.z))[0]);
    const own=b.last&&b.last.team!==T,ass=(!own&&b.passer&&b.passer!==sc&&b.passer.team===T&&this.t-b.passerT<9)?b.passer:null;const name=own?b.last.d.name+' (c)':sc.d.name;
    this.log.push({type:'goal',name,team:scIdx,min:Math.ceil(this.gmin),assist:ass?ass.d.name:''});this.goalInfo={t:3.6,team:scIdx,scorer:sc,name,min:Math.ceil(this.gmin)};
    AudioManager.sfx('goal');AudioManager.say('goal');AudioManager.vib([60,40,120]);World.cheer(1);CameraManager.shake=.4;World.part.emit(b.pos.x,2,b.pos.z,70,14,12,[T.kit.c1,'#ffffff','#f0b429'],2.2);
    UI.goalBanner(name,Math.ceil(this.gmin),T.club.short);this.updateScoreboard();
    sc.act='celeb';sc.actT=0;sc.actD=0;sc.actV=Math.floor(Math.random()*4);sc.celebT=0;b.owner=null;this.replayAfter=true;this.snapshot();
    T.players.forEach(p=>{if(p!==sc&&!p.sent&&p.role!=='GK'){p.celebTarget=sc;}});},
  finishGoal(){T0:{this.teams.forEach(T=>T.players.forEach(p=>{p.celebTarget=null;if(p.act==='celeb')p.act='';}));}this.startReplay(()=>{const conc=1-this.goalInfo.team;this.state='restart';this.setupKickoff(conc,true);AudioManager.sfx('whistle');});},
  bigEvent(k){this.pendingReplay=this.t+2;},
  onPost(){AudioManager.sfx('post');AudioManager.say('post');World.cheer(.6);CameraManager.shake=.2;UI.toast('','');this.pendingReplay=this.t+1.8;UI.hint('');},
  /* ---------------- reposição ---------------- */
  restartLogic(dt){const rs=this.rs;if(!rs)return;rs.t+=dt;const tk=rs.taker;if(!tk||tk.sent){this.rs=null;this.state='play';return;}
    if(tk.act==='throwhold'&&rs.type!=='throw')tk.act='';
    if(tk.team.human&&this.sel===tk&&!rs.auto){if(rs.t>10){rs.auto=true;}else return;}
    if(rs.t<rs.delay)return;if(tk.kq)return;this.execRestart(null,.6,null,null);},
  execRestart(kind,power,wd,ax){const rs=this.rs;if(!rs||this.state!=='restart')return;const tk=rs.taker,T=tk.team,dir=T.dir,human=kind!==null;const stick=human&&ax&&ax.m>.2?wd:null;
    const nearest=()=>this.bestPass(tk,stick,false);
    switch(rs.type){
      case'kickoff':{const m=nearest();this.doPass(tk,m,'pass',.35);break;}
      case'throw':{const m=nearest();if(m){const dx=m.x-tk.x,dz=m.z-tk.z,d=Math.hypot(dx,dz),Tm=.7+d/22,sp=d/Tm;this.queueKick(tk,dx/d*sp,Tm*4.9-1.5,dz/d*sp,0,'throw','pass',{y:2.1});}break;}
      case'corner':{if(!human||kind==='cross'||kind==='shoot')this.doCross(tk,Math.max(.5,power),wd||{x:-dir,z:0},stick);else this.doPass(tk,nearest(),'pass',power);break;}
      case'goalkick':{this.gkDistribute(tk,!human,kind&&kind!=='pass'?'long':(human?'pass':null),wd,ax);break;}
      case'freekick':{const dg=Math.hypot(dir*HL-rs.x,rs.z);if((kind==='shoot'||!human)&&dg<30&&!rs.indirect&&(human||Math.random()<.65)){this.doShot(tk,{power:human?Math.max(.45,power):.75,aimZ:human&&stick?wd.z*3.2:undefined,human});}else if(kind==='cross'||(!human&&dg<45&&dg>22&&Math.random()<.5))this.doCross(tk,.7,wd,stick);else this.doPass(tk,nearest(),'pass',Math.max(.4,power));break;}
      case'penalty':{this.doShot(tk,{power:human?Math.max(.6,power):.78,aimZ:human&&ax&&ax.m>.2?wd.z*3.2:(Math.random()<.5?-1:1)*rnd(1.8,3.1),human:false});break;}}
    rs.executed=true;},
  /* goleiro: distribuição */
  gkDistribute(g,ai,kind,wd,ax){const T=g.team;const stick=!ai&&ax&&ax.m>.2?wd:null;if(g.kq)return;
    if(kind==='pass'||(ai&&Math.random()<.4)){const m=this.bestPass(g,stick,false);if(m){const dx=m.x-g.x,dz=m.z-g.z,d=Math.hypot(dx,dz),sp=clamp(d*.62+5,9,22);this.queueKick(g,dx/d*sp,0,dz/d*sp,0,'pass','pass',{pow:.4});return;}}
    let best=null,bs=-1e9;T.players.forEach(m=>{if(m===g||m.sent)return;const d=Math.hypot(m.x-g.x,m.z-g.z);if(d<22)return;let sc=-Math.abs(d-38)*.3+(m.role==='ST'||m.role==='CM'?3:0)+Math.random()*4;if(stick){sc+=((m.x-g.x)*stick.x+(m.z-g.z)*stick.z)/d*8;}if(sc>bs){bs=sc;best=m;}});
    if(best)this.doPass(g,best,'long',.7);else{this.queueKick(g,T.dir*14,8,0,0,'pass','long',{pow:.6});}},
  /* ---------------- IA ---------------- */
  aiUpdate(dt){const b=BallManager,DC=this.DC(),now=this.t;
    for(const T of this.teams){const O=this.teams[1-T.idx],dir=T.dir,tac=T.tac;let phase=b.owner?(b.owner.team===T?'att':'def'):'loose';
      if(this.state==='restart'&&this.rs)phase=this.rs.team===T.idx?'att':'def';
      const xs=O.players.filter(o=>!o.sent).map(o=>o.x*dir).sort((a,c)=>c-a);T.off=xs[1]!==undefined?xs[1]:0;
      const bx=b.pos.x+b.vel.x*.35,bz=b.pos.z+b.vel.z*.35;const field=T.players.filter(p=>!p.sent&&p.role!=='GK'&&p!==this.sel).sort((a,c)=>Math.hypot(a.x-bx,a.z-bz)-Math.hypot(c.x-bx,c.z-bz));
      let nch=phase==='att'?0:(phase==='def'?(tac.press>=1?2:1):2);if(T.pressCall>now&&phase==='def')nch=3;if(this.state==='restart'&&phase==='def')nch=0;if(!T.human&&this.cfg.training&&T.idx===1)nch=0;
      T.chasers=field.slice(0,nch);const taken=new Set();
      for(const p of T.players){if(p.sent||p===this.sel&&T.human)continue;if(p.role==='GK')continue;if(p.stun>0||p.act==='fall'||p.sl){p.aiSet=false;continue;}if(p.kq){p.aiSet=false;continue;}
        if(this.cfg.training&&T.idx===1){this.steer(p,0,0,dt);p.aiSet=true;continue;}
        const own=b.owner===p;let tx,tz,sprint=false,sf=.8;
        if(this.state==='restart'&&this.rs&&p===this.rs.taker){this.steer(p,0,0,dt);p.aiSet=true;continue;}
        if(own&&this.state==='play'){this.ownerAI(p,dt);continue;}
        if(p.celebTarget){tx=p.celebTarget.x;tz=p.celebTarget.z;sprint=true;const d=Math.hypot(tx-p.x,tz-p.z);if(d<3){tx=p.x;tz=p.z;p.act=p.act||'';}this.goTo(p,tx,tz,dt,sprint,true);continue;}
        const ch=T.chasers.indexOf(p)>=0;
        if(ch&&this.state!=='restart'){const tgt=b.owner||b;const px=b.owner?b.owner.x+b.owner.vx*.3:bx,pz=b.owner?b.owner.z+b.owner.vz*.3:bz;const dd=Math.hypot(px-p.x,pz-p.z);sprint=dd>4&&(DC.press>.6||phase==='loose');this.goTo(p,px,pz,dt,sprint,false);continue;}
        const u=clamp((b.pos.x*dir+HL)/PL,0,1);let fx=p.slot[1],fz=p.slot[2];const role=p.role,def=FAMILY[role]==='D',att=FAMILY[role]==='A';
        let nfx=fx+(u-.5)*.55*(def?.7:1)+(tac.ment-1)*.045*(def?.6:1.2)+(def?(tac.line-1)*.06:0);if(phase==='att'){if(att)nfx+=.08;else if(!def)nfx+=.04;}if(phase==='def')nfx-=.04;if(this.state==='restart'&&this.rs&&this.rs.type==='corner'&&phase==='att'&&(att||FAMILY[role]==='M'&&role!=='CDM'))nfx=.9+Math.random()*0+(p.slot[2]*.05);
        nfx=clamp(nfx,.04,.96);let wf=.8+(tac.width-1)*.14;if(phase==='def')wf*=1-.14*tac.compact;let zz=fz*wf*HW*.95;zz+=clamp(b.pos.z*dir-zz,-30,30)*(phase==='def'?.2:.08);
        zz+=Math.sin(now*.7+p.d.num)*1.6;tx=dir*(-HL+nfx*PL);tz=dir*zz;
        if(phase==='att'&&att&&u>.35){const lim=Math.max(T.off,b.pos.x*dir)-.6;if(tx*dir>lim)tx=dir*lim;}
        if(phase==='att'&&b.owner&&FAMILY[role]==='M'&&b.owner!==p&&!def){const o=b.owner;if(Math.hypot(o.x-p.x,o.z-p.z)<20&&taken.size<2){taken.add(p);tx=o.x+dir*7;tz=o.z+(p.z>o.z?1:-1)*9;}}
        if(phase==='def'&&(def||FAMILY[role]==='M')){let mo=null,md=15;O.players.forEach(o=>{if(o.sent||o.role==='GK'||taken.has(o))return;const d=Math.hypot(o.x-tx,o.z-tz);if(d<md&&(b.owner!==o)){md=d;mo=o;}});if(mo){taken.add(mo);const gx=-dir*HL,vx=gx-mo.x,vz=-mo.z,vl=Math.hypot(vx,vz)||1;const mix=DC.disc;tx=lerp(tx,mo.x+vx/vl*1.9,.7*mix);tz=lerp(tz,mo.z+vz/vl*1.9,.7*mix);}}
        const dd=Math.hypot(tx-p.x,tz-p.z);sprint=dd>12&&(phase==='att'||u>.6);this.goTo(p,tx,tz,dt,sprint,false);}
      this.gkUpdate(T,dt);}},
  goTo(p,tx,tz,dt,sprint,fast){const dx=tx-p.x,dz=tz-p.z,d=Math.hypot(dx,dz);let sp=this.maxSp(p,sprint&&p.stam>12);if(d<3)sp*=Math.max(.2,d/3);if(d<.3)sp=0;p.sprint=sprint;this.steer(p,d>.001?dx/d*sp:0,d>.001?dz/d*sp:0,dt);p.aiSet=true;},
  ownerAI(p,dt){const T=p.team,O=this.teams[1-T.idx],DC=this.DC(),dir=T.dir,b=BallManager;p.hold+=dt;p.think-=dt;const gx=dir*HL,dg=Math.hypot(gx-p.x,p.z);let nd=99,no=null;O.players.forEach(o=>{if(o.sent)return;const d=Math.hypot(o.x-p.x,o.z-p.z);if(d<nd){nd=d;no=o;}});
    if(p.kq){this.steer(p,0,0,dt);p.aiSet=true;return;}
    if(p.think<=0){p.think=DC.react*(.5+Math.random()*.9);const role=p.role,gk=role==='GK';
      let sh=0;if(!gk&&role!=='CB'&&dg<34)sh=Math.pow((34-dg)/34,1.05)*(p.a.finishing/100+.3)*(1-Math.abs(p.z)/55)*(nd<1.8?1.25:1)*(FAMILY[role]==='A'?1.2:.8)*1.9;
      if(Math.random()<sh){this.doShot(p,{});return;}
      const pressure=nd<2.8;
      if(Math.abs(p.z)>HW-16&&p.x*dir>HL-26&&(role==='LW'||role==='RW'||role==='LM'||role==='RM'||role==='LB'||role==='RB')&&Math.random()<.45){this.doCross(p,.7,{x:dir,z:0},false);return;}
      if(role==='CB'&&pressure&&p.x*dir<-HL+30&&Math.random()<.5){const m=this.bestPass(p,null,true);this.doPass(p,m,'long',.8);return;}
      const wantPass=pressure||p.hold>(2.8-T.tac.build*.6)||Math.random()<.1+T.tac.build*.05;
      if(wantPass&&(Math.random()<DC.dec||!pressure)){const thr=Math.random()<.18&&FAMILY[role]!=='D';const m=this.bestPass(p,null,thr);if(m){this.doPass(p,m,thr?'through':(Math.hypot(m.x-p.x,m.z-p.z)>26?'long':'pass'),.5+Math.random()*.3);return;}}}
    /* conduz a bola */
    let vx=dir,vz=-p.z*.02;if(T.tac.att===0)vz+=Math.sign(p.z||1)*.35;if(T.tac.att===2)vz-=p.z*.03;
    O.players.forEach(o=>{if(o.sent)return;const dx=p.x-o.x,dz=p.z-o.z,d=Math.hypot(dx,dz);if(d<7&&d>.1&&(o.x-p.x)*dir>-1.5){vx+=dx/d*(7-d)*.22;vz+=dz/d*(7-d)*.22;}});
    if(Math.abs(p.z)>HW-3)vz-=Math.sign(p.z)*1;const l=Math.hypot(vx,vz)||1;const spr=nd>3&&p.stam>25;const sp=this.maxSp(p,spr)*.96;this.steer(p,vx/l*sp,vz/l*sp,dt);p.aiSet=true;p.sprint=spr;},
  gkUpdate(T,dt){const g=T.gk;if(!g||g.sent||g===this.sel&&T.human&&BallManager.owner===g)return;const b=BallManager,own=-T.dir*HL;
    if(g.kq||g.sl){return;}
    if(b.owner===g){this.steer(g,0,0,dt);g.aiSet=true;g.hold+=dt;if(this.state==='play'&&(!T.human||g!==this.sel)&&g.hold>1.7)this.gkDistribute(g,true);else if(this.state==='play'&&g.hold>8)this.gkDistribute(g,true);return;}
    if(T.human&&g===this.sel)return;
    let tx,tz,sp=5.2;const bd=Math.hypot(b.pos.x-own,b.pos.z);const gxo=1.1+clamp((26-bd)/26,0,1)*5;let l=Math.hypot(b.pos.x-own,b.pos.z)||1;tx=own+(b.pos.x-own)/l*gxo;tz=clamp(b.pos.z/l*gxo*1.1,-GH*.95,GH*.95);
    const toward=b.vel.x*T.dir<-3;
    if(b.shot&&b.shot.team!==T.idx&&!b.shot.res&&toward){const tt=(own-b.pos.x)/b.vel.x;if(tt>0&&tt<2){const yy=b.pos.y+b.vel.y*tt-4.9*tt*tt,zz=b.pos.z+b.vel.z*tt;if(yy<3&&Math.abs(zz)<GH+1.8){let zt=clamp(zz,-GH-.5,GH+.5);if(this.rs&&this.rs.pen&&g.pdive){zt=g.pdive*2.4;}tz=zt;tx=own+T.dir*.7;sp=8+(g.a.reaction-60)*.05;if(tt<.5&&g.act!=='dive'){g.act='dive';g.actT=0;g.actD=.9;g.actV=(tz>g.z?1:-1)*T.dir;}}}}
    else if(this.state==='play'&&!b.owner&&bd<17&&Math.abs(b.pos.z)<20&&Math.sign(b.pos.x)===-T.dir){let closer=true;const my=Math.hypot(b.pos.x-g.x,b.pos.z-g.z);this.all.forEach(p=>{if(p!==g&&Math.hypot(b.pos.x-p.x,b.pos.z-p.z)<my-1.5)closer=false;});if(closer&&Math.hypot(b.vel.x,b.vel.z)<9){tx=b.pos.x;tz=b.pos.z;sp=7;}}
    if(T.gkRush>this.t&&this.state==='play'&&bd<30){tx=b.pos.x;tz=b.pos.z;sp=7;}
    const dx=tx-g.x,dz=tz-g.z,d=Math.hypot(dx,dz);let s=Math.min(sp,d*3.2);if(d<.15)s=0;if(g.act==='dive'){this.steer(g,d>.01?dz/d*0+0:0,d>.01?dz/d*s*1.3:0,dt);g.vx=0;g.vz=dz/(d||1)*Math.min(8.5,d*5);}else this.steer(g,d>.01?dx/d*s:0,d>.01?dz/d*s:0,dt);g.aiSet=true;if(g.act!=='dive'&&Math.hypot(b.pos.x-g.x,b.pos.z-g.z)>1)g.yaw=lerp(g.yaw,Math.atan2(b.pos.x-g.x,b.pos.z-g.z),.1);},
  /* ---------------- treinador (IA) ---------------- */
  coach(dt){this.coachT+=dt;if(this.coachT<20||this.state!=='play')return;this.coachT=0;
    this.teams.forEach(T=>{if(T.human)return;const O=this.teams[1-T.idx],diff=T.score-O.score,late=this.gmin>65&&!this.cfg.training;
      if(late&&diff<0&&T.coach.mode!=='atk'){T.coach.mode='atk';T.tac.ment=3;T.tac.press=2;T.tac.line=2;this.setFormation(T,T.formation.startsWith('3')?'3-4-3':'4-3-3');UI.toast(T.club.short+' ▲','info');}
      else if(late&&diff>0&&T.coach.mode!=='def'){T.coach.mode='def';T.tac.ment=0;T.tac.line=0;T.tac.press=0;this.setFormation(T,'5-3-2');}
      if(this.gmin>50&&T.subs<4){const tired=T.players.filter(p=>!p.sent&&p.role!=='GK'&&p.stam<38).sort((a,c)=>a.stam-c.stam)[0];if(tired){const sub=T.bench.filter(d=>d.pos!=='GK').sort((a,c)=>fitScore(c.pos,tired.role)*100+c.ovr-(fitScore(a.pos,tired.role)*100+a.ovr))[0];if(sub)this.substitute(T,tired,sub);}}});},
  setFormation(T,key){if(!FORMS[key])return;T.formation=key;const sl=FORMS[key],used=new Set();sl.forEach((s,i)=>{let best=null,bs=-1;T.players.forEach(p=>{if(p.sent||used.has(p))return;const sc=fitScore(p.d.pos,s[0])*100+p.d.ovr+(s[0]==='GK'&&p.d.pos==='GK'?1000:0);if(sc>bs){bs=sc;best=p;}});if(best){used.add(best);best.slot=s;best.role=s[0];}});},
  substitute(T,out,sub){if(T.subs>=T.maxSubs||out.sent)return false;const i=T.players.indexOf(out);const nd={d:sub};World.scene.remove(out.mesh);T.players[i]=nd;T.bench=T.bench.filter(x=>x!==sub);T.bench.push(out.d);T.subs++;
    this.spawn(nd,T,i);nd.slot=out.slot;nd.role=out.role;nd.x=out.x;nd.z=out.z;nd.yaw=out.yaw;if(T.gk===out)T.gk=nd;if(BallManager.owner===out)BallManager.owner=null;if(this.sel===out)this.sel=nd;this.refreshAll();this.refreshShadows();return true;},
  /* ---------------- árbitro ---------------- */
  refUpdate(dt){const r=this.ref;if(!r)return;const b=BallManager.pos;const tx=b.x*.8-Math.sign(b.x||1)*6,tz=clamp(b.z+14,-HW+4,HW-2);const dx=tx-r.x,dz=tz-r.z,d=Math.hypot(dx,dz);const sp=Math.min(6.5,d*1.2);r.vx=d>.1?dx/d*sp:0;r.vz=d>.1?dz/d*sp:0;r.x+=r.vx*dt;r.z+=r.vz*dt;const s=Math.hypot(r.vx,r.vz);r.ph=(r.ph||0)+dt*(4+s);r.spdN=lerp(r.spdN||0,s/8,.2);r.yaw=Math.atan2(b.x-r.x,b.z-r.z);r.act='';r.lean=0;r.mesh=r.root;AnimationManager.pose(r,r);},
  /* ---------------- câmera / sincronização ---------------- */
  introSpecial(){const a=this.introT*.5;return{cam:true,pos:new THREE.Vector3(Math.sin(a+.5)*45,9+this.introT*3,Math.cos(a+.5)*45),look:new THREE.Vector3(0,1,0),fov:42};},
  goalSpecial(){if(this.state==='goal'&&this.goalInfo&&this.goalInfo.scorer){const s=this.goalInfo.scorer;return{cam:true,pos:new THREE.Vector3(s.x-Math.sin(s.yaw)*-6+3,3.2,s.z+7),look:new THREE.Vector3(s.x,1.3,s.z),fov:34};}
    if(this.state==='restart'&&this.rs&&this.rs.type==='penalty'){const T=this.teams[this.rs.team];return{cam:true,pos:new THREE.Vector3(T.dir*(HL-26),7,0),look:new THREE.Vector3(T.dir*HL,1,0),fov:34};}return null;},
  cameraStep(dt,special){if(this.cfg.demo){CameraManager.menu(dt);return;}const b=BallManager;CameraManager.update(dt,{x:b.pos.x,z:b.pos.z,vx:b.vel.x,vz:b.vel.z},this.sel,SaveManager.data.settings.cam,special);},
  animateAll(dt,idle){},
  syncAll(dt){for(const p of this.all)AnimationManager.pose(p,p);BallManager.sync(dt);
    if(this.sel&&!this.sel.sent&&this.state!=='intro'&&this.state!=='full'){this.ring.visible=this.arrow.visible=true;this.ring.position.set(this.sel.x,.06,this.sel.z);this.arrow.position.set(this.sel.x,2.6+Math.sin(this.t*5)*.12,this.sel.z);this.ring.rotation.z+=dt;}else this.ring.visible=this.arrow.visible=false;
    if(this.pendingReplay&&this.t>this.pendingReplay&&this.state==='play'){this.pendingReplay=0;this.startReplay(null);}},
  /* ---------------- replay ---------------- */
  snapshot(){const n=this.all.length,RN=240;let f=this.rec[this.recI%RN];if(!f||f.n!==n){f=this.rec[this.recI%RN]={n,p:new Float32Array(n*8),a:new Array(n),b:new Float32Array(3)};}
    for(let i=0;i<n;i++){const p=this.all[i],k=i*8;f.p[k]=p.x;f.p[k+1]=p.z;f.p[k+2]=p.yaw;f.p[k+3]=p.ph;f.p[k+4]=p.spdN;f.p[k+5]=p.actT;f.p[k+6]=p.actD;f.p[k+7]=p.actV;f.a[i]=p.act;}
    f.b[0]=BallManager.pos.x;f.b[1]=BallManager.pos.y;f.b[2]=BallManager.pos.z;this.recI++;this.recN=Math.min(this.recN+1,RN);},
  startReplay(after){if(this.cfg.demo){if(after)after();return;}const RN=240,len=Math.min(this.recN,115);if(len<30){if(after)after();return;}const fr=[];for(let i=len;i>=1;i--){const f=this.rec[(this.recI-i+RN*10)%RN];if(f&&f.n===this.all.length)fr.push(f);}if(fr.length<20){if(after)after();return;}
    this.prevState=this.state;this.state='replay';this.rp={fr,t:0,after,len:fr.length};UI.replayShow(true);AudioManager.sfx('trans');},
  skipReplay(){if(this.rp)this.rp.t=1e9;},
  updateReplay(dt){const r=this.rp;r.t+=dt*30*.6;const i=Math.min(r.len-1,Math.floor(r.t)),f=r.fr[i],n=this.all.length;const tmp=this.tmp;
    for(let k=0;k<n;k++){const p=this.all[k],o=k*8;tmp.x=f.p[o];tmp.z=f.p[o+1];tmp.yaw=f.p[o+2];tmp.ph=f.p[o+3];tmp.spdN=f.p[o+4];tmp.actT=f.p[o+5]+(r.t-i)*.033;tmp.actD=f.p[o+6];tmp.actV=f.p[o+7];tmp.act=f.a[k];tmp.lean=.08*Math.min(1,tmp.spdN);tmp.shield=false;AnimationManager.pose(p,tmp);}
    const m=BallManager.mesh;m.position.set(f.b[0],f.b[1],f.b[2]);const bx=f.b[0],bz=f.b[2],seg=r.t/r.len;let pos,look;
    if(seg<.4){pos=new THREE.Vector3(bx-9,5,bz+14);look=new THREE.Vector3(bx+3,1,bz);}else if(seg<.75){const gs=Math.sign(bx)||1;pos=new THREE.Vector3(gs*(HL+16),6,bz*.5);look=new THREE.Vector3(bx,1.2,bz);}else{pos=new THREE.Vector3(bx*.7,28,36);look=new THREE.Vector3(bx,0,bz);}
    CameraManager.update(dt,{x:bx,z:bz,vx:0,vz:0},null,'broadcast',{cam:true,pos,look,fov:seg<.4?34:seg<.75?32:38});BallManager.blob.position.set(bx,.03,bz);
    if(r.t>=r.len-1){UI.replayShow(false);const a=r.after;this.rp=null;this.state=this.prevState==='replay'?'play':this.prevState;this.syncAll(0);if(a)a();else this.state='play';}},
  /* ---------------- intervalo / fim ---------------- */
  halfTime(){this.state='halftime';this.timer=3.2;AudioManager.sfx('whistle2');UI.toast(t('half')+'  '+this.teams[0].score+' - '+this.teams[1].score,'info',3000);this.gmin=45;BallManager.owner=null;},
  fullTime(){if(this.state==='full')return;this.state='full';if(this.cfg.demo){setTimeout(()=>{if(this.active&&this.state==='full'&&this.cfg.demo)UI.startDemo();},900);return;}AudioManager.sfx('whistle2');AudioManager.crowd(.6);const t0=this.teams[0],t1=this.teams[1],tot=t0.poss+t1.poss||1;
    this.res={home:this.cfg.home,away:this.cfg.away,hs:t0.score,as:t1.score,log:this.log.slice(),stats:{poss:[Math.round(t0.poss/tot*100),100-Math.round(t0.poss/tot*100)],shots:[t0.shots,t1.shots],onT:[t0.onT,t1.onT],fouls:[t0.fouls,t1.fouls],yel:[t0.yel,t1.yel],red:[t0.red,t1.red],corners:[t0.corners,t1.corners]},teams:[t0.club.short,t1.club.short]};
    setTimeout(()=>{if(this.state==='full')UI.showResult(this.res);},1600);},
  quit(){this.active=false;this.cleanup();UI.hudShow(false);},
  /* ---------------- pausa / HUD ---------------- */
  togglePause(){if(!this.active||this.state==='full'||this.state==='intro'||this.state==='replay')return;if(this.paused){this.paused=false;UI.hidePause();}else{this.paused=true;UI.showPause();}},
  updateScoreboard(){const a=this.teams[0],b=this.teams[1];if(!a)return;const m=Math.floor(this.gmin),mm=String(m).padStart(2,'0');World.drawScore(a.club.short,b.club.short,a.score,b.score,this.cfg.training?'TREINO':mm+"'");},
  hudTick(dt){this.hudT-=dt;if(this.hudT>0&&this.hint<=0)return;this.hudT=.1;this.hint-=.1;const T=this.teams[0],O=this.teams[1],s=this.sel;const m=Math.floor(this.gmin),sec=Math.floor((this.gmin%1)*60);
    UI.hudUpdate({hs:T.score,as:O.score,time:this.cfg.training?'TREINO':String(m).padStart(2,'0')+':'+String(sec).padStart(2,'0')+(this.half===2&&this.gmin>45?'':''),sel:s?('#'+s.d.num+' '+s.d.name):'',stam:s?s.stam:0,mode:InputManager.mode,charge:Math.max(InputManager.charge('pass'),InputManager.charge('shoot'),InputManager.charge('cross'),InputManager.charge('through')),gk:this.t<1e9&&(T.gk&&Math.abs(BallManager.pos.x+T.dir*HL)<35)});
    if(this.tick%3===0){this.radarT=0;UI.radar(this);}
    if(Math.floor(this.gmin)!==this.lastMin){this.lastMin=Math.floor(this.gmin);this.updateScoreboard();}}
};
