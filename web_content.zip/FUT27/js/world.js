'use strict';
/* ===== FUT27 · world.js · World (estádio), PlayerManager (modelos), AnimationManager, CameraManager ===== */
const HL=52.5,HW=34,PL=105,GH=3.66,GHGT=2.44,BRAD=0.16;
const mats={};const mat=(c,o)=>{const k=c+(o||'');return mats[k]||(mats[k]=new THREE.MeshLambertMaterial(Object.assign({color:c},o||{})));};

const World={
  scene:null,cam:null,hemi:null,sun:null,spots:[],pitchMat:null,crowd:null,crowdHead:null,crowdBase:null,crowdN:0,crowdPh:null,flags:[],rain:null,rainN:0,scoreCv:null,scoreTex:null,excite:0,exciteT:0,lightHeads:[],roofs:[],adMats:[],part:null,frame:0,weather:'sunny',stadium:null,kitC:['#d62828','#1d4ed8'],
  init(){const r=GraphicsManager.renderer;this.scene=new THREE.Scene();this.cam=new THREE.PerspectiveCamera(40,innerWidth/innerHeight,.5,500);
    this.hemi=new THREE.HemisphereLight(0xffffff,0x3a5a35,.85);this.scene.add(this.hemi);
    this.sun=new THREE.DirectionalLight(0xfff1d0,1.1);this.sun.position.set(-30,70,25);const sc=this.sun.shadow.camera;sc.left=-72;sc.right=72;sc.top=52;sc.bottom=-52;sc.near=10;sc.far=190;this.sun.shadow.bias=-.0004;this.scene.add(this.sun,this.sun.target);
    this.buildPitch();this.buildGoals();this.buildAds();this.buildStands();this.buildExtras();this.buildScoreboard();this.buildRain();this.part=new Particles(500);this.scene.add(this.part.pts);
    this.applyStadium(0,['#d62828','#1d4ed8']);this.applyWeather('sunny');this.applyQuality();},
  applyQuality(){const P=GraphicsManager.profile();this.sun.castShadow=P.shadow;if(this.sun.shadow.map){this.sun.shadow.map.dispose();this.sun.shadow.map=null;}this.sun.shadow.mapSize.set(P.sm,P.sm);
    this.buildCrowd(P.crowd);this.rainN=P.rain;this.rain.geometry.setDrawRange(0,this.rainN*2);this.spots.forEach(s=>s.visible=P.spots&&this.weather==='night');this.applyWeather(this.weather);
    this.scene.traverse(o=>{if(o.material&&o.material.needsUpdate!==undefined)o.material.needsUpdate=true;});if(typeof MatchManager!=='undefined'&&MatchManager.active)MatchManager.refreshShadows();},
  /* ---------- gramado ---------- */
  buildPitch(){const W=2048,H=1365,k=W/120,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');
    for(let i=0;i<16;i++){g.fillStyle=i%2?'#2f7d32':'#348a37';g.fillRect(i*W/16,0,W/16+1,H);}
    for(let i=0;i<9000;i++){g.fillStyle=Math.random()<.5?'rgba(0,40,0,.05)':'rgba(255,255,255,.035)';g.fillRect(Math.random()*W,Math.random()*H,2+Math.random()*3,2+Math.random()*3);}
    const X=x=>(x+60)*k,Y=z=>(z+40)*k;g.strokeStyle='rgba(255,255,255,.92)';g.lineWidth=3;g.fillStyle='rgba(255,255,255,.92)';
    g.strokeRect(X(-HL),Y(-HW),PL*k,68*k);g.beginPath();g.moveTo(X(0),Y(-HW));g.lineTo(X(0),Y(HW));g.stroke();g.beginPath();g.arc(X(0),Y(0),9.15*k,0,7);g.stroke();g.beginPath();g.arc(X(0),Y(0),.35*k,0,7);g.fill();
    [-1,1].forEach(s=>{const gx=s*HL;g.strokeRect(s>0?X(gx-16.5):X(gx),Y(-20.16),16.5*k,40.32*k);g.strokeRect(s>0?X(gx-5.5):X(gx),Y(-9.16),5.5*k,18.32*k);
      const px=gx-s*11;g.beginPath();g.arc(X(px),Y(0),.3*k,0,7);g.fill();g.save();g.beginPath();g.rect(s>0?0:X(gx-s*16.5),0,s>0?X(gx-16.5):W,H);g.clip();g.beginPath();g.arc(X(px),Y(0),9.15*k,0,7);g.stroke();g.restore();});
    [[-1,-1],[-1,1],[1,-1],[1,1]].forEach(q=>{g.beginPath();g.arc(X(q[0]*HL),Y(q[1]*HW),1*k,0,7);g.stroke();});
    const tx=new THREE.CanvasTexture(c);tx.encoding=THREE.sRGBEncoding;tx.anisotropy=4;this.pitchMat=new THREE.MeshStandardMaterial({map:tx,roughness:.92,metalness:0});
    const p=new THREE.Mesh(new THREE.PlaneGeometry(120,80),this.pitchMat);p.rotation.x=-Math.PI/2;p.receiveShadow=true;this.scene.add(p);
    const o=new THREE.Mesh(new THREE.PlaneGeometry(500,500),new THREE.MeshLambertMaterial({color:0x26402a}));o.rotation.x=-Math.PI/2;o.position.y=-.05;this.scene.add(o);},
  buildGoals(){const nc=document.createElement('canvas');nc.width=nc.height=64;const g=nc.getContext('2d');g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=3;g.strokeRect(0,0,64,64);const nt=new THREE.CanvasTexture(nc);nt.wrapS=nt.wrapT=THREE.RepeatWrapping;nt.repeat.set(10,5);
    const netM=new THREE.MeshBasicMaterial({map:nt,transparent:true,opacity:.55,side:THREE.DoubleSide,depthWrite:false});const post=mat(0xffffff),D=2.2;
    [-1,1].forEach(s=>{const gr=new THREE.Group();gr.position.x=s*HL;[-GH,GH].forEach(z=>{const m=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,GHGT,8),post);m.position.set(0,GHGT/2,z);m.castShadow=true;gr.add(m);const b=new THREE.Mesh(new THREE.CylinderGeometry(.04,.04,GHGT,6),post);b.position.set(s*D,GHGT/2,z);gr.add(b);});
      const bar=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,GH*2,8),post);bar.rotation.x=Math.PI/2;bar.position.y=GHGT;bar.castShadow=true;gr.add(bar);
      const back=new THREE.Mesh(new THREE.PlaneGeometry(GH*2,GHGT),netM);back.rotation.y=Math.PI/2;back.position.set(s*D,GHGT/2,0);gr.add(back);
      [-1,1].forEach(z=>{const sd=new THREE.Mesh(new THREE.PlaneGeometry(D,GHGT),netM);sd.position.set(s*D/2,GHGT/2,z*GH);gr.add(sd);});
      const top=new THREE.Mesh(new THREE.PlaneGeometry(D,GH*2),netM);top.rotation.x=Math.PI/2;top.position.set(s*D/2,GHGT,0);gr.add(top);this.scene.add(gr);});},
  buildAds(){const c=document.createElement('canvas');c.width=2048;c.height=64;const g=c.getContext('2d');const names=['FUT27','ROYAL BANK','SOL ENERGIA','AEROLINE','NOVA TELECOM','TURBO MOTORS','GRANDE COLA','ARENA+'],cols=['#0b3d2e','#1d3b8a','#c2410c','#0e7490','#6d28d9','#b91c1c','#be123c','#15803d'];
    for(let i=0;i<8;i++){g.fillStyle=cols[i];g.fillRect(i*256,0,256,64);g.fillStyle='#fff';g.font='italic bold 34px Arial';g.textAlign='center';g.textBaseline='middle';g.fillText(names[i],i*256+128,34);}
    const tx=new THREE.CanvasTexture(c);tx.encoding=THREE.sRGBEncoding;tx.wrapS=THREE.RepeatWrapping;this.adTex=tx;
    [[0,-HW-3,110,0],[0,HW+3,110,Math.PI],[-HL-5,0,74,Math.PI/2],[HL+5,0,74,-Math.PI/2]].forEach(a=>{const t2=tx.clone();t2.needsUpdate=true;t2.repeat.set(a[2]/55,1);const m=new THREE.MeshBasicMaterial({map:t2});const b=new THREE.Mesh(new THREE.BoxGeometry(a[2],.95,.15),[mat(0x111111),mat(0x111111),mat(0x111111),mat(0x111111),m,mat(0x111111)]);b.position.set(a[0],.48,a[1]);b.rotation.y=a[3];this.scene.add(b);this.adMats.push(t2);});},
  buildStands(){const rows=14,dR=.95,hR=.62;this.standCfg=[];
    [[0,0,40,124],[1,Math.PI,40,124],[2,-Math.PI/2,62,90],[3,Math.PI/2,62,90]].forEach(s=>{const gr=new THREE.Group();gr.rotation.y=s[1];const D0=s[2],L=s[3],slant=Math.hypot(rows*dR,rows*hR),phi=Math.atan2(hR,dR);
      const ramp=new THREE.Mesh(new THREE.PlaneGeometry(L,slant),new THREE.MeshLambertMaterial({color:0x777d85,side:THREE.DoubleSide}));ramp.geometry.rotateX(-Math.PI/2+phi);ramp.position.set(0,rows*hR/2,-(D0+rows*dR/2));gr.add(ramp);this.standMesh=this.standMesh||[];this.standMesh.push(ramp);
      const wall=new THREE.Mesh(new THREE.BoxGeometry(L,rows*hR+3,.6),mat(0x2b2f36));wall.position.set(0,(rows*hR+3)/2,-(D0+rows*dR+.4));gr.add(wall);
      const front=new THREE.Mesh(new THREE.BoxGeometry(L,1.1,.3),mat(0x3a3f47));front.position.set(0,.55,-(D0-.2));gr.add(front);
      if(s[0]===0||s[0]===2||s[0]===3){const roof=new THREE.Mesh(new THREE.BoxGeometry(L,.5,10),mat(0x1c2026));roof.position.set(0,rows*hR+4.5,-(D0+rows*dR-3));roof.rotation.x=.08;gr.add(roof);this.roofs.push(roof);}
      this.scene.add(gr);this.standCfg.push({yaw:s[1],D0,L,rows,dR,hR});});},
  buildExtras(){const pole=mat(0x555a62),head=new THREE.MeshBasicMaterial({color:0xffffff});
    [[-1,-1],[-1,1],[1,-1],[1,1]].forEach(q=>{const x=q[0]*68,z=q[1]*50;const p=new THREE.Mesh(new THREE.BoxGeometry(.9,32,.9),pole);p.position.set(x,16,z);this.scene.add(p);const h=new THREE.Mesh(new THREE.BoxGeometry(7,3.4,1),head.clone());h.position.set(x,32.5,z);h.lookAt(0,0,0);this.scene.add(h);this.lightHeads.push(h);
      const sp=new THREE.SpotLight(0xfff6e0,0,260,.75,.55,1);sp.position.set(x,32,z);sp.target.position.set(0,0,0);this.scene.add(sp,sp.target);this.spots.push(sp);});
    /* bandeirinhas de escanteio */
    [[-1,-1],[-1,1],[1,-1],[1,1]].forEach(q=>{const f=new THREE.Mesh(new THREE.CylinderGeometry(.03,.03,1.5,5),mat(0xffffff));f.position.set(q[0]*HL,.75,q[1]*HW);this.scene.add(f);const fl=new THREE.Mesh(new THREE.PlaneGeometry(.45,.3),new THREE.MeshBasicMaterial({color:0xffd23f,side:THREE.DoubleSide}));fl.position.set(q[0]*HL+.22*-q[0],1.35,q[1]*HW);this.scene.add(fl);});
    /* túnel e bancos */
    const tun=new THREE.Mesh(new THREE.BoxGeometry(9,4.2,7),mat(0x0b0d10));tun.position.set(0,2.1,-(HW+8));this.scene.add(tun);const tf=new THREE.Mesh(new THREE.BoxGeometry(9.6,.4,.6),new THREE.MeshBasicMaterial({color:0xf0b429}));tf.position.set(0,4.3,-(HW+4.6));this.scene.add(tf);this.trim=tf;
    [-12,12].forEach(x=>{const b=new THREE.Group();const bench=new THREE.Mesh(new THREE.BoxGeometry(7,.5,.7),mat(0x1f2937));bench.position.y=.5;const roof=new THREE.Mesh(new THREE.BoxGeometry(7.4,.15,1.6),new THREE.MeshLambertMaterial({color:0x9bd8ff,transparent:true,opacity:.35}));roof.position.set(0,2,.2);const back=new THREE.Mesh(new THREE.BoxGeometry(7,1.6,.1),mat(0x1f2937));back.position.set(0,1.2,.5);b.add(bench,roof,back);b.position.set(x,0,HW+5.2);this.scene.add(b);});},
  buildScoreboard(){const c=document.createElement('canvas');c.width=512;c.height=128;this.scoreCv=c;this.scoreTex=new THREE.CanvasTexture(c);this.scoreTex.encoding=THREE.sRGBEncoding;
    const m=new THREE.Mesh(new THREE.PlaneGeometry(26,6.5),new THREE.MeshBasicMaterial({map:this.scoreTex}));m.position.set(0,15.5,-(40+14*.95+.2));this.scene.add(m);this.drawScore('FUT27','',0,0,'');},
  drawScore(h,a,hs,as,tm){const c=this.scoreCv,g=c.getContext('2d');g.fillStyle='#07140f';g.fillRect(0,0,512,128);g.fillStyle='#f0b429';g.fillRect(0,0,512,8);g.fillStyle='#fff';g.font='italic 800 44px Arial';g.textAlign='center';g.textBaseline='middle';
    if(a){g.fillText(h+'  '+hs+' - '+as+'  '+a,256,60);g.fillStyle='#f0b429';g.font='bold 30px Arial';g.fillText(tm,256,104);}else{g.fillText(h,256,70);}this.scoreTex.needsUpdate=true;},
  /* ---------- torcida (instancing) ---------- */
  buildCrowd(sp){if(this.crowd){this.scene.remove(this.crowd);this.crowd.geometry.dispose();this.crowd.dispose();}if(this.crowdHead){this.scene.remove(this.crowdHead);this.crowdHead.dispose();this.crowdHead=null;}
    const pos=[];const v=new THREE.Vector3();
    this.standCfg.forEach(s=>{const n=Math.floor(s.L/sp);for(let r=0;r<s.rows;r++)for(let i=0;i<n;i++){const a=(i-n/2+.5)*sp+(r%2?sp*.5:0);v.set(a,r*s.hR+.5,-(s.D0+r*s.dR+.5)).applyAxisAngle(new THREE.Vector3(0,1,0),s.yaw);pos.push(v.x,v.y,v.z);}});
    const N=pos.length/3;this.crowdN=N;this.crowdBase=new Float32Array(pos);this.crowdPh=new Float32Array(N);for(let i=0;i<N;i++)this.crowdPh[i]=Math.random()*6.28;
    this.crowd=new THREE.InstancedMesh(new THREE.BoxGeometry(.55*Math.max(1,sp*.7),.9,.4),new THREE.MeshLambertMaterial({color:0xffffff}),N);this.crowd.frustumCulled=false;this.scene.add(this.crowd);
    if(GraphicsManager.profile().detail>=2){this.crowdHead=new THREE.InstancedMesh(new THREE.SphereGeometry(.17,6,5),new THREE.MeshLambertMaterial({color:0xffffff}),N);this.crowdHead.frustumCulled=false;this.scene.add(this.crowdHead);}
    this.writeCrowd(0);this.colorCrowd();
    this.flags.forEach(f=>this.scene.remove(f));this.flags=[];const nf=GraphicsManager.q==='low'?6:18;
    for(let i=0;i<nf;i++){const k=Math.floor(Math.random()*N),f=new THREE.Mesh(new THREE.PlaneGeometry(1.6,1),new THREE.MeshBasicMaterial({color:new THREE.Color(this.kitC[i%2]),side:THREE.DoubleSide}));f.position.set(this.crowdBase[k*3],this.crowdBase[k*3+1]+2.2,this.crowdBase[k*3+2]);f.userData.p=Math.random()*6;this.scene.add(f);this.flags.push(f);}},
  colorCrowd(){if(!this.crowd||!this.stadium)return;const pal=this.stadium.crowd,c=new THREE.Color(),h=new THREE.Color();const k0=new THREE.Color(this.kitC[0]),k1=new THREE.Color(this.kitC[1]);
    for(let i=0;i<this.crowdN;i++){const x=this.crowdBase[i*3],r=Math.random();if(r<.5)c.copy(x<0?k0:k1);else if(r<.55)c.set(0x151515);else c.set(pal[Math.floor(Math.random()*pal.length)]);this.crowd.setColorAt(i,c);if(this.crowdHead){h.set(SKIN[Math.floor(Math.random()*SKIN.length)]);this.crowdHead.setColorAt(i,h);}}
    this.crowd.instanceColor.needsUpdate=true;if(this.crowdHead)this.crowdHead.instanceColor.needsUpdate=true;},
  writeCrowd(ex){const m=new THREE.Matrix4(),t=performance.now()*.001,B=this.crowdBase;for(let i=0;i<this.crowdN;i++){const y=B[i*3+1]+(ex>0?Math.abs(Math.sin(t*(6+ex*4)+this.crowdPh[i]))*.38*ex:0);m.setPosition(B[i*3],y,B[i*3+2]);this.crowd.setMatrixAt(i,m);if(this.crowdHead){m.setPosition(B[i*3],y+.62,B[i*3+2]);this.crowdHead.setMatrixAt(i,m);}}this.crowd.instanceMatrix.needsUpdate=true;if(this.crowdHead)this.crowdHead.instanceMatrix.needsUpdate=true;},
  cheer(v){this.excite=Math.max(this.excite,v);},
  applyStadium(idx,kit){const s=STADIUMS[idx];this.stadium=s;this.kitC=kit||this.kitC;this.standMesh.forEach(m=>m.material.color.set(s.stand));this.roofs.forEach(r=>r.visible=s.roof&&GraphicsManager.q!=='low');this.trim.material.color.set(s.trim);
    this.adMats.forEach((a,i)=>{a.offset.x=((s.ad+i*2)%8)/8;});this.colorCrowd();this.flags.forEach((f,i)=>f.material.color.set(this.kitC[i%2]));},
  applyWeather(w){this.weather=w;const C={sunny:{bg:0x8fc9ff,fog:[140,340],hemi:.85,sun:1.15,sc:0xfff1d0,wet:false,rain:false},cloudy:{bg:0xa5b4c0,fog:[100,300],hemi:1,sun:.5,sc:0xdfe8f0,wet:false,rain:false},rain:{bg:0x59646d,fog:[70,220],hemi:.85,sun:.4,sc:0xcfdbe6,wet:true,rain:true},night:{bg:0x040814,fog:[90,280],hemi:.32,sun:.3,sc:0x9fb4ff,wet:false,rain:false,night:true}}[w];
    this.scene.background=new THREE.Color(C.bg);this.scene.fog=new THREE.Fog(C.bg,C.fog[0],C.fog[1]);this.hemi.intensity=C.hemi*(C.night&&!GraphicsManager.profile().spots?1.5:1);this.sun.intensity=C.sun;this.sun.color.set(C.sc);
    this.pitchMat.roughness=C.wet?.28:.92;this.pitchMat.metalness=C.wet?.18:0;this.pitchMat.color.set(C.wet?0xb5c4b5:C.night?0xdddddd:0xffffff);this.rain.visible=C.rain;this.spots.forEach(s=>{s.visible=!!C.night&&GraphicsManager.profile().spots;s.intensity=C.night?1.1:0;});
    this.lightHeads.forEach(h=>h.material.color.set(C.night?0xffffee:0x9aa0a8));AudioManager.rain(C.rain);if(w==='night')this.trim.material.color.set(0xffffff);},
  buildRain(){const N=1700,pos=new Float32Array(N*6);for(let i=0;i<N;i++){const x=(Math.random()-.5)*110,y=Math.random()*40,z=(Math.random()-.5)*80;pos.set([x,y,z,x-.35,y-1,z+.1],i*6);}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));this.rain=new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:0xcfe3ff,transparent:true,opacity:.45}));this.rain.frustumCulled=false;this.scene.add(this.rain);},
  update(dt,fx,fz){this.frame++;
    if(this.rain.visible){const a=this.rain.geometry.attributes.position.array,N=this.rainN,d=34*dt;for(let i=0;i<N;i++){const k=i*6;let y=a[k+1]-d;if(y<0)y+=40;a[k+1]=y;a[k+4]=y-1;}this.rain.geometry.attributes.position.needsUpdate=true;this.rain.position.set(fx*.8,0,fz*.5);}
    this.exciteT+=dt;this.excite=Math.max(0,this.excite-dt*.22);AudioManager.crowd(.12+this.excite*.55);
    if(this.excite>.04&&this.frame%(GraphicsManager.q==='low'?4:2)===0)this.writeCrowd(this.excite);else if(this.excite<=.04&&this.excite>0&&this.frame%30===0)this.writeCrowd(0);
    this.flags.forEach(f=>{f.rotation.z=Math.sin(this.exciteT*(2+this.excite*6)+f.userData.p)*(.15+this.excite*.5);});
    this.part.update(dt);},
  menuIdle(dt,t){}
};

class Particles{
  constructor(n){this.n=n;this.pos=new Float32Array(n*3);this.col=new Float32Array(n*3);this.vel=new Float32Array(n*3);this.life=new Float32Array(n);this.g=-9;this.next=0;
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(this.pos,3));g.setAttribute('color',new THREE.BufferAttribute(this.col,3));this.pts=new THREE.Points(g,new THREE.PointsMaterial({size:.42,vertexColors:true,transparent:true,sizeAttenuation:true,depthWrite:false}));this.pts.frustumCulled=false;for(let i=0;i<n;i++)this.pos[i*3+1]=-50;}
  emit(x,y,z,count,spread,speed,cols,life){const lim=GraphicsManager.q==='low'?.4:1;count=Math.ceil(count*lim);const c=new THREE.Color();for(let k=0;k<count;k++){const i=this.next;this.next=(this.next+1)%this.n;this.pos[i*3]=x;this.pos[i*3+1]=y;this.pos[i*3+2]=z;this.vel[i*3]=(Math.random()-.5)*spread;this.vel[i*3+1]=Math.random()*speed;this.vel[i*3+2]=(Math.random()-.5)*spread;this.life[i]=life*(.6+Math.random()*.6);c.set(cols[Math.floor(Math.random()*cols.length)]);this.col[i*3]=c.r;this.col[i*3+1]=c.g;this.col[i*3+2]=c.b;}}
  update(dt){let any=false;for(let i=0;i<this.n;i++){if(this.life[i]<=0)continue;any=true;this.life[i]-=dt;if(this.life[i]<=0){this.pos[i*3+1]=-50;continue;}this.vel[i*3+1]+=this.g*dt;this.pos[i*3]+=this.vel[i*3]*dt;this.pos[i*3+1]+=this.vel[i*3+1]*dt;this.pos[i*3+2]+=this.vel[i*3+2]*dt;if(this.pos[i*3+1]<.05){this.pos[i*3+1]=.05;this.vel[i*3+1]*=-.3;this.vel[i*3]*=.6;this.vel[i*3+2]*=.6;}}if(any){this.pts.geometry.attributes.position.needsUpdate=true;this.pts.geometry.attributes.color.needsUpdate=true;}}
}

/* ================= JOGADORES 3D (low-poly procedural) ================= */
const PlayerManager={
  G:null,
  init(){const C=THREE;this.G={thigh:new C.CylinderGeometry(.085,.065,.46,7),shin:new C.CylinderGeometry(.062,.05,.46,7),leg:new C.CylinderGeometry(.08,.05,.92,6),boot:new C.BoxGeometry(.1,.07,.27),torso:new C.CylinderGeometry(.215,.165,.54,8),shorts:new C.CylinderGeometry(.17,.19,.24,8),up:new C.CylinderGeometry(.055,.048,.3,6),fo:new C.CylinderGeometry(.045,.04,.28,6),hand:new C.SphereGeometry(.05,6,5),neck:new C.CylinderGeometry(.055,.06,.1,6),head:new C.SphereGeometry(.112,10,8),eye:new C.SphereGeometry(.014,4,3),
      hair1:new C.SphereGeometry(.12,8,5,0,6.3,0,1.35),hair2:new C.SphereGeometry(.17,8,6),hair4:new C.BoxGeometry(.04,.07,.2),hair5:new C.SphereGeometry(.135,7,5),hair3b:new C.BoxGeometry(.2,.2,.07),blob:new C.CircleGeometry(.5,12),ring:new C.RingGeometry(.62,.78,24),arrow:new C.ConeGeometry(.18,.4,4)};},
  build(d,kit,opts){/* retorna {root,parts} */const G=this.G,det=GraphicsManager.profile().detail,o=opts||{};const root=new THREE.Group(),body=new THREE.Group();root.add(body);
    const k1=mat(kit.c1),k2=mat(kit.c2),sk=mat(d.skin),P={body};const sc=(o.ref?1.72:d.h)/1.76;
    const mk=(g,m,x,y,z,par)=>{const e=new THREE.Mesh(g,m);e.position.set(x,y,z);(par||body).add(e);return e;};
    const sock=mat(kit.sock||kit.c1),boot=mat(d.boot);
    [-1,1].forEach(s=>{const hip=new THREE.Group();hip.position.set(s*.1,.93,0);body.add(hip);P['hip'+s]=hip;
      if(det>=1){mk(G.thigh,k2,0,-.22,0,hip);const kn=new THREE.Group();kn.position.y=-.45;hip.add(kn);P['kn'+s]=kn;mk(G.shin,sock,0,-.23,0,kn);mk(G.boot,boot,0,-.5,.06,kn);}
      else{mk(G.leg,sock,0,-.46,0,hip);mk(G.boot,boot,0,-.92,.06,hip);}
      const sh=new THREE.Group();sh.position.set(s*.27,1.42,0);body.add(sh);P['sh'+s]=sh;mk(G.up,k1,0,-.14,0,sh);const el=new THREE.Group();el.position.y=-.29;sh.add(el);P['el'+s]=el;mk(G.fo,sk,0,-.13,0,el);if(det>=1)mk(G.hand,sk,0,-.29,0,el);});
    const tor=mk(G.torso,k1,0,1.2,0);tor.scale.set(1.12*d.build,1,.85*d.build);P.torso=tor;const shs=mk(G.shorts,k2,0,.95,0);shs.scale.set(d.build,1,.9*d.build);
    if(det>=1)mk(G.neck,sk,0,1.5,0);const head=mk(G.head,sk,0,1.64,0);head.scale.set(1,1.1,1.02);
    if(det>=2){[-1,1].forEach(s=>mk(G.eye,mat(0x111111),s*.04,1.66,.1));}
    const hm=mat(d.hairC);if(d.hair===1)mk(G.hair1,hm,0,1.67,0);else if(d.hair===2)mk(G.hair2,hm,0,1.69,-.01);else if(d.hair===3){mk(G.hair1,hm,0,1.67,0);mk(G.hair3b,hm,0,1.6,-.09);}else if(d.hair===4)mk(G.hair4,hm,0,1.76,0);else if(d.hair===5){const h=mk(G.hair5,hm,0,1.7,0);h.scale.y=.75;}
    root.scale.set(sc*(o.ref?1:d.build*.98+.02),sc,sc*(o.ref?1:d.build*.98+.02));
    root.traverse(m=>{if(m.isMesh)m.castShadow=GraphicsManager.profile().shadow&&det>=1;});
    const blob=new THREE.Mesh(G.blob,new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:.28,depthWrite:false}));blob.rotation.x=-Math.PI/2;blob.position.y=.03;blob.scale.setScalar(.7);root.add(blob);P.blob=blob;blob.visible=!GraphicsManager.profile().shadow;
    return{root,parts:P};}
};

/* ================= ANIMAÇÃO PROCEDURAL ================= */
const sm=t=>t<=0?0:t>=1?1:t*t*(3-2*t);
const AnimationManager={
  /* s: estado {x,z,yaw,ph,spdN,act,actT,actD,actV,lean,shield,jump}  —  usado tanto ao vivo quanto no replay */
  pose(mp,s){const P=mp.parts,root=mp.mesh;if(!P)return;const run=Math.min(1,s.spdN),fast=Math.max(0,s.spdN-1),ph=s.ph;
    let lh=Math.sin(ph)*(.15+.85*run)*(.8+.2*run),rh=-lh,lk=Math.max(0,-Math.sin(ph+.7))*1.25*run+.12*run,rk=Math.max(0,Math.sin(ph+.7))*1.25*run+.12*run;
    let la=Math.sin(ph)*.85*(.2+.8*run),ra=-la,le=-(.25+.75*run),re=le,lean=.1*run+.09*fast+(s.lean||0),bob=Math.abs(Math.sin(ph))*.045*run,twist=Math.sin(ph)*.14*run,by=0,bz=0,rz=0,sp=0;
    const idle=1-run;la+=Math.sin(s.ph*.2)*.03*idle;
    if(s.shield){lean=.35;la=.2;ra=.2;sp=.7;le=-.4;re=-.4;}
    const a=s.act;if(a){const T=s.actT,D=s.actD||.5,k=clamp(T/D,0,1);
      if(a==='kick'||a==='pass'||a==='shoot'||a==='cross'){const big=a==='shoot'||a==='cross'?1:.6,sd=s.actV>=0?1:-1;let sw;if(k<.35){sw=-sm(k/.35)*(.9*big+.1);}else if(k<.55){sw=lerp(-(.9*big+.1),1.5*big,sm((k-.35)/.2));}else sw=lerp(1.5*big,0,sm((k-.55)/.45));
        const kb=k<.35?1.2*sm(k/.35):k<.55?lerp(1.2,.15,sm((k-.35)/.2)):lerp(.15,.2,sm((k-.55)/.45));
        if(sd>0){rh=sw;rk=kb;lh=-.2;lk=.3;}else{lh=sw;lk=kb;rh=-.2;rk=.3;}
        la=sd>0?-.8*big:.8*big;ra=-la;lean=a==='cross'?-.15:.12;}
      else if(a==='head'){const j=Math.sin(k*Math.PI);by=j*.7;lean=lerp(-.5,.5,sm(k));la=ra=-1.4;lh=-.3;rh=.3;lk=rk=.6;}
      else if(a==='slide'){const f=sm(clamp(k*5,0,1))*(k>.75?1-sm((k-.75)/.25):1);lean=-1.2*f;by=-.55*f;rh=1.45*f;rk=.1;lh=.6*f;lk=1.2*f;la=-1.5*f;ra=1.1*f;}
      else if(a==='fall'){const f=k<.12?sm(k/.12):k>.75?1-sm((k-.75)/.25):1;lean=-1.45*f;by=-.62*f;la=ra=-.6*f;lh=rh=.1;}
      else if(a==='trap'){const f=Math.sin(k*Math.PI);rh=.7*f;rk=.6*f;lean=-.1*f;}
      else if(a==='throw'){const f=k<.5?sm(k/.5):1-sm((k-.5)/.5)*.8;la=ra=-3.0*f+(k>.5?1.2*sm((k-.5)/.5):0);le=re=-.3;lean=-.3*f+.3*(k>.5?1:0);}
      else if(a==='throwhold'){la=ra=-3.1;le=re=-.25;lean=-.15;lh=-.2;rh=.2;}
      else if(a==='dive'){const f=sm(clamp(k*4,0,1))*(k>.8?1-sm((k-.8)/.2):1),sd=s.actV>=0?1:-1;bz=sd*1.35*f;by=.55*f;la=ra=-2.8*f;le=re=-.1;lh=.4*f;rh=-.3*f;rz=0;lean=0;}
      else if(a==='catch'){const f=Math.sin(Math.min(1,k*1.5)*Math.PI*.5);la=ra=-1.7*f;le=re=-.9*f;lean=.2*f;}
      else if(a==='celeb'){const v=s.actV|0,t2=s.actT;if(v===0){la=ra=-2.9;le=re=-.2;by=Math.abs(Math.sin(t2*8))*.35;lean=-.1;}else if(v===1){lean=-.75;by=-.35;la=-2.2;ra=-1.0;le=re=-.3;lh=-1.0;rk=1.9;lk=.4;}else if(v===2){sp=1.3;la=ra=-.1;le=re=-.1;lean=.1;by=Math.abs(Math.sin(t2*6))*.2;twist=Math.sin(t2*3)*.4;}else{la=-3.0;ra=-.2;le=-.2*0-1.3;re=-.3;by=Math.abs(Math.sin(t2*10))*.3;}}
      else if(a==='stand'){lean=.05;}
    }
    P.hip1.rotation.x=-rh;P['hip-1'].rotation.x=-lh;if(P.kn1){P.kn1.rotation.x=rk;P['kn-1'].rotation.x=lk;}
    P.sh1.rotation.x=ra;P['sh-1'].rotation.x=la;P['sh-1'].rotation.z=-.1-sp;P.sh1.rotation.z=.1+sp;P['el-1'].rotation.x=le;P.el1.rotation.x=re;
    P.body.rotation.x=lean;P.body.rotation.y=twist;P.body.rotation.z=bz;P.body.position.y=bob+by;P.body.position.x=bz*.12;
    root.position.set(s.x,0,s.z);root.rotation.y=s.yaw;P.blob.scale.setScalar(.7*(1-by*.3));}
};

/* ================= CÂMERA ================= */
const CameraManager={
  mode:'broadcast',fx:0,fz:0,fov:40,pos:new THREE.Vector3(0,24,50),look:new THREE.Vector3(),fwd:{x:0,z:-1},ang:0,shake:0,rp:null,
  modes:['broadcast','wide','dynamic','player'],
  snap(){this.pos.set(this.fx*.8,24,50);this.look.set(this.fx,0,0);},
  menu(dt){this.ang+=dt*.1;const a=this.ang;this.pos.set(Math.sin(a)*74,20+Math.sin(a*.7)*4,Math.cos(a)*74);this.look.set(0,3,0);World.cam.position.copy(this.pos);World.cam.lookAt(this.look);World.cam.fov=38;World.cam.updateProjectionMatrix();this.fwd={x:0,z:-1};},
  /* f: ponto de foco (bola), sel: jogador controlado, dir: sentido de ataque do humano */
  update(dt,f,sel,mode,special){const cam=World.cam;let tp,tl,tf=40;const k=1-Math.exp(-dt*(special?4:2.6));
    const lx=clamp(f.x+f.vx*.35,-HL-6,HL+6),lz=clamp(f.z+f.vz*.2,-HW,HW);this.fx=lerp(this.fx,lx,k);this.fz=lerp(this.fz,lz,k);
    if(special&&special.cam){tp=special.pos;tl=special.look;tf=special.fov||36;}
    else if(mode==='wide'){tp=new THREE.Vector3(this.fx*.35,40,64);tl=new THREE.Vector3(this.fx*.5,0,this.fz*.2);tf=44;this.fwd={x:0,z:-1};}
    else if(mode==='dynamic'){tp=new THREE.Vector3(this.fx-8,19,36+this.fz*.15);tl=new THREE.Vector3(this.fx+7,0,this.fz*.45);tf=42;this.fwd={x:0,z:-1};}
    else if(mode==='player'&&sel){const yx=Math.sin(sel.yaw),yz=Math.cos(sel.yaw);const fxx=lerp(this.pfx||yx,yx,.04),fzz=lerp(this.pfz||yz,yz,.04);this.pfx=fxx;this.pfz=fzz;const l=Math.hypot(fxx,fzz)||1;const dx=fxx/l,dz=fzz/l;tp=new THREE.Vector3(sel.x-dx*9,6.2,sel.z-dz*9);tl=new THREE.Vector3(sel.x+dx*10,0,sel.z+dz*10);tf=58;this.fwd={x:dx,z:dz};}
    else{tp=new THREE.Vector3(this.fx*.78,23.5,49+this.fz*.12);tl=new THREE.Vector3(this.fx,0,this.fz*.35-2);tf=36+Math.min(8,Math.hypot(f.vx,f.vz)*.25);this.fwd={x:0,z:-1};}
    const kk=mode==='player'&&!special?1-Math.exp(-dt*8):k;this.pos.lerp(tp,kk);this.look.lerp(tl,kk);this.fov=lerp(this.fov,tf,k);
    cam.position.copy(this.pos);if(this.shake>0){cam.position.x+=(Math.random()-.5)*this.shake;cam.position.y+=(Math.random()-.5)*this.shake;this.shake=Math.max(0,this.shake-dt*2);}
    cam.lookAt(this.look);if(Math.abs(cam.fov-this.fov)>.05){cam.fov=this.fov;cam.updateProjectionMatrix();}}
};
