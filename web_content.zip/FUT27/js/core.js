'use strict';
/* ===== FUT27 · core.js · SaveManager, GraphicsManager, AudioManager, InputManager ===== */
const SaveManager={
  key:'fut27_save_v1',data:null,
  defaults(){return{money:8000000,myClub:'RJF',squad:null,lineup:null,formation:'4-3-3',captain:null,tac:{ment:1,press:1,line:1,width:1,att:1,build:1,compact:1},cards:[],tour:{},career:null,
    settings:{lang:'pt',gfx:'auto',fps:60,vol:{music:.5,fx:.8,crowd:.6,voice:.7},vib:true,cam:'broadcast',diff:1,dur:5,ctl:'auto',debug:false}};},
  load(){let d=this.defaults();try{const s=localStorage.getItem(this.key);if(s){const o=JSON.parse(s);d=Object.assign(d,o);d.settings=Object.assign(this.defaults().settings,o.settings||{});d.settings.vol=Object.assign({music:.5,fx:.8,crowd:.6,voice:.7},d.settings.vol||{});}}catch(e){}this.data=d;return d;},
  has(){try{return !!localStorage.getItem(this.key);}catch(e){return false;}},
  save(){try{localStorage.setItem(this.key,JSON.stringify(this.data));return true;}catch(e){return false;}},
  reset(){try{localStorage.removeItem(this.key);}catch(e){}this.data=this.defaults();},
  /* elenco do clube do jogador (com contratações/cartas) */
  squad(){const d=this.data;if(!d.squad||d.squadClub!==d.myClub){d.squad=genSquad(d.myClub).map(p=>Object.assign({},p));d.squadClub=d.myClub;d.lineup=null;d.captain=null;}return d.squad;},
  lineupIds(){const d=this.data,sq=this.squad();const ok=d.lineup&&d.lineup.length===11&&d.lineup.every(id=>sq.some(p=>p.id===id))&&new Set(d.lineup).size===11;if(!ok)d.lineup=autoLineup(sq,d.formation);return d.lineup;}
};

const GraphicsManager={
  renderer:null,q:'medium',scale:1,maxScale:1,fps:60,acc:0,frames:0,lastRender:0,debug:false,dbg:null,
  PROF:{low:{shadow:false,sm:512,pr:.7,crowd:3.0,rain:300,detail:0,aa:false,spots:false},medium:{shadow:true,sm:1024,pr:1,crowd:1.7,rain:700,detail:1,aa:false,spots:false},high:{shadow:true,sm:2048,pr:1.5,crowd:1.0,rain:1100,detail:2,aa:true,spots:true},ultra:{shadow:true,sm:4096,pr:2,crowd:.8,rain:1700,detail:2,aa:true,spots:true}},
  hasWebGL(){try{const c=document.createElement('canvas');return !!(window.WebGLRenderingContext&&(c.getContext('webgl')||c.getContext('experimental-webgl')));}catch(e){return false;}},
  detect(){const mob=/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent),mem=navigator.deviceMemory||4,cores=navigator.hardwareConcurrency||4;if(!mob&&cores>=8)return'high';if(mem<=2||cores<=4)return'low';return'medium';},
  init(canvas){const s=SaveManager.data.settings;this.q=s.gfx==='auto'?this.detect():s.gfx;const P=this.PROF[this.q];
    this.renderer=new THREE.WebGLRenderer({canvas,antialias:P.aa,powerPreference:'high-performance'});const r=this.renderer;r.outputEncoding=THREE.sRGBEncoding;r.shadowMap.type=THREE.PCFShadowMap;
    this.dbg=document.getElementById('debug');this.debug=!!s.debug;this.dbg.classList.toggle('hidden',!this.debug);
    this.maxScale=Math.min(window.devicePixelRatio||1,P.pr);this.scale=this.maxScale;r.shadowMap.enabled=P.shadow;this.resize();window.addEventListener('resize',()=>this.resize());},
  profile(){return this.PROF[this.q];},
  setQuality(q){const s=SaveManager.data.settings;s.gfx=q;this.q=q==='auto'?this.detect():q;const P=this.PROF[this.q];this.maxScale=Math.min(window.devicePixelRatio||1,P.pr);this.scale=this.maxScale;this.renderer.shadowMap.enabled=P.shadow;this.resize();if(World.scene)World.applyQuality();},
  resize(){const w=window.innerWidth,h=window.innerHeight;this.renderer.setPixelRatio(this.scale);this.renderer.setSize(w,h,false);if(World.cam){World.cam.aspect=w/h;World.cam.updateProjectionMatrix();}},
  setDebug(v){this.debug=v;SaveManager.data.settings.debug=v;this.dbg.classList.toggle('hidden',!v);},
  shouldRender(now){if(SaveManager.data.settings.fps===30){if(now-this.lastRender<29)return false;}this.lastRender=now;return true;},
  tick(dt){this.frames++;this.acc+=dt;if(this.acc>=1){this.fps=this.frames/this.acc;const tg=SaveManager.data.settings.fps;
      if(this.fps<tg*.8&&this.scale>.5){this.scale=Math.max(.5,this.scale-.1);this.resize();}else if(this.fps>tg*.95&&this.scale<this.maxScale){this.scale=Math.min(this.maxScale,this.scale+.05);this.resize();}
      this.frames=0;this.acc=0;if(this.debug){const i=this.renderer.info,m=performance.memory?(performance.memory.usedJSHeapSize/1048576).toFixed(0)+'MB':'n/d';
        this.dbg.textContent='FPS '+this.fps.toFixed(0)+'  res '+this.scale.toFixed(2)+'  '+this.q+'\nDraw calls '+i.render.calls+'\nTriângulos '+i.render.triangles+'\nJogadores ativos '+MatchManager.activeCount()+'\nMemória '+m+'\nPartida '+MatchManager.state+'  '+(MatchManager.gmin|0)+"'";}}}
};

const AudioManager={
  quiet:false,ctx:null,g:{},nb:null,crowdG:null,rainG:null,musT:null,musMode:'off',step:0,lastSay:0,
  init(){if(this.ctx)return;try{this.ctx=new(window.AudioContext||window.webkitAudioContext)();}catch(e){return;}const c=this.ctx;
    this.g.master=c.createGain();this.g.master.connect(c.destination);['music','fx','crowd','voice'].forEach(k=>{const n=c.createGain();n.connect(this.g.master);this.g[k]=n;});
    const len=c.sampleRate*2;this.nb=c.createBuffer(1,len,c.sampleRate);const d=this.nb.getChannelData(0);for(let i=0;i<len;i++)d[i]=Math.random()*2-1;
    this.applyVol();
    const mk=(type,f,q)=>{const s=c.createBufferSource();s.buffer=this.nb;s.loop=true;const fl=c.createBiquadFilter();fl.type=type;fl.frequency.value=f;fl.Q.value=q;const gn=c.createGain();gn.gain.value=0;s.connect(fl);fl.connect(gn);s.start();return gn;};
    this.crowdG=mk('bandpass',550,.4);this.crowdG.connect(this.g.crowd);this.rainG=mk('highpass',1800,.5);this.rainG.connect(this.g.fx);},
  resume(){if(this.ctx&&this.ctx.state==='suspended')this.ctx.resume();},
  applyVol(){if(!this.ctx)return;const v=SaveManager.data.settings.vol;['music','fx','crowd','voice'].forEach(k=>this.g[k].gain.value=v[k]);},
  tone(type,f0,f1,dur,vol,dest,delay){if(!this.ctx)return;const c=this.ctx,o=c.createOscillator(),g=c.createGain(),t0=c.currentTime+(delay||0);o.type=type;o.frequency.setValueAtTime(f0,t0);if(f1!==f0)o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t0+dur);g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(vol,t0+.008);g.gain.exponentialRampToValueAtTime(.0001,t0+dur);o.connect(g);g.connect(dest||this.g.fx);o.start(t0);o.stop(t0+dur+.05);},
  noise(dur,vol,f,type,delay,dest){if(!this.ctx)return;const c=this.ctx,s=c.createBufferSource();s.buffer=this.nb;const fl=c.createBiquadFilter();fl.type=type||'lowpass';fl.frequency.value=f||1200;const g=c.createGain(),t0=c.currentTime+(delay||0);g.gain.setValueAtTime(vol,t0);g.gain.exponentialRampToValueAtTime(.0001,t0+dur);s.connect(fl);fl.connect(g);g.connect(dest||this.g.fx);s.start(t0,Math.random());s.stop(t0+dur+.05);},
  sfx(n,p){if(!this.ctx||this.quiet)return;p=p||.5;
    switch(n){
      case'kick':this.tone('sine',170,45,.14,.5+p*.5);this.noise(.07,.35+p*.4,1800,'bandpass');break;
      case'pass':this.tone('sine',130,50,.1,.28+p*.2);this.noise(.05,.15,1400,'bandpass');break;
      case'bounce':this.tone('sine',110,60,.1,.12+p*.25);break;
      case'post':this.tone('triangle',1500,900,.35,.35);this.tone('sine',520,300,.3,.25);break;
      case'net':this.noise(.5,.4,900,'lowpass');break;
      case'whistle':this.tone('sine',3000,3050,.5,.2);this.tone('sine',3150,3100,.5,.12);break;
      case'whistle2':this.tone('sine',3000,3000,.18,.2);this.tone('sine',3000,3000,.18,.2,null,.28);this.tone('sine',3000,3000,.5,.2,null,.56);break;
      case'goal':this.noise(2.2,.6,900,'bandpass',0,this.g.crowd);this.tone('sawtooth',220,220,.7,.1,this.g.fx);this.tone('sawtooth',330,330,.7,.08,this.g.fx);this.tone('sawtooth',440,440,.9,.08,this.g.fx,.12);break;
      case'click':this.tone('square',880,660,.06,.12);break;
      case'select':this.tone('sine',520,780,.1,.18);this.tone('sine',780,1040,.1,.14,null,.07);break;
      case'back':this.tone('sine',600,360,.1,.15);break;
      case'trans':this.noise(.3,.18,2400,'bandpass');this.tone('sine',300,900,.25,.1);break;
      case'card':this.tone('triangle',440,880,.25,.2);this.tone('triangle',660,1320,.3,.16,null,.1);break;
      case'oh':this.noise(.9,.5,700,'bandpass',0,this.g.crowd);break;
      case'tackle':this.noise(.12,.4,600,'lowpass');this.tone('sine',90,50,.15,.4);break;}},
  crowd(l){if(this.crowdG)this.crowdG.gain.setTargetAtTime(l,this.ctx.currentTime,.4);},
  rain(on){if(this.rainG)this.rainG.gain.setTargetAtTime(on?.16:0,this.ctx.currentTime,.5);},
  music(mode){if(!this.ctx)return;this.musMode=mode;if(this.musT){clearInterval(this.musT);this.musT=null;}if(mode==='off')return;
    const sc=[0,3,5,7,10,12,15,17],bass=[0,0,5,3];this.step=0;
    this.musT=setInterval(()=>{if(this.ctx.state!=='running')return;const s=this.step++,m=this.musMode==='menu';
      if(s%2===0||m){const n=sc[(s*3+(s>>3))%8]+(s%16<8?0:-2);this.tone('triangle',110*Math.pow(2,(n+12)/12),110*Math.pow(2,(n+12)/12),.35,.14,this.g.music);}
      if(s%4===0)this.tone('sine',55*Math.pow(2,bass[(s>>2)%4]/12),55*Math.pow(2,bass[(s>>2)%4]/12),.5,.3,this.g.music);
      if(s%4===2&&m)this.noise(.05,.12,6000,'highpass',0,this.g.music);},this.musMode==='menu'?260:340);},
  say(key){if(this.quiet)return;const lg=SaveManager.data.settings.lang,L=NARR[lg]&&NARR[lg][key];if(!L||!window.speechSynthesis)return;const now=performance.now();if(now-this.lastSay<1800&&key!=='goal')return;this.lastSay=now;
    try{const u=new SpeechSynthesisUtterance(pick(L));u.lang={pt:'pt-BR',en:'en-GB',es:'es-ES'}[lg];u.volume=SaveManager.data.settings.vol.voice;u.rate=1.15;u.pitch=1.1;speechSynthesis.cancel();if(u.volume>0)speechSynthesis.speak(u);}catch(e){}},
  vib(ms){if(SaveManager.data.settings.vib&&navigator.vibrate)try{navigator.vibrate(ms);}catch(e){}}
};

const InputManager={
  mx:0,my:0,keys:{},btn:{},ptr:{},joyId:null,joyOrg:null,mode:'attack',pads:{},touch:false,
  names:['pass','shoot','cross','through','sprint','switch','tackle','press','slide','gk'],
  init(){this.names.forEach(n=>this.btn[n]={down:false,t:0,pr:false,rl:false,rel:0});
    this.touch=('ontouchstart' in window)||navigator.maxTouchPoints>0;
    const KM={KeyJ:'pass',KeyK:'shoot',KeyL:'cross',KeyI:'through',ShiftLeft:'sprint',ShiftRight:'sprint',Space:'switch',KeyU:'tackle',KeyO:'press',KeyQ:'slide',KeyG:'gk'};
    window.addEventListener('keydown',e=>{if(e.repeat)return;this.keys[e.code]=true;const n=KM[e.code];if(n){this.press(n);e.preventDefault();}if(e.code==='KeyP'||e.code==='Escape')MatchManager.togglePause();if(e.code==='Backquote')GraphicsManager.setDebug(!GraphicsManager.debug);});
    window.addEventListener('keyup',e=>{this.keys[e.code]=false;const n=KM[e.code];if(n)this.release(n);});
    const zone=document.getElementById('joyZone'),base=document.getElementById('joyBase'),knob=document.getElementById('joyKnob');
    const R=()=>Math.min(innerWidth,innerHeight)*.11;
    zone.addEventListener('pointerdown',e=>{if(this.joyId!==null)return;this.joyId=e.pointerId;this.joyOrg={x:e.clientX,y:e.clientY};zone.setPointerCapture(e.pointerId);base.style.display='block';base.style.left=e.clientX+'px';base.style.top=e.clientY+'px';knob.style.transform='translate(-50%,-50%)';});
    zone.addEventListener('pointermove',e=>{if(e.pointerId!==this.joyId)return;let dx=e.clientX-this.joyOrg.x,dy=e.clientY-this.joyOrg.y;const r=R(),d=Math.hypot(dx,dy);if(d>r){dx*=r/d;dy*=r/d;}this.mx=dx/r;this.my=dy/r;knob.style.transform='translate(calc(-50% + '+dx+'px),calc(-50% + '+dy+'px))';});
    const up=e=>{if(e.pointerId!==this.joyId)return;this.joyId=null;this.mx=this.my=0;base.style.display='none';};zone.addEventListener('pointerup',up);zone.addEventListener('pointercancel',up);
    document.querySelectorAll('#touch .tb').forEach(el=>{const a=el.dataset.a,d=el.dataset.d;
      el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture(e.pointerId);const n=(this.mode==='defend'&&d)?d:a;this.ptr[e.pointerId]=n;el.classList.add('on');this.press(n);AudioManager.resume();});
      const rel=e=>{const n=this.ptr[e.pointerId];if(n){this.release(n);delete this.ptr[e.pointerId];}el.classList.remove('on');};el.addEventListener('pointerup',rel);el.addEventListener('pointercancel',rel);});},
  press(n){const b=this.btn[n];if(!b.down){b.down=true;b.t=performance.now();b.pr=true;}},
  release(n){const b=this.btn[n];if(b.down){b.down=false;b.rl=true;b.rel=Math.min(1,(performance.now()-b.t)/650);}},
  pressed(n){const b=this.btn[n];if(b.pr){b.pr=false;return true;}return false;},
  released(n){const b=this.btn[n];if(b.rl){b.rl=false;return b.rel;}return-1;},
  held(n){return this.btn[n].down;},
  charge(n){const b=this.btn[n];return b.down?Math.min(1,(performance.now()-b.t)/650):0;},
  clear(){this.names.forEach(n=>{const b=this.btn[n];b.pr=b.rl=false;});},
  poll(){/* gamepad */const gps=navigator.getGamepads?navigator.getGamepads():[];let gx=0,gy=0;
    for(const g of gps){if(!g)continue;const p=this.pads[g.index]||(this.pads[g.index]={});let ax=g.axes[0]||0,ay=g.axes[1]||0;if(Math.hypot(ax,ay)<.18)ax=ay=0;gx=ax;gy=ay;
      if(g.buttons[14]&&g.buttons[14].pressed)gx=-1;if(g.buttons[15]&&g.buttons[15].pressed)gx=1;if(g.buttons[12]&&g.buttons[12].pressed)gy=-1;if(g.buttons[13]&&g.buttons[13].pressed)gy=1;
      const MAP={0:'pass',1:'shoot',2:'through',3:'cross',5:'sprint',7:'sprint',4:'switch',6:'press',10:'slide',11:'tackle'};
      for(const k in MAP){const dn=g.buttons[k]&&g.buttons[k].pressed;if(dn&&!p[k])this.press(MAP[k]);if(!dn&&p[k])this.release(MAP[k]);p[k]=dn;}
      const st=g.buttons[9]&&g.buttons[9].pressed;if(st&&!p.st)MatchManager.togglePause();p.st=st;}
    this.gx=gx;this.gy=gy;},
  axis(){let x=this.mx,y=this.my;const k=this.keys;
    if(k.ArrowLeft||k.KeyA)x-=1;if(k.ArrowRight||k.KeyD)x+=1;if(k.ArrowUp||k.KeyW)y-=1;if(k.ArrowDown||k.KeyS)y+=1;x+=this.gx||0;y+=this.gy||0;
    const m=Math.hypot(x,y);if(m>1){x/=m;y/=m;}return{x,y,m:Math.min(1,m)};}
};
