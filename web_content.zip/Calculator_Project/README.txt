CALCULATOR - PRIVATE FILE VAULT (prototype)

Contents:
- index.html: self-contained calculator and PIN-protected encrypted file vault prototype.

App name shown: Calculator

Features:
- Calculator keypad
- First-use PIN setup (4-12 digits) triggered by entering a PIN and pressing equals
- Vault file import
- Photos, videos, documents categories
- AES-GCM encryption before local browser storage
- Export/decrypt and delete files

IMPORTANT:
This is an HTML prototype intended to be opened inside a secure-context browser or Android WebView wrapper.
WebCrypto may be unavailable if opened directly as file:// in some Android browsers. For a native APK,
use an Android WebView wrapper project/build service that includes index.html as its local asset.
This prototype does not include native biometric authentication or an independent Android backup system.
Please test with non-sensitive files first. Uninstalling/clearing app storage can erase vault contents.
