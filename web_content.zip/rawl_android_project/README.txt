# تطبيق روول Android

هذا مشروع Android Studio جاهز لتحويل متجر روول إلى APK.

## المتطلبات
- Android Studio حديث.
- JDK 17.
- Android SDK 36.
- اتصال إنترنت أول مرة لتنزيل Gradle/dependencies.

المشروع يستخدم Android Gradle Plugin 9.4.0 وGradle 9.6.0.

## إنشاء APK
1. فك الضغط عن `rawl_android_project.zip`.
2. افتح Android Studio.
3. اختر Open ثم مجلد `rawl_android_project`.
4. انتظر Gradle Sync حتى يكتمل.
5. من القائمة:
   Build > Build APK(s)
6. سيظهر ملف APK في:
   app/build/outputs/apk/debug/app-debug.apk

## إنشاء نسخة Release
Build > Generate Signed App Bundle / APK > APK
ثم أنشئ keystore واحفظ كلمة المرور بأمان.

## تعديل بيانات المتجر
الواجهة موجودة في:
app/src/main/assets/index.html

داخل الملف:
- رقم واتساب الحالي: 967770343555.
- العنوان: تعز – المدينة – جولة المسبح.
- عدّل المنتجات والأسعار داخل products.
- الشعار الحالي محفوظ باسم rawl_logo.webp داخل assets.

ملاحظة: الأسعار ورقم الهاتف الحاليان تجريبيان.
