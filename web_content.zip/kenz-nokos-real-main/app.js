const $ = id => document.getElementById(id);
const state = { token: localStorage.getItem('kn_token') || '', user: null, view: 'home', config: null };
const rp = n => 'Rp' + Number(n || 0).toLocaleString('id-ID');
function toast(msg){const el=$('toast');el.textContent=msg;el.style.display='block';clearTimeout(window.__toast);window.__toast=setTimeout(()=>el.style.display='none',3200)}
async function api(path, options={}) {
  const headers={'Content-Type':'application/json',...(options.headers||{})};
  if(state.token) headers.Authorization='Bearer '+state.token;
  const res=await fetch('/api'+path,{...options,headers});
  const data=await res.json().catch(()=>({error:'Respons server tidak valid.'}));
  if(!res.ok) throw new Error(data.error||'Permintaan gagal.');
  return data;
}
function setSession(user,token){state.user=user;state.token=token||state.token;if(token)localStorage.setItem('kn_token',token);$('session').textContent=user?'Login sebagai '+user.username:'Belum login';$('logout').classList.toggle('hidden',!user);$('balance').textContent=rp(user?.balance||0)}
async function refreshMe(){if(!state.token){setSession(null,'');return}try{const d=await api('/me');setSession(d.user)}catch{state.token='';localStorage.removeItem('kn_token');setSession(null,'')}}
function nav(){document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.view===state.view))}
function card(title,body){return `<article class="card"><h2>${title}</h2>${body}</article>`}
function authForm(mode='login'){const register=mode==='register';return card(register?'Buat akun KenzNokos':'Login KenzNokos',`<p>${register?'Gunakan username unik dan password minimal 8 karakter.':'Masuk ke akun yang tersimpan aman di server.'}</p><form id="authForm"><label class="field"><label>Username</label><input name="username" autocomplete="username" minlength="3" maxlength="24" required></label><label class="field"><label>Password</label><input name="password" type="password" autocomplete="${register?'new-password':'current-password'}" minlength="${register?8:1}" required></label><button class="primary full">${register?'Daftar':'Masuk'}</button></form><button id="switchAuth" class="ghost full">${register?'Sudah punya akun? Login':'Belum punya akun? Daftar'}</button>`)}
function render(){
 nav(); const v=$('view');
 if(state.view==='home'){
  v.innerHTML=card('Status layanan',`<div class="notice">${state.config?.paymentConfigured?'Gateway pembayaran terkonfigurasi di server.':'Payment gateway belum dikonfigurasi.'}</div><p>Saldo dan riwayat tersimpan di backend. Nomor atau kode OTP tidak akan dibuat secara acak.</p>`)+card('Akses cepat',`<button class="primary full" data-go="deposit">＋ Isi saldo via payment gateway</button><button class="ghost full" data-go="services">Lihat layanan</button>`);
 } else if(state.view==='services'){
  v.innerHTML=card('Layanan nomor',`<div class="notice">Pemesanan terkunci karena provider nomor resmi belum terhubung. Setelah provider yang sah tersedia, integrasi harus diuji dan diaktifkan dari backend.</div><p>Untuk menjaga keamanan, aplikasi tidak menampilkan nomor contoh maupun OTP buatan.</p><button class="ghost full" id="providerStatus">Periksa status integrasi</button>`);
 } else if(state.view==='deposit'){
  v.innerHTML=card('Deposit otomatis',`<p>Minimal ${rp(10000)}. Pembayaran dibuat melalui Midtrans dan saldo baru ditambahkan setelah webhook terverifikasi.</p><form id="depForm"><label class="field"><label>Nominal (Rp)</label><input name="amount" type="number" min="10000" max="2000000" step="1000" placeholder="10000" required></label><div class="actions">${[10000,20000,50000].map(n=>`<button type="button" class="ghost quick" data-amount="${n}">${rp(n)}</button>`).join('')}</div><button class="primary full">Lanjut ke pembayaran</button></form><p class="muted">Jangan tutup halaman sebelum diarahkan ke halaman pembayaran. Saldo tidak ditambah hanya berdasarkan redirect sukses; webhook server yang menentukan.</p>`);
 } else if(state.view==='history'){
  v.innerHTML=card('Riwayat',`<p>Riwayat diambil dari server setelah login.</p><button class="primary full" id="loadHistory">Muat riwayat</button><div id="historyRows"></div>`);
 } else if(state.view==='account'){
  v.innerHTML=state.user?card('Akun',`<p>Username: <b>${esc(state.user.username)}</b></p><p>ID akun: ${state.user.id}</p><button id="logout2" class="ghost full">Keluar dari akun</button>`):authForm('login');
 }
 if(!state.user && ['deposit','history','services'].includes(state.view)){v.innerHTML=authForm('login')+`<div class="card"><p>Login dibutuhkan untuk mengakses fitur akun.</p></div>`}
 v.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>go(b.dataset.go));
 const af=$('authForm');if(af)af.onsubmit=authSubmit;
 const sw=$('switchAuth');if(sw)sw.onclick=()=>{v.innerHTML=authForm(v.innerHTML.includes('Buat akun')?'login':'register');const f=$('authForm');if(f)f.onsubmit=authSubmit;$('switchAuth').onclick=()=>{state.view='account';render()};};
 const df=$('depForm');if(df)df.onsubmit=depositSubmit;
 v.querySelectorAll('.quick').forEach(b=>b.onclick=()=>{const inp=df?.elements.amount;if(inp)inp.value=b.dataset.amount});
 const hist=$('loadHistory');if(hist)hist.onclick=loadHistory;
 const ps=$('providerStatus');if(ps)ps.onclick=()=>toast('Provider belum dikonfigurasi di server.');
 const lo=$('logout2');if(lo)lo.onclick=logout;
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function go(view){state.view=view;render();window.scrollTo({top:0,behavior:'smooth'})}
async function authSubmit(e){e.preventDefault();const f=new FormData(e.currentTarget);const mode=e.currentTarget.querySelector('button').textContent.trim()==='Daftar'?'register':'login';try{const d=await api('/auth/'+mode,{method:'POST',body:JSON.stringify({username:f.get('username'),password:f.get('password')})});setSession(d.user,d.token);toast('Berhasil '+(mode==='register'?'mendaftar':'login'));go('home')}catch(err){toast(err.message)}}
async function depositSubmit(e){e.preventDefault();try{const amount=Number(new FormData(e.currentTarget).get('amount'));const d=await api('/payments/create',{method:'POST',body:JSON.stringify({amount})});location.href=d.redirectUrl}catch(err){toast(err.message)}}
async function loadHistory(){const target=$('historyRows');if(!target)return;target.innerHTML='<p>Memuat…</p>';try{const d=await api('/history');const items=[...d.ledger.map(x=>({...x,title:x.kind})),...d.payments.map(x=>({title:'Pembayaran '+x.status,note:x.order_id,amount:x.amount,created_at:x.created_at})),...d.orders.map(x=>({title:x.product,note:x.status,amount:-x.price,created_at:x.created_at}))];target.innerHTML=items.length?items.map(x=>`<div class="row"><div><b>${esc(x.title)}</b><div class="muted">${esc(x.note||x.created_at||'')}</div></div><span class="amount">${rp(x.amount)}</span></div>`).join(''):'<p>Belum ada transaksi.</p>'}catch(e){target.innerHTML='';toast(e.message)}}
function logout(){state.token='';state.user=null;localStorage.removeItem('kn_token');setSession(null,'');go('account');toast('Anda sudah keluar')}
$('logout').onclick=logout;$('depositShortcut').onclick=()=>go('deposit');$('historyShortcut').onclick=()=>go('history');
document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>go(b.dataset.view));
async function init(){try{state.config=await api('/config')}catch{}await refreshMe();render()}
init();
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
