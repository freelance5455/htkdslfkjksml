package com.anbar.offline;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int CREATE_FILE = 1002;

    private String pendingTextContent = null;
    private byte[] pendingBinaryContent = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER); } catch (Exception e) { fileChooserCallback = null; return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        /** Save plain text (e.g. JSON backup) letting the user pick where to store it. */
        @JavascriptInterface public void saveFile(String filename, String content) {
            runOnUiThread(() -> {
                pendingTextContent = content;
                pendingBinaryContent = null;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                try { startActivityForResult(intent, CREATE_FILE); } catch (Exception ignored) {}
            });
        }

        /** Save a binary file (e.g. .xlsx), content passed base64-encoded from JS, letting the user pick where to store it. */
        @JavascriptInterface public void saveBinaryFile(String filename, String base64, String mime) {
            runOnUiThread(() -> {
                try {
                    pendingBinaryContent = Base64.decode(base64, Base64.DEFAULT);
                    pendingTextContent = null;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mime);
                    intent.putExtra(Intent.EXTRA_TITLE, filename);
                    startActivityForResult(intent, CREATE_FILE);
                } catch (Exception ignored) {}
            });
        }

        /** Write a binary file to the app cache and open the Android share sheet (WhatsApp/Telegram/Email/etc). */
        @JavascriptInterface public void shareBinaryFile(String filename, String base64, String mime) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    File dir = new File(getCacheDir(), "share");
                    if (!dir.exists()) dir.mkdirs();
                    File f = new File(dir, filename);
                    try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(bytes); }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mime);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "ارسال فایل"));
                } catch (Exception ignored) {}
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null);
            fileChooserCallback = null;
        } else if (requestCode == CREATE_FILE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                if (pendingBinaryContent != null) {
                    os.write(pendingBinaryContent);
                } else if (pendingTextContent != null) {
                    os.write(pendingTextContent.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) {}
            pendingTextContent = null;
            pendingBinaryContent = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
