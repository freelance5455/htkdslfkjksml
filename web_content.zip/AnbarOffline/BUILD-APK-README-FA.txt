ساخت APK انبار آفلاین با یک اجرا

1) Android Studio را روی Windows نصب کنید.
   سایت رسمی: https://developer.android.com/studio

2) هنگام نصب، Android SDK را نیز نصب کنید.
   در Android Studio از مسیر:
   Tools > SDK Manager
   این موارد را نصب کنید:
   - Android SDK Platform 35
   - Android SDK Build-Tools 35.x

3) این پوشه را Extract کنید.

4) فقط روی فایل زیر دوبار کلیک کنید:
   BUILD-APK.bat

5) اسکریپت Gradle 8.9 را در صورت نیاز خودش دانلود می‌کند و پروژه را Build می‌کند.

6) در پایان فایل زیر ساخته می‌شود:
   AnbarOffline.apk

این APK برای نصب روی چند گوشی Android (انباردار و همکاران) قابل استفاده است.

نکته: بار اول برای Build اینترنت لازم است تا Gradle در صورت نبودن روی سیستم دانلود شود.
خود برنامه پس از نصب به‌طور کامل آفلاین کار می‌کند.
