$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'ANBAR OFFLINE - BUILD APK' -ForegroundColor Cyan

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
  throw 'Java/JDK not found. Install Android Studio first.'
}

$sdk = $env:ANDROID_HOME
if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
if (-not $sdk -and (Test-Path "$env:LOCALAPPDATA\Android\Sdk")) { $sdk = "$env:LOCALAPPDATA\Android\Sdk" }
if (-not $sdk) { throw 'Android SDK not found. Install Android Studio + SDK.' }

if (-not (Test-Path "$sdk\platforms\android-35\android.jar")) {
  throw 'Android SDK Platform 35 is missing. Install it from Android Studio > Tools > SDK Manager.'
}

$gradle = (Get-Command gradle -ErrorAction SilentlyContinue).Source
if (-not $gradle) {
  $gradle = "$PSScriptRoot\.tools\gradle-8.9\bin\gradle.bat"
  if (-not (Test-Path $gradle)) {
    New-Item -ItemType Directory -Force "$PSScriptRoot\.tools" | Out-Null
    $zip = "$PSScriptRoot\.tools\gradle-8.9-bin.zip"
    Write-Host 'Downloading Gradle 8.9...' -ForegroundColor Yellow
    Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $zip
    Expand-Archive -Force $zip "$PSScriptRoot\.tools"
  }
}

$env:ANDROID_HOME = $sdk
$env:ANDROID_SDK_ROOT = $sdk
& $gradle --no-daemon clean assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed.' }

$apk = "$PSScriptRoot\app\build\outputs\apk\debug\app-debug.apk"
if (-not (Test-Path $apk)) { throw 'APK was not produced.' }
Copy-Item $apk "$PSScriptRoot\AnbarOffline.apk" -Force
Write-Host "`nSUCCESS: $PSScriptRoot\AnbarOffline.apk" -ForegroundColor Green
Start-Process explorer.exe "/select,`"$PSScriptRoot\AnbarOffline.apk`""
