@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

echo ======================================================
echo        ANBAR OFFLINE - BUILD APK
 echo ======================================================
echo.

REM ---- Java ----
where java >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Java is not installed or is not in PATH.
  echo Install Android Studio first; it includes a compatible JDK/JBR.
  pause
  exit /b 1
)

REM ---- Android SDK detection ----
set "SDK="
if defined ANDROID_HOME set "SDK=%ANDROID_HOME%"
if not defined SDK if defined ANDROID_SDK_ROOT set "SDK=%ANDROID_SDK_ROOT%"
if not defined SDK if exist "%LOCALAPPDATA%\Android\Sdk" set "SDK=%LOCALAPPDATA%\Android\Sdk"
if not defined SDK if exist "%USERPROFILE%\AppData\Local\Android\Sdk" set "SDK=%USERPROFILE%\AppData\Local\Android\Sdk"

if not defined SDK (
  echo [ERROR] Android SDK was not found.
  echo.
  echo Install Android Studio and its recommended Android SDK packages,
  echo then run this file again.
  echo.
  echo Required for this project: Android SDK Platform 35 and Build Tools 35.x
  echo.
  pause
  exit /b 1
)

set "ANDROID_HOME=%SDK%"
set "ANDROID_SDK_ROOT=%SDK%"

echo Android SDK: %SDK%

REM ---- Check required SDK platform ----
if not exist "%SDK%\platforms\android-35\android.jar" (
  echo.
  echo [ERROR] Android SDK Platform 35 is missing.
  echo Open Android Studio -^> Tools -^> SDK Manager and install:
  echo   Android SDK Platform 35
  echo   Android SDK Build-Tools 35.x
  echo.
  pause
  exit /b 1
)

REM ---- Find Gradle or download Gradle 8.9 locally ----
set "GRADLE_CMD="
where gradle >nul 2>&1
if not errorlevel 1 set "GRADLE_CMD=gradle"

if not defined GRADLE_CMD if exist "%~dp0.tools\gradle-8.9\bin\gradle.bat" set "GRADLE_CMD=%~dp0.tools\gradle-8.9\bin\gradle.bat"

if not defined GRADLE_CMD (
  echo.
  echo Gradle was not found. Downloading Gradle 8.9 (~130 MB)...
  if not exist "%~dp0.tools" mkdir "%~dp0.tools"
  set "GZIP=%~dp0.tools\gradle-8.9-bin.zip"
  set "GDIR=%~dp0.tools\gradle-8.9"
  if not exist "!GDIR!\bin\gradle.bat" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '%~dp0.tools\gradle-8.9-bin.zip'"
    if errorlevel 1 (
      echo [ERROR] Could not download Gradle 8.9. Check your internet connection.
      pause
      exit /b 1
    )
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%~dp0.tools\gradle-8.9-bin.zip' '%~dp0.tools'"
    if errorlevel 1 (
      echo [ERROR] Could not extract Gradle.
      pause
      exit /b 1
    )
  )
  set "GRADLE_CMD=%~dp0.tools\gradle-8.9\bin\gradle.bat"
)

echo.
echo Building Anbar Offline APK...
echo.
call "%GRADLE_CMD%" --no-daemon clean assembleDebug
if errorlevel 1 (
  echo.
  echo ======================================================
  echo BUILD FAILED
  echo ======================================================
  echo Read the error above and send me a screenshot if needed.
  pause
  exit /b 1
)

if exist "%~dp0app\build\outputs\apk\debug\app-debug.apk" (
  copy /Y "%~dp0app\build\outputs\apk\debug\app-debug.apk" "%~dp0AnbarOffline.apk" >nul
  echo.
  echo ======================================================
  echo BUILD SUCCESSFUL
  echo ======================================================
  echo.
  echo APK created:
  echo %~dp0AnbarOffline.apk
  echo.
  echo Copy this APK to your Android phones and install it.
  echo.
  start "" explorer.exe /select,"%~dp0AnbarOffline.apk"
) else (
  echo [ERROR] Build finished but APK file was not found.
  pause
  exit /b 1
)

pause
endlocal
