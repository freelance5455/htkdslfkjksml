SAPIERAH — Proyek aplikasi Android

Isi: aplikasi manajemen peternakan sapi perah dibungkus dalam aplikasi Android WebView. Data disimpan otomatis di penyimpanan lokal WebView pada HP (localStorage), tanpa impor manual dan tanpa perlu internet untuk pemakaian lokal.

Cara membuat APK:
1. Ekstrak ZIP ini di komputer.
2. Buka folder Sapierah-Android melalui Android Studio.
3. Izinkan Gradle menyelesaikan sinkronisasi dan mengunduh Android Gradle Plugin/SDK jika diminta.
4. Pilih Build > Build APK(s).
5. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

Catatan penting:
- Data berada di aplikasi/perangkat yang sama. Menghapus aplikasi atau menghapus data aplikasi dapat menghapus data lokal. Sediakan fitur ekspor/cadangan dari aplikasi jika ingin memindahkan atau mengamankan data.
- File ini adalah proyek sumber siap dibuka di Android Studio, bukan APK yang sudah dikompilasi. Lingkungan ini tidak memiliki Android SDK/Gradle untuk menghasilkan APK final secara langsung.
