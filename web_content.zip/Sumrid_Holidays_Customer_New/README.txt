Sumrid Holidays Adventure ® — Customer App Project

App name: Sumrid Holidays Customer
Package name for APK builder: com.sumridholidays.customer

Includes:
- Welcome screen
- Main Daily Service: Chandigarh ↔ Lad Bharol via Sarkaghat, Dharampur and Khaddar
- Popular routes: Lad Bharol, Baijnath, Bir, Dharamshala, Palampur, Shimla, Manali
- Best Offers: first ride 15% OFF, referral ₹150 OFF, round trip 15% OFF, 7 rides then 8th free
- Local, office/job, hourly, airport, railway/bus stand, sightseeing, outstation and custom trip services
- Booking form, Google Maps directions, My Booking

Note: This front-end project currently stores bookings locally. Firebase/Firestore synchronization must be configured separately before production use.
