import { jsxDEV } from "react/jsx-dev-runtime";
import React, { useMemo, useRef, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import * as THREE from "three";
const skin = "#bf8d70";
const muscleColor = "#c99c80";
function Form({ at, size, color = skin, round = true }) {
  return /* @__PURE__ */ jsxDEV("mesh", { position: at, scale: size, castShadow: true, receiveShadow: true, children: [
    round ? /* @__PURE__ */ jsxDEV("sphereGeometry", { args: [1, 28, 20] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 15,
      columnNumber: 14
    }, this) : /* @__PURE__ */ jsxDEV("capsuleGeometry", { args: [0.5, 0.8, 6, 14] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 15,
      columnNumber: 54
    }, this),
    /* @__PURE__ */ jsxDEV("meshStandardMaterial", { color, roughness: 0.76 }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 16,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
function Torso({ female }) {
  const geometry = useMemo(() => {
    const profiles = female ? [[0.42, 0.2, 0.27], [0.47, 0.43, 0.29], [0.4, 0.72, 0.25], [0.34, 1.02, 0.22], [0.43, 1.3, 0.25], [0.54, 1.55, 0.28], [0.52, 1.74, 0.27], [0.41, 1.94, 0.23], [0.17, 2.12, 0.16]] : [[0.47, 0.2, 0.29], [0.52, 0.43, 0.31], [0.43, 0.73, 0.27], [0.4, 1.04, 0.25], [0.54, 1.32, 0.29], [0.68, 1.58, 0.32], [0.72, 1.78, 0.31], [0.51, 2, 0.25], [0.17, 2.12, 0.16]];
    const curve = new THREE.CatmullRomCurve3(profiles.map(([x, y, z]) => new THREE.Vector3(x, y, z)), false, "centripetal");
    const rings = 64, sides = 48, vertices = [], indices = [];
    for (let i = 0; i <= rings; i++) {
      const p = curve.getPoint(i / rings);
      for (let j = 0; j <= sides; j++) {
        const a = j / sides * Math.PI * 2;
        vertices.push(Math.cos(a) * p.x, p.y, Math.sin(a) * p.z);
        if (i < rings && j < sides) {
          const n = i * (sides + 1) + j, next = n + sides + 1;
          indices.push(n, next, n + 1, next, next + 1, n + 1);
        }
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
  }, [female]);
  return /* @__PURE__ */ jsxDEV("mesh", { geometry, castShadow: true, receiveShadow: true, children: /* @__PURE__ */ jsxDEV("meshStandardMaterial", { color: skin, roughness: 0.7, metalness: 0 }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 43,
    columnNumber: 61
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 43,
    columnNumber: 10
  }, this);
}
function Muscle({ name, at, size, selected, onSelect, round = true }) {
  return /* @__PURE__ */ jsxDEV("mesh", { position: at, scale: size, castShadow: true, onClick: (e) => {
    e.stopPropagation();
    onSelect(name);
  }, children: [
    round ? /* @__PURE__ */ jsxDEV("sphereGeometry", { args: [1, 28, 20] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 48,
      columnNumber: 14
    }, this) : /* @__PURE__ */ jsxDEV("capsuleGeometry", { args: [0.5, 0.8, 6, 14] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 48,
      columnNumber: 54
    }, this),
    /* @__PURE__ */ jsxDEV("meshStandardMaterial", { color: selected ? "#f5c518" : muscleColor, roughness: 0.67, emissive: selected ? "#9c7300" : "#000000", emissiveIntensity: selected ? 0.25 : 0 }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 49,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 47,
    columnNumber: 10
  }, this);
}
function Human({ gender, selected, onSelect }) {
  const female = gender === "female";
  const muscle = (name, at, size, round = true) => /* @__PURE__ */ jsxDEV(Muscle, { name, at, size, round, selected: selected === name, onSelect }, name + at.join("-"), false, {
    fileName: "<stdin>",
    lineNumber: 55,
    columnNumber: 73
  }, this);
  const limb = (at, size) => /* @__PURE__ */ jsxDEV(Form, { at, size, round: false }, at.join("-"), false, {
    fileName: "<stdin>",
    lineNumber: 56,
    columnNumber: 43
  }, this);
  return /* @__PURE__ */ jsxDEV("group", { scale: [female ? 0.92 : 1, 1, 1], children: [
    /* @__PURE__ */ jsxDEV(Form, { at: [0, 2.58, 0], size: [0.28, 0.36, 0.25] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 59,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(Form, { at: [0, 2.19, 0], size: [0.15, 0.27, 0.15] }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 60,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(Torso, { female }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 61,
      columnNumber: 5
    }, this),
    [-1, 1].map((side) => /* @__PURE__ */ jsxDEV(React.Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Form, { at: [side * 0.71, 1.98, 0], size: [0.25, 0.24, 0.23] }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 64,
        columnNumber: 7
      }, this),
      limb([side * 0.84, 1.47, 0], [0.18, 0.45, 0.18]),
      limb([side * 0.94, 0.78, 0.01], [0.135, 0.43, 0.14]),
      /* @__PURE__ */ jsxDEV(Form, { at: [side * 0.98, 0.29, 0.01], size: [0.12, 0.21, 0.075] }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 67,
        columnNumber: 7
      }, this),
      [-2, -1, 0, 1, 2].map((finger) => /* @__PURE__ */ jsxDEV(Form, { at: [side * 0.98 + finger * 0.035, 0.105, 0.02], size: [0.026, 0.12, 0.027] }, "finger" + side + finger, false, {
        fileName: "<stdin>",
        lineNumber: 68,
        columnNumber: 40
      }, this)),
      /* @__PURE__ */ jsxDEV(Form, { at: [side * 0.88, 0.23, 0.02], size: [0.035, 0.13, 0.03] }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 69,
        columnNumber: 7
      }, this),
      limb([side * 0.28, -0.48, 0], [female ? 0.23 : 0.26, 0.66, 0.22]),
      /* @__PURE__ */ jsxDEV(Form, { at: [side * 0.28, -1.25, 0], size: [0.19, 0.19, 0.19] }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 72,
        columnNumber: 7
      }, this),
      limb([side * 0.29, -1.84, -0.015], [0.17, 0.55, 0.17]),
      /* @__PURE__ */ jsxDEV(Form, { at: [side * 0.29, -2.48, 0.1], size: [0.16, 0.12, 0.31] }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 74,
        columnNumber: 7
      }, this)
    ] }, side, true, {
      fileName: "<stdin>",
      lineNumber: 63,
      columnNumber: 26
    }, this)),
    muscle("Chest", [-0.27, 1.69, 0.245], [female ? 0.27 : 0.32, 0.23, 0.11]),
    muscle("Chest", [0.27, 1.69, 0.245], [female ? 0.27 : 0.32, 0.23, 0.11]),
    muscle("Shoulders", [-0.72, 2, 0.12], [0.25, 0.24, 0.2]),
    muscle("Shoulders", [0.72, 2, 0.12], [0.25, 0.24, 0.2]),
    muscle("Biceps", [-0.84, 1.47, 0.15], [0.18, 0.39, 0.16], false),
    muscle("Biceps", [0.84, 1.47, 0.15], [0.18, 0.39, 0.16], false),
    muscle("Triceps", [-0.86, 1.46, -0.13], [0.17, 0.39, 0.15], false),
    muscle("Triceps", [0.86, 1.46, -0.13], [0.17, 0.39, 0.15], false),
    muscle("Forearms", [-0.94, 0.79, 0.11], [0.13, 0.38, 0.13], false),
    muscle("Forearms", [0.94, 0.79, 0.11], [0.13, 0.38, 0.13], false),
    [-0.16, 0.16].flatMap((x) => [1.04, 0.75, 0.46].map((y) => muscle("Abdominals", [x, y, 0.255], [0.135, 0.125, 0.075]))),
    muscle("Obliques", [-0.45, 0.79, 0.09], [0.12, 0.32, 0.13], false),
    muscle("Obliques", [0.45, 0.79, 0.09], [0.12, 0.32, 0.13], false),
    muscle("Quadriceps", [-0.28, -0.49, 0.17], [female ? 0.21 : 0.24, 0.57, 0.15], false),
    muscle("Quadriceps", [0.28, -0.49, 0.17], [female ? 0.21 : 0.24, 0.57, 0.15], false),
    muscle("Calves", [-0.29, -1.83, 0.08], [0.15, 0.43, 0.14], false),
    muscle("Calves", [0.29, -1.83, 0.08], [0.15, 0.43, 0.14], false),
    muscle("Back (Lats)", [-0.34, 1.38, -0.245], [0.25, 0.47, 0.09]),
    muscle("Back (Lats)", [0.34, 1.38, -0.245], [0.25, 0.47, 0.09]),
    muscle("Trapezius", [0, 1.91, -0.25], [0.28, 0.35, 0.09]),
    muscle("Glutes", [-0.24, 0.36, -0.25], [0.24, 0.23, 0.1]),
    muscle("Glutes", [0.24, 0.36, -0.25], [0.24, 0.23, 0.1]),
    muscle("Hamstrings", [-0.28, -0.5, -0.17], [0.22, 0.55, 0.12], false),
    muscle("Hamstrings", [0.28, -0.5, -0.17], [0.22, 0.55, 0.12], false)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 57,
    columnNumber: 10
  }, this);
}
function Anatomy3D({ gender, selected, onSelect, lang }) {
  const controls = useRef(null);
  const [rotate, setRotate] = useState(false);
  const [backView, setBackView] = useState(false);
  const toggleView = () => {
    const nextBack = !backView;
    if (controls.current) {
      controls.current.object.position.set(0, 0.1, nextBack ? -7.2 : 7.2);
      controls.current.target.set(0, 0.2, 0);
      controls.current.update();
    }
    setBackView(nextBack);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "model-panel", "aria-label": lang === "fa" ? "\u0645\u062F\u0644 \u0633\u0647\u200C\u0628\u0639\u062F\u06CC \u0622\u0646\u0627\u062A\u0648\u0645\u06CC" : "3D anatomy model", children: [
    /* @__PURE__ */ jsxDEV(Canvas, { shadows: true, camera: { position: [0, 0.1, 7.2], fov: 36 }, dpr: [1, 1.7], gl: { antialias: true, alpha: true }, children: [
      /* @__PURE__ */ jsxDEV("color", { attach: "background", args: ["#151512"] }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 120,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("ambientLight", { intensity: 1.25 }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 121,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("directionalLight", { position: [4, 6, 6], intensity: 2.1, castShadow: true, "shadow-mapSize-width": 1024, "shadow-mapSize-height": 1024 }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 122,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("directionalLight", { position: [-4, 2, -4], intensity: 1.3, color: "#d8c995" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 123,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(Human, { gender, selected, onSelect }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 124,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("mesh", { rotation: [-Math.PI / 2, 0, 0], position: [0, -2.67, 0], receiveShadow: true, children: [
        /* @__PURE__ */ jsxDEV("planeGeometry", { args: [20, 20] }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 126,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("shadowMaterial", { transparent: true, opacity: 0.22 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 126,
          columnNumber: 42
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 125,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(OrbitControls, { ref: controls, enableDamping: true, dampingFactor: 0.08, minDistance: 5.1, maxDistance: 9, minPolarAngle: 0.7, maxPolarAngle: 2.35, autoRotate: rotate, autoRotateSpeed: 0.4, target: [0, 0.2, 0] }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 128,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 119,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "model-controls", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setRotate(!rotate), "aria-label": rotate ? "Stop model rotation" : "Rotate model", children: rotate ? lang === "fa" ? "\u062A\u0648\u0642\u0641" : "\u2161 Pause" : lang === "fa" ? "\u0686\u0631\u062E\u0634" : "\u21BB Rotate" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 131,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleView, "aria-label": backView ? "Show anatomy front" : "Show anatomy back", children: backView ? lang === "fa" ? "\u0646\u0645\u0627\u06CC \u0631\u0648\u0628\u0647\u200C\u0631\u0648" : "Front view" : lang === "fa" ? "\u0646\u0645\u0627\u06CC \u067E\u0634\u062A" : "Back view" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 132,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 130,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "model-caption", children: lang === "fa" ? "\u0628\u0631\u0627\u06CC \u0686\u0631\u062E\u0627\u0646\u062F\u0646\u060C \u0628\u06A9\u0634\u06CC\u062F \xB7 \u0639\u0636\u0644\u0647 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F" : "DRAG TO ROTATE \xB7 SELECT A MUSCLE" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 134,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 118,
    columnNumber: 10
  }, this);
}
export {
  Anatomy3D as default
};
