module.exports = {
  appId: 'com.eps.platform',
  appName: 'EPS Platform',
  webDir: 'www',
  backgroundColor: '#ffffff',
  android: { allowMixedContent: true },
  server: { androidScheme: 'https', cleartext: true },
  plugins: {
    SplashScreen: { launchShowDuration: 0 },
    StatusBar: { overlaysWebView: false, backgroundColor: '#ffffff', style: 'LIGHT' }
  }
};
