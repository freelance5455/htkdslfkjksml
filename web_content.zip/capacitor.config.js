const { CapacitorConfig } = require('@capacitor/cli');

const config = {
  appId: 'com.mohamed.diaa.demons',
  appName: 'محمد ضياء الصعب Demons',
  webDir: 'www'
};

module.exports = config;
