X-HANTER INVITUZ Android wrapper

Isi:
- HTML/CSS/JS dashboard dibundel di app/src/main/assets.
- Android WebView membuka dashboard secara lokal/offline.
- Tidak membutuhkan izin internet atau izin WhatsApp.

Cara build APK:
1. Buka folder proyek ini dengan Android Studio.
2. Tunggu Gradle Sync selesai (JDK 17 diperlukan).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug ada di app/build/outputs/apk/debug/app-debug.apk.

Penting:
APK ini membungkus tampilan dashboard. Backend Node.js dan koneksi WhatsApp Baileys tidak ikut berjalan di dalam APK. Status bot tetap OFFLINE sampai backend di-host dan integrasi yang aman dibuat.
