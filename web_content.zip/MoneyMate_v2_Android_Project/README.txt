MoneyMate v2 Android Studio project
Includes local transaction tracking, savings goal, QR snapshot sharing and WhatsApp text report sharing.
Build APK using Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
The QR feature uses an online QR image generator and currently encodes a data snapshot; it is not a hosted public web page. For robust scanning across all QR scanner apps, use a hosted report URL or import the QR JSON with a compatible app.
WhatsApp shares the full report as message text.
This is source code, not a compiled APK.
