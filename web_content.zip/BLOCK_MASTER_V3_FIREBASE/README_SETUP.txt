# BLOCK MASTER V3

## Fitur
- Pemain dapat membuat akun atau masuk menggunakan username.
- Username unik (tidak membedakan huruf besar/kecil).
- Global leaderboard Top 50.
- Panel owner tersembunyi dari akun pemain biasa.
- Owner dapat memberi tambahan skor dan ban/unban pemain.
- Owner login memakai username `rasyaxpranzz` dan password akun Firebase yang terhubung ke email owner.
- Email owner tidak ditampilkan pada UI pemain.

## Setup Firebase
1. Firebase Console > Authentication > Sign-in method: aktifkan Anonymous dan Email/Password.
2. Buat akun Email/Password untuk email owner yang telah ditentukan dan verifikasi emailnya.
3. Firestore Database: buat database.
4. Project settings > Your apps > Web app: isi `firebase-config.js`.
5. Salin `firestore.rules` ke Firebase Console > Firestore Database > Rules, lalu Publish.
6. Hosting `index.html` melalui HTTPS (contoh Firebase Hosting).

## Penting tentang keamanan dan batasan username-only
- Login owner menampilkan username, tetapi autentikasi sebenarnya tetap memverifikasi akun Firebase Email/Password yang emailnya cocok dan sudah diverifikasi. Password tidak disimpan di source code.
- Jangan pernah membagikan password owner. Nama username owner tidak ditampilkan di layar pemain biasa, tetapi tidak bisa dianggap rahasia karena kode frontend dapat diperiksa.
- Akun pemain memakai Firebase Anonymous Auth. Karena tidak ada password/email pemulihan untuk pemain, username-only hanya bisa masuk kembali dari perangkat/browser yang masih menyimpan sesi anonim. Jika data aplikasi/browser dihapus atau pindah perangkat, akun lama tidak dapat dipulihkan hanya dengan username. Untuk login lintas perangkat diperlukan metode pemulihan tambahan (misalnya password atau kode pemulihan).
- Rules melindungi perubahan skor dan status ban dari pemain biasa. Untuk anti-cheat yang lebih kuat, perhitungan skor game sebaiknya divalidasi server-side dengan Cloud Functions; skor game yang berjalan sepenuhnya di browser masih dapat dimodifikasi oleh pengguna mahir.
- Firestore rules mencegah pemain yang diblokir melakukan update. Setelah mengganti rules, uji dengan akun pemain dan owner.
- Owner dapat memberi skor tambahan (bukan mengganti skor) dan melakukan ban/unban berdasarkan username.
- File `firebase-config.js` masih harus diisi dengan konfigurasi project Firebase milikmu.
