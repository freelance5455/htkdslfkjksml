# Bitácora de Envíos – paquete PWA

Archivos incluidos:
- index.html
- manifest.json
- sw.js
- icons/

## Cómo publicarlo
1. Suba todos los archivos respetando la misma estructura de carpetas.
2. Publique `index.html` en la raíz del sitio o en la carpeta final de la app.
3. Sirva el sitio por HTTPS.
4. Abra la app en Google Chrome (Android) o Edge/Chrome (Windows).

## Instalación correcta
- Windows: usar “Instalar app” desde Edge o Chrome.
- Android: usar Google Chrome y elegir “Instalar app”.
- No usar “Agregar a pantalla principal” si desea que aparezca en el cajón de aplicaciones como app.

## Nota
En Android, si el navegador no genera WebAPK, el resultado puede ser solo un acceso directo. Para máxima garantía, también puede empaquetarse luego como TWA/Capacitor.
