/*
# Create app_settings table for PhotoCraft AI remote configuration

## Purpose
This migration creates a single-row configuration table that serves as the
remote configuration backend for the PhotoCraft AI app. The admin panel
writes settings here; the mobile app reads them at runtime. This lets the
admin change AdMob IDs, ad frequency, and maintenance mode WITHOUT publishing
a new app version.

## New Tables

### app_settings
A single-row table (enforced by a CHECK constraint on id = 1) that stores:
- `id` (int, primary key, always 1)
- `ads_enabled` (bool, default true) — master ON/OFF for all ads
- `maintenance_mode` (bool, default false) — when true, app shows maintenance screen
- `admob_app_id` (text) — Google AdMob App ID
- `banner_ad_unit_id` (text) — Banner ad unit ID
- `interstitial_ad_unit_id` (text) — Interstitial ad unit ID
- `rewarded_ad_unit_id` (text) — Rewarded ad unit ID
- `ad_cooldown_seconds` (int, default 60) — minimum seconds between interstitial ads
- `ad_frequency` (int, default 3) — show interstitial every N qualifying actions
- `hd_export_rewarded` (bool, default true) — whether HD export requires rewarded ad
- `ai_enhance_rewarded` (bool, default true) — whether extra AI ops require rewarded ad
- `updated_at` (timestamptz) — last modification timestamp

## Security
- RLS enabled on app_settings.
- SELECT is public (TO anon, authenticated) because the mobile app reads config
  with the anon key — there are no user accounts in the app itself.
- INSERT / UPDATE / DELETE are restricted to authenticated users only (the admin).
  A dedicated admin signup creates the first authenticated admin user.
- No sensitive data (passwords, API keys) is stored in this table. AdMob unit IDs
  are not secrets — they are public identifiers per Google's documentation.
*/

CREATE TABLE IF NOT EXISTS app_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  ads_enabled boolean NOT NULL DEFAULT true,
  maintenance_mode boolean NOT NULL DEFAULT false,
  admob_app_id text NOT NULL DEFAULT 'ca-app-pub-3940256099942544~3347511713',
  banner_ad_unit_id text NOT NULL DEFAULT 'ca-app-pub-3940256099942544/6300978111',
  interstitial_ad_unit_id text NOT NULL DEFAULT 'ca-app-pub-3940256099942544/1033173712',
  rewarded_ad_unit_id text NOT NULL DEFAULT 'ca-app-pub-3940256099942544/5224354917',
  ad_cooldown_seconds integer NOT NULL DEFAULT 60,
  ad_frequency integer NOT NULL DEFAULT 3,
  hd_export_rewarded boolean NOT NULL DEFAULT true,
  ai_enhance_rewarded boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Seed the single row if it doesn't exist
INSERT INTO app_settings (id)
SELECT 1
WHERE NOT EXISTS (SELECT 1 FROM app_settings WHERE id = 1);

ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

-- Public read: the mobile app (anon key) needs to fetch config
DROP POLICY IF EXISTS "public_read_app_settings" ON app_settings;
CREATE POLICY "public_read_app_settings"
ON app_settings FOR SELECT
TO anon, authenticated
USING (true);

-- Only authenticated users (admins) can modify settings
DROP POLICY IF EXISTS "admin_insert_app_settings" ON app_settings;
CREATE POLICY "admin_insert_app_settings"
ON app_settings FOR INSERT
TO authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_app_settings" ON app_settings;
CREATE POLICY "admin_update_app_settings"
ON app_settings FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_app_settings" ON app_settings;
CREATE POLICY "admin_delete_app_settings"
ON app_settings FOR DELETE
TO authenticated
USING (true);

-- Auto-update updated_at on every row change
DROP TRIGGER IF EXISTS app_settings_updated_at ON app_settings;
CREATE OR REPLACE FUNCTION update_app_settings_timestamp()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER app_settings_updated_at
BEFORE UPDATE ON app_settings
FOR EACH ROW
EXECUTE FUNCTION update_app_settings_timestamp();
