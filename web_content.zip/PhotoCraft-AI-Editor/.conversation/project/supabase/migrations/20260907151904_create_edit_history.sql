/*
# Create edit_history table for optional analytics

## Purpose
Stores a lightweight log of photo editing sessions so the admin dashboard can
display usage statistics. No photos are stored — only metadata about the
editing operations performed.

## New Tables

### edit_history
- `id` (uuid, primary key)
- `session_id` (text) — anonymous per-session identifier (generated client-side)
- `operations` (text) — comma-separated list of operations performed (crop,resize,compress,bg_remove,ai_enhance,rotate)
- `saved` (bool) — whether the user saved the result
- `shared` (bool) — whether the user shared the result
- `created_at` (timestamptz)

## Security
- RLS enabled.
- SELECT/INSERT open to anon + authenticated (no user accounts in the app).
- UPDATE/DELETE restricted to authenticated admins.
*/

CREATE TABLE IF NOT EXISTS edit_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text,
  operations text,
  saved boolean DEFAULT false,
  shared boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE edit_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_edit_history" ON edit_history;
CREATE POLICY "anon_insert_edit_history"
ON edit_history FOR INSERT
TO anon, authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "anon_select_edit_history" ON edit_history;
CREATE POLICY "anon_select_edit_history"
ON edit_history FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "admin_update_edit_history" ON edit_history;
CREATE POLICY "admin_update_edit_history"
ON edit_history FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_edit_history" ON edit_history;
CREATE POLICY "admin_delete_edit_history"
ON edit_history FOR DELETE
TO authenticated
USING (true);
