import { useState, useCallback, useEffect } from 'react';
import { AppSettingsProvider, useAppSettings } from '@/context/AppSettingsContext';
import { AdManagerProvider, useAdManager } from '@/context/AdManagerContext';
import { SplashScreen } from '@/screens/SplashScreen';
import { HomeScreen } from '@/screens/HomeScreen';
import { PhotoEditor } from '@/screens/PhotoEditor';
import { AIGenerateScreen } from '@/screens/AIGenerateScreen';
import { PreviewScreen } from '@/screens/PreviewScreen';
import { SuccessScreen } from '@/screens/SuccessScreen';
import { MaintenanceScreen } from '@/screens/MaintenanceScreen';
import { AdminLogin } from '@/screens/admin/AdminLogin';
import { AdminDashboard } from '@/screens/admin/AdminDashboard';
import { BannerAd } from '@/components/ads/BannerAd';
import { InterstitialAd } from '@/components/ads/InterstitialAd';
import { supabase } from '@/lib/supabase';
import type { PhotoImageData, EditorScreen } from '@/lib/types';

function AppContent() {
  const { settings, loading } = useAppSettings();
  const { showInterstitial } = useAdManager();

  const [screen, setScreen] = useState<EditorScreen>('splash');
  const [editorMode, setEditorMode] = useState<string | undefined>(undefined);
  const [currentImage, setCurrentImage] = useState<PhotoImageData | null>(null);
  const [currentOperations, setCurrentOperations] = useState<string[]>([]);
  const [interstitialVisible, setInterstitialVisible] = useState(false);
  const [pendingAfterAd, setPendingAfterAd] = useState<null | 'success'>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  // Check admin session on mount
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) setIsAdmin(true);
    });
  }, []);

  const handleSplashDone = useCallback(() => {
    if (settings.maintenance_mode) {
      setScreen('maintenance');
    } else {
      setScreen('home');
    }
  }, [settings.maintenance_mode]);

  const handleNavigateEditor = useCallback((screen: 'editor' | 'ai_generate', mode?: string) => {
    setEditorMode(screen === 'editor' ? mode : undefined);
    setScreen(screen);
  }, []);

  const handleBackToHome = useCallback(() => {
    setScreen('home');
    setEditorMode(undefined);
    setCurrentImage(null);
    setCurrentOperations([]);
  }, []);

  const handlePreview = useCallback((image: PhotoImageData, operations: string[]) => {
    setCurrentImage(image);
    setCurrentOperations(operations);
    setScreen('preview');
  }, []);

  const handleSaved = useCallback((img: PhotoImageData, ops: string[]) => {
    setCurrentImage(img);
    setCurrentOperations(ops);
    // Check if interstitial should be shown after editing session
    if (showInterstitial()) {
      setPendingAfterAd('success');
      setInterstitialVisible(true);
    } else {
      setScreen('success');
    }
  }, [showInterstitial]);

  const handleInterstitialClose = useCallback(() => {
    setInterstitialVisible(false);
    if (pendingAfterAd === 'success') {
      setScreen('success');
    }
    setPendingAfterAd(null);
  }, [pendingAfterAd]);

  // Show loading while settings are being fetched
  if (loading && screen === 'splash') {
    return <SplashScreen onDone={handleSplashDone} />;
  }

  // Maintenance mode overrides all app screens (except admin)
  if (settings.maintenance_mode && screen !== 'admin-login' && screen !== 'admin-dashboard') {
    return <MaintenanceScreen onRetry={() => window.location.reload()} />;
  }

  if (screen === 'splash') {
    return <SplashScreen onDone={handleSplashDone} />;
  }

  if (screen === 'admin-login') {
    return (
      <AdminLogin
        onBack={() => setScreen('home')}
        onLoggedIn={() => { setIsAdmin(true); setScreen('admin-dashboard'); }}
      />
    );
  }

  if (screen === 'admin-dashboard' && isAdmin) {
    return <AdminDashboard onLogout={() => { setIsAdmin(false); setScreen('home'); }} />;
  }

  return (
    <div className="min-h-screen bg-ink-50">
      {screen === 'home' && (
        <HomeScreen
          onNavigate={handleNavigateEditor}
          onAdminClick={() => setScreen(isAdmin ? 'admin-dashboard' : 'admin-login')}
        />
      )}

      {screen === 'editor' && (
        <PhotoEditor
          initialMode={editorMode}
          onBack={handleBackToHome}
          onPreview={handlePreview}
          onSaved={handleSaved}
        />
      )}

      {screen === 'ai_generate' && (
        <AIGenerateScreen
          onBack={handleBackToHome}
          onPreview={handlePreview}
          onSaved={handleSaved}
        />
      )}

      {screen === 'preview' && currentImage && (
        <PreviewScreen
          image={currentImage}
          operations={currentOperations}
          onBack={() => setScreen('editor')}
          onSaved={() => handleSaved(currentImage!, currentOperations)}
        />
      )}

      {screen === 'success' && currentImage && (
        <SuccessScreen
          image={currentImage}
          operations={currentOperations}
          onHome={handleBackToHome}
        />
      )}

      {/* Fallback: if we reach success screen without an image, go home */}
      {screen === 'success' && !currentImage && (
        <div className="min-h-screen bg-gradient-mesh flex flex-col items-center justify-center px-6">
          <p className="text-white mb-6">Something went wrong. No image to display.</p>
          <button onClick={handleBackToHome} className="btn-primary">
            Back to Home
          </button>
        </div>
      )}

      {/* Banner Ad — shown on home screen only */}
      {screen === 'home' && <BannerAd />}

      {/* Interstitial Ad */}
      <InterstitialAd
        visible={interstitialVisible}
        onClose={handleInterstitialClose}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppSettingsProvider>
      <AdManagerProvider>
        <AppContent />
      </AdManagerProvider>
    </AppSettingsProvider>
  );
}
