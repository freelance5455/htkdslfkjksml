import { useState, useCallback, useRef } from 'react';
import {
  ArrowLeft,
  RotateCw,
  Undo2,
  Redo2,
  Save,
  Share2,
  Crop as CropIcon,
  Minimize2,
  FileArchive,
  Scissors,
  Loader2,
  Gift,
  Eye,
  AlertCircle,
  X,
} from 'lucide-react';
import type { PhotoImageData } from '@/lib/types';
import {
  fileToImageData,
  cropImage,
  resizeImage,
  rotateImage,
  compressImage,
  removeBackground,
  aiEnhance,
  saveImageToDevice,
  shareImage,
  formatBytes,
  estimateFileSize,
} from '@/lib/imageProcessing';
import { PhotoPicker } from '@/components/PhotoPicker';
import { CropOverlay } from '@/components/CropOverlay';
import { ResizePanel } from '@/components/ResizePanel';
import { CompressPanel } from '@/components/CompressPanel';
import { RewardedAd } from '@/components/ads/RewardedAd';
import { supabase } from '@/lib/supabase';

interface PhotoEditorProps {
  initialMode?: string;
  onBack: () => void;
  onPreview: (image: PhotoImageData, operations: string[]) => void;
  onSaved: (image: PhotoImageData, operations: string[]) => void;
}

type ToolPanel = 'none' | 'crop' | 'resize' | 'compress';

export function PhotoEditor({ initialMode, onBack, onPreview, onSaved }: PhotoEditorProps) {
  const [image, setImage] = useState<PhotoImageData | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [toolPanel, setToolPanel] = useState<ToolPanel>('none');
  const [operations, setOperations] = useState<string[]>([]);
  const [fileSize, setFileSize] = useState(0);

  // Undo/redo stacks
  const undoStack = useRef<PhotoImageData[]>([]);
  const redoStack = useRef<PhotoImageData[]>([]);

  // Rewarded ad state
  const [rewardedVisible, setRewardedVisible] = useState(false);
  const [rewardedAction, setRewardedAction] = useState<'ai_enhance' | 'save' | null>(null);

  // Error state
  const [saveError, setSaveError] = useState<string | null>(null);

  const updateImage = useCallback((newImage: PhotoImageData, op: string) => {
    setImage((prev: PhotoImageData | null) => {
      if (prev) {
        undoStack.current.push(prev);
        redoStack.current = [];
      }
      return newImage;
    });
    setOperations((prev) => [...prev, op]);
    estimateFileSize(newImage.dataUrl).then(setFileSize);
  }, []);

  const handlePhotoSelected = useCallback(async (file: File) => {
    setLoading(true);
    setLoadingMessage('Loading photo...');
    try {
      const imgData = await fileToImageData(file);
      setImage(imgData);
      estimateFileSize(imgData.dataUrl).then(setFileSize);
      // If launched from a specific mode, open that tool
      if (initialMode && initialMode !== 'crop') {
        // Handle below via effect-like check after state set
        setTimeout(() => {
          if (initialMode === 'resize') setToolPanel('resize');
          else if (initialMode === 'compress') setToolPanel('compress');
          else if (initialMode === 'bg_remove') handleRemoveBg();
          else if (initialMode === 'ai_enhance') handleAiEnhance();
        }, 100);
      } else if (initialMode === 'crop') {
        setTimeout(() => setToolPanel('crop'), 100);
      }
    } catch {
      setLoadingMessage('Failed to load photo');
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialMode]);

  const handleUndo = useCallback(() => {
    if (undoStack.current.length === 0) return;
    const prev = undoStack.current.pop()!;
    setImage((current) => {
      if (current) redoStack.current.push(current);
      return prev;
    });
    setOperations((ops) => ops.slice(0, -1));
  }, []);

  const handleRedo = useCallback(() => {
    if (redoStack.current.length === 0) return;
    const next = redoStack.current.pop()!;
    setImage((current) => {
      if (current) undoStack.current.push(current);
      return next;
    });
    setOperations((ops) => [...ops, 'redo']);
  }, []);

  const handleCrop = useCallback(
    async (x: number, y: number, w: number, h: number) => {
      if (!image) return;
      setLoading(true);
      setLoadingMessage('Cropping...');
      setToolPanel('none');
      try {
        const result = await cropImage(image, x, y, w, h);
        updateImage(result, 'crop');
      } finally {
        setLoading(false);
      }
    },
    [image, updateImage],
  );

  const handleResize = useCallback(
    async (w: number, h: number) => {
      if (!image) return;
      setLoading(true);
      setLoadingMessage('Resizing...');
      setToolPanel('none');
      try {
        const result = await resizeImage(image, w, h, true);
        updateImage(result, 'resize');
      } finally {
        setLoading(false);
      }
    },
    [image, updateImage],
  );

  const handleRotate = useCallback(async () => {
    if (!image) return;
    setLoading(true);
    setLoadingMessage('Rotating...');
    try {
      const result = await rotateImage(image, 90);
      updateImage(result, 'rotate');
    } finally {
      setLoading(false);
    }
  }, [image, updateImage]);

  const handleCompress = useCallback(
    async (quality: number) => {
      if (!image) return;
      setLoading(true);
      setLoadingMessage('Compressing...');
      setToolPanel('none');
      try {
        const result = await compressImage(image, quality);
        updateImage(result, 'compress');
      } finally {
        setLoading(false);
      }
    },
    [image, updateImage],
  );

  const handleRemoveBg = useCallback(async () => {
    if (!image) return;
    setLoading(true);
    setLoadingMessage('Removing background...');
    try {
      const result = await removeBackground(image, 32);
      updateImage(result, 'bg_remove');
    } catch {
      setLoadingMessage('Failed to remove background');
    } finally {
      setLoading(false);
    }
  }, [image, updateImage]);

  const handleAiEnhance = useCallback(async () => {
    if (!image) return;
    setLoading(true);
    setLoadingMessage('AI enhancing...');
    try {
      const result = await aiEnhance(image);
      updateImage(result, 'ai_enhance');
    } catch {
      setLoadingMessage('AI enhancement failed');
    } finally {
      setLoading(false);
    }
  }, [image, updateImage]);

  const handleAiEnhanceClick = useCallback(() => {
    if (!image) return;
    setRewardedAction('ai_enhance');
    setRewardedVisible(true);
  }, [image]);

  const saveCurrentImage = useCallback(async () => {
    if (!image) return;
    setSaveError(null);
    setLoading(true);
    setLoadingMessage('Saving to your device...');
    try {
      const filename = `photocraft_${Date.now()}.${image.format === 'image/png' ? 'png' : 'jpg'}`;
      await saveImageToDevice(image.dataUrl, filename);

      // Log to edit history (non-blocking — don't fail the save if this errors)
      supabase.from('edit_history').insert({
        operations: operations.join(','),
        saved: true,
        shared: false,
      }).then(() => {}, () => {});

      onSaved(image, operations);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error while saving';
      setSaveError(`Could not save the photo: ${msg}. Please try again.`);
    } finally {
      setLoading(false);
    }
  }, [image, operations, onSaved]);

  const handleRewardedComplete = useCallback(() => {
    setRewardedVisible(false);
    if (rewardedAction === 'ai_enhance') {
      handleAiEnhance();
    } else if (rewardedAction === 'save') {
      saveCurrentImage();
    }
    setRewardedAction(null);
  }, [rewardedAction, handleAiEnhance, saveCurrentImage]);

  const handleSave = useCallback(() => {
    if (!image) return;
    setRewardedAction('save');
    setRewardedVisible(true);
  }, [image]);

  const handleShare = useCallback(async () => {
    if (!image) return;
    setLoading(true);
    setLoadingMessage('Preparing to share...');
    try {
      const filename = `photocraft_${Date.now()}.${image.format === 'image/png' ? 'png' : 'jpg'}`;
      await shareImage(image.dataUrl, filename, 'PhotoCraft AI Edit');
    } catch {
      // Ignore share errors
    } finally {
      setLoading(false);
    }
  }, [image]);

  const handlePreview = useCallback(() => {
    if (!image) return;
    onPreview(image, operations);
  }, [image, operations, onPreview]);

  const canUndo = undoStack.current.length > 0;
  const canRedo = redoStack.current.length > 0;

  // Photo picker state
  if (!image) {
    return (
      <div className="min-h-screen bg-ink-50 pb-28">
        <div className="safe-top flex items-center gap-3 px-4 py-4">
          <button onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white shadow-soft active:scale-90">
            <ArrowLeft className="h-5 w-5 text-ink-700" />
          </button>
          <h1 className="font-display text-lg font-bold text-ink-900">Photo Editor</h1>
        </div>
        {loading ? (
          <div className="flex flex-col items-center justify-center py-32">
            <Loader2 className="h-10 w-10 animate-spin text-brand-500" />
            <p className="mt-4 text-sm text-ink-500">{loadingMessage}</p>
          </div>
        ) : (
          <PhotoPicker onPhotoSelected={handlePhotoSelected} />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-ink-950 flex flex-col">
      {/* Top bar */}
      <div className="safe-top flex items-center justify-between px-4 py-4 bg-ink-950 z-20">
        <button
          onClick={() => { setImage(null); undoStack.current = []; redoStack.current = []; onBack(); }}
          className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white active:scale-90"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="flex flex-col items-center">
          <h1 className="font-display text-base font-semibold text-white">Editor</h1>
          <p className="text-[10px] text-ink-400">{image.width} × {image.height} · {formatBytes(fileSize)}</p>
        </div>
        <div className="flex gap-1">
          <button
            onClick={handleUndo}
            disabled={!canUndo}
            className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white transition-all active:scale-90 disabled:opacity-30"
          >
            <Undo2 className="h-5 w-5" />
          </button>
          <button
            onClick={handleRedo}
            disabled={!canRedo}
            className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white transition-all active:scale-90 disabled:opacity-30"
          >
            <Redo2 className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Image preview area */}
      <div className="flex flex-1 items-center justify-center px-4 py-4 overflow-hidden">
        <div className="relative max-w-full max-h-full">
          <img
            src={image.dataUrl}
            alt="Editing"
            className="max-w-full max-h-[50vh] rounded-2xl object-contain"
            style={{
              backgroundImage: image.format === 'image/png'
                ? 'linear-gradient(45deg, #2a2a2a 25%, transparent 25%), linear-gradient(-45deg, #2a2a2a 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #2a2a2a 75%), linear-gradient(-45deg, transparent 75%, #2a2a2a 75%)'
                : undefined,
              backgroundSize: image.format === 'image/png' ? '20px 20px' : undefined,
              backgroundPosition: image.format === 'image/png' ? '0 0, 0 10px, 10px -10px, -10px 0px' : undefined,
            }}
          />
        </div>
      </div>

      {/* Operations applied */}
      {operations.length > 0 && (
        <div className="px-4 py-2">
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {operations.map((op, i) => (
              <span
                key={i}
                className="shrink-0 rounded-full bg-brand-500/20 px-3 py-1 text-[10px] font-medium text-brand-300"
              >
                {op}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Action buttons */}
      <div className="flex gap-2 px-4 pb-3 safe-bottom">
        <button onClick={handleSave} className="btn-primary flex-1">
          <Save className="h-5 w-5" />
          Save
        </button>
        <button onClick={handleShare} className="btn-secondary px-5">
          <Share2 className="h-5 w-5" />
        </button>
        <button onClick={handlePreview} className="btn-secondary px-5">
          <Eye className="h-5 w-5" />
        </button>
      </div>

      {/* Bottom toolbar */}
      <div className="flex items-center justify-around bg-ink-900 px-2 py-2 safe-bottom border-t border-white/5">
        <button className="editor-tool-btn" onClick={() => setToolPanel('crop')}>
          <CropIcon className="h-5 w-5" />
          <span className="text-[10px] font-medium">Crop</span>
        </button>
        <button className="editor-tool-btn" onClick={() => setToolPanel('resize')}>
          <Minimize2 className="h-5 w-5" />
          <span className="text-[10px] font-medium">Resize</span>
        </button>
        <button className="editor-tool-btn" onClick={handleRotate}>
          <RotateCw className="h-5 w-5" />
          <span className="text-[10px] font-medium">Rotate</span>
        </button>
        <button className="editor-tool-btn" onClick={() => setToolPanel('compress')}>
          <FileArchive className="h-5 w-5" />
          <span className="text-[10px] font-medium">Compress</span>
        </button>
        <button className="editor-tool-btn" onClick={handleRemoveBg}>
          <Scissors className="h-5 w-5" />
          <span className="text-[10px] font-medium">Rem BG</span>
        </button>
        <button className="editor-tool-btn" onClick={handleAiEnhanceClick}>
          <Gift className="h-5 w-5 text-accent-400" />
          <span className="text-[10px] font-medium">AI</span>
        </button>
      </div>

      {/* Tool panels */}
      {toolPanel === 'crop' && image && (
        <CropOverlay image={image} onCrop={handleCrop} onCancel={() => setToolPanel('none')} />
      )}
      {toolPanel === 'resize' && image && (
        <ResizePanel image={image} onResize={handleResize} onCancel={() => setToolPanel('none')} />
      )}
      {toolPanel === 'compress' && image && (
        <CompressPanel image={image} onCompress={handleCompress} onCancel={() => setToolPanel('none')} />
      )}

      {/* Rewarded Ad */}
      <RewardedAd
        visible={rewardedVisible}
        rewardText={rewardedAction === 'ai_enhance' ? 'AI Enhancement' : 'Save'}
        onReward={handleRewardedComplete}
        onClose={() => { setRewardedVisible(false); setRewardedAction(null); }}
      />

      {/* Loading overlay */}
      {loading && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-ink-950/90 backdrop-blur-sm">
          <Loader2 className="h-12 w-12 animate-spin text-brand-500" />
          <p className="mt-4 text-sm font-medium text-white">{loadingMessage}</p>
        </div>
      )}

      {/* Save error dialog */}
      {saveError && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/90 px-6 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-ink-900 p-6 shadow-card animate-scale-in">
            <div className="mb-5 flex flex-col items-center text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-error-500/20">
                <AlertCircle className="h-7 w-7 text-error-500" />
              </div>
              <h3 className="font-display text-lg font-bold text-white mb-2">Save Failed</h3>
              <p className="text-sm text-ink-400 leading-relaxed">{saveError}</p>
            </div>
            <button
              onClick={() => setSaveError(null)}
              className="btn-primary w-full"
            >
              <X className="h-5 w-5" />
              Dismiss
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
