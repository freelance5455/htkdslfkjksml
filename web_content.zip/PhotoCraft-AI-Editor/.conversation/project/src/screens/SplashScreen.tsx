import { useEffect, useState } from 'react';
import { Camera, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onDone: () => void;
}

export function SplashScreen({ onDone }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onDone, 300);
          return 100;
        }
        return prev + 4;
      });
    }, 40);
    return () => clearInterval(interval);
  }, [onDone]);

  return (
    <div className="bg-gradient-mesh fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden">
      {/* Animated background orbs */}
      <div className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-brand-500/20 blur-3xl animate-pulse-soft" />
      <div className="pointer-events-none absolute -bottom-32 -right-20 h-80 w-80 rounded-full bg-accent-500/15 blur-3xl animate-pulse-soft" style={{ animationDelay: '1s' }} />

      <div className="relative flex flex-col items-center animate-scale-in">
        <div className="relative mb-6">
          <div className="absolute inset-0 rounded-[2rem] bg-brand-500/30 blur-xl animate-pulse-soft" />
          <div className="relative flex h-24 w-24 items-center justify-center rounded-[2rem] bg-gradient-brand shadow-glow">
            <Camera className="h-12 w-12 text-white" />
          </div>
          <div className="absolute -bottom-2 -right-2 flex h-9 w-9 items-center justify-center rounded-xl bg-accent-500 shadow-lg">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
        </div>

        <h1 className="mb-1 font-display text-3xl font-extrabold text-white tracking-tight">
          PhotoCraft AI
        </h1>
        <p className="text-sm font-medium text-brand-300 tracking-wide">
          Professional Photo Editor
        </p>
      </div>

      <div className="absolute bottom-20 left-0 right-0 flex flex-col items-center px-12">
        <div className="h-1 w-48 overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand-400 to-accent-400 transition-all duration-75 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="mt-4 text-xs text-ink-500">Loading your editing studio...</p>
      </div>
    </div>
  );
}
