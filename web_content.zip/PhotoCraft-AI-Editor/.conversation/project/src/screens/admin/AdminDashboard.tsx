import { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  Settings,
  ToggleLeft,
  ToggleRight,
  LogOut,
  Save,
  Loader2,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Image as ImageIcon,
  Share2,
  Download,
  Clock,
  Eye,
  EyeOff,
  RotateCcw,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAppSettings } from '@/context/AppSettingsContext';
import type { AppSettings } from '@/lib/types';

interface AdminDashboardProps {
  onLogout: () => void;
}

type Tab = 'dashboard' | 'admob' | 'app';
type SaveState = 'idle' | 'saving' | 'saved' | 'error';

export function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const { settings, refresh } = useAppSettings();
  const [tab, setTab] = useState<Tab>('dashboard');
  const [form, setForm] = useState<AppSettings>(settings);
  const [saveState, setSaveState] = useState<SaveState>('idle');
  const [showIds, setShowIds] = useState(false);
  const [stats, setStats] = useState({ total: 0, saved: 0, shared: 0, today: 0 });

  useEffect(() => {
    setForm(settings);
  }, [settings]);

  const loadStats = useCallback(async () => {
    const { count: total } = await supabase.from('edit_history').select('*', { count: 'exact', head: true });
    const { count: saved } = await supabase.from('edit_history').select('*', { count: 'exact', head: true }).eq('saved', true);
    const { count: shared } = await supabase.from('edit_history').select('*', { count: 'exact', head: true }).eq('shared', true);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const { count: todayCount } = await supabase
      .from('edit_history')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', today.toISOString());
    setStats({ total: total ?? 0, saved: saved ?? 0, shared: shared ?? 0, today: todayCount ?? 0 });
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  const handleSave = async () => {
    setSaveState('saving');
    try {
      const { error } = await supabase
        .from('app_settings')
        .update({
          ads_enabled: form.ads_enabled,
          maintenance_mode: form.maintenance_mode,
          admob_app_id: form.admob_app_id,
          banner_ad_unit_id: form.banner_ad_unit_id,
          interstitial_ad_unit_id: form.interstitial_ad_unit_id,
          rewarded_ad_unit_id: form.rewarded_ad_unit_id,
          ad_cooldown_seconds: form.ad_cooldown_seconds,
          ad_frequency: form.ad_frequency,
          hd_export_rewarded: form.hd_export_rewarded,
          ai_enhance_rewarded: form.ai_enhance_rewarded,
        })
        .eq('id', 1);

      if (error) throw error;
      await refresh();
      setSaveState('saved');
      setTimeout(() => setSaveState('idle'), 2000);
    } catch {
      setSaveState('error');
      setTimeout(() => setSaveState('idle'), 3000);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    onLogout();
  };

  const handleResetToTest = () => {
    setForm({
      ...form,
      admob_app_id: 'ca-app-pub-3940256099942544~3347511713',
      banner_ad_unit_id: 'ca-app-pub-3940256099942544/6300978111',
      interstitial_ad_unit_id: 'ca-app-pub-3940256099942544/1033173712',
      rewarded_ad_unit_id: 'ca-app-pub-3940256099942544/5224354917',
    });
  };

  return (
    <div className="min-h-screen bg-ink-50">
      {/* Header */}
      <div className="bg-gradient-mesh safe-top px-6 pb-6 pt-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10">
              <Settings className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="font-display text-lg font-bold text-white">Admin Panel</h1>
              <p className="text-xs text-ink-400">PhotoCraft AI</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-2.5 text-sm font-medium text-white active:scale-95"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </button>
        </div>

        {/* Tabs */}
        <div className="mt-6 flex gap-1 rounded-2xl bg-white/5 p-1">
          {[
            { key: 'dashboard' as Tab, label: 'Dashboard', icon: LayoutDashboard },
            { key: 'admob' as Tab, label: 'AdMob', icon: TrendingUp },
            { key: 'app' as Tab, label: 'App Settings', icon: Settings },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex flex-1 items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
                tab === t.key
                  ? 'bg-white text-ink-900 shadow-soft'
                  : 'text-ink-300 hover:text-white'
              }`}
            >
              <t.icon className="h-4 w-4" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="px-5 py-6 pb-28">
        {tab === 'dashboard' && (
          <div className="space-y-4 animate-fade-in">
            <h2 className="font-display text-lg font-bold text-ink-900">Overview</h2>

            <div className="grid grid-cols-2 gap-4">
              <StatCard icon={ImageIcon} label="Total Edits" value={stats.total} color="from-brand-400 to-brand-600" />
              <StatCard icon={Clock} label="Today" value={stats.today} color="from-accent-400 to-accent-600" />
              <StatCard icon={Download} label="Saved" value={stats.saved} color="from-success-500 to-success-700" />
              <StatCard icon={Share2} label="Shared" value={stats.shared} color="from-brand-500 to-accent-500" />
            </div>

            <div className="card mt-4">
              <h3 className="mb-4 font-display font-semibold text-ink-900">Current Status</h3>
              <div className="space-y-3">
                <StatusRow label="Ads" enabled={settings.ads_enabled} />
                <StatusRow label="Maintenance Mode" enabled={settings.maintenance_mode} />
                <StatusRow label="HD Export (Rewarded)" enabled={settings.hd_export_rewarded} />
                <StatusRow label="AI Enhance (Rewarded)" enabled={settings.ai_enhance_rewarded} />
              </div>
            </div>

            <div className="card">
              <h3 className="mb-3 font-display font-semibold text-ink-900">Ad Configuration</h3>
              <p className="text-xs text-ink-500 mb-3">Currently active AdMob IDs:</p>
              <div className="space-y-2">
                <ConfigRow label="App ID" value={settings.admob_app_id} />
                <ConfigRow label="Banner" value={settings.banner_ad_unit_id} />
                <ConfigRow label="Interstitial" value={settings.interstitial_ad_unit_id} />
                <ConfigRow label="Rewarded" value={settings.rewarded_ad_unit_id} />
              </div>
            </div>
          </div>
        )}

        {tab === 'admob' && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold text-ink-900">AdMob Settings</h2>
              <button
                onClick={() => setShowIds(!showIds)}
                className="flex items-center gap-1.5 text-xs font-medium text-ink-500"
              >
                {showIds ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                {showIds ? 'Hide' : 'Show'}
              </button>
            </div>

            <div className="card space-y-4">
              <AdmobInput
                label="AdMob App ID"
                value={form.admob_app_id}
                onChange={(v) => setForm({ ...form, admob_app_id: v })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"
                masked={!showIds}
              />
              <AdmobInput
                label="Banner Ad Unit ID"
                value={form.banner_ad_unit_id}
                onChange={(v) => setForm({ ...form, banner_ad_unit_id: v })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
                masked={!showIds}
              />
              <AdmobInput
                label="Interstitial Ad Unit ID"
                value={form.interstitial_ad_unit_id}
                onChange={(v) => setForm({ ...form, interstitial_ad_unit_id: v })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
                masked={!showIds}
              />
              <AdmobInput
                label="Rewarded Ad Unit ID"
                value={form.rewarded_ad_unit_id}
                onChange={(v) => setForm({ ...form, rewarded_ad_unit_id: v })}
                placeholder="ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
                masked={!showIds}
              />

              <button
                onClick={handleResetToTest}
                className="flex items-center gap-2 text-xs font-medium text-brand-600"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Reset to Google Test IDs
              </button>
            </div>

            <div className="card space-y-4">
              <h3 className="font-display font-semibold text-ink-900">Ad Frequency & Cooldown</h3>
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <label className="text-sm font-medium text-ink-700">Cooldown (seconds)</label>
                  <span className="font-display font-bold text-brand-600">{form.ad_cooldown_seconds}s</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="300"
                  step="15"
                  value={form.ad_cooldown_seconds}
                  onChange={(e) => setForm({ ...form, ad_cooldown_seconds: parseInt(e.target.value) })}
                  className="w-full h-2 rounded-full appearance-none bg-ink-200 accent-brand-500 cursor-pointer"
                />
                <p className="mt-1 text-xs text-ink-400">Minimum time between interstitial ads</p>
              </div>

              <div>
                <div className="mb-2 flex items-center justify-between">
                  <label className="text-sm font-medium text-ink-700">Frequency (every N actions)</label>
                  <span className="font-display font-bold text-brand-600">{form.ad_frequency}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  step="1"
                  value={form.ad_frequency}
                  onChange={(e) => setForm({ ...form, ad_frequency: parseInt(e.target.value) })}
                  className="w-full h-2 rounded-full appearance-none bg-ink-200 accent-brand-500 cursor-pointer"
                />
                <p className="mt-1 text-xs text-ink-400">Show interstitial after every N qualifying actions</p>
              </div>
            </div>
          </div>
        )}

        {tab === 'app' && (
          <div className="space-y-4 animate-fade-in">
            <h2 className="font-display text-lg font-bold text-ink-900">App Settings</h2>

            <div className="card space-y-1">
              <ToggleRow
                label="Ads ON/OFF"
                description="Master switch for all ads"
                enabled={form.ads_enabled}
                onChange={(v) => setForm({ ...form, ads_enabled: v })}
              />
              <ToggleRow
                label="Maintenance Mode"
                description="Show maintenance screen to users"
                enabled={form.maintenance_mode}
                onChange={(v) => setForm({ ...form, maintenance_mode: v })}
              />
              <ToggleRow
                label="HD Export (Rewarded)"
                description="Require rewarded ad for HD export"
                enabled={form.hd_export_rewarded}
                onChange={(v) => setForm({ ...form, hd_export_rewarded: v })}
              />
              <ToggleRow
                label="AI Enhance (Rewarded)"
                description="Require rewarded ad for AI enhancement"
                enabled={form.ai_enhance_rewarded}
                onChange={(v) => setForm({ ...form, ai_enhance_rewarded: v })}
              />
            </div>

            <div className="card">
              <h3 className="mb-2 font-display font-semibold text-ink-900">Info</h3>
              <p className="text-xs text-ink-500">
                Settings are stored remotely and fetched by the app at runtime.
                Changes take effect immediately — no app update required.
              </p>
              <p className="mt-2 text-xs text-ink-400">
                Last updated: {new Date(settings.updated_at).toLocaleString()}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Save button (fixed) */}
      {(tab === 'admob' || tab === 'app') && (
        <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md px-5 py-4 safe-bottom shadow-card border-t border-ink-100">
          <button
            onClick={handleSave}
            disabled={saveState === 'saving'}
            className={`btn-primary w-full transition-all ${
              saveState === 'saved' ? 'bg-success-500' : ''
            } ${saveState === 'error' ? 'bg-error-500' : ''}`}
          >
            {saveState === 'saving' && (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Saving...
              </>
            )}
            {saveState === 'saved' && (
              <>
                <CheckCircle2 className="h-5 w-5" />
                Saved Successfully
              </>
            )}
            {saveState === 'error' && (
              <>
                <AlertCircle className="h-5 w-5" />
                Failed to Save
              </>
            )}
            {saveState === 'idle' && (
              <>
                <Save className="h-5 w-5" />
                Save Changes
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: typeof ImageIcon; label: string; value: number; color: string }) {
  return (
    <div className="card">
      <div className={`flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br ${color} mb-3`}>
        <Icon className="h-5 w-5 text-white" />
      </div>
      <p className="font-display text-2xl font-extrabold text-ink-900">{value}</p>
      <p className="text-xs text-ink-500 mt-0.5">{label}</p>
    </div>
  );
}

function StatusRow({ label, enabled }: { label: string; enabled: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-ink-600">{label}</span>
      <span className={`flex items-center gap-1.5 text-xs font-semibold ${enabled ? 'text-success-600' : 'text-ink-400'}`}>
        <span className={`h-2 w-2 rounded-full ${enabled ? 'bg-success-500' : 'bg-ink-300'}`} />
        {enabled ? 'ON' : 'OFF'}
      </span>
    </div>
  );
}

function ConfigRow({ label, value }: { label: string; value: string }) {
  const isTest = value.includes('3940256099942544');
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-xs font-medium text-ink-500 shrink-0">{label}</span>
      <div className="flex items-center gap-2 min-w-0">
        <span className="text-xs text-ink-700 truncate">{value}</span>
        {isTest && (
          <span className="shrink-0 rounded-full bg-warning-50 px-2 py-0.5 text-[9px] font-bold uppercase text-warning-600">TEST</span>
        )}
      </div>
    </div>
  );
}

function ToggleRow({ label, description, enabled, onChange }: { label: string; description: string; enabled: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between py-3">
      <div className="flex-1">
        <p className="text-sm font-semibold text-ink-900">{label}</p>
        <p className="text-xs text-ink-500 mt-0.5">{description}</p>
      </div>
      <button onClick={() => onChange(!enabled)} className="shrink-0">
        {enabled ? (
          <ToggleRight className="h-10 w-10 text-brand-500" />
        ) : (
          <ToggleLeft className="h-10 w-10 text-ink-300" />
        )}
      </button>
    </div>
  );
}

function AdmobInput({ label, value, onChange, placeholder, masked }: { label: string; value: string; onChange: (v: string) => void; placeholder: string; masked: boolean }) {
  const isTest = value.includes('3940256099942544');
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <label className="text-sm font-medium text-ink-700">{label}</label>
        {isTest && (
          <span className="rounded-full bg-warning-50 px-2 py-0.5 text-[9px] font-bold uppercase text-warning-600">TEST ID</span>
        )}
      </div>
      <input
        type="text"
        value={masked && !isTest ? value.replace(/./g, '•').slice(0, 30) + '...' : value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        readOnly={masked && !isTest}
        className="input-field font-mono text-sm"
      />
    </div>
  );
}
