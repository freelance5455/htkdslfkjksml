import { useEffect, useState } from 'react';
import { CheckCircle2, Home, Share2, Sparkles } from 'lucide-react';
import { shareImage } from '@/lib/imageProcessing';
import type { PhotoImageData } from '@/lib/types';

interface SuccessScreenProps {
  image: PhotoImageData;
  operations: string[];
  onHome: () => void;
}

export function SuccessScreen({ image, operations, onHome }: SuccessScreenProps) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setShow(true), 100);
    return () => clearTimeout(t);
  }, []);

  const handleShare = async () => {
    const filename = `photocraft_${Date.now()}.${image.format === 'image/png' ? 'png' : 'jpg'}`;
    await shareImage(image.dataUrl, filename, 'PhotoCraft AI Edit');
  };

  return (
    <div className="min-h-screen bg-gradient-mesh flex flex-col items-center justify-center px-6 overflow-hidden">
      <div className="pointer-events-none absolute -top-20 -left-20 h-72 w-72 rounded-full bg-success-500/20 blur-3xl animate-pulse-soft" />
      <div className="pointer-events-none absolute -bottom-32 -right-20 h-80 w-80 rounded-full bg-brand-500/15 blur-3xl animate-pulse-soft" style={{ animationDelay: '1s' }} />

      {show && (
        <div className="relative flex flex-col items-center animate-scale-in">
          <div className="relative mb-8">
            <div className="absolute inset-0 rounded-full bg-success-500/30 blur-2xl animate-pulse-soft" />
            <div className="relative flex h-28 w-28 items-center justify-center rounded-full bg-gradient-to-br from-success-500 to-success-700 shadow-glow">
              <CheckCircle2 className="h-14 w-14 text-white" />
            </div>
          </div>

          <h1 className="mb-2 font-display text-2xl font-extrabold text-white text-center">
            Photo Saved!
          </h1>
          <p className="mb-2 text-center text-sm text-ink-400 max-w-xs">
            Your edited photo has been saved to your device
          </p>

          {operations.length > 0 && (
            <div className="mb-8 flex flex-wrap items-center justify-center gap-2">
              {operations.map((op, i) => (
                <span
                  key={i}
                  className="flex items-center gap-1 rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-brand-300"
                >
                  <Sparkles className="h-3 w-3" />
                  {op}
                </span>
              ))}
            </div>
          )}

          {/* Preview thumbnail */}
          <div className="mb-8 overflow-hidden rounded-2xl shadow-card ring-1 ring-white/10">
            <img
              src={image.dataUrl}
              alt="Saved photo"
              className="max-h-40 max-w-[200px] object-contain bg-ink-900"
            />
          </div>

          <div className="w-full max-w-xs space-y-3">
            <button onClick={handleShare} className="btn-secondary w-full">
              <Share2 className="h-5 w-5" />
              Share Photo
            </button>
            <button onClick={onHome} className="btn-primary w-full">
              <Home className="h-5 w-5" />
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
