import { useState, useCallback } from 'react';
import {
  ArrowLeft,
  Sparkles,
  Loader2,
  Save,
  Share2,
  Eye,
  Shapes,
  Mountain,
  User,
  Palette,
  AlertCircle,
  X,
  Gift,
} from 'lucide-react';
import type { PhotoImageData, GenerateStyle } from '@/lib/types';
import { aiGenerateImage, saveImageToDevice, shareImage, formatBytes, estimateFileSize } from '@/lib/imageProcessing';
import { RewardedAd } from '@/components/ads/RewardedAd';
import { supabase } from '@/lib/supabase';

interface AIGenerateScreenProps {
  onBack: () => void;
  onPreview: (image: PhotoImageData, operations: string[]) => void;
  onSaved: (image: PhotoImageData, operations: string[]) => void;
}

const STYLES: { key: GenerateStyle; label: string; icon: typeof Sparkles; gradient: string }[] = [
  { key: 'abstract', label: 'Abstract', icon: Palette, gradient: 'from-brand-500 to-accent-500' },
  { key: 'landscape', label: 'Landscape', icon: Mountain, gradient: 'from-success-500 to-brand-600' },
  { key: 'portrait', label: 'Portrait', icon: User, gradient: 'from-accent-400 to-accent-600' },
  { key: 'geometric', label: 'Geometric', icon: Shapes, gradient: 'from-ink-600 to-ink-800' },
];

export function AIGenerateScreen({ onBack, onPreview, onSaved }: AIGenerateScreenProps) {
  const [generatedImage, setGeneratedImage] = useState<PhotoImageData | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [selectedStyle, setSelectedStyle] = useState<GenerateStyle>('abstract');
  const [fileSize, setFileSize] = useState(0);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [rewardedVisible, setRewardedVisible] = useState(false);
  const [pendingAction, setPendingAction] = useState<'generate' | 'save' | null>(null);

  const handleGenerate = useCallback(async () => {
    setLoading(true);
    setLoadingMessage('AI is creating your image...');
    try {
      const result = await aiGenerateImage(1024, 1024, selectedStyle);
      setGeneratedImage(result);
      estimateFileSize(result.dataUrl).then(setFileSize);
    } catch {
      setLoadingMessage('Generation failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [selectedStyle]);

  const handleGenerateClick = useCallback(() => {
    setPendingAction('generate');
    setRewardedVisible(true);
  }, []);

  const saveCurrentImage = useCallback(async () => {
    if (!generatedImage) return;
    setSaveError(null);
    setLoading(true);
    setLoadingMessage('Saving to your device...');
    try {
      const filename = `photocraft_ai_${Date.now()}.jpg`;
      await saveImageToDevice(generatedImage.dataUrl, filename);
      supabase.from('edit_history').insert({
        operations: 'ai_generate',
        saved: true,
        shared: false,
      }).then(() => {}, () => {});
      onSaved(generatedImage, ['ai_generate']);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setSaveError(`Could not save the photo: ${msg}. Please try again.`);
    } finally {
      setLoading(false);
    }
  }, [generatedImage, onSaved]);

  const handleSave = useCallback(() => {
    if (!generatedImage) return;
    setPendingAction('save');
    setRewardedVisible(true);
  }, [generatedImage]);

  const handleRewardedComplete = useCallback(() => {
    setRewardedVisible(false);
    if (pendingAction === 'generate') {
      handleGenerate();
    } else if (pendingAction === 'save') {
      saveCurrentImage();
    }
    setPendingAction(null);
  }, [pendingAction, handleGenerate, saveCurrentImage]);

  const handleShare = useCallback(async () => {
    if (!generatedImage) return;
    setLoading(true);
    setLoadingMessage('Preparing to share...');
    try {
      const filename = `photocraft_ai_${Date.now()}.jpg`;
      await shareImage(generatedImage.dataUrl, filename, 'PhotoCraft AI Generated Image');
    } catch {
      // Ignore share errors
    } finally {
      setLoading(false);
    }
  }, [generatedImage]);

  const handlePreview = useCallback(() => {
    if (!generatedImage) return;
    onPreview(generatedImage, ['ai_generate']);
  }, [generatedImage, onPreview]);

  return (
    <div className="min-h-screen bg-ink-950 flex flex-col">
      {/* Top bar */}
      <div className="safe-top flex items-center justify-between px-4 py-4 bg-ink-950 z-20">
        <button onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white active:scale-90">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="flex flex-col items-center">
          <h1 className="font-display text-base font-semibold text-white">AI Generate</h1>
          {generatedImage && (
            <p className="text-[10px] text-ink-400">{generatedImage.width} × {generatedImage.height} · {formatBytes(fileSize)}</p>
          )}
        </div>
        <div className="w-10" />
      </div>

      {/* Image area */}
      <div className="flex flex-1 items-center justify-center px-4 py-4 overflow-hidden">
        {generatedImage ? (
          <div className="relative max-w-full max-h-full animate-scale-in">
            <img
              src={generatedImage.dataUrl}
              alt="AI Generated"
              className="max-w-full max-h-[50vh] rounded-2xl object-contain shadow-card"
            />
          </div>
        ) : (
          <div className="flex flex-col items-center text-center px-8">
            <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-[2rem] bg-gradient-to-br from-brand-500 to-accent-500 shadow-glow animate-pulse-soft">
              <Sparkles className="h-12 w-12 text-white" />
            </div>
            <h2 className="mb-2 font-display text-xl font-bold text-white">AI Photo Generation</h2>
            <p className="text-sm text-ink-400 max-w-xs">
              Choose a style and let AI create a unique photo for you. Each generation is one-of-a-kind.
            </p>
          </div>
        )}
      </div>

      {/* Style selector */}
      <div className="px-4 py-2">
        <p className="mb-2 text-xs font-medium uppercase tracking-wider text-ink-400">Style</p>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {STYLES.map((s) => (
            <button
              key={s.key}
              onClick={() => setSelectedStyle(s.key)}
              className={`flex shrink-0 items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-medium transition-all active:scale-95 ${
                selectedStyle === s.key
                  ? `bg-gradient-to-r ${s.gradient} text-white shadow-soft`
                  : 'bg-white/10 text-ink-300'
              }`}
            >
              <s.icon className="h-4 w-4" />
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2 px-4 pb-3 safe-bottom">
        {generatedImage && (
          <>
            <button onClick={handleSave} className="btn-primary flex-1">
              <Save className="h-5 w-5" />
              Save
            </button>
            <button onClick={handleShare} className="btn-secondary px-5">
              <Share2 className="h-5 w-5" />
            </button>
            <button onClick={handlePreview} className="btn-secondary px-5">
              <Eye className="h-5 w-5" />
            </button>
          </>
        )}
      </div>

      {/* Generate / Regenerate button */}
      <div className="flex items-center justify-around bg-ink-900 px-2 py-2 safe-bottom border-t border-white/5">
        <button className="editor-tool-btn" onClick={handleGenerateClick}>
          <Gift className="h-5 w-5 text-accent-400" />
          <span className="text-[10px] font-medium">
            {generatedImage ? 'Regenerate' : 'Generate'}
          </span>
        </button>
      </div>

      {/* Rewarded Ad */}
      <RewardedAd
        visible={rewardedVisible}
        rewardText={pendingAction === 'save' ? 'Save' : 'AI Generation'}
        onReward={handleRewardedComplete}
        onClose={() => { setRewardedVisible(false); setPendingAction(null); }}
      />

      {/* Loading overlay */}
      {loading && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-ink-950/90 backdrop-blur-sm">
          <Loader2 className="h-12 w-12 animate-spin text-brand-500" />
          <p className="mt-4 text-sm font-medium text-white">{loadingMessage}</p>
        </div>
      )}

      {/* Save error dialog */}
      {saveError && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/90 px-6 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-ink-900 p-6 shadow-card animate-scale-in">
            <div className="mb-5 flex flex-col items-center text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-error-500/20">
                <AlertCircle className="h-7 w-7 text-error-500" />
              </div>
              <h3 className="font-display text-lg font-bold text-white mb-2">Save Failed</h3>
              <p className="text-sm text-ink-400 leading-relaxed">{saveError}</p>
            </div>
            <button onClick={() => setSaveError(null)} className="btn-primary w-full">
              <X className="h-5 w-5" />
              Dismiss
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
