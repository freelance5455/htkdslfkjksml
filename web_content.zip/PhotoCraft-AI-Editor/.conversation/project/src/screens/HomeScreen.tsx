import {
  Camera,
  Crop,
  Minimize2,
  FileArchive,
  Scissors,
  Sparkles,
  Settings,
  ChevronRight,
  Wand2,
} from 'lucide-react';
import { useAppSettings } from '@/context/AppSettingsContext';

interface HomeScreenProps {
  onNavigate: (screen: 'editor' | 'ai_generate', initialMode?: string) => void;
  onAdminClick: () => void;
}

interface FeatureCardProps {
  icon: typeof Camera;
  label: string;
  description: string;
  gradient: string;
  onClick: () => void;
}

function FeatureCard({ icon: Icon, label, description, gradient, onClick }: FeatureCardProps) {
  return (
    <button
      onClick={onClick}
      className="feature-tile group text-left"
    >
      <div className={`flex h-14 w-14 items-center justify-center rounded-2xl ${gradient} shadow-soft transition-transform group-hover:scale-110`}>
        <Icon className="h-7 w-7 text-white" />
      </div>
      <div className="flex-1">
        <h3 className="font-display text-base font-semibold text-ink-900">{label}</h3>
        <p className="mt-0.5 text-xs text-ink-500 leading-relaxed">{description}</p>
      </div>
      <ChevronRight className="h-5 w-5 text-ink-300 absolute top-5 right-5 transition-transform group-hover:translate-x-1" />
    </button>
  );
}

export function HomeScreen({ onNavigate, onAdminClick }: HomeScreenProps) {
  const { settings } = useAppSettings();

  return (
    <div className="min-h-screen bg-ink-50 pb-28">
      {/* Header */}
      <div className="bg-gradient-mesh relative px-6 pb-12 pt-14 safe-top overflow-hidden">
        <div className="pointer-events-none absolute -top-20 -right-16 h-56 w-56 rounded-full bg-brand-500/20 blur-3xl" />
        <div className="pointer-events-none absolute top-10 -left-10 h-40 w-40 rounded-full bg-accent-500/10 blur-3xl" />

        <div className="relative">
          <div className="mb-8 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-brand-300">Welcome back</p>
              <h1 className="font-display text-2xl font-extrabold text-white tracking-tight">
                PhotoCraft AI
              </h1>
            </div>
            <button
              onClick={onAdminClick}
              className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white/80 backdrop-blur-sm transition-all active:scale-90 hover:bg-white/20"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>

          {/* Hero card */}
          <div className="rounded-3xl bg-white/10 p-5 backdrop-blur-md ring-1 ring-white/15 animate-slide-up">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-brand">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-display text-base font-semibold text-white">
                  AI-Powered Editing
                </p>
                <p className="text-xs text-ink-300 mt-0.5">
                  Enhance, crop, compress & remove backgrounds
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature grid */}
      <div className="-mt-6 px-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-ink-900">Quick Actions</h2>
        </div>

        {/* Primary CTAs */}
        <button
          onClick={() => onNavigate('editor')}
          className="mb-3 flex w-full items-center gap-4 rounded-3xl bg-gradient-to-r from-brand-600 to-brand-700 p-5 shadow-card transition-all active:scale-95 hover:shadow-glow animate-slide-up"
        >
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-sm">
            <Camera className="h-7 w-7 text-white" />
          </div>
          <div className="flex-1 text-left">
            <h3 className="font-display text-lg font-bold text-white">Create / Edit Photo</h3>
            <p className="text-xs text-brand-100 mt-0.5">Start a new editing session</p>
          </div>
          <ChevronRight className="h-6 w-6 text-white/70" />
        </button>

        <button
          onClick={() => onNavigate('ai_generate')}
          className="mb-5 flex w-full items-center gap-4 rounded-3xl bg-gradient-to-r from-accent-500 to-accent-600 p-5 shadow-card transition-all active:scale-95 hover:shadow-glow animate-slide-up"
        >
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-sm">
            <Wand2 className="h-7 w-7 text-white" />
          </div>
          <div className="flex-1 text-left">
            <h3 className="font-display text-lg font-bold text-white">AI Generate Photo</h3>
            <p className="text-xs text-accent-100 mt-0.5">Create unique art with AI</p>
          </div>
          <ChevronRight className="h-6 w-6 text-white/70" />
        </button>

        {/* Feature grid */}
        <div className="grid grid-cols-2 gap-4">
          <FeatureCard
            icon={Crop}
            label="Crop & Resize"
            description="Trim and scale"
            gradient="bg-gradient-to-br from-brand-400 to-brand-600"
            onClick={() => onNavigate('editor', 'crop')}
          />
          <FeatureCard
            icon={FileArchive}
            label="Compress"
            description="Reduce file size"
            gradient="bg-gradient-to-br from-success-500 to-success-700"
            onClick={() => onNavigate('editor', 'compress')}
          />
          <FeatureCard
            icon={Scissors}
            label="Remove BG"
            description="Cut out background"
            gradient="bg-gradient-to-br from-accent-400 to-accent-600"
            onClick={() => onNavigate('editor', 'bg_remove')}
          />
          <FeatureCard
            icon={Sparkles}
            label="AI Enhance"
            description="Smart improvement"
            gradient="bg-gradient-to-br from-brand-500 to-accent-500"
            onClick={() => onNavigate('editor', 'ai_enhance')}
          />
          <FeatureCard
            icon={Minimize2}
            label="Resize"
            description="Change dimensions"
            gradient="bg-gradient-to-br from-ink-600 to-ink-800"
            onClick={() => onNavigate('editor', 'resize')}
          />
        </div>
      </div>

      {settings.maintenance_mode && (
        <div className="mt-6 mx-5 rounded-2xl bg-warning-50 p-4 ring-1 ring-warning-500/20">
          <p className="text-sm font-medium text-warning-600">
            Maintenance mode is active. Some features may be unavailable.
          </p>
        </div>
      )}
    </div>
  );
}
