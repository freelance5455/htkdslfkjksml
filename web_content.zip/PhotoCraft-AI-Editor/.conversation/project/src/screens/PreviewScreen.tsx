import { ArrowLeft, Save, Share2, Edit3, Loader2, AlertCircle, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import type { PhotoImageData } from '@/lib/types';
import { saveImageToDevice, shareImage, formatBytes, estimateFileSize } from '@/lib/imageProcessing';
import { supabase } from '@/lib/supabase';
import { RewardedAd } from '@/components/ads/RewardedAd';

interface PreviewScreenProps {
  image: PhotoImageData;
  operations: string[];
  onBack: () => void;
  onSaved: () => void;
}

export function PreviewScreen({ image, operations, onBack, onSaved }: PreviewScreenProps) {
  const [saving, setSaving] = useState(false);
  const [fileSize, setFileSize] = useState(0);
  const [sizeLoaded, setSizeLoaded] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [rewardedVisible, setRewardedVisible] = useState(false);

  useEffect(() => {
    estimateFileSize(image.dataUrl).then((s) => {
      setFileSize(s);
      setSizeLoaded(true);
    });
  }, [image.dataUrl]);

  const saveCurrentImage = async () => {
    setSaveError(null);
    setSaving(true);
    try {
      const filename = `photocraft_${Date.now()}.${image.format === 'image/png' ? 'png' : 'jpg'}`;
      await saveImageToDevice(image.dataUrl, filename);

      // Log to edit history (non-blocking)
      supabase.from('edit_history').insert({
        operations: operations.join(','),
        saved: true,
        shared: false,
      }).then(() => {}, () => {});

      onSaved();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setSaveError(`Could not save the photo: ${msg}. Please try again.`);
    } finally {
      setSaving(false);
    }
  };

  const handleSave = () => {
    setRewardedVisible(true);
  };

  const handleShare = async () => {
    const filename = `photocraft_${Date.now()}.${image.format === 'image/png' ? 'png' : 'jpg'}`;
    await shareImage(image.dataUrl, filename, 'PhotoCraft AI Edit');
    supabase.from('edit_history').insert({
      operations: operations.join(','),
      saved: false,
      shared: true,
    }).then(() => {}, () => {});
  };

  return (
    <div className="min-h-screen bg-ink-950 flex flex-col">
      <div className="safe-top flex items-center justify-between px-4 py-4">
        <button onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white active:scale-90">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display text-lg font-semibold text-white">Preview</h1>
        <div className="w-10" />
      </div>

      <div className="flex flex-1 items-center justify-center px-6 py-4 overflow-hidden">
        <div className="relative animate-scale-in">
          <img
            src={image.dataUrl}
            alt="Preview"
            className="max-w-full max-h-[55vh] rounded-3xl object-contain shadow-card"
            style={{
              backgroundImage: image.format === 'image/png'
                ? 'linear-gradient(45deg, #2a2a2a 25%, transparent 25%), linear-gradient(-45deg, #2a2a2a 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #2a2a2a 75%), linear-gradient(-45deg, transparent 75%, #2a2a2a 75%)'
                : undefined,
              backgroundSize: image.format === 'image/png' ? '20px 20px' : undefined,
              backgroundPosition: image.format === 'image/png' ? '0 0, 0 10px, 10px -10px, -10px 0px' : undefined,
            }}
          />
        </div>
      </div>

      {/* Info card */}
      <div className="px-6 py-3">
        <div className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium uppercase tracking-wider text-ink-400">Dimensions</span>
            <span className="text-sm font-semibold text-white">{image.width} × {image.height}</span>
          </div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium uppercase tracking-wider text-ink-400">File size</span>
            <span className="text-sm font-semibold text-white">{sizeLoaded ? formatBytes(fileSize) : '...'}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wider text-ink-400">Operations</span>
            <span className="text-sm font-semibold text-brand-400">{operations.length} applied</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="safe-bottom space-y-3 px-6 pb-6 pt-3">
        <button onClick={handleSave} disabled={saving} className="btn-primary w-full">
          {saving ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-5 w-5" />
              Save to Gallery
            </>
          )}
        </button>
        <div className="flex gap-3">
          <button onClick={handleShare} className="btn-secondary flex-1">
            <Share2 className="h-5 w-5" />
            Share
          </button>
          <button onClick={onBack} className="btn-secondary flex-1">
            <Edit3 className="h-5 w-5" />
            Keep Editing
          </button>
        </div>
      </div>

      <RewardedAd
        visible={rewardedVisible}
        rewardText="Save"
        onReward={() => {
          setRewardedVisible(false);
          saveCurrentImage();
        }}
        onClose={() => setRewardedVisible(false)}
      />

      {/* Save error dialog */}
      {saveError && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/90 px-6 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-ink-900 p-6 shadow-card animate-scale-in">
            <div className="mb-5 flex flex-col items-center text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-error-500/20">
                <AlertCircle className="h-7 w-7 text-error-500" />
              </div>
              <h3 className="font-display text-lg font-bold text-white mb-2">Save Failed</h3>
              <p className="text-sm text-ink-400 leading-relaxed">{saveError}</p>
            </div>
            <button
              onClick={() => setSaveError(null)}
              className="btn-primary w-full"
            >
              <X className="h-5 w-5" />
              Dismiss
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
