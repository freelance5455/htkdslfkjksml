import { Wrench, Clock } from 'lucide-react';

interface MaintenanceScreenProps {
  onRetry: () => void;
}

export function MaintenanceScreen({ onRetry }: MaintenanceScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-mesh flex flex-col items-center justify-center px-6">
      <div className="pointer-events-none absolute -top-20 -right-20 h-72 w-72 rounded-full bg-warning-500/15 blur-3xl" />

      <div className="relative flex flex-col items-center animate-scale-in">
        <div className="mb-8 flex h-24 w-24 items-center justify-center rounded-[2rem] bg-gradient-to-br from-warning-500 to-warning-600 shadow-glow">
          <Wrench className="h-12 w-12 text-white" />
        </div>

        <h1 className="mb-2 font-display text-2xl font-extrabold text-white text-center">
          Under Maintenance
        </h1>
        <p className="mb-10 text-center text-sm text-ink-400 max-w-xs">
          PhotoCraft AI is currently undergoing maintenance. Please check back soon.
        </p>

        <button onClick={onRetry} className="btn-primary">
          <Clock className="h-5 w-5" />
          Try Again
        </button>
      </div>
    </div>
  );
}
