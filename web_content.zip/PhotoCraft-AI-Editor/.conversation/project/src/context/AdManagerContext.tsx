import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { useAppSettings } from './AppSettingsContext';
import { AdFrequencyController, settingsToAdMobConfig } from '@/lib/admob';
import type { AdMobConfig } from '@/lib/types';
import { initializeNativeAds, isAndroidApp, showNativeRewardedAd } from '@/lib/native';

interface AdManagerContextValue {
  config: AdMobConfig;
  adsEnabled: boolean;
  frequencyController: AdFrequencyController;
  showInterstitial: () => boolean;
  bannerVisible: boolean;
  setBannerVisible: (v: boolean) => void;
  rewardedReady: boolean;
  showRewardedAd: () => Promise<boolean>;
}

const AdManagerContext = createContext<AdManagerContextValue | null>(null);

export function AdManagerProvider({ children }: { children: ReactNode }) {
  const { settings } = useAppSettings();
  const [controller] = useState(() => new AdFrequencyController());
  const [bannerVisible, setBannerVisible] = useState(true);

  const config = settingsToAdMobConfig(settings);
  const adsEnabled = settings.ads_enabled;

  useEffect(() => {
    controller.updateSettings(settings.ad_cooldown_seconds, settings.ad_frequency);
    if (!adsEnabled) controller.reset();
  }, [settings, controller, adsEnabled]);

  useEffect(() => {
    if (!isAndroidApp) return;
    initializeNativeAds(config).catch(() => {
      // Rewarded actions remain blocked if the native SDK cannot initialize.
    });
  }, [config]);

  const showInterstitial = useCallback((): boolean => {
    if (!adsEnabled) return false;
    return controller.shouldShowInterstitial();
  }, [adsEnabled, controller]);

  const showRewardedAd = useCallback(async (): Promise<boolean> => {
    if (isAndroidApp) {
      try {
        return await showNativeRewardedAd(config);
      } catch {
        return false;
      }
    }
    if (!adsEnabled) return true;
    // Browser-only fallback; Android always uses the native SDK above.
    await new Promise((resolve) => setTimeout(resolve, 1500));
    return true;
  }, [adsEnabled, config]);

  return (
    <AdManagerContext.Provider
      value={{
        config,
        adsEnabled,
        frequencyController: controller,
        showInterstitial,
        bannerVisible,
        setBannerVisible,
        rewardedReady: isAndroidApp || adsEnabled,
        showRewardedAd,
      }}
    >
      {children}
    </AdManagerContext.Provider>
  );
}

export function useAdManager() {
  const ctx = useContext(AdManagerContext);
  if (!ctx) throw new Error('useAdManager must be used within AdManagerProvider');
  return ctx;
}
