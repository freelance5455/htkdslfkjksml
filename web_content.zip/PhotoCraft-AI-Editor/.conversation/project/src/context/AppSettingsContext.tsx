import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import type { AppSettings } from '@/lib/types';
import { TEST_ADMOB_CONFIG } from '@/lib/admob';

interface AppSettingsContextValue {
  settings: AppSettings;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

const defaultSettings: AppSettings = {
  id: 1,
  ads_enabled: true,
  maintenance_mode: false,
  admob_app_id: TEST_ADMOB_CONFIG.appId,
  banner_ad_unit_id: TEST_ADMOB_CONFIG.bannerId,
  interstitial_ad_unit_id: TEST_ADMOB_CONFIG.interstitialId,
  rewarded_ad_unit_id: TEST_ADMOB_CONFIG.rewardedId,
  ad_cooldown_seconds: 60,
  ad_frequency: 3,
  hd_export_rewarded: true,
  ai_enhance_rewarded: true,
  updated_at: new Date().toISOString(),
};

const AppSettingsContext = createContext<AppSettingsContextValue>({
  settings: defaultSettings,
  loading: true,
  error: null,
  refresh: async () => {},
});

export function AppSettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('*')
        .eq('id', 1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setSettings(data as AppSettings);
      }
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load settings');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return (
    <AppSettingsContext.Provider value={{ settings, loading, error, refresh }}>
      {children}
    </AppSettingsContext.Provider>
  );
}

export function useAppSettings() {
  return useContext(AppSettingsContext);
}
