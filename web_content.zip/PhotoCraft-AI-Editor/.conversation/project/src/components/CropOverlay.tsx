import { useState, useRef, useCallback, useEffect } from 'react';
import { Check, X, Crop as CropIcon } from 'lucide-react';
import type { PhotoImageData } from '@/lib/imageProcessing';

interface CropOverlayProps {
  image: PhotoImageData;
  onCrop: (x: number, y: number, width: number, height: number) => void;
  onCancel: () => void;
}

const ASPECT_RATIOS = [
  { label: 'Free', ratio: 0 },
  { label: '1:1', ratio: 1 },
  { label: '4:3', ratio: 4 / 3 },
  { label: '3:4', ratio: 3 / 4 },
  { label: '16:9', ratio: 16 / 9 },
  { label: '9:16', ratio: 9 / 16 },
];

export function CropOverlay({ image, onCrop, onCancel }: CropOverlayProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [crop, setCrop] = useState({ x: 10, y: 10, width: 80, height: 80 });
  const [aspectIndex, setAspectIndex] = useState(0);
  const dragging = useRef<{ type: 'move' | 'resize' | null; startX: number; startY: number; origX: number; origY: number; origW: number; origH: number }>({
    type: null,
    startX: 0,
    startY: 0,
    origX: 0,
    origY: 0,
    origW: 0,
    origH: 0,
  });

  const applyAspect = useCallback((ratio: number) => {
    if (ratio === 0) return;
    setCrop((prev) => {
      const newH = prev.width / ratio;
      if (newH <= 100) {
        return { ...prev, height: newH, y: Math.max(0, Math.min(100 - newH, prev.y)) };
      }
      const newW = prev.height * ratio;
      return { ...prev, width: newW, x: Math.max(0, Math.min(100 - newW, prev.x)) };
    });
  }, []);

  useEffect(() => {
    if (aspectIndex > 0) applyAspect(ASPECT_RATIOS[aspectIndex].ratio);
  }, [aspectIndex, applyAspect]);

  const handlePointerDown = (e: React.PointerEvent, type: 'move' | 'resize') => {
    e.stopPropagation();
    dragging.current = {
      type,
      startX: e.clientX,
      startY: e.clientY,
      origX: crop.x,
      origY: crop.y,
      origW: crop.width,
      origH: crop.height,
    };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragging.current.type || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const dxPct = ((e.clientX - dragging.current.startX) / rect.width) * 100;
    const dyPct = ((e.clientY - dragging.current.startY) / rect.height) * 100;

    if (dragging.current.type === 'move') {
      setCrop((prev) => ({
        ...prev,
        x: Math.max(0, Math.min(100 - prev.width, dragging.current.origX + dxPct)),
        y: Math.max(0, Math.min(100 - prev.height, dragging.current.origY + dyPct)),
      }));
    } else {
      const newW = Math.max(10, Math.min(100 - dragging.current.origX, dragging.current.origW + dxPct));
      const ratio = ASPECT_RATIOS[aspectIndex].ratio;
      let newH = Math.max(10, Math.min(100 - dragging.current.origY, dragging.current.origH + dyPct));
      if (ratio > 0) newH = newW / ratio;
      setCrop((prev) => ({
        ...prev,
        width: Math.min(newW, 100 - prev.x),
        height: Math.min(newH, 100 - prev.y),
      }));
    }
  };

  const handlePointerUp = () => {
    dragging.current.type = null;
  };

  const handleConfirm = () => {
    const x = (crop.x / 100) * image.width;
    const y = (crop.y / 100) * image.height;
    const w = (crop.width / 100) * image.width;
    const h = (crop.height / 100) * image.height;
    onCrop(x, y, w, h);
  };

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-ink-950">
      {/* Header */}
      <div className="safe-top flex items-center justify-between px-4 py-4">
        <button
          onClick={onCancel}
          className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white active:scale-90"
        >
          <X className="h-5 w-5" />
        </button>
        <h2 className="font-display font-semibold text-white">Crop Photo</h2>
        <button
          onClick={handleConfirm}
          className="flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-600 text-white active:scale-90"
        >
          <Check className="h-5 w-5" />
        </button>
      </div>

      {/* Image with crop overlay */}
      <div className="flex flex-1 items-center justify-center px-4 overflow-hidden">
        <div
          ref={containerRef}
          className="relative touch-none select-none"
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          style={{ maxWidth: '100%', maxHeight: '100%' }}
        >
          <img
            src={image.dataUrl}
            alt="To crop"
            className="block max-w-full max-h-[60vh] rounded-lg"
            draggable={false}
          />
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-ink-950/60 rounded-lg pointer-events-none" />
          {/* Crop window */}
          <div
            className="absolute border-2 border-brand-400 cursor-move touch-none"
            style={{
              left: `${crop.x}%`,
              top: `${crop.y}%`,
              width: `${crop.width}%`,
              height: `${crop.height}%`,
              boxShadow: '0 0 0 9999px rgba(15, 23, 42, 0.6)',
            }}
            onPointerDown={(e) => handlePointerDown(e, 'move')}
          >
            {/* Grid lines */}
            <div className="pointer-events-none absolute inset-0">
              <div className="absolute top-1/3 left-0 right-0 border-t border-white/30" />
              <div className="absolute top-2/3 left-0 right-0 border-t border-white/30" />
              <div className="absolute left-1/3 top-0 bottom-0 border-l border-white/30" />
              <div className="absolute left-2/3 top-0 bottom-0 border-l border-white/30" />
            </div>
            {/* Corner handles */}
            {[
              { pos: '-bottom-1 -right-1', cursor: 'nwse-resize' },
            ].map((h, i) => (
              <div
                key={i}
                className={`absolute ${h.pos} h-5 w-5 rounded-full bg-brand-500 ring-2 ring-white shadow-lg`}
                style={{ cursor: h.cursor, touchAction: 'none' }}
                onPointerDown={(e) => handlePointerDown(e, 'resize')}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Aspect ratio options */}
      <div className="safe-bottom px-4 pb-6 pt-4">
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {ASPECT_RATIOS.map((r, i) => (
            <button
              key={r.label}
              onClick={() => setAspectIndex(i)}
              className={`flex shrink-0 items-center gap-1.5 rounded-2xl px-4 py-2.5 text-sm font-medium transition-all active:scale-95 ${
                aspectIndex === i
                  ? 'bg-brand-600 text-white'
                  : 'bg-white/10 text-ink-300'
              }`}
            >
              <CropIcon className="h-4 w-4" />
              {r.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
