import { useState, useEffect } from 'react';
import { Gift, Loader2, CheckCircle2, X } from 'lucide-react';
import { useAdManager } from '@/context/AdManagerContext';

interface RewardedAdProps {
  visible: boolean;
  rewardText: string;
  onReward: () => void;
  onClose: () => void;
}

type AdState = 'prompt' | 'loading' | 'success' | 'error';

/**
 * Rewarded Ad modal.
 * The protected action only continues after the native AdMob bridge reports
 * a completed reward. Failed or dismissed ads never grant the reward.
 */
export function RewardedAd({ visible, rewardText, onReward, onClose }: RewardedAdProps) {
  const { showRewardedAd } = useAdManager();
  const [adState, setAdState] = useState<AdState>('prompt');

  // Reset state when ad becomes visible
  useEffect(() => {
    if (visible) {
      setAdState('prompt');
    }
  }, [visible]);

  const handleWatch = async () => {
    setAdState('loading');
    try {
      const success = await showRewardedAd();
      if (success) {
        setAdState('success');
        setTimeout(() => {
          onReward();
        }, 1500);
      } else {
        setAdState('error');
      }
    } catch {
      setAdState('error');
    }
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/95 animate-fade-in">
      <div className="relative flex w-full max-w-sm flex-col items-center px-8 animate-scale-in">
        {adState !== 'success' && (
          <button
            onClick={onClose}
            className="absolute -top-2 right-0 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-all active:scale-90 hover:bg-white/20"
          >
            <X className="h-5 w-5" />
          </button>
        )}

        {adState === 'prompt' && (
          <>
            <div className="mb-8 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-accent-400 to-accent-600 shadow-glow">
              <Gift className="h-10 w-10 text-white" />
            </div>
            <p className="mb-1 text-xs font-medium uppercase tracking-widest text-accent-400">
              Rewarded Ad
            </p>
            <h2 className="mb-2 text-2xl font-display font-bold text-white">
              Unlock {rewardText}
            </h2>
            <p className="mb-10 text-center text-sm text-ink-400">
              Watch a short ad to unlock this feature for free.
            </p>
            <button
              onClick={handleWatch}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-accent-500 px-6 py-4 font-semibold text-white shadow-soft transition-all active:scale-95 hover:bg-accent-600"
            >
              <Gift className="h-5 w-5" />
              Watch Ad to Continue
            </button>
          </>
        )}

        {adState === 'loading' && (
          <>
            <div className="mb-8 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-accent-400 to-accent-600 shadow-glow">
              <Loader2 className="h-10 w-10 text-white animate-spin" />
            </div>
            <p className="mb-1 text-xs font-medium uppercase tracking-widest text-accent-400">
              Rewarded Ad
            </p>
            <h2 className="mb-2 text-2xl font-display font-bold text-white">
              Watching Ad...
            </h2>
            <p className="text-center text-sm text-ink-400">
              Please wait while the ad plays. Your reward will unlock shortly.
            </p>
          </>
        )}

        {adState === 'error' && (
          <>
            <div className="mb-8 flex h-20 w-20 items-center justify-center rounded-3xl bg-error-500/20">
              <X className="h-10 w-10 text-error-500" />
            </div>
            <p className="mb-1 text-xs font-medium uppercase tracking-widest text-error-400">
              Ad unavailable
            </p>
            <h2 className="mb-2 text-2xl font-display font-bold text-white">
              Could not show the ad
            </h2>
            <p className="mb-8 text-center text-sm text-ink-400">
              No reward was granted. Try again or cancel to return without continuing.
            </p>
            <button
              onClick={handleWatch}
              className="mb-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-accent-500 px-6 py-4 font-semibold text-white shadow-soft transition-all active:scale-95 hover:bg-accent-600"
            >
              <Gift className="h-5 w-5" />
              Try Again
            </button>
            <button
              onClick={onClose}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-white/10 px-6 py-3 font-medium text-white transition-all active:scale-95 hover:bg-white/20"
            >
              Cancel
            </button>
          </>
        )}

        {adState === 'success' && (
          <>
            <div className="mb-8 flex h-20 w-20 items-center justify-center rounded-3xl bg-success-500 shadow-glow animate-scale-in">
              <CheckCircle2 className="h-10 w-10 text-white" />
            </div>
            <h2 className="mb-2 text-2xl font-display font-bold text-white">
              Reward Unlocked!
            </h2>
            <p className="text-center text-sm text-ink-400">
              {rewardText} is now available. Enjoy!
            </p>
          </>
        )}
      </div>
    </div>
  );
}
