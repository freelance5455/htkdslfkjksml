import { useEffect, useState } from 'react';
import { X, Sparkles } from 'lucide-react';
import { Capacitor } from '@capacitor/core';

interface InterstitialAdProps {
  visible: boolean;
  onClose: () => void;
}

/**
 * Interstitial Ad modal.
 * Shows a full-screen ad overlay at appropriate points in the user flow.
 * This legacy web-only placeholder is hidden in the Android build.
 */
export function InterstitialAd({ visible, onClose }: InterstitialAdProps) {
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    if (!visible) {
      setCountdown(3);
      return;
    }

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [visible]);

  if (!visible || Capacitor.getPlatform() === 'android') return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/95 animate-fade-in">
      <div className="relative flex w-full max-w-sm flex-col items-center px-8 animate-scale-in">
        <div className="mb-8 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-brand shadow-glow">
          <Sparkles className="h-10 w-10 text-white" />
        </div>

        <p className="mb-1 text-xs font-medium uppercase tracking-widest text-brand-400">
          Advertisement
        </p>
        <h2 className="mb-2 text-2xl font-display font-bold text-white">
          Your Ad Here
        </h2>
        <p className="mb-10 text-center text-sm text-ink-400">
          This is where Google AdMob interstitial ads will appear when
          you add your real ad unit ID.
        </p>

        <div className="h-1 w-full overflow-hidden rounded-full bg-ink-800">
          <div
            className="h-full bg-brand-500 transition-all duration-1000 ease-linear"
            style={{ width: `${((3 - countdown) / 3) * 100}%` }}
          />
        </div>

        <button
          onClick={onClose}
          disabled={countdown > 0}
          className="mt-8 flex items-center gap-2 rounded-2xl bg-white/10 px-6 py-3 font-medium text-white transition-all active:scale-95 hover:bg-white/20 disabled:opacity-40"
        >
          {countdown > 0 ? (
            <span>Skip in {countdown}s</span>
          ) : (
            <>
              <X className="h-5 w-5" />
              <span>Close Ad</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
