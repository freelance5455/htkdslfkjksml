import { useAdManager } from '@/context/AdManagerContext';
import { Capacitor } from '@capacitor/core';

/**
 * Banner Ad component.
 * Renders a non-intrusive banner at the bottom of the screen.
 * This legacy web-only placeholder is hidden in the Android build.
 */
export function BannerAd() {
  const { adsEnabled, bannerVisible, config } = useAdManager();
  // Android must not render simulated ad UI.
  if (Capacitor.getPlatform() === 'android') return null;

  if (!adsEnabled || !bannerVisible) return null;

  return (
    <div className="safe-bottom fixed bottom-0 left-0 right-0 z-30 flex h-[60px] items-center justify-center bg-ink-900/95 backdrop-blur-sm">
      <div className="flex items-center gap-2 px-4 text-center">
        <div className="flex items-center gap-1.5 text-ink-400">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-success-500 animate-pulse-soft" />
          <span className="text-[10px] font-medium uppercase tracking-wider">Ad</span>
        </div>
        <span className="text-xs text-ink-500 truncate max-w-[180px]">
          Banner Ad Unit: {config.bannerId.replace('ca-app-pub-3940256099942544/', 'TEST /')}
        </span>
      </div>
    </div>
  );
}
