import { useState, useEffect } from 'react';
import { X, FileArchive, Zap } from 'lucide-react';
import type { PhotoImageData } from '@/lib/imageProcessing';
import { estimateFileSize, formatBytes } from '@/lib/imageProcessing';

interface CompressPanelProps {
  image: PhotoImageData;
  onCompress: (quality: number) => void;
  onCancel: () => void;
}

export function CompressPanel({ image, onCompress, onCancel }: CompressPanelProps) {
  const [quality, setQuality] = useState(60);
  const [estimatedSize, setEstimatedSize] = useState(0);

  useEffect(() => {
    // Estimate compressed size based on quality ratio
    estimateFileSize(image.dataUrl).then((original) => {
      setEstimatedSize(Math.round(original * (quality / 100)));
    });
  }, [quality, image.dataUrl]);

  const qualityLabels: Record<number, string> = {
    20: 'Max Compression',
    40: 'High Compression',
    60: 'Balanced',
    80: 'High Quality',
    100: 'Original Quality',
  };

  const getLabel = () => {
    const keys = Object.keys(qualityLabels).map(Number).sort((a, b) => a - b);
    for (const k of keys) {
      if (quality <= k) return qualityLabels[k];
    }
    return 'Custom';
  };

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-ink-950">
      <div className="safe-top flex items-center justify-between px-4 py-4">
        <button onClick={onCancel} className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white active:scale-90">
          <X className="h-5 w-5" />
        </button>
        <h2 className="font-display font-semibold text-white">Compress Photo</h2>
        <div className="w-10" />
      </div>

      <div className="flex flex-1 items-center justify-center px-6 overflow-hidden">
        <img src={image.dataUrl} alt="To compress" className="max-w-full max-h-[45vh] rounded-xl opacity-80" />
      </div>

      <div className="safe-bottom space-y-5 px-6 pb-6 pt-4">
        {/* Quality slider */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <label className="text-sm font-medium text-ink-300">Quality</label>
            <span className="font-display font-bold text-white">{quality}%</span>
          </div>
          <input
            type="range"
            min="10"
            max="100"
            value={quality}
            onChange={(e) => setQuality(parseInt(e.target.value))}
            className="w-full h-2 rounded-full appearance-none bg-ink-700 accent-brand-500 cursor-pointer"
          />
          <p className="mt-2 text-xs text-brand-400 font-medium">{getLabel()}</p>
        </div>

        {/* Size estimation */}
        <div className="flex items-center justify-between rounded-2xl bg-white/5 px-5 py-4 ring-1 ring-white/10">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/20">
              <FileArchive className="h-5 w-5 text-brand-400" />
            </div>
            <div>
              <p className="text-xs text-ink-400">Estimated size</p>
              <p className="font-display font-bold text-white">{formatBytes(estimatedSize)}</p>
            </div>
          </div>
          <Zap className="h-5 w-5 text-accent-400" />
        </div>

        <button
          onClick={() => onCompress(quality / 100)}
          className="btn-primary w-full"
        >
          Apply Compression
        </button>
      </div>
    </div>
  );
}
