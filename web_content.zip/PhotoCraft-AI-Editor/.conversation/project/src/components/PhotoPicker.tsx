import { useRef, useCallback } from 'react';
import { ImagePlus, FolderOpen } from 'lucide-react';

interface PhotoPickerProps {
  onPhotoSelected: (file: File) => void;
}

/**
 * Photo selection component.
 * Provides gallery selection via file input (accept="image/*").
 * On Android, this opens the system gallery picker.
 */
export function PhotoPicker({ onPhotoSelected }: PhotoPickerProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) onPhotoSelected(file);
      // Reset so the same file can be picked again
      if (inputRef.current) inputRef.current.value = '';
    },
    [onPhotoSelected],
  );

  return (
    <div className="flex flex-col items-center justify-center px-6 py-16">
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFile}
      />

      <div className="mb-8 flex h-24 w-24 items-center justify-center rounded-[2rem] bg-gradient-to-br from-brand-100 to-brand-200">
        <FolderOpen className="h-12 w-12 text-brand-600" />
      </div>

      <h2 className="mb-2 font-display text-xl font-bold text-ink-900 text-center">
        Select a Photo
      </h2>
      <p className="mb-10 text-center text-sm text-ink-500 max-w-xs">
        Choose a photo from your gallery to start editing
      </p>

      <button
        onClick={() => inputRef.current?.click()}
        className="btn-primary w-full max-w-xs"
      >
        <ImagePlus className="h-5 w-5" />
        Choose from Gallery
      </button>
    </div>
  );
}
