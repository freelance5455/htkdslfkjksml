import { useState } from 'react';
import { X, Minimize2, Lock, Unlock } from 'lucide-react';
import type { PhotoImageData } from '@/lib/imageProcessing';

interface ResizePanelProps {
  image: PhotoImageData;
  onResize: (width: number, height: number) => void;
  onCancel: () => void;
}

export function ResizePanel({ image, onResize, onCancel }: ResizePanelProps) {
  const [width, setWidth] = useState(image.width);
  const [height, setHeight] = useState(image.height);
  const [lockAspect, setLockAspect] = useState(true);
  const ratio = image.width / image.height;

  const handleWidthChange = (w: number) => {
    setWidth(w);
    if (lockAspect) setHeight(Math.round(w / ratio));
  };

  const handleHeightChange = (h: number) => {
    setHeight(h);
    if (lockAspect) setWidth(Math.round(h * ratio));
  };

  const presets = [
    { label: 'Original', w: image.width, h: image.height },
    { label: 'HD 720p', w: 1280, h: 720 },
    { label: 'Full HD', w: 1920, h: 1080 },
    { label: 'Square 1080', w: 1080, h: 1080 },
    { label: 'Instagram', w: 1080, h: 1080 },
    { label: 'Story 9:16', w: 1080, h: 1920 },
    { label: 'Small 640', w: 640, h: 360 },
  ];

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-ink-950">
      <div className="safe-top flex items-center justify-between px-4 py-4">
        <button onClick={onCancel} className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-white active:scale-90">
          <X className="h-5 w-5" />
        </button>
        <h2 className="font-display font-semibold text-white">Resize Photo</h2>
        <div className="w-10" />
      </div>

      <div className="flex flex-1 items-center justify-center px-6 overflow-hidden">
        <div className="relative">
          <img src={image.dataUrl} alt="To resize" className="max-w-full max-h-[45vh] rounded-xl opacity-80" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="rounded-2xl bg-ink-950/80 px-4 py-2 backdrop-blur-sm">
              <span className="text-sm font-semibold text-white">{width} × {height}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="safe-bottom space-y-4 px-6 pb-6 pt-4">
        {/* Dimensions */}
        <div className="flex items-end gap-3">
          <div className="flex-1">
            <label className="mb-1.5 block text-xs font-medium text-ink-400">Width (px)</label>
            <input
              type="number"
              value={width}
              onChange={(e) => handleWidthChange(parseInt(e.target.value) || 0)}
              className="w-full rounded-2xl bg-white/10 px-4 py-3 text-white ring-1 ring-inset ring-white/15 focus:ring-2 focus:ring-brand-500 focus:outline-none"
            />
          </div>
          <button
            onClick={() => setLockAspect(!lockAspect)}
            className="mb-1 flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-white transition-all active:scale-90"
          >
            {lockAspect ? <Lock className="h-5 w-5" /> : <Unlock className="h-5 w-5" />}
          </button>
          <div className="flex-1">
            <label className="mb-1.5 block text-xs font-medium text-ink-400">Height (px)</label>
            <input
              type="number"
              value={height}
              onChange={(e) => handleHeightChange(parseInt(e.target.value) || 0)}
              className="w-full rounded-2xl bg-white/10 px-4 py-3 text-white ring-1 ring-inset ring-white/15 focus:ring-2 focus:ring-brand-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Presets */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {presets.map((p) => (
            <button
              key={p.label}
              onClick={() => { setWidth(p.w); setHeight(p.h); }}
              className="flex shrink-0 items-center gap-1.5 rounded-2xl bg-white/10 px-3.5 py-2 text-xs font-medium text-ink-300 transition-all active:scale-95 hover:bg-white/20"
            >
              <Minimize2 className="h-3.5 w-3.5" />
              {p.label}
            </button>
          ))}
        </div>

        <button
          onClick={() => onResize(width, height)}
          disabled={width < 1 || height < 1}
          className="btn-primary w-full"
        >
          Apply Resize
        </button>
      </div>
    </div>
  );
}
