import { Capacitor } from '@capacitor/core';
import { AdMob, MaxAdContentRating } from '@capacitor-community/admob';
import type { AdMobConfig } from './types';

export const isAndroidApp = Capacitor.getPlatform() === 'android';

const TEST_REWARDED_AD_UNIT_ID = 'ca-app-pub-3940256099942544/5224354917';

let nativeAdsInitialized = false;

export async function initializeNativeAds(config: AdMobConfig): Promise<void> {
  if (!isAndroidApp || nativeAdsInitialized) return;

  await AdMob.initialize({
    initializeForTesting: true,
    maxAdContentRating: MaxAdContentRating.General,
  });
  nativeAdsInitialized = true;
  void config;
}

export async function showNativeRewardedAd(config: AdMobConfig): Promise<boolean> {
  if (!isAndroidApp) return false;

  const rewardedAdUnitId = import.meta.env.VITE_ADMOB_USE_TEST_ADS === 'false'
    ? config.rewardedId
    : TEST_REWARDED_AD_UNIT_ID;

  await initializeNativeAds(config);
  await AdMob.prepareRewardVideoAd({ adId: rewardedAdUnitId });
  const reward = await AdMob.showRewardVideoAd({ adId: rewardedAdUnitId });
  return Boolean(reward);
}