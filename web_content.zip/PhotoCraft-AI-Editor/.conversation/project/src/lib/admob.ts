import type { AppSettings, AdMobConfig } from './types';

/**
 * AdMob configuration and ad management service.
 *
 * This module centralizes AdMob settings. Native rewarded ads are served by
 * the Google Mobile Ads SDK on Android through src/lib/native.ts. Web-only
 * banner/interstitial placeholders are hidden from Android.
 *
 * TEST AdMob IDs (Google's official test IDs) are used as defaults.
 * Replace them with your real IDs through the Admin Panel — settings are
 * stored in Supabase and fetched remotely at runtime.
 */

export const TEST_ADMOB_CONFIG: AdMobConfig = {
  appId: 'ca-app-pub-3940256099942544~3347511713',
  bannerId: 'ca-app-pub-3940256099942544/6300978111',
  interstitialId: 'ca-app-pub-3940256099942544/1033173712',
  rewardedId: 'ca-app-pub-3940256099942544/5224354917',
};

export function settingsToAdMobConfig(settings: AppSettings): AdMobConfig {
  return {
    appId: settings.admob_app_id || TEST_ADMOB_CONFIG.appId,
    bannerId: settings.banner_ad_unit_id || TEST_ADMOB_CONFIG.bannerId,
    interstitialId: settings.interstitial_ad_unit_id || TEST_ADMOB_CONFIG.interstitialId,
    rewardedId: settings.rewarded_ad_unit_id || TEST_ADMOB_CONFIG.rewardedId,
  };
}

/**
 * Ad frequency controller.
 * Enforces cooldown between interstitial ads and limits frequency.
 */
export class AdFrequencyController {
  private lastInterstitialTime: number = 0;
  private actionCount: number = 0;
  private cooldownSeconds: number;
  private frequency: number;

  constructor(cooldownSeconds: number = 60, frequency: number = 3) {
    this.cooldownSeconds = cooldownSeconds;
    this.frequency = frequency;
  }

  updateSettings(cooldownSeconds: number, frequency: number) {
    this.cooldownSeconds = cooldownSeconds;
    this.frequency = frequency;
  }

  /**
   * Records a qualifying action (e.g., completing an edit session).
   * Returns true if an interstitial ad should be shown now.
   */
  shouldShowInterstitial(): boolean {
    const now = Date.now();
    const elapsed = (now - this.lastInterstitialTime) / 1000;

    // Cooldown check — don't show two ads back-to-back
    if (elapsed < this.cooldownSeconds) return false;

    this.actionCount++;

    // Frequency check — only show every N qualifying actions
    if (this.actionCount < this.frequency) return false;

    this.actionCount = 0;
    this.lastInterstitialTime = now;
    return true;
  }

  /**
   * Force-reset the controller (e.g., when ads are turned off).
   */
  reset() {
    this.lastInterstitialTime = 0;
    this.actionCount = 0;
  }
}
