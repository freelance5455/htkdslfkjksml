export interface AppSettings {
  id: number;
  ads_enabled: boolean;
  maintenance_mode: boolean;
  admob_app_id: string;
  banner_ad_unit_id: string;
  interstitial_ad_unit_id: string;
  rewarded_ad_unit_id: string;
  ad_cooldown_seconds: number;
  ad_frequency: number;
  hd_export_rewarded: boolean;
  ai_enhance_rewarded: boolean;
  updated_at: string;
}

export type EditorScreen =
  | 'splash'
  | 'home'
  | 'editor'
  | 'ai_generate'
  | 'preview'
  | 'success'
  | 'maintenance'
  | 'admin-login'
  | 'admin-dashboard';

export type EditOperation =
  | 'crop'
  | 'resize'
  | 'rotate'
  | 'compress'
  | 'bg_remove'
  | 'ai_enhance'
  | 'ai_generate';

export type GenerateStyle = 'abstract' | 'landscape' | 'portrait' | 'geometric';

export interface PhotoImageData {
  dataUrl: string;
  width: number;
  height: number;
  originalWidth: number;
  originalHeight: number;
  quality: number;
  format: string;
}

export interface HistoryEntry {
  image: PhotoImageData;
  operation: string;
}

export interface AdMobConfig {
  appId: string;
  bannerId: string;
  interstitialId: string;
  rewardedId: string;
}
