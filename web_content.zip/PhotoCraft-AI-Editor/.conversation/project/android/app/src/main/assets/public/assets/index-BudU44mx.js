const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DIx5njdy.js","assets/index-PVpIrrb0.js","assets/index-DGE9Vk28.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-PVpIrrb0.js";const o=r("Share",{web:()=>t(()=>import("./web-DIx5njdy.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
