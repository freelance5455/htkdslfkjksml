(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const toast = (message) => {
    const el = $('toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2800);
  };
  const safeParse = (value, fallback) => { try { return JSON.parse(value) ?? fallback; } catch { return fallback; } };
  const store = {
    get(key, fallback) { return safeParse(localStorage.getItem('akillibox_' + key), fallback); },
    set(key, value) { localStorage.setItem('akillibox_' + key, JSON.stringify(value)); }
  };

  // Navigation
  const titles = {translate:'Terjimeçi',calculator:'Kalkulýator',knowledge:'Bilim ammary',privacy:'Gizlinlik',support:'AI Support'};
  document.querySelectorAll('.nav-card').forEach((button, i) => button.addEventListener('click', () => {
    document.querySelectorAll('.nav-card').forEach(b => b.classList.toggle('active', b === button));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === 'tab-' + button.dataset.tab));
    $('sectionTitle').textContent = titles[button.dataset.tab]; $('sectionIndex').textContent = `0${i+1} / 05`;
    window.scrollTo({top: document.querySelector('.workspace').offsetTop - 10, behavior:'smooth'});
  }));
  const updateConnection = () => {
    const online = navigator.onLine;
    $('connectionPill').innerHTML = `<i style="background:${online?'#55e5b0':'#ffc978'};box-shadow:0 0 9px ${online?'#55e5b0':'#ffc978'}"></i><span>${online?'Online':'Offline tertip'}</span>`;
  };
  window.addEventListener('online', updateConnection); window.addEventListener('offline', updateConnection); updateConnection();

  // Translation: compact built-in offline phrase dictionary, not a full neural translator.
  const dictionary = {
    'tk-en': {'salam':'hello','sag bol':'thank you','sagbol':'thank you','hoş geldiň':'welcome','nähili':'how','men seni söýýärin':'I love you','ertir':'tomorrow','şu gün':'today','kitap':'book','suw':'water','mekdep':'school','öý':'home','dost':'friend','maşgala':'family','hoş':'good','hawa':'yes','ýok':'no','salam dünýä':'hello world','meniň adym':'my name is'},
    'en-tk': {'hello':'salam','thank you':'sag bol','welcome':'hoş geldiň','how are you':'ýagdaýlaryň nähili?','tomorrow':'ertir','today':'şu gün','book':'kitap','water':'suw','school':'mekdep','home':'öý','friend':'dost','family':'maşgala','yes':'hawa','no':'ýok','hello world':'salam dünýä','good morning':'ertiriňiz haýyrly bolsun'},
    'tk-ru': {'salam':'привет','sag bol':'спасибо','kitap':'книга','suw':'вода','mekdep':'школа','öý':'дом','dost':'друг','maşgala':'семья','hawa':'да','ýok':'нет','ertir':'завтра'},
    'ru-tk': {'привет':'salam','спасибо':'sag bol','книга':'kitap','вода':'suw','школа':'mekdep','дом':'öý','друг':'dost','семья':'maşgala','да':'hawa','нет':'ýok','завтра':'ertir'},
    'en-de': {'hello':'hallo','thank you':'danke','book':'buch','water':'wasser','school':'schule','home':'haus','friend':'freund','yes':'ja','no':'nein'},
    'de-en': {'hallo':'hello','danke':'thank you','buch':'book','wasser':'water','schule':'school','haus':'home','freund':'friend','ja':'yes','nein':'no'},
    'de-tk': {'hallo':'salam','danke':'sag bol','buch':'kitap','wasser':'suw','schule':'mekdep','haus':'öý'},
    'tk-de': {'salam':'hallo','sag bol':'danke','kitap':'buch','suw':'wasser','mekdep':'schule','öý':'haus'},
    'ru-en': {'привет':'hello','спасибо':'thank you','книга':'book','вода':'water','школа':'school','дом':'home'},
    'en-ru': {'hello':'привет','thank you':'спасибо','book':'книга','water':'вода','school':'школа','home':'дом'}
  };
  const languageNames = {tk:'tk',en:'en',ru:'ru',de:'de'};
  $('sourceText').addEventListener('input', () => $('sourceCount').textContent = `${$('sourceText').value.length} / 2000`);
  $('swapLanguages').addEventListener('click', () => {
    const a=$('sourceLang'), b=$('targetLang'); const v=a.value; a.value=b.value; b.value=v;
    const text=$('sourceText').value; $('sourceText').value=$('translationResult').textContent === 'Terjime şu ýerde görkeziler.' ? text : $('translationResult').textContent;
    $('sourceCount').textContent=`${$('sourceText').value.length} / 2000`;
  });
  $('translationMode').addEventListener('change', () => $('translateHint').textContent = $('translationMode').value === 'offline'
    ? 'Offline tertipde diňe programmanyň içindäki sözlük we sözlemler ulanylýar. Bu doly sözlem terjimeçisi däldir.'
    : 'Online terjime üçin internet gerek. Bu demo MyMemory API hyzmatyny synap görýär; hyzmat elýeterliligine bagly.');
  $('clearText').addEventListener('click', () => { $('sourceText').value=''; $('sourceCount').textContent='0 / 2000'; $('translationResult').textContent='Terjime şu ýerde görkeziler.'; });
  async function translateText() {
    const text=$('sourceText').value.trim(); if(!text){toast('Ilki terjime edilmeli teksti ýaz.');return;}
    const from=$('sourceLang').value, to=$('targetLang').value;
    if(from===to){$('translationResult').textContent=text;return;}
    $('resultStatus').textContent='Işlenýär...';
    if($('translationMode').value==='online') {
      if(!navigator.onLine){toast('Online terjime üçin internet gerek.');$('resultStatus').textContent='Internet ýok';return;}
      try {
        const url=`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text.slice(0,450))}&langpair=${languageNames[from]}|${languageNames[to]}`;
        const response=await fetch(url); if(!response.ok) throw new Error('Service error');
        const data=await response.json(); const result=data?.responseData?.translatedText;
        if(!result) throw new Error('No result');
        $('translationResult').textContent=decodeEntities(result); $('resultStatus').textContent='Online';
      } catch { $('translationResult').textContent='Online hyzmat häzir jogap bermedi. Interneti barla ýa-da offline tertibi synap gör.'; $('resultStatus').textContent='Elýeterli däl'; }
    } else {
      const map=dictionary[`${from}-${to}`]||{}; const normalized=text.toLocaleLowerCase().trim();
      if(map[normalized]) {$('translationResult').textContent=map[normalized];}
      else {
        const words=normalized.split(/(\s+|[.,!?;:])/);
        const translated=words.map(w=>map[w]||w).join('');
        $('translationResult').textContent=translated===normalized
          ? 'Bu sözlemiň offline terjimesi sözlükde ýok. Has köp sözlük goşmak ýa-da online tertibi ulanmak gerek.'
          : translated;
      }
      $('resultStatus').textContent='Offline sözlük';
    }
  }
  function decodeEntities(str){const t=document.createElement('textarea');t.innerHTML=str;return t.value;}
  $('translateButton').addEventListener('click',translateText);
  $('copyResult').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('translationResult').textContent);toast('Netije göçürildi.');}catch{toast('Göçürmek üçin teksti el bilen saýla.');}});
  $('speakResult').addEventListener('click',()=>{if(!('speechSynthesis' in window)){toast('Bu brauzerde sesli okamak goldanylmaýar.');return;}const u=new SpeechSynthesisUtterance($('translationResult').textContent);u.lang={tk:'tk-TM',en:'en-US',ru:'ru-RU',de:'de-DE'}[$('targetLang').value];speechSynthesis.speak(u);});
  $('voiceInput').addEventListener('click',()=>{
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){toast('Ses tanamak bu brauzerde goldanylmaýar. Teksti el bilen ýaz.');return;}
    const rec=new SR();rec.lang={tk:'tk-TM',en:'en-US',ru:'ru-RU',de:'de-DE'}[$('sourceLang').value];rec.interimResults=false;
    rec.onresult=e=>{$('sourceText').value=e.results[0][0].transcript;$('sourceCount').textContent=`${$('sourceText').value.length} / 2000`;};
    rec.onerror=()=>toast('Ses tanamak başa barmady. Brauzer rugsatlaryny barla.');rec.start();toast('Diňleýärin... Rugsat soralsa, mikrofony aç.');
  });
  $('imageInput').addEventListener('change',e=>{if(e.target.files?.length){$('ocrArea').classList.remove('hidden');toast('Surat saýlandy. Bu başlangyç wersiýada OCR tanamak goşulmady.');}});
  $('dismissOcr').addEventListener('click',()=>$('ocrArea').classList.add('hidden'));

  // Calculator: safe parser; no eval() used.
  let expression='', angle='DEG', calcHistory=store.get('calcHistory',[]);
  const displayExpr=()=> $('calcExpression').textContent=expression||'Hasaplamany giriziň';
  const fmt=n=>{if(!Number.isFinite(n))throw new Error('Netije çäkden çykdy');return Number.parseFloat(n.toPrecision(12)).toString();};
  function tokenize(s) {
    s=s.replace(/π/g,'pi').replace(/÷/g,'/').replace(/×/g,'*').replace(/−/g,'-').replace(/\s+/g,'');
    const re=/((?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?|pi|sin|cos|tan|sqrt|log|[()+\-*/%^])/igy;
    const tokens=[];let pos=0,m;
    while(pos<s.length){re.lastIndex=pos;m=re.exec(s);if(!m||m.index!==pos)throw new Error('Nädogry nyşan');tokens.push(m[0]);pos=re.lastIndex;}
    return tokens;
  }
  function evaluate(input){
    const t=tokenize(input);let i=0;
    const peek=()=>t[i];const eat=()=>t[i++];
    function primary(){
      const x=eat();if(x===undefined)throw new Error('Aňlatma doly däl');
      if(x==='+'||x==='-'){const v=primary();return x==='-'?-v:v;}
      if(x==='('){const v=addSub();if(eat()!==')')throw new Error('Ýaý ýapylmady');return v;}
      if(x==='pi')return Math.PI;
      if(['sin','cos','tan','sqrt','log'].includes(x)){
        if(eat()!=='(')throw new Error('Funksiýa üçin ýaý gerek');const v=addSub();if(eat()!==')')throw new Error('Ýaý ýapylmady');
        if(x==='sqrt'){if(v<0)throw new Error('Negatiw sanyň köki hakyky däl');return Math.sqrt(v);}
        if(x==='log'){if(v<=0)throw new Error('Log üçin san noldan uly bolmaly');return Math.log10(v);}
        const a=angle==='DEG'?v*Math.PI/180:v;return Math[x](a);
      }
      if(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(x))return Number(x);
      throw new Error('Nädogry aňlatma');
    }
    function power(){let a=primary();if(peek()==='^'){eat();a=Math.pow(a,power());}return a;}
    function mulDiv(){let a=power();while(['*','/','%'].includes(peek())){const op=eat(),b=power();if(op==='*')a*=b;else if(op==='/'){if(b===0)throw new Error('Nola bölmek bolmaýar');a/=b;}else a%=b;}return a;}
    function addSub(){let a=mulDiv();while(peek()==='+'||peek()==='-'){const op=eat(),b=mulDiv();a=op==='+'?a+b:a-b;}return a;}
    const result=addSub();if(i<t.length)throw new Error('Aňlatmada artykmaç nyşan bar');if(!Number.isFinite(result))throw new Error('Netije hasaplap bolmaýar');return result;
  }
  function updateCalc(){displayExpr();try{$('calcDisplay').textContent=expression?fmt(evaluate(expression)):'0';}catch{$('calcDisplay').textContent=expression?'…':'0';}}
  function renderCalcHistory(){$('calcHistory').innerHTML='';if(!calcHistory.length){$('calcHistory').textContent='Häzirlikçe taryh ýok.';return;}calcHistory.slice(0,5).forEach(item=>{const b=document.createElement('button');b.className='history-chip';b.textContent=`${item.expression} = ${item.result}`;b.addEventListener('click',()=>{expression=item.result;updateCalc();});$('calcHistory').appendChild(b);});}
  document.querySelectorAll('.key').forEach(b=>b.addEventListener('click',()=>{
    const a=b.dataset.action,v=b.dataset.value;
    if(a==='clear')expression='';
    else if(a==='back')expression=expression.slice(0,-1);
    else if(a==='sign')expression=expression?`-(${expression})`:'-';
    else if(a==='equals'){
      try{const result=fmt(evaluate(expression));calcHistory.unshift({expression,result});calcHistory=calcHistory.slice(0,20);store.set('calcHistory',calcHistory);$('calcExpression').textContent=expression+' =';expression=result;renderCalcHistory();}catch(err){toast(err.message||'Hasaplap bolmady.');}
    } else if(v!==undefined)expression+=v;
    updateCalc();
  }));
  $('angleMode').addEventListener('click',()=>{angle=angle==='DEG'?'RAD':'DEG';$('angleMode').textContent=angle;updateCalc();});
  $('calcClearHistory').addEventListener('click',()=>{calcHistory=[];store.set('calcHistory',calcHistory);renderCalcHistory();toast('Hasaplama taryhy arassalandy.');});
  renderCalcHistory();

  // Knowledge notes
  let notes=store.get('notes',[]), editingId=null;
  function renderNotes(){
    const q=$('noteSearch').value.trim().toLowerCase();const list=$('notesList');list.innerHTML='';
    const filtered=notes.filter(n=>(n.title+' '+n.body).toLowerCase().includes(q));
    if(!filtered.length){list.innerHTML='<div class="empty-state"><span>▤</span><b>Bellık tapylmady</b><p>Gözlegi üýtget ýa-da täze bellik goş.</p></div>';return;}
    filtered.slice().reverse().forEach(n=>{
      const card=document.createElement('article');card.className='note-card';
      const title=document.createElement('h4');title.textContent=n.title;
      const body=document.createElement('p');body.textContent=n.body;
      const meta=document.createElement('div');meta.className='note-meta';
      const date=document.createElement('span');date.textContent=new Date(n.updated||n.created).toLocaleDateString();
      const actions=document.createElement('span');
      const edit=document.createElement('button');edit.className='delete-note';edit.style.color='#8fdfff';edit.textContent='Üýtget';edit.addEventListener('click',()=>{$('noteTitle').value=n.title;$('noteBody').value=n.body;editingId=n.id;$('saveNote').textContent='Üýtgetmeleri sakla';document.querySelector('.workspace').scrollIntoView({behavior:'smooth'});});
      const del=document.createElement('button');del.className='delete-note';del.textContent='Poz';del.addEventListener('click',()=>{if(confirm('Bu belligi pozmalymy?')){notes=notes.filter(x=>x.id!==n.id);store.set('notes',notes);renderNotes();toast('Bellik pozuldy.');}});
      actions.append(edit,del);meta.append(date,actions);card.append(title,body,meta);list.append(card);
    });
  }
  $('saveNote').addEventListener('click',()=>{
    const title=$('noteTitle').value.trim(),body=$('noteBody').value.trim();if(!title||!body){toast('Belligiň adyny we mazmunyny ýaz.');return;}
    if(editingId){const n=notes.find(n=>n.id===editingId);if(n){n.title=title;n.body=body;n.updated=Date.now();}}
    else notes.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),title,body,created:Date.now()});
    store.set('notes',notes);$('noteTitle').value='';$('noteBody').value='';editingId=null;$('saveNote').textContent='＋ Bellik goş';renderNotes();toast('Bellik şu enjamda saklandy.');
  });
  $('noteSearch').addEventListener('input',renderNotes);
  $('exportNotes').addEventListener('click',()=>download('akillibox-bellikler.json',JSON.stringify(notes,null,2),'application/json'));
  $('importNotes').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{const parsed=JSON.parse(await f.text());if(!Array.isArray(parsed))throw new Error();notes=notes.concat(parsed.filter(n=>n&&typeof n.title==='string'&&typeof n.body==='string').map(n=>({...n,id:String(n.id||Date.now()+Math.random())})));store.set('notes',notes);renderNotes();toast('Bellikler import edildi.');}catch{toast('JSON faýly dogry däl.');}e.target.value='';});
  function download(name,content,type){const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);}
  renderNotes();

  // PIN lock. The PIN is a UI lock only in this demo, not cryptographic file protection.
  let pin=store.get('pin',null),locked=false;
  function updatePinState(){$('pinState').textContent=pin?'PIN sazlanan':'Sazlanmadyk';}
  $('setPin').addEventListener('click',()=>{const p=$('newPin').value.trim();if(!/^\d{4,12}$/.test(p)){toast('PIN 4–12 sany san bolmaly.');return;}pin=p;store.set('pin',pin);$('newPin').value='';updatePinState();toast('PIN sazlandy. Ýatda sakla!');});
  function showLock(){if(!pin){toast('Ilki Gizlinlik bölüminde PIN sazla.');return;}locked=true;$('lockOverlay').classList.remove('hidden');$('unlockPin').value='';}
  $('lockButton').addEventListener('click',showLock);
  $('unlockButton').addEventListener('click',()=>{if($('unlockPin').value===pin){locked=false;$('lockOverlay').classList.add('hidden');toast('Gulp açyldy.');}else toast('PIN nädogry.');});
  $('unlockPin').addEventListener('keydown',e=>{if(e.key==='Enter')$('unlockButton').click();});
  updatePinState();
  $('clearAllData').addEventListener('click',()=>{if(confirm('Ähli AkyllıBox ýerli maglumatlaryny, bellikleri we PIN sazlamasyny pozmalymy? Bu amal yzyna gaýtarylmaýar.')){Object.keys(localStorage).filter(k=>k.startsWith('akillibox_')).forEach(k=>localStorage.removeItem(k));notes=[];pin=null;calcHistory=[];renderNotes();renderCalcHistory();updatePinState();toast('AkyllıBox maglumatlary pozuldy.');}});

  // Built-in support guide, deliberately transparent: not a generative AI connection.
  const supportAnswers={
    offline:'Offline mümkinçilikler:\n• Kalkulýator internet talap etmeýär.\n• Bellikler şu brauzeriň ýerli ammarynda saklanýar.\n• Terjimeçi diňe içine girizilen sözlükde bar sözleri terjime edýär.\n• Online terjime, surat OCR we käbir ses funksiýalary internete ýa-da brauzer goldawyna bagly.',
    translation:'Terjimeçi:\n1. Çeşme dilini we terjime dilini saýla.\n2. Teksti ýaz.\n3. Offline tertipde sözlükdäki sözler ulanylýar; ähli sözlemleri terjime etmeýär.\n4. Online tertipde internet bar bolsa terjime hyzmatyny synap gör.\n5. Ses tanamak we sesli okamak brauzere, dil goldawyna we rugsatlara bagly. Surat OCR bu demo wersiýada entek durmuşa geçirilmedi.',
    calculator:'Kalkulýator:\n• Sanlary we amallary düwmeler arkaly giriz.\n• sin, cos, tan, sqrt we log funksiýalary bar.\n• DEG/RAD düwmesi burç birligini üýtgedýär.\n• ^ derejä göterýär, π pi sanyny aňladýar.\n• = netijäni hasaplaýar. Nola bölmek we nädogry aňlatmalar barada duýduryş berilýär.',
    privacy:'Gizlinlik:\n• Gizlinlik bölüminde 4–12 sanly PIN sazlap bolýar.\n• Ýokardaky gulp düwmesi programma interfeýsini gulplaýar.\n• Üns beriň: bu demo PIN-i doly şifrleme hökmünde ulanmaýar. Bellikler ýerli brauzer ammarynda şifrlenmän saklanýar. Hakyky duýgur maglumatlar üçin şifrleme we Android Keystore bilen native programma gerek.',
    notes:'Bilim ammary:\n1. Belligiň adyny we mazmunyny ýaz.\n2. “Bellik goş” düwmesine bas.\n3. Gözleg meýdanyndan bellikleri tap.\n4. “Üýtget” ýa-da “Poz” bilen dolandyr.\n5. Eksport/Import arkaly JSON ätiýaçlyk faýly döredip ýa-da dikeldip bolýar. Maglumatlar diňe şol brauzerde saklanýar.'
  };
  function answerSupport(key){
    const answer=supportAnswers[key]||'Bu demo gollanmasynda degişli maglumat tapylmady. Soragy “terjimeçi”, “kalkulýator”, “gizlinlik”, “bilim ammary” ýa-da “offline” ýaly sözler bilen anyklaşdyr.';
    $('supportAnswer').innerHTML='';const icon=document.createElement('div');icon.className='answer-icon';icon.textContent='✧';const box=document.createElement('div');const b=document.createElement('b');b.textContent=({offline:'Offline mümkinçilikler',translation:'Terjimeçi',calculator:'Kalkulýator',privacy:'Gizlinlik',notes:'Bilim ammary'})[key]||'Gollanma jogaby';const p=document.createElement('p');p.textContent=answer;box.append(b,p);$('supportAnswer').append(icon,box);
  }
  function askSupport(){
    const q=$('supportQuestion').value.toLowerCase();
    const key=q.includes('off')||q.includes('internet')?'offline':q.includes('terj')||q.includes('surat')||q.includes('ses')?'translation':q.includes('kalk')||q.includes('hasap')?'calculator':q.includes('pin')||q.includes('gizlin')||q.includes('gulp')?'privacy':q.includes('bellik')||q.includes('bilim')||q.includes('faýl')?'notes':'';
    if(!key){toast('Soragy has anyk ýaz ýa-da taýýar temany saýla.');return;}answerSupport(key);
  }
  $('askSupport').addEventListener('click',askSupport);
  $('supportQuestion').addEventListener('keydown',e=>{if(e.key==='Enter')askSupport();});
  document.querySelectorAll('[data-question]').forEach(b=>b.addEventListener('click',()=>answerSupport(b.dataset.question)));
})();