# AkyllıBox — HTML, CSS, JavaScript başlangyç taslamasy

Bu ZIP faýlynda brauzerde işleýän, telefona uýgunlaşýan demo programma bar.

## Faýllar
- `index.html` — sahypanyň gurluşy
- `style.css` — animasiýaly arka plan we dizaýn
- `app.js` — programmanyň logikasy
- `README.md` — gollanma

## Işletmek
1. ZIP-i çykaryň.
2. `index.html` faýlyny häzirki zaman brauzerde açyň.
3. Internet bolmasa hem kalkulýator, bellikler, UI we gollanma işleýär.
4. Online terjime üçin internet gerek.

Telefonda kodlary redaktirlemek üçin HTML/CSS/JS goldaýan editor ulanyp bilersiňiz. Ýerli faýllardan `index.html` açmak brauzere görä çäklendirilip biler; şeýle ýagdaýda editoruň preview/live-server funksiýasyny ulanyň.

## Möhüm çäklendirmeler — dogruçyl bellik
Bu ilkinji demo; hiç bir programma üçin “hiç hili problema bolmaz” diýip kepil geçmek mümkin däl. Dürli Android brauzerlerinde aýratynlyklary synagdan geçiriň.

- **Offline terjime:** diňe kiçi içerki sözlük. Bu doly terjime modeli däl.
- **Online terjime:** MyMemory köpçülige açyk API-sini synap görýär; hyzmatyň elýeterliligine, çäklendirmelerine we internetiňize bagly.
- **Ses:** mikrofon arkaly tanamak diňe brauzer goldasa we rugsat berilse işleýär. Käbir brauzerlerde ses tanamak üçin internet gerek bolup biler.
- **Surat terjimesi/OCR:** interfeýs taýýar, ýöne suratdan teksti awtomatik tanamak bu demo wersiýada entek goşulmady.
- **Gizlinlik:** PIN diňe programma interfeýsini gulplaýar. Bellikler `localStorage`-da şifrlenmän saklanýar. Hakyky gizlin maglumatlar üçin Web Crypto AES-GCM/Android Keystore, ygtybarly açar dolandyryşy we howpsuz ätiýaçlyk nusgasy durmuşa geçirilmelidir.
- **AI Support:** bu wersiýada öňünden taýýarlanan gollanma/akylly gözleg bar; generatiw AI modeli ýa-da uzakdaky AI API-si bilen baglanyşyk ýok.
- **Maglumatlaryň saklanyşy:** bellikler şol bir brauzeriň ýerli ammarynda saklanýar. Brauzer maglumatlaryny pozmak bellikleri hem pozup biler. Eksport düwmesini ätiýaçlyk üçin ulanyň.

## Indiki ösüş üçin
1. OCR üçin Tesseract.js ýa-da başga OCR çözgüdini goşmak.
2. Has giň offline terjime modeli we degişli dil paketleri.
3. Web Crypto AES-GCM arkaly şifrlenen maglumat ammary.
4. APK hökmünde paýlamak isleseňiz, bu web-taslamany Capacitor/Cordova ýaly wrapper bilen Android taslamasyna öwürmek we enjamda synag etmek.
5. Android native aýratynlyklary üçin rugsatlary we howpsuzlygy barlamak.
