import * as THREE from 'three';
export function makeActor(scene,color,isBot=false){const root=new THREE.Group();scene.add(root);const material=new THREE.MeshStandardMaterial({color,roughness:.65});
const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.85,3,7),material);torso.position.y=1.35;torso.castShadow=true;root.add(torso);const head=new THREE.Mesh(new THREE.SphereGeometry(.31,8,6),new THREE.MeshStandardMaterial({color:'#e3c7a4'}));head.position.y=2.18;root.add(head);
const visor=new THREE.Mesh(new THREE.BoxGeometry(.42,.12,.12),new THREE.MeshBasicMaterial({color:isBot?'#ff634f':'#4cf5ff'}));visor.position.set(0,2.2,.25);root.add(visor);
for(const x of [-.28,.28]){const leg=new THREE.Mesh(new THREE.BoxGeometry(.22,.72,.28),material);leg.position.set(x,.42,0);root.add(leg)}
const orb=new THREE.Mesh(new THREE.SphereGeometry(.14,8,6),new THREE.MeshBasicMaterial({color:isBot?'#ff6c50':'#4cf5ff'}));orb.position.set(0,1.35,.58);root.add(orb);return root;}
