import * as THREE from 'three';
export function makeArena(scene){const obstacles=[];const mat=(c)=>new THREE.MeshStandardMaterial({color:c,roughness:.88});
const floor=new THREE.Mesh(new THREE.PlaneGeometry(70,70),mat('#526b68'));floor.rotation.x=-Math.PI/2;floor.position.y=-.08;floor.receiveShadow=true;scene.add(floor);
const grid=new THREE.GridHelper(70,35,'#72918b','#647d78');grid.position.y=-.06;scene.add(grid);
function box(x,y,z,w,h,d,color,collide=true){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(color));m.position.set(x,y+h/2,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);if(collide)obstacles.push({x,z,hw:w/2,hd:d/2});return m}
// Boundary walls and original training-yard cover.
box(0,0,-34,68,2,1,'#304d5a');box(0,0,34,68,2,1,'#304d5a');box(-34,0,0,1,2,68,'#304d5a');box(34,0,0,1,2,68,'#304d5a');
box(-12,0,-10,8,2.4,5,'#8b735a');box(12,0,-10,8,2.4,5,'#8b735a');box(0,0,8,12,1.3,2,'#d2a65e');box(-18,0,10,3,1.5,7,'#647e8d');box(18,0,10,3,1.5,7,'#647e8d');box(-7,0,23,10,2,3,'#8b735a');box(9,0,-23,11,2,3,'#8b735a');
// Low-poly trees.
for(const [x,z] of [[-27,-20],[-25,20],[26,-22],[27,20],[-28,2],[28,2]]){const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.35,.48,2,6),mat('#76513a'));trunk.position.set(x,1,z);scene.add(trunk);const crown=new THREE.Mesh(new THREE.ConeGeometry(1.8,4,7),mat('#2e7c58'));crown.position.set(x,3.6,z);crown.castShadow=true;scene.add(crown);obstacles.push({x,z,hw:1.1,hd:1.1})}
// Training markings.
for(let i=-2;i<=2;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(1.2,0.07,5,24),mat('#39c9d4'));ring.rotation.x=Math.PI/2;ring.position.set(i*3,.02,0);scene.add(ring)}
return {obstacles};}
