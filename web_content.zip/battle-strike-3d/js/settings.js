const defaults={sensitivity:1,quality:'low',bestScore:0};
export function loadSettings(){try{return {...defaults,...JSON.parse(localStorage.getItem('bs3d-settings')||'{}')}}catch{return {...defaults}}}
export function saveSettings(s){try{localStorage.setItem('bs3d-settings',JSON.stringify(s));return true}catch{return false}}
