# Battle Strike 3D — prototype Level 01

Prototype third-person arena tag shooter for Android browsers, built with JavaScript modules and Three.js. The core loop is fictional energy tagging; no realistic weapons.

## Important dependency note
`index.html` imports Three.js 0.170.0 from jsDelivr using an import map. This environment could not download/vendor the library because external DNS/network access was unavailable. **Therefore this folder is not yet fully offline/self-contained** and requires internet to load Three.js on first run. To make it fully offline, download `three.module.js` from the official Three.js distribution into `vendor/three.module.js` and change the import map mapping for `three` to `./vendor/three.module.js`. No APK is included or claimed.

## Run
Because JavaScript modules generally do not work from `file://`, serve this folder from a local HTTP server (or import it into a web IDE that serves project files), then open `index.html` in Chrome. On Android, rotate to landscape. Touch controls: left joystick moves, drag right side rotates camera, TAG fires an energy orb, DASH gives a short burst. Pause/settings/restart are implemented.

## Modules
- `js/main.js`: game loop, controls, bot, projectiles, round state, UI
- `js/arena.js`: arena, cover, trees, collision bounds
- `js/actors.js`: procedural low-poly characters
- `js/settings.js`: local settings/progress storage with fallback
- `style.css`: mobile HUD and menus

## Test status / known limitations
- Source was reviewed for module/file consistency, but a real browser/device runtime test could not be run in this environment.
- Bot movement/chasing and basic obstacle avoidance, energy tagging, score, timer, win/loss, pause and restart are implemented but not device-verified.
- APK export is not performed. Package with a tool such as Capacitor only after the dependency is vendored and browser/device tests pass.
