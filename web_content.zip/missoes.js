/* J.A.R.V.I.S BR — missões que sobrevivem ao fechar o app: lembretes, despertador, repetições e pomodoro.
   Ficam no aparelho (j_missoes) e disparam em qualquer tela do app que estiver aberta. */
"use strict";
const Missoes = (() => {
  const CH = "j_missoes";
  const listar = () => { try { return JSON.parse(localStorage.getItem(CH) || "[]") || []; } catch (e) { return []; } };
  const salvar = l => { try { localStorage.setItem(CH, JSON.stringify(l.slice(-200))); } catch (e) {} };
  let aoDisparar = null;
  const MIN = 60000;
  function criar(m) {
    const l = listar(), id = (l.reduce((a, x) => Math.max(a, x.id), 0) || 0) + 1;
    const nova = { id, tipo: m.tipo || "lembrete", titulo: String(m.titulo || "Lembrete").slice(0, 200), alvo: +m.alvo || Date.now() + MIN,
      intervalo: +m.intervalo || 0, repeticoes: +m.repeticoes || 0, feitas: 0, estado: "ativa", criada: Date.now(),
      fase: m.tipo === "pomodoro" ? "foco" : "", ciclos: +m.ciclos || 4, foco: +m.foco || 25, pausa: +m.pausa || 5, diario: !!m.diario };
    l.push(nova); salvar(l); return nova;
  }
  function comando(acao, id) {
    const l = listar(), m = l.find(x => x.id === +id); if (!m) return { erro: "missão não encontrada" };
    if (acao === "pausar" && m.estado === "ativa") { m.resta = Math.max(0, m.alvo - Date.now()); m.estado = "pausada"; }
    else if (acao === "continuar" && m.estado === "pausada") { m.alvo = Date.now() + (m.resta || 0); m.estado = "ativa"; delete m.resta; }
    else if (acao === "cancelar") m.estado = "cancelada";
    else if (acao === "apagar") l.splice(l.indexOf(m), 1);
    salvar(l); return { ok: true, missao: m };
  }
  function progresso(m) {
    if (m.tipo === "pomodoro") return Math.min(100, Math.round(100 * m.feitas / (m.ciclos * 2)));
    if (m.repeticoes) return Math.min(100, Math.round(100 * m.feitas / m.repeticoes));
    if (m.estado === "concluida") return 100;
    const total = m.alvo - m.criada; return total > 0 ? Math.min(99, Math.round(100 * (Date.now() - m.criada) / total)) : 0;
  }
  function descrever(m) {
    const quando = new Date(m.estado === "pausada" ? Date.now() + (m.resta || 0) : m.alvo);
    const hora = quando.toLocaleString("pt-BR", { weekday: "short", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    const tipo = { lembrete: "Lembrete", despertador: "Despertador", repetir: "Repetição", pomodoro: "Pomodoro", contagem: "Contagem" }[m.tipo] || m.tipo;
    let extra = "";
    if (m.tipo === "pomodoro") extra = ` · ${m.fase === "foco" ? "foco" : "pausa"} · ciclo ${Math.min(m.ciclos, Math.floor(m.feitas / 2) + 1)}/${m.ciclos}`;
    else if (m.repeticoes) extra = ` · ${m.feitas}/${m.repeticoes}`;
    else if (m.intervalo) extra = ` · a cada ${Math.round(m.intervalo / MIN)} min`;
    return `${tipo}: ${m.titulo} — ${m.estado === "concluida" ? "concluída" : m.estado === "cancelada" ? "cancelada" : "próximo " + hora}${extra}`;
  }
  function tique() {
    const l = listar(), agora = Date.now(); let mudou = false; const disparos = [];
    for (const m of l) {
      if (m.estado !== "ativa" || m.alvo > agora) continue;
      mudou = true;
      if (m.tipo === "pomodoro") {
        m.feitas++;
        if (m.feitas >= m.ciclos * 2) { m.estado = "concluida"; disparos.push([m, `Pomodoro "${m.titulo}" concluído: ${m.ciclos} ciclos. Belo trabalho.`]); }
        else if (m.fase === "foco") { m.fase = "pausa"; m.alvo = agora + m.pausa * MIN; disparos.push([m, `Hora da pausa: ${m.pausa} minutos. Levante, beba água.`]); }
        else { m.fase = "foco"; m.alvo = agora + m.foco * MIN; disparos.push([m, `De volta ao foco: ${m.foco} minutos em "${m.titulo}".`]); }
        continue;
      }
      m.feitas++;
      disparos.push([m, m.tipo === "despertador" ? `Bom dia! ${m.titulo}` : m.titulo]);
      if (m.tipo === "despertador" && m.diario) m.alvo += 24 * 60 * MIN;
      else if (m.intervalo && (!m.repeticoes || m.feitas < m.repeticoes)) m.alvo = agora + m.intervalo;
      else m.estado = "concluida";
    }
    if (mudou) salvar(l);
    for (const [m, texto] of disparos) { try { (aoDisparar || padrao)(m, texto); } catch (e) {} }
  }
  function padrao(m, texto) {
    try { navigator.vibrate && navigator.vibrate([300, 120, 300, 120, 300]); } catch (e) {}
    if (typeof J !== "undefined") { J.bip(880, 0.15, 0.08); setTimeout(() => J.bip(1100, 0.2, 0.08), 220); J.falar("Aviso: " + texto); }
    const d = document.createElement("div");
    d.style.cssText = "position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:99;background:#1a0f00;border:1px solid #ff6b00;color:#ffcc00;padding:12px 16px;border-radius:8px;font:600 14px 'Courier New',monospace;max-width:90vw;box-shadow:0 0 24px rgba(255,107,0,.35)";
    d.textContent = "⏰ " + texto; d.onclick = () => d.remove(); document.body.appendChild(d); setTimeout(() => d.remove(), 15000);
  }
  setInterval(tique, 2000); setTimeout(tique, 600);
  return { listar, criar, comando, progresso, descrever, tique, set aoDisparar(fn) { aoDisparar = fn; } };
})();
