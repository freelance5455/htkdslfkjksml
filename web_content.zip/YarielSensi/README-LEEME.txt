YARIEL SENSI - PROYECTO ANDROID
Incluye el proyecto para compilar la aplicación; todavía no es un APK instalable.
Incluye diseño oscuro/rojo, generador de sensibilidades baja/media/alta, marcas ampliadas, modelo opcional y sugerencia de DPI opcional.
Para compilar: abre esta carpeta en Android Studio en una computadora, sincroniza Gradle y elige Build > Build Bundle(s) / APK(s) > Build APK(s).
AndroidIDE en teléfonos puede ser complicado y puede requerir descargas grandes. Esta app ofrece valores orientativos; no modifica Free Fire.

ACTUALIZACIÓN DE SENSIBILIDAD: incluye cuatro niveles (Baja, Media, Alta y Muy alta) con valores sugeridos en escala de hasta 200. Empieza por Media o Alta y ajusta poco a poco en el campo de entrenamiento; la sensibilidad ideal depende del dispositivo y de tu control.

ACTUALIZACIÓN:
- El selector de marca y el modelo modifican ligeramente el perfil sugerido para producir combinaciones distintas.
- Son ajustes iniciales generados por reglas simples; no son mediciones oficiales ni garantizan mejor puntería.
- La casilla "Incluir sugerencia de DPI (opcional)" controla si aparece o no el valor de DPI. Si no está marcada, no se muestra DPI.
- Prueba los valores gradualmente en el campo de entrenamiento y conserva los que te resulten cómodos. No cambies el DPI del sistema sin saber cómo restaurarlo.

NUEVA FUNCIÓN: cada vez que pulses GENERAR SENSIBILIDAD, la app crea una combinación nueva de valores dentro del nivel elegido. La variación es aleatoria y puede requerir pruebas para encontrar una configuración cómoda.
