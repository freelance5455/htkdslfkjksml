ParkMe APK build
Option A (no installs, easiest): create a free GitHub repo, upload ALL files of this folder
(including the hidden .github folder), open Actions > "Build ParkMe APK" > Run workflow.
When it finishes, download "ParkMe-apk" -> app-debug.apk -> install on your phone.
Option B (PC): install Node 18+, JDK 17, Android Studio, then run ./build-apk.sh
To edit the app: change www/index.html and rebuild.
