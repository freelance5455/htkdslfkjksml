#!/bin/bash
# Run on a PC with Node 18+, JDK 17 and Android Studio/SDK installed
set -e
npm install
[ -d android ] || npx cap add android
sed -i 's#</manifest>#<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/><uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/></manifest>#' android/app/src/main/AndroidManifest.xml
npx cap sync android
cd android && ./gradlew assembleDebug
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
