FORGELIFE PRO — OFFLINE-FIRST PERSONAL LIFE APP

PROJECT STRUCTURE
- index.html: app screens and semantic UI
- assets/styles.css: responsive design and accessibility styles
- assets/app.js: finance, budget, goals, workouts, notes, calendar, offline assistant and local memory
- assets/register-sw.js: safe service-worker registration
- service-worker.js: versioned app-shell cache for offline reopening
- manifest.json and icons/: install metadata and app icons

RUN / INSTALL ON ANDROID
1. Extract this ZIP. Keep the folders together.
2. For a quick test, open index.html in a modern browser. Some browser features are restricted on local files.
3. For PWA installation and reliable offline caching, host the entire folder on an HTTPS static host. A service worker cannot be installed from an ordinary file:// URL.
4. Open the HTTPS address in Chrome, wait for the first load to finish, then use Chrome menu > Install app / Add to Home screen.
5. Launch it once while online so the service worker can cache all app-shell files; then test offline mode.

DATA SAFETY
- Records and memories are stored locally in this browser/device, not automatically synced.
- Use the app's Export backup function before changing browser, clearing site data, or moving devices.
- Import only backups you trust. Do not use this prototype as the sole copy of important financial records.

AI LIMITATIONS
Forge's assistant uses bundled offline reference material and rules. It is not a genuine large language model and does not have live internet access. Current time/date come from the device. Personal plans can only be reported if they exist in the app's saved data.

BUILD STATUS
This is a modular PWA source project, not a signed Android APK. Creating an APK requires a native wrapper/build environment and signing.
