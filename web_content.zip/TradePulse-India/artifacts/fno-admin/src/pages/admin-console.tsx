import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'wouter';
import { Activity, AlertTriangle, ArrowRight, Bot, Check, ChevronDown, CircleDot, Plus, Search, ShieldCheck, Sparkles, ToggleLeft, ToggleRight, X, Zap } from 'lucide-react';

type Outcome = 'Pending' | 'Correct' | 'Incorrect' | 'Expired';
type Segment = 'Equity' | 'Index Futures' | 'Index Options' | 'Stock Futures';
type BiasDirection = 'Bullish' | 'Bearish' | 'Neutral';
type AgentVote = { agent: string; score: number; bias: BiasDirection; note: string };
type Signal = { id: string; symbol: string; instrument: string; segment: Segment; bias: BiasDirection; confidence: number; timeframe: string; generated: string; outcome: Outcome; agents: string[]; rationale: string; contributions?: AgentVote[]; indicators: { momentum: string; trend: string; volatility: string; breadth: string } };
type Agent = { id: string; name: string; role: string; enabled: boolean; count: number; accuracy: number; rating: number; lastTest: string };
type Row = Record<string, string | number | boolean>;
type Section = 'users' | 'registered-users' | 'payments' | 'subscriptions' | 'ai-agents' | 'ai-performance' | 'notifications' | 'security' | 'audit' | 'system' | 'support' | 'strategy-lab' | 'backtesting' | 'risk-management' | 'market-data' | 'compliance';
const stored = <T,>(key: string, fallback: T): T => { try { const v = localStorage.getItem(`tpi-demo-${key}`); return v ? JSON.parse(v) as T : fallback; } catch { return fallback; } };
const save = (key: string, value: unknown) => { try { localStorage.setItem(`tpi-demo-${key}`, JSON.stringify(value)); } catch { /* Storage may be disabled; this session still works. */ } };
const seedSignals: Signal[] = [
  { id: 'SIG-D-0318', symbol: 'NIFTY', instrument: 'NIFTY 50 Index', segment: 'Index Futures', bias: 'Bullish', confidence: 78, timeframe: 'Intraday · 30m', generated: '10:42:18 IST', outcome: 'Pending', agents: ['Trend Lens', 'Momentum Desk', 'Volatility Reader'], rationale: 'Synthetic trend alignment and positive breadth support a cautiously constructive demo bias.', indicators: { momentum: 'Positive · +0.42σ', trend: 'Upward · 3/4 windows', volatility: 'Moderate · 18th pct', breadth: '61% synthetic advance' } },
  { id: 'SIG-D-0317', symbol: 'RELIANCE', instrument: 'Reliance Industries', segment: 'Equity', bias: 'Neutral', confidence: 64, timeframe: 'Swing · 1D', generated: '10:15:06 IST', outcome: 'Correct', agents: ['Trend Lens', 'Event Context'], rationale: 'Mixed synthetic momentum and trend inputs produced a balanced evaluation case.', indicators: { momentum: 'Neutral · +0.08σ', trend: 'Range · 2/4 windows', volatility: 'Low · 22nd pct', breadth: '48% synthetic advance' } },
  { id: 'SIG-D-0316', symbol: 'BANKNIFTY', instrument: 'NIFTY Bank Index', segment: 'Index Options', bias: 'Bearish', confidence: 71, timeframe: 'Intraday · 15m', generated: '09:58:44 IST', outcome: 'Incorrect', agents: ['Momentum Desk', 'Volatility Reader', 'Breadth Monitor'], rationale: 'Synthetic breadth divergence outweighed a mild short-term momentum uptick.', indicators: { momentum: 'Mixed · −0.21σ', trend: 'Downward · 3/4 windows', volatility: 'Elevated · 76th pct', breadth: '39% synthetic advance' } },
  { id: 'SIG-D-0315', symbol: 'TCS', instrument: 'Tata Consultancy Services', segment: 'Equity', bias: 'Bullish', confidence: 67, timeframe: 'Swing · 1D', generated: '09:32:11 IST', outcome: 'Expired', agents: ['Trend Lens', 'Breadth Monitor'], rationale: 'Synthetic trend and breadth alignment generated a low urgency demo candidate.', indicators: { momentum: 'Positive · +0.30σ', trend: 'Upward · 3/4 windows', volatility: 'Low · 24th pct', breadth: '57% synthetic advance' } },
];
const seedAgents: Agent[] = [
  { id: 'agent-trend', name: 'Trend Lens', role: 'Synthetic trend regime analysis', enabled: true, count: 146, accuracy: 72.6, rating: 4, lastTest: '10:42 IST' },
  { id: 'agent-momentum', name: 'Momentum Desk', role: 'Momentum and oscillator interpretation', enabled: true, count: 128, accuracy: 68.8, rating: 4, lastTest: '10:42 IST' },
  { id: 'agent-volatility', name: 'Volatility Reader', role: 'Volatility context and uncertainty', enabled: true, count: 93, accuracy: 64.5, rating: 3, lastTest: '10:41 IST' },
  { id: 'agent-breadth', name: 'Breadth Monitor', role: 'Synthetic market breadth scoring', enabled: true, count: 111, accuracy: 70.3, rating: 4, lastTest: '10:42 IST' },
  { id: 'agent-event', name: 'Event Context', role: 'Sample event and sector context', enabled: false, count: 61, accuracy: 61.9, rating: 3, lastTest: '09:32 IST' },
];
const seedRows: Record<Exclude<Section, 'ai-agents' | 'ai-performance'>, Row[]> = {
  users: [
    { id: 'USR-DEMO-081', name: 'Rohan Shah', mobile: '+91 90000 00081', email: 'rohan.shah@tradepulse.demo', source: 'Manually added', plan: 'Gold', signupDate: 'Admin entry · demo', status: 'Active' },
    { id: 'USR-DEMO-077', name: 'Priya Nair', mobile: '+91 90000 00077', email: 'priya.nair@tradepulse.demo', source: 'Manually added', plan: 'Diamond', signupDate: 'Admin entry · demo', status: 'Active' },
    { id: 'USR-DEMO-062', name: 'Arjun Mehta', mobile: '+91 90000 00062', email: 'arjun.mehta@tradepulse.demo', source: 'Manually added', plan: 'Kohinoor', signupDate: 'Admin entry · demo', status: 'Review' },
  ],
  'registered-users': [
    { id: 'USR-SIGNUP-101', name: 'Ananya Rao', mobile: '+91 91111 00101', email: 'ananya@example.demo', signupDate: 'Demo signup · 09:42 IST', plan: 'Gold', subscription: 'Active', status: 'Active' },
    { id: 'USR-SIGNUP-102', name: 'Kabir Sen', mobile: '+91 91111 00102', email: 'kabir@example.demo', signupDate: 'Demo signup · 10:05 IST', plan: 'Diamond', subscription: 'Pending payment', status: 'Active' },
  ],
  payments: [
    { ref: 'PAY-DEMO-92841', user: 'Ananya Rao', plan: 'Gold', amount: 'Not configured', method: 'Demo UPI', transaction: 'DEMO-UTR-92841', date: 'Demo · 10:08 IST', status: 'Pending', review: 'Pending' },
    { ref: 'PAY-DEMO-92837', user: 'Kabir Sen', plan: 'Diamond', amount: 'Not configured', method: 'Demo bank transfer', transaction: 'DEMO-UTR-92837', date: 'Demo · 09:44 IST', status: 'Pending', review: 'Pending' },
    { ref: 'PAY-DEMO-92820', user: 'Arjun Mehta', plan: 'Kohinoor', amount: 'Not configured', method: 'Demo UPI', transaction: 'DEMO-UTR-92820', date: 'Demo · 09:19 IST', status: 'Rejected', review: 'Flagged' },
    { ref: 'PAY-DEMO-92811', user: 'Rohan Shah', plan: 'Elite', amount: 'Not configured', method: 'Demo card', transaction: 'DEMO-UTR-92811', date: 'Demo · 08:55 IST', status: 'Approved', review: 'Clear' },
  ],
  subscriptions: [
    { user: 'Ananya Rao', plan: 'Gold', price: 'Not set', period: 'To configure', status: 'Active', renewal: 'Not set' },
    { user: 'Kabir Sen', plan: 'Diamond', price: 'Not set', period: 'To configure', status: 'Pending', renewal: 'Not set' },
    { user: 'Arjun Mehta', plan: 'Kohinoor', price: 'Not set', period: 'To configure', status: 'Paused', renewal: 'Not set' },
    { user: 'Rohan Shah', plan: 'Elite', price: 'Not set', period: 'To configure', status: 'Active', renewal: 'Not set' },
  ],
  'strategy-lab': [
    { strategy: 'Trend + Momentum', segment: 'Index & Stock F&O', status: 'Draft', version: 'Demo v1' },
    { strategy: 'Options OI Confirmation', segment: 'Index Options', status: 'Testing', version: 'Demo v1' },
  ],
  backtesting: [
    { run: 'BT-DEMO-001', strategy: 'Trend + Momentum', period: 'Sample only', status: 'Not run', result: 'No historical data connected' },
  ],
  'risk-management': [
    { rule: 'Maximum daily signals', value: '5', status: 'Enabled' },
    { rule: 'Minimum confidence threshold', value: '70%', status: 'Enabled' },
    { rule: 'Global signal kill switch', value: 'OFF', status: 'Ready' },
  ],
  'market-data': [
    { source: 'Angel One SmartAPI', purpose: 'Market feed', status: 'Not connected', detail: 'Credentials to be added later' },
    { source: 'Historical market data', purpose: 'Backtesting', status: 'Not connected', detail: 'No live or historical feed configured' },
  ],
  compliance: [
    { item: 'Private testing mode', status: 'Enabled', detail: 'No public users or paid advisory launch' },
    { item: 'Risk disclosure records', status: 'Pending', detail: 'To be prepared before public launch' },
  ],
  notifications: [
    { id: 'NTF-DEMO-301', title: 'Signal review queue', detail: 'One synthetic signal is awaiting evaluation.', audience: 'Research admins', time: '10:42 IST', status: 'Unread' },
    { id: 'NTF-DEMO-298', title: 'Sample payment flagged', detail: 'PAY-DEMO-92820 has a local review flag.', audience: 'Billing team', time: '09:46 IST', status: 'Unread' },
    { id: 'NTF-DEMO-284', title: 'Agent test completed', detail: 'Trend Lens generated a local sample result.', audience: 'Platform admins', time: '09:20 IST', status: 'Read' },
  ],
  security: [
    { session: 'SES-DEMO-0A81', user: 'Rohan Shah', device: 'Chrome · macOS', location: 'Mumbai, IN', seen: '10:42 IST', status: 'Active' },
    { session: 'SES-DEMO-0A52', user: 'Priya Nair', device: 'Safari · iOS', location: 'Bengaluru, IN', seen: '10:15 IST', status: 'Active' },
  ],
  audit: [
    { time: '24 Jun · 10:42:18 IST', actor: 'Rohan Shah', event: 'Generated simulated signal', target: 'SIG-D-0318 · NIFTY', result: 'Recorded locally' },
    { time: '24 Jun · 10:15:03 IST', actor: 'Priya Nair', event: 'Reviewed sample payment', target: 'PAY-DEMO-92837', result: 'Recorded locally' },
    { time: '24 Jun · 09:38:51 IST', actor: 'Rohan Shah', event: 'Paused analysis agent', target: 'Event Context', result: 'Recorded locally' },
  ],
  system: [
    { component: 'Signal generator', status: 'Local simulation', detail: 'Synthetic inputs only', latency: '—' },
    { component: 'Agent ensemble', status: 'Demo ready', detail: '5 sample agents', latency: 'Local' },
    { component: 'Market data feed', status: 'Not connected', detail: 'No market data available', latency: '—' },
    { component: 'Payment provider', status: 'Not connected', detail: 'Sample records only', latency: '—' },
  ],
  support: [
    { ticket: 'SUP-DEMO-1842', subject: 'Review outcome clarification', customer: 'Meridian Learning', priority: 'Normal', assignee: 'Priya Nair', status: 'Open', updated: '10:02 IST' },
    { ticket: 'SUP-DEMO-1838', subject: 'Sample plan assignment', customer: 'Saffron Works', priority: 'Normal', assignee: 'Unassigned', status: 'New', updated: '09:38 IST' },
    { ticket: 'SUP-DEMO-1829', subject: 'Agent evaluation workflow', customer: 'Blue Cedar Studio', priority: 'Low', assignee: 'Dev Malhotra', status: 'Waiting', updated: 'Yesterday' },
  ],
};

const sectionMeta: Record<Section, { title: string; eyebrow: string; description: string; columns: [string, string][] }> = {
  users: { title: 'Manually added users', eyebrow: 'Master admin user management', description: 'Manage users created directly by the Master Admin. Self-signups are listed separately.', columns: [['id', 'User ID'], ['name', 'Name'], ['mobile', 'Mobile'], ['email', 'Email'], ['source', 'Source'], ['plan', 'Plan'], ['status', 'Access']] },
  'registered-users': { title: 'Self-signup users', eyebrow: 'User registrations', description: 'A separate directory of users who registered themselves through the app. Demo records only.', columns: [['id', 'User ID'], ['name', 'Name'], ['mobile', 'Mobile'], ['email', 'Email'], ['signupDate', 'Signup date'], ['plan', 'Selected plan'], ['subscription', 'Subscription'], ['status', 'Account']] },
  payments: { title: 'Deposits & payments', eyebrow: 'Payment verification · demo mode', description: 'Review each payment against the subscription plan selected by the user. No bank details or real payment provider configured.', columns: [['ref', 'Payment ID'], ['user', 'User'], ['plan', 'Purchased plan'], ['amount', 'Amount'], ['method', 'Method'], ['transaction', 'Transaction / UTR'], ['date', 'Date'], ['status', 'Payment status']] },
  subscriptions: { title: 'Subscription management', eyebrow: 'Master admin subscription controls', description: 'Control global access, four subscription tiers and individual user subscriptions. Prices and bank details remain unconfigured.', columns: [['user', 'User'], ['plan', 'Plan'], ['price', 'Price'], ['period', 'Billing'], ['renewal', 'Expiry / renewal'], ['status', 'Subscription']] },
  'ai-agents': { title: 'AI signal agents', eyebrow: 'Synthetic ensemble controls', description: 'Enable or pause demo agents and configure their local test contribution.', columns: [] },
  'ai-performance': { title: 'AI performance & ratings', eyebrow: 'Evaluation workspace', description: 'Inspect sample outcomes and adjust local AI agent ratings for testing.', columns: [] },
  'strategy-lab': { title: 'Strategy Lab', eyebrow: 'Strategy configuration', description: 'Draft and organize strategies for private testing. No live execution.', columns: [['strategy', 'Strategy'], ['segment', 'Market segment'], ['version', 'Version'], ['status', 'Status']] },
  backtesting: { title: 'Backtesting & paper trading', eyebrow: 'Historical evaluation', description: 'Prepare strategy test runs and simulated paper-trading workflows. No broker orders.', columns: [['run', 'Run ID'], ['strategy', 'Strategy'], ['period', 'Period'], ['status', 'Status'], ['result', 'Result']] },
  'risk-management': { title: 'Risk management', eyebrow: 'Signal safety controls', description: 'Configure signal-level risk guardrails and emergency controls for testing.', columns: [['rule', 'Control'], ['value', 'Value'], ['status', 'Status']] },
  'market-data': { title: 'Market data & API', eyebrow: 'Data connections', description: 'View planned data sources and connection readiness. No credentials are stored yet.', columns: [['source', 'Source'], ['purpose', 'Purpose'], ['status', 'Connection'], ['detail', 'Details']] },
  compliance: { title: 'Compliance & documentation', eyebrow: 'Private test workspace', description: 'Track documentation placeholders for a future public launch. This is not a compliance approval.', columns: [['item', 'Item'], ['status', 'Status'], ['detail', 'Details']] },
  notifications: { title: 'Notifications', eyebrow: 'Local communications', description: 'Sample events from the private testing console. No messages are sent.', columns: [['title', 'Notification'], ['detail', 'Details'], ['audience', 'Audience'], ['time', 'Time · IST'], ['status', 'Read state']] },
  security: { title: 'Security', eyebrow: 'Demo sessions & policy', description: 'Review fictional sessions and local-only policy controls.', columns: [['session', 'Session ID'], ['user', 'User'], ['device', 'Device'], ['location', 'Location'], ['seen', 'Last active'], ['status', 'Session']] },
  audit: { title: 'Audit log', eyebrow: 'Local accountability', description: 'A browser-local history of sample administrator actions.', columns: [['time', 'Timestamp · IST'], ['actor', 'Actor'], ['event', 'Activity'], ['target', 'Target'], ['result', 'Result']] },
  system: { title: 'System status', eyebrow: 'Demo environment', description: 'Illustrative component status only; no production service is monitored.', columns: [['component', 'Component'], ['status', 'Demo status'], ['detail', 'Configuration'], ['latency', 'Runtime']] },
  support: { title: 'Support desk', eyebrow: 'Sample ticket triage', description: 'Update fictional ticket ownership and statuses in this browser only.', columns: [['ticket', 'Ticket'], ['subject', 'Subject'], ['customer', 'Account'], ['priority', 'Priority'], ['assignee', 'Assignee'], ['updated', 'Updated'], ['status', 'State']] },
};
const input = 'h-10 rounded-lg border border-[#303c43] bg-[#10181e] px-3 text-[10px] text-[#dce3df] outline-none focus:border-[#87965c]';
const button = 'inline-flex h-9 items-center justify-center gap-2 rounded-lg border border-[#39463b] bg-[#28332a] px-3 text-[10px] font-semibold text-[#dbe69a] transition hover:bg-[#34412f] disabled:opacity-40';

function Badge({ children }: { children: string }) {
  const tone = /correct|active|enabled|clear|read|recorded|demo ready|local simulation/i.test(children) ? 'border-[#354a3c] bg-[#23332b] text-[#a8c77d]' : /pending|review|watch|waiting|trial|new|unread/i.test(children) ? 'border-[#55462e] bg-[#342f23] text-[#dfbd78]' : /incorrect|suspend|failed|paused|flagged|not connected|revoked/i.test(children) ? 'border-[#563731] bg-[#392825] text-[#e18c7a]' : 'border-[#3b464b] bg-[#252e33] text-[#aab6b8]';
  return <span className={`inline-flex whitespace-nowrap rounded border px-1.5 py-1 text-[8px] font-medium ${tone}`}>{children}</span>;
}
function Heading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="mb-2 flex items-center gap-2 text-[9px] font-semibold uppercase tracking-[.19em] text-[#9aab83]"><span className="h-px w-5 bg-[#a6b77c]" />{eyebrow}</div><h1 className="font-display text-[27px] font-semibold tracking-[-.035em] text-[#edf0e9] sm:text-[32px]">{title}</h1><p className="mt-1.5 max-w-2xl text-[11px] text-[#819098]">{description}</p></div>{action}</div>;
}
function DemoBanner({ children = 'SIMULATED / DEMO — generated locally from synthetic sample inputs. Not live market data or a recommendation.' }: { children?: string }) {
  return <div className="mb-5 flex items-start gap-2.5 rounded-lg border border-[#4d4932] bg-[#28271e] p-3 text-[9px] leading-relaxed text-[#c8bd8b]"><AlertTriangle size={14} className="mt-0.5 shrink-0 text-[#d6bb73]" />{children}</div>;
}
function Metric({ label, value, note, accent }: { label: string; value: string; note: string; accent?: string }) {
  return <div className="rounded-xl border border-[#28343c] bg-[#151e24] p-4 sm:p-5"><p className="text-[9px] font-semibold uppercase tracking-[.13em] text-[#85939a]">{label}</p><strong className={`mt-2 block font-display text-[23px] font-semibold tracking-tight ${accent || 'text-[#eef0e8]'}`}>{value}</strong><p className="mt-1 text-[9px] text-[#718087]">{note}</p></div>;
}
function getSignals() { return stored<Signal[]>('signals', seedSignals); }
function setSignals(data: Signal[]) { save('signals', data); window.dispatchEvent(new Event('tpi-data')); }
function scoreBias(score: number): BiasDirection {
  return score > 0.12 ? 'Bullish' : score < -0.12 ? 'Bearish' : 'Neutral';
}
function createSyntheticEnsemble(agents: Agent[]) {
  const inputs = {
    trend: Math.random() * 2 - 1,
    momentum: Math.random() * 2 - 1,
    volatility: Math.random(),
    breadth: Math.random() * 2 - 1,
    event: Math.random() * 2 - 1,
  };
  const scorers: Record<string, (sample: typeof inputs) => number> = {
    'agent-trend': (sample) => sample.trend * 0.7 + sample.momentum * 0.2 + sample.breadth * 0.1,
    'agent-momentum': (sample) => sample.momentum * 0.75 + sample.trend * 0.25,
    'agent-volatility': (sample) => (sample.trend * 0.4 + sample.momentum * 0.35 + sample.breadth * 0.25) * (1 - sample.volatility * 0.35),
    'agent-breadth': (sample) => sample.breadth * 0.7 + sample.trend * 0.3,
    'agent-event': (sample) => sample.event * 0.6 + sample.trend * 0.25 + sample.breadth * 0.15,
  };
  const contributions: AgentVote[] = agents.map((agent) => {
    const score = Math.max(-1, Math.min(1, scorers[agent.id]?.(inputs) ?? inputs.trend));
    const bias = scoreBias(score);
    return {
      agent: agent.name,
      score: Math.round(score * 100),
      bias,
      note: bias === 'Neutral' ? 'Mixed synthetic inputs' : `${bias} synthetic alignment`,
    };
  });
  const weights = agents.map((agent) => 0.5 + agent.rating / 5);
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
  const ensembleScore = contributions.reduce((sum, vote, index) => sum + (vote.score / 100) * weights[index], 0) / totalWeight;
  const bias = scoreBias(ensembleScore);
  const supportingVotes = contributions.filter((vote) => vote.bias === bias).length;
  const confidence = Math.max(52, Math.min(89, Math.round(49 + Math.abs(ensembleScore) * 31 + supportingVotes / contributions.length * 12 - inputs.volatility * 5)));
  const momentum = inputs.momentum;
  const trend = inputs.trend;
  const breadthPct = Math.round((inputs.breadth + 1) * 50);
  const volatilityPct = Math.round(inputs.volatility * 100);
  const indicators = {
    momentum: `${momentum > 0.15 ? 'Positive' : momentum < -0.15 ? 'Negative' : 'Neutral'} · ${momentum >= 0 ? '+' : ''}${momentum.toFixed(2)}σ`,
    trend: `${trend > 0.18 ? 'Upward' : trend < -0.18 ? 'Downward' : 'Range'} · synthetic score ${trend >= 0 ? '+' : ''}${trend.toFixed(2)}`,
    volatility: `${volatilityPct > 70 ? 'Elevated' : volatilityPct < 30 ? 'Low' : 'Moderate'} · ${volatilityPct}th pct`,
    breadth: `${breadthPct}% synthetic advance`,
  };
  const direction = bias === 'Neutral' ? 'The ensemble is balanced' : `${supportingVotes} of ${contributions.length} agents support a ${bias.toLowerCase()} evaluation`;
  return {
    bias,
    confidence,
    rationale: `${direction}. The local test ensemble combines synthetic trend, momentum, volatility, breadth and event-context scores; agent ratings act only as demo weights.`,
    indicators,
    contributions,
  };
}

export function Overview() {
  const [signals, setSignalState] = useState(getSignals);
  const [period, setPeriod] = useState('7D');
  useEffect(() => { const refresh = () => setSignalState(getSignals()); window.addEventListener('tpi-data', refresh); return () => window.removeEventListener('tpi-data', refresh); }, []);
  const correct = signals.filter((s) => s.outcome === 'Correct').length;
  const evaluated = signals.filter((s) => s.outcome === 'Correct' || s.outcome === 'Incorrect').length;
  const recent = [...signals].slice(0, 4);
  return <div className="enter">
    <Heading eyebrow="Trade Pulse India · private evaluation" title="Signal operations" description="A contained workspace for evaluating synthetic multi-agent signal research, registered users and subscription operations." action={<span className="inline-flex items-center gap-1.5 rounded-md border border-[#3d4533] bg-[#252b22] px-2.5 py-1.5 text-[8px] font-semibold uppercase tracking-[.12em] text-[#c4d17d]"><CircleDot size={10} /> Private demo</span>} />
    <DemoBanner />
    <div className="mb-6 grid grid-cols-2 gap-3 xl:grid-cols-4"><Metric label="Synthetic signals" value={String(signals.length)} note="Local sample history" /><Metric label="Agents enabled" value={`${stored('agents', seedAgents).filter((a: Agent) => a.enabled).length} / 5`} note="Analysis ensemble" /><Metric label="Evaluated outcomes" value={evaluated ? `${Math.round(correct / evaluated * 100)}%` : '—'} note={`${evaluated} locally reviewed signals`} accent="text-[#c9d980]" /><Metric label="Pending review" value={String(signals.filter((s) => s.outcome === 'Pending').length)} note="Awaiting admin evaluation" /></div>
    <div className="grid gap-5 xl:grid-cols-[1.55fr_1fr]">
      <section className="overflow-hidden rounded-xl border border-[#28343c] bg-[#151e24]">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#29343b] px-4 py-4 sm:px-5"><div><h2 className="text-[12px] font-semibold">Signal evaluation activity</h2><p className="mt-1 text-[9px] text-[#78878e]">Synthetic sample generation · local outcomes</p></div><div className="flex gap-1 rounded-lg bg-[#10181e] p-1">{['7D', '30D'].map((p) => <button key={p} onClick={() => setPeriod(p)} className={`rounded px-2 py-1 text-[8px] ${p === period ? 'bg-[#354036] text-[#dbe897]' : 'text-[#77868d]'}`}>{p}</button>)}</div></div>
        <div className="px-4 pb-3 pt-4 sm:px-5"><div className="mb-1 flex items-center gap-2"><span className="font-data text-[22px] text-[#e9eee7]">{signals.length.toString().padStart(2, '0')}</span><span className="rounded bg-[#28372e] px-1.5 py-1 font-data text-[8px] text-[#abc37b]">local signals</span></div><div className="h-[165px]"><svg viewBox="0 0 760 165" preserveAspectRatio="none" className="h-full w-full" role="img" aria-label="Synthetic signal activity visualization"><defs><linearGradient id="signalFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#b9cf72" stopOpacity=".2" /><stop offset="100%" stopColor="#b9cf72" stopOpacity="0" /></linearGradient></defs>{[24, 65, 106, 147].map((y) => <line key={y} x1="0" x2="760" y1={y} y2={y} stroke="#2a353b" strokeDasharray="3 6" />)}<path d="M0 116 C42 106 50 130 91 99 S143 105 187 82 S239 101 278 72 S335 84 377 61 S425 76 468 53 S520 73 562 45 S615 61 655 35 S718 43 760 20 L760 165 L0 165Z" fill="url(#signalFill)" /><path d="M0 116 C42 106 50 130 91 99 S143 105 187 82 S239 101 278 72 S335 84 377 61 S425 76 468 53 S520 73 562 45 S615 61 655 35 S718 43 760 20" fill="none" stroke="#c3d77b" strokeWidth="2" vectorEffect="non-scaling-stroke" /><circle cx="760" cy="20" r="3.5" fill="#dce992" /></svg></div><div className="mt-2 flex justify-between font-data text-[8px] text-[#64737b]"><span>18 Jun</span><span>20 Jun</span><span>22 Jun</span><span>23 Jun</span><span>Today · IST</span></div></div>
      </section>
      <section className="rounded-xl border border-[#28343c] bg-[#151e24] p-4 sm:p-5"><div className="flex items-center justify-between"><div><h2 className="text-[12px] font-semibold">Ensemble status</h2><p className="mt-1 text-[9px] text-[#78878e]">Sample evaluation agents</p></div><Link href="/ai-agents" className="text-[9px] font-semibold text-[#bfce7a]">Configure <ArrowRight size={12} className="ml-1 inline" /></Link></div><div className="mt-3 divide-y divide-[#29343b]">{stored<Agent[]>('agents', seedAgents).slice(0, 4).map((agent) => <div key={agent.id} className="flex items-center justify-between gap-2 py-2.5"><div className="flex items-center gap-2.5"><span className="grid h-7 w-7 place-items-center rounded-md border border-[#334139] bg-[#1b2823] text-[#c5d779]"><Bot size={14} /></span><div><p className="text-[9px] font-medium text-[#cbd3d0]">{agent.name}</p><p className="mt-0.5 text-[8px] text-[#738189]">{agent.role}</p></div></div><Badge>{agent.enabled ? 'Enabled' : 'Paused'}</Badge></div>)}</div><div className="mt-3 rounded-lg border border-[#303a36] bg-[#1b2522] p-2.5 text-[8px] leading-relaxed text-[#98a795]">Agent outputs are deterministic-style demo data, not generated by a live AI model.</div></section>
    </div>
    <div className="mt-5 grid gap-5 xl:grid-cols-[1.45fr_1fr]">
      <section className="overflow-hidden rounded-xl border border-[#28343c] bg-[#151e24]"><div className="flex items-center justify-between px-4 py-4 sm:px-5"><div><h2 className="text-[12px] font-semibold">Recent simulated signals</h2><p className="mt-1 text-[9px] text-[#78878e]">Latest synthetic instrument evaluations</p></div><Link href="/signal-history" className="text-[9px] font-semibold text-[#bfce7a]">Full history <ArrowRight size={12} className="ml-1 inline" /></Link></div><div className="overflow-x-auto"><table className="w-full min-w-[600px] text-left"><thead><tr className="border-y border-[#29343b] bg-[#121a20] text-[8px] uppercase tracking-[.12em] text-[#718087]">{['Instrument', 'Segment', 'Bias', 'Confidence', 'Review'].map((x) => <th key={x} className="px-4 py-2.5 font-medium">{x}</th>)}</tr></thead><tbody>{recent.map((s) => <tr key={s.id} className="border-b border-[#263139] last:border-0 hover:bg-[#1b252b]"><td className="px-4 py-3"><b className="text-[9px] text-[#cbd3d0]">{s.symbol}</b><span className="ml-2 text-[8px] text-[#738189]">{s.instrument}</span></td><td className="px-4 py-3 text-[8px] text-[#9da9aa]">{s.segment}</td><td className="px-4 py-3"><Bias value={s.bias} /></td><td className="px-4 py-3 font-data text-[9px]">{s.confidence}%</td><td className="px-4 py-3"><Badge>{s.outcome}</Badge></td></tr>)}</tbody></table></div></section>
      <section className="rounded-xl border border-[#28343c] bg-[#151e24] p-4 sm:p-5"><h2 className="text-[12px] font-semibold">Workspace shortcuts</h2><p className="mt-1 text-[9px] text-[#78878e]">Keep evaluation moving</p><div className="mt-4 grid gap-2">{[{ href: '/signals', label: 'Generate a synthetic signal', icon: Zap }, { href: '/signal-history', label: 'Review signal outcomes', icon: Activity }, { href: '/users', label: 'Manage sample access', icon: ShieldCheck }].map(({ href, label, icon: Icon }) => <Link key={href} href={href} className="flex items-center gap-2.5 rounded-lg border border-[#303b42] bg-[#111a20] p-3 text-[9px] font-medium text-[#bdc7c5] transition hover:border-[#566249]"><Icon size={14} className="text-[#c5d779]" />{label}<ArrowRight size={12} className="ml-auto text-[#748187]" /></Link>)}</div><p className="mt-4 text-[8px] leading-relaxed text-[#718087]">All mutations stay in this browser's local demo session. This console cannot place orders or connect to trading infrastructure.</p></section>
    </div>
    <p className="mt-6 text-center text-[8px] text-[#58676e]">SIMULATED / DEMO · no live prices, recommendations, trading, broker, payment or external AI connections</p>
  </div>;
}

function Bias({ value }: { value: string }) {
  const style = value === 'Bullish' ? 'text-[#a8c77d] bg-[#23332b]' : value === 'Bearish' ? 'text-[#e18c7a] bg-[#392825]' : 'text-[#dfbd78] bg-[#342f23]';
  return <span className={`inline-flex rounded px-1.5 py-1 text-[8px] font-medium ${style}`}>{value}</span>;
}

export function SignalGenerator() {
  const [symbol, setSymbol] = useState('NIFTY');
  const [segment, setSegment] = useState<Segment>('Index Futures');
  const [timeframe, setTimeframe] = useState('Intraday · 30m');
  const [generated, setGenerated] = useState<Signal | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const symbols: Record<Segment, { symbol: string; instrument: string }[]> = {
    Equity: [{ symbol: 'RELIANCE', instrument: 'Reliance Industries' }, { symbol: 'TCS', instrument: 'Tata Consultancy Services' }, { symbol: 'INFY', instrument: 'Infosys' }, { symbol: 'HDFCBANK', instrument: 'HDFC Bank' }],
    'Index Futures': [{ symbol: 'NIFTY', instrument: 'NIFTY 50 Index' }, { symbol: 'BANKNIFTY', instrument: 'NIFTY Bank Index' }, { symbol: 'FINNIFTY', instrument: 'NIFTY Financial Services' }],
    'Index Options': [{ symbol: 'NIFTY', instrument: 'NIFTY 50 Index · Options' }, { symbol: 'BANKNIFTY', instrument: 'NIFTY Bank Index · Options' }],
    'Stock Futures': [{ symbol: 'RELIANCE', instrument: 'Reliance Industries · Futures' }, { symbol: 'TCS', instrument: 'Tata Consultancy Services · Futures' }, { symbol: 'INFY', instrument: 'Infosys · Futures' }],
  };
  const chosen = symbols[segment].find((item) => item.symbol === symbol) || symbols[segment][0];
  const generate = () => {
    setBusy(true); setNotice('');
    window.setTimeout(() => {
      const allAgents = stored<Agent[]>('agents', seedAgents);
      const agents = allAgents.filter((agent) => agent.enabled);
      if (!agents.length) { setBusy(false); setNotice('Enable at least one analysis agent before generating a sample.'); return; }
      const result = createSyntheticEnsemble(agents);
      const timestamp = new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date());
      const signal: Signal = { ...result, id: `SIG-D-${Date.now().toString(36).toUpperCase()}`, symbol: chosen.symbol, instrument: chosen.instrument, segment, timeframe, generated: `${timestamp} IST`, outcome: 'Pending', agents: agents.map((agent) => agent.name) };
      const testedAgents = allAgents.map((agent) => agent.enabled ? { ...agent, count: agent.count + 1, lastTest: `${timestamp} IST` } : agent);
      save('agents', testedAgents);
      setSignals([signal, ...getSignals()]); setGenerated(signal); setBusy(false);
    }, 420);
  };
  return <div className="enter"><Heading eyebrow="Synthetic signal lab" title="Generate a signal" description="Run a local multi-agent evaluation against a fictional instrument profile. No market feed is queried." action={<span className="inline-flex items-center gap-1.5 rounded-md border border-[#3d4533] bg-[#252b22] px-2 py-1 text-[8px] font-semibold uppercase tracking-[.12em] text-[#c4d17d]"><Sparkles size={11} /> Local generation</span>} /><DemoBanner />
    <div className="grid gap-5 xl:grid-cols-[.85fr_1.35fr]">
      <section className="rounded-xl border border-[#28343c] bg-[#151e24] p-4 sm:p-5"><div className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-lg bg-[#2b3525] text-[#d8e66a]"><Zap size={15} /></span><div><h2 className="text-[12px] font-semibold">Test configuration</h2><p className="mt-0.5 text-[9px] text-[#78878e]">All inputs are fictional</p></div></div>
        <label className="mt-5 block"><span className="mb-1.5 block text-[9px] font-semibold uppercase tracking-[.12em] text-[#829096]">Instrument segment</span><select className={`${input} w-full`} value={segment} onChange={(e) => { const next = e.target.value as Segment; setSegment(next); setSymbol(symbols[next][0].symbol); }} data-testid="select-segment">{Object.keys(symbols).map((value) => <option key={value}>{value}</option>)}</select></label>
        <label className="mt-4 block"><span className="mb-1.5 block text-[9px] font-semibold uppercase tracking-[.12em] text-[#829096]">Sample instrument</span><select className={`${input} w-full`} value={symbol} onChange={(e) => setSymbol(e.target.value)} data-testid="select-symbol">{symbols[segment].map((item) => <option key={item.symbol} value={item.symbol}>{item.symbol} — {item.instrument}</option>)}</select></label>
        <label className="mt-4 block"><span className="mb-1.5 block text-[9px] font-semibold uppercase tracking-[.12em] text-[#829096]">Evaluation window</span><select className={`${input} w-full`} value={timeframe} onChange={(e) => setTimeframe(e.target.value)} data-testid="select-timeframe">{['Intraday · 15m', 'Intraday · 30m', 'Swing · 1D', 'Position · 1W'].map((item) => <option key={item}>{item}</option>)}</select></label>
        <div className="mt-4 rounded-lg border border-[#29353b] bg-[#11191f] p-3"><div className="flex items-center justify-between"><span className="text-[9px] font-medium text-[#bdc7c5]">Enabled contributors</span><span className="font-data text-[9px] text-[#cbdc83]">{stored<Agent[]>('agents', seedAgents).filter((agent) => agent.enabled).length} agents</span></div><div className="mt-2 flex flex-wrap gap-1.5">{stored<Agent[]>('agents', seedAgents).filter((agent) => agent.enabled).map((agent) => <span key={agent.id} className="rounded border border-[#303d36] bg-[#1c2922] px-2 py-1 text-[8px] text-[#a9b89a]">{agent.name}</span>)}</div><Link href="/ai-agents" className="mt-2 inline-block text-[8px] text-[#c5d779]">Configure agents <ArrowRight size={10} className="ml-1 inline" /></Link></div>
        <button onClick={generate} disabled={busy} className={`${button} mt-5 w-full`} data-testid="button-generate-signal">{busy ? <><span className="h-3 w-3 animate-pulse rounded-full bg-[#d8e66a]" />Building synthetic ensemble…</> : <><Sparkles size={13} />Generate demo signal</>}</button>{notice && <p className="mt-3 text-[9px] text-[#dfbd78]" role="status">{notice}</p>}
        <p className="mt-3 text-[8px] leading-relaxed text-[#718087]">This tool returns a synthetic research scenario for interface testing only. It cannot submit trades or produce live recommendations.</p>
      </section>
      <section className="min-h-[430px] rounded-xl border border-[#28343c] bg-[#151e24] p-4 sm:p-5">
        {!generated ? <div className="flex h-full min-h-[390px] flex-col items-center justify-center text-center"><span className="grid h-14 w-14 place-items-center rounded-2xl border border-[#334139] bg-[#1b2823] text-[#c5d779]"><Activity size={22} /></span><h2 className="mt-4 font-display text-[17px] font-semibold text-[#d9e1dc]">Awaiting a test run</h2><p className="mt-2 max-w-xs text-[9px] leading-relaxed text-[#7e8c91]">Choose a fictional Indian equity or index sample and generate an ensemble signal to inspect its synthetic snapshot.</p><div className="mt-5 flex items-center gap-2 text-[8px] uppercase tracking-[.13em] text-[#748187]"><span className="h-px w-7 bg-[#3a4646]" />Nothing live is queried<span className="h-px w-7 bg-[#3a4646]" /></div></div> : <div className="enter">
          <div className="flex flex-wrap items-start justify-between gap-3"><div><div className="flex items-center gap-2"><Badge>SIMULATED / DEMO</Badge><span className="font-data text-[8px] text-[#718087]">{generated.id}</span></div><h2 className="mt-3 font-display text-[24px] font-semibold text-[#edf0e9]">{generated.symbol}<span className="ml-2 text-[13px] font-normal text-[#819098]">{generated.instrument}</span></h2><p className="mt-1 text-[9px] text-[#809097]">{generated.segment} · {generated.timeframe} · {generated.generated}</p></div><Badge>{generated.outcome}</Badge></div>
          <div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-lg border border-[#29353b] bg-[#11191f] p-4"><p className="text-[8px] uppercase tracking-[.13em] text-[#829096]">Ensemble bias</p><div className="mt-2"><Bias value={generated.bias} /></div><p className="mt-2 text-[8px] text-[#75848a]">Research direction label · not advice</p></div><div className="rounded-lg border border-[#29353b] bg-[#11191f] p-4"><p className="text-[8px] uppercase tracking-[.13em] text-[#829096]">Confidence score</p><div className="mt-2 flex items-baseline gap-1"><strong className="font-display text-[24px] text-[#e4ebdb]">{generated.confidence}</strong><span className="text-[10px] text-[#829096]">%</span></div><div className="mt-2 h-1 overflow-hidden rounded bg-[#29343b]"><div className="h-full rounded bg-[#b8cb73]" style={{ width: `${generated.confidence}%` }} /></div></div></div>
          <div className="mt-4 rounded-lg border border-[#29353b] bg-[#11191f] p-4"><h3 className="text-[9px] font-semibold text-[#d3dad5]">Synthetic indicator snapshot</h3><div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">{Object.entries(generated.indicators).map(([key, value]) => <div key={key}><p className="text-[7px] uppercase tracking-[.1em] text-[#718087]">{key}</p><p className="mt-1 text-[9px] text-[#b7c2be]">{value}</p></div>)}</div></div>
           <div className="mt-4 rounded-lg border border-[#29353b] bg-[#11191f] p-4"><h3 className="text-[9px] font-semibold text-[#d3dad5]">Ensemble rationale</h3><p className="mt-2 text-[9px] leading-relaxed text-[#94a19f]">{generated.rationale}</p><div className="mt-3 grid gap-2 sm:grid-cols-2">{generated.contributions?.map((vote) => <div key={vote.agent} className="flex items-center justify-between gap-2 rounded border border-[#2c383e] px-2.5 py-2"><div><p className="text-[8px] font-medium text-[#cbd3d0]">{vote.agent}</p><p className="mt-0.5 text-[7px] text-[#748187]">{vote.note}</p></div><span className="font-data text-[8px] text-[#a9bf7c]">{vote.score > 0 ? '+' : ''}{vote.score}</span></div>)}</div></div>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2"><span className="text-[8px] text-[#748187]">No entry, target or stop levels are generated.</span><Link href="/signal-history" className="text-[9px] font-semibold text-[#c5d779]">Open signal history <ArrowRight size={11} className="ml-1 inline" /></Link></div>
        </div>}
      </section>
    </div>
  </div>;
}

export function SignalHistory() {
  const [signals, setSignalState] = useState(getSignals);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All outcomes');
  const [segmentFilter, setSegmentFilter] = useState('All segments');
  const [notice, setNotice] = useState('');
  const visible = useMemo(() => signals.filter((s) => `${s.id} ${s.symbol} ${s.instrument} ${s.segment} ${s.bias} ${s.agents.join(' ')}`.toLowerCase().includes(query.toLowerCase()) && (filter === 'All outcomes' || s.outcome === filter) && (segmentFilter === 'All segments' || s.segment === segmentFilter)), [signals, query, filter, segmentFilter]);
  const outcome = (id: string, value: Outcome) => { const next = signals.map((s) => s.id === id ? { ...s, outcome: value } : s); setSignalState(next); setSignals(next); setNotice(`Review saved locally for ${id}.`); };
  const reset = () => { setSignals(seedSignals); setSignalState(seedSignals); setNotice('Sample signal history restored.'); };
  return <div className="enter"><Heading eyebrow="Synthetic activity ledger" title="Signal history" description="Search generated demo scenarios and evaluate outcomes locally. No live price performance is recorded." action={<Link href="/signals" className={button}><Zap size={13} />Generate signal</Link>} /><DemoBanner />
    <div className="mb-5 grid grid-cols-2 gap-3 xl:grid-cols-4"><Metric label="Total scenarios" value={String(signals.length)} note="Browser-local sample records" /><Metric label="Pending review" value={String(signals.filter((s) => s.outcome === 'Pending').length)} note="Awaiting manual evaluation" /><Metric label="Correct" value={String(signals.filter((s) => s.outcome === 'Correct').length)} note="Locally selected outcome" accent="text-[#a8c77d]" /><Metric label="Incorrect / expired" value={String(signals.filter((s) => s.outcome === 'Incorrect' || s.outcome === 'Expired').length)} note="Locally selected outcome" /></div>
    {notice && <div className="mb-3 flex items-center justify-between rounded-lg border border-[#354a3c] bg-[#23332b] p-2.5 text-[9px] text-[#b8cf8e]" role="status">{notice}<button onClick={() => setNotice('')} aria-label="Dismiss message"><X size={13} /></button></div>}
    <section className="overflow-hidden rounded-xl border border-[#28343c] bg-[#151e24]"><div className="flex flex-col gap-3 border-b border-[#29343b] p-4 sm:flex-row sm:items-center sm:justify-between sm:px-5"><div><h2 className="text-[12px] font-semibold">Scenario ledger</h2><p className="mt-1 text-[9px] text-[#78878e]">{visible.length} of {signals.length} local records</p></div><div className="flex flex-wrap gap-2"><label className="flex h-9 min-w-[190px] flex-1 items-center gap-2 rounded-lg border border-[#303c43] bg-[#10181e] px-3 sm:flex-none"><Search size={13} className="text-[#738189]" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search signal history…" className="w-full bg-transparent text-[9px] outline-none placeholder:text-[#637179]" data-testid="input-signal-search" /></label><select className={`${input} h-9`} value={filter} onChange={(e) => setFilter(e.target.value)}><option>All outcomes</option>{['Pending', 'Correct', 'Incorrect', 'Expired'].map((x) => <option key={x}>{x}</option>)}</select><select className={`${input} h-9`} value={segmentFilter} onChange={(e) => setSegmentFilter(e.target.value)}><option>All segments</option>{['Equity', 'Index Futures', 'Index Options', 'Stock Futures'].map((x) => <option key={x}>{x}</option>)}</select><button className="h-9 rounded-lg border border-[#303c43] px-3 text-[9px] text-[#a9b4b4] hover:bg-[#202a31]" onClick={reset}>Reset samples</button></div></div>
      <div className="overflow-x-auto"><table className="w-full min-w-[1030px] text-left"><thead><tr className="border-b border-[#29343b] bg-[#121a20] text-[8px] uppercase tracking-[.12em] text-[#718087]">{['Scenario', 'Segment', 'Bias', 'Confidence', 'Window', 'Generated · IST', 'Agents', 'Outcome review'].map((x) => <th key={x} className="px-3 py-3 font-medium">{x}</th>)}</tr></thead><tbody>{visible.map((s) => <tr key={s.id} className="border-b border-[#253038] align-top last:border-0 hover:bg-[#1b252b]"><td className="px-3 py-3"><b className="text-[9px] text-[#d2dad5]">{s.symbol}</b><span className="block mt-1 text-[8px] text-[#748187]">{s.instrument}</span><span className="mt-1 block font-data text-[7px] text-[#66757c]">{s.id}</span></td><td className="px-3 py-3 text-[8px] text-[#9da9aa]">{s.segment}</td><td className="px-3 py-3"><Bias value={s.bias} /></td><td className="px-3 py-3 font-data text-[9px]">{s.confidence}%</td><td className="px-3 py-3 text-[8px] text-[#9da9aa]">{s.timeframe}</td><td className="px-3 py-3 font-data text-[8px] text-[#9da9aa]">{s.generated}</td><td className="px-3 py-3"><div className="flex max-w-[180px] flex-wrap gap-1">{s.agents.map((a) => <span key={a} className="rounded border border-[#303d36] px-1.5 py-1 text-[7px] text-[#a9b89a]">{a}</span>)}</div></td><td className="px-3 py-3"><div className="flex flex-col items-start gap-2"><Badge>{s.outcome}</Badge><select aria-label={`Review outcome for ${s.id}`} className="h-7 rounded border border-[#364148] bg-[#111a20] px-2 text-[8px] text-[#bdc7c5]" value={s.outcome} onChange={(e) => outcome(s.id, e.target.value as Outcome)} data-testid={`select-outcome-${s.id}`}><option>Pending</option><option>Correct</option><option>Incorrect</option><option>Expired</option></select></div></td></tr>)}</tbody></table></div>
      {!visible.length && <div className="flex flex-col items-center px-6 py-12 text-center"><Search size={18} className="text-[#82917a]" /><b className="mt-3 text-[11px] text-[#c5ceca]">No matching scenarios</b><p className="mt-1 text-[9px] text-[#7b898f]">Adjust search or filters, or generate a new synthetic signal.</p></div>}
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#29343b] px-4 py-3 text-[8px] text-[#718087]"><span>Local outcomes · SIMULATED / DEMO</span><span>No live market data or real performance is tracked</span></div>
    </section>
    <div className="mt-4 rounded-lg border border-[#2c393f] bg-[#141d23] p-3 text-[8px] leading-relaxed text-[#78878e]">Outcome labels are manually editable evaluation metadata. They do not indicate actual trading results, future performance or a recommendation.</div>
  </div>;
}

export default function AdminConsole({ section }: { section: Section }) {
  const page = sectionMeta[section];
  const [rows, setRows] = useState<Row[]>(() => stored(`rows-${section}`, seedRows[section as keyof typeof seedRows] || []));
  const [agents, setAgents] = useState<Agent[]>(() => stored('agents', seedAgents));
  const [signals, setSignalState] = useState(getSignals);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');
  const [policies, setPolicies] = useState(() => stored('policies', { mfa: true, idle: true, location: false }));
  const [dialog, setDialog] = useState(false);
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [planChoice, setPlanChoice] = useState('Gold');
  const [notice, setNotice] = useState('');
  const [globalSubscription, setGlobalSubscription] = useState(() => stored('global-subscription-enabled', true));
  const [planEnabled, setPlanEnabled] = useState<Record<string, boolean>>(() => stored('plan-enabled', { Gold: true, Diamond: true, Kohinoor: true, Elite: true }));
  const persistRows = (next: Row[]) => { setRows(next); save(`rows-${section}`, next); };
  const persistAgents = (next: Agent[]) => { setAgents(next); save('agents', next); };
  const filtered = useMemo(() => rows.filter((row) => Object.values(row).join(' ').toLowerCase().includes(query.toLowerCase()) && (filter === 'All' || String(row.status || row.review || 'All') === filter)), [rows, query, filter]);
  const metric = (label: string, value: string, note: string) => <Metric label={label} value={value} note={note} />;
  const action = (index: number, key: string, value: string) => persistRows(rows.map((row, i) => i === index ? { ...row, [key]: value } : row));
  const userAdd = () => {
    if (!name.trim() || !/^\\+?[0-9\\s()-]{8,18}$/.test(mobile.trim()) || !email.includes('@')) return;
    const userId = `USR-MANUAL-${String(Date.now()).slice(-5)}`;
    const cleanName = name.trim();
    persistRows([{ id: userId, name: cleanName, mobile: mobile.trim(), email: email.trim(), source: 'Manually added', plan: planChoice, signupDate: 'Admin entry · demo', status: 'Active' }, ...rows]);
    const subscriptionRows = stored<Row[]>('rows-subscriptions', seedRows.subscriptions);
    save('rows-subscriptions', [{ user: cleanName, userId, plan: planChoice, price: 'Not set', period: 'To configure', status: 'Inactive', renewal: 'Not set' }, ...subscriptionRows]);
    setDialog(false); setName(''); setMobile(''); setEmail(''); setPlanChoice('Gold');
    setNotice('Demo user added to the manual user directory in this browser.');
  };
  if (section === 'ai-agents') return <div className="enter"><Heading eyebrow={page.eyebrow} title={page.title} description={page.description} /><DemoBanner /><div className="mb-5 grid grid-cols-2 gap-3 xl:grid-cols-4">{metric('Analysis agents', String(agents.length), 'Synthetic contributors')}{metric('Enabled', String(agents.filter((a) => a.enabled).length), 'Local configuration')}{metric('Sample signals', String(agents.reduce((sum, a) => sum + a.count, 0)), 'Illustrative run count')}{metric('Average sample accuracy', `${(agents.reduce((sum, a) => sum + a.accuracy, 0) / agents.length).toFixed(1)}%`, 'Historical synthetic outcomes')}</div><div className="grid gap-3 lg:grid-cols-2">{agents.map((agent) => <article key={agent.id} className="rounded-xl border border-[#28343c] bg-[#151e24] p-4 sm:p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div className="flex gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg border border-[#334139] bg-[#1b2823] text-[#c5d779]"><Bot size={17} /></span><div><div className="flex items-center gap-2"><h2 className="text-[11px] font-semibold text-[#d8e0da]">{agent.name}</h2><Badge>{agent.enabled ? 'Enabled' : 'Paused'}</Badge></div><p className="mt-1 text-[9px] text-[#839095]">{agent.role}</p></div></div><button className="rounded-lg border border-[#364148] px-2.5 py-1.5 text-[8px] text-[#bdc7c5] hover:border-[#687953]" onClick={() => persistAgents(agents.map((a) => a.id === agent.id ? { ...a, enabled: !a.enabled } : a))} data-testid={`button-toggle-${agent.id}`}>{agent.enabled ? 'Pause agent' : 'Enable agent'}</button></div><div className="mt-5 grid grid-cols-3 gap-3 border-t border-[#29343b] pt-4"><div><p className="text-[7px] uppercase tracking-[.11em] text-[#748187]">Sample signals</p><b className="mt-1 block font-data text-[12px] text-[#d5ddd7]">{agent.count}</b></div><div><p className="text-[7px] uppercase tracking-[.11em] text-[#748187]">Sample accuracy</p><b className="mt-1 block font-data text-[12px] text-[#d5ddd7]">{agent.accuracy}%</b></div><div><p className="text-[7px] uppercase tracking-[.11em] text-[#748187]">Last test</p><b className="mt-1 block font-data text-[10px] text-[#d5ddd7]">{agent.lastTest}</b></div></div><div className="mt-4 flex items-center justify-between rounded-lg border border-[#2d393c] bg-[#11191f] px-3 py-2.5"><div><p className="text-[8px] font-medium text-[#bdc7c5]">Test contribution weight</p><p className="mt-0.5 text-[7px] text-[#718087]">Local 1–5 evaluation rating</p></div><select aria-label={`Rating for ${agent.name}`} className="h-8 rounded border border-[#364148] bg-[#182127] px-2 text-[9px] text-[#dce3df]" value={agent.rating} onChange={(e) => persistAgents(agents.map((a) => a.id === agent.id ? { ...a, rating: Number(e.target.value) } : a))}>{[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} / 5</option>)}</select></div></article>)}</div><p className="mt-4 text-[8px] text-[#718087]">Toggles and ratings are stored locally. No model is loaded or called.</p></div>;
  if (section === 'ai-performance') {
    const evalSignals = signals.filter((s) => s.outcome !== 'Pending');
    return <div className="enter"><Heading eyebrow={page.eyebrow} title={page.title} description={page.description} /><DemoBanner /><div className="mb-5 grid grid-cols-2 gap-3 xl:grid-cols-4">{metric('Evaluated scenarios', String(evalSignals.length), 'Local outcome labels')}{metric('Correct labels', String(evalSignals.filter((s) => s.outcome === 'Correct').length), 'Editable by signal review')}{metric('Incorrect labels', String(evalSignals.filter((s) => s.outcome === 'Incorrect').length), 'Editable by signal review')}{metric('Agent ratings', '1—5', 'Individual local test ratings')}</div><div className="grid gap-5 xl:grid-cols-[1.3fr_.85fr]"><section className="rounded-xl border border-[#28343c] bg-[#151e24] p-4 sm:p-5"><div className="flex items-center justify-between"><div><h2 className="text-[12px] font-semibold">Outcome history</h2><p className="mt-1 text-[9px] text-[#78878e]">Sample records bucketed by generated session</p></div><Link href="/signal-history" className="text-[9px] text-[#c5d779]">Review outcomes <ArrowRight size={11} className="ml-1 inline" /></Link></div><div className="mt-4 space-y-3">{[{ date: 'Today · IST', signals: signals.length, correct: signals.filter((s) => s.outcome === 'Correct').length, incorrect: signals.filter((s) => s.outcome === 'Incorrect').length }, { date: '23 Jun · sample bucket', signals: 24, correct: 15, incorrect: 6 }, { date: '22 Jun · sample bucket', signals: 19, correct: 12, incorrect: 4 }, { date: '21 Jun · sample bucket', signals: 31, correct: 20, incorrect: 7 }].map((bucket) => <div key={bucket.date} className="rounded-lg border border-[#2c383e] bg-[#11191f] p-3"><div className="flex items-center justify-between"><b className="text-[9px] text-[#cbd3d0]">{bucket.date}</b><span className="font-data text-[8px] text-[#879495]">{bucket.signals} sample signals</span></div><div className="mt-3 flex items-center gap-3"><div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#29343b]"><div className="h-full rounded-full bg-[#adc66f]" style={{ width: `${bucket.signals ? bucket.correct / bucket.signals * 100 : 0}%` }} /></div><span className="font-data text-[8px] text-[#a9bf7c]">{bucket.signals ? Math.round(bucket.correct / bucket.signals * 100) : 0}% correct labels</span></div><p className="mt-2 text-[7px] text-[#718087]">{bucket.correct} correct · {bucket.incorrect} incorrect · remaining pending / expired</p></div>)}</div><p className="mt-3 text-[8px] text-[#718087]">Historical buckets are illustrative samples; only today's counts update from local signal reviews.</p></section><section className="rounded-xl border border-[#28343c] bg-[#151e24] p-4 sm:p-5"><h2 className="text-[12px] font-semibold">Individual agent ratings</h2><p className="mt-1 text-[9px] text-[#78878e]">Editable testing configuration</p><div className="mt-3 divide-y divide-[#29343b]">{agents.map((agent) => <div key={agent.id} className="flex items-center justify-between gap-2 py-3"><div><p className="text-[9px] font-medium text-[#cbd3d0]">{agent.name}</p><p className="mt-1 text-[8px] text-[#75838a]">{agent.count} samples · {agent.accuracy}% illustrative accuracy</p></div><select className="h-8 rounded border border-[#364148] bg-[#182127] px-2 text-[9px] text-[#dce3df]" aria-label={`Rating for ${agent.name}`} value={agent.rating} onChange={(e) => persistAgents(agents.map((a) => a.id === agent.id ? { ...a, rating: Number(e.target.value) } : a))}>{[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} / 5</option>)}</select></div>)}</div><Link href="/ai-agents" className="mt-3 inline-block text-[9px] text-[#c5d779]">Manage agent configuration <ArrowRight size={11} className="ml-1 inline" /></Link></section></div></div>;
  }
  const columns = page.columns;
  return <div className="enter"><Heading eyebrow={page.eyebrow} title={page.title} description={page.description} action={section === 'users' ? <button className={button} onClick={() => setDialog(true)}><Plus size={13} />Add user</button> : section === 'system' ? <button className={button} onClick={() => setNotice('Local demo maintenance notice queued for preview.')}><Activity size={13} />Simulate notice</button> : <Badge>Sample data</Badge>} />
    {section === 'payments' && <DemoBanner>SIMULATED / DEMO — payment rows are fictional review records only. No payment provider, funds, settlement, debit, credit or refund actions exist.</DemoBanner>}
    {section === 'system' && <DemoBanner>Local demo health only. No production service is monitored and no maintenance action leaves this browser.</DemoBanner>}
    {section === 'subscriptions' && <div className="mb-5 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#35433a] bg-[#1a2521] p-4"><div><b className="text-[10px]">Global subscription access</b><p className="mt-1 text-[8px] text-[#82918a]">Master Admin can stop new subscription access globally. Existing user access remains individually controlled.</p></div><button className={button} onClick={() => { const next = !globalSubscription; setGlobalSubscription(next); save('global-subscription-enabled', next); setNotice(next ? 'Global subscription access enabled.' : 'Global subscription access disabled.'); }}>{globalSubscription ? 'ON · Disable' : 'OFF · Enable'}</button></div>
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">{['Gold', 'Diamond', 'Kohinoor', 'Elite'].map((plan, index) => <div key={plan} className="rounded-xl border border-[#28343c] bg-[#151e24] p-4"><h3 className="text-[10px] font-semibold">{plan}</h3><b className="mt-2 block font-data text-[13px] text-[#d8e393]">Price not set</b><p className="mt-1 text-[8px] text-[#738189]">Level {index + 1} · configure later</p><button className="mt-3 rounded-md border border-[#364148] px-2 py-1.5 text-[8px] text-[#bfc9c5]" onClick={() => { const next = { ...planEnabled, [plan]: !planEnabled[plan] }; setPlanEnabled(next); save('plan-enabled', next); setNotice(`${plan} plan ${next[plan] ? 'enabled' : 'disabled'}.`); }}>{planEnabled[plan] ? 'Plan ON · Disable' : 'Plan OFF · Enable'}</button></div>)}</div>
    </div>}
    {section === 'security' && <div className="mb-5 grid gap-3 sm:grid-cols-3">{[['Require MFA', 'Demo sign-in policy', true], ['Idle timeout', '30 minute sample rule', true], ['Restrict by location', 'Local toggle only', false]].map(([title, detail, enabled]) => <button key={String(title)} onClick={() => setPolicies((old) => { const next = { ...old, [title === 'Require MFA' ? 'mfa' : title === 'Idle timeout' ? 'idle' : 'location']: !old[title === 'Require MFA' ? 'mfa' : title === 'Idle timeout' ? 'idle' : 'location'] }; save('policies', next); return next; })} className="flex items-center justify-between gap-2 rounded-lg border border-[#303b42] bg-[#151e24] p-3 text-left"><span><b className="block text-[9px]">{String(title)}</b><span className="mt-1 block text-[7px] text-[#75838a]">{String(detail)}</span></span>{(title === 'Require MFA' ? policies.mfa : title === 'Idle timeout' ? policies.idle : policies.location) ? <ToggleRight size={19} className="text-[#c5d77a]" /> : <ToggleLeft size={19} className="text-[#748187]" />}</button>)}</div>}
    {notice && <div className="mb-3 flex justify-between rounded-lg border border-[#354a3c] bg-[#23332b] p-2.5 text-[9px] text-[#b8cf8e]" role="status">{notice}<button onClick={() => setNotice('')} aria-label="Dismiss notice"><X size={13} /></button></div>}
    <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">{metric(section === 'users' ? 'Manually added users' : section === 'registered-users' ? 'Self-signup users' : section === 'payments' ? 'Payment records' : section === 'support' ? 'Sample tickets' : 'Local records', String(rows.length), 'Browser-local sample set')}{metric('Environment', 'Demo', 'No production connection')}{metric('Market context', 'India · IST', 'Illustrative workspace')}{metric('Storage', 'Local', 'Private browser session')}</div>
    <section className="overflow-hidden rounded-xl border border-[#28343c] bg-[#151e24]"><div className="flex flex-col gap-3 border-b border-[#29343b] p-4 sm:flex-row sm:items-center sm:justify-between sm:px-5"><div><h2 className="text-[12px] font-semibold">{section === 'payments' ? 'Payment ledger · verification queue' : section === 'users' ? 'Manually added user directory' : section === 'registered-users' ? 'Self-signup user directory' : section === 'subscriptions' ? 'User subscription assignments' : `${page.title} records`}</h2><p className="mt-1 text-[9px] text-[#78878e]">{filtered.length} sample records displayed</p></div><div className="flex flex-wrap items-center gap-2"><label className="flex h-9 min-w-[180px] flex-1 items-center gap-2 rounded-lg border border-[#303c43] bg-[#10181e] px-3 sm:flex-none"><Search size={13} className="text-[#738189]" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Search ${section.replace('-', ' ')}…`} className="w-full bg-transparent text-[9px] outline-none placeholder:text-[#637179]" /></label>{['users', 'registered-users', 'payments', 'subscriptions', 'notifications', 'security', 'support'].includes(section) && <div className="relative"><select className="h-9 appearance-none rounded-lg border border-[#303c43] bg-[#10181e] pl-3 pr-7 text-[9px] text-[#bdc7c5]" value={filter} onChange={(e) => setFilter(e.target.value)}><option>All</option>{[...new Set(rows.map((row) => String(row.status || row.review || '')).filter(Boolean))].map((status) => <option key={status}>{status}</option>)}</select><ChevronDown size={11} className="pointer-events-none absolute right-2 top-3 text-[#76858b]" /></div>}</div></div>
      <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left"><thead><tr className="border-b border-[#29343b] bg-[#121a20] text-[8px] uppercase tracking-[.12em] text-[#718087]">{columns.map(([, label]) => <th key={label} className="px-4 py-3 font-medium">{label}</th>)}<th className="px-4 py-3 font-medium">Local action</th></tr></thead><tbody>{filtered.map((row) => { const index = rows.indexOf(row); return <tr key={String(row.id || row.ref || row.session || row.ticket || index)} className="border-b border-[#253038] last:border-0 hover:bg-[#1b252b]">{columns.map(([key]) => <td key={key} className="max-w-[280px] px-4 py-3 text-[9px] text-[#b8c2c0]">{['status', 'review'].includes(key) ? <Badge>{String(row[key])}</Badge> : <span className={/amount|price/.test(key) ? 'font-data' : ''}>{String(row[key] ?? '—')}</span>}</td>)}<td className="px-4 py-3">
        {['users', 'registered-users'].includes(section) && <div className="flex gap-1"><button className="rounded-md border border-[#364148] px-2 py-1.5 text-[8px] text-[#bfc9c5]" onClick={() => action(index, 'status', row.status === 'Blocked' ? 'Active' : 'Blocked')}>{row.status === 'Blocked' ? 'Unblock' : 'Block'}</button></div>}
        {section === 'payments' && <div className="flex flex-col gap-1"><select aria-label={`Payment verification for ${row.ref}`} className="rounded border border-[#364148] bg-[#111a20] px-2 py-1.5 text-[8px] text-[#bfc9c5]" value={String(row.status)} onChange={(e) => { const nextStatus = e.target.value; const nextRows = rows.map((r, i) => i === index ? { ...r, status: nextStatus, review: nextStatus === 'Approved' ? 'Clear' : nextStatus === 'Rejected' ? 'Flagged' : 'Pending' } : r); persistRows(nextRows); if (nextStatus === 'Approved') { const subscriptions = stored<Row[]>('rows-subscriptions', seedRows.subscriptions); save('rows-subscriptions', subscriptions.map((sub) => sub.user === row.user ? { ...sub, status: 'Active', plan: row.plan } : sub)); } setNotice(`Demo payment ${nextStatus.toLowerCase()}. Subscription activation is reflected in the subscription records when approved.`); }}><option>Pending</option><option>Approved</option><option>Rejected</option></select><span className="text-[7px] text-[#75838a]">Demo verification only</span></div>}
         {section === 'subscriptions' && <div className="flex flex-col gap-1"><select aria-label={`Plan for ${row.user}`} className="rounded border border-[#364148] bg-[#111a20] px-2 py-1 text-[8px] text-[#bfc9c5]" value={String(row.plan)} onChange={(e) => action(index, 'plan', e.target.value)}>{['Gold', 'Diamond', 'Kohinoor', 'Elite'].map((p) => <option key={p}>{p}</option>)}</select><button className="rounded-md border border-[#364148] px-2.5 py-1.5 text-[8px] text-[#bfc9c5]" onClick={() => action(index, 'status', row.status === 'Active' ? 'Paused' : 'Active')}>{row.status === 'Active' ? 'Deactivate' : 'Activate'}</button></div>}
        {section === 'notifications' && <button className="rounded-md border border-[#364148] px-2.5 py-1.5 text-[8px] text-[#bfc9c5]" onClick={() => action(index, 'status', row.status === 'Read' ? 'Unread' : 'Read')}>{row.status === 'Read' ? 'Mark unread' : 'Mark read'}</button>}
        {section === 'security' && <button disabled={row.status === 'Revoked'} className="rounded-md border border-[#503834] px-2.5 py-1.5 text-[8px] text-[#e3a28e] disabled:opacity-50" onClick={() => action(index, 'status', 'Revoked')}>{row.status === 'Revoked' ? 'Revoked' : 'Revoke demo session'}</button>}
        {section === 'support' && <div className="flex items-center gap-1"><select className="max-w-[100px] rounded border border-[#364148] bg-[#111a20] px-1 py-1 text-[8px] text-[#bfc9c5]" value={String(row.status)} onChange={(e) => action(index, 'status', e.target.value)}><option>New</option><option>Open</option><option>Waiting</option><option>Resolved</option></select><select className="max-w-[100px] rounded border border-[#364148] bg-[#111a20] px-1 py-1 text-[8px] text-[#bfc9c5]" value={String(row.assignee)} onChange={(e) => action(index, 'assignee', e.target.value)}><option>Unassigned</option><option>Priya Nair</option><option>Dev Malhotra</option><option>Rohan Shah</option></select></div>}
        {['audit', 'system'].includes(section) && <span className="text-[8px] text-[#6e7b83]">Read only</span>}
      </td></tr>; })}</tbody></table>{!filtered.length && <div className="flex flex-col items-center px-6 py-12 text-center"><Search size={18} className="text-[#82917a]" /><b className="mt-3 text-[11px] text-[#c5ceca]">No matching records</b><p className="mt-1 text-[9px] text-[#7b898f]">Adjust your search or status filter.</p></div>}</div><div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#29343b] px-4 py-3 text-[8px] text-[#718087]"><span>Local demo state · saved in this browser</span><span>India operations · IST · sample records</span></div></section>
    {section === 'payments' && <p className="mt-3 flex items-start gap-2 text-[8px] leading-relaxed text-[#78878e]"><AlertTriangle size={12} className="shrink-0 text-[#d2b373]" />Payment records and review flags are examples only. No charges, settlements or refunds are available.</p>}
    {section === 'users' && <p className="mt-3 text-[8px] text-[#78878e]">Manual users and self-signup users are kept in separate local demo directories. No real accounts are provisioned.</p>}
    {dialog && <div className="fixed inset-0 z-50 grid place-items-center bg-[#080d11]/80 p-4" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && setDialog(false)}><div role="dialog" aria-modal="true" aria-labelledby="dialog-title" className="w-full max-w-md rounded-xl border border-[#36434a] bg-[#172128] p-5 shadow-2xl enter"><div className="flex items-start justify-between"><div><h2 id="dialog-title" className="font-display text-[17px] font-semibold">Add user</h2><p className="mt-1 text-[9px] text-[#849198]">Create a manual demo user. Self-signup records stay in the separate Registered Users section.</p></div><button onClick={() => setDialog(false)} aria-label="Close dialog"><X size={16} /></button></div><div className="mt-5 space-y-3"><label className="block"><span className="mb-1 block text-[8px] uppercase tracking-[.12em] text-[#829096]">Full name</span><input className={`${input} w-full`} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Ananya Rao" /></label><label className="block"><span className="mb-1 block text-[8px] uppercase tracking-[.12em] text-[#829096]">Mobile number</span><input className={`${input} w-full`} type="tel" value={mobile} onChange={(e) => setMobile(e.target.value)} placeholder="+91 98765 43210" /></label><label className="block"><span className="mb-1 block text-[8px] uppercase tracking-[.12em] text-[#829096]">Email address</span><input className={`${input} w-full`} type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@example.com" /></label><label className="block"><span className="mb-1 block text-[8px] uppercase tracking-[.12em] text-[#829096]">Subscription plan</span><select className={`${input} w-full`} value={planChoice} onChange={(e) => setPlanChoice(e.target.value)}>{['Gold', 'Diamond', 'Kohinoor', 'Elite'].map((p) => <option key={p}>{p}</option>)}</select></label></div><div className="mt-5 flex justify-end gap-2"><button className="h-9 rounded-lg px-3 text-[9px] text-[#9aa6a9]" onClick={() => setDialog(false)}>Cancel</button><button className={button} onClick={userAdd} disabled={!name.trim() || !/^\\+?[0-9\\s()-]{8,18}$/.test(mobile.trim()) || !email.includes('@')}><Check size={12} />Add user</button></div></div></div>}
  </div>;
}
