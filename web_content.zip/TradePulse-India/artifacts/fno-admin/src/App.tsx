import { type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import AdminConsole, { Overview, SignalGenerator, SignalHistory } from '@/pages/admin-console';
import { Activity, Bell, Bot, ChartNoAxesCombined, ChevronDown, CircleHelp, Command, CreditCard, FileClock, Headset, LayoutDashboard, Menu, ReceiptText, ScrollText, ServerCog, ShieldCheck, UserRoundCog, X, Zap } from 'lucide-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();
const paths = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/signals', label: 'Generate signal', icon: Zap },
  { href: '/signal-history', label: 'Signal history', icon: FileClock },
  { href: '/ai-agents', label: 'AI agents', icon: Bot },
  { href: '/ai-performance', label: 'AI performance & ratings', icon: ChartNoAxesCombined },
  { href: '/users', label: 'Manually added users', icon: UserRoundCog },
  { href: '/registered-users', label: 'Self-signup users', icon: UserRoundCog },
  { href: '/subscriptions', label: 'Subscriptions', icon: ReceiptText },
  { href: '/payments', label: 'Deposits & payments', icon: CreditCard },
  { href: '/strategy-lab', label: 'Strategy Lab', icon: Zap },
  { href: '/backtesting', label: 'Backtesting & paper trading', icon: Activity },
  { href: '/risk-management', label: 'Risk management', icon: ShieldCheck },
  { href: '/market-data', label: 'Market data & API', icon: ServerCog },
  { href: '/notifications', label: 'Notifications', icon: Bell },
  { href: '/security', label: 'Security', icon: ShieldCheck },
  { href: '/audit', label: 'Audit log', icon: ScrollText },
  { href: '/system', label: 'System status', icon: ServerCog },
  { href: '/support', label: 'Support desk', icon: Headset },
  { href: '/compliance', label: 'Compliance & docs', icon: ScrollText },
];

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Shell><Switch>
    <Route path="/" component={Overview} />
    <Route path="/signals" component={SignalGenerator} />
    <Route path="/signal-history" component={SignalHistory} />
    <Route path="/users">{() => <AdminConsole section="users" />}</Route>
    <Route path="/registered-users">{() => <AdminConsole section="registered-users" />}</Route>
    <Route path="/payments">{() => <AdminConsole section="payments" />}</Route>
    <Route path="/subscriptions">{() => <AdminConsole section="subscriptions" />}</Route>
    <Route path="/ai-agents">{() => <AdminConsole section="ai-agents" />}</Route>
    <Route path="/ai-performance">{() => <AdminConsole section="ai-performance" />}</Route>
    <Route path="/notifications">{() => <AdminConsole section="notifications" />}</Route>
    <Route path="/security">{() => <AdminConsole section="security" />}</Route>
    <Route path="/audit">{() => <AdminConsole section="audit" />}</Route>
    <Route path="/system">{() => <AdminConsole section="system" />}</Route>
    <Route path="/support">{() => <AdminConsole section="support" />}</Route>
    <Route path="/strategy-lab">{() => <AdminConsole section="strategy-lab" />}</Route>
    <Route path="/backtesting">{() => <AdminConsole section="backtesting" />}</Route>
    <Route path="/risk-management">{() => <AdminConsole section="risk-management" />}</Route>
    <Route path="/market-data">{() => <AdminConsole section="market-data" />}</Route>
    <Route path="/compliance">{() => <AdminConsole section="compliance" />}</Route>
    <Route component={NotFound} />
  </Switch></Shell></ErrorBoundary>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileMenu, setMobileMenu] = useState(false);
  const [notice, setNotice] = useState(false);
  const [profile, setProfile] = useState(false);
  const current = paths.find((item) => item.href === location);
  return <div className="app-noise min-h-[100dvh] bg-[#111820] text-[#dce3e8]">
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[236px] flex-col border-r border-[#26313a] bg-[#0e151c] lg:flex">
      <Brand />
      <div className="px-4 pt-6"><div className="mb-3 px-3 text-[9px] font-semibold uppercase tracking-[.2em] text-[#65727c]">Signal operations</div>
        <nav className="max-h-[calc(100dvh-270px)] space-y-1 overflow-y-auto pr-1">{paths.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-${href === '/' ? 'overview' : href.slice(1)}`} className={`group flex h-9 items-center gap-3 rounded-lg px-3 text-[11px] font-medium transition ${location === href ? 'bg-[#222d30] text-[#e4ed9c] shadow-[inset_2px_0_0_#d8e66a]' : 'text-[#8d9aa3] hover:bg-[#1a242c] hover:text-[#e3e9e8]'}`}><Icon size={15} strokeWidth={1.8} /><span>{label}</span></Link>)}</nav>
      </div>
      <div className="mt-auto p-4"><div className="rounded-xl border border-[#29343a] bg-[#151e24] p-3.5"><div className="flex items-center gap-2 text-[9px] font-semibold uppercase tracking-[.12em] text-[#c4d17d]"><span className="h-1.5 w-1.5 rounded-full bg-[#d8e66a]" />Private demo console</div><p className="mt-2 text-[9px] leading-relaxed text-[#76838a]">Synthetic data only. No feeds, models, brokers or payment providers.</p><div className="mt-3 border-t border-[#29343a] pt-2 text-[8px] text-[#6e7b83]">LOCAL SESSION · INDIA / IST</div></div><p className="mt-3 flex items-center gap-2 px-3 text-[9px] text-[#718087]"><CircleHelp size={13} /> Internal evaluation workspace</p></div>
    </aside>
    <div className="min-h-[100dvh] lg:pl-[236px]">
      <header className="sticky top-0 z-20 flex h-[62px] items-center justify-between border-b border-[#26313a] bg-[#111820]/95 px-4 backdrop-blur-xl sm:px-7 lg:px-9">
        <div className="flex items-center gap-3"><button className="rounded-md p-2 text-[#8b99a2] hover:bg-[#202a31] lg:hidden" onClick={() => setMobileMenu(true)} aria-label="Toggle navigation" data-testid="button-mobile-menu"><Menu size={18} /></button><div className="hidden text-[10px] text-[#75838b] sm:block">Private workspace <span className="mx-2 text-[#43515a]">/</span><span className="text-[#d8e0df]">{current?.label || 'Overview'}</span></div><div className="text-[11px] font-medium sm:hidden">{current?.label || 'Overview'}</div><span className="hidden items-center gap-1.5 rounded border border-[#3d4533] bg-[#252b22] px-2 py-1 text-[8px] font-semibold uppercase tracking-[.11em] text-[#c4d17d] md:flex">SIMULATED · DEMO</span></div>
        <div className="flex items-center gap-2 sm:gap-4"><span className="hidden font-data text-[9px] text-[#819098] sm:block">LOCAL SESSION <span className="ml-2 text-[#dce2df]">IST</span></span><span className="h-4 w-px bg-[#2b363e]" />
          <div className="relative"><button aria-label="Notifications" onClick={() => { setNotice(!notice); setProfile(false); }} className="rounded-lg p-2 text-[#93a0a7] hover:bg-[#202a31]" data-testid="button-notifications"><Bell size={16} /></button>{notice && <div className="absolute right-0 top-11 z-40 w-64 rounded-xl border border-[#344049] bg-[#192229] p-4 shadow-2xl"><b className="text-[11px]">Console notices</b><p className="mt-2 text-[9px] leading-relaxed text-[#95a1a5]">All systems are in local simulation mode. No live connections are configured.</p><button className="mt-3 text-[9px] text-[#c4d17d]" onClick={() => setNotice(false)}>Dismiss</button></div>}</div>
          <div className="relative"><button onClick={() => { setProfile(!profile); setNotice(false); }} className="flex items-center gap-2 rounded-full py-1 pl-1 pr-1.5 hover:bg-[#202a31]" data-testid="button-profile"><span className="grid h-7 w-7 place-items-center rounded-full border border-[#46513c] bg-[#2c372c] text-[9px] font-semibold text-[#dce69a]">RS</span><span className="hidden text-[9px] sm:block">R. Shah</span><ChevronDown size={12} className="text-[#78868c]" /></button>{profile && <div className="absolute right-0 top-11 z-40 w-44 rounded-xl border border-[#344049] bg-[#192229] p-3 text-[9px] shadow-2xl"><p className="text-[#89969b]">Local admin identity</p><p className="mt-2 text-[#d8e0df]">Rohan Shah · Platform admin</p><button className="mt-3 text-[#c4d17d]" onClick={() => setProfile(false)}>Close</button></div>}</div>
        </div>
      </header>
      {mobileMenu && <div className="fixed inset-0 z-40 bg-[#0b1117]/75 lg:hidden" onClick={() => setMobileMenu(false)}><nav className="h-full w-[290px] overflow-y-auto border-r border-[#29343b] bg-[#0e151c] p-5" onClick={(event) => event.stopPropagation()}><div className="mb-6 flex items-center justify-between"><Brand compact /><button onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={17} /></button></div>{paths.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileMenu(false)} className={`mb-1 flex items-center gap-3 rounded-lg px-3 py-2.5 text-[11px] ${location === href ? 'bg-[#222d30] text-[#e4ed9c]' : 'text-[#9aa6ac]'}`}><Icon size={15} />{label}</Link>)}<div className="mt-5 rounded-lg border border-[#29343a] p-3 text-[9px] text-[#89959a]">Demo only · external services disabled</div></nav></div>}
      <main className="mx-auto max-w-[1600px] px-4 pb-12 pt-6 sm:px-7 sm:pt-8 lg:px-9">{children}</main>
    </div>
  </div>;
}
function Brand({ compact = false }: { compact?: boolean }) {
  return <div className={`${compact ? '' : 'flex h-[72px] items-center gap-3 border-b border-[#25313a] px-6'}`}>
    {!compact && <div className="grid h-9 w-9 place-items-center rounded-xl bg-[#d8e66a] text-[#121920]"><Command size={18} strokeWidth={2.4} /></div>}
    <div><div className="font-display text-[14px] font-bold tracking-tight text-[#f0f3eb]">Trade Pulse <span className="text-[#d8e66a]">India</span></div>{!compact && <div className="mt-0.5 text-[8px] font-semibold uppercase tracking-[.18em] text-[#74818b]">Signal testing console</div>}</div>
  </div>;
}
export default App;
