# TradePulse India

Private, mobile-first testing app for AI-generated Indian-market trading signals, agent performance review, user access, payments, and subscription administration. This is not a broker app or trade execution terminal.

## Run & Operate

- `pnpm --filter @workspace/fno-admin run dev` — run the responsive admin web app
- `pnpm --filter @workspace/fno-admin run typecheck` — typecheck the admin app
- `pnpm --filter @workspace/fno-admin run build` — build the admin app
- `pnpm run typecheck` — full workspace typecheck
- `pnpm run build` — typecheck + build all packages

## Product scope

- Private testing only; synthetic/demo data.
- Signals and agent evaluation only; no portfolio, broker order book, margin or order execution features.
- One Master Admin Panel for now.
- Subscription tiers: Gold, Diamond, Kohinoor and Elite. Prices/billing/bank details remain unconfigured until decided.
- Manually added users and self-signup users have separate directories.
- Add User fields: full name, mobile number, email and selected plan.
- Deposit/payment records show the purchased plan and demo verification status.
- Master Admin controls global subscription access, each plan, and individual subscription status.
- Mobile-first responsive web app; preserve desktop browser support and future PWA compatibility.

## Source map

- `artifacts/fno-admin/src/App.tsx` — application shell, navigation and routes.
- `artifacts/fno-admin/src/pages/admin-console.tsx` — dashboard, signals, user/payment/subscription management, agent controls and demo data.
- `.agents/memory/trade-pulse-demo-scope.md` — persistent product boundaries and requirements.

## Important testing limitation

The current frontend uses browser-local demo storage and synthetic data. It is not a production authentication system or shared server database. Changes in one browser/device do not automatically sync to another device. Do not publish as a live subscription or trading-signal service until backend authentication, database persistence, payment verification, security and required reviews are implemented.
