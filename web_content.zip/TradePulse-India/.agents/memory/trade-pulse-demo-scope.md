---
name: Trade Pulse India test-platform scope
description: Trade Pulse India is a private, mobile-first demo workspace for synthetic Indian stock and F&O signals, agent ratings, users and subscriptions.
---

This is a private personal testing application, not a broker app or trading terminal. Its purpose is to generate and review Indian stock and index/stock F&O trading signals using AI-agent concepts, inspect signal history and agent ratings/performance, and let one Master Admin manage users, subscriptions and payment verification.

**Product exclusions:** No broker portfolios, client positions, order books, margin screens, broker order execution, or automatic trading. Signals are for manual review only.

**Current test scope:** Demo/synthetic data only. No live market feed, real AI model, broker connection, payment gateway, bank account details, public signup service, or production database is connected. Browser-local demo storage is used for test interactions.

**Master Admin requirements:** One Master Admin Panel for now. Include dashboard, signal generation/history, AI agent ON/OFF and ratings, manually added users, separate self-signup user directory, deposits/payments with purchased plan, subscriptions, strategy lab, backtesting/paper trading, risk controls, market data/API status, notifications, security, audit log, system monitoring, support and compliance/documentation placeholders.

**Subscription tiers:** Gold, Diamond, Kohinoor and Elite. Prices, billing periods, and bank details are intentionally unconfigured until the user decides them. Master Admin controls global subscription availability, each plan's availability, and each user's subscription activation/deactivation.

**User data:** Add User form includes full name, mobile number, email address and selected plan. Manually added users and self-signup users must be shown in separate sections/directories.

**Payment verification:** Every demo payment record shows the purchased plan, user, amount/status, method, transaction/UTR reference and date. Admin can mark a payment Pending, Approved or Rejected. Approval can reflect an active subscription in the local demo subscription records. Clearly label all such actions as demo-only.

**How to apply:** Preserve the mobile-first responsive web app so it works on phones and desktop browsers. Keep the architecture modular for a future PWA and backend. Do not connect live market data, payment providers, brokers, or order execution unless the user explicitly changes this private-testing scope.
