# Smart Commercial Readiness

## Current build
- Android application with command UI.
- Supported local actions: websites, Android Settings, accessibility settings, notification access settings, dialer, SMS composer, alarm screen, selected installed apps, Home, Back and Recent Apps.
- Accessibility actions require explicit Android authorization.
- Backend API is included as an optional server component.

## Before selling to companies
1. Replace placeholder business/contact information.
2. Deploy the backend behind HTTPS.
3. Add authenticated users, company accounts and role-based access.
4. Do not store sensitive commands or notification content without a documented business need and retention policy.
5. Add crash reporting, audit logging and secure secret management.
6. Test on the Android versions and device models used by customers.
7. Review every permission and disclose why it is needed.
8. Create a signed release build and test the APK/AAB.
9. Prepare company licensing terms, support terms and a privacy policy.
