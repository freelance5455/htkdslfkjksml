KAVÉRON DELIVERY
Phone-friendly delivery storefront.
Open index.html in Chrome after extracting.
Customer name, phone and delivery address are saved on the device.
This is an order/delivery demo; real online payment and a delivery backend must be connected before accepting real payments/orders.
