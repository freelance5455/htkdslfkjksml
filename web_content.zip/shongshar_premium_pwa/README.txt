সংসার — Premium Black + Gold Mobile PWA
========================================

ফাইল:
- index.html — সম্পূর্ণ অ্যাপের UI, CSS animation এবং JavaScript
- manifest.webmanifest — PWA manifest
- sw.js — Service Worker ও basic offline caching
- icons/icon-192.png এবং icons/icon-512.png — অ্যাপ আইকন

লাইভ করার নিয়ম:
1. ZIP extract করুন।
2. shongshar_premium_pwa ফোল্ডারের ভেতরের সব ফাইল ও icons ফোল্ডারসহ আপনার hosting-এর public_html / site root-এ আপলোড করুন।
3. নিশ্চিত করুন index.html, manifest.webmanifest, sw.js এবং icons/ একই root structure-এ আছে।
4. সাইট HTTPS-এ চালু করুন। PWA install ও service worker-এর জন্য HTTPS প্রয়োজন (localhost ব্যতিক্রম)।
5. Chrome Android-এ সাইট খুলুন। Install prompt এলে ইনস্টল করুন; না এলে Chrome ⋮ > Add to Home screen / Install app দেখুন।

ফিচার:
- Mobile-first Premium Black + Gold animated UI
- ড্যাশবোর্ড: মাসিক/আজকের খরচ, বাজার, যাতায়াত, বাকি বিল
- দৈনিক খরচ যোগ/সম্পাদনা/মুছে ফেলা
- তারিখ/খাত/সার্চ ফিল্টার
- বাংলা বাজারের ফর্দ, পরিমাণ, আনুমানিক দাম, কেনা হয়েছে চেকবক্স
- বিল যোগ, due status, paid/unpaid, monthly/yearly repeat
- তারিখভিত্তিক রিপোর্ট ও category summary
- CSV export, print, JSON backup/restore
- PWA manifest, icons, service worker basic offline caching
- Responsive mobile navigation and quick-add modal

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- ডেটা browser Local Storage-এ থাকে; login/cloud sync নেই। একই ব্রাউজার/ডিভাইসে ব্যবহার করুন।
- ব্রাউজার ডেটা মুছে গেলে হিসাব হারাতে পারে; Settings থেকে নিয়মিত JSON backup নিন।
- বিলের due reminder অ্যাপের মধ্যে দেখায়; স্বয়ংক্রিয় push notification পাঠায় না।
- Service worker শুধু একই origin-এর ফাইল cache করে; Google Fonts অনলাইনে থাকলে তবেই লোড হবে।
- লাইভ করার আগে মোবাইলে নিজে টেস্ট করুন এবং backup রাখুন।
