@echo off
chcp 65001 >nul
title Installation de PS FERME
echo ============================================
echo   PS FERME - Gestion de porcherie
echo   Installation sur cet ordinateur (Windows)
echo ============================================
echo.
set "SRC=%~dp0application"
set "DEST=%LOCALAPPDATA%\PS_FERME"
if not exist "%SRC%\index.html" (
  echo ERREUR : le dossier "application" est introuvable a cote de ce fichier.
  echo Decompressez d'abord tout le ZIP, puis relancez l'installation.
  pause & exit /b 1
)
echo Copie des fichiers dans %DEST% ...
if not exist "%DEST%" mkdir "%DEST%"
xcopy "%SRC%" "%DEST%\application" /E /I /Y /Q >nul
if errorlevel 1 ( echo ERREUR de copie. & pause & exit /b 1 )
rem --- cherche Microsoft Edge, sinon Google Chrome ---
set "NAV="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "NAV=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined NAV if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "NAV=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined NAV if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "NAV=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined NAV if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "NAV=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined NAV if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "NAV=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not defined NAV (
  echo ERREUR : ni Microsoft Edge ni Google Chrome n'a ete trouve.
  echo Installez Edge ou Chrome puis relancez cette installation.
  pause & exit /b 1
)
echo Navigateur utilise : %NAV%
rem --- lanceur ---
> "%DEST%\Lancer_PS_FERME.bat" (
  echo @echo off
  echo start "" "%NAV%" --app="file:///%DEST:\=/%/application/index.html" --user-data-dir="%DEST%\profil" --no-first-run --no-default-browser-check
)
rem --- raccourcis Bureau et Menu Demarrer ---
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; foreach($p in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ $s=$w.CreateShortcut((Join-Path $p 'PS FERME.lnk')); $s.TargetPath='%DEST%\Lancer_PS_FERME.bat'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\application\icons\ps_ferme.ico'; $s.WindowStyle=7; $s.Description='PS FERME - Gestion de porcherie'; $s.Save() }"
echo.
echo Installation terminee.
echo Un raccourci "PS FERME" a ete cree sur le Bureau et dans le menu Demarrer.
echo Vos donnees sont enregistrees sur cet ordinateur : pensez a faire des
echo sauvegardes regulieres (menu Donnees - Sauvegarde complete).
echo.
choice /m "Lancer PS FERME maintenant"
if errorlevel 2 exit /b 0
call "%DEST%\Lancer_PS_FERME.bat"
