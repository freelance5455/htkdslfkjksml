@echo off
chcp 65001 >nul
echo Desinstallation de PS FERME.
echo ATTENTION : cela supprime aussi les donnees enregistrees sur cet ordinateur.
echo Faites d'abord une sauvegarde (menu Donnees - Sauvegarde complete).
choice /m "Continuer"
if errorlevel 2 exit /b 0
del "%USERPROFILE%\Desktop\PS FERME.lnk" 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\PS FERME.lnk" 2>nul
rmdir /S /Q "%LOCALAPPDATA%\PS_FERME"
echo PS FERME a ete desinstalle.
pause
