Question Paper Cleaner — Android WebView wrapper

This project packages the supplied HTML app as an Android app. The HTML is in:
app/src/main/assets/index.html

Build an APK:
1. Install Android Studio.
2. Open this project folder in Android Studio.
3. Let Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.

Notes:
- The app needs internet access for Gemini API calls and Google Fonts.
- Enter your own Gemini API key in the app. Do not share the APK with a key already saved in it.
- Printing/PDF behavior depends on Android's WebView and print service; test on your device.
