# AI Tool Recommender

Full-stack local project: Vite + React frontend, Express + Prisma backend, PostgreSQL, JWT authentication, and optional OpenAI recommendations.

## Requirements
- Node.js 20+
- PostgreSQL 14+

## Setup
1. Copy `backend/.env.example` to `backend/.env` and fill in PostgreSQL/JWT/OpenAI values.
2. Copy `frontend/.env.example` to `frontend/.env.local`.
3. Run `npm install` in the root, then `npm run install:all`.
4. Create the database named `ai_tools_db` (or change DATABASE_URL).
5. Run `npm run db:push` and optionally `npm run db:seed`.
6. Run `npm run dev`.
7. Open http://localhost:5173.

OpenAI is optional: if `OPENAI_API_KEY` is blank, the backend uses a local keyword-based recommendation fallback.
