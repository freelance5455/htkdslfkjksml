import { PrismaClient } from '@prisma/client';
const p=new PrismaClient();
const tools=[
{name:'ChatGPT',description:'General-purpose AI assistant for writing, brainstorming, coding, analysis and research.',category:'Assistant',url:'https://chatgpt.com',pricing:['Free','Paid'],tags:['writing','coding','research','chat']},
{name:'Claude',description:'AI assistant suited to long documents, analysis, writing and coding.',category:'Assistant',url:'https://claude.ai',pricing:['Free','Paid'],tags:['writing','documents','coding','research']},
{name:'GitHub Copilot',description:'AI coding assistant integrated with popular development environments.',category:'Coding',url:'https://github.com/features/copilot',pricing:['Paid'],tags:['coding','programming','developer','ide']},
{name:'Canva',description:'Visual design platform with AI features for presentations, posters and social content.',category:'Design',url:'https://www.canva.com',pricing:['Free','Paid'],tags:['design','presentation','graphics','social']},
{name:'Perplexity',description:'AI-powered answer and research engine with web sources.',category:'Research',url:'https://www.perplexity.ai',pricing:['Free','Paid'],tags:['research','search','sources','study']},
{name:'Grammarly',description:'Writing assistant for grammar, clarity, tone and rewriting.',category:'Writing',url:'https://www.grammarly.com',pricing:['Free','Paid'],tags:['writing','grammar','editing','students']},
{name:'Notion AI',description:'AI features inside a workspace for notes, documents, planning and knowledge management.',category:'Productivity',url:'https://www.notion.com/product/ai',pricing:['Paid'],tags:['notes','productivity','planning','documents']},
{name:'Runway',description:'AI creative tools for generating and editing video.',category:'Video',url:'https://runwayml.com',pricing:['Free','Paid'],tags:['video','creative','generation','editing']}
];
for(const t of tools) await p.tool.upsert({where:{name:t.name},update:t,create:t});
await p.$disconnect();
