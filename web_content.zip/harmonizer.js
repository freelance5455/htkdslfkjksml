// =====================================================================
// JUZISOUND ETHNO HARMONIZER ENGINE - VLADI SOUND EDITION
// =====================================================================

const SCALES = {
  hicaz: {
    name: 'Хиджаз',
    desc: 'Любим за кючеци и сола',
    degrees: [0, 1, 4, 5, 7, 8, 10]
  },
  hicazkar: {
    name: 'Хиджазкар',
    desc: 'Ориенталски мажор',
    degrees: [0, 1, 4, 5, 7, 8, 11]
  },
  kurdi: {
    name: 'Кюрди',
    desc: 'Мелодичен фригийски лад',
    degrees: [0, 1, 3, 5, 7, 8, 10]
  },
  saba: {
    name: 'Саба',
    desc: 'Тъжен ориенталски лад',
    degrees: [0, 1, 3, 4, 7, 8, 10]
  },
  ussak: {
    name: 'Ушак / Баяти',
    desc: 'Класически фолклорен лад',
    degrees: [0, 1, 3, 5, 7, 8, 10]
  },
  nihavend: {
    name: 'Нихавенд',
    desc: 'Хармоничен минор / Циганска гама',
    degrees: [0, 2, 3, 5, 7, 8, 11]
  },
  gypsy: {
    name: 'Цигански лад',
    desc: 'Двоен хармоничен минор',
    degrees: [0, 2, 3, 6, 7, 8, 11]
  },
  major: {
    name: 'Мажор',
    desc: 'Весел класически лад',
    degrees: [0, 2, 4, 5, 7, 9, 11]
  },
  minor: {
    name: 'Минор',
    desc: 'Натурален минор',
    degrees: [0, 2, 3, 5, 7, 8, 10]
  },
  rast: {
    name: 'Раст',
    desc: 'Традиционен ориенталски макам',
    degrees: [0, 2, 3.5, 5, 7, 9, 10.5]
  }
};

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const NOTE_NAMES_BG = ['До', 'До#', 'Ре', 'Ре#', 'Ми', 'Фа', 'Фа#', 'Сол', 'Сол#', 'Ла', 'Сиb', 'Си'];

class EthnoHarmonizer {
  constructor() {
    this.enabled = true;
    this.rootNote = 2; // D (Ре)
    this.scaleKey = 'hicaz';
    this.interval = 'upper_3rd';
    this.microtuning = new Array(12).fill(0);
    this.harmonyVolumeRatio = 0.9;
    this.secondChannel = 2;
  }

  setRootNote(noteIndex) {
    this.rootNote = ((noteIndex % 12) + 12) % 12;
  }

  setScale(scaleKey) {
    if (SCALES[scaleKey]) {
      this.scaleKey = scaleKey;
    }
  }

  setInterval(intervalKey) {
    this.interval = intervalKey;
  }

  toggleMicrotone(noteIndex, cents = -50) {
    const idx = ((noteIndex % 12) + 12) % 12;
    this.microtuning[idx] = this.microtuning[idx] === 0 ? cents : 0;
    return this.microtuning[idx] !== 0;
  }

  resetMicrotuning() {
    this.microtuning.fill(0);
  }

  getHarmonizedNote(midiNote) {
    if (!this.enabled) return null;

    const scale = SCALES[this.scaleKey];
    if (!scale) return null;

    const pitchClass = midiNote % 12;
    const octave = Math.floor(midiNote / 12);
    const relPitch = ((pitchClass - this.rootNote) % 12 + 12) % 12;

    const degrees = scale.degrees;
    const numDegrees = degrees.length;

    let closestDegIdx = 0;
    let minDistance = 999;
    for (let i = 0; i < numDegrees; i++) {
      const dist = Math.abs(degrees[i] - relPitch);
      if (dist < minDistance) {
        minDistance = dist;
        closestDegIdx = i;
      }
    }

    let targetNotes = [];

    switch (this.interval) {
      case 'upper_3rd': {
        const targetDegIdx = closestDegIdx + 2;
        const octaveOffset = Math.floor(targetDegIdx / numDegrees);
        const wrappedDegIdx = targetDegIdx % numDegrees;
        const semitoneFromRoot = degrees[wrappedDegIdx] + (octaveOffset * 12);
        const harmMidi = (octave * 12) + this.rootNote + Math.round(semitoneFromRoot);
        targetNotes.push(harmMidi);
        break;
      }

      case 'lower_3rd': {
        let targetDegIdx = closestDegIdx - 2;
        let octaveOffset = 0;
        if (targetDegIdx < 0) {
          octaveOffset = -1;
          targetDegIdx += numDegrees;
        }
        const semitoneFromRoot = degrees[targetDegIdx] + (octaveOffset * 12);
        const harmMidi = (octave * 12) + this.rootNote + Math.round(semitoneFromRoot);
        targetNotes.push(harmMidi);
        break;
      }

      case 'upper_4th': {
        const targetDegIdx = closestDegIdx + 3;
        const octaveOffset = Math.floor(targetDegIdx / numDegrees);
        const semitoneFromRoot = degrees[targetDegIdx % numDegrees] + (octaveOffset * 12);
        targetNotes.push((octave * 12) + this.rootNote + Math.round(semitoneFromRoot));
        break;
      }

      case 'upper_6th': {
        const targetDegIdx = closestDegIdx + 5;
        const octaveOffset = Math.floor(targetDegIdx / numDegrees);
        const semitoneFromRoot = degrees[targetDegIdx % numDegrees] + (octaveOffset * 12);
        targetNotes.push((octave * 12) + this.rootNote + Math.round(semitoneFromRoot));
        break;
      }

      case 'octave_up': {
        targetNotes.push(midiNote + 12);
        break;
      }

      case 'octave_down': {
        targetNotes.push(midiNote - 12);
        break;
      }

      case 'dual_3rd_oct': {
        const targetDegIdx = closestDegIdx + 2;
        const octaveOffset = Math.floor(targetDegIdx / numDegrees);
        const semitoneFromRoot = degrees[targetDegIdx % numDegrees] + (octaveOffset * 12);
        targetNotes.push((octave * 12) + this.rootNote + Math.round(semitoneFromRoot));
        targetNotes.push(midiNote + 12);
        break;
      }

      default:
        return null;
    }

    return targetNotes;
  }

  getDetuneCents(midiNote) {
    const pitchClass = midiNote % 12;
    return this.microtuning[pitchClass] || 0;
  }

  generateKorgSysExTune() {
    const sysex = [0xF0, 0x42, 0x30, 0x00, 0x4C];
    for (let i = 0; i < 12; i++) {
      const val = this.microtuning[i] < 0 ? 14 : 64;
      sysex.push(val);
    }
    sysex.push(0xF7);
    return new Uint8Array(sysex);
  }
}

window.EthnoHarmonizer = EthnoHarmonizer;
window.SCALES = SCALES;
window.NOTE_NAMES = NOTE_NAMES;
window.NOTE_NAMES_BG = NOTE_NAMES_BG;
