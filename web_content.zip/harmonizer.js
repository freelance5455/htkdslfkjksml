// =====================================================================
// JUZISOUND ETHNO HARMONIZER ENGINE
// Balkan & Oriental Intelligent Scale Harmony & Microtuning
// =====================================================================

const SCALES = {
  hicaz: {
    name: 'Хиджаз (Hicaz)',
    desc: 'Фаворит за кючеци и маками (Phrygian Dominant)',
    degrees: [0, 1, 4, 5, 7, 8, 10]
  },
  hicazkar: {
    name: 'Хиджазкар (Hicazkar)',
    desc: 'Ориенталски мажор (Double Harmonic Major)',
    degrees: [0, 1, 4, 5, 7, 8, 11]
  },
  kurdi: {
    name: 'Кюрди (Kürdi)',
    desc: 'Мелодичен фригийски лад (Phrygian)',
    degrees: [0, 1, 3, 5, 7, 8, 10]
  },
  saba: {
    name: 'Саба (Saba)',
    desc: 'Тъжен ориенталски лад с намалена квинта',
    degrees: [0, 1, 3, 4, 7, 8, 10]
  },
  ussak: {
    name: 'Ушак / Баяти (Uşşak)',
    desc: 'Класически балкански фолк лад',
    degrees: [0, 1, 3, 5, 7, 8, 10]
  },
  nihavend: {
    name: 'Нихавенд (Хармоничен минор)',
    desc: 'Циганска гама с висока 7-ма степен',
    degrees: [0, 2, 3, 5, 7, 8, 11]
  },
  gypsy: {
    name: 'Цигански лад (Gypsy Minor)',
    desc: 'Двоен хармоничен минор с повишена 4-та степен',
    degrees: [0, 2, 3, 6, 7, 8, 11]
  },
  major: {
    name: 'Мажор (Major / Çargah)',
    desc: 'Класически весел лад',
    degrees: [0, 2, 4, 5, 7, 9, 11]
  },
  minor: {
    name: 'Натурален Минор (Minor)',
    desc: 'Естествен минор (Еолийски)',
    degrees: [0, 2, 3, 5, 7, 8, 10]
  },
  rast: {
    name: 'Раст (Rast)',
    desc: 'Традиционен макам с четвърт тонове',
    degrees: [0, 2, 3.5, 5, 7, 9, 10.5]
  }
};

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const NOTE_NAMES_BG = ['До (C)', 'До# (C#)', 'Ре (D)', 'Ре# (D#)', 'Ми (E)', 'Фа (F)', 'Фа# (F#)', 'Сол (G)', 'Сол# (G#)', 'Ла (A)', 'Сиb (Bb)', 'Си (B)'];

class EthnoHarmonizer {
  constructor() {
    this.enabled = true;               // Master ON/OFF
    this.rootNote = 2;                 // 2 = D (Ре) по подразбиране
    this.scaleKey = 'hicaz';           // Хиджаз
    this.interval = 'upper_3rd';       // 'upper_3rd', 'lower_3rd', 'upper_6th', 'octave_up', 'dual_3rd_oct'
    
    // Микротунинг (четвърт тонове в центове за всяка от 12-те ноти)
    this.microtuning = new Array(12).fill(0); // 0 cents
    
    // Динамика на втория глас (сила на терцата спрямо основния тон)
    this.harmonyVolumeRatio = 0.9;     // 90%
    this.secondChannel = 2;            // За изпращане към Upper 2 на Korg Pa
  }

  setRootNote(noteIndex) {
    this.rootNote = ((noteIndex % 12) + 12) % 12;
  }

  setScale(scaleKey) {
    if (SCALES[scaleKey]) {
      this.scaleKey = scaleKey;
    }
  }

  setInterval(intervalKey) {
    this.interval = intervalKey;
  }

  toggleMicrotone(noteIndex, cents = -50) {
    const idx = ((noteIndex % 12) + 12) % 12;
    this.microtuning[idx] = this.microtuning[idx] === 0 ? cents : 0;
    return this.microtuning[idx] !== 0;
  }

  resetMicrotuning() {
    this.microtuning.fill(0);
  }

  // Изчисляване на хармонизираната нота за дадена входяща MIDI нота
  getHarmonizedNote(midiNote) {
    if (!this.enabled) return null;

    const scale = SCALES[this.scaleKey];
    if (!scale) return null;

    // Относителна височина спрямо основния тон (0 .. 11)
    const pitchClass = midiNote % 12;
    const octave = Math.floor(midiNote / 12);
    const relPitch = ((pitchClass - this.rootNote) % 12 + 12) % 12;

    const degrees = scale.degrees;
    const numDegrees = degrees.length;

    // Намиране на най-близката степен от лада
    let closestDegIdx = 0;
    let minDistance = 999;
    for (let i = 0; i < numDegrees; i++) {
      const dist = Math.abs(degrees[i] - relPitch);
      if (dist < minDistance) {
        minDistance = dist;
        closestDegIdx = i;
      }
    }

    // Изчисляване на интервала в стъпки от лада
    let targetNotes = [];

    switch (this.interval) {
      case 'upper_3rd': {
        // Горна терца: +2 степени в гамата
        const targetDegIdx = closestDegIdx + 2;
        const octaveOffset = Math.floor(targetDegIdx / numDegrees);
        const wrappedDegIdx = targetDegIdx % numDegrees;
        const semitoneFromRoot = degrees[wrappedDegIdx] + (octaveOffset * 12);
        const harmMidi = (octave * 12) + this.rootNote + Math.round(semitoneFromRoot);
        targetNotes.push(harmMidi);
        break;
      }

      case 'lower_3rd': {
        // Долна терца: -2 степени в гамата
        let targetDegIdx = closestDegIdx - 2;
        let octaveOffset = 0;
        if (targetDegIdx < 0) {
          octaveOffset = -1;
          targetDegIdx += numDegrees;
        }
        const semitoneFromRoot = degrees[targetDegIdx] + (octaveOffset * 12);
        const harmMidi = (octave * 12) + this.rootNote + Math.round(semitoneFromRoot);
        targetNotes.push(harmMidi);
        break;
      }

      case 'upper_4th': {
        // Кварта: +3 степени в гамата
        const targetDegIdx = closestDegIdx + 3;
        const octaveOffset = Math.floor(targetDegIdx / numDegrees);
        const semitoneFromRoot = degrees[targetDegIdx % numDegrees] + (octaveOffset * 12);
        targetNotes.push((octave * 12) + this.rootNote + Math.round(semitoneFromRoot));
        break;
      }

      case 'upper_6th': {
        // Горна секста: +5 степени
        const targetDegIdx = closestDegIdx + 5;
        const octaveOffset = Math.floor(targetDegIdx / numDegrees);
        const semitoneFromRoot = degrees[targetDegIdx % numDegrees] + (octaveOffset * 12);
        targetNotes.push((octave * 12) + this.rootNote + Math.round(semitoneFromRoot));
        break;
      }

      case 'octave_up': {
        targetNotes.push(midiNote + 12);
        break;
      }

      case 'octave_down': {
        targetNotes.push(midiNote - 12);
        break;
      }

      case 'dual_3rd_oct': {
        // Горна терца + Октава едновременно (плътен балкански саунд!)
        const targetDegIdx = closestDegIdx + 2;
        const octaveOffset = Math.floor(targetDegIdx / numDegrees);
        const semitoneFromRoot = degrees[targetDegIdx % numDegrees] + (octaveOffset * 12);
        targetNotes.push((octave * 12) + this.rootNote + Math.round(semitoneFromRoot));
        targetNotes.push(midiNote + 12);
        break;
      }

      default:
        return null;
    }

    return targetNotes;
  }

  // Получаване на детюнинг в центове за дадена MIDI нота
  getDetuneCents(midiNote) {
    const pitchClass = midiNote % 12;
    return this.microtuning[pitchClass] || 0;
  }

  // Генериране на Korg SysEx съобщение за настройка на четвърт тонове
  generateKorgSysExTune() {
    // Korg Pa Sub-Scale SysEx (Octave tuning dump)
    // F0 42 30 [Channel] 4C [Scale] ... F7
    const sysex = [0xF0, 0x42, 0x30, 0x00, 0x4C];
    for (let i = 0; i < 12; i++) {
      // 64 е център (0 cents), 0 е -64 cents (-50 цента е приблизително 14)
      const val = this.microtuning[i] < 0 ? 14 : 64;
      sysex.push(val);
    }
    sysex.push(0xF7);
    return new Uint8Array(sysex);
  }
}

// Глобален експорт
window.EthnoHarmonizer = EthnoHarmonizer;
window.SCALES = SCALES;
window.NOTE_NAMES = NOTE_NAMES;
window.NOTE_NAMES_BG = NOTE_NAMES_BG;
