Toll POS Android project. Open in Android Studio and use Build > Generate APKs.
The supplied HTML is bundled as app/src/main/assets/index.html.
The HTML uses React/Tailwind/Google Fonts CDN resources, so internet access is required for those resources.
