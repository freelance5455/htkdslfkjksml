// 1. Go to https://console.firebase.google.com → create a project (free Spark plan is fine)
// 2. Add a Web App to the project, copy the config values it gives you below
// 3. Enable Firestore Database (Build > Firestore Database > Create database)
// 4. Enable Authentication > Sign-in method > Anonymous (this app signs each device in anonymously)
window.ZIPPY_FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};
