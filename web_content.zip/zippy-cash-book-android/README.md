# Zippy Cash Book — Android build

This is a Capacitor wrapper around the Zippy Cash Book web app, set up so it
runs as a standalone Android app with a real Firebase backend (Firestore) and
a native "Save to Drive" backup flow. This folder needs to be built on your
own machine — it needs Node.js and Android Studio, which aren't available in
this chat environment.

## Why a separate build from the in-chat version

The version you tested inside Claude uses Claude's own built-in data store,
which only works inside Claude's chat/artifact view. A standalone Android app
runs completely outside that environment, so it needs its own real backend —
that's what this folder wires up (Firebase Firestore, same document
structure, so the two versions store data compatibly).

## One-time setup

1. **Create a Firebase project** (free): https://console.firebase.google.com
   - Add a **Web App** to the project → copy the config object it shows you.
   - Paste those values into `www/firebase-config.js` (placeholders are marked).
   - In the Firebase console: **Build → Firestore Database → Create database**
     (start in production mode, pick a region close to Kenya, e.g. `europe-west1`).
   - In the Firebase console: **Build → Authentication → Sign-in method →
     enable Google.** Pick a support email when prompted.
   - Set Firestore security rules to only allow signed-in access, e.g.:
     ```
     rules_version = '2';
     service cloud.firestore {
       match /databases/{database}/documents {
         match /{document=**} {
           allow read, write: if request.auth != null;
         }
       }
     }
     ```

2. **Register the Android app in Firebase** so Google Sign-In works natively:
   - In the Firebase console, add an **Android app** to the project using
     the `appId` from `capacitor.config.json` (`com.heavensseed.zippycashbook`).
     You'll add its SHA-1 fingerprint and download its config file in step 5,
     once the native Android project exists.

3. **Install tools** (once, on your computer):
   - Node.js LTS: https://nodejs.org
   - Android Studio (includes the Android SDK): https://developer.android.com/studio

4. **Install project dependencies** — open a terminal in this folder:
   ```
   npm install
   npx cap add android
   npx cap sync android
   ```

5. **Finish the Google Sign-In wiring** (needs the `android/` folder from step 4):
   - Run `cd android && ./gradlew signingReport`, copy the `debug` variant's
     `SHA1` value, and add it to the Android app you registered in Firebase
     (step 2) — add the `release` SHA-1 too once you have a release keystore.
   - Download `google-services.json` from that Firebase Android app and place
     it at `android/app/google-services.json`.
   - In `android/build.gradle`, add to the `dependencies` block:
     `classpath 'com.google.gms:google-services:4.4.2'`
   - In `android/app/build.gradle`, add at the very bottom:
     `apply plugin: 'com.google.gms.google-services'`
   - Re-run `npx cap sync android`.

## Building the app

```
npx cap open android
```
This opens the project in Android Studio. From there:
- **Run ▶** on a connected phone/emulator to test it live.
- **Build → Generate Signed Bundle / APK** to produce an installable `.apk`
  (or `.aab` for the Play Store) you can share directly with your team.

## Backup behavior on Android

The Settings tab's "Export Backup" button writes the JSON backup file, then
opens Android's native **share sheet** — if the Google Drive app is
installed, "Save to Drive" appears there automatically, so backing up is a
two-tap action for the user. No Google OAuth setup is needed for this,
since it rides on the Drive app the person already has installed. If Drive
isn't installed, the share sheet still offers other apps (email, Files, etc.)
as a fallback.

## Updating the app later

Whenever you (or Claude) change `www/index.html`, re-run:
```
npx cap sync android
```
then rebuild from Android Studio.

## App icon

The `app-icon/` folder has the launcher icon already made:
- `ic_launcher_foreground.png` + `ic_launcher_background.png` — the two
  layers for Android's adaptive icon system.
- `play-store-icon-512.png` — the flattened 512×512 icon for the Play
  Store listing.

To wire it up (after `npx cap add android`): in Android Studio, right-click
`android/app/src/main/res` → **New → Image Asset** → Icon Type
**Launcher Icons (Adaptive and Legacy)** → set the Foreground and Background
layers to the two PNGs above. Studio generates all the density folders and
the legacy fallback for you.
