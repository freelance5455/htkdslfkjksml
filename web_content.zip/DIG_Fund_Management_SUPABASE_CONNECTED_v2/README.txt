D.I.G Fund Management – Ghazipur Unit
Supabase Connected v2 (WebView/APK compatible)

This version does NOT depend on the external supabase-js CDN. It uses the Supabase Auth REST and Data REST APIs directly, making it more reliable inside HTML-to-APK WebViews.

Project URL: https://igmjsmrcfppyenvkvqvx.supabase.co
Client key: publishable key only.

Do NOT put a Supabase secret/service_role key into the app.

First login requires internet. After login, cached data remains available offline; queued writes sync when the connection returns.
