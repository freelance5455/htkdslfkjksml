Carrom Practice Android Project

यह प्रोजेक्ट आपकी दी हुई index.html फ़ाइल को Android WebView ऐप में पैक करता है।
यह अभी APK नहीं है; APK बनाने के लिए Android Studio वाले कंप्यूटर की आवश्यकता होगी।

APK बनाने के आसान चरण:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में इस प्रोजेक्ट फ़ोल्डर को Open करें।
3. Gradle sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।
6. APK को अपने Android फोन में भेजें, खोलें और केवल भरोसेमंद स्रोत से आए APK को ही इंस्टॉल करें।

ध्यान दें:
- इस प्रोजेक्ट में केवल स्थानीय Carrom Practice बोर्ड है।
- यह Aim Carrom King नहीं है और किसी दूसरे गेम के ऊपर काम नहीं करता।
- ऑनलाइन APK builder पर अपना Google password या निजी खाते की जानकारी न दें।
