FAKEPAY DEMO - Android Studio Project

महत्वपूर्ण:
- यह केवल मनोरंजन/डेमो ऐप है।
- कोई वास्तविक UPI, बैंक, PhonePe या भुगतान सेवा से कनेक्शन नहीं है।
- स्क्रीन पर DEMO / NOT REAL MONEY पहचान हमेशा दिखाई देती है।
- इसे असली भुगतान का प्रमाण बताकर किसी को धोखा देने के लिए उपयोग न करें।

APK बनाने के चरण:
1. Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Open चुनकर FakePhonePeDemo फ़ोल्डर खोलें।
4. Gradle Sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/ में मिलेगा।

यह प्रोजेक्ट Android Studio में build करने के लिए source project है; इस ZIP में पहले से compiled APK शामिल नहीं है।
