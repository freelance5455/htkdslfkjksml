YKS SUPER SOFTWARE — Mobile Web App Starter

यह responsive web app starter है, जिसे Android फोन पर browser में खोला जा सकता है और static hosting पर publish किया जा सकता है। यह तैयार APK नहीं है।

शामिल काम करने वाले browser tools:
- Word / Character Counter
- Case Converter, Text Cleaner, Text Reverser
- Percentage, GST, Basic Calculator
- Age Calculator, Date Difference
- Password Generator, BMI estimate
- KM/Miles, Celsius/Fahrenheit converters
- Base64, URL Encoder/Decoder
- Lorem text, Quick Notes (browser local storage)
- QR code external service, Website opener

चलाने का आसान तरीका:
1. ZIP extract करें।
2. index.html को किसी static hosting service पर upload करें (जैसे GitHub Pages/Netlify आदि), या अपने web developer से publish करवाएँ।
3. PWA install/offline support के लिए इसे HTTPS hosting पर चलाना होगा। केवल file manager से index.html खोलने पर installable PWA behavior सीमित हो सकता है।
4. QR tool external QR service पर link भेजता है; sensitive/private links इस्तेमाल न करें।

महत्वपूर्ण:
- PDF merge/compress, image compression, OCR, document conversion जैसे advanced tools अभी शामिल नहीं हैं।
- वेबसाइट पर मौजूद Blogger posts अपने-आप इस app में sync नहीं होते; यह स्वतंत्र tool interface है।
- Play Store APK/AAB अलग Android build/signing प्रक्रिया से बनता है।
- Publish करने से पहले privacy policy, terms, branding, and tools thoroughly test करें।
