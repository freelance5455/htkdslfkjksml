SAHBAJ AI — Personal Android + HTML project

WHAT IS INCLUDED
- web/index.html: browser version.
- android/: Android Studio WebView wrapper.
- Firebase project configuration: ff-macro-b8d13 (Realtime Database + Email/Password Auth).
- firebase-database.rules.json: per-user private chat-history rules.

RUN HTML LOCALLY
1. Extract this ZIP on your phone/computer.
2. Open web/index.html in Chrome (internet is needed for Firebase, OpenRouter and JS/PDF libraries).
3. Sign up with your email/password.
4. Open Settings, paste a NEW OpenRouter API key, choose model openrouter/free, press Test API, then Save settings.

BUILD ANDROID APK
1. Open the android folder in Android Studio.
2. Wait for Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
This ZIP contains source code, not a prebuilt APK. Build has not been run in this environment.

FIREBASE SETUP REQUIRED ONCE
- In Firebase Console for ff-macro-b8d13, Authentication > Sign-in method > Email/Password must be enabled.
- Realtime Database must exist. Publish firebase-database.rules.json contents under Rules.
- The included rules only allow a signed-in user to read/write their own /users/<uid> branch.
- Firebase web API config is included in the HTML; it is a public client config, not an admin credential. Never put Firebase service-account credentials in this app.

OPENROUTER SETUP
- Create a NEW API key at https://openrouter.ai/keys. Do not use the key previously pasted into chat; revoke it because it was exposed.
- Paste the new key into Settings on your own device. It is stored in localStorage, not hard-coded in the source.
- The app sends prompts and selected file content/images to OpenRouter for AI processing. Chat text/history is saved in your Firebase Realtime Database.
- openrouter/free is a free-model router; model availability, vision support, rate limits and free quotas can change. If a free model rejects an image, select a free vision-capable model from https://openrouter.ai/models?max_price=0.

SUPPORTED INPUT
- Text/code files: HTML, CSS, JS, JSON, XML, Java, Kotlin, TXT, MD, Gradle and properties.
- ZIP: extracts common text/code files for analysis (not binary files).
- Images: sent as image input.
- PDF: extracts text from up to 15 pages. Scanned PDFs need OCR or page screenshots.
- Video: samples up to five frames; original audio/video is not sent.

LIMITATIONS AND SECURITY
- This is a personal-use client app. API key is stored locally on the device. Anyone who can access that device/app storage may be able to retrieve it. Do not share the APK with the key configured. A server proxy is required for a public/shared app.
- The app analyzes files and suggests corrected code; it does not yet automatically rewrite all uploaded source files into a rebuilt ZIP. Review AI-generated code before replacing project files.
- Internet is required for AI/Firebase/CDN resources.
- No live Firebase or OpenRouter test was possible here because a fresh private API key and Firebase console access are not available. Use Test API in Settings after entering the new key.
