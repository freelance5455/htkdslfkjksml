Simple Chat Web ZIP

ZIP to APK converter के लिए index.html ZIP के root में है।

जरूरी सेटअप:
1. Firebase Console में project और Realtime Database बनाएं।
2. Firebase project में Web App जोड़कर config लें।
3. index.html को text editor में खोलें और FIREBASE_CONFIG के सभी YOUR_* values बदलें। databaseURL अपने console से सही लें।
4. Realtime Database Rules में सुरक्षित authentication/authorization लगाएं। Test mode/public read-write इस्तेमाल न करें।
5. इस फोल्डर की index.html को ZIP करें (index.html ZIP के root में रहे), फिर ZIP to APK app में चुनें।
6. APK converter की WebView में internet access जरूरी है; कुछ converters module scripts या remote Firebase CDN को रोक सकते हैं।

ध्यान: यह prototype है। इसमें Firebase Authentication नहीं है। Room ID/Password अकेले access control नहीं है। संवेदनशील बातचीत के लिए वास्तविक user auth, room membership rules, validation और abuse protection जोड़ें।
