AI_OS_By_Rudra — Safe local prototype

Pydroid 3:
  pip install fastapi uvicorn
  python backend.py

ZIP-to-APK:
- index.html ZIP के root में है।
- WebSocket endpoint ws://127.0.0.1:5000/ws
- यह ZIP HTML WebView frontend और Python backend का local prototype है।

Private login:
- PRIME_PRIVATE_PASSWORD_SHA256 environment variable में अपने पासवर्ड का SHA-256 hash सेट करें।
- कोई default password शामिल नहीं है।

Video:
- media/clip_001.mp4 जैसे clips रखें।
- POST /video/join चलाने के लिए FFmpeg install/configure होना चाहिए।
- 15/30/60 मिनट के generation orchestration के लिए external video provider integration अभी बाकी है।

महत्वपूर्ण सीमाएँ:
- Arbitrary live Python/shell execution शामिल नहीं है।
- D.C. AI remote device control नहीं करता; केवल सुरक्षित demo placeholder है।
- floating.html का widget app के अंदर draggable UI है, system-wide overlay नहीं।
- Quick panel HTML panel है, Android Quick Settings tile नहीं।
- AccessibilityService, MediaProjection, WebRTC device control और native overlay के लिए native Android code और explicit user consent चाहिए।
- Swarm generation तथा Kling/LTX/Luma/Meshy APIs के लिए provider credentials और integration आवश्यक हैं।
