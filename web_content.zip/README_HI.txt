NAXURA AI — Starter PWA

WHAT THIS ZIP DOES
- Mobile-friendly NAXURA AI interface.
- Chat history stored locally in this browser/device.
- New chat and clear history.
- Image upload and camera capture.
- Video request form with a 1–60 minute project-duration setting.
- Voice input where the browser supports it.
- Installable PWA foundation (requires HTTPS hosting).

IMPORTANT LIMITATIONS
This is a FRONT-END STARTER, not a fully connected AI product.
It does NOT generate real AI chat answers, images, or videos yet.
Those features require a server-side backend and AI provider APIs.
The 60-minute value is only a project-duration setting. It does not mean
an AI provider can generate a single 60-minute clip. Never claim a file
was generated unless the provider actually returns one.

SECURITY
Do not put API keys in index.html or any browser JavaScript.
Connect APIs through server-side routes such as:
  POST /api/chat
  POST /api/image
  POST /api/video
Store provider keys as server-side environment secrets.
Do not publish a key in a public repository.

HOW TO TEST
1. Extract this ZIP.
2. Upload the files to a web host that serves HTTPS.
3. Open the HTTPS site in Chrome on Android.
4. Use Chrome menu > Install app / Add to Home screen.
5. To create an Android package, use PWABuilder with the published HTTPS URL.
   PWABuilder Android packaging needs a valid published PWA and HTTPS.
   See https://www.pwabuilder.com/ and
   https://github.com/pwa-builder/PWABuilder/blob/main/docs/builder/other-android.md

FREE AI OPTIONS
Gemini API has a limited free tier for certain models; check current limits:
https://ai.google.dev/gemini-api/docs/pricing
AI image/video generation may have separate limits or paid pricing.
