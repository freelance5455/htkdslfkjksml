भोगता समाज कल्याण Android ऐप - शुरुआती Android Studio प्रोजेक्ट

कैसे APK बनाएँ:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. Android Studio में Open चुनकर इस ZIP को Extract करने के बाद BhogtaSamaj फ़ोल्डर खोलें।
3. Gradle Sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

महत्वपूर्ण:
- यह प्रारंभिक ऑफलाइन संस्करण है। डेटा उसी मोबाइल में सेव होता है।
- अलग-अलग मोबाइलों के बीच डेटा साझा नहीं होता।
- UPI ID/QR अभी जानबूझकर placeholder रखा गया है; सही समिति UPI ID मिलने पर जोड़ें।
- ऐप में दान प्रविष्टि भुगतान की पुष्टि नहीं है। बैंक/UPI स्टेटमेंट से मिलान करें।
- Admin का शुरुआती पासवर्ड 123456 है। पहले उपयोग पर बदलें।
- यह स्थानीय डेमो लॉगिन है, सुरक्षित सर्वर-आधारित authentication नहीं।
- सार्वजनिक उपयोग से पहले backend, सुरक्षित admin login, backup, privacy policy और संस्था के बैंक/UPI विवरण जोड़ना जरूरी है।
