VISHAL LIVE CAMERA — Android APK SOURCE PROJECT

यह ZIP Android ऐप का source project है; इसमें पहले से बना हुआ APK शामिल नहीं है।
फोन से APK बनाने के लिए AndroidIDE जैसे Android Gradle IDE में ZIP extract/import करें और Gradle sync/build APK चलाएँ। AndroidIDE/Gradle/SDK संस्करण के अनुसार build configuration समायोजित करनी पड़ सकती है।

जरूरी सेटअप:
1) Signaling server को किसी भरोसेमंद hosting पर Node.js के साथ deploy करें।
2) Server को TLS/HTTPS के पीछे चलाएँ ताकि WebSocket URL wss:// हो। साधारण ws:// सार्वजनिक इंटरनेट पर इस्तेमाल न करें।
3) दोनों Android ऐप में वही wss:// server URL डालें।
4) पहले फोन पर कैमरा चालू करें और 6 अंकों का कोड दूसरे फोन में डालें।

सीमाएँ और सुरक्षा:
- दोनों फोन के मालिकों की जानकारी और अनुमति जरूरी है।
- यह ऐप कैमरा चालू होने पर स्पष्ट रूप से दिखाता है; छिपकर निगरानी नहीं करता।
- फोन पूरी तरह बंद होने पर कैमरा नहीं चल सकता।
- Android/निर्माता स्क्रीन लॉक या बैकग्राउंड में कैमरा रोक सकते हैं। इस डेमो में लॉक स्क्रीन पर लगातार कैमरा चलने की गारंटी नहीं है।
- इंटरनेट, TLS signaling server और आम तौर पर STUN/TURN नेटवर्क सहायता जरूरी होती है। इस starter में STUN है; कुछ नेटवर्कों पर TURN server भी जोड़ना होगा।
- सार्वजनिक उपयोग से पहले signaling server में authentication, rate limiting, मजबूत random room tokens और security review जोड़ें।
- यह starter project है, production-ready या Play Store verified ऐप नहीं।
