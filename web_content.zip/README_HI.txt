NANHE STEPS – नन्हे कदम

यह एक शुरुआती मोबाइल वेब ऐप (PWA prototype) है, APK नहीं।

फोन पर चलाने के लिए:
1. ZIP को Extract करें।
2. Nanhe_Steps folder के अंदर की सभी files एक ही folder में रखें।
3. Acode में उसी folder से index.html खोलें।
4. Preview / Open in Browser से चलाएँ।
5. app.js को Run JavaScript से अलग से न चलाएँ।

मुख्य सुविधाएँ:
- हिंदी / English भाषा बदलना
- ABC, हिंदी अक्षर, गिनती, रंग, आकार, जानवर, फल और छोटी क्विज़
- Listen बटन (फोन/browser की speech सुविधा पर निर्भर)

ध्यान दें: यह demo है। अभी इसमें APK build, user accounts, ads, payment या cloud backup नहीं है।
