Ghar Ka Khana — Green Edition (V3)

Files:
- index.html: customer food-ordering demo
- app-icon.png: supplied Ghar Ka Khana logo (512x512)

APK builder steps:
1. Upload ZIP or extract index.html and app-icon.png if the builder asks for separate files.
2. App name: Ghar Ka Khana
3. Set app-icon.png as the launcher icon in the builder settings.
4. Build APK and test it.

Important: menu, cart and orders are local demo features. Real payments require a merchant payment gateway integration; payment buttons alone do not collect money. The Customer Care number in the HTML is the number previously supplied and appears to have 9 digits; confirm the correct 10-digit number before publishing.
