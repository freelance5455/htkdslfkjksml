DAYFLOW PRO WEBSITE

Pages:
- index.html      Overview dashboard
- tasks.html      Daily repeat checklist
- calendar.html   Calendar and past-day records
- habits.html     Daily habit tracker
- analytics.html  Weekly progress insights
- settings.html   Task template and data backup

HOW TO USE:
1. Extract the ZIP.
2. Open index.html in a browser, or upload the full folder to a static hosting service.
3. Keep the assets folder beside all HTML files.
4. Data is stored in browser localStorage on the same device/browser.
5. This is a multi-page website; use the sidebar navigation to switch pages.

NOTE:
This version stores data locally in the browser. It does not sync between devices and is not an online account system.
