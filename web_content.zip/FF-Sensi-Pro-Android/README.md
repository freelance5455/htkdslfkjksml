# FF Sensi Pro - Android project

A real Android app (WebView + native code). The whole app UI is `app/src/main/assets/index.html`.

## What the native part does
- **Asks for the notification permission on the first launch** (Android 13+).
- **Notification bar messages**: every ~6 hours the app reads your `version.json` and shows a notification when
  - a new version is available (`versionCode` is higher than the installed one), or
  - you publish a news message (change `notifyId`, set `noticeTitle` / `noticeMessage`).
- Native AdMob banner at the bottom. App ID ca-app-pub-1524545934747329~8903249225 is in AndroidManifest.xml, ad unit ca-app-pub-1524545934747329/3678385857 is in Config.java (debug builds use Google's test banner).
- Share Card sends the picture to WhatsApp, Facebook and so on (native share sheet).
- Copy buttons use the Android clipboard. Links open the YouTube app or browser. Back button works.
- Permissions used: INTERNET, ACCESS_NETWORK_STATE, POST_NOTIFICATIONS, VIBRATE.

## Build the APK without a computer (GitHub, free)
1. Create a free GitHub account and a new repository (for example `ff-sensi`).
2. Upload the contents of this folder (including the hidden `.github` folder) to the repository.
3. Open the **Actions** tab, choose **Build APK**, tap **Run workflow**.
4. When it finishes, open the run and download the **FF-Sensi-Pro-APK** file, unzip it, install `app-debug.apk`.

## Build with Android Studio
Open this folder in Android Studio, wait for Gradle sync, then Build > Build APK(s).

## Notifications for updates
1. Turn on GitHub Pages for the repository (Settings > Pages) and put `docs/version.json` there.
2. In `app/src/main/java/com/ffsensi/pro/Config.java` set `UPDATE_URL` to the public link of that file.
3. Whenever you release a new version: raise `versionCode` in `app/build.gradle` and in `version.json`.
4. To send a news notification: change `notifyId` to a new value and edit `noticeTitle` / `noticeMessage`.

## Before Google Play
- Debug APKs are signed with a debug key. For Google Play you need a release keystore and an AAB (Build > Generate Signed Bundle).
- Add a privacy policy page and the Ads declaration in Play Console.
- Change `applicationId` in `app/build.gradle` if `com.ffsensi.pro` is taken.

## Important
This project was written without being compiled or run on a device. If the build shows an error, send the error text and it can be fixed.
