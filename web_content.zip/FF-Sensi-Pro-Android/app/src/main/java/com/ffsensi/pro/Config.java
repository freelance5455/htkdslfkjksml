package com.ffsensi.pro;

public class Config {
    /** Put your own link here (see README). Example: https://yourname.github.io/ff-sensi/version.json */
    public static final String UPDATE_URL = "https://YOUR-USERNAME.github.io/ff-sensi/version.json";
    /** Your AdMob ad unit ID (replaces the earlier 5239336386 unit). */
    public static final String BANNER_ID = "ca-app-pub-1524545934747329/3678385857";
    /** Google's official test banner: used in debug builds so you never click your own live ads. */
    public static final String TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111";
}
