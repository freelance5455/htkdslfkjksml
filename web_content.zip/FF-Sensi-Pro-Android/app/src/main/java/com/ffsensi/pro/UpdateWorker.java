package com.ffsensi.pro;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.core.content.pm.PackageInfoCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** Checks version.json every few hours and shows a notification for a new version or a news message. */
public class UpdateWorker extends Worker {

    public UpdateWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        try {
            if (Config.UPDATE_URL.contains("YOUR-")) return Result.success();
            HttpURLConnection con = (HttpURLConnection) new URL(Config.UPDATE_URL).openConnection();
            con.setConnectTimeout(10000);
            con.setReadTimeout(10000);
            BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            JSONObject j = new JSONObject(sb.toString());
            SharedPreferences sp = ctx.getSharedPreferences("upd", Context.MODE_PRIVATE);

            long cur = PackageInfoCompat.getLongVersionCode(ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0));
            long latest = j.optLong("versionCode", 0);
            if (latest > cur && sp.getLong("notifiedVersion", 0) < latest) {
                NotificationHelper.show(ctx, 1001,
                        j.optString("title", "Update available"),
                        j.optString("message", "A new version of FF Sensi Pro is ready."),
                        j.optString("url", ""));
                sp.edit().putLong("notifiedVersion", latest).apply();
            }

            String nid = j.optString("notifyId", "");
            if (!nid.isEmpty() && !nid.equals(sp.getString("notifyId", ""))) {
                NotificationHelper.show(ctx, 1002,
                        j.optString("noticeTitle", "FF Sensi Pro"),
                        j.optString("noticeMessage", ""),
                        j.optString("noticeUrl", ""));
                sp.edit().putString("notifyId", nid).apply();
            }
        } catch (Exception ignored) {
        }
        return Result.success();
    }
}
