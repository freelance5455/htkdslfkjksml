@echo off
setlocal
cd /d "%~dp0"

echo ========================================
echo   Urenoverzicht - Android APK bouwen
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo FOUT: Node.js is niet gevonden. Installeer eerst Node.js LTS.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo FOUT: npm is niet gevonden. Installeer Node.js opnieuw.
  pause
  exit /b 1
)

echo [1/4] Dependencies installeren...
call npm install
if errorlevel 1 goto :error

if not exist "android\settings.gradle" (
  echo [2/4] Android-project aanmaken...
  call npx cap add android
  if errorlevel 1 goto :error
) else (
  echo [2/4] Bestaand Android-project gevonden.
)

echo [3/4] App-iconen genereren en project synchroniseren...
call npm run icons
if errorlevel 1 goto :error
call npx cap sync android
if errorlevel 1 goto :error

echo [4/4] Debug-APK bouwen...
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto :error

 echo.
echo APK succesvol gebouwd:
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
start "" "%CD%\app\build\outputs\apk\debug"
pause
exit /b 0

:error
echo.
echo Er is iets misgegaan. Controleer de foutmelding hierboven.
echo Benodigd: Android Studio met Android SDK en een werkende internetverbinding.
pause
exit /b 1
