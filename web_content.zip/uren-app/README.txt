URENOVERZICHT - ANDROID APP BOUWEN
==================================
Vereist: Node.js (nodejs.org) en Android Studio (developer.android.com/studio)

Open een terminal in deze map en voer uit:

  1. npm install
  2. npx cap add android
  3. npm run icons        (zet het van Berkom-logo als app-icoon)
  4. npx cap sync android
  5. npx cap open android

In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
De APK staat daarna in android/app/build/outputs/apk/debug/
Zet hem op je telefoon en installeer (toestemming "onbekende bronnen" nodig).

Na een wijziging in www/index.html: npx cap sync android en opnieuw bouwen.

OPSLAG
Gegevens worden opgeslagen in de native Android-opslag (Preferences) en
ook in localStorage. Ze blijven bewaard na het sluiten van de app.
Let op: gegevens wissen via Android-instellingen of de app verwijderen
wist ook de uren. Maak dus nog steeds af en toe een back-up
(die opent nu het deel-menu zodat je hem kunt opslaan of mailen).
