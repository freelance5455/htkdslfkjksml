URENOVERZICHT - ANDROID APK BOUWEN
==================================

Deze map bevat de Urenoverzicht-app als Capacitor-project.

BENODIGD
--------
- Een Windows-pc
- Node.js LTS: https://nodejs.org/
- Android Studio: https://developer.android.com/studio
- In Android Studio moet de Android SDK geïnstalleerd zijn.
- Internetverbinding tijdens de eerste build (npm/Gradle downloads).

SNELSTE MANIER (WINDOWS)
-----------------------
1. Pak deze volledige map uit op je pc.
2. Installeer Node.js LTS en Android Studio.
3. Open Android Studio minstens één keer en voltooi de SDK-installatie.
4. Dubbelklik op build-apk-windows.bat in deze map.
5. Wacht tot de build klaar is.

De APK wordt aangemaakt op:
android\app\build\outputs\apk\debug\app-debug.apk

HANDMATIG
---------
Open een terminal in deze map en voer uit:

  npm install
  npx cap add android
  npm run icons
  npx cap sync android
  cd android
  gradlew.bat assembleDebug

Als de Android-map al bestaat, sla dan 'npx cap add android' over.

INSTALLEREN
-----------
Kopieer app-debug.apk naar je Android-telefoon en open het bestand.
Android kan vragen om installatie vanuit deze bron toe te staan.

APP-GEGEVENS
------------
De app gebruikt Capacitor Preferences en localStorage voor lokale opslag.
Verwijderen van de app of wissen van de appgegevens kan opgeslagen uren wissen.
Maak daarom regelmatig een back-up.

APP-INSTELLINGEN
----------------
Naam: Urenoverzicht
Application ID: nl.vanberkom.urenoverzicht
