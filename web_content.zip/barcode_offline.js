(function(){
  const C39={"0":"101001101101","1":"110100101011","2":"101100101011","3":"110110010101","4":"101001101011","5":"110100110101","6":"101100110101","7":"101001011011","8":"110100101101","9":"101100101101","A":"110101001011","B":"101101001011","C":"110110100101","D":"101011001011","E":"110101100101","F":"101101100101","G":"101010011011","H":"110101001101","I":"101101001101","J":"101011001101","K":"110101010011","L":"101101010011","M":"110110101001","N":"101011010011","O":"110101101001","P":"101101101001","Q":"101010110011","R":"110101011001","S":"101101011001","T":"101011011001","U":"110010101011","V":"100110101011","W":"110011010101","X":"100101101011","Y":"110010110101","Z":"100110110101","-":"100101011011",".":"110010101101"," ":"100110101101","$":"100100100101","/":"100100101001","+":"100101001001","%":"101001001001","*":"100101101101"};
  const L=["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"], G=["0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"], R=["1110010","1100110","1101100","1000010","1011100","1001110","1010000","1000100","1001000","1110100"];
  const PAR=["LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"];
  function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');}
  function ean13(v){
    v=String(v).replace(/\D/g,''); if(v.length===12) v+=check(v); if(v.length!==13) throw Error('EAN-13 требует 12 или 13 цифр');
    let p=PAR[+v[0]], bits='101'; for(let i=1;i<=6;i++) bits+=(p[i-1]=='L'?L:R)[+v[i]]; for(let i=7;i<=12;i++) bits+=R[+v[i]]; return bits+'101';
  }
  function check(v){let s=0; for(let i=0;i<v.length;i++) s+=(+v[i])*(i%2?3:1); return (10-s%10)%10;}
  function ean8(v){v=String(v).replace(/\D/g,''); if(v.length===7)v+=check(v); if(v.length!==8)throw Error('EAN-8 требует 7 или 8 цифр'); let b='101'; for(let i=0;i<4;i++)b+=L[+v[i]]; b+='01010'; for(let i=4;i<8;i++)b+=R[+v[i]]; return b+'101';}
  function code39(v){v=String(v).toUpperCase(); if(!/^[0-9A-Z. \-$/+%]+$/.test(v))throw Error('CODE39: недопустимые символы'); return ('*'+v+'*').split('').map((c)=>C39[c]).join('0');}
  function render(el,bits,opts,text){
    const width=opts.width||2,h=opts.height||100,margin=opts.margin??10, show=opts.displayValue!==false;
    const total=bits.length*width+margin*2, svgW=total, svgH=h+(show?24:0)+margin*2;
    let x=margin, rect=''; for(const b of bits){if(b==='1')rect+=`<rect x="${x}" y="${margin}" width="${width}" height="${h}" fill="${opts.lineColor||'#000'}/>`;x+=width;}
    let t=show?`<text x="${svgW/2}" y="${margin+h+18}" text-anchor="middle" font-family="Arial" font-size="14" fill="${opts.lineColor||'#000'}">${esc(text)}</text>`:'';
    el.setAttribute('viewBox',`0 0 ${svgW} ${svgH}`); el.setAttribute('width',svgW); el.setAttribute('height',svgH); el.innerHTML=`<rect width="100%" height="100%" fill="${opts.background||'#fff'}"/>${rect}${t}`;
  }
  window.JsBarcode=function(target,value,opts){
    const el=typeof target==='string'?document.querySelector(target):target; opts=opts||{}; let fmt=(opts.format||'auto').toUpperCase(),bits,text=String(value);
    try{
      if(fmt==='EAN13'||fmt==='EAN-13'||fmt==='UPC') {if(fmt==='UPC'){text='0'+text; bits=ean13(text);}else bits=ean13(text);}
      else if(fmt==='EAN8'||fmt==='EAN-8') bits=ean8(text);
      else if(fmt==='CODE39') bits=code39(text).replace(/^/,'').replace(/\*$/,'');
      else { // offline fallback: Code39-compatible visual for formats not implemented in this embedded build
        bits=code39(text.replace(/[^0-9A-Z. \-$/+%]/gi,'')).replace(/^/,'').replace(/\*$/,'');
      }
      render(el,bits,opts,text); if(opts.valid)opts.valid(true);
    }catch(e){if(opts.valid)opts.valid(false); throw e;}
  };
})();
