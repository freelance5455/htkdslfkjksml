Serve this folder over local HTTP. No server-side application code is required.
