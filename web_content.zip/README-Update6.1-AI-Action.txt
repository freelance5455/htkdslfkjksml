CLICKER UNIVERSE — UPDATE 6.1 AI ACTION COMPANION

Files:
- clicker_universe.html: Owner version (Admin Panel included)
- clicker_universe_brother.html: Brother version (no Admin Panel)

AI Companion improvements:
- Conversational local/offline helper (still scripted, not connected to real ChatGPT)
- Can grant coins: "dai 500 coins", "coins inf"
- Can grant gems/diamonds: "dai 30 diamanti"
- Can perform clicks: "clicca 100" (also a Click x10 quick button)
- Auto-click toggle button and natural-language activation/deactivation
- Boss attack action and stats response

Note: A truly general ChatGPT that understands any question requires a secure online backend/API. Do not put API keys in the HTML file.
Open the HTML file in a browser to play. Progress is saved locally in the browser/device.
