ACC V15 – requested report printing and two-action backup update

Changes to the supplied ACC V14 project:
- Monthly report now has one visible action: Print report. It prepares the selected report view and calls window.print().
- Backup & restore now has exactly two visible actions: Backup data and Restore data.
- Backup serializes the complete ACC data object to a JSON file and opens Android's file share sheet when supported. Choose Google Drive in that sheet to save the file. If file sharing is unavailable, the app attempts a normal download.
- Restore opens the system file picker and reads a selected ACC JSON file. If Google Drive is offered as a file source, select the saved backup there. Restore replaces current app data after confirmation.
- Existing data schema and other app sections are preserved. Service worker cache version was changed.

IMPORTANT LIMITATIONS (cannot be fixed by HTML alone):
Direct upload to Google Drive without showing a share sheet requires Google OAuth consent and a configured Google Cloud OAuth client / Drive API integration. No OAuth client credentials or Drive connection were supplied. Therefore Backup data prepares the file and asks the user to choose Google Drive in Android's share sheet; it does not silently upload directly.

The Android system print screen can open only if the APK builder's WebView implements Android WebView printing (native PrintDocumentAdapter integration). This ZIP calls window.print() for the report but cannot add that native Android bridge. If the builder lacks WebView print support, open the app in Chrome to use the Android print dialog.

Test backup and restore with test data before using real records. Keep the original ZIP and an independent backup.
