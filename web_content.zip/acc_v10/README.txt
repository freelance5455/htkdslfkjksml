ACC V15 – embedded WebView compatibility patch

Based on the supplied ACC_V15_print_drive_backup.zip.

Changes:
- Monthly report Print report now generates the report PDF and opens the PDF blob in a separate viewer tab/window. It no longer relies only on window.print(), which was silently ignored by the user's APK WebView. If popups are blocked, a visible Open / save monthly report PDF link is inserted into the report screen.
- Backup data first attempts the Android/Web Share API with the JSON file, allowing the user to choose Google Drive where available. If file sharing is unavailable, it copies the full JSON backup to the clipboard; if clipboard access is unavailable, it displays a copyable text fallback.
- Restore data opens the JSON file picker. If that cannot be opened, it offers a paste-JSON fallback. Restoring replaces current app data only after confirmation.

Important platform limitation:
This is still an HTML app packaged by a third-party APK builder. The supplied project does not contain a native Android bridge, Google OAuth configuration, Drive API credentials, or native PrintDocumentAdapter. Therefore it cannot silently upload directly to Google Drive or force-open Android's native print service from HTML alone. The app now provides a PDF file/viewer path and Google Drive share/copy paths that do not falsely claim direct integration. Test on the target APK before entering real financial data.
