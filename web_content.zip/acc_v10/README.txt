ACC V11 – Dashboard and Reports / Backup Update

Changes in this update:
- Removed the Dashboard Customize button and its drag/resize editor. Dashboard sections now use the normal responsive layout to avoid overlap and clipping.
- Added an Account mode selector to Monthly Report: All accounts, Cash, or Bank.
- Print / Save PDF now calls the phone/browser print function from the current report, rather than opening a separate print webpage. Choose the phone's print service and then Save as PDF if available.
- Backup downloads an ACC JSON file named ACC-backup-YYYY-MM-DD.json. On Android Chrome, it normally appears in the Downloads folder; if Chrome asks where to save, choose a folder there.
- Restore uses the phone's file picker and FileReader to read the selected ACC JSON backup. Select the file from Downloads, then tap Restore selected backup.

The package preserves the existing local storage key and data schema. Back up your records before updating. Restore replaces current records, so keep a separate backup copy.

This is a PWA source package, not an APK. Update the files on the same hosting location used by the current ACC installation. The backup/download and print behavior still depends on the browser or Android webview permissions and should be tested on the target phone.
