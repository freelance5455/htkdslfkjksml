ACC V10 – Professional Header and Dashboard Layout Controls

This update enlarges the profile icon and welcome text and reduces unused space above the dashboard header. It adds a Customize button to the dashboard. In Customize mode, use each section's Move handle to drag the main dashboard sections into a new order, and use the corner handle to resize a section. Tap Done to save the layout on this phone.

Movable/resizable sections: profile header, financial date range, balance summary, account cards, quick-entry actions, budget summary, and transaction area. Layout preferences are stored locally in this browser and do not alter transaction data.

The package preserves ACC's existing app data storage key. Back up your records before updating. This is a PWA source package, not an APK. Update the files on the same hosting location used by your current ACC installation.
