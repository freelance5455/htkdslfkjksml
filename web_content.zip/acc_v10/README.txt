ACC V14 – Android WebView backup, restore, export and compact dashboard update

Changes:
- Reduced dashboard total-balance number to a responsive 22–24 CSS px range.
- Reduced dashboard income/expense figures to 13px and Cash/Bank balances to 15px.
- Backup now prepares a JSON copy and first attempts Android file sharing when the Web Share API supports files. If the APK does not provide file saving/sharing, the JSON is shown in a copyable text area and a download link is provided as a fallback.
- Restore supports both a selected JSON file and pasted backup JSON. The file picker is now a direct visible label/input interaction rather than relying only on a scripted click on a hidden input.
- CSV export uses the same share/download fallback path.
- Monthly report PDF remains generated from the selected date range and account mode. It attempts the Android share sheet when supported and provides a visible PDF download link.
- Service worker cache version bumped so updated files are not kept behind an old cached copy.

Important Android APK builder limitation:
An HTML-only project cannot add Android's native DownloadManager, file chooser implementation, or PrintDocumentAdapter by itself. The APK builder's WebView must expose a file chooser callback (WebChromeClient.onShowFileChooser), a download listener (setDownloadListener), and, for native printing, Android print bridge support. If these are absent, the app now exposes copy/paste and visible link fallbacks instead of pretending the action succeeded. Test the rebuilt APK on the target phone.

Update steps:
1. Back up existing ACC records before installing.
2. Import this ZIP into HTML to APK Builder – ZIP APK and build a new APK.
3. Install the new APK using the same package identity/signing setup if updating an existing app.
4. Test Save backup, Choose backup file, Restore selected backup, Restore pasted backup, CSV export, and Monthly report PDF.

The localStorage data key and data schema are preserved. Restore replaces current records, so retain a separate backup copy.


V14 typography update:
- Total balance reduced to 20px.
- Dashboard income/expense figures reduced to 11px.
- Cash/Bank balances reduced to 13px.
- Transaction amounts reduced to 12px.
- Service worker cache version bumped to refresh the new styling.
