PANCHAL BUSINESS MANAGER v3 — Mobile-first offline ERP prototype

FILES
- index.html, styles.css, app.js: app source
- manifest.webmanifest, sw.js: installable PWA/offline cache support

HOW TO USE ON ANDROID
1. Extract this ZIP on your phone.
2. Open index.html in Chrome for a basic preview. Some browsers restrict local-file features.
3. For install + offline caching, host the folder on a free HTTPS static host (for example GitHub Pages) or use a free local web server app. HTTPS hosting needs internet for first load; afterwards cached app shell works offline.
4. Export a JSON backup regularly from Settings & Backup.

CURRENT MODULES
Dashboard, Quotations (separate), Invoices (separate), Purchase, Inventory/Items, Customers & Suppliers, Income/Expenses, Projects/Work Orders, Staff, Attendance, Salary/Advances, Reports, Multiple business profiles, JSON backup/restore.

IMPORTANT LIMITATIONS
This is an early working prototype, not a production accounting package and not a certified GST application.
- GST is only simple percentage calculation; no HSN/SAC, place-of-supply, tax ledger, GST return, e-invoice or e-way bill.
- Stock quantities are opening figures only; sales/purchase lines are not yet linked to stock movements.
- Accounting double-entry ledger, bank reconciliation, receivables/payables ageing, audit trail and proper P&L are not implemented.
- Staff login/permissions, encrypted backup, customer signature capture and biometric security are not implemented.
- Each device stores its own data. Manual JSON export/import is needed to move data; no automatic sync.
- PDF export uses the Android/Chrome print dialog: open document preview → Print / Save PDF → select “Save as PDF” in the system print screen. Direct silent PDF download is not supported by the browser.
- Voice entry is not yet implemented.
- Never store sensitive real customer or employee data until security controls are added.
All source code and assets in this package are self-contained and use no paid libraries or subscription.


VERSION 6 NOTES
- Party can be typed directly while creating a quotation, invoice or purchase. On save, it is added/updated in the Party directory; case-insensitive duplicates are merged.
- Document preview offers WhatsApp text share, Android/Web Share (HTML document where supported), HTML download, and Print / Save as PDF.
- IMPORTANT APK limitation: HTML alone cannot force a WebView APK to expose Android native file chooser, DownloadManager, FileProvider or print framework. Native PDF attachment sharing requires the APK builder to implement Android bridge/intents. WhatsApp fallback sends document text; it does NOT attach a PDF. For PDF, use Print / Save PDF, save it on the phone, then attach it in WhatsApp.
- Tested JavaScript syntax and project structure; actual APK Forge device behavior must still be tested in the generated APK.
