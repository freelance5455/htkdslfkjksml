WINAMP XP ANDROID – KÉTFÜLES PROJEKT

Funkciók:
- Winamp XP stílusú helyi zenelejátszó és hangszínszabályzó
- Android natív fájlválasztó, több hangfájl kiválasztásával
- Külön INTERNET RÁDIÓ fül: Radio Browser adatbázis keresése, stream lejátszása
- A helyi zenék offline működnek; az internetes rádióhoz internet kell.

FONTOS: Ez Android Studio projektforrás, nem telepíthető APK. APK készítéséhez Android SDK/Gradle build szükséges.
Android 13+ alatt az ACTION_OPEN_DOCUMENT fájlválasztó nem kér külön teljes tárhelyengedélyt; a felhasználó által kiválasztott fájlhoz ad hozzáférést.


FÁJLVÁLASZTÓ JAVÍTÁS
A + ADD gomb az Android natív fájlválasztóját nyitja meg az AndroidBridge.pickAudio() hívással. Több hangfájl egyszerre is kiválasztható. A kiválasztott fájlok URI-ja és neve visszakerül a lejátszási listába.
