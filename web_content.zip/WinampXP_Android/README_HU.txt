WINAMP XP – NATÍV ANDROID PROJEKT

Ez egy Android Studio projekt, amely a Winamp XP offline lejátszót natív Android alkalmazásba csomagolja.
A program a kezelőfelületet és a lejátszást a telefonon, helyben futtatja; internetet nem igényel.

APK készítése:
1. Telepítsd a számítógépre az Android Studio-t.
2. Csomagold ki a WinampXP_Android.zip fájlt.
3. Android Studio > Open > válaszd ki a WinampXP_Android mappát.
4. Várd meg a Gradle szinkronizálását (ehhez első alkalommal internet kellhet a fejlesztői gépen).
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Az APK helye: app/build/outputs/apk/debug/app-debug.apk
7. Másold át a telefonra, nyisd meg, és engedélyezd az ismeretlen alkalmazásból telepítést, ha kéri.

A telefonra telepített alkalmazás internet nélkül használható. Zenéket az ADD gombbal választhatsz ki.
A zenelejátszás képernyő lezárásakor/ háttérben való folytatása ebben az első verzióban Android-verziótól függhet.
