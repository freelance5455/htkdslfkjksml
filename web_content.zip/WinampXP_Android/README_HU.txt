WINAMP XP – JAVÍTOTT ANDROID PROJEKT

Ez a ZIP a javított Android Studio projekt forráskódját tartalmazza, nem kész APK-t.
A módosítások: natív Android zenefájl-választó (ACTION_OPEN_DOCUMENT), több fájl kiválasztása, WebView fájlválasztó callback, ADD gomb aktiválása, Android target SDK 34.

A projektből még APK-t kell építeni; a forráskód önmagában nem telepíthető.
