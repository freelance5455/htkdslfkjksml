package hu.winampxp.player;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.content.ContentResolver;
import android.view.Window;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int FILE_CHOOSER = 1001;
    private boolean pickerInProgress = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff25237d);
        getWindow().setNavigationBarColor(0xff171727);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        webView.setBackgroundColor(0xff25237d);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    /** Ezt hívja meg a JavaScript a + ADD gomb megnyomásakor. */
    private class AndroidBridge {
        @JavascriptInterface
        public void pickAudio() {
            runOnUiThread(() -> openAudioPicker());
        }
    }

    private void openAudioPicker() {
        if (pickerInProgress || isFinishing()) return;
        pickerInProgress = true;

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

        try {
            startActivityForResult(intent, FILE_CHOOSER);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                fallback.addCategory(Intent.CATEGORY_OPENABLE);
                fallback.setType("audio/*");
                fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(fallback, "Zenék kiválasztása"), FILE_CHOOSER);
            } catch (Exception ignored) {
                pickerInProgress = false;
                sendSelection(new JSONArray());
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER) return;

        pickerInProgress = false;
        JSONArray selectedFiles = new JSONArray();
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                for (int i = 0; i < count; i++) {
                    Uri uri = data.getClipData().getItemAt(i).getUri();
                    addSelectedFile(selectedFiles, uri, data.getFlags());
                }
            } else if (data.getData() != null) {
                addSelectedFile(selectedFiles, data.getData(), data.getFlags());
            }
        }
        sendSelection(selectedFiles);
    }

    private void addSelectedFile(JSONArray files, Uri uri, int intentFlags) {
        if (uri == null) return;
        try {
            int takeFlags = intentFlags & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (takeFlags != 0) {
                try { getContentResolver().takePersistableUriPermission(uri, takeFlags); }
                catch (Exception ignored) { /* Egyes szolgáltatók nem támogatják a tartós engedélyt. */ }
            }

            String name = getFileName(uri);
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = "audio/*";

            JSONObject item = new JSONObject();
            item.put("name", name);
            item.put("uri", uri.toString());
            item.put("type", mime);
            files.put(item);
        } catch (Exception ignored) { }
    }

    private String getFileName(Uri uri) {
        String result = "Zene";
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index >= 0) result = cursor.getString(index);
                }
            } catch (Exception ignored) { }
        }
        if (result == null || result.trim().isEmpty()) result = "Zene";
        return result;
    }

    private void sendSelection(JSONArray files) {
        if (webView == null) return;
        String script = "if(window.onAudioSelected){window.onAudioSelected(" + files.toString() + ");}";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
