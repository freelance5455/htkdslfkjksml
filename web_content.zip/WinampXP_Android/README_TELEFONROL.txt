WINAMP XP – APK KÉSZÍTÉSE CSAK ANDROIDOS TELEFONRÓL

A projektben van egy GitHub Actions munkafolyamat, amely a GitHub felhős gépén elkészíti az APK-t.
Saját számítógép és Android Studio nem kell. GitHub-fiók szükséges.

1. Nyisd meg a github.com oldalt a telefon böngészőjében, és jelentkezz be / hozz létre ingyenes fiókot.
2. Hozz létre egy új, Public repository-t, például WinampXP néven.
3. A telefonon csomagold ki a ZIP-et egy fájlkezelővel.
4. A GitHub új repository oldalán válaszd az Add file > Upload files lehetőséget.
5. Töltsd fel a kicsomagolt WinampXP_Android mappa TARTALMÁT (a .github mappát is beleértve), majd Commit changes.
   Fontos: a build.gradle, settings.gradle és app mappa közvetlenül a repository gyökerében legyen.
6. Nyisd meg a repository Actions fülét. Válaszd a Build Winamp XP APK munkafolyamatot.
7. Nyomd meg a Run workflow gombot, majd várd meg, amíg zöld pipát kapsz.
8. Nyisd meg a sikeres futást, görgess az Artifacts részhez, és töltsd le a WinampXP-Android-APK csomagot.
9. Csomagold ki a letöltött ZIP-et. Benne lesz az app-debug.apk.
10. Nyisd meg az APK-t, és ha a telefon kéri, engedélyezd a böngészőnek/fájlkezelőnek az ismeretlen alkalmazások telepítését.

A GitHub Actions futtatása és az artifact letöltése a GitHub aktuális ingyenes kereteitől függ.
A telepített lejátszó offline használatra készült. A GitHubra feltöltött projekt nyilvános lesz,
ezért személyes adatot ne tegyél bele.
