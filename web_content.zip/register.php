<?php
session_start(); require_once __DIR__ . '/includes.php';
if (is_logged_in()) { header('Location: dashboard.php'); exit; }
$error = ''; $name = ''; $email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? ''));
  $password = $_POST['password'] ?? ''; $confirm = $_POST['confirm'] ?? '';
  if (!csrf_valid()) $error = 'Сессия формы устарела. Обновите страницу и попробуйте снова.';
  elseif (mb_strlen($name) < 2 || mb_strlen($name) > 50) $error = 'Имя должно содержать от 2 до 50 символов.';
  elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'Введите корректный email.';
  elseif (strlen($password) < 8) $error = 'Пароль должен быть не короче 8 символов.';
  elseif ($password !== $confirm) $error = 'Пароли не совпадают.';
  else {
    $users = users_read(); $exists = false;
    foreach ($users as $u) if (strtolower($u['email']) === $email) { $exists = true; break; }
    if ($exists) $error = 'Аккаунт с таким email уже существует.';
    else {
      $users[] = ['id' => bin2hex(random_bytes(8)), 'name' => $name, 'email' => $email, 'password' => password_hash($password, PASSWORD_DEFAULT), 'created_at' => date('c')];
      if (users_write($users)) { session_regenerate_id(true); $_SESSION['user'] = ['name'=>$name, 'email'=>$email]; header('Location: dashboard.php'); exit; }
      $error = 'Не удалось сохранить аккаунт. Проверьте права на папку data.';
    }
  }
}
$pageTitle = 'Регистрация'; include __DIR__ . '/header.php';
?>
<section class="auth-wrap"><div class="auth-aside"><div class="eyebrow">НАЧНИ СЕЙЧАС</div><h1>Создай свой<br>аккаунт.</h1><p>Всего пара шагов — и личный кабинет готов.</p><div class="aside-note">Без лишних сложностей. Только нужное.</div></div>
<div class="auth-card"><h2>Регистрация</h2><p class="muted">Заполни данные ниже</p>
<?php if ($error): ?><div class="alert"><?= h($error) ?></div><?php endif; ?>
<form method="post" autocomplete="on"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
<label>Имя<input name="name" value="<?= h($name) ?>" required minlength="2" maxlength="50" placeholder="Как тебя зовут?"></label>
<label>Email<input type="email" name="email" value="<?= h($email) ?>" required placeholder="you@example.com"></label>
<label>Пароль<input type="password" name="password" required minlength="8" placeholder="Минимум 8 символов" autocomplete="new-password"></label>
<label>Повтори пароль<input type="password" name="confirm" required minlength="8" placeholder="Ещё раз пароль" autocomplete="new-password"></label>
<button class="btn primary full" type="submit">Создать аккаунт <span>→</span></button></form>
<div class="auth-switch">Уже зарегистрирован? <a href="login.php">Войти</a></div></div></section>
<?php include __DIR__ . '/footer.php'; ?>