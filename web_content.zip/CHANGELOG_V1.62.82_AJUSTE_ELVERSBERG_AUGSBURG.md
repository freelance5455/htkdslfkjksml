# Carreira de Craque v1.62.82 — Ajuste de escudos

- SV Elversberg: removido o aumento especial que deixava o escudo maior que os demais; voltou ao tamanho padrão dos escudos na tabela.
- FC Augsburg: removida a grande margem transparente do arquivo e centralizado o escudo em uma tela transparente, mantendo proporção e cores. Agora ocupa o espaço visual equivalente aos demais escudos.
- Hamburger SV e demais escudos preservados.
- Nenhuma alteração em sistemas, elencos, calendário ou saves.
