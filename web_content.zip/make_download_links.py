import shutil

shutil.copy('traffic_light_app_source_code.zip', 'public/traffic_light_app_source_code.zip')
shutil.copy('public/download.html', 'public/download')
print("Static download files copied to public directory!")
