const { contextBridge, ipcRenderer } = require('electron');
const inv = (c, ...a) => ipcRenderer.invoke(c, ...a);
contextBridge.exposeInMainWorld('gcApi', {
  sync: (url, payload) => inv('gc:sync', url, payload),
  serverStart: (port, token) => inv('gc:serverStart', port, token),
  serverStop: () => inv('gc:serverStop'),
  serverStatus: () => inv('gc:serverStatus'),
  saveBackup: o => inv('gc:saveBackup', o),
  version: () => inv('gc:version'),
  updateGet: () => inv('gc:updateGet'),
  updateSet: u => inv('gc:updateSet', u),
  updateCheck: () => inv('gc:updateCheck'),
  onUpdate: cb => ipcRenderer.on('gc:update', (e, s) => cb(s)),
  fsGet: () => inv('gc:fsGet'),
  fsSet: v => inv('gc:fsSet', v),
  fsToggle: () => inv('gc:fsToggle'),
  onFs: cb => ipcRenderer.on('gc:fs', (e, v) => cb(v))
});
