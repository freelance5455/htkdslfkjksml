const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getPath: (name) => ipcRenderer.invoke('app:get-path', name),
  writeFile: (filePath, data) => ipcRenderer.invoke('fs:write-file', { filePath, data }),
  platform: process.platform,
});
