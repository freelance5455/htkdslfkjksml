# ANONYMOUX STUDIO 2.4.6

This build adds the requested theme-aware dashboard background, responsive admin-console hardening, transparent logo/favicon assets, and a shared Fish Audio voice picker across Voice Studio and Voice Agent Studio.

See `DEEP-AUDIT-AND-IMPLEMENTATION-REPORT-2.4.6.md` for the audit, change list, verification results, configuration requirements, and deployment limitations.

No database migration is required. Preserve the existing `config.local.php`, live database, and private `storage/` directory during deployment. Enable PHP cURL and OpenSSL and configure Fish Audio credentials before testing voice library/agent features.
