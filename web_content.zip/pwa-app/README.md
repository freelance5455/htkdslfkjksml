# Mi App Web (PWA)

Esta carpeta es una **app web instalable** (PWA) que muestra tu página dentro
de la app. Funciona en Android, iPhone y PC, y se puede convertir en `.apk`
firmado sin escribir código.

## 1) Personalizar

- **URL de tu web** → editá `config.js`
- **Nombre de la app** → editá `manifest.json` (`name`, `short_name`) y el
  `<title>` en `index.html`
- **Ícono** → reemplazá `icons/icon-192.png` y `icons/icon-512.png` por tu logo
  (mismo tamaño en píxeles)
- **Color** → `theme_color` en `manifest.json`

## 2) Publicarla (gratis, sin servidor propio)

Necesitás subir estos archivos a un hosting con HTTPS. Opciones gratis:

- **Netlify** (netlify.com): arrastrás la carpeta y listo, te da una URL.
- **Vercel** (vercel.com): igual de simple.
- **GitHub Pages**: subís la carpeta a un repo y activás Pages.

Una vez publicada, cualquiera puede entrar desde el celular y tocar
"Agregar a pantalla de inicio" / "Instalar app" — se comporta como una app
nativa, con ícono propio y sin barra del navegador.

## 3) Convertirla en .apk firmado (opcional, gratis)

Si además querés un `.apk` para subir a Google Play o compartir por WhatsApp:

1. Andá a **https://www.pwabuilder.com**
2. Pegá la URL donde publicaste tu PWA (paso 2)
3. Elegí **Android**
4. Descargá el paquete: viene con `.apk`/`.aab` ya firmado y listo para instalar
   (PWABuilder genera y guarda el keystore automáticamente).

Esta es la forma más simple: no instalás Android Studio ni tocás código.

## ¿Diferencia con el proyecto Android nativo?

| | PWA (esta carpeta) | Proyecto Android nativo |
|---|---|---|
| Requiere hosting propio | Sí (gratis) | No |
| Se instala en el celular | Sí | Sí |
| Funciona offline (básico) | Sí | Sí |
| Convertible a .apk firmado | Sí, vía PWABuilder | Ya lo es |
| Requiere Android Studio | No | Sí (o PWABuilder) |
