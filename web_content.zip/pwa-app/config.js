// 👉 Cambia esto por la URL de tu página web
const SITE_URL = "https://www.tu-pagina-web.com";
