# Sense Generator V3 — Android bridge starter

## Import and build
1. Install Android Studio (official): https://developer.android.com/studio
2. Open this project folder (`SenseGeneratorAndroid`) in Android Studio.
3. Allow Gradle sync / install SDK Platform 35 if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location when finished.

## What is included
- WebView wrapper and JavaScript bridge (`Android` object)
- Android VPN authorization request via `VpnService.prepare()`
- Demo `VpnService` that creates a local TUN interface without routes/DNS (does not tunnel internet traffic)
- Shortcut to Developer Options for user to enable Wireless debugging themselves

## JavaScript bridge
- `Android.requestVpnPermission()`
- `Android.startDemoVpn()`
- `Android.stopVpn()`
- `Android.openWirelessDebugSettings()`
- `Android.openVpnSettings()`
- `Android.showToast('message')`

## Integrating your full original HTML
Replace `app/src/main/assets/index.html` with your complete HTML file. Keep the Android bridge calls above for the native buttons. The code pasted in the chat was truncated in the PHONE_LIST section, so this starter does not include all your original generator screens.

## Important limitations
This VPN is a demonstration interface only: it establishes a local VPN TUN device but does not route traffic, connect to a VPN provider/server, or change gameplay/network settings. ADB cannot be granted via an ordinary permission prompt; Wireless debugging must be enabled by the device owner in Android settings.
