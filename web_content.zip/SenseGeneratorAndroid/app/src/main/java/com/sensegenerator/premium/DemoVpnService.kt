package com.sensegenerator.premium

import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.content.Intent
import java.io.IOException

/** Demonstration-only VPN: creates a local TUN interface but routes no internet traffic. */
class DemoVpnService : VpnService() {
    private var tunnel: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startDemo()
            ACTION_STOP -> stopDemo()
        }
        return START_NOT_STICKY
    }

    private fun startDemo() {
        if (tunnel != null) return
        try {
            tunnel = Builder()
                .setSession("Sense Generator Demo VPN")
                .addAddress("10.10.0.2", 32)
                .setMtu(1500)
                // Deliberately no routes or DNS: this is NOT a traffic tunnel.
                .establish()
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun stopDemo() {
        try { tunnel?.close() } catch (_: IOException) { }
        tunnel = null
        stopSelf()
    }

    override fun onDestroy() {
        try { tunnel?.close() } catch (_: IOException) { }
        tunnel = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.sensegenerator.premium.VPN_START"
        const val ACTION_STOP = "com.sensegenerator.premium.VPN_STOP"
    }
}
