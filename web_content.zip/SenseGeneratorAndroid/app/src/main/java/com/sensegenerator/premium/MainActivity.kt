package com.sensegenerator.premium

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val vpnRequestCode = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @android.webkit.JavascriptInterface
        fun requestVpnPermission() {
            runOnUiThread {
                val intent = VpnService.prepare(this@MainActivity)
                if (intent != null) startActivityForResult(intent, vpnRequestCode)
                else Toast.makeText(this@MainActivity, "VPN já autorizada. Você pode iniciar.", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun startDemoVpn() {
            runOnUiThread {
                val permissionIntent = VpnService.prepare(this@MainActivity)
                if (permissionIntent != null) {
                    startActivityForResult(permissionIntent, vpnRequestCode)
                    Toast.makeText(this@MainActivity, "Autorize a VPN na tela do Android e toque em iniciar novamente.", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, DemoVpnService::class.java).setAction(DemoVpnService.ACTION_START))
                    web.evaluateJavascript("vpnStatus('Iniciando VPN demonstrativa…')", null)
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopVpn() {
            runOnUiThread {
                startService(Intent(this@MainActivity, DemoVpnService::class.java).setAction(DemoVpnService.ACTION_STOP))
                web.evaluateJavascript("vpnStatus('VPN desconectada')", null)
            }
        }

        @android.webkit.JavascriptInterface
        fun openWirelessDebugSettings() {
            runOnUiThread {
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                Toast.makeText(this@MainActivity, "Nas opções do desenvolvedor, procure Depuração sem fio.", Toast.LENGTH_LONG).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun openVpnSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }
        }

        @android.webkit.JavascriptInterface
        fun showToast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(150), Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "Autorização VPN concedida. Toque em iniciar VPN.", Toast.LENGTH_LONG).show()
                web.evaluateJavascript("vpnStatus('Autorização concedida — VPN ainda não iniciada')", null)
            } else {
                Toast.makeText(this, "Autorização VPN cancelada", Toast.LENGTH_SHORT).show()
                web.evaluateJavascript("vpnStatus('Autorização não concedida')", null)
            }
        }
    }
}
