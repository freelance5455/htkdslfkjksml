
/* My Shop v8.5 — Supabase cloud integration layer.
   Uses only the public anon key. No service-role key is included.
*/
(function(){
  const C=window.MYSHOP_CONFIG||{};
  if(!C.supabaseUrl||!C.supabaseAnonKey)return;
  let client=null, syncing=false, booted=false;
  const oldSave=window.save;
  const oldLogout=window.clearCurrentAccount;
  function ensureClient(){
    if(client||!window.supabase?.createClient)return client;
    client=window.supabase.createClient(C.supabaseUrl,C.supabaseAnonKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}});
    return client;
  }
  function normPhone(v){
    let p=String(v||"").replace(/\s|-/g,"").trim();
    if(p.startsWith("+92")) p="0"+p.slice(3);
    else if(p.startsWith("0092")) p="0"+p.slice(4);
    p=p.replace(/[^0-9]/g,"");
    return p;
  }
  function authAliases(phone){
    const p=normPhone(phone), digits=p.replace(/[^0-9]/g,"");
    const out=[p,digits];
    if(p.startsWith("0")&&p.length===11) out.push("92"+p.slice(1),"+92"+p.slice(1));
    return [...new Set(out)];
  }
  function authEmail(phone){return normPhone(phone).replace(/[^0-9]/g,"")+"@auth.myshop.local"}
  async function uploadDataUrl(data,path){
    if(!data||!data.startsWith("data:")||!client)return null;
    try{
      const [head,b64]=data.split(",");
      const mime=(head.match(/data:([^;]+)/)||[])[1]||"audio/webm";
      const bytes=Uint8Array.from(atob(b64),c=>c.charCodeAt(0));
      const blob=new Blob([bytes],{type:mime});
      const {error}=await client.storage.from("myshop-files").upload(path,blob,{contentType:mime,upsert:true});
      if(error)throw error;
      const {data:pub}=client.storage.from("myshop-files").getPublicUrl(path);
      return pub?.publicUrl||null;
    }catch(e){console.warn("voice upload failed",e);return null}
  }
  async function getShop(){
    const u=(await client.auth.getUser()).data.user;
    const {data,error}=await client.from("profiles").select("shop_id,full_name,phone,role").eq("id",u?.id).single();
    if(error||!data?.shop_id)return null;
    return data;
  }
  function localSale(x,voice){return {id:x.id,stockId:x.stockId,date:x.date,product:x.product,category:x.category,amount:x.amount,cost:x.cost,customer:x.customer,phone:x.phone,cnic:x.cnic,condition:x.condition,payment:x.payment,desc:x.desc,voice:voice||x.voice||"",imei:x.imei||""}}

  function encodeDebtRecord(x){
    return "__MYSHOP_DEBT_V2__"+JSON.stringify({desc:x.desc||x.description||"",original:Number(x.original||x.balance||0),date:x.date||null,history:Array.isArray(x.history)?x.history:[],statusOverride:x.statusOverride||null});
  }
  function decodeDebtRecord(v){
    if(typeof v!=="string")return null;
    if(!v.startsWith("__MYSHOP_DEBT_V2__"))return null;
    try{return JSON.parse(v.slice("__MYSHOP_DEBT_V2__".length))||null}catch(e){return null}
  }
  async function cloudSync(){
    if(!client||!S?.user||syncing)return;
    syncing=true;
    try{
      const profile=await getShop(); if(!profile?.shop_id) return;
      const sid=profile.shop_id;
      // Upload voice notes first and replace data URLs with storage URLs.
      for(const type of ["sales","purchases","expenses"]){
        for(const r of (S.records[type]||[])){
          if(r.voice?.startsWith("data:")){
            const url=await uploadDataUrl(r.voice,`${sid}/voice/${type}/${r.id}.webm`);
            if(url)r.voice=url;
          }
        }
      }
      await client.from("sales").delete().eq("shop_id",sid);
      await client.from("purchases").delete().eq("shop_id",sid);
      await client.from("expenses").delete().eq("shop_id",sid);
      await client.from("stock").delete().eq("shop_id",sid);
      await client.from("receivables").delete().eq("shop_id",sid);
      await client.from("payables").delete().eq("shop_id",sid);
      const sales=(S.records.sales||[]).map(x=>({shop_id:sid,sale_date:x.date,product:x.product,category:x.category,amount:Number(x.amount||0),cost:Number(x.cost||0),customer_name:x.customer_name||x.customer||"",phone:x.phone||"",cnic:x.cnic||"",condition:x.condition||"",payment_method:x.payment_method||x.payment||"",description:x.description||x.desc||"",voice_url:x.voice_url||x.voice||null,imei:x.imei||null}));
      const purchases=(S.records.purchases||[]).map(x=>({shop_id:sid,purchase_date:x.date,product:x.product,category:x.category,amount:Number(x.amount||0),quantity:Number(x.quantity||1),supplier:x.supplier||"",imei:x.imei||"",owner_name:x.owner||x.owner_name||"",cnic:x.cnic||"",condition:x.condition||"",description:x.description||x.desc||"",voice_url:x.voice_url||x.voice||null}));
      const expenses=(S.records.expenses||[]).map(x=>({shop_id:sid,expense_date:x.date,name:x.name,amount:Number(x.amount||0),description:x.description||x.desc||"",voice_url:x.voice_url||x.voice||null}));
      const stock=(S.records.stock||[]).map(x=>({shop_id:sid,category:x.category||"used",product:x.product||"",quantity:Number(x.qty??x.quantity??1),purchase_cost:Number(x.cost??x.purchase_cost??0),sale_price:Number(x.sale??x.sale_price??0),imei:x.imei||null,condition:x.condition||null,available:x.available!==false}));
      const recv=(S.records.receivables||[]).map(x=>({shop_id:sid,name:x.name||"",phone:x.phone||"",balance:Number(x.balance||0),status:x.status||"",description:encodeDebtRecord(x)}));
      const pay=(S.records.payables||[]).map(x=>({shop_id:sid,name:x.name||"",phone:x.phone||"",balance:Number(x.balance||0),status:x.status||"",description:encodeDebtRecord(x)}));
      if(sales.length)await client.from("sales").insert(sales);
      if(purchases.length)await client.from("purchases").insert(purchases);
      if(expenses.length)await client.from("expenses").insert(expenses);
      if(stock.length)await client.from("stock").insert(stock);
      if(recv.length)await client.from("receivables").insert(recv);
      if(pay.length)await client.from("payables").insert(pay);
      const {data:cloudSub}=await client.from("subscriptions").select("shop_id").eq("shop_id",sid).maybeSingle();
      if(!cloudSub)await client.from("subscriptions").insert({shop_id:sid,status:S.subscription.status||"trial",trial_started_at:S.subscription.trialStart||new Date().toISOString(),active_until:S.subscription.activeUntil||null});
    }catch(e){console.warn("Cloud sync:",e)}
    finally{syncing=false}
  }
  function makeBackupPayload(){
    return {
      app:"My Shop",
      version:11.5,
      exportedAt:new Date().toISOString(),
      user:S.user,
      settings:S.settings,
      subscription:S.subscription,
      records:S.records,
      payments:S.payments||[],
      lastDate:S.lastDate,
      dateAuto:S.dateAuto!==false
    };
  }
  async function saveAccountBackup(){
    if(!client||!S?.user)return false;
    try{
      const payload=makeBackupPayload();
      const {error}=await client.auth.updateUser({data:{myshop_backup:payload,myshop_backup_at:new Date().toISOString()}});
      if(error)throw error;
      return true;
    }catch(e){console.warn("Account backup save:",e);return false}
  }
  function restoreAccountBackup(user){
    try{
      const payload=user?.user_metadata?.myshop_backup;
      if(!payload||payload.app!=="My Shop"||!payload.records||!payload.settings)return false;
      S=mergeState({...S,settings:payload.settings,subscription:payload.subscription||S.subscription,records:payload.records,payments:Array.isArray(payload.payments)?payload.payments:S.payments,lastDate:payload.lastDate||S.lastDate,dateAuto:payload.dateAuto!==false,user:S.user});
      ensureStockIntegrity();
      ensureDebtIntegrity();
      return true;
    }catch(e){console.warn("Account backup restore:",e);return false}
  }
  async function cloudBackup(){
    const c=ensureClient();
    if(!c)return toast("Cloud backup is not available");
    try{
      const {data:{user},error}=await c.auth.getUser();
      if(error||!user)return toast("Please log in first");
      const profile=await getShop();
      if(!profile?.shop_id)return toast("Shop account is not ready");
      // First sync the structured records, then attach a complete snapshot to the
      // authenticated user's account metadata. No SQL/table/bucket changes required.
      await cloudSync();
      const ok=await saveAccountBackup();
      if(ok){
        toast("Backup created successfully");
        return true;
      }
      toast("Backup could not be created. Please try again.");
      return false;
    }catch(e){
      console.warn("Cloud backup:",e);
      toast("Backup failed. Please try again.");
      return false;
    }
  }

  async function loadCloud(){
    const profile=await getShop(); if(!profile?.shop_id)return false;
    const sid=profile.shop_id;
    const [sa,pu,ex,st,re,pa,sub]=await Promise.all([
      client.from("sales").select("*").eq("shop_id",sid),
      client.from("purchases").select("*").eq("shop_id",sid),
      client.from("expenses").select("*").eq("shop_id",sid),
      client.from("stock").select("*").eq("shop_id",sid),
      client.from("receivables").select("*").eq("shop_id",sid),
      client.from("payables").select("*").eq("shop_id",sid),
      client.from("subscriptions").select("*").eq("shop_id",sid).single()
    ]);
    if(sa.data)S.records.sales=sa.data.map(x=>({id:x.id,date:x.sale_date,product:x.product,category:x.category,amount:Number(x.amount||0),cost:Number(x.cost||0),customer:x.customer_name,phone:x.phone,cnic:x.cnic,condition:x.condition,payment:x.payment_method,desc:x.description,voice:x.voice_url,imei:x.imei}));
    if(pu.data)S.records.purchases=pu.data.map(x=>({id:x.id,date:x.purchase_date,product:x.product,category:x.category,amount:Number(x.amount||0),quantity:Number(x.quantity||1),supplier:x.supplier,imei:x.imei,owner:x.owner_name,cnic:x.cnic,condition:x.condition,desc:x.description,voice:x.voice_url}));
    if(ex.data)S.records.expenses=ex.data.map(x=>({id:x.id,date:x.expense_date,name:x.name,amount:Number(x.amount||0),desc:x.description,voice:x.voice_url}));
    if(st.data)S.records.stock=st.data.map(x=>({id:x.id,category:x.category,product:x.product,qty:Number(x.quantity||1),cost:Number(x.purchase_cost||0),sale:Number(x.sale_price||0),imei:x.imei,condition:x.condition,available:x.available}));
    if(re.data)S.records.receivables=re.data.map(x=>{const d=decodeDebtRecord(x.description);return {id:x.id,name:x.name,phone:x.phone,balance:Number(x.balance||0),status:x.status,desc:d?.desc||(!d?x.description||"":""),original:d?.original??Number(x.balance||0),date:d?.date||null,history:d?.history||[{date:todayISO(),type:"Opening",amount:Number(x.balance||0),source:"system"}],statusOverride:d?.statusOverride||null};});
    if(pa.data)S.records.payables=pa.data.map(x=>{const d=decodeDebtRecord(x.description);return {id:x.id,name:x.name,phone:x.phone,balance:Number(x.balance||0),status:x.status,desc:d?.desc||(!d?x.description||"":""),original:d?.original??Number(x.balance||0),date:d?.date||null,history:d?.history||[{date:todayISO(),type:"Opening",amount:Number(x.balance||0),source:"system"}],statusOverride:d?.statusOverride||null};});
    if(typeof ensureDebtIntegrity==="function")ensureDebtIntegrity();
    if(sub.data){S.subscription={...S.subscription,trialStart:sub.data.trial_started_at,activeUntil:sub.data.active_until,status:sub.data.status};}
    S.user={name:profile.full_name||"",phone:normPhone(profile.phone||""),role:profile.role||"shopkeeper",isAdmin:profile.role==="admin"};
    const authUser=(await client.auth.getUser()).data.user;
    // Restore account-level settings/history snapshot when present. The structured
    // cloud tables remain the source of truth for current records, so an old backup
    // cannot overwrite newer cloud records during ordinary login.
    if(authUser?.user_metadata?.myshop_backup){
      const payload=authUser.user_metadata.myshop_backup;
      if(payload?.app==="My Shop"&&payload?.settings){
        S.settings=payload.settings||S.settings;
        S.subscription=payload.subscription||S.subscription;
        S.payments=Array.isArray(payload.payments)?payload.payments:S.payments;
        S.lastDate=payload.lastDate||S.lastDate;
        S.dateAuto=payload.dateAuto!==false;
        ensureStockIntegrity();
        ensureDebtIntegrity();
      }
    }
    localSave();
    return true;
  }
  const localSave=oldSave;
  window.save=function(){localSave(); if(booted)cloudSync()};
  async function loginCloud(){
    const p=normPhone(document.getElementById("lphone")?.value), pass=document.getElementById("lpass")?.value;
    if(!p||!pass)return toast("Enter phone and password");
    const c=ensureClient(); if(!c)return;
    let ok=false, lastError=null;
    for(const alias of authAliases(p)){
      const {error}=await c.auth.signInWithPassword({email:authEmail(alias),password:pass});
      if(!error){ok=true;break;}
      lastError=error;
    }
    // If this phone/password already exists in the old local app but not in Supabase,
    // migrate that account to Supabase automatically on its first cloud login.
    if(!ok){
      try{
        const users=JSON.parse(localStorage.getItem("myshop_users")||"[]");
        const local=users.find(x=>normPhone(x.phone)===p && x.pass===pass);
        if(local){
          const {data,error}=await c.auth.signUp({
            email:authEmail(p),password:pass,
            options:{data:{full_name:local.name||"",shop_name:local.shopName||"My Shop",phone:p}}
          });
          if(!error && data?.session) ok=true;
          else if(error?.message?.toLowerCase().includes("already registered")){
            const r=await c.auth.signInWithPassword({email:authEmail(p),password:pass});
            ok=!r.error; lastError=r.error||lastError;
          } else if(error) lastError=error;
          else if(!data?.session){
            return toast("Cloud account created. In Supabase Authentication → Providers → Email, turn OFF Confirm email, then login again.");
          }
        }
      }catch(e){lastError=e}
    }
    if(!ok)return toast(lastError?.message||"Invalid phone or password. Create the account once using Create Account.");
    const loaded=await loadCloud();
    if(!loaded)return toast("Login succeeded, but your shop profile was not created. Please contact the app admin.");
    await c.rpc("claim_admin_by_phone");
    await loadCloud();
    closeModal();page="home";render();
  }
  async function signupCloud(){
    const name=document.getElementById("s_name")?.value.trim(),phone=normPhone(document.getElementById("s_phone")?.value),pass=document.getElementById("s_pass")?.value,shop=(document.getElementById("s_shop")?.value||"My Shop").trim();
    if(!name||!phone||pass.length<4)return toast("Enter name, phone and 4+ character password");
    const c=ensureClient(); if(!c)return;
    const email=authEmail(phone);
    const {data,error}=await c.auth.signUp({email,password:pass,options:{data:{full_name:name,shop_name:shop,phone}}});
    if(error)return toast(error.message||"Account creation failed");
    if(!data.session)return toast("Account created. Please turn OFF Confirm email in Supabase Authentication → Providers → Email, then login again.");
    const loaded=await loadCloud();
    if(!loaded)return toast("Account created, but the shop profile could not be loaded.");
    await c.rpc("claim_admin_by_phone"); await loadCloud(); closeModal();render();
  }
  async function logoutCloud(){
    try{await client?.auth.signOut()}catch{}
    oldLogout(); render();
  }
  async function submitPaymentCloud(){
    if(!S.user)return toast("Please log in");
    const profile=await getShop(); if(!profile?.shop_id)return toast("Shop account not ready");
    const tx=document.getElementById("pay_tx")?.value.trim(); if(!tx)return toast("Enter transaction ID");
    const method=document.getElementById("pay_method")?.value||"EasyPaisa";
    const img=document.getElementById("pay_img")?.files?.[0];
    let path=null;
    if(img){
      try{
        path=`${profile.shop_id}/payments/${Date.now()}-${img.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
        const up=await client.storage.from("myshop-files").upload(path,img,{upsert:true});
        if(up.error)throw up.error;
      }catch(e){return toast("Screenshot upload failed")}
    }
    const {error}=await client.from("payments").insert({shop_id:profile.shop_id,method,transaction_id:tx,screenshot_path:path,amount:699,status:"pending"});
    if(error)return toast(error.message||"Payment submission failed");
    toast("Payment submitted for approval");
  }
  async function submitTestPaymentCloud(tx){
    try{
      const {data:{user}}=await client.auth.getUser();
      if(!user)return toast("Please login first");
      const {data:profile,error:pe}=await client.from("profiles").select("shop_id").eq("id",user.id).single();
      if(pe||!profile?.shop_id)return toast(pe?.message||"Shop profile not found");
      const {error}=await client.from("payments").insert({
        shop_id:profile.shop_id,
        method:"TEST",
        transaction_id:tx||("TEST-"+Date.now()),
        screenshot_path:null,
        amount:0,
        status:"pending"
      });
      if(error)return toast(error.message||"Test payment submission failed");
      S.payments=S.payments||[];
      save();
      toast("Test payment submitted — no money was charged");
      render();
    }catch(e){toast(e.message||"Test payment failed")}
  }

  async function refreshSubscription(){
    if(!client)return;
    const profile=await getShop();if(!profile)return;
    const sid=profile.shop_id;
    const [{data:sub},{data:pay}]=await Promise.all([
      client.from("subscriptions").select("*").eq("shop_id",sid).single(),
      client.from("payments").select("*").eq("shop_id",sid).order("submitted_at",{ascending:false}).limit(1).maybeSingle()
    ]);
    if(sub)S.subscription={
      ...S.subscription,
      trialStart:sub.trial_started_at,
      activeUntil:sub.active_until,
      status:sub.status,
      activatedAt:sub.updated_at||null
    };
    if(pay){
      S.subscription.paymentStatus=pay.status||"";
      S.subscription.paymentMethod=pay.method||"";
      S.subscription.paymentTx=pay.transaction_id||"";
    }else{
      S.subscription.paymentStatus="";
      S.subscription.paymentMethod="";
      S.subscription.paymentTx="";
    }
    localSave();
    if(modal==="subscription")render();
  }
  async function adminPage(){
    if(!client)return `<main class="content"><section class="card"><h2>Admin unavailable</h2></section></main>`;
    const {data:payments}=await client.from("payments").select("*").order("submitted_at",{ascending:false});
    const rows=payments||[];
    return `<main class="content"><section class="card"><h2>Admin Panel</h2><p class="muted">Payment approvals</p>${rows.length?rows.map(p=>`<div class="card" style="margin:10px 0"><b>${esc(p.method)}</b> — Rs. ${esc(p.amount)}<br>TX: ${esc(p.transaction_id||"")}<br>Status: <b>${esc(p.status)}</b><br><small>${esc(p.submitted_at||"")}</small>${p.status==="pending"?`<div style="display:flex;gap:8px;margin-top:10px"><button class="btn primary" onclick="adminApprove('${p.id}')">Approve 30 Days</button><button class="btn soft" onclick="adminReject('${p.id}')">Reject</button></div>`:""}</div>`).join(""):"<p>No payment requests.</p>"}</section></main>`;
  }
  window.cloudBackup=cloudBackup;
  window.refreshSubscription=refreshSubscription;
  window.adminApprove=async id=>{const {error}=await client.rpc("approve_payment",{payment_uuid:id});if(error)return toast(error.message);toast("Payment approved — 30 days active");render()};
  window.adminReject=async id=>{const note=prompt("Reason (optional):")||null;const {error}=await client.rpc("reject_payment",{payment_uuid:id,note});if(error)return toast(error.message);toast("Payment rejected");render()};
  const oldMore=window.morePage;
  window.morePage=function(){
    let base=oldMore?oldMore():"";
    if(S.user&&(S.user.isAdmin||normPhone(S.user.phone)===normPhone(C.adminPhone)))return base.replace("</main>",`<section class="card" onclick="page='admin';render()"><h3>Admin Panel</h3><p>Approve subscription payments</p></section></main>`);
    return base;
  };
  const oldPageView=window.pageView;
  function adminLoading(){
    setTimeout(async()=>{
      const host=document.getElementById("adminPageHost");
      if(!host||page!=="admin")return;
      try{
        host.outerHTML=await adminPage();
        if(window.applyUrdu)window.applyUrdu();
      }catch(e){
        console.warn("Admin panel load:",e);
        host.outerHTML='<main id="adminPageHost" class="content"><section class="card"><h2>Admin Panel</h2><p class="muted">Unable to load payment requests. Please try again.</p></section></main>';
      }
    },0);
    return '<main id="adminPageHost" class="content"><section class="card"><h2>Admin Panel</h2><p class="muted">Loading payment requests…</p></section></main>';
  }
  window.pageView=function(){if(page==="admin")return adminLoading();return oldPageView()};
  const oldDoLogin=window.doLogin,oldSignup=window.signup;
  window.doLogin=loginCloud; window.signup=signupCloud; window.clearCurrentAccount=logoutCloud; window.submitPayment=submitPaymentCloud; window.submitTestPaymentCloud=submitTestPaymentCloud;
  async function boot(){
    const c=ensureClient(); if(!c)return;
    const {data}=await c.auth.getSession();
    if(data.session){
      try{await c.rpc("claim_admin_by_phone");await loadCloud();booted=true;render()}catch(e){console.warn(e)}
    }
    c.auth.onAuthStateChange((event,session)=>{if(event==="SIGNED_OUT"){booted=false;return} if(session&&!S.user)loadCloud().then(()=>{booted=true;render()})});
  }
  window.addEventListener("load",()=>setTimeout(boot,100));
})();
