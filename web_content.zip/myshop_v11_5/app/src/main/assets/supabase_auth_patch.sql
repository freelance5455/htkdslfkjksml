-- My Shop v8.6 authentication patch
-- Run this AFTER the main My Shop schema already installed.
-- No Twilio/SMS/WhatsApp OTP is required.

create or replace function public.claim_admin_by_phone()
returns boolean
language plpgsql
security definer
set search_path=public
as $$
begin
  if not exists (
    select 1 from public.profiles
    where id=auth.uid()
      and phone='03020890766'
  ) then
    return false;
  end if;

  update public.profiles
  set role='admin'
  where id=auth.uid()
    and phone='03020890766';

  return true;
end
$$;

-- Prevent a normal shopkeeper from promoting their own profile to admin.
drop policy if exists profiles_self on public.profiles;
drop policy if exists profiles_select_self on public.profiles;
drop policy if exists profiles_update_self on public.profiles;
drop policy if exists profiles_insert_self on public.profiles;

create policy profiles_select_self
on public.profiles
for select
using (
  id=auth.uid()
  or public.is_admin()
);

create policy profiles_update_self
on public.profiles
for update
using (
  id=auth.uid()
  or public.is_admin()
)
with check (
  public.is_admin()
  or (id=auth.uid() and role='shopkeeper')
);
