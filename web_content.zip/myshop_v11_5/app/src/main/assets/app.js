/* My Shop — final hardened local-first build.
   Account data is isolated per phone number. Optional Supabase config remains supported.
*/
const KEY="myshop_v1";
const USERS_KEY="myshop_users";
const CURRENT_KEY="myshop_current_user";
const defaultState={
 user:null,
 settings:{shopName:"My Shop",theme:"royal",font:"medium",lang:"en",layout:1,locationMode:"manual",manualLocation:"",currentLocation:""},
 subscription:{trialStart:null,activeUntil:null,status:"trial"},
 records:{sales:[],purchases:[],expenses:[],stock:[],receivables:[],payables:[]},
 payments:[], lastDate:(()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`})(), dateAuto:true
};
function cloneDefault(){return typeof structuredClone==="function"?structuredClone(defaultState):JSON.parse(JSON.stringify(defaultState))}
function mergeState(raw){
 const base=cloneDefault(), src=raw&&typeof raw==="object"?raw:{};
 return {
  ...base,...src,
  settings:{...base.settings,...(src.settings||{}),theme:((src.settings||{}).theme && (src.settings||{}).theme!=="default")?(src.settings||{}).theme:"royal",locationMode:(src.settings||{}).locationMode||"manual",manualLocation:(src.settings||{}).manualLocation||"",currentLocation:(src.settings||{}).currentLocation||""},
  subscription:{...base.subscription,...(src.subscription||{})},
  records:{...base.records,...(src.records||{})},
  payments:Array.isArray(src.payments)?src.payments:[],
  lastDate:src.lastDate||base.lastDate,
  dateAuto:src.dateAuto!==false
 };
}
function accountKey(phone){return "myshop_account_"+String(phone||"").replace(/\D/g,"")}
function load(){
 try{
  const current=localStorage.getItem(CURRENT_KEY);
  if(current)return mergeState(JSON.parse(localStorage.getItem(accountKey(current))||"{}"));
  /* One-time compatibility: keep an existing anonymous/legacy state until the owner logs in. */
  return mergeState(JSON.parse(localStorage.getItem(KEY)||"{}"));
 }catch{return cloneDefault()}
}
let S=load(); ensureStockIntegrity(); ensureDebtIntegrity(); let page="home"; let modal=null; save();
function save(){
 if(S.user?.phone)localStorage.setItem(accountKey(S.user.phone),JSON.stringify(S));
 else localStorage.setItem(KEY,JSON.stringify(S));
}
function switchAccount(u){
 S=mergeState(JSON.parse(localStorage.getItem(accountKey(u.phone))||"{}"));
 S.user={name:u.name,phone:u.phone};
 S.settings.shopName=u.shopName||S.settings.shopName||"My Shop";
 if(!S.subscription.trialStart)S.subscription.trialStart=new Date().toISOString();
 localStorage.setItem(CURRENT_KEY,u.phone); save();
}
function clearCurrentAccount(){
 if(S.user?.phone)save();
 localStorage.removeItem(CURRENT_KEY); S=cloneDefault(); page="home"; modal=null;
}
function money(n){return "Rs. "+Number(n||0).toLocaleString("en-PK")}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function toast(t){let x=document.getElementById("toast");if(!x)return;x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
function fmt(d){return new Date(d+"T00:00:00").toLocaleDateString("en-PK",{day:"2-digit",month:"short",year:"numeric"})}
function fmtPurchaseDate(d){if(!d)return "Date not added";const [y,m,day]=String(d).slice(0,10).split("-");const months=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];return `${day}-${months[Math.max(0,Number(m)-1)]}-${y}`}
function purchaseForStock(st){return S.records.purchases.find(p=>String(p.id)===String(st?.purchaseId))||null}
function dateOf(x){return x.date||x.createdAt?.slice(0,10)}
function recordsForDate(a,d=S.lastDate){return (Array.isArray(a)?a:[]).filter(x=>dateOf(x)===d)}
function salesProfitForDate(d=S.lastDate){return sum(recordsForDate(S.records.sales,d),x=>Number(x.amount||0)-Number(x.cost||0))}
function netProfitForDate(d=S.lastDate){return salesProfitForDate(d)-sum(recordsForDate(S.records.expenses,d),x=>Number(x.amount||0))}
function sum(a,fn=x=>x.amount){return (Array.isArray(a)?a:[]).reduce((t,x)=>t+Number(fn(x)||0),0)}
function selectedRecords(a){return recordsForDate(a,S.lastDate)}
function saleTotal(){return sum(recordsForDate(S.records.sales))}
function purchaseTotal(){return sum(recordsForDate(S.records.purchases))}
function expenseTotal(){return sum(S.records.expenses,x=>Number(x.amount||0))}
function totalGrossProfit(){return sum(S.records.sales,x=>Number(x.amount||0)-Number(x.cost||0))}
function profit(){return totalGrossProfit()-expenseTotal()}
function stockCounts(){let u=S.records.stock.filter(x=>x.category==="used"&&x.available!==false).length;
let n=sum(S.records.stock.filter(x=>x.category==="new"),x=>x.qty||1);
let a=sum(S.records.stock.filter(x=>x.category==="accessory"),x=>x.qty||1);return {u,n,a,total:u+n+a}}
function investment(){
 // Total investment represents the cost of CURRENT AVAILABLE inventory only.
 // Sold stock must no longer remain in the investment total.
 return sum(S.records.stock.filter(x=>{
   if(x.category==="used") return x.available!==false;
   return Number(x.qty||0)>0;
 }),x=>Number(x.cost||0)*(x.category==="used"?1:Number(x.qty||0)));
}
function normalizeDebtName(v){return String(v||"").trim().replace(/\s+/g," ").toLowerCase()}
function normalizeDebtPhone(v){return String(v||"").replace(/\D/g,"")}
function debtIdentityKey(r){
 const phone=normalizeDebtPhone(r?.phone);
 return phone?`phone:${phone}`:`name:${normalizeDebtName(r?.name)}`;
}
function debtPaymentEntries(r){
 return (Array.isArray(r?.history)?r.history:[]).filter(h=>h&&h.source==="add_payment"&&Number(h.amount||0)>0);
}
function debtAdditionEntries(r){
 return (Array.isArray(r?.history)?r.history:[]).filter(h=>h&&h.source==="debt_add"&&Number(h.amount||0)>0);
}
function debtAppliedPayments(r){return debtPaymentEntries(r).reduce((t,h)=>t+Number(h.amount||0),0);}
function debtAddedAmount(r){return debtAdditionEntries(r).reduce((t,h)=>t+Number(h.amount||0),0);}
function reconcileDebtRecord(r){
 if(!r||typeof r!=="object")return;
 let original=Math.max(0,Number(r.original||0));
 r.desc=typeof r.desc==="string"?r.desc:(typeof r.description==="string"?r.description:"");
 r.history=Array.isArray(r.history)?r.history:[];
 // Legacy records had an opening amount in `original` and may have free-text
 // history entries. Only explicit debt_add/add_payment entries affect money.
 const opening=r.history.find(h=>h&&h.type==="Opening");
 if(!opening){
   const legacyOpening=Math.max(0,Number(r.original||r.balance||0));
   original=legacyOpening;
   r.history.unshift({date:r.date||todayISO(),type:"Opening",amount:legacyOpening,source:"system"});
 }else{
   opening.amount=Math.max(0,Number(opening.amount||r.original||0));
   opening.date=opening.date||r.date||todayISO();
   opening.source=opening.source||"system";
   original=Math.max(0,Number(opening.amount||0));
 }
 r.history=r.history.map(h=>{
   if(!h||h.type==="Opening"||h.type==="Status"||h.source==="status"||h.source==="add_payment"||h.source==="debt_add")return h;
   const legacyAmount=Math.max(0,Number(h.amount||h.invalidAmount||0));
   return {...h,source:"legacy_note",amount:0,legacyAmount};
 });
 let added=0,paid=0;
 r.history.forEach(h=>{
   if(h?.source==="debt_add")added+=Math.max(0,Number(h.amount||0));
 });
 let remaining=original+added;
 r.history=r.history.map(h=>{
   if(!h||h.type==="Opening"||h.type==="Status"||h.source!=="add_payment")return h;
   const requested=Math.max(0,Number(h.amount||0));
   const applied=Math.min(requested,remaining);
   if(requested>applied){
     return {...h,amount:0,invalidAmount:requested,note:[h.note||"",`Ignored ${money(requested-applied)}: exceeds remaining balance`].filter(Boolean).join(" • ")};
   }
   remaining-=applied; paid+=applied;
   return {...h,amount:applied};
 });
 r.original=original+added;
 r.balance=Math.max(0,remaining);
 r.status=r.balance<=0?"Paid":"Unpaid";
}
function mergeDebtRecordInto(target,source){
 if(!target||!source||target===source)return;
 target.phone=target.phone||source.phone||"";
 target.desc=[target.desc,source.desc].filter(Boolean).join(" • ");
 target.history=[...(Array.isArray(target.history)?target.history:[]),...(Array.isArray(source.history)?source.history:[])];
 target.history.sort((a,b)=>String(a?.date||"").localeCompare(String(b?.date||"")));
 // Keep the oldest opening amount as the base; later duplicate records become additions.
 const srcOpening=(source.history||[]).find(h=>h?.type==="Opening");
 const hasTargetOpening=(target.history||[]).find(h=>h?.type==="Opening");
 if(srcOpening&&hasTargetOpening&&source.id!==target.id){
   const amt=Math.max(0,Number(srcOpening.amount||0));
   if(amt>0)target.history.push({date:source.date||srcOpening.date||todayISO(),type:"Debt Added",amount:amt,source:"debt_add",note:"Merged duplicate customer record"});
 }
 reconcileDebtRecord(target);
}
function consolidateDebtList(arr){
 const out=[]; const byKey=new Map();
 for(const r of arr){
   if(!r||typeof r!=="object")continue;
   if(typeof r.desc!=="string")r.desc=typeof r.description==="string"?r.description:"";
   reconcileDebtRecord(r);
   const key=debtIdentityKey(r);
   const existing=byKey.get(key);
   if(existing){mergeDebtRecordInto(existing,r);}else{byKey.set(key,r);out.push(r);}
 }
 return out;
}
function ensureDebtIntegrity(){
 S.records.receivables=consolidateDebtList(Array.isArray(S.records.receivables)?S.records.receivables:[]);
 S.records.payables=consolidateDebtList(Array.isArray(S.records.payables)?S.records.payables:[]);
}
function ensureStockIntegrity(){
 let changed=false;
 S.records.stock=Array.isArray(S.records.stock)?S.records.stock:[];
 S.records.purchases=Array.isArray(S.records.purchases)?S.records.purchases:[];
 S.records.sales=Array.isArray(S.records.sales)?S.records.sales:[];

 // A purchase must map to exactly ONE stock record. Older builds could create
 // the same stock item again during startup/migration. Collapse only records
 // that are provably tied to the same purchaseId; legitimate separate
 // purchases of the same model remain untouched.
 const kept=[];
 const byPurchase=new Map();
 for(const st of S.records.stock){
   const pid=st&&st.purchaseId?String(st.purchaseId):"";
   if(pid && byPurchase.has(pid)){
     const existing=byPurchase.get(pid);
     // Prefer the record referenced by the purchase's stockId when possible.
     const purchase=S.records.purchases.find(p=>String(p.id)===pid);
     if(purchase && String(purchase.stockId)===String(st.id) && String(purchase.stockId)!==String(existing.id)){
       const idx=kept.indexOf(existing);
       if(idx>=0)kept[idx]=st;
       byPurchase.set(pid,st);
     }
     changed=true;
     continue;
   }
   kept.push(st);
   if(pid)byPurchase.set(pid,st);
 }
 if(kept.length!==S.records.stock.length){S.records.stock=kept;changed=true;}

 for(const p of S.records.purchases){
   let st=S.records.stock.find(x=>String(x.id)===String(p.stockId)) || S.records.stock.find(x=>String(x.purchaseId)===String(p.id));
   // IMPORTANT: never recreate stock merely because a purchase exists.
   // Stock is created only when the purchase is actually saved. Recreating it
   // on every app startup caused deleted/sold stock to come back and inflated
   // Total Stock and Total Investment. If the stock record is missing, leave
   // the purchase record untouched and do not auto-add anything.
   if(!st){
     continue;
   }
   if(String(p.stockId||"")!==String(st.id)){p.stockId=st.id;changed=true;}
   if(String(st.purchaseId||"")!==String(p.id)){st.purchaseId=p.id;changed=true;}
   if(String(st.date||"")!==String(p.date||"")){st.date=p.date||"";changed=true;}
   if(String(st.supplier||"")!==String(p.supplier||"")){st.supplier=p.supplier||"";changed=true;}
   const qty=Math.max(1,Number(p.quantity||1));
   const expectedQty=(p.category||"used")==="used"?1:qty;
   if(Number(st.qty||0)!==expectedQty){st.qty=expectedQty;changed=true;}
 }
 // Remove legacy owner field from purchases without touching other historical data.
 S.records.purchases.forEach(p=>{if(Object.prototype.hasOwnProperty.call(p,"owner")){delete p.owner;changed=true;}});
 return changed;
}

function initTrial(){if(S.user&&!S.subscription.trialStart){S.subscription.trialStart=new Date().toISOString();save()}}
function trialDays(){if(!S.subscription.trialStart)return 7;let d=Math.floor((Date.now()-new Date(S.subscription.trialStart))/86400000);return Math.max(0,7-d)}
function active(){if(S.subscription.status==="active")return !S.subscription.activeUntil||Date.now()<new Date(S.subscription.activeUntil);return S.subscription.status==="trial"&&trialDays()>0}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
function validDate(d){return d&&d<=todayISO()?d:todayISO()}
function setSelectedDate(v){S.lastDate=validDate(v);S.dateAuto=S.lastDate===todayISO();window.listDate=S.lastDate;save();render()}
const URDU={
"Welcome":"خوش آمدید","Home":"ہوم","Sale":"فروخت","Purchase":"خریداری","Stock":"اسٹاک","More":"مزید","Today":"آج","Today's Sale":"آج کی فروخت","Today's Purchase":"آج کی خریداری","Expenses":"اخراجات","Profit":"منافع","Leny Hain":"لینے ہیں","Deny Hain":"دینے ہیں","Total Stock":"کل اسٹاک","Total Investment":"کل سرمایہ کاری","Quick Categories":"فوری کیٹیگریز","Tap to open":"کھولنے کے لیے دبائیں","Used Phones":"استعمال شدہ فونز","New Phones":"نئے فونز","Accessories":"لوازمات","New Sale":"نئی فروخت","Today's Hisab":"آج کا حساب","Sales":"فروخت","Purchases":"خریداری","Net Profit":"خالص منافع","Tap for details →":"تفصیل کے لیے دبائیں →","Sales Details":"فروخت کی تفصیل","Purchase Details":"خریداری کی تفصیل","Add Sale":"فروخت شامل کریں","Add Purchase":"خریداری شامل کریں","Sold Phones":"فروخت شدہ فونز","Current Sales":"موجودہ فروخت","All":"سب","Available":"دستیاب","records":"ریکارڈز","More":"مزید","Reports":"رپورٹس","Subscription":"سبسکرپشن","Settings":"ترتیبات","Backup":"بیک اپ","Restore":"بحال کریں","Account":"اکاؤنٹ","Log Out":"لاگ آؤٹ","Create Account":"اکاؤنٹ بنائیں","Forgot Password":"پاس ورڈ بھول گئے؟","Login":"لاگ اِن","Phone Number":"فون نمبر","Password":"پاس ورڈ","Shop Name":"دکان کا نام","Your Name":"آپ کا نام","Shop Details (optional)":"دکان کی تفصیل (اختیاری)","Save Settings":"ترتیبات محفوظ کریں","Font Size":"فونٹ سائز","Language":"زبان","English":"انگریزی","Urdu":"اردو","Layout / Design":"لے آؤٹ / ڈیزائن","Themes":"تھیمز","Preview before applying":"لگانے سے پہلے پیش منظر","Close":"بند کریں","Date":"تاریخ","Category":"کیٹیگری","Search Available Phone":"دستیاب فون تلاش کریں","Select Used Phone":"استعمال شدہ فون منتخب کریں","Customer Name":"گاہک کا نام","Sale Price":"فروخت کی قیمت","Condition":"حالت","Payment":"ادائیگی","CNIC":"شناختی کارڈ نمبر","Description":"تفصیل","Done":"مکمل","Done + WhatsApp Receipt":"مکمل + واٹس ایپ رسید","With Box":"ڈبے کے ساتھ","Only Phone":"صرف فون","Cash":"نقد","EasyPaisa":"ایزی پیسہ","JazzCash":"جاز کیش","HBL Konnect":"ایچ بی ایل کنیکٹ","Supplier / Purchased From":"سپلائر / خریداری کی جگہ","Owner / Customer Name":"مالک / گاہک کا نام","Purchase Price":"خریداری کی قیمت","Quantity":"تعداد","Model / Product Name":"ماڈل / پروڈکٹ کا نام","IMEI / Barcode (optional)":"IMEI / بارکوڈ (اختیاری)","Description":"تفصیل","Print / PDF":"پرنٹ / PDF","Share to WhatsApp":"واٹس ایپ پر شیئر کریں","View":"دیکھیں","Edit":"ترمیم","No records yet.":"ابھی کوئی ریکارڈ موجود نہیں۔","Recent":"حالیہ","Add Expense":"اخراجات شامل کریں","Expense":"خرچ","Amount":"رقم","Reports":"رپورٹس","Total Sales":"کل فروخت","Total Purchases":"کل خریداری","Total Expenses":"کل اخراجات","Gross Profit":"مجموعی منافع","Export CSV":"CSV برآمد کریں","Payment Method":"ادائیگی کا طریقہ","Transaction ID":"ٹرانزیکشن آئی ڈی","Payment Screenshot":"ادائیگی کا اسکرین شاٹ","Submit Payment for Approval":"ادائیگی منظوری کے لیے جمع کریں","Active":"فعال","Expired":"ختم","My Shop":"میری دکان","Cash Customer":"نقد گاہک","Available":"دستیاب","Qty":"تعداد","No phone":"فون موجود نہیں","sold":"فروخت شدہ","Sold":"فروخت شدہ","Current Sales":"موجودہ فروخت","Search model, IMEI or phone name":"ماڈل، IMEI یا فون کا نام تلاش کریں","Purchased from:":"خریداری کی جگہ:","Not added":"شامل نہیں کیا گیا","Active subscription":"فعال سبسکرپشن","Subscription expired":"سبسکرپشن ختم ہو گئی","Free trial:":"مفت آزمائش:","day(s) remaining":"دن باقی ہیں"
};
function applyUrdu(){
 document.body.classList.toggle('lang-ur',S.settings.lang==='ur');
 if(S.settings.lang!=='ur')return;
 const root=document.body;
 const walk=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
 const nodes=[];let n;while(n=walk.nextNode())nodes.push(n);
 nodes.forEach(node=>{let v=node.nodeValue;if(!v.trim())return;Object.keys(URDU).sort((a,b)=>b.length-a.length).forEach(k=>{v=v.split(k).join(URDU[k]);});node.nodeValue=v;});
 root.querySelectorAll('input,textarea').forEach(el=>{for(const a of ['placeholder']){let v=el.getAttribute(a);if(v){Object.keys(URDU).sort((a,b)=>b.length-a.length).forEach(k=>v=v.split(k).join(URDU[k]));el.setAttribute(a,v);}}});
 root.querySelectorAll('option').forEach(el=>{const v=el.textContent.trim();if(URDU[v])el.textContent=URDU[v];});
}

function render(){
 if(ensureStockIntegrity())save();
 initTrial();
 const now=todayISO(); if(S.dateAuto!==false && S.lastDate!==now){S.lastDate=now;window.listDate=now;save();} else {if(S.lastDate>now)S.lastDate=now; if(window.listDate>now)window.listDate=now;}
 const fontMap={small:"13px",medium:"15px",large:"17px",xlarge:"20px",xxlarge:"23px"}; document.documentElement.style.setProperty("--font",fontMap[S.settings.font]||"15px"); document.documentElement.style.setProperty("--font-scale",S.settings.font==="xxlarge"?"1.12":S.settings.font==="xlarge"?"1.06":"1");
 document.body.className=(S.settings.theme==="default"?"":`theme-${S.settings.theme}`)+` layout-${S.settings.layout||1}`;
 document.getElementById("app").innerHTML=S.user?appShell():login();
 if(modal) renderModal();
 applyUrdu();
}
let lastAutoDay=todayISO();
setInterval(()=>{const d=todayISO();if(d!==lastAutoDay){lastAutoDay=d;if(S.dateAuto!==false){S.dateAuto=true;S.lastDate=d;window.listDate=d;window.soldView=false;save();}}},60000);

function login(){
return `<div class="login"><div class="loginbox"><div style="font-size:44px">🏪</div><h1>My Shop</h1><p>Smart shop management — simple, professional, offline + online.</p>
<div class="form"><div class="field"><label>Phone Number</label><input id="lphone" placeholder="03XX-XXXXXXX" inputmode="tel"></div>
<div class="field"><label>Password</label><input id="lpass" type="password" placeholder="Enter password"></div>
<button class="btn primary wide" onclick="doLogin()">Login</button>
<button class="link" onclick="modal='forgot';render()">Forgot Password?</button>
<button class="btn soft wide" onclick="modal='signup';render()">Create Account</button></div></div></div>`}
function locationLabel(){
 const s=S.settings||{};
 return s.locationMode==="current" ? (s.currentLocation||"") : (s.manualLocation||"");
}
function locationText(){const v=locationLabel();return v?`<span class="shop-location" onclick="requestCurrentLocation()">📍 ${esc(v)}</span>`:`<span class="shop-location location-empty" onclick="requestCurrentLocation()">📍 Enable Location</span>`}
async function requestCurrentLocation(){
 if(!navigator.geolocation){toast("Location is not supported on this device");return}
 toast("Getting your current location…");
 navigator.geolocation.getCurrentPosition(async pos=>{
   const lat=pos.coords.latitude,lon=pos.coords.longitude;
   let label=`${lat.toFixed(5)}, ${lon.toFixed(5)}`;
   try{
     const r=await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&localityLanguage=en`);
     if(r.ok){const d=await r.json();label=d.locality||d.city||d.principalSubdivision||d.countryName||label;}
   }catch(e){}
   S.settings.locationMode="current";S.settings.currentLocation=label;save();render();toast("Current location updated");
 },()=>toast("Please enable Location permission for My Shop"),{enableHighAccuracy:true,timeout:12000,maximumAge:300000});
}
function setManualLocation(){
 const v=(document.getElementById("set_location")?.value||"").trim();
 S.settings.locationMode="manual";S.settings.manualLocation=v;save();render();
}
function appShell(){
return `<div class="shell"><div class="topbar"><div><div class="brand">${esc(S.settings.shopName)}</div><div class="subbrand">My Shop • ${active()?"Active":"Expired"} ${locationText()}</div></div><button class="iconbtn" onclick="modal='settings';render()">⚙️</button></div>${pageView()}${nav()}</div>`}
function nav(){return `<div class="bottom">${[
["home","⌂","Home"],["sale","＋","Sale"],["purchase","🛒","Purchase"],["stock","▦","Stock"],["more","☰","More"]
].map(x=>`<button class="navbtn ${page===x[0]?'active':''}" onclick="go('${x[0]}')"><b>${x[1]}</b>${x[2]}</button>`).join("")}</div>`}
function pageView(){if(page==="home")return home();if(page==="sale")return salePage();if(page==="purchase")return purchasePage();if(page==="stock")return stockPage();return morePage()}

function home(){
let s=stockCounts(), inv=investment();
return `<main class="content"><section class="welcome"><div class="hello">Welcome</div><h1>${esc(S.user.name)}</h1><div class="date"><span>📅</span><input type="date" value="${S.lastDate}" max="${todayISO()}" onchange="setSelectedDate(this.value)"></div></section>
<div class="grid">
${bubble("Today's Sale",saleTotal(),"green","saleDetails")} ${bubble("Today's Purchase",purchaseTotal(),"orange","purchaseDetails")}
${bubble("Expenses",expenseTotal(),"purple","expenseDetails")} ${bubble("Profit",profit(),"blue","profitDetails")}
${bubble("Leny Hain",sum(S.records.receivables,x=>x.balance),"green","receivable")} ${bubble("Deny Hain",sum(S.records.payables,x=>x.balance),"red","payable")}
${bubble("Total Stock",s.total,"blue","stock")} ${bubble("Total Investment",inv,"orange","investment")}
</div>
<div class="section-title">Quick Categories <small>Tap to open</small></div><div class="cards">
<button class="feature" onclick="stockFilter('used')"><span>📱</span>Used Phones</button>
<button class="feature" onclick="stockFilter('new')"><span>📦</span>New Phones</button>
<button class="feature" onclick="stockFilter('accessory')"><span>🔌</span>Accessories</button>
<button class="feature" onclick="go('sale')"><span>💸</span>New Sale</button>
</div>
<div class="section-title">Today's Hisab <small>${fmt(S.lastDate)}</small></div>
<div class="summary"><div class="summaryline"><span>Sales</span><strong>${money(saleTotal())}</strong></div><div class="summaryline"><span>Purchases</span><strong>${money(purchaseTotal())}</strong></div><div class="summaryline"><span>Expenses</span><strong>${money(expenseTotal())}</strong></div><div class="summaryline"><span>Net Profit</span><strong>${money(profit())}</strong></div></div>
</main>`}
function bubble(label,val,cl,act){return `<button class="bubble b-${cl}" onclick="openDashboard('${act}')"><div class="label">${label}</div><div class="amount">${typeof val==="number"?money(val):val}</div><div class="mini">Tap for details →</div></button>`}
function openDashboard(act){if(act==="saleDetails"){page="sale";window.listDate=S.lastDate;render()}else if(act==="purchaseDetails"){page="purchase";window.listDate=S.lastDate;render()}else if(act==="expenseDetails"){modal="expenses";render()}else if(act==="receivable"){window.debtTab="receivable";modal="lend";render()}else if(act==="payable"){window.debtTab="payable";modal="lend";render()}else if(act==="investment"){modal="investment";render()}else if(act==="stock"){stockFilter("all")}else if(act==="profitDetails"){modal="profit";render()}}

function pageHead(title){return `<div class="pagehead"><button class="back" onclick="go('home')">←</button><h2>${title}</h2></div>`}
function salePage(){let d=validDate(window.listDate||S.lastDate);window.listDate=d;let rows=S.records.sales.filter(x=>dateOf(x)===d).slice().reverse();let tab=window.saleTab||"current";return `<main class="content">${pageHead("Sales")}<div class="chips"><button class="chip ${tab==="current"?"active":""}" onclick="window.saleTab='current';render()">Current Sales</button><button class="chip ${tab==="available"?"active":""}" onclick="window.saleTab='available';window.availableCat='used';render()">Available Phones</button><button class="chip ${tab==="sold"?"active":""}" onclick="window.saleTab='sold';render()">Sold Phones</button></div>${tab==="sold"?soldPhonesPage():tab==="available"?availablePhonesPage():`<div class="field"><label>Date</label><input type="date" max="${todayISO()}" value="${d}" onchange="setSelectedDate(this.value)"></div><div class="section-title">Sales — ${fmt(d)} <small>${money(sum(rows))}</small></div><button type="button" class="current-sale-plus" aria-label="Add sale" title="Add sale" onclick="window.salePreselect=null;window.salePreselectCat=null;window.salePreselectSearch='';modal='sale';render()">＋</button>${list(rows,x=>`${esc(x.product)}<div class="muted"><b>Sold to:</b> ${esc(x.customer||"Cash Customer")}</div><div class="muted"><b>Contact:</b> ${esc(x.phone||"No phone")}</div>`,x=>money(x.amount),x=>`<button onclick="viewRecord('sales','${x.id}')">View</button><button onclick="editRecord('sales','${x.id}')">✏️</button><button onclick="del('sales','${x.id}')">🗑️</button>`)}`}</main>`}
function availablePhonesPage(){
 let cat=window.availableCat||"used";
 let rows=S.records.stock.filter(x=>x.category===cat&&x.available!==false&&(cat==="used"||Number(x.qty||0)>0));
 let qty=sum(rows,x=>cat==="used"?1:Number(x.qty||0));
 let cards=rows.map(x=>{
  const p=purchaseForStock(x), purchasedFrom=x.supplier||p?.supplier||"Not added", purchasedDate=fmtPurchaseDate(x.date||p?.date);
  const condition=x.condition||"Only Phone";
  const quantity=cat==="used"?"":`<span class="available-qty">Qty: ${Number(x.qty||0)}</span>`;
  return `<button type="button" class="sale-product-card sale-available-card" onclick="openSaleForStock('${x.id}')"><div class="sale-card-main"><div class="sale-card-row sale-card-top"><b class="sale-model">${esc(x.product)}</b><span class="condition-badge">${esc(condition)}</span><span class="available-badge">Available</span>${quantity}</div><div class="sale-card-row sale-card-meta"><span><strong>Purchased from:</strong> ${esc(purchasedFrom)}</span><span><strong>Date:</strong> ${esc(purchasedDate)}</span></div></div><span class="sale-mini-action">SALE</span></button>`;
 }).join("");
 if(!cards)cards='<div class="muted">No available phones in this category.</div>';
 return `<div class="chips"><button class="chip ${cat==='used'?'active':''}" onclick="window.availableCat='used';render()">Used Phones</button><button class="chip ${cat==='new'?'active':''}" onclick="window.availableCat='new';render()">New Phones</button><button class="chip ${cat==='accessory'?'active':''}" onclick="window.availableCat='accessory';render()">Accessories</button></div><div class="section-title">Available ${cat==='used'?'Used Phones':cat==='new'?'New Phones':'Accessories'} <small>${qty} available</small></div><button type="button" class="available-sale-plus" aria-label="Sell a phone" title="Sell a phone" onclick="window.salePreselect=null;window.salePreselectCat=null;window.salePreselectSearch='';modal='sale';render()">＋</button>${cards}`;
}
function openSaleForStock(id){const st=S.records.stock.find(x=>x.id===id&&x.available!==false&&((x.category==='used')||(Number(x.qty||0)>0)));if(!st)return toast('Phone is no longer available');window.salePreselect=st.id;window.salePreselectCat=st.category;window.salePreselectSearch=st.product||'';modal='sale';render();setTimeout(()=>{const cat=document.getElementById('sale_cat');if(cat)cat.value=st.category;const q=document.getElementById('sale_search');if(q)q.value='';filterSaleProducts();selectSaleProduct(st.id)},0)}
function soldPhonesPage(){let rows=S.records.sales.slice().sort((a,b)=>String(dateOf(b)).localeCompare(String(dateOf(a))));return `<div class="section-title">Sold Phones <small>${rows.length} sold</small></div>${list(rows,x=>`<div class="sale-card-main sold-card-main"><div class="sale-card-row sale-card-top"><b class="sale-model">${esc(x.product)}</b><span class="sold-to-badge"><strong>Sold to:</strong> ${esc(x.customer||"Cash Customer")}</span></div><div class="sale-card-row sale-card-meta"><span><strong>Contact:</strong> ${esc(x.phone||"No phone")}</span><span><strong>Date:</strong> ${esc(fmtPurchaseDate(dateOf(x)))}</span></div></div>`,x=>money(x.amount),x=>`<button onclick="viewRecord('sales','${x.id}')">View</button>`)}`}

function purchasePage(){let d=window.listDate||S.lastDate,rows=S.records.purchases.filter(x=>dateOf(x)===d).slice().reverse();return `<main class="content">${pageHead("Purchases")}<div class="section-title">Purchases — ${fmt(d)} <small>${money(sum(rows))}</small></div><button type="button" class="purchase-plus" aria-label="Add purchase" title="Add purchase" onclick="modal='purchase';render()">＋</button>${list(rows,x=>`${esc(x.product)}<div class="muted purchase-subline">${x.supplier?`Purchased from: <b>${esc(x.supplier)}</b>`:`<span class="missing-detail">Purchased from: Not added</span>`}${x.condition?` • ${esc(x.condition)}`:""}</div>`,x=>money(x.amount),x=>`<button onclick="viewRecord('purchases','${x.id}')">View</button><button onclick="editRecord('purchases','${x.id}')">✏️</button><button onclick="del('purchases','${x.id}')">🗑️</button>`)}</main>`}
function stockPage(){let cat=window.stockCat||"all";let data=S.records.stock.filter(x=>(cat==="all"||x.category===cat)&&x.available!==false&&((x.category==="used")?true:Number(x.qty||0)>0));let count=sum(data,x=>x.category==="used"?1:Number(x.qty||0));return `<main class="content">${pageHead("Stock")}<div class="chips">${["all","used","new","accessory"].map(c=>`<button class="chip ${cat===c?"active":""}" onclick="stockFilter('${c}')">${c==="all"?"All":c==="used"?"Used Phones":c==="new"?"New Phones":"Accessories"}</button>`).join("")}</div><div class="section-title">Available <small>${count} phones/items</small></div>${list(data,x=>{let p=purchaseForStock(x),d=x.date||p?.date,s=x.supplier||p?.supplier||"Not added";return `${esc(x.product)}<div class="muted">${x.category==="used"?"Available":"Qty: "+(x.qty||0)} • ${x.condition||"—"}</div><div class="muted purchase-subline">Purchased: <b>${esc(fmtPurchaseDate(d))}</b> • From: <b>${esc(s)}</b></div>`},x=>money(x.sale||x.cost),x=>`<button onclick="editRecord('stock','${x.id}')">✏️</button><button onclick="del('stock','${x.id}')">🗑️</button>`)}</main>`}
function morePage(){return `<main class="content">${pageHead("More")}<div class="cards">
<button class="feature" onclick="window.debtTab='receivable';modal='lend';render()"><span>💰</span>Leny Hain</button><button class="feature" onclick="window.debtTab='payable';modal='lend';render()"> <span>📒</span>Deny Hain</button>
<button class="feature" onclick="modal='expenses';render()"><span>🧾</span>Expenses</button><button class="feature" onclick="modal='reports';render()"><span>📊</span>Reports</button>
<button class="feature" onclick="modal='subscription';render();window.refreshSubscription&&window.refreshSubscription()"><span>⭐</span>Subscription</button><button class="feature" onclick="modal='settings';render()"><span>⚙️</span>Settings</button>
<button class="feature" onclick="backup()"><span>💾</span>Backup</button><button class="feature" onclick="document.getElementById('restore').click()"><span>♻️</span>Restore</button>
</div><input id="restore" type="file" accept=".json" hidden onchange="restore(event)">
<div class="section-title">Account</div><button class="btn danger wide" onclick="clearCurrentAccount();render()">Log Out</button></main>`}

function list(data,left,right,extra){if(!data.length)return `<div class="summary"><span class="muted">No records yet.</span></div>`;return `<div class="list">${data.map(x=>`<div class="item"><div><div class="title">${left(x)}</div></div><div style="text-align:right"><div class="price">${right(x)}</div><div class="actions">${extra?extra(x):""}</div></div></div>`).join("")}</div>`}

function renderModal(){
// Replace the current modal instead of stacking a new modal on top of it.
// Stacked modals were causing Done/Close/Add Payment/Delete to require multiple taps.
document.querySelectorAll(".modal").forEach(el=>el.remove());
let body="";
if(modal==="signup")body=`<h2>Create Account</h2><div class="form"><div class="field"><label>Shop Name</label><input id="s_shop" value="My Shop"></div><div class="field"><label>Your Name</label><input id="s_name"></div><div class="field"><label>Phone Number</label><input id="s_phone" inputmode="tel"></div><div class="field"><label>Password</label><input id="s_pass" type="password"></div><div class="field"><label>Shop Details (optional)</label><textarea id="s_details"></textarea></div><button class="btn primary wide" onclick="signup()">Create Account</button></div>`;
if(modal==="forgot")body=`<h2>Forgot Password</h2><p class="muted">Enter the same phone number used for your account. Existing accounts can set a new password.</p><div class="form"><div class="field"><label>Phone Number</label><input id="f_phone"></div><div class="field"><label>New Password</label><input id="f_pass" type="password"></div><button class="btn primary wide" onclick="resetPass()">Set New Password</button></div>`;
if(modal==="sale")body=saleForm(); if(modal==="purchase")body=purchaseForm();
if(modal==="expenses")body=expenseDetails();
if(modal==="expenseAdd")body=`<h2>Add Expense</h2><div class="form"><div class="field"><label>Date</label><input id="e_date" type="date" max="${todayISO()}" value="${validDate(S.lastDate)}"></div><div class="field"><label>Expense</label><input id="e_name" placeholder="Tea, food, electricity, rent..."></div><div class="field"><label>Amount</label><input id="e_amt" type="number"></div><div class="field"><label>Description</label><textarea id="e_desc"></textarea></div><button class="btn primary wide" onclick="addExpense()">Add Expense</button></div>`;
if(modal==="lend")body=lendForm();
if(modal==="debtAdd")body=debtAddForm();
if(modal==="debtStatus")body=debtStatusForm();
if(modal==="debtPayment")body=debtPaymentForm();
if(modal==="debtDetail")body=debtDetail();
if(modal==="reports")body=reports();if(modal==="reportDetail")body=reportDetail();
if(modal==="subscription")body=subscription();
if(modal==="settings")body=settings();
if(modal==="details")body=detailModal();
if(modal==="investment")body=investmentDetails();
if(modal==="scanner")body=scanner();if(modal==="recordView")body=recordView();if(modal==="editRecord")body=editRecordForm();if(modal==="editDebt")body=editDebtForm();if(modal==="profit")body=profitDetails();
document.body.insertAdjacentHTML("beforeend",`<div class="modal" onclick="if(event.target.classList.contains('modal'))closeModal()"><div class="modalbox">${body}<button class="btn soft wide" style="margin-top:12px" onclick="closeModal()">Close</button></div></div>`);
if(modal==="sale")setTimeout(()=>{ensureStockIntegrity();filterSaleProducts()},0);
}
function closeModal(){
 const backMap={debtDetail:'lend',debtStatus:'lend',debtPayment:'debtDetail',editDebt:'debtDetail',reportDetail:'reports'};
 const current=modal;
 document.querySelectorAll('.modal').forEach(el=>el.remove());
 if(current==="recordView" && window.reportRecordReturn){
   modal=window.reportRecordReturn;window.reportRecordReturn=null;render();return;
 }
 if(backMap[current]){modal=backMap[current];render();}else{modal=null;}
}
function saleForm(){let pre=S.records.stock.find(x=>x.id===window.salePreselect);let preCat=pre?.category||"used";return `<h2>Add Sale</h2><div class="form"><div class="field"><label>Date</label><input id="sale_date" type="date" max="${todayISO()}" value="${validDate(S.lastDate)}"></div><div class="field"><label>Category</label><select id="sale_cat" onchange="filterSaleProducts()"><option value="used" ${preCat==="used"?"selected":""}>Used Phone</option><option value="new" ${preCat==="new"?"selected":""}>New Phone</option><option value="accessory" ${preCat==="accessory"?"selected":""}>Accessory</option></select></div><div class="field"><label>Select Available Phone</label><select id="sale_product" onchange="autoSalePrice()"></select><div class="muted tiny" style="margin-top:6px">Tap the list to choose from available stock.</div></div><div class="row"><div class="field"><label>Customer Name</label><input id="sale_customer"></div><div class="field"><label>Phone</label><input id="sale_phone"></div></div><div class="field"><label>Sale Price</label><input id="sale_price" type="number"></div><div class="row"><div class="field"><label>Condition</label><select id="sale_condition"><option>With Box</option><option>Only Phone</option></select></div><div class="field"><label>Payment</label><select id="sale_payment"><option>Cash</option><option>EasyPaisa</option><option>JazzCash</option><option>HBL Konnect</option></select></div></div><div class="field"><label>CNIC</label><input id="sale_cnic"></div><div class="field"><label>Description</label><textarea id="sale_desc"></textarea></div><div class="actions"><button class="btn soft" onclick="startVoice()">🎙️ Record Voice Note</button><button class="btn green" onclick="saveSale()">Done</button></div><button class="btn primary wide" onclick="saveSale(true)">Done + WhatsApp Receipt</button></div><script>setTimeout(filterSaleProducts,0)</script>`}
function purchaseForm(){return `<h2>Add Purchase</h2><div class="form"><div class="field"><label>Date</label><input id="pur_date" type="date" max="${todayISO()}" value="${validDate(S.lastDate)}"></div><div class="field"><label>Category</label><select id="pur_cat" onchange="togglePurchaseFields()"><option value="used">Used Phone</option><option value="new">New Phone</option><option value="accessory">Accessory</option></select></div><div class="field"><label>IMEI / Barcode (optional)</label><input id="pur_imei" placeholder="Scan or type IMEI" value="${esc(window.scannedIMEI||"")}"><button class="btn soft wide" style="margin-top:7px" onclick="window.scanTarget='purchase';modal='scanner';render()">📷 Scan IMEI</button></div><div class="field"><label>Model / Product Name</label><input id="pur_product" placeholder="e.g. Samsung A52"></div><div id="purchase-extra"><div class="row"><div class="field"><label>Purchase Price</label><input id="pur_price" type="number"></div><div class="field"><label>Quantity</label><input id="pur_qty" type="number" value="1" min="1"></div></div><div class="field"><label>Supplier / Purchased From</label><input id="pur_supplier" placeholder="Name of the person/shop you bought it from"></div></div><div class="field"><label>CNIC</label><input id="pur_cnic"></div><div class="field"><label>Condition</label><select id="pur_condition"><option>With Box</option><option>Only Phone</option></select></div><div class="field"><label>Description</label><textarea id="pur_desc"></textarea></div><div class="actions"><button class="btn soft" onclick="startVoice()">🎙️ Record Voice Note</button><button class="btn green" onclick="savePurchase()">Done</button></div><button class="btn primary wide" onclick="savePurchase(true)">Done + WhatsApp Receipt</button></div>`}
function openContact(kind,phone,text=""){
 const p=normalizePhone(phone||"");
 if(!p)return toast("No phone number");
 const wa=p.startsWith("0")?"92"+p.slice(1):p;
 // Android APK: use the native bridge so WebView never navigates away from the app.
 if(window.AndroidApp&&typeof window.AndroidApp.openExternal==="function"){
   try{window.AndroidApp.openExternal(kind,p,text||"");return;}catch(e){}
 }
 if(kind==="call")location.href=`tel:${p}`;
 else if(kind==="sms")location.href=`sms:${p}`;
 else if(kind==="whatsapp")location.href=`https://wa.me/${wa}${text?`?text=${encodeURIComponent(text)}`:""}`;
}
function debtContactButtons(phone){const p=normalizePhone(phone||"");if(!p)return `<div class="contact"><span class="muted">No phone number</span></div>`;return `<div class="contact debt-contact"><button type="button" onclick="openContact('call','${esc(p)}')">☎ Call</button><button type="button" onclick="openContact('sms','${esc(p)}')">SMS</button><button type="button" onclick="openContact('whatsapp','${esc(p)}')">WhatsApp</button></div>`}
function lendForm(){
  let tab=window.debtTab||"receivable";
  S.records.receivables=S.records.receivables||[]; S.records.payables=S.records.payables||[];
  let arr=tab==="receivable"?S.records.receivables:S.records.payables;
  // Keep exactly one visible record per customer and consolidate any legacy duplicates.
  arr=consolidateDebtList(arr);
  if(tab==="receivable")S.records.receivables=arr;else S.records.payables=arr;
  let title=tab==="receivable"?"Leny Hain":"Deny Hain";
  return `<h2>${title}</h2>
  <div class="chips">
    <button class="chip ${tab==="receivable"?'active':''}" onclick="switchDebtTab('receivable')">Leny Hain</button>
    <button class="chip ${tab==="payable"?'active':''}" onclick="switchDebtTab('payable')">Deny Hain</button>
  </div>
  <div class="section-title">${tab==="receivable"?"Customers who owe you":"People you owe"}</div>
  <div class="debt-list">${arr.slice().reverse().map(x=>{
    reconcileDebtRecord(x);
    const status=x.balance<=0?"Paid":(x.status||"Unpaid");
    const cls=status==="Paid"?"paid":"unpaid";
    return `<article class="debt-card" onclick="openDebtDetail('${tab}','${x.id}')" role="button" tabindex="0">
      <div class="debt-head"><div class="debt-person"><div class="debt-name">${esc(x.name)}</div>${x.phone?`<div class="debt-phone">${esc(x.phone)}</div>`:""}</div><div class="debt-money"><strong>${money(x.balance)}</strong><button type="button" class="debt-status ${cls}" onclick="event.stopPropagation();openDebtStatus('${tab}','${x.id}')">${status}</button></div></div>
      <div class="debt-meta"><span>Original: ${money(x.original||x.balance)}</span><span>Tap customer for complete hisaab →</span></div>
      ${debtContactButtons(x.phone)}
    </article>`;
  }).join("")||`<div class="summary muted">No records yet.</div>`}</div>
  <button type="button" class="btn primary wide add-bottom-btn" onclick="modal='debtAdd';window.debtAddTab='${tab}';render()">＋ Add ${title}</button>`;
}
function debtAddForm(){
  const tab=window.debtAddTab||window.debtTab||"receivable";
  const title=tab==="receivable"?"Leny Hain":"Deny Hain";
  return `<h2>Add ${title}</h2><div class="form">
    <div class="field"><label>Name</label><input id="c_name" autocomplete="off" placeholder="Person / shop name"></div>
    <div class="row"><div class="field"><label>Phone</label><input id="c_phone" inputmode="tel" autocomplete="off"></div><div class="field"><label>Amount</label><input id="c_amt" type="number" inputmode="decimal" min="1" step="1" placeholder="0"></div></div>
    <div class="field"><label>Description / Note</label><textarea id="c_desc" placeholder="Optional note about this customer's hisaab"></textarea></div>
    <button id="debt-save-btn" type="button" class="btn primary wide" onclick="saveDebt('${tab}')">＋ Save ${title} Record</button>
  </div>`;
}
function switchDebtTab(tab){window.debtTab=tab;modal="lend";render()}
function saveDebt(tab){
  if(window._debtSaveBusy)return;
  window._debtSaveBusy=true;
  const btn=document.getElementById("debt-save-btn"); if(btn){btn.disabled=true;btn.dataset.busy="1";}
  tab=tab==="payable"?"payable":"receivable";
  const name=(document.getElementById("c_name")?.value||"").trim(),phone=(document.getElementById("c_phone")?.value||"").trim(),amount=Number(document.getElementById("c_amt")?.value),desc=(document.getElementById("c_desc")?.value||"").trim();
  if(!name){window._debtSaveBusy=false; if(btn)btn.disabled=false; return toast("Enter name");} if(!Number.isFinite(amount)||amount<=0){window._debtSaveBusy=false; if(btn)btn.disabled=false; return toast("Enter a valid amount");}
  S.records.receivables=S.records.receivables||[];S.records.payables=S.records.payables||[];
  const arr=tab==="receivable"?S.records.receivables:S.records.payables;
  const identity=phone?`phone:${normalizeDebtPhone(phone)}`:`name:${normalizeDebtName(name)}`;
  let rec=arr.find(x=>debtIdentityKey(x)===identity);
  if(rec){
    reconcileDebtRecord(rec);
    rec.name=name||rec.name; rec.phone=phone||rec.phone;
    rec.history=Array.isArray(rec.history)?rec.history:[];
    rec.history.push({date:todayISO(),type:"Debt Added",amount,source:"debt_add",note:desc});
    if(desc)rec.desc=[rec.desc,desc].filter(Boolean).join(" • ");
    reconcileDebtRecord(rec);
  }else{
    rec={id:uid(),date:todayISO(),name,phone,balance:amount,original:amount,status:"Unpaid",desc,history:[{date:todayISO(),type:"Opening",amount,source:"system"}],type:tab};
    arr.push(rec);
  }
  ensureDebtIntegrity(); save();window.debtTab=tab;modal="lend";render();window._debtSaveBusy=false;return true;
}
function findDebt(tab,id){const arr=tab==="receivable"?S.records.receivables:S.records.payables;return {arr,r:arr?.find(x=>x.id===id)}}
function openDebtStatus(tab,id){const {r}=findDebt(tab,id);if(!r)return;window.debtDetailTab=tab;window.debtDetailId=id;modal="debtStatus";render()}
function debtStatusForm(){const tab=window.debtDetailTab||"receivable",{r}=findDebt(tab,window.debtDetailId);if(!r)return `<h2>Record not found</h2>`;return `<h2>${esc(r.name)} — Status</h2><div class="summary"><div class="summaryline"><span>Remaining</span><strong>${money(r.balance)}</strong></div><div class="field"><label>Status</label><select id="debt_status_select"><option ${r.balance>0&&r.status!=="Paid"?"selected":""}>Unpaid</option><option ${r.balance<=0||r.status==="Paid"?"selected":""}>Paid</option></select></div><button class="btn primary wide" onclick="saveDebtStatus()">Save Status</button><div class="actions" style="margin-top:10px"><button class="btn soft" onclick="openDebtDetail('${tab}','${r.id}')">Receipt / Details</button><button class="btn soft" onclick="shareDebtReceipt('${tab}','${r.id}')">WhatsApp Receipt</button><button class="btn green" onclick="modal='lend';window.debtTab='${tab}';render()">Done</button></div></div>`}
function debtPaidAmount(r){return (Array.isArray(r?.history)?r.history:[]).filter(h=>h.type!=="Opening"&&h.type!=="Status").reduce((t,h)=>t+Number(h.amount||0),0)}
function saveDebtStatus(){const tab=window.debtDetailTab||"receivable",{r}=findDebt(tab,window.debtDetailId);if(!r)return;const st=document.getElementById("debt_status_select")?.value;r.history=Array.isArray(r.history)?r.history:[];if(st==="Paid"){r.statusOverride="Paid";}else{r.statusOverride="Unpaid";}reconcileDebtRecord(r);r.history.push({date:todayISO(),type:"Status",amount:0,source:"status",note:`Marked ${st}`});save();modal="lend";window.debtTab=tab;render()}
function addDebtPayment(tab,id){window.debtDetailTab=tab;window.debtDetailId=id;modal="debtPayment";render()}
function debtPaymentForm(){const tab=window.debtDetailTab||"receivable",{r}=findDebt(tab,window.debtDetailId);if(!r)return `<h2>Record not found</h2>`;return `<h2>Add Payment — ${esc(r.name)}</h2><div class="summary"><div class="summaryline"><span>Remaining</span><strong>${money(r.balance)}</strong></div><div class="field"><label>Payment Amount</label><input id="debt_payment_amount" type="number" min="1" max="${Number(r.balance||0)}" value="${Number(r.balance||0)}"></div><div class="field"><label>Date</label><input id="debt_payment_date" type="date" max="${todayISO()}" value="${todayISO()}"></div><div class="field"><label>Note (optional)</label><textarea id="debt_payment_note"></textarea></div><button class="btn primary wide" onclick="saveDebtPayment()">Save Payment</button></div>`}
function saveDebtPayment(){const tab=window.debtDetailTab||"receivable",{r}=findDebt(tab,window.debtDetailId);if(!r)return;const n=Number(document.getElementById("debt_payment_amount")?.value||0),d=document.getElementById("debt_payment_date")?.value||todayISO(),note=document.getElementById("debt_payment_note")?.value.trim()||"";if(!Number.isFinite(n)||n<=0||n>Number(r.balance||0))return toast("Enter a valid payment amount");if(d>todayISO())return toast("Future dates are not allowed");r.history=Array.isArray(r.history)?r.history:[];r.statusOverride=null;r.history.push({date:d,type:tab==="receivable"?"Received":"Paid",amount:n,note,source:"add_payment"});reconcileDebtRecord(r);save();modal="debtDetail";render()}
function editDebt(tab,id){const {r}=findDebt(tab,id);if(!r)return;window.debtEditTab=tab;window.debtEditId=id;modal="editDebt";render()}
function editDebtForm(){let tab=window.debtEditTab||"receivable",{r}=findDebt(tab,window.debtEditId);return `<h2>Edit ${tab==="receivable"?"Leny Hain":"Deny Hain"}</h2><div class="form"><div class="field"><label>Name</label><input id="debt_edit_name" value="${esc(r?.name||"")}"></div><div class="field"><label>Phone</label><input id="debt_edit_phone" inputmode="tel" value="${esc(r?.phone||"")}"></div><div class="row"><div class="field"><label>Original Amount</label><input id="debt_edit_original" type="number" value="${Number(r?.original??r?.balance??0)}"></div><div class="field"><label>Remaining Amount</label><input id="debt_edit_balance" type="number" value="${Number(r?.balance??0)}"></div></div><div class="field"><label>Description / Note</label><textarea id="debt_edit_desc">${esc(r?.desc||"")}</textarea></div><button class="btn primary wide" onclick="saveDebtEdit()">Save Changes</button></div>`}
function saveDebtEdit(){let tab=window.debtEditTab||"receivable",{r}=findDebt(tab,window.debtEditId);if(!r)return;let name=document.getElementById("debt_edit_name")?.value.trim(),phone=normalizePhone(document.getElementById("debt_edit_phone")?.value),original=Number(document.getElementById("debt_edit_original")?.value||0),balance=Number(document.getElementById("debt_edit_balance")?.value||0),desc=(document.getElementById("debt_edit_desc")?.value||"").trim();if(!name||!Number.isFinite(original)||original<=0||!Number.isFinite(balance)||balance<0||balance>original)return toast("Enter valid debt details");r.name=name;r.phone=phone;r.original=original;r.desc=desc;r.statusOverride=null;reconcileDebtRecord(r);save();modal="debtDetail";window.debtDetailTab=tab;window.debtDetailId=r.id;render()}
function deleteDebt(tab,id){const {arr,r}=findDebt(tab,id);if(!r)return;if(!confirm("Delete this customer record?"))return;const key=tab==="receivable"?"receivables":"payables";S.records[key]=arr.filter(x=>x.id!==id);save();modal="lend";window.debtTab=tab;render()}
function openDebtDetail(tab,id){const {r}=findDebt(tab,id);if(!r)return;window.debtDetailTab=tab;window.debtDetailId=id;modal="debtDetail";render()}
function debtDetail(){
 const tab=window.debtDetailTab||"receivable",{r}=findDebt(tab,window.debtDetailId);
 if(!r)return `<h2>Record not found</h2>`;
 reconcileDebtRecord(r);
 const payments=debtPaymentEntries(r).slice().reverse();
 const additions=debtAdditionEntries(r).slice().reverse();
 const legacy=(Array.isArray(r.history)?r.history:[]).filter(h=>h&&h.source==="legacy_note"&&((h.note||"").trim()||Number(h.legacyAmount||0)>0));
 const paid=debtAppliedPayments(r);
 const timeline=[...additions.map(h=>({...h,_kind:"Added"})),...payments.map(h=>({...h,_kind:tab==="receivable"?"Received":"Paid"})),...legacy.map(h=>({...h,_kind:"Note"}))].sort((a,b)=>String(b.date||"").localeCompare(String(a.date||"")));
 const paymentHtml=timeline.map(h=>{
   const label=h._kind==="Added"?"Hisab Added":h._kind==="Note"?"Description / Note":h._kind;
   const value=h._kind==="Note"?(h.note?esc(h.note):"Note"):money(h.amount);
   return `<div class="summaryline"><span>${fmt(validDate(h.date||todayISO()))}<br><small>${esc(label)}${h.note&&h._kind!=="Note"?` • ${esc(h.note)}`:""}</small></span><strong>${value}</strong></div>`;
 }).join("")||`<div class="muted">No details yet.</div>`;
 return `<h2>${esc(r.name)} — ${tab==="receivable"?"Leny Hain":"Deny Hain"}</h2>
 <div class="summary"><div class="summaryline"><span>Original</span><strong>${money(r.original||0)}</strong></div><div class="summaryline"><span>Paid / Received</span><strong>${money(paid)}</strong></div><div class="summaryline"><span>Remaining</span><strong>${money(r.balance)}</strong></div><div class="summaryline"><span>Status</span><strong>${r.balance<=0?"Paid":(r.status||"Unpaid")}</strong></div></div>
 ${r.desc?`<div class="section-title">Description / Note</div><div class="debt-desc">${esc(r.desc)}</div>`:""}
 <div class="section-title">Date-wise Hisab History</div>${paymentHtml}
 ${debtContactButtons(r.phone)}
 <div class="actions" style="margin-top:12px"><button class="btn primary" onclick="addDebtPayment('${tab}','${r.id}')">＋ Add Payment</button><button class="btn soft" onclick="shareDebtReceipt('${tab}','${r.id}')">WhatsApp Receipt</button><button class="btn soft" onclick="window.print()">Print / PDF</button><button class="btn green" onclick="modal='lend';window.debtTab='${tab}';render()">Done</button></div>`;
}
function shareDebtReceipt(tab,id){const {r}=findDebt(tab,id);if(!r)return;reconcileDebtRecord(r);const payments=debtPaymentEntries(r);const lines=["My Shop — Hisab Receipt",`Customer: ${r.name}`,`Type: ${tab==="receivable"?"Leny Hain":"Deny Hain"}`,`Original: ${money(r.original||0)}`];if(r.desc)lines.push(`Description: ${r.desc}`);lines.push("Date-wise payment history:",...(payments.length?payments.map(h=>`${fmt(validDate(h.date||todayISO()))} — ${h.type||"Payment"}: ${money(h.amount)}${h.note?` — ${h.note}`:""}`):["No payments added"]),`Remaining: ${money(r.balance)}`,`Status: ${r.balance<=0?"Paid":"Unpaid"}`);openContact("whatsapp",normalizePhone(r.phone||""),lines.join("\n"))}
function debtList(a){return list(a,x=>`${esc(x.name)}<div class="muted">${esc(x.phone)} • ${x.status}</div>`,x=>money(x.balance),x=>`<div class="contact"><button onclick="openContact('call','${esc(x.phone)}')">☎</button><button onclick="openContact('sms','${esc(x.phone)}')">SMS</button><button onclick="openContact('whatsapp','${esc(x.phone)}')">WA</button></div><button onclick="del('${a===S.records.receivables?'receivables':'payables'}','${x.id}')">🗑️</button>`) }
function reportDateRange(){
 let to=validDate(window.reportTo||todayISO()), from=validDate(window.reportFrom||to);
 if(from>to){let t=from;from=to;to=t}
 return {from,to};
}
function reportRows(){
 const {from,to}=reportDateRange(), inRange=x=>{const d=dateOf(x);return d&&d>=from&&d<=to};
 return {
  sales:S.records.sales.filter(inRange).slice().sort((a,b)=>String(dateOf(b)).localeCompare(String(dateOf(a)))),
  purchases:S.records.purchases.filter(inRange).slice().sort((a,b)=>String(dateOf(b)).localeCompare(String(dateOf(a)))),
  expenses:S.records.expenses.filter(inRange).slice().sort((a,b)=>String(dateOf(b)).localeCompare(String(dateOf(a))))
 };
}
function setReportRangeMonths(months){
 const to=todayISO(); const d=new Date(to+'T00:00:00'); d.setMonth(d.getMonth()-Number(months)+1); const from=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`;
 window.reportFrom=from;window.reportTo=to;render();
}
function setReportRangeYears(years){setReportRangeMonths(Number(years)*12)}
function reportAllRange(){
 const all=[...(S.records.sales||[]),...(S.records.purchases||[]),...(S.records.expenses||[])].map(dateOf).filter(Boolean).sort();
 window.reportFrom=all[0]||todayISO();window.reportTo=all.at(-1)||todayISO();render();
}
function reportProfit(r){return Number(r.amount||0)-Number(r.cost||0)}
function reportText(){
 const {from,to}=reportDateRange(),r=reportRows(),sales=sum(r.sales),purchases=sum(r.purchases),expenses=sum(r.expenses,x=>Number(x.amount||0)),gross=sum(r.sales,reportProfit),net=gross-expenses;
 const lines=[`MY SHOP — OFFICIAL BUSINESS REPORT`,`Period: ${fmt(from)} to ${fmt(to)}`,'',`TOTAL SALES: ${money(sales)}`,`TOTAL PURCHASES: ${money(purchases)}`,`TOTAL EXPENSES: ${money(expenses)}`,`TOTAL GROSS PROFIT: ${money(gross)}`,`PROFIT AFTER EXPENSES: ${money(net)}`,'','SALES'];
 r.sales.forEach(x=>lines.push(`${fmt(dateOf(x))} | ${x.product||''} | ${x.customer||'Cash Customer'} | ${money(x.amount)} | Profit ${money(reportProfit(x))}`));
 lines.push('','PURCHASES');r.purchases.forEach(x=>lines.push(`${fmt(dateOf(x))} | ${x.product||''} | ${x.supplier||'Not added'} | ${money(x.amount)}`));
 lines.push('','EXPENSES');r.expenses.forEach(x=>lines.push(`${fmt(dateOf(x))} | ${x.name||'Expense'} | ${money(x.amount)}${x.desc?` | ${x.desc}`:''}`));
 return lines.join('\n');
}
function shareFullReport(){
 const text=reportText();
 if(navigator.share){navigator.share({title:'My Shop Official Report',text}).catch(()=>{});return}
 const url=`https://wa.me/?text=${encodeURIComponent(text)}`;
 if(window.AndroidApp&&typeof window.AndroidApp.openExternal==='function'){try{window.AndroidApp.openExternal('whatsapp','',text);return}catch(e){}}
 location.href=url;
}
function reportSection(title,rows,kind){
 const type=kind==='sale'?'sales':kind==='purchase'?'purchases':'expenses';
 const amountLabel=kind==='sale'?'Sales':kind==='purchase'?'Purchases':'Expenses';
 if(!rows.length)return `<div class="report-section"><button type="button" class="report-section-head report-section-open" onclick="openReportDetail('${type}')"><b>${title}</b><span>0 entries ›</span></button><div class="muted report-empty">No entries in selected period.</div></div>`;
 const body=rows.slice(0,5).map(x=>{
  const date=fmt(dateOf(x)), name=kind==='expense'?(x.name||'Expense'):(x.product||'Record');
  const sub=kind==='sale'?`Sold to: ${esc(x.customer||'Cash Customer')} • ${esc(x.phone||'No phone')}`:kind==='purchase'?`Purchased from: ${esc(x.supplier||'Not added')}${x.condition?` • ${esc(x.condition)}`:''}`:`${esc(x.desc||'Expense')}`;
  const amount=Number(x.amount||0), extra=kind==='sale'?`Profit ${money(reportProfit(x))}`:'';
  return `<button class="report-entry" type="button" onclick="viewRecord('${type}','${x.id}')"><span><b>${esc(name)}</b><small>${date} • ${sub}</small></span><strong>${money(amount)}${extra?`<em>${extra}</em>`:''}</strong></button>`;
 }).join('');
 return `<div class="report-section"><button type="button" class="report-section-head report-section-open" onclick="openReportDetail('${type}')"><b>${title}</b><span>${rows.length} entries ›</span></button><div class="report-entry-list">${body}</div>${rows.length>5?`<button class="btn soft wide report-view-all" onclick="openReportDetail('${type}')">View Full ${amountLabel} Report</button>`:''}</div>`;
}
function reportPeriodButton(label,onclick,active){return `<button type="button" class="${active?'active-report-period':''}" onclick="${onclick}">${label}</button>`}
function reports(){
 const {from,to}=reportDateRange(),r=reportRows(),sales=sum(r.sales),purchases=sum(r.purchases),expenses=sum(r.expenses,x=>Number(x.amount||0)),gross=sum(r.sales,reportProfit),net=gross-expenses;
 const activeMonths=(window.reportPresetMonths||null), activeYears=(window.reportPresetYears||null), all=window.reportPresetAll===true;
 return `<div class="report-page"><div class="report-hero"><div><div class="report-kicker">MY SHOP • OFFICIAL REPORT</div><h2>Business Reports</h2><p>${fmt(from)} — ${fmt(to)}</p></div><div class="report-mark">MS</div></div>
 <div class="report-range"><div class="field"><label>From</label><input id="report_from" type="date" value="${from}" onchange="window.reportFrom=this.value;window.reportPresetMonths=null;window.reportPresetYears=null;window.reportPresetAll=false;render()"></div><div class="field"><label>To</label><input id="report_to" type="date" value="${to}" onchange="window.reportTo=this.value;window.reportPresetMonths=null;window.reportPresetYears=null;window.reportPresetAll=false;render()"></div></div>
 <div class="report-presets">${reportPeriodButton('1 Month','setReportRangeMonths(1)',activeMonths===1)}${reportPeriodButton('2 Months','setReportRangeMonths(2)',activeMonths===2)}${reportPeriodButton('3 Months','setReportRangeMonths(3)',activeMonths===3)}${reportPeriodButton('6 Months','setReportRangeMonths(6)',activeMonths===6)}${reportPeriodButton('1 Year','setReportRangeMonths(12)',activeMonths===12)}${reportPeriodButton('2 Years','setReportRangeYears(2)',activeYears===2)}${reportPeriodButton('3 Years','setReportRangeYears(3)',activeYears===3)}${reportPeriodButton('5 Years','setReportRangeYears(5)',activeYears===5)}${reportPeriodButton('All','reportAllRange()',all)}</div>
 <div class="report-summary-grid"><button class="report-summary-card" onclick="openReportDetail('sales')"><span>Total Sales</span><b>${money(sales)}</b><small>View full sales ›</small></button><button class="report-summary-card" onclick="openReportDetail('purchases')"><span>Total Purchases</span><b>${money(purchases)}</b><small>View full purchases ›</small></button><button class="report-summary-card" onclick="openReportDetail('expenses')"><span>Total Expenses</span><b>${money(expenses)}</b><small>View full expenses ›</small></button><div><span>Total Gross Profit</span><b>${money(gross)}</b></div><div class="report-net"><span>Profit After Expenses</span><b>${money(net)}</b></div></div>
 ${reportSection('Sales',r.sales,'sale')}${reportSection('Purchases',r.purchases,'purchase')}${reportSection('Expenses',r.expenses,'expense')}
 <div class="report-actions"><button class="btn primary" onclick="window.print()">🖨 Print / PDF</button><button class="btn green" onclick="shareFullReport()">💬 Share All Reports</button></div>
 </div>`;
}
function setReportRangeMonths(months){
 const to=todayISO(); const d=new Date(to+'T00:00:00'); d.setMonth(d.getMonth()-Number(months)+1); const from=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`;
 window.reportFrom=from;window.reportTo=to;window.reportPresetMonths=Number(months);window.reportPresetYears=null;window.reportPresetAll=false;render();
}
function setReportRangeYears(years){window.reportPresetYears=Number(years);window.reportPresetMonths=null;window.reportPresetAll=false;setReportRangeMonths(Number(years)*12)}
function reportAllRange(){
 const all=[...(S.records.sales||[]),...(S.records.purchases||[]),...(S.records.expenses||[])].map(dateOf).filter(Boolean).sort();
 window.reportFrom=all[0]||todayISO();window.reportTo=all.at(-1)||todayISO();window.reportPresetAll=true;window.reportPresetMonths=null;window.reportPresetYears=null;render();
}
function openReportDetail(type){window.reportDetailType=type;window.reportReturnModal='reports';modal='reportDetail';render()}
function reportDetail(){
 const type=window.reportDetailType||'sales', labels={sales:'Sales Report',purchases:'Purchases Report',expenses:'Expenses Report'}, r=reportRows()[type]||[];
 const rows=r.map(x=>{
   const name=type==='expenses'?(x.name||'Expense'):(x.product||'Record');
   const sub=type==='sales'?`Sold to: ${esc(x.customer||'Cash Customer')} • ${esc(x.phone||'No phone')}`:type==='purchases'?`Purchased from: ${esc(x.supplier||'Not added')}${x.condition?` • ${esc(x.condition)}`:''}`:`${esc(x.desc||'Expense')}`;
   const amt=Number(x.amount||0), extra=type==='sales'?`Profit ${money(reportProfit(x))}`:'';
   return `<button type="button" class="report-detail-row" onclick="viewRecord('${type}','${x.id}')"><span><b>${esc(name)}</b><small>${fmt(dateOf(x))} • ${sub}</small></span><strong>${money(amt)}${extra?`<em>${extra}</em>`:''}</strong></button>`;
 }).join('');
 const total=type==='expenses'?sum(r,x=>Number(x.amount||0)):sum(r,x=>Number(x.amount||0));
 return `<div class="report-detail-page"><div class="report-hero"><div><div class="report-kicker">MY SHOP • OFFICIAL REPORT</div><h2>${labels[type]}</h2><p>${fmt(reportDateRange().from)} — ${fmt(reportDateRange().to)}</p></div><div class="report-mark">MS</div></div><div class="summary"><div class="summaryline"><span>Total ${type==='sales'?'Sales':type==='purchases'?'Purchases':'Expenses'}</span><strong>${money(total)}</strong></div><div class="summaryline"><span>Entries</span><strong>${r.length}</strong></div></div><div class="section-title">${labels[type]} Entries</div><div class="report-detail-list">${rows||'<div class="summary muted">No entries in selected period.</div>'}</div><div class="report-actions"><button class="btn soft" onclick="closeModal()">← Back to Reports</button><button class="btn primary" onclick="window.print()">🖨 Print / PDF</button><button class="btn green" onclick="shareReportSection('${type}')">💬 Share on WhatsApp</button></div></div>`;
}
function shareReportSection(type){
 const r=reportRows()[type]||[], names={sales:'SALES REPORT',purchases:'PURCHASES REPORT',expenses:'EXPENSES REPORT'};
 const lines=[`MY SHOP — ${names[type]}`,`Period: ${fmt(reportDateRange().from)} to ${fmt(reportDateRange().to)}`,`Entries: ${r.length}`];
 r.forEach(x=>lines.push(`${fmt(dateOf(x))} | ${type==='expenses'?(x.name||'Expense'):(x.product||'Record')} | ${money(x.amount||0)}${type==='sales'?` | Profit ${money(reportProfit(x))}`:''}`));
 const text=lines.join('\n'); const url=`https://wa.me/?text=${encodeURIComponent(text)}`;
 if(window.AndroidApp&&typeof window.AndroidApp.openExternal==='function'){try{window.AndroidApp.openExternal('whatsapp','',text);return}catch(e){}}
 if(navigator.share){navigator.share({title:names[type],text}).catch(()=>{});return}
 location.href=url;
}
function subscription(){
  const sub=S.subscription||{};
  const paidActive=sub.status==="active" && (!sub.activeUntil || Date.now()<new Date(sub.activeUntil));
  const paidExpired=sub.status==="active" && sub.activeUntil && Date.now()>=new Date(sub.activeUntil);
  const trial=(!paidActive&&!paidExpired&&sub.status!=="active"&&trialDays()>0);
  const daysLeft=paidActive&&sub.activeUntil?Math.max(0,Math.ceil((new Date(sub.activeUntil)-Date.now())/86400000)):trial?trialDays():0;
  const latest=sub.paymentStatus||"";
  const status=paidActive?"Subscription Active":paidExpired?"Subscription Expired":latest==="pending"?"Payment Pending":latest==="rejected"?"Payment Rejected":trial?"Free Trial Active":"Subscription Inactive";
  const statusClass=paidActive?"green":paidExpired||latest==="rejected"?"red":latest==="pending"?"yellow":"";
  const dates=paidActive||paidExpired?`<div class="sub-dates"><div><span>Activated</span><b>${sub.activatedAt?fmt(sub.activatedAt.slice(0,10)):"—"}</b></div><div><span>Expires</span><b>${sub.activeUntil?fmt(sub.activeUntil.slice(0,10)):"—"}</b></div></div>`:"";
  const remaining=paidActive?`<div class="sub-remaining"><b>${daysLeft}</b> day(s) remaining</div>`:trial?`<div class="sub-remaining">Free trial: <b>${daysLeft}</b> day(s) remaining</div>`:"";
  const paymentInfo=latest?`<div class="sub-payment-status"><b>Latest Payment: ${esc(latest)}</b>${sub.paymentMethod?`<span>${esc(sub.paymentMethod)}</span>`:""}${sub.paymentTx?`<span>TX: ${esc(sub.paymentTx)}</span>`:""}</div>`:"";
  return `<h2>Subscription</h2><div class="paycard"><h3>My Shop Premium</h3><div style="font-size:30px;font-weight:900">Rs. 699 <span class="muted">/ 30 Days</span></div><div class="sub-status ${statusClass}"><span class="sub-dot"></span><b>${status}</b></div>${dates}${remaining}${paymentInfo}<div class="paymethod"><b>EasyPaisa</b><button class="copy" onclick="copy('PK95TMFB0000000087508632')">Copy</button><div class="muted">PK95TMFB0000000087508632</div></div><div class="paymethod"><b>JazzCash</b><button class="copy" onclick="copy('PK83JCMA2402923020890766')">Copy</button><div class="muted">PK83JCMA2402923020890766</div></div><div class="paymethod"><b>HBL Konnect</b><button class="copy" onclick="copy('PK38HABB0164030081358087')">Copy</button><div class="muted">PK38HABB0164030081358087</div></div><div class="field"><label>Payment Method</label><select id="pay_method"><option>EasyPaisa</option><option>JazzCash</option><option>HBL Konnect</option></select></div><div class="field"><label>Transaction ID</label><input id="pay_tx"></div><div class="field"><label>Payment Screenshot</label><input id="pay_img" type="file" accept="image/*"></div><button class="btn primary wide" onclick="submitPayment()">Submit Payment for Approval</button></div>`
}

function settings(){let themes=["default","dark","purple","red","blue","yellow","pink","orange","ocean","royal","sunset","emerald","rose","slate","neon","coffee","lavender"];let names={default:"Classic",dark:"Midnight",purple:"Royal Purple",red:"Ruby",blue:"Ocean Blue",yellow:"Golden",pink:"Pink Glow",orange:"Orange Fire",ocean:"Aqua",royal:"Royal",sunset:"Sunset",emerald:"Emerald",rose:"Rose",slate:"Slate",neon:"Neon",coffee:"Coffee",lavender:"Lavender"};let preview={default:"linear-gradient(135deg,#111827,#2563eb,#7c3aed)",dark:"linear-gradient(135deg,#05060a,#312e81,#ec4899)",purple:"linear-gradient(135deg,#2e1065,#7e22ce,#be185d)",red:"linear-gradient(135deg,#450a0a,#be123c,#f97316)",blue:"linear-gradient(135deg,#082f49,#1d4ed8,#06b6d4)",yellow:"linear-gradient(135deg,#422006,#ca8a04,#f97316)",pink:"linear-gradient(135deg,#500724,#db2777,#7e22ce)",orange:"linear-gradient(135deg,#431407,#ea580c,#f59e0b)",ocean:"linear-gradient(135deg,#083344,#0891b2,#1d4ed8)",royal:"linear-gradient(135deg,#2e1065,#7c3aed,#c026d3)",sunset:"linear-gradient(135deg,#431407,#ea580c,#be123c)",emerald:"linear-gradient(135deg,#022c22,#059669,#0e7490)",rose:"linear-gradient(135deg,#4c0519,#e11d48,#be185d)",slate:"linear-gradient(135deg,#0f172a,#334155,#64748b)",neon:"linear-gradient(135deg,#052e16,#166534,#06b6d4)",coffee:"linear-gradient(135deg,#451a03,#92400e,#d97706)",lavender:"linear-gradient(135deg,#4c1d95,#9333ea,#c026d3)"};return `<h2>Settings</h2><div class="form"><div class="field"><label>Shop Name</label><input id="set_shop" value="${esc(S.settings.shopName)}"></div><div class="field"><label>Shop Location</label><input id="set_location" value="${esc(S.settings.manualLocation||"")}" placeholder="e.g. Daharki Main Mobile Market"><div class="row" style="margin-top:8px"><button class="btn soft" onclick="setManualLocation()">Use Manual Location</button><button class="btn soft" onclick="requestCurrentLocation()">📍 Use Current Location</button></div><small class="muted">Current Location uses your phone's location permission. Manual Location lets you enter a city/market name.</small></div><div class="field"><label>Font Size</label><select id="set_font"><option value="small" ${S.settings.font==="small"?"selected":""}>Small</option><option value="medium" ${S.settings.font==="medium"?"selected":""}>Medium</option><option value="large" ${S.settings.font==="large"?"selected":""}>Large</option><option value="xlarge" ${S.settings.font==="xlarge"?"selected":""}>Extra Large</option><option value="xxlarge" ${S.settings.font==="xxlarge"?"selected":""}>2XL Large</option></select></div><div class="field"><label>Language</label><select id="set_lang"><option value="en">English</option><option value="ur">Urdu</option></select></div><div class="field"><label>Layout / Design</label><select id="set_layout">${Array.from({length:10},(_,i)=>`<option value="${i+1}" ${Number(S.settings.layout||1)===i+1?"selected":""}>Professional Layout ${i+1}</option>`).join("")}</select></div><button class="btn primary wide" onclick="saveSettings()">Save Settings</button><div class="section-title">Themes <small>Preview before applying</small></div><div class="theme-grid theme-preview-grid">${themes.map(t=>`<button class="theme theme-preview ${S.settings.theme===t?'sel':''}" style="--preview:${preview[t]}" onclick="S.settings.theme='${t}';save();render()"><span class="theme-preview-art"><i></i><b></b><em></em></span><span class="theme-name">${names[t]}</span><small>${S.settings.theme===t?'✓ Applied':'Tap to apply'}</small></button>`).join("")}</div></div>`}
function detailModal(){let r=selectedRecords(S.records.sales);return `<h2>Details — ${fmt(S.lastDate)}</h2><div class="summary"><b>Sales ${money(saleTotal())}</b><b>Purchases ${money(purchaseTotal())}</b><b>Expenses ${money(expenseTotal())}</b><b>Profit ${money(profit())}</b></div><div class="section-title">Sales</div>${list(r,x=>esc(x.product),x=>money(x.amount),x=>`<button onclick="editRecord('sales','${x.id}')">✏️</button><button onclick="del('sales','${x.id}')">🗑️</button>`)}` }
function investmentDetails(){let cats=["used","new","accessory"],labels={used:"Used Phones",new:"New Phones",accessory:"Accessories"};let blocks=cats.map(c=>{let rows=S.records.stock.filter(x=>x.category===c&&(c==="used"?x.available!==false:Number(x.qty||0)>0)),qty=sum(rows,x=>c==="used"?1:Number(x.qty||0)),amt=sum(rows,x=>Number(x.cost||0)*(c==="used"?1:Number(x.qty||0)));return `<button class="feature" onclick="stockFilter('${c}')"><span>${c==="used"?"📱":c==="new"?"📦":"🔌"}</span>${labels[c]}<div class="muted">Quantity: ${qty}</div><div>${money(amt)}</div></button>`}).join("");return `<h2>Total Investment</h2><div class="cards">${blocks}</div><div class="summary" style="margin-top:12px"><div class="summaryline"><span>Total Quantity</span><strong>${stockCounts().total}</strong></div><div class="summaryline"><span>Total Investment</span><strong>${money(investment())}</strong></div></div>`}
function scanner(){return `<h2>Voice Note / IMEI Scan</h2><p class="muted">Voice notes are saved with the record. IMEI scanning uses your phone camera and automatically fills the IMEI field after a successful scan.</p><button class="btn primary wide" onclick="startVoice()">🎙️ Start / Stop Voice Note</button><button class="btn soft wide" style="margin-top:8px" onclick="scanBarcode()">📷 Start Camera IMEI Scan</button><div id="scanout" class="summary" style="margin-top:12px">Ready.</div><button class="btn soft wide" style="margin-top:8px" onclick="window.scannedIMEI=window.scannedIMEI||'';modal='purchase';render()">← Back to Purchase</button>`}

function go(p){page=p;closeModal();render()} function stockFilter(c){window.stockCat=c;go("stock")}
function details(a){modal=a==="investment"?"investment":"details";render()}
function filterSaleProducts(){
 const cat=document.getElementById("sale_cat")?.value,s=document.getElementById("sale_product");
 if(!s)return;
 const rows=S.records.stock.filter(x=>x.category===cat&&x.available!==false&&(cat==="used"||Number(x.qty||0)>0));
 const wanted=window.salePreselect&&rows.some(x=>x.id===window.salePreselect)?window.salePreselect:null;
 s.innerHTML=(rows.length?rows.map(x=>`<option value="${x.id}">${esc(x.product)} — Purchase ${money(x.cost)}${x.imei?` — IMEI ${esc(x.imei)}`:""}</option>`).join(""):`<option value="">No available ${cat==='used'?'used phones':cat==='new'?'new phones':'accessories'}</option>`);
 if(wanted){s.value=wanted;autoSalePrice();} else if(rows.length){s.selectedIndex=0;window.salePreselect=s.value;autoSalePrice();} else {window.salePreselect=null;}
 // Defensive cleanup: Add Sale must never render a secondary suggestion list.
 document.querySelectorAll('#sale-suggestions,.sale-suggestions,.sale-products').forEach(el=>el.remove());
}
function selectSaleProduct(id){const st=S.records.stock.find(x=>x.id===id&&x.available!==false&&((x.category==='used')||(Number(x.qty||0)>0)));if(!st)return toast('Phone is no longer available');window.salePreselect=st.id;window.salePreselectCat=st.category;const cat=document.getElementById('sale_cat');if(cat)cat.value=st.category;const s=document.getElementById('sale_product');if(s){s.value=st.id;autoSalePrice();}}

function autoSalePrice(){let s=document.getElementById("sale_product");if(!s)return;let st=S.records.stock.find(x=>x.id===s.value),p=document.getElementById("sale_price");if(st&&p){p.dataset.purchase=st.cost||0;if(!p.value||Number(p.value)<=0)p.value=st.sale||""}}
function togglePurchaseFields(){let cat=document.getElementById("pur_cat")?.value,box=document.getElementById("purchase-extra");if(!box)return;box.innerHTML=cat==="used"?`<div class="field"><label>Purchase Price</label><input id="pur_price" type="number"></div><div class="field"><label>Supplier / Purchased From</label><input id="pur_supplier" placeholder="Name of the person/shop you bought it from"></div>`:`<div class="row"><div class="field"><label>Purchase Price</label><input id="pur_price" type="number"></div><div class="field"><label>Quantity</label><input id="pur_qty" type="number" value="1" min="1"></div></div><div class="field"><label>Supplier / Purchased From</label><input id="pur_supplier" placeholder="Name of the person/shop you bought it from"></div>`}
function viewRecord(type,id){
 let r=S.records[type].find(x=>x.id===id);if(!r)return;
 if(modal==="reports"||modal==="reportDetail")window.reportRecordReturn=modal;
 window.viewType=type;window.viewRecordData=r;modal="recordView";render()
}
function recordView(){let r=window.viewRecordData||{},type=window.viewType||"";let labels={date:"Date",product:"Product / Model",amount:"Amount",supplier:"Purchased From",customer:"Customer",phone:"Phone",cnic:"CNIC",category:"Category",quantity:"Quantity",condition:"Condition",imei:"IMEI / Barcode",desc:"Description",payment:"Payment",cost:"Purchase Cost",sale:"Sale Price"};let rows=Object.entries(r).filter(([k,v])=>k!=="voice"&&k!=="id"&&k!=="stockId"&&v!==""&&v!==null&&v!==undefined).map(([k,v])=>`<div class="summaryline record-detail-row"><span>${esc(labels[k]||k.replace(/_/g," ").replace(/\b\w/g,m=>m.toUpperCase()))}</span><strong>${esc(v)}</strong></div>`).join("");let voice=r.voice?`<div class="field"><label>Voice Note</label><audio controls preload="metadata" src="${esc(r.voice)}" style="width:100%"></audio></div>`:"";let phone=normalizePhone(r.phone||"");let contact=phone?`<div class="actions"><button class="btn soft" onclick="openContact('call','${esc(phone)}')">☎ Call</button><button class="btn soft" onclick="openContact('sms','${esc(phone)}')">SMS</button><button class="btn soft" onclick="openContact('whatsapp','${esc(phone)}')">WhatsApp</button></div>`:"";return `<h2>${type==="sales"?"Sale Details":type==="purchases"?"Purchase Details":type==="expenses"?"Expense Details":"Stock Details"}</h2><div class="summary record-details">${rows||`<div class="muted">No details available.</div>`}</div>${voice}${contact}${type==="sales"||type==="purchases"?`<div class="actions record-detail-actions"><button class="btn primary" onclick="shareReceipt('${type==="sales"?"sale":"purchase"}',window.viewRecordData)">Share to WhatsApp</button><button class="btn soft" onclick="window.print()">Print / PDF</button><button class="btn soft" onclick="closeModal();editRecord('${type}','${r.id}')">✏️ Edit</button></div>`:""}`}
function shareReceipt(type,r){let text=["My Shop Receipt",`Date: ${r.date||""}`,`${type==="sale"?"Sale":"Purchase"}: ${r.product||""}`,`Amount: ${money(r.amount||0)}`,r.customer?`Customer: ${r.customer}`:"",r.phone?`Phone: ${r.phone}`:""].filter(Boolean).join("\n"),phone=String(r.phone||"").replace(/\D/g,"");openContact("whatsapp",phone,text)}
function expenseDetails(){
 let rows=S.records.expenses.slice().sort((a,b)=>String(dateOf(b)).localeCompare(String(dateOf(a))));
 return `<h2>Expenses</h2><div class="summary"><div class="summaryline"><span>Total Expenses</span><strong>${money(expenseTotal())}</strong></div></div><div class="section-title">Expense Entries <small>${rows.length} entries</small></div><div class="detail-list">${rows.length?rows.map(x=>`<button type="button" class="detail-row" onclick="viewRecord('expenses','${x.id}')"><span><b>${esc(x.name||"Expense")}</b><small>${fmt(dateOf(x))}${x.desc?` • ${esc(x.desc)}`:""}</small></span><strong>${money(x.amount)}</strong></button>`).join(""):`<div class="summary muted">No expense entries yet.</div>`}</div><button type="button" class="btn primary wide add-bottom-btn" onclick="modal='expenseAdd';render()">＋ Add Expense</button>`
}
function profitDetails(){
 let rows=S.records.sales.slice().sort((a,b)=>String(dateOf(b)).localeCompare(String(dateOf(a))));
 let gross=totalGrossProfit(); let expenses=expenseTotal(); let net=gross-expenses;
 return `<h2>Profit</h2><div class="summary"><div class="summaryline"><span>Total Profit</span><strong>${money(gross)}</strong></div><div class="summaryline"><span>Less: Total Expenses</span><strong>${money(expenses)}</strong></div><div class="summaryline"><span>Profit After Expenses</span><strong>${money(net)}</strong></div></div><div class="section-title">Profit Entries <small>${rows.length} entries</small></div><div class="detail-list">${rows.length?rows.map(x=>{let gp=Number(x.amount||0)-Number(x.cost||0);return `<button type="button" class="detail-row" onclick="viewRecord('sales','${x.id}')"><span><b>${esc(x.product||"Sale")}</b><small>${fmt(dateOf(x))}${x.customer?` • ${esc(x.customer)}`:""}</small></span><strong>${money(gp)}</strong></button>`}).join(""):`<div class="summary muted">No profit entries yet.</div>`}</div>`
}
function editRecord(type,id){let r=S.records[type]?.find(x=>x.id===id);if(!r)return;window.editType=type;window.editId=id;modal="editRecord";render()}
function editRecordForm(){
 let type=window.editType||"",r=S.records[type]?.find(x=>x.id===window.editId)||{},isSale=type==="sales",isPurchase=type==="purchases",isExpense=type==="expenses",isStock=type==="stock";
 return `<h2>Edit ${isSale?"Sale":isPurchase?"Purchase":isExpense?"Expense":"Stock"}</h2><div class="form">
 ${!isStock?`<div class="field"><label>Date</label><input id="edit_date" type="date" max="${todayISO()}" value="${esc(validDate(r.date||""))}"></div>`:""}
 <div class="field"><label>Product / Name</label><input id="edit_product" value="${esc(r.product||r.name||"")}"></div>
 <div class="row"><div class="field"><label>${isSale?"Sale Price":isPurchase||isExpense?"Amount":"Purchase Cost"}</label><input id="edit_amount" type="number" value="${Number(r.amount??r.cost??0)}"></div>
 ${isPurchase?`<div class="field"><label>Quantity</label><input id="edit_qty" type="number" min="1" value="${Number(r.quantity||1)}"></div>`:""}</div>
 ${isSale?`<div class="row"><div class="field"><label>Customer</label><input id="edit_customer" value="${esc(r.customer||"")}"></div><div class="field"><label>Phone</label><input id="edit_phone" value="${esc(r.phone||"")}"></div></div>`:""}
 ${isPurchase?`<div class="field"><label>Purchased From</label><input id="edit_supplier" value="${esc(r.supplier||"")}"></div>`:""}
 <div class="field"><label>Description</label><textarea id="edit_desc">${esc(r.desc||"")}</textarea></div>
 <button class="btn primary wide" onclick="saveEditedRecord()">Save Changes</button></div>`;
}
function saveEditedRecord(){
 let type=window.editType,r=S.records[type]?.find(x=>x.id===window.editId);if(!r)return;
 let amount=Number(document.getElementById("edit_amount")?.value||0);if(!Number.isFinite(amount)||amount<=0)return toast("Enter a valid amount");
 let product=(document.getElementById("edit_product")?.value||"").trim();if(!product)return toast("Enter a name/product");
 if(document.getElementById("edit_date")){r.date=document.getElementById("edit_date").value;if(r.date>todayISO())return toast("Future dates are not allowed");}
 if("product"in r)r.product=product;else if("name"in r)r.name=product;
 if("amount"in r)r.amount=amount;else r.cost=amount;
 if(document.getElementById("edit_qty")){let q=Number(document.getElementById("edit_qty").value);if(!Number.isInteger(q)||q<1)return toast("Invalid quantity");r.quantity=q}
 if(type==="sales"){r.customer=document.getElementById("edit_customer")?.value.trim()||"";r.phone=normalizePhone(document.getElementById("edit_phone")?.value)}
 if(type==="purchases")r.supplier=document.getElementById("edit_supplier")?.value.trim()||"";
 r.desc=document.getElementById("edit_desc")?.value.trim()||"";
 if(type==="purchases"&&r.stockId){
   const st=S.records.stock.find(x=>x.id===r.stockId||x.purchaseId===r.id);
   if(st){st.product=r.product;st.cost=Number(r.amount||0)/(Math.max(1,Number(r.quantity||1)));st.qty=st.category==="used"?1:Math.max(1,Number(r.quantity||1));st.condition=r.condition||st.condition;st.imei=r.imei||st.imei;st.supplier=r.supplier||"";st.purchaseId=r.id;}
 }
 if(type==="stock"&&r.purchaseId){
   const p=S.records.purchases.find(x=>x.id===r.purchaseId);if(p){p.product=r.product;p.amount=Number(r.cost||0)*(p.category==="used"?1:Number(p.quantity||r.qty||1));p.condition=r.condition||p.condition;}
 }
 ensureStockIntegrity();save();closeModal();render();
}
function del(type,id){
 let arr=S.records[type];if(!Array.isArray(arr))return;let r=arr.find(x=>x.id===id);if(!r)return;
 if(type==="sales"&&r.stockId){let st=S.records.stock.find(x=>x.id===r.stockId);if(st){if(st.category==="used")st.available=true;else st.qty=Number(st.qty||0)+1;}}
 if(type==="purchases"&&r.stockId){
  let sold=S.records.sales.some(x=>x.stockId===r.stockId);
  if(sold)return toast("This purchase is linked to a sale and cannot be deleted");
  S.records.stock=S.records.stock.filter(x=>x.id!==r.stockId);
 }
 if(type==="stock"&&S.records.sales.some(x=>x.stockId===id))return toast("Sold stock cannot be deleted");
 if(!confirm("Delete this record?"))return;
 S.records[type]=arr.filter(x=>x.id!==id);save();render();
}
function normalizePhone(v){let p=String(v||"").replace(/\s|-/g,"").trim();if(p.startsWith("+92"))p="0"+p.slice(3);else if(p.startsWith("0092"))p="0"+p.slice(4);return p.replace(/[^0-9]/g,"")}
function signup(){
 let name=document.getElementById("s_name").value.trim(),phone=normalizePhone(document.getElementById("s_phone").value),pass=document.getElementById("s_pass").value,shop=(document.getElementById("s_shop").value||"My Shop").trim();
 if(!name||!phone||pass.length<4)return toast("Enter name, valid phone and a 4+ character password");
 let users=JSON.parse(localStorage.getItem(USERS_KEY)||"[]");
 if(users.some(x=>normalizePhone(x.phone)===phone))return toast("Account already exists");
 let u={phone,name,pass,shopName:shop,createdAt:new Date().toISOString()};
 users.push(u);localStorage.setItem(USERS_KEY,JSON.stringify(users));switchAccount(u);closeModal();render();
}
function doLogin(){
 let p=normalizePhone(document.getElementById("lphone").value),pass=document.getElementById("lpass").value;
 let users=JSON.parse(localStorage.getItem(USERS_KEY)||"[]"),u=users.find(x=>normalizePhone(x.phone)===p&&x.pass===pass);
 if(!u)return toast("Invalid phone or password");
 switchAccount(u);render();
}
function resetPass(){
 let p=normalizePhone(document.getElementById("f_phone").value),n=document.getElementById("f_pass").value,users=JSON.parse(localStorage.getItem(USERS_KEY)||"[]"),u=users.find(x=>normalizePhone(x.phone)===p);
 if(!u)return toast("No account found for this number");
 if(n.length<4)return toast("Password must be at least 4 characters");
 u.pass=n;localStorage.setItem(USERS_KEY,JSON.stringify(users));toast("Password changed");closeModal();render();
}
function addExpense(){
 if(!active())return toast("Subscription expired");
 let date=document.getElementById("e_date").value,name=document.getElementById("e_name").value.trim(),amount=Number(document.getElementById("e_amt").value),desc=document.getElementById("e_desc").value.trim();
 if(!date||date>todayISO()||!name||!Number.isFinite(amount)||amount<=0)return toast("Enter a valid past/today date, expense name and amount");
 S.records.expenses.push({id:uid(),date,name,amount,desc});save();modal="expenses";render();
}

function saveSale(receipt=false){
 if(!active())return toast("Subscription expired");
 let st=S.records.stock.find(x=>x.id===document.getElementById("sale_product").value);
 if(!st||st.available===false||(st.category!=="used"&&(Number(st.qty)||0)<1))return toast("Select available stock");
 let price=Number(document.getElementById("sale_price").value||0);
 if(!Number.isFinite(price)||price<=0)return toast("Enter a valid sale price");
 let rec={id:uid(),stockId:st.id,date:document.getElementById("sale_date").value,product:st.product,category:st.category,amount:price,cost:Number(st.cost||0),
 customer:document.getElementById("sale_customer").value.trim(),phone:normalizePhone(document.getElementById("sale_phone").value),cnic:document.getElementById("sale_cnic").value.trim(),
 condition:document.getElementById("sale_condition").value,payment:document.getElementById("sale_payment").value,desc:document.getElementById("sale_desc").value.trim(),voice:window.lastVoiceData||""};
 if(!rec.date||rec.date>todayISO())return toast("Future dates are not allowed");
 if(st.category==="used")st.available=false;else st.qty=Math.max(0,(Number(st.qty)||0)-1);
 S.records.sales.push(rec);window.lastVoiceData="";window.scannedIMEI="";window.salePreselect=null;save();closeModal();render();if(receipt)shareReceipt("sale",rec);
}
function savePurchase(receipt=false){
 if(!active())return toast("Subscription expired");
 let cat=document.getElementById("pur_cat").value,qty=cat==="used"?1:Number(document.getElementById("pur_qty")?.value||1),cost=Number(document.getElementById("pur_price").value||0),prod=document.getElementById("pur_product").value.trim(),supplier=(document.getElementById("pur_supplier")?.value||"").trim(),date=document.getElementById("pur_date").value;
 if(!date||date>todayISO()||!prod||!Number.isFinite(cost)||cost<=0)return toast("Enter a valid past/today date, product and purchase price");
 if(!Number.isInteger(qty)||qty<1)return toast("Quantity must be 1 or more");
 let stockId=uid(),rec={id:uid(),stockId,date,product:prod,amount:cost*qty,supplier,imei:document.getElementById("pur_imei").value.trim(),cnic:document.getElementById("pur_cnic").value.trim(),desc:document.getElementById("pur_desc").value.trim(),category:cat,quantity:qty,condition:document.getElementById("pur_condition").value,voice:window.lastVoiceData||""};
 S.records.purchases.push(rec);S.records.stock.push({id:stockId,category:cat,product:prod,cost,sale:0,qty,condition:rec.condition,available:true,imei:rec.imei,supplier:rec.supplier,date:rec.date,purchaseId:rec.id});
 window.lastVoiceData="";window.scannedIMEI="";save();closeModal();render();if(receipt)shareReceipt("purchase",rec);
}
function saveSettings(){
 S.settings.shopName=(document.getElementById("set_shop").value||"My Shop").trim()||"My Shop";
 S.settings.font=document.getElementById("set_font").value;S.settings.lang=document.getElementById("set_lang").value;S.settings.layout=Number(document.getElementById("set_layout")?.value||S.settings.layout||1);
 let users=JSON.parse(localStorage.getItem(USERS_KEY)||"[]"),u=users.find(x=>normalizePhone(x.phone)===normalizePhone(S.user?.phone));
 if(u){u.name=S.user.name;u.shopName=S.settings.shopName;localStorage.setItem(USERS_KEY,JSON.stringify(users))}
 save();closeModal();render();
}
async function copy(t){try{await navigator.clipboard?.writeText(t);toast("Copied")}catch{toast("Copy not available")}}
function submitTestPayment(){
  if(!S.user)return toast("Please login first");
  const tx="TEST-"+Date.now();
  S.payments.push({id:uid(),date:new Date().toISOString(),method:"TEST",tx,status:"pending",amount:0,screenshotName:""});
  save();
  if(window.submitTestPaymentCloud) return window.submitTestPaymentCloud(tx);
  toast("Test payment request submitted");
  render();
}

function submitPayment(){
 if(!S.user)return toast("Please log in");
 let tx=document.getElementById("pay_tx").value.trim();if(!tx)return toast("Enter transaction ID");
 let img=document.getElementById("pay_img")?.files?.[0];
 S.payments.push({id:uid(),date:new Date().toISOString(),method:document.getElementById("pay_method").value,tx,status:"pending",screenshotName:img?.name||""});save();toast("Payment submitted for approval");
}
async function backup(){
 if(window.cloudBackup){await window.cloudBackup();return}
 let payload={version:11.5,exportedAt:new Date().toISOString(),shopName:S.settings.shopName,user:S.user,settings:S.settings,subscription:S.subscription,records:S.records,payments:S.payments,lastDate:S.lastDate};
 let blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="my-shop-backup.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function restore(e){
 let f=e.target.files?.[0];if(!f)return;let r=new FileReader();
 r.onload=()=>{try{let b=JSON.parse(r.result);if(!b||!b.records||!b.settings)throw Error("invalid");S=mergeState({...b,user:S.user});save();render();toast("Backup restored")}catch{toast("Invalid backup file")}};
 r.readAsText(f);e.target.value="";
}
function exportReport(type){
 let rows=[["Date","Type","Product","Amount","Customer/Supplier"],...S.records.sales.map(x=>[x.date,"Sale",x.product,x.amount,x.customer||""]),...S.records.purchases.map(x=>[x.date,"Purchase",x.product,x.amount,x.supplier||""]),...S.records.expenses.map(x=>[x.date,"Expense",x.name,x.amount,""])];
 let csv=rows.map(r=>r.map(v=>`"${String(v??"").replaceAll('"','""')}"`).join(",")).join("\n"),a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download="my-shop-report.csv";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
async function startVoice(){
 if(window._rec){window._rec.stop();return}
 if(!navigator.mediaDevices?.getUserMedia||!("MediaRecorder" in window))return toast("Voice recording is not supported in this browser");
 try{
  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
  const types=["audio/webm;codecs=opus","audio/webm","audio/mp4"];
  const mime=types.find(t=>MediaRecorder.isTypeSupported?.(t))||"";
  const rec=new MediaRecorder(stream,mime?{mimeType:mime}:undefined),chunks=[];
  window._rec=rec;window.voiceRecordingStarted=Date.now();
  rec.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data)};
  rec.onerror=()=>{stream.getTracks().forEach(t=>t.stop());window._rec=null;toast("Voice recording failed")};
  rec.onstop=()=>{stream.getTracks().forEach(t=>t.stop());const blob=new Blob(chunks,{type:rec.mimeType||"audio/webm"});if(!blob.size){window._rec=null;return toast("No voice was recorded")};const reader=new FileReader();reader.onload=()=>{window.lastVoiceData=reader.result;window._rec=null;toast("Voice note recorded — save the record to keep it")};reader.readAsDataURL(blob)};
  rec.start(250);toast("Recording started — tap again to stop");
 }catch(e){window._rec=null;toast(e?.name==="NotAllowedError"?"Please allow microphone permission for My Shop":"Microphone could not be started")}
}
async function scanBarcode(){
 const out=document.getElementById("scanout");if(!out)return;
 if(!navigator.mediaDevices?.getUserMedia)return out.textContent="Camera is not available. Use HTTPS/Chrome and allow Camera permission.";
 let st=null,v=null,stopped=false;
 const finish=(value)=>{if(stopped)return;stopped=true;const code=String(value||"").trim();if(st)st.getTracks().forEach(t=>t.stop());if(code){window.scannedIMEI=code;out.innerHTML=`<b>Scanned IMEI:</b> ${esc(code)}<br><span class="muted">Saved to the purchase form.</span>`;toast("IMEI scanned");setTimeout(()=>{modal="purchase";render()},500)}else out.textContent="No barcode found."};
 try{
  st=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"}}});
  v=document.createElement("video");v.autoplay=true;v.playsInline=true;v.muted=true;v.style.width="100%";out.innerHTML="Point the camera at the IMEI barcode…";out.appendChild(v);v.srcObject=st;await v.play();
  if("BarcodeDetector" in window){
   let formats=["code_128","code_39","ean_13","ean_8","upc_a","upc_e","qr_code","data_matrix","itf","codabar"];
   try{if(BarcodeDetector.getSupportedFormats){const supported=await BarcodeDetector.getSupportedFormats();formats=formats.filter(f=>supported.includes(f));}}catch{}
   const det=new BarcodeDetector({formats:formats.length?formats:["code_128"]});
   const loop=async()=>{if(stopped)return;try{const codes=await det.detect(v);if(codes?.length)return finish(codes[0].rawValue)}catch{}requestAnimationFrame(loop)};loop();
  }else{
   out.innerHTML="This Chrome build does not provide native barcode scanning. Please use a current Chrome on HTTPS, or enter the IMEI manually.";
  }
 }catch(e){if(st)st.getTracks().forEach(t=>t.stop());out.textContent=e?.name==="NotAllowedError"?"Camera permission denied. Allow Camera for My Shop and try again.":"Camera scan unavailable. Enter IMEI manually."}
}
window.addEventListener("click",e=>{if(window._rec && e.target.textContent.includes("Start / Stop")){window._rec.stop();window._rec=null}});
render();
