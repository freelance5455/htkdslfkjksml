My Shop v11.14 — Official Multi-Period Reports

Preserves the finalized v9.3 build and only fixes the requested issues:
- Device-local current date now updates correctly in Pakistan/other local time zones and rolls over automatically at the new day.
- IMEI/barcode camera scan now captures the scanned value and returns it into the Purchase IMEI field; camera/permission handling improved.
- Voice recording handling improved with browser capability checks, stable MediaRecorder MIME selection, saved voice data, and playback in record details.
- Leny Hain / Deny Hain records now support full edit (name, phone, original amount, remaining amount, description).
- Leny Hain / Deny Hain records now show Call, SMS, and WhatsApp actions when a phone number is present.
- Existing themes, subscription/admin, location, stock, sales, purchases, expenses, reports, backup/restore, WhatsApp receipts and other finalized features are preserved.

Supabase integration remains unchanged except that the fixed local record behavior continues to sync through the existing integration layer.
