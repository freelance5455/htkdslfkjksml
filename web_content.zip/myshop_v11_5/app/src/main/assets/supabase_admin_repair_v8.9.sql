-- My Shop v8.9 FINAL admin-role repair
-- Run once in Supabase SQL Editor.
-- This does NOT expose or require a service-role key.

create or replace function public.claim_admin_by_phone()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_phone text;
  v_email text;
begin
  if v_uid is null then
    return false;
  end if;

  select u.phone, u.email
    into v_phone, v_email
  from auth.users u
  where u.id = v_uid;

  -- The app uses a private email alias for phone/password login.
  v_phone := regexp_replace(
    coalesce(nullif(v_phone, ''), split_part(coalesce(v_email, ''), '@', 1)),
    '[^0-9]', '', 'g'
  );

  if v_phone in ('03020890766', '923020890766', '00923020890766') then
    update public.profiles
       set role = 'admin',
           phone = '03020890766'
     where id = v_uid;
  end if;

  return exists (
    select 1 from public.profiles
    where id = v_uid and role = 'admin'
  );
end;
$$;

revoke all on function public.claim_admin_by_phone() from public;
grant execute on function public.claim_admin_by_phone() to authenticated;

-- Immediately claim the currently logged-in test account if it is the admin number.
select public.claim_admin_by_phone();
