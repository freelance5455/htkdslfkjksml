window.MYSHOP_CONFIG = {
  supabaseUrl: "https://cgcwbzpwmgleofcucrly.supabase.co",
  supabaseAnonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNnY3dienB3bWdsZW9mY3Vjcmx5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA4NzM4NjAsImV4cCI6MjEwNjQ0OTg2MH0.bdrkFbvQ_s6sbYJa6KiFSDWx0SiUd-yTbBNGc_oeto0",
  adminPhone: "03020890766",
  cloudSync: true
};