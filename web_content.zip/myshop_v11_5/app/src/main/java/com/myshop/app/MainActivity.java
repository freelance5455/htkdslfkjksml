package com.myshop.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.DownloadListener;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 9001;
    private static final int PERMISSION_REQUEST = 9002;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        requestRuntimePermissions();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setUserAgentString(s.getUserAgentString() + " MyShopAndroid/1.0");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternal(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternal(url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_REQUEST); }
                catch (ActivityNotFoundException e) { fileCallback = null; return false; }
                return true;
            }
        });
    }

    private boolean handleExternal(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();

        if (scheme.equals("tel")) {
            openIntent(new Intent(Intent.ACTION_DIAL, uri));
            return true;
        }
        if (scheme.equals("sms")) {
            openIntent(new Intent(Intent.ACTION_SENDTO, uri));
            return true;
        }
        if (scheme.equals("mailto")) {
            openIntent(new Intent(Intent.ACTION_SENDTO, uri));
            return true;
        }
        if (scheme.equals("geo")) {
            openIntent(new Intent(Intent.ACTION_VIEW, uri));
            return true;
        }
        if (scheme.equals("whatsapp")) {
            String phone = uri.getQueryParameter("phone");
            if (phone == null || phone.isEmpty()) phone = uri.getPath() == null ? "" : uri.getPath().replace("/", "");
            String text = uri.getQueryParameter("text");
            openWhatsApp(phone, text);
            return true;
        }
        if (scheme.equals("intent")) {
            try { startActivity(Intent.parseUri(url, Intent.URI_INTENT_SCHEME)); }
            catch (Exception ignored) { }
            return true;
        }
        if (scheme.equals("http") || scheme.equals("https")) {
            if (host.equals("wa.me") || host.endsWith(".wa.me") || host.equals("api.whatsapp.com") || host.equals("web.whatsapp.com")) {
                String phone = uri.getPath() == null ? "" : uri.getPath().replaceAll("/", "");
                String text = uri.getQueryParameter("text");
                openWhatsApp(phone, text);
                return true;
            }
            return false;
        }
        return false;
    }


    private void openWhatsApp(String phone, String text) {
        String clean = phone == null ? "" : phone.replaceAll("\\D", "");
        if (clean.startsWith("0")) clean = "92" + clean.substring(1);
        Uri.Builder b = Uri.parse("whatsapp://send").buildUpon().appendQueryParameter("phone", clean);
        if (text != null && !text.isEmpty()) b.appendQueryParameter("text", text);
        Intent wa = new Intent(Intent.ACTION_VIEW, b.build());
        wa.setPackage("com.whatsapp");
        if (!openIntent(wa)) {
            Uri.Builder web = Uri.parse("https://wa.me/" + clean).buildUpon();
            if (text != null && !text.isEmpty()) web.appendQueryParameter("text", text);
            openIntent(new Intent(Intent.ACTION_VIEW, web.build()));
        }
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void openExternal(String kind, String phone, String text) {
            runOnUiThread(() -> {
                String p = phone == null ? "" : phone.replaceAll("\\D", "");
                if (p.startsWith("0")) p = "92" + p.substring(1);
                try {
                    if ("call".equals(kind)) {
                        openIntent(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + (phone == null ? "" : phone))));
                    } else if ("sms".equals(kind)) {
                        openIntent(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + (phone == null ? "" : phone))));
                    } else if ("whatsapp".equals(kind)) {
                        openWhatsApp(p, text);
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not open contact app", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    private boolean openIntent(Intent intent) {
        try { startActivity(intent); return true; }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "Required app is not installed", Toast.LENGTH_SHORT).show(); return false; }
    }

    private void requestRuntimePermissions() {
        List<String> needed = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CAMERA);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), PERMISSION_REQUEST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
