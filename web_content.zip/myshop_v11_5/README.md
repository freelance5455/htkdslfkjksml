My Shop v11.7 — Sales Details + Working Account Backup

Locked baseline:
- Built directly from My Shop v11.5-LISTS-COLLAPSED.
- Existing finalized features and fixes are preserved; this upgrade changes only the explicitly requested Sales/Backup behavior.

Requested upgrades included:
- Available Phones: removed Sale Price from the phone details.
- Available Phones: shows Purchased from and Purchased date.
- Purchased date format is exactly DD-MMM-YYYY, e.g. 02-Oct-2026.
- Removed the large “+ Sale From Available Phone” button.
- Added a single + button below the available-phone category area; tapping it opens the sale form.
- Sold Phones: shows model, Sold to customer name, Contact number, and date in the same DD-MMM-YYYY format.
- Current Sales: explicitly shows Sold to customer and Contact number.
- Backup: performs a real cloud backup tied to the authenticated shop account using Supabase Auth user metadata. The complete app snapshot (records, settings, subscription state, payments and date state) is attached to the same account and can be recovered after the same phone number + password login on another phone.
- No SQL, database column, storage bucket, or Supabase dashboard change is required for Backup.
- Backup now shows a clear success/failure message instead of silently doing nothing.

Verification:
- JavaScript syntax checked with Node.js for app.js and supabase-integration.js.
- No existing feature files were removed or rearranged.
