Files in current directory: ['VORTEX_AI_MOBILE_COMPLETE.zip', 'VORTEX_AI_MOBILE_OFFLINE.zip', 'VORTEX_MOBILE_OFFLINE.zip', 'script-ai-platform-complete.zip', 'VORTEX_APPLICATION_THAI.zip', 'VORTEX_ENGLAND_TO_THAI_2_FILES.zip', '(1)VORTEX_ENGINE_DELTA-2.5.zip', 'VORTEX_SCRIPTS_THAI.zip', 'Vortex Engine Delta(1).lua', 'Vortex Engine Delta.lua', 'Vortex Key System.lua']
Found ZIP: VORTEX_AI_MOBILE_COMPLETE.zip
  - VORTEX_AI_MOBILE_OFFLINE/README.md
  - VORTEX_AI_MOBILE_OFFLINE/package.json
  - VORTEX_AI_MOBILE_OFFLINE/backend/server.js
  - VORTEX_AI_MOBILE_OFFLINE/frontend/index.html
  - VORTEX_AI_MOBILE_OFFLINE/frontend/style.css
  - VORTEX_AI_MOBILE_OFFLINE/frontend/app.js
Found ZIP: VORTEX_AI_MOBILE_OFFLINE.zip
  - README_TH.txt
  - VORTEX_AI_MOBILE_OFFLINE/
  - VORTEX_AI_MOBILE_OFFLINE/.env.example
  - VORTEX_AI_MOBILE_OFFLINE/README.md
  - VORTEX_AI_MOBILE_OFFLINE/README_TH.txt
  - VORTEX_AI_MOBILE_OFFLINE/backend/
  - VORTEX_AI_MOBILE_OFFLINE/backend/server.js
  - VORTEX_AI_MOBILE_OFFLINE/frontend/
  - VORTEX_AI_MOBILE_OFFLINE/frontend/app.js
  - VORTEX_AI_MOBILE_OFFLINE/frontend/index.html
  - VORTEX_AI_MOBILE_OFFLINE/frontend/style.css
  - VORTEX_AI_MOBILE_OFFLINE/package.json
  - app.js
  - index.html
  - style.css
Found ZIP: VORTEX_MOBILE_OFFLINE.zip
  - index.html
  - style.css
  - app.js
  - README_TH.txt
Found ZIP: script-ai-platform-complete.zip
  - script-ai-platform-complete/
  - script-ai-platform-complete/.env.example
  - script-ai-platform-complete/README.md
  - script-ai-platform-complete/backend/
  - script-ai-platform-complete/backend/mailer.js
  - script-ai-platform-complete/backend/server.js
  - script-ai-platform-complete/frontend/
  - script-ai-platform-complete/frontend/app.js
  - script-ai-platform-complete/frontend/index.html
  - script-ai-platform-complete/frontend/style.css
  - script-ai-platform-complete/package.json
Found ZIP: VORTEX_APPLICATION_THAI.zip
  - Web_App/index.html
  - Web_App/style.css
  - Web_App/app.js
  - Web_App/config.json
  - Desktop_App/vortex_app.py
  - README_TH.txt
Found ZIP: VORTEX_ENGLAND_TO_THAI_2_FILES.zip
  - Vortex_Thai_Delta.lua
  - Vortex_Thai_Full_Delta.lua
Found ZIP: (1)VORTEX_ENGINE_DELTA-2.5.zip
  - (1)VORTEX_ENGINE_DELTA-2.5/
  - (1)VORTEX_ENGINE_DELTA-2.5/VORTEX_SCRIPTS_England/
  - (1)VORTEX_ENGINE_DELTA-2.5/VORTEX_SCRIPTS_England/Vortex_England_Delta.lua
  - (1)VORTEX_ENGINE_DELTA-2.5/VORTEX_SCRIPTS_England/Vortex_England_Full_Delta.lua
  - (1)VORTEX_ENGINE_DELTA-2.5/VORTEX_SCRIPTS_KEY/
  - (1)VORTEX_ENGINE_DELTA-2.5/VORTEX_SCRIPTS_KEY/Vortex Key System.lua
  - (1)VORTEX_ENGINE_DELTA-2.5/VORTEX_SCRIPTS_THAI/
  - (1)VORTEX_ENGINE_DELTA-2.5/VORTEX_SCRIPTS_THAI/VORTEX_Thai_DELTA_.lua
  - (1)VORTEX_ENGINE_DELTA-2.5/VORTEX_SCRIPTS_THAI/VORTEX_Thai_FULL_COMPACT.lua
Found ZIP: VORTEX_SCRIPTS_THAI.zip
  - VORTEX_ENGINE_DELTA_540.lua
  - VORTEX_FULL_COMPACT.lua

