require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { GoogleGenAI } = require('@google/genai');

const app = express();
app.use(cors());
app.use(express.json());

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
const modelName = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

// ฐานข้อมูลจำลองในหน่วยความจำ (เก็บ Username & Password)
const usersStore = new Map();

// 1. API สมัครสมาชิก (ใช้แค่ username และ password)
app.post('/api/register', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่านให้ครบถ้วน' });
    }
    if (password.length < 4) {
        return res.status(400).json({ error: 'รหัสผ่านต้องมีความยาวอย่างน้อย 4 หลัก' });
    }
    if (usersStore.has(username)) {
        return res.status(400).json({ error: 'ชื่อผู้ใช้นี้ถูกใช้งาน, กรุณาใช้ชื่ออื่น' });
    }

    // บันทึกบัญชีผู้ใช้
    usersStore.set(username, { username, password });
    res.json({ success: true, message: 'สมัครสมาชิกสำเร็จ!', username });
});

// 2. API เข้าสู่ระบบ (Login)
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน' });
    }

    const user = usersStore.get(username);
    if (!user || user.password !== password) {
        return res.status(400).json({ error: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
    }

    res.json({ success: true, message: 'เข้าสู่ระบบสำเร็จ!', username });
});

// 3. API แชทกับ Script AI
app.post('/api/chat', async (req, res) => {
    try {
        const { message, confirmed } = req.body;
        if (!message) return res.status(400).json({ error: 'กรุณาส่งข้อความ' });

        const systemInstruction = `คุณคือ "Script AI" ผู้ช่วยเขียนโค้ดและพัฒนาสคริปต์ระดับสูง 
กฎการทำงานของคุณ:
1. คุณเชี่ยวชาญการเขียนโค้ดทุกภาษา โดยเฉพาะ Lua, Luau (Roblox), Python, JavaScript, HTML/CSS และสามารถเขียนโค้ดผสมผสานโครงสร้างข้ามภาษาได้อย่างยืดหยุ่น
2. หากผู้ใช้สั่งให้ "สร้าง" หรือ "เขียนสคริปต์" หรือ "ทำระบบ" และสถานะการยืนยัน (confirmed) ยังเป็น false:
   - ห้ามสร้างโค้ดฉบับเต็มทันที!
   - ให้วิเคราะห์ความต้องการ ถามคำถามเพิ่มเติมสั้นๆ เพื่อความชัดเจน และจบประโยคด้วยคำถามบังคับว่า: "คุณต้องการให้เริ่มทำหรือสร้างเลยหรือไม่?"
3. หากสถานะการยืนยัน (confirmed) เป็น true หรือผู้ใช้กดยืนยันให้เริ่มสร้างแล้ว:
   - ให้ลงมือเขียนโค้ดหรือสร้างสคริปต์ฉบับสมบูรณ์อย่างละเอียดและใช้งานได้จริงทันที!`;

        const promptContent = confirmed ? `[ผู้ใช้กดยืนยันให้เริ่มสร้างแล้ว] คำสั่งเดิม: ${message}` : message;

        const response = await ai.models.generateContent({
            model: modelName,
            contents: promptContent,
            config: { systemInstruction }
        });

        const reply = response.text || "ขออภัย ไม่สามารถประมวลผลได้ในขณะนี้";
        const askConfirmation = !confirmed && reply.includes("คุณต้องการให้เริ่มทำหรือสร้างเลยหรือไม่");

        res.json({ reply, askConfirmation });
    } catch (error) {
        console.error("Gemini API Error:", error);
        res.status(500).json({ error: 'เกิดข้อผิดพลาดในการติดต่อกับ AI' });
    }
});

// เสิร์ฟหน้าเว็บ Frontend
app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.get(/.*/, (_req, res) => {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

const PORT = process.env.PORT || 10000;
app.listen(PORT, () => {
    console.log(`SCRIPT AI OS running on port ${PORT}`);
});
