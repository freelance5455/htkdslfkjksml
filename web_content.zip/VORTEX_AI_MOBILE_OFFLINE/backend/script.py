# Let's inspect the files in the workspace or check if there's any newly uploaded zip or what the user meant.
import os, zipfile

print("Files in current directory:", os.listdir("."))
for f in os.listdir("."):
    if f.endswith(".zip"):
        print("Found ZIP:", f)
        with zipfile.ZipFile(f, "r") as z:
            for name in z.namelist():
                print("  -", name)

