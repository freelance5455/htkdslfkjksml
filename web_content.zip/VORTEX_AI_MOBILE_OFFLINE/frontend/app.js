const DEFAULT_CONFIG = {
  AutoCycle: false,
  AutoRegrab: true,
  SmartAvoid: true,
  AntiAFK: true,
  RigSyncEnabled: true,
  StuckRecovery: true,
  SpeedCap: 1.20,
  HopRatio: 1.515,
  HopMin: 40,
  HopLift: 42,
  CarryRatio: 0.90,
  CycleInterval: 0.35
};

let config = { ...DEFAULT_CONFIG };
let startTime = Date.now();
let cycleCount = 0;

const TOGGLE_META = [
  { key: "AutoCycle", title: "AI ทำงานอัตโนมัติต่อเนื่อง", desc: "วนลูปค้นหาและจัดการเป้าหมายโดย AI" },
  { key: "AutoRegrab", title: "ระบบเก็บคืนอัตโนมัติ", desc: "ดึงวัตถุกลับทันทีเมื่อหลุดระหว่างเคลื่อนที่" },
  { key: "SmartAvoid", title: "AI หลบสิ่งกีดขวางอัจฉริยะ", desc: "คำนวณเส้นทางอ้อมพอร์ทัลและพื้นที่อันตราย" },
  { key: "RigSyncEnabled", title: "ระบบซิงค์แอนิเมชัน AI", desc: "รักษาท่าทางและการเคลื่อนไหวให้ราบรื่น" },
  { key: "StuckRecovery", title: "ระบบแก้ติดสิ่งกีดขวางอัตโนมัติ", desc: "กระโดดหรือขยับตัวเมื่อตัวละครติดค้าง" },
  { key: "AntiAFK", title: "ป้องกันหลุด AFK ออฟไลน์", desc: "ส่งสัญญาณควบคุมป้องกันการตัดการเชื่อมต่อ" }
];

const SLIDER_META = [
  { key: "SpeedCap", label: "ตัวคูณความเร็วสูงสุด (SpeedCap)", min: 0.8, max: 2.0, step: 0.05 },
  { key: "HopRatio", label: "อัตราส่วนระยะกระโดด (HopRatio)", min: 1.05, max: 2.2, step: 0.015 },
  { key: "HopMin", label: "ระยะกระโดดขั้นต่ำ (HopMin)", min: 20, max: 80, step: 2 },
  { key: "HopLift", label: "แรงยกตัวแนวตั้ง (HopLift)", min: 20, max: 75, step: 1 },
  { key: "CarryRatio", label: "ความเร็วขณะถือของ (CarryRatio)", min: 0.5, max: 1.3, step: 0.05 },
  { key: "CycleInterval", label: "หน่วงเวลาแต่ละรอบ (วินาที)", min: 0.1, max: 2.0, step: 0.05 }
];

function appendChatMessage(text, sender = 'ai') {
  const box = document.getElementById("chat-box");
  const msg = document.createElement("div");
  msg.className = `chat-msg ${sender === 'ai' ? 'ai-msg' : 'user-msg'}`;
  msg.textContent = text;
  box.appendChild(msg);
  box.scrollTop = box.scrollHeight;
}

function handleAIResponse(query) {
  const q = query.toLowerCase();
  setTimeout(() => {
    if (q.includes("สวัสดี") || q.includes("hi")) {
      appendChatMessage("สวัสดีครับ! ผม VORTEX AI พร้อมช่วยเหลือคุณในโหมดออฟไลน์แล้วครับ มีอะไรให้ผมช่วยปรับแต่งไหมครับ?");
    } else if (q.includes("รัน") || q.includes("รอบ")) {
      cycleCount += 1;
      document.getElementById("stat-cycles").textContent = `${cycleCount} รอบ`;
      appendChatMessage(`รับทราบครับ! AI สั่งรันระบบรอบที่ #${cycleCount} เรียบร้อยแล้ว`);
    } else if (q.includes("รีเซ็ต") || q.includes("ค่า")) {
      config = { ...DEFAULT_CONFIG };
      renderControls();
      updateLuaPreview();
      appendChatMessage("รีเซ็ตการตั้งค่าพารามิเตอร์ทั้งหมดกลับเป็นค่าเริ่มต้นของ AI แล้วครับ");
    } else {
      appendChatMessage(`เข้าใจคำสั่ง "${query}" แล้วครับ ระบบออฟไลน์ทำงานตามการตั้งค่าปัจจุบันเรียบร้อย`);
    }
  }, 350);
}

document.getElementById("send-btn").addEventListener("click", () => {
  const input = document.getElementById("chat-input");
  const val = input.value.trim();
  if (!val) return;
  appendChatMessage(val, 'user');
  input.value = "";
  handleAIResponse(val);
});

document.getElementById("chat-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    document.getElementById("send-btn").click();
  }
});

function renderControls() {
  const toggleContainer = document.getElementById("toggle-list");
  toggleContainer.innerHTML = "";
  TOGGLE_META.forEach((item) => {
    const row = document.createElement("div");
    row.className = "toggle-item";
    row.innerHTML = `
      <div>
        <div class="toggle-title">${item.title}</div>
        <div class="toggle-desc">${item.desc}</div>
      </div>
      <label class="switch">
        <input type="checkbox" ${config[item.key] ? "checked" : ""} data-key="${item.key}" />
        <span class="slider-round"></span>
      </label>
    `;
    row.querySelector("input").addEventListener("change", (e) => {
      config[item.key] = e.target.checked;
      if (item.key === "AntiAFK") {
        document.getElementById("stat-antiafk").textContent = config.AntiAFK ? "เปิดใช้งาน" : "ปิดใช้งาน";
      }
      updateLuaPreview();
    });
    toggleContainer.appendChild(row);
  });

  const sliderContainer = document.getElementById("slider-list");
  sliderContainer.innerHTML = "";
  SLIDER_META.forEach((item) => {
    const row = document.createElement("div");
    row.className = "slider-item";
    row.innerHTML = `
      <div class="slider-top">
        <span>${item.label}</span>
        <span id="val-${item.key}">${config[item.key]}</span>
      </div>
      <input type="range" min="${item.min}" max="${item.max}" step="${item.step}" value="${config[item.key]}" />
    `;
    row.querySelector("input").addEventListener("input", (e) => {
      const num = parseFloat(e.target.value);
      config[item.key] = num;
      document.getElementById(`val-${item.key}`).textContent = num;
      updateLuaPreview();
    });
    sliderContainer.appendChild(row);
  });
}

function updateLuaPreview() {
  const code = `-- VORTEX AI OFFLINE CONFIG (มือถือ)
local cfg = getgenv().VortexDelta and getgenv().VortexDelta.Config
if cfg then
    cfg.AutoCycle = ${config.AutoCycle}
    cfg.AutoRegrab = ${config.AutoRegrab}
    cfg.SmartAvoid = ${config.SmartAvoid}
    cfg.AntiAFK = ${config.AntiAFK}
    cfg.RigSyncEnabled = ${config.RigSyncEnabled}
    cfg.StuckRecovery = ${config.StuckRecovery}
    cfg.SpeedCap = ${config.SpeedCap}
    cfg.HopRatio = ${config.HopRatio}
    cfg.HopMin = ${config.HopMin}
    cfg.HopLift = ${config.HopLift}
    cfg.CarryRatio = ${config.CarryRatio}
    cfg.CycleInterval = ${config.CycleInterval}
end`;
  document.getElementById("lua-output").textContent = code;
}

document.getElementById("run-cycle-btn").addEventListener("click", () => {
  cycleCount += 1;
  document.getElementById("stat-cycles").textContent = `${cycleCount} รอบ`;
  document.getElementById("stat-state").textContent = "AI กำลังประมวลผล...";
  setTimeout(() => {
    document.getElementById("stat-state").textContent = "เชื่อมต่อออฟไลน์";
  }, 500);
});

document.getElementById("reset-config-btn").addEventListener("click", () => {
  config = { ...DEFAULT_CONFIG };
  renderControls();
  updateLuaPreview();
});

document.getElementById("copy-lua-btn").addEventListener("click", () => {
  const text = document.getElementById("lua-output").textContent;
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById("copy-lua-btn");
    btn.textContent = "คัดลอกเรียบร้อย!";
    setTimeout(() => (btn.textContent = "คัดลอกโค้ดตั้งค่า"), 1500);
  });
});

setInterval(() => {
  const sec = Math.floor((Date.now() - startTime) / 1000);
  const h = String(Math.floor(sec / 3600)).padStart(2, "0");
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2, "0");
  const s = String(sec % 60).padStart(2, "0");
  document.getElementById("stat-uptime").textContent = `${h}:${m}:${s}`;
}, 1000);

window.addEventListener("DOMContentLoaded", () => {
  renderControls();
  updateLuaPreview();
});
