(() => {
"use strict";
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const creditsEl = document.getElementById("credits");
const selectionTitle = document.getElementById("selectionTitle");
const selectionSub = document.getElementById("selectionSub");
const toastEl = document.getElementById("toast");
const modal = document.getElementById("modal");

let W=0,H=0,dpr=1, credits=5000, power=100, zoom=1, camX=0, camY=0;
let selected=null, placing=null, muted=false, lastToast=0;
let buildings=[], units=[], particles=[];
const costs={barracks:800,factory:1200,power:600};
const buildingNames={hq:"مركز القيادة",barracks:"الثكنات",factory:"مصنع المركبات",power:"محطة الطاقة"};
const world={w:2400,h:1800};
const rand=(a,b)=>a+Math.random()*(b-a);
function resize(){dpr=Math.min(window.devicePixelRatio||1,2);W=canvas.clientWidth;H=canvas.clientHeight;canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);draw();}
window.addEventListener("resize",resize);
function initial(){
 credits=5000;power=100;zoom=1;camX=world.w/2;camY=world.h/2;placing=null;selected=null;
 buildings=[{type:"hq",x:world.w/2,y:world.h/2,w:100,h:78,hp:100}];
 units=[{type:"tank",x:world.w/2+125,y:world.h/2+75,hp:100,targetX:null,targetY:null,selected:false}];
 particles=[];updateUI();draw();toast("تم تجهيز القاعدة. ابدأ البناء والاستكشاف.");
}
function screenToWorld(sx,sy){return {x:(sx-W/2)/zoom+camX,y:(sy-H/2)/zoom+camY};}
function worldToScreen(x,y){return {x:(x-camX)*zoom+W/2,y:(y-camY)*zoom+H/2};}
function clampCam(){camX=Math.max(0,Math.min(world.w,camX));camY=Math.max(0,Math.min(world.h,camY));}
function roundedRect(x,y,w,h,r,fill,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke();}}
function drawTerrain(){
 ctx.fillStyle="#687354";ctx.fillRect(0,0,W,H);
 // world-ground pattern
 const topLeft=screenToWorld(0,0), bottomRight=screenToWorld(W,H);
 const step=90;
 for(let y=Math.floor(topLeft.y/step)*step;y<bottomRight.y+step;y+=step){
  for(let x=Math.floor(topLeft.x/step)*step;x<bottomRight.x+step;x+=step){
   const s=worldToScreen(x,y);const n=((Math.sin(x*0.027)+Math.cos(y*0.031))*0.5);
   ctx.fillStyle=n>0.25?"#727b57":n<-.25?"#5f6c4d":"#697451";
   ctx.fillRect(s.x,s.y,step*zoom+1,step*zoom+1);
   // sparse sand patches
   if((Math.abs(Math.sin(x*0.011+y*0.017))>.91)){ctx.fillStyle="#9c8a5c33";ctx.beginPath();ctx.ellipse(s.x+step*zoom*.4,s.y+step*zoom*.55,step*zoom*.38,step*zoom*.24,.3,0,Math.PI*2);ctx.fill();}
  }
 }
 // grid hints
 ctx.strokeStyle="#d7d8a011";ctx.lineWidth=1;
 const grid=60;
 for(let x=Math.floor(topLeft.x/grid)*grid;x<bottomRight.x;x+=grid){let a=worldToScreen(x,topLeft.y),b=worldToScreen(x,bottomRight.y);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}
 for(let y=Math.floor(topLeft.y/grid)*grid;y<bottomRight.y;y+=grid){let a=worldToScreen(topLeft.x,y),b=worldToScreen(bottomRight.x,y);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}
 // road
 ctx.save();ctx.lineCap="round";ctx.strokeStyle="#55584b";ctx.lineWidth=76*zoom;ctx.beginPath();let p1=worldToScreen(150,world.h*.70),p2=worldToScreen(world.w*.40,world.h*.58),p3=worldToScreen(world.w*.72,world.h*.64),p4=worldToScreen(world.w+100,world.h*.38);ctx.moveTo(p1.x,p1.y);ctx.bezierCurveTo(p2.x,p2.y,p3.x,p3.y,p4.x,p4.y);ctx.stroke();ctx.strokeStyle="#a49a75";ctx.lineWidth=2*zoom;ctx.setLineDash([18*zoom,15*zoom]);ctx.beginPath();ctx.moveTo(p1.x,p1.y);ctx.bezierCurveTo(p2.x,p2.y,p3.x,p3.y,p4.x,p4.y);ctx.stroke();ctx.restore();
 // map edge vignette
 const grd=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.15,W/2,H/2,Math.max(W,H)*.8);grd.addColorStop(0,"#00000000");grd.addColorStop(1,"#10191455");ctx.fillStyle=grd;ctx.fillRect(0,0,W,H);
}
function drawBuilding(b){
 const p=worldToScreen(b.x,b.y),w=b.w*zoom,h=b.h*zoom;
 ctx.save();ctx.translate(p.x,p.y);
 // shadow
 ctx.fillStyle="#17201877";ctx.beginPath();ctx.ellipse(4*zoom,7*zoom,w*.7,h*.6,0,0,Math.PI*2);ctx.fill();
 if(b.type==="hq"){
  ctx.fillStyle="#48545a";ctx.beginPath();ctx.moveTo(-w*.55,-h*.15);ctx.lineTo(-w*.25,-h*.52);ctx.lineTo(w*.47,-h*.43);ctx.lineTo(w*.60,-h*.08);ctx.lineTo(w*.35,h*.44);ctx.lineTo(-w*.42,h*.42);ctx.closePath();ctx.fill();
  ctx.fillStyle="#87949a";ctx.fillRect(-w*.25,-h*.28,w*.52,h*.52);ctx.fillStyle="#d4b15f";ctx.fillRect(-w*.11,-h*.48,w*.22,h*.23);ctx.fillStyle="#283239";ctx.fillRect(-w*.09,h*.02,w*.18,h*.4);
  ctx.strokeStyle="#e1c675";ctx.lineWidth=2*zoom;ctx.strokeRect(-w*.25,-h*.28,w*.52,h*.52);
 }else if(b.type==="barracks"){
  ctx.fillStyle="#59665e";ctx.fillRect(-w*.48,-h*.35,w*.96,h*.7);ctx.fillStyle="#849083";ctx.fillRect(-w*.32,-h*.23,w*.64,h*.19);ctx.fillStyle="#303a38";ctx.fillRect(-w*.13,h*.08,w*.26,h*.27);ctx.fillStyle="#c3b26d";ctx.fillRect(-w*.4,-h*.43,w*.8,h*.07);
 }else if(b.type==="factory"){
  ctx.fillStyle="#515d61";ctx.fillRect(-w*.52,-h*.34,w*1.04,h*.68);ctx.fillStyle="#76858a";ctx.fillRect(-w*.37,-h*.26,w*.74,h*.2);ctx.fillStyle="#2b3539";ctx.fillRect(-w*.25,h*.03,w*.5,h*.31);ctx.fillStyle="#c9a34f";ctx.fillRect(-w*.47,-h*.46,w*.94,h*.08);
 }else{
  ctx.fillStyle="#5a6a63";ctx.fillRect(-w*.4,-h*.38,w*.8,h*.76);ctx.fillStyle="#c6b45c";ctx.fillRect(-w*.1,-h*.6,w*.2,h*.23);ctx.strokeStyle="#9ba89d";ctx.lineWidth=2*zoom;ctx.strokeRect(-w*.4,-h*.38,w*.8,h*.76);ctx.fillStyle="#e4c565";ctx.font=`bold ${22*zoom}px sans-serif`;ctx.textAlign="center";ctx.fillText("ϟ",0,8*zoom);
 }
 // selection ring
 if(selected===b){ctx.strokeStyle="#f4d16c";ctx.lineWidth=2;ctx.setLineDash([5,4]);ctx.beginPath();ctx.ellipse(0,0,w*.72,h*.72,0,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);}
 // health bar
 ctx.fillStyle="#29312c";ctx.fillRect(-w*.35,-h*.68,w*.7,4*zoom);ctx.fillStyle="#7cbd69";ctx.fillRect(-w*.35,-h*.68,w*.7*(b.hp/100),4*zoom);
 ctx.restore();
}
function drawTank(u){
 const p=worldToScreen(u.x,u.y),s=zoom;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(u.angle||0);
 ctx.fillStyle="#18211c99";ctx.beginPath();ctx.ellipse(2*s,5*s,30*s,19*s,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#2c3932";roundedRect(-28*s,-15*s,56*s,30*s,7*s,"#2e3a32","#18221d");
 ctx.fillStyle="#4d5d48";roundedRect(-20*s,-17*s,40*s,34*s,7*s,"#4d5d48","#8a9676");
 ctx.fillStyle="#738265";roundedRect(-12*s,-11*s,25*s,22*s,5*s,"#66775b","#303b2e");
 ctx.fillStyle="#889478";ctx.fillRect(-1*s,-4*s,32*s,8*s);ctx.fillStyle="#1d2821";ctx.fillRect(23*s,-3*s,13*s,6*s);
 ctx.fillStyle="#d2bb6b";ctx.fillRect(-20*s,-13*s,5*s,5*s);
 ctx.restore();
 if(u===selected){ctx.strokeStyle="#ffe078";ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(p.x,p.y,34*s,25*s,0,0,Math.PI*2);ctx.stroke();}
 const q=worldToScreen(u.x,u.y);ctx.fillStyle="#222";ctx.fillRect(q.x-19*zoom,q.y-27*zoom,38*zoom,4*zoom);ctx.fillStyle="#81c76a";ctx.fillRect(q.x-19*zoom,q.y-27*zoom,38*zoom*(u.hp/100),4*zoom);
}
function draw(){
 if(!W||!H)return;ctx.clearRect(0,0,W,H);drawTerrain();
 // sparse rocks and scrub, fixed to world
 const tl=screenToWorld(0,0),br=screenToWorld(W,H);
 for(let i=0;i<90;i++){let x=(i*197+73)%world.w,y=(i*283+119)%world.h;if(x<tl.x-30||x>br.x+30||y<tl.y-30||y>br.y+30)continue;
  const p=worldToScreen(x,y),r=(5+(i%9))*zoom;ctx.fillStyle=i%3===0?"#424b3b":"#777b5b";ctx.beginPath();ctx.ellipse(p.x,p.y,r,r*.65,(i%5)*.3,0,Math.PI*2);ctx.fill();if(i%4===0){ctx.strokeStyle="#9d986b";ctx.lineWidth=2*zoom;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x-4*zoom,p.y-10*zoom);ctx.stroke();}
 }
 buildings.forEach(drawBuilding);units.forEach(drawTank);
 // placement preview
 if(placing&&pointer.last){const p=screenToWorld(pointer.last.x,pointer.last.y),s=worldToScreen(p.x,p.y);ctx.save();ctx.globalAlpha=.65;ctx.strokeStyle="#f0d276";ctx.fillStyle="#d8c36a33";ctx.lineWidth=2;ctx.fillRect(s.x-35*zoom,s.y-27*zoom,70*zoom,54*zoom);ctx.strokeRect(s.x-35*zoom,s.y-27*zoom,70*zoom,54*zoom);ctx.restore();}
 // minimap
 drawMinimap();
}
function drawMinimap(){
 const mw=92,mh=65,x=W-mw-12,y=H-(window.innerWidth<window.innerHeight?220:145);
 if(y<145)return;
 roundedRect(x-4,y-4,mw+8,mh+8,7,"#111a20dd","#7b8989");
 ctx.fillStyle="#667451";ctx.fillRect(x,y,mw,mh);
 ctx.fillStyle="#9c8d67";ctx.fillRect(x+mw*.12,y+mh*.63,mw*.7,3);
 buildings.forEach(b=>{ctx.fillStyle=b.type==="hq"?"#e6c45f":"#c6d0b5";ctx.fillRect(x+b.x/world.w*mw-2,y+b.y/world.h*mh-2,5,5);});
 units.forEach(u=>{ctx.fillStyle="#a8d4ee";ctx.fillRect(x+u.x/world.w*mw-1.5,y+u.y/world.h*mh-1.5,4,4);});
 const viewW=W/zoom/world.w*mw,viewH=H/zoom/world.h*mh,vx=x+(camX-W/2/zoom)/world.w*mw,vy=y+(camY-H/2/zoom)/world.h*mh;
 ctx.strokeStyle="#fff";ctx.lineWidth=1;ctx.strokeRect(Math.max(x,vx),Math.max(y,vy),Math.min(viewW,mw),Math.min(viewH,mh));
}
const pointer={down:false,x:0,y:0,last:null,moved:false,mode:""};
function getPos(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}
canvas.addEventListener("pointerdown",e=>{if(e.button!==undefined&&e.button!==0)return;canvas.setPointerCapture?.(e.pointerId);const p=getPos(e);pointer.down=true;pointer.x=p.x;pointer.y=p.y;pointer.last=p;pointer.moved=false;pointer.mode="";});
canvas.addEventListener("pointermove",e=>{const p=getPos(e);pointer.last=p;if(pointer.down){const dx=p.x-pointer.x,dy=p.y-pointer.y;if(Math.abs(dx)+Math.abs(dy)>4)pointer.moved=true;if(pointer.moved){camX-=dx/zoom;camY-=dy/zoom;clampCam();pointer.x=p.x;pointer.y=p.y;pointer.mode="pan";draw();}}});
canvas.addEventListener("pointerup",e=>{if(!pointer.down)return;pointer.down=false;const p=getPos(e);if(pointer.moved){draw();return;}handleTap(p.x,p.y);});
canvas.addEventListener("pointercancel",()=>{pointer.down=false;});
function handleTap(sx,sy){
 const p=screenToWorld(sx,sy);
 if(placing){placeBuilding(placing,p.x,p.y);return;}
 // prioritize units then buildings
 let found=units.find(u=>Math.hypot(u.x-p.x,u.y-p.y)<38/zoom);
 if(found){selected=found;updateUI();draw();return;}
 found=buildings.find(b=>Math.abs(b.x-p.x)<b.w*.65&&Math.abs(b.y-p.y)<b.h*.65);
 if(found){selected=found;updateUI();draw();return;}
 if(selected&&selected.type==="tank"){selected.targetX=Math.max(20,Math.min(world.w-20,p.x));selected.targetY=Math.max(20,Math.min(world.h-20,p.y));toast("تم إصدار أمر الحركة.");}
 else if(selected&&selected.type==="hq"){toast("اختر دبابة ثم اضغط على الأرض لتحريكها.");}
 draw();
}
function placeBuilding(type,x,y){
 const cost=costs[type];if(credits<cost){toast("الموارد غير كافية.");placing=null;draw();return;}
 const w=type==="factory"?120:100,h=type==="factory"?82:70;
 const collision=buildings.some(b=>Math.abs(b.x-x)<(b.w+w)*.48&&Math.abs(b.y-y)<(b.h+h)*.48);
 if(collision){toast("المكان مزدحم. اختر مساحة فارغة.");return;}
 if(x<70||y<70||x>world.w-70||y>world.h-70){toast("هذا المكان خارج منطقة البناء.");return;}
 credits-=cost;buildings.push({type,x,y,w,h,hp:100,buildProgress:0});selected=buildings[buildings.length-1];placing=null;updateUI();toast("بدأ إنشاء "+buildingNames[type]+".");draw();
}
function updateUI(){
 creditsEl.textContent=credits.toLocaleString("en-US");
 document.getElementById("power").textContent=power+"%";
 if(!selected){selectionTitle.textContent="لا يوجد تحديد";selectionSub.textContent="اختر وحدة أو مبنى";return;}
 if(selected.type==="tank"){selectionTitle.textContent="دبابة مدرعة";selectionSub.textContent="وحدة متحركة • جاهزة للأوامر";}
 else{selectionTitle.textContent=buildingNames[selected.type]||"مبنى";selectionSub.textContent=selected.type==="hq"?"قاعدة رئيسية • جاهز":"مبنى • قيد التشغيل";}
}
function toast(msg){toastEl.textContent=msg;toastEl.classList.add("show");clearTimeout(lastToast);lastToast=setTimeout(()=>toastEl.classList.remove("show"),2200);}
function startBuild(type){if(placing){placing=null;draw();}if(selected&&selected.type==="tank"){toast("حدد مركز القيادة أو مبنى قبل البناء.");return;}placing=type;toast("اضغط على مكان فارغ لوضع "+buildingNames[type]+".");draw();}
document.querySelectorAll("[data-build]").forEach(b=>b.addEventListener("click",()=>startBuild(b.dataset.build)));
document.getElementById("makeTank").addEventListener("click",()=>{
 if(!buildings.some(b=>b.type==="factory")){toast("أنشئ مصنع المركبات أولاً.");return;}
 if(credits<700){toast("الموارد غير كافية لإنتاج دبابة.");return;}
 credits-=700;const f=buildings.find(b=>b.type==="factory");units.push({type:"tank",x:f.x+90,y:f.y+35,hp:100,targetX:null,targetY:null,selected:false});selected=units[units.length-1];updateUI();toast("تم إنتاج دبابة جديدة.");draw();
});
document.getElementById("zoomIn").addEventListener("click",()=>{zoom=Math.min(1.8,zoom*1.15);draw();});
document.getElementById("zoomOut").addEventListener("click",()=>{zoom=Math.max(.55,zoom/1.15);draw();});
document.getElementById("resetCam").addEventListener("click",()=>{camX=world.w/2;camY=world.h/2;zoom=1;draw();});
document.getElementById("soundToggle").addEventListener("click",e=>{muted=!muted;e.currentTarget.textContent=muted?"🔇 الصوت: إيقاف":"🔊 الصوت: تشغيل";toast(muted?"تم إيقاف الصوت (المؤثرات الصوتية ستضاف لاحقاً).":"تم تشغيل إعداد الصوت.");});
function showHelp(){modal.classList.remove("hidden");}
document.getElementById("helpBtn").addEventListener("click",showHelp);document.getElementById("closeModal").addEventListener("click",()=>modal.classList.add("hidden"));document.getElementById("okModal").addEventListener("click",()=>modal.classList.add("hidden"));
document.getElementById("restartBtn").addEventListener("click",initial);
function tick(){
 let changed=false;
 for(const u of units){if(u.targetX==null)continue;const dx=u.targetX-u.x,dy=u.targetY-u.y,d=Math.hypot(dx,dy);if(d<2){u.targetX=u.targetY=null;continue;}const step=Math.min(d,1.4);u.angle=Math.atan2(dy,dx);u.x+=dx/d*step;u.y+=dy/d*step;changed=true;}
 for(const b of buildings){if(b.buildProgress!==undefined&&b.buildProgress<100){b.buildProgress=Math.min(100,b.buildProgress+.15);}}
 if(changed)draw();requestAnimationFrame(tick);
}
resize();initial();tick();
setTimeout(showHelp,650);
})();