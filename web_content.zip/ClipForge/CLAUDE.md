# ClipForge

Personal Android video editor. Kotlin + Jetpack Compose + Media3 (ExoPlayer, Transformer, Effects).

## Commands
- Build: `./gradlew assembleDebug`
- Install on device: `./gradlew installDebug`

## Conventions
- UI only in `ui/`, editing logic only in `editor/`.
- Colors come from `ui/theme/Theme.kt` (`Palette`). Never hardcode colors in screens.
- Accent color is for the active/selected thing only.
- Sentence-case labels, short verbs ("Export", "Trim").
- minSdk 29 (no storage permission needed; MediaStore + Photo Picker).

## Roadmap
1. Text overlays  2. Multi-clip timeline  3. Music/audio  4. Speed  5. Filters (LUTs)  6. Export quality options
