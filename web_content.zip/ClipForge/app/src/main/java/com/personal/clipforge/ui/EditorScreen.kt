package com.personal.clipforge.ui

import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.personal.clipforge.editor.EditorViewModel
import kotlinx.coroutines.delay

private enum class Tool(val label: String) { Trim("Trim"), Adjust("Adjust") }

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val uri = state.uri ?: return

    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_OFF
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    // Live preview of brightness / contrast
    LaunchedEffect(state.brightness, state.contrast) {
        val fx = buildList {
            if (state.brightness != 0f) add(Brightness(state.brightness))
            if (state.contrast != 0f) add(Contrast(state.contrast))
        }
        player.setVideoEffects(fx)
    }

    // Keep playback inside the trimmed range
    LaunchedEffect(state.startMs, state.endMs) {
        while (true) {
            if (player.isPlaying && player.currentPosition >= state.endMs) {
                player.seekTo(state.startMs)
            }
            delay(60)
        }
    }

    var tool by remember { mutableStateOf(Tool.Trim) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.dismissMessage() }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(Modifier.weight(1f))
                Button(onClick = { vm.export() }, enabled = !state.exporting) {
                    Text(if (state.exporting) "Exporting…" else "Export")
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f).background(androidx.compose.ui.graphics.Color.Black),
                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }
            )

            Column(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tool.entries.forEach { t ->
                        FilterChip(
                            selected = tool == t,
                            onClick = { tool = t },
                            label = { Text(t.label) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))

                when (tool) {
                    Tool.Trim -> TrimPanel(
                        durationMs = state.durationMs,
                        startMs = state.startMs,
                        endMs = state.endMs,
                        onChange = { s, e ->
                            vm.setTrim(s, e)
                            player.seekTo(s)
                        }
                    )
                    Tool.Adjust -> {
                        LabeledSlider("Brightness", state.brightness, vm::setBrightness)
                        LabeledSlider("Contrast", state.contrast, vm::setContrast)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrimPanel(durationMs: Long, startMs: Long, endMs: Long, onChange: (Long, Long) -> Unit) {
    if (durationMs <= 0) {
        Text("Could not read video length.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(formatMs(startMs))
        Text("${formatMs(endMs - startMs)} selected", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(formatMs(endMs))
    }
    RangeSlider(
        value = startMs.toFloat()..endMs.toFloat(),
        onValueChange = { r -> onChange(r.start.toLong(), r.endInclusive.toLong()) },
        valueRange = 0f..durationMs.toFloat()
    )
}

@Composable
private fun LabeledSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Slider(value = value, onValueChange = onChange, valueRange = -1f..1f)
}

private fun formatMs(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}
