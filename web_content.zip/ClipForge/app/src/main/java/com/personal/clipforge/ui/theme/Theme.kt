package com.personal.clipforge.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Base = Color(0xFF12141A)      // app background
    val Panel = Color(0xFF1B1E27)     // toolbars, sheets
    val Raised = Color(0xFF252A36)    // sliders track, chips
    val Text = Color(0xFFE8EAF0)
    val TextDim = Color(0xFF8D93A5)
    val Accent = Color(0xFFF2A33A)    // playhead, selection, primary action
}

private val scheme = darkColorScheme(
    background = Palette.Base,
    surface = Palette.Panel,
    surfaceVariant = Palette.Raised,
    onBackground = Palette.Text,
    onSurface = Palette.Text,
    onSurfaceVariant = Palette.TextDim,
    primary = Palette.Accent,
    onPrimary = Color(0xFF1A1205),
)

@Composable
fun ClipForgeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
