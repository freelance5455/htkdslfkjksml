package com.personal.clipforge.editor

import android.app.Application
import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

data class EditorState(
    val uri: Uri? = null,
    val durationMs: Long = 0,
    val startMs: Long = 0,
    val endMs: Long = 0,
    val brightness: Float = 0f,   // -1..1
    val contrast: Float = 0f,     // -1..1
    val exporting: Boolean = false,
    val message: String? = null,
)

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state.asStateFlow()

    private var transformer: Transformer? = null

    fun load(uri: Uri) {
        val retriever = MediaMetadataRetriever()
        val duration = try {
            retriever.setDataSource(getApplication(), uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            retriever.release()
        }
        _state.value = EditorState(uri = uri, durationMs = duration, endMs = duration)
    }

    fun setTrim(startMs: Long, endMs: Long) = _state.update { it.copy(startMs = startMs, endMs = endMs) }
    fun setBrightness(v: Float) = _state.update { it.copy(brightness = v) }
    fun setContrast(v: Float) = _state.update { it.copy(contrast = v) }
    fun dismissMessage() = _state.update { it.copy(message = null) }

    @OptIn(UnstableApi::class)
    fun export() {
        val s = _state.value
        val uri = s.uri ?: return
        if (s.exporting) return

        val context = getApplication<Application>()
        val outFile = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")

        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(s.startMs)
                    .setEndPositionMs(s.endMs)
                    .build()
            )
            .build()

        val videoEffects = buildList {
            if (s.brightness != 0f) add(Brightness(s.brightness))
            if (s.contrast != 0f) add(Contrast(s.contrast))
        }

        val edited = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    val saved = saveToGallery(outFile)
                    outFile.delete()
                    _state.update {
                        it.copy(
                            exporting = false,
                            message = if (saved) "Saved to Movies/ClipForge" else "Export finished, but saving failed"
                        )
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    _state.update {
                        it.copy(exporting = false, message = "Export failed: ${exportException.errorCodeName}")
                    }
                }
            })
            .build()

        transformer = t
        _state.update { it.copy(exporting = true) }
        t.start(edited, outFile.absolutePath)
    }

    private fun saveToGallery(file: File): Boolean {
        val resolver = getApplication<Application>().contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ClipForge_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipForge")
        }
        val target = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            resolver.openOutputStream(target)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onCleared() {
        transformer?.cancel()
        super.onCleared()
    }
}
