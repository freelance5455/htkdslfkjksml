package com.personal.clipforge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personal.clipforge.editor.EditorViewModel
import com.personal.clipforge.ui.EditorScreen
import com.personal.clipforge.ui.HomeScreen
import com.personal.clipforge.ui.theme.ClipForgeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ClipForgeTheme { App() }
        }
    }
}

@Composable
private fun App(vm: EditorViewModel = viewModel()) {
    var inEditor by rememberSaveable { mutableStateOf(false) }
    if (inEditor) {
        EditorScreen(vm = vm, onBack = { inEditor = false })
    } else {
        HomeScreen(onVideoPicked = { uri ->
            vm.load(uri)
            inEditor = true
        })
    }
}
