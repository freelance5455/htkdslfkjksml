# ClipForge (v0.1)

Open this folder in **Android Studio** (Koala or newer). On first open it will sync Gradle and create the wrapper automatically. Then run on a phone (Android 10+).

Included now: pick video, preview, trim, brightness/contrast (live preview), export to Movies/ClipForge.

## Getting the APK
- Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
- Or push this folder to a GitHub repo: the "Build APK" workflow runs automatically.
  Download the APK from the run page under Artifacts.
