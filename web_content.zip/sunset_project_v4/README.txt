Sunset Beach Gestão - Offline v4

Inclui a base v3 com Modo Garçom e a nova área de Relatórios/Estatísticas.
Relatórios: faturamento, quantidade de pagamentos, ticket médio, formas de pagamento,
produtos mais vendidos, vendas por garçom, vendas por mesa e resumo de entregas.

Para gerar o APK: usar a opção ZIP para APK e carregar este ZIP.
Pacote sugerido: com.sunsetbeach.gestao
Versão: 2.2.0
Código da versão: 4
