const CACHE='seedora-v1-shell';
const FILES=['./','./index.html','./manifest.webmanifest','./icons/seedora.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(u.origin===location.origin&&e.request.method==='GET')e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(x=>{caches.open(CACHE).then(c=>c.put(e.request,x.clone()));return x}).catch(()=>caches.match('./index.html'))))});
