SEEDORA V1 — ENGINE-INTEGRATED TEST BUILD
========================================

This build embeds the real, publicly hosted SeedForge interface inside SEEDORA using an iframe.

WHAT WORKS
- The real SeedForge Minecraft seed finder is displayed inside the SEEDORA screen.
- Java Edition and Bedrock Edition are supported by the engine.
- Version selector, structures, biome criteria, seed search, and map preview are provided by SeedForge.
- Mobile-friendly SEEDORA shell.
- No ads, login, tracking SDK, or subscription code added by this wrapper.

IMPORTANT LIMITATIONS
- INTERNET REQUIRED: the SeedForge engine is loaded from https://fwsoapy.github.io/seedforge/
- The engine's WASM files are NOT bundled in this ZIP. This is not an offline standalone engine.
- This ZIP is a web/PWA project, NOT an installable APK.
- The map's accuracy and supported features are those of SeedForge. Check the README and known limitations at:
  https://github.com/fwsoapy/seedforge
- Chinese Edition is not included.
- If the host blocks iframe embedding on a particular browser, use the direct link in the app footer.

RUN / TEST
1. Extract this ZIP.
2. Upload the folder to an HTTPS static host, or run it on localhost.
3. Open index.html in a browser for a basic preview. PWA installation requires HTTPS or localhost.
4. Internet must be enabled so the real engine can load.

ENGINE CREDIT & LICENSE
SeedForge by fwsoapy — https://github.com/fwsoapy/seedforge
SeedForge declares MIT licensing and credits Cubiomes by Cubitect. This wrapper does not redistribute their source or compiled WASM; it embeds their hosted public interface.
Minecraft is a trademark of Mojang Synergies AB. Unofficial fan project; not affiliated with Mojang or Microsoft.
