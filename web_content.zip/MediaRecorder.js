/*
  MediaRecorder.js
  Helper module to attach standardized handlers to a MediaRecorder instance.

  Exports:
    - attachMediaRecorderHandlers(recorder, options, { outputVideo, statusDiv, manualCleanup, stopAllAudioPlayback, logDebug, downloadBtn, effectSelect, powerSelect })
      Attaches onstart/ondataavailable/onstop/onerror handlers and uses provided dependencies
      to warm-up the output video element and finalize UI state.
*/

export function attachMediaRecorderHandlers(recorder, options, deps = {}) {
  const {
    outputVideo,
    statusDiv,
    manualCleanup,
    stopAllAudioPlayback,
    logDebug,
    downloadBtn,
    effectSelect,
    powerSelect,
  } = deps;

  const recordedChunks = [];

  recorder.onstart = () => {
    logDebug && logDebug('MediaRecorder started. state=', recorder.state, 'mime=', options.mimeType);
  };

  recorder.ondataavailable = (event) => {
    if (event.data && event.data.size > 0) recordedChunks.push(event.data);
  };

  const warmUpOutputVideo = async (videoEl, blobUrl, audioCaptured) => {
    try {
      videoEl.preload = 'auto';
      videoEl.playsInline = true;
      videoEl.crossOrigin = 'anonymous';
      videoEl.src = blobUrl;
      videoEl.load();

      const originalMuted = videoEl.muted;
      if (!audioCaptured) videoEl.muted = true;

      const p = videoEl.play();
      if (p && typeof p.then === 'function') {
        await p.then(() => { try { videoEl.pause(); } catch (e) {} }).catch(() => {});
      }

      videoEl.muted = audioCaptured ? false : true;
    } catch (e) {
      logDebug && logDebug('Warm-up failed:', e);
    }
  };

  recorder.onstop = () => {
    logDebug && logDebug('MediaRecorder onstop triggered. chunks=' + recordedChunks.length);

    // Ensure audio playback nodes are stopped immediately
    try { stopAllAudioPlayback && stopAllAudioPlayback(); } catch (e) { logDebug && logDebug('stopAllAudioPlayback failed', e); }

    if (recordedChunks.length === 0) {
      statusDiv && (statusDiv.textContent = 'Error: No video data was recorded.');
      logDebug && logDebug('No recorded chunks present.');
      manualCleanup && manualCleanup();
      return;
    }

    const blob = new Blob(recordedChunks, { type: options.mimeType });
    const url = URL.createObjectURL(blob);
    logDebug && logDebug('Created blob URL:', url);

    (async () => {
      try {
        await warmUpOutputVideo(outputVideo, url, recorder.stream && recorder.stream.getAudioTracks().length > 0);
      } catch (e) {
        logDebug && logDebug('Warm-up helper error:', e);
        // Fallback direct assignment
        try { outputVideo.src = url; outputVideo.muted = recorder.stream && recorder.stream.getAudioTracks().length > 0 ? false : true; } catch (ee) {}
      }
    })();

    // prepare download link
    downloadBtn && (downloadBtn.href = url);
    const extension = options.mimeType && options.mimeType.toLowerCase().includes('mp4') ? 'mp4' : 'webm';
    try { if (downloadBtn) downloadBtn.download = `ihtx-${(effectSelect && effectSelect.value) || 'effect'}-power${(powerSelect && powerSelect.value) || '1'}.${extension}`; } catch(e){}

    statusDiv && (statusDiv.textContent = recorder.stream && recorder.stream.getAudioTracks().length > 0
      ? 'Generation complete! Your video with audio is ready. Tap Download to save it.'
      : 'Generation complete! Video is ready (no audio captured). Tap Download to save it.');

    // final cleanup callback supplied by consumer
    manualCleanup && manualCleanup();
    logDebug && logDebug('attachMediaRecorderHandlers: onstop complete.');
  };

  recorder.onerror = (event) => {
    logDebug && logDebug('MediaRecorder error:', event && event.error);
    statusDiv && (statusDiv.textContent = `MediaRecorder error: ${(event && event.error && (event.error.name || event.error)) || event || 'unknown'}. Generation failed.`);
    manualCleanup && manualCleanup();
  };

  return {
    // expose recordedChunks for advanced use if needed
    getRecordedChunks: () => recordedChunks,
  };
}