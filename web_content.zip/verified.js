/* Vortex: галочки и команды создателя. Подключается до основного бандла. */
(function () {
  'use strict';
  var KEY_STORE = 'vortex_verified', CREATOR_STORE = 'vortex_creator';
  var CREATOR_KEY = window.VORTEX_CREATOR_KEY || 'vortex-creator'; // поменяйте в config.js
  var names = {};   // username -> displayName (всё, что видели в ответах API)
  var me = null;    // username текущего пользователя

  function rd(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
  function wr(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  var verified = rd(KEY_STORE, []);          // массив username
  var isCreator = !!rd(CREATOR_STORE, false);

  /* ---------- сбор пользователей из ответов API ---------- */
  function walk(o, depth) {
    if (!o || typeof o !== 'object' || depth > 6) return;
    if (Array.isArray(o)) { for (var i = 0; i < o.length; i++) walk(o[i], depth + 1); return; }
    if (typeof o.username === 'string') {
      names[o.username.toLowerCase()] = o.displayName || o.username;
      if (o.verified === true && verified.indexOf(o.username.toLowerCase()) < 0) verified.push(o.username.toLowerCase());
    }
    for (var k in o) if (o[k] && typeof o[k] === 'object') walk(o[k], depth + 1);
  }
  var realFetch = window.fetch.bind(window);
  window.fetch = function (url, opt) {
    return realFetch(url, opt).then(function (res) {
      try {
        var u = String(url);
        if (u.indexOf('/api/') !== -1) {
          res.clone().json().then(function (j) {
            walk(j, 0);
            if (/\/auth\/(me|login|register)/.test(u) && j && j.user && j.user.username) me = j.user.username.toLowerCase();
            schedule();
          }).catch(function () {});
        }
      } catch (e) {}
      return res;
    });
  };

  /* ---------- галочка в интерфейсе ---------- */
  var BADGE = '<svg viewBox="0 0 24 24" width="14" height="14" aria-label="Подтверждён" role="img"><circle cx="12" cy="12" r="11" fill="#3b82f6"/><path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var style = document.createElement('style');
  style.textContent = '.vx-badge{display:inline-flex;vertical-align:-2px;margin-left:4px;flex-shrink:0}' +
    '#vx-toast{position:fixed;left:50%;top:calc(16px + env(safe-area-inset-top,0px));transform:translateX(-50%);z-index:2147483647;max-width:calc(100% - 32px);background:#27272a;color:#fafafa;border:1px solid #3f3f46;border-radius:14px;padding:10px 16px;font:500 13px Inter,system-ui,sans-serif;box-shadow:0 8px 30px #0008}';
  document.head.appendChild(style);

  function matchSet() {
    var m = {};
    verified.forEach(function (u) {
      m['@' + u] = 1;
      var dn = names[u];
      if (dn && dn.length > 1) m[dn] = 1;
      if (u === me && dn) m[dn] = 1;
    });
    return m;
  }
  var pending = false;
  function schedule() { if (pending) return; pending = true; requestAnimationFrame(function () { pending = false; decorate(); }); }
  function decorate() {
    var set = matchSet();
    // сначала убираем галочки, которые больше не нужны
    document.querySelectorAll('.vx-badge').forEach(function (b) {
      var p = b.previousSibling;
      if (!p || p.nodeType !== 3 || !set[p.nodeValue.trim()]) b.remove();
    });
    if (!verified.length || !document.body) return;
    var w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        var p = n.parentNode, t = n.nodeValue.trim();
        if (!t || !set[t]) return NodeFilter.FILTER_REJECT;
        if (p.closest('textarea,input,script,style,#vx-toast,#demo')) return NodeFilter.FILTER_REJECT;
        if (n.nextSibling && n.nextSibling.classList && n.nextSibling.classList.contains('vx-badge')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var list = [], n; while ((n = w.nextNode())) list.push(n);
    list.forEach(function (t) {
      if (t.nodeValue.trim().charAt(0) === '@') return; // юзернейм без галочки, галочка только у имени
      var s = document.createElement('span'); s.className = 'vx-badge'; s.innerHTML = BADGE;
      t.parentNode.insertBefore(s, t.nextSibling);
    });
  }
  new MutationObserver(function (m) {
    for (var i = 0; i < m.length; i++) { var t = m[i].target; if (!(t.classList && t.classList.contains('vx-badge'))) { schedule(); return; } }
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  /* ---------- команды ---------- */
  function toast(msg) {
    var t = document.getElementById('vx-toast') || document.createElement('div');
    t.id = 'vx-toast'; t.textContent = msg; document.body.appendChild(t);
    clearTimeout(t._h); t._h = setTimeout(function () { t.remove(); }, 3500);
  }
  function norm(a) { return String(a || '').replace(/^@/, '').trim().toLowerCase(); }
  function set(u, on) {
    var i = verified.indexOf(u);
    if (on && i < 0) verified.push(u);
    if (!on && i >= 0) verified.splice(i, 1);
    wr(KEY_STORE, verified); schedule();
  }
  // Вернёт true, если сообщение было командой (тогда оно не отправляется в чат)
  window.__vortexCmd = function (text) {
    var p = text.trim().split(/\s+/), c = p[0].toLowerCase();
    if (['/creator', '/verify', '/unverify', '/verified', '/creatorhelp'].indexOf(c) < 0) return false;
    if (c === '/creator') {
      if (p[1] === CREATOR_KEY) { isCreator = true; wr(CREATOR_STORE, true); toast('Режим создателя включён. /creatorhelp — список команд'); }
      else toast('Неверный ключ');
      return true;
    }
    if (!isCreator) { toast('Команда доступна только создателю: /creator <ключ>'); return true; }
    if (c === '/creatorhelp') { toast('/verify [@ник] · /unverify [@ник] · /verified · /creator off'); return true; }
    if (c === '/verified') { toast(verified.length ? 'С галочкой: ' + verified.map(function (u) { return '@' + u; }).join(', ') : 'Галочек пока нет'); return true; }
    var u = norm(p[1]) || me;
    if (!u) { toast('Не удалось определить пользователя. Укажите @ник'); return true; }
    set(u, c === '/verify');
    toast(c === '/verify' ? 'Галочка выдана @' + u : 'Галочка снята у @' + u);
    return true;
  };
  var origCmd = window.__vortexCmd;
  window.__vortexCmd = function (t) {
    if (/^\/creator\s+off\s*$/i.test(t)) { isCreator = false; wr(CREATOR_STORE, false); toast('Режим создателя выключен'); return true; }
    return origCmd(t);
  };
  // то же из консоли: vortex.verify('ник')
  window.vortex = { verify: function (u) { set(norm(u) || me, true); }, unverify: function (u) { set(norm(u) || me, false); } };
})();
