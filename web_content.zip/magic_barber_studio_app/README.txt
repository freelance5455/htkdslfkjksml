MAGIC BARBER STUDIO — Local-first starter app

FILES
- index.html: the application
- logo.png: rasterized from the saved MAGIC BARBER STUDIO circular logo PDF

HOW TO TEST
1. Keep index.html and logo.png in the same folder.
2. Open index.html in a modern browser to test the interface.
3. Data is saved in that browser's local storage on that device.
4. Use Settings > Export backup regularly. Store the JSON backup securely.
5. Use Settings > Restore backup to import it on the same or another device/browser.

IMPORTANT LIMITATIONS
- This is an initial prototype, not a finished APK or a security-audited product.
- Local data is not synchronized between devices.
- The app stores data in browser localStorage. Clearing browser/app data can erase records.
- The backup JSON is not encrypted. Protect it as it contains personal customer information.
- Automatic retention cleanup runs when the app opens. Expired visit records are removed; client profiles without remaining visits are removed as well. Upcoming appointments are stored on visit records and may be removed when that visit expires, so review retention settings before using real records.
- No live server, cloud database, paid service, card, or billing setup is included.
- Default services/prices are examples and should be edited to match the shop's real menu.
