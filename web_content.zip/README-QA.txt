Otter Reader v28 — Final QA report
Date: 2026-09-29

RESULT: PASSED for the tested browser/mobile-WebView scenarios.

Viewport checks:
- 360x800: no horizontal overflow; Otto images load at 1254x1254; quick actions fit.
- 390x844: no horizontal overflow; Otto images load at 1254x1254; quick actions fit.
- 430x932: no horizontal overflow; Otto images load at 1254x1254; quick actions fit.
- 1365x768: no horizontal overflow; desktop dashboard fits viewport with internal scrolling where designed.

Function checks:
- Library navigation: PASS
- Statistics navigation: PASS
- Light/dark theme switching: PASS
- Otto contextual message: PASS
- HD Otto scene changes: PASS
- Timer start: PASS
- Timer pause/resume: PASS
- Timer reset with confirmation: PASS
- Finish timer -> session dialog: PASS
- Duplicate timer in session dialog: NOT PRESENT
- FB2 import: PASS (title, author and estimated length parsed)
- PDF import: PASS in tested PDFs; page count checks /Type /Page and /Pages /Count markers
- Long book titles: no horizontal overflow; titles are clamped in library cards
- Mobile timer is hidden in Library/Statistics to avoid repeated mascot blocks
- JavaScript syntax/runtime: no page errors in automated test flow

APK / HTML-to-APK notes:
- v28 final HTML is self-contained; Otto images are embedded into index.html.
- Required wrapper settings: JavaScript ON, DOM Storage/localStorage ON, File Chooser/File Upload ON.
- Actual Android system file picker depends on the converter/WebView implementation. The app-side <input type=file> flow is verified in Chromium.
- Internet access is not required for the app itself.
