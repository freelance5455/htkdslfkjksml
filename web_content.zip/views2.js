'use strict';
/* ============================================================
   Telas — parte 2: histórico, métricas, perfil, patentes, conquistas, sobre, backup
   ============================================================ */
const RENDERERS = { train:renderTrainView, history:renderHistoryView, stats:renderStatsView, settings:renderSettingsView };

/* ---------- HISTÓRICO ---------- */
function renderHistoryView(){
  $('#historyTitle').textContent = t('hist.title');
  const statsWrap = $('#historyStats'), list = $('#historyList'); U.clear(statsWrap); U.clear(list);
  const totalMs = State.history.reduce((a,s)=>a + Math.max(0, s.completedAt - (s.startedAt || s.completedAt)), 0);
  statsWrap.appendChild(statCard(t('lbl.sessions'), State.history.length, t('hist.registered')));
  statsWrap.appendChild(statCard(t('lbl.thisWeek'), weekDaysCount(Date.now()) + '/' + S().weeklyGoal, t('hist.weeklyGoal')));
  const ws = State.game ? State.game.weekStreak.current : 0;
  statsWrap.appendChild(statCard(t('lbl.weeksInGoal'), ws, t('hist.weeksInGoal', { n:ws })));
  statsWrap.appendChild(statCard(t('hist.totalTime'), fmtDuration(totalMs), t('hist.training')));
  if(!State.history.length){
    const empty = h('div', { class:'empty' });
    empty.appendChild(h('div', { class:'empty-icon' }, [icon('clock', 20)])); empty.appendChild(h('div', { text:t('hist.empty') }));
    empty.appendChild(h('div', { style:{ marginTop:'6px', fontSize:'12px' }, text:t('hist.emptyHint') })); list.appendChild(empty); return;
  }
  sessionsDesc().forEach(session=>{
    const card = h('button', { class:'session-card', type:'button' });
    const left = h('div');
    left.appendChild(h('div', { class:'session-date', text:fmtDateLong(session.completedAt) }));
    const doneCount = session.exercises.filter(ex=>(ex.sets||[]).some(s=>s.done)).length;
    left.appendChild(h('div', { class:'session-sub', text:(session.dayTitle || t('lbl.workout')) + ' • ' + t('hist.exCount', { a:doneCount, b:session.exercises.length }) }));
    card.appendChild(left);
    const right = h('div', { class:'session-right' });
    const rep = State.game && State.game.reports[session.id];
    if(gamOn() && rep && rep.qualified && rep.xp) right.appendChild(h('div', { class:'session-xp', text:'+' + fmtInt(rep.xp.total + rep.questXp) + ' ' + t('lbl.xp') }));
    right.appendChild(h('div', { class:'session-badge', text:fmtDuration(session.completedAt - (session.startedAt || session.completedAt)) }));
    card.appendChild(right);
    card.addEventListener('click', ()=>openSessionDetail(session.id)); list.appendChild(card);
  });
}

/* Detalhe da sessão: editável (carga, reps, minutos) + nota */
function openSessionDetail(sessionId){
  const orig = State.history.find(s=>s.id === sessionId); if(!orig) return;
  const draft = U.clone(orig);
  Modals.open({ title:t('hist.detail'), tall:true, build(body, foot){
    body.appendChild(h('div', { class:'sum-title', text:fmtDateLong(draft.completedAt) }));
    body.appendChild(h('div', { class:'sum-sub', text:(draft.dayTitle || t('lbl.workout')) + ' • ' + fmtDuration(draft.completedAt - draft.startedAt) }));
    body.appendChild(h('p', { class:'field-hint', text:t('hist.editHint') }));
    let any = false;
    draft.exercises.forEach(ex=>{
      const done = (ex.sets || []).filter(s=>s.done); if(!done.length) return; any = true;
      const card = h('div', { class:'sum-block' }); card.appendChild(h('div', { class:'sum-h', text:ex.name }));
      done.forEach((st, i)=>{
        const row = h('div', { class:'set-row edit' + (ex.cardio ? ' cardio' : '') });
        row.appendChild(h('div', { class:'set-num', text:String(i+1) }));
        if(ex.cardio || 'minutes' in st){
          const inp = h('input', { type:'text', inputmode:'decimal', value:st.minutes || '', 'aria-label':t('set.minutes') + ' — ' + ex.name + ' #' + (i+1) });
          inp.addEventListener('input', ()=>{ const n = U.parseNum(inp.value); st.minutes = n == null ? '' : String(n); }); row.appendChild(inp);
          row.appendChild(h('span', { class:'set-unit', text:t('unit.min') }));
        } else {
          const l = h('input', { type:'text', inputmode:'decimal', value:loadInputValue(st.load), placeholder:unitLabel(), 'aria-label':t('set.load', { u:unitLabel() }) + ' — ' + ex.name + ' #' + (i+1) });
          l.addEventListener('input', ()=>{ st.load = dispToKg(l.value); });
          const r = h('input', { type:'text', inputmode:'numeric', value:st.reps || '', placeholder:t('lbl.repsShort'), 'aria-label':t('set.reps') + ' — ' + ex.name + ' #' + (i+1) });
          r.addEventListener('input', ()=>{ st.reps = r.value.replace(/[^\d]/g,''); });
          row.appendChild(l); row.appendChild(r);
        }
        card.appendChild(row);
      });
      body.appendChild(card);
    });
    if(!any) body.appendChild(h('div', { class:'empty', text:t('hist.noSets') }));
    const note = h('textarea', { id:'s-note', maxlength:'500', placeholder:t('hist.notePh') }); note.value = draft.note || '';
    body.appendChild(fieldEl(t('hist.note'), note));
    foot.appendChild(h('button', { class:'btn btn-danger', type:'button', 'aria-label':t('btn.delete'), onclick:async ()=>{
      const ok = await confirmDialog({ title:t('hist.deleteTitle'), message:t('hist.deleteMsg'), confirmText:t('btn.delete') });
      if(!ok) return;
      takeSnapshot(); State.history = State.history.filter(s=>s.id !== sessionId);
      persistHistory(); rebuildGamification(); renderTopbar(); RENDERERS[State.currentView](); showUndoBar(t('undo.sessionDeleted'));
    } }, [ icon('trash') ]));
    foot.appendChild(h('button', { class:'btn btn-ghost', type:'button', onclick:()=>{ const rep = State.game && State.game.reports[orig.id]; openShareCard({ kind:'session', session:orig, report:rep }); } }, [ icon('share') ]));
    foot.appendChild(h('button', { class:'btn btn-primary', type:'button', text:t('btn.save'), onclick:()=>{
      draft.note = note.value.trim();
      const idx = State.history.findIndex(s=>s.id === sessionId); if(idx < 0) return;
      State.history[idx] = draft; persistHistory();
      const { prev, next } = rebuildGamification(), diff = gameDiff(prev, next);
      Modals.close(); renderTopbar(); RENDERERS[State.currentView](); showToast(t('toast.saved'), 'success');
      if(gamOn()) diff.newAch.forEach(toastAchievement);
    } }));
  }});
}

/* ---------- MÉTRICAS ---------- */
function sparkline(values, color){
  const svg = document.createElementNS(SVGNS, 'svg'); svg.setAttribute('viewBox','0 0 100 30'); svg.setAttribute('preserveAspectRatio','none'); svg.setAttribute('class','spark'); svg.setAttribute('aria-hidden','true');
  const pts = values.slice(-14); if(pts.length < 2) return svg;
  const min = Math.min(...pts), max = Math.max(...pts), rng = (max - min) || 1;
  const coords = pts.map((v,i)=>[ (i/(pts.length-1))*100, 27 - ((v-min)/rng)*24 ]);
  const line = document.createElementNS(SVGNS, 'polyline');
  line.setAttribute('points', coords.map(c=>c[0].toFixed(1) + ',' + c[1].toFixed(1)).join(' ')); line.setAttribute('fill','none'); line.setAttribute('stroke', color || '#00E5FF'); line.setAttribute('stroke-width','2'); line.setAttribute('stroke-linejoin','round'); line.setAttribute('stroke-linecap','round'); line.setAttribute('vector-effect','non-scaling-stroke');
  svg.appendChild(line);
  const lc = coords[coords.length-1], dot = document.createElementNS(SVGNS, 'circle'); dot.setAttribute('cx', lc[0]); dot.setAttribute('cy', lc[1]); dot.setAttribute('r','2.2'); dot.setAttribute('fill', color || '#00E5FF'); svg.appendChild(dot);
  return svg;
}
function renderStatsView(){
  $('#statsTitle').textContent = t('stats.title');
  const wrap = $('#statsContent'); U.clear(wrap);
  if(State.history.length){
    let volume = 0, reps = 0, sets = 0, cardioMin = 0;
    State.history.forEach(s=>s.exercises.forEach(ex=>(ex.sets||[]).forEach(st=>{
      if(!st.done) return;
      if(ex.cardio || 'minutes' in st){ cardioMin += U.parseNum(st.minutes) || 0; return; }
      sets++; const r = U.parseNum(st.reps), l = U.parseNum(st.load); if(r) reps += r; if(r && l) volume += r*l;
    })));
    const grid = h('div', { class:'stat-grid' });
    grid.appendChild(statCard(t('stats.totalVolume'), fmtInt(kgToDisp(volume)), unitLabel() + ' × ' + t('lbl.repsShort')));
    grid.appendChild(statCard(t('lbl.reps'), fmtInt(reps), t('lbl.totalPl')));
    grid.appendChild(statCard(t('lbl.sets'), fmtInt(sets), t('lbl.completedPl')));
    grid.appendChild(statCard(t('lbl.cardio'), fmtInt(cardioMin), t('unit.minutes')));
    wrap.appendChild(grid);
    // frequência semanal (8 semanas, dias distintos)
    const goal = S().weeklyGoal, weeks = []; let wk = U.weekKey(U.dayKey(Date.now()));
    for(let i=0;i<8;i++){ weeks.unshift({ wk, n: weekDaysCount(U.keyToTs(wk) + 3600000*12) }); wk = U.addDays(wk, -7); }
    const maxN = Math.max(goal, ...weeks.map(w=>w.n), 1);
    const card = h('div', { class:'stat-card', style:{ marginBottom:'12px' } });
    card.appendChild(h('div', { class:'lbl', text:t('stats.weekly', { n:goal }) }));
    const bars = h('div', { class:'week-bars', role:'img', 'aria-label':t('stats.weeklyAria') });
    weeks.forEach(w=>{
      const col = h('div', { class:'week-bar' }); col.appendChild(h('b', { text:w.n ? String(w.n) : '' }));
      col.appendChild(h('div', { class:'bar' + (w.n === 0 ? ' zero' : (w.n >= goal ? ' goal' : '')), style:{ height:(w.n === 0 ? 3 : Math.max(8, w.n/maxN*70)) + '%' } }));
      col.appendChild(h('span', { text:fmtMonthDay(U.keyToTs(w.wk)) })); bars.appendChild(col);
    });
    card.appendChild(bars); wrap.appendChild(card);
  }
  wrap.appendChild(renderHeatmapCard());
  if(State.history.length) wrap.appendChild(renderRadarCard());
  wrap.appendChild(renderBodyWeightCard());
  if(!State.history.length){ const empty = h('div', { class:'empty', style:{ marginTop:'12px' } }); empty.appendChild(h('div', { class:'empty-icon' }, [icon('bars', 20)])); empty.appendChild(h('div', { text:t('stats.empty') })); empty.appendChild(h('div', { style:{ marginTop:'6px', fontSize:'12px' }, text:t('stats.emptyHint') })); wrap.appendChild(empty); return; }
  // evolução por exercício (por exerciseKey: renomear não quebra)
  wrap.appendChild(h('div', { class:'sec-title' }, [ h('span', { text:t('stats.evolution') }) ]));
  const map = new Map();
  [...State.history].sort((a,b)=>a.completedAt - b.completedAt).forEach(session=>session.exercises.forEach(ex=>{
    const done = (ex.sets || []).filter(s=>s.done); if(!done.length) return;
    let maxLoad = 0, totReps = 0, minutes = 0;
    done.forEach(s=>{ const l = U.parseNum(s.load), r = U.parseNum(s.reps), m = U.parseNum(s.minutes); if(l && l > maxLoad) maxLoad = l; if(r) totReps += r; if(m) minutes += m; });
    const key = ex.key || U.norm(ex.name);
    if(!map.has(key)) map.set(key, { name:ex.name, pts:[] });
    const e = map.get(key); e.name = ex.name; e.pts.push({ date:session.completedAt, maxLoad, totReps, minutes });
  }));
  const entries = [...map.values()].sort((a,b)=>b.pts[b.pts.length-1].date - a.pts[a.pts.length-1].date);
  const list = h('div', { class:'ex-list' });
  entries.forEach(e=>{
    const hasLoad = e.pts.some(p=>p.maxLoad > 0), hasReps = e.pts.some(p=>p.totReps > 0);
    const metric = p => hasLoad ? kgToDisp(String(p.maxLoad)) : (hasReps ? p.totReps : p.minutes);
    const uTxt = hasLoad ? ' ' + unitLabel() : (hasReps ? ' ' + t('lbl.repsShort') : ' ' + t('unit.min'));
    const vals = e.pts.map(metric), last = vals[vals.length-1], prev = vals.length > 1 ? vals[vals.length-2] : null;
    const c = h('div', { class:'stat-card' }); c.appendChild(h('div', { class:'lbl', text:e.name }));
    const v = h('div', { class:'val', style:{ fontSize:'20px' } }); v.appendChild(document.createTextNode(fmtNum(last, 1) + uTxt));
    if(prev !== null && last !== prev){ const d = last - prev; v.appendChild(h('span', { class:'delta ' + (d > 0 ? 'up' : 'down'), text:(d > 0 ? '▲ +' : '▼ ') + fmtNum(d, 1) })); }
    if(vals.length > 1 && last > Math.max(...vals.slice(0,-1))) v.appendChild(h('span', { class:'pr', text:t('lbl.pr') }));
    c.appendChild(v); c.appendChild(h('div', { class:'sub', text:t('stats.records', { n:e.pts.length }) + ' • ' + t('stats.lastOn', { date:fmtDateShort(e.pts[e.pts.length-1].date) }) }));
    if(vals.length > 1) c.appendChild(sparkline(vals)); list.appendChild(c);
  });
  wrap.appendChild(list);
}

/* Mapa de calor: 12 semanas, toque abre a sessão */
function renderHeatmapCard(){
  const card = h('div', { class:'stat-card', style:{ marginBottom:'12px' } });
  card.appendChild(h('div', { class:'lbl', text:t('stats.heatmap') }));
  const byDay = {};
  State.history.forEach(s=>{ const k = U.dayKey(s.completedAt), i = sessionInfo(s); const o = byDay[k] || (byDay[k] = { units:0, sessions:[] }); o.units += i.sets + i.cardioMin / 5; o.sessions.push(s); });
  const todayK = U.dayKey(Date.now()), start = U.addDays(U.weekKey(todayK), -7*11);
  const head = h('div', { class:'heat-head', 'aria-hidden':'true' });
  [1,2,3,4,5,6,0].forEach(d=>head.appendChild(h('span', { text:fmtWeekdayNarrow(d) }))); card.appendChild(head);
  const grid = h('div', { class:'heat', role:'grid', 'aria-label':t('stats.heatmap') });
  for(let i=0;i<84;i++){
    const k = U.addDays(start, i), o = byDay[k], future = k > todayK;
    const lvl = !o ? 0 : (o.units < 8 ? 1 : (o.units < 16 ? 2 : 3));
    const label = fmtDateLong(U.keyToTs(k)) + (o ? ' — ' + t('stats.heatSessions', { n:o.sessions.length }) : '');
    const cell = h('button', { class:'heat-cell l' + lvl + (k === todayK ? ' today' : ''), type:'button', disabled:!o, 'aria-label':label, title:label }, [ h('span', { text:String(U.keyToDate(k).getDate()) }) ]);
    if(future) cell.style.visibility = 'hidden';
    if(o) cell.addEventListener('click', ()=>{
      if(o.sessions.length === 1) openSessionDetail(o.sessions[0].id);
      else actionSheet(fmtDateLong(U.keyToTs(k)), o.sessions.map(s=>({ label:(s.dayTitle || t('lbl.workout')) + ' • ' + fmtDuration(s.completedAt - s.startedAt), icon:'clock', opens:true, onClick:()=>openSessionDetail(s.id) })));
    });
    grid.appendChild(cell);
  }
  card.appendChild(grid); return card;
}


/* Radar semanal: séries por grupo muscular (esta semana x média das últimas 4 semanas) */
const RADAR_AXES = ['chest','back','legs','shoulders','biceps','triceps','abs','glutes','calves','cardio'];
function radarData(){
  const nowK = U.dayKey(Date.now()), curWk = U.weekKey(nowK), weeks = [0,1,2,3].map(i=>U.addDays(curWk, -7*i));
  const per = {}; weeks.forEach(w=>{ per[w] = {}; RADAR_AXES.forEach(a=>{ per[w][a] = 0; }); });
  State.history.forEach(s=>{
    const w = U.weekKey(U.dayKey(s.completedAt)); if(!per[w]) return;
    s.exercises.forEach(ex=>{
      const done = (ex.sets || []).filter(x=>x.done); if(!done.length) return;
      const key = isCardioKey(ex.muscle) ? (ex.muscle === 'cardio' ? 'cardio' : null) : ex.muscle; if(!key || !(key in per[w])) return;
      if(key === 'cardio') per[w][key] += done.reduce((a,x)=>a + (U.parseNum(x.minutes) || 0), 0) / 10;
      else per[w][key] += done.length;
    });
  });
  return { now: RADAR_AXES.map(a=>per[curWk][a]), avg: RADAR_AXES.map(a=>weeks.reduce((t,w)=>t + per[w][a], 0) / 4) };
}
function renderRadarCard(){
  const card = h('div', { class:'stat-card', style:{ marginBottom:'12px' } });
  card.appendChild(h('div', { class:'lbl', text:t('stats.radar') }));
  const d = radarData(), n = RADAR_AXES.length, cx = 160, cy = 150, R = 98;
  const max = Math.max(1, ...d.now, ...d.avg);
  if(d.avg.every(v=>v === 0) && d.now.every(v=>v === 0)){ card.appendChild(h('div', { class:'field-hint', style:{ marginTop:'8px' }, text:t('stats.radarEmpty') })); return card; }
  const pt = (i, f)=>{ const a = -Math.PI/2 + i * 2*Math.PI/n; return [cx + R*f*Math.cos(a), cy + R*f*Math.sin(a)]; };
  const top = RADAR_AXES.map((a,i)=>[a, d.avg[i]]).sort((x,y)=>y[1] - x[1]).slice(0,3).filter(x=>x[1] > 0).map(x=>t('muscle.' + x[0])).join(', ');
  const svg = document.createElementNS(SVGNS, 'svg'); svg.setAttribute('viewBox','-30 0 380 300'); svg.setAttribute('class','radar'); svg.setAttribute('role','img'); svg.setAttribute('aria-label', t('stats.radarAria', { top }));
  const mk = (tag, attrs)=>{ const e = document.createElementNS(SVGNS, tag); Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k, v)); return e; };
  [.25,.5,.75,1].forEach(f=>svg.appendChild(mk('polygon', { points:RADAR_AXES.map((_,i)=>pt(i,f).map(v=>v.toFixed(1)).join(',')).join(' '), fill:'none', stroke:'rgba(255,255,255,.12)', 'stroke-width':'1' })));
  RADAR_AXES.forEach((a,i)=>{
    const p = pt(i,1), q = pt(i,1.17);
    svg.appendChild(mk('line', { x1:cx, y1:cy, x2:p[0].toFixed(1), y2:p[1].toFixed(1), stroke:'rgba(255,255,255,.12)', 'stroke-width':'1' }));
    const tx = mk('text', { x:q[0].toFixed(1), y:(q[1] + 4).toFixed(1), 'text-anchor': q[0] < cx - 6 ? 'end' : (q[0] > cx + 6 ? 'start' : 'middle'), fill:'#9AA0A6', 'font-size':'11' });
    tx.textContent = t('muscle.' + a); svg.appendChild(tx);
  });
  const poly = (vals, fill, stroke)=>svg.appendChild(mk('polygon', { points:vals.map((v,i)=>pt(i, v / max).map(c=>c.toFixed(1)).join(',')).join(' '), fill, stroke, 'stroke-width':'2', 'stroke-linejoin':'round' }));
  poly(d.avg, 'rgba(0,229,255,.22)', '#00E5FF'); poly(d.now, 'rgba(139,92,246,.28)', '#A78BFA');
  card.appendChild(svg);
  const lg = h('div', { class:'radar-legend' });
  lg.appendChild(h('span', {}, [ h('i', { class:'sw cy' }), t('stats.radarAvg') ])); lg.appendChild(h('span', {}, [ h('i', { class:'sw vi' }), t('stats.radarNow') ]));
  card.appendChild(lg); card.appendChild(h('div', { class:'field-hint', text:t('stats.radarHint') }));
  return card;
}

/* Peso corporal ao longo do tempo */
function renderBodyWeightCard(){
  const card = h('div', { class:'stat-card', style:{ marginBottom:'12px' } });
  card.appendChild(h('div', { class:'lbl', text:t('bw.title') }));
  const log = State.data.bodyLog;
  const row = h('div', { class:'bw-form' });
  const iW = h('input', { id:'bw-w', type:'text', inputmode:'decimal', placeholder:unitLabel(), 'aria-label':t('bw.weight', { u:unitLabel() }) });
  const iD = h('input', { id:'bw-d', type:'date', value:U.dayKey(Date.now()), max:U.dayKey(Date.now()), 'aria-label':t('bw.date') });
  row.appendChild(h('div', { class:'field' }, [ h('label', { for:'bw-w', text:t('bw.weight', { u:unitLabel() }) }), iW ]));
  row.appendChild(h('div', { class:'field' }, [ h('label', { for:'bw-d', text:t('bw.date') }), iD ]));
  row.appendChild(h('button', { class:'btn btn-primary', type:'button', text:t('bw.add'), onclick:()=>{
    const n = U.parseNum(iW.value); const kg = n == null ? null : (unit() === 'lb' ? n / LB : n);
    if(!kg || kg < 20 || kg > 400 || !/^\d{4}-\d{2}-\d{2}$/.test(iD.value)){ showToast(t('bw.invalid'), 'error'); return; }
    State.data.bodyLog = State.data.bodyLog.filter(b=>b.date !== iD.value); State.data.bodyLog.push({ id:U.uid('bw'), date:iD.value, kg:Math.round(kg*100)/100 });
    State.data.bodyLog.sort((a,b)=>a.date < b.date ? -1 : 1); persistData(); renderStatsView(); showToast(t('bw.saved'), 'success');
  } }));
  card.appendChild(row);
  if(log.length >= 2){
    const pts = log.slice(-30), W = 300, H = 90, vals = pts.map(p=>kgToDisp(String(p.kg))), min = Math.min(...vals), max = Math.max(...vals), rng = (max - min) || 1;
    const t0 = U.keyToTs(pts[0].date), t1 = U.keyToTs(pts[pts.length-1].date), span = (t1 - t0) || 1;
    const svg = document.createElementNS(SVGNS, 'svg'); svg.setAttribute('viewBox', '0 0 ' + W + ' ' + (H+18)); svg.setAttribute('class','bw-chart'); svg.setAttribute('role','img'); svg.setAttribute('aria-label', t('bw.chartAria', { a:fmtNum(vals[0],1), b:fmtNum(vals[vals.length-1],1), u:unitLabel() }));
    const xy = pts.map((p,i)=>[ 10 + (U.keyToTs(p.date) - t0) / span * (W-20), 8 + (1 - (vals[i]-min)/rng) * (H-24) ]);
    const pl = document.createElementNS(SVGNS, 'polyline'); pl.setAttribute('points', xy.map(c=>c[0].toFixed(1) + ',' + c[1].toFixed(1)).join(' ')); pl.setAttribute('fill','none'); pl.setAttribute('stroke','#00E5FF'); pl.setAttribute('stroke-width','2'); pl.setAttribute('stroke-linejoin','round'); svg.appendChild(pl);
    xy.forEach(c=>{ const d = document.createElementNS(SVGNS, 'circle'); d.setAttribute('cx', c[0]); d.setAttribute('cy', c[1]); d.setAttribute('r','3'); d.setAttribute('fill','#00E5FF'); svg.appendChild(d); });
    [[fmtNum(max,1), 8],[fmtNum(min,1), H-2]].forEach(a=>{ const tx = document.createElementNS(SVGNS, 'text'); tx.setAttribute('x','298'); tx.setAttribute('y', a[1]); tx.setAttribute('text-anchor','end'); tx.setAttribute('fill','#9AA0A6'); tx.setAttribute('font-size','10'); tx.textContent = a[0]; svg.appendChild(tx); });
    [[fmtDateShort(t0), 'start'],[fmtDateShort(t1), 'end']].forEach((a,i)=>{ const tx = document.createElementNS(SVGNS, 'text'); tx.setAttribute('x', i ? '290' : '10'); tx.setAttribute('y', H+12); tx.setAttribute('text-anchor', i ? 'end' : 'start'); tx.setAttribute('fill','#9AA0A6'); tx.setAttribute('font-size','10'); tx.textContent = a[0]; svg.appendChild(tx); });
    card.appendChild(svg);
  } else card.appendChild(h('div', { class:'field-hint', style:{ marginTop:'8px' }, text:t('bw.hint') }));
  if(log.length){
    const lst = h('div', { class:'bw-list' });
    log.slice(-5).reverse().forEach(b=>{
      const r = h('div', { class:'bw-item' }); r.appendChild(h('span', { text:fmtDateFull(U.keyToTs(b.date)) })); r.appendChild(h('b', { text:fmtLoad(String(b.kg), true) }));
      r.appendChild(h('button', { class:'ex-menu', type:'button', 'aria-label':t('btn.delete') + ' ' + fmtDateShort(U.keyToTs(b.date)), onclick:()=>{ State.data.bodyLog = State.data.bodyLog.filter(x=>x.id !== b.id); persistData(); renderStatsView(); } }, [ icon('trash', 16) ]));
      lst.appendChild(r);
    }); card.appendChild(lst);
  }
  return card;
}

/* ---------- PATENTES / CONQUISTAS ---------- */
function openRanksScreen(){
  Modals.open({ title:t('rank.screenTitle'), tall:true, build(body){
    const G = State.data.gamification, lp = levelProgress(G.xpTotal);
    const top = h('div', { class:'ranks-top' });
    top.appendChild(insigniaEl(lp.rank.id, 96));
    top.appendChild(h('div', { class:'rank-name big', text:t('rank.' + lp.rank.id) }));
    top.appendChild(h('div', { class:'rank-sub', text:t('lbl.level', { n:lp.level }) + ' • ' + fmtInt(G.xpTotal) + ' ' + t('lbl.xp') }));
    const track = h('div', { class:'progress-track', style:{ width:'100%' } }); track.appendChild(h('div', { class:'progress-fill', style:{ width:lp.pct + '%' } })); top.appendChild(track);
    top.appendChild(h('div', { class:'rank-next', text: lp.nextRank ? t('rank.toNext', { xp:fmtInt(lp.xpToNextRank), rank:t('rank.' + lp.nextRank.id) }) : t('rank.max') }));
    top.appendChild(h('div', { class:'rank-next', text:t('rank.levelXp', { a:fmtInt(lp.xpInLevel), b:fmtInt(lp.xpNeeded), n:lp.level + 1 }) }));
    body.appendChild(top);
    const ladder = h('ol', { class:'ladder' });
    RANKS.forEach(r=>{
      const reached = lp.level >= r.min, current = r.id === lp.rank.id;
      const li = h('li', { class:'ladder-row' + (reached ? ' reached' : ' locked') + (current ? ' current' : ''), 'aria-current':current ? 'true' : null });
      li.appendChild(insigniaEl(r.id, 46, !reached));
      const mid = h('div', { class:'ladder-mid' });
      mid.appendChild(h('div', { class:'ladder-name', text:t('rank.' + r.id) }));
      const when = G.rankHistory[r.id];
      mid.appendChild(h('div', { class:'ladder-sub', text: reached ? (when ? t('rank.since', { date:fmtDateFull(when) }) : t('rank.reached')) : t('rank.needLevel', { n:r.min }) }));
      li.appendChild(mid);
      if(current) li.appendChild(h('span', { class:'ladder-now', text:t('rank.current') }));
      ladder.appendChild(li);
    });
    body.appendChild(ladder);
  }});
}
function achProgText(def, cur){
  if(def.metric === 'volumeKg') return fmtInt(kgToDisp(String(cur))) + ' / ' + fmtInt(kgToDisp(String(def.target))) + ' ' + unitLabel();
  if(def.metric === 'cardioMin') return fmtNum(cur / 60, 1) + ' / ' + fmtNum(def.target / 60, 0) + ' h';
  if(def.target === 1) return '';
  return fmtInt(Math.min(cur, def.target)) + ' / ' + fmtInt(def.target);
}
function openAchievementsScreen(){
  Modals.open({ title:t('ach.screenTitle'), tall:true, build(body){
    const G = State.data.gamification, game = State.game || computeGame(State.history, State.data);
    const got = ACHIEVEMENTS.filter(a=>G.achievements[a.id]).length;
    body.appendChild(h('div', { class:'ach-count', text:t('ach.count', { a:got, b:ACHIEVEMENTS.length }) }));
    const grid = h('div', { class:'ach-grid' });
    ACHIEVEMENTS.forEach(a=>{
      const ts = G.achievements[a.id], res = a.check(State.history, State.data, game);
      const card = h('button', { class:'ach-card' + (ts ? ' on' : ' off'), type:'button', 'aria-label':t('ach.' + a.id + '.n') + (ts ? ' — ' + t('ach.unlockedOn', { date:fmtDateFull(ts) }) : ' — ' + t('ach.locked')) });
      card.appendChild(h('span', { class:'ach-ic', html:achIconSVG(a.icon, ts ? '#FFD76A' : '#5A6068', 34) }));
      card.appendChild(h('div', { class:'ach-name', text:t('ach.' + a.id + '.n') }));
      card.appendChild(h('div', { class:'ach-desc', text:t('ach.' + a.id + '.d') }));
      if(ts) card.appendChild(h('div', { class:'ach-date', text:fmtDateShort(ts) }));
      else if(a.target > 1){
        const track = h('div', { class:'progress-track slim' }); track.appendChild(h('div', { class:'progress-fill', style:{ width:Math.min(100, res.cur / a.target * 100) + '%' } })); card.appendChild(track);
        card.appendChild(h('div', { class:'ach-prog', text:achProgText(a, res.cur) }));
      }
      card.addEventListener('click', ()=>openAchievementDetail(a.id));
      grid.appendChild(card);
    });
    body.appendChild(grid);
  }});
}
function openAchievementDetail(id){
  const def = ACHIEVEMENTS.find(a=>a.id === id), ts = State.data.gamification.achievements[id], res = def.check(State.history, State.data, State.game);
  Modals.open({ title:t('ach.' + id + '.n'), build(body, foot){
    body.classList.add('promo-body');
    body.appendChild(h('div', { class:'ach-big' + (ts ? '' : ' off'), html:achIconSVG(def.icon, ts ? '#FFD76A' : '#5A6068', 96) }));
    body.appendChild(h('div', { class:'promo-sub', text:t('ach.' + id + '.d') }));
    if(ts) body.appendChild(h('div', { class:'promo-date', text:t('ach.unlockedOn', { date:fmtDateFull(ts) }) }));
    else { const p = achProgText(def, res.cur); body.appendChild(h('div', { class:'promo-date', text:t('ach.locked') + (p ? ' • ' + p : '') })); }
    foot.appendChild(h('button', { class:'btn btn-ghost', type:'button', text:t('btn.back'), onclick:()=>openAchievementsScreen() }));
    if(ts) foot.appendChild(h('button', { class:'btn btn-primary', type:'button', onclick:()=>openShareCard({ kind:'achievement', id, ts }) }, [ icon('share'), t('btn.shareCard') ]));
  }});
}
function openStreakSheet(){
  const G = State.data.gamification, st = G.streak, game = State.game || computeGame(State.history, State.data);
  Modals.open({ title:t('streak.title'), build(body){
    body.appendChild(h('div', { class:'streak-big' }, [ h('span', { 'aria-hidden':'true', text:'🔥' }), h('b', { text:String(st.current) }), h('small', { text:t('streak.days', { n:st.current }) }) ]));
    const grid = h('div', { class:'stat-grid', style:{ marginBottom:'0' } });
    grid.appendChild(statCard(t('streak.best'), String(st.best), t('streak.days', { n:st.best })));
    grid.appendChild(statCard(t('lbl.weeksInGoal'), String(game.weekStreak.current), t('streak.record', { n:game.weekStreak.best })));
    grid.appendChild(statCard(t('streak.freezes'), String(st.freezes) + '/2', t('streak.freezeHint')));
    body.appendChild(grid);
    let msg = t('streak.tipStart');
    if(st.current > 0) msg = t('streak.tipKeep'); else if(game.streak.lastBreak) msg = t('streak.tipRestart', { best:st.best });
    body.appendChild(h('p', { class:'dlg-msg', text:msg }));
    body.appendChild(h('p', { class:'field-hint', text:t('streak.rules') }));
  }});
}

/* ---------- PERFIL / PREFERÊNCIAS ---------- */
function toggleRow(label, checked, onChange, hint){
  const row = h('div', { class:'toggle-row' });
  const tx = h('div', { class:'toggle-tx' }); tx.appendChild(h('div', { class:'toggle-lbl', id:'tg-' + U.slug(label), text:label })); if(hint) tx.appendChild(h('div', { class:'field-hint', text:hint }));
  const sw = h('button', { class:'switch' + (checked ? ' on' : ''), type:'button', role:'switch', 'aria-checked':String(!!checked), 'aria-labelledby':'tg-' + U.slug(label) }, [ h('span', { class:'knob' }) ]);
  sw.addEventListener('click', ()=>{ const v = sw.getAttribute('aria-checked') !== 'true'; sw.setAttribute('aria-checked', String(v)); sw.classList.toggle('on', v); onChange(v); });
  row.appendChild(tx); row.appendChild(sw); return row;
}
function renderSettingsView(){
  $('#profileTitle').textContent = t('prof.title');
  ['playerWrap','profileForm','prefsForm','dataBox','appBox'].forEach(id=>U.clear($('#' + id)));
  $('#playerTitle').hidden = !gamOn(); $('#playerTitle').textContent = t('prof.player');
  const P = State.data.profile;
  if(gamOn()){
    const G = State.data.gamification, lp = levelProgress(G.xpTotal), game = State.game || computeGame(State.history, State.data);
    const box = $('#playerWrap'), top = h('div', { class:'player-top' });
    top.appendChild(insigniaEl(lp.rank.id, 64));
    const mid = h('div', { class:'rank-mid' });
    mid.appendChild(h('div', { class:'rank-name', text:(P.name ? P.name + ' • ' : '') + t('rank.' + lp.rank.id) }));
    mid.appendChild(h('div', { class:'rank-sub', text:t('lbl.level', { n:lp.level }) + ' • ' + fmtInt(G.xpTotal) + ' ' + t('lbl.xp') }));
    top.appendChild(mid); box.appendChild(top);
    const grid = h('div', { class:'stat-grid', style:{ marginBottom:'8px' } });
    grid.appendChild(statCard(t('streak.current'), '🔥 ' + G.streak.current, t('streak.best') + ': ' + G.streak.best));
    grid.appendChild(statCard(t('ach.title'), got(G) + '/' + ACHIEVEMENTS.length, t('ach.unlockedPl')));
    grid.appendChild(statCard(t('prof.totalWorkouts'), String(State.history.length), t('lbl.sessions')));
    grid.appendChild(statCard(t('prof.bestWeek'), t('prof.daysN', { n:game.m.bestWeekSessions }), t('prof.inOneWeek')));
    box.appendChild(grid);
    const btns = h('div', { class:'two-btns' });
    btns.appendChild(h('button', { class:'btn btn-ghost', type:'button', text:t('rank.screenTitle'), onclick:openRanksScreen }));
    btns.appendChild(h('button', { class:'btn btn-ghost', type:'button', text:t('ach.screenTitle'), onclick:openAchievementsScreen }));
    box.appendChild(btns);
  }
  function got(G){ return ACHIEVEMENTS.filter(a=>G.achievements[a.id]).length; }
  const pf = $('#profileForm');
  const iName = h('input', { id:'p-name', type:'text', maxlength:'30', value:P.name || '', autocomplete:'off', placeholder:t('prof.namePh') });
  iName.addEventListener('change', ()=>{ P.name = iName.value.trim().slice(0,30); persistData(); });
  const iH = h('input', { id:'p-h', type:'text', inputmode:'numeric', value:P.heightCm ? String(P.heightCm) : '', placeholder:'—' });
  iH.addEventListener('change', ()=>{ const n = U.parseNum(iH.value); P.heightCm = n > 0 ? Math.round(n) : null; persistData(); });
  pf.appendChild(fieldEl(t('prof.name'), iName)); pf.appendChild(fieldEl(t('prof.height'), iH));
  const lastW = State.data.bodyLog[State.data.bodyLog.length-1];
  pf.appendChild(h('div', { class:'field-hint', text: lastW ? t('prof.lastWeight', { w:fmtLoad(String(lastW.kg), true), date:fmtDateShort(U.keyToTs(lastW.date)) }) : t('prof.noWeight') }));

  const pr = $('#prefsForm');
  const sLang = selectEl('pf-lang', [['auto', t('pref.langAuto')], ['pt-BR', t('lang.pt')], ['en', t('lang.en')]], S().language);
  sLang.addEventListener('change', ()=>{ S().language = sLang.value; persistData(); applyLanguage(); renderAll(); });
  const sUnit = selectEl('pf-unit', [['kg', t('unit.kg')], ['lb', t('unit.lb')]], S().weightUnit);
  sUnit.addEventListener('change', ()=>{ S().weightUnit = sUnit.value; persistData(); renderAll(); });
  const iGoal = h('input', { id:'pf-goal', type:'number', min:'1', max:'7', inputmode:'numeric', value:String(S().weeklyGoal) });
  iGoal.addEventListener('change', ()=>{ const n = Math.min(7, Math.max(1, Math.round(U.parseNum(iGoal.value) || 3))); iGoal.value = String(n); S().weeklyGoal = n; persistData(); rebuildGamification(); renderTopbar(); });
  const iRest = h('input', { id:'pf-rest', type:'number', min:'0', max:'900', inputmode:'numeric', value:String(S().defaultRest) });
  iRest.addEventListener('change', ()=>{ const n = Math.min(900, Math.max(0, Math.round(U.parseNum(iRest.value) ?? 90))); iRest.value = String(n); S().defaultRest = n; persistData(); });
  pr.appendChild(fieldEl(t('pref.language'), sLang)); pr.appendChild(h('div', { class:'field-row' }, [ fieldEl(t('pref.unit'), sUnit), fieldEl(t('pref.goal'), iGoal) ]));
  pr.appendChild(fieldEl(t('pref.rest'), iRest));
  pr.appendChild(toggleRow(t('pref.autoRest'), S().autoStartRest, v=>{ S().autoStartRest = v; persistData(); }));
  pr.appendChild(toggleRow(t('pref.sound'), S().sound, v=>{ S().sound = v; persistData(); }, t('pref.soundHint')));
  pr.appendChild(toggleRow(t('pref.gamOff'), S().gamificationOff, v=>{ S().gamificationOff = v; persistData(); renderAll(); }, t('pref.gamOffHint')));

  const db = $('#dataBox');
  db.appendChild(h('div', { class:'field-hint', text: S().lastBackupAt ? t('data.lastBackup', { date:fmtDateFull(S().lastBackupAt) }) : t('data.neverBackup') }));
  db.appendChild(h('button', { class:'btn btn-ghost btn-block', type:'button', text:t('data.export'), onclick:()=>exportBackup() }));
  db.appendChild(h('button', { class:'btn btn-ghost btn-block', type:'button', text:t('data.import'), onclick:()=>$('#fileImport').click() }));
  db.appendChild(h('button', { class:'btn btn-danger btn-block', type:'button', text:t('data.erase'), onclick:eraseAllData }));

  const ab = $('#appBox');
  ab.appendChild(h('button', { class:'btn btn-ghost btn-block', type:'button', onclick:openAbout }, [ icon('info'), t('about.title') ]));
  $('#aboutNote').textContent = APP_NAME + ' v' + APP_VERSION;
  $('#dataTitle').textContent = t('data.title'); $('#prefTitle').textContent = t('pref.title'); $('#appTitle').textContent = t('app.title');
}
function openAbout(){
  Modals.open({ title:t('about.title'), build(body, foot){
    body.appendChild(h('div', { class:'about-name', text:APP_NAME }));
    body.appendChild(h('div', { class:'about-ver', text:t('about.version', { v:APP_VERSION }) }));
    body.appendChild(h('div', { class:'sum-block' }, [ h('div', { class:'sum-h', text:t('about.privacyTitle') }), h('p', { class:'dlg-msg', text:t('about.privacy') }) ]));
    body.appendChild(h('div', { class:'sum-block' }, [ h('div', { class:'sum-h', text:t('about.healthTitle') }), h('p', { class:'dlg-msg', text:t('about.health') }) ]));
    if(SUPPORT_URL) body.appendChild(h('a', { class:'btn btn-ghost btn-block', href:SUPPORT_URL, target:'_blank', rel:'noopener noreferrer', text:t('about.support') }));
    foot.appendChild(h('button', { class:'btn btn-primary', type:'button', text:t('btn.close'), onclick:()=>Modals.close() }));
  }});
}

/* ---------- Backup / importar / apagar ---------- */
async function exportBackup(){
  const file = new File([JSON.stringify(buildBackupPayload(), null, 2)], backupFileName(), { type:'application/json' });
  const r = await shareOrDownloadFile(file, APP_NAME);
  if(r === 'aborted') return;
  S().lastBackupAt = Date.now(); persistData(); showToast(t('toast.exported'), 'success'); renderBanners(); if(State.currentView === 'settings') renderSettingsView();
}
async function importBackupFile(file){
  let parsed;
  try{ parsed = parseBackup(JSON.parse(await file.text())); }catch(e){ showToast(t('toast.badFile'), 'error'); return; }
  const ok = await confirmDialog({ title:t('imp.title'), message:t('imp.msg', { d:parsed.daysN, e:parsed.exN, s:parsed.history.length }), confirmText:t('imp.ok') });
  if(!ok) return;
  takeSnapshot();
  parsed.data.settings.language = S().language; parsed.data.settings.weightUnit = S().weightUnit; parsed.data.settings.installedAt = S().installedAt;
  State.data = parsed.data; State.history = parsed.history; State.active = null;
  persistData(); persistHistory(); persistActive(); closeRestTimer(); syncWakeLock();
  rebuildGamification(); pickInitialDay(); applyLanguage(); renderAll(); showUndoBar(t('undo.imported'));
}
async function eraseAllData(){
  const a = await confirmDialog({ title:t('erase.title1'), message:t('erase.msg1'), confirmText:t('erase.next') });
  if(!a) return;
  const b = await confirmDialog({ title:t('erase.title2'), message:t('erase.msg2'), confirmText:t('erase.final') });
  if(!b) return;
  takeSnapshot(); eraseAllStorage();
  State.data = defaultData(); State.history = []; State.active = null; State.currentDayId = null; State.game = computeGame([], State.data);
  closeRestTimer(); syncWakeLock(); persistData(); persistHistory(); persistActive();
  rebuildGamification(); applyLanguage(); State.currentView = 'train'; switchView('train'); renderAll(); showUndoBar(t('undo.erased'));
}
