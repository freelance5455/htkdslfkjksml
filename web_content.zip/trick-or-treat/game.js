/*
  Trick Or Treat
  Copyright (c) 2026 Johanna Maria Honkanen. All rights reserved.
*/
const cv=document.getElementById('c'),ctx=cv.getContext('2d');
/* the canvas fills the screen: W/H are the visible world size in CSS pixels */
let W=960,H=600,_vw=0,_vh=0;
function fit(){
  const vw=Math.max(1,Math.round(window.innerWidth||document.documentElement.clientWidth));
  const vh=Math.max(1,Math.round(window.innerHeight||document.documentElement.clientHeight));
  if(vw===_vw&&vh===_vh)return;
  _vw=vw;_vh=vh;
  /* never zoom out below 1:1; only pull back a little on very large screens */
  const sc=Math.max(1,vw/1100,vh/760);
  W=vw/sc;H=vh/sc;
  const dpr=Math.min(window.devicePixelRatio||1,2.5);
  cv.width=Math.round(vw*dpr);cv.height=Math.round(vh*dpr);
  cv.style.width=vw+'px';cv.style.height=vh+'px';
  ctx.setTransform(dpr*sc,0,0,dpr*sc,0,0);
  ctx.imageSmoothingEnabled=true;
}
addEventListener('resize',fit);
addEventListener('orientationchange',()=>{[50,200,500,1000].forEach(t=>setTimeout(fit,t))});
if(window.visualViewport)visualViewport.addEventListener('resize',fit);
fit();

/* ---------- input ---------- */
const keys={};let pressed={};
addEventListener('keydown',e=>{if(!keys[e.code])pressed[e.code]=true;keys[e.code]=true;initAudio();
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault()});
addEventListener('keyup',e=>keys[e.code]=false);
const isAct=()=>pressed.Space||pressed.KeyE||pressed.Enter;

/* ---------- touch controls ---------- */
let touchMode=false;try{touchMode=matchMedia('(pointer:coarse)').matches}catch(e){}
const joy={on:false,id:null,ox:0,oy:0,x:0,y:0,moved:0,t0:0};
const JOY_R=64,ACT_R=58;
function tpos(t){const r=cv.getBoundingClientRect();return[(t.clientX-r.left)*W/r.width,(t.clientY-r.top)*H/r.height]}
function actPos(){return[W-22-ACT_R,H-22-ACT_R]}
function inAct(px,py){const a=actPos();return Math.hypot(px-a[0],py-a[1])<ACT_R+16}
function choiceRect(i,n){const m=dlgMetrics();if(!m)return[-999,-999,0,0];
  const gap=8,gw=(m.bw-16-gap*(n-1))/n;
  return[m.bx+8+i*(gw+gap),m.by+m.bh-m.ch-8,gw,m.ch]}
function choiceAt(px,py){if(!G.dlg||!G.dlg.choices)return -1;const n=G.dlg.choices.length;
  for(let i=0;i<n;i++){const r=choiceRect(i,n);if(px>=r[0]-12&&px<=r[0]+r[2]+12&&py>=r[1]-12&&py<=r[1]+r[3]+12)return i}return -1}
function joyMove(px,py){let dx=px-joy.ox,dy=py-joy.oy;const l=Math.hypot(dx,dy);
  joy.moved=Math.max(joy.moved,l);
  if(l>JOY_R){dx*=JOY_R/l;dy*=JOY_R/l}
  let ax=dx/JOY_R,ay=dy/JOY_R;if(Math.hypot(ax,ay)<.16){ax=0;ay=0}joy.x=ax;joy.y=ay}
let _lastDown=0;
cv.addEventListener('pointerdown',e=>{e.preventDefault();initAudio();if(e.pointerType!=='mouse')touchMode=true;
  try{cv.setPointerCapture(e.pointerId)}catch(_){}
  const[px,py]=tpos(e);
  if(G.mode!=='play'){pressed.Enter=true;return}
  if(G.dlg){const d=G.dlg;
    if(d.choices&&d.shown>=d.lines[d.i].length){const i=choiceAt(px,py);if(i>=0){pressed['Digit'+(i+1)]=true;return}}
    pressed.Enter=true;return}
  if(e.pointerType==='mouse'||inAct(px,py)){pressed.Enter=true;return}
  joy.on=true;joy.id=e.pointerId;joy.ox=px;joy.oy=py;joy.x=0;joy.y=0;joy.moved=0;joy.t0=performance.now()});
cv.addEventListener('pointermove',e=>{if(joy.on&&e.pointerId===joy.id){e.preventDefault();const p=tpos(e);joyMove(p[0],p[1])}});
const pEnd=e=>{if(joy.on&&e.pointerId===joy.id){
  const quick=(performance.now()-joy.t0)<320&&joy.moved<16;
  joy.on=false;joy.x=0;joy.y=0;
  if(quick&&near&&!G.dlg)pressed.Enter=true}};
cv.addEventListener('pointerup',pEnd);cv.addEventListener('pointercancel',pEnd);cv.addEventListener('lostpointercapture',pEnd);
/* fallback: any tap/click anywhere starts the game from the title / end screens */
['touchstart','pointerdown','mousedown'].forEach(t=>addEventListener(t,()=>{if(G.mode==='title'||G.mode==='end'){_lastDown=Date.now();pressed.Enter=true;initAudio()}},{passive:true,capture:true}));
addEventListener('click',()=>{if((G.mode==='title'||G.mode==='end')&&Date.now()-_lastDown>1500){_lastDown=Date.now();pressed.Enter=true;initAudio()}},true);
cv.addEventListener('contextmenu',e=>e.preventDefault());

/* ---------- tiny sound ---------- */
let AC=null;
function initAudio(){if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)()}catch(e){}}if(AC&&AC.state==='suspended'){try{AC.resume()}catch(e){}}}
function beep(f,d=.1,type='square',v=.05){if(!AC)return;try{const o=AC.createOscillator(),g=AC.createGain();o.type=type;o.frequency.value=f;
  g.gain.value=v;g.gain.exponentialRampToValueAtTime(.001,AC.currentTime+d);o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+d)}catch(e){}}
const sfx={pick(){beep(660,.08);setTimeout(()=>beep(880,.12),70)},talk(){beep(220+Math.random()*80,.04,'triangle',.03)},
  token(){[523,659,784,1046].forEach((f,i)=>setTimeout(()=>beep(f,.2,'triangle',.07),i*110))},
  scare(){beep(120,.4,'sawtooth',.08)},knock(){beep(140,.07,'square',.08);setTimeout(()=>beep(140,.07,'square',.08),160)}};

/* ---------- state ---------- */
const G={mode:'title',scene:null,candy:0,tokens:{witch:false,zombie:false,vampire:false},mush:0,teddy:false,
  houses:0,t:0,fade:0,fadeDir:0,fadeCb:null,dlg:null,f:{}};
const P={x:0,y:0,r:11,face:1,walk:0};
let S=null;const cam={x:0,y:0};

function say(sp,lines,cb){G.dlg={sp,lines:[].concat(lines),i:0,shown:0,cb,choices:null}}
function ask(sp,text,opts,pick){G.dlg={sp,lines:[text],i:0,shown:0,cb:null,choices:opts,pick}}
function fadeTo(cb){G.fadeCb=cb;G.fadeDir=1}
const busy=()=>G.fadeDir!==0||G.dlg;

/* ---------- helpers ---------- */
function rng(s){return()=>(s=(s*16807)%2147483647)/2147483647}
function tri(a,b,c,d,e,f){ctx.beginPath();ctx.moveTo(a,b);ctx.lineTo(c,d);ctx.lineTo(e,f);ctx.closePath();ctx.fill()}
function glow(x,y,r,col,a=.5){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,col.replace('A',a));g.addColorStop(1,col.replace('A',0));ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}
function wrap(t,w){const out=[];let line='';for(const word of t.split(' ')){const test=line?line+' '+word:word;if(ctx.measureText(test).width>w){out.push(line);line=word}else line=test}out.push(line);return out}
function pumpkin(x,y,s=1,lit=true){ctx.save();ctx.translate(x,y);if(lit)glow(0,0,36*s,'rgba(255,150,30,A)',.45);
  ctx.fillStyle='#e8731a';ctx.beginPath();ctx.ellipse(0,0,13*s,11*s,0,0,7);ctx.fill();
  ctx.fillStyle='#c85a0c';ctx.beginPath();ctx.ellipse(-6*s,0,5*s,10*s,0,0,7);ctx.fill();ctx.beginPath();ctx.ellipse(6*s,0,5*s,10*s,0,0,7);ctx.fill();
  ctx.fillStyle='#3a6b1f';ctx.fillRect(-2*s,-14*s,4*s,5*s);
  if(lit){ctx.fillStyle='#ffe27a';tri(-7*s,-3*s,-3*s,-3*s,-5*s,-7*s);tri(3*s,-3*s,7*s,-3*s,5*s,-7*s);ctx.fillRect(-6*s,3*s,12*s,2.5*s)}
  ctx.restore()}

/* ---------- characters ---------- */
function drawGirl(x,y,f,walk){
  ctx.save();ctx.translate(x,y);const b=Math.sin(walk)*2;
  ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(0,13,11,5,0,0,7);ctx.fill();
  ctx.fillStyle='#222';ctx.fillRect(-5,6,4,7+b*.5);ctx.fillRect(1,6,4,7-b*.5);
  ctx.strokeStyle='#e8731a';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-f*6,4);ctx.quadraticCurveTo(-f*17,-1+b,-f*14,-13);ctx.stroke();
  ctx.fillStyle='#e8731a';ctx.beginPath();ctx.moveTo(-9,9);ctx.lineTo(-6,-8);ctx.lineTo(6,-8);ctx.lineTo(9,9);ctx.closePath();ctx.fill();
  ctx.fillStyle='#222';ctx.fillRect(-7,0,14,2);
  ctx.fillStyle='#f5cfa8';ctx.beginPath();ctx.arc(0,-14,8,0,7);ctx.fill();
  ctx.fillStyle='#5a3318';ctx.beginPath();ctx.arc(0,-16,8.5,Math.PI,0);ctx.fill();ctx.fillRect(-9,-16,3,11);ctx.fillRect(6,-16,3,11);
  ctx.fillStyle='#222';tri(-8,-21,-4,-28,-1,-21);tri(1,-21,4,-28,8,-21);
  ctx.fillRect(-4+f*1.5,-14,2,2);ctx.fillRect(2+f*1.5,-14,2,2);
  ctx.fillStyle='#ff9a2e';ctx.fillRect(f*9-4,-2+b*.3,8,7);ctx.fillStyle='#ff4fa0';ctx.fillRect(f*9-2,-4+b*.3,4,3);
  ctx.restore()}
function person(x,y,o){
  ctx.save();ctx.translate(x,y+Math.sin(G.t/18+x)*1.5);
  ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(0,15,13,5,0,0,7);ctx.fill();
  if(o.cape){ctx.fillStyle='#14091f';ctx.beginPath();ctx.moveTo(-12,14);ctx.lineTo(-8,-10);ctx.lineTo(8,-10);ctx.lineTo(12,14);ctx.closePath();ctx.fill();ctx.fillStyle='#a3122b';ctx.fillRect(-9,-8,18,3)}
  ctx.fillStyle=o.cloth;ctx.beginPath();ctx.moveTo(-9,14);ctx.lineTo(-7,-9);ctx.lineTo(7,-9);ctx.lineTo(9,14);ctx.closePath();ctx.fill();
  if(o.arms){ctx.fillStyle=o.skin;ctx.fillRect(-16,-6,10,4);ctx.fillRect(6,-6,10,4)}
  ctx.fillStyle=o.skin;ctx.beginPath();ctx.arc(0,-15,9,0,7);ctx.fill();
  if(o.hat){ctx.fillStyle='#1a0f26';ctx.beginPath();ctx.ellipse(0,-21,15,4,0,0,7);ctx.fill();tri(-8,-21,0,-44,8,-21);ctx.fillStyle='#c9a227';ctx.fillRect(-7,-25,14,3)}
  if(o.hair){ctx.fillStyle=o.hair;ctx.beginPath();ctx.arc(0,-18,9.5,Math.PI,0);ctx.fill()}
  ctx.fillStyle=o.eye||'#111';ctx.fillRect(-5,-16,3,3);ctx.fillRect(2,-16,3,3);
  if(o.fangs){ctx.fillStyle='#fff';tri(-3,-9,-1,-9,-2,-5);tri(1,-9,3,-9,2,-5)}
  if(o.stitch){ctx.strokeStyle='#2c3a1e';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-6,-20);ctx.lineTo(-1,-21);ctx.stroke()}
  ctx.restore()}
const NPC={
  witch:(x,y)=>person(x,y,{skin:'#7fb36a',cloth:'#5b2a86',hat:1,eye:'#ffe400'}),
  zombie:(x,y)=>person(x,y,{skin:'#8aa17a',cloth:'#6a4e32',arms:1,stitch:1,eye:'#d11'}),
  vampire:(x,y)=>person(x,y,{skin:'#e9e4ee',cloth:'#222',cape:1,hair:'#0f0f14',fangs:1,eye:'#d11'}),
  cat(x,y){ctx.save();ctx.translate(x,y+Math.sin(G.t/20)*1.5);ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(0,10,12,4,0,0,7);ctx.fill();
    ctx.fillStyle='#0c0c10';ctx.beginPath();ctx.ellipse(0,2,11,8,0,0,7);ctx.fill();ctx.beginPath();ctx.arc(0,-8,8,0,7);ctx.fill();tri(-8,-12,-5,-21,-1,-14);tri(1,-14,5,-21,8,-12);
    ctx.strokeStyle='#0c0c10';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(10,4);ctx.quadraticCurveTo(22,-4,16,-14);ctx.stroke();
    ctx.fillStyle='#ffe400';ctx.fillRect(-5,-10,3,3);ctx.fillRect(2,-10,3,3);ctx.restore()}
};
function label(x,y,t){ctx.font='bold 12px Georgia';ctx.textAlign='center';ctx.fillStyle='#000a';ctx.fillText(t,x+1,y+1);ctx.fillStyle='#ffe9b0';ctx.fillText(t,x,y)}

/* ---------- scenes ---------- */
function makeTown(){
  const s={name:'town',w:1700,h:700,spawn:[110,450],rects:[],circles:[],inter:[],pickups:[],ghosts:[],knocked:[false,false,false]};
  const hx=[200,640,1080],col=['#6b3a2a','#3b3f6b','#4a5a2e'];
  const lines=[
    [['Mia','Trick or treat!'],['Neighbour','Ooh, what a darling cat! Take a handful, sweetie!'],3],
    [['Mia','Trick or treat!'],['Neighbour',"Happy Halloween! Be careful tonight — folks say the woods past the street swallow wandering kids whole. Hehe!"],2],
    [['Mia','Trick or treat!'],['Neighbour',"Last house on the street! Here, the good stuff. Now hurry home!"],4]];
  hx.forEach((x,i)=>{
    s.rects.push([x,60,240,200]);
    s.inter.push({x:x+120,y:292,label:'Knock',active:()=>!s.knocked[i],act(){
      sfx.knock();s.knocked[i]=true;G.houses++;G.candy+=lines[i][2];
      say(lines[i][0][0],lines[i][0][1],()=>say(lines[i][1][0],lines[i][1][1],()=>{
        sfx.pick();say('',['+'+lines[i][2]+' candy!  ('+G.houses+'/3 houses)'],()=>{
          if(G.houses===3)say('Mia',["That's all three! My bucket is heavy... and I still want more.","Wait — what's that? A glowing orange path leading into the woods at the end of the street...","Maybe there's a bonus house with GIANT candy bars. Just a quick peek!"])})}))}})});
  [[60,160],[1640,150],[1500,90],[40,620],[1660,640],[900,640]].forEach(c=>s.circles.push([c[0],c[1],20]));
  s.enter=()=>say('Mia',["It's Halloween night, and my cat costume came out purrfect!","Mom said three houses on our street, then home. Easy!",touchMode?"(Move: drag your finger on the left side. Knock, talk & continue text: tap the right side or the text box.)":"(Move: WASD / arrow keys.  Talk, knock & continue text: E, Space or Enter.)"]);
  s.update=()=>{if(P.x>1650){if(G.houses<3){P.x=1640;if(!G.f.edge){G.f.edge=1;say('Mia',["I should visit all three houses first. Mom's rules!"])}}
    else{G.f.edge=0;fadeTo(()=>loadScene('forest'))}}};
  s.draw=()=>{
    ctx.fillStyle='#1b2b20';ctx.fillRect(0,0,s.w,s.h);
    ctx.fillStyle='#2a2630';ctx.fillRect(0,262,s.w,68);
    ctx.fillStyle='#38323f';ctx.fillRect(0,330,s.w,230);
    ctx.fillStyle='#4b4455';for(let x=0;x<s.w;x+=120)ctx.fillRect(x,440,60,8);
    ctx.fillStyle='#1b2b20';ctx.fillRect(0,560,s.w,140);
    ctx.fillStyle='#3d2f22';for(let x=0;x<s.w;x+=36){ctx.fillRect(x,590,6,40)}ctx.fillRect(0,600,s.w,5);
    hx.forEach((x,i)=>{
      ctx.fillStyle=col[i];ctx.fillRect(x,60,240,200);
      ctx.fillStyle='#2a1a1a';tri(x-14,62,x+120,0,x+254,62);
      for(const wx of [x+25,x+170]){ctx.fillStyle=s.knocked[i]?'#ffcf5a':'#ffb347';ctx.fillRect(wx,100,45,45);glow(wx+22,122,70,'rgba(255,170,60,A)',.25);ctx.fillStyle='#1a1008';ctx.fillRect(wx+21,100,3,45);ctx.fillRect(wx,121,45,3)}
      ctx.fillStyle='#24140c';ctx.fillRect(x+95,170,50,90);ctx.fillStyle='#d4a017';ctx.fillRect(x+132,218,5,5);
      pumpkin(x+50,285,1);pumpkin(x+195,285,1.1);
      ctx.fillStyle='#fff8';for(let k=0;k<4;k++){ctx.beginPath();ctx.arc(x+20+k*60,48-Math.sin(k)*5,0,0,7)}
    });
    s.circles.forEach(c=>{ctx.fillStyle='#2b1c12';ctx.fillRect(c[0]-5,c[1]-6,10,26);ctx.fillStyle='#143019';ctx.beginPath();ctx.arc(c[0],c[1]-14,30,0,7);ctx.fill();ctx.fillStyle='#1a3b20';ctx.beginPath();ctx.arc(c[0]-8,c[1]-20,18,0,7);ctx.fill()});
    if(G.houses>=3){for(let x=1350;x<1700;x+=60){pumpkin(x,445+Math.sin(x)*8,.8)}ctx.font='bold 14px Georgia';ctx.textAlign='center';ctx.fillStyle='#ffcf5a';ctx.fillText('→ BONUS CANDY HOUSE →',1540,410)}
  }; return s}

function makeForest(){
  const s={name:'forest',w:2400,h:1600,spawn:[110,800],rects:[],circles:[],inter:[],pickups:[],ghosts:[],trees:[]};
  const r=rng(777);let guard=0;
  while(s.trees.length<260&&guard++<6000){const x=r()*s.w,y=r()*s.h;
    if(Math.hypot(x-110,y-800)<150||Math.hypot(x-2290,y-800)<190)continue;
    if(s.trees.some(t=>Math.hypot(t[0]-x,t[1]-y)<82))continue;s.trees.push([x,y,r()])}
  s.trees.forEach(t=>s.circles.push([t[0],t[1],17]));
  const flies=[];for(let i=0;i<50;i++)flies.push([r()*s.w,r()*s.h,r()*6]);
  s.enter=()=>say('Mia',["The glowing path... it's so quiet in here.","Hello? Is anybody home? ...Where did the street go?"]);
  s.update=()=>{
    if(P.x>650&&!G.f.f1){G.f.f1=1;say('Mia',["This doesn't look like a candy house at all... Okay, let's go back."," ...Which way did I come from? Everything looks the same!"])}
    if(P.x>1350&&!G.f.f2){G.f.f2=1;say('Mia',["I'm lost. I'm really lost. My phone has no signal...","Wait... a faint orange glow, far ahead. Maybe it's a lantern. Maybe someone's there."])}
    if(Math.hypot(P.x-2290,P.y-800)<70&&!G.f.f3){G.f.f3=1;
      say('Mia',["It's... only a clearing. No house. Just pumpkins glowing on their own...","Why is everything spinning? I feel so dizzy... I... "],()=>{sfx.scare();fadeTo(()=>loadScene('hub'))})}};
  s.draw=()=>{
    ctx.fillStyle='#0d1a12';ctx.fillRect(0,0,s.w,s.h);
    ctx.fillStyle='#142a1b';for(let i=0;i<150;i++){const q=(i*9301+49297)%233280/233280,q2=(i*4973+12345)%233280/233280;ctx.beginPath();ctx.arc(q*s.w,q2*s.h,24+q*20,0,7);ctx.fill()}
    glow(2290,800,260,'rgba(255,140,40,A)',.55);ctx.fillStyle='#1d3a22';ctx.beginPath();ctx.arc(2290,800,120,0,7);ctx.fill();
    for(let a=0;a<6;a++)pumpkin(2290+Math.cos(a*1.05)*85,800+Math.sin(a*1.05)*85,1);
    s.trees.forEach(t=>{if(t[0]<cam.x-60||t[0]>cam.x+W+60||t[1]<cam.y-80||t[1]>cam.y+H+80)return;
      ctx.fillStyle='#1e130b';ctx.fillRect(t[0]-6,t[1]-6,12,32);ctx.fillStyle='#0a1f10';ctx.beginPath();ctx.arc(t[0],t[1]-12,34,0,7);ctx.fill();ctx.fillStyle='#0f2c16';ctx.beginPath();ctx.arc(t[0]-9,t[1]-20,19,0,7);ctx.fill()});
    flies.forEach(f=>{const x=f[0]+Math.sin(G.t/60+f[2])*20,y=f[1]+Math.cos(G.t/50+f[2])*20;glow(x,y,10,'rgba(200,255,120,A)',.9)});
  };
  s.dark=true;return s}

function makeHub(){
  const s={name:'hub',w:2000,h:1300,spawn:[1000,1120],rects:[],circles:[],inter:[],pickups:[],ghosts:[],tombs:[],bats:[]};
  s.rects.push([820,560,360,200],[220,270,180,140],[880,90,40,130],[1080,90,40,130]);
  for(let gx=1500;gx<=1900;gx+=100)for(let gy=620;gy<=1080;gy+=100){const jx=(gx*7+gy*3)%30-15,jy=(gx*5+gy*11)%30-15;
    if(Math.hypot(gx-1750,gy-960)<70)continue;s.tombs.push([gx+jx,gy+jy]);s.circles.push([gx+jx,gy+jy,14])}
  [[120,150],[1880,150],[500,180],[1500,160],[100,700],[1900,1200],[700,1200],[1300,1230]].forEach(c=>s.circles.push([c[0],c[1],20]));
  [[250,900],[450,1060],[320,1160],[620,960],[170,1090]].forEach(m=>s.pickups.push({x:m[0],y:m[1],kind:'mush',got:false}));
  s.pickups.push({x:1750,y:960,kind:'teddy',got:false});
  [[1620,760,150,0],[1700,900,130,2],[1800,700,120,4],[1580,1000,110,1]].forEach(g=>s.ghosts.push({cx:g[0],cy:g[1],rad:g[2],a:g[3],x:0,y:0}));
  for(let i=0;i<7;i++)s.bats.push({x:Math.random()*2000,y:Math.random()*1300,v:1+Math.random()*1.5,p:Math.random()*6});
  const need=()=>Object.values(G.tokens).filter(Boolean).length;
  s.inter.push({x:1000+60,y:1060,label:'Talk',act(){
    if(need()===3)say('Boo the Cat',["You've got all three tokens! Go on — the Moon Gate is north, past the castle.","Careful, kid. Home is still two realms away: Sugar Valley and Midnight Manor."]);
    else say('Boo the Cat',["Three tokens, kid: the Witch (hut, west), the Zombie (graveyard, east), the Vampire (castle, just north of here).","Tokens so far: "+need()+"/3. Mind the ghosts."])}});
  s.inter.push({x:310,y:445,label:'Talk',act(){
    if(G.tokens.witch)return say('Witch Hazel',["Safe travels, little cat! The mushrooms made a splendid stew."]);
    if(G.mush>=5){G.tokens.witch=true;sfx.token();return say('Witch Hazel',["Five glowing mushrooms! Perfect — my potion will bubble all night.","Take this Witch Token. You've earned it, dearie!"],()=>say('',['★ Witch Token obtained! ('+need()+'/3)']))}
    if(!G.f.wStart){G.f.wStart=1;return say('Witch Hazel',["Eeheehee! A mortal child! I'll trade you a Spooky Token for a favour.","My stew needs 5 glowing mushrooms from the Bubbling Swamp, south-west of my hut. Fetch them and the token is yours!"])}
    say('Witch Hazel',["You've found "+G.mush+" of 5 glowing mushrooms. Look around the green swamp, south-west!"])}});
  s.inter.push({x:1400,y:540,label:'Talk',act(){
    if(G.tokens.zombie)return say('Zed the Zombie',["Brainsss... I mean, thankss. Teddy and I are happy now."]);
    if(G.teddy){G.tokens.zombie=true;sfx.token();return say('Zed the Zombie',["TEDDY! You found Mr. Snuggles! *sniff*","Zombiess don't cry... but my eye is leaking. Take this Zombie Token, human."],()=>say('',['★ Zombie Token obtained! ('+need()+'/3)']))}
    if(!G.f.zStart){G.f.zStart=1;return say('Zed the Zombie',["Uuuurgh... hello, small human. I lost my teddy bear, Mr. Snuggles, somewhere in the graveyard.","Ghosts keep chasing me away. Can you get him back? The token is yours if you do."])}
    say('Zed the Zombie',["Mr. Snuggles... please find him in the graveyard. Watch out for the ghosts!"])}});
  const riddle=(q,opts,ok,next)=>ask('Count Vesper',q,opts,i=>{if(i===ok)say('Count Vesper',["Correct! Hmm, not bad for a mortal."],next);else say('Count Vesper',["Wrong! Think harder, child. Once more..."],()=>riddle(q,opts,ok,next))});
  s.inter.push({x:1000,y:830,label:'Talk',act(){
    if(G.tokens.vampire)return say('Count Vesper',["Run along home, little cat. And do try the garlic bread sometime."]);
    const giveToken=()=>{G.tokens.vampire=true;sfx.token();say('Count Vesper',["Two riddles solved. I am... impressed. Here, the Vampire Token."],()=>say('',['★ Vampire Token obtained! ('+need()+'/3)']))};
    const quiz=()=>riddle("What has hands but cannot clap?",["1. A ghost","2. A clock","3. A broom"],1,()=>riddle("The more of me you take, the more you leave behind. What am I?",["1. Footsteps","2. Candy","3. Shadows"],0,giveToken));
    if(G.f.vPaid)return quiz();
    say('Count Vesper',["Ah, a visitor. I love company... and candy. The entry fee for my riddle contest is 3 pieces of candy."],()=>
      ask('Count Vesper',"Candy in your bucket: "+G.candy+". Pay 3 candy?",["1. Pay 3 candy","2. Not now"],i=>{
        if(i===1)return say('Count Vesper',["Pity. Come back when you're feeling brave."]);
        if(G.candy<3)return say('Count Vesper',["You don't have enough candy! Hm... find some."]);
        G.candy-=3;G.f.vPaid=1;sfx.pick();say('Count Vesper',["Splendid. First riddle!"],quiz)}))}});
  s.inter.push({x:1000,y:235,label:'Moon Gate',act(){
    if(need()<3)return say('',["The Moon Gate is sealed. Three token slots glow faintly above it.  ("+need()+"/3)"]);
    say('Mia',["The slots light up one by one... The Moon Gate is open!","But the light on the other side is pink and sparkly... and smells like sugar?"],()=>fadeTo(()=>loadScene('candy')))}});
  s.enter=()=>say('Mia',["Ow... my head. Where am I? Why is the sky purple?!"],()=>say('Boo the Cat',["Meow. Welcome to Spooky Hollow, kid. Nobody gets here by accident.","The only way home is the Moon Gate, up north. It opens with three Spooky Tokens.","Earn one from the Witch (hut, west), the Zombie (graveyard, east) and the Vampire (castle, close by). They're odd, but fair. Talk to me if you need a hint."],()=>say('Mia',["A TALKING CAT?! ...Okay. Okay. I can do this. I just want to go home."])));
  s.update=()=>{
    s.pickups.forEach(p=>{if(p.got)return;if(Math.hypot(P.x-p.x,P.y-p.y)<24){p.got=true;sfx.pick();
      if(p.kind==='mush'){G.mush++;say('',['Glowing mushroom! ('+G.mush+'/5)'])}else{G.teddy=true;say('Mia',["A teddy bear with a stitched smile... 'Mr. Snuggles'. This must be Zed's! Back to the zombie."])}}});
    s.ghosts.forEach(g=>{g.a+=.015;g.x=g.cx+Math.cos(g.a)*g.rad;g.y=g.cy+Math.sin(g.a*1.3)*g.rad*.7;
      if(!busy()&&Math.hypot(P.x-g.x,P.y-g.y)<24){sfx.scare();fadeTo(()=>{P.x=1420;P.y=640;say('Mia',["BOO!! The ghost scared me right out of the graveyard! Deep breath... try again, carefully."])})}});
    s.bats.forEach(b=>{b.x+=b.v;if(b.x>2100){b.x=-100;b.y=Math.random()*1300}b.p+=.3})};
  s.draw=()=>{
    ctx.fillStyle='#2a1740';ctx.fillRect(0,0,s.w,s.h);
    ctx.fillStyle='#331c4d';for(let i=0;i<110;i++){const q=(i*9301+49297)%233280/233280,q2=(i*4973+12345)%233280/233280;ctx.beginPath();ctx.arc(q*s.w,q2*s.h,22+q*26,0,7);ctx.fill()}
    ctx.fillStyle='#4a3a5c';ctx.fillRect(960,230,80,900);ctx.fillRect(300,430,700,60);ctx.fillRect(1000,500,500,60);
    ctx.fillStyle='#183b2a';ctx.beginPath();ctx.ellipse(380,1040,260,190,0,0,7);ctx.fill();ctx.fillStyle='#2f8f55';for(let i=0;i<14;i++){ctx.beginPath();ctx.arc(250+(i*53)%280,980+(i*37)%130,5+(i%3),0,7);ctx.fill()}
    ctx.fillStyle='#35264a';ctx.beginPath();ctx.ellipse(1700,860,260,300,0,0,7);ctx.fill();
    s.tombs.forEach(t=>{ctx.fillStyle='#7a7585';ctx.fillRect(t[0]-10,t[1]-16,20,28);ctx.beginPath();ctx.arc(t[0],t[1]-16,10,Math.PI,0);ctx.fill();ctx.fillStyle='#4a4555';ctx.fillRect(t[0]-1,t[1]-12,2,10);ctx.fillRect(t[0]-5,t[1]-8,10,2)});
    // witch hut
    ctx.fillStyle='#5a3a24';ctx.fillRect(220,300,180,110);ctx.fillStyle='#2e6b3a';tri(205,305,310,215,415,305);ctx.fillStyle='#ffd24d';ctx.fillRect(250,330,36,36);glow(268,348,60,'rgba(255,210,80,A)',.3);ctx.fillStyle='#24140c';ctx.fillRect(320,340,44,70);
    // cauldron
    ctx.fillStyle='#111';ctx.beginPath();ctx.arc(445,440,20,0,7);ctx.fill();ctx.fillStyle='#4bd05a';ctx.beginPath();ctx.ellipse(445,433,15,6,0,0,7);ctx.fill();glow(445,430,50,'rgba(80,255,100,A)',.35);
    // castle
    ctx.fillStyle='#1a1224';ctx.fillRect(820,560,360,200);ctx.fillRect(800,520,60,240);ctx.fillRect(1140,520,60,240);tri(795,522,830,450,865,522);tri(1135,522,1170,450,1205,522);
    ctx.fillStyle='#ffcf5a';[[850,600],[1120,600],[950,620],[1030,620]].forEach(w=>{ctx.fillRect(w[0],w[1],22,34)});glow(1000,630,200,'rgba(255,90,90,A)',.15);ctx.fillStyle='#0a0610';ctx.fillRect(975,690,50,70);
    // moon gate
    ctx.fillStyle='#8a8498';ctx.fillRect(880,90,40,130);ctx.fillRect(1080,90,40,130);ctx.fillRect(870,70,260,30);
    const all=Object.values(G.tokens).every(Boolean),n=Object.values(G.tokens).filter(Boolean).length;
    ctx.save();ctx.beginPath();ctx.ellipse(1000,160,80,64,0,0,7);ctx.clip();ctx.fillStyle=all?'#aaf3ff':'#2a2150';ctx.fillRect(920,100,160,130);
    ctx.strokeStyle=all?'#fff':'#4b3d86';ctx.lineWidth=5;for(let k=0;k<5;k++){ctx.beginPath();ctx.arc(1000,160,10+k*14,G.t/40+k,G.t/40+k+3);ctx.stroke()}ctx.restore();
    if(all)glow(1000,160,200,'rgba(170,240,255,A)',.5);
    [['#b46bff',G.tokens.witch],['#7bd06a',G.tokens.zombie],['#ff4466',G.tokens.vampire]].forEach((t,i)=>{ctx.fillStyle=t[1]?t[0]:'#2c2540';ctx.beginPath();ctx.arc(975+i*25,84,8,0,7);ctx.fill();if(t[1])glow(975+i*25,84,30,'rgba(255,255,255,A)',.4)});
    // pumpkins
    [[900,300],[1100,300],[860,860],[1140,860],[600,600],[1400,400],[500,1220]].forEach(p=>pumpkin(p[0],p[1],1));
    // trees
    s.circles.filter(c=>c[2]===20).forEach(c=>{ctx.fillStyle='#1c1020';ctx.fillRect(c[0]-5,c[1]-6,10,28);ctx.fillStyle='#2b1740';ctx.beginPath();ctx.arc(c[0],c[1]-14,30,0,7);ctx.fill();ctx.fillStyle='#3a2058';ctx.beginPath();ctx.arc(c[0]-8,c[1]-20,17,0,7);ctx.fill()});
    // pickups
    s.pickups.forEach(p=>{if(p.got)return;if(p.kind==='mush'){glow(p.x,p.y,40,'rgba(120,255,180,A)',.6);ctx.fillStyle='#e8fff0';ctx.fillRect(p.x-2,p.y,4,9);ctx.fillStyle='#4bffa0';ctx.beginPath();ctx.arc(p.x,p.y,9,Math.PI,0);ctx.fill()}
      else{glow(p.x,p.y,36,'rgba(255,200,120,A)',.5);ctx.fillStyle='#b9763a';ctx.beginPath();ctx.arc(p.x,p.y,9,0,7);ctx.arc(p.x-7,p.y-8,4,0,7);ctx.arc(p.x+7,p.y-8,4,0,7);ctx.fill();ctx.fillStyle='#222';ctx.fillRect(p.x-4,p.y-3,2,2);ctx.fillRect(p.x+2,p.y-3,2,2)}});
    // npcs
    NPC.cat(1060,1060);label(1060,1030,'Boo');
    NPC.witch(310,445);label(310,395,'Witch Hazel');
    NPC.zombie(1400,540);label(1400,495,'Zed');
    NPC.vampire(1000,830);label(1000,780,'Count Vesper');
    // ghosts
    s.ghosts.forEach(g=>{const y=g.y+Math.sin(G.t/15+g.a*3)*4;glow(g.x,y,50,'rgba(200,230,255,A)',.35);ctx.fillStyle='rgba(235,245,255,.85)';ctx.beginPath();ctx.arc(g.x,y-4,15,Math.PI,0);ctx.lineTo(g.x+15,y+16);for(let k=0;k<3;k++)ctx.lineTo(g.x+10-k*10,y+(k%2?16:10));ctx.lineTo(g.x-15,y+16);ctx.closePath();ctx.fill();ctx.fillStyle='#223';ctx.fillRect(g.x-7,y-7,4,6);ctx.fillRect(g.x+3,y-7,4,6)});
    // bats
    ctx.fillStyle='#05020a';s.bats.forEach(b=>{const w=Math.sin(b.p)*8;ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(b.x-14,b.y-w);ctx.lineTo(b.x-6,b.y+4);ctx.lineTo(b.x,b.y+2);ctx.lineTo(b.x+6,b.y+4);ctx.lineTo(b.x+14,b.y-w);ctx.closePath();ctx.fill()});
  };return s}

/* ---------- extra worlds: Sugar Valley & Midnight Manor ---------- */
NPC.queen=(x,y)=>{person(x,y,{skin:'#ffd0e0',cloth:'#ff5fa8',hair:'#ffd24d',eye:'#111'});ctx.fillStyle='#ffd24d';tri(x-9,y-27,x-5,y-37,x-1,y-27);tri(x-3,y-27,x+1,y-39,x+5,y-27);tri(x+3,y-27,x+7,y-37,x+11,y-27)};
NPC.gus=(x,y)=>{person(x,y,{skin:'#c98b4b',cloth:'#a8672f',eye:'#fff'});ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x,y-1,2.5,0,7);ctx.arc(x,y+7,2.5,0,7);ctx.fill()};
NPC.skeleton=(x,y)=>{person(x,y,{skin:'#f1f1f1',cloth:'#222233',eye:'#111'});ctx.fillStyle='#d11';ctx.fillRect(x-5,y-6,10,4)};
function drawGhosts(list){list.forEach(g=>{const y=g.y+Math.sin(G.t/15+g.a*3)*4;glow(g.x,y,50,'rgba(200,230,255,A)',.35);ctx.fillStyle='rgba(235,245,255,.85)';ctx.beginPath();ctx.arc(g.x,y-4,15,Math.PI,0);ctx.lineTo(g.x+15,y+16);for(let k=0;k<3;k++)ctx.lineTo(g.x+10-k*10,y+(k%2?16:10));ctx.lineTo(g.x-15,y+16);ctx.closePath();ctx.fill();ctx.fillStyle='#223';ctx.fillRect(g.x-7,y-7,4,6);ctx.fillRect(g.x+3,y-7,4,6)})}
function hazards(s,rx,ry,msg,sp){s.ghosts.forEach(g=>{g.a+=sp;g.x=g.cx+Math.cos(g.a)*g.rad;g.y=g.cy+Math.sin(g.a*1.3)*g.rad*.7;
  if(!busy()&&Math.hypot(P.x-g.x,P.y-g.y)<24){sfx.scare();fadeTo(()=>{P.x=rx;P.y=ry;say('Mia',[msg])})}})}
function grab(s,fn){s.pickups.forEach(p=>{if(p.got)return;if(Math.hypot(P.x-p.x,P.y-p.y)<24){p.got=true;sfx.pick();fn(p)}})}

function makeCandy(){
  const s={name:'candy',w:2000,h:1200,spawn:[120,600],rects:[[940,0,90,500],[940,700,90,500]],circles:[],inter:[],pickups:[],ghosts:[],trees:[]};
  [[60,100],[220,160],[120,1050],[330,980],[560,1080],[640,160],[780,300],[760,900],[500,820],[1100,120],[1120,1080],[1280,560],[1450,150],[1480,1020],[1720,560],[1850,1000],[1880,120]].forEach((t,i)=>{s.trees.push([t[0],t[1],i%3]);s.circles.push([t[0],t[1],16])});
  [[1200,200],[1350,950],[1550,400],[1650,800],[1800,250]].forEach(p=>s.pickups.push({x:p[0],y:p[1],got:false}));
  [[1330,560,170,0],[1600,660,140,2],[1420,250,110,4],[1250,880,120,1]].forEach((g,i)=>s.ghosts.push({cx:g[0],cy:g[1],rad:g[2],a:g[3],x:0,y:0,c:i}));
  s.inter.push({x:330,y:520,label:'Talk',act(){
    if(G.key)return say('Queen Taffy',["The Rainbow Gate is in the far east. Hurry home, sweet traveler!"]);
    if(G.lolli>=5){G.key=true;G.candy+=5;sfx.token();return say('Queen Taffy',["Five Rainbow Lollipops! Marvelous! Let me melt them into a key...","*Sparkle sparkle*  Here is the Candy Key, and a bucket of sweets for your trouble!"],()=>say('',['★ Candy Key obtained!  +5 candy!']))}
    if(!G.f.qStart){G.f.qStart=1;return say('Queen Taffy',["Oh! A visitor from the Spooky Side! I am Queen Taffy of Sugar Valley.","The Rainbow Gate to the next realm is locked, and my Candy Key melted into 5 Rainbow Lollipops. They are scattered in the Lollipop Woods, east across the chocolate river.","Bring them to me and I will make you a new key. But beware the Sticky Gumdrops. They bounce, and they are VERY sticky!"])}
    say('Queen Taffy',["You have "+G.lolli+" of 5 Rainbow Lollipops. Look across the chocolate bridge, in the east!"])}});
  s.inter.push({x:870,y:600,label:'Talk',act(){say('Gus the Gingerbread',["Psst! Watch the gumdrops. They bounce in circles. Wait for one to swing away, then dash!","If one sticks to you, you get sent back to the bridge. Not fun. Trust me."])}});
  s.inter.push({x:1900,y:600,label:'Rainbow Gate',act(){
    if(!G.key)return say('',["The Rainbow Gate is locked. Maybe Queen Taffy can help?"]);
    say('Mia',["The Candy Key fits! The rainbow swirls open... but the air on the other side smells like dust and candle wax."],()=>fadeTo(()=>loadScene('mansion')))}});
  s.enter=()=>say('Mia',["Everything smells like sugar... Is that a river of CHOCOLATE?!","The Moon Gate threw me into some kind of candy world. Maybe someone here knows the way home."]);
  s.update=()=>{
    grab(s,p=>{G.lolli++;G.candy++;say('',['Rainbow Lollipop! ('+G.lolli+'/5)  +1 candy'])});
    hazards(s,1070,600,"Yuck! Sticky! A gumdrop bounced me all the way back to the bridge. Okay... timing is everything.",.02)};
  s.draw=()=>{
    ctx.fillStyle='#ffd9ee';ctx.fillRect(0,0,s.w,s.h);
    ctx.fillStyle='#ffc6e3';for(let i=0;i<70;i++){const q=(i*9301+49297)%233280/233280,q2=(i*4973+12345)%233280/233280;ctx.beginPath();ctx.arc(q*s.w,q2*s.h,26+q*30,0,7);ctx.fill()}
    ctx.fillStyle='#c9f5e2';for(let i=0;i<30;i++){const q=(i*7919+1013)%233280/233280,q2=(i*6271+777)%233280/233280;ctx.beginPath();ctx.arc(q*s.w,q2*s.h,22+q*20,0,7);ctx.fill()}
    const sp=['#ff4f4f','#ffd84f','#4fb3ff','#8aff4f','#a46fff'];for(let i=0;i<120;i++){const q=(i*8863+331)%233280/233280,q2=(i*5851+907)%233280/233280;ctx.fillStyle=sp[i%5];ctx.fillRect(q*s.w,q2*s.h,6,2)}
    ctx.fillStyle='#ffeccc';ctx.fillRect(0,570,s.w,60);
    ctx.fillStyle='#5a3320';ctx.fillRect(930,0,110,s.h);
    ctx.fillStyle='#7a4a2c';for(let y=0;y<s.h;y+=60)ctx.fillRect(950+Math.sin(G.t/30+y)*8,y,20,30);
    ctx.fillStyle='#f0c890';ctx.fillRect(920,500,130,200);ctx.fillStyle='#c9965a';for(let x=925;x<1050;x+=18)ctx.fillRect(x,500,4,200);
    ctx.fillStyle='#fff';ctx.fillRect(920,496,130,8);ctx.fillRect(920,696,130,8);
    s.trees.forEach(t=>{const x=t[0],y=t[1];
      if(t[2]===0){ctx.fillStyle='#fff';ctx.fillRect(x-4,y-34,8,52);ctx.fillStyle='#ff3b5c';for(let k=0;k<5;k++)ctx.fillRect(x-4,y-30+k*11,8,5);ctx.strokeStyle='#ff3b5c';ctx.lineWidth=8;ctx.beginPath();ctx.arc(x+10,y-34,10,Math.PI,Math.PI*2.5);ctx.stroke()}
      else{ctx.fillStyle='#fff';ctx.fillRect(x-3,y-6,6,26);ctx.fillStyle=t[2]===1?'#ff6fb5':'#6fd3ff';ctx.beginPath();ctx.arc(x,y-20,24,0,7);ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(x,y-20,16,0,9);ctx.stroke();ctx.beginPath();ctx.arc(x,y-20,7,0,9);ctx.stroke()}});
    const rb=['#ff4f4f','#ffa14f','#fff04f','#6fe86f','#4fb3ff','#a46fff'];
    if(G.key){glow(1920,600,140,'rgba(255,255,255,A)',.5);ctx.fillStyle='rgba(255,255,255,.6)';ctx.beginPath();ctx.arc(1920,640,40,Math.PI,0);ctx.fill()}
    rb.forEach((c,i)=>{ctx.strokeStyle=c;ctx.lineWidth=8;ctx.beginPath();ctx.arc(1920,640,70-i*8,Math.PI,0);ctx.stroke()});
    label(1920,540,'Rainbow Gate');
    s.pickups.forEach((p,i)=>{if(p.got)return;const bob=Math.sin(G.t/15+i)*3;glow(p.x,p.y,42,'rgba(255,255,160,A)',.6);ctx.fillStyle='#fff';ctx.fillRect(p.x-2,p.y+4,4,18);ctx.fillStyle=rb[i];ctx.beginPath();ctx.arc(p.x,p.y+bob,11,0,7);ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=2.5;ctx.beginPath();ctx.arc(p.x,p.y+bob,7,0,9);ctx.stroke();ctx.beginPath();ctx.arc(p.x,p.y+bob,3,0,9);ctx.stroke()});
    NPC.queen(330,520);label(330,468,'Queen Taffy');
    NPC.gus(870,600);label(870,556,'Gus');
    const gc=['#ff4f9a','#4fd1ff','#8aff4f','#ffd84f'];
    s.ghosts.forEach(g=>{const sq=Math.sin(G.t/10+g.a*3)*2;ctx.fillStyle='rgba(0,0,0,.25)';ctx.beginPath();ctx.ellipse(g.x,g.y+16,16,5,0,0,7);ctx.fill();ctx.fillStyle=gc[g.c%4];ctx.beginPath();ctx.arc(g.x,g.y+10,16+sq,Math.PI,0);ctx.lineTo(g.x+16+sq,g.y+14);ctx.lineTo(g.x-16-sq,g.y+14);ctx.closePath();ctx.fill();ctx.fillStyle='#fff9';ctx.fillRect(g.x-9,g.y-2,5,5);ctx.fillStyle='#222';ctx.fillRect(g.x-7,g.y+3,4,5);ctx.fillRect(g.x+3,g.y+3,4,5)});
  };return s}

function makeMansion(){
  const s={name:'mansion',w:1600,h:1200,spawn:[800,1100],rects:[],circles:[],inter:[],pickups:[],ghosts:[],dark:true,darkR:430,darkA:.88,unlocked:false,chest:false};
  const walls=[[0,780,700,40],[900,780,700,40],[0,380,700,40],[900,380,700,40],[500,820,40,140],[500,1080,40,120],[1060,820,40,140],[1060,1080,40,120]];
  const shelves=[[100,30,260,70],[450,30,180,70],[970,30,180,70],[1240,30,260,70]];
  s.lock=[700,380,200,40];
  s.rects.push(...walls,...shelves,s.lock);
  [[250,520],[250,680],[1350,700],[600,480],[1000,720],[1350,520],[620,880],[980,880]].forEach(c=>s.circles.push([c[0],c[1],22]));
  [[90,880],[1510,880],[1500,500]].forEach(p=>s.pickups.push({x:p[0],y:p[1],got:false}));
  [[250,1010,120,0],[1350,1010,120,2],[400,600,180,0],[1200,600,200,3],[800,600,140,5]].forEach(g=>s.ghosts.push({cx:g[0],cy:g[1],rad:g[2],a:g[3],x:0,y:0}));
  s.inter.push({x:800,y:1000,label:'Talk',act(){
    if(G.keys>=3)return say('Bones the Skeleton',["You found all three! The library door will open for you now. The Moonlight Door is beyond it."]);
    if(!G.f.bStart){G.f.bStart=1;return say('Bones the Skeleton',["Rattle-me-bones, a living child! I am Bones, butler of Midnight Manor.","The Moonlight Door in the library leads home, but the library door is locked with three brass keys.","One is in the kitchen (west), one in the cellar (east), one in the ballroom (north). Ghosts patrol every room, so keep moving!"])}
    say('Bones the Skeleton',["Brass keys found: "+G.keys+" of 3. Kitchen west, cellar east, ballroom north."])}});
  s.inter.push({x:800,y:448,label:'Locked Door',active:()=>!s.unlocked,act(){
    if(G.keys<3)return say('',["The library door has three keyholes.  ("+G.keys+"/3 keys)"]);
    s.unlocked=true;s.rects.splice(s.rects.indexOf(s.lock),1);sfx.token();say('',["Click, click, click! The library door swings open."])}});
  s.inter.push({x:200,y:262,label:'Open chest',active:()=>!s.chest,act(){s.chest=true;G.candy+=10;sfx.pick();say('',['A treasure chest full of candy!  +10 candy'])}});
  s.inter.push({x:800,y:92,label:'Moonlight Door',act(){say('Mia',["The Moonlight Door... I can hear Mom calling my name! Time to go home."],()=>fadeTo(()=>{G.mode='end';G.endT=0}))}});
  s.enter=()=>say('Mia',["The Rainbow Gate drops me in a huge, dark mansion... and the door slams shut behind me!","Floorboards creak. Somewhere, a ghost is humming."]);
  s.update=()=>{
    grab(s,p=>{G.keys++;sfx.token();say('',['★ Brass Key found! ('+G.keys+'/3)'])});
    hazards(s,800,1100,"BOO!! A ghost chased me back to the entrance hall. Deep breath... try again, carefully.",.015)};
  s.draw=()=>{
    ctx.fillStyle='#1c1424';ctx.fillRect(0,0,s.w,s.h);
    ctx.fillStyle='#3a2616';ctx.fillRect(0,0,s.w,380);ctx.fillStyle='#4a301c';for(let x=0;x<s.w;x+=80)ctx.fillRect(x,0,3,380);
    ctx.fillStyle='#6a1b2b';ctx.fillRect(700,0,200,380);
    for(let y=420,r=0;y<780;y+=60,r++)for(let x=0,c=0;x<s.w;x+=60,c++){ctx.fillStyle=(r+c)%2?'#2e2338':'#3b2d48';ctx.fillRect(x,y,60,60)}
    ctx.fillStyle='#2a1f2e';ctx.fillRect(0,820,s.w,380);ctx.fillStyle='#3d4350';ctx.fillRect(0,820,500,380);ctx.fillStyle='#2e2a24';ctx.fillRect(1100,820,500,380);
    ctx.fillStyle='#6a1b2b';ctx.fillRect(740,820,120,380);
    ctx.fillStyle='#4a5160';for(let y=820,r=0;y<1200;y+=50,r++)for(let x=0,c=0;x<500;x+=50,c++)if((r+c)%2)ctx.fillRect(x,y,50,50);
    walls.forEach(w=>{ctx.fillStyle='#5a4566';ctx.fillRect(w[0],w[1],w[2],w[3]);ctx.fillStyle='#6d577a';ctx.fillRect(w[0],w[1],w[2],6);ctx.fillStyle='#3a2a45';ctx.fillRect(w[0],w[1]+w[3]-6,w[2],6)});
    const bc=['#a33','#38a','#3a5','#cb3','#83a'];
    shelves.forEach(sh=>{ctx.fillStyle='#2a160c';ctx.fillRect(sh[0],sh[1],sh[2],sh[3]);for(let x=sh[0]+6,i=0;x<sh[0]+sh[2]-10;x+=14,i++){ctx.fillStyle=bc[i%5];ctx.fillRect(x,sh[1]+8,10,sh[3]-16)}});
    ctx.fillStyle='#1a1a3a';ctx.fillRect(740,0,120,80);glow(800,40,130,'rgba(200,220,255,A)',.5);ctx.fillStyle='#cfe3ff';ctx.beginPath();ctx.arc(800,40,28,0,7);ctx.fill();label(800,108,'Moonlight Door');
    if(!s.unlocked){ctx.fillStyle='#6b3d1e';ctx.fillRect(700,380,200,40);ctx.fillStyle='#c9a227';ctx.fillRect(790,390,20,20);ctx.fillStyle='#000';ctx.fillRect(797,396,6,8);
      for(let i=0;i<3;i++){ctx.fillStyle=i<G.keys?'#ffd24d':'#3a2a45';ctx.beginPath();ctx.arc(750+i*50,370,6,0,7);ctx.fill()}}
    [[40,440],[1560,440],[560,1160],[1040,1160],[40,860],[1560,860],[300,330],[1300,330],[600,740],[1000,440]].forEach((c,i)=>{const f=Math.sin(G.t/6+i*2)*.1;glow(c[0],c[1],90,'rgba(255,170,70,A)',.35+f);ctx.fillStyle='#f4ecd8';ctx.fillRect(c[0]-3,c[1],6,14);ctx.fillStyle='#ffcf5a';ctx.beginPath();ctx.ellipse(c[0],c[1]-4,3,6,0,0,7);ctx.fill()});
    s.circles.forEach(c=>{ctx.fillStyle='#6b5a78';ctx.fillRect(c[0]-14,c[1]-30,28,50);ctx.fillStyle='#8a7898';ctx.fillRect(c[0]-18,c[1]-34,36,8);ctx.fillRect(c[0]-18,c[1]+14,36,8)});
    if(!s.chest){glow(200,262,60,'rgba(255,210,90,A)',.5);ctx.fillStyle='#7a4a22';ctx.fillRect(184,252,32,22);ctx.fillStyle='#c9a227';ctx.fillRect(184,250,32,6);ctx.fillRect(197,256,6,8)}
    else{ctx.fillStyle='#7a4a22';ctx.fillRect(184,258,32,16);ctx.fillStyle='#2a160c';ctx.fillRect(186,246,28,6)}
    s.pickups.forEach((p,i)=>{if(p.got)return;const b=Math.sin(G.t/12+i)*3;glow(p.x,p.y,60,'rgba(255,220,100,A)',.7);ctx.strokeStyle='#ffd24d';ctx.lineWidth=4;ctx.beginPath();ctx.arc(p.x-6,p.y+b,7,0,7);ctx.stroke();ctx.fillStyle='#ffd24d';ctx.fillRect(p.x,p.y-2+b,16,4);ctx.fillRect(p.x+10,p.y+b,3,7);ctx.fillRect(p.x+15,p.y+b,3,5)});
    NPC.skeleton(800,1000);label(800,956,'Bones');
    drawGhosts(s.ghosts);
  };return s}

const SCENE_BG={town:'#1b2b20',forest:'#0d1a12',candy:'#ffd9ee',mansion:'#1c1424',hub:'#2a1740'};
function loadScene(n){G.scene=n;G.mode='play';S=n==='town'?makeTown():n==='forest'?makeForest():n==='candy'?makeCandy():n==='mansion'?makeMansion():makeHub();S.bg=SCENE_BG[n]||'#0b0614';P.x=S.spawn[0];P.y=S.spawn[1];S.enter&&S.enter()}

/* ---------- movement ---------- */
function tryMove(mx,my){const nx=P.x+mx,ny=P.y+my;
  if(nx<P.r||ny<P.r||nx>S.w-P.r||ny>S.h-P.r)return;
  for(const r of S.rects)if(nx+P.r>r[0]&&nx-P.r<r[0]+r[2]&&ny+P.r>r[1]&&ny-P.r<r[1]+r[3])return;
  for(const c of S.circles)if(Math.hypot(nx-c[0],ny-c[1])<c[2]+P.r)return;
  P.x=nx;P.y=ny}
function movePlayer(){
  let dx=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0),dy=(keys.KeyS||keys.ArrowDown?1:0)-(keys.KeyW||keys.ArrowUp?1:0);
  if(dx&&dy){dx*=.7071;dy*=.7071}
  if(!dx&&!dy&&joy.on){dx=joy.x;dy=joy.y}
  const sp=S.name==='forest'?2.7:3.3;if(dx||dy){P.walk+=.28;if(dx)P.face=dx>0?1:-1}
  tryMove(dx*sp,0);tryMove(0,dy*sp)}

/* ---------- update ---------- */
let near=null;
function update(){
  G.t++;
  if(G.fadeDir===1){G.fade+=.025;if(G.fade>=1){G.fade=1;G.fadeDir=-1;const c=G.fadeCb;G.fadeCb=null;c&&c()}}
  else if(G.fadeDir===-1){G.fade-=.025;if(G.fade<=0){G.fade=0;G.fadeDir=0}}
  if(G.mode==='title'){if(isAct()){initAudio();G.candy=0;G.houses=0;G.mush=0;G.teddy=false;G.lolli=0;G.key=false;G.keys=0;G.f={};G.tokens={witch:false,zombie:false,vampire:false};loadScene('town')}return}
  if(G.mode==='end'){G.endT++;if(G.endT>240&&isAct()){G.mode='title'}return}
  if(G.dlg){const d=G.dlg,full=d.lines[d.i].length;
    if(d.shown<full){d.shown+=2.4;if(G.t%3===0&&d.sp)sfx.talk()}
    if(isAct()){if(d.shown<full)d.shown=full;else if(!d.choices){d.i++;d.shown=0;if(d.i>=d.lines.length){G.dlg=null;d.cb&&d.cb()}}}
    if(d.choices&&d.shown>=full){for(let i=0;i<d.choices.length;i++)if(pressed['Digit'+(i+1)]||pressed['Numpad'+(i+1)]){G.dlg=null;d.pick(i);break}}
    pressed={};return}
  if(G.fadeDir===0)movePlayer();
  S.update&&S.update();
  near=null;let best=60;if(G.fadeDir===0)for(const it of S.inter){if(it.active&&!it.active())continue;const d=Math.hypot(P.x-it.x,P.y-it.y);if(d<best){best=d;near=it}}
  if(near&&isAct()&&!G.dlg&&G.fadeDir===0)near.act();
  cam.x=S.w>W?Math.max(0,Math.min(S.w-W,P.x-W/2)):(S.w-W)/2;
  cam.y=S.h>H?Math.max(0,Math.min(S.h-H,P.y-H/2)):(S.h-H)/2;
}

/* ---------- draw ---------- */
function objective(){
  if(G.scene==='town')return G.houses<3?'Trick-or-treat at the 3 houses ('+G.houses+'/3)':'Follow the glowing path east...';
  if(G.scene==='forest')return 'Find a way out of the woods... follow the orange glow';
  if(G.scene==='candy')return G.key?'Go to the Rainbow Gate (east)!':G.lolli>=5?'Take the lollipops to Queen Taffy':G.f.qStart?'Find 5 Rainbow Lollipops ('+G.lolli+'/5)':'Talk to Queen Taffy (west)';
  if(G.scene==='mansion')return G.keys<3?'Find 3 brass keys ('+G.keys+'/3)':(S&&S.unlocked?'Reach the Moonlight Door (north)':'Unlock the library door (north)');
  if(Object.values(G.tokens).every(Boolean))return 'Go to the Moon Gate (north)!';
  return 'Earn 3 Spooky Tokens: Witch, Zombie, Vampire';}
function shrinkFont(text,maxW,start,minPx,bold){let fs=start;const set=()=>{ctx.font=(bold?'bold ':'')+fs+'px Georgia'};set();
  while(ctx.measureText(text).width>maxW&&fs>minPx){fs--;set()}return fs}
function drawHUD(){
  let extra='';
  if(G.scene==='hub')extra='Mushrooms '+G.mush+'/5   Teddy '+(G.teddy?'✔':'–');
  if(G.scene==='candy')extra='Lollipops '+G.lolli+'/5   Candy Key '+(G.key?'✔':'–');
  if(G.scene==='mansion')extra='Brass keys '+G.keys+'/3';
  const bw=Math.min(W-20,346), bh=extra?100:76;
  ctx.fillStyle='#000a';ctx.fillRect(10,10,bw,bh);ctx.strokeStyle='#ff9a2e';ctx.lineWidth=2;ctx.strokeRect(10,10,bw,bh);
  ctx.textAlign='left';ctx.font='bold 15px Georgia';ctx.fillStyle='#ffcf5a';
  const candyTxt='🍬 Candy: '+G.candy;ctx.fillText(candyTxt,22,34);
  const dotsX=Math.min(bw-52,26+ctx.measureText(candyTxt).width+22);
  [['#b46bff',G.tokens.witch],['#7bd06a',G.tokens.zombie],['#ff4466',G.tokens.vampire]].forEach((t,i)=>{ctx.fillStyle=t[1]?t[0]:'#3a3050';ctx.beginPath();ctx.arc(dotsX+i*26,29,10,0,7);ctx.fill();ctx.strokeStyle='#fff6';ctx.lineWidth=1;ctx.stroke()});
  const obj=objective();shrinkFont(obj,bw-24,13,9,false);ctx.fillStyle='#f0e6ff';ctx.fillText(obj,22,62);
  if(extra){ctx.font='12px Georgia';ctx.fillStyle='#e8f5d8';ctx.fillText(extra,22,86)}
}
function drawTouch(){
  if(!touchMode||G.mode!=='play'||G.dlg)return;
  ctx.save();
  const jx=joy.on?joy.ox:Math.min(W*.3,120),jy=joy.on?joy.oy:H-24-JOY_R;
  ctx.globalAlpha=joy.on?.4:.18;ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(jx,jy,JOY_R,0,7);ctx.fill();
  ctx.globalAlpha=.95;ctx.fillStyle='#ffcf5a';ctx.beginPath();ctx.arc(jx+joy.x*JOY_R,jy+joy.y*JOY_R,JOY_R*.42,0,7);ctx.fill();
  const a=actPos(),hot=!!near;
  ctx.globalAlpha=hot?.92:.26;ctx.fillStyle='#ff9a2e';ctx.beginPath();ctx.arc(a[0],a[1],ACT_R,0,7);ctx.fill();
  ctx.globalAlpha=1;ctx.fillStyle=hot?'#120a1f':'#2a1830';ctx.textAlign='center';
  const lt=hot?near.label:'TAP';
  const fs=Math.max(11,Math.min(17,Math.round(ACT_R*2/(lt.length*0.62))));
  ctx.font='bold '+fs+'px Georgia';ctx.fillText(lt,a[0],a[1]+fs*.36);
  ctx.restore()}
let _dmKey='',_dm=null;
function dlgMetrics(){
  const d=G.dlg;if(!d)return null;
  const raw=d.lines[d.i]||'';
  const key=W+'x'+H+'|'+d.i+'|'+raw.length+'|'+(d.choices?d.choices.length:0);
  if(_dmKey===key&&_dm)return _dm;
  const bx=Math.max(8,Math.round(W*.035)),bw=W-bx*2;
  let fs=Math.max(13,Math.min(19,Math.round(W/26))),lh=0,nLines=1,ch=0,bh=0;
  for(let guard=0;guard<14;guard++){
    lh=Math.round(fs*1.45);ctx.font=fs+'px Georgia';
    nLines=Math.max(1,wrap(raw,bw-34).length);
    ch=Math.max(34,Math.min(50,Math.round(fs*2.3)));
    bh=26+nLines*lh+(d.choices?ch+18:10);
    if(bh<=H*.66||fs<=11)break;
    fs--;
  }
  bh=Math.min(Math.round(H*.66),bh);
  const by=H-bh-Math.max(10,Math.round(H*.02));
  _dmKey=key;_dm={bx,by,bw,bh,fs,lh,ch,nLines};
  return _dm;
}
function drawDialog(){
  const d=G.dlg;if(!d)return;const m=dlgMetrics();if(!m)return;
  const{bx,by,bw,bh,fs,lh}=m;
  ctx.fillStyle='#120a1ff2';ctx.fillRect(bx,by,bw,bh);
  ctx.strokeStyle='#ff9a2e';ctx.lineWidth=3;ctx.strokeRect(bx,by,bw,bh);
  const lfs=Math.max(11,Math.round(fs*.9));
  if(d.sp){ctx.font='bold '+lfs+'px Georgia';const w=ctx.measureText(d.sp).width+28;
    ctx.fillStyle='#ff9a2e';ctx.fillRect(bx+14,by-lfs-10,w,lfs+14);
    ctx.fillStyle='#120a1f';ctx.textAlign='left';ctx.fillText(d.sp,bx+28,by-6)}
  ctx.font=fs+'px Georgia';ctx.textAlign='left';ctx.fillStyle='#fff3e0';
  const maxLines=Math.max(1,Math.floor((bh-26-(d.choices?m.ch+18:10))/lh));
  wrap(d.lines[d.i].slice(0,Math.floor(d.shown)),bw-34).slice(0,maxLines).forEach((l,i)=>ctx.fillText(l,bx+17,by+18+lh+i*lh));
  if(d.choices&&d.shown>=d.lines[d.i].length){
    d.choices.forEach((c,i)=>{const r=choiceRect(i,d.choices.length);
      ctx.fillStyle='#2a1840';ctx.fillRect(r[0],r[1],r[2],r[3]);
      ctx.strokeStyle='#ffcf5a';ctx.lineWidth=2;ctx.strokeRect(r[0],r[1],r[2],r[3]);
      ctx.fillStyle='#ffcf5a';ctx.textAlign='center';
      const cfs=Math.max(10,Math.min(16,Math.round(r[2]/(Math.max(6,c.length)*.58))));
      ctx.font='bold '+cfs+'px Georgia';ctx.fillText(c,r[0]+r[2]/2,r[1]+r[3]/2+cfs*.36)});
    ctx.textAlign='left'}
  else if(d.shown>=d.lines[d.i].length){ctx.font=fs+'px Georgia';ctx.fillStyle='#ff9a2e';ctx.fillText(Math.floor(G.t/20)%2?'▼':'',bx+bw-30,by+bh-12)}
}
function draw(){
  ctx.clearRect(0,0,W,H);
  if(S&&(G.mode==='play'||G.mode==='end')){ctx.fillStyle=S.bg||'#0b0614';ctx.fillRect(0,0,W,H)}
  if(G.mode==='title'){
    const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#0b0420');g.addColorStop(1,'#3a1450');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
    for(let i=0;i<90;i++){ctx.fillStyle='rgba(255,255,255,'+(.3+.5*Math.abs(Math.sin(G.t/40+i)))+')';ctx.fillRect((i*137)%W,(i*71)%Math.max(40,H*.6),2,2)}
    const mx=W*.74,my=H*.15,mr=Math.max(28,Math.min(W,H)*.13);
    glow(mx,my,mr*2.4,'rgba(255,230,160,A)',.6);ctx.fillStyle='#ffe9a8';ctx.beginPath();ctx.arc(mx,my,mr,0,7);ctx.fill();
    ctx.fillStyle='#f1d58a';ctx.beginPath();ctx.arc(mx-mr*.32,my-mr*.3,mr*.17,0,7);ctx.arc(mx+mr*.34,my+mr*.3,mr*.13,0,7);ctx.fill();
    const hy=H*.74,hillH=Math.min(H*.15,90);
    ctx.fillStyle='#07030d';for(let i=0;i<10;i++)tri(i*W/9,hy,i*W/18+i*W/9,hy-hillH*(1+(i%3)*.3),i*W/9+W/9*2,hy);
    ctx.fillRect(0,hy,W,H-hy);
    pumpkin(W*.13,hy+H*.03,Math.max(1,Math.min(2.2,W/260)));
    pumpkin(W*.87,hy+H*.03,Math.max(1,Math.min(2.2,W/260)));
    drawGirl(W*.5,hy-H*.015,1,G.t/6);
    ctx.textAlign='center';
    const tf=Math.max(24,Math.min(72,Math.round(W/7.6)));
    const ty=Math.max(tf*1.6,H*.32);
    ctx.font='bold '+tf+'px Georgia';
    ctx.fillStyle='#2a0a00';ctx.fillText('TRICK OR TREAT',W/2+4,ty+4);
    ctx.fillStyle='#ff9a2e';ctx.fillText('TRICK OR TREAT',W/2,ty);
    const sf=Math.max(12,Math.min(20,Math.round(W/26)));ctx.font='italic '+sf+'px Georgia';ctx.fillStyle='#e8d6ff';
    let yy=ty+sf*2;
    wrap('Lost in the woods. Awake in a world of witches, zombies and vampires.',W-56).forEach(l=>{ctx.fillText(l,W/2,yy);yy+=sf*1.35});
    yy+=sf*.7;
    const pf=Math.max(14,Math.min(23,Math.round(W/21)));ctx.font='bold '+pf+'px Georgia';
    ctx.fillStyle=Math.floor(G.t/30)%2?'#fff':'#ffcf5a';ctx.fillText(touchMode?'Tap to start':'Press ENTER or click to start',W/2,yy+pf);
    yy+=pf*1.85;
    const inf=Math.max(11,Math.min(15,Math.round(W/32)));ctx.font=inf+'px Georgia';ctx.fillStyle='#bfa9e0';
    wrap(touchMode?'Move: drag anywhere with your thumb   •   Act & continue: tap the big orange button or the text box   •   Choices: tap them':'Move: WASD / arrow keys   •   Talk & continue: E / Space / Enter   •   Choices: 1, 2, 3',W-48).forEach(l=>{ctx.fillText(l,W/2,yy);yy+=inf*1.5});
    ctx.font=Math.max(9,Math.min(13,Math.round(W/46)))+'px Georgia';ctx.fillStyle='#9a86bd';
    ctx.fillText('© 2026 Johanna Maria Honkanen. All rights reserved.',W/2,H-24);
    ctx.font=Math.max(8,Math.min(11,Math.round(W/58)))+'px Georgia';
    ctx.fillText('Unauthorized copying, distribution or modification of this game is prohibited.',W/2,H-8);
    return}
  if(G.mode==='end'){
    const t=G.endT;ctx.fillStyle='#0f1b2e';ctx.fillRect(0,0,W,H);
    glow(W/2,H*.3,Math.max(W,H)*.55,'rgba(255,200,140,A)',Math.min(.5,t/200));
    ctx.fillStyle='#e8c89a';ctx.beginPath();ctx.arc(W/2,H*.24,Math.max(34,Math.min(70,W*.13)),0,7);ctx.fill();
    const gy=H*.72;ctx.fillStyle='#17301f';ctx.fillRect(0,gy,W,H-gy);
    drawGirl(W/2,gy-W*.02,1,0);
    pumpkin(W/2-W*.13,gy+H*.03,Math.max(1,Math.min(1.8,W/320)));
    pumpkin(W/2+W*.13,gy+H*.03,Math.max(1,Math.min(1.8,W/320)));
    ctx.textAlign='center';ctx.fillStyle='#fff3e0';
    const tf=Math.max(22,Math.min(40,Math.round(W/12)));ctx.font='bold '+tf+'px Georgia';ctx.fillText('THE END',W/2,H*.1);
    const fs=Math.max(12,Math.min(19,Math.round(W/26)));ctx.font=fs+'px Georgia';
    const txt=["Mia blinks awake on the leaves at the edge of the woods.","In the distance, Mom is calling her name. The glowing path is gone.","Her candy bucket is still in her hand — "+G.candy+" pieces left.","...And something small and black purrs somewhere in the dark. Happy Halloween!"];
    let yy=H*.1+tf*1.7;
    txt.forEach((l,i)=>{ctx.globalAlpha=Math.max(0,Math.min(1,(t-30-i*45)/40));
      wrap(l,W-56).forEach(w2=>{ctx.fillText(w2,W/2,yy);yy+=fs*1.4});ctx.globalAlpha=1});
    if(t>240){ctx.fillStyle=Math.floor(G.t/30)%2?'#fff':'#ffcf5a';ctx.font='bold '+Math.max(14,Math.min(20,Math.round(W/24)))+'px Georgia';ctx.fillText(touchMode?'Tap to play again':'Press ENTER to play again',W/2,H-26)}
    return}
  ctx.save();ctx.translate(-cam.x,-cam.y);S.draw();
  if(near&&!G.dlg){ctx.font='bold 14px Georgia';ctx.textAlign='center';const lt=(touchMode?'TAP ▶ ':'[E] ')+near.label,lw=Math.max(120,ctx.measureText(lt).width+20);ctx.fillStyle='#000a';ctx.fillRect(near.x-lw/2,near.y-60,lw,24);ctx.fillStyle='#ffcf5a';ctx.fillText(lt,near.x,near.y-43)}
  drawGirl(P.x,P.y,P.face,P.walk);
  ctx.restore();
  if(S.dark){const sx=P.x-cam.x,sy=P.y-cam.y,g=ctx.createRadialGradient(sx,sy,40,sx,sy,S.darkR||330);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,6,'+(S.darkA||.93)+')');ctx.fillStyle=g;ctx.fillRect(0,0,W,H)}
  if(G.scene==='hub'){ctx.fillStyle='rgba(60,20,110,.12)';ctx.fillRect(0,0,W,H)}
  drawHUD();drawTouch();drawDialog();
  if(G.fade>0){ctx.fillStyle='rgba(0,0,0,'+G.fade+')';ctx.fillRect(0,0,W,H)}
}
let _acc=0,_lastT=0;
function loop(now){
  now=now||performance.now();const dt=_lastT?Math.min(100,now-_lastT):16.7;_lastT=now;
  if(innerWidth!==_vw||innerHeight!==_vh)fit();
  /* fixed 60Hz steps so 90/120Hz phone screens don't speed the game up */
  _acc+=dt;let steps=0;
  while(_acc>=16.7&&steps<4){update();pressed={};_acc-=16.7;steps++}
  if(steps===4)_acc=0;
  draw();requestAnimationFrame(loop)}
loop();
