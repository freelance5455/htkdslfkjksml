/* Trick Or Treat — mobile shell helpers (fullscreen + orientation lock) */
(function () {
  const docEl = document.documentElement;
  const btn = document.getElementById('fs');
  if (!btn) return;

  const coarse = !!(window.matchMedia && matchMedia('(pointer:coarse)').matches);
  const request = docEl.requestFullscreen || docEl.webkitRequestFullscreen;
  if (!coarse || !request) { btn.style.display = 'none'; return; }

  btn.style.display = 'block';

  async function enter() {
    try {
      if (docEl.requestFullscreen) await docEl.requestFullscreen({ navigationUI: 'hide' });
      else docEl.webkitRequestFullscreen();
    } catch (e) { return; }
    try {
      if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape');
    } catch (e) { /* orientation lock is best-effort (not on iOS) */ }
    btn.style.display = 'none';
  }

  btn.addEventListener('pointerup', (e) => { e.preventDefault(); e.stopPropagation(); enter(); });
  btn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); });

  // Tapping the game after a rotation glitch: keep the canvas filling the screen.
  const refit = () => { window.dispatchEvent(new Event('resize')); };
  window.addEventListener('orientationchange', () => setTimeout(refit, 250));
  if (window.visualViewport) window.visualViewport.addEventListener('resize', refit);

  // Fullscreen left -> show the button again.
  document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement) btn.style.display = 'block'; });
})();
