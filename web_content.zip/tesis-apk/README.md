# Tesis Yönetim Sistemi → APK

Bu klasör, HTML uygulamanızı Android APK olarak derlemek için hazır WebView projesidir.

## Ne yapıldı?

- `index.html` uygulamaya **gömüldü** (`assets/index.html`)
- İnternet / site açılmaz → `file:///android_asset/index.html`
- JavaScript + localStorage açık
- Fotoğraf seçici (kamera/galeri) desteklenir
- Geri tuşu WebView geçmişinde çalışır

## Android Studio ile APK alma

1. [Android Studio](https://developer.android.com/studio) kurun
2. **File → New → New Project → Empty Views Activity**
   - Name: `Tesis Yonetim`
   - Package: `com.tesis.yonetim`
   - Language: **Java**
   - Minimum SDK: **24**
3. Oluşan projede şu dosyaları bu paketten kopyalayın:
   - `app/src/main/assets/index.html` → aynı yola (assets klasörü yoksa oluşturun)
   - `MainActivity.java` → `app/src/main/java/com/tesis/yonetim/`
   - `activity_main.xml` → `app/src/main/res/layout/`
   - `AndroidManifest.xml` → `app/src/main/` (mevcut ile birleştirin / değiştirin)
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK yolu genelde: `app/build/outputs/apk/debug/app-debug.apk`

## Giriş bilgileri

| Rol | Kullanıcı | Şifre |
|-----|-----------|-------|
| Ustabaşı | `ustabaşı261933` | `ustabaşı261933` |
| İşçi | Ustanın eklediği ad | Otomatik üretilen şifre |

## Notlar

- Veriler telefonda `localStorage` içinde saklanır (cihazda kalır)
- Uygulamayı silerseniz işçi/izin verileri silinir
- Farklı telefonlarda veri paylaşılmaz (sunucu yoktur)
