My Study Verse
1. Host this folder (GitHub Pages / Netlify / any web server) or run: python3 -m http.server
2. Open on phone in Chrome > menu > "Add to Home screen" (installs like an app).
3. Google login: paste your Google OAuth Web Client ID in index.html (const GID).
