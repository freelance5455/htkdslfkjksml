# Viridian launcher

A console-style Android home screen by xdtimeLULZ. The interface is a web page (app/src/main/assets/index.html)
shown full-screen in a WebView. Kotlin code lets it list, open, hide, rename and re-icon your real apps.

## Build it
1. Install Android Studio (latest stable) and open this folder (File > Open).
2. Let Gradle sync. This needs internet the first time: it downloads the Android libraries and also saves
   three.min.js and the Open Sans fonts into app/src/main/assets/lib so the launcher works offline afterwards.
   If Studio says the Gradle wrapper is missing, accept its offer to use or create one (Gradle 8.7).
3. Build > Build Bundle(s) / APK(s) > Build APK(s). The debug APK appears under app/build/outputs/apk/debug/.
   Or plug in your device and press Run.
4. Install the APK (allow "install unknown apps" if asked).
5. Press Home. Android asks which home app to use: pick Viridian and choose Always.
   Later you can change it in Settings > Apps > Default apps > Home app, or from Viridian's System > Default home app.

## What works
- Apps: every app with a launcher icon, sorted by name. Select to open.
- Long-press an app (or press Y / Start on a controller, or M / Menu on a keyboard) for: Hide, Rename, Change icon,
  Reset name and icon, App info and uninstall.
- System > Show hidden apps shows hidden apps dimmed so you can unhide them.
- Memory opens your Files app (Samsung My Files, Google Files, or the system file browser).
- Settings opens Android Settings, plus shortcuts to Display, Sound, Network, Bluetooth and Date and time.
- System: replay the startup, test sounds, set the default home app, About.
- Controls: touch, swipe left/right between sections, keyboard arrows + Enter, controller d-pad or sticks + A,
  B or Back goes back, Home returns to the top of the menu.

## Where things live
- app/src/main/assets/index.html: the whole interface (startup, menus, sounds).
- app/src/main/java/.../LauncherBridge.kt: app list, launching, hidden apps, names, icons, Settings and Files.
- app/src/main/java/.../MainActivity.kt: the WebView, back button, Home button, picture picker.
- Hidden apps, custom names and custom icons are saved on the device only.

## Not included yet
Widgets, notifications badges, app shortcuts, folders and work-profile apps are not handled.
