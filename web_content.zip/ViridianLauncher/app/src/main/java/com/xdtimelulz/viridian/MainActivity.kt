package com.xdtimelulz.viridian

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private lateinit var bridge: LauncherBridge
    private var pendingIconId: String? = null

    // Lets the user pick a picture to use as an app's icon.
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val id = pendingIconId
        pendingIconId = null
        if (uri != null && id != null) {
            bridge.saveIcon(id, uri)
            notifyAppsChanged()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bridge = LauncherBridge(this)

        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            isHapticFeedbackEnabled = false
            setOnLongClickListener { true }
        }

        // Serves the bundled page and app icons from a private https address.
        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/icon/", bridge.iconHandler)
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? = request?.url?.let { loader.shouldInterceptRequest(it) }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false // lets the startup jingle play by itself
            allowFileAccess = false
            allowContentAccess = false
        }
        web.addJavascriptInterface(bridge, "Viridian")

        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                js("window.onNativeBack&&window.onNativeBack()")
            }
        })
    }

    fun requestIcon(id: String) {
        pendingIconId = id
        pickImage.launch("image/*")
    }

    fun notifyAppsChanged() = js("window.onAppsChanged&&window.onAppsChanged()")

    private fun js(code: String) {
        web.post { web.evaluateJavascript(code, null) }
    }

    // Pressing Home while Viridian is already open sends you back to the top of the menu.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) js("window.onHome&&window.onHome()")
    }

    override fun onStart() {
        super.onStart()
        bridge.startWatching()
    }

    override fun onStop() {
        bridge.stopWatching()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        notifyAppsChanged()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
