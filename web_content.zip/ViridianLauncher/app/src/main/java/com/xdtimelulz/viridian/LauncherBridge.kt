package com.xdtimelulz.viridian

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Process
import android.os.UserHandle
import android.provider.Settings
import android.util.LruCache
import android.webkit.JavascriptInterface
import android.webkit.WebResourceResponse
import android.widget.Toast
import androidx.core.graphics.drawable.toBitmap
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Everything the web page can ask Android to do. The page calls these through `window.Viridian`.
 * App ids look like "com.example.app:com.example.app.MainActivity".
 */
class LauncherBridge(private val act: MainActivity) {

    private val ctx: Context = act.applicationContext
    private val launcherApps = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val me: UserHandle = Process.myUserHandle()
    private val prefs = ctx.getSharedPreferences("viridian", Context.MODE_PRIVATE)
    private val iconDir = File(ctx.filesDir, "icons").apply { mkdirs() }
    private val cache = LruCache<String, ByteArray>(300)

    private fun obj(key: String) = JSONObject(prefs.getString(key, "{}") ?: "{}")
    private fun save(key: String, o: JSONObject) = prefs.edit().putString(key, o.toString()).apply()
    private fun comp(id: String): ComponentName {
        val k = id.indexOf(':')
        return ComponentName(id.substring(0, k), id.substring(k + 1))
    }
    private fun iconFile(id: String) = File(iconDir, Integer.toHexString(id.hashCode()) + ".png")
    private fun toast(msg: String) = act.runOnUiThread { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }

    private fun tryStart(i: Intent, silent: Boolean = false): Boolean = try {
        act.startActivity(i)
        true
    } catch (e: Exception) {
        if (!silent) toast("Couldn't open that")
        false
    }

    // ---- app list -------------------------------------------------------------------------

    @JavascriptInterface
    fun getApps(): String {
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val labels = obj("labels")
        val icons = obj("icons")
        val arr = JSONArray()
        for (info in launcherApps.getActivityList(null, me)) {
            val pkg = info.componentName.packageName
            if (pkg == ctx.packageName) continue
            val id = pkg + ":" + info.componentName.className
            val original = info.label.toString()
            arr.put(
                JSONObject()
                    .put("id", id)
                    .put("pkg", pkg)
                    .put("label", labels.optString(id, original))
                    .put("orig", original)
                    .put("hidden", hidden.contains(id))
                    .put("iconV", icons.optString(id, "0"))
            )
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun launch(id: String) {
        act.runOnUiThread {
            try {
                launcherApps.startMainActivity(comp(id), me, null, null)
            } catch (e: Exception) {
                toast("Couldn't open that app")
            }
        }
    }

    // ---- hide / rename / icon -------------------------------------------------------------

    @JavascriptInterface
    fun setHidden(id: String, hidden: Boolean) {
        val set = HashSet(prefs.getStringSet("hidden", emptySet()) ?: emptySet())
        if (hidden) set.add(id) else set.remove(id)
        prefs.edit().putStringSet("hidden", set).apply()
    }

    @JavascriptInterface
    fun setLabel(id: String, label: String) {
        val o = obj("labels")
        if (label.isBlank()) o.remove(id) else o.put(id, label.trim())
        save("labels", o)
    }

    @JavascriptInterface
    fun pickIcon(id: String) {
        act.runOnUiThread { act.requestIcon(id) }
    }

    @JavascriptInterface
    fun resetIcon(id: String) {
        iconFile(id).delete()
        val o = obj("icons")
        o.remove(id)
        save("icons", o)
        cache.evictAll()
    }

    /** Called by the activity after the user picks a picture. Crops it square and stores it. */
    fun saveIcon(id: String, uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return
            val side = minOf(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(square, 256, 256, true)
            iconFile(id).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val o = obj("icons")
            o.put(id, System.currentTimeMillis().toString())
            save("icons", o)
            cache.evictAll()
        } catch (e: Exception) {
            toast("Couldn't use that image")
        }
    }

    // ---- icons for the page (https://appassets.androidplatform.net/icon/<id>) -------------

    val iconHandler = WebViewAssetLoader.PathHandler { path ->
        val bytes = iconBytes(path)
        if (bytes == null) null else WebResourceResponse("image/png", null, ByteArrayInputStream(bytes))
    }

    private fun iconBytes(id: String): ByteArray? {
        cache.get(id)?.let { return it }
        val f = iconFile(id)
        val bytes: ByteArray? = if (f.exists()) {
            f.readBytes()
        } else {
            try {
                val k = id.indexOf(':')
                val pkg = id.substring(0, k)
                val cls = id.substring(k + 1)
                launcherApps.getActivityList(pkg, me)
                    .firstOrNull { it.componentName.className == cls }
                    ?.getBadgedIcon(0)
                    ?.toBitmap(160, 160)
                    ?.let { bmp ->
                        val out = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                        out.toByteArray()
                    }
            } catch (e: Exception) {
                null
            }
        }
        if (bytes != null) cache.put(id, bytes)
        return bytes
    }

    // ---- other apps and system screens ----------------------------------------------------

    @JavascriptInterface
    fun openSettings(kind: String) {
        val action = when (kind) {
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bt" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "home" -> Settings.ACTION_HOME_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        act.runOnUiThread { tryStart(Intent(action)) }
    }

    @JavascriptInterface
    fun openFiles() {
        act.runOnUiThread {
            val candidates = listOf(
                "com.sec.android.app.myfiles",
                "com.google.android.apps.nbu.files",
                "com.google.android.documentsui",
                "com.android.documentsui"
            )
            for (p in candidates) {
                val i = ctx.packageManager.getLaunchIntentForPackage(p)
                if (i != null && tryStart(i, silent = true)) return@runOnUiThread
            }
            val view = Intent(Intent.ACTION_VIEW).setDataAndType(
                Uri.parse("content://com.android.externalstorage.documents/root/primary"),
                "vnd.android.document/root"
            )
            if (tryStart(view, silent = true)) return@runOnUiThread
            tryStart(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE))
        }
    }

    @JavascriptInterface
    fun appInfo(id: String) {
        val uri = Uri.parse("package:" + comp(id).packageName)
        act.runOnUiThread { tryStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)) }
    }

    // ---- keep the list fresh when apps are installed or removed ---------------------------

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) = changed()
        override fun onPackageAdded(packageName: String?, user: UserHandle?) = changed()
        override fun onPackageChanged(packageName: String?, user: UserHandle?) = changed()
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = changed()
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = changed()
    }

    private fun changed() {
        cache.evictAll()
        act.notifyAppsChanged()
    }

    fun startWatching() = launcherApps.registerCallback(callback)
    fun stopWatching() = launcherApps.unregisterCallback(callback)
}
