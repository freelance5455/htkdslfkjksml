plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xdtimelulz.viridian"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.xdtimelulz.viridian"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.webkit:webkit:1.11.0")
}

// Downloads the 3D library and fonts once, so the launcher works fully offline afterwards.
val fetchWebLibs by tasks.registering {
    val dir = file("src/main/assets/lib")
    doLast {
        val files = mapOf(
            "three.min.js" to "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js",
            "open-sans-300.woff2" to "https://cdn.jsdelivr.net/fontsource/fonts/open-sans@latest/latin-300-normal.woff2",
            "open-sans-400.woff2" to "https://cdn.jsdelivr.net/fontsource/fonts/open-sans@latest/latin-400-normal.woff2",
            "open-sans-600.woff2" to "https://cdn.jsdelivr.net/fontsource/fonts/open-sans@latest/latin-600-normal.woff2"
        )
        dir.mkdirs()
        files.forEach { (name, url) ->
            val f = File(dir, name)
            if (!f.exists() || f.length() == 0L) {
                try {
                    java.net.URL(url).openStream().use { input ->
                        f.outputStream().use { out -> input.copyTo(out) }
                    }
                } catch (e: Exception) {
                    logger.warn("Could not download $name: ${e.message} (the app will fall back to online copies)")
                    f.delete()
                }
            }
        }
    }
}
tasks.matching { it.name == "preBuild" || (it.name.startsWith("merge") && it.name.endsWith("Assets")) }
    .configureEach { dependsOn(fetchWebLibs) }
