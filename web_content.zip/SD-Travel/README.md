# تطبيق SD Travel لحجوزات العمرة

هذا الملف يحتوي على الكود المصدري الكامل لتطبيق **SD Travel** المصمم للعمل كتطبيق موبايل (Android / iOS) أو تطبيق ويب تقدمي (PWA).

## محتويات المشروع
- `index.html`: الواجهة الرئيسية وكافة الشاشات (الشاشة الرئيسية، حجز جديد، صفحة الحجوزات، البحث، التقارير).
- `style.css`: تصميم متجاوب مع شاشات الموبايل باللغة العربية (RTL).
- `app.js`: منطق الحساب التلقائي للمتبقي، الكاميرا والمعرض، البحث، التقارير، وتصدير البيانات.
- `manifest.json` و `capacitor.config.json`: ملفات التهيئة لتحويل المشروع إلى APK عبر Capacitor أو PWABuilder.

## طريقة التحويل إلى تطبيق موبايل APK بسهولة
1. **الطريقة السريعة (بدون برمجة):** ارفع الملفات على استضافة مجانية (مثل Netlify أو GitHub Pages) ثم أدخل الرابط في موقع **PWABuilder.com** لتحميل ملف APK جاهز للتثبيت على الأندرويد.
2. **باستخدام Capacitor:**
   - أنشئ مجلد مشروع وضع هذه الملفات داخل مجلد `www`.
   - نفذ الأوامر:
     ```bash
     npm init -y
     npm install @capacitor/core @capacitor/cli @capacitor/android
     npx cap add android
     npx cap copy
     npx cap open android
     ```
   - ثم استخرج ملف APK من برنامج Android Studio.
