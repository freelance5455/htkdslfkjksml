let bookings = JSON.parse(localStorage.getItem('sd_travel_bookings') || '[]');
let currentImages = [];

function saveToStorage() {
  localStorage.setItem('sd_travel_bookings', JSON.stringify(bookings));
  updateHomeStats();
}

function updateHomeStats() {
  document.getElementById('statTotalBookings').textContent = bookings.length;
  const totalRem = bookings.reduce((sum, b) => sum + (parseFloat(b.remainingAmount) || 0), 0);
  document.getElementById('statTotalRemaining').textContent = totalRem.toLocaleString();
}

function navigateTo(screenId) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + screenId).classList.add('active');

  const backBtn = document.getElementById('backBtn');
  if (screenId === 'home') {
    backBtn.classList.add('hidden');
    updateHomeStats();
  } else {
    backBtn.classList.remove('hidden');
  }

  if (screenId === 'new-booking' && !document.getElementById('editId').value) {
    resetForm();
  }
  if (screenId === 'bookings-list') {
    renderBookings(bookings, 'bookingsContainer');
  }
  if (screenId === 'search') {
    performSearch();
  }
  if (screenId === 'reports') {
    renderReports();
  }
}

function calculateRemaining() {
  const total = parseFloat(document.getElementById('totalAmount').value) || 0;
  const deposit = parseFloat(document.getElementById('depositAmount').value) || 0;
  const remaining = total - deposit;
  document.getElementById('remainingAmount').value = remaining >= 0 ? remaining : 0;
}

function compressImage(file, maxWidth = 900, quality = 0.7) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

async function handleFiles(files) {
  for (let file of files) {
    if (!file.type.startsWith('image/')) continue;
    const compressedDataUrl = await compressImage(file);
    currentImages.push(compressedDataUrl);
  }
  renderImagePreviews();
}

function renderImagePreviews() {
  const grid = document.getElementById('imagePreviewGrid');
  grid.innerHTML = '';
  currentImages.forEach((src, index) => {
    const div = document.createElement('div');
    div.className = 'preview-item';
    div.innerHTML = `
      <img src="${src}" onclick="openModal('${src}')" />
      <button type="button" class="remove-img-btn" onclick="removeImage(${index})">×</button>
    `;
    grid.appendChild(div);
  });
}

function removeImage(index) {
  currentImages.splice(index, 1);
  renderImagePreviews();
}

function resetForm() {
  document.getElementById('bookingForm').reset();
  document.getElementById('editId').value = '';
  document.getElementById('formTitle').textContent = 'تسجيل حجز جديد';
  document.getElementById('remainingAmount').value = 0;
  currentImages = [];
  renderImagePreviews();
}

document.getElementById('bookingForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const editId = document.getElementById('editId').value;
  const bookingData = {
    id: editId ? editId : Date.now().toString(),
    clientCode: document.getElementById('clientCode').value.trim(),
    clientName: document.getElementById('clientName').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    whatsapp: document.getElementById('whatsapp').value.trim(),
    adultCount: parseInt(document.getElementById('adultCount').value) || 1,
    companions: document.getElementById('companions').value.trim(),
    childrenCount: parseInt(document.getElementById('childrenCount').value) || 0,
    infantsCount: parseInt(document.getElementById('infantsCount').value) || 0,
    tripDate: document.getElementById('tripDate').value,
    totalAmount: parseFloat(document.getElementById('totalAmount').value) || 0,
    depositAmount: parseFloat(document.getElementById('depositAmount').value) || 0,
    remainingAmount: parseFloat(document.getElementById('remainingAmount').value) || 0,
    salesRep: document.getElementById('salesRep').value,
    images: [...currentImages],
    createdAt: new Date().toISOString()
  };

  if (editId) {
    const idx = bookings.findIndex(b => b.id === editId);
    if (idx !== -1) bookings[idx] = bookingData;
  } else {
    bookings.unshift(bookingData);
  }

  try {
    saveToStorage();
    alert('تم حفظ بيانات الحجز بنجاح ✅');
    resetForm();
    navigateTo('bookings-list');
  } catch (err) {
    alert('تنبيه: مساحة التخزين ممتلئة بسبب كثرة الصور. يرجى تقليل عدد الصور أو تصدير نسخة احتياطية.');
  }
});

function renderBookings(list, containerId) {
  const container = document.getElementById(containerId);
  if (!list.length) {
    container.innerHTML = '<p style="text-align:center;color:#64748b;padding:20px;">لا توجد حجوزات مسجلة حالياً.</p>';
    return;
  }

  container.innerHTML = list.map(b => {
    const thumbsHtml = (b.images || []).map(img => `<img src="${img}" onclick="openModal('${img}')" />`).join('');
    const waNumber = b.whatsapp.replace(/^0/, '20');
    return `
      <div class="booking-card">
        <div class="booking-card-header">
          <span class="code-badge">كود: ${b.clientCode}</span>
          <span class="rep-badge">مسؤول: ${b.salesRep}</span>
        </div>
        <div class="booking-details">
          <p><strong>العميل:</strong> ${b.clientName}</p>
          <p><strong>الهاتف:</strong> ${b.phone} | <strong>واتساب:</strong> ${b.whatsapp}</p>
          <p><strong>تاريخ الرحلة:</strong> ${b.tripDate}</p>
          <p><strong>الأفراد:</strong> ${b.adultCount} بالغ | ${b.childrenCount} طفل | ${b.infantsCount} رضيع</p>
          ${b.companions ? `<p><strong>المرافقين:</strong> ${b.companions.replace(/\n/g, ' - ')}</p>` : ''}
        </div>
        <div class="money-strip">
          <span>الإجمالي: ${b.totalAmount}</span>
          <span style="color:#15803d;">المقدم: ${b.depositAmount}</span>
          <span style="color:#b91c1c;">المتبقي: ${b.remainingAmount}</span>
        </div>
        ${thumbsHtml ? `<div class="card-thumbs">${thumbsHtml}</div>` : ''}
        <div class="card-actions">
          <a class="btn-wa" href="https://wa.me/${waNumber}" target="_blank">واتساب</a>
          <button class="btn-edit" onclick="editBooking('${b.id}')">تعديل</button>
          <button class="btn-delete" onclick="deleteBooking('${b.id}')">حذف</button>
        </div>
      </div>
    `;
  }).join('');
}

function editBooking(id) {
  const b = bookings.find(item => item.id === id);
  if (!b) return;

  document.getElementById('editId').value = b.id;
  document.getElementById('formTitle').textContent = 'تعديل بيانات الحجز';
  document.getElementById('clientCode').value = b.clientCode;
  document.getElementById('clientName').value = b.clientName;
  document.getElementById('phone').value = b.phone;
  document.getElementById('whatsapp').value = b.whatsapp;
  document.getElementById('adultCount').value = b.adultCount;
  document.getElementById('companions').value = b.companions;
  document.getElementById('childrenCount').value = b.childrenCount;
  document.getElementById('infantsCount').value = b.infantsCount;
  document.getElementById('tripDate').value = b.tripDate;
  document.getElementById('totalAmount').value = b.totalAmount;
  document.getElementById('depositAmount').value = b.depositAmount;
  document.getElementById('remainingAmount').value = b.remainingAmount;
  document.getElementById('salesRep').value = b.salesRep;
  currentImages = [...(b.images || [])];
  renderImagePreviews();

  navigateTo('new-booking');
}

function deleteBooking(id) {
  if (!confirm('هل أنت متأكد من حذف هذا الحجز؟')) return;
  bookings = bookings.filter(b => b.id !== id);
  saveToStorage();
  renderBookings(bookings, 'bookingsContainer');
  performSearch();
}

function performSearch() {
  const query = document.getElementById('searchInput').value.trim().toLowerCase();
  const rep = document.getElementById('searchRepFilter').value;

  const filtered = bookings.filter(b => {
    const matchesText =
      b.clientCode.toLowerCase().includes(query) ||
      b.clientName.toLowerCase().includes(query) ||
      b.phone.includes(query) ||
      b.whatsapp.includes(query);
    const matchesRep = rep ? b.salesRep === rep : true;
    return matchesText && matchesRep;
  });

  renderBookings(filtered, 'searchResultsContainer');
}

function renderReports() {
  const totalBookings = bookings.length;
  const totalAdults = bookings.reduce((s, b) => s + (b.adultCount || 0), 0);
  const totalChildren = bookings.reduce((s, b) => s + (b.childrenCount || 0), 0);
  const totalInfants = bookings.reduce((s, b) => s + (b.infantsCount || 0), 0);

  const totalRevenue = bookings.reduce((s, b) => s + (b.totalAmount || 0), 0);
  const totalDeposit = bookings.reduce((s, b) => s + (b.depositAmount || 0), 0);
  const totalRemaining = bookings.reduce((s, b) => s + (b.remainingAmount || 0), 0);

  const sayedBookings = bookings.filter(b => b.salesRep === 'سيد');
  const amiraBookings = bookings.filter(b => b.salesRep === 'أميرة');

  const sayedTotal = sayedBookings.reduce((s, b) => s + (b.totalAmount || 0), 0);
  const amiraTotal = amiraBookings.reduce((s, b) => s + (b.totalAmount || 0), 0);

  document.getElementById('reportsContent').innerHTML = `
    <div class="report-card">
      <h4>ملخص المعتمرين</h4>
      <div class="report-row"><span>عدد الحجوزات:</span><strong>${totalBookings}</strong></div>
      <div class="report-row"><span>إجمالي البالغين:</span><strong>${totalAdults}</strong></div>
      <div class="report-row"><span>إجمالي الأطفال:</span><strong>${totalChildren}</strong></div>
      <div class="report-row"><span>إجمالي الرضع:</span><strong>${totalInfants}</strong></div>
    </div>

    <div class="report-card">
      <h4>الملخص المالي</h4>
      <div class="report-row"><span>إجمالي قيمة الرحلات:</span><strong>${totalRevenue.toLocaleString()}</strong></div>
      <div class="report-row"><span>إجمالي المقدم المحصل:</span><strong style="color:#15803d;">${totalDeposit.toLocaleString()}</strong></div>
      <div class="report-row"><span>إجمالي المتبقي:</span><strong style="color:#b91c1c;">${totalRemaining.toLocaleString()}</strong></div>
    </div>

    <div class="report-card">
      <h4>تقرير مسؤولي المبيعات</h4>
      <div class="report-row"><span>حجوزات أ/ سيد (${sayedBookings.length}):</span><strong>${sayedTotal.toLocaleString()}</strong></div>
      <div class="report-row"><span>حجوزات أ/ أميرة (${amiraBookings.length}):</span><strong>${amiraTotal.toLocaleString()}</strong></div>
    </div>
  `;
}

function exportDataJSON() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(bookings, null, 2));
  const dlAnchor = document.createElement('a');
  dlAnchor.setAttribute("href", dataStr);
  dlAnchor.setAttribute("download", "SD_Travel_Backup.json");
  document.body.appendChild(dlAnchor);
  dlAnchor.click();
  dlAnchor.remove();
}

function exportDataCSV() {
  const headers = ["كود العميل", "اسم العميل", "الهاتف", "واتساب", "البالغين", "المرافقين", "اطفال", "رضع", "تاريخ الرحلة", "المبلغ", "المقدم", "المتبقي", "مسؤول المبيعات"];
  const rows = bookings.map(b => [
    b.clientCode, b.clientName, b.phone, b.whatsapp, b.adultCount,
    `"${(b.companions || '').replace(/\n/g, ' ')}"`, b.childrenCount, b.infantsCount,
    b.tripDate, b.totalAmount, b.depositAmount, b.remainingAmount, b.salesRep
  ]);
  const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", "SD_Travel_Bookings.csv");
  document.body.appendChild(link);
  link.click();
  link.remove();
}

function openModal(src) {
  document.getElementById('modalImage').src = src;
  document.getElementById('imageModal').classList.remove('hidden');
}

function closeModal() {
  document.getElementById('imageModal').classList.add('hidden');
}

updateHomeStats();
