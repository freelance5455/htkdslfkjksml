const STORAGE_KEY = 'sd_travel_umrah_bookings_v1';
let bookings = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
let currentImages = [];

// التنقل بين التبويبات
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-section').forEach(s => s.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'bookings-list') renderBookings();
    if (btn.dataset.tab === 'reports') updateStats();
  });
});

// حساب المتبقي تلقائياً
const totalPriceEl = document.getElementById('totalPrice');
const depositEl = document.getElementById('deposit');
const remainingEl = document.getElementById('remaining');

function calculateRemaining() {
  const total = parseFloat(totalPriceEl.value) || 0;
  const deposit = parseFloat(depositEl.value) || 0;
  remainingEl.value = Math.max(0, total - deposit);
}

totalPriceEl.addEventListener('input', calculateRemaining);
depositEl.addEventListener('input', calculateRemaining);

// ضغط الصور لحفظ المساحة على الهاتف
function compressImage(file, callback) {
  const reader = new FileReader();
  reader.onload = function(e) {
    const img = new Image();
    img.onload = function() {
      const canvas = document.createElement('canvas');
      const MAX_WIDTH = 800;
      let width = img.width;
      let height = img.height;
      if (width > MAX_WIDTH) {
        height *= MAX_WIDTH / width;
        width = MAX_WIDTH;
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, width, height);
      callback(canvas.toDataURL('image/jpeg', 0.7));
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function handleFiles(files) {
  Array.from(files).forEach(file => {
    compressImage(file, (base64) => {
      currentImages.push(base64);
      renderPreviews();
    });
  });
}

document.getElementById('cameraInput').addEventListener('change', (e) => handleFiles(e.target.files));
document.getElementById('galleryInput').addEventListener('change', (e) => handleFiles(e.target.files));

function renderPreviews() {
  const container = document.getElementById('preview-container');
  container.innerHTML = '';
  currentImages.forEach((src, index) => {
    const div = document.createElement('div');
    div.className = 'preview-item';
    div.innerHTML = `<img src="${src}" alt="مرفق" /><button type="button" class="remove-img" onclick="removeImage(${index})">×</button>`;
    container.appendChild(div);
  });
}

window.removeImage = function(index) {
  currentImages.splice(index, 1);
  renderPreviews();
};

// حفظ حجز جديد
document.getElementById('booking-form').addEventListener('submit', function(e) {
  e.preventDefault();
  const newBooking = {
    id: Date.now(),
    clientCode: document.getElementById('clientCode').value.trim(),
    tripDate: document.getElementById('tripDate').value,
    clientName: document.getElementById('clientName').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    whatsapp: document.getElementById('whatsapp').value.trim() || document.getElementById('phone').value.trim(),
    companionsCount: parseInt(document.getElementById('companionsCount').value) || 1,
    salesRep: document.getElementById('salesRep').value,
    companionsNames: document.getElementById('companionsNames').value.trim(),
    totalPrice: parseFloat(totalPriceEl.value) || 0,
    deposit: parseFloat(depositEl.value) || 0,
    remaining: parseFloat(remainingEl.value) || 0,
    images: [...currentImages]
  };

  bookings.unshift(newBooking);
  saveToStorage();
  this.reset();
  currentImages = [];
  renderPreviews();
  remainingEl.value = 0;
  alert('✅ تم حفظ الحجز بنجاح على الهاتف!');
});

function saveToStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
    updateCountBadge();
  } catch (err) {
    alert('⚠️ مساحة التخزين ممتلئة، يرجى تصدير نسخة احتياطية وتقليل حجم الصور.');
  }
}

function updateCountBadge() {
  document.getElementById('count-badge').textContent = bookings.length;
}

// عرض الحجوزات والبحث
const searchNameEl = document.getElementById('searchName');
const searchDateEl = document.getElementById('searchDate');

searchNameEl.addEventListener('input', renderBookings);
searchDateEl.addEventListener('change', renderBookings);
document.getElementById('clearSearch').addEventListener('click', () => {
  searchNameEl.value = '';
  searchDateEl.value = '';
  renderBookings();
});

function renderBookings() {
  const container = document.getElementById('bookings-container');
  const query = searchNameEl.value.toLowerCase().trim();
  const dateFilter = searchDateEl.value;

  const filtered = bookings.filter(b => {
    const matchText = !query || b.clientName.toLowerCase().includes(query) || b.clientCode.toLowerCase().includes(query);
    const matchDate = !dateFilter || b.tripDate === dateFilter;
    return matchText && matchDate;
  });

  if (filtered.length === 0) {
    container.innerHTML = '<div class="card" style="text-align:center;color:#64748b;">لا توجد حجوزات مطابقة</div>';
    return;
  }

  container.innerHTML = filtered.map(b => `
    <div class="booking-item">
      <div class="booking-header">
        <strong>${b.clientName}</strong>
        <span class="code-tag">${b.clientCode}</span>
      </div>
      <div class="booking-details">
        <p>📅 تاريخ الرحلة: <strong>${b.tripDate}</strong> | 👥 الأفراد: <strong>${b.companionsCount}</strong></p>
        <p>📞 الهاتف: ${b.phone} | 🧑‍💼 المسؤول: ${b.salesRep}</p>
        ${b.companionsNames ? `<p>📝 المرافقين: ${b.companionsNames}</p>` : ''}
      </div>
      <div class="money-bar">
        <span>الإجمالي: <strong>${b.totalPrice}</strong></span>
        <span>المقدم: <strong>${b.deposit}</strong></span>
        <span style="color:#b91c1c;">المتبقي: <strong>${b.remaining}</strong></span>
      </div>
      ${b.images && b.images.length ? `
        <div class="doc-thumbs">
          ${b.images.map(img => `<img src="${img}" onclick="openModal('${img}')" alt="مستند" />`).join('')}
        </div>
      ` : ''}
      <div class="booking-actions">
        <a class="btn-wa" href="https://wa.me/${b.whatsapp.replace(/^0/, '20')}" target="_blank">💬 واتساب</a>
        <button class="btn-del" onclick="deleteBooking(${b.id})">🗑️ حذف</button>
      </div>
    </div>
  `).join('');
}

window.deleteBooking = function(id) {
  if (confirm('هل أنت متأكد من حذف هذا الحجز؟')) {
    bookings = bookings.filter(b => b.id !== id);
    saveToStorage();
    renderBookings();
    updateStats();
  }
};

// عرض الصورة مكبرة
const modal = document.getElementById('imageModal');
const modalImg = document.getElementById('modalImg');
window.openModal = function(src) {
  modal.style.display = 'flex';
  modalImg.src = src;
};
document.querySelector('.close-modal').onclick = () => modal.style.display = 'none';
modal.onclick = (e) => { if (e.target === modal) modal.style.display = 'none'; };

// الإحصائيات والتقارير
function updateStats() {
  document.getElementById('stat-bookings').textContent = bookings.length;
  document.getElementById('stat-pilgrims').textContent = bookings.reduce((s, b) => s + (b.companionsCount || 0), 0);
  document.getElementById('stat-total').textContent = bookings.reduce((s, b) => s + (b.totalPrice || 0), 0);
  document.getElementById('stat-remaining').textContent = bookings.reduce((s, b) => s + (b.remaining || 0), 0);
}

// تصدير Excel (CSV متوافق مع العربية)
document.getElementById('exportExcelBtn').addEventListener('click', () => {
  if (bookings.length === 0) return alert('لا توجد بيانات للتصدير');
  const headers = ['كود العميل', 'اسم العميل', 'تاريخ الرحلة', 'رقم الهاتف', 'رقم الواتساب', 'عدد الأفراد', 'أسماء المرافقين', 'إجمالي السعر', 'المقدم', 'المتبقي', 'مسؤول المبيعات'];
  const rows = bookings.map(b => [
    b.clientCode, b.clientName, b.tripDate, b.phone, b.whatsapp,
    b.companionsCount, (b.companionsNames || '').replace(/\n/g, ' '),
    b.totalPrice, b.deposit, b.remaining, b.salesRep
  ]);

  const csvContent = '\uFEFF' + [headers, ...rows]
    .map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `SD_Travel_Umrah_Report_${new Date().toISOString().slice(0,10)}.csv`;
  link.click();
});

// نسخة احتياطية JSON
document.getElementById('backupJsonBtn').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(bookings, null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `SD_Travel_Backup_${new Date().toISOString().slice(0,10)}.json`;
  link.click();
});

document.getElementById('restoreJsonInput').addEventListener('change', function(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(evt) {
    try {
      const imported = JSON.parse(evt.target.result);
      if (Array.isArray(imported)) {
        bookings = imported;
        saveToStorage();
        updateStats();
        alert('✅ تم استعادة البيانات بنجاح!');
      }
    } catch (err) {
      alert('❌ ملف غير صالح');
    }
  };
  reader.readAsText(file);
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}

updateCountBadge();
updateStats();
