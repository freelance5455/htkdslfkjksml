package VoiceChanger

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var webView: WebView

    private lateinit var microphone: Microphone
    private lateinit var voiceEngine: VoiceEngine
    private lateinit var audioOutput: AudioOutput
    private lateinit var audioRouter: AudioRouter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // =========================
        // WebView
        // =========================

        webView = WebView(this)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true

        webView.webViewClient = WebViewClient()

        // =========================
        // Audio Components
        // =========================

        voiceEngine = VoiceEngine()

        audioOutput = AudioOutput()

        microphone = Microphone(
            this,
            voiceEngine,
            audioOutput
        )

        audioRouter = AudioRouter(this)

        // =========================
        // JavaScript Bridge
        // =========================

        webView.addJavascriptInterface(
            AndroidBridge(),
            "AndroidVoice"
        )

        // =========================
        // Show Web App
        // =========================

        setContentView(webView)

        webView.loadUrl(
            "file:///android_asset/index.html"
        )

        // =========================
        // Microphone Permission
        // =========================

        requestMicrophonePermission()
    }


    // =====================================================
    // Microphone Permission
    // =====================================================

    private fun requestMicrophonePermission() {

        if (
            checkSelfPermission(
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO
                ),
                100
            )
        }
    }


    // =====================================================
    // JavaScript → Android Bridge
    // =====================================================

    inner class AndroidBridge {

        @JavascriptInterface
        fun startVoice(mode: String) {

            runOnUiThread {

                // Start Voice Engine
                voiceEngine.start(mode)

                // Start Audio Output
                audioOutput.start()

                // Start Microphone
                microphone.start()

                // Start Router
                audioRouter.start()
            }
        }


        @JavascriptInterface
        fun stopVoice() {

            runOnUiThread {

                // Stop Microphone
                microphone.stop()

                // Stop Voice Engine
                voiceEngine.stop()

                // Stop Audio Output
                audioOutput.stop()

                // Stop Router
                audioRouter.stop()
            }
        }
    }


    // =====================================================
    // Activity Destroy
    // =====================================================

    override fun onDestroy() {

        try {
            microphone.stop()
        } catch (_: Exception) {
        }

        try {
            voiceEngine.stop()
        } catch (_: Exception) {
        }

        try {
            audioOutput.stop()
        } catch (_: Exception) {
        }

        try {
            audioRouter.stop()
        } catch (_: Exception) {
        }

        webView.destroy()

        super.onDestroy()
    }
}