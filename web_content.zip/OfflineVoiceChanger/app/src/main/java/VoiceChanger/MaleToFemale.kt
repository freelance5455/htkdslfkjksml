package VoiceChanger

import kotlin.math.max
import kotlin.math.min

object MaleToFemale {

    private const val PITCH_FACTOR = 1.45f

    fun process(input: ShortArray): ShortArray {

        if (input.isEmpty()) {
            return input
        }

        val output = ShortArray(input.size)

        for (i in output.indices) {

            val sourcePosition = i / PITCH_FACTOR

            val index = sourcePosition.toInt()

            val fraction = sourcePosition - index

            val sample1 =
                if (index < input.size) {
                    input[index].toFloat()
                } else {
                    0f
                }

            val sample2 =
                if (index + 1 < input.size) {
                    input[index + 1].toFloat()
                } else {
                    sample1
                }

            var sample =
                sample1 +
                (sample2 - sample1) * fraction

            // Slight brightness
            sample *= 1.08f

            // Prevent clipping
            sample = max(
                -32767f,
                min(32767f, sample)
            )

            output[i] = sample.toInt().toShort()
        }

        return smooth(output)
    }

    private fun smooth(input: ShortArray): ShortArray {

        if (input.size < 3) {
            return input
        }

        val output = input.copyOf()

        for (i in 1 until input.size - 1) {

            val previous = input[i - 1].toInt()
            val current = input[i].toInt()
            val next = input[i + 1].toInt()

            output[i] =
                (
                    previous +
                    current * 2 +
                    next
                ) / 4
        }

        return output
    }
}