package VoiceChanger

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

class AudioOutput {

    private var audioTrack: AudioTrack? = null

    private val sampleRate = 44100

    fun start() {

        if (audioTrack != null) {
            return
        }

        val minBufferSize =
            AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

        if (minBufferSize <= 0) {
            return
        }

        val bufferSize = minBufferSize * 2

        audioTrack =
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(
                            AudioAttributes.USAGE_MEDIA
                        )
                        .setContentType(
                            AudioAttributes.CONTENT_TYPE_MUSIC
                        )
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(
                            AudioFormat.ENCODING_PCM_16BIT
                        )
                        .setChannelMask(
                            AudioFormat.CHANNEL_OUT_MONO
                        )
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(
                    AudioTrack.MODE_STREAM
                )
                .build()

        audioTrack?.play()
    }

    fun play(audio: ShortArray) {

        if (audio.isEmpty()) {
            return
        }

        audioTrack?.write(
            audio,
            0,
            audio.size,
            AudioTrack.WRITE_BLOCKING
        )
    }

    fun stop() {

        try {
            audioTrack?.stop()
        } catch (_: Exception) {
        }

        audioTrack?.release()

        audioTrack = null
    }
}