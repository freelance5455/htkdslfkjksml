package VoiceChanger

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

class AudioOutput {

    private var audioTrack: AudioTrack? = null

    private val sampleRate = 44100

    fun start() {

        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(
                        AudioAttributes.USAGE_MEDIA
                    )
                    .setContentType(
                        AudioAttributes.CONTENT_TYPE_MUSIC
                    )
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                    .setChannelMask(
                        AudioFormat.CHANNEL_OUT_MONO
                    )
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .build()

        audioTrack?.play()
    }

    fun play(audio: ShortArray) {

        audioTrack?.write(
            audio,
            0,
            audio.size
        )
    }

    fun stop() {

        audioTrack?.stop()
        audioTrack?.release()

        audioTrack = null
    }
}