package VoiceChanger

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

class Microphone(
    private val context: Context,
    private val voiceEngine: VoiceEngine,
    private val audioOutput: AudioOutput
) {

    private var recorder: AudioRecord? = null
    private var recordingThread: Thread? = null

    private val sampleRate = 44100

    @Volatile
    private var running = false

    fun start() {

        if (running) return

        val bufferSize = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        if (bufferSize <= 0) {
            return
        }

        recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize * 2
        )

        recorder?.startRecording()

        running = true

        recordingThread = Thread {

            val buffer = ShortArray(bufferSize)

            while (running) {

                val count = recorder?.read(
                    buffer,
                    0,
                    buffer.size
                ) ?: 0

                if (count > 0) {

                    val inputAudio =
                        buffer.copyOf(count)

                    // Microphone
                    // ↓
                    // Voice Engine
                    val processedAudio =
                        voiceEngine.processAudio(
                            inputAudio
                        )

                    // Voice Engine
                    // ↓
                    // Audio Output
                    audioOutput.play(
                        processedAudio
                    )
                }
            }
        }

        recordingThread?.start()
    }

    fun stop() {

        running = false

        try {
            recorder?.stop()
        } catch (_: Exception) {
        }

        recorder?.release()
        recorder = null

        recordingThread = null
    }
}ction