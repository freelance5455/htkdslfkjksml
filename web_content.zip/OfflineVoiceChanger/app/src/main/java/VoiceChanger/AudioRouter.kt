package VoiceChanger

import android.content.Context
import android.media.AudioManager

class AudioRouter(
    private val context: Context
) {

    private val audioManager =
        context.getSystemService(
            Context.AUDIO_SERVICE
        ) as AudioManager

    fun start() {

        /*
         * এখানে পরবর্তীতে Android-এর
         * audio routing implementation
         * করা হবে।
         */

    }

    fun stop() {

        /*
         * Audio routing বন্ধ করার
         * implementation এখানে থাকবে।
         */

    }
}