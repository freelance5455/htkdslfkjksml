package VoiceChanger

class VoiceEngine {

    private var mode = "maleToFemale"
    private var running = false

    fun start(selectedMode: String) {

        mode = selectedMode
        running = true

        println("Voice Engine started: $mode")
    }

    fun stop() {

        running = false

        println("Voice Engine stopped")
    }

    fun processAudio(
        input: ShortArray
    ): ShortArray {

        if (!running) {
            return input
        }

        return when (mode) {

            "maleToFemale" ->
                MaleToFemale.process(input)

            "femaleToMale" ->
                FemaleToMale.process(input)

            else ->
                input
        }
    }
}