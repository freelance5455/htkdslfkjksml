package VoiceChanger

class VoiceEngine {

    private var mode = "maleToFemale"
    private var running = false

    fun start(selectedMode: String) {
        mode = selectedMode
        running = true
    }

    fun stop() {
        running = false
    }

    fun processAudio(input: ShortArray): ShortArray {

        if (!running || input.isEmpty()) {
            return input
        }

        return when (mode) {

            "maleToFemale" ->
                MaleToFemale.process(input)

            "femaleToMale" ->
                FemaleToMale.process(input)

            else ->
                input
        }
    }
}