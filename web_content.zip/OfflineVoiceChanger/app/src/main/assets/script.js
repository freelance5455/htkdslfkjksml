const maleToFemale = document.getElementById("maleToFemale");
const femaleToMale = document.getElementById("femaleToMale");

const startButton = document.getElementById("startButton");
const startIcon = document.getElementById("startIcon");
const startText = document.getElementById("startText");

const statusDot = document.getElementById("statusDot");
const statusText = document.getElementById("statusText");

let selectedVoice = "maleToFemale";
let isRunning = false;


// =====================================================
// Male → Female
// =====================================================

maleToFemale.addEventListener("click", () => {

    if (isRunning) return;

    selectedVoice = "maleToFemale";

    maleToFemale.classList.add("active");
    femaleToMale.classList.remove("active");
});


// =====================================================
// Female → Male
// =====================================================

femaleToMale.addEventListener("click", () => {

    if (isRunning) return;

    selectedVoice = "femaleToMale";

    femaleToMale.classList.add("active");
    maleToFemale.classList.remove("active");
});


// =====================================================
// START / STOP
// =====================================================

startButton.addEventListener("click", () => {

    if (!isRunning) {

        // =============================================
        // START
        // =============================================

        isRunning = true;

        startButton.classList.add("running");

        startIcon.textContent = "⏹️";
        startText.textContent = "STOP";

        statusDot.classList.add("on");
        statusText.textContent = "Voice ON";


        // =============================================
        // Send command to Android Kotlin
        // =============================================

        if (
            window.AndroidVoice &&
            typeof window.AndroidVoice.startVoice === "function"
        ) {

            window.AndroidVoice.startVoice(
                selectedVoice
            );

        } else {

            console.log(
                "AndroidVoice bridge not available"
            );
        }


        console.log(
            "Voice started:",
            selectedVoice
        );


    } else {

        // =============================================
        // STOP
        // =============================================

        isRunning = false;

        startButton.classList.remove("running");

        startIcon.textContent = "🎤";
        startText.textContent = "START";

        statusDot.classList.remove("on");
        statusText.textContent = "Voice OFF";


        // =============================================
        // Send command to Android Kotlin
        // =============================================

        if (
            window.AndroidVoice &&
            typeof window.AndroidVoice.stopVoice === "function"
        ) {

            window.AndroidVoice.stopVoice();

        } else {

            console.log(
                "AndroidVoice bridge not available"
            );
        }


        console.log(
            "Voice stopped"
        );
    }
});