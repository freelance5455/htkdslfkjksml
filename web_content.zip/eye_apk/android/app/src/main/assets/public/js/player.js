// ===== PLAYER ANIMATION DATA =====
const PS = 1.18; // player scale
const SHEATHED = P({ t: 3, a1u: 8, a1f: 16, a2u: -10, a2f: 0, l1t: 6, l1s: -2, l2t: -8, l2s: -4, w: 14 });
const READY = {
  sword: P({ t: 10, a1u: 30, a1f: 100, w: 150, a2u: 42, a2f: 110, l1t: 24, l1s: 4, l2t: -20, l2s: -8 }),
  dual: P({ t: 12, a1u: 35, a1f: 85, w: 115, a2u: 55, a2f: 120, w2: 160, l1t: 24, l1s: 4, l2t: -20, l2s: -8 }),
  hammer: P({ t: 8, a1u: 18, a1f: 140, w: -160, a2u: 40, a2f: 100, l1t: 20, l1s: 4, l2t: -18, l2s: -6 }),
  scythe: P({ t: 8, a1u: 25, a1f: 80, w: 170, a2u: 15, a2f: 60, l1t: 22, l1s: 4, l2t: -18, l2s: -6 }),
  spear: P({ t: 6, a1u: 45, a1f: 80, w: 95, a2u: 20, a2f: 75, l1t: 22, l1s: 4, l2t: -18, l2s: -6 }),
};
const RUNARM = {
  sword: { a1u: -28, a1f: -8, w: -128, a2u: 30, a2f: 70 },
  dual: { a1u: -30, a1f: -10, w: -120, a2u: -20, a2f: 10, w2: -110 },
  hammer: { a1u: 18, a1f: 140, w: -160, a2u: 40, a2f: 100 },
  scythe: { a1u: -20, a1f: 10, w: -150, a2u: 30, a2f: 60 },
  spear: { a1u: 10, a1f: 50, w: 80, a2u: -10, a2f: 30 },
};
// sheath on back: grip offset from shoulder (torso frame), relative angle
const SHEATH = { sword: { ox: -11, oy: -12, a: 14 }, dual: { ox: -10, oy: -8, a: 24 }, hammer: { ox: -7, oy: 26, a: 196 }, scythe: { ox: -7, oy: 32, a: 198 }, spear: { ox: -7, oy: 22, a: 202 } };
const REACH = { t: -6, h: -14, a1u: 196, a1f: 246, a2u: -14, a2f: 4, l1t: 10, l1s: 0, l2t: -12, l2s: -6 };
const PULL = { t: 4, h: -4, a1u: 160, a1f: 172, w: 185 };
const FLOURISH = { t: 10, a1u: 118, a1f: 146, w: 168 };

function F(t, p) { return { t, p }; }
const ATK = {
  sword: {
    combo: [
      { f: [F(0.10, { t: -6, a1u: 178, a1f: 205, w: 212, a2u: 160, a2f: 195, l1t: 20, l1s: 6, l2t: -24, l2s: -10 }), F(0.17, { t: 22, a1u: 84, a1f: 62, w: 28, a2u: 74, a2f: 58, l1t: 36, l1s: 6, l2t: -30, l2s: -14 }), F(0.30, { t: 26, a1u: 26, a1f: 4, w: -28, a2u: 20, a2f: 2, l1t: 36, l1s: 6, l2t: -30, l2s: -14 }), F(0.44, 'R')], act: [0.11, 0.22], dmg: 1, kb: 1, lunge: 260 },
      { f: [F(0.08, { t: 16, a1u: -24, a1f: -10, w: -70, a2u: -10, a2f: 10, l1t: 30, l1s: 6, l2t: -26, l2s: -12 }), F(0.16, { t: -8, a1u: 150, a1f: 168, w: 176, a2u: 140, a2f: 160 }), F(0.27, { t: -12, a1u: 172, a1f: 200, w: 214, a2u: 160, a2f: 190 }), F(0.42, 'R')], act: [0.09, 0.2], dmg: 1.1, kb: 0.6, up: -560, lunge: 160 },
      { f: [F(0.14, { bY: -6, t: -16, a1u: 205, a1f: 228, w: 240, a2u: 195, a2f: 220, l1t: 34, l1s: -4, l2t: -14, l2s: -20 }), F(0.24, { t: 36, a1u: 96, a1f: 76, w: 62, a2u: 88, a2f: 70, l1t: 46, l1s: 14, l2t: -38, l2s: -30 }), F(0.44, { t: 36, a1u: 96, a1f: 76, w: 62, a2u: 88, a2f: 70, l1t: 46, l1s: 14, l2t: -38, l2s: -30 }), F(0.6, 'R')], act: [0.17, 0.3], dmg: 2.2, kb: 2, heavy: true, fin: true, lunge: 380, impact: 0.24 },
    ],
    air: { f: [F(0.07, { t: -10, a1u: 190, a1f: 215, w: 225, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.15, { t: 30, a1u: 70, a1f: 40, w: 10, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.32, 'R')], act: [0.07, 0.2], dmg: 1.2, kb: 0.8 },
  },
  dual: {
    combo: [
      { f: [F(0.08, { a1u: 165, a1f: 190, w: 205, t: -4 }), F(0.15, { a1u: 70, a1f: 45, w: 20, t: 20 }), F(0.26, 'R')], act: [0.09, 0.18], dmg: 1, kb: 1, lunge: 200 },
      { f: [F(0.07, { a2u: 170, a2f: 195, w2: 215, t: -6, a1u: 20, a1f: 60, w: 60 }), F(0.14, { a2u: 75, a2f: 50, w2: 15, t: 22, a1u: 20, a1f: 60, w: 60 }), F(0.26, 'R')], act: [0.08, 0.17], dmg: 1, kb: 1, lunge: 200 },
      { f: [F(0.08, { a1u: 170, a1f: 200, w: 210, a2u: 170, a2f: 200, w2: 215, t: -8 }), F(0.16, { a1u: 90, a1f: 80, w: 60, a2u: 80, a2f: 70, w2: 50, t: 24 }), F(0.3, 'R')], act: [0.09, 0.19], dmg: 1.3, kb: 0.5, up: -420, lunge: 160 },
      { f: [F(0.1, { t: -10, a1u: 110, a1f: 120, w: 100, a2u: -90, a2f: -100, w2: -100 }), F(0.2, { t: 30, a1u: 40, a1f: 20, w: 10, a2u: 120, a2f: 150, w2: 160, bY: -4 }), F(0.38, 'R')], act: [0.08, 0.24], dmg: 1.9, kb: 2.2, heavy: true, fin: true, lunge: 420 },
    ],
    air: { f: [F(0.06, { a1u: 170, a1f: 200, w: 210, a2u: 170, a2f: 200, w2: 215, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.13, { a1u: 60, a1f: 30, w: 10, a2u: 60, a2f: 30, w2: 10, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.26, 'R')], act: [0.06, 0.16], dmg: 1.1, kb: 0.8 },
  },
  hammer: {
    combo: [
      { f: [F(0.16, { t: -14, a1u: 195, a1f: 205, w: 205, a2u: 190, a2f: 200 }), F(0.26, { t: 32, a1u: 92, a1f: 78, w: 72, a2u: 84, a2f: 70, l1t: 44, l1s: 12, l2t: -36, l2s: -26 }), F(0.44, { t: 32, a1u: 92, a1f: 78, w: 72, a2u: 84, a2f: 70, l1t: 44, l1s: 12, l2t: -36, l2s: -26 }), F(0.6, 'R')], act: [0.2, 0.3], dmg: 1, kb: 1, lunge: 180, impact: 0.26 },
      { f: [F(0.14, { t: -6, a1u: -70, a1f: -60, w: -100, a2u: -60, a2f: -50 }), F(0.24, { t: 22, a1u: 100, a1f: 96, w: 100, a2u: 90, a2f: 92 }), F(0.36, { t: 26, a1u: 150, a1f: 160, w: 160, a2u: 140, a2f: 150 }), F(0.55, 'R')], act: [0.17, 0.28], dmg: 1, kb: 0.7, up: -420, lunge: 200 },
      { f: [F(0.2, { bY: -10, t: -20, a1u: 210, a1f: 220, w: 230, a2u: 200, a2f: 210, l1t: 40, l1s: -10, l2t: -10, l2s: -40 }), F(0.3, { t: 40, a1u: 95, a1f: 70, w: 55, a2u: 85, a2f: 60, l1t: 50, l1s: 15, l2t: -40, l2s: -30 }), F(0.55, { t: 40, a1u: 95, a1f: 70, w: 55, a2u: 85, a2f: 60, l1t: 50, l1s: 15, l2t: -40, l2s: -30 }), F(0.75, 'R')], act: [0.24, 0.34], dmg: 2.4, kb: 1.6, heavy: true, fin: true, lunge: 260, impact: 0.3, quake: true },
    ],
    air: { f: [F(0.1, { t: -14, a1u: 200, a1f: 210, w: 215, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.2, { t: 34, a1u: 80, a1f: 60, w: 40, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.4, 'R')], act: [0.12, 0.26], dmg: 1.4, kb: 1, slamDown: true },
  },
  scythe: {
    combo: [
      { f: [F(0.10, { t: -6, a1u: -60, a1f: -40, w: -120, a2u: -40, a2f: -20 }), F(0.20, { t: 18, a1u: 105, a1f: 100, w: 95, a2u: 90, a2f: 80 }), F(0.32, { t: 22, a1u: 150, a1f: 165, w: 160, a2u: 130, a2f: 140 }), F(0.46, 'R')], act: [0.11, 0.25], dmg: 1, kb: 1, lunge: 200 },
      { f: [F(0.08, { t: -10, a1u: 170, a1f: 190, w: 200 }), F(0.18, { t: 20, a1u: 20, a1f: -10, w: -60 }), F(0.30, { t: 24, a1u: -30, a1f: -50, w: -110 }), F(0.44, 'R')], act: [0.09, 0.22], dmg: 1.1, kb: 0.8, up: -380, lunge: 160 },
      { f: [F(0.08, { t: 0, a1u: 90, a1f: 90, w: 90 }), F(0.2, { w: 270, a1u: 100, a1f: 110, t: 10 }), F(0.32, { w: 450, a1u: 90, a1f: 90, t: 20 }), F(0.5, { ...READY.scythe, w: 530 })], act: [0.08, 0.34], dmg: 1.8, kb: 1.8, heavy: true, fin: true, lunge: 300, rehit: 0.2 },
    ],
    air: { f: [F(0.08, { a1u: 90, a1f: 90, w: 90, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.22, { w: 450, a1u: 90, a1f: 90, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.34, { ...READY.scythe, w: 530 })], act: [0.08, 0.24], dmg: 1.2, kb: 0.8 },
  },
  spear: {
    combo: [
      { f: [F(0.08, { t: -6, a1u: 10, a1f: 50, w: 92, a2u: -10, a2f: 40 }), F(0.14, { t: 18, a1u: 88, a1f: 90, w: 92, a2u: 70, a2f: 88, l1t: 40, l1s: 10, l2t: -34, l2s: -20 }), F(0.26, { t: 18, a1u: 88, a1f: 90, w: 92, a2u: 70, a2f: 88, l1t: 40, l1s: 10, l2t: -34, l2s: -20 }), F(0.36, 'R')], act: [0.1, 0.2], dmg: 1, kb: 1, lunge: 300 },
      { f: [F(0.06, { t: -4, a1u: 20, a1f: 60, w: 100 }), F(0.11, { t: 16, a1u: 86, a1f: 92, w: 100 }), F(0.17, { t: -4, a1u: 20, a1f: 60, w: 86 }), F(0.22, { t: 16, a1u: 86, a1f: 88, w: 86 }), F(0.36, 'R')], act: [0.07, 0.24], dmg: 0.8, kb: 0.6, lunge: 200, rehit: 0.16 },
      { f: [F(0.14, { t: -12, a1u: 160, a1f: 170, w: 160, a2u: 150, a2f: 160 }), F(0.24, { t: 24, a1u: 95, a1f: 95, w: 98, a2u: 80, a2f: 92, l1t: 46, l1s: 10, l2t: -40, l2s: -24 }), F(0.42, { t: 24, a1u: 95, a1f: 95, w: 98, a2u: 80, a2f: 92, l1t: 46, l1s: 10, l2t: -40, l2s: -24 }), F(0.56, 'R')], act: [0.16, 0.3], dmg: 2, kb: 1.8, heavy: true, fin: true, lunge: 520, rangeMul: 1.3 },
    ],
    air: { f: [F(0.08, { t: -10, a1u: 150, a1f: 160, w: 150, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.16, { t: 30, a1u: 60, a1f: 40, w: 40, l1t: 50, l1s: -10, l2t: 20, l2s: -30 }), F(0.3, 'R')], act: [0.08, 0.22], dmg: 1.2, kb: 0.8 },
  },
};

var outfitStyle = function () {
  const o = SHOP.find(s => s.id === Save.d.outfit) || SHOP.find(s => s.id === 'out_wanderer');
  const c = o.colors; const ex = Save.d.extras;
  return { player: true, head: 'human', skin: c.skin, cloak: c.cloak, armor: c.armor, cloth: shade(c.armor, -0.25), hood: c.hood, helm: c.helm, beak: c.beak, skullmask: c.skullmask, glow: c.glow, scarf: '#6a0a10', pants: shade(c.armor, -0.45), boot: '#2a1c12', glove: '#2a1c12', sleeve: shade(c.armor, -0.15), longCape: ex.includes('ex_cape'), halo: ex.includes('ex_halo'), haloCol: '#111', eyesGlow: ex.includes('ex_eyes') };
};

// ===== NIGHTMARE EVOLUTION: extended combat animation data =====
// five-hit light combos: steps 4 and 5 appended to every weapon (step 3 stays the mini-finisher)
(() => {
  const AIRLEG = { l1t: 50, l1s: -10, l2t: 20, l2s: -30 };
  ATK.sword.combo.push(
    { f: [F(0.09, { t: -4, a1u: -30, a1f: -10, w: -80, a2u: -20, a2f: 0, l1t: 30, l1s: 6, l2t: -26, l2s: -12 }), F(0.17, { t: 24, a1u: 110, a1f: 100, w: 95, a2u: 60, a2f: 80, l1t: 40, l1s: 10, l2t: -34, l2s: -20 }), F(0.26, { t: 28, a1u: 150, a1f: 170, w: 175, a2u: 90, a2f: 110, l1t: 40, l1s: 10, l2t: -34, l2s: -20 }), F(0.4, 'R')], act: [0.1, 0.22], dmg: 1.2, kb: 1.2, lunge: 300 },
    { f: [F(0.16, { bY: -14, t: -22, a1u: 215, a1f: 235, w: 250, a2u: 205, a2f: 225, l1t: 40, l1s: -20, l2t: -10, l2s: -40 }), F(0.26, { t: 42, a1u: 92, a1f: 70, w: 50, a2u: 84, a2f: 64, l1t: 52, l1s: 16, l2t: -44, l2s: -34 }), F(0.5, { t: 42, a1u: 92, a1f: 70, w: 50, a2u: 84, a2f: 64, l1t: 52, l1s: 16, l2t: -44, l2s: -34 }), F(0.68, 'R')], act: [0.19, 0.32], dmg: 3, kb: 2.4, heavy: true, fin: true, lunge: 380, impact: 0.27, big: true },
  );
  ATK.dual.combo.push(
    { f: [F(0.06, { t: -6, a1u: 170, a1f: 200, w: 210, a2u: -60, a2f: -40, w2: -80 }), F(0.12, { t: 20, a1u: 60, a1f: 30, w: 10, a2u: 150, a2f: 180, w2: 200 }), F(0.18, { t: -6, a1u: 170, a1f: 200, w: 210, a2u: -60, a2f: -40, w2: -80 }), F(0.24, { t: 24, a1u: 60, a1f: 30, w: 10, a2u: 150, a2f: 180, w2: 200 }), F(0.34, { t: 34, a1u: 100, a1f: 90, w: 80, a2u: 100, a2f: 90, w2: 80, l1t: 50, l1s: 14, l2t: -44, l2s: -30 }), F(0.52, 'R')], act: [0.05, 0.34], rehits: [0.12, 0.19, 0.27], dmg: 1, kb: 1.6, heavy: true, fin: true, lunge: 260, big: true },
  );
  ATK.hammer.combo.push(
    { f: [F(0.14, { t: -10, a1u: -60, a1f: -50, w: -110, a2u: -50, a2f: -40 }), F(0.26, { t: 18, a1u: 95, a1f: 95, w: 95, a2u: 85, a2f: 90, l1t: 40, l1s: 10, l2t: -34, l2s: -20 }), F(0.36, { t: 22, a1u: 160, a1f: 170, w: 175, a2u: 150, a2f: 160 }), F(0.56, 'R')], act: [0.17, 0.3], dmg: 1.3, kb: 1.6, lunge: 160, rangeMul: 1.1 },
    { f: [F(0.24, { bY: -16, t: -26, a1u: 220, a1f: 228, w: 236, a2u: 210, a2f: 220, l1t: 44, l1s: -14, l2t: -12, l2s: -44 }), F(0.34, { t: 46, a1u: 96, a1f: 68, w: 52, a2u: 86, a2f: 58, l1t: 54, l1s: 18, l2t: -44, l2s: -34 }), F(0.7, { t: 46, a1u: 96, a1f: 68, w: 52, a2u: 86, a2f: 58, l1t: 54, l1s: 18, l2t: -44, l2s: -34 }), F(0.9, 'R')], act: [0.28, 0.4], dmg: 3.2, kb: 2, heavy: true, fin: true, impact: 0.34, quake: true, lunge: 140, big: true },
  );
  ATK.scythe.combo.push(
    { f: [F(0.1, { t: 10, a1u: 20, a1f: 10, w: -40, a2u: 10, a2f: 20 }), F(0.22, { t: -14, a1u: 180, a1f: 200, w: 230, a2u: 170, a2f: 190 }), F(0.4, 'R')], act: [0.1, 0.24], dmg: 1.2, kb: 0.4, up: -600, lunge: 140 },
    { f: [F(0.08, { t: 0, a1u: 90, a1f: 90, w: 90 }), F(0.2, { t: 10, a1u: 100, a1f: 110, w: 450 }), F(0.32, { t: 16, a1u: 92, a1f: 92, w: 810 }), F(0.46, { t: 24, a1u: 96, a1f: 96, w: 1030 }), F(0.62, Object.assign({}, READY.scythe, { w: 890 + 180 }))], act: [0.08, 0.44], rehits: [0.2, 0.32], dmg: 1.4, kb: 2.2, heavy: true, fin: true, lunge: 260, soul: true, big: true },
  );
  ATK.spear.combo.push(
    { f: [F(0.05, { t: -4, a1u: 30, a1f: 70, w: 110 }), F(0.09, { t: 14, a1u: 100, a1f: 110, w: 115 }), F(0.13, { t: -4, a1u: 30, a1f: 70, w: 110 }), F(0.17, { t: 14, a1u: 100, a1f: 110, w: 115 }), F(0.21, { t: -4, a1u: 30, a1f: 70, w: 110 }), F(0.25, { t: 16, a1u: 100, a1f: 110, w: 115 }), F(0.38, 'R')], act: [0.06, 0.27], rehits: [0.12, 0.2], dmg: 0.7, kb: 0.5, lunge: 120 },
    { f: [F(0.16, { t: -16, a1u: 175, a1f: 185, w: 170, a2u: 160, a2f: 170, bY: -8 }), F(0.26, { t: 30, a1u: 96, a1f: 96, w: 96, a2u: 82, a2f: 94, l1t: 52, l1s: 12, l2t: -46, l2s: -28 }), F(0.48, { t: 30, a1u: 96, a1f: 96, w: 96, a2u: 82, a2f: 94, l1t: 52, l1s: 12, l2t: -46, l2s: -28 }), F(0.62, 'R')], act: [0.18, 0.34], dmg: 2.6, kb: 2.6, heavy: true, fin: true, lunge: 640, rangeMul: 1.45, big: true },
  );
  // second air strike, built from each weapon's second combo step with airborne legs
  for (const k in ATK) { const src = ATK[k].combo[1]; ATK[k].air2 = Object.assign({}, src, { f: src.f.map(fr => F(fr.t, fr.p === 'R' ? 'R' : Object.assign({}, fr.p, AIRLEG))), lunge: 0, up: -260, dmg: 1.1 }); }
})();

// charged heavy attacks: coil = anticipation pose held while charging; f = release frames
const HEAVY = {
  sword: { name: 'MOON CLEAVER', coil: { t: -18, bY: -4, a1u: 200, a1f: 228, w: 238, a2u: 190, a2f: 220, l1t: 36, l1s: -2, l2t: -24, l2s: -22 },
    f: [F(0.08, { t: 40, a1u: 92, a1f: 70, w: 50, a2u: 84, a2f: 64, l1t: 52, l1s: 16, l2t: -44, l2s: -34 }), F(0.42, { t: 40, a1u: 92, a1f: 70, w: 50, a2u: 84, a2f: 64, l1t: 52, l1s: 16, l2t: -44, l2s: -34 }), F(0.62, 'R')], act: [0.03, 0.14], dmg: 2.4, kb: 2.6, lunge: 520, wave: 'crescent' },
  dual: { name: 'CROSSFANG', coil: { t: -10, a1u: 150, a1f: 200, w: 230, a2u: 150, a2f: 200, w2: 230, l1t: 30, l1s: 4, l2t: -26, l2s: -16 },
    f: [F(0.06, { t: 34, a1u: 60, a1f: 20, w: -20, a2u: 100, a2f: 60, w2: 20, l1t: 56, l1s: 14, l2t: -48, l2s: -30 }), F(0.14, { t: 36, a1u: 100, a1f: 60, w: 20, a2u: 60, a2f: 20, w2: -20, l1t: 56, l1s: 14, l2t: -48, l2s: -30 }), F(0.4, { t: 36, a1u: 100, a1f: 60, w: 20, a2u: 60, a2f: 20, w2: -20, l1t: 56, l1s: 14, l2t: -48, l2s: -30 }), F(0.55, 'R')], act: [0.02, 0.2], rehits: [0.09], dmg: 1.6, kb: 1.4, lunge: 980, dash: true },
  hammer: { name: 'CATACLYSM', coil: { t: -26, bY: -6, a1u: 220, a1f: 228, w: 240, a2u: 212, a2f: 222, l1t: 40, l1s: -6, l2t: -22, l2s: -36 },
    f: [F(0.1, { t: 48, a1u: 98, a1f: 68, w: 48, a2u: 88, a2f: 58, l1t: 56, l1s: 20, l2t: -46, l2s: -36 }), F(0.6, { t: 48, a1u: 98, a1f: 68, w: 48, a2u: 88, a2f: 58, l1t: 56, l1s: 20, l2t: -46, l2s: -36 }), F(0.85, 'R')], act: [0.06, 0.16], dmg: 2.8, kb: 2, lunge: 180, impact: 0.1, quake: true },
  scythe: { name: 'GRIM HARVEST', coil: { t: 16, a1u: -40, a1f: -20, w: -150, a2u: -30, a2f: -10, l1t: 30, l1s: 6, l2t: -30, l2s: -14 },
    f: [F(0.1, { t: 0, a1u: 100, a1f: 110, w: 200 }), F(0.22, { t: -6, a1u: 110, a1f: 120, w: 560 }), F(0.5, Object.assign({}, READY.scythe, { w: 530 }))], act: [0.04, 0.24], rehits: [0.13], dmg: 1.9, kb: -1.2, lunge: 200, rangeMul: 1.3, pull: true },
  spear: { name: 'HEAVEN PIERCER', coil: { t: -14, a1u: 20, a1f: 40, w: 92, a2u: -20, a2f: 20, l1t: 20, l1s: 0, l2t: -30, l2s: -30 },
    f: [F(0.06, { t: 30, a1u: 92, a1f: 92, w: 92, a2u: 76, a2f: 90, l1t: 56, l1s: 14, l2t: -50, l2s: -30 }), F(0.4, { t: 30, a1u: 92, a1f: 92, w: 92, a2u: 76, a2f: 90, l1t: 56, l1s: 14, l2t: -50, l2s: -30 }), F(0.56, 'R')], act: [0.02, 0.18], dmg: 2.3, kb: 2.2, lunge: 820, rangeMul: 1.6, pierce: true },
};
const HEAVY_LVL = [{ t: 0, mul: 1 }, { t: 0.38, mul: 1.5 }, { t: 0.85, mul: 2.1 }, { t: 1.35, mul: 2.9 }];
// plunge (air heavy)
const PLUNGE_UP = { t: -14, a1u: 200, a1f: 220, w: 200, a2u: 190, a2f: 210, w2: 200, l1t: 60, l1s: -10, l2t: 20, l2s: -40 };
const PLUNGE_DOWN = { t: 30, a1u: 70, a1f: 30, w: 10, a2u: 60, a2f: 30, w2: 10, l1t: 40, l1s: -20, l2t: 10, l2s: -40 };
// dodge
const ROLL_POSE = { t: 40, h: 20, a1u: 60, a1f: 120, a2u: 60, a2f: 120, l1t: 110, l1s: -30, l2t: 100, l2s: -40, bY: -10 };
const BACKSTEP_POSE = { t: -20, h: -6, l1t: -20, l1s: -40, l2t: 30, l2s: -10 };
// executions: frames on a slowed timeline, impact times, title
const EXEC = {
  sword: { name: 'BEHEADING', dist: 62, f: [F(0.3, { bY: -6, t: -22, a1u: 212, a1f: 236, w: 250, a2u: 202, a2f: 226, l1t: 36, l1s: -2, l2t: -24, l2s: -22 }), F(0.42, { t: 44, a1u: 94, a1f: 70, w: 44, a2u: 84, a2f: 62, l1t: 54, l1s: 18, l2t: -46, l2s: -34 }), F(0.95, { t: 44, a1u: 94, a1f: 70, w: 44, a2u: 84, a2f: 62, l1t: 54, l1s: 18, l2t: -46, l2s: -34 }), F(1.05, FLOURISH), F(1.2, 'R')], hits: [0.4], fx: 'behead' },
  dual: { name: 'THROAT RIP', dist: 40, f: [F(0.18, { t: 20, a1u: 150, a1f: 190, w: 220, a2u: 150, a2f: 190, w2: 220, l1t: 60, l1s: -20, l2t: 30, l2s: -50 }), F(0.3, { t: 40, a1u: 60, a1f: 30, w: 10, a2u: 70, a2f: 30, w2: 10, l1t: 50, l1s: 10, l2t: -40, l2s: -30 }), F(0.42, { t: 20, a1u: 140, a1f: 180, w: 200, a2u: 140, a2f: 180, w2: 200 }), F(0.52, { t: 44, a1u: 70, a1f: 30, w: 0, a2u: 60, a2f: 20, w2: 0, l1t: 54, l1s: 14, l2t: -46, l2s: -30 }), F(0.95, { t: 44, a1u: 70, a1f: 30, w: 0, a2u: 60, a2f: 20, w2: 0 }), F(1.1, 'R')], hits: [0.3, 0.52], fx: 'rip' },
  hammer: { name: 'SKULL CRUSHER', dist: 70, f: [F(0.36, { bY: -12, t: -28, a1u: 222, a1f: 230, w: 242, a2u: 214, a2f: 224, l1t: 42, l1s: -8, l2t: -22, l2s: -38 }), F(0.47, { t: 50, a1u: 98, a1f: 66, w: 46, a2u: 88, a2f: 56, l1t: 56, l1s: 20, l2t: -46, l2s: -36 }), F(1.0, { t: 50, a1u: 98, a1f: 66, w: 46, a2u: 88, a2f: 56, l1t: 56, l1s: 20, l2t: -46, l2s: -36 }), F(1.25, 'R')], hits: [0.46], fx: 'crush' },
  scythe: { name: 'SOUL HARVEST', dist: 80, f: [F(0.22, { t: 10, a1u: 110, a1f: 130, w: 250, a2u: 100, a2f: 120 }), F(0.4, { t: 4, a1u: 116, a1f: 136, w: 262, a2u: 106, a2f: 126 }), F(0.5, { t: -12, a1u: 50, a1f: 10, w: -70, a2u: 40, a2f: 20, l1t: 20, l1s: 4, l2t: -30, l2s: -14 }), F(0.95, { t: -12, a1u: 50, a1f: 10, w: -70, a2u: 40, a2f: 20 }), F(1.1, 'R')], hits: [0.49], fx: 'soul' },
  spear: { name: 'IMPALEMENT', dist: 74, f: [F(0.14, { t: -14, a1u: 20, a1f: 40, w: 92, a2u: -20, a2f: 20 }), F(0.24, { t: 26, a1u: 92, a1f: 92, w: 92, a2u: 76, a2f: 90, l1t: 50, l1s: 12, l2t: -44, l2s: -28 }), F(0.62, { t: -10, a1u: 160, a1f: 168, w: 150, a2u: 150, a2f: 160, l1t: 20, l1s: 0, l2t: -24, l2s: -16 }), F(0.78, { t: 34, a1u: 80, a1f: 60, w: 40, a2u: 70, a2f: 50, l1t: 50, l1s: 14, l2t: -44, l2s: -30 }), F(1.0, { t: 34, a1u: 80, a1f: 60, w: 40, a2u: 70, a2f: 50 }), F(1.15, 'R')], hits: [0.24, 0.78], fx: 'impale', lift: [0.26, 0.76] },
};

// relics change the player's look
const _outfitStyleBase = outfitStyle;
outfitStyle = function () {
  let s;
  const relicOut = RELICS.find(r => r.id === Save.d.outfit && r.kind === 'outfit');
  if (relicOut && Save.d.relics.includes(relicOut.id)) { const c = relicOut.colors; const ex = Save.d.extras; s = { player: true, head: 'human', skin: c.skin, cloak: c.cloak, armor: c.armor, cloth: shade(c.armor, -0.25), hood: c.hood, helm: c.helm, beak: c.beak, skullmask: c.skullmask, glow: c.glow, scarf: '#2a0004', pants: shade(c.cloak, 0.1), boot: '#1a1010', glove: '#1a1010', sleeve: shade(c.cloak, 0.15), longCape: ex.includes('ex_cape'), halo: ex.includes('ex_halo'), haloCol: '#111', eyesGlow: ex.includes('ex_eyes') }; }
  else s = _outfitStyleBase();
  const ex = Save.d.extras, own = (id) => ex.includes(id) && Save.d.relics.includes(id);
  if (own('relic_crown')) s.crownTop = true;
  if (own('relic_wings')) s.wings = 'demon';
  if (own('relic_halo')) { s.halo = true; s.haloCol = '#ffd23a'; s.haloBroken = true; }
  return s;
};
