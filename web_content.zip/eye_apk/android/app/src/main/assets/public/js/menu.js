// ===== MAIN MENU: the giant eye + panels =====
const Menu = (() => {
  const M = {};
  let cv, c, w = 0, h = 0, dpr = 1, running = false, last = 0, T = 0;
  const eye = { x: 0, y: 0, R: 100, lx: 0, ly: 0, tx: 0, ty: 0, open: 1, openT: 1, blinkT: 0, nextBlink: 3, blinking: 0, pupil: 0.36, pupilT: 0.36, mode: 'follow', modeT: 0, nextStare: 14, twitch: 0, tw: [0, 0], idleNext: 0, lastPtr: -10, focus: null, back: false, backT: 0, red: 0, expr: 'neutral', exprT: 0, ek: { top: 1, bot: 1, tilt: 0 }, vanish: null, nextVanish: 40, alpha: 1, tear: 0, sx: 0, sy: 0, sacc: 0 };
  let nextMsg = 4, msgBusy = false, shadows = [], motes = [], details = [], ptr = { x: -1, y: -1 }, menuAcc = 0, onMenuFor = 0;
  const MSGS = ["Why are you still here?", "You think you are brave?", "PLAY.", "Are you a chicken?", "I can see you.", "Don't leave me alone.", "You shouldn't have opened this.", "Your little sword won't save you."];
  const BACK_MSGS = ["YOU'RE BACK.", "I remember you.", "That didn't hurt, did it?", "You came back to me.", "We are not finished."];

  M.init = () => {
    cv = document.getElementById('eyeCanvas'); c = cv.getContext('2d');
    window.addEventListener('resize', resize); resize();
    const scr = document.getElementById('scr-menu');
    const mv = (x, y) => { ptr.x = x; ptr.y = y; eye.lastPtr = T; };
    scr.addEventListener('pointermove', e => mv(e.clientX, e.clientY));
    scr.addEventListener('pointerdown', e => { mv(e.clientX, e.clientY); eye.pupilT = 0.22; setTimeout(() => eye.pupilT = 0.36, 400); if (eye.vanish) { vanishTap(e.clientX, e.clientY); return; } if (Math.hypot(e.clientX - eye.x, e.clientY - eye.y) < eye.R * 1.2) poke(); });
    scr.addEventListener('touchmove', e => { const t = e.touches[0]; if (t) mv(t.clientX, t.clientY); }, { passive: true });
    document.querySelectorAll('#scr-menu .mbtn').forEach(b => {
      b.addEventListener('pointerenter', () => { const r = b.getBoundingClientRect(); eye.focus = { x: r.left + r.width / 2, y: r.top + r.height / 2, t: T }; });
      b.addEventListener('pointerleave', () => { eye.focus = null; });
    });
    for (let i = 0; i < 3; i++) shadows.push(newShadow(true));
    for (let i = 0; i < 60; i++) motes.push({ x: Math.random(), y: Math.random(), vx: rnd(-0.004, 0.004), vy: rnd(-0.01, -0.002), r: rnd(0.5, 2), a: rnd(0.1, 0.5) });
  };
  function newShadow(init) { return { x: init ? Math.random() : (Math.random() < 0.5 ? -0.2 : 1.2), dir: Math.random() < 0.5 ? 1 : -1, sp: rnd(0.006, 0.018), s: rnd(0.6, 1.1), a: rnd(0.25, 0.5), ph: Math.random() * 6 }; }
  function resize() {
    if (!cv) return; dpr = Math.min(window.devicePixelRatio || 1, 2); w = window.innerWidth; h = window.innerHeight;
    cv.width = w * dpr; cv.height = h * dpr; cv.style.width = w + 'px'; cv.style.height = h + 'px';
    const portrait = h > w;
    eye.R = portrait ? Math.min(w * 0.3, h * 0.17) : Math.min(h * 0.25, w * 0.16);
    eye.x = portrait ? w / 2 : w * 0.47; eye.y = portrait ? h * 0.33 : h * 0.47;
  }
  function poke() {
    const m = Save.d.mem; m.pokes = (m.pokes || 0) + 1; Save.save(); if (m.pokes >= 20 && M.onAch) M.onAch('poke20');
    eye.twitch = 0.5; AudioSys.play('eyeSquelch'); eye.blinking = 1; eye.blinkT = 0; pokeRun = (T - lastPoke < 1.2) ? pokeRun + 1 : 1; lastPoke = T;
    if (pokeRun >= 5) { setExpr('angry', 5); say(pokeRun >= 8 ? 'STOP.' : 'I said stop.', pokeRun >= 8); eye.red = Math.min(1, eye.red + 0.15); return; }
    setExpr(Math.random() < 0.5 ? 'angry' : 'amused', 2.5);
    if (Math.random() < 0.5) say(['Don\'t touch me.', 'That hurt.', 'Again. Do it again.', 'I felt that.', m.pokes > 40 ? `That is ${m.pokes} times now.` : 'Careful.'][Math.random() * 5 | 0]);
  }
  let pokeRun = 0, lastPoke = -9;
  function setExpr(x, dur) { eye.expr = x; eye.exprT = dur; }
  M.setExpr = setExpr;
  // ---- THE EYE'S MIND: lines built from what you actually did ----
  function memoryLines() {
    const d = Save.d, m = d.mem, L = [];
    const by = Object.entries(m.killedBy || {}).sort((a, b) => b[1] - a[1])[0];
    if (d.deaths > 0) L.push(`You have died ${d.deaths} time${d.deaths > 1 ? 's' : ''}. I counted.`);
    if (by && by[1] >= 2) L.push(`The ${by[0]} keeps killing you.`);
    if (m.lastResult === 'died' && m.killedByLast) L.push(`The ${m.killedByLast} got you last time.`);
    if (m.lastResult === 'won' && m.lastBoss && BOSSES[m.lastBoss]) L.push(`You killed ${BOSSES[m.lastBoss].name}. I felt it.`);
    if ((m.bestCombo || 0) >= 20) L.push(`${m.bestCombo} hits. Show-off.`);
    if (d.executions > 0) L.push(d.executions >= 20 ? `${d.executions} executions. You enjoy it.` : 'I saw what you did to them.');
    if (d.perfectDodges >= 5) L.push('You dodge like you know what is coming.');
    if (m.switches > 30) L.push('Can\'t pick a weapon?');
    if ((m.pokes || 0) > 15) L.push('Stop poking me.');
    if (d.crashes > 0) L.push('Did you think it crashed?');
    if (d.kills > 200) L.push(`${d.kills} dead. And you call me the monster.`);
    if (d.percy === 'alive') L.push('Your dog doesn\'t like me.', 'Keep that dog away from me.');
    if (d.percy === 'dead') L.push('I miss the dog. No, I don\'t.', 'Percy is buried behind you.');
    if (d.lastVisit && Date.now() - d.lastVisit > 86400000) L.push('You were gone a long time.');
    const hr = new Date().getHours(); if (hr >= 0 && hr < 5) L.push(`It is ${hr}:${String(new Date().getMinutes()).padStart(2, '0')}. Why are you awake?`);
    if (d.cleared.includes(9)) L.push('You blinded me once. I grew back.');
    return L;
  }
  let memPool = [];

  // the eye sometimes leaves. it comes back somewhere else.
  const SPOTS = () => [[0.08, 0.12], [0.92, 0.1], [0.06, 0.88], [0.94, 0.86], [0.5, 0.06], [0.78, 0.5]];
  function updateVanish(dt) {
    eye.nextVanish -= dt;
    if (!eye.vanish && eye.nextVanish <= 0 && !msgBusy && document.getElementById('panel').classList.contains('hidden')) { eye.nextVanish = rnd(45, 100); if (Math.random() < 0.55) { eye.vanish = { ph: 'closing', t: 0 }; AudioSys.play('blink'); } }
    const v = eye.vanish; if (!v) { eye.alpha += (1 - eye.alpha) * Math.min(1, dt * 3); return; }
    v.t += dt;
    if (v.ph === 'closing') { eye.open *= 0.85; eye.alpha = Math.max(0, 1 - v.t / 0.8); if (v.t > 0.9) { v.ph = 'gone'; v.t = 0; v.dur = rnd(3, 6); AudioSys.play('whisper', 0.6); } }
    else if (v.ph === 'gone') { eye.alpha = 0; if (v.t > v.dur) { const sp = SPOTS()[Math.random() * 6 | 0]; v.ph = 'elsewhere'; v.t = 0; v.x = sp[0] * w; v.y = sp[1] * h; v.dur = rnd(3.5, 6); AudioSys.play('eyeSquelch'); } }
    else if (v.ph === 'elsewhere') { if (v.t > v.dur) { v.ph = 'return'; v.t = 0; } }
    else if (v.ph === 'return') { eye.alpha = Math.min(1, v.t / 0.8); if (v.t > 0.9) { eye.vanish = null; eye.blinking = 1; eye.blinkT = 0; if (Math.random() < 0.6) say(['Did you miss me?', 'I was behind you.', 'Looking for me?'][Math.random() * 3 | 0]); } }
  }
  function vanishTap(x, y) {
    const v = eye.vanish;
    if (v.ph === 'gone' && Math.hypot(x - eye.x, y - eye.y) < eye.R * 1.2) { M.onAch && M.onAch('vanish'); say("I'm not there.", true); v.t = v.dur; }
    if (v.ph === 'elsewhere' && Math.hypot(x - v.x, y - v.y) < Math.max(40, eye.R * 0.4)) { M.onAch && M.onAch('found'); setExpr('angry', 3); say('Found me.', true); AudioSys.play('eyeSquelch'); v.ph = 'return'; v.t = 0; }
  }
  function rareEvent() {
    if (!running || eye.vanish) return; const r = Math.random();
    if (r < 0.3) { eye.tear = 0.01; setExpr('sad', 8); say('Why do you keep leaving?'); }
    else if (r < 0.55) { for (let i = 0; i < 26; i++) details.push({ type: 'eyes', x: Math.random(), y: rnd(0.08, 0.95), t: -rnd(0, 1.5), life: rnd(3, 5), side: 1 }); AudioSys.play('whisper', 2); say('We are all watching.', true); }
    else if (r < 0.8) { const btns = [...document.querySelectorAll('#scr-menu .mbtn')]; const b = btns[1 + (Math.random() * (btns.length - 1) | 0)]; if (b) { const keep = b.textContent; b.textContent = ['RUN', 'BEHIND YOU', 'DON\'T', 'I SEE YOU'][Math.random() * 4 | 0]; b.classList.add('glitched'); AudioSys.play('glitch', 0.3); setTimeout(() => { b.textContent = keep; b.classList.remove('glitched'); }, 1100); } }
    else { eye.mode = 'stare'; eye.modeT = 9; eye.pupilT = 0.12; setExpr('angry', 9); say('Do not blink.', true); }
  }
  M.rareEvent = rareEvent;
  M.vanishNow = () => { eye.nextVanish = 0; eye.vanish = null; };
  M.show = (opts = {}) => {
    document.getElementById('menuSouls').textContent = '◈ ' + Save.d.souls;
    Save.d.visits++; Save.d.lastVisit = Date.now(); Save.save();
    running = true; last = performance.now(); onMenuFor = 0;
    eye.back = !!opts.back; eye.red = opts.back ? 1 : Math.min(1, Save.d.crashes * 0.35);
    document.getElementById('scr-menu').classList.toggle('back', eye.back);
    document.querySelector('#scr-menu .menu-sub').textContent = eye.back ? 'it remembers you' : (Save.d.crashes ? 'it remembers you' : 'a hack-and-slash nightmare');
    if (eye.back) { eye.mode = 'stare'; eye.modeT = 7; eye.pupilT = 0.18; eye.open = 1.25; setTimeout(() => say("YOU'RE BACK.", true), 900); nextMsg = 9; }
    else { nextMsg = rnd(3, 6); if (Save.d.crashes > 0 && Math.random() < 0.5) setTimeout(() => say(BACK_MSGS[1 + Math.random() * 4 | 0]), 2500); }
    memPool = memoryLines(); eye.alpha = 1; eye.vanish = null; eye.nextVanish = rnd(30, 70); eye.expr = 'neutral'; eye.tear = 0;
    if (!eye.back && memPool.length && Math.random() < 0.6) setTimeout(() => { if (running) say(memPool[Math.random() * memPool.length | 0]); }, 3200);
    if (Math.random() < 0.08) setTimeout(() => rareEvent(), rnd(8000, 20000));
    AudioSys.music({ root: 33, scale: 'loc', tempo: 52, wave: 'sawtooth', bright: 260, lead: 'sine', notes: 0.12, heart: true, whispers: true, wind: 0.08, menu: true });
    requestAnimationFrame(loop);
  };
  M.hide = () => { running = false; };

  function say(text, big) {
    const el = document.getElementById('eyeMsg'); if (msgBusy && !big) return; msgBusy = true;
    el.className = 'eye-msg' + (big ? ' big' : ''); el.innerHTML = '';
    [...text].forEach((ch, i) => { const s = document.createElement('span'); s.textContent = ch === ' ' ? '\u00a0' : ch; s.style.animationDelay = (i * 0.055) + 's'; s.style.setProperty('--jx', rnd(-4, 4).toFixed(1) + 'px'); s.style.setProperty('--jy', rnd(-6, 6).toFixed(1) + 'px'); el.appendChild(s); });
    el.classList.add('show'); AudioSys.play('message'); eye.twitch = 0.3; eye.pupilT = 0.2;
    const dur = 2600 + text.length * 70;
    setTimeout(() => { el.classList.add('melt'); }, dur);
    setTimeout(() => { el.className = 'eye-msg'; el.innerHTML = ''; msgBusy = false; eye.pupilT = 0.36; }, dur + 1200);
  }
  M.say = say;

  function loop(now) {
    if (!running) return;
    const dt = Math.min(0.05, (now - last) / 1000); last = now; T += dt;
    update(dt); draw(); requestAnimationFrame(loop);
  }
  function update(dt) {
    onMenuFor += dt; menuAcc += dt; if (menuAcc > 5) { Save.d.menuTime += menuAcc; menuAcc = 0; Save.save(); }
    if (onMenuFor > 60 && M.onAch) M.onAch('menu5');
    // gaze
    eye.modeT -= dt;
    if (eye.mode === 'stare') { eye.tx = 0; eye.ty = 0; if (eye.modeT <= 0) { eye.mode = 'follow'; eye.open = 1; eye.pupilT = 0.36; } }
    else {
      eye.nextStare -= dt;
      if (eye.nextStare <= 0) { eye.mode = 'stare'; eye.modeT = rnd(2.5, 4.5); eye.nextStare = rnd(14, 26); eye.pupilT = 0.2; if (Math.random() < 0.5) say('I can see you.'); }
      const idle = T - eye.lastPtr > 3 && !eye.focus;
      let px = ptr.x, py = ptr.y;
      if (eye.focus) { px = eye.focus.x; py = eye.focus.y; }
      if (idle || ptr.x < 0) {
        eye.idleNext -= dt; if (eye.idleNext <= 0) { eye.idleNext = rnd(0.6, 2.2); const a = Math.random() * 7, r = Math.random() < 0.3 ? 0 : rnd(0.4, 1); eye.tx = Math.cos(a) * r; eye.ty = Math.sin(a) * r * 0.7; }
      } else {
        const dx = (px - eye.x) / (w * 0.42), dy = (py - eye.y) / (h * 0.42); const d = Math.hypot(dx, dy); const k = d > 1 ? 1 / d : 1;
        eye.tx = dx * k; eye.ty = dy * k;
        const near = Math.hypot(px - eye.x, py - eye.y) / eye.R; eye.pupilT = near < 2 ? 0.24 : 0.36;
      }
    }
    const sp = eye.mode === 'stare' ? 10 : 9;
    eye.lx += (eye.tx + eye.sx - eye.lx) * Math.min(1, dt * sp); eye.ly += (eye.ty + eye.sy - eye.ly) * Math.min(1, dt * sp);
    eye.pupil += (eye.pupilT - eye.pupil) * Math.min(1, dt * 4);
    // blink
    eye.nextBlink -= dt; if (eye.nextBlink <= 0 && !eye.blinking) { eye.blinking = 1; eye.blinkT = 0; eye.nextBlink = Math.random() < 0.2 ? 0.35 : rnd(2.5, 7); if (Math.random() < 0.5) AudioSys.play('blink'); }
    if (eye.blinking) { eye.blinkT += dt; if (eye.blinkT > 0.32) eye.blinking = 0; }
    const bk = eye.blinking ? (eye.blinkT < 0.13 ? eye.blinkT / 0.13 : 1 - (eye.blinkT - 0.13) / 0.19) : 0;
    const baseOpen = eye.mode === 'stare' ? 1.2 : 1; eye.openT = baseOpen * (1 - clamp(bk, 0, 1));
    eye.open += (eye.openT - eye.open) * Math.min(1, dt * 30);
    // twitch
    if (Math.random() < dt * 0.25) eye.twitch = rnd(0.15, 0.35);
    if (eye.twitch > 0) { eye.twitch -= dt; eye.tw = [rnd(-1, 1) * eye.R * 0.03, rnd(-1, 1) * eye.R * 0.02]; } else eye.tw = [0, 0];
    // messages
    nextMsg -= dt; if (nextMsg <= 0) { nextMsg = rnd(6, 13); const pool = eye.back || Save.d.crashes ? MSGS.concat(BACK_MSGS.slice(1)) : MSGS; if (eye.vanish) return; if (memPool.length && Math.random() < 0.4) say(memPool[Math.random() * memPool.length | 0]); else say(pool[Math.random() * pool.length | 0]); if (Math.random() < 0.3) setExpr(['amused', 'angry', 'sad'][Math.random() * 3 | 0], 3); }
    // expressions decay; vanish / reappear; saccades; rare events
    eye.exprT -= dt; if (eye.exprT <= 0) { if (Save.d.cleared.includes(9) && Math.random() < 0.002) setExpr('fear', 2.5); else if (eye.exprT < -1) eye.expr = 'neutral'; }
    const tgt = { neutral: [1, 1, 0], angry: [0.62, 1, 0.08], amused: [0.9, 0.62, -0.02], sad: [0.82, 1, -0.12], fear: [1.25, 1.1, 0] }[eye.expr] || [1, 1, 0];
    eye.ek.top += (tgt[0] - eye.ek.top) * Math.min(1, dt * 6); eye.ek.bot += (tgt[1] - eye.ek.bot) * Math.min(1, dt * 6); eye.ek.tilt += (tgt[2] - eye.ek.tilt) * Math.min(1, dt * 6);
    if (eye.expr === 'fear') { eye.pupilT = 0.55; eye.tw = [rnd(-1, 1) * 2, rnd(-1, 1) * 2]; } else if (eye.expr === 'angry') eye.pupilT = 0.2;
    eye.sacc -= dt; if (eye.sacc <= 0) { eye.sacc = rnd(0.15, 0.6); eye.sx = rnd(-0.04, 0.04); eye.sy = rnd(-0.03, 0.03); }
    if (eye.tear > 0) eye.tear = Math.min(1.6, eye.tear + dt * 0.12);
    updateVanish(dt);
    // whispers + heartbeat
    if (Math.random() < dt * 0.08) AudioSys.play('whisper', rnd(1, 2));
    // shadows
    shadows.forEach((s, i) => { s.x += s.dir * s.sp * dt; if (s.x < -0.3 || s.x > 1.3) shadows[i] = newShadow(false); });
    motes.forEach(m => { m.x += m.vx * dt; m.y += m.vy * dt; if (m.y < -0.02) { m.y = 1.02; m.x = Math.random(); } });
    // disturbing details
    if (Math.random() < dt * 0.12) details.push({ type: ['eyes', 'eyes', 'hand', 'face', 'eyes'][Math.random() * 5 | 0], x: Math.random(), y: rnd(0.15, 0.9), t: 0, life: rnd(1.5, 3), side: Math.random() < 0.5 ? -1 : 1 });
    details.forEach(d => d.t += dt); details = details.filter(d => d.t < d.life);
    // parallax background
    const bg = document.getElementById('menubg'); if (bg) { const ox = eye.lx * -14, oy = eye.ly * -10; bg.style.transform = `translate(${ox}px, ${oy}px) scale(1.08)`; }
  }

  function draw() {
    c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, w, h);
    const flick = 0.5 + 0.5 * Math.sin(T * 7.3) * Math.sin(T * 3.1 + 1) * Math.sin(T * 13.7);
    // candle-light breathing darkness
    c.fillStyle = `rgba(0,0,0,${0.35 + flick * 0.12})`; c.fillRect(0, 0, w, h);
    // moving shadows (figures passing behind)
    shadows.forEach(s => {
      const x = s.x * w, base = h * 0.92, H = h * 0.62 * s.s; c.save(); c.globalAlpha = s.a; c.filter = 'blur(6px)'; c.fillStyle = '#000';
      const bob = Math.sin(T * 2 + s.ph) * 4; c.beginPath(); c.ellipse(x, base - H + bob, H * 0.07, H * 0.09, 0, 0, 7); c.fill();
      c.beginPath(); c.moveTo(x - H * 0.11, base - H * 0.86 + bob); c.quadraticCurveTo(x - H * 0.16, base - H * 0.4, x - H * 0.12, base); c.lineTo(x + H * 0.12, base); c.quadraticCurveTo(x + H * 0.16, base - H * 0.4, x + H * 0.11, base - H * 0.86 + bob); c.fill();
      // long arms
      c.fillRect(x - H * 0.15, base - H * 0.8 + bob, H * 0.03, H * 0.55); c.fillRect(x + H * 0.12, base - H * 0.8 + bob, H * 0.03, H * 0.55);
      c.restore(); c.filter = 'none';
    });
    // disturbing details
    details.forEach(d => {
      const a = Math.sin(clamp(d.t / d.life, 0, 1) * Math.PI); const x = d.x * w, y = d.y * h;
      if (Math.hypot(x - eye.x, y - eye.y) < eye.R * 2.2 && d.type !== 'hand') return;
      c.save(); c.globalAlpha = a * 0.75;
      if (d.type === 'eyes') { const open = d.t > 0.2 && d.t < d.life - 0.3 && Math.sin(d.t * 2) > -0.9 ? 1 : 0.15; [-1, 1].forEach(s => { c.fillStyle = '#ff2a1a'; c.shadowColor = '#f00'; c.shadowBlur = 10; c.beginPath(); c.ellipse(x + s * 9, y, 4, 2.4 * open, 0, 0, 7); c.fill(); }); }
      if (d.type === 'hand') { const hx = d.side < 0 ? 0 : w, k = a * 70, hy = clamp(y, h * 0.55, h * 0.9); c.translate(hx, hy); c.scale(-d.side, 1); c.fillStyle = '#0c0606'; c.beginPath(); c.moveTo(0, -18); c.lineTo(k * 0.6, -14); for (let i = 0; i < 4; i++) { c.lineTo(k + 14 + i * 2, -14 + i * 8); c.lineTo(k * 0.7, -10 + i * 8); } c.lineTo(0, 22); c.fill(); }
      if (d.type === 'face') { c.globalAlpha = a * 0.16; c.fillStyle = '#d8d0c8'; c.filter = 'blur(2px)'; c.beginPath(); c.ellipse(x, y, 22, 30, 0, 0, 7); c.fill(); c.fillStyle = '#000'; c.beginPath(); c.ellipse(x - 8, y - 4, 5, 7, 0, 0, 7); c.ellipse(x + 8, y - 4, 5, 7, 0, 0, 7); c.ellipse(x, y + 14, 4, 8, 0, 0, 7); c.fill(); c.filter = 'none'; }
      c.restore();
    });
    if (eye.alpha < 0.99) { c.save(); c.translate(eye.x, eye.y); const g2 = c.createRadialGradient(0, 0, 0, 0, 0, eye.R * 1.6); g2.addColorStop(0, 'rgba(0,0,0,0.95)'); g2.addColorStop(0.6, 'rgba(20,4,4,0.8)'); g2.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g2; c.beginPath(); c.ellipse(0, 0, eye.R * 1.6, eye.R * 0.8, 0, 0, 7); c.fill(); c.restore(); }
    if (eye.alpha > 0.01) { c.save(); c.globalAlpha = eye.alpha; drawEye(); c.restore(); }
    if (eye.vanish && eye.vanish.ph === 'elsewhere') drawSmallEye(eye.vanish.x, eye.vanish.y, Math.max(16, eye.R * 0.22));
    // dust motes
    c.fillStyle = 'rgba(255,220,180,1)'; motes.forEach(m => { c.globalAlpha = m.a * (0.6 + flick * 0.4); c.beginPath(); c.arc(m.x * w, m.y * h, m.r, 0, 7); c.fill(); }); c.globalAlpha = 1;
    // vignette
    const vg = c.createRadialGradient(eye.x, eye.y, eye.R * 1.2, w / 2, h / 2, Math.max(w, h) * 0.75); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, `rgba(0,0,0,${0.82 + flick * 0.08})`); c.fillStyle = vg; c.fillRect(0, 0, w, h);
    if (eye.back) { c.fillStyle = `rgba(120,0,0,${0.08 + 0.05 * Math.sin(T * 2)})`; c.fillRect(0, 0, w, h); }
  }

  function lidPath(R, open, up) {
    // returns y of lid at normalized x in [-1,1]
    const W2 = R * 1.55; const top = -R * 1.05 * open, bot = R * (0.25 + 0.62 * Math.min(1, open));
    return { W2, top, bot };
  }
  function drawSmallEye(x, y, r) {
    const dx = clamp((ptr.x - x) / 300, -1, 1) * r * 0.35, dy = clamp((ptr.y - y) / 300, -1, 1) * r * 0.2; const bl = Math.sin(T * 1.3) > 0.97 ? 0.1 : 1;
    c.save(); c.translate(x, y); const g = c.createRadialGradient(0, 0, r * 0.5, 0, 0, r * 2.4); g.addColorStop(0, 'rgba(60,16,16,0.9)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.beginPath(); c.arc(0, 0, r * 2.4, 0, 7); c.fill();
    c.beginPath(); c.ellipse(0, 0, r * 1.4, r * 0.75 * bl, 0, 0, 7); c.save(); c.clip(); c.fillStyle = '#e8dccb'; c.fillRect(-r * 2, -r, r * 4, r * 2); c.fillStyle = '#8a1010'; c.beginPath(); c.arc(dx, dy, r * 0.5, 0, 7); c.fill(); c.fillStyle = '#000'; c.beginPath(); c.arc(dx, dy, r * 0.22, 0, 7); c.fill(); c.restore();
    c.strokeStyle = '#2a0808'; c.lineWidth = 2; c.beginPath(); c.ellipse(0, 0, r * 1.4, r * 0.75 * bl, 0, 0, 7); c.stroke(); c.restore();
  }
  function drawEye() {
    const R = eye.R; const x = eye.x + eye.tw[0], y = eye.y + eye.tw[1]; const o = clamp(eye.open, 0, 1.3);
    const lp = lidPath(R, o); const W2 = lp.W2, top = lp.top * eye.ek.top, bot = lp.bot * eye.ek.bot;
    c.save(); c.translate(x, y); c.rotate(eye.ek.tilt * 0.5);
    if (eye.tear > 0) { const ty = R * 0.3 + eye.tear * R * 1.1; c.strokeStyle = 'rgba(140,0,10,0.85)'; c.lineWidth = R * 0.04; c.beginPath(); c.moveTo(W2 * 0.55, R * 0.3); c.quadraticCurveTo(W2 * 0.6, (R * 0.3 + ty) / 2, W2 * 0.57, ty); c.stroke(); c.fillStyle = '#8a0010'; c.beginPath(); c.ellipse(W2 * 0.57, ty, R * 0.04, R * 0.06, 0, 0, 7); c.fill(); }
    // socket flesh
    let g = c.createRadialGradient(0, 0, R * 0.8, 0, 0, R * 2.6); g.addColorStop(0, 'rgba(70,28,26,0.95)'); g.addColorStop(0.45, 'rgba(40,14,14,0.75)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.beginPath(); c.ellipse(0, 0, R * 2.6, R * 1.9, 0, 0, 7); c.fill();
    // wrinkles
    c.strokeStyle = 'rgba(10,2,2,0.45)'; c.lineWidth = Math.max(1, R * 0.012);
    for (let i = 0; i < 7; i++) { const k = 1.15 + i * 0.13; c.beginPath(); c.moveTo(-W2 * k * 0.9, -R * 0.1 * k); c.quadraticCurveTo(0, -R * (0.95 + i * 0.12) - (o * R * 0.12), W2 * k * 0.9, -R * 0.08 * k); c.stroke(); }
    for (let i = 0; i < 4; i++) { const k = 1.1 + i * 0.12; c.beginPath(); c.moveTo(-W2 * k * 0.85, R * 0.15); c.quadraticCurveTo(0, R * (0.85 + i * 0.13), W2 * k * 0.85, R * 0.15); c.stroke(); }
    // opening
    const open = () => { c.beginPath(); c.moveTo(-W2, 0); c.bezierCurveTo(-W2 * 0.5, top * 1.25, W2 * 0.45, top * 1.25, W2, -R * 0.05); c.bezierCurveTo(W2 * 0.45, bot * 1.2, -W2 * 0.5, bot * 1.2, -W2, 0); c.closePath(); };
    if (o > 0.03) {
      c.save(); open(); c.clip();
      // sclera
      const bx = eye.lx * R * 0.12, by = eye.ly * R * 0.08;
      g = c.createRadialGradient(bx - R * 0.2, by - R * 0.25, R * 0.1, bx, by, R * 1.6); g.addColorStop(0, '#f3ebdf'); g.addColorStop(0.5, '#ddcfc0'); g.addColorStop(0.85, '#9a7468'); g.addColorStop(1, '#4a2a26'); c.fillStyle = g; c.fillRect(-W2, -R * 1.5, W2 * 2, R * 3);
      // redness at corners
      [-1, 1].forEach(s => { const rg = c.createRadialGradient(s * W2 * 0.9, 0, 0, s * W2 * 0.9, 0, R * 0.8); rg.addColorStop(0, `rgba(190,40,50,${0.55 + eye.red * 0.3})`); rg.addColorStop(1, 'rgba(190,40,50,0)'); c.fillStyle = rg; c.fillRect(-W2, -R * 1.5, W2 * 2, R * 3); });
      c.save(); c.translate(bx, by); EyeArt.drawVeins(c, R * 1.45, 0.8 + eye.red * 0.6); c.restore();
      // iris
      const ix = eye.lx * R * 0.72, iy = eye.ly * R * 0.45; const ir = R * 0.5;
      c.save(); c.translate(ix, iy); c.scale(1 - Math.abs(eye.lx) * 0.2, 1 - Math.abs(eye.ly) * 0.15);
      const col = eye.red > 0.6 ? ['#3a0000', '#9a0a0a', '#ff4a2a'] : ['#2a1404', '#8a4a10', '#e0a040'];
      // iris shadow ring
      c.fillStyle = 'rgba(0,0,0,0.35)'; c.beginPath(); c.arc(0, 0, ir * 1.08, 0, 7); c.fill();
      EyeArt.drawIris(c, 0, 0, ir, eye.pupil, T, col);
      c.restore();
      // lid shadow on ball
      g = c.createLinearGradient(0, top, 0, top + R * 0.7); g.addColorStop(0, 'rgba(20,0,0,0.75)'); g.addColorStop(1, 'rgba(20,0,0,0)'); c.fillStyle = g; c.fillRect(-W2, top - R * 0.2, W2 * 2, R * 1.1);
      g = c.createLinearGradient(0, bot, 0, bot - R * 0.35); g.addColorStop(0, 'rgba(40,0,0,0.5)'); g.addColorStop(1, 'rgba(40,0,0,0)'); c.fillStyle = g; c.fillRect(-W2, bot - R * 0.4, W2 * 2, R * 0.5);
      // window reflection (moonlight)
      c.fillStyle = 'rgba(230,240,255,0.55)'; const rx = -R * 0.42 + eye.lx * R * 0.1, ry = -R * 0.36 + eye.ly * R * 0.06;
      c.save(); c.translate(rx, ry); c.rotate(-0.2); c.beginPath(); c.roundRect ? c.roundRect(0, 0, R * 0.2, R * 0.26, R * 0.05) : c.rect(0, 0, R * 0.2, R * 0.26); c.fill(); c.fillStyle = 'rgba(40,20,20,0.5)'; c.fillRect(R * 0.09, 0, R * 0.02, R * 0.26); c.fillRect(0, R * 0.12, R * 0.2, R * 0.02); c.restore();
      // wet edge
      c.restore();
      c.strokeStyle = 'rgba(255,200,190,0.35)'; c.lineWidth = R * 0.03; c.beginPath(); c.moveTo(-W2 * 0.85, R * 0.04); c.bezierCurveTo(-W2 * 0.5, bot * 1.1, W2 * 0.45, bot * 1.1, W2 * 0.9, -R * 0.02); c.stroke();
    }
    // upper lid skin
    const skin = eye.back ? '#5a2422' : '#6a3430';
    g = c.createLinearGradient(0, top - R * 0.6, 0, top + R * 0.1); g.addColorStop(0, '#2a0e0c'); g.addColorStop(1, skin);
    c.fillStyle = g; c.beginPath(); c.moveTo(-W2 * 1.1, R * 0.02); c.bezierCurveTo(-W2 * 0.5, top * 1.25, W2 * 0.45, top * 1.25, W2 * 1.1, -R * 0.06); c.bezierCurveTo(W2 * 0.6, top * 1.25 - R * 0.35, -W2 * 0.6, top * 1.25 - R * 0.35, -W2 * 1.1, R * 0.02); c.fill();
    // lid rim
    c.strokeStyle = '#3a0c0c'; c.lineWidth = R * 0.07; c.beginPath(); c.moveTo(-W2, 0); c.bezierCurveTo(-W2 * 0.5, top * 1.25, W2 * 0.45, top * 1.25, W2, -R * 0.05); c.stroke();
    c.strokeStyle = 'rgba(200,110,100,0.5)'; c.lineWidth = R * 0.02; c.stroke();
    // lower lid
    c.strokeStyle = '#4a1414'; c.lineWidth = R * 0.06; c.beginPath(); c.moveTo(-W2, 0); c.bezierCurveTo(-W2 * 0.5, bot * 1.2, W2 * 0.45, bot * 1.2, W2, -R * 0.05); c.stroke();
    // lashes (upper)
    c.strokeStyle = '#0a0404'; c.lineCap = 'round';
    for (let i = 0; i <= 36; i++) { const t = i / 36; const px = bez(-W2, -W2 * 0.5, W2 * 0.45, W2, t), py = bez(0, top * 1.25, top * 1.25, -R * 0.05, t); const len = R * (0.18 + 0.14 * Math.sin(t * Math.PI)) * (0.9 + 0.2 * Math.sin(i * 7.1)); const ang = -Math.PI / 2 + (t - 0.5) * 1.6; c.lineWidth = R * 0.018; c.beginPath(); c.moveTo(px, py); c.quadraticCurveTo(px + Math.cos(ang) * len * 0.5, py + Math.sin(ang) * len * 0.6, px + Math.cos(ang - 0.5) * len, py + Math.sin(ang) * len * 0.8 - len * 0.3); c.stroke(); }
    for (let i = 2; i <= 22; i++) { const t = i / 24; const px = bez(-W2, -W2 * 0.5, W2 * 0.45, W2, t), py = bez(0, bot * 1.2, bot * 1.2, -R * 0.05, t); const len = R * 0.09; c.lineWidth = R * 0.012; c.beginPath(); c.moveTo(px, py); c.lineTo(px + (t - 0.5) * len, py + len); c.stroke(); }
    c.restore();
  }
  const bez = (a, b, cc, d, t) => { const u = 1 - t; return u * u * u * a + 3 * u * u * t * b + 3 * u * t * t * cc + t * t * t * d; };

  // ================= PANELS =================
  const $ = (s) => document.querySelector(s);
  let panelOpen = null;
  M.open = (name) => {
    AudioSys.play('ui'); panelOpen = name;
    const p = $('#panel'), body = $('#panelBody'), title = $('#panelTitle');
    p.classList.remove('hidden'); p.dataset.name = name; body.innerHTML = ''; body.scrollTop = 0;
    const builders = { shop: buildShop, weapons: buildWeapons, stages: buildStages, achievements: buildAch, settings: buildSettings, about: buildAbout, credits: buildCredits, progress: buildProgress };
    title.textContent = { shop: 'THE SHOP', weapons: 'WEAPON COLLECTION', stages: 'STAGE SELECT', achievements: 'ACHIEVEMENTS', settings: 'SETTINGS', about: 'ABOUT', credits: 'CREDITS', progress: 'PROGRESSION' }[name];
    builders[name](body);
    eye.pupilT = 0.2; if (name === 'about') setTimeout(() => say('Ask Him.'), 1600);
  };
  M.close = () => { $('#panel').classList.add('hidden'); panelOpen = null; AudioSys.play('ui'); document.getElementById('menuSouls').textContent = '◈ ' + Save.d.souls; eye.pupilT = 0.36; };
  M.refresh = () => { if (panelOpen) { const st = $('#panelBody').scrollTop; const n = panelOpen; M.open(n); $('#panelBody').scrollTop = st; } document.getElementById('menuSouls').textContent = '◈ ' + Save.d.souls; };

  function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function weaponCanvas(id, size = 110, tint) { const cvs = document.createElement('canvas'); cvs.width = size * 2; cvs.height = size * 2; cvs.style.width = size + 'px'; cvs.style.height = size + 'px'; const cc = cvs.getContext('2d'); cc.scale(2, 2); drawWeaponIcon(cc, id, size / 2, size / 2, size, tint || null, 0); return cvs; }
  function outfitCanvas(item, size = 110) {
    const cvs = document.createElement('canvas'); cvs.width = size * 2; cvs.height = size * 2; cvs.style.width = size + 'px'; cvs.style.height = size + 'px'; const cc = cvs.getContext('2d'); cc.scale(2, 2);
    const keep = Save.d.outfit, keepEx = Save.d.extras; Save.d.outfit = item.id; let style; try { style = outfitStyle(); } finally { Save.d.outfit = keep; Save.d.extras = keepEx; }
    try { drawHumanoid(cc, size / 2, size * 0.97, 1, size / 118, P(SHEATHED), style, { T: 0, grounded: true }); } catch (e) {}
    return cvs;
  }
  function iconCanvas(item, size = 110) {
    const cvs = document.createElement('canvas'); cvs.width = size * 2; cvs.height = size * 2; cvs.style.width = size + 'px'; cvs.style.height = size + 'px'; const cc = cvs.getContext('2d'); cc.scale(2, 2); const m = size / 2;
    if (item.cat === 'skins') { drawWeaponIcon(cc, Save.d.equipped, m, m, size, item.tint, 0); return cvs; }
    if (item.cat === 'effects') { const col = item.trail || '#ffffff'; cc.globalCompositeOperation = 'lighter'; for (let i = 0; i < 14; i++) { cc.strokeStyle = rgba(col, 0.08 + i * 0.05); cc.lineWidth = 16 - i; cc.beginPath(); cc.arc(m - 10, m + 20, size * 0.36, -2.6 + i * 0.03, -0.5); cc.stroke(); } cc.strokeStyle = '#fff'; cc.lineWidth = 2; cc.beginPath(); cc.arc(m - 10, m + 20, size * 0.36, -2.4, -0.5); cc.stroke(); return cvs; }
    if (item.cat === 'finishers') { cc.translate(m, m + 6); const f = item.fin; cc.fillStyle = '#5a6a3a'; if (f === 'cleave') { cc.fillStyle = '#6a2a2a'; cc.beginPath(); cc.ellipse(-8, 0, 16, 30, -0.3, 0, 7); cc.fill(); cc.beginPath(); cc.ellipse(10, 6, 16, 30, 0.3, 0, 7); cc.fill(); cc.strokeStyle = '#fff'; cc.lineWidth = 3; cc.beginPath(); cc.moveTo(-30, 30); cc.lineTo(30, -36); cc.stroke(); }
      if (f === 'ash') { for (let i = 0; i < 40; i++) { cc.fillStyle = Math.random() < 0.5 ? '#ff7a1a' : '#3a3030'; cc.fillRect(rnd(-30, 30), rnd(-36, 30) - i * 0.3, 3, 3); } }
      if (f === 'soul') { cc.globalCompositeOperation = 'lighter'; const g = cc.createRadialGradient(0, -10, 2, 0, -10, 30); g.addColorStop(0, '#e0fff8'); g.addColorStop(1, 'rgba(0,255,180,0)'); cc.fillStyle = g; cc.beginPath(); cc.arc(0, -10, 30, 0, 7); cc.fill(); }
      if (f === 'shatter') { for (let i = 0; i < 14; i++) { cc.fillStyle = `rgba(190,230,255,${rnd(0.4, 0.9)})`; cc.beginPath(); const x = rnd(-30, 30), y = rnd(-30, 30); cc.moveTo(x, y); cc.lineTo(x + rnd(5, 14), y + rnd(-6, 6)); cc.lineTo(x + rnd(-4, 6), y + rnd(6, 14)); cc.fill(); } }
      return cvs; }
    // extras
    cc.translate(m, m); if (item.upgrade) { cc.fillStyle = '#b0101a'; cc.shadowColor = '#f22'; cc.shadowBlur = 16; cc.beginPath(); cc.moveTo(0, 26); cc.bezierCurveTo(-36, 0, -22, -32, 0, -14); cc.bezierCurveTo(22, -32, 36, 0, 0, 26); cc.fill(); cc.shadowBlur = 0; cc.fillStyle = '#fff'; cc.font = '900 16px Cinzel, Georgia'; cc.textAlign = 'center'; cc.fillText('+20', 0, 4); }
    else if (item.id === 'ex_halo') { cc.strokeStyle = '#111'; cc.lineWidth = 8; cc.shadowColor = '#f00'; cc.shadowBlur = 14; cc.beginPath(); cc.ellipse(0, 0, 34, 12, 0, 0, 7); cc.stroke(); }
    else if (item.id === 'ex_eyes') { [-12, 12].forEach(x => { cc.fillStyle = '#ff3a1a'; cc.shadowColor = '#f00'; cc.shadowBlur = 18; cc.beginPath(); cc.ellipse(x, 0, 8, 4, 0, 0, 7); cc.fill(); }); }
    else { cc.fillStyle = '#4a0a10'; cc.beginPath(); cc.moveTo(-20, -34); cc.lineTo(20, -34); for (let i = 0; i < 6; i++) cc.lineTo(26 - i * 9, 34 - (i % 2) * 12); cc.lineTo(-26, 34); cc.closePath(); cc.fill(); }
    return cvs;
  }

  let shopTab = 'weapons';
  function buildShop(body) {
    const tabs = el('div', 'tabs'); const cats = [['weapons', 'WEAPONS'], ['skins', 'SKINS'], ['outfits', 'OUTFITS'], ['effects', 'EFFECTS'], ['finishers', 'FINISHERS'], ['extras', 'EXTRAS']];
    cats.forEach(([k, n]) => { const b = el('button', 'tab' + (k === shopTab ? ' on' : ''), n); b.onclick = () => { shopTab = k; M.refresh(); }; tabs.appendChild(b); });
    body.appendChild(el('div', 'wallet', `<span>◈ ${Save.d.souls}</span> souls — earned by killing. Spend them.`));
    body.appendChild(tabs); const grid = el('div', 'grid'); body.appendChild(grid);
    if (shopTab === 'weapons') {
      WEAPONS.forEach(wd => {
        const owned = Save.d.weapons.includes(wd.id), eq = Save.d.equipped === wd.id;
        const card = el('div', 'card' + (eq ? ' eq' : '')); card.appendChild(weaponCanvas(wd.id, 96));
        card.appendChild(el('div', 'cname', wd.name)); card.appendChild(el('div', 'cdesc', wd.desc + `<br><b>${wd.special}</b>`));
        const btn = el('button', 'cbtn'); if (eq) { btn.textContent = 'EQUIPPED'; btn.disabled = true; } else if (owned) { btn.textContent = 'EQUIP'; btn.onclick = () => { Save.d.equipped = wd.id; Save.save(); AudioSys.play('unsheath'); M.refresh(); }; } else { btn.innerHTML = `BUY ◈ ${wd.price}`; btn.onclick = () => buy(wd.price, () => { Save.d.weapons.push(wd.id); Save.d.equipped = wd.id; M.onWeapon && M.onWeapon(wd.id); }); card.appendChild(el('div', 'clock', 'or: ' + wd.unlock)); }
        card.appendChild(btn); grid.appendChild(card);
      });
      return;
    }
    SHOP.filter(s => s.cat === shopTab).forEach(item => {
      const owned = Save.d.owned.includes(item.id); const slot = { skins: 'skin', outfits: 'outfit', effects: 'effect', finishers: 'finisher' }[item.cat];
      const eq = slot ? Save.d[slot] === item.id : (item.upgrade ? owned : Save.d.extras.includes(item.id));
      const card = el('div', 'card' + (eq ? ' eq' : '')); card.appendChild(item.cat === 'outfits' ? outfitCanvas(item, 96) : iconCanvas(item, 96));
      card.appendChild(el('div', 'cname', item.name)); card.appendChild(el('div', 'cdesc', item.desc));
      const btn = el('button', 'cbtn');
      if (!owned && item.price > 0) { btn.innerHTML = `BUY ◈ ${item.price}`; btn.onclick = () => buy(item.price, () => { Save.d.owned.push(item.id); if (item.upgrade) Save.d.hpUp++; else equip(item, slot); }); }
      else if (item.upgrade) { btn.textContent = 'OWNED'; btn.disabled = true; }
      else if (slot) { if (eq && slot === 'skin') { btn.textContent = 'REMOVE'; btn.onclick = () => { Save.d.skin = null; Save.save(); M.refresh(); }; } else if (eq) { btn.textContent = 'EQUIPPED'; btn.disabled = true; } else { btn.textContent = 'EQUIP'; btn.onclick = () => { if (!owned) Save.d.owned.push(item.id); equip(item, slot); Save.save(); AudioSys.play('ui'); M.refresh(); }; } }
      else { btn.textContent = eq ? 'TAKE OFF' : 'WEAR'; btn.onclick = () => { if (!owned) Save.d.owned.push(item.id); if (eq) Save.d.extras = Save.d.extras.filter(x => x !== item.id); else Save.d.extras.push(item.id); Save.save(); AudioSys.play('ui'); M.refresh(); }; }
      card.appendChild(btn); grid.appendChild(card);
    });
  }
  function equip(item, slot) { if (slot) Save.d[slot] = item.id; else if (!Save.d.extras.includes(item.id)) Save.d.extras.push(item.id); }
  function buy(price, fn) {
    if (Save.d.souls < price) { AudioSys.play('deny'); M.toast(`You need ◈ ${price - Save.d.souls} more souls.`); say(['Poor thing.', 'Go kill something.', 'Not enough. Never enough.'][Math.random() * 3 | 0]); return; }
    Save.d.souls -= price; fn(); Save.save(); AudioSys.play('buy'); M.toast('Purchased.'); M.onAch && M.onAch('shopper'); M.refresh();
  }
  function bar(label, v) { return `<div class="stat"><span>${label}</span><i><b style="width:${Math.round(clamp(v, 0, 1) * 100)}%"></b></i></div>`; }
  function buildWeapons(body) {
    body.appendChild(el('div', 'wallet', `${Save.d.weapons.length} / 5 weapons claimed. Bosses drop them. The shop sells them.`));
    WEAPONS.forEach(wd => {
      const owned = Save.d.weapons.includes(wd.id), eq = Save.d.equipped === wd.id;
      const row = el('div', 'wrow' + (owned ? '' : ' locked') + (eq ? ' eq' : '')); const cv = weaponCanvas(wd.id, 120); row.appendChild(cv);
      const info = el('div', 'winfo'); info.innerHTML = `<div class="cname">${owned ? wd.name : '??? ' + wd.name}</div><div class="cdesc">${wd.desc}</div>${bar('DAMAGE', wd.dmg / 55)}${bar('SPEED', wd.speed / 1.8)}${bar('REACH', wd.range / 175)}<div class="cdesc"><b>SPECIAL — ${wd.special}:</b> ${wd.specialDesc}</div><div class="clock">${owned ? 'Owned' : 'Unlock: ' + wd.unlock + ' — or buy for ◈ ' + wd.price}</div>`;
      const btn = el('button', 'cbtn'); if (eq) { btn.textContent = 'EQUIPPED'; btn.disabled = true; } else if (owned) { btn.textContent = 'EQUIP'; btn.onclick = () => { Save.d.equipped = wd.id; Save.save(); AudioSys.play('unsheath'); M.refresh(); }; } else { btn.textContent = 'GO TO SHOP'; btn.onclick = () => { shopTab = 'weapons'; M.open('shop'); }; }
      info.appendChild(btn); row.appendChild(info); body.appendChild(row);
    });
  }
  function chUnlocked(id) { const d = Save.d; if (id === 'dark') return d.shards.length >= 1; if (id === 'glass') return d.ach.includes('nohit') || d.deaths >= 10; if (id === 'frenzy') return d.ach.includes('combo30'); return false; }
  M.chUnlocked = chUnlocked;
  function stageOpts() { return { mods: (Save.d.mods || []).filter(chUnlocked), nightmare: !!Save.d.nightmare && Save.d.cleared.length >= 3 }; }
  function buildStages(body) {
    body.appendChild(el('div', 'wallet', `Stages unlocked: ${Save.d.unlockedStage} / ${STAGES.length}. Defeat a boss to open the next.`));
    const modes = el('div', 'modes');
    const nmOpen = Save.d.cleared.length >= 3;
    const nm = el('button', 'mode' + (Save.d.nightmare && nmOpen ? ' on' : '') + (nmOpen ? '' : ' locked'), `<b>NIGHTMARE</b><small>${nmOpen ? 'Tougher, faster, more of them. Souls x2.5' : 'Clear 3 stages to unlock'}</small>`);
    nm.onclick = () => { if (!nmOpen) { AudioSys.play('deny'); return; } Save.d.nightmare = !Save.d.nightmare; Save.save(); AudioSys.play(Save.d.nightmare ? 'growl' : 'ui'); if (Save.d.nightmare) say('Now we play properly.'); M.refresh(); };
    modes.appendChild(nm);
    CHALLENGES.forEach(ch => { const un = chUnlocked(ch.id), on = un && (Save.d.mods || []).includes(ch.id); const b = el('button', 'mode' + (on ? ' on' : '') + (un ? '' : ' locked'), `<b>${un ? ch.name : '???'}</b><small>${un ? ch.desc : ch.unlock}</small>`); b.onclick = () => { if (!un) { AudioSys.play('deny'); return; } const m = Save.d.mods || (Save.d.mods = []); const k = m.indexOf(ch.id); if (k >= 0) m.splice(k, 1); else m.push(ch.id); Save.save(); AudioSys.play('ui'); M.refresh(); }; modes.appendChild(b); });
    const enOpen = Save.d.cleared.length >= 3;
    const en = el('button', 'mode endless' + (enOpen ? '' : ' locked'), `<b>THE ENDLESS ABYSS</b><small>${enOpen ? 'Waves forever. Best: wave ' + (Save.d.endlessBest || 0) : 'Clear 3 stages to unlock'}</small>`);
    en.onclick = () => { if (!enOpen) { AudioSys.play('deny'); return; } M.close(); M.onStage && M.onStage(0, Object.assign(stageOpts(), { endless: true })); };
    modes.appendChild(en); body.appendChild(modes);
    const PGS = Math.ceil(STAGES.length / 10); let pg = window.__stPg; if (pg == null) pg = Math.floor(Math.max(0, Save.d.unlockedStage - 1) / 10); pg = Math.max(0, Math.min(PGS - 1, pg)); window.__stPg = pg;
    const nav = el('div', 'pager'); const nb = (t, d2) => { const b2 = el('button', 'obtn', t); b2.disabled = pg + d2 < 0 || pg + d2 >= PGS; b2.onclick = () => { window.__stPg = pg + d2; AudioSys.play('ui'); M.refresh(); }; return b2; };
    nav.appendChild(nb('\u25c0', -1)); nav.appendChild(el('span', 'pgl', `STAGES ${pg * 10 + 1} - ${pg * 10 + 10}`)); nav.appendChild(nb('\u25b6', 1)); body.appendChild(nav);
    const grid = el('div', 'grid stages');
    STAGES.forEach((S, i) => {
      if (Math.floor(i / 10) !== pg) return; const un = i < Save.d.unlockedStage, cl = Save.d.cleared.includes(i); const B = { name: bossName(S) };
      const card = el('button', 'scard' + (un ? '' : ' locked') + (cl ? ' cleared' : ''));
      card.style.background = `linear-gradient(180deg, ${S.sky[0]}, ${S.sky[1]} 55%, ${S.sky[2]} 85%, ${S.ground})`;
      card.innerHTML = `<div class="snum">${i + 1}</div><div class="sname">${un ? S.name : '— SEALED —'}</div><div class="ssub">${un ? S.sub : 'Defeat the previous boss'}</div><div class="sboss">${un ? 'BOSS: ' + B.name : ''}</div>${cl ? '<div class="sclr">CLEARED</div>' : ''}${Save.d.nmCleared.includes(i) ? '<div class="snm">NIGHTMARE ✦</div>' : ''}${Save.d.shards.includes(i) ? '<div class="sshard">◉</div>' : ''}`;
      card.onclick = () => { if (!un) { AudioSys.play('deny'); say('Not yet.'); return; } M.close(); M.onStage && M.onStage(i, stageOpts()); };
      grid.appendChild(card);
    });
    body.appendChild(grid);
  }
  function buildAch(body) {
    const n = Save.d.ach.length; body.appendChild(el('div', 'wallet', `${n} / ${ACHIEVEMENTS.length} unlocked`));
    const list = el('div', 'alist');
    ACHIEVEMENTS.forEach(a => { const on = Save.d.ach.includes(a.id); const secret = !on && (a.hidden || a.id === 'crashed' || a.id === 'back'); list.appendChild(el('div', 'arow' + (on ? ' on' : '') + (secret ? ' secret' : ''), `<div class="aicon">${on ? '✦' : '?'}</div><div><div class="cname">${secret ? '???' : a.name}</div><div class="cdesc">${secret ? 'A hidden achievement. It is watching to see if you find it.' : a.desc}</div></div>`)); });
    body.appendChild(list);
    body.appendChild(el('div', 'cdesc center', `Kills: ${Save.d.kills} · Objects destroyed: ${Save.d.destroyed} · Times it took you: ${Save.d.crashes} · Deaths: ${Save.d.deaths} · Executions: ${Save.d.executions}`));
  }
  function buildSettings(body) {
    const s = Save.d; const wrap = el('div', 'settings');
    const slider = (label, key, fn) => { const r = el('label', 'srow', `<span>${label}</span><input type="range" min="0" max="1" step="0.05" value="${s[key]}"><em>${Math.round(s[key] * 100)}%</em>`); const inp = r.querySelector('input'), em = r.querySelector('em'); inp.oninput = () => { s[key] = +inp.value; em.textContent = Math.round(s[key] * 100) + '%'; fn(s[key]); Save.save(); }; inp.onchange = () => AudioSys.play(key === 'sfx' ? 'metal' : 'ui'); return r; };
    const toggle = (label, key) => { const r = el('div', 'srow', `<span>${label}</span><button class="tog ${s[key] ? 'on' : ''}">${s[key] ? 'ON' : 'OFF'}</button>`); const b = r.querySelector('button'); b.onclick = () => { s[key] = !s[key]; b.classList.toggle('on', s[key]); b.textContent = s[key] ? 'ON' : 'OFF'; Save.save(); AudioSys.play('ui'); }; return r; };
    wrap.appendChild(slider('MUSIC VOLUME', 'music', v => AudioSys.setMusic(v)));
    wrap.appendChild(slider('SOUND VOLUME', 'sfx', v => AudioSys.setSfx(v)));
    wrap.appendChild(toggle('SCREEN SHAKE', 'shake'));
    wrap.appendChild(toggle('VIBRATION', 'haptics'));
    wrap.appendChild(toggle('SHOW FPS', 'fps'));
    const cyc = (label, key, opts, names, fn) => { const r = el('div', 'srow', `<span>${label}</span><button class="tog on"></button>`); const b = r.querySelector('button'); const upd = () => { b.textContent = names[opts.indexOf(s[key])] || names[0]; }; upd(); b.onclick = () => { const i = opts.indexOf(s[key]); s[key] = opts[(i + 1) % opts.length]; upd(); Save.save(); AudioSys.play('ui'); fn && fn(s[key]); }; return r; };
    wrap.appendChild(cyc('GRAPHICS QUALITY', 'quality', ['auto', 'low', 'high', 'ultra'], ['AUTO', 'LOW', 'HIGH', 'ULTRA'], (v) => { Game.applyQuality && Game.applyQuality(); if (v === 'ultra') say('Now you can see me clearly.'); }));
    wrap.appendChild(el('div', 'cdesc', 'ULTRA: sharpest resolution, god rays, double fog, film grain, light bloom and more particles. AUTO drops to LOW if your phone struggles.'));
    wrap.appendChild(cyc('BUTTON SIZE', 'ctlSize', [0.85, 1, 1.15, 1.3], ['SMALL', 'NORMAL', 'LARGE', 'HUGE'], () => window.layoutControls && window.layoutControls()));
    wrap.appendChild(toggle('LEFT-HANDED (SWAP SIDES)', 'swapSides'));
    wrap.appendChild(toggle('FULLSCREEN ON PHONES', 'fullscreen'));
    if (s.percy === 'alive') wrap.appendChild(toggle('BRING PERCY', 'percyOn'));
    if (s.percy === 'dead') wrap.appendChild(el('div', 'srow', `<span>PERCY</span><em class="rip">✝ ${s.percyDiedAt ? new Date(s.percyDiedAt).toLocaleDateString() : ''}${s.percyStage >= 0 ? ' · ' + STAGES[s.percyStage].name : ''}</em>`));
    Object.values(COMPANIONS).forEach(C => { const v = (s.comp || {})[C.id]; if (v === 'alive') wrap.appendChild(toggle('BRING ' + C.name, 'compOn_' + C.id)); if (v === 'dead') { const dd = s.compDied && s.compDied[C.id]; wrap.appendChild(el('div', 'srow', `<span>${C.name}</span><em class="rip">\u271d ${dd ? new Date(dd.t).toLocaleDateString() + ' \u00b7 stage ' + (dd.stage + 1) : ''}</em>`)); } });
    const rr = el('div', 'srow', `<span>ERASE ALL PROGRESS</span><button class="tog danger">RESET</button>`); const rb = rr.querySelector('button'); let armed = false;
    rb.onclick = () => { if (!armed) { armed = true; rb.textContent = 'ARE YOU SURE?'; AudioSys.play('deny'); setTimeout(() => { armed = false; rb.textContent = 'RESET'; }, 3000); return; } Save.reset(); AudioSys.setMusic(Save.d.music); AudioSys.setSfx(Save.d.sfx); M.toast('Everything is gone. Except it. It remembers.'); say('I still remember you.'); M.refresh(); };
    wrap.appendChild(rr);
    wrap.appendChild(el('div', 'cdesc center', 'Controls: on-screen buttons on touch devices (hold HEAVY to charge; DODGE at the last moment for a perfect dodge). On desktop: A/D or arrows to move, W/Space jump, J attack, L heavy (hold), Shift dodge, K special, Q change weapon, Esc pause. Attack a staggered enemy to EXECUTE it.'));
    body.appendChild(wrap);
  }
  function buildAbout(body) {
    const a = el('div', 'about');
    a.innerHTML = `<div class="about-eye"></div><p class="quote"><span class="xx" role="button" aria-label="X">X</span> created this game. If you don't trust me, ask God (if possible).</p><p class="sig">— <span class="xx" role="button" aria-label="X">X</span></p><p class="cdesc center">No further information is available. Do not look for it.</p>${Save.d.percy === 'alive' ? '<p class="cdesc center percy-note">Percy is with you. Keep him alive. If he falls, he does not get up.</p>' : ''}${Save.d.percy === 'dead' ? '<p class="cdesc center percy-note rip">In memory of Percy. A good boy. He is not coming back.</p>' : ''}`;
    body.appendChild(a);
    Object.values(COMPANIONS).forEach(C => { const v = (Save.d.comp || {})[C.id]; if (v === 'alive') a.insertAdjacentHTML('beforeend', `<p class="cdesc center percy-note">${C.name} is with you. If ${C.name} falls, there is no coming back.</p>`); if (v === 'dead') a.insertAdjacentHTML('beforeend', `<p class="cdesc center percy-note rip">In memory of ${C.name}. Gone for good. You were warned.</p>`); });
    // SECRET: tap the X. 10 = Percy, 15 = Vesper, 20 = Lantern, 30 = Brutus. Each can die for good.
    let taps = 0, lastTap = 0;
    const gift = (id) => {
      const C = COMPANIONS[id], cs = Save.d.comp || (Save.d.comp = {});
      if (cs[id] === 'dead') { say(C.name + ' is gone. You let it happen.', true); M.toast(C.name + ' is dead. Nothing can bring them back.'); AudioSys.play('whimper'); return; }
      if (cs[id] === 'alive') { M.toast(C.name + ' is already with you.'); return; }
      cs[id] = 'alive'; Save.d['compOn_' + id] = true; Save.save(); M.onAch && M.onAch('comp_' + id); AudioSys.play('bark');
      say(C.name + ' has answered.', true); setExpr('angry', 6);
      const card = el('div', 'percy-card'); const cvs = document.createElement('canvas'); cvs.width = 320; cvs.height = 200; cvs.style.width = '160px'; cvs.style.height = '100px'; const cc = cvs.getContext('2d'); cc.scale(2, 2);
      const t0 = performance.now(); const anim = () => { if (!cvs.isConnected) return; const tt = (performance.now() - t0) / 1000; cc.clearRect(0, 0, 160, 100); drawCompanion(cc, 80, C.fly ? 52 : 92, 1, C.kind === 'golem' ? 0.9 : 1.6, { kind: C.kind, T: tt, moving: false }); requestAnimationFrame(anim); }; anim();
      card.appendChild(cvs); card.appendChild(el('div', 'cname', C.name + ' HAS JOINED YOU')); card.appendChild(el('div', 'cdesc', C.desc)); a.appendChild(card);
    };
    a.querySelectorAll('.xx').forEach(x => x.addEventListener('pointerdown', (e) => {
      e.stopPropagation(); e.preventDefault(); const now = performance.now(); if (now - lastTap > 6000) taps = 0; lastTap = now; taps++;
      x.classList.remove('tap'); void x.offsetWidth; x.classList.add('tap'); AudioSys.play(taps < 10 ? 'blink' : 'bark');
      if (taps === 4) say('Why are you touching that?');
      if (taps === 7) say('Stop. Something is coming.');
      if (taps === 12) say('There is more. You know there is more.');
      if (taps === 17) say('Do not stop now.');
      if (taps === 25) say('Almost. Do not look away.');
      if (taps === 10) {
        if (Save.d.percy === 'dead') { say('He is gone. You let him die.', true); M.toast('Percy is dead. Nothing can bring him back.'); AudioSys.play('whimper'); return; }
        if (Save.d.percy === 'alive') { M.toast('Percy is already with you. Woof.'); return; }
        Save.d.percy = 'alive'; Save.d.percyOn = true; Save.save(); M.onAch && M.onAch('percy'); AudioSys.play('bark'); setTimeout(() => AudioSys.play('bark'), 260);
        say('A dog? You brought a DOG?', true); setExpr('angry', 6);
        const card = el('div', 'percy-card'); const cvs = document.createElement('canvas'); cvs.width = 320; cvs.height = 200; cvs.style.width = '160px'; cvs.style.height = '100px'; const cc = cvs.getContext('2d'); cc.scale(2, 2);
        let t0 = performance.now(); const anim = () => { if (!cvs.isConnected) return; const tt = (performance.now() - t0) / 1000; cc.clearRect(0, 0, 160, 100); drawDog(cc, 80, 92, 1, 1.25, { T: tt, phase: 0, moving: false, wag: tt * 14, bark: Math.sin(tt * 3) > 0.9 ? 1 : 0 }); requestAnimationFrame(anim); }; anim();
        card.appendChild(cvs); card.appendChild(el('div', 'cname', 'PERCY HAS JOINED YOU')); card.appendChild(el('div', 'cdesc', 'He fights every enemy at your side, bites anything that hurts you and stays close when he is wounded. But if Percy dies once, he is dead forever.'));
        a.appendChild(card);
      }
      if (taps === 15) gift('vesper');
      if (taps === 20) gift('lantern');
      if (taps === 30) { taps = 0; gift('brutus'); }
    }));
  }
  let progTab = 'abilities';
  function buildProgress(body) {
    const tabs = el('div', 'tabs'); [['abilities', 'ABILITIES'], ['upgrades', 'UPGRADES'], ['mastery', 'MASTERY'], ['relics', 'RELICS']].forEach(([k, n]) => { const b = el('button', 'tab' + (k === progTab ? ' on' : ''), n); b.onclick = () => { progTab = k; M.refresh(); }; tabs.appendChild(b); });
    body.appendChild(el('div', 'wallet', `<span>◈ ${Save.d.souls}</span> souls · Eye shards found: ${Save.d.shards.length} / 10`)); body.appendChild(tabs);
    const grid = el('div', 'grid'); body.appendChild(grid);
    if (progTab === 'abilities') ABILITIES.forEach(ab => {
      const own = Save.d.abilities.includes(ab.id); const rq = ab.req || {}; const okC = !rq.cleared || Save.d.cleared.length >= rq.cleared, okA = !rq.ability || Save.d.abilities.includes(rq.ability);
      const card = el('div', 'card' + (own ? ' eq' : '')); card.appendChild(el('div', 'cname', ab.name)); card.appendChild(el('div', 'cdesc', ab.desc));
      const btn = el('button', 'cbtn');
      if (own) { btn.textContent = 'LEARNED'; btn.disabled = true; }
      else if (!okC || !okA) { btn.textContent = 'LOCKED'; btn.disabled = true; card.appendChild(el('div', 'clock', !okC ? `Clear ${rq.cleared} stage${rq.cleared > 1 ? 's' : ''} first` : 'Requires ' + ABILITIES.find(x => x.id === rq.ability).name)); }
      else { btn.innerHTML = `LEARN ◈ ${ab.price}`; btn.onclick = () => buy(ab.price, () => { Save.d.abilities.push(ab.id); M.onAch && M.onAch('ability1'); }); }
      card.appendChild(btn); grid.appendChild(card);
    });
    if (progTab === 'upgrades') UPGRADES.forEach(u => {
      const lv = Save.d.upg[u.id] || 0; const card = el('div', 'card' + (lv >= 3 ? ' eq' : '')); card.appendChild(el('div', 'cname', u.name)); card.appendChild(el('div', 'cdesc', u.desc));
      card.appendChild(el('div', 'pips', [0, 1, 2].map(i => `<i class="${i < lv ? 'on' : ''}"></i>`).join('')));
      const btn = el('button', 'cbtn'); if (lv >= 3) { btn.textContent = 'MAXED'; btn.disabled = true; } else { const pr = u.prices[lv]; btn.innerHTML = `UPGRADE ◈ ${pr}`; btn.onclick = () => buy(pr, () => { Save.d.upg[u.id] = lv + 1; M.onAch && M.onAch('upgrade1'); }); }
      card.appendChild(btn); grid.appendChild(card);
    });
    if (progTab === 'mastery') { WEAPONS.forEach(wd => {
      const own = Save.d.weapons.includes(wd.id); const m = masteryOf(wd.id); const card = el('div', 'card' + (m.lvl >= 10 ? ' eq' : '')); card.appendChild(weaponCanvas(wd.id, 72, own ? null : '#000000'));
      card.appendChild(el('div', 'cname', wd.name)); card.appendChild(el('div', 'cdesc', own ? `LEVEL ${m.lvl} / 10` : 'Not owned'));
      card.appendChild(el('div', 'xpbar', `<b style="width:${m.need ? Math.round(m.xp / m.need * 100) : 100}%"></b>`));
      const tech = MASTERY.tech[wd.id]; card.appendChild(el('div', 'cdesc', `<b>${m.lvl >= 5 ? '✦' : 'Lv 5'} ${tech.name}:</b> ${tech.text}`)); grid.appendChild(card); });
      body.appendChild(el('div', 'cdesc center', 'Weapons grow stronger the more you kill with them: ' + MASTERY.perks.map(p => `Lv ${p.lvl} — ${p.text}`).join(' · '))); }
    if (progTab === 'relics') RELICS.forEach(r => {
      const own = Save.d.relics.includes(r.id); const card = el('div', 'card' + (own ? '' : ' locked')); card.appendChild(el('div', 'relic-ic', own ? '✦' : '?'));
      card.appendChild(el('div', 'cname', own ? r.name : '??? RARE RELIC')); card.appendChild(el('div', 'cdesc', own ? r.desc : r.hint));
      if (own) { const btn = el('button', 'cbtn'); let on = r.kind === 'extra' ? Save.d.extras.includes(r.id) : r.kind === 'effect' ? Save.d.effect === r.id : Save.d.outfit === r.id;
        btn.textContent = on ? 'TAKE OFF' : 'WEAR';
        btn.onclick = () => { if (r.kind === 'extra') { if (on) Save.d.extras = Save.d.extras.filter(x => x !== r.id); else Save.d.extras.push(r.id); } else if (r.kind === 'effect') Save.d.effect = on ? 'fx_default' : r.id; else Save.d.outfit = on ? 'out_wanderer' : r.id; Save.save(); AudioSys.play('ui'); M.refresh(); };
        card.appendChild(btn); }
      grid.appendChild(card);
    });
  }
  function buildCredits(body) {
    const roll = el('div', 'credits');
    roll.innerHTML = `<div class="roll">
      <h3>THE EYE BEHIND YOU</h3>
      <p><small>CREATED BY</small>X</p>
      <p><small>DESIGN · CODE · NIGHTMARES</small>X</p>
      <p><small>ART</small>X, by candlelight</p>
      <p><small>MUSIC & SOUND</small>Synthesized live, in your browser, right now</p>
      <p><small>THE EYE</small>Itself</p>
      <p><small>GOBLIN KING</small>Grubnak the Gnawing</p>
      <p><small>THE CREATURE IN THE DARK</small>Unknown (it did not sign the contract)</p>
      <p><small>SPECIAL THANKS</small>You, for staying this long</p>
      <p><small>NO ANIMALS WERE HARMED</small>Several goblins were${Save.d.percy === 'dead' ? '. And one dog. You know what you did.' : ''}</p>${Save.d.percy ? '<p><small>GOOD BOY</small>Percy</p>' : ''}
      <p class="last">It is still behind you.</p></div>`;
    body.appendChild(roll);
  }
  M.toast = (msg) => { const t = document.getElementById('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(M._tt); M._tt = setTimeout(() => t.classList.remove('show'), 2400); };
  return M;
})();
