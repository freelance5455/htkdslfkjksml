// Android shell helpers (only active inside the APK)
(function () {
  const C = window.Capacitor; if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  document.documentElement.classList.add('native-app');
  const esc = () => window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Escape', key: 'Escape' }));
  document.addEventListener('visibilitychange', () => { if (document.hidden) AudioSys.suspend(); else AudioSys.resume(); });
  const App = C.Plugins && C.Plugins.App; if (!App) return;
  // Back button: closes panels/menus, pauses or resumes the game (same as Escape). Never kills the app mid-fight.
  App.addListener('backButton', esc);
  App.addListener('pause', () => AudioSys.suspend());
  App.addListener('resume', () => AudioSys.resume());
})();
