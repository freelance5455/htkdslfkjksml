// ===== GAME ENGINE =====
const Game = (() => {
  const G = {};
  let cv, c, W = 960, scale = 1, offY = 0, dpr = 1, hs = 1, HW = 960, HOY = 0, dprCap = 2;
  let st = null; // stage state
  const input = { left: false, right: false, jump: false, attack: false, special: false, heavy: false, dodge: false, jumpP: false, attackP: false, specialP: false, heavyP: false, dodgeP: false };
  G.input = input;
  const BIGPROP_KIND = ['tower', 'pillar', 'tree', 'statue', 'pillar', 'coral', 'ice', 'statue', 'spire', 'monolith'];
  const AMB_KIND = { embers: 'fire', snow: 'ice', leaves: 'wind', bubbles: 'water', spores: 'flesh', dust: 'wind', mist: 'water', glitch: 'void' };
  G.running = false;

  // ---------- setup ----------
  G.init = (canvas) => { cv = canvas; c = cv.getContext('2d'); G.applyQuality(); window.addEventListener('resize', G.resize); };
  G.resize = () => {
    const sw = window.innerWidth, sh = window.innerHeight; dpr = Math.min(window.devicePixelRatio || 1, dprCap);
    cv.width = Math.round(sw * dpr); cv.height = Math.round(sh * dpr); cv.style.width = sw + 'px'; cv.style.height = sh + 'px';
    if (sw / sh >= 1.15) {
      // landscape is the primary experience: fill the screen, zoom in a little on short phone screens so fighters read bigger
      const zoom = sh < 460 ? 1.12 : sh < 700 ? 1.06 : 1;
      scale = sh / VH * zoom; W = sw / scale;
      if (W > 1400) { W = 1400; scale = sw / W; }
      if (W < 640) { W = 640; scale = sw / W; }
      offY = sh - VH * scale; // keep the ground at the bottom, crop sky on top
      hs = sh / VH; HW = sw / hs; HOY = 0;
    }
    else { W = 640; scale = sw / W; offY = Math.max(0, (sh - VH * scale) * 0.32); hs = scale; HW = W; HOY = offY; }
    G.portrait = sw / sh < 1.15; G.view = { W, scale, offY, hs, HW };
  };

  // ---------- quality: auto / low / high / ultra ----------
  let autoQ = 'high', lowFpsT = 0;
  G.applyQuality = () => {
    const q = Save.d.quality || 'auto'; G.quality = q === 'auto' ? autoQ : q;
    dprCap = G.quality === 'ultra' ? 3 : G.quality === 'low' ? 1.25 : 2; if (cv) G.resize();
  };
  G.qualityTick = (dt) => {
    // adaptive: only 'auto' steps down, so a slow phone never stays sluggish
    if ((Save.d.quality || 'auto') !== 'auto' || !st || !G.running) return;
    if (G.fps && G.fps < 40) lowFpsT += dt; else lowFpsT = Math.max(0, lowFpsT - dt * 0.5);
    if (lowFpsT > 3 && autoQ !== 'low') { autoQ = 'low'; lowFpsT = 0; G.applyQuality(); }
  };

  // ---------- stage ----------
  G.start = (idx, opts = {}) => {
    const endless = !!opts.endless; const S = STAGES[idx]; const bg = buildBG(idx);
    const up = Save.d.upg || {}; const has = (a) => Save.d.abilities.includes(a);
    const maxHp = 100 + Save.d.hpUp * 20;
    const mods = (opts.mods || []).slice(); const nm = !!opts.nightmare;
    st = {
      idx, S, bg, T: 0, camX: 0, camTarget: 0, len: 4300, lock: null, waves: [], waveIdx: 0, enemies: [], projs: [], parts: [], decals: [], props: [], pickups: [], hazards: [], beams: [], texts: [],
      boss: null, bossStarted: false, shake: 0, hitstop: 0, slowmo: 0, slowT: 0, flash: 0, combo: 0, comboT: 0, bestCombo: 0, kills: 0, soulsGained: 0, cleared: false, dmgTaken: 0, bossDmgTaken: 0,
      spawnQ: [], banner: { text: S.name, sub: (endless ? 'THE ENDLESS ABYSS' : 'STAGE ' + (idx + 1)) + ' — ' + S.sub, t: 3.2 }, eyekill: null, distort: 0, invert: 0, stare: null, glitchT: 0,
      // nightmare evolution
      mods, nm, endless, ewave: 0, cine: null, zoom: 1, zoomT: 1, zoomX: 0, zoomY: GY - 80, witch: 0, exec: null, whisper: null, xp: {}, levelUps: [], relicFound: null, shardFound: false, execs: 0, perfects: 0, heavies: 0, stageT: 0,
      predict: 0, lastPat: [], tokens: 0, darkness: 0, flick: 1, flickT: 0, lightsOut: 0, events: { t: rnd(7, 13), n: 0 }, watchers: [], figures: [], distant: null, bigProps: [], rubble: [], lights: [], idleFightT: 0, retreatT: 0, lowHpSaid: false, firstSwing: true, soulMul: (mods.includes('glass') ? 3 : 1) * (mods.includes('frenzy') ? 2 : 1) * (mods.includes('dark') ? 1.5 : 1) * (nm ? 2.5 : 1), stageMul: endless ? 1 : 1,
      p: {
        x: 140, y: GY, vx: 0, vy: 0, facing: 1, grounded: true, hp: maxHp, maxHp, rage: 30, inv: 0, z: 12,
        weapon: Save.d.equipped, sheathed: true, act: null, step: 0, queued: false, idleT: 0, phase: 0, stepAcc: 0, landT: 0, hurtT: 0, dead: false, deathT: 0, trail: [], trail2: [], pose: P(SHEATHED), spec: null, after: [], jumpBuf: 0, coyote: 0, flashT: 0,
        dodge: null, dodgeCd: 0, jumps: 0, airHits: 0, rageMax: has('rage_overflow') ? 150 : 100, riposteT: 0, secondWind: has('second_wind'), dmgMul: 1 + 0.08 * (up.str || 0), defMul: 1 - 0.08 * (up.iron || 0), rageMul: 1 + 0.2 * (up.fury || 0), spdMul: 1 + 0.06 * (up.swift || 0), pending: null, heavyQ: false,
      },
    };
    if (mods.includes('glass')) { st.p.maxHp = st.p.hp = 1; }
    // waves
    const types = S.enemies.slice(); if (nm) { const extra = STAGES[Math.min(STAGES.length - 1, idx + 2)].enemies; types.push(extra[Math.floor(Math.random() * extra.length)]); }
    const n0 = 4 + Math.floor(idx * 0.5) + (mods.includes('frenzy') ? 3 : 0) + (nm ? 2 : 0);
    if (!endless) [650, 1450, 2250, 3050].forEach((x, i) => st.waves.push({ x, n: n0 + i + (i === 3 ? 2 : 0), types, done: false }));
    else { st.len = 1e9; st.types = types; }
    // props
    const propEnd = endless ? 6000 : st.len - 500;
    for (let x = 380; x < propEnd; x += rnd(220, 420)) st.props.push({ x, y: GY + rnd(4, 18), type: S.props, hp: 2, hitT: 0 });
    // big destructible landmarks (one between each wave, plus the arena)
    const bigXs = endless ? [900, 2200, 3600, 5000] : [1000, 1800, 2650, 3500, 3950];
    bigXs.forEach(x => st.bigProps.push({ x: x + rnd(-80, 80), hp: 6, maxHp: 6, hitT: 0, fall: 0, fallen: false, dir: 1, kind: BIGPROP_KIND[idx] || 'pillar', seed: rnd(0, 10), h: rnd(230, 290) }));
    // one hidden eye shard per stage, sealed inside one of the landmarks
    if (!endless && !Save.d.shards.includes(idx)) st.bigProps[Math.floor(Math.random() * 4)].shard = true;
    st.p.style = outfitStyle();
    st.mlvl = {}; WEAPONS.forEach(w => st.mlvl[w.id] = masteryOf(w.id).lvl);
    AudioSys.music(S.music); AudioSys.setIntensity(0); AudioSys.ambience(AMB_KIND[S.weather] || 'wind'); G.running = true; G.paused = false;
    G.onEvent && G.onEvent('start', idx);
  };
  G.stage = () => st;

  // ---------- helpers ----------
  const W2S = (x) => x - st.camX;
  function shake(v) { if (Save.d.shake) st.shake = Math.max(st.shake, v); }
  function hitstop(t) { st.hitstop = Math.max(st.hitstop, t); }
  function vib(ms) { if (Save.d.haptics && navigator.vibrate) try { navigator.vibrate(ms); } catch (e) {} }
  function part(o) { if (st.parts.length > 700) st.parts.shift(); st.parts.push(Object.assign({ t: 0, life: 0.5, vx: 0, vy: 0, g: 0, r: 3, col: '#fff', type: 'dot', rot: 0, vr: 0 }, o)); }
  function txt(x, y, s, col = '#fff', size = 18, life = 0.8) { st.texts.push({ x, y, s, col, size, t: 0, life }); }
  function blood(x, y, col, n = 14, dir = 1, power = 1) {
    for (let i = 0; i < n; i++) part({ x, y, vx: dir * rnd(60, 420) * power + rnd(-80, 80), vy: rnd(-420, 60) * power, g: 1400, r: rnd(1.5, 4), col, life: rnd(0.4, 0.9), type: 'blood' });
  }
  function sparks(x, y, col = '#ffe8a0', n = 10, dir = 1) { for (let i = 0; i < n; i++) { const a = rnd(-1.2, 1.2) + (dir < 0 ? Math.PI : 0); const sp = rnd(300, 900); part({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, g: 900, col, life: rnd(0.15, 0.35), type: 'spark', r: rnd(1, 2.2) }); } }
  function dust(x, y, n = 8, col = 'rgba(180,160,140,0.5)', spread = 1) { for (let i = 0; i < n; i++) part({ x: x + rnd(-10, 10), y: y - rnd(0, 6), vx: rnd(-160, 160) * spread, vy: rnd(-80, -10), r: rnd(5, 12), col, life: rnd(0.4, 0.8), type: 'dust' }); }
  function ring(x, y, col = '#fff', r = 40, life = 0.25) { part({ x, y, r, col, life, type: 'ring' }); }
  function debris(x, y, col, n = 8, power = 1) { for (let i = 0; i < n; i++) part({ x, y: y - rnd(0, 30), vx: rnd(-300, 300) * power, vy: rnd(-600, -150) * power, g: 1600, r: rnd(3, 7), col, life: rnd(0.8, 1.4), type: 'chunk', rot: rnd(0, 6), vr: rnd(-12, 12) }); }
  function decal(x, col, w = 20) { if (st.decals.length > 90) st.decals.shift(); st.decals.push({ x, y: GY + rnd(2, 20), w: w * rnd(0.6, 1.4), col }); }
  G.fx = { blood, sparks, dust, ring, debris, txt };
  // positional audio: pan/attenuate by world x relative to the camera
  function sfx(name, x, ...args) {
    if (x == null || !st) { AudioSys.play(name, ...args); return; }
    const cx = st.camX + W / 2; const dx = x - cx; const pan = clamp(dx / (W * 0.6), -1, 1) * 0.85;
    const off = Math.max(0, Math.abs(dx) - W / 2); const vol = clamp(1 - off / 900, 0.15, 1);
    AudioSys.playAt(pan, vol, name, ...args);
  }
  G.sfx = sfx;
  function light(x, y, r, a = 1, life = 0.15, col) { if (st.lights.length < 40) st.lights.push({ x, y, r, a, t: 0, life, col }); }
  G.light = light;
  const has = (id) => Save.d.abilities.includes(id);
  const mlvl = () => st.mlvl[st.p.weapon] || 1;
  function addXP(n) {
    const id = st.p.weapon; if (!Save.d.mxp) Save.d.mxp = {}; const before = masteryOf(id).lvl;
    Save.d.mxp[id] = (Save.d.mxp[id] || 0) + n; st.xp[id] = (st.xp[id] || 0) + n;
    const after = masteryOf(id).lvl;
    if (after > before) {
      st.mlvl[id] = after; st.levelUps.push({ id, lvl: after });
      const wd = WEAPONS.find(w => w.id === id);
      st.toast = { text: wd.name + ' — MASTERY ' + after, sub: (MASTERY.perks.find(q => q.lvl === after) || {}).text || '+4% damage', t: 2.6 };
      AudioSys.play('chargeReady', 2); G.onEvent && G.onEvent('mastery', { id, lvl: after });
    }
  }
  function impactSound(x, heavy) { const k = cls(); const nm = { sword: 'impactSword', dual: 'impactDual', hammer: 'impactHammer', scythe: 'impactScythe', spear: 'impactSpear' }[k]; sfx(nm, x, heavy ? 0.8 : rnd(0.9, 1.15)); }

  const weaponDef = () => WEAPONS.find(w => w.id === st.p.weapon);
  const cls = () => weaponDef().cls;
  function trailCol() { const rl = RELICS.find(r => r.id === Save.d.effect && r.kind === 'effect' && Save.d.relics.includes(r.id)); if (rl) return rl.trail === 'glitch' ? (Math.random() < 0.5 ? '#ff2aff' : '#2affff') : rl.trail; if (mlvl() >= 10 && Save.d.effect === 'fx_default') return '#ffd23a'; const fx = SHOP.find(s => s.id === Save.d.effect); return (fx && fx.trail) || weaponDef().trail; }
  function skinTint() { const s = SHOP.find(x => x.id === Save.d.skin); return s ? s.tint : null; }

  // ---------- player actions ----------
  function unwrapFrom(from, target) { for (const k of ['w', 'w2']) { if (target[k] == null || from[k] == null) continue; while (from[k] - target[k] > 180) from[k] -= 360; while (target[k] - from[k] > 180) from[k] += 360; } }
  function startAct(name, frames, opts = {}) {
    const p = st.p; const from = Object.assign({}, p.pose); if (frames[0]) unwrapFrom(from, frames[0].p);
    p.act = Object.assign({ name, t: 0, frames, from, hit: new Set(), ev: {} }, opts);
    p.act.dur = frames[frames.length - 1].t;
  }
  function resolveFrames(frames, base) { return frames.map(fr => ({ t: fr.t, p: fr.p === 'R' ? base : (fr.p === 'S' ? SHEATHED : Object.assign({}, base, fr.p)) })); }
  function actPose(a) {
    const fr = a.frames; let prev = { t: 0, p: a.from };
    for (const f of fr) { if (a.t <= f.t) { const k = (a.t - prev.t) / Math.max(0.0001, f.t - prev.t); return lerpPose(prev.p, f.p, ease(clamp(k, 0, 1))); } prev = f; }
    return lerpPose(fr[fr.length - 1].p, fr[fr.length - 1].p, 1);
  }
  function doDraw(thenAttack) {
    const p = st.p, k = cls(), R = READY[k];
    const reach = Object.assign({}, REACH, k === 'dual' ? { a2u: 190, a2f: 240 } : {});
    // reach back, grip, pull the blade free in an arc, flourish (a blood-flick for blades), settle into guard
    const flick = k === 'hammer' ? Object.assign({}, FLOURISH, { w: 200, t: 6 }) : FLOURISH;
    const frames = resolveFrames([F(0.12, reach), F(0.19, Object.assign({}, reach, { a1u: 200, a1f: 250 })), F(0.32, Object.assign({}, PULL, k === 'dual' ? { a2u: 150, a2f: 165, w2: 190 } : {})), F(0.43, flick), F(0.48, Object.assign({}, flick, { a1f: flick.a1f - 30, w: flick.w - 40 })), F(0.58, 'R')], R);
    startAct('draw', frames, { thenAttack, speed: 1.15 * st.p.spdMul });
    p.sheathed = false; p.drawK = 0; p.iaido = true;
  }
  function doSheath(then) {
    const p = st.p, R = READY[cls()];
    // chiburi (blood flick) before sheathing, then slide it home
    const flick = Object.assign({}, R, { t: R.t + 4, a1u: R.a1u + 40, a1f: R.a1f + 50, w: R.w + 60 });
    const flick2 = Object.assign({}, R, { t: R.t - 2, a1u: R.a1u - 20, a1f: R.a1f - 30, w: R.w - 70 });
    const frames = resolveFrames([F(0.1, flick), F(0.17, flick2), F(0.3, PULL), F(0.42, REACH), F(0.56, 'S')], SHEATHED);
    startAct('sheath', frames, { then, speed: 1.2, flickAt: 0.15 });
  }
  function doAttack() {
    const p = st.p, k = cls(), wd = weaponDef(), data = ATK[k];
    let stepD, isAir = !p.grounded;
    if (isAir) { stepD = p.airHits % 2 === 0 ? data.air : data.air2; p.airHits++; p.step = 0; if (p.vy > -100) p.vy = Math.min(p.vy, 40); }
    else { stepD = data.combo[p.step % data.combo.length]; }
    const frames = resolveFrames(stepD.f, READY[k]);
    startAct('attack', frames, { d: stepD, speed: wd.speed * (1 + (p.spdMul - 1) * 0.5), air: isAir, step: p.step % data.combo.length });
    p.idleT = 0; p.trail = []; p.trail2 = [];
    notePattern(isAir ? 'A' : 'L');
  }
  // the enemies read repetitive play: identical light-combo spam builds "predictability"
  function notePattern(ch) { const L = st.lastPat; L.push(ch); if (L.length > 12) L.shift(); const n = L.length; let same = 0; for (let i = n - 1; i >= 0 && L[i] === ch; i--) same++; const target = ch === 'L' ? clamp((same - 3) / 7, 0, 1) : 0; st.predict = lerp(st.predict, target, ch === 'L' ? 0.25 : 0.6); }
  function findExecTarget() {
    const p = st.p; let best = null, bd = 1e9;
    for (const e of st.enemies) { if (e.dead || e.boss && !e.broken) continue; if (!(e.state === 'stagger' || e.broken)) continue; const d = Math.abs(e.x - p.x); if (d < (e.boss ? 200 : 130) && Math.abs((e.flying ? e.y + 40 : e.y) - p.y) < 120 && d < bd) { bd = d; best = e; } }
    return best;
  }
  function tryAttack() {
    const p = st.p; if (p.dead || p.spec || p.dodge || st.exec || st.cine && st.cine.lock) return;
    if (p.act && p.act.name === 'charge') return;
    if (p.act && (p.act.name === 'draw' || p.act.name === 'sheath' || p.act.name === 'switch')) { if (p.act.name === 'draw') p.act.thenAttack = true; return; }
    if (p.sheathed) { doDraw(true); return; }
    if (p.grounded) { const tgt = findExecTarget(); if (tgt && (!p.act || p.act.name !== 'attack' || p.act.t > p.act.d.act[0])) { startExecution(tgt); return; } }
    if (p.act && (p.act.name === 'attack' || p.act.name === 'heavy')) {
      const a = p.act; if (a.name === 'attack' && a.t > a.d.act[0] * 1.0) a.queued = true; return;
    }
    if (p.act && p.act.name === 'hurt') return;
    doAttack();
  }
  // ----- heavy attacks: hold to charge (anticipation), release to strike, long recovery -----
  function tryHeavy() {
    const p = st.p; if (p.dead || p.spec || p.dodge || st.exec || st.cine && st.cine.lock) return;
    if (p.act && (p.act.name === 'draw' || p.act.name === 'sheath' || p.act.name === 'charge' || p.act.name === 'heavy' || p.act.name === 'plunge')) return;
    if (p.sheathed) { p.sheathed = false; p.drawK = 1; sfx('unsheath', p.x); }
    if (!p.grounded) { startPlunge(); return; }
    // L-L-H: a heavy pressed during the light chain becomes an instant combo-breaker finisher
    if (p.act && p.act.name === 'attack' && p.act.step >= 1 && p.act.t > p.act.d.act[0]) { p.heavyQ = true; return; }
    if (p.act && p.act.name === 'attack' && p.act.t < p.act.d.act[1]) return;
    startCharge(false);
  }
  function startCharge(instant) {
    const p = st.p, k = cls(), H = HEAVY[k]; const coil = Object.assign({}, READY[k], H.coil);
    startAct('charge', [{ t: 0.2, p: coil }, { t: 99, p: coil }], { lvl: 0, instant, speed: 1 });
    p.idleT = 0; p.trail = []; p.trail2 = []; sfx('charge', p.x, 0); notePattern('H');
    if (instant) { p.act.t = 0.16; p.act.lvl = 1; }
  }
  function releaseHeavy() {
    const p = st.p, a = p.act, k = cls(), H = HEAVY[k]; const lvl = a.lvl || 0; const mul = HEAVY_LVL[lvl].mul;
    const frames = resolveFrames(H.f, READY[k]);
    startAct('heavy', frames, { d: Object.assign({}, H, { heavy: true, fin: lvl >= 1, dmg: H.dmg * mul, kb: H.kb * (1 + lvl * 0.2), lvl, lunge: H.lunge * (0.8 + lvl * 0.15) }), speed: 1, lvl });
    if (lvl >= 2) { st.heavies++; } if (lvl >= 3 || (lvl >= 2 && !has('charge3'))) G.onEvent && G.onEvent('heavyfull');
    shake(3 + lvl * 2); if (k === 'dual' || k === 'spear') p.inv = Math.max(p.inv, 0.22);
    if (k === 'dual') sfx('dodge', p.x);
  }
  function updateCharge(a, dt) {
    const p = st.p; const maxL = has('charge3') ? 3 : 2;
    let lvl = 0; for (let i = 1; i <= maxL; i++) if (a.t >= HEAVY_LVL[i].t) lvl = i;
    if (lvl > a.lvl) { a.lvl = lvl; sfx('chargeReady', p.x, lvl); ring(p.x, p.y - 80, lvl >= 3 ? '#ff3a3a' : lvl === 2 ? '#ffb02a' : '#fff', 50 + lvl * 20, 0.3); p.glint = 0.3; if (lvl >= 2) shake(2); }
    if (Math.random() < 0.25 + a.lvl * 0.25) { const ang = rnd(0, 6.28), r = rnd(50, 90); part({ x: p.x + Math.cos(ang) * r, y: p.y - 80 + Math.sin(ang) * r, vx: -Math.cos(ang) * r * 3, vy: -Math.sin(ang) * r * 3, r: rnd(2, 4), col: a.lvl >= 3 ? '#ff3a3a' : a.lvl >= 2 ? '#ffb02a' : trailCol(), life: 0.3, type: 'glow' }); }
    if (Math.floor(a.t * 4) !== Math.floor((a.t - dt) * 4)) sfx('charge', p.x, a.lvl);
    p.vx *= Math.pow(0.001, dt);
    const maxT = HEAVY_LVL[maxL].t + 0.5;
    if (a.instant || !input.heavy || a.t > maxT) releaseHeavy();
  }
  function startPlunge() {
    const p = st.p; const k = cls(); const up = Object.assign({}, READY[k], PLUNGE_UP), down = Object.assign({}, READY[k], PLUNGE_DOWN);
    startAct('plunge', [{ t: 0.14, p: up }, { t: 0.22, p: down }, { t: 9, p: down }], { speed: 1 });
    p.vy = -260; p.vx *= 0.3; sfx('heavySwing', p.x); notePattern('P');
  }
  function plungeLand() {
    const p = st.p, wd = weaponDef(), k = wd.cls; const ix = p.x + p.facing * 30;
    shake(14); hitstop(0.08); sfx('boom', ix, 1.1); impactSound(ix, true); vib(60);
    part({ x: ix, y: GY + 2, type: 'crack', r: 100, life: 2.5 }); ring(ix, GY - 10, trailCol(), 150, 0.35); debris(ix, GY, st.S.ground, 12, 1.1); dust(ix, GY, 18, 'rgba(220,200,170,0.7)', 2);
    const r = has('plunge_quake') ? 200 : 120;
    for (const e of st.enemies) if (!e.dead && Math.abs(e.x - ix) < r && (!e.flying || e.y > GY - 160)) hitEnemy(e, wd.dmg * (has('plunge_quake') ? 2.2 : 1.6), Math.sign(e.x - ix) * 420, -480, { heavy: true, fin: true, poise: 2 });
    if (has('plunge_quake')) quakeWaves(ix, 0.7);
    hitBigProps(ix - r, ix + r, 2);
    startAct('heavy', resolveFrames([F(0.3, PLUNGE_DOWN), F(0.5, 'R')], READY[k]), { d: { act: [9, 9], f: [], dmg: 0 }, speed: 1 });
  }
  // ----- dodge: ground roll / backstep, air dash; i-frames; perfect dodge slows the world -----
  function tryDodge() {
    const p = st.p; if (p.dead || p.spec || st.exec || p.dodge || p.dodgeCd > 0 || st.cine && st.cine.lock) return;
    if (p.act && (p.act.name === 'heavy' && p.act.t < (p.act.d.act[1] || 0))) return; // committed
    if (!p.grounded && !has('air_dash')) return;
    if (!p.grounded && p.airDashed) return;
    const mvIn = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    const kind = !p.grounded ? 'dash' : (mvIn ? 'roll' : 'back');
    const dir = kind === 'back' ? -p.facing : (mvIn || p.facing);
    if (kind !== 'back') p.facing = dir;
    p.act = null; p.dodge = { kind, t: 0, dir, dur: kind === 'roll' ? 0.42 : kind === 'dash' ? 0.26 : 0.32, perfectChecked: false };
    p.inv = Math.max(p.inv, kind === 'back' ? 0.24 : 0.32); p.dodgeCd = 0.5; p.idleT = 0;
    if (kind === 'dash') { p.airDashed = true; p.vy = 0; }
    sfx('dodge', p.x); dust(p.x, GY, 5); notePattern('D');
  }
  function updateDodge(dt) {
    const p = st.p, d = p.dodge; d.t += dt; const k = d.t / d.dur;
    const sp = d.kind === 'roll' ? 620 : d.kind === 'dash' ? 900 : 480;
    p.vx = d.dir * sp * (1 - k * 0.6);
    if (d.kind === 'dash') { p.vy = Math.min(p.vy, 30); p.after.push({ x: p.x, y: p.y, pose: Object.assign({}, p.pose), t: 0, facing: p.facing, col: '#6a8aff' }); }
    const base = p.sheathed ? SHEATHED : READY[cls()];
    if (d.kind === 'roll') p.pose = lerpPose(p.pose, Object.assign({}, base, ROLL_POSE), 0.4);
    else if (d.kind === 'back') p.pose = lerpPose(p.pose, Object.assign({}, base, BACKSTEP_POSE), 0.35);
    else p.pose = lerpPose(p.pose, Object.assign({}, base, { t: 34, l1t: 60, l1s: 0, l2t: -30, l2s: -40 }), 0.4);
    if (d.kind === 'roll' && Math.random() < 0.4) dust(p.x, GY, 1);
    if (d.t >= d.dur) { p.dodge = null; p.vx *= 0.3; }
  }
  // ----- executions -----
  function startExecution(e) {
    const p = st.p, k = cls(), X = EXEC[k];
    p.facing = e.x > p.x ? 1 : -1; p.act = null; p.spec = null; p.dodge = null;
    const frames = resolveFrames(X.f, READY[k]);
    startAct('exec', frames, { speed: 1 });
    st.exec = { e, t: 0, k, X, hitI: 0, boss: !!e.boss };
    e.execT = 0.001; e.state = 'exec'; e.vx = 0; if (!e.boss) e.facing = -p.facing;
    p.inv = Math.max(p.inv, X.f[X.f.length - 1].t + 0.3);
    st.zoomT = e.boss ? 1.18 : 1.32; st.zoomX = (p.x + e.x) / 2; st.zoomY = GY - 80;
    sfx('execute', e.x); vib(40); shake(4);
    G.onEvent && G.onEvent('execstart', e);
  }
  function updateExecution(dt) {
    const ex = st.exec, p = st.p, e = ex.e, X = ex.X; ex.t += dt;
    if (!ex.boss) { const tx = p.x + p.facing * X.dist; e.x = lerp(e.x, tx, 0.3); if (!e.flying) { e.y = Math.min(e.y, GY); } }
    else p.x = lerp(p.x, e.x - p.facing * (e.w * 0.5 + 40), 0.15);
    // impaled enemies ride the spear
    if (X.lift && !ex.boss && ex.t > X.lift[0] && ex.t < X.lift[1]) { const tip = weaponTipWorld(); e.y = lerp(e.y, Math.min(GY, tip[1] + e.h * 0.5), 0.35); e.x = lerp(e.x, tip[0], 0.35); e.liftK = 1; }
    else if (X.lift && ex.t >= X.lift[1]) { e.y = lerp(e.y, GY, 0.5); }
    st.zoomX = lerp(st.zoomX, (p.x + e.x) / 2, 0.2);
    const hitT = X.hits[ex.hitI];
    if (hitT != null && ex.t >= hitT) {
      ex.hitI++; const last = ex.hitI >= X.hits.length; const wd = weaponDef();
      const hx = e.x, hy = e.flying ? e.y : e.y - e.h * 0.7;
      hitstop(last ? 0.16 : 0.08); shake(last ? 20 : 9); vib(last ? 90 : 30); impactSound(hx, true); if (last) sfx('gore', hx);
      blood(hx, hy, e.def.blood, last ? 60 : 24, p.facing, last ? 2 : 1.2); ring(hx, hy, '#ff2a2a', last ? 120 : 60, 0.3); st.flash = Math.max(st.flash, last ? 0.35 : 0.15);
      part({ x: hx, y: hy, type: 'slashmark', r: 110, rot: rnd(-0.8, 0.8), col: '#fff', life: 0.2 });
      for (let i = 0; i < (last ? 10 : 4); i++) decal(e.x + rnd(-40, 40), e.def.blood, 22);
      if (last) {
        if (ex.boss) { const dmg = e.maxHp * 0.08 + wd.dmg * 4; e.broken = 0; e.stagger = 0; e.hp -= dmg; e.flash = 0.2; txt(hx, hy - 50, 'BRUTAL ' + Math.round(dmg), '#ff3a3a', 30, 1.4); if (e.hp <= 0) killEnemy(e, true, p.facing); }
        else { e.execKill = X.fx; txt(e.x, e.y - e.h - 40, X.name, '#ff3a3a', 30, 1.6); e.hp = 0; killEnemy(e, true, p.facing, { exec: true }); }
        st.execs++; Save.d.executions = (Save.d.executions || 0) + 1; addXP(12); st.combo++; st.comboT = 2.2; st.bestCombo = Math.max(st.bestCombo, st.combo);
        p.rage = Math.min(p.rageMax, p.rage + 14 * p.rageMul + (has('exec_rage') ? 30 : 0));
        if (mlvl() >= 3) { p.hp = Math.min(p.maxHp, p.hp + 12); txt(p.x, p.y - 160, '+12', '#5aff7a', 16); }
        if (!ex.boss && Math.random() < 0.025 && !Save.d.relics.includes('relic_tears')) grantRelic('relic_tears', e.x);
        G.onEvent && G.onEvent('execute', { boss: ex.boss, count: Save.d.executions });
      } else { e.flash = 0.12; txt(hx, hy - 30, String(Math.round(wd.dmg)), '#fff', 18); }
    }
    if (!p.act || p.act.name !== 'exec' || ex.t > X.f[X.f.length - 1].t) { if (!e.dead) { e.execT = 0; e.state = 'stagger'; e.st = 0.5; } st.exec = null; st.zoomT = 1; }
  }
  function weaponTipWorld() { const p = st.p, wd = weaponDef(); const sk = solveSkeleton(p.pose, p.grounded); const f = p.facing * PS; const hand = sk.A1.hand; const tip = weaponPoint(hand[0], hand[1], p.pose.w, WTIP[wd.id]); return [p.x + tip[0] * f, p.y + tip[1] * PS]; }
  G.switchWeapon = (id) => {
    if (!st) return; const p = st.p; if (p.dead || p.spec || st.exec) return; if (id === p.weapon && !p.sheathed) return;
    Save.d.equipped = id; Save.save(); if (st.mem) st.mem.switches++;
    const swap = () => { p.weapon = id; p.sheathed = true; AudioSys.play('ui'); doDraw(false); txt(p.x, p.y - 160, WEAPONS.find(w => w.id === id).name, WEAPONS.find(w => w.id === id).trail, 16, 1.2); G.onEvent && G.onEvent('switch', id); };
    if (p.sheathed) swap(); else doSheath(swap);
  };
  function specCost() { return mlvl() >= 8 ? 40 : 50; }
  function trySpecial() {
    const p = st.p; const cost = specCost(); if (p.dead || p.spec || st.exec || st.cine && st.cine.lock || p.rage < cost) { if (p.rage < cost && !p.dead) { AudioSys.play('deny'); txt(p.x, p.y - 150, 'NOT ENOUGH RAGE', '#ff5a5a', 13, 0.7); } return; }
    if (p.sheathed) { p.sheathed = false; AudioSys.play('unsheath'); }
    p.rage -= cost; p.act = null; p.dodge = null; const k = cls(); p.spec = { type: k, t: 0, hit: new Set(), tick: 0 }; p.inv = Math.max(p.inv, 0.4); p.idleT = 0;
    AudioSys.play('heavySwing'); shake(4); st.zoomT = 1.08; st.zoomX = p.x; setTimeout(() => { if (st) st.zoomT = 1; }, 600);
    if (k === 'sword') { p.vy = -820; p.vx = p.facing * 260; p.grounded = false; AudioSys.play('jump'); }
    if (k === 'dual') { p.inv = 0.55; AudioSys.play('swing', 1.4); }
    if (k === 'scythe') { p.inv = 1.0; }
    G.onEvent && G.onEvent('special', k);
  }

  // ---------- damage ----------
  function hitEnemy(e, dmg, kbX, kbY, o = {}) {
    if (e.dead || e.spawnT > 0) return false;
    if (e.state === 'exec' && !o.exec) return false;
    if (e.boss && (e.intro > 0 || e.phaseT > 0)) { if (Math.random() < 0.3) { sparks(e.x, e.flying ? e.y : e.y - e.h * 0.5, '#fff', 4, 1); } return false; }
    const p = st.p, wd = weaponDef(), k = wd.cls; const R = REACT[e.type] || {}; const WA = WEAPON_AI[k];
    const hx = e.x, hy = e.flying ? e.y : e.y - e.h * 0.55;
    const dir = Math.sign(e.x - p.x) || p.facing;
    // --- evasion: predictable light-attack spam gets read and dodged ---
    if (!e.boss && !o.special && !o.heavy && !o.exec && !o.proj && e.state !== 'hurt' && e.state !== 'stagger' && e.state !== 'strike' && !e.liftK && (e.dodgeCd || 0) <= 0) {
      const ch = (R.dodge || 0) * (0.4 + st.predict * 1.6) * WA.dodge * (e.enraged ? 1.3 : 1) * (st.nm ? 1.3 : 1);
      if (Math.random() < ch) {
        e.dodgeCd = 1.4; e.state = 'evade'; e.st = 0.32; e.vx = dir * 420; if (!e.flying) { e.vy = -280; e.grounded = false; } else e.vy = -200;
        txt(hx, hy - 30, 'DODGED', '#9fb4c8', 14, 0.6); sfx('dodge', e.x); st.dodgedN = (st.dodgedN || 0) + 1;
        if (st.predict > 0.45) G.onEvent && G.onEvent('readyou');
        return false;
      }
    }
    // --- guarding: shields stop light hits from the front; heavy hits break the guard ---
    const front = Math.sign(p.x - e.x) === e.facing;
    if (!e.boss && R.block && front && !o.special && !o.exec && !o.proj && e.state !== 'stagger' && e.state !== 'hurt' && e.state !== 'strike' && e.state !== 'evade') {
      if ((e.guardT || 0) > 0 || Math.random() < R.block * WA.block * (0.6 + st.predict)) {
        if (o.heavy) {
          e.guardT = 0; e.state = 'stagger'; e.st = 1.7; e.poise = 0; sfx('guardBreak', e.x); txt(hx, hy - 40, 'GUARD BREAK', '#ffb02a', 20, 1); sparks(hx, hy, '#ffe8a0', 22, dir); shake(8); hitstop(0.08); e.vx = dir * 200;
          G.onEvent && G.onEvent('guardbreak'); return true;
        }
        e.guardT = 0.7; e.state = 'block'; e.st = 0.4; e.vx = dir * 140; sparks(hx + -dir * 10, hy, '#fff6c8', 10, -dir); sfx('block', e.x); txt(hx, hy - 30, 'BLOCKED', '#c8c8c8', 14, 0.6); hitstop(0.035); p.vx -= dir * 80;
        return false;
      }
    }
    // --- damage multipliers ---
    let mul = p.dmgMul * (1 + 0.04 * (mlvl() - 1));
    const wm = R.w ? (R.w[wd.id] ?? R.w[k] ?? 1) : 1; mul *= wm;
    if (e.state === 'stagger') mul *= 1.25;
    let crit = Math.random() < 0.12;
    if (p.riposteT > 0) { crit = true; mul *= 2.5 / 1.6; p.riposteT = 0; txt(hx, hy - 70, 'RIPOSTE', '#9fe8ff', 22, 1); sfx('perfect', e.x); }
    if (o.iaido) { crit = true; mul *= 2; txt(hx, hy - 70, 'IAIDO', '#fff', 22, 1); st.iaidoN = (st.iaidoN || 0) + 1; G.onEvent && G.onEvent('iaido'); }
    if (crit) mul *= 1.6;
    dmg = Math.round(dmg * mul);
    e.hp -= dmg; e.flash = 0.12; e.hitT = 0.18;
    // --- reactions: knockback, poise, stagger ---
    if (e.boss) {
      e.vx += kbX * 0.08; if (o.heavy) e.stagger = (e.stagger || 0) + 1;
      e.breakM = (e.breakM || 0) + dmg * (o.heavy ? 2.2 : 1) * (o.fin ? 1.3 : 1);
      if (!e.broken && !(e.intro > 0) && !(e.phaseT > 0) && e.breakM > e.maxHp * 0.12 && e.hp > 0) { e.breakM = 0; e.broken = 2.6; txt(e.x, e.y - e.h - 30, 'BROKEN — EXECUTE', '#ff3a3a', 22, 1.8); sfx('guardBreak', e.x); shake(10); G.onEvent && G.onEvent('bossbroken'); }
    } else {
      const res = e.def.heavy ? 0.45 : 1;
      e.vx = kbX * res; if (kbY && !e.flying) { e.vy = kbY * res; e.grounded = false; }
      if (e.flying) { e.vy = (kbY || -100) * 0.4; }
      if (o.pull) { e.vx = -dir * 260; }
      e.poise = (e.poise || 0) + (o.poise || (o.heavy ? 1.6 : o.fin ? 1 : 0.45)) * (k === 'hammer' ? 1.4 : 1);
      const maxPoise = e.def.heavy ? 5 : e.def.armor ? 4 : 3;
      if (e.state === 'stagger') { e.st = Math.max(e.st, 0.6); }
      else if (e.poise >= maxPoise && e.hp > 0) { e.poise = 0; e.state = 'stagger'; e.st = 1.7; txt(hx, hy - 50, 'STAGGERED', '#ffb02a', 15, 1); G.onEvent && G.onEvent('stagger'); }
      else { e.state = 'hurt'; e.st = o.heavy ? 0.45 : 0.28; }
      if (wm > 1.15 && !e.saidWeak) { e.saidWeak = 1; txt(hx, hy - 60, 'WEAK', '#ff6a3a', 14, 0.8); }
      if (wm < 0.85 && !e.saidRes) { e.saidRes = 1; txt(hx, hy - 60, 'RESISTS', '#8aa0b8', 14, 0.8); }
      if (!e.enraged && e.hp > 0 && e.hp < e.maxHp * 0.35) { e.enraged = true; sfx('growl', e.x, 1.2 / (e.def.voice || 1), 0.6); ring(e.x, hy, '#ff2020', 50, 0.3); }
    }
    // --- fx ---
    const bc = e.def.blood || '#a00';
    blood(hx, hy, bc, o.heavy ? 26 : 12, dir, o.heavy ? 1.4 : 1);
    if (e.def.armor || e.def.bone || e.type === 'iceGolem' || e.def.kind === 'eye') { sparks(hx, hy, '#ffe8a0', 12, dir); sfx('metal', e.x, rnd(0.8, 1.2)); }
    else sfx(o.heavy ? 'crunch' : 'flesh', e.x, rnd(0.8, 1.2));
    impactSound(e.x, o.heavy);
    ring(hx, hy, trailCol(), o.heavy ? 50 : 30, 0.18);
    part({ x: hx, y: hy, type: 'slashmark', r: o.heavy ? 70 : 48, rot: rnd(-0.8, 0.8), col: '#fff', life: 0.14 });
    light(hx, hy, o.heavy ? 160 : 90, 0.8, 0.12, '#ffd8b0');
    if (Math.random() < 0.5) decal(e.x + rnd(-20, 20), bc, 18);
    if (wm > 1.15) txt(hx + rnd(-10, 10), hy - 30, (crit ? 'CRIT ' : '') + dmg, '#ff7a3a', crit ? 24 : 19);
    else txt(hx + rnd(-10, 10), hy - 30, (crit ? 'CRIT ' : '') + dmg, crit ? '#ffd23a' : wm < 0.85 ? '#9aa8b8' : '#fff', crit ? 22 : 17);
    hitstop(o.heavy ? 0.09 : 0.045); shake(o.heavy ? 9 : 3.5); vib(o.heavy ? 30 : 12);
    // --- combo, rage, mastery ---
    st.combo++; st.comboT = 2.2; st.bestCombo = Math.max(st.bestCombo, st.combo);
    p.rage = Math.min(p.rageMax, p.rage + (o.special ? 2 : 6) * p.rageMul);
    if (!o.special) addXP(1);
    let ls = wd.lifesteal || 0; if (ls && wd.id === 'bloodfang' && mlvl() >= 5) ls *= 2; if (ls) p.hp = Math.min(p.maxHp, p.hp + dmg * ls);
    if (o.soul) { p.hp = Math.min(p.maxHp, p.hp + 1.5); part({ x: hx, y: hy, tx: 1, type: 'soul', col: '#5dffc1', life: 0.6, r: 5 }); }
    if (e.hp <= 0) killEnemy(e, o.fin || o.special, dir);
    G.onEvent && G.onEvent('hit', st.combo);
    return true;
  }
  function killEnemy(e, finisher, dir, ko = {}) {
    e.dead = true; e.deathT = 0; e.hp = 0; e.state = 'dead';
    const p = st.p; const fin = (SHOP.find(s => s.id === Save.d.finisher) || {}).fin || 'cleave';
    e.deathStyle = ko.exec ? (e.execKill === 'soul' ? 'soul' : e.execKill === 'crush' ? 'explode' : 'cleave') : finisher ? fin : 'collapse';
    e.dvx = dir * rnd(200, 380); e.dvy = rnd(-420, -200);
    if (finisher && !ko.exec) { st.slowmo = 0.35; st.slowT = 0.35; shake(12); txt(e.x, e.y - e.h - 30, ['BUTCHERED', 'EXECUTED', 'SEVERED', 'DESTROYED', 'ANNIHILATED'][Math.random() * 5 | 0], '#ff3a3a', 22, 1.1); blood(e.x, e.y - e.h * 0.5, e.def.blood, 40, dir, 1.6); }
    if (!e.boss) { const v = e.def.voice || 1; const r = Math.random(); sfx(r < 0.4 ? 'scream' : r < 0.75 ? 'scream2' : 'shriek', e.x, v * rnd(0.9, 1.1)); }
    st.kills++; Save.d.kills++; addXP(e.boss ? 30 : 4);
    // drops
    const val = (e.def.souls || 3) * st.soulMul; const nOrbs = Math.min(8, 2 + Math.floor(val / 3));
    for (let i = 0; i < nOrbs; i++) st.pickups.push({ type: 'soul', x: e.x, y: e.y - e.h * 0.5, vx: rnd(-200, 200), vy: rnd(-500, -200), val: Math.ceil(val / nOrbs * (1 + SD(st.idx) * 0.25)), t: 0 });
    if (!e.boss && Math.random() < (st.mods.includes('glass') ? 0 : 0.1)) st.pickups.push({ type: 'heal', x: e.x, y: e.y - 40, vx: rnd(-60, 60), vy: -300, t: 0 });
    p.rage = Math.min(p.rageMax, p.rage + 8 * p.rageMul);
    G.onEvent && G.onEvent('kill', e);
    if (e.boss) bossDeath(e);
  }
  function hurtPlayer(dmg, fromX, o = {}) {
    const p = st.p; if (p.dead || st.cleared || st.exec || st.cine && st.cine.lock) return false;
    if (p.inv > 0) {
      // perfect dodge: a hit lands inside the first moments of a dodge
      if (p.dodge && p.dodge.t < 0.2 && !p.dodge.perfect && has('perfect_dodge')) {
        p.dodge.perfect = true; st.witch = 1.3; sfx('perfect', p.x); txt(p.x, p.y - 170, 'PERFECT', '#9fe8ff', 22, 1); ring(p.x, p.y - 70, '#9fe8ff', 120, 0.4); st.perfects++; Save.d.perfectDodges = (Save.d.perfectDodges || 0) + 1;
        if (has('counter')) p.riposteT = 0.9; G.onEvent && G.onEvent('perfect', Save.d.perfectDodges);
      }
      return false;
    }
    // unstoppable heavies (Doom Hammer mastery): take the damage, keep swinging
    const armored = p.act && (p.act.name === 'heavy' || p.act.name === 'charge') && p.weapon === 'doomhammer' && mlvl() >= 5;
    dmg = Math.round(dmg * (1 + SD(st.idx) * 0.04) * p.defMul * (st.nm ? 1.5 : 1) * (st.mods.includes('frenzy') ? 1.15 : 1));
    if (st.mods.includes('glass')) dmg = Math.max(dmg, p.hp);
    p.hp -= dmg; p.inv = armored ? 0.4 : 0.85; st.dmgTaken += dmg; if (st.boss && !st.boss.dead) st.bossDmgTaken += dmg; p.flashT = 0.25;
    const dir = Math.sign(p.x - fromX) || -p.facing;
    if (!armored) { p.vx = dir * (o.kb || 380); if (p.grounded) { p.vy = -260; p.grounded = false; } if (!p.spec) { p.act = null; p.hurtT = 0.32; } p.dodge = null; }
    blood(p.x, p.y - 70, '#b0101a', 16, dir); sfx('hurt', p.x); shake(10); hitstop(0.07); vib(60); st.combo = 0;
    txt(p.x, p.y - 150, '-' + dmg, '#ff3a3a', 20);
    st.punishT = 1.2; st.lastHitBy = o.src || (st.boss && !st.boss.dead ? st.boss.key : 'minion');
    if (p.hp <= 0) {
      if (p.secondWind && !st.mods.includes('glass')) { p.secondWind = false; p.hp = Math.round(p.maxHp * 0.35); p.inv = 2; st.slowmo = 0.3; st.slowT = 1; st.flash = 0.6; ring(p.x, p.y - 70, '#ffd23a', 260, 0.6); sfx('holy', p.x); txt(p.x, p.y - 190, 'SECOND WIND', '#ffd23a', 26, 1.6); quakeHit(p.x, 220, weaponDef().dmg); G.onEvent && G.onEvent('secondwind'); return true; }
      p.hp = 0; playerDie(o);
    }
    G.onEvent && G.onEvent('hurt', p.hp / p.maxHp);
    return true;
  }
  function playerDie(o) {
    const p = st.p; if (p.dead) return;
    p.dead = true; p.deathT = 0; p.act = null; p.spec = null; p.dodge = null; st.exec = null; st.zoomT = 1; AudioSys.play('death'); AudioSys.setIntensity(0); st.slowmo = 0.6; st.slowT = 1.0;
    const final = st.idx === 9 && st.boss && !st.boss.dead;
    if (final) { st.eyekill = { t: 0 }; }
    G.onEvent && G.onEvent('playerdead', { final, by: st.lastHitBy });
  }
  G.hurtPlayer = (d, x, o) => hurtPlayer(d, x, o);

  // ---------- enemies ----------
  function spawnEnemy(type, x, opts = {}) {
    const def = ENEMIES[type]; const sc = def.scale;
    const lvl = (1 + SD(st.idx) * 0.22) * (st.nm ? 1.7 : 1) * (st.endless ? 1 + st.ewave * 0.08 : 1);
    const e = { type, def, x, y: GY, z: rnd(0, 26), vx: 0, vy: 0, facing: x < st.p.x ? 1 : -1, hp: def.hp * lvl, maxHp: def.hp * lvl, state: 'chase', st: 0, cd: rnd(0.6, 1.6), flash: 0, phase: rnd(0, 6), grounded: true, dead: false, deathT: 0,
      w: (def.kind === 'quad' ? 70 : def.kind === 'flyer' ? 46 : def.kind === 'blob' ? 54 : 40) * sc, h: (def.kind === 'quad' ? 60 : def.kind === 'flyer' ? 44 : def.kind === 'blob' ? 50 : 105) * sc, flying: def.kind === 'flyer', spawnT: 0.5, seed: rnd(0, 10),
      poise: 0, dodgeCd: 0, guardT: 0, slot: 0, token: false, enraged: false };
    if (e.flying) { e.baseY = GY - rnd(90, 150); e.y = e.baseY - 200; }
    st.enemies.push(e); return e;
  }
  G.spawnEnemy = spawnEnemy;

  // attack director: only a few enemies may commit to an attack at a time; the rest circle and wait for an opening
  function director(dt) {
    const p = st.p; const live = st.enemies.filter(e => !e.dead && !e.boss && e.spawnT <= 0);
    const melee = live.filter(e => !e.def.ranged);
    const maxTok = (st.mods.includes('frenzy') || st.nm ? 3 : 2) + (st.punishT > 0 ? 1 : 0);
    let tok = melee.filter(e => e.token).length;
    // release tokens that have gone stale
    for (const e of melee) if (e.token && (e.state === 'hurt' || e.state === 'stagger' || (e.tokT -= dt) <= 0)) { e.token = false; tok--; }
    // hand tokens to the closest waiting enemies, alternating sides to pincer the player
    const waiting = melee.filter(e => !e.token && (e.state === 'chase' || e.state === 'circle')).sort((a, b) => Math.abs(a.x - p.x) - Math.abs(b.x - p.x));
    let lastSide = st.lastTokSide || 0;
    while (tok < maxTok && waiting.length) {
      let i = waiting.findIndex(e => Math.sign(e.x - p.x) !== lastSide); if (i < 0) i = 0;
      const e = waiting.splice(i, 1)[0]; e.token = true; e.tokT = 2.6; tok++; lastSide = Math.sign(e.x - p.x); e.cd = Math.min(e.cd, st.punishT > 0 ? 0.05 : rnd(0.1, 0.5));
    }
    st.lastTokSide = lastSide;
    // holding slots on each side, so the pack surrounds the player
    const L = melee.filter(e => !e.token && e.x < p.x).sort((a, b) => b.x - a.x), Rr = melee.filter(e => !e.token && e.x >= p.x).sort((a, b) => a.x - b.x);
    // keep both sides populated: move one across if a side is empty and the other has 2+
    if (L.length === 0 && Rr.length >= 2) Rr[Rr.length - 1].flank = -1; if (Rr.length === 0 && L.length >= 2) L[L.length - 1].flank = 1;
    L.forEach((e, i) => e.slot = i); Rr.forEach((e, i) => e.slot = i);
    st.punishT = Math.max(0, (st.punishT || 0) - dt);
  }
  function updateEnemy(e, dt) {
    const p = st.p; const d = e.def;
    if (e.dead) { e.deathT += dt; if (e.deathStyle === 'collapse' || e.deathStyle === 'soul') { e.x += e.dvx * dt * Math.max(0, 1 - e.deathT * 2); } return; }
    if (e.flash > 0) e.flash -= dt; if (e.hitT > 0) e.hitT -= dt; e.dodgeCd -= dt; e.guardT -= dt;
    if (e.spawnT > 0) { e.spawnT -= dt; if (e.flying) e.y = lerp(e.y, e.baseY, 0.08); return; }
    if (e.state === 'exec') { e.phase += dt; return; }
    // perfect-dodge "witch time" slows the enemies only
    if (st.witch > 0) dt *= 0.3;
    const dx = p.x - e.x, adx = Math.abs(dx);
    e.st -= dt; e.cd -= dt * (e.enraged ? 1.6 : 1);
    if (e.state !== 'strike' && e.state !== 'windup' && e.state !== 'hurt' && e.state !== 'stagger' && e.state !== 'evade') e.facing = dx > 0 ? 1 : -1;
    const ai = WEAPON_AI[cls()];
    const spd = d.speed * (1 + SD(st.idx) * 0.03) * (e.enraged ? 1.35 : 1) * (st.mods.includes('frenzy') ? 1.2 : 1);
    if (e.enraged && Math.random() < dt * 8) part({ x: e.x + rnd(-e.w / 2, e.w / 2), y: (e.flying ? e.y : e.y - e.h * 0.5) + rnd(-e.h / 2, e.h / 2), vy: -60, r: rnd(2, 4), col: '#ff2020', life: 0.4, type: 'glow' });
    // physics
    if (!e.flying) { e.vy += 2000 * dt; e.y += e.vy * dt; if (e.y >= GY) { if (!e.grounded && e.vy > 300) { dust(e.x, GY, 6); sfx('land', e.x); } e.y = GY; e.vy = 0; e.grounded = true; } }
    e.x += e.vx * dt; e.vx *= Math.pow(0.0015, dt);
    if (st.lock) e.x = clamp(e.x, st.lock[0] - 80, st.lock[1] + 80);
    const meleeR = d.range * 0.8;
    switch (e.state) {
      case 'hurt': if (e.st <= 0 && e.grounded) { e.state = 'chase'; e.cd = Math.max(e.cd, 0.3); } if (e.flying) { e.y += e.vy * dt; e.vy *= 0.9; } break;
      case 'stagger': if (e.flying) { e.y = lerp(e.y, GY - 60, 0.04); } if (Math.random() < dt * 4) part({ x: e.x + rnd(-10, 10), y: (e.flying ? e.y : e.y - e.h) - 14, vx: rnd(-20, 20), vy: -40, r: 3, col: '#ffb02a', life: 0.5, type: 'glow' }); if (e.st <= 0) { e.state = 'chase'; e.poise = 0; e.cd = 0.4; } break;
      case 'block': if (e.st <= 0) { e.state = 'chase'; e.cd = Math.min(e.cd, 0.25); } break; // counter quickly after a block
      case 'evade': if (e.st <= 0 && (e.grounded || e.flying)) { e.state = 'chase'; e.cd = Math.min(e.cd, 0.35); e.token = true; e.tokT = 1.5; } if (e.flying) { e.y += e.vy * dt; e.vy *= 0.9; } break;
      case 'chase': case 'circle': {
        let want = 0;
        if (d.ranged) want = adx > d.range * 0.75 ? 1 : adx < 200 ? -1 : 0;
        else if (e.token || st.lock == null && adx > 520) want = adx > meleeR ? 1 : 0;
        else {
          // hold position in a ring around the player, spaced by slot, strafing a little
          const side = e.flank || (e.x < p.x ? -1 : 1); const hold = 170 + e.slot * 70 + Math.sin(st.T * 1.3 + e.seed) * 22;
          const tx = p.x + side * hold; const ddx = tx - e.x; want = Math.abs(ddx) > 18 ? Math.sign(ddx) * Math.sign(dx || 1) : 0; if (e.flank && Math.abs(ddx) < 40) e.flank = 0;
          e.state = 'circle';
        }
        const mvDir = d.ranged ? want * Math.sign(dx) : (e.state === 'circle' ? want * Math.sign(dx || 1) : want * Math.sign(dx));
        const mul = e.state === 'circle' ? 0.55 : ai.approach;
        const mv = mvDir * spd * mul; e.moving = !!mvDir;
        if (e.token) e.state = 'chase';
        if (d.teleport && adx > 260 && e.cd < 0.5 && Math.random() < 0.02) { glitchFX(e.x, e.y - 50); e.x = p.x - p.facing * rnd(70, 120); glitchFX(e.x, e.y - 50); sfx('glitch', e.x, 0.15); e.cd = 0.5; e.token = true; e.tokT = 1.5; }
        e.x += mv * dt; e.phase += dt * (Math.abs(mv) / 18 + 1);
        if (e.flying) { const ty = d.ranged ? e.baseY : (adx < 160 && e.token ? GY - 70 : e.baseY); e.y = lerp(e.y, ty + Math.sin(st.T * 3 + e.seed) * 14, 0.05); }
        if (Math.abs(mv) > 0 && !e.flying && Math.random() < dt * 3) sfx('step', e.x);
        // react to a heavy charge: the smart ones back off, the brave ones rush in to interrupt
        if (p.act && p.act.name === 'charge' && adx < 220 && !e.boss && Math.random() < dt * 2) { if (ai.dodge > 1 || Math.random() < 0.5) { e.vx = -Math.sign(dx) * 300; } else { e.token = true; e.tokT = 1.2; e.cd = 0; } }
        const canAtk = d.ranged ? adx < 520 : (e.token && adx < d.range);
        if (e.cd <= 0 && canAtk) {
          e.state = 'windup'; e.st = (d.ranged ? 0.55 : (d.heavy ? 0.7 : 0.45)) * (e.enraged ? 0.75 : 1); e.wdur = e.st;
          if (Math.random() < 0.4) sfx('growl', e.x, 1.5 / (d.voice || 1), 0.4);
          // a quick telegraph glint so attacks can be read
          part({ x: e.x + e.facing * 16, y: (e.flying ? e.y : e.y - e.h * 0.8), type: 'glint', r: 16, life: 0.25, col: e.enraged ? '#ff4040' : '#fff' });
        }
        // separation
        for (const o of st.enemies) if (o !== e && !o.dead && Math.abs(o.x - e.x) < 34 && o.flying === e.flying) e.x += (e.x < o.x ? -1 : 1) * 50 * dt;
        break;
      }
      case 'windup': if (e.flying && !d.ranged) e.y = lerp(e.y, p.y - 70, 0.05); if (e.st <= 0) { e.state = 'strike'; e.st = 0.22; e.struck = false; if (d.kind === 'quad') { e.vx = e.facing * 520; e.vy = -300; e.grounded = false; } else if (!d.ranged) e.vx = e.facing * (e.enraged ? 240 : 160); } break;
      case 'strike':
        if (!e.struck) {
          e.struck = true;
          if (d.ranged) { fireProj(d.ranged, e.x + e.facing * 20, e.flying ? e.y : e.y - e.h * 0.65, p.x + (e.enraged ? p.vx * 0.3 : 0), p.y - 60); }
          else { sfx('swing', e.x, 0.7); }
        }
        if (!d.ranged && !e.didHit) { const ey = e.flying ? e.y : e.y - e.h * 0.5; if (Math.abs(p.x - (e.x + e.facing * d.range * 0.4)) < d.range * 0.75 && Math.abs((p.y - 60) - ey) < 90) { if (hurtPlayer(d.dmg * (1 + SD(st.idx) * 0.05) * (e.enraged ? 1.2 : 1), e.x, { src: e.type })) e.didHit = true; }
          for (const dg of dogs()) if (dg && !dg.dead && !e.didHitDog && Math.abs(dg.x - (e.x + e.facing * d.range * 0.4)) < d.range * 0.7 && Math.abs((dg.y - 25) - ey) < 80) { if (hurtPercy(d.dmg * 0.8, e.x, dg)) e.didHitDog = true; } }
        if (e.st <= 0) {
          e.didHitDog = false;
          // enraged melee enemies chain a second strike
          if (e.enraged && !d.ranged && !e.chained && Math.random() < 0.5) { e.chained = true; e.state = 'windup'; e.st = 0.25; e.wdur = 0.25; e.didHit = false; break; }
          e.state = 'chase'; e.didHit = false; e.chained = false; e.cd = d.cd * rnd(0.8, 1.3) * (e.enraged ? 0.6 : 1); if (!d.ranged) { e.token = false; }
        }
        break;
    }
  }
  function glitchFX(x, y) { for (let i = 0; i < 10; i++) part({ x: x + rnd(-30, 30), y: y + rnd(-50, 50), type: 'glitch', w: rnd(10, 50), h: rnd(2, 8), col: Math.random() < 0.5 ? '#fff' : '#000', life: rnd(0.1, 0.3) }); }
  G.glitchFX = glitchFX;

  // ---------- projectiles ----------
  const PROJ = {
    arrow: { sp: 620, dmg: 8, r: 6, g: 0, col: '#d8d0b0' }, fireball: { sp: 420, dmg: 10, r: 10, g: 0, col: '#ff7a1a' }, icicle: { sp: 520, dmg: 11, r: 8, g: 0, col: '#bff4ff' }, eyebolt: { sp: 460, dmg: 13, r: 9, g: 0, col: '#ff1a1a' },
    bomb: { sp: 0, dmg: 16, r: 10, g: 1200, col: '#333', explode: 70 }, boulder: { sp: 0, dmg: 24, r: 26, g: 1400, col: '#bfeaff', roll: true }, acid: { sp: 0, dmg: 14, r: 11, g: 1200, col: '#9aff3a', puddle: true }, ink: { sp: 0, dmg: 16, r: 12, g: 1100, col: '#0a1a1a', explode: 60 },
    feather: { sp: 560, dmg: 12, r: 7, g: 0, col: '#fff6d0' }, sonic: { sp: 380, dmg: 14, r: 22, g: 0, col: '#c080ff' }, shock: { sp: 480, dmg: 16, r: 24, g: 0, col: '#ffcf80', ground: true }, frost: { sp: 420, dmg: 18, r: 28, g: 0, col: '#bff4ff', ground: true },
    wave: { sp: 360, dmg: 22, r: 40, g: 0, col: '#2adbc0', ground: true }, meteor: { sp: 0, dmg: 24, r: 18, g: 900, col: '#ff5a1a', explode: 90 }, drop: { sp: 0, dmg: 12, r: 8, g: 1300, col: '#c0102a', explode: 40 }, spear: { sp: 0, dmg: 22, r: 8, g: 2200, col: '#fff2b0', explode: 50 },
    glitchwave: { sp: 520, dmg: 20, r: 34, g: 0, col: '#fff', ground: true }, iceshard: { sp: 0, dmg: 14, r: 9, g: 1300, col: '#bfeaff', explode: 40 },
  };
  function fireProj(type, x, y, tx, ty, o = {}) {
    const P0 = PROJ[type]; const a = Math.atan2(ty - y, tx - x); const sp = o.sp || P0.sp;
    const pr = Object.assign({ type, x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, r: P0.r, dmg: P0.dmg * (1 + SD(st.idx) * 0.06), g: P0.g, life: o.life || 4, t: 0, enemy: true }, o);
    if (P0.ground) { pr.y = GY - pr.r * 0.6; pr.vy = 0; pr.vx = Math.sign(tx - x) * sp; }
    st.projs.push(pr); if (type === 'fireball' || type === 'meteor') AudioSys.play('fire'); else if (type === 'icicle') AudioSys.play('ice'); else if (type === 'eyebolt' || type === 'sonic') AudioSys.play('zap'); else if (type === 'arrow' || type === 'feather') AudioSys.play('swing', 1.6);
    return pr;
  }
  function lob(type, x, y, tx, time = 1.0, o = {}) { const P0 = PROJ[type]; const vx = (tx - x) / time; const vy = (GY - 10 - y - 0.5 * P0.g * time * time) / time; return fireProj(type, x, y, x + 1, y, Object.assign({ vx, vy }, o)); }
  G.fireProj = fireProj; G.lob = lob;
  function explode(x, y, r, dmg, col) {
    ring(x, y, col, r, 0.35); for (let i = 0; i < 18; i++) part({ x, y, vx: rnd(-1, 1) * r * 6, vy: rnd(-1, 0.2) * r * 6, r: rnd(4, 10), col, life: rnd(0.3, 0.6), type: 'dust' }); sparks(x, y, col, 10);
    AudioSys.play('boom', 0.6); shake(7); if (Math.abs(st.p.x - x) < r && Math.abs(st.p.y - 50 - y) < r + 50) hurtPlayer(dmg, x);
  }
  function updateProjs(dt) {
    const p = st.p;
    for (const pr of st.projs) {
      pr.t += dt; pr.vy += pr.g * dt; pr.x += pr.vx * dt; pr.y += pr.vy * dt;
      if (pr.enemy) {
        const py = p.y - 60, hit = Math.abs(pr.x - p.x) < pr.r + 18 && Math.abs(pr.y - py) < pr.r + (PROJ[pr.type].ground ? 30 : 55);
        for (const dg of dogs()) if (dg && !dg.dead && !pr.done && !pr.intro && Math.abs(pr.x - dg.x) < pr.r + 24 && Math.abs(pr.y - (dg.y - 25)) < pr.r + 30) { if (hurtPercy(pr.dmg * 0.8, pr.x, dg) && !PROJ[pr.type].ground && !PROJ[pr.type].roll) pr.done = true; }
        if (hit && !pr.done && !pr.intro) { if (hurtPlayer(pr.dmg, pr.x - pr.vx * 0.01)) { if (PROJ[pr.type].explode) explode(pr.x, pr.y, PROJ[pr.type].explode, 0, PROJ[pr.type].col); if (!PROJ[pr.type].ground && !PROJ[pr.type].roll) pr.done = true; } }
        // player can parry/cut projectiles with active attack
        if (!PROJ[pr.type].ground && !PROJ[pr.type].roll && p.act && p.act.name === 'attack' && p.act.activeNow && Math.abs(pr.x - (p.x + p.facing * 50)) < 70 && Math.abs(pr.y - py) < 80) { pr.done = true; sparks(pr.x, pr.y, '#fff', 10); AudioSys.play('metal', 1.5); txt(pr.x, pr.y - 20, 'DEFLECT', '#9fe8ff', 14); }
        if (pr.y >= GY - 4 && pr.g > 0) {
          if (PROJ[pr.type].roll) { pr.y = GY - pr.r; pr.vy = -Math.abs(pr.vy) * 0.3; if (Math.abs(pr.vy) < 80) { pr.vy = 0; pr.g = 0; } if (!pr.rolled) { pr.rolled = true; shake(8); AudioSys.play('boom', 0.5); dust(pr.x, GY, 12); pr.vx = Math.sign(p.x - pr.x) * 420; } }
          else { pr.done = true; if (PROJ[pr.type].explode) explode(pr.x, GY - 10, PROJ[pr.type].explode, pr.dmg, PROJ[pr.type].col); if (PROJ[pr.type].puddle) st.hazards.push({ type: 'acid', x: pr.x, w: 70, warn: 0, active: 3, dmg: 8, t: 0, tick: 0 }); }
        }
      } else {
        // player projectile (void lance / quake)
        for (const e of st.enemies) { if (e.dead || pr.hitSet.has(e)) continue; const ey = e.flying ? e.y : e.y - e.h * 0.5; if (Math.abs(e.x - pr.x) < pr.r + e.w / 2 && (pr.ground ? !e.flying || e.y > GY - 120 : Math.abs(ey - pr.y) < pr.r + e.h / 2)) { pr.hitSet.add(e); hitEnemy(e, pr.dmg, Math.sign(pr.vx) * 400, pr.ground ? -500 : -200, { heavy: true, special: true, fin: true }); } }
        if (pr.ground && Math.random() < 0.6) { debris(pr.x, GY, st.S.ground, 1, 0.6); dust(pr.x, GY, 1); }
        if (pr.type === 'lance') { part({ x: pr.x, y: pr.y + rnd(-6, 6), vx: -pr.vx * 0.05, r: rnd(3, 8), col: '#a67cff', life: 0.35, type: 'glow' }); }
        for (const pp of st.props) if (!pp.broken && Math.abs(pp.x - pr.x) < 30) breakProp(pp);
      }
      if (pr.t > pr.life || pr.x < st.camX - 300 || pr.x > st.camX + W + 300) pr.done = true;
      if (pr.type === 'fireball' || pr.type === 'meteor') part({ x: pr.x, y: pr.y, vx: rnd(-30, 30), vy: rnd(-60, -10), r: rnd(3, 7), col: Math.random() < 0.5 ? '#ff7a1a' : '#ffd040', life: 0.3, type: 'glow' });
    }
    st.projs = st.projs.filter(p => !p.done);
  }

  // ---------- hazards & beams ----------
  G.hazard = (o) => st.hazards.push(Object.assign({ t: 0, tick: 0 }, o));
  G.beam = (o) => st.beams.push(Object.assign({ t: 0 }, o));
  function updateHazards(dt) {
    const p = st.p;
    for (const h of st.hazards) {
      h.t += dt;
      if (h.t > h.warn && h.t < h.warn + h.active) {
        if (!h.fired) { h.fired = true; if (h.type === 'spike') { AudioSys.play('crunch'); debris(h.x, GY, '#888', 4); shake(4); } if (h.type === 'tentacle') { AudioSys.play('wet'); shake(6); } if (h.type === 'pillar') { AudioSys.play('beam'); shake(5); } if (h.type === 'icespike') AudioSys.play('ice'); }
        const inX = Math.abs(p.x - h.x) < h.w / 2 + 12; const inY = h.type === 'acid' ? p.y > GY - 10 : (h.type === 'pillar' ? true : p.y > GY - (h.h || 110));
        for (const dg of dogs()) if (dg && !dg.dead && h.dmg > 0 && Math.abs(dg.x - h.x) < h.w / 2 + 12 && !h.hitD) { if (h.type === 'acid') { if (hurtPercy(h.dmg * 0.5, h.x, dg)) {} } else if (hurtPercy(h.dmg, h.x, dg)) h.hitD = true; }
        if (inX && inY && h.dmg > 0) { if (h.type === 'acid') { h.tick -= dt; if (h.tick <= 0) { h.tick = 0.4; hurtPlayer(h.dmg, h.x, { kb: 120 }); } } else if (!h.hitP) { if (hurtPlayer(h.dmg, h.x)) h.hitP = true; } }
      }
    }
    st.hazards = st.hazards.filter(h => h.t < h.warn + h.active + 0.4);
    for (const b of st.beams) {
      b.t += dt;
      if (b.t > b.warn && b.t < b.warn + b.active) {
        if (!b.fired) { b.fired = true; AudioSys.play('beam'); shake(10); }
        const by = b.y; const x0 = Math.min(b.x0, b.x1), x1 = Math.max(b.x0, b.x1);
        for (const dg of dogs()) if (dg && !dg.dead && !b.hitD && b.dmg > 0 && dg.x > x0 && dg.x < x1 && Math.abs((dg.y - 25) - by) < b.thick / 2 + 25) { if (hurtPercy(b.dmg, b.x0, dg)) b.hitD = true; }
        if (p.x > x0 && p.x < x1 && Math.abs((p.y - 60) - by) < b.thick / 2 + 50 && !b.hitP && b.dmg > 0) { if (hurtPlayer(b.dmg, b.x0, { kb: 500 })) b.hitP = true; }
      }
    }
    st.beams = st.beams.filter(b => b.t < b.warn + b.active + 0.3);
  }

  // ---------- props ----------
  function breakProp(pp) {
    pp.broken = true; debris(pp.x, pp.y - 20, PROP_COL[pp.type], 12, 1); dust(pp.x, pp.y, 8); AudioSys.play('crunch'); shake(4);
    if (Math.random() < 0.7) for (let i = 0; i < 3; i++) st.pickups.push({ type: 'soul', x: pp.x, y: pp.y - 30, vx: rnd(-150, 150), vy: rnd(-400, -200), val: 2 + st.idx, t: 0 });
    if (Math.random() < 0.15) st.pickups.push({ type: 'heal', x: pp.x, y: pp.y - 30, vx: 0, vy: -300, t: 0 });
    Save.d.destroyed++; G.onEvent && G.onEvent('destroy');
  }

  // ---------- player update ----------
  function updatePlayer(dt) {
    const p = st.p; const wd = weaponDef(); const k = wd.cls;
    p.inv -= dt; p.flashT -= dt; p.hurtT -= dt; p.idleT += dt; p.landT -= dt; p.jumpBuf -= dt; p.coyote -= dt; p.dodgeCd -= dt; p.riposteT -= dt;
    if (p.dead) {
      p.deathT += dt; p.vx *= 0.9; p.x += p.vx * dt; if (!p.grounded) { p.vy += 2000 * dt; p.y += p.vy * dt; if (p.y >= GY) { p.y = GY; p.grounded = true; dust(p.x, GY, 10); AudioSys.play('land'); } }
      const kk = clamp(p.deathT / 0.9, 0, 1); p.pose = lerpPose(p.pose, P({ t: -30 + kk * -60, h: -30, a1u: 120, a1f: 150, a2u: 140, a2f: 170, l1t: 60, l1s: -40, l2t: 40, l2s: -60 }), 0.1); return;
    }
    // input
    const mvIn = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    if (input.jumpP) { p.jumpBuf = 0.15; input.jumpP = false; }
    if (st.cine && st.cine.lock) { input.attackP = input.specialP = input.heavyP = input.dodgeP = false; p.jumpBuf = 0; }
    if (input.dodgeP) { input.dodgeP = false; tryDodge(); }
    if (input.attackP) { input.attackP = false; tryAttack(); }
    if (input.heavyP) { input.heavyP = false; tryHeavy(); }
    if (input.specialP) { input.specialP = false; trySpecial(); }
    const atkLock = p.act && (p.act.name === 'attack' || p.act.name === 'heavy') && p.act.t < ((p.act.d.act[1] || 0) / p.act.speed);
    const busy = p.act && (p.act.name === 'exec' || p.act.name === 'charge' || p.act.name === 'plunge');
    // specials
    if (p.spec) { updateSpecial(dt); }
    else if (p.dodge) { updateDodge(dt); }
    else if (busy) { if (p.act.name !== 'plunge') p.vx *= Math.pow(0.0005, dt); }
    else {
      let accel = p.grounded ? 3200 : 1800; let maxV = 300 * p.spdMul * (st.cine && st.cine.lock ? 0 : 1);
      if (p.act && p.act.name === 'attack') maxV = 90; if (p.act && p.act.name === 'heavy') maxV = 40; if (p.hurtT > 0) { maxV = 0; }
      if (mvIn && p.hurtT <= 0) { if (!atkLock) p.facing = mvIn; p.vx += mvIn * accel * dt; p.vx = clamp(p.vx, -Math.max(maxV, Math.abs(p.vx) > maxV ? Math.abs(p.vx) * 0.96 : maxV), Math.max(maxV, Math.abs(p.vx) > maxV ? Math.abs(p.vx) * 0.96 : maxV)); }
      else p.vx *= Math.pow(p.grounded ? 0.00002 : 0.3, dt);
      if (p.jumpBuf > 0 && (p.grounded || p.coyote > 0) && p.hurtT <= 0) { p.vy = -760; p.grounded = false; p.jumpBuf = 0; p.coyote = 0; p.jumps = 1; sfx('jump', p.x); dust(p.x, GY, 6); if (p.act && p.act.name === 'attack') p.act = null; }
      else if (p.jumpBuf > 0 && !p.grounded && p.coyote <= 0 && has('double_jump') && p.jumps < 2 && p.hurtT <= 0) { p.vy = -680; p.jumpBuf = 0; p.jumps = 2; sfx('wings', p.x, 1.5); ring(p.x, p.y, '#9fb4ff', 40, 0.25); for (let i = 0; i < 8; i++) part({ x: p.x + rnd(-20, 20), y: p.y, vx: rnd(-120, 120), vy: rnd(40, 160), r: rnd(2, 4), col: '#c8d4ff', life: 0.4, type: 'glow' }); if (p.act && p.act.name === 'attack') p.act = null; G.onEvent && G.onEvent('doublejump'); }
    }
    // physics
    p.vy += (p.spec && p.spec.type === 'dual' ? 0 : 2000) * dt; p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.y >= GY) { if (!p.grounded) { p.jumps = 0; p.airHits = 0; p.airDashed = false; if (p.act && p.act.name === 'plunge') { p.y = GY; p.grounded = true; plungeLand(); } p.landT = 0.14; sfx('land', p.x); dust(p.x, GY, p.vy > 900 ? 14 : 6); if (p.act && p.act.air) { const d = p.act.d; if (d.slamDown) { shake(8); quakeHit(p.x, 130, wd.dmg * 1.2); } } } p.y = GY; p.vy = 0; p.grounded = true; p.coyote = 0.1; }
    else { if (p.grounded) p.coyote = 0.1; p.grounded = false; }
    const LM = G.portrait ? 24 : Math.min(150, W * 0.13); const minX = st.lock ? st.lock[0] + LM : 40, maxX = st.lock ? st.lock[1] - LM : st.len + 400; p.x = clamp(p.x, minX, maxX);
    // action anims
    if (p.act) {
      const a = p.act; a.t += dt * (a.speed || 1);
      if (a.name === 'draw') {
        if (a.t >= 0.17 && !a.ev.grab) { a.ev.grab = 1; sfx('unsheath', p.x); }
        p.drawK = clamp((a.t - 0.19) / 0.13, 0, 1);
        if (a.t >= 0.43 && !a.ev.shine) { a.ev.shine = 1; sfx('shing', p.x); p.glint = 0.35; if (cls() !== 'hammer') for (let i = 0; i < 4; i++) part({ x: p.x + p.facing * rnd(20, 60), y: p.y - rnd(80, 130), vx: p.facing * rnd(60, 200), vy: rnd(-80, 60), r: 2, col: '#8a0010', life: 0.5, type: 'drop' }); }
        if (a.thenAttack && a.t >= 0.36) { p.act = null; p.drawK = 1; doAttack(); p.act && (p.act.iaido = p.weapon === 'executioner' && mlvl() >= 5); }
      } else if (a.name === 'sheath') {
        if (a.t >= a.flickAt && !a.ev.flick) { a.ev.flick = 1; sfx('swing', p.x, 1.3); }
        p.drawK = 1 - clamp((a.t - 0.3) / 0.14, 0, 1);
        if (a.t >= 0.44 && !a.ev.in) { a.ev.in = 1; p.sheathed = true; sfx('sheath', p.x); }
      } else if (a.name === 'attack' || a.name === 'heavy') updateAttack(a, dt);
      else if (a.name === 'charge') updateCharge(a, dt);
      else if (a.name === 'plunge') { if (a.t > 0.14 && !a.ev.dive) { a.ev.dive = 1; p.vy = 1900; p.vx = p.facing * 80; } p.inv = Math.max(p.inv, 0.05); if (a.t > 0.14) p.after.push({ x: p.x, y: p.y, pose: Object.assign({}, p.pose), t: 0, facing: p.facing }); }
      else if (a.name === 'exec') { /* driven by updateExecution */ }
      if (p.act === a) {
        p.pose = actPose(a);
        // L-L-H: release a heavy straight out of the light chain
        if (a.name === 'attack' && p.heavyQ && a.t >= a.d.act[1]) { p.heavyQ = false; p.act = null; p.step = 0; startCharge(true); }
        else if (a.t >= a.dur && a.name !== 'charge' && a.name !== 'plunge') { const then = a.then; const q = a.queued && a.name === 'attack'; const wasAir = a.air; p.act = null; if (then) then(); else if (q) { if (!wasAir) p.step++; doAttack(); } else if (a.name === 'attack') { p.step = 0; } }
      }
    }
    if (!p.act && !p.spec) {
      // locomotion pose
      const speed = Math.abs(p.vx); const base = p.sheathed ? SHEATHED : READY[k];
      let target;
      if (!p.grounded) {
        target = Object.assign({}, base, p.vy < 0 ? { t: 4, l1t: 55, l1s: -5, l2t: 5, l2s: -45 } : { t: 8, l1t: 25, l1s: 15, l2t: -15, l2s: -30 });
        if (p.sheathed) Object.assign(target, { a1u: 60, a1f: 100, a2u: -40, a2f: -10 });
      } else if (speed > 30) {
        p.phase += dt * speed / 26; const s = Math.sin(p.phase), c2 = Math.sin(p.phase + Math.PI);
        p.stepAcc += dt * speed; if (p.stepAcc > 70) { p.stepAcc = 0; AudioSys.play('step'); if (Math.random() < 0.5) dust(p.x - p.facing * 10, GY, 1); }
        const run = clamp(speed / 300, 0, 1);
        target = Object.assign({}, base, { t: 6 + 10 * run, bY: 0,
          l1t: 34 * s * run + 4, l1s: 34 * s * run + 4 - 42 * Math.max(0, Math.sin(p.phase - 1.4)) * run,
          l2t: 34 * c2 * run + 4, l2s: 34 * c2 * run + 4 - 42 * Math.max(0, Math.sin(p.phase - 1.4 + Math.PI)) * run });
        if (p.sheathed) Object.assign(target, { a1u: -34 * s * run, a1f: -34 * s * run + 50, a2u: 34 * s * run, a2f: 34 * s * run + 50 });
        else { const ra = RUNARM[k]; Object.assign(target, ra, { a1u: ra.a1u + 8 * s, a2u: ra.a2u - 10 * s }); }
      } else {
        const br = Math.sin(st.T * 2.2);
        target = Object.assign({}, base, { t: base.t + br * 1.5, a1u: base.a1u + br * 2, a2u: base.a2u - br * 2, h: br * 2 });
        if (p.landT > 0) Object.assign(target, { l1t: 45, l1s: -20, l2t: -10, l2s: -55, t: base.t + 10 });
        if (!p.sheathed && p.idleT > 7 && !anyEnemyNear()) doSheath();
      }
      if (p.hurtT > 0) target = Object.assign({}, target, { t: -22, h: -25, a2u: 60, a2f: 90 });
      p.pose = lerpPose(p.pose, target, clamp(dt * 18, 0, 1));
    }
    // world-space weapon tip tracking for trails
    trackTrail(p);
    // props contact by attacks handled in attack
  }
  function anyEnemyNear() { return st.enemies.some(e => !e.dead && Math.abs(e.x - st.p.x) < 700) || (st.boss && !st.boss.dead); }

  function attackBox(p, range, back) { const f = p.facing; const x0 = p.x - f * back, x1 = p.x + f * range; return [Math.min(x0, x1), Math.max(x0, x1), p.y - 175, p.y + 10]; }
  function overlapE(box, e) { const ey0 = e.flying ? e.y - e.h / 2 : e.y - e.h, ey1 = e.flying ? e.y + e.h / 2 : e.y; return e.x + e.w / 2 > box[0] && e.x - e.w / 2 < box[1] && ey1 > box[2] && ey0 < box[3]; }
  function updateAttack(a, dt) {
    const p = st.p, wd = weaponDef(), d = a.d, k = wd.cls;
    const t0 = d.act[0], t1 = d.act[1];
    a.activeNow = a.t >= t0 && a.t <= t1;
    if (a.t >= t0 && !a.ev.sw) {
      a.ev.sw = 1; sfx(d.heavy || k === 'hammer' ? 'heavySwing' : 'swing', p.x, k === 'dual' ? 1.5 : k === 'spear' ? 1.25 : k === 'scythe' ? 0.85 : 1);
      if (d.lunge && p.grounded) p.vx = p.facing * d.lunge;
      if (d.dash) { p.inv = Math.max(p.inv, 0.3); }
      // combo names on the 3rd and 5th steps
      if (a.name === 'attack' && !a.air) { const nm = COMBO_NAMES[k] && COMBO_NAMES[k][a.step]; if (nm) { txt(p.x, p.y - 190, nm, trailCol() === '#ffffff' ? '#ffe6a0' : trailCol(), a.step === 4 ? 22 : 17, 0.9); if (a.step === 4) G.onEvent && G.onEvent('combo5'); } }
      // Moon Cleaver: charged sword heavies release a crescent wave
      if (d.wave === 'crescent' && d.lvl >= 2) { st.projs.push({ type: 'crescent', x: p.x + p.facing * 60, y: p.y - 80, vx: p.facing * 1100, vy: 0, r: 40, g: 0, life: 0.55, t: 0, enemy: false, dmg: wd.dmg * (d.lvl >= 3 ? 2.6 : 1.6), hitSet: new Set(), facing: p.facing }); sfx('zap', p.x, 0.7); }
    }
    if (d.rehit && a.t >= d.rehit && !a.ev.rh) { a.ev.rh = 1; a.hit = new Set(); }
    if (d.rehits) for (let i = 0; i < d.rehits.length; i++) if (a.t >= d.rehits[i] && !a.ev['rh' + i]) { a.ev['rh' + i] = 1; a.hit = new Set(); sfx('swing', p.x, 1.4); }
    if (d.impact && a.t >= d.impact && !a.ev.imp) {
      a.ev.imp = 1; const ix = p.x + p.facing * wd.range * 0.7; const big = d.heavy || d.big;
      shake(big ? 12 : 6); dust(ix, GY, 14, 'rgba(200,180,150,0.6)', 1.6); debris(ix, GY, st.S.ground, 6, 0.8); sfx('boom', ix, big ? 0.9 : 0.5); part({ x: ix, y: GY + 2, type: 'crack', r: big ? 70 + (d.lvl || 0) * 20 : 40, life: 2.5 }); light(ix, GY - 30, 220, 0.8, 0.2, '#ffb070');
      if (d.quake) { quakeWaves(ix, d.lvl >= 2 ? 0.9 : 0.6); hitBigProps(ix - 140, ix + 140, 1); }
    }
    if (a.activeNow) {
      const range = wd.range * (d.rangeMul || 1) * (d.pierce && p.weapon === 'voidspear' && mlvl() >= 5 ? 1.3 : 1); const box = attackBox(p, range, wd.backhit ? 70 : 14);
      for (const e of st.enemies) if (!a.hit.has(e) && overlapE(box, e)) {
        // a normal thrust stops at the first body; Heaven Piercer goes through everything
        if (d.pierce === undefined && k === 'spear' && a.name === 'heavy' && a.hit.size >= 1) continue;
        a.hit.add(e); const dir = Math.sign(e.x - p.x) || p.facing;
        const pull = d.pull || (k === 'scythe' && p.weapon === 'soulreaper' && mlvl() >= 5 && !d.heavy);
        hitEnemy(e, wd.dmg * d.dmg, dir * wd.kb * d.kb, d.up || (d.heavy ? -320 : 0), { heavy: d.heavy, fin: d.fin || d.big, soul: d.soul, pull, iaido: a.iaido && a.hit.size === 1 });
      }
      if (a.iaido && a.hit.size) a.iaido = false;
      for (const pp of st.props) if (!pp.broken && !a.hit.has(pp) && pp.x > box[0] - 20 && pp.x < box[1] + 20) { a.hit.add(pp); pp.hp--; pp.hitT = 0.2; sparks(pp.x, pp.y - 25, '#ffd', 4); if (pp.hp <= 0 || d.heavy) breakProp(pp); else sfx('crunch', pp.x); }
      if (!a.ev.big) { const hitAny = hitBigProps(box[0], box[1], d.heavy ? (d.lvl >= 2 ? 3 : 2) : d.big ? 1 : 0.5, a); if (hitAny) a.ev.big = 1; }
    }
  }
  function quakeHit(x, r, dmg) { for (const e of st.enemies) if (!e.dead && Math.abs(e.x - x) < r && (!e.flying || e.y > GY - 140)) hitEnemy(e, dmg, Math.sign(e.x - x) * 300, -450, { heavy: true }); dust(x, GY, 16, 'rgba(200,180,150,0.6)', 2); }
  function quakeWaves(x, power) { [-1, 1].forEach(dir => st.projs.push({ type: 'quake', x, y: GY - 12, vx: dir * 700, vy: 0, r: 26, g: 0, life: power, t: 0, enemy: false, ground: true, dmg: weaponDef().dmg * (power > 0.65 ? 1.6 : 0.9), hitSet: new Set() })); }

  function updateSpecial(dt) {
    const p = st.p, s = p.spec, wd = weaponDef(); s.t += dt;
    const R = READY[s.type];
    switch (s.type) {
      case 'sword': {
        // flip in the air, then dive
        const spin = clamp(s.t / 0.45, 0, 1);
        p.pose = lerpPose(p.pose, P(Object.assign({}, R, { t: -20 + spin * 30, a1u: 200, a1f: 225, w: 240, a2u: 190, a2f: 215, l1t: 70, l1s: 0, l2t: 40, l2s: -40 })), 0.3);
        if (s.t > 0.42 && !s.dive) { s.dive = true; p.vy = 1700; p.vx = p.facing * 120; AudioSys.play('heavySwing'); }
        if (s.dive) p.pose = lerpPose(p.pose, P(Object.assign({}, R, { t: 34, a1u: 100, a1f: 80, w: 60, a2u: 90, a2f: 70, l1t: 40, l1s: 10, l2t: -30, l2s: -20 })), 0.4);
        if (s.dive && p.grounded) {
          shake(18); hitstop(0.1); AudioSys.play('boom', 1.2); AudioSys.play('metal', 0.6); vib(80);
          part({ x: p.x + p.facing * 40, y: GY + 2, type: 'crack', r: 130, life: 3 }); ring(p.x + p.facing * 40, GY - 10, '#fff', 200, 0.4); debris(p.x, GY, st.S.ground, 18, 1.4); dust(p.x, GY, 24, 'rgba(220,200,170,0.7)', 2.5);
          for (const e of st.enemies) if (!e.dead && Math.abs(e.x - p.x) < 260) hitEnemy(e, wd.dmg * 3.2, Math.sign(e.x - p.x) * 600, -600, { heavy: true, special: true, fin: true });
          for (const pp of st.props) if (!pp.broken && Math.abs(pp.x - p.x) < 260) breakProp(pp);
          p.spec = null; p.act = null; startAct('attack', resolveFrames([F(0.3, { t: 34, a1u: 100, a1f: 80, w: 60, a2u: 90, a2f: 70, l1t: 44, l1s: 14, l2t: -36, l2s: -30 }), F(0.5, 'R')], R), { d: { act: [9, 9], f: [] }, speed: 1 });
        }
        if (s.t > 2) p.spec = null;
        break;
      }
      case 'dual': {
        p.vx = p.facing * 1150; p.vy = 0; p.inv = 0.2;
        const ph = Math.sin(s.t * 40);
        p.pose = P(Object.assign({}, R, { t: 30, a1u: 90 + ph * 60, a1f: 80 + ph * 70, w: 70 + ph * 90, a2u: 90 - ph * 60, a2f: 80 - ph * 70, w2: 70 - ph * 90, l1t: 60, l1s: 10, l2t: -50, l2s: -30 }));
        p.after.push({ x: p.x, y: p.y, pose: Object.assign({}, p.pose), t: 0, facing: p.facing });
        s.tick -= dt; if (s.tick <= 0) { s.tick = 0.07; s.hit = new Set(); AudioSys.play('swing', 1.6); }
        for (const e of st.enemies) if (!e.dead && !s.hit.has(e) && Math.abs(e.x - p.x) < 70 && overlapE([p.x - 60, p.x + 60, p.y - 170, p.y + 10], e)) { s.hit.add(e); hitEnemy(e, wd.dmg * 1.1, p.facing * 200, -200, { special: true, fin: true }); }
        for (const pp of st.props) if (!pp.broken && Math.abs(pp.x - p.x) < 50) breakProp(pp);
        if (Math.random() < 0.7) blood(p.x, p.y - 60, '#ff1a2a', 2, -p.facing, 0.5);
        if (s.t > 0.4 || (st.lock && (p.x <= st.lock[0] + (G.portrait ? 26 : Math.min(150, W * 0.13) + 2) || p.x >= st.lock[1] - (G.portrait ? 26 : Math.min(150, W * 0.13) + 2)))) { p.spec = null; p.vx = p.facing * 200; }
        break;
      }
      case 'hammer': {
        if (s.t < 0.4) p.pose = lerpPose(p.pose, P(Object.assign({}, R, { bY: -6, t: -22, a1u: 215, a1f: 225, w: 235, a2u: 205, a2f: 215, l1t: 30, l1s: -10, l2t: -20, l2s: -30 })), 0.25);
        else p.pose = lerpPose(p.pose, P(Object.assign({}, R, { t: 44, a1u: 98, a1f: 70, w: 50, a2u: 88, a2f: 60, l1t: 52, l1s: 18, l2t: -44, l2s: -34 })), 0.5);
        if (s.t > 0.48 && !s.slam) { s.slam = true; const ix = p.x + p.facing * 70; shake(20); hitstop(0.12); AudioSys.play('boom', 1.4); vib(100); part({ x: ix, y: GY + 2, type: 'crack', r: 160, life: 3.5 }); ring(ix, GY - 10, '#ff9a3c', 240, 0.5); debris(ix, GY, st.S.ground, 22, 1.6); quakeHit(ix, 160, wd.dmg * 1.6); quakeWaves(ix, 0.9); for (let i = 0; i < 12; i++) part({ x: ix + rnd(-200, 200), y: GY, type: 'rockspike', r: rnd(14, 30), life: 0.9 }); }
        if (s.t > 0.9) p.spec = null;
        break;
      }
      case 'scythe': {
        const ang = s.t * 1400; p.pose = P(Object.assign({}, R, { t: 10, a1u: 92, a1f: 92, w: 90 + ang, a2u: 30, a2f: 60, bY: -4 })); p.facing = Math.floor(s.t * 8) % 2 ? 1 : -1;
        s.tick -= dt; if (s.tick <= 0) { s.tick = 0.12; s.hit = new Set(); AudioSys.play('swing', 1.2); }
        for (const e of st.enemies) { if (e.dead) continue; const dx = p.x - e.x; if (Math.abs(dx) < 340 && !e.boss) e.x += Math.sign(dx) * 260 * dt; if (Math.abs(dx) < 175 && !s.hit.has(e) && (!e.flying || e.y > GY - 200)) { s.hit.add(e); hitEnemy(e, wd.dmg * 0.75, -Math.sign(dx) * 80, -120, { special: true, soul: true, fin: true }); } }
        for (const pp of st.props) if (!pp.broken && Math.abs(pp.x - p.x) < 150) breakProp(pp);
        if (Math.random() < 0.6) part({ x: p.x + rnd(-150, 150), y: p.y - rnd(20, 150), vx: (p.x - 0) * 0, type: 'soul', col: '#5dffc1', life: 0.5, r: 4 });
        if (s.t > 1.3) { p.spec = null; p.pose = P(READY.scythe); }
        break;
      }
      case 'spear': {
        if (s.t < 0.25) p.pose = lerpPose(p.pose, P(Object.assign({}, R, { t: -14, a1u: 170, a1f: 185, w: 100, a2u: 60, a2f: 90 })), 0.3);
        else p.pose = lerpPose(p.pose, P(Object.assign({}, R, { t: 22, a1u: 100, a1f: 95, w: 92, l1t: 40, l1s: 10, l2t: -34, l2s: -20 })), 0.4);
        if (s.t > 0.26 && !s.thrown) { s.thrown = true; AudioSys.play('portal'); AudioSys.play('zap'); shake(8); st.projs.push({ type: 'lance', x: p.x + p.facing * 60, y: p.y - 92, vx: p.facing * 1500, vy: 0, r: 30, g: 0, life: 1.0, t: 0, enemy: false, dmg: wd.dmg * 2.8, hitSet: new Set() }); ring(p.x + p.facing * 60, p.y - 92, '#a67cff', 60, 0.3); }
        if (s.t > 0.6) p.spec = null;
        break;
      }
    }
  }

  function trackTrail(p) {
    const wd = weaponDef(); const active = (p.act && p.act.name === 'attack' && p.act.t > p.act.d.act[0] - 0.05 && p.act.t < p.act.d.act[1] + 0.06) || p.spec;
    if (!active) { p.trail.length = 0; p.trail2.length = 0; return; }
    const sk = solveSkeleton(p.pose, p.grounded); const f = p.facing * PS;
    const toW = (pt) => [p.x + pt[0] * f, p.y + pt[1] * PS];
    const hand = sk.A1.hand; const tip = weaponPoint(hand[0], hand[1], p.pose.w, WTIP[wd.id]); const base = weaponPoint(hand[0], hand[1], p.pose.w, WBASE[wd.id]);
    p.trail.push([toW(tip), toW(base)]); if (p.trail.length > 9) p.trail.shift();
    if (wd.cls === 'dual') { const h2 = sk.A2.hand; p.trail2.push([toW(weaponPoint(h2[0], h2[1], p.pose.w2, WTIP.bloodfang)), toW(weaponPoint(h2[0], h2[1], p.pose.w2, WBASE.bloodfang))]); if (p.trail2.length > 9) p.trail2.shift(); }
  }

  // ---------- big destructible landmarks ----------
  function hitBigProps(x0, x1, dmg, a) {
    let any = false;
    for (const bp of st.bigProps) {
      if (bp.fallen || bp.falling || bp.x < x0 - 30 || bp.x > x1 + 30) continue; if (a && a.hit.has(bp)) continue; if (a) a.hit.add(bp);
      any = true; bp.hp -= dmg; bp.hitT = 0.25; bp.crackSeed = rnd(0, 9);
      sparks(bp.x, GY - rnd(40, 120), '#e8dcc0', 6, Math.sign(bp.x - st.p.x)); debris(bp.x, GY - rnd(40, 140), PROP_COL[st.S.props] || '#555', 4, 0.7); sfx('crack', bp.x, rnd(0.8, 1.2)); shake(3);
      if (bp.hp <= 0) { bp.falling = true; bp.dir = Math.sign(bp.x - st.p.x) || 1; bp.fv = 0.2; sfx('creak', bp.x, 0.6); txt(bp.x, GY - bp.h - 20, 'TIMBER', '#e8dcc0', 16, 1); }
    }
    return any;
  }
  function updateBigProps(dt) {
    for (const bp of st.bigProps) {
      if (bp.hitT > 0) bp.hitT -= dt;
      if (bp.falling && !bp.fallen) {
        bp.fv += dt * 2.6; bp.fall = Math.min(1, bp.fall + bp.fv * dt);
        if (bp.fall >= 1) {
          bp.fallen = true; const x0 = bp.x, x1 = bp.x + bp.dir * bp.h * 0.95;
          shake(20); hitstop(0.06); sfx('collapse', (x0 + x1) / 2); sfx('boom', (x0 + x1) / 2, 0.8); vib(80);
          for (let i = 0; i < 6; i++) dust(lerp(x0, x1, i / 5), GY, 6, 'rgba(200,190,170,0.6)', 1.8); debris((x0 + x1) / 2, GY - 20, PROP_COL[st.S.props] || '#555', 22, 1.4);
          for (const e of st.enemies) if (!e.dead && !e.boss && e.x > Math.min(x0, x1) - 30 && e.x < Math.max(x0, x1) + 30 && (!e.flying || e.y > GY - 140)) { hitEnemy(e, 90 + st.idx * 12, bp.dir * 300, -400, { heavy: true, special: true, fin: true, exec: true }); }
          if (st.boss && !st.boss.dead && st.boss.x > Math.min(x0, x1) - 60 && st.boss.x < Math.max(x0, x1) + 60) { hitEnemy(st.boss, 120, 0, 0, { heavy: true, special: true }); }
          st.rubble.push({ x: Math.min(x0, x1), w: Math.abs(x1 - x0), kind: bp.kind, seed: bp.seed });
          Save.d.destroyed++; st.bigBroken = (st.bigBroken || 0) + 1; G.onEvent && G.onEvent('topple');
          if (bp.shard) { st.pickups.push({ type: 'shard', x: x1 - bp.dir * 40, y: GY - 60, vx: 0, vy: -420, t: 0 }); sfx('blink', x1); txt(x1, GY - 150, '...something glints', '#ff3a3a', 14, 2); }
        }
      }
    }
  }
  function drawBigProp(bp) {
    const T = st.T, h = bp.h, kind = bp.kind; const col = '#16131a', edge = 'rgba(255,255,255,0.06)';
    c.save(); c.translate(bp.x, GY + 4); c.rotate(bp.dir * bp.fall * bp.fall * Math.PI * 0.5);
    if (bp.hitT > 0) c.translate(rnd(-3, 3), 0);
    c.fillStyle = col; c.strokeStyle = '#000'; c.lineWidth = 2; c.beginPath();
    if (kind === 'tree') { c.moveTo(-18, 0); c.bezierCurveTo(-10, -h * 0.4, -16, -h * 0.7, -6, -h); c.lineTo(6, -h); c.bezierCurveTo(14, -h * 0.6, 8, -h * 0.4, 18, 0); c.closePath(); c.fill(); c.stroke(); c.strokeStyle = col; c.lineWidth = 6; [[0.55, -1], [0.7, 1], [0.85, -1]].forEach(([k, d]) => { c.beginPath(); c.moveTo(0, -h * k); c.quadraticCurveTo(d * 40, -h * k - 30, d * 70, -h * k - 10 + Math.sin(T + k * 9) * 3); c.stroke(); }); }
    else if (kind === 'statue') { c.fillRect(-28, -30, 56, 30); c.fillRect(-20, -h * 0.75, 40, h * 0.75 - 30); c.beginPath(); c.arc(0, -h * 0.82, 16, 0, 7); c.fill(); c.fillRect(-36, -h * 0.68, 72, 10); c.fillStyle = '#ff2020'; if (Math.sin(T * 0.7 + bp.seed) > 0.6) { c.fillRect(-7, -h * 0.84, 4, 2); c.fillRect(3, -h * 0.84, 4, 2); } c.fillStyle = col; }
    else if (kind === 'ice') { c.moveTo(-26, 0); c.lineTo(-14, -h * 0.6); c.lineTo(-4, -h); c.lineTo(10, -h * 0.7); c.lineTo(24, 0); c.closePath(); c.fillStyle = 'rgba(150,200,230,0.55)'; c.fill(); c.stroke(); }
    else if (kind === 'coral') { c.moveTo(-14, 0); c.quadraticCurveTo(-30, -h * 0.5, -10, -h * 0.9); c.quadraticCurveTo(0, -h, 10, -h * 0.85); c.quadraticCurveTo(28, -h * 0.5, 14, 0); c.closePath(); c.fillStyle = '#1c2a2e'; c.fill(); c.stroke(); }
    else if (kind === 'spire') { c.moveTo(-24, 0); c.quadraticCurveTo(-8, -h * 0.5, -2, -h); c.quadraticCurveTo(8, -h * 0.5, 24, 0); c.closePath(); c.fillStyle = '#2a0d14'; c.fill(); c.stroke(); for (let i = 1; i < 5; i++) { c.fillStyle = '#5a1020'; c.beginPath(); c.arc(Math.sin(i * 2.1) * 8, -h * i / 6, 4, 0, 7); c.fill(); } }
    else if (kind === 'monolith') { c.rect(-22, -h, 44, h); c.fill(); c.stroke(); c.fillStyle = '#fff'; c.globalAlpha = 0.3 + 0.3 * Math.sin(T * 3 + bp.seed); c.fillRect(-2, -h * 0.6, 4, 4); c.globalAlpha = 1; }
    else if (kind === 'tower') { c.rect(-26, -h * 0.85, 52, h * 0.85); c.fill(); c.stroke(); c.beginPath(); c.moveTo(-34, -h * 0.85); c.lineTo(0, -h); c.lineTo(34, -h * 0.85); c.closePath(); c.fill(); c.fillStyle = '#ffae40'; c.globalAlpha = 0.6 + 0.3 * Math.sin(T * 9 + bp.seed); c.fillRect(-6, -h * 0.65, 12, 16); c.globalAlpha = 1; }
    else { c.rect(-22, -h, 44, h); c.fill(); c.stroke(); c.fillStyle = '#211c24'; c.fillRect(-30, -h, 60, 14); c.fillRect(-30, -16, 60, 16); }
    // cracks deepen as it takes damage
    const dmgK = 1 - bp.hp / bp.maxHp; if (dmgK > 0) { c.strokeStyle = 'rgba(0,0,0,0.9)'; c.lineWidth = 2; let x = 0, y = -h * 0.35; c.beginPath(); c.moveTo(x, y); for (let i = 0; i < 2 + dmgK * 8; i++) { x += Math.sin(i * 3.1 + bp.seed) * 9; y -= 12; c.lineTo(x, y); } c.stroke(); c.strokeStyle = edge; c.stroke(); }
    if (bp.shard && !bp.fallen) { const a = 0.35 + 0.35 * Math.sin(T * 2.3 + bp.seed); c.fillStyle = `rgba(255,30,30,${a})`; c.beginPath(); c.ellipse(0, -h * 0.45, 5, 2.2, 0, 0, 7); c.fill(); }
    c.restore();
  }
  function grantRelic(id, x) {
    if (Save.d.relics.includes(id)) return false; const r = RELICS.find(q => q.id === id); if (!r) return false;
    Save.d.relics.push(id); Save.save(); st.relicFound = id; sfx('relic', x); st.toast = { text: 'RELIC FOUND', sub: r.name, t: 3.2, relic: true };
    for (let i = 0; i < 20; i++) part({ x, y: GY - 80, vx: rnd(-200, 200), vy: rnd(-400, -100), r: rnd(2, 4), col: '#ffd23a', life: 1, type: 'glow' });
    G.onEvent && G.onEvent('relic', id); return true;
  }
  G.grantRelic = (id) => grantRelic(id, st ? st.p.x : 0);

  // ---------- environmental horror ----------
  const DARK = [0.28, 0.42, 0.4, 0.5, 0.3, 0.45, 0.26, 0.48, 0.42, 0.55];
  const AMBIENT = ['footBehind', 'knock', 'scrape', 'creak', 'drip', 'bell', 'hum', 'distantScream', 'whisper', 'laughLow', 'footBehind'];
  function updateEnvironment(dt) {
    const p = st.p, T = st.T; st.stageT += dt;
    // lights decay
    for (const l of st.lights) l.t += dt; st.lights = st.lights.filter(l => l.t < l.life);
    // flicker: occasional short dips, and rare "light dying" events where it nearly goes black
    st.flickT -= dt;
    if (st.flickT <= 0) { st.flickT = rnd(4, 11); st.flickSeq = { t: 0, dur: rnd(0.25, 0.7), deep: Math.random() < 0.18 }; if (st.flickSeq.deep) { sfx('hum', p.x, 0.5); } stepDistant(); }
    if (st.flickSeq) { const f = st.flickSeq; f.t += dt; const k = f.t / f.dur; st.flick = k >= 1 ? 1 : (Math.sin(f.t * 60) > 0.2 ? 1 : (f.deep ? 0.15 : 0.6)); if (f.deep && k < 1 && k > 0.4) st.flick = 0.08; if (k >= 1) { st.flickSeq = null; st.flick = 1; } }
    // ambient sounds placed around the player — often behind them
    const ev = st.events; ev.t -= dt;
    if (ev.t <= 0 && !p.dead) {
      ev.t = rnd(6, 15) * (st.boss && !st.boss.dead ? 2 : 1); ev.n++;
      const name = AMBIENT[Math.floor(Math.random() * AMBIENT.length)];
      const behind = p.x - p.facing * rnd(250, 600);
      const x = name === 'footBehind' || name === 'whisper' || name === 'laughLow' ? behind : p.x + rnd(-800, 800);
      if (name === 'whisper') sfx('whisper', x, 0.35); else sfx(name, x);
      if (name === 'footBehind' && Math.random() < 0.4) st.behindT = 1.4; // a shape flickers at the edge you are not looking at
    }
    if (st.behindT > 0) st.behindT -= dt;
    // watchers: pale-eyed figures in the background that turn to follow you; look at one long enough and it is gone
    if (st.watchers.length < 2 && Math.random() < dt * 0.06 && st.stageT > 6) st.watchers.push({ wx: st.camX * 0.55 + rnd(W * 0.15, W * 0.9), t: 0, look: 0, h: rnd(60, 95), seed: rnd(0, 9), gone: 0 });
    for (const w of st.watchers) {
      w.t += dt; const sx = w.wx - st.camX * 0.55; w.sx = sx;
      const px = p.x - st.camX; const facingIt = Math.sign(sx - px) === p.facing && sx > 0 && sx < W;
      if (w.gone > 0) { w.gone += dt; continue; }
      if (facingIt && !p.act) w.look += dt; else w.look = Math.max(0, w.look - dt * 0.5);
      if (w.look > 1.5) { w.gone = 0.001; sfx('staticBurst', st.camX + sx, 0.4); G.onEvent && G.onEvent('sawit'); }
      if (sx < -100 || sx > W + 100 || w.t > 40) w.gone = 1;
    }
    st.watchers = st.watchers.filter(w => w.gone < 0.6);
    // shadow figures crossing the mid-ground
    if (st.figures.length < 1 && Math.random() < dt * 0.05) { const dir = Math.random() < 0.5 ? 1 : -1; st.figures.push({ sx: dir > 0 ? -60 : W + 60, dir, sp: rnd(40, 90), h: rnd(110, 160), ph: 0 }); }
    for (const f of st.figures) { f.sx += f.dir * f.sp * dt; f.ph += dt * f.sp / 20; }
    st.figures = st.figures.filter(f => f.sx > -100 && f.sx < W + 100);
    // falling debris on big impacts
    if (st.shake > 14 && Math.random() < 0.3) part({ x: st.camX + rnd(0, W), y: -10, vx: rnd(-20, 20), vy: rnd(100, 300), r: rnd(2, 5), col: '#5a5048', life: 2, type: 'chunk', g: 1400 });
    // music intensity follows the fight
    const near = st.enemies.filter(e => !e.dead && Math.abs(e.x - p.x) < 900).length;
    const lvl = st.boss && !st.boss.dead ? (st.boss.p3 ? 3 : 2) : near > 0 ? 1 : 0;
    if (lvl !== st.intensity) { st.intensity = lvl; AudioSys.setIntensity(lvl); }
    if (st.witch > 0) st.witch -= dt;
  }
  // a figure on the horizon that gets a little closer every time the lights flicker
  function stepDistant() {
    if (st.boss && !st.boss.dead) return;
    if (!st.distant) { if (Math.random() < 0.35) st.distant = { sx: rnd(W * 0.2, W * 0.8), step: 0 }; return; }
    st.distant.step++; st.distant.sx += rnd(-40, 40);
    if (st.distant.step >= 4) { sfx('stinger', st.p.x); st.distant = null; G.onEvent && G.onEvent('distant'); }
  }
  function drawWatchers() {
    for (const w of st.watchers) {
      const a = w.gone > 0 ? Math.max(0, 1 - w.gone / 0.5) : clamp(w.t / 2, 0, 1) * 0.85; if (a <= 0) continue;
      const x = w.sx + (w.gone > 0 ? rnd(-6, 6) : 0), y = GY - 70, h = w.h; c.globalAlpha = a;
      c.fillStyle = '#050407'; c.beginPath(); c.moveTo(x - h * 0.16, y); c.lineTo(x - h * 0.1, y - h * 0.75); c.quadraticCurveTo(x, y - h * 1.02, x + h * 0.1, y - h * 0.75); c.lineTo(x + h * 0.16, y); c.closePath(); c.fill();
      c.beginPath(); c.arc(x, y - h * 0.82, h * 0.09, 0, 7); c.fill();
      // eyes follow the player (head turns)
      const px = st.p.x - st.camX; const look = clamp((px - x) / 200, -1, 1) * h * 0.05; const blink = Math.sin(st.T * 0.9 + w.seed) > 0.97;
      if (!blink) { c.fillStyle = w.look > 0.6 ? '#ff2020' : '#e8e2d0'; c.fillRect(x + look - h * 0.045, y - h * 0.84, 2, 1.5); c.fillRect(x + look + h * 0.02, y - h * 0.84, 2, 1.5); }
      c.globalAlpha = 1;
    }
    if (st.distant) { const d = st.distant; const h = 30 + d.step * 22; const x = d.sx, y = GY - 60; c.globalAlpha = 0.75 * st.flick; c.fillStyle = '#030204'; c.fillRect(x - h * 0.08, y - h, h * 0.16, h); c.beginPath(); c.arc(x, y - h - h * 0.08, h * 0.08, 0, 7); c.fill(); c.strokeStyle = '#030204'; c.lineWidth = Math.max(1, h * 0.03); c.beginPath(); c.moveTo(x - h * 0.08, y - h * 0.85); c.lineTo(x - h * 0.2, y - h * 0.25); c.moveTo(x + h * 0.08, y - h * 0.85); c.lineTo(x + h * 0.2, y - h * 0.25); c.stroke(); c.globalAlpha = 1; }
  }
  function drawFigures() {
    for (const f of st.figures) {
      const x = f.sx, y = GY - 20, h = f.h, sw = Math.sin(f.ph); c.globalAlpha = 0.5; c.fillStyle = '#020103';
      c.beginPath(); c.ellipse(x, y - h * 0.62, h * 0.09, h * 0.28, sw * 0.03, 0, 7); c.fill(); c.beginPath(); c.arc(x + f.dir * 2, y - h * 0.95, h * 0.07, 0, 7); c.fill();
      c.lineWidth = h * 0.05; c.strokeStyle = '#020103'; c.lineCap = 'round'; c.beginPath(); c.moveTo(x, y - h * 0.38); c.lineTo(x + sw * h * 0.12, y); c.moveTo(x, y - h * 0.38); c.lineTo(x - sw * h * 0.12, y); c.moveTo(x, y - h * 0.8); c.lineTo(x + sw * h * 0.1, y - h * 0.42); c.stroke();
      c.globalAlpha = 1;
    }
    if (st.behindT > 0) { const side = st.p.facing > 0 ? 0 : W; const a = Math.sin(clamp(st.behindT / 1.4, 0, 1) * Math.PI) * 0.6; c.globalAlpha = a; c.fillStyle = '#000'; const x = side + (side ? -30 : 30); c.beginPath(); c.ellipse(x, GY - 90, 22, 80, 0, 0, 7); c.fill(); c.beginPath(); c.arc(x, GY - 180, 16, 0, 7); c.fill(); c.globalAlpha = 1; }
  }
  // darkness / light mask, drawn at quarter resolution for speed
  let lightCv = null, lightC = null, glowSpr = null;
  function glowSprite() { if (glowSpr) return glowSpr; glowSpr = document.createElement('canvas'); glowSpr.width = glowSpr.height = 128; const g = glowSpr.getContext('2d'); const rg = g.createRadialGradient(64, 64, 0, 64, 64, 64); rg.addColorStop(0, 'rgba(0,0,0,1)'); rg.addColorStop(0.5, 'rgba(0,0,0,0.7)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = rg; g.fillRect(0, 0, 128, 128); return glowSpr; }
  function drawLightMask(viewTop) {
    const dark = st.mods.includes('dark') ? 0.93 : DARK[st.idx] * (st.nm ? 1.25 : 1);
    const amt = clamp(1 - (1 - dark) * st.flick, 0, 0.97); if (amt < 0.04) return;
    const LW = Math.ceil(W / 4), LH = Math.ceil((VH - viewTop) / 4);
    if (!lightCv) { lightCv = document.createElement('canvas'); lightC = lightCv.getContext('2d'); }
    if (lightCv.width !== LW || lightCv.height !== LH) { lightCv.width = LW; lightCv.height = LH; }
    const L = lightC; L.globalCompositeOperation = 'source-over'; L.clearRect(0, 0, LW, LH); L.fillStyle = `rgba(2,0,6,${amt})`; L.fillRect(0, 0, LW, LH);
    L.globalCompositeOperation = 'destination-out'; const spr = glowSprite();
    const hole = (x, y, r, a) => { L.globalAlpha = clamp(a, 0, 1); L.drawImage(spr, (x - st.camX - r) / 4, (y - viewTop - r) / 4, r / 2, r / 2); };
    const p = st.p; const pr = st.mods.includes('dark') ? 210 : 340; hole(p.x, p.y - 80, pr * (0.95 + 0.05 * Math.sin(st.T * 7)), 1); hole(p.x, p.y - 80, pr * 0.6, 1);
    for (const l of st.lights) hole(l.x, l.y, l.r, l.a * (1 - l.t / l.life));
    for (const pr2 of st.projs) if (pr2.type === 'fireball' || pr2.type === 'meteor' || pr2.type === 'lance' || pr2.type === 'crescent' || pr2.type === 'eyebolt') hole(pr2.x, pr2.y, 160, 0.8);
    if (st.idx === 4 || st.idx === 0) for (let x = Math.floor(st.camX / 600) * 600 + 300; x < st.camX + W + 300; x += 600) hole(x, GY - 140, 260 * (0.9 + 0.1 * Math.sin(st.T * 11 + x)), 0.6 * st.flick);
    if (st.boss && !st.boss.dead) hole(st.boss.x, st.boss.y - st.boss.h * 0.5, 360, 0.55);
    L.globalAlpha = 1; L.globalCompositeOperation = 'source-over';
    c.imageSmoothingEnabled = true; c.drawImage(lightCv, 0, viewTop, LW * 4, LH * 4);
  }

  // ---------- waves / camera ----------
  function updateWaves(dt) {
    const p = st.p;
    if (st.endless) { updateEndless(dt); return; }
    if (!st.lock) {
      const w = st.waves[st.waveIdx];
      if (w && p.x > w.x) {
        st.lock = [st.camX, st.camX + W]; const n = w.n;
        for (let i = 0; i < n; i++) { const side = i % 2 ? -1 : 1; const type = w.types[Math.floor(Math.random() * w.types.length)]; st.spawnQ.push({ t: i * 0.55 + 0.3, type, side }); }
        G.onEvent && G.onEvent('wave', st.waveIdx);
        st.banner = { text: 'WAVE ' + (st.waveIdx + 1) + ' / 4', sub: '', t: 1.4, small: true };
      } else if (!w && !st.bossStarted && p.x > st.len - 500) { startBoss(); }
    }
    if (st.spawnQ.length) {
      for (const s of st.spawnQ) { s.t -= dt; if (s.t <= 0) { const x = s.side > 0 ? st.camX + W + 40 : st.camX - 40; const e = spawnEnemy(s.type, x); e.spawnT = 0.01; s.done = true; } }
      st.spawnQ = st.spawnQ.filter(s => !s.done);
    }
    if (st.lock && !st.bossStarted && st.spawnQ.length === 0 && st.enemies.every(e => e.dead)) { st.lock = null; st.waveIdx++; st.banner = { text: st.waveIdx >= 4 ? 'THE AIR GROWS HEAVY' : 'GO →', sub: '', t: 1.6, small: true }; AudioSys.play('uiBig'); if (st.waveIdx === 2) G.onEvent && G.onEvent('midstage'); }
    st.enemies = st.enemies.filter(e => !e.dead || e.deathT < 2.2);
  }
  function spawnFromQueue(dt) {
    for (const s of st.spawnQ) { s.t -= dt; if (s.t <= 0) { const x = s.side > 0 ? st.camX + W + 40 : st.camX - 40; const e = spawnEnemy(s.type, x); e.spawnT = 0.01; s.done = true; } }
    st.spawnQ = st.spawnQ.filter(s => !s.done);
  }
  // ----- THE ENDLESS ABYSS: waves forever, a boss every fifth, the world shifts after each boss -----
  function updateEndless(dt) {
    const p = st.p;
    if (!st.lock) { st.lock = [0, W]; st.ewaveT = 2; st.eStage = st.idx; }
    spawnFromQueue(dt);
    const alive = st.enemies.some(e => !e.dead) || st.spawnQ.length || st.deathSeq;
    if (!alive) {
      st.ewaveT -= dt;
      if (st.ewaveT <= 0) {
        st.ewave++; st.ewaveT = 2.4;
        if (st.ewave > (Save.d.endlessBest || 0)) { Save.d.endlessBest = st.ewave - 1; }
        G.onEvent && G.onEvent('endlesswave', st.ewave);
        if (st.ewave % 5 === 0) { st.bossStarted = false; startBoss(); }
        else {
          const n = 3 + Math.min(10, Math.floor(st.ewave * 0.8)); const types = STAGES[st.eStage].enemies;
          for (let i = 0; i < n; i++) st.spawnQ.push({ t: i * 0.5 + 0.3, type: types[Math.floor(Math.random() * types.length)], side: i % 2 ? -1 : 1 });
          st.banner = { text: 'WAVE ' + st.ewave, sub: 'THE ENDLESS ABYSS', t: 1.6, small: true };
        }
      }
    }
    st.enemies = st.enemies.filter(e => !e.dead || e.deathT < 2.2);
  }
  function endlessShift() {
    st.eStage = (st.eStage + 1) % 10; st.idx = st.eStage; st.S = STAGES[st.eStage]; st.bg = buildBG(st.eStage);
    st.boss = null; st.bossStarted = false; st.bigProps = []; st.rubble = []; st.props = [];
    for (let x = 80; x < W; x += rnd(260, 420)) st.props.push({ x, y: GY + rnd(4, 18), type: st.S.props, hp: 2, hitT: 0 });
    [W * 0.2, W * 0.8].forEach(x => st.bigProps.push({ x, hp: 6, maxHp: 6, hitT: 0, fall: 0, fallen: false, dir: 1, kind: BIGPROP_KIND[st.eStage] || 'pillar', seed: rnd(0, 10), h: rnd(230, 290) }));
    AudioSys.transition(st.S.music); AudioSys.ambience(AMB_KIND[st.S.weather] || 'wind');
    st.banner = { text: st.S.name, sub: 'THE ABYSS SHIFTS', t: 2.6 }; st.flash = 0.6; sfx('staticBurst', st.p.x);
  }
  function startBoss() {
    st.bossStarted = true; const bx = st.camX + W; st.lock = st.endless ? st.lock : [st.camX, st.camX + W];
    const key = st.S.boss; st.boss = Bosses.create(key, st, (st.endless ? st.lock[1] : bx) - 160);
    st.enemies.push(st.boss);
    // cinematic entrance: lock input, letterbox, push the camera in on the boss, name card at the end
    const seen = (Save.d.seenIntro || []).includes(key);
    const dur = st.boss.intro;
    st.cine = { t: 0, dur, lock: true, letter: 0, boss: st.boss, key, skippable: seen, card: false };
    st.zoomT = 1.18; st.zoomX = st.boss.x - 80; st.zoomY = GY - 140;
    AudioSys.setIntensity(2); AudioSys.play('riser');
    AudioSys.transition(Object.assign({}, st.S.music, { tempo: (st.S.music.tempo || 90) * 1.25, notes: 0.36, drums: true, kick: 60 }), Math.min(2600, dur * 700));
    if (!seen) { Save.d.seenIntro = (Save.d.seenIntro || []).concat([key]); }
    G.onEvent && G.onEvent('boss', key);
  }
  function updateCine(dt) {
    const cn = st.cine; cn.t += dt; cn.letter = Math.min(1, cn.letter + dt * 2.5);
    const b = cn.boss;
    if (b) {
      st.zoomX = lerp(st.zoomX, b.x - 60, 0.05); st.zoomY = lerp(st.zoomY, (b.flying ? b.y : b.y - b.h * 0.5), 0.05);
      if (cn.t > cn.dur - 1.1 && !cn.card) { cn.card = true; st.banner = { text: BOSSES[cn.key].name, sub: BOSSES[cn.key].title, t: 2.8, boss: true }; AudioSys.play('roar'); shake(14); }
      if (cn.skippable && cn.t > 0.4 && (input.attack || input.jump || input.special)) { b.intro = 0.0001; b.introT = 99; cn.t = cn.dur; if (!cn.card) { cn.card = true; st.banner = { text: BOSSES[cn.key].name, sub: BOSSES[cn.key].title, t: 2, boss: true }; } }
      if (b.intro <= 0 || cn.t >= cn.dur) { st.cine = null; st.zoomT = 1; G.onEvent && G.onEvent('bossfight', cn.key); }
    } else if (cn.t >= cn.dur) { st.cine = null; st.zoomT = 1; }
  }
  function bossGrade() {
    const b = st.boss; const hitK = st.bossDmgTaken / st.p.maxHp; const tt = st.bossT || 60;
    let sc = 0; if (st.bossDmgTaken === 0) sc += 4; else if (hitK < 0.3) sc += 3; else if (hitK < 0.7) sc += 2; else if (hitK < 1.2) sc += 1;
    if (tt < 45) sc += 2; else if (tt < 90) sc += 1; if (st.bestCombo >= 30) sc += 1; if (st.execs >= 3) sc += 1;
    return sc >= 7 ? 'S' : sc >= 5 ? 'A' : sc >= 3 ? 'B' : 'C';
  }
  function bossDeath(b) {
    sfx('bossDie', b.x); st.slowmo = 0.25; st.slowT = 2.4; shake(24); st.flash = 0.5;
    st.zoomT = 1.28; st.zoomX = b.x; st.zoomY = b.flying ? b.y : b.y - b.h * 0.5; // kill cam
    st.deathSeq = { b, t: 0, dur: Bosses.deathDur[b.key] || 3, ev: {} };
    st.cine = { t: 0, dur: st.deathSeq.dur, lock: false, letter: 0 };
    for (const e of st.enemies) if (!e.dead && e !== b) killEnemy(e, true, 1);
    st.projs = st.projs.filter(q => !q.enemy); st.hazards = []; st.beams = []; st.lightsOut = 0;
    // relics
    const relic = RELICS.find(r => r.boss === b.key);
    if (relic && !Save.d.relics.includes(relic.id)) { const guaranteed = relic.id === 'relic_crown' && st.bossDmgTaken === 0; if (guaranteed || Math.random() < relic.chance * (st.nm ? 2 : 1)) st.pendingRelic = relic.id; }
    st.grade = bossGrade();
    if (!st.endless) { st.clearT = st.deathSeq.dur + 3.4 + (b.def.reward && !Save.d.weapons.includes(b.def.reward) ? 2.6 : 0); st.cleared = true; }
    G.onEvent && G.onEvent('bossdead', st.idx);
  }
  function updateDeathSeq(dt) {
    const S2 = st.deathSeq, b = S2.b, t = S2.t; S2.t += dt; const k = b.key; const by = b.flying ? b.y : b.y - b.h * 0.5;
    const at = (tt) => t >= tt && !S2.ev[tt] && (S2.ev[tt] = 1);
    const boom = (x, y, r) => { ring(x, y, '#ffd8a0', r, 0.4); blood(x, y, b.def.blood, 30, rnd(-1, 1), 1.8); sfx('boom', x, 0.9); shake(14); light(x, y, r * 2.4, 1, 0.3, '#ffb070'); for (let i = 0; i < 10; i++) part({ x, y, vx: rnd(-1, 1) * r * 5, vy: rnd(-1, 0.2) * r * 5, r: rnd(4, 10), col: '#ff9a3a', life: 0.5, type: 'glow' }); };
    switch (k) {
      case 'goblinKing': if (at(0.1)) part({ x: b.x, y: b.y - b.h, vx: -b.facing * 160, vy: -700, g: 1500, r: 16, col: '#ffcc30', life: 3.2, type: 'crown', rot: 0, vr: 7 }); [0.7, 1.1, 1.5, 1.9].forEach((tt, i) => { if (at(tt)) boom(b.x + (i - 1.5) * 50, by + rnd(-30, 30), 70); }); break;
      case 'vampireBat': if (t > 0.3 && t < 1.8) for (let i = 0; i < 4; i++) part({ x: b.x + rnd(-b.w, b.w), y: by + rnd(-b.h, b.h), vx: rnd(-500, 500), vy: rnd(-500, 100), r: rnd(5, 9), col: '#1a0f20', life: 1.2, type: 'bat', rot: 0 }); if (at(0.3)) sfx('wings', b.x, 0.7); if (at(0.8)) sfx('screech', b.x); break;
      case 'bigWolf': if (at(0.15)) { sfx('roar', b.x); b.pose = 'howl'; } if (t > 1.0) for (let i = 0; i < 3; i++) part({ x: b.x + rnd(-b.w * 0.6, b.w * 0.6), y: b.y - rnd(0, b.h), vx: rnd(-30, 60), vy: rnd(-120, -40), r: rnd(3, 6), col: 'rgba(40,36,36,0.8)', life: 2, type: 'dust' }); break;
      case 'undeadKnight': if (at(0.5)) { sfx('metal', b.x, 0.5); debris(b.x, by, '#4a4650', 18, 1.2); } if (at(1.2)) { sfx('holy', b.x); part({ x: b.x, y: by, vx: 0, vy: -90, r: 26, col: '#5dffd0', life: 2.4, type: 'glow' }); } if (at(1.4)) { sfx('metal', b.x + b.facing * 40, 0.4); shake(6); } break;
      case 'fireDemon': if (t < 2.2) { for (let i = 0; i < 4; i++) part({ x: b.x + rnd(-40, 40), y: GY - rnd(0, 40), vx: rnd(-30, 30), vy: rnd(-900, -400), r: rnd(8, 18), col: Math.random() < 0.5 ? '#ff7a1a' : '#ffd040', life: 0.8, type: 'glow' }); light(b.x, GY - 200, 420, 0.9, 0.1, '#ff8a3a'); } if (at(0.2)) { sfx('fire', b.x); sfx('roar', b.x); } break;
      case 'seaMonster': if (at(0.3)) sfx('splash', b.x); if (at(1.4)) sfx('splash', b.x); break;
      case 'frostGiant': if (at(0.2)) sfx('ice', b.x); if (at(1.3)) { sfx('shatter', b.x); shake(20); for (let i = 0; i < 40; i++) part({ x: b.x + rnd(-b.w * 0.6, b.w * 0.6), y: b.y - rnd(0, b.h), vx: rnd(-600, 600), vy: rnd(-800, -100), g: 1600, r: rnd(5, 14), col: Math.random() < 0.5 ? '#dff6ff' : '#8ec8e8', life: 2, type: 'chunk', rot: rnd(0, 6), vr: rnd(-10, 10) }); } break;
      case 'fallenAngel': if (at(0.3)) { sfx('shatter', b.x); } if (t < 3) for (let i = 0; i < 2; i++) part({ x: b.x + rnd(-80, 80), y: by + rnd(-80, 40), vx: rnd(-60, 60), vy: rnd(-40, 40), g: 50, r: rnd(3, 6), col: '#fff6d0', life: 2.6, type: 'feather', rot: rnd(0, 6), vr: rnd(-3, 3) }); if (at(1.6)) sfx('holy', b.x); break;
      case 'abomination': if (at(0.2)) sfx('growl', b.x, 0.4, 1); if (at(0.9)) { sfx('gore', b.x); sfx('boom', b.x, 1.2); shake(26); st.flash = 0.4; for (let i = 0; i < 4; i++) blood(b.x + rnd(-60, 60), by + rnd(-40, 40), '#c0102a', 50, rnd(-1, 1), 2.4); debris(b.x, by, '#8a2a3e', 30, 1.6); for (let i = 0; i < 24; i++) decal(b.x + rnd(-260, 260), '#c0102a', 30); } break;
      case 'theEye': if (at(0.5)) sfx('crack', b.x); if (at(1.2)) sfx('crack', b.x, 0.8); if (at(1.9)) sfx('shatter', b.x); if (at(2.4)) { sfx('staticBurst', b.x); st.distort = 0.6; } if (at(3.0)) { st.distort = 0; st.flash = 0.8; ring(b.x, b.y, '#fff', 500, 0.5); sfx('boom', b.x, 1.5); } break;
    }
    if (t >= S2.dur && !S2.done) {
      S2.done = true; st.zoomT = 1; st.cine = null;
      sfx('victoryBig', st.p.x);
      const vSouls = Math.ceil(b.def.souls * (1 + SD(st.idx) * 0.2) * st.soulMul);
      for (let i = 0; i < 40; i++) st.pickups.push({ type: 'soul', x: b.x, y: by, vx: rnd(-400, 400), vy: rnd(-800, -200), val: Math.ceil(vSouls / 40), t: 0 });
      if (b.def.reward && !Save.d.weapons.includes(b.def.reward) && !st.endless) st.pickups.push({ type: 'weapon', id: b.def.reward, x: b.x, y: GY - 60, vx: 0, vy: -200, t: 0 });
      if (st.pendingRelic) { grantRelic(st.pendingRelic, b.x); st.pendingRelic = null; }
      st.victory = { t: 0, name: b.def.name, grade: st.grade, souls: vSouls, xp: Object.values(st.xp).reduce((a, v) => a + v, 0) };
      if (st.endless) { st.deathSeq = null; setTimeout(() => { if (st && st.endless) endlessShift(); }, 2500); }
    }
  }

  // ----- PERCY: the loyal dog. He fights beside you. If he falls, he is gone forever. -----
  function percyActive() { return Save.d.percy === 'alive' && Save.d.percyOn !== false; }
  function makePercy() { const p = st.p; return { x: p.x - 70, y: GY, vx: 0, vy: 0, facing: 1, hp: 140 + st.idx * 12, maxHp: 140 + st.idx * 12, inv: 0, state: 'follow', st: 0, cd: 0, phase: 0, target: null, flash: 0, barkT: rnd(3, 6), grounded: true, dead: false, deathT: 0, kills: 0, wag: 0 }; }
  function updatePercy(dt) {
    const d = st.percy; if (!d) return; const p = st.p; d.phase += dt; d.inv -= dt; d.flash -= dt; d.cd -= dt; d.st -= dt; d.barkT -= dt;
    if (d.dead) { d.deathT += dt; d.vx *= 0.9; d.x += d.vx * dt; return; }
    d.vy += 2000 * dt; d.y += d.vy * dt; if (d.y >= GY) { d.y = GY; d.vy = 0; d.grounded = true; } else d.grounded = false;
    // pick the closest threat to you
    let tgt = null, bd = 520; for (const e of st.enemies) { if (e.dead || e.spawnT > 0 || e.state === 'exec' || (e.boss && (e.intro > 0 || e.phaseT > 0))) continue; const dd = Math.abs(e.x - p.x) * 0.6 + Math.abs(e.x - d.x) * 0.4; if (dd < bd && (!e.flying || e.y > GY - 170)) { bd = dd; tgt = e; } }
    const low = d.hp < d.maxHp * 0.3;
    if (low) tgt = null; // hurt: he stays behind you
    d.target = tgt;
    if (d.state === 'bite') {
      if (d.st <= 0) { d.state = 'follow'; }
      else if (!d.bit && d.st < 0.18 && d.target) { const e = d.target; d.bit = true; if (Math.abs(e.x - d.x) < e.w * 0.5 + 50) { const dmg = (14 + st.idx * 3) * (e.boss ? 0.8 : 1); hitEnemyPercy(e, dmg, Math.sign(e.x - d.x)); } }
    } else if (tgt && !(st.cine && st.cine.lock)) {
      const dx = tgt.x - d.x; d.facing = Math.sign(dx) || d.facing; const reach = tgt.w * 0.5 + 34;
      if (Math.abs(dx) > reach) { d.vx = lerp(d.vx, Math.sign(dx) * 360, 0.15); }
      else { d.vx *= 0.7; if (d.cd <= 0) { d.state = 'bite'; d.st = 0.34; d.bit = false; d.cd = rnd(0.55, 0.85); d.vy = -260; d.vx = d.facing * 260; sfx('growl', d.x, 2.2, 0.25); } }
    } else {
      const tx = p.x - p.facing * (low ? 90 : 70); const dx = tx - d.x;
      if (Math.abs(dx) > 30) { d.vx = lerp(d.vx, Math.sign(dx) * Math.min(420, Math.abs(dx) * 3), 0.12); d.facing = Math.sign(dx); } else { d.vx *= 0.8; d.facing = Math.sign(p.x - d.x) || 1; }
      if (low && !anyEnemyNear()) d.hp = Math.min(d.maxHp, d.hp + dt * 6);
      else if (!anyEnemyNear()) d.hp = Math.min(d.maxHp, d.hp + dt * 3);
    }
    if (d.barkT <= 0) { d.barkT = rnd(5, 12); if (tgt || Math.random() < 0.3) { sfx('bark', d.x); d.barkK = 0.3; } }
    if (d.barkK > 0) d.barkK -= dt;
    d.x += d.vx * dt; if (st.lock) d.x = clamp(d.x, st.lock[0] + 20, st.lock[1] - 20); d.x = Math.max(20, d.x);
    if (d.x < st.camX - 300 || d.x > st.camX + W + 300) { d.x = p.x - p.facing * 60; } // never lost
    d.wag += dt * (tgt ? 6 : 14);
  }
  function hitEnemyPercy(e, dmg, dir) {
    dmg = Math.round(dmg); e.hp -= dmg; e.flash = 0.1; e.hitT = 0.15;
    if (!e.boss) { e.vx = dir * 160; if (e.state !== 'stagger') { e.state = 'hurt'; e.st = 0.22; } e.poise = (e.poise || 0) + 0.5; }
    const hy = e.flying ? e.y : e.y - e.h * 0.4; blood(e.x, hy, e.def.blood, 8, dir); sfx('flesh', e.x, 1.3); txt(e.x, hy - 20, String(dmg), '#ffcf7a', 15);
    if (e.hp <= 0) { if (st.percy) st.percy.kills++; killEnemy(e, false, dir); G.onEvent && G.onEvent('percykill'); }
  }
  function hurtPercy(dmg, fromX, dg) {
    const d = dg || st.percy; if (!d || d.dead || d.inv > 0 || st.cleared) return false;
    d.hp -= dmg; d.inv = 0.7; d.flash = 0.2; d.vx = (Math.sign(d.x - fromX) || 1) * 300; d.vy = -240;
    sfx('whimper', d.x); blood(d.x, d.y - 30, '#a0101a', 8, Math.sign(d.x - fromX) || 1); txt(d.x, d.y - 70, '-' + Math.round(dmg), '#ffaa7a', 14);
    if (d.hp <= 0) {
      d.hp = 0; d.dead = true; d.deathT = 0; if (d.C) { compDie(d); return true; } Save.d.percy = 'dead'; Save.d.percyDiedAt = Date.now(); Save.d.percyStage = st.idx; Save.save();
      st.slowmo = 0.3; st.slowT = 1.6; sfx('whimper', d.x, 0.6); sfx('bell', d.x);
      st.banner = { text: 'PERCY', sub: 'He is not getting up.', t: 4, boss: true };
      G.onEvent && G.onEvent('percydead');
    }
    return true;
  }
  G.percyHit = (x, w, yTop, dmg, fromX) => { let hit = false; for (const d of dogs()) { if (!d || d.dead) continue; if (Math.abs(d.x - x) < w / 2 + 20 && hurtPercy(dmg, fromX, d)) hit = true; } return hit; };
  // ----- SECRET COMPANIONS (Vesper the raven, Lantern the wisp, Brutus the golem). Permadeath, like Percy. -----
  function dogs() { const a = []; if (st.percy) a.push(st.percy); if (st.comps) for (const q of st.comps) a.push(q); return a; }
  function activeComps() { const cs = Save.d.comp || {}; return Object.keys(COMPANIONS).filter(k => cs[k] === 'alive' && Save.d['compOn_' + k] !== false); }
  function makeComp(id) { const C = COMPANIONS[id], p = st.p, hp = C.hp + st.idx * C.hpg; return { id, C, x: p.x - 90, y: C.fly ? GY - 130 : GY, vx: 0, vy: 0, facing: 1, hp, maxHp: hp, inv: 0, state: 'follow', st: 0, cd: rnd(0.3, 1), phase: rnd(0, 6), target: null, flash: 0, dead: false, deathT: 0, kills: 0, bit: false }; }
  function compDie(d) {
    (Save.d.comp = Save.d.comp || {})[d.id] = 'dead'; (Save.d.compDied = Save.d.compDied || {})[d.id] = { t: Date.now(), stage: st.idx }; Save.save();
    st.slowmo = 0.3; st.slowT = 1.6; sfx('whimper', d.x, 0.6); sfx('bell', d.x);
    st.banner = { text: d.C.name, sub: 'Gone. Forever.', t: 4, boss: true }; G.onEvent && G.onEvent('compdead', d.id);
  }
  function updateComp(d, dt) {
    const p = st.p, C = d.C; d.phase += dt; d.inv -= dt; d.flash -= dt; d.cd -= dt; d.st -= dt;
    if (d.dead) { d.deathT += dt; d.vx *= 0.9; d.x += d.vx * dt; if (d.y < GY) { d.vy += 1500 * dt; d.y = Math.min(GY, d.y + d.vy * dt); } return; }
    if (!C.fly) { d.vy += 2000 * dt; d.y += d.vy * dt; if (d.y >= GY) { d.y = GY; d.vy = 0; } }
    let tgt = null, bd = C.kind === 'wisp' ? 560 : 480;
    for (const e of st.enemies) { if (e.dead || e.spawnT > 0 || e.state === 'exec' || (e.boss && (e.intro > 0 || e.phaseT > 0))) continue; const dd = Math.abs(e.x - p.x) * 0.6 + Math.abs(e.x - d.x) * 0.4; if (dd < bd && (C.fly || !e.flying || e.y > GY - 170)) { bd = dd; tgt = e; } }
    const low = d.hp < d.maxHp * 0.3; if (low) tgt = null; d.target = tgt;
    const hy = GY - (C.fly ? 140 : 0) - (C.kind === 'wisp' ? 20 : 0);
    if (tgt && !(st.cine && st.cine.lock)) {
      const dx = tgt.x - d.x, sg = Math.sign(dx) || d.facing; d.facing = sg; const ty = tgt.flying ? tgt.y : tgt.y - tgt.h * 0.5, dmg = C.dmg + SD(st.idx) * C.dg * 1.4;
      if (C.kind === 'raven') {
        d.vx = lerp(d.vx, Math.abs(dx) > 40 ? sg * 430 : 0, 0.18); d.y += (ty - d.y) * Math.min(1, dt * 5);
        if (Math.abs(dx) < tgt.w * 0.5 + 40 && d.cd <= 0) { d.cd = rnd(0.5, 0.8); hitEnemyPercy(tgt, dmg, sg); }
      } else if (C.kind === 'wisp') {
        d.vx = lerp(d.vx, clamp((tgt.x - sg * 300 - d.x) * 2, -300, 300), 0.1); d.y += (GY - 170 - d.y) * Math.min(1, dt * 3);
        if (d.cd <= 0 && Math.abs(dx) < 560) { d.cd = rnd(0.8, 1.1); for (let i = 0; i < 10; i++) part({ x: d.x + dx * i / 10, y: d.y + (ty - d.y) * i / 10, col: '#9ff', life: 0.25, r: 3 }); hitEnemyPercy(tgt, dmg, sg); }
      } else {
        const reach = tgt.w * 0.5 + 60;
        if (Math.abs(dx) > reach) d.vx = lerp(d.vx, sg * 170, 0.12); else { d.vx *= 0.7; if (d.cd <= 0) { d.cd = rnd(1.4, 1.9); d.state = 'bite'; d.st = 0.5; d.bit = false; } }
      }
    } else {
      const tx = p.x - p.facing * (low ? 110 : 80), dx = tx - d.x;
      if (Math.abs(dx) > 30) { d.vx = lerp(d.vx, Math.sign(dx) * Math.min(C.fly ? 380 : 300, Math.abs(dx) * 3), 0.12); d.facing = Math.sign(dx); } else { d.vx *= 0.8; d.facing = Math.sign(p.x - d.x) || 1; }
      if (C.fly) d.y += (hy + Math.sin(d.phase * 3) * 10 - d.y) * Math.min(1, dt * 3);
      if (!anyEnemyNear()) d.hp = Math.min(d.maxHp, d.hp + dt * (low ? 6 : 3));
    }
    if (d.state === 'bite') {
      if (d.st < 0.2 && !d.bit) { d.bit = true; shake(10); sfx('boom', d.x, 0.7); ring(d.x, GY - 10, '#c9a', 130, 0.35); for (const e of st.enemies.slice()) if (!e.dead && Math.abs(e.x - d.x) < 150) hitEnemyPercy(e, C.dmg + SD(st.idx) * C.dg * 1.4, Math.sign(e.x - d.x) || 1); }
      if (d.st <= 0) d.state = 'follow';
    }
    d.x += d.vx * dt; if (st.lock) d.x = clamp(d.x, st.lock[0] + 20, st.lock[1] - 20); d.x = Math.max(20, d.x);
    if (d.x < st.camX - 300 || d.x > st.camX + W + 300) d.x = p.x - p.facing * 60;
  }
  function drawComp(d) {
    if (d.dead && d.deathT > 8) return;
    const T = st.T, C = d.C, moving = Math.abs(d.vx) > 20;
    c.save(); if (d.inv > 0 && !d.dead && Math.floor(T * 14) % 2 === 0) c.globalAlpha = 0.6;
    c.fillStyle = 'rgba(0,0,0,0.35)'; c.beginPath(); c.ellipse(d.x, GY + 4, C.fly ? 16 : 30, 5, 0, 0, 7); c.fill();
    drawCompanion(c, d.x, d.y, d.facing, 1, { kind: C.kind, T, moving, bite: d.state === 'bite' ? 1 - Math.max(0, d.st) / 0.5 : 0, dead: d.dead, deathT: d.deathT, flash: d.flash > 0, low: d.hp < d.maxHp * 0.3 });
    c.restore();
    const top = d.y - (C.kind === 'golem' ? 96 : 42);
    if (!d.dead && d.hp < d.maxHp) { c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(d.x - 18, top, 36, 4); c.fillStyle = '#e8b04a'; c.fillRect(d.x - 18, top, 36 * d.hp / d.maxHp, 4); }
    if (d.dead) { c.fillStyle = 'rgba(200,200,200,0.7)'; c.font = '700 16px Georgia'; c.textAlign = 'center'; c.fillText('\u271d', d.x, d.y - 44); }
  }

  function updatePickups(dt) {
    const p = st.p;
    for (const k of st.pickups) {
      k.t += dt; if (k.type === 'weapon') { k.vy += 800 * dt; k.y += k.vy * dt; if (k.y > GY - 60) { k.y = GY - 60; k.vy = 0; } if (Math.abs(p.x - k.x) < 50 && !p.dead) { k.done = true; G.onEvent && G.onEvent('weapon', k.id); st.banner = { text: 'NEW WEAPON', sub: WEAPONS.find(w => w.id === k.id).name, t: 2.6, boss: true }; AudioSys.play('victory'); st.clearT = Math.min(st.clearT, 2.8); } continue; }
      if (k.type === 'shard') { k.vy += 900 * dt; k.y += k.vy * dt; if (k.y > GY - 50) { k.y = GY - 50; k.vy = 0; } if (Math.abs(p.x - k.x) < 46 && Math.abs(p.y - 60 - k.y) < 110 && !p.dead) { k.done = true; if (!Save.d.shards.includes(st.idx)) Save.d.shards.push(st.idx); st.shardFound = true; Save.save(); sfx('relic', k.x); st.flash = 0.5; const n = Save.d.shards.length; st.toast = { text: 'EYE SHARD ' + n + ' / 10', sub: n >= 10 ? 'It is whole. It is yours.' : 'It is still looking at you.', t: 3, relic: true }; if (n >= 10 && !Save.d.relics.includes('relic_eye')) grantRelic('relic_eye', k.x); G.onEvent && G.onEvent('shard', n); } continue; }
      if (k.t < 0.45) { k.vy += 1400 * dt; k.x += k.vx * dt; k.y += k.vy * dt; if (k.y > GY - 8) { k.y = GY - 8; k.vy *= -0.4; k.vx *= 0.6; } }
      else { const dx = p.x - k.x, dy = (p.y - 60) - k.y, d = Math.hypot(dx, dy) || 1; const sp = 600 + k.t * 900; k.x += dx / d * sp * dt; k.y += dy / d * sp * dt; if (d < 30) { k.done = true; if (k.type === 'soul') { Save.d.souls += k.val; st.soulsGained += k.val; if (Math.random() < 0.5) AudioSys.play('coin'); } else { const hv = st.mods.includes('glass') ? 0 : 18; p.hp = Math.min(p.maxHp, p.hp + hv); AudioSys.play('heal'); txt(p.x, p.y - 150, '+' + hv, '#5aff7a', 16); if (st.percy && !st.percy.dead) st.percy.hp = Math.min(st.percy.maxHp, st.percy.hp + 10); } } }
    }
    st.pickups = st.pickups.filter(k => !k.done);
  }

  // ---------- main update ----------
  G.update = (dtReal) => {
    if (!st || !G.running || G.paused) return;
    if (st.frozen) return;
    let dt = dtReal;
    if (st.hitstop > 0) { st.hitstop -= dtReal; dt = dtReal * 0.05; }
    if (st.slowT > 0) { st.slowT -= dtReal; dt *= lerp(1, st.slowmo, clamp(st.slowT / 0.3, 0, 1)); }
    if (st.exec) dt *= st.exec.t < 0.08 ? 0.35 : 0.8; // brief slow-motion as the execution begins
    st.T += dt;
    if (st.banner) { st.banner.t -= dtReal; if (st.banner.t <= 0) st.banner = null; }
    if (st.toast) { st.toast.t -= dtReal; if (st.toast.t <= 0) st.toast = null; }
    if (st.whisper) { st.whisper.t -= dtReal; if (st.whisper.t <= 0) st.whisper = null; }
    if (st.victory) st.victory.t += dtReal;
    st.shake *= Math.pow(0.002, dtReal); if (st.shake < 0.2) st.shake = 0;
    st.flash = Math.max(0, st.flash - dtReal * 1.5);
    if (st.comboT > 0) { st.comboT -= dt; if (st.comboT <= 0) st.combo = 0; }
    if (st.boss && !st.boss.dead && !st.cine) st.bossT = (st.bossT || 0) + dt;
    if (st.cine) updateCine(dtReal);
    if (st.percy === undefined) st.percy = percyActive() ? makePercy() : null;
    if (st.comps === undefined) st.comps = activeComps().map(makeComp);
    if (st.exec) updateExecution(dt);
    updatePlayer(dt);
    director(dt);
    for (const e of st.enemies) { if (e.boss) Bosses.update(e, st.witch > 0 ? dt * 0.3 : dt, st, G); else updateEnemy(e, dt); }
    updatePercy(dt);
    for (const q of st.comps || []) updateComp(q, dt);
    updateProjs(dt); updateHazards(dt); updateWaves(dt); updatePickups(dt); updateBigProps(dt);
    if (st.deathSeq) updateDeathSeq(dtReal * (st.slowT > 0 ? 0.6 : 1));
    for (const pp of st.props) if (pp.hitT > 0) pp.hitT -= dt;
    st.props = st.props.filter(pp => !pp.broken);
    for (const a of st.p.after) a.t += dt; st.p.after = st.p.after.filter(a => a.t < 0.25);
    if (st.p.after.length > 24) st.p.after.splice(0, st.p.after.length - 24);
    if (st.p.glint > 0) st.p.glint -= dt;
    // particles
    const cap = G.quality === 'low' ? 300 : G.quality === 'ultra' ? 1100 : 700; if (st.parts.length > cap) st.parts.splice(0, st.parts.length - cap);
    for (const q of st.parts) { q.t += dt; q.vy += q.g * dt; q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.vr * dt; if ((q.type === 'blood' || q.type === 'chunk' || q.type === 'crown') && q.y > GY + 6) { if (q.type === 'blood') { q.t = q.life; if (Math.random() < 0.15) decal(q.x, q.col, 8); } else { q.y = GY + 6; q.vy *= -0.35; q.vx *= 0.6; q.vr *= 0.6; } } if (q.type === 'dust') { q.vx *= 0.94; q.vy *= 0.94; } if (q.type === 'feather') { q.vx *= 0.98; q.vy = Math.min(q.vy, 60); } if (q.type === 'bat') { q.vy -= 30 * dt; } }
    st.parts = st.parts.filter(q => q.t < q.life);
    for (const t of st.texts) { t.t += dt; t.y -= 40 * dt; } st.texts = st.texts.filter(t => t.t < t.life);
    if (st.texts.length > 40) st.texts.splice(0, st.texts.length - 40);
    weather(dt);
    updateEnvironment(dt);
    // camera (with cinematic zoom)
    const p = st.p; let target = p.x - W * 0.42 + p.facing * 40;
    if (st.lock) target = clamp(target, st.lock[0], st.lock[1] - W);
    target = Math.max(0, target);
    st.camX = lerp(st.camX, target, clamp(dt * 5, 0, 1));
    if (st.lock) st.camX = clamp(st.camX, st.lock[0], st.lock[1] - W);
    st.zoom = lerp(st.zoom, st.zoomT, clamp(dtReal * 4, 0, 1));
    // eye kill
    if (st.eyekill) { st.eyekill.t += dtReal; if (st.eyekill.t > 2.6 && !st.eyekill.done) { st.eyekill.done = true; st.frozen = true; G.onEvent && G.onEvent('finalcrash'); } }
    else if (p.dead && p.deathT > 2.2 && !st.deadSent) { st.deadSent = true; G.onEvent && G.onEvent('gameover'); }
    if (st.cleared && !p.dead) { st.clearT -= dtReal; if (st.clearT <= 0 && !st.clearSent && !st.pickups.some(k => k.type === 'weapon')) { st.clearSent = true; G.onEvent && G.onEvent('clear', st.idx); } if (st.clearT < -6 && !st.clearSent) { st.clearSent = true; G.onEvent && G.onEvent('clear', st.idx); } }
  };
  G.whisper = (text, dur = 3.6) => { if (!st) return; st.whisper = { text, t: dur, dur }; AudioSys.play('whisper', 0.9); };
  function weather(dt) {
    const w = st.S.weather; const r = Math.random;
    if (w === 'embers' && r() < 0.5) part({ x: st.camX + r() * W, y: GY + 20, vx: rnd(-20, 40), vy: rnd(-90, -40), r: rnd(1, 2.5), col: r() < 0.5 ? '#ff7a1a' : '#ffc040', life: rnd(2, 4), type: 'glow', bg: true });
    if (w === 'snow' && r() < 0.9) part({ x: st.camX + r() * (W + 200) - 100, y: -10, vx: rnd(-60, -20), vy: rnd(40, 90), r: rnd(1, 3), col: '#fff', life: 7, type: 'dot', bg: true });
    if (w === 'leaves' && r() < 0.15) part({ x: st.camX + r() * W, y: -10, vx: rnd(-40, 10), vy: rnd(40, 70), r: rnd(3, 5), col: '#6a0a0a', life: 8, type: 'leaf', rot: r() * 6, vr: rnd(-3, 3), bg: true });
    if (w === 'bubbles' && r() < 0.35) part({ x: st.camX + r() * W, y: GY, vx: rnd(-10, 10), vy: rnd(-70, -30), r: rnd(2, 5), col: 'rgba(180,255,250,0.5)', life: 6, type: 'bubble', bg: true });
    if (w === 'spores' && r() < 0.3) part({ x: st.camX + r() * W, y: rnd(0, GY), vx: rnd(-20, 20), vy: rnd(-20, 20), r: rnd(1.5, 3), col: 'rgba(255,200,180,0.6)', life: 4, type: 'glow', bg: true });
    if (w === 'dust' && r() < 0.2) part({ x: st.camX + r() * W, y: rnd(60, GY), vx: rnd(5, 15), vy: rnd(-5, 5), r: rnd(0.8, 1.6), col: 'rgba(255,230,190,0.6)', life: 6, type: 'dot', bg: true });
    if (w === 'mist' && r() < 0.06) part({ x: st.camX + W + 100, y: GY - rnd(0, 60), vx: rnd(-50, -20), vy: 0, r: rnd(40, 80), col: 'rgba(160,200,190,0.06)', life: 14, type: 'fog', bg: true });
    if (w === 'glitch' && r() < 0.05) glitchFX(st.camX + r() * W, rnd(0, GY));
  }

  // ---------- RENDER ----------
  // cached textures: fog noise, film grain, glow sprite
  let fogTex = null, grainTex = null, warmSpr = null;
  function makeFog() { const cv2 = document.createElement('canvas'); cv2.width = 1024; cv2.height = 200; const g = cv2.getContext('2d'); for (let i = 0; i < 70; i++) { const x = Math.random() * 1024, y = 60 + Math.random() * 120, r = 40 + Math.random() * 110; const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, 'rgba(255,255,255,0.16)'); rg.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2); [x - 1024, x + 1024].forEach(xx => { const r2 = g.createRadialGradient(xx, y, 0, xx, y, r); r2.addColorStop(0, 'rgba(255,255,255,0.16)'); r2.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = r2; g.fillRect(xx - r, y - r, r * 2, r * 2); }); } return cv2; }
  function makeGrain() { const cv2 = document.createElement('canvas'); cv2.width = cv2.height = 160; const g = cv2.getContext('2d'); const id = g.createImageData(160, 160); for (let i = 0; i < id.data.length; i += 4) { const v = Math.random() * 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 22; } g.putImageData(id, 0, 0); return cv2; }
  function makeWarm() { const cv2 = document.createElement('canvas'); cv2.width = cv2.height = 128; const g = cv2.getContext('2d'); const rg = g.createRadialGradient(64, 64, 0, 64, 64, 64); rg.addColorStop(0, 'rgba(255,255,255,0.9)'); rg.addColorStop(0.3, 'rgba(255,255,255,0.35)'); rg.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = rg; g.fillRect(0, 0, 128, 128); return cv2; }
  const tintCache = {};
  function tintGlow(col) {
    let t = tintCache[col]; if (t) return t; const k = Object.keys(tintCache); if (k.length > 60) delete tintCache[k[0]];
    t = document.createElement('canvas'); t.width = t.height = 64; const g = t.getContext('2d'); const rg = g.createRadialGradient(32, 32, 0, 32, 32, 32); rg.addColorStop(0, col); rg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = rg; g.fillRect(0, 0, 64, 64); tintCache[col] = t; return t;
  }
  G.glowSprite = () => warmSpr || (warmSpr = makeWarm());
  function drawFog(cam, par, alpha, y, tint) {
    if (!fogTex) fogTex = makeFog(); c.save(); c.globalAlpha = alpha; const off = ((cam * par + st.T * 14 * par) % 1024 + 1024) % 1024;
    for (let x = -off; x < W; x += 1024) c.drawImage(fogTex, x, y, 1024, 200);
    if (tint) { c.globalCompositeOperation = 'source-atop'; } c.restore();
  }
  G.render = () => {
    if (!st) return;
    const Q = G.quality || 'high';
    c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = '#000'; c.fillRect(0, 0, cv.width, cv.height);
    const sx = st.shake ? rnd(-st.shake, st.shake) : 0, sy = st.shake ? rnd(-st.shake, st.shake) : 0;
    c.setTransform(dpr * scale, 0, 0, dpr * scale, sx * dpr * scale, (offY + sy) * dpr * scale);
    const viewTop = Math.max(0, -offY);
    c.save(); c.beginPath(); c.rect(0, 0, W, VH); c.clip();
    // cinematic zoom about a focus point
    const z = st.zoom || 1;
    if (z > 1.001) { const fx = clamp(st.zoomX - st.camX, W * 0.25, W * 0.75), fy = clamp(st.zoomY, viewTop + (VH - viewTop) * 0.3, GY - 40); c.translate(fx, fy); c.scale(z, z); c.translate(-fx, -fy); }
    const T = st.T, cam = st.camX, bg = st.bg, p = st.p;
    drawSky(c, W, st.S, T, st.idx);
    // ultra: god rays falling through the sky
    if (Q === 'ultra') { c.save(); c.globalCompositeOperation = 'lighter'; for (let i = 0; i < 4; i++) { const x = ((i * 337 - cam * 0.08) % (W + 400) + W + 400) % (W + 400) - 200; const a = 0.035 + 0.02 * Math.sin(T * 0.4 + i); const g = c.createLinearGradient(x, 0, x + 160, GY); g.addColorStop(0, `rgba(255,240,220,${a})`); g.addColorStop(1, 'rgba(255,240,220,0)'); c.fillStyle = g; c.beginPath(); c.moveTo(x, viewTop); c.lineTo(x + 70, viewTop); c.lineTo(x + 260, GY); c.lineTo(x + 120, GY); c.closePath(); c.fill(); } c.restore(); }
    drawLayer(c, bg.far, cam, 0.15, W); drawDynamicBG(c, bg, cam, T, W, 0.15, W2S(p.x));
    drawWatchers();
    if (Q !== 'low') drawFog(cam, 0.25, 0.5, GY - 230);
    // fog band
    const fg = c.createLinearGradient(0, GY - 160, 0, GY); fg.addColorStop(0, 'rgba(0,0,0,0)'); fg.addColorStop(1, st.S.fog); c.fillStyle = fg; c.fillRect(0, GY - 160, W, 160);
    drawLayer(c, bg.mid, cam, 0.5, W); drawDynamicBG(c, bg, cam, T, W, 0.5, W2S(p.x));
    drawFigures();
    drawGround(c, W, st.S, cam, T);
    c.save(); c.translate(-cam, 0);
    for (const q of st.parts) if (q.bg) drawPart(q);
    for (const d of st.decals) { c.fillStyle = rgba(d.col.length === 7 ? d.col : '#880000', 0.5); c.beginPath(); c.ellipse(d.x, d.y, d.w, d.w * 0.22, 0, 0, 7); c.fill(); }
    for (const q of st.parts) if (q.type === 'crack') drawPart(q);
    // rubble of toppled landmarks
    for (const r of st.rubble) { c.fillStyle = '#121014'; c.beginPath(); c.moveTo(r.x, GY + 8); for (let i = 0; i <= 10; i++) c.lineTo(r.x + r.w * i / 10, GY + 2 - Math.abs(Math.sin(i * 1.7 + r.seed)) * 18); c.lineTo(r.x + r.w, GY + 8); c.closePath(); c.fill(); }
    for (const bp of st.bigProps) if (bp.x > cam - 400 && bp.x < cam + W + 400) drawBigProp(bp);
    drawHazards(true);
    for (const pp of st.props) drawProp(c, pp, T);
    const ents = st.enemies.slice().sort((a, b) => a.z - b.z);
    for (const e of ents) if (!e.dead || e.deathT < 1) { const sh = e.flying ? 0.4 : 1; c.fillStyle = `rgba(0,0,0,${0.35 * sh})`; c.beginPath(); c.ellipse(e.x, GY + e.z * 0.4 + 2, e.w * 0.6, 6, 0, 0, 7); c.fill(); }
    c.fillStyle = 'rgba(0,0,0,0.4)'; c.beginPath(); c.ellipse(p.x, GY + 6, 30 * clamp(1 - (GY - p.y) / 400, 0.4, 1), 6, 0, 0, 7); c.fill();
    if (st.percy) drawPercy(st.percy); if (st.comps) for (const q of st.comps) drawComp(q);
    for (const e of ents) if (e.z < p.z) drawEnemy(e);
    drawPlayer();
    if (Save.d.relics.includes('relic_eye') && Save.d.extras && Save.d.extras.includes('relic_eye')) drawLittleEye();
    for (const e of ents) if (e.z >= p.z) drawEnemy(e);
    drawHazards(false);
    for (const pr of st.projs) drawProj(pr);
    drawBeams();
    for (const k of st.pickups) drawPickup(k);
    for (const q of st.parts) if (!q.bg && q.type !== 'crack') drawPart(q);
    // execution prompt over staggered enemies
    const tg = !p.dead && !st.exec && p.grounded ? findExecTarget() : null;
    if (tg) { const yy = tg.flying ? tg.y - tg.h * 0.8 : tg.y - tg.h - 34; const pul = 0.75 + 0.25 * Math.sin(T * 10); c.save(); c.textAlign = 'center'; c.font = '900 13px "Cinzel", Georgia, serif'; c.fillStyle = `rgba(255,60,60,${pul})`; c.strokeStyle = '#000'; c.lineWidth = 3; c.strokeText('EXECUTE', tg.x, yy); c.fillText('EXECUTE', tg.x, yy); c.restore(); }
    // heavy charge meter
    if (p.act && p.act.name === 'charge') { const maxL = has('charge3') ? 3 : 2; const k = clamp(p.act.t / HEAVY_LVL[maxL].t, 0, 1); c.save(); c.lineWidth = 4; c.strokeStyle = 'rgba(0,0,0,0.6)'; c.beginPath(); c.arc(p.x, p.y - 190, 14, 0, 7); c.stroke(); c.strokeStyle = p.act.lvl >= 3 ? '#ff3a3a' : p.act.lvl >= 2 ? '#ffb02a' : '#fff'; c.beginPath(); c.arc(p.x, p.y - 190, 14, -Math.PI / 2, -Math.PI / 2 + k * Math.PI * 2); c.stroke(); c.restore(); }
    c.textAlign = 'center';
    for (const t of st.texts) { const a = 1 - t.t / t.life; c.globalAlpha = a; c.font = `900 ${t.size}px "Cinzel", Georgia, serif`; c.lineWidth = 4; c.strokeStyle = 'rgba(0,0,0,0.85)'; c.strokeText(t.s, t.x, t.y); c.fillStyle = t.col; c.fillText(t.s, t.x, t.y); }
    c.globalAlpha = 1;
    // bloom-ish warm glow at light sources (high/ultra)
    if (Q !== 'low' && st.lights.length) { c.save(); c.globalCompositeOperation = 'lighter'; const spr = G.glowSprite(); for (const l of st.lights) { const a = (1 - l.t / l.life) * l.a * (Q === 'ultra' ? 0.32 : 0.2); if (a <= 0.01) continue; c.globalAlpha = a; c.drawImage(spr, l.x - l.r * 0.5, l.y - l.r * 0.5, l.r, l.r); } c.restore(); c.globalAlpha = 1; }
    c.restore();
    // darkness & light
    if (Q !== 'low' || st.mods.includes('dark')) drawLightMask(viewTop);
    if (st.lightsOut > 0) { c.fillStyle = `rgba(0,0,0,${0.78 * st.lightsOut})`; c.fillRect(0, 0, W, VH); }
    c.globalAlpha = 0.9; drawLayer(c, bg.near, cam, 1.25, W, 0); c.globalAlpha = 1;
    if (Q === 'ultra') drawFog(cam, 1.4, 0.28, GY - 120);
    // vignette
    const vg = c.createRadialGradient(W / 2, (VH + viewTop) / 2, VH * 0.35, W / 2, (VH + viewTop) / 2, W * 0.75); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.75)'); c.fillStyle = vg; c.fillRect(0, 0, W, VH);
    if (p.hp / p.maxHp < 0.3 && !p.dead) { const a = 0.25 + 0.15 * Math.sin(T * 6); const rg = c.createRadialGradient(W / 2, VH / 2, VH * 0.3, W / 2, VH / 2, W * 0.7); rg.addColorStop(0, 'rgba(120,0,0,0)'); rg.addColorStop(1, `rgba(140,0,0,${a})`); c.fillStyle = rg; c.fillRect(0, 0, W, VH); }
    if (st.witch > 0) { c.fillStyle = `rgba(60,110,200,${0.16 * clamp(st.witch, 0, 1)})`; c.fillRect(0, 0, W, VH); }
    if (st.flash > 0) { c.fillStyle = `rgba(255,255,255,${st.flash * 0.35})`; c.fillRect(0, 0, W, VH); }
    c.restore();
    // ---- screen space: letterbox, HUD, overlays (never cropped) ----
    c.setTransform(dpr * hs, 0, 0, dpr * hs, 0, HOY * dpr * hs);
    if (Q === 'ultra') { if (!grainTex) grainTex = makeGrain(); c.save(); c.globalAlpha = 0.5; const ox = rnd(0, 160), oy = rnd(0, 160); for (let x = -ox; x < HW; x += 160) for (let y = -oy; y < VH; y += 160) c.drawImage(grainTex, x, y); c.restore(); }
    const lb = st.cine ? st.cine.letter : 0; st.lbShow = lerp(st.lbShow || 0, lb, 0.12);
    if (st.lbShow > 0.01) { const h = VH * 0.11 * st.lbShow; c.fillStyle = '#000'; c.fillRect(0, 0, HW, h); c.fillRect(0, VH - h, HW, h); if (st.cine && st.cine.skippable && st.cine.boss) { c.font = '600 10px Georgia'; c.textAlign = 'right'; c.fillStyle = 'rgba(255,255,255,0.45)'; c.fillText('tap ATTACK to skip', HW - 16, VH - h / 2 + 3); } }
    if (st.stare) drawStare();
    if (st.distort > 0) distortFX(st.distort);
    if (!(st.cine && st.cine.lock)) drawHUD(); else drawBannerOnly();
    if (st.eyekill) drawEyeKill();
  };
  function drawLittleEye() {
    const p = st.p, T = st.T; const x = p.x - p.facing * 46 + Math.sin(T * 1.7) * 8, y = p.y - 190 + Math.sin(T * 2.3) * 6;
    c.save(); c.translate(x, y); c.fillStyle = '#efe6d8'; c.beginPath(); c.ellipse(0, 0, 11, 7, 0, 0, 7); c.fill(); c.strokeStyle = '#300'; c.lineWidth = 1.5; c.stroke();
    const t = st.enemies.find(e => !e.dead); const dx = t ? clamp((t.x - x) / 200, -1, 1) * 4 : p.facing * 3;
    c.fillStyle = '#a00010'; c.beginPath(); c.arc(dx, 0, 4.5, 0, 7); c.fill(); c.fillStyle = '#000'; c.beginPath(); c.arc(dx, 0, 2, 0, 7); c.fill();
    if (Math.sin(T * 0.9) > 0.97) { c.fillStyle = '#2a1414'; c.fillRect(-12, -7, 24, 14); }
    c.restore();
  }
  function drawPercy(d) {
    if (d.dead && d.deathT > 6) return;
    const T = st.T; const moving = Math.abs(d.vx) > 20; const biting = d.state === 'bite';
    c.save(); if (d.inv > 0 && !d.dead && Math.floor(T * 14) % 2 === 0) c.globalAlpha = 0.6;
    c.fillStyle = 'rgba(0,0,0,0.35)'; c.beginPath(); c.ellipse(d.x, GY + 4, 26, 5, 0, 0, 7); c.fill();
    drawDog(c, d.x, d.y, d.facing, 1, { T, phase: d.phase * (moving ? 9 : 0), moving, wag: d.wag, bite: biting ? 1 : 0, bark: d.barkK > 0 ? 1 : 0, dead: d.dead ? clamp(d.deathT / 0.8, 0, 1) : 0, flash: d.flash > 0, low: d.hp < d.maxHp * 0.3 });
    c.restore();
    if (!d.dead && d.hp < d.maxHp) { c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(d.x - 18, d.y - 66, 36, 4); c.fillStyle = '#e8b04a'; c.fillRect(d.x - 18, d.y - 66, 36 * d.hp / d.maxHp, 4); }
  }

  function drawPlayer() {
    const p = st.p, wd = weaponDef(), k = wd.cls, T = st.T;
    // after-images
    for (const a of p.after) { c.globalAlpha = (1 - a.t / 0.25) * 0.35; drawHumanoid(c, a.x, a.y, a.facing, PS, a.pose, Object.assign({}, p.style, { cloak: '#ff1a2a', skin: '#ff1a2a', armor: '#ff1a2a', cloth: '#a00' }), { T, grounded: false }); }
    c.globalAlpha = 1;
    // trails (world space)
    drawTrail(p.trail, trailCol()); if (k === 'dual') drawTrail(p.trail2, trailCol());
    if (p.inv > 0 && !p.spec && Math.floor(T * 14) % 2 === 0 && !p.dead) c.globalAlpha = 0.55;
    const tint = skinTint();
    const sh = SHEATH[k];
    let rot = 0; if (p.dead) rot = -clamp(p.deathT / 0.8, 0, 1) * 1.45; if (p.spec && p.spec.type === 'sword' && !p.spec.dive) rot = -clamp(p.spec.t / 0.42, 0, 1) * Math.PI * 2;
    const sheathGrip = (sk) => { const g = rotOff(sk, sh.ox, sh.oy); return { x: g[0], y: g[1], a: sh.a - p.pose.t }; };
    const inHandK = p.sheathed ? 0 : (p.act && (p.act.name === 'draw' || p.act.name === 'sheath') ? p.drawK : 1);
    const weaponAt = (sk, which) => {
      const hand = which === 2 ? sk.A2.hand : sk.A1.hand; const ang = which === 2 ? p.pose.w2 : p.pose.w;
      const sg = sheathGrip(sk); if (which === 2) { sg.x -= 3; sg.y += 3; sg.a -= 18; }
      const kk = easeOut(inHandK);
      let da = ang - sg.a; da = ((da + 540) % 360) - 180;
      return { x: lerp(sg.x, hand[0], kk), y: lerp(sg.y, hand[1], kk), a: sg.a + da * kk };
    };
    const opts = {
      T, vx: p.vx, grounded: p.grounded || p.dead, rot,
      sheath: (cc, sk) => { // scabbard / strap on back
        const g = sheathGrip(sk);
        if (k === 'sword') { cc.save(); cc.translate(g.x, g.y); cc.rotate(-g.a * D2R); poly(cc, [-10, 2, 10, 2, 11, 96, 0, 102, -11, 96], '#2a1a12', '#07050a', 2); cc.fillStyle = '#8a7048'; cc.fillRect(-11, 4, 22, 5); cc.fillRect(-11, 50, 22, 4); cc.fillRect(-11, 88, 22, 4); cc.restore(); }
        else if (k === 'dual') { [0, 1].forEach(i => { cc.save(); cc.translate(g.x - i * 3, g.y + i * 3); cc.rotate(-(g.a - i * 18) * D2R); poly(cc, [-6, 2, 6, 2, 5, 56, 0, 60, -5, 56], '#2a0a0a', '#07050a', 1.5); cc.restore(); }); }
        else { cc.strokeStyle = '#1a0f08'; cc.lineWidth = 3; cc.beginPath(); cc.moveTo(g.x - 4, g.y - 8); cc.lineTo(g.x + 4, g.y + 8); cc.stroke(); }
        if (inHandK < 1) { const wp = weaponAt(sk, 1); if (inHandK === 0 || p.act && p.act.name === 'sheath' && p.drawK < 0.05) drawWeaponAt(cc, wd.id, wp.x, wp.y, wp.a, tint, T); }
        if (k === 'dual' && inHandK === 0) { const wp = weaponAt(sk, 2); drawWeaponAt(cc, wd.id, wp.x, wp.y, wp.a, tint, T); }
        if (k === 'sword' && inHandK === 0) { cc.save(); const gg = sheathGrip(sk); cc.translate(gg.x, gg.y); cc.rotate(-gg.a * D2R); poly(cc, [-10, 2, 10, 2, 11, 96, 0, 102, -11, 96], 'rgba(42,26,18,0.92)', '#07050a', 2); cc.fillStyle = '#8a7048'; cc.fillRect(-11, 4, 22, 5); cc.fillRect(-11, 50, 22, 4); cc.fillRect(-11, 88, 22, 4); cc.restore(); }
      },
      weapon: (cc, sk) => { if (inHandK > 0) { const wp = weaponAt(sk, 1); drawWeaponAt(cc, wd.id, wp.x, wp.y, wp.a, tint, T); if (p.glint > 0) { const tip = weaponPoint(wp.x, wp.y, wp.a, WTIP[wd.id]); glint(cc, tip[0], tip[1], (p.glint / 0.35)); } } },
      weapon2: k === 'dual' ? (cc, sk) => { if (inHandK > 0) { const wp = weaponAt(sk, 2); drawWeaponAt(cc, wd.id, wp.x, wp.y, wp.a, tint, T); } } : null,
    };
    if (p.flashT > 0) { c.save(); }
    drawHumanoid(c, p.x, p.y + (p.dead ? clamp(p.deathT / 0.8, 0, 1) * 4 : 0), p.facing, PS, p.pose, p.style, opts);
    if (p.flashT > 0) { c.restore(); c.globalAlpha = p.flashT; c.fillStyle = 'rgba(255,0,0,0.0)'; }
    c.globalAlpha = 1;
  }
  function glint(cc, x, y, k) { cc.save(); cc.translate(x, y); cc.rotate(st.T * 3); cc.globalAlpha = k; cc.fillStyle = '#fff'; cc.shadowColor = '#fff'; cc.shadowBlur = 20; const s = 22 * k + 6; cc.beginPath(); cc.moveTo(0, -s); cc.lineTo(2, -2); cc.lineTo(s, 0); cc.lineTo(2, 2); cc.lineTo(0, s); cc.lineTo(-2, 2); cc.lineTo(-s, 0); cc.lineTo(-2, -2); cc.closePath(); cc.fill(); cc.restore(); cc.globalAlpha = 1; cc.shadowBlur = 0; }
  function drawTrail(tr, col) {
    if (tr.length < 2) return;
    c.save(); c.globalCompositeOperation = 'lighter';
    for (let i = 1; i < tr.length; i++) {
      const a = i / tr.length; const [t0, b0] = tr[i - 1], [t1, b1] = tr[i];
      c.fillStyle = rgba(col, a * 0.55); c.beginPath(); c.moveTo(t0[0], t0[1]); c.lineTo(t1[0], t1[1]); c.lineTo(b1[0], b1[1]); c.lineTo(b0[0], b0[1]); c.closePath(); c.fill();
    }
    c.strokeStyle = rgba('#ffffff', 0.85); c.lineWidth = 3; c.lineCap = 'round'; c.beginPath(); tr.forEach(([t], i) => i ? c.lineTo(t[0], t[1]) : c.moveTo(t[0], t[1])); c.stroke();
    c.restore();
  }
  function drawEnemy(e) {
    if (e.boss) { Bosses.draw(c, e, st); return; }
    const d = e.def, T = st.T, sc = d.scale;
    let alpha = 1; if (e.spawnT > 0) alpha = 1 - e.spawnT / 0.5;
    if (e.dead) { if (deathDraw(e)) return; }
    c.globalAlpha = alpha;
    const flash = e.flash > 0;
    drawEnemyBody(e, e.x, e.y, 0);
    if (flash) { c.globalCompositeOperation = 'source-over'; }
    c.globalAlpha = 1;
    if (!e.dead && e.hp < e.maxHp && !e.boss) { const bw = 40, hy = (e.flying ? e.y - e.h * 0.6 : e.y - e.h - 14); c.fillStyle = 'rgba(0,0,0,0.7)'; c.fillRect(e.x - bw / 2, hy, bw, 4); c.fillStyle = '#c01020'; c.fillRect(e.x - bw / 2, hy, bw * Math.max(0, e.hp / e.maxHp), 4); }
    if (e.state === 'windup' && !e.dead) { const k = 1 - e.st / (e.wdur || 0.5); c.fillStyle = `rgba(255,40,40,${0.5 + k * 0.5})`; c.font = '900 20px Georgia'; c.textAlign = 'center'; c.fillText('!', e.x, (e.flying ? e.y - 40 : e.y - e.h - 22)); }
  }
  function drawEnemyBody(e, x, y, rot) {
    const d = e.def, st2 = d.style, T = st.T, sc = d.scale; const flash = e.flash > 0;
    const s2 = flash ? Object.assign({}, st2, { skin: '#ffffff', skin2: '#dddddd', cloth: '#ffffff', body: '#ffffff', fur: '#ffffff', fur2: '#dddddd', wing: '#eeeeee' }) : st2;
    const fdir = e.facing;
    if (d.kind === 'humanoid') drawHumanoid(c, x, y, fdir, sc, enemyPose(e), s2, { T: T + e.seed, enemyWeapon: ['claws', 'fists'].includes(st2.weapon) ? null : st2.weapon, rot, grounded: e.grounded });
    else if (d.kind === 'quad') drawQuad(c, x, y, fdir, sc, s2, { T: T + e.seed, phase: e.phase, moving: e.moving || e.state === 'strike', open: e.state === 'windup' || e.state === 'strike' ? 1 : 0.2, lunge: e.state === 'strike' ? 8 : 0, crouch: e.state === 'windup' ? 6 : 0, rot });
    else if (d.kind === 'flyer') drawFlyer(c, x, y, fdir, sc, s2, { T: T + e.seed, seed: e.seed, open: e.state === 'windup' ? 1 : 0, rot, lookX: clamp((st.p.x - e.x) / 100, -6, 6), lookY: clamp((st.p.y - 60 - e.y) / 100, -4, 4) });
    else if (d.kind === 'blob') drawBlob(c, x, y, fdir, sc, s2, { T: T + e.seed, moving: e.moving, open: e.state === 'windup' ? 1 : 0, squash: e.state === 'windup' ? 0.2 : 0, rot });
  }
  function enemyPose(e) {
    const d = e.def; const ph = e.phase; const s = Math.sin(ph), cc = Math.sin(ph + Math.PI);
    const hunch = d.style.head === 'goblin' ? 18 : d.heavy ? 14 : d.style.head === 'fish' ? 16 : d.style.head === 'flesh' ? 22 : 8;
    let p = P({ t: hunch, a1u: 30, a1f: 60, w: 70, a2u: -10, a2f: 20 });
    if (d.style.weapon === 'bow') Object.assign(p, { a1u: 80, a1f: 88, w: 0, a2u: 60, a2f: 80 });
    if (d.style.weapon === 'spear' || d.style.weapon === 'trident') Object.assign(p, { a1u: 40, a1f: 85, w: 95 });
    if (e.moving) Object.assign(p, { l1t: 28 * s, l1s: 28 * s - 30 * Math.max(0, Math.sin(ph - 1.3)), l2t: 28 * cc, l2s: 28 * cc - 30 * Math.max(0, Math.sin(ph - 1.3 + Math.PI)), a2u: -25 * s, a2f: -25 * s + 30 });
    if (e.state === 'windup') { const k = clamp(1 - e.st / (e.wdur || 0.5), 0, 1); const tgt = d.ranged ? { a1u: 90, a1f: 90, a2u: 75, a2f: 30 } : (d.style.weapon === 'spear' || d.style.weapon === 'trident' ? { t: -6, a1u: 10, a1f: 60, w: 92 } : { t: -8, a1u: 168, a1f: 196, w: 212, a2u: -30, a2f: -10 }); p = lerpPose(p, Object.assign({}, p, tgt), ease(k)); }
    if (e.state === 'strike') { p = Object.assign(p, d.style.weapon === 'spear' || d.style.weapon === 'trident' ? { t: 20, a1u: 88, a1f: 90, w: 92, l1t: 36, l2t: -30 } : { t: 22, a1u: 78, a1f: 55, w: 26, a2u: -40, a2f: -30, l1t: 30, l1s: 4, l2t: -26, l2s: -10 }); }
    if (e.state === 'hurt') Object.assign(p, { t: -24, h: -25, a1u: -40, a1f: -20, w: -40, a2u: 60, a2f: 90 });
    if (!e.grounded && !e.flying) Object.assign(p, { t: -30, l1t: 40, l1s: 0, l2t: -20, l2s: -40 });
    return p;
  }
  function deathDraw(e) {
    const t = e.deathT; const d = e.def;
    if (e.deathStyle === 'cleave' || e.deathStyle === 'shatter') {
      if (t > 1.8) return true; const a = clamp(1.8 - t, 0, 1);
      const midY = (e.flying ? e.y : e.y - e.h * 0.5);
      const pieces = e.deathStyle === 'shatter' ? 4 : 2;
      for (let i = 0; i < pieces; i++) {
        c.save(); c.globalAlpha = a;
        const top = i === 0; const ox = (e.dvx * 0.4) * t * (top ? 1 : 0.3) + (e.deathStyle === 'shatter' ? (i - 1.5) * 60 * t : 0);
        const oy = top ? Math.min(e.dvy * t + 900 * t * t, (e.flying ? GY - e.y : 0) + e.h * 0.4) : (e.flying ? Math.min(900 * t * t, GY - e.y) : 0);
        c.beginPath(); if (pieces === 2) { if (top) c.rect(e.x - 200, midY - 400, 400, 400 - 4 + Math.sin(i) * 0); else c.rect(e.x - 200, midY + 2, 400, 400); } else { const qx = i % 2 ? 0 : -200, qy = i < 2 ? -400 : 0; c.rect(e.x + qx, midY + qy, 200, 400); }
        c.clip(); c.translate(ox, oy); if (top) { c.translate(e.x, midY); c.rotate(t * 3 * Math.sign(e.dvx)); c.translate(-e.x, -midY); }
        drawEnemyBody(e, e.x, e.y, 0); c.restore();
        if (top && t < 0.8) blood(e.x + ox, midY + oy, d.blood, 1, Math.sign(e.dvx), 0.5);
      }
      if (e.deathStyle === 'shatter' && !e.shattered) { e.shattered = true; for (let i = 0; i < 20; i++) part({ x: e.x, y: midY, vx: rnd(-400, 400), vy: rnd(-500, 0), g: 1400, r: rnd(3, 7), col: '#e0f4ff', life: 1, type: 'shard', rot: rnd(0, 6), vr: rnd(-10, 10) }); AudioSys.play('ice'); }
      c.globalAlpha = 1; return true;
    }
    if (e.deathStyle === 'ash') {
      if (!e.ashed) { e.ashed = true; for (let i = 0; i < 40; i++) part({ x: e.x + rnd(-e.w / 2, e.w / 2), y: e.y - rnd(0, e.h), vx: rnd(-40, 40), vy: rnd(-160, -40), r: rnd(1.5, 4), col: Math.random() < 0.4 ? '#ff7a1a' : '#2a2a2a', life: rnd(0.8, 1.6), type: 'glow' }); AudioSys.play('fire'); }
      if (t > 0.6) return true; c.save(); c.globalAlpha = 1 - t / 0.6; c.filter = 'brightness(0.3)'; drawEnemyBody(e, e.x, e.y, 0); c.restore(); c.globalAlpha = 1; return true;
    }
    if (e.deathStyle === 'soul') {
      if (t < 0.6 && Math.random() < 0.6) part({ x: e.x, y: e.y - e.h * 0.6, vx: rnd(-20, 20), vy: -220, r: rnd(4, 8), col: '#9fe8ff', life: 0.8, type: 'soul' });
    }
    // collapse
    if (t > 2.0) return true;
    const k = clamp(t / 0.5, 0, 1); c.save(); c.globalAlpha = clamp(2.0 - t, 0, 1);
    if (e.flying) { const fy = Math.min(e.y + 600 * t * t, GY - 8); drawEnemyBody(e, e.x, fy, -k * 1.4 * e.facing); }
    else { drawEnemyBody(e, e.x, e.y + k * 4, -k * 1.45); }
    c.restore(); return true;
  }
  function drawProj(pr) {
    const P0 = PROJ[pr.type] || {}; c.save(); c.translate(pr.x, pr.y);
    switch (pr.type) {
      case 'arrow': c.rotate(Math.atan2(pr.vy, pr.vx)); c.strokeStyle = '#d8d0b0'; c.lineWidth = 2; c.beginPath(); c.moveTo(-18, 0); c.lineTo(10, 0); c.stroke(); poly(c, [10, -3, 16, 0, 10, 3], '#aaa'); break;
      case 'fireball': case 'meteor': { const r = pr.r; const g = c.createRadialGradient(0, 0, 1, 0, 0, r * 1.8); g.addColorStop(0, '#fff6c0'); g.addColorStop(0.4, '#ff8a1a'); g.addColorStop(1, 'rgba(255,40,0,0)'); c.fillStyle = g; c.beginPath(); c.arc(0, 0, r * 1.8, 0, 7); c.fill(); if (pr.type === 'meteor') circ(c, 0, 0, r * 0.7, '#3a1a0a'); break; }
      case 'icicle': c.rotate(Math.atan2(pr.vy, pr.vx)); poly(c, [-14, -4, 14, 0, -14, 4], '#dff8ff', '#3a8aba', 1.5); break;
      case 'eyebolt': { c.shadowColor = '#f00'; c.shadowBlur = 14; circ(c, 0, 0, pr.r, '#fff'); circ(c, Math.sign(pr.vx) * 2, 0, pr.r * 0.6, '#c00'); circ(c, Math.sign(pr.vx) * 3, 0, pr.r * 0.3, '#000'); break; }
      case 'bomb': circ(c, 0, 0, pr.r, '#222', '#000'); c.strokeStyle = '#a80'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -pr.r); c.lineTo(4, -pr.r - 6); c.stroke(); circ(c, 4, -pr.r - 7, 3, Math.random() < 0.5 ? '#ff0' : '#f80'); break;
      case 'boulder': c.rotate(pr.t * 6 * Math.sign(pr.vx || 1)); poly(c, [-pr.r, 0, -pr.r * 0.6, -pr.r * 0.8, pr.r * 0.4, -pr.r, pr.r, -pr.r * 0.2, pr.r * 0.7, pr.r * 0.8, -pr.r * 0.4, pr.r * 0.9], '#bfeaff', '#3a7aaa', 3); break;
      case 'acid': case 'ink': case 'drop': circ(c, 0, 0, pr.r, P0.col, '#000', 1.5); break;
      case 'feather': c.rotate(Math.atan2(pr.vy, pr.vx)); c.fillStyle = '#fff6d0'; c.shadowColor = '#fff2b0'; c.shadowBlur = 10; c.beginPath(); c.ellipse(0, 0, 14, 3.5, 0, 0, 7); c.fill(); break;
      case 'iceshard': poly(c, [-7, -26, 7, -26, 0, 14], '#dff6ff', '#4a8ab0', 1.5); break;
      case 'spear': c.rotate(Math.PI / 2); c.shadowColor = '#fff2b0'; c.shadowBlur = 16; poly(c, [-3, -40, 3, -40, 3, 10, 7, 10, 0, 26, -7, 10, -3, 10], '#fff6d0'); break;
      case 'sonic': for (let i = 0; i < 3; i++) { c.strokeStyle = `rgba(200,140,255,${0.8 - i * 0.25})`; c.lineWidth = 3; c.beginPath(); c.arc(-Math.sign(pr.vx) * i * 10, 0, pr.r + i * 4, -1, 1); c.stroke(); } break;
      case 'shock': case 'frost': case 'wave': case 'glitchwave': case 'quake': {
        const col = pr.type === 'quake' ? '#ffb070' : P0.col; const h = pr.r * 1.8;
        const g = c.createLinearGradient(0, -h, 0, 10); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, rgba(col, 0.85)); c.fillStyle = g;
        if (pr.type === 'glitchwave') { for (let i = 0; i < 6; i++) { c.fillStyle = Math.random() < 0.5 ? '#fff' : '#000'; c.fillRect(rnd(-30, 20), -rnd(0, h), rnd(10, 40), rnd(3, 10)); } }
        else { c.beginPath(); c.moveTo(-pr.r, 12); for (let i = 0; i <= 8; i++) c.lineTo(-pr.r + i * pr.r / 4, 12 - h * (0.4 + 0.6 * Math.abs(Math.sin(i + pr.t * 20)))); c.lineTo(pr.r, 12); c.fill(); }
        if (pr.type === 'wave') { c.fillStyle = 'rgba(200,255,250,0.6)'; c.fillRect(-pr.r, -h * 0.9, pr.r * 2, 4); }
        break; }
      case 'crescent': { c.globalCompositeOperation = 'lighter'; c.scale(pr.facing || Math.sign(pr.vx) || 1, 1); const a = clamp(1 - pr.t / pr.life, 0, 1); c.globalAlpha = a; for (let i = 0; i < 3; i++) { c.strokeStyle = i === 0 ? '#ffffff' : i === 1 ? 'rgba(180,220,255,0.7)' : 'rgba(120,160,255,0.35)'; c.lineWidth = [5, 10, 18][i]; c.beginPath(); c.arc(-30, 0, 62, -1.05, 1.05); c.stroke(); } break; }
      case 'lance': { c.globalCompositeOperation = 'lighter'; const dir = Math.sign(pr.vx); const g = c.createLinearGradient(-dir * 200, 0, dir * 40, 0); g.addColorStop(0, 'rgba(120,60,255,0)'); g.addColorStop(1, 'rgba(200,170,255,0.95)'); c.fillStyle = g; c.fillRect(Math.min(-dir * 200, dir * 40), -10, 240, 20); c.scale(dir, 1); c.shadowColor = '#a67cff'; c.shadowBlur = 20; poly(c, [10, -14, 56, 0, 10, 14, 22, 0], '#f0e8ff'); break; }
    }
    c.restore();
  }
  function drawHazards(ground) {
    const T = st.T;
    for (const h of st.hazards) {
      const warn = h.t < h.warn; const k = warn ? h.t / h.warn : 1;
      if (ground) { if (warn) { c.fillStyle = `rgba(255,30,30,${0.25 + 0.35 * Math.sin(h.t * 20) ** 2})`; c.beginPath(); c.ellipse(h.x, GY + 6, h.w / 2, 8, 0, 0, 7); c.fill(); } if (h.type === 'acid' && !warn) { if (h.fire) { c.save(); c.globalCompositeOperation = 'lighter'; for (let i = 0; i < 7; i++) { const fx = h.x - h.w / 2 + (i + 0.5) * h.w / 7, fh = 26 + 22 * Math.abs(Math.sin(T * 9 + i * 1.7)); const g = c.createLinearGradient(0, GY - fh, 0, GY + 4); g.addColorStop(0, 'rgba(255,200,60,0)'); g.addColorStop(0.5, 'rgba(255,120,20,0.7)'); g.addColorStop(1, 'rgba(255,240,180,0.9)'); c.fillStyle = g; c.beginPath(); c.moveTo(fx - 10, GY + 4); c.quadraticCurveTo(fx - 6, GY - fh * 0.5, fx + Math.sin(T * 7 + i) * 4, GY - fh); c.quadraticCurveTo(fx + 6, GY - fh * 0.5, fx + 10, GY + 4); c.fill(); } c.restore(); } else { c.fillStyle = 'rgba(150,255,60,0.5)'; c.beginPath(); c.ellipse(h.x, GY + 4, h.w / 2, 7, 0, 0, 7); c.fill(); } } continue; }
      if (warn) { if (h.type === 'pillar') { c.fillStyle = `rgba(255,240,180,${0.12 + k * 0.15})`; c.fillRect(h.x - h.w / 2 * k, 0, h.w * k, GY); } continue; }
      const at = h.t - h.warn, rise = clamp(at / 0.1, 0, 1) * (at > h.active - 0.15 ? clamp((h.active - at) / 0.15, 0, 1) : 1);
      if (h.type === 'spike' || h.type === 'icespike') { const col = h.type === 'icespike' ? '#bfeaff' : (h.col || '#9a9890'); for (let i = -1; i <= 1; i++) poly(c, [h.x + i * 14 - 9, GY + 4, h.x + i * 14, GY - (h.h || 100) * rise * (i ? 0.7 : 1), h.x + i * 14 + 9, GY + 4], col, '#07050a', 2); }
      if (h.type === 'tentacle') { const hh = (h.h || 160) * rise; c.strokeStyle = h.col || '#1c5048'; c.lineWidth = 26; c.lineCap = 'round'; c.beginPath(); c.moveTo(h.x, GY + 10); c.quadraticCurveTo(h.x + Math.sin(T * 8) * 20, GY - hh * 0.5, h.x + Math.sin(T * 5) * 14, GY - hh); c.stroke(); c.strokeStyle = 'rgba(255,200,200,0.3)'; c.lineWidth = 4; c.stroke(); for (let i = 0; i < 5; i++) circ(c, h.x + 9 + Math.sin(T * 8) * 10 * (i / 5), GY - hh * (i / 5), 3, '#d8a0a0'); }
      if (h.type === 'pillar') { c.save(); c.globalCompositeOperation = 'lighter'; const g = c.createLinearGradient(h.x - h.w / 2, 0, h.x + h.w / 2, 0); g.addColorStop(0, 'rgba(255,240,180,0)'); g.addColorStop(0.5, `rgba(255,250,220,${rise})`); g.addColorStop(1, 'rgba(255,240,180,0)'); c.fillStyle = g; c.fillRect(h.x - h.w / 2, 0, h.w, GY + 10); c.restore(); }
    }
  }
  function drawBeams() {
    for (const b of st.beams) {
      const warn = b.t < b.warn; const x0 = Math.min(b.x0, b.x1), x1 = Math.max(b.x0, b.x1);
      if (warn) { c.strokeStyle = `rgba(255,0,0,${0.3 + 0.5 * Math.abs(Math.sin(b.t * 18))})`; c.lineWidth = 2; c.setLineDash([12, 8]); c.beginPath(); c.moveTo(x0, b.y); c.lineTo(x1, b.y); c.stroke(); c.setLineDash([]); continue; }
      const at = b.t - b.warn; const k = at < 0.06 ? at / 0.06 : (at > b.active - 0.1 ? Math.max(0, (b.active - at) / 0.1) : 1);
      c.save(); c.globalCompositeOperation = 'lighter'; const th = b.thick * k;
      const g = c.createLinearGradient(0, b.y - th, 0, b.y + th); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, rgba(b.col || '#ff2020', 0.95)); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(x0, b.y - th, x1 - x0, th * 2);
      c.fillStyle = `rgba(255,255,255,${0.9 * k})`; c.fillRect(x0, b.y - th * 0.18, x1 - x0, th * 0.36); c.restore();
      if (Math.random() < 0.5) sparks(rnd(x0, x1), b.y, b.col || '#f22', 2);
    }
  }
  function drawPickup(k) {
    const T = st.T; c.save(); c.translate(k.x, k.y);
    if (k.type === 'soul') { c.globalCompositeOperation = 'lighter'; c.drawImage(tintGlow('rgba(90,255,200,0.85)'), -12, -12, 24, 24); c.fillStyle = '#e0fff8'; c.beginPath(); c.arc(0, 0, 2.5, 0, 7); c.fill(); }
    else if (k.type === 'shard') { c.translate(0, Math.sin(T * 3) * 5); c.globalCompositeOperation = 'lighter'; c.drawImage(tintGlow('rgba(255,40,40,0.8)'), -26, -26, 52, 52); c.globalCompositeOperation = 'source-over'; c.rotate(Math.sin(T * 1.5) * 0.3); poly(c, [0, -14, 7, -2, 3, 12, -6, 6, -5, -6], '#2a0008', '#ff3a3a', 1.5); c.fillStyle = '#efe6d8'; c.beginPath(); c.ellipse(0, -1, 3.5, 2.2, 0, 0, 7); c.fill(); c.fillStyle = '#a00010'; c.beginPath(); c.arc(0, -1, 1.4, 0, 7); c.fill(); }
    else if (k.type === 'heal') { c.shadowColor = '#f22'; c.shadowBlur = 14; c.fillStyle = '#d0102a'; c.beginPath(); c.moveTo(0, 8); c.bezierCurveTo(-14, -2, -8, -14, 0, -6); c.bezierCurveTo(8, -14, 14, -2, 0, 8); c.fill(); }
    else if (k.type === 'weapon') { c.globalCompositeOperation = 'lighter'; const g = c.createLinearGradient(0, -400, 0, 60); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(255,230,180,0.35)'); c.fillStyle = g; c.fillRect(-30, -400, 60, 460); c.globalCompositeOperation = 'source-over'; c.translate(0, Math.sin(T * 3) * 6); drawWeaponAt(c, k.id, 0, -30, 180 + Math.sin(T * 2) * 10, null, T); c.font = '700 13px Georgia'; c.fillStyle = '#fff'; c.textAlign = 'center'; c.fillText('TAKE IT', 0, 50); }
    c.restore();
  }
  function drawPart(q) {
    const a = 1 - q.t / q.life;
    switch (q.type) {
      case 'blood': c.fillStyle = q.col; c.globalAlpha = Math.min(1, a * 2); c.beginPath(); c.arc(q.x, q.y, q.r, 0, 7); c.fill(); break;
      case 'spark': c.strokeStyle = q.col; c.globalAlpha = a; c.lineWidth = q.r; c.beginPath(); c.moveTo(q.x, q.y); c.lineTo(q.x - q.vx * 0.03, q.y - q.vy * 0.03); c.stroke(); break;
      case 'dust': c.fillStyle = q.col; c.globalAlpha = a * 0.8; c.beginPath(); c.arc(q.x, q.y, q.r * (1 + q.t * 2), 0, 7); c.fill(); break;
      case 'fog': c.fillStyle = q.col; c.globalAlpha = Math.min(1, a * 3, q.t); c.beginPath(); c.ellipse(q.x, q.y, q.r * 3, q.r, 0, 0, 7); c.fill(); break;
      case 'ring': c.strokeStyle = q.col; c.globalAlpha = a; c.lineWidth = 4 * a + 1; c.beginPath(); c.arc(q.x, q.y, q.r * (1 - a * 0.7), 0, 7); c.stroke(); break;
      case 'chunk': case 'shard': c.save(); c.translate(q.x, q.y); c.rotate(q.rot); c.globalAlpha = Math.min(1, a * 3); c.fillStyle = q.col; c.strokeStyle = '#07050a'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-q.r, -q.r * 0.6); c.lineTo(q.r * 0.8, -q.r); c.lineTo(q.r, q.r * 0.7); c.lineTo(-q.r * 0.5, q.r); c.closePath(); c.fill(); c.stroke(); c.restore(); break;
      case 'glow': case 'soul': { c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = a; c.drawImage(tintGlow(q.col), q.x - q.r * 2, q.y - q.r * 2, q.r * 4, q.r * 4); c.restore(); if (q.type === 'soul') { q.y -= 1; } break; }
      case 'crown': c.save(); c.translate(q.x, q.y); c.rotate(q.rot); c.globalAlpha = Math.min(1, a * 3); poly(c, [-12, 6, -14, -8, -7, -2, 0, -12, 7, -2, 14, -8, 12, 6], '#e8c04a', '#3a2a08', 1.5); circ(c, 0, -4, 2.5, '#c0102a'); c.restore(); break;
      case 'bat': { c.save(); c.translate(q.x, q.y); c.globalAlpha = Math.min(1, a * 3); const fl = Math.sin(q.t * 40) * 6; c.fillStyle = '#0a0608'; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-8, -6 - fl, -16, -2 + fl * 0.5); c.quadraticCurveTo(-9, 0, -6, 4); c.lineTo(0, 2); c.lineTo(6, 4); c.quadraticCurveTo(9, 0, 16, -2 + fl * 0.5); c.quadraticCurveTo(8, -6 - fl, 0, 0); c.fill(); c.fillStyle = '#f22'; c.fillRect(-2, -1, 1.2, 1.2); c.fillRect(1, -1, 1.2, 1.2); c.restore(); break; }
      case 'feather': c.save(); c.translate(q.x + Math.sin(q.t * 3) * 10, q.y); c.rotate(q.rot); c.globalAlpha = Math.min(1, a * 2); c.fillStyle = q.col || '#f6f0e0'; c.beginPath(); c.ellipse(0, 0, q.r * 2 || 10, (q.r || 5) * 0.55, 0, 0, 7); c.fill(); c.strokeStyle = 'rgba(0,0,0,0.25)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(-(q.r * 2 || 10), 0); c.lineTo(q.r * 2 || 10, 0); c.stroke(); c.restore(); break;
      case 'glint': { c.save(); c.globalCompositeOperation = 'lighter'; const k2 = Math.sin(clamp(q.t / q.life, 0, 1) * Math.PI); c.globalAlpha = k2; c.strokeStyle = q.col; c.lineWidth = 2; const R = q.r * (0.6 + k2 * 0.6); c.beginPath(); c.moveTo(q.x - R, q.y); c.lineTo(q.x + R, q.y); c.moveTo(q.x, q.y - R * 0.6); c.lineTo(q.x, q.y + R * 0.6); c.stroke(); c.drawImage(tintGlow(q.col), q.x - R * 0.6, q.y - R * 0.6, R * 1.2, R * 1.2); c.restore(); break; }
      case 'drop': c.fillStyle = q.col; c.globalAlpha = Math.min(1, a * 2); c.beginPath(); c.ellipse(q.x, q.y, q.r, q.r * 1.6, Math.atan2(q.vy, q.vx) + Math.PI / 2, 0, 7); c.fill(); break;
      case 'dot': c.fillStyle = q.col; c.globalAlpha = Math.min(1, a * 3); c.fillRect(q.x, q.y, q.r, q.r); break;
      case 'bubble': c.strokeStyle = q.col; c.globalAlpha = a; c.lineWidth = 1; c.beginPath(); c.arc(q.x + Math.sin(q.t * 4) * 3, q.y, q.r, 0, 7); c.stroke(); break;
      case 'leaf': c.save(); c.translate(q.x + Math.sin(q.t * 2) * 20, q.y); c.rotate(q.rot); c.fillStyle = q.col; c.globalAlpha = Math.min(1, a * 3); c.beginPath(); c.ellipse(0, 0, q.r, q.r * 0.5, 0, 0, 7); c.fill(); c.restore(); break;
      case 'slashmark': c.save(); c.translate(q.x, q.y); c.rotate(q.rot); c.globalAlpha = a; c.globalCompositeOperation = 'lighter'; c.fillStyle = '#fff'; c.beginPath(); c.ellipse(0, 0, q.r, 3 * a + 1, 0, 0, 7); c.fill(); c.fillStyle = rgba(trailCol(), 0.8); c.beginPath(); c.ellipse(0, 0, q.r * 1.1, 7 * a, 0, 0, 7); c.fill(); c.restore(); break;
      case 'crack': c.save(); c.globalAlpha = Math.min(1, a * 2); c.strokeStyle = '#050304'; c.lineWidth = 3; const rr = q.r; c.beginPath(); for (let i = 0; i < 7; i++) { const dir = (i % 2 ? 1 : -1) * (0.3 + i * 0.12); c.moveTo(q.x, q.y); c.lineTo(q.x + dir * rr * 0.5, q.y + 4 + (i % 3) * 3); c.lineTo(q.x + dir * rr, q.y + 2 + (i % 4) * 4); } c.stroke(); c.fillStyle = 'rgba(255,120,40,0.25)'; c.beginPath(); c.ellipse(q.x, q.y + 4, rr * 0.5 * a, 4, 0, 0, 7); c.fill(); c.restore(); break;
      case 'rockspike': { const rise = Math.sin(clamp(q.t / q.life, 0, 1) * Math.PI); poly(c, [q.x - q.r * 0.5, GY + 6, q.x, GY - q.r * 2.4 * rise, q.x + q.r * 0.5, GY + 6], st.S.ground2 === '#000000' ? '#222' : shade(st.S.ground, 0.15), '#07050a', 2); break; }
      case 'glitch': c.fillStyle = q.col; c.globalAlpha = a; c.fillRect(q.x, q.y, q.w, q.h); break;
    }
    c.globalAlpha = 1;
  }
  function drawStare() {
    const W = HW; const s = st.stare; const k = clamp(s.t / s.dur, 0, 1);
    c.save(); c.textAlign = 'center'; c.font = `900 ${28 + k * 18}px "Cinzel", Georgia, serif`; const jx = rnd(-2, 2) * k * 3;
    c.fillStyle = `rgba(0,0,0,${0.25 + k * 0.35})`; c.fillRect(0, 0, W, VH);
    c.fillStyle = '#fff'; c.shadowColor = '#f00'; c.shadowBlur = 20; c.fillText(s.text || "DON'T LOOK AT ME", W / 2 + jx, 150); c.shadowBlur = 0;
    c.font = '600 15px Georgia'; c.fillStyle = 'rgba(255,200,200,0.85)'; c.fillText('turn your back to it', W / 2, 178); c.restore();
  }
  function distortFX(k) {
    // horizontal slice offsets (cheap glitch), no strobing — done in raw pixels so it works at any zoom
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0); const n = 6; for (let i = 0; i < n; i++) { if (Math.random() > k) continue; const y = rnd(0, cv.height), h = rnd(4, 30) * dpr, dx = rnd(-30, 30) * k * dpr; try { c.drawImage(cv, 0, y, cv.width, h, dx, y, cv.width, h); } catch (e) {} } c.restore();
  }
  function drawEyeKill() {
    const W = HW; const t = st.eyekill.t; const k = clamp(t / 2.4, 0, 1);
    c.fillStyle = `rgba(0,0,0,${k * 0.6})`; c.fillRect(0, 0, W, VH);
    if (t > 0.9) { c.save(); c.textAlign = 'center'; c.font = '900 34px "Cinzel", Georgia, serif'; c.fillStyle = `rgba(255,255,255,${clamp((t - 0.9) * 2, 0, 1)})`; c.fillText('I SEE YOU', W / 2 + rnd(-2, 2), VH / 2 - 120); c.restore(); }
    if (t > 1.5) distortFX(clamp((t - 1.5), 0, 1));
  }

  function drawBanner() {
    const W = HW; if (!st.banner) return; const bn = st.banner; const a = clamp(Math.min(bn.t, 3.4 - bn.t + 0.5) * 2, 0, 1); c.save(); c.globalAlpha = a; c.textAlign = 'center';
    if (!bn.small) { const g = c.createLinearGradient(0, 0, W, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, 'rgba(0,0,0,0.65)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, VH * 0.3 - 40, W, 84); c.fillStyle = bn.boss ? 'rgba(200,20,30,0.7)' : 'rgba(240,230,216,0.35)'; c.fillRect(W * 0.2, VH * 0.3 - 40, W * 0.6, 1); c.fillRect(W * 0.2, VH * 0.3 + 43, W * 0.6, 1); }
    c.font = `900 ${bn.small ? 24 : (bn.boss ? 30 : 38)}px "Cinzel", Georgia, serif`; c.fillStyle = bn.boss ? '#ff3a3a' : '#f0e6d8'; c.shadowColor = '#000'; c.shadowBlur = 10; c.fillText(bn.text, W / 2, VH * 0.3 + (bn.small ? 0 : 6)); c.shadowBlur = 0;
    if (bn.sub) { c.font = 'italic 14px Georgia'; c.fillStyle = 'rgba(255,220,210,0.85)'; c.fillText(bn.sub, W / 2, VH * 0.3 + 30); }
    c.restore();
  }
  function drawBannerOnly() { drawBanner(); drawVictory(); }
  function drawVictory() {
    const W = HW, v = st.victory; if (!v || v.t > 6.5) return; const a = clamp(Math.min(v.t * 2, (6.5 - v.t) * 2), 0, 1);
    c.save(); c.globalAlpha = a; c.textAlign = 'center'; const y = VH * 0.36;
    const g = c.createLinearGradient(0, 0, W, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, 'rgba(10,0,2,0.75)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, y - 60, W, 130);
    c.font = '900 40px "Cinzel", Georgia, serif'; c.fillStyle = '#e8c04a'; c.shadowColor = '#000'; c.shadowBlur = 14; c.fillText('VANQUISHED', W / 2, y); c.shadowBlur = 0;
    c.font = '700 13px "Cinzel", Georgia, serif'; c.fillStyle = 'rgba(255,235,210,0.85)'; c.fillText(v.name, W / 2, y + 22);
    if (v.t > 0.9) { const gk = clamp((v.t - 0.9) * 3, 0, 1); c.save(); c.translate(W / 2, y + 50); c.scale(2 - gk, 2 - gk); c.font = '900 26px "Cinzel", Georgia, serif'; c.fillStyle = v.grade === 'S' ? '#ff3a3a' : v.grade === 'A' ? '#ffb02a' : '#f0e6d8'; c.fillText(v.grade || 'C', 0, 8); c.restore(); }
    if (v.t > 1.4) { c.font = '700 12px Georgia'; c.fillStyle = '#7affd8'; c.textAlign = 'right'; c.fillText('◈ +' + v.souls, W / 2 - 34, y + 54); c.textAlign = 'left'; c.fillStyle = '#ffd890'; c.fillText('+' + Math.round(v.xp) + ' XP', W / 2 + 34, y + 54); }
    c.restore();
  }
  function drawHUD() {
    const W = HW, p = st.p, wd = weaponDef();
    c.save();
    // health
    const hx = 14, hy = 12, hw = Math.min(200, W * 0.22);
    c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(hx - 2, hy - 2, hw + 4, 15);
    const hk = Math.max(0, p.hp / p.maxHp); p.hpShow = lerp(p.hpShow ?? hk, hk, 0.06);
    c.fillStyle = 'rgba(255,220,200,0.55)'; c.fillRect(hx, hy, hw * p.hpShow, 11);
    const hg = c.createLinearGradient(hx, 0, hx + hw, 0); hg.addColorStop(0, '#5a0008'); hg.addColorStop(1, '#d01a2a'); c.fillStyle = hg; c.fillRect(hx, hy, hw * hk, 11);
    c.fillStyle = 'rgba(255,255,255,0.15)'; c.fillRect(hx, hy, hw * hk, 3);
    c.strokeStyle = 'rgba(255,255,255,0.25)'; c.lineWidth = 1; c.strokeRect(hx - 2, hy - 2, hw + 4, 15);
    c.font = '700 9px Georgia'; c.fillStyle = '#fff'; c.textAlign = 'left'; c.fillText(Math.ceil(p.hp) + ' / ' + p.maxHp, hx + 4, hy + 9);
    // rage (scales to rage cap; tick marks show special cost)
    const rw = hw * 0.75 * (p.rageMax / 100), cost = specCost();
    c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(hx - 2, hy + 16, rw + 4, 7);
    const ready = p.rage >= cost; c.fillStyle = ready ? (Math.floor(st.T * 4) % 2 ? '#ffb02a' : '#ff7a1a') : '#8a5a1a'; c.fillRect(hx, hy + 17, rw * p.rage / p.rageMax, 5);
    c.fillStyle = 'rgba(255,255,255,0.55)'; for (let r = cost; r < p.rageMax; r += cost) c.fillRect(hx + rw * r / p.rageMax, hy + 16, 1, 7);
    // weapon slots + mastery
    const sy = hy + 28; c.font = '700 8px Georgia';
    WEAPONS.forEach((w, i) => {
      const x = hx + i * 22, owned = Save.d.weapons.includes(w.id), cur = w.id === p.weapon;
      c.fillStyle = cur ? 'rgba(160,20,30,0.75)' : 'rgba(0,0,0,0.55)'; c.fillRect(x, sy, 19, 19); c.strokeStyle = cur ? '#ff4a4a' : 'rgba(255,255,255,0.2)'; c.strokeRect(x + 0.5, sy + 0.5, 18, 18);
      if (owned) { c.save(); c.beginPath(); c.rect(x, sy, 19, 19); c.clip(); drawWeaponIcon(c, w.id, x + 9.5, sy + 9.5, 19, null, st.T); c.restore(); }
      else { c.fillStyle = 'rgba(255,255,255,0.3)'; c.textAlign = 'center'; c.fillText('?', x + 9.5, sy + 13); }
    });
    c.textAlign = 'left'; c.font = '700 10px Georgia'; c.fillStyle = 'rgba(255,220,200,0.85)'; c.fillText(wd.name, hx + 114, sy + 9);
    c.font = '700 8px Georgia'; c.fillStyle = 'rgba(255,200,120,0.75)'; c.fillText('MASTERY ' + mlvl(), hx + 114, sy + 19);
    // Percy
    let ly = sy + 32;
    if (st.percy) { const d = st.percy; c.font = '700 9px Georgia'; c.fillStyle = d.dead ? 'rgba(160,160,160,0.7)' : '#e8b04a'; c.fillText(d.dead ? 'PERCY ✝' : 'PERCY', hx, ly); if (!d.dead) { c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(hx + 44, ly - 7, 70, 6); c.fillStyle = d.hp < d.maxHp * 0.3 ? '#ff5a3a' : '#e8b04a'; c.fillRect(hx + 44, ly - 7, 70 * d.hp / d.maxHp, 6); } ly += 13; }
    for (const d of (st.comps || [])) { c.font = '700 9px Georgia'; c.fillStyle = d.dead ? 'rgba(160,160,160,0.7)' : '#e8b04a'; c.fillText(d.dead ? d.C.name + ' ✝' : d.C.name, hx, ly); if (!d.dead) { c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(hx + 44, ly - 7, 70, 6); c.fillStyle = d.hp < d.maxHp * 0.3 ? '#ff5a3a' : '#e8b04a'; c.fillRect(hx + 44, ly - 7, 70 * d.hp / d.maxHp, 6); } ly += 13; }
    // modifiers
    const tags = []; if (st.nm) tags.push('NIGHTMARE'); if (st.endless) tags.push('ENDLESS · WAVE ' + (st.ewave || 1)); for (const m of st.mods) tags.push(m.toUpperCase());
    if (tags.length) { c.font = '700 8px Georgia'; c.fillStyle = 'rgba(255,90,90,0.8)'; c.fillText(tags.join('  ·  '), hx, ly); }
    // stage label
    c.textAlign = 'center'; c.font = '700 11px "Cinzel", Georgia, serif'; c.fillStyle = 'rgba(255,255,255,0.7)'; c.fillText('STAGE ' + (st.idx + 1) + ' · ' + st.S.name, W / 2, 18);
    // souls (right, under pause/change)
    c.textAlign = 'right'; c.font = '700 12px Georgia'; c.fillStyle = '#7affd8'; c.fillText('◈ ' + Save.d.souls, W - 14, 84);
    // combo
    if (st.combo >= 3) { const r = st.combo >= 30 ? 'MERCILESS' : st.combo >= 20 ? 'SAVAGE' : st.combo >= 10 ? 'BRUTAL' : 'VIOLENT'; c.textAlign = 'right'; c.font = `900 ${24 + Math.min(st.combo, 40) * 0.3}px "Cinzel", Georgia, serif`; c.fillStyle = '#fff'; c.strokeStyle = '#000'; c.lineWidth = 4; c.strokeText(st.combo + ' HITS', W - 16, 112); c.fillText(st.combo + ' HITS', W - 16, 112); c.font = '700 12px Georgia'; c.fillStyle = '#ff4a4a'; c.fillText(r, W - 16, 128); c.fillStyle = 'rgba(255,60,60,0.7)'; c.fillRect(W - 116, 133, 100 * clamp(st.comboT / 2.2, 0, 1), 2); }
    // boss bar with phase notches
    const b = st.boss; if (b && !b.dead && !(b.intro > 0)) { const bw = Math.min(W * 0.46, 440), bx = W / 2 - bw / 2, by = 28; c.fillStyle = 'rgba(0,0,0,0.7)'; c.fillRect(bx - 2, by - 2, bw + 4, 12); c.fillStyle = '#3a0008'; c.fillRect(bx, by, bw, 8); b.hpShow = lerp(b.hpShow ?? b.hp, b.hp, 0.05); c.fillStyle = '#ffcf80'; c.fillRect(bx, by, bw * Math.max(0, b.hpShow / b.maxHp), 8); c.fillStyle = b.broken > 0 ? '#ffd040' : '#c0102a'; c.fillRect(bx, by, bw * Math.max(0, b.hp / b.maxHp), 8);
      c.fillStyle = 'rgba(255,255,255,0.6)'; c.fillRect(bx + bw * 0.66, by - 2, 1, 12); c.fillRect(bx + bw * 0.33, by - 2, 1, 12);
      if (b.breakM != null) { c.fillStyle = 'rgba(255,208,64,0.8)'; c.fillRect(bx, by + 10, bw * clamp(b.breakM / (b.maxHp * 0.12), 0, 1), 2); }
      c.textAlign = 'center'; c.font = '700 10px "Cinzel", Georgia, serif'; c.fillStyle = '#fff'; c.fillText(b.def.name + (b.phaseN > 1 ? '  ·  ' + ['I', 'II', 'III'][Math.min(2, b.phaseN - 1)] : ''), W / 2, by + 24); }
    drawBanner();
    // toast (mastery / relic)
    if (st.toast) { const tt = st.toast; const a = clamp(Math.min(tt.t * 3, 1), 0, 1); c.globalAlpha = a; c.textAlign = 'center'; const y = VH * 0.5; c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(W / 2 - 150, y - 18, 300, 40); c.strokeStyle = tt.relic ? '#ff3a3a' : '#e8c04a'; c.strokeRect(W / 2 - 150, y - 18, 300, 40); c.font = '900 13px "Cinzel", Georgia, serif'; c.fillStyle = tt.relic ? '#ff6a6a' : '#e8c04a'; c.fillText(tt.text, W / 2, y - 1); c.font = 'italic 10px Georgia'; c.fillStyle = 'rgba(255,235,210,0.85)'; c.fillText(tt.sub || '', W / 2, y + 14); c.globalAlpha = 1; }
    // the Eye whispers — bottom center, with a little eye
    if (st.whisper) { const w = st.whisper; const a = clamp(Math.min((w.dur - w.t) * 3, w.t * 1.5, 1), 0, 1); c.globalAlpha = a; c.textAlign = 'left'; c.font = 'italic 13px Georgia'; const tw = c.measureText(w.text).width; const x0 = W / 2 - tw / 2 + 12, y0 = VH * 0.62; c.fillStyle = 'rgba(0,0,0,0.5)'; c.fillRect(x0 - 32, y0 - 16, tw + 44, 24); c.fillStyle = '#efe6d8'; c.beginPath(); c.ellipse(x0 - 16, y0 - 4, 8, 5, 0, 0, 7); c.fill(); c.fillStyle = '#a00010'; c.beginPath(); c.arc(x0 - 16 + Math.sin(st.T * 2) * 2, y0 - 4, 3, 0, 7); c.fill(); c.fillStyle = 'rgba(255,190,190,0.92)'; c.fillText(w.text, x0 + rnd(-0.6, 0.6), y0); c.globalAlpha = 1; }
    drawVictory();
    if (Save.d.fps) { c.textAlign = 'left'; c.font = '9px monospace'; c.fillStyle = 'rgba(120,255,120,0.55)'; c.fillText('FPS ' + (G.fps | 0) + ' · ' + (G.quality || '') + ' · dpr ' + dpr.toFixed(2), 6, VH - 6); }
    c.restore();
  }

  // ---------- testing hooks ----------
  G.textState = () => {
    if (!st) return JSON.stringify({ mode: 'none' });
    const p = st.p;
    return JSON.stringify({ coords: 'x right, y down; ground y=' + GY, stage: st.idx + 1, camX: Math.round(st.camX), lock: st.lock, wave: st.waveIdx,
      player: { x: Math.round(p.x), y: Math.round(p.y), hp: Math.round(p.hp), rage: Math.round(p.rage), weapon: p.weapon, sheathed: p.sheathed, act: p.act && p.act.name, step: p.step, spec: p.spec && p.spec.type, dead: p.dead, facing: p.facing },
      enemies: st.enemies.filter(e => !e.dead).slice(0, 12).map(e => ({ t: e.type, x: Math.round(e.x), y: Math.round(e.y), hp: Math.round(e.hp), s: e.state || (e.atk && e.atk.name) })),
      boss: st.boss ? { hp: Math.round(st.boss.hp), atk: st.boss.atk && st.boss.atk.name, dead: st.boss.dead } : null, projs: st.projs.length, combo: st.combo, souls: Save.d.souls, cleared: st.cleared });
  };
  G.debug = { skipTo: (x) => { st.p.x = x; st.camX = x - W * 0.4; }, killAll: () => st.enemies.forEach(e => { if (!e.dead) { e.hp = 1; hitEnemy(e, 999, 100, -100, { fin: true }); } }), state: () => st,
    stagger: () => st.enemies.forEach(e => { if (!e.dead && !e.boss) { e.state = 'stagger'; e.st = 3; e.stagT = 3; } }), boss: () => { st.lock = null; st.p.x = st.len - 300; st.camX = st.p.x - W * 0.4; st.waveIdx = st.waves.length; st.spawnQ = []; st.enemies.forEach(e => { if (!e.boss) e.dead = true; }); },
    abilities: () => { Save.d.abilities = ABILITIES.map(a => a.id); Save.save(); }, rage: () => { st.p.rage = st.p.rageMax; }, god: () => { st.p.maxHp = st.p.hp = 99999; } };
  G.stop = () => { G.running = false; st = null; try { AudioSys.stopAmbience(); AudioSys.setIntensity && AudioSys.setIntensity(0); } catch (e) {} };
  G.freeze = (v) => { if (st) st.frozen = v; };
  G.canvas = () => cv;
  return G;
})();
