// ===== AUDIO: fully synthesized with WebAudio =====
const AudioSys = (() => {
  let ctx = null, master, musicBus, sfxBus, comp, noiseBuf, musicNodes = [], musicTimer = null, curMusic = null;
  let musicVol = 0.6, sfxVol = 0.8, curBus = null, intensity = 0, ambNodes = [];
  const A = {};
  A.init = () => {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; }
    comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 6;
    master = ctx.createGain(); master.gain.value = 0.9;
    musicBus = ctx.createGain(); sfxBus = ctx.createGain();
    musicBus.gain.value = musicVol; sfxBus.gain.value = sfxVol;
    musicBus.connect(comp); sfxBus.connect(comp); comp.connect(master); master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    if (A._pending) { const p = A._pending; A._pending = null; A.music(p); }
  };
  A.ready = () => !!ctx;
  A.setMusic = v => { musicVol = v; if (musicBus) musicBus.gain.setTargetAtTime(v, ctx.currentTime, 0.05); };
  A.setSfx = v => { sfxVol = v; if (sfxBus) sfxBus.gain.setTargetAtTime(v, ctx.currentTime, 0.05); };
  const now = () => ctx.currentTime;
  function env(g, t, a, peak, d, sus = 0.0001) {
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(Math.max(sus, 0.0001), t + a + d);
  }
  function osc(type, f, t, dur, vol, f2, bus = curBus || sfxBus) {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(Math.max(f2, 1), t + dur);
    env(g, t, 0.005, vol, dur); o.connect(g); g.connect(bus); o.start(t); o.stop(t + dur + 0.05); return o;
  }
  function noise(t, dur, vol, ftype, f1, f2, q = 1, bus = curBus || sfxBus) {
    const s = ctx.createBufferSource(); s.buffer = noiseBuf; const f = ctx.createBiquadFilter(); f.type = ftype; f.Q.value = q;
    f.frequency.setValueAtTime(f1, t); if (f2) f.frequency.exponentialRampToValueAtTime(f2, t + dur);
    const g = ctx.createGain(); env(g, t, 0.004, vol, dur); s.connect(f); f.connect(g); g.connect(bus);
    s.start(t, Math.random()); s.stop(t + dur + 0.05); return s;
  }
  const S = {
    swing(p = 1) { const t = now(); noise(t, 0.18, 0.5, 'bandpass', 900 * p, 3500 * p, 1.4); noise(t + 0.03, 0.14, 0.25, 'highpass', 2500, 6000); },
    heavySwing() { const t = now(); noise(t, 0.35, 0.6, 'bandpass', 300, 1400, 1); osc('sine', 120, t, 0.3, 0.3, 50); },
    shing() { const t = now(); [2400, 3150, 4200].forEach((f, i) => osc('sine', f, t + i * 0.01, 0.6, 0.07)); noise(t, 0.25, 0.25, 'highpass', 5000, 9000); },
    unsheath() { const t = now(); noise(t, 0.32, 0.35, 'bandpass', 2500, 6500, 6); osc('triangle', 1800, t + 0.2, 0.4, 0.05, 2600); },
    sheath() { const t = now(); noise(t, 0.2, 0.3, 'bandpass', 5000, 1800, 5); osc('square', 220, t + 0.18, 0.06, 0.08, 120); },
    metal(p = 1) { const t = now(); [523, 1187, 1720, 2633].forEach((f, i) => osc(i % 2 ? 'square' : 'triangle', f * p, t, 0.25 + i * 0.05, 0.06)); noise(t, 0.06, 0.6, 'highpass', 3000); },
    flesh(p = 1) { const t = now(); noise(t, 0.16, 0.8, 'lowpass', 1800 * p, 200, 2); osc('sine', 140 * p, t, 0.14, 0.45, 50); },
    crunch() { const t = now(); for (let i = 0; i < 4; i++) noise(t + i * 0.025, 0.05, 0.5, 'bandpass', 1500 + Math.random() * 1500, null, 3); osc('sine', 90, t, 0.25, 0.5, 35); },
    boom(v = 1) { const t = now(); osc('sine', 110, t, 0.6, 0.8 * v, 28); noise(t, 0.5, 0.6 * v, 'lowpass', 900, 80); },
    step() { const t = now(); noise(t, 0.05, 0.12, 'lowpass', 400 + Math.random() * 200, 120); },
    land() { const t = now(); noise(t, 0.12, 0.35, 'lowpass', 600, 90); osc('sine', 80, t, 0.12, 0.25, 40); },
    jump() { const t = now(); noise(t, 0.1, 0.18, 'bandpass', 600, 1600, 1); },
    hurt() { const t = now(); osc('sawtooth', 260, t, 0.25, 0.25, 120); noise(t, 0.2, 0.4, 'lowpass', 1200, 300); },
    scream(p = 1) { const t = now(); const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(520 * p, t); o.frequency.exponentialRampToValueAtTime(900 * p, t + 0.08); o.frequency.exponentialRampToValueAtTime(180 * p, t + 0.5);
      const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 28; lg.gain.value = 40 * p; lfo.connect(lg); lg.connect(o.frequency);
      const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1200 * p; f.Q.value = 3; const g = ctx.createGain(); env(g, t, 0.02, 0.22, 0.5);
      o.connect(f); f.connect(g); g.connect(curBus || sfxBus); o.start(t); lfo.start(t); o.stop(t + 0.6); lfo.stop(t + 0.6); },
    growl(p = 1, dur = 0.8) { const t = now(); const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(70 * p, t); o.frequency.linearRampToValueAtTime(55 * p, t + dur);
      const am = ctx.createOscillator(), ag = ctx.createGain(); am.frequency.value = 17; ag.gain.value = 0.5; const g = ctx.createGain(); env(g, t, 0.08, 0.5, dur);
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 500; am.connect(ag); ag.connect(g.gain);
      o.connect(f); f.connect(g); g.connect(curBus || sfxBus); o.start(t); am.start(t); o.stop(t + dur + 0.1); am.stop(t + dur + 0.1); noise(t, dur, 0.25, 'bandpass', 250, 120, 2); },
    roar() { S.growl(1.4, 1.6); const t = now(); noise(t, 1.4, 0.5, 'bandpass', 700, 200, 1.5); osc('sawtooth', 160, t, 1.2, 0.2, 60); },
    screech() { const t = now(); for (let i = 0; i < 3; i++) osc('sawtooth', 1400 + i * 333, t, 0.5, 0.08, 700 + i * 200); noise(t, 0.5, 0.3, 'highpass', 3000); },
    fire() { const t = now(); noise(t, 0.5, 0.5, 'lowpass', 2000, 300, 0.7); osc('sine', 60, t, 0.4, 0.3, 40); },
    ice() { const t = now(); for (let i = 0; i < 5; i++) osc('sine', 2000 + Math.random() * 3000, t + i * 0.03, 0.2, 0.05); noise(t, 0.2, 0.3, 'highpass', 4000); },
    zap() { const t = now(); osc('square', 1600, t, 0.25, 0.12, 200); noise(t, 0.2, 0.2, 'bandpass', 3000, 800, 4); },
    beam() { const t = now(); osc('sawtooth', 90, t, 1.2, 0.25, 110); osc('square', 181, t, 1.2, 0.08, 220); noise(t, 1.2, 0.3, 'bandpass', 1500, 4000, 2); },
    wet() { const t = now(); noise(t, 0.25, 0.5, 'lowpass', 900, 150, 4); osc('sine', 300, t, 0.15, 0.2, 90); },
    coin() { const t = now(); osc('sine', 1320, t, 0.12, 0.08); osc('sine', 1980, t + 0.05, 0.18, 0.06); },
    heal() { const t = now(); [523, 659, 784].forEach((f, i) => osc('sine', f, t + i * 0.06, 0.3, 0.08)); },
    ui() { const t = now(); osc('triangle', 180, t, 0.08, 0.12, 120); noise(t, 0.05, 0.1, 'bandpass', 2000); },
    uiBig() { const t = now(); osc('sine', 60, t, 0.6, 0.5, 30); noise(t, 0.5, 0.3, 'lowpass', 500, 60); osc('sawtooth', 110, t, 0.5, 0.05, 55); },
    buy() { const t = now(); [392, 523, 784, 1046].forEach((f, i) => osc('triangle', f, t + i * 0.07, 0.25, 0.1)); },
    deny() { const t = now(); osc('square', 140, t, 0.15, 0.1); osc('square', 100, t + 0.12, 0.2, 0.1); },
    blink() { const t = now(); noise(t, 0.09, 0.25, 'lowpass', 700, 200, 6); },
    eyeSquelch() { const t = now(); noise(t, 0.4, 0.4, 'lowpass', 500, 120, 8); osc('sine', 70, t, 0.4, 0.2, 40); },
    heartbeat(v = 1) { const t = now(); osc('sine', 55, t, 0.15, 0.6 * v, 40); osc('sine', 50, t + 0.22, 0.18, 0.45 * v, 35); },
    whisper(dur = 1.4) { const t = now(); for (let i = 0; i < 5; i++) { const st = t + i * dur / 6; noise(st, dur / 4, 0.12, 'bandpass', 1500 + Math.random() * 2500, 800 + Math.random() * 3000, 9); } },
    message() { const t = now(); osc('sine', 40, t, 1.2, 0.35, 32); noise(t, 0.8, 0.18, 'bandpass', 3000, 900, 12); S.whisper(1.0); },
    jumpscare() { const t = now(); for (let i = 0; i < 6; i++) osc(i % 2 ? 'sawtooth' : 'square', 300 + i * 147 + Math.random() * 60, t, 1.4, 0.16, 120 + i * 50); noise(t, 1.5, 1.0, 'bandpass', 2500, 700, 0.8); osc('sine', 45, t, 1.6, 0.9, 25); },
    glitch(dur = 0.5) { const t = now(); for (let i = 0; i < dur * 30; i++) { const st = t + i / 30; osc('square', 80 + Math.random() * 2000, st, 0.03, 0.12); } noise(t, dur, 0.4, 'highpass', 1000); },
    crashTone() { const t = now(); osc('square', 440, t, 2.0, 0.1, 438); osc('square', 443, t, 2.0, 0.1, 441); },
    portal() { const t = now(); osc('sine', 200, t, 1.5, 0.3, 1200); noise(t, 1.5, 0.3, 'bandpass', 400, 4000, 3); },
    bossDie() { const t = now(); S.roar(); osc('sawtooth', 200, t + 0.3, 2.5, 0.2, 30); noise(t + 0.3, 2.5, 0.6, 'lowpass', 2000, 60); },
    victory() { const t = now(); [261, 311, 392, 466, 523].forEach((f, i) => osc('triangle', f, t + i * 0.18, 1.2, 0.1)); },
    death() { const t = now(); osc('sawtooth', 220, t, 2.2, 0.2, 40); osc('sine', 55, t, 3, 0.5, 30); noise(t, 2, 0.3, 'lowpass', 800, 60); },
    // ---- NIGHTMARE EVOLUTION: new sounds ----
    impactSword(p = 1) { const t = now(); noise(t, 0.09, 0.7, 'highpass', 2200 * p, 900, 1.2); noise(t, 0.14, 0.6, 'lowpass', 1600, 220, 2); osc('triangle', 2900 * p, t, 0.18, 0.05, 2500); osc('sine', 150, t, 0.12, 0.4, 55); },
    impactDual(p = 1) { const t = now(); noise(t, 0.05, 0.6, 'bandpass', 3200 * p, 1500, 2); noise(t + 0.035, 0.05, 0.45, 'bandpass', 2700 * p, 1300, 2); osc('sine', 190, t, 0.08, 0.3, 80); },
    impactHammer(p = 1) { const t = now(); osc('sine', 85 * p, t, 0.5, 0.9, 26); osc('triangle', 160 * p, t, 0.18, 0.4, 50); noise(t, 0.3, 0.8, 'lowpass', 700, 60, 1); for (let i = 0; i < 3; i++) noise(t + 0.02 + i * 0.03, 0.05, 0.35, 'bandpass', 900 + Math.random() * 900, null, 3); },
    impactScythe(p = 1) { const t = now(); noise(t, 0.22, 0.55, 'bandpass', 1300 * p, 400, 1.5); noise(t + 0.02, 0.2, 0.5, 'lowpass', 1100, 150, 5); osc('sawtooth', 220 * p, t, 0.2, 0.06, 90); },
    impactSpear(p = 1) { const t = now(); noise(t, 0.08, 0.6, 'bandpass', 900, 4200, 3); osc('sine', 240 * p, t, 0.1, 0.4, 70); noise(t + 0.05, 0.12, 0.45, 'lowpass', 900, 150, 3); },
    scream2(p = 1) { const t = now(); const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(210 * p, t); o.frequency.linearRampToValueAtTime(330 * p, t + 0.15); o.frequency.exponentialRampToValueAtTime(90 * p, t + 0.9);
      const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 700 * p; f.Q.value = 4; const g = ctx.createGain(); env(g, t, 0.03, 0.26, 0.9); const am = ctx.createOscillator(), ag = ctx.createGain(); am.frequency.value = 31; ag.gain.value = 0.4; am.connect(ag); ag.connect(g.gain);
      o.connect(f); f.connect(g); g.connect(curBus || sfxBus); o.start(t); am.start(t); o.stop(t + 1); am.stop(t + 1); noise(t, 0.6, 0.15, 'bandpass', 1400, 600, 6); },
    shriek(p = 1) { const t = now(); [1, 1.06, 1.5].forEach((m, i) => osc('sawtooth', 1100 * p * m, t, 0.55, 0.05, 520 * p * m)); noise(t, 0.4, 0.25, 'highpass', 4000); },
    bossStep(w = 1) { const t = now(); osc('sine', 52, t, 0.45 * w + 0.2, 0.7 * w, 24); noise(t, 0.3, 0.45 * w, 'lowpass', 300, 40, 1); noise(t + 0.02, 0.08, 0.2 * w, 'bandpass', 900, null, 2); },
    charge(lvl = 0) { const t = now(); osc('sawtooth', 110 + lvl * 70, t, 0.35, 0.06, 220 + lvl * 120); noise(t, 0.35, 0.12, 'bandpass', 600 + lvl * 500, 2400 + lvl * 800, 6); },
    chargeReady(lvl = 1) { const t = now(); [880, 1320, 1760].slice(0, lvl + 1).forEach((f, i) => osc('sine', f, t + i * 0.04, 0.5, 0.07)); noise(t, 0.12, 0.2, 'highpass', 6000); },
    dodge() { const t = now(); noise(t, 0.22, 0.4, 'bandpass', 500, 2600, 1.2); noise(t + 0.05, 0.12, 0.12, 'lowpass', 400, 120); },
    perfect() { const t = now(); noise(t, 0.5, 0.35, 'highpass', 9000, 1500, 0.8); [1046, 1567, 2093].forEach((f, i) => osc('sine', f, t + 0.05, 1.4, 0.06)); osc('sine', 65, t, 0.8, 0.35, 40); },
    execute() { const t = now(); osc('sine', 48, t, 1.4, 0.9, 25); noise(t, 0.9, 0.7, 'lowpass', 1200, 50, 1); [311, 466, 622].forEach((f, i) => osc('triangle', f, t + 0.02, 1.6, 0.07, f * 0.98)); noise(t, 0.06, 0.8, 'highpass', 3000); },
    block() { const t = now(); [380, 760, 1190].forEach((f, i) => osc('square', f, t, 0.18 + i * 0.05, 0.07)); noise(t, 0.08, 0.6, 'bandpass', 2400, null, 2); osc('sine', 120, t, 0.12, 0.3, 60); },
    guardBreak() { const t = now(); S.block(); for (let i = 0; i < 5; i++) noise(t + 0.05 + i * 0.03, 0.06, 0.5, 'bandpass', 1500 + Math.random() * 2500, null, 4); osc('sine', 90, t + 0.05, 0.4, 0.6, 30); },
    stinger() { const t = now(); [55, 58.3, 82.4, 116.5, 123.5].forEach((f, i) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = i % 2 ? 'sawtooth' : 'triangle'; o.frequency.value = f * 2; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.09, t + 0.6); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.6); o.connect(g); g.connect(curBus || sfxBus); o.start(t); o.stop(t + 2.7); }); osc('sine', 40, t, 2.4, 0.6, 30); },
    riser(dur = 1.6) { const t = now(); osc('sawtooth', 80, t, dur, 0.1, 900); noise(t, dur, 0.35, 'bandpass', 300, 6000, 3); },
    phaseShift() { const t = now(); S.riser(1.2); setTimeout(() => { if (ctx) { S.boom(1.4); S.stinger(); } }, 1150); },
    knock() { const t = now(); [0, 0.32, 0.6].forEach(d => { osc('sine', 140, t + d, 0.12, 0.5, 70); noise(t + d, 0.06, 0.4, 'lowpass', 900, 200, 2); }); },
    scrape() { const t = now(); osc('sawtooth', 160, t, 1.6, 0.04, 140); noise(t, 1.6, 0.18, 'bandpass', 2600, 1700, 9); },
    distantScream() { const t = now(); const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(700, t); o.frequency.linearRampToValueAtTime(1050, t + 0.4); o.frequency.exponentialRampToValueAtTime(380, t + 1.8); const g = ctx.createGain(); env(g, t, 0.2, 0.06, 1.8); const v = ctx.createOscillator(), vg = ctx.createGain(); v.frequency.value = 6; vg.gain.value = 18; v.connect(vg); vg.connect(o.frequency); o.connect(g); g.connect(curBus || sfxBus); o.start(t); v.start(t); o.stop(t + 2); v.stop(t + 2); },
    footBehind(n = 4) { const t = now(); for (let i = 0; i < n; i++) { noise(t + i * 0.42, 0.08, 0.28, 'lowpass', 380 + Math.random() * 120, 90); osc('sine', 60, t + i * 0.42, 0.08, 0.15, 40); } },
    creak() { const t = now(); osc('sawtooth', 70, t, 1.1, 0.06, 95); noise(t, 1.1, 0.12, 'bandpass', 900, 600, 14); },
    drip() { const t = now(); osc('sine', 1400 + Math.random() * 500, t, 0.12, 0.08, 500); },
    bell() { const t = now(); [196, 392.5, 589, 784, 1013].forEach((f, i) => osc('sine', f, t, 3.4 - i * 0.4, 0.06 / (i + 1) * 2)); },
    hum() { const t = now(); const notes = [392, 349, 330, 294, 330]; notes.forEach((f, i) => { osc('sine', f, t + i * 0.55, 0.6, 0.025); osc('sine', f * 1.007, t + i * 0.55, 0.6, 0.02); }); },
    staticBurst(dur = 0.25) { const t = now(); noise(t, dur, 0.35, 'highpass', 1800); osc('square', 60, t, dur, 0.05); },
    collapse() { const t = now(); osc('sine', 45, t, 1.8, 0.8, 22); noise(t, 1.6, 0.7, 'lowpass', 600, 40, 0.8); for (let i = 0; i < 8; i++) noise(t + 0.1 + i * 0.12, 0.08, 0.35, 'bandpass', 600 + Math.random() * 1400, null, 3); },
    crack() { const t = now(); noise(t, 0.12, 0.6, 'bandpass', 1800, 700, 4); osc('square', 90, t, 0.08, 0.15, 50); },
    shatter() { const t = now(); for (let i = 0; i < 9; i++) osc('sine', 1800 + Math.random() * 4500, t + i * 0.02, 0.3, 0.05); noise(t, 0.4, 0.5, 'highpass', 3000, 8000); osc('sine', 70, t, 0.4, 0.5, 30); },
    wings() { const t = now(); for (let i = 0; i < 4; i++) noise(t + i * 0.14, 0.12, 0.3, 'lowpass', 900, 200, 1); },
    splash() { const t = now(); noise(t, 0.6, 0.6, 'lowpass', 3000, 300, 0.8); noise(t + 0.1, 0.4, 0.3, 'bandpass', 1500, 600, 2); },
    gore() { const t = now(); for (let i = 0; i < 4; i++) noise(t + i * 0.05, 0.15, 0.6, 'lowpass', 900, 120, 6); osc('sine', 70, t, 0.4, 0.6, 30); },
    holy() { const t = now(); [523, 659, 784, 1046].forEach((f, i) => osc('sine', f, t + i * 0.05, 2, 0.05)); noise(t, 1.2, 0.15, 'highpass', 6000, 3000); },
    laughLow() { const t = now(); for (let i = 0; i < 5; i++) { osc('sawtooth', 110 - i * 4, t + i * 0.16, 0.1, 0.08, 90); noise(t + i * 0.16, 0.1, 0.12, 'bandpass', 700, null, 6); } },
    victoryBig() { const t = now(); [130.8, 155.6, 196, 261.6, 311.1, 392].forEach((f, i) => osc('triangle', f, t + i * 0.12, 2.4 - i * 0.2, 0.09)); osc('sine', 65, t, 2.5, 0.4, 60); },
    bark(p = 1) { const t = now(); [0, 0.15].forEach(d => { osc('sawtooth', 460 * p, t + d, 0.09, 0.22, 230 * p); osc('square', 230 * p, t + d, 0.07, 0.08, 150 * p); noise(t + d, 0.08, 0.22, 'bandpass', 1100, 600, 3); }); },
    whimper(p = 1) { const t = now(); osc('sine', 950 * p, t, 0.55, 0.13, 560 * p); osc('triangle', 1300 * p, t + 0.12, 0.45, 0.05, 700 * p); },
    relic() { const t = now(); [784, 988, 1175, 1568, 1976].forEach((f, i) => osc('sine', f, t + i * 0.09, 1.4, 0.07)); },
  };
  A.play = (name, ...args) => { if (!ctx || !S[name]) return; try { S[name](...args); } catch (e) {} };
  // positional play: pan -1..1, vol 0..1 (distance attenuation)
  A.playAt = (pan, vol, name, ...args) => {
    if (!ctx || !S[name]) return;
    try {
      const g = ctx.createGain(); g.gain.value = clamp(vol, 0, 1.4);
      if (ctx.createStereoPanner) { const pn = ctx.createStereoPanner(); pn.pan.value = clamp(pan, -1, 1); g.connect(pn); pn.connect(sfxBus); } else g.connect(sfxBus);
      curBus = g; S[name](...args);
    } catch (e) {} finally { curBus = null; }
  };
  A.setIntensity = (v) => { intensity = v; };
  A.intensity = () => intensity;
  // stage ambience: rumble + texture
  A.ambience = (kind) => {
    if (!ctx) return; A.stopAmbience(); if (!kind) return; const t = now();
    const bus = ctx.createGain(); bus.gain.setValueAtTime(0.0001, t); bus.gain.exponentialRampToValueAtTime(1, t + 3); bus.connect(musicBus); ambNodes.push(bus);
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 33; const og = ctx.createGain(); og.gain.value = 0.1; const lf = ctx.createOscillator(), lg = ctx.createGain(); lf.frequency.value = 0.07; lg.gain.value = 0.08; lf.connect(lg); lg.connect(og.gain); o.connect(og); og.connect(bus); o.start(t); lf.start(t); ambNodes.push(o, lf);
    const tex = { fire: ['lowpass', 900, 0.08], water: ['lowpass', 500, 0.12], wind: ['bandpass', 1200, 0.05], void: ['bandpass', 3000, 0.03], flesh: ['lowpass', 260, 0.14], ice: ['highpass', 5000, 0.025] }[kind];
    if (tex) { const ns = ctx.createBufferSource(); ns.buffer = noiseBuf; ns.loop = true; const f = ctx.createBiquadFilter(); f.type = tex[0]; f.frequency.value = tex[1]; const g = ctx.createGain(); g.gain.value = tex[2]; const l2 = ctx.createOscillator(), l2g = ctx.createGain(); l2.frequency.value = 0.11; l2g.gain.value = tex[2] * 0.6; l2.connect(l2g); l2g.connect(g.gain); ns.connect(f); f.connect(g); g.connect(bus); ns.start(t); l2.start(t); ambNodes.push(ns, l2); }
  };
  A.stopAmbience = () => { if (!ctx) return; ambNodes.forEach(n => { try { if (n.gain) n.gain.setTargetAtTime(0.0001, now(), 0.5); else n.stop(now() + 2); } catch (e) {} }); ambNodes = []; };
  // dramatic transition: silence, stinger, then the new music
  A.transition = (cfg, gapMs = 900) => { if (!ctx) { A._pending = cfg; return; } stopMusic(); curMusic = null; S.stinger(); setTimeout(() => A.music(cfg), gapMs); };

  // ===== MUSIC: generative dark ambience per stage =====
  const SCALES = { minor: [0, 2, 3, 5, 7, 8, 10], phryg: [0, 1, 3, 5, 7, 8, 10], dim: [0, 2, 3, 5, 6, 8, 9, 11], hung: [0, 2, 3, 6, 7, 8, 11], loc: [0, 1, 3, 5, 6, 8, 10] };
  function stopMusic() {
    if (musicTimer) clearInterval(musicTimer); musicTimer = null;
    musicNodes.forEach(n => { try { if (n.gain) n.gain.setTargetAtTime(0.0001, now(), 0.4); else n.stop(now() + 1.5); } catch (e) {} });
    musicNodes = [];
  }
  A.stopMusic = () => { curMusic = null; if (ctx) stopMusic(); };
  A.music = (cfg) => {
    if (!ctx) { A._pending = cfg; return; }
    const key = JSON.stringify(cfg); if (curMusic === key) return; curMusic = key; stopMusic();
    const t = now(); const root = cfg.root || 55; const scale = SCALES[cfg.scale || 'minor'];
    const bus = ctx.createGain(); bus.gain.setValueAtTime(0.0001, t); bus.gain.exponentialRampToValueAtTime(1, t + 2); bus.connect(musicBus); musicNodes.push(bus);
    // drone pair
    [1, 1.5, 2.003].forEach((m, i) => {
      const o = ctx.createOscillator(); o.type = i === 0 ? (cfg.wave || 'sawtooth') : 'sine'; o.frequency.value = root * m;
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = cfg.bright || 420; f.Q.value = 4;
      const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 0.05 + i * 0.03; lg.gain.value = 180; lfo.connect(lg); lg.connect(f.frequency);
      const g = ctx.createGain(); g.gain.value = i === 0 ? 0.12 : 0.06; o.connect(f); f.connect(g); g.connect(bus); o.start(t); lfo.start(t); musicNodes.push(o, lfo);
    });
    // wind
    const ns = ctx.createBufferSource(); ns.buffer = noiseBuf; ns.loop = true; const nf = ctx.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = 500; nf.Q.value = 0.7;
    const nl = ctx.createOscillator(), nlg = ctx.createGain(); nl.frequency.value = 0.08; nlg.gain.value = 300; nl.connect(nlg); nlg.connect(nf.frequency);
    const ng = ctx.createGain(); ng.gain.value = cfg.wind ?? 0.05; ns.connect(nf); nf.connect(ng); ng.connect(bus); ns.start(t); nl.start(t); musicNodes.push(ns, nl);
    // sequencer
    const bpm = cfg.tempo || 90; const stepDur = 60 / bpm / 2; let step = 0;
    const pat = cfg.pattern || [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0];
    musicTimer = setInterval(() => {
      if (!ctx || ctx.state !== 'running') return; const st = now() + 0.05; const s = step++ % 16;
      if (cfg.drums !== false && pat[s]) { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(cfg.kick || 70, st); o.frequency.exponentialRampToValueAtTime(30, st + 0.25); env(g, st, 0.003, 0.5, 0.3); o.connect(g); g.connect(bus); o.start(st); o.stop(st + 0.4); }
      if (cfg.drums !== false && s % 8 === 4) noise(st, 0.18, 0.12, 'highpass', 2500, null, 1, bus);
      if (cfg.ticks && s % 2 === 1) noise(st, 0.03, 0.05, 'highpass', 7000, null, 1, bus);
      if (Math.random() < (cfg.notes ?? 0.28)) {
        const deg = scale[Math.floor(Math.random() * scale.length)]; const oct = Math.random() < 0.3 ? 4 : 2;
        const f = root * oct * Math.pow(2, deg / 12); const o = ctx.createOscillator(); o.type = cfg.lead || 'triangle'; o.frequency.value = f;
        const g = ctx.createGain(); env(g, st, 0.02, 0.07, stepDur * 6); const dl = ctx.createDelay(2); dl.delayTime.value = Math.min(stepDur * 3, 1.9); const fb = ctx.createGain(); fb.gain.value = 0.35;
        o.connect(g); g.connect(bus); g.connect(dl); dl.connect(fb); fb.connect(dl); fb.connect(bus); o.start(st); o.stop(st + stepDur * 7);
      }
      if (intensity >= 1 && s % 2 === 0) noise(st, 0.025, 0.035 * intensity, 'highpass', 8000, null, 1, bus);
      if (intensity >= 2 && (s === 3 || s === 11)) { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime((cfg.kick || 70) * 0.9, st); o.frequency.exponentialRampToValueAtTime(30, st + 0.2); env(g, st, 0.003, 0.35, 0.22); o.connect(g); g.connect(bus); o.start(st); o.stop(st + 0.3); }
      if (intensity >= 3 && s % 4 === 0) { const o = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain(); o.type = 'sawtooth'; o.frequency.value = root * (s % 8 === 0 ? 1 : 1.0595); f.type = 'lowpass'; f.frequency.value = 380; env(g, st, 0.01, 0.12, stepDur * 3); o.connect(f); f.connect(g); g.connect(bus); o.start(st); o.stop(st + stepDur * 3.5); }
      if (cfg.whispers && Math.random() < 0.03) S.whisper(1.2);
      if (cfg.heart && s % 8 === 0) S.heartbeat(0.5);
    }, stepDur * 1000);
  };
  // freeze/stutter effect for fake crash
  A.stutter = (dur = 1.2) => {
    if (!ctx) return; stopMusic(); curMusic = null; const t = now(); const n = Math.floor(dur * 14);
    for (let i = 0; i < n; i++) { const st = t + i * dur / n; osc('sawtooth', 110, st, 0.04, 0.2, 108); noise(st, 0.03, 0.3, 'bandpass', 900, null, 2); }
  };
  A.duck = (v) => { if (master) master.gain.setTargetAtTime(v, now(), 0.02); };
  A.suspend = () => { try { ctx && ctx.suspend(); } catch (e) {} };
  A.resume = () => { try { ctx && ctx.resume(); } catch (e) {} };
  return A;
})();
