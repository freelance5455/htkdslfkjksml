// ===== ART: procedural character rendering (skeletal, frame-by-frame poses) =====
const D2R = Math.PI / 180;
const vA = (a, len) => [Math.sin(a * D2R) * len, Math.cos(a * D2R) * len]; // 0 = down, + = forward
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const rnd = (a, b) => a + Math.random() * (b - a);
const ease = t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
const easeOut = t => 1 - (1 - t) * (1 - t);
function shade(hex, amt) { // amt -1..1
  let c = hex.replace('#', ''); if (c.length === 3) c = c.split('').map(x => x + x).join('');
  let r = parseInt(c.substr(0, 2), 16), g = parseInt(c.substr(2, 2), 16), b = parseInt(c.substr(4, 2), 16);
  if (amt > 0) { r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt; } else { r *= 1 + amt; g *= 1 + amt; b *= 1 + amt; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}
function rgba(hex, a) { let c = hex.replace('#', ''); if (c.length === 3) c = c.split('').map(x => x + x).join(''); return `rgba(${parseInt(c.substr(0, 2), 16)},${parseInt(c.substr(2, 2), 16)},${parseInt(c.substr(4, 2), 16)},${a})`; }

const POSE_KEYS = ['t', 'h', 'a1u', 'a1f', 'a2u', 'a2f', 'l1t', 'l1s', 'l2t', 'l2s', 'w', 'w2', 'bY'];
const BASE_POSE = { t: 3, h: 0, a1u: 8, a1f: 18, a2u: -10, a2f: 2, l1t: 6, l1s: -2, l2t: -8, l2s: -4, w: 135, w2: 140, bY: 0 };
function P(o) { return Object.assign({}, BASE_POSE, o); }
function lerpPose(a, b, t) { const o = {}; for (const k of POSE_KEYS) o[k] = lerp(a[k] ?? BASE_POSE[k], b[k] ?? BASE_POSE[k], t); return o; }

// limb stroke with outline
function limb(c, x1, y1, x2, y2, w, col, out = '#07050a') {
  c.lineCap = 'round'; c.strokeStyle = out; c.lineWidth = w + 3; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
  c.strokeStyle = col; c.lineWidth = w; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
}
function circ(c, x, y, r, fill, stroke, lw = 2) { c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); if (fill) { c.fillStyle = fill; c.fill(); } if (stroke) { c.strokeStyle = stroke; c.lineWidth = lw; c.stroke(); } }
function poly(c, pts, fill, stroke, lw = 2) { c.beginPath(); c.moveTo(pts[0], pts[1]); for (let i = 2; i < pts.length; i += 2) c.lineTo(pts[i], pts[i + 1]); c.closePath(); if (fill) { c.fillStyle = fill; c.fill(); } if (stroke) { c.strokeStyle = stroke; c.lineWidth = lw; c.lineJoin = 'round'; c.stroke(); } }

// ---------- skeleton solve ----------
const SK = { thigh: 24, shin: 24, torso: 36, ua: 19, fa: 18, head: 10 };
function solveSkeleton(pose, grounded) {
  const d1 = SK.thigh * Math.cos(pose.l1t * D2R) + SK.shin * Math.cos(pose.l1s * D2R);
  const d2 = SK.thigh * Math.cos(pose.l2t * D2R) + SK.shin * Math.cos(pose.l2s * D2R);
  const hipY = grounded ? -Math.max(d1, d2) + Math.max(0, pose.bY) * 0.3 : -46 + pose.bY;
  const hip = [0, hipY];
  const tt = pose.t * D2R;
  const sh = [hip[0] + Math.sin(tt) * SK.torso, hip[1] - Math.cos(tt) * SK.torso];
  const neck = [sh[0] + Math.sin(tt) * 6, sh[1] - Math.cos(tt) * 6];
  const head = [neck[0] + Math.sin(tt + pose.h * D2R * 0.5) * 9, neck[1] - Math.cos(tt + pose.h * D2R * 0.5) * 9];
  const arm = (u, f) => { const e = vA(u, SK.ua), h = vA(f, SK.fa); const el = [sh[0] + e[0], sh[1] + e[1]]; return { el, hand: [el[0] + h[0], el[1] + h[1]] }; };
  const leg = (t, s) => { const k = vA(t, SK.thigh), sv = vA(s, SK.shin); const kn = [hip[0] + k[0], hip[1] + k[1]]; return { kn, ft: [kn[0] + sv[0], kn[1] + sv[1]] }; };
  return { hip, sh, neck, head, A1: arm(pose.a1u, pose.a1f), A2: arm(pose.a2u, pose.a2f), L1: leg(pose.l1t, pose.l1s), L2: leg(pose.l2t, pose.l2s), tt };
}
function rotOff(sk, ox, oy) { const c = Math.cos(sk.tt), s = Math.sin(sk.tt); return [sk.sh[0] + ox * c - oy * s, sk.sh[1] + ox * s + oy * c]; }

// ---------- weapons ----------
// draws weapon with grip at (0,0), blade along +y
function drawWeaponShape(c, id, tint, glowT = 0) {
  const W = WEAPONS.find(w => w.id === id);
  const steel = tint || W.color;
  c.lineJoin = 'round';
  if (id === 'executioner') {
    // handle & pommel
    limb(c, 0, -20, 0, 2, 5, '#3a2416');
    for (let i = -18; i < 0; i += 4) { c.strokeStyle = '#1a0f08'; c.lineWidth = 1; c.beginPath(); c.moveTo(-3, i); c.lineTo(3, i + 2); c.stroke(); }
    circ(c, 0, -22, 4.5, '#8a7a5a', '#07050a', 2);
    poly(c, [-15, 1, 15, 1, 12, 6, -12, 6], '#6a5a3a', '#07050a', 2);
    const g = c.createLinearGradient(-8, 0, 8, 0); g.addColorStop(0, shade(steel, -0.55)); g.addColorStop(0.45, steel); g.addColorStop(0.55, shade(steel, 0.5)); g.addColorStop(1, shade(steel, -0.35));
    poly(c, [-8, 6, 8, 6, 9, 88, 4, 94, -9, 94, -9, 88], g, '#07050a', 2.2);
    c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, 10); c.lineTo(0, 70); c.stroke();
    circ(c, 1, 82, 3.5, '#07050a'); // executioner hole
    c.fillStyle = 'rgba(110,0,10,0.55)'; c.beginPath(); c.ellipse(5, 60, 3, 9, 0.2, 0, 7); c.fill(); c.beginPath(); c.ellipse(-5, 80, 3, 6, -0.2, 0, 7); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.65)'; c.lineWidth = 1; c.beginPath(); c.moveTo(7.5, 10); c.lineTo(8.4, 86); c.stroke();
  } else if (id === 'bloodfang') {
    limb(c, 0, -10, 0, 2, 4.5, '#2a0a0a');
    poly(c, [-7, 1, 7, 1, 5, 5, -5, 5], '#5a1a1a', '#07050a', 1.5);
    const g = c.createLinearGradient(-6, 0, 6, 0); g.addColorStop(0, shade(steel, -0.5)); g.addColorStop(0.5, shade(steel, 0.25)); g.addColorStop(1, shade(steel, -0.3));
    c.beginPath(); c.moveTo(-4, 5); c.quadraticCurveTo(-7, 30, 4, 54); c.quadraticCurveTo(6, 30, 5, 5); c.closePath(); c.fillStyle = g; c.fill(); c.strokeStyle = '#07050a'; c.lineWidth = 2; c.stroke();
    c.fillStyle = '#f2e6e0'; for (let i = 0; i < 4; i++) poly(c, [5, 12 + i * 9, 9, 15 + i * 9, 5, 18 + i * 9], '#e8d8d0');
    c.strokeStyle = 'rgba(255,60,70,0.8)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-3, 8); c.quadraticCurveTo(-5, 30, 3, 50); c.stroke();
  } else if (id === 'doomhammer') {
    limb(c, 0, -26, 0, 64, 5, '#2a1a10');
    circ(c, 0, -28, 4, '#555', '#07050a');
    for (let i = -20; i < 20; i += 5) { c.strokeStyle = '#120a06'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-3, i); c.lineTo(3, i + 3); c.stroke(); }
    const g = c.createLinearGradient(-24, 0, 24, 0); g.addColorStop(0, shade(steel, -0.6)); g.addColorStop(0.5, shade(steel, 0.2)); g.addColorStop(1, shade(steel, -0.5));
    poly(c, [-24, 60, 24, 60, 27, 66, 27, 88, 24, 94, -24, 94, -27, 88, -27, 66], g, '#07050a', 2.5);
    poly(c, [27, 70, 38, 77, 27, 84], '#3a383e', '#07050a', 2); poly(c, [-27, 70, -38, 77, -27, 84], '#3a383e', '#07050a', 2);
    poly(c, [-6, 94, 0, 104, 6, 94], '#3a383e', '#07050a', 2);
    const gl = 0.6 + 0.4 * Math.sin(glowT * 4);
    c.strokeStyle = `rgba(255,140,40,${gl})`; c.lineWidth = 2; c.shadowColor = '#ff7a1a'; c.shadowBlur = 8;
    c.beginPath(); c.moveTo(-16, 70); c.lineTo(-10, 84); c.lineTo(-4, 70); c.moveTo(4, 84); c.lineTo(10, 70); c.lineTo(16, 84); c.stroke(); c.shadowBlur = 0;
  } else if (id === 'soulreaper') {
    limb(c, 0, -30, 0, 96, 4.5, '#1e1612');
    c.strokeStyle = '#4a3a2a'; c.lineWidth = 1; for (let i = -24; i < 90; i += 14) { c.beginPath(); c.moveTo(-2.5, i); c.lineTo(2.5, i + 4); c.stroke(); }
    circ(c, 0, 96, 5, '#2a2a2a', '#07050a', 2);
    const g = c.createLinearGradient(0, 90, -60, 120); g.addColorStop(0, shade(steel, -0.5)); g.addColorStop(0.6, steel); g.addColorStop(1, shade(steel, 0.6));
    c.beginPath(); c.moveTo(2, 92); c.bezierCurveTo(-30, 80, -62, 92, -74, 122); c.bezierCurveTo(-54, 104, -28, 100, -2, 102); c.closePath();
    c.fillStyle = g; c.fill(); c.strokeStyle = '#07050a'; c.lineWidth = 2.2; c.stroke();
    c.shadowColor = '#5dffc1'; c.shadowBlur = 10; c.strokeStyle = `rgba(110,255,200,${0.5 + 0.4 * Math.sin(glowT * 3)})`; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(-4, 92); c.bezierCurveTo(-32, 84, -58, 94, -72, 118); c.stroke(); c.shadowBlur = 0;
    circ(c, 0, 92, 3, '#5dffc1');
  } else if (id === 'voidspear') {
    limb(c, 0, -46, 0, 100, 4, '#1a1426');
    for (let i = -40; i < 96; i += 18) { c.strokeStyle = '#a67cff'; c.lineWidth = 1; c.beginPath(); c.moveTo(-2, i); c.lineTo(2, i + 2); c.stroke(); }
    poly(c, [-8, 100, 8, 100, 4, 106, -4, 106], '#3a2a5a', '#07050a', 1.5);
    c.shadowColor = '#8a5cff'; c.shadowBlur = 14;
    const g = c.createLinearGradient(-8, 0, 8, 0); g.addColorStop(0, '#3a1a8a'); g.addColorStop(0.5, '#e0d0ff'); g.addColorStop(1, '#5a2aba');
    poly(c, [0, 104, 9, 116, 0, 142, -9, 116], g, '#07050a', 1.5); c.shadowBlur = 0;
    c.strokeStyle = `rgba(180,140,255,${0.5 + 0.5 * Math.sin(glowT * 5)})`; c.lineWidth = 1.2;
    c.beginPath(); c.ellipse(0, 94 + Math.sin(glowT * 3) * 4, 9, 3, 0, 0, 7); c.stroke();
    if (tint) { c.globalCompositeOperation = 'source-atop'; c.globalCompositeOperation = 'source-over'; }
  }
}
function drawWeaponAt(c, id, x, y, ang, tint, t) { c.save(); c.translate(x, y); c.rotate(-ang * D2R); drawWeaponShape(c, id, tint, t); c.restore(); }
// blade tip & base offsets for trails
const WTIP = { executioner: [8, 94], bloodfang: [3, 54], doomhammer: [0, 96], soulreaper: [-70, 118], voidspear: [0, 142] };
const WBASE = { executioner: [0, 10], bloodfang: [0, 8], doomhammer: [0, 58], soulreaper: [-30, 92], voidspear: [0, 96] };
function weaponPoint(x, y, ang, off) { const a = -ang * D2R, c = Math.cos(a), s = Math.sin(a); return [x + off[0] * c - off[1] * s, y + off[0] * s + off[1] * c]; }

function drawEnemyWeapon(c, type, x, y, ang, sc = 1, col) {
  c.save(); c.translate(x, y); c.rotate(-ang * D2R); c.lineJoin = 'round';
  if (type === 'dagger') { limb(c, 0, -5, 0, 2, 3.5, '#3a2a1a'); poly(c, [-3, 2, 3, 2, 1, 22, -1, 24], '#a8a090', '#07050a', 1.5); }
  else if (type === 'spear' || type === 'trident' || type === 'holyspear') {
    limb(c, 0, -40, 0, 50, 3.5, type === 'holyspear' ? '#e8d8a0' : '#4a3020');
    if (type === 'spear') poly(c, [-4, 50, 4, 50, 0, 70], '#9a9a9a', '#07050a', 1.5);
    else if (type === 'trident') { c.strokeStyle = '#5ae8c8'; c.lineWidth = 3; c.beginPath(); c.moveTo(-9, 50); c.lineTo(9, 50); c.moveTo(0, 50); c.lineTo(0, 72); c.moveTo(-9, 50); c.lineTo(-9, 66); c.moveTo(9, 50); c.lineTo(9, 66); c.stroke(); }
    else { c.shadowColor = '#fff2b0'; c.shadowBlur = 16; poly(c, [-6, 50, 6, 50, 0, 84], '#fff6d0', '#c8a040', 1.5); c.shadowBlur = 0; }
  }
  else if (type === 'sword') { limb(c, 0, -8, 0, 2, 3.5, '#2a2020'); poly(c, [-8, 2, 8, 2, 7, 5, -7, 5], '#5a5048', '#07050a', 1.2); poly(c, [-3, 5, 3, 5, 2, 44, 0, 48, -2, 44], col || '#9a9890', '#07050a', 1.5); }
  else if (type === 'greatsword') { limb(c, 0, -16, 0, 2, 4, '#1a2420'); poly(c, [-14, 2, 14, 2, 12, 7, -12, 7], '#3a4a44', '#07050a', 2); poly(c, [-6, 7, 6, 7, 5, 90, 0, 100, -5, 90], '#7a8a86', '#07050a', 2); c.strokeStyle = 'rgba(93,255,208,0.7)'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(0, 12); c.lineTo(0, 86); c.stroke(); }
  else if (type === 'club') { c.lineCap = 'round'; c.strokeStyle = '#07050a'; c.lineWidth = 12; c.beginPath(); c.moveTo(0, -6); c.lineTo(0, 52); c.stroke(); c.strokeStyle = '#5a3a1a'; c.lineWidth = 8; c.stroke();
    c.fillStyle = '#4a2e14'; c.beginPath(); c.ellipse(0, 52, 12, 18, 0, 0, 7); c.fill(); c.strokeStyle = '#07050a'; c.lineWidth = 2.5; c.stroke();
    for (let i = 0; i < 5; i++) { const a = i * 1.25; poly(c, [Math.cos(a) * 10, 50 + Math.sin(a) * 15, Math.cos(a) * 17, 50 + Math.sin(a) * 22, Math.cos(a + 0.3) * 10, 50 + Math.sin(a + 0.3) * 15], '#c8c0b0', '#07050a', 1); } }
  else if (type === 'iceclub') { c.lineCap = 'round'; c.strokeStyle = '#07050a'; c.lineWidth = 12; c.beginPath(); c.moveTo(0, -6); c.lineTo(0, 46); c.stroke(); c.strokeStyle = '#4a6a8a'; c.lineWidth = 8; c.stroke();
    poly(c, [-14, 40, 14, 40, 20, 62, 8, 82, -8, 82, -20, 62], '#bfeaff', '#2a5a7a', 2.5); poly(c, [-4, 46, 4, 46, 0, 76], 'rgba(255,255,255,0.7)'); }
  else if (type === 'bow') { c.strokeStyle = '#5a4030'; c.lineWidth = 3; c.beginPath(); c.arc(-12, 0, 24, -1.1, 1.1); c.stroke(); c.strokeStyle = '#ddd'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(-12 + 24 * Math.cos(-1.1), 24 * Math.sin(-1.1)); c.lineTo(-12 + 24 * Math.cos(1.1), 24 * Math.sin(1.1)); c.stroke(); }
  c.restore();
}

// ---------- heads ----------
function drawHead(c, sk, st, pose, T, look) {
  const [hx, hy] = sk.head; const r = SK.head;
  c.save(); c.translate(hx, hy); c.rotate((pose.t * 0.4 + pose.h) * D2R);
  const out = '#07050a';
  const eye = (x, y, rr, col, glow = true) => { if (glow) { c.shadowColor = col; c.shadowBlur = 10; } circ(c, x, y, rr, col); c.shadowBlur = 0; };
  switch (st.head) {
    case 'human': {
      if (st.helm) {
        const g = c.createLinearGradient(-10, -10, 10, 10); g.addColorStop(0, shade(st.armor, 0.3)); g.addColorStop(1, shade(st.armor, -0.5));
        c.beginPath(); c.arc(0, 0, r + 1.5, Math.PI, 0); c.lineTo(r + 2, 8); c.lineTo(-r, 10); c.closePath(); c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
        c.fillStyle = '#100'; c.fillRect(1, -2, 11, 3); eye(8, -0.5, 1.6, st.glow || '#ff2a2a');
        poly(c, [-4, -r - 1, 2, -r - 9, 0, -r - 1], st.cloak); // crest
      } else if (st.beak) {
        circ(c, 0, 0, r, '#e8e0d0', out, 2); poly(c, [6, -2, 26, 6, 6, 7], '#d8ccb8', out, 2);
        circ(c, 4, -2, 3.5, '#1a1a1a', '#6a5a3a', 1.5); circ(c, 4, -2, 1.6, st.glow || '#ff3a1a');
        c.fillStyle = '#121212'; c.fillRect(-15, -r - 2, 26, 4); c.fillRect(-8, -r - 13, 14, 12);
      } else if (st.skullmask) {
        circ(c, 0, 0, r, '#e8dcc0', out, 2); circ(c, 4, -2, 3, '#120a06'); eye(4, -2, 1.3, st.glow || '#ff3a1a');
        c.strokeStyle = '#120a06'; c.lineWidth = 1; for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(3 + i * 2, 5); c.lineTo(3 + i * 2, 8); c.stroke(); }
        poly(c, [-6, -r, -14, -r - 10, -9, -r + 2], '#d8ccb0', out, 1.5);
      } else {
        circ(c, 0, 0, r, st.skin, out, 2);
        poly(c, [9, -2, 12.5, 2, 9, 3], st.skin); // nose
        c.fillStyle = 'rgba(0,0,0,0.25)'; c.beginPath(); c.arc(-2, 2, r - 1, 0.6, 2.6); c.fill();
        if (st.glow) eye(5, -2, 1.8, st.glow); else { circ(c, 5, -2, 2.2, '#f0e8e0'); circ(c, 5.8, -2, 1.2, '#1a0a08'); }
        c.strokeStyle = '#3a1a10'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(2, -5.5); c.lineTo(8, -4.5); c.stroke();
        c.beginPath(); c.moveTo(4, 5.5); c.lineTo(8, 5); c.stroke();
        c.strokeStyle = 'rgba(120,20,20,0.8)'; c.lineWidth = 1; c.beginPath(); c.moveTo(1, -3); c.lineTo(4, 3); c.stroke(); // scar
        if (st.hood) {
          c.beginPath(); c.moveTo(7, -9); c.quadraticCurveTo(2, -17, -8, -13); c.quadraticCurveTo(-17, -6, -14, 8); c.quadraticCurveTo(-8, 13, -2, 12); c.quadraticCurveTo(-6, 2, -3, -6); c.quadraticCurveTo(2, -10, 7, -9); c.closePath();
          c.fillStyle = st.cloak; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
          c.fillStyle = 'rgba(0,0,0,0.35)'; c.beginPath(); c.moveTo(7, -9); c.quadraticCurveTo(2, -12, -3, -6); c.quadraticCurveTo(0, -9, 7, -9); c.fill();
        }
      }
      if (st.eyesGlow) eye(5.5, -2, 1.8, '#ff2a2a');
      break;
    }
    case 'goblin': {
      poly(c, [-6, -4, -24, -14, -8, 4], st.skin, out, 2); poly(c, [-8, -3, -19, -10, -9, 1], st.skin2);
      c.beginPath(); c.ellipse(1, 0, r + 1, r, 0, 0, 7); c.fillStyle = st.skin; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
      c.beginPath(); c.moveTo(8, -3); c.quadraticCurveTo(19, 2, 11, 6); c.closePath(); c.fillStyle = st.skin2; c.fill(); c.stroke();
      eye(5, -4, 2.2, st.eye); c.fillStyle = '#000'; c.fillRect(4.6, -6, 0.8, 4);
      c.strokeStyle = out; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -8); c.lineTo(9, -5); c.stroke();
      c.fillStyle = '#1a0806'; c.beginPath(); c.moveTo(-1, 5); c.quadraticCurveTo(5, 10, 11, 6); c.lineTo(10, 8); c.quadraticCurveTo(4, 12, -1, 7); c.fill();
      c.fillStyle = '#e8e0b0'; for (let i = 0; i < 4; i++) poly(c, [1 + i * 2.4, 6.2 + i * 0.2, 2.2 + i * 2.4, 8.5, 3.2 + i * 2.4, 6.4 + i * 0.2], '#e8e0b0');
      circ(c, -3, -5, 1.2, st.skin2); circ(c, 1, 4, 0.9, st.skin2);
      if (st.helmet) { c.beginPath(); c.arc(0, -2, r + 1, Math.PI * 1.05, Math.PI * 1.95); c.closePath(); c.fillStyle = '#5a5048'; c.fill(); c.strokeStyle = out; c.stroke(); poly(c, [0, -r - 3, 2, -r - 12, 4, -r - 3], '#8a8070', out, 1); }
      if (st.crown) { poly(c, [-9, -8, -10, -20, -5, -13, 0, -22, 5, -13, 10, -20, 9, -8], '#e8b83a', out, 2); circ(c, 0, -14, 2, '#c0102a'); }
      break;
    }
    case 'skull': {
      circ(c, 0, -1, r, st.skin, out, 2);
      c.fillStyle = st.skin; c.fillRect(-2, 4, 12, 7); c.strokeStyle = out; c.lineWidth = 2; c.strokeRect(-2, 4, 12, 7);
      circ(c, 4.5, -2, 3.6, '#0a0806'); eye(5, -2, 1.3, st.eye);
      poly(c, [9, 1, 11, 4, 8, 4], '#0a0806');
      c.strokeStyle = '#3a3428'; c.lineWidth = 1; for (let i = 0; i < 5; i++) { c.beginPath(); c.moveTo(i * 2.2, 6); c.lineTo(i * 2.2, 10); c.stroke(); }
      c.beginPath(); c.moveTo(-6, -8); c.lineTo(-3, -4); c.lineTo(-5, -1); c.stroke();
      break;
    }
    case 'demon': {
      c.beginPath(); c.moveTo(-3, -7); c.quadraticCurveTo(-18, -18, -12, -30); c.quadraticCurveTo(-12, -18, 2, -10); c.closePath(); c.fillStyle = '#2a1a14'; c.fill(); c.strokeStyle = out; c.lineWidth = 1.5; c.stroke();
      circ(c, 0, 0, r, st.skin, out, 2);
      poly(c, [3, -5, 12, -7, 10, -3], st.skin2);
      eye(6, -3, 2.2, st.eye);
      c.fillStyle = '#100'; c.beginPath(); c.moveTo(1, 4); c.lineTo(12, 3); c.lineTo(9, 8); c.lineTo(2, 7); c.fill();
      poly(c, [4, 4, 5, 7.5, 6, 4], '#fff'); poly(c, [8, 3.7, 9, 7, 10, 3.6], '#fff');
      c.beginPath(); c.moveTo(4, -7); c.quadraticCurveTo(8, -20, 18, -24); c.quadraticCurveTo(10, -16, 8, -6); c.closePath(); c.fillStyle = '#d8c8a8'; c.fill(); c.strokeStyle = out; c.lineWidth = 1.5; c.stroke();
      break;
    }
    case 'fish': {
      poly(c, [-8, -8, -4, -20, 4, -10, 8, -18, 10, -8], st.skin2, out, 1.5);
      c.beginPath(); c.ellipse(2, 0, r + 3, r - 1, 0.1, 0, 7); c.fillStyle = st.skin; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
      circ(c, 6, -3, 4.2, '#d8e8a0', out, 1.5); circ(c, 7, -3, 2, '#000'); circ(c, 6, -4.2, 0.8, '#fff');
      c.fillStyle = '#100'; c.beginPath(); c.moveTo(4, 5); c.lineTo(15, 3); c.lineTo(13, 8); c.closePath(); c.fill();
      for (let i = 0; i < 4; i++) poly(c, [6 + i * 2.2, 4.5, 7 + i * 2.2, 7, 8 + i * 2.2, 4.3], '#eee');
      c.strokeStyle = st.skin2; c.lineWidth = 1.2; for (let i = 0; i < 3; i++) { c.beginPath(); c.arc(-4 - i * 2.5, 2, 4, -0.8, 0.8); c.stroke(); }
      break;
    }
    case 'ice': {
      poly(c, [-10, 8, -12, -6, -4, -14, 6, -16, 12, -6, 12, 6, 4, 10], st.skin, '#1a3a5a', 2);
      poly(c, [-4, -14, 0, -24, 6, -16], '#e0f6ff', '#1a3a5a', 1.5); poly(c, [6, -16, 12, -22, 12, -6], '#c0e8ff', '#1a3a5a', 1.5);
      poly(c, [-10, 8, -12, -6, -4, 0], 'rgba(30,70,120,0.4)');
      c.fillStyle = '#0a1a2a'; c.fillRect(2, -5, 10, 3); eye(8, -3.5, 1.8, st.eye);
      break;
    }
    case 'helm': {
      const g = c.createLinearGradient(-10, -12, 10, 12); g.addColorStop(0, shade(st.skin, 0.4)); g.addColorStop(1, shade(st.skin, -0.6));
      c.beginPath(); c.moveTo(-11, 10); c.lineTo(-11, -6); c.quadraticCurveTo(-10, -13, 0, -13); c.quadraticCurveTo(11, -13, 12, -4); c.lineTo(12, 10); c.closePath(); c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
      c.fillStyle = '#050305'; c.fillRect(1, -4, 11, 3); c.fillRect(6, -4, 2.5, 10);
      eye(9, -2.5, 1.6, st.eye);
      for (let i = 0; i < 3; i++) circ(c, -6 + i * 4, 7, 0.9, '#888');
      if (st.cape) { c.strokeStyle = st.cape; c.lineWidth = 3; c.beginPath(); c.moveTo(-4, -13); c.quadraticCurveTo(-14, -22, -24, -14 + Math.sin(T * 6) * 3); c.stroke(); }
      break;
    }
    case 'flesh': {
      c.beginPath(); for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2, rr = r + 2 + Math.sin(i * 3 + T * 3) * 1.8; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.closePath(); c.fillStyle = st.skin; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
      c.strokeStyle = st.skin2; c.lineWidth = 1; for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(-8 + i * 3, -9); c.quadraticCurveTo(-4 + i * 3, 0, -6 + i * 4, 8); c.stroke(); }
      c.fillStyle = '#2a0006'; c.beginPath(); c.ellipse(6, 3, 6, 4 + Math.abs(Math.sin(T * 5)) * 2, 0, 0, 7); c.fill();
      for (let i = 0; i < 5; i++) { poly(c, [1 + i * 2.4, 0, 2 + i * 2.4, 3, 3 + i * 2.4, 0], '#f8f0d8'); poly(c, [1 + i * 2.4, 7, 2 + i * 2.4, 4, 3 + i * 2.4, 7], '#f8f0d8'); }
      [[3, -6], [8, -4], [-2, -8], [-6, -2]].forEach(([x, y], i) => { circ(c, x, y, 1.9, '#fff4d0', out, 0.8); circ(c, x + 0.5 * Math.sin(T * 2 + i), y, 0.9, '#000'); });
      break;
    }
    case 'shadow': {
      const jit = st.glitch && Math.random() < 0.15 ? rnd(-4, 4) : 0;
      circ(c, jit, 0, r + 1, '#050505'); c.fillStyle = '#fff'; c.shadowColor = '#fff'; c.shadowBlur = 8;
      c.beginPath(); c.ellipse(4 + jit, -2, 2.4, 4, 0, 0, 7); c.fill(); c.beginPath(); c.ellipse(9 + jit, -2, 1.6, 3.4, 0, 0, 7); c.fill(); c.shadowBlur = 0;
      c.fillStyle = '#fff'; c.fillRect(3 + jit, 5, 8, 1);
      break;
    }
    case 'giant': {
      c.beginPath(); c.ellipse(0, 0, r + 2, r + 1, 0, 0, 7); c.fillStyle = st.skin; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
      c.fillStyle = st.skin2; c.beginPath(); c.moveTo(-6, 2); c.lineTo(12, 2); c.lineTo(10, 24); c.lineTo(4, 16); c.lineTo(0, 26); c.lineTo(-3, 14); c.lineTo(-8, 20); c.closePath(); c.fill(); c.strokeStyle = '#1a3a5a'; c.lineWidth = 1.5; c.stroke();
      for (let i = 0; i < 4; i++) poly(c, [-4 + i * 4, 18, -2 + i * 4, 30, i * 4, 18], 'rgba(220,250,255,0.9)');
      c.fillStyle = '#0a1a2a'; c.fillRect(2, -4, 10, 3); eye(8, -3, 2, st.eye);
      c.strokeStyle = '#e8f8ff'; c.lineWidth = 3; c.beginPath(); c.moveTo(0, -7); c.lineTo(12, -5); c.stroke();
      poly(c, [-8, -10, -6, -22, -2, -11, 2, -24, 5, -11, 9, -18, 10, -8], '#dff6ff', '#2a5a7a', 1.5);
      break;
    }
    case 'angel': {
      c.fillStyle = '#e8e4dc'; c.beginPath(); c.moveTo(-4, -10); c.quadraticCurveTo(-18, -4, -16 + Math.sin(T * 2) * 2, 26); c.lineTo(-6, 18); c.quadraticCurveTo(-6, 4, -2, 0); c.fill();
      circ(c, 0, 0, r, st.skin, out, 2);
      c.fillStyle = '#100'; c.beginPath(); c.ellipse(5, -2, 2.2, 1.2, 0, 0, 7); c.fill();
      c.strokeStyle = '#300'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(5, -1); c.quadraticCurveTo(6, 4, 5, 10); c.stroke();
      c.strokeStyle = '#4a2a2a'; c.lineWidth = 1; c.beginPath(); c.moveTo(4, 5); c.lineTo(8, 5); c.stroke();
      c.fillStyle = '#f4f0e8'; c.beginPath(); c.arc(0, -2, r + 1, Math.PI * 1.05, Math.PI * 1.95); c.fill();
      break;
    }
  }
  c.restore();
}

// ---------- humanoid ----------
// opts: { T, weapon:{id,state,x,y,ang}, enemyWeapon, flash, sheath, vx, player }
function drawHumanoid(c, x, y, facing, scale, pose, st, opts = {}) {
  const T = opts.T || 0;
  c.save(); c.translate(x, y); c.scale(facing * scale, scale);
  if (opts.rot) c.rotate(opts.rot);
  const sk = solveSkeleton(pose, opts.grounded !== false);
  const out = '#07050a';
  const cloth = st.cloth || st.cloak || '#333', skin = st.skin, armor = st.armor || shade(cloth, -0.2);
  const isBones = st.bones;
  const legCol = isBones ? st.skin : (st.pants || shade(cloth, -0.25));
  const armCol = isBones ? st.skin : (st.sleeve || (st.player ? armor : skin));

  // wings
  if (st.wings) drawWings(c, sk, st.wings, T, opts.flap || 0);
  // cape / cloak
  const capeCol = st.cape || (st.player ? st.cloak : null);
  if (capeCol && (st.capeOn !== false)) {
    const sp = clamp((opts.vx || 0) / 300, -1, 1); const fl = Math.sin(T * 9) * 3;
    const [s1x, s1y] = rotOff(sk, -4, 2); const long = st.longCape ? 1.5 : 1;
    const tail = [-22 - Math.abs(sp) * 20 * long, (st.longCape ? 52 : 34) - Math.abs(sp) * 14 + fl];
    c.beginPath(); c.moveTo(s1x + 4, s1y - 2);
    c.quadraticCurveTo(s1x - 14, s1y + 18, sk.hip[0] + tail[0], sk.hip[1] + tail[1] - 18 * long + 20);
    c.lineTo(sk.hip[0] + tail[0] + 8 + fl, sk.hip[1] + tail[1] - 8 * long + 18);
    c.quadraticCurveTo(sk.hip[0] - 4, sk.hip[1] + 6, sk.hip[0] + 2, sk.hip[1] - 4);
    c.closePath(); const g = c.createLinearGradient(s1x, s1y, s1x - 20, s1y + 40); g.addColorStop(0, shade(capeCol, 0.1)); g.addColorStop(1, shade(capeCol, -0.5));
    c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
  }
  // sheath / back weapon
  if (opts.sheath) opts.sheath(c, sk);
  // back arm
  limb(c, sk.sh[0], sk.sh[1], sk.A2.el[0], sk.A2.el[1], 6.5, shade(armCol, -0.3));
  limb(c, sk.A2.el[0], sk.A2.el[1], sk.A2.hand[0], sk.A2.hand[1], 5.5, shade(armCol, -0.3));
  if (opts.weapon2) opts.weapon2(c, sk);
  circ(c, sk.A2.hand[0], sk.A2.hand[1], 3.4, shade(st.glove || skin, -0.3), out, 1.5);
  // back leg
  const drawLeg = (L, dark) => {
    const col = dark ? shade(legCol, -0.3) : legCol;
    limb(c, sk.hip[0], sk.hip[1], L.kn[0], L.kn[1], isBones ? 3.5 : 9, col);
    limb(c, L.kn[0], L.kn[1], L.ft[0], L.ft[1], isBones ? 3 : 7.5, dark ? shade(st.boot || legCol, -0.3) : (st.boot || legCol));
    if (!isBones) { c.fillStyle = dark ? '#0a0806' : (st.bootCol || '#1a120c'); c.beginPath(); c.ellipse(L.ft[0] + 4, L.ft[1] - 1, 7, 3.6, 0, 0, 7); c.fill(); c.strokeStyle = out; c.lineWidth = 1.5; c.stroke(); }
    else { circ(c, L.kn[0], L.kn[1], 2.4, st.skin2); c.strokeStyle = st.skin; c.lineWidth = 3; c.beginPath(); c.moveTo(L.ft[0], L.ft[1]); c.lineTo(L.ft[0] + 7, L.ft[1]); c.stroke(); }
  };
  drawLeg(sk.L2, true);
  // torso
  c.save(); c.translate(sk.hip[0], sk.hip[1]); c.rotate(sk.tt);
  if (isBones) {
    c.strokeStyle = st.skin; c.lineWidth = 3.5; c.lineCap = 'round'; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -SK.torso); c.stroke();
    for (let i = 0; i < 5; i++) { c.beginPath(); c.ellipse(1, -14 - i * 4.5, 8, 2.2, 0, Math.PI, Math.PI * 2.0); c.strokeStyle = st.skin; c.lineWidth = 2; c.stroke(); }
    c.beginPath(); c.ellipse(0, -1, 7, 4, 0, 0, 7); c.fillStyle = st.skin2; c.fill();
    if (st.cloth) { c.fillStyle = st.cloth; c.beginPath(); c.moveTo(-8, -2); c.lineTo(8, -2); c.lineTo(10, 12); c.lineTo(-10, 12); c.fill(); }
  } else {
    const bw = st.belly ? 15 : 10, cw = st.bulk ? 13 : 11;
    const g = c.createLinearGradient(-cw, 0, cw, 0); g.addColorStop(0, shade(cloth, -0.45)); g.addColorStop(0.6, cloth); g.addColorStop(1, shade(cloth, 0.15));
    c.beginPath(); c.moveTo(-8, 2); c.lineTo(8, 2); c.quadraticCurveTo(bw + 2, -16, cw, -SK.torso + 2); c.quadraticCurveTo(0, -SK.torso - 6, -cw, -SK.torso + 2); c.quadraticCurveTo(-11, -16, -8, 2); c.closePath();
    c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
    if (st.belly) { c.beginPath(); c.ellipse(6, -10, 12, 13, 0, 0, 7); c.fillStyle = st.skin; c.fill(); c.stroke(); c.strokeStyle = st.skin2; c.lineWidth = 1; c.beginPath(); c.arc(8, -8, 2, 0, 6); c.stroke(); }
    if (st.player || st.armor) {
      const ag = c.createLinearGradient(-8, -30, 10, -10); ag.addColorStop(0, shade(armor, 0.35)); ag.addColorStop(1, shade(armor, -0.4));
      c.beginPath(); c.moveTo(-6, -SK.torso + 4); c.quadraticCurveTo(12, -SK.torso + 2, 11, -18); c.quadraticCurveTo(4, -12, -6, -16); c.closePath(); c.fillStyle = ag; c.fill(); c.strokeStyle = out; c.lineWidth = 1.5; c.stroke();
      c.strokeStyle = 'rgba(255,255,255,0.18)'; c.beginPath(); c.moveTo(-3, -SK.torso + 7); c.quadraticCurveTo(7, -SK.torso + 6, 8, -22); c.stroke();
    }
    if (st.player) { // strap for sheath
      c.strokeStyle = '#1a0f08'; c.lineWidth = 3.5; c.beginPath(); c.moveTo(-9, -SK.torso + 4); c.lineTo(9, -6); c.stroke();
      c.strokeStyle = '#6a5030'; c.lineWidth = 1; c.beginPath(); c.moveTo(-9, -SK.torso + 4); c.lineTo(9, -6); c.stroke();
    }
    c.fillStyle = st.belt || '#1a100a'; c.fillRect(-9, -4, 18, 5); c.fillStyle = '#a08850'; c.fillRect(4, -3.5, 4, 4);
    if (st.flames) for (let i = 0; i < 3; i++) { const fx = -6 + i * 6, fh = 8 + Math.sin(T * 12 + i * 2) * 4; poly(c, [fx - 4, -SK.torso + 2, fx, -SK.torso - fh, fx + 4, -SK.torso + 2], `rgba(255,${120 + i * 40},20,0.85)`); }
  }
  c.restore();
  // scarf
  if (st.player && st.scarf) {
    const sp = clamp(Math.abs(opts.vx || 0) / 300, 0, 1);
    c.strokeStyle = st.scarf; c.lineWidth = 4; c.lineCap = 'round'; c.beginPath(); c.moveTo(sk.neck[0], sk.neck[1]);
    c.quadraticCurveTo(sk.neck[0] - 12, sk.neck[1] + 2 + Math.sin(T * 10) * 3, sk.neck[0] - 20 - sp * 12, sk.neck[1] + 8 - sp * 6 + Math.sin(T * 12) * 4); c.stroke();
  }
  // front leg
  drawLeg(sk.L1, false);
  // head
  drawHead(c, sk, st, pose, T);
  if (st.halo) { c.save(); c.translate(sk.head[0], sk.head[1] - 18); c.strokeStyle = st.haloCol || '#fff2b0'; c.shadowColor = c.strokeStyle; c.shadowBlur = 14; c.lineWidth = 2.5; c.beginPath(); if (st.haloBroken) { c.ellipse(0, 0, 12, 3.5, -0.15, 0.4, 5.6); c.stroke(); c.beginPath(); c.ellipse(1.5, 2, 12, 3.5, -0.4, 5.75, 6.5); } else c.ellipse(0, 0, 12, 3.5, -0.15, 0, 7); c.stroke(); c.restore(); c.shadowBlur = 0; }
  if (st.crownTop) { c.save(); c.translate(sk.head[0], sk.head[1]); c.rotate((pose.t * 0.4 + pose.h) * D2R); poly(c, [-9, -9, -10, -21, -5, -14, 0, -23, 5, -14, 10, -21, 9, -9], '#e8b83a', '#07050a', 2); circ(c, 0, -15, 2, '#c0102a'); c.restore(); }
  // front arm + weapon
  if (opts.weapon) opts.weapon(c, sk);
  if (opts.enemyWeapon) drawEnemyWeapon(c, opts.enemyWeapon, sk.A1.hand[0], sk.A1.hand[1], pose.w, 1, st.weaponCol);
  limb(c, sk.sh[0], sk.sh[1], sk.A1.el[0], sk.A1.el[1], 7, armCol);
  limb(c, sk.A1.el[0], sk.A1.el[1], sk.A1.hand[0], sk.A1.hand[1], 6, st.player ? (st.sleeve2 || armCol) : armCol);
  if (st.player || st.armor) { circ(c, sk.sh[0], sk.sh[1], 7, shade(armor, 0.1), out, 2); }
  circ(c, sk.A1.hand[0], sk.A1.hand[1], 3.8, st.glove || skin, out, 1.5);
  if (st.weapon === 'claws' || opts.claws) { c.strokeStyle = '#e8e0d0'; c.lineWidth = 1.5; for (let i = -1; i <= 1; i++) { const v = vA(pose.a1f + i * 14, 9); c.beginPath(); c.moveTo(sk.A1.hand[0], sk.A1.hand[1]); c.lineTo(sk.A1.hand[0] + v[0], sk.A1.hand[1] + v[1]); c.stroke(); } }
  if (opts.flash > 0) { c.globalCompositeOperation = 'source-atop'; }
  c.restore();
  return sk;
}

function drawWings(c, sk, type, T, flap) {
  const [sx, sy] = rotOff(sk, -6, 4); const f = Math.sin(T * (type === 'angel' ? 3 : 6)) * 0.25 + flap;
  c.save(); c.translate(sx, sy);
  for (let side = 0; side < 2; side++) {
    c.save(); c.rotate(-0.4 - f - side * 0.35); const al = side ? 0.6 : 1;
    if (type === 'angel') {
      for (let i = 0; i < 9; i++) { c.save(); c.rotate(-i * 0.13); c.fillStyle = `rgba(${235 - i * 6},${230 - i * 6},${220 - i * 8},${al})`; c.beginPath(); c.ellipse(-20 - i * 5, -10, 34 - i, 6, 0.2, 0, 7); c.fill(); c.strokeStyle = 'rgba(80,60,40,0.5)'; c.lineWidth = 1; c.stroke(); c.restore(); }
      c.fillStyle = `rgba(90,0,0,${0.5 * al})`; c.beginPath(); c.ellipse(-30, -12, 8, 3, 0.3, 0, 7); c.fill();
    } else {
      c.fillStyle = side ? '#2a0604' : '#4a0e08'; c.strokeStyle = '#07050a'; c.lineWidth = 2;
      c.beginPath(); c.moveTo(0, 0); c.lineTo(-30, -36); c.lineTo(-62, -30); c.quadraticCurveTo(-52, -16, -56, -4); c.quadraticCurveTo(-44, -6, -40, 6); c.quadraticCurveTo(-28, 0, -22, 14); c.closePath(); c.fill(); c.stroke();
      c.beginPath(); c.moveTo(-30, -36); c.lineTo(-56, -4); c.moveTo(-30, -36); c.lineTo(-40, 6); c.moveTo(-30, -36); c.lineTo(-22, 14); c.stroke();
    }
    c.restore();
  }
  c.restore();
}

// ---------- quadruped (wolf) ----------
function drawQuad(c, x, y, facing, scale, st, s) {
  // s: {phase, state, atk(0..1), T, open}
  const T = s.T, ph = s.phase; const run = s.moving ? 1 : 0.15;
  c.save(); c.translate(x, y); c.scale(facing * scale, scale); if (s.rot) c.rotate(s.rot);
  const out = '#07050a';
  const bob = Math.sin(ph * 2) * 2.5 * run; const bodyY = -38 + bob - (s.crouch || 0);
  const lunge = s.lunge || 0;
  // tail
  c.strokeStyle = st.fur2; c.lineWidth = 8; c.lineCap = 'round'; c.beginPath(); c.moveTo(-28, bodyY - 4); c.quadraticCurveTo(-44, bodyY - 14 + Math.sin(T * 6) * 4, -56, bodyY + 4 + Math.sin(T * 5) * 6); c.stroke();
  // legs
  const leg = (hx, hy, a, dark) => { const t1 = a, k = [hx + Math.sin(t1 * D2R) * 18, hy + Math.cos(t1 * D2R) * 18]; const t2 = a - 25 - Math.max(0, Math.sin((a) * D2R)) * 30; const f = [k[0] + Math.sin(t2 * D2R) * 20, k[1] + Math.cos(t2 * D2R) * 20];
    limb(c, hx, hy, k[0], k[1], 8, dark ? st.fur2 : st.fur); limb(c, k[0], k[1], f[0], f[1], 5.5, dark ? st.fur2 : st.fur); c.fillStyle = '#ddd'; for (let i = 0; i < 3; i++) { c.fillRect(f[0] + 2 + i * 2, f[1] - 1, 1.4, 3); } };
  const sw = 38 * run;
  leg(-20, bodyY + 4, Math.sin(ph) * sw - 5, true); leg(20 + lunge, bodyY + 4, Math.sin(ph + 2.2) * sw + lunge, true);
  // body
  const g = c.createLinearGradient(0, bodyY - 18, 0, bodyY + 16); g.addColorStop(0, shade(st.fur, 0.15)); g.addColorStop(1, st.fur2);
  c.beginPath(); c.moveTo(-32, bodyY - 4); c.quadraticCurveTo(-20, bodyY - 20, 6, bodyY - 18); c.quadraticCurveTo(28 + lunge, bodyY - 22, 34 + lunge, bodyY - 6); c.quadraticCurveTo(30 + lunge, bodyY + 14, 14, bodyY + 12); c.quadraticCurveTo(-6, bodyY + 6, -24, bodyY + 10); c.quadraticCurveTo(-36, bodyY + 6, -32, bodyY - 4); c.closePath();
  c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 2.5; c.stroke();
  // fur spikes
  c.fillStyle = st.fur2; for (let i = 0; i < 9; i++) { const fx = -26 + i * 7, fy = bodyY - 16 - Math.sin(i / 8 * Math.PI) * 4; poly(c, [fx - 3, fy + 3, fx + 2, fy - 8 - Math.sin(T * 8 + i) * 1.5, fx + 5, fy + 3], st.fur2); }
  // ribs (starved)
  c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 1.5; for (let i = 0; i < 4; i++) { c.beginPath(); c.arc(4 + i * 6, bodyY, 9, 0.8, 2.2); c.stroke(); }
  leg(-16, bodyY + 6, Math.sin(ph + 3.1) * sw - 5, false); leg(24 + lunge, bodyY + 6, Math.sin(ph + 5.3) * sw + lunge, false);
  // head
  const hx = 38 + lunge, hy = bodyY - 12 + (s.howl ? -10 : 0); const open = s.open || 0;
  c.save(); c.translate(hx, hy); c.rotate(s.howl ? -0.7 : (s.atk ? 0.15 : 0));
  poly(c, [-8, -6, -4, -22, 3, -9], st.fur2, out, 1.5); poly(c, [-2, -7, 4, -21, 8, -7], st.fur, out, 1.5);
  c.beginPath(); c.moveTo(-10, -6); c.quadraticCurveTo(4, -14, 16, -7); c.lineTo(30, -3); c.lineTo(30, 1); c.lineTo(10, 2); c.quadraticCurveTo(-6, 10, -10, -6); c.closePath(); c.fillStyle = st.fur; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
  c.save(); c.rotate(open * 0.5); c.beginPath(); c.moveTo(-4, 4); c.lineTo(26, 3); c.lineTo(24, 8); c.quadraticCurveTo(6, 12, -4, 4); c.closePath(); c.fillStyle = shade(st.fur, -0.2); c.fill(); c.stroke();
  for (let i = 0; i < 5; i++) poly(c, [6 + i * 4, 3, 7.5 + i * 4, -1, 9 + i * 4, 3], '#f0e8d8'); c.restore();
  for (let i = 0; i < 5; i++) poly(c, [6 + i * 4, 1, 7.5 + i * 4, 5, 9 + i * 4, 1], '#f0e8d8');
  if (open > 0.3) { c.strokeStyle = 'rgba(200,0,0,0.7)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(14, 4); c.lineTo(14, 12 + Math.sin(T * 5) * 3); c.stroke(); }
  circ(c, 30, -2, 2.2, '#100');
  c.shadowColor = st.eye; c.shadowBlur = 12; circ(c, 6, -7, 2.4, st.eye); c.shadowBlur = 0;
  c.restore();
  c.restore();
}

// ---------- flyer ----------
function drawFlyer(c, x, y, facing, scale, st, s) {
  const T = s.T; const flap = Math.sin(T * (st.wraith ? 4 : 16) + (s.seed || 0));
  c.save(); c.translate(x, y); c.scale(facing * scale, scale); if (s.rot) c.rotate(s.rot);
  const out = '#07050a';
  if (st.wraith) {
    c.globalAlpha = 0.85; const g = c.createLinearGradient(0, -30, 0, 40); g.addColorStop(0, st.body); g.addColorStop(1, 'rgba(120,180,255,0)');
    c.beginPath(); c.moveTo(-14, -18); c.quadraticCurveTo(0, -36, 14, -18); c.lineTo(16, 10); for (let i = 0; i < 6; i++) { c.lineTo(14 - i * 6, 34 + Math.sin(T * 6 + i) * 6); c.lineTo(11 - i * 6, 22); } c.closePath(); c.fillStyle = g; c.fill();
    c.fillStyle = '#0a1420'; c.beginPath(); c.ellipse(4, -16, 9, 10, 0, 0, 7); c.fill();
    c.shadowColor = st.eye; c.shadowBlur = 12; circ(c, 6, -17, 2, st.eye); circ(c, 1, -17, 1.6, st.eye); c.shadowBlur = 0;
    c.strokeStyle = st.body; c.lineWidth = 3; c.beginPath(); c.moveTo(10, -6); c.quadraticCurveTo(26, -2 + flap * 6, 30, 8); c.stroke();
    for (let i = 0; i < 3; i++) { c.beginPath(); c.moveTo(30, 8); c.lineTo(34 + i * 2, 14 + i); c.stroke(); }
    c.globalAlpha = 1; c.restore(); return;
  }
  if (st.eyeball) {
    c.strokeStyle = '#7a1020'; c.lineWidth = 5; c.beginPath(); c.moveTo(-14, 0); c.quadraticCurveTo(-30, 10 + Math.sin(T * 4) * 8, -44, 4 + Math.sin(T * 3) * 10); c.stroke();
    for (let side = -1; side <= 1; side += 2) { c.save(); c.scale(1, 1); c.rotate(side * 0.2); c.fillStyle = st.wing; c.beginPath(); c.moveTo(0, -6); c.lineTo(-8, -30 - flap * 14 * (side > 0 ? 1 : 0.6)); c.lineTo(-30, -22 - flap * 10); c.lineTo(-16, -8); c.closePath(); c.fill(); c.restore(); }
    const g = c.createRadialGradient(-4, -4, 2, 0, 0, 18); g.addColorStop(0, '#fff'); g.addColorStop(1, '#b8a898'); circ(c, 0, 0, 17, g, out, 2);
    c.strokeStyle = 'rgba(180,20,30,0.7)'; c.lineWidth = 1; for (let i = 0; i < 6; i++) { const a = i; c.beginPath(); c.moveTo(Math.cos(a) * 17, Math.sin(a) * 17); c.quadraticCurveTo(Math.cos(a + 0.3) * 10, Math.sin(a + 0.3) * 10, Math.cos(a) * 7, Math.sin(a) * 7); c.stroke(); }
    const lx = s.lookX || 6, ly = s.lookY || 0; circ(c, lx, ly, 7.5, '#8a0a0a'); circ(c, lx, ly, 3.6, '#000'); circ(c, lx - 2, ly - 2, 1.4, '#fff');
    c.restore(); return;
  }
  // bat / imp
  const wingUp = flap * 26;
  const wing = (dark) => { c.fillStyle = dark ? shade(st.wing, -0.4) : st.wing; c.strokeStyle = out; c.lineWidth = 2; c.beginPath(); c.moveTo(-2, -4); c.lineTo(-14, -24 - wingUp); c.lineTo(-38, -20 - wingUp * 0.8); c.quadraticCurveTo(-32, -10 - wingUp * 0.4, -36, -2 - wingUp * 0.2); c.quadraticCurveTo(-26, -4, -24, 4); c.quadraticCurveTo(-14, 0, -6, 6); c.closePath(); c.fill(); c.stroke();
    c.strokeStyle = shade(st.wing, 0.3); c.lineWidth = 1; c.beginPath(); c.moveTo(-14, -24 - wingUp); c.lineTo(-36, -2 - wingUp * 0.2); c.moveTo(-14, -24 - wingUp); c.lineTo(-24, 4); c.stroke(); };
  c.save(); c.scale(-1, 1); c.translate(-4, 0); wing(true); c.restore();
  if (st.imp) { c.strokeStyle = st.body; c.lineWidth = 2.5; c.beginPath(); c.moveTo(-6, 6); c.quadraticCurveTo(-18, 18, -10, 24 + Math.sin(T * 6) * 3); c.stroke(); poly(c, [-12, 22, -6, 26, -12, 28], st.body); }
  c.beginPath(); c.ellipse(0, 0, 10, 13, 0.2, 0, 7); const g = c.createRadialGradient(-2, -4, 2, 0, 0, 14); g.addColorStop(0, shade(st.body, 0.3)); g.addColorStop(1, st.body); c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
  // head
  c.save(); c.translate(6, -12);
  if (st.imp) { poly(c, [-4, -6, -8, -16, 0, -8], '#2a1a14', out, 1); poly(c, [3, -7, 4, -18, 7, -6], '#2a1a14', out, 1); }
  else { poly(c, [-6, -4, -9, -18, -1, -8], st.body, out, 1.5); poly(c, [1, -6, 4, -20, 8, -5], st.body, out, 1.5); poly(c, [2, -7, 4, -15, 6, -6], '#5a2a3a'); }
  circ(c, 0, 0, 8, st.body, out, 2); poly(c, [5, -1, 12, 1, 6, 4], shade(st.body, 0.2), out, 1);
  c.shadowColor = st.eye; c.shadowBlur = 10; circ(c, 3, -2, 2, st.eye); circ(c, -2, -2, 1.6, st.eye); c.shadowBlur = 0;
  c.fillStyle = '#100'; c.beginPath(); c.ellipse(4, 4, 4, 2 + (s.open || 0) * 3, 0, 0, 7); c.fill(); poly(c, [2, 3, 3, 7.5, 4, 3], '#fff'); poly(c, [5, 3, 6, 7.5, 7, 3], '#fff');
  c.restore();
  wing(false);
  c.restore();
}

// ---------- blob / crawler ----------
function drawBlob(c, x, y, facing, scale, st, s) {
  const T = s.T; c.save(); c.translate(x, y); c.scale(facing * scale, scale); if (s.rot) c.rotate(s.rot);
  const out = '#07050a';
  if (st.legs) {
    for (let i = 0; i < 6; i++) { const lx = -14 + i * 6, ph = T * 14 + i * 1.7; const kx = lx + Math.cos(ph) * 4 * (s.moving ? 1 : 0.2), ky = -18 - Math.abs(Math.sin(ph)) * 8; limb(c, lx, -12, kx + (i < 3 ? -8 : 8), ky, 3, st.body2); limb(c, kx + (i < 3 ? -8 : 8), ky, lx + (i < 3 ? -14 : 14), 0, 2.5, st.body2); }
    c.beginPath(); c.ellipse(0, -18, 22, 13, 0, Math.PI, 0); c.quadraticCurveTo(18, -8, 0, -8); c.quadraticCurveTo(-18, -8, -22, -18); const g = c.createLinearGradient(0, -32, 0, -8); g.addColorStop(0, shade(st.body, 0.2)); g.addColorStop(1, st.body2); c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke();
    for (let i = 0; i < 4; i++) { c.strokeStyle = st.body2; c.lineWidth = 1.5; c.beginPath(); c.arc(0, -18, 6 + i * 4, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); }
    for (let i = 0; i < 3; i++) { const ex = 10 + i * 4, ey = -30 - i * 3 + Math.sin(T * 3 + i) * 3; c.strokeStyle = st.body2; c.lineWidth = 2; c.beginPath(); c.moveTo(12, -22); c.lineTo(ex, ey); c.stroke(); c.shadowColor = st.eye; c.shadowBlur = 8; circ(c, ex, ey, 2.4, st.eye); c.shadowBlur = 0; }
    c.fillStyle = '#100'; c.beginPath(); c.ellipse(18, -12, 6, 3 + (s.open || 0) * 4, 0, 0, 7); c.fill(); for (let i = 0; i < 4; i++) poly(c, [14 + i * 2.5, -13, 15 + i * 2.5, -9, 16 + i * 2.5, -13], '#eee');
    c.restore(); return;
  }
  // flesh blob
  const pulse = Math.sin(T * 4) * 0.06; const sq = s.squash || 0;
  const W = 30 * (1 + pulse + sq), H = 30 * (1 - pulse - sq * 0.6);
  c.beginPath(); for (let i = 0; i <= 24; i++) { const a = Math.PI + i / 24 * Math.PI; const wob = 1 + Math.sin(a * 5 + T * 5) * 0.06; c.lineTo(Math.cos(a) * W * wob, Math.sin(a) * H * 1.3 * wob); } c.closePath();
  const g = c.createRadialGradient(-6, -H, 4, 0, -H * 0.4, W * 1.4); g.addColorStop(0, shade(st.body, 0.25)); g.addColorStop(0.7, st.body); g.addColorStop(1, st.body2); c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 2.5; c.stroke();
  c.strokeStyle = 'rgba(90,0,20,0.6)'; c.lineWidth = 1.3; for (let i = 0; i < 6; i++) { c.beginPath(); c.moveTo(-W * 0.8 + i * W * 0.3, -2); c.quadraticCurveTo(-W * 0.6 + i * W * 0.28, -H * 0.8, -W * 0.3 + i * W * 0.2, -H * 1.2); c.stroke(); }
  const mo = s.open || (0.3 + 0.3 * Math.sin(T * 6));
  [[W * 0.45, -H * 0.5, 9], [-W * 0.35, -H * 0.85, 6], [W * 0.05, -H * 0.25, 5]].forEach(([mx, my, mr], i) => { c.fillStyle = '#2a0006'; c.beginPath(); c.ellipse(mx, my, mr, mr * (0.3 + mo * 0.6 * (i ? 0.7 : 1)), 0, 0, 7); c.fill(); for (let k = 0; k < 5; k++) { const tx = mx - mr + k * mr * 0.45 + 1; poly(c, [tx, my - mr * 0.3 * mo - 1, tx + 1.5, my + 1, tx + 3, my - mr * 0.3 * mo - 1], '#f8f0d8'); } });
  [[W * 0.2, -H * 1.0], [W * 0.6, -H * 0.9], [-W * 0.1, -H * 1.15], [-W * 0.6, -H * 0.4]].forEach(([ex, ey], i) => { circ(c, ex, ey, 4, '#fff4d0', out, 1.2); circ(c, ex + 1.5 + Math.sin(T + i), ey, 1.8, '#000'); });
  c.restore();
}

// ---------- the Drowned Mother ----------
function drawSeaMonster(c, x, y, st, s) {
  const T = s.T; c.save(); c.translate(x, y + (s.rise || 0));
  const out = '#020606';
  // tentacles behind
  for (let i = 0; i < 6; i++) { const bx = -160 + i * 60, ph = T * 1.5 + i; c.strokeStyle = i % 2 ? '#14403a' : '#1c5048'; c.lineWidth = 22 - i; c.lineCap = 'round'; c.beginPath(); c.moveTo(bx, 0); c.bezierCurveTo(bx - 30 + Math.sin(ph) * 30, -120, bx + 40 + Math.cos(ph) * 40, -200, bx + Math.sin(ph * 1.3) * 60, -280 - i * 10); c.stroke(); c.strokeStyle = 'rgba(220,255,240,0.25)'; c.lineWidth = 3; c.stroke(); }
  // head
  const open = s.open || 0;
  c.beginPath(); c.moveTo(-150, 20); c.bezierCurveTo(-170, -160, -60, -300, 20, -290); c.bezierCurveTo(120, -280, 170, -160, 150, 20); c.closePath();
  const g = c.createLinearGradient(0, -290, 0, 20); g.addColorStop(0, '#2a6a62'); g.addColorStop(1, '#06201c'); c.fillStyle = g; c.fill(); c.strokeStyle = out; c.lineWidth = 4; c.stroke();
  // barnacles & scars
  for (let i = 0; i < 26; i++) { const bx = Math.sin(i * 12.9) * 120, by = -40 - Math.abs(Math.cos(i * 7.3)) * 220; circ(c, bx, by, 3 + (i % 4), 'rgba(200,220,200,0.25)'); }
  // eyes (many)
  const eyes = [[-60, -170, 18], [40, -180, 22], [-10, -220, 12], [90, -130, 10], [-100, -120, 9], [10, -140, 8]];
  eyes.forEach(([ex, ey, er], i) => { c.fillStyle = '#020a08'; c.beginPath(); c.ellipse(ex, ey, er + 4, er * 0.8 + 3, 0, 0, 7); c.fill(); c.shadowColor = '#e8ff7a'; c.shadowBlur = 20; circ(c, ex, ey, er * (s.blink && i < 2 ? 0.15 : 1) * 0.75, '#e8ff7a'); c.shadowBlur = 0; c.fillStyle = '#000'; c.fillRect(ex - 2 + (s.lookX || 0) * er * 0.3, ey - er * 0.6, 4, er * 1.2); });
  // mouth
  c.fillStyle = '#010303'; c.beginPath(); c.moveTo(-90, -60); c.quadraticCurveTo(0, -60 - 20 - open * 20, 90, -60); c.quadraticCurveTo(0, -60 + 30 + open * 90, -90, -60); c.fill();
  for (let i = 0; i < 14; i++) { const tx = -84 + i * 12.5; poly(c, [tx, -66 - open * 8, tx + 6, -40 - open * 4 + (i % 2) * 6, tx + 12, -66 - open * 8], '#d8e0c8'); poly(c, [tx, -54 + open * 50, tx + 6, -76 + open * 40 - (i % 2) * 6, tx + 12, -54 + open * 50], '#c8d0b8'); }
  // front tentacles (feelers)
  for (let i = 0; i < 4; i++) { const bx = -100 + i * 66, ph = T * 2 + i * 1.6; c.strokeStyle = '#1a4a44'; c.lineWidth = 12; c.beginPath(); c.moveTo(bx, -30); c.bezierCurveTo(bx + Math.sin(ph) * 30, 0, bx - 40, 30, bx - 60 + Math.cos(ph) * 20, 10); c.stroke(); }
  c.restore();
}

// ---------- THE EYE (boss) ----------
function drawEyeBoss(c, x, y, s) {
  const T = s.T; c.save(); c.translate(x, y);
  const R = 92 * (s.scale || 1);
  // tentacles
  for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2 + T * 0.2; const ph = T * 2 + i; c.strokeStyle = i % 2 ? '#2a0a10' : '#3a0e18'; c.lineWidth = 14; c.lineCap = 'round'; c.beginPath(); const sx = Math.cos(a) * R * 1.1, sy = Math.sin(a) * R * 1.1; c.moveTo(sx, sy); c.bezierCurveTo(sx + Math.cos(a) * 60 + Math.sin(ph) * 30, sy + Math.sin(a) * 60, sx + Math.cos(a + 0.5) * 120, sy + Math.sin(a + 0.5) * 120 + Math.cos(ph) * 30, sx + Math.cos(a + 0.8) * 170, sy + Math.sin(a + 0.8) * 160); c.stroke(); c.strokeStyle = 'rgba(255,120,140,0.2)'; c.lineWidth = 3; c.stroke(); }
  // rune ring
  c.save(); c.rotate(T * 0.3); c.strokeStyle = 'rgba(255,255,255,0.18)'; c.lineWidth = 1.5; c.beginPath(); c.arc(0, 0, R * 1.7, 0, 7); c.stroke(); c.font = '16px serif'; c.fillStyle = 'rgba(255,255,255,0.35)';
  const runes = 'ᚦᛖᛃᛖᛒᛖᚺᛁᚾᛞᛃᛟᚢ'; for (let i = 0; i < runes.length; i++) { c.save(); c.rotate(i / runes.length * Math.PI * 2); c.fillText(runes[i], -5, -R * 1.7 - 6); c.restore(); } c.restore();
  // flesh socket
  c.beginPath(); c.ellipse(0, 0, R * 1.32, R * 1.15, 0, 0, 7); const sg = c.createRadialGradient(0, 0, R * 0.9, 0, 0, R * 1.35); sg.addColorStop(0, '#5a1420'); sg.addColorStop(1, '#14040a'); c.fillStyle = sg; c.fill();
  // eyeball
  c.save(); c.beginPath(); const lid = s.lid ?? 1; c.ellipse(0, 0, R * 1.1, R * 0.95 * lid + 0.1, 0, 0, 7); c.clip();
  const eg = c.createRadialGradient(-R * 0.3, -R * 0.3, R * 0.1, 0, 0, R * 1.1); eg.addColorStop(0, '#fffaf0'); eg.addColorStop(0.7, '#e0d0c0'); eg.addColorStop(1, '#8a5a50'); c.fillStyle = eg; c.fillRect(-R * 1.2, -R * 1.2, R * 2.4, R * 2.4);
  if (EyeArt.veins) EyeArt.drawVeins(c, R * 1.1, 0.9);
  const lx = (s.lookX || 0) * R * 0.45, ly = (s.lookY || 0) * R * 0.35;
  EyeArt.drawIris(c, lx, ly, R * 0.5, s.pupil || 0.38, T, s.irisCol);
  c.restore();
  // lids
  c.strokeStyle = '#1a0408'; c.lineWidth = 6; c.beginPath(); c.ellipse(0, 0, R * 1.1, R * 0.95 * lid + 0.1, 0, 0, 7); c.stroke();
  c.restore();
}

// ---------- realistic eye shared art (menu + boss) ----------
const EyeArt = (() => {
  const E = {}; let irisCache = {}; let veinPaths = null;
  E.veins = true;
  function makeVeins() { veinPaths = []; for (let i = 0; i < 34; i++) { const a = Math.random() * Math.PI * 2; const path = []; let r = 1, ang = a; path.push([Math.cos(ang) * r, Math.sin(ang) * r]); const steps = 6 + (Math.random() * 6 | 0); for (let k = 0; k < steps; k++) { r -= rnd(0.04, 0.09); ang += rnd(-0.25, 0.25); path.push([Math.cos(ang) * r, Math.sin(ang) * r]); } veinPaths.push({ path, w: rnd(0.6, 2.2), br: Math.random() < 0.4 ? (Math.random() * steps | 0) : -1 }); } }
  E.drawVeins = (c, R, alpha = 1) => { if (!veinPaths) makeVeins(); c.save(); c.lineCap = 'round'; veinPaths.forEach(v => { c.strokeStyle = `rgba(${150 + (v.w * 30 | 0)},10,20,${0.55 * alpha})`; c.lineWidth = v.w * R / 120; c.beginPath(); v.path.forEach(([x, y], i) => i ? c.lineTo(x * R, y * R) : c.moveTo(x * R, y * R)); c.stroke(); if (v.br >= 0) { const [bx, by] = v.path[v.br]; c.lineWidth *= 0.6; c.beginPath(); c.moveTo(bx * R, by * R); c.lineTo(bx * R * 0.86 + by * R * 0.1, by * R * 0.86 - bx * R * 0.1); c.stroke(); } }); c.restore(); };
  function makeIris(size, col) {
    const cv = document.createElement('canvas'); cv.width = cv.height = size * 2; const c = cv.getContext('2d'); c.translate(size, size);
    const base = col || ['#6a3a0a', '#c8781a', '#e8b04a'];
    const g = c.createRadialGradient(0, 0, size * 0.2, 0, 0, size); g.addColorStop(0, base[2]); g.addColorStop(0.45, base[1]); g.addColorStop(0.85, base[0]); g.addColorStop(1, '#100804');
    c.fillStyle = g; c.beginPath(); c.arc(0, 0, size, 0, 7); c.fill();
    for (let i = 0; i < 520; i++) { const a = Math.random() * Math.PI * 2, r1 = size * rnd(0.22, 0.35), r2 = size * rnd(0.6, 0.98); c.strokeStyle = Math.random() < 0.5 ? `rgba(255,${200 + Math.random() * 55 | 0},${120 + Math.random() * 80 | 0},${rnd(0.05, 0.3)})` : `rgba(40,15,0,${rnd(0.1, 0.4)})`; c.lineWidth = rnd(0.5, 2) * size / 100; c.beginPath(); c.moveTo(Math.cos(a) * r1, Math.sin(a) * r1); const a2 = a + rnd(-0.08, 0.08); c.quadraticCurveTo(Math.cos(a2) * (r1 + r2) / 2, Math.sin(a2) * (r1 + r2) / 2, Math.cos(a) * r2, Math.sin(a) * r2); c.stroke(); }
    for (let i = 0; i < 40; i++) { const a = Math.random() * 7, r = size * rnd(0.45, 0.85); c.fillStyle = `rgba(20,8,0,${rnd(0.2, 0.5)})`; c.beginPath(); c.ellipse(Math.cos(a) * r, Math.sin(a) * r, size * 0.04, size * 0.02, a, 0, 7); c.fill(); }
    // collarette ring
    c.strokeStyle = 'rgba(255,220,150,0.35)'; c.lineWidth = size * 0.03; c.beginPath(); for (let i = 0; i <= 40; i++) { const a = i / 40 * Math.PI * 2, r = size * (0.42 + Math.sin(i * 1.7) * 0.03); c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.stroke();
    const lg = c.createRadialGradient(0, 0, size * 0.85, 0, 0, size); lg.addColorStop(0, 'rgba(0,0,0,0)'); lg.addColorStop(1, 'rgba(0,0,0,0.85)'); c.fillStyle = lg; c.beginPath(); c.arc(0, 0, size, 0, 7); c.fill();
    return cv;
  }
  E.drawIris = (c, x, y, r, pupil, T, col) => {
    const key = (col ? col.join() : 'd') + '|' + Math.round(r / 20); if (!irisCache[key]) irisCache[key] = makeIris(Math.max(60, Math.round(r / 20) * 20), col);
    const img = irisCache[key]; c.save(); c.translate(x, y); c.rotate(T * 0.02); c.drawImage(img, -r, -r, r * 2, r * 2); c.restore();
    const pr = r * pupil; const pg = c.createRadialGradient(x, y, pr * 0.3, x, y, pr * 1.1); pg.addColorStop(0, '#000'); pg.addColorStop(0.85, '#020000'); pg.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = pg; c.beginPath(); c.arc(x, y, pr * 1.1, 0, 7); c.fill();
    // reflections
    c.fillStyle = 'rgba(255,255,255,0.85)'; c.beginPath(); c.ellipse(x - r * 0.35, y - r * 0.38, r * 0.16, r * 0.11, -0.6, 0, 7); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.ellipse(x + r * 0.3, y + r * 0.3, r * 0.06, r * 0.04, -0.6, 0, 7); c.fill();
  };
  E.reset = () => { irisCache = {}; veinPaths = null; };
  return E;
})();
// weapon icon: fits a weapon diagonally (grip bottom-left, tip top-right) into a square box
const WICON = { executioner: [-28, 94], bloodfang: [-14, 54], doomhammer: [-33, 104], soulreaper: [-34, 122], voidspear: [-50, 145] };
function drawWeaponIcon(c, id, cx, cy, size, tint, T) {
  const b = WICON[id] || [-30, 100]; const L = b[1] - b[0]; const s = size * 0.9 / (L * 0.707 + 30); const m = (b[0] + b[1]) / 2;
  const dx = 0.707, dy = -0.707; c.save(); c.translate(cx - dx * m * s, cy - dy * m * s); c.scale(s, s); drawWeaponAt(c, id, 0, 0, 135, tint, T || 0); c.restore();
}

// ===== PERCY — the good boy =====
function drawDog(c, x, y, facing, sc, o) {
  const T = o.T || 0, ph = o.phase || 0, run = o.moving ? 1 : 0;
  c.save(); c.translate(x, y); c.scale(facing * sc, sc);
  if (o.dead) { c.translate(0, -4 * o.dead); c.rotate(-o.dead * 0.08); c.scale(1, 1 - o.dead * 0.35); }
  const fur = o.flash ? '#fff' : '#8a5a2e', furD = o.flash ? '#ddd' : '#5e3a1c', furL = o.flash ? '#fff' : '#c08a52', white = '#efe4d2';
  const bob = run ? Math.abs(Math.sin(ph)) * 3 : Math.sin(T * 3) * 0.8;
  const bite = o.bite || 0, lean = bite ? 0.12 : 0;
  // legs: two-segment with stride
  const leg = (lx, off, near) => {
    const a = run ? Math.sin(ph + off) * 0.7 : 0, a2 = run ? Math.max(0, Math.sin(ph + off + 1.2)) * 0.8 : 0;
    c.save(); c.translate(lx, -30 - bob * 0.3); c.rotate(o.dead ? 1.2 : a);
    c.fillStyle = near ? fur : furD; c.beginPath(); c.roundRect(-4.5, 0, 9, 17, 4); c.fill();
    c.translate(0, 15); c.rotate(o.dead ? 0.3 : -a2 * Math.sign(off + 0.1));
    c.fillStyle = near ? furL : furD; c.beginPath(); c.roundRect(-3.5, 0, 7, 14, 3); c.fill();
    c.fillStyle = near ? white : '#b9ab98'; c.beginPath(); c.ellipse(1.5, 14, 5, 3, 0, 0, 7); c.fill();
    c.restore();
  };
  leg(-16, Math.PI, false); leg(15, 0, false);
  // tail
  const wag = Math.sin((o.wag || 0)) * (o.low ? 0.2 : 0.6);
  c.save(); c.translate(-25, -42 - bob); c.rotate(-0.9 + wag + (o.dead ? 1.4 : 0) + (o.low ? 0.9 : 0));
  c.strokeStyle = fur; c.lineCap = 'round'; c.lineWidth = 6; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-6, -12, -2, -24); c.stroke();
  c.strokeStyle = white; c.lineWidth = 3.5; c.beginPath(); c.moveTo(-2.5, -20); c.lineTo(-2, -25); c.stroke(); c.restore();
  // body
  c.save(); c.translate(0, -bob); c.rotate(lean);
  const g = c.createLinearGradient(0, -58, 0, -26); g.addColorStop(0, furL); g.addColorStop(0.5, fur); g.addColorStop(1, furD);
  c.fillStyle = g; c.beginPath(); c.ellipse(0, -42, 28, 13, 0, 0, 7); c.fill();
  c.fillStyle = white; c.beginPath(); c.ellipse(18, -36, 10, 9, 0.3, 0, 7); c.fill();
  c.strokeStyle = 'rgba(0,0,0,0.25)'; c.lineWidth = 1; c.beginPath(); c.moveTo(-14, -50); c.quadraticCurveTo(-4, -46, 6, -51); c.stroke();
  c.restore();
  leg(-12, Math.PI + 1.6, true); leg(19, 1.6, true);
  // head
  c.save(); c.translate(24, -54 - bob + (o.dead ? 10 : 0)); c.rotate((bite ? 0.25 : 0) + (o.dead ? 0.5 : 0) + (o.low ? 0.15 : 0) - (o.bark ? 0.2 : 0));
  c.fillStyle = fur; c.beginPath(); c.ellipse(4, -6, 12, 11, 0, 0, 7); c.fill();
  // snout + jaw
  const open = bite ? 0.5 : o.bark ? 0.35 : 0;
  c.fillStyle = furL; c.beginPath(); c.ellipse(16, -3, 9, 5.5, 0.1, 0, 7); c.fill();
  c.save(); c.translate(10, 1); c.rotate(open); c.fillStyle = furL; c.beginPath(); c.ellipse(5, 2, 8, 3.5, 0, 0, 7); c.fill(); if (open) { c.fillStyle = '#d04a5a'; c.beginPath(); c.ellipse(5, 0, 6, 2, 0, 0, 7); c.fill(); c.fillStyle = '#fff'; c.fillRect(9, -1.5, 1.5, 2.5); } c.restore();
  c.fillStyle = '#1a0e0a'; c.beginPath(); c.ellipse(24, -5, 3, 2.5, 0, 0, 7); c.fill(); c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(23, -6.5, 1.2, 1);
  // eye
  if (o.dead) { c.strokeStyle = '#1a0e0a'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(4, -10); c.lineTo(10, -8); c.stroke(); }
  else { c.fillStyle = '#1a0e0a'; c.beginPath(); c.arc(8, -9, 2.6, 0, 7); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(8.8, -9.8, 0.9, 0, 7); c.fill(); c.strokeStyle = furD; c.lineWidth = 1.4; c.beginPath(); c.moveTo(4, o.low ? -11 : -13); c.lineTo(11, -13); c.stroke(); }
  // floppy ear (bounces)
  const flop = Math.sin(ph * 1.0 + 0.5) * (run ? 0.35 : 0.08) + (o.bark ? -0.3 : 0);
  c.save(); c.translate(-2, -14); c.rotate(0.35 + flop); c.fillStyle = furD; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-9, 6, -6, 20); c.quadraticCurveTo(-1, 22, 3, 14); c.quadraticCurveTo(5, 6, 0, 0); c.fill(); c.restore();
  c.restore();
  // collar + tag
  c.save(); c.translate(18, -48 - bob); c.rotate(0.5); c.fillStyle = '#b0182a'; c.fillRect(-3, -9, 6, 18); c.restore();
  const tsw = Math.sin(T * 6 + ph) * 2; c.fillStyle = '#e8c04a'; c.beginPath(); c.arc(24 + tsw * 0.3, -38 - bob, 3.2, 0, 7); c.fill(); c.fillStyle = '#8a6a1a'; c.font = 'bold 3px sans-serif'; c.textAlign = 'center'; c.fillText('P', 24 + tsw * 0.3, -37 - bob);
  c.restore();
}

function drawCompanion(c, x, y, f, sc, o) {
  const T = o.T || 0, k = o.kind; c.save(); c.translate(x, y); c.scale(f * sc, sc);
  const dd = o.dead ? Math.min(1, (o.deathT || 0) / 0.8) : 0;
  if (dd) { c.rotate(dd * (k === 'golem' ? 0.5 : 1.3)); c.globalAlpha = 0.85; }
  if (o.flash) c.globalAlpha *= 0.7;
  if (k === 'raven') {
    const w = dd ? 0.3 : Math.sin(T * 20) * 14;
    c.fillStyle = '#17141c'; c.beginPath(); c.moveTo(-18, -2); c.lineTo(-40, 6 + w * 0.2); c.lineTo(-18, 6); c.fill();
    c.fillStyle = '#26212e'; c.beginPath(); c.moveTo(-3, -5); c.lineTo(-24, -30 - w); c.lineTo(-30, -8 - w * 0.4); c.lineTo(8, -1); c.fill();
    c.fillStyle = '#1d1923'; c.beginPath(); c.ellipse(0, 0, 21, 10, 0, 0, 7); c.fill(); c.beginPath(); c.ellipse(18, -5, 8, 7, 0, 0, 7); c.fill();
    c.fillStyle = '#d9c27a'; c.beginPath(); c.moveTo(24, -7); c.lineTo(37, -3); c.lineTo(24, -1); c.fill();
    c.fillStyle = o.low ? '#ff9a3a' : '#ff2a2a'; c.beginPath(); c.arc(21, -8, 2.2, 0, 7); c.fill();
    c.fillStyle = '#34304a'; c.beginPath(); c.moveTo(2, -4); c.lineTo(-18, -26 - w * 0.8); c.lineTo(-22, -6 - w * 0.3); c.lineTo(12, 0); c.fill();
  } else if (k === 'wisp') {
    const fl = 0.8 + Math.sin(T * 9) * 0.2, bob = Math.sin(T * 3) * 3; c.translate(0, bob);
    for (let i = 3; i >= 1; i--) { c.globalAlpha = 0.18 * fl / i; c.fillStyle = '#7ae8ff'; c.beginPath(); c.arc(-i * 9, 8 + Math.sin(T * 5 + i) * 3, 8 - i, 0, 7); c.fill(); }
    c.globalAlpha = dd ? 0.5 : 1; c.strokeStyle = '#9aa8b0'; c.lineWidth = 2; c.beginPath(); c.arc(0, -20, 6, Math.PI, 0); c.stroke();
    c.fillStyle = '#2b3a44'; c.fillRect(-10, -16, 20, 4); c.fillRect(-10, 8, 20, 4);
    c.fillStyle = 'rgba(150,235,255,' + (0.55 * fl) + ')'; c.fillRect(-8, -12, 16, 20);
    c.fillStyle = '#e8fdff'; c.beginPath(); c.arc(0, -2, 5 * fl, 0, 7); c.fill(); c.fillStyle = '#0a1a20'; c.fillRect(-4, -5, 2, 3); c.fillRect(2, -5, 2, 3);
    if (!dd) { c.globalCompositeOperation = 'lighter'; const g = c.createRadialGradient(0, -2, 0, 0, -2, 46); g.addColorStop(0, 'rgba(120,230,255,' + 0.35 * fl + ')'); g.addColorStop(1, 'rgba(120,230,255,0)'); c.fillStyle = g; c.fillRect(-46, -48, 92, 92); c.globalCompositeOperation = 'source-over'; }
  } else {
    const sw = o.moving ? Math.sin(T * 7) * 6 : 0, up = o.bite || 0, arm = -0.4 - Math.sin(Math.min(1, up) * Math.PI) * 1.8;
    c.fillStyle = '#4a3c36'; c.fillRect(-14 + sw * 0.5, -22, 12, 22); c.fillRect(4 - sw * 0.5, -22, 12, 22);
    c.fillStyle = '#6b5a52'; c.fillRect(-20, -62, 40, 42);
    c.strokeStyle = '#2a201c'; c.lineWidth = 2; c.beginPath(); c.moveTo(-20, -48); c.lineTo(20, -40); c.moveTo(-6, -62); c.lineTo(-2, -20); for (let i = 0; i < 5; i++) { c.moveTo(-8 + i * 4, -52); c.lineTo(-6 + i * 4, -46); } c.stroke();
    c.fillStyle = '#7a665c'; c.fillRect(-12, -80, 26, 20); c.fillStyle = o.low ? '#ff9a3a' : '#ff3a2a'; c.fillRect(2, -74, 8, 5);
    c.save(); c.translate(18, -56); c.rotate(arm); c.fillStyle = '#5a4a44'; c.fillRect(-5, 0, 10, 30); c.fillStyle = '#7a665c'; c.fillRect(-8, 26, 16, 14); c.restore();
    c.save(); c.translate(-20, -56); c.rotate(0.3 + sw * 0.03); c.fillStyle = '#5a4a44'; c.fillRect(-5, 0, 10, 28); c.fillRect(-8, 24, 16, 12); c.restore();
  }
  c.restore();
}
