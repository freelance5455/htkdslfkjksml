// ===== BOSSES: unique attack patterns =====
const Bosses = (() => {
  const B = {};
  B.create = (key, st, x) => {
    const def = Object.assign({}, BOSSES[key]); const s = def.scale; if (st.S && st.S.tier) def.name += ' \u00b7 ECHO ' + st.S.tier;
    const hpMul = (1 + SD(st.idx) * 0.08) * (st.nm ? 1.7 : 1) * (st.endless ? 1 + st.ewave * 0.06 : 1);
    const b = { boss: true, key, type: key, def, x, y: GY, z: 4, vx: 0, vy: 0, facing: -1, hp: def.hp * hpMul, maxHp: def.hp * hpMul, dead: false, deathT: 0, flash: 0, atk: null, cd: 2.2, intro: INTRO_T[key] || 3, introT: 0, phaseN: 1, phaseT: 0, broken: 0, breakM: 0, T: 0, phase: 0, pose: 'roar', cp: P({}), grounded: true, last: null, spawnT: 0, seed: 0 };
    if (def.kind === 'humanoid') { b.w = 46 * s; b.h = 105 * s; }
    if (def.kind === 'quad') { b.w = 80 * s; b.h = 64 * s; }
    if (def.kind === 'flyer') { b.w = 50 * s; b.h = 46 * s; b.flying = true; b.y = GY - 220; b.baseY = GY - 200; }
    if (def.kind === 'blob') { b.w = 60 * s; b.h = 56 * s; }
    if (def.kind === 'sea') { b.w = 260; b.h = 300; b.x = st.lock[1] - 190; b.rise = 360; }
    if (def.kind === 'eye') { b.w = 170; b.h = 170; b.flying = true; b.y = GY - 200; b.baseY = GY - 200; b.lid = 0; }
    if (def.fly) { b.flying = true; b.y = GY - 150; b.baseY = GY - 150; b.w = 46 * s; b.h = 105 * s; }
    return b;
  };
  const INTRO_T = { goblinKing: 3.0, vampireBat: 3.2, bigWolf: 3.4, undeadKnight: 3.4, fireDemon: 3.2, seaMonster: 3.4, frostGiant: 3.8, fallenAngel: 3.6, abomination: 3.4, theEye: 4.2 };
  B.INTRO_T = INTRO_T;
  const once = (a, k) => { if (a['_' + k]) return false; a['_' + k] = 1; return true; };
  const atT = (a, t) => a.t >= t && once(a, 't' + t);
  function face(b, p) { b.facing = p.x > b.x ? 1 : -1; }
  function rain(G, st, type, n, spread, cx, delayStep = 0.08) {
    for (let i = 0; i < n; i++) {
      const x = cx != null ? cx + (i - (n - 1) / 2) * spread + rnd(-10, 10) : rnd(st.lock[0] + 40, st.lock[1] - 40);
      setTimeout(() => { if (Game.stage() !== st) return; G.hazard({ type: 'mark', x, w: 50, warn: 0.8, active: 0.01, dmg: 0 }); G.fireProj(type, x, -40, x, GY, { vx: 0, vy: 0 }); }, i * delayStep * 1000);
    }
  }
  function summon(st, G, type, n) { for (let i = 0; i < n; i++) { const side = i % 2 ? -1 : 1; const x = side > 0 ? st.lock[1] + 30 : st.lock[0] - 30; G.spawnEnemy(type, x); } AudioSys.play('roar'); }
  function contact(b, st, G, dmg, yTol = 90) { const p = st.p; const by = b.flying ? b.y : b.y - b.h * 0.5; if (Math.abs(p.x - b.x) < b.w * 0.5 + 18 && Math.abs((p.y - 60) - by) < yTol) G.hurtPlayer(dmg, b.x, { kb: 520 }); }

  const ATK = {
    slam(b, a, dt, st, G) { const p = st.p; const dx = p.x - b.x;
      if (a.s === 0) { b.pose = 'walk'; face(b, p); b.x += Math.sign(dx) * b.def.speed * 1.3 * dt; b.phase += dt * 6; if (Math.abs(dx) < 170 || a.t > 1.4) { a.s = 1; a.t0 = a.t; AudioSys.play('growl', 0.7); } }
      else if (a.s === 1) { b.pose = 'windup'; if (a.t - a.t0 > 0.6) { a.s = 2; a.t0 = a.t; b.pose = 'strike'; const ix = b.x + b.facing * b.w; Game.fx.dust(ix, GY, 20, 'rgba(200,180,140,0.6)', 2); Game.fx.debris(ix, GY, '#3a2a1a', 10); AudioSys.play('boom', 1); st.shake = 16; if (Math.abs(p.x - ix) < 190 && p.y > GY - 110) G.hurtPlayer(b.def.dmg * 1.3, b.x); G.fireProj('shock', ix, GY, ix - 1, GY); G.fireProj('shock', ix, GY, ix + 1, GY); if (b.p2) { setTimeout(() => G.fireProj('shock', ix, GY, p.x, GY, { sp: 640 }), 300); } } }
      else { b.pose = 'strike'; if (a.t - a.t0 > 0.7) return true; } },
    charge(b, a, dt, st, G) { const p = st.p;
      if (a.s === 0) { b.pose = 'roar'; face(b, p); if (atT(a, 0.05)) AudioSys.play('roar'); if (a.t > 0.7) { a.s = 1; a.t0 = a.t; } }
      else if (a.s === 1) { b.pose = 'charge'; b.phase += dt * 14; b.x += b.facing * b.def.speed * 4.6 * dt; contact(b, st, G, b.def.dmg); if (Math.random() < 0.5) Game.fx.dust(b.x - b.facing * 30, GY, 1); if (b.x < st.lock[0] + b.w * 0.5 || b.x > st.lock[1] - b.w * 0.5 || a.t - a.t0 > 1.8) { b.x = clamp(b.x, st.lock[0] + b.w * 0.5, st.lock[1] - b.w * 0.5); a.s = 2; a.t0 = a.t; st.shake = 14; AudioSys.play('boom', 0.9); Game.fx.debris(b.x + b.facing * 30, GY - 60, '#555', 10); } }
      else { b.pose = 'hurt'; if (a.t - a.t0 > 0.9) return true; } },
    summon(b, a, dt, st, G) { b.pose = 'roar'; if (atT(a, 0.4)) summon(st, G, b.def.minion, b.p2 ? 3 : 2); return a.t > 1.3; },
    bombs(b, a, dt, st, G) { b.pose = a.t < 0.35 ? 'windup' : 'cast'; const p = st.p; [0.4, 0.6, 0.8].concat(b.p2 ? [1.0, 1.2] : []).forEach(t => { if (atT(a, t)) G.lob('bomb', b.x, b.y - b.h * 0.8, p.x + rnd(-90, 90), rnd(0.8, 1.1)); }); return a.t > 1.5; },
    swoop(b, a, dt, st, G) { const p = st.p;
      if (a.s === 0) { b.x = lerp(b.x, p.x - b.facing * 40, 0.04); b.y = lerp(b.y, GY - 280, 0.06); b.pose = 'idle'; if (a.t > 0.8) { a.s = 1; a.t0 = a.t; const ang = Math.atan2((p.y - 50) - b.y, p.x - b.x); a.vx = Math.cos(ang) * 900; a.vy = Math.sin(ang) * 900; AudioSys.play('screech'); } }
      else if (a.s === 1) { b.x += a.vx * dt; b.y += a.vy * dt; contact(b, st, G, b.def.dmg, 70); if (b.y > GY - 40 || a.t - a.t0 > 1) { a.s = 2; a.t0 = a.t; Game.fx.dust(b.x, GY, 10); } }
      else { b.y = lerp(b.y, b.baseY, 0.05); if (a.t - a.t0 > 0.7) return true; } },
    sonic(b, a, dt, st, G) { const p = st.p; b.pose = 'cast'; b.y = lerp(b.y, GY - 120, 0.05); face(b, p); [0.5, 0.9, 1.3].concat(b.p2 ? [1.7] : []).forEach(t => { if (atT(a, t)) { G.fireProj('sonic', b.x, GY - 46, p.x, GY - 46); AudioSys.play('screech'); } }); return a.t > (b.p2 ? 2.1 : 1.7); },
    bloodrain(b, a, dt, st, G) { b.pose = 'cast'; b.y = lerp(b.y, GY - 300, 0.04); if (atT(a, 0.3)) { AudioSys.play('screech'); rain(G, st, 'drop', b.p2 ? 16 : 11, 0, null, 0.09); } return a.t > 2.0; },
    pounce(b, a, dt, st, G) { const p = st.p;
      if (a.s === 0) { b.pose = 'crouch'; face(b, p); if (a.t > 0.45) { a.s = 1; b.vy = -900; b.vx = (p.x - b.x) / 0.9; b.grounded = false; AudioSys.play('growl', 0.8, 0.5); } }
      else if (a.s === 1) { b.pose = 'leap'; contact(b, st, G, b.def.dmg); if (b.grounded) { a.s = 2; a.t0 = a.t; b.vx = 0; st.shake = 12; AudioSys.play('boom', 0.8); Game.fx.dust(b.x, GY, 16); if (b.p2) { G.fireProj('shock', b.x, GY, b.x - 1, GY); G.fireProj('shock', b.x, GY, b.x + 1, GY); } } }
      else { b.pose = 'idle'; if (a.t - a.t0 > 0.5) return true; } },
    howl(b, a, dt, st, G) { b.pose = 'howl'; if (atT(a, 0.3)) { AudioSys.play('roar'); st.shake = 8; } if (atT(a, 0.6)) summon(st, G, b.def.minion, b.p2 ? 3 : 2); return a.t > 1.4; },
    claws(b, a, dt, st, G) { const p = st.p; const n = b.p2 ? 4 : 3; const k = Math.floor(a.t / 0.42); if (k >= n) return true; if (once(a, 'c' + k)) { face(b, p); b.vx = b.facing * 640; AudioSys.play('swing', 0.6); a.hit = false; } b.pose = (a.t % 0.42) < 0.2 ? 'leap' : 'idle'; b.phase += dt * 10; if (!a.hit && Math.abs(p.x - (b.x + b.facing * 40)) < 90 && p.y > GY - 120) { if (G.hurtPlayer(b.def.dmg * 0.8, b.x)) a.hit = true; } },
    combo(b, a, dt, st, G) { const p = st.p; const n = b.p2 ? 4 : 3; const k = Math.floor(a.t / 0.5); if (k >= n) { b.pose = 'idle'; return a.t > n * 0.5 + 0.3; } const lt = a.t % 0.5;
      if (lt < 0.28) { b.pose = 'windup'; face(b, p); } else { b.pose = 'strike'; if (once(a, 's' + k)) { b.vx = b.facing * 380; AudioSys.play('heavySwing'); if (Math.abs(p.x - (b.x + b.facing * 70)) < 130 && p.y > GY - 150) G.hurtPlayer(b.def.dmg, b.x); Game.fx.sparks(b.x + b.facing * 90, GY - 80, '#5dffd0', 6, b.facing); } } },
    spikes(b, a, dt, st, G) { b.pose = a.t < 0.55 ? 'windup' : 'strike'; if (atT(a, 0.55)) { st.shake = 10; AudioSys.play('boom', 0.7); const n = b.p2 ? 9 : 7; for (let i = 0; i < n; i++) G.hazard({ type: b.key === 'frostGiant' ? 'icespike' : 'spike', col: '#c8d8d0', x: b.x + b.facing * (90 + i * 75), w: 46, warn: 0.32 + i * 0.1, active: 0.45, dmg: b.def.dmg * 0.9, h: 110 }); } return a.t > 1.6; },
    fireballs(b, a, dt, st, G) { const p = st.p; b.pose = a.t < 0.35 ? 'windup' : 'cast'; face(b, p); const vol = (t) => { if (atT(a, t)) { const n = 5; for (let i = 0; i < n; i++) { const ang = Math.atan2(p.y - 70 - (b.y - b.h * 0.75), p.x - b.x) + (i - 2) * 0.16; G.fireProj('fireball', b.x + b.facing * 30, b.y - b.h * 0.75, b.x + Math.cos(ang) * 100 + b.facing * 30, b.y - b.h * 0.75 + Math.sin(ang) * 100); } } }; vol(0.4); if (b.p2) vol(0.9); return a.t > (b.p2 ? 1.4 : 1.0); },
    meteor(b, a, dt, st, G) { b.pose = 'cast'; if (atT(a, 0.3)) { AudioSys.play('roar'); st.shake = 6; } if (atT(a, 0.5)) rain(G, st, 'meteor', b.p2 ? 10 : 7, 0, null, 0.14); return a.t > 2.0; },
    breath(b, a, dt, st, G) { const p = st.p; if (a.t < 0.55) { b.pose = 'windup'; face(b, p); return false; } b.pose = 'strike'; if (atT(a, 0.55)) AudioSys.play('fire');
      const hx = b.x + b.facing * b.w * 0.4, hy = b.y - b.h * 0.8; for (let i = 0; i < 4; i++) Game.fx && st.parts.push({ x: hx, y: hy, vx: b.facing * rnd(380, 620), vy: rnd(40, 200), g: 0, r: rnd(6, 14), col: Math.random() < 0.5 ? '#ff7a1a' : '#ffd040', life: 0.55, type: 'glow', t: 0, rot: 0, vr: 0 });
      const dx = (p.x - b.x) * b.facing; if (dx > 0 && dx < 340 && p.y > GY - 170) G.hurtPlayer(b.def.dmg * 0.6, b.x, { kb: 300 }); if (Math.random() < 0.1) AudioSys.play('fire'); return a.t > 1.7; },
    leap(b, a, dt, st, G) { const p = st.p;
      if (a.s === 0) { b.pose = 'crouch'; face(b, p); if (a.t > 0.5) { a.s = 1; b.vy = -1000; b.vx = (p.x - b.x) / 1.0; b.grounded = false; AudioSys.play('roar'); } }
      else if (a.s === 1) { b.pose = 'jump'; if (b.grounded) { a.s = 2; a.t0 = a.t; b.vx = 0; st.shake = 20; AudioSys.play('boom', 1.3); Game.fx.dust(b.x, GY, 24, 'rgba(255,140,60,0.5)', 2); if (Math.abs(p.x - b.x) < 160) G.hurtPlayer(b.def.dmg * 1.3, b.x); G.fireProj('shock', b.x, GY, b.x - 1, GY); G.fireProj('shock', b.x, GY, b.x + 1, GY); } }
      else { b.pose = 'strike'; if (a.t - a.t0 > 0.7) return true; } },
    tentacle(b, a, dt, st, G) { const p = st.p; b.open = 0.4; const n = b.p2 ? 5 : 3; for (let i = 0; i < n; i++) if (atT(a, 0.2 + i * 0.55)) G.hazard({ type: 'tentacle', x: p.x + rnd(-20, 20), w: 60, warn: 0.6, active: 0.65, dmg: b.def.dmg, h: 210, col: '#1c5048' }); return a.t > 0.2 + n * 0.55 + 1.2; },
    ink(b, a, dt, st, G) { const p = st.p; b.open = 1; [0.3, 0.5, 0.7, 0.9].forEach((t, i) => { if (atT(a, t)) { G.lob('ink', b.x - 60, GY - 200, p.x + (i - 1.5) * 80, 1.0); AudioSys.play('wet'); } }); return a.t > 1.6; },
    wave(b, a, dt, st, G) { b.open = 0.7; if (atT(a, 0.2)) AudioSys.play('roar'); if (atT(a, 0.7)) { G.fireProj('wave', b.x - 140, GY, b.x - 2000, GY); AudioSys.play('boom', 0.6); } if (b.p2 && atT(a, 1.5)) G.fireProj('wave', b.x - 140, GY, b.x - 2000, GY, { sp: 480 }); return a.t > (b.p2 ? 2.3 : 1.6); },
    stomp(b, a, dt, st, G) { const p = st.p; if (a.t < 0.7) { b.pose = 'raise'; face(b, p); return false; } b.pose = 'stomp'; if (atT(a, 0.7)) { st.shake = 22; AudioSys.play('boom', 1.4); Game.fx.dust(b.x, GY, 24, 'rgba(230,245,255,0.6)', 2.5); if (Math.abs(p.x - b.x) < 170 && p.y > GY - 100) G.hurtPlayer(b.def.dmg, b.x); G.fireProj('frost', b.x, GY, b.x - 1, GY); G.fireProj('frost', b.x, GY, b.x + 1, GY); rain(G, st, 'iceshard', 3, 90, p.x, 0.1); } return a.t > 1.5; },
    icerain(b, a, dt, st, G) { b.pose = 'cast'; if (atT(a, 0.4)) { AudioSys.play('ice'); rain(G, st, 'iceshard', b.p2 ? 14 : 10, 0, null, 0.09); } return a.t > 2.0; },
    boulder(b, a, dt, st, G) { const p = st.p; b.pose = a.t < 0.6 ? 'raise' : 'strike'; face(b, p); if (atT(a, 0.6)) { G.lob('boulder', b.x + b.facing * 40, b.y - b.h * 0.9, p.x, 1.0); AudioSys.play('heavySwing'); } return a.t > 1.6; },
    freeze(b, a, dt, st, G) { const p = st.p; b.pose = a.t < 0.5 ? 'windup' : 'strike'; face(b, p); if (atT(a, 0.5)) { G.fireProj('frost', b.x, GY, p.x, GY, { sp: 520 }); AudioSys.play('ice'); } if (b.p2 && atT(a, 1.1)) G.fireProj('frost', b.x, GY, p.x, GY, { sp: 620 }); return a.t > 1.5; },
    spearrain(b, a, dt, st, G) { const p = st.p; b.pose = 'cast'; b.y = lerp(b.y, GY - 260, 0.05); if (atT(a, 0.4)) { AudioSys.play('shing'); rain(G, st, 'spear', b.p2 ? 9 : 7, 72, p.x, 0.07); } return a.t > 1.9; },
    dash(b, a, dt, st, G) { const p = st.p;
      if (a.s === 0) { b.pose = 'windup'; face(b, p); b.y = lerp(b.y, GY - 72, 0.1); b.x = lerp(b.x, b.x < (st.lock[0] + st.lock[1]) / 2 ? st.lock[0] + 80 : st.lock[1] - 80, 0.05); if (a.t > 0.7) { a.s = 1; a.t0 = a.t; face(b, p); AudioSys.play('heavySwing'); } }
      else if (a.s === 1) { b.pose = 'strike'; b.x += b.facing * 1100 * dt; st.parts.push({ x: b.x, y: b.y - 50, vx: 0, vy: 0, g: 0, r: 30, col: 'rgba(255,240,200,0.5)', life: 0.3, type: 'glow', t: 0, rot: 0, vr: 0 }); const p2 = st.p; if (Math.abs(p2.x - b.x) < 50 && Math.abs((p2.y - 60) - (b.y - 60)) < 60) G.hurtPlayer(b.def.dmg, b.x - b.facing * 50); if (b.x < st.lock[0] + 60 || b.x > st.lock[1] - 60 || a.t - a.t0 > 1.2) { a.s = 2; a.t0 = a.t; } }
      else { b.pose = 'idle'; b.y = lerp(b.y, b.baseY, 0.05); if (a.t - a.t0 > 0.6) return true; } },
    holybeam(b, a, dt, st, G) { const p = st.p; b.pose = 'cast'; const n = b.p2 ? 4 : 3; for (let i = 0; i < n; i++) if (atT(a, 0.3 + i * 0.5)) G.hazard({ type: 'pillar', x: p.x + p.vx * 0.3, w: 80, warn: 0.7, active: 0.5, dmg: b.def.dmg }); return a.t > 0.3 + n * 0.5 + 1.2; },
    feathers(b, a, dt, st, G) { const p = st.p; b.pose = 'cast'; face(b, p); const vol = (t) => { if (atT(a, t)) { for (let i = 0; i < 7; i++) { const ang = Math.atan2(p.y - 60 - (b.y - 60), p.x - b.x) + (i - 3) * 0.12; G.fireProj('feather', b.x, b.y - 60, b.x + Math.cos(ang) * 100, b.y - 60 + Math.sin(ang) * 100); } } }; vol(0.4); if (b.p2) vol(0.9); return a.t > 1.3; },
    acid(b, a, dt, st, G) { const p = st.p; b.open = 1; [0.3, 0.5, 0.7, 0.9].concat(b.p2 ? [1.1, 1.3] : []).forEach((t, i) => { if (atT(a, t)) { G.lob('acid', b.x, b.y - b.h * 1.2, p.x + rnd(-120, 120), 0.9); AudioSys.play('wet'); } }); return a.t > 1.7; },
    sweep(b, a, dt, st, G) { const p = st.p; face(b, p); b.open = 0.5; if (atT(a, 0.1)) { AudioSys.play('growl', 0.5, 0.8); G.beam({ x0: b.x, x1: b.x + b.facing * 900, y: GY - 26, thick: 30, warn: 0.75, active: 0.35, dmg: b.def.dmg, col: '#c0102a' }); } b.sweepK = clamp((a.t - 0.85) / 0.35, 0, 1); return a.t > 1.5; },
    roll(b, a, dt, st, G) { const p = st.p;
      if (a.s === 0) { face(b, p); b.squash = 0.25; if (a.t > 0.6) { a.s = 1; a.t0 = a.t; AudioSys.play('wet'); } }
      else if (a.s === 1) { b.squash = 0; b.rollRot = (b.rollRot || 0) + b.facing * dt * 8; b.x += b.facing * 620 * dt; contact(b, st, G, b.def.dmg); if (b.x < st.lock[0] + b.w * 0.5 || b.x > st.lock[1] - b.w * 0.5 || a.t - a.t0 > 2) { b.x = clamp(b.x, st.lock[0] + b.w * 0.5, st.lock[1] - b.w * 0.5); a.s = 2; a.t0 = a.t; st.shake = 14; AudioSys.play('boom', 0.8); } }
      else { b.rollRot = lerp(b.rollRot || 0, 0, 0.1); if (a.t - a.t0 > 0.7) { b.rollRot = 0; return true; } } },
    laser(b, a, dt, st, G) { const p = st.p; b.pupilT = 0.15; face(b, p); if (atT(a, 0.1)) { const dir = p.x > b.x ? 1 : -1; G.beam({ x0: b.x, x1: b.x + dir * 1600, y: GY - 48, thick: 34, warn: 0.85, active: 0.45, dmg: b.def.dmg, col: '#ff1a1a' }); AudioSys.play('zap'); }
      if (b.p2 && atT(a, 1.4)) { const dir = p.x > b.x ? 1 : -1; G.beam({ x0: b.x, x1: b.x + dir * 1600, y: GY - 175, thick: 40, warn: 0.7, active: 0.45, dmg: b.def.dmg, col: '#ffffff' }); }
      return a.t > (b.p2 ? 2.7 : 1.6); },
    stare(b, a, dt, st, G) { const p = st.p; if (atT(a, 0.01)) { st.stare = { t: 0, dur: 2.2 }; AudioSys.play('message'); AudioSys.play('heartbeat', 1); } if (st.stare) st.stare.t = a.t; b.pupilT = 0.6;
      if (atT(a, 1.1)) AudioSys.play('heartbeat', 1.2);
      if (atT(a, 2.2)) { const looking = (p.facing === (b.x > p.x ? 1 : -1)); st.stare = null; if (looking) { st.distort = 0.8; setTimeout(() => { const s = Game.stage(); if (s) s.distort = 0; }, 700); G.hurtPlayer(b.def.dmg * 1.3, b.x, { kb: 200 }); AudioSys.play('glitch', 0.6); Game.fx.txt(p.x, p.y - 190, 'YOU LOOKED', '#ff2a2a', 22, 1.4); } else { Game.fx.txt(p.x, p.y - 190, 'good.', '#ffffff', 22, 1.4); G.onEvent && G.onEvent('stare'); } }
      return a.t > 2.6; },
    glitchwave(b, a, dt, st, G) { const p = st.p; if (atT(a, 0.1)) { AudioSys.play('glitch', 0.6); for (let i = 0; i < 6; i++) G.glitchFX(b.x + rnd(-80, 80), b.y + rnd(-80, 80)); st.distort = 0.5; }
      if (atT(a, 0.4)) { st.distort = 0; const L = st.lock; b.x = b.x > (L[0] + L[1]) / 2 ? L[0] + 140 : L[1] - 140; for (let i = 0; i < 6; i++) G.glitchFX(b.x + rnd(-80, 80), b.y + rnd(-80, 80)); }
      if (atT(a, 0.7)) { G.fireProj('glitchwave', b.x, GY, p.x, GY); } if (b.p2 && atT(a, 1.1)) G.fireProj('glitchwave', b.x, GY, p.x, GY, { sp: 640 });
      [0.9, 1.1, 1.3].forEach(t => { if (atT(a, t)) G.fireProj('eyebolt', b.x, b.y, p.x, p.y - 60); }); return a.t > 1.8; },
  };
  // ---- phase III signature attacks ----
  ATK.rampage = (b, a, dt, st, G) => { const p = st.p; const k = Math.floor(a.t / 1.25); if (k >= 3) { b.pose = 'hurt'; return a.t > 3 * 1.25 + 0.6; } const lt = a.t - k * 1.25;
    if (lt < 0.35) { b.pose = 'roar'; face(b, p); if (once(a, 'r' + k)) { AudioSys.play('roar'); st.shake = 8; } }
    else { b.pose = 'charge'; b.phase += dt * 16; b.x += b.facing * b.def.speed * 6 * dt; contact(b, st, G, b.def.dmg); if (Math.random() < dt * 6) G.lob('bomb', b.x, b.y - b.h * 0.8, b.x - b.facing * rnd(40, 160), 0.6); if (b.x <= st.lock[0] + b.w * 0.5 + 4 || b.x >= st.lock[1] - b.w * 0.5 - 4) { if (once(a, 'w' + k)) { st.shake = 16; AudioSys.play('boom', 0.9); Game.fx.debris(b.x, GY - 60, '#3a2a1a', 14); } } } };
  ATK.eclipse = (b, a, dt, st, G) => { const p = st.p; st.lightsOut = Math.max(st.lightsOut || 0, a.t < 3.6 ? 1 : 0); if (atT(a, 0.05)) { AudioSys.play('screech'); AudioSys.play('stinger'); }
    const k = Math.floor((a.t - 0.6) / 0.85); if (a.t < 0.6) { b.y = lerp(b.y, GY - 320, 0.05); b.pose = 'idle'; return false; } if (k >= 3) { b.y = lerp(b.y, b.baseY, 0.05); if (atT(a, 3.2)) rain(G, st, 'drop', 12, 0, null, 0.07); return a.t > 4.2; }
    const lt = a.t - 0.6 - k * 0.85; if (lt < 0.3) { b.x = lerp(b.x, p.x + (k % 2 ? 1 : -1) * 320, 0.2); b.y = lerp(b.y, GY - 300, 0.2); if (once(a, 'e' + k)) { const ang = Math.atan2((p.y - 50) - (GY - 300), p.x - b.x); a.vx = Math.cos(ang) * 1300; a.vy = Math.sin(ang) * 1300; AudioSys.play('screech'); } } else { b.x += a.vx * dt; b.y = Math.min(GY - 40, b.y + a.vy * dt); contact(b, st, G, b.def.dmg, 70); } };
  ATK.shadowwolves = (b, a, dt, st, G) => { b.pose = 'howl'; if (atT(a, 0.2)) { AudioSys.play('roar'); st.shake = 10; st.lightsOut = 0.6; }
    if (atT(a, 0.7)) for (let i = 0; i < 3; i++) { const side = i % 2 ? -1 : 1; const w = G.spawnEnemy('wolf', side > 0 ? st.lock[1] + 30 : st.lock[0] - 30); w.shadow = true; w.hp = w.maxHp = w.maxHp * 0.5; }
    return a.t > 1.6; };
  ATK.gravefield = (b, a, dt, st, G) => { b.pose = a.t < 0.6 ? 'windup' : 'strike'; if (atT(a, 0.6)) { st.shake = 14; AudioSys.play('boom', 0.9); const L = st.lock; const gap = Math.floor(rnd(1, 6)); for (let w = 0; w < 2; w++) for (let i = 0; i < 10; i++) { if (w === 0 && (i === gap || i === gap + 1)) continue; if (w === 1 && (i === 9 - gap || i === 8 - gap)) continue; G.hazard({ type: 'spike', x: L[0] + 60 + i * (L[1] - L[0] - 120) / 9, w: 52, warn: 0.6 + w * 1.1, active: 0.5, dmg: b.def.dmg * 0.9, h: 120 }); } } return a.t > 3.0; };
  ATK.inferno = (b, a, dt, st, G) => { b.pose = 'cast'; b.y = Math.min(b.y, GY); if (atT(a, 0.2)) { AudioSys.play('roar'); st.shake = 10; } if (atT(a, 0.5)) rain(G, st, 'meteor', 14, 0, null, 0.1); if (atT(a, 1.0)) { const L = st.lock; for (let i = 0; i < 4; i++) G.hazard({ type: 'acid', col: '#ff5a1a', fire: true, x: rnd(L[0] + 80, L[1] - 80), w: 110, warn: 0.4, active: 3, dmg: 8 }); } return a.t > 3.0; };
  ATK.maelstrom = (b, a, dt, st, G) => { const p = st.p; b.open = 1; if (atT(a, 0.1)) { AudioSys.play('roar'); st.shake = 12; } if (atT(a, 0.6)) G.fireProj('wave', b.x - 140, GY, b.x - 2000, GY, { sp: 420 }); if (atT(a, 1.6)) G.fireProj('wave', st.lock[0] - 40, GY, st.lock[1] + 2000, GY, { sp: 420 }); for (let i = 0; i < 4; i++) if (atT(a, 0.4 + i * 0.6)) G.hazard({ type: 'tentacle', x: p.x + rnd(-30, 30), w: 60, warn: 0.55, active: 0.6, dmg: b.def.dmg, h: 210, col: '#1c5048' }); return a.t > 3.2; };
  ATK.avalanche = (b, a, dt, st, G) => { const p = st.p; b.pose = a.t < 0.6 ? 'raise' : 'stomp'; if (atT(a, 0.6)) { st.shake = 24; AudioSys.play('boom', 1.4); AudioSys.play('collapse'); } for (let i = 0; i < 6; i++) if (atT(a, 0.8 + i * 0.3)) { const x = p.x + rnd(-240, 240); G.hazard({ type: 'mark', x, w: 70, warn: 0.9, active: 0.01, dmg: 0 }); G.fireProj('iceshard', x, -60, x, GY, { vx: 0, vy: 200, r: 18, dmg: b.def.dmg }); } return a.t > 3.0; };
  ATK.judgement = (b, a, dt, st, G) => { b.pose = 'cast'; b.y = lerp(b.y, GY - 300, 0.05); if (atT(a, 0.2)) { AudioSys.play('holy'); st.flash = 0.3; } const L = st.lock;
    if (atT(a, 0.4)) G.beam({ x0: L[0], x1: L[1], y: GY - 30, thick: 36, warn: 0.9, active: 0.35, dmg: b.def.dmg, col: '#fff2b0' });
    if (atT(a, 1.6)) G.beam({ x0: L[0], x1: L[1], y: GY - 150, thick: 50, warn: 0.9, active: 0.35, dmg: b.def.dmg, col: '#fff2b0' });
    if (atT(a, 2.6)) rain(G, st, 'spear', 9, 80, st.p.x, 0.06); return a.t > 3.4; };
  ATK.devour = (b, a, dt, st, G) => { const p = st.p; face(b, p); b.open = 1; if (atT(a, 0.05)) { AudioSys.play('growl', 0.4, 1); AudioSys.play('wet'); }
    if (a.t < 2.0) { const dx = b.x - p.x; if (!p.dead && Math.abs(dx) < 900) p.x += Math.sign(dx) * (180 + a.t * 120) * dt; if (Math.random() < 0.5) st.parts.push({ x: p.x + rnd(-200, 200), y: GY - rnd(10, 200), vx: Math.sign(dx) * 500, vy: 0, g: 0, r: rnd(2, 5), col: 'rgba(200,60,80,0.6)', life: 0.4, type: 'dust', t: 0, rot: 0, vr: 0 }); }
    if (atT(a, 2.0)) { st.shake = 18; AudioSys.play('crunch', 0.5); if (Math.abs(p.x - b.x) < b.w * 0.6 + 70) G.hurtPlayer(b.def.dmg * 1.6, b.x, { kb: 700 }); Game.fx.blood(b.x + b.facing * b.w * 0.4, b.y - b.h * 0.5, '#c0102a', 40, b.facing, 1.5); }
    return a.t > 2.6; };
  ATK.blinklasers = (b, a, dt, st, G) => { const p = st.p; const L = st.lock; for (let i = 0; i < 3; i++) { if (atT(a, i * 0.9)) { for (let j = 0; j < 6; j++) G.glitchFX(b.x + rnd(-80, 80), b.y + rnd(-80, 80)); b.x = rnd(L[0] + 140, L[1] - 140); b.y = GY - rnd(160, 260); AudioSys.play('glitch', 0.4); for (let j = 0; j < 6; j++) G.glitchFX(b.x + rnd(-80, 80), b.y + rnd(-80, 80)); }
      if (atT(a, i * 0.9 + 0.15)) { const dir = p.x > b.x ? 1 : -1; G.beam({ x0: b.x, x1: b.x + dir * 1600, y: i === 1 ? GY - 160 : GY - 46, thick: 34, warn: 0.6, active: 0.3, dmg: b.def.dmg, col: i === 1 ? '#ffffff' : '#ff1a1a' }); } }
    b.pupilT = 0.15; return a.t > 3.1; };
  const SIG = { goblinKing: 'rampage', vampireBat: 'eclipse', bigWolf: 'shadowwolves', undeadKnight: 'gravefield', fireDemon: 'inferno', seaMonster: 'maelstrom', frostGiant: 'avalanche', fallenAngel: 'judgement', abomination: 'devour', theEye: 'blinklasers' };
  B.SIG = SIG;
  ATK.summon_eye = ATK.summon;

  // ---- cinematic introductions (the camera locks, input is held, a name card appears at the end) ----
  function intro(b, dt, st, G) {
    const t = b.introT, k = b.key, p = st.p, d = b.def; b.pose = 'idle';
    const at = (tt) => t >= tt && once(b, 'in' + tt);
    switch (k) {
      case 'goblinKing': if (at(0)) { b.y = GY - 900; b.vy = 0; AudioSys.play('riser'); } if (t > 0.7) { if (b.y < GY) { b.vy += 3600 * dt; b.y = Math.min(GY, b.y + b.vy * dt); b.pose = 'jump'; } else if (once(b, 'land')) { st.shake = 26; AudioSys.play('boom', 1.4); AudioSys.play('bossStep', 0.6); Game.fx.dust(b.x, GY, 30, 'rgba(200,180,140,0.7)', 3); Game.fx.debris(b.x, GY, '#3a2a1a', 20, 1.6); Game.fx.ring(b.x, GY - 20, '#fff', 260, 0.4); } } else b.y = GY - 900; if (t > 1.8) b.pose = 'roar'; if (at(1.9)) AudioSys.play('roar'); break;
      case 'vampireBat': if (at(0)) AudioSys.play('wings', 0.8); b.alphaK = clamp((t - 1.4) / 0.8, 0, 1); if (t < 2) for (let i = 0; i < 3; i++) { const ang = rnd(0, 6.28), r = rnd(300, 600); st.parts.push({ x: b.x + Math.cos(ang) * r, y: b.y + Math.sin(ang) * r * 0.5, vx: -Math.cos(ang) * r * 1.6, vy: -Math.sin(ang) * r * 0.8, g: 0, r: rnd(4, 8), col: '#1a0f20', life: 0.6, type: 'bat', t: 0, rot: 0, vr: 0 }); } if (at(1.6)) { AudioSys.play('screech'); st.shake = 10; } if (t > 2) b.pose = 'cast'; break;
      case 'bigWolf': b.alphaK = t < 1.5 ? 0 : 1; st.lightsOut = t < 1.5 ? 1 : 0; b.eyesOnly = t < 1.5; if (at(0.4)) AudioSys.play('growl', 0.5, 1.2); if (at(1.5)) { b.x = st.lock[1] + 100; b.vy = -900; b.vx = -((st.lock[1] + 100) - (st.lock[0] + st.lock[1]) / 2 - 140) / 0.9; b.grounded = false; AudioSys.play('roar'); } if (t > 1.5 && !b.grounded) b.pose = 'leap'; if (t > 1.5 && b.grounded && once(b, 'land')) { b.vx = 0; st.shake = 18; AudioSys.play('boom'); Game.fx.dust(b.x, GY, 20); } if (t > 2.3) b.pose = 'howl'; if (at(2.4)) AudioSys.play('roar'); break;
      case 'undeadKnight': b.riseK = 1 - clamp((t - 0.5) / 1.8, 0, 1); if (at(0.3)) { AudioSys.play('crunch'); AudioSys.play('riser'); st.shake = 6; } if (t > 0.5 && t < 2.3 && Math.random() < 0.6) Game.fx.debris(b.x + rnd(-60, 60), GY, '#3a3a38', 1, 0.6); if (t > 2.3) b.pose = 'roar'; if (at(2.4)) { AudioSys.play('metal', 0.5); AudioSys.play('roar'); st.shake = 10; } break;
      case 'fireDemon': b.alphaK = t < 1.2 ? 0 : 1; if (at(0.2)) { const m = G.fireProj('meteor', b.x - 200, -80, b.x, GY, { vx: 200, vy: 900, dmg: 0 }); m.dmg = 0; m.intro = true; } if (at(1.2)) { st.shake = 26; st.flash = 0.7; AudioSys.play('boom', 1.5); AudioSys.play('fire'); Game.fx.ring(b.x, GY - 40, '#ff7a1a', 300, 0.5); for (let i = 0; i < 40; i++) st.parts.push({ x: b.x + rnd(-40, 40), y: GY - rnd(0, 80), vx: rnd(-300, 300), vy: rnd(-700, -200), g: 600, r: rnd(3, 9), col: Math.random() < 0.5 ? '#ff7a1a' : '#ffd040', life: 1, type: 'glow', t: 0, rot: 0, vr: 0 }); } if (t > 1.3) b.pose = 'roar'; break;
      case 'seaMonster': if (at(0)) { b.rise = 420; AudioSys.play('splash'); } b.rise = lerp(b.rise, t > 0.8 ? 0 : 420, 0.03); if (at(0.9)) { AudioSys.play('splash'); st.shake = 14; } if (t > 0.9 && Math.random() < 0.5) st.parts.push({ x: b.x + rnd(-200, 200), y: GY, vx: rnd(-80, 80), vy: rnd(-500, -200), g: 1200, r: rnd(3, 7), col: 'rgba(160,240,230,0.7)', life: 0.8, type: 'dot', t: 0, rot: 0, vr: 0 }); b.open = t > 2.4 ? 1 : 0.2; if (at(2.4)) AudioSys.play('roar'); break;
      case 'frostGiant': if (at(0)) { b.x = st.lock[1] + 220; b.tx = st.lock[1] - 220; } for (let i = 0; i < 4; i++) if (at(0.4 + i * 0.6)) { st.shake = 14 + i * 3; AudioSys.play('bossStep', 0.5); Game.fx.dust(b.x, GY, 14, 'rgba(230,245,255,0.6)', 2); } if (t < 2.8) { b.x = lerp(b.x, b.tx, dt * 1.2); b.pose = 'walk'; b.phase += dt * 3.2; } else b.pose = 'roar'; if (at(2.9)) AudioSys.play('roar'); break;
      case 'fallenAngel': if (at(0)) { b.y = GY - 700; AudioSys.play('holy'); } b.pillar = t < 2.6 ? clamp(t / 0.4, 0, 1) : clamp(1 - (t - 2.6) / 0.6, 0, 1); b.y = lerp(b.y, b.baseY, t > 0.6 ? 0.03 : 0); if (at(2.2)) { AudioSys.play('wings'); st.flash = 0.4; for (let i = 0; i < 30; i++) st.parts.push({ x: b.x + rnd(-60, 60), y: b.y - rnd(0, 120), vx: rnd(-200, 200), vy: rnd(-200, 100), g: 60, r: rnd(3, 6), col: '#fff6d0', life: 2, type: 'feather', t: 0, rot: rnd(0, 6), vr: rnd(-4, 4) }); } b.pose = t > 2.2 ? 'cast' : 'idle'; break;
      case 'abomination': b.growK = clamp((t - 0.4) / 2.2, 0, 1); if (at(0.1)) AudioSys.play('wet'); if (Math.random() < 0.3 && t < 2.6) Game.fx.blood(b.x + rnd(-80, 80), GY - rnd(0, 60) * b.growK, '#c0102a', 2, rnd(-1, 1)); if (at(1.2)) AudioSys.play('gore'); if (at(2.6)) { AudioSys.play('growl', 0.4, 1.2); st.shake = 14; } b.open = t > 2.6 ? 1 : 0.2; break;
      case 'theEye': st.lightsOut = t < 3.2 ? 1 : 0; b.lid = t < 1.6 ? 0 : clamp((t - 1.6) / 1.4, 0, 1); b.pupilT = t < 2.8 ? 0.7 : 0.38; if (at(0.3)) AudioSys.play('heartbeat', 0.8); if (at(1.0)) AudioSys.play('heartbeat', 1); if (at(1.6)) AudioSys.play('eyeSquelch'); if (at(3.0)) { AudioSys.play('glitch', 0.7); st.flash = 0.5; } break;
    }
  }
  B.intro = intro;

  B.update = (b, dt, st, G) => {
    const p = st.p; const d = b.def; b.T += dt;
    if (b.flash > 0) b.flash -= dt;
    if (b.dead) { b.deathT += dt; if (b.def.kind === 'sea') b.rise = (b.rise || 0) + dt * 120; if (Math.random() < 0.3) Game.fx.blood(b.x + rnd(-b.w / 2, b.w / 2), (b.flying ? b.y : b.y - b.h * 0.5), d.blood, 3, rnd(-1, 1)); return; }
    // three phases: 66% and 33%. Each transition is a short invulnerable set-piece.
    const want = b.hp < b.maxHp * 0.33 ? 3 : b.hp < b.maxHp * 0.66 ? 2 : 1;
    if (want > b.phaseN && b.intro <= 0) {
      b.phaseN = want; b.phaseT = 2.2; b.atk = null; b.broken = 0; b.p2 = true; if (want >= 3) b.p3 = true;
      AudioSys.play('phaseShift'); AudioSys.play('roar'); st.shake = 18; st.flash = 0.5; st.zoomT = 1.12; st.zoomX = b.x; st.zoomY = (b.flying ? b.y : b.y - b.h * 0.5);
      const txts = { 2: d.kind === 'eye' ? 'IT IS ANGRY NOW' : 'PHASE II', 3: d.kind === 'eye' ? 'IT SEES EVERYTHING' : 'PHASE III' };
      st.banner = { text: txts[want], sub: want === 3 ? 'ITS TRUE FORM' : 'ENRAGED', t: 2, small: true };
      Game.fx.ring(b.x, b.flying ? b.y : b.y - b.h * 0.5, want === 3 ? '#ff2020' : '#ffffff', 420, 0.6);
      const dir = Math.sign(p.x - b.x) || 1; if (Math.abs(p.x - b.x) < 360 && !p.dead) { p.vx = dir * 900; p.vy = -420; p.grounded = false; }
      if (d.kind === 'eye') AudioSys.play('glitch', 0.8);
      Game.onEvent && Game.onEvent('bossphase', want);
    }
    b.p2 = b.phaseN >= 2; b.p3 = b.phaseN >= 3;
    if (b.phaseT > 0) { b.phaseT -= dt; b.pose = 'roar'; b.open = 1; b.pupilT = 0.7; if (b.flying) b.y = lerp(b.y, b.baseY, 0.05); if (Math.random() < 0.5) st.parts.push({ x: b.x + rnd(-b.w, b.w), y: (b.flying ? b.y : b.y - b.h * 0.5) + rnd(-b.h * 0.6, b.h * 0.6), vx: 0, vy: -rnd(60, 200), g: 0, r: rnd(2, 5), col: b.p3 ? '#ff2020' : '#ffffff', life: 0.6, type: 'glow', t: 0, rot: 0, vr: 0 }); if (b.phaseT <= 0) st.zoomT = 1; return; }
    // broken: stunned, open to a brutal execution
    if (b.broken > 0) { b.broken -= dt; b.atk = null; b.pose = 'hurt'; b.open = 0.3; if (b.flying) b.y = lerp(b.y, Math.min(GY - b.h * 0.3, GY - 60), 0.05); if (b.broken <= 0) { b.cd = 0.4; } return; }
    if (d.style && d.style.flames && Math.random() < 0.7) st.parts.push({ x: b.x + rnd(-b.w * 0.4, b.w * 0.4), y: b.y - rnd(0, b.h), vx: rnd(-20, 20), vy: rnd(-140, -60), g: 0, r: rnd(3, 8), col: Math.random() < 0.5 ? '#ff7a1a' : '#ffd040', life: 0.6, type: 'glow', t: 0, rot: 0, vr: 0 });
    // physics
    if (!b.flying && d.kind !== 'sea') { b.vy += 2000 * dt; b.y += b.vy * dt; if (b.y >= GY) { b.y = GY; b.vy = 0; b.grounded = true; } else b.grounded = false; b.x += b.vx * dt; b.vx *= Math.pow(0.02, dt); }
    if (d.kind === 'sea') { b.rise = lerp(b.rise, 0, 0.02); }
    if (d.kind === 'eye') { b.lid = lerp(b.lid, st.eyekill ? 1 : 1, 0.05); }
    // intro
    if (b.intro > 0) { b.intro -= dt; b.introT += dt; intro(b, dt, st, G); if (b.intro <= 0) { b.alphaK = 1; b.riseK = 0; b.growK = 1; b.eyesOnly = false; b.pillar = 0; st.lightsOut = 0; if (d.kind === 'eye') b.lid = 1; if (b.flying && b.key !== 'theEye') b.y = Math.min(b.y, b.baseY); } return; }
    if (st.eyekill && d.kind === 'eye') { // finishing attack
      const t = st.eyekill.t; b.x = lerp(b.x, p.x + (b.x > p.x ? 160 : -160), 0.05); b.y = lerp(b.y, GY - 150, 0.05); b.pupilT = 0.7; b.scaleK = 1 + t * 0.15;
      if (t > 0.4 && once(b, 'fin')) { G.beam({ x0: b.x, x1: p.x + (p.x - b.x) * 3, y: p.y - 40, thick: 60, warn: 0.1, active: 1.4, dmg: 0, col: '#ff0000' }); AudioSys.play('beam'); st.shake = 18; }
      return;
    }
    if (!b.atk) {
      b.cd -= dt; const dx = p.x - b.x;
      // idle movement
      if (d.kind === 'humanoid' && !b.flying) { face(b, p); if (Math.abs(dx) > 200) { const ph0 = b.phase; b.x += Math.sign(dx) * d.speed * (b.p3 ? 1.3 : 1) * dt; b.pose = 'walk'; b.phase += dt * 5; if (Math.floor(ph0 / Math.PI) !== Math.floor(b.phase / Math.PI)) { Game.sfx('bossStep', b.x, d.scale > 2.4 ? 0.6 : 0.9); if (d.scale > 2.4) st.shake = Math.max(st.shake, 4); Game.fx.dust(b.x, GY, 2); } } else b.pose = 'idle'; }
      else if (b.flying && d.kind !== 'eye') { face(b, p); b.x = lerp(b.x, p.x - Math.sign(dx || 1) * 220, 0.015); b.y = lerp(b.y, b.baseY + Math.sin(b.T * 2) * 30, 0.04); b.pose = 'idle'; }
      else if (d.kind === 'quad') { face(b, p); if (Math.abs(dx) > 260) { b.x += Math.sign(dx) * d.speed * 0.6 * dt; b.phase += dt * 10; b.moving = true; } else if (Math.abs(dx) < 140) { b.x -= Math.sign(dx) * d.speed * 0.4 * dt; b.phase += dt * 8; b.moving = true; } else b.moving = false; b.pose = 'idle'; }
      else if (d.kind === 'blob') { face(b, p); if (Math.abs(dx) > 220) b.x += Math.sign(dx) * d.speed * dt; }
      else if (d.kind === 'eye') { b.y = lerp(b.y, b.baseY + Math.sin(b.T * 1.3) * 40, 0.03); b.x = lerp(b.x, clamp(p.x + Math.sin(b.T * 0.4) * 260 + (b.x > p.x ? 200 : -200), st.lock[0] + 120, st.lock[1] - 120), 0.01); b.pupilT = 0.38; }
      if (b.flying || d.kind === 'eye') contact(b, st, G, d.dmg * 0.6, 70);
      if (b.cd <= 0) {
        let opts = d.attacks.concat(b.p3 ? [SIG[b.key], SIG[b.key]] : []).filter(x => x !== b.last); if (st.enemies.filter(e => !e.dead && !e.boss).length >= 4) opts = opts.filter(x => x !== 'summon' && x !== 'howl');
        const name = opts[Math.floor(Math.random() * opts.length)]; b.last = name; b.atk = { name, t: 0, s: 0 };
      }
    } else {
      const a = b.atk; a.t += dt;
      const done = ATK[a.name](b, a, dt, st, G);
      if (done) { b.atk = null; b.cd = (b.p3 ? 0.4 : b.p2 ? 0.6 : 1.0) * rnd(0.8, 1.3) * (st.nm ? 0.75 : 1); st.lightsOut = 0; b.open = 0; b.squash = 0; b.sweepK = 0; }
    }
    if (st.lock && d.kind !== 'sea') { const m = Game.portrait ? 40 : 110; b.x = clamp(b.x, st.lock[0] + m, st.lock[1] - m); }
    if (b.flying) b.y = Math.min(b.y, GY - 30);
    if (Math.random() < dt * 0.25) AudioSys.play('growl', 0.6 / (d.voice || 1), 0.7);
  };

  function bossPose(b) {
    const T = b.T; const br = Math.sin(T * 2);
    const walk = (ph) => { const s = Math.sin(ph), c = Math.sin(ph + Math.PI); return { l1t: 26 * s, l1s: 26 * s - 28 * Math.max(0, Math.sin(ph - 1.3)), l2t: 26 * c, l2s: 26 * c - 28 * Math.max(0, Math.sin(ph - 1.3 + Math.PI)) }; };
    const spear = b.def.style.weapon === 'holyspear';
    const M = {
      idle: { t: 10 + br, a1u: 30 + br * 3, a1f: 70, w: spear ? 100 : 80, a2u: -10, a2f: 20 },
      walk: Object.assign({ t: 12, a1u: 20, a1f: 60, w: 70, a2u: -10, a2f: 20 }, walk(b.phase)),
      windup: { t: -10, a1u: 175, a1f: 200, w: 205, a2u: 150, a2f: 180, l1t: 20, l2t: -20, l2s: -10 },
      strike: { t: 26, a1u: 85, a1f: 60, w: 40, a2u: 70, a2f: 50, l1t: 34, l1s: 8, l2t: -30, l2s: -16 },
      cast: { t: -6, a1u: 150 + br * 5, a1f: 165, w: 165, a2u: 140, a2f: 155 },
      roar: { t: -18, h: -25, a1u: 110, a1f: 140, w: 140, a2u: 100, a2f: 130, l1t: 20, l2t: -20 },
      charge: Object.assign({ t: 32, a1u: 60, a1f: 90, w: 90, a2u: -30, a2f: 0 }, walk(b.phase * 1.5)),
      hurt: { t: -20, h: -20, a1u: -20, a1f: 0, w: -30, a2u: 40, a2f: 70 },
      crouch: { t: 20, l1t: 45, l1s: -20, l2t: -10, l2s: -55, a1u: 20, a1f: 40 },
      jump: { t: 0, a1u: 170, a1f: 190, w: 200, a2u: 160, a2f: 180, l1t: 55, l1s: -5, l2t: 5, l2s: -45 },
      raise: { t: -12, a1u: 180, a1f: 190, w: 190, a2u: 175, a2f: 185, l1t: 40, l1s: 10, l2t: -10, l2s: -10 },
      stomp: { t: 28, a1u: 90, a1f: 60, w: 50, a2u: 80, a2f: 50, l1t: 30, l1s: 20, l2t: -30, l2s: -20 },
    };
    const tgt = P(M[b.pose] || M.idle);
    if (b.def.fly) Object.assign(tgt, { l1t: 20, l1s: 0, l2t: -10, l2s: -20 });
    b.cp = lerpPose(b.cp, tgt, 0.18); return b.cp;
  }

  // per-boss death choreography (drawn); spawns are driven by Game's boss death sequence
  B.deathDur = { goblinKing: 3.2, vampireBat: 2.6, bigWolf: 3.4, undeadKnight: 3.6, fireDemon: 3.2, seaMonster: 3.6, frostGiant: 3.2, fallenAngel: 3.6, abomination: 2.8, theEye: 3.8 };
  B.draw = (c, b, st) => {
    const d = b.def, T = b.T; let alpha = 1, rot = 0, yOff = 0; const k = b.key;
    if (b.dead) {
      const dt0 = b.deathT, dur = B.deathDur[k] || 3;
      alpha = 1 - clamp((dt0 - (dur - 0.8)) / 0.8, 0, 1);
      if (k === 'goblinKing' || k === 'undeadKnight' || k === 'fallenAngel') rot = -clamp((dt0 - 0.6) / 1.2, 0, 1) * 1.45;
      if (k === 'vampireBat') alpha = 1 - clamp((dt0 - 0.4) / 1.2, 0, 1);
      if (k === 'bigWolf') alpha = 1 - clamp((dt0 - 1.2) / 1.6, 0, 1);
      if (k === 'frostGiant' && dt0 > 1.3) alpha = 0;
      if (k === 'abomination' && dt0 > 0.9) alpha = 0;
      if (k === 'fireDemon') alpha = 1 - clamp((dt0 - 0.8) / 1.4, 0, 1);
      if (alpha <= 0 && k !== 'seaMonster' && k !== 'theEye') { drawDeathExtras(c, b, st); return; }
    }
    if (b.alphaK != null && b.intro > 0) alpha = Math.min(alpha, b.alphaK);
    if (b.eyesOnly) { const ex = b.x - 20, ey = GY - 90; c.fillStyle = '#ff1010'; c.shadowColor = '#ff0000'; c.shadowBlur = 14; c.globalAlpha = clamp(b.introT / 0.6, 0, 1) * (Math.sin(b.introT * 3) > -0.9 ? 1 : 0); c.beginPath(); c.ellipse(ex, ey, 9, 3, -0.2, 0, 7); c.ellipse(ex + 40, ey, 9, 3, 0.2, 0, 7); c.fill(); c.shadowBlur = 0; c.globalAlpha = 1; return; }
    if (b.pillar > 0) { const pw = 120 * b.pillar; const g = c.createLinearGradient(b.x - pw, 0, b.x + pw, 0); g.addColorStop(0, 'rgba(255,240,200,0)'); g.addColorStop(0.5, `rgba(255,248,220,${0.75 * b.pillar})`); g.addColorStop(1, 'rgba(255,240,200,0)'); c.fillStyle = g; c.fillRect(b.x - pw, -400, pw * 2, GY + 420); }
    const bodyDraw = (shk) => {
    if (d.kind === 'humanoid') {
      const pose = bossPose(b);
      drawHumanoid(c, b.x + shk, b.y, b.facing, d.scale, pose, d.style, { T, enemyWeapon: ['claws', 'fists'].includes(d.style.weapon) ? null : d.style.weapon, rot, grounded: !b.flying, flap: b.pose === 'cast' ? 0.3 : 0 });
    } else if (d.kind === 'quad') {
      drawQuad(c, b.x + shk, b.y, b.facing, d.scale, d.style, { T, phase: b.phase, moving: b.moving || b.pose === 'leap' || (b.atk && b.atk.name === 'charge' && b.atk.s === 1), open: (b.atk ? 1 : 0.3), crouch: b.pose === 'crouch' ? 8 : 0, lunge: b.pose === 'leap' ? 10 : 0, howl: b.pose === 'howl', rot });
      if (b.atk && b.atk.name === 'charge' && b.atk.s === 1) b.phase += 0.3;
    } else if (d.kind === 'flyer') {
      drawFlyer(c, b.x + shk, b.y + (b.dead ? Math.min(b.deathT * b.deathT * 300, GY - b.y - 20) : 0), b.facing, d.scale, d.style, { T, seed: 0, open: b.atk ? 1 : 0.3, rot });
    } else if (d.kind === 'blob') {
      c.save(); if (b.rollRot) { c.translate(b.x, b.y - b.h * 0.5); c.rotate(b.rollRot); c.translate(-b.x, -(b.y - b.h * 0.5)); }
      // sweeping arm
      if (b.sweepK > 0 || (b.atk && b.atk.name === 'sweep')) { const k = b.sweepK || 0; c.strokeStyle = '#7a1a2e'; c.lineWidth = 26; c.lineCap = 'round'; c.beginPath(); c.moveTo(b.x, GY - b.h * 0.6); c.quadraticCurveTo(b.x + b.facing * 200 * (0.3 + k), GY - 120 + k * 80, b.x + b.facing * (120 + k * 700), GY - 26); c.stroke(); c.strokeStyle = 'rgba(255,200,200,0.25)'; c.lineWidth = 5; c.stroke(); }
      drawBlob(c, b.x + shk, b.y, b.facing, d.scale, d.style, { T, open: b.open || 0.4, squash: b.squash || 0, rot });
      c.restore();
      // arms/tentacles on the mass
      for (let i = 0; i < 4; i++) { const ax = b.x + (i - 1.5) * 50, ph = T * 2 + i; c.strokeStyle = '#8a2a3e'; c.lineWidth = 10; c.lineCap = 'round'; c.beginPath(); c.moveTo(ax, b.y - b.h * 0.9); c.quadraticCurveTo(ax + Math.sin(ph) * 50, b.y - b.h * 1.5, ax + Math.cos(ph) * 40, b.y - b.h * 1.8 + Math.sin(ph * 1.4) * 20); c.stroke(); circ(c, ax + Math.cos(ph) * 40, b.y - b.h * 1.8 + Math.sin(ph * 1.4) * 20, 8, '#f0e4d0', '#300', 1.5); circ(c, ax + Math.cos(ph) * 40 + 2, b.y - b.h * 1.8 + Math.sin(ph * 1.4) * 20, 3.5, '#000'); }
    } else if (d.kind === 'sea') {
      drawSeaMonster(c, b.x + shk, GY + 40, d.style, { T, open: b.open || 0.15, rise: b.rise || 0, lookX: clamp((st.p.x - b.x) / 300, -1, 1), blink: Math.sin(T * 0.7) > 0.97 });
      // water surface in front
      c.fillStyle = 'rgba(10,60,64,0.75)'; c.beginPath(); c.moveTo(b.x - 220, GY + 10); for (let x = -220; x <= 260; x += 20) c.lineTo(b.x + x, GY + 4 + Math.sin(T * 3 + x * 0.05) * 5); c.lineTo(b.x + 260, GY + 60); c.lineTo(b.x - 220, GY + 60); c.fill();
    } else if (d.kind === 'eye') {
      const p = st.p; const dx = p.x - b.x, dy = (p.y - 70) - b.y; const dd = Math.hypot(dx, dy) || 1;
      const sc = (b.scaleK || 1) * (b.dead ? (b.deathT < 2.4 ? 1 + b.deathT * 0.1 : Math.max(0.01, 1.24 - (b.deathT - 2.4) * 1.1)) : 1);
      if (b.p2) { for (let i = 0; i < 3; i++) { c.globalAlpha = 0.15; drawEyeBoss(c, b.x + rnd(-14, 14), b.y + rnd(-8, 8), { T, lookX: dx / dd, lookY: dy / dd, lid: 1, pupil: b.pupilT || 0.38, scale: sc }); } c.globalAlpha = alpha; }
      drawEyeBoss(c, b.x + shk, b.y, { T, lookX: dx / dd, lookY: dy / dd, lid: b.dead ? Math.max(0.05, 1 - b.deathT / 1.4) : Math.min(1, (b.lid || 0) + 0.0001) * (Math.sin(T * 0.8) > 0.985 ? 0.1 : 1), pupil: lerp(b.pupilNow || 0.38, b.pupilT || 0.38, 0.1), scale: sc, irisCol: ['#3a0000', '#a00000', '#ff3a1a'] });
      b.pupilNow = lerp(b.pupilNow || 0.38, b.pupilT || 0.38, 0.1);
    }
    };
    c.save(); c.globalAlpha = clamp(alpha, 0, 1);
    const shk = b.dead ? rnd(-3, 3) : (b.phaseT > 0 ? rnd(-4, 4) : 0);
    // knight rising out of his grave: clip at the ground and push him down
    if (b.riseK > 0) { c.beginPath(); c.rect(b.x - 600, -2000, 1200, 2000 + GY + 6); c.clip(); c.translate(0, b.riseK * b.h * 1.05); }
    if (b.growK != null && b.growK < 1) { const gk = 0.08 + 0.92 * b.growK; c.translate(b.x, GY); c.scale(gk, gk); c.translate(-b.x, -GY); }
    bodyDraw(shk);
    // hit flash / phase glow: redraw additively instead of a CSS filter (much cheaper on phones)
    if (b.flash > 0 || b.phaseT > 0 || (b.dead && k === 'frostGiant' && b.deathT > 0.2)) { c.globalCompositeOperation = 'lighter'; c.globalAlpha = clamp(alpha, 0, 1) * (b.flash > 0 ? 0.55 : b.dead ? clamp(b.deathT, 0, 1) * 0.6 : 0.2 + 0.15 * Math.sin(T * 20)); bodyDraw(shk); c.globalCompositeOperation = 'source-over'; }
    c.restore();
    if (b.broken > 0 && !b.dead) { const yy = (b.flying ? b.y - b.h * 0.7 : b.y - b.h - 30); c.save(); c.translate(b.x, yy); for (let i = 0; i < 3; i++) { const ang = T * 4 + i * 2.1; c.fillStyle = '#ffb02a'; c.beginPath(); c.arc(Math.cos(ang) * 26, Math.sin(ang) * 8, 4, 0, 7); c.fill(); } c.restore(); }
    if (b.dead) drawDeathExtras(c, b, st);
    // telegraph
    if (b.atk && !b.dead && b.atk.t < 0.35 && b.intro <= 0) { c.fillStyle = `rgba(255,40,40,${0.7})`; c.font = '900 24px Georgia'; c.textAlign = 'center'; c.fillText('!', b.x, (b.flying ? b.y - b.h * 0.7 : b.y - b.h - 20)); }
  };

  function drawDeathExtras(c, b, st) {
    const t = b.deathT, k = b.key;
    if (k === 'seaMonster') { // sinking whirlpool
      c.save(); c.translate(b.x, GY + 14); for (let i = 0; i < 5; i++) { c.strokeStyle = `rgba(160,240,230,${0.35 - i * 0.05})`; c.lineWidth = 3; c.beginPath(); c.ellipse(0, 0, (60 + i * 50) * Math.min(1, t), (10 + i * 7) * Math.min(1, t), 0, t * (3 - i * 0.4), t * (3 - i * 0.4) + 4.5); c.stroke(); } c.restore();
    }
    if (k === 'undeadKnight' && t > 1.4) { // his sword stays behind, stuck in the ground
      c.save(); c.translate(b.x + b.facing * 40, GY + 6); c.rotate(0.12 * b.facing); c.fillStyle = '#9aa4a8'; c.fillRect(-4, -110, 8, 110); c.fillStyle = '#2a2a30'; c.fillRect(-18, -118, 36, 8); c.fillRect(-4, -146, 8, 28); c.fillStyle = '#5dffd0'; c.globalAlpha = 0.4 + 0.3 * Math.sin(t * 3); c.fillRect(-2, -100, 4, 90); c.restore(); c.globalAlpha = 1;
    }
    if (k === 'theEye') { // cracks spreading across the eye before it implodes
      const n = Math.min(12, Math.floor(t * 5)); c.save(); c.translate(b.x, b.y); c.strokeStyle = '#000'; c.lineWidth = 3; for (let i = 0; i < n; i++) { const a = i * 2.39; c.beginPath(); c.moveTo(0, 0); let x = 0, y = 0; for (let j = 0; j < 5; j++) { x += Math.cos(a + Math.sin(j * 7 + i) * 0.5) * 18; y += Math.sin(a + Math.sin(j * 7 + i) * 0.5) * 18; c.lineTo(x, y); } c.stroke(); } c.restore();
    }
  }
  return B;
})();
