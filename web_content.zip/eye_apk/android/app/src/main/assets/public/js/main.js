// ===== MAIN: screens, loop, controls, events, the fake crash =====
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  let screen = 'gate', loopOn = false, lastT = 0, acc = 0, fpsAcc = 0, fpsN = 0, manual = false, curStage = 0, curOpts = {}, attackHeldT = 0, lastWhisper = -99;
  const STEP = 1 / 60;

  // ---------- helpers ----------
  function show(id) { $$('.screen').forEach(s => s.classList.toggle('on', s.id === id)); screen = id; }
  function ach(id) {
    if (Save.d.ach.includes(id)) return; const a = ACHIEVEMENTS.find(x => x.id === id); if (!a) return;
    Save.d.ach.push(id); Save.save(); const t = $('#achToast'); t.innerHTML = `<small>ACHIEVEMENT</small>${a.name}`; t.classList.remove('show'); void t.offsetWidth; t.classList.add('show'); AudioSys.play('uiBig');
    clearTimeout(ach._t); ach._t = setTimeout(() => t.classList.remove('show'), 2800);
  }
  function checkWeapons() { if (WEAPONS.every(w => Save.d.weapons.includes(w.id))) ach('allweapons'); }
  function nextStageIdx() { for (let i = 0; i < Save.d.unlockedStage; i++) if (!Save.d.cleared.includes(i)) return i; return Math.min(STAGES.length - 1, Save.d.unlockedStage - 1); }
  function sanitize() { if (!Save.d.weapons.includes(Save.d.equipped)) Save.d.equipped = 'executioner'; if (!Save.d.weapons.includes('executioner')) Save.d.weapons.unshift('executioner'); }

  // ---------- menu ----------
  function toMenu(opts = {}) {
    stopGame(); closeOverlay(); Globe.hide(); show('scr-menu'); Menu.show(opts);
    if (opts.back) ach('back');
  }
  Menu.onAch = ach;
  Menu.onWeapon = () => checkWeapons();
  Menu.onStage = (i, opts) => { Menu.hide(); quickTransition(() => startStage(i, opts || {})); };
  $$('#scr-menu .mbtn').forEach(b => b.addEventListener('click', () => {
    const act = b.dataset.act; AudioSys.play('ui');
    if (act === 'play') { Menu.hide(); show('scr-globe'); const idx = nextStageIdx(); Globe.show(idx, () => startStage(idx, {})); }
    else Menu.open(act);
  }));
  $('#panelClose').onclick = () => Menu.close();
  $('#panel').addEventListener('click', (e) => { if (e.target.id === 'panel') Menu.close(); });
  Globe.onBack = () => toMenu();

  function quickTransition(fn) {
    const q = $('#trans'); q.classList.add('on'); AudioSys.play('whisper', 1.2); AudioSys.play('growl', 0.6, 0.8);
    setTimeout(() => { fn(); setTimeout(() => q.classList.remove('on'), 300); }, 900);
  }

  // ---------- game ----------
  function startStage(i, opts) {
    if (opts) curOpts = opts; sanitize(); curStage = i; Menu.hide(); closeOverlay(); show('scr-game'); goFull(); Game.resize(); layoutControls();
    Game.start(i, curOpts); startLoop();
  }
  // landscape-first: try fullscreen + orientation lock on phones (silently ignored where unsupported)
  function goFull() {
    if (!Save.d.fullscreen || !matchMedia('(pointer:coarse)').matches) return;
    try { const de = document.documentElement; if (!document.fullscreenElement && de.requestFullscreen) de.requestFullscreen({ navigationUI: 'hide' }).then(() => { try { window.screen.orientation && window.screen.orientation.lock && window.screen.orientation.lock('landscape').catch(() => {}); } catch (e) {} }).catch(() => {}); } catch (e) {}
  }
  // the Eye talks to you during play — only about things that actually happened
  function whisper(text, force) { const st = Game.stage(); if (!st) return; const now = st.T; if (!force && now - lastWhisper < 22) return; lastWhisper = now; Game.whisper(text); }
  const pick = (a) => a[Math.random() * a.length | 0];
  function stopGame() { Game.stop && Game.stop(); loopOn = false; resetInput(); }
  function startLoop() { if (loopOn) return; loopOn = true; lastT = performance.now(); acc = 0; requestAnimationFrame(frame); }
  function frame(now) {
    if (!loopOn) return;
    const dt = Math.min(0.1, (now - lastT) / 1000); lastT = now;
    fpsAcc += dt; fpsN++; if (fpsAcc > 0.5) { Game.fps = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0; }
    if (!manual) { acc += dt; let n = 0; while (acc >= STEP && n < 5) { tick(STEP); acc -= STEP; n++; } if (n === 5) acc = 0; }
    Game.render(); requestAnimationFrame(frame);
  }
  function tick(dt) {
    const I = Game.input;
    if (I.attack) { attackHeldT -= dt; if (attackHeldT <= 0) { I.attackP = true; attackHeldT = 0.13; } }
    Game.update(dt); Game.qualityTick(dt);
    if (Save.d.souls >= 3000) ach('rich');
    if (Save.d.shards.length >= 10) ach('shards');
  }
  window.advanceTime = (ms) => { manual = true; const n = Math.max(1, Math.round(ms / (1000 / 60))); for (let i = 0; i < n; i++) tick(STEP); Game.render(); };
  window.render_game_to_text = () => { if (screen !== 'scr-game') return JSON.stringify({ screen, souls: Save.d.souls, unlocked: Save.d.unlockedStage, weapons: Save.d.weapons }); return Game.textState(); };

  // ---------- events from the engine ----------
  Game.onEvent = (name, data) => {
    const st = Game.stage();
    switch (name) {
      case 'start': { const m = Save.d.mem; m.lastStage = data; lastWhisper = -99; const dh = m.deaths[data] || 0;
        if (dh >= 2 && Math.random() < 0.7) setTimeout(() => whisper(`You have died here ${dh} times.`, true), 2500);
        else if (m.lastResult === 'died' && m.killedByLast && Math.random() < 0.6) setTimeout(() => whisper(`Remember the ${m.killedByLast}?`, true), 2500);
        else if (Save.d.percy === 'dead' && Math.random() < 0.35) setTimeout(() => whisper('No dog this time.', true), 3000);
        Save.save(); break; }
      case 'kill': ach('first_blood'); if (Save.d.kills >= 100) ach('kills100'); if (Save.d.kills >= 500) ach('kills500'); break;
      case 'hit': if (data >= 10) ach('combo10'); if (data >= 30) ach('combo30'); if (data >= 50) ach('combo50'); if (data > (Save.d.mem.bestCombo || 0)) Save.d.mem.bestCombo = data; if (data === 25) whisper('Show me more.'); break;
      case 'execute': ach('exec1'); if (data.count >= 50) { ach('exec50'); if (!Save.d.relics.includes('relic_halo')) Game.grantRelic('relic_halo'); } if (data.count === 1) whisper('Again.', true); break;
      case 'combo5': ach('combo5'); break;
      case 'heavyfull': ach('heavy3'); break;
      case 'mastery': if (data.lvl >= 5) ach('mastery5'); if (data.lvl >= 10) ach('master'); break;
      case 'bossphase': if (data >= 3) { ach('phase3'); whisper(pick(['It is angry now. Good.', 'Now it stops pretending.', 'This is the part where you die.']), true); } break;
      case 'perfect': if (data >= 10) ach('perfect10'); if (data === 1) whisper('Fast. Not fast enough.'); break;
      case 'iaido': ach('iaido'); break;
      case 'sawit': ach('sawit'); whisper('It saw you too.', true); break;
      case 'readyou': whisper(pick(['I know what you will do next.', 'Always the same swing.', 'Predictable.']), true); break;
      case 'endlesswave': if (data >= 10) ach('endless10'); if (data - 1 > (Save.d.endlessBest || 0)) { Save.d.endlessBest = data - 1; Save.save(); } break;
      case 'relic': ach('relic1'); break;
      case 'secondwind': ach('secondwind'); whisper('Not yet. I am not done with you.', true); break;
      case 'percydead': ach('percygone'); Save.d.percyDiedAt = Date.now(); Save.d.percyStage = curStage; Save.save(); setTimeout(() => whisper('He died for you. Was it worth it?', true), 1800); break;
      case 'compdead': ach('compgone'); Save.save(); setTimeout(() => whisper((COMPANIONS[data] ? COMPANIONS[data].name : 'They') + ' is gone. They trusted you.', true), 1800); break;
      case 'percykill': Save.d.percyKills = (Save.d.percyKills || 0) + 1; break;
      case 'switch': Save.d.mem.switches++; break;
      case 'midstage': { const m = Save.d.mem; const by = Object.entries(m.killedBy || {}).sort((a, b) => b[1] - a[1])[0]; if (by && by[1] >= 2 && Math.random() < 0.5) whisper(`The ${by[0]} killed you ${by[1]} times.`); else if (st && st.dmgTaken === 0) whisper('Untouched. For now.'); break; }
      case 'hurt': if (data < 0.25 && Math.random() < 0.5) whisper(pick(['You are bleeding.', 'Lie down. It is easier.', 'I can hear your heart.'])); break;
      case 'playerdead': { const m = Save.d.mem; Save.d.deaths++; m.deaths[curStage] = (m.deaths[curStage] || 0) + 1; const by = data && data.by; if (by) { m.killedBy[by] = (m.killedBy[by] || 0) + 1; m.killedByLast = by; } m.lastResult = 'died'; Save.save(); break; }
      case 'destroy': if (Save.d.destroyed >= 50) ach('destroyer'); break;
      case 'stare': ach('stare'); break;
      case 'bossdead': {
        const i = data; if (!Save.d.cleared.includes(i)) Save.d.cleared.push(i); Save.d.unlockedStage = Math.max(Save.d.unlockedStage, Math.min(STAGES.length, i + 2));
        if (i === 0) ach('boss1'); if (i === 4) ach('boss5'); if (i === 8) ach('boss9'); if (i === 9) ach('boss10'); if (i === 49) ach('deep50'); if (i === 99) ach('deep100');
        if (st && st.bossDmgTaken === 0) ach('nohit'); if (st && st.percy && !st.percy.dead) ach('percyboss'); Save.d.mem.lastBoss = STAGES[i].boss; Save.d.mem.lastResult = 'won'; Save.save(); break; }
      case 'weapon': if (!Save.d.weapons.includes(data)) { Save.d.weapons.push(data); Save.d.equipped = data; Save.save(); setTimeout(() => Game.switchWeapon(data), 300); } checkWeapons(); break;
      case 'clear': {
        if (st) { if (st.dmgTaken === 0) ach('ghost'); if (st.nm) { ach('nightmare1'); if (!Save.d.nmCleared.includes(data)) Save.d.nmCleared.push(data); }
          if (st.mods && st.mods.length) { ach('challenge1'); if (!Save.d.challengeDone.includes(data)) Save.d.challengeDone.push(data); if (Save.d.challengeDone.length >= 3 && !Save.d.relics.includes('relic_mask')) Game.grantRelic('relic_mask'); if (data === 9 && !Save.d.relics.includes('relic_static')) Game.grantRelic('relic_static'); } }
        Save.save(); setTimeout(() => showClear(data), st && st.victory ? 1200 : 0); break; }
      case 'gameover': Save.save(); showDeath(); break;
      case 'finalcrash': Save.save(); fakeCrash(); break;
    }
  };

  // ---------- overlays ----------
  function overlay(html) { const o = $('#overlay'); o.innerHTML = `<div class="ov-box">${html}</div>`; o.classList.add('on'); return o; }
  function closeOverlay() { const o = $('#overlay'); o.classList.remove('on'); o.innerHTML = ''; $('#wmodal').classList.remove('on'); }
  function showDeath() {
    const st = Game.stage(); const lines = ['It was always going to end like this.', 'Get up.', 'The dark is patient.', 'Again?', 'Your little sword did not save you.'];
    const o = overlay(`<h2 class="dead">YOU DIED</h2><p class="ov-sub">${lines[Math.random() * lines.length | 0]}</p><p class="ov-stats">Kills ${st ? st.kills : 0} · Best combo ${st ? st.bestCombo : 0} · Souls ◈ ${st ? st.soulsGained : 0} (kept)${st && st.endless ? ` · Wave ${st.ewave} · Best ${Save.d.endlessBest}` : ''}</p>${Save.d.percy === 'dead' && st && st.percy && st.percy.dead ? '<p class="ov-sub">Percy is gone. He is not coming back.</p>' : ''}<div class="ov-btns"><button class="obtn" data-a="retry">RETRY</button><button class="obtn" data-a="shop">SHOP</button><button class="obtn" data-a="menu">MAIN MENU</button></div>`);
    o.querySelector('[data-a=retry]').onclick = () => { AudioSys.play('ui'); closeOverlay(); startStage(curStage); };
    o.querySelector('[data-a=menu]').onclick = () => { AudioSys.play('ui'); toMenu(); };
    o.querySelector('[data-a=shop]').onclick = () => { AudioSys.play('ui'); toMenu(); setTimeout(() => Menu.open('shop'), 200); };
  }
  function showClear(i) {
    const st = Game.stage(); AudioSys.play('victory');
    if (i === 9) { return showEnding(); }
    if (i === 99) { return showDeepEnding(); }
    const B = { name: bossName(STAGES[i]) };
    const o = overlay(`<h2>STAGE ${i + 1} CLEARED</h2><p class="ov-sub">${B.name} is dead. Something else noticed.</p><p class="ov-stats">Kills ${st.kills} · Best combo ${st.bestCombo} · Souls ◈ ${st.soulsGained}${st.bossDmgTaken === 0 ? ' · UNTOUCHED' : ''}${st.grade ? ' · GRADE ' + st.grade : ''}${st.execs ? ' · Executions ' + st.execs : ''}</p>${st.percy && !st.percy.dead ? '<p class="ov-sub">Percy wags his tail. Good boy.</p>' : ''}<p class="ov-next">NEXT: ${STAGES[i + 1].name}</p><div class="ov-btns"><button class="obtn big" data-a="next">CONTINUE</button><button class="obtn" data-a="shop">SHOP</button><button class="obtn" data-a="menu">MAIN MENU</button></div>`);
    o.querySelector('[data-a=next]').onclick = () => { AudioSys.play('uiBig'); closeOverlay(); quickTransition(() => startStage(i + 1)); };
    o.querySelector('[data-a=menu]').onclick = () => { AudioSys.play('ui'); toMenu(); };
    o.querySelector('[data-a=shop]').onclick = () => { AudioSys.play('ui'); toMenu(); setTimeout(() => Menu.open('shop'), 200); };
  }
  function showDeepEnding() {
    const o = overlay(`<h2>STAGE 100 CLEARED</h2><p class="ov-sub">The Eye closes. For the first time, nothing is watching.</p><p class="ov-sub slow">You went all the way down. Nobody else has.</p><div class="ov-btns"><button class="obtn big" data-a="menu">CLIMB OUT</button></div>`);
    o.querySelector('[data-a=menu]').onclick = () => { AudioSys.play('ui'); toMenu(); };
  }
  function showEnding() {
    const o = overlay(`<h2>THE EYE IS BLIND</h2><p class="ov-sub">You killed it. The world is quiet.</p><p class="ov-sub slow">...but you can still feel it. Behind you.</p><div class="ov-btns"><button class="obtn big" data-a="menu">TURN AROUND</button></div>`);
    o.querySelector('[data-a=menu]').onclick = () => { AudioSys.play('jumpscare'); const sc = $('#scare2'); sc.classList.add('jump'); setTimeout(() => { sc.classList.remove('jump'); toMenu({ back: true }); setTimeout(() => Menu.say('You can never kill what watches.', true), 1200); }, 1300); };
  }

  // ---------- THE FAKE CRASH (illusion only — nothing actually breaks) ----------
  function fakeCrash() {
    const cr = $('#crash'); const gc = $('#game');
    resetInput(); $('#controls').classList.add('dead');
    AudioSys.stutter(1.6); gc.classList.add('distort');
    Save.d.crashes++; Save.d.lastCrash = Date.now(); Save.save(); ach('crashed');
    const steps = [];
    const at = (ms, fn) => steps.push(setTimeout(fn, ms));
    at(1500, () => { AudioSys.play('crashTone'); gc.classList.add('hung'); cr.className = 'crash on hang'; cr.innerHTML = `<div class="hung-dlg"><div class="hd-title">THE EYE BEHIND YOU</div><div class="hd-body"><div class="hd-icon">!</div><div><b>THE EYE BEHIND YOU is not responding</b><br>If you close the program, you might lose information.</div></div><div class="hd-btns"><button data-a="close">Close the program</button><button data-a="wait">Wait for the program to respond</button></div></div>`;
      cr.querySelectorAll('button').forEach(b => b.onclick = () => { AudioSys.play('glitch', 0.2); const body = cr.querySelector('.hd-body div:last-child'); ach(b.dataset.a === 'close' ? 'closer' : 'waited'); body.innerHTML = b.dataset.a === 'close' ? '<b>It will not let you close it.</b><br>Please wait.' : '<b>Waiting...</b><br>It is waiting too.'; cr.querySelectorAll('button').forEach(x => x.disabled = true); }); });
    at(5600, () => { AudioSys.play('glitch', 0.8); gc.classList.remove('hung', 'distort'); cr.className = 'crash on err'; cr.innerHTML = `<pre class="errlog"></pre>`; typeLog(cr.querySelector('.errlog')); });
    at(9800, () => { cr.className = 'crash on load'; cr.innerHTML = `<div class="fload"><div class="fl-t">Recovering session...</div><div class="fl-bar"><i></i></div><div class="fl-p">0%</div></div>`; const bar = cr.querySelector('i'), pct = cr.querySelector('.fl-p'); let p = 0; const iv = setInterval(() => { p = Math.min(99, p + (p < 70 ? rnd(4, 12) : rnd(0, 2))); bar.style.width = p + '%'; pct.textContent = Math.floor(p) + '%'; if (p >= 99) pct.textContent = '99% — it does not want you to leave'; }, 120); steps.push(iv); });
    at(13600, () => { steps.forEach(s => { clearTimeout(s); clearInterval(s); }); cr.className = 'crash'; cr.innerHTML = ''; gc.classList.remove('hung', 'distort'); $('#controls').classList.remove('dead'); toMenu({ back: true }); });
  }
  function typeLog(pre) {
    const lines = ['FATAL EXCEPTION 0x0000E7E', '  at Renderer.drawPlayer (player is not found)', '  at World.update (world.js: the world ended)', '  at Eye.watch (behind.you:∞)', '', 'Thread "hope" stopped responding.', 'Attempting to restore player... FAILED', 'Attempting to restore player... FAILED', 'Attempting to restore player... ', '', 'memory dump:', '  0x00  I  S E E  Y O U', '  0x10  I  S E E  Y O U', '  0x20  I  S E E  Y O U', '', 'Do not turn off your device.'];
    let i = 0; const iv = setInterval(() => { if (i >= lines.length || !pre.isConnected) { clearInterval(iv); return; } pre.textContent += lines[i++] + '\n'; if (Math.random() < 0.3) AudioSys.play('glitch', 0.08); }, 200);
  }

  // ---------- weapon modal (CHANGE) ----------
  function openWeapons() {
    const st = Game.stage(); if (!st || st.p.dead) return; Game.paused = true; resetInput(); AudioSys.play('ui');
    const m = $('#wmodal'); const grid = m.querySelector('.wgrid'); grid.innerHTML = '';
    WEAPONS.forEach((wd, i) => {
      const owned = Save.d.weapons.includes(wd.id); const b = document.createElement('button'); b.className = 'wslot' + (owned ? '' : ' locked') + (st.p.weapon === wd.id ? ' cur' : '');
      const cvs = document.createElement('canvas'); cvs.width = 120; cvs.height = 120; const cc = cvs.getContext('2d'); if (owned) drawWeaponIcon(cc, wd.id, 60, 60, 120, null, 0); else { cc.globalAlpha = 0.3; drawWeaponIcon(cc, wd.id, 60, 60, 120, '#000000', 0); }
      b.appendChild(cvs); const lbl = document.createElement('span'); lbl.textContent = owned ? wd.name.replace('THE ', '') : 'LOCKED'; b.appendChild(lbl);
      b.onclick = () => { if (!owned) { AudioSys.play('deny'); Menu.toast(wd.unlock); return; } closeWeapons(); Game.switchWeapon(wd.id); };
      grid.appendChild(b);
    });
    m.classList.add('on');
  }
  function closeWeapons() { $('#wmodal').classList.remove('on'); Game.paused = false; }
  $('#btnChange').addEventListener('click', (e) => { e.stopPropagation(); openWeapons(); });
  $('#wmodal').addEventListener('click', (e) => { if (e.target.id === 'wmodal' || e.target.classList.contains('wclose')) { AudioSys.play('ui'); closeWeapons(); } });
  function cycleWeapon() { const st = Game.stage(); if (!st) return; const own = WEAPONS.filter(w => Save.d.weapons.includes(w.id)); const i = own.findIndex(w => w.id === st.p.weapon); const n = own[(i + 1) % own.length]; if (n && n.id !== st.p.weapon) Game.switchWeapon(n.id); }

  // ---------- pause ----------
  function pause() {
    const st = Game.stage(); if (!st || st.p.dead || st.cleared || $('#overlay').classList.contains('on')) return; Game.paused = true; resetInput(); AudioSys.play('ui'); AudioSys.duck(0.4);
    const o = overlay(`<h2>PAUSED</h2><p class="ov-sub">It is still watching.</p><div class="ov-set"><label>MUSIC <input type="range" min="0" max="1" step="0.05" value="${Save.d.music}" data-k="music"></label><label>SOUND <input type="range" min="0" max="1" step="0.05" value="${Save.d.sfx}" data-k="sfx"></label></div><div class="ov-btns"><button class="obtn big" data-a="resume">RESUME</button><button class="obtn" data-a="restart">RESTART STAGE</button><button class="obtn" data-a="menu">QUIT TO MENU</button></div>`);
    o.querySelectorAll('input').forEach(inp => inp.oninput = () => { Save.d[inp.dataset.k] = +inp.value; if (inp.dataset.k === 'music') AudioSys.setMusic(+inp.value); else AudioSys.setSfx(+inp.value); Save.save(); });
    o.querySelector('[data-a=resume]').onclick = resume;
    o.querySelector('[data-a=restart]').onclick = () => { AudioSys.duck(1); closeOverlay(); startStage(curStage); };
    o.querySelector('[data-a=menu]').onclick = () => { AudioSys.duck(1); toMenu(); };
  }
  function resume() { AudioSys.duck(1); AudioSys.play('ui'); closeOverlay(); Game.paused = false; }
  $('#btnPause').addEventListener('click', (e) => { e.stopPropagation(); pause(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden && screen === 'scr-game' && !Game.paused) pause(); });

  // ---------- touch controls (multitouch, slide between buttons) ----------
  const ctl = $('#controls'); const ptrs = new Map();
  const keyOf = (x, y) => { const el = document.elementFromPoint(x, y); const b = el && el.closest && el.closest('[data-k]'); return b && ctl.contains(b) ? b.dataset.k : null; };
  function press(k, on) {
    const I = Game.input; const b = ctl.querySelector(`[data-k="${k}"]`); if (b) b.classList.toggle('on', on);
    if (k === 'left') I.left = on; if (k === 'right') I.right = on;
    if (k === 'jump') { if (on && !I.jump) I.jumpP = true; I.jump = on; }
    if (k === 'attack') { if (on && !I.attack) { I.attackP = true; attackHeldT = 0.28; } I.attack = on; }
    if (k === 'special') { if (on && !I.special) I.specialP = true; I.special = on; }
    if (k === 'heavy') { if (on && !I.heavy) I.heavyP = true; I.heavy = on; }
    if (k === 'dodge') { if (on && !I.dodge) I.dodgeP = true; I.dodge = on; }
    if (on && Save.d.haptics && navigator.vibrate) try { navigator.vibrate(8); } catch (e) {}
  }
  function refreshPressed() { const held = new Set(ptrs.values()); ['left', 'right', 'jump', 'attack', 'special', 'heavy', 'dodge'].forEach(k => { const isOn = held.has(k); const bb = ctl.querySelector(`[data-k="${k}"]`); if (!bb) return; const was = bb.classList.contains('on'); if (isOn !== was) press(k, isOn); }); }
  ctl.addEventListener('pointerdown', e => { e.preventDefault(); AudioSys.init(); const k = keyOf(e.clientX, e.clientY); if (k) { ptrs.set(e.pointerId, k); refreshPressed(); } });
  ctl.addEventListener('pointermove', e => { if (!ptrs.has(e.pointerId)) return; const k = keyOf(e.clientX, e.clientY); const prev = ptrs.get(e.pointerId); if (k && k !== prev && (['left', 'right'].includes(k) && ['left', 'right'].includes(prev))) { ptrs.set(e.pointerId, k); refreshPressed(); } });
  const lift = e => { if (ptrs.delete(e.pointerId)) refreshPressed(); };
  ctl.addEventListener('pointerup', lift); ctl.addEventListener('pointercancel', lift); ctl.addEventListener('lostpointercapture', lift);
  ctl.addEventListener('contextmenu', e => e.preventDefault());
  function resetInput() { ptrs.clear(); const I = Game.input; Object.keys(I).forEach(k => I[k] = false); ctl.querySelectorAll('.on').forEach(b => b.classList.remove('on')); }
  window.addEventListener('blur', resetInput);

  // ---------- keyboard (optional on desktop) ----------
  const KM = { ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right', ArrowUp: 'jump', KeyW: 'jump', Space: 'jump', KeyJ: 'attack', KeyX: 'attack', KeyK: 'special', KeyC: 'special', KeyL: 'heavy', KeyV: 'heavy', ShiftLeft: 'dodge', ShiftRight: 'dodge', KeyI: 'dodge' };
  window.addEventListener('keydown', e => {
    AudioSys.init();
    if (screen !== 'scr-game') { if (e.code === 'Escape') { if (!$('#panel').classList.contains('hidden')) Menu.close(); } return; }
    if (e.code === 'Escape' || e.code === 'KeyP') { if ($('#wmodal').classList.contains('on')) closeWeapons(); else if (Game.paused) resume(); else pause(); e.preventDefault(); return; }
    if (Game.paused) return;
    if (e.code === 'KeyQ') { cycleWeapon(); return; }
    if (/^Digit[1-5]$/.test(e.code)) { const wd = WEAPONS[+e.code.slice(5) - 1]; if (Save.d.weapons.includes(wd.id)) Game.switchWeapon(wd.id); return; }
    const k = KM[e.code]; if (k) { e.preventDefault(); if (!e.repeat) press(k, true); }
  });
  window.addEventListener('keyup', e => { const k = KM[e.code]; if (k) press(k, false); });

  // ---------- layout: portrait puts controls under the world ----------
  function layoutControls() {
    const v = Game.view; if (!v) return; const worldBottom = v.offY + VH * v.scale;
    document.body.classList.toggle('portrait', !!Game.portrait);
    document.documentElement.style.setProperty('--world-bottom', worldBottom + 'px');
    document.documentElement.style.setProperty('--world-top', v.offY + 'px');
    // control scale: smaller on short phones, user-adjustable in settings
    const hgt = window.innerHeight, base = Game.portrait ? 0.9 : hgt < 340 ? 0.74 : hgt < 400 ? 0.84 : hgt < 470 ? 0.92 : 1;
    document.documentElement.style.setProperty('--cs', (base * (Save.d.ctlSize || 1)).toFixed(3));
    document.body.classList.toggle('swap', !!Save.d.swapSides);
    const rot = document.getElementById('rotateHint'); if (rot) rot.classList.toggle('on', !!Game.portrait && screen === 'scr-game' && !rot.dataset.dismissed);
  }
  window.layoutControls = layoutControls;
  window.addEventListener('resize', () => { if (screen === 'scr-game') { Game.resize(); layoutControls(); } });
  window.addEventListener('orientationchange', () => setTimeout(() => { Game.resize(); layoutControls(); }, 200));

  // ---------- boot ----------
  function boot() {
    sanitize(); const hr = new Date().getHours(); if (hr >= 0 && hr < 5) setTimeout(() => ach('insomniac'), 4000);
    Game.init($('#game')); Menu.init(); Globe.init(); Globe.preload();
    AudioSys.setMusic(Save.d.music); AudioSys.setSfx(Save.d.sfx);
    const gate = $('#gate');
    const wake = () => {
      if (screen !== 'gate') return; AudioSys.init(); AudioSys.setMusic(Save.d.music); AudioSys.setSfx(Save.d.sfx); AudioSys.play('eyeSquelch');
      gate.classList.add('open'); setTimeout(() => gate.remove(), 1300);
      const recent = Save.d.lastCrash && Date.now() - Save.d.lastCrash < 30 * 60 * 1000;
      toMenu({ back: !!recent });
    };
    gate.addEventListener('click', wake); gate.addEventListener('keydown', wake);
    if (Save.d.crashes > 0) $('#gateText').textContent = 'IT REMEMBERS YOU. TAP TO OPEN YOUR EYES';
    document.addEventListener('pointerdown', () => AudioSys.init(), { once: true });
    const rh = $('#rotateHint'); if (rh) rh.addEventListener('click', () => { rh.dataset.dismissed = '1'; rh.classList.remove('on'); });
    window.Debug = { start: startStage, menu: toMenu, crash: fakeCrash, ach, game: Game, whisper: (t) => Game.whisper(t), percy: (v) => { Save.d.percy = v; Save.save(); } };
  }
  boot();
})();
