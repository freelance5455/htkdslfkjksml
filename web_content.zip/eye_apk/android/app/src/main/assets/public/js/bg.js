// ===== STAGE BACKGROUNDS (procedural parallax) =====
const VH = 540, GY = 432, TILE = 1600;
function seeded(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }

function buildBG(idx) {
  const S = STAGES[idx]; const R = seeded(idx * 977 + 13);
  const far = mkCanvas(TILE, VH), mid = mkCanvas(TILE, VH), near = mkCanvas(TILE, VH);
  const f = far.getContext('2d'), m = mid.getContext('2d'), n = near.getContext('2d');
  const torches = [], eyes = [], windows = [];
  const wrap = (fn) => { fn(0); fn(TILE); fn(-TILE); };
  const silhouetteRidge = (c, y0, amp, col, rough = 40) => { c.fillStyle = col; c.beginPath(); c.moveTo(0, VH); let pts = []; for (let x = 0; x <= TILE; x += rough) pts.push(y0 - amp * (0.5 + 0.5 * Math.sin(x * 0.004 + idx) * Math.cos(x * 0.0017)) - R() * amp * 0.3); pts[pts.length - 1] = pts[0]; pts.forEach((y, i) => c.lineTo(i * rough, y)); c.lineTo(TILE, VH); c.fill(); };
  const dark = shade(S.sky[0], -0.3);
  switch (S.bg) {
    case 'goblin': {
      silhouetteRidge(f, 300, 90, '#2a160c', 30);
      for (let i = 0; i < 9; i++) { const x = R() * TILE, h = 80 + R() * 120, w = 30 + R() * 30; wrap(o => { f.fillStyle = '#1e0f08'; f.fillRect(x + o, 330 - h, w, h); poly(f, [x + o - 8, 330 - h, x + o + w / 2, 330 - h - 40 - R() * 10, x + o + w + 8, 330 - h], '#1e0f08'); f.fillStyle = 'rgba(255,140,40,0.7)'; f.fillRect(x + o + w / 2 - 3, 330 - h + 20, 6, 9); }); }
      for (let i = 0; i < 14; i++) { const x = R() * TILE, h = 50 + R() * 40, w = 50 + R() * 40; wrap(o => { m.fillStyle = '#140a05'; m.beginPath(); m.moveTo(x + o, GY); m.lineTo(x + o, GY - h); m.lineTo(x + o + w / 2, GY - h - 30); m.lineTo(x + o + w, GY - h); m.lineTo(x + o + w, GY); m.fill(); m.fillStyle = '#060302'; m.fillRect(x + o + w / 2 - 7, GY - 22, 14, 22); }); if (R() < 0.6) torches.push({ x: x + w + 10, y: GY - 60, layer: 0.5 }); }
      for (let x = 0; x < TILE; x += 22) { const h = 40 + R() * 25; m.fillStyle = '#0c0603'; poly(m, [x, GY, x + 4, GY - h, x + 9, GY - h - 8, x + 14, GY - h, x + 18, GY], '#0c0603'); }
      for (let i = 0; i < 6; i++) { const x = R() * TILE; n.strokeStyle = '#050302'; n.lineWidth = 3; n.beginPath(); n.moveTo(x, GY + 60); n.lineTo(x, 200); n.stroke(); circ(n, x, 196, 9, '#d8c8a8'); circ(n, x + 3, 194, 2.5, '#050302'); }
      break; }
    case 'sky': {
      for (let i = 0; i < 200; i++) { f.fillStyle = `rgba(255,255,255,${R() * 0.8})`; f.fillRect(R() * TILE, R() * 300, 1.5, 1.5); }
      for (let i = 0; i < 6; i++) { const x = R() * TILE, y = 140 + R() * 120, w = 100 + R() * 120; wrap(o => { f.fillStyle = '#120c24'; f.beginPath(); f.moveTo(x + o, y); f.lineTo(x + o + w, y); f.lineTo(x + o + w * 0.6, y + 60 + R() * 40); f.lineTo(x + o + w * 0.3, y + 50); f.fill(); f.fillRect(x + o + w * 0.3, y - 60, 14, 60); poly(f, [x + o + w * 0.3 - 6, y - 60, x + o + w * 0.3 + 7, y - 100, x + o + w * 0.3 + 20, y - 60], '#120c24'); }); }
      silhouetteRidge(m, 420, 70, '#0c0918', 50);
      for (let i = 0; i < 5; i++) { const x = R() * TILE; wrap(o => { m.fillStyle = '#0a0814'; m.fillRect(x + o, 250, 40, GY - 250); poly(m, [x + o - 10, 250, x + o + 20, 170, x + o + 50, 250], '#0a0814'); m.fillStyle = 'rgba(255,200,120,0.5)'; m.fillRect(x + o + 16, 280, 8, 14); }); }
      for (let i = 0; i < 5; i++) { const x = R() * TILE; n.fillStyle = '#05040a'; n.fillRect(x, 0, 18, GY + 40); n.fillRect(x - 30, 60, 80, 10); }
      break; }
    case 'forest': {
      for (let i = 0; i < 40; i++) { const x = R() * TILE, w = 8 + R() * 12; wrap(o => { f.fillStyle = `rgba(30,0,4,${0.5 + R() * 0.3})`; f.fillRect(x + o, 60, w, GY); for (let k = 0; k < 4; k++) { f.strokeStyle = f.fillStyle; f.lineWidth = 3; f.beginPath(); const by = 100 + R() * 200; f.moveTo(x + o + w / 2, by); f.lineTo(x + o + w / 2 + (R() - 0.5) * 80, by - 40); f.stroke(); } }); }
      for (let i = 0; i < 18; i++) { const x = R() * TILE, w = 24 + R() * 22; wrap(o => { m.fillStyle = '#120204'; m.beginPath(); m.moveTo(x + o - w, GY); m.quadraticCurveTo(x + o, GY - 40, x + o + 4, 0); m.lineTo(x + o + w * 0.6, 0); m.quadraticCurveTo(x + o + w * 0.4, GY - 40, x + o + w * 1.6, GY); m.fill(); for (let k = 0; k < 5; k++) { m.strokeStyle = '#120204'; m.lineWidth = 6 - k; m.beginPath(); const by = 40 + k * 60; m.moveTo(x + o + w * 0.3, by); m.quadraticCurveTo(x + o + w * 0.3 + (R() - 0.5) * 120, by - 20, x + o + (R() - 0.5) * 200, by - 60 + R() * 40); m.stroke(); } }); if (R() < 0.5) eyes.push({ x: x + rnd(-10, 30), y: rnd(150, 330), layer: 0.5, s: rnd(0.6, 1.2), ph: R() * 10 }); }
      for (let i = 0; i < 4; i++) { const x = R() * TILE; n.strokeStyle = '#030001'; n.lineWidth = 2; n.beginPath(); n.moveTo(x, 0); n.lineTo(x, 120 + R() * 60); n.stroke(); n.fillStyle = '#030001'; n.fillRect(x - 14, 150, 28, 40); n.strokeRect(x - 14, 150, 28, 40); for (let k = 0; k < 4; k++) n.fillRect(x - 14 + k * 9, 150, 2, 40); }
      break; }
    case 'grave': {
      silhouetteRidge(f, 330, 70, '#0a1a18', 40);
      for (let i = 0; i < 6; i++) { const x = R() * TILE; wrap(o => { f.fillStyle = '#081210'; f.fillRect(x + o, 220, 80, 120); poly(f, [x + o - 10, 220, x + o + 40, 160, x + o + 90, 220], '#081210'); f.fillRect(x + o + 36, 130, 8, 34); f.fillRect(x + o + 28, 140, 24, 6); }); }
      for (let i = 0; i < 40; i++) { const x = R() * TILE, h = 26 + R() * 30, w = 16 + R() * 14, tilt = (R() - 0.5) * 0.3; wrap(o => { m.save(); m.translate(x + o, GY); m.rotate(tilt); m.fillStyle = '#0c1614'; if (R() < 0.4) { m.fillRect(-3, -h - 14, 6, h + 14); m.fillRect(-12, -h - 4, 24, 6); } else { m.beginPath(); m.moveTo(-w / 2, 0); m.lineTo(-w / 2, -h); m.arc(0, -h, w / 2, Math.PI, 0); m.lineTo(w / 2, 0); m.fill(); } m.restore(); }); }
      for (let i = 0; i < 5; i++) { const x = R() * TILE; m.strokeStyle = '#050a09'; m.lineWidth = 7; m.beginPath(); m.moveTo(x, GY); m.lineTo(x + 6, 220); m.stroke(); for (let k = 0; k < 5; k++) { m.lineWidth = 3; m.beginPath(); m.moveTo(x + 4, 240 + k * 30); m.lineTo(x + (R() - 0.5) * 140, 200 + k * 26); m.stroke(); } }
      for (let i = 0; i < 4; i++) { const x = R() * TILE; n.fillStyle = '#020403'; n.fillRect(x, GY - 140, 6, 200); n.fillRect(x - 26, GY - 110, 58, 7); }
      break; }
    case 'fortress': {
      silhouetteRidge(f, 340, 60, '#2a0602', 50);
      for (let i = 0; i < 7; i++) { const x = R() * TILE, h = 120 + R() * 140; wrap(o => { f.fillStyle = '#1a0402'; f.fillRect(x + o, 340 - h, 60, h); for (let k = 0; k < 4; k++) f.fillRect(x + o + k * 16, 330 - h, 10, 12); f.fillStyle = 'rgba(255,120,30,0.8)'; f.fillRect(x + o + 24, 360 - h, 10, 16); }); torches.push({ x: x + 30, y: 320 - h, layer: 0.15, big: true }); }
      for (let x = 0; x < TILE; x += 200) { m.fillStyle = '#120402'; m.fillRect(x, 280, 200, GY - 280); for (let k = 0; k < 10; k++) m.fillRect(x + k * 20, 266, 12, 16); m.strokeStyle = '#2a0a04'; m.lineWidth = 1; for (let y = 290; y < GY; y += 18) { m.beginPath(); m.moveTo(x, y); m.lineTo(x + 200, y); m.stroke(); } m.fillStyle = '#050100'; m.beginPath(); m.moveTo(x + 80, GY); m.lineTo(x + 80, 360); m.arc(x + 100, 360, 20, Math.PI, 0); m.lineTo(x + 120, GY); m.fill(); torches.push({ x: x + 60, y: 340, layer: 0.5 }); torches.push({ x: x + 140, y: 340, layer: 0.5 }); }
      for (let i = 0; i < 5; i++) { const x = R() * TILE; n.strokeStyle = '#050100'; n.lineWidth = 4; n.beginPath(); n.moveTo(x, 0); n.lineTo(x + 10, 140); n.stroke(); n.lineWidth = 2; for (let k = 0; k < 8; k++) { n.beginPath(); n.arc(x + 10, 150 + k * 10, 5, 0, 7); n.stroke(); } }
      break; }
    case 'sunken': {
      for (let i = 0; i < 10; i++) { const x = R() * TILE, h = 140 + R() * 120; wrap(o => { f.fillStyle = 'rgba(2,30,36,0.9)'; f.fillRect(x + o, 360 - h, 34, h); f.fillRect(x + o - 8, 360 - h, 50, 14); if (R() < 0.5) { f.save(); f.translate(x + o + 17, 360 - h); f.rotate(0.6); f.fillRect(-17, -h * 0.5, 34, h * 0.5); f.restore(); } }); }
      for (let i = 0; i < 4; i++) { const x = R() * TILE; wrap(o => { m.fillStyle = '#021a1e'; m.beginPath(); m.moveTo(x + o, GY); m.lineTo(x + o, 230); m.arc(x + o + 70, 230, 70, Math.PI, 0); m.lineTo(x + o + 140, GY); m.lineTo(x + o + 115, GY); m.lineTo(x + o + 115, 240); m.arc(x + o + 70, 240, 45, 0, Math.PI, true); m.lineTo(x + o + 25, GY); m.fill(); }); }
      for (let i = 0; i < 4; i++) { const x = R() * TILE; m.fillStyle = '#021a1e'; m.beginPath(); m.ellipse(x, 230, 50, 60, 0, 0, 7); m.fill(); circ(m, x - 18, 220, 10, '#000'); circ(m, x + 18, 220, 10, '#000'); m.fillRect(x - 30, 250, 60, 120); }
      break; }
    case 'ice': {
      f.fillStyle = '#4a6a8a'; silhouetteRidge(f, 300, 160, '#3a5a7a', 60); silhouetteRidge(f, 340, 90, '#2a4560', 40);
      for (let i = 0; i < 30; i++) { const x = R() * TILE, h = 30 + R() * 90; wrap(o => { poly(m, [x + o - 12, GY, x + o + (R() - 0.5) * 10, GY - h, x + o + 12, GY], `rgba(${180 + R() * 50},${220 + R() * 30},255,0.85)`, '#3a6a8a', 1.5); }); }
      for (let i = 0; i < 3; i++) { const x = R() * TILE; wrap(o => { m.fillStyle = '#1a2a3a'; m.beginPath(); m.ellipse(x + o, GY - 60, 80, 70, 0, Math.PI, 0); m.fill(); m.strokeStyle = '#d8e8f8'; m.lineWidth = 3; for (let k = 0; k < 6; k++) { m.beginPath(); m.moveTo(x + o - 60 + k * 24, GY - 60); m.lineTo(x + o - 60 + k * 24, GY - 120 + Math.abs(k - 2.5) * 16); m.stroke(); } }); }
      for (let i = 0; i < 4; i++) { const x = R() * TILE; n.fillStyle = 'rgba(220,240,255,0.5)'; poly(n, [x - 20, GY + 80, x, 80, x + 20, GY + 80], 'rgba(180,220,255,0.35)'); }
      break; }
    case 'cathedral': {
      for (let x = 0; x < TILE; x += 200) { f.fillStyle = '#0e0810'; f.fillRect(x, 0, 200, VH); f.fillStyle = '#05030a'; f.beginPath(); f.moveTo(x + 60, 330); f.lineTo(x + 60, 120); f.quadraticCurveTo(x + 100, 40, x + 140, 120); f.lineTo(x + 140, 330); f.fill(); windows.push({ x: x + 60, y: 70, w: 80, h: 260, layer: 0.15 }); }
      for (let x = 0; x < TILE; x += 320) { m.fillStyle = '#0a060c'; m.fillRect(x + 40, 0, 50, GY); m.fillRect(x + 30, GY - 30, 70, 30); m.fillRect(x + 30, 60, 70, 20); m.beginPath(); m.moveTo(x + 90, 80); m.quadraticCurveTo(x + 200, 40, x + 270, 80); m.lineTo(x + 270, 100); m.quadraticCurveTo(x + 200, 60, x + 90, 100); m.fill(); for (let k = 0; k < 3; k++) torches.push({ x: x + 150 + k * 30, y: GY - 40, layer: 0.5, candle: true }); }
      for (let i = 0; i < 4; i++) { const x = R() * TILE; n.fillStyle = '#030204'; n.fillRect(x, 0, 40, GY + 100); }
      break; }
    case 'flesh': {
      for (let i = 0; i < 26; i++) { const x = R() * TILE, y = R() * 380, r = 30 + R() * 70; wrap(o => { const g = f.createRadialGradient(x + o, y, 2, x + o, y, r); g.addColorStop(0, '#6a1a2a'); g.addColorStop(1, 'rgba(40,4,12,0)'); f.fillStyle = g; f.beginPath(); f.arc(x + o, y, r, 0, 7); f.fill(); }); }
      for (let i = 0; i < 20; i++) { f.strokeStyle = 'rgba(120,10,30,0.6)'; f.lineWidth = 2 + R() * 6; f.beginPath(); let x = R() * TILE, y = 0; f.moveTo(x, y); for (let k = 0; k < 8; k++) { x += (R() - 0.5) * 80; y += 60; f.lineTo(x, y); } f.stroke(); }
      for (let i = 0; i < 12; i++) { const x = R() * TILE, h = 100 + R() * 160; wrap(o => { m.fillStyle = '#3a0812'; m.beginPath(); m.moveTo(x + o - 30, GY); m.quadraticCurveTo(x + o - 10, GY - h * 0.5, x + o, GY - h); m.quadraticCurveTo(x + o + 10, GY - h * 0.5, x + o + 30, GY); m.fill(); for (let k = 0; k < 4; k++) poly(m, [x + o - 8, GY - h * 0.3 - k * 20, x + o, GY - h * 0.3 - k * 20 - 14, x + o + 8, GY - h * 0.3 - k * 20], '#e8dcc0'); }); eyes.push({ x: x, y: GY - 60 - R() * 100, layer: 0.5, s: rnd(1, 2), ph: R() * 10, flesh: true }); }
      for (let i = 0; i < 6; i++) { const x = R() * TILE; n.fillStyle = '#1a0206'; n.beginPath(); n.moveTo(x - 40, 0); n.quadraticCurveTo(x, 160 + R() * 60, x + 40, 0); n.fill(); }
      break; }
    case 'void': {
      for (let i = 0; i < 260; i++) { f.fillStyle = `rgba(255,255,255,${R() * 0.6})`; f.fillRect(R() * TILE, R() * GY, 1.2, 1.2); }
      for (let i = 0; i < 14; i++) { const x = R() * TILE, y = 60 + R() * 300, s = 20 + R() * 60; wrap(o => { f.strokeStyle = 'rgba(255,255,255,0.25)'; f.lineWidth = 1; f.save(); f.translate(x + o, y); f.rotate(R() * 6); f.strokeRect(-s / 2, -s / 2, s, s); f.restore(); }); }
      for (let i = 0; i < 8; i++) { const x = R() * TILE, h = 120 + R() * 200; wrap(o => { m.fillStyle = '#050508'; m.fillRect(x + o, GY - h, 26, h); m.strokeStyle = 'rgba(255,255,255,0.12)'; m.strokeRect(x + o, GY - h, 26, h); }); }
      for (let i = 0; i < 6; i++) eyes.push({ x: R() * TILE, y: 80 + R() * 200, layer: 0.15, s: rnd(1.5, 3), ph: R() * 10, track: true });
      break; }
  }
  return { far, mid, near, torches, eyes, windows, S };
}

function drawSky(c, W, S, T, idx) {
  const g = c.createLinearGradient(0, 0, 0, GY); g.addColorStop(0, S.sky[0]); g.addColorStop(0.6, S.sky[1]); g.addColorStop(1, S.sky[2]); c.fillStyle = g; c.fillRect(0, 0, W, GY + 2);
  // moon / sun
  const moon = { goblin: ['#ffb060', 0.8], sky: ['#f0e8ff', 1.4], forest: ['#ff2a1a', 1.2], grave: ['#cfeee8', 0.9], fortress: ['#ff6a1a', 0.7], ice: ['#ffffff', 0.6], cathedral: ['#e8c8a0', 0.5], flesh: ['#ffd0a0', 0.5] }[S.bg];
  if (moon) { const mx = W * 0.72, my = 110; const mg = c.createRadialGradient(mx, my, 10, mx, my, 160 * moon[1]); mg.addColorStop(0, rgba(moon[0], 0.5)); mg.addColorStop(1, rgba(moon[0], 0)); c.fillStyle = mg; c.fillRect(mx - 200, my - 200, 400, 400); circ(c, mx, my, 40 * moon[1], moon[0]); c.fillStyle = 'rgba(0,0,0,0.12)'; circ(c, mx - 10, my - 8, 8 * moon[1], 'rgba(0,0,0,0.1)'); circ(c, mx + 12, my + 10, 12 * moon[1], 'rgba(0,0,0,0.08)'); }
  if (S.bg === 'flesh') { // beating heart in sky
    const beat = 1 + Math.max(0, Math.sin(T * 7)) * 0.05; c.save(); c.translate(W * 0.72, 110); c.scale(beat, beat); circ(c, 0, 0, 30, '#8a1020'); c.restore(); }
  if (S.bg === 'ice') { for (let i = 0; i < 3; i++) { c.strokeStyle = `rgba(${80 + i * 40},255,${180 + i * 20},0.12)`; c.lineWidth = 30; c.beginPath(); for (let x = 0; x <= W; x += 40) c.lineTo(x, 80 + i * 30 + Math.sin(x * 0.006 + T * 0.4 + i) * 30); c.stroke(); } }
  if (S.bg === 'sunken') { for (let i = 0; i < 6; i++) { const x = (i * 260 + T * 12) % (W + 300) - 150; const lg = c.createLinearGradient(x, 0, x + 60, GY); lg.addColorStop(0, 'rgba(140,255,240,0.12)'); lg.addColorStop(1, 'rgba(140,255,240,0)'); c.fillStyle = lg; c.beginPath(); c.moveTo(x, 0); c.lineTo(x + 50, 0); c.lineTo(x + 160, GY); c.lineTo(x + 40, GY); c.fill(); } }
  if (S.bg === 'void') { // giant faint eye in the sky
    c.save(); c.globalAlpha = 0.12 + 0.05 * Math.sin(T); c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.ellipse(W / 2, 170, 300, 90, 0, 0, 7); c.stroke(); circ(c, W / 2 + Math.sin(T * 0.5) * 60, 170, 50, null, '#fff', 2); c.restore(); }
}

function drawLayer(c, img, camX, factor, W, yOff = 0) {
  const off = ((camX * factor) % TILE + TILE) % TILE;
  c.drawImage(img, -off, yOff); if (TILE - off < W) c.drawImage(img, TILE - off, yOff); if (2 * TILE - off < W) c.drawImage(img, 2 * TILE - off, yOff);
}

function drawGround(c, W, S, camX, T) {
  const g = c.createLinearGradient(0, GY, 0, VH); g.addColorStop(0, S.ground); g.addColorStop(1, S.ground2); c.fillStyle = g; c.fillRect(0, GY, W, VH - GY);
  // perspective lines (2.5D floor)
  c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 1;
  const vx = W / 2, sp = 90; const off = ((camX) % sp + sp) % sp;
  for (let i = -12; i < W / sp + 12; i++) { const x = i * sp - off; c.beginPath(); c.moveTo(vx + (x - vx) * 0.55, GY); c.lineTo(vx + (x - vx) * 1.6, VH); c.stroke(); }
  for (let k = 0; k < 5; k++) { const y = GY + Math.pow(k / 5, 1.6) * (VH - GY) + 4; c.globalAlpha = 0.25; c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); c.globalAlpha = 1; }
  c.fillStyle = 'rgba(255,255,255,0.06)'; c.fillRect(0, GY, W, 2);
  if (S.bg === 'sunken') { c.fillStyle = 'rgba(40,160,150,0.15)'; for (let i = 0; i < 6; i++) c.fillRect(0, GY + 10 + i * 18 + Math.sin(T * 2 + i) * 2, W, 2); }
  if (S.bg === 'flesh') { c.strokeStyle = 'rgba(160,20,40,0.5)'; c.lineWidth = 2; for (let i = 0; i < 10; i++) { const x = ((i * 220 - camX) % (W + 220) + W + 220) % (W + 220) - 110; c.beginPath(); c.moveTo(x, GY + 4); c.quadraticCurveTo(x + 40, GY + 30 + Math.sin(T * 6 + i) * 4, x + 100, VH); c.stroke(); } }
  if (S.bg === 'ice') { c.fillStyle = 'rgba(255,255,255,0.25)'; c.fillRect(0, GY, W, 6); }
  if (S.bg === 'void') { c.strokeStyle = 'rgba(255,255,255,0.15)'; c.lineWidth = 1; for (let i = -12; i < W / sp + 12; i++) { const x = i * sp - off; c.beginPath(); c.moveTo(vx + (x - vx) * 0.55, GY); c.lineTo(vx + (x - vx) * 1.6, VH); c.stroke(); } }
}

function drawDynamicBG(c, bg, camX, T, W, layer, playerScreenX) {
  bg.torches.filter(t => t.layer === layer).forEach(t => {
    const off = ((camX * layer) % TILE + TILE) % TILE; let x = t.x - off; if (x < -50) x += TILE; if (x > W + 50) return;
    const fl = Math.sin(T * 14 + t.x) * 2; const s = t.big ? 2 : t.candle ? 0.5 : 1;
    const g = c.createRadialGradient(x, t.y, 2, x, t.y, 60 * s); g.addColorStop(0, 'rgba(255,150,50,0.35)'); g.addColorStop(1, 'rgba(255,100,20,0)'); c.fillStyle = g; c.fillRect(x - 60 * s, t.y - 60 * s, 120 * s, 120 * s);
    if (!t.big) { c.fillStyle = '#1a0a04'; c.fillRect(x - 1.5 * s, t.y, 3 * s, 16 * s); }
    poly(c, [x - 5 * s, t.y, x + fl * s, t.y - (16 + fl * 2) * s, x + 5 * s, t.y], '#ff8a2a'); poly(c, [x - 2.5 * s, t.y, x + fl * 0.5 * s, t.y - 9 * s, x + 2.5 * s, t.y], '#ffe08a');
  });
  bg.windows.filter(t => t.layer === layer).forEach(t => {
    const off = ((camX * layer) % TILE + TILE) % TILE; let x = t.x - off; if (x < -100) x += TILE; if (x > W + 100) return;
    c.save(); c.beginPath(); c.moveTo(x, t.y + t.h); c.lineTo(x, t.y + 50); c.quadraticCurveTo(x + t.w / 2, t.y - 30, x + t.w, t.y + 50); c.lineTo(x + t.w, t.y + t.h); c.closePath(); c.clip();
    const cols = ['#8a1020', '#1a3a8a', '#c89a1a', '#3a1a6a', '#1a6a4a'];
    for (let i = 0; i < 8; i++) for (let k = 0; k < 3; k++) { c.fillStyle = rgba(cols[(i + k + Math.floor(t.x / 200)) % 5], 0.45 + 0.1 * Math.sin(T + i)); c.fillRect(x + k * t.w / 3, t.y + i * 36, t.w / 3 - 2, 34); }
    c.strokeStyle = '#05030a'; c.lineWidth = 4; c.beginPath(); c.moveTo(x + t.w / 2, t.y); c.lineTo(x + t.w / 2, t.y + t.h); c.stroke();
    c.restore();
    const lg = c.createLinearGradient(x, t.y, x + 120, GY); lg.addColorStop(0, 'rgba(255,200,160,0.08)'); lg.addColorStop(1, 'rgba(255,200,160,0)'); c.fillStyle = lg; c.beginPath(); c.moveTo(x, t.y + 60); c.lineTo(x + t.w, t.y + 60); c.lineTo(x + t.w + 160, GY); c.lineTo(x + 60, GY); c.fill();
  });
  bg.eyes.filter(t => t.layer === layer).forEach(t => {
    const off = ((camX * layer) % TILE + TILE) % TILE; let x = t.x - off; if (x < -60) x += TILE; if (x > W + 60) return;
    const blink = ((T + t.ph) % 5) < 0.15; const s = t.s;
    const dx = clamp((playerScreenX - x) / 300, -1, 1) * 2 * s;
    if (t.flesh || t.track) { c.fillStyle = t.track ? 'rgba(255,255,255,0.5)' : '#f8ecd0'; c.beginPath(); c.ellipse(x, t.y, 9 * s, blink ? 0.5 : 6 * s, 0, 0, 7); c.fill(); if (!blink) circ(c, x + dx, t.y, 3 * s, t.track ? '#000' : '#300'); }
    else if (!blink) { c.shadowColor = '#ff2020'; c.shadowBlur = 8; circ(c, x - 4 * s, t.y, 1.8 * s, '#ff2a2a'); circ(c, x + 4 * s, t.y, 1.8 * s, '#ff2a2a'); c.shadowBlur = 0; }
  });
}

// ---------- props (breakables) ----------
function drawProp(c, p, T) {
  c.save(); c.translate(p.x, p.y); const sh = p.hitT > 0 ? Math.sin(p.hitT * 80) * 3 : 0; c.translate(sh, 0); const out = '#07050a';
  switch (p.type) {
    case 'barrel': c.beginPath(); c.ellipse(0, -22, 16, 22, 0, 0, 7); c.fillStyle = '#5a3a1a'; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke(); c.strokeStyle = '#2a2a2a'; c.lineWidth = 3; c.beginPath(); c.moveTo(-15, -32); c.lineTo(15, -32); c.moveTo(-15, -12); c.lineTo(15, -12); c.stroke(); break;
    case 'crate': c.fillStyle = '#3a2a1e'; c.fillRect(-20, -38, 40, 38); c.strokeStyle = out; c.lineWidth = 2; c.strokeRect(-20, -38, 40, 38); c.beginPath(); c.moveTo(-20, -38); c.lineTo(20, 0); c.moveTo(20, -38); c.lineTo(-20, 0); c.stroke(); break;
    case 'stump': c.fillStyle = '#2a0a0a'; poly(c, [-18, 0, -14, -30, -4, -36, 6, -30, 14, -34, 18, 0], '#2a0a0a', out); c.fillStyle = '#6a1010'; c.beginPath(); c.ellipse(0, -32, 12, 4, 0, 0, 7); c.fill(); break;
    case 'tomb': c.fillStyle = '#4a5450'; c.beginPath(); c.moveTo(-14, 0); c.lineTo(-14, -34); c.arc(0, -34, 14, Math.PI, 0); c.lineTo(14, 0); c.closePath(); c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke(); c.fillStyle = '#2a302e'; c.fillRect(-2, -40, 4, 18); c.fillRect(-7, -35, 14, 4); break;
    case 'brazier': c.fillStyle = '#2a2a2a'; poly(c, [-16, -30, 16, -30, 8, -16, 4, 0, -4, 0, -8, -16], '#2a2422', out); for (let i = 0; i < 3; i++) poly(c, [-10 + i * 7, -30, -7 + i * 7 + Math.sin(T * 12 + i) * 2, -48 - Math.sin(T * 9 + i) * 5, -4 + i * 7, -30], i % 2 ? '#ffd040' : '#ff6a1a'); break;
    case 'urn': c.beginPath(); c.moveTo(-8, 0); c.quadraticCurveTo(-22, -20, -8, -38); c.lineTo(8, -38); c.quadraticCurveTo(22, -20, 8, 0); c.closePath(); c.fillStyle = '#2a6a5a'; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke(); c.strokeStyle = '#c8a040'; c.beginPath(); c.moveTo(-14, -20); c.lineTo(14, -20); c.stroke(); break;
    case 'crystal': poly(c, [-14, 0, -8, -40, 0, -54, 8, -36, 14, 0], 'rgba(170,230,255,0.85)', '#2a6a9a'); poly(c, [-8, -40, 0, -54, 0, 0], 'rgba(255,255,255,0.4)'); break;
    case 'pew': c.fillStyle = '#2a1a14'; c.fillRect(-26, -24, 52, 8); c.fillRect(-26, -46, 6, 46); c.fillRect(20, -46, 6, 46); c.strokeStyle = out; c.strokeRect(-26, -24, 52, 8); poly(c, [-3, -64, 3, -64, 3, -46, -3, -46], '#c8a040'); c.fillStyle = '#c8a040'; c.fillRect(-8, -60, 16, 3); break;
    case 'pod': { const pu = Math.sin(T * 3 + p.x) * 2; c.beginPath(); c.ellipse(0, -24, 16 + pu, 24, 0, 0, 7); c.fillStyle = '#8a2a3a'; c.fill(); c.strokeStyle = out; c.lineWidth = 2; c.stroke(); c.fillStyle = 'rgba(255,200,180,0.3)'; c.beginPath(); c.ellipse(-2, -26, 7, 12, 0, 0, 7); c.fill(); c.fillStyle = 'rgba(40,0,10,0.6)'; c.beginPath(); c.ellipse(-2, -26, 3, 6, 0.4, 0, 7); c.fill(); break; }
    case 'monolith': c.fillStyle = '#08080a'; c.fillRect(-12, -70, 24, 70); c.strokeStyle = 'rgba(255,255,255,0.4)'; c.lineWidth = 1; c.strokeRect(-12, -70, 24, 70); c.fillStyle = `rgba(255,255,255,${0.4 + 0.3 * Math.sin(T * 3 + p.x)})`; c.fillRect(-2, -50, 4, 4); break;
  }
  c.restore();
}
const PROP_COL = { barrel: '#5a3a1a', crate: '#3a2a1e', stump: '#2a0a0a', tomb: '#4a5450', brazier: '#2a2422', urn: '#2a6a5a', crystal: '#bfeaff', pew: '#2a1a14', pod: '#8a2a3a', monolith: '#18181c' };
