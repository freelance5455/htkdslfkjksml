// ===== GAME DATA =====
const WEAPONS = [
  { id: 'executioner', name: 'THE EXECUTIONER', cls: 'sword', dmg: 30, speed: 1.0, range: 112, kb: 260, len: 92, color: '#d8dde6', trail: '#ffffff', special: 'GUILLOTINE', specialDesc: 'Leap and drop a crushing vertical cleave that splits the ground.', desc: 'A massive headsman blade, notched by a thousand necks.', price: 0, unlock: 'Starting weapon' },
  { id: 'bloodfang', name: 'BLOODFANG', cls: 'dual', dmg: 13, speed: 1.75, range: 82, kb: 120, len: 52, color: '#b3202a', trail: '#ff2a3a', special: 'FRENZY', specialDesc: 'Dash through enemies, slicing everything you pass. Hits drink blood.', desc: 'Twin fangs that hunger. Every cut heals you a little.', price: 600, unlock: 'Defeat THE GOBLIN KING', lifesteal: 0.12 },
  { id: 'doomhammer', name: 'THE DOOM HAMMER', cls: 'hammer', dmg: 54, speed: 0.68, range: 104, kb: 460, len: 78, color: '#6d6a72', trail: '#ff9a3c', special: 'EARTHBREAKER', specialDesc: 'Smash the earth. A quake erupts in both directions and launches enemies.', desc: 'Forged from a fallen star. The ground fears it.', price: 1400, unlock: 'Defeat FENRHAL, THE RED HOWL' },
  { id: 'soulreaper', name: 'SOUL REAPER', cls: 'scythe', dmg: 25, speed: 1.05, range: 134, kb: 200, len: 96, color: '#8fe3c8', trail: '#5dffc1', special: 'HARVEST', specialDesc: 'A spinning storm of blades that drags enemies in and steals their souls.', desc: 'It hits behind you too. It always knows where they are.', price: 2400, unlock: 'Defeat AZGHAROTH, THE BURNING', backhit: true },
  { id: 'voidspear', name: 'THE VOID SPEAR', cls: 'spear', dmg: 22, speed: 1.3, range: 170, kb: 180, len: 128, color: '#a67cff', trail: '#8a5cff', special: 'VOID LANCE', specialDesc: 'Hurl a piercing lance of void energy across the entire screen.', desc: 'Its tip exists slightly in another world.', price: 3600, unlock: 'Defeat YMIRR, THE WINTER' },
];

const STAGES = [
  { name: 'THE GOBLIN KINGDOM', sub: 'Where the small things gnaw', sky: ['#2a1d12', '#6b3a1a', '#c2662a'], fog: 'rgba(90,60,30,0.25)', ground: '#2b2116', ground2: '#16100a', bg: 'goblin', weather: 'embers', enemies: ['goblin', 'goblin', 'goblinSpear'], boss: 'goblinKing', props: 'barrel', music: { root: 55, scale: 'phryg', tempo: 104, wave: 'sawtooth', bright: 520, lead: 'square', notes: 0.22 } },
  { name: 'THE HAUNTED SKY', sub: 'Nothing up here has a heartbeat', sky: ['#05040f', '#1b1438', '#45306b'], fog: 'rgba(60,40,110,0.25)', ground: '#1d1a26', ground2: '#0b0a10', bg: 'sky', weather: 'none', enemies: ['bat', 'bat', 'bat'], boss: 'vampireBat', props: 'crate', music: { root: 49, scale: 'dim', tempo: 80, wave: 'triangle', bright: 700, lead: 'sine', notes: 0.35, wind: 0.12 } },
  { name: 'THE BLOOD FOREST', sub: 'The trees remember every scream', sky: ['#0f0204', '#3a0508', '#7a1012'], fog: 'rgba(140,10,20,0.22)', ground: '#1d0b0b', ground2: '#0a0303', bg: 'forest', weather: 'leaves', enemies: ['wolf', 'wolf', 'wolf'], boss: 'bigWolf', props: 'stump', music: { root: 46, scale: 'minor', tempo: 118, wave: 'sawtooth', bright: 380, lead: 'triangle', notes: 0.2, pattern: [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1] } },
  { name: 'THE FORGOTTEN GRAVEYARD', sub: 'Six feet was never enough', sky: ['#030806', '#0e2420', '#2c4a44'], fog: 'rgba(120,170,160,0.18)', ground: '#151c1a', ground2: '#070a09', bg: 'grave', weather: 'mist', enemies: ['skeleton', 'skeleton', 'skeletonArcher'], boss: 'undeadKnight', props: 'tomb', music: { root: 52, scale: 'loc', tempo: 76, wave: 'square', bright: 360, lead: 'sine', notes: 0.3, whispers: true } },
  { name: 'THE BURNING FORTRESS', sub: 'The walls are still screaming', sky: ['#120200', '#4a0a02', '#b53a0a'], fog: 'rgba(255,90,20,0.15)', ground: '#24120a', ground2: '#0d0503', bg: 'fortress', weather: 'embers', enemies: ['demon', 'demon', 'imp'], boss: 'fireDemon', props: 'brazier', music: { root: 41, scale: 'hung', tempo: 128, wave: 'sawtooth', bright: 600, lead: 'sawtooth', notes: 0.18, kick: 80, ticks: true } },
  { name: 'THE SUNKEN KINGDOM', sub: 'They breathe water now', sky: ['#010a10', '#04323d', '#0b6d77'], fog: 'rgba(20,140,150,0.2)', ground: '#0c1e20', ground2: '#030a0b', bg: 'sunken', weather: 'bubbles', enemies: ['fishman', 'fishman', 'crawler'], boss: 'seaMonster', props: 'urn', music: { root: 43, scale: 'dim', tempo: 70, wave: 'sine', bright: 300, lead: 'sine', notes: 0.32, drums: true, wind: 0.09 } },
  { name: 'THE FROZEN WASTELAND', sub: 'The cold keeps them fresh', sky: ['#060c18', '#1d3756', '#7aa7c7'], fog: 'rgba(200,230,255,0.2)', ground: '#c9d8e6', ground2: '#7d93a8', bg: 'ice', weather: 'snow', enemies: ['iceGolem', 'iceWraith', 'iceWraith'], boss: 'frostGiant', props: 'crystal', music: { root: 58, scale: 'minor', tempo: 84, wave: 'triangle', bright: 900, lead: 'sine', notes: 0.3, wind: 0.16 } },
  { name: 'THE ABANDONED CATHEDRAL', sub: 'God left. Something else stayed.', sky: ['#07040a', '#22142a', '#4a2a3e'], fog: 'rgba(200,150,90,0.12)', ground: '#1e1a1c', ground2: '#0a0809', bg: 'cathedral', weather: 'dust', enemies: ['knight', 'knight', 'knight'], boss: 'fallenAngel', props: 'pew', music: { root: 55, scale: 'minor', tempo: 66, wave: 'sawtooth', bright: 800, lead: 'triangle', notes: 0.38, drums: false, whispers: true } },
  { name: 'THE WORLD OF FLESH', sub: 'It is alive. You are inside it.', sky: ['#1a0206', '#5a0e1e', '#a8324a'], fog: 'rgba(200,40,70,0.2)', ground: '#4a1420', ground2: '#1c050a', bg: 'flesh', weather: 'spores', enemies: ['fleshling', 'blob', 'fleshling'], boss: 'abomination', props: 'pod', music: { root: 38, scale: 'phryg', tempo: 96, wave: 'sawtooth', bright: 300, lead: 'square', notes: 0.15, heart: true, wind: 0.02 } },
  { name: "THE EYE'S DOMAIN", sub: 'It was always behind you', sky: ['#000000', '#0a0a0e', '#1c1c24'], fog: 'rgba(255,255,255,0.05)', ground: '#101014', ground2: '#000000', bg: 'void', weather: 'glitch', enemies: ['glitch', 'glitch', 'watcher'], boss: 'theEye', props: 'monolith', music: { root: 36, scale: 'loc', tempo: 60, wave: 'sawtooth', bright: 250, lead: 'sine', notes: 0.2, heart: true, whispers: true } },
];

// kind: humanoid | quad | flyer | blob | special
const ENEMIES = {
  goblin: { kind: 'humanoid', hp: 26, dmg: 7, speed: 120, scale: 0.72, range: 52, cd: 1.2, souls: 3, blood: '#5fae2a', voice: 1.6, style: { skin: '#5c8a2e', skin2: '#3c5e1c', cloth: '#5a3a1e', head: 'goblin', weapon: 'dagger', eye: '#ffde3a' } },
  goblinSpear: { kind: 'humanoid', hp: 32, dmg: 9, speed: 95, scale: 0.78, range: 86, cd: 1.6, souls: 4, blood: '#5fae2a', voice: 1.4, style: { skin: '#4f7d2a', skin2: '#2f4f18', cloth: '#6b2a1a', head: 'goblin', weapon: 'spear', eye: '#ff6a2a', helmet: true } },
  bat: { kind: 'flyer', hp: 20, dmg: 7, speed: 150, scale: 0.8, range: 50, cd: 1.4, souls: 3, blood: '#6a1030', voice: 2.2, style: { body: '#2a1a2e', wing: '#1a0f20', eye: '#ff2a4a' } },
  wolf: { kind: 'quad', hp: 34, dmg: 10, speed: 210, scale: 0.95, range: 70, cd: 1.3, souls: 4, blood: '#a0101a', voice: 1, style: { fur: '#2a2224', fur2: '#141012', eye: '#ff2020' } },
  skeleton: { kind: 'humanoid', hp: 30, dmg: 9, speed: 85, scale: 1.0, range: 62, cd: 1.5, souls: 4, blood: '#d8d2c0', bone: true, voice: 0.8, style: { skin: '#d9d2bc', skin2: '#9c947c', cloth: '#2a2a2a', head: 'skull', weapon: 'sword', eye: '#5dffd0', bones: true } },
  skeletonArcher: { kind: 'humanoid', hp: 24, dmg: 8, speed: 70, scale: 0.95, range: 420, cd: 2.4, ranged: 'arrow', souls: 5, blood: '#d8d2c0', bone: true, voice: 0.8, style: { skin: '#cfc7ae', skin2: '#958d74', cloth: '#3a2a20', head: 'skull', weapon: 'bow', eye: '#5dffd0', bones: true } },
  demon: { kind: 'humanoid', hp: 48, dmg: 12, speed: 100, scale: 1.12, range: 66, cd: 1.4, souls: 6, blood: '#ff7a1a', voice: 0.7, style: { skin: '#8a1a10', skin2: '#4a0a06', cloth: '#1a0a06', head: 'demon', weapon: 'claws', eye: '#ffd21a', horns: true } },
  imp: { kind: 'flyer', hp: 26, dmg: 9, speed: 120, scale: 0.85, range: 380, cd: 2.2, ranged: 'fireball', souls: 5, blood: '#ff7a1a', voice: 2, style: { body: '#b0281a', wing: '#4a0e08', eye: '#ffe23a', imp: true } },
  fishman: { kind: 'humanoid', hp: 46, dmg: 12, speed: 90, scale: 1.05, range: 80, cd: 1.5, souls: 6, blood: '#2adbc0', voice: 0.9, style: { skin: '#2f6a66', skin2: '#163a38', cloth: '#1a2a2a', head: 'fish', weapon: 'trident', eye: '#e8ff7a' } },
  crawler: { kind: 'blob', hp: 30, dmg: 10, speed: 130, scale: 0.8, range: 50, cd: 1.2, souls: 5, blood: '#2adbc0', voice: 1.3, style: { body: '#3c6b5e', body2: '#1a3a32', eye: '#e8ff7a', legs: true } },
  iceGolem: { kind: 'humanoid', hp: 90, dmg: 18, speed: 60, scale: 1.4, range: 80, cd: 2.0, souls: 9, blood: '#bff4ff', voice: 0.5, heavy: true, style: { skin: '#8ec8e8', skin2: '#3d7aa8', cloth: '#5a9ac8', head: 'ice', weapon: 'fists', eye: '#e0ffff' } },
  iceWraith: { kind: 'flyer', hp: 34, dmg: 11, speed: 110, scale: 1.0, range: 360, cd: 2.0, ranged: 'icicle', souls: 6, blood: '#bff4ff', voice: 1.5, style: { body: '#c8e6ff', wing: '#6a9ac8', eye: '#00f0ff', wraith: true } },
  knight: { kind: 'humanoid', hp: 70, dmg: 15, speed: 85, scale: 1.12, range: 76, cd: 1.5, souls: 8, blood: '#8a1a3a', armor: true, voice: 0.75, style: { skin: '#4a4650', skin2: '#2a2830', cloth: '#5a1a2a', head: 'helm', weapon: 'sword', eye: '#ff3a8a', cape: '#3a0a18' } },
  fleshling: { kind: 'humanoid', hp: 50, dmg: 14, speed: 115, scale: 1.08, range: 64, cd: 1.3, souls: 8, blood: '#c0102a', voice: 1.1, style: { skin: '#c4566a', skin2: '#7a2236', cloth: '#5a1020', head: 'flesh', weapon: 'claws', eye: '#fff4d0' } },
  blob: { kind: 'blob', hp: 60, dmg: 14, speed: 75, scale: 1.25, range: 60, cd: 1.6, souls: 9, blood: '#c0102a', voice: 0.7, style: { body: '#b03a52', body2: '#5a1020', eye: '#fff4d0', mouths: true } },
  glitch: { kind: 'humanoid', hp: 60, dmg: 16, speed: 120, scale: 1.05, range: 66, cd: 1.3, souls: 10, blood: '#ffffff', teleport: true, voice: 0.6, style: { skin: '#0a0a0a', skin2: '#000000', cloth: '#050505', head: 'shadow', weapon: 'claws', eye: '#ffffff', glitch: true } },
  watcher: { kind: 'flyer', hp: 44, dmg: 13, speed: 90, scale: 1.0, range: 420, cd: 2.0, ranged: 'eyebolt', souls: 10, blood: '#ffffff', voice: 0.6, style: { body: '#e8e4dc', wing: '#202020', eye: '#ff0000', eyeball: true } },
};

const BOSSES = {
  goblinKing: { name: 'GRUBNAK, THE GOBLIN KING', title: 'Tyrant of the Rot Throne', kind: 'humanoid', hp: 520, dmg: 16, scale: 2.0, speed: 90, attacks: ['slam', 'charge', 'summon', 'bombs'], minion: 'goblin', blood: '#5fae2a', voice: 1.0, style: { skin: '#6a9a34', skin2: '#3a5a1a', cloth: '#7a1a1a', head: 'goblin', weapon: 'club', eye: '#ff2a1a', crown: true, belly: true }, reward: 'bloodfang', souls: 120 },
  vampireBat: { name: 'NOCTURNA, THE BLOOD MOTHER', title: 'She who drinks the moon', kind: 'flyer', hp: 600, dmg: 15, scale: 3.0, speed: 160, attacks: ['swoop', 'sonic', 'summon', 'bloodrain'], minion: 'bat', blood: '#6a1030', voice: 1.4, style: { body: '#3a1a30', wing: '#22101c', eye: '#ff1a3a', boss: true }, souls: 150 },
  bigWolf: { name: 'FENRHAL, THE RED HOWL', title: 'Hunger given a body', kind: 'quad', hp: 700, dmg: 18, scale: 2.4, speed: 260, attacks: ['pounce', 'charge', 'howl', 'claws'], minion: 'wolf', blood: '#a0101a', voice: 0.6, style: { fur: '#3a1a1a', fur2: '#1a0808', eye: '#ff3a0a', boss: true }, reward: 'doomhammer', souls: 180 },
  undeadKnight: { name: 'SIR HOLLOWMERE', title: 'The Knight Who Would Not Stay Dead', kind: 'humanoid', hp: 820, dmg: 20, scale: 1.9, speed: 110, attacks: ['combo', 'spikes', 'charge', 'summon'], minion: 'skeleton', blood: '#d8d2c0', armor: true, voice: 0.55, style: { skin: '#5a5e62', skin2: '#2a2e32', cloth: '#1a3a34', head: 'helm', weapon: 'greatsword', eye: '#5dffd0', cape: '#0a2420', crown: false, bones: false }, souls: 220 },
  fireDemon: { name: 'AZGHAROTH, THE BURNING', title: 'The fire that learned to hate', kind: 'humanoid', hp: 950, dmg: 22, scale: 2.5, speed: 90, attacks: ['fireballs', 'meteor', 'breath', 'leap'], minion: 'imp', blood: '#ff7a1a', voice: 0.45, style: { skin: '#a8200e', skin2: '#4a0804', cloth: '#1a0804', head: 'demon', weapon: 'claws', eye: '#fff23a', horns: true, flames: true, wings: 'demon' }, reward: 'soulreaper', souls: 260 },
  seaMonster: { name: 'THE DROWNED MOTHER', title: 'Ancient. Patient. Hungry.', kind: 'sea', hp: 1100, dmg: 22, scale: 1, speed: 0, attacks: ['tentacle', 'ink', 'wave', 'summon'], minion: 'crawler', blood: '#2adbc0', voice: 0.4, style: {}, souls: 300 },
  frostGiant: { name: 'YMIRR, THE WINTER', title: 'The cold that walks', kind: 'humanoid', hp: 1300, dmg: 26, scale: 3.0, speed: 70, attacks: ['stomp', 'icerain', 'boulder', 'freeze'], minion: 'iceWraith', blood: '#bff4ff', voice: 0.35, heavy: true, style: { skin: '#9ccce8', skin2: '#4a80a8', cloth: '#3a4a5a', head: 'giant', weapon: 'iceclub', eye: '#00f0ff', beard: true }, reward: 'voidspear', souls: 340 },
  fallenAngel: { name: 'SERAPHIEL, THE FALLEN', title: 'Heaven threw her away', kind: 'humanoid', fly: true, hp: 1400, dmg: 26, scale: 1.7, speed: 180, attacks: ['spearrain', 'dash', 'holybeam', 'feathers'], minion: 'knight', blood: '#ffe9a0', voice: 1.2, style: { skin: '#e8dccc', skin2: '#a89880', cloth: '#d8d0c0', head: 'angel', weapon: 'holyspear', eye: '#ffffff', wings: 'angel', halo: true }, souls: 400 },
  abomination: { name: 'THE MASS', title: 'Everyone it ever ate is still inside', kind: 'blob', hp: 1700, dmg: 28, scale: 3.4, speed: 70, attacks: ['acid', 'sweep', 'summon', 'roll'], minion: 'fleshling', blood: '#c0102a', voice: 0.3, style: { body: '#b03a52', body2: '#4a0a18', eye: '#fff4d0', mouths: true, boss: true }, souls: 480 },
  theEye: { name: 'THE EYE', title: 'It has been watching you this whole time', kind: 'eye', hp: 2200, dmg: 30, scale: 1, speed: 60, attacks: ['laser', 'stare', 'tentacle', 'glitchwave', 'summon'], minion: 'glitch', blood: '#ffffff', voice: 0.3, style: {}, souls: 1000 },
};

const SHOP = [
  // weapons appear from WEAPONS
  { cat: 'skins', id: 'skin_bone', name: 'Ossuary Bone', desc: 'Weapon carved from the dead.', price: 300, tint: '#e8dcc0' },
  { cat: 'skins', id: 'skin_gold', name: 'Heretic Gold', desc: 'Gilded and cursed.', price: 500, tint: '#e8b83a' },
  { cat: 'skins', id: 'skin_blood', name: 'Bloodsteel', desc: 'It is still wet.', price: 700, tint: '#c0182a' },
  { cat: 'skins', id: 'skin_void', name: 'Voidglass', desc: 'You can see stars inside it.', price: 1100, tint: '#6a3aff' },
  { cat: 'outfits', id: 'out_wanderer', name: 'The Wanderer', desc: 'Hooded leather. Where it all began.', price: 0, colors: { cloak: '#3a2a22', armor: '#5a5048', hood: true, skin: '#c89a7a' } },
  { cat: 'outfits', id: 'out_crimson', name: 'Crimson Knight', desc: 'Plate armor dyed in red.', price: 450, colors: { cloak: '#6a0a12', armor: '#8a8a92', helm: true, skin: '#c89a7a' } },
  { cat: 'outfits', id: 'out_plague', name: 'Plague Doctor', desc: 'A beaked mask. Herbs inside. They don\'t help.', price: 800, colors: { cloak: '#141414', armor: '#3a3028', beak: true, skin: '#c89a7a' } },
  { cat: 'outfits', id: 'out_shadow', name: 'Hollow Shade', desc: 'You are becoming one of them.', price: 1300, colors: { cloak: '#08080c', armor: '#18181f', hood: true, skin: '#202024', glow: '#9fe8ff' } },
  { cat: 'outfits', id: 'out_bone', name: 'Bone Saint', desc: 'Wear their skulls proudly.', price: 1800, colors: { cloak: '#d8ccb0', armor: '#a89c80', skullmask: true, skin: '#c89a7a' } },
  { cat: 'effects', id: 'fx_default', name: 'Pale Steel', desc: 'Clean white slash trails.', price: 0, trail: null },
  { cat: 'effects', id: 'fx_ember', name: 'Hellfire Trail', desc: 'Slashes leave burning embers.', price: 400, trail: '#ff7a1a' },
  { cat: 'effects', id: 'fx_frost', name: 'Frostbite Trail', desc: 'Freezing blue arcs.', price: 400, trail: '#7ae8ff' },
  { cat: 'effects', id: 'fx_blood', name: 'Sanguine Trail', desc: 'Every swing bleeds.', price: 650, trail: '#ff1a2a' },
  { cat: 'effects', id: 'fx_void', name: 'Void Rift Trail', desc: 'Reality tears behind your blade.', price: 900, trail: '#b05aff' },
  { cat: 'finishers', id: 'fin_cleave', name: 'Clean Cleave', desc: 'Finished enemies split in two.', price: 0, fin: 'cleave' },
  { cat: 'finishers', id: 'fin_ash', name: 'Ash to Ash', desc: 'Finished enemies crumble into burning ash.', price: 500, fin: 'ash' },
  { cat: 'finishers', id: 'fin_soul', name: 'Soul Rip', desc: 'Tear their soul out as they die.', price: 750, fin: 'soul' },
  { cat: 'finishers', id: 'fin_shatter', name: 'Shatter', desc: 'They break like glass.', price: 1000, fin: 'shatter' },
  { cat: 'extras', id: 'ex_cape', name: 'Tattered Cape', desc: 'A long torn cape flowing behind you.', price: 350 },
  { cat: 'extras', id: 'ex_halo', name: 'Black Halo', desc: 'A ring of darkness over your head.', price: 900 },
  { cat: 'extras', id: 'ex_eyes', name: 'Glowing Eyes', desc: 'Your eyes burn in the dark.', price: 600 },
  { cat: 'extras', id: 'up_hp1', name: 'Vitality Rune I', desc: '+20 max health (permanent).', price: 500, upgrade: 'hp' },
  { cat: 'extras', id: 'up_hp2', name: 'Vitality Rune II', desc: '+20 max health (permanent).', price: 1200, upgrade: 'hp' },
  { cat: 'extras', id: 'up_hp3', name: 'Vitality Rune III', desc: '+20 max health (permanent).', price: 2500, upgrade: 'hp' },
];

const ACHIEVEMENTS = [
  { id: 'first_blood', name: 'First Blood', desc: 'Kill your first enemy.' },
  { id: 'combo10', name: 'Butcher', desc: 'Land a 10-hit combo.' },
  { id: 'combo30', name: 'Abattoir', desc: 'Land a 30-hit combo.' },
  { id: 'kills100', name: 'Hundred Graves', desc: 'Kill 100 enemies.' },
  { id: 'kills500', name: 'Mass Grave', desc: 'Kill 500 enemies.' },
  { id: 'boss1', name: 'Regicide', desc: 'Defeat the Goblin King.' },
  { id: 'boss5', name: 'Fireproof', desc: 'Defeat Azgharoth.' },
  { id: 'boss9', name: 'Indigestion', desc: 'Defeat The Mass.' },
  { id: 'boss10', name: 'Blind', desc: 'Defeat THE EYE.' },
  { id: 'allweapons', name: 'Arsenal of Ruin', desc: 'Own all five weapons.' },
  { id: 'crashed', name: 'Not Responding', desc: 'Experience... something.' },
  { id: 'back', name: "You're Back", desc: 'Return after the eye took you.' },
  { id: 'shopper', name: 'Blood Money', desc: 'Buy something from the shop.' },
  { id: 'rich', name: 'Hoarder', desc: 'Hold 3000 souls at once.' },
  { id: 'stare', name: 'Don\'t Look', desc: 'Survive THE EYE\'s stare by looking away.' },
  { id: 'menu5', name: 'Staring Contest', desc: 'Stay on the main menu for 60 seconds.' },
  { id: 'destroyer', name: 'Vandal', desc: 'Destroy 50 objects.' },
  { id: 'nohit', name: 'Untouchable', desc: 'Defeat any boss without taking damage.' },
  { id: 'combo50', name: 'Slaughterhouse', desc: 'Land a 50-hit combo.' },
  { id: 'exec1', name: 'Headsman', desc: 'Perform your first execution.' },
  { id: 'exec50', name: 'Royal Executioner', desc: 'Perform 50 executions.' },
  { id: 'combo5', name: 'Five Cuts', desc: 'Finish a full five-hit combo.' },
  { id: 'heavy3', name: 'Full Weight', desc: 'Land a fully charged heavy attack.' },
  { id: 'mastery5', name: 'Bonded', desc: 'Reach mastery level 5 with any weapon.' },
  { id: 'ability1', name: 'Awakened', desc: 'Learn your first combat ability.' },
  { id: 'upgrade1', name: 'Stronger Than Yesterday', desc: 'Buy a character upgrade.' },
  { id: 'phase3', name: 'Last Breath', desc: 'Push a boss into its final phase.' },
  // hidden
  { id: 'insomniac', name: 'Insomniac', desc: 'Play between midnight and 5 a.m.', hidden: true },
  { id: 'poke20', name: 'Stop Touching Me', desc: 'Poke the eye 20 times.', hidden: true },
  { id: 'waited', name: 'Patient', desc: 'Wait for it to respond.', hidden: true },
  { id: 'closer', name: 'No Escape', desc: 'Try to close it.', hidden: true },
  { id: 'perfect10', name: 'Shadow Step', desc: 'Perform 10 perfect dodges.', hidden: true },
  { id: 'iaido', name: 'Iaijutsu', desc: 'Kill an enemy with the very first swing of your draw.', hidden: true },
  { id: 'ghost', name: 'Ghost', desc: 'Clear a whole stage without taking damage.', hidden: true },
  { id: 'master', name: 'Master of Ruin', desc: 'Reach mastery level 10 with any weapon.', hidden: true },
  { id: 'shards', name: 'Seen Everything', desc: 'Find all ten eye shards.', hidden: true },
  { id: 'vanish', name: 'Where Did It Go?', desc: 'Touch the empty socket.', hidden: true },
  { id: 'found', name: 'Found You', desc: 'Catch the eye where it should not be.', hidden: true },
  { id: 'sawit', name: 'I Saw It', desc: 'Stare back at the thing in the distance.', hidden: true },
  { id: 'endless10', name: 'Abyss Walker', desc: 'Survive 10 waves in the Endless Abyss.', hidden: true },
  { id: 'nightmare1', name: 'Wide Awake', desc: 'Clear a stage on Nightmare.', hidden: true },
  { id: 'challenge1', name: 'Masochist', desc: 'Clear a stage with a secret challenge.', hidden: true },
  { id: 'relic1', name: 'Grave Robber', desc: 'Find a rare relic.', hidden: true },
  { id: 'secondwind', name: 'Not Yet', desc: 'Come back from death with Second Wind.', hidden: true },
  { id: 'percy', name: 'Good Boy', desc: 'Find Percy.', hidden: true },
  { id: 'percygone', name: 'He Was a Good Boy', desc: 'Lose Percy. Forever.', hidden: true },
  { id: 'percyboss', name: 'Best Friends', desc: 'Defeat a boss with Percy at your side.', hidden: true },
  { id: 'comp_vesper', name: 'One-Eyed Omen', desc: 'Call Vesper.', hidden: true },
  { id: 'comp_lantern', name: 'Small Light', desc: 'Call Lantern.', hidden: true },
  { id: 'comp_brutus', name: 'Stitched Together', desc: 'Call Brutus.', hidden: true },
  { id: 'compgone', name: 'Gone For Good', desc: 'Lose a companion. Forever.', hidden: true },
  { id: 'deep50', name: 'Halfway Down', desc: 'Clear stage 50.' },
  { id: 'deep100', name: 'The Bottom of the Eye', desc: 'Clear stage 100.' },
];

// ===== PROGRESSION =====
const MASTERY = {
  max: 10,
  need: (lvl) => 80 + 60 * (lvl + 1), // xp to go from lvl -> lvl+1
  perks: [
    { lvl: 2, text: '+4% damage per level with this weapon' },
    { lvl: 3, text: 'Executions heal 12 health' },
    { lvl: 5, text: 'Weapon technique unlocked' },
    { lvl: 8, text: 'Special costs 40 rage instead of 50' },
    { lvl: 10, text: 'Master aura and a golden trail' },
  ],
  tech: {
    executioner: { name: 'IAIDO', text: 'The first swing out of the sheath deals double damage and always crits.' },
    bloodfang: { name: 'BLOODRUSH', text: 'Lifesteal is doubled.' },
    doomhammer: { name: 'UNSTOPPABLE', text: 'You cannot be knocked out of a heavy attack.' },
    soulreaper: { name: "REAPER'S REACH", text: 'Light hits drag enemies toward you.' },
    voidspear: { name: 'IMPALE', text: 'Heavy thrusts pierce every enemy in a line and reach further.' },
  },
};
function masteryOf(id) {
  let xp = (Save.d.mxp && Save.d.mxp[id]) || 0, lvl = 1;
  while (lvl < MASTERY.max && xp >= MASTERY.need(lvl)) { xp -= MASTERY.need(lvl); lvl++; }
  return { lvl, xp, need: lvl >= MASTERY.max ? 0 : MASTERY.need(lvl) };
}

const ABILITIES = [
  { id: 'perfect_dodge', name: "WITCH'S STEP", desc: 'Dodge at the last instant to slow the world around you.', price: 600, req: { cleared: 1 } },
  { id: 'double_jump', name: 'GHOST LEAP', desc: 'Jump a second time in mid-air.', price: 500, req: {} },
  { id: 'air_dash', name: 'SHADOW DASH', desc: 'Dodge while airborne to dash through the air.', price: 800, req: { ability: 'double_jump' } },
  { id: 'counter', name: 'RIPOSTE', desc: 'Attack right after a perfect dodge for a guaranteed critical hit.', price: 900, req: { ability: 'perfect_dodge' } },
  { id: 'plunge_quake', name: 'METEOR FALL', desc: 'Heavy attacks in the air plunge down and release a shockwave.', price: 700, req: { cleared: 2 } },
  { id: 'charge3', name: 'DEEP CHARGE', desc: 'Hold heavy attacks longer to reach a third charge level.', price: 1200, req: { cleared: 3 } },
  { id: 'exec_rage', name: 'BLOODTHIRST', desc: 'Executions restore 30 rage.', price: 1000, req: { cleared: 2 } },
  { id: 'rage_overflow', name: 'OVERFLOW', desc: 'Your rage can build up to 150.', price: 1500, req: { cleared: 4 } },
  { id: 'second_wind', name: 'SECOND WIND', desc: 'Once per stage, rise again at 35% health when you die.', price: 2500, req: { cleared: 5 } },
];
const UPGRADES = [
  { id: 'str', name: 'STRENGTH', desc: '+8% damage per level', prices: [400, 1000, 2200] },
  { id: 'iron', name: 'IRON SKIN', desc: '-8% damage taken per level', prices: [400, 1000, 2200] },
  { id: 'fury', name: 'FURY', desc: '+20% rage gained per level', prices: [350, 900, 2000] },
  { id: 'swift', name: 'SWIFTNESS', desc: '+6% movement and attack speed per level', prices: [450, 1100, 2400] },
];
const RELICS = [
  { id: 'relic_crown', name: 'Crown of Grubnak', desc: 'A gnawed golden crown.', hint: 'Grubnak sometimes drops it. Beating him untouched guarantees it.', boss: 'goblinKing', chance: 0.12, kind: 'extra' },
  { id: 'relic_wings', name: "Nocturna's Wings", desc: 'Leather wings that twitch on their own.', hint: 'Torn from the Blood Mother, if you are lucky.', boss: 'vampireBat', chance: 0.1, kind: 'extra' },
  { id: 'relic_halo', name: 'Broken Halo', desc: 'Still warm. Still holy. Barely.', hint: 'Seraphiel drops it, rarely. Or perform 50 executions.', boss: 'fallenAngel', chance: 0.1, kind: 'extra' },
  { id: 'relic_static', name: 'Static Trail', desc: 'Your blade leaves broken pixels behind.', hint: 'THE EYE drops it, very rarely. Or clear a secret challenge in its domain.', boss: 'theEye', chance: 0.08, kind: 'effect', trail: 'glitch' },
  { id: 'relic_tears', name: 'Weeping Trail', desc: 'Every swing cries blood.', hint: 'Any execution has a tiny chance to drop it.', kind: 'effect', trail: '#8a0010', drip: true },
  { id: 'relic_mask', name: 'Mask of the Watcher', desc: 'Now you are the one who watches.', hint: 'Clear secret challenges on three different stages.', kind: 'outfit', colors: { cloak: '#0b0b0d', armor: '#e8e4dc', skullmask: true, skin: '#c89a7a', glow: '#ff2020' } },
  { id: 'relic_eye', name: 'The Little Eye', desc: 'A small eye that follows you everywhere.', hint: 'Find all ten eye shards hidden in the stages.', kind: 'extra' },
];
const CHALLENGES = [
  { id: 'dark', name: 'LIGHTS OUT', desc: 'Only a small light surrounds you.', unlock: 'Find an eye shard.', souls: 1.5 },
  { id: 'glass', name: 'GLASS BONES', desc: 'Any hit kills you. Souls x3.', unlock: 'Defeat a boss without taking damage, or die 10 times.', souls: 3 },
  { id: 'frenzy', name: 'BLOOD MOON', desc: 'More enemies, faster and angrier. Souls x2.', unlock: 'Land a 30-hit combo.', souls: 2 },
];
// how each enemy reacts to each weapon class: dmg multipliers + behaviour
const REACT = {
  goblin: { dodge: 0.14, block: 0 }, goblinSpear: { dodge: 0.08, block: 0.15, w: { hammer: 1.2 } },
  bat: { dodge: 0.2, w: { spear: 1.4, scythe: 1.25, hammer: 0.8 } },
  wolf: { dodge: 0.3, w: { spear: 1.2, dual: 1.15 } },
  skeleton: { dodge: 0.06, block: 0.28, w: { hammer: 1.5, spear: 0.7, dual: 0.8 } },
  skeletonArcher: { dodge: 0.12, w: { hammer: 1.4, spear: 0.75 } },
  demon: { dodge: 0.1, block: 0.12, w: { spear: 1.2, scythe: 0.85 } },
  imp: { dodge: 0.22, w: { spear: 1.35, scythe: 1.2, hammer: 0.8 } },
  fishman: { dodge: 0.1, block: 0.22, w: { executioner: 1.2, sword: 1.2, hammer: 0.9 } },
  crawler: { dodge: 0.18, w: { scythe: 1.3, hammer: 0.75 } },
  iceGolem: { dodge: 0, block: 0.1, w: { hammer: 1.6, dual: 0.6, sword: 0.85 } },
  iceWraith: { dodge: 0.2, w: { spear: 1.35, scythe: 1.3, hammer: 0.8 } },
  knight: { dodge: 0.05, block: 0.45, w: { sword: 0.75, dual: 0.6, hammer: 1.5, spear: 1.15 } },
  fleshling: { dodge: 0.1, w: { sword: 1.2, dual: 1.15 } },
  blob: { dodge: 0, w: { hammer: 0.7, scythe: 1.35, sword: 1.2 } },
  glitch: { dodge: 0.32, w: { scythe: 1.5, sword: 0.85 } },
  watcher: { dodge: 0.18, w: { spear: 1.4, scythe: 1.2 } },
};
// how enemies adapt to the weapon you hold
const WEAPON_AI = { sword: { dodge: 1, block: 1, approach: 1 }, dual: { dodge: 0.6, block: 1.5, approach: 0.9 }, hammer: { dodge: 1.7, block: 0.4, approach: 0.85 }, scythe: { dodge: 1.1, block: 0.9, approach: 0.8 }, spear: { dodge: 0.9, block: 1, approach: 1.35 } };
const COMBO_NAMES = {
  sword: ['', '', 'HEADSMAN', '', 'GUILLOTINE STORM'], dual: ['', '', 'FANG DANCE', '', 'THOUSAND BITES'], hammer: ['', '', 'BONECRUSHER', '', 'WORLD BREAKER'], scythe: ['', '', 'REAPING', '', 'DEATH WALTZ'], spear: ['', '', 'SKEWER', '', 'VOID PIERCER'],
};

// ===== SAVE =====
const Save = (() => {
  const KEY = 'eyebehindyou_v1';
  const def = () => ({ souls: 0, unlockedStage: 1, cleared: [], weapons: ['executioner'], equipped: 'executioner', owned: ['out_wanderer', 'fx_default', 'fin_cleave'], outfit: 'out_wanderer', skin: null, effect: 'fx_default', finisher: 'fin_cleave', extras: [], hpUp: 0, ach: [], kills: 0, destroyed: 0, music: 0.6, sfx: 0.8, shake: true, fps: true, haptics: true, crashes: 0, lastCrash: 0, visits: 0, lastVisit: 0, menuTime: 0,
    mxp: {}, abilities: [], upg: { str: 0, iron: 0, fury: 0, swift: 0 }, relics: [], shards: [], challengeDone: [], mods: [], nightmare: false, nmCleared: [], endlessBest: 0, executions: 0, perfectDodges: 0, deaths: 0, seenIntro: [], quality: 'auto', ctlSize: 1, swapSides: false, fullscreen: true, ver: 2, percy: '', percyOn: true, percyDiedAt: 0, percyStage: -1, percyKills: 0, comp: {}, compDied: {}, xTaps: 0,
    mem: { deaths: {}, killedBy: {}, wuse: {}, quits: 0, pokes: 0, stareFails: 0, staresPassed: 0, lastStage: -1, lastResult: '', lastBoss: '', sessions: 0, firstSeen: 0, playTime: 0, pauses: 0, bestCombo: 0, switches: 0, bought: 0, said: {} } });
  let d;
  let mem = null;
  const memStore = (() => { try { const k = '__eye_t'; localStorage.setItem(k, '1'); localStorage.removeItem(k); return localStorage; } catch (e) { return null; } })();
  try { const raw = JSON.parse((memStore && memStore.getItem(KEY)) || '{}'); const base = def(); d = Object.assign(base, raw); ['upg', 'mem'].forEach(k => { d[k] = Object.assign(def()[k], raw[k] || {}); }); if (!d.mxp) d.mxp = {}; } catch (e) { d = def(); }
  const S = { d };
  S.persistent = !!memStore;
  S.save = () => { try { if (memStore) memStore.setItem(KEY, JSON.stringify(d)); } catch (e) {} };
  S.reset = () => { const keepCrash = d.crashes, keepMem = d.mem; S.d = d = def(); d.crashes = keepCrash; d.mem = keepMem; S.save(); };
  return S;
})();

// ===== STAGES 11-100: THE DEEPER DARK (unlocks after the Eye falls) =====
const SD = i => i < 10 ? i : 9 + (i - 9) * 0.25; // difficulty index: smooth curve so 100 stages stay fair
const bossName = S => BOSSES[S.boss].name + (S.tier ? ' \u00b7 ECHO ' + S.tier : '');
(function () {
  const base = STAGES.slice(0, 10);
  const PFX = ['ECHOED', 'DEEPER', 'BLEEDING', 'HOLLOW', 'SCREAMING', 'FORGOTTEN', 'ABYSSAL', 'ETERNAL', 'AWAKENED'];
  const SUBS = ['It remembers you.', 'The floor is thinner here.', 'Something kept the lights on.', 'You have been here before.', 'The silence has teeth.', 'Do not count the footsteps.', 'It learned your name.', 'Nothing here is asleep.', 'The last place that still has a door.', 'Turn around. Please.'];
  const toHsl = (r, g, b) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0; if (mx !== mn) { const dd = mx - mn; s = l > 0.5 ? dd / (2 - mx - mn) : dd / (mx + mn); h = mx === r ? (g - b) / dd + (g < b ? 6 : 0) : mx === g ? (b - r) / dd + 2 : (r - g) / dd + 4; h *= 60; } return [h, s, l]; };
  const toRgb = (h, s, l) => { h = ((h % 360) + 360) % 360 / 360; if (s === 0) return [l * 255, l * 255, l * 255]; const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q, f = t => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 0.5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; }; return [f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255]; };
  const rotRgb = (r, g, b, deg) => { const [h, s, l] = toHsl(r, g, b); return toRgb(h + deg, s, l).map(v => Math.round(v)); };
  const rot = (str, deg) => str.replace(/#([0-9a-f]{6})/gi, (m, h) => { const [r, g, b] = rotRgb(parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4), 16), deg); return '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join(''); })
    .replace(/rgba\((\d+),\s*(\d+),\s*(\d+)/g, (m, r, g, b) => { const [R2, G2, B2] = rotRgb(+r, +g, +b, deg); return `rgba(${R2},${G2},${B2}`; });
  for (let i = 10; i < 100; i++) {
    const t = Math.floor(i / 10), b = base[i % 10], deg = t * 41;
    const extra = t >= 2 ? base[(i + t * 3) % 10].enemies.slice(0, 2) : [];
    const S = Object.assign({}, b, {
      tier: t, name: (i % 10 === 9 ? PFX[t - 1] + ' DOMAIN OF THE EYE' : PFX[t - 1] + ' ' + b.name.replace(/^THE /, '')), sub: SUBS[(i * 7 + t) % 10],
      sky: b.sky.map(x => rot(x, deg)), fog: rot(b.fog, deg), ground: rot(b.ground, deg), ground2: rot(b.ground2, deg), enemies: Array.from(new Set(b.enemies.concat(extra)))
    });
    STAGES.push(S);
  }
  STAGES[99].name = 'THE EYE AWAKENED'; STAGES[99].sub = 'It stopped pretending.';
})();

// ===== SECRET COMPANIONS (About -> tap X: 15 / 20 / 30). Like Percy, if they fall they are gone forever. =====
const COMPANIONS = {
  vesper: { id: 'vesper', name: 'VESPER', taps: 15, kind: 'raven', fly: true, hp: 110, hpg: 9, dmg: 12, dg: 2.5, desc: 'A one-eyed raven. She dives at whatever hurts you. If she falls, she does not rise.' },
  lantern: { id: 'lantern', name: 'LANTERN', taps: 20, kind: 'wisp', fly: true, hp: 90, hpg: 8, dmg: 10, dg: 2.2, desc: 'A drowned child\'s lantern with something kind inside. It burns enemies from afar. If the flame goes out, it stays out.' },
  brutus: { id: 'brutus', name: 'BRUTUS', taps: 30, kind: 'golem', fly: false, hp: 420, hpg: 30, dmg: 26, dg: 5, desc: 'Stitched together from every grave you left. He smashes everything near you. If he breaks, he stays broken.' }
};
