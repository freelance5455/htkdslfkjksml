// ===== PLAY: the cinematic globe + jumpscare transition =====
const Globe = (() => {
  const Gl = {};
  let cv, c, w, h, dpr, running = false, last = 0, T = 0, proj = null, path = null, world = null, grat = null, rot = [0, -18, 0], spin = 8, drag = null, picked = null, hover = null, phase = 'spin', phaseT = 0, onDone = null, stars = [], dots = [], loadP = null, R = 200;
  const PLACES = ['THE NORTHERN WASTES', 'THE DROWNED COAST', 'THE QUIET PLAINS', 'THE OLD MOUNTAINS', 'THE FORGOTTEN ISLES'];
  function load() {
    if (loadP) return loadP;
    loadP = (async () => {
      if (!window.d3 || !window.topojson) return null;
      const r = await fetch('lib/countries-110m.json'); const topo = await r.json();
      const fc = topojson.feature(topo, topo.objects.countries); world = fc.features.filter(f => f.properties && f.properties.name !== 'Antarctica');
      return world;
    })().catch(() => null);
    return loadP;
  }
  Gl.preload = load;
  Gl.init = () => {
    cv = document.getElementById('globeCanvas'); c = cv.getContext('2d');
    window.addEventListener('resize', resize);
    for (let i = 0; i < 220; i++) stars.push({ x: Math.random(), y: Math.random(), r: Math.random() * 1.4, a: Math.random() });
    for (let i = 0; i < 26; i++) dots.push({ lon: rnd(-180, 180), lat: rnd(-55, 70), ph: Math.random() * 6 });
    cv.addEventListener('pointerdown', e => { if (phase !== 'spin') return; cv.setPointerCapture(e.pointerId); drag = { x: e.clientX, y: e.clientY, r0: rot.slice(), moved: 0, t: performance.now() }; });
    cv.addEventListener('pointermove', e => { if (drag) { const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.moved = Math.max(drag.moved, Math.hypot(dx, dy)); const k = 90 / R; rot = [drag.r0[0] + dx * k * 0.8, clamp(drag.r0[1] - dy * k * 0.8, -70, 70), 0]; } else if (phase === 'spin') hover = featureAt(e.clientX, e.clientY); });
    const up = (e) => { if (!drag) return; const d = drag; drag = null; if (d.moved < 10 && performance.now() - d.t < 600) choose(e.clientX, e.clientY); };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', () => drag = null);
    document.getElementById('globeBack').onclick = () => { if (phase !== 'spin') return; AudioSys.play('ui'); Gl.hide(); Gl.onBack && Gl.onBack(); };
  };
  function resize() {
    if (!cv) return; dpr = Math.min(window.devicePixelRatio || 1, 2); w = window.innerWidth; h = window.innerHeight;
    cv.width = w * dpr; cv.height = h * dpr; cv.style.width = w + 'px'; cv.style.height = h + 'px';
    R = Math.min(w * 0.42, h * 0.36); if (window.d3) { proj = d3.geoOrthographic().scale(R).translate([w / 2, h * 0.56]).clipAngle(90); path = d3.geoPath(proj, c); grat = d3.geoGraticule10(); }
  }
  function featureAt(x, y) { if (!proj || !world) return null; const ll = proj.invert([x, y]); if (!ll || Math.hypot(x - w / 2, y - h * 0.56) > R) return null; for (const f of world) if (d3.geoContains(f, ll)) return f; return null; }
  function choose(x, y) {
    if (Math.hypot(x - w / 2, y - h * 0.56) > R * 1.02) return;
    const f = featureAt(x, y); let name = f ? f.properties.name.toUpperCase() : null;
    if (!name) { const ll = proj && proj.invert([x, y]); name = ll ? (ll[1] > 60 ? 'THE FROZEN NORTH' : ll[1] < -50 ? 'THE BOTTOM OF THE WORLD' : 'THE DEEP OCEAN') : PLACES[Math.random() * PLACES.length | 0]; }
    picked = { f, name, x, y }; phase = 'stop'; phaseT = 0; AudioSys.play('uiBig'); AudioSys.play('heartbeat', 1.2);
    const info = document.getElementById('globeInfo'); info.textContent = name; info.classList.add('show');
    document.getElementById('globeTitle').classList.add('fade');
  }
  Gl.show = (stageIdx, done) => {
    onDone = done; phase = 'spin'; phaseT = 0; picked = null; hover = null; spin = 8; T = 0;
    resize(); load().then(() => resize());
    const scr = document.getElementById('scr-globe'); scr.classList.add('on');
    document.getElementById('globeInfo').className = 'globe-info'; document.getElementById('globeInfo').textContent = '';
    document.getElementById('globeTitle').className = 'globe-title';
    document.getElementById('globeStage').textContent = 'NEXT: STAGE ' + (stageIdx + 1) + ' — ' + STAGES[stageIdx].name;
    const sc = document.getElementById('scare'); sc.className = 'scare';
    AudioSys.music({ root: 40, scale: 'loc', tempo: 58, wave: 'triangle', bright: 400, lead: 'sine', notes: 0.2, wind: 0.14, heart: true });
    running = true; last = performance.now(); requestAnimationFrame(loop);
  };
  Gl.hide = () => { running = false; document.getElementById('scr-globe').classList.remove('on'); };
  function loop(now) { if (!running) return; const dt = Math.min(0.05, (now - last) / 1000); last = now; T += dt; update(dt); draw(); requestAnimationFrame(loop); }
  function update(dt) {
    phaseT += dt;
    if (phase === 'spin') { if (!drag) rot[0] += spin * dt; }
    else if (phase === 'stop') {
      // ease rotation so the chosen place faces us
      if (picked.f && window.d3) { const cen = d3.geoCentroid(picked.f); const tgt = [-cen[0], -cen[1] * 0.7]; let d0 = ((tgt[0] - rot[0] + 540) % 360) - 180; rot[0] += d0 * Math.min(1, dt * 3); rot[1] += (tgt[1] - rot[1]) * Math.min(1, dt * 3); }
      if (phaseT > 1.6) { phase = 'dark'; phaseT = 0; AudioSys.stopMusic(); AudioSys.play('whisper', 1.6); }
    } else if (phase === 'dark') {
      if (phaseT > 1.4) { phase = 'creature'; phaseT = 0; const sc = document.getElementById('scare'); sc.className = 'scare lurk'; AudioSys.play('growl', 0.5, 1.4); }
    } else if (phase === 'creature') {
      if (phaseT > 1.5 && !Gl._jumped) { Gl._jumped = true; const sc = document.getElementById('scare'); sc.className = 'scare jump'; AudioSys.play('jumpscare'); if (Save.d.haptics && navigator.vibrate) try { navigator.vibrate([80, 40, 160]); } catch (e) {} }
      if (phaseT > 2.6) { phase = 'after'; phaseT = 0; Gl._jumped = false; const sc = document.getElementById('scare'); sc.className = 'scare gone'; AudioSys.play('glitch', 0.5); }
    } else if (phase === 'after') {
      if (phaseT > 1.7) { phase = 'done'; Gl.hide(); onDone && onDone(); }
    }
  }
  function draw() {
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.fillStyle = '#020104'; c.fillRect(0, 0, w, h);
    stars.forEach(s => { c.fillStyle = `rgba(255,240,230,${s.a * (0.5 + 0.5 * Math.sin(T * 2 + s.x * 40))})`; c.fillRect(s.x * w, s.y * h, s.r, s.r); });
    const cx = w / 2, cy = h * 0.56;
    // atmosphere glow
    let g = c.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.35); g.addColorStop(0, 'rgba(160,20,20,0.45)'); g.addColorStop(1, 'rgba(160,20,20,0)'); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, R * 1.35, 0, 7); c.fill();
    // ocean
    g = c.createRadialGradient(cx - R * 0.35, cy - R * 0.35, R * 0.1, cx, cy, R); g.addColorStop(0, '#2a1418'); g.addColorStop(0.7, '#12080c'); g.addColorStop(1, '#050204'); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, R, 0, 7); c.fill();
    if (proj && world) {
      proj.rotate(rot);
      c.beginPath(); path(grat); c.strokeStyle = 'rgba(255,80,80,0.08)'; c.lineWidth = 1; c.stroke();
      c.beginPath(); world.forEach(f => path(f)); c.fillStyle = '#3a2224'; c.fill(); c.strokeStyle = 'rgba(255,120,110,0.28)'; c.lineWidth = 0.7; c.stroke();
      if (hover && phase === 'spin') { c.beginPath(); path(hover); c.fillStyle = 'rgba(200,30,40,0.55)'; c.fill(); }
      if (picked && picked.f) { c.beginPath(); path(picked.f); c.fillStyle = `rgba(230,20,30,${0.6 + 0.3 * Math.sin(T * 8)})`; c.fill(); c.strokeStyle = '#ff6060'; c.lineWidth = 1.5; c.stroke(); }
      // pulsing dread markers
      dots.forEach(d => { const p = proj([d.lon, d.lat]); const vis = d3.geoDistance([d.lon, d.lat], [-rot[0], -rot[1]]) < Math.PI / 2; if (!p || !vis) return; const k = 0.5 + 0.5 * Math.sin(T * 2 + d.ph); c.fillStyle = `rgba(255,40,30,${0.4 + k * 0.5})`; c.beginPath(); c.arc(p[0], p[1], 1.6 + k * 1.5, 0, 7); c.fill(); });
    } else {
      // fallback procedural globe
      c.save(); c.beginPath(); c.arc(cx, cy, R, 0, 7); c.clip(); c.strokeStyle = 'rgba(255,90,90,0.2)';
      for (let i = 0; i < 12; i++) { const a = ((i * 30 + rot[0]) % 360) * D2R; const rx = Math.abs(Math.cos(a)) * R; c.beginPath(); c.ellipse(cx, cy, rx, R, 0, 0, 7); c.stroke(); }
      for (let i = -2; i <= 2; i++) { c.beginPath(); c.ellipse(cx, cy + i * R * 0.35, Math.sqrt(1 - (i * 0.35) ** 2) * R, R * 0.06, 0, 0, 7); c.stroke(); }
      for (let i = 0; i < 9; i++) { const a = (i * 40 + rot[0]) * D2R; const x = cx + Math.sin(a) * R * 0.7; if (Math.cos(a) < 0) continue; c.fillStyle = '#3a2224'; c.beginPath(); c.ellipse(x, cy + Math.sin(i * 2.3) * R * 0.5, R * 0.18 * Math.cos(a), R * 0.12, 0, 0, 7); c.fill(); }
      c.restore();
    }
    // shading terminator
    g = c.createRadialGradient(cx - R * 0.4, cy - R * 0.4, R * 0.2, cx + R * 0.2, cy + R * 0.2, R * 1.2); g.addColorStop(0, 'rgba(255,200,180,0.08)'); g.addColorStop(0.6, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.75)'); c.fillStyle = g; c.beginPath(); c.arc(cx, cy, R, 0, 7); c.fill();
    // eye reflection on the globe — something watches
    if (phase === 'spin') { const a = 0.06 + 0.04 * Math.sin(T * 0.7); c.fillStyle = `rgba(255,255,255,${a})`; c.beginPath(); c.ellipse(cx + R * 0.45, cy - R * 0.5, R * 0.1, R * 0.05, -0.5, 0, 7); c.fill(); }
    // vignette
    g = c.createRadialGradient(cx, cy, R, w / 2, h / 2, Math.max(w, h) * 0.8); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.85)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    // darkness phases
    let dark = 0; if (phase === 'stop') dark = clamp((phaseT - 0.8) / 0.8, 0, 1) * 0.6; if (phase === 'dark') dark = 0.6 + clamp(phaseT / 0.8, 0, 1) * 0.4; if (phase === 'creature' || phase === 'after') dark = 1;
    if (dark) { c.fillStyle = `rgba(0,0,0,${dark})`; c.fillRect(0, 0, w, h); }
    if (phase === 'dark' && phaseT > 0.6) { c.fillStyle = `rgba(200,200,200,${clamp((phaseT - 0.6), 0, 0.5) * 0.4})`; c.font = 'italic 16px Georgia'; c.textAlign = 'center'; c.fillText('something is coming up the stairs', w / 2, h / 2); }
    if (phase === 'after') { const a = Math.sin(clamp(phaseT / 1.7, 0, 1) * Math.PI); c.fillStyle = `rgba(220,30,30,${a})`; c.font = `900 ${Math.min(34, w * 0.06)}px Cinzel, Georgia`; c.textAlign = 'center'; c.fillText('IT FOLLOWED YOU THERE.', w / 2 + rnd(-1.5, 1.5), h / 2); }
  }
  return Gl;
})();
