The Eye Behind You - Android project (Capacitor 7)
Build: npm install ; npx cap sync android ; cd android ; ./gradlew assembleRelease
Needs JDK 21 + Android SDK 35. Output: android/app/build/outputs/apk/release/app-release.apk
KEEP keystore/eye-release.jks (password: eyebehindyou). Future updates must be signed with this same key
or Android will refuse to install them over the old version.
Game files live in www/ (same game as the web version, with fonts and libraries bundled for offline play).
