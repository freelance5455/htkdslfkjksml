const KEY="rvv_data_v1";
let data=JSON.parse(localStorage.getItem(KEY)||'null')||{
 properties:[
  {name:"Kidana Plot 76",type:"1 BHK / Residential",price:"₹15 Lac",status:"Available"},
  {name:"Plot 302",type:"Residential Plot",price:"₹11.50 Lac booking",status:"Booked/Enquiry"},
  {name:"Row House",type:"Ground Floor Row House",price:"On enquiry",status:"Coming Soon"}
 ],
 customers:[]
};
const save=()=>localStorage.setItem(KEY,JSON.stringify(data));
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
function render(){
 $("#propertyList").innerHTML=data.properties.map((p,i)=>`<div class="card"><h3>${esc(p.name)}</h3><div class="muted">${esc(p.type)} · ${esc(p.status)}</div><strong>${esc(p.price)}</strong></div>`).join("")||'<p class="muted">No properties yet.</p>';
 $("#customerList").innerHTML=data.customers.map((c,i)=>`<div class="card"><h3>${esc(c.name)}</h3><div class="muted">${esc(c.phone)} · ${esc(c.interest||"General enquiry")}</div><div>${esc(c.note||"")}</div></div>`).join("")||'<p class="muted">No customer enquiries yet.</p>';
}
function bot(text){$("#messages").insertAdjacentHTML("beforeend",`<div class="msg bot">${esc(text)}</div>`);$("#messages").scrollTop=99999}
function user(text){$("#messages").insertAdjacentHTML("beforeend",`<div class="msg user">${esc(text)}</div>`)}
function answer(q){
 const x=q.toLowerCase();
 if(x.includes("property")||x.includes("plot")||x.includes("available")) return `I can show ${data.properties.length} property records. Ask for a plot, row house, villa or price.`;
 if(x.includes("invest")) return "I can record an investment enquiry and connect it to a property. Use Customers → + Add.";
 if(x.includes("book")) return "For a booking enquiry, add the customer's name, phone and property interest in Customers.";
 if(x.includes("hello")||x.includes("hi")) return "Hello! I’m RV Venture AI. Ask me about properties, investment or booking.";
 return "I can help with RV Venture property information, investment enquiries, bookings and customer records. For real AI answers, connect an AI API later.";
}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();let q=$("#chatInput").value.trim();if(!q)return;user(q);$("#chatInput").value="";setTimeout(()=>bot(answer(q)),150)});
document.querySelectorAll(".quick button").forEach(b=>b.onclick=()=>{$("#chatInput").value=b.dataset.q;$("#chatForm").requestSubmit()});
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab,.panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#"+b.dataset.tab).classList.add("active")});
const modal=$("#modal"), mc=$("#modalContent");
function openForm(type){
 mc.innerHTML=type==="property"?`<h2>Add Property</h2><div class="field"><label>Name</label><input id="f1"></div><div class="field"><label>Type</label><input id="f2"></div><div class="field"><label>Price</label><input id="f3"></div><button class="save" id="save">Save</button>`:`<h2>Add Customer</h2><div class="field"><label>Name</label><input id="f1"></div><div class="field"><label>Phone</label><input id="f2"></div><div class="field"><label>Interest</label><input id="f3"></div><div class="field"><label>Note</label><input id="f4"></div><button class="save" id="save">Save</button>`;
 modal.classList.add("show");
 $("#save").onclick=()=>{if(type==="property")data.properties.push({name:$("#f1").value,type:$("#f2").value,price:$("#f3").value,status:"Available"});else data.customers.push({name:$("#f1").value,phone:$("#f2").value,interest:$("#f3").value,note:$("#f4").value});save();render();modal.classList.remove("show")};
}
$("#addProperty").onclick=()=>openForm("property");$("#addCustomer").onclick=()=>openForm("customer");$(".close").onclick=()=>modal.classList.remove("show");
$("#exportBtn").onclick=()=>{const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="rv-venture-data.json";a.click()};
bot("Welcome to RV Venture AI. I can help with properties, investment and customer enquiries.");
render();