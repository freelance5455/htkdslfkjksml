plugins { id("com.android.application") }
android { namespace="com.rvventure.ai"; compileSdk=35
    defaultConfig { applicationId="com.rvventure.ai"; minSdk=23; targetSdk=35; versionCode=1; versionName="1.0" }
}
