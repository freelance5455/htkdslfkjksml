# Vibhav Jewellery Android project

This is an Android WebView wrapper around your supplied HTML app.

## Build the APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `VibhavJewellery` folder.
4. Allow Gradle sync to finish. If prompted, install the Android Gradle Plugin / SDK components.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show a link to the generated APK (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Included
- Original jewellery management HTML app in `app/src/main/assets/index.html`
- Android WebView wrapper with JavaScript and DOM storage enabled
- Portrait layout
- Image / JSON file chooser support
- Backup export to the Downloads folder

## Important
- This project source is prepared, but an APK has **not** been compiled or device-tested in this environment.
- Your app currently stores records in the WebView's local storage on this device. Clearing app data or uninstalling the app can erase records. Use the app's Backup tab regularly and keep backup files somewhere safe.
- Do not use this as your only accounting record until you have tested stock, sales, purchase, payment, backup and restore workflows with sample data.
