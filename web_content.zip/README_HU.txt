WINAMP CLASSIC – HTML TO APK (FÁJLVÁLASZTÓ JAVÍTÁS)
Kezdőfájl: index.html

A ZENE TALLÓZÁSA gomb közvetlenül a látható fájlválasztó HTML-elemre kapja a koppintást, nem egy elrejtett inputot próbál megnyitni.

Telepítés:
1. Csomagold ki a ZIP-et.
2. Az index.html fájlt add meg a HTML to APK konverterben.
3. Engedélyezd a File upload / File chooser / Choose files funkciót.
4. Az internet rádióhoz engedélyezd az Internet access opciót.
5. Generáld újra és telepítsd az APK-t.

FONTOS: Android WebView csak akkor nyitja meg a natív Android fájlválasztót, ha a HTML-to-APK alkalmazás támogatja a WebChromeClient.onShowFileChooser funkciót. Ha a gomb ezután sem nyit tallózót, a konverternek kell támogatnia/engedélyeznie a fájlfeltöltést; ezt önmagában HTML-ből nem lehet kikényszeríteni.
