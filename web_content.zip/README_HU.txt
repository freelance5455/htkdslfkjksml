WINAMP CLASSIC – HTML TO APK
A kezdőfájl: index.html

1. Töltsd le / csomagold ki a ZIP-et.
2. A HTML to APK alkalmazásban válaszd ki az index.html fájlt.
3. Engedélyezd az internetelérést és a helyi fájlválasztót (file input).
4. Állítsd be kezdőoldalnak az index.html-t, majd készíts APK-t.

Funkciók: helyi audiofájlok offline lejátszása, külön internet rádió fül, rádiókeresés, lejátszás/szünet/stop és playlist.
Megjegyzés: az EQ csúszkák jelenleg csak látványelemek. A böngésző/WebView fájlválasztójának működése a használt HTML-to-APK konvertertől függ. A kiválasztott fájlokat előfordulhat, hogy újra ki kell választani az alkalmazás újraindítása után.