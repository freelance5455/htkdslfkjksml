/** GAME 8 — Rhythm Keys. Hit each character inside its timing window. */
import { backdrop, text, roundRect, rngFrom, panel, bar } from './util.js';

const LANES = ['a', 's', 'd', 'f', 'j', 'k', 'l', ';'];

export default {
  id: 'rhythm-keys',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 97);
    const bpm = ctx.difficulty === 'easy' ? 64 : ctx.difficulty === 'hard' ? 108 : 84;
    const beat = 60 / bpm;
    let notes = [];
    let nextBeat = 1.6;
    let hits = 0;
    let perfect = 0;
    let lastResult = '';
    let lastResultAt = -5;
    let speed = 210;

    return {
      update(dt, t) {
        while (t > nextBeat) {
          const lane = Math.floor(rnd() * LANES.length);
          notes.push({ lane, ch: LANES[lane], at: nextBeat, judged: false });
          if (ctx.difficulty === 'hard' && rnd() < 0.35) {
            const lane2 = (lane + 3) % LANES.length;
            notes.push({ lane: lane2, ch: LANES[lane2], at: nextBeat, judged: false });
          }
          nextBeat += beat;
        }
        const strike = ctx.height - 120;
        for (const n of notes) {
          const y = strike - (n.at - t) * speed;
          n.y = y;
          if (!n.judged && y > strike + 46) {
            n.judged = true;
            n.missed = true;
            ctx.miss();
            lastResult = 'MISSED';
            lastResultAt = t;
          }
        }
        notes = notes.filter((n) => n.y < ctx.height + 40);
      },
      onKey(ch) {
        const key = ch.toLowerCase();
        const t = ctx.elapsed / 1000;
        const strike = ctx.height - 120;
        const candidates = notes.filter((n) => !n.judged && n.ch === key);
        if (!candidates.length) {
          ctx.miss();
          lastResult = 'WRONG KEY';
          lastResultAt = t;
          return false;
        }
        candidates.sort((a, b) => Math.abs(a.y - strike) - Math.abs(b.y - strike));
        const note = candidates[0];
        const distance = Math.abs(note.y - strike);
        note.judged = true;
        hits += 1;
        if (distance < 16) { perfect += 1; ctx.hit(24); lastResult = 'PERFECT'; }
        else if (distance < 40) { ctx.hit(14); lastResult = 'GOOD'; }
        else { ctx.hit(5); lastResult = 'LATE'; }
        lastResultAt = t;
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#12111a', bottom: '#0b0a10' });
        const laneW = Math.min(96, (W - 160) / LANES.length);
        const startX = W / 2 - (laneW * LANES.length) / 2;
        const strike = H - 120;

        LANES.forEach((lane, i) => {
          const x = startX + i * laneW;
          g.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.025)' : 'rgba(255,255,255,0.01)';
          g.fillRect(x, 60, laneW - 6, H - 140);
          text(g, lane.toUpperCase(), x + (laneW - 6) / 2, H - 66, { size: 13, align: 'center', color: '#5d6672', weight: '600' });
        });

        // strike line
        g.strokeStyle = 'rgba(224,160,113,0.6)';
        g.lineWidth = 2;
        g.beginPath(); g.moveTo(startX - 10, strike); g.lineTo(startX + laneW * LANES.length, strike); g.stroke();
        g.fillStyle = 'rgba(224,160,113,0.07)';
        g.fillRect(startX - 10, strike - 22, laneW * LANES.length + 10, 44);

        for (const n of notes) {
          if (n.y == null) continue;
          const x = startX + n.lane * laneW + (laneW - 6) / 2;
          const proximity = Math.max(0, 1 - Math.abs(n.y - strike) / 220);
          roundRect(g, x - 26, n.y - 13, 52, 26, 6);
          g.fillStyle = n.judged ? 'rgba(127,179,165,0.25)' : `rgba(${Math.round(120 + proximity * 104)},${Math.round(170 + proximity * 30)},${Math.round(190 - proximity * 40)},${0.55 + proximity * 0.45})`;
          g.fill();
          text(g, n.ch.toUpperCase(), x, n.y + 5, { size: 13, align: 'center', color: '#0f1418', weight: '700' });
        }

        panel(g, 14, 12, 250, 50, { radius: 8 });
        text(g, `${bpm} BPM`, 26, 32, { size: 12, color: '#e9edf1' });
        bar(g, 26, 40, 120, 5, perfect / Math.max(1, hits), { color: '#d9b26a' });
        text(g, `${hits} hit · ${perfect} perfect`, 160, 32, { size: 10, color: '#8d96a3', family: 'system-ui, sans-serif' });

        if (ctx.elapsed / 1000 - lastResultAt < 0.6) {
          text(g, lastResult, W / 2, strike - 60, {
            size: lastResult === 'PERFECT' ? 26 : 20, align: 'center', weight: '700',
            color: lastResult === 'PERFECT' ? '#d9b26a' : lastResult === 'MISSED' || lastResult === 'WRONG KEY' ? '#ef8a8a' : '#7fb3a5',
          });
        }
      },
    };
  },
};
