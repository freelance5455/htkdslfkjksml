/** GAME 12 — Code Sprint. Type symbols and brackets exactly, no autocorrect. */
import { backdrop, text, roundRect, rngFrom, measure, panel, bar } from './util.js';

const SNIPPETS = {
  easy: ['(a + b)', 'x = 1;', '{ }', '[i]', 'n < 10', 'a && b', 'f(x)', 'i++;'],
  normal: ['if (x > 0) {', 'total += n;', 'arr[i] = 0;', 'return true;', 'for (i = 0;', 'a ?? b', '`${id}`', 'x !== y', 'obj.key;', 'p || q;'],
  hard: ['const sum = (a, b) => a + b;', 'if (!ready) { return; }', 'list.map(x => x * 2);', 'a?.b?.[0] ?? c;', '<div class="box">', 'SELECT * FROM t;', '$("#id").on("click", f);', 'let { a, b } = obj;'],
};

export default {
  id: 'code-sprint',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 167);
    const pool = SNIPPETS[ctx.difficulty] ?? SNIPPETS.normal;
    let tokens = [];
    let completed = 0;
    let combo = 0;
    let bestCombo = 0;
    let spawnAt = 0;
    let laneCount = 3;

    function spawn() {
      const code = pool[Math.floor(rnd() * pool.length)];
      tokens.push({
        id: Math.random().toString(36).slice(2),
        code,
        typed: '',
        x: ctx.width + 40,
        y: 150 + Math.floor(rnd() * laneCount) * 110,
        speed: 20 * (ctx.difficulty === 'hard' ? 1.6 : ctx.difficulty === 'easy' ? 0.8 : 1.15),
      });
    }
    spawn();
    spawn();

    return {
      update(dt) {
        spawnAt += dt;
        if (spawnAt > 2.4) { spawnAt = 0; spawn(); }
        for (const t of tokens) t.x -= t.speed * dt;
        const passed = tokens.filter((t) => t.x < 90);
        if (passed.length) {
          tokens = tokens.filter((t) => t.x >= 90);
          combo = 0;
          ctx.status(`${passed.length} commit${passed.length > 1 ? 's' : ''} missed`);
        }
      },
      onKey(ch) {
        const candidates = tokens.filter((t) => (t.typed + ch).startsWith(t.code.slice(0, t.typed.length + 1)));
        const exact = tokens.filter((t) => t.code.startsWith(t.typed + ch));
        const match = exact.length ? exact : candidates;
        if (!match.length) {
          for (const t of tokens) if (t.typed) { t.typed = ''; }
          combo = 0;
          return false;
        }
        // prefer the token already in progress, else the most urgent (closest to the desk)
        let target = match.find((t) => t.typed.length > 0);
        if (!target) target = match.slice().sort((a, b) => a.x - b.x)[0];
        for (const t of tokens) if (t !== target) t.typed = '';
        target.typed += ch;
        if (target.typed === target.code) {
          completed += 1;
          combo += 1;
          bestCombo = Math.max(bestCombo, combo);
          ctx.hit(20 + target.code.length * 3 + Math.min(40, combo * 5));
          ctx.status(`Committed · combo ×${combo}`);
          tokens = tokens.filter((t) => t !== target);
        } else {
          ctx.hit(4);
        }
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#0e1218', bottom: '#0a0d12' });

        // desk / conveyor
        for (let i = 0; i < 3; i += 1) {
          const y = 150 + i * 110;
          g.fillStyle = 'rgba(255,255,255,0.015)';
          g.fillRect(80, y - 24, W - 120, 48);
          g.strokeStyle = 'rgba(255,255,255,0.04)';
          g.strokeRect(80, y - 24, W - 120, 48);
        }
        g.fillStyle = 'rgba(239,138,138,0.12)';
        g.fillRect(72, 120, 8, 330);
        text(g, 'REVIEW', 40, 470, { size: 8.5, color: '#8d96a3', weight: '600' });

        const size = 17;
        for (const t of tokens) {
          const w = measure(g, t.code, size) + 30;
          roundRect(g, t.x - 14, t.y - 20, w, 40, 7);
          g.fillStyle = t.typed ? '#2b3a33' : '#1e242c';
          g.fill();
          g.strokeStyle = t.typed ? '#7fb3a5' : 'rgba(255,255,255,0.12)';
          g.lineWidth = t.typed ? 1.6 : 1;
          g.stroke();
          const done = t.code.slice(0, t.typed.length);
          const rest = t.code.slice(t.typed.length);
          text(g, done, t.x, t.y + 5, { size, color: '#8ee0b8' });
          text(g, rest, t.x + measure(g, done, size), t.y + 5, { size, color: '#dbe2e8' });
        }

        panel(g, 14, 12, 300, 52, { radius: 8 });
        text(g, `${completed} snippets merged`, 26, 32, { size: 12, color: '#e9edf1' });
        text(g, `combo ×${combo} · best ×${bestCombo}`, 26, 50, { size: 10, color: '#8d96a3', family: 'system-ui, sans-serif' });
        bar(g, 230, 26, 70, 5, Math.min(1, combo / 12), { color: '#e0a071' });

        text(g, 'Every bracket and semicolon counts — no auto-complete, no mercy', W / 2, H - 26, {
          size: 12, align: 'center', color: 'rgba(233,237,241,0.4)', family: 'system-ui, sans-serif',
        });
      },
    };
  },
};
