/**
 * Arcade shell.
 *
 * Every game implements the same small contract and receives the same measured
 * keystroke accounting, so accuracy means the same thing in all twelve games:
 *
 *   init(ctx) -> {
 *     update(dt, t)      advance simulation (dt in seconds)
 *     render(g)          draw the current frame
 *     onKey(char)        -> true (correct) | false (wrong) | null (ignore)
 *     resize(w, h)       optional
 *     destroy()          optional cleanup
 *   }
 *
 *   ctx.hit(points)      award points and count a correct keystroke
 *   ctx.miss()           count a wrong keystroke
 *   ctx.finish(outcome)  end the round ('COMPLETE' | 'GAME_OVER')
 *   ctx.status(text)     small hint line under the HUD
 *
 * The shell owns the clock, the score, accuracy, pause/resume, the result
 * screen and the submission to the server (which recomputes the score).
 */
import { api } from '../api.js';
import { el, mount, icon, toast } from '../ui.js';
import { queueActivity } from '../offline.js';
import { registerOverlay } from '../overlays.js';

const COLORS = {
  ink: '#12161c',
  panel: '#1b2028',
  line: 'rgba(255,255,255,0.10)',
  text: '#e9edf1',
  muted: '#8d96a3',
  brand: '#7fb3a5',
  accent: '#e0a071',
  gold: '#d9b26a',
  danger: '#ef8a8a',
  ok: '#8ee0b8',
};

export { COLORS };

export function openGame({ game, difficulty, tokenId, onExit, onReplay }) {
  const state = {
    running: false,
    paused: false,
    startedAt: 0,
    elapsedMs: 0,
    attempts: 0,
    correct: 0,
    errors: 0,
    points: 0,
    level: 0,
    outcome: 'COMPLETE',
    finished: false,
  };

  const durationMs = game.durationSec * 1000;
  let impl = null;
  let raf = 0;
  let lastFrame = 0;
  let resizeObserver = null;

  const scoreEl = el('b', {}, '0');
  const accEl = el('b', {}, '100%');
  const timeEl = el('b', {}, fmt(durationMs));
  const statusEl = el('div', { class: 'game-hud__stat', style: { color: COLORS.muted, marginLeft: '6px' } });

  const hud = el('div', { class: 'game-hud' },
    el('div', { class: 'game-hud__title' }, game.title),
    el('span', { class: 'badge', style: { background: 'rgba(255,255,255,0.08)', color: '#c3cad4', border: '0' } }, difficulty),
    el('div', { class: 'game-hud__stat' }, 'Score ', scoreEl),
    el('div', { class: 'game-hud__stat' }, 'Accuracy ', accEl),
    el('div', { class: 'game-hud__stat' }, 'Time ', timeEl),
    statusEl,
    el('div', { class: 'game-hud__spacer' }),
    el('button', { class: 'btn btn--sm btn--ghost', style: { color: '#c3cad4' }, onclick: pause }, icon('pause', 13), 'Pause'),
    el('button', { class: 'btn btn--sm btn--ghost', style: { color: '#c3cad4' }, onclick: quit }, 'Quit'));

  const canvas = el('canvas', { width: '960', height: '600', style: { display: 'block' } });
  const g = canvas.getContext('2d');
  const overlayHost = el('div', { class: 'game-overlay' });
  const wrap = el('div', { class: 'game-canvas-wrap', tabindex: '0' }, canvas, overlayHost);
  const stage = el('div', { class: 'game-stage', role: 'dialog', 'aria-modal': 'true', 'aria-label': `${game.title} game` }, hud, wrap);
  document.body.appendChild(stage);

  // --------------------------------------------------------------- sizing
  function resize() {
    const rect = wrap.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.max(320, Math.floor(rect.width * dpr));
    canvas.height = Math.max(240, Math.floor(rect.height * dpr));
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (impl?.resize) impl.resize(rect.width, rect.height);
  }
  resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(wrap);
  resize();

  function width() { return canvas.width / Math.min(2, window.devicePixelRatio || 1); }
  function height() { return canvas.height / Math.min(2, window.devicePixelRatio || 1); }

  // ----------------------------------------------------------------- ctx
  // One keystroke must be accounted exactly once. A game may call ctx.hit /
  // ctx.miss itself (most do, because it knows the value of the hit); if it
  // does not, the boolean it returns decides the verdict.
  let accounted = false;

  const ctx = {
    canvas,
    g,
    get width() { return width(); },
    get height() { return height(); },
    difficulty,
    settings: game.difficultySettings ?? {},
    hit(points = 10) {
      if (accounted) { state.points += points; scoreEl.textContent = String(Math.round(state.points)); return; }
      accounted = true;
      state.attempts += 1;
      state.correct += 1;
      state.points += points;
      scoreEl.textContent = String(Math.round(state.points));
      updateAccuracy();
    },
    miss() {
      if (accounted) return;
      accounted = true;
      state.attempts += 1;
      state.errors += 1;
      updateAccuracy();
    },
    level(n) { state.level = n; },
    status(text) { statusEl.textContent = text ?? ''; },
    finish(outcome = 'COMPLETE') { if (!state.finished) finish(outcome); },
    get elapsed() { return state.elapsedMs; },
    get timeLeft() { return Math.max(0, durationMs - state.elapsedMs); },
    get state() { return state; },
  };

  function updateAccuracy() {
    const acc = state.attempts === 0 ? 100 : (state.correct / state.attempts) * 100;
    accEl.textContent = `${acc.toFixed(0)}%`;
    accEl.style.color = acc >= 95 ? COLORS.ok : acc >= 85 ? COLORS.gold : COLORS.danger;
  }

  // --------------------------------------------------------------- input
  function onKeyDown(event) {
    if (event.key === 'Escape') { event.preventDefault(); if (!state.finished) pause(); return; }
    if (!state.running || state.paused || state.finished) return;
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    if (event.key.length !== 1) return;
    event.preventDefault();
    let verdict = null;
    accounted = false;
    try { verdict = impl?.onKey?.(event.key); } catch (err) { console.error(err); }
    if (!accounted) {
      if (verdict === true) ctx.hit(game.pointsPerHit ?? 10);
      else if (verdict === false) ctx.miss();
    }
  }
  window.addEventListener('keydown', onKeyDown);

  // ---------------------------------------------------------------- loop
  function frame(now) {
    raf = requestAnimationFrame(frame);
    if (!state.running || state.paused || state.finished) { lastFrame = now; return; }
    const dt = Math.min(0.05, (now - lastFrame) / 1000 || 0.016);
    lastFrame = now;
    state.elapsedMs = now - state.startedAt;
    timeEl.textContent = fmt(Math.max(0, durationMs - state.elapsedMs));
    if (state.elapsedMs >= durationMs) { finish('COMPLETE'); return; }
    try {
      impl?.update(dt, state.elapsedMs / 1000);
      g.clearRect(0, 0, width(), height());
      impl?.render(g);
    } catch (err) {
      console.error('[bica] game frame error', err);
      finish('GAME_OVER');
    }
  }

  function start() {
    state.running = true;
    state.paused = false;
    state.startedAt = performance.now() - state.elapsedMs;
    lastFrame = performance.now();
    mount(overlayHost);
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
    wrap.focus();
  }

  function pause() {
    if (!state.running || state.finished) return;
    state.paused = true;
    mount(overlayHost, el('div', { class: 'game-overlay__panel' },
      el('h2', {}, 'Paused'),
      el('p', { class: 'muted small' }, 'The clock is stopped. Nothing is being measured while this screen is open.'),
      el('div', { style: { display: 'flex', gap: '10px', marginTop: '16px' } },
        el('button', { class: 'btn btn--primary', onclick: () => { state.paused = false; mount(overlayHost); wrap.focus(); } }, icon('play', 14), 'Resume'),
        el('button', { class: 'btn', onclick: () => { destroy(); if (onReplay) onReplay(); } }, icon('reload', 14), 'Restart'),
        el('button', { class: 'btn btn--ghost', onclick: quit }, 'Quit to arcade'))));
  }

  function quit() {
    if (state.finished) { destroy(); onExit?.(); return; }
    if (!state.running) { destroy(); onExit?.(); return; }
    state.paused = true;
    mount(overlayHost, el('div', { class: 'game-overlay__panel' },
      el('h2', {}, 'Leave this round?'),
      el('p', { class: 'muted small' }, 'The round will not be scored or saved.'),
      el('div', { style: { display: 'flex', gap: '10px', marginTop: '16px' } },
        el('button', { class: 'btn btn--primary', onclick: () => { state.paused = false; mount(overlayHost); wrap.focus(); } }, 'Keep playing'),
        el('button', { class: 'btn btn--danger', onclick: () => { destroy(); onExit?.(); } }, 'Leave'))));
  }

  let unregister = null;
  function destroy() {
    state.running = false;
    cancelAnimationFrame(raf);
    window.removeEventListener('keydown', onKeyDown);
    if (resizeObserver) resizeObserver.disconnect();
    try { impl?.destroy?.(); } catch { /* ignore */ }
    stage.remove();
    if (unregister) { unregister(); unregister = null; }
  }
  unregister = registerOverlay(destroy);

  // -------------------------------------------------------------- finish
  async function finish(outcome) {
    if (state.finished) return;
    state.finished = true;
    state.outcome = outcome;
    state.running = false;
    cancelAnimationFrame(raf);
    const accuracy = state.attempts ? (state.correct / state.attempts) * 100 : 0;
    const minutes = Math.max(1, state.elapsedMs) / 60000;
    const completionBonus = outcome === 'COMPLETE' ? 1 : Math.min(1, state.elapsedMs / durationMs);

    mount(overlayHost, el('div', { class: 'game-overlay__panel' },
      el('h2', {}, 'Submitting round…'),
      el('p', { class: 'muted small' }, 'The server recalculates your score from the raw keystroke counts.')));

    const payload = {
      tokenId,
      clientSessionId: crypto.randomUUID ? crypto.randomUUID() : `g-${Date.now()}`,
      gameId: game.id,
      difficulty,
      levelReached: state.level,
      outcome,
      summary: {
        basePoints: Math.round(state.points),
        accuracy: Number(accuracy.toFixed(1)),
        netWpm: Number(((state.correct / 5) / minutes).toFixed(1)),
        committedChars: state.correct,
        correctChars: state.correct,
        errorKeystrokes: state.errors,
        completionBonus,
      },
      meta: { attempts: state.attempts, elapsedMs: Math.round(state.elapsedMs) },
    };

    let result = null;
    let offline = false;
    try {
      result = await api.post('/api/games/submit', payload);
    } catch (err) {
      if (err.isNetwork) {
        await queueActivity({ kind: 'game', endpoint: '/api/games/submit', payload, label: `${game.title} round` });
        offline = true;
      } else {
        toast(err.message, { type: 'warn' });
      }
    }

    const serverScore = result?.round?.score ?? null;
    const counted = result?.round ? result.round.verified === 1 : true;
    showResults({
      score: serverScore ?? Math.round(state.points * (accuracy / 100) ** 2),
      accuracy,
      offline,
      confirmed: Boolean(serverScore) || Boolean(result?.round),
      counted,
      note: result?.note ?? null,
      stars: counted ? starsFor(accuracy, completionBonus) : 0,
      achievements: result?.newAchievements ?? [],
      outcome,
    });
  }

  function showResults({ score, accuracy, offline, confirmed, counted = true, note = null, stars, achievements, outcome }) {
    const starRow = el('div', { style: { display: 'flex', gap: '6px', margin: '4px 0 14px' } },
      [1, 2, 3].map((n) => el('span', { style: { color: n <= stars ? COLORS.gold : 'var(--line-strong)' } }, icon('award', 22))));

    mount(overlayHost, el('div', { class: 'game-overlay__panel' },
      el('div', { class: 'eyebrow' }, offline ? 'Saved locally · will sync' : counted ? (confirmed ? 'Verified by the server' : 'Round complete') : 'Recorded · not counted'),
      el('h2', {}, outcome === 'COMPLETE' ? 'Round complete' : 'Round over'),
      note ? el('p', { class: 'small', style: { color: 'var(--warn)', marginTop: '0' } }, note) : null,
      offline ? el('p', { class: 'small', style: { color: 'var(--warn)' } },
        'No connection to the lab server. This round is stored on this computer and will be submitted automatically.') : null,
      starRow,
      el('div', { class: 'result__grid', style: { gridTemplateColumns: 'repeat(3, 1fr)' } },
        el('div', { class: 'result__stat' }, el('b', {}, String(score)), el('span', {}, 'score')),
        el('div', { class: 'result__stat' }, el('b', {}, `${accuracy.toFixed(1)}%`), el('span', {}, 'accuracy')),
        el('div', { class: 'result__stat' }, el('b', {}, String(state.correct)), el('span', {}, 'correct keys'))),
      el('p', { class: 'tiny muted', style: { marginTop: '12px', lineHeight: '1.5' } },
        `Score = base points × accuracy² × difficulty. Accuracy was measured from ${state.attempts} keystrokes (${state.errors} wrong). Speed alone cannot raise this score.`),
      achievements.length ? el('div', { style: { marginTop: '12px', display: 'flex', gap: '6px', flexWrap: 'wrap' } },
        achievements.map((a) => el('span', { class: 'badge badge--gold' }, icon('award', 11), a.name))) : null,
      el('div', { style: { display: 'flex', gap: '10px', marginTop: '20px', flexWrap: 'wrap' } },
        el('button', { class: 'btn btn--primary', onclick: () => { destroy(); if (onReplay) onReplay(); } }, icon('reload', 14), 'Play again'),
        el('button', { class: 'btn', onclick: () => { destroy(); onExit?.(); } }, 'Back to arcade'))));
  }

  // ----------------------------------------------------------- instructions
  showInstructions();
  function showInstructions() {
    mount(overlayHost, el('div', { class: 'game-overlay__panel' },
      el('div', { class: 'eyebrow' }, `${game.category} · ${difficulty}`),
      el('h2', {}, game.title),
      el('p', { class: 'muted', style: { marginBottom: '4px' } }, game.tagline),
      el('div', { class: 'game-overlay__rule' },
        el('div', { style: { marginBottom: '8px' } }, el('strong', {}, 'How to play. '), game.mechanic),
        el('div', {}, el('strong', {}, 'Learning objective. '), game.objective),
        el('div', { style: { marginTop: '8px', color: 'var(--ink-500)' } },
          `Keys: ${game.keysHint} · ${game.durationSec} seconds · accuracy is squared into your score.`)),
      el('label', { class: 'check', style: { marginTop: '12px' } },
        el('input', { type: 'checkbox', id: 'game-ready' }),
        el('span', { class: 'small' }, 'I have read the instructions and I am ready to type.')),
      el('div', { style: { display: 'flex', gap: '10px', marginTop: '16px' } },
        el('button', {
          class: 'btn btn--primary btn--lg',
          onclick: () => {
            const ready = document.getElementById('game-ready');
            if (!ready?.checked) { toast('Tick the box to start.', { type: 'warn' }); return; }
            startRound();
          },
        }, icon('play', 15), 'Start round'),
        el('button', { class: 'btn btn--lg btn--ghost', onclick: () => { destroy(); onExit?.(); } }, 'Back'))));
  }

  function startRound() {
    impl = game.create(ctx);
    mount(overlayHost);
    if (impl?.resize) impl.resize(width(), height());
    start();
  }

  return { destroy, stage, state };
}

function fmt(ms) {
  const total = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return m > 0 ? `${m}:${String(s).padStart(2, '0')}` : `${s}s`;
}

function starsFor(accuracy, completion) {
  if (completion < 0.5) return 0;
  if (accuracy >= 98) return 3;
  if (accuracy >= 92) return 2;
  if (accuracy >= 85) return 1;
  return 0;
}
