/** GAME 2 — Bubble Pop. Bubbles drift upward; type a whole word to pop one. */
import { backdrop, text, roundRect, rngFrom, wordPool, diffOf, measure, panel } from './util.js';

export default {
  id: 'bubble-pop',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 7);
    const d = diffOf(ctx.difficulty);
    const pool = wordPool(ctx.difficulty);
    const bubbleColors = ['#2f6b60', '#39566e', '#6b5540', '#4a4668', '#3d6b52'];
    let bubbles = [];
    let buffer = '';
    let activeId = null;
    let combo = 0;
    let spawnAt = 0;
    let popped = 0;
    let escapes = 0;

    function spawn() {
      const word = pool[Math.floor(rnd() * pool.length)];
      const r = 26 + word.length * 5.2;
      bubbles.push({
        id: Math.random().toString(36).slice(2),
        word,
        typed: 0,
        x: 60 + rnd() * Math.max(80, ctx.width - 140),
        y: ctx.height + r,
        r,
        vy: (14 + rnd() * 10) * d.speed,
        color: bubbleColors[Math.floor(rnd() * bubbleColors.length)],
      });
    }

    return {
      update(dt) {
        spawnAt += dt;
        if (spawnAt > Math.max(0.55, 1.5 / d.density)) {
          spawnAt = 0;
          spawn();
        }
        for (const b of bubbles) b.y -= b.vy * dt;
        const escaped = bubbles.filter((b) => b.y + b.r < 0);
        if (escaped.length) {
          escapes += escaped.length;
          for (const b of escaped) {
            if (activeId === b.id) { activeId = null; buffer = ''; }
            combo = 0;
            ctx.status(`${escapes} bubble${escapes > 1 ? 's' : ''} escaped — the word cost you the combo`);
          }
          bubbles = bubbles.filter((b) => b.y + b.r >= 0);
        }
        if (escapes >= 8) { ctx.level(popped); ctx.finish('GAME_OVER'); }
      },
      onKey(ch) {
        const key = ch.toLowerCase();
        const candidate = buffer + key;
        const matches = bubbles.filter((b) => b.word.startsWith(candidate));
        if (matches.length === 0) {
          if (activeId) {
            const b = bubbles.find((x) => x.id === activeId);
            if (b) b.typed = 0;
          }
          buffer = '';
          activeId = null;
          combo = 0;
          return false;
        }
        // Prefer completing the bubble that is already started, otherwise the
        // highest (most urgent) matching bubble.
        let target = matches.find((b) => b.id === activeId);
        if (!target) {
          target = matches.slice().sort((a, b2) => a.y - b2.y)[0];
        }
        if (activeId !== target.id) { buffer = key; target.typed = key.length; activeId = target.id; } else { buffer = candidate; target.typed = buffer.length; }

        if (buffer === target.word) {
          combo += 1;
          popped += 1;
          ctx.hit(18 + Math.min(30, combo * 4) + target.word.length * 2);
          bubbles = bubbles.filter((b) => b.id !== target.id);
          buffer = '';
          activeId = null;
          ctx.status(`Combo ×${combo}`);
        }
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#0f141a', bottom: '#141b22' });

        // water lines
        g.strokeStyle = 'rgba(127,179,165,0.05)';
        for (let i = 0; i < 7; i += 1) {
          g.beginPath();
          g.moveTo(0, 40 + i * ((H - 60) / 7));
          g.bezierCurveTo(W * 0.3, 30 + i * ((H - 60) / 7), W * 0.7, 55 + i * ((H - 60) / 7), W, 40 + i * ((H - 60) / 7));
          g.stroke();
        }

        for (const b of bubbles) {
          g.save();
          g.beginPath();
          g.arc(b.x, b.y, b.r, 0, Math.PI * 2);
          g.fillStyle = b.color;
          g.globalAlpha = 0.92;
          g.fill();
          g.globalAlpha = 1;
          g.strokeStyle = b.id === activeId ? '#e0a071' : 'rgba(255,255,255,0.18)';
          g.lineWidth = b.id === activeId ? 2 : 1;
          g.stroke();
          const tw = measure(g, b.word, 15);
          text(g, b.word, b.x - tw / 2, b.y + 5, { size: 15, color: 'rgba(255,255,255,0.86)' });
          if (b.typed > 0) {
            text(g, b.word.slice(0, b.typed), b.x - tw / 2, b.y + 5, { size: 15, color: '#ffd9a8', weight: '700' });
          }
          g.restore();
        }

        panel(g, 14, 12, 190, 44, { radius: 8 });
        text(g, 'SPELLED', 26, 30, { size: 9, color: '#8d96a3', weight: '600' });
        text(g, `${popped} words`, 26, 46, { size: 13, color: '#e9edf1' });

        if (buffer) {
          text(g, buffer.toUpperCase(), W / 2, H - 28, { size: 20, align: 'center', color: '#e0a071', weight: '700' });
        } else {
          text(g, 'Start typing a word to lock on to its bubble', W / 2, H - 28, {
            size: 12, align: 'center', color: 'rgba(233,237,241,0.4)', family: 'system-ui, sans-serif',
          });
        }
        roundRect(g, 0, 0, 0, 0, 0);
      },
    };
  },
};
