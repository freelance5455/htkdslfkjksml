/** GAME 6 — Keyboard Maze. Move with U/D/L/R keys through a real maze. */
import { backdrop, text, rngFrom, panel } from './util.js';

export default {
  id: 'keyboard-maze',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 67);
    const size = ctx.difficulty === 'easy' ? 7 : ctx.difficulty === 'hard' ? 13 : 9;
    const cell = () => Math.min((ctx.width - 120) / size, (ctx.height - 190) / size);

    /** Recursive-backtracker maze, then knock out extra walls for difficulty. */
    function buildMaze(n) {
      const grid = Array.from({ length: n }, () => Array.from({ length: n }, () => ({ walls: { n: true, s: true, e: true, w: true }, visited: false })));
      const stack = [[0, 0]];
      grid[0][0].visited = true;
      while (stack.length) {
        const [x, y] = stack[stack.length - 1];
        const options = [];
        if (y > 0 && !grid[y - 1][x].visited) options.push([x, y - 1, 'n', 's']);
        if (y < n - 1 && !grid[y + 1][x].visited) options.push([x, y + 1, 's', 'n']);
        if (x > 0 && !grid[y][x - 1].visited) options.push([x - 1, y, 'w', 'e']);
        if (x < n - 1 && !grid[y][x + 1].visited) options.push([x + 1, y, 'e', 'w']);
        if (!options.length) { stack.pop(); continue; }
        const [nx, ny, from, to] = options[Math.floor(rnd() * options.length)];
        grid[y][x].walls[from] = false;
        grid[ny][nx].walls[to] = false;
        grid[ny][nx].visited = true;
        stack.push([nx, ny]);
      }
      // extra openings make the maze less claustrophobic on easy
      if (ctx.difficulty === 'easy') {
        for (let i = 0; i < n; i += 1) {
          const x = Math.floor(rnd() * (n - 1));
          const y = Math.floor(rnd() * n);
          grid[y][x].walls.e = false;
          grid[y][x + 1].walls.w = false;
        }
      }
      return grid;
    }

    const maze = buildMaze(size);
    let pos = { x: 0, y: 0 };
    let steps = 0;
    let bumps = 0;
    let level = 1;
    let cleared = 0;
    const goal = { x: size - 1, y: size - 1 };

    return {
      update() {
        if (pos.x === goal.x && pos.y === goal.y) {
          cleared += 1;
          level += 1;
          ctx.hit(120 + Math.max(0, 60 - steps * 3));
          ctx.status(`Maze ${cleared} cleared in ${steps} steps`);
          steps = 0;
          if (cleared >= 3) { ctx.level(cleared); ctx.finish('COMPLETE'); }
        }
      },
      onKey(ch) {
        const key = ch.toLowerCase();
        const dir = { u: 'n', d: 's', l: 'w', r: 'e' }[key];
        if (!dir) return false;
        const cellObj = maze[pos.y][pos.x];
        if (cellObj.walls[dir]) {
          bumps += 1;
          ctx.status(`Wall — ${bumps} wrong turn${bumps === 1 ? '' : 's'}`);
          return false;
        }
        if (dir === 'n') pos = { x: pos.x, y: pos.y - 1 };
        if (dir === 's') pos = { x: pos.x, y: pos.y + 1 };
        if (dir === 'w') pos = { x: pos.x - 1, y: pos.y };
        if (dir === 'e') pos = { x: pos.x + 1, y: pos.y };
        steps += 1;
        ctx.hit(4);
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#111820', bottom: '#0c1116' });
        const c = cell();
        const ox = (W - c * size) / 2;
        const oy = 96 + Math.max(0, (H - 190 - c * size) / 2);

        g.fillStyle = 'rgba(255,255,255,0.02)';
        g.fillRect(ox, oy, c * size, c * size);

        for (let y = 0; y < size; y += 1) {
          for (let x = 0; x < size; x += 1) {
            const cellObj = maze[y][x];
            const px = ox + x * c;
            const py = oy + y * c;
            g.strokeStyle = 'rgba(127,179,165,0.35)';
            g.lineWidth = 1.4;
            g.beginPath();
            if (cellObj.walls.n) { g.moveTo(px, py); g.lineTo(px + c, py); }
            if (cellObj.walls.s) { g.moveTo(px, py + c); g.lineTo(px + c, py + c); }
            if (cellObj.walls.w) { g.moveTo(px, py); g.lineTo(px, py + c); }
            if (cellObj.walls.e) { g.moveTo(px + c, py); g.lineTo(px + c, py + c); }
            g.stroke();
          }
        }

        // goal
        const gx = ox + goal.x * c;
        const gy = oy + goal.y * c;
        g.fillStyle = 'rgba(224,160,113,0.28)';
        g.fillRect(gx + 4, gy + 4, c - 8, c - 8);
        text(g, 'EXIT', gx + c / 2, gy + c / 2 + 4, { size: Math.min(11, c / 4), align: 'center', color: '#e0a071', weight: '700', family: 'system-ui, sans-serif' });

        // player
        const px = ox + pos.x * c;
        const py = oy + pos.y * c;
        g.fillStyle = '#7fb3a5';
        g.beginPath();
        g.arc(px + c / 2, py + c / 2, c * 0.28, 0, Math.PI * 2);
        g.fill();

        panel(g, 14, 12, 300, 54, { radius: 8 });
        text(g, 'U  up    D  down    L  left    R  right', 26, 34, { size: 11, color: '#c3cad4' });
        text(g, `Maze ${cleared + 1} · ${steps} steps · ${bumps} wrong turns`, 26, 54, { size: 10, color: '#8d96a3', family: 'system-ui, sans-serif' });
      },
    };
  },
};
