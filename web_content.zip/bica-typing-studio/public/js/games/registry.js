/**
 * Arcade registry — the client half of every game.
 *
 * The server catalogue (shared/scoring.js) owns titles, rules text, duration
 * and difficulty factors, so the arcade listing, the report and the score
 * formula cannot drift apart. This file only maps a game id to its module and
 * is loaded lazily, one file per game, on first play.
 */
const LOADERS = {
  'falling-letters': () => import('./falling-letters.js'),
  'bubble-pop': () => import('./bubble-pop.js'),
  'speed-circuit': () => import('./speed-circuit.js'),
  'word-orbit': () => import('./word-orbit.js'),
  'typing-bakery': () => import('./typing-bakery.js'),
  'keyboard-maze': () => import('./keyboard-maze.js'),
  'word-guardian': () => import('./word-guardian.js'),
  'rhythm-keys': () => import('./rhythm-keys.js'),
  'word-builder': () => import('./word-builder.js'),
  'station-master': () => import('./station-master.js'),
  'typing-expedition': () => import('./typing-expedition.js'),
  'code-sprint': () => import('./code-sprint.js'),
};

export const GAME_IDS = Object.keys(LOADERS);

export function hasModule(id) { return Object.prototype.hasOwnProperty.call(LOADERS, id); }

export async function loadGame(id) {
  const loader = LOADERS[id];
  if (!loader) throw new Error(`No client module is registered for "${id}".`);
  const mod = await loader();
  return mod.default;
}
