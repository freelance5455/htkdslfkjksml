/** GAME 1 — Falling Letters. Type each key before it reaches the floor. */
import { backdrop, text, roundRect, rngFrom, clamp, diffOf, panel } from './util.js';

export default {
  id: 'falling-letters',
  create(ctx) {
    const rnd = rngFrom(Date.now());
    const d = diffOf(ctx.difficulty);
    const letters = 'asdfghjklqwertyuiopzxcvbnm'.split('');
    const COLUMNS = 7;
    let items = [];
    let lives = Math.max(2, Math.round(d.lives));
    let spawnAt = 0;
    let speed = 46 * d.speed;
    let level = 1;
    let floorHeat = [];

    function spawn() {
      const lane = Math.floor(rnd() * COLUMNS);
      const busy = items.some((it) => it.lane === lane && it.y < 40);
      if (busy) return;
      items.push({
        lane,
        y: -20,
        ch: letters[Math.floor(rnd() * letters.length)],
        vy: speed * (0.85 + rnd() * 0.4),
      });
    }

    return {
      update(dt) {
        spawnAt += dt;
        const interval = Math.max(0.32, 1.15 / d.density - level * 0.03);
        if (spawnAt > interval) {
          spawnAt = 0;
          spawn();
          if (rnd() < 0.25) spawn();
        }
        const h = ctx.height;
        const floor = h - 74;
        for (const it of items) {
          it.y += it.vy * dt;
        }
        const hit = items.filter((it) => it.y >= floor);
        if (hit.length) {
          items = items.filter((it) => it.y < floor);
          lives -= hit.length;
          floorHeat.push({ at: ctx.elapsed, lane: hit[0].lane });
          ctx.status(`Lost ${hit.length} letter${hit.length > 1 ? 's' : ''} — ${Math.max(0, lives)} left`);
          if (lives <= 0) { ctx.level(level); ctx.finish('GAME_OVER'); }
        }
        const newLevel = 1 + Math.floor(ctx.elapsed / 22000);
        if (newLevel !== level) {
          level = newLevel;
          speed = Math.min(150, 46 * d.speed * (1 + level * 0.22));
          ctx.status(`Speed up — level ${level}`);
        }
        floorHeat = floorHeat.filter((f) => ctx.elapsed - f.at < 600);
      },
      onKey(ch) {
        const key = ch.toLowerCase();
        const candidates = items.filter((it) => it.ch === key);
        if (candidates.length === 0) return false;
        // clear the lowest one first: that is the most urgent
        candidates.sort((a, b) => b.y - a.y);
        const target = candidates[0];
        items = items.filter((it) => it !== target);
        ctx.hit(12);
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#101820', bottom: '#0d1218' });
        const floor = H - 74;
        const laneW = W / COLUMNS;

        // lanes
        for (let i = 0; i < COLUMNS; i += 1) {
          g.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.018)' : 'rgba(255,255,255,0.005)';
          g.fillRect(i * laneW, 0, laneW, floor);
        }
        // floor glow + damage flash
        g.fillStyle = '#1b2028';
        g.fillRect(0, floor, W, H - floor);
        g.strokeStyle = 'rgba(127,179,165,0.35)';
        g.beginPath(); g.moveTo(0, floor); g.lineTo(W, floor); g.stroke();
        for (const f of floorHeat) {
          g.fillStyle = `rgba(239,138,138,${0.35 * (1 - (ctx.elapsed - f.at) / 600)})`;
          g.fillRect(f.lane * laneW, floor - 60, laneW, 60);
        }

        for (const it of items) {
          const cx = it.lane * laneW + laneW / 2;
          roundRect(g, cx - 19, it.y - 19, 38, 38, 7);
          g.fillStyle = '#232a33';
          g.fill();
          g.strokeStyle = 'rgba(127,179,165,0.5)';
          g.lineWidth = 1.2;
          g.stroke();
          text(g, it.ch.toUpperCase(), cx, it.y + 7, { size: 20, align: 'center', color: '#eaf0f4', weight: '600' });
        }

        // lives + level
        panel(g, 14, 12, 150, 46, { radius: 8 });
        text(g, 'LIVES', 26, 30, { size: 9, color: '#8d96a3', weight: '600' });
        for (let i = 0; i < Math.max(0, lives); i += 1) {
          g.beginPath();
          g.arc(30 + i * 16, 44, 5, 0, Math.PI * 2);
          g.fillStyle = '#7fb3a5';
          g.fill();
        }
        text(g, `LEVEL ${level}`, 26, 66, { size: 10, color: '#8d96a3' });
        text(g, 'Type the lowest matching letter', W / 2, H - 26, {
          size: 12, color: 'rgba(233,237,241,0.45)', align: 'center', family: 'system-ui, sans-serif',
        });
        clamp(0, 0, 0);
      },
    };
  },
};
