/** GAME 11 — Typing Expedition. Ten locations, one passage each. */
import { backdrop, text, roundRect, rngFrom, panel, bar, measure } from './util.js';
import { EXPEDITION_LOCATIONS, PARAGRAPHS } from '/shared/textbank.js';

export default {
  id: 'typing-expedition',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 149);
    const total = EXPEDITION_LOCATIONS.length;
    let reached = 0;
    let passage = '';
    let typedIdx = 0;
    let errors = 0;
    let supplies = 100;
    let transitioning = false;

    function loadPassage() {
      const base = PARAGRAPHS[Math.floor(rnd() * PARAGRAPHS.length)];
      const length = ctx.difficulty === 'easy' ? 60 : ctx.difficulty === 'hard' ? 150 : 100;
      passage = base.split(' ').slice(0, Math.round(length / 6)).join(' ');
      if (passage.length < 40) passage = base.slice(0, length);
      typedIdx = 0;
      errors = 0;
    }
    loadPassage();

    return {
      update(dt) {
        if (transitioning) {
          transitioning = false;
          loadPassage();
        }
        if (reached >= total) { ctx.level(reached); ctx.finish('COMPLETE'); }
        if (supplies <= 0) { ctx.level(reached); ctx.finish('GAME_OVER'); }
      },
      onKey(ch) {
        const expected = passage[typedIdx];
        if (expected === undefined) return null;
        if (ch === expected) {
          typedIdx += 1;
          if (typedIdx >= passage.length) {
            reached += 1;
            supplies = Math.min(100, supplies + 4);
            ctx.hit(70 + Math.round((1 - errors / passage.length) * 50));
            ctx.status(`Reached ${EXPEDITION_LOCATIONS[Math.min(reached, total - 1)]}`);
            transitioning = true;
          } else {
            ctx.hit(2);
          }
          return true;
        }
        errors += 1;
        supplies -= 0.6;
        return false;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#101a16', bottom: '#0b1210' });

        // map strip
        const mapY = 70;
        const step = (W - 120) / (total - 1);
        g.strokeStyle = 'rgba(127,179,165,0.25)';
        g.lineWidth = 2;
        g.beginPath(); g.moveTo(60, mapY); g.lineTo(W - 60, mapY); g.stroke();
        EXPEDITION_LOCATIONS.forEach((name, i) => {
          const x = 60 + i * step;
          const done = i <= reached;
          g.beginPath();
          g.arc(x, mapY, done ? 7 : 5, 0, Math.PI * 2);
          g.fillStyle = i === reached ? '#e0a071' : done ? '#7fb3a5' : '#2c3540';
          g.fill();
          text(g, name.split(' ')[0], x, mapY + 22, {
            size: 8.5, align: 'center', color: i === reached ? '#e0a071' : '#7b8492', family: 'system-ui, sans-serif',
          });
        });

        // supplies
        panel(g, 40, 8, 240, 42, { radius: 8 });
        text(g, 'SUPPLIES', 54, 25, { size: 8.5, color: '#8d96a3', weight: '600' });
        bar(g, 54, 31, 120, 5, supplies / 100, { color: supplies > 40 ? '#7fb3a5' : '#ef8a8a' });
        text(g, `${reached} / ${total} locations`, 190, 30, { size: 9.5, color: '#8d96a3', family: 'system-ui, sans-serif' });

        // mission panel
        const boxY = H / 2 - 120;
        roundRect(g, 50, boxY, W - 100, 260, 12);
        g.fillStyle = 'rgba(255,255,255,0.04)';
        g.fill();
        g.strokeStyle = 'rgba(127,179,165,0.22)';
        g.stroke();

        text(g, `MISSION ${Math.min(reached + 1, total)} · ${EXPEDITION_LOCATIONS[Math.min(reached, total - 1)].toUpperCase()}`, 72, boxY + 30, {
          size: 10, color: '#e0a071', weight: '700',
        });

        const size = 17;
        const maxW = W - 164;
        let line = '';
        let y = boxY + 66;
        const lines = [];
        for (const word of passage.split(' ')) {
          const attempt = line ? `${line} ${word}` : word;
          if (measure(g, attempt, size) > maxW && line) { lines.push(line); line = word; }
          else line = attempt;
        }
        if (line) lines.push(line);
        let consumed = 0;
        for (const ln of lines.slice(0, 7)) {
          const done = Math.min(ln.length, Math.max(0, typedIdx - consumed));
          text(g, ln.slice(0, done), 72, y, { size, color: '#8ee0b8' });
          text(g, ln.slice(done), 72 + measure(g, ln.slice(0, done), size), y, { size, color: '#dbe2e8' });
          consumed += ln.length + 1;
          y += size * 1.5;
        }

        bar(g, 72, boxY + 226, W - 144, 5, typedIdx / Math.max(1, passage.length), { color: '#7fb3a5' });
        text(g, `${typedIdx} / ${passage.length} characters · ${errors} errors on this leg`, W / 2, boxY + 250, {
          size: 10, align: 'center', color: '#8d96a3', family: 'system-ui, sans-serif',
        });
      },
    };
  },
};
