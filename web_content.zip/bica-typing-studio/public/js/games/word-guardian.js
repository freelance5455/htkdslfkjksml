/** GAME 7 — Word Guardian. Complete words to fire; keep the barrier standing. */
import { backdrop, text, roundRect, rngFrom, wordPool, diffOf, measure, panel, bar } from './util.js';

export default {
  id: 'word-guardian',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 83);
    const d = diffOf(ctx.difficulty);
    const pool = wordPool(ctx.difficulty);
    let enemies = [];
    let barrier = 100;
    let killed = 0;
    let typed = '';
    let lockedId = null;
    let spawnAt = 0;
    let shot = null;

    function spawn() {
      const word = pool[Math.floor(rnd() * pool.length)];
      enemies.push({
        id: Math.random().toString(36).slice(2),
        word,
        x: ctx.width - 40,
        y: 120 + rnd() * Math.max(120, ctx.height - 300),
        speed: (26 + rnd() * 18) * d.speed,
      });
    }
    spawn();

    return {
      update(dt) {
        spawnAt += dt;
        if (spawnAt > Math.max(0.9, 2.1 / d.density)) { spawnAt = 0; spawn(); }
        const barrierX = 150;
        for (const e of enemies) e.x -= e.speed * dt;
        const breached = enemies.filter((e) => e.x < barrierX);
        if (breached.length) {
          barrier -= breached.length * 14;
          enemies = enemies.filter((e) => e.x >= barrierX);
          if (lockedId && breached.some((e) => e.id === lockedId)) { lockedId = null; typed = ''; }
          ctx.status(`Barrier at ${Math.max(0, Math.round(barrier))}%`);
          if (barrier <= 0) { ctx.level(killed); ctx.finish('GAME_OVER'); }
        }
        if (shot) {
          shot.life -= dt;
          if (shot.life <= 0) shot = null;
        }
      },
      onKey(ch) {
        const attempt = typed + ch.toLowerCase();
        const candidates = enemies.filter((e) => e.word.startsWith(attempt));
        if (candidates.length === 0) {
          typed = '';
          lockedId = null;
          return false;
        }
        let target = candidates.find((e) => e.id === lockedId);
        if (!target) target = candidates.slice().sort((a, b) => a.x - b.x)[0];
        for (const e of candidates) if (e !== target) e.word = e.word;
        lockedId = target.id;
        typed = attempt;
        if (typed === target.word) {
          killed += 1;
          ctx.hit(16 + target.word.length * 2);
          shot = { from: { x: 160, y: ctx.height / 2 }, to: { x: target.x, y: target.y }, life: 0.18 };
          enemies = enemies.filter((e) => e.id !== target.id);
          typed = '';
          lockedId = null;
          ctx.status(`${killed} stopped`);
        }
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#0e141a', bottom: '#0a0f13' });

        // ground
        g.fillStyle = 'rgba(127,179,165,0.05)';
        g.fillRect(0, H - 70, W, 70);
        g.strokeStyle = 'rgba(127,179,165,0.14)';
        g.beginPath(); g.moveTo(0, H - 70); g.lineTo(W, H - 70); g.stroke();

        // barrier
        const glow = Math.max(0, barrier) / 100;
        g.fillStyle = `rgba(127,179,165,${0.1 + glow * 0.18})`;
        g.fillRect(150, 80, 10, H - 150);
        g.strokeStyle = `rgba(127,179,165,${0.35 + glow * 0.4})`;
        g.lineWidth = 1.4;
        g.beginPath(); g.moveTo(155, 80); g.lineTo(155, H - 70); g.stroke();

        // guardian
        g.save();
        g.translate(120, H / 2);
        g.beginPath();
        g.arc(0, 0, 20, 0, Math.PI * 2);
        g.fillStyle = '#1f2a31';
        g.fill();
        g.strokeStyle = '#7fb3a5';
        g.lineWidth = 1.6;
        g.stroke();
        text(g, '⌨', 0, 6, { size: 16, align: 'center', color: '#7fb3a5', family: 'system-ui, sans-serif' });
        g.restore();

        // enemies
        for (const e of enemies) {
          const isTarget = e.id === lockedId;
          const size = 14;
          const w = measure(g, e.word, size) + 26;
          roundRect(g, e.x - w / 2, e.y - 16, w, 32, 8);
          g.fillStyle = isTarget ? '#3d332a' : '#242c33';
          g.fill();
          g.strokeStyle = isTarget ? '#e0a071' : 'rgba(255,255,255,0.12)';
          g.lineWidth = isTarget ? 1.8 : 1;
          g.stroke();
          if (isTarget) {
            text(g, typed, e.x - w / 2 + 13, e.y + 5, { size, color: '#ffd9a8', weight: '700' });
            text(g, e.word.slice(typed.length), e.x - w / 2 + 13 + measure(g, typed, size), e.y + 5, { size, color: '#eef2f5' });
          } else {
            text(g, e.word, e.x - w / 2 + 13, e.y + 5, { size, color: '#dbe2e8' });
          }
          // eye
          g.beginPath();
          g.arc(e.x - w / 2 + 5, e.y, 2.4, 0, Math.PI * 2);
          g.fillStyle = '#ef8a8a';
          g.fill();
        }

        if (shot) {
          g.strokeStyle = 'rgba(224,160,113,0.9)';
          g.lineWidth = 2;
          g.beginPath();
          g.moveTo(shot.from.x, shot.from.y);
          g.lineTo(shot.to.x, shot.to.y);
          g.stroke();
        }

        panel(g, 14, 12, 220, 50, { radius: 8 });
        text(g, 'BARRIER', 26, 30, { size: 9, color: '#8d96a3', weight: '600' });
        bar(g, 26, 36, 130, 6, barrier / 100, { color: barrier > 40 ? '#7fb3a5' : '#ef8a8a' });
        text(g, `${killed} stopped`, 26, 54, { size: 10, color: '#8d96a3', family: 'system-ui, sans-serif' });
        text(g, 'Type any word — the closest creature locks on', W / 2, H - 26, {
          size: 12, align: 'center', color: 'rgba(233,237,241,0.4)', family: 'system-ui, sans-serif',
        });
      },
    };
  },
};
