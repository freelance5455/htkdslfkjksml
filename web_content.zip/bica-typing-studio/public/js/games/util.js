/** Small drawing / maths helpers shared by the arcade games. */

export function rngFrom(seed = Date.now()) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
export function lerp(a, b, t) { return a + (b - a) * t; }
export function pick(rnd, arr) { return arr[Math.floor(rnd() * arr.length) % arr.length]; }

export function roundRect(g, x, y, w, h, r = 8) {
  const radius = Math.min(r, w / 2, h / 2);
  g.beginPath();
  g.moveTo(x + radius, y);
  g.arcTo(x + w, y, x + w, y + h, radius);
  g.arcTo(x + w, y + h, x, y + h, radius);
  g.arcTo(x, y + h, x, y, radius);
  g.arcTo(x, y, x + w, y, radius);
  g.closePath();
}

export function text(g, str, x, y, {
  size = 14, color = '#e9edf1', align = 'left', baseline = 'alphabetic',
  weight = '400', family = 'ui-monospace, Menlo, Consolas, monospace', alpha = 1,
} = {}) {
  g.save();
  g.globalAlpha = alpha;
  g.fillStyle = color;
  g.textAlign = align;
  g.textBaseline = baseline;
  g.font = `${weight} ${size}px ${family}`;
  g.fillText(str, x, y);
  g.restore();
}

export function measure(g, str, size = 14, family = 'ui-monospace, Menlo, Consolas, monospace') {
  g.save();
  g.font = `400 ${size}px ${family}`;
  const w = g.measureText(str).width;
  g.restore();
  return w;
}

export function panel(g, x, y, w, h, { fill = 'rgba(255,255,255,0.05)', stroke = 'rgba(255,255,255,0.12)', radius = 10 } = {}) {
  roundRect(g, x, y, w, h, radius);
  g.fillStyle = fill;
  g.fill();
  if (stroke) { g.strokeStyle = stroke; g.lineWidth = 1; g.stroke(); }
}

export function bar(g, x, y, w, h, pct, { color = '#7fb3a5', track = 'rgba(255,255,255,0.12)' } = {}) {
  roundRect(g, x, y, w, h, h / 2);
  g.fillStyle = track; g.fill();
  const filled = clamp(pct, 0, 1) * w;
  if (filled > 1) {
    roundRect(g, x, y, Math.max(h, filled), h, h / 2);
    g.fillStyle = color; g.fill();
  }
}

export function backdrop(g, w, h, { top = '#12161c', bottom = '#171d24' } = {}) {
  const grad = g.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, top);
  grad.addColorStop(1, bottom);
  g.fillStyle = grad;
  g.fillRect(0, 0, w, h);
}

export const WORDS = {
  easy: ['cat', 'dog', 'sun', 'map', 'pen', 'cup', 'box', 'key', 'run', 'top', 'net', 'bag', 'hat', 'fan', 'bus', 'jam'],
  normal: ['table', 'river', 'paper', 'light', 'stone', 'money', 'train', 'plant', 'cloud', 'brush', 'office', 'letter', 'record', 'market', 'pencil', 'window'],
  hard: ['keyboard', 'register', 'certificate', 'announcement', 'vocabulary', 'punctuation', 'station', 'examination', 'instruction', 'correspondence'],
};

export function wordPool(difficulty) {
  if (difficulty === 'easy') return WORDS.easy;
  if (difficulty === 'hard') return [...WORDS.normal, ...WORDS.hard];
  return [...WORDS.easy, ...WORDS.normal];
}

export const DIFF = {
  easy: { speed: 0.72, density: 0.7, lives: 4 },
  normal: { speed: 1, density: 1, lives: 3 },
  hard: { speed: 1.42, density: 1.35, lives: 2 },
};

export function diffOf(level) { return DIFF[level] ?? DIFF.normal; }
