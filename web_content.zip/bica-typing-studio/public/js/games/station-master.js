/** GAME 10 — Station Master. Type announcements verbatim, capitals and all. */
import { backdrop, text, roundRect, rngFrom, panel, bar, measure } from './util.js';
import { STATIONS } from '/shared/textbank.js';

export default {
  id: 'station-master',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 131);
    const d = Math.min(1.4, 0.85 + (ctx.difficulty === 'hard' ? 0.45 : ctx.difficulty === 'easy' ? 0 : 0.15));
    let index = 0;
    let announcement = null;
    let typedIdx = 0;
    let completed = 0;
    let errorsHere = 0;
    let timeLeft = 22;
    const maxTime = 22;

    function build() {
      const station = STATIONS[Math.floor(rnd() * STATIONS.length)];
      const train = 12000 + Math.floor(rnd() * 8000);
      const platform = 1 + Math.floor(rnd() * 4);
      const minutes = 5 + Math.floor(rnd() * 40);
      return `Attention please. Train ${train} to ${station} will arrive on platform ${platform} at ${minutes} minutes past the hour.`;
    }

    function next() {
      announcement = build();
      typedIdx = 0;
      errorsHere = 0;
      timeLeft = maxTime;
      index += 1;
    }
    next();

    return {
      update(dt) {
        timeLeft -= dt * d;
        if (timeLeft <= 0) {
          ctx.status('Announcement missed — the platform went quiet');
          ctx.miss();
          next();
        }
      },
      onKey(ch) {
        const expected = announcement[typedIdx];
        if (expected === undefined) return null;
        if (ch === expected) {
          typedIdx += 1;
          if (typedIdx >= announcement.length) {
            const accuracy = 1 - errorsHere / announcement.length;
            completed += 1;
            ctx.hit(60 + Math.round(accuracy * 40) + Math.max(0, Math.round(timeLeft * 2)));
            ctx.status(`Announcement ${completed} broadcast cleanly`);
            next();
          } else {
            ctx.hit(3);
          }
          return true;
        }
        errorsHere += 1;
        return false;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#0f151b', bottom: '#0a0f14' });

        // platform board
        roundRect(g, 40, 40, W - 80, 74, 10);
        g.fillStyle = '#151c22';
        g.fill();
        g.strokeStyle = 'rgba(224,160,113,0.35)';
        g.stroke();
        text(g, 'PLATFORM ANNOUNCEMENT SYSTEM', 60, 66, { size: 10, color: '#8d96a3', weight: '600' });
        text(g, `BROADCAST ${completed}`, 60, 92, { size: 16, color: '#e0a071', weight: '600' });
        bar(g, W - 320, 76, 240, 6, timeLeft / maxTime, { color: timeLeft < 6 ? '#ef8a8a' : '#7fb3a5' });
        text(g, `${Math.max(0, timeLeft).toFixed(1)}s`, W - 60, 96, { size: 11, align: 'right', color: '#8d96a3' });

        // the announcement
        const boxY = H / 2 - 110;
        roundRect(g, 40, boxY, W - 80, 220, 12);
        g.fillStyle = 'rgba(255,255,255,0.04)';
        g.fill();
        g.strokeStyle = 'rgba(255,255,255,0.10)';
        g.stroke();
        text(g, 'SAY EXACTLY THIS', 60, boxY + 30, { size: 9, color: '#8d96a3', weight: '600' });

        // wrap the announcement
        const maxW = W - 140;
        const size = 24;
        const words = announcement.split(' ');
        let line = '';
        let y = boxY + 70;
        const lines = [];
        for (const word of words) {
          const attempt = line ? `${line} ${word}` : word;
          if (measure(g, attempt, size) > maxW && line) { lines.push(line); line = word; }
          else line = attempt;
        }
        if (line) lines.push(line);

        let consumed = 0;
        for (const ln of lines) {
          const done = Math.min(ln.length, Math.max(0, typedIdx - consumed));
          text(g, ln.slice(0, done), 60, y, { size, color: '#8ee0b8' });
          text(g, ln.slice(done), 60 + measure(g, ln.slice(0, done), size), y, { size, color: '#e9edf1' });
          consumed += ln.length + 1;
          y += size * 1.55;
        }

        text(g, 'Capitals and punctuation each count as a character.', W / 2, H - 40, {
          size: 12, align: 'center', color: 'rgba(233,237,241,0.4)', family: 'system-ui, sans-serif',
        });
      },
    };
  },
};
