/** GAME 4 — Word Orbit. Clear a lane by typing its word before the ship reaches it. */
import { backdrop, text, roundRect, rngFrom, wordPool, diffOf, measure, panel, bar } from './util.js';

export default {
  id: 'word-orbit',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 33);
    const d = diffOf(ctx.difficulty);
    const pool = wordPool(ctx.difficulty);
    const LANES = 4;
    let lanes = [];
    let wave = 1;
    let hull = 100;
    let cleared = 0;

    function newLane(i) {
      return {
        i,
        word: pool[Math.floor(rnd() * pool.length)],
        progress: 0,
        speed: (0.055 + rnd() * 0.03) * d.speed * (1 + wave * 0.08),
        lock: 0,
      };
    }

    function resetWave() {
      lanes = Array.from({ length: LANES }, (_, i) => newLane(i));
    }
    resetWave();

    return {
      update(dt) {
        let allClear = true;
        for (const lane of lanes) {
          if (lane.lock > 0) lane.lock = Math.max(0, lane.lock - dt);
          if (lane.progress < 1) {
            allClear = false;
            lane.progress = Math.min(1, lane.progress + lane.speed * dt);
            if (lane.progress >= 1) {
              hull -= 18;
              lane.progress = 0;
              lane.lock = 0;
              lane.word = pool[Math.floor(rnd() * pool.length)];
              lane.speed = (0.055 + rnd() * 0.03) * d.speed * (1 + wave * 0.08);
              ctx.status(`Hull damage — ${Math.max(0, Math.round(hull))}%`);
              if (hull <= 0) { ctx.level(wave); ctx.finish('GAME_OVER'); return; }
            }
          }
        }
        if (allClear) {
          wave += 1;
          cleared += LANES;
          ctx.status(`Wave ${wave} — all lanes clear`);
          resetWave();
        }
      },
      onKey(ch) {
        // Each lane keeps a typed prefix in `typed`; a key must extend exactly
        // one lane's prefix, otherwise it is a miss and every prefix resets.
        const candidates = lanes.filter((l) => (l.typed ?? '') + ch === l.word.slice(0, (l.typed ?? '').length + ch.length));
        if (candidates.length === 0) {
          for (const l of lanes) l.typed = '';
          return false;
        }
        let target = candidates.find((l) => l.lock > 0);
        if (!target) target = candidates.slice().sort((a, b) => b.progress - a.progress)[0];
        for (const l of lanes) if (l !== target) l.typed = '';
        target.lock = 1.4;
        target.typed = (target.typed ?? '') + ch;
        if (target.typed === target.word) {
          const bonus = Math.round(12 + (1 - target.progress) * 30);
          ctx.hit(bonus);
          cleared += 1;
          Object.assign(target, newLane(target.i));
        } else {
          ctx.hit(5);
        }
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#0b1117', bottom: '#101820' });

        // stars
        g.fillStyle = 'rgba(255,255,255,0.20)';
        for (let i = 0; i < 48; i += 1) {
          const x = ((i * 137) % Math.max(1, W));
          const y = ((i * 89) % Math.max(1, H));
          g.fillRect(x, y, 1.4, 1.4);
        }

        const laneH = Math.min(74, (H - 160) / LANES);
        const top = 90;

        lanes.forEach((lane, i) => {
          const y = top + i * laneH + laneH / 2;
          const startX = W - 120;
          const endX = 130;
          const x = startX - (startX - endX) * lane.progress;

          // lane guide
          g.strokeStyle = 'rgba(127,179,165,0.10)';
          g.beginPath(); g.moveTo(endX, y); g.lineTo(startX + 40, y); g.stroke();

          // asteroid
          const r = 20 + lane.word.length * 2.2;
          g.save();
          g.beginPath();
          for (let a = 0; a < 9; a += 1) {
            const ang = (a / 9) * Math.PI * 2;
            const rad = r * (0.86 + ((lane.i * 7 + a * 3) % 5) * 0.05);
            const px = x + Math.cos(ang) * rad;
            const py = y + Math.sin(ang) * rad;
            if (a === 0) g.moveTo(px, py); else g.lineTo(px, py);
          }
          g.closePath();
          g.fillStyle = lane.lock > 0 ? '#3c4a52' : '#2c3540';
          g.fill();
          if (lane.lock > 0) { g.strokeStyle = '#e0a071'; g.lineWidth = 1.6; g.stroke(); }
          g.restore();

          const typed = lane.typed ?? '';
          const size = 15;
          const tw = measure(g, lane.word, size);
          text(g, typed, x - tw / 2, y + 5, { size, color: '#ffd9a8', weight: '700' });
          text(g, lane.word.slice(typed.length), x - tw / 2 + measure(g, typed, size), y + 5, { size, color: 'rgba(255,255,255,0.85)' });

          bar(g, endX, y + laneH / 2 - 8, 90, 4, lane.progress, { color: lane.progress > 0.75 ? '#ef8a8a' : '#7fb3a5' });
        });

        // ship
        g.save();
        g.translate(96, H / 2);
        g.beginPath();
        g.moveTo(28, 0); g.lineTo(-16, -14); g.lineTo(-6, 0); g.lineTo(-16, 14);
        g.closePath();
        g.fillStyle = '#7fb3a5'; g.fill();
        g.restore();

        panel(g, 14, 12, 210, 46, { radius: 8 });
        text(g, 'HULL', 26, 30, { size: 9, color: '#8d96a3', weight: '600' });
        bar(g, 26, 36, 120, 6, hull / 100, { color: hull > 40 ? '#7fb3a5' : '#ef8a8a' });
        text(g, `WAVE ${wave} · ${cleared} cleared`, 26, 52, { size: 10, color: '#8d96a3' });

        text(g, 'Type the word of the closest asteroid in any lane', W / 2, H - 24, {
          size: 12, align: 'center', color: 'rgba(233,237,241,0.4)', family: 'system-ui, sans-serif',
        });
        roundRect(g, 0, 0, 0, 0, 0);
      },
    };
  },
};
