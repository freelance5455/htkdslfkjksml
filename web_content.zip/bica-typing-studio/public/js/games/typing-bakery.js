/** GAME 5 — Typing Bakery. Serve a queue of orders before the counter overflows. */
import { backdrop, text, roundRect, rngFrom, diffOf, panel, measure, bar } from './util.js';
import { BAKERY_ITEMS } from '/shared/textbank.js';

export default {
  id: 'typing-bakery',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 51);
    const d = diffOf(ctx.difficulty);
    let queue = [];
    let served = 0;
    let earnings = 0;
    let spawnAt = 0;
    let current = null;
    let typed = '';
    let angry = 0;

    function addOrder() {
      const item = BAKERY_ITEMS[Math.floor(rnd() * BAKERY_ITEMS.length)];
      queue.push({ item, age: 0, patience: 26 - (d.speed - 1) * 6, id: Math.random().toString(36).slice(2) });
    }
    addOrder();

    return {
      update(dt) {
        spawnAt += dt;
        if (spawnAt > Math.max(1.4, 2.6 / d.density)) { spawnAt = 0; addOrder(); }

        for (const o of queue) o.age += dt;
        const expired = queue.filter((o) => o.age > o.patience);
        if (expired.length) {
          queue = queue.filter((o) => o.age <= o.patience);
          angry += expired.length;
          if (current && expired.some((o) => o.id === current.id)) { current = null; typed = ''; }
          ctx.status(`${angry} customer${angry === 1 ? '' : 's'} left without an order`);
          if (angry >= 5) { ctx.level(served); ctx.finish('GAME_OVER'); }
        }
      },
      onKey(ch) {
        if (!current) {
          const match = queue.find((o) => o.item.startsWith(ch.toLowerCase()));
          if (!match) return false;
          current = match;
          typed = ch.toLowerCase();
        } else {
          const attempt = typed + ch;
          if (!current.item.startsWith(attempt)) {
            typed = '';
            current = null;
            return false;
          }
          typed = attempt;
        }
        if (typed === current.item) {
          const rush = Math.max(0, 1 - current.age / current.patience);
          const value = 10 + Math.round(rush * 12) + current.item.length;
          served += 1;
          earnings += value;
          queue = queue.filter((o) => o.id !== current.id);
          ctx.hit(value);
          ctx.status(`Sold ${current.item} — Rs ${earnings}`);
          current = null;
          typed = '';
        }
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#161311', bottom: '#100d0b' });

        // counter
        g.fillStyle = '#221b16';
        g.fillRect(0, H - 210, W, 210);
        g.strokeStyle = 'rgba(224,160,113,0.25)';
        g.beginPath(); g.moveTo(0, H - 210); g.lineTo(W, H - 210); g.stroke();
        text(g, 'BICA BAKERY', 40, H - 232, { size: 12, color: 'rgba(224,160,113,0.8)', weight: '600', family: 'system-ui, sans-serif' });

        panel(g, 30, 16, 250, 50, { radius: 8 });
        text(g, 'TAKINGS', 44, 34, { size: 9, color: '#8d96a3', weight: '600' });
        text(g, `Rs ${earnings}`, 44, 54, { size: 16, color: '#f0e4d6' });
        text(g, `${served} served · ${angry}/5 walked out`, 300, 44, { size: 11, color: angry >= 3 ? '#ef8a8a' : '#8d96a3', family: 'system-ui, sans-serif' });

        // queue
        const cardW = Math.min(240, (W - 120) / 3);
        queue.slice(0, 3).forEach((o, i) => {
          const x = 40 + i * (cardW + 18);
          const y = 90;
          const isActive = current?.id === o.id;
          roundRect(g, x, y, cardW, 92, 10);
          g.fillStyle = isActive ? '#39312a' : '#26201b';
          g.fill();
          g.strokeStyle = isActive ? '#e0a071' : 'rgba(255,255,255,0.10)';
          g.lineWidth = isActive ? 2 : 1;
          g.stroke();
          text(g, `ORDER ${served + i + 1}`, x + 14, y + 24, { size: 9, color: '#8d96a3', weight: '600' });
          const word = isActive ? o.item : o.item;
          const shown = isActive ? o.item.slice(0, typed.length) : '';
          const size = Math.min(17, (cardW - 30) / Math.max(8, word.length) * 1.7);
          text(g, shown, x + 14, y + 56, { size, color: '#ffd9a8', weight: '700' });
          text(g, word.slice(shown.length), x + 14 + measure(g, shown, size), y + 56, { size, color: '#f0e4d6' });
          bar(g, x + 14, y + 72, cardW - 28, 4, 1 - o.age / o.patience, { color: o.age / o.patience > 0.7 ? '#ef8a8a' : '#7fb3a5' });
        });

        // typing prompt
        const promptY = H - 120;
        text(g, 'TYPE THE ORDER', W / 2, promptY - 26, { size: 9, align: 'center', color: '#8d96a3', weight: '600' });
        if (typed) {
          text(g, typed, W / 2, promptY + 12, { size: 24, align: 'center', color: '#e0a071', weight: '700' });
        } else {
          text(g, 'Begin typing any item name to pick that order', W / 2, promptY + 8, {
            size: 13, align: 'center', color: 'rgba(240,228,214,0.42)', family: 'system-ui, sans-serif',
          });
        }
        roundRect(g, 0, 0, 0, 0, 0);
      },
    };
  },
};
