/** GAME 3 — Speed Circuit. Correct characters move your car; mistakes stall it. */
import { backdrop, text, roundRect, rngFrom, wordPool, diffOf, measure, panel, bar, clamp, lerp } from './util.js';

export default {
  id: 'speed-circuit',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 21);
    const d = diffOf(ctx.difficulty);
    const pool = wordPool(ctx.difficulty);
    const TRACK = 1;
    const bots = [
      { name: 'BICA-02', progress: 0, speed: 0.0135 * d.speed, color: '#6b7b8c' },
      { name: 'BICA-07', progress: 0, speed: 0.0148 * d.speed, color: '#8a7b6b' },
      { name: 'BICA-11', progress: 0, speed: 0.0162 * d.speed, color: '#726b8a' },
    ];
    let player = 0;
    let words = [];
    let current = '';
    let typedIdx = 0;
    let finished = false;
    let place = 0;
    let boost = 0;

    function refill() {
      while (words.length < 6) words.push(pool[Math.floor(rnd() * pool.length)]);
      current = words[0];
      typedIdx = 0;
    }
    refill();

    return {
      update(dt) {
        for (const b of bots) {
          b.progress = clamp(b.progress + b.speed * dt * 3.1, 0, 1.05);
        }
        if (boost > 0) boost = Math.max(0, boost - dt);
        for (const b of bots) {
          if (b.progress >= 1 && !b.doneAt) b.doneAt = ctx.elapsed;
        }
        if (player >= 1 && !finished) {
          finished = true;
          place = 1 + bots.filter((b) => b.progress >= 1).length;
          ctx.status(place === 1 ? 'Chequered flag — first place' : `Finished ${place}${place === 2 ? 'nd' : place === 3 ? 'rd' : 'th'}`);
          ctx.level(place);
          ctx.finish('COMPLETE');
        }
        if (bots.every((b) => b.progress >= 1) && !finished) {
          finished = true;
          ctx.status('Every bot finished first');
          ctx.finish('GAME_OVER');
        }
      },
      onKey(ch) {
        const expected = current[typedIdx];
        if (ch === expected) {
          typedIdx += 1;
          player = clamp(player + (0.0075 + (boost > 0 ? 0.002 : 0)) * (d.speed > 1 ? 1.15 : 1), 0, 1);
          if (typedIdx >= current.length) {
            words.shift();
            refill();
            ctx.hit(20);
            boost = 0.35;
          } else {
            ctx.hit(6);
          }
          return true;
        }
        // wrong key: stall
        player = Math.max(0, player - 0.004);
        boost = 0;
        return false;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#101820', bottom: '#0c1116' });

        const left = 70;
        const right = W - 70;
        const laneH = 54;
        const top = 110;
        const trackLen = right - left;

        // track
        g.fillStyle = 'rgba(255,255,255,0.03)';
        g.fillRect(left - 6, top - 18, trackLen + 12, laneH * 4 + 20);
        for (let i = 0; i <= 4; i += 1) {
          g.strokeStyle = 'rgba(255,255,255,0.07)';
          g.beginPath();
          g.moveTo(left - 6, top - 18 + i * laneH);
          g.lineTo(right + 6, top - 18 + i * laneH);
          g.stroke();
        }
        // finish line
        for (let y = top - 18; y < top - 18 + laneH * 4; y += 10) {
          g.fillStyle = (Math.floor((y - top) / 10) % 2 === 0) ? '#dfe4ea' : '#2b323c';
          g.fillRect(right - 4, y, 8, 10);
        }

        const rows = [
          { label: 'YOU', progress: player, color: '#7fb3a5', isMe: true },
          ...bots.map((b2) => ({ label: b2.name, progress: b2.progress, color: b2.color })),
        ];
        rows.forEach((row, i) => {
          const y = top + i * laneH;
          text(g, row.label, left - 14, y + 5, { size: 10, align: 'right', color: row.isMe ? '#e9edf1' : '#8d96a3', weight: '600', family: 'system-ui, sans-serif' });
          const x = left + clamp(row.progress, 0, 1) * (trackLen - 40);
          // car
          roundRect(g, x, y - 9, 30, 16, 4);
          g.fillStyle = row.color;
          g.fill();
          if (row.isMe && boost > 0) {
            g.fillStyle = 'rgba(224,160,113,0.5)';
            g.fillRect(x - 16, y - 4, 14, 6);
          }
          g.fillStyle = 'rgba(15,19,25,0.55)';
          g.fillRect(x + 8, y - 6, 8, 12);
        });

        // typing strip
        const stripY = H - 130;
        panel(g, 40, stripY, W - 80, 84, { radius: 10 });
        const cur = current ?? '';
        const size = 26;
        const full = words.slice(0, 4).join(' ');
        const tw = measure(g, full, size);
        const startX = W / 2 - tw / 2;
        text(g, 'TYPE TO DRIVE', 56, stripY + 26, { size: 9, color: '#8d96a3', weight: '600' });
        const donePart = cur.slice(0, typedIdx);
        const rest = cur.slice(typedIdx);
        text(g, donePart, startX, stripY + 58, { size, color: '#8ee0b8', weight: '600' });
        const doneW = measure(g, donePart, size);
        text(g, rest, startX + doneW, stripY + 58, { size, color: '#e9edf1', weight: '600' });
        text(g, words.slice(1, 4).join(' '), startX + measure(g, cur, size) + 14, stripY + 58, { size: size * 0.8, color: 'rgba(233,237,241,0.32)' });

        // progress bar for the player
        bar(g, left, H - 34, trackLen, 6, player, { color: '#7fb3a5' });
        text(g, `${Math.round(player * 100)}% of the circuit`, W / 2, H - 14, { size: 11, align: 'center', color: '#8d96a3', family: 'system-ui, sans-serif' });
        lerp(0, 1, 0);
      },
    };
  },
};
