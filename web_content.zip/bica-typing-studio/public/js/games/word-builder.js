/** GAME 9 — Word Builder. Supply the missing letters of each word. */
import { backdrop, text, roundRect, rngFrom, wordPool, measure, panel, bar } from './util.js';

export default {
  id: 'word-builder',
  create(ctx) {
    const rnd = rngFrom(Date.now() + 113);
    const pool = wordPool(ctx.difficulty === 'easy' ? 'easy' : ctx.difficulty === 'hard' ? 'hard' : 'normal');
    const blankCount = ctx.difficulty === 'easy' ? 1 : ctx.difficulty === 'hard' ? 3 : 2;
    let current = null;
    let typedIdx = 0;
    let solved = 0;
    let streak = 0;
    let bestStreak = 0;
    let lives = 3;
    let revealed = null;

    function newWord() {
      let word = pool[Math.floor(rnd() * pool.length)];
      if (word.length < blankCount + 2) word = pool.find((w) => w.length >= blankCount + 3) ?? word;
      const positions = new Set();
      while (positions.size < Math.min(blankCount, word.length - 2)) {
        positions.add(1 + Math.floor(rnd() * (word.length - 2)));
      }
      current = {
        word,
        blanks: [...positions].sort((a, b) => a - b),
        hint: word.slice(0, Math.min(2, word.length)),
      };
      typedIdx = 0;
      revealed = current.word.split('').map((c, i) => (current.blanks.includes(i) ? null : c));
    }
    newWord();

    function expectedChar() {
      const pos = current.blanks[typedIdx];
      return pos == null ? null : current.word[pos];
    }

    return {
      update() { /* word is solved by keystrokes only */ },
      onKey(ch) {
        const expected = expectedChar();
        if (expected == null) return null;
        if (ch.toLowerCase() !== expected) {
          streak = 0;
          lives -= 1;
          ctx.status(`Wrong letter — ${lives} attempt${lives === 1 ? '' : 's'} left on this word`);
          if (lives <= 0) { ctx.level(solved); ctx.finish('GAME_OVER'); return false; }
          return false;
        }
        revealed[current.blanks[typedIdx]] = expected;
        typedIdx += 1;
        if (typedIdx >= current.blanks.length) {
          solved += 1;
          streak += 1;
          bestStreak = Math.max(bestStreak, streak);
          ctx.hit(14 + current.word.length * 3 + streak * 4);
          ctx.status(`Solved ${current.word} · streak ${streak}`);
          newWord();
        }
        return true;
      },
      render(g) {
        const W = ctx.width;
        const H = ctx.height;
        backdrop(g, W, H, { top: '#111820', bottom: '#0c1216' });

        const size = Math.min(58, (W - 220) / Math.max(6, current.word.length));
        const wordW = measure(g, current.word, size);
        const startX = W / 2 - wordW / 2;
        const baseY = H / 2 + 10;

        text(g, 'COMPLETE THE WORD', W / 2, H / 2 - 90, { size: 10, align: 'center', color: '#8d96a3', weight: '600' });

        let cursorX = startX;
        let nextBlankIndex = current.blanks[typedIdx];
        current.word.split('').forEach((c, i) => {
          const isBlank = current.blanks.includes(i);
          const charW = measure(g, c, size);
          if (isBlank) {
            const solved = revealed[i] != null;
            const isNext = i === nextBlankIndex;
            roundRect(g, cursorX - 4, baseY - size + 6, charW + 8, size + 4, 6);
            g.fillStyle = solved ? 'rgba(127,179,165,0.18)' : isNext ? 'rgba(224,160,113,0.22)' : 'rgba(255,255,255,0.06)';
            g.fill();
            g.strokeStyle = isNext ? '#e0a071' : 'rgba(255,255,255,0.14)';
            g.lineWidth = isNext ? 1.8 : 1;
            g.stroke();
            text(g, solved ? revealed[i].toUpperCase() : '·', cursorX, baseY, {
              size, color: solved ? '#8ee0b8' : isNext ? '#e0a071' : '#5d6672', align: 'left', weight: '700',
            });
          } else {
            text(g, c, cursorX, baseY, { size, color: '#e9edf1', align: 'left', weight: '400' });
          }
          cursorX += charW;
        });

        // progress of the current word
        bar(g, W / 2 - 120, baseY + 40, 240, 5, typedIdx / current.blanks.length, { color: '#7fb3a5' });

        panel(g, 14, 12, 260, 50, { radius: 8 });
        text(g, `${solved} words solved`, 26, 32, { size: 12, color: '#e9edf1' });
        text(g, `streak ${streak} · best ${bestStreak}`, 26, 50, { size: 10, color: '#8d96a3', family: 'system-ui, sans-serif' });

        text(g, `Type only the missing letters, left to right — one mistake costs an attempt`, W / 2, H - 34, {
          size: 12, align: 'center', color: 'rgba(233,237,241,0.4)', family: 'system-ui, sans-serif',
        });
      },
    };
  },
};
