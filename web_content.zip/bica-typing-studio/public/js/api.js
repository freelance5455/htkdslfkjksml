/** JSON API client with consistent error shape and offline awareness. */

export class ApiError extends Error {
  constructor(message, { status = 0, code = 'network_error', field = null, payload = null } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.field = field;
    this.payload = payload;
  }
  get isNetwork() { return this.status === 0; }
  get isAuth() { return this.status === 401; }
}

async function request(method, path, body, { signal } = {}) {
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: body === undefined ? {} : { 'content-type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: 'same-origin',
      signal,
    });
  } catch (err) {
    throw new ApiError('Could not reach the server. Check the connection to your lab server.', { code: 'offline' });
  }

  if (res.status === 204) return null;
  const text = await res.text();
  let data = null;
  if (text) {
    try { data = JSON.parse(text); } catch { data = { message: text.slice(0, 200) }; }
  }
  if (!res.ok) {
    throw new ApiError(
      data?.message || defaultMessage(res.status),
      { status: res.status, code: data?.error ?? `http_${res.status}`, field: data?.field ?? null, payload: data },
    );
  }
  return data;
}

function defaultMessage(status) {
  if (status === 401) return 'Please sign in again.';
  if (status === 403) return 'You do not have permission to do that.';
  if (status === 404) return 'That item could not be found.';
  if (status === 429) return 'Too many attempts. Please wait and try again.';
  if (status >= 500) return 'The server hit an error. Please try again.';
  return 'The request could not be completed.';
}

export const api = {
  get: (path, opts) => request('GET', path, undefined, opts),
  post: (path, body, opts) => request('POST', path, body ?? {}, opts),
  patch: (path, body, opts) => request('PATCH', path, body ?? {}, opts),
  put: (path, body, opts) => request('PUT', path, body ?? {}, opts),
  del: (path, body, opts) => request('DELETE', path, body ?? {}, opts),
};

/** Download a binary endpoint through the browser (uses the session cookie). */
export async function downloadFile(path, filename) {
  const res = await fetch(path, { credentials: 'same-origin' });
  if (!res.ok) {
    let message = 'The file could not be generated.';
    try { const j = await res.json(); message = j.message || message; } catch { /* binary */ }
    throw new ApiError(message, { status: res.status });
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function openPdf(path) {
  const win = window.open(path, '_blank', 'noopener');
  if (!win) throw new ApiError('Your browser blocked the new tab. Allow pop-ups for this site.');
}
