/**
 * Offline queue (IndexedDB) + service-worker registration.
 * Every completed activity is written locally first when the network is down,
 * then replayed. The server's UNIQUE(client_session_id) makes replay idempotent.
 */
import { api } from './api.js';
import { state, emit } from './store.js';

const DB_NAME = 'bica-typing-studio';
const DB_VERSION = 1;
const STORE = 'pending';

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('kind', 'kind');
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function tx(mode, fn) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const store = t.objectStore(STORE);
    let result;
    try { result = fn(store); } catch (err) { reject(err); return; }
    t.oncomplete = () => resolve(result);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
}

export async function queueActivity({ kind, endpoint, payload, label = 'Activity' }) {
  const id = (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  await tx('readwrite', (store) => store.put({
    id, kind, endpoint, payload, label,
    createdAt: new Date().toISOString(),
    attempts: 0,
    status: 'pending',
    lastError: null,
  }));
  await refreshCount();
  return id;
}

export async function listPending() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORE, 'readonly');
    const req = t.objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result.sort((a, b) => a.createdAt.localeCompare(b.createdAt)));
    req.onerror = () => reject(req.error);
  });
}

async function removePending(id) {
  await tx('readwrite', (store) => store.delete(id));
}

async function markAttempt(id, error) {
  const db = await openDb();
  return new Promise((resolve) => {
    const t = db.transaction(STORE, 'readwrite');
    const store = t.objectStore(STORE);
    const get = store.get(id);
    get.onsuccess = () => {
      const row = get.result;
      if (row) {
        row.attempts += 1;
        row.lastError = error ? String(error).slice(0, 300) : null;
        row.status = error ? 'failed' : 'pending';
        store.put(row);
      }
      resolve();
    };
    t.oncomplete = () => resolve();
  });
}

export async function refreshCount() {
  try {
    const rows = await listPending();
    state.pendingSync = rows.length;
    emit('sync');
  } catch {
    state.pendingSync = 0;
  }
}

let flushing = false;
export async function flushQueue() {
  if (flushing) return { synced: 0, remaining: state.pendingSync };
  if (!navigator.onLine) return { synced: 0, remaining: state.pendingSync };
  flushing = true;
  state.syncState = 'syncing';
  emit('sync');
  let synced = 0;
  try {
    const rows = await listPending();
    for (const row of rows) {
      try {
        await api.post(row.endpoint, row.payload);
        await removePending(row.id);
        synced += 1;
      } catch (err) {
        if (err.status >= 400 && err.status < 500 && err.status !== 429) {
          // Permanent rejection (validation, expired token): keep the record but
          // mark it failed so the student can see it was not counted.
          await markAttempt(row.id, err.message);
        } else {
          await markAttempt(row.id, err.message);
          break; // network blip — stop and retry later
        }
      }
    }
  } finally {
    flushing = false;
    state.syncState = 'idle';
    await refreshCount();
    emit('sync');
  }
  return { synced, remaining: state.pendingSync };
}

/** Retry one failed record, or discard it deliberately. */
export async function retryPending(id) {
  const rows = await listPending();
  const row = rows.find((r) => r.id === id);
  if (!row) return;
  try {
    await api.post(row.endpoint, row.payload);
    await removePending(id);
  } catch (err) {
    await markAttempt(id, err.message);
  }
  await refreshCount();
}

export async function discardPending(id) {
  await removePending(id);
  await refreshCount();
}

export function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => {
      console.warn('[bica] service worker not registered:', err.message);
    });
  });
}

export function watchConnectivity() {
  const update = () => {
    state.online = navigator.onLine;
    emit('online');
    if (navigator.onLine) flushQueue();
  };
  window.addEventListener('online', update);
  window.addEventListener('offline', update);
  setInterval(() => { if (navigator.onLine && state.pendingSync > 0) flushQueue(); }, 45000);
}
