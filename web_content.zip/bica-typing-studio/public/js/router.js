/** Hash router. Patterns like '#/learn/:lessonId'. */

const routes = [];
let notFoundHandler = null;
let beforeRender = null;

export function route(pattern, handler, options = {}) {
  routes.push({ pattern, handler, options, segments: pattern.split('/').filter(Boolean) });
}

export function setNotFound(handler) { notFoundHandler = handler; }
export function setBeforeRender(fn) { beforeRender = fn; }

export function parseHash(hash = location.hash) {
  const raw = String(hash || '').replace(/^#\/?/, '');
  const [pathPart, queryPart] = raw.split('?');
  const segments = pathPart.split('/').filter(Boolean);
  const query = Object.fromEntries(new URLSearchParams(queryPart || ''));
  return { segments, query, path: segments.join('/') };
}

function match(segments) {
  for (const r of routes) {
    if (r.segments.length !== segments.length) continue;
    const params = {};
    let ok = true;
    for (let i = 0; i < r.segments.length; i += 1) {
      const pattern = r.segments[i];
      if (pattern.startsWith(':')) params[pattern.slice(1)] = decodeURIComponent(segments[i]);
      else if (pattern !== segments[i]) { ok = false; break; }
    }
    if (ok) return { route: r, params };
  }
  return null;
}

export async function resolve() {
  const { segments, query } = parseHash();
  const found = match(segments.length ? segments : ['']);
  if (!found) {
    if (notFoundHandler) return notFoundHandler({ query });
    return null;
  }
  if (beforeRender) {
    const verdict = await beforeRender(found.route, found.params, query);
    if (verdict === false) return null;
  }
  return found.route.handler({ params: found.params, query });
}

export function navigate(path, { replace = false } = {}) {
  const target = path.startsWith('#') ? path : `#/${path.replace(/^\//, '')}`;
  if (location.hash === target) { resolve(); return; }
  if (replace) history.replaceState(null, '', target);
  else location.hash = target;
  if (replace) resolve();
}

export function start() {
  window.addEventListener('hashchange', () => { resolve(); });
  if (!location.hash) history.replaceState(null, '', '#/dashboard');
  return resolve();
}
