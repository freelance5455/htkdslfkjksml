/**
 * Typing workspace.
 *
 * One implementation used by lessons, practice, examinations and challenges.
 * Keystrokes are handled here, measured by the shared engine, and submitted to
 * the server, which recomputes everything and decides pass/fail.
 *
 * Performance notes:
 *  - only the visible window of characters is in the DOM (default 220 glyphs)
 *  - a keypress touches at most three spans, never the whole tree
 *  - the HUD is throttled to ~12 updates/second
 *  - no animation is allowed to block input: all cosmetic work is deferred to rAF
 */
import { TypingSession, toChars } from '/shared/typing-engine.js';
import { KEY_ROWS, KEY_WIDTH, keyForChar, FINGER_COLOR, FINGER_LABEL } from '/shared/keyboard.js';
import { api } from './api.js';
import { el, mount, icon, fmtClock } from './ui.js';
import { toast } from './ui.js';
import { registerOverlay } from './overlays.js';
import { queueActivity } from './offline.js';

const WINDOW_SIZE = 220;

function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() : `s-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

/**
 * @returns {{destroy:Function, finished:Promise}}
 */
export function openTypingWorkspace(options) {
  const {
    text, mode = 'text', durationSec = null, allowBackspace = true,
    showTimer = true, showLiveWpm = true, tokenId, source = 'practice',
    refId = null, sessionTitle = '', meta = {}, thresholds = null, passMark = null,
    onExit = null, onComplete = null,
  } = options;

  const session = new TypingSession({
    target: text,
    mode: mode === 'time' ? 'time' : 'text',
    durationMs: mode === 'time' ? durationSec * 1000 : null,
    allowBackspace,
  });

  const total = toChars(text).length;

  // ---------------------------------------------------------------- markup
  const timerValue = el('div', { class: 'tstat__value num' }, showTimer ? fmtClock(session.remainingMs ?? 0) : '—');
  const wpmValue = el('div', { class: 'tstat__value num' }, '0');
  const accValue = el('div', { class: 'tstat__value num' }, '100%');
  const progressFill = el('div', { class: 'typing-progress__fill', style: { width: '0%' } });
  const targetHost = el('div', {
    class: 'typing-target', role: 'textbox', 'aria-multiline': 'false',
    'aria-label': 'Typing area. Type the passage shown.', tabindex: '0',
  });
  const liveRegion = el('div', { class: 'sr-only', 'aria-live': 'polite' });
  const fingerHost = el('div', { class: 'typing-finger' });
  const kbHost = el('div', { class: 'kb', 'aria-hidden': 'true' });

  const finishBtn = el('button', { class: 'btn btn--sm', onclick: () => finish('manual') }, 'Finish');
  const exitBtn = el('button', { class: 'btn btn--sm btn--ghost', onclick: () => attemptExit() }, 'Exit');

  const root = el('div', { class: 'typing-screen', role: 'dialog', 'aria-modal': 'true', 'aria-label': sessionTitle || 'Typing exercise' },
    el('div', { class: 'typing-bar' },
      el('div', {},
        el('div', { class: 'typing-bar__title' }, sessionTitle || 'Typing exercise'),
        el('div', { class: 'typing-bar__sub' }, describeMode())),
      el('div', { class: 'typing-bar__stats' },
        showTimer ? el('div', { class: 'tstat' }, el('div', { class: 'tstat__label' }, mode === 'time' ? 'Remaining' : 'Elapsed'), timerValue) : null,
        showLiveWpm ? el('div', { class: 'tstat' }, el('div', { class: 'tstat__label' }, 'Live WPM'), wpmValue) : null,
        el('div', { class: 'tstat' }, el('div', { class: 'tstat__label' }, 'Accuracy'), accValue),
        finishBtn,
        exitBtn)),
    el('div', { class: 'typing-progress' }, progressFill),
    el('div', { class: 'typing-body' },
      targetHost,
      el('div', { class: 'typing-hint' },
        el('span', {}, 'Type what you see · '),
        el('span', {}, el('kbd', {}, 'Esc'), ' to leave'),
        allowBackspace ? el('span', {}, el('kbd', {}, 'Backspace'), ' corrections allowed') : el('span', { class: 'badge badge--warn' }, 'Backspace disabled'))),
    el('div', { class: 'typing-foot' },
      fingerHost,
      el('div', { class: 'typing-foot__spacer' }),
      kbHost),
    liveRegion);

  function describeMode() {
    if (mode === 'time') return `${durationSec} second timed exercise`;
    return `${total} characters`;
  }

  // ------------------------------------------------------------- rendering
  let renderedWindow = { from: -1, to: -1 };
  let resultOverlay = null;
  const spanByIndex = new Map();

  let cursorSpan = null;

  /**
   * Rebuilds the visible slice of the passage.
   *
   * `renderWindow` and `updateChar` must never call each other in a loop: an
   * index outside the window used to trigger a re-render, which repainted the
   * cursor, which asked for a re-render again. The window is derived from
   * `session.index` and always contains the cursor, so a missing span means the
   * glyph is simply not on screen — nothing to paint, no re-render.
   */
  function renderWindow(force = false) {
    const view = session.renderState({ window: WINDOW_SIZE, lead: 60 });
    if (!force && view.from === renderedWindow.from && view.to === renderedWindow.to) return;
    renderedWindow = { from: view.from, to: view.to };
    spanByIndex.clear();
    const frag = document.createDocumentFragment();
    for (const row of view.chars) {
      const cls = row.char === ' ' ? 'ch ch--space' : 'ch';
      const span = el('span', { class: cls, dataset: { i: String(row.i) } }, row.char === ' ' ? '\u00a0' : row.char);
      spanByIndex.set(row.i, span);
      frag.appendChild(span);
    }
    mount(targetHost, frag);
    cursorSpan = null;
    paintChar(view.cursor);
    paintCursor();
  }

  /** Repaint one glyph's correctness class (no side effects beyond that span). */
  function paintChar(i) {
    const span = spanByIndex.get(i);
    if (!span) return;
    const state = session.charState(i);
    span.className = `${session.targetChars[i] === ' ' ? 'ch ch--space' : 'ch'}${state === 'correct' ? ' ch--correct' : state === 'incorrect' ? ' ch--incorrect' : ''}`;
  }

  function paintCursor() {
    if (cursorSpan) cursorSpan.classList.remove('ch--current');
    cursorSpan = spanByIndex.get(session.index) ?? null;
    if (cursorSpan) cursorSpan.classList.add('ch--current');
  }

  function updateChar(i) {
    paintChar(i);
    paintCursor();
  }

  function updateKeyboard() {
    const nextChar = session.targetChars[session.index];
    const info = nextChar ? keyForChar(nextChar) : null;
    for (const btn of kbHost.querySelectorAll('.kb__key')) {
      btn.classList.remove('kb__key--next', 'kb__key--next-shift');
      if (!info) continue;
      const matches = btn.dataset.key === info.key
        || (info.shift && (info.key === 'ShiftLeft' || info.key === 'ShiftRight') && btn.dataset.key === 'ShiftLeft');
      if (matches) btn.classList.add(info.shift && (btn.dataset.key === 'ShiftLeft') ? 'kb__key--next-shift' : 'kb__key--next');
    }
    if (info?.finger) {
      mount(fingerHost,
        el('span', { class: 'typing-finger__swatch', style: { background: FINGER_COLOR[info.finger] } }),
        el('span', {}, `Next key `),
        el('span', { class: 'mono', style: { fontWeight: '600' } }, nextChar === ' ' ? 'Space' : nextChar),
        el('span', { class: 'muted' }, ` · ${FINGER_LABEL[info.finger] ?? ''}`));
    } else {
      mount(fingerHost, el('span', { class: 'muted' }, 'Passage complete'));
    }
  }

  function buildKeyboard() {
    if (!('ontouchstart' in window) && window.innerWidth < 860) return;
    const frag = document.createDocumentFragment();
    for (const row of KEY_ROWS) {
      const rowEl = el('div', { class: 'kb__row' });
      for (const key of row) {
        const width = KEY_WIDTH[key];
        const label = key === 'Space' ? '' : (key.startsWith('Shift') ? 'Shift' : key === 'Backspace' ? '⌫' : key);
        rowEl.appendChild(el('div', {
          class: `kb__key${key === 'f' || key === 'j' ? ' kb__key--home' : ''}`,
          dataset: { key },
          style: width ? { flex: 'none', width: `${width * 27}px` } : {},
          title: label,
        }, label));
      }
      frag.appendChild(rowEl);
    }
    mount(kbHost, frag);
  }

  let hudLast = 0;
  function updateHud(force = false) {
    const now = performance.now();
    if (!force && now - hudLast < 80) return;
    hudLast = now;
    const live = session.live();
    wpmValue.textContent = String(Math.round(live.grossWpm));
    accValue.textContent = `${live.accuracy.toFixed(0)}%`;
    accValue.className = `tstat__value num ${live.accuracy < 90 ? 'tstat__value--warn' : ''}`;
    if (showTimer) {
      timerValue.textContent = mode === 'time' ? fmtClock(session.remainingMs ?? 0) : fmtClock(session.elapsedMs);
      timerValue.className = `tstat__value num ${mode === 'time' && (session.remainingMs ?? 0) < 10000 ? 'tstat__value--warn' : ''}`;
    }
    const pctDone = mode === 'time'
      ? Math.min(100, (session.elapsedMs / (durationSec * 1000)) * 100)
      : Math.min(100, (session.index / total) * 100);
    progressFill.style.width = `${pctDone}%`;
  }

  // ---------------------------------------------------------------- input --
  let lastAnnounced = 0;
  function onKeyDown(event) {
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    if (event.key === 'Escape') { event.preventDefault(); attemptExit(); return; }
    if (session.finished) return;

    if (event.key === 'Backspace') {
      event.preventDefault();
      session.press('Backspace');
      updateChar(session.index);
      updateKeyboard();
      updateHud(true);
      return;
    }
    if (event.key.length !== 1) return; // ignore Shift, arrows, F-keys, Tab
    event.preventDefault();
    const result = session.press(event.key);
    if (!result.accepted) return;

    renderWindow();
    updateChar(session.index - 1);
    updateChar(session.index);
    updateKeyboard();
    updateHud();

    const live = session.live();
    if (live.errorKeystrokes > lastAnnounced) {
      lastAnnounced = live.errorKeystrokes;
      liveRegion.textContent = `Mistake. Accuracy ${live.accuracy.toFixed(0)} percent.`;
    }
    if (result.finished) finish('complete');
  }

  function onTimerTick() {
    if (session.finished) return;
    updateHud();
    if (session.isExpired) finish('time');
  }

  let timerId = null;
  let finished = false;
  let resolveFinished;
  const finishedPromise = new Promise((resolve) => { resolveFinished = resolve; });

  function attemptExit() {
    if (session.finished) { destroy(); if (onExit) onExit(); return; }
    if (session.forwardKeystrokes === 0) { destroy(); if (onExit) onExit(); return; }
    import('./ui.js').then(({ confirmDialog }) => {
      confirmDialog({
        title: 'Leave this exercise?',
        message: 'The attempt will not be recorded. Your keystrokes so far are discarded.',
        confirmLabel: 'Leave',
        danger: true,
      }).then((ok) => {
        if (ok) { destroy(); if (onExit) onExit(); }
      });
    });
  }

  let unregister = null;
  function destroy() {
    if (timerId) clearInterval(timerId);
    window.removeEventListener('keydown', onKeyDown);
    root.remove();
    if (resultOverlay) { resultOverlay.remove(); resultOverlay = null; }
    document.body.classList.remove('exam-mode');
    if (unregister) { unregister(); unregister = null; }
  }

  // ---------------------------------------------------------------- submit
  async function finish(reason) {
    if (finished) return;
    finished = true;
    const summary = session.finish();
    if (timerId) clearInterval(timerId);
    updateHud(true);
    const localMetrics = {
      grossWpm: summary.grossWpm,
      netWpm: summary.netWpm,
      accuracy: summary.accuracy,
      consistency: summary.consistency,
      committedChars: summary.committedChars,
      correctChars: summary.correctChars,
      errorKeystrokes: summary.errorKeystrokes,
      uncorrectedErrors: summary.uncorrectedErrors,
      durationMs: summary.elapsedMs,
    };

    const why = reason === 'manual' ? 'You ended the exercise early, so the result reflects only the part you typed.' : null;
    const payload = {
      tokenId,
      clientSessionId: uuid(),
      title: sessionTitle,
      mode: mode === 'time' ? 'time' : 'text',
      summary: {
        ...localMetrics,
        forwardKeystrokes: summary.forwardKeystrokes,
        backspaces: summary.backspaces,
        // Rhythm samples: the server recomputes consistency from these rather
        // than trusting a number computed in the browser.
        intervals: summary.intervals,
        perKey: summary.perKey,
        bigrams: summary.bigrams.slice(0, 40),
        timeline: summary.timeline,
        committedChars: summary.committedChars,
      },
      meta: { ...meta, finishReason: reason, timeline: summary.timeline, errorPositions: summary.errorPositions.slice(0, 200) },
    };

    let serverResult = null;
    let offline = false;
    try {
      serverResult = await api.post('/api/sessions', payload);
    } catch (err) {
      if (err.isNetwork || err.code === 'offline') {
        await queueActivity({ kind: source, endpoint: '/api/sessions', payload, label: sessionTitle });
        offline = true;
      } else if (err.status === 422 || err.status === 409) {
        toast(err.message, { type: 'warn', timeout: 7000 });
        offline = false;
        serverResult = null;
        showFailure(err.message, localMetrics, why);
        return;
      } else {
        toast(err.message, { type: 'error' });
        showFailure(err.message, localMetrics, why);
        return;
      }
    }

    const verified = Boolean(serverResult?.session?.verified);
    const metrics = serverResult?.session ?? { ...localMetrics, verified: false };
    showResult({
      metrics,
      passed: serverResult ? serverResult.passed : null,
      reasons: serverResult?.reasons ?? [],
      thresholds: serverResult?.thresholds ?? thresholds ?? passMark ?? null,
      achievements: serverResult?.newAchievements ?? [],
      verified,
      offline,
      why,
    });
    if (onComplete) onComplete({ metrics, passed: serverResult?.passed ?? null, offline });
    resolveFinished({ metrics, passed: serverResult?.passed ?? null, offline });
  }

  // -------------------------------------------------------------- results --
  function showResult({ metrics, passed, reasons, thresholds: th, achievements, verified, offline, why }) {
    const verdictClass = passed === false ? 'result__verdict--fail' : 'result__verdict--pass';
    const verdictIcon = passed === false ? 'alert' : 'check';
    const verdictText = passed === false
      ? 'Not yet at the requirement'
      : passed === true ? 'Requirement met' : 'Session complete';

    const stat = (label, value, hint) => el('div', { class: 'result__stat' },
      el('b', {}, value), el('span', {}, label), hint ? el('div', { class: 'tiny muted' }, hint) : null);

    const panel = el('div', { class: 'result' },
      el('div', { class: 'result__head' },
        el('div', { class: `result__verdict ${verdictClass}` }, icon(verdictIcon, 22)),
        el('div', {},
          el('div', { class: 'eyebrow' }, offline ? 'Saved locally' : verified ? 'Verified result' : 'Result'),
          el('h2', {}, verdictText),
          el('p', { class: 'muted', style: { margin: '4px 0 0' } },
            offline
              ? 'There is no connection to the lab server right now. This attempt is stored on this computer and will be submitted automatically when the connection returns.'
              : `${metrics.committedChars} characters in ${fmtClock(metrics.durationMs)}.`))),

      el('div', { class: 'result__grid' },
        stat('Net WPM', metrics.netWpm ?? 0),
        stat('Gross WPM', metrics.grossWpm ?? 0),
        stat('Accuracy', `${metrics.accuracy ?? 0}%`),
        stat('Consistency', `${metrics.consistency ?? 0}%`),
        stat('Errors', `${metrics.errorKeystrokes ?? 0}`, `${metrics.uncorrectedErrors ?? 0} left uncorrected`),
        stat('Correct chars', `${metrics.correctChars ?? 0}`, `of ${metrics.committedChars ?? 0}`)),

      th ? el('div', { class: 'panel', style: { marginTop: '20px' } },
        el('div', { class: 'panel__head' }, el('h3', {}, 'Requirement')),
        el('div', { class: 'panel__body' },
          el('div', { class: 'small' },
            `Accuracy ≥ ${th.minAccuracy ?? 0}%`, (th.minWpm ?? 0) > 0 ? ` · Net speed ≥ ${th.minWpm} WPM` : '',
            ` · Measured ${metrics.accuracy ?? 0}%${(th.minWpm ?? 0) > 0 ? ` at ${metrics.netWpm ?? 0} WPM` : ''}`),
          reasons?.length ? el('div', { class: 'result__notes' },
            el('div', { class: 'small', style: { fontWeight: '600', marginBottom: '4px' } }, 'What to fix'),
            el('ul', { style: { margin: '0', paddingLeft: '18px' } }, reasons.map((r) => el('li', { class: 'small' }, r)))) : null)) : null,

      why ? el('p', { class: 'small muted', style: { marginTop: '16px' } }, why) : null,

      achievements?.length ? el('div', { style: { marginTop: '20px' } },
        el('div', { class: 'eyebrow' }, 'New achievements'),
        el('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } },
          achievements.map((a) => el('span', { class: 'badge badge--gold' }, icon('award', 12), a.name)))) : null,

      el('div', { class: 'result__formula' },
        `grossWPM = (chars ÷ 5) ÷ minutes · netWPM = max(0, grossWPM − uncorrected errors per minute) · accuracy = correct keystrokes ÷ all keystrokes. `
        + `A corrected mistake still counts against accuracy.`),

      el('div', { style: { display: 'flex', gap: '10px', marginTop: '24px', flexWrap: 'wrap' } },
        el('button', {
          class: 'btn btn--primary',
          onclick: () => {
            destroy();
            if (onExit) onExit();
            else if (onComplete) onComplete({ metrics, passed, offline });
          },
        }, 'Continue'),
        el('button', { class: 'btn', onclick: () => { if (options.onRetry) { destroy(); options.onRetry(); } } }, icon('reload', 14), 'Try again')));

    const overlay = el('div', {
      class: 'dialog-backdrop', style: { zIndex: '90', background: 'var(--paper)', alignItems: 'start', paddingTop: '6vh', overflow: 'auto' },
    }, el('div', { style: { width: 'min(880px, 100%)' } }, panel));
    resultOverlay = overlay;
    // The result screen replaces the workspace *inside* the workspace
    // container, so navigating away (or destroy()) can never leave an
    // orphaned overlay sitting over the application.
    mount(root, overlay);
    window.removeEventListener('keydown', onKeyDown);
    document.body.classList.remove('exam-mode');
    const btn = overlay.querySelector('button');
    if (btn) btn.focus();
  }

  function showFailure(message, metrics, why) {
    showResult({
      metrics: { ...metrics, verified: false }, passed: false, reasons: [message], thresholds: null, achievements: [], verified: false, offline: false, why,
    });
  }

  // ------------------------------------------------------------------ boot
  // NB: append, never mount() — mount() clears its target, and wiping <body>
  // takes the whole application shell with it.
  document.body.appendChild(root);
  if (options.examMode) document.body.classList.add('exam-mode');
  buildKeyboard();
  renderWindow(true);
  updateKeyboard();
  updateHud(true);
  window.addEventListener('keydown', onKeyDown);
  targetHost.focus({ preventScroll: true });
  root.addEventListener('mousedown', () => targetHost.focus({ preventScroll: true }));
  timerId = setInterval(onTimerTick, 200);

  if (mode === 'time' && !showTimer) {
    timerValue.textContent = 'hidden';
  }


  unregister = registerOverlay(destroy);

  return {
    destroy,
    finished: finishedPromise,
    session,
    finish: () => finish('manual'),
  };
}

/** Fetch and open a lesson drill. */
export async function startLesson(lessonId, drillIndex, { onExit, onComplete, onRetry }) {
  const data = await api.post(`/api/curriculum/lessons/${lessonId}/start`, { drillIndex });
  return openTypingWorkspace({
    text: data.text,
    mode: data.lesson.isExam && data.lesson.durationMs ? 'time' : 'text',
    durationSec: data.lesson.durationMs ? Math.round(data.lesson.durationMs / 1000) : null,
    tokenId: data.tokenId,
    source: 'lesson',
    refId: lessonId,
    sessionTitle: `${data.lesson.id} — ${data.lesson.title}`,
    meta: { drillIndex: data.drillIndex },
    thresholds: data.thresholds,
    examMode: Boolean(data.lesson.isExam),
    onExit,
    onComplete,
    onRetry,
  });
}
