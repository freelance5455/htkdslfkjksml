/** Tiny observable store. Holds the signed-in user, centre settings and UI prefs. */

const listeners = new Set();

export const state = {
  user: null,
  settings: null,
  online: typeof navigator === 'undefined' ? true : navigator.onLine,
  pendingSync: 0,
  syncState: 'idle', // idle | syncing | error
};

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function emit(reason = 'update') {
  for (const fn of listeners) {
    try { fn(state, reason); } catch (err) { console.error('[bica] listener failed', err); }
  }
}

export function setUser(user) {
  state.user = user;
  applyPrefs(user?.prefs);
  emit('user');
}

export function setPrefs(prefs) {
  if (state.user) state.user.prefs = { ...state.user.prefs, ...prefs };
  applyPrefs(state.user?.prefs);
  emit('prefs');
}

export function applyPrefs(prefs = {}) {
  const root = document.documentElement;
  const theme = prefs.theme === 'dark' || prefs.theme === 'light' ? prefs.theme : 'light';
  root.setAttribute('data-theme', theme);
  root.setAttribute('data-motion', prefs.reducedMotion ? 'reduced' : 'normal');
  document.body?.classList.toggle('large-text', Boolean(prefs.largeText));
}

export function isStaff(user = state.user) {
  return user?.role === 'INSTRUCTOR' || user?.role === 'ADMIN';
}

export function homeFor(user = state.user) {
  if (!user) return '#/login';
  if (user.role === 'ADMIN') return '#/admin';
  if (user.role === 'INSTRUCTOR') return '#/instructor';
  return '#/dashboard';
}
