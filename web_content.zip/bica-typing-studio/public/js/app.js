/** Application shell, routing table and boot sequence. */
import { api, ApiError } from './api.js';
import { el, mount, icon, initials, toast, clear } from './ui.js';
import { state, setUser, setPrefs, subscribe, isStaff, homeFor } from './store.js';
import { route, setNotFound, setBeforeRender, start, parseHash, navigate } from './router.js';
import { registerServiceWorker, watchConnectivity, flushQueue, refreshCount, listPending } from './offline.js';
import { dismissOverlays } from './overlays.js';
import { setLanguage, t } from './i18n.js';

const appRoot = document.getElementById('app');

// ------------------------------------------------------------------ shell --
const NAV = {
  STUDENT: [
    { section: 'Study', items: [
      { path: 'dashboard', label: 'Dashboard', icon: 'grid' },
      { path: 'learn', label: 'Learn', icon: 'book' },
      { path: 'practice', label: 'Practice', icon: 'keyboard' },
      { path: 'arcade', label: 'Arcade', icon: 'gamepad' },
      { path: 'challenge', label: 'Challenge', icon: 'trophy' },
      { path: 'progress', label: 'Progress', icon: 'chart' },
    ] },
  ],
  INSTRUCTOR: [
    { section: 'Teaching', items: [
      { path: 'instructor', label: 'Overview', icon: 'grid' },
      { path: 'instructor/classes', label: 'Classes', icon: 'users' },
      { path: 'instructor/students', label: 'Students', icon: 'user' },
      { path: 'instructor/assignments', label: 'Assignments', icon: 'file' },
      { path: 'instructor/tests', label: 'Typing tests', icon: 'keyboard' },
      { path: 'instructor/certificates', label: 'Certificates', icon: 'award' },
    ] },
    { section: 'My own practice', items: [
      { path: 'practice', label: 'Practice', icon: 'keyboard' },
      { path: 'learn', label: 'Curriculum', icon: 'book' },
    ] },
  ],
  ADMIN: [
    { section: 'Administration', items: [
      { path: 'admin', label: 'Overview', icon: 'grid' },
      { path: 'admin/users', label: 'Users', icon: 'users' },
      { path: 'admin/classes', label: 'Classes', icon: 'home' },
      { path: 'instructor/assignments', label: 'Assignments', icon: 'file' },
      { path: 'admin/settings', label: 'Settings', icon: 'settings' },
      { path: 'admin/audit', label: 'Audit log', icon: 'shield' },
      { path: 'admin/backups', label: 'Backups', icon: 'database' },
    ] },
    { section: 'Teaching', items: [
      { path: 'instructor', label: 'Instructor view', icon: 'user' },
    ] },
  ],
};

let currentCleanup = null;

export function renderShell(user) {
  if (currentCleanup) { try { currentCleanup(); } catch { /* ignore */ } currentCleanup = null; }
  clear(appRoot);
  const sections = NAV[user.role] ?? NAV.STUDENT;
  const active = parseHash().segments[0] ?? '';

  dismissOverlays();
  const nav = el('nav', { class: 'nav', 'aria-label': 'Primary' },
    el('div', { class: 'nav__brand' },
      el('div', { class: 'nav__mark' }, 'B'),
      el('div', { class: 'nav__wordmark' },
        el('strong', {}, 'BICA'),
        el('span', {}, 'Typing Studio'))),
    ...sections.map((section) => el('div', { class: 'nav__section' },
      el('div', { class: 'nav__label' }, section.section),
      ...section.items.map((item) => el('a', {
        class: 'nav__item',
        href: `#/${item.path}`,
        'aria-current': isActive(active, item.path) ? 'page' : null,
        title: item.label,
      }, icon(item.icon, 17), el('span', {}, item.label))))),
    el('div', { class: 'nav__foot' },
      el('div', { class: 'nav__user' },
        el('div', { class: 'nav__avatar', 'aria-hidden': 'true' }, initials(user.displayName)),
        el('div', { class: 'nav__meta' },
          el('strong', { title: user.displayName }, user.displayName),
          el('span', {}, user.role)),
        el('button', {
          class: 'btn btn--ghost btn--icon', style: { color: '#8d96a3' },
          title: 'Sign out', 'aria-label': 'Sign out',
          onclick: signOut,
        }, icon('logout', 16)))));

  const crumbs = el('div', { class: 'topbar__crumbs' });
  const actions = el('div', { class: 'topbar__actions' });
  const content = el('div', { class: 'content', id: 'main-content', tabindex: '-1' });

  const main = el('main', { class: 'main' },
    el('div', { class: 'topbar' },
      crumbs,
      el('div', { class: 'topbar__spacer' }),
      actions),
    content);

  mount(appRoot, el('div', { class: 'shell' }, nav, main));
  return { crumbs, actions, content };
}

function isActive(activeSegment, itemPath) {
  const first = itemPath.split('/')[0];
  if (itemPath.includes('/')) {
    const second = itemPath.split('/')[1];
    const segs = parseHash().segments;
    return segs[0] === first && segs[1] === second;
  }
  return activeSegment === first && !(first === 'instructor' && parseHash().segments.length > 1);
}

function setHeader({ title, crumbs = [], actions = [] } = {}) {
  const shell = document.querySelector('.shell');
  if (!shell) return;
  const crumbHost = shell.querySelector('.topbar__crumbs');
  const actionHost = shell.querySelector('.topbar__actions');
  if (crumbHost) {
    mount(crumbHost, ...crumbs.map((c, i) => el('span', {},
      ...(i > 0 ? [el('span', { style: { opacity: 0.5 } }, '/')] : []),
      c.href ? el('a', { href: c.href, style: { color: 'inherit', textDecoration: 'none' } }, c.label) : el('b', {}, c.label))));
  }
  if (actionHost) mount(actionHost, ...actions);
  if (title) document.title = `${title} · BICA Typing Studio`;
}

// ------------------------------------------------------------- async loader
async function view(name) {
  const module = await import(`./views/${name}.js`);
  return module.default;
}

const log = (...args) => console.info('[bica]', ...args);

async function renderRoute(handler) {
  // A typing session or an arcade round owns the whole screen. Moving to a new
  // screen always takes the screen back.
  dismissOverlays();
  const shell = document.querySelector('.shell');
  if (!shell) return;
  const content = shell.querySelector('.content');
  if (!content) return;
  document.body.classList.remove('exam-mode');
  if (currentCleanup) { try { currentCleanup(); } catch { /* ignore */ } currentCleanup = null; }
  content.className = 'content';
  mount(content, el('div', { style: { padding: '48px', textAlign: 'center', color: 'var(--ink-500)' } }, 'Loading…'));
  try {
    const result = await handler();
    if (!result) return;
    const { node, cleanup, header, wide } = result;
    if (wide) content.className = 'content content--wide';
    mount(content, node);
    if (header) setHeader(header);
    if (typeof cleanup === 'function') currentCleanup = cleanup;
    content.focus({ preventScroll: true });
    window.scrollTo({ top: 0 });
  } catch (err) {
    if (err instanceof ApiError && err.isAuth) { signOutLocal(); return; }
    console.error('[bica] route failed', err);
    mount(content, el('div', { class: 'empty' },
      el('div', { class: 'empty__icon' }, icon('alert', 40)),
      el('h3', {}, 'This screen could not be opened'),
      el('p', {}, err?.message || 'Unexpected error.'),
      el('button', { class: 'btn btn--primary', onclick: () => location.reload() }, 'Reload')));
  }
}

function defineRoutes() {
  // -- public
  route('login', async () => {
    const loginView = await view('login');
    const node = await loginView({});
    clear(appRoot);
    mount(appRoot, node);
    document.title = 'Sign in · BICA Typing Studio';
    return null;
  });
  route('verify', async () => {
    const v = await view('verify');
    const node = await v({ params: {} });
    clear(appRoot);
    mount(appRoot, node);
    return null;
  });
  route('verify/:cert', async ({ params }) => {
    const v = await view('verify');
    const node = await v({ params });
    clear(appRoot);
    mount(appRoot, node);
    return null;
  });

  // -- student
  //
  // Every authenticated route goes through `renderRoute`, which owns the mount
  // point, the loading state, the error panel and the previous view's cleanup.
  // A view module resolves to `{ node, header?, cleanup?, wide? }`.
  const screen = (name) => (ctx) => renderRoute(async () => {
    const render = await view(name);
    return render({ ...ctx, setHeader });
  });

  const studentRoute = (name, path) => route(path, screen(name),
    { roles: ['STUDENT', 'INSTRUCTOR', 'ADMIN'] });

  studentRoute('dashboard', 'dashboard');
  studentRoute('learn', 'learn');
  studentRoute('learn', 'learn/:lessonId');
  studentRoute('practice', 'practice');
  studentRoute('arcade', 'arcade');
  studentRoute('challenge', 'challenge');
  studentRoute('progress', 'progress');
  studentRoute('profile', 'profile');
  studentRoute('learn', 'curriculum');

  // -- instructor
  const staffRoute = (name, path) => route(path, screen(name),
    { roles: ['INSTRUCTOR', 'ADMIN'] });

  staffRoute('instructor', 'instructor');
  staffRoute('instructor-classes', 'instructor/classes');
  staffRoute('instructor-classes', 'instructor/classes/:classId');
  staffRoute('instructor-students', 'instructor/students');
  staffRoute('instructor-students', 'instructor/students/:studentId');
  staffRoute('instructor-assignments', 'instructor/assignments');
  staffRoute('instructor-tests', 'instructor/tests');
  staffRoute('instructor-certificates', 'instructor/certificates');

  // -- admin
  const adminRoute = (name, path) => route(path, screen(name), { roles: ['ADMIN'] });

  adminRoute('admin', 'admin');
  adminRoute('admin-users', 'admin/users');
  adminRoute('admin-classes', 'admin/classes');
  adminRoute('admin-settings', 'admin/settings');
  adminRoute('admin-audit', 'admin/audit');
  adminRoute('admin-backups', 'admin/backups');

  setBeforeRender(async (r, params) => {
    const publicPaths = ['login', 'verify'];
    const isPublic = publicPaths.includes(r.segments[0]);
    if (!state.user) {
      if (isPublic) return true;
      navigate('/login', { replace: true });
      return false;
    }
    if (isPublic && r.segments[0] === 'login') {
      navigate(homeFor(state.user), { replace: true });
      return false;
    }
    if (state.user.mustChangePw && r.segments[0] !== 'profile') {
      navigate('/profile', { replace: true });
      toast('Choose a new password to finish setting up your account.', { type: 'warn', timeout: 8000 });
      return false;
    }
    if (r.options?.roles && !r.options.roles.includes(state.user.role)) {
      renderShell(state.user);
      navigate(homeFor(state.user), { replace: true });
      toast('You do not have access to that area.', { type: 'warn' });
      return false;
    }
    return true;
  });

  setNotFound(async () => {
    if (!state.user) { navigate('/login', { replace: true }); return; }
    const shell = renderShell(state.user);
    mount(shell.content, el('div', { class: 'empty' },
      el('div', { class: 'empty__icon' }, icon('search', 40)),
      el('h3', {}, 'Page not found'),
      el('p', {}, 'That address does not exist in BICA Typing Studio.'),
      el('a', { class: 'btn btn--primary', href: `#${homeFor(state.user).slice(1)}` }, 'Go to my dashboard')));
    setHeader({ title: 'Not found' });
  });
}

// ------------------------------------------------------------------- auth --
let signingOut = false;
async function signOut() {
  if (signingOut) return;
  signingOut = true;
  try { await api.post('/api/auth/logout'); } catch { /* offline is fine */ }
  signOutLocal();
}
function signOutLocal() {
  setUser(null);
  signingOut = false;
  clear(appRoot);
  navigate('/login', { replace: true });
}

export function afterLogin(user) {
  setUser(user);
  renderShell(user);
  navigate(homeFor(user), { replace: true });
}

// ------------------------------------------------------------------- boot --
async function boot() {
  registerServiceWorker();
  watchConnectivity();
  try {
    const { user } = await api.get('/api/auth/me');
    setUser(user);
    setLanguage(user.prefs?.language || 'en');
    renderShell(user);
  } catch (err) {
    if (!(err instanceof ApiError) || !err.isAuth) {
      // Server unreachable: still show the sign-in screen with an explanation.
      log('session check failed', err.message);
    }
    setUser(null);
  }
  defineRoutes();
  await start();
  refreshCount();
  if (state.pendingSync > 0) flushQueue();
  window.addEventListener('beforeunload', (e) => {
    if (state.pendingSync > 0) {
      e.preventDefault();
      e.returnValue = 'Some practice results are still waiting to sync.';
    }
  });
  setInterval(() => {
    api.get('/api/auth/me').catch((err) => {
      if (err instanceof ApiError && err.isAuth) signOutLocal();
    });
  }, 5 * 60 * 1000);
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && e.target === document.body && state.user) {
      e.preventDefault();
      const search = document.querySelector('input[type="search"]');
      if (search) search.focus();
    }
  });
}

subscribe((s, reason) => {
  if (reason === 'sync') {
    const badge = document.querySelector('[data-sync-badge]');
    if (badge) badge.textContent = s.pendingSync > 0 ? `${s.pendingSync} pending` : '';
  }
});

window.addEventListener('online', () => toast('Connection restored — syncing any saved results.', { type: 'ok' }));
window.addEventListener('offline', () => toast('You are offline. Completed practice will be saved on this computer.', { type: 'warn', timeout: 7000 }));

boot();

export { appRoot, setHeader, view, renderRoute, listPending, setPrefs, isStaff, t };
