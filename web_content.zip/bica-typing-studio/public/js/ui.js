/** DOM, icons, charts, dialogs, toasts. No framework, no dependencies. */

export function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props ?? {})) {
    if (value == null || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'html') node.innerHTML = value;
    else if (key === 'dataset') Object.assign(node.dataset, value);
    else if (key === 'style' && typeof value === 'object') Object.assign(node.style, value);
    else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
    else if (key in node && key !== 'list' && typeof value !== 'object') node[key] = value;
    else node.setAttribute(key, value === true ? '' : String(value));
  }
  append(node, children);
  return node;
}

function append(node, children) {
  for (const child of children.flat(4)) {
    if (child == null || child === false || child === true) continue;
    node.appendChild(child instanceof Node ? child : document.createTextNode(String(child)));
  }
}

export function frag(...children) {
  const f = document.createDocumentFragment();
  append(f, children);
  return f;
}

export function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
export function mount(node, ...children) { clear(node); append(node, children); return node; }

export function esc(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ------------------------------------------------------------------- icons
const ICONS = {
  grid: 'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
  book: 'M4 5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2zM8 3v18',
  keyboard: 'M2 6h20v12H2zM6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h12',
  gamepad: 'M7 12h4M9 10v4M15 11h.01M18 13h.01M6 7h12a4 4 0 0 1 4 4v2a4 4 0 0 1-7 2l-1-1h-4l-1 1a4 4 0 0 1-7-2v-2a4 4 0 0 1 4-4z',
  trophy: 'M8 4h8v5a4 4 0 0 1-8 0zM8 6H5v2a3 3 0 0 0 3 3M16 6h3v2a3 3 0 0 1-3 3M12 13v4M9 20h6',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  users: 'M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 20v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 7 19.4a1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a1.7 1.7 0 0 0-1.6-1H1a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 3 9a1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1H23a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  logout: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
  check: 'M20 6L9 17l-5-5',
  x: 'M18 6L6 18M6 6l12 12',
  play: 'M5 3l14 9-14 9z',
  pause: 'M6 4h4v16H6zM14 4h4v16h-4z',
  reload: 'M23 4v6h-6M1 20v-6h6M3.5 9a9 9 0 0 1 14.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0 0 20.5 15',
  download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  plus: 'M12 5v14M5 12h14',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.3-4.3',
  right: 'M9 18l6-6-6-6',
  left: 'M15 18l-6-6 6-6',
  lock: 'M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4',
  spark: 'M12 2l2.2 6.8L21 11l-6.8 2.2L12 20l-2.2-6.8L3 11l6.8-2.2z',
  flame: 'M12 22c4 0 7-2.7 7-6.5 0-4.5-4-6.5-4-10.5-2 1-3 3-3 5-1 0-2-1-2-3-2 2-5 4.5-5 8.5C5 19.3 8 22 12 22z',
  clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2',
  target: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10zM12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2z',
  medal: 'M12 15a6 6 0 1 0 0-12 6 6 0 0 0 0 12zM8.2 13.5L7 22l5-3 5 3-1.2-8.5',
  award: 'M12 3l2.5 5 5.5.8-4 3.9.9 5.5L12 15.6 7.1 18.2l.9-5.5-4-3.9L9.5 8z',
  alert: 'M12 9v4M12 17h.01M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  database: 'M12 8c4.4 0 8-1.3 8-3s-3.6-3-8-3-8 1.3-8 3 3.6 3 8 3zM4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3',
  cloud: 'M18 16.5a4 4 0 0 0-.9-7.9 6 6 0 0 0-11.6 1.6A3.5 3.5 0 0 0 6 16.5z',
  home: 'M3 11l9-8 9 8M5 9.5V21h14V9.5',
  speed: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 12l4-4',
  wave: 'M2 12h3l2-6 3 12 3-9 2 3h5',
  stack: 'M12 2l9 5-9 5-9-5zM3 12l9 5 9-5M3 17l9 5 9-5',
  crown: 'M3 18h18M3 18l2-9 4 4 3-7 3 7 4-4 2 9',
  bolt: 'M13 2L4 14h6l-1 8 9-12h-6z',
  filter: 'M3 5h18l-7 8v6l-4 2v-8z',
  file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h5',
  user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v5M12 8h.01',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
  archive: 'M21 8v13H3V8M1 3h22v5H1zM10 12h4',
  upload: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12',
};

export function icon(name, size = 16, extra = '') {
  const path = ICONS[name] ?? ICONS.info;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.7');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  if (extra) svg.setAttribute('class', extra);
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', path);
  svg.appendChild(p);
  return svg;
}

// ------------------------------------------------------------------ format
export function fmtMs(ms) {
  const total = Math.max(0, Math.round(Number(ms) / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function fmtMinutes(ms) {
  const mins = Math.round(Number(ms) / 60000);
  if (mins < 60) return `${mins} min`;
  return `${Math.floor(mins / 60)} h ${mins % 60} min`;
}

export function fmtClock(ms, { showTenths = false } = {}) {
  const total = Math.max(0, Number(ms));
  const m = Math.floor(total / 60000);
  const s = Math.floor((total % 60000) / 1000);
  if (!showTenths) return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  const tenths = Math.floor((total % 1000) / 100);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${tenths}`;
}

export function relTime(iso) {
  if (!iso) return 'never';
  const then = Date.parse(String(iso).includes('T') ? iso : `${String(iso).replace(' ', 'T')}Z`);
  if (!Number.isFinite(then)) return 'unknown';
  const diff = Date.now() - then;
  const mins = Math.round(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.round(hours / 24);
  if (days === 1) return 'yesterday';
  if (days < 30) return `${days} days ago`;
  return new Date(then).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function fmtDate(iso) {
  if (!iso) return '—';
  const t = Date.parse(String(iso).includes('T') ? iso : `${String(iso).replace(' ', 'T')}Z`);
  if (!Number.isFinite(t)) return '—';
  return new Date(t).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function initials(name = '') {
  return String(name).split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || '?';
}

export function pct(n) { return `${Math.round(Number(n) * 10) / 10}%`; }

// ------------------------------------------------------------------ toasts
export function toast(message, { type = 'info', timeout = 4200 } = {}) {
  const host = document.getElementById('toasts');
  if (!host) return;
  const node = el('div', {
    class: `toast ${type === 'ok' ? 'toast--ok' : type === 'error' ? 'toast--error' : type === 'warn' ? 'toast--warn' : ''}`,
    role: 'status',
  },
  el('div', { style: { flex: '1' } }, message),
  el('button', {
    class: 'toast__close', 'aria-label': 'Dismiss',
    onclick: () => node.remove(),
  }, icon('x', 13)));
  host.appendChild(node);
  if (timeout) setTimeout(() => node.remove(), timeout);
  return node;
}

// ----------------------------------------------------------------- dialogs
export function dialog({ title, body, actions = [], wide = false, onClose = null }) {
  const backdrop = el('div', { class: 'dialog-backdrop', role: 'presentation' });
  const close = () => {
    backdrop.remove();
    document.removeEventListener('keydown', onKey);
    if (onClose) onClose();
  };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const panel = el('div', {
    class: `dialog ${wide ? 'dialog--wide' : ''}`,
    role: 'dialog', 'aria-modal': 'true', 'aria-label': title,
  },
  el('div', { class: 'dialog__head' }, el('h2', {}, title)),
  el('div', { class: 'dialog__body' }, typeof body === 'string' ? el('p', {}, body) : body),
  actions.length ? el('div', { class: 'dialog__foot' }, actions.map((a) => el('button', {
    class: `btn ${a.variant ? `btn--${a.variant}` : ''}`,
    onclick: () => { if (a.onClick) a.onClick(close); else close(); },
  }, a.label))) : null);
  backdrop.appendChild(panel);
  backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop) close(); });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(backdrop);
  const focusable = panel.querySelector('button, input, select, textarea, a[href]');
  if (focusable) focusable.focus();
  return { close, panel };
}

export function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false }) {
  return new Promise((resolve) => {
    let settled = false;
    const d = dialog({
      title,
      body: el('p', {}, message),
      actions: [
        { label: 'Cancel', onClick: (close) => { settled = true; close(); resolve(false); } },
        {
          label: confirmLabel,
          variant: danger ? 'danger' : 'primary',
          onClick: (close) => { settled = true; close(); resolve(true); },
        },
      ],
      onClose: () => { if (!settled) resolve(false); },
    });
  });
}

// ------------------------------------------------------------------ charts
/** Line chart with axes, grid and an optional target rule. */
export function lineChart({ data, height = 180, valueKey = 'value', labelKey = 'label', target = null, unit = '', emptyLabel = 'No data yet' }) {
  const W = 640;
  const H = height;
  const pad = { l: 38, r: 12, t: 12, b: 24 };
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.setAttribute('class', 'chart');
  svg.setAttribute('role', 'img');

  const points = (data ?? []).filter((d) => Number.isFinite(Number(d[valueKey])));
  if (points.length === 0) {
    svg.setAttribute('aria-label', emptyLabel);
    const t = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    t.setAttribute('x', W / 2); t.setAttribute('y', H / 2);
    t.setAttribute('text-anchor', 'middle'); t.setAttribute('class', 'chart__empty');
    t.textContent = emptyLabel;
    svg.appendChild(t);
    return svg;
  }

  const values = points.map((d) => Number(d[valueKey]));
  const max = Math.max(...values, target ?? 0) * 1.15 || 10;
  const min = 0;
  const x = (i) => pad.l + (i * (W - pad.l - pad.r)) / Math.max(1, points.length - 1);
  const y = (v) => pad.t + (H - pad.t - pad.b) * (1 - (v - min) / (max - min || 1));

  const ns = 'http://www.w3.org/2000/svg';
  const add = (tag, attrs, text) => {
    const n = document.createElementNS(ns, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    if (text != null) n.textContent = text;
    svg.appendChild(n);
    return n;
  };

  for (let i = 0; i <= 3; i += 1) {
    const v = min + ((max - min) * i) / 3;
    const yy = y(v);
    add('line', { x1: pad.l, y1: yy, x2: W - pad.r, y2: yy, class: 'chart__grid' });
    add('text', { x: pad.l - 6, y: yy + 3, 'text-anchor': 'end', class: 'chart__axis' }, `${Math.round(v)}`);
  }

  if (target != null) {
    add('line', {
      x1: pad.l, y1: y(target), x2: W - pad.r, y2: y(target),
      stroke: '#a8823c', 'stroke-width': 1, 'stroke-dasharray': '4 4',
    });
    add('text', { x: W - pad.r, y: y(target) - 4, 'text-anchor': 'end', class: 'chart__axis', fill: '#a8823c' }, `target ${target}${unit}`);
  }

  const line = points.map((d, i) => `${i === 0 ? 'M' : 'L'}${x(i)},${y(Number(d[valueKey]))}`).join(' ');
  add('path', {
    d: `${line} L${x(points.length - 1)},${y(min)} L${x(0)},${y(min)} Z`,
    class: 'chart__area',
  });
  add('path', { d: line, class: 'chart__line' });

  const step = Math.ceil(points.length / 7);
  points.forEach((d, i) => {
    if (points.length <= 24) add('circle', { cx: x(i), cy: y(Number(d[valueKey])), r: 2.6, class: 'chart__point' });
    if (i % step === 0 || i === points.length - 1) {
      add('text', { x: x(i), y: H - 6, 'text-anchor': 'middle', class: 'chart__axis' }, String(d[labelKey] ?? ''));
    }
  });
  svg.setAttribute('aria-label', `Chart of ${valueKey} over ${points.length} points; latest ${values[values.length - 1]}${unit}`);
  return svg;
}

export function barChart({ data, height = 160, valueKey = 'value', labelKey = 'label', unit = '' }) {
  const W = 640;
  const H = height;
  const pad = { l: 34, r: 10, t: 10, b: 24 };
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.setAttribute('class', 'chart');
  const rows = data ?? [];
  if (!rows.length) {
    const t = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    t.setAttribute('x', W / 2); t.setAttribute('y', H / 2); t.setAttribute('text-anchor', 'middle');
    t.setAttribute('class', 'chart__empty'); t.textContent = 'No data yet';
    svg.appendChild(t);
    return svg;
  }
  const ns = 'http://www.w3.org/2000/svg';
  const add = (tag, attrs, text) => {
    const n = document.createElementNS(ns, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    if (text != null) n.textContent = text;
    svg.appendChild(n);
    return n;
  };
  const max = Math.max(...rows.map((r) => Number(r[valueKey])), 1) * 1.1;
  const bw = (W - pad.l - pad.r) / rows.length;
  const y = (v) => pad.t + (H - pad.t - pad.b) * (1 - v / max);
  add('line', { x1: pad.l, y1: H - pad.b, x2: W - pad.r, y2: H - pad.b, class: 'chart__grid' });
  add('line', { x1: pad.l, y1: pad.t, x2: pad.l, y2: H - pad.b, class: 'chart__grid' });
  add('text', { x: pad.l - 6, y: y(max) + 3, 'text-anchor': 'end', class: 'chart__axis' }, `${Math.round(max)}`);
  add('text', { x: pad.l - 6, y: H - pad.b + 3, 'text-anchor': 'end', class: 'chart__axis' }, '0');
  rows.forEach((r, i) => {
    const v = Number(r[valueKey]);
    const h = Math.max(1, H - pad.b - y(v));
    add('rect', {
      x: pad.l + i * bw + bw * 0.16, y: y(v), width: bw * 0.68, height: h, rx: 2,
      class: 'chart__bar',
    });
    add('text', { x: pad.l + i * bw + bw / 2, y: H - 6, 'text-anchor': 'middle', class: 'chart__axis' }, String(r[labelKey] ?? ''));
  });
  svg.setAttribute('aria-label', `Bar chart of ${valueKey} by ${labelKey}${unit ? ` in ${unit}` : ''}`);
  return svg;
}

// ------------------------------------------------------------- components
export function statTile({ label, value, unit = '', hint = '', delta = null }) {
  return el('div', { class: 'stat' },
    el('div', { class: 'stat__label' }, label),
    el('div', { class: 'stat__value num' }, String(value), unit ? el('small', {}, unit) : null),
    hint ? el('div', { class: 'tiny muted', style: { marginTop: '2px' } }, hint) : null,
    delta != null ? el('div', { class: `stat__delta ${delta < 0 ? 'stat__delta--down' : ''}` }, `${delta >= 0 ? '+' : ''}${delta}`) : null);
}

export function emptyState({ title, message, action = null, iconName = 'info' }) {
  return el('div', { class: 'empty' },
    el('div', { class: 'empty__icon' }, icon(iconName, 40)),
    el('h3', {}, title),
    el('p', {}, message),
    action || null);
}

export function meter(value, { max = 100, accent = false, ok = false, thin = false } = {}) {
  const p = Math.max(0, Math.min(100, (Number(value) / max) * 100));
  return el('div', { class: `meter ${accent ? 'meter--accent' : ''} ${ok ? 'meter--ok' : ''} ${thin ? 'meter--thin' : ''}`, role: 'progressbar', 'aria-valuenow': Math.round(p), 'aria-valuemin': 0, 'aria-valuemax': 100 },
    el('div', { class: 'meter__fill', style: { width: `${p}%` } }));
}

export function skeleton(height = 16, width = '100%') {
  return el('div', { style: { height: `${height}px`, width, background: 'var(--surface-3)', borderRadius: '4px' } });
}

/** Renders a promise-based view with a loading state and error state. */
export async function withLoading(host, loader, render) {
  mount(host, el('div', { style: { padding: '40px', textAlign: 'center', color: 'var(--ink-500)' } }, 'Loading…'));
  try {
    const data = await loader();
    mount(host, render(data));
  } catch (err) {
    mount(host, emptyState({
      title: 'Could not load this screen',
      message: err?.message || 'The server did not respond as expected.',
      iconName: 'alert',
      action: el('button', { class: 'btn', onclick: () => location.reload() }, 'Reload'),
    }));
  }
}
