import { api } from '../api.js';
import { el, icon, toast, fmtMs, relTime, emptyState, statTile } from '../ui.js';
import { openTypingWorkspace } from '../typing.js';

export default async function challengeView() {
  const [data, board] = await Promise.all([
    api.get('/api/challenges'),
    api.get('/api/leaderboard?scope=class&period=week&limit=10').catch(() => ({ entries: [], disabled: true })),
  ]);

  const [daily, weekly] = [data.daily, data.weekly];

  if (data.competitiveEnabled === false) {
    return {
      node: el('div', {}, el('div', { class: 'panel' }, el('div', { class: 'panel__body' },
        emptyState({
          title: 'Challenges are switched off',
          message: 'Your centre has turned off competitive features. Lessons, practice and the arcade all still work.',
          iconName: 'lock',
        })))),
      header: { title: 'Challenge', crumbs: [{ label: 'Challenge' }] },
    };
  }

  function leaderboardRows(rows, metricKey) {
    return el('div', { class: 'leaderboard' }, rows.map((row, i) => el('div', {
      class: `lb-row${row.is_me ? ' lb-row--me' : ''}`,
    },
    el('span', { class: `lb-rank${i === 0 ? ' lb-rank--top' : ''}` }, String(i + 1)),
    el('span', { class: 'lb-name' }, row.name, row.is_me ? el('span', { class: 'badge', style: { marginLeft: '6px' } }, 'you') : null),
    el('span', { class: 'lb-metric' }, `${Math.round(row[metricKey])} WPM`),
    el('span', { class: 'tiny muted', style: { fontFamily: 'var(--font-mono)' } }, `${Math.round(row.accuracy)}%`))));
  }

  function challengeCard(chal, kindLabel) {
    if (!chal) return null;
    const attempt = chal.myAttempt;

    const standings = chal.leaderboard?.length
      ? el('div', { style: { marginTop: '14px' } },
        el('div', { class: 'eyebrow' }, `${kindLabel} standings`),
        leaderboardRows(chal.leaderboard, 'net_wpm'))
      : el('p', { class: 'tiny muted', style: { marginTop: '12px' } },
        'No attempts on this challenge yet — the board stays empty until someone finishes one.');

    const attemptLine = attempt
      ? el('div', { class: 'challenge-hero__attempt' },
        el('div', { class: 'small' },
          el('strong', {}, 'Your best attempt: '),
          `${attempt.netWpm} WPM at ${Math.round(attempt.accuracy)}% accuracy — ${relTime(attempt.at)}`),
        el('div', { class: 'tiny muted' }, 'Attempts are verified by the server; only your best net WPM is kept on the board.'))
      : el('p', { class: 'small muted', style: { margin: '10px 0' } },
        'You have not attempted this yet. One clean run is enough — your best score is kept.');

    return el('article', { class: 'challenge-hero' },
      el('div', {},
        el('div', { class: 'challenge-hero__label' }, icon('target', 12), kindLabel),
        el('h2', {}, chal.title),
        el('div', { class: 'game-scoreline' },
          el('span', {}, `${Math.round(chal.durationMs / 600) / 100} min`),
          el('span', {}, `${chal.passageChars} character passage`),
          el('span', {}, `closes ${relTime(chal.endsAt)}`)),
        attemptLine,
        el('div', { style: { display: 'flex', gap: '10px', marginTop: '10px' } },
          el('button', { class: 'btn btn--primary', onclick: () => start(chal, kindLabel) },
            icon('play', 14), attempt ? 'Try to beat it' : 'Start challenge'))),
      el('div', { style: { minWidth: '280px' } }, standings));
  }

  async function start(chal, kindLabel) {
    try {
      const session = await api.get(`/api/challenges/${encodeURIComponent(chal.id)}/start`);
      openTypingWorkspace({
        text: session.text,
        mode: session.mode,
        durationSec: session.durationSec,
        allowBackspace: true,
        tokenId: session.tokenId,
        source: 'challenge',
        refId: session.refId ?? chal.id,
        sessionTitle: scenarioTitle(kindLabel, session.title),
        meta: { challengeId: chal.id, kind: chal.kind },
        onExit: () => {},
        onComplete: () => { toast('Challenge submitted. Reloading the board…', { type: 'ok' }); setTimeout(() => location.reload(), 900); },
      });
    } catch (err) {
      toast(err.message, { type: 'error' });
    }
  }

  const goals = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Personal goals')),
    el('div', { class: 'panel__body' },
      el('p', { class: 'small muted', style: { marginTop: 0 } },
        'Targets are measured against your own verified history, not against other students.'),
      el('div', { class: 'stats', style: { border: '0' } },
        statTile({ label: 'Best net WPM', value: data.personalBest.bestWpm ?? 0, hint: 'verified sessions only' }),
        statTile({ label: 'Best accuracy', value: `${Math.round(data.personalBest.bestAccuracy ?? 0)}%` }),
        statTile({ label: 'Verified sessions', value: data.personalBest.sessions ?? 0 }))));

  const boardBody = board.disabled
    ? el('p', { class: 'small muted', style: { padding: '16px 20px', margin: 0 } }, board.message ?? 'Leaderboards are turned off.')
    : board.entries.length === 0
      ? el('p', { class: 'small muted', style: { padding: '16px 20px', margin: 0 } }, 'No verified sessions in your class this week yet.')
      : leaderboardRows(board.entries, 'best_wpm');

  const boardPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' },
      el('h3', {}, 'Class leaderboard — this week'),
      el('span', { class: 'tiny muted' }, board.disabled ? 'disabled' : 'class only')),
    el('div', { class: 'panel__body', style: { padding: 0 } }, boardBody),
    el('div', { class: 'panel__foot tiny muted' },
      'Names appear only if the centre allows public display names; otherwise you see BICA numbers. There is no student-to-student chat.'));

  const node = el('div', {},
    el('div', { style: { marginBottom: '20px' } },
      el('div', { class: 'eyebrow' }, 'Challenge'),
      el('h1', {}, 'Challenge yourself'),
      el('p', { class: 'lede' }, 'Two new passages each day and each week, generated from a fixed seed so every student in the centre types exactly the same text. Results are server-verified before they reach a board.')),
    daily ? challengeCard(daily, 'Daily') : null,
    weekly ? el('div', { style: { marginTop: '18px' } }, challengeCard(weekly, 'Weekly')) : null,
    el('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginTop: '24px' } }, goals, boardPanel));

  return {
    node,
    header: {
      title: 'Challenge',
      crumbs: [{ label: 'Challenge' }],
      actions: [el('button', { class: 'btn btn--sm', onclick: () => location.reload() }, icon('reload', 13), 'Refresh')],
    },
  };
}

function scenarioTitle(kindLabel, title) {
  return `${kindLabel} challenge — ${title ?? 'fixed passage'}`;
}

