import { api } from '../api.js';
import { el, icon, toast, statTile, relTime, fmtMinutes, fmtDate, meter, emptyState } from '../ui.js';
import { navigate } from '../router.js';
import { pageHead, staffPanel, dataTable, formDialog, confirmAction, kvList, badge, field } from './_staff.js';

export default async function studentsView({ params = {} }) {
  if (params.studentId) return studentDetail(Number(params.studentId));
  return studentList();
}

// ------------------------------------------------------------------ list
async function studentList() {
  const [{ students }, { classes }] = await Promise.all([
    api.get('/api/instructor/students'),
    api.get('/api/instructor/classes').catch(() => ({ classes: [] })),
  ]);

  const state = { q: '', classId: '' };
  const tbodyHost = el('div', {});

  function render() {
    const needle = state.q.trim().toLowerCase();
    const filtered = students.filter((s) => {
      const matches = !needle || s.display_name.toLowerCase().includes(needle) || s.username.toLowerCase().includes(needle);
      return matches;
    });
    tbodyHost.replaceChildren(dataTable({
      rows: filtered,
      empty: 'No students match that search.',
      onRowClick: (row) => navigate(`/instructor/students/${row.id}`),
      columns: [
        { label: 'Student', render: (r) => el('div', {}, el('div', { style: { fontWeight: '600' } }, r.display_name), el('div', { class: 'tiny muted' }, r.username)) },
        { label: 'Lessons', align: 'right', render: (r) => String(r.mastered) },
        { label: 'Best WPM', align: 'right', render: (r) => String(Math.round(r.best_wpm)) },
        { label: 'Accuracy', align: 'right', render: (r) => (r.avg_accuracy ? `${Math.round(r.avg_accuracy)}%` : '—') },
        { label: 'Last practice', align: 'right', render: (r) => (r.last_at ? relTime(r.last_at) : badge('never', 'warn')) },
        { label: 'Account', render: (r) => (r.is_active ? badge('active', 'ok') : badge('disabled')) },
      ],
    }));
  }
  render();

  const search = el('input', {
    class: 'input', type: 'search', placeholder: 'Search name or username',
    oninput: (e) => { state.q = e.target.value; render(); },
  });

  const classFilter = el('select', {
    class: 'select',
    onchange: (e) => { state.classId = e.target.value; if (state.classId) location.hash = `#/instructor/classes/${state.classId}`; },
  }, el('option', { value: '' }, 'All my classes…'), classes.map((c) => el('option', { value: String(c.id) }, c.name)));

  const node = el('div', {},
    pageHead('Instructor', 'Students', 'Every student enrolled in a class you teach. Open a student for their full report, notes and certificate eligibility.'),
    el('div', { style: { display: 'flex', gap: '10px', marginBottom: '16px', maxWidth: '620px' } }, search, classFilter),
    staffPanel(`${students.length} students`,
      el('div', { class: 'panel__body', style: { padding: 0 } }, tbodyHost)));

  return {
    node,
    header: { title: 'Students', crumbs: [{ label: 'Instructor', href: '#/instructor' }, { label: 'Students' }] },
  };
}

// ---------------------------------------------------------------- detail
async function studentDetail(studentId) {
  const [report, eligibility] = await Promise.all([
    api.get(`/api/instructor/students/${studentId}`),
    api.get(`/api/certificates/eligibility/${studentId}`).catch(() => null),
  ]);
  const { student, stats, progress, classes, notes, weakKeys: reportWeak, assignments, recentSessions } = report;

  const kpis = el('div', { class: 'stats', style: { gridTemplateColumns: 'repeat(5, 1fr)', marginBottom: '20px' } },
    statTile({ label: 'Level', value: `${report.level}/6`, hint: report.levelName }),
    statTile({ label: 'Best net WPM', value: stats.bestWpm }),
    statTile({ label: 'Average accuracy', value: `${Math.round(stats.avgAccuracy)}%` }),
    statTile({ label: 'Practice time', value: fmtMinutes(stats.totalMs), hint: `${stats.sessions} sessions` }),
    statTile({ label: 'Last practice', value: stats.lastPracticeDaysAgo == null ? 'never' : `${stats.lastPracticeDaysAgo}d`, hint: `${stats.streak}-day streak` }));

  const profile = staffPanel('Student record',
    el('div', { class: 'panel__body' },
      kvList([
        ['Full name', student.displayName],
        ['Username', student.username],
        ['Classes', classes.map((c) => c.name).join(', ') || 'not enrolled'],
        ['Account', student.active ? 'active' : 'disabled'],
        ['Created', fmtDate(student.createdAt)],
        ['Last sign-in', student.lastLoginAt ? relTime(student.lastLoginAt) : 'never'],
      ])),
    [
      el('button', { class: 'btn btn--sm', onclick: addNote }, 'Add note'),
      el('button', { class: 'btn btn--sm btn--ghost', onclick: resetPassword }, 'Reset password'),
      el('a', { class: 'btn btn--sm btn--ghost', href: `/api/instructor/students/${studentId}/report.pdf`, download: '' }, icon('download', 13), 'PDF report'),
    ]);

  function addNote() {
    formDialog({
      title: `Note about ${student.displayName}`,
      intro: 'Notes are visible to instructors and administrators of this centre. Keep them factual and about typing work.',
      fields: [{ name: 'note', label: 'Note', type: 'textarea', rows: 5, required: true, placeholder: 'Struggles with the right-hand pinky keys; needs short drills, not long passages.' }],
      submitLabel: 'Save note',
      onSubmit: async (values, close) => {
        await api.post(`/api/instructor/students/${studentId}/notes`, values);
        close();
        toast('Note saved.', { type: 'ok' });
        location.reload();
      },
    });
  }

  function resetPassword() {
    formDialog({
      title: 'Reset password',
      intro: 'This signs the student out everywhere and forces a password change at next sign-in. Tell them the temporary password in person.',
      fields: [{ name: 'password', label: 'Temporary password', required: true, hint: 'At least 10 characters.' }],
      submitLabel: 'Reset password',
      onSubmit: async (values, close) => {
        await api.post(`/api/instructor/students/${studentId}/reset-password`, values);
        close();
        toast('Password reset.', { type: 'ok' });
      },
    });
  }

  const progressRows = progress.lessons.filter((l) => l.mastered || l.unlocked).slice(-14).reverse();
  const progressPanel = staffPanel('Course progress',
    el('div', { class: 'panel__body' },
      el('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '6px' } },
        el('span', { class: 'small' }, `${progress.mastered} of ${progress.total} lessons mastered`),
        el('span', { class: 'small muted' }, `level ${report.level} — ${report.levelName}`)),
      meter(progress.mastered, { max: progress.total, ok: true }),
      el('div', { style: { marginTop: '16px' } },
        dataTable({
          rows: progressRows,
          empty: 'No lessons started yet.',
          columns: [
            { label: 'Lesson', render: (r) => `L${r.level} · ${r.title}` },
            { label: 'Attempts', align: 'right', render: (r) => String(r.attempts ?? 0) },
            { label: 'Best accuracy', align: 'right', render: (r) => (r.bestAccuracy ? `${Math.round(r.bestAccuracy)}%` : '—') },
            { label: 'Best WPM', align: 'right', render: (r) => (r.bestWpm ? String(Math.round(r.bestWpm)) : '—') },
            { label: 'Status', render: (r) => (r.mastered ? badge('mastered', 'ok') : r.unlocked ? badge('unlocked') : badge('locked')) },
          ],
        }))));

  const weakKeys = (reportWeak ?? []).slice(0, 8);
  const keysPanel = staffPanel('Weak keys',
    el('div', { class: 'panel__body' },
      weakKeys.length
        ? el('div', {}, weakKeys.map((k) => el('div', { class: 'key-row' },
          el('code', { class: 'keycap' }, k.key === ' ' ? 'space' : k.key),
          el('div', { style: { flex: 1 } }, meter(k.errorRate, { max: Math.max(10, k.errorRate), thin: true })),
          el('span', { class: 'tiny muted', style: { width: '58px', textAlign: 'right' } }, `${k.errorRate}% of ${k.attempts}`))))
        : el('p', { class: 'small muted', style: { margin: 0 } }, 'No per-key statistics yet — this student has not completed a session with keystroke data.')));

  const notesPanel = staffPanel('Instructor notes',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      notes?.length
        ? el('div', {}, notes.map((n) => el('div', { class: 'note-row' },
          el('div', { class: 'small' }, n.note),
          el('div', { class: 'tiny muted' }, `${n.author ?? 'Instructor'} · ${relTime(n.created_at)}`))))
        : el('p', { class: 'small muted', style: { padding: '16px 20px', margin: 0 } }, 'No notes yet.')));

  const assignPanel = staffPanel('Assigned work',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: assignments?.items ?? [],
        empty: 'Nothing assigned to this student.',
        columns: [
          { label: 'Title', render: (r) => r.title },
          { label: 'Type', render: (r) => badge(r.kind.toLowerCase()) },
          { label: 'Due', render: (r) => (r.dueAt ? fmtDate(r.dueAt) : '—') },
          { label: 'Status', render: (r) => statusBadge(r.status) },
        ],
      })),
    [el('button', { class: 'btn btn--sm', onclick: () => navigate('/instructor/assignments') }, 'Assign')]);

  const certPanel = staffPanel('Certificate',
    el('div', { class: 'panel__body' },
      eligibility
        ? el('div', {},
          el('div', { class: 'small', style: { marginBottom: '8px' } },
            eligibility.eligible ? 'All configured criteria are met.' : 'Criteria not yet met.'),
          el('div', {}, eligibility.checks.map((c) => el('div', { class: 'check-row' },
            el('span', { style: { color: c.met ? 'var(--ok)' : 'var(--ink-400)' } }, icon(c.met ? 'check' : 'x', 14)),
            el('span', { class: 'small' }, c.label),
            el('span', { class: 'tiny muted', style: { marginLeft: 'auto' } }, String(c.actual))))),
          el('button', {
            class: 'btn btn--sm btn--primary', style: { marginTop: '12px' }, disabled: !eligibility.eligible,
            onclick: issue,
          }, 'Issue certificate'))
        : el('p', { class: 'small muted', style: { margin: 0 } }, 'Eligibility could not be loaded.')));

  async function issue() {
    confirmAction({
      title: 'Issue certificate',
      message: `Issue a numbered BICA certificate to ${student.displayName} using their verified best results? One active certificate per student.`,
      confirmLabel: 'Issue',
      run: async () => {
        const { certificate } = await api.post('/api/certificates/issue', { studentId });
        toast(`Certificate ${certificate.certificate_no} issued.`, { type: 'ok', timeout: 7000 });
        location.reload();
      },
    });
  }

  const recent = staffPanel('Recent sessions',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: (recentSessions ?? []).slice(0, 12),
        empty: 'No sessions yet.',
        columns: [
          { label: 'When', render: (r) => relTime(r.startedAt) },
          { label: 'Activity', render: (r) => r.title || r.source },
          { label: 'Net WPM', align: 'right', render: (r) => String(Math.round(r.netWpm)) },
          { label: 'Accuracy', align: 'right', render: (r) => `${Math.round(r.accuracy)}%` },
          { label: 'Verified', render: (r) => (r.verified ? badge('yes', 'ok') : badge('no', 'warn')) },
        ],
      })));

  const header = el('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: '16px', marginBottom: '18px' } },
    el('div', {},
      el('div', { class: 'eyebrow' }, student.username),
      el('h1', {}, student.displayName),
      el('p', { class: 'lede' }, classes.length ? `Enrolled in ${classes.map((c) => c.name).join(', ')}.` : 'Not enrolled in a class.')),
    el('a', { class: 'btn btn--sm btn--ghost', href: '#/instructor/students' }, 'All students'));

  const node = el('div', {}, header, kpis,
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.5fr) minmax(0, 1fr)', gap: '20px' } },
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, progressPanel, recent),
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, profile, keysPanel, certPanel, assignPanel, notesPanel)));


  return {
    node,
    header: {
      title: student.displayName,
      crumbs: [
        { label: 'Instructor', href: '#/instructor' },
        { label: 'Students', href: '#/instructor/students' },
        { label: student.displayName },
      ],
    },
  };
}

function statusBadge(status) {
  if (status === 'COMPLETED') return badge('completed', 'ok');
  if (status === 'LATE') return badge('late', 'gold');
  if (status === 'OVERDUE') return badge('overdue', 'danger');
  return badge('pending');
}
