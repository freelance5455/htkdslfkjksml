import { api } from '../api.js';
import { el, icon, toast, fmtDate, emptyState, statTile } from '../ui.js';
import { pageHead, staffPanel, dataTable, formDialog, confirmAction, badge, kvList } from './_staff.js';

export default async function certificatesView() {
  const [{ certificates }, { students }] = await Promise.all([
    api.get('/api/certificates'),
    api.get('/api/instructor/students'),
  ]);

  const active = certificates.filter((c) => !c.revoked_at);
  const revoked = certificates.filter((c) => c.revoked_at);

  const kpis = el('div', { class: 'stats', style: { gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: '20px' } },
    statTile({ label: 'Certificates issued', value: certificates.length }),
    statTile({ label: 'Currently valid', value: active.length }),
    statTile({ label: 'Revoked', value: revoked.length }),
    statTile({ label: 'Students without one', value: Math.max(0, students.length - active.length), hint: 'not all eligible' }));

  const issuedPanel = staffPanel('Issued certificates',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: certificates,
        empty: 'No certificates issued yet.',
        columns: [
          { label: 'Number', render: (c) => el('code', { class: 'tiny' }, c.certificate_no) },
          { label: 'Student', render: (c) => el('div', {}, el('div', { style: { fontWeight: '600' } }, c.student_name), el('div', { class: 'tiny muted' }, c.username)) },
          { label: 'Course', render: (c) => c.course_title },
          { label: 'Result at issue', align: 'right', render: (c) => `${c.best_wpm} WPM · ${Math.round(c.best_accuracy)}%` },
          { label: 'Issued', align: 'right', render: (c) => fmtDate(c.issued_at) },
          { label: 'Status', render: (c) => (c.revoked_at ? badge('revoked', 'danger') : badge('valid', 'ok')) },
          {
            label: '', align: 'right',
            render: (c) => el('div', { style: { display: 'flex', gap: '6px', justifyContent: 'flex-end' } },
              el('a', { class: 'btn btn--sm btn--ghost', href: `/api/certificates/${c.certificate_no}/pdf`, download: '' }, 'PDF'),
              el('a', { class: 'btn btn--sm btn--ghost', href: `#/verify/${c.certificate_no}`, target: '_blank', rel: 'noopener' }, 'Verify')),
          },
        ],
      })),
    [el('button', { class: 'btn btn--sm btn--primary', onclick: () => issue() }, icon('plus', 13), 'Issue certificate')]);

  function issue() {
    const eligible = students.map((s) => ({ value: String(s.id), label: `${s.display_name} — ${s.mastered} lessons mastered` }));
    if (!eligible.length) { toast('There are no students in your classes yet.', { type: 'warn' }); return; }

    const handle = formDialog({
      title: 'Issue a certificate',
      intro: 'Eligibility is checked against the centre\u2019s configured criteria using verified results only. If the criteria are not met the server refuses the request — you cannot issue a certificate by overriding it here.',
      fields: [{ name: 'studentId', label: 'Student', type: 'select', value: eligible[0].value, options: eligible }],
      submitLabel: 'Check and issue',
      onSubmit: async (values, close) => {
        try {
          const { certificate } = await api.post('/api/certificates/issue', { studentId: Number(values.studentId) });
          close();
          showIssued(certificate);
        } catch (err) {
          if (err.code === 'not_eligible' && err.payload?.eligibility) {
            showNotEligible(err.payload.eligibility, Number(values.studentId));
            return;
          }
          throw err;
        }
      },
    });
    return handle;
  }

  function showIssued(cert) {
    confirmAction({
      title: `Issued: ${cert.certificate_no}`,
      message: `The verification code is ${cert.verification_code}. Print it on the certificate. Anyone can confirm the certificate at /#/verify/${cert.certificate_no}.`,
      confirmLabel: 'Download PDF',
      run: async () => {
        window.open(`/api/certificates/${cert.certificate_no}/pdf`, '_blank', 'noopener');
        location.reload();
      },
    });
  }

  async function showNotEligible(eligibility, studentId) {
    const data = await api.get(`/api/certificates/eligibility/${studentId}`).catch(() => eligibility);
    await import('../ui.js').then(({ dialog }) => dialog({
      title: 'Criteria not met',
      body: el('div', {},
        el('p', { class: 'small muted', style: { marginTop: 0 } }, 'The student is not yet eligible. These are the exact checks the server applies:'),
        el('div', {}, (data.checks ?? []).map((c) => el('div', { class: 'check-row' },
          el('span', { style: { color: c.met ? 'var(--ok)' : 'var(--danger)' } }, icon(c.met ? 'check' : 'x', 14)),
          el('span', { class: 'small' }, c.label),
          el('span', { class: 'tiny muted', style: { marginLeft: 'auto' } }, `actual: ${c.actual}`)))),
        el('p', { class: 'tiny muted', style: { marginTop: '12px' } },
          'Criteria are set by the administrator under Admin → Settings. They exist so a certificate means something.')),
      actions: [{ label: 'Close' }],
    }));
  }

  const criteriaPanel = staffPanel('What a certificate states',
    el('div', { class: 'panel__body' },
      kvList([
        ['Certificate number', 'BICA-<year>-<sequence>, unique and printed on the document'],
        ['Verification code', 'Derived from a secret held by the server, printed on the document'],
        ['Course', 'The course title configured by the centre'],
        ['Results at issue', 'Best verified net WPM and best verified accuracy on a session of 100+ characters'],
        ['Signature', 'Space for the centre\u2019s authorised signature'],
      ]),
      el('div', { class: 'callout', style: { marginTop: '14px' } },
        el('strong', {}, 'Honesty note. '),
        'BICA certificates record training completed at this centre. They are not an externally accredited qualification and the document says so.')));

  const node = el('div', {},
    pageHead('Instructor', 'Certificates',
      'Issue numbered certificates to students who meet the centre\u2019s criteria, and download or verify any that have been issued.'),
    kpis,
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.7fr) minmax(0, 1fr)', gap: '20px' } },
      issuedPanel,
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, criteriaPanel)),
    revoked.length
      ? el('div', { style: { marginTop: '20px' } }, staffPanel('Revoked certificates',
        el('div', { class: 'panel__body', style: { padding: 0 } },
          dataTable({
            rows: revoked,
            empty: '',
            columns: [
              { label: 'Number', render: (c) => c.certificate_no },
              { label: 'Student', render: (c) => c.student_name },
              { label: 'Revoked', align: 'right', render: (c) => fmtDate(c.revoked_at) },
              { label: 'Reason', render: (c) => c.revoke_reason ?? '—' },
            ],
          }))))
      : null);


  return {
    node,
    header: {
      title: 'Certificates',
      crumbs: [{ label: 'Instructor', href: '#/instructor' }, { label: 'Certificates' }],
    },
  };
}
