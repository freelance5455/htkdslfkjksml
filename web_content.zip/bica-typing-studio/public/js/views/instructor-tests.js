import { api } from '../api.js';
import { el, icon, toast, fmtMs, fmtDate, emptyState } from '../ui.js';
import { pageHead, staffPanel, dataTable, formDialog, confirmAction, badge } from './_staff.js';

export default async function testsView() {
  const { tests } = await api.get('/api/instructor/tests');

  function editor(test = null) {
    formDialog({
      title: test ? `Edit “${test.title}”` : 'New typing test',
      intro: test
        ? 'Changing a passage affects future attempts only. Results already recorded keep the text that was actually typed.'
        : 'A test is a fixed passage under examination conditions. Students cannot restart it without a new server token, and the server verifies every result.',
      wide: true,
      fields: [
        { name: 'title', label: 'Title', required: true, value: test?.title ?? '', placeholder: 'Term 2 speed test — 5 minutes' },
        { name: 'passage', label: 'Passage', type: 'textarea', rows: 8, required: true, value: test?.passage ?? '',
          hint: 'Between 80 and 5000 characters. Line breaks become spaces. Use the passage your syllabus covers — no invented exam material.' },
        { name: 'durationMs', label: 'Duration (minutes)', type: 'number', min: 0.5, max: 30, step: 0.5,
          value: test ? test.duration_ms / 60000 : 5, required: true },
        { name: 'minAccuracy', label: 'Pass accuracy (%)', type: 'number', min: 0, max: 100, value: test?.min_accuracy ?? 95, required: true },
        { name: 'minWpm', label: 'Pass speed (net WPM)', type: 'number', min: 0, max: 300, value: test?.min_wpm ?? 20, required: true },
        { name: 'allowBackspace', label: 'Backspace allowed', type: 'checkbox', value: test ? Boolean(test.allow_backspace) : false,
          hint: 'Off is closer to a real employment typing test.' },
        { name: 'showTimer', label: 'Show the countdown timer', type: 'checkbox', value: test ? Boolean(test.show_timer) : true },
        { name: 'showLiveWpm', label: 'Show live speed while typing', type: 'checkbox', value: test ? Boolean(test.show_live_wpm) : false },
      ],
      submitLabel: test ? 'Save changes' : 'Create test',
      onSubmit: async (values, close) => {
        const payload = {
          title: values.title,
          passage: values.passage,
          durationMs: Math.round(Number(values.durationMs) * 60000),
          minAccuracy: Number(values.minAccuracy),
          minWpm: Number(values.minWpm),
          allowBackspace: values.allowBackspace,
          showTimer: values.showTimer,
          showLiveWpm: values.showLiveWpm,
        };
        if (payload.durationMs < 30000) throw new Error('The duration must be at least 30 seconds.');
        if (test) await api.patch(`/api/instructor/tests/${test.id}`, payload);
        else await api.post('/api/instructor/tests', payload);
        close();
        toast(test ? 'Test updated.' : 'Test created. It can now be assigned or taken from the practice screen.', { type: 'ok' });
        location.reload();
      },
    });
  }

  function toggleActive(test) {
    const next = !test.is_active;
    confirmAction({
      title: next ? 'Publish test' : 'Withdraw test',
      message: next
        ? 'Students will see this test in their practice screen and it can be assigned.'
        : 'The test stops appearing for students. Existing results are untouched.',
      confirmLabel: next ? 'Publish' : 'Withdraw',
      danger: !next,
      run: async () => {
        await api.patch(`/api/instructor/tests/${test.id}`, { isActive: next });
        toast(next ? 'Published.' : 'Withdrawn.', { type: 'ok' });
        location.reload();
      },
    });
  }

  const rows = tests.map((t) => ({ ...t }));

  const list = staffPanel(`Your tests (${tests.length})`,
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows,
        empty: 'No tests yet. Create one with your own passage and pass marks.',
        columns: [
          { label: 'Title', render: (t) => el('div', {}, el('div', { style: { fontWeight: '600' } }, t.title),
            el('div', { class: 'tiny muted' }, `${t.passage?.length ?? 0} characters · created ${fmtDate(t.created_at)}`)) },
          { label: 'Duration', align: 'right', render: (t) => fmtMs(t.duration_ms) },
          { label: 'Pass mark', align: 'right', render: (t) => `${t.min_accuracy}% · ${t.min_wpm} WPM` },
          { label: 'Conditions', render: (t) => el('div', { class: 'chip-grid' },
            t.allow_backspace ? badge('backspace') : badge('no backspace', 'gold'),
            t.show_timer ? badge('timer shown') : badge('timer hidden'),
            t.show_live_wpm ? badge('live WPM') : badge('WPM hidden')) },
          { label: 'Status', render: (t) => (t.is_active ? badge('published', 'ok') : badge('withdrawn')) },
          {
            label: '', align: 'right',
            render: (t) => el('div', { style: { display: 'flex', gap: '6px', justifyContent: 'flex-end' } },
              el('button', { class: 'btn btn--sm', onclick: () => editor(t) }, 'Edit'),
              el('button', { class: 'btn btn--sm btn--ghost', onclick: () => toggleActive(t) }, t.is_active ? 'Withdraw' : 'Publish')),
          },
        ],
      })),
    [el('button', { class: 'btn btn--sm btn--primary', onclick: () => editor() }, icon('plus', 13), 'New test')]);

  const guidance = staffPanel('Writing a fair test',
    el('div', { class: 'panel__body' },
      el('p', { class: 'small muted', style: { marginTop: 0, lineHeight: '1.6' } },
        'Pass marks are enforced by the server from measured counters, not from what the student reports. If you set 95% accuracy, a student with 94.8% fails even if they ask to be passed.'),
      el('div', { class: 'kv' },
        kv('Accuracy first', 'A 20 WPM student at 98% is more employable than a 35 WPM student at 88%. Set the accuracy mark where the concept is solid, then raise speed.'),
        kv('Duration', 'Three to five minutes matches the length of most employment typing screens.'),
        kv('Backspace', 'Turning backspace off makes corrected mistakes count permanently — useful for examination realism, harsh for beginners.'),
        kv('Randomised passages', 'Not used for instructor tests: everyone types the same text so marks are comparable.'))));

  const node = el('div', {},
    pageHead('Instructor', 'Typing tests',
      'Fixed-passage tests with your own pass marks, examination conditions and verified results.'),
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.7fr) minmax(0, 1fr)', gap: '20px' } },
      list, guidance));


  return {
    node,
    header: {
      title: 'Tests',
      crumbs: [{ label: 'Instructor', href: '#/instructor' }, { label: 'Tests' }],
      actions: [el('button', { class: 'btn btn--sm btn--primary', onclick: () => editor() }, icon('plus', 13), 'New test')],
    },
  };
}

function kv(label, body) {
  return el('div', { class: 'kv__row', style: { alignItems: 'start' } },
    el('span', { class: 'kv__key', style: { width: '150px', flex: 'none' } }, label),
    el('span', { class: 'kv__value small muted', style: { fontFamily: 'var(--font-ui)', fontWeight: '400' } }, body));
}
