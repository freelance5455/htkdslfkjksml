import { api } from '../api.js';
import { el, icon, toast, statTile, relTime, fmtMinutes, barChart, emptyState } from '../ui.js';
import { navigate } from '../router.js';
import { pageHead, staffPanel, dataTable, formDialog, confirmAction, kvList, badge, exportButton, field } from './_staff.js';

export default async function classesView({ params = {} }) {
  if (params.classId) return classDetail(Number(params.classId));
  return classList();
}

// ------------------------------------------------------------------ list
async function classList() {
  const { classes } = await api.get('/api/instructor/classes');

  const create = () => formDialog({
    title: 'New class',
    intro: 'A class groups students so you can assign work, read reports and export results together.',
    fields: [
      { name: 'name', label: 'Class name', required: true, placeholder: 'Evening Batch B — 2026' },
      { name: 'code', label: 'Class code', required: true, placeholder: 'EVE-B-2026', hint: 'Letters, digits and dashes. Students quote this code when asking for help.' },
      { name: 'description', label: 'Description', type: 'textarea', rows: 3, placeholder: 'Mon–Fri, 6–8 pm, ground floor lab' },
    ],
    submitLabel: 'Create class',
    onSubmit: async (values, close) => {
      await api.post('/api/instructor/classes', values);
      close();
      toast('Class created.', { type: 'ok' });
      location.reload();
    },
  });

  const rows = classes.map((c) => ({ ...c }));

  const node = el('div', {},
    pageHead('Instructor', 'Classes', 'Every class you are responsible for. Click a class for its roster, participation and export options.'),
    staffPanel('Your classes',
      el('div', { class: 'panel__body', style: { padding: 0 } },
        dataTable({
          rows,
          empty: 'You have no classes yet.',
          onRowClick: (row) => navigate(`/instructor/classes/${row.id}`),
          columns: [
            { label: 'Class', render: (r) => el('div', {}, el('div', { style: { fontWeight: '600' } }, r.name), el('div', { class: 'tiny muted' }, r.description || r.code)) },
            { label: 'Code', render: (r) => el('code', {}, r.code) },
            { label: 'Students', align: 'right', render: (r) => String(r.students ?? 0) },
            { label: 'Instructor', render: (r) => r.instructor_name ?? '—' },
            { label: 'Status', render: (r) => (r.is_active ? badge('active', 'ok') : badge('archived')) },
            { label: '', align: 'right', render: (r) => el('button', { class: 'btn btn--sm', onclick: () => navigate(`/instructor/classes/${r.id}`) }, 'Open') },
          ],
        })),
      [el('button', { class: 'btn btn--sm btn--primary', onclick: create }, icon('plus', 13), 'New class')]));

  return {
    node,
    header: { title: 'Classes', crumbs: [{ label: 'Instructor', href: '#/instructor' }, { label: 'Classes' }] },
  };
}

// ---------------------------------------------------------------- detail
async function classDetail(classId) {
  const [report, status] = await Promise.all([
    api.get(`/api/instructor/classes/${classId}`),
    api.get(`/api/instructor/classes/${classId}/assignment-status`).catch(() => ({ rows: [] })),
  ]);
  const { class: cls, students, totals } = report;

  const kpis = el('div', { class: 'stats', style: { gridTemplateColumns: 'repeat(5, 1fr)' } },
    statTile({ label: 'Students', value: totals.students, hint: `${totals.active} active accounts` }),
    statTile({ label: 'Class average', value: totals.avgWpm, hint: 'net WPM' }),
    statTile({ label: 'Average accuracy', value: `${Math.round(totals.avgAccuracy)}%` }),
    statTile({ label: 'Lessons mastered', value: totals.lessonsMastered }),
    statTile({ label: 'Practice time', value: fmtMinutes(totals.practiceMs), hint: 'all students' }));

  const needsHelp = students.filter((s) => (s.avgAccuracy > 0 && s.avgAccuracy < 90) || s.overdue > 0);

  const roster = staffPanel('Roster',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: students,
        empty: 'No students enrolled yet.',
        onRowClick: (row) => navigate(`/instructor/students/${row.id}`),
        columns: [
          { label: 'Student', render: (r) => el('div', {}, el('div', { style: { fontWeight: '600' } }, r.displayName), el('div', { class: 'tiny muted' }, r.username)) },
          { label: 'Mastered', align: 'right', render: (r) => String(r.mastered) },
          { label: 'Best WPM', align: 'right', render: (r) => String(Math.round(r.bestWpm)) },
          { label: 'Accuracy', align: 'right', render: (r) => (r.avgAccuracy ? `${Math.round(r.avgAccuracy)}%` : '—') },
          { label: 'Open work', align: 'right', render: (r) => (r.overdue ? badge(`${r.overdue} overdue`, 'danger') : r.pending ? badge(`${r.pending} pending`) : '—') },
          { label: 'Last practice', align: 'right', render: (r) => (r.lastPracticeAt ? relTime(r.lastPracticeAt) : badge('none', 'warn')) },
        ],
      })),
    [
      exportButton({ label: 'CSV', href: `/api/instructor/classes/${classId}/export.csv` }),
      el('button', { class: 'btn btn--sm btn--primary', onclick: () => addStudent() }, icon('plus', 13), 'Add student'),
    ]);

  function addStudent() {
    formDialog({
      title: `Add a student to ${cls.name}`,
      intro: 'Create a login for a new student, or enrol an existing account by its username.',
      fields: [
        { name: 'mode', label: 'What do you want to do?', type: 'select', value: 'new', options: [
          { value: 'new', label: 'Create a new student account' },
          { value: 'existing', label: 'Enrol an existing account' },
        ] },
        { name: 'username', label: 'Username', placeholder: 'ria.das', hint: 'Letters, digits, dot, dash, underscore.' },
        { name: 'displayName', label: 'Full name', placeholder: 'Ria Das' },
        { name: 'password', label: 'Temporary password', type: 'text', placeholder: 'at least 10 characters', hint: 'The student must change it at first sign-in. Read it out; never write it on the board.' },
      ],
      wide: true,
      submitLabel: 'Add to class',
      onSubmit: async (values, close) => {
        if (values.mode === 'existing') {
          const found = await api.get(`/api/instructor/students?q=${encodeURIComponent(values.username)}`);
          const match = (found.students ?? []).find((s) => s.username.toLowerCase() === values.username.toLowerCase());
          if (!match) throw new Error('No student account with that username.');
          await api.post(`/api/instructor/classes/${classId}/students`, { studentId: match.id });
        } else {
          await api.post(`/api/instructor/classes/${classId}/students`, {
            username: values.username, displayName: values.displayName, password: values.password,
          });
        }
        close();
        toast('Student enrolled.', { type: 'ok' });
        refresh();
      },
    });
  }

  const attentionPanel = staffPanel('Attendance and risk',
    el('div', { class: 'panel__body' },
      needsHelp.length
        ? el('div', {}, needsHelp.map((s) => el('div', { class: 'risk-row' },
          el('div', {},
            el('div', { style: { fontWeight: '600', fontSize: 'var(--fs-sm)' } }, s.displayName),
            el('div', { class: 'tiny muted' }, s.avgAccuracy && s.avgAccuracy < 90 ? `Accuracy ${Math.round(s.avgAccuracy)}% — below the 90% floor` : `Last practice ${relTime(s.lastPracticeAt)}`)),
          el('a', { class: 'btn btn--sm', href: `#/instructor/students/${s.id}` }, 'Open'))))
        : emptyState({ title: 'Nobody at risk', message: 'No student in this class is below 90% accuracy or overdue on assigned work.', iconName: 'check' })));

  const assignmentPanel = staffPanel('Assignment status',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: status.rows ?? [],
        empty: 'No active assignments for this class.',
        columns: [
          { label: 'Student', render: (r) => r.displayName },
          { label: 'Pending', align: 'right', render: (r) => String(r.pending ?? 0) },
          { label: 'Overdue', align: 'right', render: (r) => (r.overdue ? badge(String(r.overdue), 'danger') : '0') },
          { label: 'Completed', align: 'right', render: (r) => String(r.completed ?? 0) },
        ],
      })),
    [el('button', { class: 'btn btn--sm', onclick: () => navigate('/instructor/assignments') }, 'Assign work')]);

  const edit = () => formDialog({
    title: 'Edit class',
    fields: [
      { name: 'name', label: 'Class name', value: cls.name, required: true },
      { name: 'description', label: 'Description', type: 'textarea', rows: 3, value: cls.description ?? '' },
      { name: 'isActive', label: 'Class is active', type: 'checkbox', value: true },
    ],
    onSubmit: async (values, close) => {
      await api.patch(`/api/instructor/classes/${classId}`, values);
      close();
      toast('Class updated.', { type: 'ok' });
      location.reload();
    },
  });

  function refresh() {
    location.hash = `#/instructor/classes/${classId}`;
    location.reload();
  }

  const header = el('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: '16px', marginBottom: '18px' } },
    el('div', {},
      el('div', { class: 'eyebrow' }, `Class ${cls.code}`),
      el('h1', {}, cls.name),
      el('p', { class: 'lede' }, cls.description || 'No description set for this class.')),
    el('div', { style: { display: 'flex', gap: '8px' } },
      el('button', { class: 'btn btn--sm', onclick: edit }, 'Edit class'),
      el('a', { class: 'btn btn--sm btn--ghost', href: '#/instructor/classes' }, 'All classes')));

  const node = el('div', {}, header, kpis,
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.6fr) minmax(0, 1fr)', gap: '20px' } },
      roster,
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, attentionPanel, assignmentPanel)));


  return {
    node,
    header: {
      title: cls.name,
      crumbs: [{ label: 'Instructor', href: '#/instructor' }, { label: 'Classes', href: '#/instructor/classes' }, { label: cls.name }],
    },
  };
}
