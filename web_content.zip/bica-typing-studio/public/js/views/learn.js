import { api } from '../api.js';
import { el, icon, meter, emptyState, relTime } from '../ui.js';
import { navigate } from '../router.js';
import { startLesson } from '../typing.js';

export default async function learnView({ params }) {
  if (params.lessonId) return lessonDetail(params.lessonId);
  return curriculumList();
}

async function curriculumList() {
  const data = await api.get('/api/curriculum');
  const current = data.currentLessonId;

  const header = el('div', { style: { marginBottom: '22px' } },
    el('div', { class: 'eyebrow' }, 'Learn'),
    el('h1', { style: { marginBottom: '6px' } }, 'The typing course'),
    el('p', { class: 'lede' }, 'Seven levels, fifty lessons. Each lesson unlocks when you meet its accuracy requirement — not when you click it. Expect two to four minutes per lesson.'),
    el('div', { class: 'stats', style: { marginTop: '18px' } },
      el('div', { class: 'stat' }, el('div', { class: 'stat__label' }, 'Lessons mastered'), el('div', { class: 'stat__value num' }, `${data.masteredCount}`, el('small', {}, `/ ${data.totalLessons}`))),
      el('div', { class: 'stat' }, el('div', { class: 'stat__label' }, 'Unlocked'), el('div', { class: 'stat__value num' }, String(data.unlockedCount))),
      el('div', { class: 'stat' }, el('div', { class: 'stat__label' }, 'Progression'), el('div', { class: 'stat__value num' }, data.sequential ? 'Sequential' : 'Open')),
      el('div', { class: 'stat' }, el('div', { class: 'stat__label' }, 'Curriculum version'), el('div', { class: 'stat__value num', style: { fontSize: '18px' } }, data.curriculumVersion ?? '—'))));

  const blocks = data.levels.map((level) => {
    const mastered = level.lessons.filter((l) => l.mastered).length;
    const anyUnlocked = level.lessons.some((l) => l.unlocked);
    const isCurrent = level.lessons.some((l) => l.id === current);
    return el('section', { class: `level-block ${anyUnlocked ? '' : 'level-block--locked'}` },
      el('div', { class: 'level-block__head' },
        el('div', { class: 'level-badge' }, String(level.level)),
        el('div', { class: 'level-block__title' },
          el('h3', {}, `${level.name}${isCurrent ? ' · current' : ''}`),
          el('p', {}, level.blurb)),
        el('div', { style: { textAlign: 'right', minWidth: '120px' } },
          el('div', { class: 'small', style: { fontWeight: '600' } }, `${mastered} / ${level.lessons.length}`),
          el('div', { style: { marginTop: '4px' } }, meter(mastered, { max: level.lessons.length, thin: true })))),
      el('div', { class: 'lesson-list' }, level.lessons.map((lesson, i) => {
        const cls = lesson.mastered ? 'lesson-row lesson-row--done' : lesson.id === current ? 'lesson-row lesson-row--current' : lesson.unlocked ? 'lesson-row' : 'lesson-row lesson-row--locked';
        return el('a', {
          class: cls,
          href: lesson.unlocked ? `#/learn/${lesson.id}` : null,
          'aria-disabled': lesson.unlocked ? null : 'true',
        },
        el('div', { class: 'lesson-row__status' }, lesson.mastered ? icon('check', 13) : !lesson.unlocked ? icon('lock', 11) : String(i + 1)),
        el('div', {},
          el('div', { class: 'lesson-row__title' }, lesson.title),
          el('div', { class: 'lesson-row__meta' },
            lesson.objective,
            lesson.isExam ? el('span', { class: 'badge badge--accent', style: { marginLeft: '8px' } }, 'scored exam') : null)),
        el('div', { class: 'lesson-row__right' },
          lesson.bestAccuracy > 0 ? el('span', { class: 'mono' }, `${Math.round(lesson.bestAccuracy)}%`) : null,
          lesson.bestWpm > 0 ? el('span', { class: 'mono tiny muted' }, `${lesson.bestWpm} wpm`) : null,
          el('span', { class: 'badge' }, `≥${Math.round(lesson.thresholds?.minAccuracy ?? lesson.minAccuracy)}%`),
          lesson.unlocked ? icon('right', 14) : null));
      })));
  });

  const node = el('div', {}, header, el('div', { class: 'curriculum' }, blocks));
  return {
    node,
    header: {
      title: 'Learn',
      crumbs: [{ label: 'Learn' }],
      actions: current ? [el('button', { class: 'btn btn--sm btn--primary', onclick: () => navigate(`/learn/${current}`) }, icon('play', 13), 'Current lesson')] : [],
    },
  };
}

async function lessonDetail(lessonId) {
  let data;
  try {
    data = await api.get(`/api/curriculum/lessons/${lessonId}`);
  } catch (err) {
    if (err.status === 403) {
      return {
        node: emptyState({
          title: 'This lesson is locked',
          message: 'Master the previous lesson first. Your instructor can also unlock lessons from the instructor portal.',
          iconName: 'lock',
          action: el('button', { class: 'btn btn--primary', onclick: () => navigate('/learn') }, 'Back to the course'),
        }),
        header: { title: 'Locked lesson', crumbs: [{ label: 'Learn', href: '#/learn' }, { label: 'Locked' }] },
      };
    }
    throw err;
  }

  const { lesson, progress, fingerGuide, keyDetails } = data;
  let selectedDrill = 0;

  const drillButtons = el('div', { class: 'chip-grid' }, lesson.drills.map((d, i) => el('button', {
    class: 'chip',
    'aria-pressed': i === 0 ? 'true' : 'false',
    onclick: (e) => {
      selectedDrill = i;
      for (const chip of e.currentTarget.parentElement.children) chip.setAttribute('aria-pressed', 'false');
      e.currentTarget.setAttribute('aria-pressed', 'true');
      previewHost.textContent = d;
      previewMeta.textContent = `${d.length} characters`;
    },
  }, `Drill ${i + 1}`)));

  const previewHost = el('div', {
    class: 'mono',
    style: {
      padding: '16px', background: 'var(--surface-2)', border: '1px solid var(--line)',
      borderRadius: '8px', fontSize: '15px', lineHeight: '1.9', color: 'var(--ink-700)', whiteSpace: 'pre-wrap',
    },
  }, lesson.drills[0]);
  const previewMeta = el('div', { class: 'tiny muted', style: { marginTop: '6px' } }, `${lesson.drills[0].length} characters`);

  const startBtn = el('button', { class: 'btn btn--primary btn--lg', onclick: launch }, icon('play', 15), 'Begin drill');
  const practiceBtn = el('button', { class: 'btn btn--lg', onclick: () => navigate('/practice') }, 'Practise instead');

  async function launch() {
    startBtn.disabled = true;
    startBtn.textContent = 'Starting…';
    try {
      await startLesson(lesson.id, selectedDrill, {
        onExit: () => { startBtn.disabled = false; startBtn.textContent = 'Begin drill'; refresh(); },
        onComplete: (res) => {
          startBtn.disabled = false;
          startBtn.textContent = 'Begin drill';
          if (res?.passed) refresh();
        },
        onRetry: () => launch(),
      });
    } catch (err) {
      startBtn.disabled = false;
      startBtn.textContent = 'Begin drill';
      const { toast: t2 } = await import('../ui.js');
      t2(err.message, { type: 'error' });
    }
  }

  async function refresh() {
    try {
      const fresh = await api.get(`/api/curriculum/lessons/${lesson.id}`);
      render(fresh);
    } catch { /* ignore */ }
  }

  function render(fresh) {
    const p = fresh.progress;
    bestHost.textContent = p?.bestAccuracy
      ? `Best so far: ${Math.round(p.bestAccuracy)}% accuracy at ${p.bestWpm} WPM (${p.attempts} attempt${p.attempts === 1 ? '' : 's'}${p.lastAttemptAt ? `, ${relTime(p.lastAttemptAt)}` : ''}).`
      : 'No attempts recorded for this lesson yet.';
    if (p?.mastered) {
      masteredBadge.classList.remove('hidden');
    }
  }

  const bestHost = el('p', { class: 'small muted', style: { marginTop: '10px' } },
    progress?.bestAccuracy
      ? `Best so far: ${Math.round(progress.bestAccuracy)}% accuracy at ${progress.bestWpm} WPM (${progress.attempts} attempt${progress.attempts === 1 ? '' : 's'}).`
      : 'No attempts recorded for this lesson yet.');

  const masteredBadge = el('span', { class: `badge badge--ok ${progress?.mastered ? '' : 'hidden'}` }, icon('check', 12), 'Mastered');

  const node = el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 320px', gap: '24px' } },
    el('div', {},
      el('div', { class: 'eyebrow' }, `Level ${lesson.level} · ${lesson.levelName} · Lesson ${lesson.order}`),
      el('div', { style: { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' } },
        el('h1', {}, lesson.title), masteredBadge),
      el('p', { class: 'lede', style: { marginBottom: '20px' } }, lesson.objective),

      el('div', { class: 'panel', style: { marginBottom: '18px' } },
        el('div', { class: 'panel__head' }, el('h3', {}, 'Before you type')),
        el('div', { class: 'panel__body' },
          el('p', { style: { marginBottom: '14px', lineHeight: '1.6' } }, lesson.explanation),
          el('h4', { style: { marginBottom: '8px' } }, 'Finger positions for this drill'),
          el('div', { style: { display: 'grid', gap: '6px' } },
            fingerGuide.length === 0
              ? el('p', { class: 'small muted' }, 'All fingers are used in this drill.')
              : fingerGuide.map((f) => el('div', { style: { display: 'grid', gridTemplateColumns: '12px 170px 1fr', gap: '10px', alignItems: 'center' } },
                el('span', { style: { width: '10px', height: '10px', borderRadius: '2px', background: f.color } }),
                el('span', { class: 'small', style: { fontWeight: '550' } }, f.label),
                el('span', { class: 'mono small muted' }, f.keys.slice(0, 14).join(' '))))))),

      el('div', { class: 'panel', style: { marginBottom: '18px' } },
        el('div', { class: 'panel__head' },
          el('h3', {}, 'Drill'),
          el('span', { class: 'tiny muted' }, 'Choose a variation')),
        el('div', { class: 'panel__body' },
          drillButtons,
          el('div', { style: { marginTop: '14px' } }, previewHost, previewMeta),
          el('div', { style: { display: 'flex', gap: '10px', marginTop: '18px', alignItems: 'center', flexWrap: 'wrap' } },
            startBtn, practiceBtn),
          bestHost)),

      el('div', { class: 'panel' },
        el('div', { class: 'panel__head' }, el('h3', {}, 'Keys in this drill')),
        el('div', { class: 'panel__body' },
          el('div', { class: 'chip-grid' }, lesson.keys.slice(0, 40).map((k) => el('span', { class: 'chip mono' }, k === ' ' ? 'Space' : k))),
          el('p', { class: 'tiny muted', style: { marginTop: '10px', marginBottom: 0 } },
            `${lesson.keys.length} distinct keys · about ${lesson.estMinutes} minutes`)))),

    el('aside', { style: { display: 'grid', gap: '16px', alignContent: 'start' } },
      el('div', { class: 'panel' },
        el('div', { class: 'panel__head' }, el('h3', {}, 'Requirement')),
        el('div', { class: 'panel__body' },
          el('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '6px' } },
            el('span', { class: 'small' }, 'Accuracy'),
            el('span', { class: 'mono small', style: { fontWeight: '600' } }, `${Math.round(progress?.thresholds?.minAccuracy ?? lesson.minAccuracy)}%`)),
          el('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '6px' } },
            el('span', { class: 'small' }, 'Net speed'),
            el('span', { class: 'mono small', style: { fontWeight: '600' } },
              (progress?.thresholds?.minWpm ?? lesson.minWpm) > 0 ? `${progress?.thresholds?.minWpm ?? lesson.minWpm} WPM` : 'no target')),
          el('div', { style: { display: 'flex', justifyContent: 'space-between' } },
            el('span', { class: 'small' }, 'Corrected errors'),
            el('span', { class: 'small' }, 'not allowed')),
          el('p', { class: 'tiny muted', style: { marginTop: '10px', marginBottom: 0, lineHeight: '1.55' } },
            'A lesson is mastered when a single attempt meets every requirement above. Two good attempts do not combine into one pass.'))),

      el('div', { class: 'panel' },
        el('div', { class: 'panel__head' }, el('h3', {}, 'Key map')),
        el('div', { class: 'panel__body' },
          el('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(52px, 1fr))', gap: '6px' } },
            keyDetails.slice(0, 12).map((k) => {
              const label = k.key === ' ' ? '\u2423' : k.key;
              const finger = String(k.finger ?? '').replace('L-', 'left ').replace('R-', 'right ');
              return el('div', {
                style: {
                  border: '1px solid var(--line)', borderRadius: '5px', padding: '6px 4px',
                  textAlign: 'center', background: 'var(--surface-2)',
                },
              },
              el('div', { class: 'mono', style: { fontWeight: '600', fontSize: '13px' } }, label),
              el('div', { class: 'tiny muted', style: { lineHeight: '1.2', marginTop: '2px' } }, finger));
            }))))));

  return {
    node,
    header: {
      title: lesson.title,
      crumbs: [{ label: 'Learn', href: '#/learn' }, { label: `Level ${lesson.level}` }, { label: lesson.id }],
      actions: [el('button', { class: 'btn btn--sm btn--primary', onclick: launch }, icon('play', 13), 'Begin drill')],
    },
  };
}
