import { api } from '../api.js';
import { el, icon, toast, fmtDate, relTime, emptyState } from '../ui.js';
import { navigate } from '../router.js';
import { pageHead, staffPanel, dataTable, formDialog, confirmAction, badge } from './_staff.js';

export default async function assignmentsView() {
  const [{ assignments }, { classes }, catalog, studentsData] = await Promise.all([
    api.get('/api/instructor/assignments'),
    api.get('/api/instructor/classes'),
    api.get('/api/instructor/catalog'),
    api.get('/api/instructor/students').catch(() => ({ students: [] })),
  ]);
  const students = studentsData.students ?? [];

  // ------------------------------------------------------------- assignments
  const rows = assignments.map((a) => ({ ...a }));
  const open = rows.filter((a) => !a.dueAt || Date.parse(a.dueAt.replace(' ', 'T')) > Date.now());

  const listPanel = staffPanel(`Active assignments (${rows.length})`,
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows,
        empty: 'No assignments yet. Use “New assignment” to give a class a lesson, game, test or practice target.',
        columns: [
          { label: 'Title', render: (a) => el('div', {}, el('div', { style: { fontWeight: '600' } }, a.title), el('div', { class: 'tiny muted' }, a.instructions || '—')) },
          { label: 'Type', render: (a) => badge(a.kind.toLowerCase()) },
          { label: 'Target', render: (a) => el('code', { class: 'tiny' }, a.targetRef) },
          { label: 'Given to', render: (a) => a.className ? `Class: ${a.className}` : a.studentName ? `Student: ${a.studentName}` : '—' },
          { label: 'Due', render: (a) => (a.dueAt ? fmtDate(a.dueAt) : el('span', { class: 'muted' }, 'no deadline')) },
          {
            label: '', align: 'right',
            render: (a) => el('button', {
              class: 'btn btn--sm btn--ghost',
              onclick: () => confirmAction({
                title: 'Archive assignment',
                message: `“${a.title}” will stop appearing for students. Completed results are kept.`,
                confirmLabel: 'Archive',
                danger: true,
                run: async () => {
                  await api.del(`/api/instructor/assignments/${a.id}`);
                  toast('Assignment archived.', { type: 'ok' });
                  location.reload();
                },
              }),
            }, 'Archive'),
          },
        ],
      })),
    [el('button', { class: 'btn btn--sm btn--primary', onclick: create }, icon('plus', 13), 'New assignment')]);

  // ----------------------------------------------------------------- create
  function targetOptions(kind) {
    if (kind === 'LESSON') return catalog.lessons.map((l) => ({ value: l.id, label: `L${l.level} — ${l.title}` }));
    if (kind === 'GAME') return catalog.games.map((g) => ({ value: g.id, label: g.title }));
    if (kind === 'TEST') return catalog.tests.map((t) => ({ value: String(t.id), label: t.title }));
    return [{ value: 'any', label: 'Any practice session' }];
  }

  function create() {
    const fields = [
      { name: 'kind', label: 'Type of work', type: 'select', value: 'LESSON', options: [
        { value: 'LESSON', label: 'Lesson — a specific lesson must be mastered' },
        { value: 'GAME', label: 'Game — one round of a specific game' },
        { value: 'TEST', label: 'Test — a timed test you created' },
        { value: 'PRACTICE', label: 'Practice — any qualifying practice session' },
      ] },
      { name: 'title', label: 'Title students will see', required: true, placeholder: 'Home row consolidation' },
      { name: 'target', label: 'Which one', type: 'select', value: '', options: targetOptions('LESSON') },
      { name: 'audience', label: 'Give it to', type: 'select', value: classes[0] ? `class:${classes[0].id}` : '', options: [
        ...classes.map((c) => ({ value: `class:${c.id}`, label: `Whole class — ${c.name}` })),
        ...students.map((s) => ({ value: `student:${s.id}`, label: `One student — ${s.display_name}` })),
      ] },
      { name: 'dueAt', label: 'Deadline', type: 'datetime-local' },
      { name: 'instructions', label: 'Instructions', type: 'textarea', rows: 3, placeholder: 'Two clean runs. Accuracy first: 95% or nothing counts.' },
      { name: 'minDurationMinutes', label: 'Minimum practice length (minutes, practice only)', type: 'number', min: 1, max: 60, value: 2 },
    ];

    const handle = formDialog({
      title: 'New assignment',
      intro: 'Students see this in their dashboard as work to do, with the deadline and whether it is pending, late or complete.',
      fields,
      wide: true,
      submitLabel: 'Assign',
      onSubmit: async (values, close) => {
        const [audienceKind, audienceId] = String(values.audience).split(':');
        const payload = {
          kind: values.kind,
          title: values.title,
          targetRef: values.kind === 'PRACTICE' ? 'any' : String(values.target),
          dueAt: values.dueAt ? values.dueAt : null,
          instructions: values.instructions || null,
          ...(audienceKind === 'class' ? { classId: Number(audienceId) } : { studentId: Number(audienceId) }),
          ...(values.kind === 'PRACTICE' ? { criteria: { minDurationMs: Number(values.minDurationMinutes ?? 2) * 60000 } } : {}),
        };
        if (!payload.targetRef) throw new Error('Choose which lesson, game or test to assign.');
        await api.post('/api/instructor/assignments', payload);
        close();
        toast('Assignment created.', { type: 'ok' });
        location.reload();
      },
    });

    // keep the target list in step with the chosen type
    const panelEl = handle.panel;
    const kindSelect = panelEl.querySelectorAll('select')[0];
    const targetSelect = panelEl.querySelectorAll('select')[1];
    kindSelect.addEventListener('change', () => {
      const options = targetOptions(kindSelect.value);
      targetSelect.replaceChildren(...options.map((o) => el('option', { value: o.value }, o.label)));
      const durationField = panelEl.querySelectorAll('input[type="number"]')[0]?.closest('.field');
      if (durationField) durationField.style.display = kindSelect.value === 'PRACTICE' ? '' : 'none';
    });
    if (kindSelect.value !== 'PRACTICE') {
      const durationField = panelEl.querySelectorAll('input[type="number"]')[0]?.closest('.field');
      if (durationField) durationField.style.display = 'none';
    }
  }

  const explain = staffPanel('How assignments are assessed',
    el('div', { class: 'panel__body' },
      el('p', { class: 'small muted', style: { marginTop: 0, lineHeight: '1.6' } },
        'Assignments are evaluated when a student opens their dashboard, not stored as a status. A lesson assignment is complete when a verified session for that lesson passes the mastery rule after the assignment was created. A test assignment needs one submitted test session. A game assignment needs one finished round. Practice needs a session of at least the minimum length you set.'),
      el('p', { class: 'small muted', style: { marginTop: 0, lineHeight: '1.6' } },
        'That means a student cannot mark their own work complete, and nothing becomes “done” because of an accident — only a real, server-recorded session counts.')));

  const node = el('div', {},
    pageHead('Instructor', 'Assignments',
      'Give a class or a single student a specific lesson, game, test or practice target, with or without a deadline.'),
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.6fr) minmax(0, 1fr)', gap: '20px' } },
      listPanel,
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } },
        open.length ? staffPanel('Deadlines ahead',
          el('div', { class: 'panel__body', style: { padding: 0 } },
            dataTable({
              rows: open.slice(0, 6),
              empty: 'No deadlines set.',
              columns: [
                { label: 'Work', render: (a) => a.title },
                { label: 'Due', align: 'right', render: (a) => (a.dueAt ? relTime(a.dueAt) : '—') },
              ],
            })))
          : emptyState({ title: 'No open deadlines', message: 'Assignments without deadlines still appear in student dashboards.', iconName: 'clock' }),
        explain)));


  return {
    node,
    header: {
      title: 'Assignments',
      crumbs: [{ label: 'Instructor', href: '#/instructor' }, { label: 'Assignments' }],
      actions: [el('button', { class: 'btn btn--sm btn--primary', onclick: () => create() }, icon('plus', 13), 'New assignment')],
    },
  };
}
