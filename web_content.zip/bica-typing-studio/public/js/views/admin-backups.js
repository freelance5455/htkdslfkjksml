import { api } from '../api.js';
import { el, icon, toast, relTime, emptyState } from '../ui.js';
import { pageHead, staffPanel, dataTable, confirmAction, badge } from './_staff.js';

function bytes(n) {
  if (n >= 1048576) return `${(n / 1048576).toFixed(1)} MB`;
  if (n >= 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${n} B`;
}

export default async function backupsView() {
  const [{ backups, directory }, sync] = await Promise.all([
    api.get('/api/admin/backups'),
    api.get('/api/admin/sync-status').catch(() => ({ summary: [], failed: [] })),
  ]);

  const creating = { busy: false };

  async function createBackup() {
    if (creating.busy) return;
    creating.busy = true;
    toast('Creating a consistent copy of the database…', { type: 'info', timeout: 3000 });
    try {
      const result = await api.post('/api/admin/backups', {});
      toast(`Backup created: ${result.file ?? 'database copy'} (${bytes(result.bytes ?? 0)})`, { type: 'ok', timeout: 6000 });
      setTimeout(() => location.reload(), 700);
    } catch (err) {
      toast(err.message, { type: 'error' });
      creating.busy = false;
    }
  }

  const latest = backups[0];

  const list = staffPanel(`Backups (${backups.length})`,
    el('div', { class: 'panel__body', style: { padding: 0 } },
      backups.length
        ? dataTable({
          rows: backups,
          empty: '',
          rowKey: (b) => b.file,
          columns: [
            { label: 'File', render: (b) => el('code', { class: 'tiny' }, b.file) },
            { label: 'Size', align: 'right', render: (b) => bytes(b.bytes) },
            { label: 'Created', align: 'right', render: (b) => relTime(b.createdAt) },
            {
              label: '', align: 'right',
              render: (b) => el('a', { class: 'btn btn--sm', href: `/api/admin/backups/${encodeURIComponent(b.file)}`, download: '' },
                icon('download', 12), 'Download'),
            },
          ],
        })
        : emptyState({
          title: 'No backups yet',
          message: 'Create the first backup now. Backups are consistent SQLite copies taken with the database open, so they are safe while students are working.',
          iconName: 'database',
          action: el('button', { class: 'btn btn--primary', onclick: createBackup }, 'Create backup'),
        })),
    [el('button', { class: 'btn btn--sm btn--primary', onclick: createBackup }, icon('archive', 13), 'Create backup')]);

  const policy = staffPanel('Backup policy',
    el('div', { class: 'panel__body' },
      el('div', { class: 'kv' },
        kv('Where', directory ?? 'configured backup directory'),
        kv('How', 'better-sqlite3 online backup API — a consistent snapshot while the app keeps running.'),
        kv('Latest', latest ? `${latest.file} · ${relTime(latest.createdAt)} · ${bytes(latest.bytes)}` : 'none'),
        kv('Restore', 'Stop the server, copy the backup file over data/bica.db, start the server. Documented in docs/RECOVERY.md.'),
        kv('Off-site', 'Download the file and keep a copy on a different machine or drive. A backup on the same disk does not survive a disk failure.')),
      el('div', { class: 'callout callout--warn', style: { marginTop: '14px' } },
        el('strong', {}, 'Do this before every term. '),
        'Download the latest backup, verify it opens, and store it away from the lab computer. A backup you have never opened is not a backup.')));

  const stepItems = [
    el('li', {}, el('strong', {}, 'Stop the server.'), ' Nothing else may write to the database during a restore.'),
    el('li', {}, el('strong', {}, 'Keep the current file.'), ' Rename data/bica.db to bica.db.before-restore so the restore can be undone.'),
    el('li', {}, el('strong', {}, 'Copy the backup'), ' over data/bica.db, keeping the same filename.'),
    el('li', {}, el('strong', {}, 'Start the server'), ' and sign in. The migration table will confirm the schema version; a backup from a newer version will refuse to open rather than corrupt data.'),
    el('li', {}, el('strong', {}, 'Check three things:'), ' a student can sign in, a lesson opens, and the newest session you remember is present.'),
  ];

  const restoreSteps = staffPanel('Restore procedure',
    el('div', { class: 'panel__body' }, el('ol', { class: 'steps' }, stepItems)));

  const syncRows = sync.summary ?? [];
  const queuePanel = staffPanel('Offline submissions',
    el('div', { class: 'panel__body' },
      syncRows.length
        ? el('div', { class: 'kv' }, syncRows.map((r) => kv(`${r.status} · ${r.kind}`, `${r.count}${r.latest ? ` · last ${relTime(r.latest)}` : ''}`)))
        : el('p', { class: 'small muted', style: { margin: 0 } },
          'No offline submissions have been recorded yet. When a student finishes practice without a network connection, the result is queued on their computer and appears here after it syncs.'),
      el('p', { class: 'tiny muted', style: { marginTop: '12px' } },
        'Conflict rule: a session is identified by a client-generated id. If the same id arrives twice, the second submission is reported as a duplicate and the stored result is not overwritten with a newer computation.')));

  const node = el('div', {},
    pageHead('Administration', 'Backups and recovery',
      'A single-file database makes backup straightforward — provided somebody actually does it, and checks the copy opens.'),
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.4fr) minmax(0, 1fr)', gap: '20px' } },
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, list, restoreSteps),
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, policy, queuePanel)));


  return {
    node,
    header: {
      title: 'Backups',
      crumbs: [{ label: 'Administration', href: '#/admin' }, { label: 'Backups' }],
      actions: [el('button', { class: 'btn btn--sm btn--primary', onclick: createBackup }, icon('archive', 13), 'Create backup')],
    },
  };
}

function kv(label, value) {
  return el('div', { class: 'kv__row', style: { alignItems: 'start' } },
    el('span', { class: 'kv__key', style: { width: '110px', flex: 'none' } }, label),
    el('span', { class: 'kv__value small muted', style: { fontFamily: 'var(--font-ui)', fontWeight: '400' } }, value));
}
