import { api } from '../api.js';
import { el, icon, statTile, lineChart, barChart, relTime, fmtMinutes, emptyState, toast } from '../ui.js';
import { navigate } from '../router.js';
import { pageHead, staffPanel, dataTable, confirmAction, badge, exportButton } from './_staff.js';

export default async function adminView() {
  const [dash, sync] = await Promise.all([
    api.get('/api/admin/dashboard'),
    api.get('/api/admin/sync-status').catch(() => ({ summary: [], failed: [] })),
  ]);
  const { counts, daily, levelDistribution, topClasses, demoDataPresent } = dash;

  const kpis = el('div', { class: 'stats', style: { gridTemplateColumns: 'repeat(5, 1fr)', marginBottom: '20px' } },
    statTile({ label: 'Active students', value: counts.students }),
    statTile({ label: 'Instructors', value: counts.instructors }),
    statTile({ label: 'Classes', value: counts.classes }),
    statTile({ label: 'Practice hours', value: counts.practiceHours, hint: `${counts.sessions} sessions` }),
    statTile({ label: 'Average net WPM', value: counts.averageWpm30d, hint: 'last 30 days' }));

  const chartData = daily.map((d) => ({ label: d.day.slice(5), value: d.avg_wpm, sessions: d.sessions, students: d.students }));

  const activity = staffPanel('Centre activity, last 30 days',
    el('div', { class: 'panel__body' },
      chartData.length
        ? el('div', {},
          lineChart({ data: chartData, height: 190, valueKey: 'value', labelKey: 'label', unit: ' WPM' }),
          el('div', { class: 'tiny muted', style: { marginTop: '8px' } },
            'Average net WPM of verified sessions per day. A flat line with rising session counts usually means students are practising but not improving — check the accuracy column in class reports.'))
        : emptyState({
          title: 'No sessions recorded',
          message: 'The centre has no typing sessions yet. Enrol students and have them complete a lesson to see activity here.',
          iconName: 'chart',
        })));

  const levelBars = levelDistribution.map((l) => ({ label: `L${l.level}`, value: l.mastered }));
  const levelPanel = staffPanel('Lessons mastered by level',
    el('div', { class: 'panel__body' },
      levelDistribution.some((l) => l.mastered > 0)
        ? barChart({ data: levelBars, height: 170, unit: '' })
        : el('p', { class: 'small muted', style: { margin: 0 } }, 'No lesson has been mastered yet across the centre.')));

  const classPanel = staffPanel('Classes by average speed',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: topClasses,
        empty: 'No classes yet.',
        columns: [
          { label: 'Class', render: (c) => el('div', {}, el('div', { style: { fontWeight: '600' } }, c.name), el('div', { class: 'tiny muted' }, c.code)) },
          { label: 'Students', align: 'right', render: (c) => String(c.students) },
          { label: 'Avg WPM', align: 'right', render: (c) => String(c.avg_wpm ?? 0) },
          { label: 'Accuracy', align: 'right', render: (c) => (c.avg_accuracy ? `${c.avg_accuracy}%` : '—') },
        ],
      })),
    [el('button', { class: 'btn btn--sm btn--ghost', onclick: () => navigate('/instructor/classes') }, 'All classes')]);

  const syncRows = sync.summary ?? [];
  const failedSync = sync.failed ?? [];
  const syncPanel = staffPanel('Offline sync',
    el('div', { class: 'panel__body' },
      syncRows.length
        ? el('div', {},
          el('div', { class: 'kv' }, syncRows.map((r) => el('div', { class: 'kv__row' },
            el('span', { class: 'kv__key' }, `${r.status} · ${r.kind}`),
            el('span', { class: 'kv__value' }, `${r.count} record${r.count === 1 ? '' : 's'}${r.latest ? `, last ${relTime(r.latest)}` : ''}`)))),
          failedSync.length
            ? el('div', { style: { marginTop: '12px' } },
              el('div', { class: 'small', style: { fontWeight: '600', marginBottom: '6px' } }, `${failedSync.length} failed submissions need a decision`),
              failedSync.slice(0, 6).map((f) => el('div', { class: 'sync-row' },
                el('div', {},
                  el('div', { class: 'small' }, f.display_name ?? 'Student'),
                  el('div', { class: 'tiny muted' }, f.reason ?? f.error ?? 'Submission rejected by the server')),
                el('span', { class: 'tiny muted' }, relTime(f.created_at)))))
            : null)
        : el('p', { class: 'small muted', style: { margin: 0 } },
          'No offline submissions have been recorded. Students working without a connection save results locally; when they reconnect, each result is recorded here with its final status.')));

  const systems = staffPanel('Centre state',
    el('div', { class: 'panel__body' },
      el('div', { class: 'kv' },
        kv('Database', 'SQLite, file based, migration-tracked'),
        kv('Certificates issued', String(counts.certificates)),
        kv('Game rounds played', String(counts.gameRounds)),
        kv('Average accuracy', `${counts.averageAccuracy30d}%`)),
      demoDataPresent
        ? el('div', { class: 'callout callout--warn', style: { marginTop: '14px' } },
          el('div', { style: { fontWeight: '600', marginBottom: '4px' } }, 'Demonstration data is present'),
          el('div', { class: 'small' }, 'This database still contains demo students and demo sessions. Remove it before using the system with real students.'),
          el('button', { class: 'btn btn--sm btn--danger', style: { marginTop: '10px' }, onclick: purgeDemo }, 'Remove all demo data'))
        : el('div', { class: 'tiny muted', style: { marginTop: '12px' } }, 'No demonstration data in this database.')),
    [
      exportButton({ label: 'Users CSV', href: '/api/admin/export/users.csv' }),
      el('button', { class: 'btn btn--sm', onclick: () => navigate('/admin/backups') }, 'Backups'),
    ]);

  function purgeDemo() {
    confirmAction({
      title: 'Remove all demonstration data',
      message: 'Every user flagged as demo will be deleted along with their sessions, progress, game rounds and certificates. Real accounts are untouched. This cannot be undone — take a backup first.',
      confirmLabel: 'Delete demo data',
      danger: true,
      run: async () => {
        const { removed } = await api.del('/api/admin/demo-data');
        toast(`${removed} demo account${removed === 1 ? '' : 's'} removed.`, { type: 'ok' });
        location.reload();
      },
    });
  }

  const quickLinks = staffPanel('Administration',
    el('div', { class: 'panel__body' },
      el('div', { class: 'quick-grid' },
        quick('People', 'Create accounts, change roles, deactivate leavers.', 'users', '/admin/users'),
        quick('Classes', 'Every class in the centre and who teaches it.', 'grid', '/admin/classes'),
        quick('Settings', 'Grading policy, certificates, features, language.', 'settings', '/admin/settings'),
        quick('Audit log', 'Every privileged action with who, what and when.', 'shield', '/admin/audit'),
        quick('Backups', 'Create a consistent database copy and download it.', 'database', '/admin/backups'))));

  const node = el('div', {},
    pageHead('Administration', 'Centre overview',
      'Everything in one place: who is enrolled, how the centre is typing, and the systems that keep it running.'),
    kpis,
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.5fr) minmax(0, 1fr)', gap: '20px', marginBottom: '20px' } },
      activity, systems),
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: '20px', marginBottom: '20px' } },
      levelPanel, classPanel),
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: '20px' } },
      syncPanel, quickLinks));


  return {
    node,
    header: {
      title: 'Admin',
      crumbs: [{ label: 'Administration' }],
      actions: [exportButton({ label: 'Export users', href: '/api/admin/export/users.csv' })],
    },
  };
}

function kv(label, value) {
  return el('div', { class: 'kv__row' }, el('span', { class: 'kv__key' }, label), el('span', { class: 'kv__value' }, String(value)));
}

function quick(title, body, iconName, href) {
  return el('a', { class: 'quick-link', href: `#${href}` },
    el('div', { class: 'quick-link__icon' }, icon(iconName, 17)),
    el('div', {}, el('div', { class: 'quick-link__title' }, title), el('div', { class: 'tiny muted' }, body)));
}
