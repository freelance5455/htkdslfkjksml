import { api } from '../api.js';
import { el, icon, toast, statTile, relTime, fmtMinutes } from '../ui.js';
import { navigate } from '../router.js';
import { pageHead, staffPanel, dataTable, formDialog, confirmAction, badge, exportButton } from './_staff.js';

export default async function adminClassesView() {
  const { classes } = await api.get('/api/instructor/classes');

  const enrolled = classes.reduce((sum, c) => sum + (c.students ?? 0), 0);
  const active = classes.filter((c) => c.is_active).length;

  const kpis = el('div', { class: 'stats', style: { gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: '20px' } },
    statTile({ label: 'Classes', value: classes.length }),
    statTile({ label: 'Active', value: active }),
    statTile({ label: 'Enrolments', value: enrolled }),
    statTile({ label: 'Average class size', value: classes.length ? Math.round((enrolled / classes.length) * 10) / 10 : 0 }));

  function edit(cls) {
    formDialog({
      title: cls ? `Edit ${cls.name}` : 'New class',
      fields: [
        { name: 'name', label: 'Class name', required: true, value: cls?.name ?? '' },
        { name: 'code', label: 'Class code', required: !cls, value: cls?.code ?? '', hint: cls ? 'Codes are fixed after creation so exports stay stable.' : 'Letters, digits, dashes.' },
        { name: 'description', label: 'Description', type: 'textarea', rows: 3, value: cls?.description ?? '' },
        ...(cls ? [{ name: 'isActive', label: 'Class is active', type: 'checkbox', value: Boolean(cls.is_active) }] : []),
      ],
      onSubmit: async (values, close) => {
        if (cls) {
          await api.patch(`/api/instructor/classes/${cls.id}`, values);
          close();
          toast('Class updated.', { type: 'ok' });
        } else {
          await api.post('/api/instructor/classes', values);
          close();
          toast('Class created.', { type: 'ok' });
        }
        location.reload();
      },
    });
  }

  const list = staffPanel('All classes',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: classes,
        empty: 'No classes exist yet.',
        onRowClick: (row) => navigate(`/instructor/classes/${row.id}`),
        columns: [
          { label: 'Class', render: (c) => el('div', {}, el('div', { style: { fontWeight: '600' } }, c.name), el('div', { class: 'tiny muted' }, c.description || '—')) },
          { label: 'Code', render: (c) => el('code', { class: 'tiny' }, c.code) },
          { label: 'Instructor', render: (c) => c.instructor_name ?? '—' },
          { label: 'Students', align: 'right', render: (c) => String(c.students ?? 0) },
          { label: 'Status', render: (c) => (c.is_active ? badge('active', 'ok') : badge('archived')) },
          {
            label: '', align: 'right',
            render: (c) => el('div', { style: { display: 'flex', gap: '6px', justifyContent: 'flex-end' } },
              el('a', { class: 'btn btn--sm btn--ghost', href: `/api/instructor/classes/${c.id}/export.csv`, download: '' }, 'CSV'),
              el('button', { class: 'btn btn--sm', onclick: () => edit(c) }, 'Edit')),
          },
        ],
      })),
    [el('button', { class: 'btn btn--sm btn--primary', onclick: () => edit(null) }, icon('plus', 13), 'New class')]);

  const policy = staffPanel('Access rules for classes',
    el('div', { class: 'panel__body' },
      el('div', { class: 'kv' },
        kv('Instructors see', 'Only classes they own or co-teach, and only students enrolled in those classes.'),
        kv('Students see', 'Only their own sessions, statistics and certificates. The API rejects everything else with 403, not an empty list.'),
        kv('Administrators see', 'Everything, and every privileged action is written to the audit log with the actor.'),
        kv('Exports', 'CSV only from classes the instructor can access; student records leave the building only through an authorised export.'))));

  const node = el('div', {},
    pageHead('Administration', 'Classes and enrolment',
      'Classes group students for assignment, reporting and certificates. Open any class to add students and export its results.'),
    kpis,
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.7fr) minmax(0, 1fr)', gap: '20px' } },
      list, policy));


  return {
    node,
    header: {
      title: 'Classes',
      crumbs: [{ label: 'Administration', href: '#/admin' }, { label: 'Classes' }],
    },
  };
}

function kv(label, value) {
  return el('div', { class: 'kv__row', style: { alignItems: 'start' } },
    el('span', { class: 'kv__key', style: { width: '130px', flex: 'none' } }, label),
    el('span', { class: 'kv__value small muted', style: { fontFamily: 'var(--font-ui)', fontWeight: '400' } }, value));
}
