import { api } from '../api.js';
import { el, icon, lineChart, statTile, emptyState, fmtMinutes, relTime, fmtDate, dialog, toast } from '../ui.js';
import { navigate } from '../router.js';

export default async function progressView({ query }) {
  const range = Number(query.days) || 30;
  const [dashboard, keyData, history, achievements, adaptive, certs] = await Promise.all([
    api.get('/api/me/dashboard'),
    api.get('/api/me/key-stats'),
    api.get(`/api/me/history?days=${range}`),
    api.get('/api/me/achievements'),
    api.get('/api/me/adaptive'),
    api.get('/api/certificates').catch(() => ({ certificates: [] })),
  ]);

  const stats = dashboard.stats;
  const earned = achievements.achievements.filter((a) => a.earned);
  const pending = achievements.achievements.filter((a) => !a.earned);

  // --------------------------------------------------------------- headline
  const headline = el('div', { class: 'stats', style: { gridTemplateColumns: 'repeat(6, 1fr)' } },
    statTile({ label: 'Best net WPM', value: stats.bestWpm, hint: 'verified sessions' }),
    statTile({ label: 'Recent average', value: stats.currentWpm, hint: 'last five sessions' }),
    statTile({ label: 'Average accuracy', value: `${Math.round(stats.averageAccuracy)}%` }),
    statTile({ label: 'Practice time', value: fmtMinutes(stats.totalPracticeMs) }),
    statTile({ label: 'Sessions', value: stats.totalSessions, hint: `${stats.gamesPlayed} game rounds` }),
    statTile({ label: 'Streak', value: stats.streak, hint: stats.streak === 1 ? 'day' : 'days' }));

  // ----------------------------------------------------------------- charts
  const chartData = history.history.map((row) => ({
    label: row.day.slice(5),
    value: row.avg_wpm,
    best: row.best_wpm,
    accuracy: row.avg_accuracy,
    minutes: Math.round((row.practice_ms ?? 0) / 60000),
  }));

  const wpmChart = el('div', {}, chartData.length
    ? lineChart({ data: chartData, height: 210, valueKey: 'value', labelKey: 'label', unit: ' WPM', target: null })
    : emptyState({
      title: 'No sessions in this period',
      message: 'Once you complete a lesson or practice round, your daily speed and accuracy appear here.',
      action: el('button', { class: 'btn btn--primary', onclick: () => navigate('/practice') }, 'Start practising'),
    }));

  const accChart = el('div', {}, chartData.length
    ? lineChart({ data: chartData, height: 150, valueKey: 'accuracy', labelKey: 'label', unit: '%', target: 95 })
    : el('div', { class: 'empty empty--inline' }, el('p', {}, 'Accuracy history needs at least one session.')));

  const practiceChart = el('div', {}, chartData.length
    ? lineChart({ data: chartData, height: 150, valueKey: 'minutes', labelKey: 'label', unit: ' min' })
    : el('div', { class: 'empty empty--inline' }, el('p', {}, 'Practice minutes appear here after your first session.')));

  const rangeChips = el('div', { class: 'chip-grid' }, [30, 90, 180, 365].map((d) => el('button', {
    class: 'chip',
    'aria-pressed': d === range ? 'true' : 'false',
    onclick: () => navigate(`/progress?days=${d}`),
  }, d === 365 ? 'A year' : `${d} days`)));

  // ------------------------------------------------------------- key table
  const keys = keyData.keys.slice(0, 26);
  const keyTable = keys.length
    ? el('div', { class: 'table-wrap' }, el('table', { class: 'data' },
      el('thead', {}, el('tr', {},
        el('th', {}, 'Key'), el('th', { class: 'num' }, 'Presses'), el('th', { class: 'num' }, 'Errors'),
        el('th', { class: 'num' }, 'Error rate'), el('th', { class: 'num' }, 'Avg gap'))),
      el('tbody', {}, keys.map((k) => el('tr', {},
        el('td', {}, el('code', { class: 'keycap' }, k.key === ' ' ? 'space' : k.key)),
        el('td', { class: 'num' }, String(k.attempts)),
        el('td', { class: 'num' }, String(k.errors)),
        el('td', { class: 'num' }, el('span', {
          class: `badge ${k.errorRate >= 8 ? 'badge--danger' : k.errorRate >= 4 ? 'badge--warn' : 'badge--ok'}`,
        }, `${k.errorRate}%`)),
        el('td', { class: 'num muted' }, k.avgIntervalMs ? `${k.avgIntervalMs} ms` : '—'))))))
    : el('div', { class: 'empty empty--inline' }, el('p', {}, 'No per-key data yet. It is collected from every session automatically.'));

  const weakList = keyData.weakKeys?.length
    ? el('div', { class: 'chip-grid' }, keyData.weakKeys.slice(0, 8).map((k) => el('span', { class: 'chip chip--static' },
      el('code', { class: 'keycap' }, k.key === ' ' ? 'space' : k.key),
      el('span', { class: 'tiny muted' }, `${k.errorRate}% error`))))
    : el('p', { class: 'small muted' }, 'No weak keys identified yet — that usually means fewer than twenty sessions so far.');

  // ---------------------------------------------------------- achievements
  const achGrid = el('div', { class: 'badge-grid' },
    achievements.achievements.map((a) => el('div', { class: `achievement${a.earned ? ' achievement--earned' : ''}` },
      el('div', { class: 'achievement__icon' }, icon(a.earned ? 'award' : 'lock', 18)),
      el('div', {},
        el('div', { class: 'achievement__name' }, a.name),
        el('div', { class: 'tiny muted' }, a.description),
        a.earned
          ? el('div', { class: 'tiny', style: { color: 'var(--ok)', marginTop: '2px' } }, `Earned ${fmtDate(a.earnedAt)}`)
          : null))));

  // ---------------------------------------------------------- certificates
  const certRows = certs.certificates ?? [];
  const certificatePanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' },
      el('h3', {}, 'Certificates'),
      el('span', { class: 'tiny muted' }, certRows.length ? `${certRows.length} issued` : 'none yet')),
    el('div', { class: 'panel__body' },
      certRows.length === 0
        ? el('div', {},
          el('p', { class: 'small muted', style: { marginTop: 0 } },
            'A BICA certificate is issued when you meet the centre\u2019s criteria: a minimum level mastered, a minimum number of lessons and a verified speed and accuracy. When you qualify, your instructor can issue it and you can download the PDF here.'),
          el('div', { class: 'tiny muted' },
            `Current criteria: level ${dashboard.curriculum.activeLevel} of 6 reached, ${dashboard.curriculum.masteredCount} lessons mastered, best verified ${stats.bestWpm} WPM at ${Math.round(stats.averageAccuracy)}% accuracy.`))
        : el('div', {}, certRows.map((c) => el('div', { class: 'cert-row' },
          el('div', {},
            el('div', { style: { fontWeight: '600' } }, c.course_title || 'Typing proficiency'),
            el('div', { class: 'tiny muted' }, `${c.certificate_no} · ${c.course_title} · issued ${fmtDate(c.issued_at)} · ${c.best_wpm} WPM, ${Math.round(c.best_accuracy)}% accuracy`)),
          el('div', { style: { display: 'flex', gap: '8px' } },
            el('button', { class: 'btn btn--sm', onclick: () => downloadCert(c) }, icon('download', 13), 'PDF'),
            el('a', { class: 'btn btn--sm btn--ghost', href: `#/verify/${c.certificate_no}`, target: '_blank', rel: 'noopener' }, 'Verify')))))));

  async function downloadCert(cert) {
    const no = cert.certificate_no;
    try {
      const res = await fetch(`/api/certificates/${encodeURIComponent(no)}/pdf`, { credentials: 'include' });
      if (!res.ok) throw new Error('The certificate PDF could not be downloaded.');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = el('a', { href: url, download: `${no}.pdf` });
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    } catch (err) {
      toast(err.message, { type: 'error' });
    }
  }

  // ---------------------------------------------------------------- sessions
  const sessionRows = el('div', {});
  const loadSessions = async () => {
    sessionRows.replaceChildren(el('div', { class: 'small muted' }, 'Loading sessions…'));
    try {
      const { sessions } = await api.get('/api/me/sessions?limit=40');
      if (!sessions.length) {
        sessionRows.replaceChildren(el('div', { class: 'empty empty--inline' }, el('p', {}, 'No sessions recorded yet.')));
        return;
      }
      sessionRows.replaceChildren(el('div', { class: 'table-wrap' }, el('table', { class: 'data' },
        el('thead', {}, el('tr', {},
          el('th', {}, 'When'), el('th', {}, 'What'), el('th', { class: 'num' }, 'Net WPM'),
          el('th', { class: 'num' }, 'Accuracy'), el('th', { class: 'num' }, 'Duration'), el('th', {}, 'Verified'))),
        el('tbody', {}, sessions.map((s) => el('tr', {},
          el('td', { class: 'muted' }, relTime(s.started_at)),
          el('td', {}, s.title || s.source),
          el('td', { class: 'num' }, String(Math.round(s.net_wpm))),
          el('td', { class: 'num' }, `${Math.round(s.accuracy)}%`),
          el('td', { class: 'num muted' }, fmtMinutes(s.duration_ms)),
          el('td', {}, s.verified
            ? el('span', { class: 'badge badge--ok' }, 'verified')
            : el('span', { class: 'badge badge--warn' }, 'unverified'))))))));
    } catch (err) {
      sessionRows.replaceChildren(el('div', { class: 'small', style: { color: 'var(--danger)' } }, err.message));
    }
  };
  loadSessions();

  function runRecommendation(rec) {
    const action = rec.action ?? {};
    if (action.kind === 'lesson' && action.lessonId) { navigate(`/learn/${action.lessonId}`); return; }
    if (action.kind === 'game' && action.gameId) { navigate('/arcade'); return; }
    if (action.preset) { navigate(`/practice?preset=${encodeURIComponent(action.preset)}`); return; }
    if (action.kind === 'practice') { navigate('/practice'); return; }
    if (action.kind === 'test') { navigate('/practice'); return; }
    toast('This suggestion is described above; it has no automatic start.', { type: 'info' });
  }

  const recItems = (adaptive.recommendations ?? []).slice(0, 3).map((rec) => el('div', { class: 'rec' },
    el('div', { style: { fontWeight: '600', color: 'var(--ink-800)' } }, rec.title),
    el('div', { class: 'tiny muted', style: { lineHeight: '1.5', marginTop: '2px' } }, rec.reason),
    el('button', { class: 'btn btn--sm', style: { marginTop: '6px' }, onclick: () => runRecommendation(rec) }, 'Open', icon('right', 12))));

  if (recItems.length === 0) {
    recItems.push(el('p', { class: 'small muted' },
      'No recommendations yet — the engine needs a few saved sessions before it will claim to know your patterns.'));
  }

  // ------------------------------------------------------------------ layout
  const insightPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'What the engine thinks needs work')),
    el('div', { class: 'panel__body' },
      el('p', { class: 'small', style: { marginTop: 0 } }, adaptive.diagnosis?.summary ?? 'Not enough data for a diagnosis yet.'),
      recItems,
      el('div', { class: 'tiny muted', style: { marginTop: '10px' } },
        `Based on ${adaptive.sessionsAnalysed ?? 0} saved sessions. The engine is deterministic: same data, same recommendation.`)));

  const speedPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Speed over time'), rangeChips),
    el('div', { class: 'panel__body' }, wpmChart));

  const topRow = el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.6fr) minmax(0, 1fr)', gap: '20px', marginTop: '22px' } },
    speedPanel, insightPanel);

  const accPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Accuracy over time'), el('span', { class: 'tiny muted' }, 'target line at 95%')),
    el('div', { class: 'panel__body' }, accChart));

  const minutesPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Daily practice minutes')),
    el('div', { class: 'panel__body' }, practiceChart));

  const chartRow = el('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginTop: '20px' } },
    accPanel, minutesPanel);

  const keysPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Per-key statistics'), el('span', { class: 'tiny muted' }, 'worst first')),
    el('div', { class: 'panel__body', style: { padding: 0 } }, keyTable));

  const weakPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Weak keys')),
    el('div', { class: 'panel__body' },
      weakList,
      el('p', { class: 'tiny muted', style: { marginBottom: 0 } },
        'A weak key has a measured error rate above your own average. A drill built from these keys is one click away.'),
      el('button', { class: 'btn btn--sm', style: { marginTop: '12px' }, onclick: () => navigate('/practice?preset=weak-keys') },
        icon('target', 13), 'Drill my weak keys')));

  const keyRow = el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.4fr) minmax(0, 1fr)', gap: '20px', marginTop: '20px' } },
    keysPanel, weakPanel);

  const achPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Achievements'),
      el('span', { class: 'tiny muted' }, `${earned.length} of ${achievements.achievements.length} earned`)),
    el('div', { class: 'panel__body' },
      achGrid,
      pending.length
        ? el('p', { class: 'tiny muted', style: { marginBottom: 0 } },
          `${pending.length} still locked. Locked achievements are earned by real, verified behaviour.`)
        : null));

  const certColumn = el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, certificatePanel);
  const achRow = el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.5fr) minmax(0, 1fr)', gap: '20px', marginTop: '20px' } },
    achPanel, certColumn);

  const historyPanel = el('div', { class: 'panel', style: { marginTop: '20px' } },
    el('div', { class: 'panel__head' },
      el('h3', {}, 'Session history'),
      el('button', { class: 'btn btn--sm btn--ghost', onclick: loadSessions }, icon('reload', 13), 'Refresh')),
    el('div', { class: 'panel__body', style: { padding: 0 } }, sessionRows));

  const pageHead = el('div', { style: { marginBottom: '18px' } },
    el('div', { class: 'eyebrow' }, 'Progress'),
    el('h1', {}, 'Your progress'),
    el('p', { class: 'lede' }, 'Everything here comes from sessions the server verified. Nothing is estimated or invented: if a number is empty, you have not produced it yet.'));

  const node = el('div', {}, pageHead, headline, topRow, chartRow, keyRow, achRow, historyPanel);

  return {
    node,
    header: {
      title: 'Progress',
      crumbs: [{ label: 'Progress' }],
      actions: [el('button', { class: 'btn btn--sm', onclick: () => navigate('/practice') }, icon('play', 13), 'Practise now')],
    },
  };
}

