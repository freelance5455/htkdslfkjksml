import { api } from '../api.js';
import { el, icon, toast, emptyState, fmtMs } from '../ui.js';
import { openTypingWorkspace } from '../typing.js';
import { navigate } from '../router.js';

export default async function practiceView({ query }) {
  const [{ presets, durations }, { tests }] = await Promise.all([
    api.get('/api/practice/presets'),
    api.get('/api/sessions/tests/available').catch(() => ({ tests: [] })),
  ]);

  const settings = {
    preset: query.preset && presets.some((p) => p.id === query.preset) ? query.preset : 'random-words',
    duration: Number(query.duration) || 60,
    wordCount: null,
    allowBackspace: true,
    showTimer: true,
    showLiveWpm: true,
    customText: '',
  };

  const statusLine = el('div', { class: 'small muted', style: { minHeight: '20px' } });

  // ------------------------------------------------------------ preset grid
  const groups = [...new Set(presets.map((p) => p.group))];
  const presetCards = groups.map((group) => el('div', { style: { marginBottom: '18px' } },
    el('div', { class: 'eyebrow' }, group),
    el('div', { class: 'chip-grid' }, presets.filter((p) => p.group === group).map((preset) => el('button', {
      class: 'chip',
      'aria-pressed': preset.id === settings.preset ? 'true' : 'false',
      title: preset.description,
      dataset: { preset: preset.id },
      onclick: (e) => {
        settings.preset = preset.id;
        for (const chip of document.querySelectorAll('[data-preset]')) chip.setAttribute('aria-pressed', 'false');
        e.currentTarget.setAttribute('aria-pressed', 'true');
        statusLine.textContent = preset.description;
        customWrap.classList.toggle('hidden', preset.id !== 'custom');
      },
    }, preset.label)))));

  const customWrap = el('div', { class: `field ${settings.preset === 'custom' ? '' : 'hidden'}` },
    el('label', { for: 'custom-text' }, 'Your own passage'),
    el('textarea', {
      class: 'textarea', id: 'custom-text', rows: '5', placeholder: 'Paste or type a passage (40–5000 characters). Use it for real work text, exam practice or a passage your instructor gave you.',
      oninput: (e) => { settings.customText = e.target.value; },
    }),
    el('div', { class: 'hint' }, 'Custom passages are measured exactly like everything else. Line breaks are converted to spaces.'));

  // ----------------------------------------------------------- mode switch
  const durationPicker = el('div', { class: 'chip-grid' }, durations.map((d) => el('button', {
    class: 'chip',
    'aria-pressed': d === settings.duration ? 'true' : 'false',
    dataset: { duration: String(d) },
    onclick: (e) => {
      settings.duration = d;
      settings.wordCount = null;
      for (const chip of document.querySelectorAll('[data-duration]')) chip.setAttribute('aria-pressed', 'false');
      e.currentTarget.setAttribute('aria-pressed', 'true');
      for (const chip of document.querySelectorAll('[data-words]')) chip.setAttribute('aria-pressed', 'false');
    },
  }, d >= 60 ? `${d / 60} min` : `${d} sec`)));

  const durationChips = durations.map((d) => el('button', {
    class: 'chip',
    'aria-pressed': d === settings.duration ? 'true' : 'false',
    dataset: { duration: String(d) },
    onclick: (e) => {
      settings.duration = d;
      settings.wordCount = null;
      for (const chip of document.querySelectorAll('[data-timed]')) chip.setAttribute('aria-pressed', 'false');
      e.currentTarget.setAttribute('aria-pressed', 'true');
      modeLabel.textContent = `timed · ${d >= 60 ? `${d / 60} min` : `${d} sec`}`;
    },
  }, d >= 60 ? `${d / 60} min` : `${d} sec`));

  const wordChips = [10, 25, 50, 100].map((n) => el('button', {
    class: 'chip',
    'aria-pressed': 'false',
    dataset: { timed: 'words' },
    onclick: (e) => {
      settings.wordCount = n;
      for (const chip of document.querySelectorAll('[data-timed]')) chip.setAttribute('aria-pressed', 'false');
      for (const chip of document.querySelectorAll('[data-duration]')) chip.setAttribute('aria-pressed', 'false');
      e.currentTarget.setAttribute('aria-pressed', 'true');
      modeLabel.textContent = `fixed · ${n} words`;
    },
  }, `${n} words`));

  const modeLabel = el('span', { class: 'badge badge--brand' }, `timed · ${settings.duration >= 60 ? `${settings.duration / 60} min` : `${settings.duration} sec`}`);

  // ------------------------------------------------------------- options
  const optionToggle = (label, hint, key) => el('label', { class: 'switch', style: { justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--line)' } },
    el('span', {}, el('div', { class: 'small', style: { fontWeight: '600' } }, label), el('div', { class: 'tiny muted' }, hint)),
    el('span', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
      el('input', {
        type: 'checkbox', checked: settings[key],
        onchange: (e) => { settings[key] = e.target.checked; },
      }),
      el('span', { class: 'switch__track' })));

  // ---------------------------------------------------------------- start
  const startBtn = el('button', { class: 'btn btn--primary btn--lg btn--block', onclick: start }, icon('play', 15), 'Start practice');

  async function start() {
    if (settings.preset === 'custom' && settings.customText.trim().length < 40) {
      toast('Your custom passage needs at least 40 characters.', { type: 'warn' });
      return;
    }
    startBtn.disabled = true;
    startBtn.textContent = 'Preparing…';
    try {
      const payload = {
        preset: settings.preset,
        allowBackspace: settings.allowBackspace,
        ...(settings.wordCount ? { wordCount: settings.wordCount } : { durationSec: settings.duration }),
        ...(settings.preset === 'custom' ? { customText: settings.customText } : {}),
      };
      const data = await api.post('/api/practice/generate', payload);
      openTypingWorkspace({
        text: data.text,
        mode: data.mode,
        durationSec: data.durationSec,
        tokenId: data.tokenId,
        source: 'practice',
        refId: data.preset,
        sessionTitle: data.presetLabel,
        meta: { preset: data.preset, wordCount: data.wordCount },
        onExit: reset,
        onComplete: () => reset(),
        onRetry: () => start(),
      });
      reset();
    } catch (err) {
      toast(err.message, { type: 'error' });
      reset();
    }
  }

  function reset() {
    startBtn.disabled = false;
    startBtn.replaceChildren(icon('play', 15), document.createTextNode('Start practice'));
  }

  // ------------------------------------------------------------ tests list
  const testsPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' },
      el('h3', {}, 'Typing tests set by your instructor'),
      el('span', { class: 'tiny muted' }, 'examination conditions')),
    tests.length === 0
      ? el('div', { class: 'panel__body' },
        el('p', { class: 'small muted', style: { margin: 0 } },
          'No tests have been published yet. Your instructor can create a timed test with its own passage and pass mark.'))
      : el('div', {}, tests.map((test) => el('div', {
        style: {
          display: 'grid', gridTemplateColumns: '1fr auto', gap: '14px', alignItems: 'center',
          padding: '12px 20px', borderBottom: '1px solid var(--line)',
        },
      },
      el('div', {},
        el('div', { style: { fontWeight: '600', fontSize: '14px' } }, test.title),
        el('div', { class: 'tiny muted' },
          `${fmtMs(test.durationMs)} · pass ${test.minAccuracy}% accuracy${test.minWpm > 0 ? ` and ${test.minWpm} WPM` : ''} · ${test.allowBackspace ? 'backspace allowed' : 'no backspace'}`)),
      el('button', { class: 'btn btn--sm', onclick: () => startTest(test.id) }, 'Start test')))));

  async function startTest(testId) {
    try {
      const data = await api.post(`/api/sessions/tests/${testId}/start`);
      openTypingWorkspace({
        text: data.text,
        mode: 'time',
        durationSec: data.durationSec,
        allowBackspace: data.allowBackspace,
        showTimer: data.showTimer,
        showLiveWpm: data.showLiveWpm,
        tokenId: data.tokenId,
        source: 'test',
        refId: String(testId),
        sessionTitle: data.title,
        passMark: data.passMark,
        examMode: true,
        meta: { testId },
        onExit: () => {},
        onComplete: () => {},
        onRetry: () => startTest(testId),
      });
    } catch (err) {
      toast(err.message, { type: 'error' });
    }
  }

  // ---------------------------------------------------------- analyser tool
  const analysisText = el('textarea', { class: 'textarea', rows: '4', placeholder: 'Paste the correct text…' });
  const analysisTyped = el('textarea', { class: 'textarea', rows: '4', placeholder: 'Paste what you typed…' });
  const analysisSeconds = el('input', { class: 'input', type: 'number', min: '5', max: '7200', value: '60', style: { maxWidth: '120px' } });
  const analysisResult = el('div', { style: { marginTop: '12px' } });

  const analyserPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Analyse typing done elsewhere'),
      el('span', { class: 'tiny muted' }, 'office work, an exam, a document')),
    el('div', { class: 'panel__body' },
      el('p', { class: 'small muted', style: { marginTop: 0 } },
        'Typed something in Word or a website and want a measurement? Paste the source text and your output. Nothing is saved to your record — this is a scratch analysis.'),
      el('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' } },
        analysisText, analysisTyped),
      el('div', { style: { display: 'flex', gap: '12px', alignItems: 'flex-end', marginTop: '12px' } },
        el('div', {},
          el('div', { class: 'label', style: { marginBottom: '4px' } }, 'Time taken (seconds)'),
          analysisSeconds),
        el('button', { class: 'btn', onclick: analyse }, 'Analyse')),
      analysisResult));

  async function analyse() {
    try {
      const { result } = await api.post('/api/practice/analyse', {
        text: analysisText.value,
        typed: analysisTyped.value,
        seconds: Number(analysisSeconds.value),
      });
      analysisResult.replaceChildren(el('div', { class: 'result__grid' },
        resultStat('Net WPM', result.netWpm),
        resultStat('Gross WPM', result.grossWpm),
        resultStat('Accuracy', `${result.accuracy}%`),
        resultStat('Characters', result.committedChars)));
    } catch (err) {
      toast(err.message, { type: 'error' });
    }
  }

  const layout = el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 340px', gap: '24px' } },
    el('div', {},
      el('div', { class: 'panel', style: { marginBottom: '20px' } },
        el('div', { class: 'panel__head' }, el('h3', {}, 'What to practise')),
        el('div', { class: 'panel__body' }, presetCards, customWrap, statusLine)),
      el('div', { style: { display: 'grid', gap: '20px' } }, testsPanel, analyserPanel)),
    el('aside', { style: { display: 'grid', gap: '18px', alignContent: 'start' } },
      el('div', { class: 'panel' },
        el('div', { class: 'panel__head' }, el('h3', {}, 'Session setup'), modeLabel),
        el('div', { class: 'panel__body' },
          el('div', { class: 'eyebrow' }, 'Timed'),
          el('div', { class: 'chip-grid', style: { marginBottom: '14px' } }, durationChips),
          el('div', { class: 'eyebrow' }, 'Fixed length'),
          el('div', { class: 'chip-grid', style: { marginBottom: '16px' } }, wordChips),
          optionToggle('Backspace allowed', 'Turn off for examination realism.', 'allowBackspace'),
          optionToggle('Show timer', 'Hide it to practise without clock pressure.', 'showTimer'),
          optionToggle('Show live speed', 'Hiding it keeps attention on accuracy.', 'showLiveWpm'),
          el('div', { style: { marginTop: '18px' } }, startBtn),
          el('p', { class: 'tiny muted', style: { marginTop: '12px', marginBottom: 0, lineHeight: '1.5' } },
            'Every practice result is measured by the same engine as lessons and saved to your history.'))),
      el('div', { class: 'panel' },
        el('div', { class: 'panel__head' }, el('h3', {}, 'How the numbers work')),
        el('div', { class: 'panel__body' },
          el('div', { class: 'small muted', style: { lineHeight: '1.6', fontFamily: 'var(--font-mono)', fontSize: '11.5px' } },
            el('div', {}, 'gross = (chars ÷ 5) ÷ minutes'),
            el('div', {}, 'net = gross − errors ÷ minutes'),
            el('div', {}, 'accuracy = correct ÷ all keys'),
            el('div', {}, 'consistency = 100 − variability'))))));

  if (!query.preset) statusLine.textContent = presets.find((p) => p.id === settings.preset)?.description ?? '';

  const node = el('div', {},
    el('div', { style: { marginBottom: '22px' } },
      el('div', { class: 'eyebrow' }, 'Practice'),
      el('h1', {}, 'Free practice'),
      el('p', { class: 'lede' }, 'Eighteen practice modes, from random words to office correspondence. Not tied to the course — pick what you actually need today.')),
    layout);

  if (query.preset === 'weak-keys') {
    toast('Weak-key mode uses the keys with your highest measured error rates.', { timeout: 6000 });
  }

  return {
    node,
    header: {
      title: 'Practice',
      crumbs: [{ label: 'Practice' }],
      actions: [el('button', { class: 'btn btn--sm btn--primary', onclick: start }, icon('play', 13), 'Start now')],
    },
  };
}

function resultStat(label, value) {
  return el('div', { class: 'result__stat' }, el('b', {}, String(value)), el('span', {}, label));
}
