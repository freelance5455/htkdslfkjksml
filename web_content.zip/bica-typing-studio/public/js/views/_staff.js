/**
 * Shared building blocks for the instructor and admin portals.
 * Not a route — imported by the staff views.
 */
import { el, icon, dialog, toast } from '../ui.js';

export function pageHead(eyebrow, title, lede) {
  return el('div', { style: { marginBottom: '18px' } },
    el('div', { class: 'eyebrow' }, eyebrow),
    el('h1', {}, title),
    lede ? el('p', { class: 'lede' }, lede) : null);
}

export function staffPanel(title, body, actions = []) {
  return el('div', { class: 'panel' },
    el('div', { class: 'panel__head' },
      el('h3', {}, title),
      actions.length ? el('div', { style: { display: 'flex', gap: '8px' } }, actions) : null),
    body);
}

export function kpiRow(tiles) {
  return el('div', { class: 'stats', style: { gridTemplateColumns: `repeat(${Math.min(tiles.length, 5)}, 1fr)`, marginBottom: '20px' } }, tiles);
}

/**
 * @param {{columns:Array<{label:string,align?:string,render:(row)=>any}>, rows:Array, empty?:string, onRowClick?:Function}} opts
 */
export function dataTable({ columns, rows, empty = 'Nothing here yet.', onRowClick = null, rowKey = (r) => r.id }) {
  if (!rows.length) {
    return el('div', { class: 'empty', style: { padding: '30px 20px' } }, el('p', { style: { margin: 0 } }, empty));
  }
  return el('div', { class: 'table-wrap' },
    el('table', { class: 'data' },
      el('thead', {}, el('tr', {}, columns.map((c) => el('th', { class: c.align === 'right' ? 'num' : '' }, c.label)))),
      el('tbody', {}, rows.map((row) => el('tr', {
        dataset: { key: String(rowKey(row)) },
        class: onRowClick ? 'is-clickable' : '',
        onclick: onRowClick ? (event) => { if (!event.target.closest('button, a, input, select')) onRowClick(row); } : null,
      }, columns.map((c) => el('td', { class: c.align === 'right' ? 'num' : '' }, c.render(row))))))));
}

export function field(label, input, hint = null) {
  return el('div', { class: 'field' },
    el('label', {}, label),
    input,
    hint ? el('div', { class: 'hint' }, hint) : null);
}

export function kvList(pairs) {
  return el('div', { class: 'kv' }, pairs.filter(Boolean).map(([label, value]) =>
    el('div', { class: 'kv__row' }, el('span', { class: 'kv__key' }, label), el('span', { class: 'kv__value' }, String(value ?? '—')))));
}

export function badge(text, tone = '') {
  return el('span', { class: `badge ${tone ? `badge--${tone}` : ''}` }, text);
}

/**
 * Small controlled form inside a dialog.
 * fields: [{name, label, type, value, options, hint, required, min, max, rows}]
 */
export function formDialog({ title, intro = null, fields, submitLabel = 'Save', onSubmit, wide = false }) {
  const inputs = new Map();
  const errorHost = el('div', { class: 'small', style: { color: 'var(--danger)', minHeight: '18px' } });

  const body = el('div', {},
    intro ? el('p', { class: 'small muted', style: { marginTop: 0 } }, intro) : null,
    fields.map((spec) => {
      let input;
      if (spec.type === 'select') {
        input = el('select', { class: 'select' },
          (spec.options ?? []).map((opt) => el('option', { value: opt.value, selected: String(opt.value) === String(spec.value) }, opt.label)));
      } else if (spec.type === 'textarea') {
        input = el('textarea', { class: 'textarea', rows: String(spec.rows ?? 5), placeholder: spec.placeholder ?? '' }, spec.value ?? '');
      } else if (spec.type === 'checkbox') {
        input = el('input', { type: 'checkbox', checked: Boolean(spec.value) });
      } else {
        input = el('input', {
          class: 'input',
          type: spec.type ?? 'text',
          value: spec.value ?? '',
          min: spec.min != null ? String(spec.min) : undefined,
          max: spec.max != null ? String(spec.max) : undefined,
          step: spec.step != null ? String(spec.step) : undefined,
          placeholder: spec.placeholder ?? '',
          autocomplete: 'off',
        });
      }
      inputs.set(spec.name, { spec, input });
      return field(spec.label, input, spec.hint);
    }),
    errorHost);

  const dlg = dialog({
    title,
    body,
    wide,
    actions: [
      { label: 'Cancel' },
      {
        label: submitLabel,
        variant: 'primary',
        onClick: async (close) => {
          const values = {};
          for (const [name, { spec, input }] of inputs) {
            if (spec.type === 'checkbox') values[name] = input.checked;
            else if (spec.type === 'number') values[name] = input.value === '' ? null : Number(input.value);
            else values[name] = input.value;
            if (spec.required && (values[name] === '' || values[name] == null)) {
              errorHost.textContent = `${spec.label} is required.`;
              input.focus();
              return;
            }
          }
          try {
            await onSubmit(values, close);
          } catch (err) {
            errorHost.textContent = err.message ?? 'That did not work.';
          }
        },
      },
    ],
  });
  return dlg;
}

export function confirmAction({ title, message, confirmLabel = 'Confirm', danger = false, run }) {
  const dlg = dialog({
    title,
    body: el('p', { class: 'small' }, message),
    actions: [
      { label: 'Cancel' },
      {
        label: confirmLabel,
        variant: danger ? 'danger' : 'primary',
        onClick: async (close) => {
          try {
            await run();
            close();
          } catch (err) {
            toast(err.message, { type: 'error' });
          }
        },
      },
    ],
  });
  return dlg;
}

export function exportButton({ label, href }) {
  return el('a', { class: 'btn btn--sm', href, download: '' }, icon('download', 13), label);
}

export function subtitle(text) {
  return el('div', { class: 'small muted', style: { marginBottom: '10px' } }, text);
}
