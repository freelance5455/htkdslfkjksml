import { api } from '../api.js';
import { el, icon, fmtDate, toast } from '../ui.js';

/**
 * Public certificate verification. Renders outside the application shell so a
 * third party (an employer, for example) can check a certificate without an
 * account.
 */
export default async function verifyView({ params = {} } = {}) {
  const numberInput = el('input', {
    class: 'input', placeHolder: undefined, placeholder: 'BICA-2026-00001',
    value: params.cert ?? '', spellcheck: 'false', autocomplete: 'off',
    style: { fontFamily: 'var(--font-mono)', textTransform: 'uppercase' },
  });
  const codeInput = el('input', {
    class: 'input', placeholder: 'XXXX-XXXX-XXXX (optional)',
    spellcheck: 'false', autocomplete: 'off',
    style: { fontFamily: 'var(--font-mono)', textTransform: 'uppercase' },
  });
  const result = el('div', { class: 'verify__result' });

  async function check(certNo = numberInput.value.trim(), code = codeInput.value.trim()) {
    if (!certNo) { toast('Enter the certificate number printed on the document.', { type: 'warn' }); return; }
    result.replaceChildren(el('div', { class: 'small muted' }, 'Checking with the centre register…'));
    try {
      const url = `/api/public/verify/${encodeURIComponent(certNo)}${code ? `?code=${encodeURIComponent(code)}` : ''}`;
      const data = await api.get(url);
      render(data, certNo, code);
      if (location.hash.split('/')[2] !== certNo) {
        history.replaceState(null, '', `#/verify/${encodeURIComponent(certNo)}`);
      }
    } catch (err) {
      if (err.status === 404) {
        result.replaceChildren(message('not_found', 'No certificate with that number', 'The register has no record of that certificate number. Check the number printed on the document — it looks like BICA-2026-00001.'));
      } else {
        result.replaceChildren(message('error', 'Could not check right now', err.message || 'The verification service did not answer. Try again in a moment.'));
      }
    }
  }

  function render(data, certNo, code) {
    const cert = data.certificate;
    if (!data.valid) {
      const reason = data.reason === 'revoked'
        ? 'This certificate was issued but has since been revoked by the centre.'
        : data.reason === 'code_mismatch'
          ? 'The certificate number exists, but the verification code does not match it.'
          : 'This certificate is not valid.';
      result.replaceChildren(el('div', { class: 'verify__card verify__card--bad' },
        el('div', { class: 'verify__badge' }, icon('x', 22)),
        el('h2', {}, 'Not valid'),
        el('p', {}, reason),
        certRow('Certificate', cert.number),
        certRow('Holder', cert.holder),
        certRow('Course', cert.course)));
      return;
    }
    result.replaceChildren(el('div', { class: 'verify__card verify__card--ok' },
      el('div', { class: 'verify__badge' }, icon('check', 22)),
      el('h2', {}, 'Valid certificate'),
      el('p', { class: 'muted small' }, 'Issued by BICA Computer Training Centre and confirmed against the centre register.'),
      el('div', { class: 'kv', style: { marginTop: '14px' } },
        certRow('Certificate number', cert.number),
        certRow('Holder', cert.holder),
        certRow('Course', cert.course),
        certRow('Best verified speed', `${cert.bestWpm} WPM`),
        certRow('Accuracy at issue', `${Math.round(cert.bestAccuracy)}%`),
        certRow('Issued', fmtDate(cert.issuedAt))),
      !code
        ? el('p', { class: 'tiny', style: { color: 'var(--warn)', marginTop: '12px' } },
          'Checked by number only. Add the verification code printed on the certificate to bind this result to the physical document.')
        : null,
      el('div', { class: 'callout', style: { marginTop: '16px' } },
        data.notice ?? 'Internal certificate of BICA Computer Training Centre. Not an externally accredited qualification.')));
  }

  function message(kind, title, body) {
    return el('div', { class: `verify__card verify__card--${kind === 'not_found' ? 'bad' : 'neutral'}` },
      el('div', { class: 'verify__badge' }, icon(kind === 'not_found' ? 'search' : 'alert', 22)),
      el('h2', {}, title),
      el('p', { class: 'small muted' }, body));
  }

  const form = el('form', {
    class: 'verify__form',
    onsubmit: (e) => { e.preventDefault(); check(); },
  },
  el('div', { class: 'field' }, el('label', { for: 'cert-no' }, 'Certificate number'), numberInput),
  el('div', { class: 'field' }, el('label', { for: 'cert-code' }, 'Verification code'), codeInput),
  el('button', { class: 'btn btn--primary btn--block', type: 'submit' }, icon('shield', 14), 'Verify certificate'));

  const node = el('div', { class: 'verify' },
    el('header', { class: 'verify__head' },
      el('div', {},
        el('div', { class: 'verify__brand' }, 'BICA'),
        el('div', { class: 'verify__brand-sub' }, 'Computer Training Centre')),
      el('a', { class: 'btn btn--sm btn--ghost', href: '#/login' }, 'Staff and student sign in')),
    el('main', { class: 'verify__main' },
      el('div', { class: 'verify__intro' },
        el('h1', {}, 'Certificate verification'),
        el('p', { class: 'lede' },
          'Enter the number printed on a BICA certificate to confirm it was issued by this centre. Verification is public and requires no account.'),
        el('div', { class: 'callout', style: { marginTop: '18px' } },
          el('strong', {}, 'What this proves. '),
          'That the centre issued this certificate to the named holder with these measured results. BICA certificates are internal records of training completed here; they are not an externally accredited qualification and should not be read as one.'),
        el('p', { class: 'tiny muted', style: { marginTop: '18px' } },
          'No password, student identifier or contact detail is exposed by this page.')),
      el('div', { class: 'verify__panel' }, form, result)));

  if (params.cert) check(params.cert);
  setTimeout(() => { if (!params.cert) numberInput.focus(); }, 40);

  return node;
}

function certRow(label, value) {
  return el('div', { class: 'kv__row' },
    el('span', { class: 'kv__key' }, label),
    el('span', { class: 'kv__value' }, String(value ?? '—')));
}
