import { api } from '../api.js';
import { el, icon, toast, dialog, emptyState, statTile } from '../ui.js';
import { openGame } from '../games/shell.js';
import { loadGame, hasModule } from '../games/registry.js';
import { navigate } from '../router.js';

export default async function arcadeView({ query = {} } = {}) {
  const data = await api.get('/api/games');
  const { games, difficulties, arcadeEnabled } = data;

  if (!arcadeEnabled) {
    return {
      node: el('div', {}, el('div', { class: 'panel' }, el('div', { class: 'panel__body' },
        emptyState({
          title: 'The arcade is switched off',
          message: 'Your centre has disabled typing games for now. Practice and lessons are still available.',
          iconName: 'lock',
          action: el('button', { class: 'btn btn--primary', onclick: () => navigate('/practice') }, 'Go to practice'),
        })))),
      header: { title: 'Arcade', crumbs: [{ label: 'Arcade' }] },
    };
  }

  const totalPlays = games.reduce((sum, g) => sum + (g.personal?.plays ?? 0), 0);
  const bestScores = games.map((g) => g.personal?.bestScore ?? 0);
  const topScore = Math.max(0, ...bestScores);
  const played = games.filter((g) => (g.personal?.plays ?? 0) > 0).length;

  const grid = el('div', { class: 'game-grid' });

  games.forEach((game) => {
    const personal = game.personal ?? {};
    const locked = !game.enabled || !hasModule(game.id);
    const card = el('article', { class: `game-card${locked ? ' game-card--disabled' : ''}` },
      el('div', { class: 'game-card__body' },
        el('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' } },
          el('span', { class: 'badge' }, game.category),
          el('span', { class: 'tiny muted' }, `${game.durationSec}s`)),
        el('div', { class: 'game-card__title' }, game.title),
        el('div', { class: 'game-card__tagline' }, game.tagline),
        el('div', { class: 'tiny muted', style: { marginTop: 'auto', paddingTop: '8px' } },
          personal.plays
            ? `${personal.plays} play${personal.plays === 1 ? '' : 's'} · best ${personal.bestScore} · ${Math.round(personal.bestAccuracy ?? 0)}% best accuracy`
            : 'Not played yet')),
      el('div', { class: 'game-card__foot' },
        locked
          ? el('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '6px' } }, icon('lock', 12), game.enabled ? 'Module unavailable' : 'Disabled by your instructor')
          : el('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '6px' } }, icon('play', 12), personal.plays ? 'Play again' : 'Play')));

    if (!locked) {
      // the whole card opens the game, not just the button
      card.style.cursor = 'pointer';
      card.addEventListener('click', (event) => {
        if (event.target.closest('button')) return;
        openSetup(game);
      });
    }
    grid.appendChild(card);
  });

  function openSetup(game) {
    const choice = { difficulty: game.personal?.plays ? (localStorage.getItem(`bica.difficulty.${game.id}`) ?? 'normal') : 'normal' };
    const diffRow = el('div', { class: 'diff-row' }, difficulties.map((d) => el('button', {
      class: 'diff-card',
      'aria-pressed': d.id === choice.difficulty ? 'true' : 'false',
      onclick: (e) => {
        choice.difficulty = d.id;
        for (const b of diffRow.querySelectorAll('.diff-card')) b.setAttribute('aria-pressed', 'false');
        e.currentTarget.setAttribute('aria-pressed', 'true');
      },
    },
    el('strong', {}, d.label),
    el('span', { class: 'tiny muted' }, d.blurb),
    el('span', { class: 'tiny', style: { color: 'var(--accent)' } }, `score ×${d.factor}`))));

    const body = el('div', {},
      el('p', { class: 'muted', style: { marginTop: 0 } }, game.mechanic),
      el('div', { class: 'callout' },
        el('strong', {}, 'Learning objective. '), game.objective),
      el('div', { class: 'small muted', style: { margin: '10px 0 6px' } },
        `Keys used: ${game.keysHint}. Round length: ${game.durationSec} seconds. Your score is base points × accuracy² × difficulty, so a fast but sloppy round scores less than a careful one.`),
      el('div', { class: 'eyebrow', style: { marginTop: '16px' } }, 'Difficulty'),
      diffRow);

    const dlg = dialog({
      title: game.title,
      body,
      wide: true,
      actions: [
        { label: 'Cancel' },
        { label: 'Start round', variant: 'primary', onClick: () => startRound() },
      ],
    });

    async function startRound() {
      try {
        localStorage.setItem(`bica.difficulty.${game.id}`, choice.difficulty);
        const { tokenId } = await api.post('/api/games/start', { gameId: game.id, difficulty: choice.difficulty });
        const plugin = await loadGame(game.id);
        dlg.close();
        openGame({
          game: { ...game, create: plugin.create },
          difficulty: choice.difficulty,
          tokenId,
          onExit: () => refresh(),
          onReplay: () => openSetup(game),
        });
      } catch (err) {
        toast(err.message, { type: 'error' });
      }
    }
  }

  async function refresh() {
    try {
      const fresh = await api.get('/api/games');
      const host = grid.parentElement;
      const again = await arcadeView();
      host?.replaceWith(again.node);
    } catch {
      /* leave the current view in place */
    }
  }

  const summary = el('div', { class: 'stats', style: { gridTemplateColumns: 'repeat(4, 1fr)' } },
    statTile({ label: 'Rounds played', value: totalPlays }),
    statTile({ label: 'Games tried', value: played, hint: `of ${games.length} available` }),
    statTile({ label: 'Best score', value: topScore }),
    statTile({ label: 'Arcade', value: arcadeEnabled ? 'Open' : 'Closed' }));

  const node = el('div', {},
    el('div', { style: { marginBottom: '20px' } },
      el('div', { class: 'eyebrow' }, 'Arcade'),
      el('h1', {}, 'Typing games'),
      el('p', { class: 'lede' }, 'Twelve games, one shared keyboard and one scoring rule. Every round is measured keystroke by keystroke and saved to your record, so the arcade counts towards your practice time and weak-key analysis.')),
    summary,
    grid,
    el('div', { class: 'panel', style: { marginTop: '26px' } },
      el('div', { class: 'panel__body' },
        el('div', { class: 'small muted', style: { lineHeight: '1.6' } },
          el('strong', {}, 'Which game should I play? '),
          'Short on time: Falling Letters or Rhythm Keys train instant key recognition. Words feel slow: Bubble Pop and Typing Bakery. Accuracy is the weak point: Word Guardian, Word Orbit and Word Builder. Numbers and symbols: Station Master and Code Sprint. Endurance: Typing Expedition and Speed Circuit.'))));

  // Deep link: the dashboard, the adaptive engine and the challenge board all
  // send players to `#/arcade?game=<id>`. Open that game's setup sheet once the
  // view is actually in the document.
  const wanted = typeof query.game === 'string' ? games.find((g) => g.id === query.game) : null;
  if (wanted && wanted.enabled && hasModule(wanted.id)) {
    setTimeout(() => {
      if (document.body.contains(node)) openSetup(wanted);
    }, 0);
  }

  return {
    node,
    header: {
      title: 'Arcade',
      crumbs: [{ label: 'Arcade' }],
      actions: [el('button', { class: 'btn btn--sm', onclick: () => navigate('/progress') }, icon('chart', 13), 'My game history')],
    },
  };
}
