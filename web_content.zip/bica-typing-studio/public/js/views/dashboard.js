import { api } from '../api.js';
import {
  el, icon, mount, statTile, meter, emptyState, fmtMinutes, relTime, lineChart, pct,
} from '../ui.js';
import { navigate } from '../router.js';

export default async function dashboardView() {
  const data = await api.get('/api/me/dashboard');
  const { stats, curriculum, today, recommendations, diagnosis, recentActivity, prediction, weakKeys } = data;

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  // ---------------------------------------------------------------- hero
  const lesson = curriculum.currentLesson;
  const hero = el('div', {
    class: 'panel', style: { padding: '0', overflow: 'hidden', marginBottom: '20px' },
  },
  el('div', { style: { display: 'grid', gridTemplateColumns: '1fr 260px', gap: '0' } },
    el('div', { style: { padding: '24px 26px' } },
      el('div', { class: 'eyebrow' }, `${curriculum.activeLevel !== null ? `Level ${curriculum.activeLevel}` : 'Course'} · ${curriculum.masteredCount} of ${curriculum.totalLessons} lessons mastered`),
      el('h1', { style: { fontSize: '26px', marginBottom: '6px' } },
        lesson ? lesson.title : 'Curriculum complete'),
      lesson
        ? el('p', { class: 'lede', style: { fontSize: '14px', marginBottom: '16px' } }, lesson.objective)
        : el('p', { class: 'lede', style: { fontSize: '14px', marginBottom: '16px' } },
          'Every lesson is mastered. Keep the level with the daily challenge and the arcade.'),
      el('div', { style: { display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' } },
        lesson
          ? el('button', { class: 'btn btn--primary', onclick: () => navigate(`/learn/${lesson.id}`) }, icon('play', 14), 'Continue lesson')
          : el('button', { class: 'btn btn--primary', onclick: () => navigate('/challenge') }, icon('bolt', 14), 'Open daily challenge'),
        el('button', { class: 'btn', onclick: () => navigate('/practice') }, icon('keyboard', 14), 'Free practice'),
        el('span', { class: 'tiny muted' },
          lesson ? `Requires ${Math.round(lesson.thresholds?.minAccuracy ?? lesson.minAccuracy)}% accuracy${(lesson.thresholds?.minWpm ?? lesson.minWpm) > 0 ? ` and ${lesson.thresholds?.minWpm ?? lesson.minWpm} WPM` : ''}` : '')),
      el('div', { style: { marginTop: '18px', maxWidth: '420px' } },
        el('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: '11.5px', color: 'var(--ink-500)', marginBottom: '5px' } },
          el('span', {}, 'Course progress'),
          el('span', {}, `${Math.round((curriculum.masteredCount / curriculum.totalLessons) * 100)}%`)),
        meter(curriculum.masteredCount, { max: curriculum.totalLessons, thin: true }))),
    el('div', { style: {
      background: 'var(--surface-2)', borderLeft: '1px solid var(--line)', padding: '24px',
      display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', textAlign: 'center',
    } },
      el('div', { class: 'eyebrow' }, "Today's target"),
      todayRing(today.progressPct, fmtMinutes(today.practiceMs), `of ${today.targetMinutes} min`),
      el('div', { class: 'tiny muted', style: { marginTop: '10px' } },
        `${today.sessions} session${today.sessions === 1 ? '' : 's'} · ${today.games} arcade round${today.games === 1 ? '' : 's'}`))));

  // ---------------------------------------------------------------- stats
  const statsStrip = el('div', { class: 'stats', style: { marginBottom: '20px' } },
    statTile({ label: 'Current net speed', value: stats.currentWpm, unit: 'WPM', hint: 'last 5 sessions' }),
    statTile({ label: 'Best net speed', value: stats.bestWpm, unit: 'WPM' }),
    statTile({ label: 'Accuracy', value: stats.currentAccuracy, unit: '%', hint: `avg all time ${stats.averageAccuracy}%` }),
    statTile({ label: 'Practice time', value: fmtMinutes(stats.totalPracticeMs), hint: `${stats.totalSessions} sessions` }),
    statTile({ label: 'Streak', value: stats.streak, unit: stats.streak === 1 ? 'day' : 'days', hint: `${stats.achievementsEarned} achievements` }));

  // -------------------------------------------------------- recommendations
  const recList = el('div', {}, recommendations.map((rec, i) => {
    const actionBtn = rec.action
      ? el('button', { class: 'btn btn--sm', onclick: () => runRecommendation(rec) }, 'Open', icon('right', 12))
      : el('span');
    return el('div', {
      style: {
        display: 'grid', gridTemplateColumns: '28px 1fr auto', gap: '14px',
        padding: '14px 20px', borderBottom: i < recommendations.length - 1 ? '1px solid var(--line)' : '0',
        alignItems: 'start',
      },
    },
    el('div', {
      style: {
        width: '24px', height: '24px', borderRadius: '50%', background: 'var(--brand-100)',
        color: 'var(--brand-700)', display: 'grid', placeItems: 'center', fontSize: '11px', fontWeight: '700',
      },
    }, String(i + 1)),
    el('div', {},
      el('div', { style: { fontWeight: '600', fontSize: '14px' } }, rec.title),
      el('div', { class: 'small muted', style: { marginTop: '3px', lineHeight: '1.5' } }, rec.reason),
      el('div', { style: { marginTop: '6px' } }, el('span', { class: 'badge' }, rec.type.replace('-', ' ')))),
    actionBtn);
  }));

  const recPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' },
      el('h3', {}, 'What to work on next'),
      el('span', { class: 'badge badge--brand' }, 'From your data')),
    el('div', { class: 'panel__body', style: { padding: '0' } },
      recommendations.length === 0
        ? emptyState({
          title: 'Not enough data yet',
          message: 'Complete two or three practice sessions and this panel will start recommending specific drills from your own error patterns.',
          iconName: 'chart',
          action: el('button', { class: 'btn btn--primary', onclick: () => navigate('/practice') }, 'Start a practice session'),
        })
        : recList));

  // ------------------------------------------------------------- activity
  const activityPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Recent activity'),
      el('a', { class: 'small', href: '#/progress', style: { textDecoration: 'none' } }, 'All progress →')),
    recentActivity.length === 0
      ? el('div', { class: 'panel__body' }, emptyState({
        title: 'No activity yet',
        message: 'Your first lesson takes about three minutes. Everything you type is measured and saved.',
        iconName: 'keyboard',
        action: el('button', { class: 'btn btn--primary', onclick: () => navigate('/learn') }, 'Open the curriculum'),
      }))
      : el('div', {}, recentActivity.map((row) => el('div', {
        style: {
          display: 'grid', gridTemplateColumns: '1fr auto auto', gap: '12px', alignItems: 'center',
          padding: '10px 20px', borderBottom: '1px solid var(--line)', fontSize: '13px',
        },
      },
      el('div', {},
        el('div', { style: { fontWeight: '550' } }, row.title || row.type),
        el('div', { class: 'tiny muted' }, `${row.kind === 'game' ? 'Arcade' : row.type} · ${relTime(row.at)}`)),
      el('div', { class: 'mono', style: { fontSize: '12.5px' } }, `${row.wpm} WPM`),
      el('div', { style: { textAlign: 'right' } },
        el('span', { class: `badge ${row.accuracy >= 95 ? 'badge--ok' : row.accuracy >= 85 ? 'badge--warn' : 'badge--danger'}` }, `${Math.round(row.accuracy)}%`))))));

  // ---------------------------------------------------------------- aside
  const sideCol = el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } },
    // weak keys
    el('div', { class: 'panel' },
      el('div', { class: 'panel__head' }, el('h3', {}, 'Weakest keys')),
      el('div', { class: 'panel__body' },
        weakKeys.length === 0
          ? el('p', { class: 'small muted', style: { margin: 0 } },
            'No key data yet. The engine needs about a dozen presses per key before it can name a weak one — that usually happens in your first lesson.')
          : el('div', {},
            ...weakKeys.slice(0, 5).map((k) => el('div', {
              style: { display: 'grid', gridTemplateColumns: '34px 1fr 52px', gap: '10px', alignItems: 'center', marginBottom: '8px' },
            },
            el('div', {
              class: 'mono',
              style: {
                height: '26px', display: 'grid', placeItems: 'center', background: 'var(--surface-2)',
                border: '1px solid var(--line)', borderRadius: '4px', fontSize: '12px', fontWeight: '600',
              },
            }, k.key === ' ' ? '␣' : k.key),
            meter(Math.min(100, k.errorRate * 8), { accent: k.errorRate > 6, thin: true }),
            el('div', { class: 'mono tiny', style: { textAlign: 'right' } }, `${k.errorRate}%`))),
            el('button', {
              class: 'btn btn--sm btn--block', style: { marginTop: '6px' },
              onclick: () => navigate('/practice?preset=weak-keys'),
            }, 'Drill these keys')))),
    // forecast
    el('div', { class: 'panel' },
      el('div', { class: 'panel__head' }, el('h3', {}, 'Forecast')),
      el('div', { class: 'panel__body' },
        prediction.available
          ? el('div', {},
            el('div', { style: { display: 'flex', alignItems: 'baseline', gap: '6px' } },
              el('div', { style: { fontFamily: 'var(--font-display)', fontSize: '28px', color: 'var(--ink-900)' } }, prediction.estimateWpm),
              el('span', { class: 'small muted' }, 'WPM in ~4 sessions')),
            el('p', { class: 'tiny muted', style: { marginTop: '6px', lineHeight: '1.5' } }, prediction.basis),
            prediction.sessionsToNextTarget
              ? el('p', { class: 'tiny', style: { marginTop: '6px' } },
                `About ${prediction.sessionsToNextTarget} more sessions at the current rate to reach the ${prediction.nextTargetWpm} WPM requirement.`)
              : null,
            el('div', { class: 'badge', style: { marginTop: '8px' } }, `confidence: ${prediction.confidence}`))
          : el('p', { class: 'small muted', style: { margin: 0 } }, prediction.reason))),
    // diagnosis
    el('div', { class: 'panel' },
      el('div', { class: 'panel__head' }, el('h3', {}, 'Bottleneck')),
      el('div', { class: 'panel__body' },
        el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
          el('span', { class: 'badge badge--accent' }, diagnosis.bottleneck ?? '—'),
          el('span', { class: 'tiny muted' }, `${diagnosis.sessionsAnalysed} sessions analysed`)),
        el('p', { class: 'tiny muted', style: { marginTop: '8px', marginBottom: 0, lineHeight: '1.55' } },
          diagnosis.sessionsAnalysed < 3
            ? 'Determined from your recorded keystrokes. More sessions sharpen the analysis.'
            : `Average ${diagnosis.avgWpm} WPM at ${pct(diagnosis.avgAcc)} accuracy, consistency ${diagnosis.consistency}%.`))));

  const body = el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 340px', gap: '20px' } },
    el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, recPanel, activityPanel),
    sideCol);

  const node = el('div', {},
    el('div', { style: { marginBottom: '18px' } },
      el('div', { class: 'eyebrow' }, new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })),
      el('h1', { style: { fontSize: '24px' } }, `${greeting}, ${data.student.displayName.split(' ')[0]}.`)),
    hero,
    statsStrip,
    body);

  // chart appended inside activity panel footer if there's history
  api.get('/api/me/history?days=30').then(({ history }) => {
    if (!history.length) return;
    const chartPanel = el('div', { class: 'panel', style: { marginTop: '20px' } },
      el('div', { class: 'panel__head' }, el('h3', {}, 'Net speed, last 30 days')),
      el('div', { class: 'panel__body' },
        lineChart({
          data: history.map((h) => ({ label: h.day.slice(5), value: h.best_wpm })),
          valueKey: 'value',
          target: lesson?.thresholds?.minWpm || null,
          height: 170,
        })));
    body.firstChild.appendChild(chartPanel);
  }).catch(() => { /* chart is optional */ });

  return {
    node,
    header: {
      title: 'Dashboard',
      crumbs: [{ label: 'Dashboard' }],
      actions: [
        el('button', { class: 'btn btn--sm', onclick: () => navigate('/practice') }, icon('keyboard', 14), 'Practice'),
        el('button', { class: 'btn btn--sm btn--primary', onclick: () => navigate('/arcade') }, icon('gamepad', 14), 'Arcade'),
      ],
    },
  };
}

function todayRing(percent, value, sub) {
  const p = Math.max(0, Math.min(100, percent));
  const r = 34;
  const c = 2 * Math.PI * r;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 90 90');
  svg.setAttribute('width', '92');
  svg.setAttribute('height', '92');
  svg.setAttribute('aria-label', `${p}% of today's target completed`);
  const track = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  track.setAttribute('cx', '45'); track.setAttribute('cy', '45'); track.setAttribute('r', String(r));
  track.setAttribute('fill', 'none'); track.setAttribute('stroke', 'var(--line)'); track.setAttribute('stroke-width', '6');
  const arc = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  arc.setAttribute('cx', '45'); arc.setAttribute('cy', '45'); arc.setAttribute('r', String(r));
  arc.setAttribute('fill', 'none');
  arc.setAttribute('stroke', p >= 100 ? 'var(--ok)' : 'var(--brand)');
  arc.setAttribute('stroke-width', '6');
  arc.setAttribute('stroke-linecap', 'round');
  arc.setAttribute('stroke-dasharray', `${(c * p) / 100} ${c}`);
  arc.setAttribute('transform', 'rotate(-90 45 45)');
  const valueText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
  valueText.setAttribute('x', '45'); valueText.setAttribute('y', '47');
  valueText.setAttribute('text-anchor', 'middle');
  valueText.setAttribute('font-family', 'var(--font-display)');
  valueText.setAttribute('font-size', '16');
  valueText.setAttribute('fill', 'var(--ink-900)');
  valueText.textContent = `${Math.round(p)}%`;
  svg.append(track, arc, valueText);
  return el('div', { style: { display: 'grid', placeItems: 'center', gap: '4px' } },
    svg,
    el('div', { style: { fontSize: '13px', fontWeight: '600' } }, value),
    el('div', { class: 'tiny muted' }, sub));
}

function runRecommendation(rec) {
  const a = rec.action ?? {};
  if (a.kind === 'lesson' && a.lessonId) return navigate(`/learn/${a.lessonId}`);
  if (a.kind === 'practice') return navigate(`/practice?preset=${encodeURIComponent(a.preset ?? 'random-words')}${a.durationMs ? `&duration=${Math.round(a.durationMs / 1000)}` : ''}${a.keys ? `&keys=${encodeURIComponent(a.keys.join(','))}` : ''}`);
  if (a.kind === 'game' && a.gameId) return navigate(`/arcade?game=${encodeURIComponent(a.gameId)}`);
  if (a.kind === 'challenge') return navigate('/challenge');
  return navigate('/practice');
}
