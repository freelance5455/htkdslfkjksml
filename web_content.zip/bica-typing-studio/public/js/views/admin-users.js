import { api } from '../api.js';
import { el, icon, toast, relTime, fmtDate } from '../ui.js';
import { pageHead, staffPanel, dataTable, formDialog, confirmAction, badge, exportButton } from './_staff.js';

export default async function adminUsersView() {
  const state = { role: '', q: '' };
  let users = [];

  const host = el('div', {});
  const countLabel = el('span', { class: 'tiny muted' });

  async function load() {
    const params = new URLSearchParams();
    if (state.role) params.set('role', state.role);
    if (state.q) params.set('q', state.q);
    const query = params.toString();
    const data = await api.get(`/api/admin/users${query ? `?${query}` : ''}`);
    users = data.users;
    render();
  }

  function render() {
    countLabel.textContent = `${users.length} account${users.length === 1 ? '' : 's'}`;
    host.replaceChildren(dataTable({
      rows: users,
      empty: 'No accounts match those filters.',
      rowKey: (u) => u.id,
      columns: [
        {
          label: 'Account',
          render: (u) => el('div', {},
            el('div', { style: { fontWeight: '600' } },
              u.display_name,
              u.is_demo ? el('span', { class: 'badge', style: { marginLeft: '6px' } }, 'demo') : null,
              u.must_change_pw ? el('span', { class: 'badge badge--warn', style: { marginLeft: '6px' } }, 'must change password') : null),
            el('div', { class: 'tiny muted' }, `${u.username}${u.email ? ` · ${u.email}` : ''}`)),
        },
        { label: 'Role', render: (u) => badge(u.role.toLowerCase(), u.role === 'ADMIN' ? 'gold' : u.role === 'INSTRUCTOR' ? 'brand' : '') },
        { label: 'Status', render: (u) => (u.is_active ? badge('active', 'ok') : badge('disabled')) },
        { label: 'Last sign-in', align: 'right', render: (u) => (u.last_login_at ? relTime(u.last_login_at) : el('span', { class: 'muted' }, 'never')) },
        { label: 'Created', align: 'right', render: (u) => fmtDate(u.created_at) },
        {
          label: '', align: 'right',
          render: (u) => el('div', { style: { display: 'flex', gap: '6px', justifyContent: 'flex-end' } },
            el('button', { class: 'btn btn--sm', onclick: () => edit(u) }, 'Edit'),
            el('button', { class: 'btn btn--sm btn--ghost', onclick: () => resetPassword(u) }, 'Password')),
        },
      ],
    }));
  }

  function create() {
    formDialog({
      title: 'New account',
      intro: 'The person must change this password at first sign-in. Passwords are hashed with scrypt before they touch the database.',
      wide: true,
      fields: [
        { name: 'displayName', label: 'Full name', required: true },
        { name: 'username', label: 'Username', required: true, hint: 'Lowercase letters, digits, dot, dash, underscore.' },
        { name: 'role', label: 'Role', type: 'select', value: 'STUDENT', options: [
          { value: 'STUDENT', label: 'Student' },
          { value: 'INSTRUCTOR', label: 'Instructor' },
          { value: 'ADMIN', label: 'Administrator' },
        ] },
        { name: 'password', label: 'Temporary password', required: true, hint: 'At least 10 characters.' },
        { name: 'email', label: 'Email (optional)', type: 'email' },
        { name: 'phone', label: 'Phone (optional)' },
      ],
      submitLabel: 'Create account',
      onSubmit: async (values, close) => {
        await api.post('/api/admin/users', values);
        close();
        toast('Account created.', { type: 'ok' });
        await load();
      },
    });
  }

  function edit(user) {
    formDialog({
      title: `Edit ${user.display_name}`,
      fields: [
        { name: 'displayName', label: 'Full name', value: user.display_name, required: true },
        { name: 'role', label: 'Role', type: 'select', value: user.role, options: [
          { value: 'STUDENT', label: 'Student' },
          { value: 'INSTRUCTOR', label: 'Instructor' },
          { value: 'ADMIN', label: 'Administrator' },
        ] },
        { name: 'email', label: 'Email', type: 'email', value: user.email ?? '' },
        { name: 'phone', label: 'Phone', value: user.phone ?? '' },
        { name: 'isActive', label: 'Account is active', type: 'checkbox', value: Boolean(user.is_active),
          hint: 'Deactivating a leaver keeps their records but revokes every session immediately.' },
      ],
      submitLabel: 'Save changes',
      onSubmit: async (values, close) => {
        await api.patch(`/api/admin/users/${user.id}`, values);
        close();
        toast('Account updated.', { type: 'ok' });
        await load();
      },
    });
  }

  function resetPassword(user) {
    formDialog({
      title: `Reset password for ${user.display_name}`,
      intro: 'This signs them out everywhere and forces a change at next sign-in. Tell them the temporary password in person.',
      fields: [{ name: 'password', label: 'Temporary password', required: true, hint: 'At least 10 characters.' }],
      submitLabel: 'Reset password',
      onSubmit: async (values, close) => {
        await api.post(`/api/admin/users/${user.id}/reset-password`, values);
        close();
        toast('Password reset.', { type: 'ok' });
      },
    });
  }

  const roleFilter = el('div', { class: 'chip-grid' }, [['', 'All'], ['STUDENT', 'Students'], ['INSTRUCTOR', 'Instructors'], ['ADMIN', 'Administrators']].map(([value, label]) => el('button', {
    class: 'chip',
    'aria-pressed': state.role === value ? 'true' : 'false',
    onclick: (e) => {
      state.role = value;
      for (const chip of roleFilter.querySelectorAll('.chip')) chip.setAttribute('aria-pressed', 'false');
      e.currentTarget.setAttribute('aria-pressed', 'true');
      load();
    },
  }, label)));

  const search = el('input', {
    class: 'input', type: 'search', placeholder: 'Search name or username', style: { maxWidth: '300px' },
    oninput: (e) => {
      state.q = e.target.value;
      clearTimeout(search._timer);
      search._timer = setTimeout(load, 220);
    },
  });

  await load();

  const node = el('div', {},
    pageHead('Administration', 'People',
      'Every account in the centre. Roles are enforced by the server on every request — changing a role here changes what the API will allow, not just which buttons appear.'),
    el('div', { style: { display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap' } },
      roleFilter, search,
      el('div', { style: { marginLeft: 'auto', display: 'flex', gap: '8px', alignItems: 'center' } },
        countLabel,
        exportButton({ label: 'Export CSV', href: '/api/admin/export/users.csv' }))),
    staffPanel('Accounts',
      el('div', { class: 'panel__body', style: { padding: 0 } }, host),
      [el('button', { class: 'btn btn--sm btn--primary', onclick: create }, icon('plus', 13), 'New account')]),
    el('div', { class: 'callout', style: { marginTop: '16px' } },
      el('strong', {}, 'Do not create shared logins. '),
      'Results are only defensible if each account belongs to one person. A class that shares a login produces a record that cannot be audited or certified.'));


  return {
    node,
    header: {
      title: 'People',
      crumbs: [{ label: 'Administration', href: '#/admin' }, { label: 'People' }],
      actions: [el('button', { class: 'btn btn--sm btn--primary', onclick: () => create() }, icon('plus', 13), 'New account')],
    },
  };
}
