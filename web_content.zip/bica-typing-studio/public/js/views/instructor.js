import { api } from '../api.js';
import { el, icon, statTile, lineChart, relTime, fmtMinutes, emptyState } from '../ui.js';
import { navigate } from '../router.js';
import { pageHead, staffPanel, dataTable, badge } from './_staff.js';

export default async function instructorView() {
  const data = await api.get('/api/instructor/dashboard');
  const { totals, classes, needsSupport, recentActivity } = data;

  const kpis = el('div', { class: 'stats', style: { gridTemplateColumns: 'repeat(5, 1fr)' } },
    statTile({ label: 'Students', value: totals.students, hint: `${totals.activeThisWeek} active this week` }),
    statTile({ label: 'Classes', value: totals.classes }),
    statTile({ label: 'Average net WPM', value: totals.averageWpm, hint: 'verified, last 30 days' }),
    statTile({ label: 'Average accuracy', value: `${Math.round(totals.averageAccuracy)}%` }),
    statTile({ label: 'Practice hours', value: totals.practiceHours, hint: `${totals.sessions30d} sessions` }));

  const attention = staffPanel('Needs attention',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      needsSupport.length
        ? dataTable({
          rows: needsSupport,
          empty: 'Nobody flagged.',
          onRowClick: (row) => navigate(`/instructor/students/${row.id}`),
          columns: [
            { label: 'Student', render: (r) => el('div', {}, el('div', { style: { fontWeight: '600' } }, r.display_name), el('div', { class: 'tiny muted' }, r.username)) },
            { label: 'Class', render: (r) => r.class_name },
            { label: 'Avg accuracy', align: 'right', render: (r) => `${Math.round(r.avg_accuracy)}%` },
            { label: 'Best WPM', align: 'right', render: (r) => String(Math.round(r.best_wpm)) },
            { label: 'Last practice', align: 'right', render: (r) => (r.last_at ? relTime(r.last_at) : badge('never', 'warn')) },
          ],
        })
        : emptyState({
          title: 'Nothing flagged',
          message: 'Students appear here when their verified accuracy drops below 90% or they have not practised for a week.',
          iconName: 'check',
        })),
    [el('a', { class: 'btn btn--sm btn--ghost', href: '#/instructor/students' }, 'All students')]);

  const classPanel = staffPanel('Classes',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: classes,
        empty: 'No classes yet. Create one from the classes screen.',
        onRowClick: (row) => navigate(`/instructor/classes/${row.id}`),
        columns: [
          { label: 'Class', render: (r) => el('div', {}, el('div', { style: { fontWeight: '600' } }, r.name), el('div', { class: 'tiny muted' }, r.code)) },
          { label: 'Students', align: 'right', render: (r) => String(r.students ?? 0) },
          { label: 'Instructor', render: (r) => r.instructor_name ?? '—' },
        ],
      })),
    [el('button', { class: 'btn btn--sm', onclick: () => navigate('/instructor/classes') }, icon('plus', 13), 'Manage')]);

  const recent = staffPanel('Recent activity',
    el('div', { class: 'panel__body', style: { padding: 0 } },
      dataTable({
        rows: recentActivity.slice(0, 10),
        empty: 'No sessions recorded in your classes yet.',
        columns: [
          { label: 'Student', render: (r) => r.display_name },
          { label: 'Activity', render: (r) => `${r.source}${r.ref_id ? ` · ${r.ref_id}` : ''}` },
          { label: 'Net WPM', align: 'right', render: (r) => String(Math.round(r.net_wpm)) },
          { label: 'Accuracy', align: 'right', render: (r) => `${Math.round(r.accuracy)}%` },
          { label: 'When', align: 'right', render: (r) => relTime(r.started_at) },
        ],
      })));

  const quick = staffPanel('Common tasks',
    el('div', { class: 'panel__body' },
      el('div', { class: 'quick-grid' },
        quickLink('Assign work', 'Give a class a lesson, game or test with a deadline.', 'stack', '/instructor/assignments'),
        quickLink('Create a test', 'Fixed passage, exam conditions, your own pass marks.', 'file', '/instructor/tests'),
        quickLink('Class report', 'Roster with accuracy, speed, participation and CSV export.', 'chart', '/instructor/classes'),
        quickLink('Issue certificates', 'Check eligibility and issue a numbered certificate.', 'award', '/instructor/certificates'))));

  const node = el('div', {},
    pageHead('Instructor', 'Teaching overview',
      classes.length
        ? `You are responsible for ${classes.length} class${classes.length === 1 ? '' : 'es'}. Figures below cover verified sessions in the last 30 days.`
        : 'You are not assigned to a class yet. Create one to begin.'),
    kpis,
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.2fr) minmax(0, 1fr)', gap: '20px', marginBottom: '20px' } },
      attention, classPanel),
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: '20px' } },
      recent, quick));

  return {
    node,
    header: {
      title: 'Instructor',
      crumbs: [{ label: 'Instructor' }],
      actions: [el('button', { class: 'btn btn--sm btn--primary', onclick: () => navigate('/instructor/assignments') }, icon('plus', 13), 'New assignment')],
    },
  };
}

function quickLink(title, body, iconName, href) {
  return el('a', { class: 'quick-link', href: `#${href}` },
    el('div', { class: 'quick-link__icon' }, icon(iconName, 17)),
    el('div', {},
      el('div', { class: 'quick-link__title' }, title),
      el('div', { class: 'tiny muted' }, body)));
}

