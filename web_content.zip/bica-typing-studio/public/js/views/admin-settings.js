import { api } from '../api.js';
import { el, icon, toast } from '../ui.js';
import { pageHead, staffPanel, confirmAction, badge } from './_staff.js';

/**
 * Settings screen generated from the server's own schema. The server is the
 * authority: each control can only produce a value the PUT endpoint accepts,
 * and a rejected value is reported rather than silently dropped.
 */
const GROUPS = [
  {
    id: 'org', title: 'Centre identity',
    hint: 'Used on certificates, reports and the sign-in screen.',
    keys: ['org.name', 'org.address', 'org.certificateSignatory'],
  },
  {
    id: 'curriculum', title: 'Grading and progression',
    hint: 'Mastery gates. Accuracy is the primary criterion; speed is a floor, never a substitute.',
    keys: ['curriculum.minAccuracy', 'curriculum.minWpm', 'curriculum.minChars', 'curriculum.requireSequentialUnlock'],
  },
  {
    id: 'exams', title: 'Examination defaults',
    hint: 'Applied to new tests. Each test can override them.',
    keys: ['exams.passAccuracy', 'exams.passWpm', 'exams.allowBackspace'],
  },
  {
    id: 'features', title: 'Features and competition',
    hint: 'Turning off competition removes challenges and leaderboards for everybody, including classes that had them.',
    keys: ['features.competitive', 'features.leaderboards', 'features.publicNames', 'features.arcade', 'features.offlineQueue'],
  },
  {
    id: 'cert', title: 'Certificates',
    hint: 'A certificate is issued only when every criterion below is met by verified results.',
    keys: ['cert.enabled', 'cert.minLevel', 'cert.minLessons', 'cert.minWpm', 'cert.minAccuracy', 'cert.courseTitle'],
  },
  {
    id: 'student', title: 'Students and interface',
    hint: 'Daily target and default interface language for new accounts.',
    keys: ['student.dailyTargetMinutes', 'ui.theme', 'ui.defaultLanguage'],
  },
];

const LABELS = {
  'org.name': ['Centre name', 'Printed on certificates and reports.'],
  'org.address': ['Address', 'Optional. Appears under the centre name on certificates.'],
  'org.certificateSignatory': ['Certificate signatory', 'The role or name that signs certificates, e.g. “Centre Administrator”.'],
  'curriculum.minAccuracy': ['Minimum accuracy to master a lesson (%)', 'Leave blank to use each lesson’s own requirement (usually 95%).'],
  'curriculum.minWpm': ['Minimum net WPM to master a lesson', 'Leave blank to use each lesson’s own requirement.'],
  'curriculum.minChars': ['Minimum characters typed per attempt', 'Stops a three-character fluke from mastering a lesson.'],
  'curriculum.requireSequentialUnlock': ['Require lessons in order', 'Off lets students jump to any lesson — not recommended.'],
  'exams.passAccuracy': ['Default pass accuracy (%)', 'Applied to new tests.'],
  'exams.passWpm': ['Default pass speed (net WPM)', 'A floor, not a target.'],
  'exams.allowBackspace': ['Allow backspace by default', 'Off makes mistakes permanent, as in many employment tests.'],
  'features.competitive': ['Challenges and competition', 'Master switch for the challenge screen.'],
  'features.leaderboards': ['Leaderboards', 'Class-only boards, ranked on verified net WPM.'],
  'features.publicNames': ['Show display names on leaderboards', 'Off replaces names with anonymous BICA numbers.'],
  'features.arcade': ['Typing games', 'Off removes the arcade entirely.'],
  'features.offlineQueue': ['Offline result queue', 'Lets results be saved locally and submitted later.'],
  'cert.enabled': ['Issue certificates', 'Off blocks issuing, even for eligible students.'],
  'cert.minLevel': ['Minimum level mastered', '0–6. Level 3 means the whole elementary stage is complete.'],
  'cert.minLessons': ['Minimum lessons mastered', 'Counts verified mastery, not attempts.'],
  'cert.minWpm': ['Minimum verified net WPM', 'Measured on a verified session.'],
  'cert.minAccuracy': ['Minimum verified accuracy (%)', 'Measured on a session carrying at least 100 characters.'],
  'cert.courseTitle': ['Course title on the certificate', 'Use the name your centre actually teaches.'],
  'student.dailyTargetMinutes': ['Daily practice target (minutes)', 'Drives the ring on the student dashboard.'],
  'ui.theme': ['Default theme', 'light or dark.'],
  'ui.defaultLanguage': ['Default interface language', 'en, bn or hi. Language of the interface is separate from the typing course.'],
};

export default async function adminSettingsView() {
  const { settings, schema, defaults } = await api.get('/api/admin/settings');
  const draft = { ...settings };
  const pendingKeys = new Set();
  const saveBtn = el('button', { class: 'btn btn--primary', disabled: true }, icon('check', 14), 'Save changes');
  const dirtyLabel = el('span', { class: 'tiny muted' }, 'No unsaved changes');

  function markDirty(key, value) {
    if (JSON.stringify(value) === JSON.stringify(settings[key])) pendingKeys.delete(key);
    else pendingKeys.add(key);
    draft[key] = value;
    saveBtn.disabled = pendingKeys.size === 0;
    dirtyLabel.textContent = pendingKeys.size
      ? `${pendingKeys.size} unsaved change${pendingKeys.size === 1 ? '' : 's'}`
      : 'No unsaved changes';
  }

  function control(key, rule) {
    const [label, hint] = LABELS[key] ?? [key, ''];
    const value = settings[key];
    let input;

    if (rule.type === 'boolean') {
      input = el('label', { class: 'switch' },
        el('input', { type: 'checkbox', checked: Boolean(value), onchange: (e) => markDirty(key, e.target.checked) }),
        el('span', { class: 'switch__track' }));
    } else if (rule.type === 'number') {
      input = el('input', {
        class: 'input', type: 'number',
        min: String(rule.min ?? ''), max: String(rule.max ?? ''),
        step: rule.integer ? '1' : '0.1',
        value: value == null ? '' : String(value),
        placeholder: rule.nullable ? 'use lesson default' : '',
        oninput: (e) => {
          const raw = e.target.value;
          markDirty(key, raw === '' && rule.nullable ? null : Number(raw));
        },
      });
    } else {
      input = el('input', {
        class: 'input', type: 'text', maxlength: String(rule.max ?? 200), value: value == null ? '' : String(value),
        oninput: (e) => markDirty(key, e.target.value),
      });
    }

    return el('div', { class: 'settings-row' },
      el('div', {},
        el('div', { class: 'settings-row__label' }, label),
        el('div', { class: 'settings-row__hint' }, hint),
        el('div', { class: 'tiny', style: { color: 'var(--ink-400)', marginTop: '2px', fontFamily: 'var(--font-mono)' } }, key)),
      el('div', {}, input));
  }

  const groups = GROUPS.map((group) => {
    const rows = group.keys.filter((key) => schema[key]).map((key) => control(key, schema[key]));
    return el('div', { style: { marginBottom: '20px' } },
      el('div', { class: 'eyebrow', style: { marginBottom: '4px' } }, group.title),
      el('p', { class: 'small muted', style: { margin: '0 0 10px' } }, group.hint),
      el('div', { class: 'settings-group' }, rows));
  });

  const gamesRow = el('div', { class: 'settings-row' },
    el('div', {},
      el('div', { class: 'settings-row__label' }, 'Enabled games'),
      el('div', { class: 'settings-row__hint' }, 'Disabled games disappear from the arcade and cannot be started. A game switched off mid-round still records the round.'),
      el('div', { class: 'tiny', style: { color: 'var(--ink-400)', marginTop: '2px', fontFamily: 'var(--font-mono)' } }, 'games.enabled')),
    el('div', { class: 'chip-grid', style: { justifyContent: 'flex-end' } },
      (await import('../games/registry.js')).GAME_IDS.map((id) => {
        const on = (settings['games.enabled'] ?? []).includes(id);
        return el('button', {
          class: 'chip', 'aria-pressed': on ? 'true' : 'false',
          onclick: (e) => {
            const current = new Set(draft['games.enabled'] ?? []);
            if (current.has(id)) current.delete(id); else current.add(id);
            const next = [...current];
            e.currentTarget.setAttribute('aria-pressed', current.has(id) ? 'true' : 'false');
            markDirty('games.enabled', next);
          },
        }, id);
      })));

  saveBtn.addEventListener('click', async () => {
    saveBtn.disabled = true;
    saveBtn.textContent = 'Saving…';
    const patch = {};
    for (const key of pendingKeys) patch[key] = draft[key];
    try {
      await api.put('/api/admin/settings', { settings: patch });
      toast(`${pendingKeys.size} setting${pendingKeys.size === 1 ? '' : 's'} saved. They apply to new requests immediately.`, { type: 'ok', timeout: 6000 });
      location.reload();
    } catch (err) {
      toast(err.message, { type: 'error', timeout: 8000 });
      saveBtn.disabled = false;
      saveBtn.replaceChildren(icon('check', 14), document.createTextNode('Save changes'));
    }
  });

  const resetToDefaults = () => {
    confirmAction({
      title: 'Restore default settings',
      message: 'Every setting returns to the value shipped with the system. Students, sessions and certificates are not touched. Take a backup first if you have tuned these values deliberately.',
      confirmLabel: 'Restore defaults',
      danger: true,
      run: async () => {
        await api.put('/api/admin/settings', { settings: defaults });
        toast('Defaults restored.', { type: 'ok' });
        location.reload();
      },
    });
  };

  const node = el('div', {},
    pageHead('Administration', 'Centre settings',
      'These values are enforced by the server. Changing a pass mark here changes what the API accepts, not just what a screen shows.'),
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0, 1.6fr) minmax(0, 1fr)', gap: '24px' } },
      el('div', {}, groups, el('div', { class: 'eyebrow', style: { marginBottom: '4px' } }, 'Arcade'), el('div', { class: 'settings-group' }, gamesRow)),
      el('div', { style: { position: 'sticky', top: '80px', alignSelf: 'start' } },
        staffPanel('Unsaved changes',
          el('div', { class: 'panel__body' },
            el('p', { class: 'small muted', style: { marginTop: 0 } }, 'Settings save as a single request. Invalid values are rejected with the exact field named, and nothing is applied.'),
            dirtyLabel,
            el('div', { style: { marginTop: '12px', display: 'flex', gap: '8px', flexWrap: 'wrap' } },
              saveBtn,
              el('button', { class: 'btn btn--ghost', onclick: () => location.reload() }, 'Discard')),
            el('div', { style: { marginTop: '16px' } },
              el('button', { class: 'btn btn--sm btn--danger', onclick: resetToDefaults }, 'Restore defaults'))),
          [badge('server-enforced', 'brand')]))));

  return {
    node,
    header: {
      title: 'Settings',
      crumbs: [{ label: 'Administration', href: '#/admin' }, { label: 'Settings' }],
    },
  };
}
