import { api } from '../api.js';
import { el, icon, relTime, fmtDate, emptyState } from '../ui.js';
import { pageHead, staffPanel, dataTable, badge } from './_staff.js';

const CATEGORIES = [
  { id: '', label: 'Everything', match: () => true },
  { id: 'auth', label: 'Sign-in', match: (a) => a.startsWith('auth.') },
  { id: 'people', label: 'People', match: (a) => /user|student|password/.test(a) },
  { id: 'classes', label: 'Classes and work', match: (a) => /class|assignment|test/.test(a) },
  { id: 'certificates', label: 'Certificates', match: (a) => a.startsWith('certificate.') },
  { id: 'settings', label: 'Settings and data', match: (a) => /settings|backup|export|demo/.test(a) },
];

export default async function auditView() {
  const { entries } = await api.get('/api/admin/audit?limit=300');
  const state = { category: '', q: '' };
  const host = el('div', {});

  function render() {
    const cat = CATEGORIES.find((c) => c.id === state.category) ?? CATEGORIES[0];
    const needle = state.q.trim().toLowerCase();
    const rows = entries.filter((e) => cat.match(e.action)
      && (!needle || `${e.action} ${e.actor ?? ''} ${e.target ?? ''}`.toLowerCase().includes(needle)));

    host.replaceChildren(dataTable({
      rows,
      empty: 'No audit entries match those filters.',
      rowKey: (e) => e.id,
      columns: [
        { label: 'When', render: (e) => el('div', {}, el('div', {}, relTime(e.at)), el('div', { class: 'tiny muted' }, fmtDate(e.at))) },
        { label: 'Actor', render: (e) => el('div', {}, el('div', { style: { fontWeight: '600' } }, e.actor ?? 'system'), el('div', { class: 'tiny muted' }, e.actor_role ?? '')) },
        { label: 'Action', render: (e) => el('code', { class: 'tiny' }, e.action) },
        { label: 'Target', render: (e) => (e.target ? el('span', { class: 'tiny muted' }, e.target) : '—') },
        {
          label: 'Detail', render: (e) => {
            const detail = e.detail && Object.keys(e.detail).length ? e.detail : null;
            if (!detail) return el('span', { class: 'tiny muted' }, '—');
            return el('span', { class: 'tiny', style: { fontFamily: 'var(--font-mono)', color: 'var(--ink-500)' } },
              Object.entries(detail).slice(0, 3).map(([k, v]) => `${k}=${typeof v === 'object' ? JSON.stringify(v) : v}`).join(' · '));
          },
        },
      ],
    }));
  }

  const chips = el('div', { class: 'chip-grid' }, CATEGORIES.map((c) => el('button', {
    class: 'chip',
    'aria-pressed': state.category === c.id ? 'true' : 'false',
    onclick: (e) => {
      state.category = c.id;
      for (const chip of chips.querySelectorAll('.chip')) chip.setAttribute('aria-pressed', 'false');
      e.currentTarget.setAttribute('aria-pressed', 'true');
      render();
    },
  }, c.label)));

  const search = el('input', {
    class: 'input', type: 'search', placeholder: 'Search action, person or target', style: { maxWidth: '320px' },
    oninput: (e) => { state.q = e.target.value; render(); },
  });

  render();

  const node = el('div', {},
    pageHead('Administration', 'Audit log',
      'Every privileged action is recorded with the actor, the target and the time. The log is append-only from the application\u2019s point of view: there is no screen that edits or deletes an entry.'),
    el('div', { style: { display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap' } },
      chips, search,
      el('span', { class: 'tiny muted', style: { marginLeft: 'auto' } }, `${entries.length} recent entries`)),
    staffPanel('Entries',
      el('div', { class: 'panel__body', style: { padding: 0 } }, host)),
    el('div', { class: 'callout', style: { marginTop: '16px' } },
      el('strong', {}, 'What is recorded. '),
      'Sign-ins and failed sign-in attempts, password changes and resets, account creation and role changes, class and enrolment changes, assignment and test changes, certificate issue and revocation, settings changes, backups and exports. Reading a student record is not logged; writing to it is.'));


  return {
    node,
    header: {
      title: 'Audit log',
      crumbs: [{ label: 'Administration', href: '#/admin' }, { label: 'Audit log' }],
    },
  };
}
