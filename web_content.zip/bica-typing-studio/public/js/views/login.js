import { api } from '../api.js';
import { el, icon } from '../ui.js';
import { state } from '../store.js';
import { t } from '../i18n.js';

export default async function loginView() {
  const errorHost = el('div', { class: 'error-text', role: 'alert' });
  const submitBtn = el('button', { class: 'btn btn--primary btn--lg btn--block', type: 'submit' }, t('auth.signIn'));
  let busy = false;

  const form = el('form', {
    class: 'auth__form', novalidate: true,
    onsubmit: async (event) => {
      event.preventDefault();
      if (busy) return;
      errorHost.textContent = '';
      const username = form.querySelector('#username').value.trim();
      const password = form.querySelector('#password').value;
      if (!username || !password) {
        errorHost.textContent = 'Enter your username and password.';
        return;
      }
      busy = true;
      submitBtn.disabled = true;
      submitBtn.textContent = t('auth.signingIn');
      try {
        const { user } = await api.post('/api/auth/login', { username, password });
        const app = await import('../app.js');
        app.afterLogin(user);
      } catch (err) {
        errorHost.textContent = err.message || 'Sign-in failed.';
        form.querySelector('#password').value = '';
        form.querySelector('#password').focus();
      } finally {
        busy = false;
        submitBtn.disabled = false;
        submitBtn.textContent = t('auth.signIn');
      }
    },
  },
  el('div', { class: 'eyebrow' }, 'BICA Computer Training Centre'),
  el('h1', {}, t('auth.welcome')),
  el('p', { class: 'lede' }, 'Sign in to continue your typing course, or to open your class dashboard.'),

  el('div', { class: 'field' },
    el('label', { for: 'username' }, t('auth.username')),
    el('input', { class: 'input', id: 'username', name: 'username', autocomplete: 'username', autocapitalize: 'none', spellcheck: 'false', required: true, autofocus: true })),

  el('div', { class: 'field' },
    el('label', { for: 'password' }, t('auth.password')),
    el('input', { class: 'input', id: 'password', name: 'password', type: 'password', autocomplete: 'current-password', required: true })),

  errorHost,
  el('div', { style: { marginTop: '16px' } }, submitBtn),
  el('p', { class: 'hint', style: { marginTop: '16px' } },
    'Accounts are created by your centre administrator or instructor. If you cannot sign in, ask the office to reset your password.'));

  const aside = el('aside', { class: 'auth__aside' },
    el('div', { class: 'auth__brand' },
      el('div', { class: 'nav__mark' }, 'B'),
      el('div', { class: 'nav__wordmark' },
        el('strong', {}, 'BICA'),
        el('span', {}, 'Typing Studio'))),
    el('div', {},
      el('p', { class: 'auth__quote' }, 'Accuracy first. Speed is what accuracy becomes when it repeats.'),
      el('p', { style: { fontSize: '13px', color: '#98a2b0', maxWidth: '38ch', lineHeight: '1.6' } },
        'A structured course from the home row to professional transcription, twelve arcade drills, and verified results your instructor can actually use.')),
    el('div', { class: 'auth__facts' },
      el('div', {}, el('strong', {}, '7'), 'levels'),
      el('div', {}, el('strong', {}, '50'), 'lessons'),
      el('div', {}, el('strong', {}, '12'), 'arcade games'),
      el('div', {}, el('strong', {}, '100%'), 'measured')));

  const panel = el('div', { class: 'auth__panel' },
    el('div', { style: { width: '100%', display: 'grid', placeItems: 'center' } }, form));

  if (state.pendingSync > 0) {
    form.appendChild(el('p', { class: 'hint', style: { marginTop: '12px' } },
      `${state.pendingSync} saved result(s) on this computer are waiting to sync. They will be sent automatically after sign-in.`));
  }

  return el('div', { class: 'auth' }, aside, panel);
}
