import { api } from '../api.js';
import { el, icon, toast, dialog, fmtMinutes, fmtDate, relTime } from '../ui.js';
import { state, setPrefs, subscribe } from '../store.js';
import { setLanguage, LANGUAGES, getLanguage, t } from '../i18n.js';
import { listPending, retryPending, discardPending, refreshCount } from '../offline.js';

export default async function profileView() {
  const [me, dash, pending] = await Promise.all([
    api.get('/api/auth/me'),
    api.get('/api/me/dashboard').catch(() => null),
    listPending().catch(() => []),
  ]);
  const user = me.user;
  const prefs = user.prefs ?? {};

  // ------------------------------------------------------------ identity card
  const identity = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Account')),
    el('div', { class: 'panel__body' },
      el('div', { class: 'profile-head' },
        el('div', { class: 'avatar avatar--lg' }, initialsOf(user.displayName)),
        el('div', {},
          el('div', { style: { fontFamily: 'var(--font-display)', fontSize: 'var(--fs-xl)' } }, user.displayName),
          el('div', { class: 'small muted' }, `${user.username} · ${roleLabel(user.role)}`),
          user.mustChangePw
            ? el('div', { class: 'badge badge--warn', style: { marginTop: '6px' } }, 'Password change required')
            : null)),
      el('div', { class: 'kv', style: { marginTop: '18px' } },
        kv('Display name', user.displayName),
        kv('Username', user.username),
        kv('Role', roleLabel(user.role)),
        kv('Centre', 'BICA Computer Training Centre'),
        ...(dash ? [kv('Member since', dash.stats?.totalSessions ? 'active' : 'new account')] : []))));

  // -------------------------------------------------------------- password
  const pwCurrent = el('input', { class: 'input', type: 'password', autocomplete: 'current-password' });
  const pwNext = el('input', { class: 'input', type: 'password', autocomplete: 'new-password' });
  const pwAgain = el('input', { class: 'input', type: 'password', autocomplete: 'new-password' });
  const pwError = el('div', { class: 'small', style: { color: 'var(--danger)', minHeight: '18px' } });

  const passwordPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Password')),
    el('div', { class: 'panel__body' },
      el('p', { class: 'small muted', style: { marginTop: 0 } },
        'Changing your password signs out every other device using this account. Passwords are stored as scrypt hashes, never as text.'),
      el('div', { class: 'field' }, el('label', {}, 'Current password'), pwCurrent),
      el('div', { class: 'field' }, el('label', {}, 'New password'), pwNext,
        el('div', { class: 'hint' }, 'At least 8 characters. Length matters more than symbols.')),
      el('div', { class: 'field' }, el('label', {}, 'Repeat new password'), pwAgain),
      pwError,
      el('button', { class: 'btn btn--primary', onclick: changePassword }, 'Update password')));

  async function changePassword() {
    pwError.textContent = '';
    if (pwNext.value !== pwAgain.value) { pwError.textContent = 'The new passwords do not match.'; return; }
    try {
      await api.post('/api/auth/password', { currentPassword: pwCurrent.value, newPassword: pwNext.value });
      pwCurrent.value = ''; pwNext.value = ''; pwAgain.value = '';
      toast('Password updated. Other sessions have been signed out.', { type: 'ok' });
    } catch (err) {
      pwError.textContent = err.message;
    }
  }

  // ---------------------------------------------------------- preferences
  const prefToggle = (label, hint, key, initial) => el('div', { class: 'settings-row' },
    el('div', {}, el('div', { class: 'settings-row__label' }, label), el('div', { class: 'settings-row__hint' }, hint)),
    el('label', { class: 'switch' },
      el('input', {
        type: 'checkbox', checked: Boolean(initial),
        onchange: async (e) => { await savePref({ [key]: e.target.checked }); },
      }),
      el('span', { class: 'switch__track' })));

  const themeSelect = el('select', { class: 'select', onchange: (e) => savePref({ theme: e.target.value }) },
    [['light', 'Light'], ['dark', 'Dark'], ['system', 'Match system']].map(([value, label]) =>
      el('option', { value, selected: (prefs.theme ?? 'system') === value }, label)));

  const langSelect = el('select', { class: 'select', onchange: (e) => savePref({ language: e.target.value }) },
    LANGUAGES.map((l) => el('option', { value: l.code, selected: getLanguage() === l.code },
      l.complete ? l.label : `${l.label} (partial)`)));

  const preferencesPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Interface preferences')),
    el('div', {},
      el('div', { class: 'settings-row' },
        el('div', {}, el('div', { class: 'settings-row__label' }, 'Theme'),
          el('div', { class: 'settings-row__hint' }, 'Applies to this account on every device.')),
        themeSelect),
      el('div', { class: 'settings-row' },
        el('div', {}, el('div', { class: 'settings-row__label' }, 'Interface language'),
          el('div', { class: 'settings-row__hint' }, 'Separate from the course language. Languages marked partial fall back to English for untranslated text.')),
        langSelect),
      prefToggle('Reduce motion', 'Removes chart and panel animation.', 'reducedMotion', Boolean(prefs.reducedMotion)),
      prefToggle('Key click sound', 'A quiet click on each keystroke. Off by default in shared labs.', 'sound', Boolean(prefs.sound)),
      prefToggle('Show the on-screen keyboard', 'Highlights the next key and the finger to use.', 'keyboardGuide', prefs.keyboardGuide !== false),
      prefToggle('Show live speed while typing', 'Turn off to focus only on accuracy.', 'showLiveWpm', prefs.showLiveWpm !== false),
      el('div', { class: 'panel__foot tiny muted' },
        'Preferences are stored with your account, not in this browser.')));

  async function savePref(patch) {
    const before = { ...prefs, ...patch };
    try {
      const { prefs: saved } = await api.patch('/api/auth/preferences', patch);
      setPrefs(saved);
      if ('language' in patch) setLanguage(patch.language);
      if ('theme' in patch) applyTheme(patch.theme);
      toast('Preference saved.', { type: 'ok', timeout: 1800 });
    } catch (err) {
      toast(err.message, { type: 'error' });
    }
  }

  // ------------------------------------------------------------ sync queue
  const pendingPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Offline results'),
      el('span', { class: `badge ${pending.length ? 'badge--warn' : 'badge--ok'}` },
        pending.length ? `${pending.length} pending` : 'all synced')),
    el('div', { class: 'panel__body' },
      el('p', { class: 'small muted', style: { marginTop: 0 } },
        'Practice completed without a network connection is stored on this computer and submitted when the lab server is reachable again. Nothing is discarded silently.'),
      pending.length
        ? el('div', {}, pending.map((item) => el('div', { class: 'sync-row' },
          el('div', {},
            el('div', { class: 'small' }, item.label ?? 'Practice result'),
            el('div', { class: 'tiny muted' }, `${relTime(item.createdAt)} · ${item.endpoint}`)),
          el('div', { style: { display: 'flex', gap: '6px' } },
            el('button', { class: 'btn btn--sm', onclick: () => { retryPending(item.id).then(() => refresh()); } }, 'Retry'),
            el('button', { class: 'btn btn--sm btn--ghost', onclick: () => { discardPending(item.id).then(() => refresh()); } }, 'Discard')))))
        : el('p', { class: 'small', style: { margin: 0, color: 'var(--ok)' } }, 'Everything on this computer has been submitted to the server.')));

  async function refresh() {
    const rows = await listPending();
    await refreshCount();
    mountPending(rows);
  }
  function mountPending(rows) {
    const host = pendingPanel.querySelector('.panel__body');
    if (host) host.replaceWith(renderPendingBody(rows));
  }
  function renderPendingBody(rows) {
    return el('div', { class: 'panel__body' }, rows.length
      ? el('div', {}, rows.map((item) => el('div', { class: 'sync-row' },
        el('div', {},
          el('div', { class: 'small' }, item.label ?? 'Practice result'),
          el('div', { class: 'tiny muted' }, `${relTime(item.createdAt)} · ${item.endpoint}`)),
        el('div', { style: { display: 'flex', gap: '6px' } },
          el('button', { class: 'btn btn--sm', onclick: () => { retryPending(item.id).then(refresh); } }, 'Retry'),
          el('button', { class: 'btn btn--sm btn--ghost', onclick: () => { discardPending(item.id).then(refresh); } }, 'Discard')))))
      : el('p', { class: 'small', style: { margin: 0, color: 'var(--ok)' } }, 'Everything on this computer has been submitted to the server.'));
  }

  // ------------------------------------------------------------- statistics
  const statsPanel = dash ? el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Your record')),
    el('div', { class: 'panel__body' },
      el('div', { class: 'kv' },
        kv('Lessons mastered', `${dash.curriculum.masteredCount} of ${dash.curriculum.totalLessons}`),
        kv('Sessions', String(dash.stats.totalSessions)),
        kv('Practice time', fmtMinutes(dash.stats.totalPracticeMs)),
        kv('Best verified speed', `${dash.stats.bestWpm} WPM`),
        kv('Average accuracy', `${Math.round(dash.stats.averageAccuracy)}%`),
        kv('Game rounds', String(dash.stats.gamesPlayed)),
        kv('Achievements', `${dash.stats.achievementsEarned} of ${dash.stats.achievementsTotal}`),
        kv('Streak', `${dash.stats.streak} days`)))) : null;

  const privacyPanel = el('div', { class: 'panel' },
    el('div', { class: 'panel__head' }, el('h3', {}, 'Privacy')),
    el('div', { class: 'panel__body' },
      el('p', { class: 'small muted', style: { marginTop: 0, lineHeight: '1.6' } },
        'Your typing records are visible to you, your instructors for classes you are enrolled in, and centre administrators. Other students cannot read your sessions, key statistics or reports — the server rejects those requests, it is not a matter of hiding buttons.'),
      el('p', { class: 'small muted', style: { lineHeight: '1.6' } },
        'Leaderboards show your display name only when the centre enables public display names; otherwise you appear as an anonymous BICA number. There is no messaging between students.'),
      el('button', { class: 'btn btn--sm btn--ghost', onclick: () => signOut() }, icon('logout', 13), 'Sign out of this device')));

  function signOut() {
    dialog({
      title: 'Sign out?',
      body: el('p', { class: 'small' }, 'Any practice waiting to sync stays on this computer and will be submitted the next time you sign in on it.'),
      actions: [{ label: 'Cancel' }, { label: 'Sign out', variant: 'primary', onClick: async (close) => { close(); await api.post('/api/auth/logout'); location.hash = '#/login'; location.reload(); } }],
    });
  }

  const node = el('div', {},
    el('div', { style: { marginBottom: '18px' } },
      el('div', { class: 'eyebrow' }, 'Profile'),
      el('h1', {}, 'Profile and settings'),
      el('p', { class: 'lede' }, 'Your account, how the interface behaves, and what happens to work done without a connection.')),
    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: '20px' } },
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, identity, statsPanel, passwordPanel),
      el('div', { style: { display: 'grid', gap: '20px', alignContent: 'start' } }, preferencesPanel, pendingPanel, privacyPanel)));

  const unsub = subscribe(() => {});
  return {
    node,
    cleanup: () => unsub(),
    header: { title: 'Profile', crumbs: [{ label: 'Profile' }] },
  };
}

function kv(label, value) {
  return el('div', { class: 'kv__row' }, el('span', { class: 'kv__key' }, label), el('span', { class: 'kv__value' }, String(value)));
}

function initialsOf(name = '') {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || 'B';
}

function roleLabel(role) {
  return role === 'ADMIN' ? 'Centre administrator' : role === 'INSTRUCTOR' ? 'Instructor' : 'Student';
}

function applyTheme(theme) {
  const root = document.documentElement;
  if (theme === 'dark') { root.setAttribute('data-theme', 'dark'); return; }
  if (theme === 'light') { root.setAttribute('data-theme', 'light'); return; }
  const dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  root.setAttribute('data-theme', dark ? 'dark' : 'light');
}

