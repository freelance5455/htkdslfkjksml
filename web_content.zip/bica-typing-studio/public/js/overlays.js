/**
 * Full-screen overlay registry.
 *
 * The typing workspace and the arcade shell both cover the whole application.
 * Because they live outside the routed content area, a route change (back
 * button, a link inside a toast, a programmatic navigate) used to leave them
 * stranded on top of the new screen — an invisible blocker that swallowed every
 * click.
 *
 * Anything that occupies the screen registers a teardown function here. The
 * router dismisses all of them before it mounts a new screen.
 */

const teardowns = new Set();

/**
 * @param {() => void} destroy removes the overlay and its listeners
 * @returns {() => void} the unregister function
 */
export function registerOverlay(destroy) {
  teardowns.add(destroy);
  return () => teardowns.delete(destroy);
}

export function dismissOverlays() {
  for (const destroy of [...teardowns]) {
    teardowns.delete(destroy);
    try {
      destroy();
    } catch (err) {
      console.error('[bica] overlay teardown failed', err);
    }
  }
}

export function hasOverlay() {
  return teardowns.size > 0;
}
