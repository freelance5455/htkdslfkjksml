/**
 * Interface internationalisation.
 * English is complete. Bengali and Hindi are scaffolded: navigation and the
 * sign-in screen are translated so the architecture is exercised, everything
 * else falls back to English deliberately rather than showing blank strings.
 *
 * IMPORTANT: interface language is independent of typing-course language.
 * Only the English QWERTY typing curriculum is supported (see docs/LIMITATIONS).
 */

export const LANGUAGES = [
  { code: 'en', label: 'English', native: 'English', complete: true },
  { code: 'bn', label: 'Bengali', native: 'বাংলা', complete: false },
  { code: 'hi', label: 'Hindi', native: 'हिन्दी', complete: false },
];

const STRINGS = {
  en: {
    'app.name': 'BICA Typing Studio',
    'nav.learn': 'Learn',
    'nav.practice': 'Practice',
    'nav.arcade': 'Arcade',
    'nav.challenge': 'Challenge',
    'nav.progress': 'Progress',
    'nav.dashboard': 'Dashboard',
    'nav.instructor': 'Instructor',
    'nav.admin': 'Administration',
    'nav.profile': 'Profile',
    'auth.signIn': 'Sign in',
    'auth.username': 'Username',
    'auth.password': 'Password',
    'auth.signingIn': 'Signing in…',
    'auth.welcome': 'Welcome back',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.retry': 'Retry',
    'common.close': 'Close',
    'common.continue': 'Continue',
  },
  bn: {
    'app.name': 'বিকা টাইপিং স্টুডিও',
    'nav.learn': 'শেখা',
    'nav.practice': 'অনুশীলন',
    'nav.arcade': 'আর্কেড',
    'nav.challenge': 'চ্যালেঞ্জ',
    'nav.progress': 'অগ্রগতি',
    'nav.dashboard': 'ড্যাশবোর্ড',
    'nav.instructor': 'প্রশিক্ষক',
    'nav.admin': 'প্রশাসন',
    'nav.profile': 'প্রোফাইল',
    'auth.signIn': 'সাইন ইন',
    'auth.username': 'ব্যবহারকারীর নাম',
    'auth.password': 'পাসওয়ার্ড',
    'auth.signingIn': 'সাইন ইন হচ্ছে…',
    'auth.welcome': 'স্বাগতম',
  },
  hi: {
    'app.name': 'बीका टाइपिंग स्टूडियो',
    'nav.learn': 'सीखें',
    'nav.practice': 'अभ्यास',
    'nav.arcade': 'आर्केड',
    'nav.challenge': 'चुनौती',
    'nav.progress': 'प्रगति',
    'nav.dashboard': 'डैशबोर्ड',
    'nav.instructor': 'प्रशिक्षक',
    'nav.admin': 'प्रशासन',
    'nav.profile': 'प्रोफ़ाइल',
    'auth.signIn': 'साइन इन',
    'auth.username': 'उपयोगकर्ता नाम',
    'auth.password': 'पासवर्ड',
    'auth.signingIn': 'साइन इन हो रहा है…',
    'auth.welcome': 'वापसी पर स्वागत',
  },
};

let current = 'en';

export function setLanguage(code) {
  current = ['en', 'bn', 'hi'].includes(code) ? code : 'en';
  document.documentElement.setAttribute('lang', current);
}

export function getLanguage() { return current; }

export function t(key) {
  return STRINGS[current]?.[key] ?? STRINGS.en[key] ?? key;
}

export function isComplete(code) {
  return Boolean(LANGUAGES.find((l) => l.code === code)?.complete);
}
