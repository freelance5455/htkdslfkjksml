# BICA TYPING STUDIO — Security & Privacy

Scope: a single-server deployment on a training-centre LAN (Windows or Linux),
accessed by students on lab machines. There is no cloud component, no external
API, and no third-party script in the application.

---

## 1. Threat model

| Actor | Capability assumed | Primary defence |
|---|---|---|
| Student on a lab PC | Full control of their own browser: can edit JS, call the API directly, replay requests, lie about speed | Server-side recomputation, single-use tokens, server clock, role checks, append-only results |
| Curious student | Can guess URLs and IDs of classmates | Every read is filtered by ownership/class membership in SQL, not in the UI |
| Instructor | Trusted for their own classes, not for the centre | `requireClassAccess` / `canAccessStudent`, admin-only operations locked |
| Administrator | Trusted, but must be accountable | Every privileged mutation written to `audit_log` with actor and detail |
| Someone on the LAN | Can reach the port; may sniff if HTTP | Documented HTTPS path (reverse proxy), `Secure` cookies when enabled, no secrets in the client |
| Lost laptop / stolen disk | Has the SQLite file | Passwords are scrypt hashes, not recoverable; backups are `0600` |

Explicit non-goals: defending against a compromised server host, or against an
administrator who is actively malicious. Both are out of scope for a single-room
training centre and are stated here rather than silently ignored.

---

## 2. Authentication

- **Password hashing:** `scrypt` (N=16384, r=8, p=1, 64-byte key, 96 MB maxmem)
  with a 16-byte random per-user salt, stored as
  `scrypt$N$r$p$salt$hash`. Verification is `timingSafeEqual`.
- **Password length:** minimum 10 characters, enforced by `hashPassword()` and by
  every route that sets a password. No maximum below 200.
- **Sessions:** 256-bit random opaque identifier stored in `auth_sessions`.
  The cookie carries only that identifier.
- **Cookie flags:** `HttpOnly`, `SameSite=Lax`, `Path=/`, `Max-Age` equal to the
  session TTL (12 h by default), plus `Secure` when `BICA_COOKIE_SECURE=1`
  (set this behind HTTPS).
- **Expiry:** checked in SQL (`expires_at > datetime('now')`) on every request; a
  revoked session (`revoked_at`) stops working immediately because the check
  happens server-side, not in a token.
- **Generic errors:** a failed login answers "Incorrect username or password."
  regardless of which part was wrong, and takes the same time whether or not the
  user exists (the hash is always computed against a dummy value for unknown
  users).
- **Rate limiting:** in-process token bucket, 20 attempts / 15 min per IP and
  8 attempts / 15 min per username; a success clears that username's bucket.
  `429` with a human message. The limiter is per-process, which matches the
  single-process deployment (see §7 for the multi-process note).
- **First-run admin:** `npm run seed` creates one administrator and prints a
  one-time password to the console; it is not written to the database in plain
  text and must be changed at first sign-in (`must_change_pw`).

---

## 3. Authorisation

Roles: `ADMIN`, `INSTRUCTOR`, `STUDENT`.

| Layer | Mechanism |
|---|---|
| Route | `requireAuth`, `requireRole('ADMIN')`, `requireRole('INSTRUCTOR','ADMIN')` |
| Object | `canAccessStudent(db, user, studentId)`, `canAccessClass(db, user, classId)` — a student is reachable only if they are the caller; an instructor only if the student is enrolled in a class they own or co-teach |
| Query | Student-facing list endpoints filter with `WHERE student_id = ?`; there is no code path that selects all students for a student caller |
| Data shaping | Staff endpoints select the columns they need; password hashes and session ids are never included in any response |

Tested in `tests/integration.test.js`: anonymous access to five protected
endpoints (401), a student hitting `/api/admin/users` and `/api/instructor/*`
(403), a student posting a forged admin user (403), an instructor reading an
unenrolled student (403), and a student reading another student's profile (403).

---

## 4. Result integrity

Detailed in `TYPING_ENGINE.md` §4. In summary: server-issued single-use tokens,
server clock for duration, physical-plausibility ceilings, unique client session
ids for idempotent replay, and no update path for a stored result.

---

## 5. Web hardening

Response headers set in `server/app.js` for every response:

```
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';
  img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none';
  base-uri 'none'; form-action 'self'; frame-ancestors *
X-Content-Type-Options: nosniff
Referrer-Policy: same-origin
Permissions-Policy: geolocation=(), microphone=(), camera=()
Cross-Origin-Resource-Policy: same-origin
```

Notes on two deliberate choices:

- `style-src 'unsafe-inline'` is required because the UI sets element styles
  through the DOM (bars, meters, charts). Script injection is still blocked:
  `script-src 'self'` with **no** `unsafe-inline` and **no** `unsafe-eval`.
- `frame-ancestors *` allows the app to run inside a lab portal or an embedded
  preview frame. If BICA is exposed beyond the lab, tighten this to the portal
  origin.

Other measures: JSON body limit 512 KB (`express.json({ limit })`), no
`x-powered-by`, all SQL parameterised, all inputs validated by
`server/lib/validate.js` (unknown fields rejected, lengths capped, enums
checked), CSV export neutralises leading `= + - @` to prevent spreadsheet formula
injection, and `path.basename()` + a filename regex on any user-supplied filename
(backup download).

---

## 6. Data protection and student privacy

- **Minimisation.** An account stores: username, display name, role, password
  hash, active flag, preferences. Email and phone are optional and unused by the
  product. No address, photo, biometric data or date of birth.
- **Keystroke data.** Only aggregates are stored (`perKey` counters per session,
  rolling `key_statistics` per student). Raw keystroke timing streams are never
  persisted, so a result cannot be reconstructed into someone's typing
  behaviour outside the exercise.
- **Leaderboards.** Display name only, and only if `features.publicNames` is on;
  otherwise the board shows an assigned identifier. Competitive features and
  leaderboards can each be switched off centre-wide
  (`features.competitive`, `features.leaderboards`).
- **No student-to-student messaging.** There is no chat, comment or direct
  message feature anywhere in the product.
- **Exports.** CSV and PDF leave the server only through an authorised endpoint,
  and every export of a student report is audited.
- **Deletion.** `DELETE /api/admin/demo-data` removes seeded demo accounts;
  individual students are deactivated rather than deleted so their results stay
  attributable, and a real erasure request is handled by an administrator with a
  documented database backup taken first.

---

## 7. Deployment hardening checklist

For the operator — these are configuration steps, not code:

1. Run behind HTTPS (nginx/Caddy/IIS) and set `BICA_COOKIE_SECURE=1`,
   `BICA_TRUST_PROXY=1`.
2. Set `BICA_SECRET` explicitly (or protect `data/.app_secret`, which is created
   `0600`) and back it up: certificate verification codes are derived from it.
   **If the secret changes, previously printed verification codes stop matching.**
3. Change the seeded administrator password at first sign-in; delete demo
   accounts (`Admin → Users → Remove demo data`) before real students are created.
4. Store `data/` on a disk that is backed up; keep backups on a *different* disk
   or drive (`BICA_BACKUP_DIR`).
5. Bind to the LAN interface only; do not port-forward to the internet unless a
   reverse proxy with TLS and authentication is in front.
6. Keep Node 20 LTS patched. `npm audit` is not part of the runtime; the
   dependency footprint is `express` + `better-sqlite3` (+ `playwright-core` as a
   dev-only test tool), which is deliberate.

**Multi-process note.** The rate limiter is in-process. If BICA is ever run under
a cluster or several instances, move the limiter to a shared store (or front the
app with a proxy that limits login attempts). Every other security control is
stateful in SQLite and is unaffected.

---

## 8. Incident response (short form)

1. Stop the server; keep `data/bica.db` and the WAL file as they are.
2. Copy `data/` to a safe location before investigating (the database is
   `data/bica.db`; `-wal`/`-shm` belong to it).
3. Review `audit_log` for the window in question (Admin → Audit log).
4. Revoke affected sessions: `DELETE FROM auth_sessions WHERE user_id = ?` (or
   on suspicion of a shared machine, `WHERE ip = ?`), then force password resets
   from Admin → Users.
5. Restore from a known-good backup only after preserving the current file — see
   `RECOVERY.md`.
