# BICA TYPING STUDIO — Deployment

Two supported topologies. Both use the same code, the same single SQLite file and
no cloud service.

1. **Lab server (recommended).** One PC in the lab runs the app; every student
   machine reaches it over the LAN. Backups, upgrades and the database live in one
   place.
2. **Single machine.** One instructor PC used by one student at a time, or by the
   instructor alone for demonstrations and report work.

---

## 1. Requirements

| Item | Requirement |
|---|---|
| Node.js | 20 LTS or newer (`node -v` must print v20+) |
| OS | Windows 10/11, Ubuntu 22.04+/Debian 12+, or macOS 13+ |
| RAM | 512 MB free is ample for 200 students |
| Disk | < 100 MB for the app; database grows ~1–2 MB per 1,000 sessions |
| Network | LAN only. No internet access is required at runtime |
| Browser | Chrome/Edge/Firefox/Safari, current versions. Physical keyboard required for real use |

SQLite is bundled (`better-sqlite3`); there is no database server to install.

---

## 2. First install

```bash
# 1. unzip somewhere permanent, e.g. C:\BICA\typing  or  /opt/bica-typing
cd bica-typing-studio

# 2. install production dependencies only
npm ci --omit=dev

# 3. create the first administrator (prints a one-time password)
npm run seed

# 4. start
npm start
```

`npm run seed` creates one `ADMIN` account and prints its one-time password to
the console **once**. Sign in and you will be held on the Profile screen until
you set your own password (enforced server-side).

`npm run seed:demo` additionally creates clearly flagged demo accounts
(`instructor`, `student1`, `student2`) with the password `BicaDemo2026!`. Use it
for training staff, then remove them with **Admin → Users → Remove demo data**
before real students exist.

Open `http://<server-ip>:8080` from a student machine.

---

## 3. Configuration

All configuration is environment variables; there is no config file to edit.

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `8080` | Listening port |
| `HOST` | `0.0.0.0` | Bind address. Use `127.0.0.1` behind a reverse proxy |
| `BICA_DB` | `data/bica.db` | Database file path |
| `BICA_SECRET` | generated, stored in `data/.app_secret` (`0600`) | HMAC key for certificate verification codes. **Back it up**; changing it invalidates printed codes |
| `BICA_BACKUP_DIR` | `data/backups` | Where `npm run backup` writes snapshots. Point this at a different disk |
| `BICA_SESSION_HOURS` | `12` | Session lifetime |
| `BICA_COOKIE_SECURE` | `0` | Set to `1` when served over HTTPS |
| `BICA_TRUST_PROXY` | `0` | Set to `1` behind nginx/Caddy/IIS so client IPs are correct |
| `BICA_ORG` | `BICA Computer Training Centre` | Organisation name used in reports |
| `NODE_ENV` | `development` | `production` for a real deployment |
| `BICA_ADMIN_USER` / `BICA_ADMIN_PASSWORD` | — | Optional: seed a specific administrator instead of a random password |

Centre-wide behaviour (mastery thresholds, certificate criteria, feature
switches, exam defaults) is set in the running app under **Admin → Settings**,
not in the environment. Values are validated server-side against a schema with
minimums and maximums.

---

## 4. Running it as a service

### Windows (the common case in an Indian training centre)

Use the built-in Task Scheduler: *Create Task → Run whether user is logged on or
not → Trigger: At startup → Action: Start a program*.

- Program: `C:\Program Files\nodejs\node.exe`
- Arguments: `server\index.js`
- Start in: `C:\BICA\typing\bica-typing-studio`

Set the environment variables in *System Properties → Environment Variables*, or
use a small `.cmd` wrapper:

```bat
@echo off
cd /d C:\BICA\typing\bica-typing-studio
set NODE_ENV=production
set PORT=8080
"C:\Program Files\nodejs\node.exe" server\index.js >> logs\server.log 2>&1
```

Allow the port through Windows Firewall for the local subnet only:

```powershell
New-NetFirewallRule -DisplayName "BICA Typing Studio" -Direction Inbound -Protocol TCP `
  -LocalPort 8080 -RemoteAddress LocalSubnet -Action Allow
```

### Linux (systemd)

```ini
# /etc/systemd/system/bica-typing.service
[Unit]
Description=BICA Typing Studio
After=network.target

[Service]
Type=simple
User=bica
WorkingDirectory=/opt/bica-typing/bica-typing-studio
Environment=NODE_ENV=production PORT=8080 HOST=0.0.0.0
ExecStart=/usr/bin/node server/index.js
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload && sudo systemctl enable --now bica-typing
sudo journalctl -u bica-typing -f      # logs
```

---

## 5. HTTPS (recommended once it leaves the lab)

Caddy is the shortest path and needs three lines:

```
typing.bica.local {
  reverse_proxy 127.0.0.1:8080
}
```

Then start the app with `HOST=127.0.0.1 BICA_TRUST_PROXY=1 BICA_COOKIE_SECURE=1`.
Behind nginx, add `proxy_set_header X-Forwarded-For $remote_addr;` and
`proxy_set_header X-Forwarded-Proto $scheme;`.

The application sets a strict CSP (`script-src 'self'`, no `unsafe-eval`) and
serves no third-party assets, so a proxy only needs to pass traffic through.

---

## 6. Backups

```bash
npm run backup                       # snapshot to data/backups (or BICA_BACKUP_DIR)
node server/backup.js list           # list snapshots
node server/backup.js restore <file>  # restore — stop the server first
```

Snapshots use SQLite's online backup API, so they are consistent even while
students are typing. Files are written `0600`. Schedule `npm run backup` daily
(Task Scheduler / cron) and copy `data/backups` to a different disk weekly.

**Also back up `data/.app_secret`** (or your `BICA_SECRET`): without it,
previously issued certificate verification codes can no longer be reproduced.

See `RECOVERY.md` for a full restore drill.

---

## 7. Upgrading

```bash
npm run backup            # always first
# replace the application files, keeping data/ intact
npm ci --omit=dev
npm start                 # migrations run automatically on boot
```

Migrations are forward-only and numbered (`server/migrations/*.sql`); each runs
once and is recorded in `schema_migrations`. The boot log prints which ones were
applied. There is no down-migration: roll back by restoring the backup, which is
why the backup is step one.

---

## 8. Verification after deployment

```bash
curl -s http://localhost:8080/api/public/health      # {"ok":true,...}
npm test                                              # engine + HTTP contract tests
npm run check                                         # front-end module graph
```

Then in a browser: sign in, complete one 15-second practice session, confirm the
result screen says *Verified result*, open **Progress** and confirm the session
appears. If it does, keystrokes, measurement, persistence and reporting are all
working end to end.

---

## 9. Operational notes

- **Time zone.** Session times are stored in UTC and rendered in the browser's
  local zone. Do not change the server clock backwards; the plausibility checks
  use it.
- **Lab machines without a permanent home page.** Point the browser to
  `http://<server>/` and use the kiosk/multikiosk mode of the browser if students
  should not browse elsewhere.
- **Students sharing a machine.** Each must sign out; the session cookie is
  per-browser-profile. If shared profiles are unavoidable, shorten
  `BICA_SESSION_HOURS` (e.g. 1) and enable **Admin → Settings → offline queue**
  off if you do not want queued work crossing accounts.
- **Power cuts.** SQLite in WAL mode recovers automatically; the offline queue in
  the browser holds unsent results and replays them when the LAN returns.
- **Scaling.** One process, one file, comfortably handles a room of 30–200
  concurrent students. Beyond that, move the database to PostgreSQL (the SQL is
  portable except for a handful of date functions) rather than running multiple
  processes against one file.
