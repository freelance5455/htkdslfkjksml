# BICA TYPING STUDIO — Final Report

**Product:** BICA Typing Studio — typing education, practice, arcade and classroom
management for BICA Computer Training Centre
**Version:** 1.0.0
**Runtime:** Node.js 20 LTS, SQLite (WAL), no external services
**Dependencies:** `express`, `better-sqlite3` (runtime); `playwright-core` (tests only)

---

## 1. What was delivered

| Area | Delivered |
|---|---|
| **Learn** | 7 levels, 50 lessons, finger-position coaching, live keyboard guidance, mastery gated on measured accuracy (server-decided), per-lesson drills, per-lesson result reports |
| **Practice** | 18 presets across words / patterns / personal / real-world, timed (15 s – 10 min) and fixed-word modes, custom passages, backspace and HUD toggles, examination mode, and a standalone analyser for typing done elsewhere |
| **Arcade** | 12 independently implemented games with 3 difficulties each, instructions, pause/restart, live HUD, server-verified results, per-game personal bests and a class leaderboard |
| **Challenge** | Daily and weekly challenges with server-generated passages, personal bests, class/weekly/monthly leaderboards, privacy switch for names |
| **Progress** | Speed and accuracy history, per-key heatmap, weak-key ranking, consistency, achievements, certificates, game history |
| **Instructor** | Dashboard KPIs, classes, enrolment, student profiles, assignments, typing-test authoring, certificate issuing, CSV export, PDF reports, notes |
| **Admin** | Users, classes, settings (mastery, exam, certificate, feature switches), audit log, backups, sync status, centre-wide analytics |
| **Certificates** | Criteria-gated issuance, unique number, HMAC verification code, PDF download, public verification page, revocation |
| **Platform** | Offline shell + IndexedDB result queue with idempotent replay, strict CSP, role checks enforced server-side, one-file backup/restore |

Size: ~16,000 lines of hand-written JavaScript, SQL, CSS and HTML across 93 files;
zero build step; 737 lines of CSS design system.

---

## 2. Verification log

Everything below was run in this environment against the delivered code.

| Suite | Command | Result |
|---|---|---|
| Module graph (every relative import resolves) | `npm run check` | 54 files, 126 imports — clean |
| Typing-engine unit tests | `npm test` | 27/27 |
| HTTP integration tests (auth, RBAC, verification, certificates, exports, rate limiting) | `npm test` | 27/27 |
| Browser end-to-end (practice, lesson, challenge, all 12 games, instructor, admin, every screen per role) | `npm run test:e2e` | **57/57** |
| Strict-CSP browser pass (no `unsafe-eval`, real policy) | `npm run test:csp` | no violations |
| Offline queue (drop network mid-session, replay on reconnect) | `npm run test:offline` | **6/6**, exactly one verified row |

Total: **54 automated tests + 57 browser checks + 6 offline checks**, all passing
on the delivered tree.

Notable behaviours proven, not asserted:

- A practice session is submitted, recomputed and stored server-side; the result
  screen shows the server's numbers, and refuses client-declared WPM.
- An impossibly fast submission is rejected (`422`); a replayed client id returns
  the original row instead of a duplicate.
- A sloppy lesson attempt does **not** master the lesson.
- All 12 games open, draw to canvas, accept keystrokes and quit cleanly.
- Instructor CSV export and student PDF report download real files.
- A certificate is refused below criteria, then issued, verified, revoked and
  refused again — and a student cannot issue one for themselves.
- With the network cut mid-exercise, the result is saved locally, queued, and
  submitted exactly once when the connection returns.

---

## 3. Defects found and fixed in this pass

The build inherited from the earlier session rendered, but several core flows
were broken. Each of these was reproduced in a browser, fixed, and covered by a
test:

| # | Defect | Effect | Fix |
|---|---|---|---|
| 1 | The router never mounted a view's output | **Every screen after sign-in was blank** | Route handlers now go through `renderRoute`, which owns the mount point, loading state, error panel and cleanup |
| 2 | `renderWindow` ↔ `updateChar` mutual recursion | `RangeError: Maximum call stack size exceeded` while typing | Window rendering and glyph painting are now one-directional; the cursor is tracked explicitly |
| 3 | The typing workspace used `mount(document.body, …)` | Opening any lesson **wiped the application shell** | Append instead of mount, with the reason recorded in the code |
| 4 | The result overlay was appended to `<body>` and never removed | An invisible blocker over the whole app after a session | The result renders inside the workspace container and is destroyed with it |
| 5 | `serverResult` used outside its scope in the "Continue" button | Continue did nothing; the screen could not be closed | Handler uses values passed into the result view |
| 6 | `intervals` were never sent to the server | Consistency always displayed `0%` | Rhythm samples are submitted and recomputed server-side |
| 7 | Free navigation away from a session left typing/game overlays alive | Stuck modal, swallowed clicks | Added `public/js/overlays.js`; the router dismisses every overlay on route change |
| 8 | `manifest.webmanifest` missing | 404 on every page load; no installability | Added, with icons and shortcuts |
| 9 | `GET /api/admin/backups` called `backupDir()` without config | 500 on the Backups screen | Config passed through |
| 10 | Two staff views imported symbols that do not exist (`badge` from `ui.js`, `emptyState` from `_staff.js`) | Assignments and Typing-tests screens failed to open | Imports corrected; `scripts/check-modules.mjs` now catches this class of bug for every view and game at once |
| 11 | Arcade ignored `?game=` links used by the dashboard and the adaptive engine | "Play this game" recommendation went to the arcade index | Deep link opens the game's setup sheet |
| 12 | `must_change_pw` was set but never enforced; the profile read `mustChangePassword` | One-time passwords never had to be changed | Enforced server-side (403 until changed) and in the router; flag name corrected |
| 13 | The login limiter counted successful sign-ins against the IP; unknown usernames skipped scrypt | A whole lab could lock itself out; username enumeration by timing | Only failures accumulate; a dummy hash is verified for unknown accounts |
| 14 | Game rounds that ended quickly were rejected as cheating | A beginner losing in ten seconds was told their attempt was fake | Now recorded as `verified = 0` with a zero score and an explanation; still cannot reach a leaderboard |
| 15 | A flat 1.5 s floor on untimed drills | A fast student finishing a 17-character drill was refused | Floor lowered to 350 ms; per-character plausibility does the real work |
| 16 | Certificate `minLevel: 0` was stricter than `minLevel: 1` | Switching the requirement off made it impossible to satisfy | `minLevel: 0` now means "no level requirement", with the label to match |
| 17 | The demo database contained a 409.6 WPM session from earlier testing | Dashboard figures were nonsense | Removed, and the plausibility guard that should have blocked it was verified |
| 18 | Service worker cached only a fraction of the modules | "Works offline" was only half true | Full shell list generated from the tree; cache version bumped |
| 19 | Dead `void identifier;` lint artifacts, including `const dlg = formDialog; void dlg;` | Noise that hid real problems | Removed; the one meaningful case rewritten |

---

## 4. Documentation set

| Document | Contents |
|---|---|
| `README.md` | What it is, quick start, commands, where to read next |
| `docs/ARCHITECTURE.md` | Component map, data model, trust boundaries, offline model |
| `docs/TYPING_ENGINE.md` | Formulas, input handling, anti-manipulation rules, emitted data |
| `docs/RESEARCH.md` | Competitor research that shaped the feature set |
| `docs/SECURITY.md` | Threat model, authentication, authorisation, hardening, incident response |
| `docs/DEPLOYMENT.md` | Install, Windows service, systemd, HTTPS, backups, upgrade |
| `docs/KNOWN_LIMITATIONS.md` | 25 honest limitations, including what is *not* implemented |
| `docs/RECOVERY.md` | Backup strategy, restore drill, disaster scenarios |
| `docs/FINAL_REPORT.md` | This document |

---

## 5. What is deliberately not done

Stated in the product and in `docs/KNOWN_LIMITATIONS.md`:

- **Bengali/Hindi typing curricula** — needs IME handling, glyph-cluster
  comparison and layout-specific finger maps. The interface language selector is
  interface-only, and says so.
- **Real-time multiplayer** — Speed Circuit's opponents are deterministic computer
  cars, described as such.
- **Cloud sync** — offline is a browser-side queue with idempotent replay, not a
  sync engine.
- **Desktop installer** — a browser pointed at a LAN server was chosen
  deliberately; Tauri/Electron is documented as a future option.
- **External accreditation** — certificates state plainly that they are internal
  to the centre.

---

## 6. Recommended next steps (in order)

1. **Install on the lab server** (`docs/DEPLOYMENT.md`), set your own administrator
   password, delete demo accounts.
2. **Run one real class through a week** of lessons and practice. The adaptive
   recommendations and weak-key analysis only become useful after ~10 sessions
   per student.
3. **Set mastery and certificate thresholds** to match how BICA actually certifies
   students (Admin → Settings).
4. **Schedule the daily backup** and perform the restore drill in
   `docs/RECOVERY.md` once.
5. Then consider, in this order: Bengali/Hindi curriculum work (largest teaching
   value), a print stylesheet polish pass for certificates, and an XLSX export if
   instructors keep asking for it.

---

## 7. Honest summary

This is a working product, not a demonstration: students can learn, practise,
play, be measured, be reported on and be certified, and every one of those paths
has been driven end to end in a real browser against the real server.

The parts most likely to matter in daily use — accuracy-gated progression,
verified results, weak-key feedback, class reports, offline resilience — are
implemented and tested. The parts that are hard, slow or require language work
(Bengali curricula, real-time competition, desktop packaging) are not pretended;
they are documented as missing.
