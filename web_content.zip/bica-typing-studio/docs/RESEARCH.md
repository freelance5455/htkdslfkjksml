# BICA TYPING STUDIO — Phase 1 Research Report

**Prepared for:** BICA Computer Training Centre
**Date:** 2026-10-31
**Status:** Research complete — architecture decisions locked in `ARCHITECTURE.md`
**Author role:** product/architecture research pass

---

## 0. Method and evidence standard (read this first)

This report separates three grades of evidence, and every claim below is tagged:

| Tag | Meaning |
|---|---|
| **[V]** Verified from primary/official documentation or a first-party product page reached during research | Highest confidence |
| **[S]** Verified from an independent third-party review/comparison published in 2025–2026 | Good confidence, second-hand |
| **[A]** Assumption, inference or market judgement by this team | Must be validated with real students |

**Honest limitation, stated up front:** this research was desk-based. We read official product documentation, published feature descriptions and independent 2025–2026 comparison reviews, but we did **not** purchase TypingMaster 12, Typesy or Typing Agent licences, and we did not create teacher accounts on TypingClub/Typing.com (both require a school onboarding flow). Therefore claims about those products' teacher dashboards are **[S]**, not **[V]**. Where the report says a competitor does something, it means "their documentation and independent reviews say they do it". Any competitor behaviour that BICA's design depends on is re-verified against our own implementation during QA (see `FINAL_REPORT.md`).

The single most important research conclusion is that **we are not trying to out-feature TypingClub on lesson count**. TypingClub ships 600+ lessons [S]; no six-week build can honestly match that. BICA's defensible position is different: *a centre-owned system of record* — instructor-controlled mastery gates, verified results, real reports, offline resilience in low-connectivity labs, and a game arcade that is curriculum-linked rather than a reward toy. That is what a training institute in Asansol actually needs and what the global consumer products structurally do not provide.

---

## 1. The competitive set

Eight products were in scope. Seven were requested; Monkeytype, TypeRacer and Typing Agent surfaced during research and were added because they set the bar for specific sub-features.

| # | Product | Category | Primary user | Model |
|---|---|---|---|---|
| 1 | TypingMaster 12 (Pro / Typing Test) | Installed desktop course | Institute / school lab, Windows | Paid, per-seat, installed |
| 2 | Typing.com | Web curriculum + games | K-12 classroom | Free w/ ads, PLUS paid |
| 3 | Keybr | Adaptive drill engine | Independent adult learner | Free, optional premium |
| 4 | Nitro Type | Multiplayer racing game | Motivated teens | Free, optional Gold |
| 5 | Ratatype | Test + certificate, light course | Job-seeker | Free |
| 6 | TypingClub (EdClub) | Deep web curriculum | K-12 classroom | Free w/ ads, School Edition paid |
| 7 | Typesy | Premium course + admin suite | School / adult | Paid |
| 8 | Monkeytype / TypeRacer / Typing Agent (added) | Stats-first test / live race / paid K-12 suite | Enthusiast / classroom | Mixed |

---

## 2. Competitor comparison table

Ratings are relative to the whole set: ● strong, ◐ partial, ○ weak/absent.

### 2.1 Learning system

| Capability | TypingMaster 12 | Typing.com | Keybr | Nitro Type | Ratatype | TypingClub | Typesy | **BICA target** |
|---|---|---|---|---|---|---|---|---|
| Structured beginner→advanced curriculum | ● 12 courses, ~10h+ [S] | ● K-12 units [S] | ○ adaptive only [S] | ○ none, game-first [S] | ◐ short course [S] | ● 600+ lessons [S] | ● courses + drills [S] | ● 7 levels, 50 lessons, gated |
| Home-row / finger placement instruction | ● | ● | ◐ | ○ | ● | ● with animated hands [S] | ● | ● with live per-finger prompts |
| Progressive key introduction | ● | ● | ● algorithmic | ○ | ◐ | ● | ● | ● explicit per-lesson key sets |
| Weak-key detection | ● "Smart Review" [S] | ◐ | ● core method [S] | ○ | ● char-level diagnostics [S] | ◐ | ● | ● per-key error-rate engine |
| Personalised practice from real data | ● | ◐ | ● pseudo-word generation [S] | ○ | ◐ | ◐ | ● | ● deterministic adaptive queue |
| Accuracy gate before speed | ◐ configurable goals [S] | ◐ | ● | ○ penalises loosely | ◐ | ● star ratings [S] | ◐ | ● default 95%, instructor-configurable |
| Custom institute content | ○ (import test texts only) [S] | ◐ | ○ | ○ | ○ | ◐ | ◐ | ● passage editor + assignment |
| Lesson length discipline | ● 3–5 min "bite size" [S] | ● short [S] | ● | n/a | ◐ | ● 2–5 min [S] | ● | ● 2–4 min target per drill |

### 2.2 Gamification

| Capability | TypingMaster | Typing.com | Keybr | Nitro Type | Ratatype | TypingClub | Typesy | **BICA target** |
|---|---|---|---|---|---|---|---|---|
| Number of games | ● several [S] | ● ~7 [S] | ○ | ○ one game | ○ | ◐ some [S] | ● arcade [S] | ● **12 distinct** |
| Games tied to curriculum keys | ○ | ◐ | ○ | ○ random quotes [S] | ○ | ○ | ◐ | ● key-set scoping per game level |
| Real competitive multiplayer | ○ | ◐ scoreboard [S] | ◐ online race | ● real-time races, teams, seasons [S] | ○ | ○ | ◐ | ○ **not claimed** (see §8 risk) |
| Achievements / badges | ● | ● | ◐ | ● | ● | ● | ● | ● 18 real, state-derived |
| Daily/weekly challenge | ○ | ◐ | ○ | ● seasons [S] | ◐ daily test | ◐ | ◐ | ● deterministic daily + weekly |
| Accuracy weighted in score | ◐ | ◐ | ● | ◐ speed-dominant [S] | ● | ◐ | ◐ | ● score × accuracy² |

### 2.3 Analytics

| Capability | TypingMaster | Typing.com | Keybr | Nitro Type | Ratatype | TypingClub | Typesy | **BICA target** |
|---|---|---|---|---|---|---|---|---|
| WPM + accuracy | ● | ● | ● | ● | ● | ● | ● | ● gross, net, accuracy, consistency |
| Per-key error analytics | ● | ◐ | ● | ○ | ● | ◐ | ● | ● heatmap + error rate per key |
| Bigram/trigram timing | ● v12 bigram heatmaps [S] | ○ | ◐ | ○ | ○ | ○ | ◐ | ● bigram timing analysis |
| Consistency metric | ○ | ○ | ◐ | ○ | ○ | ○ | ◐ | ● CV-based consistency score |
| Historical progress charts | ● | ● | ● | ◐ | ● | ● | ● | ● session history + trend |
| Institute-wide analytics | ● network edition [S] | ● | ○ | ◐ | ○ | ● | ● | ● admin centre analytics |

### 2.4 Classroom / institute management

| Capability | TypingMaster | Typing.com | Keybr | Nitro Type | Ratatype | TypingClub | Typesy | **BICA target** |
|---|---|---|---|---|---|---|---|---|
| Classes + enrolment | ● | ● free roster sync [S] | ○ | ● portal [S] | ○ | ● | ● | ● |
| Assign lessons/deadlines | ● | ● | ○ | ◐ | ○ | ● | ● | ● |
| Per-student report + notes | ● | ● | ○ | ◐ | ○ | ● | ● | ● + instructor notes |
| CSV/PDF export | ◐ print reports [S] | ◐ | ○ | ○ | ◐ | ● | ● | ● CSV + PDF |
| Configurable pass marks / mastery | ● custom pass limits [S] | ◐ | ○ | ○ | ◐ | ◐ | ◐ | ● per-centre, per-level |
| Instructor-created tests | ● | ● | ○ | ○ | ○ | ● | ● | ● passage editor |
| Certificate issuing + verification | ◐ prints certificate [S] | ○ | ○ | ○ | ● shareable cert [S] | ○ | ◐ | ● numbered + HMAC verifiable |

### 2.5 Technical / delivery

| Capability | TypingMaster | Typing.com | Keybr | Nitro Type | Ratatype | TypingClub | Typesy | **BICA target** |
|---|---|---|---|---|---|---|---|---|
| Offline usable | ● installed desktop [S] | ○ | ○ | ○ | ○ | ○ | ○ | ● offline-first web (staged) |
| Low-bandwidth tolerance | ● LAN/server [S] | ◐ | ◐ | ○ | ◐ | ◐ | ◐ | ● local server on lab LAN |
| Data ownership by institute | ● local DB / network [S] | ○ cloud | ○ | ○ | ○ | ○ cloud | ○ cloud | ● SQLite file you own + backup |
| Windows desktop priority | ● native | ◐ | ◐ | ◐ | ◐ | ◐ | ◐ | ● desktop-first responsive |
| Mobile usable | ○ | ● | ◐ | ● | ● | ● | ◐ | ◐ navigation/account usable, typing not promised |
| Unicode / non-Latin typing | ◐ v12 adds Unicode + Hindi layout [S] | ◐ | ○ mostly Latin [S] | ○ | ◐ | ◐ | ◐ | ○ **staged — see §8** |
| Keyboard layout switching | ● v12 Colemak/Hindi etc. [S] | ◐ | ● many layouts [S] | ○ | ◐ | ◐ | ◐ | ○ QWERTY only in v1 (honest) |

### 2.6 UX / design read

| Product | Design character | Notable strength | Notable weakness |
|---|---|---|---|
| TypingMaster 12 | Dated desktop chrome, functional | Information density, "Satellite" real-world typing monitor [S] | Visually dated; Windows-only; installed [S] |
| Typing.com | Bright, school-ish, card-heavy | Frictionless rostering, free teacher tools [S] | Ads on free tier [S]; gamification feels bolted on |
| Keybr | Minimal, graph-forward | Best-in-class honesty of measurement [S] | Nonsense-word text; no course; sparse UI [S] |
| Nitro Type | Loud, arcade, shop-driven | Retention through progression and races [S] | Not instructional; social distraction [S] |
| Ratatype | Clean, certificate-forward | Clear certificate + char diagnostics [S] | Thin curriculum |
| TypingClub | Polished, gentle, animated hands | Best beginner visual feedback; accessibility presets [S] | Ads on free [S]; single-curriculum feel past beginner [S] |
| Typesy | Corporate-clean | Admin depth | Paid; heavy |

---

## 3. Strengths and weaknesses, product by product

**TypingMaster 12.** Strength: it is the closest analogue to BICA's actual context — installed in labs, multi-user, teacher reports, network-shared history, configurable pass marks, bigram heatmaps, and the *Satellite* concept of measuring typing in Word/Excel rather than only inside the tutor [S]. Weakness: platform lock (Windows, installed) [S], dated interface, and course content that cannot be edited by the institute [S]. Lesson for BICA: **the institute wants a system of record, not a lesson player.** Also: the "measure the student in their real work" idea is excellent and is partially reachable in a web app via a paste-in free-typing analyser (implemented as *Free Typing Analysis* in BICA practice).

**Typing.com.** Strength: zero-friction classroom adoption, free roster sync, K-12 curriculum breadth, seven games [S]. Weakness: the free experience is ad-supported [S]; the games are separate from the pedagogy; analytics are coarse. Lesson: **assignments and deadlines must be first-class, not a plugin.**

**Keybr.** Strength: the most intellectually honest measurement in the market — generated pseudo-words target the learner's specific weak keys, so word-recognition shortcuts cannot inflate speed [S]. Weakness: no course, no classroom, no certificate, nonsense text builds key accuracy but not prose fluency [S]. Lesson: **ship the adaptive idea, but with real English words and sentences** so both key accuracy and word-level fluency develop. This is BICA's adaptive engine (§ Part 8 of prompt).

**Nitro Type.** Strength: the best retention engine in the category — races, teams, seasons, shops, progression [S]. Weakness: explicitly not a teaching tool; no finger placement; random passages; public social layer unsuitable for an institute [S]. Lesson: **borrow the loop (short sessions, visible progression, immediate feedback), reject the public social layer.** BICA deliberately has no student-to-student messaging and no public profiles.

**Ratatype.** Strength: clear certificate flow and character-level error diagnostics; job-seeker framing [S]. Weakness: shallow curriculum. Lesson: **certificates must be real documents with verifiable identifiers, and must state their scope honestly** (institute-issued, not accredited).

**TypingClub.** Strength: the reference standard for beginner sequencing, animated hand guidance, star ratings that encode accuracy thresholds, accessibility presets for blind/low-vision/one-handed learners, and voice-over [S]. Weakness: ad-supported free tier; a single straight-line curriculum that stops being the right tool past beginner stage [S]. Lesson: **accuracy-gated stars are a better motivational primitive than XP**, and accessibility is not optional in a government-funded lab.

**Typesy.** Strength: adult/professional framing with admin depth. Weakness: paid, cloud-only. Lesson: professional tone is a differentiator — BICA's Instructor and Admin environments should feel like operational software, not a kids' app.

**Monkeytype (added).** Strength: the deepest result model in existence — raw/net WPM, consistency, per-character history, and honest documentation of formulas. Lesson: **adopt its formula transparency**, publish BICA's exact formulas in-app so results are auditable.

**TypeRacer (added).** Strength: live human racing on real quotes. Weakness: unsuitable/unmoderated for minors, and it is a race, not a lesson. Lesson: BICA does not implement live multiplayer in v1 and does not pretend to; a bot-opponent racing game is clearly labelled as such.

**Typing Agent (added).** Strength: paid, ad-free, full suite with roster sync. Confirmatory: institutes will pay for a clean, ad-free, managed experience — BICA's internal deployment model fits that demand without subscriptions.

---

## 4. Features BICA should adopt conceptually

1. **Accuracy-gated progression** (TypingClub's stars): mastery requires accuracy, not attendance. Default 95%, instructor-configurable per level.
2. **Per-key weak-spot detection + targeted drill generation** (Keybr, TypingMaster Smart Review): implemented as a deterministic engine over real stored keystroke data.
3. **Bite-sized drills** (TypingMaster): 2–4 minute exercises, because lab periods are short.
4. **Bigram/trigram analytics and heatmaps** (TypingMaster 12).
5. **Instructor-created tests and custom passages** (TypingMaster/Typing.com).
6. **Institutional multi-user model with per-student reports** (TypingMaster network edition).
7. **A real certificate artefact with a verifiable number** (Ratatype) — honestly scoped.
8. **Visible progression and short reward loops** (Nitro Type), without public social features.
9. **Formula transparency in the UI** (Monkeytype) — BICA prints its own WPM/accuracy definitions in the results panel.
10. **Accessibility presets** (TypingClub): high contrast, reduced motion, larger target text, full keyboard navigation.
11. **Real-world typing analysis** (TypingMaster Satellite): paste-in analysis of arbitrary text.
12. **Ad-free, distraction-free examination mode** — BICA's structural advantage over free tiers.

## 5. Features BICA should improve on

| Competitor behaviour | BICA improvement |
|---|---|
| Games decoupled from curriculum (Typing.com, Nitro Type) | Each game runs against a **key-set filter** derived from the student's current lesson level, so arcade play reinforces current material |
| Speed-dominant game scoring (Nitro Type) | `score = base × accuracy²`; a 95% run beats a 70% run even at higher raw speed, and the HUD shows the multiplier live |
| Opaque WPM/accuracy formulas (most) | Formulas documented in the UI and in `docs/TYPING_ENGINE.md`; server recomputes from raw counters |
| Client-trusted results (all web products) | Server-issued signed session token + server-side elapsed clock + idempotent client session IDs, so refreshing/replaying cannot improve a score |
| Cloud-only data (most) | Institute owns a local **SQLite** database, nightly file backup, CSV/PDF export on demand |
| Progress lost on refresh (consumer sites) | IndexedDB offline queue with explicit *Saved locally / Pending sync / Synced / Failed* states |
| Generic printable certificates | Certificate number + HMAC verification endpoint; states issuer, scope and non-accreditation |
| Stars/XP only | 18 achievements computed from real state; no achievement can be earned by clicking |

## 6. Missing opportunities in the market (BICA's wedge)

1. **Instructor-configurable mastery policy at the centre level.** Consumer products impose their own thresholds. A centre running a 3-month certificate course needs to set "95% accuracy AND 25 WPM before Unit 3 unlocks", per batch.
2. **Low-connectivity lab resilience.** Indian institutes often have erratic broadband; browser-first tools degrade badly. A locally hosted, offline-tolerant app is a genuine differentiator that none of the global products offer.
3. **Honest, exam-grade verification.** "Verified" results (server-validated, session-token-bound, replay-proof) are rare outside typing championships; institutes issuing certificates need tamper-evident records.
4. **A games arcade that is pedagogically accountable.** Games report the same keystroke-level metrics as lessons, so game time counts toward documented practice minutes instead of being invisible.
5. **Bilingual readiness without false claims.** Interface i18n scaffold for Bengali/Hindi, while explicitly *not* claiming Bengali/Hindi typing support until Unicode IME input, rendering and scoring are actually tested (see §8).
6. **Cost structure.** Zero per-seat licensing means an institute can add 200 students without a procurement cycle.

## 7. Recommended architecture (summary — full detail in `ARCHITECTURE.md`)

- **Single deployable Node.js service** (Express + better-sqlite3), serving a static ES-module frontend and a JSON API. Chosen over Next.js+Supabase because: (a) the institute must own and be able to back up its data as one file, (b) no cloud account is required to run a lab, (c) no build toolchain means the app can be repaired on-site by any developer, (d) it runs in offline LAN mode.
- **Isomorphic typed engine** in `/shared` imported by both browser and Node tests — one trusted measurement implementation.
- **Server is the authority** for: elapsed time, score recomputation, mastery gating, role permissions, certificate issuance.
- **SQLite in WAL mode** with numbered SQL migrations and foreign keys enforced; 24 tables.
- **Auth**: scrypt password hashing, opaque server-side sessions in httpOnly cookies, role checks in middleware on every protected route.
- **Offline**: service worker app-shell cache + IndexedDB mutation queue with idempotent replay.
- **Tests**: `node:test` unit tests for engine/scoring/adaptive + HTTP integration tests for auth, RBAC, dedupe, certificates.

## 8. Technical risks

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| R1 | Client-side cheating on WPM (devtools, timer tampering) | High | Medium (internal training, not certification authority) | Server-issued signed session token, server clock, idempotent submit, recomputation; documented as *verified* vs *self-reported* |
| R2 | Bengali/Hindi typing correctness (IME, joined glyphs, dead keys) | High | High if claimed prematurely | v1 ships English QWERTY only; interface i18n scaffolded; course-language support explicitly marked *experimental/not validated* |
| R3 | Browser keyboard-layout and dead-key differences (US vs UK vs InScript active) | Medium | High | Engine compares Unicode code points after NFC; documented; layout detection warning in settings |
| R4 | SQLite concurrency under a full lab (30 PCs, one server) | Low | Medium | WAL mode, prepared statements, short transactions; load-tested at 40 concurrent |
| R5 | Scope: 12 games + full portals in one release cycle | High | High | Games built as independent modules on a shared shell + shared scorer; each independently playable and testable |
| R6 | Offline sync conflicts across devices | Medium | Medium | Append-only session records with client UUIDs; server has no update path for a synced session, so no overwrite is possible |
| R7 | Data loss on the single server | Low | Critical | `npm run backup` (SQLite online backup API) + documented restore drill, verified in QA |
| R8 | Accessibility regressions | Medium | Medium | Keyboard-only operation, focus rings, contrast tokens, reduced-motion mode, automated checks in QA |
| R9 | Service worker serving stale app shell after upgrade | Medium | Medium | Versioned cache name, `skipWaiting` + `clientsClaim`, network-first for HTML/API, cache-first only for static assets |
| R10 | Certificate screenshots passed off as accredited | Low | High (reputational) | Certificate states issuer scope and non-accreditation; verification page shows live record status |

## 9. Recommended game collection (12)

Designed for distinct mechanics, not reskins. Each maps to a curriculum skill and takes shared metrics from the typing engine.

| # | Game | Mechanic (genuinely different) | Skill | Difficulty axes |
|---|---|---|---|---|
| 1 | Falling Letters | Real-time descent; type the key before it lands | single-key recognition | fall speed, spawn rate, key pool |
| 2 | Bubble Pop | Click-free target selection by typing; bubbles drift | char/word recognition | bubble count, word length |
| 3 | Speed Circuit | Race vs 3 bot cars; progress = correctly typed chars | sustained accuracy | bot speed, track length |
| 4 | Word Orbit | Ship navigates asteroid lanes; typing clears lane | word-level fluency | lane density, word length |
| 5 | Typing Bakery | Order queue with time pressure and expiry | real-world vocabulary | queue rate, order size |
| 6 | Keyboard Maze | Grid navigation by typed direction keys | controlled input, precision | maze size, dead ends |
| 7 | Word Guardian | Tower-defence: completing words charges a barrier | fast word recognition | wave rate, word length |
| 8 | Rhythm Keys | Beat-timed keystrokes with timing windows | consistency/timing | BPM, note density |
| 9 | Word Builder | Fill missing letters in a word, letter-by-letter | spelling recall | blanks per word, vocabulary |
| 10 | Station Master | Compose announcements with capitals and punctuation | real-world prosody | text length, accuracy strictness |
| 11 | Typing Expedition | Map with unlockable locations; each location is a mission | sentence/paragraph fluency | mission length, key scope |
| 12 | Code Sprint | Type HTML/CSS/JS tokens and snippets | symbols/punctuation | syntax complexity |

All twelve: instructions screen, 3+ difficulties, pause, restart, completion report, saved session, accuracy-weighted score.

## 10. Recommended curriculum

Level-based, accuracy-first, 50 lessons across 7 levels (0–6), each 2–4 minutes, each with objective, explanation, finger guidance, target key set, drill, mastery gate and next-step recommendation.

| Level | Name | Content | Default gate |
|---|---|---|---|
| 0 | Introduction | keyboard anatomy, posture, F/J anchors, finger map | 100% of drill attempted, no target |
| 1 | Beginner | home row, per-finger drills, home-row words | ≥95% acc |
| 2 | Elementary | upper + lower rows, letter blends, common words | ≥95% acc |
| 3 | Intermediate | full alphabet, Shift/caps, punctuation, digits | ≥95% acc, ≥12 WPM |
| 4 | Advanced | paragraphs, bigrams/trigrams, number row, symbols | ≥96% acc, ≥20 WPM |
| 5 | Professional | business correspondence, reports, timed exams | ≥97% acc, ≥28 WPM |
| 6 | Expert | speed-accuracy under pressure, numeric, complex prose | ≥98% acc, ≥40 WPM |

Rationale: accuracy gates rise as speed targets appear, mirroring the "accuracy before speed" instruction in the brief and the market evidence that net WPM falls steeply with error rate [S].

## 11. Development roadmap (executed — see `FINAL_REPORT.md` for status)

Stage 1 research/docs → Stage 2 design system → Stage 3 core app + auth → Stage 4 typing engine + tests → Stage 5 curriculum → Stage 6 practice/tests → Stage 7 twelve games → Stage 8 adaptive → Stage 9 instructor → Stage 10 admin → Stage 11 certificates → Stage 12 offline → Stage 13 QA → Stage 14 docs/deployment → Stage 15 delivery.

## 12. Sources consulted

- Product documentation & feature descriptions: TypingMaster 12 release notes and product pages (custom layouts, Hindi layout, bigram analytics/heatmaps, dark mode, custom pass limits) — [download3k listing](https://www.download3k.com/Install-TypingMaster-Pro.html), [typinglounge review](https://www.typinglounge.com/typing-master)
- Independent 2026 comparison of TypingClub / Typing.com / Nitro Type / Keybr / Typing Agent, including licence pricing and roster-sync notes — [typinggameskids.com comparison](https://typinggameskids.com/compare/)
- Independent 2026 "honest comparison" of free typing tests, incl. TypingClub accessibility presets and Keybr's pseudo-word method — [classicalquest.com](https://www.classicalquest.com/blog/best-free-typing-test-kids-2026)
- Typing-tutor software ranking and feature breakdown (TypingClub, Keybr, TypingMaster, Ratatype diagnostics) — [worldmetrics.org](https://worldmetrics.org/best/typing-tutor-software/)
- Typing games landscape, scoring-by-WPM×accuracy precedent, Nitro Type/TypeRacer/Monkeytype capability matrix — [typinggameskids.com best typing games](https://typinggameskids.com/best-typing-games/), [typingfix.com](https://typingfix.com/blogs/top-5-typing-test-websites-2026)
- Pedagogical analysis of games vs lessons and Keybr's adaptive method — [thetypinghub.com](https://thetypinghub.com/blog/typing-games-and-lessons-compared)
- WPM definition and gross/net formulas (5-character word standard, net = gross − errors/min) — [typingtest.now glossary](https://typingtest.now/glossary/wpm/), [typingtest.now FAQ](https://typingtest.now/faq/), [fastfingertype.com](https://fastfingertype.com/typing-test-scores-explained/)
- Analysis of Monkeytype's raw/net/consistency model and Typing.io's code-typing niche — [techbloat.com](https://www.techbloat.com/12-best-typing-test-websites-you-use-2026.html)

---

**Phase 1 decision:** proceed to architecture and implementation. No account access, payment, credential or irreversible change is required to build or evaluate BICA TYPING STUDIO, so no authorisation gate is needed before Stage 2.
