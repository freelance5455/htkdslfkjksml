# BICA TYPING STUDIO — Architecture

**Status:** locked for v1.0
**Companion docs:** `RESEARCH.md` (why), `TYPING_ENGINE.md` (measurement), `SECURITY.md`, `DEPLOYMENT.md`, `FINAL_REPORT.md` (what shipped).

---

## 1. Relationship to BICA ONE

BICA TYPING STUDIO is a **separate application with a separate database**. Nothing in this repository reads, writes, migrates or depends on any pre-existing BICA ONE schema, deployment or credentials. Rationale:

- Different domain model (practice sessions, keystroke analytics, curriculum mastery) versus whatever BICA ONE holds.
- Different release cadence and risk profile: a lab-critical tool must be upgradeable independently.
- Inspecting an existing production database before touching it is mandatory; no existing repository was present in this environment, so a clean standalone build was the correct and only safe path. If an existing BICA ONE install exists on your server, this app does not interact with it.

If account/student identity should later be shared between the two apps, the correct approach is an explicit SSO bridge (signed token exchange), **not** sharing a database file.

## 2. Technology decisions

| Layer | Choice | Why (and what was rejected) |
|---|---|---|
| Runtime | Node.js 20 LTS | Ubiquitous, long support, single runtime for server + tests |
| HTTP | Express 4 | Minimal, stable, no ceremony; the API is small enough that a framework's conventions add nothing |
| DB | SQLite (better-sqlite3) in WAL mode | One file the institute owns and can copy; no DB server to administer; synchronous API removes an entire class of race bugs; proven far beyond 200 students |
| Frontend | Native ES modules + hand-written CSS design system, no bundler | Zero build step = zero toolchain rot; the app can be debugged on-site in any browser; no CDN dependency in a lab that may be offline |
| Frontend framework | None | The UI is a handful of screens with a router; React would add 100KB+ and a build pipeline for no measurable benefit here. Rejected deliberately, not by default. |
| Auth | scrypt (node:crypto) + opaque session IDs in httpOnly cookies | No password material on the client, no JWT revocation problem |
| PDF | In-repo minimal PDF writer (`server/lib/pdf.js`) | Certificates and reports need ~6 text boxes, 3 rules and 2 rects. A 200-line deterministic writer beats a 2MB dependency we cannot audit |
| CSV | In-repo RFC 4180 writer | Trivial, and injection-safe (leading `=+-@` neutralised) |
| Offline | Service worker + IndexedDB queue | Required by brief; implemented with idempotent replay |
| Tests | `node:test` + `node:assert` | Built in; no test-framework dependency |
| Desktop packaging | Not shipped in v1 | Tauri/Electron was evaluated. The institute's need is satisfied by a browser pointed at a LAN server, which also centralises backups. Packaging is documented as a future option, not claimed |

**Dependency budget:** runtime dependencies are `express` and `better-sqlite3`. Nothing else. No icon library (inline SVG), no chart library (hand-drawn SVG charts), no date library, no CSS framework.

## 3. Repository layout

```
bica-typing-studio/
├── server/
│   ├── index.js               # process entry: config, listen
│   ├── app.js                 # app factory (exported for integration tests)
│   ├── db.js                  # connection, migrations runner, helpers
│   ├── migrations/*.sql       # numbered, forward-only
│   ├── auth.js                # scrypt hash/verify, sessions, RBAC middleware
│   ├── seed.js                # admin-only seed + optional demo seed
│   ├── backup.js              # online backup + restore drill
│   ├── lib/pdf.js             # minimal PDF writer
│   ├── lib/csv.js             # CSV + CSV-injection guard
│   ├── lib/validate.js        # input validation helpers
│   └── routes/
│       ├── auth.js  sessions.js  curriculum.js  games.js
│       ├── practice.js  challenges.js  adaptive.js
│       ├── instructor.js  admin.js  certificates.js  reports.js
├── shared/                    # isomorphic: imported by browser AND node tests
│   ├── typing-engine.js       # THE measurement implementation
│   ├── curriculum.js          # 7 levels / 50 lessons, generated + explicit drill text
│   ├── adaptive.js            # deterministic personalised recommendation engine
│   ├── scoring.js             # game scoring, accuracy-weighted
│   ├── rng.js                 # seeded PRNG (daily challenges, bot opponents)
│   └── textbank.js            # word lists, sentences, paragraphs, code snippets
├── public/
│   ├── index.html  sw.js  manifest.webmanifest
│   ├── css/app.css            # design tokens + components
│   └── js/
│       ├── app.js  router.js  api.js  store.js  ui.js  i18n.js  offline.js
│       ├── typing.js  overlays.js   # the shared typing workspace + modal registry
│       ├── views/{login,dashboard,learn,practice,arcade,challenge,progress,profile,
│       │         instructor*,admin*,verify}.js
│       └── games/{shell,falling-letters,bubble-pop,speed-circuit,word-orbit,typing-bakery,
│                  keyboard-maze,word-guardian,rhythm-keys,word-builder,station-master,
│                  typing-expedition,code-sprint}.js
├── tests/                     # node:test unit + HTTP integration, browser e2e,
│                              # offline queue, strict-CSP pass
├── scripts/                   # migrate, module-graph check, password reset
├── docs/
└── data/bica.db               # created at runtime (gitignored)
```

Frontend modules are loaded dynamically by the router; no bundler, no transpile target beyond ES2022.

## 4. Data model

24 tables. Full DDL in `server/migrations/001_init.sql`. Key design decisions:

**Identity and roles.** `users(id, username, password_hash, role, display_name, is_active, ...)`. `role ∈ {ADMIN, INSTRUCTOR, STUDENT}`. Authorisation is enforced in server middleware (`requireRole`, `requireStudentOwnership`, `requireClassAccess`), never by hiding UI. A student can only ever read rows where `user_id = session.user.id`; an instructor only classes they own (or co-teach via `class_instructors`); admin is unrestricted but every admin mutation is written to `audit_log`.

**Curriculum is code, progress is data.** Level/lesson definitions live in `shared/curriculum.js` (versioned, reviewable, testable) and are mirrored into `lessons` on migration/seed for referential integrity and instructor assignment. Progress lives in `lesson_progress` (one row per student+lesson, unique constraint) with `best_accuracy`, `best_wpm`, `attempts`, `mastered_at`.

**Sessions are append-only and verified.** `typing_sessions` stores mode, source (`lesson|practice|test|game|challenge`), target length, `typed_chars`, `correct_chars`, `error_keystrokes`, `duration_ms`, computed `gross_wpm`/`net_wpm`/`accuracy`, `verified` flag and `client_session_id UNIQUE`. The unique client id plus a server-issued signed session token is what prevents duplicate submission and replay. There is **no update path** for a submitted session, so no sync can overwrite a result.

**Keystroke analytics.** `typing_errors` (per-session per-key attempt/error counters) and `key_statistics` (rolling per-student per-key totals) support the heatmap and adaptive engine without storing every raw keypress (privacy + size).

**Institutional structure.** `classes`, `enrollments(student_id, class_id, status)`, `class_instructors`, `assignments(scope, target, due_at, criteria_json)`, `assignment_submissions`, `instructor_notes`, `certificates`, `achievements`/`student_achievements`, `game_sessions`, `typing_tests` (instructor-authored passages), `app_settings` (JSON key/value with typed getters), `audit_log`, `sync_records`, `schema_migrations`.

**Constraints that matter:** `UNIQUE(users.username)`, `UNIQUE(lesson_progress.student_id, lesson_id)`, `UNIQUE(typing_sessions.client_session_id)`, `UNIQUE(certificates.certificate_no)`, `UNIQUE(student_achievements.student_id, achievement_id)`, `CHECK(role IN (...))`, `CHECK(accuracy BETWEEN 0 AND 100)`, FK `ON DELETE CASCADE` for owned rows and `RESTRICT` for referential ones.

**Indexes:** `typing_sessions(student_id, started_at DESC)`, `typing_sessions(source, student_id)`, `key_statistics(student_id, key)`, `enrollments(class_id)`, `assignments(class_id, due_at)`, `certificates(verification_code)`.

## 5. Request flow and trust boundaries

```
browser ──(cookie session)──► express  ──► auth middleware ──► route handler ──► better-sqlite3
   │                              │                                   │
   │ IndexedDB queue              │ validate()                        │ recompute metrics
   └──POST /api/sessions/replay───┘                                   └── never trust client WPM
```

Trust rules:
1. The client never states WPM, accuracy or pass/fail. It states raw counters and a session token; the server recomputes and decides.
2. Elapsed time is `min(server_now − token.startedAt, ...)`; a submit that arrives faster than 90% of the nominal duration (with a 1.5 s grace) is rejected as *too fast to be genuine*.
3. Mastery (lesson unlock) is decided server-side from stored progress and current settings.
4. Certificate issuance requires mastered lessons + a verified session meeting configured criteria.
5. Every mutation is validated (`no unknown fields`, length caps, enum checks) and parameterised.

## 6. Measurement contract (see `TYPING_ENGINE.md` for formulas)

One implementation, `shared/typing-engine.js`, imported by lessons, practice, tests, and every game. It emits a `SessionSummary`:

```
{ typedChars, correctChars, errorKeystrokes, uncorrectedErrors, backspaces,
  durationMs, grossWpm, netWpm, accuracy, consistency,
  perKey: [{key, attempts, errors, avgIntervalMs}],
  bigrams: [{pair, count, avgIntervalMs, errors}],
  timeline: [cumulative wpm each 5s] }
```

Client and server both run the *same* arithmetic; the server's numbers win.

## 7. Offline and synchronisation

- `sw.js` caches the app shell (cache-first, versioned) and serves navigation network-first with an offline fallback.
- `GET /api/*` responses that represent study material (curriculum, games catalogue, session catalogue) are cached stale-while-revalidate so lessons open offline.
- Completed activity is written to IndexedDB (`pending_sessions`, `pending_game_sessions`) immediately with a UUID and shown as **Saved locally**.
- On reconnect (or manual "Sync now"), the queue is replayed. The server's `UNIQUE(client_session_id)` makes replay idempotent; a duplicate returns the original row with `duplicate: true`, so retries are safe.
- Status surface: *Saved locally → Pending sync → Synced* (with timestamp) *→ Failed* (with reason, retry button). Nothing is silently dropped or overwritten.

## 8. Security posture (summary; details in `SECURITY.md`)

scrypt(64MB, N=16384) password hashing; ≥12-char minimum for staff accounts; httpOnly + SameSite=Lax + Secure-when-behind-HTTPS cookies; session expiry with rolling refresh; generic login error messages; login rate limiting (per-IP and per-username, in-memory token bucket); `helmet`-equivalent security headers hand-set; strict CSP with **no `unsafe-eval`**; body size limits; server-side role checks on every route; parameterised SQL; CSV injection guard; no service-role keys anywhere; audit log for admin actions; backups exclude nothing but are stored with `0600`. Student data minimisation: username, display name, optional class, nothing else. No public leaderboard exposes usernames — only display names, and competitive features can be switched off centre-wide.

## 9. Performance plan

- Keystroke handling is `O(1)` per key and never touches the DOM tree wholesale: the typing workspace renders only the active word line plus a caret. `requestAnimationFrame` is used for cursor scroll and game loops; metric recomputation on key is incremental with a 250 ms throttle for the HUD.
- Server: prepared statements cached per process; WAL; paginated list endpoints (`LIMIT/OFFSET` with caps); analytics queries bounded by date range.
- Boot: single HTML, one CSS file, ~40 small ES modules fetched in parallel; no font downloads (system font stack with a deliberate serif/sans/mono trio).
- Budgets: first contentful paint < 400 ms on LAN, typing latency < 16 ms per key, instructor list of 500 students < 300 ms (load-tested in QA).

## 10. Accessibility plan

Full keyboard operation (every interactive element reachable, visible focus ring), ARIA live regions for typing feedback and timer warnings, `prefers-reduced-motion` honoured plus an in-app toggle, contrast-checked token palette (AA for body, AAA for typing surface), a "large target text" setting, no colour-only error signalling (icons + underline), and semantic headings per screen.

## 11. Internationalisation

`public/js/i18n.js` holds interface dictionaries: `en` complete, `bn`/`hi` scaffolded with the shell/nav/auth strings and a documented fallback. Interface language is independent of course language. **Course languages:** English QWERTY is the only supported typing curriculum. Bengali/Hindi typing requires validated IME handling, glyph-cluster comparison and layout-specific finger maps; that work is planned but **not implemented**, and the UI says so rather than pretending.

## 12. Deployment topology

Two supported modes:
1. **Lab server (recommended).** One Windows/Linux PC runs `node server/index.js` bound to `0.0.0.0:8080`; students on the LAN use `http://<server-ip>:8080`. Data is one SQLite file; backups to a second disk/Drive.
2. **Single machine.** Runs locally for one instructor + one student machine.

Optional HTTPS via reverse proxy (IIS/nginx/Caddy) with `TRUST_PROXY=1` and `COOKIE_SECURE=1`. No cloud account, no external service, no outbound network required at runtime.
