# BICA TYPING STUDIO — Known Limitations

Written down deliberately. A limitation that is documented is a product
decision; one that is hidden is a defect waiting to embarrass the centre.

**Status legend:** ✅ works as described · ⚠️ partial, behaviour explained ·
⛔ not implemented (the UI does not pretend otherwise)

---

## Measurement

| # | Limitation | Status | Notes |
|---|---|---|---|
| 1 | Speed ceiling ≈ 200 WPM | ⚠️ | A submission implying more than one character per 60 ms sustained is refused as implausible. No human on a physical keyboard reaches this; a stenographer would. Make it configurable before running a stenography course. |
| 2 | Consistency needs ≥ 3 keystroke intervals | ⚠️ | Below that the screen shows "not enough data" rather than a fabricated 0%. |
| 3 | Character comparison is exact (NFC normalised) | ⚠️ | `é` typed as base + combining accent is not equal to precomposed `é`. Correct for a typing tutor (it measures the keystrokes you made) but stricter than a word processor. |
| 4 | Layout-independent measurement | ⚠️ | The engine measures characters produced, not physical keys. The on-screen keyboard guide is QWERTY only. An AZERTY student is measured fairly but guided by the wrong finger map. |
| 5 | Bengali / Hindi typing | ⛔ | The curriculum is **English QWERTY only**. Bengali and Hindi need IME/compose handling, glyph-cluster comparison and layout-specific finger maps; none of that is implemented, and the interface language selector is explicitly about the *interface*, not the course. |

## Platforms & offline

| # | Limitation | Status | Notes |
|---|---|---|---|
| 6 | No desktop installer | ⛔ | Evaluated Tauri/Electron and rejected for v1: a browser pointed at a LAN server centralises backups and updates. Documented as a future option, not claimed as done. |
| 7 | Offline covers the shell only | ⚠️ | The service worker caches the app shell, the typing engine and all game modules, so the interface opens without a network. **Starting a new lesson or practice needs the server** (texts and tokens are generated server-side for integrity). A session *in progress* completes offline and is queued. |
| 8 | One process, one database file | ⚠️ | Designed for a room, not a campus. The login rate limiter is in-process; multi-instance deployment needs a shared limiter and PostgreSQL. |
| 9 | Service worker caching | ⚠️ | A browser that refuses service workers (private windows, some locked-down lab profiles) simply runs online. Nothing breaks; the offline badge never appears. |

## Documents & exports

| # | Limitation | Status | Notes |
|---|---|---|---|
| 10 | PDF fonts are WinAnsi | ⚠️ | Certificates and reports render Latin-1 text only. A Bengali or Devanagari student name would be replaced with `?` in the PDF. The HTML certificate/print view is Unicode-correct and is the right path for those names; the UI states this. |
| 11 | Certificate verification codes are HMAC-derived | ⚠️ | They prove the document was produced by this installation. They are **not** an external accreditation, and both the certificate and the verify page say so in plain language. |
| 12 | CSV is the interchange format | ✅ | No XLSX writer. CSV opens in Excel and Google Sheets, and formula injection is neutralised. |
| 13 | No email/SMS | ⛔ | Nothing in the product sends mail. Password resets are performed by an administrator. No mail credentials exist to leak. |

## Competition & social

| # | Limitation | Status | Notes |
|---|---|---|---|
| 14 | No student-to-student messaging | ⛔ (by design) | Leaderboards and shared challenges only. There is no chat, comment or direct-message surface anywhere. |
| 15 | No real-time multiplayer racing | ⛔ | Speed Circuit's opponents are deterministic computer cars seeded per round, not other students. Nothing in the UI calls them humans. |
| 16 | Leaderboards are per class/site | ✅ | No cross-institute league; there is no server-to-server federation. |

## Content

| # | Limitation | Status | Notes |
|---|---|---|---|
| 17 | Curriculum is fixed code, versioned | ⚠️ | 7 levels / 50 lessons live in `shared/curriculum.js` with a version string that is stored with results, so an old result can always be interpreted. Instructors can create their own tests and passages; they cannot add curriculum levels without a code change (deliberate: the sequence encodes pedagogy). |
| 18 | Game content is English | ⚠️ | Word lists, bakery items, station names and code snippets are English/technical. Instructors can disable individual games. |
| 19 | Achievements are fixed | ⚠️ | The set lives in `server/services/achievements.js` and is evaluated server-side. Thresholds are not editable in the UI. |

## Accessibility

| # | Limitation | Status | Notes |
|---|---|---|---|
| 20 | Full keyboard operation, ARIA live feedback, reduced-motion support, large-target-text setting | ✅ | Verified by manual pass; not verified with a screen reader on every screen. A formal WCAG 2.1 AA audit has not been performed — claim AA *intent*, not certification. |
| 21 | Colour is never the only signal | ✅ | Errors use icon + underline + text, not just red. |
| 22 | Mobile | ⚠️ | Layouts are responsive down to 360 px and the app is usable for reviewing progress and reports on a phone. Touch typing on a glass keyboard is not the product, and the app says so when it detects a touch device without a hardware keyboard. |

## Operations

| # | Limitation | Status | Notes |
|---|---|---|---|
| 23 | Single sign-on with other centre systems | ⛔ | Separate application, separate database. An SSO bridge would be a signed-token exchange, not a shared database. |
| 24 | Backups are local files | ⚠️ | `BICA_BACKUP_DIR` can point at a synced folder, but BICA itself performs no cloud upload. That is the operator's decision and their responsibility. |
| 25 | No audit of read access | ⚠️ | Writes and privileged actions are audited; ordinary reads are not logged (volume, and low value for a classroom tool). |

---

## What this product does **not** claim

- It is not "AI". The adaptive engine is a deterministic, explainable rule system
  over stored per-key statistics, and the interface describes it that way.
- It does not synchronise with a cloud service.
- It does not run multiplayer.
- It does not issue accredited qualifications.
- It does not type-check speech, images or handwriting.

Every one of those would be a legitimate future feature. None of them is
pretended to exist today.
