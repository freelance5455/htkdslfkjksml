# BICA TYPING STUDIO — Backup, Restore & Recovery Drills

The whole installation is three things: the application folder, the database
file `data/bica.db` (plus its `-wal`/`-shm` sidecars) and the secret in
`data/.app_secret`. Lose the code and it can be unzipped again. Lose the database
and every student's history is gone. Lose the secret and previously printed
certificate codes stop verifying.

---

## 1. What to back up

| Path | Why | Frequency |
|---|---|---|
| `data/bica.db` (via `npm run backup`, never by copying the live file) | All student data | Daily, automatically |
| `data/.app_secret` or the value of `BICA_SECRET` | Certificate verification codes derive from it | Once, at install; store it with the backups |
| `data/backups/` | The snapshots themselves | Copy off-machine weekly |
| Instructor-authored passages/tests | Live in the database, so covered by the database backup | — |
| Application folder | Reproducible from the delivered zip | On release |

Nothing else holds state. There are no upload directories, no caches worth
keeping, no external services.

---

## 2. Taking a backup

```bash
npm run backup
# [bica] backup written: bica-2026-11-01T09-14-22.db (612.4 KB)
```

This uses SQLite's online backup API: consistent even while students are typing,
no need to stop the server. Files are written `0600` into `BICA_BACKUP_DIR`
(default `data/backups`).

Scheduling:

- **Windows (Task Scheduler):** daily at 18:00 →
  `"C:\Program Files\nodejs\node.exe" server\backup.js backup`,
  *Start in* `C:\BICA\typing\bica-typing-studio`.
- **Linux (cron):** `0 18 * * * cd /opt/bica-typing/bica-typing-studio && /usr/bin/node server/backup.js backup`

Verify a backup is real, not just present:

```bash
node server/backup.js list
sqlite3 data/backups/bica-2026-11-01T09-14-22.db "select count(*) from typing_sessions;"
```

(Any SQLite client works; `sqlite3` is not required by the app.)

---

## 3. Restoring

**Stop the server first.** Restoring under a running server produces a file that
the process still has open.

```bash
# 0. preserve the current state, whatever it is
cp data/bica.db data/bica.db.before-restore-$(date +%s)

# 1. restore
node server/backup.js restore bica-2026-11-01T09-14-22.db
#    → the current database is copied to bica.db.pre-restore-<timestamp> first

# 2. start and check
npm start
curl -s http://localhost:8080/api/public/health
```

Then sign in as an administrator and confirm: the dashboard counts look right,
**Admin → Audit log** has entries, and one student's profile opens.

`restore` refuses a path outside the backup directory and removes stale `-wal` /
`-shm` sidecars so the restored file is not mixed with an old write-ahead log.

---

## 4. Restore drill (do this once, before you need it)

1. Note the current number of sessions: `Admin → Overview`, or
   `sqlite3 data/bica.db "select count(*) from typing_sessions;"`.
2. Run `npm run backup`.
3. Create a throwaway student and complete one practice session.
4. Stop the server, restore the backup from step 2, start the server.
5. Confirm the throwaway student is gone and the earlier count is back.
6. Delete the throwaway `.pre-restore-*` file only after the check passes.

A backup that has never been restored is a hope, not a backup.

---

## 5. Disaster scenarios

### The server PC dies

1. Install Node 20 on a replacement machine.
2. Unzip the application.
3. Copy the newest `data/backups/*.db` to `data/bica.db` **and** copy
   `data/.app_secret` (or set `BICA_SECRET` to the saved value).
4. `npm ci --omit=dev && npm start`.

Students keep their history. Certificate codes keep verifying.

### The database file is corrupt

SQLite reports `database disk image is malformed` or fails to open.

```bash
# 1. keep the damaged file — do not delete it
mv data/bica.db data/bica.db.damaged-$(date +%s)

# 2. try a recovery dump from the damaged file (if the file opens at all)
sqlite3 data/bica.db.damaged "pragma integrity_check;"
sqlite3 data/bica.db.damaged ".recover" | sqlite3 data/bica.db.recovered

# 3. otherwise restore the newest good backup (see §3)
```

Loss window = time since the last successful backup. This is why the backup runs
daily and copies off-machine weekly.

### A power cut in the middle of a lab session

SQLite in WAL mode recovers on the next open; nothing to do. Two things to check
afterwards:

- Students whose result was still in the browser queue will replay it when they
  reopen the app on the same browser profile (the queue lives in IndexedDB).
- A session that was mid-exercise is simply not recorded — tokens expire after
  6 hours and are never re-used.

### The secret file is lost

New certificates get new verification codes. Previously printed codes cannot be
reproduced without the original secret — reissue the affected certificates
(Admin → Certificates → revoke, then issue again after the student's next
verified attempt). Record this in the audit trail.

### An administrator forgets their password

```bash
node scripts/set-password.mjs admin
# Password set for admin (ADMIN — Centre Administrator).
# All existing sessions for that account have been signed out.
#
#   one-time password: 8fQ2mZ0kTn4vRb
#   (shown once — copy it now)
```

The account is flagged `must_change_pw`, so the next sign-in is held on the
Profile screen until a new password is chosen. Every other session for that
account is revoked at the same time. The reset is written to the audit log with
actor `null` and action `cli.password_reset`, so it is visible in
**Admin → Audit log** even though no user performed it.

The same command is how you replace the published demo administrator password on
a fresh installation:

```bash
node scripts/set-password.mjs admin "a-long-password-of-your-own"
```

### Somebody loses a laptop with a signed-in session

Admin → Users → *Reset password* for that account, or revoke sessions directly:

```bash
sqlite3 data/bica.db "update auth_sessions set revoked_at = datetime('now') where user_id = 5;"
```

Revocation is immediate: the session row is checked on every request.

---

## 6. Recovery contacts on the certificate

Each certificate carries the certificate number and a verification code. The
public page `/#/verify` answers with holder name, course, best verified speed and
accuracy, issue date and revocation status — enough to answer a phone enquiry
without exposing any other student data.
