# BICA TYPING STUDIO — Typing Engine & Measurement Contract

**Implementation:** `shared/typing-engine.js`
**Engine version:** `1.0.0` (reported on every session summary)
**Used by:** lessons, practice, timed tests, challenges and all twelve arcade games.

The engine is one file, imported unchanged by the browser *and* by the Node test
runner. There is no second implementation anywhere in the codebase: lessons,
practice, examinations and games cannot disagree about what "WPM" means.

---

## 1. Why one engine

Every typing product eventually tells two students different speeds for the same
typing. It happens when the HUD, the result screen and the report each compute
their own numbers. BICA avoids that structurally:

```
keystrokes ─► TypingSession (browser)  ─► summary (raw counters) ─► server
                     │                                               │
                     └── live HUD reads the same computeMetrics() ◄──┘
                                    verifySubmission() recomputes
```

The client is allowed to *measure* and *display*. It is never allowed to
*declare* a result. A submission carries raw counters (`committedChars`,
`correctChars`, `forwardKeystrokes`, `errorKeystrokes`, `uncorrectedErrors`,
`backspaces`, inter-key `intervals`). The server recomputes WPM and accuracy from
those counters using `verifySubmission()`, stores **its own** numbers, and the
displayed result is the server's response.

Any `netWpm`, `grossWpm` or `accuracy` a client sends is ignored. There is a test
for this (`tests/integration.test.js` → "the server recomputes metrics and
ignores client-declared WPM").

---

## 2. Formulas

Character counts follow the standard "one word = five characters" convention,
which is what typing certificates in India (and most examination boards) use.

| Metric | Formula | Notes |
|---|---|---|
| Gross WPM | `(committedChars ÷ 5) ÷ elapsedMinutes` | committed = characters advanced (final positions filled), not keystrokes |
| Net WPM | `max(0, grossWPM − uncorrectedErrors ÷ elapsedMinutes)` | each character still wrong at the end costs one WPM |
| Correct WPM | `(correctChars ÷ 5) ÷ elapsedMinutes` | informational; shown on progress screens |
| Accuracy | `(forwardKeystrokes − errorKeystrokes) ÷ forwardKeystrokes × 100` | **per keystroke**, so a mistake that is later corrected still counts |
| Consistency | `max(0, 100 × (1 − CV))` where CV is the coefficient of variation of inter-key intervals | samples > 1500 ms are excluded (a coffee break is not rhythm) |
| Duration | `min(serverNow − tokenIssuedAt, nominalDuration + 1500 ms)` | server clock only |

`elapsedMinutes = max(durationMs, 1) / 60000` — the `max(…, 1)` guard means a
theoretical zero-duration submission divides by 1 ms instead of producing
`Infinity`.

### Why accuracy is per keystroke, not per final character

Consider typing `the` as `teh` then backspacing and correcting. The final text is
perfect; the typist pressed four wrong-or-right keys to get there. Per-keystroke
accuracy reports 4/5 = 80% for that word. Per-final-character accuracy would
report 100% and reward sloppiness. BICA uses per-keystroke accuracy everywhere,
including game scoring.

### Rounding

WPM and accuracy are rounded to one decimal place, half away from zero, at the
moment of persistence. All other arithmetic is floating point until display.

---

## 3. Input handling

| Case | Behaviour |
|---|---|
| Space | a normal character; compared like any other |
| Capital letters | `A` ≠ `a`; shift is measured like any other keystroke |
| Punctuation / digits / symbols | treated identically to letters |
| Backspace | consumes a position (`index -= 1`), counts as `backspaces`, never as a correct keystroke; disabling it is a per-exercise option and is enforced in the engine |
| Repeated keys | each press is a separate sample; no de-duplication |
| Over-typing past the end | ignored (does not inflate counts) |
| Tab / newline in a passage | normalised to a single space when the drill is built, so a stray newline in a passage can never be un-typeable |
| Unicode | iterated with `Intl.Segmenter`-style code-point iteration (`toChars`), so astral characters count as one char; comparison is exact — `é` (U+00E9) and `e` + U+0301 are **not** treated as equal |
| Keyboard layout | the engine measures characters, not physical keys, so an AZERTY or Dvorak user is measured on what they produced; the on-screen keyboard guidance is QWERTY and says so |

`toChars()` normalises input with NFC before comparison. That is a deliberate
choice: it makes visually identical text compare identically without merging
genuinely different characters (`ß` ≠ `ss`, `İ` ≠ `I`). It does **not** attempt
glyph-cluster equivalence for Bengali or Devanagari — see
`KNOWN_LIMITATIONS.md`.

---

## 4. Anti-manipulation rules

Implemented in `server/services/sessions.js`:

1. **Server-issued token.** Every exercise starts with `POST …/start`, which
   stores a token bound to `(user, source, ref, expectedMs, targetChars)`.
   Submissions without a token are rejected with `invalid_token`.
2. **Single use.** A token is consumed in the same transaction that stores the
   session; a second submission gets `token_used` (409).
3. **Idempotent client id.** `typing_sessions.client_session_id` is `UNIQUE`.
   Replaying an offline queue returns the original row (`duplicate: true`)
   instead of writing a second result.
4. **Server clock.** Duration is derived from the token's creation time, never
   from the client. A timed submission that arrives before 90% of its nominal
   duration (minus 1.5 s grace) is refused with `too_fast` (422).
5. **Physical plausibility.** A submission claiming more than one character per
   60 ms sustained (≈200 WPM) is refused with `implausible_speed` (422). Untimed
   drills have an absolute floor of 350 ms, low enough that a fast student
   finishing a 17-character home-row line is not punished.
6. **Length sanity.** A lesson submission longer than its drill + 5 characters is
   refused with `overlong`.
7. **No update path.** There is no `UPDATE typing_sessions`. A result cannot be
   edited after the fact by any role, including ADMIN; corrections happen by
   recording another attempt.

Refreshing the page mid-exercise destroys the token's usefulness in the same way
as leaving: the attempt is simply not submitted. It cannot be re-submitted
because the token is only accepted while unconsumed *and* within 6 hours.

---

## 5. Live HUD

The HUD recomputes metrics on every keystroke but writes to the DOM at most every
80 ms (`updateHud`), and the passage is rendered as a sliding window of 220
characters so a 5,000-character transcription never builds a 5,000-node DOM. A
keypress touches at most three spans. Nothing in the render path awaits, animates
or lays out the whole page, so input latency stays under a frame.

---

## 6. Data emitted

```js
{
  engineVersion: '1.0.0',
  mode: 'time' | 'text' | 'words',
  // computed metrics (see §2)
  grossWpm, netWpm, correctWpm, accuracy, consistency,
  committedChars, correctChars, forwardKeystrokes, errorKeystrokes,
  uncorrectedErrors, backspaces, durationMs,
  // structure
  targetChars, completedTarget, startedAt, endedAt, elapsedMs,
  perKey:    [{ key, attempts, errors, avgIntervalMs }],
  bigrams:   [{ pair, count, avgIntervalMs, errorRate }],
  timeline:  [{ atMs, wpm }],          // one sample per 5 s
  intervals: [ms, …],                  // last 4000, for consistency replay
  errorPositions: [index, …],
}
```

`perKey` is keyed on **the key the student actually pressed** (what they struggle
with), not the key that was expected. The server aggregates it into
`key_statistics` (rolling per student per key) and `typing_errors` (per session),
which is what the heatmap, the weak-key recommendations and the adaptive engine
read. Raw keystroke streams are never stored: privacy and size.

---

## 7. Tests

`node --test tests/` runs 27 engine tests, including:

- monotonic behaviour (more correct characters ⇒ higher WPM),
- accuracy is per keystroke and survives backspace correction,
- zero and negative durations do not produce `Infinity`/`NaN`,
- the render window stays bounded on long passages,
- the server clamps impossible submissions,
- a full simulated 60-second session produces a coherent summary.

The HTTP contract tests in `tests/integration.test.js` cover token, replay,
plausibility, ownership and role enforcement.

---

## 8. Known limits of the measurement

- WPM is a coarse proxy for skill. The product shows accuracy, consistency and
  per-key data alongside it because a single number hides the thing that matters.
- Consistency needs at least three intervals; with fewer it reports `0` and the
  UI labels it "not enough data" rather than inventing a value.
- The 200 WPM ceiling will not be reached by a human using a physical keyboard,
  but it is a hard refusal, not a flag. If BICA ever runs a stenography course,
  make the ceiling configurable before that course goes live.
