/**
 * HTTP integration tests.
 *
 * The unit tests cover the typing engine. This suite covers the parts that only
 * exist once the server is assembled: authentication, role authorisation, the
 * session-verification contract, mastery unlocking, certificates, exports and
 * the offline replay path.
 *
 * Every test runs against a throwaway SQLite database in the OS temp directory,
 * seeded with one admin, one instructor, two students and a class. Nothing here
 * touches data/bica.db.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../server/app.js';
import { loadConfig } from '../server/config.js';
import { openDb, migrate } from '../server/db.js';
import { syncLessons, ensureDefaults } from '../server/seed-data.js';
import { hashPassword } from '../server/auth.js';
import { getLesson } from '../shared/curriculum.js';

// ---------------------------------------------------------------- harness ---

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bica-test-'));
const dbPath = path.join(dir, 'test.db');
const config = loadConfig({
  dbPath,
  secret: 'test-secret-that-is-long-enough-for-hmac-signing',
  env: 'test',
  minDurationRatio: 0.9,
  durationGraceMs: 1500,
  port: 0,
  host: '127.0.0.1',
  // The suite signs in many times from one address; the production limiter
  // (8 per user, 20 per IP) is covered by its own assertions below.
  loginMaxPerIp: 500,
  loginMaxPerUser: 500,
});

const db = openDb(dbPath);
migrate(db);
syncLessons(db);
ensureDefaults(db);

const PASSWORD = 'IntegrationTest2026!';
function addUser(username, role, displayName) {
  const info = db.prepare(`
    INSERT INTO users (username, password_hash, role, display_name, is_active, must_change_pw)
    VALUES (?,?,?,?,1,0)
  `).run(username, hashPassword(PASSWORD), role, displayName);
  return Number(info.lastInsertRowid);
}

const adminId = addUser('admin', 'ADMIN', 'Test Admin');
const instructorId = addUser('teacher', 'INSTRUCTOR', 'Test Instructor');
const studentId = addUser('learner', 'STUDENT', 'Test Learner');
const otherStudentId = addUser('other', 'STUDENT', 'Other Learner');

const classInfo = db.prepare(`
  INSERT INTO classes (name, code, instructor_id, is_active) VALUES ('Test Batch','TB-1',?,1)
`).run(instructorId);
const classId = Number(classInfo.lastInsertRowid);
db.prepare('INSERT INTO class_instructors (class_id, instructor_id) VALUES (?,?)').run(classId, instructorId);
db.prepare("INSERT INTO enrollments (class_id, student_id, status) VALUES (?,?,'ACTIVE')").run(classId, studentId);

const app = createApp({ db, config });
const server = app.listen(0, '127.0.0.1');
await new Promise((resolve) => server.once('listening', resolve));
const BASE = `http://127.0.0.1:${server.address().port}`;

test.after(() => {
  server.close();
  try { db.close(); } catch { /* already closed */ }
  fs.rmSync(dir, { recursive: true, force: true });
});

/** Minimal cookie-jar client. */
function client() {
  let cookie = '';
  return {
    async request(method, url, body) {
      const res = await fetch(`${BASE}${url}`, {
        method,
        headers: {
          ...(body ? { 'content-type': 'application/json' } : {}),
          ...(cookie ? { cookie } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
        redirect: 'manual',
      });
      const setCookie = res.headers.getSetCookie?.() ?? [];
      for (const raw of setCookie) {
        const pair = raw.split(';')[0];
        if (pair.startsWith('bica_sid=')) cookie = pair;
      }
      const text = await res.text();
      let json = null;
      try { json = JSON.parse(text); } catch { /* non-JSON body */ }
      return { status: res.status, headers: res.headers, text, json };
    },
    get(url) { return this.request('GET', url); },
    post(url, body) { return this.request('POST', url, body ?? {}); },
    patch(url, body) { return this.request('PATCH', url, body ?? {}); },
    del(url) { return this.request('DELETE', url); },
  };
}

async function signIn(username, password = PASSWORD) {
  const c = client();
  const res = await c.post('/api/auth/login', { username, password });
  return { client: c, res };
}

// ------------------------------------------------------------------ auth ---

test('anonymous requests are rejected, not merely hidden', async () => {
  const c = client();
  for (const url of ['/api/me/dashboard', '/api/curriculum', '/api/admin/users', '/api/instructor/students']) {
    const res = await c.get(url);
    assert.equal(res.status, 401, `${url} should require authentication`);
  }
});

test('sign-in works and sets an httpOnly session cookie', async () => {
  const c = client();
  const res = await c.post('/api/auth/login', { username: 'learner', password: PASSWORD });
  assert.equal(res.status, 200);
  const raw = (res.headers.getSetCookie?.() ?? []).join('|');
  assert.match(raw, /bica_sid=/);
  assert.match(raw, /HttpOnly/i);
  assert.match(raw, /SameSite=Lax/i);
  const me = await c.get('/api/auth/me');
  assert.equal(me.status, 200);
  assert.equal(me.json.user.role, 'STUDENT');
  assert.equal(me.json.user.passwordHash, undefined, 'never leak the password hash');
});

test('wrong password is refused with a generic message', async () => {
  const { res } = await signIn('learner', 'wrong-password');
  assert.equal(res.status, 401);
  assert.doesNotMatch(res.text, /no such user|unknown user|user not found/i);
});

test('a student cannot reach instructor or admin endpoints', async () => {
  const { client: c } = await signIn('learner');
  assert.equal((await c.get('/api/admin/users')).status, 403);
  assert.equal((await c.get('/api/instructor/students')).status, 403);
  const forged = await c.post('/api/admin/users', { username: 'ghost', password: 'GhostPass2026!', role: 'ADMIN', displayName: 'Ghost' });
  assert.equal(forged.status, 403, 'role checks are enforced server-side');
});

test('security headers and CSP ship with every response', async () => {
  const c = client();
  const res = await c.get('/');
  assert.equal(res.status, 200);
  const csp = res.headers.get('content-security-policy');
  assert.match(csp, /default-src 'self'/);
  assert.doesNotMatch(csp, /unsafe-eval/);
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
});

// ------------------------------------------------------- typed session API ---

test('a session cannot be submitted without a server-issued token', async () => {
  const { client: c } = await signIn('learner');
  const res = await c.post('/api/sessions', {
    tokenId: 'not-a-real-token',
    clientSessionId: 'client-abc-123',
    summary: { committedChars: 50, correctChars: 50, forwardKeystrokes: 50, errorKeystrokes: 0 },
  });
  assert.ok(res.status >= 400);
  assert.equal(res.json.error, 'invalid_token');
});

test('the server recomputes metrics and ignores client-declared WPM', async () => {
  const { client: c } = await signIn('learner');
  const gen = await c.post('/api/practice/generate', { preset: 'random-words', durationSec: 10 });
  assert.equal(gen.status, 200);

  // Wait out the nominal duration the way a real student would.
  await new Promise((r) => setTimeout(r, 9600));

  const submitted = await c.post('/api/sessions', {
    tokenId: gen.json.tokenId,
    clientSessionId: 'client-honest-1234',
    title: 'Honesty check',
    mode: 'time',
    summary: {
      committedChars: 100,
      correctChars: 96,
      forwardKeystrokes: 104,
      errorKeystrokes: 8,
      uncorrectedErrors: 4,
      durationMs: 10000,
      // The client lies about its own speed; the server must ignore these.
      netWpm: 999,
      grossWpm: 999,
      accuracy: 100,
    },
  });
  assert.equal(submitted.status, 200);
  const s = submitted.json.session;
  assert.ok(s.netWpm < 200, `net WPM should be recomputed, got ${s.netWpm}`);
  assert.ok(s.accuracy < 100, `accuracy should reflect the 8 error keystrokes, got ${s.accuracy}`);
  assert.equal(s.verified, true);
});

test('an impossibly fast submission is refused', async () => {
  const { client: c } = await signIn('learner');
  const gen = await c.post('/api/practice/generate', { preset: 'random-words', durationSec: 30 });
  const res = await c.post('/api/sessions', {
    tokenId: gen.json.tokenId,
    clientSessionId: 'client-cheat-1234',
    mode: 'time',
    summary: { committedChars: 240, correctChars: 240, forwardKeystrokes: 240, errorKeystrokes: 0 },
  });
  assert.equal(res.status, 422);
  assert.match(res.json.error, /too_fast|implausible/);
});

test('replaying the same client session id is idempotent, not a second result', async () => {
  const { client: c } = await signIn('learner');
  const gen = await c.post('/api/practice/generate', { preset: 'random-words', durationSec: 10 });
  await new Promise((r) => setTimeout(r, 9600));
  const payload = {
    tokenId: gen.json.tokenId,
    clientSessionId: 'client-replay-1234',
    mode: 'time',
    summary: { committedChars: 60, correctChars: 60, forwardKeystrokes: 60, errorKeystrokes: 0 },
  };
  const first = await c.post('/api/sessions', payload);
  assert.equal(first.status, 200);
  const second = await c.post('/api/sessions', payload);
  assert.equal(second.status, 200);
  assert.equal(second.json.duplicate, true);
  assert.equal(second.json.session.id, first.json.session.id);
  const count = db.prepare('SELECT COUNT(*) AS n FROM typing_sessions WHERE client_session_id = ?').get('client-replay-1234');
  assert.equal(count.n, 1);
});

// --------------------------------------------------------------- ownership ---

test('a student only ever sees their own rows', async () => {
  const { client: c } = await signIn('other');
  const me = await c.get('/api/me/dashboard');
  assert.equal(me.status, 200);
  const sessions = await c.get('/api/me/sessions');
  assert.equal(sessions.status, 200);
  for (const s of sessions.json.sessions) {
    assert.equal(s.student_id, otherStudentId);
  }
  const foreign = await c.get(`/api/instructor/students/${studentId}`);
  assert.equal(foreign.status, 403);
});

test('an instructor reaches only their own classes', async () => {
  const { client: c } = await signIn('teacher');
  const res = await c.get('/api/instructor/students');
  assert.equal(res.status, 200);
  const ids = res.json.students.map((s) => s.id);
  assert.ok(ids.includes(studentId), 'enrolled student is visible');
  assert.ok(!ids.includes(otherStudentId), 'unenrolled student must not be');
  const profile = await c.get(`/api/instructor/students/${studentId}`);
  assert.equal(profile.status, 200);
  assert.equal((await c.get(`/api/instructor/students/${otherStudentId}`)).status, 403);
});

// --------------------------------------------------------------- curriculum ---

test('lessons unlock from measured mastery, not from clicking', async () => {
  const { client: c } = await signIn('learner');
  const before = await c.get('/api/curriculum');
  const lessons = before.json.levels.flatMap((l) => l.lessons);
  const locked = lessons.filter((l) => !l.unlocked && !l.mastered);
  assert.ok(locked.length > 40, 'the course starts almost entirely locked');

  // Mastery requires accuracy, and the server decides it — a fake high score
  // sent from the client is discarded (covered above), so mastery does not
  // change unless a genuine attempt passes.
  const target = lessons[0];
  const start = await c.post(`/api/curriculum/lessons/${target.id}/start`, { drillIndex: 0 });
  assert.equal(start.status, 200);
  assert.ok(start.json.text.length > 0);
  assert.ok(start.json.tokenId);
});

test('lesson submission below the accuracy threshold does not grant mastery', async () => {
  const { client: c } = await signIn('learner');
  const lesson = getLesson('L0-01');
  const start = await c.post('/api/curriculum/lessons/L0-01/start', { drillIndex: 0 });
  const length = lesson.drills[0].length;
  await new Promise((r) => setTimeout(r, 1200)); // let the drill take a human moment
  const res = await c.post('/api/sessions', {
    tokenId: start.json.tokenId,
    clientSessionId: 'client-sloppy-123',
    title: 'Sloppy attempt',
    mode: 'text',
    meta: { drillIndex: 0 },
    summary: {
      committedChars: length,
      correctChars: Math.floor(length * 0.6),
      forwardKeystrokes: length,
      errorKeystrokes: Math.floor(length * 0.4),
      uncorrectedErrors: Math.floor(length * 0.4),
    },
  });
  assert.equal(res.status, 200);
  assert.equal(res.json.passed, false);
  const progress = db.prepare('SELECT * FROM lesson_progress WHERE student_id = ? AND lesson_id = ?').get(studentId, 'L0-01');
  assert.ok(!progress || progress.mastered_at === null, 'a sloppy attempt must not master the lesson');
});

// ------------------------------------------------------------- certificates ---

test('a certificate cannot be issued before the criteria are met', async () => {
  const { client: c } = await signIn('teacher');
  const res = await c.post('/api/certificates/issue', { studentId });
  assert.equal(res.status, 422);
  assert.equal(res.json.error, 'not_eligible');
  assert.ok(Array.isArray(res.json.eligibility.checks));
  assert.ok(res.json.eligibility.checks.some((chk) => chk.met === false));
});

test('certificate verification answers honestly for an unknown number', async () => {
  const c = client();
  const res = await c.get('/api/public/verify/BICA-2026-99999');
  assert.equal(res.status, 404);
  assert.equal(res.json.valid, false);
  assert.equal(res.json.reason, 'not_found');
});

// ------------------------------------------------------------------ exports ---

test('CSV export is authorised and RFC-4180 safe', async () => {
  const { client: c } = await signIn('teacher');
  const res = await c.get(`/api/instructor/classes/${classId}/export.csv`);
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type') ?? '', /csv/);
  assert.match(res.headers.get('content-disposition') ?? '', /attachment/);
  assert.ok(res.text.split('\n').length >= 2, 'header row plus at least one data row');

  const stranger = (await signIn('other')).client;
  assert.equal((await stranger.get(`/api/instructor/classes/${classId}/export.csv`)).status, 403);
});

test('a PDF report is a real PDF document', async () => {
  const { client: c } = await signIn('teacher');
  const res = await c.get(`/api/instructor/students/${studentId}/report.pdf`);
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type') ?? '', /pdf/);
  assert.ok(res.text.startsWith('%PDF-'), 'file starts with the PDF magic number');
});

// ------------------------------------------------------------------- admin ---

test('admin mutations are written to the audit log', async () => {
  const { client: c } = await signIn('admin');
  const created = await c.post('/api/admin/users', {
    username: 'newstudent', password: 'NewStudent2026!', role: 'STUDENT', displayName: 'New Student',
  });
  assert.equal(created.status, 201);
  const log = await c.get('/api/admin/audit');
  assert.equal(log.status, 200);
  assert.ok(log.json.entries.some((e) => /user/i.test(e.action)), 'user creation is audited');
});

test('settings changes are validated against the allowed set', async () => {
  const { client: c } = await signIn('admin');
  const settings = await c.get('/api/admin/settings');
  assert.equal(settings.status, 200);
  const bad = await c.request('PUT', '/api/admin/settings', { 'curriculum.minAccuracy': 12 });
  assert.ok(bad.status >= 400, 'an out-of-range threshold is refused');
  const good = await c.request('PUT', '/api/admin/settings', { 'curriculum.minAccuracy': 96 });
  assert.equal(good.status, 200);
  assert.equal(good.json.settings['curriculum.minAccuracy'], 96);
  await c.request('PUT', '/api/admin/settings', { 'curriculum.minAccuracy': 95 });
});

test('unknown API endpoints return JSON, not an HTML stack page', async () => {
  const c = client();
  const res = await c.get('/api/does-not-exist');
  assert.equal(res.status, 404);
  assert.equal(res.json.error, 'not_found');
});

// ---------------------------------------------------------------- games ---

test('game rounds are scored server-side with accuracy squared', async () => {
  const { client: c } = await signIn('learner');
  const start = await c.post('/api/games/start', { gameId: 'falling-letters', difficulty: 'normal' });
  assert.equal(start.status, 200);
  // The server refuses a round that ends before the game could plausibly have
  // been played (min 25% of the duration, capped at 8 s for long games).
  await new Promise((r) => setTimeout(r, 8600));
  const submit = await c.post('/api/games/submit', {
    tokenId: start.json.tokenId,
    clientSessionId: 'round-abc-12345',
    gameId: 'falling-letters',
    difficulty: 'normal',
    outcome: 'GAME_OVER',
    summary: { basePoints: 100, accuracy: 80, committedChars: 80, correctChars: 64, errorKeystrokes: 16, completionBonus: 0.5 },
  });
  assert.equal(submit.status, 200);
  const round = submit.json.round;
  // 100 base × 0.8² accuracy × 1.35 difficulty × (0.5 + 0.5 × 0.5 completion)
  // = 64.8 → 65. Speed cannot inflate this; only accuracy and completion can.
  assert.equal(round.score, 65);
  assert.ok(round.score < 100, 'an 80%-accurate round scores below its base points');
});

test('an unknown game id is refused', async () => {
  const { client: c } = await signIn('learner');
  const res = await c.post('/api/games/start', { gameId: 'not-a-game', difficulty: 'normal' });
  assert.equal(res.status, 404);
});

// ------------------------------------------------- password-change policy ---

test('an account with a one-time password is held at the password screen', async () => {
  const info = db.prepare(`
    INSERT INTO users (username, password_hash, role, display_name, is_active, must_change_pw)
    VALUES ('firstadmin', ?, 'ADMIN', 'First Admin', 1, 1)
  `).run(hashPassword(PASSWORD));
  const id = Number(info.lastInsertRowid);

  const { client: c } = await signIn('firstadmin');
  const blocked = await c.get('/api/admin/dashboard');
  assert.equal(blocked.status, 403);
  assert.equal(blocked.json.error, 'password_change_required');

  // The password screen itself stays reachable.
  assert.equal((await c.get('/api/auth/me')).status, 200);
  const changed = await c.post('/api/auth/password', {
    currentPassword: PASSWORD,
    newPassword: 'BrandNewPassword2026!',
  });
  assert.equal(changed.status, 200);

  const allowed = await c.get('/api/admin/dashboard');
  assert.equal(allowed.status, 200, 'the gate lifts once the password is set');
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
});

test('a password change revokes the account’s other sessions', async () => {
  const info = db.prepare(`
    INSERT INTO users (username, password_hash, role, display_name, is_active, must_change_pw)
    VALUES ('twodevices', ?, 'STUDENT', 'Two Devices', 1, 0)
  `).run(hashPassword(PASSWORD));
  const id = Number(info.lastInsertRowid);

  const first = (await signIn('twodevices')).client;
  const second = (await signIn('twodevices')).client;
  assert.equal((await second.get('/api/me/dashboard')).status, 200);

  const changed = await first.post('/api/auth/password', {
    currentPassword: PASSWORD,
    newPassword: 'ReplacedPassword2026!',
  });
  assert.equal(changed.status, 200);
  assert.equal((await second.get('/api/me/dashboard')).status, 401, 'the other device is signed out');
  assert.equal((await first.get('/api/me/dashboard')).status, 200, 'the device that changed it stays signed in');
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
});

// ------------------------------------------------------------ rate limiting ---

test('repeated failed sign-ins hit the rate limiter', async () => {
  // A second app instance with the production defaults.
  const strictConfig = { ...config, loginMaxPerIp: 20, loginMaxPerUser: 8 };
  const strictApp = createApp({ db, config: strictConfig });
  const strictServer = strictApp.listen(0, '127.0.0.1');
  await new Promise((resolve) => strictServer.once('listening', resolve));
  const origin = `http://127.0.0.1:${strictServer.address().port}`;
  try {
    let lastStatus = 0;
    for (let i = 0; i < 10; i += 1) {
      const res = await fetch(`${origin}/api/auth/login`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ username: 'learner', password: `wrong-${i}` }),
      });
      lastStatus = res.status;
      await res.text();
    }
    assert.equal(lastStatus, 429, 'the ninth-plus attempt is throttled');
  } finally {
    strictServer.close();
  }
});

test('a round that ends too quickly is recorded but not scored', async () => {
  const { client: c } = await signIn('learner');
  const start = await c.post('/api/games/start', { gameId: 'word-guardian', difficulty: 'normal' });
  // No artificial wait: a beginner losing in the first seconds must not be
  // treated as a cheat, and must not gain a high score either.
  const submit = await c.post('/api/games/submit', {
    tokenId: start.json.tokenId,
    clientSessionId: 'round-tooshort-123',
    gameId: 'word-guardian',
    difficulty: 'normal',
    outcome: 'GAME_OVER',
    summary: { basePoints: 90, accuracy: 95, committedChars: 40, correctChars: 38, errorKeystrokes: 2, completionBonus: 0.3 },
  });
  assert.equal(submit.status, 200);
  assert.equal(submit.json.round.verified, 0, 'stored, but flagged as not verified');
  assert.equal(submit.json.round.score, 0, 'no score credit');
  assert.match(submit.json.note, /not scored/i);

  const catalog = await c.get('/api/games');
  const game = catalog.json.games.find((g) => g.id === 'word-guardian');
  assert.equal(game.personal.bestScore ?? 0, 0, 'an uncounted round never becomes a personal best');
});

// ------------------------------------------------ certificate end to end ---

test('a certificate is issued, verifies, revokes and prints as a PDF', async () => {
  const { client: admin } = await signIn('admin');
  const relaxed = await admin.request('PUT', '/api/admin/settings', {
    'cert.minLevel': 0, 'cert.minLessons': 0, 'cert.minWpm': 0, 'cert.minAccuracy': 0,
  });
  assert.equal(relaxed.status, 200);

  // One genuine, verified session so the certificate has something to state.
  const { client: learner } = await signIn('learner');
  const gen = await learner.post('/api/practice/generate', { preset: 'random-words', durationSec: 10 });
  await new Promise((r) => setTimeout(r, 9600));
  const session = await learner.post('/api/sessions', {
    tokenId: gen.json.tokenId,
    clientSessionId: 'client-certificate-1',
    title: 'Certificate qualifying run',
    mode: 'time',
    summary: {
      committedChars: 120, correctChars: 118, forwardKeystrokes: 122,
      errorKeystrokes: 4, uncorrectedErrors: 2, backspaces: 2,
    },
  });
  assert.equal(session.status, 200);
  assert.equal(session.json.session.verified, true);

  // The instructor issues it.
  const { client: teacher } = await signIn('teacher');
  const issued = await teacher.post('/api/certificates/issue', { studentId });
  assert.ok([200, 201].includes(issued.status), `unexpected ${issued.status}: ${issued.text.slice(0, 200)}`);
  const cert = issued.json.certificate;
  assert.match(cert.certificate_no, /^BICA-\d{4}-\d+$/);
  assert.ok(cert.verification_code.length >= 8);

  // The holder can download the document.
  const pdf = await learner.get(`/api/certificates/${cert.certificate_no}/pdf`);
  assert.equal(pdf.status, 200);
  assert.ok(pdf.text.startsWith('%PDF-'));

  // Anyone can verify it, with or without the code.
  const anonymous = client();
  const good = await anonymous.get(`/api/public/verify/${cert.certificate_no}?code=${encodeURIComponent(cert.verification_code)}`);
  assert.equal(good.status, 200);
  assert.equal(good.json.valid, true);
  assert.equal(good.json.certificate.number, cert.certificate_no);
  assert.match(good.json.notice, /not an externally accredited/i);

  const wrongCode = await anonymous.get(`/api/public/verify/${cert.certificate_no}?code=WRONG-CODE-99`);
  assert.equal(wrongCode.json.valid, false);
  assert.equal(wrongCode.json.reason, 'code_mismatch');

  // Revocation is visible immediately.
  const revoked = await admin.post(`/api/certificates/${cert.certificate_no}/revoke`, { reason: 'Issued during the integration test' });
  assert.ok([200, 201].includes(revoked.status), `unexpected ${revoked.status}: ${revoked.text.slice(0, 200)}`);
  const afterRevoke = await anonymous.get(`/api/public/verify/${cert.certificate_no}`);
  assert.equal(afterRevoke.json.valid, false);
  assert.equal(afterRevoke.json.reason, 'revoked');

  // A student can never issue one for themselves.
  const selfIssue = await learner.post('/api/certificates/issue', { studentId });
  assert.equal(selfIssue.status, 403);
});
