/**
 * Strict-CSP browser check.
 *
 * The other browser tests bypass the Content-Security-Policy because Playwright's
 * `waitForFunction` needs `eval`. This one does the opposite: it loads the real
 * app *with* the shipped policy and asserts that nothing violates it. A view that
 * relies on `eval`, inline script or an inline event attribute works in the other
 * tests and fails here — which is exactly what we want to catch before a student
 * opens it in a locked-down browser.
 *
 * Usage: node tests/csp-check.mjs [baseUrl]
 */
import { chromium } from 'playwright-core';

const BASE = process.argv[2] ?? 'http://127.0.0.1:8080';
const ACCOUNT = { username: 'student1', password: 'BicaDemo2026!' };

const violations = [];
const failures = [];

const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
// No bypassCSP on purpose.
const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await context.newPage();

page.on('console', (msg) => {
  if (msg.type() !== 'error') return;
  const text = msg.text();
  if (/Content Security Policy|Refused to/i.test(text)) violations.push(text.slice(0, 300));
  else if (!/status of 401/.test(text)) failures.push(`console: ${text.slice(0, 200)}`);
});
page.on('pageerror', (err) => failures.push(`exception: ${err.message}`));

try {
  await page.goto(`${BASE}/#/login`, { waitUntil: 'load' });
  await page.waitForSelector('input[name="username"]', { timeout: 15000 });
  await page.fill('input[name="username"]', ACCOUNT.username);
  await page.fill('input[type="password"]', ACCOUNT.password);
  await page.click('button[type="submit"]');
  await page.waitForSelector('.content', { timeout: 20000 });
  await page.waitForTimeout(1200);

  for (const route of ['dashboard', 'learn', 'practice', 'arcade', 'progress', 'profile']) {
    await page.goto(`${BASE}/#/${route}`, { waitUntil: 'load' });
    await page.waitForTimeout(900);
    const text = await page.locator('.content').innerText().catch(() => '');
    if (text.trim().length < 40) failures.push(`#/${route} rendered almost nothing`);
  }

  // Open a practice drill: the typing workspace builds its keyboard from JS.
  await page.goto(`${BASE}/#/practice`, { waitUntil: 'load' });
  await page.waitForTimeout(700);
  await page.click('button:has-text("Start practice")');
  await page.waitForSelector('.typing-target', { timeout: 20000 });
  await page.click('.typing-target');
  await page.keyboard.type('abc', { delay: 60 });
  await page.waitForTimeout(400);
  const spans = await page.$$eval('.typing-target .ch', (els) => els.length);
  if (spans === 0) failures.push('typing workspace rendered no characters');
} catch (err) {
  failures.push(err.message);
}

await browser.close();

if (violations.length) {
  console.log('CSP violations:');
  for (const v of [...new Set(violations)]) console.log(`  - ${v}`);
}
if (failures.length) {
  console.log('Failures:');
  for (const f of [...new Set(failures)]) console.log(`  - ${f}`);
}
if (!violations.length && !failures.length) {
  console.log('strict CSP: no violations, all student screens render');
}
process.exit(violations.length || failures.length ? 1 : 0);
