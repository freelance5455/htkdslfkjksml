import test from 'node:test';
import assert from 'node:assert/strict';
import {
  TypingSession, computeMetrics, analyzeBigrams, verifySubmission, toChars, ENGINE_VERSION,
} from '../shared/typing-engine.js';

/** Deterministic clock helper. */
function clock(start = 0) {
  let t = start;
  return { now: () => t, advance: (ms) => { t += ms; }, set: (v) => { t = v; } };
}

function typeAll(session, text, c, msPerKey = 200) {
  for (const ch of toChars(text)) {
    c.advance(msPerKey);
    session.press(ch);
  }
}

test('engine version is reported on every summary', () => {
  const s = new TypingSession({ target: 'abc', now: () => 0 });
  assert.equal(s.summary().engineVersion, ENGINE_VERSION);
});

test('gross WPM uses the 5-character word standard', () => {
  // 250 committed chars in exactly 60s = 50 WPM
  const m = computeMetrics({ committedChars: 250, correctChars: 250, forwardKeystrokes: 250, durationMs: 60000 });
  assert.equal(m.grossWpm, 50);
});

test('net WPM subtracts uncorrected errors per minute', () => {
  // 1420 chars / 3 min = 94.7 gross, 9 uncorrected errors in 3 min = 3/min
  const m = computeMetrics({
    committedChars: 1420, correctChars: 1411, forwardKeystrokes: 1420,
    errorKeystrokes: 9, uncorrectedErrors: 9, durationMs: 180000,
  });
  assert.equal(m.grossWpm, 94.7);
  assert.equal(m.netWpm, 91.7);
  assert.equal(m.accuracy, 99.4);
});

test('net WPM never goes negative', () => {
  const m = computeMetrics({ committedChars: 50, correctChars: 0, forwardKeystrokes: 50, errorKeystrokes: 50, uncorrectedErrors: 50, durationMs: 60000 });
  assert.equal(m.netWpm, 0);
  assert.equal(m.accuracy, 0);
});

test('accuracy is computed from keystrokes, not from the final text', () => {
  const c = clock();
  const s = new TypingSession({ target: 'cat', now: c.now });
  c.advance(100); s.press('c');   // correct
  c.advance(100); s.press('x');   // wrong  -> error keystroke stays counted
  c.advance(50); s.press('Backspace');
  c.advance(100); s.press('a');   // corrected
  c.advance(100); s.press('t');
  const sum = s.summary();
  assert.equal(sum.committedChars, 3);
  assert.equal(sum.correctChars, 3, 'final text is fully correct');
  assert.equal(sum.errorKeystrokes, 1);
  assert.equal(sum.uncorrectedErrors, 0);
  assert.equal(sum.forwardKeystrokes, 4);
  assert.equal(sum.accuracy, 75, 'a corrected mistake still costs accuracy');
  assert.equal(sum.backspaces, 1);
  assert.equal(sum.netWpm, sum.grossWpm, 'no uncorrected errors means no net penalty');
});

test('backspace disabled: wrong character is permanent and penalised', () => {
  const c = clock();
  const s = new TypingSession({ target: 'cat', allowBackspace: false, now: c.now });
  c.advance(100); s.press('c');
  c.advance(100); s.press('x');
  const back = s.press('Backspace');
  assert.equal(back.accepted, false);
  c.advance(100); s.press('t');
  assert.equal(s.summary().uncorrectedErrors, 1);
  assert.equal(s.summary().committedChars, 3);
  assert.equal(s.summary().correctChars, 2);
});

test('backspace at position zero is ignored', () => {
  const s = new TypingSession({ target: 'ab', now: () => 0 });
  assert.equal(s.press('Backspace').accepted, false);
  assert.equal(s.summary().backspaces, 0);
});

test('repeated characters are each counted', () => {
  const c = clock();
  const s = new TypingSession({ target: 'aaa', now: c.now });
  for (let i = 0; i < 3; i += 1) { c.advance(100); s.press('a'); }
  const sum = s.summary();
  assert.equal(sum.committedChars, 3);
  assert.equal(sum.correctChars, 3);
  assert.equal(sum.perKey.find((k) => k.key === 'a').attempts, 3);
});

test('spaces, capitals, punctuation and digits all count as characters', () => {
  const c = clock();
  const text = 'Hello, World 2026!';
  const s = new TypingSession({ target: text, now: c.now });
  typeAll(s, text, c);
  const sum = s.summary();
  assert.equal(sum.committedChars, toChars(text).length);
  assert.equal(sum.accuracy, 100);
  assert.ok(sum.perKey.some((k) => k.key === ','));
  assert.ok(sum.perKey.some((k) => k.key === '2'));
  assert.ok(sum.perKey.some((k) => k.key === 'H'), 'capital and lowercase are distinct keys');
});

test('capital H and lowercase h are different characters', () => {
  const c = clock();
  const s = new TypingSession({ target: 'Hi', now: c.now });
  c.advance(100); s.press('h');
  c.advance(100); s.press('i');
  assert.equal(s.summary().correctChars, 1);
  assert.equal(s.summary().accuracy, 50);
});

test('Unicode: surrogate pairs count as one character', () => {
  const chars = toChars('a😀b');
  assert.equal(chars.length, 3);
  const c = clock();
  const s = new TypingSession({ target: 'a😀b', now: c.now });
  c.advance(100); s.press('a');
  c.advance(100); s.press('😀');
  c.advance(100); s.press('b');
  const sum = s.summary();
  assert.equal(sum.committedChars, 3);
  assert.equal(sum.accuracy, 100);
});

test('Unicode: NFC and NFD forms of the same letter compare equal', () => {
  const target = 'caf\u00e9';        // café precomposed
  const typed = 'cafe\u0301';        // café decomposed
  const c = clock();
  const s = new TypingSession({ target, now: c.now });
  for (const ch of toChars(typed)) { c.advance(100); s.press(ch); }
  const sum = s.summary();
  assert.equal(sum.correctChars, 4, 'decomposed é collapses into the precomposed target');
  assert.equal(sum.errorKeystrokes, 0);
});

test('Unicode: visually similar but distinct scripts are NOT equal (no unsafe folding)', () => {
  const c = clock();
  const s = new TypingSession({ target: 'a', now: c.now });
  c.advance(100); s.press('\u0430'); // Cyrillic а
  assert.equal(s.summary().accuracy, 0);
  assert.equal(s.summary().uncorrectedErrors, 1);
});

test('time mode expires and cannot be extended by further keypresses', () => {
  const c = clock();
  const s = new TypingSession({ target: 'abcdefghij', mode: 'time', durationMs: 1000, now: c.now });
  c.advance(900); s.press('a');
  c.advance(200); s.press('b'); // beyond the deadline
  assert.equal(s.finished, true);
  const sum = s.summary();
  assert.equal(sum.committedChars, 1, 'the late keystroke was not accepted');
  assert.ok(sum.elapsedMs >= 1000);
});

test('fixed-text mode finishes when the passage is completed', () => {
  const c = clock();
  const s = new TypingSession({ target: 'go', now: c.now });
  c.advance(100); s.press('g');
  const r = s.press('o');
  assert.equal(r.finished, true);
  assert.equal(s.isComplete, true);
  assert.equal(s.press('x').accepted, false, 'no over-typing after completion');
});

test('over-typing beyond the passage is ignored in time mode', () => {
  const c = clock();
  const s = new TypingSession({ target: 'ab', mode: 'time', durationMs: 60000, now: c.now });
  c.advance(100); s.press('a');
  c.advance(100); s.press('b');
  c.advance(100); s.press('c');
  assert.equal(s.summary().committedChars, 2);
});

test('consistency is high for even rhythm and low for erratic rhythm', () => {
  const even = { intervals: Array(20).fill(200) };
  const erratic = { intervals: [60, 900, 80, 1200, 70, 600, 90, 1100, 50, 800] };
  const a = computeMetrics({ committedChars: 100, correctChars: 100, forwardKeystrokes: 100, durationMs: 60000, ...even });
  const b = computeMetrics({ committedChars: 100, correctChars: 100, forwardKeystrokes: 100, durationMs: 60000, ...erratic });
  assert.equal(a.consistency, 100);
  assert.ok(b.consistency < 45, `erratic rhythm should score low, got ${b.consistency}`);
});

test('pauses longer than 1.5s are excluded from rhythm statistics', () => {
  const m = computeMetrics({ committedChars: 10, correctChars: 10, forwardKeystrokes: 10, durationMs: 60000, intervals: [200, 200, 60000, 200] });
  assert.equal(m.consistency, 100);
});

test('per-key error rates identify the weak key', () => {
  const c = clock();
  const s = new TypingSession({ target: 'rrrrtttt', now: c.now });
  // press r correctly twice, wrongly twice; t correctly four times
  ['r', 'r', 'r', 'r', 't', 't', 't', 't'].forEach((ch, i) => {
    c.advance(150);
    if (i < 4 && i % 2 === 0) s.press('e'); // wrong key at two r positions
    else s.press(ch);
  });
  const sum = s.summary();
  const e = sum.perKey.find((k) => k.key === 'e');
  const t = sum.perKey.find((k) => k.key === 't');
  assert.equal(e.errors, 2);
  assert.equal(t.errors, 0);
});

test('bigram analysis ranks the slowest pair first', () => {
  const rows = analyzeBigrams([
    { pair: 'th', intervalMs: 120, errored: false },
    { pair: 'th', intervalMs: 130, errored: false },
    { pair: 'qu', intervalMs: 700, errored: true },
  ]);
  assert.equal(rows[0].pair, 'qu');
  assert.equal(rows[0].avgIntervalMs, 700);
  assert.equal(rows[0].errorRate, 100);
});

test('server verification ignores client-claimed WPM and accuracy', () => {
  const metrics = verifySubmission({
    summary: {
      typedChars: 500, committedChars: 500, correctChars: 450, forwardKeystrokes: 500,
      errorKeystrokes: 50, uncorrectedErrors: 50, backspaces: 0,
      grossWpm: 999, netWpm: 999, accuracy: 100, // lies
    },
    serverDurationMs: 60000,
  });
  assert.equal(metrics.grossWpm, 100);
  assert.equal(metrics.accuracy, 90);
  assert.ok(metrics.netWpm < 100);
});

test('server verification clamps impossible submissions', () => {
  const m = verifySubmission({
    summary: { committedChars: 10, correctChars: 500, forwardKeystrokes: 5, errorKeystrokes: 999 },
    serverDurationMs: 1000,
  });
  assert.equal(m.correctChars, 10, 'correctChars clamped to committedChars');
  assert.equal(m.errorKeystrokes, 5, 'errors clamped to keystrokes');
  assert.ok(m.accuracy >= 0);
});

test('negative and zero durations do not explode the maths', () => {
  const m = computeMetrics({ committedChars: 10, correctChars: 10, forwardKeystrokes: 10, durationMs: 0 });
  assert.ok(Number.isFinite(m.grossWpm) && m.grossWpm > 0);
  const m2 = computeMetrics({ committedChars: 0, correctChars: 0, forwardKeystrokes: 0, durationMs: 60000 });
  assert.equal(m2.grossWpm, 0);
  assert.equal(m2.accuracy, 100, 'no keystrokes yet is not an error state');
});

test('timeline samples accumulate for the results chart', () => {
  const c = clock();
  const s = new TypingSession({ target: 'x'.repeat(200), now: c.now, mode: 'time', durationMs: 30000 });
  for (let i = 0; i < 100; i += 1) { c.advance(200); s.press('x'); }
  assert.ok(s.summary().timeline.length >= 3);
});

test('render window stays bounded for long passages', () => {
  const c = clock();
  const text = 'a'.repeat(3000);
  const s = new TypingSession({ target: text, now: c.now });
  for (let i = 0; i < 1500; i += 1) { c.advance(5); s.press('a'); }
  const view = s.renderState({ window: 220 });
  assert.equal(view.chars.length, 220);
  assert.equal(view.cursor, 1500);
  assert.equal(view.chars.find((r) => r.i === 1500).state, 'pending');
});

test('accidental newlines and tabs in a passage become spaces', () => {
  assert.deepEqual(toChars('a\nb\tc'), ['a', ' ', 'b', ' ', 'c']);
});

test('a full 60-second simulated session produces a coherent summary', () => {
  const c = clock();
  const text = 'The quick brown fox jumps over the lazy dog. '.repeat(20);
  const s = new TypingSession({ target: text, mode: 'time', durationMs: 60000, now: c.now });
  let i = 0;
  while (!s.finished && i < text.length) {
    c.advance(150);
    s.press(text[i]);
    i += 1;
  }
  const sum = s.finished ? s.summary() : s.finish();
  assert.ok(sum.elapsedMs >= 59000);
  assert.equal(sum.accuracy, 100);
  assert.ok(sum.grossWpm > 60 && sum.grossWpm < 100, `plausible WPM, got ${sum.grossWpm}`);
  assert.equal(sum.perKey.length > 10, true);
});
