/**
 * End-to-end functional test (headless Chromium).
 *
 * This is the test that proves the product works, not just that it renders. It
 * drives the real UI the way a student and an instructor would:
 *
 *   student   · practice a timed drill, finish it, see a verified result
 *             · open the first unlocked lesson, complete a drill, see mastery
 *             · launch a daily challenge
 *             · launch every arcade game and confirm gameplay draws + scores
 *   instructor· read the dashboard, open a student, create a typing test,
 *               create an assignment, export CSV, download a PDF report
 *   admin     · create a user, change a setting, take a backup
 *
 * Usage:
 *   node server/index.js                     # in one shell
 *   node tests/e2e.mjs [baseUrl]
 *
 * Requires `playwright-core` and an installed Chromium. Set
 * PLAYWRIGHT_BROWSERS_PATH if your browser lives outside the default cache.
 */
import { chromium } from 'playwright-core';

const BASE = process.argv[2] ?? 'http://127.0.0.1:8080';
const ACCOUNTS = {
  student: { username: 'student1', password: 'BicaDemo2026!' },
  instructor: { username: 'instructor', password: 'BicaDemo2026!' },
  admin: { username: 'admin', password: 'BicaAdmin2026!' },
};
const GAMES = [
  'falling-letters', 'bubble-pop', 'speed-circuit', 'word-orbit', 'typing-bakery',
  'keyboard-maze', 'word-guardian', 'rhythm-keys', 'word-builder', 'station-master',
  'typing-expedition', 'code-sprint',
];

const results = [];
const problems = [];
const rejected = [];
let browser;

function record(name, ok, detail = '') {
  results.push({ name, ok, detail });
  if (!ok) problems.push(`${name}${detail ? ` — ${detail}` : ''}`);
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`);
}

function diagnostics(page, label) {
  page.on('console', (msg) => {
    if (msg.type() !== 'error') return;
    const text = msg.text();
    if (/Failed to load resource.*(401|403)/.test(text)) return;
    problems.push(`[${label}] console: ${text}`);
  });
  page.on('pageerror', (err) => problems.push(`[${label}] exception: ${err.message}`));
  page.on('response', (res) => {
    if (res.status() >= 500) problems.push(`[${label}] server error ${res.status()} ${res.url().replace(BASE, '')}`);
    // 4xx responses are part of the contract (a refused cheat, an expired token).
    // They are only a problem when they are unexpected, so surface the URL.
    if (res.status() >= 400 && res.status() < 500 && res.status() !== 401) {
      rejected.push(`[${label}] ${res.status()} ${res.request().method()} ${res.url().replace(BASE, '')}`);
    }
  });
}

async function newPage(label) {
  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    acceptDownloads: true,
    bypassCSP: true, // the app's real CSP forbids eval, which Playwright needs
  });
  const page = await context.newPage();
  diagnostics(page, label);
  return { context, page };
}

async function signIn(page, account) {
  await page.goto(`${BASE}/#/login`, { waitUntil: 'networkidle' });
  await page.fill('input[name="username"]', account.username);
  await page.fill('input[type="password"]', account.password);
  await page.click('button[type="submit"]');
  await page.waitForFunction(
    () => !location.hash.includes('login'),
    null,
    { timeout: 15000 },
  );
  await page.waitForSelector('.content', { timeout: 15000 });
  await page.waitForTimeout(600);
}

/** Types the visible target text at a human-plausible pace. */
async function typeTarget(page, { maxChars = 400, delay = 62 } = {}) {
  const chars = await page.$$eval('.typing-target .ch', (els) => els.map((e) => e.textContent));
  const text = chars.join('').replace(/\u00a0/g, ' ').slice(0, maxChars);
  await page.click('.typing-target');
  await page.keyboard.type(text, { delay });
  return text.length;
}

const SCREENS = {
  student: ['dashboard', 'learn', 'practice', 'arcade', 'challenge', 'progress', 'profile', 'curriculum'],
  instructor: ['instructor', 'instructor/classes', 'instructor/students', 'instructor/assignments',
    'instructor/tests', 'instructor/certificates', 'instructor/students/3', 'instructor/classes/1'],
  admin: ['admin', 'admin/users', 'admin/classes', 'admin/settings', 'admin/audit', 'admin/backups',
    'instructor', 'instructor/assignments'],
};

/**
 * Walks every screen for a signed-in role and asserts it rendered real content
 * rather than an error panel. Catches the class of bug where one lazy-loaded
 * view has a broken import that nobody clicked yet.
 */
async function walkScreens(page, role) {
  for (const route of SCREENS[role]) {
    await page.goto(`${BASE}/#/${route}`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(500);
    const text = await page.locator('.content').innerText().catch(() => '');
    const broken = /could not be opened|Page not found/i.test(text);
    record(`${role} screen #/${route}`, !broken && text.trim().length > 40,
      broken ? text.replace(/\s+/g, ' ').slice(0, 90) : `${text.trim().length} chars`);
  }
}

async function waitForResult(page, timeout = 40000) {
  await page.waitForSelector('.result, .result__grid, .typing-result', { timeout });
}

// ===========================================================================
async function studentFlow() {
  const { context, page } = await newPage('student');
  try {
    await signIn(page, ACCOUNTS.student);
    record('student signs in', true);
    await walkScreens(page, 'student');

    // ---------------------------------------------------------- practice
    await page.goto(`${BASE}/#/practice`, { waitUntil: 'networkidle' });
    await page.waitForSelector('.chip-grid');
    await page.click('[data-duration="15"]');
    await page.click('button:has-text("Start practice")');
    await page.waitForSelector('.typing-target', { timeout: 20000 });
    const typed = await typeTarget(page, { maxChars: 240 });
    record('practice registers keystrokes', typed > 0, `${typed} visible characters`);
    const live = await page.textContent('.typing-bar__stats').catch(() => '');
    record('practice HUD shows live metrics', /WPM/i.test(live), live.replace(/\s+/g, ' ').trim().slice(0, 60));
    await waitForResult(page, 45000);
    const resultText = await page.locator('.typing-result, .result, .result__grid').first().innerText().catch(() => '');
    record('practice result screen appears', resultText.length > 10, resultText.replace(/\s+/g, ' ').slice(0, 80));
    const verified = /verified|server/i.test(await page.locator('body').innerText());
    record('practice result is server-verified', verified);
    await page.click('.result button:has-text("Continue"), button:has-text("Continue")').catch(() => {});
    await page.waitForTimeout(600);
    record('result screen closes cleanly', (await page.$('.dialog-backdrop')) === null);

    // ------------------------------------------------------------- lesson
    await page.goto(`${BASE}/#/learn`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(700);
    const firstLesson = await page.$('.lesson-row[href], .lesson-list a.lesson-row');
    record('curriculum lists lessons', Boolean(firstLesson));
    if (firstLesson) {
      await firstLesson.click();
      await page.waitForTimeout(900);
      const startBtn = await page.$('button:has-text("Begin drill")');
      record('lesson detail opens with a start control', Boolean(startBtn));
      if (startBtn) {
        await startBtn.click();
        await page.waitForSelector('.typing-target', { timeout: 20000 });
        await typeTarget(page, { maxChars: 200, delay: 70 });
        // A drill ends automatically when the passage is complete.
        await page.waitForTimeout(2500);
        const bodyText = await page.locator('body').innerText();
        record('lesson drill completes and reports', /accuracy|passed|mastered|next/i.test(bodyText));
        await page.keyboard.press('Escape');
        await page.waitForTimeout(400);
        await page.click('.dialog button:has-text("Leave"), .dialog button:has-text("Exit"), .dialog button:has-text("Discard")').catch(() => {});
        await page.waitForTimeout(400);
      }
    }

    // ---------------------------------------------------------- challenge
    await page.goto(`${BASE}/#/challenge`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(900);
    const challengeBtn = await page.$('button:has-text("Start challenge"), button:has-text("Try to beat it")');
    record('daily challenge offers an attempt', Boolean(challengeBtn));
    if (challengeBtn) {
      await challengeBtn.click();
      await page.waitForSelector('.typing-target', { timeout: 20000 }).catch(() => {});
      record('challenge opens the typing workspace', Boolean(await page.$('.typing-target')));
      await page.keyboard.press('Escape');
      await page.waitForTimeout(300);
      await page.click('.dialog button:has-text("Leave"), .dialog button:has-text("Exit")').catch(() => {});
      await page.waitForTimeout(400);
    }

    // ------------------------------------------------------------- arcade
    for (const gameId of GAMES) {
      await page.goto(`${BASE}/#/arcade?game=${gameId}`, { waitUntil: 'networkidle' });
      await page.waitForTimeout(700);
      // The deep link raises the setup sheet; open it explicitly if it is not up.
      if (!(await page.$('.dialog'))) {
        await page.click(`[data-game="${gameId}"]`).catch(() => {});
        await page.waitForTimeout(400);
      }
      await page.click('.dialog button:has-text("Start round")').catch(() => {});
      await page.waitForSelector('.game-stage', { timeout: 20000 }).catch(() => {});
      const stage = await page.$('.game-stage');
      if (!stage) { record(`arcade ${gameId}`, false, 'game screen did not open'); continue; }
      const ready = await page.$('#game-ready');
      if (ready) await ready.check();
      const startBtn = await page.$('button:has-text("Start round")');
      if (!startBtn) { record(`arcade ${gameId}`, false, 'no start button'); continue; }
      await startBtn.click();
      await page.waitForTimeout(900);
      // Type a spread of characters so most games receive plausible input.
      await page.keyboard.type('asdfjkl; the quick brown fox jumps over lazy dog', { delay: 45 });
      await page.waitForTimeout(700);
      const drew = await page.evaluate(() => {
        const c = document.querySelector('.game-canvas-wrap canvas');
        if (!c || !c.width) return false;
        const ctx = c.getContext('2d');
        const { data } = ctx.getImageData(0, 0, Math.min(120, c.width), Math.min(120, c.height));
        for (let i = 0; i < data.length; i += 4) {
          if (data[i + 3] !== 0 && (data[i] > 0 || data[i + 1] > 0 || data[i + 2] > 0)) return true;
        }
        return false;
      });
      const hud = await page.textContent('.game-hud').catch(() => '');
      record(`arcade ${gameId}`, drew && /Score/.test(hud), drew ? '' : 'canvas stayed blank');
      await page.keyboard.press('Escape');
      await page.waitForTimeout(400);
      await page.click('button:has-text("Quit to arcade"), button:has-text("Leave")').catch(() => {});
      await page.waitForTimeout(400);
    }
  } catch (err) {
    record('student flow', false, err.message);
  } finally {
    await context.close();
  }
}

// ===========================================================================
async function instructorFlow() {
  const { context, page } = await newPage('instructor');
  try {
    await signIn(page, ACCOUNTS.instructor);
    record('instructor signs in', true);
    await walkScreens(page, 'instructor');

    await page.goto(`${BASE}/#/instructor`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(900);
    const dash = await page.locator('.content').innerText();
    record('instructor dashboard shows KPIs', /students/i.test(dash) && dash.length > 200);

    await page.goto(`${BASE}/#/instructor/students/3`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(900);
    const profile = await page.locator('.content').innerText();
    record('student profile renders a report', /speed|wpm|accuracy/i.test(profile), `${profile.length} chars`);

    // -- create a typing test
    await page.goto(`${BASE}/#/instructor/tests`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(700);
    await page.click('button:has-text("New test")').catch(() => {});
    await page.waitForTimeout(500);
    const titleInput = await page.$('.dialog input[name="title"], .dialog input');
    if (titleInput) {
      const stamp = Date.now().toString().slice(-6);
      await titleInput.fill(`E2E passage ${stamp}`);
      const passage = await page.$('.dialog textarea');
      if (passage) {
        await passage.fill('The quick brown fox jumps over the lazy dog while the diligent student types steadily and keeps every finger on its home key. Accuracy first, speed second, always.');
      }
      await page.click('.dialog button:has-text("Save"), .dialog button:has-text("Create")');
      await page.waitForTimeout(1200);
      const list = await page.locator('.content').innerText();
      record('instructor can create a typing test', list.includes(stamp), `looking for ${stamp}`);
    } else {
      record('instructor can create a typing test', false, 'dialog did not open');
    }

    // -- CSV export
    await page.goto(`${BASE}/#/instructor/classes/1`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(700);
    const csvHref = await page.$eval('a[download], a[href*=".csv"]', (a) => a.getAttribute('href')).catch(() => null);
    if (csvHref) {
      const res = await page.request.get(`${BASE}${csvHref}`);
      const body = await res.text();
      record('instructor CSV export returns data', res.ok() && body.split('\n').length > 1, `${res.status()} · ${body.split('\n').length} rows`);
    } else {
      record('instructor CSV export returns data', false, 'no export control');
    }

    // -- PDF report download
    await page.goto(`${BASE}/#/instructor/students/3`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(800);
    const pdfLink = await page.$('a[href*="pdf"], a[href*="report"], button:has-text("PDF")');
    if (pdfLink) {
      const [download] = await Promise.all([
        page.waitForEvent('download', { timeout: 15000 }).catch(() => null),
        pdfLink.click(),
      ]);
      record('student report downloads as PDF', Boolean(download), download ? download.suggestedFilename() : 'no download');
    } else {
      record('student report downloads as PDF', false, 'no PDF control');
    }
  } catch (err) {
    record('instructor flow', false, err.message);
  } finally {
    await context.close();
  }
}

// ===========================================================================
async function adminFlow() {
  const { context, page } = await newPage('admin');
  try {
    await signIn(page, ACCOUNTS.admin);
    record('admin signs in', true);
    await walkScreens(page, 'admin');

    await page.goto(`${BASE}/#/admin/settings`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(800);
    record('admin settings render', (await page.locator('.content').innerText()).includes('Mastery'));

    await page.goto(`${BASE}/#/admin/backups`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(800);
    const before = await page.locator('.content').innerText();
    await page.click('button:has-text("Back up now"), button:has-text("Create backup")').catch(() => {});
    await page.waitForTimeout(2000);
    const after = await page.locator('.content').innerText();
    record('admin can create a backup', after !== before && /bica-/i.test(after));

    await page.goto(`${BASE}/#/admin/audit`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(800);
    const audit = await page.locator('.content').innerText();
    record('audit log records admin actions', /backup|settings|created/i.test(audit));
  } catch (err) {
    record('admin flow', false, err.message);
  } finally {
    await context.close();
  }
}

// ===========================================================================
browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
try {
  await studentFlow();
  await instructorFlow();
  await adminFlow();
} finally {
  await browser.close();
}

const passed = results.filter((r) => r.ok).length;
console.log(`\n${passed}/${results.length} end-to-end checks passed`);
if (rejected.length) {
  console.log('\nRejected requests (expected for the anti-cheat paths):');
  for (const r of [...new Set(rejected)]) console.log(`  · ${r}`);
}
const unique = [...new Set(problems)];
if (unique.length) {
  console.log('\nProblems:');
  for (const p of unique) console.log(` - ${p}`);
}
process.exit(results.some((r) => !r.ok) || unique.length ? 1 : 0);
