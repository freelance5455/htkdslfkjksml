/**
 * Offline queue check.
 *
 * Proves the honest claim in docs/KNOWN_LIMITATIONS.md: a session that is
 * *in progress* when the network drops is finished locally, shown as
 * "Saved locally", queued in IndexedDB, and submitted automatically when the
 * connection returns — without creating a duplicate result.
 *
 * Usage: node tests/offline-check.mjs [baseUrl]
 */
import { chromium } from 'playwright-core';

const BASE = process.argv[2] ?? 'http://127.0.0.1:8080';
const ACCOUNT = { username: 'student1', password: 'BicaDemo2026!' };
const problems = [];
const results = [];
const record = (name, ok, detail = '') => {
  results.push({ name, ok, detail });
  if (!ok) problems.push(`${name}${detail ? ` — ${detail}` : ''}`);
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`);
};

const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, bypassCSP: true });
const page = await context.newPage();
page.on('pageerror', (err) => problems.push(`exception: ${err.message}`));

try {
  await page.goto(`${BASE}/#/login`, { waitUntil: 'networkidle' });
  await page.fill('input[name="username"]', ACCOUNT.username);
  await page.fill('input[type="password"]', ACCOUNT.password);
  await page.click('button[type="submit"]');
  await page.waitForSelector('.content', { timeout: 20000 });
  await page.waitForTimeout(1200);

  // A service worker must be controlling the page for the shell to work offline.
  const controlled = await page.evaluate(() => Boolean(navigator.serviceWorker?.controller));
  record('service worker controls the page', controlled, controlled ? '' : 'not yet activated');

  await page.goto(`${BASE}/#/practice`, { waitUntil: 'networkidle' });
  await page.click('[data-duration="15"]');
  await page.click('button:has-text("Start practice")');
  await page.waitForSelector('.typing-target', { timeout: 20000 });

  const text = await page.$$eval('.typing-target .ch', (els) => els.map((e) => e.textContent).join('').replace(/\u00a0/g, ' ').slice(0, 120));
  await page.click('.typing-target');
  await page.keyboard.type(text, { delay: 62 });

  // The network goes away mid-exercise.
  await context.setOffline(true);
  await page.waitForTimeout(400);
  await page.click('.typing-bar button:has-text("Finish")');

  await page.waitForSelector('.result', { timeout: 20000 }).catch(() => {});
  const resultText = await page.locator('.result').innerText().catch(() => '');
  record('offline result screen appears', resultText.length > 0, resultText.split('\n')[0] ?? '');
  record('offline result says it is saved locally', /saved locally|no connection/i.test(resultText), resultText.split('\n')[0] ?? '');

  const queued = await page.evaluate(async () => {
    const db = await new Promise((resolve, reject) => {
      const req = indexedDB.open('bica-typing-studio');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    const names = [...db.objectStoreNames];
    if (!names.includes('pending')) return { found: false, names };
    const store = 'pending';
    const count = await new Promise((resolve) => {
      const req = db.transaction(store).objectStore(store).count();
      req.onsuccess = () => resolve(req.result);
    });
    return { found: true, names, store, count };
  });
  record('the result is queued in IndexedDB', Boolean(queued.count), JSON.stringify(queued));

  const before = await page.request.get(`${BASE}/api/me/sessions`).then((r) => r.json());

  await context.setOffline(false);
  await page.waitForTimeout(1200);
  // Nudge the queue the way the app does on reconnect, then give the real
  // network a moment: Chromium's offline emulation can report `onLine` before
  // requests actually succeed.
  await page.evaluate(() => window.dispatchEvent(new Event('online')));

  const countQueue = () => page.evaluate(async () => {
    const db = await new Promise((resolve, reject) => {
      const req = indexedDB.open('bica-typing-studio');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    const names = [...db.objectStoreNames];
    if (!names.includes('pending')) return 0;
    return new Promise((resolve) => {
      const req = db.transaction('pending').objectStore('pending').count();
      req.onsuccess = () => resolve(req.result);
    });
  });

  let remaining = await countQueue();
  for (let i = 0; i < 12 && remaining > 0; i += 1) {
    await page.waitForTimeout(1500);
    await page.evaluate(() => window.dispatchEvent(new Event('online')));
    remaining = await countQueue();
  }
  record('the queue empties once the connection returns', remaining === 0, `${remaining} still pending`);

  const after = await page.request.get(`${BASE}/api/me/sessions`).then((r) => r.json());
  const grew = (after.sessions?.length ?? 0) - (before.sessions?.length ?? 0);
  record('the offline result reached the server exactly once', grew === 1, `${grew} new session(s)`);
} catch (err) {
  record('offline flow', false, err.message);
} finally {
  await context.setOffline(false);
  await browser.close();
}

const passed = results.filter((r) => r.ok).length;
console.log(`\n${passed}/${results.length} offline checks passed`);
const unique = [...new Set(problems)];
if (unique.length) {
  console.log('Problems:');
  for (const p of unique) console.log(` - ${p}`);
}
process.exit(results.some((r) => !r.ok) || unique.length ? 1 : 0);
