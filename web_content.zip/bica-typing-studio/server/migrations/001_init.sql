-- BICA TYPING STUDIO — initial schema (migration 001)
-- Forward-only. Every table is created here; later migrations alter additively.

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------- identity
CREATE TABLE users (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  username        TEXT    NOT NULL UNIQUE,
  password_hash   TEXT    NOT NULL,
  role            TEXT    NOT NULL CHECK (role IN ('ADMIN','INSTRUCTOR','STUDENT')),
  display_name    TEXT    NOT NULL,
  email           TEXT,
  phone           TEXT,
  is_active       INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  must_change_pw  INTEGER NOT NULL DEFAULT 0 CHECK (must_change_pw IN (0,1)),
  is_demo         INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0,1)),
  prefs_json      TEXT    NOT NULL DEFAULT '{}',
  created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
  last_login_at   TEXT,
  CHECK (length(username) BETWEEN 3 AND 40),
  CHECK (length(display_name) BETWEEN 1 AND 80)
);
CREATE INDEX idx_users_role ON users(role, is_active);

CREATE TABLE auth_sessions (
  id           TEXT PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at   TEXT NOT NULL,
  ip           TEXT,
  user_agent   TEXT,
  revoked_at   TEXT
);
CREATE INDEX idx_auth_sessions_user ON auth_sessions(user_id, expires_at);

CREATE TABLE login_attempts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  username   TEXT NOT NULL,
  ip         TEXT,
  succeeded  INTEGER NOT NULL CHECK (succeeded IN (0,1)),
  at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_login_attempts ON login_attempts(username, at);

-- ------------------------------------------------------------ institution
CREATE TABLE classes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  code        TEXT NOT NULL UNIQUE,
  description TEXT,
  instructor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE class_instructors (
  class_id      INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  instructor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (class_id, instructor_id)
);

CREATE TABLE enrollments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id      INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  status        TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','COMPLETED','WITHDRAWN')),
  enrolled_at   TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (student_id, class_id)
);
CREATE INDEX idx_enrollments_class ON enrollments(class_id, status);

-- -------------------------------------------------------------- curriculum
CREATE TABLE lessons (
  id            TEXT PRIMARY KEY,               -- e.g. L1-03 (matches shared/curriculum.js)
  level         INTEGER NOT NULL CHECK (level BETWEEN 0 AND 6),
  order_index   INTEGER NOT NULL,
  title         TEXT NOT NULL,
  objective     TEXT NOT NULL,
  target_keys   TEXT NOT NULL,                  -- space separated key set
  min_accuracy  REAL NOT NULL,
  min_wpm       REAL NOT NULL DEFAULT 0,
  est_minutes   REAL NOT NULL DEFAULT 3,
  curriculum_version TEXT NOT NULL,
  UNIQUE (level, order_index)
);

CREATE TABLE lesson_progress (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id    TEXT NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  attempts     INTEGER NOT NULL DEFAULT 0,
  best_accuracy REAL NOT NULL DEFAULT 0,
  best_wpm     REAL NOT NULL DEFAULT 0,
  total_ms     INTEGER NOT NULL DEFAULT 0,
  mastered_at  TEXT,
  last_attempt_at TEXT,
  UNIQUE (student_id, lesson_id)
);

-- ---------------------------------------------------------------- activity
CREATE TABLE typing_session_tokens (
  id          TEXT PRIMARY KEY,                 -- opaque, server-issued
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source      TEXT NOT NULL CHECK (source IN ('lesson','practice','test','game','challenge')),
  ref_id      TEXT,
  expected_ms INTEGER NOT NULL,
  target_chars INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  consumed_at TEXT
);
CREATE INDEX idx_tokens_user ON typing_session_tokens(user_id, created_at);

CREATE TABLE typing_sessions (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source             TEXT NOT NULL CHECK (source IN ('lesson','practice','test','game','challenge')),
  ref_id             TEXT,
  title              TEXT,
  mode               TEXT,                       -- time | words | text | lesson
  target_chars       INTEGER NOT NULL DEFAULT 0,
  typed_chars        INTEGER NOT NULL DEFAULT 0,
  correct_chars      INTEGER NOT NULL DEFAULT 0,
  error_keystrokes   INTEGER NOT NULL DEFAULT 0,
  uncorrected_errors INTEGER NOT NULL DEFAULT 0,
  backspaces         INTEGER NOT NULL DEFAULT 0,
  duration_ms        INTEGER NOT NULL,
  gross_wpm          REAL NOT NULL,
  net_wpm            REAL NOT NULL,
  accuracy           REAL NOT NULL CHECK (accuracy BETWEEN 0 AND 100),
  consistency        REAL NOT NULL DEFAULT 0,
  passed             INTEGER NOT NULL DEFAULT 0,
  verified           INTEGER NOT NULL DEFAULT 1,
  client_session_id  TEXT NOT NULL UNIQUE,
  token_id           TEXT,
  started_at         TEXT NOT NULL,
  ended_at           TEXT NOT NULL,
  created_at         TEXT NOT NULL DEFAULT (datetime('now')),
  meta_json          TEXT NOT NULL DEFAULT '{}',
  CHECK (typed_chars >= 0 AND correct_chars >= 0 AND duration_ms > 0)
);
CREATE INDEX idx_sessions_student_time ON typing_sessions(student_id, started_at DESC);
CREATE INDEX idx_sessions_source ON typing_sessions(source, student_id, started_at DESC);

CREATE TABLE typing_errors (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id   INTEGER NOT NULL REFERENCES typing_sessions(id) ON DELETE CASCADE,
  key          TEXT NOT NULL,
  attempts     INTEGER NOT NULL DEFAULT 0,
  errors       INTEGER NOT NULL DEFAULT 0,
  avg_interval_ms REAL NOT NULL DEFAULT 0
);
CREATE INDEX idx_typing_errors_session ON typing_errors(session_id);

CREATE TABLE key_statistics (
  student_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key          TEXT NOT NULL,
  attempts     INTEGER NOT NULL DEFAULT 0,
  errors       INTEGER NOT NULL DEFAULT 0,
  total_interval_ms INTEGER NOT NULL DEFAULT 0,
  intervals    INTEGER NOT NULL DEFAULT 0,
  updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (student_id, key)
);

CREATE TABLE game_sessions (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game_id           TEXT NOT NULL,
  difficulty        TEXT NOT NULL,
  score             INTEGER NOT NULL,
  accuracy          REAL NOT NULL CHECK (accuracy BETWEEN 0 AND 100),
  wpm               REAL NOT NULL DEFAULT 0,
  typed_chars       INTEGER NOT NULL DEFAULT 0,
  correct_chars     INTEGER NOT NULL DEFAULT 0,
  error_keystrokes  INTEGER NOT NULL DEFAULT 0,
  duration_ms       INTEGER NOT NULL,
  level_reached     INTEGER NOT NULL DEFAULT 0,
  outcome           TEXT NOT NULL DEFAULT 'COMPLETE',
  verified          INTEGER NOT NULL DEFAULT 1,
  client_session_id TEXT NOT NULL UNIQUE,
  token_id          TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  meta_json         TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX idx_game_sessions_student ON game_sessions(student_id, created_at DESC);
CREATE INDEX idx_game_sessions_board ON game_sessions(game_id, difficulty, score DESC);

CREATE TABLE typing_tests (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  instructor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  title        TEXT NOT NULL,
  passage      TEXT NOT NULL,
  duration_ms  INTEGER NOT NULL DEFAULT 60000,
  min_wpm      REAL NOT NULL DEFAULT 0,
  min_accuracy REAL NOT NULL DEFAULT 95,
  allow_backspace INTEGER NOT NULL DEFAULT 1,
  show_timer   INTEGER NOT NULL DEFAULT 1,
  show_live_wpm INTEGER NOT NULL DEFAULT 1,
  randomize    INTEGER NOT NULL DEFAULT 0,
  is_active    INTEGER NOT NULL DEFAULT 1,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ------------------------------------------------------------- assignments
CREATE TABLE assignments (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  instructor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id     INTEGER REFERENCES classes(id) ON DELETE CASCADE,
  student_id   INTEGER REFERENCES users(id) ON DELETE CASCADE,
  kind         TEXT NOT NULL CHECK (kind IN ('LESSON','GAME','TEST','PRACTICE')),
  target_ref   TEXT NOT NULL,
  title        TEXT NOT NULL,
  instructions TEXT,
  criteria_json TEXT NOT NULL DEFAULT '{}',
  due_at       TEXT,
  is_active    INTEGER NOT NULL DEFAULT 1,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (class_id IS NOT NULL OR student_id IS NOT NULL)
);
CREATE INDEX idx_assignments_class ON assignments(class_id, due_at);
CREATE INDEX idx_assignments_student ON assignments(student_id, due_at);

CREATE TABLE assignment_submissions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  assignment_id INTEGER NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  student_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_id    INTEGER REFERENCES typing_sessions(id) ON DELETE SET NULL,
  game_session_id INTEGER REFERENCES game_sessions(id) ON DELETE SET NULL,
  status        TEXT NOT NULL DEFAULT 'SUBMITTED' CHECK (status IN ('SUBMITTED','PASSED','FAILED','LATE')),
  score         REAL NOT NULL DEFAULT 0,
  feedback      TEXT,
  submitted_at  TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (assignment_id, student_id, session_id)
);
CREATE INDEX idx_submissions_assignment ON assignment_submissions(assignment_id, status);

-- -------------------------------------------------------------- engagement
CREATE TABLE achievements (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT NOT NULL,
  icon        TEXT NOT NULL,
  tier        TEXT NOT NULL DEFAULT 'bronze' CHECK (tier IN ('bronze','silver','gold','platinum')),
  rule_json   TEXT NOT NULL,
  sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE student_achievements (
  student_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  achievement_id TEXT NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
  earned_at      TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (student_id, achievement_id)
);

CREATE TABLE challenges (
  id          TEXT PRIMARY KEY,                 -- daily-2026-10-31 / weekly-2026-W44
  kind        TEXT NOT NULL CHECK (kind IN ('DAILY','WEEKLY')),
  title       TEXT NOT NULL,
  passage     TEXT NOT NULL,
  duration_ms INTEGER NOT NULL,
  starts_at   TEXT NOT NULL,
  ends_at     TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE challenge_attempts (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  challenge_id TEXT NOT NULL REFERENCES challenges(id) ON DELETE CASCADE,
  student_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_id   INTEGER NOT NULL REFERENCES typing_sessions(id) ON DELETE CASCADE,
  net_wpm      REAL NOT NULL,
  accuracy     REAL NOT NULL,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (challenge_id, student_id)
);

CREATE TABLE certificates (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  certificate_no   TEXT NOT NULL UNIQUE,
  verification_code TEXT NOT NULL UNIQUE,
  student_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_title     TEXT NOT NULL,
  level            INTEGER NOT NULL,
  best_wpm         REAL NOT NULL,
  best_accuracy    REAL NOT NULL,
  lessons_mastered INTEGER NOT NULL,
  issued_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  issued_at        TEXT NOT NULL DEFAULT (datetime('now')),
  revoked_at       TEXT,
  revoke_reason    TEXT,
  payload_json     TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX idx_cert_student ON certificates(student_id);

-- -------------------------------------------------------- notes / settings
CREATE TABLE instructor_notes (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  instructor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  student_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  note         TEXT NOT NULL,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (length(note) <= 2000)
);
CREATE INDEX idx_notes_student ON instructor_notes(student_id, created_at DESC);

CREATE TABLE app_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action     TEXT NOT NULL,
  target     TEXT,
  detail_json TEXT NOT NULL DEFAULT '{}',
  at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_audit_at ON audit_log(at DESC);

CREATE TABLE sync_records (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client_ref    TEXT NOT NULL,
  kind          TEXT NOT NULL,
  status        TEXT NOT NULL CHECK (status IN ('PENDING','SYNCED','FAILED')),
  attempts      INTEGER NOT NULL DEFAULT 0,
  last_error    TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (student_id, client_ref)
);
