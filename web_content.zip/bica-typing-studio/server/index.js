import { loadConfig } from './config.js';
import { openDb, migrate } from './db.js';
import { createApp } from './app.js';
import { ensureDefaults } from './seed-data.js';

const config = loadConfig();
const db = openDb(config.dbPath);
const ran = migrate(db);
if (ran.length) console.log(`[bica] applied migrations: ${ran.join(', ')}`);
ensureDefaults(db);

const app = createApp({ db, config });
const server = app.listen(config.port, config.host, () => {
  console.log(`[bica] BICA Typing Studio listening on http://${config.host}:${config.port}`);
  console.log(`[bica] database: ${config.dbPath}`);
  console.log(`[bica] mode: ${config.env}`);
});

function shutdown(signal) {
  console.log(`[bica] ${signal} received, closing…`);
  server.close(() => {
    try { db.close(); } catch { /* already closed */ }
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
