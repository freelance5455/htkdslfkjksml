/**
 * Seeding.
 *
 *   npm run seed          creates the first administrator (if none exists)
 *   npm run seed:demo     additionally creates clearly-flagged demo accounts
 *
 * Design rule: no fabricated performance numbers are ever written. Demo
 * accounts start with genuinely empty history, and the UI shows real empty
 * states. If you want demo data for screenshots, run scripts/simulate.js, which
 * drives the real typing engine and the real submission endpoint.
 */
import crypto from 'node:crypto';
import { loadConfig } from './config.js';
import { openDb, migrate } from './db.js';
import { hashPassword } from './auth.js';
import { syncLessons, ensureDefaults } from './seed-data.js';

const config = loadConfig();
const db = openDb(config.dbPath);
const ran = migrate(db);
if (ran.length) console.log(`[bica] applied migrations: ${ran.join(', ')}`);
syncLessons(db);
ensureDefaults(db);

const demo = process.argv.includes('--demo');

function passwordFromEnv(envKey) {
  return process.env[envKey] || null;
}

function createUser({ username, displayName, role, password, isDemo = false, mustChange = true }) {
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) {
    console.log(`[bica] user "${username}" already exists (id ${existing.id}) — left untouched.`);
    return existing.id;
  }
  const info = db.prepare(`
    INSERT INTO users (username, password_hash, role, display_name, is_demo, must_change_pw)
    VALUES (?,?,?,?,?,?)
  `).run(username, hashPassword(password), role, displayName, isDemo ? 1 : 0, mustChange ? 1 : 0);
  console.log(`[bica] created ${role} "${username}" (id ${info.lastInsertRowid})`);
  return info.lastInsertRowid;
}

const adminCount = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'ADMIN'").get().c;
if (adminCount === 0) {
  const username = process.env.BICA_ADMIN_USER || 'admin';
  const password = passwordFromEnv('BICA_ADMIN_PASSWORD') || crypto.randomBytes(9).toString('base64url');
  createUser({ username, displayName: 'Centre Administrator', role: 'ADMIN', password, mustChange: true });
  if (!passwordFromEnv('BICA_ADMIN_PASSWORD')) {
    console.log('');
    console.log('  ┌──────────────────────────────────────────────────────────────┐');
    console.log('  │ FIRST ADMINISTRATOR CREATED — record this password now.       │');
    console.log('  │ It is shown once and cannot be recovered, only reset.         │');
    console.log('  └──────────────────────────────────────────────────────────────┘');
    console.log(`     username: ${username}`);
    console.log(`     password: ${password}`);
    console.log('     You will be asked to change it at first sign-in.');
    console.log('');
  }
} else {
  console.log('[bica] an administrator already exists — no admin account created.');
}

if (demo) {
  const instructorPassword = passwordFromEnv('BICA_DEMO_PASSWORD') || 'BicaDemo2026!';
  const studentPassword = passwordFromEnv('BICA_DEMO_PASSWORD') || 'BicaDemo2026!';

  const instructorId = createUser({
    username: 'instructor', displayName: 'Demo Instructor', role: 'INSTRUCTOR',
    password: instructorPassword, isDemo: true, mustChange: false,
  });
  const classCode = 'DEMO-B1';
  let cls = db.prepare('SELECT id FROM classes WHERE code = ?').get(classCode);
  if (!cls) {
    const info = db.prepare('INSERT INTO classes (name, code, description, instructor_id) VALUES (?,?,?,?)')
      .run('Demo Batch B1', classCode, 'Sample batch for evaluation. Safe to delete.', instructorId);
    cls = { id: info.lastInsertRowid };
    console.log(`[bica] created demo class ${classCode} (id ${cls.id})`);
  }

  const demoStudents = [
    { username: 'student1', displayName: 'Demo Student One' },
    { username: 'student2', displayName: 'Demo Student Two' },
  ];
  for (const s of demoStudents) {
    const id = createUser({ ...s, role: 'STUDENT', password: studentPassword, isDemo: true, mustChange: false });
    db.prepare("INSERT OR IGNORE INTO enrollments (student_id, class_id) VALUES (?,?)").run(id, cls.id);
  }
  console.log('');
  console.log('[bica] demo accounts (all flagged is_demo=1, removable from Admin → Demo data):');
  console.log(`     instructor / ${instructorPassword}`);
  console.log(`     student1   / ${studentPassword}`);
  console.log(`     student2   / ${studentPassword}`);
  console.log('     Demo accounts contain NO fabricated statistics — only real empty state.');
  console.log('');
}

db.close();
console.log('[bica] seed complete.');
