/**
 * Backup and restore.
 *
 *   node server/backup.js backup            create a timestamped snapshot
 *   node server/backup.js list              list snapshots
 *   node server/backup.js restore <file>    restore (stop the server first)
 *
 * The snapshot uses SQLite's online backup API, so it is safe to run while the
 * server is handling requests (no torn copy, no need to stop the lab).
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb, migrate, defaultDbPath } from './db.js';
import { loadConfig } from './config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function backupDir(config) {
  return process.env.BICA_BACKUP_DIR || path.join(path.dirname(config.dbPath || defaultDbPath()), 'backups');
}

export async function createBackup(db, config) {
  const dir = backupDir(config);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(dir, `bica-${stamp}.db`);
  await db.backup(file);
  fs.chmodSync(file, 0o600);
  const stat = fs.statSync(file);
  return { file: path.basename(file), path: file, bytes: stat.size, createdAt: new Date().toISOString() };
}

export function listBackups(config) {
  const dir = backupDir(config);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter((f) => /^bica-.*\.db$/.test(f))
    .map((f) => {
      const stat = fs.statSync(path.join(dir, f));
      return { file: f, bytes: stat.size, createdAt: stat.mtime.toISOString() };
    })
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function restoreBackup(sourceFile, config) {
  const dir = backupDir(config);
  const full = path.isAbsolute(sourceFile) ? sourceFile : path.join(dir, path.basename(sourceFile));
  if (!fs.existsSync(full)) throw new Error(`Backup not found: ${full}`);
  const target = config.dbPath || defaultDbPath();

  // Keep the current database before overwriting it, so a bad restore is undoable.
  if (fs.existsSync(target)) {
    const safety = `${target}.pre-restore-${Date.now()}`;
    fs.copyFileSync(target, safety);
    console.log(`[bica] current database saved to ${safety}`);
  }
  for (const suffix of ['-wal', '-shm']) {
    const sidecar = `${target}${suffix}`;
    if (fs.existsSync(sidecar)) fs.rmSync(sidecar);
  }
  fs.copyFileSync(full, target);
  fs.chmodSync(target, 0o600);
  return target;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  const config = loadConfig();
  const command = process.argv[2] ?? 'backup';
  if (command === 'backup') {
    const db = openDb(config.dbPath);
    migrate(db);
    createBackup(db, config).then((result) => {
      console.log(`[bica] backup written: ${result.file} (${(result.bytes / 1024).toFixed(1)} KB)`);
      db.close();
    }).catch((err) => { console.error('[bica] backup failed:', err.message); process.exitCode = 1; });
  } else if (command === 'list') {
    for (const b of listBackups(config)) console.log(`${b.file}\t${(b.bytes / 1024).toFixed(1)} KB\t${b.createdAt}`);
  } else if (command === 'restore') {
    const file = process.argv[3];
    if (!file) { console.error('Usage: node server/backup.js restore <file>'); process.exit(1); }
    console.log(`[bica] restored to ${restoreBackup(file, config)}`);
  } else {
    console.error(`Unknown command: ${command}`);
    process.exit(1);
  }
}
