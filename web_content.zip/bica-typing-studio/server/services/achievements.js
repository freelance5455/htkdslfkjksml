/**
 * Achievement evaluation.
 * Rules are evaluated from stored activity only. Nothing can be earned by
 * clicking, and an achievement is recorded once (PRIMARY KEY guard).
 */
import { LESSONS } from '../../shared/curriculum.js';

export const ACHIEVEMENTS = [
  { id: 'first-session', name: 'First Keystroke', description: 'Complete your first recorded practice session.', icon: 'spark', tier: 'bronze', sort: 10 },
  { id: 'first-lesson', name: 'First Lesson', description: 'Complete any curriculum lesson drill.', icon: 'book', tier: 'bronze', sort: 20 },
  { id: 'home-row-master', name: 'Home Row Master', description: 'Master the beginner checkpoint lesson (L1-08).', icon: 'home', tier: 'silver', sort: 30 },
  { id: 'wpm-10', name: '10 WPM', description: 'Reach a verified net speed of 10 words per minute.', icon: 'speed', tier: 'bronze', sort: 40 },
  { id: 'wpm-20', name: '20 WPM', description: 'Reach a verified net speed of 20 words per minute.', icon: 'speed', tier: 'bronze', sort: 41 },
  { id: 'wpm-30', name: '30 WPM', description: 'Reach a verified net speed of 30 words per minute.', icon: 'speed', tier: 'silver', sort: 42 },
  { id: 'wpm-40', name: '40 WPM', description: 'Reach a verified net speed of 40 words per minute.', icon: 'speed', tier: 'gold', sort: 43 },
  { id: 'wpm-60', name: '60 WPM', description: 'Reach a verified net speed of 60 words per minute.', icon: 'speed', tier: 'platinum', sort: 44 },
  { id: 'accuracy-champion', name: 'Accuracy Champion', description: 'Finish a session of 200+ characters at 99% accuracy or better.', icon: 'target', tier: 'gold', sort: 50 },
  { id: 'perfect-lesson', name: 'Perfect Lesson', description: 'Pass a lesson drill with 100% accuracy.', icon: 'check', tier: 'silver', sort: 51 },
  { id: 'consistency-90', name: 'Metronome', description: 'Score 90% or better typing consistency on a 300+ character session.', icon: 'wave', tier: 'silver', sort: 52 },
  { id: 'streak-3', name: 'Three-Day Streak', description: 'Practise on three consecutive days.', icon: 'flame', tier: 'bronze', sort: 60 },
  { id: 'streak-7', name: 'Seven-Day Streak', description: 'Practise on seven consecutive days.', icon: 'flame', tier: 'gold', sort: 61 },
  { id: 'streak-30', name: 'Thirty-Day Streak', description: 'Practise on thirty consecutive days.', icon: 'flame', tier: 'platinum', sort: 62 },
  { id: 'lessons-10', name: 'Ten Lessons Down', description: 'Master ten curriculum lessons.', icon: 'stack', tier: 'bronze', sort: 70 },
  { id: 'lessons-25', name: 'Halfway There', description: 'Master twenty-five curriculum lessons.', icon: 'stack', tier: 'silver', sort: 71 },
  { id: 'curriculum-complete', name: 'Course Complete', description: 'Master every lesson in the curriculum.', icon: 'crown', tier: 'platinum', sort: 72 },
  { id: 'arcade-explorer', name: 'Arcade Explorer', description: 'Play six different arcade games.', icon: 'gamepad', tier: 'silver', sort: 80 },
  { id: 'arcade-50', name: 'Arcade Regular', description: 'Play fifty arcade rounds.', icon: 'gamepad', tier: 'gold', sort: 81 },
  { id: 'exam-passed', name: 'Examination Passed', description: 'Pass a scored examination lesson.', icon: 'medal', tier: 'gold', sort: 90 },
  { id: 'challenge-5', name: 'Challenger', description: 'Complete five daily or weekly challenges.', icon: 'bolt', tier: 'silver', sort: 91 },
  { id: 'certificate-earned', name: 'Certified', description: 'Earn a BICA typing certificate.', icon: 'award', tier: 'platinum', sort: 100 },
  { id: 'practice-60', name: 'One Hour In', description: 'Accumulate sixty minutes of verified practice.', icon: 'clock', tier: 'bronze', sort: 110 },
  { id: 'marathon', name: 'Marathon', description: 'Complete a single session of ten minutes or longer.', icon: 'clock', tier: 'silver', sort: 111 },
];

export const ACHIEVEMENT_BY_ID = new Map(ACHIEVEMENTS.map((a) => [a.id, a]));

export function seedAchievements(db) {
  const stmt = db.prepare(`
    INSERT INTO achievements (id, name, description, icon, tier, rule_json, sort_order)
    VALUES (@id, @name, @description, @icon, @tier, @rule, @sort)
    ON CONFLICT(id) DO UPDATE SET name = excluded.name, description = excluded.description,
      icon = excluded.icon, tier = excluded.tier, sort_order = excluded.sort_order
  `);
  const tx = db.transaction(() => {
    for (const a of ACHIEVEMENTS) stmt.run({ ...a, rule: '{}' });
  });
  tx();
}

function distinctDays(db, userId) {
  const rows = db.prepare(`
    SELECT DISTINCT date(started_at) AS d FROM typing_sessions WHERE student_id = ?
    UNION SELECT DISTINCT date(created_at) FROM game_sessions WHERE student_id = ?
    ORDER BY d DESC
  `).all(userId, userId);
  return rows.map((r) => r.d);
}

export function computeStreak(days) {
  if (!days.length) return 0;
  const sorted = [...new Set(days)].sort().reverse();
  const today = new Date();
  const iso = (d) => d.toISOString().slice(0, 10);
  const todayKey = iso(today);
  const yesterdayKey = iso(new Date(today.getTime() - 86400000));
  if (sorted[0] !== todayKey && sorted[0] !== yesterdayKey) return 0;
  let streak = 1;
  let cursor = new Date(`${sorted[0]}T00:00:00Z`);
  for (let i = 1; i < sorted.length; i += 1) {
    cursor = new Date(cursor.getTime() - 86400000);
    if (sorted[i] === iso(cursor)) streak += 1;
    else break;
  }
  return streak;
}

/** Evaluate every rule; persist and return only newly earned achievements. */
export function evaluateAchievements(db, userId) {
  const stats = {
    sessions: db.prepare('SELECT COUNT(*) AS c FROM typing_sessions WHERE student_id = ?').get(userId).c,
    lessonSessions: db.prepare("SELECT COUNT(*) AS c FROM typing_sessions WHERE student_id = ? AND source = 'lesson'").get(userId).c,
    bestWpm: db.prepare('SELECT COALESCE(MAX(net_wpm),0) AS v FROM typing_sessions WHERE student_id = ? AND verified = 1').get(userId).v,
    bestAccuracy: db.prepare('SELECT COALESCE(MAX(accuracy),0) AS v FROM typing_sessions WHERE student_id = ? AND verified = 1').get(userId).v,
    bestConsistency: db.prepare('SELECT COALESCE(MAX(consistency),0) AS v FROM typing_sessions WHERE student_id = ? AND typed_chars >= 300').get(userId).v,
    perfectLesson: db.prepare("SELECT COUNT(*) AS c FROM typing_sessions WHERE student_id = ? AND source='lesson' AND accuracy >= 100 AND passed = 1").get(userId).c,
    examPassed: db.prepare("SELECT COUNT(*) AS c FROM typing_sessions WHERE student_id = ? AND passed = 1 AND ref_id IN (SELECT id FROM lessons WHERE level >= 5)").get(userId).c,
    mastered: db.prepare('SELECT COUNT(*) AS c FROM lesson_progress WHERE student_id = ? AND mastered_at IS NOT NULL').get(userId).c,
    homeRow: db.prepare("SELECT 1 AS ok FROM lesson_progress WHERE student_id = ? AND lesson_id = 'L1-08' AND mastered_at IS NOT NULL").get(userId),
    games: db.prepare('SELECT COUNT(*) AS c FROM game_sessions WHERE student_id = ?').get(userId).c,
    distinctGames: db.prepare('SELECT COUNT(DISTINCT game_id) AS c FROM game_sessions WHERE student_id = ?').get(userId).c,
    challengeSessions: db.prepare("SELECT COUNT(*) AS c FROM typing_sessions WHERE student_id = ? AND source = 'challenge'").get(userId).c,
    certificates: db.prepare('SELECT COUNT(*) AS c FROM certificates WHERE student_id = ? AND revoked_at IS NULL').get(userId).c,
    totalMs: db.prepare('SELECT COALESCE(SUM(duration_ms),0) AS v FROM typing_sessions WHERE student_id = ?').get(userId).v,
    longestMs: db.prepare('SELECT COALESCE(MAX(duration_ms),0) AS v FROM typing_sessions WHERE student_id = ?').get(userId).v,
    streak: computeStreak(distinctDays(db, userId)),
    totalLessons: LESSONS.length,
  };

  const rules = {
    'first-session': stats.sessions >= 1,
    'first-lesson': stats.lessonSessions >= 1,
    'home-row-master': Boolean(stats.homeRow),
    'wpm-10': stats.bestWpm >= 10,
    'wpm-20': stats.bestWpm >= 20,
    'wpm-30': stats.bestWpm >= 30,
    'wpm-40': stats.bestWpm >= 40,
    'wpm-60': stats.bestWpm >= 60,
    'accuracy-champion': db.prepare("SELECT 1 AS ok FROM typing_sessions WHERE student_id = ? AND typed_chars >= 200 AND accuracy >= 99 LIMIT 1").get(userId) != null,
    'perfect-lesson': stats.perfectLesson >= 1,
    'consistency-90': stats.bestConsistency >= 90,
    'streak-3': stats.streak >= 3,
    'streak-7': stats.streak >= 7,
    'streak-30': stats.streak >= 30,
    'lessons-10': stats.mastered >= 10,
    'lessons-25': stats.mastered >= 25,
    'curriculum-complete': stats.mastered >= stats.totalLessons,
    'arcade-explorer': stats.distinctGames >= 6,
    'arcade-50': stats.games >= 50,
    'exam-passed': stats.examPassed >= 1,
    'challenge-5': stats.challengeSessions >= 5,
    'certificate-earned': stats.certificates >= 1,
    'practice-60': stats.totalMs >= 60 * 60 * 1000,
    'marathon': stats.longestMs >= 10 * 60 * 1000,
  };

  const insert = db.prepare('INSERT OR IGNORE INTO student_achievements (student_id, achievement_id) VALUES (?, ?)');
  const earned = [];
  const tx = db.transaction(() => {
    for (const [id, ok] of Object.entries(rules)) {
      if (!ok) continue;
      const res = insert.run(userId, id);
      if (res.changes > 0) earned.push(ACHIEVEMENT_BY_ID.get(id));
    }
  });
  tx();
  return { earned, stats };
}

export function listAchievements(db, userId) {
  const earned = new Map(db.prepare('SELECT achievement_id, earned_at FROM student_achievements WHERE student_id = ?').all(userId)
    .map((r) => [r.achievement_id, r.earned_at]));
  return ACHIEVEMENTS
    .sort((a, b) => a.sort - b.sort)
    .map((a) => ({ ...a, earned: earned.has(a.id), earnedAt: earned.get(a.id) ?? null }));
}
