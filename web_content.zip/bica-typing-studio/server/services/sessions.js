/**
 * Session authority.
 * ---------------------------------------------------------------------------
 * The browser measures; the server judges. A submitted result is accepted only
 * if:
 *   1. it carries a server-issued token belonging to that student,
 *   2. the token is unused and not stale,
 *   3. the server's own clock says enough time actually passed,
 *   4. the implied speed is physically plausible,
 *   5. the metrics recomputed from raw counters agree with the engine's rules.
 * The unique client session id makes retries and offline replays idempotent.
 */
import crypto from 'node:crypto';
import { verifySubmission } from '../../shared/typing-engine.js';
import { getLesson, evaluateAttempt } from '../../shared/curriculum.js';
import { computeGameScore, getGame, SCORING_VERSION } from '../../shared/scoring.js';
import { evaluateAchievements } from './achievements.js';
import { getSettings } from '../settings.js';

const MAX_TOKEN_AGE_MS = 6 * 60 * 60 * 1000;     // absolute ceiling
const MIN_MS_PER_CHAR = 60;                       // ≈ 200 WPM ceiling — beyond this a human result is implausible
// Absolute floor for a session that has no nominal duration. It must stay low:
// the per-character rule above is what actually catches scripted submissions,
// and a short drill (a 17-character home-row line) can legitimately be typed by
// a fast student in under two seconds. Rejecting that would punish the best
// students on the shortest exercises.
const MIN_ROUND_MS = 350;
const SOURCES = ['lesson', 'practice', 'test', 'game', 'challenge'];

export class SessionError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

function sqliteUtcToMs(value) {
  // SQLite datetime('now') is "YYYY-MM-DD HH:MM:SS" in UTC.
  return Date.parse(`${String(value).replace(' ', 'T')}Z`);
}

export function startSession(db, { userId, source, refId = null, expectedMs = 0, targetChars = 0 }) {
  if (!SOURCES.includes(source)) throw new SessionError('bad_source', 'Unknown session source.');
  const id = crypto.randomBytes(24).toString('base64url');
  db.prepare(`
    INSERT INTO typing_session_tokens (id, user_id, source, ref_id, expected_ms, target_chars)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(id, userId, source, refId, Math.max(0, Math.round(expectedMs)), Math.max(0, Math.round(targetChars)));
  return { tokenId: id, startedAt: new Date().toISOString() };
}

function getToken(db, userId, tokenId) {
  return db.prepare('SELECT * FROM typing_session_tokens WHERE id = ? AND user_id = ?').get(tokenId, userId) ?? null;
}

/**
 * @returns {{session:object, duplicate:boolean, passed:boolean, reasons:string[], thresholds:object|null, summary:object, newAchievements:Array}}
 */
export function submitSession(db, config, { user, tokenId, clientSessionId, summary, title = '', mode = 'text', meta = {} }) {
  if (typeof clientSessionId !== 'string' || clientSessionId.length < 8 || clientSessionId.length > 100) {
    throw new SessionError('bad_client_id', 'A client session id is required.');
  }

  // -- idempotent replay: the same client id returns the same stored result ---
  const existing = db.prepare('SELECT * FROM typing_sessions WHERE client_session_id = ?').get(clientSessionId);
  if (existing) {
    if (existing.student_id !== user.id) throw new SessionError('conflict', 'Session id already used.', 409);
    return {
      session: existing,
      duplicate: true,
      passed: Boolean(existing.passed),
      reasons: [],
      thresholds: null,
      summary: {
        grossWpm: existing.gross_wpm, netWpm: existing.net_wpm, accuracy: existing.accuracy,
        consistency: existing.consistency, committedChars: existing.typed_chars,
      },
      newAchievements: [],
    };
  }

  const token = getToken(db, user.id, tokenId);
  if (!token) throw new SessionError('invalid_token', 'This session token is not valid for your account.', 400);
  if (token.consumed_at) throw new SessionError('token_used', 'This session has already been submitted.', 409);

  const startedMs = sqliteUtcToMs(token.created_at);
  if (!Number.isFinite(startedMs)) throw new SessionError('bad_token', 'Session token is corrupt.', 400);
  const serverMs = Date.now() - startedMs;
  if (serverMs > MAX_TOKEN_AGE_MS) throw new SessionError('expired', 'This session expired before submission.', 409);

  // -- clock checks ---------------------------------------------------------
  if (token.expected_ms > 0 && serverMs + config.durationGraceMs < token.expected_ms * config.minDurationRatio) {
    throw new SessionError('too_fast', 'The submission arrived faster than the exercise allows.', 422);
  }

  const committedRaw = Math.max(0, Number(summary?.committedChars ?? summary?.typedChars ?? 0));
  if (committedRaw > 0 && serverMs < committedRaw * MIN_MS_PER_CHAR) {
    throw new SessionError('implausible_speed', 'The reported speed is not physically plausible.', 422);
  }
  if (token.expected_ms === 0 && serverMs < MIN_ROUND_MS) {
    throw new SessionError('too_fast', 'This drill finished faster than a human can type it.', 422);
  }

  // For timed exercises the nominal duration is the denominator; for
  // open-ended drills the elapsed server time is.
  const durationMs = token.expected_ms > 0
    ? Math.min(serverMs, token.expected_ms + config.durationGraceMs)
    : serverMs;

  const metrics = verifySubmission({ summary, serverDurationMs: durationMs });

  // -- lesson-specific authority -------------------------------------------
  let passed = false;
  let reasons = [];
  let thresholds = null;
  let drillLength = 0;
  let lessonId = null;

  if (token.source === 'lesson') {
    const lesson = getLesson(token.ref_id);
    if (!lesson) throw new SessionError('unknown_lesson', 'That lesson does not exist.', 400);
    lessonId = lesson.id;
    const drillIndex = Number(meta.drillIndex ?? 0);
    if (!Number.isInteger(drillIndex) || drillIndex < 0 || drillIndex >= lesson.drills.length) {
      throw new SessionError('bad_drill', 'Unknown drill for this lesson.', 400);
    }
    if (metrics.committedChars > lesson.drills[drillIndex].length + 5) {
      throw new SessionError('overlong', 'Submitted text is longer than the drill.', 422);
    }
    drillLength = lesson.drills[drillIndex].length;
    const settings = getSettings(db);
    const verdict = evaluateAttempt({ lesson, metrics, settings, drillLength });
    passed = verdict.passed;
    reasons = verdict.reasons;
    thresholds = verdict.thresholds;
  }

  if (token.source === 'test') {
    const test = db.prepare('SELECT * FROM typing_tests WHERE id = ?').get(Number(token.ref_id));
    if (test) {
      passed = metrics.accuracy >= test.min_accuracy && metrics.netWpm >= test.min_wpm;
      thresholds = { minAccuracy: test.min_accuracy, minWpm: test.min_wpm };
      if (!passed) reasons = ['Did not meet the pass mark for this test.'];
    }
  }

  const startedAt = new Date(startedMs).toISOString();
  const endedAt = new Date(startedMs + durationMs).toISOString();

  const insert = db.prepare(`
    INSERT INTO typing_sessions (
      student_id, source, ref_id, title, mode, target_chars, typed_chars, correct_chars,
      error_keystrokes, uncorrected_errors, backspaces, duration_ms, gross_wpm, net_wpm,
      accuracy, consistency, passed, verified, client_session_id, token_id, started_at, ended_at, meta_json
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?,?)
  `);

  let sessionId;
  const tx = db.transaction(() => {
    const res = insert.run(
      user.id, token.source, token.ref_id, String(title).slice(0, 120), String(mode).slice(0, 20),
      metrics.committedChars, metrics.committedChars, metrics.correctChars,
      metrics.errorKeystrokes, metrics.uncorrectedErrors, metrics.backspaces,
      metrics.durationMs, metrics.grossWpm, metrics.netWpm, metrics.accuracy, metrics.consistency,
      passed ? 1 : 0, clientSessionId, token.id, startedAt, endedAt,
      JSON.stringify(meta).slice(0, 8000),
    );
    sessionId = res.lastInsertRowid;

    db.prepare('UPDATE typing_session_tokens SET consumed_at = datetime(\'now\') WHERE id = ?').run(token.id);

    // per-key counters for this session
    const errStmt = db.prepare('INSERT INTO typing_errors (session_id, key, attempts, errors, avg_interval_ms) VALUES (?,?,?,?,?)');
    for (const row of (Array.isArray(summary?.perKey) ? summary.perKey.slice(0, 200) : [])) {
      if (!row || typeof row.key !== 'string' || row.key.length === 0 || row.key.length > 4) continue;
      errStmt.run(sessionId, row.key, Math.max(0, Number(row.attempts) || 0), Math.max(0, Number(row.errors) || 0), Math.max(0, Number(row.avgIntervalMs) || 0));
    }

    // rolling per-student key statistics
    const upsert = db.prepare(`
      INSERT INTO key_statistics (student_id, key, attempts, errors, total_interval_ms, intervals, updated_at)
      VALUES (?,?,?,?,?,?, datetime('now'))
      ON CONFLICT(student_id, key) DO UPDATE SET
        attempts = attempts + excluded.attempts,
        errors = errors + excluded.errors,
        total_interval_ms = total_interval_ms + excluded.total_interval_ms,
        intervals = intervals + excluded.intervals,
        updated_at = datetime('now')
    `);
    for (const row of (Array.isArray(summary?.perKey) ? summary.perKey.slice(0, 200) : [])) {
      if (!row || typeof row.key !== 'string' || row.key.length === 0 || row.key.length > 4) continue;
      const attempts = Math.max(0, Number(row.attempts) || 0);
      const intervals = attempts > 0 ? attempts - 1 : 0;
      upsert.run(user.id, row.key, attempts, Math.max(0, Number(row.errors) || 0),
        intervals * Math.max(0, Number(row.avgIntervalMs) || 0), intervals);
    }

    // lesson progress + mastery
    if (lessonId) {
      db.prepare(`
        INSERT INTO lesson_progress (student_id, lesson_id, attempts, best_accuracy, best_wpm, total_ms, mastered_at, last_attempt_at)
        VALUES (?,?,1,?,?,?,?, datetime('now'))
        ON CONFLICT(student_id, lesson_id) DO UPDATE SET
          attempts = attempts + 1,
          best_accuracy = MAX(best_accuracy, excluded.best_accuracy),
          best_wpm = MAX(best_wpm, excluded.best_wpm),
          total_ms = total_ms + excluded.total_ms,
          mastered_at = COALESCE(lesson_progress.mastered_at, excluded.mastered_at),
          last_attempt_at = datetime('now')
      `).run(
        user.id, lessonId, metrics.accuracy, metrics.netWpm, metrics.durationMs,
        passed ? new Date().toISOString().replace('T', ' ').slice(0, 19) : null,
      );
    }

    // challenge attempt (best per student per challenge)
    if (token.source === 'challenge' && token.ref_id) {
      const challenge = db.prepare('SELECT * FROM challenges WHERE id = ?').get(token.ref_id);
      if (challenge && typeof challenge.passage === 'string' && metrics.committedChars <= challenge.passage.length + 5) {
        db.prepare(`
          INSERT INTO challenge_attempts (challenge_id, student_id, session_id, net_wpm, accuracy)
          VALUES (?,?,?,?,?)
          ON CONFLICT(challenge_id, student_id) DO UPDATE SET
            session_id = CASE WHEN excluded.net_wpm > challenge_attempts.net_wpm THEN excluded.session_id ELSE challenge_attempts.session_id END,
            net_wpm = MAX(challenge_attempts.net_wpm, excluded.net_wpm),
            accuracy = MAX(challenge_attempts.accuracy, excluded.accuracy)
        `).run(challenge.id, user.id, sessionId, metrics.netWpm, metrics.accuracy);
      }
    }
  });
  tx();

  const session = db.prepare('SELECT * FROM typing_sessions WHERE id = ?').get(sessionId);
  let newAchievements = [];
  try {
    newAchievements = evaluateAchievements(db, user.id).earned;
  } catch (err) {
    console.error('[bica] achievement evaluation failed', err);
  }

  return { session, duplicate: false, passed, reasons, thresholds, summary: metrics, newAchievements };
}

// --------------------------------------------------------------- game rounds

export function startGameRound(db, { userId, gameId, difficulty }) {
  const game = getGame(gameId);
  if (!game) throw new SessionError('unknown_game', 'That game does not exist.');
  const token = startSession(db, {
    userId, source: 'game', refId: `${gameId}:${difficulty}`, expectedMs: game.durationSec * 1000, targetChars: 0,
  });
  return { ...token, gameId, difficulty, scoringVersion: SCORING_VERSION };
}

export function submitGameRound(db, config, { user, tokenId, clientSessionId, gameId, difficulty, summary, levelReached = 0, outcome = 'COMPLETE', meta = {} }) {
  const game = getGame(gameId);
  if (!game) throw new SessionError('unknown_game', 'That game does not exist.');

  const existing = db.prepare('SELECT * FROM game_sessions WHERE client_session_id = ?').get(clientSessionId);
  if (existing) {
    if (existing.student_id !== user.id) throw new SessionError('conflict', 'Round id already used.', 409);
    return { round: existing, duplicate: true, newAchievements: [] };
  }

  const token = getToken(db, user.id, tokenId);
  if (!token) throw new SessionError('invalid_token', 'Unknown round token.', 400);
  if (token.consumed_at) throw new SessionError('token_used', 'This round was already submitted.', 409);
  if (token.source !== 'game') throw new SessionError('bad_source', 'Token is not a game round.', 400);

  const startedMs = sqliteUtcToMs(token.created_at);
  const serverMs = Date.now() - startedMs;
  if (serverMs > MAX_TOKEN_AGE_MS) throw new SessionError('expired', 'Round expired before submission.', 409);

  // A round that ends suspiciously early is *recorded* but not counted. Refusing
  // it outright punished beginners: losing all three lives in ten seconds is a
  // normal first attempt at Word Guardian, not cheating. So the row is stored
  // with verified = 0 and a zero score, which keeps it out of personal bests and
  // leaderboards without losing the fact that the student played.
  const minimumRoundMs = Math.min(game.durationSec * 1000 * 0.25, 8000);
  const tooShort = serverMs < minimumRoundMs;

  const basePoints = Math.max(0, Math.round(Number(summary?.basePoints ?? 0)));
  const accuracy = Number(summary?.accuracy ?? 0);
  const scored = computeGameScore({ basePoints, accuracy, difficulty, completionBonus: Number(summary?.completionBonus ?? 1) });
  const storedScore = tooShort ? 0 : scored.score;

  const insert = db.prepare(`
    INSERT INTO game_sessions (student_id, game_id, difficulty, score, accuracy, wpm, typed_chars,
      correct_chars, error_keystrokes, duration_ms, level_reached, outcome, verified, client_session_id, token_id, meta_json)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?)
  `);
  let roundId;
  const tx = db.transaction(() => {
    const res = insert.run(
      user.id, gameId, difficulty, storedScore, Math.max(0, Math.min(100, accuracy)),
      Math.max(0, Number(summary?.netWpm ?? 0)), Math.max(0, Number(summary?.committedChars ?? 0)),
      Math.max(0, Number(summary?.correctChars ?? 0)), Math.max(0, Number(summary?.errorKeystrokes ?? 0)),
      Math.max(1, Math.round(serverMs)), Math.max(0, Math.round(levelReached)),
      ['COMPLETE', 'GAME_OVER', 'ABANDONED'].includes(outcome) ? outcome : 'COMPLETE',
      clientSessionId, token.id, JSON.stringify({ ...meta, scoring: scored, tooShort }).slice(0, 6000),
    );
    roundId = res.lastInsertRowid;
    if (tooShort) {
      db.prepare('UPDATE game_sessions SET verified = 0 WHERE id = ?').run(roundId);
    }
    db.prepare("UPDATE typing_session_tokens SET consumed_at = datetime('now') WHERE id = ?").run(token.id);
  });
  tx();

  const round = db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(roundId);
  let newAchievements = [];
  try { newAchievements = evaluateAchievements(db, user.id).earned; } catch { /* non-fatal */ }
  return {
    round,
    duplicate: false,
    scoring: { ...scored, score: storedScore },
    newAchievements,
    note: tooShort
      ? `This round lasted ${(serverMs / 1000).toFixed(1)} s. Rounds shorter than ${Math.round(minimumRoundMs / 1000)} s are recorded but not scored, so a very quick first attempt cannot become a high score.`
      : null,
  };
}
