/**
 * Lightweight, explainable forecast.
 * Uses an exponentially weighted moving average of recent net WPM plus the
 * observed daily improvement rate. Deliberately simple: a student can be told
 * exactly how the number was produced, and the UI always labels it as an
 * estimate rather than a promise.
 */
import { effectiveThresholds } from '../../shared/curriculum.js';

export function predictNext(sessions = [], curriculum = { lessons: [] }, settings = {}) {
  const recent = sessions.filter((s) => Number(s.net_wpm) > 0).slice(0, 10);
  if (recent.length < 3) {
    return {
      available: false,
      reason: 'At least three completed sessions are needed before a forecast is meaningful.',
    };
  }

  const alpha = 0.4;
  let ewma = Number(recent[recent.length - 1].net_wpm);
  for (let i = recent.length - 2; i >= 0; i -= 1) {
    ewma = alpha * Number(recent[i].net_wpm) + (1 - alpha) * ewma;
  }

  // Improvement per session, from the two oldest and two newest of the window.
  const newest = recent.slice(0, 2).reduce((a, s) => a + Number(s.net_wpm), 0) / 2;
  const oldest = recent.slice(-2).reduce((a, s) => a + Number(s.net_wpm), 0) / 2;
  const perSession = (newest - oldest) / Math.max(1, recent.length - 1);
  const projected = Math.max(0, ewma + perSession * 4); // four sessions ahead

  const next = curriculum.lessons?.find((l) => l.unlocked && !l.mastered) ?? null;
  const threshold = next ? effectiveThresholds(next, settings) : null;
  const sessionsToTarget = next && threshold && threshold.minWpm > 0 && perSession > 0.05
    ? Math.max(1, Math.ceil((threshold.minWpm - ewma) / (perSession * 1)))
    : null;

  return {
    available: true,
    estimateWpm: Math.round(projected * 10) / 10,
    currentTrendPerSession: Math.round(perSession * 100) / 100,
    basis: `${recent.length} recent sessions, exponentially weighted (α=0.4), projected four sessions ahead.`,
    sessionsToNextTarget: sessionsToTarget,
    nextTargetWpm: threshold?.minWpm || null,
    confidence: recent.length >= 6 ? 'moderate' : 'low',
  };
}
