/**
 * Report assembly. Pure reads — no route logic — so the same data feeds the
 * instructor UI, the CSV export and the PDF export and cannot drift apart.
 */
import { buildProgressMap, LEVELS, TOTAL_LESSONS } from '../../shared/curriculum.js';
import { rankWeakKeys } from '../../shared/adaptive.js';
import { computeStreak } from './achievements.js';
import { getSettings } from '../settings.js';

export function studentProgress(db, studentId, settings = null) {
  const s = settings ?? getSettings(db);
  const rows = db.prepare('SELECT * FROM lesson_progress WHERE student_id = ?').all(studentId);
  const map = {};
  for (const r of rows) map[r.lesson_id] = { ...r, mastered: Boolean(r.mastered_at) };
  return buildProgressMap(map, s);
}

export function studentReport(db, studentId) {
  const settings = getSettings(db);
  const student = db.prepare(`
    SELECT id, username, display_name, email, phone, is_active, is_demo, created_at, last_login_at
    FROM users WHERE id = ? AND role = 'STUDENT'
  `).get(studentId);
  if (!student) return null;

  const classes = db.prepare(`
    SELECT c.id, c.name, c.code, e.status, e.enrolled_at
    FROM enrollments e JOIN classes c ON c.id = e.class_id
    WHERE e.student_id = ? ORDER BY c.name
  `).all(studentId);

  const sessions = db.prepare(`
    SELECT * FROM typing_sessions WHERE student_id = ? ORDER BY started_at DESC LIMIT 100
  `).all(studentId);

  const agg = db.prepare(`
    SELECT COUNT(*) AS sessions,
           COALESCE(SUM(duration_ms),0) AS total_ms,
           COALESCE(MAX(net_wpm),0) AS best_wpm,
           COALESCE(MAX(accuracy),0) AS best_accuracy,
           COALESCE(AVG(net_wpm),0) AS avg_wpm,
           COALESCE(AVG(accuracy),0) AS avg_accuracy,
           COALESCE(AVG(consistency),0) AS avg_consistency
    FROM typing_sessions WHERE student_id = ? AND verified = 1
  `).get(studentId);

  const progress = studentProgress(db, studentId, settings);
  const keyStats = db.prepare('SELECT * FROM key_statistics WHERE student_id = ?').all(studentId);
  const weakKeys = rankWeakKeys(keyStats, { limit: 10 });

  const games = db.prepare(`
    SELECT game_id, COUNT(*) AS plays, MAX(score) AS best_score, MAX(accuracy) AS best_accuracy, MAX(wpm) AS best_wpm
    FROM game_sessions WHERE student_id = ? GROUP BY game_id ORDER BY plays DESC
  `).all(studentId);

  const tests = db.prepare(`
    SELECT id, title, net_wpm, accuracy, passed, started_at
    FROM typing_sessions WHERE student_id = ? AND source = 'test' ORDER BY started_at DESC LIMIT 20
  `).all(studentId);

  const timeline = db.prepare(`
    SELECT date(started_at) AS day, ROUND(AVG(net_wpm),1) AS avg_wpm, ROUND(AVG(accuracy),1) AS avg_accuracy,
           SUM(duration_ms) AS practice_ms, COUNT(*) AS sessions
    FROM typing_sessions WHERE student_id = ?
    GROUP BY day ORDER BY day ASC LIMIT 180
  `).all(studentId);

  const notes = db.prepare(`
    SELECT n.id, n.note, n.created_at, u.display_name AS author
    FROM instructor_notes n LEFT JOIN users u ON u.id = n.instructor_id
    WHERE n.student_id = ? ORDER BY n.created_at DESC LIMIT 50
  `).all(studentId);

  const certificates = db.prepare(`
    SELECT certificate_no, course_title, best_wpm, best_accuracy, issued_at, revoked_at
    FROM certificates WHERE student_id = ? ORDER BY issued_at DESC
  `).all(studentId);

  const days = db.prepare(`
    SELECT DISTINCT date(started_at) AS d FROM typing_sessions WHERE student_id = ?
    UNION SELECT DISTINCT date(created_at) FROM game_sessions WHERE student_id = ?
  `).all(studentId, studentId).map((x) => x.d);

  const assignments = assignmentStatusForStudent(db, studentId);

  // Risk assessment is deliberately transparent: three named signals.
  const lastSessionDays = sessions[0] ? Math.floor((Date.now() - Date.parse(`${sessions[0].started_at.replace(' ', 'T')}Z`)) / 86400000) : null;
  const riskFlags = [];
  if (lastSessionDays == null) riskFlags.push('No recorded practice yet.');
  else if (lastSessionDays >= 7) riskFlags.push(`No practice for ${lastSessionDays} days.`);
  if (agg.sessions >= 5 && agg.avg_accuracy < 90) riskFlags.push(`Average accuracy ${Math.round(agg.avg_accuracy * 10) / 10}% is below the 90% support threshold.`);
  if (progress.masteredCount === 0 && agg.sessions >= 3) riskFlags.push('Several sessions completed but no lesson mastered.');
  if (assignments.overdue > 0) riskFlags.push(`${assignments.overdue} overdue assignment(s).`);

  return {
    student: {
      id: student.id, username: student.username, displayName: student.display_name,
      email: student.email, phone: student.phone, active: Boolean(student.is_active),
      demo: Boolean(student.is_demo), createdAt: student.created_at, lastLoginAt: student.last_login_at,
    },
    classes,
    enrolment: classes[0] ?? null,
    level: progress.currentLesson?.level ?? 6,
    levelName: LEVELS[progress.currentLesson?.level ?? 6].name,
    progress: {
      mastered: progress.masteredCount,
      total: TOTAL_LESSONS,
      unlocked: progress.unlockedCount,
      currentLesson: progress.currentLesson,
      lessons: progress.lessons.map((l) => ({
        id: l.id, level: l.level, title: l.title, mastered: l.mastered, unlocked: l.unlocked,
        attempts: l.attempts, bestAccuracy: l.bestAccuracy, bestWpm: l.bestWpm, lastAttemptAt: l.lastAttemptAt,
      })),
    },
    stats: {
      sessions: agg.sessions,
      totalMs: agg.total_ms,
      bestWpm: Math.round(agg.best_wpm * 10) / 10,
      avgWpm: Math.round(agg.avg_wpm * 10) / 10,
      bestAccuracy: Math.round(agg.best_accuracy * 10) / 10,
      avgAccuracy: Math.round(agg.avg_accuracy * 10) / 10,
      avgConsistency: Math.round(agg.avg_consistency * 10) / 10,
      streak: computeStreak(days),
      lastPracticeDaysAgo: lastSessionDays,
    },
    weakKeys,
    recentSessions: sessions.slice(0, 25).map((s) => ({
      id: s.id, source: s.source, refId: s.ref_id, title: s.title, netWpm: s.net_wpm,
      accuracy: s.accuracy, durationMs: s.duration_ms, passed: Boolean(s.passed), startedAt: s.started_at,
    })),
    games,
    tests,
    timeline,
    notes,
    certificates,
    assignments,
    riskFlags,
    atRisk: riskFlags.length > 0,
    settings: {
      minAccuracy: settings['curriculum.minAccuracy'],
      minWpm: settings['curriculum.minWpm'],
    },
  };
}

/** Read-time assignment evaluation — no write coupling, always accurate. */
export function assignmentStatusForStudent(db, studentId, onlyClassId = null) {
  const rows = db.prepare(`
    SELECT a.*, c.name AS class_name, u.display_name AS instructor_name
    FROM assignments a
    LEFT JOIN classes c ON c.id = a.class_id
    LEFT JOIN users u ON u.id = a.instructor_id
    WHERE a.is_active = 1 AND (
      (a.student_id = ?) OR (a.class_id IS NOT NULL AND a.class_id IN (SELECT class_id FROM enrollments WHERE student_id = ?))
    ) ${onlyClassId ? 'AND a.class_id = ?' : ''}
    ORDER BY a.due_at IS NULL, a.due_at ASC, a.created_at DESC
  `).all(...(onlyClassId ? [studentId, studentId, onlyClassId] : [studentId, studentId]));

  const items = rows.map((a) => {
    let qualifying = null;
    if (a.kind === 'LESSON') {
      qualifying = db.prepare(`
        SELECT * FROM typing_sessions WHERE student_id = ? AND source = 'lesson' AND ref_id = ?
          AND passed = 1 AND started_at >= ? ORDER BY started_at DESC LIMIT 1
      `).get(studentId, a.target_ref, a.created_at);
    } else if (a.kind === 'TEST') {
      qualifying = db.prepare(`
        SELECT * FROM typing_sessions WHERE student_id = ? AND source = 'test' AND ref_id = ?
          AND started_at >= ? ORDER BY started_at DESC LIMIT 1
      `).get(studentId, a.target_ref, a.created_at);
    } else if (a.kind === 'GAME') {
      qualifying = db.prepare(`
        SELECT * FROM game_sessions WHERE student_id = ? AND game_id = ? AND created_at >= ?
        ORDER BY created_at DESC LIMIT 1
      `).get(studentId, a.target_ref, a.created_at);
    } else if (a.kind === 'PRACTICE') {
      qualifying = db.prepare(`
        SELECT * FROM typing_sessions WHERE student_id = ? AND source = 'practice' AND started_at >= ?
          AND duration_ms >= ? ORDER BY started_at DESC LIMIT 1
      `).get(studentId, a.created_at, Number(JSON.parse(a.criteria_json || '{}').minDurationMs ?? 60000));
    }

    const now = Date.now();
    const due = a.due_at ? Date.parse(`${a.due_at.replace(' ', 'T')}Z`) : null;
    let status = 'PENDING';
    if (qualifying) {
      const doneAt = qualifying.started_at ?? qualifying.created_at;
      status = due && Date.parse(`${doneAt.replace(' ', 'T')}Z`) > due ? 'LATE' : 'COMPLETED';
    } else if (due && now > due) {
      status = 'OVERDUE';
    }

    return {
      id: a.id,
      title: a.title,
      kind: a.kind,
      targetRef: a.target_ref,
      instructions: a.instructions,
      dueAt: a.due_at,
      createdAt: a.created_at,
      className: a.class_name,
      instructorName: a.instructor_name,
      status,
    };
  });

  return {
    items,
    pending: items.filter((i) => i.status === 'PENDING').length,
    overdue: items.filter((i) => i.status === 'OVERDUE').length,
    completed: items.filter((i) => i.status === 'COMPLETED' || i.status === 'LATE').length,
  };
}

export function classReport(db, classId) {
  const cls = db.prepare(`
    SELECT c.*, u.display_name AS instructor_name FROM classes c
    LEFT JOIN users u ON u.id = c.instructor_id WHERE c.id = ?
  `).get(classId);
  if (!cls) return null;

  const students = db.prepare(`
    SELECT u.id, u.username, u.display_name, u.is_active, e.enrolled_at, e.status
    FROM enrollments e JOIN users u ON u.id = e.student_id
    WHERE e.class_id = ? ORDER BY u.display_name
  `).all(classId);

  const rows = students.map((s) => {
    const agg = db.prepare(`
      SELECT COUNT(*) AS sessions, COALESCE(SUM(duration_ms),0) AS ms,
             COALESCE(MAX(net_wpm),0) AS best_wpm, COALESCE(AVG(net_wpm),0) AS avg_wpm,
             COALESCE(AVG(accuracy),0) AS avg_accuracy, MAX(started_at) AS last_at
      FROM typing_sessions WHERE student_id = ? AND verified = 1
    `).get(s.id);
    const mastered = db.prepare('SELECT COUNT(*) AS c FROM lesson_progress WHERE student_id = ? AND mastered_at IS NOT NULL').get(s.id).c;
    const games = db.prepare('SELECT COUNT(*) AS c FROM game_sessions WHERE student_id = ?').get(s.id).c;
    const openAssignments = assignmentStatusForStudent(db, s.id, classId);
    return {
      id: s.id,
      username: s.username,
      displayName: s.display_name,
      active: Boolean(s.is_active),
      enrolledAt: s.enrolled_at,
      status: s.status,
      sessions: agg.sessions,
      practiceMs: agg.ms,
      bestWpm: Math.round(agg.best_wpm * 10) / 10,
      avgWpm: Math.round(agg.avg_wpm * 10) / 10,
      avgAccuracy: Math.round(agg.avg_accuracy * 10) / 10,
      mastered,
      games,
      lastPracticeAt: agg.last_at,
      overdue: openAssignments.overdue,
      pending: openAssignments.pending,
    };
  });

  const totals = {
    students: rows.length,
    active: rows.filter((r) => r.active).length,
    avgWpm: rows.length ? Math.round((rows.reduce((a, r) => a + r.avgWpm, 0) / rows.length) * 10) / 10 : 0,
    avgAccuracy: rows.length ? Math.round((rows.reduce((a, r) => a + r.avgAccuracy, 0) / rows.length) * 10) / 10 : 0,
    lessonsMastered: rows.reduce((a, r) => a + r.mastered, 0),
    practiceMs: rows.reduce((a, r) => a + r.practiceMs, 0),
    needingSupport: rows.filter((r) => r.avgAccuracy > 0 && r.avgAccuracy < 90 || r.overdue > 0).length,
  };

  return { class: { id: cls.id, name: cls.name, code: cls.code, description: cls.description, instructorName: cls.instructor_name }, students: rows, totals };
}
