import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { attachUser } from './auth.js';
import { loadConfig } from './config.js';
import { authRoutes } from './routes/auth.js';
import { meRoutes } from './routes/me.js';
import { curriculumRoutes } from './routes/curriculum.js';
import { practiceRoutes } from './routes/practice.js';
import { sessionRoutes } from './routes/sessions.js';
import { gameRoutes } from './routes/games.js';
import { challengeRoutes, leaderboardRoutes } from './routes/challenges.js';
import { instructorRoutes } from './routes/instructor.js';
import { adminRoutes } from './routes/admin.js';
import { certificateRoutes, publicRoutes } from './routes/certificates.js';
import { syncLessons } from './seed-data.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, '..', 'public');
const sharedDir = path.join(__dirname, '..', 'shared');

export function createApp({ db, config = loadConfig() }) {
  syncLessons(db);
  const app = express();
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', 1);

  app.use((req, res, next) => {
    // No inline scripts, no eval, no third-party origins. Frames are allowed
    // because the app is designed to run inside a lab/portal preview frame.
    res.setHeader('Content-Security-Policy', [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data:",
      "font-src 'self'",
      "connect-src 'self'",
      "object-src 'none'",
      "base-uri 'none'",
      "form-action 'self'",
      "frame-ancestors *",
    ].join('; '));
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    next();
  });

  app.use(express.json({ limit: config.maxBodyBytes }));
  app.use(attachUser(db, config));

  // An account created with a one-time password can sign in and change its
  // password, and nothing else. Enforced here rather than by hiding screens.
  const PASSWORD_CHANGE_ALLOWLIST = new Set(['/api/auth/me', '/api/auth/password', '/api/auth/logout']);
  app.use((req, res, next) => {
    if (req.user?.mustChangePw && req.path.startsWith('/api') && !PASSWORD_CHANGE_ALLOWLIST.has(req.path)) {
      return res.status(403).json({
        error: 'password_change_required',
        message: 'Set a new password before using BICA Typing Studio.',
      });
    }
    return next();
  });

  // ---- API ---------------------------------------------------------------
  app.use('/api/auth', authRoutes(db, config));
  app.use('/api/me', meRoutes(db));
  app.use('/api/curriculum', curriculumRoutes(db));
  app.use('/api/practice', practiceRoutes(db));
  app.use('/api/sessions', sessionRoutes(db, config));
  app.use('/api/games', gameRoutes(db, config));
  app.use('/api/challenges', challengeRoutes(db));
  app.use('/api/leaderboard', leaderboardRoutes(db));
  app.use('/api/instructor', instructorRoutes(db));
  app.use('/api/admin', adminRoutes(db, config));
  app.use('/api/certificates', certificateRoutes(db, config));
  app.use('/api/public', publicRoutes(db));

  app.use('/api', (req, res) => res.status(404).json({ error: 'not_found', message: 'Unknown API endpoint.' }));

  // ---- static assets -----------------------------------------------------
  app.use('/shared', express.static(sharedDir, {
    setHeaders: (res) => res.setHeader('Cache-Control', 'public, max-age=300'),
  }));
  app.use(express.static(publicDir, {
    index: 'index.html',
    setHeaders: (res, filePath) => {
      if (filePath.endsWith('index.html') || filePath.endsWith('sw.js')) {
        res.setHeader('Cache-Control', 'no-cache');
      } else {
        res.setHeader('Cache-Control', 'public, max-age=600');
      }
    },
  }));

  // SPA fallback (anything that is not an API call or a real file).
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    if (path.extname(req.path)) return next();
    return res.sendFile(path.join(publicDir, 'index.html'));
  });

  app.use((req, res) => res.status(404).send('Not found'));

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err?.type === 'entity.too.large') {
      return res.status(413).json({ error: 'too_large', message: 'Request body is too large.' });
    }
    if (err instanceof SyntaxError && 'body' in err) {
      return res.status(400).json({ error: 'bad_json', message: 'Request body is not valid JSON.' });
    }
    console.error('[bica] unhandled error:', err);
    return res.status(500).json({ error: 'internal_error', message: 'Something went wrong on the server.' });
  });

  return app;
}
