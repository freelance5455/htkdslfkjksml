/** Reconciles the curriculum (code) with the lessons table (data). */
import { LESSONS, CURRICULUM_VERSION } from '../shared/curriculum.js';
import { seedAchievements } from './services/achievements.js';
import { getSettings, setSetting, DEFAULTS } from './settings.js';

export function syncLessons(db) {
  const upsert = db.prepare(`
    INSERT INTO lessons (id, level, order_index, title, objective, target_keys, min_accuracy, min_wpm, est_minutes, curriculum_version)
    VALUES (@id, @level, @orderIndex, @title, @objective, @targetKeys, @minAccuracy, @minWpm, @estMinutes, @curriculumVersion)
    ON CONFLICT(id) DO UPDATE SET
      level = excluded.level, order_index = excluded.order_index, title = excluded.title,
      objective = excluded.objective, target_keys = excluded.target_keys,
      min_accuracy = excluded.min_accuracy, min_wpm = excluded.min_wpm,
      est_minutes = excluded.est_minutes, curriculum_version = excluded.curriculum_version
  `);
  const tx = db.transaction(() => {
    for (const lesson of LESSONS) {
      upsert.run({ ...lesson, targetKeys: lesson.keys.join(' ') });
    }
    // Remove lessons that no longer exist in code, unless a student has progress
    // on them (in which case foreign keys would block the delete anyway).
    const ids = LESSONS.map((l) => l.id);
    const placeholders = ids.map(() => '?').join(',');
    db.prepare(`DELETE FROM lessons WHERE id NOT IN (${placeholders})
      AND id NOT IN (SELECT lesson_id FROM lesson_progress)`).run(...ids);
  });
  tx();
  return LESSONS.length;
}

export function ensureDefaults(db) {
  seedAchievements(db);
  const existing = db.prepare('SELECT key FROM app_settings').all().map((r) => r.key);
  for (const [key, value] of Object.entries(DEFAULTS)) {
    if (!existing.includes(key)) setSetting(db, key, value, null);
  }
  return getSettings(db);
}

export { CURRICULUM_VERSION };
