import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function readOrCreateSecret(file) {
  try {
    const existing = fs.readFileSync(file, 'utf8').trim();
    if (existing.length >= 32) return existing;
  } catch { /* not created yet */ }
  const secret = crypto.randomBytes(48).toString('hex');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, secret, { mode: 0o600 });
  return secret;
}

export function loadConfig(overrides = {}) {
  const dbPath = overrides.dbPath
    ?? process.env.BICA_DB
    ?? path.join(__dirname, '..', 'data', 'bica.db');

  const secretFile = process.env.BICA_SECRET_FILE
    || path.join(path.dirname(dbPath), '.app_secret');

  return {
    env: process.env.NODE_ENV || 'development',
    port: Number(overrides.port ?? process.env.PORT ?? 8080),
    host: overrides.host ?? process.env.HOST ?? '0.0.0.0',
    dbPath,
    secret: overrides.secret ?? process.env.BICA_SECRET ?? readOrCreateSecret(secretFile),
    sessionTtlHours: Number(process.env.BICA_SESSION_HOURS ?? 12),
    cookieSecure: process.env.BICA_COOKIE_SECURE === '1',
    cookieName: 'bica_sid',
    trustProxy: process.env.BICA_TRUST_PROXY === '1',
    orgName: process.env.BICA_ORG || 'BICA Computer Training Centre',
    // A submission may not arrive faster than this fraction of its nominal
    // duration. Guards against timer manipulation and instant replays.
    minDurationRatio: 0.9,
    durationGraceMs: 1500,
    maxBodyBytes: 512 * 1024,
    ...overrides,
  };
}
