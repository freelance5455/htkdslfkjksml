import express from 'express';
import { requireAuth } from '../auth.js';
import { startSession } from '../services/sessions.js';
import { PRESETS, generatePractice, presetById } from '../../shared/practice.js';
import { rankWeakKeys } from '../../shared/adaptive.js';
import { handle, body, num, oneOf, str, bool } from '../lib/validate.js';

const DURATIONS = [15, 30, 60, 120, 180, 300, 600];

export function practiceRoutes(db) {
  const r = express.Router();

  r.get('/presets', requireAuth, (req, res) => res.json({
    presets: PRESETS,
    durations: DURATIONS,
    defaults: { durationSec: 60, allowBackspace: true, showTimer: true, showLiveWpm: true },
  }));

  /**
   * Generates the text AND issues the attempt token in one call, so the target
   * text the student types is the one the server generated.
   */
  r.post('/generate', requireAuth, (req, res) => {
    try {
      const b = body(req);
      const preset = oneOf(b.preset, PRESETS.map((p) => p.id), { name: 'Preset', fallback: 'random-words' });
      const meta = presetById(preset);
      const timed = b.wordCount == null;

      let durationSec = num(b.durationSec, { name: 'Duration', min: 10, max: 1800, integer: true, fallback: 60 });
      let wordCount = null;
      if (!timed) {
        wordCount = num(b.wordCount, { name: 'Word count', min: 5, max: 500, integer: true, fallback: 25 });
        durationSec = Math.max(30, Math.round(wordCount * 1.6));
      }

      const weak = rankWeakKeys(db.prepare('SELECT * FROM key_statistics WHERE student_id = ?').all(req.user.id)).map((k) => k.key);
      const generated = generatePractice({
        preset,
        durationSec: timed ? durationSec : Math.max(45, durationSec),
        seed: b.seed ? String(b.seed).slice(0, 60) : null,
        keys: weak.slice(0, 3),
        customText: b.customText ? str(b.customText, { name: 'Custom text', min: 40, max: 5000, trim: false }) : null,
        language: b.language,
      });

      // Word-count mode trims to the requested number of words.
      let text = generated.text;
      if (!timed && wordCount) {
        text = text.split(/\s+/).slice(0, wordCount).join(' ');
      }

      const expectedMs = timed ? durationSec * 1000 : 0;
      const { tokenId, startedAt } = startSession(db, {
        userId: req.user.id,
        source: 'practice',
        refId: preset,
        expectedMs,
        targetChars: text.length,
      });

      return res.json({
        tokenId,
        startedAt,
        text,
        preset,
        presetLabel: meta?.label ?? preset,
        mode: timed ? 'time' : 'text',
        durationSec: timed ? durationSec : null,
        wordCount: timed ? null : wordCount,
        expectedMs,
        allowBackspace: bool(b.allowBackspace, true),
        meta: generated.meta,
      });
    } catch (err) { return handle(res, err); }
  });

  /** Free typing analysis: metrics for text the student pasted elsewhere. */
  r.post('/analyse', requireAuth, (req, res) => {
    try {
      const b = body(req);
      const text = str(b.text, { name: 'Text', min: 20, max: 20000, trim: false });
      const typed = str(b.typed, { name: 'Typed text', min: 1, max: 20000, trim: false });
      const seconds = num(b.seconds, { name: 'Seconds', min: 5, max: 7200, fallback: 60 });
      const t = text.normalize('NFC');
      const y = typed.normalize('NFC');
      let correct = 0;
      let firstError = -1;
      for (let i = 0; i < Math.min(t.length, y.length); i += 1) {
        if (t[i] === y[i]) correct += 1;
        else if (firstError < 0) firstError = i;
      }
      const committed = y.length;
      const accuracy = committed ? (correct / committed) * 100 : 0;
      const gross = (committed / 5) / (seconds / 60);
      const net = Math.max(0, gross - ((committed - correct) / (seconds / 60)));
      return res.json({
        result: {
          committedChars: committed,
          correctChars: correct,
          accuracy: Math.round(accuracy * 10) / 10,
          grossWpm: Math.round(gross * 10) / 10,
          netWpm: Math.round(net * 10) / 10,
          firstErrorAt: firstError,
          formula: 'netWpm = max(0, (chars/5)/minutes − errors/minute)',
        },
      });
    } catch (err) { return handle(res, err); }
  });

  return r;
}
