import express from 'express';
import { requireAuth, audit } from '../auth.js';
import { studentContext } from './me.js';
import { startSession } from '../services/sessions.js';
import { getLesson, LEVELS, TOTAL_LESSONS } from '../../shared/curriculum.js';
import { fingerInstructionsFor, keyForChar } from '../../shared/keyboard.js';
import { handle, id, num, body } from '../lib/validate.js';

export function curriculumRoutes(db) {
  const r = express.Router();

  r.get('/', requireAuth, (req, res) => {
    try {
      const { curriculum, settings } = studentContext(db, req.user.id);
      return res.json({
        curriculumVersion: curriculum.lessons[0]?.curriculumVersion ?? null,
        totalLessons: TOTAL_LESSONS,
        masteredCount: curriculum.masteredCount,
        unlockedCount: curriculum.unlockedCount,
        currentLessonId: curriculum.currentLesson?.id ?? null,
        sequential: settings['curriculum.requireSequentialUnlock'] !== false,
        levels: LEVELS.map((meta) => ({
          ...meta,
          lessons: curriculum.lessons.filter((l) => l.level === meta.level),
        })),
      });
    } catch (err) { return handle(res, err); }
  });

  r.get('/lessons/:lessonId', requireAuth, (req, res) => {
    try {
      const lesson = getLesson(String(req.params.lessonId));
      if (!lesson) return res.status(404).json({ error: 'not_found', message: 'Lesson not found.' });
      const { curriculum } = studentContext(db, req.user.id);
      const progress = curriculum.lessons.find((l) => l.id === lesson.id);
      if (progress && !progress.unlocked && req.user.role === 'STUDENT') {
        return res.status(403).json({
          error: 'locked',
          message: 'This lesson unlocks when the previous lesson is mastered.',
        });
      }
      return res.json({
        lesson,
        progress,
        fingerGuide: fingerInstructionsFor(lesson.keys),
        keyDetails: lesson.keys.slice(0, 40).map((k) => ({ key: k, ...keyForChar(k) })),
      });
    } catch (err) { return handle(res, err); }
  });

  /** Issues a server-issued token for one drill of a lesson. */
  r.post('/lessons/:lessonId/start', requireAuth, (req, res) => {
    try {
      const lesson = getLesson(String(req.params.lessonId));
      if (!lesson) return res.status(404).json({ error: 'not_found', message: 'Lesson not found.' });
      const b = body(req);
      const drillIndex = num(b.drillIndex, { name: 'Drill', min: 0, max: lesson.drills.length - 1, integer: true, fallback: 0 });

      const { curriculum } = studentContext(db, req.user.id);
      const progress = curriculum.lessons.find((l) => l.id === lesson.id);
      if (progress && !progress.unlocked && req.user.role === 'STUDENT') {
        return res.status(403).json({ error: 'locked', message: 'This lesson is not unlocked yet.' });
      }

      const { tokenId, startedAt } = startSession(db, {
        userId: req.user.id,
        source: 'lesson',
        refId: lesson.id,
        expectedMs: 0,
        targetChars: lesson.drills[drillIndex].length,
      });
      audit(db, req.user.id, 'lesson.start', lesson.id, { drillIndex });
      return res.json({
        tokenId,
        startedAt,
        text: lesson.drills[drillIndex],
        drillIndex,
        drillCount: lesson.drills.length,
        lesson: {
          id: lesson.id, title: lesson.title, level: lesson.level, levelName: lesson.levelName,
          objective: lesson.objective, explanation: lesson.explanation, keys: lesson.keys,
          isExam: lesson.isExam, durationMs: lesson.durationMs,
        },
        thresholds: progress?.thresholds ?? { minAccuracy: lesson.minAccuracy, minWpm: lesson.minWpm },
        fingerGuide: fingerInstructionsFor(lesson.keys),
        best: { accuracy: progress?.bestAccuracy ?? 0, wpm: progress?.bestWpm ?? 0, mastered: Boolean(progress?.mastered) },
      });
    } catch (err) { return handle(res, err); }
  });

  r.get('/levels/:level', requireAuth, (req, res) => {
    try {
      const level = id(req.params.level, { name: 'Level' });
      if (level > 6) return res.status(400).json({ error: 'validation_failed', message: 'Level must be 0 to 6.' });
      const { curriculum } = studentContext(db, req.user.id);
      const lessons = curriculum.lessons.filter((l) => l.level === level);
      if (!lessons.length) return res.status(404).json({ error: 'not_found', message: 'No lessons at that level.' });
      return res.json({ level, meta: LEVELS[level], lessons });
    } catch (err) { return handle(res, err); }
  });

  return r;
}
