import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { requireRole, hashPassword, audit, safeJson } from '../auth.js';
import { getSettings, setSetting, DEFAULTS } from '../settings.js';
import { GAME_IDS } from '../../shared/scoring.js';
import { LEVELS } from '../../shared/curriculum.js';
import { csvResponse } from '../lib/csv.js';
import { createBackup, listBackups, backupDir } from '../backup.js';
import { handle, body, str, num, id, bool, oneOf, cleanText, ValidationError } from '../lib/validate.js';

export function adminRoutes(db, config) {
  const r = express.Router();
  r.use(requireRole('ADMIN'));

  r.get('/dashboard', (req, res) => {
    try {
      const counts = db.prepare(`
        SELECT
          (SELECT COUNT(*) FROM users WHERE role='STUDENT' AND is_active=1) AS students,
          (SELECT COUNT(*) FROM users WHERE role='INSTRUCTOR' AND is_active=1) AS instructors,
          (SELECT COUNT(*) FROM classes WHERE is_active=1) AS classes,
          (SELECT COUNT(*) FROM typing_sessions) AS sessions,
          (SELECT COUNT(*) FROM game_sessions) AS game_rounds,
          (SELECT COUNT(*) FROM certificates WHERE revoked_at IS NULL) AS certificates,
          (SELECT COALESCE(SUM(duration_ms),0) FROM typing_sessions) AS total_ms,
          (SELECT COALESCE(AVG(net_wpm),0) FROM typing_sessions WHERE verified=1 AND started_at >= datetime('now','-30 days')) AS avg_wpm,
          (SELECT COALESCE(AVG(accuracy),0) FROM typing_sessions WHERE verified=1 AND started_at >= datetime('now','-30 days')) AS avg_accuracy
      `).get();

      const daily = db.prepare(`
        SELECT date(started_at) AS day, COUNT(*) AS sessions, ROUND(AVG(net_wpm),1) AS avg_wpm,
               COUNT(DISTINCT student_id) AS students
        FROM typing_sessions WHERE started_at >= datetime('now','-30 days')
        GROUP BY day ORDER BY day ASC
      `).all();

      const levelDistribution = db.prepare(`
        SELECT l.level, COUNT(lp.id) AS mastered
        FROM lessons l LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.mastered_at IS NOT NULL
        GROUP BY l.level ORDER BY l.level
      `).all();

      const topClasses = db.prepare(`
        SELECT c.name, c.code, COUNT(DISTINCT e.student_id) AS students,
               ROUND(AVG(s.net_wpm),1) AS avg_wpm, ROUND(AVG(s.accuracy),1) AS avg_accuracy
        FROM classes c
        LEFT JOIN enrollments e ON e.class_id = c.id
        LEFT JOIN typing_sessions s ON s.student_id = e.student_id
        GROUP BY c.id ORDER BY avg_wpm DESC LIMIT 6
      `).all();

      const syncStatus = db.prepare(`
        SELECT status, COUNT(*) AS c FROM sync_records GROUP BY status
      `).all();

      return res.json({
        counts: {
          students: counts.students,
          instructors: counts.instructors,
          classes: counts.classes,
          sessions: counts.sessions,
          gameRounds: counts.game_rounds,
          certificates: counts.certificates,
          practiceHours: Math.round((counts.total_ms / 3600000) * 10) / 10,
          averageWpm30d: Math.round(counts.avg_wpm * 10) / 10,
          averageAccuracy30d: Math.round(counts.avg_accuracy * 10) / 10,
        },
        daily,
        levelDistribution: LEVELS.map((l) => ({
          level: l.level, name: l.name,
          mastered: levelDistribution.find((d) => d.level === l.level)?.mastered ?? 0,
        })),
        topClasses,
        syncStatus,
        demoDataPresent: db.prepare("SELECT COUNT(*) AS c FROM users WHERE is_demo = 1").get().c > 0,
      });
    } catch (err) { return handle(res, err); }
  });

  // ------------------------------------------------------------------ users
  r.get('/users', (req, res) => {
    try {
      const role = req.query.role ? oneOf(req.query.role, ['ADMIN', 'INSTRUCTOR', 'STUDENT'], { name: 'Role' }) : null;
      const q = req.query.q ? String(req.query.q).slice(0, 60) : null;
      let sql = `SELECT id, username, role, display_name, email, phone, is_active, is_demo, must_change_pw,
                        created_at, last_login_at FROM users WHERE 1=1`;
      const params = [];
      if (role) { sql += ' AND role = ?'; params.push(role); }
      if (q) { sql += ' AND (display_name LIKE ? OR username LIKE ?)'; params.push(`%${q}%`, `%${q}%`); }
      sql += ' ORDER BY role, display_name LIMIT 500';
      return res.json({ users: db.prepare(sql).all(...params) });
    } catch (err) { return handle(res, err); }
  });

  r.post('/users', (req, res) => {
    try {
      const b = body(req);
      const username = str(b.username, { name: 'Username', min: 3, max: 40 }).toLowerCase();
      if (!/^[a-z0-9._-]+$/.test(username)) throw new ValidationError('Username may contain letters, digits, dot, dash and underscore only.', 'username');
      const role = oneOf(b.role, ['ADMIN', 'INSTRUCTOR', 'STUDENT'], { name: 'Role' });
      const displayName = cleanText(b.displayName, { name: 'Full name', min: 1, max: 80 });
      const password = str(b.password, { name: 'Password', min: 10, max: 200, trim: false });
      const email = b.email ? str(b.email, { name: 'Email', max: 120, required: false }) : null;
      const phone = b.phone ? str(b.phone, { name: 'Phone', max: 30, required: false }) : null;
      const info = db.prepare(`
        INSERT INTO users (username, password_hash, role, display_name, email, phone, must_change_pw)
        VALUES (?,?,?,?,?,?,1)
      `).run(username, hashPassword(password), role, displayName, email, phone);
      audit(db, req.user.id, 'admin.user_create', `user:${info.lastInsertRowid}`, { username, role });
      return res.status(201).json({ user: db.prepare('SELECT id, username, role, display_name, is_active FROM users WHERE id = ?').get(info.lastInsertRowid) });
    } catch (err) { return handle(res, err); }
  });

  r.patch('/users/:userId', (req, res) => {
    try {
      const userId = id(req.params.userId, { name: 'User' });
      const target = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
      if (!target) return res.status(404).json({ error: 'not_found' });
      const b = body(req);

      // An administrator must not be able to lock the last active admin out.
      if ((b.isActive === false || b.role) && target.role === 'ADMIN') {
        const activeAdmins = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role='ADMIN' AND is_active=1").get().c;
        if (activeAdmins <= 1) {
          return res.status(422).json({ error: 'last_admin', message: 'The last active administrator cannot be deactivated or demoted.' });
        }
      }

      const displayName = b.displayName ? cleanText(b.displayName, { name: 'Full name', min: 1, max: 80 }) : null;
      const role = b.role ? oneOf(b.role, ['ADMIN', 'INSTRUCTOR', 'STUDENT'], { name: 'Role' }) : null;
      const isActive = b.isActive != null ? (bool(b.isActive) ? 1 : 0) : null;
      const email = b.email != null ? str(b.email, { name: 'Email', max: 120, required: false }) : null;
      const phone = b.phone != null ? str(b.phone, { name: 'Phone', max: 30, required: false }) : null;

      db.prepare(`UPDATE users SET display_name = COALESCE(?, display_name), role = COALESCE(?, role),
                  is_active = COALESCE(?, is_active), email = COALESCE(?, email), phone = COALESCE(?, phone)
                  WHERE id = ?`).run(displayName, role, isActive, email, phone, userId);
      if (isActive === 0) db.prepare("UPDATE auth_sessions SET revoked_at = datetime('now') WHERE user_id = ?").run(userId);
      audit(db, req.user.id, 'admin.user_update', `user:${userId}`, { role, isActive });
      return res.json({ user: db.prepare('SELECT id, username, role, display_name, is_active FROM users WHERE id = ?').get(userId) });
    } catch (err) { return handle(res, err); }
  });

  r.post('/users/:userId/reset-password', (req, res) => {
    try {
      const userId = id(req.params.userId, { name: 'User' });
      const password = str(body(req).password, { name: 'New password', min: 10, max: 200, trim: false });
      const info = db.prepare('UPDATE users SET password_hash = ?, must_change_pw = 1 WHERE id = ?')
        .run(hashPassword(password), userId);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found' });
      db.prepare("UPDATE auth_sessions SET revoked_at = datetime('now') WHERE user_id = ?").run(userId);
      audit(db, req.user.id, 'admin.password_reset', `user:${userId}`);
      return res.json({ ok: true });
    } catch (err) { return handle(res, err); }
  });

  r.delete('/demo-data', (req, res) => {
    try {
      const demo = db.prepare('SELECT id, username FROM users WHERE is_demo = 1').all();
      const tx = db.transaction(() => {
        for (const u of demo) db.prepare('DELETE FROM users WHERE id = ?').run(u.id);
      });
      tx();
      audit(db, req.user.id, 'admin.demo_purge', null, { removed: demo.length });
      return res.json({ removed: demo.length });
    } catch (err) { return handle(res, err); }
  });

  // --------------------------------------------------------------- settings
  r.get('/settings', (req, res) => {
    try {
      return res.json({
        settings: getSettings(db),
        defaults: DEFAULTS,
        schema: settingsSchema(),
      });
    } catch (err) { return handle(res, err); }
  });

  r.put('/settings', (req, res) => {
    try {
      const b = body(req);
      const patch = b.settings && typeof b.settings === 'object' ? b.settings : b;
      const schema = settingsSchema();
      const applied = {};
      for (const [key, value] of Object.entries(patch)) {
        if (!(key in DEFAULTS)) throw new ValidationError(`Unknown setting: ${key}`, key);
        const rule = schema[key];
        let clean = value;
        if (rule?.type === 'number') {
          if (value === null && rule.nullable) clean = null;
          else clean = num(value, { name: key, min: rule.min, max: rule.max, integer: rule.integer });
        } else if (rule?.type === 'boolean') {
          clean = bool(value);
        } else if (rule?.type === 'string') {
          clean = value === null ? null : str(value, { name: key, max: rule.max ?? 200, required: false });
        } else if (rule?.type === 'array') {
          if (!Array.isArray(value)) throw new ValidationError(`${key} must be a list.`, key);
          clean = value.filter((v) => rule.allowed.includes(v));
        }
        setSetting(db, key, clean, req.user.id);
        applied[key] = clean;
      }
      audit(db, req.user.id, 'admin.settings_update', null, applied);
      return res.json({ settings: getSettings(db), applied });
    } catch (err) { return handle(res, err); }
  });

  r.get('/audit', (req, res) => {
    try {
      const limit = num(req.query.limit, { name: 'Limit', min: 1, max: 500, integer: true, fallback: 100 });
      const rows = db.prepare(`
        SELECT a.id, a.action, a.target, a.detail_json, a.at, u.display_name AS actor, u.role AS actor_role
        FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id
        ORDER BY a.at DESC LIMIT ?
      `).all(limit);
      return res.json({ entries: rows.map((x) => ({ ...x, detail: safeJson(x.detail_json) })) });
    } catch (err) { return handle(res, err); }
  });

  // ---------------------------------------------------------------- backups
  r.get('/backups', (req, res) => {
    try {
      return res.json({ backups: listBackups(config), directory: backupDir(config) });
    } catch (err) { return handle(res, err); }
  });

  r.post('/backups', async (req, res) => {
    try {
      const result = await createBackup(db, config);
      audit(db, req.user.id, 'admin.backup', result.file, { bytes: result.bytes });
      return res.status(201).json(result);
    } catch (err) { return handle(res, err); }
  });

  r.get('/backups/:file', (req, res) => {
    try {
      const name = path.basename(String(req.params.file));
      if (!/^bica-[\w.-]+\.db$/.test(name)) return res.status(400).json({ error: 'invalid_file' });
      const full = path.join(backupDir(config), name);
      if (!fs.existsSync(full)) return res.status(404).json({ error: 'not_found' });
      audit(db, req.user.id, 'admin.backup_download', name);
      res.setHeader('Content-Type', 'application/x-sqlite3');
      res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
      return fs.createReadStream(full).pipe(res);
    } catch (err) { return handle(res, err); }
  });

  r.get('/sync-status', (req, res) => {
    try {
      const rows = db.prepare(`
        SELECT s.status, s.kind, COUNT(*) AS count, MAX(s.created_at) AS latest
        FROM sync_records s GROUP BY s.status, s.kind
      `).all();
      const failed = db.prepare(`
        SELECT s.*, u.display_name FROM sync_records s JOIN users u ON u.id = s.student_id
        WHERE s.status = 'FAILED' ORDER BY s.created_at DESC LIMIT 25
      `).all();
      return res.json({ summary: rows, failed, queueEnabled: getSettings(db)['features.offlineQueue'] !== false });
    } catch (err) { return handle(res, err); }
  });

  r.get('/export/users.csv', (req, res) => {
    try {
      const users = db.prepare(`
        SELECT u.id, u.username, u.display_name, u.role, u.email, u.phone, u.is_active, u.created_at, u.last_login_at,
               (SELECT COUNT(*) FROM lesson_progress lp WHERE lp.student_id = u.id AND lp.mastered_at IS NOT NULL) AS mastered
        FROM users u ORDER BY u.role, u.display_name
      `).all();
      audit(db, req.user.id, 'admin.export_users');
      return csvResponse(res, `bica-users-${new Date().toISOString().slice(0, 10)}.csv`, [
        { key: 'id', label: 'ID' },
        { key: 'username', label: 'Username' },
        { key: 'display_name', label: 'Full name' },
        { key: 'role', label: 'Role' },
        { key: 'email', label: 'Email' },
        { key: 'phone', label: 'Phone' },
        { key: 'is_active', label: 'Active' },
        { key: 'mastered', label: 'Lessons mastered' },
        { key: 'created_at', label: 'Created' },
        { key: 'last_login_at', label: 'Last login' },
      ], users);
    } catch (err) { return handle(res, err); }
  });

  return r;
}

function settingsSchema() {
  return {
    'org.name': { type: 'string', max: 120 },
    'org.address': { type: 'string', max: 240 },
    'org.certificateSignatory': { type: 'string', max: 120 },
    'curriculum.minAccuracy': { type: 'number', min: 50, max: 100, nullable: true },
    'curriculum.minWpm': { type: 'number', min: 0, max: 200, nullable: true },
    'curriculum.minChars': { type: 'number', min: 0, max: 3000, integer: true },
    'curriculum.requireSequentialUnlock': { type: 'boolean' },
    'features.competitive': { type: 'boolean' },
    'features.leaderboards': { type: 'boolean' },
    'features.publicNames': { type: 'boolean' },
    'features.arcade': { type: 'boolean' },
    'features.offlineQueue': { type: 'boolean' },
    'games.enabled': { type: 'array', allowed: GAME_IDS },
    'exams.allowBackspace': { type: 'boolean' },
    'exams.passAccuracy': { type: 'number', min: 0, max: 100 },
    'exams.passWpm': { type: 'number', min: 0, max: 200 },
    'cert.enabled': { type: 'boolean' },
    'cert.minLevel': { type: 'number', min: 0, max: 6, integer: true },
    'cert.minLessons': { type: 'number', min: 0, max: 60, integer: true },
    'cert.minWpm': { type: 'number', min: 0, max: 200 },
    'cert.minAccuracy': { type: 'number', min: 0, max: 100 },
    'cert.courseTitle': { type: 'string', max: 160 },
    'student.dailyTargetMinutes': { type: 'number', min: 1, max: 480, integer: true },
    'ui.theme': { type: 'string', max: 20 },
    'ui.defaultLanguage': { type: 'string', max: 5 },
  };
}
