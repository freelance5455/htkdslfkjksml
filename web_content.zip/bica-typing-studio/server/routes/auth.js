import express from 'express';
import crypto from 'node:crypto';
import {
  hashPassword, verifyPassword, newSessionId, sessionCookie, RateLimiter,
  requireAuth, audit, safeJson, MIN_PASSWORD_LENGTH,
} from '../auth.js';
import { str, body, handle, ValidationError } from '../lib/validate.js';

const LOGIN_WINDOW_MS = 15 * 60 * 1000;

export function authRoutes(db, config) {
  const r = express.Router();
  // Only failed attempts accumulate: a whole lab signing in successfully from
  // one gateway must not lock itself out, while a password-guessing loop still
  // runs into the ceiling within a few attempts.
  const ipLimiter = new RateLimiter({ windowMs: LOGIN_WINDOW_MS, max: config.loginMaxPerIp ?? 20 });
  const userLimiter = new RateLimiter({ windowMs: LOGIN_WINDOW_MS, max: config.loginMaxPerUser ?? 8 });

  r.post('/login', (req, res) => {
    try {
      const b = body(req);
      const username = str(b.username, { name: 'Username', min: 3, max: 40 }).toLowerCase();
      const password = str(b.password, { name: 'Password', min: 1, max: 200, trim: false });
      const ip = req.ip || 'unknown';

      const ipCheck = ipLimiter.check(ip);
      const userCheck = userLimiter.check(username);
      if (!ipCheck.allowed || !userCheck.allowed) {
        return res.status(429).json({ error: 'rate_limited', message: 'Too many attempts. Please wait a few minutes and try again.' });
      }

      const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
      // Always spend the same scrypt work, whether or not the account exists, so
      // response time cannot be used to enumerate usernames.
      const dummyHash = 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$'
        + 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==';
      const ok = verifyPassword(password, user?.password_hash ?? dummyHash) && Boolean(user?.is_active);

      db.prepare('INSERT INTO login_attempts (username, ip, succeeded) VALUES (?,?,?)').run(username, ip, ok ? 1 : 0);

      // Constant response shape and message: never reveal whether the account exists.
      if (!ok) {
        return res.status(401).json({ error: 'invalid_credentials', message: 'Username or password is incorrect.' });
      }

      const sid = newSessionId();
      const expiresAt = new Date(Date.now() + config.sessionTtlHours * 3600_000);
      db.prepare(`
        INSERT INTO auth_sessions (id, user_id, expires_at, ip, user_agent)
        VALUES (?,?,?,?,?)
      `).run(sid, user.id, expiresAt.toISOString(), ip, String(req.headers['user-agent'] ?? '').slice(0, 300));
      db.prepare("UPDATE users SET last_login_at = datetime('now') WHERE id = ?").run(user.id);
      userLimiter.reset(username);
      ipLimiter.reset(ip);

      res.setHeader('Set-Cookie', sessionCookie(config, sid, config.sessionTtlHours * 3600));
      audit(db, user.id, 'auth.login', `user:${user.id}`, { ip });
      return res.json({
        user: {
          id: user.id, username: user.username, role: user.role,
          displayName: user.display_name, mustChangePw: Boolean(user.must_change_pw),
          prefs: safeJson(user.prefs_json),
        },
      });
    } catch (err) { return handle(res, err); }
  });

  r.post('/logout', (req, res) => {
    const sid = req.user?.sessionId;
    if (sid) db.prepare("UPDATE auth_sessions SET revoked_at = datetime('now') WHERE id = ?").run(sid);
    res.setHeader('Set-Cookie', `${config.cookieName}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
    return res.json({ ok: true });
  });

  r.get('/me', (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'authentication_required' });
    return res.json({ user: req.user });
  });

  r.post('/password', requireAuth, (req, res) => {
    try {
      const b = body(req);
      const current = str(b.currentPassword, { name: 'Current password', min: 1, max: 200, trim: false });
      const next = str(b.newPassword, { name: 'New password', min: MIN_PASSWORD_LENGTH, max: 200, trim: false });
      const me = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
      if (!verifyPassword(current, me.password_hash)) {
        return res.status(400).json({ error: 'invalid_current_password', message: 'Your current password is incorrect.' });
      }
      if (verifyPassword(next, me.password_hash)) {
        throw new ValidationError('The new password must be different from the current one.', 'newPassword');
      }
      db.prepare('UPDATE users SET password_hash = ?, must_change_pw = 0 WHERE id = ?').run(hashPassword(next), req.user.id);
      // Invalidate every other session for this account.
      db.prepare("UPDATE auth_sessions SET revoked_at = datetime('now') WHERE user_id = ? AND id <> ?")
        .run(req.user.id, req.user.sessionId);
      audit(db, req.user.id, 'auth.password_changed', `user:${req.user.id}`);
      return res.json({ ok: true });
    } catch (err) { return handle(res, err); }
  });

  r.patch('/preferences', requireAuth, (req, res) => {
    try {
      const b = body(req);
      const allowed = ['theme', 'reducedMotion', 'sound', 'language', 'largeText', 'keyboardGuide', 'showLiveWpm'];
      const current = safeJson(db.prepare('SELECT prefs_json FROM users WHERE id = ?').get(req.user.id).prefs_json);
      const next = { ...current };
      for (const key of allowed) {
        if (key in b) next[key] = b[key];
      }
      db.prepare('UPDATE users SET prefs_json = ? WHERE id = ?').run(JSON.stringify(next), req.user.id);
      return res.json({ prefs: next });
    } catch (err) { return handle(res, err); }
  });

  /** Session self-test endpoint used by the offline queue to confirm identity. */
  r.get('/session', requireAuth, (req, res) => res.json({
    ok: true,
    user: { id: req.user.id, role: req.user.role, displayName: req.user.displayName },
    serverTime: new Date().toISOString(),
    nonce: crypto.randomBytes(8).toString('hex'),
  }));

  return r;
}
