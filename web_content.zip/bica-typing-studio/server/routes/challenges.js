import express from 'express';
import { requireAuth } from '../auth.js';
import { getSettings } from '../settings.js';
import { startSession } from '../services/sessions.js';
import { seeded, isoDateKey, isoWeekKey } from '../../shared/rng.js';
import { PARAGRAPHS, BUSINESS_PASSAGES, REPORT_PASSAGES } from '../../shared/textbank.js';
import { handle, str, oneOf, num } from '../lib/validate.js';

function buildPassage(seedKey, pool, targetChars) {
  const rng = seeded(seedKey);
  const shuffled = rng.shuffle(pool);
  let text = '';
  let i = 0;
  while (text.length < targetChars) {
    text += `${shuffled[i % shuffled.length]} `;
    i += 1;
    if (i > 60) break;
  }
  return text.trim();
}

/** Deterministic per-day and per-week challenges, created on first request. */
export function ensureChallenges(db, now = new Date()) {
  const settings = getSettings(db);
  const dayKey = isoDateKey(now);
  const weekKey = isoWeekKey(now);

  const dailyId = `daily-${dayKey}`;
  const weeklyId = `weekly-${weekKey}`;

  const existing = db.prepare('SELECT * FROM challenges WHERE id IN (?, ?)').all(dailyId, weeklyId);
  const have = new Set(existing.map((c) => c.id));
  const insert = db.prepare(`
    INSERT INTO challenges (id, kind, title, passage, duration_ms, starts_at, ends_at)
    VALUES (?,?,?,?,?,?,?)
  `);
  const tx = db.transaction(() => {
    if (!have.has(dailyId)) {
      const pass = buildPassage(`daily-${dayKey}`, PARAGRAPHS, 700);
      insert.run(dailyId, 'DAILY', `Daily challenge — ${dayKey}`, pass, 60000,
        `${dayKey}T00:00:00Z`, `${dayKey}T23:59:59Z`);
    }
    if (!have.has(weeklyId)) {
      const pass = buildPassage(`weekly-${weekKey}`, [...BUSINESS_PASSAGES, ...REPORT_PASSAGES], 1600);
      insert.run(weeklyId, 'WEEKLY', `Weekly challenge — ${weekKey}`, pass, 180000,
        `${dayKey}T00:00:00Z`, `${dayKey}T23:59:59Z`);
    }
  });
  tx();
  void settings;
  return { dailyId, weeklyId };
}

function leaderboardFor(db, challengeId, settings) {
  if (settings['features.leaderboards'] === false) return [];
  const revealNames = settings['features.publicNames'] !== false;
  return db.prepare(`
    SELECT a.net_wpm, a.accuracy, a.created_at,
           CASE WHEN ? = 1 THEN u.display_name ELSE 'BICA-' || printf('%04d', u.id) END AS name,
           CASE WHEN u.id = ? THEN 1 ELSE 0 END AS is_me
    FROM challenge_attempts a JOIN users u ON u.id = a.student_id
    WHERE a.challenge_id = ? AND u.is_active = 1
    ORDER BY a.net_wpm DESC, a.accuracy DESC LIMIT 25
  `).all(revealNames ? 1 : 0, settings.__viewerId ?? -1, challengeId);
}

export function challengeRoutes(db) {
  const r = express.Router();

  r.get('/', requireAuth, (req, res) => {
    try {
      const ids = ensureChallenges(db);
      const settings = { ...getSettings(db), __viewerId: req.user.id };
      const daily = db.prepare('SELECT * FROM challenges WHERE id = ?').get(ids.dailyId);
      const weekly = db.prepare('SELECT * FROM challenges WHERE id = ?').get(ids.weeklyId);
      const attempts = db.prepare('SELECT * FROM challenge_attempts WHERE student_id = ? AND challenge_id IN (?, ?)')
        .all(req.user.id, ids.dailyId, ids.weeklyId);
      const attemptMap = Object.fromEntries(attempts.map((a) => [a.challenge_id, a]));
      const personalBest = db.prepare(`
        SELECT MAX(net_wpm) AS best_wpm, MAX(accuracy) AS best_accuracy, COUNT(*) AS sessions
        FROM typing_sessions WHERE student_id = ? AND verified = 1
      `).get(req.user.id);

      const shape = (row) => row && ({
        id: row.id,
        kind: row.kind,
        title: row.title,
        durationMs: row.duration_ms,
        passageChars: (row.passage || '').length,
        endsAt: row.ends_at,
        myAttempt: attemptMap[row.id]
          ? { netWpm: attemptMap[row.id].net_wpm, accuracy: attemptMap[row.id].accuracy, at: attemptMap[row.id].created_at }
          : null,
        leaderboard: leaderboardFor(db, row.id, settings).slice(0, 10),
      });

      return res.json({
        daily: shape(daily),
        weekly: shape(weekly),
        personalBest: {
          bestWpm: personalBest.best_wpm ?? 0,
          bestAccuracy: personalBest.best_accuracy ?? 0,
          sessions: personalBest.sessions ?? 0,
        },
        competitiveEnabled: settings['features.competitive'] !== false,
        leaderboardsEnabled: settings['features.leaderboards'] !== false,
      });
    } catch (err) { return handle(res, err); }
  });

  r.get('/:challengeId/start', requireAuth, (req, res) => {
    try {
      const challengeId = str(req.params.challengeId, { name: 'Challenge', min: 5, max: 60 });
      const challenge = db.prepare('SELECT * FROM challenges WHERE id = ?').get(challengeId);
      if (!challenge) return res.status(404).json({ error: 'not_found', message: 'Challenge not found.' });
      const settings = getSettings(db);
      if (settings['features.competitive'] === false) {
        return res.status(403).json({ error: 'competitive_disabled', message: 'Challenges are disabled by your centre.' });
      }
      const { tokenId, startedAt } = startSession(db, {
        userId: req.user.id, source: 'challenge', refId: challenge.id,
        expectedMs: challenge.duration_ms, targetChars: challenge.passage.length,
      });
      return res.json({
        tokenId,
        startedAt,
        text: challenge.passage,
        mode: 'time',
        durationSec: Math.round(challenge.duration_ms / 1000),
        expectedMs: challenge.duration_ms,
        title: challenge.title,
        kind: challenge.kind,
      });
    } catch (err) { return handle(res, err); }
  });

  return r;
}

export function leaderboardRoutes(db) {
  const r = express.Router();

  r.get('/', requireAuth, (req, res) => {
    try {
      const settings = getSettings(db);
      if (settings['features.leaderboards'] === false) {
        return res.json({ disabled: true, entries: [], message: 'Leaderboards are disabled by your centre.' });
      }
      const scope = oneOf(req.query.scope, ['global', 'class'], { name: 'Scope', fallback: 'global' });
      const period = oneOf(req.query.period, ['week', 'month', 'all'], { name: 'Period', fallback: 'week' });
      const limit = num(req.query.limit, { name: 'Limit', min: 1, max: 100, integer: true, fallback: 20 });
      const since = period === 'week' ? "datetime('now','-7 days')" : period === 'month' ? "datetime('now','-30 days')" : null;

      const revealNames = settings['features.publicNames'] !== false;
      let classFilter = '';
      const params = [];
      if (scope === 'class') {
        classFilter = `AND s.student_id IN (
          SELECT e.student_id FROM enrollments e
          WHERE e.class_id IN (SELECT class_id FROM enrollments WHERE student_id = ?)
        )`;
        params.push(req.user.id);
      }

      const rows = db.prepare(`
        SELECT
          CASE WHEN ? = 1 THEN u.display_name ELSE 'BICA-' || printf('%04d', u.id) END AS name,
          MAX(s.net_wpm) AS best_wpm,
          ROUND(AVG(s.accuracy),1) AS avg_accuracy,
          COUNT(*) AS sessions,
          MAX(s.accuracy) AS best_accuracy,
          CASE WHEN u.id = ? THEN 1 ELSE 0 END AS is_me
        FROM typing_sessions s JOIN users u ON u.id = s.student_id
        WHERE s.verified = 1 AND u.is_active = 1
          ${since ? `AND s.started_at >= ${since}` : ''}
          ${classFilter}
        GROUP BY s.student_id
        ORDER BY best_wpm DESC, avg_accuracy DESC
        LIMIT ?
      `).all(revealNames ? 1 : 0, req.user.id, ...params, limit);

      return res.json({
        scope, period, entries: rows,
        note: 'Only verified sessions count. Net WPM is the ranking metric; accuracy breaks ties.',
        competitiveEnabled: settings['features.competitive'] !== false,
      });
    } catch (err) { return handle(res, err); }
  });

  return r;
}
