import express from 'express';
import { requireRole, canAccessClass, canAccessStudent, hashPassword, audit } from '../auth.js';
import { getSettings } from '../settings.js';
import { studentReport, classReport, assignmentStatusForStudent } from '../services/reports.js';
import { csvResponse } from '../lib/csv.js';
import { createPdf } from '../lib/pdf.js';
import { getLesson } from '../../shared/curriculum.js';
import { getGame, GAMES } from '../../shared/scoring.js';
import {
  handle, body, str, num, id, oneOf, bool, cleanText, ValidationError,
} from '../lib/validate.js';

const isoNow = () => new Date().toISOString().replace('T', ' ').slice(0, 19);

export function instructorRoutes(db) {
  const r = express.Router();
  r.use(requireRole('INSTRUCTOR', 'ADMIN'));

  // ------------------------------------------------------------- dashboard
  r.get('/dashboard', (req, res) => {
    try {
      const classes = req.user.role === 'ADMIN'
        ? db.prepare('SELECT * FROM classes ORDER BY name').all()
        : db.prepare(`
            SELECT DISTINCT c.* FROM classes c
            LEFT JOIN class_instructors ci ON ci.class_id = c.id
            WHERE c.instructor_id = ? OR ci.instructor_id = ? ORDER BY c.name
          `).all(req.user.id, req.user.id);

      const classIds = classes.map((c) => c.id);
      const placeholders = classIds.length ? classIds.map(() => '?').join(',') : 'NULL';
      const studentCount = classIds.length
        ? db.prepare(`SELECT COUNT(DISTINCT student_id) AS c FROM enrollments WHERE class_id IN (${placeholders})`).get(...classIds).c
        : 0;

      const agg = db.prepare(`
        SELECT COUNT(*) AS sessions, COALESCE(AVG(net_wpm),0) AS avg_wpm, COALESCE(AVG(accuracy),0) AS avg_accuracy,
               COALESCE(SUM(duration_ms),0) AS ms
        FROM typing_sessions
        WHERE verified = 1 AND started_at >= datetime('now','-30 days')
          AND student_id IN (SELECT student_id FROM enrollments WHERE class_id IN (${placeholders}))
      `).get(...(classIds.length ? classIds : [0]));

      const activeWeek = classIds.length
        ? db.prepare(`
            SELECT COUNT(DISTINCT student_id) AS c FROM typing_sessions
            WHERE started_at >= datetime('now','-7 days')
              AND student_id IN (SELECT student_id FROM enrollments WHERE class_id IN (${placeholders}))
          `).get(...classIds).c
        : 0;

      const roster = classIds.length
        ? db.prepare(`
            SELECT u.id, u.display_name, u.username, c.name AS class_name,
                   COALESCE(AVG(s.accuracy),0) AS avg_accuracy, COALESCE(MAX(s.net_wpm),0) AS best_wpm,
                   MAX(s.started_at) AS last_at
            FROM enrollments e
            JOIN users u ON u.id = e.student_id
            JOIN classes c ON c.id = e.class_id
            LEFT JOIN typing_sessions s ON s.student_id = u.id AND s.verified = 1
            WHERE e.class_id IN (${placeholders})
            GROUP BY u.id, e.class_id
          `).all(...classIds)
        : [];

      const needsSupport = roster.filter((s) => (s.avg_accuracy > 0 && s.avg_accuracy < 90)
        || (s.last_at && Date.now() - Date.parse(`${s.last_at.replace(' ', 'T')}Z`) > 7 * 86400000));

      const openAssignments = classIds.length
        ? db.prepare(`
            SELECT COUNT(*) AS c FROM assignments
            WHERE is_active = 1 AND (class_id IN (${placeholders}) OR student_id IN (
              SELECT student_id FROM enrollments WHERE class_id IN (${placeholders})
            ))
          `).get(...classIds, ...classIds).c
        : 0;

      const recent = classIds.length
        ? db.prepare(`
            SELECT s.id, s.source, s.ref_id, s.net_wpm, s.accuracy, s.started_at, u.display_name
            FROM typing_sessions s JOIN users u ON u.id = s.student_id
            WHERE s.student_id IN (SELECT student_id FROM enrollments WHERE class_id IN (${placeholders}))
            ORDER BY s.started_at DESC LIMIT 15
          `).all(...classIds)
        : [];

      return res.json({
        totals: {
          students: studentCount,
          activeThisWeek: activeWeek,
          classes: classes.length,
          completedLessons: classIds.length
            ? db.prepare(`SELECT COUNT(*) AS c FROM lesson_progress
                WHERE mastered_at IS NOT NULL AND student_id IN (
                  SELECT student_id FROM enrollments WHERE class_id IN (${placeholders}))`).get(...classIds).c
            : 0,
          averageWpm: Math.round(agg.avg_wpm * 10) / 10,
          averageAccuracy: Math.round(agg.avg_accuracy * 10) / 10,
          practiceHours: Math.round((agg.ms / 3600000) * 10) / 10,
          sessions30d: agg.sessions,
          openAssignments,
          needingSupport: needsSupport.length,
        },
        classes,
        needsSupport: needsSupport.slice(0, 10),
        recentActivity: recent,
      });
    } catch (err) { return handle(res, err); }
  });

  // ---------------------------------------------------------------- classes
  r.get('/classes', (req, res) => {
    const rows = req.user.role === 'ADMIN'
      ? db.prepare(`
          SELECT c.*, u.display_name AS instructor_name,
                 (SELECT COUNT(*) FROM enrollments e WHERE e.class_id = c.id AND e.status='ACTIVE') AS students
          FROM classes c LEFT JOIN users u ON u.id = c.instructor_id ORDER BY c.name
        `).all()
      : db.prepare(`
          SELECT DISTINCT c.*, u.display_name AS instructor_name,
                 (SELECT COUNT(*) FROM enrollments e WHERE e.class_id = c.id AND e.status='ACTIVE') AS students
          FROM classes c
          LEFT JOIN users u ON u.id = c.instructor_id
          LEFT JOIN class_instructors ci ON ci.class_id = c.id
          WHERE c.instructor_id = ? OR ci.instructor_id = ? ORDER BY c.name
        `).all(req.user.id, req.user.id);
    return res.json({ classes: rows });
  });

  r.post('/classes', (req, res) => {
    try {
      const b = body(req);
      const name = cleanText(b.name, { name: 'Class name', min: 2, max: 80 });
      const code = str(b.code, { name: 'Class code', min: 2, max: 20 }).toUpperCase().replace(/[^A-Z0-9\-_]/g, '');
      if (!code) throw new ValidationError('Class code must contain letters or digits.', 'code');
      const description = b.description ? cleanText(b.description, { name: 'Description', max: 300, required: false }) : null;
      const instructorId = req.user.role === 'ADMIN' && b.instructorId ? id(b.instructorId, { name: 'Instructor' }) : req.user.id;
      const info = db.prepare('INSERT INTO classes (name, code, description, instructor_id) VALUES (?,?,?,?)')
        .run(name, code, description, instructorId);
      audit(db, req.user.id, 'class.create', `class:${info.lastInsertRowid}`, { name, code });
      return res.status(201).json({ class: db.prepare('SELECT * FROM classes WHERE id = ?').get(info.lastInsertRowid) });
    } catch (err) { return handle(res, err); }
  });

  r.get('/classes/:classId', (req, res) => {
    try {
      const classId = id(req.params.classId, { name: 'Class' });
      if (!canAccessClass(db, req.user, classId)) return res.status(403).json({ error: 'forbidden' });
      const report = classReport(db, classId);
      if (!report) return res.status(404).json({ error: 'not_found' });
      return res.json(report);
    } catch (err) { return handle(res, err); }
  });

  r.patch('/classes/:classId', (req, res) => {
    try {
      const classId = id(req.params.classId, { name: 'Class' });
      if (!canAccessClass(db, req.user, classId)) return res.status(403).json({ error: 'forbidden' });
      const b = body(req);
      const name = b.name ? cleanText(b.name, { name: 'Class name', min: 2, max: 80 }) : null;
      const description = b.description != null ? cleanText(b.description, { name: 'Description', max: 300, required: false }) : null;
      const isActive = b.isActive != null ? (bool(b.isActive) ? 1 : 0) : null;
      db.prepare(`
        UPDATE classes SET name = COALESCE(?, name), description = COALESCE(?, description), is_active = COALESCE(?, is_active)
        WHERE id = ?
      `).run(name, description, isActive, classId);
      audit(db, req.user.id, 'class.update', `class:${classId}`);
      return res.json({ class: db.prepare('SELECT * FROM classes WHERE id = ?').get(classId) });
    } catch (err) { return handle(res, err); }
  });

  // ------------------------------------------------------------ enrolments
  r.post('/classes/:classId/students', (req, res) => {
    try {
      const classId = id(req.params.classId, { name: 'Class' });
      if (!canAccessClass(db, req.user, classId)) return res.status(403).json({ error: 'forbidden' });
      const b = body(req);

      let studentId;
      if (b.studentId) {
        studentId = id(b.studentId, { name: 'Student' });
        const student = db.prepare("SELECT id FROM users WHERE id = ? AND role = 'STUDENT'").get(studentId);
        if (!student) throw new ValidationError('That student does not exist.', 'studentId');
      } else {
        const username = str(b.username, { name: 'Username', min: 3, max: 40 }).toLowerCase();
        if (!/^[a-z0-9._-]+$/.test(username)) throw new ValidationError('Username may contain letters, digits, dot, dash and underscore only.', 'username');
        const displayName = cleanText(b.displayName, { name: 'Full name', min: 1, max: 80 });
        const password = str(b.password, { name: 'Temporary password', min: 10, max: 200, trim: false });
        const info = db.prepare(`
          INSERT INTO users (username, password_hash, role, display_name, must_change_pw)
          VALUES (?,?,?,?,1)
        `).run(username, hashPassword(password), 'STUDENT', displayName);
        studentId = info.lastInsertRowid;
        audit(db, req.user.id, 'student.create', `user:${studentId}`, { username });
      }

      db.prepare(`
        INSERT INTO enrollments (student_id, class_id) VALUES (?,?)
        ON CONFLICT(student_id, class_id) DO UPDATE SET status = 'ACTIVE'
      `).run(studentId, classId);
      audit(db, req.user.id, 'class.enrol', `class:${classId}`, { studentId });
      return res.status(201).json({ studentId, enrolled: true });
    } catch (err) { return handle(res, err); }
  });

  r.delete('/classes/:classId/students/:studentId', (req, res) => {
    try {
      const classId = id(req.params.classId, { name: 'Class' });
      const studentId = id(req.params.studentId, { name: 'Student' });
      if (!canAccessClass(db, req.user, classId)) return res.status(403).json({ error: 'forbidden' });
      db.prepare("UPDATE enrollments SET status = 'WITHDRAWN' WHERE class_id = ? AND student_id = ?").run(classId, studentId);
      audit(db, req.user.id, 'class.withdraw', `class:${classId}`, { studentId });
      return res.json({ ok: true });
    } catch (err) { return handle(res, err); }
  });

  // -------------------------------------------------------------- students
  r.get('/students', (req, res) => {
    try {
      const q = req.query.q ? String(req.query.q).slice(0, 60) : null;
      const classId = req.query.classId ? id(req.query.classId, { name: 'Class' }) : null;
      if (classId && !canAccessClass(db, req.user, classId)) return res.status(403).json({ error: 'forbidden' });

      let sql = `
        SELECT DISTINCT u.id, u.username, u.display_name, u.is_active, u.created_at,
               (SELECT COUNT(*) FROM lesson_progress lp WHERE lp.student_id = u.id AND lp.mastered_at IS NOT NULL) AS mastered,
               (SELECT COALESCE(MAX(net_wpm),0) FROM typing_sessions s WHERE s.student_id = u.id) AS best_wpm,
               (SELECT COALESCE(AVG(accuracy),0) FROM typing_sessions s WHERE s.student_id = u.id) AS avg_accuracy,
               (SELECT MAX(started_at) FROM typing_sessions s WHERE s.student_id = u.id) AS last_at
        FROM users u
        WHERE u.role = 'STUDENT'
      `;
      const params = [];
      if (req.user.role !== 'ADMIN') {
        sql += ` AND u.id IN (
          SELECT e.student_id FROM enrollments e JOIN classes c ON c.id = e.class_id
          LEFT JOIN class_instructors ci ON ci.class_id = c.id
          WHERE c.instructor_id = ? OR ci.instructor_id = ?
        )`;
        params.push(req.user.id, req.user.id);
      }
      if (classId) {
        sql += ' AND u.id IN (SELECT student_id FROM enrollments WHERE class_id = ? AND status = \'ACTIVE\')';
        params.push(classId);
      }
      if (q) {
        sql += ' AND (u.display_name LIKE ? OR u.username LIKE ?)';
        params.push(`%${q}%`, `%${q}%`);
      }
      sql += ' ORDER BY u.display_name LIMIT 500';
      const students = db.prepare(sql).all(...params);
      return res.json({ students });
    } catch (err) { return handle(res, err); }
  });

  r.get('/students/:studentId', (req, res) => {
    try {
      const studentId = id(req.params.studentId, { name: 'Student' });
      if (!canAccessStudent(db, req.user, studentId)) return res.status(403).json({ error: 'forbidden' });
      const report = studentReport(db, studentId);
      if (!report) return res.status(404).json({ error: 'not_found', message: 'Student not found.' });
      return res.json(report);
    } catch (err) { return handle(res, err); }
  });

  r.post('/students/:studentId/notes', (req, res) => {
    try {
      const studentId = id(req.params.studentId, { name: 'Student' });
      if (!canAccessStudent(db, req.user, studentId)) return res.status(403).json({ error: 'forbidden' });
      const note = cleanText(body(req).note, { name: 'Note', min: 2, max: 2000 });
      const info = db.prepare('INSERT INTO instructor_notes (instructor_id, student_id, note) VALUES (?,?,?)')
        .run(req.user.id, studentId, note);
      audit(db, req.user.id, 'note.create', `user:${studentId}`);
      return res.status(201).json({ note: db.prepare('SELECT * FROM instructor_notes WHERE id = ?').get(info.lastInsertRowid) });
    } catch (err) { return handle(res, err); }
  });

  r.post('/students/:studentId/reset-password', (req, res) => {
    try {
      const studentId = id(req.params.studentId, { name: 'Student' });
      if (!canAccessStudent(db, req.user, studentId)) return res.status(403).json({ error: 'forbidden' });
      const password = str(body(req).password, { name: 'New password', min: 10, max: 200, trim: false });
      db.prepare('UPDATE users SET password_hash = ?, must_change_pw = 1 WHERE id = ? AND role = ?')
        .run(hashPassword(password), studentId, 'STUDENT');
      db.prepare("UPDATE auth_sessions SET revoked_at = datetime('now') WHERE user_id = ?").run(studentId);
      audit(db, req.user.id, 'student.reset_password', `user:${studentId}`);
      return res.json({ ok: true });
    } catch (err) { return handle(res, err); }
  });

  // ----------------------------------------------------------- assignments
  r.get('/assignments', (req, res) => {
    try {
      const rows = db.prepare(`
        SELECT a.*, c.name AS class_name, u.display_name AS student_name
        FROM assignments a
        LEFT JOIN classes c ON c.id = a.class_id
        LEFT JOIN users u ON u.id = a.student_id
        WHERE a.is_active = 1 AND (
          a.instructor_id = ? OR ? = 'ADMIN'
          OR a.class_id IN (SELECT id FROM classes WHERE instructor_id = ?)
        )
        ORDER BY a.created_at DESC LIMIT 200
      `).all(req.user.id, req.user.role, req.user.id);
      return res.json({
        assignments: rows.map((a) => ({
          id: a.id, title: a.title, kind: a.kind, targetRef: a.target_ref,
          className: a.class_name, studentName: a.student_name, dueAt: a.due_at,
          instructions: a.instructions, createdAt: a.created_at,
          criteria: JSON.parse(a.criteria_json || '{}'),
        })),
      });
    } catch (err) { return handle(res, err); }
  });

  r.post('/assignments', (req, res) => {
    try {
      const b = body(req);
      const kind = oneOf(b.kind, ['LESSON', 'GAME', 'TEST', 'PRACTICE'], { name: 'Assignment type' });
      const title = cleanText(b.title, { name: 'Title', min: 2, max: 120 });
      const targetRef = str(b.targetRef, { name: 'Target', min: 1, max: 80 });
      const classId = b.classId ? id(b.classId, { name: 'Class' }) : null;
      const studentId = b.studentId ? id(b.studentId, { name: 'Student' }) : null;
      if (!classId && !studentId) throw new ValidationError('Choose a class or a student.', 'classId');
      if (classId && !canAccessClass(db, req.user, classId)) return res.status(403).json({ error: 'forbidden' });

      if (kind === 'LESSON' && !getLesson(targetRef)) throw new ValidationError('Unknown lesson.', 'targetRef');
      if (kind === 'GAME' && !getGame(targetRef)) throw new ValidationError('Unknown game.', 'targetRef');
      if (kind === 'TEST' && !db.prepare('SELECT 1 AS ok FROM typing_tests WHERE id = ?').get(Number(targetRef))) {
        throw new ValidationError('Unknown test.', 'targetRef');
      }

      const dueAt = b.dueAt ? str(b.dueAt, { name: 'Due date', min: 10, max: 30 }).replace('T', ' ').slice(0, 19) : null;
      const instructions = b.instructions ? cleanText(b.instructions, { name: 'Instructions', max: 1000, required: false }) : null;
      const info = db.prepare(`
        INSERT INTO assignments (instructor_id, class_id, student_id, kind, target_ref, title, instructions, criteria_json, due_at)
        VALUES (?,?,?,?,?,?,?,?,?)
      `).run(req.user.id, classId, studentId, kind, targetRef, title, instructions, JSON.stringify(b.criteria ?? {}), dueAt);
      audit(db, req.user.id, 'assignment.create', `assignment:${info.lastInsertRowid}`, { kind, targetRef });
      return res.status(201).json({ id: info.lastInsertRowid });
    } catch (err) { return handle(res, err); }
  });

  r.delete('/assignments/:assignmentId', (req, res) => {
    try {
      const assignmentId = id(req.params.assignmentId, { name: 'Assignment' });
      const row = db.prepare('SELECT * FROM assignments WHERE id = ?').get(assignmentId);
      if (!row) return res.status(404).json({ error: 'not_found' });
      if (req.user.role !== 'ADMIN' && row.instructor_id !== req.user.id) return res.status(403).json({ error: 'forbidden' });
      db.prepare('UPDATE assignments SET is_active = 0 WHERE id = ?').run(assignmentId);
      audit(db, req.user.id, 'assignment.archive', `assignment:${assignmentId}`);
      return res.json({ ok: true });
    } catch (err) { return handle(res, err); }
  });

  // ----------------------------------------------------------------- tests
  r.get('/tests', (req, res) => {
    try {
      const tests = db.prepare('SELECT * FROM typing_tests WHERE instructor_id = ? OR ? = \'ADMIN\' ORDER BY created_at DESC')
        .all(req.user.id, req.user.role);
      return res.json({ tests });
    } catch (err) { return handle(res, err); }
  });

  r.post('/tests', (req, res) => {
    try {
      const b = body(req);
      const title = cleanText(b.title, { name: 'Title', min: 3, max: 120 });
      const passage = str(b.passage, { name: 'Passage', min: 80, max: 5000, trim: true });
      const durationMs = num(b.durationMs, { name: 'Duration', min: 30000, max: 1800000, integer: true, fallback: 300000 });
      const minWpm = num(b.minWpm, { name: 'Pass mark (WPM)', min: 0, max: 300, fallback: 20 });
      const minAccuracy = num(b.minAccuracy, { name: 'Pass mark (accuracy)', min: 0, max: 100, fallback: 95 });
      const allowBackspace = bool(b.allowBackspace, true) ? 1 : 0;
      const showTimer = bool(b.showTimer, true) ? 1 : 0;
      const showLiveWpm = bool(b.showLiveWpm, true) ? 1 : 0;
      const randomize = bool(b.randomize, false) ? 1 : 0;
      const info = db.prepare(`
        INSERT INTO typing_tests (instructor_id, title, passage, duration_ms, min_wpm, min_accuracy,
          allow_backspace, show_timer, show_live_wpm, randomize)
        VALUES (?,?,?,?,?,?,?,?,?,?)
      `).run(req.user.id, title, passage, durationMs, minWpm, minAccuracy, allowBackspace, showTimer, showLiveWpm, randomize);
      audit(db, req.user.id, 'test.create', `test:${info.lastInsertRowid}`, { title });
      return res.status(201).json({ test: db.prepare('SELECT * FROM typing_tests WHERE id = ?').get(info.lastInsertRowid) });
    } catch (err) { return handle(res, err); }
  });

  r.patch('/tests/:testId', (req, res) => {
    try {
      const testId = id(req.params.testId, { name: 'Test' });
      const test = db.prepare('SELECT * FROM typing_tests WHERE id = ?').get(testId);
      if (!test) return res.status(404).json({ error: 'not_found' });
      if (req.user.role !== 'ADMIN' && test.instructor_id !== req.user.id) return res.status(403).json({ error: 'forbidden' });
      const b = body(req);
      db.prepare(`UPDATE typing_tests SET
        title = COALESCE(?, title), passage = COALESCE(?, passage), duration_ms = COALESCE(?, duration_ms),
        min_wpm = COALESCE(?, min_wpm), min_accuracy = COALESCE(?, min_accuracy),
        allow_backspace = COALESCE(?, allow_backspace), show_timer = COALESCE(?, show_timer),
        show_live_wpm = COALESCE(?, show_live_wpm), is_active = COALESCE(?, is_active)
        WHERE id = ?`).run(
        b.title ? cleanText(b.title, { name: 'Title', min: 3, max: 120 }) : null,
        b.passage ? str(b.passage, { name: 'Passage', min: 80, max: 5000, trim: true }) : null,
        b.durationMs != null ? num(b.durationMs, { name: 'Duration', min: 30000, max: 1800000, integer: true }) : null,
        b.minWpm != null ? num(b.minWpm, { name: 'Pass mark (WPM)', min: 0, max: 300 }) : null,
        b.minAccuracy != null ? num(b.minAccuracy, { name: 'Pass mark (accuracy)', min: 0, max: 100 }) : null,
        b.allowBackspace != null ? (bool(b.allowBackspace) ? 1 : 0) : null,
        b.showTimer != null ? (bool(b.showTimer) ? 1 : 0) : null,
        b.showLiveWpm != null ? (bool(b.showLiveWpm) ? 1 : 0) : null,
        b.isActive != null ? (bool(b.isActive) ? 1 : 0) : null,
        testId,
      );
      audit(db, req.user.id, 'test.update', `test:${testId}`);
      return res.json({ test: db.prepare('SELECT * FROM typing_tests WHERE id = ?').get(testId) });
    } catch (err) { return handle(res, err); }
  });

  // --------------------------------------------------------------- exports
  r.get('/classes/:classId/export.csv', (req, res) => {
    try {
      const classId = id(req.params.classId, { name: 'Class' });
      if (!canAccessClass(db, req.user, classId)) return res.status(403).json({ error: 'forbidden' });
      const report = classReport(db, classId);
      if (!report) return res.status(404).json({ error: 'not_found' });
      const columns = [
        { key: 'username', label: 'Username' },
        { key: 'displayName', label: 'Student name' },
        { key: 'status', label: 'Enrolment' },
        { key: 'enrolledAt', label: 'Enrolled on' },
        { key: 'sessions', label: 'Sessions' },
        { key: 'practiceMs', label: 'Practice minutes', get: (r2) => Math.round(r2.practiceMs / 60000) },
        { key: 'bestWpm', label: 'Best net WPM' },
        { key: 'avgWpm', label: 'Average net WPM' },
        { key: 'avgAccuracy', label: 'Average accuracy %' },
        { key: 'mastered', label: 'Lessons mastered' },
        { key: 'games', label: 'Arcade rounds' },
        { key: 'pending', label: 'Pending assignments' },
        { key: 'overdue', label: 'Overdue assignments' },
        { key: 'lastPracticeAt', label: 'Last practice' },
      ];
      audit(db, req.user.id, 'export.class_csv', `class:${classId}`);
      return csvResponse(res, `bica-class-${report.class.code}-${isoNow().slice(0, 10)}.csv`, columns, report.students);
    } catch (err) { return handle(res, err); }
  });

  r.get('/students/:studentId/report.pdf', (req, res) => {
    try {
      const studentId = id(req.params.studentId, { name: 'Student' });
      if (!canAccessStudent(db, req.user, studentId)) return res.status(403).json({ error: 'forbidden' });
      const report = studentReport(db, studentId);
      if (!report) return res.status(404).json({ error: 'not_found' });
      const settings = getSettings(db);
      const pdf = createPdf({ size: 'A4' });
      const M = 48;
      pdf.rect({ x: 0, y: 0, w: pdf.width, h: 86, fill: '#12161c' });
      pdf.text(settings['org.name'], { x: M, y: 28, size: 15, font: 'bold', color: '#ffffff' });
      pdf.text('Student progress report', { x: M, y: 50, size: 10, color: '#c8d0da' });
      pdf.text(`Generated ${new Date().toLocaleString('en-IN')}`, { x: pdf.width - M, y: 50, size: 9, color: '#c8d0da', align: 'right' });

      let y = 118;
      pdf.text(report.student.displayName, { x: M, y, size: 18, font: 'bold', color: '#12161c' });
      y += 20;
      pdf.text(`${report.student.username}  ·  ${report.classes.map((c) => c.name).join(', ') || 'No class'}  ·  Level ${report.level} (${report.levelName})`, { x: M, y, size: 9.5, color: '#5c6470' });
      y += 28;

      const stat = (label, value, x) => {
        pdf.text(String(value), { x, y, size: 16, font: 'bold', color: '#12161c' });
        pdf.text(label, { x, y: y + 14, size: 8, color: '#5c6470' });
      };
      const colW = (pdf.width - 2 * M) / 4;
      stat('Best net WPM', report.stats.bestWpm, M);
      stat('Average accuracy', `${report.stats.avgAccuracy}%`, M + colW);
      stat('Lessons mastered', `${report.progress.mastered}/${report.progress.total}`, M + colW * 2);
      stat('Practice time', `${Math.round(report.stats.totalMs / 60000)} min`, M + colW * 3);
      y += 44;
      pdf.line(M, y, pdf.width - M, y, { color: '#dfe4ea', width: 0.8 });
      y += 22;

      pdf.text('Performance', { x: M, y, size: 11, font: 'bold', color: '#12161c' });
      y += 16;
      y = pdf.paragraph(
        `Sessions recorded: ${report.stats.sessions}. Average net speed: ${report.stats.avgWpm} WPM. Consistency: ${report.stats.avgConsistency}%. Current streak: ${report.stats.streak} day(s). `
        + `Most recent practice: ${report.stats.lastPracticeDaysAgo == null ? 'never' : `${report.stats.lastPracticeDaysAgo} day(s) ago`}.`,
        { x: M, y, size: 9.5, color: '#2b323c', maxWidth: pdf.width - 2 * M },
      );
      y += 14;

      pdf.text('Weakest keys (from recorded keystrokes)', { x: M, y, size: 11, font: 'bold', color: '#12161c' });
      y += 16;
      if (report.weakKeys.length === 0) {
        pdf.text('Not enough keystroke data yet.', { x: M, y, size: 9.5, color: '#5c6470' });
        y += 16;
      } else {
        for (const k of report.weakKeys.slice(0, 6)) {
          pdf.text(`${k.key === ' ' ? 'Space' : `"${k.key}"`}`, { x: M, y, size: 9.5, font: 'mono', color: '#12161c' });
          pdf.text(`${k.errorRate}% error rate over ${k.attempts} presses`, { x: M + 60, y, size: 9.5, color: '#2b323c' });
          y += 14;
        }
      }
      y += 8;

      pdf.text('Recent sessions', { x: M, y, size: 11, font: 'bold', color: '#12161c' });
      y += 16;
      pdf.text('Source', { x: M, y, size: 8, color: '#5c6470', font: 'bold' });
      pdf.text('Reference', { x: M + 70, y, size: 8, color: '#5c6470', font: 'bold' });
      pdf.text('Net WPM', { x: M + 200, y, size: 8, color: '#5c6470', font: 'bold' });
      pdf.text('Accuracy', { x: M + 270, y, size: 8, color: '#5c6470', font: 'bold' });
      pdf.text('Result', { x: M + 330, y, size: 8, color: '#5c6470', font: 'bold' });
      pdf.text('When', { x: M + 390, y, size: 8, color: '#5c6470', font: 'bold' });
      y += 12;
      for (const s of report.recentSessions.slice(0, 14)) {
        pdf.text(s.source, { x: M, y, size: 8.5, color: '#2b323c' });
        pdf.text(s.refId ?? s.title ?? '-', { x: M + 70, y, size: 8.5, color: '#2b323c' });
        pdf.text(String(s.netWpm), { x: M + 200, y, size: 8.5, color: '#2b323c' });
        pdf.text(`${Math.round(s.accuracy)}%`, { x: M + 270, y, size: 8.5, color: '#2b323c' });
        pdf.text(s.passed ? 'passed' : '-', { x: M + 330, y, size: 8.5, color: '#2b323c' });
        pdf.text(String(s.startedAt).slice(0, 16), { x: M + 390, y, size: 8.5, color: '#2b323c' });
        y += 12;
        if (y > pdf.height - 80) break;
      }

      if (report.riskFlags.length) {
        y += 8;
        pdf.text('Support flags', { x: M, y, size: 10, font: 'bold', color: '#9a3412' });
        y += 14;
        for (const flag of report.riskFlags.slice(0, 4)) {
          y = pdf.paragraph(`• ${flag}`, { x: M, y, size: 9, color: '#9a3412', maxWidth: pdf.width - 2 * M });
        }
      }

      pdf.line(M, pdf.height - 52, pdf.width - M, pdf.height - 52, { color: '#dfe4ea', width: 0.8 });
      pdf.text('BICA Typing Studio · internal progress report · not an external accreditation document', {
        x: M, y: pdf.height - 38, size: 7.5, color: '#7a828d',
      });
      audit(db, req.user.id, 'export.student_pdf', `user:${studentId}`);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `inline; filename="bica-report-${report.student.username}.pdf"`);
      return res.send(pdf.build());
    } catch (err) { return handle(res, err); }
  });

  /** Course + game catalogs for assignment pickers. */
  r.get('/catalog', (req, res) => {
    try {
      const curriculum = db.prepare('SELECT id, level, title FROM lessons ORDER BY level, order_index').all();
      const tests = db.prepare('SELECT id, title FROM typing_tests WHERE is_active = 1').all();
      return res.json({
        lessons: curriculum,
        games: GAMES.map((g) => ({ id: g.id, title: g.title })),
        tests,
      });
    } catch (err) { return handle(res, err); }
  });

  /** Assignment status matrix for a class (used by the assignments screen). */
  r.get('/classes/:classId/assignment-status', (req, res) => {
    try {
      const classId = id(req.params.classId, { name: 'Class' });
      if (!canAccessClass(db, req.user, classId)) return res.status(403).json({ error: 'forbidden' });
      const students = db.prepare(`
        SELECT u.id, u.display_name FROM enrollments e JOIN users u ON u.id = e.student_id
        WHERE e.class_id = ? AND e.status = 'ACTIVE' ORDER BY u.display_name
      `).all(classId);
      const rows = students.map((s) => {
        const st = assignmentStatusForStudent(db, s.id, classId);
        return { studentId: s.id, displayName: s.display_name, ...st };
      });
      return res.json({ rows });
    } catch (err) { return handle(res, err); }
  });

  return r;
}
