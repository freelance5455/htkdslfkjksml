import express from 'express';
import { requireAuth } from '../auth.js';
import { submitSession, startSession, SessionError } from '../services/sessions.js';
import { canAccessStudent } from '../auth.js';
import { body, handle, id, str, oneOf, num } from '../lib/validate.js';

export function sessionRoutes(db, config) {
  const r = express.Router();

  r.post('/', requireAuth, (req, res) => {
    try {
      const b = body(req);
      const tokenId = str(b.tokenId, { name: 'Session token', min: 8, max: 120 });
      const clientSessionId = str(b.clientSessionId, { name: 'Client session id', min: 8, max: 100 });
      if (!b.summary || typeof b.summary !== 'object') {
        return res.status(400).json({ error: 'validation_failed', message: 'A session summary is required.' });
      }
      const result = submitSession(db, config, {
        user: req.user,
        tokenId,
        clientSessionId,
        summary: b.summary,
        title: b.title == null ? '' : str(b.title, { name: 'Title', max: 120, required: false }),
        mode: oneOf(b.mode, ['time', 'words', 'text'], { name: 'Mode', fallback: 'text' }),
        meta: typeof b.meta === 'object' && b.meta ? b.meta : {},
      });
      return res.json({
        session: {
          id: result.session.id,
          source: result.session.source,
          refId: result.session.ref_id,
          title: result.session.title,
          durationMs: result.session.duration_ms,
          grossWpm: result.session.gross_wpm,
          netWpm: result.session.net_wpm,
          accuracy: result.session.accuracy,
          consistency: result.session.consistency,
          committedChars: result.session.typed_chars,
          correctChars: result.session.correct_chars,
          errorKeystrokes: result.session.error_keystrokes,
          uncorrectedErrors: result.session.uncorrected_errors,
          backspaces: result.session.backspaces,
          passed: Boolean(result.session.passed),
          verified: Boolean(result.session.verified),
          startedAt: result.session.started_at,
        },
        duplicate: result.duplicate,
        passed: result.passed,
        reasons: result.reasons,
        thresholds: result.thresholds,
        newAchievements: result.newAchievements,
      });
    } catch (err) {
      if (err instanceof SessionError) {
        return res.status(err.status).json({ error: err.code, message: err.message });
      }
      return handle(res, err);
    }
  });

  r.get('/:sessionId', requireAuth, (req, res) => {
    try {
      const sessionId = id(req.params.sessionId, { name: 'Session' });
      const row = db.prepare('SELECT * FROM typing_sessions WHERE id = ?').get(sessionId);
      if (!row) return res.status(404).json({ error: 'not_found', message: 'Session not found.' });
      if (!canAccessStudent(db, req.user, row.student_id)) return res.status(403).json({ error: 'forbidden' });
      const perKey = db.prepare('SELECT key, attempts, errors, avg_interval_ms FROM typing_errors WHERE session_id = ? ORDER BY errors DESC').all(sessionId);
      return res.json({ session: row, perKey });
    } catch (err) { return handle(res, err); }
  });

  /** Instructor-configured tests (read side is shared with students). */
  r.get('/tests/available', requireAuth, (req, res) => {
    try {
      const tests = db.prepare(`
        SELECT id, title, duration_ms, min_wpm, min_accuracy, allow_backspace, show_timer, show_live_wpm, randomize
        FROM typing_tests WHERE is_active = 1 ORDER BY created_at DESC LIMIT 100
      `).all().map((t) => ({
        id: t.id, title: t.title, durationMs: t.duration_ms, minWpm: t.min_wpm, minAccuracy: t.min_accuracy,
        allowBackspace: Boolean(t.allow_backspace), showTimer: Boolean(t.show_timer),
        showLiveWpm: Boolean(t.show_live_wpm), randomize: Boolean(t.randomize),
      }));
      return res.json({ tests });
    } catch (err) { return handle(res, err); }
  });

  r.post('/tests/:testId/start', requireAuth, (req, res) => {
    try {
      const testId = num(req.params.testId, { name: 'Test', min: 1, max: 1e9, integer: true });
      const test = db.prepare('SELECT * FROM typing_tests WHERE id = ? AND is_active = 1').get(testId);
      if (!test) return res.status(404).json({ error: 'not_found', message: 'Test not found.' });
      const started = startSession(db, {
        userId: req.user.id, source: 'test', refId: String(test.id),
        expectedMs: test.duration_ms, targetChars: test.passage.length,
      });
      return res.json({
        tokenId: started.tokenId,
        startedAt: started.startedAt,
        text: test.passage,
        mode: 'time',
        durationSec: Math.round(test.duration_ms / 1000),
        expectedMs: test.duration_ms,
        allowBackspace: Boolean(test.allow_backspace),
        showTimer: Boolean(test.show_timer),
        showLiveWpm: Boolean(test.show_live_wpm),
        title: test.title,
        passMark: { minWpm: test.min_wpm, minAccuracy: test.min_accuracy },
      });
    } catch (err) { return handle(res, err); }
  });

  return r;
}
