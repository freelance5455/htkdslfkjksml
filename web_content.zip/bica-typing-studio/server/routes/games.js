import express from 'express';
import { requireAuth } from '../auth.js';
import { getSettings, enabledGameIds } from '../settings.js';
import { gameCatalog, getGame, DIFFICULTIES } from '../../shared/scoring.js';
import { startGameRound, submitGameRound, SessionError } from '../services/sessions.js';
import { body, handle, str, oneOf, num } from '../lib/validate.js';

export function gameRoutes(db, config) {
  const r = express.Router();

  r.get('/', requireAuth, (req, res) => {
    try {
      const settings = getSettings(db);
      const enabled = enabledGameIds(settings);
      const best = db.prepare(`
        SELECT game_id, difficulty,
               MAX(CASE WHEN verified = 1 THEN score ELSE 0 END) AS best_score,
               MAX(CASE WHEN verified = 1 THEN accuracy ELSE 0 END) AS best_accuracy,
               COUNT(*) AS plays
        FROM game_sessions WHERE student_id = ? GROUP BY game_id, difficulty
      `).all(req.user.id);
      const byGame = new Map();
      for (const row of best) {
        const entry = byGame.get(row.game_id) ?? { bestScore: 0, bestAccuracy: 0, plays: 0, byDifficulty: {} };
        entry.bestScore = Math.max(entry.bestScore, row.best_score);
        entry.bestAccuracy = Math.max(entry.bestAccuracy, row.best_accuracy);
        entry.plays += row.plays;
        entry.byDifficulty[row.difficulty] = { bestScore: row.best_score, bestAccuracy: row.best_accuracy, plays: row.plays };
        byGame.set(row.game_id, entry);
      }
      const catalog = gameCatalog({ enabledIds: enabled })
        .map((g) => ({
          ...g,
          personal: byGame.get(g.id) ?? { bestScore: 0, bestAccuracy: 0, plays: 0, byDifficulty: {} },
          arcadeEnabled: settings['features.arcade'] !== false,
        }));
      return res.json({
        games: catalog,
        difficulties: Object.values(DIFFICULTIES),
        arcadeEnabled: settings['features.arcade'] !== false,
      });
    } catch (err) { return handle(res, err); }
  });

  r.post('/start', requireAuth, (req, res) => {
    try {
      const b = body(req);
      const settings = getSettings(db);
      if (settings['features.arcade'] === false) {
        return res.status(403).json({ error: 'arcade_disabled', message: 'The arcade is disabled by your centre.' });
      }
      const gameId = str(b.gameId, { name: 'Game', min: 2, max: 40 });
      const game = getGame(gameId);
      if (!game) return res.status(404).json({ error: 'not_found', message: 'That game does not exist.' });
      if (!enabledGameIds(settings).includes(gameId)) {
        return res.status(403).json({ error: 'game_disabled', message: 'This game has been disabled by your instructor.' });
      }
      const difficulty = oneOf(b.difficulty, ['easy', 'normal', 'hard'], { name: 'Difficulty', fallback: 'normal' });
      const round = startGameRound(db, { userId: req.user.id, gameId, difficulty });
      return res.json(round);
    } catch (err) { return handle(res, err); }
  });

  r.post('/submit', requireAuth, (req, res) => {
    try {
      const b = body(req);
      const result = submitGameRound(db, config, {
        user: req.user,
        tokenId: str(b.tokenId, { name: 'Round token', min: 8, max: 120 }),
        clientSessionId: str(b.clientSessionId, { name: 'Client round id', min: 8, max: 100 }),
        gameId: str(b.gameId, { name: 'Game', min: 2, max: 40 }),
        difficulty: oneOf(b.difficulty, ['easy', 'normal', 'hard'], { name: 'Difficulty', fallback: 'normal' }),
        summary: b.summary && typeof b.summary === 'object' ? b.summary : {},
        levelReached: num(b.levelReached, { name: 'Level', min: 0, max: 10000, integer: true, fallback: 0 }),
        outcome: oneOf(b.outcome, ['COMPLETE', 'GAME_OVER', 'ABANDONED'], { name: 'Outcome', fallback: 'COMPLETE' }),
        meta: typeof b.meta === 'object' && b.meta ? b.meta : {},
      });
      return res.json({
        round: result.round,
        duplicate: result.duplicate,
        scoring: result.scoring ?? null,
        newAchievements: result.newAchievements ?? [],
        // Present when the round was too short to score (see submitGameRound).
        note: result.note ?? null,
      });
    } catch (err) {
      if (err instanceof SessionError) return res.status(err.status).json({ error: err.code, message: err.message });
      return handle(res, err);
    }
  });

  r.get('/history', requireAuth, (req, res) => {
    try {
      const rows = db.prepare(`
        SELECT id, game_id, difficulty, score, accuracy, wpm, duration_ms, level_reached, outcome, created_at
        FROM game_sessions WHERE student_id = ? ORDER BY created_at DESC LIMIT 50
      `).all(req.user.id);
      return res.json({ history: rows });
    } catch (err) { return handle(res, err); }
  });

  /** Per-game leaderboard within the student's own classes only. */
  r.get('/:gameId/leaderboard', requireAuth, (req, res) => {
    try {
      const gameId = str(req.params.gameId, { name: 'Game', min: 2, max: 40 });
      const settings = getSettings(db);
      if (settings['features.leaderboards'] === false) {
        return res.json({ leaderboard: [], disabled: true, message: 'Leaderboards are disabled by your centre.' });
      }
      const rows = db.prepare(`
        SELECT g.score, g.accuracy, g.difficulty, g.created_at,
               CASE WHEN ? = 1 THEN u.display_name ELSE 'BICA-' || printf('%04d', u.id) END AS name
        FROM game_sessions g JOIN users u ON u.id = g.student_id
        WHERE g.game_id = ? AND u.is_active = 1 AND g.verified = 1
        ORDER BY g.score DESC, g.accuracy DESC LIMIT 20
      `).all(settings['features.publicNames'] === false ? 0 : 1, gameId);
      return res.json({ leaderboard: rows, gameId });
    } catch (err) { return handle(res, err); }
  });

  return r;
}
