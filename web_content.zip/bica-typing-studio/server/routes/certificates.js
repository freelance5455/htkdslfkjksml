import express from 'express';
import crypto from 'node:crypto';
import { requireAuth, requireRole, canAccessStudent, audit } from '../auth.js';
import { getSettings } from '../settings.js';
import { createPdf } from '../lib/pdf.js';
import { studentProgress } from '../services/reports.js';
import { evaluateAchievements } from '../services/achievements.js';
import { handle, body, id, str } from '../lib/validate.js';

function verificationCode(config, payload) {
  return crypto.createHmac('sha256', config.secret)
    .update(JSON.stringify(payload))
    .digest('hex')
    .slice(0, 12)
    .toUpperCase()
    .replace(/(.{4})(?=.)/g, '$1-');
}

export function certificateEligibility(db, studentId) {
  const settings = getSettings(db);
  const progress = studentProgress(db, studentId, settings);
  const best = db.prepare(`
    SELECT COALESCE(MAX(net_wpm),0) AS best_wpm,
           (SELECT accuracy FROM typing_sessions WHERE student_id = ? AND verified = 1
            ORDER BY accuracy DESC, net_wpm DESC LIMIT 1) AS best_accuracy_ref
    FROM typing_sessions WHERE student_id = ? AND verified = 1
  `).get(studentId, studentId);

  // Best accuracy among sessions that carried at least 100 characters, so a
  // three-character fluke cannot satisfy the accuracy criterion.
  const accuracyRow = db.prepare(`
    SELECT accuracy FROM typing_sessions
    WHERE student_id = ? AND verified = 1 AND typed_chars >= 100
    ORDER BY accuracy DESC, net_wpm DESC LIMIT 1
  `).get(studentId);

  const bestWpm = Math.round(best.best_wpm * 10) / 10;
  const bestAccuracy = Math.round((accuracyRow?.accuracy ?? best.best_accuracy_ref ?? 0) * 10) / 10;
  const mastered = progress.masteredCount;

  const requirements = {
    minLevel: Number(settings['cert.minLevel'] ?? 3),
    minLessons: Number(settings['cert.minLessons'] ?? 20),
    minWpm: Number(settings['cert.minWpm'] ?? 20),
    minAccuracy: Number(settings['cert.minAccuracy'] ?? 95),
  };

  const levelMasteredCounts = [0, 1, 2, 3, 4, 5, 6].map((lvl) => ({
    level: lvl,
    mastered: progress.lessons.filter((l) => l.level === lvl && l.mastered).length,
    total: progress.lessons.filter((l) => l.level === lvl).length,
  }));
  const levelsCompleteThrough = levelMasteredCounts
    .filter((l) => l.total > 0 && l.mastered === l.total)
    .map((l) => l.level);

  // "Complete every lesson through level N" means every level from 0 to N is
  // fully mastered. `minLevel: 0` is read as "no level requirement", because an
  // administrator switching the requirement off must not accidentally make it
  // stricter than leaving it at 1.
  const requiredLevels = requirements.minLevel === 0
    ? []
    : Array.from({ length: requirements.minLevel + 1 }, (_, i) => i);
  const levelsMet = requiredLevels.every((lvl) => levelsCompleteThrough.includes(lvl));

  const checks = [
    { id: 'lessons', label: `At least ${requirements.minLessons} lessons mastered`, met: mastered >= requirements.minLessons, actual: mastered },
    {
      id: 'level',
      label: requirements.minLevel === 0
        ? 'No level requirement'
        : `Complete every lesson in levels 0–${requirements.minLevel}`,
      met: levelsMet,
      actual: levelsCompleteThrough.length ? `levels ${levelsCompleteThrough.join(', ')} complete` : 'no level complete',
    },
    { id: 'wpm', label: `Best verified net speed of ${requirements.minWpm} WPM`, met: bestWpm >= requirements.minWpm, actual: bestWpm },
    { id: 'accuracy', label: `Best verified accuracy of ${requirements.minAccuracy}%`, met: bestAccuracy >= requirements.minAccuracy, actual: bestAccuracy },
  ];

  return {
    eligible: checks.every((c) => c.met),
    checks,
    requirements,
    bestWpm,
    bestAccuracy,
    mastered,
    levelsCompleteThrough,
    courseTitle: settings['cert.courseTitle'],
    certificateEnabled: settings['cert.enabled'] !== false,
  };
}

export function certificateRoutes(db, config) {
  const r = express.Router();

  r.get('/', requireAuth, (req, res) => {
    try {
      const isStaff = req.user.role !== 'STUDENT';
      const rows = isStaff
        ? db.prepare(`
            SELECT c.*, u.display_name AS student_name, u.username
            FROM certificates c JOIN users u ON u.id = c.student_id
            ORDER BY c.issued_at DESC LIMIT 200
          `).all()
        : db.prepare(`
            SELECT c.*, u.display_name AS student_name, u.username
            FROM certificates c JOIN users u ON u.id = c.student_id
            WHERE c.student_id = ? ORDER BY c.issued_at DESC
          `).all(req.user.id);
      return res.json({
        certificates: rows,
        eligibility: req.user.role === 'STUDENT' ? certificateEligibility(db, req.user.id) : null,
      });
    } catch (err) { return handle(res, err); }
  });

  r.get('/eligibility/:studentId', requireAuth, requireRole('INSTRUCTOR', 'ADMIN'), (req, res) => {
    try {
      const studentId = id(req.params.studentId, { name: 'Student' });
      if (!canAccessStudent(db, req.user, studentId)) return res.status(403).json({ error: 'forbidden' });
      return res.json(certificateEligibility(db, studentId));
    } catch (err) { return handle(res, err); }
  });

  r.post('/issue', requireAuth, requireRole('INSTRUCTOR', 'ADMIN'), (req, res) => {
    try {
      const b = body(req);
      const studentId = id(b.studentId, { name: 'Student' });
      if (!canAccessStudent(db, req.user, studentId)) return res.status(403).json({ error: 'forbidden' });

      const eligibility = certificateEligibility(db, studentId);
      if (!eligibility.certificateEnabled) {
        return res.status(403).json({ error: 'certificates_disabled', message: 'Certificate issuing is disabled by the administrator.', eligibility });
      }
      if (!eligibility.eligible) {
        return res.status(422).json({
          error: 'not_eligible',
          message: 'The configured completion criteria are not yet met.',
          eligibility,
        });
      }

      const already = db.prepare('SELECT * FROM certificates WHERE student_id = ? AND revoked_at IS NULL').get(studentId);
      if (already) return res.status(409).json({ error: 'already_issued', message: 'This student already holds an active certificate.', certificate: already });

      const student = db.prepare('SELECT * FROM users WHERE id = ?').get(studentId);
      const year = new Date().getUTCFullYear();
      const seq = (db.prepare('SELECT COUNT(*) AS c FROM certificates').get().c + 1).toString().padStart(5, '0');
      const certificateNo = `BICA-${year}-${seq}`;
      const issuedAt = new Date().toISOString();
      const payload = {
        certificateNo, studentId, course: eligibility.courseTitle,
        bestWpm: eligibility.bestWpm, bestAccuracy: eligibility.bestAccuracy, issuedAt,
      };
      const code = verificationCode(config, payload);

      db.prepare(`
        INSERT INTO certificates (certificate_no, verification_code, student_id, course_title, level,
          best_wpm, best_accuracy, lessons_mastered, issued_by, issued_at, payload_json)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
      `).run(certificateNo, code, studentId, eligibility.courseTitle, eligibility.requirements.minLevel,
        eligibility.bestWpm, eligibility.bestAccuracy, eligibility.mastered, req.user.id, issuedAt,
        JSON.stringify({ ...payload, verificationCode: code, issuedByRole: req.user.role }));

      audit(db, req.user.id, 'certificate.issue', `certificate:${certificateNo}`, { studentId, student: student.username });
      try { evaluateAchievements(db, studentId); } catch { /* non-fatal */ }
      const certificate = db.prepare('SELECT * FROM certificates WHERE certificate_no = ?').get(certificateNo);
      return res.status(201).json({ certificate });
    } catch (err) { return handle(res, err); }
  });

  r.post('/:certificateNo/revoke', requireAuth, requireRole('ADMIN'), (req, res) => {
    try {
      const certificateNo = str(req.params.certificateNo, { name: 'Certificate', min: 6, max: 40 });
      const reason = body(req).reason ? str(body(req).reason, { name: 'Reason', min: 3, max: 300 }) : 'Revoked by administrator';
      const info = db.prepare("UPDATE certificates SET revoked_at = datetime('now'), revoke_reason = ? WHERE certificate_no = ? AND revoked_at IS NULL")
        .run(reason, certificateNo);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found', message: 'No active certificate with that number.' });
      audit(db, req.user.id, 'certificate.revoke', `certificate:${certificateNo}`, { reason });
      return res.json({ ok: true });
    } catch (err) { return handle(res, err); }
  });

  /** PDF certificate. Unicode caveat documented: WinAnsi fonts only. */
  r.get('/:certificateNo/pdf', requireAuth, (req, res) => {
    try {
      const certificateNo = str(req.params.certificateNo, { name: 'Certificate', min: 6, max: 40 });
      const cert = db.prepare(`
        SELECT c.*, u.display_name, u.username FROM certificates c JOIN users u ON u.id = c.student_id
        WHERE c.certificate_no = ?
      `).get(certificateNo);
      if (!cert) return res.status(404).json({ error: 'not_found' });
      if (req.user.role === 'STUDENT' && cert.student_id !== req.user.id) return res.status(403).json({ error: 'forbidden' });

      const settings = getSettings(db);
      const pdf = createPdf({ size: 'A4l' });
      const W = pdf.width;
      const H = pdf.height;

      pdf.rect({ x: 0, y: 0, w: W, h: H, fill: '#fbfaf7' });
      pdf.rect({ x: 0, y: 0, w: W, h: 12, fill: '#12161c' });
      pdf.rect({ x: 0, y: H - 12, w: W, h: 12, fill: '#12161c' });
      pdf.rect({ x: 26, y: 26, w: W - 52, h: H - 52, stroke: '#c9b48a', lineWidth: 1.2 });
      pdf.rect({ x: 32, y: 32, w: W - 64, h: H - 64, stroke: '#e3d9c4', lineWidth: 0.6 });

      pdf.text(settings['org.name'].toUpperCase(), { x: W / 2, y: 66, size: 12, font: 'bold', color: '#5c6470', align: 'center' });
      pdf.text('Certificate of Completion', { x: W / 2, y: 104, size: 30, font: 'serifBold', color: '#12161c', align: 'center' });
      pdf.line(W / 2 - 60, 122, W / 2 + 60, 122, { color: '#c9b48a', width: 1.4 });

      pdf.text('This certificate is awarded to', { x: W / 2, y: 168, size: 11, color: '#5c6470', align: 'center' });
      pdf.text(cert.display_name, { x: W / 2, y: 206, size: 28, font: 'serifBold', color: '#12161c', align: 'center', maxWidth: W - 160 });
      pdf.line(W / 2 - 150, 218, W / 2 + 150, 218, { color: '#dfe4ea', width: 0.8 });

      pdf.paragraph(`for the satisfactory completion of ${cert.course_title}, having met the centre's configured requirements of at least ${cert.lessons_mastered} mastered lessons while maintaining verified accuracy and speed.`, {
        x: W / 2 - 190, y: 244, size: 10.5, color: '#2b323c', maxWidth: 380, lineHeight: 1.5,
      });

      const boxY = 300;
      const boxW = 120;
      const boxGap = 20;
      const startX = W / 2 - (boxW * 3 + boxGap * 2) / 2;
      const boxes = [
        { label: 'VERIFIED NET SPEED', value: `${cert.best_wpm} WPM` },
        { label: 'VERIFIED ACCURACY', value: `${cert.best_accuracy}%` },
        { label: 'LESSONS MASTERED', value: `${cert.lessons_mastered}` },
      ];
      boxes.forEach((b, i) => {
        const x = startX + i * (boxW + boxGap);
        pdf.rect({ x, y: boxY, w: boxW, h: 56, fill: '#ffffff', stroke: '#e3d9c4', lineWidth: 0.7 });
        pdf.text(b.value, { x: x + boxW / 2, y: boxY + 14, size: 15, font: 'bold', color: '#12161c', align: 'center' });
        pdf.text(b.label, { x: x + boxW / 2, y: boxY + 36, size: 6.5, color: '#7a828d', align: 'center' });
      });

      pdf.text('Issued on', { x: 90, y: H - 132, size: 8, color: '#7a828d' });
      pdf.text(new Date(cert.issued_at).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' }),
        { x: 90, y: H - 116, size: 11, color: '#12161c' });
      pdf.line(150, H - 96, 330, H - 96, { color: '#2b323c', width: 0.8 });
      pdf.text(settings['org.certificateSignatory'] || 'Centre Administrator', { x: 150, y: H - 92, size: 9.5, color: '#2b323c' });
      pdf.text('Authorised signatory', { x: 150, y: H - 80, size: 7.5, color: '#7a828d' });

      pdf.text('Certificate number', { x: W - 240, y: H - 132, size: 8, color: '#7a828d' });
      pdf.text(cert.certificate_no, { x: W - 240, y: H - 116, size: 11, font: 'mono', color: '#12161c' });
      pdf.text('Verification code', { x: W - 240, y: H - 100, size: 8, color: '#7a828d' });
      pdf.text(cert.verification_code, { x: W - 240, y: H - 86, size: 10, font: 'mono', color: '#12161c' });
      pdf.line(W - 240, H - 72, W - 90, H - 72, { color: '#dfe4ea', width: 0.6 });

      if (cert.revoked_at) {
        pdf.text('REVOKED', { x: W / 2, y: 250, size: 40, font: 'bold', color: '#b91c1c', align: 'center' });
      }

      pdf.text(`Verify at: /verify  ·  ${settings['org.name']}  ·  This is an internal training certificate. It is not an externally accredited qualification.`, {
        x: W / 2, y: H - 46, size: 7, color: '#8a919b', align: 'center', maxWidth: W - 120,
      });

      audit(db, req.user.id, 'certificate.pdf', `certificate:${certificateNo}`);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `inline; filename="${certificateNo}.pdf"`);
      return res.send(pdf.build());
    } catch (err) { return handle(res, err); }
  });

  return r;
}

/** Public verification endpoint — deliberately exposes only what is printed. */
export function publicRoutes(db) {
  const r = express.Router();

  r.get('/health', (req, res) => res.json({ ok: true, service: 'bica-typing-studio', time: new Date().toISOString() }));

  r.get('/verify/:certificateNo', (req, res) => {
    try {
      const certificateNo = str(req.params.certificateNo, { name: 'Certificate', min: 4, max: 60 }).toUpperCase();
      const code = req.query.code ? str(req.query.code, { name: 'Verification code', min: 4, max: 40 }).toUpperCase() : null;
      const cert = db.prepare(`
        SELECT c.certificate_no, c.verification_code, c.course_title, c.best_wpm, c.best_accuracy,
               c.issued_at, c.revoked_at, u.display_name
        FROM certificates c JOIN users u ON u.id = c.student_id
        WHERE c.certificate_no = ?
      `).get(certificateNo);
      if (!cert) return res.status(404).json({ valid: false, reason: 'not_found', message: 'No certificate with that number exists.' });
      const codeMatches = !code || code === cert.verification_code;
      return res.json({
        valid: !cert.revoked_at && codeMatches,
        reason: cert.revoked_at ? 'revoked' : codeMatches ? 'ok' : 'code_mismatch',
        certificate: {
          number: cert.certificate_no,
          holder: cert.display_name,
          course: cert.course_title,
          bestWpm: cert.best_wpm,
          bestAccuracy: cert.best_accuracy,
          issuedAt: cert.issued_at,
          revoked: Boolean(cert.revoked_at),
        },
        notice: 'Internal certificate of BICA Computer Training Centre. Not an externally accredited qualification.',
      });
    } catch (err) { return handle(res, err); }
  });

  return r;
}
