import express from 'express';
import { requireAuth } from '../auth.js';
import { getSettings } from '../settings.js';
import { buildProgressMap, LEVELS, TOTAL_LESSONS } from '../../shared/curriculum.js';
import { predictNext } from '../services/predict.js';
import { recommend, rankWeakKeys } from '../../shared/adaptive.js';
import { listAchievements, computeStreak } from '../services/achievements.js';
import { handle, num } from '../lib/validate.js';

function progressIndex(db, studentId) {
  const rows = db.prepare('SELECT * FROM lesson_progress WHERE student_id = ?').all(studentId);
  const map = {};
  for (const row of rows) map[row.lesson_id] = { ...row, mastered: Boolean(row.mastered_at) };
  return map;
}

export function studentContext(db, studentId) {
  const settings = getSettings(db);
  const curriculum = buildProgressMap(progressIndex(db, studentId), settings);
  const sessions = db.prepare('SELECT * FROM typing_sessions WHERE student_id = ? ORDER BY started_at DESC LIMIT 25').all(studentId);
  const keyStats = db.prepare('SELECT * FROM key_statistics WHERE student_id = ?').all(studentId);
  return { settings, curriculum, sessions, keyStats, weakKeys: rankWeakKeys(keyStats) };
}

export function meRoutes(db) {
  const r = express.Router();

  r.get('/dashboard', requireAuth, (req, res) => {
    try {
      const userId = req.user.id;
      const { settings, curriculum, sessions, keyStats, weakKeys } = studentContext(db, userId);

      const today = db.prepare(`
        SELECT COALESCE(SUM(duration_ms),0) AS ms, COUNT(*) AS sessions
        FROM typing_sessions
        WHERE student_id = ? AND date(started_at) = date('now')
      `).get(userId);
      const todayGames = db.prepare(`
        SELECT COUNT(*) AS c FROM game_sessions WHERE student_id = ? AND date(created_at) = date('now')
      `).get(userId);

      const totals = db.prepare(`
        SELECT COUNT(*) AS sessions, COALESCE(SUM(duration_ms),0) AS ms,
               COALESCE(MAX(net_wpm),0) AS best_wpm,
               COALESCE(AVG(net_wpm),0) AS avg_wpm,
               COALESCE(AVG(accuracy),0) AS avg_accuracy
        FROM typing_sessions WHERE student_id = ? AND verified = 1
      `).get(userId);
      const last5 = sessions.slice(0, 5);
      const currentWpm = last5.length ? last5.reduce((a, s) => a + s.net_wpm, 0) / last5.length : 0;
      const currentAccuracy = last5.length ? last5.reduce((a, s) => a + s.accuracy, 0) / last5.length : 0;

      const games = db.prepare('SELECT COUNT(*) AS c FROM game_sessions WHERE student_id = ?').get(userId).c;
      const achievementRows = listAchievements(db, userId);
      const days = db.prepare(`
        SELECT DISTINCT date(started_at) AS d FROM typing_sessions WHERE student_id = ?
        UNION SELECT DISTINCT date(created_at) FROM game_sessions WHERE student_id = ?
      `).all(userId, userId).map((x) => x.d);
      const streak = computeStreak(days);

      const dailyTargetMinutes = Number(settings['student.dailyTargetMinutes'] ?? 15);
      const targetMs = dailyTargetMinutes * 60000;

      const recentActivity = db.prepare(`
        SELECT 'session' AS kind, id, source AS type, COALESCE(title, 'Practice session') AS title,
               net_wpm AS wpm, accuracy, duration_ms AS durationMs, created_at AS at, passed
        FROM typing_sessions WHERE student_id = ?
        UNION ALL
        SELECT 'game' AS kind, id, game_id AS type, game_id AS title, wpm, accuracy, duration_ms, created_at, 0
        FROM game_sessions WHERE student_id = ?
        ORDER BY at DESC LIMIT 12
      `).all(userId, userId);

      const adaptive = recommend({ keyStats, sessions, lessons: curriculum.lessons, settings });

      return res.json({
        student: { id: userId, displayName: req.user.displayName, role: req.user.role },
        curriculum: {
          currentLesson: curriculum.currentLesson,
          masteredCount: curriculum.masteredCount,
          totalLessons: TOTAL_LESSONS,
          levels: LEVELS.map((l) => ({
            level: l.level, name: l.name,
            mastered: curriculum.lessons.filter((x) => x.level === l.level && x.mastered).length,
            total: curriculum.lessons.filter((x) => x.level === l.level).length,
          })),
          activeLevel: curriculum.currentLesson?.level ?? 6,
        },
        today: {
          practiceMs: today.ms,
          sessions: today.sessions,
          games: todayGames.c,
          targetMinutes: dailyTargetMinutes,
          progressPct: Math.min(100, Math.round((today.ms / Math.max(1, targetMs)) * 100)),
        },
        stats: {
          totalSessions: totals.sessions,
          totalPracticeMs: totals.ms,
          currentWpm: Math.round(currentWpm * 10) / 10,
          bestWpm: Math.round(totals.best_wpm * 10) / 10,
          currentAccuracy: Math.round(currentAccuracy * 10) / 10,
          averageAccuracy: Math.round(totals.avg_accuracy * 10) / 10,
          gamesPlayed: games,
          streak,
          achievementsEarned: achievementRows.filter((a) => a.earned).length,
          achievementsTotal: achievementRows.length,
        },
        weakKeys,
        prediction: predictNext(sessions, curriculum, settings),
        recommendations: adaptive.recommendations.slice(0, 3),
        diagnosis: adaptive.diagnosis,
        recentActivity,
        lastSession: sessions[0] ?? null,
      });
    } catch (err) { return handle(res, err); }
  });

  r.get('/sessions', requireAuth, (req, res) => {
    try {
      const limit = num(req.query.limit, { name: 'limit', min: 1, max: 200, integer: true, fallback: 40 });
      const rows = db.prepare(`
        SELECT id, source, ref_id, title, mode, typed_chars, correct_chars, error_keystrokes,
               duration_ms, gross_wpm, net_wpm, accuracy, consistency, passed, verified, started_at
        FROM typing_sessions WHERE student_id = ? ORDER BY started_at DESC LIMIT ?
      `).all(req.user.id, limit);
      return res.json({ sessions: rows });
    } catch (err) { return handle(res, err); }
  });

  /** History for charts: daily aggregates over the last N days. */
  r.get('/history', requireAuth, (req, res) => {
    try {
      const days = num(req.query.days, { name: 'days', min: 7, max: 365, integer: true, fallback: 60 });
      const rows = db.prepare(`
        SELECT date(started_at) AS day,
               COUNT(*) AS sessions,
               ROUND(AVG(net_wpm),1) AS avg_wpm,
               ROUND(MAX(net_wpm),1) AS best_wpm,
               ROUND(AVG(accuracy),1) AS avg_accuracy,
               SUM(duration_ms) AS practice_ms
        FROM typing_sessions
        WHERE student_id = ? AND started_at >= datetime('now', ?)
        GROUP BY day ORDER BY day ASC
      `).all(req.user.id, `-${days} days`);
      return res.json({ days, history: rows });
    } catch (err) { return handle(res, err); }
  });

  r.get('/key-stats', requireAuth, (req, res) => {
    try {
      const rows = db.prepare('SELECT * FROM key_statistics WHERE student_id = ? ORDER BY errors DESC').all(req.user.id);
      const shaped = rows.map((k) => ({
        key: k.key,
        attempts: k.attempts,
        errors: k.errors,
        errorRate: k.attempts ? Math.round((k.errors / k.attempts) * 1000) / 10 : 0,
        avgIntervalMs: k.intervals ? Math.round(k.total_interval_ms / k.intervals) : 0,
      }));
      return res.json({ keys: shaped, weakKeys: rankWeakKeys(rows) });
    } catch (err) { return handle(res, err); }
  });

  r.get('/achievements', requireAuth, (req, res) => {
    try {
      return res.json({ achievements: listAchievements(db, req.user.id) });
    } catch (err) { return handle(res, err); }
  });

  r.get('/adaptive', requireAuth, (req, res) => {
    try {
      const { settings, curriculum, sessions, keyStats } = studentContext(db, req.user.id);
      const result = recommend({ keyStats, sessions, lessons: curriculum.lessons, settings });
      return res.json({ ...result, sessionsAnalysed: sessions.length });
    } catch (err) { return handle(res, err); }
  });

  return r;
}

export { progressIndex };
