/**
 * Authentication and authorisation.
 * - Passwords: scrypt (N=16384, r=8, p=1, 64 MB) with a per-user random salt.
 * - Sessions: opaque 256-bit random identifiers stored server-side; the cookie
 *   only carries the identifier, never any user data. Revocation is immediate.
 * - Role checks happen in middleware on the server. Hiding a button in the UI
 *   is a convenience, never a security control.
 */
import crypto from 'node:crypto';

const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64, maxmem: 96 * 1024 * 1024 };
export const MIN_PASSWORD_LENGTH = 10;

export function hashPassword(password) {
  if (typeof password !== 'string' || password.length < MIN_PASSWORD_LENGTH) {
    throw new Error(`Password must be at least ${MIN_PASSWORD_LENGTH} characters.`);
  }
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password.normalize('NFKC'), salt, SCRYPT.keylen, SCRYPT);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${hash.toString('base64')}`;
}

export function verifyPassword(password, stored) {
  if (typeof password !== 'string' || typeof stored !== 'string') return false;
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, N, r, p, saltB64, hashB64] = parts;
  try {
    const salt = Buffer.from(saltB64, 'base64');
    const expected = Buffer.from(hashB64, 'base64');
    const actual = crypto.scryptSync(password.normalize('NFKC'), salt, expected.length, {
      N: Number(N), r: Number(r), p: Number(p), maxmem: SCRYPT.maxmem,
    });
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

export function newSessionId() { return crypto.randomBytes(32).toString('base64url'); }
export function newTokenId() { return crypto.randomBytes(24).toString('base64url'); }

// ------------------------------------------------------------------ cookies
export function parseCookies(header = '') {
  const out = {};
  for (const part of String(header).split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    if (!k) continue;
    out[k] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function sessionCookie(config, value, maxAgeSeconds) {
  const bits = [
    `${config.cookieName}=${encodeURIComponent(value)}`,
    'Path=/', 'HttpOnly', 'SameSite=Lax',
    `Max-Age=${maxAgeSeconds}`,
  ];
  if (config.cookieSecure) bits.push('Secure');
  return bits.join('; ');
}

// ------------------------------------------------------------- rate limiting
/**
 * Token-bucket limiter keyed by arbitrary string. In-process, which is correct
 * for the single-server deployment this app targets.
 */
export class RateLimiter {
  constructor({ windowMs = 15 * 60 * 1000, max = 8 } = {}) {
    this.windowMs = windowMs;
    this.max = max;
    this.hits = new Map();
  }
  check(key) {
    const now = Date.now();
    const arr = (this.hits.get(key) ?? []).filter((t) => now - t < this.windowMs);
    arr.push(now);
    this.hits.set(key, arr);
    if (this.hits.size > 5000) this._sweep(now);
    return { allowed: arr.length <= this.max, remaining: Math.max(0, this.max - arr.length), retryMs: this.windowMs };
  }
  reset(key) { this.hits.delete(key); }
  _sweep(now) {
    for (const [k, arr] of this.hits) {
      if (arr.every((t) => now - t >= this.windowMs)) this.hits.delete(k);
    }
  }
}

// ------------------------------------------------------------- middleware --
export function attachUser(db, config) {
  return (req, res, next) => {
    req.user = null;
    const sid = parseCookies(req.headers.cookie)[config.cookieName];
    if (!sid) return next();
    const row = db.prepare(`
      SELECT s.id AS session_id, s.expires_at, u.id, u.username, u.role, u.display_name,
             u.is_active, u.must_change_pw, u.prefs_json
      FROM auth_sessions s JOIN users u ON u.id = s.user_id
      WHERE s.id = ? AND s.revoked_at IS NULL AND s.expires_at > datetime('now')
    `).get(sid);
    if (!row || !row.is_active) return next();
    db.prepare("UPDATE auth_sessions SET last_seen_at = datetime('now') WHERE id = ?").run(sid);
    req.user = {
      id: row.id,
      username: row.username,
      role: row.role,
      displayName: row.display_name,
      mustChangePw: Boolean(row.must_change_pw),
      prefs: safeJson(row.prefs_json),
      sessionId: row.session_id,
    };
    return next();
  };
}

export function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'authentication_required' });
  return next();
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'authentication_required' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'forbidden', required: roles });
    return next();
  };
}

/** Instructors may only touch classes they own or co-teach; admins may touch all. */
export function canAccessClass(db, user, classId) {
  if (!user) return false;
  if (user.role === 'ADMIN') return true;
  if (user.role !== 'INSTRUCTOR') return false;
  const own = db.prepare('SELECT 1 AS ok FROM classes WHERE id = ? AND instructor_id = ?').get(classId, user.id);
  if (own) return true;
  return Boolean(db.prepare('SELECT 1 AS ok FROM class_instructors WHERE class_id = ? AND instructor_id = ?').get(classId, user.id));
}

/** Instructors may only view students enrolled in a class they can access. */
export function canAccessStudent(db, user, studentId) {
  if (!user) return false;
  if (user.role === 'ADMIN') return true;
  if (user.id === studentId) return true;
  if (user.role !== 'INSTRUCTOR') return false;
  return Boolean(db.prepare(`
    SELECT 1 AS ok FROM enrollments e
    JOIN classes c ON c.id = e.class_id
    LEFT JOIN class_instructors ci ON ci.class_id = c.id
    WHERE e.student_id = ?
      AND (c.instructor_id = ? OR ci.instructor_id = ?)
  `).get(studentId, user.id, user.id));
}

export function audit(db, actorId, action, target = null, detail = {}) {
  try {
    db.prepare('INSERT INTO audit_log (actor_id, action, target, detail_json) VALUES (?,?,?,?)')
      .run(actorId ?? null, action, target, JSON.stringify(detail).slice(0, 4000));
  } catch { /* audit must never break the request */ }
}

export function safeJson(str, fallback = {}) {
  try { return JSON.parse(str); } catch { return fallback; }
}
