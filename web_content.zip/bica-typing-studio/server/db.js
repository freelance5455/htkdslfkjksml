// Database connection + forward-only migration runner.
import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function defaultDbPath() {
  return process.env.BICA_DB || path.join(__dirname, '..', 'data', 'bica.db');
}

export function openDb(dbPath = defaultDbPath()) {
  if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');
  db.pragma('synchronous = NORMAL');
  return db;
}

/**
 * Applies every *.sql migration that has not yet been recorded, in filename order,
 * each inside its own transaction. Returns the list of applied filenames.
 */
export function migrate(db, migrationsDir = path.join(__dirname, 'migrations')) {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    name TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);
  const applied = new Set(db.prepare('SELECT name FROM schema_migrations').all().map((r) => r.name));
  const files = fs.readdirSync(migrationsDir).filter((f) => f.endsWith('.sql')).sort();
  const ran = [];
  for (const file of files) {
    if (applied.has(file)) continue;
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    const run = db.transaction(() => {
      db.exec(sql);
      db.prepare('INSERT INTO schema_migrations (name) VALUES (?)').run(file);
    });
    run();
    ran.push(file);
  }
  return ran;
}

/** Convenience wrapper used by routes: single-row / single-value helpers. */
export const q = {
  one: (db, sql, ...args) => db.prepare(sql).get(...args),
  all: (db, sql, ...args) => db.prepare(sql).all(...args),
  run: (db, sql, ...args) => db.prepare(sql).run(...args),
};
