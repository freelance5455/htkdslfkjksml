/**
 * Centre-wide settings, stored as typed JSON values in app_settings.
 * Defaults live here so a fresh install behaves sensibly without seeding.
 */
import { GAME_IDS } from '../shared/scoring.js';

export const DEFAULTS = {
  'org.name': 'BICA Computer Training Centre',
  'org.address': '',
  'org.certificateSignatory': 'Centre Administrator',

  // Mastery policy. null = use the per-lesson default from the curriculum.
  'curriculum.minAccuracy': null,
  'curriculum.minWpm': null,
  'curriculum.minChars': 0,
  'curriculum.requireSequentialUnlock': true,

  // Feature switches
  'features.competitive': true,
  'features.leaderboards': true,
  'features.publicNames': true,       // false = show BICA-IDs instead of names
  'features.arcade': true,
  'features.offlineQueue': true,

  'games.enabled': GAME_IDS,

  // Examination defaults
  'exams.allowBackspace': true,
  'exams.passAccuracy': 95,
  'exams.passWpm': 20,

  // Certificate policy
  'cert.enabled': true,
  'cert.minLevel': 3,
  'cert.minLessons': 20,
  'cert.minWpm': 20,
  'cert.minAccuracy': 95,
  'cert.courseTitle': 'Certificate in Computer Typing (English QWERTY)',

  'student.dailyTargetMinutes': 15,
  'ui.theme': 'light',
  'ui.defaultLanguage': 'en',
};

export function getSettings(db) {
  const rows = db.prepare('SELECT key, value FROM app_settings').all();
  const merged = { ...DEFAULTS };
  for (const row of rows) {
    try { merged[row.key] = JSON.parse(row.value); } catch { merged[row.key] = row.value; }
  }
  return merged;
}

export function setSetting(db, key, value, actorId = null) {
  db.prepare(`
    INSERT INTO app_settings (key, value, updated_by) VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now'), updated_by = excluded.updated_by
  `).run(key, JSON.stringify(value), actorId);
}

export function enabledGameIds(settings) {
  const list = settings['games.enabled'];
  if (!Array.isArray(list)) return GAME_IDS;
  return list.filter((id) => GAME_IDS.includes(id));
}
