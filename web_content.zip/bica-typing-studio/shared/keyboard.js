/**
 * Keyboard model for English QWERTY (US layout).
 * Used by the on-screen keyboard, finger guidance, and per-key analytics.
 * Layout support beyond QWERTY is intentionally NOT claimed (see docs/RESEARCH.md §8 R2/R3).
 */

export const FINGER_BY_KEY = {
  // left pinky
  '`': 'L-pinky', '1': 'L-pinky', q: 'L-pinky', a: 'L-pinky', z: 'L-pinky',
  // left ring
  '2': 'L-ring', w: 'L-ring', s: 'L-ring', x: 'L-ring',
  // left middle
  '3': 'L-middle', e: 'L-middle', d: 'L-middle', c: 'L-middle',
  // left index
  '4': 'L-index', '5': 'L-index', r: 'L-index', f: 'L-index', v: 'L-index',
  t: 'L-index', g: 'L-index', b: 'L-index',
  // right index
  '6': 'R-index', '7': 'R-index', y: 'R-index', h: 'R-index', n: 'R-index',
  u: 'R-index', j: 'R-index', m: 'R-index',
  // right middle
  '8': 'R-middle', i: 'R-middle', k: 'R-middle', ',': 'R-middle',
  // right ring
  '9': 'R-ring', o: 'R-ring', l: 'R-ring', '.': 'R-ring',
  // right pinky
  '0': 'R-pinky', '-': 'R-pinky', '=': 'R-pinky', p: 'R-pinky', '[': 'R-pinky',
  ']': 'R-pinky', '\\': 'R-pinky', ';': 'R-pinky', "'": 'R-pinky', '/': 'R-pinky',
  ' ': 'Thumb',
};

export const FINGER_LABEL = {
  'L-pinky': 'Left little finger',
  'L-ring': 'Left ring finger',
  'L-middle': 'Left middle finger',
  'L-index': 'Left index finger',
  'R-index': 'Right index finger',
  'R-middle': 'Right middle finger',
  'R-ring': 'Right ring finger',
  'R-pinky': 'Right little finger',
  Thumb: 'Either thumb',
};

export const FINGER_COLOR = {
  'L-pinky': '#b3441f', 'L-ring': '#a8641b', 'L-middle': '#5d7d21',
  'L-index': '#1f7a6d', 'R-index': '#215f8f', 'R-middle': '#4a55a2',
  'R-ring': '#7a3f8f', 'R-pinky': '#a63b62', Thumb: '#5c6470',
};

export const KEY_ROWS = [
  ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 'Backspace'],
  ['Tab', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\\'],
  ['CapsLock', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'", 'Enter'],
  ['ShiftLeft', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 'ShiftRight'],
  ['Space'],
];

/** Wide keys get proportional width in the renderer. */
export const KEY_WIDTH = {
  Backspace: 2, Tab: 1.5, CapsLock: 1.75, Enter: 2.25,
  ShiftLeft: 2.25, ShiftRight: 2.25, Space: 9,
};

const SHIFTED = {
  '`': '~', '1': '!', '2': '@', '3': '#', '4': '$', '5': '%',
  '6': '^', '7': '&', '8': '*', '9': '(', '0': ')', '-': '_', '=': '+',
  '[': '{', ']': '}', '\\': '|', ';': ':', "'": '"', ',': '<', '.': '>', '/': '?',
};

/**
 * Resolve a character to the physical key that produces it.
 * @returns {{key:string, shift:boolean, finger:string, label:string}}
 */
export function keyForChar(ch) {
  if (ch === ' ') return { key: 'Space', shift: false, finger: 'Thumb', label: 'Space bar' };
  const lower = ch.toLowerCase();
  const isUpper = ch !== lower && /[A-Z]/.test(ch);
  const isShiftedSymbol = SHIFTED[lower] === ch;
  const base = isShiftedSymbol ? lower : (isUpper ? lower : ch);
  const finger = FINGER_BY_KEY[base] || null;
  return {
    key: base,
    shift: isUpper || isShiftedSymbol,
    finger,
    label: finger ? FINGER_LABEL[finger] : 'Unknown key',
  };
}

/** Instruction text for a lesson's target key set. */
export function fingerInstructionsFor(keys = []) {
  const byFinger = new Map();
  for (const k of keys) {
    const info = keyForChar(k);
    if (!info.finger) continue;
    if (!byFinger.has(info.finger)) byFinger.set(info.finger, []);
    byFinger.get(info.finger).push(k === ' ' ? 'Space' : k);
  }
  return [...byFinger.entries()].map(([finger, list]) => ({
    finger,
    label: FINGER_LABEL[finger],
    color: FINGER_COLOR[finger],
    keys: list,
  }));
}
