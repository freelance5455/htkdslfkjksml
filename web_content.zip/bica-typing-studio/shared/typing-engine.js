/**
 * BICA TYPING STUDIO — Typing Engine
 * ---------------------------------------------------------------------------
 * ONE measurement implementation, imported by the browser and by Node tests.
 * Lessons, practice, examinations and all twelve games route their keystrokes
 * through this module, so a student's WPM means the same thing everywhere.
 *
 * FORMULAS (documented to the student in the results panel)
 *   A "word" is 5 characters, including spaces (standard convention).
 *   grossWpm  = (committedChars / 5) / minutes
 *   netWpm    = max(0, grossWpm - uncorrectedErrors / minutes)
 *   accuracy  = (forwardKeystrokes - errorKeystrokes) / forwardKeystrokes * 100
 *   consistency = max(0, 100 * (1 - CV(interKeyIntervals)))   [intervals < 1.5 s]
 *
 *   committedChars      characters currently present in the text field
 *   forwardKeystrokes   every non-Backspace key that advanced the field
 *   errorKeystrokes     forward keystrokes whose character did not match
 *                       (a mistake that is later corrected still counts — the
 *                       accuracy figure is honest about it)
 *   uncorrectedErrors   positions still wrong at the moment of measurement
 *
 * UNICODE
 *   Target and input are NFC-normalised and compared code point by code point.
 *   Two visually similar but distinct characters (e.g. Latin "a" vs Cyrillic
 *   "а") are NOT treated as equal. Surrogate pairs are one character.
 *
 * ANTI-TAMPER
 *   The engine is a measuring instrument, not an authority. Every result is
 *   recomputed on the server from raw counters against a server-issued session
 *   token and a server clock. See server/routes/sessions.js.
 */

export const ENGINE_VERSION = '1.0.0';
export const CHARS_PER_WORD = 5;
const MAX_INTERVAL_MS = 1500; // pauses longer than this are not rhythm data
const TIMELINE_BUCKET_MS = 5000;

export function normalizeText(input) {
  return String(input ?? '')
    .normalize('NFC')
    .replace(/\r\n?/g, ' ')
    .replace(/[\n\t]/g, ' ');
}

/** Split into code points (not UTF-16 units) so emoji/surrogates count as one. */
export function toChars(text) {
  return Array.from(normalizeText(text));
}

export function round1(n) {
  return Math.round(n * 10) / 10;
}

// ---------------------------------------------------------------- pure math

/**
 * Pure metric computation. Used by TypingSession and by the server to
 * independently verify a submitted result.
 */
export function computeMetrics({
  committedChars = 0,
  correctChars = 0,
  forwardKeystrokes = 0,
  errorKeystrokes = 0,
  uncorrectedErrors = 0,
  durationMs = 0,
  backspaces = 0,
  intervals = [],
} = {}) {
  const minutes = Math.max(durationMs, 1) / 60000;
  const committed = Math.max(0, committedChars);
  const correct = Math.min(Math.max(0, correctChars), committed);
  const grossWpm = committed / CHARS_PER_WORD / minutes;
  const netWpm = Math.max(0, grossWpm - Math.max(0, uncorrectedErrors) / minutes);
  const correctWpm = correct / CHARS_PER_WORD / minutes;
  const accuracy = forwardKeystrokes > 0
    ? Math.max(0, ((forwardKeystrokes - Math.max(0, errorKeystrokes)) / forwardKeystrokes) * 100)
    : 100;

  let consistency = 0;
  const clean = intervals.filter((v) => Number.isFinite(v) && v > 0 && v <= MAX_INTERVAL_MS);
  if (clean.length >= 3) {
    const mean = clean.reduce((a, b) => a + b, 0) / clean.length;
    const variance = clean.reduce((a, b) => a + (b - mean) ** 2, 0) / clean.length;
    const cv = mean > 0 ? Math.sqrt(variance) / mean : 1;
    consistency = Math.max(0, Math.min(100, 100 * (1 - cv)));
  }

  return {
    durationMs: Math.round(durationMs),
    committedChars: committed,
    correctChars: correct,
    forwardKeystrokes,
    errorKeystrokes,
    uncorrectedErrors: Math.max(0, uncorrectedErrors),
    backspaces,
    grossWpm: round1(grossWpm),
    netWpm: round1(netWpm),
    correctWpm: round1(correctWpm),
    accuracy: round1(Math.min(100, accuracy)),
    consistency: round1(consistency),
  };
}

/**
 * Bigram analysis: which two-key sequences are slow or error-prone.
 * @param {Array<{pair:string, intervalMs:number, errored:boolean}>} samples
 */
export function analyzeBigrams(samples = []) {
  const map = new Map();
  for (const s of samples) {
    if (!s || !s.pair) continue;
    let row = map.get(s.pair);
    if (!row) {
      row = { pair: s.pair, count: 0, totalMs: 0, errorCount: 0 };
      map.set(s.pair, row);
    }
    row.count += 1;
    if (Number.isFinite(s.intervalMs) && s.intervalMs > 0 && s.intervalMs <= MAX_INTERVAL_MS) {
      row.totalMs += s.intervalMs;
    }
    if (s.errored) row.errorCount += 1;
  }
  return [...map.values()]
    .map((r) => ({
      pair: r.pair,
      count: r.count,
      avgIntervalMs: r.count ? Math.round(r.totalMs / r.count) : 0,
      errorRate: r.count ? round1((r.errorCount / r.count) * 100) : 0,
    }))
    .sort((a, b) => b.avgIntervalMs - a.avgIntervalMs || b.errorRate - a.errorRate);
}

// -------------------------------------------------------------- the session

export class TypingSession {
  /**
   * @param {object} opts
   * @param {string}  opts.target          text to type
   * @param {'time'|'words'|'text'} opts.mode
   * @param {number} [opts.durationMs]     required for mode 'time'
   * @param {boolean} [opts.allowBackspace=true]
   * @param {() => number} [opts.now]      injectable clock (tests)
   */
  constructor({ target, mode = 'text', durationMs = null, allowBackspace = true, now = () => Date.now() } = {}) {
    this.targetChars = toChars(target);
    this.mode = mode;
    this.durationMs = durationMs;
    this.allowBackspace = allowBackspace !== false;
    this.now = now;

    this.typed = [];        // characters placed, index 0..length-1
    this.index = 0;
    this.forwardKeystrokes = 0;
    this.errorKeystrokes = 0;
    this.backspaces = 0;
    this.startedAt = now();
    this.endedAt = null;
    this.finished = false;
    this.lastKeyAt = null;
    this.intervals = [];
    this.perKey = new Map();   // key -> { attempts, errors, totalMs, intervals }
    this.bigramSamples = [];
    this.lastChar = null;
    this.timeline = [];
    this._nextBucket = TIMELINE_BUCKET_MS;
    this._errorPositions = new Map(); // position -> true (first error at this spot)
  }

  get length() { return this.targetChars.length; }
  get elapsedMs() { return (this.endedAt ?? this.now()) - this.startedAt; }
  get remainingMs() {
    if (this.mode !== 'time' || !this.durationMs) return null;
    return Math.max(0, this.durationMs - this.elapsedMs);
  }
  get isComplete() {
    if (this.mode === 'time') return false;
    return this.index >= this.targetChars.length;
  }
  get isExpired() {
    return this.mode === 'time' && this.durationMs != null && this.elapsedMs >= this.durationMs;
  }

  /** Current correctness of a single position, for rendering. */
  charState(pos) {
    const expected = this.targetChars[pos];
    const actual = this.typed[pos];
    if (actual == null) return 'pending';
    return actual === expected ? 'correct' : 'incorrect';
  }

  /** Full render model for the typing surface. */
  renderState({ window = 220, lead = 40 } = {}) {
    // A sliding window keeps the DOM small for long passages.
    const from = Math.max(0, Math.min(this.index - lead, this.targetChars.length - window));
    const to = Math.min(this.targetChars.length, from + window);
    const chars = [];
    for (let i = from; i < to; i += 1) {
      chars.push({ i, char: this.targetChars[i], state: this.charState(i) });
    }
    return { from, to, chars, cursor: this.index, total: this.targetChars.length };
  }

  /**
   * Feed one keystroke.
   * @param {string} key a single character, or 'Backspace'
   * @returns {{accepted:boolean, correct?:boolean, finished:boolean}}
   */
  press(key) {
    if (this.finished) return { accepted: false, finished: true, correct: false };
    if (this.isExpired) { this.finish(); return { accepted: false, finished: true, correct: false }; }

    const t = this.now();

    if (key === 'Backspace') {
      if (this.allowBackspace && this.index > 0) {
        this.index -= 1;
        this.typed.length = this.index;
        this.backspaces += 1;
        this.lastKeyAt = t;
        return { accepted: true, finished: false };
      }
      return { accepted: false, finished: false };
    }

    if (typeof key !== 'string' || key.length === 0) return { accepted: false, finished: false };
    const ch = toChars(key)[0]; // one code point per keystroke
    if (ch === undefined) return { accepted: false, finished: false };

    // Interval / rhythm bookkeeping (based on real key timing, not layout).
    let interval = null;
    if (this.lastKeyAt != null) {
      interval = t - this.lastKeyAt;
      if (interval > 0 && interval <= MAX_INTERVAL_MS) this.intervals.push(interval);
    }
    this.lastKeyAt = t;

    if (this.index >= this.targetChars.length) {
      // Over-typing past a finished passage in a fixed-length mode: ignore.
      return { accepted: false, finished: this.isComplete };
    }

    const expected = this.targetChars[this.index];
    const correct = ch === expected;

    this.forwardKeystrokes += 1;
    if (!correct) {
      this.errorKeystrokes += 1;
      if (!this._errorPositions.has(this.index)) this._errorPositions.set(this.index, true);
    }

    this.typed[this.index] = ch;
    this.index += 1;

    // Per-key statistics keyed on the KEY THE STUDENT PRESSED (what they
    // actually struggle with), plus whether it was the right key.
    const stat = this.perKey.get(ch) ?? { attempts: 0, errors: 0, totalMs: 0, intervals: 0 };
    stat.attempts += 1;
    if (!correct) stat.errors += 1;
    if (interval != null && interval > 0 && interval <= MAX_INTERVAL_MS) {
      stat.totalMs += interval;
      stat.intervals += 1;
    }
    this.perKey.set(ch, stat);

    if (this.lastChar != null && interval != null) {
      this.bigramSamples.push({ pair: this.lastChar + ch, intervalMs: interval, errored: !correct });
    }
    this.lastChar = ch;

    // 5-second WPM timeline for the results chart.
    if (this.elapsedMs >= this._nextBucket) {
      this.timeline.push({ atMs: Math.round(this.elapsedMs), wpm: this._currentWpm() });
      this._nextBucket += TIMELINE_BUCKET_MS;
    }

    if (this.isComplete) this.finish();
    return { accepted: true, correct, finished: this.finished };
  }

  _currentWpm() {
    const m = computeMetrics(this._raw());
    return m.grossWpm;
  }

  _raw() {
    let correct = 0;
    for (let i = 0; i < this.index; i += 1) {
      if (this.typed[i] === this.targetChars[i]) correct += 1;
    }
    return {
      committedChars: this.index,
      correctChars: correct,
      forwardKeystrokes: this.forwardKeystrokes,
      errorKeystrokes: this.errorKeystrokes,
      uncorrectedErrors: this.index - correct,
      durationMs: this.elapsedMs,
      backspaces: this.backspaces,
      intervals: this.intervals,
    };
  }

  /** Stop the session (timer expiry, user submits, or passage completed). */
  finish() {
    if (this.finished) return this.summary();
    this.endedAt = this.now();
    this.finished = true;
    return this.summary();
  }

  /** Non-mutating live metrics for the HUD. */
  live() {
    return computeMetrics(this._raw());
  }

  summary() {
    const raw = this._raw();
    const metrics = computeMetrics(raw);
    const elapsed = Math.max(1, this.endedAt ? this.endedAt - this.startedAt : this.elapsedMs);
    return {
      engineVersion: ENGINE_VERSION,
      mode: this.mode,
      ...metrics,
      targetChars: this.targetChars.length,
      completedTarget: this.index >= this.targetChars.length,
      startedAt: this.startedAt,
      endedAt: this.endedAt ?? this.now(),
      elapsedMs: Math.round(elapsed),
      intervals: this.intervals.slice(-4000),
      perKey: [...this.perKey.entries()].map(([key, s]) => ({
        key,
        attempts: s.attempts,
        errors: s.errors,
        avgIntervalMs: s.intervals ? Math.round(s.totalMs / s.intervals) : 0,
      })),
      bigrams: analyzeBigrams(this.bigramSamples),
      timeline: this.timeline,
      errorPositions: [...this._errorPositions.keys()],
    };
  }
}

/**
 * Server-side re-computation from a submitted summary. Deliberately ignores any
 * client-declared wpm/accuracy and derives everything from raw counters.
 */
export function verifySubmission({ summary, serverDurationMs }) {
  const durationMs = Math.max(1, Math.round(serverDurationMs));
  const forward = Math.max(0, Math.min(summary.forwardKeystrokes ?? summary.typedChars ?? 0, 1e7));
  const errors = Math.max(0, Math.min(summary.errorKeystrokes ?? 0, forward));
  const committed = Math.max(0, Math.min(summary.committedChars ?? summary.typedChars ?? 0, 1e7));
  const correct = Math.max(0, Math.min(summary.correctChars ?? 0, committed));
  const uncorrected = Math.max(0, Math.min(summary.uncorrectedErrors ?? committed - correct, committed));
  const intervals = Array.isArray(summary.intervals) ? summary.intervals.slice(0, 5000) : [];
  const metrics = computeMetrics({
    committedChars: committed,
    correctChars: correct,
    forwardKeystrokes: forward,
    errorKeystrokes: errors,
    uncorrectedErrors: uncorrected,
    durationMs,
    backspaces: Math.max(0, Math.min(summary.backspaces ?? 0, 1e7)),
    intervals,
  });
  return metrics;
}
