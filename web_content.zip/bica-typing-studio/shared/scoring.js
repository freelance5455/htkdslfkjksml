/**
 * Game catalogue and scoring.
 * ---------------------------------------------------------------------------
 * Scoring rule (identical for all twelve games, so the arcade is fair):
 *
 *   score = round( basePoints × accuracyFactor × difficultyFactor )
 *   accuracyFactor = (accuracy / 100) ^ 2
 *
 * Consequences, deliberately chosen:
 *   - 100% accuracy at 60 correct hits  = 60 × 1.00 = 60
 *   -  80% accuracy at 80 correct hits  = 80 × 0.64 = 51
 *   -  60% accuracy at 95 correct hits  = 95 × 0.36 = 34
 * A sloppy fast run loses to a careful slower run — speed alone never wins.
 */

export const SCORING_VERSION = '1.0.0';

export const DIFFICULTIES = {
  easy: { id: 'easy', label: 'Easy', factor: 1, blurb: 'Learn the mechanic. Short, forgiving.' },
  normal: { id: 'normal', label: 'Normal', factor: 1.35, blurb: 'The intended experience.' },
  hard: { id: 'hard', label: 'Hard', factor: 1.8, blurb: 'Fast, dense, unforgiving.' },
};

export const GAMES = [
  {
    id: 'falling-letters', title: 'Falling Letters', category: 'Reaction',
    tagline: 'Keys fall. Type them before they land.',
    objective: 'Individual-key recognition and reaction under time pressure.',
    mechanic: 'Letters descend in columns. Type the lowest matching letter to clear it. A letter reaching the floor costs a life.',
    keysHint: 'Single characters', durationSec: 90,
  },
  {
    id: 'bubble-pop', title: 'Bubble Pop', category: 'Recognition',
    tagline: 'Drifting bubbles, each holding a word.',
    objective: 'Character and word recognition with target selection.',
    mechanic: 'Bubbles float upward. Type a bubble\'s word in full to pop it. Popping two in a row builds a combo multiplier.',
    keysHint: 'Words', durationSec: 120,
  },
  {
    id: 'speed-circuit', title: 'Speed Circuit', category: 'Endurance',
    tagline: 'Your car moves only when your typing is right.',
    objective: 'Sustained accuracy at a steady pace.',
    mechanic: 'Three bot cars race you on a circuit. Each correct character advances your car; mistakes stall it. Finish first.',
    keysHint: 'Words and phrases', durationSec: 150,
  },
  {
    id: 'word-orbit', title: 'Word Orbit', category: 'Fluency',
    tagline: 'Clear the lane before the asteroid field.',
    objective: 'Word-level fluency and fast reading.',
    mechanic: 'Your ship flies through lanes. Each lane holds one word; type it to clear the lane and keep flying.',
    keysHint: 'Words', durationSec: 120,
  },
  {
    id: 'typing-bakery', title: 'Typing Bakery', category: 'Real-world',
    tagline: 'The counter queue never stops.',
    objective: 'Real-world vocabulary accuracy under queue pressure.',
    mechanic: 'Customers arrive with orders. Type each item exactly. Orders expire if the queue overflows; every completed order earns money.',
    keysHint: 'Product names', durationSec: 120,
  },
  {
    id: 'keyboard-maze', title: 'Keyboard Maze', category: 'Control',
    tagline: 'Type a direction to step. Type carefully.',
    objective: 'Controlled input and key-combination precision.',
    mechanic: 'A grid maze. Type U, D, L or R to move one cell. Walls do not forgive. Reach the exit in as few wrong turns as possible.',
    keysHint: 'Direction letters', durationSec: 180,
  },
  {
    id: 'word-guardian', title: 'Word Guardian', category: 'Reaction',
    tagline: 'Words charge the barrier. Nothing may pass.',
    objective: 'Fast word recognition and prioritisation.',
    mechanic: 'Creatures advance on your barrier. Complete the highlighted word to fire. The barrier weakens with each arrival you miss.',
    keysHint: 'Words', durationSec: 120,
  },
  {
    id: 'rhythm-keys', title: 'Rhythm Keys', category: 'Timing',
    tagline: 'Every key has a beat.',
    objective: 'Timing, consistency and even rhythm.',
    mechanic: 'Characters scroll toward a strike line on a musical beat. Type inside the timing window. Early or late both cost points.',
    keysHint: 'Letters on beat', durationSec: 90,
  },
  {
    id: 'word-builder', title: 'Word Builder', category: 'Spelling',
    tagline: 'Some letters are missing. Supply them.',
    objective: 'Spelling recall and letter-position awareness.',
    mechanic: 'A word appears with blanks. Type the missing letters in order. Correct completions raise your vocabulary streak.',
    keysHint: 'Missing letters', durationSec: 120,
  },
  {
    id: 'station-master', title: 'Station Master', category: 'Real-world',
    tagline: 'Every announcement goes out exactly as typed.',
    objective: 'Real-world typing fluency with capitals and punctuation.',
    mechanic: 'Announcements must be typed verbatim, capitals and punctuation included. A single mismatch holds the announcement.',
    keysHint: 'Sentences', durationSec: 180,
  },
  {
    id: 'typing-expedition', title: 'Typing Expedition', category: 'Progression',
    tagline: 'Ten locations. One keyboard.',
    objective: 'Sentence and paragraph fluency across a journey.',
    mechanic: 'A map of ten locations. Each location is a mission with its own passage. Accuracy unlocks the next location and earns supplies.',
    keysHint: 'Passages', durationSec: 300,
  },
  {
    id: 'code-sprint', title: 'Code Sprint', category: 'Technical',
    tagline: 'Brackets, symbols and syntax at speed.',
    objective: 'Symbols, punctuation and technical typing.',
    mechanic: 'HTML, CSS and JavaScript tokens rush past. Type each token exactly. A stray character breaks the sprint.',
    keysHint: 'Code symbols', durationSec: 120,
  },
];

export const GAME_IDS = GAMES.map((g) => g.id);
export const GAME_BY_ID = new Map(GAMES.map((g) => [g.id, g]));

export function getGame(id) { return GAME_BY_ID.get(id) ?? null; }

/** Accuracy is squared so it dominates the score. */
export function accuracyFactor(accuracy) {
  const a = Math.max(0, Math.min(100, Number(accuracy) || 0));
  return (a / 100) ** 2;
}

export function difficultyFactor(difficulty) {
  return DIFFICULTIES[difficulty]?.factor ?? 1;
}

/**
 * @param {object} p
 * @param {number} p.basePoints   raw game points earned (hits/objectives)
 * @param {number} p.accuracy     measured by the typing engine, 0-100
 * @param {string} p.difficulty   easy|normal|hard
 * @param {number} [p.completionBonus] 0-1 fraction of objectives completed
 */
export function computeGameScore({ basePoints = 0, accuracy = 0, difficulty = 'normal', completionBonus = 1 }) {
  const base = Math.max(0, Math.round(basePoints));
  const af = accuracyFactor(accuracy);
  const df = difficultyFactor(difficulty);
  const completion = Math.max(0, Math.min(1, completionBonus));
  const score = Math.round(base * af * df * (0.5 + 0.5 * completion));
  return {
    scoringVersion: SCORING_VERSION,
    score,
    basePoints: base,
    accuracyFactor: Math.round(af * 1000) / 1000,
    difficultyFactor: df,
    completionFactor: Math.round((0.5 + 0.5 * completion) * 100) / 100,
    explanation: `${base} base × ${(af).toFixed(2)} accuracy factor × ${df} difficulty × ${(0.5 + 0.5 * completion).toFixed(2)} completion`,
  };
}

/** Star rating used on completion screens: accuracy-weighted, never speed-only. */
export function starsFor({ accuracy, completionBonus = 1 }) {
  if (completionBonus < 0.5) return 0;
  if (accuracy >= 98) return 3;
  if (accuracy >= 92) return 2;
  if (accuracy >= 85) return 1;
  return 0;
}

export function gameCatalog({ enabledIds = null } = {}) {
  return GAMES.map((g) => ({
    ...g,
    difficulties: Object.values(DIFFICULTIES),
    enabled: enabledIds ? enabledIds.includes(g.id) : true,
  }));
}
