/**
 * Content bank. All text is original to BICA TYPING STUDIO — no third-party
 * course copy is reproduced. Passages are deliberately plain ASCII prose so
 * that measurement is not distorted by exotic glyphs in foundational lessons.
 */

export const HOME_ROW_WORDS = [
  'add', 'all', 'ask', 'dad', 'fad', 'fall', 'flask', 'glad', 'had', 'half',
  'hall', 'has', 'jag', 'lad', 'lass', 'sad', 'salad', 'sash', 'shall', 'skid',
  'flak', 'flash', 'glass', 'hajj', 'kadai', 'dhal', 'lakh', 'dais',
];

export const COMMON_WORDS = [
  'the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'any', 'can', 'had', 'her',
  'was', 'one', 'our', 'out', 'day', 'get', 'has', 'him', 'his', 'how', 'man', 'new',
  'now', 'old', 'see', 'two', 'way', 'who', 'boy', 'did', 'its', 'let', 'put', 'say',
  'she', 'too', 'use', 'that', 'with', 'have', 'this', 'will', 'your', 'from', 'they',
  'know', 'want', 'been', 'good', 'much', 'some', 'time', 'very', 'when', 'come',
  'here', 'just', 'like', 'long', 'make', 'many', 'more', 'only', 'over', 'such',
  'take', 'than', 'them', 'well', 'were', 'what', 'work', 'year', 'back', 'call',
  'came', 'each', 'even', 'find', 'give', 'hand', 'high', 'keep', 'last', 'left',
  'life', 'live', 'look', 'made', 'most', 'move', 'must', 'name', 'need', 'next',
  'open', 'part', 'play', 'right', 'said', 'same', 'seem', 'show', 'side', 'tell',
  'turn', 'used', 'want', 'week', 'went', 'word', 'world', 'write', 'young',
  'office', 'report', 'record', 'letter', 'student', 'computer', 'keyboard',
  'typing', 'practice', 'accuracy', 'speed', 'morning', 'evening', 'market',
  'school', 'college', 'teacher', 'lesson', 'machine', 'account', 'balance',
  'invoice', 'payment', 'customer', 'service', 'quality', 'station', 'district',
  'document', 'printing', 'register', 'certificate', 'training', 'centre',
];

export const DIFFICULT_WORDS = [
  'acknowledgement', 'administration', 'approximately', 'bureaucracy', 'consequently',
  'correspondence', 'entrepreneur', 'extraordinary', 'infrastructure', 'maintenance',
  'necessarily', 'occasionally', 'parliamentary', 'pronunciation', 'questionnaire',
  'recommendation', 'reconciliation', 'representative', 'simultaneously',
  'straightforward', 'substantially', 'threshold', 'unfortunately', 'verification',
  'miscellaneous', 'occurrence', 'perseverance', 'rhythm', 'successful', 'tomorrow',
];

export const SENTENCES = [
  'The quick brown fox jumps over the lazy dog.',
  'A good typist looks at the screen and not at the keys.',
  'Please bring the printed register to the front desk.',
  'Accuracy matters more than speed in the first month.',
  'The class begins at ten in the morning every day.',
  'She typed the invoice and saved a copy for the office.',
  'Keep your wrists relaxed and your feet flat on the floor.',
  'Our centre opens new batches on the first Monday of each month.',
  'The student completed the practice test in four minutes.',
  'Type each word carefully and then increase your speed.',
  'The report was checked twice before it was sent to head office.',
  'A steady rhythm produces better results than a fast burst.',
  'Rest your fingers on the home row before you begin.',
  'The keyboard has five rows and many small keys.',
  'Practice for fifteen minutes a day and you will improve.',
  'He handed over the receipt and wished the customer a good day.',
  'The examination will last for five minutes only.',
  'Good posture reduces strain on the neck and shoulders.',
  'The printer is out of paper again this afternoon.',
  'Press the shift key with the little finger of the other hand.',
];

export const PARAGRAPHS = [
  'A training centre runs on small details. Registers must be filled correctly, receipts must reach the right file, and every student should be able to see how far they have come. Typing is one of those skills that quietly decides how quickly the rest of the work gets done.',
  'The morning batch begins with a short warm up on the home row. Students are asked to type slowly for two minutes without looking down at their hands. Only after that do they attempt the timed exercise, because speed without control is just noise.',
  'When you type a long document, keep your eyes a few words ahead of your fingers. This small habit reduces the pauses between words and makes the whole passage feel smoother. It also gives you time to notice an error before it grows into a sentence.',
  'A good keyboard is not expensive, but it must be clean and level. Wrists should float above the desk rather than rest on the edge, and the screen should sit at eye level so the neck stays straight. These habits matter more than the brand of the machine.',
  'Feedback is the heart of practice. A student who knows exactly which three keys are slowing them down can fix the problem in a week. A student who only knows a final score will keep repeating the same mistake for a month.',
  'The office closes the accounts on the last working day of each month. All vouchers must be signed, filed, and entered into the register before four in the afternoon. Any discrepancy should be reported to the accountant immediately.',
  'An announcement over the station loudspeaker follows a fixed pattern. First the train number, then the platform, then the expected time of arrival. Correct punctuation keeps the message clear even when the noise level is high.',
  'Practice sessions should be short and frequent. Twenty minutes in the morning and twenty in the evening will do more good than a single two hour block at the end of the week. The fingers learn through repetition, not through exhaustion.',
];

export const BUSINESS_PASSAGES = [
  'Dear Sir, We acknowledge receipt of your letter dated 12 March regarding the supply of computer accessories to our training centre. The items have been inspected and found to be in order. Please send the invoice for the same at your earliest convenience so that payment can be processed in this financial year. Yours faithfully, The Principal.',
  'Subject: Revised schedule for the evening batch. This is to inform all enrolled students that the evening batch will now commence at 6:30 pm instead of 6:00 pm with effect from next Monday. The change is required because the lab is being used for an external examination until 6:15 pm. Students are requested to note the revised timing.',
  'To Whom It May Concern, This is to certify that the bearer has completed the prescribed course of study in data entry and computer fundamentals at this centre. During the course the candidate maintained regular attendance and demonstrated consistent accuracy in typing exercises. This certificate is issued for the purpose of employment.',
  'Monthly report summary. Total enrolment for the month stood at one hundred and twelve students across four batches. Average attendance was ninety one percent. Three instructors conducted forty eight classes, and the practical lab remained available for additional practice on all working days except public holidays.',
  'Invoice particulars. Two desktop computers, four keyboards, one laser printer, and a box of continuous stationery. Delivery is to be made to the first floor laboratory before the fifteenth of this month. Payment terms are thirty days from the date of the invoice, subject to inspection of the goods on arrival.',
  'Memo. All instructors are requested to submit their batch wise progress reports by Friday afternoon. The report should list the lessons completed, the current average typing speed of each batch, and the names of any students who require additional support before the next assessment.',
];

export const REPORT_PASSAGES = [
  'A study of beginner typing performance shows that learners who are required to reach ninety five percent accuracy before increasing speed finish the beginner course sooner than those who chase speed first. The reason is simple: uncorrected errors cost more time than slow but clean typing.',
  'Data collected from practice sessions can be used to plan the next week of teaching. If four students in a batch share the same weak key, a short group drill is more efficient than four separate remedial sessions. Aggregate key statistics make that pattern visible.',
  'The centre recorded one thousand two hundred practice sessions in the last quarter. Average net speed rose from eighteen words per minute in the first week to thirty four words per minute in the twelfth week, while average accuracy improved from ninety one to ninety seven percent.',
];

export const CODE_SNIPPETS = {
  html: [
    '<div class="card">Hello</div>',
    '<p id="intro">Welcome to BICA</p>',
    '<a href="/login">Sign in</a>',
    '<input type="text" name="user">',
    '<ul><li>One</li><li>Two</li></ul>',
  ],
  css: [
    '.card { padding: 16px; }',
    'body { font-family: sans-serif; }',
    ':root { --ink: #12161c; }',
    '.grid { display: grid; gap: 12px; }',
    '@media (max-width: 640px) { .nav { display: none; } }',
  ],
  js: [
    'const total = items.length;',
    'function add(a, b) { return a + b; }',
    'if (ready) { start(); } else { wait(); }',
    'const names = rows.map(r => r.name);',
    'export default class Session { }',
    'for (let i = 0; i < n; i += 1) { sum += i; }',
  ],
};

export const SYMBOL_LINES = [
  '{} () [] <> / \\ | & * #',
  '!@#$%^&*()_+-=',
  'name@domain.co.in; phone: 033-2244',
  'a=b+c*d/e; x<y>z&q|r',
  '"quoted" (parenthesised) [bracketed]',
  '50% + 25% = 75%; #tag',
  'c:\\users\\bica\\data\\file.txt',
  'price $45.50 - tax 8.5% * 2',
];

export const NUMBER_LINES = [
  '1 2 3 4 5 6 7 8 9 0',
  '10 20 30 40 50 60 70 80 90',
  '1234 5678 9012 3456',
  '2026 2027 1998 2005 1950',
  'Phone 98300 11223 and 033 2244 5566',
  'Invoice 4471 dated 31/10/2026 total 12,450',
  'Batch 7 started 09:30 and ended 11:45',
];

export const BIGRAMS = ['th', 'he', 'in', 'er', 'an', 're', 'on', 'at', 'en', 'nd', 'ti', 'es', 'or', 'te', 'of', 'ed', 'is', 'it', 'al', 'ar'];
export const TRIGRAMS = ['the', 'and', 'ing', 'her', 'tha', 'ere', 'ent', 'hat', 'tha', 'for', 'not', 'ion', 'tio', 'ver', 'all'];

export const BAKERY_ITEMS = [
  'white bread', 'brown bread', 'milk rusk', 'cream bun', 'veg puff',
  'chicken patty', 'butter toast', 'fruit cake', 'plum cake', 'sweet roll',
  'masala biscuit', 'coconut cookie', 'tea cake', 'paneer roll', 'jam bun',
];

export const STATIONS = [
  'Asansol Junction', 'Raniganj', 'Andal', 'Durgapur', 'Barakar',
  'Chittaranjan', 'Jamtara', 'Madhupur', 'Jasidih', 'Deoghar',
  'Sitarampur', 'Kulti', 'Burnpur', 'Kalipahari', 'Barachak',
];

export const EXPEDITION_LOCATIONS = [
  'Home Base', 'Typing Meadow', 'Home Row Forest', 'Upper Ridge', 'Lower Valley',
  'Capital Peak', 'Punctuation Pass', 'Number Desert', 'Symbol Cavern', 'Summit',
];

/** Deterministic helpers used by the practice generator. */
export function pickWords(rng, n, pool = COMMON_WORDS) {
  return Array.from({ length: n }, () => rng.pick(pool)).join(' ');
}

export function buildParagraph(rng, count = 2) {
  const pool = rng.shuffle(PARAGRAPHS);
  return pool.slice(0, count).join(' ');
}
