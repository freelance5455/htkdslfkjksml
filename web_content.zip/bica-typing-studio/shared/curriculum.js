/**
 * BICA TYPING STUDIO — Curriculum
 * ---------------------------------------------------------------------------
 * Curriculum structure is CODE (reviewable, testable, versioned) while student
 * progress is DATA. A lesson is a small, focused drill of roughly 2–4 minutes.
 *
 * Progression is gated on demonstrated skill, never on clicks:
 *   - the next lesson unlocks only when the previous one is mastered
 *   - mastery = accuracy >= threshold AND netWpm >= threshold AND the whole
 *     drill was attempted AND the centre's minimum character count was met
 *
 * Thresholds default from the level table and can be overridden centre-wide by
 * the administrator (app_settings: curriculum.minAccuracy / curriculum.minWpm /
 * curriculum.requireSequentialUnlock).
 */

export const CURRICULUM_VERSION = '1.0.0';

export const LEVELS = [
  {
    level: 0, name: 'Introduction', tagline: 'Meet the machine before you race it',
    blurb: 'Keyboard anatomy, posture, hand placement and the F/J anchors. No speed target — the goal is correct habits.',
    defaultMinAccuracy: 90, defaultMinWpm: 0,
  },
  {
    level: 1, name: 'Beginner', tagline: 'Home row, one finger at a time',
    blurb: 'The eight home-row keys and the two index reach keys, drilled finger by finger, then combined into real words.',
    defaultMinAccuracy: 95, defaultMinWpm: 0,
  },
  {
    level: 2, name: 'Elementary', tagline: 'Upper row, lower row, real words',
    blurb: 'Adds the upper and lower letter rows and builds word-level fluency on short common words.',
    defaultMinAccuracy: 95, defaultMinWpm: 0,
  },
  {
    level: 3, name: 'Intermediate', tagline: 'Capitals, punctuation, digits',
    blurb: 'Completes the alphabet, introduces Shift and capitals, punctuation, and the number row.',
    defaultMinAccuracy: 95, defaultMinWpm: 12,
  },
  {
    level: 4, name: 'Advanced', tagline: 'Fluency on real content',
    blurb: 'Paragraphs, difficult vocabulary, bigram and trigram patterns, symbols and mixed content.',
    defaultMinAccuracy: 96, defaultMinWpm: 20,
  },
  {
    level: 5, name: 'Professional', tagline: 'Office-standard output',
    blurb: 'Business correspondence, reports and timed examination conditions at professional accuracy.',
    defaultMinAccuracy: 97, defaultMinWpm: 28,
  },
  {
    level: 6, name: 'Expert', tagline: 'Speed with a clean record',
    blurb: 'High-speed accuracy, complex punctuation, numerical strings and accuracy under time pressure.',
    defaultMinAccuracy: 98, defaultMinWpm: 40,
  },
];

const L0 = [
  {
    title: 'This is a keyboard', keys: ['a', 's', 'd', 'f', 'j', 'k', 'l'],
    objective: 'Recognise the main areas of a keyboard and name them without looking.',
    explanation: 'A keyboard has a main typing area, a number pad, function keys and modifier keys. You will use the main area almost all the time. Your left hand covers the left side, your right hand the right side, and your thumbs work the space bar.',
    drills: ['asdf jkl asdf jkl', 'fff jjj fff jjj asdf jkl'],
  },
  {
    title: 'Sit correctly', keys: ['a', 's', 'd', 'f', 'j', 'k', 'l'],
    objective: 'Adopt a posture that you can hold for a full practice session.',
    explanation: 'Sit square to the keyboard with both feet flat. Keep your back straight, shoulders relaxed and elbows close to your body. The screen should be roughly at eye level. Wrists float above the desk — they do not rest on it.',
    drills: ['asdf jkl asdf jkl', 'aaaa ssss dddd ffff'],
  },
  {
    title: 'Find F and J without looking', keys: ['f', 'j'],
    objective: 'Locate the home position by touch using the raised bumps on F and J.',
    explanation: 'Feel the small raised bar on the F key and the J key. Place your left index finger on F and your right index finger on J. From those two anchors, every other key is a short reach away.',
    drills: ['fj fj fjf jfj', 'ff jj fj jf ff jj'],
  },
  {
    title: 'The finger map', keys: ['a', 's', 'd', 'f', 'j', 'k', 'l', ';'],
    objective: 'Assign each home-row key to the correct finger.',
    explanation: 'Left little finger on A, ring on S, middle on D, index on F. Right index on J, middle on K, ring on L, little on semicolon. Each finger owns a column of keys and returns home after every reach.',
    drills: ['asdf jkl; asdf jkl;', 'aa ss dd ff jj kk ll ;;'],
  },
  {
    title: 'Your first words', keys: ['a', 'd', 'f', 'j', 'k', 'l', 's'],
    objective: 'Produce real words using only the home row.',
    explanation: 'Short words are enough to prove the technique works. Keep your eyes on the screen and let the fingers find the keys.',
    drills: ['ask dad fall glad', 'add all lads salad'],
  },
];

const L1 = [
  {
    title: 'Left hand: index finger', keys: ['f', 'g', 'r', 't', 'v', 'b'],
    objective: 'Reach the left index column without moving the whole hand.',
    explanation: 'The left index finger owns F and G on the home row, and reaches up to R and T and down to V and B. Only the finger moves; the wrist stays still.',
    drills: ['fff ggg fg fg', 'ff gg fg gf ffg ggf'],
  },
  {
    title: 'Right hand: index finger', keys: ['j', 'h', 'y', 'u', 'n', 'm'],
    objective: 'Reach the right index column while keeping the J anchor.',
    explanation: 'The right index finger owns J and H, reaches up to Y and U and down to N and M. Return to J after every reach so the anchor is never lost.',
    drills: ['jjj hhh jh jh', 'jj hh jh hj jjh hhj'],
  },
  {
    title: 'Left hand: middle and ring', keys: ['d', 'e', 'c', 's', 'w', 'x'],
    objective: 'Control the left middle and ring fingers.',
    explanation: 'The middle finger types D, reaches up to E and down to C. The ring finger types S, reaches up to W and down to X. Small, deliberate movements.',
    drills: ['ddd eee ccc', 'sss www xxx'],
  },
  {
    title: 'Right hand: middle and ring', keys: ['k', 'i', ',', 'l', 'o', '.'],
    objective: 'Control the right middle and ring fingers.',
    explanation: 'The middle finger types K, reaches up to I and down to the comma. The ring finger types L, reaches up to O and down to the full stop.',
    drills: ['kkk iii ,,,', 'lll ooo ...'],
  },
  {
    title: 'Both little fingers', keys: ['a', 'q', 'z', 'p', ';', '/'],
    objective: 'Use the little fingers, which do the most reaching.',
    explanation: 'The left little finger owns A, Q and Z. The right little finger owns the semicolon, P and the slash. These fingers are weaker, so they need deliberate practice.',
    drills: ['aaa qqq zzz', ';;; ppp ///'],
  },
  {
    title: 'Home-row combinations', keys: ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';'],
    objective: 'Combine all eight fingers without losing the home position.',
    explanation: 'Type each group twice, then return to the anchor without looking down. Speed is irrelevant here; the anchor is everything.',
    drills: ['asdf jkl; asdf jkl;', 'fg hj fg hj; sad lad; half glad'],
  },
  {
    title: 'Home-row words', keys: ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
    objective: 'Type short words with clean finger returns.',
    explanation: 'These words use only the home row, so any error is a technique error, not a knowledge error.',
    drills: ['ask dad add all fall glad', 'half salad shall flash glass'],
  },
  {
    title: 'Beginner checkpoint', keys: ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
    objective: 'Demonstrate home-row mastery before moving to the upper row.',
    explanation: 'This is a longer mixed drill. Aim for a steady rhythm and zero uncorrected errors.',
    drills: ['asdf jkl; fghj kl; asdf jkl; fghj', 'a lad had a flask; dad shall add salad'],
  },
];

const L2 = [
  {
    title: 'Upper row: left hand', keys: ['q', 'w', 'e', 'r', 't'],
    objective: 'Reach the upper row with the left hand and return home.',
    explanation: 'Every upper-row key is one row above home. Keep the wrist level and reach with the finger, not the arm.',
    drills: ['qqq www eee rrr ttt', 'we were wet tree qwert'],
  },
  {
    title: 'Upper row: right hand', keys: ['y', 'u', 'i', 'o', 'p'],
    objective: 'Reach the upper row with the right hand and return home.',
    explanation: 'Y and U belong to the index finger, I to the middle, O to the ring, P to the little finger.',
    drills: ['yyy uuu iii ooo ppp', 'you pour pretty oil up'],
  },
  {
    title: 'Lower row: left hand', keys: ['z', 'x', 'c', 'v', 'b'],
    objective: 'Reach downward with the left hand without dropping the wrist.',
    explanation: 'Reaching down is harder than reaching up. Curl the finger slightly and pull it back to home immediately.',
    drills: ['zzz xxx ccc vvv bbb', 'zebra box carve verb'],
  },
  {
    title: 'Lower row: right hand', keys: ['n', 'm', ',', '.', '/'],
    objective: 'Reach downward with the right hand, including the comma and full stop.',
    explanation: 'N and M are index-finger keys. The comma sits under the middle finger, the full stop under the ring finger.',
    drills: ['nnn mmm nnn mmm', 'name, money, moon. noon.'],
  },
  {
    title: 'All letters, first pass', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Type a word containing any letter of the alphabet.',
    explanation: 'You now know every letter position. The remaining work is muscle memory and consistency.',
    drills: ['the quick brown fox jumps', 'pack my box with five jugs'],
  },
  {
    title: 'Common letter blends', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Type frequent two-letter combinations as single movements.',
    explanation: 'Frequent pairs like th, he, in and er should feel like one motion. Repeated pairs build that shortcut.',
    drills: ['the then there them', 'in into inner ink'],
  },
  {
    title: 'Common words I', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Build speed on the highest-frequency English words.',
    explanation: 'These words make up a large part of everyday text. Recognising them as whole units is faster than reading letter by letter.',
    drills: ['the and for are but not you all', 'any can had her was one our out'],
  },
  {
    title: 'Common words II', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Extend word-level fluency to longer common words.',
    explanation: 'Keep the rhythm even. A steady pace beats a fast start that collapses halfway.',
    drills: ['that with have this will your', 'from they know want been good'],
  },
  {
    title: 'Short sentences', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Type complete sentences including the space bar and full stop.',
    explanation: 'The space bar is pressed with either thumb. Do not look down — the thumbs learn quickly.',
    drills: ['The class begins at ten.', 'She typed the letter.'],
  },
  {
    title: 'Elementary checkpoint', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Hold accuracy across a longer mixed passage.',
    explanation: 'This drill mixes all three letter rows. If accuracy drops at the end, the cause is usually tension.',
    drills: ['Practice for fifteen minutes a day and you will improve.', 'A steady rhythm produces better results than a fast burst.'],
  },
];

const L3 = [
  {
    title: 'The Shift key', keys: ['Shift'],
    objective: 'Produce capital letters with the opposite-hand Shift key.',
    explanation: 'Use the little finger of the hand that is NOT typing the letter. Left hand Shift for right-hand letters, right hand Shift for left-hand letters.',
    drills: ['Ac As Ad Af', 'Ja Js Jd Jf'],
  },
  {
    title: 'Capitals in words', keys: ['Shift'],
    objective: 'Type proper nouns without stopping the rhythm.',
    explanation: 'The Shift press and the letter press should feel simultaneous. Do not hold Shift longer than necessary.',
    drills: ['Asansol Durgapur Kolkata', 'Rina Amit Sunita Bica'],
  },
  {
    title: 'Sentence capitals', keys: ['Shift'],
    objective: 'Start every sentence with a capital automatically.',
    explanation: 'Capitalisation is a habit, not a decision. Train it now so you never have to correct it later.',
    drills: ['The report is ready. Please check it.', 'Our centre opens at nine. Bring your ID.'],
  },
  {
    title: 'Comma and full stop', keys: [',', '.'],
    objective: 'Punctuate at speed with the correct fingers.',
    explanation: 'The comma belongs to the right middle finger and the full stop to the right ring finger. Never reach across with the index finger.',
    drills: ['One, two, three. Four, five.', 'Ready, set, go. Wait, stop.'],
  },
  {
    title: 'Question and colon', keys: ['?', ':'],
    objective: 'Use Shift with punctuation marks correctly.',
    explanation: 'The question mark needs Shift with the right little finger; the colon needs Shift with the right little finger too, on the semicolon key.',
    drills: ['Are you ready? Yes.', 'Note: bring the file.'],
  },
  {
    title: 'Apostrophe and quotes', keys: ["'", '"'],
    objective: 'Type contractions and quoted text accurately.',
    explanation: 'The apostrophe sits on the home row under the right little finger. The quotation mark is its Shift pair.',
    drills: ["It's the centre's file.", 'She said "ready" twice.'],
  },
  {
    title: 'Number row: 1 to 5', keys: ['1', '2', '3', '4', '5'],
    objective: 'Reach the left half of the number row and return home.',
    explanation: 'Each number is directly above a letter column: 1 above Q, 2 above W, 3 above E, 4 above R, 5 above T.',
    drills: ['12345 54321', '11 22 33 44 55'],
  },
  {
    title: 'Number row: 6 to 0', keys: ['6', '7', '8', '9', '0'],
    objective: 'Reach the right half of the number row and return home.',
    explanation: '6 sits above Y and is typed with the right index. 7, 8, 9 and 0 belong to the right index, middle, ring and little fingers.',
    drills: ['67890 09876', '66 77 88 99 00'],
  },
  {
    title: 'Numbers inside sentences', keys: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
    objective: 'Keep rhythm when switching between letters and digits.',
    explanation: 'The row change is the hard part. Return to home after every digit, even when the next character is another digit.',
    drills: ['Batch 7 starts at 10:30.', 'Invoice 4471 was paid on 12 March.'],
  },
  {
    title: 'Intermediate checkpoint', keys: ['Shift', ',', '.', '?', ':', "'", '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
    objective: 'Combine capitals, punctuation and digits at 12 words per minute.',
    explanation: 'This is the first lesson with a speed target. If accuracy falls below the threshold, repeat the drill rather than pushing on.',
    drills: ["Rina's report (Batch 4) is due on 15 June.", 'Please send 12 copies to Room 3 by 5 pm.'],
  },
];

const L4 = [
  {
    title: 'Paragraph rhythm', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Hold accuracy across a full paragraph.',
    explanation: 'Long text exposes tension. Every few lines, check that your shoulders are still down and your wrists are still floating.',
    drills: ['A training centre runs on small details. Registers must be filled correctly, receipts must reach the right file, and every student should be able to see how far they have come.'],
  },
  {
    title: 'Difficult vocabulary', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Type long, low-frequency words without stalling.',
    explanation: 'Break a long word into syllables in your head, but type it in one flow. Do not re-read the word after every letter.',
    drills: ['acknowledgement administrative bureaucratic', 'infrastructure recommendation verification'],
  },
  {
    title: 'Bigram training', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Turn the twenty most common letter pairs into single movements.',
    explanation: 'The most valuable typing improvement available to you is smoothness on th, he, in, er, an and re. Drill them as pairs, not as letters.',
    drills: ['th he in er an re on at en nd', 'ti es or te of ed is it al ar'],
  },
  {
    title: 'Trigram training', keys: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    objective: 'Automate the most common three-letter groups.',
    explanation: 'Once three-letter groups are automatic, most English words type themselves. Keep the same even rhythm throughout.',
    drills: ['the and ing her tha ere', 'ent hat for not ion tio'],
  },
  {
    title: 'Number-row mastery', keys: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
    objective: 'Type realistic numeric strings at working speed.',
    explanation: 'Account numbers and dates are the most common numeric task in an office. Group digits in fours mentally.',
    drills: ['1234 5678 9012 3456', 'Invoice 4471 dated 31/10/2026 total 12,450'],
  },
  {
    title: 'Symbols and brackets', keys: ['(', ')', '[', ']', '{', '}', '@', '#', '%', '&', '*', '$'],
    objective: 'Reach the shifted symbol layer without losing accuracy.',
    explanation: 'Symbols are simply Shift plus a punctuation key. The difficulty is the Shift timing, not the key position.',
    drills: ['{ } ( ) [ ] < > / \\', 'name@domain.co.in 50% #tag'],
  },
  {
    title: 'Mixed content', keys: 'abcdefghijklmnopqrstuvwxyz'.split('').concat(['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '@', '.', ',', '-']),
    objective: 'Move between prose, numbers and symbols in one flow.',
    explanation: 'Mixed content is what real office work looks like. There is no pattern to ride — only technique.',
    drills: ['Email rina.s@bica.co.in or call 98300 11223 before 5 pm.', 'Room 12, 2nd floor: fee Rs 1,450 (approx).'],
  },
  {
    title: 'Advanced checkpoint', keys: 'abcdefghijklmnopqrstuvwxyz'.split('').concat(['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', ',', '.', '-', ':', '(', ')']),
    objective: 'Hold 96% accuracy at 20 words per minute.',
    explanation: 'This drill is scored. Read it once before you start typing so your eyes stay ahead of your fingers.',
    drills: ['The office closes the accounts on the last working day of each month. All vouchers must be signed, filed, and entered into the register before four in the afternoon.'],
  },
];

const L5 = [
  {
    title: 'Business letter', keys: 'all',
    objective: 'Type a formal business letter with correct punctuation and capitals.',
    explanation: 'Formal correspondence has a fixed shape. Accuracy on capitalisation and commas matters more than raw speed.',
    drills: ['Dear Sir, We acknowledge receipt of your letter dated 12 March regarding the supply of computer accessories to our training centre.'],
  },
  {
    title: 'Office memorandum', keys: 'all',
    objective: 'Type an internal memo at professional accuracy.',
    explanation: 'Memos are short and factual. Keep the layout clean and never leave a sentence uncapitalised.',
    drills: ['Memo. All instructors are requested to submit their batch wise progress reports by Friday afternoon. The report should list the lessons completed.'],
  },
  {
    title: 'Monthly report', keys: 'all',
    objective: 'Sustain accuracy across report-style prose with figures.',
    explanation: 'Reports mix prose and numbers. Slow slightly at each figure and return to your rhythm afterwards.',
    drills: ['Total enrolment for the month stood at 112 students across four batches. Average attendance was 91 percent. Three instructors conducted 48 classes.'],
  },
  {
    title: 'Long-form transcription', keys: 'all',
    objective: 'Transcribe three or more sentences continuously without a break in rhythm.',
    explanation: 'Transcription is the professional test: no stopping, no looking down, no drifting accuracy at the end.',
    drills: ['A good keyboard is not expensive, but it must be clean and level. Wrists should float above the desk rather than rest on the edge, and the screen should sit at eye level so the neck stays straight.'],
  },
  {
    title: 'Professional timed examination', keys: 'all',
    objective: 'Achieve 97% accuracy at 28 words per minute under test conditions.',
    explanation: 'This is a scored examination drill. Backspace is available, but each correction costs time and accuracy — aim to type it right the first time.',
    drills: ['An announcement over the station loudspeaker follows a fixed pattern. First the train number, then the platform, then the expected time of arrival. Correct punctuation keeps the message clear even when the noise level is high.'],
    exam: true, durationMs: 180000,
  },
];

const L6 = [
  {
    title: 'Speed with a clean record', keys: 'all',
    objective: 'Raise speed while holding 98% accuracy.',
    explanation: 'At this level the limiting factor is error rate, not finger speed. Push the pace only while accuracy stays above the threshold.',
    drills: ['Practice sessions should be short and frequent. Twenty minutes in the morning and twenty in the evening will do more good than a single two hour block.'],
  },
  {
    title: 'Advanced punctuation', keys: 'all',
    objective: 'Handle nested punctuation, quotes and dashes without slips.',
    explanation: 'Complex punctuation is a Shift-timing problem. Keep the little fingers relaxed; they do most of the work here.',
    drills: ['He said, "Send the file (the revised one, not the first draft) to the office by 4:30 pm — no later."'],
  },
  {
    title: 'Numerical strings', keys: 'all',
    objective: 'Type dense numeric and alphanumeric strings accurately.',
    explanation: 'Account numbers, dates and codes punish a single slip. Accuracy first; speed follows from repetition.',
    drills: ['A/C 4471-8820-1193 dated 31/10/2026; ref BICA/TYP/2026/0417; amount Rs 12,450.75'],
  },
  {
    title: 'Expert examination', keys: 'all',
    objective: 'Pass the final scored examination at 98% accuracy and 40 words per minute.',
    explanation: 'The final drill. Nothing new is introduced here — this is a test of everything you have practised.',
    drills: ['Data collected from practice sessions can be used to plan the next week of teaching. If four students in a batch share the same weak key, a short group drill is more efficient than four separate remedial sessions. Aggregate key statistics make that pattern visible.'],
    exam: true, durationMs: 300000,
  },
];

const GROUPS = [
  { level: 0, list: L0 },
  { level: 1, list: L1 },
  { level: 2, list: L2 },
  { level: 3, list: L3 },
  { level: 4, list: L4 },
  { level: 5, list: L5 },
  { level: 6, list: L6 },
];

function buildLessons() {
  const out = [];
  for (const group of GROUPS) {
    const meta = LEVELS[group.level];
    group.list.forEach((raw, i) => {
      const order = i + 1;
      const keys = raw.keys === 'all' ? 'abcdefghijklmnopqrstuvwxyz'.split('') : raw.keys;
      out.push({
        id: `L${group.level}-${String(order).padStart(2, '0')}`,
        level: group.level,
        levelName: meta.name,
        order,
        orderIndex: out.length,
        title: raw.title,
        objective: raw.objective,
        explanation: raw.explanation,
        keys,
        drills: raw.drills,
        minAccuracy: raw.minAccuracy ?? meta.defaultMinAccuracy,
        minWpm: raw.minWpm ?? meta.defaultMinWpm,
        estMinutes: 3,
        isExam: Boolean(raw.exam),
        durationMs: raw.durationMs ?? null,
        curriculumVersion: CURRICULUM_VERSION,
      });
    });
  }
  return out;
}

export const LESSONS = buildLessons();
export const LESSON_BY_ID = new Map(LESSONS.map((l) => [l.id, l]));
export const TOTAL_LESSONS = LESSONS.length;

export function getLesson(id) { return LESSON_BY_ID.get(id) ?? null; }
export function lessonsForLevel(level) { return LESSONS.filter((l) => l.level === level); }
export function levelsWithLessons() {
  return LEVELS.map((meta) => ({ ...meta, lessons: lessonsForLevel(meta.level) }));
}
export function firstLesson() { return LESSONS[0]; }
export function nextLesson(id) {
  const i = LESSONS.findIndex((l) => l.id === id);
  return i >= 0 ? LESSONS[i + 1] ?? null : null;
}

/** Effective thresholds for a lesson, after centre-wide overrides. */
export function effectiveThresholds(lesson, settings = {}) {
  const accOverride = settings['curriculum.minAccuracy'] != null ? Number(settings['curriculum.minAccuracy']) : null;
  const wpmOverride = settings['curriculum.minWpm'] != null ? Number(settings['curriculum.minWpm']) : null;
  return {
    minAccuracy: Number.isFinite(accOverride) && accOverride > 0 ? accOverride : lesson.minAccuracy,
    minWpm: Number.isFinite(wpmOverride) && wpmOverride >= 0 ? wpmOverride : lesson.minWpm,
    minChars: Number(settings['curriculum.minChars'] ?? 0) || 0,
  };
}

/**
 * Judge one attempt. Pure function — the server calls it with stored settings,
 * the browser calls it for instant feedback, and both must agree.
 */
export function evaluateAttempt({ lesson, metrics, settings = {}, drillLength = 0 }) {
  const t = effectiveThresholds(lesson, settings);
  const reasons = [];
  const accuracy = Number(metrics.accuracy ?? 0);
  const netWpm = Number(metrics.netWpm ?? 0);
  const committed = Number(metrics.committedChars ?? metrics.typedChars ?? 0);

  if (accuracy + 1e-9 < t.minAccuracy) reasons.push(`Accuracy ${accuracy.toFixed(1)}% is below the ${t.minAccuracy}% requirement.`);
  if (t.minWpm > 0 && netWpm + 1e-9 < t.minWpm) reasons.push(`Net speed ${netWpm.toFixed(1)} WPM is below the ${t.minWpm} WPM requirement.`);
  if (drillLength > 0 && committed < Math.ceil(drillLength * 0.6)) reasons.push('Most of the drill was not attempted.');
  if (t.minChars > 0 && committed < t.minChars) reasons.push(`At least ${t.minChars} characters are required.`);
  if (Number(metrics.uncorrectedErrors ?? 0) > 0) reasons.push(`${metrics.uncorrectedErrors} character(s) were left incorrect.`);

  return {
    passed: reasons.length === 0,
    reasons,
    thresholds: t,
    metrics: { accuracy, netWpm, committed },
  };
}

/**
 * Compute unlock state for the whole curriculum from stored progress.
 * @param {Record<string,{mastered:boolean,best_accuracy:number,best_wpm:number}>} progressById
 * @param {object} settings
 * @returns {{lessons:Array, unlockedCount:number, masteredCount:number, currentLesson:object|null, nextLesson:object|null}}
 */
export function buildProgressMap(progressById = {}, settings = {}) {
  const sequential = settings['curriculum.requireSequentialUnlock'] !== false
    && settings['curriculum.requireSequentialUnlock'] !== 'false';
  let previousMastered = true;
  const rows = [];
  for (const lesson of LESSONS) {
    const p = progressById[lesson.id];
    const mastered = Boolean(p?.mastered);
    const unlocked = sequential ? (lesson.orderIndex === 0 || previousMastered) : true;
    rows.push({
      ...lesson,
      mastered,
      unlocked,
      attempts: p?.attempts ?? 0,
      bestAccuracy: p?.best_accuracy ?? 0,
      bestWpm: p?.best_wpm ?? 0,
      lastAttemptAt: p?.last_attempt_at ?? null,
      thresholds: effectiveThresholds(lesson, settings),
    });
    previousMastered = mastered;
  }
  const current = rows.find((r) => r.unlocked && !r.mastered) ?? null;
  return {
    lessons: rows,
    unlockedCount: rows.filter((r) => r.unlocked).length,
    masteredCount: rows.filter((r) => r.mastered).length,
    currentLesson: current,
    nextLesson: current ? nextLesson(current.id) : null,
  };
}
