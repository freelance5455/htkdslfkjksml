/**
 * BICA TYPING STUDIO — Adaptive learning engine (deterministic)
 * ---------------------------------------------------------------------------
 * This is deliberately NOT labelled "AI". It is a transparent rule engine over
 * the student's own stored keystroke data. Every recommendation can be traced
 * back to the numbers that produced it, which is what an instructor needs when
 * a student asks "why this exercise?".
 *
 * Inputs (all from the database, never invented):
 *   keyStats  : [{ key, attempts, errors, total_interval_ms, intervals }]
 *   sessions  : recent typing_sessions rows, newest first
 *   lessons   : rows from curriculum.buildProgressMap()
 *
 * Output: an ordered list of recommendations, each with the evidence that
 * triggered it, plus a plain-language diagnosis of the student's bottleneck.
 */

const PUNCTUATION = [';', ':', ',', '.', "'", '"', '?', '!', '-', '(', ')', '[', ']', '/', '@'];
const DIGITS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];

const MIN_ATTEMPTS_FOR_CONFIDENCE = 12;

function pct(n) { return Math.round(n * 10) / 10; }

/** Rank keys by measured difficulty: error rate first, then slowness. */
export function rankWeakKeys(keyStats = [], { minAttempts = MIN_ATTEMPTS_FOR_CONFIDENCE, limit = 8 } = {}) {
  const rows = keyStats
    .filter((k) => (k.attempts ?? 0) >= minAttempts)
    .map((k) => {
      const attempts = Number(k.attempts) || 0;
      const errors = Number(k.errors) || 0;
      const avgInterval = k.intervals ? Number(k.total_interval_ms || 0) / Number(k.intervals) : 0;
      return {
        key: k.key,
        attempts,
        errors,
        errorRate: attempts ? pct((errors / attempts) * 100) : 0,
        avgIntervalMs: Math.round(avgInterval),
      };
    });

  if (rows.length === 0) return [];

  // A key is "slow" relative to the student's own median rhythm, not an
  // absolute threshold, so the ranking works for both 8 and 80 WPM students.
  const intervals = rows.map((r) => r.avgIntervalMs).filter((v) => v > 0).sort((a, b) => a - b);
  const median = intervals.length ? intervals[Math.floor(intervals.length / 2)] : 0;

  return rows
    .map((r) => ({
      ...r,
      slowness: median > 0 && r.avgIntervalMs > 0 ? pct((r.avgIntervalMs / median - 1) * 100) : 0,
      severity: pct(r.errorRate * 2.5 + Math.max(0, (median > 0 && r.avgIntervalMs ? (r.avgIntervalMs / median - 1) * 100 : 0)) * 0.35),
    }))
    .sort((a, b) => b.severity - a.severity || b.errorRate - a.errorRate)
    .slice(0, limit);
}

function groupErrorRate(keys, keyStats) {
  const map = new Map(keyStats.map((k) => [k.key, k]));
  let attempts = 0;
  let errors = 0;
  for (const key of keys) {
    const row = map.get(key);
    if (!row) continue;
    attempts += Number(row.attempts) || 0;
    errors += Number(row.errors) || 0;
  }
  return attempts >= MIN_ATTEMPTS_FOR_CONFIDENCE ? { attempts, errors, rate: pct((errors / attempts) * 100) } : null;
}

/** Trend across the last N sessions: positive means improving. */
export function trend(sessions = [], field = 'net_wpm', n = 8) {
  const rows = sessions.slice(0, n).map((s) => Number(s[field])).filter((v) => Number.isFinite(v));
  if (rows.length < 4) return { slope: 0, delta: 0, reliable: false };
  const half = Math.floor(rows.length / 2);
  const recent = rows.slice(0, half);
  const older = rows.slice(half);
  const mean = (a) => a.reduce((x, y) => x + y, 0) / a.length;
  const delta = mean(recent) - mean(older);
  return { slope: pct(delta), delta: pct(delta), reliable: true };
}

/**
 * @returns {{diagnosis:object, recommendations:Array}}
 */
export function recommend({ keyStats = [], sessions = [], lessons = [], settings = {} } = {}) {
  const weak = rankWeakKeys(keyStats);
  const recent = sessions.slice(0, 12);
  const wpmTrend = trend(recent, 'net_wpm');
  const accTrend = trend(recent, 'accuracy');
  const recommendations = [];

  const avg = (field) => (recent.length
    ? recent.reduce((a, s) => a + Number(s[field] || 0), 0) / recent.length
    : 0);
  const avgWpm = pct(avg('net_wpm'));
  const avgAcc = pct(avg('accuracy'));
  const punctuation = groupErrorRate(PUNCTUATION, keyStats);
  const digits = groupErrorRate(DIGITS, keyStats);

  // ---- 1. accuracy-first rule (the brief's explicit example) --------------
  if (recent.length >= 3 && avgWpm >= 25 && avgAcc < 90) {
    recommendations.push({
      type: 'accuracy',
      priority: 1,
      title: 'Consolidate accuracy before pushing speed',
      reason: `Your recent average is ${avgWpm} WPM at ${avgAcc}% accuracy. At this accuracy roughly 1 in ${Math.max(2, Math.round(100 / Math.max(1, 100 - avgAcc)))} keys is wrong, and each correction costs more time than slow typing would.`,
      action: { kind: 'practice', preset: 'accuracy-drill', durationMs: 120000 },
    });
  }

  // ---- 2. weak-key targeting ---------------------------------------------
  if (weak.length > 0) {
    const top = weak.slice(0, 3);
    const keyList = top.map((k) => k.key === ' ' ? 'Space' : k.key);
    recommendations.push({
      type: 'weak-keys',
      priority: avgAcc < 90 ? 2 : 1,
      title: `Targeted drill: ${keyList.join(', ')}`,
      reason: top
        .map((k) => `${k.key === ' ' ? 'Space' : `"${k.key}"`} is wrong ${k.errorRate}% of the time over ${k.attempts} presses${k.avgIntervalMs ? ` and takes ${k.avgIntervalMs} ms on average` : ''}`)
        .join('; ') + '.',
      action: { kind: 'practice', preset: 'weak-keys', keys: top.map((k) => k.key), durationMs: 120000 },
    });
  }

  // ---- 3. punctuation / number-row diagnostics ---------------------------
  if (punctuation && punctuation.rate >= 6) {
    recommendations.push({
      type: 'punctuation',
      priority: 2,
      title: 'Punctuation drill',
      reason: `Punctuation keys show a ${punctuation.rate}% error rate across ${punctuation.attempts} presses.`,
      action: { kind: 'practice', preset: 'punctuation', durationMs: 120000 },
    });
  }
  if (digits && digits.rate >= 8) {
    recommendations.push({
      type: 'numbers',
      priority: 2,
      title: 'Number-row drill',
      reason: `Number keys show a ${digits.rate}% error rate across ${digits.attempts} presses.`,
      action: { kind: 'practice', preset: 'numbers', durationMs: 120000 },
    });
  }

  // ---- 4. next curriculum lesson -----------------------------------------
  const current = lessons.find((l) => l.unlocked && !l.mastered);
  if (current) {
    recommendations.push({
      type: 'lesson',
      priority: avgAcc >= 90 || recent.length < 3 ? 1 : 3,
      title: `Continue the course: ${current.id} — ${current.title}`,
      reason: `Level ${current.level} (${current.levelName}), lesson ${current.order} of ${lessons.filter((l) => l.level === current.level).length}. Requirement: ${current.thresholds?.minAccuracy ?? current.minAccuracy}% accuracy${(current.thresholds?.minWpm ?? current.minWpm) > 0 ? ` and ${current.thresholds?.minWpm ?? current.minWpm} WPM` : ''}.`,
      action: { kind: 'lesson', lessonId: current.id },
    });
  } else if (lessons.length > 0) {
    recommendations.push({
      type: 'complete',
      priority: 3,
      title: 'Curriculum complete — maintain with challenges',
      reason: 'Every lesson currently available to you is mastered. Use the daily challenge and the arcade to hold your level.',
      action: { kind: 'challenge', challenge: 'daily' },
    });
  }

  // ---- 5. speed work only when accuracy is already good -----------------
  if (recent.length >= 5 && avgAcc >= 96 && wpmTrend.reliable && Math.abs(wpmTrend.delta) < 1.5) {
    recommendations.push({
      type: 'speed',
      priority: 2,
      title: 'Speed plateau: add short timed bursts',
      reason: `Accuracy is strong at ${avgAcc}% and speed has been flat (${wpmTrend.delta > 0 ? '+' : ''}${wpmTrend.delta} WPM across your last sessions). Try 60-second timed runs instead of longer ones.`,
      action: { kind: 'practice', preset: 'timed-60', durationMs: 60000 },
    });
  }

  // ---- 6. rhythm ---------------------------------------------------------
  const consistency = recent.length
    ? recent.reduce((a, s) => a + Number(s.consistency || 0), 0) / recent.length
    : 0;
  if (recent.length >= 4 && consistency > 0 && consistency < 55) {
    recommendations.push({
      type: 'rhythm',
      priority: 2,
      title: 'Build an even rhythm',
      reason: `Your consistency score is ${pct(consistency)}%, which means bursts followed by long pauses. Rhythm Keys and 30-second drills help more than long passages right now.`,
      action: { kind: 'game', gameId: 'rhythm-keys' },
    });
  }

  // ---- 7. arcade, only when it serves the goal ---------------------------
  if (avgAcc >= 90 && weak.length > 0) {
    recommendations.push({
      type: 'game',
      priority: 4,
      title: 'Practise the weak keys in the arcade',
      reason: 'Games now scope their keys to your current lesson level, so arcade time reinforces the same material.',
      action: { kind: 'game', gameId: 'falling-letters' },
    });
  }

  const primary = recommendations.sort((a, b) => a.priority - b.priority)[0] ?? null;

  const diagnosis = {
    sessionsAnalysed: recent.length,
    avgWpm,
    avgAcc,
    wpmTrend: wpmTrend.delta,
    accuracyTrend: accTrend.delta,
    consistency: pct(consistency),
    weakKeys: weak,
    bottleneck: avgAcc < 90 && avgWpm >= 25 ? 'accuracy'
      : consistency > 0 && consistency < 55 ? 'rhythm'
        : weak.length > 0 ? 'specific keys'
          : 'speed',
  };

  return { diagnosis, recommendations: recommendations.sort((a, b) => a.priority - b.priority) };
}

/**
 * Build drill text that concentrates on the given weak keys while staying real
 * English: words are drawn from the bank, then spliced so the target keys are
 * over-represented. Deterministic for a given seed.
 */
export function buildWeakKeyDrill(keys, rng, words = []) {
  const targets = keys.filter((k) => k && k !== ' ').slice(0, 3);
  if (targets.length === 0) return '';
  const bucket = targets.map((k) => []);
  for (const word of words) {
    for (const k of targets) {
      if (word.toLowerCase().includes(k.toLowerCase())) bucket[targets.indexOf(k)].push(word);
    }
  }
  const out = [];
  for (let round = 0; round < 14; round += 1) {
    const i = round % targets.length;
    const pool = bucket[i];
    if (pool.length === 0) continue;
    out.push(rng.pick(pool));
    if (round % 4 === 3) out.push(rng.pick(words));
  }
  // interleave single-key bursts so the target key is unavoidable
  const bursts = targets.map((k) => `${k}${k}${k}`);
  return `${bursts.join(' ')} ${out.join(' ')}`.trim();
}
