/**
 * Practice text generation. Runs on the server so the target text is
 * authoritative (the client cannot shorten it to inflate WPM).
 */
import { seeded } from './rng.js';
import { buildWeakKeyDrill } from './adaptive.js';
import {
  COMMON_WORDS, HOME_ROW_WORDS, DIFFICULT_WORDS, SENTENCES, PARAGRAPHS,
  BUSINESS_PASSAGES, REPORT_PASSAGES, CODE_SNIPPETS, SYMBOL_LINES,
  NUMBER_LINES, BIGRAMS, TRIGRAMS, pickWords,
} from './textbank.js';

export const PRESETS = [
  { id: 'random-words', label: 'Random words', group: 'Words', description: 'A fresh shuffle of the common English word pool each time.' },
  { id: 'common-words', label: 'Common vocabulary', group: 'Words', description: 'The highest-frequency English words, in normal proportions.' },
  { id: 'home-row', label: 'Home-row words', group: 'Words', description: 'Words reachable without leaving the home row — good for absolute beginners.' },
  { id: 'difficult-words', label: 'Difficult words', group: 'Words', description: 'Long, low-frequency vocabulary for advanced fluency.' },
  { id: 'bigrams', label: 'Bigram drill', group: 'Patterns', description: 'The twenty most common letter pairs, grouped twenty at a time.' },
  { id: 'trigrams', label: 'Trigram drill', group: 'Patterns', description: 'Three-letter groups that make up most of English prose.' },
  { id: 'weak-keys', label: 'Weak-key drill', group: 'Personalised', description: 'Generated from your own measured error rates. Requires recorded practice first.' },
  { id: 'sentences', label: 'Sentences', group: 'Prose', description: 'Complete sentences with natural punctuation.' },
  { id: 'paragraph', label: 'Paragraphs', group: 'Prose', description: 'Continuous prose for sustained rhythm.' },
  { id: 'business', label: 'Business correspondence', group: 'Professional', description: 'Letters and memos in formal office style.' },
  { id: 'reports', label: 'Report prose', group: 'Professional', description: 'Analytical report-style passages with figures.' },
  { id: 'capitals', label: 'Capitalisation', group: 'Mechanics', description: 'Heavy use of Shift and sentence capitals.' },
  { id: 'punctuation', label: 'Punctuation', group: 'Mechanics', description: 'Commas, quotes, colons and question marks in context.' },
  { id: 'numbers', label: 'Numbers', group: 'Mechanics', description: 'The number row, dates, amounts and phone-style groups.' },
  { id: 'symbols', label: 'Symbols', group: 'Mechanics', description: 'The shifted symbol layer, brackets and email-style strings.' },
  { id: 'mixed', label: 'Mixed content', group: 'Mechanics', description: 'Prose, numbers and symbols in one flow — closest to real office work.' },
  { id: 'code', label: 'Code typing', group: 'Technical', description: 'HTML, CSS and JavaScript tokens and one-line snippets.' },
  { id: 'accuracy', label: 'Accuracy drill', group: 'Personalised', description: 'Short, low-density text so every keystroke can be deliberate.' },
];

export const PRESET_IDS = PRESETS.map((p) => p.id);

function targetLength(durationSec, density = 1) {
  const chars = Math.round(Number(durationSec) * 3.6 * density);
  return Math.max(120, Math.min(2400, chars));
}

function fillTo(rng, pieces, length, separator = ' ') {
  const out = [];
  let total = 0;
  let guard = 0;
  while (total < length && guard < 2000) {
    const piece = rng.pick(pieces);
    if (!piece) break;
    out.push(piece);
    total += piece.length + separator.length;
    guard += 1;
  }
  return out.join(separator).slice(0, length + 40).trim();
}

/**
 * @param {object} opts
 * @param {string} opts.preset
 * @param {number} opts.durationSec
 * @param {string} [opts.seed]      makes generation reproducible (tests/daily)
 * @param {string[]} [opts.keys]    for weak-keys preset
 * @param {string} [opts.customText]
 * @param {string} [opts.language]  code preset: html|css|js
 */
export function generatePractice({ preset = 'random-words', durationSec = 60, seed = null, keys = [], customText = null, language = 'js' } = {}) {
  const rng = seeded(seed ?? `${preset}-${Date.now()}-${Math.random()}`);
  const length = targetLength(durationSec, preset === 'accuracy' ? 0.55 : 1);

  switch (preset) {
    case 'random-words':
    case 'timed':
      return { text: fillTo(rng, COMMON_WORDS, length), meta: { preset, pool: 'common' } };
    case 'common-words':
      return { text: fillTo(rng, COMMON_WORDS.slice(0, 60), length), meta: { preset } };
    case 'home-row':
      return { text: fillTo(rng, HOME_ROW_WORDS, length), meta: { preset } };
    case 'difficult-words':
      return { text: fillTo(rng, DIFFICULT_WORDS, length), meta: { preset } };
    case 'bigrams': {
      const rows = [];
      while (rows.join(' ').length < length) rows.push(rng.shuffle(BIGRAMS).join(' '));
      return { text: rows.join(' ').slice(0, length + 20).trim(), meta: { preset } };
    }
    case 'trigrams': {
      const rows = [];
      while (rows.join(' ').length < length) rows.push(rng.shuffle(TRIGRAMS).join(' '));
      return { text: rows.join(' ').slice(0, length + 20).trim(), meta: { preset } };
    }
    case 'weak-keys': {
      const text = buildWeakKeyDrill(keys.length ? keys : ['r', 't', 'y'], rng, COMMON_WORDS);
      const repeated = fillTo(rng, text.split(' '), Math.max(140, Math.min(600, length)));
      return { text: repeated, meta: { preset, keysUsed: keys } };
    }
    case 'sentences':
      return { text: fillTo(rng, SENTENCES, length), meta: { preset } };
    case 'paragraph': {
      const paras = rng.shuffle(PARAGRAPHS);
      let text = '';
      let i = 0;
      while (text.length < length && i < 40) { text += `${paras[i % paras.length]} `; i += 1; }
      return { text: text.trim().slice(0, length + 60), meta: { preset } };
    }
    case 'business':
      return { text: fillTo(rng, BUSINESS_PASSAGES, length), meta: { preset } };
    case 'reports':
      return { text: fillTo(rng, REPORT_PASSAGES, length), meta: { preset } };
    case 'capitals': {
      const rows = rng.shuffle(SENTENCES).map((s) => s.replace(/\b(the|a|an)\b/gi, (m) => m.toUpperCase()));
      return { text: fillTo(rng, rows, length), meta: { preset } };
    }
    case 'punctuation': {
      const rows = rng.shuffle(SENTENCES).filter((s) => /[,;:"'?!]/.test(s));
      const extra = ['Note: bring the file, the register, and the receipt.', "He asked, \"Is it ready?\" Then he left.", 'Items: pens, paper, ink; total 3.'];
      return { text: fillTo(rng, [...rows, ...extra], length), meta: { preset } };
    }
    case 'numbers':
      return { text: fillTo(rng, NUMBER_LINES, length), meta: { preset } };
    case 'symbols':
      return { text: fillTo(rng, SYMBOL_LINES, length), meta: { preset } };
    case 'mixed': {
      const pool = [...SENTENCES, ...NUMBER_LINES, ...SYMBOL_LINES];
      return { text: fillTo(rng, pool, length), meta: { preset } };
    }
    case 'code': {
      const lang = ['html', 'css', 'js'].includes(language) ? language : 'js';
      const pool = CODE_SNIPPETS[lang];
      const lines = [];
      let total = 0;
      while (total < length) {
        const line = rng.pick(pool);
        lines.push(line);
        total += line.length + 1;
      }
      return { text: lines.join(' ').slice(0, length + 40).trim(), meta: { preset, language: lang } };
    }
    case 'accuracy': {
      const pool = COMMON_WORDS.slice(0, 40);
      return { text: fillTo(rng, pool, length), meta: { preset, note: 'Low density: accuracy over speed.' } };
    }
    case 'custom': {
      const text = String(customText ?? '').normalize('NFC').replace(/\s+/g, ' ').trim();
      if (text.length < 40) throw Object.assign(new Error('Custom practice text must be at least 40 characters.'), { status: 400 });
      if (text.length > 5000) throw Object.assign(new Error('Custom practice text is limited to 5000 characters.'), { status: 400 });
      return { text, meta: { preset, chars: text.length } };
    }
    default:
      return { text: fillTo(rng, COMMON_WORDS, length), meta: { preset: 'random-words' } };
  }
}

export function presetById(id) {
  return PRESETS.find((p) => p.id === id) ?? null;
}

export { pickWords };
