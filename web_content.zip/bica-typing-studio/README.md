# BICA TYPING STUDIO

A typing tutor, an arcade and a classroom management system for **BICA Computer
Training Centre**. Runs on one lab PC, needs no internet, and keeps every
student's measured history in a single file you own.

```
Learn      seven levels, fifty gated lessons, accuracy first
Practice   timed and fixed-length drills, custom passages, examination mode
Arcade     twelve real games, one shared keyboard, accuracy-weighted scoring
Challenge  daily and weekly challenges, class leaderboards, personal bests
Progress   speed and accuracy history, weak-key analysis, achievements, certificates
Faculty    classes, assignments, tests, reports (CSV + PDF), certificates
Admin      users, settings, mastery policy, audit log, backups, sync status
```

---

## Quick start

```bash
npm ci                 # express + better-sqlite3, nothing else
npm run seed           # creates the first administrator, prints its password once
npm start              # http://localhost:8080
```

Then open `http://<server-ip>:8080` from a lab machine.
Full installation, Windows service and HTTPS instructions: **`docs/DEPLOYMENT.md`**.

Want demo accounts to explore first? `npm run seed:demo` adds `instructor`,
`student1`, `student2` with the password `BicaDemo2026!`. Remove them from
**Admin → Users → Remove demo data** before real students are created.

---

## Requirements

- Node.js **20 LTS or newer**
- Any modern browser
- A physical keyboard (the product is about touch typing)
- No database server, no cloud account, no internet at runtime

---

## Commands

| Command | What it does |
|---|---|
| `npm start` | Run the server (`PORT`, `HOST`, see `docs/DEPLOYMENT.md`) |
| `npm run dev` | Run with auto-restart on file changes |
| `npm run seed` | Create the first administrator |
| `npm run seed:demo` | Also create flagged demo accounts |
| `npm run migrate` | Apply pending database migrations |
| `npm run backup` | Consistent snapshot into `data/backups` |
| `npm test` | Typing-engine unit tests + HTTP integration tests |
| `npm run check` | Verify every front-end import resolves to a real export |
| `npm run test:e2e` | Drive the real UI in headless Chromium (needs a running server) |

---

## How it is built

- **Server:** Node 20 + Express, SQLite in WAL mode, opaque server-side sessions.
- **Client:** native ES modules and a hand-written CSS design system. No bundler,
  no framework, no CDN — so it can be debugged on a lab machine with the browser
  it already has, and it still works when the internet is down.
- **Measurement:** one typing engine (`shared/typing-engine.js`) used by lessons,
  practice, tests, challenges and every game. The server recomputes every result
  from raw keystroke counters and stores only its own numbers.
- **Dependencies:** `express` and `better-sqlite3`. `playwright-core` is dev-only,
  for the browser test.

Read next, in this order:

1. `docs/ARCHITECTURE.md` — data model, trust boundaries, offline model
2. `docs/TYPING_ENGINE.md` — the measurement contract and anti-cheat rules
3. `docs/RESEARCH.md` — the competitor research behind the feature set
4. `docs/SECURITY.md` — who can see what, and why
5. `docs/DEPLOYMENT.md` — install, service, HTTPS, backups
6. `docs/KNOWN_LIMITATIONS.md` — what this product deliberately does not do
7. `docs/RECOVERY.md` — backup and restore drills
8. `docs/FINAL_REPORT.md` — what was built, what was verified, what is next

---

## What makes it different

- **Accuracy gates progression.** A lesson unlocks when the measured accuracy
  requirement is met, not when the previous link is clicked. Default threshold is
  95% on foundational lessons; the administrator can change it.
- **Speed cannot buy a score.** Game score = base points × accuracy² × difficulty,
  and the server computes it. A fast sloppy round loses to a careful one.
- **Results are verified, not reported.** The browser measures; the server
  decides. Tokens are single-use, the clock is the server's, and an implausibly
  fast submission is refused rather than recorded.
- **Recommendations are explainable.** The adaptive engine is a deterministic rule
  system over stored per-key statistics and the screen shows its reasoning. It is
  not marketed as AI.
- **Honest about limits.** Bengali/Hindi curricula, real-time multiplayer, cloud
  sync and external accreditation are *not* implemented, and the interface says so
  instead of faking them. See `docs/KNOWN_LIMITATIONS.md`.

---

## Licence and ownership

Written for BICA Computer Training Centre. The curriculum text, game code and
visual system in this repository are original work produced for this centre; no
competitor's content, artwork or source code was copied. Typing pedagogies
(home-row sequencing, accuracy-before-speed gating, 5-character word standard)
are industry-standard practice, not proprietary material.
