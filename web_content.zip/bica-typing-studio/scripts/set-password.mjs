/**
 * Set (or reset) a password from the command line.
 *
 *   node scripts/set-password.mjs <username> [password]
 *
 * With no password argument a strong random one is generated and printed once.
 * The account is flagged `must_change_pw`, so the next sign-in forces the user
 * to choose their own password — which is what you want for a handed-over
 * installation or a forgotten administrator password.
 *
 * Use it:
 *   - after installing from a demo database, to replace the published demo
 *     administrator password;
 *   - when an administrator forgets their password (see docs/RECOVERY.md).
 *
 * Stop the server first if you want a completely quiet database; the write is
 * safe either way (SQLite in WAL mode, single statement).
 */
import crypto from 'node:crypto';
import { loadConfig } from '../server/config.js';
import { openDb, migrate } from '../server/db.js';
import { hashPassword, MIN_PASSWORD_LENGTH } from '../server/auth.js';

const [, , usernameArg, passwordArg] = process.argv;

if (!usernameArg) {
  console.error('Usage: node scripts/set-password.mjs <username> [password]');
  process.exit(1);
}

const config = loadConfig();
const db = openDb(config.dbPath);
migrate(db);

const user = db.prepare('SELECT id, username, role, display_name FROM users WHERE lower(username) = lower(?)').get(usernameArg);
if (!user) {
  console.error(`No account called "${usernameArg}" exists in ${config.dbPath}.`);
  const names = db.prepare('SELECT username, role FROM users ORDER BY role, username').all();
  if (names.length) {
    console.error('Accounts that do exist:');
    for (const n of names) console.error(`  ${n.username} (${n.role})`);
  }
  process.exit(1);
}

const password = passwordArg ?? crypto.randomBytes(12).toString('base64url');
if (password.length < MIN_PASSWORD_LENGTH) {
  console.error(`Password must be at least ${MIN_PASSWORD_LENGTH} characters.`);
  process.exit(1);
}

db.prepare('UPDATE users SET password_hash = ?, must_change_pw = 1 WHERE id = ?')
  .run(hashPassword(password), user.id);

// Every existing session for that account stops working immediately: a password
// reset is also a "sign this person out everywhere" action.
db.prepare("UPDATE auth_sessions SET revoked_at = datetime('now') WHERE user_id = ? AND revoked_at IS NULL")
  .run(user.id);

db.prepare("INSERT INTO audit_log (actor_id, action, target, detail_json) VALUES (NULL, 'cli.password_reset', ?, ?)")
  .run(`user:${user.id}`, JSON.stringify({ by: 'scripts/set-password.mjs' }));

console.log(`Password set for ${user.username} (${user.role} — ${user.display_name}).`);
console.log('All existing sessions for that account have been signed out.');
console.log('The user will be asked to choose a new password at next sign-in.');
if (!passwordArg) {
  console.log('');
  console.log(`  one-time password: ${password}`);
  console.log('  (shown once — copy it now)');
}
db.close();
