/**
 * Static module-graph check.
 *
 * The front end is loaded lazily by the router, so a broken named import in a
 * view that nobody clicked yet stays invisible until a student opens it. This
 * script walks every ES module under public/js (and shared/), parses each
 * import, resolves the target file and asserts that every requested named
 * export actually exists there.
 *
 * It is deliberately a parser, not a bundler: no dependencies, no build step.
 *
 * Usage: node scripts/check-modules.mjs
 * Exit code 1 if any import is unresolved.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const roots = [path.join(root, 'public', 'js'), path.join(root, 'shared')];

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

/** Collapse `export { a, b as c }`, `export function f`, `export const x`, `export default`. */
function exportsOf(file) {
  const src = fs.readFileSync(file, 'utf8');
  const names = new Set();
  if (/^\s*export\s+default/m.test(src)) names.add('default');

  for (const m of src.matchAll(/^\s*export\s+(?:async\s+)?(?:function|class)\s+([A-Za-z_$][\w$]*)/gm)) {
    names.add(m[1]);
  }
  for (const m of src.matchAll(/^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)/gm)) {
    names.add(m[1]);
  }
  for (const m of src.matchAll(/^\s*export\s*\{([^}]*)\}/gm)) {
    for (const part of m[1].split(',')) {
      const piece = part.trim();
      if (!piece) continue;
      const alias = piece.split(/\s+as\s+/);
      names.add((alias[1] ?? alias[0]).trim());
    }
  }
  return names;
}

const files = roots.flatMap((dir) => (fs.existsSync(dir) ? walk(dir) : []));
const cache = new Map();
const problems = [];
const importCount = { value: 0 };

for (const file of files) {
  const src = fs.readFileSync(file, 'utf8');
  const rel = path.relative(root, file);

  const patterns = [
    /import\s+([^'"]*?)\s+from\s+['"]([^'"]+)['"]/g,
    /export\s+[^'"]*?\s+from\s+['"]([^'"]+)['"]/g,
    /import\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
  ];

  const specs = [];
  for (const re of patterns) {
    for (const m of src.matchAll(re)) {
      if (m.length === 3) specs.push({ clause: m[1], spec: m[2] });
      else specs.push({ clause: '', spec: m[1] });
    }
  }

  for (const { clause, spec } of specs) {
    if (!spec.startsWith('.')) continue; // node: builtins / bare packages
    importCount.value += 1;
    const target = path.resolve(path.dirname(file), spec);
    if (!fs.existsSync(target)) {
      problems.push(`${rel}: cannot resolve '${spec}'`);
      continue;
    }
    if (!clause) continue;

    const named = clause.match(/\{([^}]*)\}/)?.[1] ?? '';
    const hasDefault = /^[^,{]*[A-Za-z_$]/.test(clause.replace(/\{[^}]*\}/, '').trim()) || /^\s*[A-Za-z_$][\w$]*\s*,/.test(clause);
    if (!cache.has(target)) cache.set(target, exportsOf(target));
    const available = cache.get(target);

    if (hasDefault && !available.has('default')) {
      problems.push(`${rel}: '${spec}' has no default export`);
    }
    for (const part of named.split(',')) {
      const piece = part.trim();
      if (!piece) continue;
      const imported = piece.split(/\s+as\s+/)[0].trim();
      if (!available.has(imported)) {
        problems.push(`${rel}: '${spec}' does not export '${imported}'`);
      }
    }
  }
}

console.log(`[modules] checked ${files.length} files, ${importCount.value} relative imports`);
if (problems.length) {
  console.log(`[modules] ${problems.length} problem(s):`);
  for (const p of [...new Set(problems)]) console.log(`  - ${p}`);
  process.exit(1);
}
console.log('[modules] every relative import resolves to a real export');
