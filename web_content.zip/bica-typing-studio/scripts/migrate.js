#!/usr/bin/env node
import { loadConfig } from '../server/config.js';
import { openDb, migrate } from '../server/db.js';
import { syncLessons, ensureDefaults } from '../server/seed-data.js';

const config = loadConfig();
const db = openDb(config.dbPath);
const ran = migrate(db);
console.log(ran.length ? `[bica] applied: ${ran.join(', ')}` : '[bica] already up to date');
syncLessons(db);
ensureDefaults(db);
console.log(`[bica] database ready at ${config.dbPath}`);
db.close();
