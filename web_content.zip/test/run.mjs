// تست منطق هسته (تقویم، حقوق، پاک‌سازی داده، XLSX). اجرا:  node test/run.mjs
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { writeFileSync, mkdirSync } from 'node:fs';
const require = createRequire(import.meta.url);
const core = require('../www/js/core.js');
Object.assign(globalThis, core);
const exp = require('../www/js/export.js');

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('✓', name); };

t('تبدیل تاریخ شمسی با ICU کاملاً یکسان است (۱۳۸۰ تا ۱۴۵۰)', () => {
  const f = new Intl.DateTimeFormat('en-u-ca-persian', { year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'UTC' });
  let bad = 0, cnt = 0;
  for (let d = new Date(Date.UTC(2001, 0, 1)); d < new Date(Date.UTC(2072, 0, 1)); d = new Date(d.getTime() + 864e5)) {
    const p = f.formatToParts(d), g = (k) => { const x = p.find((q) => q.type === k); return x ? +x.value : NaN; };
    const j = g2j(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
    cnt++;
    const y = Number.isNaN(g('relatedYear')) ? g('year') : g('relatedYear');
    if (j[0] !== y || j[1] !== g('month') || j[2] !== g('day')) bad++;
  }
  assert.equal(bad, 0, bad + ' mismatches of ' + cnt);
});
t('j2g معکوس دقیق g2j است', () => {
  for (let y = 1380; y <= 1450; y++) for (let m = 1; m <= 12; m++) for (let d = 1; d <= mLen(y, m); d++) {
    const iso = jIso(y, m, d), [gy, gm, gd] = iso.split('-').map(Number), j = g2j(gy, gm, gd);
    assert.deepEqual(j, [y, m, d], `${y}/${m}/${d} -> ${iso}`);
  }
});
t('سال کبیسه و طول ماه', () => {
  assert.equal(mLen(1403, 12), 30); assert.equal(mLen(1404, 12), 29); assert.equal(mLen(1405, 12), 29); assert.equal(mLen(1408, 12), 30);
  assert.equal(mLen(1405, 6), 31); assert.equal(mLen(1405, 7), 30);
  assert.equal(jIso(1405, 1, 1), '2026-03-21');
});
t('validJ', () => { assert.ok(validJ(1405, 12, 29)); assert.ok(!validJ(1405, 12, 30)); assert.ok(!validJ(1405, 13, 1)); assert.ok(!validJ(1405, 0, 1)); assert.ok(!validJ(1405, 1, 32)); });
t('num ارقام فارسی/عربی/جداکننده', () => {
  assert.equal(num('۱٬۲۰۰٬۰۰۰'), 1200000); assert.equal(num('١٢٫٥'), 12.5); assert.equal(num('abc'), 0); assert.equal(num(''), 0); assert.equal(num('1,500'), 1500); assert.equal(num(null), 0);
});
t('esc', () => assert.equal(esc(`<a href="x" onclick='y'>&`), '&lt;a href=&quot;x&quot; onclick=&#39;y&#39;&gt;&amp;'));
t('money منفی/صفر', () => { assert.equal(money(-0.4), '۰'); assert.equal(money(1234567), '۱,۲۳۴,۵۶۷'); });

// ---- حقوق ----
const mk = () => ({ ...defaultDb(),
  workers: [{ id: 'w1', name: 'علی', role: 'استادکار', wage: 800000, pl: 'p1', on: 1 }, { id: 'w2', name: 'رضا', role: '', wage: 600000, pl: '', on: 0 }],
  places: [{ id: 'p1', name: 'برج' }],
  att: [{ id: 'a1', w: 'w1', d: '2026-03-21', s: 1, pl: 'p1' }, { id: 'a2', w: 'w1', d: '2026-03-22', s: 0.5, ot: 2, pl: 'p1' }, { id: 'a3', w: 'w1', d: '2026-03-23', s: 1, late: 2, pl: 'p1' }, { id: 'a4', w: 'w1', d: '2026-03-24', s: 0 }],
  adv: [{ id: 'v1', w: 'w1', d: '2026-03-22', amt: 100000 }], trn: [{ id: 't1', w: 'w1', d: '2026-03-23', amt: 50000, note: 'ماشین' }] });
t('محاسبهٔ حقوق: روزمزد، اضافه‌کار، تاخیر، مساعده، کرایه', () => {
  const db = mk(), r = workerReport(db, db.workers[0], '2026-03-21', '2026-03-31');
  assert.equal(r.days, 2.5);
  assert.equal(r.gross, 800000 + 680000 + 800000);   // روز۲: نیم‌روز ۴۰۰٬۰۰۰ + ۲ ساعت اضافه‌کار × ۱۰۰٬۰۰۰ × ۱٫۴
  assert.equal(r.ld, 200000);                        // ۲ ساعت تاخیر × ۱۰۰٬۰۰۰
  assert.equal(r.adv, 100000);
  assert.equal(r.tt, 50000);
  assert.equal(r.net, 2280000 + 50000 - 200000 - 100000);
});
t('بازهٔ تاریخ: خارج از بازه حساب نمی‌شود', () => {
  const db = mk(), r = workerReport(db, db.workers[0], '2026-03-23', '2026-03-23');
  assert.equal(r.days, 1); assert.equal(r.adv, 0); assert.equal(r.tt, 50000);
});
t('buildReports: خلاصه + نیرو؛ غیرفعال بدون رکورد حذف می‌شود', () => {
  const db = mk(), ps = buildReports(db, { y: 1405, m: 1, from: 1, to: 31, worker: 'all' });
  assert.equal(ps.length, 2); assert.ok(ps[0].isSummary);
  assert.equal(ps[0].tables[0].r.length, 1);
  db.att.push({ id: 'a9', w: 'w2', d: '2026-03-25', s: 1, pl: '' });
  assert.equal(buildReports(db, { y: 1405, m: 1, from: 1, to: 31, worker: 'all' }).length, 3);
  assert.equal(buildReports(db, { y: 1405, m: 1, from: 1, to: 31, worker: 'w1' }).length, 1);
  assert.equal(buildReports(db, { y: 1405, m: 1, from: 1, to: 31, worker: 'zzz' }).length, 0);
});
t('monthRange: ورودی نامعتبر اصلاح می‌شود', () => {
  const r = monthRange(1405, 12, 20, 5); assert.ok(r.a <= r.b); assert.equal(monthRange(1405, 12, 0, 99).b, 29); assert.equal(monthRange(1405, 1, -3, 31).a, 1);
});
t('normalizeDb: ورودی مخرب و ناسازگار', () => {
  assert.equal(normalizeDb(null), null); assert.equal(normalizeDb({ workers: 1 }), null);
  const d = normalizeDb({ workers: [{ id: 'x"><img>', name: '<b>a</b>', wage: 'abc' }, { name: '' }], att: [{ w: 'x"><img>', d: '2026-03-21', s: 1 }, { w: 'x"><img>', d: '2026-03-21', s: 0 }, { w: 'nope', d: '2026-03-21', s: 1 }, { w: 'ximg', d: 'bad', s: 1 }, { w: 'ximg', d: '2026-03-22', s: 7 }], adv: [{ w: 'ximg', d: '2026-03-21', amt: -5 }, { w: 'ximg', d: '2026-03-21', amt: 5 }], set: { col: 'red', hpd: -4 } });
  assert.equal(d.workers.length, 1); assert.equal(d.workers[0].id, 'ximg'); assert.equal(d.workers[0].wage, 0);
  assert.equal(d.att.length, 1); assert.equal(d.adv.length, 1); assert.equal(d.set.col, '#4f46e5'); assert.equal(d.set.hpd, 8);
});
t('مهاجرت قدیمی: تاخیر دقیقه → ساعت', () => {
  const d = normalizeDb({ workers: [{ id: 'a', name: 'x' }], att: [{ w: 'a', d: '2026-03-21', s: 1, late: 150 }], set: {} });
  assert.equal(d.att[0].late, 2);
});
t('XLSX: ساختار zip/CRC و محتوا', () => {
  const db = mk(), ps = buildReports(db, { y: 1405, m: 1, from: 1, to: 31, worker: 'all' });
  const blob = exp.toXlsx(ps, db.set);
  return blob.arrayBuffer().then((ab) => { mkdirSync('/tmp/rl-test', { recursive: true }); writeFileSync('/tmp/rl-test/report.xlsx', Buffer.from(ab)); });
});
console.log(`\n${n} تست موفق`);
