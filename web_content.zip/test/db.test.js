import 'fake-indexeddb/auto'
import test from 'node:test'
import assert from 'node:assert/strict'
import {
  addCustomer,
  addPayment,
  adjustStock,
  changeFor,
  backupData,
  clearAdminPin,
  customerBalance,
  db,
  ensureSettings,
  hasAdminPin,
restoreData,
  salesBetween,
  saveBill,
  setAdminPin,
  stockHistory,
  updateCustomerPhone,
  verifyAdminPin,
  voidBill,
} from '../src/db/database.js'
import { hashPin } from '../src/lib/pin.js'

const ALL = ['0000', '9999']

async function addProduct(stock = 10) {
  return db.products.add({
    name: 'Sabut',
    barcode: `bc-${Math.random().toString(36).slice(2, 8)}`,
    category: 'Ration',
    mrp: 40,
    price: 35,
    stock,
  })
}

function line(pid, qty = 1) {
  return { productId: pid, name: 'Sabut', price: 35, mrp: 40, stock: 10, qty }
}

test('udhar bill: stock kam hota hai aur ledger me due banta hai', async () => {
  await ensureSettings()
  const pid = await addProduct(10)

  const bill = await saveBill({
    items: [line(pid, 3)],
    total: 105,
    payMode: 'UDHAR',
    customerName: '  Ramu   Bhai ',
    customerPhone: '9876543210',
  })

  assert.equal(bill.billNo, '0001')
  assert.ok(bill.id > 0)
  assert.equal((await db.products.get(pid)).stock, 7)

  const c = await db.customers.where('name').equals('Ramu Bhai').first()
  assert.ok(c, 'naam trim karke save hona chahiye')
  assert.equal(c.phone, '9876543210')
  assert.equal(bill.customerName, 'Ramu Bhai')

  assert.deepEqual(await customerBalance(c.id), { due: 105, paid: 0, balance: 105 })
  assert.equal((await salesBetween(...ALL)).length, 1)
})

test('voidBill: stock wapas, udhar hat, reports se nikal, history bani rahe', async () => {
  const pid = await addProduct(10)
  const bill = await saveBill({
    items: [line(pid, 4)],
    total: 140,
    payMode: 'UDHAR',
    customerName: 'Void Test',
  })
  const c = await db.customers.where('name').equals('Void Test').first()
  assert.equal((await db.products.get(pid)).stock, 6)

  await voidBill(bill.id, 'Galat napa')

  assert.equal((await db.products.get(pid)).stock, 10, 'stock wapas nahi hua')
  const bal = await customerBalance(c.id)
  assert.equal(bal.balance, 0, 'udhar wapas nahi hua')
  assert.equal(bal.paid, 140, 'reversing entry credit honi chahiye')
  assert.equal((await salesBetween(...ALL)).some((b) => b.id === bill.id), false)
  assert.ok((await db.bills.get(bill.id)).voidedAt, 'void history nahi bachi')
  assert.equal((await db.bills.get(bill.id)).voidReason, 'Galat napa')

  await assert.rejects(() => voidBill(bill.id), /pehle hi void/)
})

test('bill number badhta hai aur payment balance kam karta hai', async () => {
  const pid = await addProduct(5)
  const first = await saveBill({ items: [line(pid)], total: 35, payMode: 'CASH' })
  const second = await saveBill({
    items: [line(pid)],
    total: 35,
    payMode: 'UDHAR',
    customerName: 'Payment Test',
  })
  assert.match(first.billNo, /^\d{4}$/)
  assert.equal(Number(second.billNo), Number(first.billNo) + 1)

  const c = await db.customers.where('name').equals('Payment Test').first()
  assert.equal((await customerBalance(c.id)).balance, 35)
  await addPayment(c.id, 20, 'part payment')
  assert.equal((await customerBalance(c.id)).balance, 15)
})

test('same naam alag case/space ke saath ek hi customer hai, phone bhar jaata hai', async () => {
  const a = await addCustomer('Suresh Kumar')
  const b = await addCustomer('  suresh   kumar ', '9000000000')
  assert.equal(a.id, b.id)
  assert.equal((await db.customers.get(a.id)).phone, '9000000000')
  await assert.rejects(() => addCustomer('   '), /naam chahiye/)
})

test('decimal qty (kg): stock aur total dono sahi', async () => {
  const pid = await addProduct(10.5)
  const bill = await saveBill({
    items: [line(pid, 2.5)],
    total: 87.5,
    payMode: 'CASH',
    cashGiven: 100,
  })
  assert.equal(bill.changeReturned, 12.5)
  assert.equal((await db.products.get(pid)).stock, 8)
  assert.equal(bill.items[0].qty, 2.5)
})

test('float garbage: 0.2+0.1 = 0.30000000000000004 nahi banta', async () => {
  const pid = await addProduct(0.2)
  await adjustStock(pid, 0.1)
  const p = await db.products.get(pid)
  assert.equal(p.stock, 0.3)
  await voidBill((await saveBill({ items: [line(pid, 0.1)], total: 3.5, payMode: 'CASH' })).id)
  assert.equal((await db.products.get(pid)).stock, 0.3)
})

test('changeFor: paise wapas, exact par zero, paise kam par negative', () => {
  assert.equal(changeFor(105, 200), 95)
  assert.equal(changeFor(105, 105), 0)
  assert.equal(changeFor(105, ''), 0, 'khali input = exact payment')
  assert.equal(changeFor(105, 0), 0)
  assert.equal(changeFor(105, 50), -55)
  assert.equal(changeFor(0.1, 0.3), 0.2, 'paise ka hisaab float me nahi rehna chahiye')
})

test('cash bill me diye hue paise aur change save hote hain', async () => {
  const pid = await addProduct(10)
  const bill = await saveBill({
    items: [line(pid, 3)],
    total: 105,
    payMode: 'CASH',
    cashGiven: 200,
  })
  assert.equal(bill.cashGiven, 200)
  assert.equal(bill.changeReturned, 95)
  const stored = await db.bills.get(bill.id)
  assert.equal(stored.changeReturned, 95)
  assert.equal((await db.products.get(pid)).stock, 7, 'change se stock wapas nahi aata')
})

test('udhar bill me change nahi hota', async () => {
  const pid = await addProduct(2)
  const bill = await saveBill({
    items: [line(pid, 1)],
    total: 35,
    payMode: 'UDHAR',
    customerName: 'Change Udhar',
    cashGiven: 500,
  })
  assert.equal(bill.changeReturned, 0)
})

test('updateCustomerPhone: phone set/badal/jhaad', async () => {
  const c = await addCustomer('Phone Test', '1111111111')
  assert.equal(await updateCustomerPhone(c.id, '2222222222'), '2222222222')
  assert.equal((await db.customers.get(c.id)).phone, '2222222222')
  assert.equal(await updateCustomerPhone(c.id, '  '), '')
  assert.equal((await db.customers.get(c.id)).phone, '')
})

test('stockLog: sale/adjust/void sab log hote hain', async () => {
  const pid = await addProduct(10)
  const bill = await saveBill({ items: [line(pid, 2)], total: 70, payMode: 'CASH' })
  await adjustStock(pid, 5)
  await voidBill(bill.id, 'test')

  const all = await stockHistory(50)
  assert.deepEqual(
    all.filter((l) => l.productId === pid).map((l) => l.type),
    ['void', 'adjust', 'sale'],
    'sabse naya pehle (void, adjust, sale)',
  )
  const [v, a, s] = all.filter((l) => l.productId === pid)
  assert.equal(v.qty, 2)
  assert.equal(a.qty, 5)
  assert.equal(s.qty, -2)
  assert.equal(s.productName, 'Sabut')
})

test('restoreData: galat backup friendly error + sahi backup round-trip', async () => {
  await assert.rejects(() => restoreData('yahan koi json nahi'), /galat/)
  await assert.rejects(() => restoreData('{"products": 1}'), /galat/)
  await assert.rejects(() => restoreData('{"products": [1,2]}'), 'garbage items reject')
  await assert.rejects(() => restoreData('"[1,2,3]"'), /galat/)
  await assert.rejects(() => restoreData('{}'), /galat/)

  const pid = await addProduct(4)
  await saveBill({ items: [line(pid, 1)], total: 35, payMode: 'CASH' })
  const before = {
    bills: (await db.bills.toArray()).length,
    products: (await db.products.toArray()).length,
  }
  const json = await backupData()
  await restoreData(json)
  assert.equal((await db.bills.toArray()).length, before.bills, 'restore ke baad bills waise hi')
  assert.equal((await db.products.toArray()).length, before.products, 'restore ke baad products waise hi')
})

test('admin PIN: set, verify, galat PIN reject, clear', async () => {
  await clearAdminPin()
  assert.equal(await hasAdminPin(), false)
  assert.equal(await verifyAdminPin('1234'), true, 'bina PIN sabko entry')

  await setAdminPin('1234')
  assert.equal(await hasAdminPin(), true)
  assert.equal(await verifyAdminPin('1234'), true)
  assert.equal(await verifyAdminPin('9999'), false)
  assert.equal(await verifyAdminPin('12345'), false)
  assert.equal(await verifyAdminPin(''), false)

  const row = await db.settings.get('adminPinHash')
  assert.equal(row.value, hashPin('1234'), 'plaintext PIN kabhi store nahi hota')
  assert.notEqual(row.value, '1234')

  await setAdminPin('0000')
  assert.equal(await verifyAdminPin('0000'), true, 'PIN badalna sabit')

  await assert.rejects(() => setAdminPin('12'), /4-6 digit/)
  await assert.rejects(() => setAdminPin(''), /khaali/)

  await clearAdminPin()
  assert.equal(await hasAdminPin(), false)
  assert.equal(await verifyAdminPin('1234'), true)
})
