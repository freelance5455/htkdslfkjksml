// اختبارات صندوق أسود: تشغّل السيرفر فعليًا على بورت عشوائي وقاعدة مؤقتة
const { test, before, after } = require('node:test'), assert = require('node:assert/strict');
const { spawn } = require('node:child_process'), path = require('path'), fs = require('fs'), os = require('os');
const totp = require('../lib/totp');
const PORT = 20000 + Math.floor(Math.random() * 20000), BASE = 'http://127.0.0.1:' + PORT;
const ADMIN = 'boss', APASS = 'Sup3r-Secret-Pass-9';
let proc, tmp, ipn = 0, out = '';
const nip = () => '10.9.' + Math.floor(++ipn / 250) + '.' + (ipn % 250 + 1);

before(async () => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'osint-'));
  proc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: { ...process.env, PORT, DB_PATH: path.join(tmp, 't.db'), ADMIN_USER: ADMIN, ADMIN_PASS: APASS, NODE_ENV: 'test' } });
  proc.stdout.on('data', d => out += d); proc.stderr.on('data', d => out += d);
  for (let i = 0; i < 100; i++) { try { if ((await fetch(BASE + '/healthz')).ok) return; } catch (e) {} await new Promise(r => setTimeout(r, 100)); }
  throw new Error('server did not start: ' + out);
});
after(() => { proc && proc.kill(); fs.rmSync(tmp, { recursive: true, force: true }); });

async function call(method, url, body, o = {}) {
  const h = { 'Content-Type': 'application/json', 'X-Forwarded-For': o.ip || nip() };
  if (method !== 'GET' && !o.noCsrf) h['X-Requested-With'] = 'fetch';
  if (o.cookie) h.Cookie = o.cookie;
  const r = await fetch(BASE + url, { method, headers: h, body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body) });
  const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch (e) {}
  const ck = (r.headers.getSetCookie ? r.headers.getSetCookie() : []).map(s => s.split(';')[0]).find(s => s.startsWith('sid=')) || '';
  return { s: r.status, j, t, h: r.headers, ck };
}
const login = (n, p, extra = {}, ip) => call('POST', '/api/login', { n, p, ...extra }, { ip });
const adminCookie = async () => (await login(ADMIN, APASS)).ck;
async function mkUser(n, p = 'Alice-Strong-Pass-1', r = 'user') { const ck = await adminCookie(); const x = await call('POST', '/api/admin/users', { n, p, r }, { cookie: ck }); assert.equal(x.s, 200, JSON.stringify(x.j)); return p; }
async function enable2fa(cookie) {
  const s = await call('POST', '/api/me/2fa/setup', {}, { cookie }); assert.equal(s.s, 200);
  const step = Math.floor(Date.now() / 30000), key = totp.b32dec(s.j.secret);
  const e = await call('POST', '/api/me/2fa/enable', { c: totp.hotp(key, step) }, { cookie }); assert.equal(e.s, 200, JSON.stringify(e.j));
  return { key, step, codes: e.j.codes };
}

test('healthz + ترويسات الأمان', async () => {
  const r = await call('GET', '/healthz'); assert.equal(r.s, 200); assert.deepEqual(r.j, { ok: 1 });
  assert.match(r.h.get('content-security-policy'), /script-src 'self'/); assert.match(r.h.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.match(r.h.get('permissions-policy'), /camera=\(\)/); assert.equal(r.h.get('x-powered-by'), null);
  const a = await call('GET', '/api/me'); assert.equal(a.s, 401); assert.equal(a.h.get('cache-control'), 'no-store');
});
test('CSRF: بدون الهيدر المخصص = 403', async () => { assert.equal((await call('POST', '/api/login', { n: ADMIN, p: APASS }, { noCsrf: true })).s, 403); });
test('تسجيل الدخول والجلسة وتسجيل الخروج', async () => {
  assert.equal((await login(ADMIN, 'wrong-password-123')).s, 401);
  assert.equal((await login('nobody', 'wrong-password-123')).s, 401);
  const r = await login(ADMIN, APASS); assert.equal(r.s, 200); assert.deepEqual(r.j, { n: ADMIN, r: 'admin', f: false }); assert.ok(r.ck);
  const me = await call('GET', '/api/me', undefined, { cookie: r.ck }); assert.equal(me.j.n, ADMIN);
  await call('POST', '/api/logout', {}, { cookie: r.ck });
  assert.equal((await call('GET', '/api/me', undefined, { cookie: r.ck })).s, 401);
});
test('أخطاء الجسم: JSON خاطئ = 400، كبير = 413', async () => {
  assert.equal((await call('POST', '/api/login', '{nope')).s, 400);
  const big = await call('POST', '/api/login', { n: 'x', p: 'y'.repeat(40000) }); assert.equal(big.s, 413);
});
test('سياسة كلمة المرور عند إنشاء مستخدم + صلاحيات الأدمن', async () => {
  const ck = await adminCookie();
  for (const p of ['short', 'password1234', 'alllowercaseonly']) assert.equal((await call('POST', '/api/admin/users', { n: 'weak1', p, r: 'user' }, { cookie: ck })).s, 400, p);
  assert.equal((await call('POST', '/api/admin/users', { n: 'bad name', p: 'Alice-Strong-Pass-1', r: 'user' }, { cookie: ck })).s, 400);
  const p = await mkUser('carol'); const c = (await login('carol', p)).ck;
  assert.equal((await call('GET', '/api/admin/users', undefined, { cookie: c })).s, 403);
  assert.equal((await call('POST', '/api/admin/users', { n: 'carol', p, r: 'user' }, { cookie: ck })).s, 409);
});
test('قفل المحاولات الفاشلة لكل اسم مستخدم (حتى لو IP مختلف) ويشمل الأسماء الوهمية', async () => {
  await mkUser('dave'); let last;
  for (let i = 0; i < 5; i++) last = await login('dave', 'bad-password-' + i);
  assert.equal(last.s, 401);
  assert.equal((await login('dave', 'bad-again-123')).s, 429);
  assert.equal((await login('dave', 'Alice-Strong-Pass-1')).s, 429);   // حتى الباسورد الصحيح مقفول
  for (let i = 0; i < 5; i++) await login('ghost', 'x' + i);
  assert.equal((await login('ghost', 'x')).s, 429);
});
test('حد دخول لكل IP', async () => {
  const ip = nip(); let s = 0; for (let i = 0; i < 11; i++) s = (await login('nobody' + i, 'x', {}, ip)).s;
  assert.equal(s, 429);
});
test('حد عام للـ API لكل IP', async () => {
  const ip = nip(); let s = 0; for (let i = 0; i < 121; i++) s = (await call('GET', '/api/me', undefined, { ip })).s;
  assert.equal(s, 429);
});
test('تغيير كلمة المرور: يتحقق من الحالية ويطبق السياسة ويلغي الجلسات الأخرى', async () => {
  const p = await mkUser('erin'); const a = (await login('erin', p)).ck, b = (await login('erin', p)).ck;
  assert.equal((await call('POST', '/api/me/password', { o: 'wrong-current-1', p: 'New-Strong-Pass-77' }, { cookie: a })).s, 400);
  assert.equal((await call('POST', '/api/me/password', { o: p, p: 'weak' }, { cookie: a })).s, 400);
  assert.equal((await call('POST', '/api/me/password', { o: p, p: 'New-Strong-Pass-77' }, { cookie: a })).s, 200);
  assert.equal((await call('GET', '/api/me', undefined, { cookie: b })).s, 401);
  assert.equal((await call('GET', '/api/me', undefined, { cookie: a })).s, 200);
  assert.equal((await login('erin', 'New-Strong-Pass-77')).s, 200);
});
test('2FA: تفعيل، دخول بخطوتين، منع إعادة الاستخدام، رموز الاسترجاع، تعطيل', async () => {
  const p = await mkUser('frank'); const ck = (await login('frank', p)).ck;
  assert.equal((await call('POST', '/api/me/2fa/enable', { c: '123456' }, { cookie: ck })).s, 400);   // قبل setup
  const s = await call('POST', '/api/me/2fa/setup', {}, { cookie: ck }); assert.match(s.j.uri, /^otpauth:\/\/totp\//);
  assert.equal((await call('POST', '/api/me/2fa/enable', { c: '000000' }, { cookie: ck })).s, 400);
  const key = totp.b32dec(s.j.secret), step = Math.floor(Date.now() / 30000);
  const en = await call('POST', '/api/me/2fa/enable', { c: totp.hotp(key, step) }, { cookie: ck });
  assert.equal(en.s, 200); assert.equal(en.j.codes.length, 8); assert.match(en.j.codes[0], /^[0-9a-f]{5}-[0-9a-f]{5}$/);
  assert.equal((await call('POST', '/api/me/2fa/setup', {}, { cookie: ck })).s, 400);   // مفعّل أصلاً
  const r1 = await login('frank', p); assert.equal(r1.s, 200); assert.deepEqual(r1.j, { need2fa: 1 }); assert.equal(r1.ck, '');
  assert.equal((await login('frank', p, { c: totp.hotp(key, step) })).s, 401);          // نفس الرمز المستخدم في التفعيل
  const ok = await login('frank', p, { c: totp.hotp(key, step + 1) }); assert.equal(ok.s, 200); assert.equal(ok.j.f, true); assert.ok(ok.ck);
  const rec = en.j.codes[0];
  assert.equal((await login('frank', p, { c: rec })).s, 200);
  assert.equal((await login('frank', p, { c: rec })).s, 401);                           // مرة وحدة فقط
  assert.equal((await login('frank', 'Wrong-Pass-123456', { c: en.j.codes[1] })).s, 401);
  assert.equal((await call('POST', '/api/me/2fa/disable', { p: 'wrong-pass-12345', c: en.j.codes[1] }, { cookie: ok.ck })).s, 400);
  assert.equal((await call('POST', '/api/me/2fa/disable', { p, c: '000000' }, { cookie: ok.ck })).s, 400);
  assert.equal((await call('POST', '/api/me/2fa/disable', { p, c: en.j.codes[2] }, { cookie: ok.ck })).s, 200);
  const after = await login('frank', p); assert.equal(after.s, 200); assert.equal(after.j.f, false);
});
test('الأدمن يقدر يعيد ضبط 2FA لمستخدم', async () => {
  const p = await mkUser('gina'); const ck = (await login('gina', p)).ck; await enable2fa(ck);
  assert.deepEqual((await login('gina', p)).j, { need2fa: 1 });
  const ack = await adminCookie(); const list = await call('GET', '/api/admin/users', undefined, { cookie: ack });
  const g = list.j.find(u => u.username === 'gina'); assert.equal(g.totp_on, 1);
  assert.equal((await call('POST', '/api/admin/users/' + g.id + '/reset2fa', {}, { cookie: ack })).s, 200);
  assert.equal((await call('GET', '/api/me', undefined, { cookie: ck })).s, 401);       // جلساته انلغت
  assert.equal((await login('gina', p)).j.f, false);
  assert.equal((await call('POST', '/api/admin/users/9999/reset2fa', {}, { cookie: ack })).s, 404);
});
test('أدوات مخصصة: التحقق من الرابط والنوع', async () => {
  const ck = await adminCookie();
  assert.equal((await call('POST', '/api/admin/tools', { type: 'user', name: 'X', url: 'javascript:alert({q})', descr: '' }, { cookie: ck })).s, 400);
  assert.equal((await call('POST', '/api/admin/tools', { type: 'nope', name: 'X', url: 'https://a.com/?q={q}' }, { cookie: ck })).s, 400);
  assert.equal((await call('POST', '/api/admin/tools', { type: 'user', name: 'X', url: 'https://a.com/?q={q}' }, { cookie: ck })).s, 200);
  assert.ok((await call('GET', '/api/tools', undefined, { cookie: ck })).j.some(t => t.name === 'X'));
});
test('لا يمكن حذف آخر أدمن أو حذف النفس', async () => {
  const ck = await adminCookie(), list = (await call('GET', '/api/admin/users', undefined, { cookie: ck })).j, me = list.find(u => u.username === ADMIN);
  assert.equal((await call('DELETE', '/api/admin/users/' + me.id, undefined, { cookie: ck })).s, 400);
});
test('تصدير النسخة لا يحتوي هاشات ولا أسرار', async () => {
  const ck = await adminCookie(), r = await call('GET', '/api/admin/export', undefined, { cookie: ck });
  assert.equal(r.s, 200); assert.ok(r.j.users.length > 0);
  for (const u of r.j.users) assert.deepEqual(Object.keys(u).sort(), ['created_at', 'role', 'totp_on', 'username']);
  assert.ok(!/"pass_hash"|"totp_secret"|"recovery"/.test(r.t));
});
test('الملفات الثابتة تنخدم والمسارات المجهولة 404', async () => {
  assert.equal((await call('GET', '/')).s, 200); assert.equal((await call('GET', '/api/nothing', undefined, { cookie: await adminCookie() })).s, 404);
});

test('سجل البحث: يتحقق، يتجاهل المكرر المتتالي، خاص بكل مستخدم، ويمسح', async () => {
  const p = await mkUser('hana'), ck = (await login('hana', p)).ck, p2 = await mkUser('ivan'), ck2 = (await login('ivan', p2)).ck;
  assert.equal((await call('POST', '/api/search', { t: 'nope', v: 'x' }, { cookie: ck })).s, 400);
  assert.equal((await call('POST', '/api/search', { t: 'user', v: '  ' }, { cookie: ck })).s, 400);
  for (const [t, v] of [['user', 'abc'], ['user', 'abc'], ['domain', 'example.com'], ['cve', 'CVE-2024-3094']]) assert.equal((await call('POST', '/api/search', { t, v }, { cookie: ck })).s, 200);
  const h = await call('GET', '/api/history', undefined, { cookie: ck });
  assert.deepEqual(h.j, [{ type: 'cve', value: 'CVE-2024-3094' }, { type: 'domain', value: 'example.com' }, { type: 'user', value: 'abc' }]);
  assert.deepEqual((await call('GET', '/api/history', undefined, { cookie: ck2 })).j, []);
  const log = await call('GET', '/api/admin/log', undefined, { cookie: await adminCookie() }); assert.ok(log.j.some(l => l.action === 'search domain: example.com'));
  await call('DELETE', '/api/history', undefined, { cookie: ck }); assert.deepEqual((await call('GET', '/api/history', undefined, { cookie: ck })).j, []);
});
test('الحالات: إنشاء/قراءة/تعديل/حذف + عناصر + عزل بين المستخدمين (حتى الأدمن)', async () => {
  const p = await mkUser('jade'), ck = (await login('jade', p)).ck, p2 = await mkUser('kai'), ck2 = (await login('kai', p2)).ck;
  assert.equal((await call('POST', '/api/cases', { title: '   ' }, { cookie: ck })).s, 400);
  const mk = await call('POST', '/api/cases', { title: 'قضية تجريبية', target: 'example.com' }, { cookie: ck }); assert.equal(mk.s, 200); const id = mk.j.id;
  const it = (b) => call('POST', '/api/cases/' + id + '/items', b, { cookie: ck });
  assert.equal((await it({ kind: 'search', type: 'domain', value: 'example.com' })).s, 200);
  assert.equal((await it({ kind: 'note', text: 'ملاحظة: النطاق مسجّل حديثًا' })).s, 200);
  assert.equal((await it({ kind: 'link', value: 'https://crt.sh/?q=example.com', text: 'crt' })).s, 200);
  for (const bad of [{ kind: 'search', type: 'zzz', value: 'x' }, { kind: 'note', text: '' }, { kind: 'link', value: 'javascript:alert(1)' }, { kind: 'link', value: 'ftp://x.com/a' }, { kind: 'other' }]) assert.equal((await it(bad)).s, 400, JSON.stringify(bad));
  const g = await call('GET', '/api/cases/' + id, undefined, { cookie: ck });
  assert.equal(g.j.case.title, 'قضية تجريبية'); assert.deepEqual(g.j.items.map(x => x.kind), ['search', 'note', 'link']);
  assert.equal((await call('GET', '/api/cases', undefined, { cookie: ck })).j[0].n, 3);
  // العزل
  assert.equal((await call('GET', '/api/cases/' + id, undefined, { cookie: ck2 })).s, 404);
  assert.equal((await call('GET', '/api/cases/' + id, undefined, { cookie: await adminCookie() })).s, 404);
  assert.equal((await call('PUT', '/api/cases/' + id, { title: 'hack' }, { cookie: ck2 })).s, 404);
  assert.equal((await call('DELETE', '/api/cases/' + id, undefined, { cookie: ck2 })).s, 404);
  assert.deepEqual((await call('GET', '/api/cases', undefined, { cookie: ck2 })).j, []);
  // تعديل وحذف عنصر
  assert.equal((await call('PUT', '/api/cases/' + id, { status: 'closed', title: 'جديد' }, { cookie: ck })).s, 200);
  assert.equal((await call('PUT', '/api/cases/' + id, { status: 'weird' }, { cookie: ck })).s, 400);
  assert.equal((await call('GET', '/api/cases/' + id, undefined, { cookie: ck })).j.case.status, 'closed');
  assert.equal((await call('DELETE', '/api/cases/' + id + '/items/' + g.j.items[0].id, undefined, { cookie: ck2 })).s, 404);
  assert.equal((await call('DELETE', '/api/cases/' + id + '/items/' + g.j.items[0].id, undefined, { cookie: ck })).s, 200);
  assert.equal((await call('GET', '/api/cases/' + id, undefined, { cookie: ck })).j.items.length, 2);
  assert.equal((await call('DELETE', '/api/cases/' + id, undefined, { cookie: ck })).s, 200);
  assert.equal((await call('GET', '/api/cases/' + id, undefined, { cookie: ck })).s, 404);
  assert.equal((await call('GET', '/api/cases/abc', undefined, { cookie: ck })).s, 404);
});
test('الحالات: حذف المستخدم يحذف حالاته (cascade) والملاحظة الطويلة تُقص', async () => {
  const p = await mkUser('leo'), ck = (await login('leo', p)).ck;
  const id = (await call('POST', '/api/cases', { title: 'x'.repeat(200) }, { cookie: ck })).j.id;
  await call('POST', '/api/cases/' + id + '/items', { kind: 'note', text: 'ن'.repeat(6000) }, { cookie: ck });
  const g = await call('GET', '/api/cases/' + id, undefined, { cookie: ck }); assert.equal(g.j.case.title.length, 80); assert.equal(g.j.items[0].text.length, 5000);
  const ack = await adminCookie(), u = (await call('GET', '/api/admin/users', undefined, { cookie: ack })).j.find(x => x.username === 'leo');
  assert.equal((await call('DELETE', '/api/admin/users/' + u.id, undefined, { cookie: ack })).s, 200);
  assert.equal((await call('GET', '/api/cases/' + id, undefined, { cookie: ck })).s, 401);
});

test('معرّفات غير رقمية في مسارات الأدمن لا تكسر السيرفر', async () => {
  const ck = await adminCookie();
  assert.equal((await call('DELETE', '/api/admin/users/abc', undefined, { cookie: ck })).s, 404);
  assert.equal((await call('POST', '/api/admin/users/abc/reset2fa', {}, { cookie: ck })).s, 404);
  assert.equal((await call('DELETE', '/api/admin/tools/abc', undefined, { cookie: ck })).s, 200);
  assert.equal((await call('GET', '/healthz')).s, 200);
});
