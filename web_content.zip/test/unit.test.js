const { test } = require('node:test'), assert = require('node:assert/strict');
const totp = require('../lib/totp'), { checkPass } = require('../lib/policy');

test('TOTP: RFC 6238 test vectors (SHA-1, آخر 6 أرقام)', () => {
  const key = Buffer.from('12345678901234567890');
  assert.equal(totp.b32enc(key), 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ');
  assert.deepEqual(totp.b32dec('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ'), key);
  for (const [t, code] of [[59, '287082'], [1111111109, '081804'], [1111111111, '050471'], [1234567890, '005924'], [2000000000, '279037'], [20000000000, '353130']])
    assert.equal(totp.hotp(key, Math.floor(t / 30)), code, 'T=' + t);
});
test('TOTP: verify (نافذة ±1 + منع إعادة الاستخدام)', () => {
  const secret = totp.newSecret(), key = totp.b32dec(secret), now = 1700000000000, step = Math.floor(now / 30000);
  const c = (s) => totp.hotp(key, s);
  assert.equal(totp.verify(secret, c(step), { now }), step);
  assert.equal(totp.verify(secret, c(step - 1), { now }), step - 1);
  assert.equal(totp.verify(secret, c(step + 1), { now }), step + 1);
  assert.equal(totp.verify(secret, c(step + 2), { now }), 0);
  assert.equal(totp.verify(secret, c(step), { now, last: step }), 0);
  assert.equal(totp.verify(secret, 'abcdef', { now }), 0);
  assert.equal(totp.verify(secret, '12345', { now }), 0);
  assert.match(totp.uri(secret, 'ali ce'), /^otpauth:\/\/totp\/OSINT%20Hub:ali%20ce\?secret=[A-Z2-7]{32}&issuer=/);
});
test('سياسة كلمات المرور', () => {
  for (const bad of ['short1A!', 'a'.repeat(30), 'alllowercaseonly', 'password1234', 'Rashid-Strong-1!x']) {
    const e = checkPass(bad, bad === 'Rashid-Strong-1!x' ? 'rashid' : 'u');
    assert.ok(e, 'must reject: ' + bad);
  }
  assert.equal(checkPass('Correct-Horse-Battery-9', 'ali'), null);
  assert.equal(checkPass('a very long passphrase with only letters', 'ali'), null);
  assert.ok(checkPass('x'.repeat(73) + '1A', 'ali'));
  assert.ok(checkPass(null, 'ali'));
});
