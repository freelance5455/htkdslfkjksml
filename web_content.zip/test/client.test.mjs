import vm from 'node:vm'; import fs from 'node:fs'; import assert from 'node:assert/strict';
class El {
  constructor(sel){ this.sel=sel; this.value=''; this.textContent=''; this._h=''; this.style={}; this.dataset={}; this.children=[]; this.listeners={}; this.onclick=null; this.onkeydown=null; this.onchange=null; this.oninput=null;
    const s=new Set(); this.classList={add:c=>s.add(c),remove:c=>s.delete(c),toggle:(c,f)=>{const on=f===undefined?!s.has(c):f;on?s.add(c):s.delete(c)},contains:c=>s.has(c),_s:s}; this.selectedOptions=[{textContent:'opt'}]; }
  set innerHTML(v){ this._h=String(v); this.children=[]; } get innerHTML(){ return this._h; }
  appendChild(c){ this.children.push(c); this._h+=c._h||''; return c; } focus(){ this.focused=true; } click(){ return this.onclick && this.onclick({target:this}); } remove(){}
  closest(){ return null; }
}
const els={}; const get=s=>els[s]??(els[s]=new El(s));
const document={ querySelector:get, querySelectorAll:()=>[], createElement:()=>new El('new'), body:new El('body'), documentElement:new El('html') };
const calls=[]; const routes={'GET /api/me':()=>({s:401,j:{e:'unauthorized'}})};
const ctx={ document, window:{}, location:{reload(){ctx.reloaded=true}}, navigator:{clipboard:{writeText:async t=>{ctx.copied=t}}}, confirm:()=>true, URL, Blob, console, setInterval:()=>0, setTimeout, clearTimeout,
  localStorage:{_m:new Map(),getItem(k){return this._m.get(k)??null},setItem(k,v){this._m.set(k,String(v))}},
  fetch: async (u,init={})=>{ const m=init.method||'GET'; calls.push({m,u,b:init.body?JSON.parse(init.body):undefined}); const h=routes[m+' '+u]; const r=h?h(init.body?JSON.parse(init.body):undefined):{s:200,j:{}}; return {ok:r.s<400,status:r.s,json:async()=>r.j}; } };
vm.createContext(ctx); vm.runInContext(fs.readFileSync(new URL('../public/app.js', import.meta.url),'utf8'),ctx);
const run=c=>vm.runInContext(c,ctx); const t=async(n,f)=>{ try{ await f(); console.log('PASS',n);}catch(e){ console.log('FAIL',n,e.stack.split('\n').slice(0,3).join(' | ')); process.exitCode=1; } };
const tick=()=>new Promise(r=>setTimeout(r,5));

await t('detect: أنواع القيم', ()=>{
  const d=v=>run('detect('+JSON.stringify(v)+')');
  const cases=[['a@b.com','email'],['example.com','domain'],['sub.example.co.uk','domain'],['8.8.8.8','ip'],['2001:4860:4860::8888','ip'],['999.1.1.1',null],['https://x.com/a?b=1','url'],['https://x.com/p.png','img'],
   ['CVE-2024-3094','cve'],['cve-2021-44228','cve'],['AS13335','asn'],['d41d8cd98f00b204e9800998ecf8427e','hash'],['da39a3ee5e6b4b0d3255bfef95601890afd80709','hash'],
   ['0x742d35Cc6634C0532925a3b844Bc454e4438f44e','crypto'],['1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa','crypto'],['+964 770 123 4567','phone'],['ali','null'],['john smith',null]];
  for(const [v,e] of cases){ const r=d(v); assert.equal(r===null?'null':r, e===null?'null':e, v); }
});
await t('fill: {q} {r} {n}', ()=>{
  assert.equal(run("fill('https://a/?q={q}','a b&c')"),'https://a/?q=a%20b%26c');
  assert.equal(run("fill('https://w/*/{r}','https://x.com/a b')"),'https://w/*/https://x.com/a%20b');
  assert.equal(run("fill('https://bgp/AS{n}','AS13335')"),'https://bgp/AS13335');
});
await t('كل نوع له روابط صالحة (http/https + عنصر نائب موجود)', ()=>{
  const T=run('T'); const types=Object.keys(T); assert.equal(types.length,12);
  for(const k of types){ assert.ok(T[k].length>=3,k); for(const [n,u,d] of T[k]){ assert.match(u,/^https:\/\//,n); assert.match(u,/\{(q|r|n)\}/,n+' '+u); } }
  assert.equal(JSON.stringify(types),JSON.stringify(run('TT')));
});
await t('links يدمج الأدوات المخصصة لنفس النوع فقط', ()=>{
  run("custom=[{type:'domain',name:'Mine',url:'https://m.com/?q={q}',descr:'x'},{type:'ip',name:'Other',url:'https://o.com/{q}',descr:''}]");
  const d=run("links('domain','a.com').map(x=>x[0])"); assert.ok(d.includes('Mine')&&!d.includes('Other'));
});
await t('safe يمنع javascript: وغيره', ()=>{ assert.equal(run("safe('javascript:alert(1)')"),'#'); assert.equal(run("safe('data:text/html,x')"),'#'); assert.equal(run("safe('https://ok.com/a')"),'https://ok.com/a'); });
await t('esc يهرب HTML والاقتباسات', ()=>{ assert.equal(run(`esc('<img src=x onerror="a()">\\'')`),'&lt;img src=x onerror=&quot;a()&quot;&gt;&#39;'); });
await t('الدخول: need2fa يُظهر خانة الرمز ثم يدخل بالرمز', async()=>{
  routes['POST /api/login']=b=> b.c ? {s:200,j:{n:'sara',r:'user',f:true}} : {s:200,j:{need2fa:1}};
  routes['GET /api/tools']=()=>({s:200,j:[]}); routes['GET /api/cases']=()=>({s:200,j:[]}); routes['GET /api/history']=()=>({s:200,j:[]});
  get('#lc').classList.add('hide'); get('#app').classList.add('hide'); get('#lu').value='sara'; get('#lp').value='Strong-Passw0rd-xyz'; calls.length=0; await get('#lb').click(); await tick();
  assert.equal(get('#lc').classList.contains('hide'),false); assert.equal(calls[0].b.c,undefined); assert.ok(!get('#app').classList.contains('hide')===false);
  get('#lc').value='123456'; await get('#lb').click(); await tick(); await tick();
  assert.equal(calls.find(c=>c.u==='/api/login'&&c.b.c).b.c,'123456'); assert.equal(get('#app').classList.contains('hide'),false); assert.match(get('#who').textContent,/sara.*🔒/);
});
await t('الدخول الخاطئ: 401 و429 رسائل مختلفة', async()=>{
  const lock=run('({})'); void lock; run("document.querySelector('#auth').classList.remove('hide')");
  run("me=null"); get('#lc').classList.add('hide'); get('#lu').value='x'; get('#lp').value='y';
  routes['POST /api/login']=()=>({s:401,j:{e:'invalid credentials'}}); await get('#lb').click(); await tick(); assert.match(get('#le').textContent,/غير صحيحة/);
  routes['POST /api/login']=()=>({s:429,j:{e:'too many'}}); await get('#lb').click(); await tick(); assert.match(get('#le').textContent,/كثيرة/);
});
await t('الطرفية: تعرّف تلقائي + حفظ تلقائي في الحالة النشطة + سجل البحث', async()=>{
  run("me={n:'sara',r:'user',f:true}; activeCase=7; cases=[{id:7,title:'Case A',status:'open'}]; custom=[]");
  routes['POST /api/search']=()=>({s:200,j:{ok:1}}); routes['GET /api/history']=()=>({s:200,j:[{type:'domain',value:'example.com'}]});
  routes['POST /api/cases/7/items']=()=>({s:200,j:{id:1}}); get('#out').innerHTML=''; calls.length=0;
  await run("run('example.com')"); await tick();
  assert.ok(calls.some(c=>c.u==='/api/search'&&c.b.t==='domain'&&c.b.v==='example.com'));
  const it=calls.find(c=>c.u==='/api/cases/7/items'); assert.deepEqual(it.b,{kind:'search',type:'domain',value:'example.com'});
  assert.match(get('#out').innerHTML,/\[auto\] domain/); assert.match(get('#out').innerHTML,/saved to case: Case A/); assert.match(get('#out').innerHTML,/crt\.sh/);
  assert.match(get('#hs').innerHTML,/domain: example\.com/);
});
await t('الطرفية: لا تنفّذ HTML من القيمة (XSS) ولا روابط خطيرة', async()=>{
  run("activeCase=0"); get('#out').innerHTML=''; await run(`run('user <img src=x onerror=alert(1)>')`); await tick();
  const h=get('#out').innerHTML; assert.ok(!/<img/.test(h)); assert.match(h,/&lt;img/);
  get('#out').innerHTML=''; await run("run('hlep')"); assert.match(get('#out').innerHTML,/command not found: hlep/);
  get('#out').innerHTML=''; await run("run('note x')"); assert.match(get('#out').innerHTML,/اختر حالة نشطة/);
});
await t('caseMd: تقرير Markdown من الحالة', ()=>{
  const md=run(`caseMd({case:{title:'T',target:'ex.com',status:'open',created_at:'2026-01-01'},items:[{kind:'search',type:'cve',value:'CVE-2024-3094',created_at:'t1'},{kind:'note',text:'سطر1\\nسطر2',created_at:'t2'},{kind:'link',value:'https://a.com',text:'A',created_at:'t3'}]})`);
  assert.match(md,/^# T/); assert.match(md,/## Search — cve: CVE-2024-3094/); assert.match(md,/\[NVD\]\(https:\/\/nvd\.nist\.gov\/vuln\/detail\/CVE-2024-3094\)/); assert.match(md,/> سطر1\n> سطر2/); assert.match(md,/\[A\]\(https:\/\/a\.com\)/);
});
await t('الحالات: فتح حالة وعرض العناصر وتهريب النص', async()=>{
  routes['GET /api/cases/7']=()=>({s:200,j:{case:{id:7,title:'<b>x</b>',target:'t',status:'open',created_at:'c'},items:[{id:1,kind:'note',text:'<script>1</script>',created_at:'x'},{id:2,kind:'link',value:'javascript:alert(1)',text:'bad',created_at:'x'},{id:3,kind:'search',type:'ip',value:'1.1.1.1',created_at:'x'}]}});
  await run('openCase(7)'); const h=get('#kd').innerHTML;
  assert.ok(!/<script>1/.test(h)&&!/<b>x<\/b>/.test(h)); assert.ok(!/href="javascript:/.test(h)); assert.match(h,/shodan\.io\/host\/1\.1\.1\.1/);
});
await t('2FA: setup ثم enable يعرض رموز الاسترجاع ويحدّث الحالة', async()=>{
  run("me={n:'sara',r:'user',f:false}; renderTwoFA()"); assert.match(get('#tf').innerHTML,/ENABLE 2FA/);
  routes['POST /api/me/2fa/setup']=()=>({s:200,j:{secret:'ABCDEFGHIJKLMNOP',uri:'otpauth://totp/OSINT%20Hub:sara?secret=ABCDEFGHIJKLMNOP'}});
  await get('#tf').onclick({target:{id:'fs'}}); assert.match(get('#tf').innerHTML,/ABCDEFGHIJKLMNOP/); assert.match(get('#tf').innerHTML,/href="otpauth:\/\/totp\//);
  routes['POST /api/me/2fa/enable']=()=>({s:200,j:{codes:['aaaaa-bbbbb','ccccc-ddddd']}}); get('#f3').value='123456';
  await get('#tf').onclick({target:{id:'fe2'}}); assert.equal(run('me.f'),true); assert.match(get('#tf').innerHTML,/aaaaa-bbbbb/);
  run("renderTwoFA()"); assert.match(get('#tf').innerHTML,/DISABLE 2FA/);
});
await t('الثيم', ()=>{ run("theme('amber')"); assert.equal(document.documentElement.dataset.theme,'amber'); run("theme('bogus')"); assert.equal(document.documentElement.dataset.theme,''); assert.equal(ctx.localStorage.getItem('osint_theme'),'cyan'); });
