cat ~/islam/99-names.txt | less
