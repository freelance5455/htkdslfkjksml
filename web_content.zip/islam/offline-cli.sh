#!/bin/bash
while true; do
clear
echo "========================================"
echo "   ☪  BISMILLAH  ☪"
echo "   forkde_lit ISLAM APK"
echo "   100% OFFLINE - HALAL"
echo "========================================"
echo "1. Ayatul Kursi 2:255 [AUDIO+TEXT]"
echo "2. Anti-Sihr 2:102 [AUDIO+TEXT]"
echo "3. 99 Names [AUDIO+TEXT]"
echo "4. 10 Duas [TEXT ONLY]"
echo "5. Exit"
echo "========================================"
read -p "Choose 1-5: " c
clear
case $c in
 1) echo ">>> Ayatul Kursi 2:255 <<<"; mpv ~/islam/audio/2-255.mp3 --no-video 2>/dev/null & cat ~/islam/duas/10-duas.txt | head -20; wait ;;
 2) echo ">>> Anti-Sihr 2:102 <<<"; mpv ~/islam/audio/2-102.mp3 --no-video 2>/dev/null & cat ~/islam/duas/10-duas.txt; wait ;;
 3) echo ">>> 99 Names <<<"; mpv ~/islam/audio/99-names.mp3 --no-video 2>/dev/null & cat ~/islam/99-names-clean.txt; wait ;;
 4) cat ~/islam/duas/10-duas.txt | less ;;
 5) exit ;;
esac
read -p "Press Enter..."
done
