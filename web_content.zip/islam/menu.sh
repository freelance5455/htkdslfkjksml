#!/bin/bash
while true; do
clear
echo "=== OFFLINE ISLAM ==="
echo "1. Ayatul Kursi 2:255 audio"
echo "2. Surah 2:102 audio"
echo "3. Play 10 Duas (shuffle)"
echo "4. List 10 Duas TEXT"
echo "5. Play one Dua by name"
echo "6. Exit"
read -p "Choose: " c
case $c in
 1) mpv ~/islam/audio/2-255.mp3 ;;
 2) mpv ~/islam/audio/2-102.mp3 ;;
 3) mpv ~/islam/duas/ --shuffle ;;
 4) cat ~/islam/duas/10-duas.txt | less ;;
 5) ls ~/islam/duas/*.mp3; read -p "Name (e.g. 01-morning): " n; mpv ~/islam/duas/$n.mp3 ;;
 6) exit ;;
esac
read -p "Enter..."
done
