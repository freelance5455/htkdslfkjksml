/* JOSTECH — COURS 05 : INTELLIGENCE ARTIFICIELLE (NIVEAUX 1, 2 & 3) */
registerDisciplineLevels(5, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Histoire de l'IA, IA symbolique et approche par apprentissage.",
    chapters: [{
      id: "ia-1-1", title: "Chapitre 1 : Fondements de l'Intelligence Artificielle",
      lessons: [{
        id: "ia-1-1-1", title: "Leçon 1 : IA Symbolique vs Machine Learning", duration: "25 min",
        objectives: ["Définir l'IA (Test de Turing, Dartmouth 1956).", "Distinguer systèmes à règles (symboliques) et apprentissage statistique."],
        prerequisites: ["Notions d'algorithmique."],
        sections: [
          { type: "definition", term: "Intelligence Artificielle (IA)", text: "Domaine scientifique visant à concevoir des systèmes capables de réaliser des tâches nécessitant normalement l'intelligence humaine : perception visuelle, compréhension du langage, raisonnement et prise de décision." },
          { type: "theory", title: "Deux grandes approches", text: "Dans l'IA symbolique (systèmes experts), l'ingénieur écrit explicitement toutes les règles logiques (SI fièvre ET toux ALORS diagnostic). C'est exact mais impossible à écrire pour reconnaître un visage sur une photo ! Dans le Machine Learning, on fournit des milliers d'exemples à un algorithme statistique pour qu'il découvre lui-même les motifs." }
        ],
        exercise: {
          question: "Pour calculer la note /20 d'un QCM et pour reconnaître automatiquement l'écriture manuscrite d'un étudiant, quelle approche (Règles classiques ou Machine Learning) choisissez-vous pour chaque tâche ?",
          solution: "1) Calculer la note /20 : programmation classique déterministe (règles exactes).\n2) Reconnaître l'écriture manuscrite : Machine Learning, car chaque personne écrit différemment."
        },
        summary: "L'IA symbolique excelle quand les règles sont claires ; le Machine Learning s'impose face aux données complexes (images, voix, textes).",
        references: ["Russell, S. & Norvig, P. — Artificial Intelligence: A Modern Approach."]
      }]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Apprentissage supervisé, non supervisé et généralisation.",
    chapters: [{
      id: "ia-2-1", title: "Chapitre 2 : Paradigmes du Machine Learning",
      lessons: [{
        id: "ia-2-1-1", title: "Leçon 1 : Supervisé, Non-Supervisé et Overfitting", duration: "30 min",
        objectives: ["Classer un problème en Régression, Classification ou Clustering.", "Diagnostiquer et prévenir le surapprentissage (Overfitting)."],
        prerequisites: ["Niveau 1 IA et Python."],
        sections: [
          { type: "table", title: "Les 3 familles du Machine Learning", headers: ["Type", "Données", "Exemples concrets"], rows: [
            ["Supervisé", "Étiquetées (Entrée + Réponse)", "Classification (Spam/Non-spam), Régression (Prédire un prix)."],
            ["Non supervisé", "Non étiquetées", "Clustering (Regrouper des profils d'étudiants par habitudes)."],
            ["Renforcement", "Récompenses / Pénalités", "Robot apprenant à marcher ou IA jouant aux échecs."]
          ]},
          { type: "warning", title: "Le piège du Surapprentissage (Overfitting)", text: "Un modèle qui apprend par cœur les données d'entraînement (sans comprendre la règle générale) obtient 99 % sur ses exercices connus mais échoue sur de nouvelles données réelles. On sépare donc toujours les données en jeu d'Entraînement (80 %) et jeu de Test (20 %)." }
        ],
        exercise: {
          question: "Un modèle obtient 99 % de précision sur ses données d'entraînement mais seulement 54 % sur le jeu de test. Quel est ce phénomène et citez 2 solutions ?",
          solution: "C'est du surapprentissage (Overfitting). Solutions : collecter plus de données variées, simplifier le modèle ou appliquer une régularisation / validation croisée."
        },
        summary: "La vraie qualité d'un modèle ML se mesure uniquement sur des données inédites (jeu de Test) qu'il n'a jamais vues durant l'entraînement.",
        references: ["Géron, A. — Machine Learning avec Scikit-Learn et TensorFlow."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Deep Learning, Transformers, IA Générative et Ingénierie des Prompts.",
    chapters: [{
      id: "ia-3-1", title: "Chapitre 3 : Réseaux de Neurones & LLM",
      lessons: [{
        id: "ia-3-1-1", title: "Leçon 1 : Deep Learning, Attention et Prompt Engineering", duration: "30 min",
        objectives: ["Comprendre couches profondes et rétropropagation.", "Concevoir des prompts structurés et évaluer les hallucinations."],
        prerequisites: ["Niveau 2 — Machine Learning."],
        sections: [
          { type: "theory", title: "Des réseaux de neurones aux Transformers", text: "Le Deep Learning empile de multiples couches de neurones artificiels ajustant leurs poids mathématiques par rétropropagation du gradient. En Vision par ordinateur, les CNN détectent contours puis objets. En Langage (NLP), l'architecture Transformer (2017) et son mécanisme d'Attention prédisent le mot suivant le plus probable selon tout le contexte, donnant naissance aux Grands Modèles de Langage (LLM) et à l'IA générative." },
          { type: "code", lang: "Prompt Engineering — Structure professionnelle (RTCF)", code: "Rôle       : Tu es professeur universitaire en réseaux.\nTâche      : Explique le routage IP à un étudiant L1.\nContraintes: Maximum 150 mots, avec 1 analogie postale.\nFormat     : Titre + 3 points clés." }
        ],
        exercise: {
          question: "Pourquoi un LLM peut-il inventer une fausse référence bibliographique avec assurance (Hallucination) ?",
          solution: "Parce qu'un LLM est un modèle probabiliste qui génère la suite de mots la plus plausible statistiquement, et non une base de données vérifiée : il faut toujours vérifier ses sources critiques."
        },
        summary: "Le Deep Learning et les Transformers révolutionnent vision et langage, mais exigent un esprit critique humain et des prompts précis.",
        references: ["Vaswani, A. et al. (2017) — Attention Is All You Need."]
      }]
    }]
  }
});