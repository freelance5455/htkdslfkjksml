QUIZ MASTER — Endless No-Repeat Edition

This version fixes the repeating-question problem.

FIXES
- Near-duplicate wording such as “Which club...” / “Which team...” is treated as the same question.
- Offline mode removes duplicate facts from the playable question bank.
- Offline questions do not repeat until the unique bank for that category is exhausted.
- Online mode keeps a persistent history of canonical question keys.
- Online mode requests larger batches and blocks reworded duplicates.
- Online mode remains endless while the internet/API can supply new questions.
- If online loading fails, the app falls back to the stored category bank without intentionally repeating until that bank is exhausted.
- Works as a single HTML file and can be packaged by an APK builder.

IMPORTANT
The no-repeat history is stored in the app/browser local storage. Clearing app data/storage resets the history.
