-- Faragooya Arena Features: private rooms + visible emote events
-- Additive migration. Run in Supabase SQL Editor. Does not alter existing tables.
create extension if not exists pgcrypto;
create table if not exists public.fg_private_rooms (
 id uuid primary key default gen_random_uuid(),
 room_code text not null unique check (room_code ~ '^FG-[A-Z0-9]{3}-[A-Z0-9]{3}$'),
 host_id uuid not null references auth.users(id) on delete cascade,
 guest_id uuid references auth.users(id) on delete set null,
 status text not null default 'waiting' check(status in ('waiting','ready','playing','finished','cancelled')),
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default now()+interval '2 hours'
);
create index if not exists fg_private_rooms_host_idx on public.fg_private_rooms(host_id,created_at desc);
create index if not exists fg_private_rooms_guest_idx on public.fg_private_rooms(guest_id,created_at desc);
alter table public.fg_private_rooms enable row level security;
drop policy if exists fg_rooms_read_members on public.fg_private_rooms;
create policy fg_rooms_read_members on public.fg_private_rooms for select to authenticated using(auth.uid()=host_id or auth.uid()=guest_id);
drop policy if exists fg_rooms_create_host on public.fg_private_rooms;
create policy fg_rooms_create_host on public.fg_private_rooms for insert to authenticated with check(auth.uid()=host_id);
create or replace function public.fg_room_create()
returns table(room_id uuid, room_code text, expires_at timestamptz)
language plpgsql security definer set search_path=public,pg_temp as $$
declare v_id uuid; v_code text;
begin
 if auth.uid() is null then raise exception 'login_required'; end if;
 loop
  v_code:='FG-'||upper(substr(encode(gen_random_bytes(3),'hex'),1,3))||'-'||upper(substr(encode(gen_random_bytes(3),'hex'),1,3));
  exit when not exists(select 1 from public.fg_private_rooms r where r.room_code=v_code and r.expires_at>now());
 end loop;
 insert into public.fg_private_rooms(room_code,host_id) values(v_code,auth.uid()) returning id into v_id;
 return query select r.id,r.room_code,r.expires_at from public.fg_private_rooms r where r.id=v_id;
end $$;
create or replace function public.fg_room_join(p_room_code text)
returns table(room_id uuid, room_code text, status text)
language plpgsql security definer set search_path=public,pg_temp as $$
declare v_id uuid;
begin
 if auth.uid() is null then raise exception 'login_required'; end if;
 select r.id into v_id from public.fg_private_rooms r where r.room_code=upper(trim(p_room_code)) and r.status='waiting' and r.expires_at>now() and r.host_id<>auth.uid() for update;
 if v_id is null then raise exception 'room_not_available'; end if;
 update public.fg_private_rooms set guest_id=auth.uid(),status='ready' where id=v_id and guest_id is null;
 if not found then raise exception 'room_already_joined'; end if;
 return query select r.id,r.room_code,r.status from public.fg_private_rooms r where r.id=v_id;
end $$;
grant execute on function public.fg_room_create() to authenticated;
grant execute on function public.fg_room_join(text) to authenticated;
create table if not exists public.fg_duel_emote_events(
 id bigint generated always as identity primary key,
 room_id uuid not null references public.fg_private_rooms(id) on delete cascade,
 sender_id uuid not null references auth.users(id) on delete cascade,
 emote_id text not null check(length(emote_id) between 1 and 64),
 created_at timestamptz not null default now()
);
create index if not exists fg_emote_room_time_idx on public.fg_duel_emote_events(room_id,created_at desc);
alter table public.fg_duel_emote_events enable row level security;
drop policy if exists fg_emote_read_room_members on public.fg_duel_emote_events;
create policy fg_emote_read_room_members on public.fg_duel_emote_events for select to authenticated using(exists(select 1 from public.fg_private_rooms r where r.id=room_id and (r.host_id=auth.uid() or r.guest_id=auth.uid())));
create or replace function public.fg_duel_send_emote(p_room_id uuid,p_emote_id text)
returns bigint language plpgsql security definer set search_path=public,pg_temp as $$
declare v_event bigint;
begin
 if auth.uid() is null then raise exception 'login_required'; end if;
 if not exists(select 1 from public.fg_private_rooms r where r.id=p_room_id and (r.host_id=auth.uid() or r.guest_id=auth.uid()) and r.status in ('ready','playing') and r.expires_at>now()) then raise exception 'not_room_member'; end if;
 if length(p_emote_id)<1 or length(p_emote_id)>64 then raise exception 'invalid_emote'; end if;
 insert into public.fg_duel_emote_events(room_id,sender_id,emote_id) values(p_room_id,auth.uid(),p_emote_id) returning id into v_event;
 return v_event;
end $$;
grant execute on function public.fg_duel_send_emote(uuid,text) to authenticated;
-- Enable Realtime on events table in Dashboard if you want instant push updates.
