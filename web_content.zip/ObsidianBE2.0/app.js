const themeButton=document.getElementById('theme');
if(localStorage.getItem('obsidian-theme')==='light') document.body.classList.add('light');
themeButton.addEventListener('click',()=>{document.body.classList.toggle('light');localStorage.setItem('obsidian-theme',document.body.classList.contains('light')?'light':'dark')});
document.getElementById('status').textContent='Натисни кнопку запуску. Якщо Minecraft не відкрився, запусти його зі свого меню програм.';
