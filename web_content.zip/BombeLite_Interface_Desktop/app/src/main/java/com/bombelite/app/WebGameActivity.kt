package com.bombelite.app

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Opens user-provided HTTPS HTML5 games in an isolated WebView without the launcher's JS bridge. */
class WebGameActivity : Activity() {
    private var gameWebView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rawUrl = intent.getStringExtra(EXTRA_GAME_URL).orEmpty()
        val gameUri = runCatching { Uri.parse(rawUrl) }.getOrNull()
        if (gameUri == null || gameUri.scheme?.equals("https", ignoreCase = true) != true || gameUri.host.isNullOrBlank() || !gameUri.userInfo.isNullOrBlank()) {
            Toast.makeText(this, "Informe um link HTTPS válido para o jogo.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        window.statusBarColor = Color.rgb(5, 11, 20)
        window.navigationBarColor = Color.rgb(5, 11, 20)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(5, 11, 20))
        }
        val toolbar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setBackgroundColor(Color.rgb(10, 21, 36))
        }
        val backButton = Button(this).apply {
            text = "‹ Bombe Lite"
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = "Jogo web"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val reloadButton = Button(this).apply {
            text = "↻"
            contentDescription = "Recarregar jogo"
            setOnClickListener { gameWebView?.reload() }
        }
        toolbar.addView(backButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        toolbar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        toolbar.addView(reloadButton, LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT))

        val browser = WebView(this)
        gameWebView = browser
        browser.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
        }
        browser.webViewClient = object : WebViewClient() {
            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (Uri.parse(url).scheme?.equals("https", ignoreCase = true) == true) return false
                Toast.makeText(this@WebGameActivity, "Por segurança, só links HTTPS são abertos aqui.", Toast.LENGTH_SHORT).show()
                return true
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.scheme?.equals("https", ignoreCase = true) == true) return false
                Toast.makeText(this@WebGameActivity, "Por segurança, só links HTTPS são abertos aqui.", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        browser.webChromeClient = WebChromeClient()

        root.addView(toolbar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        root.addView(browser, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        browser.loadUrl(gameUri.toString())
    }

    @Deprecated("Use the Bombe Lite toolbar to return to the launcher")
    override fun onBackPressed() {
        finish()
    }

    override fun onDestroy() {
        gameWebView?.apply {
            stopLoading()
            loadUrl("about:blank")
            removeAllViews()
            destroy()
        }
        gameWebView = null
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_GAME_URL = "com.bombelite.app.extra.WEB_GAME_URL"
    }
}
