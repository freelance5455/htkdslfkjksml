package com.bombelite.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.provider.ContactsContract
import android.content.pm.PackageManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val discoveredDevices = linkedMapOf<String, BluetoothDevice>()
    private var bluetoothReceiverRegistered = false
    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    try {
                        val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                        if (device != null) {
                            val address = device.address
                            discoveredDevices[address] = device
                            refreshBluetoothPage()
                        }
                    } catch (_: SecurityException) {
                        showBluetoothMessage("Permissão de dispositivos próximos necessária.")
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    showBluetoothMessage("Busca concluída. Toque em um dispositivo para parear.")
                    refreshBluetoothPage()
                }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> refreshBluetoothPage()
                BluetoothDevice.ACTION_ACL_CONNECTED,
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    try {
                        val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                        val connected = intent.action == BluetoothDevice.ACTION_ACL_CONNECTED
                        val name = try { device?.name } catch (_: SecurityException) { null }
                            ?: "Dispositivo Bluetooth"
                        notifyBluetoothConnectionChange(connected, name)
                    } catch (_: SecurityException) {
                        showBluetoothMessage("Não foi possível ler o estado da conexão Bluetooth.")
                    }
                    refreshBluetoothPage()
                }
            }
        }
    }

    private var wifiReceiverRegistered = false
    private val wifiScanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == WifiManager.SCAN_RESULTS_AVAILABLE_ACTION) {
                val updated = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false)
                publishWifiNetworks(updated)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.statusBarColor = Color.rgb(5, 11, 20)
        window.navigationBarColor = Color.rgb(5, 11, 20)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(5, 11, 20))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(), "AndroidApp")
        }
        setContentView(webView)
        registerBluetoothReceiver()
        registerWifiReceiver()
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        if (bluetoothReceiverRegistered) {
            try { unregisterReceiver(bluetoothReceiver) } catch (_: IllegalArgumentException) { }
            bluetoothReceiverRegistered = false
        }
        try { bluetoothAdapter()?.cancelDiscovery() } catch (_: SecurityException) { }
        if (wifiReceiverRegistered) {
            try { unregisterReceiver(wifiScanReceiver) } catch (_: IllegalArgumentException) { }
            wifiReceiverRegistered = false
        }
        super.onDestroy()
    }

    private fun registerBluetoothReceiver() {
        val filter = android.content.IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(bluetoothReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(bluetoothReceiver, filter)
        }
        bluetoothReceiverRegistered = true
    }

    private fun registerWifiReceiver() {
        val filter = android.content.IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(wifiScanReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(wifiScanReceiver, filter)
        }
        wifiReceiverRegistered = true
    }

    private fun wifiManager(): WifiManager? =
        applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private fun requiredWifiScanPermissions(): Array<String> {
        val requested = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requested.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        return requested.distinct().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
    }

    private fun startWifiScan() {
        val manager = wifiManager()
        if (manager == null) {
            showWifiStatus("Wi-Fi indisponível neste aparelho.")
            return
        }
        val missing = requiredWifiScanPermissions()
        if (missing.isNotEmpty()) {
            showWifiStatus("Permita acesso à localização e a dispositivos Wi-Fi próximos para buscar redes.")
            requestPermissions(missing, WIFI_SCAN_PERMISSION_REQUEST)
            return
        }
        try {
            if (!manager.isWifiEnabled) {
                showWifiStatus("Ative o Wi-Fi para procurar redes próximas.")
                openWifiSettings()
                return
            }
            if (manager.startScan()) {
                showWifiStatus("Procurando redes Wi-Fi próximas...")
            } else {
                showWifiStatus("O Android limitou uma nova varredura; tentando mostrar resultados recentes.")
                publishWifiNetworks(false)
            }
        } catch (_: SecurityException) {
            showWifiStatus("Permissão de localização ou Wi-Fi necessária para obter os resultados.")
        } catch (_: Exception) {
            showWifiStatus("Não foi possível iniciar a busca Wi-Fi. Tente nas configurações do Android.")
        }
    }

    private fun publishWifiNetworks(resultsUpdated: Boolean) {
        try {
            val results = wifiManager()?.scanResults.orEmpty().sortedByDescending { it.level }
            val networks = JSONArray()
            val seen = mutableSetOf<String>()
            results.forEach { result ->
                val name = result.SSID?.takeIf { it.isNotBlank() } ?: "Rede oculta"
                val key = "$name|${result.BSSID.orEmpty()}"
                if (seen.add(key)) {
                    networks.put(JSONObject().put("nome", name).put("sinal", result.level))
                }
            }
            val status = when {
                networks.length() == 0 -> "Nenhuma rede retornada. Verifique se Wi-Fi e localização estão ativados e tente novamente."
                resultsUpdated -> "Busca concluída: ${networks.length()} rede(s) encontrada(s)."
                else -> "O Android limitou a nova busca; exibindo resultados recentes (${networks.length()} rede(s))."
            }
            val script = "window.updateWifiNetworks && window.updateWifiNetworks(${JSONObject.quote(networks.toString())}, ${JSONObject.quote(status)});"
            if (::webView.isInitialized) runOnUiThread { webView.evaluateJavascript(script, null) }
        } catch (_: SecurityException) {
            showWifiStatus("O Android não liberou os resultados. Confirme as permissões de Wi-Fi e localização.")
        } catch (_: Exception) {
            showWifiStatus("Não foi possível ler os resultados da busca Wi-Fi.")
        }
    }

    private fun showWifiStatus(message: String) {
        if (::webView.isInitialized) {
            val script = "window.setWifiScanState && window.setWifiScanState(${JSONObject.quote(message)});"
            runOnUiThread { webView.evaluateJavascript(script, null) }
        }
    }

    private fun homeStatusJson(): String {
        val batteryIntent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val batteryLevel = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val batteryScale = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryKnown = batteryLevel >= 0 && batteryScale > 0
        val batteryPercent = if (batteryKnown) (batteryLevel * 100 / batteryScale).coerceIn(0, 100) else 0
        val storage = StatFs(Environment.getDataDirectory().path)
        val wifiEnabled = try { wifiManager()?.isWifiEnabled == true } catch (_: Exception) { false }
        val wifiConnected = try {
            val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            manager.getNetworkCapabilities(manager.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (_: Exception) { false }
        val bluetoothEnabled: Boolean? = try { bluetoothAdapter()?.isEnabled } catch (_: SecurityException) { null }
        return JSONObject()
            .put("batteryKnown", batteryKnown)
            .put("batteryPercent", batteryPercent)
            .put("storageFreeBytes", storage.availableBytes)
            .put("storageTotalBytes", storage.totalBytes)
            .put("wifiEnabled", wifiEnabled)
            .put("wifiConnected", wifiConnected)
            .put("bluetoothKnown", bluetoothEnabled != null)
            .put("bluetoothEnabled", bluetoothEnabled == true)
            .toString()
    }

    private fun refreshBluetoothPage() {
        if (::webView.isInitialized) {
            runOnUiThread {
                webView.evaluateJavascript("window.refreshBluetoothScreen && window.refreshBluetoothScreen();", null)
            }
        }
    }

    private fun showBluetoothMessage(message: String) {
        if (::webView.isInitialized) {
            runOnUiThread {
                val safe = JSONObject.quote(message)
                webView.evaluateJavascript("window.setBluetoothMessage && window.setBluetoothMessage($safe);", null)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.refreshBluetoothScreen && window.refreshBluetoothScreen();", null)
            webView.evaluateJavascript("window.refreshHomeStatus && window.refreshHomeStatus();", null)
        }
    }

    private fun notifyBluetoothConnectionChange(connected: Boolean, name: String) {
        if (::webView.isInitialized) {
            runOnUiThread {
                val safeName = JSONObject.quote(name)
                webView.evaluateJavascript(
                    "window.bluetoothConnectionChanged && window.bluetoothConnectionChanged($connected, $safeName);",
                    null
                )
            }
        }
    }

    private fun bluetoothAdapter(): BluetoothAdapter? =
        getSystemService(BluetoothManager::class.java)?.adapter

    private fun bluetoothDeviceKind(device: BluetoothDevice): String {
        val deviceClass = try { device.bluetoothClass?.deviceClass } catch (_: SecurityException) { null }
        return when (deviceClass) {
            BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES,
            BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET -> "Fones de ouvido"
            BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER -> "Caixas de som"
            else -> {
                val name = try { device.name.orEmpty().lowercase() } catch (_: SecurityException) { "" }
                when {
                    listOf("fone", "headphone", "headset", "earbud", "airpod", "earphone").any { name.contains(it) } -> "Fones de ouvido"
                    listOf("caixa", "speaker", "soundbar", "alto-falante", "boombox").any { name.contains(it) } -> "Caixas de som"
                    else -> "Outros dispositivos"
                }
            }
        }
    }

    private fun hasBluetoothConnectPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun bluetoothStateJson(): String {
        val adapter = bluetoothAdapter()
        if (adapter == null) {
            return JSONObject()
                .put("available", false)
                .put("enabled", false)
                .put("permission", true)
                .put("paired", JSONArray())
                .put("discovered", JSONArray())
                .toString()
        }
        if (!hasBluetoothConnectPermission()) {
            return JSONObject()
                .put("available", true)
                .put("enabled", false)
                .put("permission", false)
                .put("paired", JSONArray())
                .put("discovered", JSONArray())
                .toString()
        }
        return try {
            val paired = JSONArray()
            val enabled = adapter.isEnabled
            if (enabled) {
                adapter.bondedDevices.orEmpty().forEach { device ->
                    val item = JSONObject()
                    val name = try { device.name } catch (_: SecurityException) { null }
                    item.put("name", name ?: "Dispositivo Bluetooth")
                    item.put("address", try { device.address } catch (_: SecurityException) { "" })
                    item.put("bonded", true)
                    item.put("kind", bluetoothDeviceKind(device))
                    paired.put(item)
                }
            }
            val discovered = JSONArray()
            if (enabled) {
                val bondedAddresses = adapter.bondedDevices.orEmpty().mapNotNull { device ->
                    try { device.address } catch (_: SecurityException) { null }
                }.toSet()
                discoveredDevices.forEach { (address, device) ->
                    if (!bondedAddresses.contains(address)) {
                        val item = JSONObject()
                        item.put("name", try { device.name } catch (_: SecurityException) { null } ?: "Dispositivo Bluetooth")
                        item.put("address", address)
                        item.put("bonded", false)
                        item.put("kind", bluetoothDeviceKind(device))
                        discovered.put(item)
                    }
                }
            }
            JSONObject()
                .put("available", true)
                .put("enabled", enabled)
                .put("permission", true)
                .put("paired", paired)
                .put("discovered", discovered)
                .toString()
        } catch (_: SecurityException) {
            JSONObject()
                .put("available", true)
                .put("enabled", false)
                .put("permission", false)
                .put("paired", JSONArray())
                .toString()
        }
    }

    private fun requiredBluetoothPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                .toTypedArray()
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        } else emptyArray()

    private fun requestBluetoothConnectPermission() {
        val missing = requiredBluetoothPermissions()
        if (missing.isNotEmpty()) {
            requestPermissions(missing, BLUETOOTH_PERMISSION_REQUEST)
        } else {
            refreshBluetoothPage()
        }
    }

    private fun enableBluetooth() {
        val adapter = bluetoothAdapter()
        if (adapter == null) {
            showBluetoothMessage("Bluetooth indisponível neste aparelho.")
            return
        }
        try {
            if (adapter.isEnabled) {
                showBluetoothMessage("Bluetooth já está ativado.")
            } else {
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            }
        } catch (_: SecurityException) {
            showBluetoothMessage("Permita o acesso a dispositivos próximos para ativar o Bluetooth.")
        } catch (_: ActivityNotFoundException) {
            openBluetoothSettings()
        }
    }

    private fun startBluetoothScan() {
        val adapter = bluetoothAdapter()
        if (adapter == null) {
            showBluetoothMessage("Bluetooth indisponível neste aparelho.")
            return
        }
        val missing = requiredBluetoothPermissions()
        if (missing.isNotEmpty()) {
            requestPermissions(missing, BLUETOOTH_SCAN_PERMISSION_REQUEST)
            return
        }
        try {
            if (!adapter.isEnabled) {
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                showBluetoothMessage("Ative o Bluetooth para iniciar a busca.")
                return
            }
            discoveredDevices.clear()
            refreshBluetoothPage()
            if (adapter.isDiscovering) adapter.cancelDiscovery()
            if (adapter.startDiscovery()) {
                showBluetoothMessage("Procurando dispositivos próximos...")
            } else {
                showBluetoothMessage("Não foi possível iniciar a busca. Tente novamente.")
            }
        } catch (_: SecurityException) {
            showBluetoothMessage("Permita o acesso a dispositivos próximos e tente novamente.")
        } catch (_: ActivityNotFoundException) {
            openBluetoothSettings()
        }
    }

    private fun stopBluetoothScan() {
        try {
            val adapter = bluetoothAdapter()
            if (adapter == null) {
                showBluetoothMessage("Bluetooth indisponível neste aparelho.")
                return
            }
            if (!hasBluetoothConnectPermission()) {
                requestBluetoothConnectPermission()
                return
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN), BLUETOOTH_PERMISSION_REQUEST)
                return
            }
            if (adapter.isDiscovering) {
                adapter.cancelDiscovery()
                showBluetoothMessage("Busca Bluetooth interrompida.")
            } else {
                showBluetoothMessage("Não há busca Bluetooth em andamento.")
            }
        } catch (_: SecurityException) {
            showBluetoothMessage("Permita o acesso a dispositivos próximos para controlar a busca.")
        }
    }

    private fun disconnectBluetoothDevice(address: String) {
        // Android não oferece uma API pública genérica para desconectar qualquer perfil.
        // Encaminha ao painel do sistema, onde o usuário pode desconectar com segurança.
        showBluetoothMessage("Desconecte este dispositivo nas configurações Bluetooth do Android.")
        openBluetoothSettings()
    }

    private fun pairBluetoothDevice(address: String) {
        if (!hasBluetoothConnectPermission()) {
            requestBluetoothConnectPermission()
            return
        }
        try {
            val adapter = bluetoothAdapter() ?: return
            val device = discoveredDevices[address] ?: adapter.bondedDevices.firstOrNull { it.address == address }
            if (device == null) {
                showBluetoothMessage("Dispositivo não encontrado. Faça uma nova busca.")
                return
            }
            if (device.bondState == BluetoothDevice.BOND_BONDED) {
                openBluetoothSettings()
                return
            }
            if (!device.createBond()) showBluetoothMessage("O pareamento não foi iniciado. Tente novamente.")
            else showBluetoothMessage("Confirme o pareamento na janela do Android.")
        } catch (_: SecurityException) {
            showBluetoothMessage("Permita o acesso a dispositivos próximos para parear.")
        }
    }

    @Deprecated("Use Activity Result APIs for new permission flows")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == BLUETOOTH_SCAN_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                startBluetoothScan()
            } else {
                showBluetoothMessage("Permissão de dispositivos próximos não concedida.")
            }
        } else if (requestCode == BLUETOOTH_PERMISSION_REQUEST) {
            refreshBluetoothPage()
        } else if (requestCode == WIFI_SCAN_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                startWifiScan()
            } else {
                showWifiStatus("Permissão não concedida; abra as configurações de Wi-Fi para procurar redes.")
            }
        }
    }

    private fun launchFromMenu(id: String) {
        when (id) {
            "install_apk" -> requestApkInstall()
            "whatsapp" -> openWhatsAppChat()
            "youtube" -> launchPackage("com.google.android.youtube", "YouTube", "https://www.youtube.com")
            "playstore" -> launchPackage("com.android.vending", "Play Store", "https://play.google.com/store")
            "google" -> launchPackage("com.google.android.googlequicksearchbox", "Google", "https://www.google.com")
            "gmail" -> launchPackage("com.google.android.gm", "Gmail", "https://mail.google.com")
            "chrome" -> launchPackage("com.android.chrome", "Chrome", "https://www.google.com/")
            "instagram" -> launchPackage("com.instagram.android", "Instagram", storePackage = "com.instagram.android")
            "tiktok" -> launchPackage("com.zhiliaoapp.musically", "TikTok", storePackage = "com.zhiliaoapp.musically")
            "discord" -> launchPackage("com.discord", "Discord", storePackage = "com.discord")
            "telegram" -> launchPackage("org.telegram.messenger", "Telegram", storePackage = "org.telegram.messenger")
            "netflix" -> launchPackage("com.netflix.mediaclient", "Netflix", storePackage = "com.netflix.mediaclient")
            "spotify" -> launchPackage("com.spotify.music", "Spotify", storePackage = "com.spotify.music")
            "facebook" -> launchPackage("com.facebook.katana", "Facebook", storePackage = "com.facebook.katana")
            "amazon" -> launchPackage("com.amazon.mShop.android.shopping", "Amazon", storePackage = "com.amazon.mShop.android.shopping")
            "roblox" -> launchPackage("com.roblox.client", "Roblox", storePackage = "com.roblox.client")
            "freefire" -> launchPackage("com.dts.freefireth", "Free Fire", storePackage = "com.dts.freefireth")
            "minecraft" -> launchPackage("com.mojang.minecraftpe", "Minecraft", storePackage = "com.mojang.minecraftpe")
            "gta_sa" -> launchPackage("com.rockstargames.gtasa", "GTA: San Andreas", storePackage = "com.rockstargames.gtasa")
            "stumble_guys" -> launchPackage("com.kitkagames.fallbuddies", "Stumble Guys", storePackage = "com.kitkagames.fallbuddies")
            "among_us" -> launchPackage("com.innersloth.spacemafia", "Among Us", storePackage = "com.innersloth.spacemafia")
            "game_search" -> openPlayStoreSearch("jogos")
            "sites", "browser" -> openWebPage("https://www.google.com")
            "settings" -> openSettings()
            "wifi", "ver_networks" -> openWifiSettings()
            "connections" -> openWirelessSettings()
            "bluetooth" -> openBluetoothSettings()
            "files" -> openFiles()
            "trash" -> { Toast.makeText(this, "A lixeira depende do app de arquivos ou galeria.", Toast.LENGTH_LONG).show(); openFiles() }
            "my_computer" -> openSystemSettingsAction("android.settings.INTERNAL_STORAGE_SETTINGS")
            "camera" -> openCamera()
            "gallery" -> openGallery()
            "calculator" -> launchPackage("com.google.android.calculator", "Calculadora", storePackage = "com.google.android.calculator")
            "clock" -> launchPackage("com.google.android.deskclock", "Relógio", storePackage = "com.google.android.deskclock")
            "airplane" -> openSystemSettingsAction(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            "brightness" -> openSystemSettingsAction(Settings.ACTION_DISPLAY_SETTINGS)
            "battery" -> openSystemSettingsAction(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "user" -> openSystemSettingsAction(Settings.ACTION_SYNC_SETTINGS)
            "device_info" -> openSystemSettingsAction(Settings.ACTION_DEVICE_INFO_SETTINGS)
            else -> Toast.makeText(this, "Atalho desconhecido.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try { startActivityForResult(intent, FILE_PICK_REQUEST) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Nenhum seletor de arquivos está disponível.", Toast.LENGTH_LONG).show() }
        catch (_: SecurityException) { Toast.makeText(this, "Não foi possível abrir os arquivos.", Toast.LENGTH_LONG).show() }
    }

    private fun openCamera() {
        try { startActivity(Intent("android.media.action.IMAGE_CAPTURE")) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Nenhuma câmera está disponível.", Toast.LENGTH_LONG).show() }
        catch (_: SecurityException) { Toast.makeText(this, "Não foi possível abrir a câmera.", Toast.LENGTH_LONG).show() }
    }

    private fun openGallery() {
        try { startActivity(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Nenhuma galeria está disponível.", Toast.LENGTH_LONG).show() }
        catch (_: SecurityException) { Toast.makeText(this, "Não foi possível abrir a galeria.", Toast.LENGTH_LONG).show() }
    }

    private fun openSystemSettingsAction(action: String) {
        try { startActivity(Intent(action)) }
        catch (_: ActivityNotFoundException) { openSettings() }
        catch (_: SecurityException) { openSettings() }
    }

    private fun requestWhatsAppContact() {
        val picker = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
        try {
            startActivityForResult(picker, CONTACT_PICK_REQUEST)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Não foi possível abrir os contatos. Digite o telefone manualmente.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Não foi possível acessar o contato selecionado.", Toast.LENGTH_LONG).show()
        }
    }

    private fun handlePickedWhatsAppContact(uri: Uri?) {
        if (uri == null) return
        val projection = arrayOf(
            ContactsContract.Contacts.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        try {
            contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (!cursor.moveToFirst()) return
                val name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)) ?: ""
                val number = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)) ?: ""
                val script = "window.setSelectedMessageContact && window.setSelectedMessageContact(${JSONObject.quote(name)}, ${JSONObject.quote(number)});"
                runOnUiThread { webView.evaluateJavascript(script, null) }
            }
        } catch (_: SecurityException) {
            Toast.makeText(this, "Não foi possível ler esse contato. Digite o número manualmente.", Toast.LENGTH_LONG).show()
        } catch (_: IllegalArgumentException) {
            Toast.makeText(this, "Esse contato não tem um telefone disponível.", Toast.LENGTH_LONG).show()
        }
    }

    private fun sendWhatsAppMessage(phoneInput: String, messageInput: String) {
        val phone = phoneInput.filter { it.isDigit() }
        val message = messageInput.trim()
        if (phone.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "Informe o telefone e a mensagem.", Toast.LENGTH_LONG).show()
            return
        }
        val encodedMessage = Uri.encode(message)
        val whatsappUri = Uri.parse("whatsapp://send?phone=$phone&text=$encodedMessage")
        val whatsappIntent = Intent(Intent.ACTION_VIEW, whatsappUri).setPackage("com.whatsapp")
        try {
            startActivity(whatsappIntent)
        } catch (_: ActivityNotFoundException) {
            openWebPage("https://wa.me/$phone?text=$encodedMessage")
        } catch (_: SecurityException) {
            openWebPage("https://wa.me/$phone?text=$encodedMessage")
        }
    }

    private fun sendWhatsAppViaServer(endpointInput: String, phoneInput: String, messageInput: String) {
        val endpoint = endpointInput.trim()
        val phone = phoneInput.filter { it.isDigit() }
        val message = messageInput.trim()
        if (phone.isEmpty() || message.isEmpty()) {
            dispatchServerSendResult(false, "Informe telefone e mensagem.")
            return
        }
        val parsedUrl = try { URL(endpoint) } catch (_: Exception) { null }
        if (parsedUrl == null || parsedUrl.protocol != "https" || parsedUrl.host.isBlank() || parsedUrl.host.equals("seu-servidor.com", ignoreCase = true)) {
            dispatchServerSendResult(false, "Configure o endereço HTTPS real do seu servidor.")
            return
        }
        val payload = JSONObject().put("numero", phone).put("mensagem", message).toString()
        Thread {
            var connection: HttpURLConnection? = null
            try {
                val conn = URL(endpoint).openConnection() as HttpURLConnection
                connection = conn
                conn.requestMethod = "POST"
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15000
                conn.readTimeout = 25000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { stream -> stream.write(payload.toByteArray(Charsets.UTF_8)) }
                val responseCode = conn.responseCode
                val accepted = responseCode in 200..299
                if (accepted) conn.inputStream.close() else conn.errorStream?.close()
                dispatchServerSendResult(
                    accepted,
                    if (accepted) "O servidor aceitou a solicitação; a entrega depende da resposta do WhatsApp Business."
                    else "O servidor não confirmou o envio (HTTP $responseCode)."
                )
            } catch (_: Exception) {
                dispatchServerSendResult(false, "Não foi possível conectar ao servidor. Confira o endpoint HTTPS.")
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    private fun dispatchServerSendResult(success: Boolean, message: String) {
        val script = "window.serverSendResult && window.serverSendResult($success, ${JSONObject.quote(message)});"
        runOnUiThread {
            if (::webView.isInitialized) webView.evaluateJavascript(script, null)
        }
    }

    private fun requestApkInstall() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:$packageName")
                    )
                )
                Toast.makeText(this, "Permita instalar apps do Bombe Lite e toque em Instalar APK novamente.", Toast.LENGTH_LONG).show()
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "Abra as configurações do Android para permitir a instalação deste app.", Toast.LENGTH_LONG).show()
            } catch (_: SecurityException) {
                Toast.makeText(this, "Não foi possível abrir a permissão de instalação.", Toast.LENGTH_LONG).show()
            }
            return
        }

        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
        }
        try {
            startActivityForResult(picker, APK_PICK_REQUEST)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Não foi possível abrir o seletor de arquivos.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "O Android bloqueou o acesso ao seletor de arquivos.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Android file picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CONTACT_PICK_REQUEST) {
            if (resultCode == RESULT_OK) handlePickedWhatsAppContact(data?.data)
            return
        }
        if (requestCode != APK_PICK_REQUEST || resultCode != RESULT_OK) return
        val apkUri = data?.data ?: return
        val installer = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(installer)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Nenhum instalador de APK está disponível.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Não foi possível abrir o instalador do Android.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openWhatsAppChat() {
        val number = "5511999999999"
        val intentUri = "intent://send/#Intent;package=com.whatsapp;scheme=whatsapp;end"
        try {
            val intent = Intent.parseUri(intentUri, Intent.URI_INTENT_SCHEME)
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            openWebPage("https://wa.me/$number")
        } catch (_: SecurityException) {
            openWebPage("https://wa.me/$number")
        } catch (_: java.net.URISyntaxException) {
            openWebPage("https://wa.me/$number")
        }
    }

    private fun launchPackage(
        packageName: String,
        appName: String,
        fallbackUrl: String? = null,
        fallbackScheme: String? = null,
        storePackage: String? = null
    ) {
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                startActivity(launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            }
        } catch (_: ActivityNotFoundException) {
            // O pacote pode ter sido removido depois da leitura do menu.
        } catch (_: SecurityException) {
            // Tenta a alternativa web, quando houver.
        }

        if (storePackage != null) {
            openPlayStoreDetails(storePackage)
        } else if (fallbackUrl != null) {
            openWebPage(fallbackUrl)
        } else if (fallbackScheme != null) {
            openDeepLink(fallbackScheme, appName)
        } else {
            Toast.makeText(this, "$appName não está instalado.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openPlayStoreDetails(packageId: String) {
        val marketUri = Uri.parse("market://details?id=$packageId")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, marketUri))
        } catch (_: ActivityNotFoundException) {
            openWebPage("https://play.google.com/store/apps/details?id=$packageId")
        } catch (_: SecurityException) {
            openWebPage("https://play.google.com/store/apps/details?id=$packageId")
        }
    }

    private fun openPlayStoreSearch(query: String) {
        val encodedQuery = Uri.encode(query)
        val marketUri = Uri.parse("market://search?q=$encodedQuery&c=apps")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, marketUri))
        } catch (_: ActivityNotFoundException) {
            openWebPage("https://play.google.com/store/search?q=$encodedQuery&c=apps")
        } catch (_: SecurityException) {
            openWebPage("https://play.google.com/store/search?q=$encodedQuery&c=apps")
        }
    }

    private fun openDeepLink(uri: String, appName: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "$appName não está disponível neste aparelho.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Não foi possível abrir $appName.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openWebPage(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Nenhum navegador está disponível.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Não foi possível abrir o navegador.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Não foi possível abrir as configurações.", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Não foi possível abrir as configurações.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openHomeSettings() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: ActivityNotFoundException) {
            openSettings()
        } catch (_: SecurityException) {
            openSettings()
        }
    }

    private fun openWifiSettings() {
        try {
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
        } catch (_: ActivityNotFoundException) {
            openWirelessSettings()
        } catch (_: SecurityException) {
            openWirelessSettings()
        }
    }

    private fun openWirelessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        } catch (_: ActivityNotFoundException) {
            openSettings()
        } catch (_: SecurityException) {
            openSettings()
        }
    }

    private fun openBluetoothSettings() {
        try {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        } catch (_: ActivityNotFoundException) {
            openSettings()
        } catch (_: SecurityException) {
            openSettings()
        }
    }

    @Deprecated("Use the in-page navigation for the Android back action")
    override fun onBackPressed() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack();", null)
        } else {
            super.onBackPressed()
        }
    }

    companion object {
        private const val APK_PICK_REQUEST = 703
        private const val CONTACT_PICK_REQUEST = 704
        private const val BLUETOOTH_PERMISSION_REQUEST = 701
        private const val BLUETOOTH_SCAN_PERMISSION_REQUEST = 702
        private const val WIFI_SCAN_PERMISSION_REQUEST = 705
        private const val FILE_PICK_REQUEST = 706
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun openApp(id: String) {
            runOnUiThread { launchFromMenu(id) }
        }

        @JavascriptInterface
        fun pickWhatsAppContact() {
            runOnUiThread { this@MainActivity.requestWhatsAppContact() }
        }

        @JavascriptInterface
        fun sendWhatsAppMessage(phone: String, message: String) {
            runOnUiThread { this@MainActivity.sendWhatsAppMessage(phone, message) }
        }

        @JavascriptInterface
        fun sendWhatsAppViaServer(endpoint: String, phone: String, message: String) {
            this@MainActivity.sendWhatsAppViaServer(endpoint, phone, message)
        }

        @JavascriptInterface
        fun openStoreItem(packageId: String) {
            val safePackageId = packageId.trim()
            if (!safePackageId.matches(Regex("[A-Za-z0-9._]+"))) return
            runOnUiThread { openPlayStoreDetails(safePackageId) }
        }

        @JavascriptInterface
        fun searchPlayStore(query: String) {
            runOnUiThread { openPlayStoreSearch(query) }
        }

        @JavascriptInterface
        fun getBluetoothState(): String = bluetoothStateJson()

        @JavascriptInterface
        fun getHomeStatus(): String = homeStatusJson()

        @JavascriptInterface
        fun scanWifiNetworks() {
            runOnUiThread { this@MainActivity.startWifiScan() }
        }

        @JavascriptInterface
        fun requestBluetoothConnectPermission() {
            runOnUiThread { this@MainActivity.requestBluetoothConnectPermission() }
        }

        @JavascriptInterface
        fun openHomeSettings() {
            runOnUiThread { this@MainActivity.openHomeSettings() }
        }

        @JavascriptInterface
        fun openBluetoothSettings() {
            runOnUiThread { this@MainActivity.openBluetoothSettings() }
        }

        @JavascriptInterface
        fun enableBluetooth() {
            runOnUiThread { this@MainActivity.enableBluetooth() }
        }

        @JavascriptInterface
        fun startBluetoothScan() {
            runOnUiThread { this@MainActivity.startBluetoothScan() }
        }

        @JavascriptInterface
        fun stopBluetoothScan() {
            runOnUiThread { this@MainActivity.stopBluetoothScan() }
        }

        @JavascriptInterface
        fun pairBluetoothDevice(address: String) {
            runOnUiThread { this@MainActivity.pairBluetoothDevice(address) }
        }

        @JavascriptInterface
        fun disconnectBluetoothDevice(address: String) {
            runOnUiThread { this@MainActivity.disconnectBluetoothDevice(address) }
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finish() }
        }
    }
}
