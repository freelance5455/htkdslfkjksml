(() => {
  const host = document.querySelector('#messageKeyboard');
  const field = document.querySelector('#messageText');
  if (!host || !field) return;

  let shifted = true;
  let symbols = false;
  let english = false;

  function insertText(text) {
    const start = field.selectionStart ?? field.value.length;
    const end = field.selectionEnd ?? start;
    field.value = field.value.slice(0, start) + text + field.value.slice(end);
    const caret = start + text.length;
    field.setSelectionRange(caret, caret);
    field.focus();
  }

  function addRow(labels, parent, options = {}) {
    const row = document.createElement('div');
    row.className = 'message-key-row';
    if (options.indent) row.style.paddingInline = options.indent;
    parent.append(row);
    for (const item of labels) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'message-key' + (item.className ? ' ' + item.className : '') + (item.action === 'shift' && shifted ? ' active' : '');
      button.textContent = item.label;
      button.setAttribute('aria-label', item.aria || item.label);
      button.onclick = () => handleKey(item.action || item.label);
      row.append(button);
    }
  }

  function build() {
    host.replaceChildren();
    if (!symbols) {
      addRow(Array.from('1234567890', c => ({label:c})), host);
      addRow(Array.from(shifted ? 'QWERTYUIOP' : 'qwertyuiop', c => ({label:c})), host);
      addRow(Array.from(shifted ? 'ASDFGHJKL' : 'asdfghjkl', c => ({label:c})), host, {indent:'4%'});
      addRow([
        {label:'⇧', action:'shift', className:'wide', aria:'Shift'},
        ...Array.from(shifted ? 'ZXCVBNM' : 'zxcvbnm', c => ({label:c})),
        {label:'⌫', action:'backspace', className:'wide', aria:'Apagar'}
      ], host);
    } else {
      addRow(Array.from('!@#$%&-+()', c => ({label:c})), host);
      addRow(Array.from('*"\':;!?/_=', c => ({label:c})), host);
      addRow(Array.from('[]{}\\|~`<>', c => ({label:c})), host);
    }
    addRow([
      {label:symbols ? 'ABC' : '?123', action:'symbols', className:'wide'},
      {label:'🌐 ' + (english ? 'English' : 'Português (BR)'), action:'language', className:'label-key', aria:'Idioma'},
      {label:',', action:','},
      {label:'Espaço', action:'space', className:'extra-wide'},
      {label:'.', action:'.'},
      {label:'↵', action:'enter', className:'wide', aria:'Enter'}
    ], host);
  }

  function handleKey(key) {
    if (key === 'shift') { shifted = !shifted; build(); return; }
    if (key === 'symbols') { symbols = !symbols; build(); return; }
    if (key === 'language') { english = !english; build(); return; }
    if (key === 'backspace') {
      let start = field.selectionStart ?? field.value.length;
      let end = field.selectionEnd ?? start;
      if (start === end && start > 0) {
        const previousCharacter = Array.from(field.value.slice(0, start)).pop() || '';
        start -= previousCharacter.length;
      }
      field.setRangeText('', start, end, 'end');
      field.focus();
      return;
    }
    if (key === 'space') { insertText(' '); return; }
    if (key === 'enter') { insertText('\n'); return; }
    insertText(key.length === 1 && /[a-z]/i.test(key) ? (shifted ? key.toUpperCase() : key.toLowerCase()) : key);
  }

  build();
})();
