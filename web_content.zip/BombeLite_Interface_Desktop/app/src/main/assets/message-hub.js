(() => {
  const conversations = [
    {name:'João Silva',platform:'WhatsApp',preview:'Tá chegando aí? 🚀',time:'12:34',icon:'🟢',messages:[['Tá chegando aí? 🚀',false],['Sim, já tô saindo agora!',true],['Beleza! Te espero 😊',false]]},
    {name:'Maria Souza',platform:'Messenger',preview:'Beleza! Te vejo depois então. 😊',time:'11:58',icon:'🔵',messages:[['Vamos marcar para amanhã?',false],['Beleza! Te vejo depois então. 😊',true]]},
    {name:'Lucas Gamer',platform:'Discord',preview:'Bora jogar mais tarde?',time:'11:20',icon:'🎮',messages:[['Bora jogar mais tarde?',false],['Fechado, te chamo!',true]]},
    {name:'Ana Clara',platform:'Instagram',preview:'Amei a foto 😍',time:'10:45',icon:'📸',messages:[['Amei a foto 😍',false],['Obrigada!! 💜',true]]},
    {name:'Grupo da Família',platform:'WhatsApp',preview:'Vovó: Já almoçaram?',time:'09:32',icon:'🟢',messages:[['Vovó: Já almoçaram?',false],['Sim, vó! 😄',true]]},
    {name:'Trabalho',platform:'Telegram',preview:'Reunião às 15h, ok?',time:'08:17',icon:'✈️',messages:[['Reunião às 15h, ok?',false],['Ok, confirmado.',true]]},
    {name:'Sistema',platform:'SMS',preview:'Nova mensagem de exemplo',time:'Ontem',icon:'✉️',messages:[['Nova mensagem SMS de demonstração.',false]]}
  ];
  let activeFilter = 'Todos';
  let activeConversation = conversations[0];
  let pendingServerText = '';

  function showConversation(item) {
    activeConversation = item;
    document.querySelectorAll('.demo-conversation').forEach(row => row.classList.toggle('selected', row.dataset.name === item.name));
    document.querySelector('#previewAvatar').textContent = item.icon;
    document.querySelector('#previewName').textContent = item.name + ' (' + item.platform + ')';
    document.querySelector('#previewStatus').textContent = 'Prévia de demonstração';
    const chat = document.querySelector('#messageDemoChat');
    chat.replaceChildren();
    for (const [text, outgoing] of item.messages) {
      const bubble = document.createElement('div');
      bubble.className = 'demo-bubble' + (outgoing ? ' outgoing' : '');
      bubble.textContent = text;
      chat.append(bubble);
    }
  }

  window.renderMessageConversations = (filter = activeFilter) => {
    activeFilter = filter;
    const query = (document.querySelector('#messageSearch')?.value || '').trim().toLocaleLowerCase('pt-BR');
    const list = document.querySelector('#messageConversationList');
    if (!list) return;
    list.replaceChildren();
    const visible = conversations.filter(item => (filter === 'Todos' || item.platform === filter) && (item.name + ' ' + item.preview).toLocaleLowerCase('pt-BR').includes(query));
    for (const item of visible) {
      const row = document.createElement('button');
      row.type = 'button';
      row.className = 'demo-conversation' + (item === activeConversation ? ' selected' : '');
      row.dataset.name = item.name;
      const avatar = document.createElement('span'); avatar.className = 'demo-avatar'; avatar.textContent = item.icon;
      const copy = document.createElement('span'); copy.className = 'demo-copy';
      const name = document.createElement('strong'); name.textContent = item.name + ' (' + item.platform + ')';
      const preview = document.createElement('small'); preview.textContent = item.preview;
      copy.append(name, preview);
      const time = document.createElement('span'); time.className = 'demo-meta'; time.textContent = item.time;
      row.append(avatar, copy, time);
      row.onclick = () => showConversation(item);
      list.append(row);
    }
    if (!visible.length) {
      const empty = document.createElement('p');
      empty.className = 'message-preview-note';
      empty.textContent = 'Nenhum exemplo nesta categoria.';
      list.append(empty);
    }
    if (visible.length && !visible.includes(activeConversation)) showConversation(visible[0]);
    document.querySelectorAll('[data-message-filter]').forEach(button => button.classList.toggle('active', button.dataset.messageFilter === filter));
  };

  function sendViaServer() {
    const endpoint = document.querySelector('#messageServerEndpoint').value.trim();
    const phone = document.querySelector('#messagePhone').value.replace(/\D/g, '');
    const message = document.querySelector('#messageText').value.trim();
    let parsed;
    try { parsed = new URL(endpoint); } catch (_) { showToast('Informe a URL HTTPS do seu servidor.'); return; }
    if (parsed.protocol !== 'https:' || !parsed.host || parsed.hostname.toLowerCase() === 'seu-servidor.com') {
      showToast('Configure o endpoint HTTPS real do seu servidor.'); return;
    }
    if (!phone || !message) { showToast('Preencha telefone e mensagem antes de enviar.'); return; }
    if (!window.AndroidApp || typeof window.AndroidApp.sendWhatsAppViaServer !== 'function') {
      showToast('O envio via servidor está disponível no app Android instalado.'); return;
    }
    pendingServerText = message;
    const button = document.querySelector('#sendServerMessage');
    button.disabled = true;
    window.AndroidApp.sendWhatsAppViaServer(endpoint, phone, message);
  }

  window.serverSendResult = (success, message) => {
    const button = document.querySelector('#sendServerMessage');
    button.disabled = false;
    if (success && document.querySelector('#messageText').value.trim() === pendingServerText) {
      document.querySelector('#messageText').value = '';
    }
    showToast(message || (success ? 'O servidor aceitou a solicitação.' : 'O servidor não confirmou o envio.'));
  };

  document.querySelectorAll('[data-message-filter]').forEach(button => {
    button.onclick = () => window.renderMessageConversations(button.dataset.messageFilter);
  });
  document.querySelector('#messageSearch').addEventListener('input', () => window.renderMessageConversations(activeFilter));
  document.querySelector('#newMessage').onclick = () => { document.querySelector('#messageComposer').hidden = false; };
  document.querySelector('#messageComposeBack').onclick = () => { document.querySelector('#messageComposer').hidden = true; };
  document.querySelector('#messageSettings').onclick = () => showToast('A lista é demonstrativa; o WhatsApp pode abrir com mensagem preparada e o envio via Business exige endpoint configurado.');
  document.querySelector('#messageMore').onclick = () => showToast('Conversas de exemplo — não há outras contas conectadas.');
  document.querySelector('#previewMore').onclick = () => showToast('Esta conversa é apenas uma prévia demonstrativa.');
  document.querySelector('#previewBack').onclick = () => window.renderMessageConversations('Todos');
  document.querySelector('#sendServerMessage').onclick = sendViaServer;
  window.renderMessageConversations('Todos');
})();
