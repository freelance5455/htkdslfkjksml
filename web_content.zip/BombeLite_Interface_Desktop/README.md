# Bombe Lite — projeto Android Studio com interface integrada

Este é o projeto-fonte de **um único app Android Bombe Lite**, preparado para abrir no Android Studio. A interface da tela inicial foi refeita a partir das duas imagens fornecidas: painel desktop com barra lateral, grupos de apps/jogos/sistema, busca, status do aparelho e atalhos rápidos; e menu Iniciar central com busca, cartões e barra inferior. Os módulos e o minijogo Bombe Lite permanecem dentro deste mesmo app; os demais aplicativos são atalhos para apps Android instalados ou para suas páginas de loja/site, não cópias instaladas dentro do Bombe Lite.

As imagens fornecidas usadas como referência estão em `app/src/main/assets/referencia_dashboard_interface.jpg` e `app/src/main/assets/referencia_menu_iniciar.jpg`. Elas podem ser abertas no próprio app por **Aplicativos → Sobre**. Também há arquivos de referência adicionais em `app/src/main/assets/`.

## Abrir e compilar

1. Abra a pasta `BombeLite_Interface_Desktop/` no Android Studio.
2. Use JDK 17 e instale/configure o Android SDK 35; sincronize o Gradle.
3. Para compilar localmente, escolha **Build → Build APK(s)**.

## Usar como tela inicial e navegar

O projeto já registra o Bombe Lite como uma opção de app **HOME** do Android. Depois de instalar o APK, abra o Bombe Lite, entre em **Configurações → Definir tela inicial**, escolha **Bombe Lite** como app de início padrão e confirme conforme as opções do aparelho. Assim, o botão **Home** do Android volta para o Bombe Lite; ao tocar num app, ele abre normalmente e o Bombe Lite fica em segundo plano. O botão **Voltar** navega pelas telas internas e, já na tela inicial, não fecha o app. **Recentes** e **Home** continuam sendo controles do próprio Android; o Bombe Lite não fica por cima de outros apps.

Os atalhos visíveis chamam suas ações Android correspondentes ou abrem o app/loja compatível. Algumas ações protegidas — como conectar a uma rede ou alterar configurações do sistema — passam pela tela oficial do Android e podem pedir confirmação.

**O ZIP distribuído é somente o projeto-fonte Android Studio; não contém APK.** Não há APK compilado incluído neste projeto/arquivo.

## O que os controles fazem

- **Busca e navegação:** buscam e filtram os grupos de aplicativos; a barra lateral abre categorias, Wi‑Fi, configurações e arquivos. Os atalhos do menu Iniciar e os cartões fecham o menu ao navegar para outra tela.
- **Apps e jogos:** tentam abrir o pacote instalado. Se não estiver instalado, os jogos e vários aplicativos abrem sua página na Play Store; serviços com fallback web podem abrir o site oficial. Na Loja, a seção **Jogar dentro do Bombe Lite** permite salvar até 20 links HTTPS e carregar um jogo HTML5 em uma WebView separada. O trecho recebido apenas abre a página online — não baixa arquivos para uso offline nem instala APK; por isso, cada jogo precisa estar hospedado num endereço real e compatível com WebView. O domínio de exemplo enviado (`seuservidor.com`) não foi usado como se fosse um endereço funcional. O WebView do jogo não recebe a ponte JavaScript privilegiada do launcher. Para jogos Android, a instalação e as permissões continuam sendo confirmadas pelo usuário no Android/na loja.
- **Bombe Lite:** abre o minijogo interno de bombas. Loja Bombe Lite, Configurações do Bombe Lite, Mensagens, câmera/galeria, arquivos e as demais telas Bombe Lite são módulos do mesmo app.
- **Wi‑Fi:** ao abrir a tela, o app inicia uma busca nativa pelo `WifiManager`; **Atualizar** repete a busca. A lista mostra os SSIDs encontrados, a intensidade estimada do sinal em porcentagem e a quantidade de redes retornadas. Ao tocar numa rede WPA2/WPA3 no Android 10+, o Bombe Lite pede uma senha (8–63 caracteres) e solicita autorização ao Android pelo seletor de rede; em rede aberta, a solicitação de autorização também é exibida, sem campo de senha. Essa conexão solicitada pelo app pode ficar limitada ao Bombe Lite e não deve ser tratada como conexão salva para todo o aparelho. O botão **Configurações de Wi‑Fi** abre a tela oficial do Android para conectar e gerenciar a rede para o aparelho inteiro. Redes ocultas, WEP/EAP/OWE, versões anteriores ao Android 10 e demais casos não compatíveis são encaminhados às configurações. Senhas não são salvas nem registradas pelo app. Uma solicitação anterior é liberada ao iniciar outra, ao transferir o usuário às configurações e ao destruir a Activity.
- **Bluetooth:** a tela Bombe Lite pode pedir acesso a dispositivos próximos, procurar dispositivos e solicitar pareamento por meio do Android. A desconexão genérica abre as configurações Bluetooth do Android, pois o sistema não fornece ao app um controle público genérico confiável para desconectar qualquer dispositivo.
- **Arquivos / Meu Computador / Lixeira:** Arquivos abre o seletor de documentos do Android; Meu Computador abre a tela de armazenamento se o aparelho a fornecer. **Lixeira não é uma lixeira própria:** informa que depende do app de arquivos/galeria e usa o seletor de arquivos como alternativa.
- **Câmera e Galeria:** encaminham a captura/seleção ao app compatível do aparelho.
- **Atalhos rápidos:** Wi‑Fi e Bluetooth abrem as telas Bombe Lite. Modo avião, brilho e bateria encaminham para as configurações do sistema; não modificam essas configurações protegidas em segundo plano. Sair fecha a atividade Bombe Lite.
- **Instalar APK:** abre o seletor de arquivo e, quando exigido, a página de permissão do Android; a instalação é iniciada pelo sistema e depende da confirmação do usuário.
- **Mensagens:** o hub é interno. A abertura/envio pelo WhatsApp depende do WhatsApp instalado e de confirmação; o envio via WhatsApp Business depende de endpoint HTTPS próprio configurado pelo usuário.

## Permissões e limites da plataforma

O manifesto declara acesso à internet/estado da rede, leitura e alteração do estado Wi‑Fi necessário às operações permitidas, `CHANGE_NETWORK_STATE` para solicitar conexões autorizadas pelo Android, `ACCESS_FINE_LOCATION` e, no Android 13+, `NEARBY_WIFI_DEVICES` para tentativa de varredura Wi‑Fi; permissões Bluetooth compatíveis com versões antigas e com Android 12+ (`BLUETOOTH_SCAN` e `BLUETOOTH_CONNECT`); e `REQUEST_INSTALL_PACKAGES` para encaminhar instalação de APK selecionado pelo usuário. As permissões sensíveis são solicitadas em tempo de execução quando necessárias. A captura, seleção de contatos e arquivos são encaminhadas a telas/seletoras do Android, sem pedir acesso amplo ao armazenamento ou à agenda.

O Android controla as permissões e pode restringir buscas Wi‑Fi/Bluetooth ou não disponibilizar certos apps/configurações. As telas do sistema, o seletor, a Play Store e os apps externos podem variar conforme fabricante, versão Android e aplicativos instalados.

## Estrutura principal

- Interface WebView: `app/src/main/assets/index.html` (mais os scripts auxiliares de mensagens na mesma pasta).
- Rotas e ações Android: `app/src/main/java/com/bombelite/app/MainActivity.kt`.
- Permissões e visibilidade de pacotes: `app/src/main/AndroidManifest.xml`.
- Build Android Studio: `settings.gradle.kts`, `build.gradle.kts` e `app/build.gradle.kts`.
