# Bombe Lite — projeto Android Studio com interface integrada

Este é o projeto-fonte de **um único app Android Bombe Lite**, preparado para abrir no Android Studio. A interface da tela inicial foi refeita a partir das duas imagens fornecidas: painel desktop com barra lateral, grupos de apps/jogos/sistema, busca, status do aparelho e atalhos rápidos; e menu Iniciar central com busca, cartões e barra inferior. Os módulos e o minijogo Bombe Lite permanecem dentro deste mesmo app; os demais aplicativos são atalhos para apps Android instalados ou para suas páginas de loja/site, não cópias instaladas dentro do Bombe Lite.

As imagens fornecidas usadas como referência estão em `app/src/main/assets/referencia_dashboard_interface.jpg` e `app/src/main/assets/referencia_menu_iniciar.jpg`. Elas podem ser abertas no próprio app por **Aplicativos → Sobre**. Também há arquivos de referência adicionais em `app/src/main/assets/`.

## Abrir e compilar

1. Abra a pasta `BombeLite_Interface_Desktop/` no Android Studio.
2. Use JDK 17 e instale/configure o Android SDK 35; sincronize o Gradle.
3. Para compilar localmente, escolha **Build → Build APK(s)**.

**O ZIP distribuído é somente o projeto-fonte Android Studio; não contém APK.** Não há APK compilado incluído neste projeto/arquivo.

## O que os controles fazem

- **Busca e navegação:** buscam e filtram os grupos de aplicativos; a barra lateral abre categorias, Wi‑Fi, configurações e arquivos. Os atalhos do menu Iniciar e os cartões fecham o menu ao navegar para outra tela.
- **Apps e jogos:** tentam abrir o pacote instalado. Se não estiver instalado, os jogos e vários aplicativos abrem sua página na Play Store; serviços com fallback web podem abrir o site oficial. A instalação e permissões externas são sempre confirmadas pelo usuário no Android/na loja.
- **Bombe Lite:** abre o minijogo interno de bombas. Loja Bombe Lite, Configurações do Bombe Lite, Mensagens, câmera/galeria, arquivos e as demais telas Bombe Lite são módulos do mesmo app.
- **Wi‑Fi:** o painel começa com quatro nomes ilustrativos: Minha Internet, WiFi Casa, Rede Local e AndroidAP. **Atualizar** limpa esses exemplos, solicita as permissões necessárias e tenta exibir os nomes e a intensidade de sinal das redes retornadas pelo Android. O Android pode limitar a frequência de varredura e, nesses casos, podem aparecer resultados recentes. Tocar numa rede ou em **Configurações de Wi‑Fi** abre as configurações oficiais, onde se escolhe a rede e informa a senha; o app não conecta silenciosamente.
- **Bluetooth:** a tela Bombe Lite pode pedir acesso a dispositivos próximos, procurar dispositivos e solicitar pareamento por meio do Android. A desconexão genérica abre as configurações Bluetooth do Android, pois o sistema não fornece ao app um controle público genérico confiável para desconectar qualquer dispositivo.
- **Arquivos / Meu Computador / Lixeira:** Arquivos abre o seletor de documentos do Android; Meu Computador abre a tela de armazenamento se o aparelho a fornecer. **Lixeira não é uma lixeira própria:** informa que depende do app de arquivos/galeria e usa o seletor de arquivos como alternativa.
- **Câmera e Galeria:** encaminham a captura/seleção ao app compatível do aparelho.
- **Atalhos rápidos:** Wi‑Fi e Bluetooth abrem as telas Bombe Lite. Modo avião, brilho e bateria encaminham para as configurações do sistema; não modificam essas configurações protegidas em segundo plano. Sair fecha a atividade Bombe Lite.
- **Instalar APK:** abre o seletor de arquivo e, quando exigido, a página de permissão do Android; a instalação é iniciada pelo sistema e depende da confirmação do usuário.
- **Mensagens:** o hub é interno. A abertura/envio pelo WhatsApp depende do WhatsApp instalado e de confirmação; o envio via WhatsApp Business depende de endpoint HTTPS próprio configurado pelo usuário.

## Permissões e limites da plataforma

O manifesto declara acesso à internet/estado da rede, leitura e alteração do estado Wi‑Fi necessário às operações permitidas, `ACCESS_FINE_LOCATION` e, no Android 13+, `NEARBY_WIFI_DEVICES` para tentativa de varredura Wi‑Fi; permissões Bluetooth compatíveis com versões antigas e com Android 12+ (`BLUETOOTH_SCAN` e `BLUETOOTH_CONNECT`); e `REQUEST_INSTALL_PACKAGES` para encaminhar instalação de APK selecionado pelo usuário. As permissões sensíveis são solicitadas em tempo de execução quando necessárias. A captura, seleção de contatos e arquivos são encaminhadas a telas/seletoras do Android, sem pedir acesso amplo ao armazenamento ou à agenda.

O Android controla as permissões e pode restringir buscas Wi‑Fi/Bluetooth ou não disponibilizar certos apps/configurações. As telas do sistema, o seletor, a Play Store e os apps externos podem variar conforme fabricante, versão Android e aplicativos instalados.

## Estrutura principal

- Interface WebView: `app/src/main/assets/index.html` (mais os scripts auxiliares de mensagens na mesma pasta).
- Rotas e ações Android: `app/src/main/java/com/bombelite/app/MainActivity.kt`.
- Permissões e visibilidade de pacotes: `app/src/main/AndroidManifest.xml`.
- Build Android Studio: `settings.gradle.kts`, `build.gradle.kts` e `app/build.gradle.kts`.
