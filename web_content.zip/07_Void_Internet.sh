#!/bin/bash
# Void Internet v3.0.0 - Comandos limpos com 2>/dev/null || true
echo "Aplicando Void Internet..."

settings put global wifi_scan_throttle_enabled 0 2>/dev/null || true
settings put global mobile_data_always_on 1 2>/dev/null || true
settings put global wifi_networks_available_notification_on 0 2>/dev/null || true
setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960 2>/dev/null || true
setprop net.tcp.buffersize.wifi 524288,1048576,2097152,524288,1048576,2097152 2>/dev/null || true
setprop net.dns1 8.8.8.8 2>/dev/null || true
setprop net.dns2 8.8.4.4 2>/dev/null || true

echo "Void Internet aplicado!"
