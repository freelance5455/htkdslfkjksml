GESTÃO ACADÉMICA - C.A.H. | VERSÃO 1

Este projecto é a base real para a aplicação web.

1. Crie um projecto no Supabase.
2. Abra SQL Editor e execute schema.sql.
3. No ficheiro app.js, substitua SUPABASE_URL e SUPABASE_ANON_KEY.
4. Publique os ficheiros numa hospedagem web (por exemplo Vercel/Netlify).

IMPORTANTE: Para produção, devem ser configuradas políticas RLS no Supabase e autenticação do administrador.


ACESSO DO ADMINISTRADOR
- A área pública NÃO mostra mais o botão/opção Administrador aos alunos.
- O administrador entra pela página separada: /admin.html
- Mesmo conhecendo o endereço, o acesso continua protegido pelo login do Supabase e pelo perfil papel=admin.
