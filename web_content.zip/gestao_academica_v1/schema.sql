-- Gestão Académica C.A.H. - Supabase/PostgreSQL schema
create extension if not exists pgcrypto;

create table if not exists students (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text not null,
  age integer,
  institution text,
  residence text,
  school_period text,
  school_start time,
  school_end time,
  available_days text[] default '{}',
  preferred_period text,
  created_at timestamptz not null default now()
);

create table if not exists enrollments (
  id uuid primary key default gen_random_uuid(),
  registration_number text unique not null,
  student_id uuid not null references students(id) on delete cascade,
  service text not null,
  level text,
  class_name text,
  course text,
  monthly_value numeric(12,2) not null default 0,
  status text not null default 'PENDENTE' check (status in ('PENDENTE','APROVADA','REJEITADA')),
  created_at timestamptz not null default now()
);

create table if not exists enrollment_subjects (
  id uuid primary key default gen_random_uuid(),
  enrollment_id uuid not null references enrollments(id) on delete cascade,
  subject_name text not null
);

create table if not exists monthly_fees (
  id uuid primary key default gen_random_uuid(),
  enrollment_id uuid not null references enrollments(id) on delete cascade,
  month integer not null check (month between 1 and 12),
  year integer not null,
  amount numeric(12,2) not null,
  due_date date,
  status text not null default 'PENDENTE' check (status in ('PENDENTE','PARCIAL','PAGO')),
  unique(enrollment_id, month, year)
);

create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  monthly_fee_id uuid not null references monthly_fees(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  method text not null,
  reference text,
  payment_date date not null default current_date,
  created_at timestamptz not null default now()
);

create table if not exists availability (
  id uuid primary key default gen_random_uuid(),
  day_of_week text unique not null,
  start_time time not null,
  end_time time not null,
  active boolean not null default true
);

insert into availability(day_of_week,start_time,end_time) values
('Segunda','14:00','19:00'),('Terça','14:00','19:00'),('Quarta','14:00','19:00'),('Quinta','14:00','19:00'),('Sexta','14:00','19:00'),('Sábado','07:00','18:00'),('Domingo','07:00','18:00')
on conflict (day_of_week) do nothing;

create or replace function update_monthly_fee_status(p_fee uuid)
returns void language plpgsql as $$
declare total_paid numeric(12,2); fee_amount numeric(12,2);
begin
  select amount into fee_amount from monthly_fees where id=p_fee;
  select coalesce(sum(amount),0) into total_paid from payments where monthly_fee_id=p_fee;
  update monthly_fees set status = case when total_paid >= fee_amount then 'PAGO' when total_paid > 0 then 'PARCIAL' else 'PENDENTE' end where id=p_fee;
end; $$;

create or replace function payments_after_change()
returns trigger language plpgsql as $$
begin
  perform update_monthly_fee_status(coalesce(new.monthly_fee_id, old.monthly_fee_id));
  return coalesce(new,old);
end; $$;

drop trigger if exists trg_payment_status on payments;
create trigger trg_payment_status after insert or update or delete on payments
for each row execute function payments_after_change();
