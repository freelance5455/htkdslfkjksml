VINYL VAULT V8.1 REPAIR

Fixed:
- Settings button crash caused by a missing discogsToken element.
- V7 storage keys renamed to V8.
- Discogs no longer replaces the app window.
- Android wrapper opens Discogs in the external browser while Vinyl Vault stays open.
- Added a dedicated Discogs release ID field and Import release ID button.
- Camera permission is requested by the Android wrapper.
- Collection remains local; JSON backup/restore remains available.

ANDROID BUILD
Open the android folder in Android Studio and build the debug APK.
The web version is in index.html and is also copied into android/app/src/main/assets/index.html.

IMPORTANT
The Discogs API can reject browser/WebView requests because of CORS or rate limits. V8.1 therefore keeps manual entry as a reliable fallback: search Discogs, copy the release ID, return to Vinyl Vault, enter the ID, and save.
