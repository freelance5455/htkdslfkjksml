import os, uuid, zipfile, shutil, subprocess, threading, time
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Header, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

BASE = Path("/srv")
BUILDS = BASE / "builds"
BUILDS.mkdir(parents=True, exist_ok=True)
API_KEY = os.getenv("API_KEY", "")
MAX_MB = int(os.getenv("MAX_UPLOAD_MB", "100"))
TIMEOUT = int(os.getenv("BUILD_TIMEOUT_SECONDS", "900"))
JOBS = {}
LOCK = threading.Lock()

app = FastAPI(title="LADEN APK COMPILER", version="1.0")
app.mount("/web", StaticFiles(directory=str(BASE / "web")), name="web")

def authorize(key):
    if not API_KEY or key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")

def safe_extract(zip_path: Path, dest: Path):
    with zipfile.ZipFile(zip_path) as z:
        for item in z.infolist():
            p = Path(item.filename)
            if p.is_absolute() or ".." in p.parts:
                raise ValueError("Unsafe ZIP path")
            # Reject symlinks and unusually large expanded files
            mode = item.external_attr >> 16
            if (mode & 0o170000) == 0o120000:
                raise ValueError("ZIP symlinks are not allowed")
            if item.file_size > 300 * 1024 * 1024:
                raise ValueError("An archive entry is too large")
        z.extractall(dest)

def find_project(folder: Path):
    candidates = [folder] + [p for p in folder.iterdir() if p.is_dir()]
    for p in candidates:
        if ( (p / "settings.gradle").exists() or (p / "settings.gradle.kts").exists() ):
            return p
    raise RuntimeError("Не найден Gradle-проект: нужны gradlew и settings.gradle(.kts) в корне ZIP или на один уровень ниже.")

def run_build(job_id, archive):
    work = BUILDS / job_id
    work.mkdir(parents=True, exist_ok=True)
    try:
        source = work / "upload.zip"
        shutil.copyfile(archive, source)
        project = work / "src"
        project.mkdir()
        safe_extract(source, project)
        gradle_project = find_project(project)
        wrapper = gradle_project / "gradlew"
        if wrapper.exists():
            wrapper.chmod(0o755)
            gradle_cmd = [str(wrapper)]
        else:
            gradle_cmd = ["gradle"]
        result = subprocess.run(
            gradle_cmd + ["--no-daemon", "--stacktrace", "assembleDebug"],
            cwd=str(gradle_project), capture_output=True, text=True,
            timeout=TIMEOUT, env={**os.environ, "ANDROID_HOME": "/opt/android-sdk", "ANDROID_SDK_ROOT": "/opt/android-sdk"}
        )
        log = (result.stdout or "") + "\n" + (result.stderr or "")
        (work / "build.log").write_text(log[-200000:], errors="replace")
        if result.returncode != 0:
            JOBS[job_id] = {"status": "failed", "error": "Gradle завершился с ошибкой. Откройте журнал сборки.", "log": f"/api/jobs/{job_id}/log"}
            return
        apks = list(gradle_project.glob("**/build/outputs/apk/**/*.apk"))
        if not apks:
            raise RuntimeError("Gradle завершился, но APK-файл не найден.")
        chosen = max(apks, key=lambda p: p.stat().st_mtime)
        final_apk = work / "LADEN-GAMES-debug.apk"
        shutil.copyfile(chosen, final_apk)
        JOBS[job_id] = {"status": "success", "download": f"/api/jobs/{job_id}/download", "filename": final_apk.name}
    except subprocess.TimeoutExpired:
        JOBS[job_id] = {"status": "failed", "error": "Превышено время сборки."}
    except Exception as e:
        JOBS[job_id] = {"status": "failed", "error": str(e)}
    finally:
        try:
            Path(archive).unlink(missing_ok=True)
        except Exception:
            pass

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "web" / "index.html").read_text()

@app.get("/api/health")
def health():
    return {"service": "LADEN APK COMPILER", "status": "online"}

@app.post("/api/builds")
async def create_build(background: BackgroundTasks, file: UploadFile = File(...), x_api_key: str = Header(default="")):
    authorize(x_api_key)
    if not file.filename.lower().endswith(".zip"):
        raise HTTPException(400, "Загрузите ZIP-архив.")
    job_id = uuid.uuid4().hex[:12]
    temp = BUILDS / f"{job_id}-incoming.zip"
    size = 0
    with temp.open("wb") as out:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk: break
            size += len(chunk)
            if size > MAX_MB * 1024 * 1024:
                temp.unlink(missing_ok=True)
                raise HTTPException(413, f"Максимальный размер ZIP: {MAX_MB} MB.")
            out.write(chunk)
    JOBS[job_id] = {"status": "building"}
    background.add_task(run_build, job_id, str(temp))
    return {"job_id": job_id, "status": "building", "status_url": f"/api/jobs/{job_id}"}

@app.get("/api/jobs/{job_id}")
def job_status(job_id: str, x_api_key: str = Header(default="")):
    authorize(x_api_key)
    if job_id not in JOBS: raise HTTPException(404, "Сборка не найдена.")
    return JOBS[job_id]

@app.get("/api/jobs/{job_id}/download")
def download(job_id: str, x_api_key: str = Header(default="")):
    authorize(x_api_key)
    p = BUILDS / job_id / "LADEN-GAMES-debug.apk"
    if not p.exists(): raise HTTPException(404, "APK ещё не готов.")
    return FileResponse(p, filename="LADEN-GAMES-debug.apk", media_type="application/vnd.android.package-archive")

@app.get("/api/jobs/{job_id}/log")
def get_log(job_id: str, x_api_key: str = Header(default="")):
    authorize(x_api_key)
    p = BUILDS / job_id / "build.log"
    if not p.exists(): raise HTTPException(404, "Журнал пока недоступен.")
    return FileResponse(p, filename="build.log", media_type="text/plain")
