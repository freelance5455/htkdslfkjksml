"""End-to-end Loonie Academy v10 Knowledge Kingdom tests in isolated Chromium.
Inlines assets and mocks localStorage because localhost requests are restricted.
This is a non-destructive test-browser run, never the user's storage.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json

ROOT=Path(__file__).resolve().parent
html=(ROOT/'index.html').read_text()
for f in ('curriculum-v6.js','curriculum-v7.js','university-v8.js','inquiry-v9.js','kingdom-v10.js','career-v11.js','life-v12.js','curriculum-v13.js','academy-v13.js'):
    assert f'<script src="{f}"></script>' in html
    html=html.replace(f'<script src="{f}"></script>', '<script>\n'+(ROOT/f).read_text()+'\n</script>')
for f in ('university-v8.css','inquiry-v9.css','kingdom-v10.css','career-v11.css','life-v12.css','academy-v13.css'):
    assert f'<link rel="stylesheet" href="{f}">' in html
    html=html.replace(f'<link rel="stylesheet" href="{f}">','<style>'+ (ROOT/f).read_text()+'</style>')
import re
html=re.sub(r'<link rel="preconnect"[^>]*>|<link href="https://fonts.googleapis.com[^>]*>', '', html)

def init(browser,db=None,viewport=None):
    ctx=browser.new_context(viewport=viewport or {'width':390,'height':844},accept_downloads=True)
    page=ctx.new_page();page.set_default_timeout(6000)
    data=db if db is not None else {'loonieAcademy_v1':json.dumps({'onboarded':True,'done':{'79':'5/5'},'stars':{'79':3},'notes':{'79':'Important legacy note'},'checks':{},'sound':False})}
    page.evaluate('''db=>{window.__db=db;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__db[k]??null,setItem:(k,v)=>window.__db[k]=String(v),removeItem:k=>delete window.__db[k],clear:()=>{Object.keys(window.__db).forEach(k=>delete window.__db[k]);}}});}''',data)
    page.set_content(html,wait_until='domcontentloaded',timeout=90000)
    page.wait_for_function('window.LOONIE_V10 && window.LOONIE_V9 && window.LOONIE_V8')
    return ctx,page
errors=[]

def route(page,h):
    page.evaluate('''()=>{document.querySelectorAll('.overlay').forEach(e=>e.remove());}''')
    page.evaluate('h=>{location.hash="#"+h;route();}',h)
    assert 'Something went wrong' not in page.locator('#screen').inner_text(),(h,page.locator('#screen').inner_text()[:700])

def select_answers(page,kind,id,n=0,correct=True):
    qs=page.evaluate('''([kind,id,n,correct])=>{let r=LOONIE_V10.regions.find(x=>x.id===id),ids=LOONIE_V10.lessonsFor(r);let qs=kind==='guard'?LOONIE_V10.sourceQs(ids,5):kind==='daily'?LOONIE_V10.dailyQs():LOONIE_V10.sourceQs([ids[n]],3);for(let i=0;i<qs.length;i++){let q=qs[i],a=correct?q.a:(q.a+1)%q.o.length;document.querySelector(`.kingdom-choice[data-q="${i}"][data-a="${a}"]`).click();}document.querySelector('#king-submit').click();return qs;}''',[kind,id,n,correct])
    assert page.locator('.kingdom-result').count()==1,(kind,id,page.locator('#screen').inner_text()[-1000:])
    return qs

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx,page=init(browser)
    page.on('pageerror',lambda e:errors.append(str(e)))
    print('INITIAL VALIDATION',page.evaluate('LOONIE_V10.validate()'),flush=True)
    assert page.evaluate('LOONIE_V10.validate().ok')
    assert page.evaluate('LOONIE_V9.validate().ok')
    assert page.evaluate('LOONIE_V8.validate().ok')
    assert page.evaluate('LESSONS.length')==807
    assert page.evaluate('LESSONS.reduce((n,l)=>n+l.quiz.length,0)')==3714
    assert page.evaluate('state.notes[79]')=='Important legacy note'
    assert page.evaluate('!state.kingdomV10 || !Object.keys(state.kingdomV10.quests||{}).length')
    for h,t in [('world','Knowledge World'),('learn','Study hub'),('kingdom','Every lesson'),('journal10','Expedition Journal'),('realm10-lantern','Lantern Library'),('practice','Practice'),('lab','Experimental Lab'),('inquiry','Interactive Inquiry'),('uni','Personal University'),('experiment-lab','Experimental Labs'),('notebook','Research Notebook')]:
        route(page,h);assert t.lower() in page.locator('#screen').inner_text().lower(),h
        print('ROUTE',h,'OK',flush=True)
    # Test gating: guardian & lesson and chapter 2 are locked initially.
    route(page,'guardian10-lantern');assert 'Complete both story quests' in page.locator('#screen').inner_text()
    route(page,'quest10-lantern-1');assert 'Complete Chapter 1' in page.locator('#screen').inner_text()
    route(page,'quest10-lantern-0');assert 'Finish the lesson' in page.locator('#screen').inner_text()
    route(page,'realm10-lantern');assert page.locator('#king-build').is_disabled()
    assert not page.evaluate('LOONIE_V10.build("lantern").ok')

    for idx,r in enumerate(page.evaluate('LOONIE_V10.regions')):
        rid=r['id']
        ids=page.evaluate('id=>LOONIE_V10.lessonsFor(LOONIE_V10.regions.find(x=>x.id===id))',rid)
        # The quest reads the existing lesson-completion system: set in the isolated QA profile.
        for n,lid in enumerate(ids):
            page.evaluate('id=>{state.done[id]="3/3";state.stars[id]=3;save();}',lid)
            route(page,f'quest10-{rid}-{n}')
            assert page.locator('.kingdom-question').count()==3
            if idx==0 and n==0:
                # Partial submissions must not mark completion; incorrect responses must not pay.
                before=page.evaluate('LOONIE_V10.scores()')
                page.locator('#king-submit').click()
                assert 'Answer every question' in page.locator('#king-feedback').inner_text()
                select_answers(page,'quest',rid,n,correct=False)
                assert not page.evaluate('LOONIE_V10.isQuest("lantern",0)')
                assert page.evaluate('LOONIE_V10.scores().sparks')==before['sparks']
                route(page,f'quest10-{rid}-{n}')
            select_answers(page,'quest',rid,n)
            assert page.evaluate('([id,n])=>LOONIE_V10.isQuest(id,n)',[rid,n])
            assert page.evaluate('LOONIE_V10.scores().quests')==idx*2+n+1
            # Reward guard: passing the same mission again does not grant additional XP/coins/sparks.
            if idx==0 and n==0:
                page.evaluate('''()=>document.querySelectorAll('.overlay').forEach(e=>e.remove())''')
                wallet=page.evaluate('({xp:state.xp,coins:state.coins,sparks:LOONIE_V10.scores().sparks})')
                route(page,'quest10-lantern-0');select_answers(page,'quest','lantern',0)
                assert page.evaluate('({xp:state.xp,coins:state.coins,sparks:LOONIE_V10.scores().sparks})')==wallet
            route(page,f'realm10-{rid}')
            assert page.locator('#king-build').is_enabled()
            page.locator('#king-build').click()
            assert page.evaluate('id=>LOONIE_V10.tier(id)',rid)==n+1
            assert page.evaluate('LOONIE_V10.scores().sparks')==0
        route(page,f'guardian10-{rid}')
        assert page.locator('.kingdom-question').count()==5
        if idx==0:
            # Guardian cannot be defeated with an all-wrong answer set.
            select_answers(page,'guard',rid,correct=False)
            assert not page.evaluate('LOONIE_V10.isGuard("lantern")')
            assert page.evaluate('LOONIE_V10.scores().sparks')==0
            route(page,'guardian10-lantern')
        select_answers(page,'guard',rid)
        assert page.evaluate('id=>LOONIE_V10.isGuard(id)',rid)
        assert page.evaluate('LOONIE_V10.scores().guardians')==idx+1
        route(page,f'realm10-{rid}')
        assert page.locator('#king-build').is_enabled()
        page.locator('#king-build').click()
        assert page.evaluate('id=>LOONIE_V10.tier(id)',rid)==3
        assert page.evaluate('LOONIE_V10.scores().sparks')==0
        print('REALM',rid,'2 quests + guardian + 3 builds PASS',flush=True)

    assert page.evaluate('LOONIE_V10.scores()')=={'quests':12,'guardians':6,'built':18,'sparks':0}
    assert page.evaluate('!!state.ach["kingdom-crown"]')
    assert page.evaluate('!!state.ach["kingdom-builder"]')
    route(page,'journal10');assert 'Royal Scholar' in page.locator('#screen').inner_text()
    route(page,'realm10-lantern')
    page.locator('#king-note').fill('I checked original calculations and noted that my knowledge depends on evidence. I will revisit this tomorrow.')
    note=page.evaluate('state.kingdomV10.notes.lantern');assert 'calculations' in note
    # Daily once-only reward even on replay.
    route(page,'daily10');assert page.locator('.kingdom-question').count()==3
    select_answers(page,'daily','lantern')
    assert page.evaluate('state.kingdomV10.daily.claimed')
    before=page.evaluate('({xp:state.xp,coins:state.coins})')
    route(page,'daily10');select_answers(page,'daily','lantern')
    assert page.evaluate('({xp:state.xp,coins:state.coins})')==before
    # Export/restore: independent app-wide backup includes kingdom and all old data.
    pack=page.evaluate('makeBackup()');parsed=json.loads(pack)
    assert parsed['state']['kingdomV10']['guardians']['lantern']['finishedAt']
    assert parsed['state']['notes']['79']=='Important legacy note'
    assert parsed['state']['kingdomV10']['notes']['lantern']==note
    assert parsed['checksum']
    print('BACKUP, LEGACY PRESERVATION, DAILY, REPLAY GATES PASS',flush=True)
    # Confirm responsive layout and reload persistence.
    route(page,'kingdom')
    page.screenshot(path=str(ROOT/'qa-kingdom-phone.png'),full_page=True)
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+5'),page.evaluate('({scroll:document.documentElement.scrollWidth,viewport:innerWidth})')
    route(page,'realm10-lantern');page.screenshot(path=str(ROOT/'qa-realm-phone.png'),full_page=True)
    backing=page.evaluate('window.__db')
    ctx2,page2=init(browser,backing)
    page2.on('pageerror',lambda e:errors.append(str(e)))
    assert page2.evaluate('LOONIE_V10.scores()')=={'quests':12,'guardians':6,'built':18,'sparks':0}
    assert page2.evaluate('state.kingdomV10.notes.lantern')==note
    assert page2.evaluate('LOONIE_V9.validate().ok && LOONIE_V8.validate().ok')
    print('PERSISTENCE IN FRESH CHROMIUM PAGE PASS',flush=True)
    # Desktop viewport
    desktop,dp=init(browser,{'loonieAcademy_v1':json.dumps({'onboarded':True,'sound':False})},{'width':1280,'height':800})
    dp.on('pageerror',lambda e:errors.append(str(e)))
    dp.evaluate('''()=>{location.hash='#kingdom';route()}''')
    assert dp.locator('.kingdom-region').count()==6
    assert dp.evaluate('document.documentElement.scrollWidth <= window.innerWidth+5')
    print('DESKTOP LAYOUT PASS',flush=True)
    assert not errors,errors[:8]
    print('PHASE 4 QA ALL PASS — 6 realms, 12 quests, 6 guardians, 18 build upgrades, replay protection, backup, reload',flush=True)
    desktop.close();ctx2.close();ctx.close();browser.close()
