ختمتي - KHATMATI
BY : NOUR ISLEM HADYAOUI

محتوى المجلد:
- index.html      التطبيق كامل
- manifest.json   معلومات التطبيق (الاسم، الألوان، الأيقونات)
- sw.js           يخليه يخدم بدون انترنت
- icons/          الأيقونات (192 و 512 و maskable)

الطريقة 1: تطبيق قابل للتثبيت (PWA)
1) ارفع المجلد كامل على Netlify (Drag and drop) او GitHub Pages
2) افتح الرابط في Chrome على الهاتف
3) القائمة ⋮ ثم "تثبيت التطبيق" / "اضافة الى الشاشة الرئيسية"

الطريقة 2: APK
- ارفع الرابط (من Netlify) على موقع PWABuilder.com ثم اختر Android وحمّل APK
- او ارفع هذا الـ zip مباشرة على موقع يحول HTML الى APK (مثل WebIntoApp)
