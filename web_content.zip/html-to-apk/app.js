/* PDF -> EPUB, jalan sepenuhnya di browser.
   Alur: baca PDF (pdf.js) -> kelompokkan teks jadi baris -> paragraf/judul
         -> bagi jadi bab -> bungkus jadi EPUB 3 (JSZip). */

pdfjsLib.GlobalWorkerOptions.workerSrc =
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

const $ = (id) => document.getElementById(id);
let pdfFile = null;

/* ---------- UI ---------- */
$('file').addEventListener('change', (e) => setFile(e.target.files[0]));
$('mode').addEventListener('change', () => {
  $('pagesWrap').hidden = $('mode').value !== 'pages';
});
const drop = $('drop');
['dragover', 'dragenter'].forEach((ev) =>
  drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach((ev) =>
  drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', (e) => setFile(e.dataTransfer.files[0]));

function setFile(f) {
  if (!f) return;
  if (!/\.pdf$/i.test(f.name)) { setStatus('File harus berformat PDF.'); return; }
  pdfFile = f;
  $('dropText').textContent = f.name;
  if (!$('title').value) $('title').placeholder = f.name.replace(/\.pdf$/i, '');
  $('go').disabled = false;
  $('download').hidden = true;
  setStatus('');
}
function setStatus(t) { $('status').textContent = t; }
function setProgress(p) { $('bar').hidden = false; $('bar').value = p; }

$('go').addEventListener('click', async () => {
  $('go').disabled = true;
  $('download').hidden = true;
  try {
    const opts = {
      title: $('title').value.trim() || pdfFile.name.replace(/\.pdf$/i, ''),
      author: $('author').value.trim() || 'Tidak diketahui',
      lang: $('lang').value,
      mode: $('mode').value,
      pagesPer: Math.max(1, parseInt($('pagesPer').value, 10) || 10),
      fontSize: $('fontSize').value,
    };
    const blob = await convert(pdfFile, opts);
    const url = URL.createObjectURL(blob);
    const a = $('download');
    a.href = url;
    a.download = opts.title.replace(/[\\/:*?"<>|]+/g, '_') + '.epub';
    a.hidden = false;
    setStatus('Selesai.');
  } catch (err) {
    console.error(err);
    setStatus('Gagal: ' + (err.message || err));
  } finally {
    $('go').disabled = false;
  }
});

/* ---------- Konversi ---------- */
async function convert(file, opts) {
  setStatus('Membaca PDF...');
  const data = new Uint8Array(await file.arrayBuffer());
  const pdf = await pdfjsLib.getDocument({ data }).promise;

  const pages = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    pages.push(await extractPage(await pdf.getPage(i)));
    setProgress((i / pdf.numPages) * 70);
    setStatus(`Mengekstrak teks: halaman ${i} dari ${pdf.numPages}`);
  }

  const totalChars = pages.flat().reduce((n, l) => n + l.text.length, 0);
  if (totalChars < 20) {
    throw new Error('PDF ini tidak punya teks (kemungkinan hasil scan). Perlu OCR dulu.');
  }

  setStatus('Menyusun paragraf dan bab...');
  const blocks = buildBlocks(pages);
  const chapters = splitChapters(blocks, opts);

  setStatus('Membuat file EPUB...');
  const blob = await buildEpub(chapters, opts);
  setProgress(100);
  return blob;
}

/* Satu halaman -> daftar baris {text, y, size, x0, x1} */
async function extractPage(page) {
  const tc = await page.getTextContent();
  const rows = [];
  for (const it of tc.items) {
    if (!it.str || !it.str.trim()) continue;
    const size = Math.hypot(it.transform[2], it.transform[3]) || it.height || 10;
    const x = it.transform[4], y = it.transform[5];
    let row = rows.find((r) => Math.abs(r.y - y) < size * 0.4);
    if (!row) { row = { y, size: 0, items: [] }; rows.push(row); }
    row.items.push({ str: it.str, x, w: it.width, size });
  }
  rows.sort((a, b) => b.y - a.y); // atas ke bawah
  return rows.map((r) => {
    r.items.sort((a, b) => a.x - b.x);
    let text = '', prevEnd = null;
    for (const it of r.items) {
      if (prevEnd !== null && it.x - prevEnd > it.size * 0.15 && !text.endsWith(' ')) text += ' ';
      text += it.str;
      prevEnd = it.x + it.w;
    }
    const size = Math.max(...r.items.map((i) => i.size));
    return {
      text: text.replace(/\s+/g, ' ').trim(),
      y: r.y, size,
      x0: r.items[0].x, x1: prevEnd,
    };
  }).filter((l) => l.text);
}

/* Semua halaman -> blok {type: h1|h2|p, text} */
function buildBlocks(pages) {
  // ukuran huruf isi (median berbobot jumlah karakter)
  const sizes = [];
  pages.flat().forEach((l) => { for (let i = 0; i < l.text.length; i += 10) sizes.push(l.size); });
  sizes.sort((a, b) => a - b);
  const body = sizes[Math.floor(sizes.length / 2)] || 10;

  const blocks = [];
  let para = null, prev = null;
  const flush = () => { if (para) blocks.push({ type: 'p', text: para.trim() }); para = null; };

  pages.forEach((lines) => {
    const maxW = Math.max(1, ...lines.map((l) => l.x1 - l.x0));
    prev = null;
    // buang nomor halaman yang berdiri sendiri
    lines = lines.filter((l, i) => !(/^\d{1,4}$/.test(l.text) && (i === 0 || i === lines.length - 1)));

    lines.forEach((l) => {
      const level = l.size >= body * 1.5 ? 'h1' : l.size >= body * 1.2 ? 'h2' : null;
      if (level && l.text.length < 120) {
        flush();
        const last = blocks[blocks.length - 1];
        if (last && last.type === level && !last.closed) last.text += ' ' + l.text; // judul multi-baris
        else blocks.push({ type: level, text: l.text });
        prev = l;
        return;
      }
      if (blocks.length) blocks[blocks.length - 1].closed = true;

      const gap = prev ? prev.y - l.y : 0;
      const bigGap = prev && gap > l.size * 1.7;
      const prevShort = prev && (prev.x1 - prev.x0) < maxW * 0.6 && /[.!?:”"')]$/.test(prev.text);

      if (para === null) {
        para = l.text;
      } else if (bigGap || prevShort) {
        flush();
        para = l.text;
      } else if (/[a-zA-Z]-$/.test(para)) {
        para = para.slice(0, -1) + l.text;   // sambung kata yang terpotong tanda hubung
      } else {
        para += ' ' + l.text;
      }
      prev = l;
    });
  });
  flush();
  return blocks;
}

/* Blok -> bab [{title, blocks}] */
function splitChapters(blocks, opts) {
  if (opts.mode === 'single') return [{ title: opts.title, blocks }];

  if (opts.mode === 'heading') {
    const hasH1 = blocks.some((b) => b.type === 'h1');
    const key = hasH1 ? 'h1' : 'h2';
    const out = [];
    let cur = null;
    for (const b of blocks) {
      if (b.type === key) {
        cur = { title: b.text, blocks: [b] };
        out.push(cur);
      } else {
        if (!cur) { cur = { title: 'Awal', blocks: [] }; out.push(cur); }
        cur.blocks.push(b);
      }
    }
    if (out.length >= 2) return out;
    // tidak ada judul yang terdeteksi: pakai pembagian per halaman
  }

  // per N "halaman": perkiraan dari jumlah blok, karena blok lintas halaman
  const per = opts.mode === 'pages' ? opts.pagesPer : 10;
  const perChapter = Math.max(5, per * 6); // ~6 paragraf per halaman
  const out = [];
  for (let i = 0; i < blocks.length; i += perChapter) {
    out.push({ title: `Bagian ${out.length + 1}`, blocks: blocks.slice(i, i + perChapter) });
  }
  return out.length ? out : [{ title: opts.title, blocks }];
}

/* ---------- EPUB ---------- */
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function chapterXhtml(ch, opts) {
  const body = ch.blocks.map((b) =>
    b.type === 'p' ? `<p>${esc(b.text)}</p>` : `<${b.type}>${esc(b.text)}</${b.type}>`).join('\n');
  const hasHeading = ch.blocks.some((b) => b.type !== 'p');
  return `<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="${opts.lang}" xml:lang="${opts.lang}">
<head><meta charset="utf-8"/><title>${esc(ch.title)}</title>
<link rel="stylesheet" type="text/css" href="style.css"/></head>
<body>
${hasHeading ? '' : `<h2>${esc(ch.title)}</h2>`}
${body}
</body></html>`;
}

async function buildEpub(chapters, opts) {
  const zip = new JSZip();
  const id = 'urn:uuid:' + (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()));
  const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');

  // 1. mimetype harus pertama dan tidak dikompres
  zip.file('mimetype', 'application/epub+zip', { compression: 'STORE' });

  zip.file('META-INF/container.xml',
`<?xml version="1.0"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
<rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles>
</container>`);

  // Gaya tampilan buku: ubah di sini
  zip.file('OEBPS/style.css',
`body{font-size:${opts.fontSize};line-height:1.5;margin:0 4%}
h1{font-size:1.6em;margin:1.5em 0 .7em;text-align:center}
h2{font-size:1.25em;margin:1.3em 0 .6em}
p{margin:0 0 .8em;text-align:justify;text-indent:0}`);

  chapters.forEach((ch, i) => zip.file(`OEBPS/ch${i + 1}.xhtml`, chapterXhtml(ch, opts)));

  const navItems = chapters.map((ch, i) => `<li><a href="ch${i + 1}.xhtml">${esc(ch.title)}</a></li>`).join('\n');
  zip.file('OEBPS/nav.xhtml',
`<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="${opts.lang}">
<head><meta charset="utf-8"/><title>Daftar isi</title></head>
<body><nav epub:type="toc" id="toc"><h1>Daftar isi</h1><ol>
${navItems}
</ol></nav></body></html>`);

  const ncxPoints = chapters.map((ch, i) =>
`<navPoint id="n${i + 1}" playOrder="${i + 1}"><navLabel><text>${esc(ch.title)}</text></navLabel><content src="ch${i + 1}.xhtml"/></navPoint>`).join('\n');
  zip.file('OEBPS/toc.ncx',
`<?xml version="1.0" encoding="utf-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
<head><meta name="dtb:uid" content="${id}"/></head>
<docTitle><text>${esc(opts.title)}</text></docTitle>
<navMap>
${ncxPoints}
</navMap></ncx>`);

  const manifest = chapters.map((_, i) =>
    `<item id="ch${i + 1}" href="ch${i + 1}.xhtml" media-type="application/xhtml+xml"/>`).join('\n');
  const spine = chapters.map((_, i) => `<itemref idref="ch${i + 1}"/>`).join('\n');
  zip.file('OEBPS/content.opf',
`<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" xml:lang="${opts.lang}">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="bookid">${id}</dc:identifier>
<dc:title>${esc(opts.title)}</dc:title>
<dc:creator>${esc(opts.author)}</dc:creator>
<dc:language>${opts.lang}</dc:language>
<meta property="dcterms:modified">${now}</meta>
</metadata>
<manifest>
<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
<item id="css" href="style.css" media-type="text/css"/>
${manifest}
</manifest>
<spine toc="ncx">
${spine}
</spine>
</package>`);

  return zip.generateAsync({ type: 'blob', mimeType: 'application/epub+zip', compression: 'DEFLATE' });
}
