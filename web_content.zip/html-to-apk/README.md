# PDF ke EPUB

Konverter berbasis web. Semua proses di browser, tanpa server.

## Cara pakai
1. Buka `index.html` di browser (butuh internet untuk memuat pdf.js dan JSZip dari CDN).
2. Pilih PDF, isi judul/penulis, klik Konversi, lalu Unduh.

Kalau browser menolak membuka langsung dari file, jalankan server lokal di folder ini:
`python -m http.server 8000` lalu buka `http://localhost:8000`.

## File
- `index.html` - tampilan dan form
- `style.css` - gaya tampilan aplikasi
- `app.js` - seluruh logika

## Bagian yang bisa kamu ubah di `app.js`
- `extractPage` - cara teks dikelompokkan jadi baris
- `buildBlocks` - deteksi judul (`body * 1.5` = h1, `body * 1.2` = h2) dan paragraf (`l.size * 1.7` = jarak antar paragraf)
- `splitChapters` - aturan pembagian bab
- `buildEpub` - isi CSS buku dan metadata

## Batasan
- PDF hasil scan (gambar) tidak punya teks, butuh OCR dulu.
- Tata letak dua kolom, tabel, dan gambar tidak dipertahankan.
- Struktur bab bergantung pada ukuran huruf judul, jadi hasilnya tergantung PDF.
