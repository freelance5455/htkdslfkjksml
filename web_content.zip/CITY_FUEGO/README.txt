CITY FUEGO

INSTALLATION:
1. Installer Node.js LTS.
2. Ouvrir un terminal dans ce dossier.
3. npm install
4. npm start
5. Ouvrir http://localhost:3000

ADMIN PAR DEFAUT:
Email: admin@cityfuego.com
Mot de passe: ChangeMoi123456!

IMPORTANT: change OWNER_PASSWORD et JWT_SECRET dans .env avant une mise en ligne publique.
Le dossier data contient SQLite et uploads les images.
