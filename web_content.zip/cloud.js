(function () {
  const statusEl = () => document.getElementById("cloudStatus");
  const setStatus = (message) => { if (statusEl()) statusEl().textContent = message; };
  const configured = () => {
    const c = window.STUDY_BUDDY_FIREBASE_CONFIG;
    return c && c.apiKey && !c.apiKey.startsWith("PASTE_") &&
      c.projectId && !c.projectId.startsWith("YOUR_");
  };

  let auth, db, saveTimer;
  function setSignedInUI(user) {
    const logout = document.getElementById("cloudLogoutBtn");
    const login = document.getElementById("cloudLoginBtn");
    const register = document.getElementById("cloudRegisterBtn");
    if (logout) logout.hidden = !user;
    if (login) login.hidden = !!user;
    if (register) register.hidden = !!user;
  }

  if (!configured()) {
    setStatus("Not connected yet. Add your Firebase web config in firebase-config.js.");
    return;
  }
  if (!window.firebase) {
    setStatus("Firebase SDK could not load. Check your internet connection.");
    return;
  }

  try {
    firebase.initializeApp(window.STUDY_BUDDY_FIREBASE_CONFIG);
    auth = firebase.auth();
    db = firebase.firestore();
    auth.onAuthStateChanged(async (user) => {
      setSignedInUI(user);
      if (!user) {
        setStatus("Signed out. Your current browser copy remains available.");
        return;
      }
      setStatus("Signed in as " + user.email + ". Loading your cloud data…");
      try {
        const ref = db.collection("users").doc(user.uid);
        const snap = await ref.get();
        if (snap.exists && window.studyBuddyApplyCloudState) {
          window.studyBuddyApplyCloudState(snap.data().appState);
          setStatus("Cloud data loaded. Your account is syncing.");
        } else {
          await ref.set({
            email: user.email || null,
            appState: window.studyBuddyGetState ? window.studyBuddyGetState() : {},
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
          });
          setStatus("Cloud backup created for this account.");
        }
      } catch (err) {
        setStatus("Cloud read failed: " + (err.message || "Check Firestore rules."));
      }
    });

    window.studyBuddyCloudSave = (appState) => {
      const user = auth.currentUser;
      if (!user) return;
      clearTimeout(saveTimer);
      saveTimer = setTimeout(async () => {
        try {
          await db.collection("users").doc(user.uid).set({
            email: user.email || null,
            appState: appState,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
          }, { merge: true });
          setStatus("Saved securely to your cloud account.");
        } catch (err) {
          setStatus("Cloud save failed: " + (err.message || "Check Firestore rules."));
        }
      }, 700);
    };

    const form = document.getElementById("cloudAuthForm");
    if (form) form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const email = document.getElementById("cloudEmail").value.trim();
      const password = document.getElementById("cloudPassword").value;
      try {
        await auth.signInWithEmailAndPassword(email, password);
      } catch (err) {
        setStatus("Sign-in failed: " + (err.message || "Check your details."));
      }
    });
    const register = document.getElementById("cloudRegisterBtn");
    if (register) register.addEventListener("click", async () => {
      const email = document.getElementById("cloudEmail").value.trim();
      const password = document.getElementById("cloudPassword").value;
      if (!email || password.length < 6) {
        setStatus("Enter a valid email and a password of at least 6 characters.");
        return;
      }
      try {
        await auth.createUserWithEmailAndPassword(email, password);
        setStatus("Account created. Cloud sync is now enabled.");
      } catch (err) {
        setStatus("Account creation failed: " + (err.message || "Check Firebase settings."));
      }
    });
    const logout = document.getElementById("cloudLogoutBtn");
    if (logout) logout.addEventListener("click", () => auth.signOut());
  } catch (err) {
    setStatus("Firebase setup error: " + (err.message || "Check firebase-config.js."));
  }
})();
