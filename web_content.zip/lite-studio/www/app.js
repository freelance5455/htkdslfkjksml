'use strict';
const $=id=>document.getElementById(id),cv=$('cv'),cx=cv.getContext('2d');
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
/* ---------- Studio ---------- */
let uid=1,scenes=[{name:'Scene 1',src:[{id:uid++,t:'color',on:1,c:'#1d3557'},{id:uid++,t:'text',on:1,x:'Lite Studio'}]}],cur=0,vid=document.createElement('video'),camOn=0,micS=null,an=null,mute=0,rc=null,lc=null,ws=null,chunks=[],fps=30,kbps=3000,sent=0,gtok=null;
vid.muted=true;vid.playsInline=true;
const S=()=>scenes[cur];
function toast(m){const t=$('toast');t.textContent=m;t.style.display='block';clearTimeout(t.h);t.h=setTimeout(()=>t.style.display='none',4000)}
function tab(p){document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.p==p));document.querySelectorAll('.pan').forEach(d=>d.classList.toggle('on',d.id==p))}
$('nav').onclick=e=>e.target.dataset.p&&tab(e.target.dataset.p);
const NAMES={camera:'📷 Camera',color:'🎨 Color'};
function render(){
$('scl').innerHTML=scenes.map((s,i)=>`<div class="row ${i==cur?'sel':''}"><span data-a="sel" data-i="${i}">${esc(s.name)}</span>${scenes.length>1?`<button data-a="dsc" data-i="${i}">🗑</button>`:''}</div>`).join('');
$('sol').innerHTML=S().src.map((o,i)=>`<div class="row"><span>${o.t=='text'?'🔤 '+esc(o.x):NAMES[o.t]}</span>${o.t=='text'?`<button data-a="edt" data-i="${i}">✏️</button>`:''}${o.t=='color'?`<input class="clr" type="color" value="${/^#[0-9a-f]{6}$/i.test(o.c)?o.c:'#000000'}" data-a="clr" data-i="${i}">`:''}<button data-a="tgl" data-i="${i}">${o.on?'👁':'🚫'}</button><button data-a="dso" data-i="${i}">🗑</button></div>`).join('')||'<small>No sources</small>'}
document.addEventListener('click',e=>{const el=e.target.closest('[data-a]');if(!el)return;const i=+el.dataset.i,a=el.dataset.a;
if(a=='sel')cur=i;else if(a=='dsc'){scenes.splice(i,1);cur=0}else if(a=='dso')S().src.splice(i,1);else if(a=='tgl')S().src[i].on^=1;
else if(a=='edt'){const v=prompt('Text',S().src[i].x);if(v!==null)S().src[i].x=v.slice(0,80)}else return;render()});
document.addEventListener('change',e=>{if(e.target.dataset.a=='clr')S().src[+e.target.dataset.i].c=e.target.value});
$('addsc').onclick=()=>{scenes.push({name:'Scene '+(scenes.length+1),src:[]});cur=scenes.length-1;render()};
document.querySelectorAll('[data-add]').forEach(b=>b.onclick=async()=>{const t=b.dataset.add;if(t=='camera')await cam();S().src.push({id:uid++,t,on:1,c:'#2a9d8f',x:'New text'});render()});
async function cam(){if(camOn)return;try{const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:$('face').value,width:{ideal:1280},height:{ideal:720}},audio:false});vid.srcObject=s;await vid.play();camOn=s}catch(e){toast('Camera unavailable. Allow camera permission.')}}
$('face').onchange=()=>{if(camOn){camOn.getTracks().forEach(t=>t.stop());camOn=0;cam()}};
$('mic').onclick=async()=>{if(micS){mute^=1;micS.getAudioTracks().forEach(t=>t.enabled=!mute);$('mic').textContent=mute?'Unmute':'Mute';return}
try{micS=await navigator.mediaDevices.getUserMedia({audio:true});const ac=new AudioContext();an=ac.createAnalyser();an.fftSize=256;ac.createMediaStreamSource(micS).connect(an);$('mic').textContent='Mute'}catch(e){toast('Mic permission denied.')}};
const d8=new Uint8Array(128);
function draw(){cx.clearRect(0,0,cv.width,cv.height);
for(const o of S().src){if(!o.on)continue;
if(o.t=='color'){cx.fillStyle=o.c;cx.fillRect(0,0,cv.width,cv.height)}
else if(o.t=='camera'&&camOn&&vid.videoWidth){const r=Math.max(cv.width/vid.videoWidth,cv.height/vid.videoHeight),w=vid.videoWidth*r,h=vid.videoHeight*r;cx.drawImage(vid,(cv.width-w)/2,(cv.height-h)/2,w,h)}
else if(o.t=='text'){cx.fillStyle='#fff';cx.font='bold '+cv.height/9+'px sans-serif';cx.textAlign='center';cx.textBaseline='middle';cx.fillText(o.x,cv.width/2,cv.height/2,cv.width*.9)}}
if(an){an.getByteTimeDomainData(d8);let m=0;for(const v of d8)m=Math.max(m,Math.abs(v-128));$('lv').style.width=Math.min(100,m/1.2)+'%'}
setTimeout(draw,1000/fps)}
function setRes(){const[w,h,k]=$('res').value.split('x');cv.width=+w;cv.height=+h;kbps=+k;fps=+$('fps').value}
$('res').onchange=$('fps').onchange=setRes;
const mime=()=>['video/webm;codecs=h264,opus','video/webm;codecs=vp8,opus','video/webm','video/mp4'].find(m=>MediaRecorder.isTypeSupported(m));
function stream(){const st=cv.captureStream(fps);let a=micS&&micS.getAudioTracks()[0];if(!a)a=new AudioContext().createMediaStreamDestination().stream.getAudioTracks()[0];st.addTrack(a);return st}
$('rec').onclick=()=>{if(rc){rc.stop();return}
if(!window.MediaRecorder)return toast('Recording not supported here.');
chunks=[];const mt=mime();rc=new MediaRecorder(stream(),{mimeType:mt,videoBitsPerSecond:kbps*1000});
rc.ondataavailable=e=>e.data.size&&chunks.push(e.data);
rc.onstop=()=>{const v=document.createElement('video');v.src=URL.createObjectURL(new Blob(chunks,{type:mt}));v.controls=true;$('out').replaceChildren(v);rc=null;chunks=[];$('rec').textContent='⏺ Record';$('rec').classList.remove('red')};
rc.start(1000);$('rec').textContent='⏹ Stop';$('rec').classList.add('red')};
function stopLive(msg){if(lc&&lc.state!='inactive')lc.stop();lc=null;const w=ws;ws=null;if(w){try{w.close()}catch(e){}}$('live').style.display='none';$('go').textContent='📡 Go Live';$('go').classList.replace('red','grn');if(msg)toast(msg)}
$('go').onclick=()=>{if(ws)return stopLive('Stream stopped.');
const relay=$('relay').value.trim(),key=$('key').value.trim(),token=$('tok').value;
if(!relay||!key||!token){tab('sm');return toast('Enter relay URL, password and stream key.')}
if(!/^wss:\/\/[^\s\/]+(:\d+)?(\/\S*)?$/.test(relay))return toast('Relay must use wss:// (encrypted).');
if(!window.MediaRecorder)return toast('Streaming not supported here.');
sent=0;ws=new WebSocket(relay);const me=ws;
me.onopen=()=>{me.send(JSON.stringify({key,fps,kbps,token}));
lc=new MediaRecorder(stream(),{mimeType:mime(),videoBitsPerSecond:kbps*1000,audioBitsPerSecond:128000});
lc.ondataavailable=e=>{if(e.data.size&&ws===me&&me.readyState==1){me.send(e.data);sent+=e.data.size;$('stat').textContent='Sent '+(sent/1048576).toFixed(1)+' MB'}};
lc.start(500);$('live').style.display='block';$('go').textContent='⏹ End Live';$('go').classList.replace('grn','red')};
me.onerror=()=>ws===me&&stopLive('Cannot reach relay server.');
me.onclose=()=>ws===me&&stopLive('Connection closed.')};
function loadGsi(){return new Promise((ok,no)=>{if(window.google&&google.accounts)return ok();const s=document.createElement('script');s.src='https://accounts.google.com/gsi/client';s.onload=ok;s.onerror=no;document.head.appendChild(s)})}
$('gsign').onclick=async()=>{const cid=$('cid').value.trim();if(!/^[\w.-]+\.apps\.googleusercontent\.com$/.test(cid))return toast('Enter a valid Google Client ID.');
try{await loadGsi()}catch(e){return toast('Google script failed to load.')}
google.accounts.oauth2.initTokenClient({client_id:cid,scope:'https://www.googleapis.com/auth/youtube.readonly',callback:async r=>{
if(r.error)return toast('Sign-in failed.');gtok=r.access_token;$('who').textContent='Signed in ✓';
try{const j=await(await fetch('https://www.googleapis.com/youtube/v3/liveStreams?part=cdn&mine=true',{headers:{Authorization:'Bearer '+gtok}})).json();
const k=j.items&&j.items[0]&&j.items[0].cdn.ingestionInfo.streamName;if(k){$('key').value=k;toast('Stream key filled from YouTube.')}else toast('No stream key found. Enable live streaming on your channel.')}catch(e){toast('Could not fetch stream key.')}}}).requestAccessToken()};
$('gout').onclick=()=>{if(gtok&&window.google)google.accounts.oauth2.revoke(gtok,()=>{});gtok=null;$('who').textContent='Not signed in';toast('Signed out.')};
$('clr').onclick=()=>{$('key').value='';$('tok').value='';$('relay').value='';toast('Secrets cleared.')};
render();draw();
