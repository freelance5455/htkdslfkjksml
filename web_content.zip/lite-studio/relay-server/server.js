// Hardened relay: WebSocket (behind HTTPS proxy) -> ffmpeg -> YouTube RTMPS.
const { WebSocketServer } = require('ws');
const { spawn } = require('child_process');
const crypto = require('crypto');
const TOKEN = process.env.RELAY_TOKEN || '';
if (TOKEN.length < 16) { console.error('Set RELAY_TOKEN to 16+ random characters.'); process.exit(1); }
const PORT = +process.env.PORT || 8080, MAX_STREAMS = +process.env.MAX_STREAMS || 1, MAX_HOURS = +process.env.MAX_HOURS || 12;
const dig = s => crypto.createHash('sha256').update(String(s)).digest();
const good = t => crypto.timingSafeEqual(dig(t), dig(TOKEN));
const bad = new Map(); let active = 0;
const wss = new WebSocketServer({ host: '127.0.0.1', port: PORT, maxPayload: 2 * 1024 * 1024 });
wss.on('connection', (ws, req) => {
  const ip = process.env.TRUST_PROXY ? (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress : req.socket.remoteAddress;
  const b = bad.get(ip) || { n: 0, until: 0 };
  if (Date.now() < b.until) return ws.terminate();
  let ff = null, life = null;
  const hs = setTimeout(() => !ff && ws.terminate(), 5000);
  const fail = () => { b.n++; if (b.n >= 5) { b.until = Date.now() + 15 * 60e3; b.n = 0; } bad.set(ip, b); ws.terminate(); };
  ws.on('message', m => {
    if (!ff) {
      let c; try { c = JSON.parse(m.toString()); } catch { return fail(); }
      if (typeof c.token !== 'string' || !good(c.token)) return fail();
      if (typeof c.key !== 'string' || !/^[\w-]{8,64}$/.test(c.key)) return ws.terminate();
      if (active >= MAX_STREAMS) return ws.terminate();
      clearTimeout(hs); bad.delete(ip); active++;
      const fps = Math.min(60, Math.max(10, +c.fps || 30)), k = Math.min(9000, Math.max(500, +c.kbps || 4500));
      ff = spawn('ffmpeg', ['-loglevel','error','-protocol_whitelist','pipe','-i','pipe:0','-c:v','libx264','-preset','veryfast','-tune','zerolatency','-pix_fmt','yuv420p','-b:v',k+'k','-maxrate',k+'k','-bufsize',2*k+'k','-g',String(fps*2),'-r',String(fps),'-c:a','aac','-b:a','128k','-ar','44100','-f','flv','rtmps://a.rtmps.youtube.com:443/live2/'+c.key], { stdio: ['pipe','ignore','ignore'] });
      ff.stdin.on('error', () => {});
      ff.on('close', () => { active--; clearTimeout(life); ws.terminate(); });
      life = setTimeout(() => ws.terminate(), MAX_HOURS * 3600e3);
      return;
    }
    if (ff.stdin.writable) ff.stdin.write(m);
  });
  ws.on('close', () => { clearTimeout(hs); if (ff) { ff.stdin.end(); setTimeout(() => ff.kill('SIGKILL'), 3000); } });
  ws.on('error', () => ws.terminate());
});
console.log('Relay on 127.0.0.1:' + PORT + ' (put an HTTPS proxy in front)');
