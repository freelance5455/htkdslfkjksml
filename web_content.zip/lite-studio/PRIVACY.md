# Privacy Policy — Lite Studio
Last updated: October 21, 2026

**Summary:** Lite Studio does not collect, store, sell or share your personal data.

## What the app accesses
- **Camera and microphone:** only while the app is open and only after you allow permission. Used to build your preview, recording and live stream.
- **Google account (optional):** if you tap "Sign in with Google", the app requests read-only YouTube access solely to fill in your stream key. The access token is kept in memory only and revoked when you tap Sign out.

## What leaves your device
- **Live streaming:** when you tap Go Live, your video and audio go over an encrypted connection (wss://) to the relay server you configured, which forwards them to YouTube over RTMPS. The relay server is run by you; it does not store or log your stream.
- **Recordings:** stay on your phone until you save or delete them. They are never uploaded by the app.

## What is stored
Nothing. Stream key, relay password, Client ID and Google token live in memory and disappear when the app closes. The app has no analytics, ads, trackers or crash reporting.

## Your control
Revoke camera/microphone in Android settings at any time. Sign out inside the app, or remove access at myaccount.google.com/permissions. Reset your stream key in YouTube Studio if you think it leaked.

## Third parties
Google/YouTube process data under their own policies (policies.google.com/privacy).

## Contact
Add your email here: ______________
