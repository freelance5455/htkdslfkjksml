# Lite Studio (secured)

## Relay server
    cd relay-server && npm install
    RELAY_TOKEN="<16+ random chars>" TRUST_PROXY=1 node server.js
- Listens on 127.0.0.1 only; Caddy (see Caddyfile) adds HTTPS/wss automatically.
- Firewall: allow only 443 (and SSH). Run as a non-root user. Keep Node/ffmpeg updated.
- Password required, constant-time check, 5 bad tries = 15 min ban, 1 stream at a time, size and time limits.
- Video goes to YouTube over RTMPS (encrypted).

## Android app (Capacitor)
    npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
    (use the provided capacitor.config.json)  npx cap add android
In android/app/src/main/AndroidManifest.xml:
- add permissions CAMERA, RECORD_AUDIO, MODIFY_AUDIO_SETTINGS
- on <application> set  android:allowBackup="false"  android:usesCleartextTraffic="false"
In MainActivity.java, inside onCreate after super.onCreate:
    getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE);
(blocks screenshots, screen recording and the recent-apps preview)
Build a signed RELEASE APK with minify enabled (never publish the debug build).

## What is protected
- No secrets stored; key/password/Google token live in memory only
- Strict Content-Security-Policy, no inline scripts, escaped text, wss-only relay
- Google token is read-only YouTube scope and is revoked on Sign out

## Limits (be aware)
- There is no app lock. Anyone holding your unlocked phone can open the app. If your stream key leaks, reset it in YouTube Studio.
- Never share these files after typing real secrets into them; none are stored in the files.
