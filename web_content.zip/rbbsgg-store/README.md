# RBBSGG STORE

Scout Store Management & Billing app (inventory, purchases, customers, billing, invoices, reports, signature).

## Folder structure
```
rbbsgg-store/
  index.html        page skeleton
  css/style.css     all styling (violet & white theme, Poppins font)
  js/app.js         all app logic (data, views, billing, reports)
  assets/           logo.jpg, icon-192.png, icon-512.png
  manifest.json     makes it installable on Android
  sw.js             service worker (offline support)
```

## Step 1: Test on a computer
Open a terminal in this folder and run `python3 -m http.server 8000`, then open http://localhost:8000

## Step 2: Put it online (free, HTTPS needed for install)
Upload the whole folder to GitHub Pages, Netlify (drag & drop) or Cloudflare Pages.

## Step 3: Install on Android
Open the link in Chrome, tap the menu (three dots), then "Add to Home screen" / "Install app".

## Step 4 (optional): Real APK
Give your hosted link to https://www.pwabuilder.com and choose Android, or wrap the folder with Capacitor.

## Notes
- Data is saved in the phone browser (localStorage). Use Settings > Backup > Export regularly.
- Barcode labels use JsBarcode and the font uses Google Fonts (both load from the internet).
- Printing an invoice and choosing "Save as PDF" creates the PDF.
- Database: all data functions are in js/app.js (the `S` object and `save()`); to move to Supabase later, replace `save()` and the initial load.
