/* JOSTECH — COURS 04 : CYBERSÉCURITÉ (NIVEAUX 1, 2 & 3) */
registerDisciplineLevels(4, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Triade CIA, menaces numériques courantes et hygiène de sécurité.",
    chapters: [{
      id: "sec-1-1", title: "Chapitre 1 : Fondements de la Cybersécurité",
      lessons: [{
        id: "sec-1-1-1", title: "Leçon 1 : La Triade CIA et les Menaces Courantes", duration: "25 min",
        objectives: ["Maîtriser les 3 piliers : Confidentialité, Intégrité, Disponibilité.", "Identifier phishing, ransomwares et ingénierie sociale."],
        prerequisites: ["Culture numérique et bases des réseaux."],
        sections: [
          { type: "definition", term: "Triade CIA (Confidentiality, Integrity, Availability)", text: "• Confidentialité : seules les personnes autorisées peuvent lire l'information (ex: chiffrement).\n• Intégrité : les données n'ont pas été altérées ni falsifiées en chemin.\n• Disponibilité : les systèmes et cours restent accessibles quand les utilisateurs en ont besoin." },
          { type: "table", title: "Menaces principales", headers: ["Menace", "Mécanisme", "Parade clé"], rows: [
            ["Phishing (Hameçonnage)", "Faux e-mail/SMS imitant une banque ou université pour voler un mot de passe.", "Vérifier l'URL exacte + activer MFA."],
            ["Ransomware", "Logiciel malveillant chiffrant les fichiers pour exiger une rançon.", "Sauvegardes hors ligne (3-2-1) + mises à jour."],
            ["Ingénierie sociale", "Manipulation psychologique poussant une victime à divulguer un secret.", "Sensibilisation et vérification d'identité."]
          ]}
        ],
        exercise: {
          question: "Un attaquant sature le serveur de JOSTECH par millions de fausses requêtes (attaque DDoS), rendant le site inaccessible. Quel pilier de la triade CIA est touché ?",
          solution: "C'est la Disponibilité (Availability) qui est compromise, car les données ne sont ni volées ni modifiées, mais le service devient inutilisable."
        },
        summary: "Toute politique de cybersécurité équilibre Confidentialité, Intégrité et Disponibilité, renforcées par l'authentification multifacteur (MFA) et les sauvegardes.",
        references: ["ANSSI — Guide d'hygiène informatique.", "NIST Cybersecurity Framework."]
      }]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Cryptographie symétrique, asymétrique et fonctions de hachage.",
    chapters: [{
      id: "sec-2-1", title: "Chapitre 2 : Cryptographie Appliquée",
      lessons: [{
        id: "sec-2-1-1", title: "Leçon 1 : Chiffrement (AES, RSA) et Hachage (SHA-256)", duration: "30 min",
        objectives: ["Distinguer chiffrement réversible et hachage irréversible.", "Comprendre l'échange hybride HTTPS."],
        prerequisites: ["Niveau 1 — Cybersécurité et binaire."],
        sections: [
          { type: "theory", title: "Chiffrement vs Hachage", text: "Le chiffrement (AES, RSA) est réversible avec la bonne clé : il sert à protéger des messages en transit ou stockés. Le hachage (SHA-256, bcrypt) est à sens unique : impossible de retrouver le texte d'origine depuis son empreinte, ce qui le rend idéal pour vérifier l'intégrité d'un fichier et stocker les mots de passe." },
          { type: "table", title: "Comparatif cryptographique", headers: ["Famille", "Clés", "Exemples & Usage"], rows: [
            ["Symétrique", "1 seule clé secrète partagée", "AES-256 : très rapide pour chiffrer de gros volumes."],
            ["Asymétrique", "Clé publique + clé privée", "RSA, ECDSA : échange de clés et signatures numériques."],
            ["Hachage", "Aucune clé (irréversible)", "SHA-256 (intégrité), Argon2/bcrypt (mots de passe)."]
          ]}
        ],
        exercise: {
          question: "Pourquoi ne doit-on JAMAIS stocker les mots de passe en clair ou simplement chiffrés en AES, mais toujours hachés avec un sel (Salt) ?",
          solution: "Avec un hachage lent salé (Argon2/bcrypt), même si la base de données est volée, l'attaquant ne peut ni déchiffrer les mots de passe, ni utiliser de tables précalculées (Rainbow Tables)."
        },
        summary: "HTTPS combine la sécurité de l'asymétrique (pour échanger une clé de session) avec la rapidité du symétrique (AES) pour tout le trafic.",
        references: ["Schneier, B. — Applied Cryptography."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Sécurité applicative OWASP, tests autorisés et investigation numérique.",
    chapters: [{
      id: "sec-3-1", title: "Chapitre 3 : Audit Applicatif & Éthique",
      lessons: [{
        id: "sec-3-1-1", title: "Leçon 1 : Injections SQL, OWASP et Cadre Légal", duration: "30 min",
        objectives: ["Corriger une faille d'injection SQL via requêtes préparées.", "Respecter le cadre légal des tests d'intrusion."],
        prerequisites: ["Bases SQL, Web et Niveau 2."],
        sections: [
          { type: "code", lang: "SQL — Faille Injection vs Requête Préparée", code: "// VULNÉRABLE (concaténation directe) :\n\"SELECT * FROM users WHERE email = '\" + input + \"'\"\n// Si input = \"' OR '1'='1\", l'attaquant contourne l'accès !\n\n// SÉCURISÉ (Requête paramétrée) :\n\"SELECT * FROM users WHERE email = ?\" // Paramètre lié séparément" },
          { type: "warning", title: "Éthique et Réglementation", text: "Tout test de vulnérabilité (Pentest) sans autorisation écrite explicite du propriétaire du système est un délit pénal grave. La cybersécurité universitaire se pratique exclusivement en laboratoire isolé ou sous contrat légal défini." }
        ],
        exercise: {
          question: "Comment les requêtes préparées (Prepared Statements) empêchent-elles définitivement les injections SQL ?",
          solution: "Le SGBD compile d'abord la structure SQL, puis traite l'entrée utilisateur strictement comme une donnée littérale, jamais comme une commande SQL exécutable."
        },
        summary: "Neutraliser les entrées (requêtes préparées, textContent) et respecter le cadre légal et la chaîne de preuves sont les bases de l'ingénieur cybersécurité.",
        references: ["OWASP Top 10 Web Application Security Risks."]
      }]
    }]
  }
});