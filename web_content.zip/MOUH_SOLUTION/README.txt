MOUH SOLUTION — Online-ready prototype

1) Extract the ZIP.
2) Open index.html in Chrome. For best camera support on Android, host the files
   on HTTPS or run through localhost; browsers may block camera access from file://.
3) Use "Open camera" or "Choose from gallery". Image preview is local and functional.
4) For real AI image analysis, deploy a secure backend endpoint and paste its HTTPS URL
   into the app's server URL field. The endpoint contract:
   - POST multipart/form-data
   - fields: image (file), prompt (text)
   - response JSON: {"answer":"..."}
   Keep AI provider API keys on the backend, never in HTML/JavaScript.

This ZIP does not include an AI backend or API key, so real image interpretation is
not active until a backend is connected. Camera access normally requires HTTPS or localhost.
