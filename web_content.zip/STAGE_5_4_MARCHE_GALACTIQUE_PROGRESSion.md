# CGD — SOCLE 5.4 : marché galactique, progression et gestion des galaxies

## Base préservée
- Extension de l'archive SOCLE 5.3 / V117 sans remplacement des moteurs de compétition.
- Conservation des 24 galaxies, des 24 légendaires, des effectifs et de la règle de deux damistes permanents par club.
- Les contrats individuels et leurs clauses restent gérés par les modules existants ; les contrats actifs suivent les joueurs lors des échanges finalisés.

## Progression des damistes
- Séances d'entraînement avec cinq axes : stratégie, attaque, défense, anticipation et condition physique.
- Expérience, talents, nombre de séances, niveau plafonné à 99 et baisse de forme après l'effort.
- Repos de 1 à 30 jours : récupération de forme et décrément des blessures.
- Blessures explicites avec type, durée, saison de début et historique.
- Les actions sont sauvegardées dans le journal de carrière.

## Gestion galactique
- Tableau classé des 24 galaxies.
- Indicateur de puissance fondé sur les niveaux des représentants et des damistes des clubs explicitement rattachés à la galaxie.
- Affichage des effectifs, représentants, puissance et points de compétition lorsqu'ils sont renseignés.
- Validation stricte du nombre de galaxies et de l'unicité des identifiants.

## Marché et contrats
- Les offres d'échange joueur contre joueur, indemnités, clauses et finalisation restent assurées par `transfers.js`.
- Les contrats individuels 1 à 5 saisons, salaires, primes, clause libératoire, fidélité, apparitions et non-transfert restent assurés par `player-contracts.js`.
- Les 24 légendaires restent recrutables depuis le marché existant, avec remplacement d'un joueur pour conserver deux places.
- Les achats/ventes autonomes et prêts avec retour automatique, ainsi que les contrats individuels négociables avant recrutement des légendaires, restent des extensions à réaliser : ils ne sont pas déclarés comme opérationnels dans cette version.

## Vérifications
- Tests de progression, repos, blessures et classement galactique ajoutés.
- Les moteurs de compétition, calendriers et règles de dames ne sont pas modifiés par cette tranche.
