# Application Android Officielle - aeroNET BF

## Contenu du projet
- `app/src/main/assets/index.html` : Interface complète de l'application aeroNET BF (Forfaits, Mobile Money, Speedtest, Éligibilité, Support WhatsApp).
- `app/src/main/java/bf/aeronet/app/MainActivity.kt` : Activité Android native WebView plein écran avec gestion du bouton Retour et redirection WhatsApp/Appels.
- `app/src/main/AndroidManifest.xml` : Configuration Android (`bf.aeronet.app`, permissions Internet).

## Comment générer le fichier APK (.apk)
1. Ouvrez **Android Studio** sur votre ordinateur (Dell Latitude).
2. Cliquez sur **File > Open** et sélectionnez le dossier extrait `aeroNET_BF_Android`.
3. Laissez Gradle synchroniser les dépendances (connexion Internet requise la première fois).
4. Dans le menu du haut, cliquez sur **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Récupérez votre fichier prêt à installer dans : `app/build/outputs/apk/debug/app-debug.apk`.
