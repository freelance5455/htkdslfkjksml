from playwright.sync_api import sync_playwright, TimeoutError as PwTimeout
from pathlib import Path
from PIL import Image,ImageDraw
from collections import Counter

root=Path(__file__).resolve().parents[1];out=root/'tests/screenshots';out.mkdir(parents=True,exist_ok=True)
html=(root/'standalone.html').read_text()
main_screens=['dashboard','agenda','clients','campaigns','settings','salon','salonEdit','services','serviceEditor','loyalty','invite','whatsapp','reviews','suggestions','schedule','pricing','clientHome','clientSalon','clientBookings','clientSchedule','clientBook','clientFav','clientProfile','clientLoyalty','clientReview','clientSuggestion','inviteJoin']
all_screens=['login','signup','onboarding','dashboard','agenda','appointment','newAppointment','services','serviceEditor','schedule','salon','salonEdit','salonPreview','clients','clientDetail','clientEditor','loyalty','invite','whatsapp','campaigns','campaignEditor','campaignDetail','reviews','suggestions','tags','settings','pricing','notifications','reports','branding','audit','clientHome','clientSchedule','clientBook','clientConfirm','clientFav','clientProfile','clientNotifications','clientLoyalty','clientReview','clientSuggestion','inviteJoin','clientBookings','clientSalon','clientHelp']
log=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None,args=['--no-sandbox'])
 for w,h,label in [(360,780,'android_360'),(393,852,'android_393'),(412,915,'android_412'),(768,1024,'tablet_768'),(1440,1000,'desktop_1440')]:
  page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
  page.set_content(html,wait_until='load')
  page.wait_for_timeout(150)
  assert page.locator('h1').count()>0, 'No first screen'
  page.screenshot(path=str(out/f'{label}_painel.png'),full_page=True)
  for scr in main_screens:
   page.evaluate('(s)=>{go(s)}',scr)
   page.wait_for_timeout(20)
   if page.locator('h1').count()==0:raise AssertionError(f'No heading: {scr}')
   if label=='android_393':
    if scr in ['dashboard','agenda','clients','campaigns','settings','salon','services','whatsapp','reviews','clientHome','clientSalon','clientSchedule','clientBook','clientFav']:
     page.screenshot(path=str(out/f'mobile_{scr}.png'),full_page=True)
  bad=page.locator('img').evaluate_all('(all)=>all.filter(x=>x.complete && !x.naturalWidth).map(x=>x.getAttribute("src")?.slice(0,80))')
  if bad: log.append((label,'broken images',bad[:3]))
  if errors:log.append((label,'page errors',errors))
  print(label,'screens',len(main_screens),'OK','errors',len(errors))
  page.close()
 # all screens single-phone sweep
 page=browser.new_page(viewport={'width':393,'height':852});errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
 page.set_content(html,wait_until='load')
 for scr in all_screens:
  page.evaluate('(s)=>{go(s)}',scr)
  if page.locator('main').count()==0:raise AssertionError('missing main for '+scr)
 assert not errors,errors
 print('All routes:',len(all_screens),'screen render calls, 0 JS exceptions')
 # simulate clicks + creation
 page.evaluate("go('newAppointment')")
 page.locator('input[name="time"]').fill('17:00')
 page.locator('form[data-form="appointment"] button[type="submit"]').click()
 assert page.evaluate('ui.screen')=='appointment'
 print('Create appointment: PASS')
 page.evaluate("ui.editMode=true;go('serviceEditor')")
 page.locator('input[name="name"]').fill('Penteado para Eventos')
 page.locator('textarea[name="desc"]').fill('Penteado social com preparação personalizada.')
 page.locator('form[data-form="service"] button[type="submit"]').click()
 assert page.evaluate('store.services.length')==5
 print('Create service: PASS')
 page.evaluate("go('campaignEditor')")
 page.locator('input[name="name"]').fill('Teste automatizado')
 page.locator('textarea[name="message"]').fill('Horários especiais disponíveis nesta semana.')
 page.locator('select[name="frequency"]').select_option('weekly')
 page.locator('form[data-form="campaign"] button[type="submit"]').click()
 assert page.evaluate('store.campaigns.length')==4
 print('Create campaign: PASS')
 page.evaluate("switchRole('client')")
 page.locator('button[data-action="go:clientSchedule"]').first.click()
 page.locator('button[data-action="go:clientBook"]').first.click()
 page.locator('button[data-action="slot:15:00"]').click()
 page.locator('button[data-action="openBookingConfirm"]').click()
 assert page.evaluate('ui.screen')=='clientConfirm'
 print('Client booking: PASS')
 page.evaluate("go('inviteJoin')")
 page.locator('form[data-form="joinInvite"] button[type="submit"]').click()
 assert page.locator('[role="dialog"]').count()==1
 page.locator('button[data-action="acceptFavorite"]').click()
 assert page.evaluate('store.favorite')==True
 print('Opt-in favorite: PASS')
 page.evaluate("go('clientReview')")
 before=page.evaluate('store.services.map(x=>x.rating)')
 page.locator('form[data-form="review"] button[type="submit"]').click()
 after=page.evaluate('store.services.map(x=>x.rating)')
 assert before==after
 print('Private review no immediate public score change: PASS')
 page.evaluate("go('clientSuggestion')")
 page.locator('textarea[name="text"]').fill('Gostaria de horários estendidos na sexta-feira.')
 page.locator('form[data-form="suggestion"] button[type="submit"]').click()
 assert page.evaluate('store.suggestions.length')==3
 print('Anonymous suggestion: PASS')
 assert not errors,errors
 page.close();browser.close()
 print('Issues:',log)
 # 3 x 5 collage for review
 files=[out/f'mobile_{s}.png' for s in ['dashboard','agenda','clients','campaigns','settings','salon','services','whatsapp','reviews','clientHome','clientSalon','clientSchedule','clientBook','clientFav']]
 thumbs=[]
 for f in files:
  im=Image.open(f).convert('RGB')
  im.thumbnail((260,580))
  cell=Image.new('RGB',(300,625),'#f4e8ec')
  cell.paste(im,((300-im.width)//2,12))
  ImageDraw.Draw(cell).text((15,595),f.stem.replace('mobile_',''),fill='#56283f')
  thumbs.append(cell)
 columns=5;rows=(len(thumbs)+columns-1)//columns
 sheet=Image.new('RGB',(columns*300,rows*625),'#f4e8ec')
 for idx,im in enumerate(thumbs):sheet.paste(im,((idx%columns)*300,(idx//columns)*625))
 sheet.save(root/'tests/v3_contact_sheet.jpg',quality=86)
