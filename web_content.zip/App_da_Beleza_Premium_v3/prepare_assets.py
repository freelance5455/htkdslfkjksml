from PIL import Image,ImageEnhance,ImageFilter,ImageDraw,ImageOps
from pathlib import Path
p=Path('/mnt/data/app_da_beleza_premium_v3/assets')
p.mkdir(exist_ok=True)
root=Path('/mnt/data')
refs={
 'salon':(root/'a_polished_high_end_beauty_salon_app_ui_mockup_in.png',(280,160,760,405)),
 'hair':(root/'a_polished_high_end_beauty_salon_app_ui_mockup_in.png',(60,948,282,1078)),
 'nails':(root/'a_polished_high_end_beauty_salon_app_ui_mockup_in.png',(297,948,505,1078)),
 'brows':(root/'a_polished_high_end_beauty_salon_app_ui_mockup_in.png',(530,948,744,1078)),
 'spa':(root/'a_polished_high_end_beauty_salon_app_ui_mockup_in.png',(766,948,969,1078)),
 'portrait1':(root/'a_highly_polished_smartphone_ui_mockup_in_portrait.png',(115,278,247,399)),
 'portrait2':(root/'a_highly_polished_smartphone_ui_mockup_in_portrait.png',(142,629,234,715)),
 'portrait3':(root/'a_highly_polished_smartphone_ui_mockup_in_portrait.png',(142,735,233,819)),
 'portrait4':(root/'a_highly_detailed_realistic_ui_mobile_app_screens.png',(275,619,365,713)),
 'portrait5':(root/'a_highly_detailed_realistic_ui_mobile_app_screens.png',(276,740,365,832)),
 'portrait6':(root/'a_highly_detailed_realistic_ui_mobile_app_screens.png',(275,853,365,946)),
}
for name,(path,box) in refs.items():
 im=Image.open(path).convert('RGB').crop(box)
 im=ImageOps.fit(im,(1200,660) if name=='salon' else (750,540) if name in ('hair','nails','brows','spa') else (256,256),method=Image.Resampling.LANCZOS)
 im=ImageEnhance.Contrast(im).enhance(1.06)
 im=ImageEnhance.Color(im).enhance(0.97)
 im.save(p/(name+'.webp'),format='WEBP',quality=88,method=6)
 # produce jpg fallback? not needed
# logo svg: vector, no font assets
logo='''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs><linearGradient id="g" x1="0" x2="1" y1="0" y2="1"><stop stop-color="#f5d89e"/><stop offset="1" stop-color="#b88a4f"/></linearGradient></defs><circle cx="100" cy="100" r="97" fill="#662c41"/><circle cx="100" cy="100" r="91" fill="none" stroke="url(#g)" stroke-width="2"/><g fill="none" stroke="url(#g)" stroke-linecap="round" stroke-linejoin="round" stroke-width="3.5"><path d="M100 107C75 86 79 61 100 36c21 25 25 50 0 71Z"/><path d="M99 113C66 110 48 87 54 59c32 8 46 27 45 54Z"/><path d="M101 113c33-3 51-26 45-54-32 8-46 27-45 54Z"/><path d="M101 117c-27 13-53 5-67-19 29-13 49-10 67 19Z"/><path d="M99 117c27 13 53 5 67-19-29-13-49-10-67 19Z"/><path d="M55 134c26 12 64 12 90 0"/></g><text x="100" y="159" text-anchor="middle" font-size="15" fill="#f1d6a6" font-family="Georgia, serif" letter-spacing="3">MAISON</text><text x="100" y="177" text-anchor="middle" font-size="22" fill="#fff4e5" font-family="Georgia, serif">BELLA</text></svg>'''
(p/'maison-bella-logo.svg').write_text(logo)
# contact sheet
thumbs=[]
for name in refs:
 im=Image.open(p/(name+'.webp')).convert('RGB')
 im.thumbnail((215,135))
 cell=Image.new('RGB',(240,170),'white'); cell.paste(im,((240-im.width)//2,5))
 ImageDraw.Draw(cell).text((10,143),name,fill='#281625')
 thumbs.append(cell)
sheet=Image.new('RGB',(240*4,170*3),'#eee')
for i,im in enumerate(thumbs): sheet.paste(im,((i%4)*240,(i//4)*170))
sheet.save(root/'app_beleza_v3_assets_contact.png')
print('assets generated',len(list(p.iterdir())))
