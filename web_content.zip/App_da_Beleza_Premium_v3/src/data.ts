const PAD=(n:number)=>String(n).padStart(2,'0');
function localIso(d:Date):string{return `${d.getFullYear()}-${PAD(d.getMonth()+1)}-${PAD(d.getDate())}`;}
function offsetDate(n=0):string{const d=new Date();d.setDate(d.getDate()+n);return localIso(d);}
const formatDate=(iso:string, opts:Intl.DateTimeFormatOptions={day:'2-digit',month:'long',year:'numeric'}):string=>{
 const d=new Date(`${iso}T12:00:00`);return d.toLocaleDateString('pt-BR',opts);
};
const money=(n:number)=>n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const escapeHtml=(s:string):string=>s.replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]||x));
const safeText=(x:unknown)=>escapeHtml(String(x??''));
const asset=(name:string):string=>`assets/${name}`;
const dateShort=(iso:string)=>formatDate(iso,{weekday:'short',day:'2-digit',month:'short'}).replace('.','');
const salonSeed:SalonInfo={name:'Maison Bella Studio',subtitle:'Beleza • Cuidado • Bem-estar',description:'Beleza com delicadeza, cuidado e atenção a cada detalhe. Um espaço acolhedor para seu momento especial.',address:'Campo Grande · Rio de Janeiro',phone:'(21) 99999-0000',instagram:'@maisonbellastudio',logo:asset('maison-bella-logo.svg'),cover:asset('salon.webp'),showPrices:false,suggestionsEnabled:true,marketingEnabled:true,businessHours:'Seg–Sáb · 08h às 19h',loyaltyEvery:5,loyaltyGift:'Uma hidratação capilar especial'};
const servicesSeed:BeautyService[]=[
{id:'hair',name:'Corte & Finalização',category:'Cabelos',desc:'Corte personalizado e finalização delicada para valorizar sua beleza natural.',duration:60,price:120,showPrice:false,image:asset('hair.webp'),active:true,rating:4.8,reviewCount:84},
{id:'nails',name:'Manicure Premium',category:'Unhas',desc:'Esmaltação e cuidado das unhas com acabamento impecável.',duration:45,price:55,showPrice:false,image:asset('nails.webp'),active:true,rating:4.9,reviewCount:63},
{id:'brows',name:'Design de Sobrancelhas',category:'Sobrancelhas',desc:'Design personalizado com atenção ao formato e expressão do rosto.',duration:40,price:65,showPrice:false,image:asset('brows.webp'),active:true,rating:4.7,reviewCount:42},
{id:'spa',name:'Hidratação & Ritual Facial',category:'Estética',desc:'Ritual de cuidado e hidratação para uma pausa relaxante.',duration:75,price:165,showPrice:false,image:asset('spa.webp'),active:true,rating:4.9,reviewCount:51}
];
const clientsSeed:SalonClient[]=[
{id:'ana',name:'Ana Paula Ferreira',phone:'(21) 99999-1111',email:'ana@example.test',tags:['VIP','Frequente'],avatar:asset('portrait2.webp'),visits:14,loyalty:4,marketing:true,notes:'Prefere agendamentos no período da manhã.'},
{id:'larissa',name:'Larissa Souza',phone:'(21) 99999-2222',email:'larissa@example.test',tags:['Frequente'],avatar:asset('portrait3.webp'),visits:8,loyalty:3,marketing:true,notes:'Prefere horários à tarde.'},
{id:'beatriz',name:'Beatriz Lima',phone:'(21) 99999-3333',email:'beatriz@example.test',tags:['Nova'],avatar:asset('portrait5.webp'),visits:1,loyalty:1,marketing:true,notes:''},
{id:'camila',name:'Camila Mendes',phone:'(21) 99999-4444',email:'camila@example.test',tags:['VIP','Frequente'],avatar:asset('portrait4.webp'),visits:12,loyalty:2,marketing:true,notes:''},
{id:'mariana',name:'Mariana Costa',phone:'(21) 99999-5555',email:'mariana@example.test',tags:['Aniversariante'],avatar:asset('portrait6.webp'),visits:4,loyalty:4,marketing:false,notes:'Não deseja receber promoções.'},
{id:'renata',name:'Renata Almeida',phone:'(21) 99999-6666',email:'renata@example.test',tags:['Nova'],avatar:asset('portrait1.webp'),visits:2,loyalty:2,marketing:true,notes:''}
];
const apptSeed:Appointment[]=[
{id:'apt-1',clientId:'ana',serviceId:'hair',date:offsetDate(0),time:'09:00',status:'Concluído',professional:'Juliana Costa',note:''},
{id:'apt-2',clientId:'larissa',serviceId:'nails',date:offsetDate(0),time:'10:30',status:'Confirmado',professional:'Juliana Costa',note:''},
{id:'apt-3',clientId:'beatriz',serviceId:'brows',date:offsetDate(0),time:'13:00',status:'Confirmado',professional:'Juliana Costa',note:''},
{id:'apt-4',clientId:'camila',serviceId:'spa',date:offsetDate(0),time:'15:00',status:'Confirmado',professional:'Juliana Costa',note:'Prefere atendimento com pouca luz.'},
{id:'apt-5',clientId:'renata',serviceId:'hair',date:offsetDate(1),time:'09:30',status:'Confirmado',professional:'Juliana Costa',note:''},
{id:'apt-6',clientId:'ana',serviceId:'nails',date:offsetDate(2),time:'11:00',status:'Confirmado',professional:'Juliana Costa',note:''},
{id:'apt-7',clientId:'mariana',serviceId:'brows',date:offsetDate(-2),time:'14:00',status:'Concluído',professional:'Juliana Costa',note:''},
];
const campaignSeed:Campaign[]=[
{id:'camp1',name:'Novidade da semana',message:'Um momento só seu faz toda a diferença. Consulte os horários disponíveis para esta semana! ✨',audience:'VIP + Frequente',schedule:'Segundas, às 10h',status:'Agendada',created:offsetDate(-1),tags:['VIP','Frequente']},
{id:'camp2',name:'Cuidados de primavera',message:'Já conhece nosso ritual facial? Preparamos horários especiais para você.',audience:'Clientes elegíveis',schedule:'Enviada ontem',status:'Enviada',created:offsetDate(-1),tags:[]},
{id:'camp3',name:'Campanha em revisão',message:'Novidades do salão',audience:'Clientes elegíveis',schedule:'Envio pausado',status:'Suspensa',created:offsetDate(-3),tags:[]}
];
const suggestionsSeed:Suggestion[]=[
{id:'sg1',text:'Seria ótimo abrir alguns horários mais cedo nas sextas-feiras. Obrigada pelo carinho!',date:offsetDate(-4),status:'Nova'},
{id:'sg2',text:'Gostaria de ter mais opções de cores de esmalte nas próximas semanas.',date:offsetDate(-9),status:'Nova'}
];
function createStore():DemoStore{
 return {salon:{...salonSeed},clients:clientsSeed.map(c=>({...c,tags:[...c.tags]})),services:servicesSeed.map(s=>({...s})),appointments:apptSeed.map(a=>({...a})),campaigns:campaignSeed.map(c=>({...c,tags:[...c.tags]})),suggestions:suggestionsSeed.map(s=>({...s})),favorite:true,selectedDate:offsetDate(0),clientMarketing:true,clientConnected:true,readNotifications:false,tags:['VIP','Frequente','Nova','Aniversariante','Sem atendimento há 30 dias'],notifications:['Seu atendimento de amanhã está confirmado.','Uma nova cliente aceitou seu convite.','Você tem uma sugestão de melhoria.'],releaseVersion:3};
}
