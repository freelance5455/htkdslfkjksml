const STORAGE_KEY='beauty-premium-v3-demo-v1';
let store:DemoStore = createStore();
try { const old=localStorage.getItem(STORAGE_KEY);if(old){const data=JSON.parse(old) as DemoStore;if(data.releaseVersion===3)store=data;} } catch (_err) { /* privacy mode */ }
let ui:UiState={role:'professional',screen:'dashboard',history:[],selectedServiceId:'hair',selectedClientId:'ana',selectedApptId:'apt-1',selectedCampaignId:'camp1',selectedTags:[],selectedSlots:'10:30',selectedBookingService:'hair',toast:'',editMode:false,filter:'',showMenu:false,modal:'',pendingInvite:false};
function persist(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(store));}catch(_err){/* storage unavailable */}}
function toast(message:string){ui.toast=message;render();window.setTimeout(()=>{if(ui.toast===message){ui.toast='';document.querySelector('.toast')?.remove();}},3300)}
function go(screen:AppScreen, replace=false){
 if(!replace&&ui.screen!==screen)ui.history.push(ui.screen);
 ui.screen=screen;ui.modal='';ui.filter='';ui.showMenu=false; window.scrollTo({top:0,behavior:'instant'});render();
}
function back(){const prev=ui.history.pop();if(prev){ui.screen=prev;ui.modal='';render();}else go(ui.role==='professional'?'dashboard':'clientHome',true)}
function switchRole(role:Role){ui.role=role;ui.history=[];go(role==='professional'?'dashboard':'clientHome',true)}
function serviceById(id:string){return store.services.find(s=>s.id===id)||store.services[0]}
function clientById(id:string){return store.clients.find(c=>c.id===id)||store.clients[0]}
function appointmentById(id:string){return store.appointments.find(a=>a.id===id)||store.appointments[0]}
function campaignById(id:string){return store.campaigns.find(c=>c.id===id)||store.campaigns[0]}
function visibleAppts(date:string){return store.appointments.filter(a=>a.date===date&&a.status!=='Cancelado').sort((a,b)=>a.time.localeCompare(b.time))}
function getAttendedCount(){return store.appointments.filter(a=>a.status==='Concluído').length}
function newId(prefix:string){return `${prefix}-${Date.now()}-${Math.round(Math.random()*1000)}`}
function safeTel(phone:string){return phone.replace(/\D/g,'')}
function fakeQR(){const cells=[];for(let y=0;y<17;y++)for(let x=0;x<17;x++){let on=false;const seed=((x*31+y*53+x*y*7)%13)<6;const finder=(xx:number,yy:number)=>{const a=x-xx,b=y-yy;if(a<0||b<0||a>6||b>6)return false;return a===0||a===6||b===0||b===6||(a>=2&&a<=4&&b>=2&&b<=4)};on=seed||finder(0,0)||finder(10,0)||finder(0,10);if(on)cells.push(`<i style="grid-column:${x+1};grid-row:${y+1}"></i>`)}return `<div class="fake-qr" aria-label="QR Code ilustrativo, não funcional">${cells.join('')}</div>`}
function percentDone(){const d=store.appointments.filter(a=>a.date===store.selectedDate);return Math.round(100*d.filter(a=>a.status==='Concluído').length/Math.max(1,d.length))}
