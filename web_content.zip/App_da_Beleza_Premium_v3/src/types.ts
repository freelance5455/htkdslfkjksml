type Role = 'professional' | 'client';
type ApptStatus = 'Confirmado' | 'Concluído' | 'Cancelado' | 'Em andamento';
type CampaignStatus = 'Agendada' | 'Enviada' | 'Suspensa' | 'Rascunho';
type AppScreen =
  | 'login' | 'signup' | 'onboarding'
  | 'dashboard' | 'agenda' | 'appointment' | 'newAppointment' | 'services' | 'serviceEditor'
  | 'schedule' | 'salon' | 'salonEdit' | 'salonPreview' | 'clients' | 'clientDetail'
  | 'clientEditor' | 'loyalty' | 'invite' | 'whatsapp' | 'campaigns' | 'campaignEditor'
  | 'campaignDetail' | 'reviews' | 'suggestions' | 'tags' | 'settings' | 'pricing'
  | 'notifications' | 'reports' | 'branding' | 'audit'
  | 'clientHome' | 'clientSchedule' | 'clientBook' | 'clientConfirm' | 'clientFav'
  | 'clientProfile' | 'clientNotifications' | 'clientLoyalty' | 'clientReview'
  | 'clientSuggestion' | 'inviteJoin' | 'serviceDetail' | 'clientBookings' | 'clientSalon'
  | 'clientHelp';
interface BeautyService { id:string; name:string; category:string; desc:string; duration:number; price:number; showPrice:boolean; image:string; active:boolean; rating:number; reviewCount:number }
interface SalonClient { id:string; name:string; phone:string; email:string; tags:string[]; avatar:string; visits:number; loyalty:number; marketing:boolean; notes:string }
interface Appointment { id:string; clientId:string; serviceId:string; date:string; time:string; status:ApptStatus; professional:string; note:string }
interface Campaign { id:string; name:string; message:string; audience:string; schedule:string; status:CampaignStatus; created:string; tags:string[] }
interface Suggestion {id:string; text:string; date:string; status:'Nova'|'Arquivada'|'Denunciada'}
interface SalonInfo { name:string; subtitle:string; description:string; address:string; phone:string; instagram:string; logo:string; cover:string; showPrices:boolean; suggestionsEnabled:boolean; marketingEnabled:boolean; businessHours:string; loyaltyEvery:number; loyaltyGift:string }
interface DemoStore { salon:SalonInfo; clients:SalonClient[]; services:BeautyService[]; appointments:Appointment[]; campaigns:Campaign[]; suggestions:Suggestion[]; favorite:boolean; selectedDate:string; clientMarketing:boolean; clientConnected:boolean; readNotifications:boolean; tags:string[]; notifications:string[]; releaseVersion:number }
interface UiState {role:Role; screen:AppScreen; history:AppScreen[]; selectedServiceId:string; selectedClientId:string; selectedApptId:string; selectedCampaignId:string; selectedTags:string[]; selectedSlots:string; selectedBookingService:string; toast:string; editMode:boolean; filter:string; showMenu:boolean; modal:string; pendingInvite:boolean}
