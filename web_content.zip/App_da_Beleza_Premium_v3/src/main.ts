let uploadTarget='';
function numberField(v:FormDataEntryValue|null, fallback=0){const n=Number(v||fallback);return Number.isFinite(n)?n:fallback}
function getValue(fd:FormData,key:string):string{return String(fd.get(key)||'').trim()}
function formSubmit(form:HTMLFormElement):void{
 const fd=new FormData(form),type=form.dataset.form;
 switch(type){
 case 'service':{
  const model:BeautyService=ui.editMode?{id:newId('svc'),name:'',category:'Outros',desc:'',duration:60,price:0,showPrice:false,image:asset('hair.webp'),active:true,rating:0,reviewCount:0}:{...serviceById(ui.selectedServiceId)};
  model.name=getValue(fd,'name');model.desc=getValue(fd,'desc');model.duration=Math.max(15,numberField(fd.get('duration'),60));model.price=Math.max(0,numberField(fd.get('price'),0));model.category=getValue(fd,'category');model.showPrice=fd.has('showPrice');
  if(!model.name||!model.desc){toast('Preencha nome e descrição.');return}
  const idx=store.services.findIndex(s=>s.id===model.id);if(idx>=0)store.services[idx]=model;else store.services.push(model);
  ui.selectedServiceId=model.id;ui.editMode=false;persist();go('services');toast('Serviço salvo na demonstração.');break;
 }
 case 'salon':{
  for(const k of ['name','subtitle','description','address','phone','instagram'] as const){store.salon[k]=getValue(fd,k)}
  persist();go('salon');toast('Informações do salão atualizadas.');break;
 }
 case 'client':{
  const name=getValue(fd,'name'),phone=getValue(fd,'phone');if(!name||!phone){toast('Informe nome e telefone.');return}
  const client:SalonClient={id:newId('cl'),name,phone,email:getValue(fd,'email'),tags:[getValue(fd,'tag')||'Nova'],avatar:asset('portrait6.webp'),visits:0,loyalty:0,marketing:false,notes:''};
  store.clients.unshift(client);ui.selectedClientId=client.id;persist();go('clientDetail');toast('Cliente fictícia adicionada.');break;
 }
 case 'appointment':{
  const date=getValue(fd,'date'),time=getValue(fd,'time'),serviceId=getValue(fd,'serviceId'),clientId=getValue(fd,'clientId');
  if(!date||!time){toast('Informe data e horário.');return}
  const conflict=store.appointments.some(a=>a.date===date&&a.time===time&&a.status!=='Cancelado');
  if(conflict){toast('Já existe um atendimento nesse horário. Escolha outro.');return}
  const ap:Appointment={id:newId('appt'),date,time,clientId,serviceId,status:'Confirmado',professional:'Juliana Costa',note:getValue(fd,'note')};
  store.appointments.push(ap);ui.selectedApptId=ap.id;store.selectedDate=date;persist();go('appointment');toast('Agendamento de teste registrado.');break;
 }
 case 'campaign':{
  const name=getValue(fd,'name'),message=getValue(fd,'message'),fr=getValue(fd,'frequency'),date=getValue(fd,'date'),time=getValue(fd,'time');
  if(!name||!message){toast('Escreva o título e a mensagem.');return}
  const labels:Record<string,string>={now:'Envio imediato (simulado)',date:`${date} às ${time}`,daily:`Diariamente às ${time}`,weekdays:`Dias selecionados às ${time}`,weekly:`Semanalmente às ${time}`,fortnight:`A cada 15 dias às ${time}`,firstN:`Primeiros ${Math.max(1,numberField(fd.get('days'),5))} dias`};
  const audience=getValue(fd,'audience')==='tags'?`Tags: ${ui.selectedTags.join(', ')||'não selecionadas'}`:getValue(fd,'audience')==='selected'?'Clientes selecionadas (demonstração)':'Clientes elegíveis';
  const camp:Campaign={id:newId('camp'),name,message,audience,schedule:labels[fr]||fr,status:fr==='now'?'Enviada':'Agendada',created:offsetDate(),tags:[...ui.selectedTags]};
  store.campaigns.unshift(camp);ui.selectedCampaignId=camp.id;ui.selectedTags=[];persist();go('campaignDetail');toast('Campanha salva. Nenhum push real foi enviado.');break;
 }
 case 'loyalty':{
  store.salon.loyaltyEvery=Math.min(30,Math.max(2,numberField(fd.get('every'),5)));store.salon.loyaltyGift=getValue(fd,'gift');persist();toast('Regra de fidelidade atualizada.');break;
 }
 case 'tag':{
  const t=getValue(fd,'tag');if(t&&!store.tags.includes(t)){store.tags.push(t);persist();toast('Tag adicionada.')}else toast('Essa tag já existe ou está vazia.');break;
 }
 case 'joinInvite':{const code=getValue(fd,'code').toUpperCase();if(code==='MAISON-BELLA'){ui.modal='favorite';render()}else toast('Código de demonstração não encontrado. Use MAISON-BELLA.');break;}
 case 'suggestion':{
  const msg=getValue(fd,'text');if(!msg){toast('Escreva sua sugestão.');return}
  store.suggestions.unshift({id:newId('sg'),text:msg,date:offsetDate(),status:'Nova'});persist();go('clientProfile');toast('Sugestão enviada na demonstração, sem identificação ao salão.');break;
 }
 case 'review':{
  const keys=['technical','kindness','timing','hygiene'];const values=keys.map(k=>numberField(fd.get(k),5));
  if(values.some(v=>v<1||v>5)){toast('Avalie os quatro critérios.');return}
  const score=values.reduce((s,v)=>s+v,0)/values.length;
  // Deliberately do not change public scores immediately: 7-day delay and 10-person batch gate.
  store.notifications.unshift(`Avaliação de ${score.toFixed(1).replace('.',',')} estrelas recebida em fila protegida (demonstração).`);
  persist();go('clientBookings');toast('Avaliação recebida. Ela não altera notas públicas imediatamente.');break;
 }
 case 'whatsapp':{
  const c=clientById(ui.selectedClientId),intro=`${store.salon.name}\n\nOlá, ${c.name}!\n`,msg=intro+getValue(fd,'body');
  // Never open wa.me with fictional customer numbers in demo; no real messages or network calls.
  clipboardText(msg).then(ok=>toast(ok?'Mensagem copiada. No app real, abre o WhatsApp com rascunho.':'Prévia pronta. Nenhuma mensagem foi enviada.'));
  break;
 }
 case 'signup':{switchRole(getValue(fd,'role')==='client'?'client':'professional');toast('Bem-vinda à demonstração!');break;}
 }
}
async function clipboardText(txt:string):Promise<boolean>{
 try{if(navigator.clipboard){await navigator.clipboard.writeText(txt);return true}}catch(_e){}
 try{const t=document.createElement('textarea');t.value=txt;t.style.position='fixed';t.style.left='-999px';document.body.appendChild(t);t.select();const ok=document.execCommand('copy');t.remove();return ok}catch(_e){return false}
}
function act(action:string):void{
 const [cmd,...rest]=action.split(':'),value=rest.join(':');
 if(cmd==='go'){if(value==='clientSchedule'&&ui.role==='client')store.selectedDate=offsetDate(1);go(value as AppScreen);return}
 if(cmd==='switch'){switchRole(value as Role);return}
 if(cmd==='date'||cmd==='bookingDate'){store.selectedDate=value;persist();render();return}
 if(cmd==='back'){back();return}
 if(cmd==='openClient'){ui.selectedClientId=value;go('clientDetail');return}
 if(cmd==='selectService'){ui.selectedServiceId=value;ui.editMode=false;go('serviceEditor');return}
 if(cmd==='newService'){ui.editMode=true;go('serviceEditor');return}
 if(cmd==='bookService'){ui.selectedBookingService=value;if(ui.role==='client')store.selectedDate=offsetDate(1);go(ui.role==='client'?'clientSchedule':'serviceEditor');return}
 if(cmd==='bookServiceSelect'){ui.selectedBookingService=value;render();return}
 if(cmd==='openAppt'){ui.selectedApptId=value;go('appointment');return}
 if(cmd==='openClientBooking'){ui.selectedApptId=value;go('clientBookings');toast('Selecione um agendamento para visualizar.');return}
 if(cmd==='openCampaign'){ui.selectedCampaignId=value;go('campaignDetail');return}
 if(cmd==='slot'){ui.selectedSlots=value;render();return}
 if(cmd==='filter'){ui.filter=value;render();return}
 if(cmd==='toggleTag'){ui.selectedTags=ui.selectedTags.includes(value)?ui.selectedTags.filter(t=>t!==value):[...ui.selectedTags,value];render();return}
 if(cmd==='togglePrices'){store.salon.showPrices=!store.salon.showPrices;persist();toast(store.salon.showPrices?'Preços do catálogo visíveis.':'Preços do catálogo ocultos.');return}
 if(cmd==='servicePrice'){const s=serviceById(value);s.showPrice=!s.showPrice;persist();toast(`Preço de ${s.name}: ${s.showPrice?'visível':'oculto'}`);return}
 if(cmd==='toggleSuggestions'){store.salon.suggestionsEnabled=!store.salon.suggestionsEnabled;persist();toast(`Sugestões ${store.salon.suggestionsEnabled?'habilitadas':'desabilitadas'}.`);return}
 if(cmd==='toggleMarketing'){store.clientMarketing=!store.clientMarketing;persist();toast(`Promoções ${store.clientMarketing?'permitidas':'desativadas'}.`);return}
 if(cmd==='clientTag') {const c=clientById(ui.selectedClientId);c.tags=c.tags.includes(value)?c.tags.filter(t=>t!==value):[...c.tags,value];persist();render();return}
 if(cmd==='removeTag'){store.tags=store.tags.filter(t=>t!==value);store.clients.forEach(c=>c.tags=c.tags.filter(t=>t!==value));persist();toast('Tag removida da demonstração.');return}
 if(cmd==='deleteService'){ui.modal='deleteService';render();return}
 if(cmd==='confirmDeleteService'){if(store.services.length<=1){ui.modal='';toast('Mantenha pelo menos um serviço.');return}store.services=store.services.filter(s=>s.id!==ui.selectedServiceId);ui.modal='';persist();go('services');toast('Serviço removido.');return}
 if(cmd==='openBookingConfirm'){
  if(!ui.selectedSlots||!ui.selectedBookingService){toast('Escolha serviço e horário.');return}
  // Simulation only: explicit non-binding booking (no payment, no price agreement).
  const ap:Appointment={id:newId('book'),clientId:'ana',serviceId:ui.selectedBookingService,date:store.selectedDate===offsetDate(0)?offsetDate(1):store.selectedDate,time:ui.selectedSlots,status:'Confirmado',professional:'Juliana Costa',note:'Solicitação de demonstração — sem contratação vinculante.'};
  const existing=store.appointments.some(a=>a.date===ap.date&&a.time===ap.time&&a.status!=='Cancelado');
  if(existing){toast('Horário indisponível na demonstração. Escolha outro.');return}
  store.appointments.push(ap);persist();go('clientConfirm');return;
 }
 if(cmd==='completeAppt'){appointmentById(ui.selectedApptId).status='Concluído';persist();toast('Atendimento concluído na demonstração.');return}
 if(cmd==='cancelAppt'){appointmentById(ui.selectedApptId).status='Cancelado';persist();toast('Atendimento cancelado na demonstração.');return}
 if(cmd==='copyInvite'||cmd==='inviteProfessional'||cmd==='shareSalon'){
  const url=cmd==='inviteProfessional'?'https://exemplo.invalid/convite-profissional':`https://exemplo.invalid/salao/maison-bella`;
  clipboardText(url).then(ok=>toast(ok?'Link ilustrativo copiado.':'Link fictício de demonstração.'));return;
 }
 if(cmd==='simulateInvite'){ui.modal='favorite';render();return}
 if(cmd==='acceptFavorite'){store.favorite=true;store.clientConnected=true;ui.modal='';persist();go('clientFav');toast('Salão adicionado voluntariamente aos favoritos.');return}
 if(cmd==='removeFavorite'){store.favorite=false;persist();toast('Salão removido dos seus favoritos.');return}
 if(cmd==='closeModal'){ui.modal='';render();return}
 if(cmd==='selectImage'){uploadTarget=value;ui.modal='image';render();return}
 if(cmd==='readNotices'){store.readNotifications=true;persist();toast('Notificações marcadas como lidas.');return}
 if(cmd==='reportSuggestion'){const s=store.suggestions.find(x=>x.id===value);if(s){s.status='Denunciada';persist();toast('Denúncia registrada para análise administrativa (simulação).');}return}
 if(cmd==='appealCampaign'){toast('Pedido de revisão protocolado na demonstração.');return}
 if(cmd==='pauseCampaign'){campaignById(ui.selectedCampaignId).status='Rascunho';persist();toast('Campanha pausada.');return}
 if(cmd==='duplicateCampaign'){const x=campaignById(ui.selectedCampaignId);store.campaigns.unshift({...x,id:newId('copy'),name:x.name+' — cópia',status:'Rascunho'});persist();go('campaigns');toast('Campanha duplicada.');return}
 if(cmd==='individualLoyalty'){toast('Regra individual: selecione uma cliente na lista para personalizar.');go('clients');return}
 if(cmd==='scheduleToggle'){toast('Disponibilidade alterada visualmente. Salve para confirmar na versão real.');return}
 if(cmd==='saveSchedule'){toast('Horários demonstrativos revisados.');return}
 if(cmd==='fakeSetting'){toast('Configuração ilustrativa. Regras finais seguem o documento v0.15.');return}
 if(cmd==='resetDemo'){store=createStore();persist();switchRole('professional');toast('Demonstração restaurada com dados fictícios.');return}
 if(cmd==='showAbout'){ui.modal='about';render();return}
}
// All behavior is delegated to stable root, so rerendering never duplicates listeners.
root.addEventListener('click',(e:MouseEvent)=>{
 const t=e.target as HTMLElement;
 const submit=t.closest<HTMLButtonElement>('button[type="submit"]');
 if(submit){
   const f=submit.closest<HTMLFormElement>('form');
   if(f){ e.preventDefault(); if(f.checkValidity())formSubmit(f); else f.reportValidity(); return; }
 }
 const el=t.closest<HTMLElement>('[data-action]');
 if(!el)return;
 if(el instanceof HTMLInputElement&&['checkbox','radio'].includes(el.type))return; // change below handles form toggles
 e.preventDefault();act(el.dataset.action||'');
});
root.addEventListener('change',(e:Event)=>{
 const t=e.target as HTMLInputElement;
 if(t.id==='upload-image'&&t.files?.[0]){
  const f=t.files[0];if(!['image/jpeg','image/png','image/webp'].includes(f.type)){toast('Selecione JPG, PNG ou WebP.');return}
  if(f.size>3*1024*1024){toast('Use uma imagem de até 3 MB nesta demonstração.');return}
  // Browser-only centered crop and compression for demonstration; no upload to any server.
  const reader=new FileReader();reader.onload=()=>{
   const raw=String(reader.result||'');
   const photo=new Image();photo.onload=()=>{
     const [w,h]=uploadTarget==='logo'?[480,480]:uploadTarget==='cover'?[1200,660]:[750,540];
     const c=document.createElement('canvas');c.width=w;c.height=h;
     const ctx=c.getContext('2d');if(!ctx){toast('Não foi possível processar essa imagem.');return}
     const scale=Math.max(w/photo.naturalWidth,h/photo.naturalHeight);
     const dw=photo.naturalWidth*scale,dh=photo.naturalHeight*scale;
     ctx.drawImage(photo,(w-dw)/2,(h-dh)/2,dw,dh);
     const data=c.toDataURL('image/webp',.86);
     if(uploadTarget==='logo')store.salon.logo=data;
     else if(uploadTarget==='cover')store.salon.cover=data;
     else serviceById(ui.selectedServiceId).image=data;
     persist();ui.modal='';render();toast('Imagem recortada e otimizada nesta demonstração.');
   };
   photo.onerror=()=>toast('Não foi possível abrir essa imagem.');
   photo.src=raw;
  };reader.readAsDataURL(f);return;
 }
 if(t.dataset.action){act(t.dataset.action);return}
 if(t.id==='wa-template'){
  const bodies:Record<string,string>={custom:'',confirm:'Seu atendimento está confirmado. Estamos felizes em receber você!',change:'Precisamos combinar uma alteração de horário. Podemos conversar?',thanks:'Obrigada pela visita! Foi um prazer cuidar de você.'};
  const textarea=document.getElementById('wa-body') as HTMLTextAreaElement|null;
  if(textarea){textarea.value=bodies[t.value]||'';textarea.dispatchEvent(new Event('input',{bubbles:true}))}
 }
});
root.addEventListener('input',(e:Event)=>{
 const t=e.target as HTMLInputElement|HTMLTextAreaElement;
 if(t.id==='client-search'){
  const selStart=t.selectionStart,selEnd=t.selectionEnd;
  ui.filter=t.value;render();const newInput=document.getElementById('client-search') as HTMLInputElement|null;
  if(newInput){newInput.focus();try{newInput.setSelectionRange(selStart,selEnd)}catch(_e){}}return;
 }
 if(t.id==='wa-body'){
  const el=document.getElementById('wa-preview-text');if(el)el.textContent=`Olá, ${clientById(ui.selectedClientId).name}!\n${t.value}`;
 }
 if(t.id==='campaign-message'){
  const el=document.getElementById('campaign-preview-message');if(el)el.textContent=t.value||'Sua mensagem aparecerá aqui.';
 }
});
root.addEventListener('submit',(e:SubmitEvent)=>{e.preventDefault();const f=e.target as HTMLFormElement;formSubmit(f)});
window.addEventListener('keydown',(e:KeyboardEvent)=>{if(e.key==='Escape'&&ui.modal){ui.modal='';render()}else if(e.key==='Backspace'&&e.target===document.body&&!ui.modal)back()});
window.addEventListener('popstate',()=>back());
render();
