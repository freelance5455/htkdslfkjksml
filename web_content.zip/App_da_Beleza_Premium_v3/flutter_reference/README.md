# Flutter/Dart — referência técnica, não compilada

Este diretório contém **fonte experimental Flutter** das principais telas e padrões visuais do App da Beleza Premium v3. **Não é um APK**, não está conectado a backend e **não foi compilado/testado no Android** porque o ambiente atual não possui Flutter SDK e Android SDK nem acesso para instalá-los.

## Objetivo
Validar a direção de arte e a capacidade de transposição para Flutter. O protótipo executável e testado no navegador está em `../standalone.html`; não tratar os dois códigos como equivalentes ou sincronizados automaticamente.

## Depois de instalar Flutter e Android SDK

```sh
flutter create . --platforms=android,web
flutter pub get
flutter analyze
flutter test
flutter run -d chrome
flutter run -d <dispositivo-android>
```

O comando `flutter create` deverá ser executado em uma cópia do projeto; revise os arquivos gerados antes de sobrescrever configurações. Incluímos apenas um `pubspec.yaml`, `lib/main.dart` e assets de referência; faltam wrappers de plataforma, lockfile, teste nativo, FCM e AdMob de teste.

## Gate obrigatório
Não escolher Flutter definitivamente nem anunciar o app como Android validado até comparar a prova nativa contra a alternativa React/Capacitor em aparelho: splash, toque, teclado, back, câmera/galeria, FCM, AdMob de teste, performance e acessibilidade.
