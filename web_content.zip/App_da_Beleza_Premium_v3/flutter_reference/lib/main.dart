// Referência Flutter/Dart de UI — NÃO compilada neste ambiente.
// Importante: app nativo definitivo só após Gate 0 (Flutter SDK, Android SDK,
// FCM e AdMob de TESTE validados num Android físico/emulador).
import 'package:flutter/material.dart';

void main() => runApp(const BeautyApp());

class Palette {
  static const rose900 = Color(0xFF692C43);
  static const rose800 = Color(0xFF842B50);
  static const rose700 = Color(0xFFA12E60);
  static const rose600 = Color(0xFFBC4276);
  static const rose100 = Color(0xFFF7E5EC);
  static const cream = Color(0xFFFBF7F5);
  static const ink = Color(0xFF30222B);
  static const muted = Color(0xFF8C7B83);
  static const champagne = Color(0xFFD2B185);
}

ThemeData premiumTheme() => ThemeData(
  useMaterial3: true,
  scaffoldBackgroundColor: Palette.cream,
  colorScheme: ColorScheme.fromSeed(
    seedColor: Palette.rose700,
    brightness: Brightness.light,
    primary: Palette.rose700,
    surface: Colors.white,
    onSurface: Palette.ink,
  ),
  textTheme: const TextTheme(
    headlineLarge: TextStyle(fontFamily: 'Georgia',fontSize:30,fontWeight:FontWeight.w500,color:Palette.ink),
    headlineMedium: TextStyle(fontFamily:'Georgia',fontSize:25,fontWeight:FontWeight.w500,color:Palette.ink),
    titleLarge: TextStyle(fontSize:19,fontWeight:FontWeight.w700,color:Palette.ink),
    titleMedium: TextStyle(fontSize:15,fontWeight:FontWeight.w700,color:Palette.ink),
    bodyMedium: TextStyle(fontSize:13,color:Palette.ink,height:1.55),
    bodySmall: TextStyle(fontSize:11,color:Palette.muted,height:1.5),
  ),
  cardTheme: CardThemeData(
    color:Colors.white,
    surfaceTintColor:Colors.transparent,
    elevation:0,
    shape:RoundedRectangleBorder(
      borderRadius:BorderRadius.circular(19),
      side:const BorderSide(color:Color(0xFFEFE3E6)),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled:true,
    fillColor:Colors.white,
    contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:15),
    border:OutlineInputBorder(borderRadius:BorderRadius.circular(13)),
    enabledBorder:OutlineInputBorder(
      borderRadius:BorderRadius.circular(13),
      borderSide:const BorderSide(color:Color(0xFFEAD9E0)),
    ),
  ),
  filledButtonTheme: FilledButtonThemeData(
    style:FilledButton.styleFrom(
      backgroundColor:Palette.rose700,
      foregroundColor:Colors.white,
      minimumSize:const Size(0,48),
      shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14)),
    ),
  ),
  navigationBarTheme: NavigationBarThemeData(
    elevation:0,
    backgroundColor:Colors.white,
    indicatorColor:Palette.rose100,
    height:74,
    labelTextStyle:WidgetStateProperty.all(
      const TextStyle(fontSize:10,fontWeight:FontWeight.w700),
    ),
  ),
);

class BeautyApp extends StatelessWidget {
  const BeautyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title:'App da Beleza Premium v3 — referência',
    debugShowCheckedModeBanner:false,
    theme:premiumTheme(),
    home:const RoleShell(),
  );
}

class DemoService {
  final String id,name,description,asset;
  final int minutes;
  const DemoService(this.id,this.name,this.minutes,this.asset,this.description);
}

const demoServices = <DemoService>[
  DemoService('hair','Corte & Finalização',60,'assets/hair.webp','Corte e finalização personalizados.'),
  DemoService('nails','Manicure Premium',45,'assets/nails.webp','Esmaltação e cuidado delicado das unhas.'),
  DemoService('brows','Design de Sobrancelhas',40,'assets/brows.webp','Design e cuidado personalizado.'),
  DemoService('spa','Ritual Facial',75,'assets/spa.webp','Pausa de autocuidado e hidratação.'),
];

class DemoClient {
  final String name,avatar,tag;
  const DemoClient(this.name,this.avatar,this.tag);
}
const demoClients = <DemoClient>[
  DemoClient('Ana Paula Ferreira','assets/portrait2.webp','VIP'),
  DemoClient('Larissa Souza','assets/portrait3.webp','Frequente'),
  DemoClient('Beatriz Lima','assets/portrait5.webp','Nova'),
  DemoClient('Camila Mendes','assets/portrait4.webp','Frequente'),
  DemoClient('Mariana Costa','assets/portrait6.webp','Aniversariante'),
];

class RoleShell extends StatefulWidget {
  const RoleShell({super.key});
  @override
  State<RoleShell> createState() => _RoleShellState();
}

class _RoleShellState extends State<RoleShell> {
  bool professional=true;
  int index=0;
  void changeRole(){setState((){professional=!professional;index=0;});}
  void openPage(String title,Widget page){
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder:(_) => Scaffold(
        appBar: AppBar(title:Text(title),backgroundColor:Colors.white),
        body:SafeArea(child:page),
      ),
    ));
  }

  @override
  Widget build(BuildContext context){
    final items=professional
      ? const [(Icons.home_outlined,'Painel'),(Icons.calendar_month_outlined,'Agenda'),(Icons.people_outline,'Clientes'),(Icons.campaign_outlined,'Campanhas'),(Icons.settings_outlined,'Gestão')]
      : const [(Icons.home_outlined,'Início'),(Icons.calendar_today_outlined,'Agenda'),(Icons.favorite_outline,'Favoritos'),(Icons.person_outline,'Perfil')];
    final pages=professional
      ? <Widget>[
          ProDashboard(onOpen:openPage),
          const ProAgenda(),
          const ProClients(),
          const ProCampaigns(),
          ProSettings(onOpen:openPage,onSwitch:changeRole),
        ]
      : <Widget>[
          ClientHome(onOpen:openPage),
          const ClientBookings(),
          ClientFavorites(onOpen:openPage),
          ClientProfile(onSwitch:changeRole),
        ];
    return Scaffold(
      appBar:AppBar(
        toolbarHeight:70,
        backgroundColor:Colors.white,
        title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(items[index].$2,style:Theme.of(context).textTheme.titleLarge),
          const SizedBox(height:3),
          Text(professional?'Maison Bella Studio · Profissional':'Seu espaço de beleza',style:Theme.of(context).textTheme.bodySmall),
        ]),
        leading:const Padding(padding:EdgeInsets.all(12),child:Icon(Icons.spa_outlined,color:Palette.rose700)),
        actions:[
          IconButton(onPressed:(){openPage('Notificações',const NotificationsPage());},icon:const Icon(Icons.notifications_none,color:Palette.rose800),tooltip:'Notificações'),
          const Padding(padding:EdgeInsets.only(right:12),child:CircleAvatar(radius:15,backgroundImage:AssetImage('assets/portrait1.webp'))),
        ],
      ),
      body:SafeArea(child:IndexedStack(index:index,children:pages)),
      bottomNavigationBar:NavigationBar(
        selectedIndex:index,
        onDestinationSelected:(n)=>setState(()=>index=n),
        destinations:items.map((x)=>NavigationDestination(icon:Icon(x.$1),label:x.$2)).toList(),
      ),
    );
  }
}

class ProDashboard extends StatelessWidget {
  final void Function(String,Widget) onOpen;
  const ProDashboard({super.key,required this.onOpen});
  @override
  Widget build(BuildContext context){
    final theme=Theme.of(context);
    return ListView(children:[
      Stack(children:[
        SizedBox(height:228,width:double.infinity,child:Image.asset('assets/salon.webp',fit:BoxFit.cover)),
        Container(height:228,decoration:BoxDecoration(gradient:LinearGradient(colors:[Palette.rose900.withValues(alpha:.95),Palette.rose900.withValues(alpha:.13)]))),
        Positioned(left:24,top:33,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('BOM DIA, JULIANA',style:TextStyle(letterSpacing:1.6,color:Colors.white70,fontWeight:FontWeight.w700,fontSize:10)),
          const SizedBox(height:12),
          const Text('Seu salão em\nharmonia.',style:TextStyle(fontFamily:'Georgia',fontSize:35,height:1.1,color:Colors.white)),
          const SizedBox(height:10),
          Text('Uma bela experiência começa\ncom organização.',style:theme.textTheme.bodySmall?.copyWith(color:Colors.white)),
        ])),
      ]),
      const SectionHeading('Visão do dia'),
      Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:GridView.count(
        crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
        childAspectRatio:1.52,mainAxisSpacing:10,crossAxisSpacing:10,
        children:const [MetricCard(Icons.calendar_month_outlined,'Atendimentos','4'),MetricCard(Icons.check_circle_outline,'Concluídos','1'),MetricCard(Icons.people_outline,'Suas clientes','6'),MetricCard(Icons.star_outline,'Nota geral','4,8')],
      )),
      const SectionHeading('Próximos atendimentos'),
      const AppointmentTile(name:'Ana Paula Ferreira',service:'Corte & Finalização',time:'09:00',avatar:'assets/portrait2.webp',done:true),
      const AppointmentTile(name:'Larissa Souza',service:'Manicure Premium',time:'10:30',avatar:'assets/portrait3.webp'),
      const AppointmentTile(name:'Beatriz Lima',service:'Design de Sobrancelhas',time:'13:00',avatar:'assets/portrait5.webp'),
      const SectionHeading('Ações rápidas'),
      Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Wrap(spacing:8,runSpacing:8,children:[
        QuickAction(Icons.add_circle_outline,'Agendar',()=>onOpen('Novo agendamento',const QuickFormPage(title:'Novo agendamento'))),
        QuickAction(Icons.content_cut,'Serviços',()=>onOpen('Serviços',const ProServices())),
        QuickAction(Icons.share_outlined,'Convites',()=>onOpen('Convites',const InvitesPage())),
        QuickAction(Icons.loyalty_outlined,'Fidelidade',()=>onOpen('Cartão fidelidade',const LoyaltyPage())),
      ])),
      const SizedBox(height:30),
    ]);
  }
}

class SectionHeading extends StatelessWidget {
  final String title;
  const SectionHeading(this.title,{super.key});
  @override
  Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(19,23,19,12),child:Text(title,style:Theme.of(context).textTheme.titleLarge));
}

class MetricCard extends StatelessWidget {
  final IconData icon;final String name,value;
  const MetricCard(this.icon,this.name,this.value,{super.key});
  @override
  Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(name,style:Theme.of(context).textTheme.bodySmall),Icon(icon,size:19,color:Palette.rose700)]),
    const Spacer(),Text(value,style:const TextStyle(fontFamily:'Georgia',fontSize:26,color:Palette.rose900)),
  ])));
}

class AppointmentTile extends StatelessWidget {
  final String name,service,time,avatar;final bool done;
  const AppointmentTile({super.key,required this.name,required this.service,required this.time,required this.avatar,this.done=false});
  @override
  Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.symmetric(horizontal:15,vertical:3),child:Card(child:ListTile(
    contentPadding:const EdgeInsets.symmetric(horizontal:10,vertical:6),
    leading:CircleAvatar(backgroundImage:AssetImage(avatar),radius:21),
    title:Text(name,style:const TextStyle(fontSize:13,fontWeight:FontWeight.bold)),
    subtitle:Text('$time · $service',style:Theme.of(context).textTheme.bodySmall),
    trailing:Text(done?'Concluído':'Confirmado',style:TextStyle(fontSize:10,fontWeight:FontWeight.bold,color:done?Colors.green:Palette.rose700)),
  )));
}

class QuickAction extends StatelessWidget {
  final IconData icon;final String text;final VoidCallback onTap;
  const QuickAction(this.icon,this.text,this.onTap,{super.key});
  @override
  Widget build(BuildContext context)=>SizedBox(width:158,height:88,child:Card(child:InkWell(
    borderRadius:BorderRadius.circular(17),onTap:onTap,
    child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,color:Palette.rose700),const SizedBox(height:7),Text(text,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w700))]),
  )));
}

class ProAgenda extends StatefulWidget {
  const ProAgenda({super.key});
  @override
  State<ProAgenda> createState()=>_ProAgendaState();
}
class _ProAgendaState extends State<ProAgenda>{
  int dayOffset=0;
  @override Widget build(BuildContext context){
    final selected=DateTime.now().add(Duration(days:dayOffset));
    return ListView(padding:const EdgeInsets.all(18),children:[
      Text('Agenda inteligente',style:Theme.of(context).textTheme.headlineLarge),
      const SizedBox(height:8),Text('Seus atendimentos sempre organizados.',style:Theme.of(context).textTheme.bodySmall),
      const SizedBox(height:22),
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        Text('${selected.day}/${selected.month}/${selected.year}',style:Theme.of(context).textTheme.titleMedium),
        IconButton(onPressed:()=>setState(()=>dayOffset=0),icon:const Icon(Icons.today_outlined)),
      ]),
      SizedBox(height:83,child:ListView.separated(scrollDirection:Axis.horizontal,itemCount:7,separatorBuilder:(_,__)=>const SizedBox(width:7),itemBuilder:(_,i){
        final date=DateTime.now().add(Duration(days:i));
        return ChoiceChip(label:Column(mainAxisSize:MainAxisSize.min,children:[Text(['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][date.weekday%7],style:const TextStyle(fontSize:10)),Text('${date.day}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))]),selected:dayOffset==i,onSelected:(_)=>setState(()=>dayOffset=i));
      })),
      const SectionHeading('Atendimentos do dia'),
      const AppointmentTile(name:'Ana Paula Ferreira',service:'Corte & Finalização',time:'09:00',avatar:'assets/portrait2.webp',done:true),
      const AppointmentTile(name:'Larissa Souza',service:'Manicure Premium',time:'10:30',avatar:'assets/portrait3.webp'),
      const AppointmentTile(name:'Beatriz Lima',service:'Sobrancelhas',time:'13:00',avatar:'assets/portrait5.webp'),
      const SizedBox(height:18),FilledButton.icon(onPressed:()=>showDialog<void>(context:context,builder:(_)=>const AlertDialog(title:Text('Demonstração'),content:Text('Agendamento real dependerá do backend e das regras de agenda.'))),icon:const Icon(Icons.add),label:const Text('Novo agendamento')),
    ]);
  }
}

class ProClients extends StatelessWidget{
  const ProClients({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    Text('Suas clientes',style:Theme.of(context).textTheme.headlineLarge),
    const SizedBox(height:7),Text('${demoClients.length} clientes fictícias do salão',style:Theme.of(context).textTheme.bodySmall),
    const SizedBox(height:18),const TextField(decoration:InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Buscar na sua lista')),
    const SizedBox(height:16),...demoClients.map((c)=>Card(child:ListTile(leading:CircleAvatar(backgroundImage:AssetImage(c.avatar)),title:Text(c.name),subtitle:Text(c.tag),trailing:const Icon(Icons.chevron_right)))),
  ]);
}

class ProCampaigns extends StatelessWidget{
  const ProCampaigns({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    Text('Suas campanhas',style:Theme.of(context).textTheme.headlineLarge),
    const SizedBox(height:8),Text('Comunique novidades às clientes autorizadas.',style:Theme.of(context).textTheme.bodySmall),
    const SizedBox(height:20),Card(child:ListTile(leading:const Icon(Icons.campaign_outlined,color:Palette.rose700),title:const Text('Novidade da semana'),subtitle:const Text('VIP + Frequente · Semanal'),trailing:const Text('Agendada',style:TextStyle(color:Palette.rose700)))),
    Card(child:ListTile(leading:const Icon(Icons.notifications_paused_outlined,color:Palette.rose700),title:const Text('Campanha em revisão'),subtitle:const Text('Suspensão temporária demonstrativa'),trailing:const Icon(Icons.shield_outlined))),
    const SizedBox(height:16),FilledButton.icon(onPressed:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>Scaffold(appBar:AppBar(title:const Text('Nova campanha')),body:const QuickFormPage(title:'Nova campanha',campaign:true)))),icon:const Icon(Icons.add),label:const Text('Criar campanha')),
    const SizedBox(height:18),const InfoNote('Mais mensagens não significam mais agendamentos. O excesso pode gerar silenciamento, denúncias ou desinstalações.'),
  ]);
}

class ProSettings extends StatelessWidget{
  final void Function(String,Widget) onOpen;final VoidCallback onSwitch;
  const ProSettings({super.key,required this.onOpen,required this.onSwitch});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    Text('Gestão do salão',style:Theme.of(context).textTheme.headlineLarge),
    const SizedBox(height:18),Card(color:Palette.rose900,child:ListTile(leading:const CircleAvatar(backgroundImage:AssetImage('assets/portrait1.webp')),title:const Text('Maison Bella Studio',style:TextStyle(color:Colors.white)),subtitle:const Text('Perfil profissional',style:TextStyle(color:Colors.white70)),trailing:const Icon(Icons.check,color:Palette.champagne))),
    const SectionHeading('Seu negócio'),
    SettingItem('Meu Salão',Icons.store_outlined,()=>onOpen('Meu Salão',const SalonDetails())),
    SettingItem('Serviços e fotografias',Icons.content_cut,()=>onOpen('Serviços',const ProServices())),
    SettingItem('Horários e regras',Icons.calendar_month_outlined,()=>onOpen('Horários',const QuickFormPage(title:'Expediente e bloqueios'))),
    SettingItem('Preços opcionais',Icons.visibility_outlined,()=>onOpen('Preços',const PricingPage())),
    const SectionHeading('Relacionamento'),
    SettingItem('Cartão fidelidade',Icons.card_giftcard_outlined,()=>onOpen('Fidelidade',const LoyaltyPage())),
    SettingItem('Avaliações por serviço',Icons.star_outline,()=>onOpen('Avaliações',const ReviewsPage())),
    SettingItem('Sugestões anônimas',Icons.chat_bubble_outline,()=>onOpen('Sugestões',const SuggestionsPage())),
    SettingItem('Convites por código',Icons.share_outlined,()=>onOpen('Convites',const InvitesPage())),
    const SectionHeading('Demonstração'),
    SettingItem('Trocar para cliente',Icons.swap_horiz,onSwitch),
  ]);
}

class SettingItem extends StatelessWidget {
  final String label; final IconData icon;final VoidCallback onTap;
  const SettingItem(this.label,this.icon,this.onTap,{super.key});
  @override Widget build(BuildContext context)=>Card(child:ListTile(onTap:onTap,leading:Icon(icon,color:Palette.rose700),title:Text(label,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700)),trailing:const Icon(Icons.chevron_right,color:Palette.muted)));
}

class SalonDetails extends StatelessWidget{
 const SalonDetails({super.key});
 @override Widget build(BuildContext context)=>ListView(children:[
   Image.asset('assets/salon.webp',height:220,width:double.infinity,fit:BoxFit.cover),
   Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('Maison Bella Studio',style:Theme.of(context).textTheme.headlineMedium),
    const SizedBox(height:8),const Text('Beleza • Cuidado • Bem-estar'),
    const SizedBox(height:16),const Text('Campo Grande · Rio de Janeiro'),
    const SizedBox(height:8),const Text('Seg–Sáb · 08h às 19h'),
    const SizedBox(height:18),FilledButton.icon(onPressed:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>Scaffold(appBar:AppBar(title:const Text('Editar perfil')),body:const QuickFormPage(title:'Dados e identidade')))),icon:const Icon(Icons.edit_outlined),label:const Text('Editar perfil')),
   ])),
 ]);
}

class ProServices extends StatelessWidget{
 const ProServices({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
  Text('Serviços',style:Theme.of(context).textTheme.headlineLarge),
  const SizedBox(height:8),Text('Uma foto por serviço nesta primeira versão.',style:Theme.of(context).textTheme.bodySmall),
  const SizedBox(height:18),...demoServices.map((s)=>Card(child:ListTile(contentPadding:const EdgeInsets.all(8),leading:ClipRRect(borderRadius:BorderRadius.circular(10),child:Image.asset(s.asset,width:85,height:70,fit:BoxFit.cover)),title:Text(s.name,style:const TextStyle(fontSize:13,fontWeight:FontWeight.bold)),subtitle:Text('${s.minutes} minutos · Valor oculto no catálogo',style:const TextStyle(fontSize:11)),trailing:const Icon(Icons.chevron_right)))),
  const SizedBox(height:13),const InfoNote('Galeria de múltiplos trabalhos e edição avançada de fotos ficam para depois.'),
 ]);
}

class InfoNote extends StatelessWidget{
 final String text;const InfoNote(this.text,{super.key});
 @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Palette.rose100,borderRadius:BorderRadius.circular(15)),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.info_outline,size:20,color:Palette.rose700),const SizedBox(width:10),Expanded(child:Text(text,style:const TextStyle(fontSize:11,color:Palette.rose800,height:1.6)))]));
}

class LoyaltyPage extends StatelessWidget{
 const LoyaltyPage({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
   Container(padding:const EdgeInsets.all(23),decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[Palette.rose900,Palette.rose600])),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Icon(Icons.card_giftcard,color:Palette.champagne,size:35),const SizedBox(height:19),const Text('Cada visita merece um carinho.',style:TextStyle(fontFamily:'Georgia',fontSize:25,color:Colors.white)),
    const SizedBox(height:14),const Row(children:[Icon(Icons.check_circle,color:Palette.champagne),Icon(Icons.check_circle,color:Palette.champagne),Icon(Icons.check_circle,color:Palette.champagne),Icon(Icons.check_circle,color:Palette.champagne),Icon(Icons.circle_outlined,color:Palette.champagne)]),
    const SizedBox(height:14),const Text('5 atendimentos concluídos = 1 hidratação especial',style:TextStyle(color:Colors.white,fontSize:11))
   ])),
   const SizedBox(height:18),const InfoNote('Regras gerais e individuais serão integradas à base de atendimentos concluídos no backend real.'),
 ]);
}

class InvitesPage extends StatelessWidget{
 const InvitesPage({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
  Text('Seu convite',style:Theme.of(context).textTheme.headlineLarge),
  const SizedBox(height:12),const Text('Envie seu link às clientes. Não há busca pública nem indicação de concorrentes nesta primeira versão.'),
  const SizedBox(height:19),Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[const Icon(Icons.qr_code,size:120,color:Palette.rose900),const SizedBox(height:12),const Text('QR meramente ilustrativo',style:TextStyle(fontSize:10,color:Palette.muted)),const SizedBox(height:12),const SelectableText('https://exemplo.invalid/salao/maison-bella')]))),
  const SizedBox(height:18),const InfoNote('O salão só entra nos favoritos mediante escolha explícita da cliente.'),
 ]);
}

class ReviewsPage extends StatelessWidget{
 const ReviewsPage({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
  Text('Avaliações',style:Theme.of(context).textTheme.headlineLarge),
  const SizedBox(height:16),Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[const Icon(Icons.star,color:Palette.champagne,size:32),Text('4,8',style:Theme.of(context).textTheme.headlineLarge),const Text('Média geral de avaliações fictícias')]))),
  ...demoServices.map((s)=>Card(child:ListTile(leading:ClipRRect(borderRadius:BorderRadius.circular(10),child:Image.asset(s.asset,width:65,height:55,fit:BoxFit.cover)),title:Text(s.name),trailing:const Text('★ 4,8',style:TextStyle(color:Palette.rose700))))),
  const SizedBox(height:15),const InfoNote('Notas agregadas após pelo menos 7 dias e lotes de 10 avaliações válidas de clientes diferentes. Sem comentários nem nomes públicos.'),
 ]);
}

class SuggestionsPage extends StatefulWidget{
 const SuggestionsPage({super.key});
 @override State<SuggestionsPage> createState()=>_SuggestionsPageState();
}
class _SuggestionsPageState extends State<SuggestionsPage>{bool enabled=true;
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  Text('Sugestões',style:Theme.of(context).textTheme.headlineLarge),
  SwitchListTile(title:const Text('Permitir sugestões anônimas'),value:enabled,onChanged:(v)=>setState(()=>enabled=v),activeColor:Palette.rose700),
  if(enabled)const Card(child:ListTile(title:Text('Sugestão anônima'),subtitle:Text('Seria ótimo ter horários mais cedo às sextas-feiras.'),trailing:Icon(Icons.flag_outlined))),
  const InfoNote('Anonimato somente perante a profissional. Administração poderá investigar abusos com dados restritos conforme a lei.'),
 ]);
}

class PricingPage extends StatefulWidget{
 const PricingPage({super.key});
 @override State<PricingPage> createState()=>_PricingPageState();
}
class _PricingPageState extends State<PricingPage>{bool showPrices=false;
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  Text('Visibilidade dos preços',style:Theme.of(context).textTheme.headlineLarge),
  SwitchListTile(value:showPrices,onChanged:(v)=>setState(()=>showPrices=v),activeColor:Palette.rose700,title:const Text('Mostrar valores no catálogo'),subtitle:const Text('Desativado por padrão')),
  const SizedBox(height:18),const InfoNote('Mesmo oculto na vitrine, preço ou orçamento precisa ser informado antes de uma contratação vinculante.'),
 ]);
}

class QuickFormPage extends StatelessWidget {
 final String title;final bool campaign;
 const QuickFormPage({super.key,required this.title,this.campaign=false});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  Text(title,style:Theme.of(context).textTheme.headlineLarge),
  const SizedBox(height:15),TextFormField(decoration:InputDecoration(labelText:campaign?'Título da campanha':'Nome'),maxLength:80),
  const SizedBox(height:12),TextFormField(decoration:InputDecoration(labelText:campaign?'Mensagem':'Observações'),maxLines:4,maxLength:250),
  const SizedBox(height:14),FilledButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Somente demonstração: nada foi enviado.'))),child:const Text('Salvar simulação')),
 ]);
}

class NotificationsPage extends StatelessWidget {
 const NotificationsPage({super.key});
 @override Widget build(BuildContext context)=>ListView(children:const [
  ListTile(leading:Icon(Icons.calendar_today_outlined),title:Text('Seu atendimento de amanhã está confirmado.')),
  ListTile(leading:Icon(Icons.favorite_outline),title:Text('Uma nova cliente aceitou seu convite.')),
  ListTile(leading:Icon(Icons.mark_chat_unread_outlined),title:Text('Você tem uma sugestão de melhoria.')),
 ]);
}

class ClientHome extends StatelessWidget{
 final void Function(String,Widget) onOpen;
 const ClientHome({super.key,required this.onOpen});
 @override Widget build(BuildContext context)=>ListView(children:[
  Stack(children:[SizedBox(height:224,width:double.infinity,child:Image.asset('assets/salon.webp',fit:BoxFit.cover)),Container(height:224,decoration:BoxDecoration(gradient:LinearGradient(colors:[Palette.rose900.withValues(alpha:.93),Palette.rose900.withValues(alpha:.1)]))),const Positioned(left:24,top:37,child:Text('Seu momento\nde beleza.',style:TextStyle(fontFamily:'Georgia',color:Colors.white,fontSize:32)))]),
  Padding(padding:const EdgeInsets.all(17),child:Column(children:[
   Card(child:ListTile(leading:const CircleAvatar(backgroundColor:Palette.rose900,child:Icon(Icons.spa,color:Palette.champagne)),title:const Text('Maison Bella Studio'),subtitle:const Text('Seu salão escolhido · Campo Grande - RJ'),trailing:const Icon(Icons.chevron_right))),
   const SizedBox(height:10),FilledButton.icon(onPressed:()=>onOpen('Agendar',const ClientBookingFlow()),icon:const Icon(Icons.calendar_month),label:const Text('Agendar atendimento')),
   const SizedBox(height:18),const SectionHeading('Serviços para você'),
   ...demoServices.map((s)=>Card(child:ListTile(leading:ClipRRect(borderRadius:BorderRadius.circular(10),child:Image.asset(s.asset,width:80,height:58,fit:BoxFit.cover)),title:Text(s.name),subtitle:Text('${s.minutes} minutos · Valor sob consulta')))),
   const SizedBox(height:15),const InfoNote('Sem busca por salões concorrentes nesta primeira versão. Novos favoritos exigem aceite da cliente.'),
  ])),
 ]);
}

class ClientBookings extends StatelessWidget{
 const ClientBookings({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
   Text('Meus agendamentos',style:Theme.of(context).textTheme.headlineLarge),
   const SizedBox(height:16),const Card(child:ListTile(leading:Icon(Icons.calendar_today,color:Palette.rose700),title:Text('Manicure Premium'),subtitle:Text('Maison Bella Studio · 10:30'),trailing:Text('Confirmado',style:TextStyle(color:Palette.rose700,fontSize:11)))),
   const SizedBox(height:15),const InfoNote('Cancelamentos e remarcações ficam sujeitos às condições informadas na reserva real.'),
 ]);
}

class ClientFavorites extends StatelessWidget{
 final void Function(String,Widget) onOpen;
 const ClientFavorites({super.key,required this.onOpen});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  Text('Meus favoritos',style:Theme.of(context).textTheme.headlineLarge),
  const SizedBox(height:16),Card(child:ListTile(leading:ClipRRect(borderRadius:BorderRadius.circular(9),child:Image.asset('assets/salon.webp',width:80,height:55,fit:BoxFit.cover)),title:const Text('Maison Bella Studio'),subtitle:const Text('Incluído com sua autorização'),trailing:const Icon(Icons.favorite,color:Palette.rose700))),
  FilledButton.icon(onPressed:()=>onOpen('Adicionar salão',const InviteConsent()),icon:const Icon(Icons.add),label:const Text('Adicionar por convite')),
 ]);
}

class ClientProfile extends StatelessWidget{
 final VoidCallback onSwitch;
 const ClientProfile({super.key,required this.onSwitch});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  const Center(child:CircleAvatar(radius:43,backgroundImage:AssetImage('assets/portrait2.webp'))),
  const SizedBox(height:12),Center(child:Text('Ana Paula Ferreira',style:Theme.of(context).textTheme.headlineMedium)),
  const SizedBox(height:17),const Card(child:ListTile(leading:Icon(Icons.notifications_outlined),title:Text('Preferências de notificações'))),
  const Card(child:ListTile(leading:Icon(Icons.star_border),title:Text('Avaliações por serviço'))),
  const Card(child:ListTile(leading:Icon(Icons.card_giftcard_outlined),title:Text('Meu cartão fidelidade'))),
  const SizedBox(height:16),FilledButton.tonalIcon(onPressed:onSwitch,icon:const Icon(Icons.swap_horiz),label:const Text('Ver ambiente profissional')),
 ]);
}

class ClientBookingFlow extends StatefulWidget{
 const ClientBookingFlow({super.key});
 @override State<ClientBookingFlow> createState()=>_ClientBookingFlowState();
}
class _ClientBookingFlowState extends State<ClientBookingFlow>{String? service;String? time;
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
  Text('Escolha um serviço',style:Theme.of(context).textTheme.headlineLarge),
  const SizedBox(height:15),...demoServices.map((s)=>Card(child:RadioListTile<String>(value:s.id,groupValue:service,onChanged:(v)=>setState(()=>service=v),title:Text(s.name),subtitle:Text('${s.minutes} minutos · Valor sob consulta')))),
  const SectionHeading('Selecione um horário'),
  Wrap(spacing:8,children:['09:00','10:30','14:00','15:30'].map((h)=>ChoiceChip(label:Text(h),selected:time==h,onSelected:(_)=>setState(()=>time=h))).toList()),
  const SizedBox(height:21),FilledButton(onPressed:service!=null&&time!=null?()=>showDialog<void>(context:context,builder:(_)=>const AlertDialog(title:Text('Prévia de agendamento'),content:Text('Reserva simulada. No app real, o valor deve ser informado antes de uma contratação vinculante.'))):null,child:const Text('Revisar atendimento')),
 ]);
}

class InviteConsent extends StatelessWidget{
 const InviteConsent({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
  Text('Novo salão',style:Theme.of(context).textTheme.headlineLarge),
  const SizedBox(height:16),const TextField(decoration:InputDecoration(labelText:'Código de convite')),
  const SizedBox(height:19),FilledButton(onPressed:()=>showDialog<void>(context:context,builder:(_)=>AlertDialog(title:const Text('Adicionar aos favoritos?'),content:const Text('Mesmo após receber o convite, o salão só será adicionado se você aceitar.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Agora não')),TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Aceitar'))])),child:const Text('Ver convite')),
 ]);
}
