# Roadmap Premium v3 — situação de execução

**Data:** 08/11/2026 · **Objetivo:** protótipo profissional para aprovação visual e ensaio de jornadas, sem lançamento de aplicativo.

| Lote | Proposto | Estado | Evidência | Dependência restante |
|---|---|---|---|---|
| 1 | Arquitetura e prova técnica | **PARCIAL** | Fonte TypeScript strict, build offline, referência Flutter/Dart criada, ADR | Flutter SDK e Android SDK indisponíveis; não houve prova nativa, APK, AdMob/FCM |
| 2 | Design premium | **ENTREGUE — WEB** | Tokens CSS, ícones SVG, logo, assets WebP gerados a partir de composições de IA | Aprovação visual do usuário; equivalência Flutter ainda não verificada |
| 3 | Ambiente profissional | **ENTREGUE — DEMO WEB** | Painel, Agenda, Clientes, Campanhas, Gestão e telas auxiliares, formulários mock | Integrações reais, autorização e backend ficam fora deste protótipo |
| 4 | Ambiente cliente | **ENTREGUE — DEMO WEB** | Convites, favoritos opcionais, serviços, agendamento, cartão, avaliações, sugestões | Backend real e sincronização multiusuário pendentes |
| 5 | QA, acabamento e documentação | **PARCIAL** | 45 telas varridas, 5 tamanhos testados, fluxos mock aprovados, capturas e docs | Android físico, TalkBack, FCM, AdMob, testes de segurança e validação jurídica |

**Resultado:** referência de interface web testável sem dependências externas. **Não equivale** a concluir um aplicativo Android de produção.

## Continuação ao retornar

1. Revisão estética do usuário nas cinco abas profissionais e quatro da cliente; registrar mudanças visuais sem alterar o escopo funcional.
2. Em ambiente com Flutter/Android SDK, executar Gate 0 com APK de teste e verificar suporte a imagens, teclado, botão Voltar, FCM e AdMob TESTE.
3. Escolher a tecnologia final com evidências (Flutter ou React/Capacitor) e usar o Design System desta demo como baseline.
4. Integrar dados reais apenas após aprovação visual, contratos API, autenticação e política de privacidade.
