# Checklist técnico para integração — após aprovação visual

1. **Escolher a stack nativa pelo Gate 0** em Android real: Flutter/Dart versus TypeScript/Capacitor. O código atual em TypeScript é prévia de experiência, não aplicação nativa homologada.
2. **API e banco compartilhados**: definir contrato de autenticação/permissões cliente-profissional-admin, `salon_id` em todas entidades apropriadas, autorização server-side e testes de isolamento.
3. **Agenda transacional**: verificar disponibilidades e gravar reserva atomicamente; impedir duas clientes na mesma vaga; cancelamento/remarcação idempotentes.
4. **Upload**: formato, tamanho, corte, otimização, metadados, antivírus, conteúdo inadequado, armazenamento seguro e associação correta ao serviço.
5. **Push FCM**: templates operacionais versus campanhas comerciais, consentimento, opt-out, scheduler fuso horário, deduplicação, auditoria, suspensão automática e recurso.
6. **Reputação**: quatro critérios de 1 a 5 estrelas; gravação por serviço concluído; 7 dias antes de elegibilidade; lotes de 10 avaliações de clientes distintos, por serviço e para média geral, sem identificação individual.
7. **Sugestões**: anonimato relativo para profissional, identidade controlada no admin; denúncia, revisão, retenção e compartilhamento legal com autoridades quando cabível.
8. **Fidelidade**: créditos só após atendimento realmente concluído; regra geral/individual configurável e antifraude.
9. **WhatsApp**: formar `https://wa.me/<numero-E164>?text=<url-encoded>` com mensagem/cabeçalho, abrir aplicativo via deep link, envio manual; respeitar contatos autorizados.
10. **AdMob**: usar IDs de TESTE, política de anúncios, localização não intrusiva, métricas de sessão/retention com consentimento aplicável.
11. **Admin web**: monitorar salões, denúncias, campanhas e recursos; acessos auditados e ações reversíveis.
12. **Build**: lockfiles, CI, lint, testes, assinatura Android somente com chaves protegidas, revisão Play Store/privacidade antes de publicação.
