# Design System — App da Beleza Premium v3

## Direção

**Luxo discreto:** fundo marfim, rosa nobre, cartões brancos, champagne só como acento, fotografias cuidadas e tipografia editorial para frases de destaque. Evitar efeitos excessivos e telas visivelmente genéricas.

## Tokens principais

| Token | Valor | Uso |
|---|---|---|
| `--rose-900` | `#692C43` | Hero e marca |
| `--rose-800` | `#842B50` | Ações secundárias e estados |
| `--rose-700` | `#A12E60` | Ação principal |
| `--rose-600` | `#BC4276` | Destaques |
| `--rose-100` | `#F7E5EC` | Fundo suave |
| `--cream` | `#FBF7F5` | Tela |
| `--ink` | `#30222B` | Texto principal |
| `--muted` | `#8C7B83` | Texto secundário |
| `--champagne` | `#D2B185` | Acentos pontuais |
| `--surface` | `#FFFFFF` | Cartões e cabeçalhos |

Raio: 9/13/18/24/30 px. Sombras suaves; separação principalmente por espaço e borda. Texto UI com stack de fontes do sistema (não distribuímos arquivos de fontes); destaque editorial com Georgia/serif. Ícones: SVG vetorial de traço consistente (paths autorais compatíveis com convenção de ícones lineares).

## Componentes

`TopBar`, `BottomNav`, `MetricCard`, `AppointmentRow`, `ServiceCard`, `QuickCard`, `ClientRow`, `TagPill`, `CampaignCard`, `ModalSheet`, `PhotoEditor`, `LoyaltyCard`, `RatingCard`, `Toast`, `Error/EmptyState`, `TextField`, `Select`, `Switch`, `DateRail`, `TimeSlot`.

Estados demonstrados: foco, selecionado, disponível, desativado, vazio, sucesso, confirmação e aviso; animações discretas com respeito a `prefers-reduced-motion`.

## Navegação

Profissional: **Painel / Agenda / Clientes / Campanhas / Gestão**. Cliente: **Início / Agenda / Favoritos / Perfil**. Sem sidebar fixa no Android. Perfil e configurações não competem com a navegação principal.

## Fotografia e identidade

Uma foto ilustrativa por serviço no MVP; capa e logo editáveis; galeria de vários trabalhos fica para depois. Imagens `assets/*.webp` foram geradas a partir de composições ilustrativas de IA e recortadas/otimizadas para demonstração. Logo SVG original do salão fictício Maison Bella Studio.

Upload no protótipo: JPG/PNG/WebP de até 3 MB, corte central para proporções próprias de logo, capa e serviço, compressão WebP em canvas no navegador. Em produção, será necessário endpoint seguro, remoção de metadados, limites de upload, tratamento de formatos, acessibilidade e crop selecionável com melhor UX.

## Acessibilidade

Há rótulos, foco visível e `prefers-reduced-motion`. **Não houve auditoria completa WCAG/TalkBack**. Antes de produção: ampliar textos de legenda menores, testar contraste em modos de tela, aumentar alvos pequenos a pelo menos 44–48dp, teste com leitor de tela e fontes ampliadas sem cortes.
