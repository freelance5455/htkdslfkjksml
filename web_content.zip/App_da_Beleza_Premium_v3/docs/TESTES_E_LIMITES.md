# Qualidade e testes executados

## Resultados na prévia Web (Chromium)

- **TypeScript strict:** `tsc --project tsconfig.json` — passou sem erros.
- **Navegação:** 45 rotas renderizadas sem exceções JavaScript.
- **Layout responsivo:** varredura das 27 telas principais em **360×780, 393×852, 412×915, 768×1024 e 1440×1000** — sem erros JS.
- **Fluxos simulados:** novo agendamento, novo serviço, campanha agendada, reserva de cliente, favoritos via consentimento, avaliação privada sem publicação imediata e sugestão — todos passaram.
- **Fotografia:** carregamento local e crop central/Canvas WebP testados com foto de demonstração.
- **Imagens:** nenhuma imagem quebrada identificada nas verificações do protótipo.
- **Bug corrigido:** toast de confirmação interceptava cliques na parte inferior; alterado para `pointer-events:none` e remoção sem reconstruir formulário.
- **Bug corrigido:** botão “Alterar capa” era parcialmente coberto pelo cartão com logo; reposicionado e retestado.

Screenshots disponíveis em `tests/screenshots/`. Contato: `tests/v3_contact_sheet.jpg`.

## NÃO testado ou NÃO implementado

- Android físico, Android SDK, Flutter SDK, APK, instalação, AdMob de teste, FCM de teste, microfone/câmera nativa, deep links, notificações fora do app, botão Voltar Android.
- Backend multiusuário, sincronização de reservas, LGPD de produção, criptografia de servidor, termos, consulta/limite de spam, disparo real de campanhas, contestação real, regras reais de fidelidade.
- Processamento real de lote de dez avaliações distintas após sete dias e anonimização de nível de servidor.
- Auditoria completa de acessibilidade e performance em aparelho intermediário.

## Reexecução da suíte

Instale Playwright para Python e Chromium local. Execute:

```bash
python tests/visual_smoke.py
```

**Observação:** a suíte deste ambiente usa `page.set_content()` para evitar restrições locais de navegação. O usuário final abre `standalone.html` no Chrome.

## Regras antes de produção

Não publicar nem tratar os dados da demo como reais. Não vincular as imagens de clientes fictícios a pessoas reais. Não autorizar envio automático pelo WhatsApp. Não presumir que um link QR de ilustração funciona. Não usar os números fictícios para contato real.
