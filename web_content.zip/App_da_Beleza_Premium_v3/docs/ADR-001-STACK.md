# ADR-001 · Linguagem e arquitetura do App da Beleza

**Status:** ADIADO até Gate 0 nativo (decisão final não forçada por limitação do ambiente).

## Contexto

O app será publicado primeiro em **Android**, terá duas interfaces (profissional/cliente), AdMob e push. O usuário exige visual premium definido antes do backend e quer experimentar o design no Chrome sem refazer tudo depois.

## Candidatas finais

1. **Flutter + Dart**: desenho previsível, componentes/roteamento nativos do toolkit, web e Android a partir do mesmo projeto; integrações de AdMob e FCM requerem SDKs Android e testes reais. **Candidata principal**.
2. **TypeScript + React + Capacitor**: melhor se HTML/CSS do navegador for a fonte final de UI; requer testes de desempenho WebView, teclado, notificações/AdMob por plugins e Android Back. **Candidata secundária**.
3. **Kotlin + Jetpack Compose**: ótimo controle Android, mas prévia HTML independente resultaria em maior divergência de UI entre plataformas. Reserva de contingência.

## Decisão operacional nesta entrega

Construir uma **prévia TypeScript + CSS sem dependências e executável offline** para aprovar estética, e em paralelo fornecer uma **referência Flutter não compilada**. Isso NÃO aprova React/Capacitor nem Flutter de forma definitiva e NÃO garante transferência automática do TS para Dart. A prévia HTML será a referência de experiência e tokens.

## Gate 0 obrigatório

A mesma microexperiência (Painel, Agenda e Meu Salão com fotografia) deve ser construída e verificada no Flutter e no React/Capacitor, em Chrome e Android real/emulador. Verificar instalação, navegação, botão Back, safe areas, teclado, FCM, AdMob de teste, carregamento de imagens, câmera/galeria, links externos, desempenho e acessibilidade.

**Sem ferramentas Android nesta execução:** não se pode marcar Gate 0 como PASS. Não iniciar instalação, assinatura, publicação ou uso de chaves reais sem autorização técnica apropriada.
