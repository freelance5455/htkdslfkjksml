# Mapa de telas · Premium v3

As rotas da prévia se organizam em duas interfaces de um único App da Beleza. Dados e nomes são ficcionais.

## Acesso e configuração

- `login` — Entrada e seleção de ambiente de demonstração.
- `signup` — Cadastro de teste.
- `onboarding` — Assistente de configuração inicial.

## Profissional (5 abas e telas internas)

**Painel:** `dashboard`, `reports`, `notifications`.

**Agenda:** `agenda`, `appointment`, `newAppointment`, `schedule`.

**Clientes:** `clients`, `clientDetail`, `clientEditor`, `tags`, `loyalty`, `whatsapp`, `invite`.

**Campanhas:** `campaigns`, `campaignEditor`, `campaignDetail`.

**Gestão:** `settings`, `salon`, `salonEdit`, `salonPreview`, `branding`, `services`, `serviceEditor`, `pricing`, `reviews`, `suggestions`, `audit`.

## Cliente (4 abas e telas internas)

**Início:** `clientHome`, `clientSalon`, `serviceDetail` (referência de rota), `clientSchedule`, `clientBook`, `clientConfirm`.

**Agenda:** `clientBookings`, `clientReview`.

**Favoritos:** `clientFav`, `inviteJoin`, `clientLoyalty`.

**Perfil:** `clientProfile`, `clientNotifications`, `clientSuggestion`, `clientHelp`.

## Avisos de fidelidade ao escopo

- **Nenhuma tela pública de busca por salões, rankings ou serviços externos** no lançamento.
- Outros estabelecimentos entram por link/código/QR e só viram favorito mediante escolha da cliente.
- Avaliação de cinco estrelas por **serviço concluído**, sem comentário público; agregação protegida e publicação diferida são responsabilidade futura do backend.
- Preços ocultos por padrão no catálogo; preços/orçamento precisam ser comunicados antes de contratação vinculante.
- WhatsApp abre texto pré-preenchido no produto futuro, exigindo envio manual. Na demo o texto é apenas copiado para evitar abrir contato fictício.
- Cartão fidelidade geral/individual, tags e programação de push exibem os controles; efetividade em servidor, privacidade e automação NÃO estão implementadas na prévia.
