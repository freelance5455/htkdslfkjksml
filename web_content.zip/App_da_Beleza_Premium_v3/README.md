# App da Beleza · Premium v3

**Entrega de protótipo visual e funcional de demonstração (08/11/2026).** Referência de escopo: documento mestre `Planejamento_Completo_Apps_Barbeiro_e_Beleza_v015.docx`. Não altera o documento de produto aprovado.

## Começar em 30 segundos

**A opção mais simples** é abrir o arquivo `App_da_Beleza_Premium_v3_DEMO.html` (também incluído aqui como `standalone.html`) diretamente no Chrome. Ele contém imagens fictícias, CSS, SVG e JavaScript embutidos, **sem CDN, sem instalação, sem login real e sem internet**.

Para ver como Android: abra no Chrome → **F12** → **Ctrl + Shift + M** → escolha Pixel ou Galaxy. O HTML ajusta-se automaticamente a celulares; no computador, aparece num simulador visual com moldura.

No primeiro acesso da demonstração você entra no **Painel da profissional**. Acesse **Gestão → Trocar para ambiente cliente** para experimentar a cliente. Há também **Gestão → Simular tela de entrada** e **Gestão → Assistente de primeiro acesso**.

## O que foi feito

- **45 rotas de apresentação/fluxo** cobertas pela varredura de testes; principais áreas de profissional e cliente com navegação real no protótipo.
- Interface mobile-first com navegação inferior (5 abas profissional, 4 cliente), design em rosa nobre/marfim/champagne e ícones vetoriais SVG originais.
- Fotografias ilustrativas de IA de salão, cabelo, unhas, sobrancelhas, facial e personagens fictícios. Os ativos foram extraídos de composições geradas por IA e preparados em WebP.
- Formulários interativos de demonstração: novo atendimento, serviço, cliente e campanha; confirmação de favorito; cartão fidelidade; notas e sugestões.
- Edição local de **capa, logo e foto ilustrativa de serviço** com corte central e compressão WebP no navegador; sem upload para servidor.
- Preços ocultos no catálogo por padrão; opções de exibição; mensagens prontas e prévia WhatsApp **sem envio para número fictício**.
- Avisos comerciais separados de operacionais; suspensão de campanhas e pedido de revisão em simulação.
- Avaliações privadas de 1–5 estrelas por serviço e resumo público agregado fictício. **A regra real de 7 dias + lotes de 10 deve ser implementada no backend**; o protótipo não a calcula nem publica automaticamente.
- Protótipo offline; estado demonstrativo salvo em armazenamento local quando permitido pelo navegador; botão de reset em Gestão.

## Estrutura

| Local | Conteúdo |
|---|---|
| `standalone.html` | Prévia offline completa; pronto para abrir em arquivo local |
| `index.html` | Entrada modular web |
| `src/*.ts` | Código TypeScript strict de apresentação, estado e interações |
| `styles.css` | Design system premium e responsividade |
| `assets/*` | Logo SVG, imagens WebP de demonstração |
| `build/app.js` | JavaScript gerado pelo compilador TypeScript |
| `build_standalone.py` | Gera HTML único com CSS, JS e imagens embutidos |
| `tests/visual_smoke.py` | Testes de navegação, criação simulada e capturas em Chrome |
| `tests/screenshots/*` | Evidências de renderização em diferentes tamanhos |
| `docs/*` | Decisões técnicas, telas, qualidade, pendências e integrações |
| `flutter_reference/*` | **Fonte Flutter experimental e não compilado**, para Gate 0 futuro |

## Reconstruir a versão web

Requisitos: Node/TypeScript CLI (`tsc`) e Python 3.

```bash
tsc -p tsconfig.json
python build_standalone.py
```

A versão modular `index.html` usa arquivos locais relativos; no Chrome, a versão `standalone.html` oferece maior praticidade. Nenhuma dependência do npm é necessária para a prévia web.

## Limites desta entrega

Este é um **protótipo de UI**, não um sistema operacional. Não há contas reais, banco de dados, multiusuário, autenticação, push FCM, AdMob, API WhatsApp, avaliações processadas de forma segura, cobrança, controle de acesso de servidor ou APK. Nenhuma reserva ou mensagem real é enviada. Os links `exemplo.invalid` são fictícios.

O ambiente onde o protótipo foi produzido não possui Flutter SDK ou Android SDK e bloqueia a instalação externa; **por isso não foi possível compilar, instalar ou validar APK Android**. A escolha Flutter/Dart permanece **candidata**, condicionada ao Gate 0.

## Referências

- Plano técnico já aprovado: `Roadmap_Tecnico_App_da_Beleza_Premium_v3.docx` (fora deste ZIP, fornecido separadamente em conversa anterior).
- Base funcional: documento mestre v0.15.
- Descrições completas: `docs/ROADMAP_STATUS.md`, `docs/ADR-001-STACK.md`, `docs/MAPA_DE_TELAS.md`, `docs/TESTES_E_LIMITES.md`, `docs/DESIGN_SYSTEM.md`.
