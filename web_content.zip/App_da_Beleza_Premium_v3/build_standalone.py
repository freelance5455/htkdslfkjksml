from pathlib import Path
import base64,json,re,shutil
root=Path('/mnt/data/app_da_beleza_premium_v3')
html=(root/'index.html').read_text()
css=(root/'styles.css').read_text()
js=(root/'build/app.js').read_text()
assets={}
for f in (root/'assets').iterdir():
 if f.suffix.lower() not in ('.webp','.svg'):continue
 mime='image/svg+xml' if f.suffix=='.svg' else 'image/webp'
 assets[f.name]=f'data:{mime};base64,'+base64.b64encode(f.read_bytes()).decode('ascii')
# edit compiled emitted JS only; TypeScript source stays clean.
js=js.replace('const asset = (name) => `assets/${name}`;', 'const asset = (name) => INLINE_ASSETS[name] || `assets/${name}`;')
# direct logo embedded literal (not from asset function)
js=js.replace('src="assets/maison-bella-logo.svg"', 'src="'+assets['maison-bella-logo.svg']+'"')
js='const INLINE_ASSETS = '+json.dumps(assets,ensure_ascii=False,separators=(',',':'))+';\n'+js
html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+css+'</style>')
html=html.replace('<script src="build/app.js" defer></script>','<script>'+js+'</script>')
assert '<script src=' not in html
out=root/'standalone.html';out.write_text(html)
out2=Path('/mnt/data/App_da_Beleza_Premium_v3_DEMO.html');shutil.copyfile(out,out2)
print('Standalone:', out2, out2.stat().st_size, 'assets',len(assets))
