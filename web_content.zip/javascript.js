// =========================
// تنظیمات قابل تغییر
// =========================
const MAIN_PASSWORD = "123"; // رمز ورود اصلی را اینجا تغییر بده.
// برای امنیت بهتر، رمزها را در کد عمومی قرار ندهید؛ این نسخه یک گاوصندوق محلی آموزشی است.

// =========================
// IndexedDB
// =========================
const DB_NAME = "SecureVaultDB";
const DB_VERSION = 1;
const STORE = "files";
let db, selectedFile = null, currentObjectUrl = null, entered = "";

const $ = id => document.getElementById(id);
const loginView=$("loginView"), homeView=$("homeView"), fileView=$("fileView");
const loginDots=[...document.querySelectorAll("#loginDots i")];

function openDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=e=>{
      const d=e.target.result;
      if(!d.objectStoreNames.contains(STORE)){
        d.createObjectStore(STORE,{keyPath:"id",autoIncrement:true});
      }
    };
    req.onsuccess=e=>{db=e.target.result;resolve(db)};
    req.onerror=()=>reject(req.error);
  });
}
function tx(mode){return db.transaction(STORE,mode).objectStore(STORE)}
function addFile(file){
  return new Promise((resolve,reject)=>{
    const r=tx("readwrite").add({name:file.name,type:file.type||"application/octet-stream",size:file.size,blob:file,date:Date.now()});
    r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error);
  });
}
function getAll(){
  return new Promise((resolve,reject)=>{
    const r=tx("readonly").getAll(); r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error);
  });
}
function getOne(id){
  return new Promise((resolve,reject)=>{
    const r=tx("readonly").get(id); r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error);
  });
}
function removeFile(id){
  return new Promise((resolve,reject)=>{
    const r=tx("readwrite").delete(id); r.onsuccess=resolve; r.onerror=()=>reject(r.error);
  });
}

// =========================
// رمز ورود
// =========================
function updateDots(){
  loginDots.forEach((d,i)=>d.classList.toggle("on",i<entered.length));
}
function resetEntry(){entered="";updateDots()}
function buildKeys(){
  const box=$("loginKeys");
  [1,2,3,4,5,6,7,8,9,"⌫",0].forEach(n=>{
    const b=document.createElement("button"); b.className="key"; b.textContent=n;
    b.onclick=()=>{
      if(n==="⌫"){resetEntry();return}
      if(entered.length<3) entered+=String(n);
      updateDots();
      if(entered.length===3){
        if(entered===MAIN_PASSWORD){
          $("loginMsg").textContent="";
          loginView.classList.add("hidden"); homeView.classList.remove("hidden");
          resetEntry(); renderFiles();
        }else{
          $("loginMsg").textContent="رمز اشتباه است.";
          setTimeout(()=>{resetEntry();$("loginMsg").textContent=""},650);
        }
      }
    };
    box.appendChild(b);
  });
}

// =========================
// فایل‌ها
// =========================
function formatSize(n){
  if(n<1024)return n+" B";
  if(n<1048576)return (n/1024).toFixed(1)+" KB";
  if(n<1073741824)return (n/1048576).toFixed(1)+" MB";
  return (n/1073741824).toFixed(1)+" GB";
}
function iconFor(type,name){
  if(type.startsWith("image/"))return "🖼️";
  if(type.startsWith("video/"))return "🎬";
  if(type.startsWith("audio/"))return "🎵";
  if(type.includes("pdf")||name.toLowerCase().endsWith(".pdf"))return "📕";
  if(type.includes("zip")||name.toLowerCase().endsWith(".zip"))return "🗜️";
  if(type.includes("text"))return "📄";
  return "📦";
}
async function renderFiles(){
  const list=$("files"), files=await getAll();
  $("fileCount").textContent=files.length+" فایل";
  list.innerHTML="";
  if(!files.length){list.innerHTML='<p style="text-align:center">هنوز فایلی وارد نشده است.</p>';return}
  files.sort((a,b)=>b.date-a.date).forEach(f=>{
    const el=document.createElement("div"); el.className="file-item";
    el.innerHTML=`<div class="ico">${iconFor(f.type,f.name)}</div><div class="meta"><strong>${escapeHtml(f.name)}</strong><small>${formatSize(f.size)}</small></div><span>›</span>`;
    el.onclick=()=>openFile(f.id); list.appendChild(el);
  });
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

$("importBtn").onclick=()=>$("fileInput").click();
$("fileInput").onchange=async e=>{
  for(const file of e.target.files) await addFile(file);
  e.target.value=""; renderFiles();
};

async function openFile(id){
  selectedFile=await getOne(id);
  if(!selectedFile)return;
  homeView.classList.add("hidden"); fileView.classList.remove("hidden");
  $("fileName").textContent=selectedFile.name;
  $("fileInfo").textContent=formatSize(selectedFile.size)+" • "+(selectedFile.type||"فایل");
  $("fileIcon").textContent=iconFor(selectedFile.type,selectedFile.name);
  const p=$("preview"); p.innerHTML="";
  if(currentObjectUrl){URL.revokeObjectURL(currentObjectUrl);currentObjectUrl=null}
  currentObjectUrl=URL.createObjectURL(selectedFile.blob);
  if(selectedFile.type.startsWith("image/")){
    const img=document.createElement("img");img.src=currentObjectUrl;p.appendChild(img);
  }else if(selectedFile.type.startsWith("video/")){
    const v=document.createElement("video");v.src=currentObjectUrl;v.controls=true;p.appendChild(v);
  }else if(selectedFile.type==="application/pdf"){
    const frame=document.createElement("iframe");frame.src=currentObjectUrl;p.appendChild(frame);
  }else{
    p.innerHTML="<p>پیش‌نمایش این نوع فایل در مرورگر موجود نیست. برای دسترسی، از دکمه خروجی گرفتن استفاده کن.</p>";
  }
}
$("backBtn").onclick=()=>{if(currentObjectUrl)URL.revokeObjectURL(currentObjectUrl);currentObjectUrl=null;fileView.classList.add("hidden");homeView.classList.remove("hidden");renderFiles()};
$("downloadBtn").onclick=()=>{
  if(!selectedFile)return;
  const url=URL.createObjectURL(selectedFile.blob),a=document.createElement("a");
  a.href=url;a.download=selectedFile.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
};
$("deleteBtn").onclick=async()=>{
  if(!selectedFile)return;
  if(confirm("این فایل حذف شود؟")){
    await removeFile(selectedFile.id); selectedFile=null; $("backBtn").click();
  }
};
$("lockBtn").onclick=()=>{
  if(currentObjectUrl)URL.revokeObjectURL(currentObjectUrl);
  currentObjectUrl=null;selectedFile=null;homeView.classList.add("hidden");fileView.classList.add("hidden");loginView.classList.remove("hidden");resetEntry();
};

openDB().then(buildKeys).catch(()=>{$("loginMsg").textContent="حافظه برنامه در این محیط در دسترس نیست."});