const MAIN_CODE = "123";
const PAGE_CODES = { page1: "111", page2: "222", page3: "333" };

const lockScreen = document.getElementById("lockScreen");
const vault = document.getElementById("vault");
const pageLock = document.getElementById("pageLock");
const dots = [...document.querySelectorAll("#dots span")];
const message = document.getElementById("message");
let entered = "";

function updateDots(list, value){
  list.forEach((dot,i)=>dot.classList.toggle("active", i < value.length));
}

function resetMain(){
  entered = "";
  updateDots(dots, entered);
  message.textContent = "";
}

document.querySelectorAll("[data-key]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    if(entered.length >= 3) return;
    entered += btn.dataset.key;
    updateDots(dots, entered);
    if(entered.length === 3){
      if(entered === MAIN_CODE){
        lockScreen.classList.add("hidden");
        vault.classList.remove("hidden");
        resetMain();
      }else{
        message.textContent = "کد اشتباه است.";
        setTimeout(resetMain,700);
      }
    }
  });
});

document.getElementById("clear").addEventListener("click",resetMain);

let selectedPage = null;
let pageEntered = "";
const pageDots = [...document.querySelectorAll("#pageDots span")];
const pageMessage = document.getElementById("pageMessage");

document.querySelectorAll(".page-btn").forEach(btn=>{
  btn.addEventListener("click",()=>{
    selectedPage = btn.dataset.page;
    pageEntered = "";
    updateDots(pageDots,pageEntered);
    pageMessage.textContent = "";
    document.getElementById("pageLockTitle").textContent =
      selectedPage === "page1" ? "باز کردن صفحه اول" :
      selectedPage === "page2" ? "باز کردن صفحه دوم" : "باز کردن صفحه سوم";
    vault.classList.add("hidden");
    pageLock.classList.remove("hidden");
  });
});

document.querySelectorAll("[data-page-key]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    if(pageEntered.length >= 3) return;
    pageEntered += btn.dataset.pageKey;
    updateDots(pageDots,pageEntered);
    if(pageEntered.length === 3){
      if(pageEntered === PAGE_CODES[selectedPage]){
        pageLock.classList.add("hidden");
        document.getElementById(selectedPage).classList.remove("hidden");
      }else{
        pageMessage.textContent = "کد این صفحه اشتباه است.";
        setTimeout(()=>{
          pageEntered="";
          updateDots(pageDots,pageEntered);
          pageMessage.textContent="";
        },700);
      }
    }
  });
});

document.getElementById("pageClear").addEventListener("click",()=>{
  pageEntered="";
  updateDots(pageDots,pageEntered);
  pageMessage.textContent="";
});

document.getElementById("cancelPage").addEventListener("click",()=>{
  pageLock.classList.add("hidden");
  vault.classList.remove("hidden");
});

document.querySelectorAll(".back").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".vault-page").forEach(p=>p.classList.add("hidden"));
    vault.classList.remove("hidden");
  });
});

document.getElementById("lock").addEventListener("click",()=>{
  document.querySelectorAll(".vault-page").forEach(p=>p.classList.add("hidden"));
  vault.classList.add("hidden");
  pageLock.classList.add("hidden");
  lockScreen.classList.remove("hidden");
  resetMain();
});
