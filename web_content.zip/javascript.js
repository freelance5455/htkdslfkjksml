function ratioFromEvent(e){
  const r = seek.getBoundingClientRect();
  return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
}
seek.addEventListener('pointerdown', e=>{
  dragging = true;
  seek.setPointerCapture(e.pointerId);
  dragRatio = ratioFromEvent(e);
  paintSeek(dragRatio);
});
seek.addEventListener('pointermove', e=>{
  if(!dragging) return;
  dragRatio = ratioFromEvent(e);
  paintSeek(dragRatio);
});
seek.addEventListener('pointerup', e=>{
  if(!dragging) return;
  dragging = false;
  const d = getDuration();
  if(d) seek(dragRatio * d);
});