AMINA AI — ONLINE DEPLOYMENT PROJECT

What this project does
- Responsive Amina AI chat website, with English/Hausa interface and local browser chat history.
- Node.js backend that calls the OpenAI Responses API.
- The website calls its own /api/chat endpoint by default. No manual endpoint setting is needed after deployment.
- The API key stays on the server; never put it in index.html or share it in chat.
- No fake offline AI replies: if the online service is unavailable, Amina shows a connection error.

IMPORTANT
This ZIP is deployment-ready, but it is not already published online. You must deploy it and add your own OpenAI API key. API use may cost money; check your API billing/usage limits before using it. ChatGPT subscription and OpenAI API billing are separate.

DEPLOY USING RENDER (phone-friendly steps)
1. Download and extract this ZIP.
2. Create a GitHub account if you do not already have one, then create a NEW repository for this project.
3. Upload all files in this folder to that repository. Do NOT upload your .env file or any API key.
4. Open https://render.com and sign in.
5. Choose New > Blueprint (or create a Web Service connected to the repository). If using a Web Service manually, choose:
   - Runtime: Node
   - Build command: npm install
   - Start command: npm start
6. If using the Blueprint, Render reads render.yaml. In the service's Environment settings, add:
   - Key: OPENAI_API_KEY
   - Value: your own API key from the official OpenAI API platform
   Save and deploy. Keep this value private.
7. Wait for deployment to finish. Open the public HTTPS URL Render gives you, for example https://your-service.onrender.com.
8. Test by asking Amina a question in English, then in Hausa.

Official pages
- Render deploy guide: https://render.com/docs/web-services
- Render environment variables: https://render.com/docs/configure-environment-variables
- OpenAI API platform: https://platform.openai.com/
- OpenAI API models: https://platform.openai.com/docs/models

IF THE APP DOES NOT ANSWER
- Open https://YOUR-SERVICE.onrender.com/api/health. It should return JSON showing whether the AI is configured.
- If configured is false, add OPENAI_API_KEY to the Render service environment and redeploy.
- If you see an API/billing/model error, check your API account access, usage limits, and Render logs.
- Free hosting services may sleep when unused, so the first request can take longer.

PHONE NOTE
Once deployed, the website works online from Android or other devices using its public HTTPS URL. You do not need to run localhost on your phone.

PRIVACY / MEMORY
- Chat history is stored in that browser's local storage, not in a cloud account and not automatically shared across devices.
- Anyone with access to the same browser profile may be able to see locally saved chats. Clear browser storage if you need to remove them.
- Do not enter passwords, bank PINs, or payment-card details into the assistant.
