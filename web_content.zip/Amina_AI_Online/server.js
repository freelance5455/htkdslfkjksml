import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || "gpt-5-mini";
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));
app.use(express.static(__dirname));

const openai = apiKey ? new OpenAI({ apiKey }) : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(openai), assistant: "Amina" });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!openai) return res.status(503).json({ error: "AI is not configured. Set OPENAI_API_KEY in your server environment." });
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    if (!messages.length) return res.status(400).json({ error: "Please send at least one message." });

    // Accept only user/assistant text messages and cap context size.
    const safeMessages = messages.slice(-24).map(m => ({
      role: m?.role === "assistant" ? "assistant" : "user",
      content: String(m?.content || "").slice(0, 8000)
    })).filter(m => m.content.trim());

    const language = req.body?.language === "ha" ? "Hausa" : "English";
    const response = await openai.responses.create({
      model,
      instructions: `You are Amina, a helpful, friendly, accurate AI assistant. Reply in the language of the user's latest message; the requested interface language is ${language}, but follow the latest message if it is clearly in another language. Support natural English and Hausa, including ɓ, ɗ, ƙ, and ƴ. Explain clearly, adapt to the user's level, and ask a concise clarification when needed. Do not pretend to have live web access or know current facts unless tools are enabled. Never request passwords, PINs, or payment-card details. For high-stakes topics, provide general information and recommend a qualified professional. Keep responses useful and reasonably concise.`,
      input: safeMessages.map(m => ({ role: m.role, content: m.content })),
      max_output_tokens: 1200
    });
    const reply = (response.output_text || "").trim();
    if (!reply) return res.status(502).json({ error: "The AI returned an empty response. Please try again." });
    res.json({ reply });
  } catch (err) {
    console.error("AI request failed:", err?.status || "", err?.message || "Unknown error");
    const status = err?.status === 401 ? 502 : 502;
    res.status(status).json({ error: "The AI service could not complete this request. Check the server logs and API configuration." });
  }
});

app.listen(port, "0.0.0.0", () => console.log(`Amina AI server listening on port ${port}`));
