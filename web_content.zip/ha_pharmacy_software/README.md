# HA Pharmacy Software — offline-first starter

A responsive pharmacy inventory + billing web app with a PWA shell. The current build runs locally in a browser, saves data per username on that device, supports offline medicine management and billing, decrements stock when a sale is completed, and provides JSON backups + CSV exports. It is a working starter/demo, **not yet a production-secure multi-device Appwrite deployment**.

## Features included

- Welcome/sign-in/register screens and responsive dashboard.
- Local demo registration with a username unique within this browser profile.
- Store profile, medicine inventory, salt/formula, brand, strength, dosage form, pack size, stock unit, SKU/barcode, batch, expiry, minimum-stock warning, purchase/selling price.
- Create an invoice with multiple medicines, quantity controls, discount, invoice number, customer name/phone, save and print.
- Stock is checked again before sale and decremented at sale completion; a movement record is written locally.
- Low-stock/out-of-stock/expired labels, dashboard totals, sales history, estimated gross profit and 7-day sales chart.
- JSON backup/restore and CSV export for stock, invoices and reports.
- PWA manifest/service worker shell for offline use after it has been served over HTTPS/localhost and cached.

## Important limits — read before using real pharmacy records

1. **Local demo authentication is not secure production authentication.** The password hash in this starter is intentionally only a local demo placeholder. Browser storage can be cleared or inspected by someone with device access. Do not use it for real customer data or rely on it for account security.
2. **Usernames are unique only in the current browser's local storage.** They are not reserved globally. Logging in on another phone will not retrieve the first phone's data in this starter.
3. **Appwrite sync is not implemented in this starter.** The config file and proposed data model are supplied, but a secure server-side username-to-Appwrite-auth flow, tenant-level authorization, and conflict-safe sync adapter still need to be deployed. The Sync button deliberately reports this instead of pretending to sync.
4. A production implementation must use Appwrite Auth, a server-side Function to enforce unique usernames, database permissions/tenant isolation, and server-side validation. Never put an Appwrite API key in browser code.
5. Offline invoices can conflict with changes made on another device. Production sync should upload immutable invoice IDs and stock-movement events, then reconcile stock server-side; it should not simply overwrite a shared stock number.
6. Medicine unit choice is important: select one consistent stock unit (e.g. strip, bottle, piece). This starter bills in the selected stock unit; pack size is recorded as product information and does not automatically convert units.
7. This is not a prescription, dispensing, controlled-drug, tax-compliance, or regulatory system. Confirm local requirements and validate all stock and invoices before business use.

## Run locally

### Quickest option (Windows)

1. Extract the ZIP to a folder such as `C:\HA-Pharmacy`.
2. Install Node.js LTS from <https://nodejs.org/> if it is not already installed.
3. Open Command Prompt or PowerShell in the extracted folder.
4. Run:

   ```powershell
   npx --yes http-server . -p 8080 -c-1
   ```

5. On the computer, open `http://localhost:8080`.
6. On a phone connected to the same Wi-Fi, use the computer's local IP and port, e.g. `http://192.168.1.20:8080`. Service-worker/PWA installation normally requires HTTPS or localhost, so LAN HTTP may run the app but not install its PWA shell. Use HTTPS hosting for installation.

You can also open `index.html` directly for a basic local demo, but PWA caching and service worker registration require HTTPS or localhost.

## Host as a website

Upload the folder contents to any static host that serves HTTPS (for example, Cloudflare Pages, Netlify, or GitHub Pages). Do not publish sensitive production records in this demo. A static host alone does not provide secure multi-tenant accounts or Appwrite sync.

## Appwrite setup plan

1. Create an Appwrite project at <https://cloud.appwrite.io/>.
2. Add a Web platform for your production domain and `localhost` for development.
3. Create a database and collections. Suggested collections and attributes:

### `pharmacy_profiles`

- `ownerUserId` (string, required, indexed)
- `usernameNormalized` (string, required, **unique index**)
- `storeName` (string, required)
- `phone` (string, optional)
- `address` (string, optional)
- `createdAt` (datetime/string)

### `medicines`

- `ownerUserId` (string, required, indexed)
- `medicineId` (string, required, indexed)
- `name`, `salt`, `brand`, `strength`, `form`, `unit`, `sku`, `batch`, `expiry` (strings; fields used for search should be indexed where appropriate)
- `packSize`, `stock`, `minStock`, `cost`, `price` (numeric attributes)
- `updatedAt` (datetime/string)

### `bills`

- `ownerUserId` (string, required, indexed)
- `billId` (string, required, indexed)
- `number`, `date`, `customer`, `phone` (strings)
- `itemsJson` (string; or use a separate `bill_items` collection for larger systems)
- `subtotal`, `discount`, `total`, `estimatedCost` (numeric attributes)
- `createdAt`, `syncStatus` (string/datetime as appropriate)

### `stock_movements`

- `ownerUserId` (string, required, indexed)
- `movementId`, `medicineId`, `type`, `billId`, `date`, `note` (strings)
- `quantity` (number; negative for sale)
- `createdAt` (datetime/string)

4. Configure permissions so users can only read/write records belonging to their own authenticated identity. A `ownerUserId` field by itself is **not** an access-control boundary; enforce authorization through Appwrite document permissions or a trusted server-side API/Function.
5. In `appwrite-config.js`, set the public endpoint, project ID, database ID and collection IDs, then enable the config only after the secure auth and sync adapter have been implemented and tested.
6. For username/password-only sign-in, implement an Appwrite Function (or trusted backend) that normalizes and reserves usernames atomically and maps them to Appwrite Auth users. Appwrite's standard client Auth flow uses email/password; do not simulate secure usernames by creating fake email addresses in untrusted browser code.
7. Implement an idempotent sync protocol: stable client-generated IDs; immutable bill and stock-movement events; retry queue; server-side transaction/atomic stock checks; conflict handling; and a visible last-sync status. Test duplicate retries and two-device simultaneous sales.

## Build Android APK (Capacitor wrapper)

Prerequisites: Node.js LTS, Android Studio, Android SDK, and Java version supported by your installed Android Studio.

1. Create a separate working copy of this folder.
2. In that folder run:

   ```bash
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "HA Pharmacy" "com.haseebabbas.hapharmacy" --web-dir .
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

3. In Android Studio, wait for Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Android Studio shows the generated APK path. Test on a non-production device first.

If Capacitor asks for a web build directory and the root directory includes native config files, you may instead put the web files in a `www` folder and set `webDir: "www"` in `capacitor.config.*`; copy `index.html`, `styles.css`, `app.js`, `appwrite-config.js`, `manifest.webmanifest`, `icon.svg` and `sw.js` into `www`, then run `npx cap sync android`.

## Suggested production milestones

1. Confirm medicine unit/pack conversion rules (e.g. pieces ↔ strips ↔ boxes).
2. Deploy Appwrite Auth and unique username Function.
3. Add tenant-safe cloud sync + audit history + conflict handling.
4. Add barcode scanner, supplier/purchase receiving, returns, backup policy and user roles if needed.
5. Test printer layouts and backup/restore, then pilot with dummy data before real stock.
