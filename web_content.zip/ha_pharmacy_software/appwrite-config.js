/*
  Appwrite connection settings.
  1) Create an Appwrite project and Web platform for your deployed domain/localhost.
  2) Create a database and collections according to README.md.
  3) Put your public endpoint, project ID and database ID below.
  Do NOT put API keys or server secrets in this file.
*/
window.HA_APPWRITE_CONFIG = {
  endpoint: "https://cloud.appwrite.io/v1",
  projectId: "YOUR_APPWRITE_PROJECT_ID",
  databaseId: "YOUR_APPWRITE_DATABASE_ID",
  collections: {
    profiles: "pharmacy_profiles",
    medicines: "medicines",
    bills: "bills",
    stockMovements: "stock_movements"
  },
  enabled: false
};
