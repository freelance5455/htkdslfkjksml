#!/bin/bash
# ADAPTIVE RF X FPS
# Todos com 2>/dev/null || true

echo "Aplicando Adaptive RF X FPS..."

settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system min_refresh_rate 120 2>/dev/null || true
settings put system user_refresh_rate 120 2>/dev/null || true
settings put global force_high_refresh_rate 1 2>/dev/null || true
setprop debug.refresh_rate.min_fps 120 2>/dev/null || true
setprop debug.game.refresh_rate.min_fps 120 2>/dev/null || true
settings put global window_animation_scale 0 2>/dev/null || true
settings put global transition_animation_scale 0 2>/dev/null || true
settings put global animator_duration_scale 0 2>/dev/null || true
settings put global force_gpu_rendering 1 2>/dev/null || true

echo "Adaptive RF X FPS aplicado!"
