# SentryUp Android Studio Project

This project packages the current SentryUp web app in an Android WebView.

## Included
- Full Games / No Underlines HTML
- Supabase Admin Content Sync
- AI SentryBot Edge Function integration
- Internet permission
- Mobile WebView wrapper

## Open in Android Studio
1. Extract this project ZIP.
2. Open the `SentryUp_Android_Studio_Final` folder in Android Studio.
3. Allow Gradle sync and install any SDK components Android Studio requests.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Click **Run** to install the app.
6. To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important
The Gemini API key is NOT stored in this Android project. It must remain in the Supabase Edge Function secret `GEMINI_API_KEY`.

The app needs Internet access for Supabase and the AI bot. The game UI/content is bundled locally.

Application ID: `com.sentryup.app`
Version: `1.0`
