# SentryUp: no custom ProGuard rules required.
