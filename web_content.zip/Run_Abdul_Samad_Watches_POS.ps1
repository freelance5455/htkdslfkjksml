$appPath = Join-Path $PSScriptRoot "abdul_samad_watches_pos.html"
if (-not (Test-Path $appPath)) {
    Write-Host "ERROR: abdul_samad_watches_pos.html not found in $PSScriptRoot" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}
Start-Process -FilePath $appPath
