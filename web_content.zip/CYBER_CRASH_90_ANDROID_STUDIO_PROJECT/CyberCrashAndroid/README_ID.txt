YXC.V2 RIFKI — PROYEK ANDROID

Isi perubahan:
- Login Developer Rifki (akun lokal demo yang sudah ditanam di aplikasi).
- Tidak ada registrasi umum.
- Menu membuat akun pembeli tetap khusus Developer.
- Statistik TOTAL LOGIN bertambah setiap login berhasil pada perangkat tersebut.
- 90 pilihan efek visual demo dalam daftar geser horizontal.
- Semua 90 pilihan hanya animasi/tampilan lokal. Tidak mengirim pesan, menghubungi nomor, mengeksploitasi aplikasi, atau membuat perangkat lain crash.

CARA MEMBUAT APK:
1. Buka folder CyberCrashAndroid di Android Studio.
2. Tunggu Gradle Sync selesai (butuh Android SDK Platform 35 dan koneksi untuk mengambil plugin Gradle bila belum tersedia).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
File ini adalah proyek Android Studio siap dibangun, bukan APK yang sudah dikompilasi. Lingkungan pembuatan saat ini tidak memiliki Android SDK/Gradle, jadi APK biner belum dapat dibuat di sini.
Akun dan hitungan login disimpan lokal pada perangkat/browser aplikasi, belum tersinkron antar-HP. Untuk penggunaan banyak pembeli lintas perangkat dibutuhkan backend/database dan autentikasi server.
