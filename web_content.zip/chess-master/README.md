# Chess Master

Single-file offline chess game. No server, no build step, no dependencies.

## Run
Open `index.html` in any modern browser (works offline). On a phone, host the
folder anywhere static (GitHub Pages, Netlify) and use "Add to Home Screen".

## App icon
Icons are in `icons/` and wired up via `manifest.json` (installable as a PWA when hosted over HTTPS).

## Included
- Vs bot (9 levels, built-in engine, not Stockfish) and local 2-player
- Full rules, clocks, undo, resign, draw, PGN copy, saved games
- 10 interactive lessons
- Post-game review: accuracy, eval graph, move classification

## Not included
Online multiplayer, accounts/ratings, puzzles, PGN import, native Android/iOS builds.
To ship as an app, wrap this folder with Capacitor or similar.
