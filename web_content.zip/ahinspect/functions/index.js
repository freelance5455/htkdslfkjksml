const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");

initializeApp();
const ADMIN_SETUP_CODE = defineSecret("ADMIN_SETUP_CODE");

exports.activateAdmin = onCall({ secrets: [ADMIN_SETUP_CODE] }, async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Önce hesabına giriş yap.");
  }
  const code = String(request.data?.code || "");
  if (code !== ADMIN_SETUP_CODE.value()) {
    throw new HttpsError("permission-denied", "Admin kodu yanlış.");
  }
  await getAuth().setCustomUserClaims(request.auth.uid, { admin: true });
  return { success: true };
});
