M—TECH SPAM LAB — Android WebView / HTML-to-APK project

Includes:
- index.html: complete English Matrix-themed interface with hooded hacker-style icon, animated background, splash-like dashboard, message console, progress, operator list, API settings screen, statistics, and logs.
- assets/: visual reference images.

Build:
1. Extract the ZIP in your Android file manager.
2. Open your HTML-to-APK / WebView builder.
3. Import index.html as the start page and include the assets folder.
4. Enable JavaScript and allow local/offline assets.
5. Set app name to M—TECH SPAM LAB and build APK.

Important:
This is a front-end project and a local simulation. It does not send messages, contact phone numbers, extract carrier APIs, or connect to a provider. For legitimate real SMS testing, integrate an authorized messaging provider through a secure backend, use opted-in test recipients, and never embed secret API tokens in the APK.

The ZIP is intentionally not padded with junk to claim a 50–60 MB size. A valid project does not need arbitrary filler; final APK size depends on the assets and builder.
