Nathaney Clinic updated web files
- index.html: root entry
- web/index.html: entry for APK builders that load appassets.androidplatform.net/web/index.html

Changes:
- Admin delete now deletes from Firestore first, then updates local UI only on success; errors leave the record intact and show a message.
- Image/PDF file inputs accept common gallery image types.
- Invoice upload errors distinguish PDF and photo size problems.

Important:
Gallery selection in an Android WebView APK also depends on the HTML-to-APK builder supporting the native file chooser (WebChromeClient.onShowFileChooser). If tapping the file field does not open Gallery/Documents, enable its File Upload / File Chooser permission/setting or use a builder that supports it. Firebase Storage rules and billing must permit uploads.
