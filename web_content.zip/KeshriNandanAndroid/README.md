# Keshri Nandan Manufacturing Accounts (Android Studio project)

This is a native Android shell (Kotlin WebView) for an offline-first manufacturing/accounts app based on the supplied workbook's 11-sheet workflow.

## Modules
Dashboard; Product Master; Material Master; BOM/Recipe; Purchases; Production; Material Issue; Sales/GST calculation; Expenses; Stock Summary; JSON backup/restore and print view.

## Build APK
1. Install Android Studio (Ladybug or newer) and Android SDK Platform 35.
2. Open this folder (`KeshriNandanAndroid`) in Android Studio.
3. Allow Gradle sync.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important notes
- Data is stored locally in the app's WebView storage on that device. Export JSON backups regularly.
- This is a first working MVP, not a hosted multi-user accounting system. No login/cloud sync is configured.
- GST invoice figures are calculated from entered rates and GST percentages; validate GST rules, invoice numbering, HSN/SAC, CGST/SGST/IGST and statutory reports with a qualified accountant before commercial use.
- The workbook's sample products/materials are not automatically imported; add/edit master records in the app. The original Excel file remains unchanged.
