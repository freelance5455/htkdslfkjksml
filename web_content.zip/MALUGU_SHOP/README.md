# MALUGU SHOP — mfano wa kwanza (demo)

Hii ni prototype ya duka la bidhaa mbalimbali inayofanya kazi kwenye kivinjari cha Android na kompyuta.

## Iliyopo
- Bidhaa za mfano na bei za TZS
- Utafutaji na vikundi vya bidhaa
- Kikapu na kuongeza/kupunguza idadi
- Fomu ya oda ya majaribio
- Oda huhifadhiwa kwenye kifaa/kivinjari hicho kupitia localStorage
- Hakuna malipo halisi, akaunti za wateja, au seva

## Jinsi ya kujaribu kwenye Android
1. Pakua ZIP na utoe (extract) faili.
2. Fungua `index.html` kwenye Chrome ya simu. Ikiwa faili halifunguki moja kwa moja, fungua kupitia app ya Files.
3. Jaribu kutafuta bidhaa, kuongeza kikapuni na kutuma oda ya majaribio.

## Jinsi ya kuandaa APK
Njia inayopendekezwa ni kutumia kompyuta:
1. Sakinisha Android Studio na Android SDK.
2. Unda mradi mpya wa Android (Empty Views Activity).
3. Weka `index.html` kwenye `app/src/main/assets/`.
4. Tumia Android WebView kupakia `file:///android_asset/index.html`, au tumia Capacitor kuifunga kama app ya Android.
5. Jenga na ujaribu debug APK; kisha tengeneza signed release APK kwa usambazaji.
6. Jaribu kwenye simu halisi kabla ya kutoa kwa wateja.

## Muhimu kabla ya biashara halisi
- Badilisha bidhaa/bei za mfano kwenye sehemu ya `products` ndani ya `index.html`.
- Ongeza backend/database salama kwa bidhaa na oda; localStorage pekee si mfumo wa oda wa wateja wengi.
- Tumia uthibitishaji na ruhusa za msimamizi.
- Malipo ya simu yanahitaji kuunganishwa na mtoa huduma rasmi na kuthibitishwa upande wa seva. Usihifadhi PIN au siri za malipo ndani ya app.
- Ongeza sera ya faragha, masharti, mawasiliano ya biashara na gharama za usafirishaji.
- Usitumie demo hii kukusanya taarifa nyeti za wateja au kupokea malipo halisi.

## Muundo wa mradi
- `index.html` — UI, CSS na JavaScript ya demo.
- `README.md` — mwongozo huu.
