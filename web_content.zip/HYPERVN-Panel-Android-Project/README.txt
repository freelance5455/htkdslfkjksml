HYPERVN Panel Android
1. Open this folder in Android Studio
2. Build > Build APK(s)
3. Output: app/build/outputs/apk/debug/app-debug.apk
Opens connection gate then panel https://mc.hypervn.net:33334
