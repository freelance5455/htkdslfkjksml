require("dotenv").config();
const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const helmet = require("helmet");
const compression = require("compression");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DB_FILE = path.resolve(ROOT, process.env.DATABASE_FILE || "./data/connectly.sqlite");
const UPLOAD_DIR = path.resolve(ROOT, process.env.UPLOAD_DIR || "./uploads");
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 25);
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET to a random secret of at least 32 characters in .env");
  process.exit(1);
}
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(DB_FILE);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, username TEXT NOT NULL UNIQUE,
 email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '',
 avatar_url TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS posts (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL DEFAULT '', media_url TEXT NOT NULL DEFAULT '',
 media_type TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS likes (
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL, PRIMARY KEY(user_id, post_id)
);
CREATE TABLE IF NOT EXISTS comments (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
 body TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS follows (
 follower_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 following_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL, PRIMARY KEY(follower_id, following_id),
 CHECK(follower_id <> following_id)
);
CREATE TABLE IF NOT EXISTS messages (
 id TEXT PRIMARY KEY, sender_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 recipient_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 actor_id TEXT REFERENCES users(id) ON DELETE SET NULL,
 kind TEXT NOT NULL, post_id TEXT REFERENCES posts(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_pair ON messages(sender_id, recipient_id, created_at);
`);

const id = () => crypto.randomUUID();
const now = () => new Date().toISOString();
const publicUser = u => ({
  id: u.id, name: u.name, username: u.username, bio: u.bio || "",
  avatarUrl: u.avatar_url || "", createdAt: u.created_at
});
const getUser = db.prepare("SELECT * FROM users WHERE id=?");
const getPost = db.prepare("SELECT * FROM posts WHERE id=?");

function createNotification(userId, actorId, kind, postId = null) {
  if (userId && userId !== actorId) {
    db.prepare("INSERT INTO notifications(id,user_id,actor_id,kind,post_id,created_at) VALUES(?,?,?,?,?,?)")
      .run(id(), userId, actorId, kind, postId, now());
  }
}
function tokenFor(user) {
  return jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: "7d", issuer: "connectly" });
}
function auth(req, res, next) {
  const header = req.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return res.status(401).json({ error: "Please log in." });
  try {
    const payload = jwt.verify(token, JWT_SECRET, { issuer: "connectly" });
    const user = getUser.get(payload.sub);
    if (!user) return res.status(401).json({ error: "Account no longer exists." });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: "Session expired. Please log in again." });
  }
}
function cleanText(value, max = 2000) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function routeError(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

app.disable("x-powered-by");
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(compression());
app.use(cors({
  origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(",").map(s => s.trim()) : true,
  credentials: false
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false, limit: "1mb" }));
app.use("/uploads", express.static(UPLOAD_DIR, { maxAge: "1d", immutable: false }));
app.use(express.static(path.join(ROOT, "public")));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase())
});
const upload = multer({
  storage,
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = /^(image\/jpeg|image\/png|image\/gif|image\/webp|video\/mp4|video\/webm)$/;
    if (!allowed.test(file.mimetype)) return cb(new Error("Only JPG, PNG, GIF, WEBP, MP4 and WEBM files are allowed."));
    cb(null, true);
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Connectly API" }));

app.post("/api/auth/register", routeError(async (req, res) => {
  const name = cleanText(req.body.name, 80);
  const username = cleanText(req.body.username, 24).toLowerCase().replace(/^@/, "");
  const email = cleanText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  if (name.length < 2) return res.status(400).json({ error: "Name must be at least 2 characters." });
  if (!/^[a-z0-9_]{3,24}$/.test(username)) return res.status(400).json({ error: "Username must be 3–24 characters (letters, numbers, underscores)." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email." });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });
  if (db.prepare("SELECT 1 FROM users WHERE email=? OR username=?").get(email, username)) {
    return res.status(409).json({ error: "That email or username is already registered." });
  }
  const user = {
    id: id(), name, username, email, password_hash: await bcrypt.hash(password, 12),
    bio: "", avatar_url: "", created_at: now()
  };
  db.prepare("INSERT INTO users(id,name,username,email,password_hash,bio,avatar_url,created_at) VALUES(?,?,?,?,?,?,?,?)")
    .run(user.id, user.name, user.username, user.email, user.password_hash, user.bio, user.avatar_url, user.created_at);
  res.status(201).json({ token: tokenFor(user), user: publicUser(user) });
}));

app.post("/api/auth/login", routeError(async (req, res) => {
  const email = cleanText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: "Incorrect email or password." });
  }
  res.json({ token: tokenFor(user), user: publicUser(user) });
}));
app.get("/api/me", auth, (req, res) => res.json({ user: publicUser(req.user) }));

app.patch("/api/me", auth, (req, res) => {
  const name = cleanText(req.body.name, 80);
  const bio = cleanText(req.body.bio, 300);
  if (name.length < 2) return res.status(400).json({ error: "Name must be at least 2 characters." });
  db.prepare("UPDATE users SET name=?,bio=? WHERE id=?").run(name, bio, req.user.id);
  res.json({ user: publicUser(getUser.get(req.user.id)) });
});

app.post("/api/me/avatar", auth, upload.single("media"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Choose an image." });
  if (!req.file.mimetype.startsWith("image/")) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "Avatar must be an image." });
  }
  const url = `/uploads/${req.file.filename}`;
  db.prepare("UPDATE users SET avatar_url=? WHERE id=?").run(url, req.user.id);
  res.json({ user: publicUser(getUser.get(req.user.id)) });
});

app.get("/api/users", auth, (req, res) => {
  const q = cleanText(req.query.q, 80);
  const rows = q
    ? db.prepare("SELECT * FROM users WHERE id<>? AND (name LIKE ? OR username LIKE ?) ORDER BY name LIMIT 30").all(req.user.id, `%${q}%`, `%${q}%`)
    : db.prepare("SELECT * FROM users WHERE id<>? ORDER BY created_at DESC LIMIT 30").all(req.user.id);
  res.json({ users: rows.map(u => ({
    ...publicUser(u),
    followers: db.prepare("SELECT count(*) n FROM follows WHERE following_id=?").get(u.id).n,
    following: db.prepare("SELECT count(*) n FROM follows WHERE follower_id=?").get(u.id).n,
    isFollowing: !!db.prepare("SELECT 1 FROM follows WHERE follower_id=? AND following_id=?").get(req.user.id, u.id)
  })) });
});

function postShape(p, viewerId) {
  const u = getUser.get(p.user_id);
  return {
    id: p.id, body: p.body, mediaUrl: p.media_url || "", mediaType: p.media_type || "",
    createdAt: p.created_at, user: publicUser(u),
    likeCount: db.prepare("SELECT count(*) n FROM likes WHERE post_id=?").get(p.id).n,
    commentCount: db.prepare("SELECT count(*) n FROM comments WHERE post_id=?").get(p.id).n,
    liked: !!db.prepare("SELECT 1 FROM likes WHERE user_id=? AND post_id=?").get(viewerId, p.id),
    comments: db.prepare(`SELECT c.id,c.body,c.created_at,u.id user_id,u.name,u.username,u.avatar_url
      FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.created_at ASC LIMIT 20`).all(p.id)
      .map(c => ({ id:c.id, body:c.body, createdAt:c.created_at, user:{id:c.user_id,name:c.name,username:c.username,avatarUrl:c.avatar_url||""} }))
  };
}
app.get("/api/feed", auth, (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 30, 1), 60);
  const offset = Math.max(Number(req.query.offset) || 0, 0);
  const posts = db.prepare(`SELECT p.* FROM posts p
    WHERE p.user_id=? OR p.user_id IN (SELECT following_id FROM follows WHERE follower_id=?)
    ORDER BY p.created_at DESC LIMIT ? OFFSET ?`).all(req.user.id, req.user.id, limit, offset);
  res.json({ posts: posts.map(p => postShape(p, req.user.id)) });
});
app.get("/api/users/:id/posts", auth, (req, res) => {
  const user = getUser.get(req.params.id);
  if (!user) return res.status(404).json({ error: "User not found." });
  const posts = db.prepare("SELECT * FROM posts WHERE user_id=? ORDER BY created_at DESC LIMIT 60").all(user.id);
  res.json({ user: publicUser(user), posts: posts.map(p => postShape(p, req.user.id)) });
});

app.post("/api/posts", auth, upload.single("media"), (req, res) => {
  const body = cleanText(req.body.body, 2200);
  if (!body && !req.file) return res.status(400).json({ error: "Write a caption or attach media." });
  const postId = id();
  const mediaUrl = req.file ? `/uploads/${req.file.filename}` : "";
  const mediaType = req.file ? (req.file.mimetype.startsWith("video/") ? "video" : "image") : "";
  db.prepare("INSERT INTO posts(id,user_id,body,media_url,media_type,created_at) VALUES(?,?,?,?,?,?)")
    .run(postId, req.user.id, body, mediaUrl, mediaType, now());
  res.status(201).json({ post: postShape(getPost.get(postId), req.user.id) });
});
app.delete("/api/posts/:id", auth, (req, res) => {
  const post = getPost.get(req.params.id);
  if (!post) return res.status(404).json({ error: "Post not found." });
  if (post.user_id !== req.user.id) return res.status(403).json({ error: "You can only delete your own posts." });
  if (post.media_url) {
    const f = path.join(UPLOAD_DIR, path.basename(post.media_url));
    if (fs.existsSync(f)) fs.unlinkSync(f);
  }
  db.prepare("DELETE FROM posts WHERE id=?").run(post.id);
  res.json({ ok: true });
});

app.post("/api/posts/:id/like", auth, (req, res) => {
  const post = getPost.get(req.params.id);
  if (!post) return res.status(404).json({ error: "Post not found." });
  const existing = db.prepare("SELECT 1 FROM likes WHERE user_id=? AND post_id=?").get(req.user.id, post.id);
  if (existing) db.prepare("DELETE FROM likes WHERE user_id=? AND post_id=?").run(req.user.id, post.id);
  else {
    db.prepare("INSERT INTO likes(user_id,post_id,created_at) VALUES(?,?,?)").run(req.user.id, post.id, now());
    createNotification(post.user_id, req.user.id, "like", post.id);
  }
  res.json({ liked: !existing, likeCount: db.prepare("SELECT count(*) n FROM likes WHERE post_id=?").get(post.id).n });
});
app.post("/api/posts/:id/comments", auth, (req, res) => {
  const post = getPost.get(req.params.id);
  const body = cleanText(req.body.body, 1000);
  if (!post) return res.status(404).json({ error: "Post not found." });
  if (!body) return res.status(400).json({ error: "Comment cannot be empty." });
  const comment = { id:id(), user_id:req.user.id, post_id:post.id, body, created_at:now() };
  db.prepare("INSERT INTO comments(id,user_id,post_id,body,created_at) VALUES(?,?,?,?,?)")
    .run(comment.id, comment.user_id, comment.post_id, comment.body, comment.created_at);
  createNotification(post.user_id, req.user.id, "comment", post.id);
  res.status(201).json({ comment:{ id:comment.id, body, createdAt:comment.created_at, user:publicUser(req.user) } });
});

app.post("/api/users/:id/follow", auth, (req, res) => {
  const target = getUser.get(req.params.id);
  if (!target) return res.status(404).json({ error: "User not found." });
  if (target.id === req.user.id) return res.status(400).json({ error: "You cannot follow yourself." });
  const exists = db.prepare("SELECT 1 FROM follows WHERE follower_id=? AND following_id=?").get(req.user.id, target.id);
  if (exists) db.prepare("DELETE FROM follows WHERE follower_id=? AND following_id=?").run(req.user.id, target.id);
  else {
    db.prepare("INSERT INTO follows(follower_id,following_id,created_at) VALUES(?,?,?)").run(req.user.id, target.id, now());
    createNotification(target.id, req.user.id, "follow");
  }
  res.json({ following: !exists });
});

app.get("/api/notifications", auth, (req, res) => {
  const rows = db.prepare(`SELECT n.*,u.name,u.username,u.avatar_url FROM notifications n
    LEFT JOIN users u ON u.id=n.actor_id WHERE n.user_id=? ORDER BY n.created_at DESC LIMIT 60`).all(req.user.id);
  res.json({ notifications: rows.map(n => ({
    id:n.id, kind:n.kind, postId:n.post_id, createdAt:n.created_at, isRead:!!n.is_read,
    actor:n.actor_id ? {id:n.actor_id,name:n.name,username:n.username,avatarUrl:n.avatar_url||""} : null
  })) });
});
app.post("/api/notifications/read", auth, (req, res) => {
  db.prepare("UPDATE notifications SET is_read=1 WHERE user_id=?").run(req.user.id);
  res.json({ ok:true });
});

app.get("/api/messages/:userId", auth, (req, res) => {
  const other = getUser.get(req.params.userId);
  if (!other) return res.status(404).json({ error: "User not found." });
  const messages = db.prepare(`SELECT * FROM messages WHERE
    (sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?)
    ORDER BY created_at ASC LIMIT 200`).all(req.user.id, other.id, other.id, req.user.id);
  res.json({ messages: messages.map(m => ({
    id:m.id, body:m.body, createdAt:m.created_at,
    senderId:m.sender_id, recipientId:m.recipient_id
  })) });
});
app.post("/api/messages/:userId", auth, (req, res) => {
  const other = getUser.get(req.params.userId);
  const body = cleanText(req.body.body, 2000);
  if (!other) return res.status(404).json({ error: "User not found." });
  if (other.id === req.user.id) return res.status(400).json({ error: "Cannot message yourself." });
  if (!body) return res.status(400).json({ error: "Message cannot be empty." });
  const message = { id:id(), sender_id:req.user.id, recipient_id:other.id, body, created_at:now() };
  db.prepare("INSERT INTO messages(id,sender_id,recipient_id,body,created_at) VALUES(?,?,?,?,?)")
    .run(message.id, message.sender_id, message.recipient_id, message.body, message.created_at);
  createNotification(other.id, req.user.id, "message");
  res.status(201).json({ message:{ id:message.id, body, createdAt:message.created_at, senderId:message.sender_id, recipientId:message.recipient_id } });
});

app.get("/api/search", auth, (req, res) => {
  const q = cleanText(req.query.q, 80);
  if (!q) return res.json({ users:[], posts:[] });
  const users = db.prepare("SELECT * FROM users WHERE name LIKE ? OR username LIKE ? LIMIT 20").all(`%${q}%`,`%${q}%`);
  const posts = db.prepare("SELECT * FROM posts WHERE body LIKE ? ORDER BY created_at DESC LIMIT 30").all(`%${q}%`);
  res.json({
    users: users.map(publicUser),
    posts: posts.map(p => postShape(p, req.user.id))
  });
});

app.use("/api", (_req, res) => res.status(404).json({ error: "API endpoint not found." }));
app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    const msg = err.code === "LIMIT_FILE_SIZE" ? `File is too large (max ${MAX_UPLOAD_MB} MB).` : err.message;
    return res.status(400).json({ error: msg });
  }
  if (err.message && /Only JPG|Avatar must/.test(err.message)) return res.status(400).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});

app.listen(PORT, () => console.log(`Connectly running at http://localhost:${PORT}`));
