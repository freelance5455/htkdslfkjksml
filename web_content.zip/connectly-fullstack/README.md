# Connectly — full-stack social media starter

A runnable multi-user social app starter: Node.js + Express API, SQLite database, JWT authentication, password hashing, persistent posts, image/video uploads, likes, comments, follows, search, notifications, profiles and direct messages.

## Requirements
- Node.js 20+
- npm

## Run locally
1. Extract the ZIP.
2. Copy `.env.example` to `.env`.
3. In `.env`, set `JWT_SECRET` to a random secret of at least 32 characters. Example generation:
   - macOS/Linux: `openssl rand -hex 32`
   - PowerShell: `[Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))`
4. Install and start:
   ```bash
   npm install
   npm start
   ```
5. Open `http://localhost:3000`.

Create an account in the app. Each user needs a distinct account/email to test multi-user features. You can open the app in a second browser profile to test two accounts on one computer.

## Features
- Registration and login; passwords hashed with bcrypt
- JWT-authenticated API routes
- SQLite persistence
- Feed from you and accounts you follow
- Text posts plus image/video uploads
- Likes, comments, follows and notifications
- Search users and posts
- User profiles, bio/avatar editing
- One-to-one direct messages (poll-free request/response, not real-time sockets)
- Responsive mobile-friendly UI and light/dark mode
- Upload size/type checks, Helmet, rate-limited auth endpoints

## API overview
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/me`, `PATCH /api/me`, `POST /api/me/avatar`
- `GET /api/users?q=...`
- `GET /api/feed`
- `GET /api/users/:id/posts`
- `POST /api/posts`, `DELETE /api/posts/:id`
- `POST /api/posts/:id/like`
- `POST /api/posts/:id/comments`
- `POST /api/users/:id/follow`
- `GET /api/notifications`, `POST /api/notifications/read`
- `GET /api/messages/:userId`, `POST /api/messages/:userId`
- `GET /api/search?q=...`
- `GET /api/health`

Protected endpoints expect `Authorization: Bearer <token>`.

## Important production notes
This is a working starter, not a finished large-scale production service.
- SQLite and local uploads are convenient for development. For a public deployment with multiple instances, move to managed PostgreSQL and S3-compatible object storage (S3, Cloudflare R2, or similar).
- Set a strong private `JWT_SECRET`, use HTTPS, restrict `CORS_ORIGIN`, and never commit `.env`.
- For a public launch, add email verification, password reset, token revocation/refresh, moderation/reporting/blocking, privacy controls, CSRF strategy if using cookies, robust validation, audit logging, backups, malware/content scanning, and automated tests.
- Current JWTs are stored in browser localStorage. For a hardened production web app, consider secure HttpOnly cookies and a carefully designed CSRF/session strategy.
- Direct messages are stored and fetched via REST; they are not end-to-end encrypted or real-time. Add WebSockets (e.g. Socket.IO) for live chat.
- Local uploads are served by Express and are not cloud storage. Add signed uploads and private access policies for production.
- Stories, reels, groups, pages, live video, push notifications and OAuth are not implemented in this starter.
- If deploying to a host with an ephemeral filesystem, configure persistent storage or replace SQLite/uploads with managed services.
