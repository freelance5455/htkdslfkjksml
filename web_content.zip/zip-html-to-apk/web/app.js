const $=s=>document.querySelector(s);
let selected=null, currentJob=null, pollTimer=null;
function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2600)}
function fmt(n){if(n<1024)return n+" B";if(n<1024**2)return(n/1024).toFixed(1)+" KB";if(n<1024**3)return(n/1024**2).toFixed(1)+" MB";return(n/1024**3).toFixed(2)+" GB"}
async function loadConfig(){try{const c=await fetch("/api/config").then(r=>r.json());$("#maxSize").textContent=c.maxUploadGB+" GB"}catch{}}
function setFile(f){if(!f)return;const ext=f.name.toLowerCase().split(".").pop();if(!["zip","html","htm"].includes(ext)){toast("Pilih file ZIP atau HTML");return}selected=f;$("#filePreview").textContent=`${f.name} · ${fmt(f.size)}`}
$("#file").addEventListener("change",e=>setFile(e.target.files[0]));
const drop=$("#drop");drop.addEventListener("dragover",e=>{e.preventDefault();drop.classList.add("drag")});drop.addEventListener("dragleave",()=>drop.classList.remove("drag"));drop.addEventListener("drop",e=>{e.preventDefault();drop.classList.remove("drag");setFile(e.dataTransfer.files[0])});
function showBuild(){ $("#empty").classList.add("hidden");$("#progress").classList.remove("hidden");$("#download").classList.add("hidden");$("#logs").textContent="";$("#bar").style.width="8%"; }
async function startBuild(){
 if(!selected){toast("Pilih file ZIP atau HTML dulu");return}
 const name=$("#appName").value.trim(), pkg=$("#packageId").value.trim();
 if(!name){toast("Nama aplikasi wajib diisi");return}
 if(!/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,5}$/.test(pkg)){toast("Package ID tidak valid");return}
 const btn=$("#build");btn.disabled=true;btn.textContent="Mengunggah...";
 showBuild();$("#buildStatus").textContent="UPLOADING";$("#progressTitle").textContent="Mengunggah dan menyiapkan project...";
 const fd=new FormData();fd.append("project",selected);fd.append("appName",name);fd.append("packageId",pkg);
 try{
  const r=await fetch("/api/build",{method:"POST",body:fd});const d=await r.json();if(!r.ok)throw new Error(d.error||"Upload gagal");
  currentJob=d.id;$("#progressTitle").textContent="Build sedang berjalan";$("#buildStatus").textContent="BUILDING";poll();
 }catch(e){$("#progressTitle").textContent="Build gagal";$("#logs").textContent=e.message;$("#buildStatus").textContent="ERROR";btn.disabled=false;btn.textContent="Build APK ↗"}
}
async function poll(){
 if(!currentJob)return;
 try{
  const r=await fetch("/api/jobs/"+currentJob),d=await r.json();if(!r.ok)throw new Error(d.error||"Job error");
  $("#logs").textContent=(d.log||[]).join("\n");$("#logs").scrollTop=$("#logs").scrollHeight;
  if(d.status==="done"){ $("#progressTitle").textContent="APK berhasil dibuat";$("#progressPct").textContent="100%";$("#bar").style.width="100%";$("#buildStatus").textContent="SUCCESS";$("#download").href=d.downloadUrl;$("#download").classList.remove("hidden");$("#build").disabled=false;$("#build").textContent="Build APK ↗";toast("APK siap diunduh");return}
  if(d.status==="error"){ $("#progressTitle").textContent="Build gagal";$("#buildStatus").textContent="ERROR";$("#build").disabled=false;$("#build").textContent="Build APK ↗";toast(d.error||"Build gagal");return}
  $("#bar").style.width=d.status==="processing"?"55%":"20%";$("#progressPct").textContent="●";
  pollTimer=setTimeout(poll,2500);
 }catch(e){$("#logs").textContent+="\n"+e.message;$("#buildStatus").textContent="ERROR";$("#build").disabled=false;$("#build").textContent="Build APK ↗"}
}
$("#build").addEventListener("click",startBuild);loadConfig();
