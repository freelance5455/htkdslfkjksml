# ZIP / HTML to APK Converter

A self-hosted web application that wraps an HTML/CSS/JavaScript website inside a native Android WebView APK.

## Important: what this project does
- Accepts a ZIP containing a website or a single `.html` file.
- Detects `index.html` (or renames a single HTML file to `index.html`).
- Creates a native Android WebView project and invokes Gradle to build a debug APK.
- Supports app name and Android package ID configuration.
- Provides an APK download when the build succeeds.

This is a source project, not a hosted conversion service and not a precompiled APK.

## Upload size
The requested maximum is configured as **183 GB** in `server/.env.example`.
This is only an application-side upload ceiling. It does NOT mean a typical VPS, phone, browser, disk, or internet connection can actually accept/process a 183 GB file. The server needs enough free disk space, memory, bandwidth, and build capacity. For real deployments, use resumable/chunked uploads and object storage for files this large. This starter uses a normal multipart upload and is best tested with small projects.

## Requirements
- Node.js 20+
- Java JDK 17
- Android SDK with platform 35 and build-tools installed
- Gradle 8.9+ installed and available on PATH
- Android SDK environment variable `ANDROID_HOME` (or `ANDROID_SDK_ROOT`)

## Run locally
```bash
cd server
cp .env.example .env
npm install
npm start
```
Open `http://localhost:3000`.

## Build configuration
The server runs `gradle assembleDebug` inside a generated Android project.
Set `ANDROID_HOME`/`ANDROID_SDK_ROOT` correctly and ensure the SDK platform/build-tools are installed.
The APK appears in the server's `jobs/<job-id>/project/app/build/outputs/apk/debug/app-debug.apk`.
Use the UI's Download APK button after a successful build.

## Accepted ZIP structure
Either:
```
my-site.zip
  index.html
  style.css
  app.js
  assets/
```
or:
```
my-site.zip
  my-site/
    index.html
    ...
```
The server searches for the first `index.html` (case-insensitive). If no index exists but exactly one HTML file exists, it uses that file as the entry point.

## Safety / limitations
- ZIP extraction rejects path traversal, symlinks, excessive file counts, and expanded archives larger than `MAX_EXTRACTED_GB`.
- This starter only packages static web files. Server-side Node/PHP/Python code inside the ZIP is not executed.
- Do not upload websites or assets you do not have permission to package.
- Only upload projects you trust. The WebView has JavaScript enabled for local website functionality; avoid loading untrusted remote content.
- For public deployment, add user accounts, rate limits, HTTPS, malware scanning, persistent job storage, and proper cleanup.
- The "Unlimited • Rp20.000" card is a promotional UI placeholder supplied by the project owner. It does not process payments or verify purchases. The TikTok handle is shown as requested; verify the seller and terms independently before paying.
