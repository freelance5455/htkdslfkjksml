require("dotenv").config();
const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawn } = require("child_process");
const yauzl = require("yauzl");
const archiver = require("archiver");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = path.resolve(__dirname, "..");
const JOBS = path.join(__dirname, "jobs");
const TEMPLATE = path.resolve(__dirname, process.env.ANDROID_TEMPLATE_DIR || "../android-template");
fs.mkdirSync(JOBS, { recursive: true });
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(ROOT, "web")));

const uploadLimit = Number(process.env.MAX_UPLOAD_GB || 183) * 1024 ** 3;
const upload = multer({
  dest: path.join(JOBS, "incoming"),
  limits: { fileSize: uploadLimit, files: 1 }
});

const jobs = new Map();
let activeBuilds = 0;
const maxBuilds = Math.max(1, Number(process.env.MAX_BUILDS || 2));

function cleanName(s) {
  return String(s || "My Website").replace(/[^a-zA-Z0-9 _.-]/g, "").trim().slice(0, 40) || "My Website";
}
function validPackage(s) {
  const v = String(s || "").trim();
  return /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,5}$/.test(v) ? v : null;
}
function run(cmd, args, cwd, onLine) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { cwd, env: process.env, shell: false });
    let out = "";
    p.stdout.on("data", d => { const s=d.toString(); out += s; onLine?.(s); });
    p.stderr.on("data", d => { const s=d.toString(); out += s; onLine?.(s); });
    p.on("error", reject);
    p.on("close", code => code === 0 ? resolve(out) : reject(new Error(out.slice(-5000) || `${cmd} exited ${code}`)));
  });
}
function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
    const a = path.join(src, ent.name), b = path.join(dst, ent.name);
    if (ent.isDirectory()) copyDir(a, b);
    else if (ent.isFile()) fs.copyFileSync(a, b);
  }
}
function safeResolve(base, entry) {
  const normalized = entry.replace(/\\/g, "/");
  if (normalized.startsWith("/") || /^[a-zA-Z]:/.test(normalized)) throw new Error("ZIP berisi path absolut yang tidak diizinkan");
  const dest = path.resolve(base, normalized);
  if (dest !== base && !dest.startsWith(base + path.sep)) throw new Error("ZIP berisi path traversal");
  return dest;
}
function extractZip(zipPath, destDir) {
  const maxBytes = Number(process.env.MAX_EXTRACTED_GB || 10) * 1024 ** 3;
  const maxFiles = Number(process.env.MAX_FILES || 10000);
  return new Promise((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true, decodeStrings: true }, (err, zip) => {
      if (err) return reject(err);
      let expanded = 0, count = 0, pending = 0, ended = false, failed = false;
      const finish = () => { if (ended && pending === 0 && !failed) resolve(); };
      const fail = e => { if (failed) return; failed = true; try { zip.close(); } catch {} reject(e); };
      zip.on("error", fail);
      zip.on("end", () => { ended = true; finish(); });
      zip.on("entry", entry => {
        if (failed) return;
        try {
          const mode = (entry.externalFileAttributes >>> 16) & 0xF000;
          if (mode === 0xA000) throw new Error("Symlink dalam ZIP tidak diizinkan");
          const out = safeResolve(destDir, entry.fileName);
          if (entry.fileName.endsWith("/")) {
            fs.mkdirSync(out, { recursive: true });
            zip.readEntry();
            return;
          }
          count++;
          expanded += Number(entry.uncompressedSize || 0);
          if (count > maxFiles) throw new Error("Jumlah file ZIP melewati batas");
          if (expanded > maxBytes) throw new Error("Ukuran hasil ekstraksi ZIP melewati batas server");
          fs.mkdirSync(path.dirname(out), { recursive: true });
          pending++;
          zip.openReadStream(entry, (e, stream) => {
            if (e) return fail(e);
            const ws = fs.createWriteStream(out, { flags: "wx" });
            stream.on("error", fail); ws.on("error", fail);
            ws.on("finish", () => { pending--; finish(); });
            stream.pipe(ws);
            zip.readEntry();
          });
        } catch (e) { fail(e); }
      });
      zip.readEntry();
    });
  });
}
function findIndex(webRoot) {
  const all = [];
  function walk(dir) {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(p);
      else if (ent.isFile()) all.push(p);
    }
  }
  walk(webRoot);
  let idx = all.find(p => path.basename(p).toLowerCase() === "index.html");
  if (!idx) {
    const html = all.filter(p => /\.html?$/i.test(p));
    if (html.length === 1) {
      idx = path.join(webRoot, "index.html");
      fs.copyFileSync(html[0], idx);
    }
  }
  return idx;
}
function patchProject(projectDir, appName, packageId) {
  const appGradle = path.join(projectDir, "app", "build.gradle");
  let gradle = fs.readFileSync(appGradle, "utf8");
  gradle = gradle.replace(/applicationId\s+"[^"]+"/, `applicationId "${packageId}"`);
  fs.writeFileSync(appGradle, gradle);
  const manifest = path.join(projectDir, "app", "src", "main", "AndroidManifest.xml");
  let xml = fs.readFileSync(manifest, "utf8").replace('android:label="Web2APK"', `android:label="${appName.replace(/&/g,"&amp;").replace(/"/g,"&quot;")}"`);
  fs.writeFileSync(manifest, xml);
  const javaDir = path.join(projectDir, "app", "src", "main", "java");
  const oldPkg = path.join(javaDir, "com", "web2apk", "converter");
  const newPkg = path.join(javaDir, ...packageId.split("."));
  fs.mkdirSync(path.dirname(newPkg), { recursive: true });
  fs.renameSync(oldPkg, newPkg);
  const java = path.join(newPkg, "MainActivity.java");
  let src = fs.readFileSync(java, "utf8").replace("package com.web2apk.converter;", `package ${packageId};`);
  fs.writeFileSync(java, src);
}
async function buildJob(job, filePath, kind, appName, packageId) {
  activeBuilds++;
  job.status = "processing"; job.log.push("Memulai proses...");
  const dir = path.join(JOBS, job.id);
  const project = path.join(dir, "project");
  try {
    const webRoot = path.join(dir, "site");
    fs.mkdirSync(webRoot, { recursive: true });
    if (kind === "zip") {
      job.log.push("Mengekstrak ZIP dengan pemeriksaan keamanan...");
      await extractZip(filePath, webRoot);
    } else {
      fs.copyFileSync(filePath, path.join(webRoot, "index.html"));
    }
    if (!findIndex(webRoot)) throw new Error("index.html tidak ditemukan. ZIP harus berisi index.html atau satu file HTML.");
    job.log.push("Menyiapkan proyek Android WebView...");
    copyDir(TEMPLATE, project);
    const assets = path.join(project, "app", "src", "main", "assets", "www");
    fs.rmSync(assets, { recursive: true, force: true });
    copyDir(webRoot, assets);
    patchProject(project, appName, packageId);
    job.log.push("Menjalankan Gradle. Proses ini memerlukan Android SDK dan JDK...");
    await run("gradle", ["--no-daemon", "assembleDebug"], project, s => {
      const lines=s.split(/\r?\n/).filter(Boolean);
      for(const line of lines.slice(-8)) job.log.push(line.slice(0,240));
      if(job.log.length>120) job.log=job.log.slice(-120);
    });
    const apk = path.join(project, "app", "build", "outputs", "apk", "debug", "app-debug.apk");
    if (!fs.existsSync(apk)) throw new Error("Build selesai tetapi file APK tidak ditemukan.");
    job.apk = apk; job.status = "done"; job.log.push("APK berhasil dibuat.");
  } catch (e) {
    job.status = "error"; job.error = e.message; job.log.push("ERROR: "+e.message);
  } finally {
    activeBuilds--;
    try { fs.rmSync(filePath, { force: true }); } catch {}
  }
}
app.get("/api/config", (req,res)=>res.json({
  maxUploadGB:Number(process.env.MAX_UPLOAD_GB||183),
  maxExtractedGB:Number(process.env.MAX_EXTRACTED_GB||10),
  maxBuilds,
  premium:{priceIDR:20000,handle:"ziptros_635",unlimited:true}
}));
app.post("/api/build", upload.single("project"), async (req,res)=>{
  if(!req.file) return res.status(400).json({error:"Pilih file ZIP atau HTML terlebih dahulu."});
  if(activeBuilds>=maxBuilds){fs.rmSync(req.file.path,{force:true});return res.status(429).json({error:"Antrean build sedang penuh. Coba lagi nanti."});}
  const ext=path.extname(req.file.originalname).toLowerCase();
  const kind=ext===".zip"?"zip":(ext===".html"||ext===".htm"?"html":null);
  if(!kind){fs.rmSync(req.file.path,{force:true});return res.status(400).json({error:"Format yang didukung hanya .zip, .html, dan .htm"});}
  const packageId=validPackage(req.body.packageId||"com.web2apk.converted");
  if(!packageId){fs.rmSync(req.file.path,{force:true});return res.status(400).json({error:"Package ID tidak valid. Contoh: com.nama.aplikasi"});}
  const id=crypto.randomBytes(8).toString("hex");
  const job={id,status:"queued",log:[],error:null,apk:null,createdAt:Date.now()};
  jobs.set(id,job);
  res.json({id,status:"queued"});
  buildJob(job,req.file.path,kind,cleanName(req.body.appName),packageId);
});
app.get("/api/jobs/:id",(req,res)=>{
  const j=jobs.get(req.params.id);if(!j)return res.status(404).json({error:"Job tidak ditemukan"});
  res.json({id:j.id,status:j.status,log:j.log.slice(-40),error:j.error,downloadUrl:j.status==="done"?`/api/jobs/${j.id}/download`:null});
});
app.get("/api/jobs/:id/download",(req,res)=>{
  const j=jobs.get(req.params.id);if(!j||j.status!=="done"||!j.apk||!fs.existsSync(j.apk))return res.status(404).json({error:"APK belum siap"});
  res.download(j.apk,"gsk-converted-app.apk");
});
app.get("/api/health",(req,res)=>res.json({ok:true,gradle: "build-on-server"}));
app.listen(PORT,"0.0.0.0",()=>console.log(`ZIP/HTML to APK berjalan di http://0.0.0.0:${PORT}`));
