/* ============================================================
   LAKSHYA — all-in-one study companion
   Vanilla JS · offline · data localStorage me (sirf is phone me)
   ============================================================ */
(() => {
'use strict';

/* ---------- tiny helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const pad = n => String(n).padStart(2, '0');
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseD = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (s, n) => { const d = parseD(s); d.setDate(d.getDate() + n); return iso(d); };
const dayDiff = (a, b) => Math.round((parseD(b) - parseD(a)) / 864e5);
const dowOf = s => (parseD(s).getDay() + 6) % 7;            // Mon=0 … Sun=6
const weekStart = s => addDays(s, -dowOf(s));
const DOW = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const fmtD = s => { const d = parseD(s); return d.getDate() + ' ' + MON[d.getMonth()]; };
const num = v => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };
const toInt = v => Math.max(0, parseInt(v, 10) || 0);
const f2 = n => { n = Math.round(n * 100) / 100; return n === 0 ? 0 : n; };
const f1 = n => { n = Math.round(n * 10) / 10; return n === 0 ? 0 : n; };
const pct = (a, b) => b ? Math.round(a / b * 100) : 0;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sum = (a, f = x => x) => a.reduce((s, x) => s + f(x), 0);
const hexa = (h, a) => { const n = parseInt(h.slice(1), 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; };
const darken = (h, f) => { const n = parseInt(h.slice(1), 16); const c = v => Math.round(v * (1 - f)).toString(16).padStart(2, '0'); return '#' + c(n >> 16 & 255) + c(n >> 8 & 255) + c(n & 255); };
const countBy = (arr, fn) => arr.reduce((o, x) => { const k = fn(x); o[k] = (o[k] || 0) + 1; return o; }, {});
const fmtDur = s => { s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return h ? `${h}h ${m}m` : m ? `${m}m` : `${s}s`; };
const fmtHrs = s => f1(s / 3600) + 'h';
const clock = (s, up) => { s = Math.max(0, up ? Math.ceil(s) : Math.floor(s)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + pad(m) : pad(m)) + ':' + pad(x); };
const to12 = t => { if (!t) return ''; const [h, m] = t.split(':').map(Number); return `${h % 12 || 12}:${pad(m)} ${h < 12 ? 'AM' : 'PM'}`; };
const toMin = t => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const nowHM = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };

/* ---------- icons ---------- */
const IC = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  plan: '<rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17M9 15l2 2 4-4"/>',
  focus: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 9.5v4l2.5 1.5M9.5 3h5"/>',
  syl: '<path d="M12 3L3 8l9 5 9-5z"/><path d="M3 12.5l9 5 9-5"/><path d="M3 17l9 5 9-5"/>',
  test: '<rect x="5" y="4" width="14" height="17" rx="3"/><path d="M9 3h6v3H9zM9 13l2 2 4-4"/>',
  grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="2"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="2"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  check: '<path d="M5 13l4 4L19 7"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  next: '<path d="M9 5l7 7-7 7"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
  moon: '<path d="M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z"/>',
  undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 010 12h-3"/>',
  play: '<path d="M7 4.5v15l12-7.5z" fill="currentColor"/>',
  pause: '<rect x="6" y="4.5" width="4" height="15" rx="1.2" fill="currentColor"/><rect x="14" y="4.5" width="4" height="15" rx="1.2" fill="currentColor"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2.5" fill="currentColor"/>',
  flame: '<path d="M12 3c1 3 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z"/>',
  star: '<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1.1 5.8L12 16.8 6.7 19.6l1.1-5.8L3.5 9.7l5.9-.8z"/>',
  cards: '<rect x="3.5" y="7" width="13" height="13" rx="2.5"/><path d="M7.5 4h11a2 2 0 012 2v11"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  book: '<path d="M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2z"/><path d="M4 19V5M9 7h6"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
  trophy: '<path d="M7 4h10v5a5 5 0 01-10 0zM7 6H4v2a3 3 0 003 3M17 6h3v2a3 3 0 01-3 3M12 14v4M8 21h8M9 18h6"/>',
  palette: '<path d="M12 3a9 9 0 100 18c1.2 0 1.8-.9 1.4-2-.4-1.1.2-2 1.4-2H17a4 4 0 004-4c0-5-4-10-9-10z"/><circle cx="7.5" cy="11" r="1" fill="currentColor"/><circle cx="10" cy="7" r="1" fill="currentColor"/><circle cx="15" cy="7.5" r="1" fill="currentColor"/>',
  down: '<path d="M12 4v12M7 11l5 5 5-5M5 20h14"/>',
  up: '<path d="M12 16V4M7 9l5-5 5 5M5 20h14"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  habit: '<path d="M4 12a8 8 0 0114-5.3L20 9M20 12a8 8 0 01-14 5.3L4 15"/><path d="M20 4v5h-5M4 20v-5h5"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  note: '<rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  table: '<rect x="3.5" y="4.5" width="17" height="15" rx="3"/><path d="M3.5 10h17M9.5 10v9.5"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  archive: '<rect x="3" y="4" width="18" height="4.5" rx="1.5"/><path d="M5 8.5V19a1 1 0 001 1h12a1 1 0 001-1V8.5M10 12.5h4"/>',
  wand: '<path d="M5 19L17 7M14 4l1 2.5L17.5 7.5 15 8.5 14 11l-1-2.5L10.5 7.5 13 6.5zM6 4l.6 1.4L8 6l-1.4.6L6 8l-.6-1.4L4 6l1.4-.6z"/>'
};
const icon = (n, s = 22) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${IC[n] || ''}</svg>`;

/* ---------- presets ---------- */
const KEY = 'lakshya.v2', OLDKEY = 'mtsTracker.v1';
const P_MTS = [
  ['ga', 'General Awareness', 'GA', '🌍', '#f5a524', true, ['History – Ancient', 'History – Medieval', 'History – Modern & Freedom Struggle*', 'Geography – India*', 'Geography – World', 'Indian Polity & Constitution*', 'Indian Economy', 'Physics', 'Chemistry', 'Biology & Human Body*', 'Books & Authors', 'Awards & Honours', 'Sports', 'Important Days & Themes', 'Capitals, Currencies & Organisations', 'Current Affairs (last 6 months)*', 'Science & Technology', 'Art & Culture', 'Govt. Schemes', 'Environment & Ecology', 'Miscellaneous GK']],
  ['eng', 'English', 'English', '✍️', '#2dd4bf', true, ['Synonyms*', 'Antonyms*', 'One Word Substitution*', 'Idioms & Phrases*', 'Spelling Error', 'Error Spotting*', 'Sentence Improvement', 'Fill in the Blanks*', 'Active / Passive Voice', 'Direct / Indirect Speech', 'Cloze Test', 'Reading Comprehension', 'Para Jumbles', 'Tenses', 'Prepositions', 'Articles & Determiners', 'Subject-Verb Agreement', 'Vocabulary (Misc)']],
  ['math', 'Maths', 'Maths', '🧮', '#a78bfa', false, ['Number System', 'Simplification & BODMAS', 'Percentage', 'Ratio & Proportion', 'Average', 'Profit & Loss', 'Simple & Compound Interest', 'Time & Work', 'Time, Speed & Distance', 'Algebra', 'Geometry', 'Mensuration', 'Data Interpretation', 'Fractions & Decimals']],
  ['reas', 'Reasoning', 'Reasoning', '🧠', '#fb7185', false, ['Number / Alphabet Series', 'Analogy', 'Classification (Odd one out)', 'Coding-Decoding', 'Blood Relations', 'Direction Sense', 'Venn Diagram', 'Order & Ranking', 'Non-Verbal / Figures', 'Mathematical Operations', 'Syllogism', 'Calendar & Clock']]
];
const mkTopic = (sid, name, imp) => ({ id: uid() + Math.random().toString(36).slice(2, 4), sid, name, imp: !!imp, status: 'todo', conf: 0, rev: 0, last: '', due: '', notes: '', created: Date.now() });
function buildPreset() {
  const subjects = [], topics = [];
  P_MTS.forEach(([id, name, short, emoji, color, merit, list]) => {
    subjects.push({ id, name, short, emoji, color, merit, archived: false });
    list.forEach(n => { const imp = n.endsWith('*'); topics.push(mkTopic(id, imp ? n.slice(0, -1) : n, imp)); });
  });
  return { subjects, topics };
}
const REASONS = {
  forgot: { label: 'Padha tha, yaad nahi aaya', short: 'Yaad nahi', color: '#fbbf24', ico: '🧠', fix: 'Notes/flashcards se roz dohrao (spaced revision).' },
  silly: { label: 'Silly mistake', short: 'Silly', color: '#f87171', ico: '🤦', fix: 'Question poora padho, NOT/EXCEPT check karo, mark karne se pehle option dobara dekho.' },
  notstudied: { label: 'Topic padha hi nahi', short: 'Padha nahi', color: '#a78bfa', ico: '📕', fix: 'Ye topic syllabus me pehle cover karo, phir PYQ practice.' },
  confused: { label: '2 options me confuse', short: 'Confuse', color: '#60a5fa', ico: '🔀', fix: 'Concept clear karo aur milte-julte facts ka compare table banao.' },
  guess: { label: 'Tukka galat laga', short: 'Tukka', color: '#2dd4bf', ico: '🎲', fix: 'Elimination use karo; sure na ho to skip karo (negative marking bachegi).' },
  time: { label: 'Time nahi mila', short: 'Time', color: '#94a3b8', ico: '⏱', fix: 'Sectional timed tests do. Easy questions pehle, GA/English jaldi nipta lo.' }
};
const REASON_KEYS = Object.keys(REASONS);
const STAT = { todo: { label: 'Baaki', ico: '○' }, learning: { label: 'Padh rahe', ico: '◐' }, done: { label: 'Complete', ico: '●' } };
const INTS = [1, 3, 7, 14, 30, 60];          // topic revision gaps (days)
const BOX = [1, 3, 7, 14, 30];               // mistake-card gaps (days)
const TEST_TYPES = ['Full Mock', 'Sectional', 'Topic Test', 'PYQ', 'Quiz'];
const EMOJIS = ['📘', '📗', '📕', '🌍', '🧮', '🧠', '🔬', '⚗️', '🧬', '🏛', '💰', '🗣', '✍️', '📐', '⚽', '🎨', '💻', '⚖️', '🧪', '📰'];
const COLORS = ['#f5a524', '#2dd4bf', '#a78bfa', '#fb7185', '#60a5fa', '#34d399', '#f472b6', '#fbbf24', '#fb923c', '#22d3ee'];
const QUOTES = ['Roz thoda sa, par roz: yahi jeet ki chaabi hai.', 'Mock me galti karna fail hona nahi, sikhna hai.', 'Aaj ki mehnat, kal ka selection.', 'Discipline motivation se bada hota hai.', 'Ek ek topic, ek ek din: syllabus khatam ho jayega.', 'Jo aaj revise karta hai, wo exam me bhoolta nahi.', 'Silly mistakes hi merit se door rakhti hain. Dhyan se padho.', 'Chhote steps bhi manzil tak pahunchate hain.', 'Phone side me, focus on. Sirf 25 minute.', 'Kal ke khud se behtar bano, dusron se tulna mat karo.', 'Consistency > Intensity.', 'Sapne wo nahi jo neend me aaye, wo hain jo neend na aane de.'];
const TITLES = ['Beginner 🌱', 'Learner 📘', 'Achiever ⭐', 'Warrior ⚔️', 'Scholar 🎓', 'Master 🏅', 'Legend 👑'];
const THEMES = [
  { id: 'midnight', name: 'Midnight', bg: '#0b0e17', acc: '#7c9cff', acc2: '#b18cff' },
  { id: 'amoled', name: 'AMOLED', bg: '#000000', acc: '#8b9dff', acc2: '#e879f9' },
  { id: 'aurora', name: 'Aurora', bg: '#07131a', acc: '#2dd4bf', acc2: '#8b5cf6' },
  { id: 'ocean', name: 'Ocean', bg: '#06101f', acc: '#38bdf8', acc2: '#6366f1' },
  { id: 'forest', name: 'Forest', bg: '#0a140f', acc: '#4ade80', acc2: '#a3e635' },
  { id: 'sunset', name: 'Sunset', bg: '#160d12', acc: '#fb923c', acc2: '#f43f5e' },
  { id: 'cyber', name: 'Cyber', bg: '#09090f', acc: '#a3e635', acc2: '#22d3ee' },
  { id: 'sakura', name: 'Sakura', light: true, bg: '#fdf2f6', acc: '#ec4899', acc2: '#a855f7' },
  { id: 'paper', name: 'Paper', light: true, bg: '#f6f1e7', acc: '#c2410c', acc2: '#dc2626' },
  { id: 'frost', name: 'Frost', light: true, bg: '#eef4fb', acc: '#2563eb', acc2: '#7c3aed' }
];
const ACCENTS = [['#7c9cff', '#b18cff'], ['#2dd4bf', '#22d3ee'], ['#34d399', '#a3e635'], ['#fbbf24', '#fb7185'], ['#fb923c', '#f43f5e'], ['#f472b6', '#a78bfa'], ['#e879f9', '#6366f1'], ['#38bdf8', '#2dd4bf']];

/* ---------- state ---------- */
const defaults = () => ({
  v: 2,
  profile: { name: '', exam: 'SSC MTS', examDate: '', dailyGoal: 240, streakMin: 30, dayStart: 0, target: 0, onboarded: false },
  subjects: [], topics: [], tests: [], mistakes: [], sessions: [], tasks: [], blocks: [], habits: [],
  revLog: {}, timer: null, cyc: { date: '', n: 0 }, badges: {}, lvl: 0, lastSid: '',
  settings: {
    theme: 'midnight', accent: '', card: 'soft', radius: 'normal', font: 'default', fs: 'm', density: 'cozy', nav: 'float', motion: 'full',
    haptics: true, sound: true, wake: true, correct: 1, negative: 0.25,
    pomo: { focus: 25, short: 5, long: 15, every: 4, autoBreak: true }
  }
});
const migrate = d => {
  const b = defaults(), s = { ...b, ...d };
  s.profile = { ...b.profile, ...(d.profile || {}) };
  const ds = d.settings || {};
  s.settings = { ...b.settings, ...ds, pomo: { ...b.settings.pomo, ...(ds.pomo || {}) } };
  ['subjects', 'topics', 'tests', 'mistakes', 'sessions', 'tasks', 'blocks', 'habits'].forEach(k => { if (!Array.isArray(s[k])) s[k] = []; });
  s.revLog = d.revLog || {}; s.badges = d.badges || {}; s.cyc = d.cyc || { date: '', n: 0 };
  return s;
};
function fromV1(o) {                                   // purane "MTS Tracker" ka data
  const s = defaults(), pr = buildPreset();
  s.subjects = pr.subjects; s.topics = pr.topics; s.profile.onboarded = true;
  const os = o.settings || {};
  s.profile.examDate = os.examDate || ''; s.profile.target = os.target || 0;
  s.settings.correct = os.correct ?? 1; s.settings.negative = os.negative ?? 0.25;
  s.settings.theme = os.theme === 'light' ? 'frost' : 'midnight'; s.settings.haptics = os.haptics !== false;
  s.settings.motion = os.lite ? 'lite' : 'full';
  if (os.merit) s.subjects.forEach(x => { if (x.id in os.merit) x.merit = !!os.merit[x.id]; });
  const find = (sid, name) => {
    let t = s.topics.find(x => x.sid === sid && (x.name === name || x.name.startsWith(name)));
    if (!t) { t = mkTopic(sid, name); s.topics.push(t); } return t;
  };
  const tmap = {};
  (o.tests || []).forEach(t => { s.tests.push({ id: t.id, name: t.name, date: t.date, type: 'Full Mock', mins: 0, created: t.created || Date.now(), sections: t.sections || {}, demo: !!t.demo }); tmap[t.id] = 1; });
  const td = iso(new Date());
  (o.mistakes || []).forEach(m => {
    const t = find(m.sec, m.topic);
    s.mistakes.push({ id: m.id, testId: m.testId || null, sid: m.sec, tid: t.id, tn: m.topic, kind: m.kind, reason: m.reason, q: m.q || '', ans: m.ans || '', created: m.created || Date.now(), box: 0, due: td, done: !!m.done, demo: !!m.demo });
  });
  s.revLog = o.revLog || {};
  return s;
}
function load() {
  try { const raw = localStorage.getItem(KEY); if (raw) return migrate(JSON.parse(raw)); } catch (e) { /* ignore */ }
  try { const old = localStorage.getItem(OLDKEY); if (old) return fromV1(JSON.parse(old)); } catch (e) { /* ignore */ }
  return defaults();
}
let S = load();

/* ---------- save + memo ---------- */
let M = {}, saveT = 0;
const dirty = () => { M = {}; };
const memo = (k, fn) => k in M ? M[k] : (M[k] = fn());
function flushSave() { clearTimeout(saveT); saveT = 0; try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { toast('Storage full ho gaya, backup le lo', 'bad'); } }
function save() { dirty(); clearTimeout(saveT); saveT = setTimeout(flushSave, 250); }
addEventListener('pagehide', flushSave);
document.addEventListener('visibilitychange', () => { if (document.hidden) flushSave(); });

/* ---------- dates (din kab badalta hai: setting) ---------- */
const dayShift = () => (S.profile.dayStart || 0) * 36e5;
const today = () => iso(new Date(Date.now() - dayShift()));
const dateOf = ts => iso(new Date(ts - dayShift()));

/* ---------- subjects / topics ---------- */
const ghostSub = { id: '', name: 'General', short: 'General', emoji: '📚', color: '#8b95ae', merit: false };
const sub = id => S.subjects.find(s => s.id === id) || ghostSub;
const short = s => s.short || s.name.slice(0, 10);
const activeSubs = () => S.subjects.filter(s => !s.archived);
const meritIds = all => S.subjects.filter(s => s.merit && (all || !s.archived)).map(s => s.id);
const topicsOf = sid => S.topics.filter(t => t.sid === sid);
const topic = id => S.topics.find(t => t.id === id);
const tName = m => (topic(m.tid) || {}).name || m.tn || 'Unknown';
const isDue = t => t.status === 'done' && !!t.due && t.due <= today();
const tint = c => `background:${hexa(c, .16)};color:${c}`;
const subBadge = id => { const s = sub(id); return `<span class="badge" style="${tint(s.color)}">${s.emoji} ${esc(short(s))}</span>`; };
function subProg(sid) {
  const ts = topicsOf(sid), c = { todo: 0, learning: 0, done: 0 };
  ts.forEach(t => c[t.status]++);
  const n = ts.length;
  return { n, ...c, pct: n ? Math.round((c.done + c.learning * .5) / n * 100) : 0, revised: ts.filter(t => t.rev > 0).length, due: ts.filter(isDue).length };
}
function setStatus(t, st) {
  if (t.status === st) return;
  t.status = st;
  if (st === 'done') { t.doneOn = today(); schedRev(t); } else { t.due = ''; if (st === 'todo') { t.rev = 0; t.doneOn = ''; } }
}
function schedRev(t) { t.due = t.rev >= INTS.length ? '' : addDays(today(), INTS[t.rev]); }
function markRevised(t) { t.rev++; t.last = today(); if (t.status !== 'done') t.status = 'done'; schedRev(t); S.revLog[today()] = (S.revLog[today()] || 0) + 1; }

/* ---------- spaced repetition (mistake cards) ---------- */
const cardDue = m => !m.done && (!m.due || m.due <= today());
function srGood(m) { const b = m.box || 0; m.lastRev = today(); if (b + 1 >= 5) { m.box = 5; m.done = true; m.due = ''; } else { m.box = b + 1; m.due = addDays(today(), BOX[b]); } }
function srHard(m) { m.due = addDays(today(), 2); m.lastRev = today(); }
function srAgain(m) { m.box = 0; m.done = false; m.due = addDays(today(), 1); m.lastRev = today(); }

/* ---------- study time / streak / xp ---------- */
const totalSecs = () => memo('ts', () => sum(S.sessions, x => x.secs));
const dayMap = () => memo('dm', () => { const m = {}; S.sessions.forEach(x => { m[x.date] = (m[x.date] || 0) + x.secs; }); return m; });
const dayMins = d => Math.floor((dayMap()[d] || 0) / 60);
const secsBySub = () => memo('sbs', () => { const m = {}; S.sessions.forEach(x => { m[x.sid || ''] = (m[x.sid || ''] || 0) + x.secs; }); return m; });
const secsByTopic = () => memo('sbt', () => { const m = {}; S.sessions.forEach(x => { if (x.tid) m[x.tid] = (m[x.tid] || 0) + x.secs; }); return m; });
const streakInfo = () => memo('st', () => {
  const dm = dayMap(), need = Math.max(1, S.profile.streakMin) * 60, ok = d => (dm[d] || 0) >= need;
  let cur = 0, d = today(); if (!ok(d)) d = addDays(d, -1);
  while (ok(d) && cur < 4000) { cur++; d = addDays(d, -1); }
  let best = 0, run = 0, prev = null;
  Object.keys(dm).filter(ok).sort().forEach(x => { run = prev && dayDiff(prev, x) === 1 ? run + 1 : 1; if (run > best) best = run; prev = x; });
  return { cur, best: Math.max(best, cur) };
});
function habitStreak(h) {
  let cur = 0, d = today(); if (!h.days[d]) d = addDays(d, -1);
  while (h.days[d] && cur < 4000) { cur++; d = addDays(d, -1); }
  let best = 0, run = 0, prev = null;
  Object.keys(h.days).sort().forEach(x => { run = prev && dayDiff(prev, x) === 1 ? run + 1 : 1; if (run > best) best = run; prev = x; });
  return { cur, best: Math.max(best, cur) };
}
const xpTotal = () => memo('xp', () => Math.floor(totalSecs() / 60) + S.tests.length * 30 + S.topics.filter(t => t.status === 'done').length * 15 + sum(S.topics, t => t.rev) * 10 + S.tasks.filter(t => t.done).length * 8 + sum(S.habits, h => Object.keys(h.days).length) * 5 + sum(Object.values(S.revLog)) * 3);
function lvlInfo() { const x = xpTotal(), L = Math.floor(Math.sqrt(x / 60)) + 1, lo = 60 * (L - 1) ** 2, hi = 60 * L * L; return { L, x, lo, hi, p: clamp((x - lo) / (hi - lo), 0, 1), title: TITLES[Math.min(TITLES.length - 1, Math.floor((L - 1) / 2))] }; }

/* ---------- tests / marks ---------- */
const mc = () => num(S.settings.correct), ng = () => num(S.settings.negative);
const sortedTests = () => [...S.tests].sort((a, b) => a.date === b.date ? a.created - b.created : (a.date < b.date ? -1 : 1));
function secStat(s) {
  const skip = Math.max(0, s.total - s.correct - s.wrong), att = s.correct + s.wrong;
  return { total: s.total, correct: s.correct, wrong: s.wrong, skip, att, acc: att ? s.correct / att * 100 : 0, attPct: s.total ? att / s.total * 100 : 0, score: s.correct * mc() - s.wrong * ng(), max: s.total * mc() };
}
function testStat(t) {
  const secs = {}, M_ = new Set(meritIds(true)); let merit = 0, meritMax = 0, total = 0, totalMax = 0;
  for (const k in t.sections) { const st = secStat(t.sections[k]); secs[k] = st; total += st.score; totalMax += st.max; if (M_.has(k)) { merit += st.score; meritMax += st.max; } }
  return { secs, merit, meritMax, total, totalMax };
}
function headScore(t) { const st = testStat(t); return st.meritMax > 0 ? { score: st.merit, max: st.meritMax, label: 'Merit' } : { score: st.total, max: st.totalMax, label: 'Total' }; }
function agg(tests, keys) {
  const a = { total: 0, correct: 0, wrong: 0, skip: 0, att: 0, score: 0, max: 0, n: tests.length };
  tests.forEach(t => keys.forEach(k => { const s = t.sections[k]; if (!s) return; const st = secStat(s); a.total += st.total; a.correct += st.correct; a.wrong += st.wrong; a.skip += st.skip; a.att += st.att; a.score += st.score; a.max += st.max; }));
  a.acc = a.att ? a.correct / a.att * 100 : 0; a.attPct = a.total ? a.att / a.total * 100 : 0;
  return a;
}
const loggedCount = (tid, sid, kind) => S.mistakes.filter(m => m.testId === tid && m.sid === sid && m.kind === kind).length;
function logProgress(t) {
  let need = 0, got = 0;
  for (const k in t.sections) { const st = secStat(t.sections[k]); need += st.wrong + st.skip; got += Math.min(st.wrong, loggedCount(t.id, k, 'wrong')) + Math.min(st.skip, loggedCount(t.id, k, 'skip')); }
  return { need, got };
}
const mistakesByTopic = () => memo('mbt', () => { const m = {}; S.mistakes.forEach(x => { if (!x.tid) return; const o = m[x.tid] || (m[x.tid] = { n: 0, p: 0 }); o.n++; if (!x.done) o.p++; }); return m; });
function topWeak(ms, n) {
  const g = {};
  ms.forEach(m => { const k = m.sid + '|' + (m.tid || m.tn); const o = g[k] || (g[k] = { sid: m.sid, tid: m.tid, name: tName(m), n: 0, r: {} }); o.n++; o.r[m.reason] = (o.r[m.reason] || 0) + 1; });
  return Object.values(g).sort((a, b) => b.n - a.n).slice(0, n).map(x => ({ ...x, top: Object.entries(x.r).sort((a, b) => b[1] - a[1])[0][0] }));
}
function focusAreas(n) {
  const mb = mistakesByTopic(), ms = new Set(meritIds()), rows = [];
  S.topics.forEach(t => {
    if (sub(t.sid).archived) return;
    const p = (mb[t.id] || {}).p || 0;
    if (t.status === 'done' && !p) return;
    let sc = 0; const why = [];
    if (p) { sc += p * 3; why.push(p + ' galtiyan'); }
    if (t.status === 'todo') { sc += 2; why.push('padha nahi'); } else if (t.status === 'learning') { sc += 1; why.push('adhoora'); }
    if (t.imp) { sc += 2; why.push('⭐ important'); }
    if (t.conf && t.conf <= 2) { sc += 4 - t.conf; why.push('confidence kam'); }
    if (ms.has(t.sid)) sc *= 1.4;
    if (sc > 0) rows.push({ t, sc, why });
  });
  return rows.sort((a, b) => b.sc - a.sc).slice(0, n);
}

/* ---------- badges ---------- */
const bestAcc = () => Math.max(0, ...S.tests.map(t => { const a = agg([t], Object.keys(t.sections)); return a.acc; }));
const BADGES = [
  ['first', '🚀', 'Shuruaat', 'Pehla focus session', () => [S.sessions.length, 1]],
  ['h10', '⏳', '10 Ghante', 'Total 10 ghante padhai', () => [totalSecs() / 3600, 10]],
  ['h50', '🔥', '50 Ghante', 'Total 50 ghante padhai', () => [totalSecs() / 3600, 50]],
  ['h100', '💎', '100 Ghante', 'Total 100 ghante padhai', () => [totalSecs() / 3600, 100]],
  ['h250', '👑', '250 Ghante', 'Total 250 ghante padhai', () => [totalSecs() / 3600, 250]],
  ['s3', '📅', '3 Din Streak', 'Lagatar 3 din goal', () => [streakInfo().best, 3]],
  ['s7', '🗓', '7 Din Streak', 'Lagatar 7 din goal', () => [streakInfo().best, 7]],
  ['s30', '🏔', '30 Din Streak', 'Lagatar 30 din goal', () => [streakInfo().best, 30]],
  ['t1', '📝', 'Pehla Test', 'Pehla mock test add karo', () => [S.tests.length, 1]],
  ['t5', '📚', '5 Tests', '5 mock tests complete', () => [S.tests.length, 5]],
  ['t15', '🎯', '15 Tests', '15 mock tests complete', () => [S.tests.length, 15]],
  ['t30', '🏆', '30 Tests', '30 mock tests complete', () => [S.tests.length, 30]],
  ['acc', '🎖', '80% Accuracy', 'Kisi test me 80%+ accuracy', () => [bestAcc(), 80]],
  ['top10', '✅', '10 Topics', '10 topics complete', () => [S.topics.filter(t => t.status === 'done').length, 10]],
  ['top30', '🌟', '30 Topics', '30 topics complete', () => [S.topics.filter(t => t.status === 'done').length, 30]],
  ['rev25', '🔁', '25 Revisions', 'Topics/cards 25 baar revise', () => [sum(S.topics, t => t.rev) + sum(Object.values(S.revLog)), 25]],
  ['task25', '☑️', '25 Tasks', '25 planner tasks complete', () => [S.tasks.filter(t => t.done).length, 25]],
  ['hab7', '🌱', 'Habit Hero', 'Kisi habit ki 7 din streak', () => [Math.max(0, ...S.habits.map(h => habitStreak(h).best)), 7]],
  ['early', '🌅', 'Early Bird', 'Subah 6 baje se pehle session', () => [S.sessions.some(x => !x.manual && new Date(x.ts).getHours() < 6) ? 1 : 0, 1]],
  ['owl', '🦉', 'Night Owl', 'Raat 11 baje ke baad session', () => [S.sessions.some(x => !x.manual && new Date(x.ts).getHours() >= 23) ? 1 : 0, 1]],
  ['mara', '🏃', 'Marathon', 'Ek session me 2 ghante', () => [Math.max(0, ...S.sessions.map(x => x.secs)) / 60, 120]],
  ['lv5', '⭐', 'Level 5', 'Level 5 tak pahuncho', () => [lvlInfo().L, 5]]
];
function checkProgress(silent) {
  let ch = false;
  BADGES.forEach(b => { const [c, t] = b[4](); if (c >= t && !S.badges[b[0]]) { S.badges[b[0]] = today(); ch = true; if (!silent) toast(`🏆 Badge mila: ${b[2]}`, 'ok'); } });
  const L = lvlInfo().L;
  if (L > (S.lvl || 0)) { if (!silent && S.lvl > 0) toast(`⬆️ Level ${L} unlock ho gaya!`, 'ok'); S.lvl = L; ch = true; }
  if (ch) save();
}

/* ---------- theme engine ---------- */
function applyTheme() {
  const st = S.settings, th = THEMES.find(t => t.id === st.theme) || THEMES[0], r = document.documentElement;
  r.dataset.theme = th.id;
  ['card', 'radius', 'font', 'fs', 'density', 'nav', 'motion'].forEach(k => { r.dataset[k] = st[k]; });
  const [a, b] = st.accent ? st.accent.split(',') : [th.acc, th.acc2];
  const sp = (k, v) => r.style.setProperty(k, v);
  sp('--acc', a); sp('--acc2', b); sp('--acc-t', th.light ? darken(a, .32) : a); sp('--acc-soft', hexa(a, th.light ? .12 : .16)); sp('--glow', hexa(a, th.light ? .14 : .17));
  const m = $('meta[name="theme-color"]'); if (m) m.content = th.bg;
}

/* ============ UI INFRA: toast, layers (back button), sheets, charts, router ============ */
const UI = {
  pl: { date: '' }, tt: { day: 0 }, fc: { sid: '', tid: '', free: false },
  sf: { f: 'all', q: '' }, an: { sec: 'merit', range: '5' },
  nb: { status: 'due', sid: 'all', reason: 'all', tid: '', q: '', limit: 40 },
  st: { range: 'week' }, tf: { type: 'all' }, ob: { step: 0, preset: 'mts', name: '', exam: 'SSC MTS', date: '', goal: 240, theme: 'midnight' }
};

let toastT;
function toast(msg, type) {
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.className = 'show ' + (type || '');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2400);
}
const haptic = (ms = 8) => { if (S.settings.haptics && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) { /* ignore */ } } };
let AC = null;
function unlockAudio() { try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume(); } catch (e) { /* ignore */ } }
function beep() {
  if (!S.settings.sound || !AC) return;
  try { [0, .24, .48].forEach((d, i) => { const o = AC.createOscillator(), g = AC.createGain(); o.frequency.value = i === 2 ? 988 : 784; o.connect(g); g.connect(AC.destination); const t = AC.currentTime + d; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.18, t + .02); g.gain.exponentialRampToValueAtTime(.001, t + .22); o.start(t); o.stop(t + .24); }); } catch (e) { /* ignore */ }
}

/* ---------- layers: sheets / dialogs / overlays share the Android back button ---------- */
const layers = [];
let pendingAfter = null, navDepth = 0;
function pushLayer(fn) { layers.push(fn); try { history.pushState({ L: layers.length }, '', location.href); } catch (e) { /* ignore */ } }
function closeLayer(after) {
  if (!layers.length) { if (after) after(); return; }
  pendingAfter = after || null;
  history.back();
}
addEventListener('popstate', () => {
  if (layers.length) { const fn = layers.pop(); fn(); const a = pendingAfter; pendingAfter = null; if (a) a(); }
  else if (navDepth > 0) navDepth--;
});
function killLayers() { while (layers.length) { const fn = layers.pop(); fn(true); } pendingAfter = null; }

let sheetClean = 0;
function openSheet(title, body, footer) {
  const root = $('#sheetRoot'); clearTimeout(sheetClean);
  root.innerHTML = `<div class="backdrop" data-act="sheetClose"></div><div class="sheet" role="dialog" aria-label="${esc(title)}"><div class="sh-handle"><div class="grab"></div><div class="sh-head"><h3>${title}</h3><button class="ibtn" data-act="sheetClose" aria-label="Band karo">${icon('close', 20)}</button></div></div><div class="sh-body" id="shBody">${body}</div>${footer ? `<div class="sh-foot">${footer}</div>` : ''}</div>`;
  root.classList.remove('open');
  requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add('open')));
  pushLayer(instant => { root.classList.remove('open'); if (instant) root.innerHTML = ''; else sheetClean = setTimeout(() => { root.innerHTML = ''; }, 360); });
  bindDrag();
}
function bindDrag() {
  const sh = $('#sheetRoot .sheet'), hd = $('#sheetRoot .sh-handle'); if (!sh || !hd) return;
  let y0 = 0, dy = 0, on = false;
  hd.addEventListener('pointerdown', e => { if (e.target.closest('.ibtn')) return; on = true; y0 = e.clientY; dy = 0; sh.style.transition = 'none'; try { hd.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ } });
  hd.addEventListener('pointermove', e => { if (!on) return; dy = Math.max(0, e.clientY - y0); sh.style.transform = `translate(-50%,${dy}px)`; });
  const end = () => { if (!on) return; on = false; sh.style.transition = ''; sh.style.transform = ''; if (dy > 90) closeLayer(); };
  hd.addEventListener('pointerup', end); hd.addEventListener('pointercancel', end);
}
let dlgCb = null;
function confirmBox(title, msg, okText, cb, kind = 'danger') {
  dlgCb = cb;
  $('#dlgRoot').innerHTML = `<div class="dlg-bg"><div class="dlg"><h3>${title}</h3><p>${msg}</p><div class="btn-row"><button class="btn ghost" data-act="dlgNo">Cancel</button><button class="btn ${kind}" data-act="dlgYes">${okText}</button></div></div></div>`;
  pushLayer(() => { $('#dlgRoot').innerHTML = ''; });
}

/* ---------- charts (pure SVG, light on memory) ---------- */
let gid = 0;
function ring(p, o = {}) {
  p = clamp(p, 0, 100); const size = o.size || 86, sw = o.sw || 4.5, c = o.c || 'var(--acc)';
  return `<div class="ring" style="width:${size}px;height:${size}px"><svg viewBox="0 0 42 42"><circle cx="21" cy="21" r="15.915" fill="none" stroke="${o.track || 'var(--surface2)'}" stroke-width="${sw}"/>${p > 0 ? `<circle class="v" cx="21" cy="21" r="15.915" fill="none" stroke="${c}" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${p} ${100 - p}"/>` : ''}</svg><div class="rl">${o.label ?? `<b>${Math.round(p)}%</b>`}</div></div>`;
}
function donut(items, total, top, sub_) {
  let acc = 0;
  const segs = items.map(it => { const p = it.v / total * 100, w = Math.max(0, p - 0.8); const c = `<circle cx="21" cy="21" r="15.915" fill="none" stroke="${it.color}" stroke-width="6" stroke-dasharray="${w} ${100 - w}" stroke-dashoffset="${-acc}"/>`; acc += p; return c; }).join('');
  return `<div class="donut-wrap"><svg viewBox="0 0 42 42"><circle cx="21" cy="21" r="15.915" fill="none" stroke="var(--surface2)" stroke-width="6"/>${segs}</svg><div class="donut-c"><b>${top}</b><span>${sub_}</span></div></div>`;
}
function lineChart(vals, labels, color, o = {}) {
  if (!vals.length) return '<p class="muted small center">Data nahi hai</p>';
  const W = 320, H = 150, pl = 30, pr = 12, pt = 16, pb = 24, id = 'g' + (++gid);
  let mn = o.min !== undefined ? o.min : Math.min(...vals), mx = o.max !== undefined ? o.max : Math.max(...vals);
  if (o.min === undefined) { if (mx === mn) { mx += 1; mn -= 1; } const p = (mx - mn) * .12; mn -= p; mx += p; }
  const X = i => pl + (vals.length === 1 ? (W - pl - pr) / 2 : i * (W - pl - pr) / (vals.length - 1));
  const Y = v => pt + (H - pt - pb) * (1 - (v - mn) / (mx - mn));
  const pts = vals.map((v, i) => [X(i), Y(v)]);
  const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  const area = d + ` L${pts[pts.length - 1][0].toFixed(1)} ${H - pb} L${pts[0][0].toFixed(1)} ${H - pb} Z`;
  const grid = [0, .5, 1].map(f => { const v = mn + (mx - mn) * f, y = Y(v); return `<line class="gl" x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}"/><text x="${pl - 5}" y="${y + 3}" text-anchor="end">${Math.round(v)}</text>`; }).join('');
  const xl = labels.map((l, i) => (vals.length <= 8 || i === 0 || i === vals.length - 1 || i % 2 === 0) ? `<text x="${X(i)}" y="${H - 7}" text-anchor="middle">${l}</text>` : '').join('');
  const dots = pts.map(p => `<circle cx="${p[0]}" cy="${p[1]}" r="3.4" fill="${color}" stroke="var(--surface)" stroke-width="1.6"/>`).join('');
  const lp = pts[pts.length - 1], lv = o.fmt ? o.fmt(vals[vals.length - 1]) : f2(vals[vals.length - 1]);
  const tl = o.target !== undefined && o.target >= mn && o.target <= mx ? `<line x1="${pl}" x2="${W - pr}" y1="${Y(o.target)}" y2="${Y(o.target)}" stroke="var(--ok)" stroke-width="1" stroke-dasharray="4 3"/><text x="${W - pr}" y="${Y(o.target) - 3}" text-anchor="end" style="fill:var(--ok)">target</text>` : '';
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".32"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>${grid}${tl}<path d="${area}" fill="url(#${id})"/><path class="ln" pathLength="1" d="${d}" fill="none" stroke="${color}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>${dots}<text x="${Math.min(lp[0], W - 16)}" y="${lp[1] - 8}" text-anchor="${lp[0] > W - 30 ? 'end' : 'middle'}" style="fill:${color};font-weight:700;font-size:10px">${lv}</text>${xl}</svg>`;
}
function barChart(vals, labels, o = {}) {
  const W = 320, H = o.h || 150, pl = 6, pr = 6, pt = 18, pb = 22, n = vals.length;
  if (!n) return '<p class="muted small center">Data nahi hai</p>';
  const mx = Math.max(o.goal || 0, ...vals, 1), bw = (W - pl - pr) / n, gap = Math.min(7, bw * .3), ch = H - pt - pb;
  const bars = vals.map((v, i) => {
    const h = ch * v / mx, x = pl + i * bw + gap / 2, w = bw - gap, y = H - pb - h, col = o.colors ? o.colors[i] : (o.color || 'var(--acc)');
    const hi = o.hi === i;
    return `<rect class="bar" x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${Math.max(v ? 2 : 0, h).toFixed(1)}" rx="${Math.min(5, w / 2).toFixed(1)}" fill="${col}" opacity="${hi || o.hi === undefined ? 1 : .82}" style="animation-delay:${Math.min(i, 30) * 22}ms"/>` +
      (n <= 8 && v ? `<text x="${(x + w / 2).toFixed(1)}" y="${(y - 4).toFixed(1)}" text-anchor="middle" style="font-size:9px">${o.fmt ? o.fmt(v) : v}</text>` : '');
  }).join('');
  const step = n > 14 ? (n > 24 ? 5 : 2) : 1;
  const xl = labels.map((l, i) => (i % step === 0 || i === n - 1) && l !== '' ? `<text x="${(pl + i * bw + bw / 2).toFixed(1)}" y="${H - 6}" text-anchor="middle">${l}</text>` : '').join('');
  const gl = o.goal ? `<line x1="${pl}" x2="${W - pr}" y1="${H - pb - ch * o.goal / mx}" y2="${H - pb - ch * o.goal / mx}" stroke="var(--ok)" stroke-width="1" stroke-dasharray="4 3"/><text x="${W - pr}" y="${H - pb - ch * o.goal / mx - 3}" text-anchor="end" style="fill:var(--ok)">goal</text>` : '';
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img"><line class="gl" x1="${pl}" x2="${W - pr}" y1="${H - pb}" y2="${H - pb}"/>${gl}${bars}${xl}</svg>`;
}
function spark(vals, color) {
  if (vals.length < 2) return '';
  const W = 100, H = 30, mn = Math.min(...vals), mx = Math.max(...vals), r = mx - mn || 1;
  const d = vals.map((v, i) => (i ? 'L' : 'M') + (i * W / (vals.length - 1)).toFixed(1) + ' ' + (H - 3 - (v - mn) / r * (H - 6)).toFixed(1)).join(' ');
  return `<svg viewBox="0 0 ${W} ${H}" width="84" height="26" preserveAspectRatio="none"><path class="ln" pathLength="1" d="${d}" fill="none" stroke="${color}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}
function heatmap(weeks) {
  const td = today(), dm = dayMap(), goal = Math.max(1, S.profile.dailyGoal) * 60, start = addDays(weekStart(td), -(weeks - 1) * 7);
  let cells = '';
  for (let i = 0; i < weeks * 7; i++) {
    const d = addDays(start, i);
    if (d > td) { cells += '<i class="hm-x"></i>'; continue; }
    const s = dm[d] || 0, r = s / goal, o = !s ? 0 : r < .25 ? .28 : r < .5 ? .46 : r < 1 ? .72 : 1;
    cells += `<i class="${d === td ? 'hm-t' : ''}" style="${o ? `background:var(--acc);opacity:${o}` : ''}" title="${fmtD(d)}: ${fmtDur(s)}"></i>`;
  }
  return `<div class="hm" style="grid-template-columns:repeat(${weeks},1fr)">${cells}</div>`;
}
const stackBar = s => { const T = s.total || 1; return `<div class="stack"><i style="width:${s.correct / T * 100}%;background:var(--ok)"></i><i style="width:${s.wrong / T * 100}%;background:var(--bad)"></i><i style="width:${s.skip / T * 100}%;background:var(--skip)"></i></div>`; };

/* ---------- router / paint ---------- */
const META = {
  home: { t: 'Lakshya', tab: 'home' }, plan: { t: 'Planner', tab: 'plan', fab: 'task' }, focus: { t: 'Focus', tab: 'focus' },
  syllabus: { t: 'Syllabus', tab: 'syllabus', fab: 'subject' }, subject: { t: 'Subject', tab: 'syllabus', back: 'syllabus', fab: 'topic' },
  tests: { t: 'Mock Tests', tab: 'tests', fab: 'test' }, test: { t: 'Test Detail', tab: 'tests', back: 'tests', fab: 'mistake' },
  analysis: { t: 'Analysis', tab: 'tests' }, notebook: { t: 'Mistake Notebook', tab: 'tests', fab: 'note' },
  stats: { t: 'Stats', tab: 'home', back: 'home' }, habits: { t: 'Habits', tab: 'home', back: 'home', fab: 'habit' },
  timetable: { t: 'Weekly Timetable', tab: 'plan', back: 'plan', fab: 'block' }, badges: { t: 'Achievements', tab: 'home', back: 'home' },
  settings: { t: 'Settings', tab: 'home', back: 'home' }, look: { t: 'Appearance', tab: 'home', back: 'settings' }
};
let cur = { name: 'home', arg: null };
const page = html => `<div class="page">${html}</div>`;
const greet = () => { const h = new Date().getHours(); return h < 5 ? 'Raat ke jaagne wale' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 21 ? 'Good evening' : 'Good night'; };
const empty = (emoji, title, sub_, btns = '') => `<div class="card empty"><div class="big">${emoji}</div><h3>${title}</h3><p>${sub_}</p><div class="btn-row">${btns}</div></div>`;
const segTabs = on => `<div class="seg">${[['tests', 'Tests'], ['analysis', 'Analysis'], ['notebook', 'Notebook']].map(([k, l]) => `<button class="${on === k ? 'on' : ''}" data-act="goTab" data-k="${k}">${l}</button>`).join('')}</div>`;

function paint(anim = true) {
  const h = (location.hash || '#home').slice(1), [n, arg] = h.split('/');
  const name = ROUTES[n] ? n : 'home', m = META[name];
  cur = { name, arg };
  const view = $('#view');
  let html;
  try { html = ROUTES[name](arg); } catch (e) { console.error(e); html = `<div class="page"><div class="card"><h3>Oops 😅</h3><p class="muted small">Ye screen load nahi hui: ${esc(e.message)}</p><button class="btn ghost block" data-act="goHome">Home par jao</button></div></div>`; }
  view.innerHTML = html;
  const pg = view.firstElementChild;
  if (pg) { if (!anim) pg.classList.add('noanim'); else if (m.back) pg.classList.add('slide'); }
  if (anim) view.scrollTop = 0;
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.r === m.tab));
  let title = m.t;
  if (name === 'subject') title = sub(arg).name; else if (name === 'test') { const t = S.tests.find(x => x.id === arg); if (t) title = t.name; }
  $('#topTitle').textContent = title;
  $('#backBtn').classList.toggle('hidden', !m.back);
  $('#brand').classList.toggle('hidden', !!m.back);
  const hasFab = !!m.fab && !(name === 'subject' && !S.subjects.some(s => s.id === arg));
  $('#fab').classList.toggle('hidden', !hasFab);
  document.body.classList.toggle('noFab', !hasFab);
  animateCounts(); updateMini(); tickUI();
}
const render = keep => { const v = $('#view'), y = v.scrollTop; paint(!keep); if (keep) v.scrollTop = y; };
function go(h) { if (location.hash === '#' + h) { render(); return; } navDepth++; location.hash = h; }
function goTab(h) { if (location.hash === '#' + h) { render(); return; } location.replace('#' + h); }
function goBack() { const m = META[cur.name] || {}; if (navDepth > 0) { navDepth--; history.back(); } else location.replace('#' + (m.back || 'home')); }
function animateCounts() {
  if (S.settings.motion !== 'full') return;
  $$('[data-count]').forEach(el => {
    const end = Number(el.dataset.count); if (!end) return;
    const t0 = performance.now(), dur = 750; el.textContent = 0;
    const step = t => { const p = Math.min(1, (t - t0) / dur); el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  });
}

/* ============ HOME · PLANNER · TIMETABLE · HABITS ============ */
const dueTopics = () => S.topics.filter(t => isDue(t) && !sub(t.sid).archived);
const dueCards = () => S.mistakes.filter(cardDue);
const blocksOn = d => { const w = dowOf(d); return S.blocks.filter(b => b.days.includes(w)).sort((a, b) => a.start.localeCompare(b.start)); };
function blockNow() { const bl = blocksOn(today()), n = nowHM(); return { cur: bl.find(b => b.start <= n && n < b.end), next: bl.find(b => b.start > n) }; }
const blockRow = (b, now) => { const s = sub(b.sid); return `<div class="item tap" data-act="editBlock" data-id="${b.id}"><div class="ico" style="--c:${s.color}">${s.emoji}</div><div class="txt"><b>${esc(b.label || s.name)}</b><small>${to12(b.start)} – ${to12(b.end)} · ${fmtDur((toMin(b.end) - toMin(b.start)) * 60)}</small></div>${now ? '<span class="badge live">● ABHI</span>' : ''}</div>`; };

function taskRow(t, noPlay) {
  const s = t.sid ? sub(t.sid) : null;
  return `<div class="item ${t.done ? 'done' : ''}"><button class="chk ${t.done ? 'on' : ''}" data-act="taskDone" data-id="${t.id}" aria-label="Done">${t.done ? icon('check', 16) : ''}</button><div class="txt" data-act="editTask" data-id="${t.id}"><b>${esc(t.title)}</b><small>${s ? `${s.emoji} ${esc(short(s))}` : 'General'}${t.est ? ` · ${t.est}m` : ''}${t.time ? ` · ${to12(t.time)}` : ''}</small></div>${noPlay || t.done ? '' : `<button class="ibtn sm" data-act="taskFocus" data-id="${t.id}" aria-label="Start">${icon('play', 15)}</button>`}</div>`;
}

function V_home() {
  const td = today(), L = lvlInfo(), st = streakInfo(), pr = S.profile;
  const secs = dayMap()[td] || 0, mins = Math.floor(secs / 60), goal = Math.max(1, pr.dailyGoal), gp = clamp(mins / goal * 100, 0, 100);
  const dl = pr.examDate ? dayDiff(td, pr.examDate) : null;
  const remain = S.topics.filter(t => t.status !== 'done' && !sub(t.sid).archived).length;
  const dT = dueTopics().length, dC = dueCards().length;
  const pace = dl !== null && dl > 0 && remain ? `📖 ~${f1(remain / dl)} topics/din` : '';
  let h = `<section class="hero"><div class="hero-top"><div><p>${greet()}${pr.name ? ', ' + esc(pr.name) : ''} 👋</p><h2>${esc(pr.exam || 'Meri taiyari')}</h2></div>
    <button class="lvl" data-act="goBadges"><span>Lv ${L.L}</span><em>${L.title}</em><i><u style="transform:scaleX(${L.p.toFixed(3)})"></u></i></button></div>
    <div class="hero-mid"><div class="cd">${dl === null ? `<button data-act="goSettings">📅 Exam date set karo</button>` : dl > 0 ? `<b data-count="${dl}">${dl}</b><span>din baaki</span>` : dl === 0 ? '<b>🔥</b><span>Exam aaj hai!</span>' : '<b>✓</b><span>Exam ho chuka</span>'}</div>
    <div class="hring">${ring(gp, { size: 108, sw: 5, c: '#fff', track: 'rgba(255,255,255,.22)', label: `<b>${mins}</b><small>/ ${goal}m</small>` })}</div></div>
    <div class="hero-foot"><span>🔥 ${st.cur} din streak</span><span>⏱ Aaj ${fmtDur(secs)}</span>${pace ? `<span>${pace}</span>` : ''}</div></section>`;

  h += `<div class="qa"><button class="tile" data-act="goFocus"><span style="--c:var(--acc)">${icon('focus')}</span><em>Focus</em></button>
    <button class="tile" data-act="goPlan"><span style="--c:#34d399">${icon('plan')}</span><em>Plan</em></button>
    <button class="tile" data-act="fabTest"><span style="--c:#fbbf24">${icon('test')}</span><em>Test add</em></button>
    <button class="tile" data-act="revHub"><span style="--c:#fb7185">${icon('cards')}</span><em>Revise</em>${dT + dC ? `<u>${dT + dC}</u>` : ''}</button></div>`;

  const bn = blockNow();
  if (bn.cur || bn.next) h += `<div class="card"><h3>🗓 ${bn.cur ? 'Abhi ka slot' : 'Agla slot'}<small data-act="goTimetable" class="lnk">Timetable ›</small></h3>${blockRow(bn.cur || bn.next, !!bn.cur)}</div>`;

  const tasks = S.tasks.filter(t => t.date === td).sort((a, b) => (a.done - b.done) || (a.time || '99').localeCompare(b.time || '99') || a.created - b.created);
  h += `<div class="sec-title"><span>Aaj ka plan</span><button data-act="goPlan">${tasks.length ? `${tasks.filter(t => t.done).length}/${tasks.length} done ›` : 'Planner ›'}</button></div>`;
  h += tasks.length ? `<div class="card">${tasks.slice(0, 5).map(t => taskRow(t)).join('')}${tasks.length > 5 ? `<button class="btn ghost block sm" data-act="goPlan" style="margin-top:10px">+${tasks.length - 5} aur dekho</button>` : ''}</div>`
    : `<div class="card empty slim"><p>Aaj ke liye koi task nahi. Smart plan syllabus aur revision ke hisab se khud bana dega.</p><div class="btn-row"><button class="btn primary" data-act="smartPlan" data-d="${td}">${icon('wand', 18)} Smart plan banao</button></div></div>`;

  if (dT + dC) h += `<button class="card press row" data-act="revHub"><span class="bigemo">🔁</span><div class="sp"><b>Aaj ka revision</b><br><small class="muted">${dT} topics · ${dC} mistake cards due</small></div><span class="btn primary sm">Start</span></button>`;

  const subs = activeSubs();
  if (subs.length) h += `<div class="sec-title"><span>Syllabus progress</span><button data-act="goSyllabus">Sab dekho ›</button></div><div class="hs">${subs.map(s => { const p = subProg(s.id); return `<button class="card press hs-c" data-act="openSubject" data-id="${s.id}">${ring(p.pct, { size: 70, sw: 5, c: s.color, label: `<b style="font-size:.95rem">${p.pct}%</b>` })}<b>${s.emoji} ${esc(short(s))}</b><small class="muted">${p.done}/${p.n} done</small></button>`; }).join('')}</div>`;

  const fa = focusAreas(3);
  if (fa.length) h += `<div class="sec-title"><span>Focus karo (kamzor areas)</span></div><div class="card">${fa.map(({ t, why }) => { const s = sub(t.sid); return `<div class="item tap" data-act="openTopic" data-id="${t.id}"><div class="ico" style="--c:${s.color}">${s.emoji}</div><div class="txt"><b>${esc(t.name)}</b><small>${why.join(' · ')}</small></div>${icon('next', 16)}</div>`; }).join('')}</div>`;

  if (S.habits.length) h += `<div class="card"><h3>🌱 Aaj ki habits<small data-act="goHabits" class="lnk">Sab ›</small></h3><div class="chips">${S.habits.map(x => `<button class="chip ${x.days[td] ? 'on' : ''}" data-act="habitTick" data-id="${x.id}">${x.emoji} ${esc(x.name)}</button>`).join('')}</div></div>`;

  const dm = dayMap(), wk = [...Array(7)].map((_, i) => addDays(td, i - 6)), vals = wk.map(d => Math.floor((dm[d] || 0) / 60));
  const thisW = sum(vals), prevW = sum([...Array(7)].map((_, i) => Math.floor((dm[addDays(td, i - 13)] || 0) / 60)));
  h += `<div class="card"><h3>Is hafte ki padhai<small class="${thisW >= prevW ? 'pos' : 'neg'}">${fmtDur(thisW * 60)} ${prevW ? (thisW >= prevW ? '▲' : '▼') + Math.abs(pct(thisW - prevW, prevW)) + '%' : ''}</small></h3>${barChart(vals, wk.map(d => DOW[dowOf(d)]), { goal, hi: 6, fmt: v => v + 'm' })}<button class="btn ghost block sm" data-act="goStats" style="margin-top:10px">Poora stats dekho ›</button></div>`;

  const T = sortedTests(), last = T[T.length - 1];
  if (last) { const hs = headScore(last), tr = T.slice(-8).map(t => headScore(t).score); h += `<button class="card press row" data-act="openTest" data-id="${last.id}"><div class="sp"><small class="muted">Pichla test · ${fmtD(last.date)}</small><br><b>${esc(last.name)}</b></div><div class="center">${spark(tr, 'var(--acc)')}</div><div class="score"><b>${f2(hs.score)}</b><small>${hs.label}/${f2(hs.max)}</small></div></button>`; }
  else h += `<div class="card empty slim"><p>Abhi tak koi mock test nahi. Test add karoge to galtiyon ka poora analysis milega.</p><div class="btn-row"><button class="btn ghost" data-act="fabTest">${icon('plus', 18)} Test add karo</button></div></div>`;

  h += `<div class="quote">“${QUOTES[Math.floor(Date.now() / 864e5) % QUOTES.length]}”</div>`;
  return page(h);
}

/* ---------- smart plan ---------- */
function smartPlan(date) {
  const have = new Set(S.tasks.filter(t => t.date === date).map(t => t.tid).filter(Boolean));
  const goal = Math.max(60, S.profile.dailyGoal), out = []; let est = 0;
  const push = (title, sid, tid, e, kind) => { out.push({ id: uid() + out.length, date, title, sid, tid: tid || '', est: e, time: '', done: false, created: Date.now() + out.length, kind }); est += e; };
  dueTopics().filter(t => !have.has(t.id)).sort((a, b) => a.due.localeCompare(b.due)).slice(0, 3).forEach(t => push('🔁 Revise: ' + t.name, t.sid, t.id, 20, 'rev'));
  const nc = dueCards().length;
  if (nc && !S.tasks.some(t => t.date === date && t.kind === 'nb')) push(`🃏 Mistake notebook revise (${nc} cards)`, '', '', 15, 'nb');
  const dl = S.profile.examDate ? dayDiff(date, S.profile.examDate) : 0;
  const remain = S.topics.filter(t => t.status !== 'done' && !sub(t.sid).archived).length;
  const want = dl > 0 ? clamp(Math.ceil(remain / dl), 1, 4) : 2;
  const order = [...activeSubs()].sort((a, b) => (b.merit ? 1 : 0) - (a.merit ? 1 : 0));
  const q = order.map(s => topicsOf(s.id).filter(t => t.status !== 'done' && !have.has(t.id)).sort((a, b) => ((b.status === 'learning') - (a.status === 'learning')) || ((b.imp ? 1 : 0) - (a.imp ? 1 : 0))));
  let picked = 0, guard = 0;
  while (picked < want && q.some(x => x.length) && guard++ < 50) {
    for (const list of q) {
      if (picked >= want || !list.length) continue;
      const t = list.shift(), e = t.status === 'learning' ? 30 : 45;
      if (est + e > goal && out.length >= 3) { picked = want; break; }
      push((t.status === 'learning' ? '📖 Complete karo: ' : '📘 Naya topic: ') + t.name, t.sid, t.id, e, 'new'); picked++;
    }
  }
  const T = sortedTests(), lt = T[T.length - 1];
  if ((!lt || dayDiff(lt.date, date) >= 7) && est + 60 <= goal * 1.25 && S.subjects.length) push('📝 Ek mock test do aur galtiyan log karo', '', '', 60, 'test');
  if (!out.length) return 0;
  S.tasks.push(...out); return out.length;
}

/* ---------- planner ---------- */
function V_plan() {
  const td = today(), sel = UI.pl.date || td, ws = weekStart(sel), days = [...Array(7)].map((_, i) => addDays(ws, i));
  const wd = parseD(ws);
  let h = `<div class="row wkhead"><button class="ibtn" data-act="plWeek" data-d="-7" aria-label="Pichla hafta">${icon('back', 18)}</button><b class="sp center">${MON[wd.getMonth()]} ${wd.getFullYear()}</b>${sel !== td ? `<button class="chip" data-act="plDay" data-d="${td}">Aaj</button>` : ''}<button class="ibtn" data-act="plWeek" data-d="7" aria-label="Agla hafta">${icon('next', 18)}</button></div>`;
  h += `<div class="wk">${days.map(d => { const ts = S.tasks.filter(t => t.date === d), dn = ts.filter(x => x.done).length; return `<button class="${d === sel ? 'on' : ''} ${d === td ? 'today' : ''}" data-act="plDay" data-d="${d}"><small>${DOW[dowOf(d)]}</small><b>${parseD(d).getDate()}</b><i class="${ts.length ? (dn === ts.length ? 'all' : 'has') : ''}"></i></button>`; }).join('')}</div>`;
  const tasks = S.tasks.filter(t => t.date === sel).sort((a, b) => (a.done - b.done) || (a.time || '99').localeCompare(b.time || '99') || a.created - b.created);
  const dn = tasks.filter(t => t.done).length, estAll = sum(tasks, t => t.est || 0), estDone = sum(tasks.filter(t => t.done), t => t.est || 0);
  h += `<div class="card row"><div class="sp"><small class="muted">${sel === td ? 'Aaj' : DOW[dowOf(sel)] + ', ' + fmtD(sel)}</small><br><b style="font-size:1.3rem">${dn}/${tasks.length} tasks</b><br><small class="muted">Plan: ${fmtDur(estAll * 60)} · Padhai: ${fmtDur((dayMap()[sel] || 0))}</small></div>${ring(tasks.length ? dn / tasks.length * 100 : 0, { size: 78, c: 'var(--ok)' })}</div>`;
  if (sel === td) {
    const old = S.tasks.filter(t => t.date < td && !t.done);
    if (old.length) h += `<div class="warnbar"><span>⏰</span><div><b>${old.length} purane task adhoore hain.</b><div class="btn-row" style="margin-top:8px"><button class="btn sm ghost" data-act="carryOver">Aaj me le aao</button><button class="btn sm danger" data-act="dropOld">Hata do</button></div></div></div>`;
  }
  const bl = blocksOn(sel), bn = sel === td ? blockNow() : {};
  h += `<div class="sec-title"><span>🗓 Timetable</span><button data-act="goTimetable">Edit ›</button></div>`;
  h += bl.length ? `<div class="card">${bl.map(b => blockRow(b, bn.cur && bn.cur.id === b.id)).join('')}</div>` : `<div class="card empty slim"><p>Is din ka koi fixed slot nahi. Weekly timetable bana lo.</p><div class="btn-row"><button class="btn ghost" data-act="goTimetable">Timetable banao</button></div></div>`;
  h += `<div class="sec-title"><span>✅ Tasks</span><button data-act="smartPlan" data-d="${sel}">✨ Smart plan</button></div>`;
  h += tasks.length ? `<div class="card">${tasks.map(t => taskRow(t)).join('')}</div>` : empty('📝', 'Koi task nahi', 'Neeche + dabake task jodo ya Smart plan se auto-plan banao.', `<button class="btn primary" data-act="smartPlan" data-d="${sel}">${icon('wand', 18)} Smart plan</button>`);
  return page(h);
}

/* ---------- weekly timetable ---------- */
function V_timetable() {
  const d = UI.tt.day, bl = S.blocks.filter(b => b.days.includes(d)).sort((a, b) => a.start.localeCompare(b.start));
  const wkSecs = {}; S.blocks.forEach(b => b.days.forEach(() => { wkSecs[b.sid] = (wkSecs[b.sid] || 0) + (toMin(b.end) - toMin(b.start)) * 60; }));
  const tot = sum(Object.values(wkSecs));
  let h = `<div class="wk tt">${DOW.map((x, i) => `<button class="${i === d ? 'on' : ''}" data-act="ttDay" data-k="${i}"><b>${x}</b><i class="${S.blocks.some(b => b.days.includes(i)) ? 'has' : ''}"></i></button>`).join('')}</div>`;
  h += bl.length ? `<div class="card">${bl.map(b => blockRow(b, false)).join('')}</div>` : empty('🗓', DOW[d] + ' khali hai', 'Fixed study slots jodo (jaise 6–8 AM Maths). Planner aur Home par "abhi ka slot" dikhega.', `<button class="btn primary" data-act="fabBlock">${icon('plus', 18)} Slot add karo</button>`);
  if (tot) h += `<div class="card"><h3>Hafte ka time-split<small>${fmtDur(tot)} / week</small></h3>${Object.entries(wkSecs).sort((a, b) => b[1] - a[1]).map(([sid, s]) => { const x = sub(sid); return `<div class="hbar-row"><div class="hb-t"><b>${x.emoji} ${esc(x.name)}</b><span>${fmtDur(s)} · ${pct(s, tot)}%</span></div><div class="hbar"><i style="width:${pct(s, tot)}%;background:${x.color}"></i></div></div>`; }).join('')}</div>`;
  return page(h);
}

/* ---------- habits ---------- */
const HABIT_SUG = [['📰', 'Current Affairs padhna'], ['📖', '10 naye words'], ['📝', 'PYQ practice'], ['🏃', 'Exercise / walk'], ['😴', 'Time par sona'], ['📵', 'Social media band (2h)']];
function V_habits() {
  const td = today();
  if (!S.habits.length) return page(empty('🌱', 'Habits banao', 'Chhoti daily aadatein: roz tick karo aur streak badhao.', `<button class="btn primary" data-act="fabHabit">${icon('plus', 18)} Nayi habit</button>`) + `<div class="sec-title"><span>Suggestions (tap karo)</span></div><div class="chips">${HABIT_SUG.map((x, i) => `<button class="chip" data-act="habitSug" data-k="${i}">${x[0]} ${x[1]}</button>`).join('')}</div>`);
  const wk = [...Array(7)].map((_, i) => addDays(td, i - 6));
  return page(S.habits.map(x => {
    const s = habitStreak(x), c30 = [...Array(30)].filter((_, i) => x.days[addDays(td, -i)]).length;
    return `<div class="card"><div class="row"><span class="bigemo">${x.emoji}</span><div class="sp"><b>${esc(x.name)}</b><br><small class="muted">🔥 ${s.cur} din · best ${s.best} · 30 din me ${pct(c30, 30)}%</small></div><button class="ibtn sm" data-act="editHabit" data-id="${x.id}" aria-label="Edit">${icon('edit', 16)}</button></div>
    <div class="hdots">${wk.map(d => `<button class="hd ${x.days[d] ? 'on' : ''} ${d === td ? 'td' : ''}" data-act="habitDay" data-id="${x.id}" data-d="${d}"><small>${DOW[dowOf(d)][0]}</small>${x.days[d] ? icon('check', 14) : ''}</button>`).join('')}</div></div>`;
  }).join(''));
}

/* ============ COMMIT helper ============ */
function commit(rerender = true) { save(); checkProgress(); if (rerender) render(true); }

/* ============ FOCUS TIMER (timestamp based: screen lock / reload safe) ============ */
const tElapsed = t => t.acc + (t.running ? (Date.now() - t.startedAt) / 1000 : 0);
let wakeLock = null;
async function wake(on) {
  try {
    if (on && S.settings.wake && 'wakeLock' in navigator && !wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); }
    else if (!on && wakeLock) { await wakeLock.release(); wakeLock = null; }
  } catch (e) { wakeLock = null; }
}
function logSession(t, secs, extra) {
  S.sessions.push({ id: uid(), date: dateOf(t.sessionStart), ts: t.sessionStart, secs: Math.round(secs), sid: t.sid || '', tid: t.tid || '', mode: t.mode, dist: t.dist || 0, ...(extra || {}) });
}
function alertEnd(msg) { beep(); haptic(); if (S.settings.haptics && navigator.vibrate) { try { navigator.vibrate([220, 90, 220, 90, 320]); } catch (e) { /* ignore */ } } toast(msg, 'ok'); }
function tStart() {
  unlockAudio();
  const P = S.settings.pomo, f = UI.fc;
  if (!f.sid && !S.subjects.length) return toast('Pehle koi subject add karo (Syllabus tab)');
  if (S.cyc.date !== today()) S.cyc = { date: today(), n: 0 };
  S.timer = { phase: 'focus', mode: f.free ? 'free' : 'pomo', planned: f.free ? 0 : P.focus * 60, startedAt: Date.now(), acc: 0, running: true, sid: f.sid, tid: f.tid, dist: 0, sessionStart: Date.now() };
  S.lastSid = f.sid; wake(true); commit();
}
function tToggle() {
  const t = S.timer; if (!t) return;
  if (t.running) { t.acc = tElapsed(t); t.running = false; wake(false); } else { t.startedAt = Date.now(); t.running = true; wake(true); }
  save(); render(true);
}
function tFinish() {
  const t = S.timer; if (!t) return;
  const e = tElapsed(t);
  if (t.phase === 'focus') {
    if (e >= 60) { logSession(t, e); toast(`✓ ${fmtDur(e)} ki padhai log ho gayi`, 'ok'); } else toast('1 minute se kam tha, log nahi hua');
  }
  S.timer = null; wake(false); commit();
}
function tFinishPhase() {
  const t = S.timer; if (!t) return;
  const P = S.settings.pomo, late = Date.now() - (t.startedAt + (t.planned - t.acc) * 1000);
  if (t.phase === 'focus') {
    logSession(t, t.planned);
    if (S.cyc.date !== today()) S.cyc = { date: today(), n: 0 };
    S.cyc.n++;
    const long = S.cyc.n % P.every === 0;
    alertEnd('🎉 Focus complete! ' + (long ? 'Lamba break lo ☕' : 'Chhota break lo ☕'));
    if (P.autoBreak && late < 120000) S.timer = { phase: long ? 'long' : 'short', mode: 'break', planned: (long ? P.long : P.short) * 60, startedAt: Date.now(), acc: 0, running: true, sid: t.sid, tid: t.tid, dist: 0, sessionStart: Date.now() };
    else { S.timer = null; wake(false); }
  } else { alertEnd('Break khatam! Wapas padhai 💪'); S.timer = null; wake(false); }
  commit();
}
function tick() {
  const t = S.timer; if (!t) return;
  if (t.running && t.planned && tElapsed(t) >= t.planned) { tFinishPhase(); return; }
  tickUI();
}
function tickUI() {
  updateMini();
  const t = S.timer; if (!t || cur.name !== 'focus') return;
  const e = tElapsed(t), p = clamp(t.planned ? e / t.planned * 100 : (e % 3600) / 3600 * 100, 0, 100);
  const el = $('#fcTime'); if (el) el.textContent = t.planned ? clock(t.planned - e, true) : clock(e);
  const r = $('#fcRing'); if (r) r.setAttribute('stroke-dasharray', `${p} ${100 - p}`);
}
function updateMini() {
  const m = $('#mini'), t = S.timer, show = !!t && cur.name !== 'focus';
  m.classList.toggle('hidden', !show); $('#nav').classList.toggle('run', !!t && t.running);
  if (!show) { m.dataset.k = ''; return; }
  const k = t.phase + t.sid + t.running;
  if (m.dataset.k !== k) { m.dataset.k = k; m.innerHTML = `<button data-act="goFocus"><span class="dotp ${t.running ? 'on' : ''}"></span><div><b id="miniTime"></b><small>${t.phase === 'focus' ? (t.running ? 'Focus' : '⏸ Paused') : '☕ Break'} · ${esc(sub(t.sid).name)}</small></div>${icon('next', 16)}</button>`; }
  const e = tElapsed(t), el = $('#miniTime'); if (el) el.textContent = t.planned ? clock(t.planned - e, true) : clock(e);
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) { if (S.timer && S.timer.running) wake(true); tick(); } });
setInterval(tick, 500);

const PRESETS = { 25: [25, 5], 50: [50, 10], 90: [90, 15] };
function V_focus() {
  const t = S.timer, P = S.settings.pomo, F = UI.fc, subs = activeSubs();
  if (!F.sid || !S.subjects.some(s => s.id === F.sid && !s.archived)) F.sid = (S.lastSid && sub(S.lastSid).id ? S.lastSid : '') || meritIds()[0] || (subs[0] || {}).id || '';
  const sid = t ? t.sid : F.sid, tid = t ? t.tid : F.tid, s = sub(sid), tp = topic(tid);
  const brk = t && t.phase !== 'focus', e = t ? tElapsed(t) : 0;
  const p = t ? clamp(t.planned ? e / t.planned * 100 : (e % 3600) / 3600 * 100, 0, 100) : 0;
  const planned = t ? t.planned : (F.free ? 0 : P.focus * 60);
  const disp = t ? (t.planned ? clock(t.planned - e, true) : clock(e)) : (planned ? clock(planned) : '00:00');
  if (!S.subjects.length) return page(empty('⏱', 'Pehle subject chuno', 'Focus timer subject ke hisab se time log karta hai.', `<button class="btn primary" data-act="goSyllabus">Syllabus setup karo</button>`));
  let h = `<div class="fcbox ${t && t.running ? 'run' : ''} ${brk ? 'brk' : ''}"><div class="fcring"><svg viewBox="0 0 42 42"><defs><linearGradient id="fg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--acc)"/><stop offset="1" stop-color="var(--acc2)"/></linearGradient></defs><circle class="trk" cx="21" cy="21" r="15.915" fill="none" stroke-width="2.2"/><circle id="fcRing" class="prg" cx="21" cy="21" r="15.915" fill="none" stroke="${brk ? 'var(--ok)' : 'url(#fg)'}" stroke-width="2.6" stroke-linecap="round" stroke-dasharray="${p} ${100 - p}"/></svg>
    <div class="fcin"><small>${t ? (brk ? '☕ Break time' : t.running ? 'Focus chal raha hai' : '⏸ Paused') : (F.free ? 'Stopwatch' : 'Focus session')}</small><b id="fcTime">${disp}</b><span>${s.emoji} ${esc(s.name)}${tp ? ' · ' + esc(tp.name) : ''}</span></div></div></div>`;
  if (!t) {
    h += `<div class="btn-row fcbtn"><button class="btn primary big" data-act="tStart">${icon('play', 20)} ${F.free ? 'Stopwatch shuru' : 'Focus shuru karo'}</button></div>`;
    h += `<div class="lbl">Subject</div><div class="chips row">${subs.map(x => `<button class="chip ${F.sid === x.id ? 'on' : ''}" style="--c:${x.color}" data-act="fcSub" data-id="${x.id}">${x.emoji} ${esc(short(x))}</button>`).join('')}</div>`;
    const ts = topicsOf(F.sid).filter(x => x.status !== 'done').slice(0, 14);
    if (ts.length || F.tid) h += `<div class="lbl">Topic (optional)</div><div class="chips row"><button class="chip ${!F.tid ? 'on' : ''}" data-act="fcTopic" data-id="">Koi nahi</button>${(F.tid && !ts.some(x => x.id === F.tid) && topic(F.tid) ? [topic(F.tid), ...ts] : ts).map(x => `<button class="chip ${F.tid === x.id ? 'on' : ''}" style="--c:${s.color}" data-act="fcTopic" data-id="${x.id}">${esc(x.name)}</button>`).join('')}</div>`;
    h += `<div class="lbl">Mode</div><div class="chips row">${Object.keys(PRESETS).map(k => `<button class="chip ${!F.free && P.focus === PRESETS[k][0] && P.short === PRESETS[k][1] ? 'on' : ''}" data-act="fcPreset" data-k="${k}">${PRESETS[k][0]} · ${PRESETS[k][1]}</button>`).join('')}<button class="chip ${F.free ? 'on' : ''}" data-act="fcPreset" data-k="free">⏱ Stopwatch</button></div>`;
    if (!F.free) h += `<div class="card row" style="margin-top:12px"><div class="sp"><b>Focus ${P.focus} min</b><br><small class="muted">Break ${P.short}m · har ${P.every} session ke baad ${P.long}m ka lamba break</small></div><div class="qty"><button data-act="fcDur" data-d="-5">−</button><button data-act="fcDur" data-d="5">+</button></div></div>`;
  } else {
    h += `<div class="btn-row fcbtn">${brk ? `<button class="btn ghost" data-act="tSkip">Break skip karo</button>` : `<button class="btn ghost" data-act="tFinish">${icon('stop', 18)} Finish</button>`}<button class="btn primary" data-act="tToggle">${icon(t.running ? 'pause' : 'play', 18)} ${t.running ? 'Pause' : 'Resume'}</button></div>`;
    if (!brk) h += `<div class="row" style="justify-content:center;margin-top:14px"><button class="chip" data-act="tDist">📵 Distraction +1 <b>${t.dist || 0}</b></button><button class="chip" data-act="tCancel">✕ Discard</button></div>`;
  }
  const td = today(), ses = S.sessions.filter(x => x.date === td).sort((a, b) => b.ts - a.ts), secs = dayMap()[td] || 0, goal = Math.max(1, S.profile.dailyGoal);
  h += `<div class="card" style="margin-top:18px"><h3>Aaj ka time<small>${S.cyc.date === td ? S.cyc.n : 0} sessions</small></h3><div class="row"><b style="font-size:1.6rem">${fmtDur(secs)}</b><span class="muted small">/ ${fmtDur(goal * 60)} goal</span><span class="sp"></span><b class="${secs >= goal * 60 ? 'pos' : ''}">${Math.min(100, pct(secs, goal * 60))}%</b></div><div class="stack" style="margin-top:10px"><i style="width:${Math.min(100, secs / (goal * 60) * 100)}%;background:var(--grad)"></i></div></div>`;
  h += `<div class="sec-title"><span>Aaj ke sessions</span><button data-act="fabManual">+ Manual time</button></div>`;
  h += ses.length ? `<div class="card">${ses.map(x => { const q = sub(x.sid), tt = topic(x.tid); return `<div class="item"><div class="ico" style="--c:${q.color}">${q.emoji}</div><div class="txt"><b>${fmtDur(x.secs)}${x.manual ? ' · manual' : ''}</b><small>${esc(q.name)}${tt ? ' · ' + esc(tt.name) : ''}${x.manual ? '' : ' · ' + to12(pad(new Date(x.ts).getHours()) + ':' + pad(new Date(x.ts).getMinutes()))}${x.dist ? ' · 📵' + x.dist : ''}</small></div><button class="ibtn sm" data-act="delSession" data-id="${x.id}" aria-label="Delete">${icon('trash', 15)}</button></div>`; }).join('')}</div>` : `<div class="card empty slim"><p>Aaj abhi tak koi session nahi. Pehla 25 minute shuru karo! 💪</p></div>`;
  return page(h);
}

/* manual time sheet */
let MT = null;
function openManualSheet() {
  const subs = activeSubs(); if (!subs.length) return toast('Pehle subject add karo');
  MT = { sid: UI.fc.sid || subs[0].id, tid: '', date: today(), mins: 30 };
  openSheet('Padhai ka time jodo', `<label class="lbl">Subject</label><div class="chips" id="mtSubs"></div><label class="lbl">Topic (optional)</label><div class="chips box" id="mtTopics"></div><label class="lbl">Kitni der?</label><div class="chips" id="mtMins">${[15, 30, 45, 60, 90, 120].map(m => `<button class="chip" data-act="mtMins" data-k="${m}">${m}m</button>`).join('')}</div><div class="g2" style="margin-top:12px"><div><small>Minutes</small><input class="inp num" id="mtMinIn" type="number" inputmode="numeric" min="1" max="600" value="30"></div><div><small>Date</small><input class="inp" id="mtDate" type="date" max="${today()}" value="${today()}"></div></div>`, `<button class="btn primary" data-act="mtSave">Save karo</button>`);
  mtRender();
}
function mtRender() {
  $('#mtSubs').innerHTML = activeSubs().map(x => `<button class="chip ${MT.sid === x.id ? 'on' : ''}" style="--c:${x.color}" data-act="mtSub" data-id="${x.id}">${x.emoji} ${esc(short(x))}</button>`).join('');
  $('#mtTopics').innerHTML = `<button class="chip ${!MT.tid ? 'on' : ''}" data-act="mtTopic" data-id="">Koi nahi</button>` + topicsOf(MT.sid).map(x => `<button class="chip ${MT.tid === x.id ? 'on' : ''}" style="--c:${sub(MT.sid).color}" data-act="mtTopic" data-id="${x.id}">${esc(x.name)}</button>`).join('');
  $$('#mtMins .chip').forEach(c => c.classList.toggle('on', Number(c.dataset.k) === MT.mins));
}

/* revision hub */
function openRevHub() {
  const ts = dueTopics().sort((a, b) => a.due.localeCompare(b.due)), nc = dueCards().length;
  if (!ts.length && !nc) return toast('Aaj revise karne ke liye kuch nahi 🎉', 'ok');
  openSheet('Aaj ka revision', `${nc ? `<div class="card row press" data-act="revCards"><span class="bigemo">🃏</span><div class="sp"><b>Mistake flashcards</b><br><small class="muted">${nc} cards due</small></div><span class="btn primary sm">Start</span></div>` : ''}
    ${ts.length ? `<div class="sec-title"><span>Topics revise karo (${ts.length})</span></div><div class="card">${ts.map(t => { const s = sub(t.sid), od = dayDiff(t.due, today()); return `<div class="item"><div class="ico" style="--c:${s.color}">${s.emoji}</div><div class="txt" data-act="openTopicFromSheet" data-id="${t.id}"><b>${esc(t.name)}</b><small>${od > 0 ? od + ' din late' : 'aaj due'} · revised ×${t.rev}</small></div><button class="btn sm primary" data-act="topicRevSheet" data-id="${t.id}">✓ Ho gaya</button></div>`; }).join('')}</div>` : ''}`);
}

/* ============ SYLLABUS ============ */
function syllabusForecast() {
  const all = S.topics.filter(t => !sub(t.sid).archived), remain = all.filter(t => t.status !== 'done').length, td = today();
  const recent = all.filter(t => t.status === 'done' && t.doneOn && dayDiff(t.doneOn, td) < 14).length;
  if (!remain) return { txt: '🎉 Poora syllabus complete!' };
  const need = S.profile.examDate && dayDiff(td, S.profile.examDate) > 0 ? remain / dayDiff(td, S.profile.examDate) : 0;
  if (!recent) return { txt: need ? `Exam tak roz ~${f1(need)} topics chahiye. Pichle 14 din me koi topic complete nahi hua.` : 'Topics complete karte jao, yahan forecast dikhega.' };
  const rate = recent / 14, days = Math.ceil(remain / rate), fin = addDays(td, days);
  let txt = `Is raftaar (${f1(rate)} topics/din) se syllabus ~${fmtD(fin)} tak khatam hoga.`;
  if (S.profile.examDate) { const gap = dayDiff(fin, S.profile.examDate); txt += gap >= 0 ? ` Exam se ${gap} din pehle ✅` : ` Exam se ${-gap} din late ⚠️ (roz ~${f1(need)} topics chahiye)`; }
  return { txt, late: S.profile.examDate && dayDiff(fin, S.profile.examDate) < 0 };
}
function V_syllabus() {
  const subs = activeSubs();
  if (!subs.length) return page(empty('📚', 'Syllabus khaali hai', 'SSC MTS ka ready syllabus load karo ya apne subjects khud banao.', `<button class="btn primary" data-act="loadPreset">SSC MTS syllabus load karo</button><button class="btn ghost" data-act="fabSubject">Apna subject add karo</button>`));
  const all = S.topics.filter(t => !sub(t.sid).archived), n = all.length, done = all.filter(t => t.status === 'done').length, learn = all.filter(t => t.status === 'learning').length, rev = all.filter(t => t.rev > 0).length, due = dueTopics().length;
  const pc = n ? Math.round((done + learn * .5) / n * 100) : 0, fc = syllabusForecast();
  let h = `<div class="card"><div class="row" style="gap:16px">${ring(pc, { size: 104, sw: 5 })}<div class="sp"><div class="g2s"><div><b>${done}</b><small>Complete</small></div><div><b>${learn}</b><small>Padh rahe</small></div><div><b>${n - done - learn}</b><small>Baaki</small></div><div><b>${rev}</b><small>Revised</small></div></div></div></div><p class="note ${fc.late ? 'warn' : ''}">${fc.txt}</p>${due ? `<button class="btn primary block" data-act="revHub" style="margin-top:12px">🔁 ${due} topics revision ke liye due</button>` : ''}</div>`;
  h += subs.map(s => {
    const p = subProg(s.id), secs = secsBySub()[s.id] || 0;
    return `<button class="card press subcard" data-act="openSubject" data-id="${s.id}"><div class="row"><div class="ico lg" style="--c:${s.color}">${s.emoji}</div><div class="sp"><b>${esc(s.name)}</b> ${s.merit ? '<span class="badge" style="background:var(--acc-soft);color:var(--acc-t)">MERIT</span>' : ''}<br><small class="muted">${p.done}/${p.n} complete${p.due ? ` · 🔁 ${p.due} due` : ''}${secs ? ` · ⏱ ${fmtHrs(secs)}` : ''}</small></div><b style="color:${s.color};font-size:1.15rem">${p.pct}%</b></div>
    <div class="stack" style="margin-top:12px"><i style="width:${pct(p.done, p.n)}%;background:${s.color}"></i><i style="width:${pct(p.learning, p.n)}%;background:${hexa(s.color, .45)}"></i></div></button>`;
  }).join('');
  if (S.subjects.some(s => s.archived)) h += `<button class="btn ghost block" data-act="goSettings" style="margin-top:4px">Archived subjects Settings me hain</button>`;
  return page(h);
}
function filteredTopics(sid) {
  const f = UI.sf, q = f.q.trim().toLowerCase(), mb = mistakesByTopic();
  return topicsOf(sid).filter(t => (f.f === 'all' || (f.f === 'due' ? isDue(t) : f.f === 'imp' ? t.imp : f.f === 'weak' ? (mb[t.id] && mb[t.id].p) || (t.conf && t.conf <= 2) : t.status === f.f)) && (!q || t.name.toLowerCase().includes(q)));
}
function topicRow(t) {
  const mb = mistakesByTopic()[t.id] || {}, ts = secsByTopic()[t.id] || 0, meta = [];
  if (t.status === 'done') { meta.push(t.rev ? `Revised ×${t.rev}` : 'Revise baaki'); if (isDue(t)) meta.push('🔁 due'); else if (t.due) meta.push('next ' + fmtD(t.due)); }
  if (mb.p) meta.push('❌ ' + mb.p);
  if (ts) meta.push('⏱ ' + fmtDur(ts));
  if (t.conf) meta.push('★'.repeat(t.conf));
  return `<div class="item trw s-${t.status}"><button class="tst" data-act="cycleStatus" data-id="${t.id}" aria-label="Status badlo">${STAT[t.status].ico}</button><div class="txt" data-act="openTopic" data-id="${t.id}"><b>${esc(t.name)}${t.imp ? ' ⭐' : ''}</b><small>${meta.join(' · ') || STAT[t.status].label}</small></div>${isDue(t) ? `<button class="btn sm ghost" data-act="topicRev" data-id="${t.id}">✓</button>` : ''}</div>`;
}
const topicListHtml = sid => { const l = filteredTopics(sid); return l.length ? l.map(topicRow).join('') : '<p class="muted small center" style="padding:16px 0">Koi topic nahi mila.</p>'; };

function V_subject(id) {
  const s = S.subjects.find(x => x.id === id);
  if (!s) return page(empty('🤷', 'Subject nahi mila', '', `<button class="btn primary" data-act="goSyllabus">Syllabus par jao</button>`));
  const p = subProg(id), td = today(), dm = {};
  S.sessions.filter(x => x.sid === id).forEach(x => { dm[x.date] = (dm[x.date] || 0) + x.secs; });
  const secs = secsBySub()[id] || 0, w7 = sum([...Array(7)].map((_, i) => dm[addDays(td, -i)] || 0));
  const days = [...Array(14)].map((_, i) => addDays(td, i - 13));
  const T = sortedTests().filter(t => t.sections[id]), ms = S.mistakes.filter(m => m.sid === id && m.testId);
  let h = `<div class="card" style="border-top:3px solid ${s.color}"><div class="row" style="gap:16px">${ring(p.pct, { size: 96, sw: 5, c: s.color })}<div class="sp"><div class="g2s"><div><b>${p.done}/${p.n}</b><small>Complete</small></div><div><b>${p.learning}</b><small>Padh rahe</small></div><div><b>${p.revised}</b><small>Revised</small></div><div><b class="${p.due ? 'neg' : ''}">${p.due}</b><small>Revise due</small></div></div></div></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn ghost sm" data-act="focusSub" data-id="${id}">${icon('play', 15)} Focus</button><button class="btn ghost sm" data-act="editSubject" data-id="${id}">${icon('edit', 15)} Edit subject</button></div></div>`;
  h += `<div class="grid2"><div class="card stat"><b>${fmtDur(secs)}</b><span>Total padhai</span></div><div class="card stat"><b>${fmtDur(w7)}</b><span>Pichle 7 din</span></div></div>`;
  if (secs) h += `<div class="card"><h3>Time (14 din)</h3>${barChart(days.map(d => Math.floor((dm[d] || 0) / 60)), days.map(d => parseD(d).getDate()), { color: s.color, fmt: v => v + 'm', hi: 13 })}</div>`;
  if (T.length) {
    const a = agg(T, [id]), acc = T.map(t => agg([t], [id]).acc), lb = T.map(t => fmtD(t.date).split(' ')[0]);
    h += `<div class="card"><h3>Test performance<small>${T.length} tests</small></h3><div class="g2s" style="margin-bottom:10px"><div><b>${Math.round(a.acc)}%</b><small>Accuracy</small></div><div><b>${Math.round(a.attPct)}%</b><small>Attempt</small></div><div><b>${f2(a.score / T.length)}</b><small>Avg score</small></div><div><b>${f2(Math.max(...T.map(t => secStat(t.sections[id]).score)))}</b><small>Best</small></div></div>${lineChart(acc.slice(-10), lb.slice(-10), s.color, { min: 0, max: 100, fmt: v => Math.round(v) + '%' })}</div>`;
  }
  if (ms.length) {
    const rc = countBy(ms, m => m.reason), items = REASON_KEYS.filter(r => rc[r]).map(r => ({ v: rc[r], color: REASONS[r].color, r })).sort((a, b) => b.v - a.v);
    h += `<div class="card"><h3>Galtiyan kyun? <small>${ms.length}</small></h3><div class="row" style="gap:14px">${donut(items, ms.length, ms.length, 'mistakes')}<div class="legend">${items.map(i => `<div><i style="background:${i.color}"></i><span>${REASONS[i.r].ico} ${REASONS[i.r].short}</span><b>${pct(i.v, ms.length)}%</b></div>`).join('')}</div></div></div>`;
  }
  h += `<div class="chips row" style="margin:14px 0 8px">${[['all', 'Sab'], ['todo', 'Baaki'], ['learning', 'Padh rahe'], ['done', 'Complete'], ['due', '🔁 Due'], ['imp', '⭐ Important'], ['weak', '⚠ Weak']].map(([k, l]) => `<button class="chip ${UI.sf.f === k ? 'on' : ''}" data-act="sfF" data-k="${k}">${l}</button>`).join('')}</div>
    <div class="search">${icon('search', 18)}<input class="inp" id="sfQ" placeholder="Topic dhundo…" value="${esc(UI.sf.q)}"></div>
    <div class="card" id="topicList">${topicListHtml(id)}</div>`;
  return page(h);
}

/* ---- topic sheet ---- */
let TP = null;
function openTopicSheet(id) {
  const t = topic(id); if (!t) return;
  TP = { id, status: t.status, conf: t.conf, imp: t.imp };
  const s = sub(t.sid), mb = mistakesByTopic()[id] || { n: 0, p: 0 }, ts = secsByTopic()[id] || 0;
  openSheet('Topic details', `<div class="row" style="margin-bottom:6px">${subBadge(t.sid)}</div>
    <label class="lbl">Naam</label><input class="inp" id="tpName" maxlength="60" value="${esc(t.name)}">
    <label class="lbl">Status</label><div class="seg" id="tpStatus">${Object.keys(STAT).map(k => `<button class="${TP.status === k ? 'on' : ''}" data-act="tpStatus" data-k="${k}">${STAT[k].ico} ${STAT[k].label}</button>`).join('')}</div>
    <label class="lbl">Confidence (khud ko rate karo)</label><div class="stars" id="tpConf">${[1, 2, 3, 4, 5].map(i => `<button class="${i <= TP.conf ? 'on' : ''}" data-act="tpConf" data-k="${i}">${icon('star', 26)}</button>`).join('')}</div>
    <label class="lbl">Options</label><div class="chips"><button class="chip ${TP.imp ? 'on' : ''}" id="tpImp" data-act="tpImp">⭐ Important topic</button></div>
    <label class="lbl">Notes / yaad rakhne wale points</label><textarea class="inp" id="tpNotes" rows="3" placeholder="Short tricks, formulae, facts…">${esc(t.notes)}</textarea>
    <div class="card" style="margin-top:16px"><div class="g2s"><div><b>${ts ? fmtDur(ts) : '–'}</b><small>Time diya</small></div><div><b>${mb.p}/${mb.n}</b><small>Galtiyan (baaki/total)</small></div><div><b>${t.rev}</b><small>Revisions</small></div><div><b>${t.due ? fmtD(t.due) : '–'}</b><small>Agli revision</small></div></div></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn ghost sm" data-act="focusTopic" data-id="${id}">${icon('play', 15)} Focus karo</button>${t.status === 'done' ? `<button class="btn ghost sm" data-act="tpRev" data-id="${id}">✓ Revise kar liya</button>` : ''}${mb.n ? `<button class="btn ghost sm" data-act="topicMistakes" data-id="${id}">❌ Galtiyan</button>` : ''}</div>`,
    `<button class="btn danger" style="flex:0 0 auto;padding:13px 16px" data-act="tpDelete" aria-label="Delete">${icon('trash', 18)}</button><button class="btn primary" data-act="tpSave">Save karo</button>`);
}
function openTopicAdd(sid) {
  const s = sub(sid);
  openSheet('Topics add karo', `<div class="hintbar">${s.emoji} ${esc(s.name)}</div><label class="lbl">Topic ka naam (ek line = ek topic)</label><textarea class="inp" id="taText" rows="6" placeholder="Percentage&#10;Profit & Loss*&#10;Time & Work"></textarea><p class="muted small" style="margin-top:8px">Naam ke end me * lagao to topic ⭐ important ban jayega.</p>`, `<button class="btn primary" data-act="taSave" data-id="${sid}">Add karo</button>`);
}

/* ---- subject sheet ---- */
let SB = null;
function openSubjectSheet(id) {
  const s = id ? S.subjects.find(x => x.id === id) : null;
  SB = { id: id || null, emoji: s ? s.emoji : '📘', color: s ? s.color : COLORS[S.subjects.length % COLORS.length], merit: s ? s.merit : false };
  openSheet(s ? 'Subject edit' : 'Naya subject', `<label class="lbl">Naam</label><input class="inp" id="sbName" maxlength="30" value="${s ? esc(s.name) : ''}" placeholder="Jaise: General Science">
    <label class="lbl">Chhota naam (chips me dikhega)</label><input class="inp" id="sbShort" maxlength="10" value="${s ? esc(short(s)) : ''}" placeholder="Auto">
    <label class="lbl">Emoji</label><div class="chips" id="sbEmojis"></div><label class="lbl">Rang</label><div class="chips" id="sbColors"></div>
    <label class="lbl">Merit subject?</label><div class="set-row" style="border:0"><div><b>Merit me count hota hai</b><small>Merit score aur analysis me priority milti hai</small></div><button class="sw ${SB.merit ? 'on' : ''}" id="sbMerit" data-act="sbMerit"></button></div>
    ${s ? `<div class="btn-row" style="margin-top:14px"><button class="btn ghost" data-act="sbArchive">${icon('archive', 18)} ${s.archived ? 'Restore' : 'Archive'}</button><button class="btn danger" data-act="sbDelete">${icon('trash', 18)} Delete</button></div>` : ''}`,
    `<button class="btn primary" data-act="sbSave">${s ? 'Update karo' : 'Add karo'}</button>`);
  sbRender();
}
function sbRender() {
  $('#sbEmojis').innerHTML = EMOJIS.map(e => `<button class="chip ${SB.emoji === e ? 'on' : ''}" data-act="sbEmoji" data-k="${e}">${e}</button>`).join('');
  $('#sbColors').innerHTML = COLORS.map(c => `<button class="swatch ${SB.color === c ? 'on' : ''}" style="background:${c}" data-act="sbColor" data-k="${c}" aria-label="rang"></button>`).join('');
}

/* ============ MOCK TESTS · ANALYSIS · NOTEBOOK · FLASHCARDS ============ */
const reasonBadge = r => { const R = REASONS[r] || REASONS.silly; return `<span class="badge" style="${tint(R.color)}">${R.ico} ${R.short}</span>`; };
const secDot = id => `<span class="dot" style="background:${sub(id).color}"></span>`;

function testCard(t) {
  const st = testStat(t), hs = headScore(t), lp = logProgress(t);
  const bars = Object.keys(t.sections).map(k => { const s = st.secs[k], q = sub(k); return `<div class="mini"><span style="color:${q.color}">${esc(short(q))}</span>${stackBar(s)}<em>${s.correct}/${s.total}</em></div>`; }).join('');
  const logTxt = lp.need === 0 ? '<span class="tag-ok">Perfect score 🎉</span>' : lp.got >= lp.need ? '<span class="tag-ok">✓ Sab mistakes log hui</span>' : `<span class="tag-warn">⚠ ${lp.got}/${lp.need} mistakes log hui</span>`;
  return `<button class="card tcard press" data-act="openTest" data-id="${t.id}"><div class="tc-top"><div><h4>${esc(t.name)}</h4><small>${fmtD(t.date)} · ${esc(t.type || 'Full Mock')}${t.mins ? ' · ' + t.mins + ' min' : ''}</small></div><div class="score"><b>${f2(hs.score)}</b><small>${hs.label} / ${f2(hs.max)}</small></div></div>${bars}<div class="tc-foot">${logTxt}<span class="muted">Dekho ›</span></div></button>`;
}
function mistakeCard(m, hideSrc) {
  const t = m.testId ? S.tests.find(x => x.id === m.testId) : null, s = sub(m.sid);
  const src = t ? `${esc(t.name)} · ${fmtD(t.date)}` : 'Manual note';
  const kind = m.kind === 'wrong' ? '❌ Galat' : m.kind === 'skip' ? '⏭ Skip' : '📝 Note';
  const due = !m.done && m.due ? (m.due <= today() ? ' · 🔁 due' : ' · next ' + fmtD(m.due)) : '';
  return `<article class="mcard ${m.done ? 'done' : ''}"><div class="mc-top">${secDot(m.sid)}<b>${esc(tName(m))}</b>${reasonBadge(m.reason)}<span class="kind">${kind}</span></div>${m.q ? `<p class="mc-q">${esc(m.q)}</p>` : ''}${m.ans ? `<p class="mc-a">✔ ${esc(m.ans)}</p>` : ''}
    <div class="mc-foot"><small>${hideSrc ? esc(short(s)) : src}${due}</small><div class="mc-actions"><button class="${m.done ? 'ok' : ''}" data-act="toggleDone" data-id="${m.id}" aria-label="Revised">${icon(m.done ? 'undo' : 'check', 18)}</button><button data-act="editM" data-id="${m.id}" aria-label="Edit">${icon('edit', 17)}</button><button class="del" data-act="delM" data-id="${m.id}" aria-label="Delete">${icon('trash', 17)}</button></div></div></article>`;
}

function V_tests() {
  const f = UI.tf.type, all = sortedTests();
  let T = [...all].reverse(); if (f !== 'all') T = T.filter(t => t.type === f);
  let h = segTabs('tests');
  if (!all.length) return page(h + empty('📝', 'Pehla mock test add karo', 'Score aur galtiyan log karoge to topic-wise, reason-wise poora analysis milega.', `<button class="btn primary" data-act="fabTest">${icon('plus', 18)} Test add karo</button><button class="btn ghost" data-act="loadDemo">Demo data se dekho</button>`));
  const hs = all.map(t => headScore(t)), avg = sum(hs, x => x.max ? x.score / x.max : 0) / all.length * 100, best = Math.max(...hs.map(x => x.max ? x.score / x.max * 100 : 0));
  h += `<div class="grid2 three"><div class="card stat"><b>${all.length}</b><span>Tests</span></div><div class="card stat"><b>${Math.round(avg)}%</b><span>Avg score</span></div><div class="card stat"><b>${Math.round(best)}%</b><span>Best</span></div></div>`;
  const types = [...new Set(all.map(t => t.type || 'Full Mock'))];
  if (types.length > 1) h += `<div class="chips row" style="margin-bottom:12px">${['all', ...types].map(k => `<button class="chip ${f === k ? 'on' : ''}" data-act="tfType" data-k="${k}">${k === 'all' ? 'Sab' : k}</button>`).join('')}</div>`;
  h += T.map(testCard).join('');
  return page(h);
}

function V_test(id) {
  const t = S.tests.find(x => x.id === id);
  if (!t) return page(empty('🤷', 'Test nahi mila', '', `<button class="btn primary" data-act="goTests">Tests par jao</button>`));
  const st = testStat(t), hs = headScore(t), lp = logProgress(t);
  const ms = S.mistakes.filter(m => m.testId === t.id).sort((a, b) => a.created - b.created);
  const sameType = sortedTests().filter(x => x.type === t.type && x.id !== t.id && (x.date < t.date || (x.date === t.date && x.created < t.created)));
  const prev = sameType[sameType.length - 1], pd = prev ? hs.score - headScore(prev).score : null;
  const totQ = sum(Object.values(t.sections), s => s.total);
  let h = `<section class="hero"><p>${fmtD(t.date)} · ${esc(t.type || 'Full Mock')}</p><h2>${esc(t.name)}</h2><div class="hero-grid"><div><b>${f2(hs.score)}</b><span>${hs.label} score</span></div><div><b>${pct(hs.score, hs.max)}%</b><span>of ${f2(hs.max)}</span></div><div><b>${pd === null ? '–' : (pd >= 0 ? '+' : '') + f2(pd)}</b><span>vs pichla ${esc(t.type || 'test')}</span></div></div>${t.mins ? `<div class="hero-foot"><span>⏱ ${t.mins} min</span><span>${f1(t.mins * 60 / Math.max(1, totQ))}s / question</span><span>Total ${f2(st.total)}/${f2(st.totalMax)}</span></div>` : ''}</section>`;
  if (lp.need > lp.got) h += `<div class="warnbar"><span>⚠️</span><div><b>${lp.need - lp.got} galat/skip questions abhi log nahi hue.</b><br>Jitna sach log karoge, analysis utna accurate hoga.</div></div>`;
  h += `<div class="btn-row" style="margin-bottom:12px"><button class="btn primary" data-act="addM" data-id="${t.id}">${icon('plus', 18)} Mistake log karo</button></div>`;
  h += Object.keys(t.sections).map(k => {
    const s = st.secs[k], q = sub(k), lw = loggedCount(t.id, k, 'wrong'), ls = loggedCount(t.id, k, 'skip');
    return `<div class="card" style="border-left:4px solid ${q.color}"><h3>${q.emoji} ${esc(q.name)}${q.merit ? ' <span class="badge" style="background:var(--acc-soft);color:var(--acc-t)">MERIT</span>' : ''}<small>${f2(s.score)} / ${f2(s.max)}</small></h3>${stackBar(s)}<div class="g2s" style="margin-top:12px"><div><b class="pos">${s.correct}</b><small>Sahi</small></div><div><b class="neg">${s.wrong}</b><small>Galat</small></div><div><b>${s.skip}</b><small>Skip</small></div><div><b>${Math.round(s.acc)}%</b><small>Accuracy</small></div></div><p class="small ${(lw < s.wrong || ls < s.skip) ? 'tag-warn' : 'tag-ok'}" style="margin-top:10px">Logged: Galat ${lw}/${s.wrong} · Skip ${ls}/${s.skip}</p></div>`;
  }).join('');
  if (ms.length) {
    const rc = countBy(ms, m => m.reason), items = REASON_KEYS.filter(r => rc[r]).map(r => ({ v: rc[r], color: REASONS[r].color, r })).sort((a, b) => b.v - a.v);
    h += `<div class="card"><h3>Is test me galtiyan kyun?</h3><div class="row" style="gap:14px">${donut(items, ms.length, ms.length, 'logged')}<div class="legend">${items.map(i => `<div><i style="background:${i.color}"></i><span>${REASONS[i.r].ico} ${REASONS[i.r].short}</span><b>${i.v}</b></div>`).join('')}</div></div></div>`;
  }
  h += `<div class="sec-title"><span>Is test ki mistakes (${ms.length})</span></div>${ms.length ? ms.map(m => mistakeCard(m, true)).join('') : '<p class="muted small center" style="padding:10px">Abhi koi mistake log nahi hui.</p>'}`;
  h += `<div class="btn-row" style="margin-top:14px"><button class="btn ghost" data-act="editTest" data-id="${t.id}">${icon('edit', 18)} Edit test</button><button class="btn danger" data-act="delTest" data-id="${t.id}">${icon('trash', 18)} Delete</button></div>`;
  return page(h);
}

/* ---------- analysis ---------- */
function analysisKeys() { const f = UI.an.sec; return f === 'merit' ? meritIds(true) : f === 'all' ? S.subjects.map(s => s.id) : [f]; }
function insightsFor(T, ms, keys) {
  const out = [], tot = ms.length; if (!tot) return out;
  const rc = countBy(ms, m => m.reason), sorted = Object.entries(rc).sort((a, b) => b[1] - a[1]), [r0, n0] = sorted[0];
  out.push({ e: REASONS[r0].ico, t: `Sabse badi dikkat: <b>${REASONS[r0].label}</b> (${pct(n0, tot)}%)`, d: REASONS[r0].fix });
  sorted.slice(1, 3).forEach(([r, n]) => { if (pct(n, tot) >= 20) out.push({ e: REASONS[r].ico, t: `<b>${REASONS[r].label}</b> bhi ${pct(n, tot)}% hai`, d: REASONS[r].fix }); });
  const skips = ms.filter(m => m.kind === 'skip').length;
  if (pct(skips, tot) >= 35) out.push({ e: '⏭', t: `Attempt na kiye gaye questions ${pct(skips, tot)}% hain`, d: 'Jo aate hain wo chhutne nahi chahiye. Easy/GA-English pehle karo, phir baaki; sure ho to attempt karo.' });
  const a = agg(T, keys);
  if (a.wrong && a.acc < 75 && T.length) out.push({ e: '➖', t: `Galat answers se har test me ~<b>${f2(a.wrong * ng() / T.length)}</b> marks kat rahe hain`, d: 'Accuracy 75% se upar laao; 50-50 me elimination ke baad hi mark karo.' });
  const tw = topWeak(ms, 1)[0];
  if (tw && tw.n >= 3) out.push({ e: '🎯', t: `<b>${esc(tw.name)}</b> me ${tw.n} galtiyan`, d: `Is topic ka dedicated revision slot banao. Mukhya reason: ${REASONS[tw.top].label}.` });
  if (T.length >= 3) {
    const sc = T.map(t => agg([t], keys).score), lastv = sc[sc.length - 1], avgPrev = sum(sc.slice(0, -1)) / (sc.length - 1);
    out.push(lastv >= avgPrev ? { e: '📈', t: 'Trend positive hai!', d: `Pichla score (${f2(lastv)}) pehle ke average (${f2(avgPrev)}) se upar hai. Isi routine ko pakde raho.` } : { e: '📉', t: 'Pichla test average se neeche gaya', d: `Pichla ${f2(lastv)} vs average ${f2(avgPrev)}. Sabse badi reason category par kaam karo.` });
  }
  return out;
}
function V_analysis() {
  const f = UI.an, keys = analysisKeys(), all = sortedTests(), idx = {}; all.forEach((t, i) => { idx[t.id] = i + 1; });
  let T = all.filter(t => keys.some(k => t.sections[k])); if (f.range !== 'all') T = T.slice(-Number(f.range));
  const chips = [['merit', 'Merit'], ['all', 'Sab'], ...activeSubs().map(s => [s.id, short(s)])];
  let h = segTabs('analysis') + `<div class="chips row" style="margin-bottom:10px">${chips.map(([k, l]) => `<button class="chip ${f.sec === k ? 'on' : ''}" data-act="anSec" data-k="${k}">${esc(l)}</button>`).join('')}</div><div class="seg">${[['5', 'Last 5'], ['10', 'Last 10'], ['all', 'Sab']].map(([k, l]) => `<button class="${f.range === k ? 'on' : ''}" data-act="anRange" data-k="${k}">${l}</button>`).join('')}</div>`;
  if (!T.length) return page(h + empty('📊', 'Analysis ke liye data chahiye', 'Kam se kam ek test add karo (aur galtiyan log karo).', `<button class="btn primary" data-act="fabTest">${icon('plus', 18)} Test add karo</button><button class="btn ghost" data-act="loadDemo">Demo data</button>`));
  const a = agg(T, keys), ids = new Set(T.map(t => t.id)), ms = S.mistakes.filter(m => ids.has(m.testId) && keys.includes(m.sid)), needTot = a.wrong + a.skip;
  const label = f.sec === 'merit' ? 'Merit' : f.sec === 'all' ? 'Overall' : short(sub(f.sec));
  const scs = T.map(t => agg([t], keys).score), mean = sum(scs) / scs.length, sd = Math.sqrt(sum(scs, x => (x - mean) ** 2) / scs.length);
  h += `<div class="grid2"><div class="card stat"><b>${Math.round(a.acc)}%</b><span>Accuracy (sahi / attempt)</span></div><div class="card stat"><b>${Math.round(a.attPct)}%</b><span>Attempt rate</span></div><div class="card stat"><b>${f2(a.score / T.length)}</b><span>Avg score / ${f2(a.max / T.length)}</span></div><div class="card stat"><b class="neg">−${f2(a.wrong * ng() / T.length)}</b><span>Negative marks / test</span></div></div>`;
  h += `<div class="card"><div class="g2s"><div><b>${f2(Math.max(...scs))}</b><small>Best</small></div><div><b>${f2(Math.min(...scs))}</b><small>Worst</small></div><div><b>±${f2(sd)}</b><small>Consistency</small></div><div><b>${T.length}</b><small>Tests</small></div></div></div>`;
  if (ms.length < needTot) h += `<div class="warnbar"><span>⚠️</span><div><b>Analysis adhoora hai:</b> ${needTot} galat/skip me se sirf ${ms.length} log hue hain. Test detail me baaki add karo.</div></div>`;
  const lb = T.map(t => 'T' + idx[t.id]);
  h += `<div class="card"><h3>${esc(label)} score trend<small>T = test number</small></h3>${lineChart(scs, lb, 'var(--acc)', { target: f.sec === 'merit' && S.profile.target ? S.profile.target : undefined })}</div><div class="card"><h3>${esc(label)} accuracy trend<small>%</small></h3>${lineChart(T.map(t => agg([t], keys).acc), lb, '#34d399', { min: 0, max: 100, fmt: v => Math.round(v) + '%' })}</div>`;
  if (!ms.length) return page(h + `<div class="card"><p class="muted center small">Is selection me koi mistake log nahi hui. Test detail me galat/skip questions ka topic aur reason add karo, phir yahan reason breakdown aur weak topics dikhenge.</p></div>`);
  const rc = countBy(ms, m => m.reason), items = REASON_KEYS.filter(r => rc[r]).map(r => ({ v: rc[r], color: REASONS[r].color, r })).sort((x, y) => y.v - x.v);
  h += `<div class="card"><h3>Galtiyan kyun hui? <small>${ms.length} logged</small></h3><div class="row" style="gap:16px">${donut(items, ms.length, ms.length, 'mistakes')}<div class="legend">${items.map(i => `<div><i style="background:${i.color}"></i><span>${REASONS[i.r].ico} ${REASONS[i.r].short}</span><b>${pct(i.v, ms.length)}%</b></div>`).join('')}</div></div></div>`;
  const lost = {}; ms.forEach(m => { lost[m.reason] = (lost[m.reason] || 0) + (m.kind === 'wrong' ? mc() + ng() : mc()); });
  const lostTot = sum(Object.values(lost)), rec = (lost.silly || 0) + (lost.forgot || 0) + (lost.confused || 0);
  h += `<div class="card"><h3>💸 Marks kahan gaye?<small>${f2(lostTot)} total</small></h3>${REASON_KEYS.filter(r => lost[r]).sort((x, y) => lost[y] - lost[x]).map(r => `<div class="hbar-row"><div class="hb-t"><b>${REASONS[r].ico} ${REASONS[r].short}</b><span>${f2(lost[r])} marks · ${f2(lost[r] / T.length)}/test</span></div><div class="hbar"><i style="width:${pct(lost[r], lostTot)}%;background:${REASONS[r].color}"></i></div></div>`).join('')}<p class="note">Silly + Yaad nahi + Confuse theek kar lo to har test me ~<b>${f2(rec / T.length)}</b> marks badh sakte hain.</p></div>`;
  const wk = topWeak(ms, 9), kc = countBy(ms, m => m.kind);
  h += `<div class="card"><h3>Topic-wise kamzori<small>tap = notes dekho</small></h3>${wk.map(w => {
    const parts = REASON_KEYS.filter(r => w.r[r]).map(r => `<i style="width:${w.r[r] / w.n * 100}%;background:${REASONS[r].color}"></i>`).join('');
    return `<button class="hbar-row block" data-act="nbTopic" data-sid="${w.sid}" data-id="${w.tid || ''}"><div class="hb-t"><b>${secDot(w.sid)} ${esc(w.name)}</b><span>${w.n} galti</span></div><div class="hbar" style="width:${Math.max(14, w.n / wk[0].n * 100)}%">${parts}</div><div class="hb-tag">${REASONS[w.top].ico} ${REASONS[w.top].short}: ${REASONS[w.top].fix.split(/[.:;/]/)[0]}</div></button>`;
  }).join('')}<p class="small muted" style="margin-top:4px">❌ Galat: ${kc.wrong || 0} · ⏭ Skip: ${kc.skip || 0}</p></div>`;
  if (keys.length > 1) {
    h += `<div class="card"><h3>Subject × Reason<small>kitni galtiyan</small></h3><div class="heat"><span></span>${REASON_KEYS.map(r => `<span class="hh">${REASONS[r].ico}</span>`).join('')}${keys.filter(k => ms.some(m => m.sid === k)).map(k => {
      const c = countBy(ms.filter(m => m.sid === k), m => m.reason), mxv = Math.max(1, ...REASON_KEYS.map(r => c[r] || 0));
      return `<span class="hl" style="color:${sub(k).color}">${esc(short(sub(k)))}</span>${REASON_KEYS.map(r => { const n = c[r] || 0; return `<span class="hc" style="background:${hexa(REASONS[r].color, n ? .15 + .6 * n / mxv : .05)}">${n || ''}</span>`; }).join('')}`;
    }).join('')}</div></div>`;
  }
  const ins = insightsFor(T, ms, keys);
  if (ins.length) h += `<div class="card"><h3>💡 Smart insights</h3>${ins.map(i => `<div class="ins"><span class="e">${i.e}</span><div><b>${i.t}</b><p>${i.d}</p></div></div>`).join('')}</div>`;
  return page(h);
}

/* ---------- notebook ---------- */
function notesFiltered() {
  const f = UI.nb, q = f.q.trim().toLowerCase();
  return S.mistakes.filter(m => (f.status === 'all' || (f.status === 'done' ? m.done : f.status === 'pending' ? !m.done : cardDue(m))) && (f.sid === 'all' || m.sid === f.sid) && (f.reason === 'all' || m.reason === f.reason) && (!f.tid || m.tid === f.tid) && (!q || (m.q + ' ' + m.ans + ' ' + tName(m)).toLowerCase().includes(q))).sort((a, b) => b.created - a.created);
}
function nbListHtml() {
  const f = UI.nb, list = notesFiltered();
  if (!list.length) return empty('📓', f.status === 'done' ? 'Abhi kuch revise nahi hua' : f.status === 'due' ? 'Aaj kuch due nahi 🎉' : 'Notebook khaali hai', 'Test ki galtiyan ya apne manual notes yahan jama hote hain. + dabake naya point jodo.', '');
  return list.slice(0, f.limit).map(m => mistakeCard(m)).join('') + (list.length > f.limit ? `<button class="btn ghost block" data-act="nbMore">Aur dikhao (${list.length - f.limit})</button>` : '');
}
function V_notebook() {
  const f = UI.nb, list = notesFiltered(), q = list.filter(m => !m.done && (f.status === 'pending' || f.status === 'all' ? true : cardDue(m)));
  const stat = [['due', `🔁 Due (${S.mistakes.filter(cardDue).length})`], ['pending', 'Baaki'], ['done', 'Revised'], ['all', 'Sab']];
  let h = segTabs('notebook') + `<div class="seg">${stat.map(([k, l]) => `<button class="${f.status === k ? 'on' : ''}" data-act="nbStatus" data-k="${k}">${l}</button>`).join('')}</div>
    <div class="search">${icon('search', 18)}<input class="inp" id="nbQ" placeholder="Question, answer ya topic…" value="${esc(f.q)}"></div>
    <div class="chips row" style="margin-bottom:8px">${[['all', 'Sab'], ...activeSubs().map(s => [s.id, short(s)])].map(([k, l]) => `<button class="chip ${f.sid === k ? 'on' : ''}" style="--c:${k === 'all' ? 'var(--acc)' : sub(k).color}" data-act="nbSid" data-k="${k}">${esc(l)}</button>`).join('')}</div>
    <div class="chips row" style="margin-bottom:12px">${[['all', 'Har reason'], ...REASON_KEYS.map(r => [r, REASONS[r].ico + ' ' + REASONS[r].short])].map(([k, l]) => `<button class="chip ${f.reason === k ? 'on' : ''}" style="--c:${k === 'all' ? 'var(--acc)' : REASONS[k].color}" data-act="nbReason" data-k="${k}">${l}</button>`).join('')}</div>`;
  if (f.tid) h += `<div class="chips" style="margin-bottom:12px"><button class="chip on" data-act="nbClearTopic">Topic: ${esc((topic(f.tid) || {}).name || '?')} <span class="x">✕</span></button></div>`;
  h += `<div class="row" style="margin:0 2px 12px;justify-content:space-between"><span class="muted small" id="nbCount">${list.length} points</span>${q.length ? `<button class="btn primary sm" data-act="startRevise">🃏 Revise karo (${q.length})</button>` : ''}</div><div id="nbList">${nbListHtml()}</div>`;
  return page(h);
}

/* ---------- flashcards (spaced repetition) ---------- */
let RV = null;
function startRevise(ids) {
  if (!ids.length) return toast('Revise karne ke liye kuch nahi bacha 🎉', 'ok');
  RV = { queue: [...ids], total: ids.length, yes: 0, again: 0, flip: false };
  const root = $('#rvRoot'); root.innerHTML = '<div class="rv" id="rvBox"></div>'; root.classList.remove('open');
  rvRender();
  requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add('open')));
  pushLayer(instant => { RV = null; root.classList.remove('open'); if (instant) root.innerHTML = ''; else setTimeout(() => { if (!RV) root.innerHTML = ''; }, 400); });
}
function rvButtons() {
  return RV.flip ? `<div class="rv-btns"><button class="btn danger" data-act="rvNo">🔁 Bhool gaya</button><button class="btn ghost" data-act="rvHard">😅 Mushkil</button><button class="btn primary" data-act="rvYes">✓ Yaad hai</button></div>` : `<button class="btn ghost block" data-act="rvFlip" style="padding:16px">Answer dikhao</button>`;
}
function rvRender() {
  const box = $('#rvBox'); if (!box) return;
  const left = RV.queue.length, doneN = RV.total - left;
  const top = `<div class="rv-top"><button class="ibtn" data-act="rvClose" aria-label="Band">${icon('close', 20)}</button><div class="rv-prog"><i style="transform:scaleX(${doneN / RV.total})"></i></div><span>${doneN}/${RV.total}</span></div>`;
  if (!left) { box.innerHTML = `${top}<div class="rv-end"><div class="big">🎉</div><h2>Revision complete!</h2><p>${RV.yes} yaad · ${RV.again} dobara dekhne hain</p><button class="btn primary block" data-act="rvClose">Badhiya, band karo</button></div>`; return; }
  const m = S.mistakes.find(x => x.id === RV.queue[0]);
  if (!m) { RV.queue.shift(); return rvRender(); }
  const R = REASONS[m.reason] || REASONS.silly, s = sub(m.sid);
  box.innerHTML = `${top}<div class="fc ${RV.flip ? 'flip' : ''}" data-act="rvFlip"><div class="fc-in"><div class="face front"><div class="tags"><span class="badge" style="${tint(s.color)}">${s.emoji} ${esc(short(s))}</span>${reasonBadge(m.reason)}</div><div class="qtxt ${m.q && m.q.length > 80 ? 'sm' : ''}">${m.q ? esc(m.q) : `Topic:<br>${esc(tName(m))}`}</div><div class="hint">${m.q ? 'Socho, phir tap karke answer dekho' : 'Is topic ke points yaad karo, phir tap karo'}</div></div>
    <div class="face back"><div class="tags"><span class="badge" style="background:rgba(255,255,255,.16);color:#fff">${esc(tName(m))}</span></div><div class="qtxt ${m.ans && m.ans.length > 80 ? 'sm' : ''}">${m.ans ? esc(m.ans) : 'Notes se is topic ko ek baar padho'}</div><div class="tip">${R.ico} ${R.fix}</div></div></div></div><div id="rvBtns">${rvButtons()}</div>`;
}
function rvAnswer(g) {
  const id = RV.queue.shift(), m = S.mistakes.find(x => x.id === id);
  if (m) {
    if (g === 'good') { srGood(m); RV.yes++; } else if (g === 'hard') { srHard(m); RV.yes++; } else { srAgain(m); RV.again++; RV.queue.push(id); }
    S.revLog[today()] = (S.revLog[today()] || 0) + 1; save();
  }
  RV.flip = false; rvRender();
  if (!RV.queue.length) checkProgress();
}
const closeRevise = () => closeLayer(() => render(true));

/* ---------- add / edit test ---------- */
let TF = null;
function openTestSheet(id) {
  const subs = activeSubs(); if (!subs.length) return toast('Pehle Syllabus tab me subjects add karo');
  const t = id ? S.tests.find(x => x.id === id) : null, lastT = sortedTests().slice(-1)[0], defTot = { ga: 25, eng: 25, math: 20, reas: 20 };
  TF = { id: id || null, type: t ? (t.type || 'Full Mock') : (lastT && lastT.type) || 'Full Mock', incl: {} };
  const list = [...subs]; if (t) Object.keys(t.sections).forEach(k => { if (!list.some(s => s.id === k)) list.push(sub(k)); });
  list.forEach(s => { TF.incl[s.id] = t ? !!t.sections[s.id] : (lastT ? !!lastT.sections[s.id] || !Object.keys(lastT.sections).length : true); });
  if (!t && !Object.values(TF.incl).some(Boolean)) list.forEach(s => { TF.incl[s.id] = true; });
  TF.list = list.map(s => s.id);
  const blocks = list.map(s => {
    const k = s.id, sc = t && t.sections[k], lt = lastT && lastT.sections[k], tot = sc ? sc.total : (lt ? lt.total : defTot[k] || 25);
    return `<div class="secblk ${TF.incl[k] ? '' : 'hidden'}" id="blk-${k}" style="--c:${s.color}"><div class="sb-h"><b>${s.emoji} ${esc(s.name)}</b>${s.merit ? '<span class="badge" style="background:var(--acc-soft);color:var(--acc-t)">MERIT</span>' : ''}<span class="sk" id="sk-${k}"></span></div><div class="g3"><div><small>Total Qs</small><input class="inp num tfin" data-k="${k}" id="t-${k}" type="number" inputmode="numeric" min="0" value="${tot}"></div><div><small>Sahi ✔</small><input class="inp num tfin" data-k="${k}" id="c-${k}" type="number" inputmode="numeric" min="0" value="${sc ? sc.correct : ''}" placeholder="0"></div><div><small>Galat ✘</small><input class="inp num tfin" data-k="${k}" id="w-${k}" type="number" inputmode="numeric" min="0" value="${sc ? sc.wrong : ''}" placeholder="0"></div></div></div>`;
  }).join('');
  openSheet(t ? 'Test edit karo' : 'Naya mock test', `<label class="lbl">Test ka naam</label><input class="inp" id="tfName" maxlength="40" value="${esc(t ? t.name : 'Mock Test ' + (S.tests.length + 1))}">
    <div class="g2"><div><label class="lbl">Date</label><input class="inp" id="tfDate" type="date" max="${today()}" value="${t ? t.date : today()}"></div><div><label class="lbl">Time (min)</label><input class="inp num" id="tfMins" type="number" inputmode="numeric" min="0" max="300" placeholder="optional" value="${t && t.mins ? t.mins : ''}"></div></div>
    <label class="lbl">Type</label><div class="chips" id="tfTypes">${TEST_TYPES.map(k => `<button class="chip ${TF.type === k ? 'on' : ''}" data-act="tfTypeSet" data-k="${k}">${k}</button>`).join('')}</div>
    <label class="lbl">Sections</label><div class="chips">${list.map(s => `<button class="chip ${TF.incl[s.id] ? 'on' : ''}" style="--c:${s.color}" data-act="tfToggle" data-k="${s.id}">${esc(s.name)}</button>`).join('')}</div>${blocks}<p class="muted small" style="margin-top:12px">Skip (attempt nahi kiye) apne aap Total − Sahi − Galat se nikal jaayenge.</p>`,
    `<button class="btn primary" data-act="tfSave">${t ? 'Update karo' : 'Save karo'}</button>`);
  TF.list.forEach(updateSkip);
}
function updateSkip(k) {
  const el = $('#sk-' + k); if (!el) return;
  const tot = toInt($('#t-' + k).value), c = toInt($('#c-' + k).value), w = toInt($('#w-' + k).value), bad = c + w > tot;
  el.innerHTML = bad ? '<span class="neg">Sahi+Galat &gt; Total!</span>' : `Skip ${tot - c - w} · Score ${f2(c * mc() - w * ng())}`;
}

/* ---------- add / edit mistake ---------- */
let MS = null, MSlast = { sid: null, kind: 'wrong' };
function pendingCombo(t, sids) {
  let best = null;
  for (const k of [...sids].sort((a, b) => (sub(b).merit ? 1 : 0) - (sub(a).merit ? 1 : 0))) {
    const s = secStat(t.sections[k]);
    if (s.wrong > loggedCount(t.id, k, 'wrong')) return { sid: k, kind: 'wrong' };
    if (!best && s.skip > loggedCount(t.id, k, 'skip')) best = { sid: k, kind: 'skip' };
  }
  return best;
}
function openMistakeSheet(o) {
  if (!S.subjects.length) return toast('Pehle subjects add karo');
  const m = o.id ? S.mistakes.find(x => x.id === o.id) : null, tid = o.testId || (m && m.testId) || null, t = tid ? S.tests.find(x => x.id === tid) : null;
  const sids = t ? Object.keys(t.sections) : activeSubs().map(s => s.id);
  const pc = t && !m ? pendingCombo(t, sids) : null;
  let sid = m ? m.sid : pc ? pc.sid : (MSlast.sid && sids.includes(MSlast.sid) ? MSlast.sid : sids[0]);
  if (!sids.includes(sid)) sid = sids[0];
  MS = { id: m ? m.id : null, testId: t ? t.id : null, sids, sid, kind: m ? m.kind : t ? (pc ? pc.kind : MSlast.kind) : 'note', tid: m ? m.tid : '', reason: m ? m.reason : '', qty: 1 };
  openSheet(m ? 'Mistake edit karo' : t ? 'Mistake log karo' : 'Naya point note karo',
    `<div class="hintbar" id="msHint"></div><label class="lbl">Subject</label><div class="chips" id="msSecs"></div>
    ${t ? `<label class="lbl">Type</label><div class="seg" id="msKinds" style="margin-bottom:0"><button data-act="msKind" data-k="wrong">❌ Galat kiya</button><button data-act="msKind" data-k="skip">⏭ Attempt nahi kiya</button></div>` : ''}
    <label class="lbl">Topic</label><div class="chips box" id="msTopics"></div>
    <div class="newtopic" id="msNewRow"><input class="inp" id="msNewTopic" placeholder="Naye topic ka naam" maxlength="40"><button class="btn primary sm" data-act="msAddTopic">Add</button></div>
    <label class="lbl">Kyun hua?</label><div class="chips" id="msReasons">${REASON_KEYS.map(r => `<button class="chip" style="--c:${REASONS[r].color}" data-act="msReason" data-k="${r}">${REASONS[r].ico} ${REASONS[r].label}</button>`).join('')}</div>
    <label class="lbl">Question / Point (optional)</label><textarea class="inp" id="msQ" rows="2" placeholder="Jaise: Dandi March kab shuru hui?">${m ? esc(m.q) : ''}</textarea>
    <label class="lbl">Sahi answer / seekh (optional)</label><textarea class="inp" id="msA" rows="2" placeholder="Jaise: 12 March 1930">${m ? esc(m.ans) : ''}</textarea>
    ${m ? '' : `<label class="lbl">Aise kitne questions?</label><div class="qty"><button data-act="msQty" data-d="-1">−</button><b id="msQty">1</b><button data-act="msQty" data-d="1">+</button><small>Jyada ho to text sirf pehle question par lagta hai</small></div>`}`,
    m ? `<button class="btn primary" data-act="msSave" data-next="0">Update karo</button>` : `<button class="btn ghost" data-act="msSave" data-next="0">Save & Band</button><button class="btn primary" data-act="msSave" data-next="1">Save & Next</button>`);
  msRender();
}
function msRender() {
  $('#msSecs').innerHTML = MS.sids.map(k => `<button class="chip ${MS.sid === k ? 'on' : ''}" style="--c:${sub(k).color}" data-act="msSec" data-k="${k}">${sub(k).emoji} ${esc(short(sub(k)))}</button>`).join('');
  const kinds = $('#msKinds'); if (kinds) $$('button', kinds).forEach(b => b.classList.toggle('on', b.dataset.k === MS.kind));
  msTopics(); $$('#msReasons .chip').forEach(c => c.classList.toggle('on', c.dataset.k === MS.reason)); msHint();
}
function msTopics() {
  const list = topicsOf(MS.sid);
  $('#msTopics').innerHTML = list.map(t => `<button class="chip ${MS.tid === t.id ? 'on' : ''}" style="--c:${sub(MS.sid).color}" data-act="msTopic" data-id="${t.id}">${esc(t.name)}</button>`).join('') + `<button class="chip dash" data-act="msNew">＋ Naya</button>`;
}
function msHint() {
  const el = $('#msHint'); if (!el) return;
  if (!MS.testId) { el.textContent = 'Manual note: kisi bhi source (book, class, PYQ) ka point jo yaad rakhna hai.'; return; }
  const t = S.tests.find(x => x.id === MS.testId), s = secStat(t.sections[MS.sid]);
  el.textContent = `${short(sub(MS.sid))} · Galat ${loggedCount(t.id, MS.sid, 'wrong')}/${s.wrong} log · Skip ${loggedCount(t.id, MS.sid, 'skip')}/${s.skip} log`;
}

/* ============ STATS · BADGES · SETTINGS · APPEARANCE · MENU · ONBOARDING ============ */
function V_stats() {
  const td = today(), r = UI.st.range, dm = dayMap(), st = streakInfo(), L = lvlInfo(), goal = Math.max(1, S.profile.dailyGoal);
  let vals, labels, hi, gl, from;
  if (r === 'week') { const ds = [...Array(7)].map((_, i) => addDays(td, i - 6)); vals = ds.map(d => Math.floor((dm[d] || 0) / 60)); labels = ds.map(d => DOW[dowOf(d)]); hi = 6; gl = goal; from = ds[0]; }
  else if (r === 'month') { const ds = [...Array(30)].map((_, i) => addDays(td, i - 29)); vals = ds.map(d => Math.floor((dm[d] || 0) / 60)); labels = ds.map(d => String(parseD(d).getDate())); hi = 29; gl = goal; from = ds[0]; }
  else { const w0 = weekStart(td), ws = [...Array(12)].map((_, i) => addDays(w0, -7 * (11 - i))); vals = ws.map(w => Math.floor(sum([...Array(7)].map((_, i) => dm[addDays(w, i)] || 0)) / 60)); labels = ws.map(w => String(parseD(w).getDate())); hi = 11; gl = goal * 7; from = '0000-00-00'; }
  const ses = S.sessions.filter(x => x.date >= from), tot = sum(ses, x => x.secs), nDays = r === 'week' ? 7 : r === 'month' ? 30 : Math.max(1, Math.min(84, S.sessions.length ? dayDiff(S.sessions.reduce((m, x) => x.date < m ? x.date : m, td), td) + 1 : 1));
  let h = `<section class="hero"><p>Total padhai</p><h2>${fmtDur(totalSecs())}</h2><div class="hero-grid"><div><b>${S.sessions.length}</b><span>sessions</span></div><div><b>${st.cur}</b><span>🔥 streak (best ${st.best})</span></div><div><b>Lv ${L.L}</b><span>${L.x} XP</span></div></div></section>`;
  h += `<div class="seg">${[['week', '7 din'], ['month', '30 din'], ['all', '12 hafte']].map(([k, l]) => `<button class="${r === k ? 'on' : ''}" data-act="stRange" data-k="${k}">${l}</button>`).join('')}</div>`;
  h += `<div class="card"><h3>⏱ Padhai ka time<small>${fmtDur(tot)} · avg ${fmtDur(tot / nDays)}/din</small></h3>${barChart(vals, labels, { goal: gl, hi, fmt: v => v >= 60 ? f1(v / 60) + 'h' : v + 'm', color: 'var(--acc)' })}</div>`;
  const bySub = {}; ses.forEach(x => { bySub[x.sid || ''] = (bySub[x.sid || ''] || 0) + x.secs; });
  const items = Object.entries(bySub).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ v, color: sub(k).color, k }));
  if (items.length) h += `<div class="card"><h3>📚 Subject-wise time</h3><div class="row" style="gap:16px">${donut(items, tot, fmtHrs(tot), 'total')}<div class="legend">${items.map(i => `<div><i style="background:${i.color}"></i><span>${sub(i.k).emoji} ${esc(short(sub(i.k)))}</span><b>${pct(i.v, tot)}%</b></div>`).join('')}</div></div></div>`;
  const hrs = Array(24).fill(0); ses.filter(x => !x.manual).forEach(x => { hrs[new Date(x.ts).getHours()] += x.secs; });
  if (sum(hrs) > 0) {
    let bi = 0, bv = -1; for (let i = 0; i < 24; i++) { const v = hrs[i] + hrs[(i + 1) % 24] + hrs[(i + 2) % 24]; if (v > bv) { bv = v; bi = i; } }
    const fh = x => to12(pad(x % 24) + ':00');
    h += `<div class="card"><h3>🕒 Kab sabse zyada padhte ho?</h3>${barChart(hrs.map(x => Math.round(x / 60)), hrs.map((_, i) => i % 6 === 0 ? fh(i).replace(':00', '') : ''), { h: 120, color: 'var(--acc2)' })}<p class="note">Best focus window: <b>${fh(bi)} – ${fh(bi + 3)}</b>. Mushkil topics isi time par rakho.</p></div>`;
  }
  const w8 = [...Array(7)].map(() => 0); for (let i = 0; i < 56; i++) { const d = addDays(td, -i); w8[dowOf(d)] += (dm[d] || 0) / 60 / 8; }
  if (sum(w8) > 0) { const bd = w8.indexOf(Math.max(...w8)); h += `<div class="card"><h3>📆 Din-wise average (8 hafte)</h3>${barChart(w8.map(Math.round), DOW, { hi: bd, fmt: v => v + 'm' })}<p class="note">Sabse productive din: <b>${DOW[bd]}</b> (~${fmtDur(w8[bd] * 60)}). Sabse kam: <b>${DOW[w8.indexOf(Math.min(...w8))]}</b>.</p></div>`; }
  h += `<div class="card"><h3>🗓 Consistency<small>last 15 weeks</small></h3>${heatmap(15)}<div class="hm-leg"><span>kam</span><i style="background:var(--acc);opacity:.28"></i><i style="background:var(--acc);opacity:.46"></i><i style="background:var(--acc);opacity:.72"></i><i style="background:var(--acc)"></i><span>goal</span></div></div>`;
  const dys = Object.keys(dm), bestDay = dys.reduce((m, d) => (dm[d] > (dm[m] || 0) ? d : m), ''), longest = Math.max(0, ...S.sessions.map(x => x.secs));
  h += `<div class="card"><h3>🏅 Records</h3><div class="g2s"><div><b>${longest ? fmtDur(longest) : '–'}</b><small>Sabse lamba session</small></div><div><b>${bestDay ? fmtDur(dm[bestDay]) : '–'}</b><small>Best din ${bestDay ? '(' + fmtD(bestDay) + ')' : ''}</small></div><div><b>${S.sessions.length ? fmtDur(totalSecs() / S.sessions.length) : '–'}</b><small>Avg session</small></div><div><b>${dys.filter(d => dm[d] >= S.profile.streakMin * 60).length}</b><small>Goal wale din</small></div></div></div>`;
  const act = activeSubs();
  if (act.length) h += `<div class="card"><h3>📘 Syllabus progress</h3>${act.map(s => { const p = subProg(s.id); return `<button class="hbar-row block" data-act="openSubject" data-id="${s.id}"><div class="hb-t"><b>${s.emoji} ${esc(s.name)}</b><span>${p.done}/${p.n} · ${p.pct}%</span></div><div class="hbar"><i style="width:${p.pct}%;background:${s.color}"></i></div></button>`; }).join('')}</div>`;
  const T = sortedTests();
  if (T.length) { const hs = T.map(t => { const x = headScore(t); return x.max ? x.score / x.max * 100 : 0; }); h += `<button class="card press row" data-act="goTab" data-k="analysis"><div class="sp"><b>📝 Mock tests</b><br><small class="muted">${T.length} tests · avg ${Math.round(sum(hs) / hs.length)}% · best ${Math.round(Math.max(...hs))}%</small></div>${spark(hs.slice(-8), 'var(--acc)')}${icon('next', 16)}</button>`; }
  const pr = S.tasks, td2 = pr.filter(t => t.done).length;
  h += `<div class="grid2"><div class="card stat"><b>${td2}</b><span>Tasks complete / ${pr.length}</span></div><div class="card stat"><b>${S.topics.filter(t => t.status === 'done').length}</b><span>Topics complete / ${S.topics.length}</span></div></div>`;
  return page(h);
}

function V_badges() {
  const L = lvlInfo(), got = BADGES.filter(b => S.badges[b[0]]).length;
  let h = `<section class="hero"><p>${L.title}</p><h2>Level ${L.L}</h2><div class="target">${L.x} XP · agle level tak ${L.hi - L.x} XP<div class="tr"><i style="width:${L.p * 100}%"></i></div></div></section>
    <div class="card"><h3>XP kaise milta hai?</h3><p class="muted small">1 XP / minute padhai · 30 / test · 15 / topic complete · 10 / revision · 8 / task · 5 / habit · 3 / flashcard</p></div>
    <div class="sec-title"><span>Badges ${got}/${BADGES.length}</span></div><div class="bgrid">`;
  h += BADGES.map(b => { const [c, t] = b[4](), ok = !!S.badges[b[0]]; return `<div class="bdg ${ok ? 'on' : ''}"><div class="be">${b[1]}</div><b>${b[2]}</b><small>${ok ? '✓ ' + fmtD(S.badges[b[0]]) : b[3]}</small>${ok ? '' : `<div class="stack" style="height:5px;margin-top:8px"><i style="width:${clamp(c / t * 100, 0, 100)}%;background:var(--acc)"></i></div>`}</div>`; }).join('');
  return page(h + '</div>');
}

function V_settings() {
  const pr = S.profile, st = S.settings, P = st.pomo, subs = S.subjects;
  const sw = (on, act) => `<button class="sw ${on ? 'on' : ''}" data-act="${act}" aria-pressed="${on}"></button>`;
  const inp = (path, val, o = {}) => `<input class="inp ${o.w || ''}" data-set="${path}" ${o.type === 'text' ? 'type="text"' : o.type === 'date' ? 'type="date"' : 'type="number" inputmode="decimal" data-n="1"'} ${o.step ? `step="${o.step}"` : ''} value="${esc(val === 0 && o.blank ? '' : val)}" ${o.ph ? `placeholder="${o.ph}"` : ''}>`;
  return page(`
  <div class="card"><h3>👤 Profile & goal</h3>
    <div class="set-row"><div><b>Tumhara naam</b></div>${inp('profile.name', pr.name, { type: 'text', w: 'wide', ph: 'Naam' })}</div>
    <div class="set-row"><div><b>Exam ka naam</b></div>${inp('profile.exam', pr.exam, { type: 'text', w: 'wide' })}</div>
    <div class="set-row"><div><b>Exam date</b><small>Countdown aur pace ke liye</small></div>${inp('profile.examDate', pr.examDate, { type: 'date', w: 'wide' })}</div>
    <div class="set-row"><div><b>Target merit score</b><small>Analysis graph me target line</small></div>${inp('profile.target', pr.target, { blank: 1, ph: '0' })}</div>
    <div class="set-row"><div><b>Daily goal (minutes)</b><small>Ring aur streak ke liye</small></div>${inp('profile.dailyGoal', pr.dailyGoal)}</div>
    <div class="set-row"><div><b>Streak ke liye min. padhai</b><small>Minutes per din</small></div>${inp('profile.streakMin', pr.streakMin)}</div>
    <div class="set-row"><div><b>Din kab badalta hai?</b><small>Raat ko jaagte ho to late rakho</small></div></div>
    <div class="seg" style="margin:0">${[[0, '12 AM'], [3, '3 AM'], [4, '4 AM'], [5, '5 AM']].map(([k, l]) => `<button class="${pr.dayStart === k ? 'on' : ''}" data-act="setDayStart" data-k="${k}">${l}</button>`).join('')}</div></div>
  <div class="card"><h3>📚 Subjects</h3>${subs.length ? subs.map(s => `<div class="item tap" data-act="editSubject" data-id="${s.id}"><div class="ico" style="--c:${s.color}">${s.emoji}</div><div class="txt"><b>${esc(s.name)}</b><small>${topicsOf(s.id).length} topics${s.merit ? ' · MERIT' : ''}${s.archived ? ' · archived' : ''}</small></div>${icon('next', 16)}</div>`).join('') : '<p class="muted small">Koi subject nahi.</p>'}
    <div class="btn-row" style="margin-top:12px"><button class="btn ghost sm" data-act="fabSubject">${icon('plus', 16)} Subject add</button>${S.subjects.some(s => s.id === 'ga') ? '' : `<button class="btn ghost sm" data-act="loadPreset">SSC MTS syllabus</button>`}</div></div>
  <div class="card"><h3>✍️ Marking scheme</h3>
    <div class="set-row"><div><b>Sahi answer</b></div>${inp('settings.correct', st.correct, { step: .25 })}</div>
    <div class="set-row"><div><b>Galat answer (negative)</b><small>Apne exam pattern ke hisab se</small></div>${inp('settings.negative', st.negative, { step: .25 })}</div></div>
  <div class="card"><h3>⏱ Focus timer</h3>
    <div class="set-row"><div><b>Focus (min)</b></div>${inp('settings.pomo.focus', P.focus)}</div>
    <div class="set-row"><div><b>Chhota break (min)</b></div>${inp('settings.pomo.short', P.short)}</div>
    <div class="set-row"><div><b>Lamba break (min)</b></div>${inp('settings.pomo.long', P.long)}</div>
    <div class="set-row"><div><b>Lamba break har kitne session?</b></div>${inp('settings.pomo.every', P.every)}</div>
    <div class="set-row"><div><b>Auto break</b><small>Focus ke baad break khud shuru</small></div>${sw(P.autoBreak, 'setAutoBreak')}</div>
    <div class="set-row"><div><b>Screen on rakho</b><small>Timer ke dauran screen band na ho</small></div>${sw(st.wake, 'setWake')}</div>
    <div class="set-row"><div><b>Alarm sound</b></div>${sw(st.sound, 'setSound')}</div>
    <div class="set-row"><div><b>Vibration</b></div>${sw(st.haptics, 'setHaptic')}</div></div>
  <button class="card press row" data-act="goLook"><span class="bigemo">🎨</span><div class="sp"><b>Appearance</b><br><small class="muted">10 themes, accent, card style, font aur aur bhi</small></div>${icon('next', 16)}</button>
  <div class="card"><h3>💾 Data & backup</h3><p class="muted small" style="margin-bottom:12px">Data sirf is phone ke browser me save hai. Browser data clear karne se pehle backup le lo.</p>
    <div class="btn-row" style="margin-bottom:10px"><button class="btn ghost" data-act="doExport">${icon('down', 18)} Backup</button><button class="btn ghost" data-act="doImport">${icon('up', 18)} Restore</button></div>
    <div class="btn-row">${S.tests.some(t => t.demo) ? '<button class="btn ghost" data-act="rmDemo">Demo hatao</button>' : '<button class="btn ghost" data-act="loadDemo">Demo data</button>'}<button class="btn danger" data-act="resetAll">Sab reset</button></div></div>
  <p class="muted small center" style="padding:6px 0 0">Lakshya · tumhari taiyari, tumhare haath 🎯</p>`);
}

function V_look() {
  const st = S.settings;
  const seg = (o, opts) => `<div class="seg" style="margin-bottom:0">${opts.map(([k, l]) => `<button class="${st[o] === k ? 'on' : ''}" data-act="setOpt" data-o="${o}" data-k="${k}">${l}</button>`).join('')}</div>`;
  const th = list => `<div class="themes">${list.map(t => `<button class="th ${st.theme === t.id ? 'on' : ''}" data-theme="${t.id}" data-act="setTheme" data-k="${t.id}"><div class="thp"><i style="background:linear-gradient(135deg,${t.acc},${t.acc2})"></i><u></u><u></u></div><b>${t.name}</b>${st.theme === t.id ? `<span class="tk">${icon('check', 14)}</span>` : ''}</button>`).join('')}</div>`;
  return page(`<div class="lbl" style="margin-top:0">Dark themes</div>${th(THEMES.filter(t => !t.light))}<div class="lbl">Light themes</div>${th(THEMES.filter(t => t.light))}
    <div class="card" style="margin-top:16px"><h3>🎨 Accent rang</h3><div class="chips"><button class="chip ${!st.accent ? 'on' : ''}" data-act="setAccent" data-k="">Theme ka</button>${ACCENTS.map(a => `<button class="swatch ${st.accent === a.join() ? 'on' : ''}" style="background:linear-gradient(135deg,${a[0]},${a[1]})" data-act="setAccent" data-k="${a.join()}" aria-label="accent"></button>`).join('')}</div></div>
    <div class="card"><h3>🧩 UI options</h3>
      <div class="lbl" style="margin-top:0">Card style</div>${seg('card', [['soft', 'Soft'], ['outline', 'Outline'], ['elev', 'Elevated']])}
      <div class="lbl">Corners</div>${seg('radius', [['sharp', 'Sharp'], ['normal', 'Normal'], ['round', 'Round']])}
      <div class="lbl">Text size</div>${seg('fs', [['s', 'Chhota'], ['m', 'Normal'], ['l', 'Bada']])}
      <div class="lbl">Font</div>${seg('font', [['default', 'Clean'], ['serif', 'Classic'], ['mono', 'Mono']])}
      <div class="lbl">Density</div>${seg('density', [['cozy', 'Cozy'], ['compact', 'Compact']])}
      <div class="lbl">Navigation bar</div>${seg('nav', [['float', 'Floating'], ['bar', 'Classic bar']])}
      <div class="lbl">Animations</div>${seg('motion', [['full', 'Full'], ['lite', 'Light'], ['off', 'Off']])}
      <p class="muted small" style="margin-top:10px">Kam RAM wale phone par "Light" ya "Off" rakho.</p></div>`);
}

function openMenu() {
  const items = [['stats', 'chart', 'Stats', '#7c9cff'], ['notebook', 'book', 'Notebook', '#fb7185'], ['habits', 'habit', 'Habits', '#34d399'], ['timetable', 'table', 'Timetable', '#fbbf24'], ['badges', 'trophy', 'Badges', '#f59e0b'], ['look', 'palette', 'Themes', '#e879f9'], ['analysis', 'test', 'Test analysis', '#60a5fa'], ['settings', 'gear', 'Settings', '#94a3b8']];
  openSheet('Sab features', `<div class="menu">${items.map(([k, ic, l, c]) => `<button class="tile" data-act="menuGo" data-k="${k}"><span style="--c:${c}">${icon(ic)}</span><em>${l}</em></button>`).join('')}</div>`);
}

/* ---------- onboarding ---------- */
function showOnboarding() {
  UI.ob.theme = S.settings.theme; obRender();
  $('#obRoot').classList.add('on');
}
function obRender() {
  const o = UI.ob, root = $('#obRoot'), step = o.step, N = 4;
  const dots = `<div class="obdots">${[...Array(N)].map((_, i) => `<i class="${i === step ? 'on' : i < step ? 'dn' : ''}"></i>`).join('')}</div>`;
  let body = '';
  if (step === 0) body = `<div class="ob-emo">🎯</div><h1>Lakshya me swagat hai</h1><p>Syllabus, mock tests, focus timer aur revision: sab ek jagah. Chalo setup karte hain (30 second).</p><label class="lbl">Tumhara naam</label><input class="inp" data-ob="name" maxlength="20" placeholder="Naam likho" value="${esc(o.name)}">`;
  else if (step === 1) body = `<div class="ob-emo">📚</div><h1>Kis exam ki taiyari?</h1><div class="obopts"><button class="${o.preset === 'mts' ? 'on' : ''}" data-act="obPreset" data-k="mts"><b>SSC MTS</b><small>Ready syllabus: GA, English, Maths, Reasoning. Merit: GA + English</small></button><button class="${o.preset === 'custom' ? 'on' : ''}" data-act="obPreset" data-k="custom"><b>Kuch aur / khud banaunga</b><small>Khaali start, subjects khud add karo</small></button></div><label class="lbl">Exam ka naam</label><input class="inp" data-ob="exam" maxlength="30" value="${esc(o.exam)}"><label class="lbl">Exam date (pata ho to)</label><input class="inp" type="date" data-ob="date" value="${esc(o.date)}">`;
  else if (step === 2) body = `<div class="ob-emo">⏱</div><h1>Roz kitna padhna hai?</h1><p>Ye tumhara daily goal hoga. Baad me Settings se badal sakte ho.</p><div class="goalbox"><button data-act="obGoal" data-d="-30">−</button><div><b>${fmtDur(o.goal * 60)}</b><small>per din</small></div><button data-act="obGoal" data-d="30">+</button></div><div class="chips" style="justify-content:center;margin-top:14px">${[120, 180, 240, 360, 480].map(m => `<button class="chip ${o.goal === m ? 'on' : ''}" data-act="obGoalSet" data-k="${m}">${m / 60}h</button>`).join('')}</div>`;
  else body = `<div class="ob-emo">🎨</div><h1>Apna look chuno</h1><p>10 themes hain. Baad me Appearance me aur options milenge.</p><div class="themes">${THEMES.slice(0, 6).map(t => `<button class="th ${o.theme === t.id ? 'on' : ''}" data-theme="${t.id}" data-act="obTheme" data-k="${t.id}"><div class="thp"><i style="background:linear-gradient(135deg,${t.acc},${t.acc2})"></i><u></u><u></u></div><b>${t.name}</b></button>`).join('')}</div>`;
  root.innerHTML = `<div class="ob">${dots}<div class="ob-body" key="${step}">${body}</div><div class="btn-row obbtn">${step ? '<button class="btn ghost" data-act="obBack">Peeche</button>' : ''}<button class="btn primary" data-act="obNext">${step === N - 1 ? 'Shuru karein 🚀' : 'Aage'}</button></div></div>`;
}
function obFinish() {
  const o = UI.ob, p = S.profile;
  p.name = o.name.trim(); p.exam = o.exam.trim() || 'Meri Taiyari'; p.examDate = o.date; p.dailyGoal = o.goal; p.onboarded = true;
  S.settings.theme = o.theme;
  if (o.preset === 'mts' && !S.subjects.length) { const pr = buildPreset(); S.subjects = pr.subjects; S.topics = pr.topics; }
  applyTheme(); flushSave(); save();
  $('#obRoot').classList.remove('on'); setTimeout(() => { $('#obRoot').innerHTML = ''; }, 400);
  location.replace('#home'); render(); toast(`Swagat hai${p.name ? ', ' + p.name : ''}! 🎯`, 'ok');
}

/* ---------- task / block / habit sheets ---------- */
let TKF = null;
function openTaskSheet(id, date) {
  const t = id ? S.tasks.find(x => x.id === id) : null;
  TKF = { id: id || null, date: t ? t.date : (date || UI.pl.date || today()), sid: t ? t.sid : '', tid: t ? t.tid : '', est: t ? t.est : 30 };
  openSheet(t ? 'Task edit' : 'Naya task', `<label class="lbl">Kya karna hai?</label><input class="inp" id="tkTitle" maxlength="80" placeholder="Jaise: Percentage ke 20 questions" value="${t ? esc(t.title) : ''}">
    <label class="lbl">Subject</label><div class="chips" id="tkSubs"></div><label class="lbl">Topic (optional)</label><div class="chips box" id="tkTopics"></div>
    <label class="lbl">Kitna time?</label><div class="chips" id="tkEst">${[15, 30, 45, 60, 90, 120].map(m => `<button class="chip" data-act="tkEst" data-k="${m}">${m}m</button>`).join('')}</div>
    <div class="g2" style="margin-top:12px"><div><small>Date</small><input class="inp" id="tkDate" type="date" value="${TKF.date}"></div><div><small>Start time (optional)</small><input class="inp" id="tkTime" type="time" value="${t ? t.time || '' : ''}"></div></div>`,
    `${t ? `<button class="btn danger" style="flex:0 0 auto;padding:13px 16px" data-act="tkDelete" aria-label="Delete">${icon('trash', 18)}</button>` : ''}<button class="btn primary" data-act="tkSave">${t ? 'Update' : 'Add karo'}</button>`);
  tkRender();
}
function tkRender() {
  $('#tkSubs').innerHTML = `<button class="chip ${!TKF.sid ? 'on' : ''}" data-act="tkSub" data-id="">General</button>` + activeSubs().map(s => `<button class="chip ${TKF.sid === s.id ? 'on' : ''}" style="--c:${s.color}" data-act="tkSub" data-id="${s.id}">${s.emoji} ${esc(short(s))}</button>`).join('');
  $('#tkTopics').innerHTML = TKF.sid ? `<button class="chip ${!TKF.tid ? 'on' : ''}" data-act="tkTopic" data-id="">Koi nahi</button>` + topicsOf(TKF.sid).filter(t => t.status !== 'done' || t.id === TKF.tid).map(t => `<button class="chip ${TKF.tid === t.id ? 'on' : ''}" style="--c:${sub(TKF.sid).color}" data-act="tkTopic" data-id="${t.id}">${esc(t.name)}</button>`).join('') : '<span class="muted small">Pehle subject chuno</span>';
  $$('#tkEst .chip').forEach(c => c.classList.toggle('on', Number(c.dataset.k) === TKF.est));
}
let BKF = null;
function openBlockSheet(id) {
  const b = id ? S.blocks.find(x => x.id === id) : null;
  BKF = { id: id || null, days: b ? [...b.days] : [UI.tt.day], sid: b ? b.sid : (meritIds()[0] || (activeSubs()[0] || {}).id || '') };
  openSheet(b ? 'Slot edit' : 'Naya study slot', `<label class="lbl">Kin dino me?</label><div class="chips" id="bkDays"></div><label class="lbl">Subject</label><div class="chips" id="bkSubs"></div>
    <div class="g2"><div><label class="lbl">Start</label><input class="inp" id="bkStart" type="time" value="${b ? b.start : '06:00'}"></div><div><label class="lbl">End</label><input class="inp" id="bkEnd" type="time" value="${b ? b.end : '08:00'}"></div></div>
    <label class="lbl">Label (optional)</label><input class="inp" id="bkLabel" maxlength="40" placeholder="Jaise: Maths practice" value="${b ? esc(b.label || '') : ''}">`,
    `${b ? `<button class="btn danger" style="flex:0 0 auto;padding:13px 16px" data-act="bkDelete" aria-label="Delete">${icon('trash', 18)}</button>` : ''}<button class="btn primary" data-act="bkSave">${b ? 'Update' : 'Add karo'}</button>`);
  bkRender();
}
function bkRender() {
  $('#bkDays').innerHTML = DOW.map((d, i) => `<button class="chip ${BKF.days.includes(i) ? 'on' : ''}" data-act="bkDay" data-k="${i}">${d}</button>`).join('');
  $('#bkSubs').innerHTML = activeSubs().map(s => `<button class="chip ${BKF.sid === s.id ? 'on' : ''}" style="--c:${s.color}" data-act="bkSub" data-id="${s.id}">${s.emoji} ${esc(short(s))}</button>`).join('') || '<span class="muted small">Pehle subjects add karo</span>';
}
let HBF = null;
const HEMO = ['📰', '📖', '📝', '🏃', '😴', '📵', '💧', '🧘', '🥗', '✍️', '🎧', '🔁'];
function openHabitSheet(id) {
  const h = id ? S.habits.find(x => x.id === id) : null;
  HBF = { id: id || null, emoji: h ? h.emoji : '📰' };
  openSheet(h ? 'Habit edit' : 'Nayi habit', `<label class="lbl">Habit ka naam</label><input class="inp" id="hbName" maxlength="40" placeholder="Jaise: Roz 10 naye words" value="${h ? esc(h.name) : ''}"><label class="lbl">Emoji</label><div class="chips" id="hbEmo"></div>`,
    `${h ? `<button class="btn danger" style="flex:0 0 auto;padding:13px 16px" data-act="hbDelete" aria-label="Delete">${icon('trash', 18)}</button>` : ''}<button class="btn primary" data-act="hbSave">${h ? 'Update' : 'Add karo'}</button>`);
  $('#hbEmo').innerHTML = HEMO.map(e => `<button class="chip ${HBF.emoji === e ? 'on' : ''}" data-act="hbEmoji" data-k="${e}">${e}</button>`).join('');
}

/* ============ ROUTES ============ */
const ROUTES = { home: V_home, plan: V_plan, focus: V_focus, syllabus: V_syllabus, subject: V_subject, tests: V_tests, test: V_test, analysis: V_analysis, notebook: V_notebook, stats: V_stats, habits: V_habits, timetable: V_timetable, badges: V_badges, settings: V_settings, look: V_look };

/* ============ DEMO DATA ============ */
function loadDemo() {
  if (S.tests.some(t => t.demo)) return toast('Demo pehle se loaded hai');
  if (!S.subjects.length) { const pr = buildPreset(); S.subjects = pr.subjects; S.topics = pr.topics; }
  let seed = 7; const rnd = () => (seed = seed * 16807 % 2147483647) / 2147483647, pick = a => a[Math.floor(rnd() * a.length)];
  const wpick = pairs => { let r = rnd() * sum(pairs, p => p[1]); for (const [v, w] of pairs) { if ((r -= w) <= 0) return v; } return pairs[0][0]; };
  const subs = activeSubs(), now = Date.now(), td = today(); let seq = 0;
  S.topics.forEach(t => { const r = rnd(); if (t.status === 'todo' && r < .55) { t.status = r < .35 ? 'done' : 'learning'; t.demo = true; if (t.status === 'done') { t.rev = Math.floor(rnd() * 4); t.doneOn = addDays(td, -Math.floor(rnd() * 20)); t.due = addDays(td, Math.floor(rnd() * 8) - 3); t.conf = 1 + Math.floor(rnd() * 5); } } });
  const accB = { ga: .5, eng: .62, math: .6, reas: .68 }, tot = { ga: 25, eng: 25, math: 20, reas: 20 };
  for (let i = 0; i < 6; i++) {
    const t = { id: uid() + i, name: 'Demo Mock ' + (i + 1), date: addDays(td, -(5 - i) * 4 - 1), type: i % 3 === 2 ? 'Sectional' : 'Full Mock', mins: 70 + Math.floor(rnd() * 20), created: now + i, demo: true, sections: {} };
    subs.forEach(s => {
      const total = tot[s.id] || 20, att = Math.round(total * (.82 + rnd() * .14)), acc = Math.min(.92, (accB[s.id] || .6) + i * .04 + (rnd() - .5) * .08), correct = Math.round(att * acc), wrong = att - correct, skip = total - att;
      t.sections[s.id] = { total, correct, wrong };
      const tps = topicsOf(s.id), mk = kind => {
        const tp = rnd() < .55 ? tps[Math.floor(rnd() * Math.min(5, tps.length))] : pick(tps);
        const reason = kind === 'skip' ? wpick([['notstudied', 4], ['time', 3], ['confused', 2], ['forgot', 1]]) : (s.id === 'ga' || s.id === 'eng') ? wpick([['forgot', 4], ['notstudied', 3], ['silly', 2], ['confused', 2], ['guess', 2]]) : wpick([['silly', 4], ['time', 2], ['confused', 2], ['forgot', 1]]);
        S.mistakes.push({ id: uid() + (seq++), testId: t.id, sid: s.id, tid: tp.id, tn: tp.name, kind, reason, q: '', ans: '', created: now + i * 1000 + seq, box: 0, due: addDays(td, Math.floor(rnd() * 3) - 1), done: false, demo: true });
      };
      for (let j = 0; j < wrong; j++) mk('wrong'); for (let j = 0; j < skip; j++) mk('skip');
    });
    S.tests.push(t);
  }
  [['ga', 'Awards & Honours', 'forgot', 'Pehla Param Vir Chakra kisko mila?', 'Major Somnath Sharma'], ['ga', 'History – Modern & Freedom Struggle', 'forgot', 'Rowlatt Act kab pass hua?', '1919'], ['eng', 'Idioms & Phrases', 'forgot', '"Once in a blue moon" ka matlab?', 'Bahut kam / kabhi-kabhi'], ['eng', 'One Word Substitution', 'forgot', 'Kitaabein pasand karne wala vyakti?', 'Bibliophile']].forEach(([sid, tn, reason, q, ans], i) => {
    const tp = S.topics.find(x => x.sid === sid && x.name === tn) || topicsOf(sid)[0]; if (!tp) return;
    S.mistakes.push({ id: uid() + 'n' + i, testId: null, sid, tid: tp.id, tn: tp.name, kind: 'note', reason, q, ans, created: now + 99999 + i, box: 0, due: td, done: false, demo: true });
  });
  for (let i = 34; i >= 0; i--) {
    const d = addDays(td, -i); if (rnd() < .22 && i > 0) continue;
    const n = 1 + Math.floor(rnd() * 3);
    for (let j = 0; j < n; j++) {
      const s = pick(subs), tps = topicsOf(s.id), hr = wpick([[6, 2], [7, 3], [8, 2], [10, 1], [16, 1], [19, 3], [20, 3], [21, 2], [22, 1]]), ts = parseD(d).getTime() + hr * 36e5 + Math.floor(rnd() * 50) * 6e4;
      if (ts > now) continue;
      S.sessions.push({ id: uid() + (seq++), date: dateOf(ts), ts, secs: (25 + Math.floor(rnd() * 4) * 10) * 60, sid: s.id, tid: rnd() < .6 ? pick(tps).id : '', mode: 'pomo', dist: Math.floor(rnd() * 3), demo: true });
    }
  }
  const nt = (date, title, sid, est, done) => S.tasks.push({ id: uid() + (seq++), date, title, sid, tid: '', est, time: '', done, created: now + seq, demo: true });
  nt(td, '📘 Percentage ke 20 questions', 'math', 45, true); nt(td, '📖 Current Affairs: last 1 month', 'ga', 40, false); nt(td, '🔁 Idioms revise karo', 'eng', 20, false); nt(td, '📝 Sectional test (English)', 'eng', 30, false);
  nt(addDays(td, -1), '📘 Polity notes', 'ga', 45, true); nt(addDays(td, -1), '📘 Series practice', 'reas', 30, true); nt(addDays(td, 1), '📘 Geography India', 'ga', 45, false);
  if (!S.blocks.length) { [[[0, 1, 2, 3, 4], '06:00', '08:00', 'ga', 'GA reading'], [[0, 1, 2, 3, 4, 5], '19:00', '20:30', 'eng', 'English practice'], [[5, 6], '10:00', '13:00', 'math', 'Maths + Reasoning'], [[0, 2, 4], '21:00', '22:00', 'reas', 'Reasoning']].forEach(([days, start, end, sid, label]) => S.blocks.push({ id: uid() + (seq++), days, start, end, sid, label, demo: true })); }
  if (!S.habits.length) HABIT_SUG.slice(0, 3).forEach(([emoji, name]) => { const days = {}; for (let i = 0; i < 25; i++) if (rnd() < .7) days[addDays(td, -i)] = 1; S.habits.push({ id: uid() + (seq++), emoji, name, days, demo: true }); });
  S.profile.examDate = S.profile.examDate || addDays(td, 60);
  commit(false); checkProgress(true); toast('Demo data load ho gaya ✨', 'ok'); goTab('home'); render();
}
function removeDemo() {
  S.tests = S.tests.filter(t => !t.demo); S.mistakes = S.mistakes.filter(m => !m.demo); S.sessions = S.sessions.filter(x => !x.demo); S.tasks = S.tasks.filter(x => !x.demo); S.blocks = S.blocks.filter(x => !x.demo); S.habits = S.habits.filter(x => !x.demo);
  S.topics.forEach(t => { if (t.demo) { t.status = 'todo'; t.rev = 0; t.due = ''; t.doneOn = ''; t.conf = 0; delete t.demo; } });
  commit(); toast('Demo data hata diya');
}

/* ============ ACTIONS ============ */
const focusOn = (sid, tid) => { if (sid) UI.fc.sid = sid; UI.fc.tid = tid || ''; UI.fc.free = false; goTab('focus'); };
const setBtns = (sel, k) => $$(sel).forEach(b => b.classList.toggle('on', b.dataset.k === String(k)));
const setPath = (path, v) => { const p = path.split('.'); let o = S; for (let i = 0; i < p.length - 1; i++) o = o[p[i]]; o[p[p.length - 1]] = v; };
const ACT = {
  back: goBack, goHome: () => goTab('home'), goTab: el => goTab(el.dataset.k),
  goFocus: () => goTab('focus'), goPlan: () => goTab('plan'), goSyllabus: () => goTab('syllabus'), goTests: () => goTab('tests'),
  goStats: () => go('stats'), goSettings: () => go('settings'), goLook: () => go('look'), goBadges: () => go('badges'), goHabits: () => go('habits'), goTimetable: () => go('timetable'),
  openMenu, menuGo: el => closeLayer(() => go(el.dataset.k)),
  sheetClose: () => closeLayer(), dlgNo: () => closeLayer(), dlgYes: () => { const cb = dlgCb; dlgCb = null; closeLayer(cb); },
  fab: () => {
    const f = META[cur.name].fab;
    if (f === 'task') openTaskSheet(null); else if (f === 'subject') openSubjectSheet(); else if (f === 'topic') openTopicAdd(cur.arg);
    else if (f === 'test') openTestSheet(); else if (f === 'mistake') openMistakeSheet({ testId: cur.arg }); else if (f === 'note') openMistakeSheet({});
    else if (f === 'habit') openHabitSheet(); else if (f === 'block') openBlockSheet();
  },
  fabTest: () => openTestSheet(), fabSubject: () => openSubjectSheet(), fabHabit: () => openHabitSheet(), fabBlock: () => openBlockSheet(), fabManual: openManualSheet,
  openSubject: el => { UI.sf = { f: 'all', q: '' }; go('subject/' + el.dataset.id); }, openTest: el => go('test/' + el.dataset.id),
  openTopic: el => openTopicSheet(el.dataset.id), openTopicFromSheet: el => closeLayer(() => openTopicSheet(el.dataset.id)),

  /* revision */
  revHub: openRevHub,
  revCards: () => closeLayer(() => startRevise(dueCards().map(m => m.id))),
  topicRev: el => { const t = topic(el.dataset.id); if (!t) return; markRevised(t); commit(); toast(t.due ? `✓ Revised · agli revision ${fmtD(t.due)}` : '✓ Revised · topic mastered 🎉', 'ok'); },
  topicRevSheet: el => { const t = topic(el.dataset.id); if (!t) return; markRevised(t); save(); checkProgress(); closeLayer(() => { render(true); openRevHub(); }); },
  tpRev: el => { const t = topic(el.dataset.id); if (!t) return; markRevised(t); save(); closeLayer(() => { commit(); toast('✓ Revised', 'ok'); }); },

  /* planner */
  smartPlan: el => { const n = smartPlan(el.dataset.d); if (!n) return toast('Plan banane layak kuch nahi mila. Pehle syllabus add karo.'); commit(); toast(`✨ ${n} tasks add ho gaye`, 'ok'); },
  taskDone: el => { const t = S.tasks.find(x => x.id === el.dataset.id); if (!t) return; t.done = !t.done; t.doneAt = t.done ? Date.now() : 0; if (t.done) { const tp = topic(t.tid); if (tp && tp.status === 'todo' && t.kind !== 'rev') setStatus(tp, 'learning'); haptic(14); } commit(); },
  editTask: el => openTaskSheet(el.dataset.id),
  taskFocus: el => { const t = S.tasks.find(x => x.id === el.dataset.id); if (!t) return; if (t.kind === 'nb') startRevise(dueCards().map(m => m.id)); else if (t.kind === 'test') openTestSheet(); else focusOn(t.sid, t.tid); },
  plWeek: el => { UI.pl.date = addDays(UI.pl.date || today(), Number(el.dataset.d)); render(true); },
  plDay: el => { UI.pl.date = el.dataset.d === today() ? '' : el.dataset.d; render(true); },
  carryOver: () => { const td = today(); S.tasks.forEach(t => { if (t.date < td && !t.done) t.date = td; }); commit(); toast('Aaj me aa gaye ✓'); },
  dropOld: () => confirmBox('Purane tasks hatayein?', 'Aaj se pehle ke adhoore tasks delete ho jayenge.', 'Hata do', () => { const td = today(); S.tasks = S.tasks.filter(t => t.date >= td || t.done); commit(); }),
  ttDay: el => { UI.tt.day = Number(el.dataset.k); render(true); },
  editBlock: el => openBlockSheet(el.dataset.id),
  tkEst: el => { TKF.est = Number(el.dataset.k); tkRender(); },
  tkSub: el => { TKF.sid = el.dataset.id; TKF.tid = ''; tkRender(); },
  tkTopic: el => { TKF.tid = el.dataset.id; tkRender(); },
  tkSave: () => {
    const title = $('#tkTitle').value.trim(); if (!title) return toast('Task ka naam likho');
    const date = $('#tkDate').value || today(), time = $('#tkTime').value || '';
    if (TKF.id) { const t = S.tasks.find(x => x.id === TKF.id); Object.assign(t, { title, date, time, sid: TKF.sid, tid: TKF.tid, est: TKF.est }); }
    else S.tasks.push({ id: uid(), date, title, sid: TKF.sid, tid: TKF.tid, est: TKF.est, time, done: false, created: Date.now() });
    UI.pl.date = date === today() ? '' : date; closeLayer(() => { commit(); toast('Task save ✓'); });
  },
  tkDelete: () => confirmBox('Task delete karein?', 'Ye task hat jayega.', 'Delete', () => { S.tasks = S.tasks.filter(x => x.id !== TKF.id); closeLayer(() => commit()); }),
  bkDay: el => { const k = Number(el.dataset.k), i = BKF.days.indexOf(k); if (i >= 0) { if (BKF.days.length > 1) BKF.days.splice(i, 1); } else BKF.days.push(k); bkRender(); },
  bkSub: el => { BKF.sid = el.dataset.id; bkRender(); },
  bkSave: () => {
    const start = $('#bkStart').value, end = $('#bkEnd').value; if (!BKF.sid) return toast('Subject chuno');
    if (!start || !end || toMin(end) <= toMin(start)) return toast('End time start ke baad hona chahiye');
    const clash = S.blocks.find(b => b.id !== BKF.id && b.days.some(d => BKF.days.includes(d)) && toMin(b.start) < toMin(end) && toMin(start) < toMin(b.end));
    if (clash) return toast(`Ye slot "${clash.label || sub(clash.sid).name}" (${to12(clash.start)}–${to12(clash.end)}) se takra raha hai`, 'bad');
    const o = { days: [...BKF.days].sort(), sid: BKF.sid, start, end, label: $('#bkLabel').value.trim() };
    if (BKF.id) Object.assign(S.blocks.find(x => x.id === BKF.id), o); else S.blocks.push({ id: uid(), ...o });
    closeLayer(() => { commit(); toast('Slot save ✓'); });
  },
  bkDelete: () => confirmBox('Slot delete karein?', 'Ye timetable slot hat jayega.', 'Delete', () => { S.blocks = S.blocks.filter(x => x.id !== BKF.id); closeLayer(() => commit()); }),

  /* habits */
  habitTick: el => { const h = S.habits.find(x => x.id === el.dataset.id), d = today(); if (h.days[d]) delete h.days[d]; else { h.days[d] = 1; haptic(14); } commit(); },
  habitDay: el => { const h = S.habits.find(x => x.id === el.dataset.id), d = el.dataset.d; if (h.days[d]) delete h.days[d]; else h.days[d] = 1; commit(); },
  habitSug: el => { const [emoji, name] = HABIT_SUG[Number(el.dataset.k)]; S.habits.push({ id: uid(), emoji, name, days: {}, created: Date.now() }); commit(); },
  editHabit: el => openHabitSheet(el.dataset.id),
  hbEmoji: el => { HBF.emoji = el.dataset.k; $$('#hbEmo .chip').forEach(c => c.classList.toggle('on', c.dataset.k === HBF.emoji)); },
  hbSave: () => { const name = $('#hbName').value.trim(); if (!name) return toast('Habit ka naam likho'); if (HBF.id) Object.assign(S.habits.find(x => x.id === HBF.id), { name, emoji: HBF.emoji }); else S.habits.push({ id: uid(), name, emoji: HBF.emoji, days: {}, created: Date.now() }); closeLayer(() => commit()); },
  hbDelete: () => confirmBox('Habit delete karein?', 'Iski poori history hat jayegi.', 'Delete', () => { S.habits = S.habits.filter(x => x.id !== HBF.id); closeLayer(() => commit()); }),

  /* focus */
  fcSub: el => { UI.fc.sid = el.dataset.id; UI.fc.tid = ''; render(true); },
  fcTopic: el => { UI.fc.tid = el.dataset.id; render(true); },
  fcPreset: el => { const k = el.dataset.k; if (k === 'free') UI.fc.free = true; else { UI.fc.free = false; S.settings.pomo.focus = PRESETS[k][0]; S.settings.pomo.short = PRESETS[k][1]; } save(); render(true); },
  fcDur: el => { const P = S.settings.pomo; P.focus = clamp(P.focus + Number(el.dataset.d), 5, 180); save(); render(true); },
  tStart, tToggle, tFinish,
  tSkip: () => { S.timer = null; wake(false); commit(); },
  tDist: () => { if (S.timer) { S.timer.dist = (S.timer.dist || 0) + 1; save(); render(true); } },
  tCancel: () => confirmBox('Session discard karein?', 'Ye session log nahi hoga.', 'Discard', () => { S.timer = null; wake(false); commit(); }),
  delSession: el => confirmBox('Session delete karein?', 'Ye time total se hat jayega.', 'Delete', () => { S.sessions = S.sessions.filter(x => x.id !== el.dataset.id); commit(); }),
  mtSub: el => { MT.sid = el.dataset.id; MT.tid = ''; mtRender(); }, mtTopic: el => { MT.tid = el.dataset.id; mtRender(); },
  mtMins: el => { MT.mins = Number(el.dataset.k); $('#mtMinIn').value = MT.mins; mtRender(); },
  mtSave: () => {
    const mins = toInt($('#mtMinIn').value), date = $('#mtDate').value || today();
    if (mins < 1 || mins > 600) return toast('1 se 600 minute ke beech likho');
    if (date > today()) return toast('Future ki date nahi chalegi');
    S.sessions.push({ id: uid(), date, ts: parseD(date).getTime() + 12 * 36e5, secs: mins * 60, sid: MT.sid, tid: MT.tid, mode: 'manual', manual: true, dist: 0 });
    closeLayer(() => { commit(); toast(`✓ ${fmtDur(mins * 60)} jod diya`, 'ok'); });
  },

  /* syllabus */
  loadPreset: () => { const pr = buildPreset(); pr.subjects.forEach(s => { if (!S.subjects.some(x => x.id === s.id)) S.subjects.push(s); }); pr.topics.forEach(t => { if (!S.topics.some(x => x.sid === t.sid && x.name === t.name)) S.topics.push(t); }); commit(); toast('SSC MTS syllabus load ho gaya ✓', 'ok'); },
  cycleStatus: el => { const t = topic(el.dataset.id); if (!t) return; const nx = { todo: 'learning', learning: 'done', done: 'todo' }[t.status]; setStatus(t, nx); haptic(10); commit(); if (nx === 'done') toast(`✓ "${t.name}" complete! Pehli revision kal`, 'ok'); },
  sfF: el => { UI.sf.f = el.dataset.k; render(true); },
  focusSub: el => focusOn(el.dataset.id, ''),
  focusTopic: el => closeLayer(() => { const t = topic(el.dataset.id); if (t) focusOn(t.sid, t.id); }),
  topicMistakes: el => closeLayer(() => { UI.nb = { status: 'all', sid: 'all', reason: 'all', tid: el.dataset.id, q: '', limit: 40 }; go('notebook'); }),
  tpStatus: el => { TP.status = el.dataset.k; setBtns('#tpStatus button', TP.status); },
  tpConf: el => { const k = Number(el.dataset.k); TP.conf = TP.conf === k ? 0 : k; $$('#tpConf button').forEach((b, i) => b.classList.toggle('on', i < TP.conf)); },
  tpImp: () => { TP.imp = !TP.imp; $('#tpImp').classList.toggle('on', TP.imp); },
  tpSave: () => {
    const t = topic(TP.id), name = $('#tpName').value.trim(); if (!name) return toast('Naam khaali nahi ho sakta');
    t.name = name; t.conf = TP.conf; t.imp = TP.imp; t.notes = $('#tpNotes').value.trim(); setStatus(t, TP.status);
    closeLayer(() => { commit(); toast('Save ✓'); });
  },
  tpDelete: () => confirmBox('Topic delete karein?', 'Topic syllabus se hat jayega (purani galtiyan naam ke saath bachi rahengi).', 'Delete', () => { const id = TP.id; S.topics = S.topics.filter(x => x.id !== id); S.tasks.forEach(x => { if (x.tid === id) x.tid = ''; }); S.sessions.forEach(x => { if (x.tid === id) x.tid = ''; }); closeLayer(() => commit()); }),
  taSave: el => {
    const lines = $('#taText').value.split('\n').map(x => x.trim()).filter(Boolean); if (!lines.length) return toast('Kam se kam ek topic likho');
    let n = 0; lines.forEach(l => { const imp = l.endsWith('*'), name = imp ? l.slice(0, -1).trim() : l; if (name && !S.topics.some(x => x.sid === el.dataset.id && x.name.toLowerCase() === name.toLowerCase())) { S.topics.push(mkTopic(el.dataset.id, name, imp)); n++; } });
    closeLayer(() => { commit(); toast(`${n} topics add ho gaye ✓`, 'ok'); });
  },
  sbMerit: () => { SB.merit = !SB.merit; $('#sbMerit').classList.toggle('on', SB.merit); },
  sbEmoji: el => { SB.emoji = el.dataset.k; sbRender(); }, sbColor: el => { SB.color = el.dataset.k; sbRender(); },
  editSubject: el => openSubjectSheet(el.dataset.id),
  sbSave: () => {
    const name = $('#sbName').value.trim(); if (!name) return toast('Subject ka naam likho');
    const sh = $('#sbShort').value.trim() || name.slice(0, 10);
    if (SB.id) Object.assign(S.subjects.find(x => x.id === SB.id), { name, short: sh, emoji: SB.emoji, color: SB.color, merit: SB.merit });
    else S.subjects.push({ id: uid(), name, short: sh, emoji: SB.emoji, color: SB.color, merit: SB.merit, archived: false });
    closeLayer(() => { commit(); toast('Subject save ✓'); });
  },
  sbArchive: () => { const s = S.subjects.find(x => x.id === SB.id); s.archived = !s.archived; closeLayer(() => { commit(); toast(s.archived ? 'Archive ho gaya' : 'Restore ho gaya'); if (cur.name === 'subject') goTab('syllabus'); }); },
  sbDelete: () => confirmBox('Subject delete karein?', 'Iske topics, mistakes, tasks aur test sections hamesha ke liye hat jayenge. Archive karna safe option hai.', 'Delete', () => {
    const id = SB.id; S.subjects = S.subjects.filter(x => x.id !== id); S.topics = S.topics.filter(x => x.sid !== id); S.mistakes = S.mistakes.filter(x => x.sid !== id);
    S.tasks = S.tasks.filter(x => x.sid !== id); S.blocks = S.blocks.filter(x => x.sid !== id); S.sessions.forEach(x => { if (x.sid === id) { x.sid = ''; x.tid = ''; } });
    S.tests.forEach(t => { delete t.sections[id]; }); S.tests = S.tests.filter(t => Object.keys(t.sections).length);
    closeLayer(() => { commit(false); goTab('syllabus'); });
  }),

  /* tests */
  tfType: el => { UI.tf.type = el.dataset.k; render(true); },
  tfTypeSet: el => { TF.type = el.dataset.k; setBtns('#tfTypes .chip', TF.type); },
  tfToggle: el => { const k = el.dataset.k; TF.incl[k] = !TF.incl[k]; el.classList.toggle('on', TF.incl[k]); $('#blk-' + k).classList.toggle('hidden', !TF.incl[k]); },
  tfSave: () => {
    const name = $('#tfName').value.trim() || ('Mock Test ' + (S.tests.length + 1)), date = $('#tfDate').value || today(), mins = toInt($('#tfMins').value), secs = {};
    let ok = true, any = false;
    for (const k of TF.list) {
      if (!TF.incl[k]) continue; any = true;
      const total = toInt($('#t-' + k).value), c = toInt($('#c-' + k).value), w = toInt($('#w-' + k).value);
      if (total <= 0 || c + w > total) { ok = false; const b = $('#blk-' + k); b.classList.remove('shake'); void b.offsetWidth; b.classList.add('shake'); continue; }
      secs[k] = { total, correct: c, wrong: w };
    }
    if (!any) return toast('Kam se kam ek section chuno'); if (!ok) return toast('Numbers check karo: Sahi + Galat ≤ Total', 'bad');
    let id = TF.id; const isNew = !id;
    if (id) { const t = S.tests.find(x => x.id === id); Object.assign(t, { name, date, mins, type: TF.type, sections: secs }); } else { id = uid(); S.tests.push({ id, name, date, mins, type: TF.type, created: Date.now(), sections: secs }); }
    closeLayer(() => {
      commit(false); go('test/' + id); toast(isNew ? 'Test save ho gaya ✓' : 'Update ho gaya ✓', 'ok');
      if (isNew && logProgress(S.tests.find(x => x.id === id)).need > 0) setTimeout(() => openMistakeSheet({ testId: id }), 500);
    });
  },
  addM: el => openMistakeSheet({ testId: el.dataset.id }), editTest: el => openTestSheet(el.dataset.id),
  delTest: el => confirmBox('Test delete karein?', 'Is test ki saari logged mistakes bhi hat jayengi.', 'Delete', () => { const id = el.dataset.id; S.tests = S.tests.filter(t => t.id !== id); S.mistakes = S.mistakes.filter(m => m.testId !== id); commit(false); goTab('tests'); toast('Test delete ho gaya'); }),
  anSec: el => { UI.an.sec = el.dataset.k; render(true); }, anRange: el => { UI.an.range = el.dataset.k; render(true); },
  nbTopic: el => { UI.nb = { status: 'all', sid: el.dataset.id ? 'all' : el.dataset.sid, reason: 'all', tid: el.dataset.id, q: '', limit: 40 }; go('notebook'); },
  nbStatus: el => { UI.nb.status = el.dataset.k; UI.nb.limit = 40; render(true); }, nbSid: el => { UI.nb.sid = el.dataset.k; UI.nb.limit = 40; render(true); },
  nbReason: el => { UI.nb.reason = el.dataset.k; UI.nb.limit = 40; render(true); }, nbClearTopic: () => { UI.nb.tid = ''; render(true); }, nbMore: () => { UI.nb.limit += 40; render(true); },
  startRevise: () => startRevise(notesFiltered().filter(m => !m.done && (UI.nb.status === 'pending' || UI.nb.status === 'all' ? true : cardDue(m))).map(m => m.id)),
  toggleDone: el => { const m = S.mistakes.find(x => x.id === el.dataset.id); if (!m) return; if (m.done) { m.done = false; m.box = 0; m.due = today(); } else { m.done = true; m.box = 5; m.due = ''; S.revLog[today()] = (S.revLog[today()] || 0) + 1; toast('Revised ✓'); } commit(); },
  editM: el => openMistakeSheet({ id: el.dataset.id }),
  delM: el => confirmBox('Point delete karein?', 'Ye mistake/note hamesha ke liye hat jayega.', 'Delete', () => { S.mistakes = S.mistakes.filter(x => x.id !== el.dataset.id); commit(); toast('Delete ho gaya'); }),
  rvFlip: () => { if (!RV || RV.flip) return; RV.flip = true; const fc = $('.fc'); if (fc) fc.classList.add('flip'); const b = $('#rvBtns'); if (b) b.innerHTML = rvButtons(); },
  rvYes: () => rvAnswer('good'), rvHard: () => rvAnswer('hard'), rvNo: () => rvAnswer('again'), rvClose: closeRevise,
  msSec: el => { MS.sid = el.dataset.k; MSlast.sid = MS.sid; MS.tid = ''; msRender(); },
  msKind: el => { MS.kind = el.dataset.k; MSlast.kind = MS.kind; msRender(); },
  msTopic: el => { MS.tid = el.dataset.id; msTopics(); },
  msReason: el => { MS.reason = el.dataset.k; $$('#msReasons .chip').forEach(c => c.classList.toggle('on', c.dataset.k === MS.reason)); },
  msNew: () => { const r = $('#msNewRow'); r.classList.toggle('show'); if (r.classList.contains('show')) $('#msNewTopic').focus(); },
  msAddTopic: () => { const v = $('#msNewTopic').value.trim(); if (!v) return; let t = S.topics.find(x => x.sid === MS.sid && x.name.toLowerCase() === v.toLowerCase()); if (!t) { t = mkTopic(MS.sid, v); S.topics.push(t); } MS.tid = t.id; save(); $('#msNewTopic').value = ''; $('#msNewRow').classList.remove('show'); msTopics(); },
  msQty: el => { MS.qty = clamp(MS.qty + Number(el.dataset.d), 1, 40); $('#msQty').textContent = MS.qty; },
  msSave: el => {
    if (!MS.tid) return toast('Topic chuno'); if (!MS.reason) return toast('Reason chuno: kyun galat hua?');
    const q = $('#msQ').value.trim(), ans = $('#msA').value.trim(), tn = (topic(MS.tid) || {}).name || '';
    if (MS.id) { Object.assign(S.mistakes.find(x => x.id === MS.id), { sid: MS.sid, kind: MS.kind, tid: MS.tid, tn, reason: MS.reason, q, ans }); return closeLayer(() => { commit(); toast('Update ho gaya ✓'); }); }
    const now = Date.now();
    for (let i = 0; i < MS.qty; i++) S.mistakes.push({ id: uid() + i, testId: MS.testId, sid: MS.sid, tid: MS.tid, tn, kind: MS.kind, reason: MS.reason, q: i === 0 ? q : '', ans: i === 0 ? ans : '', created: now + i, box: 0, due: today(), done: false });
    MSlast.sid = MS.sid; MSlast.kind = MS.kind; save(); dirty();
    if (el.dataset.next === '1') {
      render(true); toast(`Saved ✓ (${MS.qty})`, 'ok'); MS.tid = ''; MS.reason = ''; MS.qty = 1; $('#msQ').value = ''; $('#msA').value = ''; $('#msQty').textContent = 1; msRender();
      if (MS.testId) { const t = S.tests.find(x => x.id === MS.testId), pc = pendingCombo(t, MS.sids); if (pc) { MS.sid = pc.sid; MS.kind = pc.kind; msRender(); } }
      $('#shBody').scrollTo({ top: 0, behavior: 'smooth' });
    } else closeLayer(() => { commit(); toast('Save ho gaya ✓', 'ok'); });
  },

  /* stats / settings / look */
  stRange: el => { UI.st.range = el.dataset.k; render(true); },
  setDayStart: el => { S.profile.dayStart = Number(el.dataset.k); commit(); },
  setAutoBreak: () => { S.settings.pomo.autoBreak = !S.settings.pomo.autoBreak; commit(); },
  setWake: () => { S.settings.wake = !S.settings.wake; commit(); }, setSound: () => { S.settings.sound = !S.settings.sound; if (S.settings.sound) { unlockAudio(); beep(); } commit(); },
  setHaptic: () => { S.settings.haptics = !S.settings.haptics; commit(); haptic(30); },
  setOpt: el => { S.settings[el.dataset.o] = el.dataset.k; applyTheme(); commit(); },
  setTheme: el => { S.settings.theme = el.dataset.k; applyTheme(); commit(); },
  setAccent: el => { S.settings.accent = el.dataset.k; applyTheme(); commit(); },
  doExport: () => { flushSave(); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(S)], { type: 'application/json' })); a.download = `lakshya-backup-${today()}.json`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); toast('Backup file ban gayi ⬇'); },
  doImport: () => {
    const i = document.createElement('input'); i.type = 'file'; i.accept = '.json,application/json';
    i.onchange = () => {
      const f = i.files[0]; if (!f) return; const r = new FileReader();
      r.onload = () => { try { const d = JSON.parse(r.result); if (!Array.isArray(d.tests) || !Array.isArray(d.mistakes)) throw 0; confirmBox('Backup restore karein?', 'Abhi ka saara data is backup se replace ho jayega.', 'Restore', () => { S = d.subjects ? migrate(d) : fromV1(d); applyTheme(); flushSave(); render(); toast('Restore ho gaya ✓', 'ok'); }, 'primary'); } catch (e) { toast('Ye valid backup file nahi hai', 'bad'); } };
      r.readAsText(f);
    }; i.click();
  },
  loadDemo, rmDemo: () => removeDemo(),
  resetAll: () => confirmBox('Sab kuch reset karein?', 'Saara data hamesha ke liye delete ho jayega. Pehle backup le lo.', 'Reset', () => { S = defaults(); flushSave(); applyTheme(); location.replace('#home'); render(); UI.ob.step = 0; showOnboarding(); }),

  /* onboarding */
  obPreset: el => { const o = UI.ob; o.preset = el.dataset.k; if (o.preset === 'mts' && (!o.exam || o.exam === 'Meri Taiyari')) o.exam = 'SSC MTS'; if (o.preset === 'custom' && o.exam === 'SSC MTS') o.exam = 'Meri Taiyari'; obRender(); },
  obGoal: el => { UI.ob.goal = clamp(UI.ob.goal + Number(el.dataset.d), 30, 720); obRender(); }, obGoalSet: el => { UI.ob.goal = Number(el.dataset.k); obRender(); },
  obTheme: el => { UI.ob.theme = el.dataset.k; S.settings.theme = el.dataset.k; applyTheme(); obRender(); },
  obBack: () => { UI.ob.step = Math.max(0, UI.ob.step - 1); obRender(); },
  obNext: () => { if (UI.ob.step >= 3) return obFinish(); UI.ob.step++; obRender(); }
};

/* ============ EVENTS ============ */
document.addEventListener('click', e => {
  const na = e.target.closest('#nav a'); if (na) { e.preventDefault(); haptic(6); goTab(na.dataset.r); return; }
  const el = e.target.closest('[data-act]'); if (!el) return;
  const fn = ACT[el.dataset.act]; if (!fn) return;
  haptic(); fn(el, e);
});
document.addEventListener('pointerdown', e => {
  if (S.settings.motion === 'off') return;
  const el = e.target.closest('.btn,.chip,.tile,button.card,.ibtn,.fab,.seg button'); if (!el) return;
  const r = el.getBoundingClientRect(), s = Math.max(r.width, r.height) * 1.6, i = document.createElement('i');
  i.className = 'rp'; i.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
  el.appendChild(i); i.addEventListener('animationend', () => i.remove());
}, { passive: true });
document.addEventListener('input', e => {
  const t = e.target;
  if (t.classList.contains('tfin')) updateSkip(t.dataset.k);
  else if (t.dataset.ob) UI.ob[t.dataset.ob] = t.value;
  else if (t.id === 'sfQ') { UI.sf.q = t.value; const l = $('#topicList'); if (l) l.innerHTML = topicListHtml(cur.arg); }
  else if (t.id === 'nbQ') { UI.nb.q = t.value; UI.nb.limit = 40; const l = $('#nbList'); if (l) { l.innerHTML = nbListHtml(); $('#nbCount').textContent = notesFiltered().length + ' points'; } }
});
document.addEventListener('change', e => {
  const t = e.target, path = t.dataset && t.dataset.set; if (!path) return;
  let v = t.value;
  if (t.dataset.n) { v = num(v); if (/dailyGoal|streakMin|pomo\./.test(path)) v = Math.max(1, Math.round(v)); else v = Math.max(0, v); }
  setPath(path, v); S.profile.exam = S.profile.exam || 'Meri Taiyari'; save(); toast('Save ho gaya'); if (cur.name === 'home') render(true);
});
addEventListener('hashchange', () => { killLayers(); $('#sheetRoot').classList.remove('open'); paint(true); });

/* ============ INIT ============ */
$('#backBtn').innerHTML = icon('back', 22); $('#fab').innerHTML = icon('plus', 28);
$('#menuBtn').innerHTML = icon('grid', 21); $('#gearBtn').innerHTML = icon('gear', 21); $('#brand').textContent = '🎯';
const NAVI = { home: 'home', plan: 'plan', focus: 'focus', syllabus: 'syl', tests: 'test' };
$$('#nav a').forEach(a => { $('.pill', a).innerHTML = icon(NAVI[a.dataset.r], a.classList.contains('mid') ? 26 : 22); });
applyTheme(); checkProgress(true);
if (!S.profile.onboarded) showOnboarding();
paint(true);
if (S.timer && S.timer.running) wake(true);
setTimeout(() => { const sp = $('#splash'); if (sp) { sp.classList.add('out'); setTimeout(() => sp.remove(), 500); } }, 650);
})();
