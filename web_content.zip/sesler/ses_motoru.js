// 5N1K Ses Motoru v7 (APK / Android WebView uyumlu)
window.SesMotoru = {
    sesAcik: true,
    audioCtx: null,
    aktifAudio: null,
    trVoice: null,
    durumMesaji: "Hazır",
    _token: 0,

    init() {
        this.audioContextHazirla();
        try {
            if ('speechSynthesis' in window) {
                window.speechSynthesis.onvoiceschanged = () => this.sesleriTara();
                this.sesleriTara();
            }
        } catch (e) {}
    },

    durumYaz(m) {
        this.durumMesaji = m;
        try {
            const el = document.getElementById('sesDurum');
            if (el) el.textContent = '🔈 ' + m;
        } catch (e) {}
    },

    audioContextHazirla() {
        try {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!this.audioCtx && AC) this.audioCtx = new AC();
        } catch (e) {}
    },

    sesleriTara() {
        try {
            if (!('speechSynthesis' in window)) return;
            const voices = window.speechSynthesis.getVoices() || [];
            const tr = voices.filter(v => v.lang && /^tr([-_]|$)/i.test(v.lang));
            if (tr.length) {
                this.trVoice = tr.find(v => v.localService) || tr[0];
            }
        } catch (e) {}
    },

    // Oyuna dokunulan ilk anda çağrılır: WebView'in ses kilidini açar.
    kilidiAc() {
        try {
            this.audioContextHazirla();
            if (this.audioCtx && this.audioCtx.state === 'suspended') this.audioCtx.resume();
            // Sessiz bir <audio> oynatarak medya kilidini aç
            const s = new Audio("data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=");
            s.volume = 0.01;
            const p = s.play();
            if (p && p.catch) p.catch(() => {});
        } catch (e) {}
        try {
            if ('speechSynthesis' in window) {
                window.speechSynthesis.resume();
                this.sesleriTara();
            }
        } catch (e) {}
        this.efektCal('basla');
    },

    durdur() {
        try {
            const a = this.aktifAudio;
            if (a) {
                // ÖNEMLİ: src="" hata olayı tetikler; önce dinleyicileri temizle
                a.onended = a.onerror = a.onplaying = null;
                a.pause();
                a.removeAttribute('src');
                try { a.load(); } catch (e) {}
                this.aktifAudio = null;
            }
        } catch (e) {}
        try {
            if ('speechSynthesis' in window) window.speechSynthesis.cancel();
        } catch (e) {}
    },

    konus(metin, bittiginde) {
        if (!this.sesAcik || !metin) {
            if (bittiginde) bittiginde();
            return;
        }
        const token = ++this._token;
        this.durdur();

        let bitti = false;
        const aktif = () => token === this._token;
        const tamamla = () => {
            if (bitti || !aktif()) return;
            bitti = true;
            if (bittiginde) bittiginde();
        };
        // Emniyet: hiçbir şey bitiş bildirmezse oyun akışı takılmasın
        setTimeout(tamamla, Math.max(4000, metin.length * 110));

        const devam = () => {
        // 1) Yerel Android köprüleri (varsa)
        try {
            const w = window;
            const kopruler = [
                [w.Website2APK, 'textToSpeech'], [w.Website2APK, 'speak'],
                [w.Android, 'speak'], [w.AndroidTTS, 'speak']
            ];
            for (const [nesne, ad] of kopruler) {
                if (nesne && typeof nesne[ad] === 'function') {
                    nesne[ad](metin);
                    this.durumYaz('Android TTS köprüsü');
                    setTimeout(tamamla, Math.max(2200, metin.length * 80));
                    return;
                }
            }
        } catch (e) {}

        // 2) Web Speech -> 3) Online MP3 -> 4) Bip sesi
        const sonScare = () => {
            if (!aktif()) return;
            this.ritmikHecele(metin);
            this.durumYaz('Ses motoru bulunamadı (cihazda Metin Okuma/Google TTS kurulu mu?)');
            setTimeout(tamamla, Math.max(1500, metin.split(' ').length * 160));
        };
        const online = () => {
            if (!aktif()) return;
            this.onlineMp3Dene(metin, token, tamamla, sonScare);
        };
        this.webSpeechDene(metin, token, tamamla, online);
        };

        // 0) Pakete eklenmiş kayıtlı MP3 varsa önce onu çal
        const dosya = (window.SES_MAP || {})[metin];
        if (dosya) this.dosyaCal(dosya, token, tamamla, devam);
        else devam();
    },

    dosyaCal(dosya, token, tamamla, yedek) {
        const aktif = () => token === this._token;
        const a = new Audio();
        this.aktifAudio = a;
        a.preload = 'auto';
        let bitti = false;
        const hata = () => {
            clearTimeout(zaman);
            if (bitti || !aktif()) return;
            bitti = true;
            a.onended = a.onerror = a.onplaying = null;
            try { a.pause(); } catch (e) {}
            yedek();
        };
        const zaman = setTimeout(hata, 5000);
        a.onplaying = () => { clearTimeout(zaman); this.durumYaz('Kayıtlı ses (MP3)'); };
        a.onended = () => { clearTimeout(zaman); if (!bitti) { bitti = true; tamamla(); } };
        a.onerror = hata;
        a.src = dosya;
        const p = a.play();
        if (p && p.catch) p.catch(hata);
    },

    webSpeechDene(metin, token, tamamla, yedek) {
        const aktif = () => token === this._token;
        const ss = ('speechSynthesis' in window) ? window.speechSynthesis : null;
        if (!ss || typeof SpeechSynthesisUtterance === 'undefined') { yedek(); return; }

        // cancel() hemen ardından speak() Android'de yutuluyor; kısa bekle
        setTimeout(() => {
            if (!aktif()) return;
            try {
                ss.resume();
                if (!this.trVoice) this.sesleriTara();
                const u = new SpeechSynthesisUtterance(metin);
                u.lang = 'tr-TR';
                u.rate = 0.9;
                u.pitch = 1.0;
                u.volume = 1;
                if (this.trVoice) { u.voice = this.trVoice; u.lang = this.trVoice.lang; }
                window.__aktifKonusma = u; // çöp toplayıcı olayları yutmasın

                let basladi = false;
                u.onstart = () => { basladi = true; this.durumYaz('Cihaz sesi (TTS)'); };
                u.onend = () => { if (aktif()) { basladi = true; tamamla(); } };
                u.onerror = (ev) => {
                    if (!aktif()) return;
                    const hata = ev && ev.error;
                    if (hata === 'interrupted' || hata === 'canceled') return;
                    if (basladi) tamamla(); else yedek();
                };
                ss.speak(u);

                // Başlama kontrolü: ilk kullanımda motor geç açılabilir
                setTimeout(() => {
                    if (!aktif() || basladi) return;
                    if (ss.speaking && !ss.paused) { basladi = true; this.durumYaz('Cihaz sesi (TTS)'); return; }
                    try { ss.cancel(); } catch (e) {}
                    yedek();
                }, 2200);
            } catch (e) {
                yedek();
            }
        }, 120);
    },

    onlineMp3Dene(metin, token, tamamla, sonCare) {
        const aktif = () => token === this._token;
        const q = encodeURIComponent(metin);
        const kaynaklar = [
            "https://translate.google.com/translate_tts?ie=UTF-8&tl=tr&client=tw-ob&q=" + q,
            "https://translate.google.com/translate_tts?ie=UTF-8&tl=tr&client=gtx&q=" + q,
            "https://api.streamelements.com/kappa/v2/speech?voice=Filiz&text=" + q
        ];
        let i = 0;
        const dene = () => {
            if (!aktif()) return;
            if (i >= kaynaklar.length) { sonCare(); return; }
            const a = new Audio();
            this.aktifAudio = a;
            // crossOrigin KULLANMA: CORS başlığı olmayan ses dosyalarını engeller
            a.setAttribute('referrerpolicy', 'no-referrer');
            a.preload = 'auto';
            let ilerledi = false;
            const sonraki = () => {
                if (ilerledi || !aktif()) return;
                ilerledi = true;
                a.onended = a.onerror = a.onplaying = null;
                try { a.pause(); } catch (e) {}
                dene();
            };
            const zamanAsimi = setTimeout(sonraki, 6000);
            a.onplaying = () => { clearTimeout(zamanAsimi); this.durumYaz('Online ses'); };
            a.onended = () => { clearTimeout(zamanAsimi); if (!ilerledi) { ilerledi = true; tamamla(); } };
            a.onerror = () => { clearTimeout(zamanAsimi); sonraki(); };
            a.src = kaynaklar[i++];
            const p = a.play();
            if (p && p.catch) p.catch(() => { clearTimeout(zamanAsimi); sonraki(); });
        };
        dene();
    },

    ritmikHecele(metin) {
        try {
            this.audioContextHazirla();
            const ctx = this.audioCtx;
            if (!ctx) return;
            if (ctx.state === 'suspended') ctx.resume();
            const kelimeler = metin.split(' ');
            const t0 = ctx.currentTime;
            kelimeler.forEach((k, i) => {
                const osc = ctx.createOscillator();
                const g = ctx.createGain();
                osc.type = 'triangle';
                const t = t0 + i * 0.16;
                osc.frequency.setValueAtTime(350 + (i % 4) * 80, t);
                g.gain.setValueAtTime(0.2, t);
                g.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
                osc.connect(g); g.connect(ctx.destination);
                osc.start(t); osc.stop(t + 0.14);
            });
        } catch (e) {}
    },

    efektCal(tip) {
        if (!this.sesAcik) return;
        try {
            this.audioContextHazirla();
            const ctx = this.audioCtx;
            if (!ctx) return;
            if (ctx.state === 'suspended') ctx.resume();
            const now = ctx.currentTime;
            const ayar = {
                dogru: { notalar: [523.25, 659.25, 783.99, 1046.5], aralik: 0.08, tip: 'triangle', vol: 0.25, sure: 0.2 },
                yanlis: { notalar: [320, 220], aralik: 0.12, tip: 'sine', vol: 0.2, sure: 0.2 },
                basla: { notalar: [440, 554.37, 659.25, 880], aralik: 0.06, tip: 'sine', vol: 0.18, sure: 0.15 }
            }[tip];
            if (!ayar) return;
            ayar.notalar.forEach((f, i) => {
                const osc = ctx.createOscillator();
                const g = ctx.createGain();
                const t = now + i * ayar.aralik;
                osc.type = ayar.tip;
                osc.frequency.setValueAtTime(f, t);
                g.gain.setValueAtTime(ayar.vol, t);
                g.gain.exponentialRampToValueAtTime(0.001, t + ayar.sure);
                osc.connect(g); g.connect(ctx.destination);
                osc.start(t); osc.stop(t + ayar.sure);
            });
        } catch (e) {}
    }
};

window.addEventListener('DOMContentLoaded', () => window.SesMotoru.init());
