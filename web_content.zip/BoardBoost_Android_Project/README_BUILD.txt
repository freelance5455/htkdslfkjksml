BOARD BOOST — CBSE CLASS 12 COMMERCE
Android Studio project

PHONE-TO-APK OPTION:
This folder is also suitable for online HTML/APK builders only if they accept Android projects; otherwise use BoardBoost_CBSE12_Web_Package.zip, which is the web package.

ANDROID STUDIO:
1. Extract this ZIP on a Windows/macOS/Linux/ChromeOS computer.
2. Open the extracted BoardBoost_Android_Project folder in Android Studio.
3. Allow Gradle sync to finish. Android Studio may download Gradle/SDK components.
4. Build > Build APK(s).
5. APK is normally under app/build/outputs/apk/debug/app-debug.apk.

APP DETAILS:
Name: BoardBoost
Package: com.boardboost.cbse12
Min Android: API 23
Target Android: API 35
Portrait orientation.
The dashboard is bundled locally as app/src/main/assets/index.html.
No INTERNET permission is required for the dashboard's offline functionality.
