[Setup]
AppName=Quero que atues como um Arquitet
AppVersion=1.0
DefaultDirName={localappdata}\Quero que atues como um Arquitet
DefaultGroupName=Quero que atues como um Arquitet
DisableProgramGroupPage=yes
OutputBaseFilename=QueroqueatuescomoumArquitet-Setup
Compression=lzma2
WizardStyle=modern
PrivilegesRequired=admin

[Languages]
Name: "pt"; MessagesFile: "compiler:Languages\Portuguese.isl"

[Types]
Name: "rec"; Description: "Recomendada"
Name: "full"; Description: "Completa (todos os motores)"
Name: "custom"; Description: "Personalizada"; Flags: iscustom

[Components]
Name: "app"; Description: "Quero que atues como um Arquitet"; Types: rec full custom; Flags: fixed
Name: "e_webview2"; Description: "WebView2 (janela da app)"; Types: rec full
Name: "e_vcredist"; Description: "Visual C++ Runtime"; Types: rec full
Name: "e_node"; Description: "Node.js LTS"; Types: full
Name: "e_python"; Description: "Python 3.12"; Types: full
Name: "e_git"; Description: "Git"; Types: full
Name: "e_ffmpeg"; Description: "FFmpeg"; Types: full
Name: "e_dotnet"; Description: ".NET Desktop 8"; Types: full
Name: "e_ollama"; Description: "Ollama (IA local)"; Types: full
Name: "e_java"; Description: "Java 21 (JDK)"; Types: full
Name: "e_go"; Description: "Go"; Types: full
Name: "e_rust"; Description: "Rust"; Types: full
Name: "e_docker"; Description: "Docker Desktop"; Types: full
Name: "e_imagemagick"; Description: "ImageMagick"; Types: full
Name: "e_cuda"; Description: "NVIDIA CUDA Toolkit"; Types: full

[Tasks]
Name: "desk"; Description: "Criar atalho no ambiente de trabalho"

[Files]
Source: "app\*"; DestDir: "{app}\app"; Flags: recursesubdirs ignoreversion
Source: "iniciar.bat"; DestDir: "{app}"
Source: "preparar.bat"; DestDir: "{app}"

[Icons]
Name: "{autoprograms}\Quero que atues como um Arquitet"; Filename: "{app}\iniciar.bat"; WorkingDir: "{app}"
Name: "{autodesktop}\Quero que atues como um Arquitet"; Filename: "{app}\iniciar.bat"; Tasks: desk

[Run]
Filename: "winget"; Parameters: "install --id Microsoft.EdgeWebView2Runtime -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_webview2; StatusMsg: "A instalar WebView2 (janela da app)…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Microsoft.VCRedist.2015+.x64 -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_vcredist; StatusMsg: "A instalar Visual C++ Runtime…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_node; StatusMsg: "A instalar Node.js LTS…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Python.Python.3.12 -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_python; StatusMsg: "A instalar Python 3.12…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Git.Git -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_git; StatusMsg: "A instalar Git…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Gyan.FFmpeg -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_ffmpeg; StatusMsg: "A instalar FFmpeg…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Microsoft.DotNet.DesktopRuntime.8 -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_dotnet; StatusMsg: "A instalar .NET Desktop 8…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Ollama.Ollama -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_ollama; StatusMsg: "A instalar Ollama (IA local)…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id EclipseAdoptium.Temurin.21.JDK -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_java; StatusMsg: "A instalar Java 21 (JDK)…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id GoLang.Go -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_go; StatusMsg: "A instalar Go…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Rustlang.Rustup -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_rust; StatusMsg: "A instalar Rust…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Docker.DockerDesktop -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_docker; StatusMsg: "A instalar Docker Desktop…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id ImageMagick.ImageMagick -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_imagemagick; StatusMsg: "A instalar ImageMagick…"; Flags: runhidden waituntilterminated
Filename: "winget"; Parameters: "install --id Nvidia.CUDA -e --silent --accept-package-agreements --accept-source-agreements"; Components: e_cuda; StatusMsg: "A instalar NVIDIA CUDA Toolkit…"; Flags: runhidden waituntilterminated
Filename: "{app}\preparar.bat"; StatusMsg: "A instalar bibliotecas e ficheiros do projeto…"; Flags: runhidden waituntilterminated
Filename: "{app}\iniciar.bat"; Description: "Abrir Quero que atues como um Arquitet"; Flags: postinstall nowait skipifsilent shellexec