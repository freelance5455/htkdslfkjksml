-- KOR staff-only access policies
-- First disable public sign-ups in Supabase Dashboard > Authentication > Settings.
-- Create staff accounts manually in Authentication > Users.
-- Run this SQL in Supabase SQL Editor.

alter table public.students enable row level security;
alter table public.attendance enable row level security;
alter table public.inventory enable row level security;
alter table public.payments enable row level security;

 drop policy if exists "staff access students" on public.students;
 create policy "staff access students" on public.students for all to authenticated using (true) with check (true);
 drop policy if exists "staff access attendance" on public.attendance;
 create policy "staff access attendance" on public.attendance for all to authenticated using (true) with check (true);
 drop policy if exists "staff access inventory" on public.inventory;
 create policy "staff access inventory" on public.inventory for all to authenticated using (true) with check (true);
 drop policy if exists "staff access payments" on public.payments;
 create policy "staff access payments" on public.payments for all to authenticated using (true) with check (true);
