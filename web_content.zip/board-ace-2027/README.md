# BOARD ACE 2027

An Android-friendly, installable Progressive Web App for CBSE Class 10 study planning.

## Technology
- React 18 + TypeScript + Vite
- PWA manifest and service worker
- Browser localStorage for on-device data
- No paid backend or API key required for core features

## Run locally
1. Install Node.js 20 LTS or later on a computer.
2. Extract this ZIP.
3. Open a terminal in the `board-ace-2027` folder.
4. Run `npm install`
5. Run `npm run dev`
6. Open the local address printed by Vite.

To create a production build:
- Run `npm run build`
- The deployable website is in `dist/`.
- Deploy the `dist` folder to any HTTPS static hosting provider.

## Install on Android
1. Deploy the `dist` folder to an HTTPS website (PWA installation requires HTTPS, except localhost).
2. Open that website in Chrome on your Android phone.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen**.
4. Confirm. BOARD ACE will appear with an app icon.

## Included working features
- Responsive mobile dashboard and bottom navigation
- Editable board exam countdown date
- Daily task creation, completion and deletion
- Subject-wise editable chapter/topic tracker with status
- Practice-test score logging and history
- Revision list based on topics marked “Needs revision”
- Personal notes with deletion
- Search across subjects, tasks and notes
- Dark/light theme and adjustable text size
- JSON export/import backup
- Offline app-shell caching
- Tutor prompt handoff (copies a prompt; no fake AI connection)

## Data and privacy
All student data is stored in localStorage in the current browser profile. It is not automatically cloud-synced or encrypted. Export a backup regularly. Do not use a shared/public device for private notes. Clearing browser storage can erase the app's saved data.

## Syllabus accuracy
The app deliberately starts with an empty editable chapter list. Add chapter names only after checking your school's confirmed subject list and the official CBSE 2026–27 curriculum:
https://cbseacademic.nic.in/curriculum_2027.html

Class X curriculum listings include Mathematics, Science, Social Science and language subjects including English and Odia. “Computer” can refer to different electives/skill subjects; confirm the exact subject name and code with your school before entering its syllabus. Do not assume IT (402), Computer Applications (165), or another course without confirmation.

The exam date is editable and is only a countdown setting, not an official timetable announcement.

## Important limitations / next development steps
- AI tutoring requires a real provider integration and secure backend; this build only prepares a prompt for the student to paste into their chosen AI assistant.
- Notifications, true background sync, cloud backup, and native APK packaging are not included in this first release.
- Test score records are entered by the student; this version does not yet contain a question bank or official CBSE papers.
- Offline caching covers the app shell; previously visited app code and locally saved data remain available, but external font loading and external links need internet.
- For multi-device sync, encrypted cloud storage, notification scheduling or Play Store distribution, add a secure backend and a native wrapper in a later release.

## Manual testing checklist
- [ ] Home dashboard loads on a narrow Android viewport
- [ ] Add, complete and delete today's task
- [ ] Add syllabus topics and change all five statuses
- [ ] Save a practice test and verify percentage
- [ ] Mark a topic “Needs revision” and see it in Revision
- [ ] Save and delete a note
- [ ] Search for a subject, task and note
- [ ] Switch light/dark themes
- [ ] Change text size and exam date
- [ ] Export JSON, clear app data, then import the backup
- [ ] Install from Chrome over HTTPS
- [ ] Open the installed app once online, then test app-shell loading offline

## Update the app
Edit files in `src/`, then run `npm run build` and redeploy the new `dist/` folder. Increase the cache name in `public/sw.js` when changing cached shell assets.
