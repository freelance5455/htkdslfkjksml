import { useEffect, useMemo, useState } from 'react'

type Task = { id: string; title: string; subject: string; minutes: number; date: string; done: boolean; detail: string }
type Chapter = { id: string; name: string; status: 'Not started'|'Learning'|'Practising'|'Completed'|'Needs revision' }
type Note = { id: string; title: string; body: string; subject: string; updated: string }
type Result = { id: string; title: string; subject: string; score: number; total: number; date: string; weak: string }
type Data = { tasks: Task[]; chapters: Record<string, Chapter[]>; notes: Note[]; results: Result[]; examDate: string; theme: 'dark'|'light'; font: number; streak: number; lastDone: string }
const SUBJECTS = ['Mathematics Standard','Science','Social Science','English','Odia','Information Technology / Computer']
const COLORS = ['#8b9cff','#59c6ad','#e6aa62','#d18ce8','#65b9e9','#e18b9b']
const today = () => new Date().toISOString().slice(0,10)
const uid = () => Math.random().toString(36).slice(2,10)
const initial: Data = {
  tasks: [
    {id:'t1',title:'Revise one Maths concept',subject:SUBJECTS[0],minutes:40,date:today(),done:false,detail:'Read your textbook examples and solve 5 questions.'},
    {id:'t2',title:'Science concept study',subject:SUBJECTS[1],minutes:40,date:today(),done:false,detail:'Study one topic and write a short explanation.'},
    {id:'t3',title:'Recall yesterday’s learning',subject:'Revision',minutes:20,date:today(),done:false,detail:'Close the book and recall key points.'}
  ],
  chapters: Object.fromEntries(SUBJECTS.map(s => [s, []])),
  notes: [], results: [], examDate:'2027-02-17', theme:'dark', font:100, streak:0, lastDone:''
}
function load(): Data {
  try { const raw = localStorage.getItem('board-ace-data'); return raw ? {...initial,...JSON.parse(raw)} : initial } catch { return initial }
}
function App() {
  const [data,setData] = useState<Data>(load)
  const [page,setPage] = useState('Home')
  const [subject,setSubject] = useState(SUBJECTS[0])
  const [newTask,setNewTask] = useState({title:'',subject:SUBJECTS[0],minutes:'30',detail:''})
  const [newChapter,setNewChapter] = useState('')
  const [note,setNote] = useState({title:'',body:'',subject:SUBJECTS[0]})
  const [test,setTest] = useState({title:'Quick practice',subject:SUBJECTS[0],score:'',total:'10',weak:''})
  const [search,setSearch] = useState('')
  const [toast,setToast] = useState('')
  const [assistantQuestion,setAssistantQuestion] = useState('')
  const [assistantStyle,setAssistantStyle] = useState('Explain in simple Hinglish, then give a board-exam-ready answer in English.')
  useEffect(()=>{ localStorage.setItem('board-ace-data',JSON.stringify(data)) },[data])
  useEffect(()=>{ if(!toast) return; const t=setTimeout(()=>setToast(''),2600); return ()=>clearTimeout(t) },[toast])
  const update = (patch: Partial<Data>) => setData(d=>({...d,...patch}))
  const tasksToday = data.tasks.filter(t=>t.date===today())
  const completed = tasksToday.filter(t=>t.done).length
  const minutesToday = tasksToday.filter(t=>t.done).reduce((a,t)=>a+t.minutes,0)
  const totalChapters = Object.values(data.chapters).flat()
  const syllabusDone = totalChapters.length ? Math.round(totalChapters.filter(c=>c.status==='Completed').length/totalChapters.length*100) : 0
  const daysLeft = Math.max(0,Math.ceil((new Date(data.examDate+'T00:00:00').getTime()-new Date(today()+'T00:00:00').getTime())/86400000))
  const weeklyMinutes = data.tasks.filter(t=>t.done && (Date.now()-new Date(t.date+'T00:00:00').getTime())<7*86400000).reduce((a,t)=>a+t.minutes,0)
  const allItems = useMemo(()=>[
    ...SUBJECTS.map(s=>({type:'Subject',label:s})),
    ...data.tasks.map(t=>({type:'Task',label:t.title})),
    ...data.notes.map(n=>({type:'Note',label:n.title}))
  ].filter(x=>x.label.toLowerCase().includes(search.toLowerCase())),[data,search])
  const setTaskDone = (id:string) => setData(d=>{
    const tasks=d.tasks.map(t=>t.id===id?{...t,done:!t.done}:t)
    const nowDone=tasks.some(t=>t.id===id && t.done)
    const todayCount=tasks.filter(t=>t.date===today()&&t.done).length
    const streak=nowDone && todayCount===1 && d.lastDone!==today()?d.streak+1:d.streak
    return {...d,tasks,streak,lastDone:nowDone?today():d.lastDone}
  })
  const addTask = () => {
    if(!newTask.title.trim()) return setToast('Please enter a task name.')
    const mins=Number(newTask.minutes)
    if(!Number.isFinite(mins)||mins<5||mins>240) return setToast('Duration must be 5–240 minutes.')
    update({tasks:[{id:uid(),title:newTask.title.trim(),subject:newTask.subject,minutes:mins,date:today(),done:false,detail:newTask.detail},...data.tasks]})
    setNewTask({...newTask,title:'',detail:''}); setToast('Task added to today.')
  }
  const addChapter = () => {
    if(!newChapter.trim()) return setToast('Enter a chapter or topic name.')
    update({chapters:{...data.chapters,[subject]:[...(data.chapters[subject]||[]),{id:uid(),name:newChapter.trim(),status:'Not started'}]}})
    setNewChapter(''); setToast('Syllabus item added.')
  }
  const updateChapter = (id:string,status:Chapter['status']) => update({chapters:{...data.chapters,[subject]:(data.chapters[subject]||[]).map(c=>c.id===id?{...c,status}:c)}})
  const addNote = () => {
    if(!note.title.trim()||!note.body.trim()) return setToast('Add a note title and its content.')
    update({notes:[{id:uid(),...note,updated:new Date().toLocaleString()},...data.notes]})
    setNote({...note,title:'',body:''}); setToast('Note saved on this device.')
  }
  const saveResult = () => {
    const score=Number(test.score), total=Number(test.total)
    if(!test.title.trim()||!Number.isFinite(score)||!Number.isFinite(total)||total<=0||score<0||score>total) return setToast('Enter a valid test title and score.')
    update({results:[{id:uid(),title:test.title,subject:test.subject,score,total,date:today(),weak:test.weak},...data.results]})
    setTest({...test,title:'',score:'',weak:''}); setToast('Test result saved.')
  }
  const exportData = () => {
    const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'})
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='board-ace-backup.json'; a.click(); URL.revokeObjectURL(url); setToast('Backup downloaded.')
  }
  const importData = (file?:File) => {
    if(!file) return
    const reader=new FileReader()
    reader.onload=()=>{try{const parsed=JSON.parse(String(reader.result)); if(!parsed.tasks||!parsed.chapters) throw new Error(); update({...initial,...parsed}); setToast('Backup restored.')}catch{setToast('That backup file is not valid.')}}; reader.readAsText(file)
  }
  const copyPrompt = async () => {
    const prompt=`Act as a careful CBSE Class 10 tutor. ${assistantStyle}\nQuestion/topic: ${assistantQuestion}\nGive a step-by-step explanation, then a concise exam-ready answer. Clearly say if anything is uncertain and do not claim your answer is an official marking scheme.`
    try { await navigator.clipboard.writeText(prompt); setToast('Tutor prompt copied. Paste it into your AI assistant.') } catch { setToast('Clipboard unavailable. Select and copy the prompt manually.') }
  }
  const nav=[['Home','⌂'],['Planner','▦'],['Subjects','▤'],['Tests','◷'],['Revision','↻'],['More','•••']]
  return <div className={`app ${data.theme}`} style={{'--font-scale':data.font/100} as React.CSSProperties}>
    <header className="topbar"><div className="brand"><div className="brandmark">BA</div><div><b>BOARD ACE <span>2027</span></b><small>YOUR BOARD EXAM COMPANION</small></div></div><button className="icon-btn" onClick={()=>update({theme:data.theme==='dark'?'light':'dark'})} aria-label="Toggle theme">{data.theme==='dark'?'☀':'☾'}</button></header>
    <main>
      {page==='Home'&&<section>
        <div className="welcome"><div><p className="eyebrow">TUESDAY · {new Date().toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'})}</p><h1>Small steps.<br/><em>Big results.</em></h1><p className="muted">Your Class 10 preparation, one focused day at a time.</p></div><div className="countdown"><strong>{daysLeft}</strong><span>DAYS TO BOARD<br/>EXAM DATE</span></div></div>
        <div className="hero-actions"><button className="primary" onClick={()=>setPage('Planner')}>Start today’s study <span>→</span></button><button className="secondary" onClick={()=>setPage('Subjects')}>Explore subjects</button></div>
        <div className="stats-grid">
          <Stat label="Today completed" value={`${completed}/${tasksToday.length}`} sub={`${tasksToday.length-completed} tasks pending`}/>
          <Stat label="Study time" value={`${minutesToday} min`} sub="Completed today"/>
          <Stat label="Weekly focus" value={`${Math.round(weeklyMinutes/60*10)/10} h`} sub="Last 7 days"/>
          <Stat label="Syllabus progress" value={`${syllabusDone}%`} sub={`${totalChapters.length} items added`}/>
        </div>
        <div className="section-head"><div><p className="eyebrow">YOUR FOCUS</p><h2>Today’s targets</h2></div><button className="text-btn" onClick={()=>setPage('Planner')}>View planner →</button></div>
        <div className="card task-card">{tasksToday.length===0?<Empty text="No tasks for today. Add a small target in Planner."/>:tasksToday.map(t=><TaskRow key={t.id} task={t} onToggle={()=>setTaskDone(t.id)}/>)}</div>
        <div className="section-head"><div><p className="eyebrow">YOUR SIX SUBJECTS</p><h2>Keep moving forward</h2></div><button className="text-btn" onClick={()=>setPage('Subjects')}>All subjects →</button></div>
        <div className="subject-grid">{SUBJECTS.map((s,i)=><button className="subject-tile" key={s} onClick={()=>{setSubject(s);setPage('Subjects')}}><span className="subject-dot" style={{background:COLORS[i]}}></span><b>{s}</b><small>{(data.chapters[s]||[]).length} syllabus items</small><span className="tile-arrow">↗</span></button>)}</div>
        <div className="quote">“Consistency beats last-minute pressure.”<small>— Your daily reminder</small></div>
      </section>}
      {page==='Planner'&&<section><PageTitle eyebrow="PLAN WITH PURPOSE" title="Daily study planner" desc="Keep your plan realistic around school, meals, breaks and sleep."/>
        <div className="card schedule"><b>Suggested weekday rhythm</b><div className="timeline"><span>7:00 AM – 2:00 PM</span><p>School</p><span>2:00 PM – 4:00 PM</span><p>Lunch, rest and reset</p><span>4:00 PM – 5:00 PM</span><p>Focused study block 1</p><span>5:00 PM – 5:30 PM</span><p>Break</p><span>5:30 PM – 6:30 PM</span><p>Focused study block 2</p><span>After 6:30 PM</span><p>Revision, dinner and free time</p></div><small className="muted">Adjust this rhythm to your actual homework, family routine and sleep needs.</small></div>
        <div className="section-head"><div><p className="eyebrow">ADD A TARGET</p><h2>Build today’s plan</h2></div></div>
        <div className="card form-grid"><Field label="Task name"><input value={newTask.title} onChange={e=>setNewTask({...newTask,title:e.target.value})} placeholder="e.g. Practise quadratic equations"/></Field><Field label="Subject"><select value={newTask.subject} onChange={e=>setNewTask({...newTask,subject:e.target.value})}>{[...SUBJECTS,'Revision','Homework'].map(s=><option>{s}</option>)}</select></Field><Field label="Duration (minutes)"><input type="number" min="5" max="240" value={newTask.minutes} onChange={e=>setNewTask({...newTask,minutes:e.target.value})}/></Field><Field label="What will you do?"><input value={newTask.detail} onChange={e=>setNewTask({...newTask,detail:e.target.value})} placeholder="Read, practise, recall…"/></Field><button className="primary full" onClick={addTask}>＋ Add study task</button></div>
        <div className="section-head"><div><p className="eyebrow">{new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'})}</p><h2>Task checklist</h2></div><span className="pill">{completed}/{tasksToday.length} done</span></div>
        <div className="card task-card">{tasksToday.length?tasksToday.map(t=><TaskRow key={t.id} task={t} onToggle={()=>setTaskDone(t.id)} onDelete={()=>update({tasks:data.tasks.filter(x=>x.id!==t.id)})}/>):<Empty text="Your day is clear. Add a task above."/>}</div>
        <div className="section-head"><h2>Upcoming tasks</h2></div><div className="card task-card">{data.tasks.filter(t=>t.date>today()).sort((a,b)=>a.date.localeCompare(b.date)).map(t=><div className="task-row" key={t.id}><div><b>{t.title}</b><small>{t.date} · {t.subject}</small></div><button className="tiny-btn" onClick={()=>update({tasks:data.tasks.filter(x=>x.id!==t.id)})}>Remove</button></div>)}{!data.tasks.some(t=>t.date>today())&&<Empty text="No upcoming tasks yet."/>}</div>
      </section>}
      {page==='Subjects'&&<section><PageTitle eyebrow="YOUR LEARNING LIBRARY" title="Subject tracker" desc="Add chapters from your own verified school syllabus. Nothing is pre-filled or assumed."/>
        <div className="subject-tabs">{SUBJECTS.map((s,i)=><button key={s} className={subject===s?'active':''} onClick={()=>setSubject(s)}><span style={{background:COLORS[i]}}></span>{s}</button>)}</div>
        <div className="card"><div className="card-title"><div><p className="eyebrow">SYLLABUS TRACKER</p><h3>{subject}</h3></div><span className="pill">{(data.chapters[subject]||[]).length} topics</span></div>
          <div className="add-inline"><input value={newChapter} onChange={e=>setNewChapter(e.target.value)} placeholder="Enter exact chapter / topic name"/><button className="primary" onClick={addChapter}>Add</button></div>
          {(data.chapters[subject]||[]).length===0?<Empty text="No chapters added. Use your current CBSE syllabus or school list to add the exact names."/>:(data.chapters[subject]||[]).map(c=><div className="chapter-row" key={c.id}><div><b>{c.name}</b><small>Update as you make progress</small></div><select value={c.status} onChange={e=>updateChapter(c.id,e.target.value as Chapter['status'])}>{['Not started','Learning','Practising','Completed','Needs revision'].map(x=><option>{x}</option>)}</select><button className="remove" onClick={()=>update({chapters:{...data.chapters,[subject]:data.chapters[subject].filter(x=>x.id!==c.id)}})}>×</button></div>)}
        </div>
        <div className="notice"><b>CBSE accuracy note</b><p>For 2026–27, check your exact Class X subject and syllabus against CBSE’s official curriculum and your school confirmation. Mathematics Standard, Science and Social Science are listed in the official curriculum; English and Odia appear in the language list. “Computer” is not a single universal subject name—confirm whether your school has Information Technology, Computer Applications or another elective before adding its syllabus.</p><a href="https://cbseacademic.nic.in/curriculum_2027.html" target="_blank" rel="noreferrer">Open CBSE Curriculum 2026–27 ↗</a></div>
      </section>}
      {page==='Tests'&&<section><PageTitle eyebrow="PRACTISE · REVIEW · IMPROVE" title="Test centre" desc="Record your practice scores and identify what to revise next."/>
        <div className="notice"><b>Authenticity matters</b><p>Questions you create or enter here are personal practice—not official CBSE papers. Use the CBSE website for authentic sample papers and previous-year papers.</p><a href="https://cbseacademic.nic.in/" target="_blank" rel="noreferrer">CBSE Academic website ↗</a></div>
        <div className="card"><p className="eyebrow">RECORD A PRACTICE TEST</p><div className="form-grid"><Field label="Test name"><input value={test.title} onChange={e=>setTest({...test,title:e.target.value})} placeholder="e.g. Trigonometry practice"/></Field><Field label="Subject"><select value={test.subject} onChange={e=>setTest({...test,subject:e.target.value})}>{SUBJECTS.map(s=><option>{s}</option>)}</select></Field><div className="two-fields"><Field label="Score"><input type="number" value={test.score} onChange={e=>setTest({...test,score:e.target.value})} placeholder="e.g. 8"/></Field><Field label="Out of"><input type="number" value={test.total} onChange={e=>setTest({...test,total:e.target.value})}/></Field></div><Field label="Topics to revise (optional)"><input value={test.weak} onChange={e=>setTest({...test,weak:e.target.value})} placeholder="e.g. identities, word problems"/></Field><button className="primary full" onClick={saveResult}>Save test result</button></div></div>
        <div className="section-head"><h2>Test history</h2><span className="pill">{data.results.length} tests</span></div>
        <div className="card">{data.results.length===0?<Empty text="Your saved test scores will appear here. No sample scores are shown."/>:data.results.map(r=><div className="result-row" key={r.id}><div><b>{r.title}</b><small>{r.subject} · {r.date}{r.weak?` · Revise: ${r.weak}`:''}</small></div><strong>{r.score}/{r.total}<small>{Math.round(r.score/r.total*100)}%</small></strong><button className="remove" onClick={()=>update({results:data.results.filter(x=>x.id!==r.id)})}>×</button></div>)}</div>
      </section>}
      {page==='Revision'&&<section><PageTitle eyebrow="REMEMBER MORE" title="Revision centre" desc="Use active recall: close the book, explain the idea, then check what you missed."/>
        <div className="stats-grid"><Stat label="Needs revision" value={totalChapters.filter(c=>c.status==='Needs revision').length.toString()} sub="Topics marked by you"/><Stat label="Completed topics" value={totalChapters.filter(c=>c.status==='Completed').length.toString()} sub="Across all subjects"/></div>
        <div className="section-head"><h2>Topics to revisit</h2></div><div className="card">{totalChapters.filter(c=>c.status==='Needs revision').length===0?<Empty text="Nothing marked for revision yet. Mark a topic as Needs revision in Subjects."/>:SUBJECTS.flatMap(s=>(data.chapters[s]||[]).filter(c=>c.status==='Needs revision').map(c=><div className="task-row" key={c.id}><div><b>{c.name}</b><small>{s}</small></div><button className="tiny-btn" onClick={()=>{setSubject(s);setPage('Subjects')}}>Review</button></div>))}</div>
        <div className="section-head"><h2>Quick recall routine</h2></div><div className="card recall-list"><p><b>1. Recall without looking</b><small>Write what you remember for 3–5 minutes.</small></p><p><b>2. Check your textbook</b><small>Correct missing points in a different pen.</small></p><p><b>3. Practise one question</b><small>Apply the concept in a board-style answer.</small></p><p><b>4. Schedule another review</b><small>Revisit tomorrow, then after a few days.</small></p></div>
      </section>}
      {page==='More'&&<section><PageTitle eyebrow="YOUR PERSONAL WORKSPACE" title="More tools" desc="Keep your study material organised and backed up."/>
        <div className="card"><p className="eyebrow">AI STUDY ASSISTANT HANDOFF</p><h3>Prepare a tutor prompt</h3><p className="muted">This app does not pretend to have an AI service connected. Copy a carefully structured question and paste it into your preferred AI assistant.</p><Field label="Your question or topic"><textarea rows={3} value={assistantQuestion} onChange={e=>setAssistantQuestion(e.target.value)} placeholder="e.g. Explain the distance formula with one example."/></Field><Field label="Answer style"><select value={assistantStyle} onChange={e=>setAssistantStyle(e.target.value)}><option>Explain in simple Hinglish, then give a board-exam-ready answer in English.</option><option>Teach me step by step and ask me one practice question.</option><option>Check my answer using a clear marking rubric; do not claim it is an official CBSE marking scheme.</option><option>Create concise revision notes and five practice questions.</option></select></Field><button className="primary full" disabled={!assistantQuestion.trim()} onClick={copyPrompt}>Copy tutor prompt</button></div>
        <div className="card"><p className="eyebrow">PERSONAL NOTES</p><h3>Save a study note</h3><div className="form-grid"><Field label="Title"><input value={note.title} onChange={e=>setNote({...note,title:e.target.value})} placeholder="Note title"/></Field><Field label="Subject"><select value={note.subject} onChange={e=>setNote({...note,subject:e.target.value})}>{SUBJECTS.map(s=><option>{s}</option>)}</select></Field><Field label="Content"><textarea rows={4} value={note.body} onChange={e=>setNote({...note,body:e.target.value})} placeholder="Write formulas, definitions or reminders…"/></Field><button className="primary full" onClick={addNote}>Save note</button></div></div>
        <div className="section-head"><h2>Saved notes</h2></div><div className="card">{data.notes.length===0?<Empty text="Your notes will be saved privately on this device."/>:data.notes.map(n=><div className="note-row" key={n.id}><div><b>{n.title}</b><small>{n.subject} · {n.updated}</small><p>{n.body}</p></div><button className="remove" onClick={()=>update({notes:data.notes.filter(x=>x.id!==n.id)})}>×</button></div>)}</div>
        <div className="card"><p className="eyebrow">APP PREFERENCES</p><Field label={`Text size · ${data.font}%`}><input type="range" min="85" max="125" step="5" value={data.font} onChange={e=>update({font:Number(e.target.value)})}/></Field><Field label="Board exam date (editable)"><input type="date" value={data.examDate} onChange={e=>update({examDate:e.target.value})}/></Field><p className="muted small">Countdown uses this date. Confirm the actual exam timetable when CBSE publishes it.</p><div className="backup-actions"><button className="secondary" onClick={exportData}>↓ Export backup</button><label className="secondary file-label">↑ Import backup<input type="file" accept="application/json" onChange={e=>importData(e.target.files?.[0])}/></label></div></div>
        <div className="notice"><b>Privacy & storage</b><p>Your notes, tasks and scores are stored in this browser on this device. They are not automatically synced to a cloud account. Export a backup regularly, especially before clearing browser data or changing phones.</p></div>
      </section>}
      {search.trim()&&<div className="search-results"><b>Search results</b>{allItems.length?allItems.slice(0,8).map((x,i)=><p key={i}><small>{x.type}</small> {x.label}</p>):<p className="muted">No matching items.</p>}</div>}
    </main>
    <div className="searchbar"><span>⌕</span><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search subjects, tasks and notes…"/>{search&&<button onClick={()=>setSearch('')}>×</button>}</div>
    <nav className="bottom-nav">{nav.map(([name,icon])=><button key={name} className={page===name?'selected':''} onClick={()=>setPage(name)}><span>{icon}</span><small>{name}</small></button>)}</nav>
    {toast&&<div className="toast">{toast}</div>}
    <footer>BOARD ACE 2027 <span>·</span> Made for steady progress</footer>
  </div>
}
function Stat({label,value,sub}:{label:string,value:string,sub:string}){return <div className="stat"><small>{label}</small><strong>{value}</strong><span>{sub}</span></div>}
function PageTitle({eyebrow,title,desc}:{eyebrow:string,title:string,desc:string}){return <div className="page-title"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="muted">{desc}</p></div>}
function Field({label,children}:{label:string,children:React.ReactNode}){return <label className="field"><span>{label}</span>{children}</label>}
function Empty({text}:{text:string}){return <div className="empty">{text}</div>}
function TaskRow({task,onToggle,onDelete}:{task:Task,onToggle:()=>void,onDelete?:()=>void}){return <div className={`task-row ${task.done?'is-done':''}`}><button className={`check ${task.done?'checked':''}`} onClick={onToggle}>{task.done?'✓':''}</button><div className="task-copy"><b>{task.title}</b><small>{task.subject} · {task.minutes} min{task.detail?` · ${task.detail}`:''}</small></div>{onDelete&&<button className="remove" onClick={onDelete}>×</button>}</div>}
export default App
