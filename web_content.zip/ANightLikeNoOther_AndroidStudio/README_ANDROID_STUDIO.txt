# À Night Like No Other — Android Studio Project

## What's included
- `app/src/main/assets/index.html`: the complete current HTML game build supplied for this packaging task.
- `app/src/main/java/com/anightlike/noother/MainActivity.java`: Android WebView launcher with JavaScript and DOM storage enabled.
- Android manifest, theme resources, Gradle project configuration and a web manifest.
- `Game_Information_and_App_Guide.pdf`: app overview and feature reference.
- `How_to_Play_and_Game_Instructions.pdf`: player-facing instructions.

## Build an APK in Android Studio
1. Install the latest stable Android Studio.
2. In Android Studio, choose **Open** and select this unzipped `ANightLikeNoOther_AndroidStudio` folder.
3. Allow Android Studio to use/download a compatible Gradle distribution. This project is configured for Gradle 8.9 and Android Gradle Plugin 8.7.3.
4. Install Android SDK Platform 35 when prompted (Tools → SDK Manager).
5. Wait for Gradle Sync to finish. Resolve any SDK/license prompts.
6. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. When the build completes, select **locate** in the notification. The debug APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
8. Transfer that APK to your Android device and install it. If Android asks, allow installation from the file manager/browser used to open the APK.
9. For sharing beyond personal testing, create a signed release build using **Build → Generate Signed Bundle / APK** and keep the signing key in a safe backup.

## Requirements
- Android Studio with Android SDK Platform 35.
- JDK 17 or newer compatible with your Android Studio installation (Android Studio's bundled JBR is recommended).
- Internet access on first Gradle sync to download Gradle/plugin dependencies.
- Minimum Android version configured as API 23 (Android 6.0); target SDK API 35.

## Important packaging notes
- This is a WebView-based Android wrapper around the HTML game, not a rewrite into native Android UI.
- The game logic and UI are in `index.html`.
- Game persistence depends on the HTML implementation and WebView DOM storage. Back up important customized game content before uninstalling or clearing app data.
- The project includes Gradle wrapper properties but not the Gradle wrapper JAR or a prebuilt APK. Android Studio's Gradle integration can download/use the configured Gradle distribution during project sync; if your setup requires `gradlew`, use Android Studio's **Gradle wrapper** task or install Gradle and generate wrapper files.
- No signing keystore is included. Generate and protect your own release keystore.
- First run and all gameplay flows must be tested on the actual Android device. In particular test player setup, coin flip, wheel drawing, custom media, To Do Chest save/reopen, completion tracking, random turns, audio and unlock notifications.
- This package does not guarantee that every feature is bug-free or that an APK has already been built.

## Troubleshooting
- If Gradle Sync fails, check Android Studio's Gradle JDK setting and SDK Platform 35 installation.
- If the app opens to a blank screen, test the HTML in Chrome and inspect WebView errors with Android Studio Logcat.
- If local progress disappears, check app storage settings and avoid clearing app data.
- If external media fails, check its URL, network access and Android WebView media compatibility.
