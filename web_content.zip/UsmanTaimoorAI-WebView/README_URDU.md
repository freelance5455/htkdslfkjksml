# عثمان تیمور AI — Android WebView Project

یہ Android Studio project آپ کے موجودہ `index.html` کو Android WebView کے اندر کھولتا ہے۔

## Android Studio میں چلانے کا طریقہ

1. Android Studio کھولیں۔
2. `File > Open` کریں اور اس project کا فولڈر منتخب کریں۔
3. Gradle Sync مکمل ہونے دیں۔
4. فون USB debugging کے ساتھ connect کریں یا emulator چلائیں۔
5. `Run` دبائیں۔

## APK بنانے کا طریقہ

Android Studio میں:
`Build > Build App Bundle(s) / APK(s) > Build APK(s)`

APK عام طور پر `app/build/outputs/apk/debug/app-debug.apk` میں بنے گی۔

## اہم

- Chat API کے لیے Internet permission موجود ہے۔
- JavaScript اور localStorage فعال ہیں۔
- 📎 image upload کے لیے Android file chooser شامل ہے۔
- آپ کا اصل chat HTML `app/src/main/assets/index.html` میں موجود ہے۔
