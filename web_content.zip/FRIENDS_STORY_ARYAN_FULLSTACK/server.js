
const express=require("express");
const crypto=require("crypto");
const cors=require("cors");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const multer=require("multer");
const Database=require("better-sqlite3");
const path=require("path");
const fs=require("fs");
const paymentRoutes=require("./config/payments");

const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"change-this-secret";
const db=new Database("fsa.db");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use("/api/payments",paymentRoutes);
app.use("/uploads",express.static(path.join(__dirname,"uploads")));

// Extra Pocket-FM style features (demo-ready API layer)
app.get("/api/features",(req,res)=>res.json({
 coins:true, referrals:true, ratings:true, comments:true, playlists:true,
 sleepTimer:true, creatorProfiles:true, leaderboard:true, dailyReward:true
}));
app.post("/api/coins/reward",(req,res)=>res.json({ok:true,message:"Coins reward recorded (demo)",coinsEarned:Number(req.body.coins||10)}));
app.post("/api/referral/apply",(req,res)=>res.json({ok:true,message:"Referral applied (demo)",bonusCoins:50}));
app.get("/api/leaderboard",(req,res)=>res.json({items:[]}));
app.post("/api/ratings",(req,res)=>res.json({ok:true,message:"Rating saved (demo)"}));
app.post("/api/comments",(req,res)=>res.json({ok:true,message:"Comment saved (demo)"}));
app.post("/api/playlists",(req,res)=>res.json({ok:true,message:"Playlist created (demo)"}));


// Production-style premium entitlement endpoints
app.post("/api/premium/activate", auth, (req,res)=>{
  try{
    const {order_id,payment_id,signature,plan="monthly"}=req.body;
    if(!order_id||!payment_id||!signature) return res.status(400).json({error:"Payment details required"});
    const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET||"").update(order_id+"|"+payment_id).digest("hex");
    if(!process.env.RAZORPAY_KEY_SECRET || !crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(signature)))
      return res.status(400).json({error:"Invalid payment signature"});
    const days=plan==="yearly"?365:30;
    const now=new Date(), expiry=new Date(now.getTime()+days*86400000);
    db.prepare(`INSERT INTO premium(user_id,plan,payment_id,order_id,starts_at,expires_at,status)
      VALUES(?,?,?,?,?,?,?)
      ON CONFLICT(user_id) DO UPDATE SET plan=excluded.plan,payment_id=excluded.payment_id,order_id=excluded.order_id,starts_at=excluded.starts_at,expires_at=excluded.expires_at,status='active'`)
      .run(req.user.id,plan,payment_id,order_id,now.toISOString(),expiry.toISOString(),"active");
    res.json({ok:true,premium:true,expires_at:expiry.toISOString()});
  }catch(e){res.status(500).json({error:e.message})}
});

app.get("/api/premium/status", auth, (req,res)=>{
  const row=db.prepare("SELECT * FROM premium WHERE user_id=?").get(req.user.id);
  if(!row) return res.json({premium:false});
  const active=row.status==="active" && (!row.expires_at || new Date(row.expires_at)>new Date());
  if(!active) db.prepare("UPDATE premium SET status='expired' WHERE user_id=?").run(req.user.id);
  res.json({premium:active, plan:row.plan, expires_at:row.expires_at, payment_id:row.payment_id});
});

app.post("/api/payments/webhook",(req,res)=>{
  try{
    const secret=process.env.RAZORPAY_WEBHOOK_SECRET;
    const signature=req.headers["x-razorpay-signature"];
    if(!secret||!signature) return res.status(400).json({error:"Webhook secret/signature missing"});
    const raw=JSON.stringify(req.body);
    const expected=crypto.createHmac("sha256",secret).update(raw).digest("hex");
    if(expected!==signature) return res.status(400).json({error:"Invalid webhook signature"});
    // Keep webhook acknowledgement simple; entitlement should be granted only
    // after verified payment/order events are mapped to a known user/order.
    res.json({received:true});
  }catch(e){res.status(400).json({error:e.message})}
});

app.use(express.static(path.join(__dirname,"public")));

fs.mkdirSync(path.join(__dirname,"uploads"),{recursive:true});
db.exec(`CREATE TABLE IF NOT EXISTS premium (
          user_id INTEGER PRIMARY KEY,
          plan TEXT NOT NULL,
          payment_id TEXT,
          order_id TEXT,
          starts_at TEXT NOT NULL,
          expires_at TEXT,
          status TEXT NOT NULL DEFAULT 'active'
        );`);
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE,password TEXT,role TEXT DEFAULT 'user',premium INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS stories(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,category TEXT,description TEXT,cover TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS episodes(id INTEGER PRIMARY KEY AUTOINCREMENT,story_id INTEGER,title TEXT,episode_no INTEGER,audio TEXT,premium INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER,story_id INTEGER,UNIQUE(user_id,story_id));
CREATE TABLE IF NOT EXISTS history(user_id INTEGER,episode_id INTEGER,progress INTEGER DEFAULT 0,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,episode_id));
`);
const count=db.prepare("SELECT COUNT(*) c FROM stories").get().c;
if(!count){
 const add=db.prepare("INSERT INTO stories(title,category,description) VALUES(?,?,?)");
 add.run("Dil Ki Kahani","Romance","Ek emotional love story.");
 add.run("Raaz Ka Shehar","Thriller","Mystery aur suspense se bhari series.");
 add.run("Andheri Raat","Horror","Darawani kahaniyon ki series.");
}
function auth(req,res,next){
 try{const h=req.headers.authorization||"";if(!h.startsWith("Bearer "))return res.status(401).json({error:"Login required"});req.user=jwt.verify(h.slice(7),JWT_SECRET);next()}
 catch(e){return res.status(401).json({error:"Invalid token"})}
}
function admin(req,res,next){if(req.user.role!=="admin")return res.status(403).json({error:"Admin only"});next()}
const storage=multer({dest:path.join(__dirname,"uploads")});

app.post("/api/signup",async(req,res)=>{
 const {email,password}=req.body;if(!email||!password)return res.status(400).json({error:"Email and password required"});
 try{const hash=await bcrypt.hash(password,10);const info=db.prepare("INSERT INTO users(email,password) VALUES(?,?)").run(email,hash);const user={id:info.lastInsertRowid,email,role:"user"};res.json({token:jwt.sign(user,JWT_SECRET),user})}
 catch(e){res.status(400).json({error:"Email already registered"})}
});
app.post("/api/login",async(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE email=?").get(req.body.email);
 if(!u||!(await bcrypt.compare(req.body.password,u.password)))return res.status(401).json({error:"Invalid login"});
 const user={id:u.id,email:u.email,role:u.role,premium:!!u.premium};res.json({token:jwt.sign(user,JWT_SECRET),user});
});
app.get("/api/stories",(req,res)=>{
 const stories=db.prepare("SELECT * FROM stories ORDER BY id DESC").all();
 for(const s of stories)s.episodes=db.prepare("SELECT * FROM episodes WHERE story_id=? ORDER BY episode_no").all(s.id);
 res.json(stories);
});
app.get("/api/me",auth,(req,res)=>res.json(req.user));
app.post("/api/favorites/:storyId",auth,(req,res)=>{
 const id=+req.params.storyId;const old=db.prepare("SELECT 1 FROM favorites WHERE user_id=? AND story_id=?").get(req.user.id,id);
 if(old)db.prepare("DELETE FROM favorites WHERE user_id=? AND story_id=?").run(req.user.id,id);else db.prepare("INSERT OR IGNORE INTO favorites VALUES(?,?)").run(req.user.id,id);
 res.json({favorite:!old});
});
app.get("/api/favorites",auth,(req,res)=>res.json(db.prepare("SELECT s.* FROM stories s JOIN favorites f ON f.story_id=s.id WHERE f.user_id=?").all(req.user.id)));
app.post("/api/history",auth,(req,res)=>{
 const e=+req.body.episode_id,p=Math.max(0,Math.min(100,+req.body.progress||0));
 db.prepare("INSERT INTO history(user_id,episode_id,progress) VALUES(?,?,?) ON CONFLICT(user_id,episode_id) DO UPDATE SET progress=excluded.progress,updated_at=CURRENT_TIMESTAMP").run(req.user.id,e,p);
 res.json({ok:true});
});
app.get("/api/history",auth,(req,res)=>res.json(db.prepare("SELECT h.*,e.title episode_title,e.audio,e.story_id FROM history h JOIN episodes e ON e.id=h.episode_id WHERE h.user_id=? ORDER BY h.updated_at DESC").all(req.user.id)));
app.post("/api/admin/story",auth,admin,(req,res)=>{
 const x=req.body;if(!x.title||!x.category)return res.status(400).json({error:"Title/category required"});
 const info=db.prepare("INSERT INTO stories(title,category,description) VALUES(?,?,?)").run(x.title,x.category,x.description||"");
 res.json({id:info.lastInsertRowid});
});
app.post("/api/admin/episode",auth,admin,storage.single("audio"),(req,res)=>{
 if(!req.body.story_id||!req.body.title)return res.status(400).json({error:"Story/title required"});
 const audio=req.file?"/uploads/"+req.file.filename:"";
 const info=db.prepare("INSERT INTO episodes(story_id,title,episode_no,audio,premium) VALUES(?,?,?,?,?)").run(+req.body.story_id,req.body.title,+req.body.episode_no||1,audio,req.body.premium==="1"?1:0);
 res.json({id:info.lastInsertRowid,audio});
});
app.post("/api/admin/make-premium",auth,admin,(req,res)=>{db.prepare("UPDATE users SET premium=1 WHERE id=?").run(+req.body.user_id);res.json({ok:true})});
app.post("/api/premium/demo",auth,(req,res)=>{db.prepare("UPDATE users SET premium=1 WHERE id=?").run(req.user.id);res.json({premium:true})});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`FRIENDS STORY ARYAN server: http://localhost:${PORT}`));
