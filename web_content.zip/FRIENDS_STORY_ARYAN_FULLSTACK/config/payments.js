
const express=require("express");
const crypto=require("crypto");
const Razorpay=require("razorpay");
const router=express.Router();

const enabled=process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET;
const razorpay=enabled?new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET}):null;

router.post("/create-order", async (req,res)=>{
  if(!razorpay) return res.status(503).json({error:"Razorpay keys not configured"});
  try{
    const amount=Number(req.body.amount||2900);
    const order=await razorpay.orders.create({amount,currency:"INR",receipt:"fsa_"+Date.now()});
    res.json({order});
  }catch(e){res.status(500).json({error:e.message})}
});
router.post("/verify", (req,res)=>{
  const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
  const body=razorpay_order_id+"|"+razorpay_payment_id;
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET).update(body).digest("hex");
  if(expected!==razorpay_signature)return res.status(400).json({verified:false});
  res.json({verified:true});
});
module.exports=router;
