
const admin=require("firebase-admin");
let ready=false;
try{
 if(process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY){
  admin.initializeApp({credential:admin.credential.cert({
   projectId:process.env.FIREBASE_PROJECT_ID,
   clientEmail:process.env.FIREBASE_CLIENT_EMAIL,
   privateKey:process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g,"\n")
  })});
  ready=true;
 }
}catch(e){console.warn("Firebase not configured:",e.message)}
async function sendPush(token,title,body){
 if(!ready) throw new Error("Firebase not configured");
 return admin.messaging().send({token,notification:{title,body}});
}
module.exports={sendPush,isReady:()=>ready};
