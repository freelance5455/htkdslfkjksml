# FRIENDS STORY ARYAN — Full Stack

## Run
1. Install Node.js 18+.
2. Open terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

## Backend included
- SQLite database
- Signup/login with bcrypt
- JWT authentication
- Stories + episodes API
- Favorites API
- Listening history/progress API
- Admin story creation
- Admin audio upload
- Premium flag/demo subscription endpoint

## Admin
For the first admin account, after signup, change its role in SQLite:
`UPDATE users SET role='admin' WHERE email='YOUR_EMAIL';`

## Production
Set a strong JWT_SECRET environment variable.
For real payments use Razorpay/Stripe keys and server-side payment verification.
For real push notifications use Firebase/FCM or another push provider.
For cloud/offline protected audio use object storage/CDN and signed URLs.


## Real payment + notifications setup

1. Copy `config/.env.example` to `.env`.
2. Put your Razorpay test/live keys in `.env`.
3. Put your Firebase Admin service-account values in `.env`.
4. Run `npm install`.
5. Start with `npm start`.

### Razorpay
The integration includes order creation and server-side payment-signature verification.
Do not put `RAZORPAY_KEY_SECRET` in frontend code.

### Firebase notifications
The server helper is ready for FCM push notifications. A mobile/web client still needs to register an FCM token and send that token securely to your backend.

### Important
Never upload `.env` or service-account JSON files to GitHub or expose secret keys in the browser.


## Added Pocket FM-style engagement features

- 🪙 Coins + daily reward API
- 🎁 Referral/invite bonus API
- ⭐ Ratings & reviews API
- 💬 Comments API
- 📋 Custom playlists API
- ⏰ Sleep timer (frontend-ready)
- 👤 Creator profiles (frontend-ready)
- 🏆 Leaderboard API

These new endpoints are demo-ready and can be connected to the SQLite user/story tables for production persistence.


## Premium payment security

The backend now includes:
- server-side Razorpay signature verification
- Premium entitlement stored in SQLite
- monthly/yearly expiry handling
- `/api/premium/status` to check current access
- `/api/premium/activate` to unlock after verified payment
- Razorpay webhook signature validation endpoint

For production, configure `RAZORPAY_WEBHOOK_SECRET` in `.env` and configure the matching webhook in Razorpay Dashboard. Never expose Razorpay secret keys in frontend code.


## Creator photo
The uploaded Aryan photo is included as `public/aryan.jpg` and displayed in the app's creator profile/header.
