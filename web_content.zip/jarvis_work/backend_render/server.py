"""JARVIS Gemini backend. Keep GEMINI_API_KEY on the server, never in the APK."""
import os
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional

app = FastAPI(title="JARVIS Gemini Backend", version="3.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"])
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
SYSTEM = ("Siz JARVIS nomli shaxsiy AI yordamchisiz. Foydalanuvchiga Sir deb murojaat qiling. "
          "O'zbek tilida, lo'nda va aniq javob bering. Telefon amallarini bajardim deb yolg'on aytmang; "
          "agar ilova amali tasdiq talab qilsa, buni tushuntiring.")
class ChatRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=12000)
    history: Optional[list[dict]] = None
@app.get("/")
async def root(): return {"status":"online", "service":"JARVIS Gemini Backend", "model":MODEL}
@app.get("/health")
async def health(): return {"status":"healthy"}
@app.post("/chat")
async def chat(req: ChatRequest):
    key = os.getenv("GEMINI_API_KEY")
    if not key: raise HTTPException(503, "Serverda GEMINI_API_KEY sozlanmagan")
    contents = []
    for item in (req.history or [])[-8:]:
        role = item.get("role")
        text = item.get("content")
        if role in ("user", "assistant") and isinstance(text, str) and text.strip():
            contents.append({"role":"user" if role == "user" else "model", "parts":[{"text":text[:12000]}]})
    contents.append({"role":"user", "parts":[{"text":req.prompt}]})
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent"
    payload = {"system_instruction":{"parts":[{"text":SYSTEM}]}, "contents":contents, "generationConfig":{"temperature":0.6, "maxOutputTokens":1200}}
    try:
        async with httpx.AsyncClient(timeout=45) as client:
            res = await client.post(url, params={"key":key}, json=payload)
        if res.status_code != 200:
            raise HTTPException(502, f"Gemini API xatosi ({res.status_code}): {res.text[:500]}")
        data = res.json()
        answer = "".join(p.get("text", "") for p in data.get("candidates", [{}])[0].get("content", {}).get("parts", []))
        if not answer: raise HTTPException(502, "Gemini bo'sh javob qaytardi")
        return {"response":answer, "model":MODEL, "status":"success"}
    except httpx.RequestError as exc:
        raise HTTPException(503, f"Gemini bilan aloqa xatosi: {exc.__class__.__name__}")
