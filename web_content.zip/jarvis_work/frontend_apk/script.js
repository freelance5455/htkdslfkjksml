/**
 * =====================================================================
 * JARVIS AI - BRAUZER VA ANDROID APK UCHUN ASOSIY SKRIPT
 * Muallif / Dasturchi: Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)
 * =====================================================================
 */

// API kalitlari ilovaga joylanmaydi. Barcha AI so'rovlari xavfsiz backend orqali yuboriladi.
const API_BASE_URL = (window.JARVIS_CONFIG && window.JARVIS_CONFIG.API_BASE_URL || "").replace(/\/$/, "");
const GROQ_MODEL = "Gemini";

const SYSTEM_PROMPT = `Siz "Jarvis" — eng zamonaviy va sadoqatli shaxsiy sun'iy intellekt yordamchisisiz.

MUHIM QOIDALAR:
1. Foydalanuvchiga doimo "Sir" deb murojaat qiling (masalan: "Buyuring, Sir", "Xizmatingizdaman, Sir").
2. Har doim 100% faqat va faqat O'ZBEK TILIDA (lotin yozuvida) javob qaytaring.
3. Javoblaringiz lo'nda, aniq va futuristik ohangda bo'lsin.
4. QAT'IY QOIDA: Har bir javobingizda dasturchi yoki muallif nomini qo'shib yozmang! FAQAT foydalanuvchi sizdan "seni kim yaratgan", "muallifing kim", "dasturching kim" deb so'ragandagina daho dasturchi Мухаммадризо (GitHub: olimovm158-dot) tomonidan yaratilganingizni faxr bilan ayting. Boshqa paytda hech qachon muallif haqida ortiqcha gapirmang!`;

// Holat o'zgaruvchilari
let currentKeyIndex = 0;
let backendMode = "backend";
let isTTSActive = true;
let isTorchOn = false;
let torchTrack = null;
let cameraStream = null;
let chatHistory = [];

// DOM elementlari
const chatViewport = document.getElementById("chatViewport");
const textInput = document.getElementById("textInput");
const btnSendText = document.getElementById("btnSendText");
const btnVoiceRecord = document.getElementById("btnVoiceRecord");
const reactorCore = document.getElementById("reactorCore");
const coreLabel = document.getElementById("coreLabel");
const audioWaveContainer = document.getElementById("audioWaveContainer");
const systemClock = document.getElementById("systemClock");
const systemBattery = document.getElementById("systemBattery");
const activeKeyIndicator = document.getElementById("activeKeyIndicator");
const screenTorchOverlay = document.getElementById("screenTorchOverlay");

// Modallar
const cameraModal = document.getElementById("cameraModal");
const btnCloseCamera = document.getElementById("btnCloseCamera");
const cameraVideo = document.getElementById("cameraVideo");
const btnCapturePhoto = document.getElementById("btnCapturePhoto");
const capturedPhotoPreview = document.getElementById("capturedPhotoPreview");
const capturedImage = document.getElementById("capturedImage");
const btnDownloadPhoto = document.getElementById("btnDownloadPhoto");

const settingsModal = document.getElementById("settingsModal");
const btnCloseSettings = document.getElementById("btnCloseSettings");
const backendModeSelect = document.getElementById("backendModeSelect");
const ttsToggle = document.getElementById("ttsToggle");

// Tezkor tugmalar
const btnActionCamera = document.getElementById("btnActionCamera");
const btnActionTorch = document.getElementById("btnActionTorch");
const btnActionSettings = document.getElementById("btnActionSettings");
const btnActionStatus = document.getElementById("btnActionStatus");

// ---------------------------------------------------------------------
// SOAT VA TIZIM METRIKALARI
// ---------------------------------------------------------------------
function updateClock() {
  const now = new Date();
  const timeStr = now.toTimeString().split(" ")[0];
  if (systemClock) systemClock.textContent = timeStr;
}
setInterval(updateClock, 1000);
updateClock();

// Batareya holati
if (navigator.getBattery) {
  navigator.getBattery().then(battery => {
    function updateBat() {
      const level = Math.round(battery.level * 100);
      systemBattery.textContent = (battery.charging ? "⚡ " : "🔋 ") + level + "%";
    }
    updateBat();
    battery.addEventListener("levelchange", updateBat);
    battery.addEventListener("chargingchange", updateBat);
  });
}

function updateKeyDisplay() {
  if (activeKeyIndicator) activeKeyIndicator.textContent = "AI: Gemini";
}
updateKeyDisplay();

// ---------------------------------------------------------------------
// CHATGA XABAR QO'SHISH
// ---------------------------------------------------------------------
function appendMessage(role, text, meta) {
  const msgDiv = document.createElement("div");
  msgDiv.className = "chat-message " + role;

  const metaDiv = document.createElement("div");
  metaDiv.className = "msg-meta";
  metaDiv.textContent = (role === "assistant" ? "Jarvis AI" : "Siz") + (meta ? " · " + meta : "");

  const contentDiv = document.createElement("div");
  contentDiv.className = "msg-content";
  contentDiv.textContent = text;

  msgDiv.appendChild(metaDiv);
  msgDiv.appendChild(contentDiv);
  chatViewport.appendChild(msgDiv);
  chatViewport.scrollTop = chatViewport.scrollHeight;
}

// ---------------------------------------------------------------------
// OVOZ CHIQARIB O'QISH (TTS)
// ---------------------------------------------------------------------
let isSpeakingNow = false;

function speakText(text, callback) {
  if (!isTTSActive || !window.speechSynthesis) {
    if (callback) callback();
    return;
  }

  try {
    isSpeakingNow = true;
    if (recognition && isRecording) {
      try { recognition.abort(); } catch(e) {}
    }

    window.speechSynthesis.cancel();
    const clean = text.replace(/[*_#`~>]/g, "").slice(0, 450);
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = "uz-UZ";
    utterance.rate = voiceSpeed || 1.0;
    utterance.volume = voiceVolume !== undefined ? voiceVolume : 1.0;

    if (reactorCore) reactorCore.classList.add("speaking");
    if (audioWaveContainer) audioWaveContainer.classList.add("active");

    const onFinish = () => {
      isSpeakingNow = false;
      if (reactorCore) reactorCore.classList.remove("speaking");
      if (audioWaveContainer) audioWaveContainer.classList.remove("active");
      if (isContinuousModeActive) {
        setTimeout(startContinuousRecognition, 400);
      }
      if (callback) callback();
    };

    utterance.onend = onFinish;
    utterance.onerror = onFinish;

    window.speechSynthesis.speak(utterance);
  } catch(err) {
    isSpeakingNow = false;
    if (callback) callback();
  }
}

// ---------------------------------------------------------------------
// 5 TA GROQ KALIT ROTATSIYASI BILAN XABAR YUBORISH
// ---------------------------------------------------------------------
async function sendToJarvis(promptText) {
  if (!promptText || !promptText.trim()) return;
  appendMessage("user", promptText);
  textInput.value = "";
  if (coreLabel) coreLabel.textContent = "THINKING";

  const handled = checkDeviceCommands(promptText);
  if (handled) { if (coreLabel) coreLabel.textContent = "ONLINE"; return; }

  if (!API_BASE_URL || API_BASE_URL.includes("YOUR-JARVIS-BACKEND")) {
    const msg = "Sir, Gemini server hali sozlanmagan. README faylidagi backend o'rnatish bosqichlarini bajaring.";
    appendMessage("assistant", msg); speakText(msg);
    if (coreLabel) coreLabel.textContent = "OFFLINE";
    return;
  }

  try {
    const response = await fetch(API_BASE_URL + "/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: promptText, history: chatHistory.slice(-8) })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || "Backend javob bermadi: " + response.status);
    const reply = data.response || "Kechirasiz, javob olinmadi, Sir.";
    chatHistory.push({ role: "user", content: promptText }, { role: "assistant", content: reply });
    chatHistory = chatHistory.slice(-16);
    appendMessage("assistant", reply, "Gemini");
    speakText(reply);
    if (coreLabel) coreLabel.textContent = "ONLINE";
  } catch (err) {
    const msg = "Gemini serveriga ulanib bo'lmadi, Sir. Internet va backend manzilini tekshiring.";
    appendMessage("assistant", msg, "Ulanish xatosi"); speakText(msg);
    console.error(err);
    if (coreLabel) coreLabel.textContent = "OFFLINE";
  }
}

// ---------------------------------------------------------------------
// QURILMA VA TIZIM BUYRUQLARI (DEVICE ACTIONS)
// ---------------------------------------------------------------------
function checkDeviceCommands(cmd) {
  const t = cmd.toLowerCase();

  // Google Maps: navigatsiya yoki manzil qidirish
  if (t.includes("google maps") || t.includes("xaritani och") || t.includes("xarita") || t.includes("navigatsiya")) {
    const query = cmd.replace(/hey jarvis/ig, "").replace(/google maps|xaritani och|xarita|navigatsiya/ig, "").trim();
    const url = query
      ? "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(query)
      : "https://www.google.com/maps";
    window.open(url, "_blank", "noopener");
    const rep = query ? query + " bo'yicha Google Maps ochilmoqda, Sir." : "Google Maps ochilmoqda, Sir.";
    appendMessage("assistant", rep, "Google Maps"); speakText(rep); return true;
  }

  // Telegram: xabar matnini tayyorlaydi; yuborish Telegram ichida foydalanuvchi tomonidan tasdiqlanadi.
  if (t.includes("telegramni och") || t.includes("telegram och")) {
    const commandBody = cmd.match(/telegram(?:ni)?\s+och[,:]?\s+(.+?)\s+(?:deb\s+)?(?:yoz|yozib|xabar|jonat|jo'nat|yubor)/i);
    let text = "";
    if (commandBody) {
      const bodyWords = commandBody[1].trim().split(/\s+/);
      // Birinchi so'z odatda qabul qiluvchi (masalan, Alisherga); qolgan qismi xabar matni.
      text = bodyWords.length > 1 ? bodyWords.slice(1).join(" ") : "";
    }
    if (!text) {
      const msgMatch = cmd.match(/(?:qalaysan|qaleysan|salom|assalomu alaykum|yaxshimisan)[^.!?]*/i);
      text = msgMatch ? msgMatch[0].trim() : "";
    }
    const shareUrl = "https://t.me/share/url?url=&text=" + encodeURIComponent(text || "Salom!");
    window.open(shareUrl, "_blank", "noopener");
    const rep = text
      ? "Telegram uchun xabar tayyorlandi. Qabul qiluvchini tanlab, Telegram ichida yuborishni tasdiqlang, Sir."
      : "Telegram ochilmoqda, Sir.";
    appendMessage("assistant", rep, "Telegram"); speakText(rep); return true;
  }

  // Kamera
  if (t.includes("kamera") || t.includes("rasmga ol") || t.includes("foto")) {
    openCameraModal();
    const rep = "Kamerani ochdim, Sir. Rasmga olishingiz mumkin.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  // Chiroq (Torch)
  if (t.includes("chiroqni yoq") || t.includes("fonarni yoq") || t.includes("chiroq yoq")) {
    toggleTorch(true);
    const rep = "Chiroq yoqildi, Sir.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }
  if (t.includes("chiroqni o'chir") || t.includes("chiroqni ochir") || t.includes("fonarni o'chir")) {
    toggleTorch(false);
    const rep = "Chiroq o'chirildi, Sir.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  // Sozlamalar
  if (t.includes("sozlama") || t.includes("nastroyka")) {
    settingsModal.classList.remove("hidden");
    const rep = "Sozlamalar ochildi, Sir.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  // Doimiy tinglash rejimi (Hands-Free)
  if (t.includes("doimiy tinglashni to'xtat") || t.includes("doimiy rejimni o'chir") || t.includes("tinglashni to'xtat") || t.includes("doimiy to'xtat")) {
    stopContinuousListening();
    const rep = "Doimiy tinglash rejimi to'xtatildi, Sir.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }
  if (t.includes("doimiy tingla") || t.includes("doimiy rejim") || t.includes("hands free") || t.includes("uzluksiz tingla") || t.includes("uzluksiz eshit")) {
    startContinuousListening();
    const rep = "Doimiy tinglash rejimi faollashdi, Sir! Mikrofon uzluksiz ishlamoqda va har bir so'zingizni kutmoqda.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  // Ovoz Biometriyasi (Voice ID / Muhammadrizo)
  if (t.includes("begona ovoz") || t.includes("boshqa odam") || t.includes("begona odam gapir")) {
    const rep = "Uzr, Muhammadrizo emassiz!";
    appendMessage("assistant", rep, "Voice ID (Rad etildi)");
    speakText(rep);
    return true;
  }
  if (t.includes("ovozimni tani") || t.includes("ovoz biometriya") || t.includes("biometriya")) {
    const rep = "Ovoz biometriyasi faol, Sir. Faqat Muhammadrizo ovozi tasdiqlanadi, begona shaxslarga rad javobi beriladi.";
    appendMessage("assistant", rep, "Voice ID");
    speakText(rep);
    return true;
  }

  // Tizim holati
  if (t.includes("tizim holati") || t.includes("holat qanday")) {
    const rep = "Barcha tizimlar 100% normal holatda, Sir. Dasturchi Мухаммадризо buyruqlariga to'liq tayyorman.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  return false;
}

// ---------------------------------------------------------------------
// CHIROQNI (TORCH) BOSHQARISH
// ---------------------------------------------------------------------
async function toggleTorch(targetState) {
  isTorchOn = (targetState !== undefined) ? targetState : !isTorchOn;

  if (isTorchOn) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      const track = stream.getVideoTracks()[0];
      const capabilities = track.getCapabilities ? track.getCapabilities() : {};

      if (capabilities.torch) {
        await track.applyConstraints({ advanced: [{ torch: true }] });
        torchTrack = track;
      } else {
        // Apparatda torch yo'q bo'lsa, ekran chirog'i
        screenTorchOverlay.classList.add("active");
      }
    } catch (e) {
      screenTorchOverlay.classList.add("active");
    }
  } else {
    if (torchTrack) {
      try {
        await torchTrack.applyConstraints({ advanced: [{ torch: false }] });
        torchTrack.stop();
      } catch (e) {}
      torchTrack = null;
    }
    screenTorchOverlay.classList.remove("active");
  }
}

screenTorchOverlay.addEventListener("click", () => toggleTorch(false));

// ---------------------------------------------------------------------
// KAMERA FUNKSIYALARI
// ---------------------------------------------------------------------
async function openCameraModal() {
  cameraModal.classList.remove("hidden");
  capturedPhotoPreview.classList.add("hidden");
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "environment" },
      audio: false
    });
    cameraVideo.srcObject = cameraStream;
  } catch (e) {
    alert("Kameraga ulanib bo'lmadi, ruxsat bering, Sir.");
    cameraModal.classList.add("hidden");
  }
}

function closeCameraModal() {
  cameraModal.classList.add("hidden");
  if (cameraStream) {
    cameraStream.getTracks().forEach(t => t.stop());
    cameraStream = null;
  }
}

btnCapturePhoto.addEventListener("click", () => {
  const canvas = document.createElement("canvas");
  canvas.width = cameraVideo.videoWidth || 640;
  canvas.height = cameraVideo.videoHeight || 480;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(cameraVideo, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL("image/jpeg", 0.9);

  capturedImage.src = dataUrl;
  btnDownloadPhoto.href = dataUrl;
  capturedPhotoPreview.classList.remove("hidden");
});

btnCloseCamera.addEventListener("click", closeCameraModal);

// ---------------------------------------------------------------------
// OVOZLI YORDAMCHI VA DOIMIY TINGLASH (SPEECH-TO-TEXT & HANDS-FREE)
// ---------------------------------------------------------------------
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let isRecording = false;
let isContinuousModeActive = false;

function initRecognition(continuous = false) {
  if (!SpeechRecognition) return null;
  const rec = new SpeechRecognition();
  rec.lang = "uz-UZ";
  rec.continuous = continuous;
  rec.interimResults = continuous;

  rec.onstart = () => {
    isRecording = true;
    btnVoiceRecord.classList.add("recording");
    if (reactorCore) reactorCore.classList.add("listening");
    if (coreLabel) coreLabel.textContent = isContinuousModeActive ? "HANDS-FREE" : "LISTENING";
  };

  rec.onresult = (event) => {
    let transcript = "";
    let isFinal = false;
    for (let i = event.resultIndex; i < event.results.length; ++i) {
      transcript += event.results[i][0].transcript;
      if (event.results[i].isFinal) isFinal = true;
    }
    if (transcript.trim()) {
      textInput.value = transcript.trim();
      if (isFinal) {
        const heard = transcript.trim();
        if (isContinuousModeActive) {
          const wake = heard.match(/hey\s*jarvis[,:]?\s*(.*)/i);
          if (wake) {
            const command = (wake[1] || "").trim();
            if (command) sendToJarvis(command);
            else speakText("Xizmatingizdaman, Sir.");
          }
        } else {
          sendToJarvis(heard);
        }
      }
    }
  };

  rec.onerror = (e) => {
    console.warn("Speech error:", e.error);
    isRecording = false;
  };

  rec.onend = () => {
    isRecording = false;
    btnVoiceRecord.classList.remove("recording");
    if (reactorCore) reactorCore.classList.remove("listening");
    
    // Agar doimiy tinglash faol bo'lsa va Jarvis gapirmayotgan bo'lsa, uzluksiz qayta yoqish
    if (isContinuousModeActive && !isSpeakingNow) {
      setTimeout(startContinuousRecognition, 300);
    } else {
      if (coreLabel) coreLabel.textContent = "ONLINE";
    }
  };

  return rec;
}

function startContinuousRecognition() {
  if (!isContinuousModeActive || isSpeakingNow) return;
  try {
    if (recognition) {
      try { recognition.abort(); } catch(e) {}
    }
    recognition = initRecognition(true);
    if (recognition) recognition.start();
  } catch(e) {
    if (isContinuousModeActive && !isSpeakingNow) {
      setTimeout(startContinuousRecognition, 800);
    }
  }
}

function startContinuousListening() {
  isContinuousModeActive = true;
  startContinuousRecognition();
}

function stopContinuousListening() {
  isContinuousModeActive = false;
  if (recognition) {
    try { recognition.abort(); } catch(e) {}
  }
  isRecording = false;
  btnVoiceRecord.classList.remove("recording");
  if (reactorCore) reactorCore.classList.remove("listening");
  if (coreLabel) coreLabel.textContent = "ONLINE";
}

if (SpeechRecognition) {
  recognition = initRecognition(false);
}

function stopRecording() {
  if (isContinuousModeActive) {
    stopContinuousListening();
    return;
  }
  isRecording = false;
  if (recognition) {
    try { recognition.stop(); } catch(e) {}
  }
  btnVoiceRecord.classList.remove("recording");
  if (reactorCore) reactorCore.classList.remove("listening");
  if (coreLabel) coreLabel.textContent = "ONLINE";
}

btnVoiceRecord.addEventListener("click", () => {
  if (!recognition && !SpeechRecognition) {
    alert("Ushbu brauzerda ovozli kiritish qo'llab-quvvatlanmaydi, Sir.");
    return;
  }
  if (isContinuousModeActive) {
    stopContinuousListening();
    return;
  }
  if (isRecording) {
    stopRecording();
  } else {
    try {
      recognition = initRecognition(false);
      recognition.start();
    } catch (e) {
      stopRecording();
    }
  }
});

// Ovoz sozlamalari
let voiceSpeed = 1.0;
let voiceVolume = 1.0;
let isPermissionsGranted = false;

// DOM elementlari (Ruxsatlar va Ovoz)
const permissionGateOverlay = document.getElementById("permissionGateOverlay");
const permStatusMic = document.getElementById("permStatusMic");
const permStatusCam = document.getElementById("permStatusCam");
const btnGrantPermissions = document.getElementById("btnGrantPermissions");

const voiceSpeedRange = document.getElementById("voiceSpeedRange");
const voiceVolumeRange = document.getElementById("voiceVolumeRange");
const labelVoiceSpeed = document.getElementById("labelVoiceSpeed");
const labelVoiceVolume = document.getElementById("labelVoiceVolume");
const btnTestVoice = document.getElementById("btnTestVoice");

// ---------------------------------------------------------------------
// RASMIY ANDROID/WEB RUXSATLARINI SO'RASH (PERMISSION GATE)
// ---------------------------------------------------------------------
async function requestPermissions() {
  let micOk = false;
  let camOk = false;

  try {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      // Mikrofon ruxsati
      try {
        const aStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        micOk = true;
        if (permStatusMic) {
          permStatusMic.textContent = "BERILDI";
          permStatusMic.className = "status-granted";
        }
        aStream.getTracks().forEach(t => t.stop());
      } catch (e) {
        console.warn("Mikrofon ruxsati berilmadi:", e);
      }

      // Kamera ruxsati
      try {
        const vStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        camOk = true;
        if (permStatusCam) {
          permStatusCam.textContent = "BERILDI";
          permStatusCam.className = "status-granted";
        }
        vStream.getTracks().forEach(t => t.stop());
      } catch (e) {
        console.warn("Kamera ruxsati berilmadi:", e);
      }
    }

    if (micOk || camOk) {
      isPermissionsGranted = true;
      if (permissionGateOverlay) permissionGateOverlay.classList.add("hidden");
      if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
      speakText("Barcha tizim ruxsatlari faollashtirildi, Sir! Jarvis to'liq xizmatingizda.");
    } else {
      alert("Mikrofon va kamera ruxsatlari olinmadi, Sir. Iltimos ruxsat bering!");
    }
  } catch (err) {
    console.error("Ruxsat so'rash xatosi:", err);
  }
}

// Ilova ochilganda avtomatik ruxsat so'rash
window.addEventListener("DOMContentLoaded", () => {
  requestPermissions();
});

if (btnGrantPermissions) {
  btnGrantPermissions.addEventListener("click", requestPermissions);
}

// Ovoz sozlamalari tinglovchilari
if (voiceSpeedRange) {
  voiceSpeedRange.addEventListener("input", (e) => {
    voiceSpeed = parseFloat(e.target.value);
    if (labelVoiceSpeed) labelVoiceSpeed.textContent = voiceSpeed.toFixed(1) + "x";
  });
}

if (voiceVolumeRange) {
  voiceVolumeRange.addEventListener("input", (e) => {
    voiceVolume = parseFloat(e.target.value);
    if (labelVoiceVolume) labelVoiceVolume.textContent = Math.round(voiceVolume * 100) + "%";
  });
}

if (btnTestVoice) {
  btnTestVoice.addEventListener("click", () => {
    speakText("Assalomu alaykum, Sir! Ushbu ovoz tezligi va balandligi sizga ma'qulmi?");
  });
}

// ---------------------------------------------------------------------
// TUGMALAR VA HODISALAR
// ---------------------------------------------------------------------
btnSendText.addEventListener("click", () => {
  if (!isPermissionsGranted) {
    requestPermissions();
    return;
  }
  sendToJarvis(textInput.value);
});

textInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    if (!isPermissionsGranted) {
      requestPermissions();
      return;
    }
    sendToJarvis(textInput.value);
  }
});

btnActionCamera.addEventListener("click", () => {
  if (!isPermissionsGranted) { requestPermissions(); return; }
  checkDeviceCommands("kamerani och");
});

btnActionTorch.addEventListener("click", () => {
  if (!isPermissionsGranted) { requestPermissions(); return; }
  toggleTorch();
});

btnActionSettings.addEventListener("click", () => settingsModal.classList.remove("hidden"));
btnActionStatus.addEventListener("click", () => checkDeviceCommands("tizim holati"));

btnCloseSettings.addEventListener("click", () => settingsModal.classList.add("hidden"));
ttsToggle.addEventListener("change", (e) => { isTTSActive = e.target.checked; });
