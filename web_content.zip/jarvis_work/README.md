# JARVIS — Samsung Galaxy A26 5G uchun shaxsiy yordamchi

Bu arxiv siz yuborgan JARVIS loyihasining mavjud HTML/CSS/JavaScript interfeysi ustiga tayyorlandi. Asosiy dizayn, chat, TTS, kamera, fonar, ovoz sozlamalari va mavjud UI saqlangan. Groq kalitlari frontend va backend kodidan olib tashlandi: ular avval ochiq turgani sababli **bekor qilinishi kerak**.

## Arxiv tarkibi

- `frontend_apk/` — HTML-to-APK ilovasiga beriladigan tayyor frontend papkasi.
- `server.py`, `requirements.txt`, `Procfile` — Gemini AI uchun xavfsiz backend.
- `backend_render/` — Render'ga joylash uchun backend nusxasi.
- `AndroidManifest.xml` — Android Studio loyihasi uchun ruxsatlar namunasi; HTML-to-APK dasturi bu faylni e'tiborsiz qoldirishi mumkin.

## 1. Avval Gemini backendni ishga tushiring

1. `server.py`, `requirements.txt`, `Procfile` fayllarini GitHub repozitoriyga yuklang.
2. Render'da **New → Web Service** yarating va shu repozitoriyni ulang.
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn server:app --host 0.0.0.0 --port $PORT`
5. Render → Environment bo'limida `GEMINI_API_KEY` nomli secret environment variable yarating. Qiymatiga Google AI Studio'dan olingan yangi Gemini API kalitini kiriting.
6. Ixtiyoriy `GEMINI_MODEL` qiymati: `gemini-2.5-flash`.
7. Deploy tugagach, `https://SIZNING-SERVER.onrender.com/health` manzilini tekshiring. `{"status":"healthy"}` qaytishi kerak.

**API kalitni hech qachon `config.js`, `script.js` yoki APK ichiga yozmang.** Gemini kaliti faqat serverda tursin.

## 2. Frontendni backendga ulang

`frontend_apk/config.js` faylini oching va quyidagi qatorni Render bergan HTTPS manzilga almashtiring:

```js
API_BASE_URL: "https://SIZNING-SERVER.onrender.com",
```

Masalan, oxirida `/` qo'shmang. So'ng `frontend_apk/` papkasini HTML-to-APK ilovasiga import qiling. Start/Home file sifatida `index.html` ni tanlang. Internet, JavaScript, mikrofon va kamera ruxsatlarini yoqing.

## 3. Mavjud imkoniyatlar

- JARVIS interfeysi, chat va suhbat tarixi (joriy sessiya ichida)
- Gemini bilan backend orqali chat
- Ovozli kiritish (Web Speech API mavjud bo'lsa)
- Ovozli javob (Speech Synthesis mavjud bo'lsa)
- Kamera va suratga olish
- Fonarni yoqish/o'chirish (brauzer/WebView qurilma imkon bersa)
- Google Maps'ni ochish va so'rov bo'yicha xaritada qidirish
- Telegram share oynasida tayyor matnni ulashish

## 4. Muhim Android cheklovlari

Bu ZIP **HTML-to-APK WebView ilovasi** uchun. U yolg'iz o'zi quyidagilarni kafolatlay olmaydi:

- Ekran o'chiq paytda doimiy "Hey Jarvis" wake-word tinglash.
- Android ekranini yashirin yoki uzluksiz ko'rish. Ekran ko'rish uchun native Android `MediaProjection` va har safar foydalanuvchi roziligi kerak.
- Boshqa ilovalarni to'liq boshqarish. Buning uchun native Kotlin `AccessibilityService` va foydalanuvchi tomonidan maxsus ruxsat kerak.
- Telegram kontaktini avtomatik aniqlash yoki xabarni foydalanuvchi tasdig'isiz yuborish. Hozir Telegram share oynasiga tayyor matn uzatiladi; kontaktni tanlash va yuborish Telegram ichida amalga oshiriladi.
- Wi-Fi/Bluetooth kabi himoyalangan tizim sozlamalarini oddiy web sahifadan bevosita almashtirish.

Shu sababli bu APK hozirgi HTML funksiyalarini ishga tushiradi. Haqiqiy fon wake-word, ekran ko'rish va Android bo'ylab boshqaruv uchun keyingi bosqichda Kotlin native Android qobig'i kerak bo'ladi. HTML-to-APK builder bu imkoniyatlarni avtomatik qo'shib bermaydi.

## 5. Groq kalitlari xavfsizligi

Siz yuborgan ZIP ichida Groq API kalitlari ochiq ko'ringan. Ularni Groq boshqaruv panelida darhol revoke/delete qiling. Ushbu yangilangan arxivda o'sha kalitlar yo'q.
