/* JARVIS client configuration. Set this to your deployed HTTPS backend URL. */
window.JARVIS_CONFIG = {
  API_BASE_URL: "https://YOUR-JARVIS-BACKEND.onrender.com",
  APP_NAME: "JARVIS"
};
