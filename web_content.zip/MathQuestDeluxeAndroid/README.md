# Math Quest Deluxe — Android

Jogo HTML5 em português com mapa de 20 fases, progressão desbloqueável, guardiões, vidas, combo, pontuação, moedas, estrelas, conquistas, modo treino e progresso salvo localmente.

## Jogar no celular
Abra `app/src/main/assets/index.html` em um navegador Android moderno.

## Gerar APK no AndroidIDE
1. Extraia o ZIP.
2. Abra a pasta `MathQuestDeluxeAndroid` no AndroidIDE.
3. Conclua a configuração inicial do Gradle/Android SDK.
4. Execute `assembleDebug` ou use a opção de compilar APK.
5. O APK costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

Este ZIP contém o código-fonte e não um APK já compilado.
