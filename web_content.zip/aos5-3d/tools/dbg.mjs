// usage: node tools/dbg.mjs <levelId> <maxSec> "<js expression using window.__game>"
import { createRequire } from 'module';
const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const [id, max, expr] = process.argv.slice(2);
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox', '--enable-webgl'] });
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
page.on('pageerror', e => console.log('PAGEERROR', e.message));
await page.goto('file://' + process.cwd() + '/dist/index.html?q=low'); await page.waitForTimeout(1200);
const rep = await page.evaluate(async ([id, max]) => { const r = await window.__bot.runLevel(+id, +max); window.__bot.log.length = 0; return r; }, [id, max]);
console.log(JSON.stringify(rep));
console.log(JSON.stringify(await page.evaluate(expr)));
await browser.close();
