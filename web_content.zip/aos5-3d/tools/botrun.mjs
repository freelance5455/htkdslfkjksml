// usage: node tools/botrun.mjs <html> <levelId[,id...]> [maxSec] [--shot=prefix]
import { createRequire } from 'module';
const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const [file, ids, max] = process.argv.slice(2);
const shot = (process.argv.find(a => a.startsWith('--shot=')) || '').split('=')[1];
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox', '--enable-webgl'] });
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
const logs = [];
page.on('console', m => { const t = m.text(); if ((m.type() === 'error' || t.startsWith('[game]')) && !t.includes('AudioContext')) logs.push(m.type() + ': ' + t); });
page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 5).join('\n')));
await page.goto('file://' + process.cwd() + '/' + file + '?q=low');
await page.waitForTimeout(1500);
for (const id of ids.split(',')) {
  const t0 = Date.now();
  const rep = await page.evaluate(async ([id, max]) => { const r = await window.__bot.runLevel(+id, +max); r.log = window.__bot.log.splice(0); return r; }, [id, max || 600]);
  const lg = rep.log; delete rep.log;
  console.log(JSON.stringify(rep), 'wall', Math.round((Date.now() - t0) / 1000) + 's');
  if (rep.result !== 'complete' && lg) console.log(lg.slice(-3).join('\n'));
  if (shot) { await page.evaluate(() => { window.__game.step(0.1); }); await page.waitForTimeout(200); await page.screenshot({ path: shot + '_' + id + '.png' }); }
}
console.log(logs.slice(0, 12).join('\n') || 'no console errors');
await browser.close();
