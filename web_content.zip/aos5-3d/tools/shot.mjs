// usage: node tools/shot.mjs <html> <out.png> [--step=seconds] [--w=1280 --h=720] [--q=query] [--eval="js"]
import { createRequire } from 'module';
const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const args = Object.fromEntries(process.argv.slice(4).map(a => { const [k, ...v] = a.replace(/^--/, '').split('='); return [k, v.join('=') || true]; }));
const [file, out] = process.argv.slice(2, 4);
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox', '--enable-webgl'] });
const page = await browser.newPage({ viewport: { width: +(args.w || 1280), height: +(args.h || 720) } });
const logs = [];
page.on('console', m => { const t = m.text(); if (m.type() === 'error' || m.type() === 'warning' || t.startsWith('[game]')) logs.push(m.type() + ': ' + t); });
page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 4).join('\n')));
await page.goto('file://' + process.cwd() + '/' + file + (args.q ? '?' + args.q : ''));
await page.waitForTimeout(+(args.wait || 1500));
if (args.eval) { const r = await page.evaluate(args.eval); if (r !== undefined) console.log('eval:', JSON.stringify(r)); }
if (args.step) { await page.evaluate(`window.__step(${+args.step})`); await page.waitForTimeout(300); }
await page.screenshot({ path: out });
console.log(logs.slice(0, 15).join('\n') || 'no console errors');
await browser.close();
