// usage: node tools/audit.mjs <html> <ids comma>  — lists unreachable ground objects per level
import { createRequire } from 'module';
const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const [file, ids] = process.argv.slice(2);
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
page.on('pageerror', e => console.log('PAGEERROR', e.message));
await page.goto('file://' + process.cwd() + '/' + file + '?q=low'); await page.waitForTimeout(1200);
for (const id of ids.split(',')) { const r = await page.evaluate(([i, m]) => window.__bot.audit(+i, m ? { map: m.split(',').map(Number) } : {}), [id, process.env.MAP || '']); const mp = r.map; delete r.map; console.log(JSON.stringify(r)); if (mp) console.log(mp); }
await browser.close();
