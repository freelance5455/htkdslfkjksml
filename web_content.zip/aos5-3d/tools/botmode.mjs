// usage: node tools/botmode.mjs <html> <zombie|defense|jump> [variant] [maxSec]
import { createRequire } from 'module';
const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const [file, key, v, max, seed] = process.argv.slice(2);
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
page.on('pageerror', e => console.log('PAGEERROR', e.message));
page.on('console', m => { if (m.type() === 'error') console.log('ERR', m.text()); });
await page.goto('file://' + process.cwd() + '/' + file + '?q=low'); await page.waitForTimeout(1200);
const r = await page.evaluate(async ([key, v, max, seed]) => { const R0 = window.__game.Run, of = R0.onFall; window.__falls = []; R0.onFall = function () { const P = window.__game.G.p; window.__falls.push([P.x.toFixed(1), P.y.toFixed(1), P.z.toFixed(1), (this.W.tower ? this.W.tower.platforms.findIndex(p => P.x >= p.x0 - 3 && P.x <= p.x1 + 3) : -1)].join(',')); return of.call(this); }; const r = await window.__bot.runLevel('m_' + key, +max || 300, { mode: { key, v, seed: +seed || 0 }, logEvery: 600 }); const res = window.__game.G.run.results; return { r, res, log: window.__bot.log.slice(-3), falls: window.__falls.slice(0, 30), plats: window.__game.G.W.tower && window.__game.G.W.tower.platforms.map(p => [p.kind[0], p.x0.toFixed(0), p.x1.toFixed(0), p.z0.toFixed(0), p.z1.toFixed(0), p.y.toFixed(1)].join(',')) }; }, [key, v || 'easy', max, seed]);
console.log(JSON.stringify(r.r)); console.log(JSON.stringify(r.res)); console.log(r.log.join('\n')); console.log(JSON.stringify(r.falls)); console.log((r.plats||[]).join(' | '));
await browser.close();
