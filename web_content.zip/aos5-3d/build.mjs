// Build script: bundles src/ into dist/game.js and a standalone dist/index.html (no network needed)
import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';
const require = createRequire('/opt/npm-tools/node_modules/');
const esbuild = require('esbuild');
const args = process.argv.slice(2);
const prod = !args.includes('--dev');
const entry = (args.find(a => a.startsWith('--entry=')) || '--entry=src/main.js').split('=')[1];
const outName = (args.find(a => a.startsWith('--out=')) || '--out=index').split('=')[1];
const r = await esbuild.build({
  entryPoints: [entry], bundle: true, format: 'iife', minify: prod, sourcemap: false,
  outfile: `dist/${outName}.js`, target: 'es2019', legalComments: 'none',
  nodePaths: [path.resolve('vendor/node_modules')],
  logLevel: 'warning', write: false,
});
const js = r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = fs.readFileSync('src/style.css', 'utf8');
const html = `<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#0b0d12">
<title>Anger of Stick 5 — Unofficial 3D Fan Adaptation</title>
<style>${css}</style></head>
<body><div id="app"></div><canvas id="gl"></canvas><div id="ui"></div><div id="touch"></div>
<script>${js}</script></body></html>`;
fs.writeFileSync(`dist/${outName}.html`, html);
console.log(`built dist/${outName}.html  (${(html.length / 1024).toFixed(0)} KB)`);
