// Procedural textures + materials (all original, generated at runtime — no external assets)
import * as THREE from 'three';
import { RNG } from './util.js';
import { G } from './ctx.js';

// World size (metres) covered by one texture repeat
export const TILE_SIZE = {
  asphalt: 8, paving: 6, concrete: 6, brick: 4, facade: 8, metal: 4, corrugated: 4, tiles: 4, labwall: 4,
  wood: 4, grass: 6, carpet: 4, hazard: 2, dirt: 6, tunnel: 6, roof: 6, plaster: 4,
};

const texCache = {};
const matCache = {};

function mkCanvas(size) { const c = document.createElement('canvas'); c.width = c.height = size; return c; }
function toTex(c, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = G.quality === 'low' ? 1 : 4;
  return t;
}
function speckle(g, S, rng, n, colA, colB, maxR = 1.6, alpha = 0.5) {
  for (let i = 0; i < n; i++) {
    g.globalAlpha = rng.range(0.1, alpha);
    g.fillStyle = rng.chance(0.5) ? colA : colB;
    const r = rng.range(0.4, maxR);
    g.fillRect(rng.range(0, S), rng.range(0, S), r, r);
  }
  g.globalAlpha = 1;
}

const DRAW = {
  asphalt(g, S, rng) {
    g.fillStyle = '#4b4e57'; g.fillRect(0, 0, S, S);
    speckle(g, S, rng, S * S / 10, '#2a2c32', '#7c7f88', 1.8, 0.55);
    g.strokeStyle = 'rgba(20,20,24,.55)'; g.lineWidth = S / 160;
    for (let i = 0; i < 3; i++) { g.beginPath(); let x = rng.range(0, S), y = rng.range(0, S); g.moveTo(x, y); for (let k = 0; k < 6; k++) { x += rng.range(-S / 8, S / 8); y += rng.range(-S / 8, S / 8); g.lineTo(x, y); } g.stroke(); }
  },
  paving(g, S, rng) {
    g.fillStyle = '#9a9ca3'; g.fillRect(0, 0, S, S);
    const n = 2, c = S / n;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { g.fillStyle = `hsl(220,5%,${rng.range(55, 66)}%)`; g.fillRect(i * c + 2, j * c + 2, c - 4, c - 4); }
    speckle(g, S, rng, S * S / 14, '#555', '#ccc', 1.5, 0.35);
  },
  concrete(g, S, rng) {
    g.fillStyle = '#8f9197'; g.fillRect(0, 0, S, S);
    speckle(g, S, rng, S * S / 6, '#5a5c62', '#b8bac0', 1.8, 0.4);
    for (let i = 0; i < 5; i++) { g.fillStyle = `rgba(40,40,50,${rng.range(0.03, 0.08)})`; g.fillRect(rng.range(0, S), 0, rng.range(4, 16), S); }
  },
  plaster(g, S, rng) {
    g.fillStyle = '#d8cfc0'; g.fillRect(0, 0, S, S);
    speckle(g, S, rng, S * S / 8, '#a89f90', '#f3ecdf', 1.6, 0.35);
    g.fillStyle = 'rgba(80,70,60,.18)'; g.fillRect(0, S * 0.92, S, S * 0.08);
  },
  brick(g, S, rng) {
    g.fillStyle = '#6f655d'; g.fillRect(0, 0, S, S);
    const rows = 8, cols = 4, bh = S / rows, bw = S / cols;
    for (let r = 0; r < rows; r++) for (let c = -1; c < cols; c++) {
      const off = (r % 2) * bw / 2;
      g.fillStyle = `hsl(${rng.range(8, 20)},${rng.range(38, 52)}%,${rng.range(34, 46)}%)`;
      g.fillRect(c * bw + off + 1.5, r * bh + 1.5, bw - 3, bh - 3);
    }
    speckle(g, S, rng, S * S / 12, '#2a1a14', '#d8b8a0', 1.5, 0.25);
  },
  facade(g, S, rng, lit) {
    // 4x4 windows per tile; `lit` pass only draws lit windows (emissive map)
    g.fillStyle = lit ? '#000' : '#b9b3a8'; g.fillRect(0, 0, S, S);
    const n = 4, c = S / n;
    if (!lit) { speckle(g, S, rng, S * S / 14, '#8a8478', '#d6d0c4', 1.6, 0.3); }
    const seed = rng.s;
    const r2 = new RNG(seed ^ 0x9e37);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      const x = i * c + c * 0.2, y = j * c + c * 0.16, w = c * 0.6, h = c * 0.62;
      const on = r2.chance(0.35);
      if (lit) {
        if (on) { g.fillStyle = r2.chance(0.8) ? '#ffcf70' : '#9fe0ff'; g.fillRect(x, y, w, h); }
      } else {
        g.fillStyle = '#2a3240'; g.fillRect(x - 3, y - 3, w + 6, h + 6);
        const gr = g.createLinearGradient(x, y, x, y + h); gr.addColorStop(0, '#5b7088'); gr.addColorStop(1, '#1d2531');
        g.fillStyle = gr; g.fillRect(x, y, w, h);
        g.fillStyle = '#2a3240'; g.fillRect(x + w / 2 - 1.5, y, 3, h);
        g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(x - 3, y + h + 3, w + 6, 4);
      }
    }
  },
  metal(g, S, rng) {
    const gr = g.createLinearGradient(0, 0, S, S); gr.addColorStop(0, '#838a93'); gr.addColorStop(1, '#6c737c');
    g.fillStyle = gr; g.fillRect(0, 0, S, S);
    g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = 2;
    g.strokeRect(2, 2, S / 2 - 4, S - 4); g.strokeRect(S / 2 + 2, 2, S / 2 - 4, S - 4);
    g.fillStyle = 'rgba(30,30,30,.6)';
    for (const [x, y] of [[8, 8], [S / 2 - 8, 8], [8, S - 8], [S / 2 - 8, S - 8], [S / 2 + 8, 8], [S - 8, 8], [S / 2 + 8, S - 8], [S - 8, S - 8]]) { g.beginPath(); g.arc(x, y, 2.2, 0, 6.3); g.fill(); }
    speckle(g, S, rng, S * S / 12, '#4a3020', '#c0c6cc', 1.8, 0.3);
    g.fillStyle = 'rgba(140,70,30,.18)'; for (let i = 0; i < 6; i++) g.fillRect(rng.range(0, S), rng.range(0, S), rng.range(6, 30), rng.range(6, 24));
  },
  corrugated(g, S, rng) {
    const n = 16, w = S / n;
    for (let i = 0; i < n; i++) { const gr = g.createLinearGradient(i * w, 0, (i + 1) * w, 0); gr.addColorStop(0, '#d4d4d4'); gr.addColorStop(0.5, '#ffffff'); gr.addColorStop(1, '#a9a9a9'); g.fillStyle = gr; g.fillRect(i * w, 0, w, S); }
    speckle(g, S, rng, S * S / 14, '#555', '#fff', 1.6, 0.25);
    g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(0, 0, S, 3); g.fillRect(0, S - 3, S, 3);
  },
  tiles(g, S, rng) {
    g.fillStyle = '#aeb6bf'; g.fillRect(0, 0, S, S);
    const n = 4, c = S / n;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { g.fillStyle = `hsl(210,12%,${rng.range(80, 88)}%)`; g.fillRect(i * c + 1.5, j * c + 1.5, c - 3, c - 3); }
    speckle(g, S, rng, S * S / 20, '#888', '#fff', 1.4, 0.25);
  },
  labwall(g, S, rng) {
    g.fillStyle = '#e4e9ee'; g.fillRect(0, 0, S, S);
    g.strokeStyle = 'rgba(80,100,120,.35)'; g.lineWidth = 2; g.strokeRect(2, 2, S - 4, S - 4); g.beginPath(); g.moveTo(S / 2, 0); g.lineTo(S / 2, S); g.stroke();
    g.fillStyle = '#2f8fd0'; g.fillRect(0, S * 0.46, S, S * 0.08);
    g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(0, S * 0.9, S, S * 0.1);
    speckle(g, S, rng, S * S / 30, '#99a', '#fff', 1.2, 0.2);
  },
  wood(g, S, rng) {
    const n = 6, h = S / n;
    for (let i = 0; i < n; i++) { g.fillStyle = `hsl(${rng.range(24, 32)},${rng.range(40, 52)}%,${rng.range(28, 40)}%)`; g.fillRect(0, i * h, S, h - 2); g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(0, i * h + h - 2, S, 2); }
    g.strokeStyle = 'rgba(40,20,10,.25)'; g.lineWidth = 1;
    for (let i = 0; i < 40; i++) { const y = rng.range(0, S); g.beginPath(); g.moveTo(0, y); g.lineTo(S, y + rng.range(-3, 3)); g.stroke(); }
  },
  grass(g, S, rng) {
    g.fillStyle = '#4c7a3a'; g.fillRect(0, 0, S, S);
    speckle(g, S, rng, S * S / 4, '#2f5a26', '#8fbf62', 2, 0.55);
  },
  carpet(g, S, rng) {
    g.fillStyle = '#6a4a58'; g.fillRect(0, 0, S, S);
    speckle(g, S, rng, S * S / 3, '#4a3340', '#8a6676', 1.6, 0.5);
    g.strokeStyle = 'rgba(255,255,255,.07)'; g.lineWidth = 3; g.strokeRect(S * .1, S * .1, S * .8, S * .8);
  },
  hazard(g, S) {
    g.fillStyle = '#f2c230'; g.fillRect(0, 0, S, S);
    g.fillStyle = '#16161a';
    for (let i = -2; i < 6; i++) { g.beginPath(); g.moveTo(i * S / 3, 0); g.lineTo(i * S / 3 + S / 6, 0); g.lineTo(i * S / 3 + S / 6 + S, S); g.lineTo(i * S / 3 + S, S); g.fill(); }
  },
  dirt(g, S, rng) {
    g.fillStyle = '#6b5a45'; g.fillRect(0, 0, S, S);
    speckle(g, S, rng, S * S / 3, '#3d3224', '#a38f70', 2, 0.55);
  },
  tunnel(g, S, rng) {
    g.fillStyle = '#6f7b84'; g.fillRect(0, 0, S, S);
    const n = 4, c = S / n;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { g.fillStyle = `hsl(200,8%,${rng.range(38, 48)}%)`; g.fillRect(i * c + 2, j * c + 2, c - 4, c - 4); }
    speckle(g, S, rng, S * S / 8, '#1c2226', '#a3b0b8', 1.8, 0.4);
    g.fillStyle = 'rgba(10,25,20,.35)'; for (let i = 0; i < 5; i++) g.fillRect(rng.range(0, S), 0, rng.range(3, 10), rng.range(S * .3, S));
  },
  roof(g, S, rng) {
    g.fillStyle = '#585b60'; g.fillRect(0, 0, S, S);
    speckle(g, S, rng, S * S / 3, '#2c2d30', '#9a9da3', 1.8, 0.6);
    g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 2; g.strokeRect(1, 1, S - 2, S - 2);
  },
};

export function getTex(name, lit = false) {
  const key = name + (lit ? ':lit' : '');
  if (texCache[key]) return texCache[key];
  const S = G.quality === 'low' ? 128 : 256;
  const c = mkCanvas(S); const g = c.getContext('2d');
  let seed = 0; for (let i = 0; i < name.length; i++) seed = (seed * 31 + name.charCodeAt(i)) >>> 0;
  const rng = new RNG(seed + 7);
  DRAW[name](g, S, rng, lit);
  const t = toTex(c, !lit ? true : true);
  texCache[key] = t;
  return t;
}

const SURF = { // roughness / metalness per surface kind
  asphalt: [0.95, 0], paving: [0.85, 0], concrete: [0.9, 0], plaster: [0.9, 0], brick: [0.9, 0], facade: [0.8, 0.05], metal: [0.45, 0.55],
  corrugated: [0.5, 0.35], tiles: [0.35, 0.05], labwall: [0.5, 0.05], wood: [0.8, 0], grass: [1, 0], carpet: [1, 0], hazard: [0.6, 0.1],
  dirt: [1, 0], tunnel: [0.85, 0.05], roof: [0.95, 0],
};

/** Cached environment material: M('brick', 0xffffff) */
export function M(name, color = 0xffffff, extra = null) {
  const key = name + ':' + color + ':' + (extra ? JSON.stringify(extra) : '');
  if (matCache[key]) return matCache[key];
  const [rough, metal] = SURF[name] || [0.8, 0];
  const o = { map: getTex(name), color, roughness: rough, metalness: metal };
  if (name === 'facade') { o.emissiveMap = getTex('facade', true); o.emissive = new THREE.Color(0xffffff); o.emissiveIntensity = 0.9; }
  if (extra) Object.assign(o, extra);
  const m = new THREE.MeshStandardMaterial(o);
  m.userData.tex = name;
  matCache[key] = m;
  return m;
}

export function plain(color, opts = {}) {
  const key = 'plain:' + color + ':' + JSON.stringify(opts);
  if (matCache[key]) return matCache[key];
  const m = new THREE.MeshStandardMaterial({ color, roughness: opts.rough ?? 0.8, metalness: opts.metal ?? 0, ...(opts.extra || {}) });
  matCache[key] = m; return m;
}
export function glow(color, opts = {}) {
  const key = 'glow:' + color + ':' + JSON.stringify(opts);
  if (matCache[key]) return matCache[key];
  const m = new THREE.MeshBasicMaterial({ color, ...opts });
  matCache[key] = m; return m;
}
export function glass(color = 0x9fd6ff, opacity = 0.28) {
  const key = 'glass:' + color + opacity;
  if (matCache[key]) return matCache[key];
  const m = new THREE.MeshStandardMaterial({ color, roughness: 0.1, metalness: 0.2, transparent: true, opacity, depthWrite: false });
  matCache[key] = m; return m;
}
/** ghost version (used when a wall hides the player from the camera) */
export function ghostOf(mat) {
  if (mat.userData.ghost) return mat.userData.ghost;
  const g = mat.clone(); g.transparent = true; g.opacity = 0.18; g.depthWrite = false;
  mat.userData.ghost = g; return g;
}

// ------- toon (character) materials with rim light -------
let gradTex = null;
function gradient() {
  if (gradTex) return gradTex;
  const d = new Uint8Array([120, 120, 120, 255, 175, 175, 175, 255, 225, 225, 225, 255, 255, 255, 255, 255]);
  gradTex = new THREE.DataTexture(d, 4, 1, THREE.RGBAFormat); gradTex.minFilter = gradTex.magFilter = THREE.NearestFilter; gradTex.needsUpdate = true;
  return gradTex;
}
export function toon(color, opts = {}) {
  const m = new THREE.MeshToonMaterial({ color, gradientMap: gradient() });
  if (opts.emissive) { m.emissive = new THREE.Color(opts.emissive); m.emissiveIntensity = opts.emissiveIntensity ?? 1; }
  const rim = new THREE.Color(opts.rim ?? 0x88aaff);
  m.userData.rim = rim; m.userData.base = new THREE.Color(color);
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uRim = { value: rim };
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\nuniform vec3 uRim;')
      .replace('#include <dithering_fragment>', `#include <dithering_fragment>
        float rimF = 1.0 - saturate(dot(normalize(vNormal), normalize(vViewPosition)));
        gl_FragColor.rgb += uRim * pow(rimF, 2.6) * 0.55;`);
  };
  m.customProgramCacheKey = () => 'toonrim';
  return m;
}

export function disposeTextures() { /* textures are small & cached for the whole session */ }

// ---------- decals (lane markings, arrows, stains...) ----------
const decalCache = {};
export function decalMat(name) {
  if (decalCache[name]) return decalCache[name];
  const S = 128; const c = mkCanvas(S); const g = c.getContext('2d');
  g.clearRect(0, 0, S, S);
  if (name === 'dash') { g.fillStyle = '#e8e4d0'; g.fillRect(S * 0.42, S * 0.1, S * 0.16, S * 0.5); }
  else if (name === 'line') { g.fillStyle = '#e8e4d0'; g.fillRect(S * 0.45, 0, S * 0.1, S); }
  else if (name === 'yline') { g.fillStyle = '#e8c030'; g.fillRect(S * 0.38, 0, S * 0.06, S); g.fillRect(S * 0.56, 0, S * 0.06, S); }
  else if (name === 'zebra') { g.fillStyle = '#e8e8e8'; for (let i = 0; i < 5; i++) g.fillRect(i * S / 5 + 4, 0, S / 5 - 10, S); }
  else if (name === 'arrow') { g.fillStyle = '#ffd23a'; g.beginPath(); g.moveTo(S * 0.5, S * 0.08); g.lineTo(S * 0.85, S * 0.5); g.lineTo(S * 0.62, S * 0.5); g.lineTo(S * 0.62, S * 0.92); g.lineTo(S * 0.38, S * 0.92); g.lineTo(S * 0.38, S * 0.5); g.lineTo(S * 0.15, S * 0.5); g.closePath(); g.fill(); }
  else if (name === 'stain') { const r = new RNG(5); for (let i = 0; i < 14; i++) { const x = S / 2 + r.range(-S * .25, S * .25), y = S / 2 + r.range(-S * .25, S * .25); const gr = g.createRadialGradient(x, y, 0, x, y, S * r.range(.1, .22)); gr.addColorStop(0, 'rgba(20,20,22,.55)'); gr.addColorStop(1, 'rgba(20,20,22,0)'); g.fillStyle = gr; g.fillRect(0, 0, S, S); } }
  else if (name === 'puddle') { const gr = g.createRadialGradient(S / 2, S / 2, 2, S / 2, S / 2, S / 2); gr.addColorStop(0, 'rgba(120,160,200,.55)'); gr.addColorStop(0.8, 'rgba(90,130,170,.35)'); gr.addColorStop(1, 'rgba(90,130,170,0)'); g.fillStyle = gr; g.fillRect(0, 0, S, S); }
  else if (name === 'sludge') { const gr = g.createRadialGradient(S / 2, S / 2, 2, S / 2, S / 2, S / 2); gr.addColorStop(0, 'rgba(120,200,60,.85)'); gr.addColorStop(0.85, 'rgba(70,150,40,.7)'); gr.addColorStop(1, 'rgba(70,150,40,0)'); g.fillStyle = gr; g.fillRect(0, 0, S, S); }
  else if (name === 'ring') { g.strokeStyle = '#fff'; g.lineWidth = S * 0.06; g.beginPath(); g.arc(S / 2, S / 2, S * 0.43, 0, 6.3); g.stroke(); const gr = g.createRadialGradient(S / 2, S / 2, S * .1, S / 2, S / 2, S * .46); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(255,255,255,.35)'); g.fillStyle = gr; g.beginPath(); g.arc(S / 2, S / 2, S * 0.46, 0, 6.3); g.fill(); }
  else if (name === 'blob') { const gr = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2); gr.addColorStop(0, 'rgba(0,0,0,.55)'); gr.addColorStop(0.6, 'rgba(0,0,0,.3)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, S, S); }
  else if (name === 'square') { g.fillStyle = 'rgba(255,255,255,.28)'; g.fillRect(0, 0, S, S); g.strokeStyle = '#fff'; g.lineWidth = 6; g.strokeRect(3, 3, S - 6, S - 6); }
  else if (name === 'hexgrid') { g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 3; for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { g.strokeRect(i * 32 + 2, j * 32 + 2, 28, 28); } }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping;
  const m = new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  if (name === 'stain' || name === 'blob') m.color = new THREE.Color(0x000000), m.map = t;
  decalCache[name] = m; return m;
}
