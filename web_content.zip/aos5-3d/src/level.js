// Level runner: builds the world, spawns actors, tracks objectives / locks / waves / checkpoints / pickups / breakables / boss / results.
import * as THREE from 'three';
import { G } from './ctx.js';
import { Save } from './save.js';
import { LEVEL_BY_ID, LEVELS } from './data/levels.js';
import { ENEMIES, BOSSES } from './data/enemies.js';
import { buildLevel } from './levelbuild.js';
import { breakable, ZMAX } from './templates.js';
import { Enemy } from './enemy.js';
import { Ally } from './ally.js';
import { Player } from './player.js';
import { Combat } from './combat.js';
import { Hazards } from './hazards.js';
import { Cam } from './camera.js';
import { Input } from './input.js';
import { bindFx } from './props.js';
import { RNG, clamp } from './util.js';

const coinGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.07, 12).rotateX(Math.PI / 2);
const coinMat = new THREE.MeshStandardMaterial({ color: 0xffc928, emissive: 0x8a5a00, emissiveIntensity: 0.7, metalness: 0.8, roughness: 0.3 });
const hpGeo = new THREE.SphereGeometry(0.3, 12, 8);
const hpMat = new THREE.MeshStandardMaterial({ color: 0x3aff7a, emissive: 0x15a040, emissiveIntensity: 0.9, roughness: 0.4 });
const crossMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
const keyGeo = new THREE.OctahedronGeometry(0.36);
const beaconGeo = new THREE.CylinderGeometry(0.1, 0.1, 6, 6);
const KEYCOL = { 'بطاقة دخول': 0x4ad8ff, 'مفتاح البوابة': 0xffc83a, 'خلية وقود': 0xff7a2a, 'بطاقة أمن': 0xc070ff, 'صمام': 0x6aff8a };
const rr = (a, b) => a + Math.random() * (b - a);

export const Run = {
  active: false,
  // ---------------------------------------------------------------- start
  begin(o) {
    this.end(true);
    const spec = o.spec; const W = o.world || buildLevel(spec);
    G.W = W; this.W = W; bindFx(G.fx);
    const stage = G.stage; stage.setWorld(W, spec.theme); stage.scene.add(W.group);
    if (W.void) { let my = 1e9; for (const r of W.route) my = Math.min(my, r.y); W.killY = Math.min(-14, my - 14); }
    else W.killY = -14;
    const R = this; R.spec = spec; R.id = spec.id; R.diff = spec.diff || 1; R.mode = o.mode || null; R.time = 0; R.state = 'intro'; R.stateT = 0; R.frozenInput = true;
    R.stats = { kills: 0, taken: 0, hits: 0, deaths: 0, levelUps: 0, coins: 0, xp: 0 }; R.coins = 0; R.xp = 0; R.keys = {}; R.switchesOn = 0; R.nests = 0; R.rescued = new Set(); R.bossDefeated = false; R.boss = null; R.bossStarted = false;
    R.protectObj = null; R.protectActive = false; R.protectLeft = 0; R.protectDone = false; R.phaseSpeed = 1; R.hazardSlow = 1;
    R.pickups = []; R.cps = W.checkpoints; R.checkpoint = { x: W.start.x, y: W.start.y, z: W.start.z }; R.nestList = [];
    R.totalSwitches = spec.segs.reduce((a, s) => a + (s.switches || 0), 0); R.totalKeys = spec.segs.reduce((a, s) => a + (s.keys ? s.keys.n : 0), 0);
    R.objectives = (spec.objectives || []).map(ob => ({ ...ob, done: false, cur: 0 })); R.allDone = R.objectives.length === 0; R.exitOpen = false; R.deadT = 0; R.par = 70 + W.endX * 0.9;
    R.completeT = 0; R.results = null; R.shownCP = 0; R.noExit = !!o.noExit; R.arena = null;
    for (const s of Object.values(W.segInfo)) if (s.arena) R.arena = s;
    G.enemies.length = 0; G.allies.length = 0; Combat.reset();
    // actors
    if (!G.p) Player.create();
    Player.reset(W.start.x, W.start.y, W.start.z); Player.clearSummons(); G.p.rig.setHold(null);
    Ally.spawnTeam();
    for (const sp of W.spawns) Enemy.spawn(sp.type, sp.x, sp.y, sp.z, { group: sp.group, seg: sp.seg });
    for (const pk of W.pickups) this.addPickup(pk.type, pk.x, pk.y, pk.z, pk.v, pk);
    for (const b of W.breakables) this.setupBreakable(b);
    if (W.protect) { R.protectObj = W.protect.target; R.protectObj.aimable = false; R.protectSeg = W.segInfo[W.protect.seg]; }
    if (W.boss) { const b = W.boss; const e = Enemy.spawn(b.id, b.x, b.y, b.z, { state: 'dormant', seg: b.seg }); e.untargetable = true; R.boss = e; e.yaw = -Math.PI / 2 + Math.PI; if (b.id === 'mastermind') { e.shielded = false; } }
    for (const s of Object.values(W.segInfo)) if (s.lock) { s.lock.state = 'idle'; s.lock.wave = -1; s.lock.waveT = 0; s.lock.waveEnemies = []; s.lock.t = 0; }
    Hazards.build(W);
    W.exitMesh.setOpen(R.allDone && !R.noExit);
    R.exitOpen = R.allDone && !R.noExit;
    stage.update(0.5, { x: W.start.x, y: W.start.y, z: W.start.z }, null);
    Cam.snap(G.p); Cam.init = true; Cam.focusOn(W.start.x + 18, W.start.y, 0, 2.4, 16, 0.5);
    if (!o.menu) { G.audio && G.audio.music(spec.mus || ({ tunnel: 'tunnel', sewer: 'tunnel', lab: 'lab' }[spec.theme] || 'level')); G.ui && G.ui.onRunBegin(R); }
    else { R.state = 'menu'; Cam.clearCine(); }
    R.active = true; G.state = 'play';
    for (let i = 0; i < 2; i++) G.W.update(0.016, 0, G.p);
  },
  end(silent) {
    if (!this.active && !silent) return;
    Enemy.clearAll(); Ally.clearAll(); Combat.reset(); Hazards.clear(); Player.clearSummons();
    if (G.fx) G.fx.clear();
    for (const p of this.pickups || []) G.stage.scene.remove(p.mesh);
    this.pickups = [];
    if (G.W && G.W.group) { G.stage.scene.remove(G.W.group); G.W.dispose && G.W.dispose(); }
    this.active = false;
  },
  segAt(x) { let best = null; for (const s of Object.values(this.W.segInfo)) if (x >= s.x0 && x < s.x1) best = s; return best || Object.values(this.W.segInfo)[0]; },

  // ---------------------------------------------------------------- pickups
  addPickup(type, x, y, z, v = 1, extra = {}) {
    if (this.pickups.length > 160 && type === 'coin') return null;
    let mesh;
    if (type === 'coin') { mesh = new THREE.Mesh(coinGeo, coinMat); }
    else if (type === 'hp') { mesh = new THREE.Group(); mesh.add(new THREE.Mesh(hpGeo, hpMat)); const a = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.12, 0.12), crossMat), b = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.46, 0.12), crossMat); mesh.add(a, b); a.position.z = b.position.z = 0.28; }
    else { const col = KEYCOL[extra.name] || 0xffffff; mesh = new THREE.Group(); const k = new THREE.Mesh(keyGeo, new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.6, metalness: 0.6, roughness: 0.3 })); k.scale.set(1, 1.4, 0.6); mesh.add(k); const bm = new THREE.Mesh(beaconGeo, new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false })); bm.position.y = 3; mesh.add(bm); }
    mesh.position.set(x, y, z); G.stage.scene.add(mesh);
    const p = { type, x, y, z, v, mesh, t: Math.random() * 6, id: extra.id, name: extra.name, vy: extra.vy || 0, vx: extra.vx || 0, vz: extra.vz || 0, drop: !!extra.drop, base: y, got: false, age: 0 };
    this.pickups.push(p); return p;
  },
  dropLoot(x, y, z, coins, hp) {
    const n = Math.min(6, Math.max(1, coins)); const each = Math.max(1, Math.floor(coins / n)); let left = coins;
    for (let i = 0; i < n && left > 0; i++) { const v = i === n - 1 ? left : Math.min(each, left); left -= v; const a = Math.random() * 6.28, s = rr(1.5, 4); this.addPickup('coin', x, y + 0.9, z, v, { drop: true, vx: Math.cos(a) * s, vz: Math.sin(a) * s, vy: rr(4, 7) }); }
    if (hp) this.addPickup('hp', x + 0.4, y + 0.9, z, 25, { drop: true, vy: 5 });
  },
  updatePickups(dt) {
    const P = G.p, W = G.W; const mag = P.magnet;
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const k = this.pickups[i]; k.t += dt; k.age += dt;
      if (k.drop) {
        k.vy -= 18 * dt; const nx = k.x + k.vx * dt, nz = k.z + k.vz * dt; if (W.isFree(nx, nz, k.y - 0.9, 0.2)) { k.x = nx; k.z = nz; } k.y += k.vy * dt;
        const gy = W.groundAt(k.x, k.z, k.y - 0.5, 0.1, 0.6) + 0.55; if (k.y <= gy) { k.y = gy; if (Math.abs(k.vy) > 3) { k.vy = -k.vy * 0.45; k.vx *= 0.6; k.vz *= 0.6; } else { k.vy = 0; k.vx = k.vz = 0; k.drop = false; k.base = k.y; } }
      } else { k.y = k.base + Math.sin(k.t * 3) * 0.12; }
      const dx = P.x - k.x, dz = P.z - k.z, d = Math.hypot(dx, dz), dy = Math.abs((P.y + 0.9) - k.y);
      if (!P.dead && k.type !== 'key' && d < mag && dy < 3 && k.age > 0.35) { const sp = 13 * dt; k.x += dx / d * sp; k.z += dz / d * sp; k.y += ((P.y + 0.9) - k.y) * Math.min(1, dt * 8); k.base = k.y; k.drop = false; }
      k.mesh.position.set(k.x, k.y, k.z); if (k.type !== 'hp') k.mesh.rotation.y = k.t * 3; else k.mesh.rotation.y = k.t * 1.5;
      if (!P.dead && d < 1.05 && dy < 2.2 && k.age > 0.25) {
        if (k.type === 'hp' && P.hp >= P.maxHp - 0.5) { continue; }
        this.collect(k); G.stage.scene.remove(k.mesh); this.pickups.splice(i, 1);
      }
    }
  },
  collect(k) {
    const P = G.p;
    if (k.type === 'coin') { this.coins += k.v; this.stats.coins += k.v; G.fx.coin(k.x, k.y, k.z); G.audio && G.audio.sfx('coin'); if (this.coinText === undefined || G.t - this.coinText > 0.25) { G.fx.text(P.x, P.y + 2.2, P.z, '+' + k.v + ' 🪙', 'coin'); this.coinText = G.t; } }
    else if (k.type === 'hp') { Player.heal(k.v); G.audio && G.audio.sfx('heal'); }
    else if (k.type === 'key') { this.keys[k.name] = (this.keys[k.name] || 0) + 1; G.audio && G.audio.sfx('pickup'); G.fx.ring(k.x, k.y - 0.5, k.z, 2, KEYCOL[k.name] || 0xffffff, 0.5); G.ui && G.ui.toast('✔ ' + k.name + ' (' + this.keys[k.name] + '/' + this.needKeys(k.name) + ')'); if (Object.values(this.keys).reduce((a, b) => a + b, 0) >= this.totalKeys) { if (G.W.unlock('keys')) { G.audio && G.audio.sfx('unlock'); G.ui && G.ui.toast('🔓 فُتح الباب المقفل'); } } }
  },
  needKeys(name) { let n = 0; for (const s of this.spec.segs) if (s.keys && s.keys.name === name) n += s.keys.n; return n; },

  // ---------------------------------------------------------------- breakables
  setupBreakable(b) {
    b.kind = 'breakable'; b.r = Math.max(b.hx, b.hz); b.h = b.hh; b.dead = false; b.aimable = b.type === 'nest' || b.type === 'pylon' || b.protect; b.flashT = 0; b.maxHp = b.hp;
    if (b.type === 'nest') { this.nestList.push(b); b.spawnT = rr(3, 6); b.kids = []; }
    if (b.protect) { b.aimable = false; }
  },
  hurtBreakable(b, dmg, o = {}) {
    if (b.dead || b.hp <= 0) return 0;
    if (b.protect && o.src !== 'enemy-proj' && (o.from && o.from.kind !== 'enemy')) return 0;
    b.hp -= dmg; b.flashT = 0.12; b.mesh.scale.setScalar(1.06);
    G.fx.hit(b.x, b.y + b.hh * 0.5, b.z, b.type === 'barricade' ? 0xcaa070 : 0xffe0a0); if (dmg > 2) G.fx.text(b.x, b.y + b.hh + 0.1, b.z, String(Math.round(dmg)), '');
    G.audio && G.audio.sfx('hit');
    if (b.hp <= 0) this.destroyBreakable(b, o);
    return dmg;
  },
  destroyBreakable(b, o = {}) {
    b.dead = true; b.hp = 0; G.stage.scene.remove(b.mesh); b.mesh.visible = false; if (b.collider) { b.collider.enabled = false; G.W.nav && G.W.nav.toggle(b.collider, false); }
    G.fx.dust(b.x, b.y + 0.4, b.z, 10, b.type === 'nest' ? 0x7a4a8a : 0xa08868); G.fx.spark(b.x, b.y + 0.6, b.z, 0xffe0a0, 8);
    if (b.type === 'generator' && b.protect) { G.fx.explode(b.x, b.y + 1, b.z, 3, 0xff8a2a); return; }
    const L = b.loot || {}; this.dropLoot(b.x, b.y, b.z, L.coins || 0, L.hp);
    if (b.explosive) { G.fx.explode(b.x, b.y + 0.5, b.z, 3.4, 0xff8a2a); G.audio && G.audio.sfx('boom'); Combat.area(b.x, b.z, 3.4, 30, 'p', { knock: 9, y: b.y, kind: 'explo' }); Combat.area(b.x, b.z, 3.4, 26 * (G.run ? 1 : 1), 'e', { knock: 9, y: b.y }); }
    if (b.type === 'nest') { this.nests++; G.fx.explode(b.x, b.y + 0.8, b.z, 3, 0xb36bff); G.audio && G.audio.sfx('boom'); G.ui && G.ui.toast('دُمّر العش (' + this.nests + ')'); for (const k of b.kids || []) if (!k.dead) Enemy.hurt(k, 9999, {}); }
    if (b.type === 'pylon') { G.fx.explode(b.x, b.y + 1.5, b.z, 3, 0x66ffee); G.audio && G.audio.sfx('boom'); this.checkPylons(); }
    if (b.type === 'barricade') G.audio && G.audio.sfx('boom');
    if (b.type === 'safe') this.dropLoot(b.x, b.y, b.z, 25, true);
  },
  spawnPylons(boss) {
    if (!this.arena) return; const a = this.arena; const cx = (a.x0 + a.x1) / 2 + 2; this.pylons = this.pylons || [];
    for (const p of this.pylons) if (!p.dead) return;
    this.pylons = [];
    const spots = [[cx - 8, -9], [cx + 6, 10], [cx + 8, -8], [cx - 6, 9]];
    for (let i = 0; i < 3; i++) { const [x, z] = spots[i]; const b = breakable(G.W, { type: 'pylon', x, z, y: 0, hp: 150 + 20 * this.diff }); this.setupBreakable(b); b.aimable = true; this.pylons.push(b); G.fx.ring(x, 0, z, 3, 0x66ffee, 0.6); }
    boss.shielded = true; G.ui && G.ui.toast('الأبراج تحمي العقل المدبّر — دمّرها!'); G.audio && G.audio.sfx('warn');
  },
  checkPylons() { if (!this.pylons) return; if (this.pylons.every(p => p.dead)) { const b = this.boss; if (b && !b.dead) { b.shielded = false; b.weak = 5; b.stunT = 2.2; b.rig.setHold('stun'); G.ui && G.ui.toast('انهار الدرع! اضرب العقل المدبّر!'); G.fx.explode(b.x, b.y + 2, b.z, 5, 0x66ffee); G.fx.addShake(0.8); } } },

  // ---------------------------------------------------------------- interact
  interact(it) {
    if (!it.enabled) return;
    if (it.type === 'switch') {
      it.enabled = false; this.switchesOn++; if (it.lightMat) it.lightMat.color.setHex(0x3aff7a); if (it.beacon) it.beacon.visible = false;
      G.audio && G.audio.sfx('switch'); G.fx.ring(it.x, it.y, it.z, 2.2, 0x3aff7a, 0.5); G.fx.spark(it.x, it.y + 1.3, it.z, 0x3aff7a, 10); G.ui && G.ui.toast('تم تشغيل الجهاز (' + this.switchesOn + '/' + this.totalSwitches + ')');
      if (this.switchesOn >= this.totalSwitches) { if (G.W.unlock('switches')) { G.audio && G.audio.sfx('unlock'); G.ui && G.ui.toast('🔓 فُتح الباب المقفل'); } }
    } else if (it.type === 'cage') {
      it.enabled = false; if (it.collider) { it.collider.enabled = false; G.W.nav && G.W.nav.toggle(it.collider, false); } if (it.beacon) it.beacon.visible = false;
      this.rescued.add(it.ally); G.audio && G.audio.sfx('unlock'); G.fx.explode(it.x, it.y + 1, it.z, 2.5, 0x66ffa8);
      it.sink = 0; G.W.addAnim((t, dt) => { if (it.mesh.visible) { it.sink += dt; it.mesh.position.y -= dt * 3; if (it.sink > 0.8) it.mesh.visible = false; } });
      const first = !Save.d.allies[it.ally]; Ally.join(it.ally, it.x, it.y, it.z);
      const def = G.AllyDefs[it.ally]; G.ui && G.ui.banner((first ? 'انضمّ إلى فريقك: ' : 'حُرّر: ') + def.name + ' (' + def.role + ')', 3);
    } else if (it.type === 'mech') { Player.mount(it); }
  },

  // ---------------------------------------------------------------- events
  onEnemyDeath(e) {
    const def = e.def; if (e.wave === 'boss' && !def.coins) return;
    const c = def.coins; const n = Array.isArray(c) ? Math.round(rr(c[0], c[1])) : c;
    if (!e.noLoot) this.dropLoot(e.x, e.y, e.z, n * (e.boss ? 1 : 1), !e.boss && Math.random() < 0.1);
    const xp = Math.round(def.xp * (this.replay ? 0.6 : 1)); if (!e.noLoot) { this.xp += xp; this.stats.xp += xp; Player.addXP(xp); }
    if (e.boss) { this.bossDefeated = true; if (this.pylons) for (const p of this.pylons) if (!p.dead) { p.dead = true; p.mesh.visible = false; p.collider.enabled = false; } for (const x of G.enemies) if (x !== e && !x.dead) Enemy.hurt(x, 99999, {}); G.W.unlock('boss'); G.W.unlock('arena_in'); if (this.arena && this.arena.gateW) { G.W.openDoor(this.arena.gateW, true); } G.ui && G.ui.banner('هُزم ' + def.name + '!', 3); G.audio && G.audio.music('victory'); G.audio && G.audio.sfx('win'); Cam.focusOn(e.x, e.y + 1, e.z, 2.2, 12, 0.5); G.slowmo = 1.4; }
  },
  onPlayerDeath() {
    if (this.mode && this.mode.onDeath) { this.mode.onDeath(); return; }
    this.state = 'dead'; this.deadT = 0; this.stats.deaths++; G.ui && G.ui.hideAbilityTips && G.ui.hideAbilityTips();
  },
  onFall() {
    const P = G.p; if (this.state !== 'play') { const s = P.safe || this.W.start; Player.place(s.x, s.y + 0.1, s.z); return; }
    this.fellFlag = true; const s = P.safe || this.checkpoint; Player.hurt(Math.max(1, P.maxHp * 0.15), { tick: true }); if (P.dead) return;
    Player.place(s.x, s.y + 0.2, s.z); P.iframes = 1.2; G.fx.ring(s.x, s.y, s.z, 2, 0xffffff, 0.4); G.ui && G.ui.toast('سقطت! عدت إلى آخر نقطة آمنة'); G.audio && G.audio.sfx('hurt'); Cam.snap(P);
  },
  respawn() {
    const P = G.p, cp = this.checkpoint; Player.reset(cp.x, cp.y + 0.05, cp.z); Player.clearSummons(); Combat.reset(); G.fx.clear();
    for (const a of G.allies) { a.down = false; a.hp = a.maxHp; a.rig.setHold(null); Ally.snapNear(a); }
    for (const e of G.enemies) { e.target = null; e.atk && Enemy.cancel(e); }
    if (this.boss && !this.boss.dead && this.bossStarted) { this.boss.hp = Math.min(this.boss.maxHp, this.boss.hp + this.boss.maxHp * 0.15); }
    this.state = 'play'; this.frozenInput = false; Cam.snap(P); G.ui && G.ui.onRespawn();
  },
  // ---------------------------------------------------------------- objectives
  objDone(o) {
    const W = G.W, P = G.p;
    switch (o.type) {
      case 'reach': { const s = W.segInfo[o.seg]; if (!s) return true; if (o.at === 'entry') return P.x > s.x0 + 3 && P.x < s.x1 + 40; if (o.at === 'center') return P.x > (s.x0 + s.x1) / 2; if (o.at === 'exit') { if (s.void) return Math.hypot(P.x - s.exit.x, P.z - s.exit.z) < 4 && Math.abs(P.y - (s.exit.y || 0)) < 2.5; return P.x > s.x1 - 3.5; } return false; }
      case 'clear': { const s = W.segInfo[o.seg]; if (s && s.lock) { o.cur = s.lock.state === 'done' ? 1 : 0; return s.lock.state === 'done'; } if (G.p.x < (s ? s.x0 : 0)) return false; const left = G.enemies.filter(e => e.seg === o.seg && !e.dead).length; o.left = left; return left === 0 && P.x > s.x0 + 3; }
      case 'switches': o.cur = this.switchesOn; return this.switchesOn >= o.n;
      case 'rescue': return this.rescued.has(o.ally);
      case 'collect': o.cur = this.keys[o.name] || 0; return o.cur >= o.n;
      case 'destroy': o.cur = this.nests; return this.nests >= o.n;
      case 'boss': return this.bossDefeated;
      case 'protect': o.cur = this.protectDone ? 1 : 0; return this.protectDone;
    }
    return false;
  },
  updateObjectives() {
    let all = true;
    for (const o of this.objectives) { if (!o.done) { if (this.objDone(o)) { o.done = true; G.ui && G.ui.objectiveDone(o); G.audio && G.audio.sfx('objective'); } } if (!o.done) all = false; }
    if (all && !this.allDone) { this.allDone = true; if (!this.noExit) { this.exitOpen = true; G.W.exitMesh.setOpen(true); G.ui && G.ui.banner('المخرج مفتوح — تقدّم نحو البوابة الخضراء!', 3); G.audio && G.audio.sfx('unlock'); } }
  },
  current() { return this.objectives.find(o => !o.done) || null; },
  goal() {
    const W = G.W, P = G.p; const cur = this.current();
    if (!cur) return this.noExit ? null : { x: W.exit.x, y: W.exit.y, z: W.exit.z, label: 'المخرج' };
    const s = W.segInfo[cur.seg];
    switch (cur.type) {
      case 'reach': { if (!s) return null; if (cur.at === 'entry') return { x: s.x0 + 4, z: s.entry.z, y: s.entry.y || 0 }; if (cur.at === 'center') return { x: (s.x0 + s.x1) / 2, z: 0, y: 0 }; return { x: s.exit.x - 1, z: s.exit.z, y: s.exit.y || 0 }; }
      case 'clear': { const e = G.enemies.filter(e => e.seg === cur.seg && !e.dead).sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z))[0]; if (e) return { x: e.x, z: e.z, y: e.y }; return s ? { x: (s.x0 + s.x1) / 2, z: 0, y: 0 } : null; }
      case 'switches': { const it = G.W.interactables.filter(i => i.type === 'switch' && i.enabled).sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z))[0]; return it ? { x: it.x, z: it.z, y: it.y } : null; }
      case 'rescue': { const it = G.W.interactables.find(i => i.type === 'cage' && i.ally === cur.ally && i.enabled); return it ? { x: it.x, z: it.z, y: it.y } : null; }
      case 'collect': { const k = this.pickups.filter(k => k.type === 'key' && k.name === cur.name).sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z))[0]; return k ? { x: k.x, z: k.z, y: k.y - 0.9 } : null; }
      case 'destroy': { const n = this.nestList.filter(n => !n.dead).sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z))[0]; return n ? { x: n.x, z: n.z, y: n.y, attack: true } : null; }
      case 'boss': { if (this.boss && !this.boss.dead) return { x: this.boss.x, z: this.boss.z, y: 0, attack: true }; return null; }
      case 'protect': { if (this.protectObj) return { x: this.protectObj.x, z: this.protectObj.z, y: 0 }; return null; }
    }
    return null;
  },
  // ---------------------------------------------------------------- waves / locks
  waveSpots(info, n) {
    const W = G.W, P = G.p, out = []; const areas = info.areas.filter(a => a.tag === 'main'); if (!areas.length) return out;
    for (let tr = 0; tr < 140 && out.length < n; tr++) {
      const a = areas[Math.floor(Math.random() * areas.length)]; const x = rr(a.x0 + 1, a.x1 - 1), z = rr(a.z0 + 1, a.z1 - 1); const d = Math.hypot(x - P.x, z - P.z);
      if (d < (tr < 70 ? 9 : 5) || d > 26) continue; if (!W.isFree(x, z, a.y || 0, 0.9)) continue; if (out.some(o => Math.hypot(o.x - x, o.z - z) < 1.8)) continue; out.push({ x, z, y: a.y || 0 });
    }
    return out;
  },
  spawnWave(info, list, idx) {
    const L = info.lock; const types = []; for (const [t, n] of Object.entries(list)) for (let i = 0; i < n; i++) types.push(t);
    const spots = this.waveSpots(info, types.length); L.waveEnemies = [];
    types.forEach((t, i) => { const s = spots[i] || spots[0]; if (!s) return; const z = ENEMIES[t].rises; const e = Enemy.spawn(t, s.x, s.y, s.z, { state: z ? 'rising' : 'chase', rise: z, fromWave: true, seg: info.id, group: info.id + '_w' + idx }); e.wave = info.id + idx; if (z) { e.untargetable = true; } else { G.fx.ring(s.x, s.y, s.z, 1.6, 0xff6a3a, 0.5); G.fx.dust(s.x, s.y, s.z, 5); } L.waveEnemies.push(e); });
    G.audio && G.audio.sfx('warn'); G.fx.addShake(0.2);
  },
  setBarriers(info, on) { for (const b of info.lock.barriers) { b.collider.enabled = on; b.mesh.visible = on; } },
  updateLocks(dt) {
    const P = G.p;
    for (const info of Object.values(G.W.segInfo)) {
      const L = info.lock; if (!L) continue;
      if (L.state === 'idle') {
        if (P.x > L.triggerX && P.x < info.x1 - 4 && !P.dead) { L.state = 'active'; L.wave = -1; L.waveT = 1.2; L.t = 0; this.setBarriers(info, true); G.audio && G.audio.sfx('warn'); G.ui && G.ui.banner(info.spec.protect ? 'احمِ الجهاز من الموجات!' : 'الطريق مغلق — اهزم الأعداء!', 2.4); if (info.spec.protect && this.protectObj) { this.protectActive = true; const ob = this.objectives.find(o => o.type === 'protect'); this.protectLeft = ob ? ob.secs : 45; } if (info.spec.alarm) G.audio && G.audio.sfx('thunder'); }
      } else if (L.state === 'active') {
        L.t += dt; const prot = !!info.spec.protect;
        const alive = G.enemies.filter(e => e.seg === info.id && e.fromWave && !e.dead).length;
        if (prot && this.protectActive && !this.protectDone) {
          this.protectLeft -= dt; if (this.protectObj.dead) { this.fail('تحطّم الجهاز الذي كان عليك حمايته!'); return; }
          if (this.protectLeft <= 0) { this.protectDone = true; this.protectActive = false; for (const e of G.enemies) if (e.seg === info.id && !e.dead) { e.noLoot = true; Enemy.hurt(e, 99999, {}); } L.state = 'done'; this.setBarriers(info, false); G.ui && G.ui.banner('اكتمل البث! نجحت في الحماية', 3); G.audio && G.audio.sfx('win'); continue; }
        }
        const waves = L.waves;
        if (prot) {
          L.waveT -= dt;
          if (L.waveT <= 0 && (alive <= 3 || L.t - (L.lastSpawn || 0) > 14)) { L.wave++; this.spawnWave(info, waves[L.wave % waves.length], L.wave); L.waveT = 4; L.lastSpawn = L.t; }
        } else if (alive === 0) {
          if (L.wave >= waves.length - 1 && L.wave >= 0) { L.state = 'done'; this.setBarriers(info, false); G.ui && G.ui.banner('تم تطهير المنطقة — الطريق مفتوح', 2.4); G.audio && G.audio.sfx('unlock'); }
          else { L.waveT -= dt; if (L.waveT <= 0) { L.wave++; this.spawnWave(info, waves[L.wave], L.wave); L.waveT = 1.8; G.ui && G.ui.toast('الموجة ' + (L.wave + 1) + ' من ' + waves.length); } }
        }
      }
    }
  },
  updateBoss(dt) {
    const b = this.boss; if (!b || b.dead || !this.arena) return; const a = this.arena, P = G.p;
    if (!this.bossStarted) {
      if (P.x > a.x0 + 7 && !P.dead) {
        this.bossStarted = true; this.state = 'bossintro'; this.stateT = 0; this.frozenInput = true;
        G.W.openDoor(a.gateW, false); G.W.setDoorLocked(a.gateW, true); G.audio && G.audio.sfx('door'); G.fx.addShake(0.5);
        b.state = 'intro'; b.st = -0.5; b.rig.act('roar', 1.1); b.untargetable = false; Cam.focusOn(b.x, b.y + 1.5, b.z, 3.2, 17, 0.5);
        G.ui && G.ui.bossIntro(b.def); G.audio && G.audio.music('boss'); G.audio && G.audio.sfx('roar');
        if (b.type === 'mastermind') this.spawnPylons(b);
      }
    }
  },
  // ---------------------------------------------------------------- hazards / cps / exit
  updateCheckpoints() {
    const P = G.p; for (const cp of this.cps) { if (cp.active) continue; if (Math.hypot(P.x - cp.x, P.z - cp.z) < cp.r && Math.abs(P.y - cp.y) < 3) { cp.active = true; cp.mat.color.setHex(0xffe94a); this.checkpoint = { x: cp.x, y: cp.y, z: cp.z }; G.ui && G.ui.toast('✔ نقطة حفظ'); G.audio && G.audio.sfx('objective'); G.fx.ring(cp.x, cp.y, cp.z, 2.5, 0xffe94a, 0.5); Player.heal(P.maxHp * 0.2); } }
  },
  // ---------------------------------------------------------------- update
  update(dt) {
    if (!this.active) return;
    const W = G.W, P = G.p; G.t += dt; this.stateT += dt;
    const mode = this.mode;
    if (this.state === 'intro') { if (this.stateT > 2.4 || (this.skipIntro)) { this.state = 'play'; this.frozenInput = false; Cam.clearCine(); G.ui && G.ui.onIntroEnd(); } }
    else if (this.state === 'bossintro') { if (this.stateT > 3.0) { this.state = 'play'; this.frozenInput = false; this.boss.state = 'chase'; this.boss.rig.setHold(null); Cam.clearCine(); G.ui && G.ui.bossBar(true); } }
    if (this.state === 'play' || this.state === 'bossintro' || this.state === 'intro') this.time += this.state === 'play' ? dt : 0;
    W.update(dt, G.t, P); const zone = W.updateZone(P);
    Player.update(dt); Player.updateSummons(dt);
    Ally.updateAll(dt); Enemy.updateAll(dt); Combat.update(dt); Hazards.update(dt, G.t);
    this.updatePickups(dt); this.updateCheckpoints();
    if (this.state === 'play') {
      this.updateObjectives(); this.updateLocks(dt); this.updateBoss(dt); this.updateNests(dt);
      if (mode && mode.update) mode.update(dt);
      if (this.exitOpen && !this.noExit && !P.dead) { const ex = W.exit; if (Math.hypot(P.x - ex.x, P.z - ex.z) < ex.r + 0.6 && Math.abs(P.y - (ex.y || 0)) < 3) this.complete(); }
    }
    if (this.state === 'dead') { this.deadT += dt; if (this.deadT > 1.4 && !this.failShown) { this.failShown = true; G.ui && G.ui.showFail(this); } }
    if (this.state === 'complete') { this.completeT += dt; if (this.completeT > 1.9 && !this.resShown) { this.resShown = true; G.ui && G.ui.showResults(this.results, this); } }
    if (this.protectObj && this.protectObj.mesh) { const b = this.protectObj; if (b.flashT > 0) { b.flashT -= dt; if (b.flashT <= 0) b.mesh.scale.setScalar(1); } }
    for (const b of this.nestList) if (b.flashT > 0) { b.flashT -= dt; if (b.flashT <= 0) b.mesh.scale.setScalar(1); }
    for (const b of W.breakables) if (b.flashT > 0 && !b.dead) { b.flashT -= dt; if (b.flashT <= 0) b.mesh.scale.setScalar(1); }
    const seg = this.segAt(P.x); this.seg = seg;
    Cam.update(dt, P, W, zone, seg);
    W.updateOcclusion(new THREE.Vector3(Cam.pos.x, Cam.pos.y, Cam.pos.z), new THREE.Vector3(P.x, P.y + 1, P.z));
    G.stage.update(dt, { x: P.x, y: P.y, z: P.z }, zone); G.fx.update(dt);
  },
  updateNests(dt) {
    const P = G.p;
    for (const n of this.nestList) { if (n.dead) continue; if (Math.hypot(P.x - n.x, P.z - n.z) > 22) continue; n.spawnT -= dt; n.kids = n.kids.filter(k => !k.dead); if (n.spawnT <= 0 && n.kids.length < 3) { n.spawnT = rr(7, 10); for (let tr = 0; tr < 8; tr++) { const a = Math.random() * 6.28, r = 2.2; const x = n.x + Math.cos(a) * r, z = n.z + Math.sin(a) * r; if (G.W.isFree(x, z, n.y, 0.7)) { const e = Enemy.spawn(Math.random() < 0.35 ? 'zfast' : 'zombie', x, n.y, z, { state: 'rising', rise: true, fromWave: true, seg: n.seg }); n.kids.push(e); G.fx.ring(x, n.y, z, 1.4, 0xb36bff, 0.5); break; } } } }
  },
  // ---------------------------------------------------------------- results
  fail(msg) { if (this.state !== 'play') return; this.state = 'dead'; this.deadT = 0; this.failMsg = msg; this.stats.deaths++; G.audio && G.audio.sfx('lose'); },
  complete() {
    if (this.state !== 'play') return;
    if (this.mode && this.mode.complete) return this.mode.complete(); this.state = 'complete'; this.completeT = 0; this.frozenInput = true; const P = G.p, spec = this.spec;
    const id = spec.id; const prev = Save.d.completed[id]; const first = !prev; this.replay = !first;
    const par = this.par, t = this.time; let stars = 1; if (this.stats.deaths === 0) stars = 2; if (this.stats.deaths === 0 && t <= par) stars = 3; if (prev && prev.stars > stars) stars = Math.max(stars, 1);
    const score = Math.round(this.stats.kills * 25 + this.stats.coins * 6 + stars * 500 + Math.max(0, par - t) * 4 - this.stats.taken * 0.5 - this.stats.deaths * 150);
    const rew = spec.rew || { coins: 100, xp: 50 };
    const f = first ? 1 : 0.4; const bonusC = Math.round(rew.coins * f * (stars === 3 ? 1.25 : stars === 2 ? 1.1 : 1)); const bonusXp = Math.round(rew.xp * f);
    const coinsTotal = bonusC + this.coins;
    Save.d.coins += coinsTotal; Save.d.stats.coinsEarned += coinsTotal; Player.addXP(bonusXp);
    const best = prev ? Math.max(prev.best || 0, score) : score; const bestStars = prev ? Math.max(prev.stars || 0, stars) : stars; const bestT = prev && prev.time ? Math.min(prev.time, t) : t;
    Save.d.completed[id] = { best, stars: bestStars, time: Math.round(bestT * 10) / 10, runs: (prev ? prev.runs : 0) + 1 };
    const newBest = !prev || score > (prev.best || 0);
    if (Save.d.unlockedStage <= id) Save.d.unlockedStage = id + 1;
    let unlocks = []; if (id >= 6 && !Save.d.titan) { Save.d.titan = true; unlocks.push('★ قوة التحوّل (العملاق) — اضغط [تحوّل] عند امتلاء عدّاد الغضب'); }
    for (const [k, it] of Object.entries(G.ItemDefs)) if (it.unlock.type === 'stage' && it.unlock.n === id) unlocks.push('سلاح جديد في المتجر: ' + it.name);
    for (const [k, a] of Object.entries(G.AllyDefs)) if (this.rescued.has(k) && !prev) unlocks.push('حليف: ' + a.name);
    if (LEVEL_BY_ID[id + 1]) unlocks.push('المرحلة ' + (id + 1) + ' مفتوحة'); else unlocks.push('أكملت الحملة!');
    Save.commit(true);
    this.results = { id, name: spec.name, time: t, par, kills: this.stats.kills, taken: Math.round(this.stats.taken), deaths: this.stats.deaths, coinsPicked: this.coins, rewardCoins: bonusC, rewardXp: bonusXp + this.xp, stars, score, best, newBest, first, unlocks, mode: this.mode ? this.mode.id : 'story' };
    P.rig.setHold('victory'); G.audio && G.audio.music('victory'); G.audio && G.audio.sfx('win'); G.fx.ring(P.x, P.y, P.z, 5, 0x66ffa8, 0.8); G.fx.spark(P.x, P.y + 2, P.z, 0xffe94a, 30, { speed: 7 }); Cam.focusOn(P.x + 1, P.y, P.z, 9, 8, 0.35);
  },
};
