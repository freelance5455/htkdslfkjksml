// Scene setup: sky dome, sun with follow-shadows, hemisphere light, dynamic light pool, interior mood blending.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { THEMES } from './themes.js';
import { damp } from './util.js';
import { G } from './ctx.js';

export const QUALITY = {
  low: { dpr: 1, shadow: 0, outline: false, particles: 120, lights: 2, env: false, aa: false, draw: 70, fxScale: 0.5 },
  med: { dpr: 1.25, shadow: 1024, outline: true, particles: 260, lights: 4, env: true, aa: true, draw: 110, fxScale: 0.8 },
  high: { dpr: 2, shadow: 2048, outline: true, particles: 480, lights: 6, env: true, aa: true, draw: 160, fxScale: 1 },
};

export class Stage {
  constructor(renderer, qname = 'med') {
    this.renderer = renderer;
    this.scene = new THREE.Scene(); this.scene.scale.x = -1; this._v = new THREE.Vector3();
    this.camera = new THREE.PerspectiveCamera(52, innerWidth / innerHeight, 0.2, 700);
    this.sunDir = new THREE.Vector3(-0.5, 0.8, -0.5).normalize();
    this.hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1);
    this.sun = new THREE.DirectionalLight(0xffffff, 2);
    this.sun.castShadow = true; this.sun.shadow.bias = -0.0004; this.sun.shadow.normalBias = 0.04;
    this.scene.add(this.hemi, this.sun, this.sun.target);
    this.sky = this._makeSky(); this.scene.add(this.sky);
    this.stars = null; this.pool = [];
    this.mood = { sun: 1, hemi: 1 }; this.moodT = { sun: 1, hemi: 1 };
    this.theme = null; this.flash = 0; this.nextFlash = 5;
    this.world = null; this.envTex = null;
    this.setQuality(qname);
  }
  _makeSky() {
    const geo = new THREE.SphereGeometry(450, 24, 14);
    const mat = new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: { top: { value: new THREE.Color(0x203050) }, bot: { value: new THREE.Color(0xf0a060) } },
      vertexShader: 'varying float h; void main(){ vec4 p = modelMatrix*vec4(position,1.0); h = normalize(position).y; gl_Position = projectionMatrix*viewMatrix*p; }',
      fragmentShader: 'uniform vec3 top; uniform vec3 bot; varying float h; void main(){ float t = smoothstep(-0.05, 0.75, h); gl_FragColor = vec4(mix(bot, top, t), 1.0); }',
    });
    const m = new THREE.Mesh(geo, mat); m.frustumCulled = false; m.renderOrder = -10; return m;
  }
  setQuality(q) {
    this.q = QUALITY[q] || QUALITY.med; this.qname = q; G.fx = G.fx || {}; G.fx.outline = this.q.outline;
    const r = this.renderer;
    r.setPixelRatio(Math.min(devicePixelRatio || 1, this.q.dpr));
    r.shadowMap.enabled = this.q.shadow > 0; r.shadowMap.type = THREE.PCFSoftShadowMap;
    this.sun.castShadow = this.q.shadow > 0;
    if (this.q.shadow) { this.sun.shadow.mapSize.set(this.q.shadow, this.q.shadow); if (this.sun.shadow.map) { this.sun.shadow.map.dispose(); this.sun.shadow.map = null; } const c = this.sun.shadow.camera; const S = 34; Object.assign(c, { left: -S, right: S, top: S, bottom: -S, near: 1, far: 140 }); c.updateProjectionMatrix(); }
    if (this.q.env && !this.envTex) { const pm = new THREE.PMREMGenerator(r); this.envTex = pm.fromScene(new RoomEnvironment(), 0.04).texture; pm.dispose(); }
    this.scene.environment = this.q.env ? this.envTex : null; this.scene.environmentIntensity = 0.35;
    this._poolN(this.q.lights);
    this.resize();
  }
  _poolN(n) {
    for (const l of this.pool) this.scene.remove(l); this.pool = [];
    for (let i = 0; i < n; i++) { const l = new THREE.PointLight(0xffffff, 0, 14, 1.6); l.intensity = 0; l.visible = false; this.scene.add(l); this.pool.push(l); }
    if (this.world) this.world.lightPool = this.pool;
  }
  /** place camera in GAME coordinates (scene is mirrored on x so +x runs to the right of the screen) */
  setCamera(px, py, pz, tx, ty, tz) { this.camera.position.set(-px, py, pz); this.camera.lookAt(-tx, ty, tz); this.camera.updateMatrixWorld(); }
  toScreen(x, y, z) { const v = this._v.set(-x, y, z).project(this.camera); if (v.z > 1 || v.z < -1) return null; return v; }
  resize() { const w = innerWidth, h = innerHeight; this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); }
  setTheme(name) {
    const th = THEMES[name] || THEMES.dusk; this.theme = th;
    this.sky.material.uniforms.top.value.setHex(th.sky[0]); this.sky.material.uniforms.bot.value.setHex(th.sky[1]);
    this.scene.fog = new THREE.Fog(th.fog[0], th.fog[1], th.fog[2]); this.scene.background = new THREE.Color(th.fog[0]);
    this.sun.color.setHex(th.sun.c); this.sunDir.set(...th.sun.dir).normalize();
    this.hemi.color.setHex(th.hemi[0]); this.hemi.groundColor.setHex(th.hemi[1]);
    this.renderer.toneMappingExposure = th.exposure;
    if (this.stars) { this.scene.remove(this.stars); this.stars = null; }
    if (th.stars) { const g = new THREE.BufferGeometry(); const n = 300, p = new Float32Array(n * 3); for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, e = 0.15 + Math.random() * 1.2, r = 420; p[i * 3] = Math.cos(a) * Math.cos(e) * r; p[i * 3 + 1] = Math.sin(e) * r; p[i * 3 + 2] = Math.sin(a) * Math.cos(e) * r; } g.setAttribute('position', new THREE.BufferAttribute(p, 3)); this.stars = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 1.6, sizeAttenuation: false, fog: false })); this.scene.add(this.stars); }
    this.mood = { sun: 1, hemi: 1 }; this.moodT = { sun: 1, hemi: 1 };
  }
  attach(world) {
    if (this.world) this.scene.remove(this.world.group);
    this.world = world; this.scene.add(world.group); world.lightPool = this.pool;
    if (world.theme && !this._themeName) this.setTheme(world.spec.theme);
  }
  setWorld(world, themeName) { this.attach(world); this.setTheme(themeName || world.spec.theme); }
  update(dt, focus, zone) {
    const th = this.theme; if (!th) return;
    this.moodT = zone ? zone.mood : { sun: 1, hemi: 1 };
    this.mood.sun = damp(this.mood.sun, this.moodT.sun ?? 1, 5, dt); this.mood.hemi = damp(this.mood.hemi, this.moodT.hemi ?? 1, 5, dt);
    let flash = 0;
    if (th.lightning) { this.nextFlash -= dt; if (this.nextFlash <= 0) { this.flash = 1; this.nextFlash = 4 + Math.random() * 8; } this.flash = Math.max(0, this.flash - dt * 2.5); flash = this.flash * (Math.random() > 0.3 ? 1 : 0.4); }
    this.sun.intensity = th.sun.i * this.mood.sun + flash * 2;
    this.hemi.intensity = th.hemi[2] * this.mood.hemi + flash * 1.5;
    if (focus) {
      this.sun.position.set(focus.x + this.sunDir.x * 70, focus.y + this.sunDir.y * 70, focus.z + this.sunDir.z * 70);
      this.sun.target.position.set(focus.x, focus.y, focus.z); this.sun.target.updateMatrixWorld();
      this.sky.position.set(-this.camera.position.x, this.camera.position.y, this.camera.position.z); if (this.stars) this.stars.position.copy(this.sky.position);
    }
  }
  render() { this.renderer.render(this.scene, this.camera); }
}
