// Multi-floor path following: ground A* (nav grid) + explicit stair links so actors can climb to upper floors and come back down.
import { G } from './ctx.js';

export function planLink(e, tx, ty, tz) {
  const W = G.W, links = W.links || []; if (!links.length) return null;
  const up = ty > e.y; let best = null, bs = 1e9;
  for (const L of links) {
    const a = up ? L.from : L.to, b = up ? L.to : L.from;
    if (Math.abs(a.y - e.y) > 1.2 && !(up === false && Math.abs(L.to.y - e.y) < 1.4)) continue;
    if (Math.abs(b.y - ty) > 1.6) continue;
    const s = Math.hypot(a.x - e.x, a.z - e.z) + Math.hypot(b.x - tx, b.z - tz) + Math.hypot(a.x - b.x, a.z - b.z);
    if (s < bs) { bs = s; best = L; }
  }
  if (!best) return null;
  const a = up ? best.from : best.to, b = up ? best.to : best.from; const wp = [];
  if (up) { const p = W.nav.path(e.x, e.z, a.x, a.z, 4000); if (p) for (let i = 1; i < p.length; i++) wp.push({ x: p[i].x, z: p[i].z }); wp.push({ x: a.x, z: a.z, y: a.y }); wp.push({ x: b.x, z: b.z, y: b.y }); wp.push({ x: tx, z: tz, y: ty }); }
  else { wp.push({ x: a.x, z: a.z, y: a.y }); wp.push({ x: b.x, z: b.z, y: b.y }); const p = W.nav.path(b.x, b.z, tx, tz, 4000); if (p) for (let i = 1; i < p.length; i++) wp.push({ x: p[i].x, z: p[i].z }); wp.push({ x: tx, z: tz }); }
  return wp;
}
/** returns the point the actor should steer toward this frame. Keeps state on e (path/pi/pathT/vp/vpi). */
export function steerPoint(e, tx, tz, ty, dt) {
  const W = G.W; if (!W.nav || !W.nav.enabled) return { x: tx, z: tz };
  ty = ty ?? e.y;
  const d = Math.hypot(tx - e.x, tz - e.z);
  const levelDiff = Math.abs(ty - e.y) > 0.9 && (W.links || []).length > 0;
  if (levelDiff) {
    e.pathT -= dt; if (e.pathT <= 0 || !e.vp) { e.vp = planLink(e, tx, ty, tz); e.vpi = 0; e.pathT = 0.9; }
    if (e.vp && e.vp.length) {
      while (e.vpi < e.vp.length - 1) { const w = e.vp[e.vpi]; if (Math.hypot(w.x - e.x, w.z - e.z) < 0.75 && (w.y === undefined || Math.abs(w.y - e.y) < 1.2)) e.vpi++; else break; }
      const w = e.vp[Math.min(e.vpi, e.vp.length - 1)]; return { x: w.x, z: w.z };
    }
    return { x: tx, z: tz };
  }
  e.vp = null;
  if (e.y > 0.9) return { x: tx, z: tz }; // on an upper floor: open-plan direct steering
  if (d > 2.0 && !W.nav.los(e.x, e.z, tx, tz)) {
    e.pathT -= dt;
    if (e.pathT <= 0 || !e.path) { e.path = W.nav.path(e.x, e.z, tx, tz, 2600); e.pi = 1; e.pathT = 0.6 + Math.random() * 0.4; }
    if (e.path && e.path.length > 1) { while (e.pi < e.path.length - 1 && Math.hypot(e.path[e.pi].x - e.x, e.path[e.pi].z - e.z) < 0.9) e.pi++; const w = e.path[Math.min(e.pi, e.path.length - 1)]; return { x: w.x, z: w.z }; }
  } else e.path = null;
  return { x: tx, z: tz };
}
