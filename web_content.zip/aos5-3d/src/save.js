// Persistent save (localStorage with checksum + backup + in-memory fallback).
import { ITEMS } from './data/items.js';
const KEY = 'aos5_3d_save_v1', KEY_B = 'aos5_3d_save_v1_bak';
export const DEFAULT_KEYS = { up: 'KeyW', down: 'KeyS', left: 'KeyA', right: 'KeyD', jump: 'Space', dodge: 'ShiftLeft', attack: 'KeyJ', a1: 'KeyK', a2: 'KeyL', switch: 'KeyR', interact: 'KeyF', transform: 'KeyT', pause: 'Escape', camL: 'KeyQ', camR: 'KeyE' };
export const KEY_LABELS = { up: 'للأمام', down: 'للخلف', left: 'يسار', right: 'يمين', jump: 'قفز', dodge: 'تفادي', attack: 'هجوم', a1: 'قدرة 1', a2: 'قدرة 2', switch: 'تبديل السلاح', interact: 'تفاعل', transform: 'تحوّل', pause: 'إيقاف', camL: 'تدوير الكاميرا يسارًا', camR: 'تدوير الكاميرا يمينًا' };

function fresh() {
  return {
    v: 1, coins: 0, xp: 0, level: 1, unlockedStage: 1, completed: {},
    items: { pipe: { lv: 1 } }, equip: { primary: 'pipe', a1: null, a2: null },
    allies: {}, team: [], upgrades: {},
    settings: { music: 0.5, sfx: 0.8, quality: 'auto', touch: 'auto', keys: { ...DEFAULT_KEYS }, shake: true, autoAim: true, camSens: 1, hints: true, view: 'third' },
    modes: { zombie: { best: 0, runs: 0 }, jump: { best: {}, runs: 0 }, defense: { best: 0, runs: 0 } },
    titan: false, stats: { kills: 0, deaths: 0, playtime: 0, coinsEarned: 0 }, ver: 1,
  };
}
const hash = (s) => { let h = 2166136261 >>> 0; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h.toString(36); };
const mem = {};
function rd(k) { try { const v = localStorage.getItem(k); return v; } catch (e) { return mem[k] ?? null; } }
function wr(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { mem[k] = v; return false; } }

function merge(base, src) { // deep-merge saved data over defaults (keeps new fields on updates)
  if (Array.isArray(base) || typeof base !== 'object' || base === null) return src === undefined ? base : src;
  const out = { ...base };
  if (src && typeof src === 'object') for (const k of Object.keys(src)) out[k] = (k in base && typeof base[k] === 'object' && base[k] !== null && !Array.isArray(base[k]) && (k !== 'completed' && k !== 'items' && k !== 'allies' && k !== 'upgrades' && k !== 'best')) ? merge(base[k], src[k]) : src[k];
  return out;
}
function validate(d) {
  d.coins = Math.max(0, Math.floor(+d.coins || 0)); d.xp = Math.max(0, Math.floor(+d.xp || 0)); d.level = Math.max(1, Math.min(99, Math.floor(+d.level || 1)));
  d.unlockedStage = Math.max(1, Math.min(99, Math.floor(+d.unlockedStage || 1)));
  if (!d.items.pipe) d.items.pipe = { lv: 1 };
  for (const k of Object.keys(d.items)) if (!ITEMS[k]) delete d.items[k];
  if (!d.items[d.equip.primary]) d.equip.primary = 'pipe';
  for (const s of ['a1', 'a2']) if (d.equip[s] && !d.items[d.equip[s]]) d.equip[s] = null;
  d.team = (d.team || []).filter(a => d.allies[a]).slice(0, 3);
  return d;
}

export const Save = {
  d: fresh(), ok: true, corrupt: false, timer: null,
  load() {
    let raw = rd(KEY), parsed = null;
    for (const r of [raw, rd(KEY_B)]) {
      if (!r) continue;
      try { const o = JSON.parse(r); if (o && o.h === hash(JSON.stringify(o.d))) { parsed = o.d; break; } else this.corrupt = true; } catch (e) { this.corrupt = true; }
    }
    this.d = validate(merge(fresh(), parsed || {}));
    if (parsed) this.corrupt = false;
    return this.d;
  },
  commit(now = false) {
    if (now) return this._write();
    clearTimeout(this.timer); this.timer = setTimeout(() => this._write(), 400);
  },
  _write() {
    clearTimeout(this.timer);
    const j = JSON.stringify(this.d); const out = JSON.stringify({ d: this.d, h: hash(j) });
    const old = rd(KEY); if (old) wr(KEY_B, old);
    this.ok = wr(KEY, out); if (!this.ok && window.G_UI) window.G_UI.toast('تعذّر الحفظ الدائم — سيُحفظ مؤقتًا في هذه الجلسة فقط');
    return this.ok;
  },
  reset() { this.d = fresh(); this._write(); },
  export() { return JSON.stringify(this.d); },
};
