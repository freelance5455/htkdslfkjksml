// Segment templates: each builds a stretch of a level along +X and returns its end x.
import * as THREE from 'three';
import { Props } from './props.js';
import { glow, plain } from './materials.js';

export const ZMAX = 20;
const FAC = [0xb8a890, 0x9aa0a8, 0xa88a7a, 0x8a98a8, 0xc0b098, 0x7a8290, 0xb09888];
const BRICK = [0xd09070, 0xb87a60, 0xc08a6a, 0xa87060];

// ---------------------------------------------------------------- helpers
function facade(W, x0, x1, zIn, o = {}) {
  const rng = W.rng;
  for (const side of [-1, 1]) {
    const rs = (o.reserved || []).filter(r => r.side === side).sort((a, b) => a.x0 - b.x0);
    let cur = x0; const ranges = [];
    for (const r of rs) { if (r.x0 > cur) ranges.push([cur, r.x0]); cur = Math.max(cur, r.x1); }
    if (cur < x1) ranges.push([cur, x1]);
    for (const [a, b] of ranges) {
      let x = a;
      while (x < b - 0.01) {
        let w = Math.min(rng.range(8, 15), b - x); if (b - (x + w) < 5) w = b - x;
        const h = o.h ?? rng.range(9, 24);
        const spec = o.mat === 'brick' ? ['brick', rng.pick(BRICK)] : o.mat === 'metal' ? ['corrugated', rng.pick([0x8a98a8, 0xa8a090, 0x7a8a7a, 0xb08a60])] : ['facade', rng.pick(FAC)];
        const za = side > 0 ? zIn : -ZMAX, zb = side > 0 ? ZMAX : -zIn;
        W.box(x, 0, za, x + w, h, zb, spec, { c: { los: true } });
        if (o.shops !== false && rng.chance(0.6) && w > 7) { // lit shop windows & awning on the street face
          const zf = side > 0 ? zIn - 0.04 : -zIn, zf1 = side > 0 ? zIn : -zIn + 0.04;
          W.box(x + 1, 0.5, zf, x + w - 1, 2.5, zf1, { glow: rng.pick([0xffd9a0, 0xa8e0ff, 0xffb8c0, 0xc8ffc0]) }, { collide: false });
          W.box(x + 0.6, 2.7, side > 0 ? zIn - 1.2 : -zIn, x + w - 0.6, 2.85, side > 0 ? zIn : -zIn + 1.2, { plain: rng.pick([0xc0392b, 0x2e86c1, 0x27ae60, 0xd4ac0d]), rough: 0.9 }, { collide: false });
        }
        x += w;
      }
    }
  }
}
function lampLine(W, x0, x1, hw, step = 15, color = 0xffd8a0, on = true) {
  let k = 0; for (let x = x0 + 6; x < x1 - 3; x += step, k++) Props.lampPost(W, x, (k % 2 ? 1 : -1) * (hw + 0.4), 5.4, color, on, k % 2 ? -1 : 1);
}
function laneMarks(W, x0, x1, hw) {
  W.decal((x0 + x1) / 2, 0, 0.9, x1 - x0, 'yline', Math.PI / 2);
  for (const sd of [-1, 1]) for (let x = x0 + 2; x < x1 - 4; x += 6) W.decal(x + 1.5, sd * hw * 0.5, 0.3, 3, 'line', Math.PI / 2);
}
function stains(W, x0, x1, hw, n) { const r = W.rng; for (let i = 0; i < n; i++) { const t = r.pick(['stain', 'stain', 'puddle']); const s = r.range(2, 4.5); W.decal(r.range(x0 + 2, x1 - 2), r.range(-hw + 1, hw - 1), s, s, t, r.range(0, 3)); } }
export function breakable(W, def) {
  const d = Object.assign({ y: 0, hp: 30, loot: { coins: 3 }, id: 'b' + W.breakables.length }, def);
  const g = new THREE.Group(); g.position.set(d.x, d.y, d.z); const std = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: o.r ?? 0.8, metalness: o.m ?? 0 });
  let hx = 0.5, hz = 0.5, hh = 1.0;
  const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; g.add(m); return m; };
  switch (d.type) {
    case 'crate': add(new THREE.BoxGeometry(1, 1, 1), std(0xa8794a, { r: 0.9 }), 0, 0.5, 0); add(new THREE.BoxGeometry(1.02, 0.12, 1.02), std(0x6a4524), 0, 0.5, 0); hx = hz = 0.5; hh = 1; break;
    case 'barrel': add(new THREE.CylinderGeometry(0.4, 0.4, 1.0, 10), std(0xc0392b, { r: 0.5, m: 0.3 }), 0, 0.5, 0); add(new THREE.CylinderGeometry(0.42, 0.42, 0.08, 10), std(0xf2c230), 0, 0.7, 0); add(new THREE.CylinderGeometry(0.42, 0.42, 0.08, 10), std(0xf2c230), 0, 0.3, 0); hx = hz = 0.4; hh = 1; d.explosive = true; d.hp = d.hp || 15; break;
    case 'barricade': { const w = d.w || 3.4; hx = w / 2; hz = 0.6; hh = 1.9; add(new THREE.BoxGeometry(w, 1.4, 0.9), std(0x7a6a58, { r: 1 }), 0, 0.7, 0); add(new THREE.BoxGeometry(w + 0.2, 0.2, 1.0), std(0x3a3d44, { m: 0.6 }), 0, 1.5, 0); for (let i = 0; i < 3; i++) { const b = add(new THREE.BoxGeometry(w * 0.3, 0.25, 0.12), std(0xf2c230), -w * 0.33 + i * w * 0.33, 1.1, 0.5); b.rotation.z = 0.4; } d.hp = d.hp || 90; break; }
    case 'nest': { hx = hz = 1.3; hh = 1.6; add(new THREE.SphereGeometry(1.35, 12, 8), std(0x6a4a5a, { r: 0.7 }), 0, 0.5, 0).scale.set(1, 0.8, 1); for (let i = 0; i < 6; i++) { const a = i / 6 * 6.28; add(new THREE.ConeGeometry(0.2, 0.9, 5), std(0x9a4aff, { r: 0.4 }), Math.cos(a) * 0.9, 0.9, Math.sin(a) * 0.9).rotation.set(Math.sin(a) * 0.4, 0, -Math.cos(a) * 0.4); } add(new THREE.SphereGeometry(0.45, 10, 8), new THREE.MeshBasicMaterial({ color: 0xb36bff }), 0, 1.0, 0); d.hp = d.hp || 160; break; }
    case 'generator': { hx = 1.0; hz = 0.8; hh = 1.8; add(new THREE.BoxGeometry(2, 1.8, 1.6), std(0x4a5260, { m: 0.5, r: 0.5 }), 0, 0.9, 0); add(new THREE.BoxGeometry(1.2, 0.5, 0.1), new THREE.MeshBasicMaterial({ color: 0xff8a2a }), 0, 1.2, 0.85); d.hp = d.hp || 150; break; }
    case 'safe': { hx = hz = 0.5; hh = 1.1; add(new THREE.BoxGeometry(1, 1.1, 1), std(0x3a4a5a, { m: 0.7, r: 0.4 }), 0, 0.55, 0); add(new THREE.CylinderGeometry(0.18, 0.18, 0.1, 10), std(0xd0a640, { m: 0.9 }), 0, 0.6, 0.52).rotation.x = Math.PI / 2; d.hp = d.hp || 50; break; }
    case 'pylon': { hx = hz = 0.7; hh = 3.4; add(new THREE.CylinderGeometry(0.6, 0.8, 0.6, 8), std(0x2a2e38, { m: 0.6 }), 0, 0.3, 0); add(new THREE.CylinderGeometry(0.25, 0.35, 2.6, 8), std(0x3a4050, { m: 0.6 }), 0, 1.8, 0); add(new THREE.OctahedronGeometry(0.55), new THREE.MeshBasicMaterial({ color: 0x66ffee }), 0, 3.3, 0); d.hp = d.hp || 160; break; }
    default: add(new THREE.BoxGeometry(1, 1, 1), std(0x888888), 0, 0.5, 0);
  }
  W.group.add(g);
  d.mesh = g; d.hx = hx; d.hz = hz; d.hh = hh; d.maxHp = d.hp;
  d.collider = W.addCollider({ x0: d.x - hx, x1: d.x + hx, z0: d.z - hz, z1: d.z + hz, y0: d.y, y1: d.y + hh, breakable: d, ceil: false });
  W.breakables.push(d); return d;
}
function nook(W, x, side, hw, w = 7, d = 6.5) {
  const rng = W.rng, zin = hw + 2.5, th = 0.4, H = 3.8, x1 = x + w;
  const za = side > 0 ? zin : -zin - d, zb = side > 0 ? zin + d : -zin;
  W.floor(x, za, x1, zb, 0, 'wood', { collide: false });
  const hide = [];
  const spec = ['brick', rng.pick(BRICK)];
  // back wall & side walls
  const back = side > 0 ? zb - th / 2 : za + th / 2, front = side > 0 ? za + th / 2 : zb - th / 2;
  const bw = W.wall('x', back, x, x1, 0, H, th, [], spec, { fade: side < 0, hideIn: side < 0 }); if (side < 0) bw.forEach(r => hide.push(r.mesh));
  const fw = W.wall('x', front, x, x1, 0, H, th, [{ c: x + w / 2, w: 2.8, h: 3.0 }], spec, { fade: side > 0, hideIn: side > 0 }); if (side > 0) fw.forEach(r => hide.push(r.mesh));
  W.wall('z', x + th / 2, za, zb, 0, H, th, [], spec); W.wall('z', x1 - th / 2, za, zb, 0, H, th, [], spec);
  const upper = W.box(x, H, za, x1, H + rng.range(6, 14), zb, ['facade', rng.pick(FAC)], { hideIn: true, collide: false }); hide.push(upper.mesh);
  W.door({ x: x + w / 2, z: side > 0 ? za + th / 2 : zb - th / 2, axis: 'x', w: 2.8, h: 3.0, auto: true, color: rng.pick([0x6b4a32, 0x3a5a7a, 0x5a3a3a]) });
  const zone = W.zone({ x0: x + 0.3, x1: x1 - 0.3, z0: za + 0.3, z1: zb - 0.3, hide, mood: { sun: 0.35, hemi: 0.9 }, cam: { dist: 7.5, pitch: 0.9 } });
  const cz = (za + zb) / 2; W.lamp(x + w / 2, 3.0, cz, 0xffd9a0, 7, 11, { flicker: 0.05 });
  Props.shelf(W, x + w / 2, side > 0 ? zb - 1.3 : za + 1.3, w - 2, 'x');
  return { x0: x, x1, za, zb, cz, zone, area: { x0: x + 0.8, x1: x1 - 0.8, z0: za + 0.8, z1: zb - 0.8, y: 0 } };
}

// ---------------------------------------------------------------- outdoor templates
export const T = {};

T.street = (W, s, x0) => {
  const len = s.len || 40, hw = s.hw || 7, x1 = x0 + len, rng = W.rng, zIn = hw + 2.5;
  W.floor(x0, -hw, x1, hw, 0, s.ground || 'asphalt', { collide: false });
  for (const sd of [-1, 1]) W.floor(x0, sd > 0 ? hw : -zIn, x1, sd > 0 ? zIn : -hw, 0.15, 'paving');
  laneMarks(W, x0, x1, hw);
  if (s.crosswalk !== false) W.decal(x0 + len * 0.45, 0, hw * 2, 3, 'zebra', Math.PI / 2);
  stains(W, x0, x1, hw, Math.floor(len / 8));
  // enterable shop nooks
  const reserved = [], nooks = [];
  const nn = s.nooks ?? (len > 34 ? 1 : 0);
  for (let i = 0; i < nn; i++) { const side = i % 2 ? 1 : -1; const nx = x0 + len * (0.2 + 0.5 * (i / Math.max(1, nn))) + 4; const n = nook(W, nx, side, hw); reserved.push({ side, x0: nx, x1: nx + 7 }); nooks.push(n); }
  facade(W, x0, x1, zIn, { reserved, mat: s.facade });
  lampLine(W, x0, x1, hw, 15, s.lampColor || 0xffd8a0, s.lamps !== false);
  // props
  const carN = s.cars ?? Math.floor(len / 12);
  for (let i = 0; i < carN; i++) { const x = x0 + 6 + (i + rng.range(0, 0.8)) * ((len - 12) / Math.max(1, carN)); const sd = rng.sign(); Props.car(W, x, sd * (hw - 1.5), 'x', undefined, rng.chance(s.wrecks ?? 0.3)); }
  for (let i = 0; i < (s.cover ?? 2); i++) { const x = x0 + len * (0.25 + 0.5 * rng.next()); Props.car(W, x, rng.range(-3, 3), rng.chance(0.5) ? 'x' : 'z', undefined, true); }
  for (let i = 0; i < Math.floor(len / 14); i++) { const sd = rng.sign(); Props.dumpster(W, x0 + rng.range(4, len - 4), sd * (hw + 1.3)); Props.barrel(W, x0 + rng.range(4, len - 4), sd * (hw + 0.9), rng.pick([0x3a5a8a, 0x8a3a3a, 0x3a8a5a])); }
  for (let i = 0; i < 2; i++) Props.rubble(W, x0 + rng.range(6, len - 6), rng.sign() * rng.range(3, hw - 1));
  if (s.barricade) { for (const zz of [-5.2, -1.7, 1.7, 5.2]) breakable(W, { type: 'barricade', x: x0 + len * s.barricade, z: zz, w: 3.4, loot: { coins: 4 } }); }
  if (s.barriers) for (let i = 0; i < s.barriers; i++) Props.barrier(W, x0 + len * (0.2 + 0.6 * i / s.barriers), (i % 2 ? 1 : -1) * 4, 5, 'z');
  W.area(x0 + 2, -hw + 1, x1 - 2, hw - 1, 0, 'main');
  for (const n of nooks) W.area(n.area.x0, n.area.z0, n.area.x1, n.area.z1, 0, 'room');
  const info = { x0, x1, hw, nooks };
  info.entry = { x: x0 + 1.5, z: 0 }; info.exit = { x: x1 - 1.5, z: 0 };
  info.zhalf = hw + 0.5;
  return { x1, info };
};

T.plaza = (W, s, x0) => {
  const len = s.len || 36, hw = s.hw || 15, x1 = x0 + len, rng = W.rng, cx = x0 + len / 2;
  W.floor(x0, -hw, x1, hw, 0, 'paving', { collide: false });
  for (let i = 0; i < 6; i++) W.decal(x0 + len / 2, 0, len, 1.2, 'line', Math.PI / 2, 0.025, 0xaaaaaa);
  Props.fountain(W, cx, 0, 3.2);
  for (const a of [[-8, 7], [8, 7], [-8, -7], [8, -7]]) { Props.planter(W, cx + a[0] * 1.5, a[1], 3.4, 1.4); }
  for (let i = 0; i < 3; i++) { Props.tree(W, x0 + 6 + i * (len - 12) / 2, hw - 2.2, 1.1); Props.tree(W, x0 + 6 + i * (len - 12) / 2, -hw + 2.2, 1.1); }
  Props.kiosk(W, x0 + 7, 9, 0xd05a3a); Props.kiosk(W, x1 - 7, -9, 0x3a8ad0);
  for (let i = 0; i < 4; i++) Props.bench(W, x0 + 8 + i * 6, i % 2 ? 11.5 : -11.5, 'x');
  for (let x = x0 + 5; x < x1; x += 12) { Props.lampPost(W, x, hw - 0.6, 5.5, s.lampColor || 0xffd8a0, s.lamps !== false, -1); Props.lampPost(W, x + 6, -hw + 0.6, 5.5, s.lampColor || 0xffd8a0, s.lamps !== false, 1); }
  for (let i = 0; i < 4; i++) Props.car(W, x0 + 5 + i * 9, rng.sign() * (hw - 3), 'x', undefined, true);
  for (let i = 0; i < 3; i++) Props.stack(W, x0 + rng.range(5, len - 5), rng.range(-9, 9), 2);
  stains(W, x0, x1, hw, 6);
  facade(W, x0, x1, hw, { shops: true, mat: s.facade });
  W.area(x0 + 2, -hw + 1.5, x1 - 2, hw - 1.5, 0, 'main');
  return { x1, info: { x0, x1, hw, entry: { x: x0 + 2, z: 0 }, exit: { x: x1 - 2, z: 0 }, zhalf: hw + 0.5 } };
};

T.alley = (W, s, x0) => {
  const len = s.len || 34, hw = s.hw || 3.4, x1 = x0 + len, rng = W.rng;
  W.floor(x0, -hw, x1, hw, 0, 'asphalt', { collide: false });
  W.decal((x0 + x1) / 2, 0, 1.6, len, 'stain', 0, 0.026);
  stains(W, x0, x1, hw, Math.floor(len / 5));
  facade(W, x0, x1, hw, { mat: 'brick', h: 14, shops: false });
  // brick alley walls (inner faces) already by facade. fire escape on north wall with stairs
  const fx = x0 + len * 0.4, fw = 9, run = 6 * 0.7;
  W.stairs(fx, hw - 0.8, '+x', 1.6, 2.7, 6, 'metal', { tread: 0.7, base: 0 });
  W.floor(fx + run, hw - 1.6, fx + run + fw, hw, 2.7, 'metal'); // fire-escape platform
  W.box(fx + run, 2.7, hw - 1.6, fx + run + fw, 3.6, hw - 1.5, { plain: 0x3a3f48, metal: 0.6 }, { c: { y0: 2.7, y1: 3.6, ceil: false } });
  for (let i = 0; i < Math.floor(len / 9); i++) Props.dumpster(W, x0 + 5 + i * 9 + rng.range(0, 3), rng.sign() * (hw - 0.9), 'x');
  for (let i = 0; i < Math.floor(len / 6); i++) Props.crate(W, x0 + rng.range(3, len - 3), rng.sign() * (hw - 0.7), rng.range(0.8, 1.2), 0);
  Props.stack(W, x0 + 8, -hw + 0.8, 2); Props.stack(W, x0 + len * 0.75, hw - 0.8, 2);
  // laundry line & lamps
  for (let x = x0 + 5; x < x1 - 2; x += 9) { W.box(x - 0.02, 3.4, -hw, x + 0.02, 3.44, hw, { plain: 0x888888 }, { collide: false }); W.box(x, 2.6, -1, x + 1.0, 3.4, -0.9, { plain: rng.pick([0xe0e0e0, 0xd05a5a, 0x5a8ad0]), rough: 1 }, { collide: false }); }
  for (let x = x0 + 4; x < x1 - 2; x += 11) W.lamp(x, 3.8, 0, 0xffb060, 6, 11, { flicker: 0.3 }), W.box(x - 0.2, 3.7, hw - 0.3, x + 0.2, 4.0, hw, { glow: 0xffb060 }, { collide: false });
  Props.vent(W, x0 + len * 0.7, -hw + 0.9);
  W.area(x0 + 2, -hw + 1, x1 - 2, hw - 1, 0, 'main');
  W.area(fx + run + 1, hw - 1.4, fx + run + fw - 0.5, hw - 0.4, 2.7, 'upper');
  return { x1, info: { x0, x1, hw, entry: { x: x0 + 1.5, z: 0 }, exit: { x: x1 - 1.5, z: 0 }, zhalf: hw + 0.5, slots: { special: [{ x: fx + run + fw - 1.4, z: hw - 0.8, y: 2.7 }] } } };
};

T.yard = (W, s, x0) => {
  const len = s.len || 50, hw = s.hw || 13, x1 = x0 + len, rng = W.rng;
  W.floor(x0, -hw, x1, hw, 0, 'concrete', { collide: false });
  for (let x = x0 + 4; x < x1; x += 10) W.decal(x, 0, 0.4, hw * 2, 'yline', 0, 0.025);
  stains(W, x0, x1, hw, Math.floor(len / 6));
  facade(W, x0, x1, hw, { mat: 'metal', h: 11, shops: false });
  // slalom container clusters
  const cols = [0xc0392b, 0x2e6db0, 0x2e8b57, 0xd68910, 0x7a4aa0, 0x5a6470];
  let k = 0;
  for (let x = x0 + 9; x < x1 - 8; x += 11, k++) {
    const gapNorth = k % 2 === 0; const zStart = gapNorth ? -hw + 1.6 : hw - 1.6; const dir = gapNorth ? 1 : -1;
    const n = Math.floor((hw * 2 - 7) / 2.6);
    for (let i = 0; i < n; i++) { const z = zStart + dir * i * 2.6; Props.container(W, x, z, 'z', rng.pick(cols), 0); if (rng.chance(0.3)) Props.container(W, x, z, 'z', rng.pick(cols), 2.6); }
    if (rng.chance(0.7)) Props.forklift(W, x + 5.5, dir * -hw * 0.5, 'x');
  }
  for (let i = 0; i < 6; i++) Props.pallet(W, x0 + rng.range(4, len - 4), rng.range(-hw + 2, hw - 2));
  for (let x = x0 + 6; x < x1; x += 14) { Props.lampPost(W, x, hw - 0.5, 7, 0xffe0b0, s.lamps !== false, -1); Props.lampPost(W, x + 7, -hw + 0.5, 7, 0xffe0b0, s.lamps !== false, 1); }
  Props.fence(W, x0, -hw + 0.3, x1, -hw + 0.3); Props.fence(W, x0, hw - 0.3, x1, hw - 0.3);
  W.area(x0 + 2, -hw + 1, x1 - 2, hw - 1, 0, 'main');
  return { x1, info: { x0, x1, hw, entry: { x: x0 + 2, z: 0 }, exit: { x: x1 - 2, z: 0 }, zhalf: hw + 0.5 } };
};

T.lot = (W, s, x0) => {
  const len = s.len || 44, hw = s.hw || 12, x1 = x0 + len, rng = W.rng;
  W.floor(x0, -hw, x1, hw, 0, 'asphalt', { collide: false });
  for (let x = x0 + 3; x < x1 - 3; x += 3.4) for (const sd of [-1, 1]) W.decal(x, sd * (hw - 3), 0.15, 5, 'line', 0, 0.028);
  facade(W, x0, x1, hw, { shops: false, h: 18 });
  let k = 0;
  for (let x = x0 + 8; x < x1 - 8; x += 11, k++) { // car rows with alternating gaps (guaranteed lane)
    const gapN = k % 2 === 0; for (let z = -hw + 2; z <= hw - 2; z += 3.5) { if (gapN ? z > hw - 5 : z < -hw + 5) continue; if (rng.chance(0.78)) Props.car(W, x, z, 'z', undefined, rng.chance(0.35)); }
  }
  for (let x = x0 + 6; x < x1; x += 13) { Props.lampPost(W, x, hw - 0.5, 7, 0xe8f0ff, s.lamps !== false, -1); }
  for (let i = 0; i < 3; i++) Props.barrier(W, x0 + rng.range(5, len - 5), rng.range(-6, 6), 3, rng.chance(0.5) ? 'x' : 'z');
  stains(W, x0, x1, hw, 8);
  W.area(x0 + 2, -hw + 1, x1 - 2, hw - 1, 0, 'main');
  return { x1, info: { x0, x1, hw, entry: { x: x0 + 2, z: 0 }, exit: { x: x1 - 2, z: 0 }, zhalf: hw + 0.5 } };
};

// ---------------------------------------------------------------- underground
T.tunnel = (W, s, x0) => {
  const len = s.len || 44, hw = s.hw || 6.6, H = 6.2, x1 = x0 + len, rng = W.rng, th = 1.2;
  const hide = [];
  W.floor(x0, -hw, x1, hw, 0, 'concrete', { collide: false });
  W.box(x0, 0, hw, x1, H, hw + th, 'tunnel');
  const sw = W.box(x0, 0, -hw - th, x1, H, -hw, 'tunnel', { fade: true, hideIn: true }); hide.push(sw.mesh);
  const roof = W.box(x0, H, -hw - th, x1, H + 1, hw + th, 'tunnel', { hideIn: true, collide: false }); hide.push(roof.mesh);
  // rails + sleepers
  for (const z of [-1.5, 1.5]) W.box(x0, 0.0, z - 0.06, x1, 0.18, z + 0.06, { plain: 0x777d86, metal: 0.8 }, { collide: false });
  for (let x = x0 + 1; x < x1; x += 1.6) W.box(x - 0.14, 0, -2.0, x + 0.14, 0.1, 2.0, { plain: 0x5a4a38, rough: 1 }, { collide: false });
  // raised platform (north side)
  const py = 1.1, pz0 = 3.4;
  W.floor(x0 + 6, pz0, x1 - 6, hw, py, 'paving');
  W.stairs(x0 + 6, pz0 + 1.2, '-x', 2.4, py, 3, 'concrete', { tread: 0.6 }); W.stairs(x1 - 6, pz0 + 1.2, '+x', 2.4, py, 3, 'concrete', { tread: 0.6 });
  for (let x = x0 + 12; x < x1 - 8; x += 8) Props.pillar(W, x, pz0 + 0.3, 0.9, H, 'concrete');
  W.box(x0 + 6, py, pz0 - 0.05, x1 - 6, py + 0.1, pz0 + 0.05, { plain: 0xf2c230 }, { collide: false });
  // train wreck obstacles
  const nTrains = s.trains ?? 1;
  for (let i = 0; i < nTrains; i++) Props.trainCar(W, x0 + len * (0.3 + 0.35 * i), -0.2, 11, rng.pick([0x5a6a80, 0x80605a, 0x5a8060]));
  for (let i = 0; i < 3; i++) Props.rubble(W, x0 + rng.range(5, len - 5), rng.range(-hw + 1.5, -2.5));
  stains(W, x0, x1, hw, 8);
  for (let x = x0 + 5; x < x1; x += 9) { W.lamp(x, H - 0.8, 0, s.alarm ? 0xff5040 : 0xbfe8ff, 6, 16, { flicker: 0.4 }); W.box(x - 0.8, H - 0.12, -0.1, x + 0.8, H, 0.1, { glow: s.alarm ? 0xff5040 : 0xdff4ff }, { collide: false }); }
  const zone = W.zone({ x0, x1, z0: -hw, z1: hw, hide, mood: { sun: 0.15, hemi: 0.9 }, cam: { dist: 9, pitch: 0.78 } });
  W.area(x0 + 2, -hw + 1, x1 - 2, -2.8, 0, 'main'); W.area(x0 + 6, pz0 + 0.8, x1 - 6, hw - 0.6, py, 'upper');
  W.route.push({ x: x0 + 1, z: -4, y: 0 });
  return { x1, info: { x0, x1, hw, entry: { x: x0 + 1.5, z: -3 }, exit: { x: x1 - 1.5, z: -3 }, zhalf: hw + 0.5, zone, slots: { special: [{ x: x0 + len * 0.5, z: hw - 1, y: py }] } } };
};

T.sewer = (W, s, x0) => {
  const len = s.len || 44, hw = 5.4, H = 5.2, x1 = x0 + len, rng = W.rng, th = 1.2, cw = 1.7;
  const hide = [];
  W.floor(x0, -hw, x1, -cw, 0.4, 'concrete'); W.floor(x0, cw, x1, hw, 0.4, 'concrete');
  W.floor(x0, -cw, x1, cw, -0.7, 'tunnel');
  W.box(x0, -0.69, -cw, x1, -0.5, cw, { glow: 0x58b030, o: { transparent: true, opacity: 0.85 } }, { collide: false });
  W.decal((x0 + x1) / 2, 0, 3, len, 'sludge', Math.PI / 2, -0.45);
  W.hazard({ type: 'sludge', x0, x1, z0: -cw, z1: cw, y: -0.7, dps: 6, slow: 0.55 });
  const sw = W.box(x0, -1, -hw - th, x1, H, -hw, ['tunnel', 0x88a890], { fade: true, hideIn: true }); hide.push(sw.mesh);
  W.box(x0, -1, hw, x1, H, hw + th, ['tunnel', 0x88a890]);
  const roof = W.box(x0, H, -hw - th, x1, H + 1, hw + th, 'tunnel', { hideIn: true, collide: false }); hide.push(roof.mesh);
  for (let x = x0 + 10; x < x1 - 6; x += 12) W.floor(x - 1.2, -cw, x + 1.2, cw, 0.4, 'metal'); // footbridges
  { let a = x0; const bx = []; for (let x = x0 + 10; x < x1 - 6; x += 12) bx.push(x); // AI avoids the sludge channel except on footbridges
    for (const x of bx) { if (x - 1.2 > a) W.navBlocks.push({ x0: a, x1: x - 1.2, z0: -cw + 0.3, z1: cw - 0.3 }); a = x + 1.2; } if (x1 > a) W.navBlocks.push({ x0: a, x1: x1, z0: -cw + 0.3, z1: cw - 0.3 }); }
  for (let x = x0 + 4; x < x1; x += 8) { Props.pipe(W, x, 3.6, hw - 0.5, x, hw - 0.5, 0.2); W.geo(new THREE.CylinderGeometry(0.2, 0.2, hw * 2 - 1, 8), { plain: 0x4a5a50, metal: 0.7, rough: 0.5 }, x, 4.2, 0, Math.PI / 2, 0, 0); }
  for (let x = x0 + 6; x < x1 - 3; x += 14) { const z = rng.sign() * 3.2; const g = { type: 'gas', x, z, r: 2.4, period: 7, onFor: 3, phase: rng.range(0, 7), dps: 9, y: 0.4 }; W.hazard(g); W.decal(x, z, 1.5, 1.5, 'stain', 0, 0.43); }
  for (let i = 0; i < 4; i++) Props.barrel(W, x0 + rng.range(4, len - 4), (rng.sign() > 0 ? 1 : -1) * (hw - 0.7), 0x4a6a3a);
  for (let x = x0 + 5; x < x1; x += 10) { W.lamp(x, 3.8, 0, 0x7dff9a, 5.5, 14, { flicker: 0.5 }); W.box(x - 0.3, 3.6, hw - 0.1, x + 0.3, 4.0, hw, { glow: 0x7dff9a }, { collide: false }); }
  const zone = W.zone({ x0, x1, z0: -hw, z1: hw, hide, y0: -2, mood: { sun: 0.12, hemi: 0.9 }, cam: { dist: 8.5, pitch: 0.8 } });
  W.area(x0 + 2, -hw + 1, x1 - 2, -cw - 0.3, 0.4, 'main'); W.area(x0 + 2, cw + 0.3, x1 - 2, hw - 0.8, 0.4, 'room');
  return { x1, info: { x0, x1, hw, entry: { x: x0 + 1.5, z: -3.5, y: 0.4 }, exit: { x: x1 - 1.5, z: -3.5, y: 0.4 }, zhalf: hw + 0.5, zone, slots: { special: [{ x: x0 + len * 0.6, z: hw - 1, y: 0.4 }] } } };
};

// ---------------------------------------------------------------- rooftops / jumping
T.roofs = (W, s, x0) => {
  const len = s.len || 56, x1 = x0 + len, rng = W.rng;
  const N = Math.max(3, Math.round(len / 13));
  const gaps = []; for (let i = 0; i < N - 1; i++) gaps.push(rng.range(2.4, 3.5));
  const avgW = (len - gaps.reduce((a, b) => a + b, 0)) / N;
  let x = x0, cy = s.y0 ?? 0, zc = 0; const endY = s.endY; const yStep = endY !== undefined ? (endY - cy) / (N - 1) : 0; const asc = s.rise || 0;
  const platforms = [];
  for (let i = 0; i < N; i++) {
    const first = i === 0, last = i === N - 1;
    const w = last ? x1 - x : Math.max(6, avgW * rng.range(0.9, 1.1)), d = rng.range(11, 16);
    const xe = x + w, pz0 = zc - d / 2, pz1 = zc + d / 2;
    W.floor(x, pz0, xe, pz1, cy, 'roof', { th: 0.8 });
    W.box(x, cy - 14, pz0, xe, cy - 0.8, pz1, ['facade', rng.pick(FAC)], { collide: false });
    for (const sd of [pz0, pz1 - 0.3]) W.box(x, cy, sd, xe, cy + 0.9, sd + 0.3, 'concrete', { c: { y0: cy, y1: cy + 0.9 } });
    W.decal((x + xe) / 2, zc, (xe - x) - 1, d - 1, 'square', 0, cy + 0.03, 0x6a7078);
    if (!first && !last) {
      if (rng.chance(0.6)) Props.ac(W, x + rng.range(1.5, w - 1.5), cy, zc + rng.pick([-1, 1]) * rng.range(3, d / 2 - 1.8));
      if (rng.chance(0.5)) Props.antenna(W, x + rng.range(1, w - 1), zc + rng.pick([-1, 1]) * (d / 2 - 1.2), cy, rng.range(5, 9));
      if (rng.chance(0.5)) Props.crate(W, x + rng.range(1.2, w - 1.2), zc + rng.range(-3, 3), 1, cy);
    }
    platforms.push({ x0: x, x1: xe, z0: pz0, z1: pz1, y: cy });
    W.area(x + 0.8, pz0 + 0.8, xe - 0.8, pz1 - 0.8, cy, 'main');
    if (last) break;
    let dy = endY !== undefined ? yStep : (asc ? rng.range(0.6, 1.1) * asc : rng.pick([0, 0, 0.7, -0.7, 1.0, -1.0]));
    if (endY !== undefined && i === N - 2) cy = endY; else cy += dy;
    zc = Math.max(-4, Math.min(4, zc + rng.range(-3, 3)));
    x = xe + gaps[i];
    if (rng.chance(0.25) && Math.abs(dy) < 0.3) W.floor(xe - 0.2, zc - 0.9, x + 0.2, zc + 0.9, cy, 'wood', { th: 0.2 });
  }
  for (let xx = x0 + 6; xx < x1; xx += 16) W.lamp(xx, platforms[Math.min(platforms.length - 1, Math.floor((xx - x0) / len * N))].y + 6, 0, 0xffe6c0, 5, 22);
  W.noNav = true;
  for (const p of platforms) W.route.push({ x: (p.x0 + p.x1) / 2, z: (p.z0 + p.z1) / 2, y: p.y });
  const f0 = platforms[0], lp = platforms[platforms.length - 1];
  return { x1, info: { x0, x1, hw: 8, entry: { x: f0.x0 + 2, z: (f0.z0 + f0.z1) / 2, y: f0.y }, exit: { x: lp.x1 - 2, z: (lp.z0 + lp.z1) / 2, y: lp.y }, zhalf: 8, platforms, void: true } };
};

// ---------------------------------------------------------------- jump tower (extra mode): staircase of platforms with movers / crumblers / spinners / bounce pads
T.tower = (W, s, x0) => {
  const rng = W.rng, N = s.n || 12, hd = s.hard ?? 0; // hd: 0..1 difficulty
  const gapMin = 1.8 + hd * 0.8, gapMax = 2.4 + hd * 0.9, wMin = 4.6 - hd * 2.0, wMax = 6.4 - hd * 2.4;
  const TW = W.tower = { crumbles: [], spinners: [], pads: [], movers: [], platforms: [] };
  let x = x0, y = 0, zc = 0; const plats = [], cps = [];
  const matTop = ['metal', 0x8896a8];
  const addMesh = (x0_, y0_, z0_, x1_, y1_, z1_, color) => { const m = new THREE.Mesh(new THREE.BoxGeometry(x1_ - x0_, y1_ - y0_, z1_ - z0_), new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.35 })); m.castShadow = true; m.receiveShadow = true; W.group.add(m); return m; };
  const kinds = [];
  for (let i = 0; i < N; i++) {
    let kind = 'static'; const first = i === 0, last = i === N - 1;
    if (!first && !last) {
      const r = rng.next(), a = 0.10 + 0.20 * hd; // chance scale
      if (i > 1 && r < a) kind = 'mover'; else if (i > 1 && r < a * 2) kind = 'crumble'; else if (i > 2 && r < a * 2.8) kind = 'lift'; else if (i > 2 && r < a * 3.5) kind = 'spinner'; else if (i > 2 && r < a * 4.0) kind = 'pad';
      const pk = kinds[i - 1]; if (pk && ['mover', 'crumble', 'lift', 'pad'].includes(pk) && kind !== 'static' && kind !== 'spinner') kind = 'static'; // avoid unfair chains
    }
    kinds.push(kind);
  }
  for (let i = 0; i < N; i++) {
    const first = i === 0, last = i === N - 1, kind = kinds[i], nearMover = kind === 'mover' || kinds[i - 1] === 'mover' || kinds[i + 1] === 'mover';
    let w = first || last ? 8 : rng.range(wMin, wMax), d = first || last ? 10 : rng.range(4.4, 6.4);
    if (nearMover && kind !== 'mover') d = Math.max(d, 7.6); // wide enough to catch a jump from a sliding platform
    if (kind === 'spinner') { w = Math.max(w, 7.5); d = Math.max(d, 7.5); }
    if (kind === 'mover' || kind === 'lift') { w = Math.max(4, w); d = Math.max(3.8, d * 0.8); }
    if (kind === 'crumble') { w = Math.max(3.6, w * 0.85); }
    const xe = x + w, z0 = zc - d / 2, z1 = zc + d / 2, pl = { kind, x0: x, x1: xe, z0, z1, y, cx: (x + xe) / 2, cz: zc };
    if (kind === 'static' || kind === 'spinner' || kind === 'pad') {
      W.floor(x, z0, xe, z1, y, matTop, { th: 0.6 });
      W.decal((x + xe) / 2, zc, w - 0.8, d - 0.8, 'square', 0, y + 0.03, kind === 'pad' ? 0x3aff9a : kind === 'spinner' ? 0xff6a4a : 0x8ab4ff);
      W.box(x, y - 9, z0 + 0.2, xe, y - 0.6, z1 - 0.2, ['facade', 0x4a5262], { collide: false });
    }
    if (kind === 'pad') { const pr = { x0: pl.cx - 1.3, x1: pl.cx + 1.3, z0: zc - 1.3, z1: zc + 1.3, y }; TW.pads.push(pr); W.geo(new THREE.CylinderGeometry(1.25, 1.4, 0.22, 20), { glow: 0x3aff9a }, pl.cx, y + 0.12, zc); W.lamp(pl.cx, y + 2, zc, 0x3aff9a, 4, 8); }
    if (kind === 'spinner') {
      const bar = addMesh(-3.2, 0, -0.17, 3.2, 0.34, 0.17, 0xff5a3a); const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.5, 1.0, 10), new THREE.MeshStandardMaterial({ color: 0x3a3f4a, metalness: 0.7, roughness: 0.4 })); hub.position.set(pl.cx, y + 0.5, zc); W.group.add(hub);
      const sp = { x: pl.cx, z: zc, y, len: 3.2, spd: (rng.chance(0.5) ? 1 : -1) * (1.3 + hd * 1.0), a: rng.range(0, 6.28), bar, cd: 0 }; bar.position.set(sp.x, y + 0.75, sp.z); TW.spinners.push(sp);
      const glow = new THREE.Mesh(new THREE.CylinderGeometry(3.3, 3.3, 0.04, 28, 1, true), new THREE.MeshBasicMaterial({ color: 0xff5a3a, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); glow.position.set(sp.x, y + 0.75, sp.z); W.group.add(glow);
    }
    if (kind === 'crumble') {
      const mesh = addMesh(x, y - 0.5, z0, xe, y, z1, 0xc8a070); mesh.position.set((x + xe) / 2, y - 0.25, zc);
      const col = W.addCollider({ x0: x, x1: xe, z0, z1, y0: y - 0.5, y1: y }); const cr = { col, mesh, t: 0, state: 'idle', y, base: mesh.position.y }; TW.crumbles.push(cr);
      for (let k = 0; k < 3; k++) { const crack = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.02, d * 0.8), new THREE.MeshBasicMaterial({ color: 0x4a2a10 })); crack.position.set((k - 1) * w * 0.28, 0.26, 0); crack.rotation.y = (k - 1) * 0.15; mesh.add(crack); }
    }
    if (kind === 'mover' || kind === 'lift') {
      const mesh = addMesh(x, y - 0.5, z0, xe, y, z1, kind === 'mover' ? 0x6a8ac8 : 0x7ac8a0); const hw = w / 2, hz = d / 2;
      const amp = kind === 'mover' ? 1.8 + hd * 0.5 : 0.8 + hd * 0.3, spd = (kind === 'mover' ? 0.9 : 0.8) + hd * 0.35, ph = rng.range(0, 6.28);
      const by = y, bz = zc; // captured: y / zc keep changing as the loop advances
      const col = { x0: x, x1: xe, z0, z1, y0: y - 0.5, y1: y, mover: (t, m) => { const o = Math.sin(t * spd + ph) * amp; if (kind === 'mover') { m.z0 = bz - hz + o; m.z1 = bz + hz + o; m.y0 = by - 0.5; m.y1 = by; } else { m.z0 = bz - hz; m.z1 = bz + hz; m.y1 = by + o + amp; m.y0 = m.y1 - 0.5; } } };
      W.addCollider(col); col.mover(0, col); TW.movers.push(col);
      W.addAnim((t) => { mesh.position.set(pl.cx, (col.y0 + col.y1) / 2, (col.z0 + col.z1) / 2); });
      mesh.position.set(pl.cx, (col.y0 + col.y1) / 2, (col.z0 + col.z1) / 2);
      if (kind === 'lift') pl.y = y + amp; // top of the lift cycle is y + 2*amp; midpoint y + amp
    }
    plats.push(pl); TW.platforms.push(pl);
    if (i % 5 === 0 && i > 0 && kind === 'static') cps.push({ x: pl.cx, z: z0 + 1.0, y });
    W.area(x + 0.5, z0 + 0.5, xe - 0.5, z1 - 0.5, y, 'main');
    if (last) break;
    // next platform
    let gap = rng.range(gapMin, gapMax), rise = rng.range(0.4, 0.9 + 0.1 * hd);
    if (kind === 'pad') { rise = rng.range(3.4, 4.2); gap = rng.range(1.6, 2.4); }
    if (kind === 'lift') { rise = 0.4; }
    if (kind === 'crumble' || kind === 'mover') { gap = Math.min(gap, 2.7 + hd * 0.3); }
    if (i === N - 2) rise = Math.min(rise, 0.8);
    y += (kind === 'lift' ? plats[plats.length - 1].y - y : 0) + rise; // lift: next platform is above the lift's midpoint
    if (!nearMover) zc = Math.max(-5, Math.min(5, zc + rng.range(-2.4, 2.4)));
    x = xe + gap;
  }
  for (let i = 0; i < plats.length; i += 2) W.lamp(plats[i].cx, plats[i].y + 5, plats[i].cz + 3, i % 4 ? 0xffe6c0 : 0x9ad0ff, 5, 20);
  W.noNav = true;
  for (const p of plats) W.route.push({ x: p.cx, z: p.cz, y: p.y });
  const f0 = plats[0], lp = plats[plats.length - 1]; TW.top = lp.y;
  // summit beacon
  W.geo(new THREE.CylinderGeometry(0.25, 0.25, 12, 8), { glow: 0xffe94a }, lp.cx, lp.y + 6, lp.cz);
  return { x1: lp.x1 + 1, info: { x0, x1: lp.x1 + 1, hw: 8, entry: { x: f0.x0 + 2, z: f0.cz, y: f0.y }, exit: { x: lp.cx + 1, z: lp.cz, y: lp.y }, zhalf: 8, platforms: plats, void: true, cps } };
};

// ---------------------------------------------------------------- boss / locked arena
T.arena = (W, s, x0) => {
  const len = s.len || 46, hw = s.hw || 16, x1 = x0 + len, rng = W.rng;
  const th = s.theme || 'street';
  const floorMat = { street: 'asphalt', factory: 'metal', lab: 'tiles', sewer: 'concrete', roof: 'roof', final: 'tiles', tunnel: 'concrete' }[th] || 'concrete';
  W.floor(x0, -hw, x1, hw, 0, floorMat, { collide: !!W.void });
  W.decal((x0 + x1) / 2, 0, 30, 30, 'ring', 0, 0.03, s.ringColor || 0xff5a3a);
  facade(W, x0, x1, hw, { shops: false, mat: th === 'factory' ? 'metal' : undefined, h: th === 'roof' ? 6 : undefined });
  for (const sx of [x0 + 6, x1 - 6]) for (const z of [-hw + 3, hw - 3]) Props.pillar(W, sx, z, 1.8, 7, th === 'factory' ? 'metal' : 'concrete');
  for (let i = 0; i < 6; i++) { const x = x0 + rng.range(10, len - 10), z = rng.range(-hw + 4, hw - 4); if (Math.abs(z) < 5 && Math.abs(x - (x0 + len * 0.55)) < 8) continue; if (rng.chance(0.5)) Props.crate(W, x, z, 1.4, 0); else Props.barrier(W, x, z, 3, rng.chance(0.5) ? 'x' : 'z'); }
  for (let x = x0 + 8; x < x1; x += 14) for (const z of [-hw + 1, hw - 1]) { W.lamp(x, 7, z * 0.5, s.lightColor || 0xffc890, 7, 22, { flicker: 0.1 }); }
  stains(W, x0, x1, hw, 8);
  // gates
  const gw = Math.min(hw * 2 - 2, 7);
  const gateW = W.door({ x: x0 + 0.5, z: 0, axis: 'z', w: gw, h: 4.2, kind: 'gate', lock: 'arena_in', id: 'gateW', auto: false, open: true });
  const gateE = W.door({ x: x1 - 0.5, z: 0, axis: 'z', w: gw, h: 4.2, kind: 'gate', lock: s.exitLock || 'boss', id: 'gateE', auto: false });
  W.area(x0 + 4, -hw + 2, x1 - 4, hw - 2, 0, 'main');
  const boss = { x: x0 + len * 0.62, z: 0, y: 0 };
  return { x1, info: { x0, x1, hw, entry: { x: x0 + 3, z: 0 }, exit: { x: x1 - 3, z: 0 }, zhalf: hw + 0.5, gateW, gateE, bossSpot: boss, arena: true, theme: th } };
};

// ---------------------------------------------------------------- enterable buildings
function shell(W, s, x0, o = {}) {
  const len = s.len || 28, D = o.D || 11, H = o.H || 4.8, x1 = x0 + len, th = 0.5, rng = W.rng;
  const ext = s.ext || ['brick', rng.pick(BRICK)], flo = o.floor || 'concrete';
  const hide = [];
  W.floor(x0, -D, x1, D, 0, flo, { collide: false });
  const doorH = 3.1, dw = 2.9;
  const west = W.wall('z', x0 + th / 2, -D, D, 0, H, th, [{ c: 0, w: dw, h: doorH }], ext);
  const east = W.wall('z', x1 - th / 2, -D, D, 0, H, th, [{ c: 0, w: dw, h: doorH }], ext);
  W.wall('x', D - th / 2, x0, x1, 0, H, th, [], ext);
  const sw = W.wall('x', -D + th / 2, x0, x1, 0, H, th, [], ext, { fade: true, hideIn: true }); sw.forEach(r => hide.push(r.mesh));
  const roof = W.box(x0, H, -D, x1, H + 0.5, D, 'roof', { hideIn: true, collide: false }); hide.push(roof.mesh);
  const up = W.box(x0, H + 0.5, -D, x1, H + 0.5 + rng.range(6, 12), D, ['facade', rng.pick(FAC)], { hideIn: true, collide: false }); hide.push(up.mesh);
  const dW = W.door({ x: x0 + th / 2, z: 0, axis: 'z', w: dw, h: doorH, auto: true, color: 0x4a5a6a, id: (s.id || 'b') + '_in' });
  const dE = W.door({ x: x1 - th / 2, z: 0, axis: 'z', w: dw, h: doorH, auto: !s.exitLock, lock: s.exitLock || null, color: 0x4a5a6a, id: (s.id || 'b') + '_out' });
  facade(W, x0, x1, D, { shops: false });
  const zone = W.zone({ x0: x0 + 0.3, x1: x1 - 0.3, z0: -D + 0.3, z1: D - 0.3, hide, mood: o.mood || { sun: 0.3, hemi: 0.85 }, cam: o.cam || { dist: 9, pitch: 0.82 } });
  return { x0, x1, D, H, th, hide, zone, dW, dE, len };
}
function lightsLine(W, sh, color = 0xffe2b0, step = 8, rows = [0], inten = 7) {
  for (let x = sh.x0 + 4; x < sh.x1 - 2; x += step) for (const z of rows) { W.lamp(x, sh.H - 0.8, z, color, inten, 14, { flicker: 0.05 }); }
}
function wallLights(W, sh, color = 0xfff0d0, step = 6) { for (let x = sh.x0 + 3; x < sh.x1 - 2; x += step) W.box(x - 0.4, 2.8, sh.D - sh.th, x + 0.4, 3.1, sh.D - sh.th + 0.06, { glow: color }, { collide: false }); }
function seg(W, s, sh, extra = {}) { // common return
  return { x1: sh.x1, info: Object.assign({ x0: sh.x0, x1: sh.x1, hw: sh.D, entry: { x: sh.x0 + 1.8, z: 0 }, exit: { x: sh.x1 - 1.8, z: 0 }, zhalf: sh.D, zone: sh.zone, doors: { in: sh.dW, out: sh.dE }, building: true }, extra) };
}

const B = {};
B.shop = (W, s, x0) => {
  const sh = shell(W, s, x0, { floor: 'tiles' }), rng = W.rng, D = sh.D;
  const X = (i) => x0 + i;
  for (const z of [-7, 7]) for (let i = 0; i < 3; i++) Props.shelf(W, X(7 + i * 6.4), z, 4.6, 'x', rng.pick([0x6a7480, 0x8a6a4a]));
  Props.counter(W, X(5), 4.2, 3.2, 'x'); Props.counter(W, X(5), -4.2, 3.2, 'x');
  // back room (north) with door
  const bz = 7.2, bx0 = X(sh.len - 12), bx1 = X(sh.len - 1.5);
  W.wall('x', bz, bx0, bx1, 0, sh.H, 0.3, [{ c: (bx0 + bx1) / 2, w: 2.2, h: 2.8 }], ['plaster', 0xcfc4b0]);
  W.door({ x: (bx0 + bx1) / 2, z: bz, axis: 'x', w: 2.2, h: 2.8, auto: true, color: 0x7a5a3a });
  Props.stack(W, bx0 + 1.5, D - 1.4, 2); Props.crate(W, bx1 - 1.5, D - 1.4, 1.1); Props.shelf(W, (bx0 + bx1) / 2, D - 0.9, 5, 'x');
  Props.stack(W, X(12), 2.2, 1, 0.9);
  lightsLine(W, sh, 0xfff0d0, 8, [-5, 5]); wallLights(W, sh);
  W.area(X(2), -D + 1, X(sh.len - 2), 5.8, 0, 'main'); W.area(bx0 + 0.6, bz + 0.6, bx1 - 0.6, D - 0.6, 0, 'room');
  return seg(W, s, sh, { slots: { special: [{ x: (bx0 + bx1) / 2 + 1.5, z: D - 1.2, y: 0 }] } });
};
B.apartment = (W, s, x0) => {
  s.len = s.len || 34; const sh = shell(W, s, x0, { floor: 'wood' }), rng = W.rng, D = sh.D, H = sh.H;
  const X = (i) => x0 + i, wall = ['plaster', 0xd8cfc0];
  const roomW = (sh.len - 3) / 4, areas = [];
  for (const sd of [-1, 1]) {
    const gaps = []; for (let i = 0; i < 4; i++) gaps.push({ c: X(1.5 + roomW * (i + 0.5)), w: 2.2, h: 2.8 });
    const segs = W.wall('x', sd * 2.2, X(0.6), X(sh.len - 0.6), 0, H, 0.3, gaps, wall, { fade: sd < 0 });
    for (let i = 0; i < 4; i++) { W.door({ x: X(1.5 + roomW * (i + 0.5)), z: sd * 2.2, axis: 'x', w: 2.2, h: 2.8, auto: true, color: rng.pick([0x7a5a3a, 0x5a6a7a, 0x6a4a4a]) }); }
    for (let i = 1; i < 4; i++) W.wall('z', X(1.5 + roomW * i), sd > 0 ? 2.2 : -D + 0.5, sd > 0 ? D - 0.5 : -2.2, 0, H, 0.3, [], wall, { fade: sd < 0 });
    for (let i = 0; i < 4; i++) {
      const rx = X(1.5 + roomW * i), cx = rx + roomW / 2, cz = sd * 6.4;
      const kind = (i + (sd > 0 ? 1 : 0)) % 4;
      if (kind === 0) { Props.bed(W, cx - 1.2, cz + sd * 2.5, 'x'); Props.table(W, cx + 1.6, cz - sd * 1.5, 1.2, 0.8); }
      else if (kind === 1) { Props.sofa(W, cx, cz + sd * 3, 'x'); Props.table(W, cx, cz, 1.4, 0.8); }
      else if (kind === 2) { Props.shelf(W, cx, cz + sd * 3.6, 3, 'x', 0x7a5a3a); Props.crate(W, cx - 1.6, cz - sd * 1.5, 0.9); }
      else { Props.bed(W, cx + 1.1, cz + sd * 2.6, 'x'); Props.locker(W, cx - 1.8, cz + sd * 3.8, 2, 'x'); }
      areas.push(W.area(rx + 0.9, sd > 0 ? 2.9 : -D + 1.0, rx + roomW - 0.9, sd > 0 ? D - 1.0 : -2.9, 0, 'room'));
      W.lamp(cx, H - 0.7, cz, 0xffd9a0, 5.5, 9, { flicker: 0.06 });
    }
  }
  for (let x = sh.x0 + 4; x < sh.x1 - 2; x += 8) W.lamp(x, H - 0.7, 0, 0xfff0d0, 6, 11, { flicker: 0.08 });
  W.decal(x0 + sh.len / 2, 0, 3.2, sh.len - 4, 'stain', Math.PI / 2, 0.03);
  W.area(X(1.5), -1.8, X(sh.len - 1.5), 1.8, 0, 'main');
  return seg(W, s, sh, { slots: { special: areas.map(a => ({ x: (a.x0 + a.x1) / 2, z: a.z1 > 0 ? a.z1 - 0.8 : a.z0 + 0.8, y: 0 })) } });
};
B.warehouse = (W, s, x0) => {
  s.len = s.len || 40; const sh = shell(W, s, x0, { floor: 'concrete', D: 12, H: 6.2, cam: { dist: 11, pitch: 0.85 }, mood: { sun: 0.35, hemi: 0.85 } });
  const rng = W.rng, D = 12, X = (i) => x0 + i;
  // racks forming aisles: 2 rows each side leaving lane |z|<2.8
  for (const sd of [-1, 1]) for (let i = 0; i < 4; i++) { Props.rack(W, X(7 + i * 8.5), sd * 5.2, 5.2, 'x'); if (i < 3) Props.crate(W, X(11.4 + i * 8.5), sd * 3.3, 1.0); }
  Props.forklift(W, X(sh.len * 0.5), -2.8, 'x'); Props.container(W, X(sh.len - 5), D - 2.0, 'x', 0x2e6db0); Props.stack(W, X(5), -3.3, 3, 1.0);
  // mezzanine with stairs (north), switch on top
  const my = 3.2, mx0 = X(12), mx1 = X(sh.len - 8), mz0 = 7.8, mz1 = D - 0.5;
  W.floor(mx0, mz0, mx1, mz1, my, 'metal', { th: 0.4 });
  W.box(mx0, my, mz0, mx1, my + 1.0, mz0 + 0.1, { plain: 0xd18a1f, metal: 0.4 }, { c: { y0: my, y1: my + 1.0 } });
  W.stairs(mx0 - 0.0, mz1 - 1.2, '-x', 2.2, my, 7, 'metal', { tread: 0.62 });
  for (let x = mx0 + 2; x < mx1; x += 5) W.box(x - 0.2, 0, mz0, x + 0.2, my - 0.4, mz0 + 0.4, { plain: 0x4a4f58, metal: 0.6 }, { c: { ceil: false } });
  Props.fan(W, X(sh.len / 2), 5.7, 0, 'z', 2.0);
  lightsLine(W, sh, 0xfff0c0, 9, [-6, 6], 8); wallLights(W, sh, 0xffe6b0, 8);
  W.area(X(2), -3.4, X(sh.len - 2), 3.4, 0, 'main'); W.area(X(3), -D + 0.8, X(sh.len - 3), -6.3, 0, 'room'); W.area(mx0 + 1, mz0 + 1, mx1 - 1, mz1 - 0.5, my, 'upper');
  return seg(W, s, sh, { slots: { special: [{ x: mx1 - 2, z: D - 1.6, y: my }, { x: mx0 + 3, z: D - 1.6, y: my }] } });
};
B.lab = (W, s, x0) => {
  s.len = s.len || 38; const sh = shell(W, s, x0, { floor: 'tiles', mood: { sun: 0.28, hemi: 1.0 }, D: 11, H: 4.8 });
  const rng = W.rng, D = 11, X = (i) => x0 + i, H = sh.H;
  const lw = ['labwall'];
  // inner partitions with sliding doors dividing lobby / chambers / lab
  const cuts = [X(10), X(sh.len * 0.56)];
  cuts.forEach((cx, i) => { W.wall('z', cx, -D + 0.5, D - 0.5, 0, H, 0.35, [{ c: 0, w: 3.0, h: 3.0 }], lw, { fade: true }); W.door({ x: cx, z: 0, axis: 'z', w: 3.0, h: 3.0, kind: 'slide', lock: i === 0 ? null : (s.innerLock || null), auto: !s.innerLock || i === 0, mat: { plain: 0xdfe6ec, metal: 0.5 }, id: 'labd' + i }); });
  // glass observation walls
  for (const sd of [-1, 1]) { const a = X(10) + 0.2, b = cuts[1] - 0.2, m = a + (b - a) * (sd < 0 ? 0.35 : 0.65); for (const [u, v] of [[a, m - 1.5], [m + 1.5, b]]) W.box(u, 0, sd * 3.2 - 0.05, v, 3.0, sd * 3.2 + 0.05, { glass: 0x9fe0ff, op: 0.22 }, { c: { los: false } }); }
  // lobby
  Props.console(W, X(4), -6, 'x'); Props.console(W, X(4), 6.5, 'x'); Props.sofa(W, X(2.6), 8.5, 'x'); W.box(X(1), 0, -D + 0.6, X(3.2), 2.2, -D + 1.2, { plain: 0xdfe6ec }, { c: { y1: 2.2 } });
  // chambers with tubes
  for (let i = 0; i < 5; i++) Props.tube(W, X(14 + i * 3.4), (i % 2 ? 1 : -1) * 7.2, 2.7, rng.pick([0x6aff8a, 0x6ad0ff, 0xff6ab0]));
  for (let i = 0; i < 4; i++) Props.server(W, cuts[1] + 3 + i * 1.3, D - 1.2, 'x');
  Props.console(W, cuts[1] + 4, -5.5, 'x'); Props.console(W, cuts[1] + 4, 5.5, 'x'); Props.console(W, cuts[1] + 9, 0, 'z');
  Props.locker(W, X(sh.len - 2.5), -7, 4, 'z');
  lightsLine(W, sh, 0xdff0ff, 8, [-5, 5], 8); wallLights(W, sh, 0xdff4ff, 5);
  W.area(X(1.5), -D + 1, X(9), D - 1, 0, 'main'); W.area(X(11.5), -D + 1, cuts[1] - 1.5, D - 1, 0, 'room'); W.area(cuts[1] + 1.5, -D + 1, X(sh.len - 1.5), D - 1, 0, 'room');
  return seg(W, s, sh, { slots: { special: [{ x: cuts[1] + 6, z: D - 1.4, y: 0 }, { x: X(15), z: -D + 1.4, y: 0 }, { x: X(sh.len - 3), z: 8, y: 0 }] } });
};
B.office = (W, s, x0) => {
  s.len = s.len || 30; const sh = shell(W, s, x0, { floor: 'carpet' }), rng = W.rng, D = 11, X = (i) => x0 + i;
  // cubicle rows (low partitions)
  for (const sd of [-1, 1]) for (let i = 0; i < 3; i++) { const cx = X(6 + i * 6); W.box(cx - 2.3, 0, sd * 5.2 - 0.07, cx + 2.3, 1.3, sd * 5.2 + 0.07, { plain: 0x6a7a8a, rough: 1 }, { c: { y1: 1.3, los: false } }); W.box(cx - 2.3, 0, sd * 5.2, cx - 2.16, 1.3, sd * 8.6, { plain: 0x6a7a8a, rough: 1 }, { c: { y1: 1.3, los: false } }); Props.desk(W, cx, sd * 7.4, 'x'); }
  // server room (north east) with door
  const sx0 = X(sh.len - 9), bz = 6.6;
  W.wall('x', bz, sx0, X(sh.len - 0.5), 0, sh.H, 0.3, [{ c: sx0 + 2, w: 2.2, h: 2.8 }], 'concrete'); W.wall('z', sx0, bz, D - 0.5, 0, sh.H, 0.3, [], 'concrete');
  W.door({ x: sx0 + 2, z: bz, axis: 'x', w: 2.2, h: 2.8, auto: true, color: 0x3a4a5a });
  for (let i = 0; i < 5; i++) Props.server(W, sx0 + 2.5 + i * 1.2, D - 1.2, 'x');
  Props.table(W, X(4), 0 + 0, 0.01, 0.01);
  lightsLine(W, sh, 0xeaf2ff, 8, [-5, 5], 7);
  W.area(X(2), -3.5, X(sh.len - 2), 3.5, 0, 'main'); W.area(X(3), -D + 1, X(sh.len - 3), -4.2, 0, 'room'); W.area(sx0 + 1, bz + 1, X(sh.len - 1.5), D - 1, 0, 'room');
  return seg(W, s, sh, { slots: { special: [{ x: sx0 + 4, z: D - 1.4, y: 0 }, { x: X(10), z: -D + 1.5, y: 0 }] } });
};
B.mall = (W, s, x0) => {
  s.len = s.len || 40; const sh = shell(W, s, x0, { floor: 'tiles', D: 12, H: 6.4, cam: { dist: 11, pitch: 0.85 } }), rng = W.rng, D = 12, X = (i) => x0 + i, H = 6.4;
  Props.fountain(W, X(sh.len / 2), 0, 2.0);
  // storefronts: glass fronts along z=±8 with openings
  for (const sd of [-1, 1]) for (let i = 0; i < 3; i++) {
    const cx = X(6 + i * 11);
    W.wall('x', sd * 8, cx - 4.5, cx + 4.5, 0, 3.8, 0.2, [{ c: cx, w: 3.2, h: 3.0 }], { glass: 0xaae0ff, op: 0.25 }, { fade: sd < 0 });
    W.box(cx - 4.5, 3.8, sd * 8 - 0.2, cx + 4.5, 4.6, sd * 8 + 0.2, { glow: rng.pick([0xff7a9a, 0x7ad0ff, 0xffd27a]) }, { collide: false });
    Props.shelf(W, cx, sd * (D - 1.2), 6, 'x', rng.pick([0x6a7480, 0x8a6a4a])); Props.counter(W, cx, sd * 9.8, 3, 'x');
  }
  // upper gallery (north) with stairs
  const gy = 3.4; W.floor(X(4), 8.2, X(sh.len - 4), D - 0.5, gy, 'tiles', { th: 0.4 }); W.box(X(4), gy, 8.2, X(sh.len - 4), gy + 1.0, 8.32, { glass: 0x9fe0ff, op: 0.3 }, { c: { y0: gy, y1: gy + 1.0 } });
  W.stairs(X(4), 10.4, '-x', 2.2, gy, 7, 'tiles', { tread: 0.6 });
  for (let i = 0; i < 4; i++) Props.planter(W, X(9 + i * 7.5), 4.0 * (i % 2 ? 1 : -1), 2.6, 1.2);
  lightsLine(W, sh, 0xfff4e0, 9, [-6, 0, 6], 7);
  W.area(X(2), -7, X(sh.len - 2), 7, 0, 'main'); W.area(X(3), 9, X(sh.len - 3), D - 1, 0, 'room'); W.area(X(5), 8.8, X(sh.len - 5), D - 1, gy, 'upper');
  return seg(W, s, sh, { slots: { special: [{ x: X(sh.len - 6), z: D - 1.5, y: gy }, { x: X(sh.len - 8), z: -D + 1.5, y: 0 }] } });
};
B.parking = (W, s, x0) => {
  s.len = s.len || 38; const sh = shell(W, s, x0, { floor: 'concrete', D: 12, H: 4.4, mood: { sun: 0.3, hemi: 0.8 } }), rng = W.rng, D = 12, X = (i) => x0 + i;
  for (let i = 0; i < 6; i++) for (const sd of [-1, 1]) Props.pillar(W, X(5 + i * 6), sd * 7, 0.9, sh.H, 'concrete');
  for (let i = 0; i < 5; i++) for (const sd of [-1, 1]) if (rng.chance(0.8)) Props.car(W, X(8 + i * 6), sd * 9.6, 'x', undefined, rng.chance(0.3));
  for (let x = sh.x0 + 3; x < sh.x1 - 2; x += 3.2) W.decal(x, -9.5, 0.15, 4.6, 'line', 0, 0.028);
  const gy = 3.2; W.floor(X(3), 5.0, X(14), D - 0.5, gy, 'concrete', { th: 0.4 });
  W.box(X(3), gy, 5.0, X(14), gy + 0.9, 5.15, 'concrete', { c: { y0: gy, y1: gy + 0.9 } });
  W.stairs(X(14), 10.0, '+x', 2.2, gy, 6, 'concrete', { tread: 0.6 });
  // ramp-like second deck sign
  Props.barrier(W, X(20), 1.5, 3, 'z'); Props.barrier(W, X(26), -2, 3, 'z');
  for (let x = sh.x0 + 4; x < sh.x1 - 2; x += 8) W.box(x - 0.8, sh.H - 0.1, -6, x + 0.8, sh.H, -5.9, { glow: 0xe8f0ff }, { collide: false }), W.lamp(x, sh.H - 0.7, -5, 0xe8f0ff, 6, 13, { flicker: 0.15 }), W.lamp(x, sh.H - 0.7, 5, 0xe8f0ff, 6, 13, { flicker: 0.15 });
  W.area(X(2), -5.5, X(sh.len - 2), 4, 0, 'main'); W.area(X(4), 5.6, X(13), D - 1, gy, 'upper'); W.area(X(2), -D + 1, X(sh.len - 2), -8.5, 0, 'room');
  return seg(W, s, sh, { slots: { special: [{ x: X(8), z: D - 1.4, y: gy }, { x: X(sh.len - 4), z: -D + 1.4, y: 0 }] } });
};
B.bunker = (W, s, x0) => { // security checkpoint complex: corridor with gated cells
  s.len = s.len || 36; const sh = shell(W, s, x0, { floor: 'concrete', D: 10, H: 4.4, mood: { sun: 0.25, hemi: 0.9 } }), rng = W.rng, D = 10, X = (i) => x0 + i, H = 4.4;
  const mat = ['tunnel', 0xaab4bc];
  for (let i = 1; i <= 2; i++) { const cx = X(sh.len * i / 3); W.wall('z', cx, -D + 0.5, D - 0.5, 0, H, 0.5, [{ c: 0, w: 3.0, h: 3.0 }], mat, { fade: true }); W.door({ x: cx, z: 0, axis: 'z', w: 3.0, h: 3.0, kind: 'gate', lock: s.innerLock ? s.innerLock + i : null, auto: !s.innerLock, id: 'sec' + i }); W.box(cx - 0.3, 0, -1.8, cx + 0.3, 1.0, -1.6, 'hazard', { collide: false }); }
  { // counters split into 3 sections (between the cross walls), each with a 2.6 m opening so side rooms are walkable for AI too
    const cuts = [2, sh.len / 3, sh.len * 2 / 3, sh.len - 2];
    for (const sd of [-1, 1]) for (let k = 0; k < 3; k++) {
      const a = cuts[k] + (k ? 0.4 : 0), b = cuts[k + 1] - (k < 2 ? 0.4 : 0), m = a + (b - a) * [0.72, 0.8, 0.5][k];
      for (const [u, v] of [[a, m - 1.3], [m + 1.3, b]]) W.box(X(u), 0, sd * 4 - 0.1, X(v), 1.1, sd * 4 + 0.1, ['concrete', 0xb0b8c0], { c: { y1: 1.1, los: false } });
    }
  }
  for (let i = 0; i < 4; i++) Props.locker(W, X(5 + i * 8), -D + 1.0, 3, 'x'), Props.server(W, X(5 + i * 8), D - 1.2, 'x');
  Props.barrier(W, X(sh.len * 0.17), 1.2, 3, 'z'); Props.barrier(W, X(sh.len * 0.5), -1.2, 3, 'z');
  // laser grid hazards
  if (s.lasers) for (let i = 0; i < s.lasers; i++) { const lx = X(5 + i * (sh.len - 10) / s.lasers) + 2; W.hazard({ type: 'laser', x: lx, z0: -D + 0.7, z1: D - 0.7, y: 0.6, period: 4.2, onFor: 2.2, phase: i * 1.3, dmg: 14, id: 'laser' + i }); }
  lightsLine(W, sh, 0xff9a80, 8, [-4, 4], 6); wallLights(W, sh, 0xffb090, 6);
  W.area(X(2), -3.4, X(sh.len - 2), 3.4, 0, 'main'); W.area(X(2), -D + 1, X(sh.len - 2), -4.6, 0, 'room'); W.area(X(2), 4.6, X(sh.len - 2), D - 1, 0, 'room');
  return seg(W, s, sh, { slots: { special: [{ x: X(sh.len - 4), z: D - 1.4, y: 0 }, { x: X(sh.len * 0.4), z: -D + 1.4, y: 0 }] } });
};
B.control = (W, s, x0) => { // command centre: wide room w/ consoles ring
  s.len = s.len || 34; const sh = shell(W, s, x0, { floor: 'tiles', D: 12, H: 6, mood: { sun: 0.25, hemi: 0.95 }, cam: { dist: 11, pitch: 0.85 } }), rng = W.rng, X = (i) => x0 + i;
  const cx = X(sh.len / 2);
  W.geo(new THREE.CylinderGeometry(3, 3, 0.25, 24), { plain: 0x20242c, metal: 0.6 }, cx, 0.12, 0); W.geo(new THREE.CylinderGeometry(2.7, 2.7, 0.05, 24), { glow: 0x3ad0ff }, cx, 0.27, 0);
  W.addCollider({ x0: cx - 3, x1: cx + 3, z0: -3, z1: 3, y0: 0, y1: 0.25 });
  for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; Props.console(W, cx + Math.cos(a) * 7, Math.sin(a) * 7.6, Math.abs(Math.cos(a)) > 0.7 ? 'z' : 'x'); }
  for (let i = 0; i < 4; i++) { W.box(X(3 + i * 8), 1.4, sh.D - 0.7, X(7 + i * 8), 4.6, sh.D - 0.5, { glow: [0x3a9aff, 0x3aff9a, 0xff7a3a, 0xc07aff][i] }, { collide: false }); }
  Props.pillar(W, X(8), 7.5, 1.0, sh.H, ['tunnel', 0x99a]); Props.pillar(W, X(sh.len - 8), -7.5, 1.0, sh.H, 'concrete');
  lightsLine(W, sh, 0xbfe8ff, 9, [-6, 6], 7);
  W.area(X(2), -sh.D + 1, X(sh.len - 2), sh.D - 1, 0, 'main');
  return seg(W, s, sh, { slots: { special: [{ x: X(6), z: -sh.D + 1.5, y: 0 }, { x: X(sh.len - 5), z: sh.D - 1.5, y: 0 }] } });
};

T.building = (W, s, x0) => (B[s.variant || 'shop'] || B.shop)(W, s, x0);
