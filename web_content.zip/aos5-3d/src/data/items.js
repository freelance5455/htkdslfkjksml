// Items: every item has real data used by combat (stats), the shop (price/unlock) and upgrades (cost/next).
// cat: melee | ranged | energy | special | temp
export const CATS = { melee: 'قتال قريب', ranged: 'بعيد المدى', energy: 'طاقة', special: 'خاص', temp: 'قدرة مؤقتة' };
export const RARITY = { common: { n: 'عادي', c: '#9aa4b0' }, rare: { n: 'نادر', c: '#4aa8ff' }, epic: { n: 'ملحمي', c: '#b36bff' }, legend: { n: 'أسطوري', c: '#ffb43a' } };
const up = (b) => (lv) => Math.round(b * (0.45 + 0.3 * lv * (1 + lv * 0.08)));
const sc = (v, lv, k = 0.17) => v * (1 + k * (lv - 1));

export const ITEMS = {
  // ---- melee ----
  pipe: { id: 'pipe', name: 'ماسورة الشارع', icon: '🔧', cat: 'melee', rarity: 'common', model: 'pipe', desc: 'سلاح البداية: متوازن وسريع.', price: 0, unlock: { type: 'start' }, base: 140,
    stats: (l) => ({ dmg: sc(13, l), rate: 1.0, reach: 2.4, arc: 2.0, knock: 5, combo: ['swingR', 'swingL', 'overhead'], dur: [0.42, 0.42, 0.6] }), nextDesc: 'ضرر +17%' },
  axe: { id: 'axe', name: 'فأس الإطفاء', icon: '🪓', cat: 'melee', rarity: 'common', model: 'axe', desc: 'ثقيل وقوي، ضربات علوية مدمّرة.', price: 350, unlock: { type: 'stage', n: 2 }, base: 300,
    stats: (l) => ({ dmg: sc(21, l), rate: 0.8, reach: 2.6, arc: 1.9, knock: 8, combo: ['overhead', 'swingR', 'overhead'], dur: [0.62, 0.5, 0.66] }), nextDesc: 'ضرر +17%' },
  blade: { id: 'blade', name: 'نصل الظل', icon: '🗡️', cat: 'melee', rarity: 'rare', model: 'blade', desc: 'سريع جدًا بسلسلة ثلاثية قاطعة.', price: 900, unlock: { type: 'stage', n: 5 }, base: 600,
    stats: (l) => ({ dmg: sc(16, l), rate: 1.4, reach: 2.6, arc: 2.1, knock: 4, combo: ['swingR', 'swingL', 'stab'], dur: [0.34, 0.34, 0.4] }), nextDesc: 'ضرر +17%' },
  sledge: { id: 'sledge', name: 'مطرقة الهدم', icon: '🔨', cat: 'melee', rarity: 'epic', model: 'sledge', desc: 'ضربات بطيئة تهزّ الأرض وتصيب محيطًا واسعًا.', price: 1600, unlock: { type: 'stage', n: 9 }, base: 1000,
    stats: (l) => ({ dmg: sc(36, l), rate: 0.6, reach: 2.7, arc: 2.4, knock: 13, aoe: 2.4, combo: ['overhead', 'slamGround'], dur: [0.7, 0.95] }), nextDesc: 'ضرر +17% ونطاق أوسع' },
  spear: { id: 'spear', name: 'رمح الشرر', icon: '🔱', cat: 'melee', rarity: 'legend', model: 'spear', desc: 'مدى طويل يخترق الصفوف.', price: 2400, unlock: { type: 'stage', n: 14 }, base: 1500,
    stats: (l) => ({ dmg: sc(24, l), rate: 1.0, reach: 3.8, arc: 1.0, knock: 6, pierce: true, combo: ['stab', 'stab', 'sweep'], dur: [0.4, 0.4, 0.6] }), nextDesc: 'ضرر +17%' },
  // ---- ranged ----
  sling: { id: 'sling', name: 'مقلاع', icon: '🪃', cat: 'ranged', rarity: 'common', model: 'sling', desc: 'قذائف حجرية خفيفة وبعيدة.', price: 250, unlock: { type: 'stage', n: 2 }, base: 200,
    stats: (l) => ({ dmg: sc(10, l), cd: 0.5, spd: 24, range: 24, spread: 0.02, n: 1, color: 0xd8c8a0, size: 0.13 }), nextDesc: 'ضرر +17%' },
  pistol: { id: 'pistol', name: 'مسدس الشرر', icon: '🔫', cat: 'ranged', rarity: 'rare', model: 'pistol', desc: 'طلقات شرارة سريعة (كرتونية).', price: 700, unlock: { type: 'stage', n: 4 }, base: 450,
    stats: (l) => ({ dmg: sc(8, l), cd: 0.22, spd: 32, range: 26, spread: 0.05, n: 1, color: 0xffd24a, size: 0.12 }), nextDesc: 'ضرر +17%' },
  scatter: { id: 'scatter', name: 'مدفع الرش', icon: '💥', cat: 'ranged', rarity: 'epic', model: 'scatter', desc: 'رشقة شرارات واسعة قريبة المدى.', price: 1500, unlock: { type: 'stage', n: 8 }, base: 900,
    stats: (l) => ({ dmg: sc(6.5, l), cd: 0.85, spd: 26, range: 13, spread: 0.32, n: 6, color: 0xff8a3a, size: 0.12 }), nextDesc: 'ضرر +17%' },
  arc: { id: 'arc', name: 'مدفع القوس', icon: '🛰️', cat: 'ranged', rarity: 'legend', model: 'arccannon', desc: 'شعاع طاقة يخترق الأعداء.', price: 2800, unlock: { type: 'stage', n: 13 }, base: 1700,
    stats: (l) => ({ dmg: sc(42, l), cd: 1.0, spd: 44, range: 34, spread: 0, n: 1, pierce: 4, color: 0x6ae0ff, size: 0.22 }), nextDesc: 'ضرر +17%' },
  // ---- energy (cost energy) ----
  orb: { id: 'orb', name: 'كرة الطاقة', icon: '🔮', cat: 'energy', rarity: 'rare', desc: 'كرة طاقة تنفجر عند الاصطدام.', price: 500, unlock: { type: 'plevel', n: 3 }, base: 400,
    stats: (l) => ({ kind: 'orb', cost: 24, dmg: sc(32, l), radius: 2.6, cd: 1.1, spd: 15, color: 0x6ab8ff }), nextDesc: 'ضرر +17%' },
  chain: { id: 'chain', name: 'سلسلة البرق', icon: '🌩️', cat: 'energy', rarity: 'epic', desc: 'برق يقفز بين 4 أعداء متقاربين.', price: 1500, unlock: { type: 'stage', n: 9 }, base: 900,
    stats: (l) => ({ kind: 'chain', cost: 30, dmg: sc(24, l), jumps: 3 + Math.floor(l / 3), range: 8, cd: 1.0, color: 0xd8f0ff }), nextDesc: 'ضرر +17% وقفزات أكثر' },
  nova: { id: 'nova', name: 'موجة الصدمة', icon: '💫', cat: 'energy', rarity: 'legend', desc: 'انفجار حولك يدفع الجميع بعيدًا.', price: 2000, unlock: { type: 'stage', n: 12 }, base: 1200,
    stats: (l) => ({ kind: 'nova', cost: 40, dmg: sc(36, l), radius: 6.2, knock: 14, cd: 1.6, color: 0xffd24a }), nextDesc: 'ضرر +17%' },
  // ---- special ----
  turret: { id: 'turret', name: 'برج المساعد', icon: '🗼', cat: 'special', rarity: 'rare', desc: 'ينصب برجًا يطلق النار 14 ثانية.', price: 900, unlock: { type: 'stage', n: 6 }, base: 600,
    stats: (l) => ({ kind: 'turret', cd: 26, dur: 12 + l, dmg: sc(6, l), rate: 0.35, cost: 0 }), nextDesc: 'ضرر +17% ومدة أطول' },
  shield: { id: 'shield', name: 'قبة الدرع', icon: '🔰', cat: 'special', rarity: 'epic', desc: 'قبة تمتص الضرر لـ 6 ثوانٍ.', price: 1300, unlock: { type: 'stage', n: 11 }, base: 800,
    stats: (l) => ({ kind: 'shield', cd: 32, dur: 5 + l * 0.5, absorb: 70 + l * 25, cost: 0 }), nextDesc: 'امتصاص أكبر ومدة أطول' },
  drone: { id: 'drone', name: 'درون الإسعاف', icon: '🚁', cat: 'special', rarity: 'legend', desc: 'يعالجك 8 ثوانٍ ويطلق النار على الأعداء.', price: 2200, unlock: { type: 'stage', n: 16 }, base: 1400,
    stats: (l) => ({ kind: 'drone', cd: 36, dur: 9, heal: 45 + l * 8, dmg: sc(5, l), cost: 0 }), nextDesc: 'شفاء أكبر' },
  // ---- temporary abilities ----
  rage: { id: 'rage', name: 'هيجان', icon: '😡', cat: 'temp', rarity: 'rare', desc: 'ضرر +50% لـ 10 ثوانٍ.', price: 700, unlock: { type: 'plevel', n: 4 }, base: 500,
    stats: (l) => ({ kind: 'rage', cd: 38 - l, dur: 8 + l, mult: 1.4 + l * 0.05, cost: 0 }), nextDesc: 'مدة أطول وضرر أعلى' },
  haste: { id: 'haste', name: 'اندفاع', icon: '💨', cat: 'temp', rarity: 'rare', desc: 'سرعة حركة وهجوم +40% لـ 8 ثوانٍ.', price: 800, unlock: { type: 'stage', n: 7 }, base: 550,
    stats: (l) => ({ kind: 'haste', cd: 34 - l, dur: 7 + l * 0.7, mult: 1.35 + l * 0.03, cost: 0 }), nextDesc: 'مدة أطول' },
  freeze: { id: 'freeze', name: 'حقل التجميد', icon: '❄️', cat: 'temp', rarity: 'epic', desc: 'يبطّئ الأعداء القريبين بنسبة 70% لـ 6 ثوانٍ.', price: 2400, unlock: { type: 'stage', n: 14 }, base: 1500,
    stats: (l) => ({ kind: 'freeze', cd: 44 - l * 2, dur: 5 + l * 0.6, radius: 9, slow: 0.7, cost: 0 }), nextDesc: 'مدة ونطاق أكبر' },
};
export const ITEM_ORDER = Object.keys(ITEMS);
export const ITEM_MAX = 8;
export const itemUpCost = (it, lv) => up(it.base)(lv);
export function unlockText(it) {
  const u = it.unlock; if (u.type === 'start') return 'متاح من البداية';
  if (u.type === 'stage') return `أكمل المرحلة ${u.n}`; if (u.type === 'plevel') return `بلوغ مستوى اللاعب ${u.n}`; return '';
}

// Character upgrades bought with coins
export const UPGRADES = {
  hp: { name: 'الصحة', icon: '❤️', base: 120, step: '+14 صحة', max: 12 },
  dmg: { name: 'القوة', icon: '💪', base: 150, step: '+6% ضرر', max: 12 },
  energy: { name: 'الطاقة', icon: '🔋', base: 110, step: '+12 طاقة وإعادة شحن أسرع', max: 10 },
  speed: { name: 'السرعة', icon: '👟', base: 130, step: '+3% سرعة', max: 8 },
  magnet: { name: 'مغناطيس العملات', icon: '🧲', base: 80, step: '+1.2م مدى الجمع', max: 6 },
  armor: { name: 'الدرع', icon: '🧥', base: 170, step: '-3% ضرر مستلم', max: 10 },
};
export const upgradeCost = (k, lv) => Math.round(UPGRADES[k].base * (1 + lv * 0.55));
export const xpNeeded = (lvl) => Math.round(70 * Math.pow(lvl, 1.4));
