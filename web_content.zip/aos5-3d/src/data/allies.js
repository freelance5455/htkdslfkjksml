// Six recruitable allies. Unlocked by rescuing them in specific stages.
export const ALLIES = {
  kira: { id: 'kira', name: 'كيرا', role: 'رامية', icon: '🏹', style: 'kira', color: '#39d26a', hp: 75, dmg: 10, cd: 1.0, range: 12, speed: 4.8, ai: 'ranged', unlockStage: 2,
    desc: 'تطلق سهامًا دقيقة من مسافة بعيدة وتبتعد عن الأعداء.', trait: 'سهام مخترقة كل 5 ضربات', upBase: 260 },
  barq: { id: 'barq', name: 'برق', role: 'مقاتل سريع', icon: '⚡', style: 'barq', color: '#ffd23a', hp: 62, dmg: 6, cd: 0.38, range: 1.9, speed: 6.4, ai: 'melee', unlockStage: 5,
    desc: 'يهاجم بسرعة خاطفة ويفلت من الضربات.', trait: 'ضربات متتابعة سريعة', upBase: 300 },
  sindan: { id: 'sindan', name: 'سندان', role: 'مدرّع حامٍ', icon: '🛡️', style: 'sindan', color: '#3a7bd5', hp: 210, dmg: 12, cd: 1.15, range: 2.4, speed: 3.6, ai: 'tank', unlockStage: 8,
    desc: 'يسخر من الأعداء ويجذب هجماتهم بعيدًا عنك.', trait: 'استفزاز + تقليل الضرر 40%', upBase: 340 },
  noor: { id: 'noor', name: 'نور', role: 'مسعفة', icon: '✚', style: 'noor', color: '#ff6fa0', hp: 70, dmg: 5, cd: 1.0, range: 6, speed: 4.6, ai: 'healer', unlockStage: 11,
    desc: 'تعالجك وتعالج الفريق بنبضات شفاء دورية.', trait: 'نبضة شفاء كل 7 ثوانٍ', upBase: 380 },
  shararah: { id: 'shararah', name: 'شرارة', role: 'ساحرة طاقة', icon: '✦', style: 'shararah', color: '#b36bff', hp: 66, dmg: 22, cd: 2.2, range: 11, speed: 4.2, ai: 'mage', unlockStage: 14,
    desc: 'تطلق كرات طاقة تنفجر على مجموعات الأعداء.', trait: 'انفجارات جماعية', upBase: 420 },
  zill: { id: 'zill', name: 'ظلّ', role: 'قنّاص', icon: '◎', style: 'zill', color: '#25d0d0', hp: 64, dmg: 46, cd: 2.4, range: 22, speed: 4.6, ai: 'sniper', unlockStage: 17,
    desc: 'يصيب الأهداف الخطيرة من بعيد بضربات قاضية.', trait: 'ضربة حرجة ×2 على الزعماء', upBase: 450 },
};
export const ALLY_ORDER = ['kira', 'barq', 'sindan', 'noor', 'shararah', 'zill'];
export const allyStat = (def, lv) => ({ hp: def.hp * (1 + 0.22 * (lv - 1)), dmg: def.dmg * (1 + 0.2 * (lv - 1)) });
export const allyUpCost = (def, lv) => Math.round(def.upBase * (0.6 + 0.5 * lv));
export const ALLY_MAX = 5;
