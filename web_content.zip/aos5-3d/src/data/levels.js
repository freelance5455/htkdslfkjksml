// Campaign data: 8 chapters / 22 levels. Each level is data-driven (segments + objectives + rewards).
// Segment keys: t(template) id len variant enemies{type:n} coins hp crates barrels nooks cars cover switches keys{n,name} cage nests mech boss
//               protect lock waves[{type:n}] hazards[] lasers exitLock innerLock barricade trains theme
// Objectives: reach{seg,at:entry|exit|center} clear{seg} switches{n} rescue{ally} collect{n,name} destroy{n} boss{seg} protect{seg,secs}
export const CHAPTERS = [
  { id: 0, name: 'شوارع الفوضى', icon: '🏙️', desc: 'المدينة انتشرت فيها الفوضى. ابدأ رحلتك.' },
  { id: 1, name: 'أحياء مهجورة', icon: '🏚️', desc: 'أزقة وعمارات سكنية يسكنها الموتى.' },
  { id: 2, name: 'مبانٍ تجارية ومواقف', icon: '🏬', desc: 'مجمّعات تجارية ومواقف سيارات تحرسها العصابات.' },
  { id: 3, name: 'المنطقة الصناعية', icon: '🏭', desc: 'موانئ ومستودعات ومصانع آلية.' },
  { id: 4, name: 'المنشآت الأمنية والمختبرات', icon: '🧪', desc: 'بوابات ليزر وتجارب خرجت عن السيطرة.' },
  { id: 5, name: 'الأنفاق تحت الأرض', icon: '🚇', desc: 'مترو وصرف وظلام دامس.' },
  { id: 6, name: 'أسطح المدينة', icon: '🌆', desc: 'قفزات خطرة فوق الفراغ.' },
  { id: 7, name: 'المواجهة النهائية', icon: '🧠', desc: 'مركز القيادة والعقل المدبّر.' },
];

const L = (o) => Object.assign({ diff: 1, theme: 'dusk', seed: 1 }, o);
const R = (n) => ({ coins: Math.round(110 + 38 * n + n * n * 1.2), xp: Math.round(55 + 22 * n) });

export const LEVELS = [
  L({ id: 1, ch: 0, name: 'الحي المهجور', theme: 'dusk', diff: 1, seed: 101, rew: R(1), intro: 'ادفع للأمام، اقتحم المتجر المفتوح، ونظّف الساحة.',
    segs: [
      { t: 'street', id: 's1', len: 46, enemies: { thug: 3 }, coins: 5, crates: 3, cars: 3, nooks: 1 },
      { t: 'building', variant: 'shop', id: 'shop', len: 28, enemies: { thug: 2, runner: 1 }, coins: 5, hp: 1, crates: 2 },
      { t: 'plaza', id: 'plaza', len: 34, lock: true, waves: [{ thug: 3 }, { thug: 2, runner: 2 }], coins: 4 },
      { t: 'street', id: 's2', len: 38, enemies: { armored: 1, thug: 2 }, barricade: 0.45, coins: 4, crates: 2 },
    ],
    objectives: [
      { type: 'reach', seg: 'shop', at: 'entry', text: 'ادخل المتجر المفتوح أمامك' },
      { type: 'reach', seg: 'shop', at: 'exit', text: 'اعبر المتجر واخرج من بابه الشرقي' },
      { type: 'clear', seg: 'plaza', text: 'تخلّص من العصابة في الساحة' },
    ] }),
  L({ id: 2, ch: 0, name: 'شارع المتجر المحطّم', theme: 'dusk', diff: 1, seed: 102, rew: R(2), intro: 'هناك من ينتظر الإنقاذ داخل العمارة. استعد لمقاتلة جديدة!',
    segs: [
      { t: 'street', id: 's1', len: 46, enemies: { thug: 3, runner: 2 }, barricade: 0.5, coins: 5, crates: 3 },
      { t: 'alley', id: 'alley', len: 38, enemies: { slinger: 2, thug: 2 }, coins: 4, crates: 2 },
      { t: 'building', variant: 'apartment', id: 'apt', len: 34, cage: 'kira', enemies: { thug: 3, runner: 1 }, coins: 6, hp: 1 },
      { t: 'street', id: 's2', len: 30, enemies: { thug: 2, slinger: 1 }, coins: 3 },
    ],
    objectives: [
      { type: 'reach', seg: 'apt', at: 'entry', text: 'ادخل العمارة السكنية' },
      { type: 'rescue', ally: 'kira', text: 'حرّر كيرا المحتجزة داخل الغرف' },
    ] }),
  L({ id: 3, ch: 0, name: 'ساحة السوق', theme: 'dusk', diff: 2, seed: 103, rew: R(3), intro: 'شغّل الجهاز واحمِه حتى يكتمل البث!',
    segs: [
      { t: 'street', id: 's1', len: 34, enemies: { thug: 3, runner: 2 }, coins: 4, crates: 2 },
      { t: 'plaza', id: 'market', len: 48, protect: true, lock: true, waves: [{ thug: 3, runner: 1 }, { thug: 2, slinger: 2 }, { runner: 3, thug: 2 }, { armored: 1, thug: 3 }], coins: 6 },
      { t: 'street', id: 's2', len: 30, enemies: { runner: 3, slinger: 2 }, coins: 4 },
    ],
    objectives: [
      { type: 'reach', seg: 'market', at: 'entry', text: 'اتجه إلى سوق الساحة' },
      { type: 'protect', seg: 'market', secs: 50, text: 'احمِ جهاز البث لمدة 50 ثانية' },
    ] }),
  L({ id: 4, ch: 1, name: 'أزقة الحي القديم', theme: 'night', diff: 2, seed: 104, rew: R(4), intro: 'أعشاش الزومبي تغذّي الأزقة. دمّرها!',
    segs: [
      { t: 'alley', id: 'a1', len: 38, enemies: { zombie: 4 }, nests: 1, coins: 4, crates: 2 },
      { t: 'street', id: 's1', len: 32, enemies: { zombie: 3, zfast: 2 }, coins: 4, hp: 1, nooks: 1 },
      { t: 'alley', id: 'a2', len: 40, enemies: { zombie: 3, zfast: 2 }, nests: 1, coins: 4, crates: 2 },
      { t: 'street', id: 's2', len: 30, enemies: { thug: 2, slinger: 2 }, coins: 3 },
    ],
    objectives: [{ type: 'destroy', n: 2, text: 'دمّر أعشاش الزومبي (2)' }] }),
  L({ id: 5, ch: 1, name: 'العمارة السكنية', theme: 'night', diff: 3, seed: 105, rew: R(5), intro: 'المولّدان في الغرف يفتحان المخرج. هناك مقاتل محتجز أيضًا.',
    segs: [
      { t: 'street', id: 's1', len: 32, enemies: { thug: 3, slinger: 1 }, coins: 4, cars: 3 },
      { t: 'building', variant: 'apartment', id: 'apt', len: 40, switches: 2, cage: 'barq', exitLock: 'switches', enemies: { thug: 4, runner: 2, slinger: 1 }, coins: 8, hp: 2 },
      { t: 'street', id: 's2', len: 30, enemies: { armored: 1, thug: 2 }, coins: 4 },
    ],
    objectives: [
      { type: 'reach', seg: 'apt', at: 'entry', text: 'ادخل العمارة' },
      { type: 'switches', n: 2, text: 'فعّل المولّدين داخل الغرف (2)' },
      { type: 'rescue', ally: 'barq', text: 'حرّر برق المحتجز' },
    ] }),
  L({ id: 6, ch: 1, name: 'الحديقة المهجورة', theme: 'overcast', diff: 3, seed: 106, rew: R(6), intro: 'موجات الموتى تتدفّق. بعد هذه المرحلة تُفتح قوة التحوّل!',
    segs: [
      { t: 'street', id: 's1', len: 30, enemies: { zombie: 4, zfast: 2 }, coins: 4, crates: 2 },
      { t: 'plaza', id: 'park', len: 52, lock: true, waves: [{ zombie: 5 }, { zombie: 4, zfast: 3 }, { zombie: 5, zfast: 3, mutant: 1 }], coins: 8 },
      { t: 'street', id: 's2', len: 30, enemies: { zfast: 3, zombie: 2 }, coins: 4 },
    ],
    objectives: [{ type: 'clear', seg: 'park', text: 'اصمد أمام موجات الموتى في الحديقة' }] }),
  L({ id: 7, ch: 2, name: 'المول المهجور', theme: 'overcast', diff: 3, seed: 107, rew: R(7), intro: 'اجمع 3 بطاقات دخول لفتح باب الخروج.',
    segs: [
      { t: 'street', id: 's1', len: 28, enemies: { thug: 3, runner: 2 }, coins: 4, cars: 3 },
      { t: 'building', variant: 'mall', id: 'mall', len: 44, keys: { n: 3, name: 'بطاقة دخول' }, exitLock: 'keys', enemies: { thug: 4, slinger: 2, runner: 2, armored: 1 }, coins: 10, hp: 2, crates: 3 },
      { t: 'lot', id: 'lot', len: 30, enemies: { thug: 3, runner: 2 }, coins: 4 },
    ],
    objectives: [
      { type: 'reach', seg: 'mall', at: 'entry', text: 'ادخل المول' },
      { type: 'collect', n: 3, name: 'بطاقة دخول', text: 'اجمع بطاقات الدخول (3)' },
    ] }),
  L({ id: 8, ch: 2, name: 'موقف السيارات', theme: 'rust', diff: 4, seed: 108, rew: R(8), intro: 'مفاتيح الطابق العلوي، ومدرّع محتجز في مكان ما.',
    segs: [
      { t: 'lot', id: 'l1', len: 40, enemies: { thug: 4, slinger: 2 }, coins: 5, crates: 2 },
      { t: 'building', variant: 'parking', id: 'park', len: 40, keys: { n: 2, name: 'مفتاح البوابة' }, cage: 'sindan', exitLock: 'keys', enemies: { armored: 2, thug: 3, slinger: 2 }, coins: 8, hp: 2 },
      { t: 'lot', id: 'l2', len: 36, lock: true, waves: [{ thug: 4, runner: 3 }, { armored: 2, slinger: 2 }], coins: 5 },
    ],
    objectives: [
      { type: 'reach', seg: 'park', at: 'entry', text: 'ادخل موقف السيارات' },
      { type: 'collect', n: 2, name: 'مفتاح البوابة', text: 'اجمع مفاتيح البوابة (2)' },
      { type: 'rescue', ally: 'sindan', text: 'حرّر سندان' },
      { type: 'clear', seg: 'l2', text: 'اهزم الحرس عند المخرج' },
    ] }),
  L({ id: 9, ch: 2, name: 'بوابة الأبراج', theme: 'dusk', diff: 4, seed: 109, rew: R(9), intro: 'الجزار يحرس البوابة. استخدم الروبوت الميكانيكي إن وجدته!',
    segs: [
      { t: 'street', id: 's1', len: 38, enemies: { thug: 4, armored: 1 }, barricade: 0.5, coins: 5, crates: 3 },
      { t: 'plaza', id: 'pl', len: 34, mech: true, enemies: { thug: 3, slinger: 2, runner: 2 }, coins: 6, hp: 2 },
      { t: 'arena', id: 'arena', len: 50, boss: 'butcher', theme: 'street' },
    ],
    objectives: [
      { type: 'reach', seg: 'pl', at: 'center', text: 'اتجه إلى الساحة' },
      { type: 'boss', seg: 'arena', text: 'اهزم الجزار' },
    ] }),
  L({ id: 10, ch: 3, name: 'ميناء الشحن', theme: 'industrial', diff: 5, seed: 110, rew: R(10), intro: 'اجمع 3 خلايا وقود من بين الحاويات.',
    segs: [
      { t: 'yard', id: 'y1', len: 56, enemies: { thug: 4, runner: 3 }, coins: 6, crates: 3 },
      { t: 'yard', id: 'y2', len: 52, keys: { n: 3, name: 'خلية وقود' }, hazards: ['fire'], enemies: { armored: 2, slinger: 3, runner: 2 }, coins: 6, hp: 2 },
      { t: 'yard', id: 'y3', len: 42, lock: true, waves: [{ robot: 2, thug: 3 }, { armored: 2, runner: 3 }], coins: 5 },
    ],
    objectives: [{ type: 'collect', n: 3, name: 'خلية وقود', text: 'اجمع خلايا الوقود (3)' }, { type: 'clear', seg: 'y3', text: 'اهزم حرس البوابة' }] }),
  L({ id: 11, ch: 3, name: 'المستودع الصناعي', theme: 'industrial', diff: 5, seed: 111, rew: R(11), intro: 'شغّل الآلية في الطابق العلوي لفتح الباب الدوّار.',
    segs: [
      { t: 'yard', id: 'y1', len: 38, enemies: { thug: 4, slinger: 2 }, coins: 5 },
      { t: 'building', variant: 'warehouse', id: 'wh', len: 44, switches: 2, cage: 'noor', exitLock: 'switches', enemies: { robot: 2, thug: 4, slinger: 3 }, coins: 9, hp: 2 },
      { t: 'yard', id: 'y2', len: 32, enemies: { armored: 2, robot: 1 }, coins: 4 },
    ],
    objectives: [
      { type: 'reach', seg: 'wh', at: 'entry', text: 'ادخل المستودع' },
      { type: 'switches', n: 2, text: 'فعّل آليّتَي المستودع (2)' },
      { type: 'rescue', ally: 'noor', text: 'حرّر نور المسعفة' },
    ] }),
  L({ id: 12, ch: 3, name: 'مصنع الصهر', theme: 'rust', diff: 6, seed: 112, rew: R(12), intro: 'حارس المصنع الآلي لن يتوقف. اضرب قلبه المكشوف بعد ضربة الدهس.',
    segs: [
      { t: 'yard', id: 'y1', len: 38, hazards: ['fire'], enemies: { robot: 3, thug: 3 }, coins: 5, crates: 2 },
      { t: 'building', variant: 'warehouse', id: 'wh', len: 38, enemies: { robot: 3, armored: 1, slinger: 2 }, coins: 8, hp: 2 },
      { t: 'arena', id: 'arena', len: 50, boss: 'warden', theme: 'factory', ringColor: 0xffa31a },
    ],
    objectives: [{ type: 'reach', seg: 'wh', at: 'exit', text: 'اعبر المصنع' }, { type: 'boss', seg: 'arena', text: 'دمّر حارس المصنع' }] }),
  L({ id: 13, ch: 4, name: 'بوابة الأمن', theme: 'lab', diff: 6, seed: 113, rew: R(13), intro: 'أشعة الليزر تتناوب. تدحرج عبرها بحكمة، وفعّل المفاتيح.',
    segs: [
      { t: 'street', id: 's1', len: 28, enemies: { robot: 2, thug: 3 }, coins: 4, cars: 2 },
      { t: 'building', variant: 'bunker', id: 'b1', len: 38, lasers: 3, enemies: { robot: 3, slinger: 2 }, coins: 6, hp: 1 },
      { t: 'building', variant: 'bunker', id: 'b2', len: 36, lasers: 2, switches: 2, exitLock: 'switches', enemies: { robot: 3, armored: 2 }, coins: 6, hp: 2 },
    ],
    objectives: [{ type: 'reach', seg: 'b1', at: 'entry', text: 'ادخل المنشأة الأمنية' }, { type: 'switches', n: 2, text: 'عطّل نظام الحماية (2)' }] }),
  L({ id: 14, ch: 4, name: 'المختبر ألفا', theme: 'lab', diff: 7, seed: 114, rew: R(14), intro: 'شرارة محتجزة في المختبر. اجمع بطاقتَي الأمن.',
    segs: [
      { t: 'building', variant: 'bunker', id: 'b1', len: 30, lasers: 2, enemies: { robot: 3, slinger: 2 }, coins: 5 },
      { t: 'building', variant: 'lab', id: 'lab', len: 40, keys: { n: 2, name: 'بطاقة أمن' }, cage: 'shararah', exitLock: 'keys', enemies: { robot: 3, slinger: 3, armored: 1 }, coins: 9, hp: 2 },
      { t: 'street', id: 's2', len: 28, enemies: { robot: 2, armored: 1 }, coins: 4 },
    ],
    objectives: [{ type: 'reach', seg: 'lab', at: 'entry', text: 'ادخل المختبر' }, { type: 'collect', n: 2, name: 'بطاقة أمن', text: 'اجمع بطاقات الأمن (2)' }, { type: 'rescue', ally: 'shararah', text: 'حرّر شرارة' }] }),
  L({ id: 15, ch: 4, name: 'قسم العينات', theme: 'lab', diff: 7, seed: 115, rew: R(15), intro: 'ثلاثة أعشاش متحوّرة تتغذّى على العينات. أحرقها!',
    segs: [
      { t: 'building', variant: 'lab', id: 'lab', len: 40, nests: 2, enemies: { mutant: 1, zfast: 4, robot: 2 }, coins: 8, hp: 2 },
      { t: 'building', variant: 'office', id: 'off', len: 32, nests: 1, enemies: { zombie: 5, mutant: 1, slinger: 2 }, coins: 6, hp: 1 },
      { t: 'street', id: 's2', len: 28, enemies: { zfast: 3, robot: 2 }, coins: 4 },
    ],
    objectives: [{ type: 'destroy', n: 3, text: 'دمّر الأعشاش المتحوّرة (3)' }] }),
  L({ id: 16, ch: 5, name: 'مترو الأنفاق', theme: 'tunnel', diff: 7, seed: 116, rew: R(16), intro: 'احمِ مولّد الطوارئ حتى يضيء النفق.',
    segs: [
      { t: 'tunnel', id: 't1', len: 46, trains: 1, enemies: { zombie: 5, zfast: 3 }, coins: 5, crates: 2 },
      { t: 'tunnel', id: 'tp', len: 48, protect: true, lock: true, alarm: true, trains: 0, waves: [{ zombie: 4, zfast: 2 }, { zfast: 4, mutant: 1 }, { zombie: 5, zfast: 3 }, { mutant: 2 }], coins: 6 },
      { t: 'tunnel', id: 't3', len: 40, enemies: { mutant: 1, zfast: 4 }, coins: 5, hp: 2 },
    ],
    objectives: [{ type: 'reach', seg: 'tp', at: 'entry', text: 'تقدّم إلى غرفة المولّد' }, { type: 'protect', seg: 'tp', secs: 60, text: 'احمِ المولّد لمدة 60 ثانية' }] }),
  L({ id: 17, ch: 5, name: 'شبكة الصرف', theme: 'sewer', diff: 8, seed: 117, rew: R(17), intro: 'الغاز السام يتصاعد بإيقاع. اجمع الصمامات وحرّر ظلّ.',
    segs: [
      { t: 'sewer', id: 'w1', len: 46, enemies: { zombie: 5, zfast: 3 }, coins: 5 },
      { t: 'sewer', id: 'w2', len: 46, keys: { n: 3, name: 'صمام' }, cage: 'zill', enemies: { mutant: 1, zombie: 4, slinger: 3 }, coins: 6, hp: 2 },
      { t: 'sewer', id: 'w3', len: 40, lock: true, waves: [{ zfast: 4, zombie: 3 }, { mutant: 1, zfast: 3 }], coins: 5 },
    ],
    objectives: [{ type: 'collect', n: 3, name: 'صمام', text: 'اجمع الصمامات (3)' }, { type: 'rescue', ally: 'zill', text: 'حرّر ظلّ' }, { type: 'clear', seg: 'w3', text: 'اهزم الموجات الأخيرة' }] }),
  L({ id: 18, ch: 5, name: 'قلب النفق', theme: 'tunnel', diff: 8, seed: 118, rew: R(18), intro: 'المتحوّر الأكبر ينتظر. الروبوت الميكانيكي في الطريق إن احتجته.',
    segs: [
      { t: 'tunnel', id: 't1', len: 40, mech: true, enemies: { zombie: 5, zfast: 4, mutant: 1 }, coins: 5, hp: 2 },
      { t: 'sewer', id: 'w1', len: 38, enemies: { mutant: 1, zfast: 4 }, coins: 5 },
      { t: 'arena', id: 'arena', len: 52, boss: 'alpha', theme: 'tunnel', ringColor: 0x9affc0, lightColor: 0x9affc0 },
    ],
    objectives: [{ type: 'reach', seg: 'w1', at: 'exit', text: 'اعبر النفق' }, { type: 'boss', seg: 'arena', text: 'اهزم المتحوّر الأكبر' }] }),
  L({ id: 19, ch: 6, name: 'أسطح المدينة', theme: 'sunrise', diff: 8, seed: 119, rew: R(19), intro: 'اقفز بين الأسطح! السقوط يكلّفك الصحة.',
    segs: [
      { t: 'roofs', id: 'r1', len: 64, enemies: { slinger: 3, runner: 3, robot: 1 }, coins: 8 },
      { t: 'roofs', id: 'r2', len: 64, enemies: { robot: 3, armored: 1, slinger: 3 }, coins: 8, hp: 2 },
    ],
    objectives: [{ type: 'reach', seg: 'r2', at: 'exit', text: 'اقفز عبر الأسطح حتى نهايتها' }] }),
  L({ id: 20, ch: 6, name: 'برج الاتصالات', theme: 'storm', diff: 9, seed: 120, rew: R(20), intro: 'من القمة إلى الأسفل، الجنرال يتربّص بك.',
    segs: [
      { t: 'roofs', id: 'r1', len: 80, y0: 20, endY: 0, enemies: { robot: 3, slinger: 4, runner: 3 }, coins: 10, hp: 2 },
      { t: 'arena', id: 'arena', len: 50, boss: 'general', theme: 'roof', ringColor: 0xff4a6a, lightColor: 0xffb0a0 },
    ],
    objectives: [{ type: 'reach', seg: 'r1', at: 'exit', text: 'انزل عبر أسطح البرج' }, { type: 'boss', seg: 'arena', text: 'اهزم الجنرال' }] }),
  L({ id: 21, ch: 7, name: 'مركز القيادة', theme: 'lab', diff: 9, seed: 121, rew: R(21), intro: 'ثلاثة مفاتيح تشغيل تفتح قلب المركز.',
    segs: [
      { t: 'street', id: 's1', len: 32, lock: true, waves: [{ robot: 3, slinger: 2 }, { armored: 2, robot: 2 }], coins: 5 },
      { t: 'building', variant: 'bunker', id: 'b1', len: 36, lasers: 2, enemies: { robot: 3, armored: 2, slinger: 2 }, coins: 6, hp: 2 },
      { t: 'building', variant: 'control', id: 'ctl', len: 36, switches: 3, exitLock: 'switches', enemies: { robot: 3, armored: 2, slinger: 3 }, coins: 8, hp: 2 },
    ],
    objectives: [{ type: 'clear', seg: 's1', text: 'اهزم الحرس عند المدخل' }, { type: 'switches', n: 3, text: 'فعّل مفاتيح المركز (3)' }] }),
  L({ id: 22, ch: 7, name: 'قلب العقل المدبّر', theme: 'final', diff: 10, seed: 122, rew: R(22), intro: 'المعركة الأخيرة. دمّر الأبراج ثم اضرب العقل.',
    segs: [
      { t: 'building', variant: 'lab', id: 'lab', len: 34, enemies: { robot: 3, armored: 2, slinger: 3 }, coins: 8, hp: 2 },
      { t: 'arena', id: 'arena', len: 56, boss: 'mastermind', theme: 'final', ringColor: 0x66ffee, lightColor: 0x99fff5 },
    ],
    objectives: [{ type: 'reach', seg: 'lab', at: 'exit', text: 'اخترق المختبر' }, { type: 'boss', seg: 'arena', text: 'اهزم العقل المدبّر' }] }),
];

export const LEVEL_BY_ID = Object.fromEntries(LEVELS.map(l => [l.id, l]));
