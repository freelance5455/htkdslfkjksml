// Character visual definitions (hero, allies, enemies, bosses, transformation forms)
import { Rig } from './rig.js';

export const STYLES = {
  // ---- hero ----
  hero: { id: 'hero', accent: 0xe0262d, rim: 0xff7a6a, extras: ['headband', 'scarf', 'gloves', 'belt'], limbR: 0.056 },
  titan: { id: 'titan', scale: 1.5, cloth: 0x16264a, limb: 0x16264a, pants: 0x101c38, skin: 0x16264a, accent: 0xffc83a, dark: 0x0a1226, rim: 0x6fe6ff, eyes: 0x7fffff, limbR: 0.075, torsoW: 0.12, shoulderW: 0.26, extras: ['helmet', 'visor', 'bigPads', 'chestPlate', 'core', 'bigFists', 'flameAura', 'belt'], auraColor: 0x4fd8ff, gait: 'normal' },
  mech: { id: 'mech', scale: 2.1, shape: 'box', cloth: 0x4b5260, limb: 0x3b414c, pants: 0x30353f, skin: 0x2a2e36, accent: 0xff8a1f, dark: 0x16181d, rim: 0xffb36a, eyes: 0xff7a3a, limbR: 0.085, torsoW: 0.15, shoulderW: 0.3, headR: 0.17, extras: ['bigPads', 'cannonR', 'backpack', 'antenna', 'chestPlate', 'core', 'visor'], gait: 'robot' },
  // ---- allies ----
  kira: { id: 'kira', accent: 0x39d26a, cloth: 0x24402e, limb: 0x2a3a30, skin: 0x2a3a30, pants: 0x20322a, rim: 0x7dffa0, extras: ['hood', 'bandolier', 'scarf'], weapon: 'bow' },
  barq: { id: 'barq', accent: 0xffd23a, cloth: 0x3a3622, limb: 0x2c2c34, skin: 0x2c2c34, pants: 0x2a2820, scale: 0.94, rim: 0xffe27a, extras: ['goggles', 'scarf', 'gloves'], weapon: 'dagger' },
  sindan: { id: 'sindan', accent: 0x3a7bd5, cloth: 0x1b2c44, pants: 0x1b2c44, scale: 1.16, limbR: 0.07, torsoW: 0.11, shoulderW: 0.24, rim: 0x7fb5ff, extras: ['helmet', 'bigPads', 'chestPlate', 'shield', 'belt'], gait: 'heavy', weapon: 'mace' },
  noor: { id: 'noor', accent: 0xff6fa0, cloth: 0xe8e8ee, pants: 0x2b2330, limb: 0x1a1a22, skin: 0x1a1a22, rim: 0xffb0d0, extras: ['hair', 'cross', 'coat', 'gloves'], weapon: 'baton' },
  shararah: { id: 'shararah', accent: 0xb36bff, cloth: 0x45286e, pants: 0x2e1c4c, limb: 0x2c2440, skin: 0x2c2440, rim: 0xd9aaff, extras: ['hood', 'halo', 'coat'], weapon: 'staff' },
  zill: { id: 'zill', accent: 0x25d0d0, cloth: 0x2a3138, pants: 0x242a30, skin: 0x1a1d21, limb: 0x2a3138, rim: 0x72ffff, eyes: 0x25f0f0, scale: 1.05, extras: ['hood', 'visor', 'scarf'], weapon: 'rifle' },
  // ---- enemies ----
  thug: { id: 'thug', accent: 0x9b2c2c, cloth: 0x2b2d33, pants: 0x1c1d22, skin: 0x1a1a1f, rim: 0xff6a5a, extras: ['headband'], weapon: 'bat' },
  runner: { id: 'runner', scale: 0.95, limbR: 0.046, accent: 0xf0c030, cloth: 0x3a3320, rim: 0xffe070, extras: ['hood'], gait: 'normal' },
  slinger: { id: 'slinger', accent: 0x35c6e8, cloth: 0x1d2b35, pants: 0x15202a, rim: 0x8ae8ff, extras: ['hood', 'goggles'], weapon: 'orbGun' },
  armored: { id: 'armored', scale: 1.14, limbR: 0.068, torsoW: 0.11, shoulderW: 0.23, accent: 0xc0392b, cloth: 0x41454e, pants: 0x2d3038, limb: 0x30333b, skin: 0x22252b, dark: 0x16181d, rim: 0xffa08a, eyes: 0xff3a2a, extras: ['helmet', 'visor', 'bigPads', 'chestPlate'], gait: 'heavy', weapon: 'mace' },
  zombie: { id: 'zombie', skin: 0x7f9470, limb: 0x6d8260, cloth: 0x4a4f44, pants: 0x38392f, accent: 0x7a2323, dark: 0x1f2218, rim: 0xa0ff8a, eyes: 0xe8e050, gait: 'shamble', headR: 0.21, extras: [] },
  zfast: { id: 'zfast', scale: 0.96, limbR: 0.045, skin: 0xaebca0, limb: 0x93a388, cloth: 0x59523f, pants: 0x3b3a30, accent: 0x7a1a1a, dark: 0x1a1c14, rim: 0xff8a7a, eyes: 0xff3030, gait: 'lunge', extras: ['claws', 'hair'] },
  mutant: { id: 'mutant', scale: 1.45, limbR: 0.07, torsoW: 0.12, skin: 0x5f8a58, limb: 0x4f7a4a, cloth: 0x3a5a3a, pants: 0x2a3a2a, accent: 0x9a4aff, dark: 0x1c241c, rim: 0xb0ff90, eyes: 0xff4a4a, gait: 'heavy', extras: ['bigArmR', 'spikes', 'jaw', 'horns'] },
  robot: { id: 'robot', shape: 'box', scale: 1.0, limbR: 0.06, torsoW: 0.1, skin: 0x9aa4af, limb: 0x7d8792, cloth: 0xb4bcc6, pants: 0x65707c, accent: 0xff3b3b, dark: 0x22262c, rim: 0xcfe6ff, eyes: 0xff3b3b, gait: 'robot', extras: ['antenna', 'backpack', 'chestPlate', 'visor'], weapon: 'blaster' },
  // ---- bosses ----
  butcher: { id: 'butcher', scale: 1.7, limbR: 0.075, torsoW: 0.14, shoulderW: 0.28, skin: 0x8a6a62, limb: 0x7a5d56, cloth: 0xddd4c4, pants: 0x3a2e2a, accent: 0xa01818, dark: 0x201513, rim: 0xff8a6a, eyes: 0xffa030, gait: 'heavy', extras: ['jaw', 'bigPads', 'belt', 'coat'], weapon: 'cleaver' },
  warden: { id: 'warden', shape: 'box', scale: 1.85, limbR: 0.085, torsoW: 0.16, shoulderW: 0.3, headR: 0.17, skin: 0x59616d, limb: 0x424a55, cloth: 0xd8941c, pants: 0x30363f, accent: 0xffb21a, dark: 0x1a1d22, rim: 0xffd27a, eyes: 0xff4a2a, gait: 'robot', extras: ['cannonR', 'bigPads', 'backpack', 'core', 'antenna', 'visor', 'chestPlate'] },
  alpha: { id: 'alpha', scale: 2.05, limbR: 0.082, torsoW: 0.15, shoulderW: 0.3, skin: 0x4a7a5a, limb: 0x3e6a4c, cloth: 0x2e4a38, pants: 0x20332a, accent: 0xff5ab0, dark: 0x16201a, rim: 0x9affc0, eyes: 0xff2a50, gait: 'heavy', extras: ['spikes', 'claws', 'bigFists', 'jaw', 'horns'] },
  general: { id: 'general', scale: 1.4, limbR: 0.06, torsoW: 0.1, shoulderW: 0.22, skin: 0x1a1a22, limb: 0x1a1a22, cloth: 0x2a1216, pants: 0x1a1013, accent: 0xc81e3a, dark: 0x0e0a0c, rim: 0xff6a7a, eyes: 0xff6a3a, gait: 'normal', extras: ['helmet', 'visor', 'cape', 'bigPads', 'bandolier'], weapon: 'blade' },
  mastermind: { id: 'mastermind', scale: 1.6, skin: 0x201a3a, limb: 0x241c44, cloth: 0x181030, pants: 0x181030, accent: 0x66ffee, dark: 0x0d0a1a, rim: 0x99fff5, eyes: 0x66ffee, gait: 'float', headR: 0.23, extras: ['halo', 'shards', 'core', 'cape'] },
};

export function makeRig(id, over = {}) {
  const s = Object.assign({}, STYLES[id] || STYLES.thug, over);
  const rig = new Rig(s);
  if (s.weapon) rig.setWeapon(s.weapon);
  return rig;
}
