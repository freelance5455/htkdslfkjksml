// Procedural audio (WebAudio): synthesized SFX + generative music. No external audio files (all original).
import { Save } from './save.js';
let ctx = null, master, musicG, sfxG, noiseBuf;
const A = { enabled: true, music: 0.5, sfxV: 0.8, track: null, timer: null, step: 0, nextT: 0 };

export const Audio = {
  unlock() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      master = ctx.createGain(); master.gain.value = 0.9; master.connect(ctx.destination);
      musicG = ctx.createGain(); sfxG = ctx.createGain(); musicG.connect(master); sfxG.connect(master);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      this.setVolumes(Save.d.settings.music, Save.d.settings.sfx);
      if (A.track) this.music(A.track, true);
    } catch (e) { ctx = null; }
  },
  setVolumes(m, s) { A.music = m; A.sfxV = s; if (musicG) { musicG.gain.value = m * 0.5; sfxG.gain.value = s; } },
  _tone(f, dur, type = 'square', vol = 0.2, slide = 0, delay = 0, dest = sfxG) {
    if (!ctx) return; const t = ctx.currentTime + delay; const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0005, t + dur);
    o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.02);
  },
  _noise(dur, vol = 0.2, freq = 2000, q = 1, type = 'bandpass', delay = 0, dest = sfxG, slide = 0) {
    if (!ctx) return; const t = ctx.currentTime + delay; const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t); if (slide) f.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur); f.Q.value = q;
    const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0005, t + dur);
    s.connect(f); f.connect(g); g.connect(dest); s.start(t); s.stop(t + dur + 0.02);
  },
  sfx(name) {
    if (!ctx || !A.sfxV) return;
    const T = this._tone.bind(this), N = this._noise.bind(this);
    switch (name) {
      case 'swing': N(0.14, 0.12, 1800, 0.8, 'bandpass', 0, sfxG, -1200); break;
      case 'hit': N(0.1, 0.3, 900, 1, 'lowpass'); T(150, 0.1, 'square', 0.2, -90); break;
      case 'hit2': N(0.14, 0.38, 700, 1, 'lowpass'); T(110, 0.16, 'sawtooth', 0.25, -70); break;
      case 'crit': T(520, 0.12, 'square', 0.18, 300); N(0.12, 0.3, 1200); break;
      case 'shoot': T(900, 0.1, 'square', 0.1, -600); N(0.05, 0.12, 3000); break;
      case 'laser': T(1400, 0.2, 'sawtooth', 0.09, -900); break;
      case 'orb': T(300, 0.3, 'sine', 0.2, 500); break;
      case 'zap': N(0.25, 0.22, 3500, 2, 'highpass'); T(220, 0.2, 'sawtooth', 0.12, 400); break;
      case 'nova': T(90, 0.5, 'sine', 0.35, -50); N(0.4, 0.3, 500, 1, 'lowpass'); break;
      case 'jump': T(280, 0.15, 'sine', 0.15, 300); break;
      case 'land': N(0.08, 0.18, 400, 1, 'lowpass'); break;
      case 'roll': N(0.25, 0.14, 1200, 1, 'bandpass', 0, sfxG, -600); break;
      case 'coin': T(1100, 0.07, 'square', 0.09); T(1650, 0.14, 'square', 0.09, 0, 0.06); break;
      case 'pickup': T(660, 0.1, 'triangle', 0.18); T(990, 0.18, 'triangle', 0.18, 0, 0.08); break;
      case 'heal': T(520, 0.12, 'sine', 0.2); T(780, 0.12, 'sine', 0.2, 0, 0.1); T(1040, 0.2, 'sine', 0.2, 0, 0.2); break;
      case 'door': N(0.25, 0.2, 500, 1, 'lowpass'); T(120, 0.25, 'sawtooth', 0.08, 40); break;
      case 'doorclose': N(0.18, 0.2, 400, 1, 'lowpass'); break;
      case 'hurt': T(200, 0.22, 'sawtooth', 0.22, -120); N(0.12, 0.2, 800, 1, 'lowpass'); break;
      case 'die': T(300, 0.7, 'sawtooth', 0.25, -250); N(0.5, 0.25, 600, 1, 'lowpass'); break;
      case 'edie': T(180, 0.3, 'square', 0.14, -120); N(0.2, 0.2, 700, 1, 'lowpass'); break;
      case 'boom': N(0.7, 0.55, 300, 1, 'lowpass', 0, sfxG, -200); T(60, 0.6, 'sine', 0.4, -30); break;
      case 'roar': T(80, 1.0, 'sawtooth', 0.28, 40); T(120, 1.0, 'square', 0.12, -40); N(1.0, 0.22, 400, 1, 'lowpass'); break;
      case 'transform': T(200, 1.0, 'sawtooth', 0.25, 800); T(400, 1.0, 'square', 0.12, 1200); N(0.8, 0.2, 2000, 1, 'highpass'); break;
      case 'levelup': [523, 659, 784, 1047].forEach((f, i) => T(f, 0.25, 'square', 0.14, 0, i * 0.11)); break;
      case 'click': T(700, 0.04, 'square', 0.1); break;
      case 'ok': T(600, 0.08, 'square', 0.12); T(900, 0.1, 'square', 0.12, 0, 0.07); break;
      case 'back': T(500, 0.08, 'square', 0.1); T(350, 0.1, 'square', 0.1, 0, 0.07); break;
      case 'deny': T(160, 0.18, 'square', 0.14); break;
      case 'objective': T(740, 0.1, 'triangle', 0.18); T(990, 0.2, 'triangle', 0.18, 0, 0.1); break;
      case 'switch': T(300, 0.12, 'square', 0.14); T(450, 0.16, 'square', 0.14, 0, 0.1); N(0.1, 0.15, 2000); break;
      case 'unlock': T(500, 0.1, 'triangle', 0.2); T(750, 0.1, 'triangle', 0.2, 0, 0.1); T(1000, 0.25, 'triangle', 0.2, 0, 0.2); break;
      case 'shield': T(250, 0.4, 'sine', 0.25, 400); break;
      case 'freeze': N(0.5, 0.2, 4000, 3, 'highpass'); T(1200, 0.4, 'sine', 0.1, -800); break;
      case 'warn': T(400, 0.18, 'square', 0.14); T(400, 0.18, 'square', 0.14, 0, 0.25); break;
      case 'win': [523, 659, 784, 1047, 1319].forEach((f, i) => T(f, 0.3, 'square', 0.14, 0, i * 0.12)); break;
      case 'lose': [400, 330, 262, 196].forEach((f, i) => T(f, 0.35, 'sawtooth', 0.14, 0, i * 0.2)); break;
      case 'thunder': N(1.2, 0.5, 200, 1, 'lowpass', 0, sfxG, -100); break;
      default: break;
    }
  },
  // ---------- generative music ----------
  music(name, force) {
    if (A.track === name && !force) return; A.track = name;
    clearInterval(A.timer); if (!ctx || !name) return;
    const P = TRACKS[name] || TRACKS.level; A.step = 0; A.nextT = ctx.currentTime + 0.1;
    const spb = 60 / P.bpm / 2; // eighth notes
    A.timer = setInterval(() => {
      if (!ctx) return;
      while (A.nextT < ctx.currentTime + 0.4) {
        const s = A.step % P.bass.length, bar = Math.floor(A.step / P.bass.length) % P.chords;
        const bn = P.bass[s]; if (bn >= 0) this._tone(midi(P.root + bn + (P.prog ? P.prog[bar % P.prog.length] : 0)), spb * 1.8, P.bassType || 'sawtooth', 0.13, 0, A.nextT - ctx.currentTime, musicG);
        const an = P.arp[A.step % P.arp.length]; if (an >= 0) this._tone(midi(P.root + 24 + an + (P.prog ? P.prog[bar % P.prog.length] : 0)), spb * 0.9, P.arpType || 'square', 0.045, 0, A.nextT - ctx.currentTime, musicG);
        if (P.drums) { const d = P.drums[A.step % P.drums.length]; if (d === 1) { this._tone(110, 0.14, 'sine', 0.3, -70, A.nextT - ctx.currentTime, musicG); } else if (d === 2) this._noise(0.1, 0.1, 5000, 1, 'highpass', A.nextT - ctx.currentTime, musicG); else if (d === 3) { this._noise(0.12, 0.18, 1800, 1, 'bandpass', A.nextT - ctx.currentTime, musicG); } }
        A.step++; A.nextT += spb;
      }
    }, 120);
  },
  stopMusic() { A.track = null; clearInterval(A.timer); },
};
const midi = (n) => 440 * Math.pow(2, (n - 69) / 12);
const TRACKS = {
  menu: { bpm: 84, root: 45, chords: 4, prog: [0, -2, -4, -5], bass: [0, -1, 0, -1, 7, -1, 5, -1], arp: [12, 15, 19, 15, 12, 17, 19, 22], drums: [1, -1, 2, -1, 3, -1, 2, -1], bassType: 'triangle' },
  level: { bpm: 112, root: 40, chords: 4, prog: [0, 3, 5, 2], bass: [0, 0, -1, 0, 12, -1, 7, -1], arp: [12, -1, 15, -1, 19, -1, 15, 12], drums: [1, 2, 3, 2, 1, 2, 3, 2] },
  boss: { bpm: 146, root: 38, chords: 4, prog: [0, 1, 0, -2], bass: [0, 0, 12, 0, 0, 0, 13, 0], arp: [12, 13, 12, 15, 12, 13, 12, 17], drums: [1, 2, 3, 1, 1, 2, 3, 2], bassType: 'sawtooth' },
  tunnel: { bpm: 92, root: 36, chords: 4, prog: [0, 0, -2, -5], bass: [0, -1, -1, 0, -1, 7, -1, -1], arp: [-1, 19, -1, -1, 22, -1, 17, -1], drums: [1, -1, -1, 2, 3, -1, -1, 2], bassType: 'triangle' },
  lab: { bpm: 104, root: 42, chords: 4, prog: [0, 5, 3, 7], bass: [0, -1, 0, 7, 0, -1, 12, -1], arp: [19, 22, 24, 22, 19, 17, 15, 17], drums: [1, 2, 2, 2, 3, 2, 2, 2], arpType: 'triangle' },
  victory: { bpm: 120, root: 48, chords: 2, prog: [0, 5], bass: [0, -1, 7, -1, 12, -1, 7, -1], arp: [12, 16, 19, 24, 19, 16, 12, 16], drums: null },
};
