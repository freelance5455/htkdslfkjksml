// Original 3D weapon / item models built from primitives. Built along +Y from the grip.
import * as THREE from 'three';
import { plain, glow } from './materials.js';

const g = {};
const B = (w, h, d) => g[`b${w}${h}${d}`] || (g[`b${w}${h}${d}`] = new THREE.BoxGeometry(w, h, d));
const C = (r1, r2, h, s = 8) => g[`c${r1}${r2}${h}${s}`] || (g[`c${r1}${r2}${h}${s}`] = new THREE.CylinderGeometry(r1, r2, h, s));
const S = (r) => g[`s${r}`] || (g[`s${r}`] = new THREE.SphereGeometry(r, 10, 8));
const N = (r, h) => g[`n${r}${h}`] || (g[`n${r}${h}`] = new THREE.ConeGeometry(r, h, 6));

function mesh(geo, mat, x = 0, y = 0, z = 0, rot) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); if (rot) m.rotation.set(...rot); return m; }

const METAL = () => plain(0x9aa3ad, { metal: 0.8, rough: 0.35 });
const DARK = () => plain(0x23252b, { metal: 0.3, rough: 0.6 });
const WOOD = () => plain(0x7a4f2a, { rough: 0.8 });
const RED = () => plain(0xc8352b, { rough: 0.5 });
const TAPE = () => plain(0x2b2f36, { rough: 0.95 });

const BUILD = {
  pipe() { const gp = new THREE.Group(); gp.add(mesh(C(0.032, 0.032, 1.15), plain(0x7d8791, { metal: 0.7, rough: 0.4 }), 0, 0.5, 0)); gp.add(mesh(C(0.04, 0.04, 0.3), TAPE(), 0, 0.02, 0)); gp.add(mesh(C(0.045, 0.045, 0.06), METAL(), 0, 1.1, 0)); return { mesh: gp, tilt: 0.95, aim: 'melee' }; },
  axe() { const gp = new THREE.Group(); gp.add(mesh(C(0.03, 0.035, 1.1), WOOD(), 0, 0.45, 0)); const head = mesh(B(0.07, 0.34, 0.42), RED(), 0, 0.92, 0.17); gp.add(head); gp.add(mesh(B(0.075, 0.2, 0.05), METAL(), 0, 0.92, 0.4)); gp.add(mesh(B(0.07, 0.22, 0.12), DARK(), 0, 0.92, -0.04)); return { mesh: gp, tilt: 0.9, aim: 'melee' }; },
  blade() { const gp = new THREE.Group(); gp.add(mesh(C(0.025, 0.025, 0.28), TAPE(), 0, 0.05, 0)); gp.add(mesh(C(0.09, 0.09, 0.02, 12), plain(0xd0a640, { metal: 0.8, rough: 0.3 }), 0, 0.2, 0)); gp.add(mesh(B(0.025, 0.95, 0.075), plain(0xe8eef5, { metal: 0.9, rough: 0.2 }), 0, 0.7, 0)); gp.add(mesh(B(0.03, 0.9, 0.012), glow(0x7fe3ff), 0, 0.7, 0.04)); return { mesh: gp, tilt: 0.7, aim: 'melee' }; },
  sledge() { const gp = new THREE.Group(); gp.add(mesh(C(0.035, 0.04, 1.2), WOOD(), 0, 0.5, 0)); gp.add(mesh(B(0.3, 0.2, 0.2), plain(0x3b3f47, { metal: 0.8, rough: 0.4 }), 0, 1.12, 0)); gp.add(mesh(B(0.32, 0.05, 0.22), RED(), 0, 1.02, 0)); return { mesh: gp, tilt: 1.0, aim: 'melee' }; },
  spear() { const gp = new THREE.Group(); gp.add(mesh(C(0.025, 0.025, 1.7), plain(0x5a4630, { rough: 0.8 }), 0, 0.6, 0)); gp.add(mesh(N(0.07, 0.34), plain(0xdce6f0, { metal: 0.9, rough: 0.2 }), 0, 1.62, 0)); gp.add(mesh(S(0.05), glow(0xffd24a), 0, 1.4, 0)); gp.add(mesh(C(0.045, 0.045, 0.05), METAL(), 0, 1.44, 0)); return { mesh: gp, tilt: 0.55, aim: 'melee' }; },
  sling() { const gp = new THREE.Group(); gp.add(mesh(C(0.025, 0.03, 0.22), WOOD(), 0, 0.08, 0)); gp.add(mesh(C(0.02, 0.02, 0.2), WOOD(), -0.07, 0.28, 0, [0, 0, 0.5])); gp.add(mesh(C(0.02, 0.02, 0.2), WOOD(), 0.07, 0.28, 0, [0, 0, -0.5])); gp.add(mesh(B(0.18, 0.01, 0.01), plain(0xffd27a), 0, 0.37, 0.0)); return { mesh: gp, tilt: 0.15, aim: 'ranged' }; },
  pistol() { const gp = new THREE.Group(); gp.add(mesh(B(0.06, 0.2, 0.1), DARK(), 0, 0.05, 0)); gp.add(mesh(B(0.07, 0.07, 0.34), plain(0x5b6470, { metal: 0.7, rough: 0.4 }), 0, 0.17, 0.12)); gp.add(mesh(C(0.02, 0.02, 0.1), glow(0xffcc44), 0, 0.17, 0.32, [Math.PI / 2, 0, 0])); return { mesh: gp, tilt: 0.1, aim: 'ranged' }; },
  scatter() { const gp = new THREE.Group(); gp.add(mesh(B(0.07, 0.22, 0.12), WOOD(), 0, 0.03, -0.02)); gp.add(mesh(C(0.04, 0.04, 0.6, 8), DARK(), -0.035, 0.17, 0.3, [Math.PI / 2, 0, 0])); gp.add(mesh(C(0.04, 0.04, 0.6, 8), DARK(), 0.035, 0.17, 0.3, [Math.PI / 2, 0, 0])); gp.add(mesh(B(0.1, 0.06, 0.3), plain(0xc8352b), 0, 0.18, 0.0)); return { mesh: gp, tilt: 0.1, aim: 'ranged' }; },
  arccannon() { const gp = new THREE.Group(); gp.add(mesh(B(0.12, 0.26, 0.2), DARK(), 0, 0.05, 0)); gp.add(mesh(C(0.07, 0.09, 0.62, 10), plain(0x3a4a5c, { metal: 0.7, rough: 0.35 }), 0, 0.2, 0.34, [Math.PI / 2, 0, 0])); for (let i = 0; i < 3; i++) gp.add(mesh(new THREE.TorusGeometry(0.095, 0.015, 5, 12), glow(0x6ae0ff), 0, 0.2, 0.2 + i * 0.16)); gp.add(mesh(S(0.05), glow(0x6ae0ff), 0, 0.2, 0.68)); return { mesh: gp, tilt: 0.1, aim: 'ranged' }; },
  // boss / enemy props
  cleaver() { const gp = new THREE.Group(); gp.add(mesh(C(0.05, 0.05, 0.5), TAPE(), 0, 0.1, 0)); gp.add(mesh(B(0.05, 0.9, 0.5), plain(0xb8bec6, { metal: 0.85, rough: 0.35 }), 0, 0.85, 0.12)); gp.add(mesh(B(0.056, 0.9, 0.06), RED(), 0, 0.85, 0.37)); return { mesh: gp, tilt: 0.9, aim: 'melee' }; },
  bat() { const gp = new THREE.Group(); gp.add(mesh(C(0.025, 0.055, 0.85), WOOD(), 0, 0.4, 0)); gp.add(mesh(S(0.03), DARK(), 0, -0.02, 0)); return { mesh: gp, tilt: 0.95, aim: 'melee' }; },
  baton() { const gp = new THREE.Group(); gp.add(mesh(C(0.03, 0.03, 0.8), DARK(), 0, 0.35, 0)); gp.add(mesh(C(0.036, 0.036, 0.14), glow(0xff5a3a), 0, 0.78, 0)); return { mesh: gp, tilt: 0.9, aim: 'melee' }; },
  orbGun() { const gp = new THREE.Group(); gp.add(mesh(C(0.03, 0.03, 0.3), DARK(), 0, 0.1, 0)); gp.add(mesh(S(0.11), glow(0x6ab8ff), 0, 0.32, 0)); return { mesh: gp, tilt: 0.5, aim: 'ranged' }; },
  blaster() { const gp = new THREE.Group(); gp.add(mesh(B(0.08, 0.2, 0.12), DARK(), 0, 0.04, 0)); gp.add(mesh(B(0.07, 0.07, 0.4), plain(0x3a3f4a, { metal: 0.6 }), 0, 0.16, 0.16)); gp.add(mesh(S(0.035), glow(0xff4a3a), 0, 0.16, 0.38)); return { mesh: gp, tilt: 0.1, aim: 'ranged' }; },
  staff() { const gp = new THREE.Group(); gp.add(mesh(C(0.03, 0.03, 1.4), plain(0x4a3a60, { rough: 0.6 }), 0, 0.55, 0)); gp.add(mesh(new THREE.OctahedronGeometry(0.11), glow(0xd18aff), 0, 1.35, 0)); return { mesh: gp, tilt: 0.5, aim: 'ranged' }; },
  rifle() { const gp = new THREE.Group(); gp.add(mesh(B(0.07, 0.2, 0.16), DARK(), 0, 0.03, 0)); gp.add(mesh(C(0.025, 0.025, 0.9, 6), plain(0x30343c, { metal: 0.7 }), 0, 0.16, 0.45, [Math.PI / 2, 0, 0])); gp.add(mesh(C(0.04, 0.04, 0.22, 8), DARK(), 0, 0.24, 0.2, [Math.PI / 2, 0, 0])); return { mesh: gp, tilt: 0.1, aim: 'ranged' }; },
  dagger() { const gp = new THREE.Group(); gp.add(mesh(C(0.025, 0.025, 0.18), TAPE(), 0, 0.03, 0)); gp.add(mesh(B(0.02, 0.4, 0.06), plain(0xe8eef5, { metal: 0.9, rough: 0.2 }), 0, 0.32, 0)); return { mesh: gp, tilt: 0.8, aim: 'melee' }; },
  bow() { const gp = new THREE.Group(); const arc = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.018, 5, 14, Math.PI), plain(0x2f7d3a, { rough: 0.6 })); arc.rotation.z = -Math.PI / 2; arc.position.set(0, 0.3, 0); gp.add(arc); gp.add(mesh(B(0.006, 0.64, 0.006), plain(0xeeeeee), 0.0, 0.3, 0)); return { mesh: gp, tilt: 0.1, aim: 'ranged' }; },
  mace() { const gp = new THREE.Group(); gp.add(mesh(C(0.035, 0.035, 0.9), DARK(), 0, 0.4, 0)); gp.add(mesh(S(0.2), plain(0x55606e, { metal: 0.8 }), 0, 0.98, 0)); for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; gp.add(mesh(N(0.05, 0.14), METAL(), Math.cos(a) * 0.2, 0.98, Math.sin(a) * 0.2, [Math.sin(a) * 1.5, 0, -Math.cos(a) * 1.5])); } return { mesh: gp, tilt: 0.95, aim: 'melee' }; },
};

export function buildWeaponMesh(id) { const f = BUILD[id]; return f ? f() : null; }
export const WEAPON_IDS = Object.keys(BUILD);
