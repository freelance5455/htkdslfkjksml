// DOM user interface: all menus (RTL Arabic), HUD, toasts, shop/upgrade/ally logic, settings, results & fail screens.
import { G } from './ctx.js';
import { Cam } from './camera.js';
import { Save, KEY_LABELS, DEFAULT_KEYS } from './save.js';
import { Input } from './input.js';
import { Audio } from './audio.js';
import { CHAPTERS, LEVELS, LEVEL_BY_ID } from './data/levels.js';
import { ITEMS, ITEM_ORDER, CATS, RARITY, ITEM_MAX, itemUpCost, unlockText, UPGRADES, upgradeCost, xpNeeded } from './data/items.js';
import { ALLIES, ALLY_ORDER, ALLY_MAX, allyStat, allyUpCost } from './data/allies.js';
import { ENEMIES, BOSSES } from './data/enemies.js';

const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const keyName = (c) => (c || '').replace(/^Key/, '').replace(/^Digit/, '').replace('ShiftLeft', 'Shift').replace('ShiftRight', 'Shift').replace('Space', 'Space').replace('Escape', 'Esc').replace('Arrow', '↑↓←→'.slice(0, 0)).replace('ControlLeft', 'Ctrl');
const stars = (n) => `<span class="stars">${'★'.repeat(n)}<span class="o">${'★'.repeat(3 - n)}</span></span>`;
const fmt = (n) => Math.round(n).toLocaleString('en-US');
const TYPE_AR = { thug: 'بلطجية', runner: 'عدّاؤون', slinger: 'رماة', armored: 'مدرّعون', zombie: 'زومبي', zfast: 'زومبي سريع', mutant: 'متحوّرون', robot: 'روبوتات' };
const MODE_UNLOCK = 1;

export const UI = {
  stack: [], cur: null, sel: 1, chap: 0, shopTab: 'melee', toastN: 0, hud: null, prevCtx: null, paused: false,
  init() {
    this.root = $('#ui');
    this.root.innerHTML = `<div id="floaters"></div><div id="hud" class="hidden"></div><div class="toasts" id="toasts"></div><div class="hurt" id="hurt"></div><div id="scr"></div><div id="modal"></div><div id="load" class="loading hidden"><div class="spin"></div><div id="loadt">جارٍ التحميل…</div></div>`;
    this.scr = $('#scr'); this.modal = $('#modal');
    this.root.addEventListener('click', (e) => { const t = e.target.closest('[data-a]'); if (!t || t.hasAttribute('disabled') || t.classList.contains('dis') && !t.dataset.force) { if (t && t.classList.contains('dis')) this.deny(t); return; } Audio.unlock(); this.act(t.dataset.a, t.dataset, t); });
    addEventListener('keydown', (e) => { if (G.rebinding) { e.preventDefault(); e.stopPropagation(); const a = G.rebinding; G.rebinding = null; if (e.code !== 'Escape') { Input.rebind(a, e.code); this.toast('تم ربط ' + KEY_LABELS[a] + ' بالمفتاح ' + keyName(e.code)); } this.render(); return; } }, true);
    addEventListener('pointerdown', () => Audio.unlock(), { once: true }); addEventListener('keydown', () => Audio.unlock(), { once: true });
    $('#ui').addEventListener('pointerdown', () => Audio.unlock());
  },
  deny(t) { Audio.sfx('deny'); t.animate && t.animate([{ transform: 'translateX(4px)' }, { transform: 'translateX(-4px)' }, { transform: 'none' }], { duration: 180 }); },
  // ------------------------------------------------------------------ navigation
  go(name, args) { this.stack.push({ name: this.cur && this.cur.name, args: this.cur && this.cur.args }); this.cur = { name, args }; this.render(); },
  replace(name, args) { this.cur = { name, args }; this.render(); },
  back() { const p = this.stack.pop(); if (p && p.name) { this.cur = p; this.render(); } else this.replace('title'); },
  clearScreens() { this.cur = null; this.stack = []; this.scr.innerHTML = ''; this.hudShow(this.hud && G.state === 'play'); },
  loading(v, t) { $('#load').classList.toggle('hidden', !v); if (t) $('#loadt').textContent = t; },
  render() {
    if (!this.cur) { this.scr.innerHTML = ''; return; }
    const f = this['r_' + this.cur.name]; if (!f) { this.scr.innerHTML = ''; return; }
    const sc = this.scr.firstElementChild ? this.scr.firstElementChild.querySelector('.scroll') : null; const top = sc ? sc.scrollTop : 0; const same = this._lastName === this.cur.name; this._lastName = this.cur.name;
    this.scr.innerHTML = f.call(this, this.cur.args || {});
    const sc2 = this.scr.querySelector('.scroll'); if (sc2 && same) sc2.scrollTop = top;
    this.hudShow(false);
  },
  head(title, extra = '') { return `<div class="top"><button class="btn sm" data-a="back">◀ رجوع</button><h2>${title}</h2>${extra}<span class="pill">🪙 ${fmt(Save.d.coins)}</span><span class="pill">مستوى ${Save.d.level}</span></div>`; },
  // ------------------------------------------------------------------ act router
  act(a, d, el) {
    const S = Save.d;
    switch (a) {
      case 'back': Audio.sfx('back'); this.back(); break;
      case 'go': Audio.sfx('click'); this.go(d.to); break;
      case 'home': Audio.sfx('click'); this.stack = []; this.replace('title'); break;
      case 'continue': { Audio.sfx('ok'); const id = Math.min(S.unlockedStage, LEVELS.length); this.sel = id; this.chap = LEVEL_BY_ID[id].ch; G.Game.startLevel(id); break; }
      case 'newgame': Audio.sfx('ok'); this.sel = 1; G.Game.startLevel(1); break;
      case 'chap': this.chap = +d.i; Audio.sfx('click'); this.render(); break;
      case 'sel': { const id = +d.id; if (id > S.unlockedStage) { this.deny(el); this.toast('أكمل المرحلة ' + (id - 1) + ' أولًا'); return; } this.sel = id; Audio.sfx('click'); this.render(); break; }
      case 'play': Audio.sfx('ok'); G.Game.startLevel(+d.id); break;
      case 'shoptab': this.shopTab = d.t; Audio.sfx('click'); this.render(); break;
      case 'buy': this.buy(d.id); break;
      case 'upg': this.upgradeItem(d.id); break;
      case 'equip': this.equip(d.id, d.slot); break;
      case 'hup': this.upgradeHero(d.k); break;
      case 'aup': this.upgradeAlly(d.id); break;
      case 'team': this.toggleTeam(d.id); break;
      case 'mode': Audio.sfx('ok'); G.Game.startMode(d.m, d); break;
      case 'resume': this.resume(); break;
      case 'restart': this.modalClose(); this.paused = false; Audio.sfx('ok'); G.Game.restart(); break;
      case 'respawn': Audio.sfx('ok'); this.scr.innerHTML = ''; this.cur = null; G.run.failShown = false; G.Game.respawn(); break;
      case 'quit': this.confirm('العودة إلى القائمة؟', 'سيُفقد تقدّم هذه المحاولة (العملات المجموعة تُحفظ جزئيًا).', () => { this.paused = false; G.Game.quit(); }); break;
      case 'next': { const id = G.run ? G.run.id + 1 : 1; if (LEVEL_BY_ID[id]) { this.sel = id; G.Game.startLevel(id); } else { G.Game.quit(); } break; }
      case 'menu': G.Game.quit(); break;
      case 'setopt': this.setOpt(d.k, d.v); break;
      case 'rebind': G.rebinding = d.k; Audio.sfx('click'); this.render(); break;
      case 'resetkeys': Input.resetKeys(); this.toast('أُعيدت المفاتيح الافتراضية'); this.render(); break;
      case 'resetsave': this.confirm('مسح كل التقدّم؟', 'سيتم حذف المراحل والعملات والعناصر والحلفاء نهائيًا. لا يمكن التراجع.', () => { Save.reset(); Input.rebuild(); this.toast('تم مسح التقدّم'); this.stack = []; this.replace('title'); }, true); break;
      case 'ok': this.modalClose(); break;
      case 'dismiss': this.modalClose(); break;
      case 'unlockall': break;
    }
  },
  // ------------------------------------------------------------------ modal
  confirm(title, text, onYes, danger) {
    this.modal.innerHTML = `<div class="modal"><div class="box"><h3>${title}</h3><p style="color:var(--dim)">${text}</p><div class="row" style="justify-content:center"><button class="btn ${danger ? '' : 'pri'}" id="mYes" style="${danger ? 'background:#7a1a1a' : ''}">تأكيد</button><button class="btn" id="mNo">إلغاء</button></div></div></div>`;
    $('#mYes').onclick = () => { this.modalClose(); Audio.sfx('ok'); onYes(); }; $('#mNo').onclick = () => { this.modalClose(); Audio.sfx('back'); };
  },
  modalClose() { this.modal.innerHTML = ''; },
  // ------------------------------------------------------------------ toast / banner
  toast(msg) { const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; const c = $('#toasts'); c.appendChild(t); while (c.children.length > 4) c.firstChild.remove(); setTimeout(() => t.remove(), 3300); },
  banner(msg, dur = 2.4, cls = '') { const b = document.createElement('div'); b.className = 'banner ' + cls; b.textContent = msg; b.style.animationDuration = dur + 's'; this.root.appendChild(b); setTimeout(() => b.remove(), dur * 1000 + 100); },
  hurtFlash() { const h = $('#hurt'); h.classList.add('on'); clearTimeout(this._ht); this._ht = setTimeout(() => h.classList.remove('on'), 90); },
  // ------------------------------------------------------------------ screens
  r_title() {
    const S = Save.d, started = Object.keys(S.completed).length > 0 || S.unlockedStage > 1;
    const done = Object.keys(S.completed).length;
    return `<div class="screen title"><h1 class="logo">ANGER OF STICK 5<small>UNOFFICIAL 3D FAN ADAPTATION</small></h1>
      <div class="sub">لعبة قتال ثلاثية الأبعاد — ${LEVELS.length} مرحلة في ${CHAPTERS.length} فصول · مراحل مكتملة: ${done}/${LEVELS.length}</div>
      <div class="menu">
        <button class="btn pri" data-a="${started ? 'continue' : 'newgame'}">${started ? '▶ متابعة — المرحلة ' + Math.min(S.unlockedStage, LEVELS.length) : '▶ ابدأ اللعب'}</button>
        <button class="btn" data-a="go" data-to="levels">🗺 اختيار المرحلة</button>
        <div class="row" style="flex-wrap:nowrap"><button class="btn" style="flex:1" data-a="go" data-to="shop">🛒 المتجر</button><button class="btn" style="flex:1" data-a="go" data-to="hero">💪 تطوير البطل</button></div>
        <div class="row" style="flex-wrap:nowrap"><button class="btn" style="flex:1" data-a="go" data-to="allies">🤝 الحلفاء</button><button class="btn" style="flex:1" data-a="go" data-to="modes">🎮 أوضاع إضافية</button></div>
        <button class="btn" data-a="go" data-to="settings">⚙ الإعدادات</button>
      </div>
      <div class="sub" style="margin-top:18px;font-size:12px">نسخة معجبين غير رسمية وغير تجارية · جميع الشخصيات والنماذج والأصوات أصلية ومُولَّدة برمجيًا · العملات داخل اللعبة فقط (لا دفع حقيقي)</div></div>`;
  },
  r_levels() {
    const S = Save.d; const lv = LEVEL_BY_ID[this.sel] || LEVELS[0]; if (lv.ch !== this.chap && this._chapSelFor !== this.sel) { }
    const tabs = CHAPTERS.map(c => `<div class="tab ${c.id === this.chap ? 'on' : ''}" data-a="chap" data-i="${c.id}">${c.icon} ${c.name}</div>`).join('');
    const inCh = LEVELS.filter(l => l.ch === this.chap);
    const cards = inCh.map(l => { const lock = l.id > S.unlockedStage, c = S.completed[l.id]; return `<div class="lv ${lock ? 'lock' : ''} ${l.id === this.sel ? 'sel' : ''}" data-a="sel" data-id="${l.id}"><div class="n">${lock ? '🔒' : ''} ${l.id}</div><div class="nm">${l.name}</div>${c ? stars(c.stars) : '<div class="stars"><span class="o">★★★</span></div>'}<div style="font-size:11px;color:var(--dim)">${c ? 'أفضل: ' + fmt(c.best) : lock ? 'مقفلة' : 'جديدة'}</div></div>`; }).join('');
    const sel = LEVEL_BY_ID[this.sel]; const c = S.completed[sel.id]; const ch = CHAPTERS[sel.ch];
    const feats = []; if (sel.segs.some(s => s.boss)) feats.push('👑 زعيم'); if (sel.segs.some(s => s.mech)) feats.push('🤖 روبوت ميكانيكي'); if (sel.segs.some(s => s.cage)) feats.push('🤝 إنقاذ حليف'); if (sel.segs.some(s => s.t === 'building')) feats.push('🏢 مبانٍ قابلة للدخول'); if (sel.segs.some(s => s.t === 'roofs')) feats.push('🌆 قفز'); if (sel.segs.some(s => s.lasers)) feats.push('🔴 ليزر'); if (sel.segs.some(s => s.protect)) feats.push('🛡 حماية'); if (sel.segs.some(s => s.lock)) feats.push('⚔ موجات');
    const en = {}; for (const s of sel.segs) { for (const [k, n] of Object.entries(s.enemies || {})) en[k] = (en[k] || 0) + n; for (const w of s.waves || []) for (const [k, n] of Object.entries(w)) en[k] = (en[k] || 0) + n; }
    const enT = Object.keys(en).map(k => `<span class="tag">${TYPE_AR[k]}</span>`).join('') + (sel.segs.some(s => s.boss) ? `<span class="tag" style="color:#ff8a7a">${BOSSES[sel.segs.find(s => s.boss).boss].name}</span>` : '');
    const rew = sel.rew; const team = S.team.map(id => ALLIES[id].icon + ' ' + ALLIES[id].name).join(' · ') || 'لا يوجد حلفاء بعد';
    return `<div class="screen">${this.head('اختيار المرحلة')}<div class="tabs">${tabs}</div>
      <div class="scroll"><div class="lvgrid">${cards}</div>
      <div class="panel" style="margin-top:12px"><div class="detail"><div><h3 style="margin:0 0 4px">المرحلة ${sel.id}: ${sel.name}</h3><div style="color:var(--dim);font-size:13px">${ch.icon} ${ch.name} · الصعوبة: ${'●'.repeat(Math.min(5, Math.ceil(sel.diff / 2)))}${'○'.repeat(5 - Math.min(5, Math.ceil(sel.diff / 2)))}</div><p style="font-size:14px;line-height:1.7">${sel.intro}</p><div>${feats.map(f => `<span class="tag">${f}</span>`).join('')}</div><div style="margin-top:6px">${enT}</div></div>
      <div><b>الأهداف:</b><ul class="obj">${sel.objectives.map(o => `<li>${o.text}</li>`).join('')}<li>الوصول إلى بوابة الخروج</li></ul>
      <div class="stat"><span>المكافأة</span><b>🪙 ${rew.coins} · XP ${rew.xp}${c ? ' (إعادة: 40%)' : ''}</b></div><div class="stat"><span>أفضل نتيجة</span><b>${c ? stars(c.stars) + ' ' + fmt(c.best) + ' · ' + c.time + 'ث' : '—'}</b></div><div class="stat"><span>الفريق</span><b>${team}</b></div>
      <div class="row" style="margin-top:10px"><button class="btn pri" data-a="play" data-id="${sel.id}" style="flex:1">▶ ابدأ المرحلة</button><button class="btn" data-a="go" data-to="allies">الفريق</button><button class="btn" data-a="go" data-to="shop">الحقيبة</button></div></div></div></div></div></div>`;
  },
  // ---------------- shop
  itemUnlocked(it) { const u = it.unlock; if (u.type === 'start') return true; if (u.type === 'stage') return !!Save.d.completed[u.n]; if (u.type === 'plevel') return Save.d.level >= u.n; return false; },
  itemStats(it, lv) {
    const s = it.stats(lv); const L = [];
    if (it.cat === 'melee') L.push(['الضرر', Math.round(s.dmg)], ['السرعة', s.rate.toFixed(1) + '×'], ['المدى', s.reach + 'م'], s.aoe ? ['نطاق', s.aoe + 'م'] : null);
    else if (it.cat === 'ranged') L.push(['الضرر', s.dmg.toFixed(1) + (s.n > 1 ? ' ×' + s.n : '')], ['الإطلاق', (1 / s.cd).toFixed(1) + '/ث'], ['المدى', s.range + 'م'], s.pierce ? ['اختراق', s.pierce] : null);
    else if (it.cat === 'energy') L.push(['الضرر', Math.round(s.dmg)], ['الطاقة', s.cost], ['التبريد', s.cd + 'ث'], s.radius ? ['نطاق', s.radius + 'م'] : s.jumps ? ['قفزات', s.jumps] : null);
    else { L.push(['التبريد', s.cd + 'ث'], ['المدة', s.dur.toFixed(1) + 'ث']); if (s.absorb) L.push(['امتصاص', s.absorb]); if (s.dmg) L.push(['الضرر', s.dmg.toFixed(1)]); if (s.heal) L.push(['الشفاء', s.heal]); if (s.mult) L.push(['المضاعف', '×' + s.mult.toFixed(2)]); if (s.slow) L.push(['إبطاء', Math.round(s.slow * 100) + '%']); }
    return L.filter(Boolean);
  },
  r_shop() {
    const S = Save.d; const tabs = Object.entries(CATS).map(([k, n]) => `<div class="tab ${k === this.shopTab ? 'on' : ''}" data-a="shoptab" data-t="${k}">${n}</div>`).join('');
    const eq = (id) => id && ITEMS[id] ? `${ITEMS[id].icon} ${ITEMS[id].name} <small>(م${S.items[id].lv})</small>` : '<span style="color:var(--dim)">فارغ</span>';
    const cards = ITEM_ORDER.filter(id => ITEMS[id].cat === this.shopTab).map(id => {
      const it = ITEMS[id], own = S.items[id], un = this.itemUnlocked(it), lv = own ? own.lv : 1, rar = RARITY[it.rarity];
      const stats = this.itemStats(it, lv).map(([k, v]) => `<div class="stat"><span>${k}</span><b>${v}</b></div>`).join('');
      const slot = it.cat === 'melee' || it.cat === 'ranged' ? 'primary' : null; const equipped = Object.values(S.equip).includes(id);
      let act = '';
      if (!own) act = un ? `<button class="btn gold ${S.coins >= it.price ? '' : 'dis'}" data-a="buy" data-id="${id}">شراء 🪙 ${fmt(it.price)}</button>` : `<div style="color:#ff9a7a;font-size:13px">🔒 ${unlockText(it)}</div>`;
      else {
        const maxed = lv >= ITEM_MAX; const cost = itemUpCost(it, lv);
        act = `<div class="row">${slot ? `<button class="btn sm ${S.equip.primary === id ? 'ok' : ''}" data-a="equip" data-id="${id}" data-slot="primary">${S.equip.primary === id ? '✔ مُجهَّز' : 'تجهيز'}</button>` : `<button class="btn sm ${S.equip.a1 === id ? 'ok' : ''}" data-a="equip" data-id="${id}" data-slot="a1">${S.equip.a1 === id ? '✔ خانة 1' : 'خانة 1'}</button><button class="btn sm ${S.equip.a2 === id ? 'ok' : ''}" data-a="equip" data-id="${id}" data-slot="a2">${S.equip.a2 === id ? '✔ خانة 2' : 'خانة 2'}</button>`}
        <button class="btn sm gold ${maxed || S.coins < cost ? 'dis' : ''}" data-a="upg" data-id="${id}">${maxed ? 'أقصى مستوى' : 'ترقية 🪙 ' + fmt(cost)}</button></div>${maxed ? '' : `<div style="font-size:11px;color:var(--cy)">التالي: ${it.nextDesc}</div>`}`;
      }
      return `<div class="card ${own ? '' : 'locked'}">${equipped ? '<span class="eqtag">مُجهَّز</span>' : ''}<h4><span class="ic">${it.icon}</span><span>${it.name}<br><span class="rar" style="color:${rar.c}">${rar.n}</span></span></h4><div style="font-size:12px;color:var(--dim)">${it.desc}</div>${own ? `<div class="pips">${Array.from({ length: ITEM_MAX }, (_, i) => `<i class="${i < lv ? 'on' : ''}"></i>`).join('')}</div>` : ''}${stats}${act}</div>`;
    }).join('');
    return `<div class="screen">${this.head('المتجر والحقيبة')}
      <div class="panel" style="margin-bottom:8px;display:flex;gap:16px;flex-wrap:wrap;font-size:13px"><div>⚔ السلاح: <b>${eq(S.equip.primary)}</b></div><div>[1]: <b>${eq(S.equip.a1)}</b></div><div>[2]: <b>${eq(S.equip.a2)}</b></div></div>
      <div class="tabs">${tabs}</div><div class="scroll"><div class="cards">${cards}</div></div></div>`;
  },
  buy(id) {
    const it = ITEMS[id], S = Save.d; if (S.items[id]) return; if (!this.itemUnlocked(it)) { Audio.sfx('deny'); return; }
    if (S.coins < it.price) { Audio.sfx('deny'); this.toast('العملات غير كافية'); return; }
    S.coins -= it.price; S.items[id] = { lv: 1 }; if ((it.cat === 'melee' || it.cat === 'ranged') && false) S.equip.primary = id;
    Save.commit(true); Audio.sfx('pickup'); this.toast('تم شراء ' + it.name); this.render();
  },
  upgradeItem(id) {
    const it = ITEMS[id], S = Save.d, o = S.items[id]; if (!o || o.lv >= ITEM_MAX) return; const c = itemUpCost(it, o.lv);
    if (S.coins < c) { Audio.sfx('deny'); this.toast('العملات غير كافية'); return; }
    S.coins -= c; o.lv++; Save.commit(true); Audio.sfx('levelup'); this.toast(it.name + ' → المستوى ' + o.lv); if (G.p) G.Player.syncWeapon(); this.render();
  },
  equip(id, slot) {
    const S = Save.d; if (!S.items[id]) return;
    if (slot === 'primary') S.equip.primary = id; else { const other = slot === 'a1' ? 'a2' : 'a1'; if (S.equip[other] === id) S.equip[other] = S.equip[slot]; S.equip[slot] = S.equip[slot] === id ? null : id; }
    Save.commit(true); Audio.sfx('ok'); if (G.p) G.Player.syncWeapon(); this.render();
  },
  // ---------------- hero
  r_hero() {
    const S = Save.d, up = S.upgrades; const need = xpNeeded(S.level);
    const rows = Object.entries(UPGRADES).map(([k, u]) => { const lv = up[k] || 0, max = u.max, cost = upgradeCost(k, lv); return `<div class="card"><h4><span class="ic">${u.icon}</span><span>${u.name}</span><span class="spacer"></span><span style="color:var(--cy)">${lv}/${max}</span></h4><div class="pips">${Array.from({ length: max }, (_, i) => `<i class="${i < lv ? 'on' : ''}"></i>`).join('')}</div><div style="font-size:12px;color:var(--dim)">كل مستوى: ${u.step}</div><button class="btn sm gold ${lv >= max || S.coins < cost ? 'dis' : ''}" data-a="hup" data-k="${k}">${lv >= max ? 'أقصى مستوى' : 'ترقية 🪙 ' + fmt(cost)}</button></div>`; }).join('');
    const maxHp = 100 + 14 * (up.hp || 0) + 6 * (S.level - 1), en = 100 + 12 * (up.energy || 0), dm = (1 + 0.06 * (up.dmg || 0)) * (1 + 0.03 * (S.level - 1));
    return `<div class="screen">${this.head('تطوير البطل')}<div class="scroll">
      <div class="panel" style="margin-bottom:10px"><div class="row"><div style="font-size:34px">🥷</div><div style="flex:1;min-width:220px"><b>المستوى ${S.level}</b> <span style="color:var(--dim);font-size:13px">— الخبرة ${fmt(S.xp)}/${fmt(need)}</span><div class="bar xp" style="margin-top:6px"><i style="width:${Math.min(100, S.xp / need * 100)}%"></i></div></div></div>
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr));margin-top:10px;font-size:13px"><div class="stat" style="flex-direction:column">❤ الصحة<b>${maxHp}</b></div><div class="stat" style="flex-direction:column">🔋 الطاقة<b>${en}</b></div><div class="stat" style="flex-direction:column">💥 مضاعف الضرر<b>×${dm.toFixed(2)}</b></div><div class="stat" style="flex-direction:column">👟 السرعة<b>×${(1 + 0.03 * (up.speed || 0)).toFixed(2)}</b></div><div class="stat" style="flex-direction:column">🧥 تقليل الضرر<b>${Math.round((1 - Math.max(0.35, 1 - 0.03 * (up.armor || 0))) * 100)}%</b></div><div class="stat" style="flex-direction:column">★ التحوّل<b>${S.titan ? 'مفتوح' : 'أكمل المرحلة 6'}</b></div></div>
      <div style="font-size:12px;color:var(--dim);margin-top:8px">كل مستوى لاعب: +6 صحة و+3% ضرر. الخبرة تأتي من هزيمة الأعداء وإكمال المراحل.</div></div>
      <div class="cards">${rows}</div></div></div>`;
  },
  upgradeHero(k) {
    const S = Save.d, u = UPGRADES[k], lv = S.upgrades[k] || 0; if (lv >= u.max) return; const c = upgradeCost(k, lv);
    if (S.coins < c) { Audio.sfx('deny'); this.toast('العملات غير كافية'); return; }
    S.coins -= c; S.upgrades[k] = lv + 1; Save.commit(true); Audio.sfx('levelup'); this.toast(u.name + ' → ' + (lv + 1)); if (G.p) G.Player.recompute(false); this.render();
  },
  // ---------------- allies
  r_allies() {
    const S = Save.d;
    const slots = [0, 1, 2].map(i => { const id = S.team[i]; return `<div class="card" style="align-items:center;min-height:70px;justify-content:center">${id ? `<div class="ic">${ALLIES[id].icon}</div><b>${ALLIES[id].name}</b>` : '<span style="color:var(--dim)">خانة فارغة</span>'}</div>`; }).join('');
    const cards = ALLY_ORDER.map(id => {
      const d = ALLIES[id], own = S.allies[id], lv = own ? own.lv : 1, st = allyStat(d, lv), inTeam = S.team.includes(id);
      const cost = allyUpCost(d, lv);
      return `<div class="card ${own ? '' : 'locked'}"><h4><span class="ic" style="border-color:${d.color}">${d.icon}</span><span>${d.name}<br><span class="rar" style="color:${d.color}">${d.role}</span></span></h4><div style="font-size:12px;color:var(--dim)">${d.desc}</div><div style="font-size:12px;color:var(--cy)">✦ ${d.trait}</div>
        <div class="stat"><span>المستوى</span><b>${lv}/${ALLY_MAX}</b></div><div class="stat"><span>الصحة</span><b>${Math.round(st.hp)}</b></div><div class="stat"><span>الضرر</span><b>${Math.round(st.dmg)}</b></div>
        ${own ? `<div class="row"><button class="btn sm ${inTeam ? 'ok' : ''}" data-a="team" data-id="${id}">${inTeam ? '✔ في الفريق' : 'إضافة للفريق'}</button><button class="btn sm gold ${lv >= ALLY_MAX || S.coins < cost ? 'dis' : ''}" data-a="aup" data-id="${id}">${lv >= ALLY_MAX ? 'أقصى' : 'ترقية 🪙 ' + fmt(cost)}</button></div>` : `<div style="color:#ff9a7a;font-size:13px">🔒 حرّره في المرحلة ${d.unlockStage}</div>`}</div>`;
    }).join('');
    return `<div class="screen">${this.head('الحلفاء والفريق')}<div class="scroll"><div style="margin-bottom:6px;font-size:13px;color:var(--dim)">اختر حتى 3 حلفاء يرافقونك في المراحل.</div><div class="grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:12px">${slots}</div><div class="cards">${cards}</div></div></div>`;
  },
  toggleTeam(id) { const S = Save.d; const i = S.team.indexOf(id); if (i >= 0) S.team.splice(i, 1); else { if (S.team.length >= 3) { this.toast('الفريق ممتلئ (3 كحد أقصى)'); Audio.sfx('deny'); return; } S.team.push(id); } Save.commit(true); Audio.sfx('click'); this.render(); },
  upgradeAlly(id) { const S = Save.d, d = ALLIES[id], o = S.allies[id]; if (!o || o.lv >= ALLY_MAX) return; const c = allyUpCost(d, o.lv); if (S.coins < c) { Audio.sfx('deny'); this.toast('العملات غير كافية'); return; } S.coins -= c; o.lv++; Save.commit(true); Audio.sfx('levelup'); this.toast(d.name + ' → المستوى ' + o.lv); this.render(); },
  // ---------------- modes
  r_modes() {
    const S = Save.d, ok = S.unlockedStage > MODE_UNLOCK; const m = S.modes;
    const lock = ok ? '' : `<div style="color:#ff9a7a;font-size:13px">🔒 أكمل المرحلة 1 لفتح الأوضاع</div>`;
    const dis = ok ? '' : 'dis';
    const towers = [['easy', 'برج المبتدئ', '12 منصة'], ['mid', 'برج المحترف', '20 منصة'], ['hard', 'برج الجحيم', '30 منصة']].map(([k, n, d]) => `<button class="btn sm ${dis}" data-a="mode" data-m="jump" data-v="${k}">${n} <small>(${d}) ${m.jump.best[k] ? '· ' + m.jump.best[k] + 'ث' : ''}</small></button>`).join('');
    return `<div class="screen">${this.head('الأوضاع الإضافية')}<div class="scroll"><div class="cards" style="grid-template-columns:repeat(auto-fill,minmax(300px,1fr))">
      <div class="card"><h4><span class="ic">🧟</span>وضع الزومبي</h4><div style="font-size:13px;color:var(--dim)">موجات لا نهائية متصاعدة من الزومبي والمتحوّرين في ساحة مغلقة. يتصاعد العدد والصلابة كل موجة وتظهر مكافآت بين الموجات. تنتهي المحاولة بموتك.</div><div class="stat"><span>أفضل موجة</span><b>${m.zombie.best}</b></div><div class="stat"><span>المحاولات</span><b>${m.zombie.runs}</b></div>${lock}<button class="btn pri ${dis}" data-a="mode" data-m="zombie">ابدأ</button></div>
      <div class="card"><h4><span class="ic">🗼</span>وضع القفز (البرج)</h4><div style="font-size:13px;color:var(--dim)">تحدٍّ عمودي: اصعد إلى القمة عبر منصات متحرّكة ومنهارة وعوارض دوّارة ونوابض قفز. السقوط يعيدك إلى آخر نقطة حفظ. السجل بالزمن.</div>${lock}<div class="grid">${towers}</div></div>
      <div class="card"><h4><span class="ic">🛡</span>وضع الدفاع</h4><div style="font-size:13px;color:var(--dim)">احمِ القاعدة (نواة الطاقة) من 8 موجات متنوعة تهاجم من الجهتين. للقاعدة صحة خاصة؛ إن سقطت أو متّ تخسر. الفوز يمنحك مكافآت كبيرة.</div><div class="stat"><span>أفضل موجة</span><b>${m.defense.best}/8</b></div>${lock}<button class="btn pri ${dis}" data-a="mode" data-m="defense">ابدأ</button></div>
      </div></div></div>`;
  },
  // ---------------- settings
  r_settings(args) {
    const s = Save.d.settings; const k = s.keys; const touchLbl = { auto: 'تلقائي', on: 'مفعّلة', off: 'معطّلة' };
    const keyRows = Object.keys(KEY_LABELS).map(a => `<div class="set"><label>${KEY_LABELS[a]}</label><button class="key ${G.rebinding === a ? 'wait' : ''}" data-a="rebind" data-k="${a}">${G.rebinding === a ? 'اضغط مفتاحًا…' : esc(keyName(k[a] || DEFAULT_KEYS[a]))}</button></div>`).join('');
    return `<div class="screen">${this.head('الإعدادات')}<div class="scroll"><div class="panel">
      <div class="set"><label>🎵 صوت الموسيقى</label><input type="range" min="0" max="100" value="${Math.round(s.music * 100)}" oninput="window.__setvol('music',this.value)"></div>
      <div class="set"><label>🔊 صوت المؤثرات</label><input type="range" min="0" max="100" value="${Math.round(s.sfx * 100)}" oninput="window.__setvol('sfx',this.value)"></div>
      <div class="set"><label>🎨 جودة الرسوميات<small>تؤثر على الظلال والجسيمات والإضاءة والدقة</small></label><select onchange="window.__setopt('quality',this.value)">${['auto', 'low', 'med', 'high'].map(q => `<option value="${q}" ${s.quality === q ? 'selected' : ''}>${{ auto: 'تلقائي', low: 'منخفضة', med: 'متوسطة', high: 'عالية' }[q]}</option>`).join('')}</select></div>
      <div class="set"><label>📱 أزرار اللمس<small>عصا تحكم وأزرار على الشاشة</small></label><select onchange="window.__setopt('touch',this.value)">${['auto', 'on', 'off'].map(q => `<option value="${q}" ${s.touch === q ? 'selected' : ''}>${touchLbl[q]}</option>`).join('')}</select></div>
      <div class="set"><label>🎥 منظور الكاميرا<small>الشخص الثالث: كاميرا خلف البطل (الفأرة/السحب/Q-E للتدوير)</small></label><select onchange="window.__setopt('view',this.value)">${[['third', 'الشخص الثالث'], ['classic', 'كلاسيكي (جانبي علوي)']].map(([q, n]) => `<option value="${q}" ${(s.view || 'third') === q ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
      <div class="set"><label>🖱 حساسية الكاميرا</label><input type="range" min="30" max="250" value="${Math.round((s.camSens || 1) * 100)}" oninput="window.__setsens(this.value)"></div>
      <div class="set"><label>📳 اهتزاز الكاميرا</label><div class="toggle ${s.shake !== false ? 'on' : ''}" data-a="setopt" data-k="shake" data-v="${s.shake !== false ? 0 : 1}"></div></div>
      <div class="set"><label>🎯 التصويب التلقائي<small>يوجّه الضربات نحو أقرب عدو</small></label><div class="toggle ${s.autoAim !== false ? 'on' : ''}" data-a="setopt" data-k="autoAim" data-v="${s.autoAim !== false ? 0 : 1}"></div></div>
    </div><h3>⌨ أزرار لوحة المفاتيح</h3><div class="panel">${keyRows}<div class="row" style="margin-top:10px"><button class="btn sm" data-a="resetkeys">استعادة الافتراضي</button></div><div style="font-size:12px;color:var(--dim);margin-top:8px">الفأرة: زر أيسر = هجوم · زر أيمن = تفادي. الأسهم تعمل كبديل للحركة.</div></div>
    <h3>💾 البيانات</h3><div class="panel"><div class="row"><button class="btn" style="background:#5a1a1a" data-a="resetsave">🗑 مسح كل التقدّم</button><span style="font-size:12px;color:var(--dim)">${Save.ok ? 'الحفظ التلقائي يعمل (المتصفح)' : '⚠ الحفظ الدائم غير متاح — الحفظ مؤقت'}</span></div></div></div></div>`;
  },
  setOpt(k, v) {
    const s = Save.d.settings; if (k === 'shake' || k === 'autoAim') s[k] = !!+v; else s[k] = v; Save.commit(); Audio.sfx('click');
    if (k === 'quality') G.Game.applyQuality(); if (k === 'touch') Input.showTouch(G.state === 'play'); this.render();
  },
  // ---------------- pause
  pause() {
    if (G.state !== 'play' || this.paused || !G.run || G.run.state === 'complete') return; this.paused = true; G.state = 'paused'; Input.flush();
    this.scr.innerHTML = `<div class="screen clear"><div class="panel res"><h2 style="margin-top:0">⏸ إيقاف مؤقت</h2><div class="stat"><span>المرحلة</span><b>${G.run.spec.name}</b></div><div class="stat"><span>الهدف الحالي</span><b>${G.run.current() ? G.run.current().text : 'اذهب إلى المخرج'}</b></div><div class="menu" style="margin:14px auto 0"><button class="btn pri" data-a="resume">▶ استئناف</button><button class="btn" data-a="restart">↻ إعادة المرحلة</button><button class="btn" data-a="pset">⚙ الإعدادات</button><button class="btn" data-a="quit">⌂ القائمة الرئيسية</button></div></div></div>`;
    this.cur = null; Audio.sfx('click');
    this.scr.querySelector('[data-a=pset]').onclick = () => { this.cur = { name: 'settings' }; this.stack = [{ name: '__pause' }]; this.render(); };
  },
  resume() { if (!this.paused) return; this.paused = false; this.scr.innerHTML = ''; this.cur = null; G.state = 'play'; Input.flush(); this.hudShow(true); Audio.sfx('ok'); },
  // ------------------------------------------------------------------ results / fail
  showResults(r, run) {
    G.state = 'result'; Input.showTouch(false); this.hudShow(false);
    const fm = (t) => Math.floor(t / 60) + ':' + String(Math.floor(t % 60)).padStart(2, '0');
    const has = LEVEL_BY_ID[r.id + 1] && r.mode === 'story';
    this.scr.innerHTML = `<div class="screen clear"><div class="panel res"><div class="big" style="color:${r.win === false ? '#ff9a6a' : '#6aff9a'}">${r.mode === 'story' ? 'اكتملت المرحلة!' : (r.title || 'انتهى التحدي!')}</div><div class="st">${'★'.repeat(r.stars)}<span style="color:#444">${'★'.repeat(3 - r.stars)}</span></div><div style="color:var(--dim)">${r.name}</div>
      <table>${(r.rows || []).map(([a, b]) => `<tr><td>${a}</td><td>${b}</td></tr>`).join('')}<tr><td>الزمن</td><td>${fm(r.time)} (الهدف ${fm(r.par)})</td></tr><tr><td>الأعداء المهزومون</td><td>${r.kills}</td></tr><tr><td>الضرر المستلم</td><td>${r.taken}</td></tr><tr><td>مرات السقوط</td><td>${r.deaths}</td></tr><tr><td>عملات جمعتها</td><td>🪙 ${fmt(r.coinsPicked)}</td></tr><tr><td>مكافأة المرحلة${r.first ? '' : ' (إعادة)'}</td><td>🪙 ${fmt(r.rewardCoins)} · XP ${fmt(r.rewardXp)}</td></tr><tr><td>النتيجة</td><td>${fmt(r.score)} ${r.newBest ? '🏆 رقم قياسي!' : '(الأفضل ' + fmt(r.best) + ')'}</td></tr></table>
      ${(r.unlocks || []).map(u => `<div class="unl">🔓 ${u}</div>`).join('')}
      <div class="row" style="justify-content:center;margin-top:10px">${has ? '<button class="btn pri" data-a="next">المرحلة التالية ▶</button>' : ''}<button class="btn" data-a="restart">↻ إعادة للحصول على نتيجة أفضل</button><button class="btn" data-a="menu">القائمة</button></div></div></div>`;
    this.cur = null;
  },
  showFail(run) {
    G.state = 'result'; Input.showTouch(false);
    const prot = run.failMsg; const canCp = !prot;
    this.scr.innerHTML = `<div class="screen clear"><div class="panel res"><div class="big" style="color:#ff6a6a">${prot ? 'فشلت المهمة' : 'سقطت في المعركة'}</div><p style="color:var(--dim)">${prot || 'لا بأس — الأبطال ينهضون من جديد.'}</p>
      <div class="menu" style="margin:10px auto 0">${canCp ? '<button class="btn pri" data-a="respawn">↺ المتابعة من آخر نقطة حفظ</button>' : ''}<button class="btn" data-a="restart">↻ إعادة المرحلة من البداية</button><button class="btn" data-a="menu">⌂ القائمة</button></div></div></div>`;
    this.cur = null; run.failShown = true;
  },
  onRespawn() { G.state = 'play'; Input.flush(); this.hudShow(true); this.scr.innerHTML = ''; },
  // ------------------------------------------------------------------ HUD
  hudShow(v) { const h = $('#hud'); if (h) h.classList.toggle('hidden', !v); Input.showTouch(!!v); },
  onRunBegin(run) {
    const hud = $('#hud'); this.hud = hud; const isT = Input.isTouch();
    hud.innerHTML = `<div class="hudtl"><div class="lvl"><span id="hLv"></span><span id="hName"></span></div><div class="bar"><i id="hHp" style="width:100%"></i><span id="hHpT"></span></div><div class="bar en sm"><i id="hEn" style="width:100%"></i></div><div class="bar rg sm" id="hRgW"><i id="hRg" style="width:0"></i></div><div class="bar xp sm" style="opacity:.7"><i id="hXp"></i></div></div>
      <div class="hudtr"><span class="pill" id="hCoin">🪙 0</span><span class="pill" id="hTime">0:00</span><button class="hudbtn" data-a="hpause">⏸</button></div>
      <div class="obj" id="hObj"><small id="hObjS"></small><span id="hObjT"></span></div>
      <div class="bossbar hidden" id="hBoss"><div id="hBossN"></div><div class="ph" id="hBossP"></div><div class="bar"><i id="hBossB" style="width:100%"></i></div></div>
      <div class="protbar hidden" id="hProt"><div id="hProtT"></div><div class="bar"><i id="hProtB"></i></div></div>
      <div class="abil"><div class="slot" id="hW"><span id="hWi"></span><span class="k" id="hWk"></span></div><div class="slot" id="hA1"><span id="hA1i"></span><div class="cdm" id="hA1c"></div><span class="k" id="hA1k"></span></div><div class="slot" id="hA2"><span id="hA2i"></span><div class="cdm" id="hA2c"></div><span class="k" id="hA2k"></span></div><div class="slot hidden" id="hTr"><span>★</span><span class="k" id="hTrk"></span></div></div>
      <div class="prompt hidden" id="hPrompt"></div><div class="arrow hidden" id="hArrow"></div>`;
    hud.querySelector('[data-a=hpause]').classList.add('hudbtn'); hud.querySelector('[data-a=hpause]').onclick = () => this.pause();
    hud.querySelectorAll('.abil .slot').forEach(s => { s.style.pointerEvents = 'auto'; });
    $('#hLv').textContent = run.mode ? 'تحدٍّ' : 'المرحلة ' + run.id; $('#hName').textContent = run.spec.name; this._hc = {};
    // intro banner
    const ch = CHAPTERS[run.spec.ch]; const el = document.createElement('div'); el.className = 'intro'; el.innerHTML = `<div class="ch">${run.mode ? '🏆 تحدٍّ إضافي' : ch ? ch.icon + ' ' + ch.name : ''}</div><div class="t">${run.mode ? '' : run.id < 100 ? run.id + ' — ' : ''}${run.spec.name}</div><div class="d">${run.spec.intro || (run.mode && run.mode.intro) || ''}</div>`; this.root.appendChild(el); setTimeout(() => el.remove(), 3300);
    this.hudShow(true); this.scr.innerHTML = ''; this.cur = null; this.stack = [];
    if (isT) document.body.classList.add('touch-hud');
  },
  onIntroEnd() {}, hideAbilityTips() {},
  objectiveDone(o) { this.toast('✔ ' + o.text); },
  bossIntro(def) { this.banner(def.name, 3, 'boss'); setTimeout(() => this.banner(def.intro || '', 2.6), 1200); const b = $('#hBoss'); if (b) { b.classList.remove('hidden'); $('#hBossN').textContent = '👑 ' + def.name; } },
  bossBar(v) {},
  setPrompt(text, it) {
    const p = $('#hPrompt'); if (!p) return; if (!text) { if (!p.classList.contains('hidden')) p.classList.add('hidden'); this._pt = null; return; }
    if (this._pt !== text) { this._pt = text; const k = keyName(Save.d.settings.keys.interact); p.innerHTML = Input.isTouch() && G.lastDevice === 'touch' ? esc(text) : `<b>${esc(k)}</b>${esc(text)}`; } p.classList.remove('hidden');
    const t = $('#tInt'); if (t) t.classList.toggle('hidden', false);
  },
  setHud(id, key, val, fn) { if (this._hc[id + key] !== val) { this._hc[id + key] = val; fn(val); } },
  updateHud(dt) {
    const run = G.run, P = G.p; if (!run || !P || !this.hud || this.hud.classList.contains('hidden')) return; const c = this._hc;
    const S = Save.d; const hpv = P.form === 'mech' ? P.mechHp : P.hp, hpm = P.form === 'mech' ? P.mechMax : P.maxHp;
    const set = (id, v, f) => { if (c[id] !== v) { c[id] = v; f(v); } };
    set('hp', Math.round(hpv / hpm * 100) + P.form, () => { $('#hHp').style.width = Math.max(0, hpv / hpm * 100) + '%'; $('#hHpT').textContent = (P.form === 'mech' ? '🤖 ' : '❤ ') + Math.ceil(hpv) + '/' + Math.ceil(hpm); $('#hHp').style.background = P.form === 'mech' ? 'linear-gradient(90deg,#ff8a1f,#ffc46a)' : P.form === 'titan' ? 'linear-gradient(90deg,#4ad8ff,#7affea)' : ''; });
    set('en', Math.round(P.energy), () => { $('#hEn').style.width = P.energy / P.maxEnergy * 100 + '%'; });
    set('rg', Math.round(P.rage) + (S.titan ? 1 : 0), () => { const w = $('#hRgW'); w.style.display = S.titan ? '' : 'none'; $('#hRg').style.width = P.rage + '%'; });
    const need = xpNeeded(S.level); set('xp', Math.round(S.xp / need * 100) + '_' + S.level, () => { $('#hXp').style.width = S.xp / need * 100 + '%'; $('#hLv').textContent = (run.mode ? 'تحدٍّ' : 'المرحلة ' + run.id) + ' · مستوى ' + S.level; });
    set('coin', run.coins + '|' + S.coins, () => { $('#hCoin').textContent = '🪙 ' + run.coins; });
    const tm = Math.floor(run.time); set('time', tm, () => { $('#hTime').textContent = Math.floor(tm / 60) + ':' + String(tm % 60).padStart(2, '0'); });
    // objective
    const cur = run.current(); let ot, os = 'الهدف'; if (cur) { ot = cur.text; if (cur.n) ot += ' — ' + (cur.cur || 0) + '/' + cur.n; if (cur.type === 'protect' && run.protectActive) ot = 'احمِ الجهاز: ' + Math.ceil(run.protectLeft) + 'ث'; } else { ot = run.noExit ? (run.mode ? run.mode.hudText && run.mode.hudText() : '') : (run.exitOpen ? 'اذهب إلى بوابة الخروج ➜' : '…'); os = 'اكتملت الأهداف'; }
    if (run.mode && run.mode.hudText && !cur) { ot = run.mode.hudText(); os = run.mode.title || os; }
    set('obj', ot + os, () => { $('#hObjT').textContent = ot; $('#hObjS').textContent = os; $('#hObj').classList.toggle('done', !cur); });
    // boss bar
    const b = run.boss; const bb = $('#hBoss'); if (b && run.bossStarted && !b.dead) { bb.classList.remove('hidden'); set('boss', Math.round(b.hp / b.maxHp * 200) + (b.shielded ? 's' : '') + b.phase, () => { $('#hBossB').style.width = b.hp / b.maxHp * 100 + '%'; $('#hBossB').style.background = b.shielded ? 'linear-gradient(90deg,#4affee,#2a9a9a)' : ''; $('#hBossP').textContent = (b.shielded ? '🛡 محمي بالأبراج — دمّرها · ' : '') + 'المرحلة ' + (b.phase + 1) + (b.def.phases ? '/' + b.def.phases.length : ''); }); } else if (!bb.classList.contains('hidden')) bb.classList.add('hidden');
    const pr = $('#hProt'); const po = run.protectObj; if (po && run.protectActive) { pr.classList.remove('hidden'); set('prot', Math.round(po.hp) + '|' + Math.ceil(run.protectLeft) + '|' + (run.mode ? run.mode.wave : ''), () => { $('#hProtT').textContent = run.mode && run.mode.protText ? '🛡 النواة: ' + Math.max(0, Math.ceil(po.hp)) + ' — ' + run.mode.protText() : '⚡ المولّد/الجهاز: ' + Math.max(0, Math.ceil(po.hp)) + ' — الوقت ' + Math.ceil(run.protectLeft) + 'ث'; $('#hProtB').style.width = Math.max(0, po.hp / po.maxHp * 100) + '%'; }); } else if (po && run.mode && run.mode.coreHud) { pr.classList.remove('hidden'); set('prot2', Math.round(po.hp), () => { $('#hProtT').textContent = '🛡 نواة القاعدة: ' + Math.max(0, Math.ceil(po.hp)) + '/' + po.maxHp; $('#hProtB').style.width = Math.max(0, po.hp / po.maxHp * 100) + '%'; }); } else if (!pr.classList.contains('hidden')) pr.classList.add('hidden');
    // slots
    const K = S.settings.keys; const kn = (a) => keyName(K[a]);
    let w = G.Player.weaponItem(), i1 = '—', i2 = '—', n1 = '', n2 = '', c1 = 0, c2 = 0, r1 = false, r2 = false, wi = w.icon, wn = w.name;
    if (P.form === 'titan') { wi = '👊'; wn = 'العملاق'; i1 = '💥'; n1 = 'دهس'; i2 = '📢'; n2 = 'زئير'; r1 = P.cd.a1 <= 0; r2 = P.cd.a2 <= 0; c1 = P.cd.a1 / P.cdMax.a1; c2 = P.cd.a2 / P.cdMax.a2; }
    else if (P.form === 'mech') { wi = '🔫'; wn = 'مدفع'; i1 = '🦶'; n1 = 'دهس'; i2 = '🚀'; n2 = 'صواريخ'; r1 = P.cd.a1 <= 0; r2 = P.cd.a2 <= 0; c1 = P.cd.a1 / P.cdMax.a1; c2 = P.cd.a2 / P.cdMax.a2; }
    else { for (const [slot, n] of [['a1', 1], ['a2', 2]]) { const id = S.equip[slot]; const it = id && ITEMS[id]; const cd = P.cd[slot], mx = P.cdMax[slot] || 1; const cost = it ? it.stats(S.items[id].lv).cost || 0 : 0; const ready = it && cd <= 0 && P.energy >= cost; if (n === 1) { i1 = it ? it.icon : '＋'; n1 = it ? it.name : ''; c1 = cd > 0 ? cd / mx : 0; r1 = ready; } else { i2 = it ? it.icon : '＋'; n2 = it ? it.name : ''; c2 = cd > 0 ? cd / mx : 0; r2 = ready; } } }
    set('slots', [wi, i1, i2, Math.round(c1 * 20), Math.round(c2 * 20), r1, r2, P.form].join(','), () => {
      $('#hWi').textContent = wi; $('#hWk').textContent = kn('attack'); $('#hW').title = wn; $('#hA1i').textContent = i1; $('#hA2i').textContent = i2; $('#hA1k').textContent = kn('a1'); $('#hA2k').textContent = kn('a2');
      $('#hA1c').style.height = c1 * 100 + '%'; $('#hA2c').style.height = c2 * 100 + '%'; $('#hA1').className = 'slot ' + (r1 ? 'rdy' : ''); $('#hA2').className = 'slot ' + (r2 ? 'rdy' : '');
      $('#tA1') && ($('#tA1').textContent = i1); $('#tA2') && ($('#tA2').textContent = i2);
    });
    const trOn = S.titan && P.form === 'hero' && P.rage >= 100; set('tr', trOn + '' + kn('transform'), () => { $('#hTr').classList.toggle('hidden', !trOn); $('#hTrk').textContent = kn('transform'); $('#tTr') && $('#tTr').classList.toggle('hidden', !trOn); });
    // goal arrow
    const g = run.state === 'play' ? run.goal() : null; const ar = $('#hArrow');
    if (g && G.stage) {
      const dd = Math.hypot(g.x - P.x, g.z - P.z); const v = G.stage.toScreen(g.x, (g.y || 0) + 2.2, g.z);
      if (dd < 4.5) ar.classList.add('hidden');
      else if (!v && Cam.isThird()) { const b = Cam.basis(), ddx = g.x - P.x, ddz = g.z - P.z; const rx = ddx * b.rx + ddz * b.rz, fz = ddx * b.fx + ddz * b.fz; const w = innerWidth, h = innerHeight, cx = w / 2, cy = h / 2; let dx = rx, dy = -fz; const k = Math.min((w / 2 - 44) / Math.abs(dx || 1e-3), (h / 2 - 110) / Math.abs(dy || 1e-3)); ar.style.left = cx + dx * k + 'px'; ar.style.top = cy + dy * k + 'px'; ar.style.transform = `rotate(${Math.atan2(dy, dx)}rad)`; ar.innerHTML = '➜<small>' + Math.round(dd) + 'م</small>'; ar.classList.remove('hidden'); }
      else if (v) { const w = innerWidth, h = innerHeight; let sx = (v.x * 0.5 + 0.5) * w, sy = (-v.y * 0.5 + 0.5) * h; const inside = sx > 40 && sx < w - 40 && sy > 90 && sy < h - 110; if (!inside) { const cx = w / 2, cy = h / 2; let dx = sx - cx, dy = sy - cy; const k = Math.min((w / 2 - 44) / Math.abs(dx || 1e-3), (h / 2 - 110) / Math.abs(dy || 1e-3)); sx = cx + dx * k; sy = cy + dy * k; ar.textContent = dx > 0 ? '➜' : '➜'; ar.style.transform = `rotate(${Math.atan2(dy, dx)}rad)`; } else { ar.textContent = '▼'; ar.style.transform = 'none'; sy -= 8 + 4 * Math.sin(G.t * 6); }
        ar.style.left = sx + 'px'; ar.style.top = sy + 'px'; ar.innerHTML = ar.textContent + `<small>${Math.round(dd)}م</small>`; ar.classList.remove('hidden'); }
      else ar.classList.add('hidden');
    } else ar.classList.add('hidden');
  },
  refreshHud() { if (this._hc) this._hc = {}; },
};
window.__setsens = (v) => { Save.d.settings.camSens = v / 100; Save.commit(); };
window.__setvol = (k, v) => { Save.d.settings[k] = v / 100; Save.commit(); Audio.setVolumes(Save.d.settings.music, Save.d.settings.sfx); if (k === 'sfx') Audio.sfx('coin'); };
window.__setopt = (k, v) => UI.setOpt(k, v);
