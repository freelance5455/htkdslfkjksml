// Visual effects: GPU-point particles (additive + normal), ground rings, telegraphs, beams, floating numbers.
import * as THREE from 'three';
import { G } from './ctx.js';
import { rad, TAU } from './util.js';

const VS = `attribute float size; attribute float alpha; attribute vec3 col; varying float vA; varying vec3 vC; uniform float scale;
void main(){ vA = alpha; vC = col; vec4 mv = modelViewMatrix*vec4(position,1.0); gl_Position = projectionMatrix*mv; gl_PointSize = size*scale/(-mv.z); }`;
const FS = `varying float vA; varying vec3 vC; void main(){ vec2 c = gl_PointCoord-0.5; float d = length(c); if(d>0.5) discard; float a = smoothstep(0.5,0.1,d)*vA; gl_FragColor = vec4(vC, a); }`;

class Pool {
  constructor(scene, n, additive) {
    this.n = n; this.i = 0;
    const g = new THREE.BufferGeometry();
    this.pos = new Float32Array(n * 3); this.col = new Float32Array(n * 3); this.size = new Float32Array(n); this.alpha = new Float32Array(n);
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('col', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('size', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('alpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    this.mat = new THREE.ShaderMaterial({ vertexShader: VS, fragmentShader: FS, transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, uniforms: { scale: { value: 600 } }, fog: false });
    this.pts = new THREE.Points(g, this.mat); this.pts.frustumCulled = false; scene.add(this.pts);
    this.p = Array.from({ length: n }, () => ({ life: 0, max: 1, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, g: 0, s0: 0.2, s1: 0, r: 1, gc: 1, b: 1, drag: 0 }));
    this.geo = g;
  }
  spawn(o) {
    const p = this.p[this.i]; this.i = (this.i + 1) % this.n;
    p.life = p.max = o.life; p.x = o.x; p.y = o.y; p.z = o.z; p.vx = o.vx; p.vy = o.vy; p.vz = o.vz; p.g = o.g || 0; p.s0 = o.s0; p.s1 = o.s1 ?? 0; p.r = o.r; p.gc = o.gc; p.b = o.b; p.drag = o.drag || 0;
  }
  update(dt) {
    const P = this.p;
    for (let i = 0; i < this.n; i++) {
      const p = P[i];
      if (p.life <= 0) { this.alpha[i] = 0; this.size[i] = 0; continue; }
      p.life -= dt; const u = 1 - Math.max(0, p.life) / p.max;
      p.vy += p.g * dt; const dr = Math.max(0, 1 - p.drag * dt); p.vx *= dr; p.vz *= dr; p.vy *= (p.drag ? dr : 1);
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      this.pos[i * 3] = p.x; this.pos[i * 3 + 1] = p.y; this.pos[i * 3 + 2] = p.z;
      this.col[i * 3] = p.r; this.col[i * 3 + 1] = p.gc; this.col[i * 3 + 2] = p.b;
      this.size[i] = p.s0 + (p.s1 - p.s0) * u; this.alpha[i] = (1 - u) * (1 - u * 0.3);
    }
    const a = this.geo.attributes; a.position.needsUpdate = a.col.needsUpdate = a.size.needsUpdate = a.alpha.needsUpdate = true;
  }
}
const _c = new THREE.Color();
const ringGeo = new THREE.RingGeometry(0.9, 1, 40).rotateX(-Math.PI / 2);
const discGeo = new THREE.CircleGeometry(1, 36).rotateX(-Math.PI / 2);
const boxGeo = new THREE.BoxGeometry(1, 1, 1);
const addMat = (c, o = 0.8) => new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: o, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });

export class FX {
  constructor(stage) {
    this.stage = stage; this.scene = stage.scene; this.t = 0;
    const q = stage.q; this.setQuality(q);
    this.rings = []; this.tele = []; this.beams = []; this.texts = []; this.free = { ring: [], tele: [], beam: [] };
    this.root = document.getElementById('floaters') || (() => { const d = document.createElement('div'); d.id = 'floaters'; document.getElementById('ui').appendChild(d); return d; })();
    this.shake = 0; this.hitstop = 0;
  }
  setQuality(q) {
    if (this.A) { this.scene.remove(this.A.pts); this.scene.remove(this.N.pts); }
    const n = q.particles; this.q = q;
    this.A = new Pool(this.scene, n, true); this.N = new Pool(this.scene, Math.round(n * 0.6), false);
  }
  _c(c) { _c.setHex(c); return _c; }
  emit(pool, x, y, z, c, n, o = {}) {
    n = Math.max(1, Math.round(n * (this.q.fxScale || 1)));
    const col = this._c(c);
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU, sp = (o.speed ?? 3) * (0.4 + Math.random() * 0.8), up = o.up ?? 0.5;
      const cc = o.vary ? col.clone().offsetHSL(0, 0, (Math.random() - 0.5) * 0.2) : col;
      pool.spawn({ x: x + (Math.random() - 0.5) * (o.spread || 0), y: y + (Math.random() - 0.5) * (o.spread || 0), z: z + (Math.random() - 0.5) * (o.spread || 0),
        vx: Math.cos(a) * sp * (o.flat ? 1 : 0.8) + (o.vx || 0), vy: (Math.random() * 1.2 * sp * up) + (o.vy || 0), vz: Math.sin(a) * sp * (o.flat ? 1 : 0.8) + (o.vz || 0), g: o.g ?? -6, life: (o.life ?? 0.5) * (0.6 + Math.random() * 0.7), s0: o.size ?? 0.3, s1: o.size1 ?? 0, r: cc.r, gc: cc.g, b: cc.b, drag: o.drag || 0 });
    }
  }
  spark(x, y, z, c = 0xffd860, n = 8, o = {}) { this.emit(this.A, x, y, z, c, n, { speed: 5, life: 0.35, size: 0.22, g: -10, ...o }); }
  puff(x, y, z, c = 0xcfd6dc, n = 1) { this.emit(this.N, x, y, z, c, n, { speed: 0.7, up: 1.2, life: 1.0, size: 0.5, size1: 1.4, g: 0.6, drag: 1.2 }); }
  dust(x, y, z, n = 6, c = 0xb8a890) { this.emit(this.N, x, y + 0.1, z, c, n, { speed: 2.2, up: 0.4, life: 0.5, size: 0.45, size1: 1.1, g: 0.5, flat: true, drag: 3 }); }
  glow(x, y, z, c, n = 4, o = {}) { this.emit(this.A, x, y, z, c, n, { speed: 1.2, up: 1, life: 0.6, size: 0.35, g: 1.5, ...o }); }
  hit(x, y, z, c = 0xfff0b0, big = false) { this.spark(x, y, z, c, big ? 14 : 8, { speed: big ? 7 : 5 }); this.ring(x, y, z, big ? 1.6 : 0.9, c, 0.22, { vertical: true }); }
  explode(x, y, z, r = 3, c = 0xffa040) {
    this.emit(this.A, x, y + 0.5, z, c, 26, { speed: r * 2.2, life: 0.55, size: 0.6, size1: 0.1, g: -3, up: 1 });
    this.emit(this.N, x, y + 0.4, z, 0x3a3530, 14, { speed: r * 1.2, life: 1.0, size: 0.8, size1: 2.4, g: 1.2, drag: 1.5 });
    this.ring(x, y + 0.1, z, r, c, 0.45); this.addShake(Math.min(1, r / 5) * 0.6);
  }
  coin(x, y, z) { this.emit(this.A, x, y, z, 0xffd23a, 8, { speed: 2.5, life: 0.4, size: 0.2, g: 0, up: 1.2 }); }
  heal(x, y, z) { this.emit(this.A, x, y, z, 0x66ff9a, 10, { speed: 1.2, life: 0.8, size: 0.28, g: 2.5, up: 0.6, spread: 0.8 }); }
  addShake(v) { if (G.save && G.save.d.settings.shake === false) return; this.shake = Math.min(1.2, this.shake + v); }

  ring(x, y, z, r, c, dur = 0.4, o = {}) {
    const m = (this.free.ring.pop()) || { mesh: new THREE.Mesh(ringGeo, addMat(c)) };
    m.mesh.geometry = ringGeo; m.mesh.material.color.setHex(c); m.mesh.position.set(x, y + 0.06, z); m.r = r; m.t = 0; m.dur = dur; m.vertical = !!o.vertical;
    m.mesh.rotation.set(o.vertical ? Math.PI / 2 : 0, o.vertical ? Math.random() * 3 : 0, 0); m.mesh.scale.setScalar(0.1); m.mesh.visible = true; m.mesh.renderOrder = 5;
    this.scene.add(m.mesh); this.rings.push(m);
  }
  // ground telegraph: type circle|line|cone. returns controller
  telegraph(type, x, z, y, a, b, c = 0xff3a2a) {
    const mesh = new THREE.Group(); const fill = new THREE.Mesh(type === 'circle' || type === 'cone' ? discGeo : boxGeo, addMat(c, 0.2)); const edge = new THREE.Mesh(type === 'circle' ? ringGeo : boxGeo, addMat(c, 0.7));
    mesh.add(fill); if (type === 'circle') mesh.add(edge); mesh.renderOrder = 4; fill.renderOrder = 4; edge.renderOrder = 4;
    this.scene.add(mesh);
    const T = { mesh, fill, edge, type, x, z, y, a, b, p: 0, alive: true, c };
    T.set = (nx, nz, na, nb, yaw) => { T.x = nx; T.z = nz; if (na !== undefined) T.a = na; if (nb !== undefined) T.b = nb; if (yaw !== undefined) T.yaw = yaw; };
    T.kill = () => { T.alive = false; };
    this.tele.push(T); this._applyTele(T); return T;
  }
  _applyTele(T) {
    const m = T.mesh; m.position.set(T.x, T.y + 0.07, T.z); m.rotation.y = T.yaw || 0;
    if (T.type === 'circle') { m.scale.set(T.a, 1, T.a); T.fill.scale.setScalar(Math.max(0.01, T.p)); T.edge.scale.setScalar(1); }
    else if (T.type === 'line') { // box along local +Z, length a, width b
      T.fill.scale.set(T.b, 0.05, T.a * Math.max(0.02, T.p)); T.fill.position.set(0, 0, T.a * 0.5 * Math.max(0.02, T.p)); m.scale.set(1, 1, 1);
      T.edge.scale.set(T.b, 0.04, T.a); T.edge.position.set(0, 0, T.a * 0.5); T.edge.material.opacity = 0.25;
    } else if (T.type === 'cone') { m.scale.set(T.a, 1, T.a); T.fill.scale.setScalar(Math.max(0.02, T.p)); }
    T.fill.material.opacity = 0.18 + 0.3 * T.p;
  }
  beam(x1, y1, z1, x2, y2, z2, c = 0xffffff, w = 0.15, dur = 0.12) {
    const m = (this.free.beam.pop()) || { mesh: new THREE.Mesh(boxGeo, addMat(c, 0.9)) };
    this._setBeam(m, x1, y1, z1, x2, y2, z2, w); m.mesh.material.color.setHex(c); m.t = 0; m.dur = dur; m.w = w; this.scene.add(m.mesh); this.beams.push(m);
    return m;
  }
  _setBeam(m, x1, y1, z1, x2, y2, z2, w) {
    const dx = x2 - x1, dy = y2 - y1, dz = z2 - z1, L = Math.hypot(dx, dy, dz) || 0.01;
    m.mesh.position.set((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2); m.mesh.scale.set(w, w, L);
    // orient local Z along (dx,dy,dz): game-space; scene is mirrored in x so build quaternion in game space then mirror
    const dir = new THREE.Vector3(dx, dy, dz).normalize(); const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir); m.mesh.quaternion.copy(q);
  }
  text(x, y, z, str, cls = '') {
    const el = document.createElement('div'); el.className = 'fl ' + cls; el.textContent = str; this.root.appendChild(el);
    this.texts.push({ el, x, y, z, t: 0, vy: 1.8 + Math.random() * 0.4, dx: (Math.random() - 0.5) * 0.8 });
    if (this.texts.length > 40) { const o = this.texts.shift(); o.el.remove(); }
  }
  update(dt) {
    this.t += dt;
    const sc = this.stage.renderer.domElement.height / (2 * Math.tan(rad(this.stage.camera.fov / 2)));
    this.A.mat.uniforms.scale.value = sc; this.N.mat.uniforms.scale.value = sc;
    this.A.update(dt); this.N.update(dt);
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const m = this.rings[i]; m.t += dt; const u = m.t / m.dur;
      if (u >= 1) { this.scene.remove(m.mesh); this.free.ring.push(m); this.rings.splice(i, 1); continue; }
      const e = 1 - Math.pow(1 - u, 2.2); m.mesh.scale.setScalar(Math.max(0.05, m.r * e)); m.mesh.material.opacity = 0.85 * (1 - u);
    }
    for (let i = this.tele.length - 1; i >= 0; i--) { const T = this.tele[i]; if (!T.alive) { this.scene.remove(T.mesh); T.mesh.traverse(o => { if (o.material) o.material.dispose(); }); this.tele.splice(i, 1); continue; } this._applyTele(T); }
    for (let i = this.beams.length - 1; i >= 0; i--) { const m = this.beams[i]; m.t += dt; if (m.t >= m.dur) { this.scene.remove(m.mesh); this.free.beam.push(m); this.beams.splice(i, 1); continue; } m.mesh.material.opacity = 0.9 * (1 - m.t / m.dur); }
    const cam = this.stage.camera; const w = innerWidth, h = innerHeight;
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const T = this.texts[i]; T.t += dt; if (T.t > 0.9) { T.el.remove(); this.texts.splice(i, 1); continue; }
      const v = this.stage.toScreen(T.x + T.dx * T.t, T.y + T.vy * T.t - 1.2 * T.t * T.t, T.z);
      if (!v) { T.el.style.display = 'none'; continue; } T.el.style.display = ''; T.el.style.transform = `translate(${(v.x * 0.5 + 0.5) * w}px,${(-v.y * 0.5 + 0.5) * h}px) translate(-50%,-50%)`; T.el.style.opacity = String(Math.min(1, (0.9 - T.t) * 3));
    }
    this.shake = Math.max(0, this.shake - dt * 2.4);
  }
  clear() {
    for (const m of this.rings) this.scene.remove(m.mesh); this.rings.length = 0;
    for (const T of this.tele) { this.scene.remove(T.mesh); } this.tele.length = 0;
    for (const m of this.beams) this.scene.remove(m.mesh); this.beams.length = 0;
    for (const T of this.texts) T.el.remove(); this.texts.length = 0;
    for (const p of this.A.p) p.life = 0; for (const p of this.N.p) p.life = 0;
  }
}
