// Builds a playable World from a level spec: lays segments end-to-end, populates enemies, pickups, objectives' objects.
import * as THREE from 'three';
import { World } from './world.js';
import { T, ZMAX, breakable } from './templates.js';
import { Props } from './props.js';
import { RNG } from './util.js';
import { THEMES } from './themes.js';
import { LEVEL_BY_ID } from './data/levels.js';

const rngOf = (W) => W.rng;

function pickArea(W, areas, tags, rng) {
  const pool = areas.filter(a => tags.includes(a.tag));
  if (!pool.length) return null;
  let tot = 0; for (const a of pool) tot += Math.max(1, (a.x1 - a.x0) * (a.z1 - a.z0)); let r = rng.next() * tot;
  for (const a of pool) { r -= Math.max(1, (a.x1 - a.x0) * (a.z1 - a.z0)); if (r <= 0) return a; }
  return pool[pool.length - 1];
}
function spotIn(W, areas, tags, rng, used, minD = 2.2, avoid = null, m = 0.9) {
  for (let i = 0; i < 40; i++) {
    const a = pickArea(W, areas, tags, rng); if (!a) return null;
    const p = W.freeSpot(a, m, 6, rng); if (!p) continue;
    if (avoid && avoid(p)) continue;
    if (used && used.some(u => Math.hypot(u.x - p.x, u.z - p.z) < minD)) continue;
    if (used) used.push(p); return p;
  }
  return null;
}
function makeSwitch(W, x, z, y, id) {
  const g = new THREE.Group(); g.position.set(x, y, z);
  const m = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: o.r ?? 0.6, metalness: o.m ?? 0.4 });
  const b = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.7, 0.8), m(0x3a424e)); b.position.y = 0.85; g.add(b);
  const lightMat = new THREE.MeshBasicMaterial({ color: 0xff3a3a }); const l = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.35, 0.1), lightMat); l.position.set(0, 1.25, 0.45); g.add(l);
  const lv = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.5, 0.12), m(0xd8d8d8)); lv.position.set(0.2, 0.6, 0.48); lv.rotation.z = 0.5; g.add(lv);
  const beacon = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 5, 6), new THREE.MeshBasicMaterial({ color: 0xff5a3a, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false })); beacon.position.y = 4; g.add(beacon);
  g.traverse(o => { if (o.isMesh) { o.castShadow = true; } });
  W.group.add(g);
  W.addCollider({ x0: x - 0.6, x1: x + 0.6, z0: z - 0.45, z1: z + 0.45, y0: y, y1: y + 1.7 });
  const it = W.interact({ type: 'switch', id, x, y, z, r: 2.4, prompt: 'تشغيل الجهاز', mesh: g, lightMat, beacon });
  return it;
}
function makeCage(W, x, z, y, ally) {
  const g = new THREE.Group(); g.position.set(x, y, z);
  const bar = new THREE.MeshStandardMaterial({ color: 0x5a626e, metalness: 0.8, roughness: 0.4 });
  for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2; const c = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.6, 6), bar); c.position.set(Math.cos(a) * 1.15, 1.3, Math.sin(a) * 1.15); g.add(c); }
  const top = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, 0.12, 12), bar); top.position.y = 2.6; g.add(top);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.15, 12), bar); base.position.y = 0.07; g.add(base);
  const beacon = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 7, 6), new THREE.MeshBasicMaterial({ color: 0x66ffa8, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false })); beacon.position.y = 5; g.add(beacon);
  W.group.add(g);
  const col = W.addCollider({ x0: x - 1.25, x1: x + 1.25, z0: z - 1.25, z1: z + 1.25, y0: y, y1: y + 2.6, cage: true });
  return W.interact({ type: 'cage', id: 'cage_' + ally, ally, x, y, z, r: 3.2, prompt: 'تحرير المقاتل', mesh: g, collider: col, beacon });
}
function makeMech(W, x, z, y) {
  const g = new THREE.Group(); g.position.set(x, y, z);
  const pad = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.4, 0.25, 20), new THREE.MeshStandardMaterial({ color: 0x30343c, metalness: 0.7, roughness: 0.4 })); pad.position.y = 0.12; g.add(pad);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(2.0, 0.06, 6, 28), new THREE.MeshBasicMaterial({ color: 0xff8a1f })); ring.rotation.x = Math.PI / 2; ring.position.y = 0.3; g.add(ring);
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.6, 1.0), new THREE.MeshStandardMaterial({ color: 0x4b5260, metalness: 0.6, roughness: 0.5 })); body.position.y = 1.7; g.add(body);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.6, 0.8), new THREE.MeshStandardMaterial({ color: 0x3b414c, metalness: 0.6 })); head.position.y = 3.3; g.add(head);
  const eye = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.12, 0.1), new THREE.MeshBasicMaterial({ color: 0xff8a1f })); eye.position.set(0, 3.32, 0.42); g.add(eye);
  const beacon = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 7, 6), new THREE.MeshBasicMaterial({ color: 0xff8a1f, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false })); beacon.position.y = 5; g.add(beacon);
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  W.group.add(g);
  W.addCollider({ x0: x - 0.9, x1: x + 0.9, z0: z - 0.7, z1: z + 0.7, y0: y, y1: y + 3.4, mechstation: true });
  return W.interact({ type: 'mech', id: 'mech', x, y, z, r: 3.4, prompt: 'ركوب الروبوت الميكانيكي', mesh: g, ring, beacon });
}
function makeBarrier(W, x, zh, y0 = -2, y1 = 6) {
  const col = W.addCollider({ x0: x - 0.3, x1: x + 0.3, z0: -ZMAX, z1: ZMAX, y0, y1, enabled: false, barrier: true, nav: false, proj: false });
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.2, 5, zh * 2), new THREE.MeshBasicMaterial({ color: 0xff3a3a, transparent: true, opacity: 0.28, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  mesh.position.set(x, 2.5, 0); mesh.visible = false; W.group.add(mesh);
  return { collider: col, mesh };
}
function checkpointFlag(W, x, z, y) {
  const m = new THREE.MeshBasicMaterial({ color: 0x66ffa8 });
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3, 6), new THREE.MeshStandardMaterial({ color: 0x8a929c, metalness: 0.7 })); pole.position.set(x, y + 1.5, z); W.group.add(pole);
  const flag = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.6, 0.04), m); flag.position.set(x + 0.55, y + 2.6, z); W.group.add(flag);
  const cp = { x, y, z, r: 3.5, mat: m, active: false, flag }; W.checkpoints.push(cp);
  W.addAnim((t) => { flag.rotation.y = Math.sin(t * 3 + x) * 0.2; });
}

function skyline(W, x0, x1, isVoid, rng) {
  const base = isVoid ? -90 : 0;
  for (const side of [-1, 1]) {
    for (let layer = 0; layer < 2; layer++) {
      let x = x0 - 40;
      while (x < x1 + 40) {
        const w = rng.range(10, 24), d = rng.range(10, 22), h = isVoid ? rng.range(70, 120) : rng.range(22, 80) * (layer ? 1.3 : 1);
        const z = side * (ZMAX + 8 + layer * 26 + rng.range(0, 10));
        W.box(x, base, z - (side > 0 ? 0 : d), x + w, base + h, z + (side > 0 ? d : 0), ['facade', rng.pick([0x7a8494, 0x6a7280, 0x8a8494, 0x707a8a])], { collide: false, shadow: false });
        x += w + rng.range(0, 4);
      }
    }
  }
  let z = -ZMAX - 40;
  for (const ex of [x0 - 30, x1 + 28]) for (z = -ZMAX - 40; z < ZMAX + 40; z += 16) { const h = isVoid ? rng.range(70, 110) : rng.range(25, 85); W.box(ex - 14, base, z, ex, base + h, z + rng.range(10, 16), ['facade', 0x6f7888], { collide: false, shadow: false }); }
}

export function buildLevel(spec) {
  const W = new World({ seed: spec.seed, void: spec.segs.some(s => s.t === 'roofs' || s.t === 'tower') });
  const rng = W.rng; W.spec = spec; W.theme = THEMES[spec.theme] || THEMES.dusk;
  W.checkpoints = []; W.hazardsDef = []; W.bounds = { x0: -1e5, x1: 1e5, z0: -ZMAX, z1: ZMAX };
  let x = 0; const infos = [];
  const used = [];
  spec.segs.forEach((s, idx) => {
    const t = T[s.t]; if (!t) throw new Error('template ' + s.t);
    const aFrom = W.areas.length;
    const r = t(W, s, x);
    const info = Object.assign({ id: s.id || ('seg' + idx), spec: s, idx }, r.info);
    info.areas = W.areas.slice(aFrom);
    W.segInfo[info.id] = info; infos.push(info);
    populate(W, s, info, idx, used);
    x = r.x1;
  });
  const first = infos[0], last = infos[infos.length - 1];
  // exit strip
  let exit;
  if (last.void || W.void && (last.spec.t === 'roofs' || last.spec.t === 'tower')) {
    exit = { x: last.exit.x, y: last.exit.y || 0, z: last.exit.z, r: 3.2 };
  } else {
    const sx0 = x;
    const r = T.street(W, { len: 16, cars: 0, cover: 0, nooks: 0, crosswalk: false, lamps: true }, x);
    if (W.void) W.box(sx0, -0.8, -9, r.x1, 0, 9, 'roof'); // void worlds have no implicit ground
    W.segInfo.exitstrip = Object.assign({ id: 'exitstrip', idx: infos.length, spec: { t: 'street' } }, r.info);
    x = r.x1; exit = { x: x - 6, y: 0, z: 0, r: 3.2 };
  }
  W.exit = exit;
  // exit gate visuals
  const gm = new THREE.MeshBasicMaterial({ color: 0x66ffa8 });
  for (const sd of [-1, 1]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.5, 5, 0.5), new THREE.MeshStandardMaterial({ color: 0x2c333c, metalness: 0.7, roughness: 0.4 })); p.position.set(exit.x, exit.y + 2.5, exit.z + sd * 3.4); p.castShadow = true; W.group.add(p); }
  const arch = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 7.2), gm); arch.position.set(exit.x, exit.y + 5, exit.z); W.group.add(arch);
  const beam = new THREE.Mesh(new THREE.BoxGeometry(0.08, 5, 6.4), new THREE.MeshBasicMaterial({ color: 0x66ffa8, transparent: true, opacity: 0.18, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); beam.position.set(exit.x, exit.y + 2.5, exit.z); W.group.add(beam);
  W.exitMesh = { arch, beam, gm, open: false };
  W.decal(exit.x, exit.z, 6.5, 6.5, 'ring', 0, exit.y + 0.04, 0x66ffa8);
  W.addAnim((t) => { beam.material.opacity = (W.exitMesh.open ? 0.28 : 0.06) + 0.06 * Math.sin(t * 4); });
  W.exitMesh.setOpen = (o) => { W.exitMesh.open = o; gm.color.setHex(o ? 0x66ffa8 : 0xff5a4a); beam.material.color.setHex(o ? 0x66ffa8 : 0xff5a4a); };
  W.exitMesh.setOpen(false);
  // start: dead-end cap + bounds
  const start = first.entry; W.start = { x: start.x, y: start.y || 0, z: start.z };
  W.bounds = { x0: 0.3, x1: x, z0: -ZMAX, z1: ZMAX };
  W.endX = x;
  if (!W.void) W.box(-120, -2, -150, x + 120, -0.05, 150, 'asphalt', { collide: false, shadow: false });
  W.box(-30, W.void ? -60 : 0, -ZMAX, 0, 30, ZMAX, ['facade', 0x8a8494], { collide: false });
  skyline(W, 0, x, W.void, rng);
  // checkpoints at each segment start (except first)
  infos.forEach((inf, i) => { if (i > 0 && !inf.arena) { const e = inf.entry; checkpointFlag(W, e.x + 1.2, e.z + (inf.hw ? Math.min(inf.hw - 1.5, 4) : 3), e.y || 0); } });
  for (const inf of infos) for (const c of inf.cps || []) checkpointFlag(W, c.x, c.z, c.y);
  W.finalize();
  // spawn lock barriers need nav after finalize: nothing to do (nav:false)
  return W;
}

function populate(W, s, info, idx, used) {
  const rng = W.rng, diff = (LEVEL_BY_ID[W.spec.id] || {}).diff || 1;
  const areas = info.areas; const mainTags = ['main', 'room', 'upper'];
  const isFirst = idx === 0;
  const avoidStart = (p) => isFirst && p.x < W.startHint + 14;
  W.startHint = W.startHint ?? (info.entry ? info.entry.x : 0);
  const avoid = (p) => (idx === 0 && p.x < (info.entry.x + 14)) || (info.arena && Math.hypot(p.x - info.bossSpot.x, p.z - info.bossSpot.z) < 4);
  const spots = [];
  // --- enemies (dormant clusters)
  const list = []; for (const [t, n] of Object.entries(s.enemies || {})) for (let i = 0; i < n; i++) list.push(t);
  for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(rng.next() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; }
  let gid = 0;
  for (let i = 0; i < list.length; i += 3) {
    const grp = list.slice(i, i + 3);
    const tagsPref = info.building ? ['room', 'main', 'upper'] : ['main', 'upper'];
    const c = spotIn(W, areas, i % 6 === 0 ? tagsPref : mainTags, rng, null, 0, avoid, 1.0); if (!c) continue;
    grp.forEach((t, k) => {
      let p = null; for (let tr = 0; tr < 12 && !p; tr++) { const q = { x: c.x + rng.range(-3, 3), z: c.z + rng.range(-3, 3), y: c.y }; if (W.isFree(q.x, q.z, c.y, 0.9) && !avoid(q) && W.bounds && true) p = q; }
      p = p || c;
      W.spawns.push({ type: t, x: p.x, y: p.y, z: p.z, seg: info.id, group: info.id + '_' + (gid), zombie: false });
    });
    gid++;
  }
  // --- coins / health / crates / barrels
  const coinV = 1 + Math.ceil(diff / 2);
  for (let i = 0; i < (s.coins || 0); i++) {
    const c = spotIn(W, areas, mainTags, rng, null, 0, null, 0.8); if (!c) continue;
    const n = 3; for (let k = 0; k < n; k++) { const a = k / n * 6.28; W.pickups.push({ type: 'coin', x: c.x + Math.cos(a) * 0.7, z: c.z + Math.sin(a) * 0.7, y: c.y + 0.7, v: coinV }); }
  }
  for (let i = 0; i < (s.hp || 0); i++) { const c = spotIn(W, areas, ['room', 'upper', 'main'], rng, null, 0, null, 0.8); if (c) W.pickups.push({ type: 'hp', x: c.x, z: c.z, y: c.y + 0.7, v: 30 }); }
  for (let i = 0; i < (s.crates || 0); i++) { const c = spotIn(W, areas, ['room', 'main'], rng, used, 3, null, 1.0); if (c) breakable(W, { type: rng.chance(0.25) ? 'barrel' : 'crate', x: c.x, y: c.y, z: c.z, loot: { coins: 2 + Math.floor(rng.next() * 4), hp: rng.chance(0.15) } }); }
  for (let i = 0; i < (s.barrels || 0); i++) { const c = spotIn(W, areas, ['main'], rng, used, 3, null, 1.0); if (c) breakable(W, { type: 'barrel', x: c.x, y: c.y, z: c.z }); }
  // --- special objects
  const slots = ((info.slots && info.slots.special) || []).slice(); for (let i = slots.length - 1; i > 0; i--) { const j = Math.floor(rng.next() * (i + 1)); [slots[i], slots[j]] = [slots[j], slots[i]]; }
  const takeSpecial = (tags = ['room', 'upper', 'main']) => {
    for (let tr = 0; tr < slots.length; tr++) { const sl = slots.shift(); if (W.isFree(sl.x, sl.z, sl.y || 0, 0.9)) { used.push(sl); return { x: sl.x, z: sl.z, y: sl.y || 0 }; } }
    return spotIn(W, areas, tags, rng, used, 4, (p) => (idx === 0 && p.x < info.entry.x + 12), 1.3);
  };
  for (let i = 0; i < (s.switches || 0); i++) { const p = takeSpecial(); if (p) makeSwitch(W, p.x, p.z, p.y, 'sw_' + info.id + '_' + i); }
  if (s.cage) { const p = takeSpecial(); if (p) makeCage(W, p.x, p.z, p.y, s.cage); }
  if (s.keys) { const n = s.keys.n; for (let i = 0; i < n; i++) { const p = takeSpecial(); if (p) W.pickups.push({ type: 'key', id: 'key_' + info.id + '_' + i, name: s.keys.name, x: p.x, z: p.z, y: p.y + 0.9, v: 1 }); } }
  for (let i = 0; i < (s.nests || 0); i++) { const p = takeSpecial(['main', 'room']); if (p) breakable(W, { type: 'nest', x: p.x, y: p.y, z: p.z, loot: { coins: 12, hp: true }, objective: 'nest', hp: 150 + diff * 15 }); }
  if (s.mech) { const a = areas.find(a => a.tag === 'main'); const p = a && W.freeSpot({ x0: a.x0 + 2, x1: a.x0 + 12, z0: a.z0 + 1, z1: a.z1 - 1, y: a.y }, 2.6, 30, rng); if (p) makeMech(W, p.x, p.z, p.y); }
  if (s.protect) { const cx = (info.x0 + info.x1) / 2, cz = info.building ? 0 : 0; const b = breakable(W, { type: 'generator', x: cx, y: 0, z: cz, hp: 320, loot: {}, objective: 'protect', protect: true }); W.protect = { seg: info.id, target: b }; }
  if (s.boss) W.boss = { id: s.boss, seg: info.id, x: info.bossSpot.x, z: info.bossSpot.z, y: 0 };
  // hazards (fire jets)
  for (const hz of s.hazards || []) if (hz === 'fire') for (let i = 0; i < 5; i++) { const c = spotIn(W, areas, ['main'], rng, null, 0, (p) => idx === 0 && p.x < 12, 1.4); if (c) { W.hazard({ type: 'fire', x: c.x, z: c.z, y: c.y, r: 1.2, period: 5.5, onFor: 2.2, phase: rng.range(0, 5), dps: 14 }); W.decal(c.x, c.z, 2.2, 2.2, 'stain', 0, c.y + 0.035); } }
  // lock / waves
  if (s.lock) {
    const zh = info.zhalf || 10;
    info.lock = { barriers: [makeBarrier(W, info.x0 + 8, zh), makeBarrier(W, info.x1 - 3, zh)], triggerX: info.x0 + 10, state: 'idle', waves: s.waves || [] };
  }
  info.coinV = coinV;
}
