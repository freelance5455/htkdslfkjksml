// World container + builder primitives: batched static geometry, colliders, doors, zones, lamps, hazards, nav grid.
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { M, plain, glow, glass, ghostOf, decalMat, TILE_SIZE } from './materials.js';
import { RNG, clamp, Heap } from './util.js';
import { G } from './ctx.js';

const CHUNK = 26;       // render batching chunk (m)
const CS = 4;           // collider grid cell size
const GRID_OFF = 400;

export class World {
  constructor(opts = {}) {
    this.group = new THREE.Group();
    this.void = !!opts.void;
    this.rng = new RNG(opts.seed || 1);
    this.colliders = []; this.cells = new Map(); this.movers = []; this.stamp = 1;
    this.batches = new Map();
    this.doors = []; this.zones = []; this.lamps = []; this.hazards = []; this.anim = []; this.occluders = [];
    this.areas = []; this.interactables = []; this.spawns = []; this.pickups = []; this.breakables = []; this.route = [];
    this.anchors = {}; this.segInfo = {}; this.links = []; this.navBlocks = [];
    this.bounds = { x0: -5, x1: 50, z0: -12, z1: 12 };
    this.killY = -14;
    this.lastGround = null;
    this.curZone = null;
    this.onUnlock = null;
    this.lightPool = [];
  }

  // ---------- materials ----------
  mat(spec) {
    if (!spec) return M('concrete');
    if (typeof spec === 'string') return M(spec);
    if (Array.isArray(spec)) return M(spec[0], spec[1] ?? 0xffffff, spec[2]);
    if (spec.glow != null) return glow(spec.glow, spec.o || {});
    if (spec.plain != null) return plain(spec.plain, spec);
    if (spec.glass != null) return glass(spec.glass, spec.op || 0.28);
    return M('concrete');
  }
  _matKey(spec) { return typeof spec === 'string' ? spec : JSON.stringify(spec); }
  _tileOf(spec) { const n = typeof spec === 'string' ? spec : Array.isArray(spec) ? spec[0] : null; return n && TILE_SIZE[n] ? TILE_SIZE[n] : 0; }

  // ---------- collider management ----------
  addCollider(c) {
    c.enabled = c.enabled !== false; this.colliders.push(c);
    if (c.mover) { this.movers.push(c); return c; }
    this._index(c); return c;
  }
  _index(c) {
    const ix0 = Math.floor((c.x0 + GRID_OFF) / CS), ix1 = Math.floor((c.x1 + GRID_OFF) / CS), iz0 = Math.floor((c.z0 + GRID_OFF) / CS), iz1 = Math.floor((c.z1 + GRID_OFF) / CS);
    for (let ix = ix0; ix <= ix1; ix++) for (let iz = iz0; iz <= iz1; iz++) { const k = ix * 4096 + iz; let a = this.cells.get(k); if (!a) this.cells.set(k, a = []); a.push(c); }
  }
  query(out, x0, z0, x1, z1) {
    out.length = 0; const st = ++this.stamp;
    const ix0 = Math.floor((x0 + GRID_OFF) / CS), ix1 = Math.floor((x1 + GRID_OFF) / CS), iz0 = Math.floor((z0 + GRID_OFF) / CS), iz1 = Math.floor((z1 + GRID_OFF) / CS);
    for (let ix = ix0; ix <= ix1; ix++) for (let iz = iz0; iz <= iz1; iz++) { const a = this.cells.get(ix * 4096 + iz); if (!a) continue; for (let i = 0; i < a.length; i++) { const c = a[i]; if (c._st !== st) { c._st = st; out.push(c); } } }
    for (const c of this.movers) if (c.x0 <= x1 && c.x1 >= x0 && c.z0 <= z1 && c.z1 >= z0) out.push(c);
    return out;
  }
  groundAt(x, z, y, r, step = 0.56) {
    const q = this._q || (this._q = []);
    this.query(q, x - r, z - r, x + r, z + r);
    let best = this.void ? -Infinity : 0, bc = null; const rr = r * 0.75;
    for (let i = 0; i < q.length; i++) {
      const c = q[i]; if (!c.enabled || c.walk === false) continue;
      if (x + rr < c.x0 || x - rr > c.x1 || z + rr < c.z0 || z - rr > c.z1) continue;
      if (c.y1 <= y + step && c.y1 > best) { best = c.y1; bc = c; }
    }
    this.lastGround = bc; return best;
  }
  /** push a cylinder (e.x,e.z,e.r, y..y+h) out of solid colliders. returns true if touched */
  resolve(e, step = 0.56) {
    const q = this._q2 || (this._q2 = []);
    const r = e.r;
    this.query(q, e.x - r - 0.1, e.z - r - 0.1, e.x + r + 0.1, e.z + r + 0.1);
    let hit = false;
    for (let it = 0; it < 2; it++) {
      for (let i = 0; i < q.length; i++) {
        const c = q[i]; if (!c.enabled || c.wall === false) continue;
        if (!(c.y1 > e.y + step && c.y0 < e.y + e.h)) continue;
        const nx = clamp(e.x, c.x0, c.x1), nz = clamp(e.z, c.z0, c.z1);
        let dx = e.x - nx, dz = e.z - nz; const d2 = dx * dx + dz * dz;
        if (d2 >= r * r) continue;
        hit = true;
        if (d2 > 1e-8) { const d = Math.sqrt(d2), p = r - d; e.x += dx / d * p; e.z += dz / d * p; }
        else { // centre inside box: push along min penetration axis
          const l = e.x - c.x0, rr2 = c.x1 - e.x, t = e.z - c.z0, b = c.z1 - e.z; const m = Math.min(l, rr2, t, b);
          if (m === l) e.x = c.x0 - r; else if (m === rr2) e.x = c.x1 + r; else if (m === t) e.z = c.z0 - r; else e.z = c.z1 + r;
        }
      }
    }
    // world bounds
    const b = this.bounds;
    if (e.x < b.x0 + r) { e.x = b.x0 + r; hit = true; } if (e.x > b.x1 - r) { e.x = b.x1 - r; hit = true; }
    if (e.z < b.z0 + r) { e.z = b.z0 + r; hit = true; } if (e.z > b.z1 - r) { e.z = b.z1 - r; hit = true; }
    return hit;
  }
  ceilingAt(x, z, y, r, h) {
    const q = this._q3 || (this._q3 = []); this.query(q, x - r, z - r, x + r, z + r);
    let best = Infinity;
    for (const c of q) { if (!c.enabled || c.ceil === false) continue; if (c.y0 > y + 1.0 && c.y0 < best && x + r > c.x0 && x - r < c.x1 && z + r > c.z0 && z - r < c.z1) best = c.y0; }
    return best;
  }
  pointSolid(x, y, z, pad = 0) {
    const q = this._q4 || (this._q4 = []); this.query(q, x - 0.1, z - 0.1, x + 0.1, z + 0.1);
    for (const c of q) { if (!c.enabled || c.proj === false) continue; if (x >= c.x0 - pad && x <= c.x1 + pad && z >= c.z0 - pad && z <= c.z1 + pad && y >= c.y0 && y <= c.y1) return c; }
    if (!this.void && y < 0) return { floor: true };
    return null;
  }
  /** is the straight segment blocked by tall solids (used for LOS / aggro) */
  losBlocked(ax, az, bx, bz, minH = 1.2) {
    const d = Math.hypot(bx - ax, bz - az), n = Math.ceil(d / 0.8);
    const q = this._q5 || (this._q5 = []);
    for (let i = 1; i < n; i++) {
      const t = i / n, x = ax + (bx - ax) * t, z = az + (bz - az) * t;
      this.query(q, x, z, x, z);
      for (const c of q) if (c.enabled && c.los !== false && c.y1 >= minH && c.y0 < 1.0 && x >= c.x0 && x <= c.x1 && z >= c.z0 && z <= c.z1) return true;
    }
    return false;
  }

  // ---------- static batched geometry ----------
  _boxGeo(w, h, d, tile, seed) {
    const g = new THREE.BoxGeometry(w, h, d);
    if (tile) {
      const uv = g.attributes.uv; const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
      const ox = (seed * 0.137) % 1, oy = (seed * 0.291) % 1;
      for (let f = 0; f < 6; f++) for (let i = 0; i < 4; i++) { const k = f * 4 + i; uv.setXY(k, uv.getX(k) * dims[f][0] / tile + ox, uv.getY(k) * dims[f][1] / tile + oy); }
    }
    return g;
  }
  _push(geo, spec, x, z) {
    const key = this._matKey(spec) + '|' + Math.floor(x / CHUNK);
    let b = this.batches.get(key); if (!b) this.batches.set(key, b = { spec, geos: [] });
    b.geos.push(geo);
  }
  /** box primitive. o: {collide, standalone, fade, zone, ...collider props, shadow} */
  box(x0, y0, z0, x1, y1, z1, spec = 'concrete', o = {}) {
    if (x1 < x0) [x0, x1] = [x1, x0]; if (y1 < y0) [y0, y1] = [y1, y0]; if (z1 < z0) [z0, z1] = [z1, z0];
    const w = x1 - x0, h = y1 - y0, d = z1 - z0; if (w <= 0 || h <= 0 || d <= 0) return null;
    const tile = this._tileOf(spec);
    const g = this._boxGeo(w, h, d, tile, (x0 * 7.3 + z0 * 3.1 + y0 * 1.7) | 0);
    g.translate(x0 + w / 2, y0 + h / 2, z0 + d / 2);
    const out = {};
    if (o.standalone || o.fade || o.hideIn) {
      const m = new THREE.Mesh(g, this.mat(spec)); m.castShadow = o.shadow !== false; m.receiveShadow = true;
      this.group.add(m); out.mesh = m;
      if (o.fade) this.occluders.push({ mesh: m, box: new THREE.Box3(new THREE.Vector3(x0, y0, z0), new THREE.Vector3(x1, y1, z1)), mat: m.material, ghost: ghostOf(m.material), ghosted: false });
    } else this._push(g, spec, x0 + w / 2, z0);
    if (o.collide !== false) {
      out.collider = this.addCollider(Object.assign({ x0, y0, z0, x1, y1, z1 }, o.c || {}));
    }
    return out;
  }
  /** generic geometry instance (cylinder, cone, sphere, ...) baked into the batch */
  geo(geometry, spec, x, y, z, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
    const g = geometry.clone();
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)), new THREE.Vector3(sx, sy, sz));
    g.applyMatrix4(m);
    this._push(g, spec, x, z); return g;
  }
  /** floor slab; top at y. */
  floor(x0, z0, x1, z1, y, spec, o = {}) {
    const th = o.th ?? 0.5;
    if (y > 0.01 || this.void) return this.box(x0, y - th, z0, x1, y, z1, spec, Object.assign({ c: { ceil: false, los: false, proj: o.proj ?? true } }, o));
    return this.box(x0, -th, z0, x1, 0.0, z1, spec, { collide: false, ...o });
  }
  decal(x, z, w, d, name, rotY = 0, y = 0.03, color = null) {
    const g = new THREE.PlaneGeometry(w, d); g.rotateX(-Math.PI / 2); if (rotY) g.rotateY(rotY); g.translate(x, y, z);
    const dm = decalMat(name);
    const key = 'decal:' + name + (color || '') + '|' + Math.floor(x / CHUNK);
    let b = this.batches.get(key); if (!b) { let mat = dm; if (color != null) { mat = dm.clone(); mat.color = new THREE.Color(color); } this.batches.set(key, b = { mat, geos: [], decal: true }); }
    b.geos.push(g);
  }
  wall(axis, c, a0, a1, y0, y1, th, gaps, spec, o = {}) {
    // axis 'x': wall runs along x at z=c ; axis 'z': runs along z at x=c. gaps: [{c, w, h}] in the running coordinate
    const segs = []; let cur = a0; const hf = th / 2;
    const gp = (gaps || []).slice().sort((p, q) => p.c - q.c);
    const mk = (s, e, yb, yt) => {
      if (e - s < 0.01 || yt - yb < 0.01) return;
      const r = axis === 'x' ? this.box(s, yb, c - hf, e, yt, c + hf, spec, o) : this.box(c - hf, yb, s, c + hf, yt, e, spec, o);
      if (r) segs.push(r);
    };
    for (const g of gp) { mk(cur, g.c - g.w / 2, y0, y1); if (g.h < y1 - y0) mk(g.c - g.w / 2, g.c + g.w / 2, y0 + g.h, y1); cur = g.c + g.w / 2; }
    mk(cur, a1, y0, y1);
    return segs;
  }
  stairs(x, z, dir, w, rise, steps, spec = 'concrete', o = {}) {
    // dir: '+x','-x','+z','-z' — stairs climb in that direction starting at (x,z) edge. run = steps*0.5
    const run = steps * (o.tread || 0.55), sh = rise / steps;
    for (let i = 0; i < steps; i++) {
      const top = sh * (i + 1), t0 = i * (o.tread || 0.55), t1 = t0 + (o.tread || 0.55) + (i === steps - 1 ? 0 : 0.01);
      if (dir === '+x') this.box(x + t0, o.base || 0, z - w / 2, x + t1, (o.base || 0) + top, z + w / 2, spec, o.c ? { c: o.c } : {});
      else if (dir === '-x') this.box(x - t1, o.base || 0, z - w / 2, x - t0, (o.base || 0) + top, z + w / 2, spec, o.c ? { c: o.c } : {});
      else if (dir === '+z') this.box(x - w / 2, o.base || 0, z + t0, x + w / 2, (o.base || 0) + top, z + t1, spec, o.c ? { c: o.c } : {});
      else this.box(x - w / 2, o.base || 0, z - t1, x + w / 2, (o.base || 0) + top, z - t0, spec, o.c ? { c: o.c } : {});
    }
    { const b = o.base || 0, gx = dir === '+x' ? 1 : dir === '-x' ? -1 : 0, gz = dir === '+z' ? 1 : dir === '-z' ? -1 : 0; this.links.push({ from: { x: x - gx * 0.9, z: z - gz * 0.9, y: b }, to: { x: x + gx * (run + 0.9), z: z + gz * (run + 0.9), y: b + rise } }); }
    return run;
  }
  lamp(x, y, z, color = 0xffd8a0, intensity = 6, range = 16, o = {}) {
    const l = { x, y, z, color: new THREE.Color(color), intensity, range, flicker: o.flicker || 0, phase: Math.random() * 10, zone: o.zone || null };
    this.lamps.push(l); return l;
  }
  area(x0, z0, x1, z1, y = 0, tag = 'main', seg = null) { const a = { x0, z0, x1, z1, y, tag, seg }; this.areas.push(a); return a; }
  zone(o) { // interior zone: {x0,z0,x1,z1,y0,y1,id,hide:[objects],mood,cam}
    const z = Object.assign({ hide: [], id: 'z' + this.zones.length, y0: -1, y1: 12, mood: { sun: 0.3, hemi: 0.85, fog: 0 }, cam: { dist: 8.5, pitch: 0.82 } }, o);
    this.zones.push(z); return z;
  }
  interact(o) { const it = Object.assign({ r: 2.2, enabled: true, y: 0 }, o); this.interactables.push(it); return it; }
  hazard(o) { this.hazards.push(Object.assign({ active: true }, o)); return o; }
  addAnim(fn) { this.anim.push(fn); }

  door(o) {
    const w = o.w || 2.6, h = o.h || 2.9, th = 0.34, kind = o.kind || 'swing';
    const axis = o.axis || 'z';
    const door = { x: o.x, z: o.z, y: o.y || 0, axis, w, h, kind, open: false, t: 0, lockTag: o.lock || null, locked: !!o.lock, auto: o.auto !== false, id: o.id || ('d' + this.doors.length), tag: o.tag || null, openAngle: o.dir || 1 };
    const x0 = axis === 'z' ? o.x - th / 2 : o.x - w / 2, x1 = axis === 'z' ? o.x + th / 2 : o.x + w / 2;
    const z0 = axis === 'z' ? o.z - w / 2 : o.z - th / 2, z1 = axis === 'z' ? o.z + w / 2 : o.z + th / 2;
    door.collider = this.addCollider({ x0, x1, z0, z1, y0: door.y, y1: door.y + h, door: true, ceil: false, nav: false });
    const leafSpec = o.mat || (kind === 'gate' ? { plain: 0x5a6068, metal: 0.7, rough: 0.4 } : { plain: o.color ?? 0x6b4a32, rough: 0.7 });
    const pivot = new THREE.Group(); door.pivot = pivot;
    const lg = new THREE.BoxGeometry(axis === 'z' ? 0.12 : w, h, axis === 'z' ? w : 0.12);
    const leaf = new THREE.Mesh(lg, this.mat(leafSpec)); leaf.castShadow = true; leaf.receiveShadow = true;
    // pivot placed at hinge corner
    if (kind === 'swing') { if (axis === 'z') { pivot.position.set(o.x, door.y, o.z - w / 2); leaf.position.set(0, h / 2, w / 2); } else { pivot.position.set(o.x - w / 2, door.y, o.z); leaf.position.set(w / 2, h / 2, 0); } }
    else { pivot.position.set(o.x, door.y, o.z); leaf.position.set(0, h / 2, 0); }
    pivot.add(leaf);
    // status light + handle
    const light = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, 0.16), new THREE.MeshBasicMaterial({ color: door.locked ? 0xff3030 : 0x3aff7a }));
    if (axis === 'z') light.position.set(0.1, h * 0.85, w * 0.5); else light.position.set(w * 0.5, h * 0.85, 0.1);
    leaf.parent === pivot && pivot.add(light); door.light = light;
    if (o.window !== false && kind === 'swing') { const win = new THREE.Mesh(new THREE.BoxGeometry(axis === 'z' ? 0.14 : w * 0.5, h * 0.22, axis === 'z' ? w * 0.5 : 0.14), new THREE.MeshBasicMaterial({ color: 0x8fc8ff, transparent: true, opacity: 0.45 })); win.position.set(axis === 'z' ? 0 : w / 2, h * 0.68, axis === 'z' ? w / 2 : 0); pivot.add(win); }
    this.group.add(pivot);
    if (o.open) { door.open = true; door.t = 1; door.collider.enabled = false; }
    this.doors.push(door); return door;
  }
  setDoorLocked(d, locked) { d.locked = locked; d.light.material.color.setHex(locked ? 0xff3030 : 0x3aff7a); }
  openDoor(d, open = true) { if (d.locked && open) return false; if (d.open === open) return true; d.open = open; d.collider.enabled = !open; if (this.nav) this.nav.toggle(d.collider, !open); G.audio && G.audio.sfx(open ? 'door' : 'doorclose', d.x, d.z); return true; }
  unlock(tag) { let n = 0; for (const d of this.doors) if (d.lockTag === tag && d.locked) { this.setDoorLocked(d, false); d.auto = true; if (d.kind === 'gate') this.openDoor(d, true); n++; } return n; }

  // ---------- finalize ----------
  finalize() {
    for (const [, b] of this.batches) {
      if (!b.geos.length) continue;
      const g = b.geos.length === 1 ? b.geos[0] : mergeGeometries(b.geos, false);
      const m = new THREE.Mesh(g, b.mat || this.mat(b.spec));
      m.receiveShadow = !b.decal; m.castShadow = !b.decal && !(b.mat && b.mat.transparent);
      if (b.decal) m.renderOrder = 1;
      m.matrixAutoUpdate = false; m.updateMatrix();
      g.computeBoundingSphere(); g.computeBoundingBox();
      this.group.add(m); b.geos = [];
    }
    this.batches.clear();
    this.nav = new Nav(this);
  }

  // ---------- runtime ----------
  update(dt, t, focus) {
    for (const d of this.doors) {
      const target = d.open ? 1 : 0; d.t += (target - d.t) * Math.min(1, dt * 7);
      if (Math.abs(d.t - target) < 0.002) d.t = target;
      if (d.kind === 'swing') d.pivot.rotation.y = d.t * 1.5 * d.openAngle * (d.axis === 'z' ? 1 : -1);
      else if (d.kind === 'gate') d.pivot.position.y = d.y + d.t * (d.h + 0.2);
      else d.pivot.position.set(d.x + (d.axis === 'x' ? d.t * d.w * 0.92 : 0), d.y, d.z + (d.axis === 'z' ? d.t * d.w * 0.92 : 0));
      if (d.auto && !d.locked && !d.open && focus) { const dx = focus.x - d.x, dz = focus.z - d.z; if (dx * dx + dz * dz < 5.5 && Math.abs((focus.y || 0) - d.y) < 2) this.openDoor(d, true); }
    }
    for (const m of this.movers) { const px = m.x0, py = m.y0, pz = m.z0; m.mover(t, m); m.dx = m.x0 - px; m.dy = m.y0 - py; m.dz = m.z0 - pz; }
    for (let i = 0; i < this.anim.length; i++) this.anim[i](t, dt, focus);
    this._lights(dt, t, focus);
  }
  _lights(dt, t, focus) {
    if (!this.lightPool.length || !focus) return;
    this._lt = (this._lt || 0) - dt;
    if (this._lt <= 0) {
      this._lt = 0.15; const cand = [];
      for (const l of this.lamps) { const dx = l.x - focus.x, dz = l.z - focus.z, d2 = dx * dx + dz * dz; if (d2 < 900) cand.push([d2, l]); }
      cand.sort((a, b) => a[0] - b[0]);
      this._assign = cand.slice(0, this.lightPool.length).map(c => c[1]);
    }
    const asg = this._assign || [];
    this.lightPool.forEach((pl, i) => {
      const l = asg[i];
      if (l) {
        pl.position.set(l.x, l.y, l.z); pl.color.copy(l.color); pl.distance = l.range;
        const f = l.flicker ? 1 - l.flicker * (0.5 + 0.5 * Math.sin(t * 17 + l.phase) * Math.sin(t * 7.3 + l.phase * 2)) : 1;
        pl._target = l.intensity * f;
      } else pl._target = 0;
      pl.intensity += (pl._target - pl.intensity) * Math.min(1, dt * 6);
      pl.visible = pl.intensity > 0.02;
    });
  }
  updateZone(p) {
    let z = null;
    for (const q of this.zones) if (p.x >= q.x0 && p.x <= q.x1 && p.z >= q.z0 && p.z <= q.z1 && p.y >= q.y0 && p.y <= q.y1) { z = q; break; }
    if (z !== this.curZone) {
      if (this.curZone) for (const o of this.curZone.hide) o.visible = true;
      if (z) for (const o of z.hide) o.visible = false;
      this.curZone = z;
    }
    return z;
  }
  updateOcclusion(cam, target) {
    if (!this.occluders.length) return;
    const dir = new THREE.Vector3().subVectors(target, cam); const len = dir.length(); dir.normalize();
    const ray = new THREE.Ray(cam, dir); const hit = new THREE.Vector3();
    for (const o of this.occluders) {
      if (!o.mesh.visible) continue;
      const near = Math.abs(o.box.max.x + o.box.min.x - cam.x - target.x) * 0.5 < 60;
      if (!near) continue;
      let h = false;
      if (ray.intersectBox(o.box, hit)) { const dd = hit.distanceTo(cam); h = dd < len - 0.3; }
      if (h !== o.ghosted) { o.ghosted = h; o.mesh.material = h ? o.ghost : o.mat; o.mesh.castShadow = !h; }
    }
  }

  /** is a circle (radius m) at (x,z) standing at height y free of solid colliders? */
  isFree(x, z, y = 0, m = 0.8) {
    const b = this.bounds; if (x < b.x0 + m || x > b.x1 - m || z < b.z0 + m || z > b.z1 - m) return false;
    const q = this._q6 || (this._q6 = []); this.query(q, x - m, z - m, x + m, z + m);
    for (const c of q) {
      if (!c.enabled || c.wall === false) continue;
      if (!(c.y1 > y + 0.5 && c.y0 < y + 1.8)) continue;
      const dx = Math.max(c.x0 - x, 0, x - c.x1), dz = Math.max(c.z0 - z, 0, z - c.z1);
      if (dx * dx + dz * dz < m * m) return false;
    }
    return true;
  }
  freeSpot(a, m = 0.9, tries = 40, rng = this.rng) {
    for (let i = 0; i < tries; i++) { const x = rng.range(a.x0 + m, a.x1 - m), z = rng.range(a.z0 + m, a.z1 - m); if (this.isFree(x, z, a.y || 0, m)) return { x, z, y: a.y || 0 }; }
    return null;
  }
  /** register path / segment info */
  dispose() { this.group.traverse(o => { if (o.geometry && !o.userData.keepGeo) o.geometry.dispose?.(); }); }
}

// ---------------- navigation grid (A*) ----------------
export class Nav {
  constructor(world) {
    this.w = world; const b = world.bounds;
    this.cell = 1; this.x0 = Math.floor(b.x0) - 1; this.z0 = Math.floor(b.z0) - 1;
    this.W = Math.ceil(b.x1 - b.x0) + 3; this.H = Math.ceil(b.z1 - b.z0) + 3;
    this.blocked = new Uint16Array(this.W * this.H);
    this.enabled = !world.void && !(world.noNav);
    if (this.enabled) for (const c of world.colliders) if (c.enabled && this._relevant(c)) { this._mark(c, 1); c._navOn = true; }
    if (this.enabled) for (const c of world.navBlocks || []) this._mark(c, 1);
    this.open = new Float32Array(this.W * this.H); this.from = new Int32Array(this.W * this.H); this.mark = new Uint32Array(this.W * this.H); this.runId = 0;
  }
  _relevant(c) { return c.y0 < 1.0 && c.y1 > 0.56 && c.walk !== false && c.nav !== false; }
  _cellsOf(c) {
    if (c._cells) return c._cells;
    const r = 0.5, cells = [];
    const ix0 = Math.max(0, Math.floor(c.x0 - r - this.x0)), ix1 = Math.min(this.W - 1, Math.floor(c.x1 + r - this.x0));
    const iz0 = Math.max(0, Math.floor(c.z0 - r - this.z0)), iz1 = Math.min(this.H - 1, Math.floor(c.z1 + r - this.z0));
    for (let iz = iz0; iz <= iz1; iz++) for (let ix = ix0; ix <= ix1; ix++) {
      const cx = this.x0 + ix + 0.5, cz = this.z0 + iz + 0.5;
      const dx = Math.max(c.x0 - cx, 0, cx - c.x1), dz = Math.max(c.z0 - cz, 0, cz - c.z1);
      if (dx * dx + dz * dz < r * r) cells.push(iz * this.W + ix);
    }
    return (c._cells = cells);
  }
  _mark(c, d) { for (const i of this._cellsOf(c)) this.blocked[i] += d; }
  toggle(c, blocked) { if (!this.enabled || !this._relevant(c)) return; if (!!c._navOn === blocked) return; c._navOn = blocked; this._mark(c, blocked ? 1 : -1); }
  idx(x, z) { const ix = Math.floor(x - this.x0), iz = Math.floor(z - this.z0); if (ix < 0 || iz < 0 || ix >= this.W || iz >= this.H) return -1; return iz * this.W + ix; }
  free(x, z) { const i = this.idx(x, z); return i >= 0 && !this.blocked[i]; }
  los(ax, az, bx, bz) {
    const d = Math.hypot(bx - ax, bz - az), n = Math.max(1, Math.ceil(d / 0.4));
    for (let i = 1; i <= n; i++) { const t = i / n; if (!this.free(ax + (bx - ax) * t, az + (bz - az) * t)) return false; }
    return true;
  }
  /** flood-fill ground reachability from a point (cached; doors count as passable). Returns Uint8Array (1 = reachable). */
  reach(sx, sz, force) {
    if (this._reach && !force) return this._reach;
    const W = this.W, H = this.H, r = new Uint8Array(W * H); let s = this._nearestFree(this.idx(sx, sz)); if (s < 0) return (this._reach = r);
    const q = [s]; r[s] = 1;
    while (q.length) { const c = q.pop(), cx = c % W, cz = (c / W) | 0;
      for (let k = 0; k < 4; k++) { const nx = cx + (k === 0) - (k === 1), nz = cz + (k === 2) - (k === 3); if (nx < 0 || nz < 0 || nx >= W || nz >= H) continue; const n = nz * W + nx; if (r[n] || this.blocked[n]) continue; r[n] = 1; q.push(n); } }
    return (this._reach = r);
  }
  isReach(x, z) { const i = this.idx(x, z); return i >= 0 && !!this._reach && !!this._reach[i]; }
  _nearestFree(i) {
    if (!this.blocked[i]) return i; const W = this.W, H = this.H, ix = i % W, iz = (i / W) | 0;
    for (let r = 1; r < 5; r++) for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) { const x = ix + dx, z = iz + dz; if (x < 0 || z < 0 || x >= W || z >= H) continue; const k = z * W + x; if (!this.blocked[k]) return k; }
    return -1;
  }
  path(sx, sz, tx, tz, maxNodes = 3000) {
    if (!this.enabled) return null;
    let s = this.idx(sx, sz), t = this.idx(tx, tz); if (s < 0 || t < 0) return null;
    s = this._nearestFree(s); t = this._nearestFree(t); if (s < 0 || t < 0) return null;
    const W = this.W, id = ++this.runId; const heap = new Heap(); const g = this._g || (this._g = new Float32Array(this.W * this.H));
    const tx0 = t % W, tz0 = (t / W) | 0;
    g[s] = 0; this.mark[s] = id; this.from[s] = -1; heap.push(s, 0); let n = 0, found = false;
    const DX = [1, -1, 0, 0, 1, 1, -1, -1], DZ = [0, 0, 1, -1, 1, -1, 1, -1];
    const closed = this._closed || (this._closed = new Uint32Array(this.W * this.H));
    while (heap.size && n++ < maxNodes) {
      const cur = heap.pop(); if (closed[cur] === id) continue; closed[cur] = id;
      if (cur === t) { found = true; break; }
      const cx = cur % W, cz = (cur / W) | 0;
      for (let k = 0; k < 8; k++) {
        const nx = cx + DX[k], nz = cz + DZ[k]; if (nx < 0 || nz < 0 || nx >= W || nz >= this.H) continue;
        const ni = nz * W + nx; if (this.blocked[ni] || closed[ni] === id) continue;
        if (k >= 4 && (this.blocked[cz * W + nx] || this.blocked[nz * W + cx])) continue;
        const ng = g[cur] + (k < 4 ? 1 : 1.414);
        if (this.mark[ni] !== id || ng < g[ni]) { this.mark[ni] = id; g[ni] = ng; this.from[ni] = cur; const hx = Math.abs(nx - tx0), hz = Math.abs(nz - tz0); heap.push(ni, ng + (hx + hz) + (1.414 - 2) * Math.min(hx, hz)); }
      }
    }
    if (!found) return null;
    const pts = []; for (let c = t; c !== -1; c = this.from[c]) pts.push({ x: this.x0 + (c % W) + 0.5, z: this.z0 + ((c / W) | 0) + 0.5 });
    pts.reverse();
    // string pulling
    const out = [pts[0]]; let a = 0;
    while (a < pts.length - 1) { let b = pts.length - 1; while (b > a + 1 && !this.los(pts[a].x, pts[a].z, pts[b].x, pts[b].z)) b--; out.push(pts[b]); a = b; }
    return out;
  }
}
