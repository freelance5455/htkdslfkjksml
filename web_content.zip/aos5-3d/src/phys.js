// Shared movement helper: horizontal sub-stepped collision + gravity/ground/ceiling handling for cylinder entities.
import { G } from './ctx.js';
export const GRAV = 22, STEP = 0.56;

export function moveXZ(e, dx, dz, o = {}) {
  const W = G.W; const dist = Math.hypot(dx, dz); if (dist < 1e-6) { if (!o.noResolve) W.resolve(e, o.step ?? STEP); return false; }
  const n = Math.max(1, Math.ceil(dist / (e.r * 0.7))); let hit = false;
  for (let i = 0; i < n; i++) {
    e.x += dx / n; e.z += dz / n;
    if (o.edgeGuard && e.grounded) { // do not walk off ledges (void worlds / enemies)
      const gy = W.groundAt(e.x, e.z, e.y, e.r * 0.5);
      if (gy < e.y - 0.7) { e.x -= dx / n; e.z -= dz / n; hit = true; continue; }
    }
    if (W.resolve(e, o.step ?? STEP)) hit = true;
  }
  return hit;
}
/** vertical step. returns {landed:speed} when landing this frame */
export function stepVertical(e, dt, o = {}) {
  const W = G.W; let landed = 0;
  const gy = W.groundAt(e.x, e.z, e.y, e.r, o.step ?? STEP); e.gy = gy;
  const gc = W.lastGround;
  if (e.grounded && gc && gc.mover) { e.x += gc.dx || 0; e.z += gc.dz || 0; }
  if (e.vy > 0 || e.y > gy + 0.06) {
    if (e.grounded && e.vy <= 0 && e.y - gy < 0.3 && !o.noSnap) { e.y = gy; e.vy = 0; return { landed: 0 }; }
    e.grounded = false; e.vy -= (o.grav ?? GRAV) * dt; if (e.vy < -32) e.vy = -32;
    e.y += e.vy * dt;
    if (e.vy > 0) { const c = W.ceilingAt(e.x, e.z, e.y - e.vy * dt, e.r, e.h); if (e.y + e.h > c) { e.y = c - e.h; e.vy = 0; } }
    if (e.vy <= 0 && e.y <= gy) { landed = -e.vy; e.y = gy; e.vy = 0; e.grounded = true; }
  } else { e.y = gy; e.vy = 0; e.grounded = true; }
  return { landed };
}
