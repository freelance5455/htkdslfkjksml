// Shared combat: damage dispatch, area/cone hits, projectiles. Teams: 'p' (player side) and 'e' (enemy side).
import * as THREE from 'three';
import { G } from './ctx.js';
import { angDiff } from './util.js';

const projGeo = new THREE.SphereGeometry(1, 8, 6);
const mats = new Map();
const pm = (c) => { let m = mats.get(c); if (!m) { m = new THREE.MeshBasicMaterial({ color: c, fog: false }); mats.set(c, m); } return m; };
const haloMats = new Map();
const hm = (c) => { let m = haloMats.get(c); if (!m) { m = new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }); haloMats.set(c, m); } return m; };

export const Combat = {
  projs: [], free: [],
  reset() { for (const p of this.projs) { G.stage.scene.remove(p.mesh); } this.projs.length = 0; },
  /** opposing targets for an attacker team */
  foes(team) {
    const out = [];
    if (team === 'p') {
      for (const e of G.enemies) if (!e.dead && !e.untargetable) out.push(e);
      for (const b of G.W.breakables) if (!b.dead && !b.protect && b.hp > 0) out.push(b);
    } else {
      const p = G.p; if (p && !p.dead && !p.ghost) out.push(p);
      for (const a of G.allies) if (!a.down) out.push(a);
      const pr = G.run && G.run.protectObj; if (pr && !pr.dead) out.push(pr);
      for (const t of G.turrets || []) out.push(t);
    }
    return out;
  },
  damage(t, dmg, o = {}) {
    if (!t || t.dead) return 0;
    switch (t.kind) {
      case 'enemy': return G.Enemy.hurt(t, dmg, o);
      case 'player': return G.Player.hurt(dmg, o);
      case 'ally': return G.Ally.hurt(t, dmg, o);
      case 'breakable': return G.Run.hurtBreakable(t, dmg, o);
      case 'turret': t.hp -= dmg; if (t.hp <= 0) t.life = 0; return dmg;
    }
    return 0;
  },
  /** circular area hit. o: {x,z,y,r,dmg,team,knock,stun,falloff,src} */
  area(x, z, r, dmg, team, o = {}) {
    let n = 0;
    for (const t of this.foes(team)) {
      const d = Math.hypot(t.x - x, t.z - z) - (t.r || 0.4); if (d > r) continue;
      if (o.y !== undefined && Math.abs((t.y || 0) - o.y) > (o.dy ?? 2.6)) continue;
      const k = o.falloff === false ? 1 : 1 - 0.35 * Math.max(0, d) / r;
      const L = Math.hypot(t.x - x, t.z - z) || 1;
      this.damage(t, dmg * k, { dx: (t.x - x) / L, dz: (t.z - z) / L, knock: (o.knock || 0) * k, stun: o.stun, src: o.src, from: o.from, crit: o.crit, noFlinch: o.noFlinch, kind: o.kind });
      n++;
    }
    return n;
  },
  /** cone/arc melee hit from src pose. returns number hit */
  cone(src, reach, arc, dmg, team, o = {}) {
    let n = 0; const fx = Math.sin(src.yaw), fz = Math.cos(src.yaw);
    for (const t of this.foes(team)) {
      const dx = t.x - src.x, dz = t.z - src.z; const d = Math.hypot(dx, dz) - (t.r || 0.4);
      if (d > reach) continue;
      if (Math.abs((t.y || 0) - src.y) > (o.dy ?? 1.9)) continue;
      if (d > 0.3) { const a = Math.abs(angDiff(src.yaw, Math.atan2(dx, dz))); if (a > arc / 2) continue; }
      const L = Math.hypot(dx, dz) || 1;
      this.damage(t, dmg, { dx: dx / L, dz: dz / L, knock: o.knock, stun: o.stun, src: o.src, from: src, crit: o.crit, noFlinch: o.noFlinch, kind: 'melee', pierce: o.pierce });
      n++; if (o.max && n >= o.max) break;
    }
    return n;
  },
  nearest(x, z, range, team = 'p', filter) {
    let best = null, bd = range;
    for (const t of this.foes(team)) { if (filter && !filter(t)) continue; if (t.kind === 'breakable' && !t.aimable) continue; const d = Math.hypot(t.x - x, t.z - z) - (t.r || 0.4); if (d < bd) { bd = d; best = t; } }
    return best;
  },
  // ---------------- projectiles ----------------
  shoot(o) { // {x,y,z, dx,dy,dz (normalized dir), spd, dmg, team, color, size, range, pierce, explode, knock, grav, homing, src}
    const p = this.free.pop() || { mesh: new THREE.Mesh(projGeo, null), halo: new THREE.Mesh(projGeo, null) };
    p.mesh.material = pm(o.color || 0xffffff); p.halo.material = hm(o.color || 0xffffff);
    p.x = o.x; p.y = o.y; p.z = o.z; const L = Math.hypot(o.dx, o.dy || 0, o.dz) || 1;
    p.vx = o.dx / L * o.spd; p.vy = (o.dy || 0) / L * o.spd; p.vz = o.dz / L * o.spd;
    p.spd = o.spd; p.dmg = o.dmg; p.team = o.team; p.size = o.size || 0.15; p.range = o.range || 30; p.dist = 0; p.pierce = o.pierce || 0; p.explode = o.explode || 0; p.knock = o.knock || 0; p.grav = o.grav || 0;
    p.src = o.src; p.hit = new Set(); p.color = o.color || 0xffffff; p.life = (o.range || 30) / o.spd + 0.5; p.homing = o.homing || 0; p.kind = o.kind || 'proj'; p.stun = o.stun; p.onHit = o.onHit; p.crit = o.crit; p.mdl = o.mdl;
    p.mesh.scale.setScalar(p.size); p.halo.scale.setScalar(p.size * 2.2); p.mesh.position.set(p.x, p.y, p.z); p.halo.position.copy(p.mesh.position);
    G.stage.scene.add(p.mesh); G.stage.scene.add(p.halo); this.projs.push(p); return p;
  },
  _kill(i, impact) {
    const p = this.projs[i]; G.stage.scene.remove(p.mesh); G.stage.scene.remove(p.halo); this.free.push(p); this.projs.splice(i, 1);
  },
  update(dt) {
    for (let i = this.projs.length - 1; i >= 0; i--) {
      const p = this.projs[i]; p.life -= dt;
      const step = p.spd * dt, n = Math.max(1, Math.ceil(step / 0.35)); let dead = p.life <= 0;
      for (let s = 0; s < n && !dead; s++) {
        const h = dt / n;
        if (p.homing) { const t = this.nearest(p.x, p.z, 14, p.team); if (t) { const dx = t.x - p.x, dy = (t.y || 0) + (t.h || 1.2) * 0.6 - p.y, dz = t.z - p.z, L = Math.hypot(dx, dy, dz) || 1; p.vx += (dx / L * p.spd - p.vx) * Math.min(1, h * p.homing); p.vy += (dy / L * p.spd - p.vy) * Math.min(1, h * p.homing); p.vz += (dz / L * p.spd - p.vz) * Math.min(1, h * p.homing); } }
        p.vy -= p.grav * h; p.x += p.vx * h; p.y += p.vy * h; p.z += p.vz * h; p.dist += p.spd * h;
        if (p.dist > p.range) { dead = true; this.impact(p, false); break; }
        if (G.W.pointSolid(p.x, p.y, p.z)) { dead = true; this.impact(p, true); break; }
        for (const t of this.foes(p.team)) {
          if (p.hit.has(t)) continue;
          const ty = t.y || 0, th = t.h || 1.2; if (p.y < ty - 0.2 || p.y > ty + th + 0.2) continue;
          if (t.kind === 'breakable') { if (p.x < t.collider.x0 - p.size || p.x > t.collider.x1 + p.size || p.z < t.collider.z0 - p.size || p.z > t.collider.z1 + p.size) continue; }
          else { const dx = t.x - p.x, dz = t.z - p.z, rr = (t.r || 0.4) + p.size; if (dx * dx + dz * dz > rr * rr) continue; }
          p.hit.add(t);
          const L = Math.hypot(p.vx, p.vz) || 1;
          if (!p.explode) this.damage(t, p.dmg, { dx: p.vx / L, dz: p.vz / L, knock: p.knock, src: p.src, kind: 'proj', stun: p.stun, crit: p.crit, mdl: p.mdl, hx: p.x, hy: p.y, hz: p.z });
          if (p.onHit) p.onHit(t, p);
          if (p.pierce > 0) { p.pierce--; G.fx.hit(p.x, p.y, p.z, p.color); } else { dead = true; this.impact(p, true, t); break; }
        }
      }
      if (dead) { this._kill(i); continue; }
      p.mesh.position.set(p.x, p.y, p.z); p.halo.position.copy(p.mesh.position);
      if (Math.random() < dt * 40) G.fx.glow(p.x, p.y, p.z, p.color, 1, { size: p.size * 1.6, life: 0.25, speed: 0.3 });
    }
  },
  impact(p, hit, tgt) {
    if (p.explode) { G.fx.explode(p.x, p.y, p.z, p.explode, p.color); G.audio && G.audio.sfx('boom'); this.area(p.x, p.z, p.explode, p.dmg, p.team, { y: p.y, dy: 3, knock: p.knock, src: p.src, stun: p.stun }); }
    else if (hit) G.fx.spark(p.x, p.y, p.z, p.color, 6, { speed: 3 });
  },
};
