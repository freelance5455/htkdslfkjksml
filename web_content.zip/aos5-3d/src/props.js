// Environment props (cars, crates, shelves, containers, lab gear ...). All built from primitives, original designs.
import * as THREE from 'three';
import { plain, glow, glass, decalMat } from './materials.js';
import { RNG } from './util.js';

const CYL = (r1, r2, h, s = 10) => new THREE.CylinderGeometry(r1, r2, h, s);
const SPH = (r) => new THREE.SphereGeometry(r, 10, 8);
const CONE = (r, h, s = 7) => new THREE.ConeGeometry(r, h, s);
const gcache = {};
const cyl = (r1, r2, h, s) => gcache[`c${r1}${r2}${h}${s}`] || (gcache[`c${r1}${r2}${h}${s}`] = CYL(r1, r2, h, s));
const sph = (r) => gcache[`s${r}`] || (gcache[`s${r}`] = SPH(r));
const cone = (r, h, s) => gcache[`n${r}${h}${s}`] || (gcache[`n${r}${h}${s}`] = CONE(r, h, s));

const CAR_COLORS = [0xb03a2e, 0x2e6db0, 0xd8d8d8, 0x3a3a40, 0xd4a82a, 0x2e8b57, 0x7a4aa0, 0xe0e0e8];
const CRATE_C = [0xa8794a, 0x9a6c3f, 0xb98856];

export const Props = {
  car(W, x, z, along = 'x', color, wreck = false) {
    const r = W.rng, c = color ?? r.pick(CAR_COLORS), L = 2.15, Wd = 0.92;
    const sx = along === 'x' ? L : Wd, sz = along === 'x' ? Wd : L;
    const body = { plain: wreck ? 0x5a4a40 : c, rough: 0.45, metal: wreck ? 0.2 : 0.55 };
    W.box(x - sx, 0.38, z - sz, x + sx, 1.0, z + sz, body, { collide: false });
    const cx = along === 'x' ? 0.15 : 0, cz = along === 'z' ? 0.15 : 0, csx = along === 'x' ? 1.05 : Wd - 0.08, csz = along === 'z' ? 1.05 : Wd - 0.08;
    W.box(x + cx - csx, 1.0, z + cz - csz, x + cx + csx, 1.55, z + cz + csz, { glass: 0x6a88a0, op: 0.7 }, { collide: false });
    W.box(x + cx - csx + 0.05, 1.5, z + cz - csz + 0.05, x + cx + csx - 0.05, 1.6, z + cz + csz - 0.05, body, { collide: false });
    for (const a of [-1, 1]) for (const b of [-1, 1]) {
      const wx = x + (along === 'x' ? a * 1.35 : b * (Wd - 0.05)), wz = z + (along === 'x' ? b * (Wd - 0.05) : a * 1.35);
      W.box(wx - 0.36, 0, wz - 0.36, wx + 0.36, 0.72, wz + 0.36, { plain: 0x15161a }, { collide: false });
    }
    // lights
    const hl = along === 'x' ? [[x + L, z - 0.55], [x + L, z + 0.55]] : [[x - 0.55, z + L], [x + 0.55, z + L]];
    for (const [lx, lz] of hl) W.box(lx - 0.05, 0.62, lz - 0.1, lx + 0.05, 0.78, lz + 0.1, { glow: wreck ? 0x403830 : 0xfff2c0 }, { collide: false });
    const col = W.addCollider({ x0: x - sx, x1: x + sx, z0: z - sz, z1: z + sz, y0: 0, y1: 1.55, nav: true });
    return col;
  },
  crate(W, x, z, s = 1.0, y = 0, opt = {}) {
    const c = CRATE_C[(Math.abs(x * 7 + z * 3) | 0) % 3];
    W.box(x - s / 2, y, z - s / 2, x + s / 2, y + s, z + s / 2, { plain: c, rough: 0.9 }, { c: { y0: y, y1: y + s } });
    W.box(x - s / 2 - 0.01, y + s * 0.44, z - s / 2 - 0.01, x + s / 2 + 0.01, y + s * 0.56, z + s / 2 + 0.01, { plain: 0x6a4524, rough: 0.9 }, { collide: false });
  },
  stack(W, x, z, n = 2, s = 1.1) { for (let i = 0; i < n; i++) Props.crate(W, x + (i % 2) * 0.05, z, s, i * s); },
  barrel(W, x, z, color = 0x3a5a8a) {
    W.geo(cyl(0.4, 0.4, 1.0, 10), { plain: color, metal: 0.4, rough: 0.5 }, x, 0.5, z);
    W.geo(cyl(0.42, 0.42, 0.06, 10), { plain: 0x20252d }, x, 0.75, z); W.geo(cyl(0.42, 0.42, 0.06, 10), { plain: 0x20252d }, x, 0.25, z);
    W.addCollider({ x0: x - 0.4, x1: x + 0.4, z0: z - 0.4, z1: z + 0.4, y0: 0, y1: 1.0 });
  },
  dumpster(W, x, z, along = 'x') {
    const a = along === 'x' ? [1.3, 0.65] : [0.65, 1.3];
    W.box(x - a[0], 0.2, z - a[1], x + a[0], 1.25, z + a[1], { plain: 0x2f6a45, rough: 0.6, metal: 0.3 });
    W.box(x - a[0] - 0.04, 1.25, z - a[1] - 0.04, x + a[0] + 0.04, 1.35, z + a[1] + 0.04, { plain: 0x1f4a30 }, { collide: false });
  },
  barrier(W, x, z, len = 2.4, along = 'x') {
    const sx = along === 'x' ? len / 2 : 0.3, sz = along === 'x' ? 0.3 : len / 2;
    W.box(x - sx, 0, z - sz, x + sx, 0.95, z + sz, 'concrete');
    W.box(x - sx - 0.01, 0.55, z - sz - 0.01, x + sx + 0.01, 0.8, z + sz + 0.01, 'hazard', { collide: false });
  },
  lampPost(W, x, z, h = 5.2, color = 0xffd8a0, on = true, side = 0) {
    W.box(x - 0.1, 0, z - 0.1, x + 0.1, h, z + 0.1, { plain: 0x24272e, metal: 0.6 }, { c: { proj: false } });
    W.box(x - 0.35 + side * 0.3, h, z - 0.2, x + 0.35 + side * 0.3, h + 0.12, z + 0.2, { plain: 0x24272e }, { collide: false });
    W.box(x - 0.3 + side * 0.3, h - 0.04, z - 0.16, x + 0.3 + side * 0.3, h, z + 0.16, on ? { glow: color } : { plain: 0x555 }, { collide: false });
    if (on) W.lamp(x + side * 0.3, h - 0.3, z, color, 9, 20, { flicker: 0 });
  },
  bench(W, x, z, along = 'x') {
    const sx = along === 'x' ? 0.9 : 0.25, sz = along === 'x' ? 0.25 : 0.9;
    W.box(x - sx, 0.4, z - sz, x + sx, 0.5, z + sz, { plain: 0x6a4a2a }, { c: { y0: 0, y1: 0.5 } });
    W.box(x - (along === 'x' ? 0.9 : 0.05) - (along === 'x' ? 0 : 0.2), 0.5, z - (along === 'x' ? 0.25 : 0.9), x + (along === 'x' ? 0.9 : -0.15), 0.95, z - (along === 'x' ? 0.18 : -0.9), { plain: 0x6a4a2a }, { collide: false });
    W.box(x - sx, 0, z - sz, x - sx + 0.1, 0.4, z + sz, { plain: 0x24272e }, { collide: false }); W.box(x + sx - 0.1, 0, z - sz, x + sx, 0.4, z + sz, { plain: 0x24272e }, { collide: false });
  },
  tree(W, x, z, s = 1) {
    W.geo(cyl(0.18 * s, 0.26 * s, 2.4 * s, 7), { plain: 0x5a3e28, rough: 1 }, x, 1.2 * s, z);
    const c = [0x2f6a34, 0x3a7a3a, 0x276030][(Math.abs(x * 3 + z) | 0) % 3];
    W.geo(sph(1.3 * s), { plain: c, rough: 1 }, x, 3.1 * s, z); W.geo(sph(0.95 * s), { plain: c + 0x0a1a0a, rough: 1 }, x + 0.7 * s, 3.7 * s, z + 0.3 * s); W.geo(sph(0.9 * s), { plain: c, rough: 1 }, x - 0.6 * s, 3.5 * s, z - 0.4 * s);
    W.addCollider({ x0: x - 0.3, x1: x + 0.3, z0: z - 0.3, z1: z + 0.3, y0: 0, y1: 4 });
  },
  deadTree(W, x, z) {
    W.geo(cyl(0.1, 0.26, 3.2, 6), { plain: 0x3a3028, rough: 1 }, x, 1.6, z); W.geo(cyl(0.05, 0.1, 1.4, 5), { plain: 0x3a3028 }, x + 0.5, 3.0, z, 0, 0, -0.9); W.geo(cyl(0.04, 0.08, 1.2, 5), { plain: 0x3a3028 }, x - 0.4, 2.7, z, 0, 0, 0.8);
    W.addCollider({ x0: x - 0.25, x1: x + 0.25, z0: z - 0.25, z1: z + 0.25, y0: 0, y1: 4 });
  },
  fountain(W, x, z, r = 3) {
    W.geo(cyl(r, r + 0.1, 0.7, 20), 'concrete', x, 0.35, z);
    W.geo(cyl(r - 0.25, r - 0.25, 0.05, 20), { glow: 0x4a8ab8 }, x, 0.66, z);
    W.geo(cyl(0.3, 0.45, 1.8, 10), 'concrete', x, 1.4, z); W.geo(cyl(1.0, 0.2, 0.3, 14), 'concrete', x, 2.2, z);
    W.addCollider({ x0: x - r, x1: x + r, z0: z - r, z1: z + r, y0: 0, y1: 0.7 });
    W.addCollider({ x0: x - 0.45, x1: x + 0.45, z0: z - 0.45, z1: z + 0.45, y0: 0, y1: 2.4 });
  },
  planter(W, x, z, w = 3, d = 1.2, green = true) {
    W.box(x - w / 2, 0, z - d / 2, x + w / 2, 0.7, z + d / 2, 'concrete');
    if (green) { W.box(x - w / 2 + 0.1, 0.7, z - d / 2 + 0.1, x + w / 2 - 0.1, 0.85, z + d / 2 - 0.1, 'grass', { collide: false }); for (let i = 0; i < Math.floor(w); i++) W.geo(sph(0.34), { plain: 0x3a7a3a, rough: 1 }, x - w / 2 + 0.5 + i, 1.0, z); }
  },
  kiosk(W, x, z, color = 0xd05a3a) {
    W.box(x - 1.6, 0, z - 1.2, x + 1.6, 2.4, z + 1.2, { plain: color, rough: 0.7 });
    W.box(x - 1.9, 2.4, z - 1.5, x + 1.9, 2.6, z + 1.5, { plain: 0x2b2f38 }, { collide: false });
    W.box(x - 1.2, 1.0, z - 1.25, x + 1.2, 1.9, z - 1.19, { glow: 0xffe9b0 }, { collide: false });
  },
  shelf(W, x, z, len = 4, along = 'x', color = 0x6a7480) {
    const sx = along === 'x' ? len / 2 : 0.4, sz = along === 'x' ? 0.4 : len / 2;
    W.box(x - sx, 0, z - sz, x + sx, 2.1, z + sz, { plain: color, metal: 0.5, rough: 0.5 });
    const r = W.rng;
    for (let lvl = 0; lvl < 4; lvl++) for (let i = 0; i < Math.floor(len / 0.7); i++) {
      const o = -len / 2 + 0.4 + i * 0.7; const bx = along === 'x' ? x + o : x, bz = along === 'x' ? z : z + o;
      const h = r.range(0.25, 0.4); W.box(bx - (along === 'x' ? 0.25 : 0.43), 0.1 + lvl * 0.5, bz - (along === 'x' ? 0.43 : 0.25), bx + (along === 'x' ? 0.25 : 0.43), 0.1 + lvl * 0.5 + h, bz + (along === 'x' ? 0.43 : 0.25), { plain: r.pick([0xd05a3a, 0x3a8ad0, 0xd0b03a, 0x4ab070, 0xe0e0e0]), rough: 0.8 }, { collide: false });
    }
  },
  rack(W, x, z, len = 4, along = 'x') { // industrial pallet rack
    const sx = along === 'x' ? len / 2 : 0.55, sz = along === 'x' ? 0.55 : len / 2;
    W.box(x - sx, 0, z - sz, x + sx, 3.2, z + sz, { plain: 0xd18a1f, metal: 0.4, rough: 0.5 });
    const r = W.rng;
    for (let l = 0; l < 3; l++) for (let i = 0; i < Math.floor(len / 1.3); i++) { const o = -len / 2 + 0.7 + i * 1.3; const bx = along === 'x' ? x + o : x, bz = along === 'x' ? z : z + o; W.box(bx - 0.5, 0.15 + l * 1.05, bz - 0.5, bx + 0.5, 0.15 + l * 1.05 + r.range(0.5, 0.9), bz + 0.5, { plain: r.pick(CRATE_C), rough: 0.9 }, { collide: false }); }
  },
  counter(W, x, z, len = 3, along = 'x', color = 0x7a5a3a) {
    const sx = along === 'x' ? len / 2 : 0.5, sz = along === 'x' ? 0.5 : len / 2;
    W.box(x - sx, 0, z - sz, x + sx, 1.05, z + sz, { plain: color, rough: 0.7 }); W.box(x - sx - 0.05, 1.05, z - sz - 0.05, x + sx + 0.05, 1.12, z + sz + 0.05, { plain: 0xd8d4cc, rough: 0.4 }, { collide: false });
  },
  desk(W, x, z, along = 'x') {
    const sx = along === 'x' ? 0.9 : 0.5, sz = along === 'x' ? 0.5 : 0.9;
    W.box(x - sx, 0, z - sz, x + sx, 0.85, z + sz, { plain: 0x8a7254, rough: 0.7 });
    W.box(x - 0.25, 0.85, z - 0.05, x + 0.25, 1.2, z + 0.05, { glow: 0x7ad0ff }, { collide: false });
  },
  bed(W, x, z, along = 'x') {
    const sx = along === 'x' ? 1.1 : 0.7, sz = along === 'x' ? 0.7 : 1.1;
    W.box(x - sx, 0, z - sz, x + sx, 0.45, z + sz, { plain: 0x5a4030 }); W.box(x - sx + 0.05, 0.45, z - sz + 0.05, x + sx - 0.05, 0.62, z + sz - 0.05, { plain: W.rng.pick([0x7a8ab0, 0xb07a7a, 0x7ab08a]), rough: 1 }, { collide: false });
  },
  sofa(W, x, z, along = 'x') {
    const sx = along === 'x' ? 1.1 : 0.45, sz = along === 'x' ? 0.45 : 1.1;
    W.box(x - sx, 0, z - sz, x + sx, 0.55, z + sz, { plain: 0x5a3a52, rough: 1 }); W.box(x - (along === 'x' ? sx : sx), 0.55, z - sz, x + sx, 0.95, z - sz + (along === 'x' ? 0.2 : 0), { plain: 0x4a2e44, rough: 1 }, { collide: false });
  },
  table(W, x, z, w = 1.6, d = 0.9) { W.box(x - w / 2, 0.7, z - d / 2, x + w / 2, 0.82, z + d / 2, { plain: 0x8a6a48 }, { c: { y0: 0, y1: 0.82 } }); for (const a of [-1, 1]) for (const b of [-1, 1]) W.box(x + a * (w / 2 - 0.08) - 0.04, 0, z + b * (d / 2 - 0.08) - 0.04, x + a * (w / 2 - 0.08) + 0.04, 0.7, z + b * (d / 2 - 0.08) + 0.04, { plain: 0x3a2a1a }, { collide: false }); },
  locker(W, x, z, len = 3, along = 'x') {
    const sx = along === 'x' ? len / 2 : 0.35, sz = along === 'x' ? 0.35 : len / 2;
    W.box(x - sx, 0, z - sz, x + sx, 2.0, z + sz, { plain: 0x5a7a9a, metal: 0.5, rough: 0.5 });
    for (let i = 0; i < Math.floor(len / 0.5); i++) { const o = -len / 2 + 0.25 + i * 0.5; W.box(along === 'x' ? x + o - 0.01 : x - sx - 0.01, 0.8, along === 'x' ? z - sz - 0.01 : z + o - 0.01, along === 'x' ? x + o + 0.01 : x + sx + 0.01, 1.7, along === 'x' ? z + sz + 0.01 : z + o + 0.01, { plain: 0x24323f }, { collide: false }); }
  },
  server(W, x, z, along = 'x') {
    const sx = along === 'x' ? 0.5 : 0.45, sz = along === 'x' ? 0.45 : 0.5;
    W.box(x - sx, 0, z - sz, x + sx, 2.2, z + sz, { plain: 0x22262e, metal: 0.5 });
    const r = W.rng; for (let i = 0; i < 9; i++) W.box(x - 0.35, 0.2 + i * 0.2, z + (along === 'x' ? sz : 0) - 0.03, x + 0.35, 0.28 + i * 0.2, z + (along === 'x' ? sz + 0.02 : 0.02), { glow: r.pick([0x3aff7a, 0x3a8aff, 0xffb03a]) }, { collide: false });
  },
  console(W, x, z, along = 'x') { // lab console
    const sx = along === 'x' ? 1.0 : 0.5, sz = along === 'x' ? 0.5 : 1.0;
    W.box(x - sx, 0, z - sz, x + sx, 1.0, z + sz, { plain: 0xdfe6ec, rough: 0.4 }); W.box(x - sx + 0.1, 1.0, z - sz + 0.1, x + sx - 0.1, 1.5, z - sz + 0.2, { glow: 0x5ad0ff }, { collide: false });
  },
  tube(W, x, z, h = 2.6, color = 0x6aff8a) { // containment tube (glass + glow liquid)
    W.geo(cyl(0.6, 0.6, h, 14), { glass: 0xaaffcc, op: 0.3 }, x, h / 2, z); W.geo(cyl(0.5, 0.5, h * 0.8, 12), { glow: color, o: { transparent: true, opacity: 0.4 } }, x, h * 0.45, z);
    W.geo(cyl(0.7, 0.7, 0.2, 14), { plain: 0x2a3038, metal: 0.6 }, x, 0.1, z); W.geo(cyl(0.7, 0.7, 0.2, 14), { plain: 0x2a3038, metal: 0.6 }, x, h, z);
    W.addCollider({ x0: x - 0.65, x1: x + 0.65, z0: z - 0.65, z1: z + 0.65, y0: 0, y1: h });
    W.lamp(x, h * 0.6, z, color, 2.5, 7, { flicker: 0.2 });
  },
  forklift(W, x, z, along = 'x') {
    const f = along === 'x' ? 1 : 0; const sx = f ? 1.4 : 0.8, sz = f ? 0.8 : 1.4;
    W.box(x - sx, 0.3, z - sz, x + sx, 1.1, z + sz, { plain: 0xe0a020, metal: 0.4 }); W.box(x - sx * 0.5, 1.1, z - sz * 0.8, x + sx * 0.2 * (f ? 1 : 0) + (f ? 0 : sx * 0.5), 2.0, z + sz * 0.8, { plain: 0x24272e, metal: 0.5 }, { collide: false });
    W.box(x + (f ? sx : -0.5), 0, z + (f ? -0.5 : sz), x + (f ? sx + 1.4 : 0.5), 0.15, z + (f ? 0.5 : sz + 1.4), { plain: 0x3a3d44 }, { collide: false });
    W.addCollider({ x0: x - sx - (f ? 0 : 0), x1: x + sx + (f ? 1.4 : 0), z0: z - sz, z1: z + sz + (f ? 0 : 1.4), y0: 0, y1: 2.0 });
  },
  container(W, x, z, along = 'x', color = 0xc0392b, y = 0) {
    const sx = along === 'x' ? 3.0 : 1.25, sz = along === 'x' ? 1.25 : 3.0;
    W.box(x - sx, y, z - sz, x + sx, y + 2.6, z + sz, ['corrugated', color], { c: { y0: y, y1: y + 2.6 } });
    W.box(x - sx - 0.02, y + 2.5, z - sz - 0.02, x + sx + 0.02, y + 2.62, z + sz + 0.02, { plain: 0x24272e }, { collide: false });
  },
  pallet(W, x, z) { W.box(x - 0.6, 0, z - 0.6, x + 0.6, 0.16, z + 0.6, { plain: 0x8a6a3a }, { c: { y0: 0, y1: 0.16 } }); },
  pillar(W, x, z, w = 1.0, h = 5, spec = 'concrete') { W.box(x - w / 2, 0, z - w / 2, x + w / 2, h, z + w / 2, spec); },
  fence(W, x0, z0, x1, z1, h = 2.2) {
    const along = Math.abs(x1 - x0) > Math.abs(z1 - z0) ? 'x' : 'z';
    const th = 0.06;
    if (along === 'x') { W.box(x0, 0, z0 - th, x1, h, z0 + th, { glass: 0x9aa4ae, op: 0.25 }, { c: { proj: true, los: false } }); for (let x = x0; x <= x1; x += 3) W.box(x - 0.06, 0, z0 - 0.08, x + 0.06, h + 0.1, z0 + 0.08, { plain: 0x4a4f58, metal: 0.6 }, { collide: false }); }
    else { W.box(x0 - th, 0, z0, x0 + th, h, z1, { glass: 0x9aa4ae, op: 0.25 }, { c: { proj: true, los: false } }); for (let z = z0; z <= z1; z += 3) W.box(x0 - 0.08, 0, z - 0.06, x0 + 0.08, h + 0.1, z + 0.06, { plain: 0x4a4f58, metal: 0.6 }, { collide: false }); }
  },
  rubble(W, x, z, r = 1.6) {
    const rg = W.rng; for (let i = 0; i < 5; i++) { const a = rg.range(0, 6.28), d = rg.range(0, r * 0.6), s = rg.range(0.3, 0.7); W.box(x + Math.cos(a) * d - s, 0, z + Math.sin(a) * d - s, x + Math.cos(a) * d + s, s * 0.8, z + Math.sin(a) * d + s, { plain: rg.pick([0x7a766e, 0x8a8478, 0x6a6862]), rough: 1 }, { c: { y1: s * 0.8 } }); }
  },
  ac(W, x, y, z) { W.box(x - 0.9, y, z - 0.7, x + 0.9, y + 1.0, z + 0.7, { plain: 0x9aa3ae, metal: 0.4 }); const fan = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.05, 10), new THREE.MeshBasicMaterial({ color: 0x2a2e34 })); fan.position.set(x, y + 1.03, z); W.group.add(fan); W.addAnim((t) => { fan.rotation.y = t * 8; }); },
  antenna(W, x, z, y = 0, h = 8) { W.box(x - 0.08, y, z - 0.08, x + 0.08, y + h, z + 0.08, { plain: 0x777c85, metal: 0.7 }, { c: { proj: false } }); for (let i = 0; i < 4; i++) W.box(x - 0.6 + i * 0.1, y + h - 0.5 - i * 0.9, z - 0.04, x + 0.6 - i * 0.1, y + h - 0.45 - i * 0.9, z + 0.04, { plain: 0x777c85, metal: 0.7 }, { collide: false }); const l = new THREE.Mesh(new THREE.SphereGeometry(0.14, 6, 5), new THREE.MeshBasicMaterial({ color: 0xff3030 })); l.position.set(x, y + h + 0.1, z); W.group.add(l); W.addAnim((t) => { l.visible = Math.sin(t * 3 + x) > 0; }); },
  vent(W, x, z, h = 1.4) { // steam vent
    W.box(x - 0.4, 0, z - 0.4, x + 0.4, h * 0.5, z + 0.4, { plain: 0x4a4f58, metal: 0.7 });
    W.addAnim((t, dt) => { if (G_FX() && Math.random() < dt * 5) G_FX().puff(x, h * 0.55, z, 0xcfd6dc); });
  },
  fan(W, x, y, z, along = 'z', r = 1.0) { // wall/ceiling fan decoration
    const f = new THREE.Group(); f.position.set(x, y, z);
    for (let i = 0; i < 3; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(r, 0.04, 0.22), new THREE.MeshBasicMaterial({ color: 0x3a3f48 })); b.rotation.y = i * 2.09; b.position.set(Math.cos(i * 2.09) * r / 2, 0, -Math.sin(i * 2.09) * r / 2); f.add(b); }
    W.group.add(f); W.addAnim((t) => { f.rotation.y = t * 5; });
  },
  billboard(W, x, z, y, w, h, color = 0x2a2f3a, text = null) { W.box(x - w / 2, y, z - 0.1, x + w / 2, y + h, z + 0.1, { plain: color, rough: 0.6 }, { collide: false }); W.box(x - w / 2 + 0.2, y + 0.2, z - 0.12, x + w / 2 - 0.2, y + h - 0.2, z + 0.12, { glow: W.rng.pick([0xff5a7a, 0x5ad0ff, 0xffd25a, 0x7aff9a]) }, { collide: false }); },
  pipe(W, x0, y, z0, x1, z1, r = 0.14, color = 0x6a7480) { const dx = x1 - x0, dz = z1 - z0, L = Math.hypot(dx, dz); const ang = Math.atan2(dz, dx); W.geo(cyl(r, r, L, 8), { plain: color, metal: 0.7, rough: 0.4 }, (x0 + x1) / 2, y, (z0 + z1) / 2, Math.PI / 2, 0, 0, 1, 1, 1); /* rotated to run along z; fix yaw below */ },
  trainCar(W, x, z, len = 14, color = 0x5a6a80) {
    W.box(x - len / 2, 0.5, z - 1.4, x + len / 2, 3.4, z + 1.4, { plain: color, metal: 0.5, rough: 0.5 });
    for (let i = 0; i < 6; i++) { const wx = x - len / 2 + 1.2 + i * (len - 2.4) / 5; W.box(wx - 0.6, 1.6, z - 1.42, wx + 0.6, 2.7, z - 1.38, { glow: 0x3a4a5a }, { collide: false }); W.box(wx - 0.6, 1.6, z + 1.38, wx + 0.6, 2.7, z + 1.42, { glow: 0x3a4a5a }, { collide: false }); }
    W.box(x - len / 2, 0, z - 1.2, x + len / 2, 0.5, z + 1.2, { plain: 0x15171b }, { collide: false });
  },
  sign(W, x, z, y, text, color = 0xffd23a) { /* simple glowing plate */ W.box(x - 0.8, y, z - 0.05, x + 0.8, y + 0.5, z + 0.05, { glow: color }, { collide: false }); },
};

let _fx = null;
export function bindFx(f) { _fx = f; }
function G_FX() { return _fx; }
