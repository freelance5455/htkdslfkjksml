// Runtime hazards (fire jets, toxic gas, laser gates, sludge) with real visuals, warnings and damage.
import * as THREE from 'three';
import { G } from './ctx.js';

const add = (c, o = 0.6) => new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: o, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });

export const Hazards = {
  list: [],
  build(W) {
    this.clear();
    for (const h of W.hazards) {
      const o = { h, type: h.type, mesh: new THREE.Group(), on: 0, warnT: 0, hitCD: 0 };
      if (h.type === 'fire') {
        const c1 = new THREE.Mesh(new THREE.ConeGeometry(h.r * 0.75, 2.6, 8, 1, true), add(0xff7a1a, 0.55)); c1.position.y = 1.3; const c2 = new THREE.Mesh(new THREE.ConeGeometry(h.r * 0.4, 1.8, 8, 1, true), add(0xffe27a, 0.8)); c2.position.y = 0.9;
        const ring = new THREE.Mesh(new THREE.RingGeometry(h.r * 0.9, h.r, 24).rotateX(-Math.PI / 2), add(0xff4a1a, 0.5)); ring.position.y = 0.05;
        o.mesh.add(c1, c2, ring); o.flame = [c1, c2]; o.ring = ring; o.mesh.position.set(h.x, h.y || 0, h.z);
      } else if (h.type === 'gas') {
        const s = new THREE.Mesh(new THREE.SphereGeometry(h.r, 14, 10), add(0x7dff5a, 0.28)); s.position.y = h.r * 0.6; const ring = new THREE.Mesh(new THREE.RingGeometry(h.r * 0.9, h.r, 24).rotateX(-Math.PI / 2), add(0x9aff5a, 0.45)); ring.position.y = 0.05;
        o.mesh.add(s, ring); o.flame = [s]; o.ring = ring; o.mesh.position.set(h.x, h.y || 0, h.z);
      } else if (h.type === 'laser') {
        const L = h.z1 - h.z0; const beam = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, L), add(0xff2a2a, 0.9)); const glow = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, L), add(0xff5a3a, 0.25));
        o.mesh.add(beam, glow); o.flame = [beam, glow]; o.mesh.position.set(h.x, h.y, (h.z0 + h.z1) / 2);
        for (const z of [h.z0, h.z1]) { const em = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.8, 0.4), new THREE.MeshStandardMaterial({ color: 0x2a2f38, metalness: 0.7 })); em.position.set(0, 0, z - (h.z0 + h.z1) / 2 + (z < 0 ? -0.2 : 0.2)); o.mesh.add(em); }
      } else { continue; }
      G.stage.scene.add(o.mesh); this.list.push(o);
    }
    this.slow = 1;
  },
  clear() { for (const o of this.list) G.stage.scene.remove(o.mesh); this.list.length = 0; },
  update(dt, t) {
    const P = G.p; let slow = 1;
    for (const W of [G.W]) for (const h of W.hazards) {
      if (h.type === 'sludge') { if (P && !P.dead && P.x > h.x0 && P.x < h.x1 && P.z > h.z0 && P.z < h.z1 && P.y < (h.y || 0) + 0.9) { slow = Math.min(slow, h.slow || 0.6); G.Player.hurt((h.dps || 5) * dt, { tick: true }); if (Math.random() < dt * 6) G.fx.glow(P.x, P.y + 0.3, P.z, 0x7dff5a, 1, { size: 0.25 }); } }
    }
    for (const o of this.list) {
      const h = o.h; if (!h.period) continue;
      const ph = (t + (h.phase || 0)) % h.period; const active = ph < h.onFor; const warn = !active && ph > h.period - 0.8;
      o.mesh.visible = true; const k = active ? 1 : warn ? 0.25 + 0.2 * Math.sin(t * 24) : 0.0;
      if (o.type === 'fire') { o.flame[0].scale.set(1, 0.2 + 0.8 * o.on, 1); o.flame[1].scale.set(1, 0.2 + 0.8 * o.on, 1); o.flame[0].visible = o.flame[1].visible = o.on > 0.05; o.flame[0].rotation.y += dt * 4; o.ring.material.opacity = 0.15 + 0.5 * (active ? 1 : warn ? 0.7 : 0); if (active && Math.random() < dt * 25) G.fx.glow(h.x + (Math.random() - 0.5) * h.r, (h.y || 0) + 1 + Math.random() * 1.5, h.z + (Math.random() - 0.5) * h.r, 0xff9a3a, 1, { size: 0.3, life: 0.5, speed: 0.5 }); }
      else if (o.type === 'gas') { o.flame[0].visible = o.on > 0.05; o.flame[0].scale.setScalar(0.4 + 0.6 * o.on); o.ring.material.opacity = 0.12 + 0.4 * (active ? 1 : warn ? 0.7 : 0); if (active && Math.random() < dt * 12) G.fx.puff(h.x + (Math.random() - 0.5) * h.r, (h.y || 0) + 0.8, h.z + (Math.random() - 0.5) * h.r, 0x8aff5a); }
      else if (o.type === 'laser') { o.flame[0].visible = o.flame[1].visible = o.on > 0.05 || warn; o.flame[0].material.opacity = active ? 0.95 : warn ? 0.25 + 0.25 * Math.sin(t * 30) : 0; o.flame[1].material.opacity = active ? 0.28 : 0; if (active && Math.random() < dt * 30) G.fx.spark(h.x, h.y, h.z0 + Math.random() * (h.z1 - h.z0), 0xff5a3a, 1, { speed: 1.5 }); }
      o.on += ((active ? 1 : 0) - o.on) * Math.min(1, dt * 12);
      o.active = active;
      if (!P || P.dead || !active) { if (o.hitCD > 0) o.hitCD -= dt; continue; }
      if (o.hitCD > 0) o.hitCD -= dt;
      if (o.type === 'fire' || o.type === 'gas') { const d = Math.hypot(P.x - h.x, P.z - h.z); if (d < h.r + P.r * 0.5 && Math.abs(P.y - (h.y || 0)) < 2.4) G.Player.hurt(h.dps * dt, { tick: true }); }
      else if (o.type === 'laser') { if (o.hitCD <= 0 && Math.abs(P.x - h.x) < 0.4 + P.r * 0.4 && P.z > h.z0 && P.z < h.z1 && P.y < h.y + 0.35) { const d = G.Player.hurt(h.dmg, { dx: -1, dz: 0, knock: 6 }); o.hitCD = 0.6; if (d) { G.fx.spark(P.x, P.y + 0.7, P.z, 0xff5a3a, 10); } } }
    }
    G.run && (G.run.hazardSlow = slow);
  },
};
