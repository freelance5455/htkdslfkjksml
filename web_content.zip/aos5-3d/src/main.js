// Entry point: boot, game flow (Game), main loop, test hooks.
import * as THREE from 'three';
import { G } from './ctx.js';
import { Save } from './save.js';
import { Input } from './input.js';
import { Audio } from './audio.js';
import { Stage } from './stage.js';
import { FX } from './fx.js';
import { UI } from './ui.js';
import { Run } from './level.js';
import { Enemy } from './enemy.js';
import { Ally } from './ally.js';
import { Player } from './player.js';
import { Cam } from './camera.js';
import { Hazards } from './hazards.js';
import { LEVEL_BY_ID } from './data/levels.js';
import { ITEMS } from './data/items.js';
import { ALLIES } from './data/allies.js';
import { Modes } from './modes.js';
import { Bot } from './bot.js';

Object.assign(G, { Cam, enemies: [], allies: [], turrets: [], state: 'boot', t: 0, hitstop: 0, slowmo: 0, Enemy, Ally, Player, Run, ItemDefs: ITEMS, AllyDefs: ALLIES, ui: UI, audio: Audio, save: Save, run: Run, Modes });
const q = new URLSearchParams(location.search);
let renderer, stage, last = 0, fpsAcc = 0, fpsN = 0, lowT = 0, errShown = false;

export const Game = {
  boot() {
    Save.load(); Input.init();
    renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('gl'), antialias: !!q.get('aa') || Save.d.settings.quality !== 'low', powerPreference: 'high-performance' });
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.outputColorSpace = THREE.SRGBColorSpace;
    G.renderer = renderer; G.stage = stage = new Stage(renderer, this.pickQuality());
    G.fx = new FX(stage); G.fx.outline = stage.q.outline;
    Audio.setVolumes(Save.d.settings.music, Save.d.settings.sfx);
    UI.init(); addEventListener('resize', () => stage.resize()); document.addEventListener('visibilitychange', () => { if (document.hidden && G.state === 'play') UI.pause(); });
    if (Save.corrupt) setTimeout(() => UI.toast('تعذّر قراءة الحفظ السابق — بدأنا حفظًا جديدًا'), 500);
    this.menuWorld(); UI.replace('title'); Audio.music('menu');
    requestAnimationFrame(frame);
    const auto = q.get('l'); if (auto) setTimeout(() => this.startLevel(+auto), 100);
  },
  pickQuality() { const s = Save.d.settings.quality; if (s !== 'auto') return s; const mobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || ('ontouchstart' in window && innerWidth < 1100); return q.get('q') || (mobile ? 'low' : 'med'); },
  applyQuality() { const n = this.pickQuality(); stage.setQuality(n); G.fx.setQuality(stage.q); G.fx.outline = stage.q.outline; for (const r of [...G.enemies.map(e => e.rig), ...G.allies.map(a => a.rig), ...(G.p ? Object.values(G.p.rigs) : [])]) r.setOutline(stage.q.outline); UI.toast('جودة الرسوميات: ' + n); },
  menuWorld() {
    try { Run.begin({ spec: LEVEL_BY_ID[1], menu: true }); } catch (e) { console.error('[game] menuWorld', e); }
    G.state = 'menu'; G.menuT = 0; UI.hudShow(false); Input.showTouch(false); Run.frozenInput = true;
    for (const e of G.enemies) { e.state = 'dormant'; }
  },
  startLevel(id) {
    const spec = LEVEL_BY_ID[id]; if (!spec) return; G.mode = null;
    UI.loading(true, 'جارٍ تحميل المرحلة ' + id + '…'); G.state = 'loading'; Audio.unlock();
    setTimeout(() => { try { Run.begin({ spec }); G.state = 'play'; Run.replay = !!Save.d.completed[id]; Input.flush(); } catch (e) { console.error('[game] startLevel failed', e); UI.toast('خطأ أثناء تحميل المرحلة'); G.state = 'menu'; UI.replace('title'); } UI.loading(false); }, 40);
  },
  startMode(m, d) { Modes.start(m, d); },
  restart() { if (G.run && G.run.spec) { if (G.run.mode && G.run.mode.restart) G.run.mode.restart(); else this.startLevel(G.run.id); } },
  respawn() { Run.respawn(); G.state = 'play'; },
  quit() {
    if (Run.active && Run.state && Run.coins && Run.state !== 'complete') { const part = Math.floor(Run.coins * 0.5); Save.d.coins += part; Save.commit(true); if (part) UI.toast('حُفظ نصف العملات المجموعة: ' + part); }
    Run.end(); this.menuWorld(); UI.stack = []; UI.replace('title'); Audio.music('menu');
  },
  step(dt) { updateGame(dt); },
};
G.Game = Game;

function updateGame(dt) {
  if (Bot.on) Bot.tick(dt);
  if (G.hitstop > 0) { G.hitstop -= dt; dt *= 0.08; }
  if (G.slowmo > 0) { G.slowmo -= dt; dt *= 0.4; }
  Run.update(dt);
  Input.clearEdges();
}
function menuUpdate(dt) {
  G.menuT += dt; G.t += dt; const W = G.W; if (!W || !G.p) return; const P = G.p;
  W.update(dt, G.t, P); P.rig.update(dt); for (const a of G.allies) a.rig.update(dt); G.fx.update(dt);
  const a = G.menuT * 0.12; const cx = 14 + Math.sin(a) * 5, cz = 0;
  stage.setCamera(P.x + 6 + Math.sin(a * 0.7) * 4, 3.4, P.z - 9 + Math.cos(a) * 2, P.x + 8, 1.4, P.z);
  stage.update(dt, { x: P.x, y: 0, z: P.z }, null);
}
function resultUpdate(dt) {
  const P = G.p, W = G.W; if (!P || !W) return; G.t += dt; W.update(dt, G.t, P); P.rig.update(dt); for (const a of G.allies) a.rig.update(dt);
  G.fx.update(dt); Cam.update(dt, P, W, W.curZone, Run.seg); stage.update(dt, { x: P.x, y: P.y, z: P.z }, W.curZone);
}
function frame(now) {
  const rdt = Math.min(0.05, (now - last) / 1000 || 0.016); last = now;
  try {
    if (G.state === 'play') { updateGame(rdt); UI.updateHud(rdt); }
    else if (G.state === 'menu') menuUpdate(rdt);
    else if (G.state === 'result') { resultUpdate(rdt); }
    if (G.state !== 'paused' || !G.stage) { }
    // auto quality drop
    if (G.state === 'play' && Save.d.settings.quality === 'auto') { fpsAcc += rdt; fpsN++; if (fpsAcc > 3) { const fps = fpsN / fpsAcc; if (fps < 26 && stage.qname !== 'low') { lowT++; if (lowT >= 2) { const n = stage.qname === 'high' ? 'med' : 'low'; stage.setQuality(n); G.fx.setQuality(stage.q); G.fx.outline = stage.q.outline; lowT = 0; UI.toast('خُفّضت الجودة تلقائيًا لتحسين الأداء'); } } else lowT = 0; fpsAcc = 0; fpsN = 0; } }
    stage.render();
  } catch (e) { if (!errShown) { errShown = true; console.error('[game] frame error', e && e.stack || e); UI.toast('حدث خطأ غير متوقع — تابع اللعب أو أعد المرحلة'); setTimeout(() => errShown = false, 4000); } }
  requestAnimationFrame(frame);
}
// ---- test hooks
window.__game = { G, Game, Run, Save, UI, Input, Enemy, Player, Ally, step(sec) { const n = Math.round(sec * 60); for (let i = 0; i < n; i++) { if (G.state === 'play') updateGame(1 / 60); else if (G.state === 'menu') menuUpdate(1 / 60); else if (G.state === 'result') resultUpdate(1 / 60); } UI.updateHud(0.016); stage.render(); }, render() { stage.render(); } };
window.__step = (s) => { window.__game.step(s); window.__ready = true; };
Game.boot();
