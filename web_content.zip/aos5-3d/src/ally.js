// Allies: follower AI with role behaviours (archer, rusher, tank, healer, mage, sniper). They path around walls and recover when stuck.
import { G } from './ctx.js';
import { Save } from './save.js';
import { ALLIES, allyStat } from './data/allies.js';
import { makeRig } from './styles.js';
import { Combat } from './combat.js';
import { Enemy } from './enemy.js';
import { moveXZ, stepVertical } from './phys.js';
import { dampAng } from './util.js';

const rnd = (a, b) => a + Math.random() * (b - a);

export const Ally = {
  create(id, x, y, z) {
    const def = ALLIES[id], lv = (Save.d.allies[id] || { lv: 1 }).lv; const st = allyStat(def, lv);
    const rig = makeRig(def.style); rig.setOutline(G.fx.outline); G.stage.scene.add(rig.root);
    const a = { kind: 'ally', id, def, lv, st, x, y, z, vy: 0, kx: 0, kz: 0, r: 0.4, h: 1.8 * (rig.S || 1), hp: st.hp, maxHp: st.hp, rig, yaw: 0, grounded: true, down: false, downT: 0, cd: rnd(0.2, 1), shots: 0, path: null, pi: 1, pathT: 0, target: null, tT: 0, slot: 0, taunt: def.ai === 'tank', pulseT: rnd(2, 5), stuckT: 0, lastX: x, lastZ: z, vSpeed: 0, nudge: 0, hurtFlash: 0, strafe: Math.random() < 0.5 ? 1 : -1, strafeT: 1, dead: false };
    a.spawn = { x, y, z };
    rig.root.position.set(x, y, z); rig.snap(); G.allies.push(a); return a;
  },
  spawnTeam() {
    this.clearAll(); const p = G.p; let i = 0;
    for (const id of Save.d.team.slice(0, 3)) { if (!Save.d.allies[id]) continue; const a = this.create(id, p.x - 1.5 - i, p.y, p.z + (i - 1) * 1.6); a.slot = i++; this.snapNear(a); }
  },
  snapNear(a) { const p = G.p; for (let tr = 0; tr < 16; tr++) { const ang = Math.random() * 6.28, r = 1.6 + Math.random() * 1.6; const x = p.x + Math.cos(ang) * r, z = p.z + Math.sin(ang) * r; if (G.W.isFree(x, z, p.y, 0.6)) { a.x = x; a.z = z; a.y = p.y; a.vy = 0; a.path = null; a.rig.root.position.set(a.x, a.y, a.z); return; } } a.x = p.x; a.z = p.z; a.y = p.y; },
  join(id, x, y, z) { // freed from a cage in a level
    if (!Save.d.allies[id]) Save.d.allies[id] = { lv: 1 };
    if (!Save.d.team.includes(id) && Save.d.team.length < 3) Save.d.team.push(id);
    Save.commit();
    if (!G.allies.some(a => a.id === id) && Save.d.team.includes(id)) { const a = this.create(id, x, y, z); a.slot = G.allies.length - 1; a.rig.act('roar', 0.8); }
  },
  remove(a) { G.stage.scene.remove(a.rig.root); a.rig.dispose(); const i = G.allies.indexOf(a); if (i >= 0) G.allies.splice(i, 1); },
  clearAll() { for (const a of G.allies) { G.stage.scene.remove(a.rig.root); a.rig.dispose(); } G.allies.length = 0; },
  hurt(a, dmg, o = {}) {
    if (a.down) return 0; if (o.tick) dmg *= 1; if (a.def.ai === 'tank') dmg *= 0.6;
    a.hp -= dmg; a.rig.flash(0xff5050, 0.1); G.fx.text(a.x, a.y + a.h, a.z, '-' + Math.round(dmg), 'p');
    if (o.dx !== undefined && o.knock) { a.kx += o.dx * o.knock * 0.4; a.kz += o.dz * o.knock * 0.4; }
    if (a.hp <= 0) { a.hp = 0; a.down = true; a.downT = 14; a.rig.setHold('down'); G.fx.text(a.x, a.y + a.h + 0.4, a.z, a.def.name + ' سقط!', 'crit'); G.audio && G.audio.sfx('edie'); }
    return dmg;
  },
  heal(a, n) { if (a.down) return; const h = Math.min(a.maxHp - a.hp, n); if (h > 0.5) { a.hp += h; G.fx.text(a.x, a.y + a.h, a.z, '+' + Math.round(h), 'heal'); G.fx.heal(a.x, a.y + 0.8, a.z); } },
  updateAll(dt) {
    const p = G.p; for (const a of G.allies) this.update(a, dt, p);
  },
  update(a, dt, p) {
    const W = G.W, def = a.def, rig = a.rig; const st = a.st;
    if (a.hurtFlash > 0) a.hurtFlash -= dt;
    if (a.down) {
      a.downT -= dt * (G.allies.some(o => o.id === 'noor' && !o.down) ? 2 : 1) * (Math.hypot(p.x - a.x, p.z - a.z) < 3 ? 2 : 1);
      if (a.downT <= 0) { a.down = false; a.hp = a.maxHp * 0.5; rig.setHold(null); G.fx.ring(a.x, a.y, a.z, 2.5, 0x66ff9a, 0.5); G.fx.heal(a.x, a.y + 0.8, a.z); }
      stepVertical(a, dt); this._sync(a, dt, 0); return;
    }
    a.hp = Math.min(a.maxHp, a.hp + dt * 0.8);
    a.cd -= dt; a.kx *= Math.max(0, 1 - 9 * dt); a.kz *= Math.max(0, 1 - 9 * dt);
    const dp = Math.hypot(p.x - a.x, p.z - a.z);
    if (dp > 30 || (dp > 16 && Math.abs(p.y - a.y) > 4) || a.y < W.killY + 2) { this.snapNear(a); G.fx.ring(a.x, a.y, a.z, 1.5, def.color ? parseInt(def.color.slice(1), 16) : 0xffffff, 0.4); }
    // target
    a.tT -= dt; if (a.tT <= 0 || !a.target || a.target.dead || a.target.untargetable) { a.target = this.pickTarget(a, p); a.tT = 0.35; }
    const tg = a.target; let vx = 0, vz = 0; const spd = a.def.speed * (dp > 9 ? 1.5 : 1);
    const fwd = { x: Math.sin(p.yaw), z: Math.cos(p.yaw) };
    // formation slot: behind and to the sides of the hero
    const side = (a.slot - 1) * 1.7, back = 2.2 + (a.slot === 1 ? 0.8 : 0);
    const hx = p.x - fwd.x * back + fwd.z * side, hz = p.z - fwd.z * back - fwd.x * side;
    let moving = false;
    const ai = def.ai;
    if (ai === 'healer') { a.pulseT -= dt; if (a.pulseT <= 0 && (p.hp < p.maxHp * 0.95 || G.allies.some(o => o.hp < o.maxHp * 0.9) )) { a.pulseT = 7; this.pulse(a, p); } else if (a.pulseT < -3) a.pulseT = 0; }
    if (ai === 'tank') { a.pulseT -= dt; if (a.pulseT <= 0 && tg) { a.pulseT = 10; G.fx.ring(a.x, a.y, a.z, 6, 0x7fb5ff, 0.6); G.audio && G.audio.sfx('shield'); for (const e of G.enemies) if (!e.dead && Math.hypot(e.x - a.x, e.z - a.z) < 6 && e.state !== 'lying' && e.state !== 'dormant') { e.target = a; e.tT = 3; } } }
    if (tg && Math.hypot(tg.x - p.x, tg.z - p.z) < 20) {
      const dx = tg.x - a.x, dz = tg.z - a.z, d = Math.hypot(dx, dz) - tg.r, ang = Math.atan2(dx, dz);
      const R = def.range;
      if (ai === 'ranged' || ai === 'mage' || ai === 'sniper') {
        const lo = ai === 'sniper' ? 9 : ai === 'mage' ? 6 : 5, hi = Math.min(R - 1, ai === 'sniper' ? 18 : 10);
        const los = !W.losBlocked(a.x, a.z, tg.x, tg.z, 1.2);
        if (d < lo) { vx = -Math.sin(ang) * spd; vz = -Math.cos(ang) * spd; moving = true; }
        else if (d > hi || !los) { const s = Enemy.steer(a, tg.x, tg.z, spd, dt); vx = s.vx; vz = s.vz; moving = true; }
        else { a.strafeT -= dt; if (a.strafeT <= 0) { a.strafe *= -1; a.strafeT = rnd(1.2, 2.5); } vx = Math.cos(ang) * a.strafe * spd * 0.4; vz = -Math.sin(ang) * a.strafe * spd * 0.4; }
        a.yaw = dampAng(a.yaw, ang, 12, dt);
        if (a.cd <= 0 && d <= R && los) this.fire(a, tg);
      } else if (ai === 'healer') {
        if (dp > 5) { const s = Enemy.steer(a, hx, hz, spd, dt); vx = s.vx; vz = s.vz; moving = true; }
        a.yaw = dampAng(a.yaw, ang, 10, dt);
        if (a.cd <= 0 && d < 2.4) this.strike(a, tg);
      } else { // melee / tank
        if (d > R * 0.8) { const s = Enemy.steer(a, tg.x, tg.z, spd, dt); vx = s.vx; vz = s.vz; moving = true; }
        a.yaw = dampAng(a.yaw, ang, 14, dt);
        if (a.cd <= 0 && d <= R) this.strike(a, tg);
      }
    } else { // follow
      if (dp > 3.2) { const s = Enemy.steer(a, hx, hz, spd, dt); vx = s.vx; vz = s.vz; moving = true; a.yaw = dampAng(a.yaw, Math.atan2(vx, vz), 10, dt); }
      else { a.yaw = dampAng(a.yaw, p.yaw, 4, dt); }
    }
    // doors
    for (const dr of W.doors) { if (!dr.open && !dr.locked && Math.abs(dr.x - a.x) < 2.2 && Math.abs(dr.z - a.z) < 2.2) W.openDoor(dr, true); }
    a.stuckT += dt; if (a.stuckT > 1) { const mv = Math.hypot(a.x - a.lastX, a.z - a.lastZ); if (moving && mv < 0.3) { a.path = null; a.pathT = 0; a.nudge = 0.7; a.strafe *= -1; } a.lastX = a.x; a.lastZ = a.z; a.stuckT = 0; }
    if (a.nudge > 0) { a.nudge -= dt; vx += Math.cos(a.yaw) * a.strafe * spd * 0.6; vz += -Math.sin(a.yaw) * a.strafe * spd * 0.6; }
    // keep out of the hero's way
    if (dp < 1.0) { vx += (a.x - p.x) * 3; vz += (a.z - p.z) * 3; }
    moveXZ(a, (vx + a.kx) * dt, (vz + a.kz) * dt, { edgeGuard: W.void });
    stepVertical(a, dt); a.vSpeed = Math.hypot(vx, vz); this._sync(a, dt, a.vSpeed);
  },
  _sync(a, dt, spd) { const r = a.rig; r.root.position.set(a.x, a.y, a.z); r.root.rotation.y = a.yaw; r.speed = spd; r.air = a.grounded ? 0 : a.vy > 0 ? 1 : -1; r.update(dt); },
  pickTarget(a, p) {
    let best = null, bd = 1e9;
    for (const e of G.enemies) {
      if (e.dead || e.untargetable || e.state === 'lying' || e.state === 'dormant' && !e.boss) continue;
      if (Math.abs(e.y - a.y) > 3.5) continue;
      const d = Math.hypot(e.x - a.x, e.z - a.z); if (d > 16) continue;
      const dp = Math.hypot(e.x - p.x, e.z - p.z); if (dp > 15) continue;
      const s = d + (e.boss ? -2 : 0); if (s < bd) { bd = s; best = e; }
    }
    return best;
  },
  fire(a, tg) {
    const def = a.def, st = a.st; a.cd = def.cd * rnd(0.9, 1.1); a.shots++;
    const dx = tg.x - a.x, dz = tg.z - a.z, d = Math.hypot(dx, dz) || 1; const oy = a.y + 1.2, dy = ((tg.y || 0) + (tg.h || 1.6) * 0.55 - oy) / d;
    const ox = a.x + dx / d * 0.5, oz = a.z + dz / d * 0.5;
    if (def.ai === 'ranged') { const pierce = a.shots % 5 === 0; Combat.shoot({ x: ox, y: oy, z: oz, dx, dy, dz, spd: 26, dmg: st.dmg * (pierce ? 1.4 : 1), team: 'p', color: pierce ? 0xb8ffd0 : 0x39d26a, size: pierce ? 0.18 : 0.12, range: 24, pierce: pierce ? 3 : 0, src: 'ally' }); a.rig.act('shoot', 0.26); G.audio && G.audio.sfx('shoot'); }
    else if (def.ai === 'mage') { Combat.shoot({ x: ox, y: oy, z: oz, dx, dy, dz, spd: 14, dmg: st.dmg, team: 'p', color: 0xb36bff, size: 0.3, range: 22, explode: 2.3, knock: 5, src: 'ally' }); a.rig.act('cast', 0.55); G.audio && G.audio.sfx('orb'); }
    else if (def.ai === 'sniper') { const mul = tg.boss ? 2 : 1; Combat.shoot({ x: ox, y: oy, z: oz, dx, dy, dz, spd: 55, dmg: st.dmg * mul, team: 'p', color: 0x72ffff, size: 0.16, range: 40, pierce: 1, src: 'ally', crit: tg.boss }); G.fx.beam(ox, oy, oz, tg.x, (tg.y || 0) + 1.1, tg.z, 0x72ffff, 0.06, 0.15); a.rig.act('shoot', 0.26); G.audio && G.audio.sfx('laser'); }
  },
  strike(a, tg) {
    const def = a.def, st = a.st; a.cd = def.cd * rnd(0.92, 1.08); a.shots++;
    a.rig.act(def.ai === 'melee' ? (a.shots % 3 === 0 ? 'stab' : a.shots % 2 ? 'swingR' : 'swingL') : def.ai === 'tank' ? 'overhead' : 'swingR', Math.max(0.3, def.cd * 0.9));
    setTimeout(() => { if (a.down || !G.allies.includes(a)) return; Combat.cone(a, def.range + 0.3, 2.0, st.dmg, 'p', { knock: def.ai === 'tank' ? 7 : 3, src: 'ally', noFlinch: def.ai === 'melee' && a.shots % 2 === 0 }); G.audio && G.audio.sfx('swing'); }, 180);
  },
  pulse(a, p) {
    a.rig.act('cast', 0.6); G.fx.ring(a.x, a.y, a.z, 8, 0x66ff9a, 0.7); G.audio && G.audio.sfx('heal');
    const amt = 14 + a.st.dmg * 3.2;
    if (Math.hypot(p.x - a.x, p.z - a.z) < 9 && G.Player) G.Player.heal(amt);
    for (const o of G.allies) if (o !== a && !o.down && Math.hypot(o.x - a.x, o.z - a.z) < 9) this.heal(o, amt);
    this.heal(a, amt * 0.5);
  },
};
