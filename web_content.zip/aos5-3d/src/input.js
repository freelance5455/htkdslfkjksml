// Unified input: keyboard (rebindable), mouse, touch (virtual joystick + buttons), and a scripted source for bots/tests.
import { Save, DEFAULT_KEYS } from './save.js';
import { G } from './ctx.js';
import { Cam } from './camera.js';

const ACTIONS = ['jump', 'dodge', 'attack', 'a1', 'a2', 'switch', 'interact', 'transform', 'pause', 'camL', 'camR'];
const ALIAS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', KeyP: 'pause' };
const hold = {}, edge = {}, buffered = {};
const sim = { on: false, x: 0, z: 0, hold: {}, edge: {} };
const touch = { x: 0, z: 0, active: false, el: null, enabled: false };
let codeToAct = {};

function rebuild() {
  codeToAct = {}; const k = (Save.d.settings.keys) || DEFAULT_KEYS;
  for (const a of ['up', 'down', 'left', 'right', ...ACTIONS]) { const c = k[a] || DEFAULT_KEYS[a]; if (c) (codeToAct[c] = codeToAct[c] || []).push(a); }
  for (const [c, a] of Object.entries(ALIAS)) (codeToAct[c] = codeToAct[c] || []).push(a);
}
const press = (a) => { if (!hold[a]) edge[a] = true; hold[a] = true; buffered[a] = performance.now(); };
const release = (a) => { hold[a] = false; };

export const Input = {
  sim, touch, ACTIONS,
  init() {
    rebuild();
    addEventListener('keydown', (e) => {
      if (G.rebinding) return;
      const acts = codeToAct[e.code]; if (!acts) return;
      if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
      if (e.repeat) return; for (const a of acts) press(a); G.lastDevice = 'kb';
    });
    addEventListener('keyup', (e) => { const acts = codeToAct[e.code]; if (acts) for (const a of acts) release(a); });
    addEventListener('blur', () => { for (const k in hold) hold[k] = false; });
    const cv = document.getElementById('ui');
    addEventListener('mousedown', (e) => { if (e.target.closest && e.target.closest('.panel, .btn, button, #touch, .hudbtn')) return; if (G.state !== 'play') return; if (e.button === 0) press('attack'); else if (e.button === 2) press('dodge'); });
    addEventListener('mouseup', (e) => { if (e.button === 0) release('attack'); else if (e.button === 2) release('dodge'); });
    addEventListener('contextmenu', (e) => { if (G.state === 'play') e.preventDefault(); });
    addEventListener('mousemove', (e) => { if (document.pointerLockElement && G.state === 'play' && Cam.isThird()) { Cam.look.dx += e.movementX || 0; Cam.look.dy += e.movementY || 0; } });
    addEventListener('mousedown', (e) => { if (e.target.closest && e.target.closest('.panel, .btn, button, #touch, .hudbtn')) return; if (G.state === 'play' && Cam.isThird() && !document.pointerLockElement && !this.isTouch()) { try { const r = document.body.requestPointerLock && document.body.requestPointerLock(); if (r && r.catch) r.catch(() => {}); } catch (_) {} } });
    setInterval(() => { if (G.state !== 'play' && document.pointerLockElement) { try { document.exitPointerLock(); } catch (_) {} } }, 250);
    this.buildTouch();
  },
  rebind(action, code) { const k = Save.d.settings.keys; for (const a in k) if (k[a] === code && a !== action) k[a] = k[action]; k[action] = code; Save.commit(); rebuild(); },
  resetKeys() { Save.d.settings.keys = { ...DEFAULT_KEYS }; Save.commit(); rebuild(); },
  rebuild,
  down(a) { return sim.on ? !!sim.hold[a] : !!hold[a]; },
  /** edge-triggered with 0.14s buffer; consume=true clears */
  pressed(a, consume = true) {
    if (sim.on) { const v = !!sim.edge[a]; if (v && consume) sim.edge[a] = false; return v; }
    const v = edge[a] || (buffered[a] && performance.now() - buffered[a] < 140 && hold[a] && edge[a] !== false && false);
    if (v && consume) edge[a] = false; return !!v;
  },
  clearEdges() { for (const k in edge) edge[k] = false; for (const k in sim.edge) sim.edge[k] = false; },
  axis() {
    if (sim.on) return { x: sim.x, z: sim.z };
    let x = (hold.right ? 1 : 0) - (hold.left ? 1 : 0), z = (hold.up ? 1 : 0) - (hold.down ? 1 : 0);
    if (touch.active) { x += touch.x; z += touch.z; }
    const l = Math.hypot(x, z); if (l > 1) { x /= l; z /= l; }
    if (Cam.isThird()) { const b = Cam.basis(); return { x: b.rx * x + b.fx * z, z: b.rz * x + b.fz * z }; } // camera-relative movement
    return { x, z };
  },
  camDir() { return (hold.camR ? 1 : 0) - (hold.camL ? 1 : 0); },
  flush() { for (const k in hold) hold[k] = false; this.clearEdges(); touch.x = touch.z = 0; touch.active = false; },
  isTouch() { const m = Save.d.settings.touch; return m === 'on' || (m !== 'off' && ('ontouchstart' in window || navigator.maxTouchPoints > 0)); },
  buildTouch() {
    const root = document.getElementById('touch'); if (!root) return;
    root.innerHTML = `
      <div id="look"></div>
      <div id="joy"><div id="joyKnob"></div></div>
      <div id="tbtns">
        <button class="tb big" data-a="attack">⚔</button>
        <button class="tb" data-a="jump">⤒</button>
        <button class="tb" data-a="dodge">↯</button>
        <button class="tb sm" data-a="a1" id="tA1">1</button>
        <button class="tb sm" data-a="a2" id="tA2">2</button>
        <button class="tb sm" data-a="switch">⇄</button>
        <button class="tb sm hidden" data-a="interact" id="tInt">✋</button>
        <button class="tb sm hidden" data-a="transform" id="tTr">★</button>
      </div>`;
    const joy = root.querySelector('#joy'), knob = root.querySelector('#joyKnob'); let jid = null, cx = 0, cy = 0;
    const R = 56;
    const upd = (e) => { let dx = e.clientX - cx, dy = e.clientY - cy; const l = Math.hypot(dx, dy); if (l > R) { dx = dx / l * R; dy = dy / l * R; } knob.style.transform = `translate(${dx}px,${dy}px)`; const k = l < 8 ? 0 : 1; touch.x = dx / R * k; touch.z = -dy / R * k; touch.active = true; };
    joy.addEventListener('pointerdown', (e) => { jid = e.pointerId; joy.setPointerCapture(jid); const r = joy.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; upd(e); e.preventDefault(); });
    joy.addEventListener('pointermove', (e) => { if (e.pointerId === jid) upd(e); });
    const end = (e) => { if (e.pointerId !== jid) return; jid = null; touch.x = touch.z = 0; touch.active = false; knob.style.transform = ''; };
    joy.addEventListener('pointerup', end); joy.addEventListener('pointercancel', end);
    const lk = root.querySelector('#look'); let lid = null, lx = 0, ly = 0;
    lk.addEventListener('pointerdown', (e) => { lid = e.pointerId; lk.setPointerCapture(lid); lx = e.clientX; ly = e.clientY; e.preventDefault(); });
    lk.addEventListener('pointermove', (e) => { if (e.pointerId !== lid) return; Cam.look.dx += (e.clientX - lx) * 1.15; Cam.look.dy += (e.clientY - ly) * 1.15; lx = e.clientX; ly = e.clientY; });
    const lend = (e) => { if (e.pointerId === lid) lid = null; }; lk.addEventListener('pointerup', lend); lk.addEventListener('pointercancel', lend);
    root.querySelectorAll('.tb').forEach(b => {
      const a = b.dataset.a;
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); b.setPointerCapture(e.pointerId); b.classList.add('on'); press(a); G.lastDevice = 'touch'; });
      const up = () => { b.classList.remove('on'); release(a); };
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
    });
    root.addEventListener('contextmenu', e => e.preventDefault());
  },
  showTouch(v) { const r = document.getElementById('touch'); if (r) r.style.display = v && this.isTouch() ? 'block' : 'none'; },
};
