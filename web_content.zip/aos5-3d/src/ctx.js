// Global game context (singletons are attached at boot to avoid circular imports)
export const G = { quality: 'med', time: 0, timeScale: 1 };
