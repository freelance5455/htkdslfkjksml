// Enemies & bosses: AI (detect / chase / keep-distance / attack tokens), attack-kind executor, boss phases.
import { G } from './ctx.js';
import { ENEMIES, BOSSES } from './data/enemies.js';
import { makeRig } from './styles.js';
import { Combat } from './combat.js';
import { moveXZ, stepVertical } from './phys.js';
import { steerPoint } from './pathing.js';
import { angDiff, dampAng, clamp, damp, TAU } from './util.js';

const RED = 0xff3a2a;
const rnd = (a, b) => a + Math.random() * (b - a);
const dist = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);

export const Enemy = {
  list() { return G.enemies; },
  spawn(type, x, y, z, o = {}) {
    const def = ENEMIES[type] || BOSSES[type]; if (!def) throw new Error('enemy ' + type);
    const boss = !!BOSSES[type]; const diff = (G.run && G.run.diff) || o.diff || 1; const sc = o.scale || 1;
    const hpMul = (1 + 0.075 * (diff - 1)) * sc * (boss ? 1 : 1);
    const rig = makeRig(def.style); rig.setOutline(G.fx.outline); G.stage.scene.add(rig.root);
    const e = {
      kind: 'enemy', type, def, boss, x, y, z, vy: 0, kx: 0, kz: 0, yaw: o.yaw ?? Math.PI * 0.5, r: def.r, h: def.h, hp: def.hp * hpMul, maxHp: def.hp * hpMul, rig,
      state: o.state || 'dormant', st: 0, group: o.group || null, seg: o.seg || null, target: null, tT: 0, atk: null, cd: rnd(0.3, 1), stunT: 0, slowT: 0, slowPow: 0, flinchT: 0,
      dmgMul: (1 + 0.06 * (diff - 1)) * (o.dmgScale || 1), speedMul: o.speedMul || 1, grounded: true, dead: false, deadT: 0, spawn: { x, y, z }, path: null, pi: 1, pathT: 0, stuckT: 0, lastX: x, lastZ: z,
      phase: 0, weak: 0, guard: 0, strafe: Math.random() < 0.5 ? 1 : -1, strafeT: rnd(1, 2.5), vSpeed: 0, enraged: false, lastAtk: null, untargetable: false, dashV: null, wave: o.wave || null, fromWave: !!o.fromWave,
      shielded: false, slowVis: 0,
    };
    if (def.rises && e.state === 'dormant') { e.state = 'lying'; e.untargetable = true; rig.setHold('down'); }
    else if (o.rise) { e.state = 'rising'; e.st = 0; rig.act('spawn', 1.2); e.untargetable = true; }
    if (boss) { e.untargetable = false; }
    rig.root.position.set(x, y, z); rig.root.rotation.y = e.yaw; rig.snap();
    if (def.rises && e.state === 'lying') rig.update(1);
    G.enemies.push(e); return e;
  },
  wake(e, force) {
    if (e.dead || (e.state !== 'dormant' && e.state !== 'lying')) return;
    if (e.state === 'lying') { e.state = 'rising'; e.st = 0; e.rig.act('getup', 0.9); G.fx.dust(e.x, e.y, e.z, 8, 0x6a5a40); }
    else e.state = 'chase';
    if (e.group && !force) for (const o of G.enemies) if (o !== e && o.group === e.group && (o.state === 'dormant' || o.state === 'lying')) this.wake(o, true);
  },
  remove(e) { G.stage.scene.remove(e.rig.root); e.rig.dispose(); const i = G.enemies.indexOf(e); if (i >= 0) G.enemies.splice(i, 1); },
  clearAll() { for (const e of G.enemies) { G.stage.scene.remove(e.rig.root); e.rig.dispose(); } G.enemies.length = 0; },

  // ------------------------------------------------------------------ damage
  hurt(e, dmg, o = {}) {
    if (e.dead || dmg <= 0) return 0;
    if (e.state === 'dormant' || e.state === 'lying') { this.wake(e); }
    const def = e.def; let m = 1;
    if (e.shielded) { G.fx.text(e.x, e.y + e.h + 0.3, e.z, 'محمي', 'e'); G.fx.spark(e.x, e.y + e.h * 0.6, e.z, 0x66ffee, 4); return 0; }
    if (e.guard > 0) { m *= 0.12; G.fx.spark(e.x, e.y + 1.2, e.z, 0x9fd8ff, 5); }
    if (def.frontReduce && o.dx !== undefined) { const ax = Math.atan2(-o.dx, -o.dz); if (Math.abs(angDiff(e.yaw, ax)) < 1.1) m *= (1 - def.frontReduce); }
    if (e.weak > 0) m *= 1.8;
    if (e.stunT > 0) m *= 1.25;
    dmg *= m;
    e.hp -= dmg; e.lastHurt = G.t;
    G.fx.hit(o.hx ?? e.x, o.hy ?? e.y + e.h * 0.6, o.hz ?? e.z, def.mech ? 0xcfe6ff : 0xfff0b0, dmg > 30);
    G.fx.text(e.x, e.y + e.h + 0.2, e.z, String(Math.max(1, Math.round(dmg))), (o.crit ? 'crit' : '') + (e.weak > 0 ? ' weak' : ''));
    e.rig.flash(0xffffff, 0.12);
    G.audio && G.audio.sfx(dmg > 25 ? 'hit2' : 'hit');
    if (G.Player && o.src !== 'ally' && o.src !== 'turret') G.Player.onDealt(dmg, e);
    if (e.hp <= 0) { this.die(e, o); return dmg; }
    if (def.enrage && !e.enraged && e.hp / e.maxHp < def.enrage) { e.enraged = true; e.speedMul *= 1.3; e.rig.flash(0xff4040, 0.5); G.fx.text(e.x, e.y + e.h + 0.7, e.z, 'غضب!', 'crit'); }
    // reactions
    const kn = (o.knock || 0) * (e.boss ? 0.12 : def.superArmor ? 0.35 : 1);
    if (o.dx !== undefined && kn) { e.kx += o.dx * kn * 1.6; e.kz += o.dz * kn * 1.6; }
    if (o.stun && !e.boss) { e.stunT = Math.max(e.stunT, o.stun); this.cancel(e); e.rig.setHold('stun'); }
    else if (!def.superArmor && !e.boss && !o.noFlinch && !(e.atk && e.atk.t > e.atk.def.tele)) {
      if (e.atk) this.cancel(e);
      e.flinchT = 0.28; e.rig.act('hurt', 0.34);
    }
    if (e.boss) this.bossPhaseCheck(e);
    return dmg;
  },
  cancel(e) { if (e.atk) { if (e.atk.tele) e.atk.tele.kill(); if (e.atk.extra) for (const t of e.atk.extra) t.kill && t.kill(); e.atk = null; e.dashV = null; e.guard = 0; e.cd = rnd(0.5, 1.1); } },
  die(e, o = {}) {
    if (e.dead) return; e.dead = true; e.deadT = 0; this.cancel(e); e.hp = 0;
    e.rig.setHold('dead'); G.audio && G.audio.sfx(e.boss ? 'boom' : 'edie');
    const p = { x: e.x, y: e.y + e.h * 0.5, z: e.z };
    G.fx.spark(p.x, p.y, p.z, 0xffe9a0, e.boss ? 30 : 12, { speed: 6 }); G.fx.dust(e.x, e.y, e.z, 8);
    if (e.boss) { G.fx.explode(p.x, p.y, p.z, 5, 0xffc060); G.slowmo = 1.2; }
    if (o.dx !== undefined) { e.kx += o.dx * 4; e.kz += o.dz * 4; }
    if (G.run) G.run.onEnemyDeath(e);
    if (G.Player) G.Player.onKill(e);
  },
  // ------------------------------------------------------------------ main update
  updateAll(dt) {
    let att = 0; for (const e of G.enemies) if (e.atk && !e.boss && e.def.ai === 'melee') att++;
    G.attackers = att; G.maxAttackers = 2 + ((G.run && G.run.diff >= 5) ? 1 : 0) + (G.allies.length ? 1 : 0);
    const px = G.p ? G.p.x : 0;
    for (let i = G.enemies.length - 1; i >= 0; i--) {
      const e = G.enemies[i];
      const far = Math.abs(e.x - px) > 70;
      if (far && !e.dead && !e.boss) { e.rig.root.visible = false; if (e.state === 'dormant' || e.state === 'lying') continue; } else e.rig.root.visible = true;
      e.rig.lodSkip = Math.abs(e.x - px) > 32 ? 1 : 0;
      this.update(e, dt);
      if (e.dead && e.deadT > 2.2) this.remove(e);
    }
    // soft separation (avoid stacking)
    const L = G.enemies; for (let i = 0; i < L.length; i++) { const a = L[i]; if (a.dead || a.state === 'lying' || a.state === 'dormant') continue; for (let j = i + 1; j < L.length; j++) { const b = L[j]; if (b.dead || b.state === 'lying' || b.state === 'dormant') continue; const dx = b.x - a.x, dz = b.z - a.z, d = Math.hypot(dx, dz), m = a.r + b.r; if (d < m && d > 0.001 && Math.abs(a.y - b.y) < 1.5) { const k = (m - d) * 0.5; if (!a.boss) { a.x -= dx / d * k * (b.boss ? 2 : 1); a.z -= dz / d * k * (b.boss ? 2 : 1); } if (!b.boss) { b.x += dx / d * k; b.z += dz / d * k; } } } }
  },
  update(e, dt) {
    const def = e.def, W = G.W, rig = e.rig;
    e.st += dt;
    if (e.dead) { e.deadT += dt; e.kx *= 0.9; e.kz *= 0.9; this._phys(e, dt, e.kx, e.kz); if (e.deadT > 1.6) { const k = Math.max(0.01, 1 - (e.deadT - 1.6) / 0.5); rig.root.scale.setScalar(k); } this._sync(e, dt); return; }
    if (e.slowT > 0) e.slowT -= dt;
    if (e.flinchT > 0) e.flinchT -= dt;
    if (e.weak > 0) { e.weak -= dt; if (Math.random() < dt * 4) rig.flash(0xffe060, 0.2); }
    if (e.guard > 0) e.guard -= dt;
    const slow = e.slowT > 0 ? 1 - e.slowPow : 1;
    const dtS = dt * slow; // slowed enemies act slower overall
    if (e.stunT > 0) { e.stunT -= dt; if (e.stunT <= 0) rig.setHold(null); this._phys(e, dt, e.kx, e.kz); e.kx *= 0.88; e.kz *= 0.88; this._sync(e, dt); return; }
    // knockback velocity decays
    let kx = e.kx, kz = e.kz; e.kx *= Math.max(0, 1 - 9 * dt); e.kz *= Math.max(0, 1 - 9 * dt);

    if (e.state === 'lying') { this._wakeCheck(e); this._phys(e, dt, 0, 0); this._sync(e, dt); return; }
    if (e.state === 'dormant') { this._wakeCheck(e); if (!e.boss) { this._phys(e, dt, kx, kz); this._sync(e, dt); return; } else { this._phys(e, dt, 0, 0); this._sync(e, dt); return; } }
    if (e.state === 'rising') { if (e.st > 0.5) e.untargetable = false; if (e.st > (e.fromWave ? 1.2 : 0.9)) { e.state = 'chase'; e.st = 0; e.untargetable = false; } this._phys(e, dt, 0, 0); this._sync(e, dt); return; }
    if (e.state === 'intro') { if (e.st > 1.2) { e.state = 'chase'; e.st = 0; rig.setHold(null); } this._phys(e, dt, 0, 0); this._sync(e, dt); return; }
    if (e.state === 'idle' && !e.boss) { this._wakeCheck(e, true); }

    // --- target
    e.tT -= dt; if (e.tT <= 0 || !e.target || e.target.dead || e.target.down) { e.target = this.pickTarget(e); e.tT = 0.45; }
    const tg = e.target;
    let vx = 0, vz = 0, want = 0; const spdBase = def.speed * e.speedMul * (G.run && G.run.phaseSpeed || 1) * slow;
    if (e.atk) { const r = this.runAttack(e, dtS); vx = r.vx; vz = r.vz; }
    else if (e.flinchT > 0) { /* staggered */ }
    else if (tg) {
      e.cd -= dtS; const d = Math.hypot(tg.x - e.x, tg.z - e.z) - (tg.r || 0.4);
      const sight = def.sight || 16;
      if (d > sight * 3) { e.state = 'idle'; e.target = null; }
      else {
        const ang = Math.atan2(tg.x - e.x, tg.z - e.z);
        if (def.ai === 'ranged') {
          const [k0, k1] = def.keep || [5, 9];
          e.strafeT -= dt; if (e.strafeT <= 0) { e.strafe *= -1; e.strafeT = rnd(1.2, 2.8); }
          let mv = 0; if (d < k0) mv = -1; else if (d > k1) mv = 1;
          if (mv > 0) { const s = this.steer(e, tg.x, tg.z, spdBase, dt); vx = s.vx; vz = s.vz; }
          else { const sx = Math.cos(ang) * e.strafe, sz = -Math.sin(ang) * e.strafe; vx = Math.sin(ang) * mv * spdBase * 0.9 + sx * spdBase * 0.5; vz = Math.cos(ang) * mv * spdBase * 0.9 + sz * spdBase * 0.5; }
          e.yaw = dampAng(e.yaw, ang, 10, dt);
          if (e.cd <= 0 && d < 20 && !W.losBlocked(e.x, e.z, tg.x, tg.z, 1.2)) this.pickAttack(e, tg, d);
        } else {
          const atkR = 2.2 + (def.attacks.reduce((m, a) => Math.max(m, a.range[1]), 0) > 3 ? 0 : 0);
          const maxR = def.attacks.reduce((m, a) => Math.max(m, a.range[1]), 0);
          const canTok = e.boss || G.attackers < G.maxAttackers;
          if (d > Math.min(maxR * 0.85, 3.0) || !canTok && d > 4.2) {
            if (!canTok && d < 6.5) { // circle while waiting for a free slot
              e.strafeT -= dt; if (e.strafeT <= 0) { e.strafe *= -1; e.strafeT = rnd(1, 2); }
              vx = Math.cos(ang) * e.strafe * spdBase * 0.6 + Math.sin(ang) * (d > 4.5 ? 1 : -0.4) * spdBase * 0.5; vz = -Math.sin(ang) * e.strafe * spdBase * 0.6 + Math.cos(ang) * (d > 4.5 ? 1 : -0.4) * spdBase * 0.5;
              e.yaw = dampAng(e.yaw, ang, 10, dt);
            } else { const s = this.steer(e, tg.x, tg.z, spdBase, dt); vx = s.vx; vz = s.vz; if (Math.hypot(vx, vz) > 0.1) e.yaw = dampAng(e.yaw, Math.atan2(vx, vz), 12, dt); }
          } else { e.yaw = dampAng(e.yaw, ang, 12, dt); if (d > 1.6 && d > maxR * 0.5) { vx = Math.sin(ang) * spdBase * 0.5; vz = Math.cos(ang) * spdBase * 0.5; } }
          if (e.cd <= 0 && canTok) this.pickAttack(e, tg, d);
        }
      }
    } else { e.tT = 0.3; }
    // doors: open nearby closed unlocked doors
    if (!e.dead) for (const dr of W.doors) { if (!dr.open && !dr.locked && Math.abs(dr.x - e.x) < 2.2 && Math.abs(dr.z - e.z) < 2.2 && Math.abs(dr.y - e.y) < 2) W.openDoor(dr, true); }
    // stuck detection
    e.stuckT += dt; if (e.stuckT > 1.0) { const moved = Math.hypot(e.x - e.lastX, e.z - e.lastZ); if (moved < 0.25 * spdBase * 1.0 && Math.hypot(vx, vz) > 0.8 && !e.atk) { e.path = null; e.pathT = 0; e.strafe *= -1; e.nudge = 0.6; } e.lastX = e.x; e.lastZ = e.z; e.stuckT = 0; }
    if (e.nudge > 0) { e.nudge -= dt; vx += Math.cos(e.yaw) * e.strafe * spdBase * 0.5; vz += -Math.sin(e.yaw) * e.strafe * spdBase * 0.5; }
    this._phys(e, dt, vx + kx, vz + kz);
    this._sync(e, dt, Math.hypot(vx, vz));
  },
  _wakeCheck(e, fromIdle) {
    const def = e.def, sight = (def.sight || 16) * (e.state === 'lying' ? 0.7 : 0.85);
    const cands = [G.p, ...G.allies]; if (G.run && G.run.protectObj && G.run.protectActive) cands.push(G.run.protectObj);
    for (const t of cands) {
      if (!t || t.dead || t.down || t.ghost) continue;
      const d = dist(e, t); if (d > sight || Math.abs(t.y - e.y) > 6) continue;
      if (d < 7 || !G.W.losBlocked(e.x, e.z, t.x, t.z, 1.2)) { if (fromIdle) { e.state = 'chase'; } else this.wake(e); e.target = t; return; }
    }
  },
  pickTarget(e) {
    let best = null, bs = 1e9; const sight = (e.def.sight || 16) * 3;
    const cand = [];
    if (G.p && !G.p.dead && !G.p.ghost) cand.push([G.p, 1]);
    for (const a of G.allies) if (!a.down) cand.push([a, a.taunt ? 0.45 : 1.15]);
    const pr = G.run && G.run.protectObj; if (pr && !pr.dead && G.run.protectActive) cand.push([pr, 0.8]);
    for (const [t, w] of cand) { const d = dist(e, t); if (d > sight) continue; if (Math.abs(t.y - e.y) > 4 && G.W.void) continue; const s = d * w; if (s < bs) { bs = s; best = t; } }
    return best;
  },
  steer(e, tx, tz, spd, dt, ty) {
    const p = steerPoint(e, tx, tz, ty ?? (e.target ? e.target.y : e.y), dt);
    const ddx = p.x - e.x, ddz = p.z - e.z, dd = Math.hypot(ddx, ddz) || 1;
    return { vx: ddx / dd * spd, vz: ddz / dd * spd };
  },
  _phys(e, dt, vx, vz) {
    const W = G.W;
    if (e.dashV) { vx = e.dashV.x; vz = e.dashV.z; }
    const hit = moveXZ(e, vx * dt, vz * dt, { edgeGuard: W.void && !e.dashV });
    e.wallHit = hit;
    if (!e.noGround) stepVertical(e, dt);
    if (e.y < W.killY) { // fell out of the world: put back at spawn
      e.x = e.spawn.x; e.y = e.spawn.y; e.z = e.spawn.z; e.vy = 0; if (e.dead) this.remove(e);
    }
    e.vSpeed = Math.hypot(vx, vz);
  },
  _sync(e, dt, spd) {
    const rig = e.rig; rig.root.position.set(e.x, e.y, e.z); rig.root.rotation.y = e.yaw;
    rig.speed = spd !== undefined ? spd : e.vSpeed; rig.air = e.grounded ? 0 : e.vy > 0 ? 1 : -1;
    if (e.slowT > 0 && !e.dead) { if (Math.random() < dt * 6) G.fx.glow(e.x, e.y + 1, e.z, 0x9fe8ff, 1, { size: 0.2 }); }
    rig.update(dt);
  },

  // ------------------------------------------------------------------ attacks
  pickAttack(e, tg, d) {
    const def = e.boss ? e.def : e.def; const ph = e.phase;
    const opts = def.attacks.filter(a => d >= a.range[0] && d <= a.range[1] && (!a.phaseMin || ph >= a.phaseMin) && a.id !== e.lastAtk);
    const pool = opts.length ? opts : def.attacks.filter(a => d >= a.range[0] && d <= a.range[1] && (!a.phaseMin || ph >= a.phaseMin));
    if (!pool.length) { e.cd = 0.25; return; }
    let tot = 0; for (const a of pool) tot += a.weight || 1; let r = Math.random() * tot, pick = pool[0];
    for (const a of pool) { r -= a.weight || 1; if (r <= 0) { pick = a; break; } }
    this.startAttack(e, pick, tg);
  },
  startAttack(e, a, tg) {
    e.lastAtk = a.id; e.atk = { def: a, t: 0, hits: 0, tele: null, extra: [], dir: Math.atan2(tg.x - e.x, tg.z - e.z), fired: 0, done: false, tx: tg.x, tz: tg.z };
    const A = e.atk, rig = e.rig, k = a.kind;
    A.hitAt = a.hitAt ?? a.tele;
    const actDur = k === 'melee' || k === 'slam' ? Math.max(a.dur, (a.hitAt ?? a.tele) / 0.46) : a.dur;
    if (a.act) rig.act(a.act, k === 'beam' || k === 'missiles' ? 0.9 : actDur);
    const y = e.y, c = RED;
    switch (k) {
      case 'melee': case 'combo': { const rr = a.reach || 2; A.tele = G.fx.telegraph('circle', e.x + Math.sin(A.dir) * rr * 0.55, e.z + Math.cos(A.dir) * rr * 0.55, y, rr * 0.8, 0, c); break; }
      case 'dash': A.tele = G.fx.telegraph('line', e.x, e.z, y, a.spd * a.time + (a.reach || 1.5), 1.6, c); A.tele.yaw = A.dir; break;
      case 'charge': A.tele = G.fx.telegraph('line', e.x, e.z, y, a.spd * a.time, a.width || 2.4, c); A.tele.yaw = A.dir; break;
      case 'slam': A.tele = G.fx.telegraph('circle', e.x, e.z, y, a.r, 0, c); break;
      case 'leap': A.tele = G.fx.telegraph('circle', tg.x, tg.z, tg.y || y, a.r, 0, c); break;
      case 'beam': A.tele = G.fx.telegraph('line', e.x, e.z, y, a.len, a.width, c); A.tele.yaw = A.dir; break;
      case 'ring': A.tele = G.fx.telegraph('circle', e.x, e.z, y, 3.5, 0, 0xff8a3a); break;
      case 'shield': e.guard = a.time; G.audio && G.audio.sfx('shield'); break;
      case 'summon': G.fx.ring(e.x, y, e.z, 4, 0xb36bff, 0.7); break;
    }
    if (k === 'shoot' || k === 'fan') G.audio && G.audio.sfx('warn');
  },
  runAttack(e, dt) {
    const A = e.atk, a = A.def, k = a.kind, tg = e.target; A.t += dt; const t = A.t; let vx = 0, vz = 0;
    const tele = a.tele;
    const trackEnd = tele * (k === 'dash' || k === 'charge' || k === 'beam' ? 0.7 : 0.55);
    if (tg && t < trackEnd && k !== 'leap') { const ang = Math.atan2(tg.x - e.x, tg.z - e.z); A.dir = dampAng(A.dir, ang, 8, dt); e.yaw = dampAng(e.yaw, A.dir, 9, dt); }
    else if (k !== 'leap') e.yaw = dampAng(e.yaw, A.dir, 6, dt);
    if (A.tele) {
      A.tele.p = clamp(t / Math.max(0.05, tele), 0, 1);
      if (k === 'melee' || k === 'combo') { const rr = a.reach || 2; A.tele.set(e.x + Math.sin(A.dir) * rr * 0.55, e.z + Math.cos(A.dir) * rr * 0.55); }
      else if (k === 'dash' || k === 'charge' || k === 'beam') { A.tele.set(e.x, e.z, undefined, undefined, A.dir); }
      else if (k === 'slam' || k === 'ring') A.tele.set(e.x, e.z);
      if (t >= (k === 'beam' ? tele : Math.max(tele, A.hitAt)) && k !== 'slam' && k !== 'melee' && k !== 'combo' && k !== 'leap') { A.tele.kill(); A.tele = null; }
    }
    const dmg = (x) => x * e.dmgMul;
    const dirx = Math.sin(A.dir), dirz = Math.cos(A.dir);
    switch (k) {
      case 'melee': {
        if (!A.done && t >= A.hitAt) { A.done = true; Combat.cone(e, a.reach, a.arc || 1.8, dmg(a.dmg), 'e', { knock: a.knock, src: e }); G.fx.dust(e.x + dirx * a.reach * 0.7, e.y, e.z + dirz * a.reach * 0.7, 3); G.audio && G.audio.sfx('swing'); if (A.tele) { A.tele.kill(); A.tele = null; } }
        break; }
      case 'combo': {
        const n = a.hits || 3; const next = tele + A.hits * (a.gap || 0.5);
        if (A.hits < n && t >= next) { A.hits++; e.yaw = dampAng(e.yaw, tg ? Math.atan2(tg.x - e.x, tg.z - e.z) : e.yaw, 20, 1); A.dir = e.yaw; Combat.cone(e, a.reach, a.arc || 2, dmg(a.dmg), 'e', { knock: a.knock, src: e }); G.audio && G.audio.sfx('swing'); if (A.hits < n) e.rig.act(A.hits % 2 ? 'swingL' : (a.act || 'swingR'), 0.5); if (A.tele) { A.tele.kill(); A.tele = null; } }
        break; }
      case 'dash': {
        if (t >= A.hitAt - 0.1 && t < A.hitAt - 0.1 + a.time) { vx = dirx * a.spd; vz = dirz * a.spd; e.dashV = { x: vx, z: vz }; if (!A.done) { A.hit = false; } if (!A.hit) { const n = Combat.cone({ x: e.x, z: e.z, y: e.y, yaw: A.dir }, a.reach, a.arc || 1.7, dmg(a.dmg), 'e', { knock: a.knock, src: e }); if (n) { A.hit = true; } } A.done = true; if (e.wallHit) { e.dashV = null; } }
        else e.dashV = null;
        break; }
      case 'charge': {
        const s = tele; if (t >= s && t < s + a.time && !A.stunned) {
          e.dashV = { x: dirx * a.spd, z: dirz * a.spd }; e.rig.setHold('charge'); if (Math.random() < dt * 30) G.fx.dust(e.x, e.y, e.z, 2);
          if (!A.struck) { for (const tt of Combat.foes('e')) { const dx = tt.x - e.x, dz = tt.z - e.z; const along = dx * dirx + dz * dirz, side = Math.abs(dx * dirz - dz * dirx); if (along > -0.5 && along < e.r + 1.2 && side < (a.width || 2) / 2 + (tt.r || 0.4)) { Combat.damage(tt, dmg(a.dmg), { dx: dirx, dz: dirz, knock: a.knock, src: e }); if (tt.kind === 'player' || tt.kind === 'ally') {} } } if (G.p && Combat.foes('e').some(() => false)) {} }
          if (e.wallHit && t > s + 0.25) { A.stunned = true; e.dashV = null; e.stunT = a.stunOnWall || 2; e.weak = (a.stunOnWall || 2) + 0.5; e.rig.setHold('stun'); G.fx.explode(e.x + dirx * 1.5, e.y + 1, e.z + dirz * 1.5, 3, 0xffd890); G.fx.addShake(0.8); G.audio && G.audio.sfx('boom'); this._endAtk(e); return { vx: 0, vz: 0 }; }
        } else if (t >= s + a.time) { e.dashV = null; e.rig.setHold(null); if (!A.after) { A.after = true; e.rig.act('land', 0.3); } }
        break; }
      case 'slam': {
        if (!A.done && t >= A.hitAt) { A.done = true; Combat.area(e.x, e.z, a.r, dmg(a.dmg), 'e', { y: e.y, knock: a.knock, src: e }); G.fx.ring(e.x, e.y, e.z, a.r, 0xffc070, 0.5); G.fx.dust(e.x, e.y, e.z, 14); G.fx.addShake(0.6); G.audio && G.audio.sfx('boom'); if (A.tele) { A.tele.kill(); A.tele = null; } if (a.vulnerable) { e.weak = a.vulnerable; } }
        break; }
      case 'leap': {
        if (t < tele) { if (A.tele && tg) { /* aim until near end */ if (t < tele * 0.7) { A.tx = tg.x; A.tz = tg.z; A.tele.set(A.tx, A.tz); e.yaw = dampAng(e.yaw, Math.atan2(A.tx - e.x, A.tz - e.z), 10, dt); } A.tele.p = clamp(t / tele, 0, 1); } A.sx = e.x; A.sz = e.z; A.sy = e.y; }
        else if (t < tele + a.time) { const u = (t - tele) / a.time; const nx = A.sx + (A.tx - A.sx) * u, nz = A.sz + (A.tz - A.sz) * u; e.leapV = { x: (nx - e.x) / Math.max(dt, 1e-3), z: (nz - e.z) / Math.max(dt, 1e-3) }; e.dashV = e.leapV; e.y = (A.sy || 0) + Math.sin(u * Math.PI) * 3.4; e.grounded = true; e.vy = 0; e.noGround = true; }
        else if (!A.done) { A.done = true; e.dashV = null; e.noGround = false; Combat.area(e.x, e.z, a.r, dmg(a.dmg), 'e', { y: A.sy, knock: a.knock, src: e }); G.fx.ring(e.x, e.y, e.z, a.r, 0xffc070, 0.5); G.fx.explode(e.x, e.y, e.z, a.r * 0.6, 0xffd890); G.fx.addShake(0.9); if (A.tele) { A.tele.kill(); A.tele = null; } e.rig.act('land', 0.3); }
        break; }
      case 'beam': {
        if (t >= tele && t < tele + a.time) {
          const u = (t - tele) / a.time, ang = A.dir + (u - 0.5) * (a.sweep || 1.4); const bx = Math.sin(ang), bz = Math.cos(ang);
          let L = 0; const y = e.y + e.h * 0.6; while (L < a.len && !G.W.pointSolid(e.x + bx * (L + 1), y, e.z + bz * (L + 1))) L += 1;
          const ox = e.x + bx * 0.9, oz = e.z + bz * 0.9;
          G.fx.beam(ox, y, oz, e.x + bx * L, y - 0.3, e.z + bz * L, 0xff5a3a, a.width * 0.5, 0.06); G.fx.beam(ox, y, oz, e.x + bx * L, y - 0.3, e.z + bz * L, 0xffe0b0, a.width * 0.18, 0.06);
          if (Math.random() < dt * 20) G.fx.spark(e.x + bx * L, e.y + 0.2, e.z + bz * L, 0xffc080, 2);
          for (const tt of Combat.foes('e')) { const dx = tt.x - e.x, dz = tt.z - e.z; const along = dx * bx + dz * bz; if (along < 0 || along > L) continue; const side = Math.abs(dx * bz - dz * bx); if (side < a.width / 2 + (tt.r || 0.4) && Math.abs((tt.y || 0) - e.y) < 2.5) Combat.damage(tt, dmg(a.dps) * dt, { tick: true, noFlinch: true, src: e, dx: bx, dz: bz }); }
          if (!A.sfx || t - A.sfx > 0.4) { A.sfx = t; G.audio && G.audio.sfx('laser'); }
          if (a.tele && A.tele) { A.tele.kill(); A.tele = null; }
          e.rig.setHold('channel');
        } else if (t >= tele + a.time && !A.done) { A.done = true; e.rig.setHold(null); }
        break; }
      case 'missiles': {
        const n = a.n, gap = (a.dur * 0.45) / n; while (A.fired < n && t >= tele + A.fired * gap) {
          const i = A.fired++; const sx = tg ? tg.x : e.x, sz = tg ? tg.z : e.z; const ang = Math.random() * TAU, rr = i === 0 ? 0 : Math.random() * (a.spread || 6);
          const mx = sx + Math.cos(ang) * rr, mz = sz + Math.sin(ang) * rr; const T = G.fx.telegraph('circle', mx, mz, (tg && tg.y) || e.y, a.r, 0, 0xff6a2a); T.born = t; T.delay = a.delay; T.mx = mx; T.mz = mz; A.extra.push(T);
          G.audio && G.audio.sfx('warn');
        }
        for (const T of A.extra) { if (!T.alive) continue; T.p = clamp((t - T.born) / T.delay, 0, 1); if (t - T.born >= T.delay) { T.kill(); G.fx.explode(T.mx, T.y, T.mz, a.r * 0.8, 0xff8a3a); G.audio && G.audio.sfx('boom'); Combat.area(T.mx, T.mz, a.r, dmg(a.dmg), 'e', { y: T.y, knock: 6, src: e }); } }
        if (A.fired >= n) e.rig.act('raise', 0.4);
        break; }
      case 'fan': case 'shoot': {
        const n = a.n || 1, gap = a.gap ?? 0.12;
        if (k === 'shoot') { while (A.fired < n && t >= A.hitAt + A.fired * gap) { A.fired++; this._fireAt(e, tg, A.dir, a, 0); } }
        else if (!A.done && t >= A.hitAt) { A.done = true; const ang = tg ? Math.atan2(tg.x - e.x, tg.z - e.z) : A.dir; for (let i = 0; i < n; i++) this._fireAt(e, tg, ang + (i / (n - 1 || 1) - 0.5) * a.spread, a, 1); }
        break; }
      case 'ring': {
        if (!A.done && t >= A.hitAt) { A.done = true; if (A.tele) { A.tele.kill(); A.tele = null; } G.fx.ring(e.x, e.y, e.z, 3, a.color || 0xff8a3a, 0.5); const off = Math.random() * TAU; for (let i = 0; i < a.n; i++) { const ang = off + i / a.n * TAU; Combat.shoot({ x: e.x + Math.sin(ang) * 1.0, y: e.y + 1.2, z: e.z + Math.cos(ang) * 1.0, dx: Math.sin(ang), dy: 0, dz: Math.cos(ang), spd: a.spd, dmg: dmg(a.dmg), team: 'e', color: a.color, size: 0.2, range: 30, src: e }); } G.audio && G.audio.sfx('nova'); }
        break; }
      case 'summon': {
        if (!A.done && t >= tele) { A.done = true; this.summon(e, a.list); }
        break; }
      case 'shield': break;
    }
    if (t >= Math.max(a.dur, k === 'melee' || k === 'slam' ? A.hitAt + 0.35 : 0)) this._endAtk(e);
    return { vx, vz };
  },
  _endAtk(e) {
    const A = e.atk; if (!A) return; if (A.tele) A.tele.kill(); for (const T of A.extra) if (T.alive && T.kill) { /* markers continue? finish */ T.kill(); }
    e.atk = null; e.dashV = null; e.noGround = false; if (e.rig.hold === 'charge' || e.rig.hold === 'channel') e.rig.setHold(null);
    const ph = e.def.phases ? e.def.phases[e.phase] : null; const cdm = ph ? ph.cd : 1; const [c0, c1] = e.def.cd || [0.8, 1.6];
    e.cd = rnd(c0, c1) * (e.boss ? 1.1 * cdm : 1);
  },
  _fireAt(e, tg, ang, a, fan) {
    const ox = e.x + Math.sin(ang) * 0.7, oz = e.z + Math.cos(ang) * 0.7, oy = e.y + e.h * 0.62;
    let dy = 0; if (tg) { const d = Math.hypot(tg.x - e.x, tg.z - e.z) || 1; dy = ((tg.y || 0) + 1.0 - oy) / d; dy = clamp(dy, -0.5, 0.5); }
    Combat.shoot({ x: ox, y: oy, z: oz, dx: Math.sin(ang), dy: fan === 2 ? 0 : dy, dz: Math.cos(ang), spd: a.spd, dmg: a.dmg * e.dmgMul, team: 'e', color: a.color || 0xff5a3a, size: 0.17, range: 30, src: e });
    G.audio && G.audio.sfx('shoot'); e.rig.flash(a.color || 0xff5a3a, 0.08);
  },
  summon(e, list) {
    if (G.enemies.filter(x => !x.dead).length > 16) return;
    for (const [type, n] of Object.entries(list)) for (let i = 0; i < n; i++) {
      for (let tr = 0; tr < 12; tr++) { const a = Math.random() * TAU, r = rnd(3, 6); const x = e.x + Math.cos(a) * r, z = e.z + Math.sin(a) * r; if (G.W.isFree(x, z, e.y, 0.9)) { const s = this.spawn(type, x, e.y, z, { state: 'chase', rise: ENEMIES[type].rises || false, fromWave: true, group: e.group, seg: e.seg }); s.wave = 'boss'; G.fx.ring(x, e.y, z, 1.6, 0xb36bff, 0.5); break; } }
    }
  },
  bossPhaseCheck(e) {
    const ph = e.def.phases; if (!ph) return; const r = e.hp / e.maxHp;
    for (let i = ph.length - 1; i > e.phase; i--) if (r <= ph[i].at) {
      e.phase = i; const P = ph[i]; e.speedMul = P.speed; this.cancel(e);
      e.stunT = 0; e.state = 'intro'; e.st = 0; e.rig.act('roar', 1.1); G.fx.ring(e.x, e.y, e.z, 8, 0xffd890, 0.7); G.fx.addShake(0.8); G.audio && G.audio.sfx('roar');
      Combat.area(e.x, e.z, 6, 0, 'e', { knock: 10, src: e });
      if (P.summon) setTimeout(() => !e.dead && this.summon(e, P.summon), 600);
      if (P.pylons && G.run) G.run.spawnPylons(e);
      G.fx.text(e.x, e.y + e.h + 1, e.z, 'المرحلة ' + (i + 1), 'crit');
      break;
    }
  },
};
