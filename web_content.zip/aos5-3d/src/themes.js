// Lighting / sky themes used by levels
// sky: [zenith, horizon]; fog: [color, near, far]; sun: {c, i, dir}; hemi: [skyColor, groundColor, intensity]
export const THEMES = {
  dusk: { sky: [0x1d2650, 0xf0a064], fog: [0x9a7086, 38, 150], sun: { c: 0xffc08a, i: 2.6, dir: [-0.6, 0.55, -0.45] }, hemi: [0x8fa0d8, 0x55404c, 0.85], exposure: 1.0, lamps: true },
  night: { sky: [0x050818, 0x1b2850], fog: [0x141c36, 28, 110], sun: { c: 0x9fb4ff, i: 1.0, dir: [0.5, 0.8, -0.5] }, hemi: [0x4a5c98, 0x1c1a28, 0.65], exposure: 1.05, lamps: true, stars: true },
  overcast: { sky: [0x59616e, 0xb6bcc4], fog: [0x9aa0a8, 30, 120], sun: { c: 0xe8ecf4, i: 1.5, dir: [-0.3, 0.9, -0.3] }, hemi: [0xb8c4d8, 0x6a665e, 1.0], exposure: 1.0, lamps: false },
  industrial: { sky: [0x4f86c4, 0xe6d9b8], fog: [0xcfc4a4, 45, 170], sun: { c: 0xfff0cf, i: 3.0, dir: [-0.5, 0.75, -0.5] }, hemi: [0xa8c8f0, 0x6a5e4a, 0.95], exposure: 1.0, lamps: false },
  rust: { sky: [0x6a4a3a, 0xe0a070], fog: [0xb48a68, 34, 130], sun: { c: 0xffb070, i: 2.5, dir: [0.6, 0.5, -0.4] }, hemi: [0xd8a880, 0x5a4034, 0.9], exposure: 1.0, lamps: true },
  lab: { sky: [0x24303c, 0x42566a], fog: [0x32404e, 40, 140], sun: { c: 0xcfe6ff, i: 1.3, dir: [0, 1, -0.3] }, hemi: [0xbad4f0, 0x40505c, 1.05], exposure: 1.05, lamps: true },
  tunnel: { sky: [0x06090d, 0x0a1218], fog: [0x0a1218, 12, 55], sun: { c: 0x6a8aa8, i: 0.5, dir: [0.2, 1, -0.2] }, hemi: [0x4a6a82, 0x101820, 0.7], exposure: 1.1, lamps: true },
  sewer: { sky: [0x050a06, 0x0c180e], fog: [0x0e2414, 10, 50], sun: { c: 0x7aaa7a, i: 0.45, dir: [0.2, 1, -0.2] }, hemi: [0x4a8a58, 0x0c180e, 0.7], exposure: 1.15, lamps: true },
  sunrise: { sky: [0x4a78c8, 0xffb08a], fog: [0xe8b898, 50, 200], sun: { c: 0xffd2a0, i: 3.0, dir: [-0.8, 0.45, -0.3] }, hemi: [0xa8c0f0, 0x7a6a66, 0.95], exposure: 1.0, lamps: false },
  storm: { sky: [0x1a1e2e, 0x4a5268], fog: [0x3a4258, 30, 130], sun: { c: 0xb8c4e8, i: 1.2, dir: [-0.3, 0.9, -0.2] }, hemi: [0x7a88b0, 0x2a2a38, 0.8], exposure: 1.0, lamps: true, lightning: true },
  final: { sky: [0x12040c, 0x6a1830], fog: [0x40101e, 30, 120], sun: { c: 0xff7a70, i: 1.8, dir: [0.4, 0.7, -0.5] }, hemi: [0xc05a6a, 0x200a14, 0.8], exposure: 1.05, lamps: true, lightning: true },
};
