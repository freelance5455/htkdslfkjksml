// Extra game modes built on the same Run engine: endless zombie waves, jump tower, base defense (8 waves).
import * as THREE from 'three';
import { G } from './ctx.js';
import { Save } from './save.js';
import { Input } from './input.js';
import { ENEMIES } from './data/enemies.js';

const rr = (a, b) => a + Math.random() * (b - a);
const fmt = (n) => Math.round(n).toLocaleString('en-US');

/** shared: begin a run with a dynamic spec + mode object */
function begin(spec, mode, o = {}) {
  const { Run, Game } = G; G.state = 'loading'; G.ui.loading(true, 'جارٍ تجهيز ' + spec.name + '…'); G.audio.unlock();
  setTimeout(() => {
    try {
      mode.spec = spec; Run.begin({ spec, mode, noExit: !!o.noExit }); G.state = 'play'; Input.flush(); if (mode.setup) mode.setup(Run);
    } catch (e) { console.error('[game] mode start failed', e); G.ui.toast('خطأ أثناء تحميل الوضع'); G.state = 'menu'; G.ui.replace('title'); }
    G.ui.loading(false);
  }, 30);
}

/** finish a mode run: grants rewards, stores record, shows the results screen */
function finish(mode, r) {
  const R = G.run; if (!R || R.state === 'complete') return;
  const S = Save.d, M = S.modes[mode.key];
  const coins = Math.round(r.coins) + R.coins; S.coins += coins; S.stats.coinsEarned += coins; G.Player.addXP(r.xp || 0);
  let newBest = false;
  if (mode.key === 'jump') { if (r.win) { const b = M.best[mode.v]; if (!b || r.time < b) { M.best[mode.v] = Math.round(r.time * 10) / 10; newBest = true; } } }
  else { if ((r.bestVal || 0) > (M.best || 0)) M.best = r.bestVal; if (r.score > (M.bestScore || 0)) { M.bestScore = r.score; newBest = true; } }
  M.runs = (M.runs || 0) + 1; Save.commit(true);
  R.state = 'complete'; R.completeT = 0; R.frozenInput = true; R.failShown = true;
  const best = mode.key === 'jump' ? (M.best[mode.v] || r.time) : M.bestScore;
  R.results = { id: mode.key, name: mode.spec.name, time: R.time, par: r.par || R.time, kills: R.stats.kills, taken: Math.round(R.stats.taken), deaths: R.stats.deaths, coinsPicked: R.coins, rewardCoins: Math.round(r.coins), rewardXp: (r.xp || 0), stars: r.stars, score: r.score, best, newBest, first: true, unlocks: r.notes || [], mode: mode.key, rows: r.rows || [], title: r.title, win: !!r.win };
  G.audio.music('victory'); G.audio.sfx(r.win ? 'win' : 'lose');
  if (r.win) { G.p.rig.setHold('victory'); G.fx.ring(G.p.x, G.p.y, G.p.z, 5, 0x66ffa8, 0.8); }
}

// ================================================================= zombie waves (endless)
function waveList(n) {
  const l = []; const z = 4 + Math.floor(n * 1.7); for (let i = 0; i < z; i++) l.push('zombie');
  if (n >= 2) for (let i = 0; i < Math.floor(n * 0.9); i++) l.push('zfast');
  if (n >= 4) for (let i = 0; i < Math.floor((n - 1) / 3); i++) l.push('mutant');
  if (n % 5 === 0) for (let i = 0; i < 1 + Math.floor(n / 5); i++) l.push('mutant');
  if (n >= 7) for (let i = 0; i < Math.floor((n - 5) / 2); i++) l.push('slinger');
  for (let i = l.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [l[i], l[j]] = [l[j], l[i]]; }
  return l.slice(0, 46);
}
function zombieMode() {
  const m = {
    id: 'zombie', key: 'zombie', title: 'وضع الزومبي', intro: 'اصمد أمام موجات لا تنتهي. كل موجة أقوى من التي قبلها!', wave: 0, st: 'prep', t: 3.0, queue: [], total: 0, spawnT: 0, cap: 20, over: false,
    spec: null,
    restart() { Modes.start('zombie'); },
    setup(R) {
      const a = R.arena; if (a && a.gateW) { G.W.openDoor(a.gateW, false); G.W.setDoorLocked(a.gateW, true); }
      G.W.checkpoints.length = 0; R.checkpoint = { x: G.W.start.x, y: 0, z: G.W.start.z };
      G.ui.banner('وضع الزومبي — اصمد أطول ما تستطيع!', 2.6); G.audio.music('boss');
    },
    hudText() { const left = this.queue.length + G.enemies.filter(e => !e.dead && e.fromWave).length; return this.st === 'prep' || this.st === 'break' ? 'الموجة ' + (this.wave + 1) + ' بعد ' + Math.ceil(this.t) + 'ث' : 'الموجة ' + this.wave + ' — المتبقي ' + left; },
    onDeath() { this.end(); },
    end() {
      if (this.over) return; this.over = true; const w = Math.max(0, this.wave - (this.st === 'wave' ? 1 : 0)), R = G.run;
      const stars = w >= 15 ? 3 : w >= 8 ? 2 : 1; const score = w * 1000 + R.stats.kills * 15;
      finish(this, { win: false, stars, score, bestVal: w, coins: w * 22 + Math.floor(w * w * 1.2), xp: w * 18, rows: [['الموجات المكتملة', w]], title: 'سقط البطل', notes: w > (Save.d.modes.zombie.best || 0) ? ['رقم قياسي جديد في عدد الموجات!'] : [] });
    },
    update(dt) {
      const R = G.run, info = R.arena; if (!info || this.over) return;
      if (this.st === 'prep' || this.st === 'break') {
        this.t -= dt; if (this.t <= 0) { this.wave++; this.queue = waveList(this.wave); this.total = this.queue.length; this.st = 'wave'; this.spawnT = 0; G.ui.banner('الموجة ' + this.wave, 1.6); G.audio.sfx('warn'); }
      } else if (this.st === 'wave') {
        const alive = G.enemies.filter(e => !e.dead && e.fromWave).length;
        this.spawnT -= dt;
        if (this.queue.length && alive < this.cap && this.spawnT <= 0) {
          const k = Math.min(this.queue.length, this.cap - alive, 3), spots = R.waveSpots(info, k); this.spawnT = 0.9;
          for (let i = 0; i < k && spots[i]; i++) {
            const t = this.queue.shift(), def = ENEMIES[t], s = spots[i], rises = def.rises;
            const e = G.Enemy.spawn(t, s.x, s.y, s.z, { state: rises ? 'rising' : 'chase', rise: rises, fromWave: true, seg: info.id, scale: 1 + 0.05 * (this.wave - 1), dmgScale: 1 + 0.03 * (this.wave - 1) });
            if (rises) e.untargetable = true; else G.fx.ring(s.x, s.y, s.z, 1.6, 0xff6a3a, 0.5);
          }
        }
        if (!this.queue.length && alive === 0) {
          this.st = 'break'; this.t = 5; const P = G.p;
          G.Player.heal(P.maxHp * 0.3); P.energy = Math.min(P.maxEnergy, P.energy + 40);
          R.dropLoot(P.x + 1.5, 0, P.z, 8 + this.wave * 3, this.wave % 2 === 0);
          G.ui.banner('تم تطهير الموجة ' + this.wave + ' ✔', 2); G.audio.sfx('objective');
        }
      }
    },
  };
  return m;
}

// ================================================================= base defense (core + 8 waves from both sides)
const DEF_WAVES = [
  { thug: 5, runner: 2 }, { thug: 4, slinger: 3, runner: 3 }, { armored: 2, thug: 5, runner: 2 }, { robot: 3, slinger: 4, thug: 4 },
  { armored: 3, robot: 3, runner: 5 }, { slinger: 6, robot: 4, armored: 2 }, { armored: 4, robot: 5, runner: 6, slinger: 3 }, { mutant: 2, armored: 4, robot: 5, slinger: 4, runner: 6 },
];
function defenseMode() {
  const m = {
    id: 'defense', key: 'defense', title: 'وضع الدفاع', intro: 'النواة هي كل شيء. اصدّ 8 موجات من الجهتين.', wave: 0, st: 'prep', t: 5.0, queue: [], spawnT: 0, cap: 16, over: false, spec: null, core: null,
    restart() { Modes.start('defense'); },
    setup(R) {
      const a = R.arena; if (a && a.gateW) { G.W.openDoor(a.gateW, false); G.W.setDoorLocked(a.gateW, true); }
      G.W.checkpoints.length = 0; const c = R.protectObj; this.core = c; c.maxHp = c.hp = 1200; R.protectActive = true; R.protectLeft = 999;
      G.ui.banner('احمِ النواة من 8 موجات!', 2.8); G.audio.music('boss');
    },
    hudText() { const left = this.queue.length + G.enemies.filter(e => !e.dead && e.fromWave).length; return this.st === 'wave' ? 'الموجة ' + this.wave + '/8 — المتبقي ' + left : 'الموجة ' + (this.wave + 1) + '/8 بعد ' + Math.ceil(this.t) + 'ث'; },
    protText() { return 'الموجة ' + Math.max(1, this.wave) + '/8'; },
    onDeath() { this.end(false, 'سقط البطل'); },
    end(win, why) {
      if (this.over) return; this.over = true; const R = G.run, c = this.core; const hpPct = c ? Math.max(0, c.hp / c.maxHp) : 0;
      const w = win ? 8 : Math.max(0, this.wave - 1);
      const stars = win ? (hpPct > 0.7 && R.stats.deaths === 0 ? 3 : hpPct > 0.35 ? 2 : 1) : 1; const score = w * 900 + Math.round(hpPct * 3000) + R.stats.kills * 20 + (win ? 4000 : 0);
      R.protectActive = false;
      finish(this, { win, stars: win ? stars : 1, score, bestVal: w, coins: win ? 520 + stars * 120 : w * 28, xp: win ? 220 : w * 14, rows: [['الموجات المصدودة', w + '/8'], ['صحة النواة', Math.round(hpPct * 100) + '%']], title: win ? 'نجحت في الدفاع!' : (why || 'سقطت القاعدة'), notes: win ? ['هزمت كل الموجات الثماني'] : [] });
    },
    update(dt) {
      const R = G.run, info = R.arena; if (!info || this.over) return; const c = this.core;
      R.protectLeft = 999;
      if (c && c.dead) { this.end(false); return; }
      if (this.st === 'prep' || this.st === 'break') {
        this.t -= dt; if (this.t <= 0) {
          this.wave++; const l = DEF_WAVES[this.wave - 1]; this.queue = []; for (const [t, n] of Object.entries(l)) for (let i = 0; i < n; i++) this.queue.push(t);
          for (let i = this.queue.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [this.queue[i], this.queue[j]] = [this.queue[j], this.queue[i]]; }
          this.st = 'wave'; this.spawnT = 0; G.ui.banner('الموجة ' + this.wave + ' / 8', 1.6); G.audio.sfx('warn');
        }
      } else {
        const alive = G.enemies.filter(e => !e.dead && e.fromWave).length; this.spawnT -= dt;
        if (this.queue.length && alive < this.cap && this.spawnT <= 0) {
          this.spawnT = 1.1; const k = Math.min(this.queue.length, 3);
          for (let i = 0; i < k; i++) {
            const t = this.queue.shift(), side = Math.random() < 0.5 ? -1 : 1, x = side < 0 ? info.x0 + 3.5 : info.x1 - 3.5, z = rr(-info.hw + 4, info.hw - 4);
            if (!G.W.isFree(x, z, 0, 0.9)) { this.queue.push(t); continue; }
            const e = G.Enemy.spawn(t, x, 0, z, { state: 'chase', fromWave: true, seg: info.id, scale: 1 + 0.06 * (this.wave - 1), dmgScale: 1 + 0.04 * (this.wave - 1) }); G.fx.ring(x, 0, z, 1.6, 0xff6a3a, 0.5); e.coreTarget = true;
          }
        }
        if (!this.queue.length && alive === 0) {
          if (this.wave >= 8) { this.end(true); return; }
          this.st = 'break'; this.t = 8; const P = G.p; G.Player.heal(P.maxHp * 0.4); if (c) { c.hp = Math.min(c.maxHp, c.hp + c.maxHp * 0.12); }
          R.dropLoot(P.x + 1.5, 0, P.z, 14 + this.wave * 4, true); G.ui.banner('تم صدّ الموجة ' + this.wave + ' ✔ — أصلحت جزءًا من النواة', 2.4); G.audio.sfx('objective');
        }
      }
    },
  };
  return m;
}

// ================================================================= jump tower
const TOWERS = { easy: { n: 12, hard: 0.0, name: 'برج المبتدئ', par: 70, rew: 140 }, mid: { n: 20, hard: 0.5, name: 'برج المحترف', par: 150, rew: 320 }, hard: { n: 30, hard: 1.0, name: 'برج الجحيم', par: 260, rew: 640 } };
function jumpMode(v) {
  const T = TOWERS[v] || TOWERS.easy;
  const m = {
    id: 'jump', key: 'jump', v, title: T.name, intro: 'منصات متحرّكة ومنهارة ومراوح ونوابض. لا تنظر إلى الأسفل!', spec: null, over: false, falls: 0, padCD: 0,
    restart() { Modes.start('jump', { v }); },
    setup(R) { G.Ally.clearAll(); G.audio.music('level'); G.ui.banner(T.name + ' — اصعد إلى القمة!', 2.4); },
    hudText() { const TW = G.W.tower; const h = Math.max(0, Math.round(G.p.y)), top = Math.round(TW.top); return 'الارتفاع ' + h + ' / ' + top + 'م — السقطات ' + this.falls; },
    onDeath() { this.falls++; G.run.respawn(); },
    complete() {
      const R = G.run; if (this.over) return; this.over = true; const t = R.time;
      const stars = t <= T.par * 0.6 ? 3 : t <= T.par ? 2 : 1; const score = Math.max(0, Math.round(5000 - t * 12 - this.falls * 60 + stars * 800));
      const M = Save.d.modes.jump; const prev = M.best[v];
      finish(this, { win: true, stars, score, par: T.par, coins: T.rew * (stars === 3 ? 1.4 : stars === 2 ? 1.15 : 1), xp: Math.round(T.rew * 0.5), rows: [['السقطات', this.falls]], title: 'وصلت إلى القمة!', notes: !prev || t < prev ? ['رقم قياسي جديد: ' + (Math.round(t * 10) / 10) + 'ث'] : [] });
    },
    update(dt) {
      const R = G.run, TW = G.W.tower, P = G.p, W = G.W; if (!TW) return; this.padCD -= dt;
      if (R.fellFlag) { R.fellFlag = false; this.falls++; }
      // crumbling platforms
      for (const c of TW.crumbles) {
        if (c.state === 'idle') { if (P.grounded && W.lastGround === c.col) { c.state = 'shake'; c.t = 0; G.audio.sfx('click'); } }
        else if (c.state === 'shake') { c.t += dt; c.mesh.position.x += (Math.random() - 0.5) * 0.04; c.mesh.position.y = c.base + (Math.random() - 0.5) * 0.03; if (c.t > 0.65) { c.state = 'fall'; c.t = 0; c.col.enabled = false; G.fx.dust(c.mesh.position.x, c.y, c.mesh.position.z, 6); } }
        else if (c.state === 'fall') { c.t += dt; c.mesh.position.y -= dt * (3 + c.t * 14); c.mesh.rotation.z += dt * 0.6; c.mesh.visible = c.t < 1.0; if (c.t > 3.2) { c.state = 'idle'; c.col.enabled = true; c.mesh.visible = true; c.mesh.rotation.z = 0; c.mesh.position.y = c.base; c.mesh.position.x = (c.col.x0 + c.col.x1) / 2; } }
      }
      // spinning bars
      for (const s of TW.spinners) {
        s.a += s.spd * dt; s.bar.rotation.y = -s.a; s.cd -= dt;
        if (P.dead || P.iframes > 0 || s.cd > 0 || Math.abs(P.y - s.y) > 1.3 || P.y > s.y + 0.95) continue;
        const dx = P.x - s.x, dz = P.z - s.z, ux = Math.cos(s.a), uz = Math.sin(s.a), along = dx * ux + dz * uz, perp = Math.abs(-dx * uz + dz * ux);
        if (Math.abs(along) < s.len + 0.3 && perp < 0.55) { s.cd = 0.8; const l = Math.hypot(dx, dz) || 1; P.kx = dx / l * 9; P.kz = dz / l * 9; P.vy = 5; P.grounded = false; G.Player.hurt(6, { src: s }); G.fx.spark(P.x, P.y + 1, P.z, 0xff6a3a, 8); G.audio.sfx('hurt'); }
      }
      // bounce pads
      if (P.grounded && this.padCD <= 0) for (const b of TW.pads) if (P.x > b.x0 && P.x < b.x1 && P.z > b.z0 && P.z < b.z1 && Math.abs(P.y - b.y) < 0.4) { P.vy = 15.2; P.grounded = false; this.padCD = 0.5; G.fx.ring(P.x, P.y, P.z, 2, 0x3aff9a, 0.4); G.audio.sfx('jump'); break; }
    },
  };
  return m;
}

export const Modes = {
  TOWERS,
  start(key, d = {}) {
    if (Save.d.unlockedStage <= 1) { G.ui.toast('أكمل المرحلة 1 لفتح الأوضاع'); return; }
    const seed = d.seed || 7000 + Math.floor(Math.random() * 9000);
    if (key === 'zombie') {
      begin({ id: 'm_zombie', ch: 0, name: 'وضع الزومبي', theme: 'night', diff: 3, seed, rew: { coins: 0, xp: 0 }, objectives: [],
        segs: [{ t: 'arena', id: 'arena', len: 60, hw: 17, theme: 'street', ringColor: 0x66ff66, lightColor: 0xa0ffb0 }] }, zombieMode(), { noExit: true });
    } else if (key === 'defense') {
      begin({ id: 'm_defense', ch: 0, name: 'وضع الدفاع', theme: 'dusk', diff: 4, seed, rew: { coins: 0, xp: 0 }, objectives: [],
        segs: [{ t: 'arena', id: 'arena', len: 62, hw: 17, theme: 'factory', ringColor: 0x66b8ff, lightColor: 0xffd0a0, protect: true }] }, defenseMode(), { noExit: true });
    } else if (key === 'jump') {
      const v = d.v || 'easy', T = TOWERS[v] || TOWERS.easy;
      begin({ id: 'm_jump_' + v, ch: 0, name: T.name, theme: 'sunrise', diff: 1, seed, rew: { coins: 0, xp: 0 },
        segs: [{ t: 'tower', id: 'tw', n: T.n, hard: T.hard }], objectives: [{ type: 'reach', seg: 'tw', at: 'exit', text: 'اصعد إلى قمة البرج' }] }, jumpMode(v));
    }
  },
};
