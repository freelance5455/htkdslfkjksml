// Automated test pilot: drives the real game through the same Input API (sim) to verify levels are completable.
import { G } from './ctx.js';
import { Input } from './input.js';
import { Combat } from './combat.js';
import { Save } from './save.js';
import { steerPoint } from './pathing.js';

const S = Input.sim;
export const Bot = {
  on: false, path: null, pathT: 0, pi: 1, goalKey: '', stuck: 0, lx: 0, lz: 0, stuckT: 0, jumpT: 0, log: [],
  enable() { this.on = true; S.on = true; },
  disable() { this.on = false; S.on = false; S.x = S.z = 0; S.hold = {}; S.edge = {}; },
  press(a) { S.edge[a] = true; },
  tick(dt) {
    const P = G.p, run = G.run, W = G.W; if (!P || !run) return;
    S.x = S.z = 0; S.hold.attack = false;
    if (run.state === 'dead') { if (run.deadT > 1.5) { if (run.failMsg) return 'fail'; G.Game.respawn(); G.run.failShown = false; } return; }
    if (run.state !== 'play' || P.dead) return;
    // use abilities opportunistically
    const foe = this.nearestFoe(P);
    const dist = foe ? Math.hypot(foe.x - P.x, foe.z - P.z) : 99;
    if (P.interact && P.form !== 'mech') { if (!(P.interact.type === 'mech' && G.run.noMech)) this.press('interact'); }
    if (P.form === 'hero') { if (P.hp < P.maxHp * 0.5 && dist < 6) { this.tryAbility(P); } if (P.energy > 60 && dist < 10 && dist > 2) this.tryAbility(P); if (G.Player.canTransform() && foe) this.press('transform'); }
    let tx, tz;
    const goal = run.goal();
    if (run.boss && run.boss.shielded && run.pylons) { // break the pylons first, fighting only what blocks the way
      const py = run.pylons.filter(p => !p.dead).sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z))[0];
      if (py) { const d = Math.hypot(py.x - P.x, py.z - P.z); if (d < 2.6) { S.hold.attack = true; this.press('attack'); this.faceXZ(P, py.x, py.z); this.moveTo(P, py.x, py.z, 0.1); } else this.moveTo(P, py.x, py.z, 1); if (G.Player.weaponItem().cat === 'ranged' && d < 12) { S.hold.attack = true; this.press('attack'); this.faceXZ(P, py.x, py.z); } return; }
    }
    if (foe && dist < (foe.boss || run.mode ? 40 : 11)) {
      const ranged = G.Player.weaponItem().cat === 'ranged';
      tx = foe.x; tz = foe.z; const want = ranged ? 7 : 1.7;
      if (dist < want + 0.4 && !ranged) { S.hold.attack = true; this.press('attack'); this.face(P, foe); this.moveTo(P, foe.x, foe.z, 0.15); }
      else if (ranged && dist < 14) { S.hold.attack = true; this.press('attack'); this.face(P, foe); if (dist < 5) this.moveTo(P, P.x * 2 - foe.x, P.z * 2 - foe.z, 1); }
      else this.moveTo(P, tx, tz, 1);
      // dodge incoming telegraphed attacks
      if (foe.atk && dist < 4 && foe.atk.t > foe.atk.def.tele * 0.7 && P.rollCD <= 0 && Math.random() < 0.06) { S.x = P.x - foe.x; S.z = P.z - foe.z; const l = Math.hypot(S.x, S.z) || 1; S.x /= l; S.z /= l; this.press('dodge'); }
      return;
    }
    if (!goal) { if (run.boss && !run.boss.dead) { this.moveTo(P, run.boss.x, run.boss.z, 1); } else if (run.mode && run.arena) { const a = run.arena; const cx = (a.x0 + a.x1) / 2, cz = 0; if (Math.hypot(cx - P.x, cz - P.z) > 4) this.moveTo(P, cx, cz, 0.8); } return; }
    // breakable nests/pylons on goal
    if (goal.attack) { const d = Math.hypot(goal.x - P.x, goal.z - P.z); if (d < 2.4) { S.hold.attack = true; this.press('attack'); this.faceXZ(P, goal.x, goal.z); return; } }
    const cur = run.current();
    if (cur && cur.type === 'protect' && run.protectActive) { // hold position near the generator, fight
      const d = Math.hypot(goal.x - P.x, goal.z - P.z); if (d > 6) this.moveTo(P, goal.x, goal.z, 1); return;
    }
    const d = Math.hypot(goal.x - P.x, goal.z - P.z);
    if (cur && (cur.type === 'switches' || cur.type === 'rescue') && d < 2.2) { this.press('interact'); return; }
    this.moveTo(P, goal.x, goal.z, 1, goal.y);
  },
  tryAbility(P) { for (const s of ['a1', 'a2']) if (G.save.d.equip[s] && P.cd[s] <= 0) { this.press(s); return; } },
  nearestFoe(P) {
    let best = null, bd = 1e9;
    for (const e of G.enemies) { if (e.dead || e.untargetable || e.state === 'lying' || e.state === 'dormant' && !e.boss) continue; if (Math.abs(e.y - P.y) > 3) continue; const d = Math.hypot(e.x - P.x, e.z - P.z); if (d < bd) { bd = d; best = e; } }
    return best;
  },
  face(P, e) { this.faceXZ(P, e.x, e.z); },
  faceXZ(P, x, z) { const dx = x - P.x, dz = z - P.z, l = Math.hypot(dx, dz) || 1; S.x = dx / l * 0.05; S.z = dz / l * 0.05; },
  moveTo(P, x, z, speed = 1, gy) {
    const W = G.W; let gx = x, gz = z;
    if (W.nav && W.nav.enabled) {
      const a = this.pp || (this.pp = { pathT: 0 }); a.x = P.x; a.y = P.y; a.z = P.z; const p = steerPoint(a, x, z, gy ?? P.y, 1 / 60); gx = p.x; gz = p.z;
    } else if (W.void) { // platform hopping: next route platform center
      const rt = W.route; let ni = -1; for (let i = 0; i < rt.length; i++) if (rt[i].x > P.x + 0.5) { ni = i; break; }
      // target the near edge of the next platform
      const cur = rt.filter(r => r.x <= P.x + 0.5).pop(); if (ni >= 0) { const nx = rt[ni]; gx = Math.max(P.x + 1, nx.x - 3); gz = nx.z; if (Math.hypot(nx.x - P.x, nx.z - P.z) < 14 || true) { gx = nx.x; gz = nx.z; } }
      if (goalNear(P, x, z)) { gx = x; gz = z; }
    }
    const dx = gx - P.x, dz = gz - P.z, l = Math.hypot(dx, dz) || 1; S.x = dx / l * speed; S.z = dz / l * speed;
    // jump over low obstacles / gaps
    this.stuckT += 1 / 60; if (this.stuckT > 0.7) { const mv = Math.hypot(P.x - this.lx, P.z - this.lz); if (mv < 0.5 && speed > 0.5) { this.press('jump'); this.stuck++; if (this.stuck % 3 === 0) { S.x += (Math.random() - 0.5) * 2; S.z += (Math.random() - 0.5) * 2; this.pp && (this.pp.path = null, this.pp.vp = null); } } this.lx = P.x; this.lz = P.z; this.stuckT = 0; }
    if (W.void && P.grounded) { const ax = P.x + S.x / Math.max(0.01, Math.hypot(S.x, S.z)) * 0.5, az = P.z + S.z / Math.max(0.01, Math.hypot(S.x, S.z)) * 0.5; const g = W.groundAt(ax, az, P.y, 0.15); if (g < P.y - 0.7) this.press('jump'); }
  },
  /** static audit: which ground-level objects are unreachable from the start? */
  async audit(id, opts = {}) {
    const md = opts.mode; const spec = md ? { id, name: id, segs: [] } : (await import('./data/levels.js')).LEVEL_BY_ID[id]; G.run.begin({ spec }); const W = G.W; const N = W.nav;
    if (!N || !N.enabled) return { id, nav: false };
    N.reach(W.start.x + 1, W.start.z, true); const bad = [];
    const nr = (x, z) => { for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) if (N.isReach(x + dx, z + dz)) return true; return false; };
    const chk = (k, o) => { if ((o.y || 0) > 0.9) return; if (!nr(o.x, o.z)) bad.push(k + '@' + o.x.toFixed(0) + ',' + o.z.toFixed(0) + (o.type ? ':' + o.type : '')); };
    for (const o of W.spawns) chk('spawn', o); for (const o of W.pickups) chk('pick', o); for (const o of W.interactables) chk(o.type, o); if (W.exit) chk('exit', W.exit); for (const o of W.breakables || []) chk('brk', o);
    let map = ''; if (opts.map) { for (let z = -14; z <= 14; z++) { let l = ''; for (let x = opts.map[0]; x < opts.map[1]; x++) { const i = N.idx(x + 0.5, z + 0.5); l += N.blocked[i] ? '#' : N._reach[i] ? '.' : '~'; } map += l + '\n'; } }
    return { id, bad, map };
  },
  /** give the test hero roughly what a normal player owns when reaching level `id` (coins spent on upgrades) */
  loadout(id) {
    const S = Save.d, n = id - 1; S.unlockedStage = Math.max(S.unlockedStage || 1, id); S.level = Math.min(30, 1 + Math.floor(n * 0.9));
    const u = Math.floor(n * 0.33); S.upgrades = { hp: Math.min(12, u), dmg: Math.min(12, u), armor: Math.min(10, Math.floor(u * 0.7)), energy: Math.min(10, Math.floor(u * 0.6)), speed: Math.min(8, Math.floor(u * 0.4)), magnet: 2 };
    const wlv = Math.min(8, 1 + Math.floor(n / 3));
    const give = (k, lv) => { S.items[k] = { lv: Math.min(8, lv) }; };
    S.items.pipe = { lv: wlv }; let prim = 'pipe';
    if (id >= 4) { give('axe', wlv); prim = 'axe'; } if (id >= 8) { give('blade', wlv); prim = 'blade'; } if (id >= 14) { give('sledge', wlv - 1); prim = 'sledge'; } if (id >= 18) { give('spear', wlv - 1); }
    S.equip.primary = prim;
    const abil = []; if (id >= 4) abil.push('orb'); if (id >= 7) abil.push('turret'); if (id >= 10) abil.push('shield'); if (id >= 13) abil.push('chain'); if (id >= 15) abil.push('nova'); if (id >= 17) abil.push('drone');
    for (const a of abil) give(a, wlv - 1);
    S.equip.a1 = abil.includes('shield') ? 'shield' : abil[0] || null; S.equip.a2 = abil.includes('nova') ? 'nova' : abil.includes('chain') ? 'chain' : abil.includes('turret') ? 'turret' : null;
    if (id >= 6) S.titan = true; Save.commit && Save.commit();
  },
  /** run the current level until complete / timeout. returns report */
  async runLevel(id, maxSec = 600, opts = {}) {
    const md = opts.mode; const spec = md ? { id, name: id, segs: [] } : (await import('./data/levels.js')).LEVEL_BY_ID[id];
    if (!opts.keep) { G.run.end && 0; }
    if (md) { this.loadout(opts.level || 12); G.Modes.start(md.key, md); await new Promise(r => setTimeout(r, 200)); this.enable(); G.ui.scr.innerHTML = ''; G.ui.cur = null; }
    else if (opts.progress !== false) { this.loadout(id); G.Player.recompute && G.p && G.Player.recompute(true); }
    if (!md) { G.run.begin({ spec }); G.state = 'play'; this.enable(); G.ui.scr.innerHTML = ''; G.ui.cur = null; }
    let t = 0, last = '', report = { id, name: spec.name, result: 'timeout', time: 0, deaths: 0, objectives: [] };
    const dt = 1 / 60; const checkEvery = 60; let n = 0;
    while (t < maxSec) {
      G.Game.step(dt); t += dt; n++;
      const r = G.run;
      if (r.state === 'complete') { report.result = 'complete'; break; }
      if (r.state === 'dead' && r.failMsg && r.deadT > 1.6) { report.result = 'fail:' + r.failMsg; break; }
      if (n % (opts.logEvery || 600) === 0) { const c = r.current(); const k = c ? c.type + ':' + (c.cur || 0) : 'exit'; this.log.push(`${id} t=${Math.round(t)} obj=${k} hp=${Math.round(G.p.hp)} x=${G.p.x.toFixed(1)} y=${G.p.y.toFixed(1)} z=${G.p.z.toFixed(1)} d=${G.run.stats.deaths} en=${G.enemies.filter(e => !e.dead).length}`); }
    }
    report.time = Math.round(t); report.deaths = G.run.stats.deaths; report.kills = G.run.stats.kills; report.objectives = G.run.objectives.map(o => (o.done ? '✔' : '✘') + o.type); report.pos = { x: +G.p.x.toFixed(1), y: +G.p.y.toFixed(1), z: +G.p.z.toFixed(1) };
    const cur = G.run.current(); if (cur) report.stuckOn = cur.type + ':' + (cur.cur || 0) + '/' + (cur.n || '');
    this.disable(); return report;
  },
};
function goalNear(P, x, z) { return Math.hypot(x - P.x, z - P.z) < 10; }
window.__bot = Bot;
