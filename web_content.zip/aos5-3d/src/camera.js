// Chase camera: side-on 3/4 view, interior zone presets, facade clamp (never ends up inside street walls), shake, cinematic focus.
import { G } from './ctx.js';
import { damp, clamp } from './util.js';
import { Save } from './save.js';
import { Input } from './input.js';

const HALF_PI = Math.PI / 2;
const _q = [];
/** segment (a→b) vs AABB slab test; returns entry t in [0,1] or 2 */
function segBox(ax, ay, az, bx, by, bz, c, pad) {
  let t0 = 0, t1 = 1; const d = [bx - ax, by - ay, bz - az], o = [ax, ay, az], lo = [c.x0 - pad, c.y0 - pad, c.z0 - pad], hi = [c.x1 + pad, c.y1 + pad, c.z1 + pad];
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-6) { if (o[i] < lo[i] || o[i] > hi[i]) return 2; }
    else { let u = (lo[i] - o[i]) / d[i], v = (hi[i] - o[i]) / d[i]; if (u > v) { const t = u; u = v; v = t; } if (u > t0) t0 = u; if (v < t1) t1 = v; if (t0 > t1) return 2; }
  }
  return t0;
}

export const Cam = {
  fx: 0, fy: 0, fz: 0, dist: 12.5, pitch: 0.6, fov: 52, cine: null, init: false,
  yaw: HALF_PI, yawT: HALF_PI, pitchOff: 0, idleT: 0, look: { dx: 0, dy: 0 }, camHeld: 0, tdist: 7.2, third: true,
  isThird() { return Save.d.settings.view !== 'classic'; },
  /** forward / right unit vectors on the ground plane for the current camera heading (game coords) */
  basis() { const y = this.isThird() ? this.yaw : 0; return { fx: Math.sin(y), fz: Math.cos(y), rx: Math.cos(y), rz: -Math.sin(y) }; },
  snap(P) { this.fx = P.x + 2; this.fy = P.y; this.fz = P.z; this.init = true; this.cine = null; this.yaw = this.yawT = HALF_PI; this.pitchOff = 0; this.cpos = null; this.tfx = P.x; this.tfy = P.y; this.tfz = P.z; },
  focusOn(x, y, z, dur, dist = 14, pitch = 0.55) { this.cine = { x, y, z, t: 0, dur, dist, pitch }; },
  clearCine() { this.cine = null; },
  update(dt, P, W, zone, seg) {
    if (this.isThird() && !this.cine) return this.updateThird(dt, P, W, zone, seg);
    this.updateClassic(dt, P, W, zone, seg);
  },
  updateThird(dt, P, W, zone, seg) {
    const st = G.stage; if (!this.init) this.snap(P);
    const sens = (Save.d.settings.camSens || 1);
    // --- manual look (mouse / touch drag / Q-E); auto-recentre toward the level direction after a pause
    const B = G.run && G.run.bossStarted && G.run.boss && !G.run.boss.dead && G.run.state === 'play' ? G.run.boss : null;
    this.camHeld = Input.camDir(); const L = this.look; let moved = false;
    if (L.dx || L.dy) { this.yawT -= L.dx * 0.0042 * sens; this.pitchOff = clamp(this.pitchOff - L.dy * 0.0032 * sens, -0.3, 0.55); L.dx = L.dy = 0; moved = true; }
    if (this.camHeld) { this.yawT += this.camHeld * 2.1 * dt * sens; moved = true; }
    if (moved) this.idleT = 0; else this.idleT += dt;
    const moving = Math.hypot(P.vx || 0, P.vz || 0) > 0.5;
    if (this.idleT > 2.2 && !P.dead && !(G.run && G.run.bossStarted && G.run.boss && !G.run.boss.dead)) { let d = HALF_PI - this.yawT; d = Math.atan2(Math.sin(d), Math.cos(d)); this.yawT += d * Math.min(1, dt * 0.9); this.pitchOff = damp(this.pitchOff, 0, 0.8, dt); }
    if (B && this.idleT > 0.9 && !P.dead) { const want = Math.atan2(B.x - P.x, B.z - P.z); let d = want - this.yawT; d = Math.atan2(Math.sin(d), Math.cos(d)); this.yawT += d * Math.min(1, dt * 3.2); }
    this.yaw = damp(this.yaw, this.yawT, 14, dt);
    let td = 7.0, tp = 0.34 + this.pitchOff, tfov = 60, lift = 1.55;
    if (P.form === 'titan') { td = 11; tfov = 64; lift = 2.8; } else if (P.form === 'mech') { td = 12; tfov = 64; lift = 3.0; }
    if (zone && zone.cam && zone.cam.dist) td = Math.max(P.form === 'titan' ? 8.8 : P.form === 'mech' ? 9.6 : 5.4, Math.min(td, zone.cam.dist * 0.6));
    if (G.run && G.run.bossStarted && G.run.boss && !G.run.boss.dead) { td += 3.2; tp += 0.12; lift += 0.4; }
    this.tdist = damp(this.tdist, td, 3, dt); this.fov = damp(this.fov, tfov, 3, dt); this.pitch = tp;
    // pivot follows the hero (vertical follow is softer so jumps feel grounded)
    this.tfx = damp(this.tfx ?? P.x, P.x, 16, dt); this.tfz = damp(this.tfz ?? P.z, P.z, 16, dt); this.tfy = damp(this.tfy ?? P.y, P.y, 6, dt);
    const sy = Math.sin(this.yaw), cy_ = Math.cos(this.yaw);
    const px = this.tfx + sy * 1.4 * 0, py = this.tfy + lift, pz = this.tfz;
    const h = Math.cos(tp) * this.tdist, v = Math.sin(tp) * this.tdist;
    let wx = px - sy * h, wy = py + v, wz = pz - cy_ * h;
    // camera collision: pull in when a wall / ceiling / prop is between pivot and camera
    let tHit = 1;
    if (W && W.query) { const q = _q; W.query(q, Math.min(px, wx) - 1, Math.min(pz, wz) - 1, Math.max(px, wx) + 1, Math.max(pz, wz) + 1); for (const c of q) { if (!c.enabled || c.los === false || c.cam === false) continue; if (c.y1 < py - 1.2 && c.y1 < wy - 1.0) continue; const t = segBox(px, py, pz, wx, wy, wz, c, 0.25); if (t < tHit) tHit = t; } }
    tHit = Math.max(0.16, tHit - 0.04 / Math.max(0.5, this.tdist)); if (tHit < 1 && this.cpos) tHit = Math.min(tHit, 1);
    const kx = px + (wx - px) * tHit, ky = py + (wy - py) * tHit, kz = pz + (wz - pz) * tHit;
    // smooth the actual camera so wall pop-in is soft (fast when pulled in, slower when releasing)
    if (!this.cpos) this.cpos = { x: kx, y: ky, z: kz };
    const cp = this.cpos; const pulling = Math.hypot(kx - px, kz - pz) < Math.hypot(cp.x - px, cp.z - pz);
    const rate = pulling ? 20 : 5; cp.x = damp(cp.x, kx, rate, dt); cp.y = damp(cp.y, ky, rate, dt); cp.z = damp(cp.z, kz, rate, dt);
    const shk = G.fx.shake, sx = shk > 0 ? (Math.random() - 0.5) * shk * 0.5 : 0, sy2 = shk > 0 ? (Math.random() - 0.5) * shk * 0.5 : 0;
    // aim a little ahead of the hero so the road ahead is visible
    let ax = px + sy * 3.2, az = pz + cy_ * 3.2; const ay = py - 0.35 - Math.sin(tp) * 1.2 + this.pitchOff * 2;
    if (B) { const bd = Math.hypot(B.x - P.x, B.z - P.z), k = Math.min(0.5, 7 / Math.max(1, bd)); ax = P.x + (B.x - P.x) * k; az = P.z + (B.z - P.z) * k; }
    st.camera.fov = this.fov; st.camera.updateProjectionMatrix();
    st.setCamera(cp.x + sx, cp.y + sy2, cp.z, ax, ay, az);
    this.fx = px; this.fy = this.tfy; this.fz = pz; this.pos = { x: cp.x, y: cp.y, z: cp.z };
  },
  updateClassic(dt, P, W, zone, seg) {
    const st = G.stage; if (!this.init) this.snap(P);
    this.cpos = null; this.yaw = this.yawT = HALF_PI; this.tfx = P.x; this.tfy = P.y; this.tfz = P.z; this.look.dx = this.look.dy = 0;
    let td = 13.2, tp = 0.78, tfov = 52; if (zone && zone.cam) { td = zone.cam.dist; tp = zone.cam.pitch; }
    if (P.form === 'titan') { td *= 1.15; tfov = 56; } else if (P.form === 'mech') { td *= 1.3; tfov = 56; }
    let tx = P.x + (P.form === 'hero' ? 2.2 : 3), ty = P.y, tz = P.z * 0.85;
    if (this.cine) { const c = this.cine; c.t += dt; tx = c.x; ty = c.y; tz = c.z; td = c.dist; tp = c.pitch; if (c.t > c.dur) this.cine = null; }
    const k = this.cine ? 3 : 7;
    this.fx = damp(this.fx, tx, k, dt); this.fz = damp(this.fz, tz, k, dt); this.fy = damp(this.fy, ty, 5, dt);
    this.dist = damp(this.dist, td, 3, dt); this.pitch = damp(this.pitch, tp, 3, dt); this.fov = damp(this.fov, tfov, 3, dt);
    const h = Math.cos(this.pitch) * this.dist; let v = Math.sin(this.pitch) * this.dist;
    let cz = this.fz - h, cy = this.fy + v + 1.0;
    // keep camera inside the street (south facades are tall solid blocks)
    if (!zone && !W.void) { const hw = seg && seg.hw ? seg.hw : 8; const zmin = -(hw + 2.0); if (cz < zmin) { const over = zmin - cz; cz = zmin; cy += over * 0.9; } }
    const sh = G.fx.shake, sx = sh > 0 ? (Math.random() - 0.5) * sh * 0.5 : 0, sy = sh > 0 ? (Math.random() - 0.5) * sh * 0.5 : 0;
    const lookY = this.fy + 1.0;
    st.camera.fov = this.fov; st.camera.updateProjectionMatrix();
    st.setCamera(this.fx + sx, cy + sy, cz, this.fx + sx * 0.3, lookY, this.fz);
    this.pos = { x: this.fx, y: cy, z: cz };
  },
};
