// Articulated 3D "stick-style" character rig: head, torso, shoulders, upper/fore arms, hands, pelvis, thighs, shins, feet.
// Every joint is a real pivot (THREE.Group), animated procedurally (locomotion + keyframed actions).
import * as THREE from 'three';
import { toon } from './materials.js';
import { clamp, damp, smooth, TAU } from './util.js';
import { G } from './ctx.js';
import { buildWeaponMesh } from './weaponmodels.js';

const FIELDS = ['y', 'lean', 'twist', 'roll', 'headX', 'headY', 'Lsf', 'Lsa', 'Lel', 'Rsf', 'Rsa', 'Rel', 'Lhf', 'Lkn', 'Rhf', 'Rkn', 'pitch', 'sideRoll'];
export const Z = () => ({ y: 0, lean: 0, twist: 0, roll: 0, headX: 0, headY: 0, Lsf: 0, Lsa: 0.12, Lel: 0.25, Rsf: 0, Rsa: 0.12, Rel: 0.25, Lhf: 0, Lkn: 0.05, Rhf: 0, Rkn: 0.05, pitch: 0, sideRoll: 0 });
export const P = (o) => Object.assign(Z(), o);

const OUTLINE_MAT = new THREE.MeshBasicMaterial({ color: 0x07080c, side: THREE.BackSide });
const geoCache = {};
function capsule(r, L) { // total length L between joints
  const k = `c${r.toFixed(3)}_${L.toFixed(3)}`;
  return geoCache[k] || (geoCache[k] = new THREE.CapsuleGeometry(r, Math.max(0.001, L - 2 * r), 3, 8));
}
function box(w, h, d) { const k = `b${w.toFixed(3)}_${h.toFixed(3)}_${d.toFixed(3)}`; return geoCache[k] || (geoCache[k] = new THREE.BoxGeometry(w, h, d)); }
function sphere(r, ws = 12, hs = 9) { const k = `s${r.toFixed(3)}_${ws}`; return geoCache[k] || (geoCache[k] = new THREE.SphereGeometry(r, ws, hs)); }
function cyl(rt, rb, h, seg = 8) { const k = `y${rt.toFixed(3)}_${rb.toFixed(3)}_${h.toFixed(3)}_${seg}`; return geoCache[k] || (geoCache[k] = new THREE.CylinderGeometry(rt, rb, h, seg)); }
function cone(r, h, seg = 6) { const k = `n${r.toFixed(3)}_${h.toFixed(3)}_${seg}`; return geoCache[k] || (geoCache[k] = new THREE.ConeGeometry(r, h, seg)); }

export class Rig {
  constructor(style) {
    this.style = style;
    const st = this.st = Object.assign({
      scale: 1, limbR: 0.052, headR: 0.2, torsoLen: 0.58, thigh: 0.46, shin: 0.46, upper: 0.34, fore: 0.33,
      shoulderW: 0.19, hipW: 0.1, torsoW: 0.085, shape: 'cap', gait: 'normal', extras: [],
      skin: 0x2c2f3a, cloth: 0x2c2f3a, pants: 0x242731, limb: 0x2c2f3a, accent: 0xd8262b, dark: 0x16181f, rim: 0x6fa0ff, eyes: null,
    }, style);
    this.root = new THREE.Group();
    this.root.name = 'rig_' + (st.id || 'x');
    this.mats = [];
    const mk = (c, o) => { const m = toon(c, { rim: st.rim, ...o }); this.mats.push(m); return m; };
    this.mSkin = mk(st.skin); this.mCloth = mk(st.cloth); this.mPants = mk(st.pants); this.mLimb = mk(st.limb);
    this.mAcc = mk(st.accent); this.mDark = mk(st.dark);
    this.mGlow = new THREE.MeshBasicMaterial({ color: st.eyes || 0xffffff });
    this.meshes = []; this.outlines = [];
    const S = st.scale; this.S = S;
    const legLen = st.thigh + st.shin;
    this.legLen = legLen * S;

    // ---- hierarchy ----
    this.body = new THREE.Group(); this.body.scale.setScalar(S); this.root.add(this.body); // scaled container
    this.hips = new THREE.Group(); this.hips.position.y = legLen; this.body.add(this.hips);
    this.baseHipY = legLen;
    this.torso = new THREE.Group(); this.hips.add(this.torso);
    const pelvisR = st.hipW * 1.25;
    this._add(this.hips, st.shape === 'box' ? box(st.hipW * 2.6, 0.16, 0.18) : sphere(pelvisR), this.mPants, 0, 0, 0);

    // torso
    const tl = st.torsoLen;
    this._add(this.torso, st.shape === 'box' ? box(st.torsoW * 2.8, tl, st.torsoW * 2.4) : capsule(st.torsoW, tl), this.mCloth, 0, tl / 2, 0);
    // head
    this.headG = new THREE.Group(); this.headG.position.y = tl + 0.03; this.torso.add(this.headG);
    this._add(this.headG, sphere(st.headR, 14, 10), this.mSkin, 0, st.headR * 0.92, 0);
    this.headTopY = tl + 0.03 + st.headR * 1.92;
    // arms
    this.arms = {};
    for (const side of ['L', 'R']) {
      const sx = side === 'L' ? 1 : -1;
      const sh = new THREE.Group(); sh.position.set(sx * st.shoulderW, tl - 0.05, 0); this.torso.add(sh);
      this._add(sh, sphere(st.limbR * 1.5), this.mLimb, 0, 0, 0);
      this._limb(sh, st.upper, this.mLimb, st);
      const el = new THREE.Group(); el.position.y = -st.upper; sh.add(el);
      this._add(el, sphere(st.limbR * 1.25), this.mLimb, 0, 0, 0);
      this._limb(el, st.fore, this.mLimb, st);
      const hand = new THREE.Group(); hand.position.y = -st.fore; el.add(hand);
      const handMesh = this._add(hand, sphere(st.limbR * 1.65, 8, 6), this.mSkin, 0, -0.02, 0);
      this.arms[side] = { sh, el, hand, handMesh, sx };
    }
    // legs
    this.legs = {};
    for (const side of ['L', 'R']) {
      const sx = side === 'L' ? 1 : -1;
      const hp = new THREE.Group(); hp.position.set(sx * st.hipW, -0.02, 0); this.hips.add(hp);
      this._add(hp, sphere(st.limbR * 1.35), this.mPants, 0, 0, 0);
      this._limb(hp, st.thigh, this.mPants, st);
      const kn = new THREE.Group(); kn.position.y = -st.thigh; hp.add(kn);
      this._add(kn, sphere(st.limbR * 1.2), this.mPants, 0, 0, 0);
      this._limb(kn, st.shin, this.mLimb, st);
      const foot = new THREE.Group(); foot.position.y = -st.shin; kn.add(foot);
      const fm = this._add(foot, box(st.limbR * 2.4, 0.07, 0.25), this.mDark, 0, -0.01, 0.07);
      this.legs[side] = { hp, kn, foot, fm, sx };
    }
    this.mount = new THREE.Group(); this.arms.R.hand.add(this.mount);
    this.mount.position.y = -0.02;
    this.weaponPivot = new THREE.Group(); this.mount.add(this.weaponPivot);
    this.weaponId = null; this.weaponMesh = null;
    this.tails = [];
    this.spinners = [];
    this._extras(st);

    // ---- animation state ----
    this.cur = Z(); this.tgt = Z();
    this.phase = 0; this.t = 0; this.speed = 0; this.air = 0; this.vy = 0;
    this.action = null; this.actT = 0; this.hold = null; this.holdT = 0;
    this.flashT = 0; this.flashCol = new THREE.Color(1, 1, 1);
    this.blend = 12; this.lodSkip = 0; this._skipCtr = 0; this.rest = null;
    this.armed = false; this.armPose = null;
    this.setOutline(G.fx ? G.fx.outline : true);
  }

  _add(parent, geo, mat, x, y, z) {
    const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z);
    m.castShadow = true; parent.add(m); this.meshes.push(m);
    if (this.outlineOn) this._addOutline(m);
    return m;
  }
  _limb(parent, L, mat, st) {
    const r = st.limbR;
    const g = st.shape === 'box' ? box(r * 2.2, L, r * 2.2) : capsule(r, L);
    return this._add(parent, g, mat, 0, -L / 2, 0);
  }
  _addOutline(m) {
    const o = new THREE.Mesh(m.geometry, OUTLINE_MAT); o.scale.setScalar(1.09); o.userData.outline = true;
    m.add(o); this.outlines.push(o);
  }
  setOutline(on) {
    this.outlineOn = !!on;
    if (on && !this.outlines.length) for (const m of this.meshes.slice()) this._addOutline(m);
    for (const o of this.outlines) o.visible = !!on;
  }

  _extras(st) {
    const ex = st.extras || [];
    const H = st.headR, tl = st.torsoLen;
    const A = this.mAcc, D = this.mDark, C = this.mCloth;
    const hg = this.headG, hy = H * 0.92;
    const add = (p, g, m, x, y, z, rot) => { const mesh = this._add(p, g, m, x, y, z); if (rot) mesh.rotation.set(...rot); return mesh; };
    if (st.eyes) {
      for (const sx of [-1, 1]) { const e = new THREE.Mesh(sphere(H * 0.17, 8, 6), this.mGlow); e.position.set(sx * H * 0.36, hy + H * 0.08, H * 0.86); hg.add(e); }
    }
    for (const x of ex) {
      switch (x) {
        case 'headband': {
          const t = add(hg, new THREE.TorusGeometry(H * 1.02, H * 0.09, 6, 16), A, 0, hy + H * 0.2, 0, [Math.PI / 2, 0, 0]);
          for (let i = 0; i < 2; i++) { const tail = new THREE.Group(); tail.position.set(0, hy + H * 0.2, -H); hg.add(tail); const m = this._add(tail, box(H * 0.28, H * 0.12, H * 1.5), A, (i ? 1 : -1) * H * 0.15, 0, -H * 0.7); this.tails.push({ g: tail, k: i, len: 1 }); }
          break; }
        case 'scarf': {
          const g = new THREE.Group(); g.position.set(0, tl - 0.02, -0.02); this.torso.add(g);
          add(g, new THREE.TorusGeometry(st.torsoW * 1.35, st.torsoW * 0.5, 6, 12), A, 0, 0.04, 0.0, [Math.PI / 2, 0, 0]);
          let parent = g; for (let i = 0; i < 4; i++) { const seg = new THREE.Group(); seg.position.set(0, i === 0 ? 0.0 : 0, i === 0 ? -0.07 : -0.17); parent.add(seg); this._add(seg, box(0.16, 0.035, 0.2), A, 0, 0, -0.1); parent = seg; this.tails.push({ g: seg, k: i, scarf: true }); }
          break; }
        case 'helmet': add(hg, new THREE.SphereGeometry(H * 1.14, 14, 9, 0, TAU, 0, Math.PI * 0.58), D, 0, hy + H * 0.05, 0); break;
        case 'visor': add(hg, box(H * 1.35, H * 0.34, H * 0.4), this.mGlow, 0, hy + H * 0.12, H * 0.78); break;
        case 'hood': add(hg, new THREE.SphereGeometry(H * 1.16, 14, 10, 0, TAU, 0, Math.PI * 0.72), C, 0, hy + H * 0.04, -H * 0.06); break;
        case 'hair': for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU; add(hg, cone(H * 0.2, H * 0.8, 5), this.mDark, Math.cos(a) * H * 0.55, hy + H * 0.8, Math.sin(a) * H * 0.55, [Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5]); } break;
        case 'goggles': add(hg, new THREE.TorusGeometry(H * 1.0, H * 0.07, 5, 14), D, 0, hy + H * 0.15, 0, [Math.PI / 2, 0, 0]);
          for (const sx of [-1, 1]) add(hg, cyl(H * 0.3, H * 0.3, H * 0.2, 10), this.mGlow, sx * H * 0.42, hy + H * 0.15, H * 0.85, [Math.PI / 2, 0, 0]); break;
        case 'antenna': add(hg, cyl(H * 0.05, H * 0.05, H * 1.1, 5), D, 0, hy + H * 1.5, 0); add(hg, sphere(H * 0.14, 8, 6), A, 0, hy + H * 2.1, 0); break;
        case 'horns': for (const sx of [-1, 1]) add(hg, cone(H * 0.18, H * 0.75, 5), this.mAcc, sx * H * 0.62, hy + H * 0.85, 0, [0, 0, -sx * 0.5]); break;
        case 'shoulderPads': for (const sx of [-1, 1]) add(this.torso, sphere(0.14, 10, 7), D, sx * st.shoulderW * 1.05, tl - 0.03, 0).scale.set(1, 0.7, 1); break;
        case 'bigPads': for (const sx of [-1, 1]) add(this.torso, box(0.24, 0.12, 0.3), D, sx * (st.shoulderW + 0.05), tl + 0.02, 0, [0, 0, sx * 0.15]); break;
        case 'chestPlate': add(this.torso, box(st.torsoW * 3.2, tl * 0.7, st.torsoW * 1.0), D, 0, tl * 0.55, st.torsoW * 1.0); break;
        case 'core': add(this.torso, sphere(0.09, 10, 8), this.mGlow, 0, tl * 0.62, st.torsoW * 1.35); break;
        case 'cross': add(this.torso, box(0.15, 0.04, 0.02), this.mGlow, 0, tl * 0.6, st.torsoW * 1.2); add(this.torso, box(0.04, 0.15, 0.02), this.mGlow, 0, tl * 0.6, st.torsoW * 1.2); break;
        case 'belt': add(this.hips, cyl(st.torsoW * 1.45, st.torsoW * 1.45, 0.07, 10), A, 0, 0.07, 0); break;
        case 'spikes': for (let i = 0; i < 5; i++) add(this.torso, cone(0.045, 0.22, 5), D, 0, tl * (0.25 + i * 0.16), -st.torsoW * 1.1, [-Math.PI / 2 - 0.2, 0, 0]); break;
        case 'bigFists': for (const s of ['L', 'R']) this.arms[s].handMesh.scale.setScalar(1.6); break;
        case 'bigArmR': this.arms.R.sh.scale.set(1.5, 1.1, 1.5); this.arms.R.handMesh.scale.setScalar(1.5); break;
        case 'claws': for (const s of ['L', 'R']) for (let i = -1; i <= 1; i++) add(this.arms[s].hand, cone(0.018, 0.17, 4), this.mGlow, i * 0.035, -0.17, 0.0, [Math.PI, 0, 0]); break;
        case 'backpack': add(this.torso, box(0.26, 0.36, 0.14), D, 0, tl * 0.6, -st.torsoW * 1.8); break;
        case 'cannonR': { const c = add(this.arms.R.el, cyl(0.075, 0.09, 0.4, 8), D, 0, -st.fore * 0.6, 0.0); c.rotation.x = 0; add(this.arms.R.el, cyl(0.04, 0.04, 0.18, 8), this.mGlow, 0, -st.fore - 0.12, 0); break; }
        case 'shield': add(this.arms.L.el, box(0.07, 0.62, 0.46), D, 0.12, -st.fore * 0.5, 0.05); add(this.arms.L.el, box(0.075, 0.5, 0.34), A, 0.14, -st.fore * 0.5, 0.05); break;
        case 'cape': { const g = new THREE.Group(); g.position.set(0, tl - 0.02, -st.torsoW * 1.2); this.torso.add(g); this._add(g, box(0.5, 0.78, 0.03), A, 0, -0.4, -0.04); this.tails.push({ g, k: 0, cape: true }); break; }
        case 'coat': add(this.hips, cyl(st.torsoW * 1.6, st.torsoW * 2.6, 0.42, 10), C, 0, -0.14, 0); break;
        case 'bandolier': add(this.torso, box(st.torsoW * 3.0, 0.05, st.torsoW * 2.7), A, 0, tl * 0.55, 0, [0, 0, 0.7]); break;
        case 'gloves': for (const s of ['L', 'R']) this.arms[s].handMesh.material = this.mAcc; break;
        case 'jaw': add(hg, box(H * 1.1, H * 0.22, H * 0.6), D, 0, hy - H * 0.62, H * 0.45); break;
        case 'shards': for (let i = 0; i < 5; i++) { const s = new THREE.Mesh(new THREE.OctahedronGeometry(0.16), this.mGlow); s.userData.i = i; this.body.add(s); this.spinners.push(s); } break;
        case 'halo': { const r = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.025, 6, 24), this.mGlow); r.rotation.x = Math.PI / 2; r.position.y = this.headTopY + 0.2; this.body.add(r); this.spinners.push(r); r.userData.halo = true; break; }
        case 'flameAura': { this.aura = new THREE.Mesh(new THREE.RingGeometry(0.45, 0.75, 24), new THREE.MeshBasicMaterial({ color: st.auraColor || 0x55ccff, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending })); this.aura.rotation.x = -Math.PI / 2; this.aura.position.y = 0.03; this.root.add(this.aura); break; }
        default: break;
      }
    }
  }

  setWeapon(id) {
    if (id === this.weaponId) return;
    this.weaponId = id;
    if (this.weaponMesh) { this.weaponPivot.remove(this.weaponMesh); this.weaponMesh = null; }
    if (!id) { this.armed = false; return; }
    const w = buildWeaponMesh(id);
    if (!w) { this.armed = false; return; }
    this.weaponMesh = w.mesh; this.weaponPivot.add(w.mesh);
    this.weaponPivot.rotation.set(Math.PI - (w.tilt || 0.9), 0, 0);
    this.weaponMesh.traverse(o => { if (o.isMesh) o.castShadow = true; });
    this.armed = true; this.aimStyle = w.aim || 'melee';
  }

  setVisible(v) { this.root.visible = v; }
  flash(color = 0xffffff, dur = 0.14) { this.flashT = dur; this.flashDur = dur; this.flashCol.set(color); }

  /** start a keyframed action (attack, hurt, roll, ...) */
  act(name, dur, opts = {}) {
    const def = ACT[name]; if (!def) return;
    this.action = { name, keys: def.keys, dur: dur || def.dur, rate: opts.rate || def.rate || 24, hold: opts.hold ?? def.hold, ease: def.ease };
    this.actT = 0; this.hold = null;
  }
  endAction() { this.action = null; }
  /** persistent pose (down / cheer / block...) */
  setHold(name) { this.hold = name; this.holdT = 0; this.action = null; }
  get busy() { return !!this.action && this.actT < this.action.dur; }

  update(dt) {
    if (!this.root.visible) return;
    if (this.lodSkip) { this._skipCtr = (this._skipCtr + 1) % (this.lodSkip + 1); if (this._skipCtr) return; dt *= (this.lodSkip + 1); }
    this.t += dt;
    const st = this.st, c = this.cur;
    let tgt, rate = this.blend, direct = null;
    if (this.action) {
      const a = this.action; this.actT += dt;
      const u = clamp(this.actT / a.dur, 0, 1);
      tgt = sampleKeys(a.keys, u);
      rate = a.rate;
      if (this.actT >= a.dur) { if (a.hold) { /* stay on last pose */ } else this.action = null; }
      direct = tgt;
    } else if (this.hold) {
      this.holdT += dt; tgt = HOLD[this.hold] ? HOLD[this.hold](this, this.holdT) : Z(); rate = 14; direct = tgt;
    } else {
      tgt = this._loco(dt);
    }
    // smoothed fields
    const k = 1 - Math.exp(-rate * dt);
    for (const f of FIELDS) {
      if (f === 'pitch' || f === 'sideRoll') c[f] = (this.action || this.hold) ? damp(c[f], tgt[f], rate * 0.8, dt) : damp(c[f], tgt[f], 14, dt);
      else c[f] += (tgt[f] - c[f]) * k;
    }
    this._apply(dt);
  }

  _loco(dt) {
    const st = this.st, p = Z();
    const sp = this.speed;
    const run = smooth(clamp((sp - 2.6) / 3.2, 0, 1));
    const moving = sp > 0.25;
    if (moving) this.phase += dt * clamp(sp * 1.55, 0, 17);
    const ph = this.phase, s = Math.sin(ph), cs = Math.cos(ph);
    const g = st.gait;
    const armed = this.armed;
    if (this.air !== 0 && g !== 'float') {
      if (this.air > 0) { p.Lhf = 0.7; p.Lkn = 1.0; p.Rhf = -0.3; p.Rkn = 0.5; p.Lsf = 1.9; p.Rsf = armed ? 1.0 : 1.9; p.Lsa = 0.5; p.Rsa = 0.5; p.Lel = 0.5; p.Rel = armed ? 1.0 : 0.5; p.lean = 0.12; p.y = 0.04; }
      else { p.Lhf = 0.4; p.Lkn = 0.3; p.Rhf = -0.25; p.Rkn = 0.8; p.Lsf = 0.8; p.Rsf = 0.8; p.Lsa = 1.2; p.Rsa = 1.2; p.Lel = 0.4; p.Rel = 0.4; p.lean = 0.05; }
      if (g === 'shamble' || g === 'lunge') { p.Lsf = 1.6; p.Rsf = 1.6; p.Lsa = 0.3; p.Rsa = 0.3; }
      return p;
    }
    switch (g) {
      case 'shamble': {
        const a = moving ? 1 : 0.15;
        p.lean = 0.28 + (moving ? 0.1 : 0); p.headX = 0.25 + 0.1 * Math.sin(this.t * 1.7); p.headY = 0.2 * Math.sin(this.t * 1.1);
        p.Lsf = 1.35 + 0.15 * s; p.Rsf = 1.25 - 0.15 * s; p.Lel = 0.15; p.Rel = 0.2; p.Lsa = 0.15; p.Rsa = 0.15;
        p.Lhf = s * 0.45 * a; p.Rhf = -s * 0.45 * a; p.Lkn = (0.1 + Math.max(0, cs) * 0.5) * a; p.Rkn = (0.1 + Math.max(0, -cs) * 0.5) * a;
        p.twist = 0.18 * s * a; p.roll = 0.1 * Math.sin(this.t * 1.3); p.y = -0.04 - 0.03 * Math.abs(s) * a;
        if (!moving) { p.Lsf = 1.1 + 0.05 * Math.sin(this.t * 1.4); p.Rsf = 1.0; }
        break; }
      case 'lunge': {
        const a = moving ? 1 : 0.2;
        p.lean = 0.5 + 0.35 * run; p.headX = -0.35; p.y = -0.12 - 0.04 * Math.abs(s) * a;
        p.Lsf = 1.2 + 1.1 * s * a; p.Rsf = 1.2 - 1.1 * s * a; p.Lel = 0.5; p.Rel = 0.5; p.Lsa = 0.4; p.Rsa = 0.4;
        p.Lhf = s * 1.05 * a; p.Rhf = -s * 1.05 * a; p.Lkn = (0.25 + Math.max(0, cs) * 1.3) * a; p.Rkn = (0.25 + Math.max(0, -cs) * 1.3) * a; p.twist = 0.22 * s * a;
        if (!moving) { p.Lsf = 0.9 + 0.1 * Math.sin(this.t * 3); p.Rsf = 0.9; p.lean = 0.35; }
        break; }
      case 'heavy': {
        const a = moving ? 1 : 0;
        p.y = -0.03 - 0.05 * Math.abs(s) * a + 0.012 * Math.sin(this.t * 2); p.lean = 0.08 + 0.04 * a; p.roll = 0.05 * s * a; p.twist = 0.12 * s * a;
        p.Lsf = -s * 0.5 * a; p.Rsf = s * 0.5 * a; p.Lsa = 0.45; p.Rsa = 0.45; p.Lel = 0.5; p.Rel = 0.5;
        p.Lhf = s * 0.55 * a; p.Rhf = -s * 0.55 * a; p.Lkn = Math.max(0, cs) * 0.5 * a + 0.05; p.Rkn = Math.max(0, -cs) * 0.5 * a + 0.05;
        if (armed) { p.Rsf = 0.5; p.Rel = 1.0; }
        break; }
      case 'robot': {
        const a = moving ? 1 : 0;
        p.y = -0.02 * Math.abs(s) * a; p.lean = 0.06; p.twist = 0.08 * s * a;
        p.Lsf = -s * 0.5 * a + 0.2; p.Rsf = s * 0.5 * a + 0.2; p.Lel = 0.7; p.Rel = 0.7; p.Lsa = 0.15; p.Rsa = 0.15;
        p.Lhf = s * 0.55 * a; p.Rhf = -s * 0.55 * a; p.Lkn = Math.max(0, cs) * 0.4 * a; p.Rkn = Math.max(0, -cs) * 0.4 * a;
        p.headY = 0.25 * Math.sin(this.t * 0.9) * (moving ? 0.2 : 1);
        break; }
      case 'float': {
        p.y = 0.25 + 0.08 * Math.sin(this.t * 2); p.lean = 0.1 + 0.1 * run; p.Lhf = 0.2; p.Rhf = -0.15; p.Lkn = 0.4; p.Rkn = 0.5;
        p.Lsf = 0.5 + 0.2 * Math.sin(this.t * 1.5); p.Rsf = 0.5 + 0.2 * Math.sin(this.t * 1.5 + 1); p.Lsa = 0.9; p.Rsa = 0.9; p.Lel = 0.5; p.Rel = 0.5; p.headX = 0.1;
        break; }
      default: { // 'normal' stick-hero gait
        const a = moving ? 1 : 0;
        const legAmp = (0.5 + 0.55 * run) * a, armAmp = (0.45 + 0.6 * run) * a;
        p.y = (moving ? -0.045 * (0.5 + run) * Math.abs(s) : 0.01 * Math.sin(this.t * 2.2) - 0.005) + (moving ? 0 : 0);
        p.lean = 0.04 + 0.2 * run * a; p.twist = 0.15 * s * a * (0.5 + run); p.headX = -0.04 * run;
        p.Lhf = s * legAmp; p.Rhf = -s * legAmp;
        p.Lkn = (0.08 + Math.max(0, cs) * (0.7 + 0.9 * run)) * a + 0.05; p.Rkn = (0.08 + Math.max(0, -cs) * (0.7 + 0.9 * run)) * a + 0.05;
        p.Lsf = -s * armAmp; p.Rsf = s * armAmp;
        p.Lel = 0.25 + 0.9 * run * a + 0.25 * Math.max(0, s) * a; p.Rel = 0.25 + 0.9 * run * a + 0.25 * Math.max(0, -s) * a;
        p.Lsa = 0.1; p.Rsa = 0.1;
        if (!moving) { p.Lsf = 0.05 * Math.sin(this.t * 2.1); p.Rsf = 0.05 * Math.sin(this.t * 2.1 + 1); p.Lel = 0.3; p.Rel = 0.3; p.headX = 0.02 * Math.sin(this.t * 1.3); }
      }
    }
    if (armed && g !== 'shamble' && g !== 'lunge') { // ready stance holding the weapon
      const mv = moving ? (0.3 + 0.2 * Math.sin(this.phase * 2)) : 0.02 * Math.sin(this.t * 2);
      p.Rsf = (this.aimStyle === 'melee' ? 0.55 : 1.2) + mv * 0.3; p.Rel = this.aimStyle === 'melee' ? 1.05 : 0.2; p.Rsa = 0.25;
      if (this.aimStyle !== 'melee') { p.Lsf = 1.0; p.Lel = 0.9; p.Lsa = 0.15; p.twist += -0.25; }
      else { p.Lsf = Math.max(p.Lsf * 0.5, 0.4); p.Lel = 1.2; p.Lsa = 0.25; p.twist += 0.1; }
    }
    if (this.rest) Object.assign(p, this.rest);
    return p;
  }

  _apply(dt) {
    const c = this.cur, A = this.arms, L = this.legs;
    this.hips.position.y = this.baseHipY + c.y;
    this.hips.rotation.set(-c.pitch, 0, c.sideRoll);
    this.torso.rotation.set(-c.lean, c.twist, c.roll);
    this.headG.rotation.set(-c.headX - c.lean * -0.3, c.headY, 0);
    A.L.sh.rotation.set(-c.Lsf, 0, c.Lsa); A.R.sh.rotation.set(-c.Rsf, 0, -c.Rsa);
    A.L.el.rotation.x = -c.Lel; A.R.el.rotation.x = -c.Rel;
    L.L.hp.rotation.x = -c.Lhf; L.R.hp.rotation.x = -c.Rhf;
    L.L.kn.rotation.x = c.Lkn; L.R.kn.rotation.x = c.Rkn;
    // feet stay roughly flat
    L.L.foot.rotation.x = -(L.L.hp.rotation.x + L.L.kn.rotation.x) * 0.5; L.R.foot.rotation.x = -(L.R.hp.rotation.x + L.R.kn.rotation.x) * 0.5;
    // cloth tails (scarf / headband / cape)
    const sp = this.speed, t = this.t;
    for (const T of this.tails) {
      if (T.scarf) T.g.rotation.x = -0.12 - 0.05 * sp * (T.k ? 0.3 : 0.5) * 0 + 0.25 * Math.sin(t * 6 + T.k * 1.2) * (0.3 + sp * 0.12) + (T.k === 0 ? 0.3 : 0.12);
      else if (T.cape) T.g.rotation.x = 0.15 + clamp(sp * 0.06, 0, 0.5) + 0.06 * Math.sin(t * 4);
      else T.g.rotation.x = 0.25 + 0.3 * Math.sin(t * 7 + T.k * 2) * (0.3 + sp * 0.08) + clamp(sp * 0.04, 0, 0.35);
    }
    for (const s of this.spinners) {
      if (s.userData.halo) { s.rotation.z += dt * 1.5; continue; }
      const a = t * 1.6 + s.userData.i * (TAU / 5); s.position.set(Math.cos(a) * 0.9, 1.5 + Math.sin(t * 2 + s.userData.i) * 0.2, Math.sin(a) * 0.9); s.rotation.y += dt * 3;
    }
    if (this.aura) { const k = 1 + 0.12 * Math.sin(t * 8); this.aura.scale.set(k, k, 1); }
    if (this.flashT > 0) {
      this.flashT -= dt; const k = clamp(this.flashT / (this.flashDur || 0.14), 0, 1);
      for (const m of this.mats) { m.emissive.copy(this.flashCol).multiplyScalar(k * 0.9); m.emissiveIntensity = 1; }
      if (this.flashT <= 0) for (const m of this.mats) m.emissive.setScalar(0);
    }
  }
  snap() { this.cur = Object.assign(Z(), this._loco(0.016)); this._apply(0.016); }
  dispose() { for (const m of this.mats) m.dispose(); this.mGlow.dispose(); }
}

function sampleKeys(keys, u) {
  if (u <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (u <= keys[i][0]) {
      const a = keys[i - 1], b = keys[i]; const k = smooth((u - a[0]) / Math.max(1e-5, b[0] - a[0]));
      const out = {}; for (const f of FIELDS) out[f] = a[1][f] + (b[1][f] - a[1][f]) * k; return out;
    }
  }
  return keys[keys.length - 1][1];
}

// ---------- keyframed actions: [normalizedTime, pose] ----------
const base = {};
export const ACT = {
  swingR: { dur: 0.42, keys: [[0, P({ Rsf: 0.6, Rel: 1.0 })], [0.32, P({ twist: -1.05, Rsf: 1.15, Rsa: 0.95, Rel: 0.55, lean: 0.05, Lsf: 0.5, Lel: 1.2, Lhf: -0.3, Rhf: 0.35 })], [0.46, P({ twist: 0.95, Rsf: 1.45, Rsa: -0.1, Rel: 0.2, lean: 0.3, Lsf: 0.2, Lel: 1.0, Lhf: 0.5, Rhf: -0.4, Lkn: 0.5 })], [0.7, P({ twist: 0.9, Rsf: 1.35, Rsa: 0, Rel: 0.2, lean: 0.25, Lhf: 0.45, Rhf: -0.35 })], [1, P({ Rsf: 0.6, Rel: 1.0 })]] },
  swingL: { dur: 0.42, keys: [[0, P({ Rsf: 0.6, Rel: 1.0 })], [0.32, P({ twist: 0.95, Rsf: 1.3, Rsa: -0.2, Rel: 0.4, lean: 0.05, Lhf: 0.35, Rhf: -0.3 })], [0.46, P({ twist: -1.05, Rsf: 1.35, Rsa: 1.0, Rel: 0.25, lean: 0.3, Lhf: -0.4, Rhf: 0.5, Rkn: 0.5 })], [0.7, P({ twist: -0.95, Rsf: 1.3, Rsa: 0.9, Rel: 0.3, lean: 0.25 })], [1, P({ Rsf: 0.6, Rel: 1.0 })]] },
  overhead: { dur: 0.6, keys: [[0, P({ Rsf: 0.6, Rel: 1.0 })], [0.38, P({ Rsf: 2.9, Rel: 0.7, Lsf: 2.4, Lel: 0.8, lean: -0.25, headX: 0.2, y: 0.02, Lhf: -0.2, Rhf: 0.3 })], [0.5, P({ Rsf: 0.9, Rel: 0.1, Lsf: 0.8, Lel: 0.3, lean: 0.6, y: -0.18, Lhf: 0.7, Rhf: -0.5, Lkn: 0.9, Rkn: 0.4, headX: -0.2 })], [0.75, P({ Rsf: 0.85, Rel: 0.1, lean: 0.55, y: -0.16, Lhf: 0.6, Rhf: -0.45, Lkn: 0.8 })], [1, P({ Rsf: 0.6, Rel: 1.0 })]] },
  slamGround: { dur: 0.9, keys: [[0, P({ Rsf: 0.6, Rel: 1.0 })], [0.45, P({ Rsf: 3.0, Rel: 0.4, Lsf: 3.0, Lel: 0.4, lean: -0.35, y: 0.06, headX: 0.3 })], [0.55, P({ Rsf: 0.5, Rel: 0.05, Lsf: 0.5, Lel: 0.05, lean: 0.95, y: -0.32, Lhf: 0.9, Rhf: -0.2, Lkn: 1.1, Rkn: 0.6, headX: -0.4 })], [0.8, P({ Rsf: 0.5, Rel: 0.05, lean: 0.9, y: -0.3, Lhf: 0.85, Lkn: 1.0, Rkn: 0.6 })], [1, P({ Rsf: 0.6, Rel: 1.0 })]] },
  stab: { dur: 0.4, keys: [[0, P({ Rsf: 0.6, Rel: 1.0 })], [0.34, P({ Rsf: 0.7, Rel: 1.9, twist: -0.55, lean: -0.12, Lhf: -0.35, Rhf: 0.35, Lsf: 0.6, Lel: 1.0 })], [0.5, P({ Rsf: 1.55, Rel: 0.05, twist: 0.35, lean: 0.4, Lhf: 0.85, Lkn: 0.4, Rhf: -0.55, Lsf: 0.3, Lel: 1.2 })], [0.75, P({ Rsf: 1.5, Rel: 0.1, twist: 0.3, lean: 0.35, Lhf: 0.8, Rhf: -0.5 })], [1, P({ Rsf: 0.6, Rel: 1.0 })]] },
  sweep: { dur: 0.6, keys: [[0, P({ Rsf: 0.6, Rel: 1.0 })], [0.35, P({ twist: -1.3, Rsf: 1.3, Rsa: 0.5, Rel: 0.3, Lsf: 1.1, Lel: 0.5, lean: 0.2, Lhf: -0.3, Rhf: 0.35 })], [0.55, P({ twist: 1.3, Rsf: 1.4, Rsa: 0.4, Rel: 0.25, Lsf: 1.3, Lel: 0.4, lean: 0.25, Lhf: 0.5, Rhf: -0.3 })], [0.8, P({ twist: 1.2, Rsf: 1.3, Rel: 0.3, lean: 0.2 })], [1, P({ Rsf: 0.6, Rel: 1.0 })]] },
  punch: { dur: 0.36, keys: [[0, P({})], [0.3, P({ Lsf: 0.7, Lel: 2.0, twist: -0.4, Lhf: -0.3, Rhf: 0.3, Rsf: 1.0, Rel: 1.5 })], [0.45, P({ Lsf: 1.5, Lel: 0.05, twist: 0.45, lean: 0.35, Lhf: 0.7, Rhf: -0.4, Rsf: 0.9, Rel: 1.5 })], [0.7, P({ Lsf: 1.4, Lel: 0.1, twist: 0.4, lean: 0.3, Lhf: 0.65, Rhf: -0.35, Rsf: 0.9, Rel: 1.5 })], [1, P({})]] },
  kick: { dur: 0.46, keys: [[0, P({})], [0.3, P({ Rhf: 0.2, Rkn: 1.6, lean: -0.15, Lsf: 1.0, Rsf: -0.4, Lsa: 0.9, Rsa: 0.9 })], [0.45, P({ Rhf: 1.5, Rkn: 0.1, lean: -0.35, Lhf: -0.1, Lsf: -0.4, Rsf: 1.0, Lsa: 0.9, Rsa: 0.9, headX: 0.2 })], [0.75, P({ Rhf: 1.3, Rkn: 0.2, lean: -0.3, Lsa: 0.9, Rsa: 0.9 })], [1, P({})]] },
  shoot: { dur: 0.26, keys: [[0, P({ Rsf: 1.35, Rel: 0.15, Lsf: 1.0, Lel: 0.9, twist: -0.25, lean: 0.08 })], [0.2, P({ Rsf: 1.55, Rel: 0.05, Lsf: 1.1, Lel: 0.8, twist: -0.25, lean: -0.05, headX: 0.05 })], [1, P({ Rsf: 1.35, Rel: 0.15, Lsf: 1.0, Lel: 0.9, twist: -0.25, lean: 0.08 })]] },
  cast: { dur: 0.7, keys: [[0, P({})], [0.4, P({ Lsf: 2.2, Rsf: 2.2, Lsa: 0.6, Rsa: 0.6, Lel: 0.5, Rel: 0.5, lean: -0.2, headX: 0.25, y: 0.04 })], [0.55, P({ Lsf: 1.5, Rsf: 1.5, Lsa: 0.1, Rsa: 0.1, Lel: 0.1, Rel: 0.1, lean: 0.35, y: -0.1, Lhf: 0.5, Rhf: -0.4, Lkn: 0.5 })], [0.85, P({ Lsf: 1.5, Rsf: 1.5, Lel: 0.15, Rel: 0.15, lean: 0.3, y: -0.08, Lhf: 0.5, Rhf: -0.35 })], [1, P({})]] },
  nova: { dur: 0.8, keys: [[0, P({})], [0.45, P({ Lsf: 0.3, Rsf: 0.3, Lsa: 1.7, Rsa: 1.7, lean: -0.1, y: -0.2, Lhf: 0.4, Rhf: 0.4, Lkn: 1.0, Rkn: 1.0, headX: 0.35 })], [0.58, P({ Lsf: 0.3, Rsf: 0.3, Lsa: 2.5, Rsa: 2.5, lean: 0.05, y: 0.12, Lhf: 0.1, Rhf: 0.1, Lkn: 0.1, Rkn: 0.1, headX: 0.3 })], [1, P({})]] },
  hurt: { dur: 0.34, keys: [[0, P({ lean: -0.4, headX: -0.35, Lsa: 0.9, Rsa: 0.9, Lsf: 0.3, Rsf: 0.3, y: -0.08, Lkn: 0.5, Rkn: 0.3, Lhf: 0.3, Rhf: -0.2 })], [0.3, P({ lean: -0.5, headX: -0.4, Lsa: 1.0, Rsa: 1.0, y: -0.1, Lkn: 0.6, Rkn: 0.4 })], [1, P({})]] },
  roll: { dur: 0.5, keys: [[0, P({ lean: 0.8, y: -0.4, Lkn: 1.6, Rkn: 1.6, Lhf: 1.5, Rhf: 1.5, Lsf: 1.6, Rsf: 1.6, Lel: 1.5, Rel: 1.5, headX: -0.5 })], [1, P({ lean: 0.8, y: -0.4, Lkn: 1.6, Rkn: 1.6, Lhf: 1.5, Rhf: 1.5, Lsf: 1.6, Rsf: 1.6, Lel: 1.5, Rel: 1.5, headX: -0.5 })]], rate: 30 },
  land: { dur: 0.2, keys: [[0, P({ y: -0.28, lean: 0.35, Lkn: 1.3, Rkn: 1.3, Lhf: 0.8, Rhf: 0.8, Lsa: 0.7, Rsa: 0.7 })], [1, P({})]] },
  roar: { dur: 1.1, keys: [[0, P({})], [0.3, P({ Lsa: 1.5, Rsa: 1.5, Lsf: 1.0, Rsf: 1.0, lean: -0.5, headX: 0.7, y: 0.03 })], [0.8, P({ Lsa: 1.7, Rsa: 1.7, Lsf: 1.2, Rsf: 1.2, lean: -0.55, headX: 0.7 })], [1, P({})]] },
  spawn: { dur: 1.3, keys: [[0, P({ y: -0.85, pitch: -1.2, Lsf: 2.2, Rsf: 1.6, Lel: 0.3, Rel: 0.5 })], [0.5, P({ y: -0.6, pitch: -0.5, Lsf: 1.6, Rsf: 2.0, lean: 0.4, Lhf: 0.8, Lkn: 1.4, Rhf: 0.2, Rkn: 1.6 })], [1, P({ y: 0, lean: 0.25, Lsf: 1.3, Rsf: 1.2 })]], rate: 14 },
  getup: { dur: 0.9, keys: [[0, P({ y: -0.78, pitch: -1.45, Lsa: 1.2, Rsa: 1.2 })], [0.55, P({ y: -0.5, pitch: -0.6, lean: 0.5, Lkn: 1.6, Rkn: 1.6, Lhf: 1.4, Rhf: 1.4 })], [1, P({})]], rate: 16 },
  // boss telegraph / attack poses
  raise: { dur: 0.9, keys: [[0, P({})], [0.8, P({ Rsf: 3.0, Lsf: 2.9, Rel: 0.5, Lel: 0.5, lean: -0.45, y: 0.04, headX: 0.3 })], [1, P({ Rsf: 3.0, Lsf: 2.9, Rel: 0.5, Lel: 0.5, lean: -0.45, y: 0.04 })]], hold: true },
  smash: { dur: 0.5, keys: [[0, P({ Rsf: 3.0, Lsf: 2.9, Rel: 0.5, Lel: 0.5, lean: -0.45 })], [0.35, P({ Rsf: 0.6, Lsf: 0.6, Rel: 0.05, Lel: 0.05, lean: 1.0, y: -0.3, Lhf: 0.9, Lkn: 1.1, Rkn: 0.6, headX: -0.4 })], [1, P({ Rsf: 0.6, Lsf: 0.6, Rel: 0.05, Lel: 0.05, lean: 0.95, y: -0.28, Lhf: 0.8, Lkn: 1.0 })]] },
  aim: { dur: 0.6, keys: [[0, P({ Rsf: 1.5, Rel: 0.05, Lsf: 1.5, Lel: 0.05, twist: -0.1 })], [1, P({ Rsf: 1.5, Rel: 0.05, Lsf: 1.5, Lel: 0.05, twist: -0.1 })]], hold: true },
  leap: { dur: 0.7, keys: [[0, P({ y: -0.3, lean: 0.4, Lkn: 1.5, Rkn: 1.5, Lhf: 1.0, Rhf: 1.0, Lsf: -0.6, Rsf: -0.6 })], [0.4, P({ y: 0.1, lean: 0.2, Lkn: 0.4, Rkn: 0.4, Lhf: 0.8, Rhf: -0.2, Lsf: 2.6, Rsf: 2.6 })], [1, P({ y: 0.05, lean: 0.7, Lsf: 1.5, Rsf: 1.5, Lkn: 0.6, Rkn: 0.6, Lhf: 0.9, Rhf: 0.9 })]], hold: true },
  block: { dur: 0.3, keys: [[0, P({ Lsf: 1.5, Rsf: 1.5, Lel: 1.9, Rel: 1.9, Lsa: 0.1, Rsa: 0.1, lean: 0.15, y: -0.08, Lkn: 0.6, Rkn: 0.6, Lhf: 0.3, Rhf: -0.2 })], [1, P({ Lsf: 1.5, Rsf: 1.5, Lel: 1.9, Rel: 1.9, Lsa: 0.1, Rsa: 0.1, lean: 0.15, y: -0.08, Lkn: 0.6, Rkn: 0.6, Lhf: 0.3, Rhf: -0.2 })]], hold: true },
  throw: { dur: 0.5, keys: [[0, P({})], [0.35, P({ Rsf: 2.6, Rel: 0.9, twist: -0.6, lean: -0.3 })], [0.5, P({ Rsf: 1.3, Rel: 0.1, twist: 0.6, lean: 0.4 })], [1, P({})]] },
};
const HOLD = {
  down: (r) => P({ y: -0.8, pitch: -1.5, Lsa: 0.9, Rsa: 0.9, Lkn: 0.1, Rkn: 0.1, headX: -0.2, Lhf: 0.1, Rhf: -0.1 }),
  cheer: (r, t) => P({ Lsf: 2.9, Rsf: 2.9, Lsa: 0.45, Rsa: 0.45, Lel: 0.3, Rel: 0.3, y: Math.abs(Math.sin(t * 6)) * 0.12, headX: 0.15, lean: -0.1, Lkn: 0.2 + 0.2 * Math.abs(Math.sin(t * 6)), Rkn: 0.2 }),
  victory: (r, t) => P({ Rsf: 3.0, Rel: 0.2, Lsf: 0.4, Lsa: 0.5, lean: -0.1, y: 0.01, twist: 0.2 * Math.sin(t * 2) }),
  dead: () => P({ y: -0.8, pitch: -1.5, Lsa: 1.2, Rsa: 1.2 }),
  sit: () => P({ y: -0.4, Lhf: 1.5, Rhf: 1.5, Lkn: 1.5, Rkn: 1.5, Lsf: 0.4, Rsf: 0.4 }),
  caged: (r, t) => P({ Lsf: 1.2, Rsf: 1.2, Lel: 0.5, Rel: 0.5, lean: 0.15, headX: 0.1 + 0.05 * Math.sin(t * 3) }),
  stun: (r, t) => P({ lean: -0.25, headX: -0.3, headY: Math.sin(t * 12) * 0.3, Lsa: 0.8, Rsa: 0.8, y: -0.06, Lkn: 0.5, Rkn: 0.5 }),
  charge: (r, t) => P({ lean: 0.9, y: -0.15, Lsf: -1.2, Rsf: -1.2, Lhf: Math.sin(t * 22) * 1.0, Rhf: -Math.sin(t * 22) * 1.0, Lkn: 0.8 + 0.6 * Math.cos(t * 22), Rkn: 0.8 - 0.6 * Math.cos(t * 22), headX: -0.3 }),
  channel: (r, t) => P({ Lsf: 2.3, Rsf: 2.3, Lsa: 0.7, Rsa: 0.7, Lel: 0.5, Rel: 0.5, lean: -0.2, headX: 0.3 + 0.05 * Math.sin(t * 9), y: 0.04 + 0.02 * Math.sin(t * 8) }),
  roarHold: (r, t) => P({ Lsa: 1.6, Rsa: 1.6, Lsf: 1.1, Rsf: 1.1, lean: -0.5, headX: 0.7 }),
};
