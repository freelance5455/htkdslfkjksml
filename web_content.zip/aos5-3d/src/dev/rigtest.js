import * as THREE from 'three';
import { G } from '../ctx.js';
import { makeRig, STYLES } from '../styles.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
G.fx = { outline: true };
const canvas = document.getElementById('gl');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setSize(innerWidth, innerHeight); renderer.shadowMap.enabled = true;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
const scene = new THREE.Scene(); scene.background = new THREE.Color(0x2a3350); scene.fog = new THREE.Fog(0x2a3350, 20, 60);
const pm = new THREE.PMREMGenerator(renderer); scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; scene.environmentIntensity = 0.5;
const sun = new THREE.DirectionalLight(0xfff0d8, 2.2); sun.position.set(6, 12, 8); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 8, bottom: -8, near: 1, far: 40 }); scene.add(sun);
scene.add(new THREE.HemisphereLight(0x9fb4ff, 0x40384a, 0.8));
const ground = new THREE.Mesh(new THREE.PlaneGeometry(80, 40), new THREE.MeshStandardMaterial({ color: 0x4a4d57, roughness: .95 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
const ids = (new URLSearchParams(location.search).get('ids') || 'hero,kira,barq,sindan,noor,shararah,zill,titan,mech').split(',');
const rigs = [];
const poses = ['idle', 'run', 'swingR', 'overhead', 'cast', 'hurt', 'shoot', 'cheer', 'stab', 'idle', 'idle'];
let x = -(ids.length - 1) * 1.1;
ids.forEach((id, i) => {
  const r = makeRig(id); r.root.position.set(x, 0, 0); x += 2.2; r.root.rotation.y = 0.35; scene.add(r.root); r.snap();
  rigs.push({ r, pose: poses[i % poses.length] });
  if (id === 'hero') r.setWeapon('blade');
});
const cam = new THREE.PerspectiveCamera(38, innerWidth / innerHeight, 0.1, 100);
const zoom = parseFloat(new URLSearchParams(location.search).get('z') || '1');
cam.position.set(0, 3.3 * zoom, 15 * zoom); cam.lookAt(0, 1.5, 0);
let t = 0;
function step(dt) { t += dt; for (const o of rigs) { const r = o.r; if (o.pose === 'run') { r.speed = 6.5; } else if (o.pose !== 'idle') { r.speed = 0; if (!r.busy && !r.hold) { if (o.pose === 'cheer') r.setHold('cheer'); else r.act(o.pose, null, { rate: 24 }); } } r.update(dt); } }
window.__step = (s) => { for (let i = 0; i < s * 60; i++) step(1 / 60); renderer.render(scene, cam); window.__ready = true; };
function loop() { step(1 / 60); renderer.render(scene, cam); requestAnimationFrame(loop); }
window.__rigs = rigs; window.__render = () => renderer.render(scene, cam);
loop();
