import * as THREE from 'three';
import { G } from '../ctx.js';
import { Stage } from '../stage.js';
import { buildLevel } from '../levelbuild.js';
import { LEVEL_BY_ID, LEVELS } from '../data/levels.js';
import { makeRig } from '../styles.js';
import { bindFx } from '../props.js';

const canvas = document.getElementById('gl');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.toneMapping = THREE.ACESFilmicToneMapping;
const stage = new Stage(renderer, new URLSearchParams(location.search).get('q') || 'med');
let W = null, hero = null;
function build(id) {
  if (W) { stage.scene.remove(W.group); }
  const spec = LEVEL_BY_ID[id];
  const t0 = performance.now();
  W = buildLevel(spec);
  stage.setWorld(W, spec.theme);
  if (hero) stage.scene.remove(hero.root);
  hero = makeRig('hero'); hero.setWeapon('pipe'); hero.root.position.set(W.start.x, W.start.y, W.start.z); hero.snap(); stage.scene.add(hero.root);
  return { ms: Math.round(performance.now() - t0), colliders: W.colliders.length, spawns: W.spawns.length, pickups: W.pickups.length, interact: W.interactables.length, breakables: W.breakables.length, zones: W.zones.length, doors: W.doors.length, end: W.endX, start: W.start, exit: W.exit };
}
function cam(x, y, z, lx, ly, lz) { stage.camera.position.set(x, y, z); stage.camera.lookAt(lx, ly, lz); }
function focus(x, z, y = 0, dist = 14, pitch = 0.62, zone = true) {
  hero.root.position.set(x, y, z); hero.update(0.016);
  const zn = W.updateZone({ x, y, z });
  stage.camera.position.set(x, y + Math.sin(pitch) * dist + 1.5, z - Math.cos(pitch) * dist); stage.camera.lookAt(x, y + 1, z);
  stage.update(0.5, { x, y, z }, zn); W.update(0.5, 5, { x, y, z }); stage.update(2, { x, y, z }, zn);
  W.updateOcclusion(stage.camera.position, new THREE.Vector3(x, y + 1, z));
}
function pathCheck() {
  const out = []; const pts = [W.start]; for (const s of Object.values(W.segInfo)) { if (s.exit) pts.push({ x: s.exit.x, z: s.exit.z }); } pts.push(W.exit);
  if (!W.nav.enabled) return 'nav disabled';
  for (let i = 1; i < pts.length; i++) { const p = W.nav.path(pts[i - 1].x, pts[i - 1].z, pts[i].x, pts[i].z, 20000); out.push(p ? p.length : null); }
  return out;
}
window.__lv = { build, focus, cam, pathCheck, render: () => { stage.render(); }, getW: () => W, stage };
window.__step = (s) => { for (let i = 0; i < s * 30; i++) { W.update(1 / 30, i / 30, hero.root.position); hero.update(1 / 30); } stage.render(); window.__ready = true; };
const id = +(new URLSearchParams(location.search).get('l') || 1);
window.__info = build(id);
function loop() { stage.render(); requestAnimationFrame(loop); }
loop();
