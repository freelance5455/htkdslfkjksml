// The hero: movement, jump, roll, combo melee / ranged weapons, abilities, summons, Titan transformation and mech riding.
import * as THREE from 'three';
import { G } from './ctx.js';
import { Save } from './save.js';
import { Input } from './input.js';
import { ITEMS, ITEM_ORDER, xpNeeded } from './data/items.js';
import { makeRig } from './styles.js';
import { Combat } from './combat.js';
import { moveXZ, stepVertical } from './phys.js';
import { angDiff, dampAng, clamp, TAU } from './util.js';

const HITK = { swingR: 0.46, swingL: 0.46, overhead: 0.5, slamGround: 0.55, stab: 0.5, sweep: 0.55, punch: 0.45, kick: 0.45 };
const TITAN = { combo: ['punch', 'kick', 'slamGround'], dur: [0.4, 0.45, 0.75], dmg: 34, reach: 3.4, arc: 2.6, knock: 11, aoe: 2.2 };
const MECH_HP = 320;
let P = null;

export const Player = {
  get p() { return P; },
  create() {
    const hero = makeRig('hero'), titan = makeRig('titan'), mech = makeRig('mech');
    for (const r of [hero, titan, mech]) { r.setOutline(G.fx.outline); G.stage.scene.add(r.root); r.root.visible = false; }
    P = G.p = {
      kind: 'player', x: 0, y: 0, z: 0, vx: 0, vz: 0, vy: 0, r: 0.42, h: 1.8, yaw: Math.PI / 2, hp: 100, maxHp: 100, energy: 100, maxEnergy: 100, rage: 0, form: 'hero',
      rigs: { hero, titan, mech }, rig: hero, grounded: true, coyote: 0, jumpBuf: 0, rollT: 0, rollCD: 0, rollDir: { x: 1, z: 0 }, iframes: 0, atk: null, comboIdx: 0, comboT: 0, shotCD: 0, cd: { a1: 0, a2: 0 }, cdMax: { a1: 1, a2: 1 }, buffs: {}, shield: null,
      dead: false, ghost: false, hurtT: 0, kx: 0, kz: 0, safe: null, safeT: 0, mechHp: 0, mechMax: MECH_HP, formT: 0, interact: null, aimT: null, attackHeld: false, stats: {}, landT: 0, lastGround: null, noControl: 0, shieldMesh: null, wasAir: false, standStill: 0,
    };
    this.recompute(true); this.setForm('hero');
    return P;
  },
  destroy() { if (!P) return; for (const r of Object.values(P.rigs)) { G.stage.scene.remove(r.root); r.dispose(); } if (P.shieldMesh) G.stage.scene.remove(P.shieldMesh); P = G.p = null; },
  recompute(full) {
    const s = Save.d, up = s.upgrades || {}, lv = s.level;
    const ratio = P.hp / P.maxHp;
    P.maxHp = 100 + 14 * (up.hp || 0) + 6 * (lv - 1); P.maxEnergy = 100 + 12 * (up.energy || 0);
    P.dmgMul = (1 + 0.06 * (up.dmg || 0)) * (1 + 0.03 * (lv - 1)); P.speedMul = 1 + 0.03 * (up.speed || 0);
    P.armor = Math.max(0.35, 1 - 0.03 * (up.armor || 0)); P.magnet = 3 + 1.2 * (up.magnet || 0); P.eRegen = 5 + 0.8 * (up.energy || 0);
    if (full) { P.hp = P.maxHp; P.energy = P.maxEnergy; } else P.hp = Math.min(P.maxHp, ratio * P.maxHp);
    this.syncWeapon();
  },
  weaponItem() { const id = Save.d.equip.primary; return ITEMS[id] || ITEMS.pipe; },
  weaponStats() { const it = this.weaponItem(); return it.stats((Save.d.items[it.id] || { lv: 1 }).lv); },
  syncWeapon() { const it = this.weaponItem(); P.rigs.hero.setWeapon(it.model || 'pipe'); },
  cycleWeapon(dir = 1) {
    const owned = ITEM_ORDER.filter(id => Save.d.items[id] && (ITEMS[id].cat === 'melee' || ITEMS[id].cat === 'ranged'));
    if (owned.length < 2) { G.ui && G.ui.toast('لا تملك سلاحًا آخر — اشترِ من المتجر'); return; }
    let i = owned.indexOf(Save.d.equip.primary); i = (i + dir + owned.length) % owned.length; Save.d.equip.primary = owned[i]; Save.commit();
    this.syncWeapon(); G.audio && G.audio.sfx('click'); G.ui && G.ui.toast(ITEMS[owned[i]].icon + ' ' + ITEMS[owned[i]].name); P.atk = null; P.comboIdx = 0;
  },
  setForm(f) {
    P.form = f; for (const k in P.rigs) P.rigs[k].root.visible = k === f; P.rig = P.rigs[f];
    P.r = f === 'hero' ? 0.42 : f === 'titan' ? 0.62 : 0.85; P.h = f === 'hero' ? 1.8 : f === 'titan' ? 2.7 : 3.9;
    P.rig.root.position.set(P.x, P.y, P.z); P.rig.root.rotation.y = P.yaw; P.rig.snap();
    if (G.ui) G.ui.refreshHud && G.ui.refreshHud();
  },
  place(x, y, z) { P.x = x; P.y = y; P.z = z; P.vy = 0; P.vx = P.vz = 0; P.kx = P.kz = 0; P.grounded = true; P.safe = { x, y, z }; P.rig.root.position.set(x, y, z); },
  reset(x, y, z) {
    P.dead = false; P.ghost = false; P.hp = P.maxHp; P.energy = P.maxEnergy; P.rage = 0; P.atk = null; P.comboIdx = 0; P.buffs = {}; P.cd.a1 = P.cd.a2 = 0; P.shield = null; P.iframes = 1.2; P.rollT = 0; P.hurtT = 0; P.noControl = 0; P.shotCD = 0;
    if (P.form !== 'hero') this.setForm('hero'); P.rig.setHold(null); P.rig.endAction(); this.place(x, y, z);
  },
  // ------------------------------------------------------------ progression
  addXP(n) {
    const s = Save.d; s.xp += n; let up = false;
    while (s.xp >= xpNeeded(s.level) && s.level < 60) { s.xp -= xpNeeded(s.level); s.level++; up = true; }
    if (up) { this.recompute(false); P.hp = P.maxHp; G.audio && G.audio.sfx('levelup'); G.ui && G.ui.toast('⬆ مستوى جديد: ' + s.level + '  (+6 صحة، +3% ضرر)'); G.fx.ring(P.x, P.y, P.z, 3, 0xffd23a, 0.7); if (G.run) G.run.stats.levelUps++; }
  },
  onDealt(dmg, e) {
    P.energy = Math.min(P.maxEnergy, P.energy + 1.2 + dmg * 0.04);
    if (P.form === 'hero' && Save.d.titan) P.rage = Math.min(100, P.rage + dmg * 0.22);
  },
  onKill(e) { if (G.run) G.run.stats.kills++; Save.d.stats.kills++; },
  // ------------------------------------------------------------ damage
  hurt(dmg, o = {}) {
    if (P.dead || P.ghost) return 0;
    if (!o.tick && P.iframes > 0) return 0;
    if (P.rollT > 0 && P.rollT > 0.12 && !o.tick) { return 0; }
    let d = dmg;
    if (P.shield && P.shield.t > 0) { const a = Math.min(P.shield.abs, d); P.shield.abs -= a; d -= a; G.fx.spark(P.x, P.y + 1, P.z, 0x6ae0ff, 4); if (P.shield.abs <= 0) { P.shield.t = 0; } if (d <= 0) return 0; }
    if (P.form === 'mech') {
      P.mechHp -= d * 0.8; G.fx.text(P.x, P.y + P.h, P.z, '-' + Math.round(d * 0.8), 'p'); P.rig.flash(0xffa060, 0.1); G.audio && G.audio.sfx('hit2'); if (!o.tick) P.iframes = 0.3;
      if (P.mechHp <= 0) this.dismount(true); return d;
    }
    d *= P.armor * (P.form === 'titan' ? 0.5 : 1);
    P.hp -= d; P.hurtT = 0.4; if (G.run) G.run.stats.taken += d;
    G.fx.text(P.x, P.y + P.h + 0.1, P.z, '-' + Math.max(1, Math.round(d)), 'p'); P.rig.flash(0xff5050, 0.12);
    if (!o.tick) { P.iframes = 0.55; G.audio && G.audio.sfx('hurt'); G.fx.addShake(0.35); if (G.ui) G.ui.hurtFlash(); }
    if (P.form === 'hero' && Save.d.titan) P.rage = Math.min(100, P.rage + d * 0.35);
    if (!o.tick && o.dx !== undefined && !o.noFlinch) { const k = (o.knock || 4) * (P.form === 'titan' ? 0.3 : 0.7); P.kx += o.dx * k; P.kz += o.dz * k; if (P.form === 'hero' && P.rollT <= 0) { P.rig.act('hurt', 0.34); if (P.atk && !P.atk.hitDone) { P.atk = null; } } }
    if (P.hp <= 0) { P.hp = 0; P.dead = true; P.rig.setHold('dead'); G.audio && G.audio.sfx('die'); if (P.form !== 'hero') this.setForm('hero'), P.rig.setHold('dead'); Save.d.stats.deaths++; if (G.run) G.run.onPlayerDeath(); }
    return d;
  },
  heal(n) { if (P.dead) return; const h = Math.min(P.maxHp - P.hp, n); if (h > 0.5) { P.hp += h; G.fx.text(P.x, P.y + P.h, P.z, '+' + Math.round(h), 'heal'); G.fx.heal(P.x, P.y + 0.8, P.z); } },
  // ------------------------------------------------------------ transformation / mech
  canTransform() { return Save.d.titan && P.form === 'hero' && P.rage >= 100 && !P.dead; },
  transform() {
    if (P.dead) return;
    if (P.form === 'titan') { this.endTitan(); return; }
    if (P.form === 'mech') { this.dismount(false); return; }
    if (!Save.d.titan) { G.ui && G.ui.toast('قوة التحوّل مقفلة — أكمل المرحلة 6'); return; }
    if (P.rage < 100) { G.ui && G.ui.toast('عدّاد الغضب غير ممتلئ (' + Math.floor(P.rage) + '%)'); G.audio && G.audio.sfx('deny'); return; }
    this.setForm('titan'); P.atk = null; P.comboIdx = 0; P.iframes = 1.0; P.hp = Math.min(P.maxHp, P.hp + P.maxHp * 0.3);
    G.fx.ring(P.x, P.y, P.z, 7, 0x6fe6ff, 0.7); G.fx.ring(P.x, P.y, P.z, 4, 0xffc83a, 0.5); G.fx.explode(P.x, P.y + 1, P.z, 3.5, 0x6fe6ff); G.fx.addShake(1); G.audio && G.audio.sfx('transform');
    Combat.area(P.x, P.z, 6, 0, 'p', { knock: 9, stun: 1.0 }); G.ui && G.ui.toast('★ وضع العملاق!');
  },
  endTitan() { this.setForm('hero'); P.rage = 0; P.iframes = 0.6; G.fx.ring(P.x, P.y, P.z, 4, 0x6fe6ff, 0.5); G.fx.spark(P.x, P.y + 1, P.z, 0x6fe6ff, 20); G.audio && G.audio.sfx('shield'); },
  mount(st) {
    if (P.form !== 'hero' || P.dead) return false;
    this.setForm('mech'); P.mechMax = MECH_HP + 40 * ((G.run && G.run.diff) || 1); P.mechHp = P.mechMax; P.atk = null; P.iframes = 1.0; P.station = st;
    st.enabled = false; if (st.beacon) st.beacon.visible = false; if (st.mesh) st.mesh.visible = false;
    G.fx.ring(P.x, P.y, P.z, 5, 0xff8a1f, 0.6); G.fx.explode(P.x, P.y + 1, P.z, 3, 0xff8a1f); G.audio && G.audio.sfx('transform'); G.ui && G.ui.toast('🤖 الروبوت الميكانيكي: [هجوم] مدفع، [1] دهس، [2] صواريخ. [تفاعل] للنزول');
    return true;
  },
  dismount(destroyed) {
    if (P.form !== 'mech') return; const x = P.x, y = P.y, z = P.z;
    this.setForm('hero'); P.iframes = 1.2; P.shield = null; G.fx.explode(x, y + 1.5, z, destroyed ? 4.5 : 2.5, 0xff8a1f); G.audio && G.audio.sfx('boom');
    if (destroyed) { Combat.area(x, z, 5, 40, 'p', { knock: 8 }); G.ui && G.ui.toast('تحطّم الروبوت!'); }
    P.vy = 6; P.grounded = false;
  },
  // ------------------------------------------------------------ attack helpers
  aimAngle(range = 14, cone = 0.9) {
    let best = null, bs = 1e9;
    const set = Combat.foes('p');
    for (const t of set) { if (t.kind === 'breakable' && !(t.aimable)) continue; const dx = t.x - P.x, dz = t.z - P.z, d = Math.hypot(dx, dz) - (t.r || 0.4); if (d > range) continue; const a = Math.abs(angDiff(P.yaw, Math.atan2(dx, dz))); if (a > cone && d > 2.2) continue; if (Math.abs((t.y || 0) - P.y) > 3.5) continue; const s = d + a * 3; if (s < bs) { bs = s; best = t; } }
    return best;
  },
  dmgOut() { const b = P.buffs; let m = P.dmgMul; if (b.rage && b.rage.t > 0) m *= b.rage.mult; if (P.form === 'titan') m *= 1; return m; },
  rate() { const b = P.buffs; return (b.haste && b.haste.t > 0) ? b.haste.mult : 1; },
  startMelee(st, forced) {
    const form = P.form, S = form === 'titan' ? TITAN : st;
    const step = P.comboIdx % S.combo.length; const act = S.combo[step]; const rate = (form === 'titan' ? 1 : st.rate) * this.rate();
    const dur = S.dur[step] / rate; const hk = HITK[act] || 0.46;
    // face target / input direction
    const tg = Save.d.settings.autoAim !== false ? this.aimAngle(4.2, 1.2) : null;
    if (tg) P.yaw = Math.atan2(tg.x - P.x, tg.z - P.z); else { const ax = Input.axis(); if (Math.hypot(ax.x, ax.z) > 0.3) P.yaw = Math.atan2(ax.x, ax.z); else if (!Input.sim.on && G.Cam && G.Cam.isThird()) P.yaw = G.Cam.yaw; }
    P.atk = { S, act, dur, t: 0, hitAt: dur * hk, hitDone: false, step, ranged: false };
    P.rig.act(act, dur); G.audio && G.audio.sfx('swing');
    const f = (form === 'titan' ? 4.5 : 3.0); P.vx += Math.sin(P.yaw) * f; P.vz += Math.cos(P.yaw) * f;
    P.comboIdx = step + 1; P.comboT = dur + 0.5;
  },
  meleeHit() {
    const A = P.atk, S = A.S; const form = P.form;
    const dmg = (form === 'titan' ? TITAN.dmg : S.dmg) * this.dmgOut() * (form === 'titan' ? 1.0 : 1);
    const crit = Math.random() < 0.09; const d = dmg * (crit ? 1.8 : 1);
    const lastStep = A.step === S.combo.length - 1;
    const n = Combat.cone(P, S.reach, S.arc, d * (lastStep ? 1.25 : 1), 'p', { knock: S.knock * (lastStep ? 1.4 : 1), crit, pierce: S.pierce });
    if (S.aoe && (A.act === 'slamGround' || A.act === 'overhead' && S.aoe > 2)) { const fx = P.x + Math.sin(P.yaw) * S.reach * 0.7, fz = P.z + Math.cos(P.yaw) * S.reach * 0.7; Combat.area(fx, fz, S.aoe, d * 0.6, 'p', { knock: S.knock * 0.6, y: P.y }); G.fx.ring(fx, P.y, fz, S.aoe, 0xffd890, 0.35); G.fx.dust(fx, P.y, fz, 6); G.fx.addShake(0.3); }
    if (n) { G.hitstop = Math.max(G.hitstop, lastStep ? 0.07 : 0.04); G.fx.addShake(lastStep ? 0.25 : 0.12); } else if (A.act === 'slamGround') { G.fx.dust(P.x + Math.sin(P.yaw) * 2, P.y, P.z + Math.cos(P.yaw) * 2, 5); }
    if (n && crit) G.audio && G.audio.sfx('crit');
    if (n && G.run) G.run.stats.hits += n;
    A.hitDone = true;
  },
  shootPrimary(st) {
    const tg = Save.d.settings.autoAim !== false ? this.aimAngle(st.range || 24, 0.8) : null;
    if (tg) P.yaw = Math.atan2(tg.x - P.x, tg.z - P.z);
    else { const ax = Input.axis(); if (Math.hypot(ax.x, ax.z) > 0.3 && !P.attackHeld) P.yaw = Math.atan2(ax.x, ax.z); else if (!Input.sim.on && G.Cam && G.Cam.isThird() && Math.hypot(ax.x, ax.z) <= 0.3) P.yaw = G.Cam.yaw; }
    const oy = P.y + 1.15, ox = P.x + Math.sin(P.yaw) * 0.6, oz = P.z + Math.cos(P.yaw) * 0.6;
    let dy = 0; if (tg) { const d = Math.hypot(tg.x - P.x, tg.z - P.z) || 1; dy = clamp(((tg.y || 0) + (tg.h || 1.4) * 0.55 - oy) / d, -0.45, 0.45); }
    for (let i = 0; i < st.n; i++) {
      const sp = (Math.random() - 0.5) * 2 * st.spread, a = P.yaw + sp * (st.n > 1 ? 1 : 0.5);
      Combat.shoot({ x: ox, y: oy, z: oz, dx: Math.sin(a), dy, dz: Math.cos(a), spd: st.spd, dmg: st.dmg * this.dmgOut(), team: 'p', color: st.color, size: st.size, range: st.range, pierce: st.pierce || 0, src: 'player', knock: 2 });
    }
    P.rig.act('shoot', 0.22); G.audio && G.audio.sfx(st.pierce ? 'laser' : 'shoot'); G.fx.spark(ox, oy, oz, st.color, 3, { speed: 3 });
    P.shotCD = st.cd / this.rate();
  },
  // ------------------------------------------------------------ abilities
  useAbility(slot) {
    if (P.dead) return;
    if (P.form === 'titan') return this.titanAbility(slot);
    if (P.form === 'mech') return this.mechAbility(slot);
    const id = Save.d.equip[slot]; if (!id) { G.ui && G.ui.toast('لا توجد قدرة في هذه الخانة — جهّزها من الحقيبة'); return; }
    const it = ITEMS[id], lv = (Save.d.items[id] || { lv: 1 }).lv, s = it.stats(lv);
    if (P.cd[slot] > 0) { G.audio && G.audio.sfx('deny'); return; }
    if (s.cost && P.energy < s.cost) { G.ui && G.ui.toast('الطاقة غير كافية'); G.audio && G.audio.sfx('deny'); return; }
    const k = s.kind; P.energy -= s.cost || 0; const dm = this.dmgOut();
    const tg = this.aimAngle(20, 1.0); if (tg) P.yaw = Math.atan2(tg.x - P.x, tg.z - P.z);
    const fx = Math.sin(P.yaw), fz = Math.cos(P.yaw);
    switch (k) {
      case 'orb': Combat.shoot({ x: P.x + fx * 0.7, y: P.y + 1.2, z: P.z + fz * 0.7, dx: fx, dy: 0, dz: fz, spd: s.spd, dmg: s.dmg * dm, team: 'p', color: s.color, size: 0.38, range: 26, explode: s.radius, knock: 8, src: 'player' }); P.rig.act('cast', 0.55); G.audio && G.audio.sfx('orb'); break;
      case 'chain': {
        const first = Combat.nearest(P.x, P.z, 13, 'p', t => t.kind === 'enemy' && Math.abs(t.y - P.y) < 3); if (!first) { P.energy += s.cost; G.ui && G.ui.toast('لا هدف قريب'); return; }
        let cur = first, from = { x: P.x, y: P.y + 1.3, z: P.z }; const hit = new Set(); P.rig.act('cast', 0.5); G.audio && G.audio.sfx('zap');
        for (let j = 0; j <= s.jumps && cur; j++) { hit.add(cur); G.fx.beam(from.x, from.y, from.z, cur.x, cur.y + 1.1, cur.z, s.color, 0.12, 0.25); G.fx.spark(cur.x, cur.y + 1.1, cur.z, s.color, 8); Combat.damage(cur, s.dmg * dm * (1 - 0.08 * j), { dx: 0, dz: 0, knock: 3, src: 'player', stun: 0.5 }); from = { x: cur.x, y: cur.y + 1.1, z: cur.z }; let nx = null, nd = s.range; for (const t of G.enemies) { if (t.dead || hit.has(t) || t.untargetable) continue; const d = Math.hypot(t.x - cur.x, t.z - cur.z); if (d < nd) { nd = d; nx = t; } } cur = nx; }
        break; }
      case 'nova': P.rig.act('nova', 0.8); G.fx.ring(P.x, P.y, P.z, s.radius, s.color, 0.5); G.fx.ring(P.x, P.y, P.z, s.radius * 0.6, 0xffffff, 0.35); G.fx.explode(P.x, P.y + 0.5, P.z, 2.5, s.color); G.fx.addShake(0.7); G.audio && G.audio.sfx('nova'); Combat.area(P.x, P.z, s.radius, s.dmg * dm, 'p', { knock: s.knock, y: P.y, stun: 0.6 }); break;
      case 'turret': this.spawnTurret(s, dm); P.rig.act('throw', 0.5); break;
      case 'shield': P.shield = { t: s.dur, abs: s.absorb }; G.audio && G.audio.sfx('shield'); G.fx.ring(P.x, P.y, P.z, 2.5, 0x6ae0ff, 0.5); P.rig.act('cast', 0.5); break;
      case 'drone': this.spawnDrone(s, dm); P.rig.act('throw', 0.5); break;
      case 'rage': P.buffs.rage = { t: s.dur, max: s.dur, mult: s.mult }; G.fx.ring(P.x, P.y, P.z, 3, 0xff4a3a, 0.5); G.audio && G.audio.sfx('roar'); P.rig.act('roar', 0.8); break;
      case 'haste': P.buffs.haste = { t: s.dur, max: s.dur, mult: s.mult }; G.fx.ring(P.x, P.y, P.z, 3, 0xffe27a, 0.5); G.audio && G.audio.sfx('transform'); break;
      case 'freeze': G.audio && G.audio.sfx('freeze'); G.fx.ring(P.x, P.y, P.z, s.radius, 0x9fe8ff, 0.6); P.rig.act('nova', 0.8); for (const e of G.enemies) if (!e.dead && Math.hypot(e.x - P.x, e.z - P.z) < s.radius) { e.slowT = s.dur; e.slowPow = s.slow; G.fx.spark(e.x, e.y + 1, e.z, 0x9fe8ff, 8); } break;
    }
    const hasteCd = (k === 'rage' || k === 'haste') ? 1 : 1;
    P.cd[slot] = s.cd * hasteCd; P.cdMax[slot] = s.cd;
  },
  titanAbility(slot) {
    if (P.cd[slot] > 0) { G.audio && G.audio.sfx('deny'); return; }
    if (slot === 'a1') { P.rig.act('slamGround', 0.8); setTimeout(() => { if (!P || P.dead || P.form !== 'titan') return; G.fx.ring(P.x, P.y, P.z, 7, 0xffc83a, 0.5); G.fx.explode(P.x, P.y + 0.3, P.z, 3.5, 0xffc83a); G.fx.addShake(1); G.audio && G.audio.sfx('boom'); Combat.area(P.x, P.z, 7, 55 * this.dmgOut(), 'p', { knock: 14, y: P.y, stun: 0.8 }); }, 450); P.cd.a1 = 3.2; P.cdMax.a1 = 3.2; }
    else { P.rig.act('roar', 0.9); G.audio && G.audio.sfx('roar'); G.fx.ring(P.x, P.y, P.z, 10, 0x6fe6ff, 0.7); G.fx.addShake(0.6); Combat.area(P.x, P.z, 10, 12 * this.dmgOut(), 'p', { knock: 9, stun: 2.2, y: P.y }); P.cd.a2 = 9; P.cdMax.a2 = 9; }
  },
  mechAbility(slot) {
    if (P.cd[slot] > 0) { G.audio && G.audio.sfx('deny'); return; }
    if (slot === 'a1') { P.rig.act('smash', 0.6); setTimeout(() => { if (!P || P.form !== 'mech') return; G.fx.ring(P.x, P.y, P.z, 5.8, 0xff8a1f, 0.5); G.fx.explode(P.x, P.y + 0.3, P.z, 3, 0xff8a1f); G.fx.addShake(0.9); G.audio && G.audio.sfx('boom'); Combat.area(P.x, P.z, 5.8, 48 * this.dmgOut(), 'p', { knock: 12, y: P.y, stun: 0.7 }); }, 300); P.cd.a1 = 4; P.cdMax.a1 = 4; }
    else { P.rig.act('raise', 0.5); for (let i = 0; i < 6; i++) setTimeout(() => { if (!P || P.form !== 'mech') return; const a = P.yaw + (i - 2.5) * 0.18; Combat.shoot({ x: P.x + Math.sin(a), y: P.y + 3.2, z: P.z + Math.cos(a), dx: Math.sin(a), dy: 0.25, dz: Math.cos(a), spd: 17, dmg: 30 * this.dmgOut(), team: 'p', color: 0xff9a3a, size: 0.26, range: 34, explode: 2.2, homing: 3, src: 'player' }); G.audio && G.audio.sfx('shoot'); }, i * 110); P.cd.a2 = 8; P.cdMax.a2 = 8; }
  },
  spawnTurret(s, dm) {
    const x = P.x + Math.sin(P.yaw) * 1.6, z = P.z + Math.cos(P.yaw) * 1.6; const g = new THREE.Group();
    const m = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, metalness: 0.6, roughness: 0.4, ...o });
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.5, 0.35, 8), m(0x3a424e)); base.position.y = 0.18; g.add(base);
    const head = new THREE.Group(); head.position.y = 0.75; const hb = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 0.6), m(0x6ae0ff, { emissive: 0x1a6a8a })); head.add(hb); const br = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.8), m(0x20262e)); br.position.z = 0.55; head.add(br); g.add(head);
    g.position.set(x, P.y, z); g.traverse(o => { if (o.isMesh) o.castShadow = true; }); G.stage.scene.add(g);
    (G.turrets = G.turrets || []).push({ kind: 'turret', x, y: P.y, z, r: 0.5, h: 1.2, hp: 90, life: s.dur, rate: s.rate, dmg: s.dmg * dm, mesh: g, head, t: 0, cdT: 0 }); G.fx.ring(x, P.y, z, 1.6, 0x6ae0ff, 0.4);
  },
  spawnDrone(s, dm) {
    const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0xe8eef4, metalness: 0.5, roughness: 0.4 });
    g.add(new THREE.Mesh(new THREE.SphereGeometry(0.25, 10, 8), m)); const r = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.04, 6, 14), new THREE.MeshBasicMaterial({ color: 0x66ff9a })); r.rotation.x = Math.PI / 2; g.add(r);
    g.position.set(P.x, P.y + 2.2, P.z); G.stage.scene.add(g); G.drone = { mesh: g, t: s.dur, heal: s.heal, dmg: s.dmg * dm, cdT: 0, healAcc: 0, x: P.x, y: P.y + 2.2, z: P.z };
  },
  updateSummons(dt) {
    const T = G.turrets || [];
    for (let i = T.length - 1; i >= 0; i--) {
      const t = T[i]; t.life -= dt; t.t += dt; t.cdT -= dt;
      if (t.life <= 0) { G.stage.scene.remove(t.mesh); G.fx.spark(t.x, t.y + 0.8, t.z, 0x6ae0ff, 10); T.splice(i, 1); continue; }
      const tg = Combat.nearest(t.x, t.z, 16, 'p', e => e.kind === 'enemy' && Math.abs(e.y - t.y) < 3 && !G.W.losBlocked(t.x, t.z, e.x, e.z, 1.2));
      if (tg) { t.head.rotation.y = Math.atan2(tg.x - t.x, tg.z - t.z); if (t.cdT <= 0) { t.cdT = t.rate; const a = Math.atan2(tg.x - t.x, tg.z - t.z); Combat.shoot({ x: t.x + Math.sin(a) * 0.6, y: t.y + 0.8, z: t.z + Math.cos(a) * 0.6, dx: Math.sin(a), dy: 0, dz: Math.cos(a), spd: 28, dmg: t.dmg, team: 'p', color: 0x6ae0ff, size: 0.12, range: 18, src: 'turret' }); G.audio && G.audio.sfx('shoot'); } }
    }
    const D = G.drone; if (D) {
      D.t -= dt; D.cdT -= dt; const a = G.t * 1.8; const tx = P.x + Math.cos(a) * 1.4, tz = P.z + Math.sin(a) * 1.4, ty = P.y + 2.4 + Math.sin(G.t * 3) * 0.15;
      D.x += (tx - D.x) * Math.min(1, dt * 6); D.y += (ty - D.y) * Math.min(1, dt * 6); D.z += (tz - D.z) * Math.min(1, dt * 6); D.mesh.position.set(D.x, D.y, D.z); D.mesh.rotation.y += dt * 4;
      D.healAcc += D.heal / 9 * dt; if (D.healAcc >= 4) { this.heal(D.healAcc); D.healAcc = 0; }
      if (D.cdT <= 0) { const tg = Combat.nearest(P.x, P.z, 14, 'p', e => e.kind === 'enemy'); if (tg) { D.cdT = 0.5; const dx = tg.x - D.x, dy = tg.y + 1 - D.y, dz = tg.z - D.z; Combat.shoot({ x: D.x, y: D.y, z: D.z, dx, dy, dz, spd: 26, dmg: D.dmg, team: 'p', color: 0x66ff9a, size: 0.1, range: 18, src: 'turret' }); } }
      if (D.t <= 0) { G.stage.scene.remove(D.mesh); G.drone = null; }
    }
  },
  clearSummons() { for (const t of G.turrets || []) G.stage.scene.remove(t.mesh); G.turrets = []; if (G.drone) { G.stage.scene.remove(G.drone.mesh); G.drone = null; } },
  // ------------------------------------------------------------ main update
  update(dt) {
    const W = G.W; const rig = P.rig;
    if (P.shieldMesh === null) { const m = new THREE.Mesh(new THREE.SphereGeometry(1.5, 16, 12), new THREE.MeshBasicMaterial({ color: 0x6ae0ff, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); m.visible = false; G.stage.scene.add(m); P.shieldMesh = m; }
    // timers
    for (const k in P.cd) if (P.cd[k] > 0) P.cd[k] -= dt;
    for (const k in P.buffs) if (P.buffs[k].t > 0) P.buffs[k].t -= dt;
    if (P.iframes > 0) P.iframes -= dt; if (P.rollCD > 0) P.rollCD -= dt; if (P.shotCD > 0) P.shotCD -= dt; if (P.hurtT > 0) P.hurtT -= dt;
    if (P.comboT > 0) { P.comboT -= dt; if (P.comboT <= 0) P.comboIdx = 0; }
    if (P.shield && P.shield.t > 0) P.shield.t -= dt;
    if (P.form === 'hero') { P.energy = Math.min(P.maxEnergy, P.energy + P.eRegen * dt); }
    else if (P.form === 'titan') { P.rage -= dt * (100 / 18); if (P.rage <= 0) { P.rage = 0; this.endTitan(); } P.energy = P.maxEnergy; }
    P.shieldMesh.visible = !!(P.shield && P.shield.t > 0) && !P.dead; if (P.shieldMesh.visible) { P.shieldMesh.position.set(P.x, P.y + 0.9, P.z); const k = 1 + 0.04 * Math.sin(G.t * 9); P.shieldMesh.scale.set(k * (P.form === 'mech' ? 1.8 : 1), k * (P.form === 'mech' ? 2.2 : 1), k * (P.form === 'mech' ? 1.8 : 1)); }
    if (P.noControl > 0) P.noControl -= dt;
    if (P.dead) { P.kx *= 0.9; P.kz *= 0.9; moveXZ(P, P.kx * dt, P.kz * dt); stepVertical(P, dt); this._syncRig(dt, 0); return; }
    if (G.run && G.run.frozenInput) { this._idle(dt); return; }

    const ax = P.noControl > 0 ? { x: 0, z: 0 } : Input.axis(); const mag = Math.hypot(ax.x, ax.z);
    // --- actions
    if (P.noControl <= 0) {
      if (Input.pressed('pause')) { G.ui && G.ui.pause(); }
      if (Input.pressed('jump')) P.jumpBuf = 0.14;
      if (Input.pressed('dodge') && P.rollCD <= 0 && P.rollT <= 0 && P.grounded && P.form !== 'mech' && !(P.atk && P.atk.t < P.atk.dur * 0.35)) this.startRoll(ax, mag);
      if (Input.pressed('switch')) this.cycleWeapon(1);
      if (Input.pressed('transform')) this.transform();
      if (Input.pressed('a1')) this.useAbility('a1');
      if (Input.pressed('a2')) this.useAbility('a2');
      if (Input.pressed('interact')) this.doInteract();
    }
    P.jumpBuf -= dt;
    P.attackHeld = Input.down('attack'); const atkPress = Input.pressed('attack');
    const st = this.weaponStats(); const ranged = P.form === 'hero' && this.weaponItem().cat === 'ranged';
    if (P.noControl <= 0 && P.rollT <= 0) {
      if (P.form === 'mech') { if ((P.attackHeld || atkPress) && P.shotCD <= 0) this.mechShoot(); }
      else if (ranged) { if ((P.attackHeld || atkPress) && P.shotCD <= 0) this.shootPrimary(st); }
      else if (atkPress || (P.attackHeld && !P.atk)) { if (!P.atk || P.atk.t > P.atk.dur * 0.55) { P.queued = false; this.startMelee(st); } else P.queued = true; }
    }
    if (P.atk) {
      const A = P.atk; A.t += dt;
      if (!A.hitDone && A.t >= A.hitAt) this.meleeHit();
      if (A.t >= A.dur) { P.atk = null; if (P.queued) { P.queued = false; this.startMelee(st); } }
    }
    // --- horizontal movement
    const base = (P.form === 'mech' ? 5.0 : P.form === 'titan' ? 6.6 : 6.3) * P.speedMul * (P.buffs.haste && P.buffs.haste.t > 0 ? P.buffs.haste.mult : 1);
    let tvx = ax.x * base, tvz = ax.z * base; let acc = P.grounded ? 16 : 5;
    if (P.atk) { const k = P.atk.t < P.atk.hitAt ? 0.45 : 0.25; tvx *= k; tvz *= k; }
    if (P.hurtT > 0.2) { tvx *= 0.3; tvz *= 0.3; }
    const hz = G.run && G.run.hazardSlow ? G.run.hazardSlow : 1; tvx *= hz; tvz *= hz;
    if (P.rollT > 0) {
      P.rollT -= dt; const sp = 11.5 * (P.buffs.haste && P.buffs.haste.t > 0 ? 1.1 : 1); P.vx = P.rollDir.x * sp; P.vz = P.rollDir.z * sp; P.yaw = Math.atan2(P.rollDir.x, P.rollDir.z);
      if (Math.random() < dt * 25) G.fx.dust(P.x, P.y, P.z, 1);
    } else { P.vx += (tvx - P.vx) * Math.min(1, acc * dt); P.vz += (tvz - P.vz) * Math.min(1, acc * dt); }
    if (!P.atk && P.rollT <= 0 && mag > 0.2) P.yaw = dampAng(P.yaw, Math.atan2(ax.x, ax.z), 16, dt);
    else if (P.atk) { /* keep facing */ }
    P.kx *= Math.max(0, 1 - 9 * dt); P.kz *= Math.max(0, 1 - 9 * dt);
    moveXZ(P, (P.vx + P.kx) * dt, (P.vz + P.kz) * dt);
    // --- jump / vertical
    if (P.grounded) P.coyote = 0.1; else P.coyote -= dt;
    if (P.jumpBuf > 0 && P.coyote > 0 && P.rollT <= 0 && !P.atk) { P.vy = P.form === 'mech' ? 7 : 8.6; P.grounded = false; P.coyote = 0; P.jumpBuf = 0; G.audio && G.audio.sfx('jump'); G.fx.dust(P.x, P.y, P.z, 4); }
    const wasAir = !P.grounded; const res = stepVertical(P, dt);
    if (res.landed > 4) { G.fx.dust(P.x, P.y, P.z, res.landed > 10 ? 10 : 5); G.audio && G.audio.sfx('land'); if (P.form === 'hero' && !P.atk) rig.act('land', 0.2); if (P.form !== 'hero') G.fx.addShake(0.2); if (res.landed > 15 && P.form === 'hero') { /* hard landing */ } }
    // safe spot / fall
    P.safeT -= dt;
    if (P.grounded && P.safeT <= 0 && W.lastGround && !W.lastGround.mover && P.rollT <= 0) { if (this.solidAround()) { P.safe = { x: P.x, y: P.y, z: P.z }; P.safeT = 0.3; } else P.safeT = 0.1; }
    if (P.y < W.killY) { G.run && G.run.onFall(); }
    // --- interaction detection
    this.findInteract();
    this._syncRig(dt, Math.hypot(P.vx, P.vz));
  },
  solidAround() { const W = G.W; for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const gy = W.groundAt(P.x + dx * 0.9, P.z + dz * 0.9, P.y, 0.1); if (gy < P.y - 0.6) return false; } return true; },
  startRoll(ax, mag) {
    let dx = mag > 0.2 ? ax.x / mag : Math.sin(P.yaw), dz = mag > 0.2 ? ax.z / mag : Math.cos(P.yaw);
    P.rollDir = { x: dx, z: dz }; P.rollT = 0.42; P.rollCD = 0.75; P.iframes = Math.max(P.iframes, 0.4); P.atk = null; P.comboIdx = 0;
    P.rig.act('roll', 0.45); G.audio && G.audio.sfx('roll'); G.fx.dust(P.x, P.y, P.z, 6);
  },
  mechShoot() {
    const tg = this.aimAngle(26, 0.8); if (tg) P.yaw = Math.atan2(tg.x - P.x, tg.z - P.z);
    const a = P.yaw, oy = P.y + 3.0; let dy = 0; if (tg) { const d = Math.hypot(tg.x - P.x, tg.z - P.z) || 1; dy = clamp(((tg.y || 0) + (tg.h || 1.4) * 0.5 - oy) / d, -0.5, 0.3); }
    Combat.shoot({ x: P.x + Math.sin(a) * 1.3, y: oy, z: P.z + Math.cos(a) * 1.3, dx: Math.sin(a), dy, dz: Math.cos(a), spd: 34, dmg: 20 * this.dmgOut(), team: 'p', color: 0xffa040, size: 0.22, range: 30, src: 'player', knock: 3, pierce: 1 });
    P.rig.act('shoot', 0.2); G.audio && G.audio.sfx('shoot'); G.fx.addShake(0.08); P.shotCD = 0.32;
  },
  _idle(dt) { P.vx *= 0.8; P.vz *= 0.8; stepVertical(P, dt); this._syncRig(dt, 0); },
  _syncRig(dt, spd) {
    const r = P.rig; r.root.position.set(P.x, P.y, P.z); r.root.rotation.y = P.yaw;
    r.speed = spd; r.air = P.grounded ? 0 : (P.vy > 0 ? 1 : -1);
    if (P.iframes > 0 && !P.dead && Math.floor(G.t * 20) % 2 === 0 && P.rollT <= 0 && P.iframes < 0.5) r.root.visible = false; else r.root.visible = true;
    r.update(dt);
  },
  // ------------------------------------------------------------ interaction
  findInteract() {
    let best = null, bd = 1e9;
    for (const it of G.W.interactables) {
      if (!it.enabled) continue; const dx = it.x - P.x, dz = it.z - P.z, d = Math.hypot(dx, dz); if (d > it.r || Math.abs((it.y || 0) - P.y) > 3) continue;
      if (it.type === 'mech' && P.form !== 'hero') continue;
      if (d < bd) { bd = d; best = it; }
    }
    // mech: allow dismount prompt
    P.interact = best; if (G.ui) G.ui.setPrompt(best ? best.prompt : (P.form === 'mech' ? 'النزول من الروبوت' : null), best);
  },
  doInteract() {
    if (P.form === 'mech' && !P.interact) { this.dismount(false); return; }
    const it = P.interact; if (!it) return;
    G.run && G.run.interact(it);
  },
};
