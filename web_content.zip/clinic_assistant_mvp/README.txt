CLINIC ASSISTANT MVP — STARTER PROTOTYPE

Files:
- index.html: working prototype
- manifest.webmanifest and sw.js: basic PWA support

Run locally:
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run: python -m http.server 8000
4. Visit http://localhost:8000

For Android:
- Host this app over HTTPS, then open it in Chrome on Android and choose Install app / Add to Home screen.
- This is a PWA prototype, not a Play Store APK. Native packaging can be added later.

Important:
- Data is stored in browser localStorage on the current device only.
- No cloud sync, encryption, authentication, audit log, or backup service is implemented.
- Do not enter real patient-identifiable or clinical data until security, privacy, clinical validation, backups and applicable Indian legal/compliance requirements have been addressed.
- Diagnosis matching is simple symptom-tag matching, not an AI diagnosis engine.
- Medicine entries are intentionally empty. Add only clinician-reviewed formulary data.
- Do not use as an autonomous prescribing tool.
