# V69 Excel In-App Downloads Picker Final

Built from V68. The Excel Choose File button no longer launches Android DocumentsUI or the WebView system file chooser on Android. It calls AndroidDPM.pickImportFile(), which opens the app-owned Downloads picker already present in MainActivity. Selecting a file returns its content URI to the native parser, which sends the parsed rows back to the existing import preview. Browser builds retain the normal HTML file input fallback. Version 2.35 / versionCode 39.
