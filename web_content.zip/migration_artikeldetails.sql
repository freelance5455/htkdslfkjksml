-- Unser Vorrat: zusätzliche Produktdetails im Bestand
-- Einmal im Supabase SQL Editor ausführen.

alter table public.inventory_items
  add column if not exists brand text,
  add column if not exists package_size text;

create index if not exists inventory_items_household_brand_idx
  on public.inventory_items(household_id, brand);
