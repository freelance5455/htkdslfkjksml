# SOUFI STORE V4 — Firebase setup

## Existing Firebase project
The current configuration targets project `soufi-store-6e1f1`. Keep using the existing project unless the owner explicitly decides otherwise. Confirm `.firebaserc` before deploying anything.

- `firebase-config.js` contains the web app configuration (not an Admin SDK secret).
- `firebase-init.js` initializes the Firebase client SDKs.
- Never place service-account JSON, private keys or Admin SDK credentials in the website or ZIP.

## Enable customer accounts
1. Open Firebase Console and select the intended project.
2. Go to Authentication → Sign-in method.
3. Enable Email/Password.
4. Add the deployed website domain under Authorized domains.
5. Deploy and test Firestore rules in a staging project before production.

## SOUFI STORE marketplace model
SOUFI STORE publishes independent merchants' listings and connects them with customers. It is not a wholesaler, warehouse or inventory-management system.

- Merchants submit product name, category, description, price and optional HTTPS image URL.
- Product proposals are reviewed by an administrator before publication.
- There is no stock field or stock management workflow.
- Customers request the quantities they choose. The backend accepts positive safe-integer quantities without an arbitrary 20-unit per-product cap, while validating safe arithmetic and order totals.
- Product `active`/`status` controls listing visibility and orderability; it is not a stock counter.
- The platform commission is fixed at 3%.

## First administrator — trusted workstation only
The first administrator must be an existing Firebase Authentication user. From `functions/`, run on a trusted workstation with Google Application Default Credentials:

```bash
npm install
gcloud auth application-default login
npm run admin:grant -- admin@example.com
```

To revoke:

```bash
npm run admin:revoke -- admin@example.com
```

Replace the example email with the intended account. The helper preserves other custom claims. The administrator must sign out and sign in again or refresh the ID token after the change. Do not grant roles through frontend code or a Firestore profile field.

## Deploy to staging first
Cloud Functions deployment requires the Firebase project to use the Blaze billing plan. Review billing before enabling it. Install Node.js 20 and Firebase CLI, authenticate, then run from the project root:

```bash
cd functions && npm install && cd ..
firebase deploy --only firestore:rules,firestore:indexes,storage,functions --project YOUR_STAGING_PROJECT_ID
firebase deploy --only hosting --project YOUR_STAGING_PROJECT_ID
```

Use the staging project ID until all tests pass. Production deployment requires explicit approval.

## Security boundaries
- `users`: users can read their own profile; users cannot promote themselves to seller/admin.
- `merchant_applications`: applicant can create/read their own application; only admins can review it.
- `merchants`: merchant reads are scoped to their own record; approval and status changes are trusted admin operations.
- `product_requests`: active approved merchants can submit proposals; only admins can review them.
- `products`: catalogue reads are limited to approved active products (with owner/admin access); writes are controlled by trusted backend/admin operations.
- `orders`: customer and admins can read parent orders; browser writes are denied.
- `merchant_orders` and `shipments`: reads are scoped to the customer, owning merchant and admin; browser writes are denied.
- `commissions`, `payments`, `transactions` and settlements: financial records are not writable by browser clients.
- `inventory` and `inventory_logs`: legacy records only; read access is retained for administration/owning merchant where applicable, and all writes are denied.
- Storage payment proofs are restricted by authenticated owner/admin access and size/type rules. Product image URLs are currently submitted as HTTPS links; product upload UI is not enabled.

## Operational limitations before launch
- Checkout and order creation require deployed callable Cloud Functions.
- Delivery fees are pending until an administrator confirms a delivery quote; do not treat the initial zero placeholder as a final customer price.
- BaridiMob proof upload/submission does not itself confirm payment. Admin must verify the actual transfer.
- COD collection requires reconciliation against the delivery company's remittance.
- Closing a return case is an administrative record only; it does not issue a refund or move money.
- Merchant settlements, refunds, delivery partner portal/webhooks and automated payment movement require separate trusted workflows and testing.
- SOUFI VIP/PRO subscriptions and loyalty points remain deferred; do not present them as active paid plans.

## Required verification
Run the current `FINAL_TEST_PLAN.md` in Firebase Emulator Suite or a separate staging project. Local syntax checks do not prove Firebase security, live callable behavior or end-to-end correctness. Do not accept real orders or payments until the staging gate is complete.
