# SOUFI STORE V3 — Phase 3 changelog

## Implemented in source (local development; not deployed)
- Shipment state changes now aggregate to the parent order across all merchant shipments, avoiding last-write-wins status corruption on multi-merchant orders.
- A parent order can only be marked delivered after every merchant shipment is in `out_for_delivery`.
- Failed delivery requires a reason, stores attempt count and event history, and can be retried through preparing/shipped/out-for-delivery transitions.
- Added customer return request callable for delivered orders and an admin review workflow (approve/reject/mark physically received).
- Return receipt moves the order to `returned` and moves eligible commission records to `return_review`; inventory is not automatically restored pending product inspection.
- Added admin return queue and operational report summaries (recent orders, delivery failures, commission totals, eligible merchant balances, settlements, campaign states, open returns).
- Customer order history now offers a return-request action for delivered orders and shows shipment failure reasons.
- Added Firestore read rules for return requests; client writes remain denied and all mutations use Cloud Functions.

## Important policy boundaries
- This does not automate carrier APIs; carrier assignment and tracking updates remain manual by the admin.
- Return acceptance/receipt is operational tracking only. Refunds, COD collection, BaridiMob review and final financial reversal remain intentionally deferred to the final payment stage.
- Returned goods are not automatically restocked. An inspection and explicit stock disposition process is still needed before stock is restored.
- Admin reports are bounded operational summaries (up to 300 recent orders, 500 commissions, 100 settlements, and 200 campaigns/returns); they are not an audited accounting ledger.

## Verification
- `node --check script.js`: passed.
- `node --check functions/index.js`: passed.
- JSON parsing for `firebase.json`, `firestore.indexes.json`, and `functions/package.json`: passed.
- Firebase Emulator, rules compilation, callable integration, UI browser tests, and staging deployment: not run.
