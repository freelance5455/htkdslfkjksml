# SOUFI STORE V4 — Marketplace model alignment

## Confirmed model
SOUFI STORE is a marketplace that lists products from independent merchants and records customer orders. It is not a wholesaler, does not own products, does not operate a warehouse, and does not manage stock quantities.

## Active application behavior
- Merchants submit product details, price, description and an optional image URL for administrative review.
- Product publication does not require a stock field.
- The storefront does not display stock, low-stock warnings or stock-editing controls.
- Cart quantity is a customer-requested order quantity, not an inventory amount.
- The checkout backend does not reserve, decrement, restore or check stock.
- There is no arbitrary per-product maximum of 20 units. Quantities must be positive safe integers, and calculated line/order totals must remain safe integers.
- Product `active`/`status` controls whether a listing is visible/orderable; it is not a stock counter.
- Delivery completion updates order, merchant-order, shipment, payment and commission lifecycle state only; product records are not modified.
- Return handling records the marketplace case and administrative decisions. The merchant/customer coordinate physical handling; the platform does not receive, inspect, restock or dispose of goods.
- Return-case closure requires the `merchant_confirmed_received` state. Approval alone is not sufficient.

## Legacy data compatibility
- Existing `stock` fields in old product documents are ignored and are not deleted or rewritten.
- Existing `inventory` and `inventory_logs` documents are retained as historical records. Firestore rules deny all writes to these collections.
- The deprecated `setSellerProductStock` callable returns a clear failed-precondition error for older clients.
- Older return records such as `received_inspection_required` are surfaced for manual administrative review; they are not automatically migrated or closed.
- Historical orders, payment records, commission records and audit logs are preserved.

## Financial and operational boundary
Closing a return case is not proof of a platform-side physical inspection and is not an automatic refund. Refunds and merchant settlement adjustments must use a separately approved, authorized financial workflow. The fixed launch commission remains 3%.

## Verification status
JavaScript syntax and static configuration checks can be performed locally. Firebase Emulator tests, deployed Cloud Functions tests, live Firebase authentication and browser/device end-to-end tests remain required before production deployment.
