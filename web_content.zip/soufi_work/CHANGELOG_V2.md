# SOUFI STORE V2 — Update log

## Firebase account and seller onboarding
- Firebase email/password login, customer registration, password reset and sign-out.
- Customer profile creation in Firestore.
- Seller applications stored as pending; application never grants seller privileges.

## Admin dashboard and merchant approval
- Admin access is gated by the trusted Firebase Authentication custom claim `admin: true`.
- Admin can list pending merchant applications and approve/reject them.
- Approval creates `merchants/{uid}`, updates `users/{uid}.role` to `seller`, and stores a configurable commission rate (0–50%).
- Commission rate is not yet applied to sales; secure order processing and commission settlement remain future backend work.

## Security boundaries
- No credentials, roles, orders or seller applications are trusted from localStorage.
- Firestore rules restrict admin writes, profile ownership and seller application access.
- Checkout/order writes, payment, payout, delivery assignment and product management remain disabled until trusted backend workflows are implemented.

## Required Firebase Console actions
- Enable Email/Password in Authentication.
- Publish the included `firestore.rules` after review.
- Assign the `admin: true` custom claim using Firebase Admin SDK in a trusted server environment.
- Add the deployed website domain to Authentication authorized domains.


## Product catalogue and stock proposal workflow
- Added a seller form to submit product details and initial stock for administrative review.
- Added admin moderation of product proposals; approval publishes products to Firestore.
- Added live public catalogue synchronization from approved/active Firestore products.
- Updated cart identity handling to support Firestore string document IDs.
- Tightened `product_requests` rules to require an approved, active merchant and validate fields, limits, and pending status.
- Direct stock edits remain intentionally unavailable; trusted backend inventory transactions are required before real orders.


## Trusted order processing batch
- Added Firebase Functions callable `createMarketplaceOrder` in `functions/index.js`.
- Server validates authentication, profile, approved products, approved merchants, quantities, current prices and stock.
- Uses a Firestore transaction to reserve/decrement stock and create a parent order plus merchant-specific suborders.
- Calculates per-merchant variable commission from the server-owned merchant record and writes a commission ledger entry.
- Creates platform-managed shipment placeholders; delivery company assignment and final delivery quotation remain pending.
- Added authenticated checkout form and Firebase Functions compat SDK initialization.
- Added Firestore read rules for merchant suborders and merchant-owned commission/shipment records; all order and financial writes remain server-only.
- Checkout uses cash-on-delivery as the only payment method in this build. Electronic payments are not integrated.
- Function deployment and live Firebase tests are not performed by this archive-generation environment.

## Batch 4 — delivery assignment and cancellation
- Added admin callable `assignMarketplaceDelivery` with active-company validation and server-side delivery-fee allocation.
- Added customer/admin callable `cancelMarketplaceOrder` for pending orders, with atomic stock restoration and cancellation of child records.
- Added admin delivery assignment controls and customer pre-confirmation cancellation button.
- Updated setup/security notes. Static validation only; no live Firebase deployment or emulator test was performed.

## Batch 5 — deployment readiness and administrator bootstrap
- Added `firestore.indexes.json` for the composite queries used by seller application review, product proposal review/history and approved catalogue loading.
- Wired the indexes file into `firebase.json` deployment configuration.
- Added a trusted-workstation script to grant/revoke the Firebase Authentication `admin` custom claim without embedding credentials in the project.
- Added npm commands `admin:grant` and `admin:revoke`.
- Added `FINAL_TEST_PLAN.md` with deployment commands, secure first-admin setup and a staging authorization/order/cancellation/delivery test matrix.
- This batch does not deploy Firebase or certify live behavior; staging tests remain mandatory.


## Security and launch-policy corrections
- Parent order documents (which contain the customer's full phone and delivery address) are no longer readable by individual merchants. Merchants use their own split order and shipment documents.
- Shipment records are read-only from browser clients, including admins; trusted Cloud Functions perform shipment mutations.
- Standard merchant commission is fixed at 3% for launch and is disclosed in the seller application and admin approval screen. Deferred VIP/PRO and rewards remain inactive.
