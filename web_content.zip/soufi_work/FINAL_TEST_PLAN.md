# SOUFI STORE V4 — Staging and release test plan

## Current business model
SOUFI STORE is a marketplace that publishes independent merchants' products and records customer orders. The platform does not own goods, operate a warehouse, or manage product stock.

- Merchants publish product details, price, images and description.
- Customers choose the products and the quantities they want to order.
- There is no stock field, stock limit, reservation, deduction, restocking or inventory availability check.
- Order quantities must be positive safe integers; the backend also verifies that line totals and order totals remain safe integers. There is no arbitrary per-product limit of 20 units.
- A product can be activated or paused by its merchant. This controls whether its listing can be ordered; it is not a stock counter.
- The platform commission is fixed at 3%.
- VIP/PRO paid plans and loyalty points remain deferred. Advertising-related features must not be treated as an active subscription system until separately approved.

## Before deployment
1. Use a separate Firebase staging project for tests; do not test with real customer orders.
2. Confirm the intended project ID in `.firebaserc` before any deploy.
3. Enable Email/Password in Firebase Authentication.
4. Confirm Firestore, Storage and Cloud Functions configuration, and review billing. Cloud Functions deployment requires the Blaze plan.
5. Install Node.js 20 and Firebase CLI on a trusted computer.
6. Never put service-account JSON keys or Admin SDK secrets in the ZIP, Hosting files or browser code.

## First administrator
From the `functions` directory, on a trusted workstation authenticated with Google Application Default Credentials:

```bash
npm install
gcloud auth application-default login
npm run admin:grant -- admin@example.com
```

Use the exact email of an existing Firebase Authentication account. To revoke the claim:

```bash
npm run admin:revoke -- admin@example.com
```

The helper preserves other custom claims. The administrator must sign out and sign in again, or refresh the ID token, after the claim changes. Never grant admin from browser code.

## Deploy to staging
From the project root:

```bash
cd functions && npm install && cd ..
firebase deploy --only firestore:rules,firestore:indexes,storage,functions --project YOUR_STAGING_PROJECT_ID
firebase deploy --only hosting --project YOUR_STAGING_PROJECT_ID
```

Do not replace `YOUR_STAGING_PROJECT_ID` with the production project until staging tests pass and the user explicitly approves production deployment.

## Staging test matrix
Use separate customer, approved merchant, administrator and unrelated-user accounts.

| Area | Test | Expected result |
|---|---|---|
| Authentication | Register, sign in, sign out and reset password | Firebase Auth handles the session; profile role starts as customer |
| Roles | Customer attempts to assign seller/admin role | Denied; only trusted admin workflow can approve a merchant |
| Merchant onboarding | Submit seller application | Application is pending; no seller privileges are granted yet |
| Product listing | Approved merchant submits product without stock fields | Proposal is accepted for admin review |
| Product approval | Admin approves a valid proposal | Published product has owner, price, approved status and active state; no stock field is required |
| Product ownership | Merchant A edits/pauses/deletes Merchant B's product | Denied by callable backend |
| Catalogue | Public user reads approved active products | Allowed; pending, inactive or unapproved products stay hidden |
| Quantity | Place order for 1, 20, 21 and a larger valid integer quantity | No stock-based or arbitrary 20-unit restriction; totals remain safe and correct |
| Quantity validation | Submit zero, negative, fractional, unsafe integer or overflowing line total | Rejected before order records are written |
| Checkout | Order products from multiple approved merchants | One parent order, merchant-specific child orders, commission rows and shipment rows are created |
| Price tampering | Forge price, merchant ID, commission or total in browser request | Backend ignores client financial/ownership values and uses Firestore data |
| Duplicate request | Submit the same request ID twice | Existing order is returned; no duplicate order or ledger rows |
| Product state | Attempt checkout with paused/unapproved product or inactive merchant | Rejected |
| Cancellation | Customer cancels own pending order | Order and child records are cancelled; no stock restoration is attempted |
| Cancellation authorization | Customer cancels another user's order or a confirmed order | Denied |
| Delivery | Admin assigns active delivery company and confirmed fee | Order total, payment amount and shipment allocations agree |
| Shipment lifecycle | Move each shipment through preparing, shipped and out-for-delivery | Only valid transitions are accepted; parent status reflects all shipments |
| Delivery completion | Complete delivery before all shipments are out-for-delivery | Rejected; no partial completion |
| Delivery completion | Complete after all shipments are out-for-delivery | Order and child shipment states update; product records remain unchanged |
| Returns | Customer requests return for delivered order and valid quantities | One return case is created; invalid or excessive return quantities are rejected |
| Return closure | Admin attempts closure before merchant-confirmed handling | Rejected |
| Return closure | Merchant handling is confirmed, then admin closes the case | Case closes; no physical platform inspection, stock change or inventory log is created |
| Legacy returns | Existing legacy return status is displayed | Admin sees a manual-review warning; no automatic migration or closure occurs |
| Financial privacy | Customer/merchant reads another user's private financial records | Denied |
| Browser writes | Browser attempts direct writes to orders, shipments, commissions, payments or inventory | Denied by Firestore rules |
| Historical inventory | Admin/owning merchant reads legacy inventory records | Read-only historical access; all writes are denied |

## Important release checks
- Confirm the 3% commission is calculated server-side and not editable by merchants.
- Confirm delivery fees are not invented: order totals are finalized only after an administrator confirms the delivery quote.
- BaridiMob proof submission does not mark payment paid; an administrator must verify the actual transfer record.
- COD collection must be reconciled against the delivery company's actual remittance record.
- Refunds, merchant payouts, delivery partner portal/webhooks and automatic payment movement are not considered implemented merely because a return case can be closed.
- Review legacy return records with statuses such as `received_inspection_required` manually before deployment.
- Check Firebase indexes requested by the deployed queries.
- Enable and test App Check and restrict Firebase API keys to approved domains where applicable.

## Verification status of this archive
Local JavaScript syntax and JSON configuration checks can be run during packaging. Firebase Emulator tests, deployed Cloud Functions tests, live Firebase authentication, browser/device end-to-end tests and production deployment have not been performed in this environment. This checklist is a required staging gate, not a claim that those tests have passed.
