# SOUFI STORE V3 — Phase 2 changelog

## Included
- Order/shipment status progression with server-side transition validation.
- Tracking number and shipment event records.
- Admin delivery company add/enable/disable controls.
- Admin order panel now updates each merchant shipment and confirms successful delivery through the stock-safe Cloud Function.
- Customer and seller dashboards show shipment status and tracking number.
- Merchant settlement workflow: eligible commissions only, admin-confirmed payout record, audit trail, seller-visible settlement history.
- SOUFI PRO / SOUFI VIP campaign request and admin review/price quote. Approved campaigns wait for payment and are not published yet.
- Low-stock warning in seller dashboard.
- Firestore rules and index updates for new collections and queries.

## Intentionally deferred
- BaridiMob and COD completion/verification, by project owner's instruction.
- Ad payment and campaign activation.
- Firebase Emulator, staging deployment, real-account tests, and security release gate.

## Important limitations
- Carrier tracking is manually updated; no delivery-company API integration exists.
- Settlement records document a payment confirmed by an administrator; no automatic bank/CCP transfer is performed.
- Local syntax/JSON checks do not replace Firebase integration tests.
