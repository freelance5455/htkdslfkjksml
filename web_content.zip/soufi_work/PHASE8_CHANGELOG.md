# SOUFI STORE V3 — Phase 8 repair pass

This pass continues from `SOUFI_STORE_V3_PHASE7_FINANCE_DEFERRED.zip` and stays within the agreed scope. It does not activate BaridiMob, COD collection, merchant payouts, or VIP/PRO purchases, and it does not add shipment tracking work.

## Repairs made locally

- Customer return requests now identify the exact product lines and quantities being returned; the server validates ownership, duplicate lines, and quantity bounds against the delivered order.
- A single return case is allowed per order, preventing a closed return from being reopened to restock the same items repeatedly.
- The admin return screen now displays and inspects only the requested return lines. Inspection quantities must match the approved return quantities exactly.
- Partial returns are represented explicitly as `partially_returned`; fully returned orders remain `returned`. Parent and affected merchant-order states are updated together when the returned parcel is received.
- Only commissions for affected merchants are moved to `return_review`; the deferred financial stage will reconcile their final amounts.
- Customer order history displays the return-request state and hides the return action once a return case exists.
- Shipment updates are blocked after an order has been returned or partially returned.
- Product proposal approval/rejection now runs through an admin-only callable transaction. This prevents concurrent admin clicks from publishing duplicate product documents and validates merchant status and proposal data on the server.
- Seller stock editing now rejects corrupt existing stock values rather than writing an invalid audit record.
- Admin order browsing now supports cursor-based pages of 30 records instead of being restricted to the newest 30.
- Admin CSV export now walks all order pages in batches of 500 and exports all order records, not just the visible report sample.
- The active admin settlement control surface and its callable action were removed from the current dashboard; settlement remains deferred. The existing financial backend records/functions were preserved for the final stage.
- Removed the dormant COD collection event handler from the current order screen; COD collection remains deferred.
- SOUFI VIP (customer) and SOUFI PRO (merchant) remain visual “قريباً” teasers only.

## Local verification

- `node --check script.js` — passed.
- `node --check functions/index.js` — passed.
- `node --check firebase-init.js` — passed.
- Firebase JSON configuration and package/index JSON parse — passed.
- Static invariants for return quantities, admin-only product moderation, deferred payment UI, and direct-write rules — passed.
- ZIP integrity — checked before delivery.

## Not claimed as verified

Firebase Emulator Suite, live Firebase deployment, Authentication/Firestore/Storage integration, browser/mobile behavior, and real operational end-to-end tests were not available in this local environment. This archive is a development build, not a production certification.
