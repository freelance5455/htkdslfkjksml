# SOUFI STORE V4.1 — Follow-up audit fixes

This update continues from `SOUFI_STORE_V4_MARKETPLACE_ALIGNED.zip` and preserves the approved marketplace model.

## Fixes
- Removed the leftover backend limit of 20 units per product. The checkout accepts any positive safe-integer requested quantity, subject to safe line/order arithmetic and Firestore/platform technical constraints.
- Fixed a checkout runtime defect where the product quantity variable was referenced before being assigned. Quantity is now read from the validated aggregated cart quantities map.
- Added validation for duplicate cart lines so their combined quantity must remain a safe integer.
- Kept product stock absent from checkout, product proposals and delivery/return processing.
- Changed legacy inventory Firestore records to read-only; no client or admin writes are allowed through Firestore rules.
- Restricted return-case closure to `merchant_confirmed_received`; approval alone no longer permits closure.
- Surfaced legacy return states for manual admin review instead of silently omitting them or migrating them automatically.
- Removed storefront wording that implied a platform stock/availability counter and clarified that merchants prepare orders they accept.
- Replaced outdated active setup/test documentation that still instructed operators to publish or test stock reservation/restoration.

## Local verification
- `node --check script.js`: passed.
- `node --check functions/index.js`: passed.
- `node --check functions/scripts/set-admin.js`: passed.
- Firebase JSON, Firestore indexes JSON and Functions package JSON parse: passed.
- Mocked callable checkout test: quantities 21 and 100,000 accepted with correct totals; zero rejected; unsafe total rejected.
- The mocked callable test is not a Firebase Emulator test. Emulator, deployed Functions, live Auth/Firestore and browser/device end-to-end tests remain outstanding.

## Admin setup helper
The trusted admin claim helper exists at `functions/scripts/set-admin.js`. It uses Application Default Credentials and does not include service-account secrets.
