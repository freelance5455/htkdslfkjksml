# Phase 6 manual test cases (Firebase Emulator / staging required)

## Return inspection
1. As customer A, request a return for a delivered order; confirm a duplicate open request is rejected.
2. As admin, approve the request and mark the physical parcel received.
3. Confirm the inspection UI lists each order product and its ordered quantity.
4. Select `restock` for a valid product quantity; close inspection; verify product stock increases by exactly that quantity and one `inventory_logs` record is created.
5. Select `damaged`; verify stock does not increase and the disposition is saved.
6. Try quantity 0, a quantity above the order line, an unknown product ID, and a product owned by another merchant; each must be rejected without partial writes.
7. Submit the same close-inspection request again; it must fail because the return is already closed and stock must not be incremented twice.
8. Verify non-admin users cannot call `disposeMarketplaceReturn` and direct client writes to returns/inventory logs remain denied.

## VIP / PRO teaser only
1. Public homepage shows SOUFI VIP labelled for customers and SOUFI PRO labelled for merchants, both with `قريباً`.
2. Seller dashboard has no campaign order or payment submission controls.
3. Admin dashboard displays the coming-soon notice and no campaign approval/payment actions.

## Regression / final-stage boundary
1. Verify product CRUD, shipment assignment/status updates, delivery tracking number display, return request review, and operational reports still load.
2. Do not run or enable BaridiMob/COD collection as part of this phase; those remain explicitly deferred to the final stage.
