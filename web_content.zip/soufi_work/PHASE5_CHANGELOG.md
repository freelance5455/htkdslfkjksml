# SOUFI STORE V3 — Phase 5: payment and collection workflows

## Implemented in this local working copy
- Create a trusted `payments` record for every order, including COD orders; COD starts as `awaiting_collection` rather than being represented only by an order flag.
- Keep the payment record amount synchronized with the final order total when administration confirms the delivery fee.
- Add `confirmCodCollection`: admin-only, requires a delivered COD order, an exact match to the confirmed final total, and a collection-statement reference. It is idempotent for already-paid orders, records a `cod_collections` ledger entry and audit log, and makes the associated 3% commission records eligible for merchant settlement.
- Add seller submission of an ad-campaign BaridiMob transfer reference after the campaign is approved and priced. Duplicate ad transfer references are blocked.
- Add admin-only ad payment review. A campaign becomes `active` only after an administrator confirms the transfer against the real account statement; a confirmed campaign receives a 30-day expiry timestamp. Rejected payments return to `awaiting_payment` for a new transfer reference.
- Add admin UI actions for COD collection reconciliation and ad payment review, and seller UI fields for ad-payment references.

## Local checks
- `node --check script.js`: passed.
- `node --check functions/index.js`: passed.
- JSON parse checks: passed.

## Important limits / not production-verified
- BaridiMob and ad-payment confirmation still require a human to compare the transfer reference with the actual CCP/BaridiMob statement. No bank API or automatic money movement exists.
- COD collection is reconciled manually against the delivery company's remittance statement; no carrier API is connected.
- Ad activation is recorded server-side with a 30-day expiry timestamp. Automated expiry scheduling and public ad-placement rendering remain to be integrated/verified before claiming end-to-end ad delivery.
- Merchant settlements remain an administrative record of a transfer that must actually have been sent outside the platform.
- No Firebase Emulator, deployed staging environment, live payment test, or browser/device end-to-end test was run in this environment.
