# SOUFI STORE — V3 audit and repair status

## النسخة التي تمت مراجعتها
`SOUFI_STORE.zip` — archive contains 33 entries, source root `soufi_work/`.

## إصلاحات هذه الجولة
- إضافة واجهة إدارية لمراجعة إثباتات BaridiMob: عرض رقم العملية والتاريخ والمبلغ ورابط الإثبات، مع تأكيد/رفض عبر Cloud Function الموثوقة.
- ربط إثبات BaridiMob بتكلفة التوصيل النهائية: لا يسمح الخادم بإرسال الإثبات قبل تأكيد السعر، ويُحدّث مبلغ الدفع إلى إجمالي الطلب بعد إضافة التوصيل.
- حماية مراجعة الدفع: لا يمكن اعتماد تحويل إذا لم يطابق مبلغ الدفع إجمالي الطلب النهائي، أو إذا كان الطلب ملغى/مغلقاً.
- حماية الإلغاء: تُلغى سجلات الدفع غير المدفوعة مع الطلب، ويُمنع إلغاء طلب لديه دفع قيد المراجعة أو مدفوع قبل تسوية الحالة.
- التحقق من التوقيع الفعلي لملف إثبات الدفع (PDF/JPEG/PNG/WebP) بدلاً من الاعتماد على Content-Type المرسل فقط.
- إخفاء كتالوج المنتجات التجريبي عند تفعيل Firebase؛ وعند فشل تحميل الكتالوج لا تبقى المنتجات المحلية ظاهرة على أنها منتجات حقيقية.
- إضافة فهرس Firestore لمراجعة مدفوعات BaridiMob حسب الحالة وتاريخ الإرسال.
- تقييد الطلب بحد أقصى 20 تاجراً حتى لا تُنشأ طلبات لا تستطيع وظيفة التوصيل إدارتها.
- تثبيت عمولة المنصة خادمياً على 3%؛ أي قيمة commissionRate محفوظة في ملف التاجر لا تُعتمد لحساب الطلب.

## فحوصات نفذت محلياً
- `node --check script.js`: ناجح.
- `node --check functions/index.js`: ناجح.
- `node --check firebase-init.js`: ناجح.
- التحقق من JSON: `firebase.json`, `firestore.indexes.json`, `functions/package.json`: ناجح.
- فحص سلامة الأرشيف بعد إعادة إنشائه: مطلوب/سيتم تنفيذه قبل التسليم.

## غير مختبر — لا تعتبره جاهزاً
- لم يتم تشغيل Firebase Emulator Suite أو النشر على Firebase الحقيقي.
- لم يتم اختبار Authentication وFirestore وStorage وCloud Functions بحسابات حقيقية.
- لم يتم التحقق من وصول أموال CCP/BaridiMob؛ تأكيد الدفع يتطلب مطابقة بشرية مع كشف الحساب الفعلي.
- لم يتم اختبار واجهة الهاتف على أجهزة فعلية أو متصفحات متعددة.
- لا تزال إدارة التاجر للمنتجات المنشورة والمخزون CRUD غير مكتملة.
- لا تزال إدارة المرتجعات والاسترداد والتسويات المالية ومستحقات التجار وشكاوى العملاء وتتبع الشحنات غير مكتملة.
- لا يوجد تكامل آلي موثوق مع شركات التوصيل؛ التعيين والسعر يدويان من الإدارة.
- بيانات حساب CCP/RIP الرسمية يجب إدخالها والتحقق منها من صاحب الحساب؛ لم يتم اختراع أي بيانات.

## بوابة ما قبل الإنتاج
1. تشغيل Emulator Suite واختبار قواعد Firestore/Storage لكل دور.
2. اختبار رحلة COD كاملة، بما فيها الحجز والإلغاء وإرجاع المخزون مرة واحدة.
3. اختبار BaridiMob من إنشاء الطلب إلى تثبيت التوصيل ورفع الإثبات ومراجعته ورفضه/تأكيده.
4. اختبار محاولات العبث بالسعر والكمية والهوية وملفات الإثبات وتكرار رقم العملية.
5. إعداد مشروع Firebase staging ونشر القواعد والفهارس والوظائف ثم إجراء اختبارات end-to-end.
6. عدم استقبال أموال أو فتح البيع العام قبل إغلاق النواقص أعلاه.

**الحالة:** نسخة تطوير محسّنة؛ ليست شهادة جاهزية إنتاجية.

## إصلاحات المرحلة الأولى — سياسة المخزون وإدارة منتجات التاجر
- إزالة خصم المخزون من `createMarketplaceOrder`: إنشاء الطلب لا يحجز ولا يخصم المخزون.
- إزالة إعادة المخزون من `cancelMarketplaceOrder`: الإلغاء لا يعيد كمية لم تُخصم أصلاً.
- إضافة `completeMarketplaceDelivery`: خصم المخزون داخل معاملة Firestore عند إتمام التسليم بنجاح، مع علامة `inventoryDeducted` لمنع التكرار، والتحقق الذري من الكميات لمنع تجاوز المخزون بين الطلبات المتزامنة.
- إضافة `setSellerProductStock` لتحديث الكمية مع تسجيل الفرق والكمية السابقة والجديدة في `inventory_logs`.
- إضافة `updateSellerProduct` لتعديل بيانات المنتج المنشور، و`setSellerProductActive` للإيقاف/التفعيل، و`deleteSellerProduct` للحذف المنطقي مع الحفاظ على مراجع الطلبات القديمة.
- كل عمليات التاجر أعلاه تتحقق خادمياً من هوية التاجر وملكية المنتج وحالة المتجر؛ لا يعتمد الأمان على إخفاء أزرار الواجهة.
- إضافة لوحة تعرض المنتجات المنشورة وحالة المخزون (متوفر/كمية محدودة/غير متوفر) وأزرار الإدارة.
- تحديث قواعد Firestore للسماح للتاجر بقراءة منتجاته الموقوفة وسجلات مخزونه وتدقيق منتجاته، مع منع الكتابة المباشرة لهذه السجلات.

### حدود واختبارات هذه المرحلة
- خصم الكمية الآن مرتبط بتأكيد التسليم الناجح من خلال `completeMarketplaceDelivery`. يلزم ربط زر/مسار الإدارة الذي يؤكد التسليم بهذه الوظيفة في مرحلة استكمال دورة الطلب والتوصيل.
- إذا وصلت عدة طلبات لنفس المخزون، لا يحدث حجز عند الإنشاء؛ عند تأكيد تسليم طلب، تفحص المعاملة المخزون الحالي وتخصم مرة واحدة. إذا لم تكف الكمية، تفشل عملية إتمام التسليم وتحتاج معالجة إدارية.
- فحوصات `node --check` لملفي `script.js` و`functions/index.js` وفحص JSON المحلي ناجحة.
- لم يتم تشغيل Firebase Emulator أو نشر Cloud Functions/Rules؛ لا تعتبر الوظائف الجديدة منشورة أو مختبرة على مشروع Firebase الحقيقي.


## المرحلة الثانية — دورة الطلبات والتوصيل والتسويات وطلبات الإعلانات
- إضافة Cloud Function إدارية لتحديث حالة كل شحنة: قيد التحضير، تم الشحن، خرج للتوصيل، فشل التسليم، مع قواعد انتقال تمنع الرجوع غير المنطقي للحالة.
- تسجيل رقم التتبع وسجل أحداث الشحنة.
- إضافة واجهة الإدارة لتعيين شركة التوصيل، وتحديث حالة كل شحنة ورقم تتبعها.
- إضافة إدارة شركات التوصيل: إضافة شركة وتفعيلها/إيقافها.
- ربط تأكيد التسليم في لوحة الإدارة بـ `completeMarketplaceDelivery`؛ الخصم النهائي للمخزون يتم داخل معاملة واحدة مع علامة منع التكرار.
- إظهار حالة الشحنة ورقم التتبع للعميل والتاجر.
- إضافة آلية تسوية خادمية للتاجر: تجمع العمولات المؤهلة فقط، تسجل مرجع التحويل، وتحوّل سجلات العمولة إلى settled داخل معاملة ذرية. الحد الأقصى لكل دفعة 400 سجل لتفادي حد معاملات Firestore.
- إضافة شاشة الإدارة للمستحقات المؤهلة، وشاشة التاجر لسجل التسويات.
- إضافة طلبات إعلانات SOUFI PRO وSOUFI VIP، ومراجعتها من الإدارة مع تحديد السعر المقترح. تظل الحملة `awaiting_payment` ولا تُعرض كإعلان نشط قبل استكمال الدفع والتفعيل في المرحلة الأخيرة.
- إضافة قواعد قراءة آمنة للتسويات والحملات وسجل أحداث الشحن، وفهرس العمولات المؤهلة.
- إضافة تنبيه داخل لوحة التاجر عند وجود منتجات بكمية محدودة أو منتهية.

### ما يزال مؤجلاً عمداً حسب قرار صاحب المشروع
- استكمال واختبار دورة بريدي موب.
- استكمال واختبار تحصيل COD ومطابقة الأموال.
- تفعيل الحملات الإعلانية بعد الدفع.
- اختبار Firebase Emulator والنشر على بيئة staging.
- اختبار أمني وتشغيلي شامل قبل العرض على السوق.

### حدود المرحلة الثانية
- إدارة شركات التوصيل والتتبع يدوية من لوحة الإدارة؛ لا يوجد API موصول آلياً مع شركات التوصيل.
- تسوية التاجر تسجل أن الإدارة أكدت التحويل؛ لا يتم تحويل الأموال آلياً من البنك/CCP.
- حالة الإعلان المقبول تنتظر الدفع؛ لا يظهر في الواجهة العامة حالياً.
- لم يتم تشغيل Firebase Emulator أو النشر الفعلي لعدم وجود CLI/اعتمادات المشروع في بيئة العمل.
- فحوصات syntax وJSON المحلية ناجحة، لكنها لا تثبت نجاح وظائف Firebase في بيئة حقيقية.


## المرحلة الثالثة — تحسين دورة الطلبات والمرتجعات والتقارير (تعديلات محلية)
- تجميع حالة الطلب الرئيسي اعتماداً على حالات جميع شحنات التجار بدلاً من استبدالها بآخر شحنة تم تعديلها.
- لا يمكن تأكيد تسليم الطلب الرئيسي حتى تصبح كل شحناته `out_for_delivery`.
- فشل التسليم يتطلب سبباً، ويحفظ عدد المحاولات وسجل الحدث، ويسمح بإعادة المحاولة عبر التحضير/الشحن/الخروج للتوصيل.
- إضافة طلب إرجاع من العميل للطلبات المسلّمة، ومراجعة الإدارة بالقبول أو الرفض أو تأكيد استلام المرتجع.
- عند استلام المرتجع تتحول حالة الطلب إلى `returned` وتُحجز عمولة مؤهلة للمراجعة؛ لا تتم إعادة المخزون تلقائياً قبل فحص السلعة.
- إضافة شاشة إدارة المرتجعات وتقارير تشغيلية مختصرة للطلبات والتسليم الفاشل والعمولات والمستحقات والتسويات والإعلانات والمرتجعات.
- إضافة قواعد قراءة آمنة لمجموعة `return_requests` مع منع الكتابة المباشرة من المتصفح.
- فحوصات syntax لـ JavaScript وقراءة ملفات JSON ناجحة محلياً. لم يتم تشغيل Emulator أو نشر التعديلات أو اختبار واجهات فعلية.

## المرحلة الرابعة — أدوات متابعة الطلبات والتقارير (تعديلات محلية)
- إضافة ترجمة واضحة لحالات الطلب في واجهات الإدارة والعميل والتاجر.
- إضافة البحث والتصفية حسب الحالة في قائمة الطلبات الإدارية (آخر 30 طلباً).
- توسيع التقارير لتشمل توزيع الحالات، المبيعات المسلّمة، متوسط الطلب المسلّم، الإلغاء والمرتجعات وفشل التسليم والطلبات قيد المعالجة، إضافة إلى المؤشرات المالية والتشغيلية السابقة.
- إضافة تصدير CSV لآخر 300 طلب مع دعم UTF-8 وعلامة BOM لتسهيل فتح الملف في برامج الجداول.
- إضافة زر تحديث يدوي للتقارير وتحديث المؤشرات بعد إجراءات الشحن والتسليم.
- فحوصات JavaScript وJSON المحلية ناجحة. لم يتم تشغيل Firebase Emulator أو اختبار متصفح/هاتف أو نشر فعلي.
- تبقى التقارير عينة محدودة وليست كشفاً محاسبياً نهائياً، وتبقى مطابقة COD وبريدي موب والاختبارات الأمنية النهائية مؤجلة.


## المرحلة الخامسة — دورة الدفع والتحصيل (تنفيذ محلي أولي)
- أصبح لكل طلب سجل `payments` سواء كان BaridiMob أو COD، وتبدأ حالة COD بـ `awaiting_collection`.
- مزامنة مبلغ سجل الدفع مع الإجمالي النهائي بعد تثبيت رسوم التوصيل.
- إضافة `confirmCodCollection` بصلاحية الإدارة فقط: لا يعمل إلا بعد التسليم، ويتطلب تطابق المبلغ المحصل مع الإجمالي النهائي ومرجع كشف شركة التوصيل؛ يسجل التحصيل مرة واحدة ويؤهل عمولات التجار للتسوية.
- إضافة إرسال مرجع تحويل إعلان PRO/VIP بعد اعتماد السعر، ومنع تكرار رقم العملية.
- إضافة مراجعة إدارية لدفعة الإعلان؛ لا تتحول الحملة إلى `active` إلا بعد مطابقة بشرية مع كشف الحساب، مع تاريخ انتهاء بعد 30 يوماً.
- تحديث واجهة الإدارة لتحصيل COD ومراجعة دفعات الإعلانات، وواجهة التاجر لإرسال مرجع الدفع.
- فحوصات syntax محلية ناجحة. لم يتم تشغيل Firebase Emulator أو نشر Firebase أو إجراء تحويل مالي حقيقي أو اختبار متصفح/هاتف.
- لا يوجد ربط آلي مع BaridiMob أو شركات التوصيل، ولا يتم تحويل الأموال من التطبيق. انتهاء الإعلانات الآلي وعرض مواضع الإعلانات العامة يحتاجان استكمالاً واختباراً قبل اعتبار دورة الإعلان نهائية.


## المرحلة السادسة — فحص المرتجعات وإغلاقها (تعديلات محلية)
- إضافة `disposeMarketplaceReturn` للإدارة لتسجيل نتيجة فحص كل منتج مرتجع: صالح وإعادة للمخزون، أو تالف وعدم إعادته.
- إعادة الكمية الصالحة للمخزون داخل معاملة Firestore مع التحقق من ملكية التاجر والمنتج والكمية، وتسجيل `inventory_logs`، ومنع تكرار المعالجة بعد إغلاق المرتجع.
- إضافة واجهة فحص المرتجع في لوحة الإدارة وتسجيل الكمية والقرار لكل منتج.
- إبقاء SOUFI VIP للزبائن وSOUFI PRO للتجار كإعلانين بصريين بعبارة «قريباً» فقط؛ تعطيل واجهة طلب/شراء الحملات من لوحة التاجر والإدارة حالياً.
- دفع وتحصيل BaridiMob وCOD لم يُستكملا في هذه المرحلة، حسب ترتيب صاحب المشروع، ويظلان للمرحلة الأخيرة.
- لم يتم تشغيل Firebase Emulator أو نشر التغييرات أو اختبار المتصفح/الهاتف؛ لا تعتبر هذه النسخة جاهزة للإنتاج.


## Phase 8 — consolidated repair pass (local development)
- Customer returns now carry exact selected product IDs and quantities; server-side validation checks every line against the authenticated customer's delivered order.
- Return cases are one-per-order. Admin inspection uses only approved return lines and requires exact quantities, preventing accidental full-order restock for a partial return.
- Parent and affected merchant orders distinguish `returned` from `partially_returned`; commissions for affected merchants are held in `return_review` pending the final financial reconciliation.
- Customer history displays return progress; shipment mutations are blocked for returned/partially-returned orders.
- Product proposal moderation moved to an admin-only transactional Cloud Function to prevent duplicate publication under concurrent review.
- Seller stock update validates the existing stock value before changing it.
- Admin order list has cursor pagination; CSV export fetches all order records in 500-document pages.
- Current admin dashboard no longer exposes COD collection or merchant settlement actions. Financial backend records/functions are preserved for the final stage. VIP/PRO remain coming-soon teasers.
- Local syntax, JSON, and static invariant checks passed. Firebase Emulator, staging/live deployment, browser/device, and real end-to-end checks remain unrun.


---

## V4 Addendum — Marketplace model correction (2026-11-12)

See `V4_MARKETPLACE_ALIGNMENT.md`. The confirmed business model is product listing and merchant/customer matching, not platform-owned inventory or warehousing. Stock management, stock deduction on delivery, and physical return inspection/restocking were removed from the active application workflow. Historical stock fields/logs are preserved and ignored, not destructively deleted. Emulator and live Firebase tests remain outstanding.

## V4.1 Addendum — checkout quantity and audit fixes
- Removed the remaining per-product quantity cap of 20; requested quantities are positive safe integers subject to safe total calculations.
- Fixed checkout quantity mapping so the validated requested quantity is attached to each product line before totals and merchant splits are calculated.
- Legacy inventory collections are read-only in Firestore rules.
- Return case closure now requires merchant-confirmed handling; legacy return states are surfaced for manual review.
- See `V4_1_AUDIT_FIXES.md` for local verification and remaining staging requirements.
