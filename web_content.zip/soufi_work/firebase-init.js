/* SOUFI STORE - Firebase bootstrap.
 * Initializes Firebase App, Authentication, Firestore and callable Functions.
 * Checkout requires deployment of the trusted functions in the functions/ directory.
 */
(function () {
  "use strict";
  const config = window.SOUFI_FIREBASE_CONFIG;
  const required = ["apiKey", "authDomain", "projectId", "appId", "messagingSenderId"];
  const ready = !!config && required.every(key =>
    typeof config[key] === "string" && config[key].trim() && !config[key].startsWith("REPLACE_")
  );

  if (!ready) {
    window.SOUFI_FIREBASE_READY = false;
    console.info("SOUFI STORE: Firebase config missing; account features are unavailable.");
    return;
  }
  if (!window.firebase) {
    window.SOUFI_FIREBASE_READY = false;
    console.error("SOUFI STORE: Firebase SDK failed to load.");
    return;
  }

  try {
    const app = window.firebase.apps.length
      ? window.firebase.app()
      : window.firebase.initializeApp(config);
    window.soufiFirebase = {
      app,
      auth: window.firebase.auth(),
      db: window.firebase.firestore(),
      functions: app.functions("us-central1"),
      storage: app.storage()
    };
    window.SOUFI_FIREBASE_READY = true;
    console.info("SOUFI STORE: Firebase initialized.");
  } catch (error) {
    window.SOUFI_FIREBASE_READY = false;
    console.error("SOUFI STORE: Firebase initialization failed.", error);
  }
})();
