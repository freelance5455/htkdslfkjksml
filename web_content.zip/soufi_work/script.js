"use strict";

/* SOUFI STORE V4 - Multi-merchant marketplace frontend.
   Firebase Auth manages accounts; trusted callable functions manage orders and privileged workflows.
   Product quantities are customer order quantities; the platform does not manage stock.
*/

const $ = (id) => document.getElementById(id);
const DB = {
  products: "soufi_products",
  stores: "soufi_stores",
  users: "soufi_users",
  cart: "soufi_cart",
  orders: "soufi_orders",
  current: "soufi_current",
  requests: "soufi_product_requests"
};

const initialProducts = [
  {id:1,name:"Samsung Galaxy",category:"Téléphones",price:45000,seller:"Mobile Store",sellerId:1,image:"assets/phone.svg",description:"Smartphone Samsung"},
  {id:2,name:"iPhone",category:"Téléphones",price:125000,seller:"Phone DZ",sellerId:2,image:"assets/phone.svg",description:"Smartphone Apple"},
  {id:3,name:"Ordinateur Portable",category:"Informatique",price:85000,seller:"Tech Store",sellerId:3,image:"assets/laptop.svg",description:"Ordinateur portable"},
  {id:4,name:"Casque Bluetooth",category:"Accessoires",price:3500,seller:"Mobile Store",sellerId:1,image:"assets/headphones.svg",description:"Casque sans fil"},
  {id:5,name:"Montre Connectée",category:"Accessoires",price:5000,seller:"Tech Store",sellerId:3,image:"assets/watch.svg",description:"Montre intelligente"},
  {id:6,name:"Chaussures Sport",category:"Mode",price:6500,seller:"Fashion DZ",sellerId:4,image:"assets/shoe.svg",description:"Chaussures sport"},
  {id:7,name:"Sac à dos",category:"Mode",price:4200,seller:"Fashion DZ",sellerId:4,image:"assets/bag.svg",description:"Sac à dos"},
  {id:8,name:"Lampe Moderne",category:"Maison",price:2800,seller:"Maison Plus",sellerId:5,image:"assets/lamp.svg",description:"Lampe décorative"},
  {id:9,name:"Parfum",category:"Beauté",price:5500,seller:"Beauty Shop",sellerId:6,image:"assets/perfume.svg",description:"Parfum élégant"},
  {id:10,name:"Clavier Gaming",category:"Informatique",price:7200,seller:"Tech Store",sellerId:3,image:"assets/keyboard.svg",description:"Clavier gaming"},
  {id:11,name:"Lunettes",category:"Mode",price:3000,seller:"Fashion DZ",sellerId:4,image:"assets/glasses.svg",description:"Lunettes modernes"},
  {id:12,name:"Appareil photo",category:"Accessoires",price:55000,seller:"Tech Store",sellerId:3,image:"assets/camera.svg",description:"Appareil photo"}
];

const initialStores = [
  {id:1,name:"Mobile Store",category:"Téléphones",wilaya:"Alger",icon:"📱"},
  {id:2,name:"Phone DZ",category:"Téléphones",wilaya:"Guelma",icon:"📲"},
  {id:3,name:"Tech Store",category:"Informatique",wilaya:"Constantine",icon:"💻"},
  {id:4,name:"Fashion DZ",category:"Mode",wilaya:"Annaba",icon:"👟"},
  {id:5,name:"Maison Plus",category:"Maison",wilaya:"Sétif",icon:"🏠"},
  {id:6,name:"Beauty Shop",category:"Beauté",wilaya:"Oran",icon:"✨"}
];

function load(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value === null ? fallback : JSON.parse(value);
  } catch (error) {
    console.warn("Storage read failed:", key, error);
    return fallback;
  }
}

function save(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); }
  catch (error) { console.error("Storage write failed:", key, error); notify("Impossible d'enregistrer les données sur cet appareil"); }
}

function safe(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]));
}

function price(value) {
  return Number(value || 0).toLocaleString("fr-FR") + " DA";
}

function orderStatusLabel(status) {
  return ({
    pending_confirmation: "بانتظار تأكيد الإدارة", confirmed: "تم تأكيد الطلب", preparing: "قيد التحضير",
    shipped: "تم الشحن", out_for_delivery: "خرج للتوصيل", delivery_failed: "فشل التسليم",
    delivered: "تم التسليم", returned: "مرتجع", partially_returned: "إرجاع جزئي", cancelled: "ملغى"
  })[status] || String(status || "غير محدد");
}

function filterAdminOrderCards() {
  const host = $("adminOrderList"); if (!host) return;
  const query = String(host.querySelector("#adminOrderSearch")?.value || "").trim().toLocaleLowerCase();
  const status = host.querySelector("#adminOrderStatus")?.value || "all";
  host.querySelectorAll(".admin-order-card").forEach(card => {
    const matchesText = !query || (card.dataset.search || "").includes(query);
    const matchesStatus = status === "all" || card.dataset.status === status;
    card.hidden = !(matchesText && matchesStatus);
  });
}

function notify(message) {
  const box = $("toast");
  if (!box) return;
  box.textContent = message;
  box.classList.add("show");
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => box.classList.remove("show"), 2400);
}

let products = load(DB.products, initialProducts);
let stores = load(DB.stores, initialStores);
// Never use browser storage for credentials, account roles, orders or seller applications.
localStorage.removeItem(DB.users);
localStorage.removeItem(DB.current);
localStorage.removeItem(DB.orders);
localStorage.removeItem(DB.requests);
let cart = load(DB.cart, []);
let currentUser = null;
let authReady = false;
let accountSetupInProgress = false;
let pendingOrderRequestId = null;
let pendingOrderItems = null;
let adminOrderPage = 0;
let adminOrderCursors = [];
const firebaseServices = () => window.SOUFI_FIREBASE_READY && window.soufiFirebase
  ? window.soufiFirebase : null;

if (!Array.isArray(products)) products = initialProducts;
if (!Array.isArray(stores)) stores = initialStores;
if (!Array.isArray(cart)) cart = [];

save(DB.products, products);
save(DB.stores, stores);

function getVisibleProducts() {
  const query = ($( "searchInput")?.value || "").trim().toLowerCase();
  let list = products.filter(p => {
    if (!query) return true;
    return [p.name, p.category, p.seller, p.description].some(v => String(v || "").toLowerCase().includes(query));
  });

  const sort = $("sortSelect")?.value;
  if (sort === "low") list.sort((a,b) => a.price - b.price);
  if (sort === "high") list.sort((a,b) => b.price - a.price);
  return list;
}

function displayProducts(list = getVisibleProducts()) {
  const grid = $("productGrid");
  if (!grid) return;
  grid.innerHTML = "";
  $("resultCount").textContent = `${list.length} produit${list.length > 1 ? "s" : ""}`;

  if (!list.length) {
    grid.innerHTML = '<p class="empty-state">Aucun produit trouvé.</p>';
    return;
  }

  list.forEach(p => {
    const card = document.createElement("article");
    card.className = "product";
    card.innerHTML = `
      <div class="product-img">
        <img src="${safe(p.image || "")}" alt="${safe(p.name)}" loading="lazy" onerror="this.style.display='none';this.parentElement.classList.add('emoji-fallback');this.parentElement.textContent='📦';">
        <span class="product-label">Populaire</span>
      </div>
      <div class="product-info">
        <span class="product-category">${safe(p.category)}</span>
        <h3>${safe(p.name)}</h3>
        <div class="product-price">${price(p.price)}</div>
        <p class="product-seller">🏪 ${safe(p.seller)}</p>
        <button class="add-btn" data-add="${safe(p.id)}">Ajouter au panier 🛒</button>
      </div>`;
    grid.appendChild(card);
  });
}

function displayStores() {
  const grid = $("storeGrid");
  if (!grid) return;
  grid.innerHTML = stores.map(s => `
    <div class="store">
      <div class="store-icon">${safe(s.icon || "🏪")}</div>
      <div><h3>${safe(s.name)}</h3><p>${safe(s.category)} · ${safe(s.wilaya)}</p></div>
    </div>`).join("");
}

function cartCount() { return cart.reduce((sum, item) => sum + Number(item.quantity || 0), 0); }

function cartTotal() {
  return cart.reduce((sum, item) => {
    const p = products.find(x => String(x.id) === String(item.id));
    return sum + (p ? Number(p.price) * Number(item.quantity) : 0);
  }, 0);
}

function renderCart() {
  const box = $("cartItems");
  if (!box) return;
  box.innerHTML = "";

  const validCart = cart.filter(item => products.some(p => String(p.id) === String(item.id)) && Number.isSafeInteger(Number(item.quantity)) && Number(item.quantity) >= 1);
  if (validCart.length !== cart.length) { cart = validCart; save(DB.cart, cart); }

  if (!cart.length) box.innerHTML = '<p class="empty-state">Votre panier est vide.</p>';

  cart.forEach(item => {
    const p = products.find(x => String(x.id) === String(item.id));
    if (!p) return;
    const row = document.createElement("div");
    row.className = "cart-line";
    row.innerHTML = `
      <div><b>${safe(p.name)}</b><p>${price(p.price * item.quantity)}</p></div>
      <div class="cart-controls">
        <button data-minus="${p.id}">−</button><span>${item.quantity}</span><button data-plus="${p.id}">+</button><button data-remove="${p.id}">×</button>
      </div>`;
    box.appendChild(row);
  });

  $("cartCount").textContent = cartCount();
  $("cartTotal").textContent = price(cartTotal());
}

function addToCart(id) {
  const p = products.find(x => String(x.id) === String(id));
  if (!p || p.active === false || p.status !== "approved") return notify("Produit indisponible");
  const item = cart.find(x => String(x.id) === String(id));
  if (item) {
    if (!Number.isSafeInteger(Number(item.quantity)) || Number(item.quantity) >= Number.MAX_SAFE_INTEGER) return notify("وصلت الكمية إلى الحد التقني الآمن؛ قسّم الطلب إلى طلبات منفصلة.");
    item.quantity++;
  } else cart.push({id:String(id), quantity:1});
  save(DB.cart, cart);
  renderCart();
  notify("Produit ajouté au panier");
}

function changeCart(id, action) {
  const item = cart.find(x => String(x.id) === String(id));
  const p = products.find(x => String(x.id) === String(id));
  if (!item || !p) return;
  if (action === "plus") {
    if (!Number.isSafeInteger(Number(item.quantity)) || Number(item.quantity) >= Number.MAX_SAFE_INTEGER) return notify("وصلت الكمية إلى الحد التقني الآمن؛ قسّم الطلب إلى طلبات منفصلة.");
    item.quantity++;
  } else if (action === "minus") {
    item.quantity--;
    if (item.quantity <= 0) cart = cart.filter(x => String(x.id) !== String(id));
  } else if (action === "remove") cart = cart.filter(x => String(x.id) !== String(id));
  save(DB.cart, cart);
  renderCart();
}

function openAccount() {
  $("accountModal")?.classList.add("show");
  if (!authReady) {
    showLoginForm();
    return;
  }
  if (!firebaseServices()) {
    showFirebaseUnavailable();
    return;
  }
  if (!currentUser) showLoginForm(); else showAccountHome();
}
function closeAccount() { $("accountModal")?.classList.remove("show"); }

function showFirebaseUnavailable() {
  const box = $("accountForm");
  if (!box) return;
  box.innerHTML = `<h3>Connexion momentanément indisponible</h3>
    <p class="security-notice">Firebase n'est pas initialisé. Vérifiez la configuration et le chargement du SDK avant de créer un compte.</p>`;
}

function showAccountHome() {
  const box = $("accountForm");
  if (!box || !currentUser) return;
  const roleLabel = currentUser.isAdmin ? "Administrateur" : (currentUser.role === "seller" ? "Vendeur approuvé" : "Client");
  box.innerHTML = `
    <div class="account-summary"><strong>${safe(currentUser.name || "Utilisateur")}</strong><span>${roleLabel}</span><small>${safe(currentUser.email || "")}</small></div>
    ${currentUser.isAdmin ? '<button class="form-btn" id="openAdminDashboard">لوحة الإدارة المركزية</button>' : (currentUser.role === "seller" ? '<button class="form-btn" id="openSellerDashboard">Ouvrir mon espace vendeur</button>' : '<p class="security-notice">Votre compte client est actif. Pour ouvrir une boutique, envoyez une demande de vendeur.</p><button class="form-btn" id="applySellerBtn">Demander une boutique</button>')}
    <div id="customerOrderHistory"><p>جاري تحميل سجل طلباتك...</p></div>
    <button class="form-btn secondary" id="logoutBtn">Se déconnecter</button>`;
  $("openSellerDashboard")?.addEventListener("click", () => { closeAccount(); displaySellerDashboard(); });
  $("openAdminDashboard")?.addEventListener("click", () => { closeAccount(); displayAdminDashboard(); });
  $("applySellerBtn")?.addEventListener("click", showSellerRegister);
  $("logoutBtn")?.addEventListener("click", logout);
  loadCustomerOrderHistory();
}

async function loadCustomerOrderHistory() {
  const target = $("customerOrderHistory");
  if (!target || !currentUser) return;
  try {
    const snap = await firebaseServices().db.collection("orders")
      .where("customerUid", "==", currentUser.uid).limit(20).get();
    if (!snap.size) { target.innerHTML = '<p class="empty-state">لا توجد طلبات سابقة.</p>'; return; }
    const docs = snap.docs.sort((a,b) => (b.data().createdAt?.toMillis?.() || 0) - (a.data().createdAt?.toMillis?.() || 0));
    target.innerHTML = `<div class="customer-orders"><h3>طلباتي</h3>${docs.map(doc => {
      const order = doc.data();
      return `<div class="dashboard-row customer-order-row" data-order="${safe(doc.id)}"><span><b>${safe(doc.id)}</b><small>${safe(order.wilaya)} · ${safe(orderStatusLabel(order.status))}</small><small class="customer-tracking">بيانات الشحنة...</small><small class="customer-return-state"></small></span><span><b>${price(order.total)}</b>${order.status === "pending_confirmation" ? `<button class="cancel-order-btn" data-id="${safe(doc.id)}">إلغاء الطلب</button>` : ""}${order.status === "delivered" ? `<button class="return-order-btn" data-id="${safe(doc.id)}">طلب إرجاع</button>` : ""}</span></div>`;
    }).join("")}</div>`;
    for (const doc of docs) {
      const row = target.querySelector(`[data-order="${CSS.escape(doc.id)}"]`);
      const order = doc.data(); const uids = Array.isArray(order.merchantUids) ? order.merchantUids : [];
      const shipmentSnaps = await Promise.all(uids.map(uid => firebaseServices().db.collection("shipments").doc(`${doc.id}_${uid}`).get()));
      const labels = shipmentSnaps.filter(x => x.exists).map(x => { const sh=x.data(); return `${safe(sh.deliveryCompanyName || "شركة التوصيل غير معينة")} · ${safe(sh.status || "قيد المعالجة")}${sh.trackingNumber ? " · تتبع: "+safe(sh.trackingNumber) : ""}${sh.failureReason ? " · السبب: "+safe(sh.failureReason) : ""}`; });
      const label = row?.querySelector(".customer-tracking"); if(label) label.textContent = labels.join(" | ") || "لم يتم تعيين شركة التوصيل بعد";
      const returnSnap = await firebaseServices().db.collection("return_requests").doc(doc.id).get();
      const returnLabel = row?.querySelector(".customer-return-state");
      if (returnSnap.exists && returnLabel) {
        const returnStatus = returnSnap.data().status;
        const labels = { pending_review: "طلب الإرجاع قيد المراجعة", approved: "تم قبول الإرجاع — بانتظار الاستلام", merchant_confirmed_received: "أكد التاجر استلام السلعة", closed: "أُغلق ملف الإرجاع", rejected: "تم رفض طلب الإرجاع" };
        returnLabel.textContent = labels[returnStatus] || "يوجد طلب إرجاع مسجل";
        row?.querySelector(".return-order-btn")?.remove();
      }
    }
    target.querySelectorAll(".cancel-order-btn").forEach(btn => btn.addEventListener("click", async () => {
      if (!confirm("هل تريد إلغاء الطلب؟")) return;
      btn.disabled = true;
      try {
        await firebaseServices().functions.httpsCallable("cancelMarketplaceOrder")({ orderId: btn.dataset.id });
        notify("تم إلغاء الطلب");
        await loadCustomerOrderHistory();
      } catch (error) { console.error(error); notify("تعذر إلغاء الطلب: " + (error.message || "خطأ")); btn.disabled = false; }
    }));
    target.querySelectorAll(".return-order-btn").forEach(btn => btn.addEventListener("click", async () => {
      const orderSnap = await firebaseServices().db.collection("orders").doc(btn.dataset.id).get();
      if (!orderSnap.exists) return notify("تعذر العثور على الطلب");
      const orderItems = Array.isArray(orderSnap.data().items) ? orderSnap.data().items : [];
      const items = [];
      for (const line of orderItems) {
        if (!confirm(`هل تريد إرجاع المنتج: ${line.name || line.productId}؟`)) continue;
        const quantity = Number(prompt(`كمية الإرجاع من ${line.name || line.productId} (المتاح ${Number(line.quantity)}):`, String(line.quantity)));
        if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > Number(line.quantity)) return notify("كمية الإرجاع غير صحيحة؛ أعد المحاولة");
        items.push({ productId: line.productId, quantity });
      }
      if (!items.length) return notify("لم تختر أي منتج للإرجاع");
      const reason = prompt("اذكر سبب طلب الإرجاع (5 أحرف على الأقل):");
      if (reason === null || reason.trim().length < 5) return;
      btn.disabled = true;
      try {
        await firebaseServices().functions.httpsCallable("requestMarketplaceReturn")({ orderId: btn.dataset.id, reason: reason.trim(), items });
        notify("تم إرسال طلب الإرجاع للمراجعة");
        await loadCustomerOrderHistory();
      } catch (error) { notify("تعذر إرسال طلب الإرجاع: " + (error.message || "خطأ")); btn.disabled = false; }
    }));
  } catch (error) {
    console.error("Customer order history failed:", error);
    target.innerHTML = '<p class="security-notice">تعذر تحميل سجل الطلبات.</p>';
  }
}

function showLoginForm() {
  const box = $("accountForm");
  if (!box) return;
  if (!firebaseServices()) return showFirebaseUnavailable();
  box.innerHTML = `
    <h3>Connexion</h3>
    <form id="loginForm">
      <input name="email" type="email" autocomplete="email" placeholder="Adresse e-mail" required maxlength="160">
      <input name="password" type="password" autocomplete="current-password" placeholder="Mot de passe" required minlength="6">
      <button class="form-btn" type="submit">Se connecter</button>
    </form>
    <div class="form-links"><button type="button" id="forgotPasswordBtn">Mot de passe oublié ?</button><button type="button" id="customerRegisterBtn">Créer un compte client</button><button type="button" id="sellerRegisterBtn">Demander une boutique</button></div>`;
  $("loginForm")?.addEventListener("submit", loginUser);
  $("forgotPasswordBtn")?.addEventListener("click", resetPassword);
  $("customerRegisterBtn")?.addEventListener("click", showCustomerRegister);
  $("sellerRegisterBtn")?.addEventListener("click", showSellerRegister);
}

function showCustomerRegister() {
  const box = $("accountForm");
  if (!box) return;
  if (!firebaseServices()) return showFirebaseUnavailable();
  box.innerHTML = `<h3>Créer un compte client</h3>
    <form id="customerRegisterForm">
      <input name="name" placeholder="Nom complet" required maxlength="80" autocomplete="name">
      <input name="email" type="email" placeholder="Adresse e-mail" required maxlength="160" autocomplete="email">
      <input name="password" type="password" placeholder="Mot de passe (8 caractères minimum)" required minlength="8" autocomplete="new-password">
      <input name="phone" type="tel" placeholder="Téléphone (facultatif)" maxlength="25" autocomplete="tel">
      <button class="form-btn" type="submit">Créer mon compte</button>
    </form>
    <div class="form-links"><button type="button" id="backToLogin">Retour à la connexion</button></div>`;
  $("customerRegisterForm")?.addEventListener("submit", registerCustomer);
  $("backToLogin")?.addEventListener("click", showLoginForm);
}

function showSellerRegister() {
  const box = $("accountForm");
  if (!box) return;
  if (!firebaseServices()) return showFirebaseUnavailable();
  const loggedIn = !!currentUser;
  box.innerHTML = `<h3>Demande d'ouverture de boutique</h3>
    <p class="security-notice">Votre demande sera examinée par l'administration. Après approbation, une commission de 3% sera prélevée sur chaque vente finalisée via SOUFI STORE. L'envoi ne vous donne pas automatiquement les droits vendeur.</p>
    <form id="sellerApplicationForm">
      ${loggedIn ? "" : '<input name="name" placeholder="Votre nom complet" required maxlength="80" autocomplete="name">'}
      <input name="storeName" placeholder="Nom souhaité de la boutique" required maxlength="80">
      ${loggedIn ? "" : '<input name="email" type="email" placeholder="Adresse e-mail" required maxlength="160" autocomplete="email"><input name="password" type="password" placeholder="Mot de passe (8 caractères minimum)" required minlength="8" autocomplete="new-password">'}
      <input name="phone" type="tel" placeholder="Téléphone" required minlength="5" maxlength="25" autocomplete="tel" value="${safe(currentUser?.phone || "")}">
      <select name="category" required><option value="">Catégorie principale</option><option>Téléphones</option><option>Informatique</option><option>Accessoires</option><option>Mode</option><option>Maison</option><option>Beauté</option><option>Sport</option><option>Autre</option></select>
      <input name="wilaya" placeholder="Wilaya" required maxlength="60">
      <button class="form-btn" type="submit">Envoyer ma demande</button>
    </form>
    <div class="form-links"><button type="button" id="backToAccount">Retour</button></div>`;
  $("sellerApplicationForm")?.addEventListener("submit", registerSellerApplication);
  $("backToAccount")?.addEventListener("click", () => currentUser ? showAccountHome() : showLoginForm());
}

async function loginUser(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const submit = form.querySelector('button[type="submit"]');
  submit.disabled = true;
  try {
    const {auth, db} = firebaseServices();
    const email = String(new FormData(form).get("email") || "").trim().toLowerCase();
    const password = String(new FormData(form).get("password") || "");
    const credential = await auth.signInWithEmailAndPassword(email, password);
    const snap = await db.collection("users").doc(credential.user.uid).get();
    if (!snap.exists) {
      await auth.signOut();
      throw new Error("PROFILE_MISSING");
    }
    const tokenInfo = await credential.user.getIdTokenResult(true);
    currentUser = {id: credential.user.uid, uid: credential.user.uid, email: credential.user.email, ...snap.data(), isAdmin: tokenInfo.claims.admin === true};
    updateAccountUI(); showAccountHome(); notify("Connexion réussie");
  } catch (error) {
    console.error("Login failed:", error);
    notify(authErrorMessage(error));
  } finally { submit.disabled = false; }
}

async function registerCustomer(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const submit = form.querySelector('button[type="submit"]');
  submit.disabled = true;
  const data = new FormData(form);
  const name = String(data.get("name") || "").trim();
  const email = String(data.get("email") || "").trim().toLowerCase();
  const password = String(data.get("password") || "");
  const phone = String(data.get("phone") || "").trim();
  let createdUser = null;
  let auth = null;
  accountSetupInProgress = true;
  try {
    const services = firebaseServices();
    auth = services.auth;
    const db = services.db;
    const credential = await auth.createUserWithEmailAndPassword(email, password);
    createdUser = credential.user;
    await credential.user.updateProfile({displayName: name});
    const stamp = window.firebase.firestore.FieldValue.serverTimestamp();
    await db.collection("users").doc(credential.user.uid).set({
      uid: credential.user.uid, name, email, phone, role: "customer",
      createdAt: stamp, updatedAt: stamp
    });
    currentUser = {id: credential.user.uid, uid: credential.user.uid, name, email, phone, role: "customer"};
    updateAccountUI(); showAccountHome(); notify("Votre compte a été créé");
  } catch (error) {
    console.error("Customer registration failed:", error);
    if (createdUser && auth?.currentUser?.uid === createdUser.uid) {
      try { await createdUser.delete(); } catch (cleanupError) { console.warn("Could not roll back incomplete signup:", cleanupError); }
    }
    notify(authErrorMessage(error));
  } finally { accountSetupInProgress = false; submit.disabled = false; }
}

async function registerSellerApplication(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const submit = form.querySelector('button[type="submit"]');
  submit.disabled = true;
  const data = new FormData(form);
  const loggedIn = !!currentUser;
  const name = loggedIn ? String(currentUser.name || "").trim() : String(data.get("name") || "").trim();
  const storeName = String(data.get("storeName") || "").trim();
  const email = loggedIn ? String(currentUser.email || "").trim().toLowerCase() : String(data.get("email") || "").trim().toLowerCase();
  const password = String(data.get("password") || "");
  const phone = String(data.get("phone") || currentUser?.phone || "").trim();
  const category = String(data.get("category") || "");
  const wilaya = String(data.get("wilaya") || "").trim();
  let newlyCreatedUser = null;
  let auth = null;
  if (!loggedIn) accountSetupInProgress = true;
  try {
    const services = firebaseServices();
    auth = services.auth;
    const db = services.db;
    let uid = currentUser?.uid;
    if (!loggedIn) {
      const credential = await auth.createUserWithEmailAndPassword(email, password);
      newlyCreatedUser = credential.user;
      await credential.user.updateProfile({displayName: name});
      uid = credential.user.uid;
    }
    const stamp = window.firebase.firestore.FieldValue.serverTimestamp();
    const batch = db.batch();
    if (!loggedIn) {
      batch.set(db.collection("users").doc(uid), {uid, name, email, phone, role: "customer", createdAt: stamp, updatedAt: stamp});
    }
    const applicationRef = db.collection("merchant_applications").doc(uid);
    batch.set(applicationRef, {ownerUid: uid, ownerName: name, email, phone, storeName, category, wilaya, status: "pending", createdAt: stamp});
    await batch.commit();
    if (!loggedIn) {
      currentUser = {id: uid, uid, name, email, phone, role: "customer"};
      updateAccountUI();
    }
    $("accountForm").innerHTML = `<div class="account-summary"><strong>Demande envoyée</strong><span>Votre demande d'ouverture de boutique est en attente d'examen par l'administration.</span><small>Référence : ${safe(applicationRef.id)}</small></div><button class="form-btn secondary" id="closeApplicationNotice">Fermer</button>`;
    $("closeApplicationNotice")?.addEventListener("click", closeAccount);
    notify("Demande envoyée à l'administration");
  } catch (error) {
    console.error("Seller application failed:", error);
    if (newlyCreatedUser && auth?.currentUser?.uid === newlyCreatedUser.uid) {
      try { await newlyCreatedUser.delete(); } catch (cleanupError) { console.warn("Could not roll back incomplete signup:", cleanupError); }
    }
    notify(authErrorMessage(error));
  } finally { if (!loggedIn) accountSetupInProgress = false; submit.disabled = false; }
}

async function resetPassword() {
  const email = prompt("Saisissez votre adresse e-mail :");
  if (!email) return;
  try {
    await firebaseServices().auth.sendPasswordResetEmail(email.trim().toLowerCase());
    notify("Si ce compte existe, un e-mail de réinitialisation a été envoyé");
  } catch (error) { console.error("Password reset failed:", error); notify(authErrorMessage(error)); }
}

async function logout() {
  try {
    await firebaseServices().auth.signOut();
    currentUser = null; updateAccountUI(); $("sellerDashboard")?.classList.remove("show");
    showLoginForm(); notify("Déconnexion réussie");
  } catch (error) { console.error("Logout failed:", error); notify("Impossible de se déconnecter maintenant"); }
}

function authErrorMessage(error) {
  const code = error?.code || error?.message;
  const messages = {
    "auth/email-already-in-use": "Cette adresse e-mail est déjà utilisée.",
    "auth/invalid-email": "Adresse e-mail invalide.",
    "auth/weak-password": "Choisissez un mot de passe plus fort (8 caractères minimum).",
    "auth/user-not-found": "Aucun compte trouvé avec cette adresse.",
    "auth/wrong-password": "Mot de passe incorrect.",
    "auth/invalid-credential": "E-mail ou mot de passe incorrect.",
    "auth/too-many-requests": "Trop de tentatives. Réessayez plus tard.",
    "permission-denied": "Accès refusé par les règles de sécurité Firestore.",
    "PROFILE_MISSING": "Profil utilisateur introuvable. Contactez l'assistance."
  };
  return messages[code] || "Une erreur est survenue. Vérifiez votre connexion et réessayez.";
}

function updateAccountUI() {
  const btn = $("accountBtn");
  if (!btn) return;
  btn.textContent = currentUser ? `♙ ${currentUser.name}` : "♙ Compte";
}


async function displayAdminDashboard() {
  if (!currentUser?.isAdmin) return notify("Accès réservé للإدارة المعتمدة");
  const box = $("sellerDashboard");
  if (!box) return;
  box.classList.add("show");
  box.innerHTML = `<div class="dashboard-head"><div><h2>لوحة الإدارة المركزية</h2><p>إدارة التجار ومراجعة المنتجات</p></div><button class="close" id="closeAdminDashboard">×</button></div>
    <h3>طلبات فتح المتاجر</h3><div id="adminApplicationList"><p>جاري تحميل الطلبات...</p></div>
    <h3>طلبات نشر المنتجات</h3><div id="adminProductRequestList"><p>جاري تحميل المنتجات المقترحة...</p></div>
    <h3>الدفع والتحصيل</h3><p class="security-notice">BaridiMob وCOD والتسويات المالية مؤجلة إلى المرحلة الأخيرة قبل الإطلاق. لا توجد إجراءات دفع أو تحصيل متاحة حالياً.</p>
    <h3>الطلبات وإدارة الشحن</h3><div id="adminOrderList"><p>جاري تحميل الطلبات...</p></div>
    <h3>طلبات المرتجعات وفشل التسليم</h3><div id="adminReturns"><p>جاري تحميل المرتجعات...</p></div>
    <h3>تقارير الإدارة</h3><div id="adminReports"><p>جاري إعداد التقارير...</p></div>
    <h3>شركات التوصيل</h3><div id="adminDeliveryCompanies"></div>
    <h3>تسويات التجار</h3><p class="security-notice">تسويات التجار مؤجلة إلى المرحلة الأخيرة مع دورة الدفع والتحصيل.</p>
    <h3>SOUFI VIP وSOUFI PRO</h3><p class="security-notice">الخدمتان قادمتان قريباً: SOUFI VIP للزبائن وSOUFI PRO للتجار. لا توجد طلبات أو دفعات إعلانية مفعّلة حالياً.</p>`;
  $("closeAdminDashboard")?.addEventListener("click", () => box.classList.remove("show"));
  const db = firebaseServices().db;
  try {
    const snap = await db.collection("merchant_applications").where("status", "==", "pending").orderBy("createdAt", "desc").limit(50).get();
    const list = $("adminApplicationList");
    if (!snap.size) { list.innerHTML = '<p class="empty-state">لا توجد طلبات متاجر معلّقة حالياً.</p>'; }
    else list.innerHTML = `<div class="admin-list">${snap.docs.map(doc => {
      const a = doc.data();
      return `<article class="admin-application" data-application="${safe(doc.id)}"><div><h3>${safe(a.storeName)}</h3><p>${safe(a.ownerName)} · ${safe(a.email)}</p><small>${safe(a.category)} · ${safe(a.wilaya)} · ${safe(a.phone)}</small></div><p class="commission-notice">عمولة المنصة: <strong>3%</strong> من كل عملية بيع مكتملة</p><div class="admin-actions"><button class="approve-application" data-uid="${safe(doc.id)}">قبول المتجر</button><button class="reject-application" data-uid="${safe(doc.id)}">رفض الطلب</button></div></article>`;
    }).join("")}</div>`;
    list.querySelectorAll(".approve-application").forEach(btn => btn.addEventListener("click", () => reviewMerchantApplication(btn.dataset.uid, true, btn.closest(".admin-application"))));
    list.querySelectorAll(".reject-application").forEach(btn => btn.addEventListener("click", () => reviewMerchantApplication(btn.dataset.uid, false, btn.closest(".admin-application"))));
  } catch (error) {
    console.error("Admin applications load failed:", error);
    $("adminApplicationList").innerHTML = '<p class="security-notice">تعذر تحميل الطلبات. تحقق من صلاحية المدير وقواعد Firestore.</p>';
  }
  try {
    const snap = await db.collection("product_requests").where("status", "==", "pending").orderBy("createdAt", "desc").limit(50).get();
    const list = $("adminProductRequestList");
    if (!snap.size) list.innerHTML = '<p class="empty-state">لا توجد منتجات تنتظر المراجعة.</p>';
    else {
      list.innerHTML = `<div class="admin-list">${snap.docs.map(doc => {
        const item = doc.data();
        return `<article class="admin-application product-review" data-request="${safe(doc.id)}">
          <div><h3>${safe(item.name)}</h3><p>${safe(item.category)} · ${price(item.price)}</p><small>${safe(item.storeName)} · ${safe(item.ownerUid)}</small>${item.description ? `<p>${safe(item.description)}</p>` : ""}</div>
          <div class="admin-actions"><button class="approve-product" data-id="${safe(doc.id)}">نشر المنتج</button><button class="reject-product" data-id="${safe(doc.id)}">رفض</button></div>
        </article>`;
      }).join("")}</div>`;
      list.querySelectorAll(".approve-product").forEach(btn => btn.addEventListener("click", () => reviewProductRequest(btn.dataset.id, true, btn.closest(".product-review"))));
      list.querySelectorAll(".reject-product").forEach(btn => btn.addEventListener("click", () => reviewProductRequest(btn.dataset.id, false, btn.closest(".product-review"))));
    }
  } catch (error) {
    console.error("Admin product requests load failed:", error);
    $("adminProductRequestList").innerHTML = '<p class="security-notice">تعذر تحميل طلبات المنتجات. تحقق من قواعد Firestore والفهارس.</p>';
  }
  // Payment review and collection controls are intentionally deferred to the final stage.
  await loadAdminOrders(true);
  await loadAdminReturns();
  await loadAdminReports();
  await loadAdminDeliveryCompanies();
  // Merchant settlement controls remain hidden until the final payment/collection stage.
}

async function loadAdminPayments() {
  const target = $("adminPaymentReviewList");
  if (!target || !currentUser?.isAdmin) return;
  try {
    const snap = await firebaseServices().db.collection("payments")
      .where("status", "==", "under_review").orderBy("submittedAt", "desc").limit(50).get();
    if (!snap.size) { target.innerHTML = '<p class="empty-state">لا توجد تحويلات تنتظر المراجعة.</p>'; return; }
    const cards = await Promise.all(snap.docs.map(async doc => {
      const payment = doc.data();
      let proofUrl = "";
      try { if (payment.proofPath) proofUrl = await firebaseServices().storage.ref(payment.proofPath).getDownloadURL(); } catch (error) { console.warn("Payment proof unavailable:", doc.id, error); }
      return `<article class="admin-application payment-review" data-payment="${safe(doc.id)}">
        <div><h3>طلب ${safe(doc.id)}</h3><p>المبلغ النهائي: <strong>${price(payment.amount)}</strong></p>
        <small>رقم العملية: ${safe(payment.operationNumber)} · التاريخ: ${safe(payment.operationDate)}</small>
        ${proofUrl ? `<p><a href="${safe(proofUrl)}" target="_blank" rel="noopener noreferrer">فتح إثبات التحويل</a></p>` : '<p class="security-notice">تعذر فتح ملف الإثبات؛ تحقق من صلاحيات Storage.</p>'}</div>
        <div class="admin-actions"><button class="confirm-payment" ${proofUrl ? '' : 'disabled'}>تأكيد وصول المبلغ</button><button class="reject-payment">رفض الإثبات</button></div>
      </article>`;
    }));
    target.innerHTML = cards.join("");
    target.querySelectorAll(".payment-review").forEach(card => {
      card.querySelector(".confirm-payment")?.addEventListener("click", () => reviewBaridiPayment(card, "confirmed"));
      card.querySelector(".reject-payment")?.addEventListener("click", () => reviewBaridiPayment(card, "rejected"));
    });
  } catch (error) {
    console.error("Admin payment review load failed:", error);
    target.innerHTML = '<p class="security-notice">تعذر تحميل إثباتات الدفع. تحقق من صلاحيات المدير والفهارس.</p>';
  }
}

async function reviewBaridiPayment(card, decision) {
  if (!currentUser?.isAdmin) return notify("غير مصرح بهذه العملية");
  const reason = decision === "rejected" ? (prompt("سبب رفض إثبات التحويل:") || "").trim() : "";
  if (decision === "rejected" && reason.length < 3) return notify("يجب إدخال سبب واضح للرفض");
  const buttons = card.querySelectorAll("button"); buttons.forEach(button => button.disabled = true);
  try {
    await firebaseServices().functions.httpsCallable("reviewBaridiMobPayment")({ orderId: card.dataset.payment, decision, reason });
    notify(decision === "confirmed" ? "تم تأكيد الدفع بعد التحقق" : "تم رفض إثبات الدفع");
    await loadAdminPayments();
  } catch (error) {
    console.error("BaridiMob review failed:", error);
    notify("تعذرت مراجعة الدفع: " + (error.message || "خطأ"));
    buttons.forEach(button => button.disabled = false);
  }
}

async function loadAdminOrders(reset = false) {
  const target = $("adminOrderList");
  if (!target || !currentUser?.isAdmin) return;
  if (reset) { adminOrderPage = 0; adminOrderCursors = []; }
  try {
    const db = firebaseServices().db;
    let ordersQuery = db.collection("orders").orderBy("createdAt", "desc");
    if (adminOrderPage > 0) {
      const cursor = adminOrderCursors[adminOrderPage - 1];
      if (cursor) ordersQuery = ordersQuery.startAfter(cursor);
      else { adminOrderPage = 0; adminOrderCursors = []; }
    }
    const [snap, companiesSnap] = await Promise.all([
      ordersQuery.limit(31).get(),
      db.collection("delivery_companies").where("active", "==", true).get()
    ]);
    const pageDocs = snap.docs.slice(0, 30);
    const hasMore = snap.docs.length > 30;
    if (!pageDocs.length) {
      target.innerHTML = `<p class="empty-state">لا توجد طلبات في هذه الصفحة.</p>${adminOrderPage > 0 ? '<button type="button" id="adminOrdersPrev">الصفحة السابقة</button>' : ''}`;
      target.querySelector("#adminOrdersPrev")?.addEventListener("click", () => { adminOrderPage = Math.max(0, adminOrderPage - 1); loadAdminOrders(); });
      return;
    }
    const companyOptions = companiesSnap.docs.map(d => `<option value="${safe(d.id)}">${safe(d.data().name || d.data().companyName || d.id)}</option>`).join("");
    const shipmentByOrder = new Map();
    await Promise.all(pageDocs.map(async doc => {
      const sh = await db.collection("shipments").where("orderId", "==", doc.id).get();
      shipmentByOrder.set(doc.id, sh.docs);
    }));
    target.innerHTML = `<div class="orders-toolbar"><input id="adminOrderSearch" type="search" placeholder="ابحث برقم الطلب أو اسم العميل أو الهاتف أو الولاية"><select id="adminOrderStatus"><option value="all">كل الحالات</option><option value="pending_confirmation">بانتظار التأكيد</option><option value="confirmed">مؤكد</option><option value="preparing">قيد التحضير</option><option value="shipped">تم الشحن</option><option value="out_for_delivery">خرج للتوصيل</option><option value="delivery_failed">فشل التسليم</option><option value="delivered">تم التسليم</option><option value="returned">مرتجع</option><option value="partially_returned">إرجاع جزئي</option><option value="cancelled">ملغى</option></select><small>الصفحة ${adminOrderPage + 1} · ${pageDocs.length} طلبات</small></div><div class="admin-list">${pageDocs.map(doc => {
      const o = doc.data();
      const itemNames = (o.items || []).map(item => `${safe(item.name)} × ${Number(item.quantity)}`).join("، ");
      const canAssign = ["pending_confirmation", "confirmed"].includes(o.status) && companyOptions;
      const shipments = shipmentByOrder.get(doc.id) || [];
      const shipControls = shipments.map(shDoc => {
        const sh = shDoc.data();
        const options = [["preparing","قيد التحضير"],["shipped","تم الشحن"],["out_for_delivery","خرج للتوصيل"],["delivery_failed","فشل التسليم"]];
        return `<div class="delivery-assignment" data-merchant="${safe(sh.merchantUid)}"><small>شحنة التاجر ${safe(sh.storeName || sh.merchantUid)} · ${safe(orderStatusLabel(sh.status || "assigned"))}${sh.trackingNumber ? " · التتبع: " + safe(sh.trackingNumber) : ""}${sh.failureReason ? " · سبب الفشل: " + safe(sh.failureReason) : ""} · محاولات التسليم: ${Number(sh.deliveryAttemptCount || 0)}</small><select class="shipment-status">${options.map(([v,l])=>`<option value="${v}" ${sh.status===v?'selected':''}>${l}</option>`).join("")}</select><input class="tracking-number" maxlength="100" value="${safe(sh.trackingNumber || "")}" placeholder="رقم التتبع"><input class="failure-reason" maxlength="300" placeholder="سبب فشل التسليم (إجباري عند الفشل)"><button class="update-shipment-btn">تحديث الشحنة</button></div>`;
      }).join("");
      const canDeliver = o.status === "out_for_delivery";
      const searchText = `${doc.id} ${o.customerName || ""} ${o.phone || ""} ${o.wilaya || ""}`.toLocaleLowerCase();
      return `<article class="admin-application admin-order-card" data-order="${safe(doc.id)}" data-status="${safe(o.status)}" data-search="${safe(searchText)}"><div><h3>طلب ${safe(doc.id)}</h3><p>${safe(o.customerName)} · ${safe(o.phone)} · ${safe(o.wilaya)}</p><small>${itemNames}</small><p><b>${price(o.total)}</b> · ${safe(orderStatusLabel(o.status))} · الدفع: ${safe(o.paymentStatus || "غير مدفوع")}</p>${canAssign ? `<div class="delivery-assignment"><select class="delivery-company"><option value="">شركة التوصيل</option>${companyOptions}</select><input class="delivery-fee" type="number" min="0" step="1" placeholder="سعر التوصيل بالدج"><button class="assign-delivery-btn">تأكيد التوصيل</button></div>` : ""}${shipControls}${canDeliver ? `<button class="complete-delivery-btn">تأكيد إتمام التسليم</button>` : ""}</div></article>`;
    }).join("")}</div><div class="report-actions">${adminOrderPage > 0 ? '<button type="button" id="adminOrdersPrev">الصفحة السابقة</button>' : ''}${hasMore ? '<button type="button" id="adminOrdersNext">الصفحة التالية</button>' : ''}</div>`;
    target.querySelector("#adminOrdersPrev")?.addEventListener("click", () => { adminOrderPage = Math.max(0, adminOrderPage - 1); loadAdminOrders(); });
    target.querySelector("#adminOrdersNext")?.addEventListener("click", () => { adminOrderCursors[adminOrderPage] = pageDocs[pageDocs.length - 1]; adminOrderPage += 1; loadAdminOrders(); });
    target.querySelector("#adminOrderSearch")?.addEventListener("input", filterAdminOrderCards);
    target.querySelector("#adminOrderStatus")?.addEventListener("change", filterAdminOrderCards);
    target.querySelectorAll(".assign-delivery-btn").forEach(btn => btn.addEventListener("click", async () => {
      const card = btn.closest(".admin-order-card");
      const companyId = card.querySelector(".delivery-company").value;
      const fee = Number(card.querySelector(".delivery-fee").value);
      if (!companyId || !Number.isSafeInteger(fee) || fee < 0) return notify("اختر شركة وأدخل سعر توصيل صحيح");
      btn.disabled = true;
      try {
        await firebaseServices().functions.httpsCallable("assignMarketplaceDelivery")({ orderId: card.dataset.order, companyId, deliveryFee: fee });
        notify("تم تعيين شركة التوصيل وتأكيد السعر"); await loadAdminOrders(); await loadAdminReports();
      } catch (error) { console.error(error); notify("فشل تعيين التوصيل: " + (error.message || "خطأ")); btn.disabled = false; }
    }));
    target.querySelectorAll(".update-shipment-btn").forEach(btn => btn.addEventListener("click", async () => {
      const row = btn.closest(".delivery-assignment"); const card = btn.closest(".admin-order-card"); btn.disabled = true;
      try {
        await firebaseServices().functions.httpsCallable("updateMarketplaceShipment")({ orderId: card.dataset.order, merchantUid: row.dataset.merchant, status: row.querySelector(".shipment-status").value, trackingNumber: row.querySelector(".tracking-number").value, failureReason: row.querySelector(".failure-reason")?.value || "" });
        notify("تم تحديث حالة الشحنة"); await loadAdminOrders(); await loadAdminReports();
      } catch (e) { notify("تعذر تحديث الشحنة: " + (e.message || "خطأ")); btn.disabled = false; }
    }));
    target.querySelectorAll(".complete-delivery-btn").forEach(btn => btn.addEventListener("click", async () => {
      const card = btn.closest(".admin-order-card"); if (!confirm("تأكيد أن الطلب سُلّم بنجاح؟")) return;
      btn.disabled = true;
      try { await firebaseServices().functions.httpsCallable("completeMarketplaceDelivery")({ orderId: card.dataset.order }); notify("تم تأكيد إتمام التسليم"); await loadAdminOrders(); await loadAdminReports(); }
      catch(e) { notify("تعذر إتمام التسليم: " + (e.message || "خطأ")); btn.disabled = false; }
    }));
  } catch (error) {
    console.error("Admin orders load failed:", error);
    target.innerHTML = '<p class="security-notice">تعذر تحميل الطلبات. تحقق من صلاحيات Firestore.</p>';
  }
}

async function loadAdminReturns() {
  const host = $('adminReturns'); if (!host || !currentUser?.isAdmin) return;
  try {
    const snap = await firebaseServices().db.collection('return_requests').where('status', 'in', ['pending_review','approved','merchant_confirmed_received','received_inspection_required','received']).limit(100).get();
    const cards = await Promise.all(snap.docs.map(async d => {
      const v=d.data();
      const orderSnap=await firebaseServices().db.collection('orders').doc(d.id).get();
      const items=Array.isArray(v.items) ? v.items : (orderSnap.exists && Array.isArray(orderSnap.data().items) ? orderSnap.data().items : []);
      const itemSummary=items.map(line=>`${safe(line.name || line.productId)} × ${Number(line.quantity||0)}`).join('، ');
      const inspection=v.status==='merchant_confirmed_received' ? `<div class="return-inspection"><p>أكد التاجر معالجة استلام السلعة مع الزبون. لا يوجد استلام أو فحص مادي لدى المنصة.</p><button class="close-return-inspection">إغلاق ملف الإرجاع</button></div>` : (['received_inspection_required','received'].includes(v.status) ? '<p class="security-notice">سجل إرجاع قديم من إصدار سابق؛ يلزم مراجعته يدوياً ولا يمكن إغلاقه تلقائياً.</p>' : '');
      return `<article class="admin-application" data-return="${safe(d.id)}"><b>طلب ${safe(d.id)}</b><p>${safe(v.reason || '')}</p><small>المنتجات والكميات: ${itemSummary}</small><small>الحالة: ${safe(v.status)}</small><textarea class="return-note" maxlength="500" placeholder="ملاحظة الإدارة">${safe(v.adminNote||'')}</textarea><div class="admin-actions">${v.status==='pending_review'?'<button data-return-decision="approved">قبول الإرجاع</button><button data-return-decision="rejected">رفض</button>':''}${v.status==='approved'?'<button data-return-decision="received">تأكيد التاجر استلام السلعة</button>':''}</div>${inspection}</article>`;
    }));
    host.innerHTML = cards.length ? `<div class="admin-list">${cards.join('')}</div>` : '<p class="empty-state">لا توجد طلبات مرتجعات معلقة.</p>';
    host.querySelectorAll('[data-return]').forEach(card => {
      card.querySelectorAll('[data-return-decision]').forEach(btn => btn.addEventListener('click', async () => {
        const decision=btn.dataset.returnDecision; if(decision==='received' && !confirm('هل أكد التاجر استلام السلعة أو معالجة الإرجاع مع الزبون؟')) return;
        btn.disabled=true; try { await firebaseServices().functions.httpsCallable('reviewMarketplaceReturn')({orderId:card.dataset.return,decision,note:card.querySelector('.return-note')?.value||''}); notify('تم تحديث طلب الإرجاع'); await loadAdminReturns(); await loadAdminReports(); } catch(e) { notify('تعذر تحديث الإرجاع: '+(e.message||'خطأ')); btn.disabled=false; }
      }));
      card.querySelector('.close-return-inspection')?.addEventListener('click', async btnEvent => {
        const button=btnEvent.currentTarget;
        const quantities=[...card.querySelectorAll('.return-quantity')];
        const dispositions=quantities.map(input=>({productId:input.dataset.product,quantity:Number(input.value),disposition:card.querySelector(`.return-disposition[data-product="${CSS.escape(input.dataset.product)}"]`)?.value}));
        if(!confirm('إغلاق ملف الإرجاع؟ لا تستلم المنصة السلعة ولا تفحصها مادياً؛ تتم المعالجة بين التاجر والزبون.')) return;
        button.disabled=true;
        try { await firebaseServices().functions.httpsCallable('disposeMarketplaceReturn')({orderId:card.dataset.return,note:'تم إغلاق ملف الإرجاع دون استلام أو فحص مادي من المنصة.'}); notify('تم إغلاق ملف الإرجاع'); await loadAdminReturns(); await loadAdminReports(); }
        catch(e) { notify('تعذر إغلاق المرتجع: '+(e.message||'خطأ')); button.disabled=false; }
      });
    });
  } catch(e) { console.error('Admin returns load failed',e); host.textContent='تعذر تحميل طلبات المرتجعات.'; }
}

async function exportAdminReportCsv(event) {
  if (!currentUser?.isAdmin) return notify("غير مصرح بتصدير التقارير");
  const button = event?.currentTarget;
  if (button) { button.disabled = true; button.textContent = "جاري تجهيز جميع الطلبات..."; }
  try {
    const db = firebaseServices().db;
    let query = db.collection("orders").orderBy("createdAt", "desc");
    let cursor = null;
    const rows = [];
    while (true) {
      const pageQuery = cursor ? query.startAfter(cursor).limit(500) : query.limit(500);
      const page = await pageQuery.get();
      for (const doc of page.docs) {
        const order = doc.data();
        rows.push({
          orderId: doc.id,
          createdAt: order.createdAt?.toDate ? order.createdAt.toDate().toISOString() : "",
          customerName: order.customerName || "", phone: order.phone || "", wilaya: order.wilaya || "",
          status: order.status || "unknown", subtotal: Number(order.subtotal || 0),
          deliveryFee: Number(order.deliveryFee || 0), total: Number(order.total || 0),
          paymentMethod: order.paymentMethod || "", paymentStatus: order.paymentStatus || ""
        });
      }
      if (page.size < 500) break;
      cursor = page.docs[page.docs.length - 1];
    }
    if (!rows.length) return notify("لا توجد بيانات متاحة للتصدير");
    const columns = ["orderId", "createdAt", "customerName", "phone", "wilaya", "status", "subtotal", "deliveryFee", "total", "paymentMethod", "paymentStatus"];
    const quote = value => `"${String(value ?? "").replace(/"/g, '""')}"`;
    const csv = [columns.join(","), ...rows.map(row => columns.map(key => quote(row[key])).join(","))].join("\r\n");
    const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const link = document.createElement("a");
    link.href = url; link.download = `soufi-store-all-orders-${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    notify(`تم تجهيز ملف يتضمن ${rows.length} طلباً`);
  } catch (error) {
    console.error("Full order CSV export failed:", error);
    notify("تعذر تصدير جميع الطلبات: " + (error.message || "خطأ"));
  } finally {
    if (button) { button.disabled = false; button.textContent = "تصدير جميع الطلبات CSV"; }
  }
}

async function loadAdminReports() {
  const host = $("adminReports"); if (!host || !currentUser?.isAdmin) return;
  try {
    const db = firebaseServices().db;
    const [orders, commissions, settlements, campaigns, returns] = await Promise.all([
      db.collection("orders").orderBy("createdAt", "desc").limit(300).get(),
      db.collection("commissions").limit(500).get(),
      db.collection("merchant_settlements").orderBy("createdAt", "desc").limit(100).get(),
      db.collection("ad_campaigns").limit(200).get(),
      db.collection("return_requests").limit(200).get()
    ]);
    const orderRows = orders.docs.map(d => { const o = d.data(); return { orderId: d.id, createdAt: o.createdAt?.toDate ? o.createdAt.toDate().toISOString() : "", customerName: o.customerName || "", phone: o.phone || "", wilaya: o.wilaya || "", status: o.status || "unknown", subtotal: Number(o.subtotal || 0), deliveryFee: Number(o.deliveryFee || 0), total: Number(o.total || 0), paymentMethod: o.paymentMethod || "", paymentStatus: o.paymentStatus || "" }; });
    window.SOUFI_ADMIN_REPORT_ROWS = orderRows;
    const countByStatus = orderRows.reduce((acc, o) => { acc[o.status] = (acc[o.status] || 0) + 1; return acc; }, {});
    const deliveredRows = orderRows.filter(o => o.status === "delivered");
    const totalSales = deliveredRows.reduce((n, o) => n + o.subtotal, 0);
    const delivered = deliveredRows.length;
    const failed = orderRows.filter(o => o.status === "delivery_failed").length;
    const pending = orderRows.filter(o => !["delivered", "returned", "partially_returned", "cancelled"].includes(o.status)).length;
    const cancelled = orderRows.filter(o => o.status === "cancelled").length;
    const returned = orderRows.filter(o => o.status === "returned").length;
    const partiallyReturned = orderRows.filter(o => o.status === "partially_returned").length;
    const commissionRows = commissions.docs.map(d => d.data());
    const commissionTotal = commissionRows.reduce((n, c) => n + Number(c.commissionAmount || 0), 0);
    const eligible = commissionRows.filter(c => c.status === "eligible_for_settlement").reduce((n, c) => n + Number(c.merchantNet || 0), 0);
    const settled = settlements.docs.reduce((n, d) => n + Number(d.data().amount || 0), 0);
    const adPending = campaigns.docs.filter(d => d.data().status === "pending_review").length;
    const adWaiting = campaigns.docs.filter(d => d.data().status === "awaiting_payment").length;
    const returnPending = returns.docs.filter(d => ["pending_review", "approved", "merchant_confirmed_received", "received_inspection_required", "received"].includes(d.data().status)).length;
    const statusRows = Object.entries(countByStatus).sort((a,b) => b[1]-a[1]).map(([status,count]) => `<div class="dashboard-row"><span>${safe(orderStatusLabel(status))}</span><b>${count}</b></div>`).join("");
    host.innerHTML = `<div class="report-actions"><button type="button" id="exportAdminOrdersCsv">تصدير جميع الطلبات CSV</button><button type="button" id="refreshAdminReports">تحديث التقارير</button></div><h4>مؤشرات الطلبات</h4><div class="dashboard-list"><div class="dashboard-row"><span>إجمالي الطلبات في العينة</span><b>${orderRows.length}</b></div><div class="dashboard-row"><span>قيمة المنتجات المسلّمة</span><b>${price(totalSales)}</b></div><div class="dashboard-row"><span>متوسط قيمة الطلب المسلّم</span><b>${price(delivered ? Math.round(totalSales / delivered) : 0)}</b></div><div class="dashboard-row"><span>طلبات قيد المعالجة</span><b>${pending}</b></div><div class="dashboard-row"><span>فشل التسليم</span><b>${failed}</b></div><div class="dashboard-row"><span>طلبات مرتجعة بالكامل / جزئياً / ملغاة</span><b>${returned} / ${partiallyReturned} / ${cancelled}</b></div></div><h4>توزيع الطلبات حسب الحالة</h4><div class="dashboard-list">${statusRows || '<p class="empty-state">لا توجد بيانات.</p>'}</div><h4>المؤشرات المالية والتشغيلية</h4><div class="dashboard-list"><div class="dashboard-row"><span>إجمالي عمولات المنصة المسجلة</span><b>${price(commissionTotal)}</b></div><div class="dashboard-row"><span>مستحقات التجار الجاهزة للتسوية</span><b>${price(eligible)}</b></div><div class="dashboard-row"><span>تسويات التجار المسجلة</span><b>${price(settled)}</b></div><div class="dashboard-row"><span>إعلانات تنتظر المراجعة / الدفع</span><b>${adPending} / ${adWaiting}</b></div><div class="dashboard-row"><span>طلبات الإرجاع المفتوحة</span><b>${returnPending}</b></div></div><small class="security-notice">تقرير تشغيلي من عينة محدودة: آخر 300 طلب، و500 سجل عمولة، و100 تسوية، و200 حملة/مرتجع. تصدير CSV يشمل جميع الطلبات عبر صفحات متتابعة؛ المؤشرات المعروضة هنا مبنية على عينة محدودة ولا تمثل كشفاً محاسبياً نهائياً ولا يتضمن تحصيل COD أو بريدي موب المؤجلين.</small>`;
    $("exportAdminOrdersCsv")?.addEventListener("click", exportAdminReportCsv);
    $("refreshAdminReports")?.addEventListener("click", loadAdminReports);
  } catch (e) { console.error("Admin reports failed", e); host.textContent = "تعذر إعداد التقارير؛ تحقق من فهارس وصلاحيات Firestore."; }
}

async function loadAdminDeliveryCompanies() {
  const host = $("adminDeliveryCompanies"); if (!host || !currentUser?.isAdmin) return;
  try { const snap = await firebaseServices().db.collection("delivery_companies").get();
    host.innerHTML = `<form id="deliveryCompanyForm" class="seller-form"><label>اسم الشركة<input name="name" required maxlength="100"></label><label>الهاتف<input name="phone" maxlength="25"></label><label>الموقع الإلكتروني<input name="website" maxlength="200"></label><button class="form-btn">إضافة شركة توصيل</button></form><div class="dashboard-list">${snap.docs.map(d => `<div class="dashboard-row"><b>${safe(d.data().name || d.id)}</b><span>${d.data().active ? "نشطة" : "متوقفة"} <button type="button" data-company-id="${safe(d.id)}" data-company-active="${d.data().active ? "false" : "true"}">${d.data().active ? "إيقاف" : "تفعيل"}</button></span></div>`).join("") || "لا توجد شركات مسجلة"}</div>`;
    $("deliveryCompanyForm")?.addEventListener("submit", async e => { e.preventDefault(); const f = new FormData(e.currentTarget); try { await firebaseServices().functions.httpsCallable("saveDeliveryCompany")({ name: f.get("name"), phone: f.get("phone"), website: f.get("website"), active: true }); notify("تمت إضافة شركة التوصيل"); loadAdminDeliveryCompanies(); loadAdminOrders(); } catch(err) { notify("تعذرت إضافة الشركة: " + (err.message || "خطأ")); } });
    host.querySelectorAll("[data-company-id]").forEach(btn => btn.addEventListener("click", async () => { const d=snap.docs.find(x=>x.id===btn.dataset.companyId); if(!d)return; try { await firebaseServices().functions.httpsCallable("saveDeliveryCompany")({companyId:d.id,name:d.data().name||d.data().companyName||d.id,phone:d.data().phone||"",website:d.data().website||"",active:btn.dataset.companyActive==="true"}); notify("تم تحديث حالة شركة التوصيل"); loadAdminDeliveryCompanies(); loadAdminOrders(); } catch(e){notify("تعذر تحديث الشركة: "+(e.message||"خطأ"));} }));
  } catch(e) { host.textContent = "تعذر تحميل شركات التوصيل."; }
}
async function loadAdminAdCampaigns() {
  const host=$("adminAdCampaigns"); if(!host||!currentUser?.isAdmin)return;
  try { const snap=await firebaseServices().db.collection("ad_campaigns").where("status","==","pending_review").limit(50).get();
    const paymentSnap=await firebaseServices().db.collection("ad_campaigns").where("status","==","payment_under_review").limit(50).get();
    host.innerHTML=(snap.size||paymentSnap.size)?`<div class="admin-list">${snap.docs.map(d=>{const a=d.data();return `<article class="admin-application" data-campaign="${safe(d.id)}"><b>${safe(a.type)} · ${safe(a.title)}</b><p>${safe(a.productName)} · التاجر ${safe(a.merchantUid)}</p><input class="ad-quote" type="number" min="1" placeholder="السعر المقترح بالدج"><button class="approve-ad">قبول وتحديد السعر</button><button class="reject-ad">رفض</button></article>`}).join("")}${paymentSnap.docs.map(d=>{const a=d.data();return `<article class="admin-application ad-payment-review" data-campaign-payment="${safe(d.id)}"><b>مراجعة دفع ${safe(a.type)} · ${safe(a.title)}</b><p>المبلغ: ${price(a.priceQuote)} · التاجر: ${safe(a.merchantUid)}</p><small>رقم العملية: ${safe(a.paymentOperationNumber)} · التاريخ: ${safe(a.paymentOperationDate)}</small><button class="confirm-ad-payment">تأكيد وصول المبلغ وتفعيل الإعلان</button><button class="reject-ad-payment">رفض الدفع</button></article>`}).join("")}</div>`:'<p class="empty-state">لا توجد طلبات إعلانية أو دفعات معلقة.</p>';
    host.querySelectorAll("[data-campaign]").forEach(card=>{card.querySelector(".approve-ad").addEventListener("click",async()=>{const priceQuote=Number(card.querySelector(".ad-quote").value);if(!Number.isSafeInteger(priceQuote)||priceQuote<1)return notify("أدخل سعراً صحيحاً");try{await firebaseServices().functions.httpsCallable("reviewAdCampaign")({campaignId:card.dataset.campaign,decision:"approved",priceQuote});notify("تم قبول الطلب وإرسال السعر للتاجر");loadAdminAdCampaigns()}catch(e){notify("تعذر قبول الإعلان: "+(e.message||"خطأ"))}});card.querySelector(".reject-ad").addEventListener("click",async()=>{const reason=prompt("سبب الرفض")||"";try{await firebaseServices().functions.httpsCallable("reviewAdCampaign")({campaignId:card.dataset.campaign,decision:"rejected",reason});notify("تم رفض طلب الإعلان");loadAdminAdCampaigns()}catch(e){notify("تعذر رفض الإعلان: "+(e.message||"خطأ"))}})});
    host.querySelectorAll("[data-campaign-payment]").forEach(card=>{card.querySelector(".confirm-ad-payment").addEventListener("click",async()=>{if(!confirm("هل تحققت من وصول التحويل في كشف الحساب الفعلي؟"))return;try{await firebaseServices().functions.httpsCallable("reviewAdCampaignPayment")({campaignId:card.dataset.campaignPayment,decision:"confirmed"});notify("تم تأكيد الدفع وتفعيل الإعلان لمدة 30 يوماً");loadAdminAdCampaigns()}catch(e){notify("تعذر تأكيد الدفع: "+(e.message||"خطأ"))}});card.querySelector(".reject-ad-payment").addEventListener("click",async()=>{const reason=(prompt("سبب رفض الدفع")||"").trim();if(reason.length<3)return notify("أدخل سبب الرفض");try{await firebaseServices().functions.httpsCallable("reviewAdCampaignPayment")({campaignId:card.dataset.campaignPayment,decision:"rejected",reason});notify("تم رفض دفعة الإعلان");loadAdminAdCampaigns()}catch(e){notify("تعذر رفض الدفع: "+(e.message||"خطأ"))}})});
  }catch(e){host.textContent="تعذر تحميل طلبات الإعلانات."}
}
async function submitSellerAdCampaign() {
  const productId=$("adProductId")?.value.trim(), title=$("adCampaignTitle")?.value.trim(), type=$("adCampaignType")?.value;
  if(!productId||!title)return notify("أدخل معرّف المنتج وعنوان الإعلان");
  try{const result=await firebaseServices().functions.httpsCallable("submitAdCampaign")({productId,title,type});notify("تم إرسال طلب الإعلان للمراجعة. معرّف الحملة: "+result.data.campaignId);$("adPaymentCampaignId").value=result.data.campaignId;$("adProductId").value="";$("adCampaignTitle").value="";}catch(e){notify("تعذر إرسال طلب الإعلان: "+(e.message||"خطأ"))}
}
async function submitSellerAdCampaignPayment() {
  const campaignId=$("adPaymentCampaignId")?.value.trim(), operationNumber=$("adPaymentOperation")?.value.trim(), operationDate=$("adPaymentDate")?.value;
  if(!campaignId||!operationNumber||!operationDate)return notify("أدخل معرّف الحملة ورقم وتاريخ التحويل");
  try{await firebaseServices().functions.httpsCallable("submitAdCampaignPayment")({campaignId,operationNumber,operationDate});notify("تم إرسال مرجع دفع الإعلان للمراجعة. لن يُفعّل قبل المطابقة البنكية.");$("adPaymentOperation").value="";}catch(e){notify("تعذر إرسال الدفع: "+(e.message||"خطأ"))}
}

async function reviewProductRequest(requestId, approve, card) {
  if (!currentUser?.isAdmin || !requestId || !card) return notify("غير مصرح بهذه العملية");
  const buttons = card.querySelectorAll("button");
  buttons.forEach(button => button.disabled = true);
  try {
    const reason = approve ? "" : (prompt("سبب رفض المنتج (اختياري):") || "");
    const result = await firebaseServices().functions.httpsCallable("reviewSellerProductRequest")({
      requestId, decision: approve ? "approved" : "rejected", reason
    });
    card.remove();
    if (!$("adminProductRequestList")?.querySelector(".product-review")) $("adminProductRequestList").innerHTML = '<p class="empty-state">تمت مراجعة جميع المنتجات المعلّقة.</p>';
    notify(approve ? "تم نشر المنتج في المتجر" : "تم رفض المنتج");
    if (result.data?.productId) await loadAdminReports();
  } catch (error) {
    console.error("Product moderation failed:", error);
    buttons.forEach(button => button.disabled = false);
    notify("تعذر مراجعة المنتج: " + (error.message || "خطأ"));
  }
}

async function reviewMerchantApplication(uid, approve, card) {
  if (!currentUser?.isAdmin || !uid || !card) return notify("غير مصرح بهذه العملية");
  // Launch policy: one transparent, fixed 3% commission for every approved merchant.
  const rate = 3;
  const buttons = card.querySelectorAll("button");
  buttons.forEach(button => button.disabled = true);
  try {
    const db = firebaseServices().db;
    const appRef = db.collection("merchant_applications").doc(uid);
    const userRef = db.collection("users").doc(uid);
    const appSnap = await appRef.get();
    if (!appSnap.exists || appSnap.data().status !== "pending") throw new Error("APPLICATION_NOT_PENDING");
    const a = appSnap.data();
    const stamp = window.firebase.firestore.FieldValue.serverTimestamp();
    const batch = db.batch();
    if (approve) {
      batch.set(db.collection("merchants").doc(uid), {
        ownerUid: uid, ownerName: a.ownerName, email: a.email, phone: a.phone,
        storeName: a.storeName, category: a.category, wilaya: a.wilaya,
        status: "approved", active: true, commissionRate: rate,
        commissionUpdatedAt: stamp, createdAt: stamp, updatedAt: stamp
      });
      batch.update(userRef, {role: "seller", updatedAt: stamp});
    }
    batch.update(appRef, {status: approve ? "approved" : "rejected", reviewedAt: stamp, reviewedBy: currentUser.uid});
    await batch.commit();
    card.remove();
    if (!$("adminApplicationList")?.querySelector(".admin-application")) $("adminApplicationList").innerHTML = '<p class="empty-state">تمت معالجة جميع الطلبات المعلّقة.</p>';
    notify(approve ? "تمت الموافقة على المتجر وتسجيل العمولة" : "تم رفض طلب المتجر");
  } catch (error) {
    console.error("Application review failed:", error);
    buttons.forEach(button => button.disabled = false);
    notify(error.message === "APPLICATION_NOT_PENDING" ? "هذا الطلب تمت معالجته مسبقاً" : authErrorMessage(error));
  }
}

async function displaySellerDashboard() {
  if (!currentUser || currentUser.role !== "seller") return openAccount();
  const box = $("sellerDashboard");
  if (!box) return;
  box.classList.add("show");
  box.innerHTML = `<div class="dashboard-head"><div><h2>مساحة التاجر</h2><p>${safe(currentUser.name || "")}</p></div><button class="close" id="closeSellerDashboard">×</button></div>
    <p class="security-notice">يمكنك عرض منتجات متجرك وإدارة حالتها. أنت مسؤول عن تجهيز الطلبات التي تقبلها والتنسيق مع الزبون؛ المنصة لا تدير مخزوناً أو مستودعات.</p>
    <form id="sellerProductForm" class="seller-form">
      <h3>إضافة منتج جديد</h3>
      <label>اسم المنتج<input name="name" required minlength="2" maxlength="100"></label>
      <label>التصنيف<input name="category" required maxlength="60"></label>
      <label>السعر بالدينار<input name="price" type="number" required min="1" max="100000000" step="1"></label>
      <label>رابط الصورة HTTPS (اختياري)<input name="image" type="url" maxlength="500" placeholder="https://..."></label>
      <label>الوصف<textarea name="description" maxlength="1000"></textarea></label>
      <button class="form-btn" type="submit">إرسال المنتج للمراجعة</button>
    </form>
    <div id="sellerPublishedProducts"><p>جاري تحميل منتجاتك المنشورة...</p></div><div id="sellerProductRequests"><p>جاري تحميل منتجاتك...</p></div>

    <div id="sellerOrderList"><p>جاري تحميل طلبات متجرك...</p></div><h3>التسويات المالية</h3><p class="security-notice">التسويات المالية مؤجلة إلى المرحلة الأخيرة قبل الإطلاق.</p>`;
  $("closeSellerDashboard")?.addEventListener("click", () => box.classList.remove("show"));
  $("sellerProductForm")?.addEventListener("submit", submitSellerProductRequest);
  $("sellerPublishedProducts")?.addEventListener("click", handleSellerProductAction);
  loadSellerProductRequests();
  loadSellerPublishedProducts();
  loadSellerOrders();
  // Seller settlement history is deferred with the payment/collection final stage.
}

async function loadSellerOrders() {
  const target = $("sellerOrderList");
  if (!target || currentUser?.role !== "seller") return;
  try {
    const snap = await firebaseServices().db.collection("merchant_orders")
      .where("merchantUid", "==", currentUser.uid).limit(30).get();
    if (!snap.size) { target.innerHTML = '<h3>طلبات متجرك</h3><p class="empty-state">لا توجد طلبات بعد.</p>'; return; }
    const docs = snap.docs.sort((a,b) => (b.data().createdAt?.toMillis?.() || 0) - (a.data().createdAt?.toMillis?.() || 0));
    target.innerHTML = `<h3>طلبات متجرك</h3><div class="dashboard-list">${docs.map(doc => {
      const o = doc.data();
      const names = (o.items || []).map(item => `${safe(item.name)} × ${Number(item.quantity)}`).join("، ");
      return `<div class="dashboard-row"><span><b>${safe(doc.id)}</b><small>${names}</small><small>العمولة ${Number(o.commissionRate).toFixed(1)}% · ${price(o.commissionAmount)}</small><small class="seller-shipment" data-order="${safe(o.orderId)}">الشحنة: جاري التحميل...</small></span><span><b>${price(o.merchantNet)}</b><small>${safe(orderStatusLabel(o.status))}</small></span></div>`;
    }).join("")}</div>`;
    for (const doc of docs) { const o=doc.data(); const sh=await firebaseServices().db.collection("shipments").doc(`${o.orderId}_${currentUser.uid}`).get(); const line=target.querySelector(`.seller-shipment[data-order="${CSS.escape(o.orderId)}"]`); if(line) line.textContent=sh.exists ? `الشحنة: ${orderStatusLabel(sh.data().status || "قيد المعالجة")}${sh.data().trackingNumber ? " · التتبع: "+sh.data().trackingNumber : ""}${sh.data().failureReason ? " · سبب الفشل: "+sh.data().failureReason : ""}` : "لا توجد بيانات شحنة"; }
  } catch (error) {
    console.error("Seller orders load failed:", error);
    target.innerHTML = '<h3>طلبات متجرك</h3><p class="security-notice">تعذر تحميل الطلبات.</p>';
  }
}

async function submitSellerProductRequest(event) {
  event.preventDefault();
  if (!currentUser || currentUser.role !== "seller") return notify("حساب التاجر غير معتمد");
  const form = event.currentTarget;
  const values = new FormData(form);
  const name = String(values.get("name") || "").trim();
  const category = String(values.get("category") || "").trim();
  const description = String(values.get("description") || "").trim();
  const priceValue = Number(values.get("price"));
  const image = String(values.get("image") || "").trim();
  if (name.length < 2 || category.length < 2 || !Number.isSafeInteger(priceValue) || priceValue < 1) return notify("تحقق من اسم المنتج والتصنيف والسعر");
  if (image) {
    try { const parsed = new URL(image); if (parsed.protocol !== "https:") throw new Error("invalid"); }
    catch (_) { return notify("رابط الصورة يجب أن يكون HTTPS صحيحاً"); }
  }
  const submit = form.querySelector("button[type=submit]");
  submit.disabled = true;
  try {
    const db = firebaseServices().db;
    const merchantSnap = await db.collection("merchants").doc(currentUser.uid).get();
    if (!merchantSnap.exists || merchantSnap.data().status !== "approved" || merchantSnap.data().active !== true) throw new Error("MERCHANT_NOT_ACTIVE");
    await db.collection("product_requests").add({
      ownerUid: currentUser.uid, storeName: merchantSnap.data().storeName,
      name, category, description, price: priceValue, image,
      status: "pending", createdAt: window.firebase.firestore.FieldValue.serverTimestamp()
    });
    form.reset();
    notify("تم إرسال المنتج إلى الإدارة للمراجعة");
    loadSellerProductRequests();
  } catch (error) {
    console.error("Product proposal failed:", error);
    notify(error.message === "MERCHANT_NOT_ACTIVE" ? "متجرك غير معتمد أو موقوف" : authErrorMessage(error));
  } finally { submit.disabled = false; }
}

async function loadSellerPublishedProducts() {
  const target = $("sellerPublishedProducts");
  if (!target || currentUser?.role !== "seller") return;
  try {
    const snap = await firebaseServices().db.collection("products").where("ownerUid", "==", currentUser.uid).get();
    const docs = snap.docs.filter(doc => doc.data().status === "approved" && !doc.data().deletedAt).sort((a,b) => (b.data().updatedAt?.toMillis?.() || 0) - (a.data().updatedAt?.toMillis?.() || 0));
    if (!docs.length) { target.innerHTML = '<h3>منتجاتك المنشورة</h3><p class="empty-state">لا توجد منتجات منشورة بعد.</p>'; return; }
    target.innerHTML = `<h3>منتجاتك المنشورة</h3><div class="dashboard-list">${docs.map(doc => {
      const item = doc.data();
      const stateLabel = item.deletedAt ? "محذوف" : item.active === false ? "متوقف مؤقتاً" : "نشط";
      return `<div class="dashboard-row seller-product-row" data-product="${safe(doc.id)}"><span><b>${safe(item.name)}</b><small>${price(item.price)} · ${stateLabel}</small></span><span class="seller-product-actions"><button type="button" data-product-action="edit" data-id="${safe(doc.id)}">تعديل</button><button type="button" data-product-action="toggle" data-active="${item.active === false ? "true" : "false"}" data-id="${safe(doc.id)}">${item.active === false ? "تفعيل" : "إيقاف"}</button><button type="button" data-product-action="delete" data-id="${safe(doc.id)}">حذف</button></span></div>`;
    }).join("")}</div>`;
  } catch (error) {
    console.error("Published seller products load failed:", error);
    target.innerHTML = '<h3>منتجاتك المنشورة</h3><p class="security-notice">تعذر تحميل المنتجات المنشورة.</p>';
  }
}

async function handleSellerProductAction(event) {
  const button = event.target.closest("button[data-product-action]");
  if (!button || !currentUser || currentUser.role !== "seller") return;
  const action = button.dataset.productAction;
  const productId = button.dataset.id;
  const callable = firebaseServices().functions.httpsCallable;
  button.disabled = true;
  try {
    if (action === "edit") {
      const snap = await firebaseServices().db.collection("products").doc(productId).get();
      if (!snap.exists || snap.data().ownerUid !== currentUser.uid) throw new Error("PRODUCT_NOT_FOUND");
      const p = snap.data();
      const name = prompt("اسم المنتج", p.name || ""); if (name === null) return;
      const category = prompt("التصنيف", p.category || ""); if (category === null) return;
      const priceValue = Number(prompt("السعر بالدينار", String(p.price || ""))); if (!Number.isSafeInteger(priceValue) || priceValue < 1) return notify("السعر غير صحيح");
      const description = prompt("الوصف", p.description || ""); if (description === null) return;
      await callable("updateSellerProduct")({ productId, patch: { name, category, price: priceValue, description } });
      notify("تم تحديث المنتج");
    } else if (action === "toggle") {
      const active = button.dataset.active === "true";
      await callable("setSellerProductActive")({ productId, active });
      notify(active ? "تم تفعيل المنتج" : "تم إيقاف المنتج مؤقتاً");
    } else if (action === "delete") {
      if (!confirm("سيتم إخفاء المنتج من المتجر مع الاحتفاظ بسجلات الطلبات. هل تريد المتابعة؟")) return;
      await callable("deleteSellerProduct")({ productId });
      notify("تم حذف المنتج من واجهة المتجر");
    }
    await loadSellerPublishedProducts();
  } catch (error) {
    console.error("Seller product action failed:", error);
    notify(error.message === "PRODUCT_NOT_FOUND" ? "المنتج غير موجود أو لا تملكه" : "تعذر تنفيذ العملية: " + (error.message || "خطأ"));
  } finally { button.disabled = false; }
}

async function loadSellerSettlements() {
  const target=$("sellerSettlementList"); if(!target||currentUser?.role!=="seller")return;
  try { const snap=await firebaseServices().db.collection("merchant_settlements").where("merchantUid","==",currentUser.uid).limit(50).get();
    target.innerHTML=`<h3>التسويات المالية</h3>${snap.size?`<div class="dashboard-list">${snap.docs.map(d=>{const v=d.data();return `<div class="dashboard-row"><span><b>${price(v.amount)}</b><small>${safe(v.reference||"دون مرجع")}</small></span><small>${safe(v.status||"مسجل")}</small></div>`}).join("")}</div>`:'<p class="empty-state">لا توجد تسويات مسجلة بعد.</p>'}`;
  } catch(e){target.innerHTML='<p class="security-notice">تعذر تحميل التسويات.</p>'}
}

async function loadSellerProductRequests() {
  const target = $("sellerProductRequests");
  if (!target || !currentUser) return;
  try {
    const snap = await firebaseServices().db.collection("product_requests").where("ownerUid", "==", currentUser.uid).orderBy("createdAt", "desc").limit(30).get();
    if (!snap.size) { target.innerHTML = '<p class="empty-state">لم ترسل منتجات بعد.</p>'; return; }
    target.innerHTML = `<h3>حالة المنتجات المرسلة</h3><div class="dashboard-list">${snap.docs.map(doc => {
      const item = doc.data();
      const label = item.status === "approved" ? "مقبول" : item.status === "rejected" ? "مرفوض" : "قيد المراجعة";
      return `<div class="dashboard-row"><span><b>${safe(item.name)}</b><small>${price(item.price)}</small></span><small>${label}</small></div>`;
    }).join("")}</div>`;
  } catch (error) {
    console.error("Seller product request history failed:", error);
    target.innerHTML = '<p class="security-notice">تعذر تحميل سجل المنتجات.</p>';
  }
}

function startApprovedProductSync() {
  const services = firebaseServices();
  if (!services || startApprovedProductSync.started) return;
  startApprovedProductSync.started = true;
  products = [];
  localStorage.removeItem(DB.products);
  displayProducts([]);
  services.db.collection("products").where("status", "==", "approved").where("active", "==", true)
    .onSnapshot(snapshot => {
      products = snapshot.docs.map(doc => ({id: doc.id, ...doc.data()}));
      displayProducts(getVisibleProducts());
      renderCart();
    }, error => {
      console.error("Approved product sync failed:", error);
      products = [];
      displayProducts([]);
      notify("تعذر تحديث كتالوج المنتجات من Firebase؛ تم إخفاء المنتجات التجريبية");
    });
}

function checkout() {
  if (!firebaseServices()) return notify("Firebase غير متصل حالياً");
  if (!currentUser) {
    notify("سجّل الدخول أولاً لإتمام الطلب");
    openAccount();
    return;
  }
  if (!cart.length) return notify("السلة فارغة");
  const host = document.getElementById("checkoutFormHost");
  if (!host) return notify("تعذر فتح نموذج الطلب");
  if (!pendingOrderRequestId) {
    pendingOrderRequestId = (window.crypto && window.crypto.randomUUID)
      ? window.crypto.randomUUID().replace(/-/g, "")
      : `req_${Date.now()}_${Math.random().toString(36).slice(2, 12)}`;
    pendingOrderItems = cart.map(item => ({productId: String(item.id), quantity: Number(item.quantity)}));
  }
  host.innerHTML = `
    <form id="secureCheckoutForm" class="secure-checkout-form">
      <h3>معلومات التوصيل</h3>
      <p class="security-notice">سيتم تأكيد تكلفة التوصيل من طرف إدارة المنصة بعد مراجعة الطلب.</p>
      <label>رقم الهاتف<input name="phone" type="tel" required minlength="5" maxlength="25" autocomplete="tel" value="${safe(currentUser.phone || "")}"></label>
      <label>الولاية<input name="wilaya" required minlength="2" maxlength="60" placeholder="مثال: سطيف"></label>
      <label>العنوان بالتفصيل<textarea name="address" required minlength="5" maxlength="300" placeholder="البلدية، الحي، الشارع، وأقرب معلم"></textarea></label>
      <label>ملاحظة للسائق (اختياري)<textarea name="note" maxlength="300"></textarea></label>
      <label>طريقة الدفع<select name="paymentMethod"><option value="cash_on_delivery">الدفع عند الاستلام</option><option value="baridimob">بريدي موب (تحويل مسبق)</option></select></label>
      <p class="security-notice">بريدي موب: بعد تسجيل الطلب ستظهر لك استمارة رفع وصل التحويل. لا يعتبر الدفع مؤكداً إلا بعد تحقق الإدارة من وصول الأموال.</p>
      <button type="submit" class="checkout-submit">تأكيد الطلب</button>
    </form>`;
  host.scrollIntoView({behavior:"smooth", block:"nearest"});
  host.querySelector("form")?.addEventListener("submit", submitSecureOrder);
}

async function submitSecureOrder(event) {
  event.preventDefault();
  if (!currentUser || !firebaseServices()?.functions) return notify("خدمة الطلبات غير مهيأة بعد");
  if (!cart.length) return notify("السلة فارغة");
  const form = event.currentTarget;
  const data = new FormData(form);
  const payload = {
    phone: String(data.get("phone") || "").trim(),
    wilaya: String(data.get("wilaya") || "").trim(),
    address: String(data.get("address") || "").trim(),
    note: String(data.get("note") || "").trim(),
    paymentMethod: data.get("paymentMethod") === "baridimob" ? "baridimob" : "cash_on_delivery",
    items: pendingOrderItems || cart.map(item => ({productId: String(item.id), quantity: Number(item.quantity)})),
    requestId: pendingOrderRequestId || `req_${Date.now()}_${Math.random().toString(36).slice(2, 12)}`
  };
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  button.textContent = "جاري إرسال الطلب...";
  try {
    const callable = firebaseServices().functions.httpsCallable("createMarketplaceOrder");
    const result = await callable(payload);
    const orderId = result.data?.orderId;
    if (!orderId) throw new Error("ORDER_RESPONSE_INVALID");
    for (const purchased of (pendingOrderItems || [])) {
      const cartItem = cart.find(item => String(item.id) === String(purchased.productId));
      if (cartItem) {
        cartItem.quantity -= purchased.quantity;
        if (cartItem.quantity <= 0) cart = cart.filter(item => String(item.id) !== String(purchased.productId));
      }
    }
    pendingOrderRequestId = null;
    pendingOrderItems = null;
    save(DB.cart, cart);
    renderCart();
    const host = document.getElementById("checkoutFormHost");
    if (host && payload.paymentMethod === "baridimob") {
      host.innerHTML = `<div class="order-success"><h3>تم تسجيل الطلب</h3><p>رقم الطلب: <b>${safe(orderId)}</b></p><p id="baridiPaymentState">انتظر تأكيد إدارة المنصة لتكلفة التوصيل والمبلغ النهائي. لن يُطلب منك التحويل قبل تحديد المبلغ الكامل.</p><div id="baridiProofHost"></div></div>`;
      watchBaridiOrder(orderId);
    } else if (host) host.innerHTML = `<div class="order-success"><h3>تم تسجيل طلبك بنجاح</h3><p>رقم الطلب: <b>${safe(orderId)}</b></p><p>ستتواصل معك إدارة المنصة لتأكيد الطلب وتكلفة التوصيل.</p></div>`;
    notify("تم تسجيل الطلب");
  } catch (error) {
    console.error("Secure order creation failed:", error);
    const messages = {
      "unauthenticated": "انتهت جلسة الدخول. سجّل الدخول مجدداً.",
      "failed-precondition": error.message || "تعذر إتمام الطلب بسبب حالة المنتج أو الطلب.",
      "functions/not-found": "خدمة الطلبات غير منشورة على Firebase بعد.",
      "functions/unavailable": "خدمة الطلبات غير متاحة حالياً. حاول لاحقاً."
    };
    notify(messages[error.code] || messages[error.code?.replace(/^functions\//, "")] || "تعذر تسجيل الطلب. تحقق من البيانات وحاول مجدداً.");
    button.disabled = false;
    button.textContent = "تأكيد الطلب بالدفع عند الاستلام";
  }
}

let activeBaridiOrderUnsubscribe = null;
function watchBaridiOrder(orderId) {
  if (activeBaridiOrderUnsubscribe) activeBaridiOrderUnsubscribe();
  const state = $("baridiPaymentState");
  const host = $("baridiProofHost");
  if (!state || !host || !currentUser) return;
  activeBaridiOrderUnsubscribe = firebaseServices().db.collection("orders").doc(orderId).onSnapshot(snapshot => {
    if (!snapshot.exists) { state.textContent = "تعذر العثور على الطلب."; return; }
    const order = snapshot.data();
    if (order.status === "cancelled") { state.textContent = "تم إلغاء الطلب؛ لا تقم بأي تحويل."; host.innerHTML = ""; return; }
    if (order.paymentStatus === "paid") { state.textContent = "تم تأكيد وصول المبلغ بنجاح."; host.innerHTML = ""; return; }
    if (order.paymentStatus === "under_review") { state.textContent = "تم استلام إثبات التحويل وهو قيد مراجعة الإدارة."; host.innerHTML = ""; return; }
    if (order.deliveryFeeStatus !== "confirmed" || !Number.isSafeInteger(order.total)) {
      state.textContent = "انتظر تأكيد إدارة المنصة لتكلفة التوصيل والمبلغ النهائي. لن يُطلب منك التحويل قبل تحديد المبلغ الكامل.";
      host.innerHTML = ""; return;
    }
    state.textContent = `المبلغ النهائي المطلوب تحويله: ${price(order.total)}. لا تحول مبلغاً مختلفاً.`;
    if (!host.querySelector("#baridiProofForm")) {
      host.innerHTML = `<form id="baridiProofForm"><label>رقم العملية<input name="operationNumber" required minlength="4" maxlength="80"></label><label>تاريخ العملية<input name="operationDate" type="date" required></label><label>صورة الوصل<input name="proof" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" required></label><button type="submit" class="checkout-submit">إرسال إثبات التحويل للمراجعة</button></form>`;
      $("baridiProofForm")?.addEventListener("submit", e => submitBaridiProof(e, orderId));
    }
  }, error => { console.error("Baridi order watch failed:", error); state.textContent = "تعذر تحديث حالة الطلب. أعد تحميل الصفحة لاحقاً."; });
}

async function submitBaridiProof(event, orderId) {
  event.preventDefault();
  const form = event.currentTarget;
  const file = form.elements.proof.files?.[0];
  if (!file || file.size > 5 * 1024 * 1024 || !['image/jpeg','image/png','image/webp','application/pdf'].includes(file.type)) {
    return notify('اختر صورة أو PDF صالحاً لا يتجاوز 5 ميغابايت');
  }
  const services = firebaseServices();
  if (!services?.storage || !services?.functions) return notify('خدمات Firebase Storage/Functions غير مهيأة');
  const button = form.querySelector('button[type=submit]');
  button.disabled = true; button.textContent = 'جاري رفع الإثبات...';
  try {
    const uid = currentUser.uid;
    const safeName = `${Date.now()}_${file.name.replace(/[^A-Za-z0-9_.-]/g,'_')}`;
    const path = `payments/proofs/${uid}/${safeName}`;
    await services.storage.ref(path).put(file, { contentType: file.type, customMetadata: { uploaderUid: uid } });
    const callable = services.functions.httpsCallable('submitBaridiMobProof');
    await callable({ orderId, operationNumber: String(new FormData(form).get('operationNumber')).trim(), operationDate: String(new FormData(form).get('operationDate')), proofPath: path });
    form.innerHTML = '<p>تم إرسال إثبات التحويل. حالة الدفع: قيد مراجعة الإدارة. لن يتم تأكيد الدفع قبل التحقق الفعلي.</p>';
  } catch (error) {
    console.error('BaridiMob proof submission failed:', error);
    notify('تعذر إرسال الإثبات. تحقق من الاتصال وحاول مجدداً.');
    button.disabled = false; button.textContent = 'إرسال إثبات التحويل للمراجعة';
  }
}

/* Événements */
$("searchBtn")?.addEventListener("click", () => displayProducts(getVisibleProducts()));
$("searchInput")?.addEventListener("input", () => displayProducts(getVisibleProducts()));
$("sortSelect")?.addEventListener("change", () => displayProducts(getVisibleProducts()));
$("showAll")?.addEventListener("click", e => { e.preventDefault(); $("searchInput").value = ""; $("sortSelect").value = "default"; displayProducts(); });

$("productGrid")?.addEventListener("click", e => {
  const btn = e.target.closest("button[data-add]");
  if (btn) addToCart(btn.dataset.add);
});

$("cartItems")?.addEventListener("click", e => {
  const btn = e.target.closest("button");
  if (!btn) return;
  if (btn.dataset.minus) changeCart(btn.dataset.minus, "minus");
  else if (btn.dataset.plus) changeCart(btn.dataset.plus, "plus");
  else if (btn.dataset.remove) changeCart(btn.dataset.remove, "remove");
});

$("openCart")?.addEventListener("click", () => { $("cartModal")?.classList.add("show"); renderCart(); });
$("closeCart")?.addEventListener("click", () => $("cartModal")?.classList.remove("show"));
$("accountBtn")?.addEventListener("click", openAccount);
$("closeAccount")?.addEventListener("click", closeAccount);
$("sellerBtn")?.addEventListener("click", () => { openAccount(); if (!currentUser) showSellerRegister(); });
$("checkoutBtn")?.addEventListener("click", checkout);

$("accountModal")?.addEventListener("click", e => { if (e.target === e.currentTarget) closeAccount(); });
$("cartModal")?.addEventListener("click", e => { if (e.target === e.currentTarget) e.currentTarget.classList.remove("show"); });

document.querySelectorAll(".category").forEach(btn => btn.addEventListener("click", () => {
  const category = btn.dataset.category;
  displayProducts(products.filter(p => p.category === category));
  $("products")?.scrollIntoView({behavior:"smooth"});
}));

/* Initialisation */
displayProducts();
displayStores();
renderCart();
updateAccountUI();
const connectionStatus = $("connectionStatus");
if (firebaseServices()) {
  connectionStatus && (connectionStatus.textContent = "Firebase connecté — authentification activée");
  startApprovedProductSync();
  firebaseServices().auth.onAuthStateChanged(async user => {
    authReady = true;
    if (!user) {
      currentUser = null;
      updateAccountUI();
      if ($("accountModal")?.classList.contains("show")) showLoginForm();
      return;
    }
    try {
      const snap = await firebaseServices().db.collection("users").doc(user.uid).get();
      if (!snap.exists) {
        if (accountSetupInProgress) return;
        currentUser = null;
        await firebaseServices().auth.signOut();
        notify("Profil utilisateur introuvable. Reconnectez-vous ou contactez l'assistance.");
        return;
      }
      const tokenInfo = await user.getIdTokenResult();
      currentUser = {id:user.uid, uid:user.uid, email:user.email, ...snap.data(), isAdmin: tokenInfo.claims.admin === true};
      updateAccountUI();
      if ($("accountModal")?.classList.contains("show")) showAccountHome();
    } catch (error) {
      console.error("Profile load failed:", error);
      currentUser = null; updateAccountUI();
      notify("Impossible de charger votre profil sécurisé");
    }
  });
} else {
  authReady = true;
  connectionStatus && (connectionStatus.textContent = "Firebase non connecté — les comptes et commandes sont indisponibles");
}
console.log("SOUFI STORE: Firebase authentication flow:", !!firebaseServices());
