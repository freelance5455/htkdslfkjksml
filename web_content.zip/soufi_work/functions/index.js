const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue, Timestamp } = require('firebase-admin/firestore');
const { getStorage } = require('firebase-admin/storage');
const crypto = require('crypto');

initializeApp();
const db = getFirestore();
const REGION = 'us-central1';

function text(value, min, max, field) {
  if (typeof value !== 'string') throw new HttpsError('invalid-argument', `Invalid ${field}`);
  const valueTrimmed = value.trim();
  if (valueTrimmed.length < min || valueTrimmed.length > max) {
    throw new HttpsError('invalid-argument', `Invalid ${field}`);
  }
  return valueTrimmed;
}


function requireActiveSeller(request) {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first.');
  return request.auth.uid;
}

async function assertActiveSeller(tx, uid) {
  const merchantRef = db.collection('merchants').doc(uid);
  const merchantSnap = await tx.get(merchantRef);
  if (!merchantSnap.exists || merchantSnap.data().ownerUid !== uid || merchantSnap.data().status !== 'approved' || merchantSnap.data().active !== true) {
    throw new HttpsError('permission-denied', 'Active merchant account required.');
  }
  return merchantSnap.data();
}

// Merchant edits only their own published product. All writes are server-side and audited.
exports.updateSellerProduct = onCall({ region: REGION, maxInstances: 10 }, async request => {
  const uid = requireActiveSeller(request);
  const productId = text(request.data?.productId, 1, 150, 'productId');
  const patch = request.data?.patch;
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new HttpsError('invalid-argument', 'Invalid product changes.');
  const allowed = ['name', 'category', 'description', 'price', 'image'];
  if (Object.keys(patch).some(key => !allowed.includes(key)) || !Object.keys(patch).length) throw new HttpsError('invalid-argument', 'Unsupported product fields.');
  const clean = {};
  if ('name' in patch) clean.name = text(patch.name, 2, 100, 'name');
  if ('category' in patch) clean.category = text(patch.category, 2, 60, 'category');
  if ('description' in patch) clean.description = typeof patch.description === 'string' ? patch.description.trim().slice(0, 1000) : (() => { throw new HttpsError('invalid-argument', 'Invalid description.'); })();
  if ('price' in patch) {
    clean.price = Number(patch.price);
    if (!Number.isSafeInteger(clean.price) || clean.price < 1 || clean.price > 100000000) throw new HttpsError('invalid-argument', 'Invalid price.');
  }
  if ('image' in patch) {
    clean.image = typeof patch.image === 'string' ? patch.image.trim() : '';
    if (clean.image.length > 500) throw new HttpsError('invalid-argument', 'Image URL is too long.');
    if (clean.image) { let parsed; try { parsed = new URL(clean.image); } catch (_) { throw new HttpsError('invalid-argument', 'Invalid image URL.'); } if (parsed.protocol !== 'https:') throw new HttpsError('invalid-argument', 'Image URL must use HTTPS.'); }
  }
  const ref = db.collection('products').doc(productId);
  return db.runTransaction(async tx => {
    await assertActiveSeller(tx, uid);
    const snap = await tx.get(ref);
    if (!snap.exists || snap.data().ownerUid !== uid || snap.data().status !== 'approved' || snap.data().deletedAt) throw new HttpsError('not-found', 'Published product not found.');
    const now = FieldValue.serverTimestamp();
    tx.update(ref, { ...clean, updatedAt: now });
    tx.create(db.collection('product_audit_logs').doc(), { productId, merchantUid: uid, action: 'updated', changedFields: Object.keys(clean), createdAt: now });
    return { productId, updated: true };
  });
});

// Deprecated: SOUFI STORE does not operate or track product inventory.
exports.setSellerProductStock = onCall({ region: REGION, maxInstances: 2 }, async () => {
  throw new HttpsError('failed-precondition', 'Inventory management is not part of the SOUFI STORE marketplace model. Use product active status instead.');
});

exports.setSellerProductActive = onCall({ region: REGION, maxInstances: 10 }, async request => {
  const uid = requireActiveSeller(request);
  const productId = text(request.data?.productId, 1, 150, 'productId');
  const active = request.data?.active;
  if (typeof active !== 'boolean') throw new HttpsError('invalid-argument', 'Active must be true or false.');
  const ref = db.collection('products').doc(productId);
  return db.runTransaction(async tx => {
    await assertActiveSeller(tx, uid);
    const snap = await tx.get(ref);
    if (!snap.exists || snap.data().ownerUid !== uid || snap.data().status !== 'approved' || snap.data().deletedAt) throw new HttpsError('not-found', 'Published product not found.');
    const now = FieldValue.serverTimestamp();
    tx.update(ref, { active, updatedAt: now });
    tx.create(db.collection('product_audit_logs').doc(), { productId, merchantUid: uid, action: active ? 'activated' : 'paused', createdAt: now });
    return { productId, active };
  });
});

exports.deleteSellerProduct = onCall({ region: REGION, maxInstances: 10 }, async request => {
  const uid = requireActiveSeller(request);
  const productId = text(request.data?.productId, 1, 150, 'productId');
  const ref = db.collection('products').doc(productId);
  return db.runTransaction(async tx => {
    await assertActiveSeller(tx, uid);
    const snap = await tx.get(ref);
    if (!snap.exists || snap.data().ownerUid !== uid || snap.data().status !== 'approved' || snap.data().deletedAt) throw new HttpsError('not-found', 'Published product not found.');
    const now = FieldValue.serverTimestamp();
    // Soft-delete keeps existing order references intact while hiding the listing.
    tx.update(ref, { active: false, deletedAt: now, updatedAt: now });
    tx.create(db.collection('product_audit_logs').doc(), { productId, merchantUid: uid, action: 'deleted', createdAt: now });
    return { productId, deleted: true };
  });
});

// Product proposals are reviewed atomically to prevent duplicate catalogue products when admins act concurrently.
exports.reviewSellerProductRequest = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const requestId = text(request.data?.requestId, 1, 150, 'requestId');
  const decision = request.data?.decision;
  if (!['approved', 'rejected'].includes(decision)) throw new HttpsError('invalid-argument', 'Invalid product review decision.');
  const requestRef = db.collection('product_requests').doc(requestId);
  const productRef = db.collection('products').doc();
  return db.runTransaction(async tx => {
    const proposalSnap = await tx.get(requestRef);
    if (!proposalSnap.exists || proposalSnap.data().status !== 'pending') throw new HttpsError('failed-precondition', 'Product proposal is no longer pending review.');
    const proposal = proposalSnap.data();
    let merchant = null;
    if (decision === 'approved') {
      if (typeof proposal.ownerUid !== 'string' || !proposal.ownerUid) throw new HttpsError('failed-precondition', 'Product proposal has no valid merchant.');
      const merchantSnap = await tx.get(db.collection('merchants').doc(proposal.ownerUid));
      if (!merchantSnap.exists || merchantSnap.data().status !== 'approved' || merchantSnap.data().active !== true) throw new HttpsError('failed-precondition', 'Merchant is not active.');
      merchant = merchantSnap.data();
      const price = Number(proposal.price);
      if (typeof proposal.name !== 'string' || proposal.name.trim().length < 2 || proposal.name.length > 100 || typeof proposal.category !== 'string' || proposal.category.trim().length < 2 || proposal.category.length > 60 || !Number.isSafeInteger(price) || price < 1 || price > 100000000) {
        throw new HttpsError('failed-precondition', 'Product proposal data is invalid.');
      }
      const image = typeof proposal.image === 'string' ? proposal.image.trim() : '';
      if (image) { let parsed; try { parsed = new URL(image); } catch (_) { throw new HttpsError('failed-precondition', 'Product image URL is invalid.'); } if (parsed.protocol !== 'https:') throw new HttpsError('failed-precondition', 'Product image URL must use HTTPS.'); }
      const now = FieldValue.serverTimestamp();
      tx.create(productRef, {
        name: proposal.name.trim(), category: proposal.category.trim(), description: typeof proposal.description === 'string' ? proposal.description.trim().slice(0, 1000) : '',
        price, image, seller: String(merchant.storeName || proposal.storeName || 'متجر').slice(0, 80), sellerId: proposal.ownerUid,
        ownerUid: proposal.ownerUid, status: 'approved', active: true, createdAt: now, updatedAt: now
      });
      tx.update(requestRef, { status: 'approved', reviewedAt: now, reviewedBy: request.auth.uid, publishedProductId: productRef.id });
      tx.create(db.collection('admin_audit_logs').doc(), { action: 'seller_product_approved', requestId, productId: productRef.id, merchantUid: proposal.ownerUid, adminUid: request.auth.uid, createdAt: now });
      return { requestId, productId: productRef.id, status: 'approved' };
    }
    const now = FieldValue.serverTimestamp();
    const reason = typeof request.data?.reason === 'string' ? request.data.reason.trim().slice(0, 300) : '';
    tx.update(requestRef, { status: 'rejected', reviewReason: reason, reviewedAt: now, reviewedBy: request.auth.uid });
    tx.create(db.collection('admin_audit_logs').doc(), { action: 'seller_product_rejected', requestId, adminUid: request.auth.uid, reason, createdAt: now });
    return { requestId, status: 'rejected' };
  });
});

exports.createMarketplaceOrder = onCall({ region: REGION, maxInstances: 10 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in before placing an order.');

  const uid = request.auth.uid;
  const data = request.data || {};
  const requestId = text(data.requestId, 12, 80, 'requestId');
  if (!/^[A-Za-z0-9_-]+$/.test(requestId)) throw new HttpsError('invalid-argument', 'Invalid requestId');

  const phone = text(data.phone, 5, 25, 'phone');
  const wilaya = text(data.wilaya, 2, 60, 'wilaya');
  const address = text(data.address, 5, 300, 'address');
  const note = typeof data.note === 'string' ? data.note.trim().slice(0, 300) : '';
  const paymentMethod = data.paymentMethod === 'baridimob' ? 'baridimob' : 'cash_on_delivery';
  if (!Array.isArray(data.items) || data.items.length < 1 || data.items.length > 30) {
    throw new HttpsError('invalid-argument', 'Cart must contain between 1 and 30 items.');
  }

  const quantities = new Map();
  for (const item of data.items) {
    if (!item || typeof item.productId !== 'string' || item.productId.length < 1 || item.productId.length > 150) {
      throw new HttpsError('invalid-argument', 'Invalid product in cart.');
    }
    const quantity = Number(item.quantity);
    if (!Number.isSafeInteger(quantity) || quantity < 1) {
      throw new HttpsError('invalid-argument', 'Invalid product quantity.');
    }
    const combinedQuantity = (quantities.get(item.productId) || 0) + quantity;
    if (!Number.isSafeInteger(combinedQuantity)) throw new HttpsError('invalid-argument', 'Requested quantity is too large.');
    quantities.set(item.productId, combinedQuantity);
  }
  if (quantities.size > 30) throw new HttpsError('invalid-argument', 'Too many unique products.');

  const orderId = `${uid}_${requestId}`;
  const orderRef = db.collection('orders').doc(orderId);
  const userRef = db.collection('users').doc(uid);
  const productRefs = [...quantities.keys()].map(id => db.collection('products').doc(id));

  return db.runTransaction(async (tx) => {
    const existingOrder = await tx.get(orderRef);
    if (existingOrder.exists) {
      return { orderId, status: existingOrder.data().status || 'pending_confirmation', alreadyCreated: true };
    }

    const userSnap = await tx.get(userRef);
    if (!userSnap.exists || !['customer', 'seller'].includes(userSnap.data().role) || userSnap.data().status === 'suspended' || userSnap.data().active === false) {
      throw new HttpsError('permission-denied', 'Customer profile is unavailable or suspended.');
    }

    const productSnaps = [];
    for (const ref of productRefs) productSnaps.push(await tx.get(ref));

    const products = [];
    const merchantIds = new Set();
    for (let i = 0; i < productSnaps.length; i++) {
      const snap = productSnaps[i];
      if (!snap.exists) throw new HttpsError('not-found', 'A product in your cart no longer exists.');
      const p = snap.data();
      if (p.status !== 'approved' || p.active !== true) throw new HttpsError('failed-precondition', 'A product is not available.');
      if (typeof p.ownerUid !== 'string' || !p.ownerUid) throw new HttpsError('failed-precondition', 'A product has no valid merchant.');
      if (!Number.isSafeInteger(p.price) || p.price < 1) {
        throw new HttpsError('failed-precondition', 'A product has invalid price data.');
      }
      // Quantity is the customer's requested order quantity, not inventory.
      const quantity = quantities.get(snap.id);
      if (!Number.isSafeInteger(quantity) || quantity < 1) {
        throw new HttpsError('invalid-argument', 'Invalid requested quantity.');
      }
      merchantIds.add(p.ownerUid);
      products.push({ ref: productRefs[i], id: snap.id, data: p, quantity });
    }
    if (merchantIds.size > 20) throw new HttpsError('invalid-argument', 'An order can contain products from at most 20 merchants.');

    const merchantRefs = [...merchantIds].map(id => db.collection('merchants').doc(id));
    const merchantSnaps = [];
    for (const ref of merchantRefs) merchantSnaps.push(await tx.get(ref));
    const merchants = new Map();
    for (let i = 0; i < merchantSnaps.length; i++) {
      const snap = merchantSnaps[i];
      if (!snap.exists || snap.data().status !== 'approved' || snap.data().active !== true) {
        throw new HttpsError('failed-precondition', 'A merchant in your cart is not active.');
      }
      // Commission is a platform constant. Never trust a merchant-editable field.
      merchants.set(snap.id, { ...snap.data(), uid: snap.id, commissionRate: 3 });
    }

    const lines = [];
    const grouped = new Map();
    let subtotal = 0;
    for (const product of products) {
      const p = product.data;
      const lineTotal = p.price * product.quantity;
      if (!Number.isSafeInteger(lineTotal) || !Number.isSafeInteger(subtotal + lineTotal)) {
        throw new HttpsError('failed-precondition', 'Order total is too large.');
      }
      subtotal += lineTotal;
      const line = {
        productId: product.id,
        name: String(p.name || '').slice(0, 100),
        image: typeof p.image === 'string' ? p.image.slice(0, 500) : '',
        unitPrice: p.price,
        quantity: product.quantity,
        lineTotal,
        merchantUid: p.ownerUid,
        storeName: String(p.seller || merchants.get(p.ownerUid).storeName || 'متجر')
      };
      lines.push(line);
      if (!grouped.has(p.ownerUid)) grouped.set(p.ownerUid, []);
      grouped.get(p.ownerUid).push(line);
    }

    const now = FieldValue.serverTimestamp();
    const merchantUids = [...grouped.keys()];
    const deliveryFee = 0; // The platform confirms the delivery quote after order review.
    const parent = {
      customerUid: uid,
      customerName: String(userSnap.data().name || '').slice(0, 80),
      customerEmail: request.auth.token.email || '',
      phone, wilaya, address, note,
      items: lines,
      merchantUids,
      subtotal,
      deliveryFee,
      deliveryFeeStatus: 'pending_platform_quote',
      total: subtotal + deliveryFee,
      currency: 'DZD',
      paymentMethod,
      paymentStatus: paymentMethod === 'baridimob' ? 'awaiting_transfer_proof' : 'awaiting_collection',
      status: 'pending_confirmation',
      createdAt: now,
      updatedAt: now
    };

    tx.create(orderRef, parent);
    {
      const paymentRef = db.collection('payments').doc(orderId);
      tx.create(paymentRef, { orderId, customerUid: uid, amount: subtotal, method: paymentMethod, status: paymentMethod === 'baridimob' ? 'awaiting_transfer_proof' : 'awaiting_collection', currency: 'DZD', createdAt: now, updatedAt: now });
    }

    // Marketplace order quantities are demand data only; no platform inventory exists.

    for (const [merchantUid, merchantLines] of grouped.entries()) {
      const merchant = merchants.get(merchantUid);
      const merchantSubtotal = merchantLines.reduce((sum, line) => sum + line.lineTotal, 0);
      const commissionAmount = Math.round(merchantSubtotal * merchant.commissionRate / 100);
      const merchantNet = merchantSubtotal - commissionAmount;
      const merchantOrderRef = db.collection('merchant_orders').doc(`${orderId}_${merchantUid}`);
      const commissionRef = db.collection('commissions').doc(`${orderId}_${merchantUid}`);
      const shipmentRef = db.collection('shipments').doc(`${orderId}_${merchantUid}`);

      tx.create(merchantOrderRef, {
        orderId, customerUid: uid, merchantUid,
        storeName: String(merchant.storeName || 'متجر').slice(0, 80),
        items: merchantLines,
        subtotal: merchantSubtotal,
        commissionRate: merchant.commissionRate,
        commissionAmount,
        merchantNet,
        currency: 'DZD',
        status: 'pending_confirmation',
        createdAt: now,
        updatedAt: now
      });
      tx.create(commissionRef, {
        orderId, merchantUid, customerUid: uid,
        grossAmount: merchantSubtotal,
        commissionRate: merchant.commissionRate,
        commissionAmount,
        merchantNet,
        status: 'pending_collection',
        createdAt: now
      });
      tx.create(shipmentRef, {
        orderId, customerUid: uid, merchantUid,
        wilaya, address,
        status: 'awaiting_platform_assignment',
        deliveryCompanyId: null,
        deliveryFee: null,
        createdAt: now,
        updatedAt: now
      });
    }

    return { orderId, status: 'pending_confirmation', alreadyCreated: false, subtotal, merchantCount: merchantUids.length };
  });
});

// Customer submits BaridiMob transfer evidence. Upload alone never marks a payment paid.
exports.submitBaridiMobProof = onCall({ region: REGION, maxInstances: 10 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first.');
  const uid = request.auth.uid;
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const operationNumber = text(request.data?.operationNumber, 4, 80, 'operationNumber');
  const operationDate = text(request.data?.operationDate, 8, 20, 'operationDate');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(operationDate) || Number.isNaN(Date.parse(operationDate))) throw new HttpsError('invalid-argument', 'Invalid operation date.');
  const proofPath = text(request.data?.proofPath, 10, 500, 'proofPath');
  if (!/^payments\/proofs\/[A-Za-z0-9_-]+\/[A-Za-z0-9_.-]+$/.test(proofPath) || !proofPath.startsWith(`payments/proofs/${uid}/`)) {
    throw new HttpsError('invalid-argument', 'Invalid proof storage path.');
  }
  const proofObject = getStorage().bucket().file(proofPath);
  const [proofFile] = await proofObject.getMetadata().catch(() => { throw new HttpsError('failed-precondition', 'Uploaded proof file was not found.'); });
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
  if (Number(proofFile.size) < 8 || Number(proofFile.size) > 5 * 1024 * 1024 || !allowedTypes.includes(proofFile.contentType) || proofFile.metadata?.uploaderUid !== uid) {
    throw new HttpsError('permission-denied', 'Proof file metadata is invalid.');
  }
  const [header] = await proofObject.download({ start: 0, end: 11 }).catch(() => { throw new HttpsError('failed-precondition', 'Could not inspect the uploaded proof file.'); });
  const actualType = header.subarray(0, 5).toString() === '%PDF-' ? 'application/pdf'
    : header[0] === 0xff && header[1] === 0xd8 && header[2] === 0xff ? 'image/jpeg'
    : header.subarray(0, 8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a])) ? 'image/png'
    : header.subarray(0, 4).toString() === 'RIFF' && header.subarray(8, 12).toString() === 'WEBP' ? 'image/webp' : null;
  if (actualType !== proofFile.contentType) throw new HttpsError('permission-denied', 'Proof file content does not match its declared type.');
  const operationHash = crypto.createHash('sha256').update(operationNumber).digest('hex');
  const orderRef = db.collection('orders').doc(orderId);
  const paymentRef = db.collection('payments').doc(orderId);
  const operationRef = db.collection('payment_operations').doc(operationHash);
  return db.runTransaction(async tx => {
    const [orderSnap, paymentSnap, operationSnap] = await Promise.all([tx.get(orderRef), tx.get(paymentRef), tx.get(operationRef)]);
    if (!orderSnap.exists || orderSnap.data().customerUid !== uid) throw new HttpsError('permission-denied', 'Order not found.');
    if (!['pending_confirmation', 'confirmed'].includes(orderSnap.data().status)) throw new HttpsError('failed-precondition', 'This order is no longer payable.');
    if (orderSnap.data().deliveryFeeStatus !== 'confirmed' || !Number.isSafeInteger(orderSnap.data().total)) {
      throw new HttpsError('failed-precondition', 'Wait until the platform confirms the delivery fee and final total before submitting payment proof.');
    }
    if (!paymentSnap.exists || paymentSnap.data().method !== 'baridimob') throw new HttpsError('failed-precondition', 'This order is not awaiting BaridiMob payment.');
    if (operationSnap.exists) throw new HttpsError('already-exists', 'This transfer number was already submitted.');
    if (!['awaiting_transfer_proof', 'rejected'].includes(paymentSnap.data().status)) throw new HttpsError('failed-precondition', 'Payment proof cannot be changed now.');
    const now = FieldValue.serverTimestamp();
    tx.set(operationRef, { orderId, customerUid: uid, operationNumber, createdAt: now });
    tx.update(paymentRef, { operationNumber, operationDate, proofPath, status: 'under_review', submittedAt: now, updatedAt: now });
    tx.update(orderRef, { paymentStatus: 'under_review', updatedAt: now });
    return { orderId, paymentStatus: 'under_review' };
  });
});

// Admin verifies against the actual CCP receipt/statement before confirming payment.
exports.reviewBaridiMobPayment = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const decision = request.data?.decision;
  const reason = typeof request.data?.reason === 'string' ? request.data.reason.trim().slice(0, 300) : '';
  if (!['confirmed', 'rejected'].includes(decision) || (decision === 'rejected' && reason.length < 3)) throw new HttpsError('invalid-argument', 'Invalid review decision or rejection reason.');
  const orderRef = db.collection('orders').doc(orderId);
  const paymentRef = db.collection('payments').doc(orderId);
  return db.runTransaction(async tx => {
    const [orderSnap, paymentSnap] = await Promise.all([tx.get(orderRef), tx.get(paymentRef)]);
    if (!orderSnap.exists || !paymentSnap.exists || paymentSnap.data().method !== 'baridimob') throw new HttpsError('not-found', 'Payment record not found.');
    if (paymentSnap.data().status !== 'under_review') throw new HttpsError('failed-precondition', 'Payment is not under review.');
    if (!['pending_confirmation', 'confirmed'].includes(orderSnap.data().status)) throw new HttpsError('failed-precondition', 'A cancelled or closed order cannot be paid.');
    if (decision === 'confirmed' && (orderSnap.data().deliveryFeeStatus !== 'confirmed' || paymentSnap.data().amount !== orderSnap.data().total)) {
      throw new HttpsError('failed-precondition', 'Payment amount does not match the confirmed final order total.');
    }
    const now = FieldValue.serverTimestamp();
    const status = decision === 'confirmed' ? 'paid' : 'rejected';
    tx.update(paymentRef, { status, reviewedBy: request.auth.uid, reviewedAt: now, rejectionReason: decision === 'rejected' ? reason : null, updatedAt: now });
    tx.update(orderRef, { paymentStatus: status, updatedAt: now });
    tx.create(db.collection('admin_audit_logs').doc(), { adminUid: request.auth.uid, action: `baridimob_${decision}`, orderId, reason, createdAt: now });
    return { orderId, paymentStatus: status };
  });
});

// Admin assigns one active delivery partner and confirms the total delivery fee.
exports.assignMarketplaceDelivery = onCall({ region: REGION, maxInstances: 10 }, async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError('permission-denied', 'Administrator access required.');
  }
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const companyId = text(request.data?.companyId, 1, 150, 'companyId');
  const deliveryFee = Number(request.data?.deliveryFee);
  if (!Number.isSafeInteger(deliveryFee) || deliveryFee < 0 || deliveryFee > 1000000) {
    throw new HttpsError('invalid-argument', 'Invalid delivery fee.');
  }
  const orderRef = db.collection('orders').doc(orderId);
  const companyRef = db.collection('delivery_companies').doc(companyId);
  return db.runTransaction(async (tx) => {
    const orderSnap = await tx.get(orderRef);
    const companySnap = await tx.get(companyRef);
    if (!orderSnap.exists) throw new HttpsError('not-found', 'Order not found.');
    if (!companySnap.exists || companySnap.data().active !== true) {
      throw new HttpsError('failed-precondition', 'Delivery company is not active.');
    }
    const order = orderSnap.data();
    const paymentRef = db.collection('payments').doc(orderId);
    const paymentSnap = await tx.get(paymentRef);
    if (!['pending_confirmation', 'confirmed'].includes(order.status)) {
      throw new HttpsError('failed-precondition', 'This order can no longer be assigned.');
    }
    const merchantUids = Array.isArray(order.merchantUids) ? order.merchantUids : [];
    if (!merchantUids.length || merchantUids.length > 20) throw new HttpsError('failed-precondition', 'Invalid order shipment data.');
    const shipmentRefs = merchantUids.map(uid => db.collection('shipments').doc(`${orderId}_${uid}`));
    const shipmentSnaps = [];
    for (const ref of shipmentRefs) shipmentSnaps.push(await tx.get(ref));
    if (shipmentSnaps.some(s => !s.exists || s.data().status === 'cancelled')) {
      throw new HttpsError('failed-precondition', 'Shipment records are unavailable or cancelled.');
    }
    const baseFee = Math.floor(deliveryFee / shipmentRefs.length);
    let remainder = deliveryFee - baseFee * shipmentRefs.length;
    const now = FieldValue.serverTimestamp();
    shipmentRefs.forEach((ref, index) => {
      const fee = baseFee + (remainder-- > 0 ? 1 : 0);
      tx.update(ref, {
        deliveryCompanyId: companyId,
        deliveryCompanyName: String(companySnap.data().name || companySnap.data().companyName || 'شركة توصيل').slice(0, 100),
        deliveryFee: fee,
        status: 'assigned',
        assignedAt: now,
        updatedAt: now
      });
    });
    const confirmedTotal = Number(order.subtotal || 0) + deliveryFee;
    if (paymentSnap.exists) {
      const expectedStatus = paymentSnap.data().method === 'baridimob' ? 'awaiting_transfer_proof' : 'awaiting_collection';
      if (paymentSnap.data().status !== expectedStatus) throw new HttpsError('failed-precondition', 'Payment is already being reviewed or collected; delivery fee cannot be changed.');
      tx.update(paymentRef, { amount: confirmedTotal, deliveryFee, updatedAt: now });
    }
    tx.update(orderRef, {
      deliveryFee,
      total: confirmedTotal,
      deliveryFeeStatus: 'confirmed',
      deliveryCompanyId: companyId,
      deliveryCompanyName: String(companySnap.data().name || companySnap.data().companyName || 'شركة توصيل').slice(0, 100),
      status: 'confirmed',
      updatedAt: now
    });
    return { orderId, deliveryFee, shipmentCount: shipmentRefs.length, status: 'confirmed' };
  });
});

// Confirm delivery and update shipment/order/payment lifecycle only; never alter product inventory.
exports.completeMarketplaceDelivery = onCall({ region: REGION, maxInstances: 10 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const orderRef = db.collection('orders').doc(orderId);
  return db.runTransaction(async tx => {
    const orderSnap = await tx.get(orderRef);
    if (!orderSnap.exists) throw new HttpsError('not-found', 'Order not found.');
    const order = orderSnap.data();
    if (order.status === 'delivered') return { orderId, status: 'delivered', alreadyCompleted: true };
    if (order.status !== 'confirmed' && order.status !== 'out_for_delivery') throw new HttpsError('failed-precondition', 'Order is not ready for delivery completion.');
    const merchantUids = Array.isArray(order.merchantUids) ? order.merchantUids : [];
    if (!merchantUids.length) throw new HttpsError('failed-precondition', 'Order has no merchant shipments.');
    const deliveryShipmentRefs = merchantUids.map(uid => db.collection('shipments').doc(`${orderId}_${uid}`));
    const deliveryShipmentSnaps = [];
    for (const ref of deliveryShipmentRefs) deliveryShipmentSnaps.push(await tx.get(ref));
    if (deliveryShipmentSnaps.some(s => !s.exists || s.data().status !== 'out_for_delivery')) {
      throw new HttpsError('failed-precondition', 'Every merchant shipment must be out for delivery before confirming the whole order delivered.');
    }
    const childRefs = merchantUids.map(uid => ({
      merchantOrderRef: db.collection('merchant_orders').doc(`${orderId}_${uid}`),
      shipmentRef: db.collection('shipments').doc(`${orderId}_${uid}`)
    }));
    const childSnaps = [];
    for (const child of childRefs) childSnaps.push(await Promise.all([tx.get(child.merchantOrderRef), tx.get(child.shipmentRef)]));
    const commissionRefs = merchantUids.map(uid => db.collection('commissions').doc(`${orderId}_${uid}`));
    const commissionSnaps = [];
    for (const ref of commissionRefs) commissionSnaps.push(await tx.get(ref));
    // Complete every transaction read before writing any document.
    const now = FieldValue.serverTimestamp();
    childRefs.forEach((child, index) => {
      const [merchantOrderSnap, shipmentSnap] = childSnaps[index];
      if (merchantOrderSnap.exists) tx.update(child.merchantOrderRef, { status: 'delivered', deliveredAt: now, updatedAt: now });
      if (shipmentSnap.exists) tx.update(child.shipmentRef, { status: 'delivered', deliveredAt: now, updatedAt: now });
    });
    if (order.paymentMethod === 'baridimob' && order.paymentStatus === 'paid') {
      commissionRefs.forEach((ref, index) => {
        if (commissionSnaps[index].exists) tx.update(ref, { status: 'eligible_for_settlement', eligibleAt: now, updatedAt: now });
      });
    }
    tx.update(orderRef, { status: 'delivered', deliveredAt: now, updatedAt: now });
    return { orderId, status: 'delivered' };
  });
});

// Admin reconciles the cash actually collected by the delivery company. This is a manual
// confirmation against the carrier's remittance statement; it never assumes collection.
exports.confirmCodCollection = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const reference = text(request.data?.reference, 3, 100, 'collection reference');
  const collectedAmount = Number(request.data?.collectedAmount);
  if (!Number.isSafeInteger(collectedAmount) || collectedAmount <= 0) throw new HttpsError('invalid-argument', 'Enter the exact collected amount in DZD.');
  const orderRef = db.collection('orders').doc(orderId);
  const paymentRef = db.collection('payments').doc(orderId);
  return db.runTransaction(async tx => {
    const [orderSnap, paymentSnap] = await Promise.all([tx.get(orderRef), tx.get(paymentRef)]);
    if (!orderSnap.exists || !paymentSnap.exists) throw new HttpsError('not-found', 'COD order/payment not found.');
    const order = orderSnap.data(); const payment = paymentSnap.data();
    if (order.paymentMethod !== 'cash_on_delivery' || payment.method !== 'cash_on_delivery') throw new HttpsError('failed-precondition', 'This order is not cash on delivery.');
    if (order.status !== 'delivered') throw new HttpsError('failed-precondition', 'COD can only be reconciled after successful delivery.');
    if (payment.status === 'paid') return { orderId, status: 'paid', alreadyCollected: true };
    if (payment.status !== 'awaiting_collection' || order.paymentStatus !== 'awaiting_collection') throw new HttpsError('failed-precondition', 'COD payment is not awaiting collection.');
    if (order.deliveryFeeStatus !== 'confirmed' || collectedAmount !== order.total || payment.amount !== order.total) throw new HttpsError('failed-precondition', 'Collected amount must exactly match the confirmed order total.');
    const merchantUids = Array.isArray(order.merchantUids) ? order.merchantUids : [];
    const commissionRefs = merchantUids.map(uid => db.collection('commissions').doc(`${orderId}_${uid}`));
    const commissionSnaps = [];
    for (const ref of commissionRefs) commissionSnaps.push(await tx.get(ref));
    const now = FieldValue.serverTimestamp();
    tx.update(paymentRef, { status: 'paid', collectedAmount, collectionReference: reference, collectedBy: request.auth.uid, collectedAt: now, updatedAt: now });
    tx.update(orderRef, { paymentStatus: 'paid', codCollectionReference: reference, codCollectedAt: now, updatedAt: now });
    commissionRefs.forEach((ref, index) => {
      if (commissionSnaps[index].exists && commissionSnaps[index].data().status === 'pending_collection') tx.update(ref, { status: 'eligible_for_settlement', eligibleAt: now, collectionReference: reference, updatedAt: now });
    });
    tx.create(db.collection('cod_collections').doc(orderId), { orderId, customerUid: order.customerUid, amount: collectedAmount, currency: 'DZD', deliveryCompanyId: order.deliveryCompanyId || null, reference, confirmedBy: request.auth.uid, status: 'reconciled', createdAt: now });
    tx.create(db.collection('admin_audit_logs').doc(), { adminUid: request.auth.uid, action: 'cod_collection_confirmed', orderId, amount: collectedAmount, reference, createdAt: now });
    return { orderId, status: 'paid', amount: collectedAmount };
  });
});

// Customer may cancel only before admin confirmation; inventory is not restored because it was never reserved.
exports.cancelMarketplaceOrder = onCall({ region: REGION, maxInstances: 10 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first.');
  const uid = request.auth.uid;
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const orderRef = db.collection('orders').doc(orderId);
  return db.runTransaction(async (tx) => {
    const orderSnap = await tx.get(orderRef);
    if (!orderSnap.exists) throw new HttpsError('not-found', 'Order not found.');
    const order = orderSnap.data();
    if (order.customerUid !== uid && request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'You cannot cancel this order.');
    if (order.status === 'cancelled') return { orderId, status: 'cancelled', alreadyCancelled: true };
    if (order.status !== 'pending_confirmation') throw new HttpsError('failed-precondition', 'Only unconfirmed orders can be cancelled.');
    const paymentRef = db.collection('payments').doc(orderId);
    const paymentSnap = await tx.get(paymentRef);
    if (paymentSnap.exists && ['under_review', 'paid'].includes(paymentSnap.data().status)) {
      throw new HttpsError('failed-precondition', 'A payment under review or already paid must be resolved by the platform before cancellation.');
    }
    const lines = Array.isArray(order.items) ? order.items : [];
    if (!lines.length || lines.length > 30) throw new HttpsError('failed-precondition', 'Invalid order items.');
    const merchantUids = Array.isArray(order.merchantUids) ? order.merchantUids : [];
    const childRefs = merchantUids.map(merchantUid => ({
      merchantUid,
      merchantOrderRef: db.collection('merchant_orders').doc(`${orderId}_${merchantUid}`),
      commissionRef: db.collection('commissions').doc(`${orderId}_${merchantUid}`),
      shipmentRef: db.collection('shipments').doc(`${orderId}_${merchantUid}`)
    }));
    const childSnaps = [];
    for (const refs of childRefs) childSnaps.push(await Promise.all([tx.get(refs.merchantOrderRef), tx.get(refs.commissionRef), tx.get(refs.shipmentRef)]));
    // All transaction reads are complete before the first write.
    const now = FieldValue.serverTimestamp();
    // Cancellation changes order/shipment/payment state only.
    childRefs.forEach((refs, index) => {
      const [merchantOrder, commission, shipment] = childSnaps[index];
      if (merchantOrder.exists) tx.update(refs.merchantOrderRef, { status: 'cancelled', updatedAt: now });
      if (commission.exists) tx.update(refs.commissionRef, { status: 'cancelled', updatedAt: now });
      if (shipment.exists) tx.update(refs.shipmentRef, { status: 'cancelled', updatedAt: now });
    });
    if (paymentSnap.exists) tx.update(paymentRef, { status: 'cancelled', cancelledAt: now, updatedAt: now });
    tx.update(orderRef, { status: 'cancelled', paymentStatus: paymentSnap.exists ? 'cancelled' : order.paymentStatus, cancelledAt: now, updatedAt: now });
    return { orderId, status: 'cancelled' };
  });
});


// Admin-controlled order lifecycle. Tracking numbers are stored on each shipment.
exports.updateMarketplaceShipment = onCall({ region: REGION, maxInstances: 10 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const merchantUid = text(request.data?.merchantUid, 1, 128, 'merchantUid');
  const status = request.data?.status;
  const trackingNumber = typeof request.data?.trackingNumber === 'string' ? request.data.trackingNumber.trim().slice(0, 100) : '';
  const failureReason = typeof request.data?.failureReason === 'string' ? request.data.failureReason.trim().slice(0, 300) : '';
  const allowed = ['preparing', 'shipped', 'out_for_delivery', 'delivery_failed'];
  if (status === 'delivery_failed' && failureReason.length < 3) throw new HttpsError('invalid-argument', 'A clear delivery failure reason is required.');
  if (!allowed.includes(status)) throw new HttpsError('invalid-argument', 'Invalid shipment status.');
  const orderRef = db.collection('orders').doc(orderId);
  const shipmentRef = db.collection('shipments').doc(`${orderId}_${merchantUid}`);
  const merchantOrderRef = db.collection('merchant_orders').doc(`${orderId}_${merchantUid}`);
  return db.runTransaction(async tx => {
    const [orderSnap, shipmentSnap, merchantOrderSnap] = await Promise.all([tx.get(orderRef), tx.get(shipmentRef), tx.get(merchantOrderRef)]);
    if (!orderSnap.exists || !shipmentSnap.exists || !merchantOrderSnap.exists) throw new HttpsError('not-found', 'Order shipment not found.');
    if (['cancelled', 'delivered', 'returned', 'partially_returned'].includes(orderSnap.data().status)) throw new HttpsError('failed-precondition', 'Closed orders cannot be changed.');
    const currentShipmentStatus = shipmentSnap.data().status || 'assigned';
    const transitions = { assigned: ['preparing'], preparing: ['shipped'], shipped: ['out_for_delivery', 'delivery_failed'], out_for_delivery: ['delivery_failed'], delivery_failed: ['preparing', 'shipped', 'out_for_delivery'] };
    if (currentShipmentStatus !== status && !(transitions[currentShipmentStatus] || []).includes(status)) throw new HttpsError('failed-precondition', `Invalid shipment transition from ${currentShipmentStatus} to ${status}.`);
    // Read the full shipment set before the first transaction write.
    const shipmentQuery = db.collection('shipments').where('orderId', '==', orderId);
    const allShipments = await tx.get(shipmentQuery);
    const now = FieldValue.serverTimestamp();
    const cleanTracking = trackingNumber || shipmentSnap.data().trackingNumber || '';
    tx.update(shipmentRef, { status, trackingNumber: cleanTracking, updatedAt: now, ...(status === 'shipped' ? { shippedAt: now } : {}), ...(status === 'out_for_delivery' ? { outForDeliveryAt: now } : {}), ...(status === 'delivery_failed' ? { deliveryFailedAt: now, failureReason, deliveryAttemptCount: Number(shipmentSnap.data().deliveryAttemptCount || 0) + 1 } : {}), ...(status !== 'delivery_failed' && currentShipmentStatus === 'delivery_failed' ? { lastFailureReason: shipmentSnap.data().failureReason || '' } : {}) });
    tx.update(merchantOrderRef, { status, updatedAt: now });
    // Parent status reflects all merchant shipments instead of being overwritten by the last edited shipment.
    const states = allShipments.docs.map(d => d.id === shipmentRef.id ? status : (d.data().status || 'assigned'));
    let parentStatus = 'confirmed';
    if (states.length && states.every(v => v === 'delivered')) parentStatus = 'delivered';
    else if (states.includes('delivery_failed')) parentStatus = 'delivery_failed';
    else if (states.every(v => ['out_for_delivery','delivered'].includes(v))) parentStatus = 'out_for_delivery';
    else if (states.some(v => ['shipped','out_for_delivery','delivered'].includes(v))) parentStatus = 'shipped';
    else if (states.some(v => v === 'preparing')) parentStatus = 'preparing';
    tx.update(orderRef, { status: parentStatus, updatedAt: now });
    tx.create(db.collection('shipment_events').doc(), { orderId, customerUid: orderSnap.data().customerUid, merchantUid, status, trackingNumber: cleanTracking, failureReason: status === 'delivery_failed' ? failureReason : '', actorUid: request.auth.uid, createdAt: now });
    return { orderId, merchantUid, status, parentStatus };
  });
});

// Customer return request is a marketplace case record. Physical handling remains
// between the customer and the responsible merchant; SOUFI STORE has no warehouse.
exports.requestMarketplaceReturn = onCall({ region: REGION, maxInstances: 10 }, async request => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first.');
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const reason = text(request.data?.reason, 5, 500, 'return reason');
  const rawItems = request.data?.items;
  const orderRef = db.collection('orders').doc(orderId);
  const returnRef = db.collection('return_requests').doc(orderId);
  return db.runTransaction(async tx => {
    const [orderSnap, returnSnap] = await Promise.all([tx.get(orderRef), tx.get(returnRef)]);
    if (!orderSnap.exists || orderSnap.data().customerUid !== request.auth.uid) throw new HttpsError('permission-denied', 'Order not found for this customer.');
    const order = orderSnap.data();
    if (order.status !== 'delivered') throw new HttpsError('failed-precondition', 'Only delivered orders can be submitted for return review.');
    if (returnSnap.exists) throw new HttpsError('already-exists', 'A return request has already been recorded for this order.');
    const orderLines = Array.isArray(order.items) ? order.items : [];
    if (!orderLines.length || orderLines.length > 30) throw new HttpsError('failed-precondition', 'Order lines are unavailable for return.');
    // Older clients may omit items; in that case preserve the original whole-order return behavior.
    const requested = Array.isArray(rawItems) ? rawItems : orderLines.map(line => ({ productId: line.productId, quantity: line.quantity }));
    if (!requested.length || requested.length > orderLines.length) throw new HttpsError('invalid-argument', 'Select at least one valid product to return.');
    const orderLineMap = new Map(orderLines.map(line => [String(line.productId), line]));
    const normalized = new Map();
    for (const item of requested) {
      const productId = text(item?.productId, 1, 150, 'return productId');
      const quantity = Number(item?.quantity);
      const line = orderLineMap.get(productId);
      if (!line || normalized.has(productId) || !Number.isSafeInteger(quantity) || quantity < 1 || quantity > Number(line.quantity || 0)) {
        throw new HttpsError('invalid-argument', 'A returned product or quantity is invalid.');
      }
      normalized.set(productId, { productId, quantity, merchantUid: line.merchantUid, name: String(line.name || '').slice(0, 120), unitPrice: Number(line.unitPrice || 0), lineTotal: Number(line.unitPrice || 0) * quantity });
    }
    const now = FieldValue.serverTimestamp();
    tx.set(returnRef, {
      orderId, customerUid: request.auth.uid, merchantUids: [...new Set([...normalized.values()].map(x => x.merchantUid).filter(Boolean))],
      items: [...normalized.values()], reason, status: 'pending_review', createdAt: now, updatedAt: now
    });
    tx.create(db.collection('admin_audit_logs').doc(), { action: 'return_requested', orderId, customerUid: request.auth.uid, itemCount: normalized.size, createdAt: now });
    return { orderId, status: 'pending_review', itemCount: normalized.size };
  });
});

// Admin reviews the marketplace return case. 'received' means the merchant confirms
// receipt/handling with the customer; it does not mean platform warehouse receipt.
exports.reviewMarketplaceReturn = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const decision = request.data?.decision;
  const note = typeof request.data?.note === 'string' ? request.data.note.trim().slice(0, 500) : '';
  if (!['approved','rejected','received'].includes(decision)) throw new HttpsError('invalid-argument', 'Invalid return decision.');
  const returnRef = db.collection('return_requests').doc(orderId);
  const orderRef = db.collection('orders').doc(orderId);
  return db.runTransaction(async tx => {
    const [returnSnap, orderSnap] = await Promise.all([tx.get(returnRef), tx.get(orderRef)]);
    if (!returnSnap.exists || !orderSnap.exists) throw new HttpsError('not-found', 'Return request not found.');
    const current = returnSnap.data().status;
    if (decision === 'approved' && current !== 'pending_review') throw new HttpsError('failed-precondition', 'Return is not awaiting review.');
    if (decision === 'rejected' && current !== 'pending_review') throw new HttpsError('failed-precondition', 'Return is not awaiting review.');
    if (decision === 'received' && current !== 'approved') throw new HttpsError('failed-precondition', 'Only an approved return can be marked received.');
    const returnData = returnSnap.data();
    const returnItems = Array.isArray(returnData.items) && returnData.items.length
      ? returnData.items
      : (Array.isArray(orderSnap.data().items) ? orderSnap.data().items.map(line => ({ productId: line.productId, quantity: line.quantity, merchantUid: line.merchantUid, name: line.name, unitPrice: line.unitPrice, lineTotal: line.lineTotal })) : []);
    const uids = decision === 'received' ? [...new Set(returnItems.map(item => item.merchantUid).filter(Boolean))] : [];
    const commissionRefs = uids.map(uid => db.collection('commissions').doc(`${orderId}_${uid}`));
    const merchantOrderRefs = uids.map(uid => db.collection('merchant_orders').doc(`${orderId}_${uid}`));
    const commissionSnaps = [];
    const merchantOrderSnaps = [];
    for (const ref of commissionRefs) commissionSnaps.push(await tx.get(ref));
    for (const ref of merchantOrderRefs) merchantOrderSnaps.push(await tx.get(ref));
    const now = FieldValue.serverTimestamp();
    const status = decision === 'approved' ? 'approved' : decision === 'rejected' ? 'rejected' : 'merchant_confirmed_received';
    tx.update(returnRef, { status, adminNote: note, reviewedBy: request.auth.uid, reviewedAt: now, updatedAt: now, ...(decision === 'received' ? { receivedAt: now } : {}) });
    if (decision === 'received') {
      const orderLines = Array.isArray(orderSnap.data().items) ? orderSnap.data().items : [];
      const returnedByProduct = new Map(returnItems.map(item => [String(item.productId), Number(item.quantity)]));
      const allReturned = orderLines.length > 0 && orderLines.every(line => returnedByProduct.get(String(line.productId)) === Number(line.quantity));
      tx.update(orderRef, { status: allReturned ? 'returned' : 'partially_returned', returnStatus: 'merchant_confirmed_received', updatedAt: now });
      commissionRefs.forEach((ref, index) => {
        if (commissionSnaps[index].exists && ['eligible_for_settlement', 'pending_collection'].includes(commissionSnaps[index].data().status)) tx.update(ref, { status: 'return_review', returnItems, updatedAt: now });
      });
      merchantOrderRefs.forEach((ref, index) => {
        if (!merchantOrderSnaps[index].exists) return;
        const merchantUid = uids[index];
        const merchantLines = orderLines.filter(line => line.merchantUid === merchantUid);
        const merchantReturned = merchantLines.length > 0 && merchantLines.every(line => returnedByProduct.get(String(line.productId)) === Number(line.quantity));
        tx.update(ref, { status: merchantReturned ? 'returned' : 'partially_returned', returnStatus: 'merchant_confirmed_received', updatedAt: now });
      });
    }
    tx.create(db.collection('admin_audit_logs').doc(), { action: `return_${decision}`, orderId, adminUid: request.auth.uid, note, createdAt: now });
    return { orderId, status };
  });
});

// Close a marketplace return case without physical inspection or stock restoration.
// The merchant/customer handle the physical item outside the platform.
exports.disposeMarketplaceReturn = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const orderId = text(request.data?.orderId, 5, 180, 'orderId');
  const returnRef = db.collection('return_requests').doc(orderId);
  const orderRef = db.collection('orders').doc(orderId);
  return db.runTransaction(async tx => {
    const [returnSnap, orderSnap] = await Promise.all([tx.get(returnRef), tx.get(orderRef)]);
    if (!returnSnap.exists || !orderSnap.exists) throw new HttpsError('not-found', 'Return request not found.');
    if (returnSnap.data().status !== 'merchant_confirmed_received') {
      throw new HttpsError('failed-precondition', 'The merchant must confirm handling of the return with the customer before the case can be closed.');
    }
    const now = FieldValue.serverTimestamp();
    tx.update(returnRef, { status: 'closed', closedBy: request.auth.uid, closedAt: now, updatedAt: now,
      handlingNote: typeof request.data?.note === 'string' ? request.data.note.trim().slice(0, 500) : '' });
    tx.update(orderRef, { returnStatus: 'closed', returnClosedAt: now, updatedAt: now });
    tx.create(db.collection('admin_audit_logs').doc(), { action: 'marketplace_return_case_closed', orderId, adminUid: request.auth.uid, createdAt: now });
    return { orderId, status: 'closed' };
  });
});

exports.saveDeliveryCompany = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const name = text(request.data?.name, 2, 100, 'company name');
  const phone = typeof request.data?.phone === 'string' ? request.data.phone.trim().slice(0, 25) : '';
  const website = typeof request.data?.website === 'string' ? request.data.website.trim().slice(0, 200) : '';
  const active = request.data?.active !== false;
  const companyId = typeof request.data?.companyId === 'string' ? request.data.companyId.trim() : '';
  const ref = companyId ? db.collection('delivery_companies').doc(companyId) : db.collection('delivery_companies').doc();
  const now = FieldValue.serverTimestamp();
  await ref.set({ name, phone, website, active, updatedAt: now, ...(companyId ? {} : { createdAt: now }) }, { merge: true });
  return { companyId: ref.id, saved: true };
});

exports.createMerchantSettlement = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const merchantUid = text(request.data?.merchantUid, 1, 128, 'merchantUid');
  const reference = typeof request.data?.reference === 'string' ? request.data.reference.trim().slice(0, 100) : '';
  const note = typeof request.data?.note === 'string' ? request.data.note.trim().slice(0, 300) : '';
  const eligibleQuery = db.collection('commissions').where('merchantUid', '==', merchantUid).where('status', '==', 'eligible_for_settlement').limit(400);
  return db.runTransaction(async tx => {
    const eligible = await tx.get(eligibleQuery);
    if (eligible.empty) throw new HttpsError('failed-precondition', 'No eligible merchant balance to settle.');
    const total = eligible.docs.reduce((sum, d) => sum + Number(d.data().merchantNet || 0), 0);
    if (!Number.isSafeInteger(total) || total <= 0) throw new HttpsError('failed-precondition', 'Invalid settlement amount.');
    const settlementRef = db.collection('merchant_settlements').doc();
    const now = FieldValue.serverTimestamp();
    tx.create(settlementRef, { merchantUid, amount: total, commissionCount: eligible.size, commissionIds: eligible.docs.map(d => d.id), status: 'paid', reference, note, paidBy: request.auth.uid, createdAt: now, paidAt: now });
    eligible.docs.forEach(d => tx.update(d.ref, { status: 'settled', settlementId: settlementRef.id, settledAt: now, updatedAt: now }));
    tx.create(db.collection('admin_audit_logs').doc(), { adminUid: request.auth.uid, action: 'merchant_settlement_paid', merchantUid, settlementId: settlementRef.id, amount: total, createdAt: now });
    return { settlementId: settlementRef.id, merchantUid, amount: total, status: 'paid' };
  });
});

exports.submitAdCampaign = onCall({ region: REGION, maxInstances: 10 }, async request => {
  const uid = requireActiveSeller(request);
  const type = request.data?.type;
  if (!['SOUFI_PRO', 'SOUFI_VIP'].includes(type)) throw new HttpsError('invalid-argument', 'Choose SOUFI PRO or SOUFI VIP.');
  const title = text(request.data?.title, 3, 100, 'campaign title');
  const productId = text(request.data?.productId, 1, 150, 'productId');
  const productRef = db.collection('products').doc(productId);
  const campaignRef = db.collection('ad_campaigns').doc();
  return db.runTransaction(async tx => {
    await assertActiveSeller(tx, uid);
    const productSnap = await tx.get(productRef);
    if (!productSnap.exists || productSnap.data().ownerUid !== uid || productSnap.data().status !== 'approved' || productSnap.data().deletedAt) throw new HttpsError('not-found', 'Published product not found.');
    const now = FieldValue.serverTimestamp();
    tx.create(campaignRef, { merchantUid: uid, productId, productName: productSnap.data().name, type, title, status: 'pending_review', priceStatus: 'not_quoted', createdAt: now, updatedAt: now });
    return { campaignId: campaignRef.id, status: 'pending_review' };
  });
});

// Merchant submits the BaridiMob transfer reference for an approved ad campaign.
// Campaigns remain hidden until an administrator verifies the actual account statement.
exports.submitAdCampaignPayment = onCall({ region: REGION, maxInstances: 10 }, async request => {
  const uid = requireActiveSeller(request);
  const campaignId = text(request.data?.campaignId, 1, 150, 'campaignId');
  const operationNumber = text(request.data?.operationNumber, 4, 80, 'operationNumber');
  const operationDate = text(request.data?.operationDate, 8, 20, 'operationDate');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(operationDate) || Number.isNaN(Date.parse(operationDate))) throw new HttpsError('invalid-argument', 'Invalid operation date.');
  const operationHash = crypto.createHash('sha256').update(operationNumber).digest('hex');
  const campaignRef = db.collection('ad_campaigns').doc(campaignId);
  // Share the same global transfer-number registry used by order payments.
  const operationRef = db.collection('payment_operations').doc(operationHash);
  return db.runTransaction(async tx => {
    const [campaignSnap, operationSnap] = await Promise.all([tx.get(campaignRef), tx.get(operationRef)]);
    if (!campaignSnap.exists || campaignSnap.data().merchantUid !== uid) throw new HttpsError('not-found', 'Campaign not found.');
    if (campaignSnap.data().status !== 'awaiting_payment' || !Number.isSafeInteger(campaignSnap.data().priceQuote) || campaignSnap.data().priceQuote <= 0) throw new HttpsError('failed-precondition', 'Campaign is not awaiting payment.');
    if (operationSnap.exists) throw new HttpsError('already-exists', 'This transfer number was already submitted for an ad.');
    const now = FieldValue.serverTimestamp();
    tx.create(operationRef, { campaignId, merchantUid: uid, operationNumber, createdAt: now });
    tx.update(campaignRef, { paymentOperationNumber: operationNumber, paymentOperationDate: operationDate, paymentStatus: 'under_review', status: 'payment_under_review', paymentSubmittedAt: now, updatedAt: now });
    return { campaignId, status: 'payment_under_review' };
  });
});

exports.reviewAdCampaignPayment = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const campaignId = text(request.data?.campaignId, 1, 150, 'campaignId');
  const decision = request.data?.decision;
  const reason = typeof request.data?.reason === 'string' ? request.data.reason.trim().slice(0, 300) : '';
  if (!['confirmed', 'rejected'].includes(decision) || (decision === 'rejected' && reason.length < 3)) throw new HttpsError('invalid-argument', 'Invalid ad payment decision.');
  const ref = db.collection('ad_campaigns').doc(campaignId);
  return db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    if (!snap.exists || snap.data().status !== 'payment_under_review' || snap.data().paymentStatus !== 'under_review') throw new HttpsError('failed-precondition', 'Ad payment is not under review.');
    const now = FieldValue.serverTimestamp();
    if (decision === 'confirmed') {
      const startAt = Timestamp.now();
      const expiresAt = Timestamp.fromMillis(startAt.toMillis() + 30 * 24 * 60 * 60 * 1000);
      tx.update(ref, { status: 'active', paymentStatus: 'paid', paymentReviewedBy: request.auth.uid, paymentReviewedAt: now, startsAt: startAt, expiresAt, updatedAt: now });
    } else {
      tx.update(ref, { status: 'awaiting_payment', paymentStatus: 'rejected', paymentRejectionReason: reason, paymentReviewedBy: request.auth.uid, paymentReviewedAt: now, updatedAt: now });
    }
    tx.create(db.collection('admin_audit_logs').doc(), { adminUid: request.auth.uid, action: `ad_payment_${decision}`, campaignId, createdAt: now });
    return { campaignId, status: decision === 'confirmed' ? 'active' : 'awaiting_payment', paymentStatus: decision === 'confirmed' ? 'paid' : 'rejected' };
  });
});

exports.reviewAdCampaign = onCall({ region: REGION, maxInstances: 5 }, async request => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError('permission-denied', 'Administrator access required.');
  const campaignId = text(request.data?.campaignId, 1, 150, 'campaignId');
  const decision = request.data?.decision;
  const priceQuote = Number(request.data?.priceQuote);
  const reason = typeof request.data?.reason === 'string' ? request.data.reason.trim().slice(0, 300) : '';
  if (!['approved', 'rejected'].includes(decision)) throw new HttpsError('invalid-argument', 'Invalid campaign decision.');
  if (decision === 'approved' && (!Number.isSafeInteger(priceQuote) || priceQuote <= 0)) throw new HttpsError('invalid-argument', 'Enter a valid campaign price quote.');
  const ref = db.collection('ad_campaigns').doc(campaignId);
  return db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    if (!snap.exists || snap.data().status !== 'pending_review') throw new HttpsError('not-found', 'Pending campaign not found.');
    const now = FieldValue.serverTimestamp();
    tx.update(ref, { status: decision === 'approved' ? 'awaiting_payment' : 'rejected', priceQuote: decision === 'approved' ? priceQuote : null, rejectionReason: decision === 'rejected' ? reason : null, reviewedBy: request.auth.uid, reviewedAt: now, updatedAt: now });
    return { campaignId, status: decision === 'approved' ? 'awaiting_payment' : 'rejected' };
  });
});
