'use strict';

// Run only from a trusted administrator workstation or CI environment.
// Authentication uses Application Default Credentials; no service-account key is stored here.
const { initializeApp, applicationDefault } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');

const projectId = process.env.GCLOUD_PROJECT || process.env.GOOGLE_CLOUD_PROJECT || 'soufi-store-6e1f1';
const email = process.argv[2];
const action = process.argv[3] || (process.env.npm_lifecycle_event === 'admin:revoke' ? 'revoke' : 'grant');

if (!email || !/^\S+@\S+\.\S+$/.test(email) || !['grant', 'revoke'].includes(action)) {
  console.error('Usage: npm run admin:grant -- user@example.com');
  console.error('   or: npm run admin:revoke -- user@example.com');
  process.exit(2);
}

async function main() {
  initializeApp({ credential: applicationDefault(), projectId });
  const auth = getAuth();
  const user = await auth.getUserByEmail(email);
  const claims = { ...(user.customClaims || {}) };
  if (action === 'grant') claims.admin = true;
  else delete claims.admin;
  await auth.setCustomUserClaims(user.uid, claims);
  console.log(`${action === 'grant' ? 'Granted' : 'Revoked'} admin claim for ${email} (${user.uid}).`);
  console.log('The user must sign out and sign in again (or refresh the ID token) for the claim to take effect.');
}

main().catch(error => {
  console.error('Admin claim update failed:', error.message || error);
  process.exitCode = 1;
});
