# SOUFI STORE V3 — Phase 4 changelog

## Work continued from the latest available Phase 3 archive
- Added Arabic labels for parent-order lifecycle states in admin, customer and merchant views.
- Added search and status filters to the administration order queue (latest 30 orders).
- Added report breakdown by order state, delivered sales total, delivered-order average, cancellations, returns, failures, pending orders, commission balances, settlements and advertising/return queues.
- Added CSV export for the same bounded set of up to 300 most recent orders, with CSV quoting and UTF-8 BOM for spreadsheet compatibility.
- Added a manual report refresh action and refreshed reports after delivery assignment, shipment updates and successful delivery completion.
- Added responsive styling for order filters and report actions.

## Verification performed locally
- `node --check script.js`: passed.
- `node --check functions/index.js`: passed.
- JSON parsing for `firebase.json`, `firestore.indexes.json`, and `functions/package.json`: passed.
- ZIP integrity test: performed before delivery.

## Not performed / limitations
- No Firebase Emulator, Firestore rules compilation, live Firebase deployment, or callable integration test.
- No real browser/device test. CSV generation and UI event wiring are source-checked but not end-to-end tested.
- The reports remain bounded samples (300 orders, 500 commission records, 100 settlements, 200 campaigns and 200 return requests); not a complete accounting ledger.
- Delivery carrier integration remains manual; no carrier API is connected.
- COD collection, BaridiMob end-to-end reconciliation, payment review/collection completion, and final security/production testing remain deferred to the final stage.
- Returned stock is not automatically restored; inspection and explicit stock disposition remain necessary.
