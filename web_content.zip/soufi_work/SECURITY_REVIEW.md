> **Historical document:** This file records earlier V2/V3 implementation stages. Its stock reservation, deduction and restocking descriptions are superseded by the V4 marketplace model and V4.1 audit fixes. The current rules and workflow are documented in `V4_MARKETPLACE_ALIGNMENT.md`, `V4_1_AUDIT_FIXES.md`, `FIREBASE_SETUP.md` and `FINAL_TEST_PLAN.md`.

# SOUFI STORE V2 — Security review and implementation status

Date: 2026-11-11
Working archive: `SOUFI_STORE_V2_ORDERS.zip`
Firebase project: `soufi-store-6e1f1`

## Implemented in this working update

- Firebase Authentication email/password sign-in, customer registration, sign-out and password-reset flow are now wired to the existing Firebase compat SDK.
- Customer profiles are written to Firestore `users/{uid}` with the fixed initial role `customer`.
- Seller onboarding creates a normal customer-authenticated account and a separate `merchant_applications` document with `status: pending`. The browser cannot assign itself the seller or admin role.
- Account role/session/order/application data is not read from or written to localStorage. Firebase Auth owns the authenticated session.
- Firestore rules now validate the allowed profile fields and constrain seller-application creation to the authenticated owner. Seller applications are only readable by their owner and admins; only admins can update/delete them.
- Legacy local user/session/order/request keys are removed on startup to clear previously stored unsafe preview data.
- Cart and public catalogue preview remain local-only. This is not used as proof of identity or permission.

## Remaining limitations

- Checkout is wired to the included trusted callable function but is not live until that function is deployed to Firebase.
- Delivery company assignment, final delivery quote, order cancellation/restocking, electronic payments and payout settlement are not implemented.
- Admin provisioning/approval must use Firebase Admin SDK in a trusted environment; never grant admin/seller roles from browser code.
- Storage upload remains disabled until Storage rules, file validation and ownership checks are ready.

## Deployment and testing required

1. Enable Email/Password in Firebase Authentication.
2. Deploy `firestore.rules` to the existing Firebase project `soufi-store-6e1f1`.
3. Configure authorized domains in Firebase Authentication.
4. Test customer registration, login, logout, password reset and seller application using separate test accounts.
5. Test denied access for cross-user profile reads, seller role self-promotion, and application edits in the Firebase Emulator Suite or a non-production project.
6. Configure an admin approval backend using Admin SDK before approving any merchant.

## Production status

This update implements the first real Firebase account/onboarding workflow. It is not yet a production-ready marketplace. Do not accept real orders or payments until the remaining backend and authorization tests are complete.

## Local checks performed for this update

- `node --check script.js`: passed (JavaScript syntax).
- ZIP integrity test: passed after packaging.
- Firebase live authentication and Firestore Rules Emulator tests: not run in this environment; they require the Firebase project/emulator and must be completed before production use.


## Admin application review update
- Added an admin-only dashboard gated by the Firebase Auth custom claim `admin == true` in the ID token.
- Admins can review pending merchant applications. Approval creates a merchant record and changes the corresponding user profile role; rejection marks the application rejected. These writes are constrained by the included Firestore rules to admins.
- Admin can set a merchant commission rate between 0% and 50%. The trusted order function applies this rate at order creation; payout settlement remains unimplemented.
- The dashboard is unavailable until the custom claim is assigned through Firebase Admin SDK in a trusted environment.


## Product workflow security review
- Seller proposal creation is restricted by Firestore rules to the signed-in UID with an approved and active `merchants/{uid}` record.
- Proposal fields and numeric ranges are validated in rules; browser validation is supplemental only.
- Only the trusted admin custom claim can read all proposals and publish catalogue products.
- Sellers cannot directly write `products` or `inventory`. The included trusted order function reserves stock atomically during checkout; manual inventory adjustments remain unimplemented.
- Public catalogue reads are limited to approved and active products.


## Trusted order backend update
- Added callable Cloud Function `createMarketplaceOrder`; client-side order writes remain denied.
- Order totals, product prices, stock, merchant ownership and variable commission are calculated from Firestore by Admin SDK code.
- Stock deduction and order/suborder/commission/shipment creation occur in one Firestore transaction.
- Request IDs make repeat submissions idempotent per customer.
- Merchant order, commission and shipment reads are scoped to the owning merchant/customer/admin; writes remain denied to browser clients.
- Delivery company assignment and delivery price quotation are not yet implemented; shipment records remain awaiting platform assignment and delivery quote.
- Cash-on-delivery is recorded as unpaid; no money movement or electronic payment is implemented.
- Cloud Function deployment, billing activation, Emulator Suite security tests and live end-to-end tests remain required before production.

## Batch 4 additions and remaining controls
- Delivery assignment is performed only by the callable backend and requires the trusted `admin: true` custom claim; the browser cannot write shipment documents directly under the Firestore rules.
- Customer cancellation is server-side and restricted to `pending_confirmation`; stock restoration and child-record cancellation share one Firestore transaction.
- No post-confirmation cancellation, return, refund, delivery tracking webhook, delivery partner portal, electronic payment, or merchant payout is implemented. Those require dedicated authorization and reconciliation flows.
- Before production, test callable authorization, duplicate cancellation, stock restoration, fee allocation, and order totals in the Firebase Emulator Suite or a staging project.


## Additional hardening in this revision
- Parent orders are restricted to the customer and trusted administrators; merchants cannot read the full multi-merchant order or other merchants' line items/customer contact details.
- Browser-side writes to shipment documents are denied. Assignment/cancellation changes must pass through trusted Cloud Functions.
- Launch commission is fixed at 3% and is disclosed before a merchant submits an application.


## V3 corrections (2026-11-12)
- The launch commission is fixed at 3% in the trusted order function. Older notes in this document describing a configurable merchant rate are superseded; the browser/admin UI must not present a variable commission control.
- BaridiMob proof submission is blocked until the platform confirms delivery fee and final order total. The payment amount is synchronized to that final total.
- Admin payment review is available in the admin dashboard and must still be matched manually against actual CCP/BaridiMob account records.
- Cancelled orders cannot accept or confirm payment; cancellation marks an unpaid payment record cancelled and is blocked while payment is under review or paid.
- Uploaded proof content signatures are checked server-side against the declared MIME type.
- Firebase emulator, deployment, and real end-to-end checks remain outstanding.
