# SOUFI STORE V3 — Phase 6 changelog

## Returns inspection and VIP/PRO availability
- Added an admin-only `disposeMarketplaceReturn` callable to close a physically received return after recording a disposition for each returned product line.
- Restock decisions add only the inspected quantity back to the owning merchant product, atomically, and create an inventory log. Damaged decisions do not increase stock.
- The callable validates the order line, merchant ownership, quantity bounds, return state, and duplicate product entries; a closed return cannot be processed again.
- Added an admin inspection interface for quantities and disposition (restock or damaged), with explicit confirmation and refresh.
- SOUFI VIP remains a customer-facing “قريباً” teaser and SOUFI PRO remains a merchant-facing “قريباً” teaser. Removed active seller campaign purchase/payment controls from the seller dashboard and replaced the admin campaign controls with a coming-soon notice.

## Verification and limitations
- Local JavaScript syntax and JSON parsing checks are required before delivery.
- Firebase Emulator, live Firebase, browser/device, and security integration tests have not been run.
- This phase does not implement BaridiMob/COD payment or collection; those remain reserved for the final stage as requested.
- Carrier status and tracking updates remain manually administered; no carrier API credentials/provider were supplied.
