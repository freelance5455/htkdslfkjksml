# Phase 8 regression cases — Emulator/staging required

## Product proposal and stock controls
1. Admin approves a pending product request; exactly one product is published and the request records its product ID.
2. Two admins attempt to approve the same request concurrently; only one approval succeeds and no duplicate product is created.
3. A non-admin cannot call `reviewSellerProductRequest`.
4. A suspended/inactive merchant's pending product proposal cannot be approved.
5. Seller A cannot edit, pause, delete, or change stock for Seller B's product.
6. Invalid, fractional, negative, or excessive stock and invalid prices are rejected.

## Order lifecycle and stock
1. Order creation validates active products, merchants, stock, prices, and quantity limits; no inventory reservation/deduction occurs at order creation.
2. Assigning a delivery company confirms the fee and final order total; inactive companies and invalid fees are rejected.
3. Every merchant shipment must reach `out_for_delivery` before the parent order can be completed.
4. Delivery completion deducts stock once in one transaction; repeated completion does not deduct again.
5. Insufficient stock at delivery completion fails without partial stock writes.
6. Delivery failure requires a reason, increments attempts, and permits only the configured retry transitions.
7. Cancelled, delivered, returned, and partially returned orders cannot be changed through shipment updates.

## Returns
1. Customer can request a return only for their own delivered order.
2. Customer selects specific product lines and quantities; unknown products, duplicate product lines, zero quantities, and quantities above the ordered amount are rejected.
3. A second return case for the same order is rejected, including after a case is closed.
4. Admin approval and physical receipt are required before inspection.
5. Admin inspection must include every requested return line exactly once and the exact approved quantity.
6. `restock` increases the owning product stock once and creates one inventory log; `damaged` records the disposition without increasing stock.
7. Repeating inspection after closure fails and cannot restock again.
8. Partial returns set parent/affected merchant orders to `partially_returned`; complete returns set them to `returned`.
9. Non-admin users cannot review/inspect returns or write return/inventory records directly.

## Admin dashboard and reports
1. Admin order list pages forward/backward through all orders without duplicates or omissions when `createdAt` values tie.
2. Status and text filters apply to the currently visible page.
3. CSV export fetches every order page in batches and emits UTF-8 CSV with the expected columns.
4. Operational report sample clearly identifies its sample limits; financial settlement actions are not available in this phase.

## Deferred boundaries
1. BaridiMob review, COD collection, and merchant settlement actions are not exposed in the active admin/seller interfaces.
2. VIP remains customer-facing “قريباً”; PRO remains merchant-facing “قريباً”; no campaign purchase controls are active.
3. No new shipment-tracking feature or carrier API integration is included in this phase.
