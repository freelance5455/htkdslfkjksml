/*
 * SOUFI STORE - Firebase Web configuration
 * Public Web App configuration for project soufi-store-6e1f1.
 * Never place service-account private keys or admin credentials here.
 * Firebase Storage is initialized for restricted BaridiMob proof uploads.
 */
window.SOUFI_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDpweeXKvu1o7hNNDieyjMK_lHMguSS4pY",
  authDomain: "soufi-store-6e1f1.firebaseapp.com",
  projectId: "soufi-store-6e1f1",
  storageBucket: "soufi-store-6e1f1.firebasestorage.app",
  messagingSenderId: "207346130411",
  appId: "1:207346130411:web:cc6ec199dd245090c10dae",
  measurementId: "G-LDT5CTYCQL"
};
