/*
 * ChatApp v6.1 — complete & tested
 * Auth: Firebase Email/Password · Database: RTDB only · WebView friendly
 */
'use strict';

const firebaseConfig = {
  apiKey: 'AIzaSyD6A_BZ7cg8jm4HePzZ0t-74x6ddIlAYA4',
  authDomain: 'chat-otaku-aed68.firebaseapp.com',
  databaseURL: 'https://chat-otaku-aed68-default-rtdb.firebaseio.com',
  projectId: 'chat-otaku-aed68',
  messagingSenderId: '272172230702',
  appId: '1:272172230702:android:d0ea32284d1960a31117bf'
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();
const SERVER = firebase.database.ServerValue.TIMESTAMP;

const APP_VERSION = '6.1';
const STORY_DURATION = 24 * 60 * 60 * 1000;
const STORY_VIEW_MS = 6000;
const MAX_TEXT = 4000;
const MAX_FILE_BYTES = 2 * 1024 * 1024;
const MAX_DATA_URL_LENGTH = 2800000;
const USERNAME_RE = /^[a-z0-9_]{3,20}$/;
const ROLES = ['user', 'moderator', 'admin', 'owner'];
const STORE_VERSION = 11;
const MOBILE_BP = 768;
const REQUEST_RETRY_MS = 7 * 24 * 60 * 60 * 1000;

/* ==================== Utilities ==================== */
const $ = id => document.getElementById(id);
const qs = sel => document.querySelector(sel);
const qsa = sel => [...document.querySelectorAll(sel)];
const esc = s => String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const escapeHtmlLine = text => esc(text).replace(/\n/g, '<br>');

const resizeMessageInput = () => {
  const el = $('message-input');
  if (!el) return;
  if (el.tagName === 'TEXTAREA') {
    el.style.height = 'auto';
    el.style.height = Math.min(140, Math.max(46, el.scrollHeight)) + 'px';
    el.style.overflowY = el.scrollHeight > 140 ? 'auto' : 'hidden';
  }
};

const normalizeUsername = value => String(value || '').trim().toLowerCase().replace(/^@/, '');
const uid = () => auth.currentUser?.uid || null;
const now = () => Date.now();

const bytes = n =>
  n < 1024 ? `${n} B`
  : n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB`
  : `${(n / 1024 / 1024).toFixed(2)} MB`;

const relativeTime = ts => {
  const d = Math.max(0, now() - Number(ts || 0));
  const m = Math.floor(d / 60000);
  const h = Math.floor(m / 60);
  const dd = Math.floor(h / 24);
  return dd ? `${dd} ي` : h ? `${h} س` : m ? `${m} د` : 'الآن';
};

const dayTime = ts => ts
  ? new Date(ts).toLocaleString('ar', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
  : '-';

const isMobile = () => window.innerWidth <= MOBILE_BP;

const safeDataUrl = u => {
  const v = String(u || '');
  return /^data:[a-z0-9.+-]+\/[a-z0-9.+-]+(;[a-z0-9=.+_-]+)*;base64,/i.test(v) ? v : '';
};
const safeImageUrl = u => {
  const v = safeDataUrl(u);
  return /^data:image\//i.test(v) ? v : '';
};
const fileUrl = data => safeDataUrl(data?.dataUrl);

const isOwner = () => !!S.me?.id && S.me.id === S.ownerUid;
const isAdmin = () => isOwner() || S.me?.role === 'admin';
const isStaff = () => isAdmin() || S.me?.role === 'moderator';
const isPrivilegedTarget = id =>
  id === S.ownerUid
  || S.profileCache.get(id)?.role === 'admin'
  || S.userCache.get(id)?.role === 'admin';

const badgeSvg = (kind, size = 'md') => {
  const cls = `badge-svg badge-${kind} badge-${size}`;
  const defs = {
    verified: '<linearGradient id="g"><stop stop-color="#4DA8FF"/><stop offset=".55" stop-color="#1E88E5"/><stop offset="1" stop-color="#0D47A1"/></linearGradient>',
    owner: '<linearGradient id="g" x2="0" y2="1"><stop stop-color="#FFF1B8"/><stop offset=".35" stop-color="#FFD54F"/><stop offset=".7" stop-color="#FFB300"/><stop offset="1" stop-color="#B45309"/></linearGradient>',
    admin: '<linearGradient id="g" x2="0" y2="1"><stop stop-color="#93C5FD"/><stop offset=".5" stop-color="#3B82F6"/><stop offset="1" stop-color="#1E3A8A"/></linearGradient>',
    moderator: '<linearGradient id="g" x2="1" y2="1"><stop stop-color="#6EE7B7"/><stop offset=".5" stop-color="#10B981"/><stop offset="1" stop-color="#047857"/></linearGradient>',
    premium: '<linearGradient id="g"><stop stop-color="#E9D5FF"/><stop offset="1" stop-color="#C084FC"/></linearGradient>',
    bot: '<linearGradient id="g" x2="0" y2="1"><stop stop-color="#B0BEC5"/><stop offset="1" stop-color="#455A64"/></linearGradient>',
    new: '<linearGradient id="g" x2="0" y2="1"><stop stop-color="#BBF7D0"/><stop offset=".5" stop-color="#22C55E"/><stop offset="1" stop-color="#15803D"/></linearGradient>'
  };
  const body = {
    verified: '<path d="M12 1.8l2.1 1.1 2.3-.2 1.1 2.1 2.1 1.1-.2 2.3 1.1 2.1-1.1 2.1.2 2.3-2.1 1.1-1.1 2.1-2.3-.2-2.1 1.1-2.1-1.1-2.3.2-1.1-2.1-2.1-1.1.2-2.3-1.1-2.1 1.1-2.1-.2-2.3 2.1-1.1 1.1-2.1 2.3.2z" fill="url(#g)"/><path d="M8 12.1l2.5 2.5 5.5-5.6" fill="none" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
    owner: '<path d="M2.5 8.5l3.5 3 3.5-5 2.5 3.5 2.5-3.5 3.5 5 3.5-3-1.7 10H4.2L2.5 8.5z" fill="url(#g)"/><rect x="4.2" y="19" width="15.6" height="2.2" rx=".7" fill="#92400E"/><circle cx="12" cy="6" r="1.4" fill="#FFF8DC"/><circle cx="6" cy="8.8" r="1" fill="#FFF8DC"/><circle cx="18" cy="8.8" r="1" fill="#FFF8DC"/>',
    admin: '<path d="M12 1L2.8 5v6.8c0 5.9 3.9 11.2 9.2 12.7 5.3-1.5 9.2-6.8 9.2-12.7V5L12 1z" fill="url(#g)"/><rect x="9.4" y="11.5" width="5.2" height="4.6" rx=".6" fill="#fff"/><path d="M10.4 11.5V10a1.6 1.6 0 013.2 0v1.5" fill="none" stroke="#fff" stroke-width="1.3"/>',
    moderator: '<path d="M10.3 3.2a1.7 1.7 0 013.4 0v.6h3.5a1 1 0 011 1v3.5h.6a1.7 1.7 0 010 3.4h-.6v3.5a1 1 0 01-1 1h-3.5v.6a1.7 1.7 0 01-3.4 0v-.6H6.8a1 1 0 01-1-1v-3.5h-.6a1.7 1.7 0 010-3.4h.6V4.8a1 1 0 011-1h3.5z" fill="url(#g)"/><path d="M9.3 12.4l1.9 1.9 3.5-3.6" fill="none" stroke="#fff" stroke-width="1.4" stroke-linecap="round"/>',
    premium: '<path d="M12 2L5 5l-3 4 10 13L22 9l-3-4-7-3z" fill="url(#g)"/><path d="M2 9h20L12 22 2 9z" fill="#6D28D9" opacity=".65"/><path d="M5 5h14M2 9h20M7 5l5 17M17 5l-5 17" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width=".5"/>',
    bot: '<circle cx="12" cy="2.5" r="1" fill="#FF5252"/><rect x="11.6" y="3.5" width=".8" height="2.5" fill="#78909c"/><rect x="4" y="6" width="16" height="13" rx="3" fill="url(#g)"/><rect x="6" y="8" width="12" height="8" rx="1.5" fill="#0f172a"/><circle cx="9.5" cy="12" r="1.3" fill="#4ade80"/><circle cx="14.5" cy="12" r="1.3" fill="#4ade80"/>',
    new: '<path d="M12 2l2.9 6.2 6.6.7-4.9 4.5 1.4 6.6L12 16.7 6 20l1.4-6.6L2.5 8.9l6.6-.7L12 2z" fill="url(#g)"/>'
  };
  return `<svg viewBox="0 0 24 24" class="${cls}" aria-label="${kind}"><defs>${defs[kind]}</defs>${body[kind]}</svg>`;
};

function userBadgesHtml(id, size = 'md') {
  const p = S.profileCache.get(id) || {};
  const u = S.userCache.get(id) || {};
  const role = id === S.ownerUid ? 'owner' : (u.role || p.role || '');
  if (role === 'owner' || id === S.ownerUid) return `<span class="badge-row">${badgeSvg('owner', size)}</span>`;
  const out = [];
  if (role === 'admin') out.push(badgeSvg('admin', size));
  else if (role === 'moderator') out.push(badgeSvg('moderator', size));
  if (p.verifyBadge === 'premium') out.push(badgeSvg('premium', size));
  if (p.verified && !['admin', 'moderator'].includes(role)) out.push(badgeSvg('verified', size));
  if (p.verifyBadge === 'bot') out.push(badgeSvg('bot', size));
  if (p.createdAt && now() - Number(p.createdAt) < 7 * 86400000 && !p.verified) out.push(badgeSvg('new', size));
  return out.length ? `<span class="badge-row">${out.join('')}</span>` : '';
}

const canManageUser = target => {
  if (!target?.id || target.id === S.ownerUid || target.id === S.me?.id) return false;
  if (isOwner()) return true;
  if (S.me?.role === 'admin') return ['user', 'moderator'].includes(target.role);
  if (S.me?.role === 'moderator') return target.role === 'user';
  return false;
};

/* ==================== State ==================== */
const S = {
  initializedForUid: null,
  activeUid: null,
  me: null,
  ownerUid: null,
  ownerProfile: null,
  appConfig: null,
  userCache: new Map(),
  profileCache: new Map(),
  presenceCache: new Map(),
  chatCache: new Map(),
  stories: [],
  storyGroups: [],
  storyRaw: {},
  storyExpiryTimer: null,
  storyGroup: null,
  storyUserList: [],
  contacts: new Set(),
  blocked: new Set(),
  activeChatId: null,
  activeChat: null,
  messageCache: new Map(),
  messageUnsubs: [],
  realtimeUnsubs: [],
  connectionRef: null,
  typingRef: null,
  typingTimer: null,
  currentReply: null,
  currentEdit: null,
  contextMessageId: null,
  storyIndex: 0,
  storyItemIndex: 0,
  storyTimer: null,
  storyProgressTimer: null,
  storyProgressStart: 0,
  storyPaused: false,
  storyDraft: null,
  pendingStoryReply: null,
  pinBuffer: '',
  pinHash: null,
  selectedGroupUsers: new Set(),
  localTheme: localStorage.getItem('chatapp_theme') || 'dark',
  localWallpaper: localStorage.getItem('chatapp_wallpaper') || 'default',
  lastNotifications: new Set(),
  adminTab: 'dashboard',
  adminUsers: [],
  adminUsersUnsub: null,
  adminSearch: '',
  adminUserFilter: 'all',
  adminLogFilter: 'all',
  pendingPrompt: null,
  voiceRecorder: null,
  voiceChunks: [],
  voiceStartedAt: 0,
  voiceTimer: null,
  typingInputBound: false,
  chatPresenceUnsub: null,
  chatTypingUnsub: null,
  deviceId: localStorage.getItem('chatapp_device_id') || globalThis.crypto?.randomUUID?.() || `dev-${Date.now()}-${Math.random().toString(16).slice(2)}`,
  registrationInProgress: false,
  sessionInitInProgress: false,
  pendingAuthError: null,
  pendingAttachment: null,
  sending: false,
  chatIndex: null,
  chatListeners: new Map(),
  chatRequests: {},
  storyAudience: { followers: new Set(), following: new Set() },
  chatRenderSeq: 0,
  chatRenderTimer: null,
  chatTab: 'all',
  chatQuery: '',
  voiceCanceled: false,
  voiceAutoSend: false,
  monitorMode: false,
  openingChat: null,
  profileFetchedAt: null,
  currentInviteCode: null,
  pendingQuickReply: null,
};
localStorage.setItem('chatapp_device_id', S.deviceId);

window.$ = $;
window.hide = el => el?.classList.add('hidden');
window.show = el => el?.classList.remove('hidden');
window.APP_VERSION = APP_VERSION;

/* ==================== In-app Prompt / Confirm ==================== */
function promptAsync(message, defaultValue = '', title = 'إدخال') {
  return new Promise(resolve => {
    const modal = $('prompt-modal');
    const input = $('prompt-input');
    const group = $('prompt-input-group');
    const ok = $('prompt-ok');
    const cancel = $('prompt-cancel');
    $('prompt-title').textContent = title;
    $('prompt-message').textContent = message;
    input.value = defaultValue;
    group.classList.remove('hidden');
    modal.classList.remove('hidden');
    setTimeout(() => { input.focus(); input.select(); }, 50);

    const cleanup = () => {
      modal.classList.add('hidden');
      ok.removeEventListener('click', onOk);
      cancel.removeEventListener('click', onCancel);
      input.removeEventListener('keydown', onKey);
    };
    const onOk = () => { const v = input.value; cleanup(); resolve(v); };
    const onCancel = () => { cleanup(); resolve(null); };
    const onKey = e => {
      if (e.key === 'Enter') { e.preventDefault(); onOk(); }
      else if (e.key === 'Escape') { onCancel(); }
    };
    ok.addEventListener('click', onOk);
    cancel.addEventListener('click', onCancel);
    input.addEventListener('keydown', onKey);
  });
}

function confirmAsync(message, title = 'تأكيد', okLabel = 'موافق', danger = false) {
  return new Promise(resolve => {
    const modal = $('prompt-modal');
    const input = $('prompt-input');
    const group = $('prompt-input-group');
    const ok = $('prompt-ok');
    const cancel = $('prompt-cancel');
    $('prompt-title').textContent = title;
    $('prompt-message').textContent = message;
    group.classList.add('hidden');
    ok.textContent = okLabel;
    ok.className = danger ? 'btn-danger' : 'btn-primary';
    ok.style.flex = '1';
    cancel.style.flex = '1';
    modal.classList.remove('hidden');

    const cleanup = () => {
      modal.classList.add('hidden');
      ok.removeEventListener('click', onOk);
      cancel.removeEventListener('click', onCancel);
      ok.textContent = 'موافق';
      ok.className = 'btn-primary';
    };
    const onOk = () => { cleanup(); resolve(true); };
    const onCancel = () => { cleanup(); resolve(false); };
    ok.addEventListener('click', onOk);
    cancel.addEventListener('click', onCancel);
  });
}

/* ==================== Toast ==================== */
function toast(message, type = 'info', ms = 3200) {
  const host = $('toast-container');
  if (!host) return;
  const n = document.createElement('div');
  n.className = `notif ${type}`;
  n.innerHTML = `<b>${type === 'error' ? '⚠️' : type === 'success' ? '✅' : 'ℹ️'}</b><p>${esc(message)}</p>`;
  host.appendChild(n);
  setTimeout(() => n.remove(), ms);
}

/* ==================== Auth Error ==================== */
function setAuthError(message) {
  const el = $('auth-error');
  if (!el) return;
  el.textContent = message || '';
  el.classList.toggle('hidden', !message);
  const retry = $('auth-retry');
  if (retry) {
    const showRetry = !!message && !!auth.currentUser && /تعذر|رفضت/.test(message);
    retry.classList.toggle('hidden', !showRetry);
  }
}

function firebaseErrorMessage(err) {
  const code = err?.code || '';
  const map = {
    'auth/email-already-in-use': 'اسم المستخدم مستخدم بالفعل.',
    'auth/invalid-email': 'اسم المستخدم غير صالح.',
    'auth/weak-password': 'كلمة المرور ضعيفة. استخدم 6 أحرف أو أكثر.',
    'auth/user-not-found': 'الحساب غير موجود.',
    'auth/wrong-password': 'بيانات الدخول غير صحيحة.',
    'auth/invalid-credential': 'اسم المستخدم أو كلمة المرور غير صحيحة.',
    'auth/too-many-requests': 'محاولات كثيرة. حاول لاحقاً.',
    'auth/network-request-failed': 'تعذر الاتصال بخدمة Firebase.',
    'auth/requires-recent-login': 'أعد تسجيل الدخول ثم أعد العملية.',
    'auth/operation-not-allowed': 'فعّل تسجيل الدخول بالبريد الإلكتروني وكلمة المرور من Firebase Authentication.',
    'auth/invalid-password': 'كلمة المرور غير صحيحة.',
    'auth/user-disabled': 'هذا الحساب معطل.'
  };
  return map[code] || err?.message || 'حدث خطأ غير متوقع.';
}

function accountEmail(username) {
  return `${normalizeUsername(username)}@accounts.chatapp.local`;
}

async function sha256(text) {
  if (!globalThis.crypto?.subtle) return text;
  const data = new TextEncoder().encode(text);
  const hash = await globalThis.crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(hash)].map(x => x.toString(16).padStart(2, '0')).join('');
}

/* ==================== View helpers ==================== */
function openView(id) {
  qsa('.modal').forEach(m => m.classList.add('hidden'));
  $(id)?.classList.remove('hidden');
}
function closeModals() {
  qsa('.modal').forEach(m => m.classList.add('hidden'));
}

/* ==================== Preferences ==================== */
function applyLocalPreferences() {
  document.documentElement.dataset.theme = S.localTheme;
  document.documentElement.dataset.wallpaper = S.localWallpaper;
  $('messages-container')?.setAttribute('data-wallpaper', S.localWallpaper);
  const pinOpt = $('opt-pin');
  if (pinOpt) pinOpt.checked = !!localStorage.getItem('chatapp_pin_hash');
  qsa('.theme-option').forEach(b => b.classList.toggle('active', b.dataset.theme === S.localTheme));
  qsa('[data-wp]').forEach(b => b.classList.toggle('active', b.dataset.wp === S.localWallpaper));
}

async function setLocalPin(pin) {
  if (!/^\d{4}$/.test(pin)) throw new Error('الـPIN يجب أن يكون 4 أرقام.');
  localStorage.setItem('chatapp_pin_hash', await sha256(pin));
  S.pinHash = localStorage.getItem('chatapp_pin_hash');
}
function clearLocalPin() {
  localStorage.removeItem('chatapp_pin_hash');
  S.pinHash = null;
}
function needsPin() {
  return !!localStorage.getItem('chatapp_pin_hash');
}
function showPinLock() {
  if (!needsPin()) return false;
  S.pinBuffer = '';
  const el = $('pin-error');
  if (el) { el.textContent = ''; el.classList.add('hidden'); }
  $('auth-screen')?.classList.add('hidden');
  $('pin-screen')?.classList.remove('hidden');
  renderPinDots();
  return true;
}
function renderPinDots() {
  const dots = $('pin-dots');
  if (dots) dots.textContent = '●'.repeat(S.pinBuffer.length) + '○'.repeat(4 - S.pinBuffer.length);
}
async function verifyPin() {
  if (await sha256(S.pinBuffer) !== localStorage.getItem('chatapp_pin_hash')) {
    const el = $('pin-error');
    if (el) { el.textContent = 'الـPIN غير صحيح.'; el.classList.remove('hidden'); }
    S.pinBuffer = '';
    renderPinDots();
    return;
  }
  $('pin-screen')?.classList.add('hidden');
  if (S.me) enterApp();
  else $('auth-screen')?.classList.remove('hidden');
}

/* ==================== Tabs ==================== */
function setAuthTab(tab) {
  qsa('.auth-tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  $('register-form')?.classList.toggle('hidden', tab !== 'register');
  $('login-form')?.classList.toggle('hidden', tab !== 'login');
  setAuthError('');
}

/* ==================== Config ==================== */
async function loadConfig(options = {}) {
  const strict = options.strict === true;
  let appSnap = null, ownerSnap = null;
  try {
    appSnap = await db.ref('config/app').once('value');
    if (auth.currentUser) ownerSnap = await db.ref('config/ownerUid').once('value');
  } catch (e) {
    if (strict) throw e;
    appSnap = null;
    ownerSnap = null;
  }
  S.appConfig = appSnap?.val() || { appName: 'ChatApp', maxAccountsPerDevice: 3, allowRegistration: true, schemaVersion: STORE_VERSION };
  S.ownerUid = ownerSnap?.val() || null;
  const an = $('about-app-name');
  if (an) an.textContent = S.appConfig.appName || 'ChatApp';
  const am = $('about-max-accounts');
  if (am) am.textContent = S.appConfig.maxAccountsPerDevice ?? 3;
  const ad = $('about-device-lock');
  if (ad) ad.textContent = 'مراقبة الجهاز فقط (وليست قيداً أمنياً)';
  $('reg-username')?.setAttribute('maxlength', '20');
  $('reg-password')?.setAttribute('minlength', '6');
}

/* ==================== Owner bootstrap ==================== */
async function bootstrapOwnerIfNeeded() {
  if (!S.me || S.me.username !== 'data') return;
  const ownerSnap = await db.ref('config/ownerUid').once('value');
  if (ownerSnap?.exists()) { S.ownerUid = ownerSnap.val(); return; }
  try {
    await db.ref('config/ownerUid').set(S.me.id);
    await db.ref(`users/${S.me.id}/role`).set('owner');
    await db.ref(`profiles/${S.me.id}`).update({ verified: true, role: 'owner' });
    S.ownerUid = S.me.id;
    try {
      const cfg = await db.ref('config/app').once('value');
      if (!cfg.exists()) await db.ref('config/app').set({ appName: 'ChatApp', maxAccountsPerDevice: 3, allowRegistration: true, schemaVersion: STORE_VERSION });
    } catch {}
    S.me.role = 'owner';
  } catch (e) {
    e.registrationOwnerBootstrap = true;
    throw e;
  }
}

/* ==================== Load current account ==================== */
async function loadCurrentAccount(retries = 3) {
  if (!uid()) return false;
  let uSnap, pSnap;
  try {
    uSnap = await db.ref(`users/${uid()}`).once('value');
    if (!uSnap?.exists()) {
      if (retries > 0) {
        await new Promise(r => setTimeout(r, 300));
        return loadCurrentAccount(retries - 1);
      }
      return false;
    }
    pSnap = await db.ref(`profiles/${uid()}`).once('value');
  } catch (e) {
    throw e;
  }
  const p = pSnap?.val() || {};
  const u = uSnap.val() || {};
  S.me = { ...u, id: uid(), bio: p.bio || '', avatar: p.avatar || '', verified: !!p.verified };
  S.userCache.set(uid(), S.me);
  S.contacts = new Set(Object.keys(u.contacts || {}));
  S.blocked = new Set(Object.keys(u.blocked || {}));
  try {
    const viewedSnap = await db.ref(`storyViewedByUser/${uid()}`).once('value');
    S.me.storyViewed = viewedSnap?.val() || {};
  } catch { S.me.storyViewed = {}; }
  return true;
}

/* ==================== Cleanup incomplete registration ==================== */
async function cleanupIncompleteRegistration(newUid, username) {
  if (!newUid) return;
  const paths = [`profiles/${newUid}`, `presence/${newUid}`, `devices/${S.deviceId}/users/${newUid}`];
  if (USERNAME_RE.test(username || '')) {
    try {
      const indexSnap = await db.ref(`usernames/${username}`).once('value');
      if (indexSnap.exists() && indexSnap.val() === newUid) paths.push(`usernames/${username}`);
    } catch {}
  }
  paths.push(`users/${newUid}`);
  for (const path of paths) {
    try { await db.ref(path).remove(); } catch {}
  }
  if (auth.currentUser?.uid === newUid) {
    try { await auth.currentUser.delete(); } catch {}
  }
}

/* ==================== Registration ==================== */
async function registrationStep(label, fn) {
  setAuthError(`جاري إنشاء الحساب — ${label}`);
  try { return await fn(); }
  catch (e) { e.registrationStep = label; throw e; }
}

async function registerAccount(ev) {
  ev.preventDefault();
  setAuthError('');
  if (S.registrationInProgress) return;
  const username = normalizeUsername($('reg-username')?.value);
  const password = $('reg-password')?.value || '';
  const confirm = $('reg-confirm')?.value || '';
  if (!USERNAME_RE.test(username)) return setAuthError('اسم المستخدم: 3–20 حرفاً، إنجليزي صغير/أرقام/_ فقط.');
  if (password.length < 6) return setAuthError('كلمة المرور يجب أن تكون 6 أحرف على الأقل.');
  if (password !== confirm) return setAuthError('تأكيد كلمة المرور غير مطابق.');
  try { await loadConfig({ strict: true }); }
  catch (e) { return setAuthError(`تعذر الوصول إلى إعدادات Firebase: ${firebaseErrorMessage(e)}`); }
  if (S.appConfig?.allowRegistration === false) return setAuthError('التسجيلات الجديدة مغلقة حالياً من الإدارة.');

  const btn = $('register-form')?.querySelector('button[type="submit"]');
  if (btn) btn.disabled = true;
  let newUid = null;
  let registrationCommitted = false;
  S.registrationInProgress = true;
  try {
    const cred = await registrationStep('إنشاء حساب Firebase', () => auth.createUserWithEmailAndPassword(accountEmail(username), password));
    newUid = cred.user.uid;
    const base = Date.now();
    const userRecord = {
      id: newUid, username, role: 'user', status: 'active', coins: 0, deviceId: S.deviceId,
      createdAt: base, lastSeen: base, showOnline: true, showLastSeen: true,
      registrationComplete: false,
      contacts: {}, blocked: {},
      settings: { notifications: true, sounds: true, readReceipts: true, showLastSeen: true, showOnline: true }
    };
    const profile = { username, displayName: '', bio: '', avatar: '', cover: '', role: 'user', verified: false, active: true, createdAt: base };
    const presence = { online: true, lastSeen: base, showOnline: true, showLastSeen: true };

    await registrationStep('حفظ ملف الحساب', () => db.ref(`users/${newUid}`).set(userRecord));
    await registrationStep('حجز اسم المستخدم', async () => {
      const existing = await db.ref(`usernames/${username}`).once('value');
      if (existing.exists() && existing.val() !== newUid) {
        const err = new Error('اسم المستخدم مستخدم بالفعل.');
        err.code = 'APP_USERNAME_TAKEN';
        throw err;
      }
      await db.ref(`usernames/${username}`).set(newUid);
    });
    await registrationStep('إنشاء الملف العام', () => db.ref(`profiles/${newUid}`).set(profile));
    await registrationStep('إنشاء حالة الاتصال', () => db.ref(`presence/${newUid}`).set(presence));
    await registrationStep('ربط الحساب بالجهاز', () => db.ref(`devices/${S.deviceId}/users/${newUid}`).set(true));
    await registrationStep('تحميل الحساب قبل الإكمال', async () => {
      const ok = await loadCurrentAccount();
      if (!ok) throw new Error('تم إنشاء البيانات الأساسية لكن تعذر قراءتها.');
    });
    await registrationStep('تهيئة النظام', () => loadConfig({ strict: true }));
    await registrationStep('تهيئة المالك عند الحاجة', bootstrapOwnerIfNeeded);
    await registrationStep('تأكيد اكتمال التسجيل', () => db.ref(`users/${newUid}/registrationComplete`).set(true));
    registrationCommitted = true;
    await registrationStep('التحقق النهائي من الحساب', async () => {
      const ok = await loadCurrentAccount();
      if (!ok || !S.me || S.me.registrationComplete !== true) throw new Error('تم إنشاء الحساب لكن ملفه لم يكتمل.');
    });

    const initialized = await initializeAuthenticatedUser(cred.user, { allowDuringRegistration: true });
    S.registrationInProgress = false;
    if (!initialized) setAuthError('تم إنشاء الحساب، لكن تعذر فتحه تلقائياً. انتقل إلى تسجيل الدخول واستخدم نفس بيانات الحساب.');
    else toast('تم إنشاء الحساب بنجاح.', 'success');
  } catch (e) {
    if (newUid && !registrationCommitted) await cleanupIncompleteRegistration(newUid, username);
    S.registrationInProgress = false;
    S.initializedForUid = null;
    S.activeUid = null;
    S.me = null;
    const permission = e?.code === 'PERMISSION_DENIED' || e?.code === 'database/permission-denied';
    const message = e?.code === 'APP_USERNAME_TAKEN'
      ? 'اسم المستخدم مستخدم بالفعل.'
      : permission
        ? `رفضت قاعدة البيانات خطوة «${e?.registrationStep || 'غير محددة'}». انشر database.rules.json من هذه النسخة.`
        : (e?.registrationStep ? `فشلت مرحلة «${e.registrationStep}»: ${firebaseErrorMessage(e)}` : firebaseErrorMessage(e));
    S.pendingAuthError = message;
    setAuthError(message);
    await auth.signOut().catch(() => {});
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function loginAccount(ev) {
  ev.preventDefault();
  setAuthError('');
  const username = normalizeUsername($('login-username')?.value);
  const password = $('login-password')?.value || '';
  if (!USERNAME_RE.test(username)) return setAuthError('اسم المستخدم غير صالح.');
  const btn = $('login-form')?.querySelector('button[type="submit"]');
  if (btn) btn.disabled = true;
  try {
    await auth.signInWithEmailAndPassword(accountEmail(username), password);
  } catch (e) {
    setAuthError(firebaseErrorMessage(e));
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function logout() {
  S.pendingAuthError = null;
  stopMyTyping();
  if (uid()) {
    try {
      await db.ref(`presence/${uid()}`).set({
        online: false,
        lastSeen: SERVER,
        showOnline: S.me?.showOnline !== false,
        showLastSeen: S.me?.showLastSeen !== false
      });
    } catch {}
  }
  detachRealtime();
  S.initializedForUid = null;
  S.activeUid = null;
  S.activeChatId = null;
  S.activeChat = null;
  S.me = null;
  S.sessionInitInProgress = false;
  S.registrationInProgress = false;
  S.messageCache.clear();
  S.chatRequests = {};
  S.chatCache.clear();
  await auth.signOut().catch(() => {});
  closeModals();
  closeAdminPanel();
  $('sidebar')?.classList.remove('open');
  $('app-screen')?.classList.add('hidden');
  $('pin-screen')?.classList.add('hidden');
  $('auth-screen')?.classList.remove('hidden');
  setAuthTab('login');
}

async function changePassword() {
  const oldPass = $('old-pass')?.value || '';
  const newPass = $('new-pass')?.value || '';
  if (newPass.length < 6) return toast('كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل.', 'error');
  if (!auth.currentUser || !S.me) return;
  try {
    const credential = firebase.auth.EmailAuthProvider.credential(auth.currentUser.email, oldPass);
    await auth.currentUser.reauthenticateWithCredential(credential);
    await auth.currentUser.updatePassword(newPass);
    $('old-pass').value = '';
    $('new-pass').value = '';
    toast('تم تغيير كلمة المرور.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function saveProfile() {
  if (!S.me) return;
  const bio = ($('profile-bio')?.value || '').trim().slice(0, 100);
  const displayName = ($('profile-displayName')?.value || '').trim().slice(0, 40);
  const cover = String(S.me.cover || '');
  const username = normalizeUsername($('profile-username')?.value || S.me.username);
  if (!USERNAME_RE.test(username)) return toast('اسم المستخدم غير صالح.', 'error');
  try {
    if (username !== S.me.username) {
      const us = await db.ref(`usernames/${username}`).once('value');
      if (us.exists() && us.val() !== S.me.id) return toast('اسم المستخدم مستخدم بالفعل.', 'error');
      const last = Number(S.me.usernameChangedAt || 0);
      if (last && now() - last < 2592000000) return toast('يمكن تغيير اسم المستخدم مرة كل 30 يوماً.', 'error');
      await db.ref(`usernames/${S.me.username}`).remove();
      await db.ref(`usernames/${username}`).set(S.me.id);
      await db.ref(`users/${S.me.id}/username`).set(username);
      await db.ref(`users/${S.me.id}/usernameChangedAt`).set(SERVER);
      await db.ref(`profiles/${S.me.id}/username`).set(username);
    }
    await db.ref(`profiles/${S.me.id}`).update({ bio, displayName, cover });
    S.me = { ...S.me, username, bio, displayName, cover, usernameChangedAt: username !== S.me.username ? now() : S.me.usernameChangedAt };
    S.profileCache.set(S.me.id, { ...S.profileCache.get(S.me.id), ...S.me });
    toast('تم حفظ الملف الشخصي.', 'success');
    renderOwnIdentity();
    renderProfileModal();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function changeAvatar(file) {
  if (!file || !S.me) return;
  if (!file.type.startsWith('image/')) return toast('اختر صورة فقط.', 'error');
  try {
    const dataUrl = await compressImage(file, 256, 0.82);
    if (dataUrl.length > MAX_FILE_BYTES * 1.37) throw new Error('الصورة كبيرة جداً.');
    await db.ref(`profiles/${S.me.id}/avatar`).set(dataUrl);
    S.me.avatar = dataUrl;
    renderOwnIdentity();
    renderProfileModal();
    toast('تم تحديث الصورة.', 'success');
  } catch (e) {
    toast(e.message || 'تعذر حفظ الصورة.', 'error');
  }
}

async function changeCover(file) {
  if (!file || !S.me) return;
  if (!file.type.startsWith('image/')) return toast('اختر صورة فقط.', 'error');
  try {
    const data = await compressImage(file, 800, .75);
    if (data.length > 2800000) return toast('الغلاف كبير جداً.', 'error');
    await db.ref(`profiles/${S.me.id}/cover`).set(data);
    S.me.cover = data;
    renderProfileModal();
    toast('تم تحديث الغلاف.', 'success');
  } catch (e) {
    toast('تعذر حفظ الغلاف.', 'error');
  }
}

function compressImage(file, maxSide = 1280, quality = .8) {
  return new Promise((resolve, reject) => {
    const img = new Image(), fr = new FileReader();
    fr.onload = () => { img.src = fr.result; };
    fr.onerror = reject;
    img.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(img.width * scale));
      c.height = Math.max(1, Math.round(img.height * scale));
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => reject(new Error('تعذر قراءة الصورة.'));
    fr.readAsDataURL(file);
  });
}

/* ==================== Identity render ==================== */
function renderOwnIdentity() {
  if (!S.me) return;
  const avatar = S.me.avatar ? `<img src="${esc(safeImageUrl(S.me.avatar))}" alt="">` : '👤';
  ['my-avatar', 'menu-avatar'].forEach(id => {
    const el = $(id);
    if (el) el.innerHTML = avatar;
  });
  const myName = $('my-username');
  if (myName) myName.textContent = '@' + S.me.username;
  const menuName = $('menu-username');
  if (menuName) menuName.textContent = '@' + S.me.username;
  const myStatus = $('my-status');
  if (myStatus) {
    myStatus.textContent = S.me.status === 'active' ? 'متصل' : S.me.status;
    myStatus.style.color = S.me.status === 'active' ? 'var(--accent)' : 'var(--danger)';
  }
  const dev = $('menu-userdevice');
  if (dev) dev.textContent = `الجهاز: ${S.deviceId.slice(0, 12)}…`;
  $('menu-admin')?.classList.toggle('hidden', !isStaff());
  renderOwnerContactCard();
}

async function loadOwnerProfile() {
  if (!S.ownerUid || S.ownerUid === uid()) {
    S.ownerProfile = S.me ? { ...S.me, id: uid() } : null;
    renderOwnerContactCard();
    return;
  }
  const snap = await db.ref(`profiles/${S.ownerUid}`).once('value').catch(() => null);
  if (snap?.exists()) {
    S.ownerProfile = { ...snap.val(), id: S.ownerUid };
    S.profileCache.set(S.ownerUid, S.ownerProfile);
  }
  renderOwnerContactCard();
}

function renderOwnerContactCard() {
  const host = $('owner-contact-card');
  if (!host) return;
  const p = S.ownerProfile;
  if (!p) {
    host.innerHTML = '<div class="owner-contact-loading">ملف المالك غير متاح حالياً.</div>';
    return;
  }
  const avatar = p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👑';
  host.innerHTML = `
    <div class="owner-contact-head" data-owner-profile="${esc(p.id)}">
      <div class="owner-contact-avatar">${avatar}</div>
      <div class="owner-contact-info">
        <strong>@${esc(p.username || 'owner')} ${p.verified ? '✓' : ''}</strong>
        <span>👑 مالك التطبيق · للاستفسار والطلبات والشكاوى</span>
      </div>
      <button class="icon-btn owner-profile-btn" title="فتح ملف المالك">›</button>
    </div>
    <div class="owner-contact-actions">
      <button data-owner-request="استفسار">استفسار</button>
      <button data-owner-request="طلب">طلب</button>
      <button data-owner-request="شكوى">شكوى</button>
    </div>`;
  host.querySelector('[data-owner-profile]')?.addEventListener('click', () => openUserProfile(p.id));
  host.querySelector('.owner-profile-btn')?.addEventListener('click', e => { e.stopPropagation(); openUserProfile(p.id); });
  host.querySelectorAll('[data-owner-request]').forEach(btn =>
    btn.addEventListener('click', () => startOwnerRequest(btn.dataset.ownerRequest))
  );
}

async function startOwnerRequest(kind) {
  if (!S.ownerUid) return toast('ملف المالك غير متاح حالياً.', 'error');
  if (S.ownerUid === uid()) return openView('profile-view');
  await startPrivateByUid(S.ownerUid);
  const input = $('message-input');
  if (input) {
    input.value = `${kind}: `;
    resizeMessageInput();
    updateSendButtons();
    input.focus();
  }
}

function renderProfileModal() {
  if (!S.me) return;
  const pu = $('profile-username');
  if (pu) { pu.value = '@' + S.me.username; pu.removeAttribute('disabled'); }
  const pb = $('profile-bio');
  if (pb) pb.value = S.me.bio || '';
  const dn = $('profile-displayName');
  if (dn) dn.value = S.me.displayName || '';
  const pd = $('profile-device');
  if (pd) pd.value = S.deviceId;
  const av = $('profile-avatar-big');
  if (av) av.innerHTML = S.me.avatar ? `<img src="${esc(safeImageUrl(S.me.avatar))}" alt="">` : '👤';
}

/* ==================== Enter app ==================== */
function enterApp() {
  if (!S.me) return;
  setupTyping();
  $('auth-screen')?.classList.add('hidden');
  $('pin-screen')?.classList.add('hidden');
  $('app-screen')?.classList.remove('hidden');
  $('splash-screen')?.classList.add('hidden');
  applyLocalPreferences();
  renderOwnIdentity();
  renderProfileModal();
  bindRealtimeData();
  loadAboutCounts();
  loadOwnerProfile();
  resizeMessageInput();
  updateSendButtons();
  localStorage.setItem('chatapp_has_account', '1');

  if (isMobile()) {
    $('sidebar')?.classList.add('open');
    $('chat-empty')?.classList.remove('hidden');
    $('chat-view')?.classList.add('hidden');
  }

  if (!S.storyExpiryTimer) S.storyExpiryTimer = setInterval(() => renderStoryData(S.storyRaw), 30000);
  handleInviteParam();
  processPendingQuickReply();  // ← أضف هذا السطر
}

/* ==================== Realtime detach / listen ==================== */
function detachRealtime() {
  S.realtimeUnsubs.forEach(fn => { try { fn(); } catch {} });
  S.realtimeUnsubs = [];
  S.messageUnsubs.forEach(fn => { try { fn(); } catch {} });
  S.messageUnsubs = [];
  if (S.connectionRef) { try { S.connectionRef.off(); } catch {} S.connectionRef = null; }
  if (S.typingRef) { try { S.typingRef.off(); } catch {} S.typingRef = null; }
  if (S.chatPresenceUnsub) { try { S.chatPresenceUnsub(); } catch {} S.chatPresenceUnsub = null; }
  if (S.chatTypingUnsub) { try { S.chatTypingUnsub(); } catch {} S.chatTypingUnsub = null; }
  if (S.storyExpiryTimer) { clearInterval(S.storyExpiryTimer); S.storyExpiryTimer = null; }
  if (S.adminUsersUnsub) { try { S.adminUsersUnsub(); } catch {} S.adminUsersUnsub = null; }
  detachChatListeners();
}

function listenError(path) {
  return err => {
    console.warn(`listener ${path} failed:`, err?.code || err);
    if (err?.code === 'PERMISSION_DENIED' || err?.code === 'permission_denied') {
      toast(`رفضت قاعدة البيانات القراءة من «${path.split('/')[0]}». انشر آخر database.rules.json.`, 'error', 5000);
    }
  };
}

function listenValue(path, handler) {
  const ref = db.ref(path);
  ref.on('value', handler, listenError(path));
  S.realtimeUnsubs.push(() => ref.off('value', handler));
}

function bindRealtimeData() {
  detachRealtime();
  if (!uid()) return;
  const presenceRef = db.ref(`presence/${uid()}`);
  const connectedRef = db.ref('.info/connected');
  const connectedHandler = snap => {
    const online = snap.val() === true;
    $('chat-status')?.classList.toggle('db-offline', !online && !!S.activeChatId);
    if (!online) return;
    presenceRef.onDisconnect().set({
      online: false,
      lastSeen: SERVER,
      showOnline: S.me?.showOnline !== false,
      showLastSeen: S.me?.showLastSeen !== false
    }).catch(() => {});
    presenceRef.update({ online: true, lastSeen: SERVER }).catch(() => {});
  };
  connectedRef.on('value', connectedHandler);
  S.realtimeUnsubs.push(() => connectedRef.off('value', connectedHandler));
  S.connectionRef = presenceRef;

  listenValue(`presence/${uid()}`, snap => {
    const p = snap.val() || {};
    S.presenceCache.set(uid(), p);
  });
  loadChatCache();
  listenValue(`notifications/${uid()}`, snap => handleNotifications(snap.val() || {}));
  listenValue(`chatRequests/${uid()}`, snap => {
    S.chatRequests = snap.val() || {};
    scheduleChatListRender();
  });
  listenValue(`followers/${uid()}`, snap => {
    S.storyAudience.followers = new Set(Object.keys(snap.val() || {}));
    renderStoryData(S.storyRaw);
  });
  listenValue(`following/${uid()}`, snap => {
    S.storyAudience.following = new Set(Object.keys(snap.val() || {}));
    renderStoryData(S.storyRaw);
  });
  listenValue('userChats/' + uid(), snap => renderChatIndex(snap.val() || {}));

  const storyRef = db.ref('stories').orderByChild('expiresAt').limitToLast(200);
  const storyHandler = snap => renderStoryData(snap.val() || {});
  storyRef.on('value', storyHandler, listenError('stories'));
  S.realtimeUnsubs.push(() => storyRef.off('value', storyHandler));
}

/* ==================== Notifications ==================== */
function handleNotifications(items) {
  Object.entries(items).forEach(([id, n]) => {
    if (!n || S.lastNotifications.has(id)) return;
    S.lastNotifications.add(id);
    if (n.read) return;

    // Toast داخل التطبيق
    toast(`${n.title || 'إشعار'}${n.body ? ': ' + n.body : ''}`, 'info', 4500);

    // نغمة + اهتزاز
    notifyTone(n.type === 'message' ? 'message' : 'other');
    if (n.type === 'message') navigator.vibrate?.(20);

    // ✅ إشعار حقيقي على الجهاز
    const chatId = n.chatId || null;
    const chat = chatId ? S.chatCache.get(chatId) : null;
    const chatName = chat ? displayChatName(chat) : (n.title || 'ChatApp');
    const senderName = n.from ? ('@' + (S.profileCache.get(n.from)?.username || '')) : '';
    const avatar = n.from ? safeImageUrl(S.profileCache.get(n.from)?.avatar) : '';

    const shouldNotify = document.hidden
      || !chatId
      || S.activeChatId !== chatId;

    if (shouldNotify && S.me?.settings?.notifications !== false) {
      showDeviceNotification({
        title: chatName,
        body: senderName
          ? `${senderName}: ${n.body || ''}`
          : (n.body || n.title || ''),
        chatId,
        chatType: chat?.type || 'private',
        senderId: n.from,
        senderName,
        avatar,
        tag: chatId ? `chat-${chatId}` : `notif-${id}`
      });
    }

    db.ref(`notifications/${uid()}/${id}/read`).set(true).catch(() => {});
  });
}

function loadChatCache() {
  try {
    const raw = JSON.parse(localStorage.getItem(`chatapp_chat_cache_${uid()}`) || '{}');
    Object.entries(raw).forEach(([id, c]) => { if (c?.id) S.chatCache.set(id, c); });
  } catch {}
}

function saveChatCache() {
  try {
    const out = {};
    for (const [id, c] of S.chatCache) out[id] = c;
    localStorage.setItem(`chatapp_chat_cache_${uid()}`, JSON.stringify(out));
  } catch {}
}

function notifyTone(kind = 'other') {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC || S.me?.settings?.sounds === false) return;
    const ac = new AC(), o = ac.createOscillator(), g = ac.createGain();
    o.frequency.value = kind === 'message' ? 880 : 660;
    g.gain.setValueAtTime(.0001, ac.currentTime);
    g.gain.exponentialRampToValueAtTime(.06, ac.currentTime + .01);
    g.gain.exponentialRampToValueAtTime(.0001, ac.currentTime + .13);
    o.connect(g);
    g.connect(ac.destination);
    o.start();
    o.stop(ac.currentTime + .15);
    setTimeout(() => ac.close?.(), 300);
  } catch {}
}

function makeNotification(targetUid, type, title, body, updates) {
  if (!targetUid || targetUid === uid()) return;
  const nid = db.ref(`notifications/${targetUid}`).push().key;
  updates[`notifications/${targetUid}/${nid}`] = {
    type, from: uid(), title, body, createdAt: SERVER, read: false
  };
}

/* ==================== Chat list ==================== */
const otherParticipant = c => Object.keys(c?.participants || {}).find(x => x !== uid());

function renderChatIndex(index) {
  S.chatIndex = index || {};
  syncChatListeners(Object.keys(S.chatIndex));
  saveChatCache();
  scheduleChatListRender();
}

function syncChatListeners(ids) {
  const wanted = new Set(ids);
  for (const [id, l] of [...S.chatListeners]) {
    if (wanted.has(id)) continue;
    try { l.ref.off('value', l.handler); } catch {}
    S.chatListeners.delete(id);
    S.chatCache.delete(id);
    
  }
  ids.forEach(id => {
    if (S.chatListeners.has(id)) return;
    const ref = db.ref(`chats/${id}`);
    const handler = snap => {
      if (!snap.exists()) {
        S.chatCache.delete(id);
        saveChatCache();
      } else {
        const c = { ...snap.val(), id };
        S.chatCache.set(id, c);
        saveChatCache();
        if (S.activeChatId === id) onActiveChatChanged(c);
      }
      scheduleChatListRender();
    };
    const onErr = err => {
      console.warn('chat listener failed:', id, err?.code || err);
      S.chatListeners.delete(id);
      S.chatCache.delete(id);
      scheduleChatListRender();
    };
    ref.on('value', handler, onErr);
    S.chatListeners.set(id, { ref, handler });
  });
}

function detachChatListeners() {
  for (const [, l] of S.chatListeners) {
    try { l.ref.off('value', l.handler); } catch {}
  }
  S.chatListeners.clear();
  S.chatCache.clear();
  S.chatIndex = null;
  clearTimeout(S.chatRenderTimer);
}

function onActiveChatChanged(c) {
  if (!c.participants?.[uid()] || (c.deletedAt && !isStaff())) {
    toast('لم تعد هذه المحادثة متاحة لك.', 'info');
    closeActiveChat();
    return;
  }
  const prev = S.activeChat || {};
  const headerChanged = c.name !== prev.name
    || Object.keys(c.participants || {}).length !== Object.keys(prev.participants || {}).length;
  S.activeChat = c;
  if (headerChanged) renderChatHeader();

  // صفّر العداد طالما المحادثة مفتوحة
  if (S.activeChatId === c.id && Number(c.unreadCount?.[uid()] || 0) > 0) {
    db.ref(`chats/${c.id}/unreadCount/${uid()}`).set(0).then(() => {
      const cached = S.chatCache.get(c.id);
      if (cached) {
        cached.unreadCount = cached.unreadCount || {};
        cached.unreadCount[uid()] = 0;
        S.chatCache.set(c.id, cached);
        saveChatCache();
        scheduleChatListRender();
      }
    }).catch(e => console.warn('unreadCount reset failed:', e?.code));
  }
}

function scheduleChatListRender() {
  clearTimeout(S.chatRenderTimer);
  S.chatRenderTimer = setTimeout(drawChatList, 50);
}

async function drawChatList() {
  const list = $('chat-list');
  const me = uid();
  if (!list || !me || !S.chatIndex) return;
  const seq = ++S.chatRenderSeq;
  const chats = Object.keys(S.chatIndex)
    .map(id => S.chatCache.get(id))
    .filter(c => c && c.participants?.[me] && !(c.deletedAt && !isStaff()));
  const pending = Object.values(S.chatRequests || {}).filter(r => r?.status === 'pending' && r.toUid === me);
  await warmProfiles(
    chats.filter(c => c.type === 'private').map(otherParticipant)
      .concat(pending.map(r => r.fromUid))
  );
  if (seq !== S.chatRenderSeq) return;

  const q = S.chatQuery.trim().toLowerCase();
  const tab = S.chatTab;
  const visible = chats.filter(c => {
    const archived = !!c.archived?.[me];
    if (tab === 'archived') {
      if (!archived) return false;
    } else {
      if (archived) return false;
      if (tab === 'unread' && !(Number(c.unreadCount?.[me] || 0) > 0)) return false;
      if (tab === 'groups' && c.type !== 'group') return false;
    }
    if (q && !`${displayChatName(c)} ${c.lastMessage?.text || ''}`.toLowerCase().includes(q)) return false;
    return true;
  }).sort((a, b) =>
    (Number(!!b.pinned?.[me]) - Number(!!a.pinned?.[me]))
    || (Number(b.updatedAt || b.createdAt || 0) - Number(a.updatedAt || a.createdAt || 0))
  );

  const requestHtml = pending
    .filter(r => !q || (`@${S.profileCache.get(r.fromUid)?.username || ''} طلب مراسلة`).toLowerCase().includes(q))
    .map(r => requestItemHtml(r.chatId, r))
    .join('');

  if (!chats.length && !requestHtml) {
    list.innerHTML = `
      <div class="chat-list-empty">
        <strong>لا توجد محادثات بعد</strong>
        <span>ابدأ بمراسلة مستخدم أو أنشئ مجموعة جديدة.</span>
        <div class="empty-actions">
          <button class="admin-btn" id="empty-new-chat">➕ محادثة جديدة</button>
          <button class="admin-btn" id="empty-new-group">👥 مجموعة جديدة</button>
        </div>
      </div>`;
  } else if (!visible.length && !requestHtml) {
    list.innerHTML = '<div class="chat-list-empty"><span>لا توجد نتائج في هذا القسم.</span></div>';
  } else {
    list.innerHTML = requestHtml + visible.map(c => chatItemHtml(c.id, c)).join('');
  }
}

function setChatTab(tab) {
  S.chatTab = tab;
  qsa('.chat-tab').forEach(b => b.classList.toggle('active', b.dataset.ctab === tab));
  scheduleChatListRender();
}

function displayChatName(c) {
  if (c.type === 'group') return c.name || 'مجموعة';
  const p = S.profileCache.get(otherParticipant(c));
  return p?.username ? '@' + p.username : 'محادثة';
}

function chatAvatarHtml(c) {
  if (c.type === 'group') {
    if (c.photo) return `<img src="${esc(safeImageUrl(c.photo))}" alt="">`;
    return `<span class="avatar-fallback">👥</span>`;
  }
  const p = S.profileCache.get(otherParticipant(c));
  return p?.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤';
}

function requestItemHtml(id, r) {
  const p = S.profileCache.get(r.fromUid) || {};
  return `<div class="chat-item request-item" data-request-chat="${esc(id)}" data-request-from="${esc(r.fromUid)}">
    <div class="chat-item-avatar">${p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤'}</div>
    <div class="chat-item-info">
      <div class="chat-item-name">@${esc(p.username || r.fromUid.slice(0, 8))} ${userBadgesHtml(r.fromUid, 'sm')}</div>
      <div class="chat-item-last">📨 طلب مراسلة جديد</div>
    </div>
    <div class="request-actions">
      <button data-request-action="approve">قبول</button>
      <button data-request-action="reject">رفض</button>
    </div>
  </div>`;
}

function chatItemHtml(id, c) {
  const me = uid();
  const target = c.type === 'private' ? otherParticipant(c) : null;
  const mine = c.lastMessage?.senderId === me;
  const unread = Number(c.unreadCount?.[me] || 0);
  const lastText = c.lastMessage?.text || 'لا توجد رسائل بعد';
  return `<div class="chat-item ${S.activeChatId === id ? 'active' : ''}" data-id="${esc(id)}">
    <div class="chat-item-avatar">${chatAvatarHtml(c)}</div>
    <div class="chat-item-info">
      <div class="chat-item-name">${esc(displayChatName(c))}${target ? userBadgesHtml(target, 'sm') : ''}${c.type === 'group' ? ' <small style="color:var(--text-secondary);font-weight:400">· ' + Object.keys(c.participants || {}).length + '</small>' : ''}</div>
      <div class="chat-item-last">${mine ? 'أنت: ' : ''}${esc(lastText.slice(0, 80))}</div>
    </div>
    <div class="chat-item-meta">
      <span class="chat-item-time">${c.lastMessage ? relativeTime(c.updatedAt || c.createdAt) : ''}</span>
      ${unread ? `<b class="chat-item-badge">${unread > 99 ? '99+' : unread}</b>` : ''}
      ${c.pinned?.[me] ? '<span class="chat-item-pin">📌</span>' : ''}
      ${c.muted?.[me] ? '<span class="chat-item-mute">🔕</span>' : ''}
    </div>
  </div>`;
}

async function warmProfiles(userIds) {
  const t = now();
  S.profileFetchedAt = S.profileFetchedAt || new Map();
  const missing = [...new Set(userIds)]
    .filter(x => x && (!S.profileCache.has(x) || t - (S.profileFetchedAt.get(x) || 0) > 5 * 60 * 1000));
  await Promise.all(missing.map(async id => {
    const ps = await db.ref(`profiles/${id}`).once('value').catch(() => null);
    if (ps?.exists()) {
      S.profileCache.set(id, { ...ps.val(), id });
      S.profileFetchedAt.set(id, t);
    }
    // users/{id} خاص — يُقرأ فقط لنفسنا أو للإداريين
    if (isStaff() || id === uid()) {
      const us = await db.ref(`users/${id}`).once('value').catch(() => null);
      if (us?.exists()) S.userCache.set(id, { ...us.val(), id });
    }
  }));
}

/* ==================== Open / close chat ==================== */
function stopMyTyping() {
  clearTimeout(S.typingTimer);
  S.typingSent = false;
  if (S.activeChatId && uid()) db.ref(`typing/${S.activeChatId}/${uid()}`).remove().catch(() => {});
}

async function openChatMonitor(chatId) {
  if (!isOwner() || !chatId) return;
  try {
    const snap = await db.ref(`chats/${chatId}`).once('value');
    if (!snap.exists()) return toast('المحادثة غير موجودة.', 'error');
    const c = { ...snap.val(), id: chatId };
    S.monitorMode = true;
    S.activeChatId = chatId;
    S.activeChat = c;
    S.chatCache.set(chatId, c);
    $('chat-view')?.classList.remove('hidden');
    $('chat-empty')?.classList.add('hidden');
    $('input-bar')?.classList.add('hidden');
    await renderChatHeader();
    loadMessages(chatId);
    toast('وضع المراقبة: قراءة فقط.', 'info');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function openChat(chatId) {
  if (!chatId || S.openingChat === chatId) return;
  S.openingChat = chatId;
  try {
    let snap;
    try { snap = await db.ref(`chats/${chatId}`).once('value'); }
    catch (e) { return toast('ليس لديك صلاحية لهذه المحادثة.', 'error'); }
    if (!snap.exists()) return toast('المحادثة غير متاحة.', 'error');
    const c = { ...snap.val(), id: chatId };
    if (c.deletedAt && !isStaff()) return toast('هذه المحادثة محذوفة إدارياً.', 'error');
    if (!c.participants?.[uid()]) return toast('ليس لديك صلاحية لهذه المحادثة.', 'error');

    if (c.type === 'private' && c.requestState === 'pending') {
      return c.createdBy === uid()
        ? toast('بانتظار موافقة الطرف الآخر.', 'info')
        : toast('لديك طلب مراسلة. اقبله من قائمة المحادثات.', 'info');
    }
    if (c.type === 'private' && c.requestState === 'rejected') {
      return toast('تم رفض طلب المراسلة سابقاً.', 'info');
    }

    if (S.activeChatId && S.activeChatId !== chatId) {
      stopMyTyping();
      S.currentReply = null;
      S.currentEdit = null;
      S.pendingAttachment = null;
      const inp = $('message-input');
      if (inp) { inp.value = ''; resizeMessageInput(); }
      $('upload-progress')?.classList.add('hidden');
      $('chat-search-bar')?.classList.add('hidden');
      updateReplyEditUI();
      updateSendButtons();
    }
    S.monitorMode = false;
    S.activeChatId = chatId;
    S.activeChat = c;
    S.chatCache.set(chatId, c);
    qsa('#chat-list .chat-item').forEach(x => x.classList.toggle('active', x.dataset.id === chatId));
    $('chat-view')?.classList.remove('hidden');
    $('input-bar')?.classList.remove('hidden');
    $('chat-empty')?.classList.add('hidden');
    if (isMobile()) $('sidebar')?.classList.remove('open');
    await renderChatHeader();
    bindActiveChatPresence();
    bindActiveChatTyping();
    loadMessages(chatId);

    // صفّر العداد فوراً
    if (Number(c.unreadCount?.[uid()] || 0) > 0) {
      db.ref(`chats/${chatId}/unreadCount/${uid()}`).set(0).then(() => {
        const cached = S.chatCache.get(chatId);
        if (cached) {
          cached.unreadCount = cached.unreadCount || {};
          cached.unreadCount[uid()] = 0;
          S.chatCache.set(chatId, cached);
          saveChatCache();
          scheduleChatListRender();
        }
      }).catch(() => {});
    }
  } finally {
    S.openingChat = null;
  }
}

function closeActiveChat() {
  stopMyTyping();
  S.messageUnsubs.forEach(fn => { try { fn(); } catch {} });
  S.messageUnsubs = [];
  if (S.chatPresenceUnsub) { try { S.chatPresenceUnsub(); } catch {} S.chatPresenceUnsub = null; }
  if (S.chatTypingUnsub) { try { S.chatTypingUnsub(); } catch {} S.chatTypingUnsub = null; }
  S.activeChatId = null;
  S.activeChat = null;
  S.monitorMode = false;
  S.renderedMsgIds = null;
  S.currentReply = null;
  S.currentEdit = null;
  S.pendingAttachment = null;
  $('chat-view')?.classList.add('hidden');
  $('chat-empty')?.classList.remove('hidden');
  $('upload-progress')?.classList.add('hidden');
  $('typing-indicator')?.classList.add('hidden');
  const inp = $('message-input');
  if (inp) { inp.value = ''; resizeMessageInput(); }
  updateReplyEditUI();
  updateSendButtons();
  qsa('#chat-list .chat-item.active').forEach(x => x.classList.remove('active'));
  if (isMobile()) $('sidebar')?.classList.add('open');
}

async function renderChatHeader() {
  const c = S.activeChat;
  if (!c) return;
  const target = c.type === 'private' ? otherParticipant(c) : null;
  if (target) await warmProfiles([target]);
  if (S.activeChat?.id !== c.id) return;
  const nm = $('chat-name');
  if (nm) nm.textContent = displayChatName(c);
  const p = target ? (S.profileCache.get(target) || {}) : {};
  const st = $('chat-status');
  if (st) st.textContent = c.type === 'group' ? `${Object.keys(c.participants || {}).length} أعضاء` : (p.bio || 'محادثة خاصة');
  const av = $('chat-avatar');
  if (av) {
    av.innerHTML = c.type === 'group'
      ? (c.photo ? `<img src="${esc(safeImageUrl(c.photo))}" alt="">` : '👥')
      : (p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤');
  }
  if (target) updatePresenceText();
  applyChatBackground();
  const banner = $('group-ban-banner');
  if (banner) {
    const mePart = c.participants?.[uid()] || {};
    const perma = c.blocked?.[uid()] === true;
    const temp = mePart.bannedUntil && Number(mePart.bannedUntil) > now();
    const isBanned = c.type === 'group' && (perma || temp);
    banner.classList.toggle('hidden', !isBanned);
    $('input-bar')?.classList.toggle('hidden', isBanned || S.monitorMode);
    if (isBanned) {
      banner.innerHTML = `🚫 ${perma
        ? 'أنت محظور من هذه المجموعة بشكل دائم.'
        : `أنت محظور مؤقتاً حتى ${esc(dayTime(mePart.bannedUntil))}.`} ${mePart.banReason ? `<br><small>السبب: ${esc(mePart.banReason)}</small>` : ''} ${S.ownerUid && uid() !== S.ownerUid ? '<button id="request-unban" class="btn-sm">طلب رفع الحظر</button>' : ''}`;
      $('request-unban')?.addEventListener('click', () => startPrivateByUid(S.ownerUid));
    }
  }
}

/* ==================== Messages ==================== */
function loadMessages(chatId) {
  S.messageUnsubs.forEach(fn => { try { fn(); } catch {} });
  S.renderedMsgIds = null;
  S.messageUnsubs = [];
  const host = $('messages-container');
  if (host) host.innerHTML = '<div class="chat-list-empty"><span>جارٍ تحميل الرسائل…</span></div>';
  S.forceScroll = true;
  const ref = db.ref(`messages/${chatId}`).orderByChild('timestamp').limitToLast(300);
  const handler = async snap => {
    if (S.activeChatId !== chatId) return;
    const messages = [];
    snap.forEach(ch => { messages.push({ ...ch.val(), id: ch.key }); });
    S.messageCache.set(chatId, messages);
    if (S.activeChat?.type === 'group') await warmProfiles(messages.map(m => m.senderId));
    if (S.activeChatId !== chatId) return;
    renderMessages(messages);
    markMessagesRead(messages);
  };
  const onErr = err => {
    console.warn('messages listener failed:', err?.code || err);
    if (host) host.innerHTML = '<div class="chat-list-empty"><strong>تعذر تحميل الرسائل</strong><span>تحقق من نشر database.rules.json ومن صلاحياتك.</span></div>';
    toast(`تعذر تحميل الرسائل: ${firebaseErrorMessage(err)}`, 'error');
  };
  ref.on('value', handler, onErr);
  S.messageUnsubs.push(() => ref.off('value', handler));
}

async function markMessagesRead(messages) {
  const chatId = S.activeChatId;
  if (!chatId || !uid()) return;

  const updates = {};
  for (const m of messages) {
    if (m.senderId === uid() || m.deletedForAll) continue;
    if (!m.deliveredTo?.[uid()]) updates[`messages/${chatId}/${m.id}/deliveredTo/${uid()}`] = SERVER;
    if (S.me?.settings?.readReceipts !== false && !m.readBy?.[uid()])
      updates[`messages/${chatId}/${m.id}/readBy/${uid()}`] = SERVER;
  }

  // صفّر العداد
  const currentUnread = Number(S.chatCache.get(chatId)?.unreadCount?.[uid()] || 0);
  if (currentUnread > 0) {
    updates[`chats/${chatId}/unreadCount/${uid()}`] = 0;
    const cached = S.chatCache.get(chatId);
    if (cached) {
      cached.unreadCount = cached.unreadCount || {};
      cached.unreadCount[uid()] = 0;
      S.chatCache.set(chatId, cached);
      saveChatCache();
      scheduleChatListRender();
    }
  }

  if (Object.keys(updates).length) {
    try {
      await db.ref().update(updates);
    } catch (e) {
      console.warn('read receipt failed:', e?.code, e?.message);
    }
  }
}

function renderMessages(messages) {
  const host = $('messages-container');
  if (!host) return;
  const me = uid();
  const visible = messages.filter(m => !m.deletedFor?.[me]);
  const nearBottom = S.forceScroll || (host.scrollHeight - host.scrollTop - host.clientHeight < 140);
  const prevTop = host.scrollTop;
  const prevIds = S.renderedMsgIds;
  const isFirstRender = !prevIds;
  if (visible.length) {
    host.innerHTML = visible.map(m => {
      const html = messageHtml(m);
      if (!isFirstRender && !prevIds.has(m.id)) {
        return html.replace('class="message ', 'class="message new ');
      }
      return html;
    }).join('');
  } else {
    host.innerHTML = '<div class="chat-list-empty"><span>لا توجد رسائل بعد. ابدأ المحادثة 👋</span></div>';
  }
  S.renderedMsgIds = new Set(visible.map(m => m.id));
  host.scrollTop = nearBottom ? host.scrollHeight : prevTop;
  S.forceScroll = false;
}

function messageHtml(m) {
  const me = uid();
  const mine = m.senderId === me;
  const deleted = !!m.deletedForAll;
  const url = fileUrl(m.fileData);
  let body = '';
  if (deleted) body = '<em>تم حذف الرسالة</em>';
  else if (m.type === 'image') body = `<img class="message-image" loading="lazy" src="${esc(url)}" alt="${esc(m.fileData?.name || 'صورة')}">`;
  else if (m.type === 'video') body = `<video class="message-video" controls preload="metadata" src="${esc(url)}"></video>`;
  else if (m.type === 'audio') body = `<audio class="message-audio" controls src="${esc(url)}"></audio>`;
  else if (m.type === 'file') body = `<a class="message-file" href="${esc(url)}" download="${esc(m.fileData?.name || 'file')}"><span class="message-file-icon">📎</span><span class="message-file-info"><span class="message-file-name">${esc(m.fileData?.name || 'ملف')}</span><span class="message-file-size">${esc(m.fileData?.size ? bytes(m.fileData.size) : '')}</span></span></a>`;
  else body = escapeHtmlLine(m.text || '');
  if (!deleted && m.type !== 'text' && m.text) body += `<div class="message-caption">${escapeHtmlLine(m.text)}</div>`;

  let replyHtml = '';
  if (m.replyTo && !deleted) {
    const storyReply = String(m.replyTo.messageId || '').startsWith('story_');
    const who = storyReply ? 'قصة' : (m.replyTo.senderId === me ? 'أنت' : '@' + (S.profileCache.get(m.replyTo.senderId)?.username || 'رد'));
    replyHtml = `<div class="msg-reply" data-reply-id="${esc(m.replyTo.messageId || '')}"><span class="msg-reply-sender">↩ ${esc(who)}</span><span class="msg-reply-text">${esc((m.replyTo.text || '').slice(0, 80))}</span></div>`;
  }

  let reactionsHtml = '';
  if (m.reactions && !deleted) {
    const grouped = {};
    Object.entries(m.reactions).forEach(([u, r]) => {
      if (r) (grouped[r] = grouped[r] || []).push(u);
    });
    if (Object.keys(grouped).length) {
      reactionsHtml = '<div class="msg-reactions">' + Object.entries(grouped).map(([r, us]) =>
        `<span class="reaction-chip ${us.includes(me) ? 'mine' : ''}" data-reaction="${esc(r)}">${esc(r)} ${us.length}</span>`
      ).join('') + '</div>';
    }
  }

  const edited = m.edited && !deleted ? ' · معدل' : '';
  const readByOthers = m.readBy && Object.keys(m.readBy).some(x => x !== me);
  const deliveredToOthers = m.deliveredTo && Object.keys(m.deliveredTo).some(x => x !== me);
  const status = mine && !deleted
    ? `<span class="message-status ${readByOthers ? 'read' : deliveredToOthers ? 'delivered' : ''}">${readByOthers || deliveredToOthers ? '✓✓' : '✓'}</span>`
    : '';
  const star = m.starred?.[me] ? '<span class="msg-star">⭐</span>' : '';
  const senderLabel = !mine && S.activeChat?.type === 'group'
    ? `<span class="msg-sender profile-link" data-profile-id="${esc(m.senderId)}">@${esc(S.profileCache.get(m.senderId)?.username || String(m.senderId || '').slice(0, 6))}</span>`
    : '';

  return `<div class="message ${mine ? 'out' : 'in'} ${deleted ? 'deleted' : ''}" data-id="${esc(m.id)}">
    <div class="message-bubble">
      ${senderLabel}${replyHtml}${body}${reactionsHtml}
      <div class="message-meta"><span>${star}${esc(dayTime(m.timestamp))}${edited}</span>${status}</div>
    </div>
  </div>`;
}

async function addReactionTo(ev, messageId, reaction) {
  if (!S.activeChatId) return;
  try {
    const path = `messages/${S.activeChatId}/${messageId}/reactions/${uid()}`;
    const cur = (await db.ref(path).once('value')).val();
    await db.ref(path).set(cur === reaction ? null : reaction);
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

/* ==================== Send message ==================== */
function updateSendButtons() {
  const has = ($('message-input')?.value || '').trim().length > 0 || !!S.pendingAttachment;
  $('btn-send')?.classList.toggle('hidden', !has);
  $('btn-voice')?.classList.toggle('hidden', has);
}

const attachmentIcon = t =>
  t === 'image' ? '📷'
  : t === 'video' ? '🎥'
  : t === 'audio' ? '🎵'
  : '📎';

async function sendMessage() {
  if (S.sending) return;
  if (!S.activeChatId || !S.activeChat || !S.me || S.monitorMode) return;
  if (S.me.status !== 'active') return toast('الحساب غير نشط.', 'error');
  const chatId = S.activeChatId;
  const chat = S.activeChat;
  const input = $('message-input');
  const text = (input?.value || '').trim();
  const att = S.pendingAttachment;
  if (!text && !att) return;
  if (text.length > MAX_TEXT) return toast(`الرسالة تتجاوز ${MAX_TEXT} حرف.`, 'error');
  if (!chat.participants?.[uid()]) return toast('لم تعد عضواً في هذه المحادثة.', 'error');
  const myPart = chat.participants?.[uid()] || {};
  if (chat.requestState === 'rejected') return toast('تم رفض طلب المراسلة. لا يمكن إرسال رسائل.', 'error');
  if (chat.requestState === 'pending') return toast('المحادثة بانتظار الموافقة.', 'info');
  if (chat.type === 'group' && chat.blocked?.[uid()] === true) return toast('أنت محظور من هذه المجموعة.', 'error');
  if (chat.type === 'group' && myPart.bannedUntil && Number(myPart.bannedUntil) > now())
    return toast(`أنت محظور مؤقتاً حتى ${dayTime(myPart.bannedUntil)}.`, 'error');
  if (chat.type === 'private') {
    const t = otherParticipant(chat);
    if (t && S.blocked.has(t)) return toast('أنت حاظر هذا المستخدم. ألغِ الحظر لتتمكن من المراسلة.', 'error');
  }

  S.sending = true;
  try {
    if (S.currentEdit) {
      if (!text) return toast('لا يمكن أن تكون الرسالة المعدّلة فارغة.', 'error');
      const up = {};
      up[`messages/${chatId}/${S.currentEdit}/text`] = text;
      up[`messages/${chatId}/${S.currentEdit}/edited`] = true;
      await db.ref().update(up);
      cancelEdit();
      input.value = '';
      resizeMessageInput();
      updateSendButtons();
      return;
    }

    // اقرأ المحادثة الحية
    let liveChat = chat;
    try {
      const fresh = await db.ref(`chats/${chatId}`).once('value');
      if (fresh.exists()) liveChat = { ...fresh.val(), id: chatId };
    } catch (readErr) {
      console.warn('sendMessage: fresh read failed', readErr?.code);
    }

    if (liveChat.type === 'private') {
      const rs = liveChat.requestState;
      if (rs === 'rejected') return toast('تم رفض طلب المراسلة.', 'error');
      if (rs === 'pending') return toast('بانتظار الموافقة.', 'info');
    }

    const freshParts = liveChat.participants || {};
    const activeParticipants = Object.keys(freshParts).filter(
      x => x && x !== uid() && freshParts[x] && freshParts[x].role
    );

    const id = db.ref(`messages/${chatId}`).push().key;
    const rec = { senderId: uid(), timestamp: SERVER, status: 'sent', type: att ? att.type : 'text' };
    if (text) rec.text = text;
    if (att) rec.fileData = att.data;
    if (S.currentReply) {
      rec.replyTo = {
        messageId: S.currentReply.id,
        senderId: S.currentReply.senderId || '',
        text: String(S.currentReply.text || (S.currentReply.fileData?.name ? attachmentIcon(S.currentReply.type) + ' ' + S.currentReply.fileData.name : '')).slice(0, 180)
      };
    }
    const preview = (att ? `${attachmentIcon(att.type)} ${text || att.data?.name || ''}` : text).slice(0, 500);
    const updates = {};
    updates[`messages/${chatId}/${id}`] = rec;
    updates[`chats/${chatId}/lastMessage`] = { senderId: uid(), text: preview, type: rec.type };
    updates[`chats/${chatId}/updatedAt`] = SERVER;
    activeParticipants.forEach(target => {
      updates[`chats/${chatId}/unreadCount/${target}`] = firebase.database.ServerValue.increment(1);
      makeNotification(target, 'message', 'رسالة جديدة', `${S.me.username}: ${preview}`, updates);
    });
    S.forceScroll = true;
    await db.ref().update(updates);

    input.value = '';
    resizeMessageInput();
    S.pendingAttachment = null;
    S.currentReply = null;
    $('upload-progress')?.classList.add('hidden');
    stopMyTyping();
    updateReplyEditUI();
    updateSendButtons();
  } catch (e) {
    console.error('sendMessage failed:', {
      code: e?.code,
      message: e?.message,
      chatId: S.activeChatId,
      me: uid(),
      chatType: S.activeChat?.type,
      requestState: S.activeChat?.requestState,
      participants: Object.keys(S.activeChat?.participants || {})
    });
    const denied = e?.code === 'PERMISSION_DENIED' || e?.code === 'database/permission-denied';
    toast(
      denied
        ? 'تعذر الإرسال: القواعد رفضت العملية. افتح Console (F12) وأرسل لي رسالة الخطأ الكاملة.'
        : firebaseErrorMessage(e),
      'error', 6000
    );
  } finally {
    S.sending = false;
  }
}

/* ==================== Attachment ==================== */
function readAsDataUrl(blobOrFile) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error || new Error('تعذر قراءة الملف.'));
    r.readAsDataURL(blobOrFile);
  });
}

async function prepareAttachment(file) {
  if (!file) return;
  if (!S.activeChatId) return toast('افتح محادثة أولاً.', 'error');
  if (file.size > MAX_FILE_BYTES) return toast('الحد الأقصى للملف داخل RTDB هو 2MB.', 'error');
  try {
    let type = 'file', dataUrl = '', mime = file.type || 'application/octet-stream', size = file.size;
    if (file.type.startsWith('image/')) {
      type = 'image';
      dataUrl = await compressImage(file, 1280, .78);
      mime = 'image/jpeg';
      size = Math.round((dataUrl.length - dataUrl.indexOf(',') - 1) * 0.75);
    } else {
      if (file.type.startsWith('video/')) type = 'video';
      else if (file.type.startsWith('audio/')) type = 'audio';
      dataUrl = await readAsDataUrl(file);
    }
    if (!safeDataUrl(dataUrl)) return toast('تعذر تجهيز الملف.', 'error');
    if (dataUrl.length > MAX_DATA_URL_LENGTH || size > MAX_FILE_BYTES)
      return toast('بعد التحويل أصبح الملف أكبر من الحد المسموح (2MB).', 'error');
    S.pendingAttachment = {
      type,
      data: { name: String(file.name || 'file').slice(-200), size, mime: mime.slice(0, 100), dataUrl }
    };
    showAttachmentBar(S.pendingAttachment.data.name);
    updateSendButtons();
  } catch (e) {
    toast(e.message || 'تعذر تجهيز الملف.', 'error');
  }
}

function showAttachmentBar(name) {
  const fn = $('upload-filename');
  if (fn) fn.textContent = name;
  const pc = $('upload-percent');
  if (pc) pc.textContent = 'جاهز للإرسال · اضغط للإلغاء ✕';
  const pf = $('progress-fill');
  if (pf) pf.style.width = '100%';
  $('upload-progress')?.classList.remove('hidden');
}

function cancelAttachment() {
  S.pendingAttachment = null;
  $('upload-progress')?.classList.add('hidden');
  updateSendButtons();
}

/* ===================================================================
 * ==================== STORY SYSTEM =================================
 * =================================================================== */

function renderStoryData(raw) {
  S.storyRaw = raw || {};
  const current = now();
  const audience = S.storyAudience || { followers: new Set(), following: new Set() };
  S.stories = Object.entries(S.storyRaw)
    .map(([id, s]) => ({ ...s, id }))
    .filter(s => s.active === true && Number(s.expiresAt || 0) > current)
    .filter(s =>
      s.userId === uid()
      || isOwner()
      || audience.followers.has(s.userId)
      || audience.following.has(s.userId)
      || !!S.chatIndex?.[[uid(), s.userId].sort().join('_')]
    )
    .sort((a, b) => Number(a.createdAt || 0) - Number(b.createdAt || 0));

  const groups = new Map();
  S.stories.forEach(s => {
    if (!groups.has(s.userId)) groups.set(s.userId, []);
    groups.get(s.userId).push(s);
  });
  const myId = uid();
  S.storyGroups = [...groups.entries()].map(([userId, stories]) => ({ userId, stories }));
  S.storyGroups.sort((a, b) => {
    if (a.userId === myId) return -1;
    if (b.userId === myId) return 1;
    const aUnread = a.stories.some(s => !S.me?.storyViewed?.[s.id]);
    const bUnread = b.stories.some(s => !S.me?.storyViewed?.[s.id]);
    if (aUnread !== bUnread) return aUnread ? -1 : 1;
    const aLast = Math.max(...a.stories.map(s => Number(s.createdAt || 0)));
    const bLast = Math.max(...b.stories.map(s => Number(s.createdAt || 0)));
    return bLast - aLast;
  });
  renderStoriesBar();
}

async function renderStoriesBar() {
  const host = $('stories-bar');
  if (!host) return;
  await warmProfiles(S.storyGroups.map(x => x.userId));
  host.innerHTML = `<div class="story-add" id="story-add"><div class="story-add-circle">＋</div><span>قصتي</span></div>` +
    S.storyGroups.map(g => {
      const p = S.profileCache.get(g.userId) || {};
      const unread = g.stories.some(s => !S.me?.storyViewed?.[s.id]);
      return `<div class="story-item" data-user="${esc(g.userId)}">
        <div class="story-circle ${unread ? 'unread' : 'viewed'}">
          ${p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤'}
        </div>
        <span>${esc(g.userId === uid() ? 'أنت' : '@' + (p.username || 'مستخدم'))}</span>
      </div>`;
    }).join('');
  $('story-add')?.addEventListener('click', createStory);

  qsa('#stories-bar .story-item').forEach(el =>
    el.addEventListener('click', () => openStoryGroup(el.dataset.user, 0))
  );
}

const STORY_GRADIENTS = [
  'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
  'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
  'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
  'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
  'linear-gradient(135deg, #30cfd0 0%, #330867 100%)',
  'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
  'linear-gradient(135deg, #232526 0%, #414345 100%)'
];
const STORY_TEXT_SIZES = { small: '18px', medium: '24px', large: '32px', xlarge: '42px' };

function createStory() {
  if (!S.me || S.me.status !== 'active') return toast('الحساب غير نشط.', 'error');
  S.storyDraft = {
    text: '',
    bgGradient: STORY_GRADIENTS[0],
    imageDataUrl: null,
    textColor: '#ffffff',
    fontSize: 'medium'
  };
  renderStoryComposer();
  openView('story-composer-view');
  setTimeout(() => {
    const ta = $('story-text-input');
    if (ta) { ta.value = ''; ta.focus(); }
  }, 100);
}

function renderStoryComposer() {
  const d = S.storyDraft;
  if (!d) return;

  const preview = $('story-preview');
  if (preview) {
    if (d.imageDataUrl) {
      preview.style.background = `url(${d.imageDataUrl}) center/cover no-repeat`;
      preview.style.backgroundColor = '#000';
    } else {
      preview.style.background = d.bgGradient;
    }
  }

  const textEl = $('story-preview-text');
  if (textEl) {
    textEl.textContent = d.text || 'اكتب قصتك هنا...';
    textEl.style.color = d.textColor;
    textEl.style.fontSize = STORY_TEXT_SIZES[d.fontSize] || '24px';
    textEl.style.opacity = d.text ? '1' : '.45';
  }

  const gList = $('story-gradients');
  if (gList && !gList.dataset.built) {
    gList.innerHTML = STORY_GRADIENTS.map((g, i) =>
      `<button class="story-gradient" data-index="${i}" style="background:${g}"></button>`
    ).join('');
    gList.dataset.built = '1';
    qsa('.story-gradient').forEach(b => b.onclick = () => {
      S.storyDraft.bgGradient = STORY_GRADIENTS[Number(b.dataset.index)];
      S.storyDraft.imageDataUrl = null;
      renderStoryComposer();
    });
  }

  qsa('.story-gradient').forEach((b, i) =>
    b.classList.toggle('active', !d.imageDataUrl && STORY_GRADIENTS[i] === d.bgGradient)
  );
  qsa('.story-color').forEach(b => b.classList.toggle('active', b.dataset.color === d.textColor));
  qsa('.story-size').forEach(b => b.classList.toggle('active', b.dataset.size === d.fontSize));

  $('story-gradients-row')?.classList.toggle('hidden', !!d.imageDataUrl);
  $('story-clear-image')?.classList.toggle('hidden', !d.imageDataUrl);
  $('story-pick-image')?.classList.toggle('hidden', !!d.imageDataUrl);
}

async function publishStory() {
  const d = S.storyDraft;
  if (!d) return;
  const text = (d.text || '').trim();
  if (!text && !d.imageDataUrl) return toast('اكتب نصاً أو اختر صورة.', 'error');
  if (text.length > 200) return toast('النص طويل جداً.', 'error');

  const ref = db.ref('stories').push();
  const ts = now();
  const meta = {
    userId: uid(),
    type: d.imageDataUrl ? 'image' : 'text',
    createdAt: ts,
    expiresAt: ts + STORY_DURATION,
    active: false
  };
  if (d.imageDataUrl) {
    meta.preview = text ? text.slice(0, 600) : '';
  } else {
    meta.preview = text.slice(0, 600);
    meta.bgGradient = d.bgGradient;
    meta.textColor = d.textColor;
    meta.fontSize = d.fontSize;
  }

  const btn = $('story-publish');
  if (btn) btn.disabled = true;

  try {
    await ref.set(meta);
    const content = d.imageDataUrl
      ? { dataUrl: d.imageDataUrl, name: 'story.jpg', caption: text, textColor: d.textColor, fontSize: d.fontSize }
      : { text, bgGradient: d.bgGradient, textColor: d.textColor, fontSize: d.fontSize };
    await db.ref(`storyContents/${ref.key}`).set(content);
    await ref.update({ active: true });
    toast('تم نشر القصة ✨', 'success');
    closeModals();
    S.storyDraft = null;
  } catch (e) {
    await ref.update({ active: false, failedAt: SERVER }).catch(() => {});
    toast(firebaseErrorMessage(e), 'error');
  } finally {
    if (btn) btn.disabled = false;
  }
}

function openStoryGroup(userId, index = 0) {
  const g = S.storyGroups.find(x => x.userId === userId);
  if (!g || !g.stories.length) return;
  S.storyGroup = g;
  S.storyIndex = S.storyGroups.findIndex(x => x.userId === userId);
  S.storyItemIndex = Math.min(index, g.stories.length - 1);
  S.storyUserList = S.storyGroups.map(x => x.userId);
  showStoryCurrent();
}

async function showStoryCurrent() {
  const g = S.storyGroups[S.storyIndex];
  if (!g) return closeStory();
  const s = g.stories[S.storyItemIndex];
  if (!s) return closeStory();
  const p = S.profileCache.get(s.userId) || {};
  const viewer = $('story-viewer');
  if (!viewer) return;

  let contentSnap = null;
  let contentReadError = null;
  try { contentSnap = await db.ref(`storyContents/${s.id}`).once('value'); }
  catch (e) { contentReadError = e; }
  const data = contentSnap?.val() || s.data || (s.type === 'text' ? { text: s.preview || '' } : {});
  if (contentReadError && s.type === 'image') {
    console.warn('story content read failed', s.id, contentReadError?.code || contentReadError);
  }

  $('story-username').textContent = s.userId === uid() ? '@' + S.me.username : '@' + (p.username || 'مستخدم');
  $('story-avatar').innerHTML = p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤';

  const remaining = Math.max(0, Number(s.expiresAt) - now());
  const hrs = Math.floor(remaining / 3600000);
  const mins = Math.floor((remaining % 3600000) / 60000);
  $('story-time').textContent = `${relativeTime(s.createdAt)} · تُحذف بعد ${hrs}س ${mins}د`;

  const viewsBtn = $('story-views-btn');
  if (viewsBtn) {
    const isMine = s.userId === uid();
    viewsBtn.classList.toggle('hidden', !isMine);
    if (isMine) {
      db.ref(`storyViews/${s.id}`).once('value').then(snap => {
        const n = Object.keys(snap.val() || {}).length;
        viewsBtn.innerHTML = `👁️ ${n}`;
      }).catch(() => {});
    }
  }

  const progress = $('story-progress');
  progress.innerHTML = g.stories.map((_, i) => {
    let width = '0%';
    if (i < S.storyItemIndex) width = '100%';
    else if (i === S.storyItemIndex) width = '0%';
    return `<span class="story-progress-seg"><i style="width:${width};${i === S.storyItemIndex ? `animation:storyProgressFill ${STORY_VIEW_MS}ms linear forwards` : ''}"></i></span>`;
  }).join('');

  const content = $('story-content');
  const sizeMap = { small: '20px', medium: '28px', large: '38px', xlarge: '48px' };
  const textColor = data.textColor || '#ffffff';
  const fontSize = sizeMap[data.fontSize] || '28px';

  if (s.type === 'image') {
    const src = safeImageUrl(data.dataUrl);
    const caption = String(data.caption || s.preview || '').trim();
    content.innerHTML = src
      ? `<div class="story-image-wrap">
           <img src="${esc(src)}" alt="" loading="eager">
           ${caption ? `<div class="story-image-caption" style="color:${esc(textColor)};font-size:${fontSize}">${escapeHtmlLine(caption)}</div>` : ''}
         </div>`
      : '<div class="story-content-text">تعذر تحميل صورة القصة.</div>';
  } else {
    const text = String(data.text || s.preview || '').trim();
    const bg = data.bgGradient || 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
    content.innerHTML = text
      ? `<div class="story-content-text" style="background:${bg}">
           <span style="color:${esc(textColor)};font-size:${fontSize}">${escapeHtmlLine(text)}</span>
         </div>`
      : '<div class="story-content-text">تعذر تحميل نص القصة.</div>';
  }

  const isMine = s.userId === uid();
  const reactBar = $('story-reactions');
  if (reactBar) {
    reactBar.classList.toggle('hidden', isMine);
    if (!isMine) {
      reactBar.innerHTML = ['❤️', '😍', '😂', '😮', '🔥', '👏']
        .map(r => `<button data-story-reaction="${r}" type="button">${r}</button>`).join('');
      reactBar.querySelectorAll('[data-story-reaction]').forEach(b =>
        b.onclick = (ev) => { ev.stopPropagation(); reactToStory(b.dataset.storyReaction); }
      );
    }
  }
  $('story-reply-btn')?.classList.toggle('hidden', isMine);
  viewer.classList.remove('hidden');
  S.storyPaused = false;
  startStoryTimer();
  await markStoryViewed(s);
}

function startStoryTimer() {
  clearTimeout(S.storyTimer);
  clearInterval(S.storyProgressTimer);
  S.storyProgressStart = now();
  S.storyTimer = setTimeout(() => { if (!S.storyPaused) nextStory(); }, STORY_VIEW_MS);
}

function pauseStory() {
  if (S.storyPaused) return;
  S.storyPaused = true;
  clearTimeout(S.storyTimer);
  const elapsed = now() - S.storyProgressStart;
  const seg = $('story-progress')?.querySelectorAll('.story-progress-seg i')[S.storyItemIndex];
  if (seg) {
    const computed = getComputedStyle(seg).width;
    seg.style.animation = 'none';
    seg.style.width = computed;
  }
  S.storyRemaining = STORY_VIEW_MS - elapsed;
}

function resumeStory() {
  if (!S.storyPaused) return;
  S.storyPaused = false;
  const remaining = S.storyRemaining || STORY_VIEW_MS;
  const seg = $('story-progress')?.querySelectorAll('.story-progress-seg i')[S.storyItemIndex];
  if (seg) {
    seg.style.width = '0%';
    seg.style.animation = `storyProgressFill ${remaining}ms linear forwards`;
  }
  S.storyProgressStart = now();
  clearTimeout(S.storyTimer);
  S.storyTimer = setTimeout(() => { if (!S.storyPaused) nextStory(); }, remaining);
}

async function markStoryViewed(s) {
  if (!uid()) return;
  const updates = {};
  updates[`storyViews/${s.id}/${uid()}`] = SERVER;
  updates[`storyViewedByUser/${uid()}/${s.id}`] = SERVER;
  await db.ref().update(updates).catch(() => {});
  S.me.storyViewed = S.me.storyViewed || {};
  S.me.storyViewed[s.id] = now();
}

function nextStory() {
  clearTimeout(S.storyTimer);
  const g = S.storyGroups[S.storyIndex];
  if (!g) return closeStory();
  if (S.storyItemIndex < g.stories.length - 1) { S.storyItemIndex++; showStoryCurrent(); return; }
  if (S.storyIndex < S.storyGroups.length - 1) { S.storyIndex++; S.storyItemIndex = 0; showStoryCurrent(); return; }
  closeStory();
}

function prevStory() {
  clearTimeout(S.storyTimer);
  const g = S.storyGroups[S.storyIndex];
  if (!g) return;
  if (S.storyItemIndex > 0) { S.storyItemIndex--; showStoryCurrent(); return; }
  if (S.storyIndex > 0) {
    S.storyIndex--;
    S.storyItemIndex = S.storyGroups[S.storyIndex].stories.length - 1;
    showStoryCurrent();
    return;
  }
}

function closeStory() {
  clearTimeout(S.storyTimer);
  clearInterval(S.storyProgressTimer);
  $('story-viewer')?.classList.add('hidden');
  $('story-reply-bar')?.classList.add('hidden');
  $('story-emoji-picker')?.classList.add('hidden');
  S.pendingStoryReply = null;
  S.storyPaused = false;
}

async function storyReply() {
  const g = S.storyGroups[S.storyIndex];
  const s = g?.stories?.[S.storyItemIndex];
  if (!s || s.userId === uid()) return;
  S.pendingStoryReply = { story: s };
  const bar = $('story-reply-bar');
  if (bar) {
    bar.classList.remove('hidden');
    const input = $('story-reply-text');
    if (input) { input.value = ''; setTimeout(() => input.focus(), 100); }
  }
  // استخدم pauseStory لإيقاف الشريط البصري أيضاً
  pauseStory();
}

async function sendStoryReplyFromBar() {
  const s = S.pendingStoryReply?.story;
  const input = $('story-reply-text');
  const text = (input?.value || '').trim();
  if (!s || !text) return;

  try {
    const id = [uid(), s.userId].sort().join('_');
    const chatSnap = await db.ref(`chats/${id}`).once('value').catch(() => null);

    if (!chatSnap?.exists()) {
      await startPrivateByUid(s.userId);
      toast('أرسلنا طلب مراسلة. بعد الموافقة ستتمكن من الرد على القصص.', 'info', 5000);
      return;
    }
    const c = chatSnap.val();

    if (c.requestState === 'rejected') {
      return toast('تم رفض طلب المراسلة. لا يمكنك الرد على القصة.', 'error');
    }
    if (c.requestState === 'pending') {
      return c.createdBy === uid()
        ? toast('بانتظار موافقة الطرف الآخر.', 'info')
        : toast('لديك طلب معلق — اقبله أولاً من قائمة المحادثات.', 'info');
    }

    const mid = db.ref(`messages/${id}`).push().key;
    const preview = `↩️ قصة: ${text.slice(0, 250)}`;
    const updates = {};
    updates[`messages/${id}/${mid}`] = {
      senderId: uid(),
      timestamp: SERVER,
      status: 'sent',
      type: 'text',
      text,
      replyTo: { messageId: 'story_' + s.id, senderId: s.userId, text: '↩️ قصة' }
    };
    updates[`chats/${id}/lastMessage`] = { senderId: uid(), text: preview.slice(0, 500), type: 'text' };
    updates[`chats/${id}/updatedAt`] = SERVER;

    if (c.participants?.[s.userId]) {
      updates[`chats/${id}/unreadCount/${s.userId}`] = firebase.database.ServerValue.increment(1);
      const nid = db.ref(`notifications/${s.userId}`).push().key;
      updates[`notifications/${s.userId}/${nid}`] = {
        type: 'story_reply',
        from: uid(),
        title: 'رد على قصتك',
        body: text.slice(0, 100),
        createdAt: SERVER,
        read: false
      };
    }

    await db.ref().update(updates);
    input.value = '';
    $('story-reply-bar')?.classList.add('hidden');
    $('story-emoji-picker')?.classList.add('hidden');
    S.pendingStoryReply = null;
    resumeStory();
    toast('تم إرسال الرد.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function reactToStory(reaction) {
  const g = S.storyGroups[S.storyIndex];
  const s = g?.stories?.[S.storyItemIndex];
  if (!s || s.userId === uid()) return;
  try {
    const path = `storyReactions/${s.id}/${uid()}`;
    const cur = (await db.ref(path).once('value')).val();
    const updates = {};
    updates[path] = cur === reaction ? null : reaction;
    if (cur !== reaction) {
      makeNotification(s.userId, 'story_reaction', 'تفاعل مع قصتك', `@${S.me.username} تفاعل ${reaction} مع قصتك`, updates);
    }
    await db.ref().update(updates);
    notifyTone('other');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function showStoryViewers() {
  const g = S.storyGroups[S.storyIndex];
  const s = g?.stories?.[S.storyItemIndex];
  if (!s) return;
  if (s.userId !== uid() && !isStaff()) return toast('المشاهدات تظهر فقط لصاحب القصة.', 'info');
  const snap = await db.ref(`storyViews/${s.id}`).once('value');
  const views = snap.val() || {};
  const ids = Object.keys(views);
  await warmProfiles(ids);
  const body = ids.length
    ? ids.map(id => {
      const u = S.profileCache.get(id) || {};
      return `<div class="contact-item">
        <div class="contact-avatar">${u.avatar ? `<img src="${esc(safeImageUrl(u.avatar))}" alt="">` : '👤'}</div>
        <div class="contact-info">
          <div class="contact-name">@${esc(u.username || id.slice(0, 8))}</div>
          <div class="contact-status">${esc(dayTime(views[id]))}</div>
        </div>
      </div>`;
    }).join('')
    : '<p style="text-align:center;color:var(--text-secondary)">لا مشاهدات بعد.</p>';
  openView('contacts-view');
  $('contacts-body').innerHTML = `<h3 style="margin-bottom:12px">👁️ المشاهدات (${ids.length})</h3>${body}`;
}

/* ==================== Private chat / groups ==================== */
async function startNewPrivateChat() {
  const name = await promptAsync('اسم المستخدم (@username):', '', 'محادثة جديدة');
  if (name === null) return;
  const username = normalizeUsername(name);
  if (username === S.me.username) return toast('لا يمكنك بدء محادثة مع نفسك.', 'error');
  try {
    const idx = await db.ref(`usernames/${username}`).once('value');
    if (!idx.exists()) return toast('المستخدم غير موجود.', 'error');
    await startPrivateByUid(idx.val());
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function startPrivateByUid(target) {
  if (!target || target === uid()) return;
  if (S.blocked.has(target)) return toast('أنت حاظر هذا المستخدم.', 'error');
  const id = [uid(), target].sort().join('_');
  try {
    let snap = null;
    try { snap = await db.ref(`chats/${id}`).once('value'); } catch {}
    if (snap?.exists()) {
      const c = snap.val() || {};

      if (c.requestState === 'rejected') {
        const rejectAge = now() - Number(c.updatedAt || c.createdAt || 0);
        if (rejectAge < REQUEST_RETRY_MS) {
          const days = Math.ceil((REQUEST_RETRY_MS - rejectAge) / 86400000);
          return toast(`تم رفض الطلب. يمكنك المحاولة بعد ${days} يوم.`, 'info');
        }
        await db.ref(`chats/${id}/requestState`).remove();
        await db.ref(`chats/${id}/updatedAt`).set(SERVER);
      } else if (c.requestState === 'pending') {
        if (c.createdBy === uid()) {
          return toast('تم إرسال طلب المراسلة، بانتظار الموافقة.', 'info');
        }
        return toast('لديك طلب معلق من هذا المستخدم. اقبله من قائمة المحادثات.', 'info');
      } else {
        await db.ref(`userChats/${uid()}/${id}`).set(true);
        await db.ref(`userChats/${target}/${id}`).set(true);
        return openChat(id);
      }
    }

    await warmProfiles([target]);
    const state = isPrivilegedTarget(target) ? 'approved' : 'pending';
    await db.ref(`chats/${id}`).set({
      type: 'private',
      createdBy: uid(),
      createdAt: SERVER,
      updatedAt: SERVER,
      requestState: state,
      participants: { [uid()]: { role: 'member' }, [target]: { role: 'member' } }
    });
    await db.ref(`userChats/${uid()}/${id}`).set(true);
    if (state === 'approved') {
      await db.ref(`userChats/${target}/${id}`).set(true);
    }
    await db.ref(`chatRequests/${target}/${uid()}`).set({
      fromUid: uid(),
      toUid: target,
      status: state,
      createdAt: Date.now(),
      chatId: id
    });
    if (state === 'pending') {
      const up = {};
      makeNotification(target, 'message_request', 'طلب مراسلة جديد', `@${S.me.username} يريد مراسلتك`, up);
      if (Object.keys(up).length) await db.ref().update(up);
      return toast('تم إرسال طلب المراسلة. سيظهر للطرف الآخر.', 'success');
    }
    await openChat(id);
  } catch (e) {
    console.error('startPrivateByUid failed:', e);
    toast(
      e?.code === 'PERMISSION_DENIED'
        ? 'تعذر بدء المحادثة. تحقق من نشر قواعد v6.1.'
        : firebaseErrorMessage(e),
      'error', 5000
    );
  }
}

async function handleChatRequest(chatId, fromUid, action) {
  const req = S.chatRequests?.[fromUid];
  if (!req || req.chatId !== chatId || req.status !== 'pending') return;
  try {
    const state = action === 'approve' ? 'approved' : 'rejected';
    const updates = {};
    updates[`chatRequests/${uid()}/${fromUid}/status`] = state;
    updates[`chats/${chatId}/requestState`] = state;
    updates[`chats/${chatId}/updatedAt`] = SERVER;
    if (state === 'rejected') {
      updates[`userChats/${uid()}/${chatId}`] = null;
      updates[`userChats/${fromUid}/${chatId}`] = null;
      makeNotification(fromUid, 'message_request', 'تم رفض طلب المراسلة', `@${S.me.username} رفض طلبك`, updates);
    } else {
      updates[`userChats/${uid()}/${chatId}`] = true;
      updates[`userChats/${fromUid}/${chatId}`] = true;
      makeNotification(fromUid, 'message_request', 'تم قبول طلب المراسلة', `@${S.me.username} قبل طلبك`, updates);
    }
    await db.ref().update(updates);
    notifyTone('other');
    toast(state === 'approved' ? 'تم قبول الطلب.' : 'تم رفض الطلب.', state === 'approved' ? 'success' : 'info');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function cancelChatRequest(chatId, targetUid) {
  const id = [uid(), targetUid].sort().join('_');
  try {
    await db.ref().update({
      [`chatRequests/${targetUid}/${uid()}`]: null,
      [`chats/${id}/requestState`]: 'rejected',
      [`chats/${id}/updatedAt`]: SERVER,
      [`userChats/${uid()}/${id}`]: null,
      [`userChats/${targetUid}/${id}`]: null
    });
    toast('تم إلغاء طلب المراسلة.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

function openGroupModal() {
  S.selectedGroupUsers.clear();
  $('group-name').value = '';
  $('group-search').value = '';
  $('group-selected').innerHTML = '';
  loadGroupUsers();
  openView('group-view');
}

async function loadGroupUsers(filter = '') {
  const host = $('group-users');
  if (!host) return;
  let ids;
  if (isStaff()) {
    const idxSnap = await db.ref('usernames').once('value').catch(() => null);
    const list = idxSnap?.val() || {};
    ids = Object.values(list).filter(x => x !== uid());
  } else {
    ids = [...S.contacts].filter(x => x !== uid());
    if (!ids.length) {
      host.innerHTML = '<p style="text-align:center;color:var(--text-secondary);padding:20px">لا توجد جهات اتصال بعد. أضف أصدقاءك أولاً من قسم جهات الاتصال.</p>';
      $('group-selected').innerHTML = '';
      return;
    }
  }
  await warmProfiles(ids);
  const items = ids.map(id => S.profileCache.get(id))
    .filter(Boolean)
    .filter(p => !filter || p.username.includes(normalizeUsername(filter)))
    .slice(0, 100);
  host.innerHTML = items.map(p => `
    <div class="group-user-item ${S.selectedGroupUsers.has(p.id) ? 'selected' : ''}" data-id="${esc(p.id)}">
      <span class="group-user-avatar">${p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤'}</span>
      <b>@${esc(p.username)}</b>${p.verified ? ' ✅' : ''}
    </div>`).join('');
  qsa('.group-user-item').forEach(el => el.addEventListener('click', () => {
    const id = el.dataset.id;
    if (S.selectedGroupUsers.has(id)) S.selectedGroupUsers.delete(id);
    else S.selectedGroupUsers.add(id);
    loadGroupUsers($('group-search').value);
  }));
  $('group-selected').innerHTML = [...S.selectedGroupUsers].map(id =>
    `<span class="group-chip">@${esc(S.profileCache.get(id)?.username || id.slice(0, 6))} <button data-id="${esc(id)}">×</button></span>`
  ).join('');
  qsa('#group-selected button').forEach(b => b.onclick = () => {
    S.selectedGroupUsers.delete(b.dataset.id);
    loadGroupUsers($('group-search').value);
  });
}

async function createGroup() {
  const name = ($('group-name').value || '').trim();
  const users = [...S.selectedGroupUsers];
  if (name.length < 2) return toast('اكتب اسم المجموعة.', 'error');
  if (!users.length) return toast('أضف عضواً واحداً على الأقل.', 'error');
  const id = db.ref('chats').push().key;
  const participants = { [uid()]: { role: 'admin' } };
  users.forEach(x => participants[x] = { role: 'member' });
  const c = {
    type: 'group',
    name: name.slice(0, 30),
    createdBy: uid(),
    createdAt: SERVER,
    updatedAt: SERVER,
    participants,
    groupAdmins: { [uid()]: true }
  };
  try {
    await db.ref(`chats/${id}`).set(c);
    const idx = {};
    Object.keys(participants).forEach(x => { idx[`userChats/${x}/${id}`] = true; });
    await db.ref().update(idx);
    closeModals();
    toast('تم إنشاء المجموعة.', 'success');
    openChat(id);
  } catch (e) {
    console.error('createGroup failed:', e);
    toast(firebaseErrorMessage(e), 'error');
  }
}

/* ==================== Context menu ==================== */
function openContextMenu(x, y, id) {
  S.contextMessageId = id;
  const m = S.messageCache.get(S.activeChatId)?.find(x => x.id === id);
  if (!m) return;
  const cm = $('context-menu');
  if (!cm) return;
  const mine = m.senderId === uid();
  qsa('#context-menu [data-action="delete"]').forEach(el => el.classList.toggle('hidden', !mine));
  qsa('#context-menu [data-action="edit"]').forEach(el => el.classList.toggle('hidden', !mine || m.type !== 'text'));
  qsa('#context-menu [data-action="copy"]').forEach(el => el.classList.toggle('hidden', m.type !== 'text'));
  qsa('#context-menu [data-action="report"]').forEach(el => el.classList.toggle('hidden', mine));
  qsa('#context-menu [data-action="star"]').forEach(el => el.textContent = m.starred?.[uid()] ? '⭐ إزالة النجمة' : '⭐ نجمة');
  cm.classList.remove('hidden');
  const w = 200, h = 320;
  cm.style.left = `${Math.min(x, window.innerWidth - w - 8)}px`;
  cm.style.top = `${Math.min(y, window.innerHeight - h - 8)}px`;
  $('reaction-picker')?.classList.add('hidden');
}

async function contextAction(action) {
  const id = S.contextMessageId;
  const m = S.messageCache.get(S.activeChatId)?.find(x => x.id === id);
  if (!m) return closeContext();
  try {
    if (action === 'reply') {
      S.currentReply = m;
      S.currentEdit = null;
      updateReplyEditUI();
      $('message-input')?.focus();
    } else if (action === 'copy') {
      try { await navigator.clipboard.writeText(m.text || ''); toast('تم النسخ.', 'success'); }
      catch { toast('تعذر النسخ تلقائياً في هذا المتصفح.', 'error'); }
    } else if (action === 'star') {
      const path = `messages/${S.activeChatId}/${id}/starred/${uid()}`;
      const cur = (await db.ref(path).once('value')).val();
      await db.ref(path).set(cur ? null : true);
    } else if (action === 'edit' && m.senderId === uid() && m.type === 'text') {
      S.currentEdit = id;
      S.currentReply = null;
      $('message-input').value = m.text || '';
      updateReplyEditUI();
      updateSendButtons();
      $('message-input').focus();
    } else if (action === 'delete' && m.senderId === uid()) {
      if (await confirmAsync('حذف الرسالة للجميع؟', 'تأكيد الحذف', 'حذف', true))
        await db.ref(`messages/${S.activeChatId}/${id}/deletedForAll`).set(true);
    } else if (action === 'info') {
      showMessageInfo(m);
    } else if (action === 'report' && m.senderId !== uid()) {
      await reportMessage(m);
    } else if (action === 'forward') {
      await forwardMessage(m);
    }
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
  closeContext();
}

function closeContext() {
  $('context-menu')?.classList.add('hidden');
  $('reaction-picker')?.classList.add('hidden');
}

function updateReplyEditUI() {
  const rep = $('reply-preview'), edit = $('edit-preview');
  if (S.currentReply) {
    $('reply-sender').textContent = S.currentReply.senderId === uid()
      ? 'رد على نفسك'
      : 'رد على @' + (S.profileCache.get(S.currentReply.senderId)?.username || '');
    $('reply-text').textContent = (S.currentReply.text || (S.currentReply.fileData?.name ? attachmentIcon(S.currentReply.type) + ' ' + S.currentReply.fileData.name : '')).slice(0, 100);
    rep?.classList.remove('hidden');
  } else {
    rep?.classList.add('hidden');
  }
  if (S.currentEdit) {
    $('edit-text').textContent = 'تعديل الرسالة';
    edit?.classList.remove('hidden');
  } else {
    edit?.classList.add('hidden');
  }
}

function cancelEdit() {
  if (S.currentEdit) { const i = $('message-input'); if (i) i.value = ''; }
  S.currentEdit = null;
  updateReplyEditUI();
  updateSendButtons();
}

function showMessageInfo(m) {
  openView('msg-info');
  $('msg-info-body').innerHTML = `
    <div class="about-info">
      <div class="about-row"><span>المرسل</span><b>@${esc(S.profileCache.get(m.senderId)?.username || m.senderId.slice(0, 10))}</b></div>
      <div class="about-row"><span>الوقت</span><b>${esc(dayTime(m.timestamp))}</b></div>
      <div class="about-row"><span>النوع</span><b>${esc(m.type)}</b></div>
      <div class="about-row"><span>تم التسليم</span><b>${Object.keys(m.deliveredTo || {}).length}</b></div>
      <div class="about-row"><span>تمت القراءة</span><b>${Object.keys(m.readBy || {}).length}</b></div>
      <div class="about-row"><span>التفاعلات</span><b>${Object.keys(m.reactions || {}).length}</b></div>
    </div>`;
}

async function forwardMessage(m) {
  const target = await promptAsync('اسم مستخدم الهدف:', '', 'إعادة توجيه');
  if (target === null) return;
  const un = normalizeUsername(target);
  const snap = await db.ref(`usernames/${un}`).once('value').catch(() => null);
  if (!snap?.exists()) return toast('المستخدم غير موجود.', 'error');
  const targetUid = snap.val();
  if (targetUid === uid()) return;
  await startPrivateByUid(targetUid);
  const input = $('message-input');
  if (m.type === 'text') {
    input.value = m.text || '';
    await sendMessage();
  } else if (m.fileData) {
    S.pendingAttachment = { type: m.type, data: m.fileData };
    input.value = '';
    await sendMessage();
  }
}

function openImage(src) {
  if (!src) return;
  $('image-viewer-img').src = src;
  openView('image-viewer');
}
window.openImage = openImage;

/* ===================================================================
 * ==================== ADMIN PANEL ==================================
 * =================================================================== */

function openAdminPanel() {
  if (!isStaff()) return toast('ليس لديك صلاحية لوحة الإدارة.', 'error');
  $('admin-panel')?.classList.remove('hidden');
  renderAdminTab('dashboard');
}

function closeAdminPanel() {
  $('admin-panel')?.classList.add('hidden');
  if (S.adminUsersUnsub) {
    try { S.adminUsersUnsub(); } catch {}
    S.adminUsersUnsub = null;
  }
}

function ensureAdminTabs() {
  const host = qs('.admin-tabs');
  if (!host) return;
  const wanted = [
    ['dashboard', '📊 الرئيسية'],
    ['users', '👥 المستخدمون'],
    ['reports', '🚩 البلاغات'],
    ['stories', '⭕ القصص'],
    ['devices', '📱 الأجهزة'],
    ['chats', '💬 المحادثات'],
    ['messages', '📨 الرسائل'],
    ['logs', '📋 السجلات'],
    ['settings', '⚙️ الإعدادات']
  ];
  const visible = wanted.filter(([id]) => id !== 'settings' || isAdmin());
  host.innerHTML = visible.map(([id, t]) =>
    `<button class="admin-tab ${S.adminTab === id ? 'active' : ''}" data-atab="${id}">${t}</button>`
  ).join('');
  qsa('.admin-tab').forEach(b => b.onclick = () => {
    S.adminTab = b.dataset.atab;
    ensureAdminTabs();
    renderAdminTab(S.adminTab);
  });
}

async function renderAdminTab(tab) {
  if (!isStaff()) return closeAdminPanel();
  S.adminTab = tab;
  ensureAdminTabs();
  const sub = $('admin-subtitle');
  if (sub) sub.textContent = `${S.me.role} · @${S.me.username}`;
  const host = $('admin-content');
  if (!host) return;
  host.innerHTML = '<div class="admin-toolbar"><b>⏳ جارٍ التحميل…</b></div>';
  try {
    if (tab === 'dashboard') await adminDashboard(host);
    else if (tab === 'users') await adminUsers(host);
    else if (tab === 'reports') await adminReports(host);
    else if (tab === 'stories') await adminStories(host);
    else if (tab === 'devices') await adminDevices(host);
    else if (tab === 'chats') await adminChats(host);
    else if (tab === 'messages') await adminMessages(host);
    else if (tab === 'logs') await adminLogs(host);
    else if (tab === 'settings') await adminSettings(host);
  } catch (e) {
    host.innerHTML = `<div class="admin-card"><b>تعذر تحميل القسم</b><p>${esc(firebaseErrorMessage(e))}</p></div>`;
  }
}

function statCard(title, value, icon, color = 'blue') {
  return `<div class="admin-stat"><span class="stat-icon ${color}">${icon}</span><div><b>${esc(value)}</b><small>${esc(title)}</small></div></div>`;
}

async function adminDashboard(host) {
  const [u, c, s, r, l, w] = await Promise.all([
    db.ref('users').once('value'),
    db.ref('chats').once('value'),
    db.ref('stories').once('value'),
    db.ref('reports').orderByChild('status').equalTo('open').once('value'),
    db.ref('admin/auditLog').limitToLast(10).once('value'),
    db.ref('walletTransactions').once('value').catch(() => null)
  ]);
  const users = u.val() || {};
  const chats = c.val() || {};
  const stories = s.val() || {};
  const reports = r.val() || {};
  const logs = l.val() || {};
  const activeUsers = Object.values(users).filter(x => x.status === 'active').length;
  const bannedUsers = Object.values(users).filter(x => x.status === 'banned').length;
  const deletedUsers = Object.values(users).filter(x => x.status === 'deleted').length;
  const activeStories = Object.values(stories).filter(x => x && x.active !== false && Number(x.expiresAt) > now()).length;
  const totalCoins = Object.values(users).reduce((s, x) => s + Number(x.coins || 0), 0);

  const total = Object.keys(users).length || 1;
  const chart = `
    <div class="admin-chart">
      <div class="admin-chart-row"><span>نشط</span><div class="admin-chart-bar"><i style="width:${(activeUsers / total * 100).toFixed(1)}%;background:var(--accent)"></i></div><b>${activeUsers}</b></div>
      <div class="admin-chart-row"><span>محظور</span><div class="admin-chart-bar"><i style="width:${(bannedUsers / total * 100).toFixed(1)}%;background:var(--danger)"></i></div><b>${bannedUsers}</b></div>
      <div class="admin-chart-row"><span>محذوف</span><div class="admin-chart-bar"><i style="width:${(deletedUsers / total * 100).toFixed(1)}%;background:var(--text-secondary)"></i></div><b>${deletedUsers}</b></div>
    </div>`;

  host.innerHTML = `
    <div class="admin-dash-grid">
      ${statCard('إجمالي المستخدمين', Object.keys(users).length, '👥', 'blue')}
      ${statCard('المحادثات', Object.keys(chats).length, '💬', 'green')}
      ${statCard('قصص فعالة', activeStories, '⭕', 'orange')}
      ${statCard('بلاغات مفتوحة', Object.keys(reports).length, '🚩', 'red')}
      ${statCard('إجمالي العملات', totalCoins.toLocaleString(), '💰', 'purple')}
      ${statCard('الأجهزة', new Set(Object.values(users).map(x => x.deviceId).filter(Boolean)).size, '📱', 'cyan')}
    </div>
    <div class="admin-card">
      <h3>📈 توزيع حالات المستخدمين</h3>
      ${chart}
    </div>
    <div class="admin-card">
      <h3>⚡ إجراءات سريعة</h3>
      <div class="admin-toolbar">
        <button class="admin-btn" data-fast="users">👥 المستخدمون</button>
        <button class="admin-btn warning" data-fast="reports">🚩 البلاغات</button>
        <button class="admin-btn" data-fast="stories">⭕ القصص</button>
        ${isAdmin() ? '<button class="admin-btn" data-fast="settings">⚙️ الإعدادات</button>' : ''}
      </div>
    </div>
    <div class="admin-card">
      <h3>📋 آخر السجلات</h3>
      ${Object.entries(logs).reverse().map(([id, x]) => `
        <div class="admin-log-row">
          <b>${esc(x.action || 'event')}</b>
          <span>@${esc(x.actorUsername || x.actorId?.slice(0, 8) || '')}</span>
          <span>${esc(x.targetId?.slice(0, 12) || '')}</span>
          <small>${esc(dayTime(x.timestamp))}</small>
          <span>${esc(JSON.stringify(x.meta || {}).slice(0, 60))}</span>
        </div>`).join('') || '<p>لا توجد سجلات.</p>'}
    </div>`;
  qsa('[data-fast]').forEach(b => b.onclick = () => renderAdminTab(b.dataset.fast));
}

async function getAllUsers() {
  const snap = await db.ref('users').once('value');
  const obj = snap.val() || {};
  return Object.entries(obj)
    .map(([id, u]) => ({ ...u, id }))
    .sort((a, b) => String(a.username).localeCompare(String(b.username)));
}

async function adminUsers(host) {
  const users = await getAllUsers();
  S.adminUsers = users;
  await warmProfiles(users.map(u => u.id));

  host.innerHTML = `
    <div class="admin-toolbar">
      <input id="admin-users-search" placeholder="🔍 بحث باليوزر أو UID…" value="${esc(S.adminSearch)}">
      <select id="admin-users-filter" class="admin-select">
        <option value="all" ${S.adminUserFilter === 'all' ? 'selected' : ''}>الكل (${users.length})</option>
        <option value="active" ${S.adminUserFilter === 'active' ? 'selected' : ''}>نشط (${users.filter(u => u.status === 'active').length})</option>
        <option value="banned" ${S.adminUserFilter === 'banned' ? 'selected' : ''}>محظور (${users.filter(u => u.status === 'banned').length})</option>
        <option value="deleted" ${S.adminUserFilter === 'deleted' ? 'selected' : ''}>محذوف (${users.filter(u => u.status === 'deleted').length})</option>
        <option value="admins" ${S.adminUserFilter === 'admins' ? 'selected' : ''}>إداريون</option>
      </select>
      <button class="admin-btn" id="admin-users-refresh">🔄 تحديث</button>
      <button class="admin-btn ghost" id="admin-users-export">📤 CSV</button>
      ${isOwner() ? '<button class="admin-btn ghost" id="admin-seed-config">⚙️ تهيئة</button>' : ''}
    </div>
    <div id="admin-users-table"></div>`;

  const draw = () => {
    const q = normalizeUsername($('admin-users-search')?.value || '');
    const filter = $('admin-users-filter')?.value || 'all';
    S.adminSearch = q;
    S.adminUserFilter = filter;
    let filtered = users.filter(u => {
      if (q && ![u.username, u.id, u.role, u.status].some(v => String(v || '').toLowerCase().includes(q))) return false;
      if (filter === 'active' && u.status !== 'active') return false;
      if (filter === 'banned' && u.status !== 'banned') return false;
      if (filter === 'deleted' && u.status !== 'deleted') return false;
      if (filter === 'admins' && !['admin', 'owner', 'moderator'].includes(u.role)) return false;
      return true;
    });
    $('admin-users-table').innerHTML = adminUserTable(filtered);
    qsa('[data-admin-user]').forEach(b => b.onclick = () => adminUserModal(b.dataset.adminUser));
  };
  $('admin-users-search').oninput = draw;
  $('admin-users-filter').onchange = draw;
  $('admin-users-refresh').onclick = () => renderAdminTab('users');
  $('admin-users-export').onclick = exportUsersCSV;
  $('admin-seed-config')?.addEventListener('click', seedDefaultConfig);
  draw();
}

function roleSelectHtml(u) {
  const options = ROLES.map(r => `<option value="${r}" ${u.role === r ? 'selected' : ''}>${r}</option>`).join('');
  const locked = (u.id === S.ownerUid) || !canManageUser(u);
  return `<select class="admin-select sm" data-role-user="${esc(u.id)}" ${locked ? 'disabled' : ''}>${options}</select>`;
}

function adminUserTable(users) {
  if (!users.length) return '<div class="admin-empty"><div class="ico">👥</div><p>لا توجد نتائج مطابقة.</p></div>';
  return `<div class="admin-table-wrap"><table class="admin-table">
    <thead><tr>
      <th>المستخدم</th><th>الدور</th><th>الحالة</th><th>موثق</th><th>العملات</th><th>آخر ظهور</th><th>إجراءات</th>
    </tr></thead>
    <tbody>${users.map(u => {
      const p = S.profileCache.get(u.id) || {};
      return `<tr class="${u.status === 'banned' ? 'blocked-row' : ''}">
        <td>
          <div class="admin-user-cell">
            <div class="admin-avatar">${p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : esc((u.username || '?')[0].toUpperCase())}</div>
            <div class="admin-user-info"><b>@${esc(u.username)}</b><span>${esc(u.id.slice(0, 12))}…</span></div>
          </div>
        </td>
        <td>${roleSelectHtml(u)}</td>
        <td><span class="status ${esc(u.status)}">${esc(u.status)}</span></td>
        <td><input type="checkbox" data-verify-user="${esc(u.id)}" ${p.verified ? 'checked' : ''} ${(!isAdmin() || u.role === 'owner') ? 'disabled' : ''}></td>
        <td><b>${Number(u.coins || 0).toLocaleString()}</b></td>
        <td><small>${esc(dayTime(u.lastSeen))}</small></td>
        <td>
          <div class="action-btns">
            <button class="icon-action" data-admin-user="${esc(u.id)}" title="فتح">✏️</button>
            ${u.status === 'active' && canManageUser(u) ? `<button class="icon-action danger" data-quick-ban="${esc(u.id)}" title="حظر">🚫</button>` : ''}
            ${u.status === 'banned' ? `<button class="icon-action success" data-quick-unban="${esc(u.id)}" title="فك الحظر">✅</button>` : ''}
          </div>
        </td>
      </tr>`;
    }).join('')}</tbody></table></div>`;
}

async function adminUserModal(id) {
  const u = (S.adminUsers || []).find(x => x.id === id) || S.userCache.get(id);
  if (!u) return;
  const p = (await db.ref(`profiles/${id}`).once('value')).val() || {};
  S.profileCache.set(id, { ...p, id });
  const h = `
    <div class="modal-content" style="max-width:720px">
      <div class="modal-header"><h3>إدارة @${esc(u.username)}</h3><button class="icon-btn" id="admin-user-close">✕</button></div>
      <div class="modal-body">
        <div class="admin-user-cell" style="margin-bottom:16px">
          <div class="profile-avatar-big" style="width:80px;height:80px;margin:0">${p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤'}</div>
          <div style="flex:1">
            <h3 style="margin:0">@${esc(u.username)} ${p.verified ? '✅' : ''}</h3>
            <p style="color:var(--text-secondary);font-size:13px">${esc(p.bio || 'لا توجد نبذة')}</p>
          </div>
        </div>
        <div class="about-info">
          <div class="about-row"><span>UID</span><b style="font-size:11px">${esc(id)}</b></div>
          <div class="about-row"><span>الحالة</span><b>${esc(u.status)}</b></div>
          <div class="about-row"><span>الدور</span><b>${esc(u.role)}</b></div>
          <div class="about-row"><span>العملات</span><b>${Number(u.coins || 0)}</b></div>
          <div class="about-row"><span>الجهاز</span><b style="font-size:11px">${esc(u.deviceId || '-')}</b></div>
          <div class="about-row"><span>أنشئ</span><b>${esc(dayTime(u.createdAt))}</b></div>
          ${u.banReason ? `<div class="about-row"><span>سبب الحظر</span><b>${esc(u.banReason)}</b></div>` : ''}
        </div>
        <div class="admin-toolbar" style="margin-top:16px">
          <button class="admin-btn" id="grant-role">🎭 تعديل الدور</button>
          <button class="admin-btn" id="toggle-verify">${p.verified ? '❌ إلغاء التوثيق' : '✅ توثيق'}</button>
          <button class="admin-btn warning" id="adjust-coins">💰 تعديل العملات</button>
          ${u.status === 'banned'
            ? '<button class="admin-btn success" id="unban-user">✅ فك الحظر</button>'
            : `<button class="admin-btn danger" id="ban-user" ${!canManageUser(u) ? 'disabled' : ''}>🚫 حظر</button>`}
          ${u.status === 'deleted'
            ? '<button class="admin-btn success" id="restore-user">♻️ استعادة</button>'
            : `<button class="admin-btn danger" id="delete-user" ${(!isAdmin() || u.role === 'owner') ? 'disabled' : ''}>🗑️ حذف قابل للاستعادة</button>`}
          <button class="admin-btn ghost" id="reset-pass">🔑 إعادة تعيين كلمة المرور</button>
        </div>
      </div>
    </div>`;
  const m = document.createElement('div');
  m.className = 'modal admin-dynamic-modal';
  m.id = 'admin-dynamic-modal';
  m.innerHTML = h;
  document.body.appendChild(m);
  m.querySelector('#admin-user-close').onclick = () => m.remove();
  m.querySelector('#grant-role').onclick = () => adminChangeRole(u);
  m.querySelector('#toggle-verify').onclick = () => adminToggleVerify(u, p);
  m.querySelector('#adjust-coins').onclick = () => adminAdjustCoins(u);
  m.querySelector('#ban-user')?.addEventListener('click', () => adminBanUser(u));
  m.querySelector('#unban-user')?.addEventListener('click', () => adminUnbanUser(u));
  m.querySelector('#delete-user')?.addEventListener('click', () => adminSetDeleted(u, true));
  m.querySelector('#restore-user')?.addEventListener('click', () => adminSetDeleted(u, false));
  m.querySelector('#reset-pass')?.addEventListener('click', () => adminResetPassword(u));
}

async function adminSetRole(u, value) {
  if (!u || !ROLES.includes(value)) return false;
  if (u.id === S.ownerUid && value !== 'owner') { toast('انقل الملكية أولاً.', 'error'); return false; }
  if (!canManageUser(u) && u.id !== S.ownerUid) { toast('هذا الحساب خارج نطاق صلاحيتك.', 'error'); return false; }

  if (value === 'owner') {
    if (!isOwner()) { toast('المالك الحالي فقط يستطيع نقل الملكية.', 'error'); return false; }
    if (u.status !== 'active') { toast('لا يمكن نقل الملكية إلى حساب غير نشط.', 'error'); return false; }
    if (!await confirmAsync(`نقل ملكية النظام إلى @${u.username}؟ سيصبح حسابك admin.`, 'نقل الملكية', 'نقل', true)) return false;
    try {
      const currentOwner = S.ownerUid || uid();
      const up = {};
      up['config/ownerUid'] = u.id;
      up[`users/${u.id}/role`] = 'owner';
      up[`users/${currentOwner}/role`] = 'admin';
      await db.ref().update(up);
      await writeAudit('ownership_transferred', u.id, { from: currentOwner, to: u.id });
      await loadConfig();
      await loadCurrentAccount();
      renderOwnIdentity();
      toast('تم نقل ملكية النظام.', 'success');
      renderAdminTab('users');
      return true;
    } catch (e) {
      toast(firebaseErrorMessage(e), 'error');
      return false;
    }
  }
  if (u.id === S.ownerUid) { toast('لا يمكن تغيير دور المالك قبل نقل الملكية.', 'error'); return false; }
  if (value === 'admin' && !isOwner()) { toast('المالك الحالي فقط يستطيع منح admin.', 'error'); return false; }
  try {
    await db.ref().update({ [`users/${u.id}/role`]: value, [`profiles/${u.id}/role`]: value });
    await writeAudit('role_changed', u.id, { from: u.role, to: value });
    toast('تم تعديل الدور.', 'success');
    renderAdminTab('users');
    return true;
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
    return false;
  }
}

async function adminChangeRole(u) {
  if (!u) return;
  const value = await promptAsync(`الدور الجديد لـ @${u.username}\n(user / moderator / admin / owner)`, u.role, 'تعديل الدور');
  if (value === null) return;
  await adminSetRole(u, value);
}

async function adminToggleVerify(u, p) {
  if (!isAdmin() || u.role === 'owner') return toast('لا تملك صلاحية.', 'error');
  try {
    await db.ref(`profiles/${u.id}/verified`).set(!p.verified);
    await writeAudit('verify_changed', u.id, { verified: !p.verified });
    toast('تم تحديث التوثيق.', 'success');
    document.getElementById('admin-dynamic-modal')?.remove();
    renderAdminTab('users');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminAdjustCoins(u) {
  if (!isAdmin() || u.role === 'owner') return toast('صلاحية العملات للمالك/admin فقط.', 'error');
  const raw = await promptAsync('أدخل مقدار التعديل (مثال 50 أو -20):', '0', 'تعديل العملات');
  if (raw === null) return;
  const delta = Number(raw);
  if (!Number.isFinite(delta) || delta === 0 || !Number.isInteger(delta)) return toast('قيمة غير صالحة.', 'error');
  const snap = await db.ref(`users/${u.id}/coins`).once('value');
  const current = Number(snap.val() || 0);
  const next = current + delta;
  if (next < 0) return toast('لا يمكن أن يصبح الرصيد سالباً.', 'error');
  const txId = db.ref().push().key;
  const updates = {};
  updates[`users/${u.id}/coins`] = next;
  updates[`walletTransactions/${u.id}/${txId}`] = { delta, before: current, after: next, reason: 'admin_adjustment', actorId: uid(), timestamp: SERVER };
  try {
    await db.ref().update(updates);
    await writeAudit('coins_adjusted', u.id, { delta, before: current, after: next });
    toast(`تم تعديل الرصيد: ${delta > 0 ? '+' : ''}${delta}.`, 'success');
    document.getElementById('admin-dynamic-modal')?.remove();
    renderAdminTab('users');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminBanUser(u) {
  if (!canManageUser(u)) return toast('لا يمكنك حظر هذا الحساب.', 'error');
  const reason = await promptAsync('سبب الحظر:', 'مخالفة القواعد', 'حظر المستخدم');
  if (reason === null) return;
  try {
    await db.ref(`users/${u.id}`).update({ status: 'banned', banReason: reason.slice(0, 300), bannedAt: SERVER, bannedBy: uid() });
    await db.ref(`profiles/${u.id}/active`).set(false);
    await writeAudit('user_banned', u.id, { reason });
    toast('تم الحظر.', 'success');
    document.getElementById('admin-dynamic-modal')?.remove();
    renderAdminTab('users');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminUnbanUser(u) {
  if (!canManageUser(u)) return;
  try {
    await db.ref(`users/${u.id}`).update({ status: 'active', banReason: null, bannedAt: null, bannedBy: null });
    await db.ref(`profiles/${u.id}/active`).set(true);
    await writeAudit('user_unbanned', u.id);
    toast('تم فك الحظر.', 'success');
    document.getElementById('admin-dynamic-modal')?.remove();
    renderAdminTab('users');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminSetDeleted(u, deleted) {
  if (!isAdmin() || u.role === 'owner') return toast('الحسابات المحمية لا يمكن حذفها.', 'error');
  const ok = await confirmAsync(
    deleted ? `حذف @${u.username}؟ يمكن استعادته لاحقاً.` : `استعادة @${u.username}؟`,
    deleted ? 'حذف قابل للاستعادة' : 'استعادة',
    deleted ? 'حذف' : 'استعادة',
    deleted
  );
  if (!ok) return;
  try {
    await db.ref(`users/${u.id}`).update({
      status: deleted ? 'deleted' : 'active',
      deletedAt: deleted ? SERVER : null,
      deletedBy: deleted ? uid() : null
    });
    await db.ref(`profiles/${u.id}/active`).set(!deleted);
    await writeAudit(deleted ? 'user_soft_deleted' : 'user_restored', u.id);
    toast(deleted ? 'تم الحذف القابل للاستعادة.' : 'تمت الاستعادة.', 'success');
    document.getElementById('admin-dynamic-modal')?.remove();
    renderAdminTab('users');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminResetPassword(u) {
  toast('لا يمكن إعادة تعيين كلمة المرور من العميل؛ استخدم Firebase Console.', 'info', 5000);
}

function exportUsersCSV() {
  const rows = [['username', 'uid', 'role', 'status', 'coins', 'deviceId', 'createdAt', 'lastSeen']];
  (S.adminUsers || []).forEach(u => rows.push([
    u.username, u.id, u.role, u.status, u.coins || 0, u.deviceId || '', u.createdAt || '', u.lastSeen || ''
  ]));
  const csv = rows.map(r => r.map(x => `"${String(x).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `users-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

async function adminReports(host) {
  const snap = await db.ref('reports').orderByChild('status').equalTo('open').once('value');
  const reports = snap.val() || {};
  host.innerHTML = `
    <div class="admin-toolbar">
      <button class="admin-btn" id="reports-refresh">🔄 تحديث</button>
      <span class="admin-toolbar-info">${Object.keys(reports).length} بلاغ مفتوح</span>
    </div>
    <div class="admin-table-wrap"><table class="admin-table">
      <thead><tr><th>النوع</th><th>الهدف</th><th>المبلّغ</th><th>السبب</th><th>الوقت</th><th>إجراء</th></tr></thead>
      <tbody>${Object.entries(reports).map(([id, r]) => `
        <tr>
          <td>${esc(r.targetType)}</td>
          <td><code style="font-size:11px">${esc((r.targetUid || r.storyId || `${r.chatId || ''}/${r.messageId || ''}`).slice(0, 16))}</code></td>
          <td>@${esc(r.reporterUsername || r.reporterId?.slice(0, 8) || '')}</td>
          <td>${esc((r.reason || '').slice(0, 60))}</td>
          <td><small>${esc(dayTime(r.createdAt))}</small></td>
          <td><button class="admin-btn sm" data-report="${esc(id)}">🔍 مراجعة</button></td>
        </tr>`).join('') || '<tr><td colspan="6" style="text-align:center">لا بلاغات.</td></tr>'}
      </tbody></table></div>`;
  $('reports-refresh').onclick = () => renderAdminTab('reports');
  qsa('[data-report]').forEach(b => b.onclick = () => reviewReport(b.dataset.report, reports[b.dataset.report]));
}

async function reviewReport(id, r) {
  const action = await promptAsync(
    'الإجراء: resolve / dismiss / ban / delete',
    'resolve', 'مراجعة البلاغ'
  );
  if (action === null) return;
  if (!['resolve', 'dismiss', 'ban', 'delete'].includes(action)) return toast('إجراء غير صالح.', 'error');
  try {
    if (action === 'ban' && r.targetUid) {
      const u = (await db.ref(`users/${r.targetUid}`).once('value')).val() || {};
      if (canManageUser({ ...u, id: r.targetUid })) {
        await db.ref(`users/${r.targetUid}`).update({ status: 'banned', banReason: `بلاغ ${id}`, bannedBy: uid(), bannedAt: SERVER });
        await db.ref(`profiles/${r.targetUid}/active`).set(false);
      }
    }
    if (action === 'delete' && r.targetUid && isAdmin()) {
      const u = (await db.ref(`users/${r.targetUid}`).once('value')).val() || {};
      if (u.role !== 'owner') {
        await db.ref(`users/${r.targetUid}`).update({ status: 'deleted', deletedBy: uid(), deletedAt: SERVER });
        await db.ref(`profiles/${r.targetUid}/active`).set(false);
      }
    }
    if (action === 'delete' && r.chatId && r.messageId) {
      await db.ref(`messages/${r.chatId}/${r.messageId}/deletedForAll`).set(true);
    }
    if (action === 'delete' && r.storyId) {
      await db.ref(`stories/${r.storyId}`).update({ active: false, deletedAt: SERVER, deletedBy: uid() });
    }
    await db.ref(`reports/${id}`).update({
      status: action === 'dismiss' ? 'dismissed' : 'resolved',
      reviewedBy: uid(),
      reviewedAt: SERVER,
      action
    });
    await writeAudit('report_reviewed', id, { action });
    toast('تمت معالجة البلاغ.', 'success');
    renderAdminTab('reports');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminStories(host) {
  const snap = await db.ref('stories').once('value');
  const stories = snap.val() || {};
  const rows = Object.entries(stories)
    .map(([id, s]) => ({ ...s, id }))
    .sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
  await warmProfiles(rows.map(s => s.userId));
  const active = rows.filter(s => s.active !== false && Number(s.expiresAt) > now()).length;
  host.innerHTML = `
    <div class="admin-toolbar">
      <button class="admin-btn" id="stories-refresh">🔄 تحديث</button>
      <button class="admin-btn warning" id="purge-expired">🧹 تنظيف المنتهية</button>
      <span class="admin-toolbar-info">${active} نشطة · ${rows.length} إجمالي</span>
    </div>
    <div class="admin-table-wrap"><table class="admin-table">
      <thead><tr><th>المالك</th><th>النوع</th><th>النشر</th><th>الانتهاء</th><th>المشاهدات</th><th>الحالة</th><th>إجراء</th></tr></thead>
      <tbody>${rows.map(s => {
        const expired = Number(s.expiresAt) <= now();
        const activeRow = s.active !== false && !expired;
        return `<tr>
          <td>@${esc(S.profileCache.get(s.userId)?.username || s.userId.slice(0, 8))}</td>
          <td>${s.type === 'image' ? '🖼️' : '📝'}</td>
          <td><small>${esc(dayTime(s.createdAt))}</small></td>
          <td><small>${esc(dayTime(s.expiresAt))}</small></td>
          <td><button class="admin-btn sm" data-story-views="${esc(s.id)}">👁️ عرض</button></td>
          <td><span class="status ${activeRow ? 'active' : 'deleted'}">${activeRow ? 'نشطة' : 'منتهية'}</span></td>
          <td>
            ${activeRow
              ? `<button class="admin-btn danger sm" data-story-delete="${esc(s.id)}">🗑️</button>`
              : (s.active === false && !expired ? `<button class="admin-btn sm" data-story-restore="${esc(s.id)}">♻️</button>` : '—')}
          </td>
        </tr>`;
      }).join('')}</tbody></table></div>`;
  $('stories-refresh').onclick = () => renderAdminTab('stories');
  $('purge-expired').onclick = purgeExpiredStories;
  qsa('[data-story-delete]').forEach(b => b.onclick = () => adminSetStoryDeleted(b.dataset.storyDelete, true));
  qsa('[data-story-restore]').forEach(b => b.onclick = () => adminSetStoryDeleted(b.dataset.storyRestore, false));
  qsa('[data-story-views]').forEach(b => b.onclick = () => showStoryViews(b.dataset.storyViews));
}

async function adminSetStoryDeleted(id, deleted) {
  try {
    const snap = await db.ref(`stories/${id}`).once('value');
    const s = snap.val() || {};
    if (deleted) {
      await db.ref(`stories/${id}`).update({ active: false, deletedAt: SERVER, deletedBy: uid() });
    } else {
      if (Number(s.expiresAt || 0) <= now()) return toast('انتهت المدة ولا يمكن استعادتها.', 'error');
      await db.ref(`stories/${id}`).update({ active: true, deletedAt: null, deletedBy: null });
    }
    await writeAudit(deleted ? 'story_deleted' : 'story_restored', id);
    toast(deleted ? 'تم الحذف.' : 'تمت الاستعادة.', 'success');
    renderAdminTab('stories');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function purgeExpiredStories() {
  const snap = await db.ref('stories').once('value');
  const obj = snap.val() || {};
  const updates = {};
  Object.entries(obj).forEach(([id, s]) => {
    if (Number(s.expiresAt || 0) < now() - 7 * 864e5 && s.active !== false) updates[`stories/${id}/active`] = false;
  });
  if (Object.keys(updates).length) await db.ref().update(updates);
  toast('تم التنظيف.', 'success');
  renderAdminTab('stories');
}

async function showStoryViews(id) {
  const snap = await db.ref(`storyViews/${id}`).once('value');
  const views = snap.val() || {};
  const ids = Object.keys(views);
  await warmProfiles(ids);
  const body = ids.length
    ? ids.map(uid2 => {
      const u = S.profileCache.get(uid2) || {};
      return `<div class="contact-item">
        <div class="contact-avatar">${u.avatar ? `<img src="${esc(safeImageUrl(u.avatar))}" alt="">` : '👤'}</div>
        <div class="contact-info">
          <div class="contact-name">@${esc(u.username || uid2.slice(0, 8))}</div>
          <div class="contact-status">${esc(dayTime(views[uid2]))}</div>
        </div>
      </div>`;
    }).join('')
    : '<p style="text-align:center;color:var(--text-secondary)">لا مشاهدات.</p>';
  openView('contacts-view');
  $('contacts-body').innerHTML = `<h3 style="margin-bottom:12px">👁️ المشاهدات (${ids.length})</h3>${body}`;
}

async function adminDevices(host) {
  const users = await getAllUsers();
  const byDevice = new Map();
  users.forEach(u => {
    if (!u.deviceId) return;
    if (!byDevice.has(u.deviceId)) byDevice.set(u.deviceId, []);
    byDevice.get(u.deviceId).push(u);
  });
  host.innerHTML = `
    <div class="admin-toolbar">
      <button class="admin-btn" id="devices-refresh">🔄 تحديث</button>
      <span class="admin-toolbar-info">${byDevice.size} جهاز</span>
    </div>
    <div class="admin-table-wrap"><table class="admin-table">
      <thead><tr><th>معرف الجهاز</th><th>الحسابات</th><th>الحالات</th><th>إجراء</th></tr></thead>
      <tbody>${[...byDevice.entries()].sort((a, b) => b[1].length - a[1].length).map(([d, list]) => `
        <tr>
          <td><code style="font-size:11px">${esc(d.slice(0, 20))}…</code></td>
          <td><b>${list.length}</b><br><small>${list.map(u => '@' + u.username).join(', ')}</small></td>
          <td>${[...new Set(list.map(u => u.status))].map(s => `<span class="status ${esc(s)}">${esc(s)}</span>`).join(' ')}</td>
          <td><button class="admin-btn sm" data-device="${esc(d)}">🔍 تفاصيل</button></td>
        </tr>`).join('')}</tbody></table></div>`;
  $('devices-refresh').onclick = () => renderAdminTab('devices');
  qsa('[data-device]').forEach(b => b.onclick = () => {
    const list = byDevice.get(b.dataset.device) || [];
    openView('contacts-view');
    $('contacts-body').innerHTML = `<h3 style="margin-bottom:12px">📱 حسابات الجهاز</h3>` +
      (list.map(u => `<div class="contact-item"><div class="contact-info"><div class="contact-name">@${esc(u.username)}</div><div class="contact-status">${esc(u.status)} · ${esc(u.id)}</div></div></div>`).join('')
      || '<p>لا حسابات.</p>');
  });
}

async function adminChats(host) {
  const snap = await db.ref('chats').once('value');
  const chats = snap.val() || {};
  host.innerHTML = `
    <div class="admin-toolbar">
      <input id="admin-chat-search" placeholder="🔍 بحث بالاسم أو ID">
      <button class="admin-btn" id="admin-chat-refresh">🔄 تحديث</button>
      <span class="admin-toolbar-info">${Object.keys(chats).length} محادثة</span>
    </div>
    <div id="admin-chat-table"></div>`;
  const draw = () => {
    const q = ($('admin-chat-search').value || '').toLowerCase();
    const rows = Object.entries(chats).filter(([id, c]) => !q || id.toLowerCase().includes(q) || String(c.name || '').toLowerCase().includes(q));
    $('admin-chat-table').innerHTML = `<div class="admin-table-wrap"><table class="admin-table">
      <thead><tr><th>ID</th><th>النوع</th><th>الاسم</th><th>الأعضاء</th><th>آخر تحديث</th><th>إجراء</th></tr></thead>
      <tbody>${rows.map(([id, c]) => `
        <tr>
          <td><code title="${esc(id)}">${esc(id.slice(0, 14))}…</code></td>
          <td>${c.type === 'group' ? '👥' : '💬'}</td>
          <td>${esc(c.name || '—')}</td>
          <td>${Object.keys(c.participants || {}).length}</td>
          <td><small>${esc(dayTime(c.updatedAt))}</small></td>
          <td>
            <button class="admin-btn sm" data-open-admin-chat="${esc(id)}">📖</button>
            ${c.deletedAt
              ? `<button class="admin-btn sm" data-restore-admin-chat="${esc(id)}">♻️</button>`
              : `<button class="admin-btn danger sm" data-delete-admin-chat="${esc(id)}">🗑️</button>`}
          </td>
        </tr>`).join('')}</tbody></table></div>`;
  };
  draw();
  $('admin-chat-search').oninput = draw;
  $('admin-chat-refresh').onclick = () => renderAdminTab('chats');
  qsa('[data-open-admin-chat]').forEach(b => b.onclick = () => openChatAsAdmin(b.dataset.openAdminChat));
  qsa('[data-delete-admin-chat]').forEach(b => b.onclick = () => adminSetChatDeleted(b.dataset.deleteAdminChat, true));
  qsa('[data-restore-admin-chat]').forEach(b => b.onclick = () => adminSetChatDeleted(b.dataset.restoreAdminChat, false));
}

async function openChatAsAdmin(id) {
  try {
    const s = await db.ref(`messages/${id}`).orderByChild('timestamp').limitToLast(30).once('value');
    const arr = [];
    s.forEach(x => { arr.push({ ...x.val(), id: x.key }); });
    await warmProfiles(arr.map(m => m.senderId));
    const body = arr.map(m => `
      <div class="admin-log-row">
        <b>@${esc(S.profileCache.get(m.senderId)?.username || m.senderId.slice(0, 8))}</b>
        <span>${esc(m.type || 'text')}</span>
        <small>${esc(dayTime(m.timestamp))}</small>
        <span>${esc((m.text || m.fileData?.name || '').slice(0, 80))}</span>
        <span>${m.deletedForAll ? '<i style="color:var(--danger)">محذوفة</i>' : ''}</span>
      </div>`).join('') || '<p>لا رسائل.</p>';
    openView('contacts-view');
    $('contacts-body').innerHTML = `<h3>💬 آخر 30 رسالة — ${esc(id.slice(0, 20))}</h3>${body}`;
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminSetChatDeleted(id, deleted) {
  if (!isAdmin()) return;
  const ok = await confirmAsync(
    deleted ? 'حذف المحادثة مع إبقاء نسخة قابلة للاستعادة؟' : 'استعادة المحادثة؟',
    deleted ? 'حذف' : 'استعادة',
    deleted ? 'حذف' : 'استعادة',
    deleted
  );
  if (!ok) return;
  try {
    await db.ref(`chats/${id}`).update({ deletedAt: deleted ? SERVER : null, deletedBy: deleted ? uid() : null });
    await writeAudit(deleted ? 'chat_soft_deleted' : 'chat_restored', id);
    toast(deleted ? 'تم الحذف.' : 'تمت الاستعادة.', 'success');
    renderAdminTab('chats');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminMessages(host) {
  host.innerHTML = `
    <div class="admin-card">
      <h3>🔎 بحث الرسائل</h3>
      <p style="color:var(--text-secondary);font-size:13px">RTDB ليس محرك بحث نصي — أدخل معرف المحادثة لعرض آخر 200 رسالة.</p>
      <div class="admin-toolbar">
        <input id="admin-message-chat" placeholder="Chat ID">
        <button class="admin-btn" id="admin-message-load">📥 تحميل</button>
      </div>
      <div id="admin-message-results"></div>
    </div>`;
  $('admin-message-load').onclick = async () => {
    const id = $('admin-message-chat').value.trim();
    if (!id) return;
    try {
      const s = await db.ref(`messages/${id}`).orderByChild('timestamp').limitToLast(200).once('value');
      const arr = [];
      s.forEach(x => { arr.push({ ...x.val(), id: x.key }); });
      await warmProfiles(arr.map(m => m.senderId));
      $('admin-message-results').innerHTML = arr.reverse().map(m => `
        <div class="admin-log-row">
          <b>@${esc(S.profileCache.get(m.senderId)?.username || m.senderId.slice(0, 8))}</b>
          <span>${esc(m.type || 'text')}</span>
          <small>${esc(dayTime(m.timestamp))}</small>
          <span>${esc((m.text || m.fileData?.name || '').slice(0, 100))}</span>
          <span>${m.deletedForAll
            ? `<button class="admin-btn sm" data-restore-message="${esc(id + '/' + m.id)}">♻️</button>`
            : `<button class="admin-btn danger sm" data-delete-message="${esc(id + '/' + m.id)}">🗑️</button>`}</span>
        </div>`).join('') || '<p>لا نتائج.</p>';
      qsa('[data-restore-message]').forEach(b => b.onclick = () => adminSetMessageDeleted(b.dataset.restoreMessage, false));
      qsa('[data-delete-message]').forEach(b => b.onclick = () => adminSetMessageDeleted(b.dataset.deleteMessage, true));
    } catch (e) {
      $('admin-message-results').innerHTML = `<p>${esc(firebaseErrorMessage(e))}</p>`;
    }
  };
}

async function adminSetMessageDeleted(path, deleted) {
  if (!isAdmin()) return;
  const [chatId, messageId] = String(path).split('/');
  if (!chatId || !messageId) return;
  try {
    await db.ref(`messages/${chatId}/${messageId}/deletedForAll`).set(!!deleted);
    await writeAudit(deleted ? 'message_deleted' : 'message_restored', path);
    toast(deleted ? 'تم الحذف.' : 'تمت الاستعادة.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function adminLogs(host) {
  const snap = await db.ref('admin/auditLog').limitToLast(300).once('value');
  const logs = Object.values(snap.val() || {}).sort((a, b) => Number(b.timestamp || 0) - Number(a.timestamp || 0));
  const actions = [...new Set(logs.map(l => l.action))].sort();
  const filtered = S.adminLogFilter === 'all' ? logs : logs.filter(l => l.action === S.adminLogFilter);
  host.innerHTML = `
    <div class="admin-toolbar">
      <button class="admin-btn" id="admin-logs-refresh">🔄 تحديث</button>
      <select id="admin-logs-filter" class="admin-select">
        <option value="all" ${S.adminLogFilter === 'all' ? 'selected' : ''}>كل الأحداث (${logs.length})</option>
        ${actions.map(a => `<option value="${esc(a)}" ${S.adminLogFilter === a ? 'selected' : ''}>${esc(a)} (${logs.filter(l => l.action === a).length})</option>`).join('')}
      </select>
    </div>
    <div class="admin-card">${filtered.map(x => `
      <div class="admin-log-row">
        <b>${esc(x.action)}</b>
        <span>@${esc(x.actorUsername || x.actorId?.slice(0, 8) || '')}</span>
        <span>${esc(x.targetId?.slice(0, 16) || '')}</span>
        <small>${esc(dayTime(x.timestamp))}</small>
        <span>${esc(JSON.stringify(x.meta || {}))}</span>
      </div>`).join('') || '<p>لا سجلات.</p>'}</div>`;
  $('admin-logs-refresh').onclick = () => renderAdminTab('logs');
  $('admin-logs-filter').onchange = e => { S.adminLogFilter = e.target.value; renderAdminTab('logs'); };
}

async function adminSettings(host) {
  if (!isAdmin()) { host.innerHTML = '<div class="admin-card"><p>قراءة الإعدادات تتطلب صلاحية admin.</p></div>'; return; }
  const s = (await db.ref('config/app').once('value')).val() || {};
  host.innerHTML = `
    <div class="admin-card">
      <h3>⚙️ الإعدادات العامة</h3>
      <div class="admin-form">
        <label>اسم التطبيق<input id="set-app-name" value="${esc(s.appName || 'ChatApp')}"></label>
        <label>أقصى حسابات للجهاز<input id="set-device-limit" type="number" min="1" max="20" value="${Number(s.maxAccountsPerDevice || 3)}"></label>
        <label class="switch-row"><span>السماح بالتسجيلات الجديدة</span><input id="set-reg" type="checkbox" ${s.allowRegistration !== false ? 'checked' : ''}></label>
        <button class="admin-btn" id="set-save">💾 حفظ</button>
      </div>
      <hr>
      <p style="font-size:13px;color:var(--text-secondary)">مالك النظام: <code>${esc(S.ownerUid || 'غير مُعيّن')}</code></p>
      <p style="font-size:13px;color:var(--text-secondary)">الإصدار: ${APP_VERSION} · مخطط: ${STORE_VERSION}</p>
    </div>`;
  $('set-save').onclick = async () => {
    const next = {
      ...s,
      appName: $('set-app-name').value.trim().slice(0, 50) || 'ChatApp',
      maxAccountsPerDevice: Math.max(1, Math.min(20, Number($('set-device-limit').value) || 3)),
      allowRegistration: $('set-reg').checked,
      schemaVersion: STORE_VERSION,
      updatedAt: SERVER,
      updatedBy: uid()
    };
    try {
      await db.ref('config/app').set(next);
      await writeAudit('app_settings_changed', 'config/app');
      toast('تم الحفظ.', 'success');
      await loadConfig();
    } catch (e) {
      toast(firebaseErrorMessage(e), 'error');
    }
  };
}

async function seedDefaultConfig() {
  if (!isOwner()) return;
  try {
    await db.ref('config/app').update({ appName: 'ChatApp', maxAccountsPerDevice: 3, allowRegistration: true, schemaVersion: STORE_VERSION });
    await writeAudit('config_seeded', 'config/app');
    toast('تمت التهيئة.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function writeAudit(action, targetId = '', meta = {}) {
  if (!uid()) return;
  const ref = db.ref('admin/auditLog').push();
  return ref.set({ actorId: uid(), actorUsername: S.me?.username || '', action, targetId, meta, timestamp: SERVER });
}

/* ===================================================================
 * ==================== PROFILES / CONTACTS ==========================
 * =================================================================== */

async function openUserProfile(targetId) {
  if (!targetId) return;

  const isMe = targetId === uid();
  const pSnap = await db.ref(`profiles/${targetId}`).once('value').catch(() => null);
  if (!pSnap?.exists() && !isMe) return toast('المستخدم غير موجود.', 'error');

  let p = pSnap?.val() || (S.me ? { ...S.me } : {});
  p.id = targetId;
  S.profileCache.set(targetId, p);

  const isTargetOwner = targetId === S.ownerUid;
  const isTargetStaff = ['admin', 'moderator'].includes(p.role);

  const [fSnap, followersSnap, followingSnap, uSnap] = await Promise.all([
    isMe ? null : db.ref(`following/${uid()}/${targetId}`).once('value').catch(() => null),
    db.ref(`followers/${targetId}`).once('value').catch(() => null),
    db.ref(`following/${targetId}`).once('value').catch(() => null),
    (isStaff() || isMe) ? db.ref(`users/${targetId}`).once('value').catch(() => null) : null
  ]);

  const follows = !!fSnap?.val();
  const followersCount = Object.keys(followersSnap?.val() || {}).length;
  const followingCount = Object.keys(followingSnap?.val() || {}).length;
  const uNode = uSnap?.val() || {};

  $('up-title').textContent = p.displayName ? `${p.displayName} · @${p.username || 'user'}` : '@' + (p.username || 'user');
  const coverEl = $('up-cover');
  if (coverEl) coverEl.style.background = p.cover ? `url(${safeImageUrl(p.cover)}) center/cover no-repeat` : '';

  const avatarEl = $('up-avatar');
  avatarEl.innerHTML = p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤';

  $('up-badges').innerHTML = userBadgesHtml(targetId, 'lg');

  const bioEl = $('up-bio');
  const bioText = String(p.bio || '').trim();
  bioEl.textContent = bioText || (isMe ? 'أضف نبذة عنك من الإعدادات.' : 'لا توجد نبذة.');
  bioEl.classList.toggle('empty', !bioText);

  const meta = [];
  if (uNode.lastSeen && (isMe || uNode.showLastSeen !== false))
    meta.push(`<span>🕐 ${esc(relativeTime(uNode.lastSeen))}</span>`);
  if (uNode.createdAt) {
    const days = Math.max(1, Math.floor((now() - uNode.createdAt) / 86400000));
    meta.push(`<span>📅 عضو منذ ${days} يوم</span>`);
  }
  $('up-meta').innerHTML = meta.join('');

  $('up-stats').innerHTML = `
    <div class="profile-stat-cell"><b>${followersCount}</b><span>متابع</span></div>
    <div class="profile-stat-cell"><b>${followingCount}</b><span>يتابع</span></div>
    <div class="profile-stat-cell"><b>${uNode.coins != null ? Number(uNode.coins).toLocaleString() : '—'}</b><span>نقاط</span></div>
  `;

  const actions = $('up-actions');
  if (isMe) {
    actions.innerHTML = `
      <button class="profile-action primary" id="up-edit-self">✏️ تعديل ملفي</button>
      <button class="profile-action" id="up-goto-settings">⚙️ الإعدادات</button>
    `;
    $('up-edit-self').onclick = () => { closeModals(); renderProfileModal(); openView('profile-view'); };
    $('up-goto-settings').onclick = () => { closeModals(); loadSettingsUI(); openView('settings-view'); };
  } else {
    const blocked = S.blocked.has(targetId);
    actions.innerHTML = `
      <button class="profile-action ${follows ? '' : 'primary'}" id="up-follow">
        ${follows ? '✓ تتابعه' : '+ متابعة'}
      </button>
      <button class="profile-action" id="up-chat">💬 مراسلة</button>
      <button class="profile-action icon-only" id="up-more" title="المزيد">⋯</button>
    `;
    $('up-follow').onclick = () => toggleFollow(targetId, () => openUserProfile(targetId));
    $('up-chat').onclick = () => { closeModals(); startPrivateByUid(targetId); };
    $('up-more').onclick = e => {
      e.stopPropagation();
      showProfileMenu(e.clientX, e.clientY, targetId, p, blocked, isTargetOwner);
    };
  }

  qsa('#up-tabs .ptab').forEach(t => {
    t.onclick = () => {
      qsa('#up-tabs .ptab').forEach(x => x.classList.toggle('active', x === t));
      renderProfileTab(t.dataset.ptab, targetId);
    };
  });

  qsa('#up-tabs .ptab').forEach(x => x.classList.toggle('active', x.dataset.ptab === 'about'));
  renderProfileTab('about', targetId);

  openView('user-profile-view');
}

function showProfileMenu(x, y, targetId, p, blocked, isOwnerTarget) {
  document.getElementById('profile-menu-popup')?.remove();

  const items = [];
  if (!isOwnerTarget) {
    items.push({ id: 'block', icon: '🚫', text: blocked ? 'إلغاء الحظر' : 'حظر المستخدم', danger: true });
    items.push({ id: 'report', icon: '🚩', text: 'إبلاغ', danger: true });
  }
  items.push({ id: 'copy-id', icon: '📋', text: 'نسخ معرف المستخدم' });

  const menu = document.createElement('div');
  menu.id = 'profile-menu-popup';
  menu.className = 'context-menu';
  menu.style.position = 'fixed';
  menu.style.zIndex = '900';
  menu.innerHTML = items.map(i =>
    `<button data-pm="${i.id}" class="${i.danger ? 'danger' : ''}">${i.icon} ${i.text}</button>`
  ).join('');

  document.body.appendChild(menu);
  const w = menu.offsetWidth || 200;
  const h = menu.offsetHeight || 160;
  menu.style.left = `${Math.min(x, window.innerWidth - w - 8)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - h - 8)}px`;

  const close = () => menu.remove();
  setTimeout(() => {
    const off = ev => {
      if (!menu.contains(ev.target)) { close(); document.removeEventListener('click', off); }
    };
    document.addEventListener('click', off);
  }, 50);

  menu.querySelectorAll('[data-pm]').forEach(b => b.onclick = async () => {
    const a = b.dataset.pm;
    close();
    if (a === 'block') await toggleBlock(targetId, () => openUserProfile(targetId));
    else if (a === 'report') await reportUser(targetId);
    else if (a === 'copy-id') {
      try { await navigator.clipboard.writeText(targetId); toast('تم نسخ المعرف.', 'success'); }
      catch { toast('تعذر النسخ.', 'error'); }
    }
  });
}

async function renderProfileTab(tab, targetId) {
  const host = $('up-tab-content');
  if (!host) return;
  host.innerHTML = '<div class="profile-empty">⏳ جارٍ التحميل…</div>';

  try {
    if (tab === 'about') {
      const p = S.profileCache.get(targetId) || {};
      const uSnap = (isStaff() || targetId === uid()) ? await db.ref(`users/${targetId}`).once('value').catch(() => null) : null;
      const u = uSnap?.val() || {};
      const rows = [];
      rows.push(`<div class="about-row"><span>اسم المستخدم</span><b>@${esc(p.username || '—')}</b></div>`);
      rows.push(`<div class="about-row"><span>المعرف</span><b style="font-size:11px">${esc(targetId.slice(0, 16))}…</b></div>`);
      if (p.verified) rows.push(`<div class="about-row"><span>التوثيق</span><b style="color:#3b82f6">✅ موثق</b></div>`);
      if (targetId === S.ownerUid) rows.push(`<div class="about-row"><span>الحساب</span><b>👑 مالك التطبيق</b></div>`);
      if (u.role && u.role !== 'user') rows.push(`<div class="about-row"><span>الدور</span><b>${esc(u.role)}</b></div>`);
      if (u.createdAt) rows.push(`<div class="about-row"><span>تاريخ الانضمام</span><b>${esc(dayTime(u.createdAt))}</b></div>`);
      if (u.lastSeen && (targetId === uid() || u.showLastSeen !== false))
        rows.push(`<div class="about-row"><span>آخر ظهور</span><b>${esc(dayTime(u.lastSeen))}</b></div>`);
      if (p.bio) rows.push(`<div class="about-row"><span>النبذة</span><b>${esc(p.bio)}</b></div>`);

      host.innerHTML = `<div class="about-info">${rows.join('')}</div>`;
    } else if (tab === 'followers' || tab === 'following') {
      const path = tab === 'followers' ? `followers/${targetId}` : `following/${targetId}`;
      const snap = await db.ref(path).once('value').catch(() => null);
      const ids = Object.keys(snap?.val() || {});
      if (!ids.length) {
        host.innerHTML = `<div class="profile-empty">${tab === 'followers' ? 'لا يوجد متابعون بعد.' : 'لا يتابع أحداً بعد.'}</div>`;
        return;
      }
      await warmProfiles(ids);
      host.innerHTML = ids.map(id => {
        const u = S.profileCache.get(id) || {};
        return `<div class="profile-list-item" data-uid="${esc(id)}">
          <div class="profile-list-avatar">${u.avatar ? `<img src="${esc(safeImageUrl(u.avatar))}" alt="">` : '👤'}</div>
          <div class="profile-list-info">
            <b>@${esc(u.username || id.slice(0, 8))}${u.verified ? ' ✓' : ''}</b>
            <span>${esc(u.bio || '')}</span>
          </div>
        </div>`;
      }).join('');
      host.querySelectorAll('[data-uid]').forEach(el => {
        el.onclick = () => { closeModals(); openUserProfile(el.dataset.uid); };
      });
    }
  } catch (e) {
    host.innerHTML = `<div class="profile-empty">تعذر التحميل.</div>`;
  }
}

async function toggleFollow(target, onDone) {
  try {
    const exists = (await db.ref(`following/${uid()}/${target}`).once('value')).exists();
    const up = {};
    if (exists) {
      up[`following/${uid()}/${target}`] = null;
      up[`followers/${target}/${uid()}`] = null;
    } else {
      up[`following/${uid()}/${target}`] = true;
      up[`followers/${target}/${uid()}`] = true;
      const nid = db.ref(`notifications/${target}`).push().key;
      up[`notifications/${target}/${nid}`] = {
        type: 'follow',
        from: uid(),
        title: 'متابعة جديدة',
        body: `@${S.me.username} بدأ متابعتك`,
        createdAt: SERVER,
        read: false
      };
    }
    await db.ref().update(up);
    toast(exists ? 'تم إلغاء المتابعة.' : 'تمت المتابعة.', 'success');
    if (typeof onDone === 'function') onDone();
    else closeModals();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function toggleBlock(target, onDone) {
  const exists = S.blocked.has(target);
  try {
    await db.ref(`users/${uid()}/blocked/${target}`).set(exists ? null : true);
    exists ? S.blocked.delete(target) : S.blocked.add(target);
    toast(exists ? 'تم إلغاء الحظر.' : 'تم الحظر.', 'success');
    if (typeof onDone === 'function') onDone();
    else closeModals();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function reportUser(target) {
  const reason = await promptAsync('سبب البلاغ:', 'إساءة أو محتوى مخالف', 'إبلاغ');
  if (reason === null) return;
  await createReport({ targetType: 'user', targetUid: target, reason: reason.slice(0, 300) });
}

async function reportMessage(m) {
  const reason = await promptAsync('سبب الإبلاغ:', 'محتوى مخالف', 'إبلاغ');
  if (reason === null) return;
  await createReport({ targetType: 'message', chatId: S.activeChatId, messageId: m.id, reason: reason.slice(0, 300) });
}

async function createReport(payload) {
  const id = db.ref('reports').push().key;
  try {
    await db.ref(`reports/${id}`).set({
      ...payload,
      reporterId: uid(),
      reporterUsername: S.me.username,
      status: 'open',
      createdAt: SERVER
    });
    toast('تم إرسال البلاغ للمراجعة.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

/* ==================== Contacts ==================== */
async function renderContacts() {
  const ids = [...S.contacts];
  await warmProfiles(ids);
  const host = $('contacts-body');
  if (!host) return;
  host.innerHTML = `
    <div class="admin-toolbar">
      <button class="admin-btn" id="contacts-refresh">🔄 تحديث</button>
      <button class="admin-btn" id="contacts-add">➕ إضافة</button>
    </div>
    ${ids.map(id => {
      const p = S.profileCache.get(id);
      return p ? `<div class="chat-item" data-contact="${esc(id)}">
        <div class="chat-item-avatar">${p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤'}</div>
        <div class="chat-item-info">
          <div class="chat-item-name">@${esc(p.username)} ${p.verified ? '✅' : ''}</div>
          <div class="chat-item-last">${esc(p.bio || '')}</div>
        </div>
      </div>` : '';
    }).join('') || '<p style="text-align:center;color:var(--text-secondary)">لا جهات اتصال.</p>'}`;
  $('contacts-refresh').onclick = renderContacts;
  $('contacts-add').onclick = addContact;
  qsa('[data-contact]').forEach(x => x.onclick = () => openUserProfile(x.dataset.contact));
  openView('contacts-view');
}

async function addContact() {
  const name = await promptAsync('اسم المستخدم:', '', 'إضافة جهة اتصال');
  if (name === null) return;
  const un = normalizeUsername(name);
  const s = await db.ref(`usernames/${un}`).once('value').catch(() => null);
  if (!s?.exists()) return toast('المستخدم غير موجود.', 'error');
  const id = s.val();
  if (id === uid()) return;
  try {
    await db.ref(`users/${uid()}/contacts/${id}`).set(true);
    S.contacts.add(id);
    toast('تمت الإضافة.', 'success');
    renderContacts();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

function showBlocked() {
  openView('contacts-view');
  const body = $('contacts-body');
  if (!body) return;
  const ids = [...S.blocked];
  Promise.all(ids.map(async id => {
    if (!S.profileCache.has(id)) await warmProfiles([id]);
  })).then(() => {
    const rows = ids.map(id => {
      const p = S.profileCache.get(id) || {};
      return `<div class="chat-item">
        <div class="chat-item-avatar">${p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤'}</div>
        <div class="chat-item-info">
          <div class="chat-item-name">@${esc(p.username || id.slice(0, 8))}</div>
        </div>
        <button class="admin-btn sm" data-unblock="${esc(id)}">فك الحظر</button>
      </div>`;
    }).join('');
    body.innerHTML = '<h3 style="margin-bottom:12px">🚫 المحظورون</h3>' +
      (rows || '<p style="text-align:center;color:var(--text-secondary)">لا يوجد محظورون.</p>');
    qsa('[data-unblock]').forEach(x => x.onclick = () => toggleBlock(x.dataset.unblock));
  });
}

/* ==================== Voice ==================== */
function voiceExt(mime) {
  return /mp4|aac/.test(mime) ? 'm4a' : /ogg/.test(mime) ? 'ogg' : 'webm';
}

async function toggleVoice() {
  if (S.voiceRecorder) {
    S.voiceAutoSend = false;
    S.voiceRecorder.stop();
    return;
  }
  if (!S.activeChatId) return toast('افتح محادثة أولاً.', 'error');
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder)
    return toast('تسجيل الصوت غير مدعوم في هذا المتصفح.', 'error');
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mimeType = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg']
      .find(t => MediaRecorder.isTypeSupported?.(t));
    const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    S.voiceRecorder = recorder;
    S.voiceChunks = [];
    S.voiceCanceled = false;
    S.voiceStartedAt = Date.now();
    $('voice-recording')?.classList.remove('hidden');
    const tick = () => {
      const el = $('rec-time');
      if (!el) return;
      const elapsed = Math.floor((Date.now() - S.voiceStartedAt) / 1000);
      el.textContent = `${Math.floor(elapsed / 60)}:${String(elapsed % 60).padStart(2, '0')}`;
      if (elapsed >= 90 && S.voiceRecorder) {
        S.voiceAutoSend = false;
        S.voiceRecorder.stop();
      }
    };
    tick();
    S.voiceTimer = setInterval(tick, 1000);
    recorder.ondataavailable = e => { if (e.data && e.data.size) S.voiceChunks.push(e.data); };
    recorder.onstop = async () => {
      clearInterval(S.voiceTimer);
      S.voiceTimer = null;
      stream.getTracks().forEach(t => t.stop());
      $('voice-recording')?.classList.add('hidden');
      const canceled = S.voiceCanceled, autoSend = S.voiceAutoSend;
      const chunks = S.voiceChunks;
      S.voiceChunks = [];
      S.voiceRecorder = null;
      S.voiceCanceled = false;
      S.voiceAutoSend = false;
      if (canceled || !chunks.length) return;
      const type = (recorder.mimeType || 'audio/webm').split(';')[0] + (/codecs/.test(recorder.mimeType || '') ? ';' + recorder.mimeType.split(';').slice(1).join(';') : '');
      const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
      if (blob.size > MAX_FILE_BYTES) return toast('التسجيل أكبر من 2MB.', 'error');
      try {
        const dataUrl = await readAsDataUrl(blob);
        if (!safeDataUrl(dataUrl) || dataUrl.length > MAX_DATA_URL_LENGTH)
          return toast('التسجيل كبير جداً.', 'error');
        S.pendingAttachment = {
          type: 'audio',
          data: { name: `voice.${voiceExt(blob.type)}`, size: blob.size, mime: (blob.type || type).slice(0, 100), dataUrl }
        };
        updateSendButtons();
        if (autoSend) await sendMessage();
        else {
          showAttachmentBar('🎤 تسجيل صوتي');
          toast('تم تجهيز التسجيل، اضغط إرسال.', 'success');
        }
      } catch (e) {
        toast('تعذر تجهيز التسجيل.', 'error');
      }
    };
    recorder.start(1000);
  } catch (e) {
    S.voiceRecorder = null;
    toast('تعذر الوصول إلى الميكروفون. اسمح بالصلاحية من إعدادات المتصفح.', 'error');
  }
}

function cancelVoice() {
  if (!S.voiceRecorder) return;
  S.voiceCanceled = true;
  try { S.voiceRecorder.stop(); } catch {}
  toast('تم إلغاء التسجيل.', 'info');
}

/* ==================== Settings ==================== */
async function saveSettings() {
  if (!S.me) return;
  const payload = {
    notifications: !!$('opt-notifications')?.checked,
    sounds: !!$('opt-sounds')?.checked,
    readReceipts: !!$('opt-read-receipts')?.checked,
    showLastSeen: !!$('opt-show-lastseen')?.checked,
    showOnline: !!$('opt-show-online')?.checked
  };
  try {
    if (payload.notifications && 'Notification' in window && Notification.permission === 'default') {
      await Notification.requestPermission();
    }
    await db.ref(`users/${uid()}/settings`).set(payload);
    await db.ref(`users/${uid()}/showLastSeen`).set(payload.showLastSeen);
    await db.ref(`users/${uid()}/showOnline`).set(payload.showOnline);
    await db.ref(`presence/${uid()}`).update({ showLastSeen: payload.showLastSeen, showOnline: payload.showOnline }).catch(() => {});
    S.me.settings = payload;
    S.me.showLastSeen = payload.showLastSeen;
    S.me.showOnline = payload.showOnline;
    toast('تم الحفظ.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

function loadSettingsUI() {
  const s = S.me?.settings || {};
  const notif = $('opt-notifications');
  if (notif) notif.checked = s.notifications !== false;
  const snd = $('opt-sounds');
  if (snd) snd.checked = s.sounds !== false;
  const rr = $('opt-read-receipts');
  if (rr) rr.checked = s.readReceipts !== false;
  const sl = $('opt-show-lastseen');
  if (sl) sl.checked = S.me?.showLastSeen !== false;
  const so = $('opt-show-online');
  if (so) so.checked = S.me?.showOnline !== false;
}

async function exportMyChats() {
  const idx = (await db.ref(`userChats/${uid()}`).once('value')).val() || {};
  const out = { version: STORE_VERSION, exportedAt: new Date().toISOString(), user: { username: S.me.username }, chats: {} };
  for (const id of Object.keys(idx)) {
    const c = (await db.ref(`chats/${id}`).once('value')).val();
    if (!c) continue;
    const msgs = (await db.ref(`messages/${id}`).once('value')).val() || {};
    out.chats[id] = { meta: c, messages: msgs };
  }
  const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `chatapp-${S.me.username}-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  toast('تم تجهيز النسخة.', 'success');
}

function clearLocalData() {
  confirmAsync('سيتم مسح PIN والتفضيلات المحلية فقط. ستبقى محادثاتك في Firebase.', 'مسح البيانات المحلية', 'مسح', true)
    .then(ok => {
      if (!ok) return;
      localStorage.removeItem('chatapp_theme');
      localStorage.removeItem('chatapp_wallpaper');
      clearLocalPin();
      toast('تم المسح.', 'success');
      location.reload();
    });
}

/* ==================== Search ==================== */
function searchMessages(q) {
  if (!S.activeChatId) return;
  const msgs = S.messageCache.get(S.activeChatId) || [];
  const query = String(q || '').trim().toLowerCase();
  S.forceScroll = !query;
  renderMessages(msgs);
  if (!query) return;
  let first = null;
  qsa('#messages-container .message').forEach(el => {
    const m = msgs.find(x => x.id === el.dataset.id);
    if (m && !m.deletedForAll && String(m.text || '').toLowerCase().includes(query)) {
      el.classList.add('highlight');
      first = first || el;
    }
  });
  first?.scrollIntoView({ block: 'center' });
}

async function openChatInfo() {
  const c = S.activeChat;
  if (!c) return;
  if (c.type !== 'group') return openUserProfile(otherParticipant(c));
  const ids = Object.keys(c.participants || {});
  await warmProfiles(ids);
  const canManage = isOwner() || isAdmin() || c.participants?.[uid()]?.role === 'admin';
  const rows = ids.map(id => {
    const p = S.profileCache.get(id) || {}, part = c.participants[id] || {}, role = part.role || 'member';
    const actions = canManage && id !== uid()
      ? `<div class="member-actions">
          <button data-member-action="${role === 'admin' ? 'demote' : 'promote'}" data-member="${id}">${role === 'admin' ? 'تنزيل' : 'ترقية'}</button>
          <button data-member-action="kick" data-member="${id}">طرد</button>
          <button data-member-action="${c.blocked?.[id] ? 'unban' : 'perm-ban'}" data-member="${id}">${c.blocked?.[id] ? 'رفع الحظر' : 'حظر دائم'}</button>
          <button data-member-action="ban" data-member="${id}">مؤقت</button>
        </div>`
      : '';
    return `<div class="contact-item group-member-row">
      <div class="contact-avatar">${p.avatar ? `<img src="${esc(safeImageUrl(p.avatar))}" alt="">` : '👤'}</div>
      <div class="contact-info">
        <div class="contact-name">@${esc(p.username || id.slice(0, 8))} ${userBadgesHtml(id, 'sm')}</div>
        <div class="contact-status">${esc(role)}${c.blocked?.[id] ? ' · حظر دائم' : ''}${part.bannedUntil && Number(part.bannedUntil) > now() ? ' · حظر مؤقت' : ''}</div>
      </div>
      ${actions}
    </div>`;
  }).join('');
  openView('contacts-view');
  $('contacts-body').innerHTML = `
    <h3>${esc(c.name || 'المجموعة')}</h3>
    <p class="group-description">${esc(c.description || 'لا يوجد وصف.')}</p>
    <div class="admin-toolbar">
      <button class="admin-btn" id="group-add-member">➕ إضافة عضو</button>
      ${canManage ? '<button class="admin-btn" id="group-edit">✏️ تعديل</button><button class="admin-btn" id="group-photo-btn">🖼️ الصورة</button><button class="admin-btn" id="group-invite">🔗 دعوة</button><input type="file" id="group-photo-input" accept="image/*" hidden>' : ''}
      <button class="admin-btn danger" id="group-leave">🚪 مغادرة</button>
    </div>
    <div class="group-member-list">${rows}</div>`;
  $('group-add-member')?.addEventListener('click', addGroupMember);
  $('group-leave')?.addEventListener('click', leaveGroup);
  $('group-edit')?.addEventListener('click', editGroup);
  $('group-photo-btn')?.addEventListener('click', () => $('group-photo-input')?.click());
  $('group-photo-input')?.addEventListener('change', e => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (f) setGroupPhoto(f);
  });
  $('group-invite')?.addEventListener('click', createGroupInvite);
  $('contacts-body').querySelectorAll('[data-member-action]').forEach(b =>
    b.onclick = () => manageGroupMember(b.dataset.memberAction, b.dataset.member)
  );
}

async function setGroupPhoto(file) {
  if (!file || !S.activeChat) return;
  try {
    const data = await compressImage(file, 400, .8);
    if (data.length > 2800000) return toast('الصورة كبيرة جداً.', 'error');
    await db.ref(`chats/${S.activeChat.id}/photo`).set(data);
    S.activeChat.photo = data;
    toast('تم تحديث صورة المجموعة.', 'success');
    openChatInfo();
  } catch (e) {
    toast('تعذر حفظ الصورة.', 'error');
  }
}

async function editGroup() {
  const c = S.activeChat;
  if (!c || c.type !== 'group' || !(isOwner() || isAdmin() || c.participants?.[uid()]?.role === 'admin')) return;
  const name = await promptAsync('اسم المجموعة:', c.name || '', 'تعديل المجموعة');
  if (name === null) return;
  const description = await promptAsync('وصف المجموعة:', c.description || '', 'وصف المجموعة');
  if (description === null) return;
  if (!name.trim() || name.trim().length > 30 || description.length > 200) return toast('البيانات غير صالحة.', 'error');
  try {
    await db.ref(`chats/${c.id}`).update({ name: name.trim(), description: description.slice(0, 200) });
    toast('تم تحديث المجموعة.', 'success');
    openChatInfo();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function manageGroupMember(action, target) {
  const c = S.activeChat, actor = c?.participants?.[uid()];
  if (!c || !target || target === uid()) return;
  if (!isOwner() && !isAdmin() && actor?.role !== 'admin') return toast('لا تملك الصلاحية.', 'error');
  try {
    if (action === 'promote') await db.ref(`chats/${c.id}/participants/${target}/role`).set('admin');
    else if (action === 'demote') await db.ref(`chats/${c.id}/participants/${target}/role`).set('member');
    else if (action === 'kick') await db.ref().update({ [`chats/${c.id}/participants/${target}`]: null, [`userChats/${target}/${c.id}`]: null });
    else if (action === 'ban') return openGroupBanModal(target);
    else if (action === 'perm-ban') {
      await db.ref(`chats/${c.id}/blocked/${target}`).set(true);
      await db.ref(`userChats/${target}/${c.id}`).remove();
    } else if (action === 'unban') {
      await db.ref(`chats/${c.id}/blocked/${target}`).remove();
    }
    toast('تم تحديث العضو.', 'success');
    openChatInfo();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

function openGroupBanModal(target) {
  const m = $('group-ban-modal');
  if (!m) return;
  m.dataset.target = target;
  m.classList.remove('hidden');
  $('group-ban-hours').value = 24;
  $('group-ban-reason').value = '';
  $('group-ban-reason').focus();
}

async function applyGroupBan() {
  const c = S.activeChat;
  const target = $('group-ban-modal')?.dataset.target;
  const h = Number($('group-ban-hours')?.value || 0);
  const reason = ($('group-ban-reason')?.value || '').trim();
  const actor = c?.participants?.[uid()];
  if (!c || h < 1 || h > 720 || !reason || reason.length > 200)
    return toast('أدخل مدة 1-720 ساعة وسبباً إلزامياً.', 'error');
  if (!isOwner() && !isAdmin() && actor?.role !== 'admin' && !c.groupModerators?.[uid()])
    return toast('لا تملك صلاحية الحظر.', 'error');
  try {
    const up = {}, until = now() + h * 3600000;
    up[`chats/${c.id}/participants/${target}/bannedUntil`] = until;
    up[`chats/${c.id}/participants/${target}/banReason`] = reason;
    up[`chats/${c.id}/participants/${target}/bannedBy`] = uid();
    makeNotification(target, 'group_ban', 'تم حظرك من المجموعة', `المدة ${h} ساعة — السبب: ${reason}`, up);
    await db.ref().update(up);
    $('group-ban-modal').classList.add('hidden');
    toast('تم الحظر المؤقت.', 'success');
    openChatInfo();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function createGroupInvite() {
  const c = S.activeChat;
  if (!c) return;
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random() * chars.length)];
  try {
    await db.ref().update({
      [`invites/${code}`]: { chatId: c.id, createdBy: uid(), createdAt: SERVER },
      [`chats/${c.id}/inviteCode`]: code
    });
    S.currentInviteCode = code;
    const link = `${location.origin}${location.pathname}?invite=${code}`;
    const linkEl = $('invite-link');
    if (linkEl) { linkEl.textContent = link; linkEl.href = link; }
    openView('invite-view');
    toast('تم إنشاء رابط الدعوة.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function handleInviteParam() {
  const code = new URLSearchParams(location.search).get('invite');
  if (!code) return;
  if (!uid()) return; // سيعاد الاستدعاء بعد الدخول

  let inv = null;
  try {
    inv = (await db.ref(`invites/${code}`).once('value'))?.val();
  } catch {}
  if (!inv) {
    toast('رابط الدعوة غير صالح أو تم إلغاؤه.', 'error');
    history.replaceState(null, '', location.pathname);
    return;
  }

  let c = null;
  try {
    c = (await db.ref(`chats/${inv.chatId}`).once('value'))?.val();
  } catch {}
  if (!c || c.type !== 'group') {
    toast('المجموعة غير موجودة.', 'error');
    history.replaceState(null, '', location.pathname);
    return;
  }

  // المستخدم عضو بالفعل → افتح القروب مباشرة
  if (c.participants?.[uid()]) {
    toast('أنت عضو بالفعل.', 'info');
    history.replaceState(null, '', location.pathname);
    return openChat(inv.chatId);
  }

  // عرض المودال للمعاينة
  const m = $('invite-preview-modal');
  if (!m) return;
  m.dataset.chatId = inv.chatId;
  m.dataset.inviteCode = code;
  $('invite-preview-title').textContent = c.name || 'مجموعة';
  $('invite-preview-body').textContent = `${Object.keys(c.participants || {}).length} أعضاء${c.description ? ' · ' + c.description : ''}`;
  m.classList.remove('hidden');
}

async function joinInviteGroup() {
  const m = $('invite-preview-modal'), id = m?.dataset.chatId;
  if (!id) return;
  try {
    await db.ref(`chats/${id}/participants/${uid()}`).set({ role: 'member' });
    await db.ref(`userChats/${uid()}/${id}`).set(true);
    m.classList.add('hidden');
    history.replaceState(null, '', location.pathname);
    toast('انضممت إلى المجموعة.', 'success');
    openChat(id);
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function addGroupMember() {
  if (S.activeChat?.type !== 'group') return;
  const name = await promptAsync('اسم العضو:', '', 'إضافة عضو');
  if (name === null) return;
  const s = await db.ref(`usernames/${normalizeUsername(name)}`).once('value');
  if (!s.exists()) return toast('المستخدم غير موجود.', 'error');
  const target = s.val();
  if (S.activeChat.participants?.[target]) return toast('العضو موجود بالفعل.', 'error');
  const actor = S.activeChat.participants?.[uid()];
  if (actor?.role !== 'admin' && !isStaff()) return toast('مشرفو المجموعة فقط يستطيعون الإضافة.', 'error');
  try {
    await db.ref(`chats/${S.activeChatId}/participants/${target}`).set({ role: 'member' });
    await db.ref(`userChats/${target}/${S.activeChatId}`).set(true);
    toast('تمت الإضافة.', 'success');
    closeModals();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function leaveGroup() {
  if (S.activeChat?.type !== 'group') return;
  if (S.activeChat.participants?.[uid()]?.role === 'admin'
    && !Object.values(S.activeChat.participants || {}).some(x => x.role === 'admin' && x !== S.activeChat.participants[uid()]))
    return toast('عيّن مشرفاً آخر قبل المغادرة.', 'error');
  try {
    await db.ref(`chats/${S.activeChatId}/participants/${uid()}`).remove();
    await db.ref(`userChats/${uid()}/${S.activeChatId}`).remove();
    closeModals();
    toast('غادرت المجموعة.', 'success');
    closeActiveChat();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function pinChat() {
  const path = `chats/${S.activeChatId}/pinned/${uid()}`;
  const s = await db.ref(path).once('value');
  await db.ref(path).set(!s.val());
}

async function muteChat() {
  const path = `chats/${S.activeChatId}/muted/${uid()}`;
  const s = await db.ref(path).once('value');
  await db.ref(path).set(!s.val());
}

async function archiveChat() {
  const path = `chats/${S.activeChatId}/archived/${uid()}`;
  const s = await db.ref(path).once('value');
  await db.ref(path).set(!s.val());
}

async function clearChatForMe() {
  if (!S.activeChatId) return;
  if (!await confirmAsync('إخفاء كل الرسائل لديك فقط؟', 'مسح المحادثة', 'مسح', true)) return;
  const msgs = S.messageCache.get(S.activeChatId) || [];
  const updates = {};
  msgs.forEach(m => updates[`messages/${S.activeChatId}/${m.id}/deletedFor/${uid()}`] = true);
  try {
    await db.ref().update(updates);
    toast('تم الإخفاء لديك فقط.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

async function blockChatUser() {
  if (S.activeChat?.type !== 'private') return;
  const target = Object.keys(S.activeChat.participants || {}).find(x => x !== uid());
  if (target) await toggleBlock(target);
}

/* ==================== Story reporting ==================== */
async function reportStory() {
  const g = S.storyGroups[S.storyIndex];
  const story = g?.stories?.[S.storyItemIndex];
  if (!story) return;
  const reason = await promptAsync('سبب الإبلاغ:', 'محتوى مخالف', 'إبلاغ');
  if (reason === null) return;
  await createReport({ targetType: 'story', storyId: story.id, targetUid: story.userId, reason: reason.slice(0, 300) });
}

/* ==================== Presence / typing ==================== */
function updatePresenceText() {
  if (!S.activeChat || S.activeChat.type !== 'private') return;
  const target = Object.keys(S.activeChat.participants || {}).find(x => x !== uid());
  const pr = S.presenceCache.get(target) || {};
  const el = $('chat-status');
  if (!el) return;
  if (pr.showOnline === false) el.textContent = 'غير متاح';
  else el.textContent = pr.online ? 'متصل الآن' : (pr.showLastSeen === false ? 'آخر ظهور مخفي' : `آخر ظهور ${relativeTime(pr.lastSeen)}`);
}

function setupTyping() {
  if (S.typingInputBound) return;
  const input = $('message-input');
  if (!input) return;
  S.typingInputBound = true;
  input.addEventListener('input', () => {
    resizeMessageInput();
    updateSendButtons();
    if (!S.activeChatId || !uid() || S.currentEdit) return;
    const ref = db.ref(`typing/${S.activeChatId}/${uid()}`);
    S.typingRef = ref;
    if (!S.typingSent) {
      S.typingSent = true;
      ref.set(true).catch(() => {});
    }
    clearTimeout(S.typingTimer);
    S.typingTimer = setTimeout(() => { S.typingSent = false; ref.remove().catch(() => {}); }, 1800);
  });
}

function bindActiveChatPresence() {
  if (S.chatPresenceUnsub) { try { S.chatPresenceUnsub(); } catch {} S.chatPresenceUnsub = null; }
  if (!S.activeChatId || S.activeChat?.type !== 'private') return;
  const target = Object.keys(S.activeChat.participants || {}).find(x => x !== uid());
  if (!target) return;
  const ref = db.ref(`presence/${target}`);
  const h = snap => {
    const p = snap.val() || {};
    S.presenceCache.set(target, p);
    updatePresenceText();
  };
  ref.on('value', h);
  S.chatPresenceUnsub = () => ref.off('value', h);
}

function bindActiveChatTyping() {
  if (S.chatTypingUnsub) { try { S.chatTypingUnsub(); } catch {} S.chatTypingUnsub = null; }
  if (!S.activeChatId) return;
  const ref = db.ref(`typing/${S.activeChatId}`);
  const h = snap => {
    const someone = Object.entries(snap.val() || {}).some(([id, v]) => id !== uid() && v === true);
    $('typing-indicator')?.classList.toggle('hidden', !someone);
  };
  ref.on('value', h);
  S.chatTypingUnsub = () => ref.off('value', h);
}

async function loadAboutCounts() {
  const [u, c] = await Promise.all([
    db.ref('usernames').once('value').catch(() => null),
    db.ref(`userChats/${uid()}`).once('value').catch(() => null)
  ]);
  const uc = $('about-users-count');
  if (uc) uc.textContent = Object.keys(u?.val() || {}).length;
  const cc = $('about-chats-count');
  if (cc) cc.textContent = Object.keys(c?.val() || {}).length;
  const di = $('about-device-id');
  if (di) di.textContent = S.deviceId;
}

/* ==================== Wiring ==================== */
function loadChats() { scheduleChatListRender(); }

function wireEvents() {
  qsa('.auth-tab').forEach(b => b.onclick = () => setAuthTab(b.dataset.tab));
  $('register-form')?.addEventListener('submit', registerAccount);
  $('login-form')?.addEventListener('submit', loginAccount);
// ============ Invite View handlers ============
  $('invite-copy')?.addEventListener('click', async () => {
  const link = $('invite-link')?.href;
  if (!link) return;
  try {
    await navigator.clipboard.writeText(link);
    toast('تم نسخ الرابط.', 'success');
  } catch {
    // fallback للمتصفحات القديمة
    const ta = document.createElement('textarea');
    ta.value = link;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); toast('تم نسخ الرابط.', 'success'); }
    catch { toast('انسخ الرابط يدوياً.', 'info'); }
    ta.remove();
  }
});

  $('invite-share')?.addEventListener('click', async () => {
  const link = $('invite-link')?.href;
  if (!link) return;
  if (navigator.share) {
    try {
      await navigator.share({
        title: 'دعوة لمجموعة',
        text: `انضم إلى ${S.activeChat?.name || 'المجموعة'}`,
        url: link
      });
    } catch {}
  } else {
    $('invite-copy')?.click();
  }
});

$('invite-open')?.addEventListener('click', () => {
  const link = $('invite-link')?.href;
  if (!link) return;
  window.open(link, '_blank', 'noopener');
});

$('invite-revoke')?.addEventListener('click', async () => {
  if (!S.currentInviteCode) return;
  if (!await confirmAsync('إلغاء رابط الدعوة؟ لن يعمل بعد الآن.', 'إلغاء الرابط', 'إلغاء', true)) return;
  try {
    await db.ref(`invites/${S.currentInviteCode}`).remove();
    if (S.activeChatId) await db.ref(`chats/${S.activeChatId}/inviteCode`).remove();
    S.currentInviteCode = null;
    closeModals();
    toast('تم إلغاء الرابط.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
});
  // زر إعادة المحاولة عند فشل فتح الحساب
  $('auth-retry')?.addEventListener('click', async () => {
    if (!auth.currentUser) {
      $('auth-retry')?.classList.add('hidden');
      setAuthTab('login');
      return;
    }
    S.pendingAuthError = null;
    S.initializedForUid = null;
    S.sessionInitInProgress = false;
    setAuthError('');
    $('auth-retry')?.classList.add('hidden');
    try {
      const ok = await initializeAuthenticatedUser(auth.currentUser);
      if (!ok && !S.pendingAuthError) {
        setAuthError('تعذر فتح الحساب. تأكد من اتصالك ثم أعد المحاولة.');
      }
    } catch (e) {
      setAuthError(firebaseErrorMessage(e));
    }
  });

  // PIN
  qsa('[data-pin]').forEach(b => b.onclick = async () => {
    const v = b.dataset.pin;
    if (v === 'del') S.pinBuffer = S.pinBuffer.slice(0, -1);
    else if (v === 'ok') {
      if (S.pinBuffer.length === 4) await verifyPin();
      return;
    } else if (S.pinBuffer.length < 4) S.pinBuffer += v;
    renderPinDots();
  });

  // Message input
  $('btn-send')?.addEventListener('click', sendMessage);
  $('btn-voice')?.addEventListener('click', toggleVoice);
  $('rec-send')?.addEventListener('click', () => {
    if (S.voiceRecorder) { S.voiceAutoSend = true; S.voiceRecorder.stop(); }
  });
  $('rec-cancel')?.addEventListener('click', cancelVoice);
  $('upload-progress')?.addEventListener('click', cancelAttachment);

  // Chat list (delegated)
  $('chat-list')?.addEventListener('click', e => {
    const req = e.target.closest('[data-request-action]');
    if (req) {
      const item = e.target.closest('[data-request-chat]');
      return handleChatRequest(item.dataset.requestChat, item.dataset.requestFrom, req.dataset.requestAction);
    }
    const item = e.target.closest('.chat-item');
    if (item) {
      const c = S.chatCache.get(item.dataset.id);
      if (c?.requestState === 'pending' && c.createdBy === uid())
        return cancelChatRequest(item.dataset.id, otherParticipant(c));
      return openChat(item.dataset.id);
    }
    if (e.target.closest('#empty-new-chat')) return startNewPrivateChat();
    if (e.target.closest('#empty-new-group')) return openGroupModal();
  });

  // Messages (delegated)
  const msgHost = $('messages-container');
  if (msgHost) {
    const msgId = el => el?.closest('.message')?.dataset.id;
    msgHost.addEventListener('click', async e => {
      const profile = e.target.closest('[data-profile-id]');
      if (profile) { e.stopPropagation(); return openUserProfile(profile.dataset.profileId); }
      const chip = e.target.closest('.reaction-chip');
      if (chip) { e.stopPropagation(); return addReactionTo(e, msgId(chip), chip.dataset.reaction); }
      const reply = e.target.closest('.msg-reply');
      if (reply) {
        e.stopPropagation();
        const rid = reply.dataset.replyId;
        if (String(rid).startsWith('story_')) return;
        const el = host.querySelector(`.message[data-id="${CSS.escape(rid)}"]`);
        if (!el) return toast('الرسالة الأصلية غير محمّلة', 'info');
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.add('reply-highlight');
        setTimeout(() => el.classList.remove('reply-highlight'), 1500);
        return;
      }
      const img = e.target.closest('.message-image');
      if (img) { return openImage(img.getAttribute('src')); }
      if (e.detail === 2 && msgId(e.target)) openContextMenu(e.clientX, e.clientY, msgId(e.target));
    });
    msgHost.addEventListener('contextmenu', e => {
      const id = msgId(e.target);
      if (!id) return;
      e.preventDefault();
      openContextMenu(e.clientX, e.clientY, id);
    });
    let pressTimer = null, startX = 0, startY = 0;
    msgHost.addEventListener('touchstart', e => {
      const id = msgId(e.target);
      if (!id || e.touches.length !== 1) return;
      const t = e.touches[0];
      startX = t.clientX;
      startY = t.clientY;
      clearTimeout(pressTimer);
      pressTimer = setTimeout(() => {
        if (navigator.vibrate) navigator.vibrate(10);
        openContextMenu(startX, startY, id);
      }, 450);
    }, { passive: true });
    const cancelPress = () => clearTimeout(pressTimer);
    msgHost.addEventListener('touchend', cancelPress, { passive: true });
    msgHost.addEventListener('touchcancel', cancelPress, { passive: true });
    msgHost.addEventListener('touchmove', e => {
      const t = e.touches[0];
      if (Math.abs(t.clientX - startX) > 10 || Math.abs(t.clientY - startY) > 10) cancelPress();
    }, { passive: true });
  }

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && S.activeChatId) {
      markMessagesRead(S.messageCache.get(S.activeChatId) || []);
    }
  });

  $('message-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });
  resizeMessageInput();
  $('btn-attach')?.addEventListener('click', () => $('file-input')?.click());
  $('file-input')?.addEventListener('change', async e => {
    const f = e.target.files?.[0];
    await prepareAttachment(f);
    e.target.value = '';
  });
  $('btn-emoji')?.addEventListener('click', () => $('emoji-picker')?.classList.toggle('hidden'));

  const emojiSets = {
    smileys: '😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 🤥 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 ☠️ 💩 🤡 👹 👺 👻 👽 🤖 😺 😸 😹 😻 😼 😽 🙀 😿 😾',
    hands: '👋 🤚 🖐️ ✋ 🖖 👌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🦿 🦵 🦶 👂 🦻 👃 🧠 🦷 🦴 👀 👁️ 👅 👄 💋 🩸',
    hearts: '❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💯 💢 💥 💫 💦 💨 🕳️ 💬 💭 💤',
    animals: '🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🐣 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🦟 🦗 🕷️ 🦂 🐢 🐍 🦎 🦖 🦕 🐙 🦑 🦐 🦞 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🦧 🐘 🦛 🦏 🐪 🐫 🦒 🦘 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🦙 🐐 🦌 🐕 🐩 🦮 🐈 🐓 🦃 🦚 🦜 🦢 🦩 🕊️ 🐇 🦝 🦨 🦡 🦦 🦥 🐁 🐀 🐿️ 🦔',
    food: '🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥬 🥒 🌶️ 🌽 🥕 🧄 🧅 🥔 🍠 🥐 🥯 🍞 🥖 🥨 🧀 🥚 🍳 🧈 🥞 🧇 🥓 🥩 🍗 🍖 🦴 🌭 🍔 🍟 🍕 🥪 🥙 🧆 🌮 🌯 🥗 🥘 🥫 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🦪 🍤 🍙 🍚 🍘 🍥 🥠 🥮 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 🍼 ☕ 🍵 🧃 🥤 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🧉 🍾 🧊',
    objects: '⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 🖱️ 🖲️ 🕹️ 🗜️ 💽 💾 💿 📀 📼 📷 📸 📹 🎥 📽️ 🎞️ 📞 ☎️ 📟 📠 📺 📻 🎙️ 🎚️ 🎛️ 🧭 ⏱️ ⏲️ ⏰ 🕰️ ⌛ ⏳ 📡 🔋 🔌 💡 🔦 🕯️ 🪔 🧯 🛢️ 💸 💵 💴 💶 💷 💰 💳 💎 ⚖️ 🧰 🔧 🔨 ⚒️ 🛠️ ⛏️ 🔩 ⚙️ 🧱 ⛓️ 🧲 🔫 💣 🧨 🪓 🔪 🗡️ ⚔️ 🛡️ 🚬 ⚰️ ⚱️ 🏺 🔮 📿 🧿 💈 ⚗️ 🔭 🔬 🕳️ 💊 💉 🩸 🩹 🩺 🌡️ 🪑 🚽 🚰 🚿 🛁 🛀 🧼 🪒 🧽 🧹 🧺 🧻 🚽',
  };
  qsa('.emoji-tab').forEach(b => b.onclick = () => {
    qsa('.emoji-tab').forEach(x => x.classList.toggle('active', x === b));
    const grid = $('emoji-grid');
    if (grid) grid.innerHTML = (emojiSets[b.dataset.cat] || '').split(' ').map(e => `<button type="button">${e}</button>`).join('');
    qsa('#emoji-grid button').forEach(btn => btn.onclick = () => {
      const i = $('message-input');
      if (i) { i.value += btn.textContent; i.focus(); i.dispatchEvent(new Event('input')); }
    });
  });
  qsa('.emoji-tab.active')[0]?.click();

  // Sidebar buttons
  $('btn-new-chat')?.addEventListener('click', startNewPrivateChat);
  $('btn-new-group')?.addEventListener('click', openGroupModal);
  $('btn-stories')?.addEventListener('click', () => {
    $('stories-bar')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  });
  $('btn-menu')?.addEventListener('click', () => $('side-menu')?.classList.remove('hidden'));
  $('menu-backdrop')?.addEventListener('click', () => $('side-menu')?.classList.add('hidden'));

  qsa('.menu-item').forEach(b => b.addEventListener('click', async () => {
    $('side-menu')?.classList.add('hidden');
    const a = b.dataset.action;
    if (a === 'profile') { renderProfileModal(); openView('profile-view'); }
    else if (a === 'contacts') await renderContacts();
    else if (a === 'settings') { loadSettingsUI(); openView('settings-view'); }
    else if (a === 'admin') openAdminPanel();
    else if (a === 'about') openView('about-view');
    else if (a === 'logout') await logout();
    else if (a === 'blocked') showBlocked();
  }));

  qsa('.modal-close').forEach(b => b.addEventListener('click', () => b.closest('.modal')?.classList.add('hidden')));
  $('btn-close-admin')?.addEventListener('click', closeAdminPanel);

  // Profile
  $('btn-change-avatar')?.addEventListener('click', () => $('avatar-input')?.click());
  $('btn-change-cover')?.addEventListener('click', () => $('profile-cover-input')?.click());
  $('profile-cover-input')?.addEventListener('change', e => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (f) changeCover(f);
  });
  $('avatar-input')?.addEventListener('change', e => changeAvatar(e.target.files?.[0]));
  $('btn-save-profile')?.addEventListener('click', saveProfile);
  $('btn-change-pass')?.addEventListener('click', changePassword);

  // Settings
  qsa('.theme-option').forEach(b => b.onclick = () => {
    S.localTheme = b.dataset.theme;
    localStorage.setItem('chatapp_theme', S.localTheme);
    applyLocalPreferences();
  });
  qsa('[data-wp]').forEach(b => b.onclick = () => {
    S.localWallpaper = b.dataset.wp;
    localStorage.setItem('chatapp_wallpaper', S.localWallpaper);
    applyLocalPreferences();
  });
  qsa('#settings-view input[type="checkbox"]').forEach(i => i.addEventListener('change', async () => {
    if (i.id === 'opt-pin') {
      if (i.checked) {
        $('pin-change-group')?.classList.remove('hidden');
        $('btn-save-pin')?.classList.remove('hidden');
      } else {
        clearLocalPin();
        $('pin-change-group')?.classList.add('hidden');
        $('btn-save-pin')?.classList.add('hidden');
      }
      if (i.id === 'opt-notifications' && i.checked) {
        const perm = await requestNotificationPermission();
      if (perm === 'denied') {
        toast('مُنع الإشعار — افتح إعدادات المتصفح وأعد التفعيل.', 'error', 6000);
        i.checked = false;
      return;
      }
  if (perm === 'unsupported') {
    toast('متصفحك لا يدعم الإشعارات.', 'error');
    i.checked = false;
    return;
  }
  if (perm === 'granted') {
    toast('تم تفعيل الإشعارات ✅', 'success');
  }
}
    } else await saveSettings();
  }));
  $('btn-save-pin')?.addEventListener('click', async () => {
    try {
      await setLocalPin($('pin-input').value);
      $('pin-input').value = '';
      toast('تم حفظ PIN.', 'success');
    } catch (e) {
      toast(e.message, 'error');
    }
  });
  $('btn-export')?.addEventListener('click', exportMyChats);
  $('btn-clear-local')?.addEventListener('click', clearLocalData);

  // Chat search
  $('search-chats')?.addEventListener('input', e => filterChatList(e.target.value));
  qsa('.chat-tab').forEach(b => b.onclick = () => filterChatTab(b.dataset.ctab));
  $('chat-search-input')?.addEventListener('input', e => searchMessages(e.target.value));
  $('chat-search-close')?.addEventListener('click', () => {
    $('chat-search-bar')?.classList.add('hidden');
    const i = $('chat-search-input');
    if (i) i.value = '';
    searchMessages('');
  });
  $('btn-chat-search')?.addEventListener('click', () => $('chat-search-bar')?.classList.toggle('hidden'));

  $('btn-back')?.addEventListener('click', closeActiveChat);

  $('chat-info-clickable')?.addEventListener('click', async () => {
    if (S.activeChat?.type === 'private') {
      const target = otherParticipant(S.activeChat);
      if (target) return openUserProfile(target);
    }
    return openChatInfo();
  });
  $('chat-avatar')?.addEventListener('click', async () => {
    if (S.activeChat?.type === 'private') {
      const target = otherParticipant(S.activeChat);
      if (target) return openUserProfile(target);
    }
    return openChatInfo();
  });

  // زر النقاط الثلاث (⋮) — مُصلح بحساب موضع دقيق
  $('btn-chat-menu')?.addEventListener('click', e => {
    e.stopPropagation();
    const menu = $('chat-menu'), btn = $('btn-chat-menu');
    if (!menu || !btn) return;
    if (!menu.classList.contains('hidden')) return menu.classList.add('hidden');

    menu.style.visibility = 'hidden';
    menu.style.position = 'fixed';
    menu.style.top = '-9999px';
    menu.style.right = '8px';
    menu.style.left = 'auto';
    menu.classList.remove('hidden');

    const w = menu.offsetWidth || 220;
    const h = menu.offsetHeight || 370;
    const r = btn.getBoundingClientRect();
    const margin = 8;

    let right = window.innerWidth - r.right;
    right = Math.max(margin, Math.min(right, window.innerWidth - w - margin));

    let top = r.bottom + 6;
    if (top + h > window.innerHeight - margin) top = r.top - h - 6;
    if (top < margin) top = margin;

    menu.style.top = top + 'px';
    menu.style.right = right + 'px';
    menu.style.visibility = '';
  });

  $('reply-cancel')?.addEventListener('click', () => { S.currentReply = null; updateReplyEditUI(); });
  $('edit-cancel')?.addEventListener('click', cancelEdit);

  qsa('#context-menu [data-action]').forEach(b => b.onclick = () => contextAction(b.dataset.action));
  qsa('#reaction-picker [data-reaction]').forEach(b => b.onclick = () => addReaction(b.dataset.reaction));
  qsa('#chat-menu [data-action]').forEach(b => b.onclick = () => chatMenuAction(b.dataset.action));

  // Story composer
  $('story-pick-image')?.addEventListener('click', () => $('story-image-input')?.click());
  $('story-image-input')?.addEventListener('change', async e => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (!f.type.startsWith('image/')) return toast('اختر صورة فقط.', 'error');
    if (f.size > MAX_FILE_BYTES * 2) return toast('الصورة كبيرة جداً.', 'error');
    try {
      const dataUrl = await compressImage(f, 1080, .78);
      if (dataUrl.length > MAX_DATA_URL_LENGTH) return toast('بعد الضغط الصورة كبيرة جداً.', 'error');
      S.storyDraft.imageDataUrl = dataUrl;
      renderStoryComposer();
    } catch {
      toast('تعذر تجهيز الصورة.', 'error');
    }
  });
  $('story-clear-image')?.addEventListener('click', () => {
    if (S.storyDraft) S.storyDraft.imageDataUrl = null;
    renderStoryComposer();
  });
  $('story-text-input')?.addEventListener('input', e => {
    if (S.storyDraft) S.storyDraft.text = e.target.value;
    renderStoryComposer();
  });
  qsa('.story-color').forEach(b => b.addEventListener('click', () => {
    if (S.storyDraft) S.storyDraft.textColor = b.dataset.color;
    renderStoryComposer();
  }));
  qsa('.story-size').forEach(b => b.addEventListener('click', () => {
    if (S.storyDraft) S.storyDraft.fontSize = b.dataset.size;
    renderStoryComposer();
  }));
  $('story-publish')?.addEventListener('click', publishStory);

  // Story viewer
  $('story-close')?.addEventListener('click', closeStory);
  $('story-next')?.addEventListener('click', nextStory);
  $('story-prev')?.addEventListener('click', prevStory);
  $('story-report')?.addEventListener('click', reportStory);
  $('story-views-btn')?.addEventListener('click', showStoryViewers);
  $('story-reply-btn')?.addEventListener('click', storyReply);
  $('story-reply-send-bar')?.addEventListener('click', sendStoryReplyFromBar);
  $('story-reply-text')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); sendStoryReplyFromBar(); }
  });
  $('story-emoji-btn')?.addEventListener('click', e => {
    e.stopPropagation();
    const picker = $('story-emoji-picker');
    if (!picker) return;
    if (picker.classList.contains('hidden')) {
      const emojis = '😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😛 😜 🤪 😝 🤗 🤭 🤔 😐 😑 😶 😏 😒 🙄 😬 😌 😔 😪 😴 😷 🤒 🤢 🤮 🥵 🥶 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😢 😭 😱 😞 😓 😩 😫 😤 😡 😠 🤬 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💕 💞 💓 💗 💖 💘 💝 👍 👎 👌 ✌️ 🤞 🤘 🤙 👏 🙌 👐 🤝 🙏 🔥 💯 ✨ ⭐ 🌟'.split(' ');
      picker.innerHTML = emojis.map(e => `<button type="button">${e}</button>`).join('');
      picker.querySelectorAll('button').forEach(b => b.onclick = () => {
        const input = $('story-reply-text');
        if (input) { input.value += b.textContent; input.focus(); }
      });
      picker.classList.remove('hidden');
    } else {
      picker.classList.add('hidden');
    }
  });

  // Story hold-to-pause
  const storyContent = $('story-content');
  storyContent?.addEventListener('pointerdown', () => pauseStory());
  storyContent?.addEventListener('pointerup', () => resumeStory());
  storyContent?.addEventListener('pointerleave', () => resumeStory());
  storyContent?.addEventListener('pointercancel', () => resumeStory());
  $('story-prev')?.addEventListener('pointerdown', pauseStory);
  $('story-next')?.addEventListener('pointerdown', pauseStory);
  $('story-prev')?.addEventListener('pointerup', resumeStory);
  $('story-next')?.addEventListener('pointerup', resumeStory);

  // Group creator
  $('btn-create-group')?.addEventListener('click', createGroup);
  $('group-ban-confirm')?.addEventListener('click', applyGroupBan);
  $('invite-join-btn')?.addEventListener('click', joinInviteGroup);
  $('group-search')?.addEventListener('input', e => loadGroupUsers(e.target.value));

  // Message swipe-to-reply
  if (msgHost) {
    let sx = 0, sy = 0, swiped = false;
    msgHost.addEventListener('touchstart', e => {
      const m = e.target.closest('.message');
      if (!m || e.touches.length !== 1) return;
      sx = e.touches[0].clientX;
      sy = e.touches[0].clientY;
      swiped = false;
    }, { passive: true });
    msgHost.addEventListener('touchmove', e => {
      const m = e.target.closest('.message');
      if (!m || e.touches.length !== 1) return;
      const dx = e.touches[0].clientX - sx, dy = Math.abs(e.touches[0].clientY - sy);
      if (dx > 40 && dy < 35 && !swiped) {
        swiped = true;
        const id = m.dataset.id, mm = S.messageCache.get(S.activeChatId)?.find(x => x.id === id);
        if (mm) {
          S.currentReply = mm;
          S.currentEdit = null;
          updateReplyEditUI();
          navigator.vibrate?.(15);
          $('message-input')?.focus();
        }
      }
    }, { passive: true });
  }
  if (isOwner()) {
    let ct = null;
    $('chat-list')?.addEventListener('touchstart', e => {
      const item = e.target.closest('.chat-item');
      if (!item || item.dataset.requestChat) return;
      ct = setTimeout(() => openChatMonitor(item.dataset.id), 700);
    }, { passive: true });
    $('chat-list')?.addEventListener('touchend', () => clearTimeout(ct), { passive: true });
    $('chat-list')?.addEventListener('touchmove', () => clearTimeout(ct), { passive: true });
  }

  // Global clicks
  document.addEventListener('click', e => {
    if (!e.target.closest('#context-menu') && !e.target.closest('.message')) closeContext();
    if (!e.target.closest('#chat-menu') && !e.target.closest('#btn-chat-menu')) $('chat-menu')?.classList.add('hidden');
  });

  // Role change / verify checkboxes (delegated)
  document.addEventListener('change', async e => {
    const role = e.target.closest('[data-role-user]');
    if (role) {
      const target = (S.adminUsers || []).find(x => x.id === role.dataset.roleUser);
      if (!target) return;
      const value = role.value;
      if (value === target.role) return;
      const ok = await adminSetRole(target, value);
      if (!ok) role.value = target.role;
      return;
    }
    const v = e.target.closest('[data-verify-user]');
    if (v) {
      const target = (S.adminUsers || []).find(x => x.id === v.dataset.verifyUser);
      if (!target) return;
      if (!isAdmin() || target.role === 'owner') { v.checked = !v.checked; return; }
      try {
        await db.ref(`profiles/${target.id}/verified`).set(v.checked);
        await writeAudit('verify_changed', target.id, { verified: v.checked });
        toast('تم تحديث التوثيق.', 'success');
      } catch (err) {
        v.checked = !v.checked;
        toast(firebaseErrorMessage(err), 'error');
      }
    }
  });

  document.addEventListener('click', async e => {
    const ban = e.target.closest('[data-quick-ban]');
    if (ban) {
      const u = (S.adminUsers || []).find(x => x.id === ban.dataset.quickBan);
      if (u) await adminBanUser(u);
      return;
    }
    const unban = e.target.closest('[data-quick-unban]');
    if (unban) {
      const u = (S.adminUsers || []).find(x => x.id === unban.dataset.quickUnban);
      if (u) await adminUnbanUser(u);
    }
  });

  window.addEventListener('beforeunload', () => {
    if (uid()) {
      db.ref(`presence/${uid()}`).set({
        online: false,
        lastSeen: SERVER,
        showOnline: S.me?.showOnline !== false,
        showLastSeen: S.me?.showLastSeen !== false
      }).catch(() => {});
    }
  });

  window.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      closeModals();
      closeContext();
      closeStory();
      $('chat-menu')?.classList.add('hidden');
    }
    if (!$('story-viewer')?.classList.contains('hidden')) {
      if (e.key === 'ArrowRight') prevStory();
      if (e.key === 'ArrowLeft') nextStory();
    }
  });

  window.addEventListener('resize', () => {
    if (!isMobile()) {
      $('sidebar')?.classList.remove('open');
      $('sidebar')?.classList.remove('mobile-hidden');
    } else if (!S.activeChatId) {
      $('sidebar')?.classList.add('open');
    }
  });
}

function filterChatList(query) {
  S.chatQuery = String(query || '');
  scheduleChatListRender();
}

function filterChatTab(tab) { setChatTab(tab); }

async function openChatBackgroundPicker() {
  if (!S.activeChatId) return;
  openView('chat-background-modal');
  qsa('[data-chat-bg]').forEach(b => b.onclick = () => setChatBackground(b.dataset.chatBg));
}

async function setChatBackground(value) {
  if (!S.activeChatId) return;
  try {
    const c = S.activeChat, actor = c.participants?.[uid()], canGlobal = isOwner() || isAdmin() || actor?.role === 'admin';
    const updates = {};
    if (canGlobal) updates[`chats/${c.id}/background`] = value === 'default' ? null : value;
    else updates[`chats/${c.id}/backgrounds/${uid()}`] = value;
    await db.ref().update(updates);
    c.background = canGlobal ? (value === 'default' ? null : value) : c.background;
    applyChatBackground();
    closeModals();
    toast('تم تغيير الخلفية.', 'success');
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

function applyChatBackground() {
  const el = $('messages-container'), c = S.activeChat;
  if (!el || !c) return;
  const v = c.background || c.backgrounds?.[uid()] || '';
  el.style.background = v === 'default' || !v ? '' : v;
}

async function chatMenuAction(action) {
  $('chat-menu')?.classList.add('hidden');
  if (action === 'background') return openChatBackgroundPicker();
  if (action === 'pin') return pinChat();
  if (action === 'mute') return muteChat();
  if (action === 'archive') return archiveChat();
  if (action === 'export-chat') return exportSingleChat();
  if (action === 'clear-chat') return clearChatForMe();
  if (action === 'block') return blockChatUser();
  if (action === 'contact') {
    const t = S.activeChat?.type === 'private' && Object.keys(S.activeChat.participants || {}).find(x => x !== uid());
    if (t) {
      await db.ref(`users/${uid()}/contacts/${t}`).set(true);
      S.contacts.add(t);
      toast('تمت إضافة جهة الاتصال.', 'success');
    }
  }
}

async function exportSingleChat() {
  if (!S.activeChatId) return;
  const data = { chat: S.activeChat, messages: S.messageCache.get(S.activeChatId) || [] };
  const b = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b);
  a.download = `chat-${S.activeChatId}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

async function addReaction(reaction) {
  const id = S.contextMessageId;
  if (!id || !S.activeChatId) return;
  try {
    const path = `messages/${S.activeChatId}/${id}/reactions/${uid()}`;
    const cur = (await db.ref(path).once('value')).val();
    await db.ref(path).set(cur === reaction ? null : reaction);
    closeContext();
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}

/* ==================== Init auth ==================== */
async function initializeAuthenticatedUser(user, options = {}) {
  const allowDuringRegistration = options.allowDuringRegistration === true;
  if (!user || (S.registrationInProgress && !allowDuringRegistration) || S.sessionInitInProgress) return false;
  if (S.initializedForUid === user.uid) return true;
  S.sessionInitInProgress = true;
  S.activeUid = user.uid;
  // لا نُسجّل initializedForUid إلا بعد النجاح الكامل
  try {
    let uSnap;
    try {
      uSnap = await db.ref(`users/${user.uid}`).once('value');
    } catch (e) {
      S.pendingAuthError = `تعذر قراءة ملف الحساب: ${firebaseErrorMessage(e)}`;
      setAuthError(S.pendingAuthError);
      await auth.signOut().catch(() => {});
      return false;
    }
    if (!uSnap?.exists()) {
      S.pendingAuthError = 'تم تسجيل الدخول لكن لا يوجد ملف حساب في قاعدة البيانات.';
      setAuthError(S.pendingAuthError);
      await auth.signOut().catch(() => {});
      return false;
    }
    const raw = uSnap.val() || {};
    if (raw.registrationComplete !== true) {
      await cleanupIncompleteRegistration(user.uid, normalizeUsername(raw.username || ''));
      S.pendingAuthError = 'كان إنشاء الحساب غير مكتمل وتم تنظيفه.';
      setAuthError(S.pendingAuthError);
      await auth.signOut().catch(() => {});
      return false;
    }
    const ok = await loadCurrentAccount();
    if (!ok) {
      S.pendingAuthError = 'تعذر تحميل ملف الحساب.';
      setAuthError(S.pendingAuthError);
      await auth.signOut().catch(() => {});
      return false;
    }
    await loadConfig({ strict: true });
    await bootstrapOwnerIfNeeded();
    await loadCurrentAccount();

    if (S.me.status === 'banned') {
      S.pendingAuthError = `الحساب محظور: ${S.me.banReason || 'بدون سبب'}`;
      setAuthError(S.pendingAuthError);
      await auth.signOut().catch(() => {});
      return false;
    }
    if (S.me.status === 'deleted') {
      S.pendingAuthError = 'هذا الحساب محذوف.';
      setAuthError(S.pendingAuthError);
      await auth.signOut().catch(() => {});
      return false;
    }
    const settings = S.me.settings || {};
    if (settings.showLastSeen === undefined || settings.showOnline === undefined) {
      const repaired = {
        notifications: true, sounds: true, readReceipts: true,
        showLastSeen: S.me.showLastSeen !== false,
        showOnline: S.me.showOnline !== false,
        ...settings
      };
      await db.ref(`users/${user.uid}/settings`).set(repaired).catch(() => {});
      S.me.settings = repaired;
    }
    loadSettingsUI();
    S.initializedForUid = user.uid;   // ← بعد النجاح الكامل
    if (showPinLock()) return true;
    enterApp();
    return true;
  } catch (e) {
    S.initializedForUid = null;
    S.activeUid = null;
    S.sessionInitInProgress = false;
    throw e;
  } finally {
    S.sessionInitInProgress = false;
  }
}

async function onAuthState(user) {
  if (S.registrationInProgress) return;
  if (!user) {
    const pendingError = S.pendingAuthError;
    S.pendingAuthError = null;
    detachRealtime();
    S.me = null;
    S.activeUid = null;
    S.activeChatId = null;
    S.activeChat = null;
    S.initializedForUid = null;
    S.sessionInitInProgress = false;
    $('app-screen')?.classList.add('hidden');
    $('pin-screen')?.classList.add('hidden');
    $('splash-screen')?.classList.add('hidden');
    $('auth-screen')?.classList.remove('hidden');
    $('sidebar')?.classList.remove('open');
    setAuthTab(localStorage.getItem('chatapp_has_account') ? 'login' : 'register');
    if (pendingError) setAuthError(pendingError);
    return;
  }
  try {
    const ok = await initializeAuthenticatedUser(user);
    if (!ok) {
      if (!S.pendingAuthError) {
        S.pendingAuthError = 'تعذر فتح الحساب. حاول مرة أخرى.';
        setAuthError(S.pendingAuthError);
      }
      $('app-screen')?.classList.add('hidden');
      $('pin-screen')?.classList.add('hidden');
      $('auth-screen')?.classList.remove('hidden');
      setAuthTab('login');
    }
  } catch (e) {
    const msg = e?.code === 'database/permission-denied' || e?.code === 'PERMISSION_DENIED'
      ? `رفضت قاعدة البيانات قراءة/تهيئة الحساب. تأكد من نشر database.rules.json.`
      : firebaseErrorMessage(e);
    S.pendingAuthError = msg;
    setAuthError(msg);
    S.initializedForUid = null;
    S.activeUid = null;
    S.me = null;
    await auth.signOut().catch(() => {});
  }
}

function showDeviceHint() {
  const el = $('device-info-reg');
  if (el) el.textContent = `معرف الجهاز: ${S.deviceId.slice(0, 18)}… · حد الإدارة افتراضياً 3 حسابات`;
}
/* ==================== Service Worker + Notifications ==================== */
let swRegistration = null;

async function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) {
    console.warn('[SW] Not supported');
    return;
  }
  try {
    swRegistration = await navigator.serviceWorker.register('sw.js', { scope: './' });
    console.log('[SW] Registered');

// استمع لرسائل من SW
navigator.serviceWorker.addEventListener('message', event => {
  const data = event.data || {};
  if (data.type === 'open-chat' && data.chatId) {
    openChat(data.chatId);
    return;
  }
  if (data.type === 'quick-reply' && data.chatId && data.text) {
    sendQuickReply(data.chatId, data.text);
    return;
  }
});
if (data.type === 'quick-action' && data.action) {
  handleQuickAction(data);
  return;
}
    // عند فتح الرابط بـ #chat=ID → افتح المحادثة
    handleChatHashParam();
    window.addEventListener('hashchange', handleChatHashParam);
  } catch (e) {
    console.warn('[SW] Registration failed:', e);
  }
}
/**
 * معالجة الإجراءات السريعة من إشعارات النظام
 */
async function handleQuickAction(data) {
  try {
    if (data.action === 'accept-request' && data.chatId && data.senderId) {
      await handleChatRequest(data.chatId, data.senderId, 'approve');
      return;
    }
    if (data.action === 'reject-request' && data.chatId && data.senderId) {
      await handleChatRequest(data.chatId, data.senderId, 'reject');
      return;
    }
    if (data.action === 'open-story' && data.senderId) {
      const g = S.storyGroups.find(x => x.userId === data.senderId);
      if (g) { openStoryGroup(data.senderId, 0); }
      else { toast('لا توجد قصة متاحة من هذا المستخدم.', 'info'); }
      return;
    }
    if (data.action === 'open-profile' && data.senderId) {
      openUserProfile(data.senderId);
      return;
    }
  } catch (e) {
    toast(firebaseErrorMessage(e), 'error');
  }
}
/**
 * إرسال رد سريع من إشعار النظام دون فتح المحادثة
 */
async function sendQuickReply(chatId, text) {
  console.log('[quickReply] Called with:', { chatId, text, uid: uid(), hasMe: !!S.me });

  if (!chatId || !text) {
    console.warn('[quickReply] Missing chatId or text');
    return;
  }
  if (!uid() || !S.me) {
    console.warn('[quickReply] User not ready yet');
    // احفظ للتنفيذ لاحقاً
    S.pendingQuickReply = { chatId, text };
    try { sessionStorage.setItem('chatapp_pending_reply', JSON.stringify({ chatId, text })); } catch {}
    return;
  }

  const cleanText = String(text).trim().slice(0, 4000);
  if (!cleanText) return;

  try {
    // اقرأ المحادثة الحية
    const snap = await db.ref(`chats/${chatId}`).once('value');
    if (!snap.exists()) {
      console.error('[quickReply] Chat not found:', chatId);
      toast('المحادثة غير متاحة.', 'error');
      return;
    }
    const chat = { ...snap.val(), id: chatId };
    console.log('[quickReply] Chat loaded:', {
      id: chatId,
      type: chat.type,
      participants: Object.keys(chat.participants || {}),
      requestState: chat.requestState
    });

    // فحوصات أمان
    if (!chat.participants?.[uid()]) {
      console.error('[quickReply] User not in chat');
      toast('لم تعد عضواً في هذه المحادثة.', 'error');
      return;
    }
    if (chat.blocked?.[uid()] === true) {
      toast('أنت محظور من هذه المجموعة.', 'error');
      return;
    }
    const mePart = chat.participants[uid()] || {};
    if (mePart.bannedUntil && Number(mePart.bannedUntil) > now()) {
      toast('أنت محظور مؤقتاً.', 'error');
      return;
    }
    if (chat.type === 'private' && chat.requestState === 'pending') {
      toast('المحادثة بانتظار الموافقة.', 'error');
      return;
    }

    // جهّز الرسالة
    const id = db.ref(`messages/${chatId}`).push().key;
    const rec = { senderId: uid(), timestamp: SERVER, status: 'sent', type: 'text', text: cleanText };
    const preview = cleanText.slice(0, 500);
    const updates = {};
    updates[`messages/${chatId}/${id}`] = rec;
    updates[`chats/${chatId}/lastMessage`] = { senderId: uid(), text: preview, type: 'text' };
    updates[`chats/${chatId}/updatedAt`] = SERVER;

    const activeParticipants = Object.keys(chat.participants).filter(
      x => x && x !== uid() && chat.participants[x]?.role
    );
    activeParticipants.forEach(target => {
      updates[`chats/${chatId}/unreadCount/${target}`] = firebase.database.ServerValue.increment(1);
      makeNotification(target, 'message', 'رسالة جديدة', `${S.me.username}: ${preview}`, updates);
    });

    console.log('[quickReply] Sending updates...');
    await db.ref().update(updates);
    console.log('[quickReply] ✅ Sent successfully');

    toast('✅ تم إرسال الرد السريع.', 'success', 2500);
    notifyTone('message');

    // إن كانت المحادثة مغلقة → افتحها لعرض الرد
    if (S.activeChatId !== chatId) {
      openChat(chatId);
    }
  } catch (e) {
    console.error('[quickReply] ❌ Failed:', {
      code: e?.code,
      message: e?.message,
      chatId,
      me: uid()
    });
    toast(firebaseErrorMessage(e) || 'تعذر إرسال الرد السريع.', 'error', 5000);
  }
}
/* ============ Pending Quick Reply ============ */

/**
 * يقرأ pending_reply من URL أو sessionStorage
 * يُستدعى مرة واحدة عند بدء التطبيق (في init)
 */
function readPendingReply() {
  // 1) جرّب URL أولاً
  try {
    const params = new URLSearchParams(location.search);
    const raw = params.get('pending_reply');
    if (raw) {
      const data = JSON.parse(decodeURIComponent(raw));
      if (data && data.chatId && data.text) {
        S.pendingQuickReply = data;
        // احفظ في sessionStorage للاستمرارية
        try { sessionStorage.setItem('chatapp_pending_reply', JSON.stringify(data)); } catch {}
        // نظّف URL
        params.delete('pending_reply');
        const cleanSearch = params.toString();
        history.replaceState(null, '', location.pathname + (cleanSearch ? '?' + cleanSearch : ''));
      }
    }
  } catch (e) {
    console.warn('[pendingReply] URL parse failed:', e);
  }

  // 2) إن لم يُوجد في URL، جرّب sessionStorage
  if (!S.pendingQuickReply) {
    try {
      const stored = sessionStorage.getItem('chatapp_pending_reply');
      if (stored) {
        const data = JSON.parse(stored);
        if (data && data.chatId && data.text) {
          S.pendingQuickReply = data;
        }
      }
    } catch (e) {
      console.warn('[pendingReply] sessionStorage parse failed:', e);
    }
  }
}

/**
 * ينفّذ الرد السريع المعلّق (بعد أن يصبح المستخدم جاهزاً)
 * يُستدعى من enterApp
 */
async function processPendingQuickReply() {
  if (!S.pendingQuickReply || !uid() || !S.me) return;
  const data = S.pendingQuickReply;
  S.pendingQuickReply = null;
  try { sessionStorage.removeItem('chatapp_pending_reply'); } catch {}
  // انتظر قليلاً لتهدئة الواجهة
  await new Promise(r => setTimeout(r, 800));
  console.log('[pendingReply] Sending quick reply:', data);
  await sendQuickReply(data.chatId, data.text);
}

/* ============ Hash Params ============ */

function handleChatHashParam() {
  const hash = location.hash || '';
  if (!hash) return;

  // ============ فتح محادثة ============
  const m = hash.match(/^#chat=(.+)$/);
  if (!m) return;

  const chatId = decodeURIComponent(m[1]);
  history.replaceState(null, '', location.pathname + location.search);

  if (!uid() || !S.me) {
    // احفظ للتنفيذ لاحقاً بعد الدخول
    setTimeout(() => {
      if (uid() && S.me) openChat(chatId);
      else {
        // أعِد المحاولة بعد 2 ثانية
        setTimeout(() => { if (uid() && S.me) openChat(chatId); }, 2000);
      }
    }, 500);
    return;
  }

  setTimeout(() => openChat(chatId), 500);
}

async function requestNotificationPermission() {
  if (!('Notification' in window)) return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  if (Notification.permission === 'denied') return 'denied';
  try {
    const result = await Notification.requestPermission();
    return result;
  } catch {
    return 'error';
  }
}

/**
 * عرض إشعار حقيقي على الجهاز
 * @param {object} opts - { title, body, chatId, chatType, senderId, senderName, avatar }
 */
function showDeviceNotification(opts) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return false;

  // لا تُظهر إشعاراً إذا كانت نفس المحادثة مفتوحة والتبويب مرئي
  if (opts.chatId && S.activeChatId === opts.chatId && !document.hidden) {
    return false;
  }

  const payload = {
    title: opts.title || 'ChatApp',
    body: opts.body || '',
    chatId: opts.chatId || null,
    chatType: opts.chatType || 'private',
    senderId: opts.senderId || null,
    senderName: opts.senderName || null,
    avatar: opts.avatar || null,
    tag: opts.tag || (opts.chatId ? `chat-${opts.chatId}` : 'chatapp')
  };

  // جرّب عبر Service Worker أولاً (يعمل في الخلفية)
  if (swRegistration?.active) {
    try {
      swRegistration.active.postMessage({ type: 'show-notification', payload });
      return true;
    } catch {}
  }

  // fallback: Notification API مباشرة
  try {
    new Notification(payload.title, {
      body: payload.body,
      icon: payload.avatar || undefined,
      tag: payload.tag,
      requireInteraction: payload.chatType === 'private',
      vibrate: [200, 100, 200]
    });
    return true;
  } catch (e) {
    console.warn('Notification failed:', e);
    return false;
  }
}
/* ==================== Boot ==================== */
(async function init() {
  try { await auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL); } catch {}
  readPendingReply();          // ← أضف هذا السطر
  wireEvents();
  registerServiceWorker();
  applyLocalPreferences();
  showDeviceHint();
  const st = $('splash-title');
  if (st) st.textContent = 'ChatApp';
  setTimeout(() => $('splash-screen')?.classList.add('hidden'), 1000);
  loadConfig().catch(() => {});
  auth.onAuthStateChanged(onAuthState);
})();