# ChatApp v5.0 — Firebase deployment checklist

1. استخدم نفس مشروع Firebase المضمّن في `app.js` و`FIREBASE_SETUP.md` (`chat-otaku-aed68`).
2. فعّل Authentication → Sign-in method → Email/Password.
3. استبدل Realtime Database Rules بالكامل بمحتوى `database.rules.json`.
4. لا تخلط هذه القواعد مع قواعد الإصدارات القديمة.
5. يمكن إدخال `database.seed.json` إلى RTDB لتهيئة `config/app`.
6. أنشئ أول مستخدم باسم `data`؛ عند عدم وجود `config/ownerUid` يصبح مالك النظام تلقائيًا.
7. اختبر بالترتيب: تسجيل → دخول → فتح محادثة خاصة → إرسال نص → إرسال مرفق صغير → إنشاء مجموعة → قصة نصية → قصة صورة.
8. عند ظهور `Permission denied`، افحص أولًا أن قواعد RTDB المنشورة هي نفس الملف وأن Authentication فعّال.
9. المشروع لا يعتمد على Firebase Storage ولا Cloud Functions. الوسائط الصغيرة تُحفظ داخل RTDB كـ data URL ضمن الحدود المعلنة داخل المشروع.

## ملاحظة ANIMEX admin
تم الاستفادة من هيكل الإدارة/الأدوار والمراجعة الموجود في ملف ANIMEX الإداري، لكن لم يتم نقل إعداد Firebase أو بنية بيانات ANIMEX إلى ChatApp لأنها تخص مشروع Firebase مختلفًا. لوحة الإدارة داخل ChatApp تعمل على نموذج ChatApp نفسه وقواعده.


## v6.0 validation
- Deploy `database.rules.json` as a full replacement, not a merge.
- Test message request: A→B pending, B approve/reject, A cancel.
- Test story audience, reply, reaction and viewer list.
- Test group temporary/permanent bans and invite join.
- Test owner 700ms monitoring mode.
- Test profile username/display name/cover/bio updates.
- Test SVG badges in profile/chat/group contexts.
