/*
 * ChatApp Service Worker — v6.1
 * ================================
 * - إشعارات غنية (Rich Notifications) مع أيقونات
 * - رد سريع مباشر من الإشعار
 * - تجميع الإشعارات حسب المحادثة
 * - دعم الأنواع المختلفة (رسالة / قصة / طلب / متابعة / حظر)
 * - فتح التطبيق على المحادثة الصحيحة
 * - أصوات واهتزاز مخصص
 * =================================
 */

const SW_VERSION = '6.1';
const CACHE_NAME = `chatapp-${SW_VERSION}`;
const APP_URL = self.location.origin + self.location.pathname.replace(/\/sw\.js$/, '/');

/* ===================================================================
 * 1) التثبيت والتفعيل
 * =================================================================== */
self.addEventListener('install', event => {
  console.log('[SW] Installing', SW_VERSION);
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  console.log('[SW] Activating', SW_VERSION);
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/* ===================================================================
 * 2) استقبال رسائل من التطبيق
 * =================================================================== */
self.addEventListener('message', event => {
  const data = event.data || {};
  if (data.type === 'show-notification' && data.payload) {
    showNotification(data.payload);
  }
  if (data.type === 'close-all') {
    self.registration.getNotifications().then(list => list.forEach(n => n.close()));
  }
  if (data.type === 'ping') {
    event.source?.postMessage({ type: 'pong', version: SW_VERSION });
  }
});

/* ===================================================================
 * 3) عرض الإشعار — الدالة الرئيسية
 * =================================================================== */
async function showNotification(payload = {}) {
  const {
    title = 'ChatApp',
    body = '',
    chatId = null,
    chatType = 'private',
    senderId = null,
    senderName = null,
    avatar = null,
    tag,
    notifType = 'message', // message | story | request | follow | ban | system
    badgeCount = null
  } = payload;

  // ============ حدد النوع والأسلوب ============
  const style = styleForType(notifType, chatType);

  // ============ الأيقونات ============
  const iconUrl = avatar || `${APP_URL}icons/icon-192.png`;
  const badgeUrl = `${APP_URL}icons/badge-72.png`;

  // ============ الأفعال (Actions) ============
  const actions = buildActions(notifType, chatType);

  // ============ Tag + renotify ============
  const finalTag = tag || (chatId ? `chat-${chatId}` : `notif-${Date.now()}`);

  // ============ الخيارات النهائية ============
  const options = {
    body,
    icon: iconUrl,
    badge: badgeUrl,
    tag: finalTag,
    renotify: true,               // اهتزاز + صوت مرة أخرى حتى مع نفس الـ tag
    requireInteraction: style.requireInteraction,
    silent: false,
    vibrate: style.vibrate,
    timestamp: Date.now(),
    dir: 'rtl',
    lang: 'ar',
    data: {
      chatId,
      chatType,
      senderId,
      senderName,
      notifType,
      url: APP_URL,
      receivedAt: Date.now()
    },
    actions
  };

  // ============ اعرض الإشعار ============
  try {
    await self.registration.showNotification(title, options);

    // ============ Badge على أيقونة التطبيق (Android) ============
    if (badgeCount != null && 'setAppBadge' in navigator) {
      try { navigator.setAppBadge(badgeCount); } catch {}
    }
  } catch (e) {
    console.error('[SW] showNotification failed:', e);
  }
}

/* ===================================================================
 * 4) تخصيص الأسلوب حسب النوع
 * =================================================================== */
function styleForType(notifType, chatType) {
  switch (notifType) {
    case 'message':
      return {
        vibrate: chatType === 'group' ? [200, 100, 200] : [180, 80, 180],
        requireInteraction: false
      };
    case 'request':
      return {
        vibrate: [300, 100, 300, 100, 300],
        requireInteraction: true  // لا تختفي حتى يقرر المستخدم
      };
    case 'story':
      return {
        vibrate: [150, 70, 150],
        requireInteraction: false
      };
    case 'follow':
      return {
        vibrate: [120],
        requireInteraction: false
      };
    case 'ban':
      return {
        vibrate: [400, 200, 400, 200, 400],
        requireInteraction: true
      };
    case 'system':
      return {
        vibrate: [100],
        requireInteraction: false
      };
    default:
      return {
        vibrate: [200, 100, 200],
        requireInteraction: false
      };
  }
}

/* ===================================================================
 * 5) بناء الأفعال حسب النوع
 * =================================================================== */
function buildActions(notifType, chatType) {
  const actions = [];

  // ===== رسالة عادية (خاص أو مجموعة) =====
  if (notifType === 'message') {
    actions.push({
      action: 'reply',
      type: 'text',
      title: 'رد ↩️',
      placeholder: chatType === 'group' ? 'رد للمجموعة...' : 'اكتب رسالتك...'
    });
    actions.push({
      action: 'open',
      title: 'فتح',
      icon: `${APP_URL}icons/action-open.png` // اختياري
    });
    return actions;
  }

  // ===== طلب مراسلة =====
  if (notifType === 'request') {
    actions.push({ action: 'accept', title: '✓ قبول' });
    actions.push({ action: 'reject', title: '✕ رفض' });
    return actions;
  }

  // ===== قصة جديدة =====
  if (notifType === 'story') {
    actions.push({ action: 'view-story', title: '👁️ عرض القصة' });
    actions.push({ action: 'open', title: 'فتح' });
    return actions;
  }

  // ===== متابعة جديدة =====
  if (notifType === 'follow') {
    actions.push({ action: 'open-profile', title: '👤 عرض الملف' });
    return actions;
  }

  // ===== حظر / إداري =====
  if (notifType === 'ban') {
    actions.push({ action: 'open', title: 'تفاصيل' });
    return actions;
  }

  // ===== افتراضي =====
  actions.push({ action: 'open', title: 'فتح' });
  return actions;
}

/* ===================================================================
 * 6) معالج النقر على الإشعار
 * =================================================================== */
self.addEventListener('notificationclick', event => {
  const notification = event.notification;
  const data = notification.data || {};
  const action = event.action;
  const replyText = (event.reply || '').trim();

  // أغلق الإشعار
  notification.close();

  // ===== 1) رد سريع =====
  if (action === 'reply') {
    if (!replyText) return; // لم يكتب شيئاً
    event.waitUntil(dispatchQuickReply(data.chatId, replyText));
    return;
  }

  // ===== 2) قبول طلب المراسلة =====
  if (action === 'accept') {
    event.waitUntil(dispatchToApp('quick-action', {
      action: 'accept-request',
      chatId: data.chatId,
      senderId: data.senderId
    }));
    return;
  }

  // ===== 3) رفض طلب المراسلة =====
  if (action === 'reject') {
    event.waitUntil(dispatchToApp('quick-action', {
      action: 'reject-request',
      chatId: data.chatId,
      senderId: data.senderId
    }));
    return;
  }

  // ===== 4) عرض قصة =====
  if (action === 'view-story') {
    event.waitUntil(dispatchToApp('quick-action', {
      action: 'open-story',
      senderId: data.senderId
    }));
    return;
  }

  // ===== 5) فتح ملف شخصي =====
  if (action === 'open-profile') {
    event.waitUntil(dispatchToApp('quick-action', {
      action: 'open-profile',
      senderId: data.senderId
    }));
    return;
  }

  // ===== 6) فتح المحادثة (افتراضي) =====
  event.waitUntil(openChatWindow(data.chatId, data.senderId));
});

/* ===================================================================
 * 7) إغلاق الإشعارات (المستخدم أزالها يدوياً)
 * =================================================================== */
self.addEventListener('notificationclose', event => {
  // يمكن إرسال إشارة للتطبيق بأن الإشعار أُغلق
  const data = event.notification.data || {};
  if (data.chatId) {
    self.clients.matchAll({ type: 'window' }).then(clients => {
      clients.forEach(c => c.postMessage({
        type: 'notification-dismissed',
        chatId: data.chatId
      }));
    });
  }
});

/* ===================================================================
 * 8) Push Notifications (مستقبلي — مع Cloud Functions)
 * =================================================================== */
self.addEventListener('push', event => {
  let payload = { title: 'ChatApp', body: 'لديك إشعار جديد' };
  try {
    if (event.data) {
      const parsed = event.data.json();
      payload = { ...payload, ...parsed };
    }
  } catch {
    payload.body = event.data?.text() || payload.body;
  }
  event.waitUntil(showNotification(payload));
});

/* ===================================================================
 * 9) Background Sync (اختياري - للمستقبل)
 * =================================================================== */
self.addEventListener('sync', event => {
  if (event.tag === 'sync-messages') {
    event.waitUntil(syncPendingMessages());
  }
});

async function syncPendingMessages() {
  // هنا يمكن إضافة منطق إرسال الرسائل المعلقة
  console.log('[SW] Sync messages');
}

/* ===================================================================
 * 10) دوال مساعدة داخلية
 * =================================================================== */

/**
 * إرسال رد سريع للنافذة المفتوحة أو فتح نافذة جديدة
 */
async function dispatchQuickReply(chatId, text) {
  if (!chatId || !text) return;

  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });

  // ✅ ابحث عن أي نافذة للتطبيق (حتى بدون focus)
  for (const client of clients) {
    if (client.url.startsWith(APP_URL)) {
      client.postMessage({
        type: 'quick-reply',
        chatId,
        text
      });
      return client.focus();
    }
  }

  // ✅ لا نافذة → افتح واحدة مع query parameter (أكثر موثوقية من hash)
  const payload = encodeURIComponent(JSON.stringify({ chatId, text }));
  const baseUrl = APP_URL.split('?')[0].split('#')[0];
  return self.clients.openWindow(`${baseUrl}?pending_reply=${payload}`);
}

/**
 * إرسال رسالة للتطبيق (نافذة مفتوحة أو فتح جديدة)
 */
async function dispatchToApp(messageType, payload) {
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });

  for (const client of clients) {
    if (client.url.startsWith(APP_URL)) {
      client.postMessage({ type: messageType, ...payload });
      return client.focus();
    }
  }

  // لا نافذة → افتح مع hash
  const hash = encodeURIComponent(JSON.stringify(payload));
  return self.clients.openWindow(`${APP_URL}#${messageType}=${hash}`);
}

/**
 * فتح نافذة المحادثة (بدون رد)
 */
async function openChatWindow(chatId, senderId) {
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });

  for (const client of clients) {
    if (client.url.startsWith(APP_URL)) {
      client.postMessage({
        type: 'open-chat',
        chatId,
        senderId
      });
      return client.focus();
    }
  }

  // افتح نافذة جديدة مع hash
  const url = chatId ? `${APP_URL}#chat=${encodeURIComponent(chatId)}` : APP_URL;
  return self.clients.openWindow(url);
}

/* ===================================================================
 * 11) Fetch Handler (اختياري)
 * — لا نخزّن شيئاً (التطبيق يعتمد على Firebase)
 * =================================================================== */
self.addEventListener('fetch', event => {
  // نترك الطلبات تمر بشكل طبيعي
  // (يمكن إضافة cache-first للموارد الثابتة لاحقاً)
  return;
});

/* ===================================================================
 * 12) معلومات
 * =================================================================== */
console.log(`[SW] ChatApp Service Worker loaded — v${SW_VERSION}`);