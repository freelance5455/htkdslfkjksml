# ChatApp v6.0

- Message requests with approve/reject/cancel and owner/admin bypass.
- Story audience filtering, story replies, reactions and notification events.
- Owner read-only monitoring mode and group moderation controls.
- Temporary/permanent group bans with RTDB enforcement.
- Group invite links, group management, photo/description editing.
- Per-user chat backgrounds and global group/admin backgrounds.
- SVG badge system and profile improvements.
- Username/display name/cover editing with 30-day username limit.
- Expanded notifications, audio tones and notification read-state handling.
- Local conversation cache and dynamic chat-menu positioning.
- Updated rules/schema/tests for v6.0.
