# ChatApp final — Firebase RTDB

هذه النسخة تستخدم Firebase Authentication (Email/Password) + Realtime Database فقط. لا تستخدم Firebase Storage ولا Cloud Functions.

## قبل التشغيل
1. من Firebase Console افتح Authentication > Sign-in method وفعّل **Email/Password**.
2. استبدل قواعد Realtime Database بمحتوى `database.rules.json` أو نفّذ إعداد Firebase CLI بعد تسجيل الدخول.
3. يمكن إدخال `database.seed.json` في RTDB لتهيئة اسم التطبيق وحد الحسابات.
4. أنشئ أول حساب باسم المستخدم `data`. إذا لم يكن `config/ownerUid` موجوداً، يصبح هذا الحساب مالك النظام تلقائياً وفق القاعدة المحمية.

## تغييرات مهمة
- كلمات المرور لم تعد محفوظة أو مشفرة داخل RTDB؛ Firebase Auth يتولى الاعتماد. أثناء التسجيل، يتم إنشاء بيانات RTDB بشكل متسلسل لتجنب تعارضات قواعد التحقق.
- اسم المستخدم ثابت بعد الإنشاء للحفاظ على فهرس `usernames` دون سباقات أو روابط مكسورة.
- البيانات الخاصة في `users`، والبيانات العامة في `profiles`، والحضور في `presence`.
- لا توجد صلاحية عامة للقراءة/الكتابة على قاعدة البيانات، والقصص العادية لا تُقرأ إلا عبر استعلام مقيّد بزمن الانتهاء والحد الأقصى للنتائج.
- لوحة الإدارة أصبحت حسب الدور: `user`, `moderator`, `admin`, `owner` مع حالات `active`, `banned`, `deleted`.
- الحذف الإداري للحسابات أصبح Soft Delete ويمكن الاستعادة.
- القصص تنتهي بعد 24 ساعة، وتملك سجل مشاهدات وفهرس مشاهدة لكل مستخدم، والتنقل أصبح بين قصص المستخدم نفسه ثم المستخدمين الآخرين. بيانات القصة نفسها موجودة في `storyContents/{storyId}` وتُجلب عند فتحها فقط.
- البلاغات، المتابعون/المتابَعون، التوثيق، سجل العملات، سجل التدقيق، الأجهزة والمحادثات لها عقد مستقلة.
- PIN محلي للجهاز وليس وسيلة مصادقة خادمية.

## حدود معروفة
Realtime Database ليس مخزناً للملفات الكبيرة؛ النسخة الحالية تضع حد 2MB للوسائط المشفرة داخل البيانات. هذا متعمد لأن المشروع لا يستخدم Storage.

معرّف الجهاز المُنشأ في المتصفح يفيد للمراقبة والإحصاءات فقط، ولا يمكن اعتباره حاجزاً أمنياً حقيقياً في تطبيق ويب: يمكن حذف التخزين المحلي أو تغييره.

## تشخيص التسجيل
إذا رأيت صفحة المحادثات الفارغة بعد تسجيل جديد في نسخة قديمة، سجّل الخروج واحذف حساب التجربة العالق من Authentication ثم جرّب الإصدار 4.5. الإصدار الجديد يمنع سباق onAuthStateChanged، ويستخدم registrationComplete ويعالج الحسابات غير المكتملة تلقائياً.

المشروع المضمّن في firebaseConfig هو `chat-otaku-aed68` وقاعدة البيانات `https://chat-otaku-aed68-default-rtdb.firebaseio.com`. يجب نشر القواعد في نفس مشروع Firebase هذا.


## Registration diagnostics
The registration flow is intentionally sequential. The UI now names the exact failed step (Auth, users, username index, profile, presence, device link, or completion). Do not merge these rules with older rules. The app must use the included `database.rules.json`.


## v5.0 reliability pass
- مربع الرسالة أصبح `textarea` حقيقيًا مع تمدد تلقائي، ويدعم Enter للإرسال وShift+Enter لسطر جديد.
- حماية إضافية لمربع الإرسال والمرفقات وحالة الاتصال داخل الواجهة.
- قراءة بيانات القصص لم تعد تعتمد على شرط query هش مرتبط بساعة الجهاز؛ بيانات المحتوى نفسها ما زالت محمية وتُقرأ فقط للمستخدمين المخولين أثناء صلاحية القصة.
- القصص النصية تحتوي على `preview` صغير داخل metadata كخطة بديلة في حال تعذر تحميل `storyContents`.
- لوحة الإدارة بقيت على نفس بنية ChatApp، مع الحفاظ على صلاحيات الأدوار والمراجعة والسجلات بدل نسخ Firebase الخاص بملف ANIMEX إلى مشروع مختلف.

## v6.0 UI fixes

راجع `CHANGELOG_v6.0.md` للتغييرات الخاصة بمحرر الرسائل والملفات الشخصية وملف المالك.
