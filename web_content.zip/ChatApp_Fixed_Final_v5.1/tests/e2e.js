// End-to-end: run the REAL app.js for two users against an in-memory RTDB that enforces database.rules.json
const fs=require('fs'), vm=require('vm');
const {makeSim}=require('./rules_sim.js');
const rulesFile=process.argv[2], appFile=process.argv[3];
const sim=makeSim(JSON.parse(fs.readFileSync(rulesFile,'utf8')));
const DB={data:{}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let keyN=0; const nextKey=()=>'-K'+String(++keyN).padStart(6,'0');
const listeners=[];
const clone=o=>o===undefined?undefined:JSON.parse(JSON.stringify(o));
const getAt=(root,p)=>{let c=root;for(const k of p){if(c==null||typeof c!=='object')return undefined;c=c[k];}return c;};

function makeSnap(key,val,order){ // order: array of keys for forEach
  return {key, val:()=>val===undefined?null:clone(val), exists:()=>val!==undefined&&val!==null,
    forEach(fn){ if(val&&typeof val==='object'){ const keys=order||Object.keys(val); for(const k of keys){ if(fn(makeSnap(k,val[k]))) return true; } } return false; }};
}
function fireAll(){ for(const l of listeners.slice()) l.run(); }

function makeFirebase(uid){
  const permErr=()=>Object.assign(new Error('PERMISSION_DENIED: Permission denied'),{code:'PERMISSION_DENIED'});
  function Ref(path,q){
    const self={path,q:q||{},
      get key(){return path[path.length-1]||null;},
      child(p){return Ref(path.concat(String(p).split('/').filter(Boolean)),null);},
      orderByChild(c){return Ref(path,{...self.q,orderByChild:c,startAt:self.q.startAt??null,limitToLast:self.q.limitToLast??null,limitToFirst:null});},
      startAt(v){return Ref(path,{...self.q,startAt:v,limitToFirst:self.q.limitToFirst??null,limitToLast:self.q.limitToLast??null});},
      limitToLast(n){return Ref(path,{...self.q,limitToLast:n,limitToFirst:null,startAt:self.q.startAt??null});},
      equalTo(v){return Ref(path,{...self.q,equalTo:v});},
      push(){const k=nextKey();return Ref(path.concat(k));},
      _read(){ const p=path.join('/'); if(!sim.read(DB,uid,p,Date.now(),self.q)) return {denied:true};
        let v=getAt(DB.data,path); let order=null;
        if(v&&typeof v==='object'&&self.q.orderByChild){ let ent=Object.entries(v).map(([k,x])=>[k,x]).sort((a,b)=>(a[1]?.[self.q.orderByChild]??0)-(b[1]?.[self.q.orderByChild]??0)||(a[0]<b[0]?-1:1));
          if(self.q.startAt!=null) ent=ent.filter(e=>(e[1]?.[self.q.orderByChild]??0)>=self.q.startAt);
          if(self.q.equalTo!==undefined) ent=ent.filter(e=>e[1]?.[self.q.orderByChild]===self.q.equalTo);
          if(self.q.limitToLast) ent=ent.slice(-self.q.limitToLast);
          v=Object.fromEntries(ent); order=ent.map(e=>e[0]); }
        return {snap:makeSnap(self.key,v,order)}; },
      async once(){ const r=self._read(); if(r.denied) throw permErr(); return r.snap; },
      on(ev,cb,err){ const l={ref:self,cb,err,run(){ const r=self._read(); if(r.denied){ if(!l.dead){l.dead=true; err&&err(permErr());} return;} setTimeout(()=>{ if(!l.off) cb(r.snap); },0); }}; listeners.push(l); l.run(); return cb; },
      off(ev,cb){ for(const l of listeners){ if(l.ref===self&&(!cb||l.cb===cb)) l.off=true; } },
      async set(v){ const res=sim.set(DB,uid,path.join('/'),v===undefined?null:v,Date.now()); if(!res.ok){ const e=permErr(); e.detail=res.why; throw e;} fireAll(); },
      async remove(){ return self.set(null); },
      async update(obj){ const w={}; for(const [k,v] of Object.entries(obj)) w[path.concat(k.split('/').filter(Boolean)).join('/')]=v; const res=sim.update(DB,uid,w,Date.now()); if(!res.ok){ const e=permErr(); e.detail=res.why; throw e;} fireAll(); },
      onDisconnect(){ return {set:async()=>{}}; }
    };
    return self;
  }
  const rootRef=()=>Ref([]);
  const fb={initializeApp(){},
    auth:Object.assign(()=>authObj,{Auth:{Persistence:{LOCAL:'l'}},EmailAuthProvider:{credential(){}}}),
    database:Object.assign(()=>({ref:p=>p?Ref(String(p).split('/').filter(Boolean)):rootRef()}),{ServerValue:{TIMESTAMP:{'.sv':'timestamp'},increment:n=>({'.sv':{increment:n}})}})};
  const user={uid,email:uid+'@x'};
  const authObj={currentUser:user,setPersistence:async()=>{},signOut:async()=>{},onAuthStateChanged(cb){ setTimeout(()=>cb(user),5); }};
  return fb;
}
function makeEl(id){ const el={id,dataset:{},style:{},value:'',textContent:'',_html:'',scrollHeight:0,scrollTop:0,clientHeight:0,checked:false,disabled:false,files:[],
  classList:{_s:new Set(['hidden']),add(...a){a.forEach(x=>this._s.add(x))},remove(...a){a.forEach(x=>this._s.delete(x))},toggle(c,f){if(f===undefined)f=!this._s.has(c);f?this._s.add(c):this._s.delete(c);return f},contains(c){return this._s.has(c)}},
  addEventListener(){},removeEventListener(){},setAttribute(){},getAttribute(){return ''},querySelector(){return makeEl('q')},querySelectorAll(){return []},closest(){return null},appendChild(){},remove(){},focus(){},select(){},click(){},scrollIntoView(){},
  get innerHTML(){return this._html},set innerHTML(v){this._html=v}}; return el; }

async function makeClient(uid){
  const els={}; const store={};
  const ctx={localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}},
    document:{getElementById:id=>els[id]||(els[id]=makeEl(id)),querySelector:()=>makeEl('q'),querySelectorAll:()=>[],createElement:()=>makeEl('c'),addEventListener(){},body:makeEl('body'),documentElement:makeEl('html'),hidden:false},
    navigator:{},innerWidth:1200,console:{...console,warn:()=>{}},setTimeout,clearTimeout,setInterval,clearInterval,Date,Math,JSON,Promise,
    crypto:require('crypto').webcrypto,Notification:undefined,Blob,URL,TextEncoder,Uint8Array,Event:class{},Image:class{},FileReader:class{}};
  ctx.window=ctx; ctx.globalThis=ctx; ctx.addEventListener=()=>{};
  ctx.firebase=makeFirebase(uid);
  vm.createContext(ctx);
  const src=fs.readFileSync(appFile,'utf8')+"\n;globalThis.__T={S,openChat,createGroup,startPrivateByUid,handleChatRequest,sendMessage,toggleBlock,renderMessages};";
  vm.runInContext(src,ctx,{filename:'app.js'});
  ctx.els=els; return ctx;
}
function register(uid,username,device,base){
  const w={};
  const r1=sim.set(DB,uid,`users/${uid}`,{id:uid,username,role:'user',status:'active',coins:0,deviceId:device,createdAt:base,lastSeen:base,showOnline:true,showLastSeen:true,registrationComplete:false,settings:{notifications:true,sounds:true,readReceipts:true,showLastSeen:true,showOnline:true}},base);
  sim.set(DB,uid,`usernames/${username}`,uid,base);
  sim.set(DB,uid,`profiles/${uid}`,{username,bio:'hi '+username,avatar:'',verified:false,active:true,createdAt:base},base);
  sim.set(DB,uid,`presence/${uid}`,{online:true,lastSeen:base,showOnline:true,showLastSeen:true},base);
  sim.set(DB,uid,`devices/${device}/users/${uid}`,true,base);
  sim.set(DB,uid,`users/${uid}/registrationComplete`,true,base);
}
let pass=0,fail=0; const T=(n,c,extra)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n+(c?'':'  '+(extra||'')));};

(async()=>{
  const t0=Date.now();
  register('UA','alice','d1',t0); register('UB','bob','d2',t0); register('UC','carol','d3',t0);
  const A=await makeClient('UA'), B=await makeClient('UB'), C=await makeClient('UC');
  await sleep(400);
  T('alice entered the app', !A.els['app-screen'].classList.contains('hidden'), 'app-screen still hidden; auth-error='+A.els['auth-error']?.textContent);
  T('bob entered the app', !B.els['app-screen'].classList.contains('hidden'));

  // A starts a private chat with B (real app code)
  await A.__T.startPrivateByUid('UB');
  await sleep(150);
  sim.update(DB,'UB',{[`chatRequests/UB/UA/status`]:'approved',[`chats/${['UA','UB'].sort().join('_')}/requestState`]:'approved'},Date.now());
  await A.__T.openChat(['UA','UB'].sort().join('_'));
  await sleep(150);
  const chatId=['UA','UB'].sort().join('_');
  T('chat doc exists', !!DB.data.chats?.[chatId]);
  T('BOTH users indexed', DB.data.userChats?.UA?.[chatId]===true && DB.data.userChats?.UB?.[chatId]===true);
  T('alice has chat open', A.__T.S.activeChatId===chatId);
  T('bob chat request/index is present', DB.data.userChats?.UB?.[chatId]===true && DB.data.chatRequests?.UB?.UA?.status==='approved');

  // send several messages, including a very long one
  for (const txt of ['one','two','three']) { A.els['message-input'].value=txt; await A.__T.sendMessage(); }
  A.els['message-input'].value='L'.repeat(3000); await A.__T.sendMessage();
  await sleep(300);
  const msgs=Object.values(DB.data.messages?.[chatId]||{});
  T('4 messages stored', msgs.length===4, 'stored='+msgs.length);
  T('lastMessage preview <= 500', DB.data.chats[chatId].lastMessage.text.length<=500);
  const html=A.els['messages-container'].innerHTML;
  T('alice UI renders ALL messages (forEach fix)', (html.match(/class="message /g)||[]).length===4, 'rendered='+(html.match(/class="message /g)||[]).length);

  // bob sees unread badge + preview in list, then opens the chat
  await sleep(200);
  const bl=B.els['chat-list'].innerHTML;
  T('bob has four unread messages', (DB.data.chats[chatId].unreadCount?.UB||0)===4);
  await B.__T.openChat(chatId);
  await sleep(400);
  const bh=B.els['messages-container'].innerHTML;
  T('bob UI renders all 4 messages', (bh.match(/class="message /g)||[]).length===4);
  T('bob unread reset to 0', (DB.data.chats[chatId].unreadCount?.UB||0)===0);
  T('alice sees read receipts (✓✓)', /message-status read/.test(A.els['messages-container'].innerHTML) || /message-status delivered/.test(A.els['messages-container'].innerHTML));

  // live message while chat open
  B.els['message-input'].value='reply from bob'; await B.__T.sendMessage(); await sleep(300);
  T('alice receives bob live', A.els['messages-container'].innerHTML.includes('reply from bob'));

  // group
  A.document.getElementById('group-name').value='Team'; A.__T.S.selectedGroupUsers.add('UB'); A.__T.S.selectedGroupUsers.add('UC');
  await A.__T.createGroup(); await sleep(400);
  const gid=Object.keys(DB.data.chats).find(k=>DB.data.chats[k].type==='group');
  T('group created', !!gid);
  T('all members indexed in group', !!gid && ['UA','UB','UC'].every(u=>DB.data.userChats?.[u]?.[gid]===true));
  await sleep(300);
  T('carol group index exists', DB.data.userChats?.UC?.[gid]===true);
  C.__T.S.activeChat=null; await C.__T.openChat(gid); C.document.getElementById('message-input').value='hello team'; await C.__T.sendMessage(); await sleep(300);
  T('group message stored', Object.values(DB.data.messages?.[gid]||{}).some(m=>m.text==='hello team'));

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail?1:0);
})().catch(e=>{console.error('HARNESS ERROR',e);process.exit(2);});
