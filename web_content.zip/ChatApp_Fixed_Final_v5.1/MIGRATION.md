# Migration from ChatApp v2

الإصدار القديم كان يعتمد على Anonymous Auth مع اسم مستخدم/كلمة مرور محفوظة في Realtime Database بترميز Base64. هذا ليس نظام كلمات مرور آمناً، ولا يمكن تحويل تلك كلمات المرور إلى Firebase Auth بشكل آمن من المتصفح.

## المسار الآمن
- احتفظ بتصدير قاعدة البيانات القديمة كنسخة أرشيفية.
- فعّل Email/Password في Firebase Authentication.
- انشر `database.rules.json`.
- استخدم ChatApp v3 لإنشاء الحسابات من جديد، خصوصاً الحساب `data` الذي يبدأ ملكية المشروع.

## لماذا لم أضع مهاجر كلمات المرور داخل HTML؟
لأن ذلك سيعيد المشكلة نفسها: أي سر موجود في JavaScript/RTDB يمكن استخراجه من العميل. نقل الحسابات القديمة مع الحفاظ على كلمات مرورها يحتاج مساراً خادمياً موثوقاً باستخدام Firebase Admin SDK أو آلية استيراد رسمية للهوية.

يمكن بعد ذلك كتابة مهاجر بيانات إداري يربط UIDs القديمة بالجديدة وينقل الرسائل والقصص مع خريطة ثابتة للمعرفات.

## ملاحظة عن القصص
في الإصدار 3 أصبحت بيانات القصة في `storyContents/{storyId}` بينما تبقى `stories/{storyId}` للبيانات الوصفية؛ هذا يمنع تنزيل الوسائط لكل المستخدمين عند فتح شريط القصص.

## v4
- أضيف `users/{uid}/registrationComplete` لمنع حسابات التسجيل الجزئي.
- أصبح التسجيل متسلسلاً بدلاً من multi-location update.
- أضيفت حقول `showLastSeen` و`showOnline` داخل `users/{uid}/settings`.
- القصص العادية تُقرأ باستعلام `expiresAt` محدود.
- إصلاح سباق `onAuthStateChanged` أثناء إنشاء الحساب.
- إصلاح إنشاء المحادثة الخاصة بحيث لا يقرأ المستخدم `/chats/{id}` قبل أن يصبح عضواً.

## final registration integrity
- `registrationComplete` can only switch false → true after the username index, profile, presence, and device link already exist.
- Profile validation now depends on the user's canonical username in `users/{uid}`, not a cross-node username lookup.
- Owner transfer permits the current owner to become admin during the same multi-location write.

## final final registration ordering
- `registrationComplete` is written last, after Auth, user, username index, profile, presence, device link, configuration and owner bootstrap succeed.
- Once completion is committed, later session initialization cannot trigger database cleanup of the complete account; the account remains recoverable through normal login.
- Client data-URL checks now match the 2,800,000-character RTDB limit exactly.

## final username diagnostics
- The username index is checked before attempting to reserve it, so an occupied username is reported as such instead of looking like a generic RTDB permission failure.

## final error-state reliability
- Auth/database failure messages survive the Auth sign-out callback instead of being cleared by the auth-screen reset.
- Incomplete-registration cleanup catches both synchronous and asynchronous failures.
- The initial owner bootstrap is no longer silently ignored while an account is being registered.

## Final cleanup hardening
- Registration rollback only removes the username index when that index already belongs to the new UID.
