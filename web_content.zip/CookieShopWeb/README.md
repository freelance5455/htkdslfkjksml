# Cookie Shop (web app)

A simple app for a chocolate chip cookie business. It tracks:

- **Stock**: cookie types, price each, how many are left, and the value of what you hold.
- **Customers**: name, number of orders and how much each has spent.
- **Sales**: pick customer, cookie, quantity and how they paid (cash or mobile money). Stock drops automatically.
- **Home**: cookies in stock, customers, total sales, sales today, and cash vs mobile money totals.

No installation, no internet needed after the first load, no accounts.

## Try it on a computer

Unzip the folder and double-click `index.html`.

## Use it on an Android 9 phone

The easiest way is to put the folder online once (free), then open that link in Chrome on the phone:

- **Netlify Drop**: go to app.netlify.com/drop and drag the unzipped `CookieShopWeb` folder onto the page. You get a link.
- or **GitHub Pages**, or any web hosting.

Then in Chrome on the phone: open the link, tap the menu (three dots), choose **Add to Home screen**. It gets the cookie icon and opens like an app, and works offline afterwards.

(Opening `index.html` straight from the phone's files also works, but without the home screen icon and offline caching.)

## Your data

Data is saved inside the browser on that device only. It is not shared between phones or computers.

- Clearing browser data for the site deletes it.
- On the Home screen, use **Download backup** now and then, and **Restore backup** to load it back (or move it to another device).

## Settings

At the top of `app.js`:

- `CURRENCY` is the symbol shown with amounts (default `K`).
- `PAYMENTS` is the list of payment choices (default Cash, Mobile money). Add more names there and they show up on sales and the Sales totals. The Home screen shows a card for each.

The app starts with one product, "Chocolate chip cookie", at price 0. Open **Stock**, tap it, and choose **Change price**.
