"use strict";

/* ---------- Settings you may want to change ---------- */
const CURRENCY = "K";                       // e.g. "K", "$", "R"
const PAYMENTS = ["Cash", "Mobile money"];  // payment choices on each sale
/* ----------------------------------------------------- */

const KEY = "cookieshop.v1";

/* ---------- Data ---------- */
let data = load();

function load() {
  try {
    const d = JSON.parse(localStorage.getItem(KEY));
    if (d && Array.isArray(d.products) && Array.isArray(d.customers) && Array.isArray(d.sales)) return d;
  } catch (e) { /* fall through to a fresh start */ }
  return {
    products: [{ id: uid(), name: "Chocolate chip cookie", price: 0, qty: 0 }],
    customers: [],
    sales: []
  };
}

function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch (e) {
    toast("Could not save. Is browser storage blocked or full?");
  }
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/* ---------- Helpers ---------- */
const $ = (s) => document.querySelector(s);

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function money(v) {
  return CURRENCY + " " + Number(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function when(ts) {
  return new Date(ts).toLocaleString([], { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function sum(arr, f) {
  return arr.reduce((a, x) => a + f(x), 0);
}

let toastTimer;
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2500);
}

/* ---------- Dialogs ---------- */
const dlg = $("#dlg");

function openDialog(build) {
  dlg.innerHTML = "";
  build(dlg);
  if (!dlg.open) dlg.showModal();
}

function closeDialog() {
  if (dlg.open) dlg.close();
}

function mk(tag, props, text) {
  const e = document.createElement(tag);
  if (props) Object.assign(e, props);
  if (text != null) e.textContent = text;
  return e;
}

/** fields: [{name, label, type:'text'|'number'|'select', value, options:[{value,label}], min, step}] */
function formDialog(title, fields, okLabel, onOk, intro) {
  openDialog((d) => {
    const form = mk("form");
    form.appendChild(mk("h3", null, title));
    if (intro) form.appendChild(mk("p", null, intro));
    const inputs = {};
    fields.forEach((f) => {
      const label = mk("label", null, f.label);
      let input;
      if (f.type === "select") {
        input = mk("select");
        f.options.forEach((o) => input.appendChild(mk("option", { value: o.value }, o.label)));
        if (f.value != null) input.value = f.value;
      } else {
        input = mk("input", { type: f.type || "text" });
        if (f.type === "number") {
          input.min = f.min != null ? f.min : "0";
          input.step = f.step || "any";
          input.inputMode = f.step === "1" ? "numeric" : "decimal";
        }
        if (f.value != null) input.value = f.value;
        if (f.placeholder) input.placeholder = f.placeholder;
      }
      inputs[f.name] = input;
      label.appendChild(input);
      form.appendChild(label);
    });
    const err = mk("div", { className: "err" });
    form.appendChild(err);
    const row = mk("div", { className: "row" });
    const cancel = mk("button", { type: "button", className: "btn alt" }, "Cancel");
    cancel.onclick = closeDialog;
    row.appendChild(cancel);
    row.appendChild(mk("button", { type: "submit", className: "btn" }, okLabel));
    form.appendChild(row);
    form.onsubmit = (ev) => {
      ev.preventDefault();
      const values = {};
      Object.keys(inputs).forEach((k) => (values[k] = inputs[k].value.trim()));
      const problem = onOk(values);
      if (problem) err.textContent = problem;
      else closeDialog();
    };
    d.appendChild(form);
    const first = form.querySelector("input, select");
    if (first) setTimeout(() => first.focus(), 30);
  });
}

function menuDialog(title, items) {
  openDialog((d) => {
    d.appendChild(mk("h3", null, title));
    items.forEach((it) => {
      const b = mk("button", { type: "button", className: "btn " + (it.danger ? "danger" : "alt") }, it.label);
      b.onclick = () => {
        closeDialog();
        it.run();
      };
      d.appendChild(b);
    });
    const c = mk("button", { type: "button", className: "btn alt" }, "Close");
    c.onclick = closeDialog;
    d.appendChild(c);
  });
}

function confirmDialog(message, yesLabel, onYes) {
  openDialog((d) => {
    d.appendChild(mk("h3", null, "Are you sure?"));
    d.appendChild(mk("p", null, message));
    const row = mk("div", { className: "row" });
    const no = mk("button", { type: "button", className: "btn alt" }, "Cancel");
    no.onclick = closeDialog;
    const yes = mk("button", { type: "button", className: "btn danger" }, yesLabel);
    yes.onclick = () => {
      closeDialog();
      onYes();
    };
    row.append(no, yes);
    d.appendChild(row);
  });
}

/* ---------- Views ---------- */
let tab = "home";

function render() {
  document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === tab));
  const view = $("#view");
  ({ home: renderHome, sales: renderSales, stock: renderStock, customers: renderCustomers }[tab])(view);
  window.scrollTo(0, 0);
}

function listHtml(rows, emptyText) {
  if (!rows.length) return `<div class="empty">${esc(emptyText)}</div>`;
  return (
    '<ul class="list">' +
    rows
      .map((r, i) => `<li data-i="${i}"><div class="t">${esc(r.t)}</div><div class="s">${esc(r.s)}</div></li>`)
      .join("") +
    "</ul>"
  );
}

function wireList(view, handler) {
  view.querySelectorAll(".list li").forEach((li) => {
    li.onclick = () => handler(Number(li.dataset.i));
  });
}

/* Home */
function renderHome(view) {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const total = sum(data.sales, (s) => s.total);
  const today = sum(data.sales.filter((s) => s.ts >= startOfDay.getTime()), (s) => s.total);
  const stockCount = sum(data.products, (p) => p.qty);

  const pay = PAYMENTS.map(
    (m) =>
      `<div class="card"><div class="big">${money(sum(data.sales.filter((s) => s.payment === m), (s) => s.total))}</div><div class="lbl">${esc(m)}</div></div>`
  ).join("");

  view.innerHTML = `
    <div class="grid">
      <div class="card"><div class="big">${stockCount}</div><div class="lbl">Cookies in stock</div></div>
      <div class="card"><div class="big">${data.customers.length}</div><div class="lbl">Customers</div></div>
      <div class="card"><div class="big">${money(total)}</div><div class="lbl">Total sales</div></div>
      <div class="card"><div class="big">${money(today)}</div><div class="lbl">Sales today</div></div>
    </div>
    <h2 class="sec">How customers paid</h2>
    <div class="grid">${pay}</div>
    <button class="btn" id="newSale">New sale</button>
    <h2 class="sec">Backup</h2>
    <div class="grid">
      <button class="btn alt" id="exp" style="margin-top:0">Download backup</button>
      <button class="btn alt" id="imp" style="margin-top:0">Restore backup</button>
    </div>
    <input type="file" id="file" accept="application/json,.json" hidden>
    <p class="note">Your data is saved in this browser on this device only. Download a backup now and then, and before clearing browser data.</p>`;

  $("#newSale").onclick = newSale;
  $("#exp").onclick = exportBackup;
  $("#imp").onclick = () => $("#file").click();
  $("#file").onchange = importBackup;
}

function exportBackup() {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = mk("a", { href: URL.createObjectURL(blob), download: "cookieshop-backup-" + new Date().toISOString().slice(0, 10) + ".json" });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

function importBackup(ev) {
  const file = ev.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const d = JSON.parse(reader.result);
      if (!d || !Array.isArray(d.products) || !Array.isArray(d.customers) || !Array.isArray(d.sales)) throw new Error("bad file");
      confirmDialog("This replaces everything currently in the app with the backup.", "Restore", () => {
        data = d;
        save();
        render();
        toast("Backup restored");
      });
    } catch (e) {
      toast("That is not a Cookie Shop backup file");
    }
  };
  reader.readAsText(file);
  ev.target.value = "";
}

/* Stock */
function renderStock(view) {
  const items = [...data.products].sort((a, b) => a.name.localeCompare(b.name));
  const rows = items.map((p) => ({ t: p.name, s: `${p.qty} in stock  |  ${money(p.price)} each` }));
  view.innerHTML = `
    <div class="summary">${sum(items, (p) => p.qty)} cookies in stock<br>Stock value ${money(sum(items, (p) => p.qty * p.price))}</div>
    ${listHtml(rows, "No cookie types yet.")}
    <button class="btn" id="add">Add cookie type</button>`;
  $("#add").onclick = addProduct;
  wireList(view, (i) => productMenu(items[i]));
}

function addProduct() {
  formDialog(
    "New cookie type",
    [
      { name: "name", label: "Name (e.g. Chocolate chip)" },
      { name: "price", label: "Price each", type: "number" },
      { name: "qty", label: "Starting quantity", type: "number", step: "1", value: "0" }
    ],
    "Save",
    (v) => {
      const price = parseFloat(v.price);
      const qty = parseInt(v.qty || "0", 10);
      if (!v.name || isNaN(price) || price < 0) return "Enter a name and a price";
      if (isNaN(qty) || qty < 0) return "Quantity must be 0 or more";
      data.products.push({ id: uid(), name: v.name, price, qty });
      save();
      render();
    }
  );
}

function productMenu(p) {
  menuDialog(p.name, [
    { label: "Add stock (baked)", run: () => changeStock(p, 1) },
    { label: "Remove stock (spoiled / given away)", run: () => changeStock(p, -1) },
    { label: "Change price", run: () => changePrice(p) },
    {
      label: "Delete",
      danger: true,
      run: () =>
        confirmDialog(`Delete ${p.name}? Past sales are kept.`, "Delete", () => {
          data.products = data.products.filter((x) => x.id !== p.id);
          save();
          render();
        })
    }
  ]);
}

function changeStock(p, sign) {
  formDialog(
    (sign > 0 ? "Add stock: " : "Remove stock: ") + p.name,
    [{ name: "n", label: "Quantity", type: "number", step: "1" }],
    "OK",
    (v) => {
      const n = parseInt(v.n, 10);
      if (isNaN(n) || n <= 0) return "Enter a number above 0";
      if (p.qty + sign * n < 0) return `Only ${p.qty} in stock`;
      p.qty += sign * n;
      save();
      render();
    }
  );
}

function changePrice(p) {
  formDialog("Price: " + p.name, [{ name: "price", label: "Price each", type: "number", value: p.price }], "Save", (v) => {
    const price = parseFloat(v.price);
    if (isNaN(price) || price < 0) return "Enter a valid price";
    p.price = price;
    save();
    render();
  });
}

/* Customers */
function customerStats(c) {
  const mine = data.sales.filter((s) => s.customerId === c.id);
  return { orders: mine.length, spent: sum(mine, (s) => s.total) };
}

function renderCustomers(view) {
  const items = [...data.customers].sort((a, b) => a.name.localeCompare(b.name));
  const rows = items.map((c) => {
    const st = customerStats(c);
    return { t: c.name, s: `${st.orders} orders  |  ${money(st.spent)} spent` };
  });
  const spent = sum(items, (c) => customerStats(c).spent);
  view.innerHTML = `
    <div class="summary">${items.length} customers<br>Total spent ${money(spent)}</div>
    ${listHtml(rows, "No customers yet.")}
    <button class="btn" id="add">Add customer</button>`;
  $("#add").onclick = addCustomer;
  wireList(view, (i) => customerMenu(items[i]));
}

function addCustomer() {
  formDialog("New customer", [{ name: "name", label: "Name" }], "Save", (v) => {
    if (!v.name) return "Enter a name";
    data.customers.push({ id: uid(), name: v.name });
    save();
    render();
  });
}

function customerMenu(c) {
  menuDialog(c.name, [
    { label: "Record a sale", run: () => newSale(c.id) },
    {
      label: "Delete customer",
      danger: true,
      run: () =>
        confirmDialog(`Delete ${c.name}? Their past sales stay in the sales list.`, "Delete", () => {
          data.customers = data.customers.filter((x) => x.id !== c.id);
          save();
          render();
        })
    }
  ]);
}

/* Sales */
function renderSales(view) {
  const items = [...data.sales].sort((a, b) => b.ts - a.ts);
  const rows = items.map((s) => ({
    t: `${s.qty} x ${s.product} - ${money(s.total)}`,
    s: `${s.customer}  |  ${s.payment}  |  ${when(s.ts)}`
  }));
  const byPay = PAYMENTS.map((m) => `${m} ${money(sum(items.filter((s) => s.payment === m), (s) => s.total))}`).join("  |  ");
  view.innerHTML = `
    <div class="summary">${items.length} sales  |  Total ${money(sum(items, (s) => s.total))}<br>${esc(byPay)}</div>
    ${listHtml(rows, "No sales yet.")}
    <button class="btn" id="add">New sale</button>`;
  $("#add").onclick = () => newSale();
  wireList(view, (i) => {
    const s = items[i];
    confirmDialog(`Delete this sale of ${s.qty} x ${s.product}? The cookies go back into stock.`, "Delete", () => {
      const p = data.products.find((x) => x.id === s.productId);
      if (p) p.qty += s.qty;
      data.sales = data.sales.filter((x) => x.id !== s.id);
      save();
      render();
    });
  });
}

function newSale(customerId) {
  if (typeof customerId !== "string") customerId = "";
  const available = data.products.filter((p) => p.qty > 0);
  if (!available.length) {
    toast("No cookies in stock. Add stock first.");
    return;
  }
  const customers = [{ value: "", label: "Walk-in customer" }].concat(
    [...data.customers].sort((a, b) => a.name.localeCompare(b.name)).map((c) => ({ value: c.id, label: c.name }))
  );
  formDialog(
    "New sale",
    [
      { name: "customer", label: "Customer", type: "select", options: customers, value: customerId },
      {
        name: "product",
        label: "Cookie",
        type: "select",
        options: available.map((p) => ({ value: p.id, label: `${p.name} - ${money(p.price)} (${p.qty} left)` }))
      },
      { name: "qty", label: "Quantity", type: "number", step: "1", value: "1", min: "1" },
      { name: "payment", label: "How did they pay?", type: "select", options: PAYMENTS.map((m) => ({ value: m, label: m })) }
    ],
    "Sell",
    (v) => {
      const p = data.products.find((x) => x.id === v.product);
      const qty = parseInt(v.qty, 10);
      if (!p) return "Pick a cookie";
      if (isNaN(qty) || qty <= 0) return "Enter a quantity above 0";
      if (qty > p.qty) return `Only ${p.qty} in stock`;
      const c = data.customers.find((x) => x.id === v.customer);
      const total = Math.round(p.price * qty * 100) / 100;
      data.sales.push({
        id: uid(),
        customerId: c ? c.id : null,
        customer: c ? c.name : "Walk-in customer",
        productId: p.id,
        product: p.name,
        qty,
        total,
        ts: Date.now(),
        payment: v.payment
      });
      p.qty -= qty;
      save();
      render();
      toast(`Sold: ${money(total)} (${v.payment})`);
    }
  );
}

/* ---------- Start ---------- */
document.querySelectorAll("#tabs button").forEach((b) => {
  b.onclick = () => {
    tab = b.dataset.tab;
    render();
  };
});

render();

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}
