MADAN OCTAPAD - Android Studio Project

यह Android ऐप का source project है; यह तैयार APK नहीं है।

APK बनाने के लिए:
1. Android Studio कंप्यूटर पर install करें।
2. इस ZIP को extract करें।
3. Android Studio में 'Open' चुनकर MadanOctapad folder खोलें।
4. Gradle sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/ में मिलेगा।

ध्यान दें: पहली बार Gradle को Android SDK और इंटरनेट की जरूरत हो सकती है।
