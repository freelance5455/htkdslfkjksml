/* Public browser configuration only. Never put the Supabase service-role key here. */
window.SPEK_CONFIG = {
  supabaseUrl: "https://vvcmcgrfhhkwylvmjiei.supabase.co",
  supabaseAnonKey: "sb_publishable_R4XwtBkeJYtCoZT28rnHAQ_wFsaukF0",
  siteUrl: window.location.origin
};
