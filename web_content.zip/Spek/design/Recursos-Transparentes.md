# Recursos transparentes do Spek

- `assets/resources/gem-crystal.png`: gema recortada da referência enviada.
- `assets/resources/life-heart.png`: coração de vida recortado da referência enviada.
- `assets/cuants/cuant-01.png` a `cuant-10.png`: medalhas Cuants sem os fundos escuros da referência.
- `assets/mascots/transparent/*.png`: mascotes originais sem o fundo branco; o arquivo principal mostra só a vista frontal, como solicitado.
- Níveis Cuants mostrados na interface: 1, 5, 10, 20, 30, 50, 75, 100, 180 e 365 dias.

`Recursos-Transparentes.png` é uma folha de conferência com quadriculado para mostrar a transparência; esse quadriculado não está nos PNGs de uso do app.
