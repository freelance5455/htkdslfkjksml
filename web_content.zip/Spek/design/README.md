# Spek — visual board

`Spek-Visual-Board.svg` is an editable vector artboard for the coral / blush / cream / plum visual system. It previews the home, lesson, and avatar surfaces. `Spek-Visual-Board.png` is a rendered preview.

The four mascot images embedded in the vector board and included under `../assets/mascots/` are exact copies of the four images supplied by the user. They remain complete, unretouched, uncropped, and with all visible marks/watermarks intact. The interface icon drawings and the user-avatar illustration are separate from those mascot references.

This is an SVG design package, not a Photoshop PSD.