const CACHE='spek-call-avatar-voice-v14';
const FILES=['./','./index.html','./manifest.json','./css/styles.css','./js/app.js','./assets/logo.svg','./assets/flame.svg','./assets/heart.svg','./assets/star.svg','./assets/sound.svg','./assets/spek-brand.svg','./assets/fonts/Fredoka-SemiBold.ttf','./assets/fonts/Nunito-Regular.ttf','./assets/fonts/Nunito-Bold.ttf','./assets/icons/spek.svg','./assets/resources/gem-crystal.png','./assets/resources/life-heart.png','./assets/cuants/cuant-01.png','./assets/cuants/cuant-02.png','./assets/cuants/cuant-03.png','./assets/cuants/cuant-04.png','./assets/cuants/cuant-05.png','./assets/cuants/cuant-06.png','./assets/cuants/cuant-07.png','./assets/cuants/cuant-08.png','./assets/cuants/cuant-09.png','./assets/cuants/cuant-10.png','./assets/mascots/transparent/spek-main.png','./assets/mascots/transparent/lumo-drake.png','./assets/mascots/transparent/pipo-chick.png','./assets/mascots/transparent/lina-sapo.png'];
const STATIC_URLS=new Set(FILES.map(path=>new URL(path,self.location.href).href));
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('spek-')&&k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const url=new URL(e.request.url);
  if(url.origin!==self.location.origin||!STATIC_URLS.has(url.href))return;
  e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{
    if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy))}
    return r;
  })));
});
