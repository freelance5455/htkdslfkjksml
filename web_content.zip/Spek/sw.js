const CACHE='spek-v2';
const FILES=['./','./index.html','./manifest.json','./css/styles.css','./js/app.js','./assets/logo.svg','./assets/mascot.svg','./assets/mascot-3d.png','./assets/flame.svg','./assets/heart.svg','./assets/star.svg','./assets/sound.svg','./assets/spek-brand.svg','./assets/fonts/Fredoka-SemiBold.ttf','./assets/fonts/Nunito-Regular.ttf','./assets/fonts/Nunito-Bold.ttf'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r}).catch(()=>caches.match('./index.html'))))});
