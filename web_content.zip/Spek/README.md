# Spek — aprendizagem gratuita de idiomas

O Spek oferece cursos iniciais de inglês, espanhol, francês, italiano, alemão, japonês e coreano. Não há anúncios pagos, checkout, assinatura nem compras com dinheiro real. As gemas são virtuais: **100 gemas são creditadas uma vez por dia por conta**, quando a pessoa entra; servem para recarregar vidas e desbloquear estilos.

## Estado desta entrega
- O pacote está configurado para o projeto Supabase escolhido pelo proprietário.
- O esquema do Spek, as políticas RLS, a carteira inicial com zero gemas, o crédito diário no fuso `America/Sao_Paulo` e o catálogo de estilos foram criados no projeto.
- A Edge Function autenticada `spek-api` foi publicada. Ela valida a sessão e executa as operações de gemas/vidas/estilos no servidor.
- `config.js` contém apenas a URL do projeto e sua chave pública/publishable. **Não contém a chave privada `service_role`.**
- A interface mantém as imagens originais dos mascotes fornecidas pelo usuário, sem redesenhá-las; agora usa PNGs transparentes e exibe somente a vista frontal do mascote principal, preservando a marca-d’água original.
- Gemas, vidas e dez emblemas de Cuants também estão em PNG transparente. Os níveis visuais aparecem em 1, 5, 10, 20, 30, 50, 75, 100, 180 e 365 dias.
- A paleta coral/blush/cream/plum, os ícones SVG e as animações são mudanças visuais; não houve alteração da lógica de negócio nesta entrega.
- O app ainda não está publicado e não foi testado com uma conta de aprendiz. Falta escolher/configurar um domínio HTTPS para hospedagem e ajustar as URLs de autenticação para esse domínio.

## Publicar o app
1. Hospede a pasta `Spek/` em um serviço de arquivos estáticos com HTTPS.
2. No Supabase, abra **Authentication → URL Configuration** e configure o domínio hospedado como Site URL e nas Redirect URLs, incluindo a rota de confirmação de e-mail.
3. Abra o Spek no domínio e teste cadastro, confirmação de e-mail, login e a recompensa diária. Cada conta recebe 100 gemas apenas uma vez por data no fuso de São Paulo, mesmo se recarregar ou entrar novamente.

O pacote inclui `supabase/migrations/202609260001_spek.sql` e `supabase/functions/spek-api/index.ts` como cópia do esquema/código para manutenção. Não execute novamente a migração no projeto já configurado; ela é para um projeto Supabase novo.

## Design editável
- `design/Spek-Visual-Board.svg` é um quadro vetorial editável (abre em Illustrator, Figma e apps compatíveis com SVG); `design/Spek-Visual-Board.png` é a prévia. Não é um PSD.

## O que inclui
- Cadastro e login por e-mail e senha com Supabase Auth; progresso sincronizado na nuvem.
- 100 gemas diárias gratuitas, vidas, Cuants, missões, mascotes, animações, áudio e música instrumental opcional.
- Nova área **Falar**: aula guiada em formato de chamada visual com Spek, perguntas faladas e resposta por microfone quando o navegador oferecer reconhecimento de voz; inclui alternativa digitada e não repete frases até completar o ciclo do idioma.
- Leitura de pronúncia com o idioma selecionado, editor de avatar com seis categorias e 120 opções por categoria, além de salvar/restaurar o visual.

## Privacidade e segurança
A chave pública/publishable no `config.js` foi projetada para uso no navegador e depende das políticas RLS. A chave `service_role` nunca deve ir para o navegador, HTML, JavaScript, ZIP ou chat. O saldo, a recompensa diária, as vidas e os estilos são alterados no servidor após validar a sessão.
