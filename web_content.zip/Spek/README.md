# Spek — app demonstrativo para aprender idiomas

Protótipo web responsivo, com identidade visual própria e tipografia arredondada, mascote de coelho 3D, lições rápidas, vidas e sequência diária **Cuants**. Os dados são mantidos localmente no navegador.

## Abrir
Extraia `Spek.zip` e abra `index.html` em um navegador moderno. Não precisa instalar bibliotecas.

## Recursos
- Cadastro e login demonstrativos com nome, e-mail e senha; a senha fica armazenada como hash PBKDF2/SHA-256 no navegador.
- 5 vidas; cada erro desconta uma. Uma vida volta a cada 4 horas.
- Cuants conta os dias seguidos em que houve lição concluída.
- Lições, áudio do navegador, pontuação, vocabulário, progresso e animações personalizadas.
- Editor com seis categorias de avatar, cada uma com 120 opções: pele, cabelo, cor do cabelo, acessório, rosto e roupa.
- Mascote 3D e fonte Fredoka incluídos localmente.
- Manifesto e service worker para instalação/cache em HTTPS ou localhost.

## Limites do protótipo
Cadastro, login e progresso não usam servidor e não sincronizam entre aparelhos. Não há recuperação de senha. Para um lançamento público, conecte uma solução de autenticação e banco de dados, e revise as práticas de segurança e privacidade.
