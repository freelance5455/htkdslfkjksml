import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);
  try {
    const authorization = req.headers.get("Authorization") || "";
    if (!authorization.startsWith("Bearer ")) return json({ error: "Faça login para continuar." }, 401);
    const url = Deno.env.get("SUPABASE_URL");
    const anon = Deno.env.get("SUPABASE_ANON_KEY");
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !anon || !service) return json({ error: "O backend Supabase não está configurado." }, 500);

    const userClient = createClient(url, anon, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { headers: { Authorization: authorization } },
    });
    const { data: auth, error: authError } = await userClient.auth.getUser();
    if (authError || !auth.user) return json({ error: "Sua sessão expirou. Entre novamente." }, 401);
    const body = await req.json().catch(() => ({}));
    const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });
    const userId = auth.user.id;
    let rpc: string;
    let params: Record<string, unknown> = { p_user_id: userId };

    switch (body.action) {
      case "claim-daily-gems": rpc = "spek_claim_daily_gems"; break;
      case "purchase-lives": rpc = "spek_purchase_lives"; break;
      case "lose-heart": rpc = "spek_lose_heart"; break;
      case "refresh-hearts": rpc = "spek_refresh_hearts"; break;
      case "purchase-avatar-style":
        if (typeof body.style_id !== "string") return json({ error: "Estilo inválido." }, 400);
        rpc = "spek_purchase_avatar_style";
        params = { ...params, p_style_id: body.style_id };
        break;
      case "save-avatar":
        if (!body.avatar || typeof body.avatar !== "object" || Array.isArray(body.avatar)) return json({ error: "O avatar enviado é inválido." }, 400);
        rpc = "spek_save_avatar";
        params = { ...params, p_avatar: body.avatar };
        break;
      default: return json({ error: "Operação desconhecida." }, 400);
    }

    const { data, error } = await admin.rpc(rpc, params);
    if (error) {
      const message = error.message || "Não foi possível concluir a operação.";
      const known: Record<string, string> = {
        insufficient_gems: "Você não tem gemas suficientes.",
        lives_full: "Suas vidas já estão completas.",
        style_not_found: "Esse estilo não está disponível.",
        style_not_owned: "Esse estilo precisa ser desbloqueado com gemas antes de equipá-lo.",
        wallet_not_found: "A carteira da conta não foi encontrada.",
        progress_not_found: "O progresso da conta não foi encontrado.",
      };
      const friendly = Object.entries(known).find(([key]) => message.includes(key))?.[1] || "Não foi possível concluir a operação.";
      return json({ error: friendly }, 400);
    }
    return json(data);
  } catch {
    return json({ error: "Não foi possível concluir a operação. Tente novamente." }, 400);
  }
});
