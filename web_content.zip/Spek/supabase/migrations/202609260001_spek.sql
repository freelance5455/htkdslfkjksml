-- Spek: free language learning, cloud accounts, and daily virtual gem rewards.
-- Apply once to a new Spek Supabase project.
create extension if not exists pgcrypto;

create table public.user_progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Aprendiz', language text,
  completed jsonb not null default '[]'::jsonb, xp integer not null default 0 check (xp >= 0),
  hearts smallint not null default 5 check (hearts between 0 and 5), last_heart_at bigint not null default 0,
  streak integer not null default 0 check (streak >= 0), last_date date,
  daily jsonb not null default '{}'::jsonb, known jsonb not null default '[]'::jsonb,
  sound boolean not null default true, music boolean not null default false, dark boolean not null default false,
  avatar jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  gems integer not null default 0 check (gems >= 0),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table public.daily_gem_claims (
  user_id uuid not null references auth.users(id) on delete cascade,
  claim_date date not null,
  gems integer not null default 100 check (gems = 100),
  claimed_at timestamptz not null default now(),
  primary key(user_id,claim_date)
);

create table public.avatar_styles (
  id text primary key, name text not null,
  kind text not null check (kind in ('accessory','hairColor','outfit')),
  value integer not null check (value between 0 and 119),
  price_gems integer not null check (price_gems > 0), description text not null default '',
  emoji text not null default '✨', active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.user_styles (
  user_id uuid not null references auth.users(id) on delete cascade,
  style_id text not null references public.avatar_styles(id),
  purchased_at timestamptz not null default now(), primary key(user_id,style_id)
);

create or replace function public.spek_create_account_rows()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.user_progress(user_id,display_name)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name','Aprendiz')) on conflict(user_id) do nothing;
  insert into public.wallets(user_id,gems) values(new.id,0) on conflict(user_id) do nothing;
  return new;
end;
$$;
drop trigger if exists spek_create_account_rows on auth.users;
create trigger spek_create_account_rows after insert on auth.users
for each row execute procedure public.spek_create_account_rows();

insert into public.user_progress(user_id,display_name)
select id,coalesce(raw_user_meta_data->>'full_name','Aprendiz') from auth.users on conflict(user_id) do nothing;
insert into public.wallets(user_id,gems) select id,0 from auth.users on conflict(user_id) do nothing;

insert into public.avatar_styles(id,name,kind,value,price_gems,description,emoji) values
 ('star-bow','Laço Estelar','accessory',26,35,'Um laço lilás com brilho de estrela.','🎀'),
 ('sun-crown','Coroa Solar','accessory',78,50,'Um toque dourado para missões especiais.','👑'),
 ('rainbow-hair','Cabelo Nebulosa','hairColor',103,45,'Cores vibrantes para um visual único.','🌈'),
 ('space-suit','Look Galáxia','outfit',89,60,'Uma roupa de explorador das estrelas.','🚀'),
 ('mint-jacket','Jaqueta Menta','outfit',33,40,'Uma cor refrescante para o seu avatar.','🧥'),
 ('lavender-wave','Ondas Lavanda','hairColor',87,40,'Um tom mágico para colorir o cabelo.','💜')
on conflict(id) do update set name=excluded.name,kind=excluded.kind,value=excluded.value,price_gems=excluded.price_gems,description=excluded.description,emoji=excluded.emoji,active=true;

alter table public.user_progress enable row level security;
alter table public.wallets enable row level security;
alter table public.daily_gem_claims enable row level security;
alter table public.avatar_styles enable row level security;
alter table public.user_styles enable row level security;
drop policy if exists "read own progress" on public.user_progress;
create policy "read own progress" on public.user_progress for select to authenticated using(auth.uid()=user_id);
drop policy if exists "update own progress" on public.user_progress;
create policy "update own progress" on public.user_progress for update to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
drop policy if exists "read own wallet" on public.wallets;
create policy "read own wallet" on public.wallets for select to authenticated using(auth.uid()=user_id);
drop policy if exists "read active styles" on public.avatar_styles;
create policy "read active styles" on public.avatar_styles for select to anon,authenticated using(active=true);
drop policy if exists "read own styles" on public.user_styles;
create policy "read own styles" on public.user_styles for select to authenticated using(auth.uid()=user_id);

revoke all on public.user_progress,public.wallets,public.daily_gem_claims,public.avatar_styles,public.user_styles from anon,authenticated;
grant select on public.user_progress,public.wallets,public.user_styles to authenticated;
grant select on public.avatar_styles to anon,authenticated;
grant update(display_name,language,completed,xp,streak,last_date,daily,known,sound,music,dark,updated_at) on public.user_progress to authenticated;
grant all on public.user_progress,public.wallets,public.daily_gem_claims,public.avatar_styles,public.user_styles to service_role;

create or replace function public.spek_claim_daily_gems(p_user_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_date date; v_inserted integer; v_balance integer;
begin
  v_date=(now() at time zone 'America/Sao_Paulo')::date;
  insert into public.daily_gem_claims(user_id,claim_date,gems) values(p_user_id,v_date,100) on conflict(user_id,claim_date) do nothing;
  get diagnostics v_inserted=row_count;
  if v_inserted=1 then
    update public.wallets set gems=gems+100,updated_at=now() where user_id=p_user_id returning gems into v_balance;
  else
    select gems into v_balance from public.wallets where user_id=p_user_id;
  end if;
  if v_balance is null then raise exception 'wallet_not_found'; end if;
  return jsonb_build_object('claimed',v_inserted=1,'gems',v_balance,'claim_date',v_date);
end;
$$;

create or replace function public.spek_purchase_lives(p_user_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_gems integer; v_hearts integer;
begin
  select gems into v_gems from public.wallets where user_id=p_user_id for update;
  if not found then raise exception 'wallet_not_found'; end if;
  select hearts into v_hearts from public.user_progress where user_id=p_user_id for update;
  if v_hearts>=5 then raise exception 'lives_full'; end if;
  if v_gems<50 then raise exception 'insufficient_gems'; end if;
  update public.wallets set gems=gems-50,updated_at=now() where user_id=p_user_id returning gems into v_gems;
  update public.user_progress set hearts=5,last_heart_at=0,updated_at=now() where user_id=p_user_id;
  return jsonb_build_object('gems',v_gems,'hearts',5,'last_heart_at',0);
end;
$$;

create or replace function public.spek_purchase_avatar_style(p_user_id uuid,p_style_id text)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_style public.avatar_styles%rowtype; v_gems integer;
begin
  select * into v_style from public.avatar_styles where id=p_style_id and active=true for share;
  if not found then raise exception 'style_not_found'; end if;
  select gems into v_gems from public.wallets where user_id=p_user_id for update;
  if not found then raise exception 'wallet_not_found'; end if;
  if exists(select 1 from public.user_styles where user_id=p_user_id and style_id=p_style_id) then return jsonb_build_object('gems',v_gems,'owned',true,'style_id',p_style_id); end if;
  if v_gems<v_style.price_gems then raise exception 'insufficient_gems'; end if;
  update public.wallets set gems=gems-v_style.price_gems,updated_at=now() where user_id=p_user_id returning gems into v_gems;
  insert into public.user_styles(user_id,style_id) values(p_user_id,p_style_id);
  return jsonb_build_object('gems',v_gems,'owned',true,'style_id',p_style_id);
end;
$$;

create or replace function public.spek_save_avatar(p_user_id uuid,p_avatar jsonb)
returns jsonb language plpgsql security definer set search_path=public
as $$
begin
  if jsonb_typeof(p_avatar)<>'object' then raise exception 'invalid_avatar'; end if;
  if exists (select 1 from public.avatar_styles st where st.active=true and st.value=(p_avatar->>st.kind)::integer and not exists (select 1 from public.user_styles us where us.user_id=p_user_id and us.style_id=st.id)) then raise exception 'style_not_owned'; end if;
  update public.user_progress set avatar=p_avatar,updated_at=now() where user_id=p_user_id;
  if not found then raise exception 'progress_not_found'; end if;
  return p_avatar;
end;
$$;

create or replace function public.spek_lose_heart(p_user_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_hearts integer; v_last bigint; v_now bigint;
begin
  select hearts,last_heart_at into v_hearts,v_last from public.user_progress where user_id=p_user_id for update;
  if not found then raise exception 'progress_not_found'; end if;
  if v_hearts>0 then
    v_now=(extract(epoch from clock_timestamp())*1000)::bigint;
    if v_hearts=5 then v_last=v_now; end if;
    v_hearts=v_hearts-1;
    update public.user_progress set hearts=v_hearts,last_heart_at=coalesce(v_last,0),updated_at=now() where user_id=p_user_id;
  end if;
  return jsonb_build_object('hearts',v_hearts,'last_heart_at',coalesce(v_last,0));
end;
$$;

create or replace function public.spek_refresh_hearts(p_user_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_hearts integer; v_last bigint; v_now bigint; v_earned integer;
begin
  select hearts,last_heart_at into v_hearts,v_last from public.user_progress where user_id=p_user_id for update;
  if not found then raise exception 'progress_not_found'; end if;
  if v_hearts<5 and v_last>0 then
    v_now=(extract(epoch from clock_timestamp())*1000)::bigint;
    v_earned=floor((v_now-v_last)::numeric/14400000)::integer;
    if v_earned>0 then
      v_hearts=least(5,v_hearts+v_earned);
      if v_hearts=5 then v_last=0; else v_last=v_last+v_earned*14400000; end if;
      update public.user_progress set hearts=v_hearts,last_heart_at=v_last,updated_at=now() where user_id=p_user_id;
    end if;
  end if;
  return jsonb_build_object('hearts',v_hearts,'last_heart_at',coalesce(v_last,0));
end;
$$;

revoke all on function public.spek_claim_daily_gems(uuid),public.spek_purchase_lives(uuid),public.spek_purchase_avatar_style(uuid,text),public.spek_save_avatar(uuid,jsonb),public.spek_lose_heart(uuid),public.spek_refresh_hearts(uuid) from public,anon,authenticated;
grant execute on function public.spek_claim_daily_gems(uuid),public.spek_purchase_lives(uuid),public.spek_purchase_avatar_style(uuid,text),public.spek_save_avatar(uuid,jsonb),public.spek_lose_heart(uuid),public.spek_refresh_hearts(uuid) to service_role;
