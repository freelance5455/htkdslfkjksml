package com.personal.audvik

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AudvikAutomationService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        // When YT Create Studio opens under scheduled automation, assist with project creation
        if (pkg.contains("youtube.creator")) {
            val rootNode: AccessibilityNodeInfo = rootInActiveWindow ?: return
            findAndClickText(rootNode, "Create")
            findAndClickText(rootNode, "New project")
        }
    }

    private fun findAndClickText(node: AccessibilityNodeInfo, targetText: String) {
        val list = node.findAccessibilityNodeInfosByText(targetText)
        for (item in list) {
            if (item.isClickable) {
                item.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                break
            }
        }
    }

    override fun onInterrupt() {}
}
