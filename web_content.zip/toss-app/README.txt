CRICKET TOSS APP - APK banane ki hidayat
=========================================

Is folder mein kya hai
- index.html      : poori app (design, toss, commentary, sab kuch isi mein hai)
- manifest.json   : app ka naam, rang aur icons
- sw.js           : offline chalne ke liye (internet ke baghair bhi chale gi)
- icons/          : app ke icons (192, 512, maskable 512)

Pehle test kar lein
Folder ko phone ya computer ke browser (Chrome) mein index.html se kholein.
Toss, commentary aur settings sab check kar lein.

------------------------------------------------------------
TAREEQA 1: Android Studio + Capacitor (sab se pakka, offline APK)
------------------------------------------------------------
Zaroorat: Node.js aur Android Studio.

  mkdir cricket-toss && cd cricket-toss
  npm init -y
  npm install @capacitor/core @capacitor/cli @capacitor/android
  npx cap init "Cricket Toss" com.apnanaam.crickettoss --web-dir=www
  mkdir www
  (index.html, manifest.json, sw.js aur icons folder www ke andar copy karein)
  npx cap add android
  npx cap sync
  npx cap open android

Android Studio khulne par:  Build > Build Bundle(s) / APK(s) > Build APK(s)
APK yahan milti hai: android/app/build/outputs/apk/debug/app-debug.apk

Icon badalna ho to icons/icon-512.png ko Android Studio ke
"Image Asset" tool mein istemal karein.

------------------------------------------------------------
TAREEQA 2: PWABuilder (pwabuilder.com)
------------------------------------------------------------
1. Folder ko kisi free hosting par daalein (Netlify Drop ya GitHub Pages),
   taake HTTPS link mil jaye.
2. pwabuilder.com par wo link daalein.
3. "Package for stores" > Android se APK download karein.

------------------------------------------------------------
TAREEQA 3: "HTML to APK" wali website ya app
------------------------------------------------------------
Kuch online tools folder ki zip file se APK bana dete hain.
Is folder ko zip karke upload karein. Tool ka maqami (reputable) hona
check kar lein, kyunke kuch tools ads ya watermark daal dete hain.

------------------------------------------------------------
Commentary ki awaz ke liye
------------------------------------------------------------
Awaz phone ke text-to-speech engine se aati hai.
- Phone mein "Speech Services by Google" (Google Text-to-speech) installed ho.
- Urdu commentary ke liye Hindi awaz install ho:
  Settings > Language > Text-to-speech > Google > Install voice data > Hindi.
- App ke Settings mein "Awaz ka test" se check kar sakte hain.

Naam ya rang badalna
- App ka naam: manifest.json aur index.html ke <title> mein.
- Team ke naam aur zubaan: app ki Settings mein (phone mein save rehte hain).
