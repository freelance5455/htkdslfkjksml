MLBB NEON CATALOG — TEMPLATE PROYEK ANDROID

Isi:
- app/src/main/assets/index.html : katalog HTML, pencarian, filter, favorit lokal
- MainActivity.java : WebView untuk membuka katalog
- Gradle files : proyek Android Studio

Membuat APK:
1. Ekstrak ZIP.
2. Buka Android Studio lalu pilih Open, dan pilih folder MLBB_Neon_Catalog.
3. Tunggu Gradle Sync selesai (perlu koneksi internet saat pertama kali).
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- Ini katalog fan-made, bukan cheat dan tidak membuka skin berbayar dalam game.
- Data hero/skin pada HTML adalah contoh; gambar resmi tidak disertakan.
- Untuk hasil stabil, gunakan Android Studio versi yang mendukung Android Gradle Plugin 8.7.3.
