Maoua LifeTrack PWA ফাইলসমূহ

1) এই ZIP Extract করুন।
2) GitHub-এ একটি নতুন Public repository তৈরি করুন।
3) index.html, manifest.json, sw.js এবং icons ফোল্ডারসহ ভেতরের সব ফাইল repository-র root-এ আপলোড করুন।
4) Repository Settings > Pages > Build and deployment > Deploy from a branch > main / (root) > Save নির্বাচন করুন।
5) প্রকাশিত HTTPS URL-টি PWA Builder-এ দিন।

নোট:
- Service Worker ও PWA installability-এর জন্য HTTPS hosting দরকার।
- HTML-এ Google Fonts, Tailwind নয়; এই উন্নত সংস্করণটি মূলত নিজস্ব CSS ব্যবহার করে। ইন্টারনেট ছাড়া সম্পূর্ণ নিশ্চয়তা দিতে বাস্তব ডিভাইসে পরীক্ষা করুন।
- এই অ্যাপের রুটিন ডেটা একই ডিভাইস/ব্রাউজারে থাকে; স্বয়ংক্রিয় cloud sync নেই।
