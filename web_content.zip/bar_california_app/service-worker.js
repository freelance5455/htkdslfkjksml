const CACHE='bar-california-v7';
const FILES=['./','./index.html','./manifest.webmanifest','./assets/logo.jpg','./assets/icon-192.png','./assets/icon-512.png','./assets/gambas-ajillo.jpg','./assets/bar-california-local.jpg','./assets/carta-bocadillos.jpg','./assets/carta-bocadillos-combinados.jpg','./assets/carta-tapas.jpg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
