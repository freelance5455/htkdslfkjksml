LATIHAN TKA & AN - TJKT SMKN 1 LAMBOYA
Pembuat: Agustinus Lay Rihi, ST

Cara pakai: buka index.html di browser (Chrome/Edge/Firefox). Tidak perlu internet.
Folder logo/ berisi berkas logo asli (logo sudah tertanam di index.html).

Acuan: Perkaban Nomor 45 Tahun 2025 tentang Kerangka Asesmen TKA SMA/MA dan SMK/MAK.
Catatan: Perkaban tersebut hanya mengatur TKA (tidak mengatur Asesmen Nasional) dan tidak memuat
mata uji TJKT. Mata uji pilihan SMK yang ada: Produk/Projek Kreatif dan Kewirausahaan.
Paket TJKT dan AN adalah latihan tambahan sekolah.

Menambah soal: di index.html cari SETS[...].q.push(...) lalu tambahkan soal dengan format
W("Sub-elemen • Level", "pertanyaan", [pilihan...], indeksJawaban, "pembahasan")
Jawaban jamak: indeks berupa daftar, mis. [0,2] dan tambahkan "M" di akhir.
Benar-Salah per pernyataan: [true,false,true] dan tambahkan "K" di akhir.
