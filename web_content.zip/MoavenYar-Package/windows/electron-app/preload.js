// Preload ساده — در صورت نیاز می‌توانید APIهای امن به صفحه تزریق کنید
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  platform: process.platform,
  version: '2.1'
});