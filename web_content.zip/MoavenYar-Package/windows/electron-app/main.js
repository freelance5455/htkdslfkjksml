const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');

// جلوگیری از اجرای چندباره
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: 'معاون‌یار ۲٫۱',
    backgroundColor: '#0a2f24',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      // اجازه استفاده از localStorage و فایل‌های محلی
      webSecurity: true
    },
    autoHideMenuBar: true,
    show: false
  });

  // بارگذاری فایل HTML
  mainWindow.loadFile('index.html');

  // نمایش بعد از آماده شدن
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // باز کردن لینک‌های خارجی در مرورگر سیستم
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // منوی ساده فارسی
  const template = [
    {
      label: 'فایل',
      submenu: [
        { role: 'reload', label: 'بارگذاری مجدد' },
        { role: 'forceReload', label: 'بارگذاری اجباری' },
        { type: 'separator' },
        { role: 'quit', label: 'خروج' }
      ]
    },
    {
      label: 'نمایش',
      submenu: [
        { role: 'togglefullscreen', label: 'تمام‌صفحه' },
        { role: 'zoomIn', label: 'بزرگ‌نمایی' },
        { role: 'zoomOut', label: 'کوچک‌نمایی' },
        { role: 'resetZoom', label: 'اندازه پیش‌فرض' }
      ]
    },
    {
      label: 'راهنما',
      submenu: [
        {
          label: 'درباره معاون‌یار',
          click: () => {
            mainWindow.webContents.executeJavaScript(`
              if (typeof showPage === 'function') showPage('about');
            `);
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});