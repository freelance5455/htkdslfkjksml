@echo off
chcp 65001 >nul
echo ========================================
echo   ساخت نسخه EXE معاون‌یار با PyInstaller
echo ========================================
echo.

REM نصب وابستگی‌ها (اگر لازم باشد)
pip install pywebview pyinstaller

echo.
echo در حال ساخت فایل EXE...
pyinstaller --onefile --windowed --name "MoavenYar" --add-data "index.html;." main.py

echo.
echo ========================================
echo ساخت تمام شد!
echo فایل EXE در پوشه dist قرار دارد.
echo ========================================
pause