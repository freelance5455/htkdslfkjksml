#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
معاون‌یار ۲٫۱ — نسخه دسکتاپ با pywebview
سازگار با ویندوز ۷ (پایتون ۳.۸ یا ۳.۹ توصیه می‌شود)
"""

import os
import sys
import webview

def get_html_path():
    """مسیر فایل index.html را پیدا می‌کند (هم در حالت توسعه و هم در حالت بسته‌بندی‌شده)"""
    if getattr(sys, 'frozen', False):
        # وقتی با PyInstaller بسته‌بندی شده
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, 'index.html')

def main():
    html_file = get_html_path()

    if not os.path.exists(html_file):
        print(f'خطا: فایل {html_file} پیدا نشد.')
        sys.exit(1)

    window = webview.create_window(
        title='معاون‌یار ۲٫۱ | سامانه حرفه‌ای مدیریت انضباط مدارس',
        url=html_file,
        width=1280,
        height=800,
        min_size=(900, 600),
        background_color='#0a2f24',
        text_select=True,
        confirm_close=False
    )

    # شروع برنامه
    webview.start(debug=False)

if __name__ == '__main__':
    main()