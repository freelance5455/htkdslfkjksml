NAVOIY REMONT SERVIS — ANDROID LOYIHA

Bu ZIP Android Studio loyihasi bo'lib, o'zi tayyor APK fayli emas.
APK yaratish uchun:
1. Kompyuterga Android Studio o'rnating.
2. Ushbu papkani Android Studio orqali Open qiling.
3. Android SDK 35 va JDK 17 o'rnatilganini tekshiring.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ni bosing.
5. APK odatda app/build/outputs/apk/debug/app-debug.apk manzilida paydo bo'ladi.

Ilova HTML faylni telefon ichidan ochadi; asosiy sahifalar internet talab qilmaydi.
Ma'lumotlar WebView localStorage ichida saqlanadi. Ilovani o'chirish yoki ilova ma'lumotlarini tozalash saqlangan ma'lumotlarni yo'qotishi mumkin.
