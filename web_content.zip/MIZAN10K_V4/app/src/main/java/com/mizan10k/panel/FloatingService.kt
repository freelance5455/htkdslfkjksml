package com.mizan10k.panel

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var tts: TextToSpeech? = null
    private val channel = "mizan_float"
    private val labels = listOf("ESP Box", "ESP Location", "Bot", "Bembot")
    override fun onCreate() {
        super.onCreate(); createNotification(); startForeground(410, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
        if (Settings.canDrawOverlays(this)) showBubble() else stopSelf()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        return START_NOT_STICKY
    }
    private fun createNotification() { if (Build.VERSION.SDK_INT >= 26) { val c = NotificationChannel(channel, "MIZAN floating controls", NotificationManager.IMPORTANCE_LOW); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c) } }
    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 2, Intent(this, FloatingService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel).setContentTitle("MIZAN 10K floating logo active").setContentText("Tap the logo to open visual controls").setSmallIcon(android.R.drawable.ic_menu_view).addAction(Notification.Action.Builder(null, "Stop", stop).build()).build() else Notification.Builder(this).setContentTitle("MIZAN 10K active").setSmallIcon(android.R.drawable.ic_menu_view).build()
    }
    private fun params(w:Int,h:Int): WindowManager.LayoutParams = WindowManager.LayoutParams(w,h, if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=24; y=220 }
    private fun bg(color:Int, radius:Float): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=radius; setStroke(2, Color.rgb(0,220,255)) }
    private fun speak(s:String) { tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "mizan_voice") }
    private fun showBubble() {
        if (bubble != null) return
        val v = ImageView(this).apply { setImageDrawable(android.graphics.drawable.Drawable.createFromStream(assets.open("mizan_logo.jpg"), null)); scaleType=ImageView.ScaleType.CENTER_CROP; background=bg(Color.rgb(8,22,36),100f); clipToOutline=true; elevation=12f; contentDescription="MIZAN 10K floating logo" }
        val p=params(58,58); wm.addView(v,p); bubble=v
        v.setOnTouchListener(object: View.OnTouchListener { var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(view:View,e:MotionEvent):Boolean { when(e.action){ MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=p.x;oy=p.y;moved=false;return true}; MotionEvent.ACTION_MOVE->{val dx=(e.rawX-sx).toInt();val dy=(e.rawY-sy).toInt();if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8)moved=true;p.x=ox+dx;p.y=oy+dy;wm.updateViewLayout(view,p);return true}; MotionEvent.ACTION_UP->{if(!moved)showPanel(p.x,p.y);return true} };return true }
        })
    }
    private fun showPanel(x:Int,y:Int) {
        if(panel!=null){ closePanel(); return }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=bg(Color.rgb(8,16,29),22f); setPadding(14,12,14,14); elevation=18f }
        val head=TextView(this).apply { text="MIZAN 10K   •   VISUAL CONTROLS   ✕"; textSize=13f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(0,225,255)); setPadding(5,8,5,12); setOnClickListener{closePanel()} }
        box.addView(head)
        box.addView(TextView(this).apply { text="UI SIMULATION ONLY • NO GAME MODIFICATION"; textSize=9f; setTextColor(Color.LTGRAY); setPadding(5,0,5,10) })
        labels.forEach { label ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(4,7,4,7) }
            row.addView(TextView(this).apply { text=label; textSize=14f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f))
            val sw=Switch(this).apply { textOn="ON"; textOff="OFF"; setOnCheckedChangeListener { _, on -> speak(if(on) "Panel activated. $label visual switch on." else "$label visual switch off.") } }
            row.addView(sw); box.addView(row)
        }
        val hide=Button(this).apply { text="HIDE TO FLOATING LOGO"; setOnClickListener{closePanel()} }; box.addView(hide)
        val stop=Button(this).apply { text="STOP FLOATING LOGO"; setOnClickListener{stopSelf()} }; box.addView(stop)
        val p=params(285,WindowManager.LayoutParams.WRAP_CONTENT).apply { this.x=x;this.y=y+65; flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN }
        wm.addView(box,p); panel=box; speak("Panel activated. Visual controls ready.")
        head.setOnTouchListener(object:View.OnTouchListener{var sx=0f;var sy=0f;var ox=0;var oy=0;override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=p.x;oy=p.y;return true};MotionEvent.ACTION_MOVE->{p.x=ox+(e.rawX-sx).toInt();p.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(box,p);return true}};return false}})
    }
    private fun closePanel(){ panel?.let{try{wm.removeView(it)}catch(_:Exception){}};panel=null }
    override fun onDestroy(){ closePanel();bubble?.let{try{wm.removeView(it)}catch(_:Exception){}};bubble=null;tts?.stop();tts?.shutdown();super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
}
