package com.mizan10k.panel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webChromeClient = WebChromeClient()
            addJavascriptInterface(Bridge(), "Mizan")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }
    inner class Bridge {
        @JavascriptInterface fun startFloating() { runOnUiThread {
            if (Settings.canDrawOverlays(this@MainActivity)) {
                val i = Intent(this@MainActivity, FloatingService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this@MainActivity, "Floating logo started", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        } }
        @JavascriptInterface fun launchGame(packageName: String, label: String) { runOnUiThread {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) startActivity(launch) else Toast.makeText(this@MainActivity, "$label is not installed or package is unavailable", Toast.LENGTH_LONG).show()
        } }
    }
    override fun onDestroy() { if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
