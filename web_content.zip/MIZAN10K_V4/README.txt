BHUTOLA PANEL V4

Android Studio project. Open the MIZAN10K_V4 folder in Android Studio and build the APK.

V4 visual update:
- Full-screen black cyber boot background with animated RGB/DJ light beams.
- Multicolor code typing animation with synthesized keyboard-like click sounds.
- Large channel-logo reveal, followed by the access-key screen.
- Access key: FF 09
- Roman Hindi voice prompt: "Enter key."
- Visual switches and floating controls are UI-only and do not modify Free Fire or provide ESP, bot, or auto-headshot functionality.
- Android overlay permission is requested only when the user chooses Enable Floating Logo.

The app needs Android Studio/Gradle to build an installable APK.
