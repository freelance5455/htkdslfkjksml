EDU PLUS — prototype web installable

CONTENU
- index.html : interface
- app.js : cours, quiz et progression locale
- sw.js : cache hors connexion
- manifest.webmanifest : configuration d'installation
- icon.svg : icône

ESSAI RAPIDE
1. Décompressez le dossier.
2. Pour tester localement, démarrez un serveur web dans ce dossier (par exemple : python -m http.server 8000).
3. Ouvrez http://localhost:8000 dans un navigateur moderne.
4. Chargez la page une première fois avec Internet, puis vérifiez le mode hors connexion.
5. Pour installer sur Android, hébergez les fichiers sur un site HTTPS puis ouvrez le site dans Chrome et choisissez « Installer l'application » ou « Ajouter à l'écran d'accueil ».

LIMITES IMPORTANTES
- Ceci est un prototype PWA, pas un APK Android natif.
- La progression et le niveau sont stockés localement dans le navigateur (localStorage).
- La synchronisation entre appareils et les comptes élèves/enseignants nécessitent un serveur et une base de données, non inclus ici.
- Les cours sont des exemples pédagogiques et doivent être complétés/validés selon les programmes officiels.
- Le cache hors connexion est disponible après le premier chargement réussi et dépend du navigateur/appareil.
