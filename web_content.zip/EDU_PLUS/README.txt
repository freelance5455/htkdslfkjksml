EDU PLUS – application éducative
Leçons incluses : 49.
Classes : 3e, 4e, 5e, 6e, 7e, 8e et 9e année fondamentale.
Chaque leçon comprend un cours, un exemple, 3 questions, une correction et une explication.
Professeur affiché à la fin de chaque leçon : CALIXTE EVENS.

Installation :
1. Héberger les fichiers sur un site HTTPS.
2. Ouvrir le site dans Chrome Android.
3. Menu Chrome > Installer l'application ou Ajouter à l'écran d'accueil.
4. Le cache hors ligne devient disponible après le premier chargement réussi.

Limites et précision pédagogique :
Cette version est une PWA, pas un APK natif. Les résultats sont enregistrés localement sur le téléphone. Il n'y a pas encore de compte élève ni de synchronisation entre appareils.
Les leçons sont des contenus pédagogiques originaux de révision, rédigés pour être cohérents avec les notions fondamentales et les domaines disciplinaires. Elles ne constituent pas une reproduction exhaustive des programmes officiels. Les programmes du troisième cycle haïtien sont en cours de mise en œuvre progressive ; un enseignant ou responsable pédagogique doit valider l’alignement annuel avant un usage officiel en classe.
