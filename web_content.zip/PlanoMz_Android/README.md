# Plano Mz — Projeto Android

Este projeto empacota a versão instalável do Plano Mz (`index.html`) num aplicativo Android nativo com WebView.

## Gerar o APK
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Escolha `Build > Build APK(s)`.
4. O APK será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

O aplicativo não depende de internet para abrir o conteúdo local do Plano Mz. Recursos que dependam de serviços externos continuam sujeitos à ligação à internet.
