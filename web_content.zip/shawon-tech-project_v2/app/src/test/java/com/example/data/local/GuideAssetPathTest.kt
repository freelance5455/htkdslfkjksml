package com.example.data.local

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * WebViewAssetLoader-এর পাথ ম্যাপিং ও বান্ডল করা গাইড অ্যাসেটের উপস্থিতি যাচাই করে।
 *
 * কেন এই টেস্ট: `assets/web/index.html` থাকা সত্ত্বেও WebView-এ
 * `ERR_HTTP_RESPONSE_CODE_FAILURE` এসেছিল, কারণ `addPathHandler("/web/", ...)`
 * দিয়ে পাথের প্রিফিক্স কাটার পর শুধু "index.html" বাঁচত — আর
 * `AssetHelper.openAsset()` সবসময় **assets রুট** থেকে পড়ে। ফলে সে খুঁজত
 * `assets/index.html`, যা নেই। `/` প্রিফিক্স দিলে "web/index.html" বাঁচে।
 *
 * এই টেস্ট দুটো জিনিস রক্ষা করে:
 *   ১. গাইডের URL আর addPathHandler প্রিফিক্স — দুটো মিলে সত্যিই ফাইল পায়।
 *   ২. ফাইলটা সত্যিই ডিস্কে আছে (নইলে বিল্ড সফল হলেও রানটাইমে 404)।
 *
 * নোট: প্রজেক্টের `GUIDE_URL` কনস্ট্যান্টে সরাসরি ইমপোর্ট করা হয়নি —
 * সেটি `androidx.compose` ক্লাসের সাথে একই ফাইলে থাকে, যা pure-JVM
 * ইউনিট টেস্টে লোড করতে গেলে Android ক্লাসপাথ দরকার হয়। তাই এখানে
 * একই স্ট্রিং আলাদা করে রাখা হয়েছে এবং নিচের টেস্টটি নিশ্চিত করে
 * যেন দুটো কখনো আলাদা হয়ে না যায়।
 */
class GuideAssetPathTest {

    private val guideUrl = "https://appassets.androidplatform.net/web/index.html"
    private val expectedAsset = "web/index.html"
    private val prefix = "/"

    /** WebViewAssetLoader.PathMatcher.getSuffixPath() ও AssetHelper.removeLeadingSlash() নকল। */
    private fun resolveAssetPath(urlPath: String, handlerPrefix: String): String {
        var suffix = urlPath.replaceFirst(handlerPrefix, "")
        if (suffix.length > 1 && suffix[0] == '/') {
            suffix = suffix.substring(1)
        }
        return suffix
    }

    private fun assetsDir(): File {
        // Gradle ইউনিট টেস্টের working dir সাধারণত module root (app/)।
        val candidates = listOf(
            File("src/main/assets"),
            File("app/src/main/assets")
        )
        return candidates.firstOrNull { it.isDirectory }
            ?: error("assets ডিরেক্টরি পাওয়া যায়নি — চেক করা হয়েছে: $candidates")
    }

    @Test
    fun `guide url resolves to bundled asset path`() {
        val urlPath = java.net.URI(guideUrl).path
        assertEquals("/web/index.html", urlPath)

        val resolved = resolveAssetPath(urlPath, prefix)
        assertEquals(expectedAsset, resolved)
    }

    @Test
    fun `web prefix would not resolve correctly - documents the original bug`() {
        val urlPath = java.net.URI(guideUrl).path
        // এটাই আগের বাগ ছিল: "/web/" কাটলে শুধু "index.html" বাঁচে,
        // আর AssetsPathHandler রুট থেকেই পড়ে — তাই 404।
        val wrong = resolveAssetPath(urlPath, "/web/")
        assertEquals("index.html", wrong)
        assertTrue(
            "এই টেস্টটি প্রমাণ করে /web/ প্রিফিক্স ভুল ছিল — এটি বদলানো উচিত নয়",
            wrong != expectedAsset
        )
    }

    @Test
    fun `guide asset exists on disk and is non trivial`() {
        val file = File(assetsDir(), expectedAsset)
        assertTrue("অ্যাসেট নেই: ${file.absolutePath}", file.isFile)
        // গাইডে ফন্ট base64-এ embed করা — কয়েকশ কিলোবাইট হবেই।
        assertTrue(
            "অ্যাসেট সন্দেহজনকভাবে ছোট: ${file.length()} বাইট",
            file.length() > 100_000
        )
    }

    @Test
    fun `guide asset is self contained with no cdn dependency`() {
        val html = File(assetsDir(), expectedAsset).readText()
        assertNotNull(html)
        assertTrue("HTML খালি", html.isNotBlank())
        // অফলাইনে WebView-এ চলার শর্ত — কোনো বাইরের রিসোর্স থাকা যাবে না।
        assertTrue(
            "HTML-এ CDN/ফন্ট লিংক আছে — অফলাইনে রেন্ডার ভাঙবে",
            !html.contains("fonts.googleapis.com")
        )
        assertTrue(
            "HTML-এ gstatic লিংক আছে — অফলাইনে রেন্ডার ভাঙবে",
            !html.contains("fonts.gstatic.com")
        )
        // ফন্ট base64-এ embed করা আছে কি না।
        assertTrue(
            "HTML-এ কোনো base64 embed পাওয়া যায়নি — ফন্ট অফলাইনে লোড হবে না",
            html.contains("base64")
        )
    }

    @Test
    fun `guide asset has expected bengali guide markers`() {
        val html = File(assetsDir(), expectedAsset).readText()
        // গাইডের আসল কনটেন্ট — ভুল ফাইল বান্ডল হলে ধরা পড়বে।
        assertTrue("গাইডে 'Shawon Tech' নেই", html.contains("Shawon Tech"))
        assertTrue(
            "গাইডে APK বিল্ড সেকশন নেই",
            html.contains("assembleDebug") || html.contains("APK")
        )
    }
}
