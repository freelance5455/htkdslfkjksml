package com.example.data.model

/**
 * স্টক সমন্বয় — the three ways a shop owner corrects stock.
 *
 * SET_TO_COUNT is the important one: the owner counts the shelf and types what
 * is actually there. The app works out the delta itself, so the owner never has
 * to do subtraction in their head.
 *
 * Mirrors the pattern used by TransactionType / PaymentMethod / FlowDirection in
 * Transaction.kt: a plain enum carrying its own Bengali label, plus a defensive
 * fromString() for persistence.
 */
enum class StockAdjustMode(val banglaLabel: String) {
    INCREASE("বৃদ্ধি করুন"),
    DECREASE("হ্রাস করুন"),
    SET_TO_COUNT("গণনা অনুযায়ী ঠিক করুন");

    companion object {
        fun fromString(value: String): StockAdjustMode =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: SET_TO_COUNT
    }
}

/**
 * The result of applying a mode to a typed quantity.
 *
 * `delta` is signed: positive adds, negative removes. `quantity` written to
 * storage is always the absolute value — the mode carries the direction.
 */
data class StockAdjustPreview(
    val currentOnHand: Int,
    val resultingOnHand: Int,
    val delta: Int,
    val isValid: Boolean,
    val errorMessage: String? = null
)

/**
 * Turns (current stock, mode, typed number) into a concrete adjustment.
 *
 * This is the single source of truth for BOTH the live preview on screen and the
 * value actually saved — they call this same function, so they cannot disagree.
 *
 * Pure: no Android, no Room, no coroutines. Trivially unit-testable.
 */
fun computeStockAdjustPreview(
    currentOnHand: Int,
    mode: StockAdjustMode,
    inputQuantity: Int
): StockAdjustPreview {
    if (inputQuantity < 0) {
        return StockAdjustPreview(
            currentOnHand = currentOnHand,
            resultingOnHand = currentOnHand,
            delta = 0,
            isValid = false,
            errorMessage = "পরিমাণ ঋণাত্মক হতে পারে না"
        )
    }

    return when (mode) {
        StockAdjustMode.INCREASE -> {
            if (inputQuantity == 0) {
                StockAdjustPreview(
                    currentOnHand, currentOnHand, 0, false, "পরিমাণ লিখুন"
                )
            } else {
                StockAdjustPreview(
                    currentOnHand = currentOnHand,
                    resultingOnHand = currentOnHand + inputQuantity,
                    delta = inputQuantity,
                    isValid = true
                )
            }
        }

        StockAdjustMode.DECREASE -> {
            when {
                inputQuantity == 0 ->
                    StockAdjustPreview(currentOnHand, currentOnHand, 0, false, "পরিমাণ লিখুন")

                inputQuantity > currentOnHand ->
                    StockAdjustPreview(
                        currentOnHand, currentOnHand, 0, false,
                        "বর্তমান স্টকের চেয়ে বেশি হ্রাস করা যাবে না (বর্তমান: $currentOnHand)"
                    )

                else ->
                    StockAdjustPreview(
                        currentOnHand = currentOnHand,
                        resultingOnHand = currentOnHand - inputQuantity,
                        delta = -inputQuantity,
                        isValid = true
                    )
            }
        }

        StockAdjustMode.SET_TO_COUNT -> {
            val delta = inputQuantity - currentOnHand
            when {
                delta == 0 ->
                    StockAdjustPreview(
                        currentOnHand, inputQuantity, 0, false,
                        "স্টক ইতিমধ্যেই $inputQuantity — কোনো পরিবর্তন নেই"
                    )

                else ->
                    StockAdjustPreview(
                        currentOnHand = currentOnHand,
                        resultingOnHand = inputQuantity,
                        delta = delta,
                        isValid = true
                    )
            }
        }
    }
}

/**
 * One saved adjustment, kept for the on-screen "সাম্প্রতিক সমন্বয়" list.
 *
 * Session-scoped today: it is rebuilt from what the owner saves while the screen
 * is open. It becomes durable — and cross-device correct — as soon as the
 * stock-movements ledger from the Phase 0/1 patch is registered in AppDatabase;
 * at that point this list is replaced by a Room query and this type is dropped.
 */
data class StockAdjustRecord(
    val productId: Long,
    val productName: String,
    val mode: StockAdjustMode,
    val delta: Int,
    val resultingOnHand: Int,
    val note: String,
    val occurredAt: Long = System.currentTimeMillis()
) {
    val isIncrease: Boolean get() = delta >= 0
}
