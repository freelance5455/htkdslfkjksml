package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * স্টক মুভমেন্টের ধরন — কেন অন-হ্যান্ড সংখ্যাটি বদলাল।
 *
 * প্রতিটি স্টক পরিবর্তনের একটি কারণ থাকা দরকার, নাহলে পরে জানা যাবে না
 * "কে, কখন, কেন" স্টক বদলেছে। TransactionType / PaymentMethod-এর মতোই
 * একটি সাধারণ enum, নিজের বাংলা লেবেল বহন করে।
 */
enum class StockMovementType(val banglaLabel: String) {
    OPENING("প্রারম্ভিক স্টক"),
    PURCHASE_IN("ক্রয় (স্টক ইন)"),
    SALE_OUT("বিক্রয় (স্টক আউট)"),
    ADJUST_INCREASE("সমন্বয় — বৃদ্ধি"),
    ADJUST_DECREASE("সমন্বয় — হ্রাস"),
    ADJUST_SET("সমন্বয় — গণনা অনুযায়ী"),
    RETURN_IN("ফেরত (স্টক ইন)"),
    DAMAGE_OUT("নষ্ট / ক্ষতি");

    companion object {
        fun fromString(value: String): StockMovementType =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: ADJUST_SET
    }
}

/**
 * স্টক লেজার — স্টকের প্রতিটি পরিবর্তনের অপরিবর্তনীয় রেকর্ড।
 *
 * `delta` সাইনযুক্ত: ধনাত্মক মানে স্টক বাড়ল, ঋণাত্মক মানে কমল।
 * `quantity` সর্বদা পরম মান — দিকনির্দেশ `delta` বহন করে।
 * `resultingOnHand` সেই মুহূর্তে স্টক কত ছিল তা ধরে রাখে, তাই লেজার
 * নিজেই একটি সম্পূর্ণ অডিট ট্রেইল — যেকোনো সময়ে ফিরে হিসাব করা যায়।
 */
@Entity(tableName = "stock_movements")
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long,
    val productName: String = "",
    val type: String,               // StockMovementType name
    val quantity: Int,              // পরম পরিমাণ
    val delta: Int,                 // সাইনযুক্ত পরিবর্তন
    val resultingOnHand: Int,       // এই মুভমেন্টের পরে স্টক
    val reason: String = "",        // কারণ / নোট
    val referenceId: Long = 0,      // SALE_OUT / PURCHASE_IN হলে transaction id
    val occurredAt: Long = System.currentTimeMillis(),
    val dateString: String = ""
) {
    val isInflow: Boolean get() = delta >= 0
}

/**
 * একটি পণ্যের স্টক সারসংক্ষেপ — products টেবিল + লেজার একসাথে।
 *
 * `stockQuantity` হলো ক্যাশ করা মান (দ্রুত দেখানোর জন্য), আর `ledgerOnHand`
 * হলো লেজার থেকে হিসাব করা প্রকৃত মান। দুটো আলাদা রাখা হয়েছে যাতে
 * অমিল ধরা পড়ে — মিলিয়ে দেখা যায়, চোখ বন্ধ করে বিশ্বাস করা যায় না।
 */
data class ProductStockRow(
    val id: Long,
    val name: String,
    val category: String,
    val unit: String,
    val buyPrice: Double,
    val sellPrice: Double,
    val stockQuantity: Int,
    val isAvailable: Boolean,
    val reorderPoint: Int,
    val reorderQuantity: Int,
    val ledgerOnHand: Int,
    val lastMovementAt: Long
) {
    /** স্টক রি-অর্ডার সীমায় পৌঁছেছে বা নিচে নেমেছে? */
    val isLowStock: Boolean get() = stockQuantity <= reorderPoint

    /** ক্যাশ করা মান আর লেজার মিলছে না — তদন্ত দরকার। */
    val hasDrift: Boolean get() = stockQuantity != ledgerOnHand
}
