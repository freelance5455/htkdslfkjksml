package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.example.ui.theme.TechNavyPrimary

/**
 * অ্যাপের ভিতরে বান্ডল করা সম্পূর্ণ অফলাইন গাইড HTML দেখায়।
 *
 * কেন WebViewAssetLoader আর `appassets.androidplatform.net`:
 * সরাসরি `file:///android_asset/...` লোড করলে WebView-এর origin হয় `null`, ফলে
 * `file://` স্কিমে অনেক API বন্ধ থাকে এবং কিছু ডিভাইসে অ্যাসেট পড়তে গিয়ে
 * permission এরর দেয়। WebViewAssetLoader একটি ভার্চুয়াল https origin দেয়,
 * যা সাধারণ https পেজের মতোই আচরণ করে — কিন্তু ফাইল আসে অ্যাপের assets থেকে,
 * নেটওয়ার্ক থেকে নয়। তাই ইন্টারনেট ছাড়াই কাজ করে।
 *
 * পাথ ম্যাপিং (গুরুত্বপূর্ণ — এখানেই আগের বাগ ছিল):
 *   addPathHandler("/", AssetsPathHandler(context))
 *   → URL  https://appassets.androidplatform.net/web/index.html
 *   → প্রিফিক্স "/" কাটার পর বাঁচে "web/index.html"
 *   → AssetHelper.removeLeadingSlash() এরপর assets.open("web/index.html")
 *   → পড়ে app/src/main/assets/web/index.html  ✅
 *
 * কেন "/web/" প্রিফিক্স দিয়ে করা যায় না:
 *   addPathHandler("/web/", ...) হলে প্রিফিক্স কাটার পর বাঁচে শুধু "index.html",
 *   আর AssetsPathHandler সবসময় **assets রুট** থেকে পড়ে — তাই ৎসা করত
 *   assets/index.html, যা নেই। এর ফলে WebView পায় 404 → HTTP_RESPONSE_CODE_FAILURE।
 *   অইভাবে AssetsPathHandler প্রিফিক্সকে ডিরেক্টরি হিসেবে ব্যবহার করে না,
 *   শুধু URL থেকে কাটে। তাই ডিরেক্টরি বাঁচাতে প্রিফিক্স হবে "/"।
 *
 * ফাইলটি থাকতেই হবে: app/src/main/assets/web/index.html
 *
 * এই স্ক্রিন ইচ্ছাকৃতভাবে নিজের Scaffold/TopAppBar রাখে না — বাইরের
 * MainAppContainer-এর Scaffold ইতিমধ্যে টপ বার ও নেভিগেশন বার দেয়।
 * নিজের বার যোগ করলে দুটো অ্যাপবার একটার উপর একটা বসে যেত।
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GuideWebViewScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // একবারই বানাই — রিকম্পোজিশনে নতুন লোডার বানালে WebView পুরো রিলোড করবে।
    val assetLoader = remember(context) {
        WebViewAssetLoader.Builder()
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(context))
            .build()
    }

    val client = remember(assetLoader) {
        object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    // গাইডের ফন্ট base64-এ embed করা — বাইরের কিছু লাগবে না।
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    webViewClient = client
                    tag = "guide_webview"
                    loadUrl(GUIDE_URL)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .testTag("guide_content")
        )

        Surface(
            shape = CircleShape,
            color = TechNavyPrimary,
            shadowElevation = 6.dp,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(18.dp)
        ) {
            FloatingActionButton(
                onClick = onBack,
                containerColor = Color.Transparent,
                contentColor = Color.White,
                elevation = androidx.compose.material3.FloatingActionButtonDefaults.elevation(0.dp),
                modifier = Modifier
                    .size(46.dp)
                    .testTag("guide_back")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "ফিরে যান",
                    tint = Color.White
                )
            }
        }
    }
}

/**
 * এক জায়গায় URL — ম্যাপিং বদলালে এখানেই বদলাতে হবে।
 * এই URL-এর পাথ এবং addPathHandler("/", ...) মিলে assets/web/index.html পড়ে।
 */
const val GUIDE_URL = "https://appassets.androidplatform.net/web/index.html"

/** রেফারেন্সের জন্য — টেস্ট ও ডকুমেন্টেশনে ব্যবহার হয়। */
const val GUIDE_ASSET_PATH = "web/index.html"
