package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.ProductStockRow
import com.example.data.model.StockMovementEntity
import kotlinx.coroutines.flow.Flow

/**
 * স্টক লেজারের ডেটা অ্যাক্সেস।
 *
 * abstract class ব্যবহার করা হয়েছে (interface নয়) কারণ @Transaction সহ
 * একটি বডিযুক্ত মেথড দরকার — Room এটিকে একটি একক ডেটাবেস ট্রানজেকশনে চালায়,
 * ফলে লেজার রেকর্ড লেখা আর products.stockQuantity হালনাগাদ করা কখনো
 * আলাদা হয়ে যেতে পারে না।
 */
@Dao
abstract class StockMovementDao {

    @Query("SELECT * FROM stock_movements ORDER BY occurredAt DESC, id DESC LIMIT :limit")
    abstract fun getRecentMovements(limit: Int): Flow<List<StockMovementEntity>>

    @Query("SELECT * FROM stock_movements WHERE productId = :productId ORDER BY occurredAt DESC, id DESC")
    abstract fun getMovementsForProduct(productId: Long): Flow<List<StockMovementEntity>>

    @Query("SELECT * FROM stock_movements WHERE type = :type ORDER BY occurredAt DESC, id DESC")
    abstract fun getMovementsByType(type: String): Flow<List<StockMovementEntity>>

    @Query("SELECT COUNT(*) FROM stock_movements")
    abstract suspend fun getMovementCount(): Int

    @Query("SELECT COUNT(*) FROM stock_movements WHERE productId = :productId")
    abstract suspend fun getMovementCountForProduct(productId: Long): Int

    @Query("SELECT COALESCE(SUM(delta), 0) FROM stock_movements WHERE productId = :productId")
    abstract suspend fun getLedgerOnHand(productId: Long): Int

    @Insert
    abstract suspend fun insertMovement(movement: StockMovementEntity): Long

    @Insert
    abstract suspend fun insertAll(movements: List<StockMovementEntity>)

    @Query("UPDATE products SET stockQuantity = :onHand WHERE id = :productId")
    abstract suspend fun updateProductOnHand(productId: Long, onHand: Int)

    @Query("DELETE FROM stock_movements")
    abstract suspend fun clearAll()

    /**
     * লেজারে একটি মুভমেন্ট লেখে এবং একই ট্রানজেকশনে products.stockQuantity
     * হালনাগাদ করে। দুটো কখনো আলাদা হতে পারে না — এটাই লেজারের মূল গ্যারান্টি।
     */
    @Transaction
    open suspend fun insertAndRecompute(movement: StockMovementEntity, newOnHand: Int): Long {
        val id = insertMovement(movement)
        updateProductOnHand(movement.productId, newOnHand)
        return id
    }

    /**
     * প্রতিটি পণ্যের জন্য লেজার-হিসাবকৃত স্টক সহ সারসংক্ষেপ।
     * সাব-কোয়েরি ব্যবহার করা হয়েছে যাতে একটি পণ্য না থাকলেও ০ আসে।
     */
    @Query(
        """
        SELECT p.id AS id, p.name AS name, p.category AS category, p.unit AS unit,
               p.buyPrice AS buyPrice, p.sellPrice AS sellPrice,
               p.stockQuantity AS stockQuantity, p.isAvailable AS isAvailable,
               p.reorderPoint AS reorderPoint, p.reorderQuantity AS reorderQuantity,
               COALESCE((SELECT SUM(m.delta) FROM stock_movements m WHERE m.productId = p.id), 0) AS ledgerOnHand,
               COALESCE((SELECT MAX(m.occurredAt) FROM stock_movements m WHERE m.productId = p.id), 0) AS lastMovementAt
        FROM products p
        ORDER BY p.name ASC
        """
    )
    abstract fun getProductStockRows(): Flow<List<ProductStockRow>>

    /** শুধু যেসব পণ্যের স্টক রি-অর্ডার সীমায় পৌঁছেছে বা নিচে নেমেছে। */
    @Query(
        """
        SELECT p.id AS id, p.name AS name, p.category AS category, p.unit AS unit,
               p.buyPrice AS buyPrice, p.sellPrice AS sellPrice,
               p.stockQuantity AS stockQuantity, p.isAvailable AS isAvailable,
               p.reorderPoint AS reorderPoint, p.reorderQuantity AS reorderQuantity,
               COALESCE((SELECT SUM(m.delta) FROM stock_movements m WHERE m.productId = p.id), 0) AS ledgerOnHand,
               COALESCE((SELECT MAX(m.occurredAt) FROM stock_movements m WHERE m.productId = p.id), 0) AS lastMovementAt
        FROM products p
        WHERE p.stockQuantity <= p.reorderPoint
        ORDER BY p.stockQuantity ASC, p.name ASC
        """
    )
    abstract fun getLowStockRows(): Flow<List<ProductStockRow>>
}
