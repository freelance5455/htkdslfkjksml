package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrandCyanLight
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.InflowGreen
import com.example.ui.theme.OutflowRed
import com.example.ui.theme.TechNavyPrimary

/**
 * "+" বোতামের কুইক-অ্যাকশন মেনু — পাঁচটি দৈনন্দিন কাজ।
 *
 * প্রতিটি অ্যাকশন একটি বিদ্যমান গন্তব্যে যায় (NavigationTab বা ফর্ম প্রিসেট),
 * তাই নতুন কোনো স্ক্রিন বা রুট লাগে না।
 */
enum class QuickAction(
    val label: String,
    val description: String,
    val icon: ImageVector,
    val accent: Color
) {
    NEW_SALE("নতুন বিক্রয়", "পণ্য বিক্রয় এন্ট্রি", Icons.Default.ShoppingCart, InflowGreen),
    NEW_PURCHASE("নতুন ক্রয়", "পণ্য ক্রয় এন্ট্রি", Icons.Default.AddShoppingCart, BrandCyanLight),
    STOCK_ADJUST("স্টক সমন্বয়", "গণনা অনুযায়ী স্টক ঠিক করুন", Icons.Default.Inventory2, GoldAccent),
    NEW_CUSTOMER("নতুন কাস্টমার", "কাস্টমার খাতায় যোগ করুন", Icons.Default.PersonAdd, TechNavyPrimary),
    NEW_DUE("নতুন বাকি", "বাকি সহ বিক্রয় এন্ট্রি", Icons.Default.Receipt, OutflowRed)
}

/**
 * FAB-এর জন্য কুইক-অ্যাকশন বটম শিট।
 *
 * Scaffold-এর floatingActionButton স্লটে FAB বসানো হয়, তাই এটি
 * bottomBar-এর উপরে স্বয়ংক্রিয়ভাবে অবস্থান নেয় — আলাদা কোনো
 * padding হিসাব করতে হয় না, শেষ লিস্ট আইটেমও ঢাকা পড়ে না।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickActionSheet(
    onDismiss: () -> Unit,
    onAction: (QuickAction) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        modifier = Modifier.testTag("quick_action_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 18.dp, end = 18.dp, bottom = 26.dp)
        ) {
            Text(
                text = "কী করতে চান?",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "একটি কাজ বেছে নিন",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(14.dp))

            QuickAction.entries.forEach { action ->
                QuickActionRow(action = action, onClick = { onAction(action) })
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

/** শিটের একটি সারি — রঙিন আইকন, বাংলা লেবেল ও ছোট বর্ণনা। */
@Composable
private fun QuickActionRow(
    action: QuickAction,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp, horizontal = 4.dp)
            .testTag("quick_action_${action.name}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(action.accent.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = action.icon,
                contentDescription = action.label,
                tint = action.accent,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(13.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = action.label,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = action.description,
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}
