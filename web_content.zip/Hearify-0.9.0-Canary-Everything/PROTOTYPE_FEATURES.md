# Hearify Experimental Everything Canary

This archive is a disposable visual/interaction stress-test. It is intentionally not the production architecture.

## Canary additions
- Mobile-first 390x844 shell with five primary tabs: Home, Search, Library, Rooms, Profile.
- Dark/night-first atmospheric shell with theme-reactive backdrop effects.
- Six additional experimental themes: Rainy City, Quiet Forest, Neon City, Late Night Study, Retro VHS, Game Night.
- Procedural ambient audio experiment using Web Audio API; fades down while real music plays and can be disabled or adjusted.
- Rich Home feed with mood cards, recent music, recommendations, room activity and social activity.
- Full Search screen with live bridge search + local fallback, suggestions, filters, empty/loading/error states.
- Library tabs for liked songs, history, playlists, albums and future saved spaces.
- Local canary likes, history, playlists, profile customization, settings and creator persistence.
- Expanded mock Rooms: discovery, joined room, shared queue, chat, reactions and room customization preview.
- Advanced theme atmosphere hooks: lighting, city silhouettes, reflections, particles and dynamic artwork glow.
- Hearify raccoon mascot built as lightweight SVG/CSS and recolored from theme variables.
- Profile tabs for overview, achievements and Echoes collection.
- Theme Creator preview with colors, particles, lighting, UI style and save/apply behavior.
- Experimental Lab overlay that exposes the canary philosophy and existing Prototype Lab.
- Onboarding for first launch.
- Persistent mini-player above mobile navigation.
- Dynamic artwork color accenting using a deterministic local color seed.

## Still mocked / partial
- Album and artist pages are represented by interactive cards rather than a complete deep-detail navigation system.
- Room synchronization, friends, followers, notifications and community themes are local/demo behavior.
- Ambient audio is procedural texture rather than theme-specific recorded sound files.
- The real YT Music bridge remains the playback/search source when available; the canary does not replace that backend.
- Native Android background playback is not provided here; this archive remains an HTML/Vite canary for the HTML → APK wrapper test.

## Build identifier
`Hearify · 0.9.0-canary · Experimental Everything`

## Intended next step
Use this canary on a phone, find the parts that actually feel like Hearify, then scrap the build and carry the successful ideas forward into the real roadmap.
