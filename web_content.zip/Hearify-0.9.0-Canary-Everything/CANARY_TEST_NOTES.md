# Hearify Canary Test Notes

## Quick phone pass
1. Open the app and finish/skip onboarding.
2. Switch among Home, Search, Library, Rooms and Profile.
3. Start a song from Home or Search and open the mini/full player.
4. Verify ambient audio fades away once real playback starts; toggle it from the header or Settings.
5. Switch themes, including the new experimental themes.
6. Open Profile → Achievements / Echoes / Edit profile.
7. Open Profile → Lab → Theme Creator and apply a custom vibe.
8. Create a temporary playlist and add a track.
9. Join a demo room, send a chat message and inspect the shared queue.
10. Reload the app and verify local canary state remains.

## Known verification limit
The source was syntax-checked with the TypeScript parser in this environment. The package dependency installation did not complete, so a full `vite build` could not be executed here.
