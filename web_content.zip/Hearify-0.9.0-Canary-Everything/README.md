# Hearify

Hearify is a music + rooms + friends prototype designed around a soft cloud UI.

## Frontend
```bash
npm install
npm run dev
```

The app remains usable without a music backend by falling back to a small YouTube-backed starter catalog. Search and playback are not tied to one hardcoded song.

## YouTube Music bridge
Hearify can use the unofficial `ytmusicapi` Python library through the included FastAPI bridge. The browser can also play starter catalog tracks through the YouTube IFrame player, so the prototype is not silent when the bridge is unavailable.

```bash
cd backend
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
# source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8787
```

The frontend defaults to the deployed Hearify bridge (`https://hearify-w782.onrender.com`). For a different bridge, or for a local bridge during development, set:

```env
VITE_YTMUSIC_API_URL=http://localhost:8787
```

You can also set `VITE_YTMUSIC_API_URL=/api` to use the included Netlify same-origin proxy. Direct HTTPS access to the bridge is the default because it removes an extra proxy layer.

The backend is intentionally separate because `ytmusicapi` is a Python library and browser code cannot directly import it. Do not put private browser/session cookies into the frontend.

## PWA
The project includes `public/manifest.json`, PWA icons, a service worker, and a Netlify SPA redirect. PWABuilder can inspect the manifest once the site is publicly deployed.

## Prototype status
See `PROTOTYPE_FEATURES.md` and the in-app Prototype Lab for the current version, changelog and upcoming ideas.


## v0.6.0
Smart autoplay queue now combines YouTube Music radio with related-song results, with lightweight UI animation and expanded themes.
