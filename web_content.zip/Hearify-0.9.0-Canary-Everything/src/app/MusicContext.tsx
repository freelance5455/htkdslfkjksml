import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { getSimilarMusic, hydrateTrack, MusicTrack, searchMusic } from './musicApi';

type MusicContextValue = {
  current: MusicTrack | null;
  queue: MusicTrack[];
  upNext: MusicTrack[];
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  loading: boolean;
  recommendationsLoading: boolean;
  error: string | null;
  playTrack: (track: MusicTrack) => Promise<void>;
  togglePlay: () => void;
  next: () => Promise<void>;
  previous: () => void;
  seek: (seconds: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  addToQueue: (track: MusicTrack) => void;
  removeFromQueue: (videoId: string) => void;
  clearQueue: () => void;
  searchTracks: typeof searchMusic;
};

const MusicContext = createContext<MusicContextValue | null>(null);
const STORAGE_KEY = 'hearify-queue-v3';
const VOLUME_KEY = 'hearify-volume';
const MAX_HISTORY = 40;
const RECOMMENDATION_COUNT = 20;

function readQueue(): MusicTrack[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((item) => item?.videoId && item?.title) : [];
  } catch {
    return [];
  }
}

type YouTubePlayer = {
  loadVideoById: (videoId: string) => void;
  playVideo: () => void;
  pauseVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead?: boolean) => void;
  setVolume: (volume: number) => void;
  getCurrentTime: () => number;
  getDuration: () => number;
};

type YouTubeStateEvent = { data: number; target?: YouTubePlayer };
type YouTubeApi = {
  Player: new (
    element: HTMLElement,
    options: {
      width: number;
      height: number;
      videoId?: string;
      playerVars?: Record<string, number | string>;
      events?: {
        onReady?: () => void;
        onStateChange?: (event: YouTubeStateEvent) => void;
        onError?: () => void;
        onAutoplayBlocked?: () => void;
      };
    },
  ) => YouTubePlayer;
};

declare global {
  interface Window {
    YT?: YouTubeApi;
    onYouTubeIframeAPIReady?: () => void;
  }
}

export function MusicProvider({ children }: { children: ReactNode }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const youtubeHostRef = useRef<HTMLDivElement | null>(null);
  const youtubePlayerRef = useRef<YouTubePlayer | null>(null);
  const youtubeApiReadyRef = useRef<Promise<void> | null>(null);
  const youtubePlayerReadyRef = useRef<Promise<void> | null>(null);
  const youtubeActiveRef = useRef(false);

  const [youtubeActive, setYoutubeActive] = useState(false);
  const [current, setCurrent] = useState<MusicTrack | null>(null);
  const [queue, setQueue] = useState<MusicTrack[]>(readQueue);
  const [radioQueue, setRadioQueue] = useState<MusicTrack[]>([]);
  const [recommendationsLoading, setRecommendationsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(() => {
    const stored = Number(localStorage.getItem(VOLUME_KEY));
    return Number.isFinite(stored) ? Math.min(1, Math.max(0, stored)) : 0.78;
  });
  const [muted, setMuted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const currentRef = useRef<MusicTrack | null>(null);
  const queueRef = useRef<MusicTrack[]>(queue);
  const radioQueueRef = useRef<MusicTrack[]>([]);
  const radioLoadingRef = useRef<Promise<void> | null>(null);
  const historyRef = useRef<MusicTrack[]>([]);
  const playingRef = useRef(false);
  const requestIdRef = useRef(0);
  const transitionRef = useRef(false);
  const pendingAutoplayRef = useRef(true);
  const endHandledRef = useRef(false);
  const progressTimerRef = useRef<number | null>(null);

  useEffect(() => { currentRef.current = current; }, [current]);
  useEffect(() => { queueRef.current = queue; }, [queue]);
  useEffect(() => { radioQueueRef.current = radioQueue; }, [radioQueue]);
  useEffect(() => { playingRef.current = isPlaying; }, [isPlaying]);
  useEffect(() => { youtubeActiveRef.current = youtubeActive; }, [youtubeActive]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(queue.slice(0, 50))); } catch { /* ignore storage errors */ }
  }, [queue]);

  useEffect(() => {
    const audio = audioRef.current;
    if (audio) audio.volume = muted ? 0 : volume;
    youtubePlayerRef.current?.setVolume(muted ? 0 : Math.round(volume * 100));
    localStorage.setItem(VOLUME_KEY, String(volume));
  }, [volume, muted]);

  const clearProgressTimer = () => {
    if (progressTimerRef.current !== null) {
      window.clearInterval(progressTimerRef.current);
      progressTimerRef.current = null;
    }
  };

  const startYouTubeProgress = () => {
    clearProgressTimer();
    progressTimerRef.current = window.setInterval(() => {
      const player = youtubePlayerRef.current;
      if (!player || !youtubeActiveRef.current) return;
      const time = Number(player.getCurrentTime?.() || 0);
      const total = Number(player.getDuration?.() || currentRef.current?.duration || 0);
      setCurrentTime(Number.isFinite(time) ? time : 0);
      if (Number.isFinite(total) && total > 0) setDuration(total);
    }, 250);
  };

  useEffect(() => clearProgressTimer, []);

  const ensureYouTubePlayer = async () => {
    if (!youtubeApiReadyRef.current) {
      youtubeApiReadyRef.current = new Promise<void>((resolve, reject) => {
        if (window.YT?.Player) {
          resolve();
          return;
        }

        const previousReady = window.onYouTubeIframeAPIReady;
        window.onYouTubeIframeAPIReady = () => {
          previousReady?.();
          resolve();
        };

        const existing = document.querySelector('script[src="https://www.youtube.com/iframe_api"]');
        if (!existing) {
          const script = document.createElement('script');
          script.src = 'https://www.youtube.com/iframe_api';
          script.async = true;
          script.onerror = () => reject(new Error('YouTube player failed to load'));
          document.head.appendChild(script);
        }
      });
    }

    await youtubeApiReadyRef.current;

    if (!youtubePlayerReadyRef.current) {
      if (!youtubeHostRef.current || !window.YT?.Player) throw new Error('YouTube player is unavailable');

      youtubePlayerReadyRef.current = new Promise<void>((resolve, reject) => {
        try {
          youtubePlayerRef.current = new window.YT!.Player(youtubeHostRef.current!, {
            width: 2,
            height: 2,
            playerVars: {
              autoplay: 0,
              controls: 0,
              playsinline: 1,
              rel: 0,
              modestbranding: 1,
              enablejsapi: 1,
              origin: window.location.origin,
            },
            events: {
              onReady: () => {
                youtubePlayerRef.current?.setVolume(muted ? 0 : Math.round(volume * 100));
                resolve();
              },
              onStateChange: (event) => {
                if (event.data === 1) {
                  setIsPlaying(true);
                  setLoading(false);
                  startYouTubeProgress();
                  return;
                }
                if (event.data === 2) {
                  setIsPlaying(false);
                  clearProgressTimer();
                  return;
                }
                if (event.data === 3) {
                  // Buffering: keep the play state visible while the player catches up.
                  setIsPlaying(true);
                  return;
                }
                if (event.data === 0 && !endHandledRef.current) {
                  endHandledRef.current = true;
                  void playNextRef.current();
                }
              },
              onError: () => {
                setLoading(false);
                setIsPlaying(false);
                setError('This song cannot be played here. Trying the next song…');
                endHandledRef.current = true;
                void playNextRef.current();
              },
              onAutoplayBlocked: () => {
                setLoading(false);
                setIsPlaying(false);
                setError('Playback was blocked by the browser. Press play to continue.');
              },
            },
          });
        } catch (err) {
          reject(err instanceof Error ? err : new Error('Unable to create YouTube player'));
        }
      });
    }

    await youtubePlayerReadyRef.current;
    return youtubePlayerRef.current!;
  };

  const prepareRecommendations = async (track: MusicTrack, requestId: number) => {
    setRecommendationsLoading(true);
    try {
      const tracks = await getSimilarMusic(track.videoId, RECOMMENDATION_COUNT);
      if (requestId !== requestIdRef.current) return;
      const seen = new Set<string>([
        track.videoId,
        ...queueRef.current.map((item) => item.videoId),
        ...historyRef.current.slice(0, 5).map((item) => item.videoId),
      ]);
      const unique = tracks.filter((item) => {
        if (seen.has(item.videoId)) return false;
        seen.add(item.videoId);
        return true;
      });
      radioQueueRef.current = unique;
      setRadioQueue(unique);
    } catch {
      if (requestId === requestIdRef.current) {
        radioQueueRef.current = [];
        setRadioQueue([]);
      }
    } finally {
      if (requestId === requestIdRef.current) setRecommendationsLoading(false);
      radioLoadingRef.current = null;
    }
  };

  const playResolved = async (requestedTrack: MusicTrack, rememberCurrent = true) => {
    const requestId = ++requestIdRef.current;
    const track = requestedTrack;

    setLoading(true);
    setError(null);
    transitionRef.current = true;
    endHandledRef.current = false;
    pendingAutoplayRef.current = true;

    const previous = currentRef.current;
    if (rememberCurrent && previous && previous.videoId !== track.videoId) {
      historyRef.current = [previous, ...historyRef.current.filter((item) => item.videoId !== previous.videoId)].slice(0, MAX_HISTORY);
    }

    setCurrent(track);
    currentRef.current = track;
    setCurrentTime(0);
    setDuration(track.duration || 0);

    const audio = audioRef.current;

    try {
      // First try direct streaming metadata from the Hearify bridge.
      const resolved = await hydrateTrack(track);
      if (requestId !== requestIdRef.current) return;

      setCurrent(resolved);
      currentRef.current = resolved;
      setDuration(resolved.duration || track.duration || 0);

      radioQueueRef.current = [];
      setRadioQueue([]);
      radioLoadingRef.current = prepareRecommendations(resolved, requestId);

      if (resolved.streamUrl && audio) {
        try {
          // Do not call stopVideo(): the YouTube API can emit an ENDED state from stopVideo().
          // Pausing is enough before moving playback to native audio.
          youtubePlayerRef.current?.pauseVideo();
          setYoutubeActive(false);
          youtubeActiveRef.current = false;
          clearProgressTimer();

          audio.pause();
          audio.src = resolved.streamUrl;
          audio.load();
          await audio.play();
          if (requestId !== requestIdRef.current) {
            audio.pause();
            return;
          }
          setIsPlaying(true);
          transitionRef.current = false;
          setLoading(false);
          return;
        } catch {
          // The signed stream may have expired or be rejected by the browser.
          // Fall through to the YouTube player using the same video id.
        }
      }

      if (resolved.videoId && !resolved.videoId.startsWith('demo-')) {
        const player = await ensureYouTubePlayer();
        if (requestId !== requestIdRef.current) return;

        audio?.pause();
        setYoutubeActive(true);
        youtubeActiveRef.current = true;
        clearProgressTimer();
        setIsPlaying(false);
        endHandledRef.current = false;

        // loadVideoById loads and plays the selected video; no stopVideo call is needed.
        player.loadVideoById(resolved.videoId);
        player.setVolume(muted ? 0 : Math.round(volume * 100));
        startYouTubeProgress();
        transitionRef.current = false;
        setLoading(false);
        return;
      }

      throw new Error('No playable source');
    } catch (err) {
      if (requestId !== requestIdRef.current) return;
      setIsPlaying(false);
      setLoading(false);
      transitionRef.current = false;
      setError(err instanceof Error && err.message === 'No playable source'
        ? 'No playable source was found for this song.'
        : 'Playback could not be started. Try another song.');
    }
  };

  const playNextRef = useRef<() => Promise<void>>(async () => undefined);

  const playNext = async () => {
    if (transitionRef.current) return;

    transitionRef.current = true;
    setLoading(true);
    setError(null);

    const manual = queueRef.current[0];
    if (manual) {
      setQueue((items) => items.slice(1));
      await playResolved(manual);
      return;
    }

    // If recommendations are still being generated for the current track,
    // wait for them instead of pretending the queue is empty.
    if (radioLoadingRef.current) {
      try { await radioLoadingRef.current; } catch { /* a fresh request below */ }
    }

    let nextTrack = radioQueueRef.current.shift();
    if (nextTrack) {
      setRadioQueue(radioQueueRef.current.slice());
      await playResolved(nextTrack);
      return;
    }

    const currentTrack = currentRef.current;
    if (currentTrack) {
      try {
        const tracks = await getSimilarMusic(currentTrack.videoId, RECOMMENDATION_COUNT);
        const seen = new Set<string>([currentTrack.videoId, ...historyRef.current.slice(0, 8).map((item) => item.videoId)]);
        const fresh = tracks.filter((item) => {
          if (seen.has(item.videoId)) return false;
          seen.add(item.videoId);
          return true;
        });
        radioQueueRef.current = fresh;
        setRadioQueue(fresh);
        nextTrack = radioQueueRef.current.shift();
        setRadioQueue(radioQueueRef.current.slice());
      } catch {
        nextTrack = undefined;
      }
    }

    if (nextTrack) {
      await playResolved(nextTrack);
      return;
    }

    transitionRef.current = false;
    setLoading(false);
    setIsPlaying(false);
    setRecommendationsLoading(false);
  };
  playNextRef.current = playNext;

  const playTrack = async (track: MusicTrack) => {
    await playResolved(track, true);
  };

  const togglePlay = () => {
    if (!currentRef.current || transitionRef.current) return;

    if (youtubeActiveRef.current) {
      const player = youtubePlayerRef.current;
      if (!player) return;
      if (playingRef.current) {
        player.pauseVideo();
        setIsPlaying(false);
      } else {
        setError(null);
        player.playVideo();
      }
      return;
    }

    const audio = audioRef.current;
    if (!audio) return;
    if (audio.paused) {
      void audio.play().then(() => {
        setIsPlaying(true);
        setError(null);
      }).catch(() => setError('Playback was blocked. Press play again.'));
    } else {
      audio.pause();
    }
  };

  const previous = () => {
    if (transitionRef.current) return;

    const elapsed = youtubeActiveRef.current
      ? Number(youtubePlayerRef.current?.getCurrentTime?.() || currentTime)
      : Number(audioRef.current?.currentTime || currentTime);

    if (elapsed > 5) {
      seek(0);
      return;
    }

    const previousTrack = historyRef.current.shift();
    if (previousTrack) {
      void playResolved(previousTrack, false);
      return;
    }

    seek(0);
  };

  const seek = (seconds: number) => {
    const max = duration > 0 ? duration : Number.MAX_SAFE_INTEGER;
    const nextTime = Math.min(max, Math.max(0, seconds));
    setCurrentTime(nextTime);
    if (youtubeActiveRef.current) youtubePlayerRef.current?.seekTo(nextTime, true);
    else if (audioRef.current) audioRef.current.currentTime = nextTime;
  };

  useEffect(() => {
    const audio = audioRef.current || new Audio();
    if (!audioRef.current) {
      audio.preload = 'metadata';
      audioRef.current = audio;
    }

    const onTime = () => setCurrentTime(Number.isFinite(audio.currentTime) ? audio.currentTime : 0);
    const onMeta = () => {
      if (Number.isFinite(audio.duration) && audio.duration > 0) setDuration(audio.duration);
    };
    const onPlay = () => {
      setIsPlaying(true);
      setLoading(false);
    };
    const onPause = () => setIsPlaying(false);
    const onEnded = () => {
      endHandledRef.current = true;
      void playNextRef.current();
    };
    const onError = () => {
      // Don't surface the native audio error immediately; playResolved already
      // has a YouTube fallback. If a direct stream is playing and fails later,
      // skip forward instead of leaving the app frozen.
      if (!youtubeActiveRef.current && currentRef.current) {
        void playNextRef.current();
      }
    };

    audio.addEventListener('timeupdate', onTime);
    audio.addEventListener('loadedmetadata', onMeta);
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onError);
    audio.volume = muted ? 0 : volume;

    return () => {
      audio.pause();
      audio.src = '';
      audio.removeEventListener('timeupdate', onTime);
      audio.removeEventListener('loadedmetadata', onMeta);
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('error', onError);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) return;
      if (event.key === 'ArrowRight') { event.preventDefault(); void playNextRef.current(); }
      if (event.key === 'ArrowLeft') { event.preventDefault(); previous(); }
      if (event.code === 'Space') { event.preventDefault(); togglePlay(); }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [currentTime, duration]);

  const setVolume = (value: number) => {
    const clamped = Math.min(1, Math.max(0, value));
    setVolumeState(clamped);
    youtubePlayerRef.current?.setVolume(muted ? 0 : Math.round(clamped * 100));
  };

  const toggleMute = () => setMuted((value) => !value);

  const addToQueue = (track: MusicTrack) => {
    setQueue((items) => items.some((item) => item.videoId === track.videoId) ? items : [...items, track]);
  };

  const removeFromQueue = (videoId: string) => {
    setQueue((items) => items.filter((item) => item.videoId !== videoId));
  };

  const clearQueue = () => setQueue([]);

  const value = useMemo<MusicContextValue>(() => ({
    current,
    queue,
    upNext: [...queue, ...radioQueue],
    isPlaying,
    currentTime,
    duration,
    volume,
    muted,
    loading,
    recommendationsLoading,
    error,
    playTrack,
    togglePlay,
    next: playNext,
    previous,
    seek,
    setVolume,
    toggleMute,
    addToQueue,
    removeFromQueue,
    clearQueue,
    searchTracks: searchMusic,
  }), [current, queue, radioQueue, isPlaying, currentTime, duration, volume, muted, loading, recommendationsLoading, error]);

  return (
    <MusicContext.Provider value={value}>
      {children}
      <div
        ref={youtubeHostRef}
        aria-hidden="true"
        style={{ position: 'fixed', width: 2, height: 2, left: -10, bottom: -10, opacity: 0.01, pointerEvents: 'none', overflow: 'hidden', zIndex: -1 }}
      />
    </MusicContext.Provider>
  );
}

export function useMusic() {
  const value = useContext(MusicContext);
  if (!value) throw new Error('useMusic must be used inside MusicProvider');
  return value;
}
