export type ThemeId =
  | "daylight"
  | "sunset"
  | "night"
  | "rainy"
  | "rainbow"
  | "ducks"
  | "sakura"
  | "ocean"
  | "lavender" | "forest" | "candy" | "arcade" | "peach" | "thunderstorm"
  | "cafe" | "midnight" | "mint" | "rose" | "starlight" | "lavacake"
  | "lavendernight" | "cloudmilk" | "berrymist" | "seaside" | "autumn" | "strawberry" | "aurora" | "space"
  | "rainycity" | "quietforest" | "neoncity" | "latenightstudy" | "retrovhs" | "gamenight";

export type Theme = {
  id: ThemeId;
  name: string;
  icon: string;
  description: string;
  sky: string;
  text: string;
  muted: string;
  primary: string;
  accent: string;
  pink: string;
  glass: string;
  glassStrong: string;
  border: string;
  shadow: string;
  note: string;
  effects: "clouds" | "stars" | "rain" | "rainbow" | "ducks" | "petals" | "bubbles";
};

export const THEMES: Theme[] = [
  {
    id: "daylight",
    name: "Daylight",
    icon: "☀️",
    description: "Soft skies and the classic Hearify look.",
    sky: "linear-gradient(160deg, #fff8c9 0%, #ffe2ae 28%, #ffd3e6 58%, #ddd2ff 100%)",
    text: "#3d2c5e",
    muted: "#9279ae",
    primary: "#b56df2",
    accent: "#6f86f7",
    pink: "#ee6fa9",
    glass: "rgba(255,255,255,0.68)",
    glassStrong: "rgba(255,255,255,0.84)",
    border: "rgba(255,255,255,0.72)",
    shadow: "rgba(80,40,160,0.16)",
    note: "rgba(130,100,190,0.5)",
    effects: "clouds",
  },
  {
    id: "sunset",
    name: "Sunset",
    icon: "🌇",
    description: "Warm orange skies for golden-hour listening.",
    sky: "linear-gradient(165deg, #ffd6a0 0%, #ff9f9f 36%, #e67bb8 66%, #7566ce 100%)",
    text: "#402443",
    muted: "#865b7c",
    primary: "#e66d8a",
    accent: "#8d65dc",
    pink: "#f27c9e",
    glass: "rgba(255,248,244,0.6)",
    glassStrong: "rgba(255,248,244,0.78)",
    border: "rgba(255,255,255,0.55)",
    shadow: "rgba(82,30,80,0.18)",
    note: "rgba(255,245,245,0.5)",
    effects: "clouds",
  },
  {
    id: "night",
    name: "Night",
    icon: "🌙",
    description: "Deep purple skies and sleepy neon accents.",
    sky: "linear-gradient(165deg, #171a3a 0%, #242153 44%, #46306e 72%, #18172e 100%)",
    text: "#f6efff",
    muted: "#b8a9d2",
    primary: "#b98cff",
    accent: "#7c8cff",
    pink: "#ee82bb",
    glass: "rgba(32,27,63,0.64)",
    glassStrong: "rgba(39,33,73,0.84)",
    border: "rgba(255,255,255,0.12)",
    shadow: "rgba(5,4,20,0.38)",
    note: "rgba(235,220,255,0.48)",
    effects: "stars",
  },
  {
    id: "rainy",
    name: "Rainy Night",
    icon: "🌧️",
    description: "Moody rain, cool glass and city-after-dark energy.",
    sky: "linear-gradient(165deg, #101d2c 0%, #1f3146 40%, #273b56 70%, #151b2a 100%)",
    text: "#edf5ff",
    muted: "#9eb1c7",
    primary: "#73b7ff",
    accent: "#7a8cff",
    pink: "#83c9f8",
    glass: "rgba(22,35,52,0.64)",
    glassStrong: "rgba(25,40,60,0.86)",
    border: "rgba(180,220,255,0.16)",
    shadow: "rgba(2,10,20,0.5)",
    note: "rgba(170,220,255,0.42)",
    effects: "rain",
  },
  {
    id: "rainbow",
    name: "Rainbow",
    icon: "🌈",
    description: "Maximum color. Zero seriousness. Pure vibes.",
    sky: "linear-gradient(145deg, #ffe2ec 0%, #ffe7af 22%, #d9ffd8 44%, #c9efff 64%, #e6d6ff 84%, #ffd8f1 100%)",
    text: "#3e2a56",
    muted: "#826d9e",
    primary: "#a66df2",
    accent: "#5da8ef",
    pink: "#ef70b8",
    glass: "rgba(255,255,255,0.58)",
    glassStrong: "rgba(255,255,255,0.78)",
    border: "rgba(255,255,255,0.72)",
    shadow: "rgba(90,50,150,0.14)",
    note: "rgba(130,100,200,0.42)",
    effects: "rainbow",
  },
  {
    id: "ducks",
    name: "Ducks",
    icon: "🦆",
    description: "Absolutely no reason. Just ducks.",
    sky: "linear-gradient(160deg, #fff9c4 0%, #e7f7c7 42%, #bdeecf 72%, #a9dceb 100%)",
    text: "#314b3e",
    muted: "#6f8d7d",
    primary: "#e3a92d",
    accent: "#45a981",
    pink: "#ef8f9f",
    glass: "rgba(255,255,248,0.67)",
    glassStrong: "rgba(255,255,248,0.84)",
    border: "rgba(255,255,255,0.74)",
    shadow: "rgba(54,91,70,0.14)",
    note: "rgba(69,150,125,0.42)",
    effects: "ducks",
  },
  {
    id: "sakura",
    name: "Sakura",
    icon: "🌸",
    description: "Blush clouds, petals and a calmer pink palette.",
    sky: "linear-gradient(160deg, #fff6fb 0%, #ffddea 36%, #f4d6ff 68%, #d9d7ff 100%)",
    text: "#4d2c4b",
    muted: "#9b7294",
    primary: "#da75bb",
    accent: "#9a82ed",
    pink: "#ef78ad",
    glass: "rgba(255,255,255,0.66)",
    glassStrong: "rgba(255,255,255,0.84)",
    border: "rgba(255,255,255,0.74)",
    shadow: "rgba(150,68,120,0.15)",
    note: "rgba(195,110,165,0.42)",
    effects: "petals",
  },
  {
    id: "ocean",
    name: "Ocean",
    icon: "🌊",
    description: "A breezy blue theme for chill sessions.",
    sky: "linear-gradient(160deg, #c9f4ff 0%, #b9e6ff 35%, #c9dcff 63%, #ded1ff 100%)",
    text: "#27405d",
    muted: "#6983a1",
    primary: "#5f9ff3",
    accent: "#6c78db",
    pink: "#d27ec8",
    glass: "rgba(247,252,255,0.62)",
    glassStrong: "rgba(247,252,255,0.82)",
    border: "rgba(255,255,255,0.7)",
    shadow: "rgba(35,83,145,0.16)",
    note: "rgba(88,143,200,0.38)",
    effects: "bubbles",
  },
  {
    id: "lavender",
    name: "Lavender Dream",
    icon: "💜",
    description: "A soft purple cloudscape for slow listening.",
    sky: "linear-gradient(160deg,#f7efff 0%,#e5d5ff 45%,#c9c1ff 74%,#e3d4ff 100%)",
    text: "#4a356b", muted: "#8d78ad", primary: "#9d78ef", accent: "#c07ce7", pink: "#e49acb",
    glass: "rgba(255,255,255,.62)", glassStrong: "rgba(255,255,255,.82)", border: "rgba(255,255,255,.72)", shadow: "rgba(90,55,145,.16)", note: "rgba(140,110,190,.42)", effects: "clouds",
  },
  {
    id: "forest",
    name: "Forest",
    icon: "🌲",
    description: "Mossy greens and quiet morning air.",
    sky: "linear-gradient(160deg,#e9f7df 0%,#cfe9ce 38%,#add7bd 70%,#98c7c0 100%)",
    text: "#29483d", muted: "#688a7c", primary: "#61a779", accent: "#4a8fbd", pink: "#d98fa4",
    glass: "rgba(250,255,249,.62)", glassStrong: "rgba(250,255,249,.82)", border: "rgba(255,255,255,.72)", shadow: "rgba(44,94,63,.16)", note: "rgba(76,137,106,.42)", effects: "clouds",
  },
  {
    id: "candy",
    name: "Candy",
    icon: "🍭",
    description: "Pastel sugar-rush energy.",
    sky: "linear-gradient(145deg,#fff0f8 0%,#ffd6ed 30%,#d9d1ff 58%,#c9f2ff 100%)",
    text: "#553b67", muted: "#9b78a4", primary: "#f178c5", accent: "#7e8ef3", pink: "#ff9bd3",
    glass: "rgba(255,255,255,.66)", glassStrong: "rgba(255,255,255,.84)", border: "rgba(255,255,255,.74)", shadow: "rgba(164,73,144,.14)", note: "rgba(190,100,180,.42)", effects: "rainbow",
  },
  {
    id: "arcade",
    name: "Neon Arcade",
    icon: "🕹️",
    description: "Late-night pixels and electric color.",
    sky: "linear-gradient(150deg,#0c112a 0%,#18285a 45%,#3a1d61 75%,#10142c 100%)",
    text: "#f7f2ff", muted: "#a9b5d7", primary: "#68e7ff", accent: "#c56cff", pink: "#ff69b8",
    glass: "rgba(20,25,56,.62)", glassStrong: "rgba(25,31,68,.84)", border: "rgba(142,211,255,.18)", shadow: "rgba(2,6,24,.46)", note: "rgba(120,225,255,.42)", effects: "stars",
  },
  {
    id: "peach",
    name: "Peachy",
    icon: "🍑",
    description: "Warm, soft and sunny without being loud.",
    sky: "linear-gradient(160deg,#fff7e6 0%,#ffd9c1 42%,#ffc0d2 72%,#e8d7ff 100%)",
    text: "#5a3c46", muted: "#a07d86", primary: "#f19b78", accent: "#d78ae8", pink: "#ef7fa8",
    glass: "rgba(255,252,248,.66)", glassStrong: "rgba(255,252,248,.84)", border: "rgba(255,255,255,.74)", shadow: "rgba(149,79,76,.15)", note: "rgba(200,125,115,.4)", effects: "clouds",
  },
  {
    id: "thunderstorm",
    name: "Thunderstorm",
    icon: "⛈️",
    description: "Dark clouds with tiny flashes of energy.",
    sky: "linear-gradient(165deg,#121928 0%,#25334d 45%,#34324f 72%,#10131f 100%)",
    text: "#f1f5ff", muted: "#a8b4c9", primary: "#7db4ff", accent: "#b487ff", pink: "#7ed9ff",
    glass: "rgba(25,32,48,.64)", glassStrong: "rgba(30,39,58,.86)", border: "rgba(190,220,255,.15)", shadow: "rgba(0,0,0,.45)", note: "rgba(190,215,255,.38)", effects: "rain",
  },
  { id: "cafe", name: "Café", icon: "☕", description: "Warm coffee tones for quiet sessions.", sky: "linear-gradient(160deg,#fff4dd 0%,#efd4bb 42%,#d6b4a0 72%,#b9968c 100%)", text: "#4c342d", muted: "#8c7066", primary: "#c58a62", accent: "#8f6a5a", pink: "#d99aa7", glass: "rgba(255,249,241,.64)", glassStrong: "rgba(255,249,241,.84)", border: "rgba(255,255,255,.72)", shadow: "rgba(87,57,42,.16)", note: "rgba(148,104,82,.4)", effects: "clouds" },
  { id: "midnight", name: "Midnight Blue", icon: "🌌", description: "Deep blue calm for late-night listening.", sky: "linear-gradient(165deg,#080f22 0%,#10274d 48%,#1f3861 72%,#090e1d 100%)", text: "#eef6ff", muted: "#9fb4d2", primary: "#62b2ff", accent: "#6f7df2", pink: "#d28eff", glass: "rgba(13,25,48,.62)", glassStrong: "rgba(17,32,59,.86)", border: "rgba(161,209,255,.16)", shadow: "rgba(0,5,18,.48)", note: "rgba(156,206,255,.38)", effects: "stars" },
  { id: "mint", name: "Mint", icon: "🌱", description: "Fresh green glass and a clean morning feel.", sky: "linear-gradient(160deg,#effff5 0%,#d6f7e4 40%,#bcebd8 72%,#c7e8f5 100%)", text: "#29483f", muted: "#6b8f84", primary: "#5dbb8c", accent: "#5fa8df", pink: "#de8fb1", glass: "rgba(250,255,252,.66)", glassStrong: "rgba(250,255,252,.84)", border: "rgba(255,255,255,.74)", shadow: "rgba(47,105,77,.14)", note: "rgba(78,151,120,.4)", effects: "bubbles" },
  { id: "rose", name: "Rose Hush", icon: "🌹", description: "Muted rose colors without the candy overload.", sky: "linear-gradient(160deg,#fff7f7 0%,#f8dadd 42%,#e7c8e4 72%,#cccdf0 100%)", text: "#523943", muted: "#9a7384", primary: "#d47f9a", accent: "#8d7bd3", pink: "#ea86ad", glass: "rgba(255,255,255,.66)", glassStrong: "rgba(255,255,255,.84)", border: "rgba(255,255,255,.74)", shadow: "rgba(123,63,87,.15)", note: "rgba(176,105,139,.4)", effects: "petals" },
  { id: "starlight", name: "Starlight", icon: "✨", description: "Soft silver-blue night with tiny stars.", sky: "linear-gradient(165deg,#11182b 0%,#283a61 42%,#5a668e 70%,#171b2d 100%)", text: "#f3f6ff", muted: "#b5c0d9", primary: "#9db7ff", accent: "#d2a4ff", pink: "#8ee1ff", glass: "rgba(25,33,54,.60)", glassStrong: "rgba(30,40,65,.84)", border: "rgba(220,235,255,.16)", shadow: "rgba(4,8,20,.42)", note: "rgba(220,232,255,.38)", effects: "stars" },
  { id: "lavacake", name: "Lavacake", icon: "🍰", description: "Warm chocolate, cream and cozy evening vibes.", sky: "linear-gradient(160deg,#fff0de 0%,#e7c4ab 42%,#b9898d 72%,#5b4b67 100%)", text: "#49333d", muted: "#856a74", primary: "#c27c86", accent: "#8f78cc", pink: "#dd97b1", glass: "rgba(255,247,240,.58)", glassStrong: "rgba(255,247,240,.78)", border: "rgba(255,255,255,.65)", shadow: "rgba(76,44,52,.20)", note: "rgba(175,116,130,.4)", effects: "clouds" },
  { id: "lavendernight", name: "Lavender Night", icon: "🪻", description: "Purple dusk, soft stars and a dreamy late-night glow.", sky: "linear-gradient(165deg,#151326 0%,#302453 45%,#5d4c83 74%,#171426 100%)", text: "#f8f1ff", muted: "#baaed1", primary: "#b89aff", accent: "#7f92ff", pink: "#e496db", glass: "rgba(30,24,53,.62)", glassStrong: "rgba(38,30,66,.84)", border: "rgba(231,220,255,.15)", shadow: "rgba(8,4,20,.46)", note: "rgba(205,180,255,.42)", effects: "stars" },
  { id: "cloudmilk", name: "Cloud Milk", icon: "🥛", description: "Creamy whites and barely-there blue for quiet focus.", sky: "linear-gradient(160deg,#fffdf7 0%,#f5f4ed 42%,#dcebf4 75%,#e6e1f2 100%)", text: "#435063", muted: "#8290a2", primary: "#8ea8d8", accent: "#b594d8", pink: "#dfa9bc", glass: "rgba(255,255,255,.72)", glassStrong: "rgba(255,255,255,.88)", border: "rgba(255,255,255,.82)", shadow: "rgba(77,89,112,.13)", note: "rgba(130,155,185,.35)", effects: "clouds" },
  { id: "berrymist", name: "Berry Mist", icon: "🫐", description: "Blueberry-purple haze with soft berry accents.", sky: "linear-gradient(160deg,#f1ecff 0%,#d8d2ff 38%,#c6d8f3 68%,#edd1e8 100%)", text: "#453d63", muted: "#827b9c", primary: "#827de8", accent: "#6aa7e7", pink: "#df8fc3", glass: "rgba(255,255,255,.62)", glassStrong: "rgba(255,255,255,.82)", border: "rgba(255,255,255,.72)", shadow: "rgba(81,70,148,.15)", note: "rgba(122,121,190,.4)", effects: "bubbles" },
  { id: "seaside", name: "Seaside", icon: "🏖️", description: "Clear water, pale sand and a breezy afternoon feel.", sky: "linear-gradient(160deg,#e9fcff 0%,#bfeff3 35%,#acd9f2 68%,#ffe4c0 100%)", text: "#2c5061", muted: "#6c8e9d", primary: "#58a9ce", accent: "#6fc3a8", pink: "#f0a2a8", glass: "rgba(251,255,255,.64)", glassStrong: "rgba(251,255,255,.84)", border: "rgba(255,255,255,.74)", shadow: "rgba(47,108,131,.15)", note: "rgba(87,156,182,.38)", effects: "bubbles" },
  { id: "autumn", name: "Autumn", icon: "🍂", description: "Amber evenings, falling leaves and cozy playlists.", sky: "linear-gradient(160deg,#fff1d2 0%,#f4c18f 36%,#d7938c 68%,#7771ad 100%)", text: "#513b3a", muted: "#8e706b", primary: "#cf855c", accent: "#8d79c7", pink: "#dd93a2", glass: "rgba(255,250,241,.62)", glassStrong: "rgba(255,250,241,.82)", border: "rgba(255,255,255,.7)", shadow: "rgba(112,67,42,.17)", note: "rgba(178,113,82,.42)", effects: "petals" },
  { id: "strawberry", name: "Strawberry", icon: "🍓", description: "Fresh pinks, cream and a little summertime sweetness.", sky: "linear-gradient(150deg,#fff4f7 0%,#ffd4df 34%,#ffc0ca 68%,#f3d5ff 100%)", text: "#5b3847", muted: "#a27888", primary: "#e86f99", accent: "#aa83e8", pink: "#f78eaa", glass: "rgba(255,255,255,.67)", glassStrong: "rgba(255,255,255,.85)", border: "rgba(255,255,255,.75)", shadow: "rgba(157,65,96,.15)", note: "rgba(218,105,137,.4)", effects: "petals" },
  { id: "aurora", name: "Aurora", icon: "🟢", description: "Cool night air with a soft northern-light gradient.", sky: "linear-gradient(155deg,#071521 0%,#10364a 38%,#214c61 62%,#423d70 100%)", text: "#effcff", muted: "#9bc2c8", primary: "#64dfbb", accent: "#7d9cff", pink: "#b98ff1", glass: "rgba(10,33,43,.62)", glassStrong: "rgba(14,42,55,.84)", border: "rgba(177,255,234,.15)", shadow: "rgba(1,12,18,.5)", note: "rgba(108,229,195,.4)", effects: "stars" },
  { id: "space", name: "Space", icon: "🪐", description: "Deep cosmic blue with tiny drifting stars.", sky: "linear-gradient(165deg,#050712 0%,#11173b 45%,#272152 72%,#070912 100%)", text: "#f5f6ff", muted: "#a7add0", primary: "#8aa4ff", accent: "#c084fc", pink: "#f08bd9", glass: "rgba(9,12,29,.64)", glassStrong: "rgba(14,18,42,.86)", border: "rgba(176,193,255,.14)", shadow: "rgba(0,0,9,.52)", note: "rgba(167,186,255,.4)", effects: "stars" },
  { id: "rainycity", name: "Rainy City", icon: "🌧️", description: "Rain on glass, neon reflections and a quiet city hum.", sky: "linear-gradient(165deg,#07111c 0%,#13283a 42%,#1d3e52 70%,#0a1019 100%)", text: "#eef8ff", muted: "#9bb3c4", primary: "#69c4ff", accent: "#8a78ff", pink: "#80d7ff", glass: "rgba(10,25,38,.64)", glassStrong: "rgba(14,32,48,.86)", border: "rgba(175,225,255,.16)", shadow: "rgba(0,6,14,.52)", note: "rgba(154,220,255,.42)", effects: "rain" },
  { id: "quietforest", name: "Quiet Forest", icon: "🌲", description: "Fireflies, deep greens and an almost-silent night.", sky: "linear-gradient(165deg,#071510 0%,#173527 42%,#235040 72%,#09130f 100%)", text: "#ebfff1", muted: "#9bbcac", primary: "#77d99e", accent: "#9ddf6f", pink: "#e2a1b8", glass: "rgba(8,26,18,.62)", glassStrong: "rgba(12,35,24,.84)", border: "rgba(184,255,205,.14)", shadow: "rgba(0,10,5,.5)", note: "rgba(175,239,192,.36)", effects: "stars" },
  { id: "neoncity", name: "Neon City", icon: "🌃", description: "Electric purple, cyan signs and moving night lights.", sky: "linear-gradient(155deg,#070919 0%,#171743 38%,#37195a 72%,#080914 100%)", text: "#f5f7ff", muted: "#a9afd2", primary: "#66e7ff", accent: "#c56cff", pink: "#ff72bd", glass: "rgba(14,14,39,.64)", glassStrong: "rgba(20,18,53,.86)", border: "rgba(114,235,255,.16)", shadow: "rgba(0,0,14,.54)", note: "rgba(113,225,255,.38)", effects: "stars" },
  { id: "latenightstudy", name: "Late Night Study", icon: "📚", description: "Warm desk light, rain outside and a very quiet room.", sky: "linear-gradient(155deg,#17120f 0%,#39291e 38%,#5b4042 70%,#14101a 100%)", text: "#fff7eb", muted: "#cbb3a0", primary: "#e6aa67", accent: "#b48bff", pink: "#e699a9", glass: "rgba(39,28,22,.62)", glassStrong: "rgba(47,34,26,.86)", border: "rgba(255,219,180,.15)", shadow: "rgba(16,7,3,.5)", note: "rgba(236,190,140,.35)", effects: "rain" },
  { id: "retrovhs", name: "Retro VHS", icon: "📼", description: "Soft scanlines, tape grain and nostalgic electric color.", sky: "linear-gradient(155deg,#170f1d 0%,#382052 40%,#5a3157 72%,#120c17 100%)", text: "#fff2ff", muted: "#c0a6c8", primary: "#ff7fc5", accent: "#8f9cff", pink: "#ffb06f", glass: "rgba(33,19,43,.64)", glassStrong: "rgba(44,24,56,.86)", border: "rgba(255,191,230,.15)", shadow: "rgba(8,2,12,.52)", note: "rgba(255,163,215,.4)", effects: "stars" },
  { id: "gamenight", name: "Game Night", icon: "🎮", description: "Playful arcade glow with tiny bursts of energy.", sky: "linear-gradient(150deg,#07131a 0%,#112c3e 38%,#1f3c55 68%,#131027 100%)", text: "#f3feff", muted: "#9bc0ce", primary: "#55e4ce", accent: "#ff6fb3", pink: "#8da8ff", glass: "rgba(12,28,39,.64)", glassStrong: "rgba(16,36,49,.86)", border: "rgba(132,255,228,.15)", shadow: "rgba(0,6,12,.48)", note: "rgba(135,239,224,.38)", effects: "rainbow" },
];

export const DEFAULT_THEME: ThemeId = "night";

export function getTheme(id: ThemeId) {
  return THEMES.find((theme) => theme.id === id) ?? THEMES[0];
}
