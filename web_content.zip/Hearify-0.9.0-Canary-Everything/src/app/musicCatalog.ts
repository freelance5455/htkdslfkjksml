import type { MusicTrack } from './musicApi';

// Small, real YouTube-backed catalog used when the optional ytmusicapi bridge is unavailable.
// It keeps the prototype playable on a static Netlify deployment while the bridge is being wired up.
export const LOCAL_CATALOG: MusicTrack[] = [
  { videoId: '4NRXx6U8ABQ', title: 'Blinding Lights', artist: 'The Weeknd', album: 'After Hours', duration: 200, durationText: '3:20', thumbnail: 'https://i.ytimg.com/vi/4NRXx6U8ABQ/hqdefault.jpg', source: 'youtube' },
  { videoId: 'H5v3kku4y6Q', title: 'As It Was', artist: 'Harry Styles', album: "Harry's House", duration: 167, durationText: '2:47', thumbnail: 'https://i.ytimg.com/vi/H5v3kku4y6Q/hqdefault.jpg', source: 'youtube' },
  { videoId: 'kPa7bsKwL-c', title: 'Die With A Smile', artist: 'Lady Gaga & Bruno Mars', album: 'MAYHEM', duration: 253, durationText: '4:13', thumbnail: 'https://i.ytimg.com/vi/kPa7bsKwL-c/hqdefault.jpg', source: 'youtube' },
  { videoId: 'Oa_RSwwpPaA', title: 'Beautiful Things', artist: 'Benson Boone', album: 'Fireworks & Rollerblades', duration: 193, durationText: '3:13', thumbnail: 'https://i.ytimg.com/vi/Oa_RSwwpPaA/hqdefault.jpg', source: 'youtube' },
  { videoId: 'eVli-tstM5E', title: 'Espresso', artist: 'Sabrina Carpenter', album: 'Short n’ Sweet', duration: 201, durationText: '3:21', thumbnail: 'https://i.ytimg.com/vi/eVli-tstM5E/hqdefault.jpg', source: 'youtube' },
  { videoId: 'djV11Xbc914', title: 'Take On Me', artist: 'a-ha', album: 'Hunting High and Low', duration: 244, durationText: '4:04', thumbnail: 'https://i.ytimg.com/vi/djV11Xbc914/hqdefault.jpg', source: 'youtube' },
  { videoId: 'ApXoWvfEYVU', title: 'Sunflower', artist: 'Post Malone & Swae Lee', album: 'Spider-Man: Into the Spider-Verse', duration: 159, durationText: '2:39', thumbnail: 'https://i.ytimg.com/vi/ApXoWvfEYVU/hqdefault.jpg', source: 'youtube' },
  { videoId: 'nyuo9-OjNNg', title: 'I Wanna Be Yours', artist: 'Arctic Monkeys', album: 'AM', duration: 184, durationText: '3:04', thumbnail: 'https://i.ytimg.com/vi/nyuo9-OjNNg/hqdefault.jpg', source: 'youtube' },
  { videoId: 'pXRviuL6vMY', title: 'Stressed Out', artist: 'twenty one pilots', album: 'Blurryface', duration: 213, durationText: '3:33', thumbnail: 'https://i.ytimg.com/vi/pXRviuL6vMY/hqdefault.jpg', source: 'youtube' },
  { videoId: 'DyDfgMOUjCI', title: 'bad guy', artist: 'Billie Eilish', album: 'WHEN WE ALL FALL ASLEEP, WHERE DO WE GO?', duration: 194, durationText: '3:14', thumbnail: 'https://i.ytimg.com/vi/DyDfgMOUjCI/hqdefault.jpg', source: 'youtube' },
  { videoId: 'Vk5-c_v4gMU', title: 'Magnetic', artist: 'ILLIT', duration: 189, durationText: '3:09', thumbnail: 'https://i.ytimg.com/vi/Vk5-c_v4gMU/hqdefault.jpg', source: 'youtube' },
];

export const LOCAL_SEARCH_HINTS = ['popular songs', 'top hits', 'music', 'songs', 'new music', 'trending'];
