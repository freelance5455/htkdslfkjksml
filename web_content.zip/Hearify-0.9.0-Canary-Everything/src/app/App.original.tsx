import { useEffect, useState, type CSSProperties } from "react";
import { motion, AnimatePresence } from "motion/react";
import { CloudBackground } from "./components/CloudBackground";
import { HomeScreen } from "./components/HomeScreen";
import { DiscoverScreen } from "./components/DiscoverScreen";
import { RoomScreen } from "./components/RoomScreen";
import { ProfileScreen } from "./components/ProfileScreen";
import { CreateRoomScreen } from "./components/CreateRoomScreen";
import { ThemePicker } from "./components/ThemePicker";
import { SettingsScreen } from "./components/SettingsScreen";
import { NowPlayingSheet } from "./components/NowPlayingSheet";
import { SearchOverlay } from "./components/SearchOverlay";
import { NotificationsPanel } from "./components/NotificationsPanel";
import { OfflineScreen } from "./components/OfflineScreen";
import { ActiveRoomsSheet } from "./components/ActiveRoomsSheet";
import { PrototypeLab } from "./components/PrototypeLab";
import { DEFAULT_THEME, getTheme, ThemeId } from "./themes";

type Tab = "home" | "discover" | "rooms" | "offline" | "profile" | "lab";
type Screen = "feed" | "room" | "create";

const NAV_ITEMS: { tab: Tab; emoji: string; label: string }[] = [
  { tab: "home", emoji: "🏠", label: "Home" },
  { tab: "discover", emoji: "🔍", label: "Discover" },
  { tab: "rooms", emoji: "🎵", label: "Rooms" },
  { tab: "offline", emoji: "📥", label: "Offline" },
  { tab: "profile", emoji: "👤", label: "Profile" },
  { tab: "lab", emoji: "🧪", label: "Lab" },
];

// Hearify logo — white hand-drawn "H" with music note
function HearifyLogo({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <rect width="48" height="48" rx="14" fill="url(#logoGrad)" />
      <defs>
        <linearGradient id="logoGrad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop stopColor="var(--primary)" />
          <stop offset="0.5" stopColor="var(--pink)" />
          <stop offset="1" stopColor="var(--accent)" />
        </linearGradient>
      </defs>
      {/* H */}
      <path d="M13 12 L13 36" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M13 24 L27 24" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M27 12 L27 30" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
      {/* Music note integrated */}
      <path d="M27 30 L34 27" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M34 27 L34 34" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
      <ellipse cx="32" cy="35" rx="2.5" ry="2" fill="white" />
    </svg>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [screen, setScreen] = useState<Screen>("feed");
  const [themeId, setThemeId] = useState<ThemeId>(() => {
    const saved = localStorage.getItem("hearify-theme") as ThemeId | null;
    return saved ?? DEFAULT_THEME;
  });
  const [showThemes, setShowThemes] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showPlayer, setShowPlayer] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showActiveRooms, setShowActiveRooms] = useState(false);
  const theme = getTheme(themeId);

  useEffect(() => {
    localStorage.setItem("hearify-theme", themeId);
  }, [themeId]);

  function handleNavTab(tab: Tab) {
    if (tab === "rooms") {
      setScreen("create");
      setActiveTab(tab);
    } else {
      setScreen("feed");
      setActiveTab(tab);
    }
  }

  const showNavBar = screen === "feed";

  return (
    <div className="hearify-original-layout flex items-center justify-center size-full"
      data-theme={theme.id}
      style={{
        background: theme.sky,
        "--sky": theme.sky,
        "--text": theme.text,
        "--muted-text": theme.muted,
        "--primary": theme.primary,
        "--accent": theme.accent,
        "--pink": theme.pink,
        "--glass": theme.glass,
        "--glass-strong": theme.glassStrong,
        "--border": theme.border,
        "--shadow": theme.shadow,
        "--note": theme.note,
        "--success": "#4ade80",
        "--muted": "color-mix(in srgb, var(--muted-text) 25%, transparent)",
      } as CSSProperties}
    >
      {/* Mobile frame */}
      <div
        className="relative overflow-hidden flex flex-col"
        style={{
          width: "min(390px, 100vw)",
          height: "min(844px, 100vh)",
          borderRadius: "min(44px, 0px)",
          boxShadow: "0 32px 80px rgba(80,40,160,0.18), 0 8px 24px rgba(0,0,0,0.1)",
          position: "relative",
        }}
      >
        <CloudBackground theme={theme} />

        {/* Content area */}
        <div className="relative flex-1 overflow-hidden" style={{ zIndex: 10 }}>
          <AnimatePresence mode="wait">
            {screen === "room" ? (
              <motion.div
                key="room"
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 28, stiffness: 300 }}
                className="absolute inset-0"
              >
                <RoomScreen onBack={() => setScreen("feed")} />
              </motion.div>
            ) : screen === "create" ? (
              <motion.div
                key="create"
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 28, stiffness: 300 }}
                className="absolute inset-0"
              >
                <CreateRoomScreen
                  onBack={() => { setScreen("feed"); setActiveTab("home"); }}
                  onCreated={() => { setScreen("room"); setActiveTab("home"); }}
                />
              </motion.div>
            ) : (
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.22 }}
                className="absolute inset-0"
                style={{ paddingBottom: 72 }}
              >
                {activeTab === "home" && (
                  <HomeScreen onRoomSelect={() => setScreen("room")} onSearch={() => setShowSearch(true)} onNotifications={() => setShowNotifications(true)} onOpenPlayer={() => setShowPlayer(true)} onSeeAllRooms={() => setShowActiveRooms(true)} />
                )}
                {activeTab === "discover" && (
                  <DiscoverScreen onRoomSelect={() => setScreen("room")} />
                )}
                {activeTab === "offline" && (
                  <OfflineScreen onPlay={() => setShowPlayer(true)} />
                )}
                {activeTab === "lab" && <PrototypeLab />}
                {activeTab === "profile" && (
                  <ProfileScreen onOpenThemes={() => { setShowSettings(false); setShowThemes(true); }} onOpenSettings={() => { setShowThemes(false); setShowSettings(true); }} />
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Bottom navigation */}
        <AnimatePresence>
          {showNavBar && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              className="absolute bottom-0 left-0 right-0"
              style={{ zIndex: 20 }}
            >
              <div
                style={{
                  margin: "0 12px 12px",
                  background: "var(--glass-strong)",
                  backdropFilter: "blur(20px)",
                  borderRadius: 28,
                  border: "1.5px solid var(--border)",
                  boxShadow: "0 8px 32px var(--shadow), 0 2px 8px color-mix(in srgb, var(--primary) 15%, transparent)",
                  display: "flex",
                  alignItems: "center",
                  padding: "8px 6px",
                  gap: 2,
                }}
              >
                {NAV_ITEMS.map((item) => {
                  const isActive = activeTab === item.tab && screen === "feed";
                  const isCreate = item.tab === "rooms";
                  return (
                    <motion.button
                      key={item.tab}
                      whileTap={{ scale: 0.88 }}
                      onClick={() => handleNavTab(item.tab)}
                      style={{
                        flex: 1,
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: 2,
                        height: 52,
                        borderRadius: 20,
                        border: "none",
                        background: isActive
                          ? "linear-gradient(135deg, color-mix(in srgb, var(--primary) 10%, transparent), color-mix(in srgb, var(--accent) 8%, transparent), color-mix(in srgb, var(--primary) 14%, transparent))"
                          : isCreate
                          ? "linear-gradient(135deg, var(--primary), var(--accent))"
                          : "transparent",
                        boxShadow: isCreate ? "0 4px 14px color-mix(in srgb, var(--primary) 42%, transparent)" : "none",
                        cursor: "pointer",
                        transition: "all 0.2s",
                        padding: 0,
                      }}
                    >
                      {isCreate ? (
                        <span style={{ fontSize: 20 }}>{item.emoji}</span>
                      ) : (
                        <span style={{ fontSize: 18 }}>{item.emoji}</span>
                      )}
                      <span
                        style={{
                          fontSize: 9,
                          fontWeight: 700,
                          fontFamily: "Nunito",
                          color: isCreate ? "white" : isActive ? "var(--primary)" : "var(--muted-text)",
                          letterSpacing: 0.2,
                        }}
                      >
                        {item.label}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <AnimatePresence>
          {showThemes && (
            <ThemePicker
              value={themeId}
              onChange={(next) => { setThemeId(next); setShowThemes(false); }}
              onClose={() => setShowThemes(false)}
            />
          )}
          {showSettings && (
            <SettingsScreen
              theme={theme}
              onBack={() => setShowSettings(false)}
              onThemes={() => { setShowSettings(false); setShowThemes(true); }}
            />
          )}
          {showPlayer && <NowPlayingSheet onClose={() => setShowPlayer(false)} />}
          {showSearch && <SearchOverlay onClose={() => setShowSearch(false)} />}
          {showNotifications && <NotificationsPanel onClose={() => setShowNotifications(false)} />}
          {showActiveRooms && <ActiveRoomsSheet onClose={() => setShowActiveRooms(false)} onRoomSelect={() => { setShowActiveRooms(false); setScreen("room"); }} />}
        </AnimatePresence>
      </div>
    </div>
  );
}
