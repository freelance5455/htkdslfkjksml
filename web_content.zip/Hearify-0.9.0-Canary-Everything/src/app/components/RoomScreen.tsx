import { useState, useEffect } from "react";
import { useMusic } from "../MusicContext";
import { LOCAL_CATALOG } from "../musicCatalog";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, MessageCircle, SkipForward, SkipBack, Play, Pause, ListMusic, Share2, Plus } from "lucide-react";

const REACTIONS = ["❤️", "🔥", "🎶", "☁️", "✨", "💜"];

const listeners = [
  { name: "You", emoji: "🧡", x: 50, y: 50 },
  { name: "Maya", emoji: "🌸", x: 20, y: 30 },
  { name: "Jae", emoji: "⚡", x: 78, y: 25 },
  { name: "Sofia", emoji: "☁️", x: 15, y: 68 },
  { name: "Noah", emoji: "🎸", x: 82, y: 70 },
  { name: "Ava", emoji: "💛", x: 50, y: 18 },
];

const roomQueue = LOCAL_CATALOG.map((track, index) => ({ ...track, active: index === 0 }));

const suggestions = LOCAL_CATALOG.slice(4, 10).map((track, index) => ({
  ...track,
  from: ["Maya 🌸", "Noah 🎸", "Sofia ☁️", "Jae ⚡", "Ava 💛", "Noah 🎸"][index] || "Friend",
  likes: 3 + index * 2,
}));



interface FloatingReaction {
  id: number;
  emoji: string;
  x: number;
}

export function RoomScreen({ onBack }: { onBack: () => void }) {
  const { current, isPlaying: globalPlaying, currentTime: musicTime, duration: musicDuration, playTrack, togglePlay, next, previous, addToQueue } = useMusic();
  const activeTrack = current || LOCAL_CATALOG[0];
  const [isPlaying, setIsPlaying] = useState(true);
  const visualPlaying = current ? globalPlaying : isPlaying;
  const [progress, setProgress] = useState(42);
  const [reactions, setReactions] = useState<FloatingReaction[]>([]);
  const [showQueue, setShowQueue] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [likedSuggestions, setLikedSuggestions] = useState<Set<string>>(new Set());
  const [showAddSuggestion, setShowAddSuggestion] = useState(false);
  const [suggestedCount, setSuggestedCount] = useState(0);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setProgress((p) => (p >= 100 ? 0 : p + 0.2));
    }, 100);
    return () => clearInterval(interval);
  }, [isPlaying]);

  useEffect(() => {
    const interval = setInterval(() => {
      const autoEmojis = ["☁️", "🎶", "✨"];
      const emoji = autoEmojis[Math.floor(Math.random() * autoEmojis.length)];
      addReaction(emoji);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  function addReaction(emoji: string) {
    const id = Date.now() + Math.random();
    const x = 20 + Math.random() * 60;
    setReactions((prev) => [...prev, { id, emoji, x }]);
    setTimeout(() => setReactions((prev) => prev.filter((r) => r.id !== id)), 2800);
  }

  const roomDuration = current ? (musicDuration || activeTrack.duration || 1) : 208;
  const roomCurrentSeconds = current ? musicTime : (progress / 100) * roomDuration;
  const roomProgress = Math.min(100, Math.max(0, (roomCurrentSeconds / roomDuration) * 100));
  const formatTime = (seconds: number) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;

  return (
    <div className="flex flex-col h-full relative overflow-hidden" style={{ fontFamily: "Nunito" }}>
      {/* Floating reactions */}
      <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 50 }}>
        <AnimatePresence>
          {reactions.map((r) => (
            <motion.div
              key={r.id}
              initial={{ opacity: 1, y: 0, scale: 0.8 }}
              animate={{ opacity: 0, y: -220, scale: 1.2 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 2.5, ease: "easeOut" }}
              style={{
                position: "absolute",
                bottom: 120,
                left: `${r.x}%`,
                fontSize: 26,
              }}
            >
              {r.emoji}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-12 pb-3">
        <motion.button whileTap={{ scale: 0.9 }} onClick={onBack} className="flex items-center gap-1">
          <ChevronLeft size={22} color="var(--muted-text)" />
        </motion.button>
        <div className="text-center">
          <p style={{ fontSize: 11, color: "var(--muted-text)", fontWeight: 600 }}>☁️ ROAD TRIP VIBES</p>
          <p style={{ fontSize: 13, color: "var(--text)", fontWeight: 700 }}>8 listening now</p>
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          style={{
            width: 36,
            height: 36,
            borderRadius: 18,
            background: "var(--glass)",
            border: "1.5px solid color-mix(in srgb, var(--primary) 25%, transparent)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Share2 size={16} color="var(--muted-text)" />
        </motion.button>
      </div>

      {/* Album art with floating avatars */}
      <div className="relative flex items-center justify-center" style={{ height: 240 }}>
        {/* Listener avatars floating around */}
        {listeners.map((l, i) => (
          <motion.div
            key={l.name}
            style={{ position: "absolute", left: `${l.x}%`, top: `${l.y}%`, transform: "translate(-50%, -50%)" }}
            animate={{ y: [0, i % 2 === 0 ? -8 : 8, 0] }}
            transition={{ duration: 3 + i * 0.5, repeat: Infinity, ease: "easeInOut" }}
          >
            <div
              style={{
                width: l.name === "You" ? 52 : 38,
                height: l.name === "You" ? 52 : 38,
                borderRadius: "50%",
                background: "linear-gradient(135deg, #fde68a, #fbcfe8)",
                border: l.name === "You" ? "3px solid var(--primary)" : "2.5px solid white",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: l.name === "You" ? 22 : 17,
                boxShadow: "0 4px 14px rgba(0,0,0,0.12)",
              }}
            >
              {l.emoji}
            </div>
            {l.name !== "You" && (
              <p style={{ fontSize: 9, color: "var(--muted-text)", textAlign: "center", marginTop: 2, fontWeight: 600 }}>
                {l.name}
              </p>
            )}
          </motion.div>
        ))}

        {/* Central album art */}
        <motion.div
          animate={{ rotate: visualPlaying ? 360 : 0 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          style={{
            width: 100,
            height: 100,
            borderRadius: 50,
            background: "linear-gradient(135deg, #fde68a, #fed7aa, #fbcfe8)",
            boxShadow: "0 8px 32px color-mix(in srgb, var(--primary) 35%, transparent), 0 0 0 6px var(--glass)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: 16,
              background: "var(--glass-strong)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <div style={{ width: 10, height: 10, borderRadius: 5, background: "var(--primary)" }} />
          </div>
        </motion.div>
      </div>

      {/* Song info */}
      <div className="px-5 text-center mb-3">
        <h2 style={{ fontSize: 20, fontFamily: "Pacifico", color: "var(--text)" }}>{activeTrack.title}</h2>
        <p style={{ fontSize: 13, color: "var(--muted-text)", fontWeight: 600 }}>{activeTrack.artist}</p>
      </div>

      {/* Progress bar */}
      <div className="px-5 mb-4">
        <div className="w-full h-1.5 rounded-full" style={{ background: "color-mix(in srgb, var(--primary) 20%, transparent)" }}>
          <div
            className="h-full rounded-full transition-all"
            style={{
              width: `${roomProgress}%`,
              background: "linear-gradient(90deg, var(--primary), var(--accent))",
              boxShadow: "0 0 8px color-mix(in srgb, var(--primary) 50%, transparent)",
            }}
          />
        </div>
        <div className="flex justify-between mt-1">
          <span style={{ fontSize: 10, color: "var(--muted-text)" }}>{formatTime(roomCurrentSeconds)}</span>
          <span style={{ fontSize: 10, color: "var(--muted-text)" }}>{formatTime(roomDuration)}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-6 mb-4">
        <motion.button whileTap={{ scale: 0.85 }} onClick={previous}>
          <SkipBack size={22} color="var(--muted-text)" fill="var(--muted-text)" />
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => { if (current) togglePlay(); else void playTrack(activeTrack); setIsPlaying((v) => !v); }}
          style={{
            width: 60,
            height: 60,
            borderRadius: 30,
            background: "linear-gradient(135deg, var(--primary), var(--accent))",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "0 6px 20px color-mix(in srgb, var(--primary) 45%, transparent)",
          }}
        >
          {isPlaying ? <Pause size={24} color="white" fill="white" /> : <Play size={24} color="white" fill="white" />}
        </motion.button>
        <motion.button whileTap={{ scale: 0.85 }} onClick={() => void next()}>
          <SkipForward size={22} color="var(--muted-text)" fill="var(--muted-text)" />
        </motion.button>
      </div>

      {/* Reaction bar */}
      <div className="flex items-center justify-center gap-3 mb-4">
        {REACTIONS.map((r) => (
          <motion.button
            key={r}
            whileTap={{ scale: 1.4 }}
            onClick={() => addReaction(r)}
            style={{
              fontSize: 22,
              background: "var(--glass)",
              border: "1.5px solid color-mix(in srgb, var(--primary) 20%, transparent)",
              borderRadius: 14,
              width: 42,
              height: 38,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {r}
          </motion.button>
        ))}
      </div>

      {/* Bottom actions */}
      <div className="flex items-center gap-3 px-5 mb-2">
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => { setShowQueue(!showQueue); setShowChat(false); }}
          style={{
            flex: 1,
            height: 42,
            borderRadius: 14,
            background: showQueue ? "linear-gradient(135deg, var(--primary), var(--accent))" : "var(--glass)",
            border: "1.5px solid color-mix(in srgb, var(--primary) 20%, transparent)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
          }}
        >
          <ListMusic size={16} color={showQueue ? "white" : "var(--muted-text)"} />
          <span style={{ fontSize: 13, fontWeight: 700, color: showQueue ? "white" : "var(--muted-text)" }}>Queue</span>
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => { setShowChat(!showChat); setShowQueue(false); }}
          style={{
            flex: 1,
            height: 42,
            borderRadius: 14,
            background: showChat ? "linear-gradient(135deg, var(--primary), var(--accent))" : "var(--glass)",
            border: "1.5px solid color-mix(in srgb, var(--primary) 20%, transparent)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
          }}
        >
          <MessageCircle size={16} color={showChat ? "white" : "var(--muted-text)"} />
          <span style={{ fontSize: 13, fontWeight: 700, color: showChat ? "white" : "var(--muted-text)" }}>Suggest</span>
        </motion.button>
      </div>

      {/* Queue panel */}
      <AnimatePresence>
        {showQueue && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mx-5 overflow-hidden"
            style={{
              background: "var(--glass)",
              backdropFilter: "blur(12px)",
              borderRadius: 20,
              border: "1.5px solid color-mix(in srgb, var(--primary) 20%, transparent)",
            }}
          >
            <div className="p-4">
              <p style={{ fontSize: 11, color: "var(--muted-text)", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>
                Up Next
              </p>
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1" style={{ scrollbarWidth: "thin" }}>
              {roomQueue.map((track) => (
                <div key={track.title} className={`flex items-center gap-3 p-2 rounded-xl cursor-pointer ${track.active ? "bg-purple-50" : ""}`} onClick={() => { void playTrack(track); }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: track.thumbnail ? `url(${track.thumbnail}) center/cover` : "var(--glass-strong)", flexShrink: 0 }} />
                  <div className="flex-1">
                    <p style={{ fontSize: 13, fontWeight: track.active ? 800 : 600, color: track.active ? "var(--primary)" : "var(--text)" }}>
                      {track.title} {track.active && "♪"}
                    </p>
                    <p style={{ fontSize: 11, color: "var(--muted-text)" }}>{track.artist}</p>
                  </div>
                  <span style={{ fontSize: 11, color: "var(--muted)" }}>{track.durationText || "—"}</span>
                </div>
              ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Suggestions panel */}
      <AnimatePresence>
        {showChat && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mx-5 overflow-hidden"
            style={{
              background: "var(--glass)",
              backdropFilter: "blur(12px)",
              borderRadius: 20,
              border: "1.5px solid color-mix(in srgb, var(--primary) 20%, transparent)",
            }}
          >
            <div className="p-4">
              <div className="flex items-center justify-between">
                <p style={{ fontSize: 11, color: "var(--muted-text)", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>
                  Song Suggestions
                </p>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  style={{
                    width: 26,
                    height: 26,
                    borderRadius: 13,
                    background: "linear-gradient(135deg, var(--primary), var(--accent))",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  onClick={() => setShowAddSuggestion(true)}
                >
                  <Plus size={14} color="white" />
                </motion.button>
              </div>
              {suggestedCount > 0 && <div style={{ marginTop: 8, padding: "7px 9px", borderRadius: 10, background: "color-mix(in srgb,var(--success) 10%,transparent)", color: "var(--success)", fontSize: 9, fontWeight: 900, textAlign: "center" }}>✓ {suggestedCount} song{suggestedCount === 1 ? "" : "s"} suggested by you</div>}
              <div className="space-y-3 max-h-40 overflow-y-auto pr-1" style={{ scrollbarWidth: "thin" }}>
              {suggestions.map((s) => (
                <div key={s.title} className="flex items-center gap-3">
                  <div
                    style={{
                      width: 38,
                      height: 38,
                      borderRadius: 10,
                      background: s.color,
                      flexShrink: 0,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 16,
                    }}
                  >
                    🎵
                  </div>
                  <div className="flex-1">
                    <p style={{ fontSize: 13, fontWeight: 700, color: "var(--text)" }}>{s.title}</p>
                    <p style={{ fontSize: 11, color: "var(--muted-text)" }}>
                      {s.artist} · by {s.from}
                    </p>
                  </div>
                  <motion.button
                    whileTap={{ scale: 1.2 }}
                    onClick={() => setLikedSuggestions((prev) => {
                      const next = new Set(prev);
                      if (next.has(s.title)) next.delete(s.title);
                      else next.add(s.title);
                      return next;
                    })}
                    className="flex items-center gap-1"
                  >
                    <span style={{ fontSize: 14 }}>{likedSuggestions.has(s.title) ? "❤️" : "🤍"}</span>
                    <span style={{ fontSize: 11, color: "var(--primary)", fontWeight: 700 }}>
                      {s.likes + (likedSuggestions.has(s.title) ? 1 : 0)}
                    </span>
                  </motion.button>
                </div>
              ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAddSuggestion && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[70] flex items-end" style={{ background: "rgba(12,8,25,.34)", backdropFilter: "blur(4px)" }}>
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} className="w-full p-5 rounded-t-[28px]" style={{ background: "var(--glass-strong)", backdropFilter: "blur(25px)", borderTop: "1px solid var(--border)" }}>
              <div className="flex items-center justify-between mb-4"><div><p style={{ fontSize: 10, fontWeight: 900, color: "var(--muted-text)", textTransform: "uppercase" }}>Prototype picker</p><h3 style={{ fontSize: 18, fontWeight: 900, color: "var(--text)" }}>Suggest a song</h3></div><button onClick={() => setShowAddSuggestion(false)} style={{ width: 34, height: 34, borderRadius: 17, background: "var(--glass)", border: "1px solid var(--border)", color: "var(--text)" }}>×</button></div>
              <div className="grid grid-cols-2 gap-2">
                {suggestions.slice(0,4).map((s) => <motion.button whileTap={{ scale: .97 }} key={s.title} onClick={() => { addToQueue(s); setSuggestedCount(v => v + 1); setShowAddSuggestion(false); }} className="text-left" style={{ padding: 12, borderRadius: 16, background: "var(--glass)", border: "1px solid var(--border)" }}><p style={{ fontSize: 11, fontWeight: 900, color: "var(--text)" }}>{s.title}</p><p style={{ fontSize: 9, color: "var(--muted-text)", marginTop: 2 }}>{s.artist}</p></motion.button>)}
              </div>
              {suggestedCount > 0 && <p style={{ fontSize: 10, color: "var(--success)", marginTop: 10, textAlign: "center", fontWeight: 800 }}>✓ Added to the room suggestion queue</p>}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
