import { motion } from "motion/react";
import { ChevronDown, Users } from "lucide-react";

const rooms = [
  ["Road Trip Vibes", "Blinding Lights", "The Weeknd", "8", "🧡💛💜", "#bfdbfe"],
  ["Late Night Chill", "Lavender Haze", "Taylor Swift", "5", "💜💙🩷", "#ddd6fe"],
  ["Summer Memories", "Sunflower", "Post Malone", "12", "☀️🌸💛", "#fce7f3"],
  ["Indie Mornings", "Ribs", "Lorde", "3", "🌿☁️", "#ccfbf1"],
  ["Study Clouds", "Snooze", "SZA", "11", "📚☁️💙", "#bfdbfe"],
  ["Midnight Drive", "After Hours", "The Weeknd", "7", "🌙🖤💜", "#c4b5fd"],
];

export function ActiveRoomsSheet({ onClose, onRoomSelect }: { onClose: () => void; onRoomSelect: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[95]" style={{ background: "rgba(12,8,25,.34)", backdropFilter: "blur(5px)" }}>
      <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "spring", damping: 28, stiffness: 300 }} className="absolute right-0 top-0 bottom-0 w-[94%]" style={{ background: "color-mix(in srgb, var(--sky) 78%, var(--glass-strong))", backdropFilter: "blur(26px)", borderLeft: "1px solid var(--border)", boxShadow: "-20px 0 60px var(--shadow)" }}>
        <div className="flex items-center gap-3 px-5 pt-12 pb-4">
          <motion.button whileTap={{ scale: .88 }} onClick={onClose} style={{ width: 38, height: 38, borderRadius: 19, display: "grid", placeItems: "center", background: "var(--glass)", border: "1px solid var(--border)" }}><ChevronDown size={18} color="var(--muted-text)" /></motion.button>
          <div><p style={{ fontSize: 10, fontWeight: 900, color: "var(--muted-text)", textTransform: "uppercase" }}>Live right now</p><h2 style={{ fontSize: 20, fontWeight: 900, color: "var(--text)" }}>Active Rooms</h2></div>
        </div>
        <div className="px-5 pb-6 overflow-y-auto h-[calc(100%-90px)]" style={{ scrollbarWidth: "none" }}>
          <div className="space-y-2.5">
            {rooms.map((room, i) => (
              <motion.button key={room[0]} whileTap={{ scale: .98 }} onClick={onRoomSelect} className="w-full text-left" style={{ padding: 14, borderRadius: 20, background: "var(--glass)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-3"><div style={{ width: 50, height: 50, borderRadius: 15, background: room[5], display: "grid", placeItems: "center", fontSize: 22 }}>{i % 2 ? "🎵" : "☁️"}</div><div className="flex-1 min-w-0"><p style={{ fontSize: 13, fontWeight: 900, color: "var(--text)" }}>{room[0]}</p><p style={{ fontSize: 10, color: "var(--muted-text)", marginTop: 2 }}>{room[1]} · {room[2]}</p><div className="flex items-center gap-2 mt-1.5"><span style={{ fontSize: 12 }}>{room[4]}</span><span className="flex items-center gap-1" style={{ fontSize: 9, color: "var(--muted-text)" }}><Users size={11} /> {room[3]} listening</span></div></div><span style={{ width: 8, height: 8, borderRadius: 4, background: "var(--success)", boxShadow: "0 0 7px var(--success)" }} /></div>
              </motion.button>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
