import { motion } from "motion/react";
import { Settings, Heart, Music, Cloud, ChevronRight } from "lucide-react";
import { useMusic } from "../MusicContext";
import { LOCAL_CATALOG } from "../musicCatalog";

const genres = ["Indie Pop", "Lo-fi", "R&B", "Dreamy", "Ambient"];

const playlists = [
  { name: "Late Night Feels", songs: 24, color: "from-violet-200/80 to-purple-200/80", emoji: "🌙" },
  { name: "Road Trip Mix", songs: 18, color: "from-amber-100/80 to-orange-200/80", emoji: "🚗" },
  { name: "Morning Clouds", songs: 31, color: "from-sky-100/80 to-blue-200/80", emoji: "☁️" },
];

const favoriteRooms = [
  { name: "Late Night Chill", members: 5, emoji: "🌙" },
  { name: "Indie Mornings", members: 3, emoji: "🌿" },
];



export function ProfileScreen({ onOpenThemes, onOpenSettings }: { onOpenThemes: () => void; onOpenSettings: () => void }) {
  const { playTrack } = useMusic();
  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ fontFamily: "Nunito" }}>
      <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        {/* Header */}
        <div className="relative pt-12 pb-6 px-5">
          <div className="flex items-center justify-between mb-6">
            <h1 style={{ fontSize: 22, fontFamily: "Pacifico", color: "var(--text)" }}>My Cloud</h1>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onOpenSettings}
              style={{
                width: 38,
                height: 38,
                borderRadius: 19,
                background: "var(--glass-strong)",
                border: "1.5px solid var(--border)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Settings size={17} color="var(--muted-text)" />
            </motion.button>
          </div>

          {/* Profile cloud card */}
          <motion.div
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            style={{
              background: "var(--glass)",
              backdropFilter: "blur(16px)",
              borderRadius: 28,
              border: "1.5px solid var(--glass-strong)",
              boxShadow: "0 12px 40px color-mix(in srgb, var(--primary) 20%, transparent), 0 4px 16px rgba(0,0,0,0.06)",
              padding: 20,
            }}
          >
            <div className="flex items-start gap-4">
              <div className="relative">
                <div
                  style={{
                    width: 72,
                    height: 72,
                    borderRadius: 36,
                    background: "linear-gradient(135deg, #fde68a, #fbcfe8, #ddd6fe)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 34,
                    border: "3px solid white",
                    boxShadow: "0 4px 16px color-mix(in srgb, var(--primary) 30%, transparent)",
                  }}
                >
                  🌸
                </div>
                <div
                  style={{
                    position: "absolute",
                    bottom: 2,
                    right: 2,
                    width: 16,
                    height: 16,
                    borderRadius: 8,
                    background: "var(--success)",
                    border: "2px solid white",
                  }}
                />
              </div>
              <div className="flex-1">
                <p style={{ fontSize: 18, fontWeight: 800, color: "var(--text)" }}>Aria Chen</p>
                <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 500 }}>@aria.dreaming</p>
                <p style={{ fontSize: 12, color: "#7c6a9e", marginTop: 4, lineHeight: 1.4 }}>
                  Lost in music, floating on clouds ☁️🎵 sharing vibes with the world
                </p>
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {genres.map((g) => (
                    <span
                      key={g}
                      style={{
                        fontSize: 10,
                        fontWeight: 700,
                        color: "var(--primary)",
                        background: "color-mix(in srgb, var(--primary) 12%, transparent)",
                        borderRadius: 10,
                        padding: "3px 8px",
                      }}
                    >
                      {g}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="px-5 space-y-5 pb-4">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { icon: "☁️", label: "Rooms Joined", value: "48" },
              { icon: "🎵", label: "Songs Shared", value: "213" },
              { icon: "❤️", label: "Likes Given", value: "1.2k" },
            ].map((stat) => (
              <div
                key={stat.label}
                style={{
                  background: "var(--glass)",
                  backdropFilter: "blur(10px)",
                  borderRadius: 18,
                  border: "1.5px solid var(--glass-strong)",
                  boxShadow: "0 4px 16px rgba(0,0,0,0.05)",
                  padding: "14px 8px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: 22, marginBottom: 4 }}>{stat.icon}</div>
                <p style={{ fontSize: 16, fontWeight: 800, color: "var(--text)" }}>{stat.value}</p>
                <p style={{ fontSize: 9, color: "var(--muted-text)", fontWeight: 600, lineHeight: 1.2 }}>{stat.label}</p>
              </div>
            ))}
          </div>

          {/* Playlists */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Music size={14} color="var(--primary)" />
                <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>
                  My Playlists
                </p>
              </div>
              <button style={{ fontSize: 12, color: "var(--primary)", fontWeight: 700 }}>+ New</button>
            </div>
            <div className="space-y-2.5">
              {playlists.map((p) => (
                <motion.div
                  key={p.name}
                  whileTap={{ scale: 0.97 }}
                  className={`flex items-center gap-3 p-3.5 bg-gradient-to-r ${p.color} backdrop-blur-xl border border-white/60`}
                  style={{ borderRadius: 18, boxShadow: "0 4px 14px rgba(0,0,0,0.06)", cursor: "pointer" }}
                >
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 12,
                      background: "var(--glass)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 20,
                    }}
                  >
                    {p.emoji}
                  </div>
                  <div className="flex-1">
                    <p style={{ fontSize: 13, fontWeight: 800, color: "var(--text)" }}>{p.name}</p>
                    <p style={{ fontSize: 11, color: "var(--muted-text)" }}>{p.songs} songs</p>
                  </div>
                  <ChevronRight size={16} color="var(--muted-text)" />
                </motion.div>
              ))}
            </div>
          </div>

          {/* Favorite Rooms */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Cloud size={14} color="var(--accent)" />
              <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>
                Saved Rooms
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {favoriteRooms.map((r) => (
                <motion.div
                  key={r.name}
                  whileTap={{ scale: 0.96 }}
                  style={{
                    background: "var(--glass)",
                    backdropFilter: "blur(10px)",
                    borderRadius: 16,
                    border: "1.5px solid var(--glass-strong)",
                    boxShadow: "0 4px 14px rgba(0,0,0,0.05)",
                    padding: 14,
                    cursor: "pointer",
                  }}
                >
                  <div style={{ fontSize: 24, marginBottom: 6 }}>{r.emoji}</div>
                  <p style={{ fontSize: 12, fontWeight: 800, color: "var(--text)" }}>{r.name}</p>
                  <p style={{ fontSize: 10, color: "var(--muted-text)" }}>{r.members} friends</p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Saved Songs */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Heart size={14} color="var(--pink)" />
              <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>
                Liked Songs
              </p>
            </div>
            <div
              style={{
                background: "var(--glass)",
                backdropFilter: "blur(10px)",
                borderRadius: 20,
                border: "1.5px solid var(--glass-strong)",
                boxShadow: "0 4px 16px rgba(0,0,0,0.05)",
                overflow: "hidden",
              }}
            >
              {LOCAL_CATALOG.slice(0, 5).map((s, i) => (
                <motion.button
                  key={s.videoId}
                  whileTap={{ scale: 0.985 }}
                  onClick={() => void playTrack(s)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left"
                  style={{ borderBottom: i < 4 ? "1px solid rgba(192,132,252,0.1)" : "none" }}
                >
                  <div style={{ width: 36, height: 36, borderRadius: 10, overflow: "hidden", background: "var(--glass-strong)", flexShrink: 0 }}>
                    {s.thumbnail && <img src={s.thumbnail} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p style={{ fontSize: 13, fontWeight: 700, color: "var(--text)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.title}</p>
                    <p style={{ fontSize: 11, color: "var(--muted-text)" }}>{s.artist}</p>
                  </div>
                  <span style={{ fontSize: 16 }}>❤️</span>
                </motion.button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
