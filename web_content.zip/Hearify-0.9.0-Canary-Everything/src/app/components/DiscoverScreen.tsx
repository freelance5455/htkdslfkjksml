import { motion } from "motion/react";
import { useMusic } from "../MusicContext";
import { MusicTrack } from "../musicApi";
import { Search, TrendingUp, Users, Heart, Zap } from "lucide-react";
import { useState, useEffect } from "react";

const categories = [
  { label: "All", active: true },
  { label: "Pop", active: false },
  { label: "Indie", active: false },
  { label: "Lo-fi", active: false },
  { label: "Hip-Hop", active: false },
];

const trending = [
  { rank: 1, name: "Espresso", artist: "Sabrina Carpenter", listeners: "2.4k", color: "#fde68a" },
  { rank: 2, name: "Birds of a Feather", artist: "Billie Eilish", listeners: "1.8k", color: "#ddd6fe" },
  { rank: 3, name: "Please Please Please", artist: "Sabrina Carpenter", listeners: "1.5k", color: "#fce7f3" },
  { rank: 4, name: "Not Like Us", artist: "Kendrick Lamar", listeners: "1.2k", color: "#ccfbf1" },
  { rank: 5, name: "A Bar Song", artist: "Shaboozey", listeners: "980", color: "#fed7aa" },
];

const communities = [
  { name: "Indie Dreamers", members: "12.4k", active: 84, emoji: "🌿", color: "from-emerald-100/80 to-teal-200/80" },
  { name: "Pop Universe", members: "31.2k", active: 256, emoji: "⭐", color: "from-yellow-100/80 to-pink-200/80" },
  { name: "Night Owls", members: "8.9k", active: 47, emoji: "🌙", color: "from-violet-200/80 to-indigo-200/80" },
  { name: "Beach Vibes", members: "15.6k", active: 113, emoji: "🏖️", color: "from-sky-100/80 to-blue-200/80" },
];

const friendActivity = [
  { name: "Ava", action: "joined Road Trip Vibes", time: "2m ago", emoji: "🧡" },
  { name: "Leo", action: "suggested Cruel Summer", time: "5m ago", emoji: "💛" },
  { name: "Zara", action: "created Midnight Blues", time: "12m ago", emoji: "💜" },
  { name: "Noah", action: "liked your song pick", time: "18m ago", emoji: "💙" },
];

export function DiscoverScreen({ onRoomSelect }: { onRoomSelect: () => void }) {
  const { searchTracks, playTrack, addToQueue } = useMusic();
  const [activeCategory, setActiveCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [trending, setTrending] = useState<MusicTrack[]>([]);
  const [loadingTrending, setLoadingTrending] = useState(true);
  const [searchError, setSearchError] = useState("");

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(() => {
      (async () => {
        setLoadingTrending(true);
        setSearchError("");
        try {
          const tracks = await searchTracks(query.trim() || "popular songs", 20);
          if (!cancelled) setTrending(tracks);
        } catch (err) {
          if (!cancelled) { setTrending([]); setSearchError(err instanceof Error ? err.message : "Live music search is unavailable."); }
        } finally {
          if (!cancelled) setLoadingTrending(false);
        }
      })();
    }, query.trim() ? 220 : 0);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [searchTracks, query]);

  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ fontFamily: "Nunito" }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-4">
        <h1 style={{ fontSize: 22, fontFamily: "Pacifico", color: "var(--text)", marginBottom: 12 }}>Discover</h1>

        {/* Search bar - cloud shaped */}
        <div
          className="flex items-center gap-3 px-4"
          style={{
            height: 48,
            background: "var(--glass)",
            backdropFilter: "blur(12px)",
            borderRadius: 28,
            border: "1.5px solid color-mix(in srgb, var(--primary) 25%, transparent)",
            boxShadow: "0 4px 16px rgba(0,0,0,0.06)",
          }}
        >
          <Search size={18} color="var(--primary)" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search rooms, songs, friends..."
            style={{
              flex: 1,
              background: "transparent",
              border: "none",
              outline: "none",
              fontSize: 14,
              color: "var(--text)",
              fontFamily: "Nunito",
            }}
          />
        </div>

        {/* Category pills */}
        <div className="flex gap-2 mt-3 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {categories.map((cat) => (
            <button
              key={cat.label}
              onClick={() => setActiveCategory(cat.label)}
              style={{
                whiteSpace: "nowrap",
                padding: "6px 16px",
                borderRadius: 20,
                fontSize: 13,
                fontWeight: 700,
                fontFamily: "Nunito",
                border: "none",
                background: activeCategory === cat.label
                  ? "linear-gradient(135deg, var(--primary), var(--accent))"
                  : "var(--glass)",
                color: activeCategory === cat.label ? "#fff" : "var(--muted-text)",
                boxShadow: activeCategory === cat.label ? "0 4px 12px color-mix(in srgb, var(--primary) 35%, transparent)" : "none",
                transition: "all 0.2s",
              }}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-4 space-y-5" style={{ scrollbarWidth: "none" }}>
        {/* Trending Rooms */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp size={15} color="var(--pink)" />
            <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>
              {query.trim() ? "Search Results" : "Trending Songs"}
            </p>
          </div>
          <div
            className="backdrop-blur-xl border border-white/60 p-4 space-y-3"
            style={{ borderRadius: 22, background: "var(--glass)", boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}
          >
            {(loadingTrending ? [] : trending).map((track, i) => (
              <motion.div key={track.videoId} whileTap={{scale:.985}} onClick={()=>void playTrack(track)} className="flex items-center gap-3 cursor-pointer">
                <span style={{ fontSize: 13, fontWeight: 800, color: "var(--primary)", minWidth: 20 }}>{String(i + 1).padStart(2, "0")}</span>
                <div
                  style={{ width: 38, height: 38, borderRadius: 10, background: "var(--glass-strong)", flexShrink: 0 }}
                  className="flex items-center justify-center"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="rgba(80,60,120,0.4)">
                    <circle cx="12" cy="12" r="9" fill="rgba(80,60,120,0.1)" stroke="rgba(80,60,120,0.3)" strokeWidth="1.5" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p style={{ fontSize: 13, fontWeight: 700, color: "var(--text)" }}>{track.title}</p>
                  <p style={{ fontSize: 11, color: "var(--muted-text)" }}>{track.artist}</p>
                </div>
                <div className="flex items-center gap-1">
                  <div style={{ width: 6, height: 6, borderRadius: 3, background: "var(--success)" }} />
                  <div className="flex items-center gap-1"><button onClick={(e)=>{e.stopPropagation(); addToQueue(track)}} aria-label="Add to queue" style={{border:"none",background:"transparent",color:"var(--primary)",fontSize:11}}>＋</button><button onClick={(e)=>{e.stopPropagation(); void playTrack(track)}} aria-label="Play song" style={{border:"none",background:"transparent",color:"var(--primary)",fontSize:11}}>▶</button></div>
                </div>
              </motion.div>
            ))}
            {loadingTrending && <div className="space-y-2">{Array.from({length:6}).map((_,i)=><div key={i} style={{height:42,borderRadius:12,background:"color-mix(in srgb,var(--glass-strong) 58%,transparent)",opacity:1-i*0.08}}/> )}</div>}
            {!loadingTrending && searchError && <div style={{padding:18,textAlign:"center",fontSize:10,color:"var(--pink)"}}>Live catalog unavailable. {searchError}</div>}
            {!loadingTrending && !searchError && !trending.length && <div style={{padding:18,textAlign:"center",fontSize:10,color:"var(--muted-text)"}}>No songs found.</div>}
          </div>
        </div>

        {/* Active Communities */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Zap size={15} color="#f59e0b" />
            <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>
              Most Active Communities
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {communities.map((c) => (
              <motion.div
                key={c.name}
                whileTap={{ scale: 0.96 }}
                onClick={onRoomSelect}
                className={`bg-gradient-to-br ${c.color} backdrop-blur-xl border border-white/60 p-4 cursor-pointer`}
                style={{ borderRadius: 20, boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
              >
                <div style={{ fontSize: 26, marginBottom: 8 }}>{c.emoji}</div>
                <p style={{ fontSize: 13, fontWeight: 800, color: "var(--text)", lineHeight: 1.2 }}>{c.name}</p>
                <p style={{ fontSize: 11, color: "var(--muted-text)", marginTop: 2 }}>{c.members} members</p>
                <div className="flex items-center gap-1 mt-2">
                  <div style={{ width: 6, height: 6, borderRadius: 3, background: "var(--success)" }} />
                  <span style={{ fontSize: 10, color: "var(--success)", fontWeight: 700 }}>{c.active} active now</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Friend Activity */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Heart size={15} color="var(--pink)" />
            <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>
              Friend Activity
            </p>
          </div>
          <div
            className="backdrop-blur-xl border border-white/60 p-4 space-y-3"
            style={{ borderRadius: 22, background: "var(--glass)", boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}
          >
            {friendActivity.map((item) => (
              <div key={item.name} className="flex items-center gap-3">
                <div
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 17,
                    background: "linear-gradient(135deg, #fde68a, #fbcfe8)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 16,
                    flexShrink: 0,
                  }}
                >
                  {item.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <p style={{ fontSize: 12, color: "var(--text)" }}>
                    <span style={{ fontWeight: 800 }}>{item.name}</span>{" "}
                    <span style={{ color: "var(--muted-text)" }}>{item.action}</span>
                  </p>
                </div>
                <span style={{ fontSize: 10, color: "var(--muted)", whiteSpace: "nowrap" }}>{item.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
