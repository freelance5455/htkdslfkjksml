import { motion } from "motion/react";
import { Theme } from "../themes";

const clouds = [
  { id: 1, x: "-10%", y: "8%", scale: 1.4, opacity: 0.34, duration: 22 },
  { id: 2, x: "60%", y: "3%", scale: 1.0, opacity: 0.27, duration: 28 },
  { id: 3, x: "30%", y: "65%", scale: 1.6, opacity: 0.2, duration: 35 },
  { id: 4, x: "-5%", y: "55%", scale: 0.9, opacity: 0.16, duration: 20 },
  { id: 5, x: "70%", y: "50%", scale: 1.1, opacity: 0.22, duration: 30 },
];

const notes = [
  { id: 1, x: "15%", y: "20%", size: 18, delay: 0 },
  { id: 2, x: "80%", y: "15%", size: 14, delay: 1.5 },
  { id: 3, x: "55%", y: "40%", size: 20, delay: 3 },
  { id: 4, x: "25%", y: "75%", size: 12, delay: 2 },
];

const stars = Array.from({ length: 10 }, (_, i) => ({
  id: i,
  x: `${(i * 37) % 100}%`,
  y: `${(i * 61) % 92}%`,
  size: 2 + (i % 3),
  delay: (i % 7) * 0.4,
}));

const raindrops = Array.from({ length: 16 }, (_, i) => ({
  id: i,
  x: `${(i * 29) % 100}%`,
  delay: (i % 9) * 0.33,
  duration: 0.8 + (i % 5) * 0.13,
}));

const petals = Array.from({ length: 8 }, (_, i) => ({
  id: i,
  x: `${(i * 43) % 100}%`,
  delay: (i % 8) * 0.8,
  duration: 7 + (i % 5),
  drift: (i % 2 ? 1 : -1) * (12 + (i % 4) * 6),
}));

const ducks = Array.from({ length: 3 }, (_, i) => ({
  id: i,
  x: `${-12 + i * 26}%`,
  y: `${18 + (i % 3) * 23}%`,
  delay: i * 1.25,
  duration: 13 + i,
}));

function CloudShape({ opacity }: { opacity: number }) {
  return (
    <svg viewBox="0 0 200 120" fill="white" style={{ opacity }}>
      <ellipse cx="100" cy="80" rx="90" ry="40" />
      <ellipse cx="70" cy="65" rx="45" ry="38" />
      <ellipse cx="130" cy="60" rx="42" ry="36" />
      <ellipse cx="100" cy="50" rx="38" ry="32" />
    </svg>
  );
}

export function CloudBackground({ theme }: { theme: Theme }) {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ zIndex: 0 }}>
      <div className="absolute inset-0 transition-all duration-700" style={{ background: "var(--sky)" }} />

      {(theme.effects === "clouds" || theme.effects === "bubbles" || theme.effects === "ducks") && clouds.map((cloud) => (
        <motion.div
          key={cloud.id}
          className="absolute w-64"
          style={{ left: cloud.x, top: cloud.y, scale: cloud.scale }}
          animate={{ y: [0, -18, 0], x: [0, 8, 0] }}
          transition={{ duration: cloud.duration, repeat: Infinity, ease: "easeInOut" }}
        >
          <CloudShape opacity={theme.id === "ducks" ? cloud.opacity * 0.75 : cloud.opacity} />
        </motion.div>
      ))}

      {theme.effects === "stars" && stars.map((star) => (
        <motion.div
          key={star.id}
          className="absolute rounded-full"
          style={{ left: star.x, top: star.y, width: star.size, height: star.size, background: "#fff", boxShadow: "0 0 9px rgba(255,255,255,.75)" }}
          animate={{ opacity: [0.15, 0.95, 0.15], scale: [0.8, 1.15, 0.8] }}
          transition={{ duration: 2.6 + star.delay, repeat: Infinity, delay: star.delay, ease: "easeInOut" }}
        />
      ))}

      {theme.effects === "rain" && raindrops.map((drop) => (
        <motion.div
          key={drop.id}
          className="absolute top-[-8%] w-px rounded-full"
          style={{ left: drop.x, height: "6vh", background: "linear-gradient(to bottom, transparent, rgba(180,220,255,.52))" }}
          animate={{ y: [0, "118vh"] }}
          transition={{ duration: drop.duration, repeat: Infinity, delay: drop.delay, ease: "linear" }}
        />
      ))}

      {theme.effects === "rainbow" && (
        <motion.div
          className="absolute left-1/2 -translate-x-1/2"
          style={{ top: "18%", width: "135%", height: 180, borderRadius: "50%", border: "14px solid rgba(255,120,170,.16)", boxShadow: "0 0 0 14px rgba(255,213,90,.12), 0 0 0 28px rgba(92,224,170,.1), 0 0 0 42px rgba(92,180,255,.08)" }}
          animate={{ y: [0, -8, 0], rotate: [-1, 1, -1] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
      )}

      {theme.effects === "petals" && petals.map((petal) => (
        <motion.div
          key={petal.id}
          className="absolute top-[-10%] rounded-full"
          style={{ left: petal.x, width: 8, height: 12, background: "rgba(255,182,210,.68)", borderRadius: "70% 30% 70% 30%", rotate: 25 }}
          animate={{ y: [0, "120vh"], x: [0, petal.drift, 0], rotate: [25, 190, 350] }}
          transition={{ duration: petal.duration, repeat: Infinity, delay: petal.delay, ease: "easeInOut" }}
        />
      ))}

      {theme.effects === "ducks" && ducks.map((duck) => (
        <motion.div
          key={duck.id}
          className="absolute text-3xl"
          style={{ left: duck.x, top: duck.y }}
          animate={{ x: [0, "125vw"], y: [0, -8, 6, 0] }}
          transition={{ duration: duck.duration, repeat: Infinity, delay: duck.delay, ease: "linear" }}
        >
          🦆
        </motion.div>
      ))}

      {theme.effects === "bubbles" && Array.from({ length: 8 }, (_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full border"
          style={{ left: `${(i * 47) % 100}%`, bottom: "-5%", width: 8 + (i % 4) * 5, height: 8 + (i % 4) * 5, borderColor: "rgba(255,255,255,.5)" }}
          animate={{ y: [0, -900], x: [0, (i % 2 ? 22 : -22), 0], opacity: [0, 0.75, 0] }}
          transition={{ duration: 7 + (i % 4), repeat: Infinity, delay: i * 0.55, ease: "easeInOut" }}
        />
      ))}

      {notes.map((note) => (
        <motion.div
          key={note.id}
          className="absolute"
          style={{ left: note.x, top: note.y, willChange: "transform, opacity" }}
          animate={{ y: [0, -30, 0], opacity: [0.08, 0.3, 0.08] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: note.delay }}
        >
          <span style={{ color: "var(--note)", fontSize: note.size, filter: "drop-shadow(0 2px 4px rgba(0,0,0,.06))" }}>♪</span>
        </motion.div>
      ))}
    </div>
  );
}
