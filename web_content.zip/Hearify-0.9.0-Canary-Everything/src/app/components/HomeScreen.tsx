import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { Bell, Search } from "lucide-react";
import { useMusic } from "../MusicContext";
import { LOCAL_CATALOG } from "../musicCatalog";

const rooms = [
  {
    id: 1,
    name: "Road Trip Vibes",
    listeners: 8,
    song: "Blinding Lights",
    artist: "The Weeknd",
    avatars: ["🧡", "💛", "💜", "💚"],
    color: "from-amber-200/80 via-orange-100/80 to-pink-200/80",
    accent: "#f59e0b",
    featured: true,
    albumColor: "#fde68a",
  },
  {
    id: 2,
    name: "Late Night Chill",
    listeners: 5,
    song: "Lavender Haze",
    artist: "Taylor Swift",
    avatars: ["💜", "💙", "🩷"],
    color: "from-violet-200/80 via-purple-100/80 to-indigo-200/80",
    accent: "#8b5cf6",
    featured: false,
    albumColor: "#ddd6fe",
  },
  {
    id: 3,
    name: "Summer Memories",
    listeners: 12,
    song: "Sunflower",
    artist: "Post Malone",
    avatars: ["☀️", "🌸", "💛", "🩵"],
    color: "from-yellow-100/80 via-pink-100/80 to-rose-200/80",
    accent: "#ec4899",
    featured: false,
    albumColor: "#fce7f3",
  },
  {
    id: 4,
    name: "Indie Mornings",
    listeners: 3,
    song: "Ribs",
    artist: "Lorde",
    avatars: ["🌿", "☁️"],
    color: "from-emerald-100/80 via-teal-100/80 to-sky-200/80",
    accent: "#14b8a6",
    featured: false,
    albumColor: "#ccfbf1",
  },
];

function AlbumArt({ color, size = 52 }: { color: string; size?: number }) {
  return (
    <div
      style={{ width: size, height: size, background: color, borderRadius: size * 0.22 }}
      className="flex items-center justify-center shrink-0 shadow-sm"
    >
      <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="rgba(80,60,120,0.5)">
        <circle cx="12" cy="12" r="10" fill="rgba(80,60,120,0.08)" stroke="rgba(80,60,120,0.3)" strokeWidth="1.5" />
        <circle cx="12" cy="12" r="3" fill="rgba(80,60,120,0.35)" />
      </svg>
    </div>
  );
}

function CloudCard({
  room,
  featured,
  onClick,
}: {
  room: (typeof rooms)[0];
  featured?: boolean;
  onClick: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={`relative cursor-pointer select-none ${featured ? "mb-2" : ""}`}
      animate={featured ? { y: [0, -5, 0] } : undefined}
      transition={featured ? { duration: 6, repeat: Infinity, ease: "easeInOut" } : undefined}
    >
      <div
        className={`bg-gradient-to-br ${room.color} backdrop-blur-xl border border-white/60 shadow-lg`}
        style={{
          borderRadius: featured ? 28 : 22,
          padding: featured ? "20px 20px 18px" : "14px 16px",
          boxShadow: `0 8px 32px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04)`,
        }}
      >
        <div className="flex items-start gap-3">
          <AlbumArt color={room.albumColor} size={featured ? 64 : 52} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 mb-0.5">
              <span style={{ fontSize: 11, color: room.accent, fontFamily: "Nunito", fontWeight: 700 }}>
                ☁️ {room.name}
              </span>
            </div>
            <p style={{ fontSize: featured ? 15 : 13, fontFamily: "Nunito", fontWeight: 700, color: "var(--text)", lineHeight: 1.3 }}>
              {room.song}
            </p>
            <p style={{ fontSize: 11, fontFamily: "Nunito", color: "var(--muted-text)", fontWeight: 500 }}>{room.artist}</p>
            <div className="flex items-center gap-1.5 mt-2">
              <div className="flex -space-x-1">
                {room.avatars.map((a, i) => (
                  <div
                    key={i}
                    style={{
                      width: 22,
                      height: 22,
                      borderRadius: 11,
                      background: "white",
                      border: "1.5px solid white",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 12,
                    }}
                  >
                    {a}
                  </div>
                ))}
              </div>
              <span style={{ fontSize: 11, color: "var(--muted-text)", fontFamily: "Nunito", fontWeight: 600 }}>
                {room.listeners} listening
              </span>
            </div>
          </div>
          <div
            style={{
              width: 8,
              height: 8,
              borderRadius: 4,
              background: "var(--success)",
              marginTop: 4,
              boxShadow: "0 0 6px var(--success)",
            }}
          />
        </div>
        {featured && (
          <div className="mt-3 pt-3" style={{ borderTop: "1px solid rgba(255,255,255,0.5)" }}>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.5)" }}>
                <div className="h-full rounded-full" style={{ width: "42%", background: room.accent }} />
              </div>
              <span style={{ fontSize: 10, color: "var(--muted-text)", fontFamily: "Nunito" }}>2:14 / 3:28</span>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function formatTime(seconds: number) {
  if (!Number.isFinite(seconds) || seconds <= 0) return "0:00";
  const total = Math.floor(seconds);
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}

export function HomeScreen({ onRoomSelect, onSearch, onNotifications, onOpenPlayer, onSeeAllRooms }: { onRoomSelect: () => void; onSearch: () => void; onNotifications: () => void; onOpenPlayer: () => void; onSeeAllRooms: () => void }) {
  const { current, isPlaying, loading, currentTime, duration, seek, togglePlay, playTrack, addToQueue, searchTracks } = useMusic();
  const fallbackTrack = LOCAL_CATALOG[0];
  const [discoveryTrack, setDiscoveryTrack] = useState<typeof fallbackTrack>(fallbackTrack);

  useEffect(() => {
    let cancelled = false;
    void searchTracks("popular songs", 6).then((tracks) => {
      if (!cancelled && tracks[0]) setDiscoveryTrack(tracks[0] as typeof fallbackTrack);
    }).catch(() => {
      // Keep the original home fallback if the live bridge is sleeping/unavailable.
    });
    return () => { cancelled = true; };
  }, [searchTracks]);

  const featuredTrack = current || discoveryTrack || fallbackTrack;
  const currentPercent = duration > 0 ? Math.min(100, Math.max(0, (currentTime / duration) * 100)) : 0;
  const currentTitle = featuredTrack.title;
  const currentArtist = featuredTrack.artist;
  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ fontFamily: "Nunito" }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-4 flex items-center justify-between">
        <div>
          <p style={{ fontSize: 13, color: "var(--muted-text)", fontWeight: 600 }}>Good evening ☁️</p>
          <h1 style={{ fontSize: 22, fontFamily: "Pacifico", color: "var(--text)", lineHeight: 1.2 }}>
            Cloud Feed
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onSearch}
            className="flex items-center justify-center"
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              background: "var(--glass)",
              border: "1.5px solid color-mix(in srgb, var(--primary) 25%, transparent)",
            }}
          >
            <Search size={18} color="var(--muted-text)" />
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onNotifications}
            className="relative flex items-center justify-center"
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              background: "var(--glass)",
              border: "1.5px solid color-mix(in srgb, var(--primary) 25%, transparent)",
            }}
          >
            <Bell size={18} color="var(--muted-text)" />
            <div
              className="absolute top-1 right-1"
              style={{ width: 8, height: 8, borderRadius: 4, background: "var(--pink)", border: "1.5px solid white" }}
            />
          </motion.button>
        </div>
      </div>

      {/* Active rooms section */}
      <div className="px-5 mb-2">
        <div className="flex items-center justify-between">
          <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>
            Active Rooms
          </p>
          <motion.button whileTap={{ scale: .94 }} onClick={onSeeAllRooms} style={{ fontSize: 12, color: "var(--primary)", fontWeight: 700, background: "none", border: "none" }}>See all</motion.button>
        </div>
      </div>

      {/* Active rooms carousel */}
      <div className="overflow-x-auto px-5 pb-3" style={{ scrollbarWidth: "none" }}>
        <div className="flex gap-3" style={{ width: "max-content" }}>
          {rooms.slice(0, 4).map((room, i) => (
            <div key={room.id} style={{ width: i === 0 ? 282 : 236 }}>
              <CloudCard room={room} featured={i === 0} onClick={onRoomSelect} />
            </div>
          ))}
        </div>
      </div>

      {/* Lower home content stays above the fold */}
      <div className="flex-1 overflow-y-auto px-5 pb-4 space-y-3" style={{ scrollbarWidth: "none" }}>
        <motion.div
          whileTap={{ scale: 0.98 }}
          onClick={() => { if (!current) void playTrack(featuredTrack); onOpenPlayer(); }}
          className="w-full text-left cursor-pointer"
          style={{
            background: "linear-gradient(135deg, color-mix(in srgb, var(--primary) 88%, white), color-mix(in srgb, var(--accent) 84%, white))",
            border: "1px solid rgba(255,255,255,.45)",
            borderRadius: 22,
            padding: 14,
            color: "white",
            boxShadow: "0 12px 28px color-mix(in srgb, var(--primary) 28%, transparent)",
          }}
        >
          <div className="flex items-center gap-3">
            <div style={{ width: 48, height: 48, borderRadius: 14, background: "rgba(255,255,255,.25)", display: "grid", placeItems: "center", fontSize: 22, overflow:"hidden" }}>{featuredTrack.thumbnail ? <img src={featuredTrack.thumbnail} alt="" loading="lazy" style={{width:"100%",height:"100%",objectFit:"cover"}}/> : "🎵"}</div>
            <div className="flex-1 min-w-0">
              <p style={{ fontSize: 10, fontWeight: 800, letterSpacing: .5, opacity: .82, textTransform: "uppercase" }}>Now playing</p>
              <p style={{ fontSize: 14, fontWeight: 900 }}>{currentTitle}</p>
              <p style={{ fontSize: 10, opacity: .82 }}>{currentArtist} · Hearify</p>
            </div>
            <motion.span whileTap={{scale:.85}} onClick={(e)=>{e.stopPropagation(); if (!current) void playTrack(featuredTrack); else togglePlay();}} style={{ width: 34, height: 34, borderRadius: 17, background: "rgba(255,255,255,.24)", display: "grid", placeItems: "center", fontSize: 14 }}>{loading ? "…" : isPlaying ? "Ⅱ" : "▶"}</motion.span>
          </div>
          <div style={{ marginTop: 10 }}>
            <div style={{ height: 4, borderRadius: 4, background: "rgba(255,255,255,.25)", overflow: "hidden" }}>
              <div style={{ width: `${duration > 0 ? Math.min(100, Math.max(0, (currentTime / duration) * 100)) : 0}%`, height: "100%", borderRadius: 4, background: "white", transition: "width .15s linear" }} />
            </div>
            <div className="flex items-center justify-between mt-1.5">
              <span style={{ fontSize: 9, opacity: .76 }}>{formatTime(currentTime)}</span>
              <span style={{ fontSize: 9, opacity: .76 }}>{formatTime(duration || featuredTrack.duration || 0)}</span>
            </div>
            <input
              aria-label="Song progress"
              type="range"
              min={0}
              max={Math.max(duration || featuredTrack.duration || 1, 1)}
              step={0.1}
              value={Math.min(currentTime, duration || featuredTrack.duration || 1)}
              onClick={(e) => e.stopPropagation()}
              onChange={(e) => seek(Number(e.target.value))}
              style={{ width: "100%", marginTop: 2, accentColor: "white", cursor: "pointer", opacity: .9 }}
            />
          </div>
        </motion.div>

        {/* Friends activity */}
        <div
          className="backdrop-blur-xl border border-white/60 p-4"
          style={{ borderRadius: 22, background: "rgba(255,255,255,0.55)", boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}
        >
          <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 10 }}>
            Friends Now Playing
          </p>
          {[
            { name: "Maya", song: "Cruel Summer", emoji: "🌸" },
            { name: "Jae", song: "Blinding Lights", emoji: "⚡" },
            { name: "Sofia", song: "As It Was", emoji: "☁️" },
          ].map((f) => (
            <div key={f.name} className="flex items-center gap-3 mb-2.5 last:mb-0">
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 17,
                  background: "linear-gradient(135deg, #fde68a, #fbcfe8)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 16,
                }}
              >
                {f.emoji}
              </div>
              <div className="flex-1">
                <p style={{ fontSize: 13, fontWeight: 700, color: "var(--text)" }}>{f.name}</p>
                <p style={{ fontSize: 11, color: "var(--muted-text)" }}>🎵 {f.song}</p>
              </div>
              <motion.button
                whileTap={{ scale: .92 }}
                onClick={onRoomSelect}
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  color: "var(--primary)",
                  background: "color-mix(in srgb, var(--primary) 12%, transparent)",
                  border: "none",
                  borderRadius: 10,
                  padding: "4px 10px",
                }}
              >
                Join
              </motion.button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
