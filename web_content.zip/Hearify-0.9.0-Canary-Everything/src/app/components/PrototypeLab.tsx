import { useEffect, useMemo, useState } from "react";
import { useMusic } from "../MusicContext";
import { LOCAL_CATALOG } from "../musicCatalog";
import { MusicTrack, getMusicHealth } from "../musicApi";
import { motion, AnimatePresence } from "motion/react";
import {
  Activity,
  Award,
  BarChart3,
  BellRing,
  Check,
  Clock3,
  Disc3,
  Gamepad2,
  Headphones,
  Heart,
  ListMusic,
  Moon,
  Music2,
  PartyPopper,
  Play,
  Radio,
  RotateCcw,
  Settings2,
  Sparkles,
  TimerReset,
  TrendingUp,
  Users,
  Wand2,
  Waves,
  X,
  Zap,
} from "lucide-react";

const VERSION = "0.5.9";
const BUILD = "LIVE MUSIC + PLAYBACK REPAIR";

const moods = ["Chill", "Happy", "Late Night", "Energetic", "Focus", "Dreamy"];
const genres = ["Pop", "Indie", "Lo-fi", "Hip-Hop", "Rock", "Electronic"];

const demoSongs = LOCAL_CATALOG.slice(0, 5).map((track) => ({ ...track, emoji: "🎵", color: "var(--glass-strong)" }));

const changelog = [
  { version: "0.5.6", title: "Live YouTube Music Bridge", items: ["Search now points at the deployed Hearify ytmusicapi bridge by default", "Home discovery can use live catalogue results", "Live bridge wording and setup docs updated"] },
  { version: "0.5.5", title: "Playback Repair + Real Search Fallback", items: ["Removed the Golden Hour player fallback", "YouTube IFrame playback for seeded catalog tracks", "Search remains usable without a hosted bridge", "Shared player state fixes"] },
  { version: "0.5.3", title: "Original Layout Restore + Live Music", items: ["Restored the proven original mobile layout", "Shared YouTube Music bridge architecture", "More themes and reduced ambient workload", "PWA manifest + offline shell", "Live catalog search and shared playback controls"] },
  { version: "0.4.0", title: "Feature Playground", items: ["Prototype Lab tab", "Smart Mix + mood mixer", "Stats, achievements and listening personality", "Room social experiments", "Equalizer, sleep timer and playback sandbox", "Prototype version tracking"] },
  { version: "0.3.2", title: "Feature Polish", items: ["Offline library prototype", "Fixed queue + suggest scrolling", "Home activity improvements", "Search / notification animations"] },
  { version: "0.3.0", title: "Everything Prototype", items: ["Now Playing", "Search", "Notifications", "Settings", "Theme system"] },
  { version: "0.2.0", title: "Themed Build", items: ["Multiple visual themes", "Ambient effects", "Profile / settings foundation"] },
];

const initialFeatures = [
  { name: "Smart Mix", desc: "Generate a queue from the connected/starter music catalog.", icon: Wand2 },
  { name: "Mood Mixer", desc: "Blend moods into the next listening session.", icon: Sparkles },
  { name: "Listening Lounge", desc: "Wander through live rooms and social activity.", icon: Radio },
  { name: "Music Personality", desc: "Turn your habits into a tiny music identity.", icon: Headphones },
  { name: "Year in Hearify", desc: "Wrapped-style stats for your prototype profile.", icon: BarChart3 },
  { name: "Achievements", desc: "Unlock silly and serious listening badges.", icon: Award },
  { name: "Room Reactions", desc: "Throw live emoji reactions into a room.", icon: PartyPopper },
  { name: "EQ Sandbox", desc: "Tune bass, mids and treble for the UI prototype.", icon: Waves },
];

const upcomingFeatures = [
  ["Listening Lounge", "Live room discovery with richer social presence and room chat."],
  ["Playlists 2.0", "Drag-to-reorder playlists, covers, folders and collaborative editing."],
  ["Year in Hearify", "Wrapped-style yearly recap generated from local listening history."],
  ["Smart Queue", "Automatic queue shaping based on mood, skips, likes and time of day."],
  ["Desktop Companion", "A compact always-on-top mini player for desktop-sized screens."],
  ["Account Sync", "Optional sign-in layer for playlists, likes and friends across devices."],
  ["Shared Listening", "Synchronized playback, host controls and room-wide queue voting."],
];


export function PrototypeLab() {
  const { searchTracks, playTrack, addToQueue, current, isPlaying: globalPlaying, togglePlay, currentTime, duration, next } = useMusic();
  const [apiOnline, setApiOnline] = useState<boolean | null>(null);
  useEffect(() => {
    let cancelled = false;
    getMusicHealth().then((result) => { if (!cancelled) setApiOnline(result.ok); });
    return () => { cancelled = true; };
  }, []);
  useEffect(() => { if (current) setNowPlaying(current); }, [current?.videoId]);
  const [section, setSection] = useState<"overview" | "playground" | "changelog" | "upcoming">("overview");
  const [mood, setMood] = useState("Dreamy");
  const [genre, setGenre] = useState("Indie");
  const [mix, setMix] = useState<MusicTrack[]>(demoSongs.slice(0, 3));
  const [nowPlaying, setNowPlaying] = useState<any>(current || demoSongs[0]);
  const [liked, setLiked] = useState(false);
  const [timer, setTimer] = useState("Off");
  const [eq, setEq] = useState({ bass: 58, mids: 46, treble: 62 });
  const [streak, setStreak] = useState(6);
  const [toast, setToast] = useState("");

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 1800);
  }

  async function generateMix() {
    let results: MusicTrack[] = [];
    try { results = await searchTracks(`${mood} ${genre} music`, 6); } catch { /* fall back to the local prototype set */ }
    const chosen = results.length ? results.slice(0, 4) : demoSongs.slice(0, 4);
    setMix(chosen as MusicTrack[]);
    setNowPlaying(chosen[0]);
    if (chosen[0]) void playTrack(chosen[0]);
    notify(`${mood} ${genre} mix generated ✨`);
  }

  function randomizeMood() {
    const nextMood = moods[Math.floor(Math.random() * moods.length)];
    const nextGenre = genres[Math.floor(Math.random() * genres.length)];
    setMood(nextMood);
    setGenre(nextGenre);
    notify("Your vibe has been randomized 🎲");
  }

  function setSleepTimer(value: string) {
    setTimer(value);
    notify(value === "Off" ? "Sleep timer off" : `Sleep timer set to ${value}`);
  }

  const personality = useMemo(() => {
    const score = eq.bass + eq.mids + eq.treble + streak * 5;
    if (score > 240) return { title: "Cloud Chaser", copy: "You collect feelings like playlists." };
    if (score > 190) return { title: "Night Driver", copy: "Your best songs sound better after midnight." };
    return { title: "Vibe Scout", copy: "You are always one skip away from finding something new." };
  }, [eq, streak]);

  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ fontFamily: "Nunito" }}>
      <div className="flex-1 overflow-y-auto px-5 pt-12 pb-8" style={{ scrollbarWidth: "none" }}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span style={{ width: 30, height: 30, borderRadius: 10, display: "grid", placeItems: "center", background: "linear-gradient(135deg,var(--primary),var(--accent))" }}>🧪</span>
              <span style={{ fontSize: 10, fontWeight: 900, color: "var(--primary)", letterSpacing: .7, textTransform: "uppercase" }}>Prototype Lab</span>
            </div>
            <h1 style={{ fontSize: 24, fontFamily: "Pacifico", color: "var(--text)", marginTop: 4 }}>Break stuff. Find magic.</h1>
            <p style={{ fontSize: 11, color: "var(--muted-text)", lineHeight: 1.45, marginTop: 3 }}>Everything here is intentionally experimental. Some ideas may be dumb. That's the point.</p>
          </div>
          <div style={{ padding: "8px 10px", borderRadius: 15, background: "var(--glass)", border: "1px solid var(--border)", textAlign: "right" }}>
            <p style={{ fontSize: 9, fontWeight: 900, color: "var(--muted-text)" }}>VERSION</p>
            <p style={{ fontSize: 13, fontWeight: 900, color: "var(--text)" }}>v{VERSION}</p>
          </div>
        </div>

        <div className="flex gap-2 mt-5 p-1 rounded-[18px]" style={{ background: "var(--glass)", border: "1px solid var(--border)" }}>
          {[
            ["overview", "Overview"],
            ["playground", "Try it"],
            ["changelog", "Changelog"],
            ["upcoming", "Upcoming"],
          ].map(([id, label]) => (
            <button key={id} onClick={() => setSection(id as typeof section)} style={{ flex: 1, padding: "9px 6px", borderRadius: 14, border: "none", background: section === id ? "linear-gradient(135deg,var(--primary),var(--accent))" : "transparent", color: section === id ? "white" : "var(--muted-text)", fontSize: 10, fontWeight: 900 }}>{label}</button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {section === "overview" && (
            <motion.div key="overview" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-4 mt-4">
              <div style={{ padding: 16, borderRadius: 22, background: "linear-gradient(135deg,color-mix(in srgb,var(--primary) 85%,white),color-mix(in srgb,var(--accent) 85%,white))", color: "white", boxShadow: "0 14px 32px color-mix(in srgb,var(--primary) 22%,transparent)" }}>
                <div className="flex items-center gap-2"><Zap size={15} /><span style={{ fontSize: 10, fontWeight: 900, letterSpacing: .6, textTransform: "uppercase" }}>{BUILD}</span></div>
                <p style={{ fontSize: 18, fontWeight: 900, marginTop: 7 }}>Hearify is allowed to be weird here.</p>
                <p style={{ fontSize: 10, opacity: .86, marginTop: 3, lineHeight: 1.45 }}>Prototype features can be rough, hidden, replaced, or completely deleted later. Try everything now.</p>
                <div className="flex items-center gap-2 mt-3"><span style={{width:7,height:7,borderRadius:4,background:apiOnline===true?"#4ade80":apiOnline===false?"#fb7185":"#fbbf24"}}/><span style={{fontSize:9,fontWeight:900,opacity:.9}}>{apiOnline===true?"YouTube Music bridge online":apiOnline===false?"Bridge offline — demo fallback active":"Checking music bridge…"}</span></div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {[{ icon: Users, value: "8", label: "live rooms" }, { icon: Music2, value: "213", label: "shared songs" }, { icon: Activity, value: "6d", label: "listening streak" }, { icon: Award, value: "14", label: "badges" }].map((s) => {
                  const Icon = s.icon;
                  return <div key={s.label} style={{ padding: 14, borderRadius: 18, background: "var(--glass)", border: "1px solid var(--border)" }}><Icon size={15} color="var(--primary)"/><p style={{ fontSize: 20, fontWeight: 900, color: "var(--text)", marginTop: 5 }}>{s.value}</p><p style={{ fontSize: 10, color: "var(--muted-text)" }}>{s.label}</p></div>;
                })}
              </div>

              <div>
                <div className="flex items-center justify-between mb-2"><p style={{ fontSize: 11, fontWeight: 900, color: "var(--text)" }}>Feature playground</p><span style={{ fontSize: 9, color: "var(--muted-text)" }}>{initialFeatures.length} experiments</span></div>
                <div className="space-y-2">
                  {initialFeatures.map((feature) => {
                    const Icon = feature.icon;
                    return <motion.button key={feature.name} whileTap={{ scale: .985 }} onClick={() => notify(`${feature.name} opened in the sandbox`) } className="w-full text-left flex items-center gap-3" style={{ padding: 12, borderRadius: 17, background: "var(--glass)", border: "1px solid var(--border)" }}><span style={{ width: 36, height: 36, borderRadius: 12, display: "grid", placeItems: "center", background: "color-mix(in srgb,var(--primary) 11%,transparent)" }}><Icon size={16} color="var(--primary)"/></span><div className="flex-1 min-w-0"><p style={{ fontSize: 12, fontWeight: 900, color: "var(--text)" }}>{feature.name}</p><p style={{ fontSize: 9, color: "var(--muted-text)", marginTop: 2 }}>{feature.desc}</p></div><span style={{ fontSize: 14, color: "var(--muted-text)" }}>›</span></motion.button>;
                  })}
                </div>
              </div>
            </motion.div>
          )}

          {section === "playground" && (
            <motion.div key="playground" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-4 mt-4">
              <section style={{ padding: 15, borderRadius: 22, background: "var(--glass)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2"><Wand2 size={15} color="var(--primary)"/><p style={{ fontSize: 12, fontWeight: 900, color: "var(--text)" }}>Smart Mix</p></div>
                <p style={{ fontSize: 9, color: "var(--muted-text)", marginTop: 3 }}>Spin up a demo queue based on mood + genre.</p>
                <div className="flex gap-2 mt-3 overflow-x-auto" style={{ scrollbarWidth: "none" }}>{moods.map((item) => <button key={item} onClick={() => setMood(item)} style={{ flexShrink: 0, padding: "7px 10px", borderRadius: 15, border: "1px solid var(--border)", background: mood === item ? "color-mix(in srgb,var(--primary) 16%,transparent)" : "transparent", color: mood === item ? "var(--primary)" : "var(--muted-text)", fontSize: 9, fontWeight: 900 }}>{item}</button>)}</div>
                <div className="flex gap-2 mt-2 overflow-x-auto" style={{ scrollbarWidth: "none" }}>{genres.map((item) => <button key={item} onClick={() => setGenre(item)} style={{ flexShrink: 0, padding: "7px 10px", borderRadius: 15, border: "1px solid var(--border)", background: genre === item ? "color-mix(in srgb,var(--accent) 16%,transparent)" : "transparent", color: genre === item ? "var(--accent)" : "var(--muted-text)", fontSize: 9, fontWeight: 900 }}>{item}</button>)}</div>
                <button onClick={generateMix} style={{ width: "100%", marginTop: 10, padding: 11, borderRadius: 15, border: "none", background: "linear-gradient(135deg,var(--primary),var(--accent))", color: "white", fontSize: 10, fontWeight: 900 }}>Generate {mood} {genre} Mix ✨</button>
                <div className="space-y-1.5 mt-3">{mix.map((song, i) => <button key={song.title} onClick={() => { setNowPlaying(song); void playTrack(song); notify(`Playing ${song.title}`); }} className="w-full flex items-center gap-2 text-left" style={{ padding: 8, borderRadius: 13, background: "color-mix(in srgb,var(--glass-strong) 55%,transparent)", border: "1px solid var(--border)" }}><span style={{ width: 30, height: 30, borderRadius: 9, background: "var(--glass-strong)", display: "grid", placeItems: "center", overflow:"hidden" }}>{song.thumbnail ? <img src={song.thumbnail} alt="" loading="lazy" style={{width:"100%",height:"100%",objectFit:"cover"}}/> : "🎵"}</span><span className="flex-1"><b style={{ display: "block", fontSize: 10, color: "var(--text)" }}>{song.title}</b><small style={{ fontSize: 8, color: "var(--muted-text)" }}>{song.artist}</small></span><span style={{ fontSize: 9, color: "var(--muted-text)" }}>{String(i + 1).padStart(2, "0")}</span></button>)}</div>
              </section>

              <section style={{ padding: 15, borderRadius: 22, background: "var(--glass)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2"><Headphones size={15} color="var(--accent)"/><p style={{ fontSize: 12, fontWeight: 900, color: "var(--text)" }}>Mini Player</p></div>
                <div className="flex items-center gap-3 mt-3"><div style={{ width: 52, height: 52, borderRadius: 15, background: "var(--glass-strong)", display: "grid", placeItems: "center", fontSize: 24, overflow:"hidden" }}>{nowPlaying?.thumbnail ? <img src={nowPlaying.thumbnail} alt="" loading="lazy" style={{width:"100%",height:"100%",objectFit:"cover"}}/> : "🎵"}</div><div className="flex-1 min-w-0"><p style={{ fontSize: 12, fontWeight: 900, color: "var(--text)" }}>{nowPlaying.title}</p><p style={{ fontSize: 9, color: "var(--muted-text)" }}>{nowPlaying.artist}</p></div><motion.button whileTap={{ scale: .88 }} onClick={togglePlay} style={{ width: 36, height: 36, borderRadius: 18, display: "grid", placeItems: "center", background: "linear-gradient(135deg,var(--primary),var(--accent))", border: "none", color: "white" }}>{globalPlaying ? "Ⅱ" : "▶"}</motion.button><button onClick={() => { setLiked(!liked); notify(liked ? "Removed from likes" : "Added to likes ❤️"); }} style={{ background: "transparent", border: "none", fontSize: 16 }}>{liked ? "❤️" : "🤍"}</button></div>
                <div className="flex items-center justify-between mt-3"><span style={{ fontSize: 8, color: "var(--muted-text)" }}>{Math.floor(currentTime/60)}:{String(Math.floor(currentTime%60)).padStart(2,"0")}</span><div style={{ height: 4, borderRadius: 4, background: "var(--muted)", flex: 1, margin: "0 8px" }}><div style={{ height: "100%", width: `${duration > 0 ? Math.min(100,(currentTime/duration)*100) : 0}%`, borderRadius: 4, background: "linear-gradient(90deg,var(--primary),var(--accent))" }}/></div><span style={{ fontSize: 8, color: "var(--muted-text)" }}>{Math.floor(duration/60)}:{String(Math.floor(duration%60)).padStart(2,"0")}</span></div>
              </section>

              <section style={{ padding: 15, borderRadius: 22, background: "var(--glass)", border: "1px solid var(--border)" }}>
                <div className="flex items-center justify-between"><div className="flex items-center gap-2"><SlidersIcon/><p style={{ fontSize: 12, fontWeight: 900, color: "var(--text)" }}>EQ Sandbox</p></div><button onClick={() => setEq({ bass: 50, mids: 50, treble: 50 })} style={{ border: "none", background: "transparent", color: "var(--primary)", fontSize: 9, fontWeight: 900 }}>Reset</button></div>
                {(["bass", "mids", "treble"] as const).map((key) => <label key={key} className="block mt-3"><div className="flex justify-between mb-1"><span style={{ fontSize: 9, fontWeight: 800, color: "var(--muted-text)", textTransform: "capitalize" }}>{key}</span><span style={{ fontSize: 9, color: "var(--primary)", fontWeight: 900 }}>{eq[key]}</span></div><input type="range" min="0" max="100" value={eq[key]} onChange={(e) => setEq({ ...eq, [key]: Number(e.target.value) })} style={{ width: "100%", accentColor: "var(--primary)" }}/></label>)}
              </section>

              <section style={{ padding: 15, borderRadius: 22, background: "var(--glass)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2"><Clock3 size={15} color="var(--pink)"/><p style={{ fontSize: 12, fontWeight: 900, color: "var(--text)" }}>Sleep Timer</p></div>
                <div className="grid grid-cols-5 gap-1.5 mt-3">{["Off", "15m", "30m", "45m", "1h"].map((value) => <button key={value} onClick={() => setSleepTimer(value)} style={{ padding: 8, borderRadius: 11, border: "1px solid var(--border)", background: timer === value ? "color-mix(in srgb,var(--pink) 14%,transparent)" : "transparent", color: timer === value ? "var(--pink)" : "var(--muted-text)", fontSize: 8, fontWeight: 900 }}>{value}</button>)}</div>
              </section>

              <section style={{ padding: 15, borderRadius: 22, background: "var(--glass)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2"><BarChart3 size={15} color="var(--primary)"/><p style={{ fontSize: 12, fontWeight: 900, color: "var(--text)" }}>Your prototype identity</p></div>
                <div className="flex items-center gap-3 mt-3"><div style={{ width: 54, height: 54, borderRadius: 18, background: "linear-gradient(135deg,var(--primary),var(--pink),var(--accent))", display: "grid", placeItems: "center", color: "white", fontSize: 22 }}>☁️</div><div className="flex-1"><p style={{ fontSize: 18, fontWeight: 900, color: "var(--text)" }}>{personality.title}</p><p style={{ fontSize: 9, color: "var(--muted-text)", marginTop: 2 }}>{personality.copy}</p></div></div>
                <div className="grid grid-cols-3 gap-2 mt-3">{[["42h","this month"],["6d","streak"],["87","songs saved"]].map(([v,l]) => <div key={l} style={{ padding: 9, borderRadius: 13, background: "color-mix(in srgb,var(--primary) 7%,transparent)", textAlign: "center" }}><p style={{ fontSize: 13, fontWeight: 900, color: "var(--text)" }}>{v}</p><p style={{ fontSize: 8, color: "var(--muted-text)" }}>{l}</p></div>)}</div>
              </section>

              <button onClick={() => { setStreak(streak + 1); notify(`Streak extended to ${streak + 1} days 🔥`); }} style={{ width: "100%", padding: 12, borderRadius: 16, border: "1px solid var(--border)", background: "var(--glass)", color: "var(--text)", fontSize: 10, fontWeight: 900 }}>Test streak system ({streak} days)</button>
              <button onClick={randomizeMood} style={{ width: "100%", padding: 12, borderRadius: 16, border: "none", background: "color-mix(in srgb,var(--accent) 12%,transparent)", color: "var(--accent)", fontSize: 10, fontWeight: 900 }}>🎲 Surprise me</button>
            </motion.div>
          )}

          {section === "changelog" && (
            <motion.div key="changelog" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-3 mt-4">
              <div style={{ padding: 14, borderRadius: 20, background: "var(--glass)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2"><RotateCcw size={14} color="var(--primary)"/><p style={{ fontSize: 11, fontWeight: 900, color: "var(--text)" }}>Prototype build history</p></div>
                <p style={{ fontSize: 9, color: "var(--muted-text)", marginTop: 3 }}>This tab is intentionally visible in prototype builds so testers can see exactly what changed.</p>
              </div>
              {changelog.map((entry, index) => <div key={entry.version} style={{ padding: 14, borderRadius: 20, background: index === 0 ? "color-mix(in srgb,var(--primary) 8%,var(--glass))" : "var(--glass)", border: index === 0 ? "1px solid color-mix(in srgb,var(--primary) 24%,transparent)" : "1px solid var(--border)" }}><div className="flex items-start justify-between"><div><span style={{ display: "inline-flex", padding: "4px 7px", borderRadius: 9, background: "linear-gradient(135deg,var(--primary),var(--accent))", color: "white", fontSize: 8, fontWeight: 900 }}>v{entry.version}</span><p style={{ fontSize: 13, fontWeight: 900, color: "var(--text)", marginTop: 6 }}>{entry.title}</p></div>{index === 0 && <span style={{ fontSize: 8, color: "var(--primary)", fontWeight: 900 }}>CURRENT</span>}</div><div className="space-y-1.5 mt-3">{entry.items.map(item => <div key={item} className="flex items-start gap-2"><Check size={12} color="var(--success)" style={{ marginTop: 1, flexShrink: 0 }}/><span style={{ fontSize: 9, color: "var(--muted-text)", lineHeight: 1.4 }}>{item}</span></div>)}</div></div>)}
              <div style={{ padding: 14, borderRadius: 20, background: "var(--glass)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-2"><TrendingUp size={14} color="var(--accent)" /><p style={{ fontSize: 11, fontWeight: 900, color: "var(--text)" }}>Upcoming</p></div>
                <p style={{ fontSize: 9, color: "var(--muted-text)", marginTop: 3 }}>Ideas queued for future prototype builds. Nothing here is promised — we're experimenting.</p>
                <div className="space-y-2 mt-3">{upcomingFeatures.map(([title, copy]) => <div key={title} className="flex items-start gap-2"><span style={{width:7,height:7,borderRadius:4,background:"var(--accent)",marginTop:4,flexShrink:0}}/><div><p style={{fontSize:10,fontWeight:900,color:"var(--text)"}}>{title}</p><p style={{fontSize:8,color:"var(--muted-text)",lineHeight:1.35,marginTop:1}}>{copy}</p></div></div>)}</div>
              </div>
            </motion.div>
          )}

          {section === "upcoming" && (
            <motion.div key="upcoming" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-3 mt-4">
              <div style={{ padding: 16, borderRadius: 22, background: "linear-gradient(135deg,color-mix(in srgb,var(--primary) 10%,var(--glass)),color-mix(in srgb,var(--accent) 8%,var(--glass)))", border: "1px solid var(--border)" }}>
                <p style={{fontSize:10,fontWeight:900,color:"var(--primary)",textTransform:"uppercase"}}>Hearify roadmap</p>
                <p style={{fontSize:18,fontWeight:900,color:"var(--text)",marginTop:5}}>What we build next</p>
                <p style={{fontSize:9,color:"var(--muted-text)",lineHeight:1.45,marginTop:3}}>A living list for the next time we come back to Hearify.</p>
              </div>
              {upcomingFeatures.map(([title, copy], index) => <div key={title} style={{padding:14,borderRadius:20,background:"var(--glass)",border:"1px solid var(--border)"}}><div className="flex items-start gap-3"><span style={{width:26,height:26,borderRadius:9,display:"grid",placeItems:"center",background:"color-mix(in srgb,var(--primary) 11%,transparent)",fontSize:10,fontWeight:900,color:"var(--primary)"}}>{String(index+1).padStart(2,"0")}</span><div className="flex-1"><p style={{fontSize:11,fontWeight:900,color:"var(--text)"}}>{title}</p><p style={{fontSize:9,color:"var(--muted-text)",lineHeight:1.4,marginTop:2}}>{copy}</p></div></div></div>)}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {toast && <motion.div initial={{ y: 12, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 12, opacity: 0 }} style={{ position: "absolute", left: 18, right: 18, bottom: 88, zIndex: 100, padding: "11px 14px", borderRadius: 16, background: "var(--glass-strong)", backdropFilter: "blur(18px)", border: "1px solid var(--border)", boxShadow: "0 12px 32px var(--shadow)", color: "var(--text)", fontSize: 10, fontWeight: 900, textAlign: "center" }}>{toast}</motion.div>}
      </AnimatePresence>
    </div>
  );
}

function SlidersIcon() {
  return <Settings2 size={15} color="var(--accent)" />;
}
