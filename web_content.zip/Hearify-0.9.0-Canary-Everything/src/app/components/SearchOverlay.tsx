
import { motion } from "motion/react";
import { ArrowLeft, Clock3, Search, Sparkles, X, ListPlus, Play } from "lucide-react";
import { useEffect, useState } from "react";
import { MusicTrack } from "../musicApi";
import { useMusic } from "../MusicContext";

const recent = ["night chill", "indie", "lofi focus", "pop classics"];

export function SearchOverlay({ onClose }: { onClose: () => void }) {
  const { searchTracks, playTrack, addToQueue } = useMusic();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<MusicTrack[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const query = q.trim();
    if (!query) {
      setResults([]);
      setError("");
      return;
    }
    const controller = new AbortController();
    const id = window.setTimeout(async () => {
      setLoading(true);
      setError("");
      try {
        const found = await searchTracks(query, 50, controller.signal);
        if (!controller.signal.aborted) setResults(found);
      } catch (err) {
        if (controller.signal.aborted) return;
        setResults([]);
        setError(err instanceof Error ? err.message : "The live music service is unavailable.");
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }, 280);
    return () => {
      window.clearTimeout(id);
      controller.abort();
    };
  }, [q, searchTracks]);

  async function handlePlay(track: MusicTrack) {
    await playTrack(track);
    onClose();
  }

  return (
    <motion.div initial={{ opacity: 0, scale: .985, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: .985, y: 10 }} transition={{ duration: .22, ease: "easeOut" }} className="absolute inset-0 z-[95] flex flex-col" style={{ background:"color-mix(in srgb,var(--sky) 78%,var(--glass-strong))", backdropFilter:"blur(24px)" }}>
      <div className="px-5 pt-12 pb-4">
        <div className="flex items-center gap-2">
          <button onClick={onClose} style={{width:38,height:38,borderRadius:19,background:"var(--glass)",border:"1px solid var(--border)",display:"grid",placeItems:"center"}}>
            <ArrowLeft size={17} color="var(--muted-text)"/>
          </button>
          <div className="flex-1 flex items-center gap-2 px-4" style={{height:44,borderRadius:16,background:"var(--glass-strong)",border:"1px solid var(--border)"}}>
            <Search size={17} color="var(--muted-text)"/>
            <input autoFocus value={q} onChange={e=>setQ(e.target.value)} placeholder="Songs, people, rooms..." style={{width:"100%",outline:"none",border:"none",background:"transparent",fontSize:13,color:"var(--text)",fontFamily:"Nunito"}}/>
            {q && <button onClick={()=>setQ("")} aria-label="Clear search"><X size={15} color="var(--muted-text)"/></button>}
          </div>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-5 pb-8" style={{scrollbarWidth:"none"}}>
        {!q && <>
          <div className="flex items-center gap-2 mb-3"><Clock3 size={15} color="var(--primary)"/><p style={{fontSize:11,fontWeight:800,color:"var(--muted-text)",textTransform:"uppercase"}}>Recent searches</p></div>
          <div className="flex flex-wrap gap-2 mb-7">{recent.map(x=><button key={x} onClick={()=>setQ(x)} style={{padding:"8px 11px",borderRadius:13,background:"var(--glass)",border:"1px solid var(--border)",fontSize:11,fontWeight:700,color:"var(--text)"}}>{x}</button>)}</div>
          <div className="flex items-center gap-2 mb-3"><Sparkles size={15} color="var(--accent)"/><p style={{fontSize:11,fontWeight:800,color:"var(--muted-text)",textTransform:"uppercase"}}>Try something</p></div>
          <div className="grid grid-cols-2 gap-3 mb-7">{["Late night songs","Find chill songs","Discover indie","Music for focus"].map(x=><motion.button whileTap={{scale:.97}} key={x} onClick={()=>setQ(x)} style={{padding:13,borderRadius:17,textAlign:"left",background:"var(--glass)",border:"1px solid var(--border)",color:"var(--text)"}}><div style={{fontSize:14,marginBottom:5}}>✨</div><span style={{fontSize:11,fontWeight:800}}>{x}</span></motion.button>)}</div>
          <div style={{padding:14,borderRadius:18,background:"color-mix(in srgb,var(--primary) 7%,var(--glass))",border:"1px solid var(--border)"}}>
            <p style={{fontSize:10,fontWeight:900,color:"var(--text)"}}>Live catalog search</p>
            <p style={{fontSize:9,color:"var(--muted-text)",marginTop:2}}>Searches YouTube Music through the live Hearify bridge.</p>
          </div>
        </>}

        {q && <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2"><Search size={15} color="var(--primary)"/><p style={{fontSize:11,fontWeight:800,color:"var(--muted-text)",textTransform:"uppercase"}}>Songs</p></div><span style={{fontSize:9,color:"var(--muted-text)"}}>{loading ? "Searching…" : `${results.length} results`}</span></div>}

        <div className="space-y-2">
          {results.map((r, i) => (
            <motion.div key={r.videoId} initial={{ opacity:0, y:5 }} animate={{ opacity:1, y:0 }} transition={{ delay: Math.min(i, 10) * 0.018, duration: 0.16 }} className="w-full flex items-center gap-3" style={{padding:10,borderRadius:17,background:"var(--glass)",border:"1px solid var(--border)"}}>
              <button onClick={() => void handlePlay(r)} className="flex items-center gap-3 flex-1 text-left min-w-0">
                <div style={{width:48,height:48,borderRadius:13,background:"var(--glass-strong)",overflow:"hidden",display:"grid",placeItems:"center",flexShrink:0}}>
                  {r.thumbnail ? <img src={r.thumbnail} alt="" loading="lazy" style={{width:"100%",height:"100%",objectFit:"cover"}}/> : <span style={{fontSize:19}}>🎵</span>}
                </div>
                <div className="flex-1 min-w-0"><p style={{fontSize:12,fontWeight:800,color:"var(--text)",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{r.title}</p><p style={{fontSize:10,color:"var(--muted-text)",marginTop:2,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{r.artist}{r.album ? ` · ${r.album}` : ""}</p></div>
                <Play size={15} color="var(--primary)" fill="var(--primary)" />
              </button>
              <button onClick={() => addToQueue(r)} aria-label={`Add ${r.title} to queue`} style={{width:34,height:34,borderRadius:12,background:"color-mix(in srgb,var(--primary) 10%,transparent)",border:"1px solid var(--border)",display:"grid",placeItems:"center"}}><ListPlus size={15} color="var(--primary)"/></button>
            </motion.div>
          ))}
          {q && !loading && !results.length && <div style={{padding:28,textAlign:"center",color:"var(--muted-text)"}}><div style={{fontSize:32}}>{error ? "⚠️" : "☁️"}</div><p style={{fontSize:13,fontWeight:800,color:"var(--text)",marginTop:6}}>{error ? "Live search failed" : "No songs found"}</p><p style={{fontSize:11, lineHeight:1.5}}>{error || "Try another search."}</p></div>}
          {loading && <div className="space-y-2" style={{paddingTop:4}}>{Array.from({length:5}).map((_,i)=><div key={i} style={{height:68,borderRadius:17,background:"color-mix(in srgb,var(--glass-strong) 55%,transparent)",border:"1px solid var(--border)",opacity:1-i*0.1,animation:"pulse 1.4s ease-in-out infinite"}}/> )}</div>}
        </div>
      </div>
    </motion.div>
  );
}
