import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  Bell, BookOpen, Check, ChevronDown, ChevronLeft, ChevronRight, Clock3, Disc3,
  Heart, Home, ListMusic, Loader2, Lock, Menu, MessageCircle, MoreHorizontal,
  Music2, Palette, Pause, Play, Plus, Radio, Repeat2, Search, Settings2, Share2,
  SlidersHorizontal, Sparkles, Star, Tag, Trash2, Users, Volume2, Wand2, Wifi,
  WifiOff, X, Zap, Download, LibraryBig, UserRound, DoorOpen, Flame, Moon,
} from "lucide-react";
import { useMusic } from "../MusicContext";
import { LOCAL_CATALOG } from "../musicCatalog";
import { DEFAULT_THEME, getTheme, THEMES, type Theme, type ThemeId } from "../themes";
import { CloudBackground } from "./CloudBackground";
import { NowPlayingSheet } from "./NowPlayingSheet";
import { NotificationsPanel } from "./NotificationsPanel";
import { SettingsScreen } from "./SettingsScreen";
import { ThemePicker } from "./ThemePicker";
import { PrototypeLab } from "./PrototypeLab";
import { CreateRoomScreen } from "./CreateRoomScreen";
import { RoomScreen } from "./RoomScreen";

const STORE = {
  theme: "hearify-canary-theme",
  liked: "hearify-canary-liked",
  history: "hearify-canary-history",
  playlists: "hearify-canary-playlists",
  profile: "hearify-canary-profile",
  settings: "hearify-canary-settings",
  firstRun: "hearify-canary-onboarded",
  creator: "hearify-canary-creator",
};

type Tab = "home" | "search" | "library" | "rooms" | "profile";
type Overlay = "player" | "settings" | "themes" | "notifications" | "lab" | "creator" | "onboarding" | "room" | "create" | null;

type CanaryPlaylist = {
  id: string;
  name: string;
  songs: string[];
  color: string;
  emoji: string;
  favorite: boolean;
  isPublic: boolean;
};

type CanaryProfile = {
  displayName: string;
  username: string;
  bio: string;
  avatar: string;
  tags: string[];
};

const DEMO_ROOMS = [
  { id: "night", name: "Late Night Chill", song: "Blinding Lights", artist: "The Weeknd", listeners: 14, emoji: "🌙", theme: "Rainy Night", color: "#45617f", mood: "Sleepy" },
  { id: "study", name: "Study Session", song: "As It Was", artist: "Harry Styles", listeners: 7, emoji: "📚", theme: "Late Night Study", color: "#9b7e6a", mood: "Focus" },
  { id: "game", name: "Game Night", song: "Sunflower", artist: "Post Malone & Swae Lee", listeners: 22, emoji: "🎮", theme: "Neon Arcade", color: "#6d4bb4", mood: "Hype" },
  { id: "road", name: "Road Trip", song: "Take On Me", artist: "a-ha", listeners: 11, emoji: "🚗", theme: "Sunset", color: "#d57b7b", mood: "Happy" },
  { id: "forest", name: "Quiet Forest", song: "Beautiful Things", artist: "Benson Boone", listeners: 5, emoji: "🌲", theme: "Quiet Forest", color: "#4d846f", mood: "Calm" },
  { id: "rain", name: "Rainy Evening", song: "Espresso", artist: "Sabrina Carpenter", listeners: 9, emoji: "🌧️", theme: "Rainy City", color: "#52779b", mood: "Cozy" },
];

const SOCIAL_ACTIVITY = [
  ["Milo", "is listening to Midnight City", "2m", "🦊"],
  ["Nora", "joined your Road Trip playlist", "8m", "🐱"],
  ["Kai", "started a Study Session room", "12m", "🧑‍🚀"],
  ["Lina", "liked your shared playlist", "24m", "🌸"],
] as const;

const ACHIEVEMENTS = [
  { id: "first", title: "First Listen", icon: "🎧", progress: 1, goal: 1, reward: "Rainy Window Echo" },
  { id: "owl", title: "Night Owl", icon: "🌙", progress: 17, goal: 20, reward: "Midnight Drive Echo" },
  { id: "explorer", title: "Explorer", icon: "🧭", progress: 31, goal: 50, reward: "Neon City Echo" },
  { id: "playlist", title: "Playlist Maker", icon: "🎶", progress: 8, goal: 10, reward: "Late Night Study Echo" },
  { id: "room", title: "Room Host", icon: "☁️", progress: 4, goal: 5, reward: "Game Night Echo" },
  { id: "social", title: "Social Butterfly", icon: "🦋", progress: 13, goal: 25, reward: "Quiet Forest Echo" },
  { id: "hundred", title: "100 Songs Played", icon: "💯", progress: 86, goal: 100, reward: "Theme Collector" },
  { id: "like", title: "First Like", icon: "❤️", progress: 1, goal: 1, reward: "Pink Frequency" },
];

const ECHOES = [
  { id: "rain", name: "Rainy Window", desc: "A city window with tiny droplets and warm reflections.", rarity: "Rare", emoji: "🌧️", unlocked: true },
  { id: "drive", name: "Midnight Drive", desc: "Headlights slide across a quiet road while the city sleeps.", rarity: "Epic", emoji: "🚗", unlocked: false },
  { id: "forest", name: "Quiet Forest", desc: "Fireflies drift around a deep green night.", rarity: "Rare", emoji: "🌲", unlocked: true },
  { id: "vhs", name: "Retro VHS", desc: "Soft scanlines, grain and old-school electric glow.", rarity: "Uncommon", emoji: "📼", unlocked: false },
  { id: "neon", name: "Neon City", desc: "Purple-blue towers and tiny moving lights.", rarity: "Legendary", emoji: "🌃", unlocked: false },
  { id: "study", name: "Late Night Study", desc: "A warm desk lamp and a room that feels safe and quiet.", rarity: "Uncommon", emoji: "📝", unlocked: true },
  { id: "game", name: "Game Night", desc: "Arcade glow, playful particles and a tiny bit of chaos.", rarity: "Rare", emoji: "🕹️", unlocked: false },
];

const DEFAULT_PLAYLISTS: CanaryPlaylist[] = [
  { id: "late", name: "Late Night Feels", songs: LOCAL_CATALOG.slice(0, 4).map(t => t.videoId), color: "#4c407d", emoji: "🌙", favorite: true, isPublic: true },
  { id: "road", name: "Road Trip Mix", songs: LOCAL_CATALOG.slice(2, 7).map(t => t.videoId), color: "#9a6249", emoji: "🚗", favorite: false, isPublic: false },
  { id: "clouds", name: "Morning Clouds", songs: LOCAL_CATALOG.slice(1, 6).map(t => t.videoId), color: "#4f82a3", emoji: "☁️", favorite: false, isPublic: true },
];

const DEFAULT_PROFILE: CanaryProfile = {
  displayName: "Aria Chen",
  username: "aria.dreaming",
  bio: "Lost in music, floating on clouds ☁️ sharing little moments with the world.",
  avatar: "🦝",
  tags: ["Night Owl", "Music Explorer", "Chill Listener", "Early Adopter"],
};

function readJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON<T>(key: string, value: T) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* canary build */ }
}

function formatTime(value: number) {
  if (!Number.isFinite(value) || value < 0) return "0:00";
  const seconds = Math.floor(value);
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
}

function trackArt(track: any, fallback = "🎵") {
  if (track?.thumbnail) return track.thumbnail;
  return fallback;
}

function getTrackColor(track: any, fallback = "#7c63d8") {
  const seed = String(track?.videoId || track?.title || "hearify");
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) | 0;
  const hue = Math.abs(hash) % 360;
  return `hsl(${hue} 68% 58%)` || fallback;
}

export function CanaryApp() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [themeId, setThemeId] = useState<ThemeId>(() => readJSON(STORE.theme, DEFAULT_THEME));
  const [overlay, setOverlay] = useState<Overlay>(() => localStorage.getItem(STORE.firstRun) ? null : "onboarding");
  const [profile, setProfile] = useState<CanaryProfile>(() => readJSON(STORE.profile, DEFAULT_PROFILE));
  const [liked, setLiked] = useState<string[]>(() => readJSON(STORE.liked, LOCAL_CATALOG.slice(0, 2).map(t => t.videoId)));
  const [history, setHistory] = useState<string[]>(() => readJSON(STORE.history, LOCAL_CATALOG.slice(2, 6).map(t => t.videoId)));
  const [playlists, setPlaylists] = useState<CanaryPlaylist[]>(() => readJSON(STORE.playlists, DEFAULT_PLAYLISTS));
  const [ambientEnabled, setAmbientEnabled] = useState<boolean>(() => readJSON(STORE.settings, { ambient: true }).ambient);
  const [ambientVolume, setAmbientVolume] = useState<number>(() => readJSON(STORE.settings, { ambient: true, volume: 0.07 }).volume ?? 0.07);
  const [lightMode, setLightMode] = useState<boolean>(() => readJSON(STORE.settings, { light: false }).light);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState(LOCAL_CATALOG.slice(0, 8));
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [roomMode, setRoomMode] = useState<"discover" | "customize" | "joined">("discover");
  const [selectedRoom, setSelectedRoom] = useState<(typeof DEMO_ROOMS)[number] | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [creatorApplied, setCreatorApplied] = useState(false);
  const [creatorConfig, setCreatorConfig] = useState(() => readJSON(STORE.creator, {
    name: "Midnight Raccoon",
    primary: "#9b7bff",
    secondary: "#3f2f67",
    accent: "#ef82bc",
    particle: "stars",
    furniture: "desk",
    lighting: 52,
    mascot: "theme",
    ambience: "rain",
    ui: "soft",
  }));

  const {
    current, isPlaying, loading, currentTime, duration, volume, muted,
    playTrack, togglePlay, next, previous, seek, setVolume, toggleMute,
    addToQueue, upNext,
  } = useMusic();

  const currentTrack = current || LOCAL_CATALOG[0];
  const theme = getTheme(themeId);
  const currentColor = getTrackColor(currentTrack);
  const canaryThemeStyle = {
    "--sky": theme.sky,
    "--text": lightMode ? "#3c3250" : theme.text,
    "--muted-text": lightMode ? "#766c87" : theme.muted,
    "--primary": creatorApplied ? (creatorConfig.primary || theme.primary) : theme.primary,
    "--accent": creatorApplied ? (creatorConfig.accent || theme.accent) : theme.accent,
    "--pink": theme.pink,
    "--glass": lightMode ? "rgba(255,255,255,.74)" : theme.glass,
    "--glass-strong": lightMode ? "rgba(255,255,255,.92)" : theme.glassStrong,
    "--border": theme.border,
    "--shadow": theme.shadow,
    "--note": theme.note,
    "--success": "#4ade80",
    "--art-color": currentColor,
  } as CSSProperties;

  useEffect(() => { writeJSON(STORE.theme, themeId); }, [themeId]);
  useEffect(() => { writeJSON(STORE.profile, profile); }, [profile]);
  useEffect(() => { writeJSON(STORE.liked, liked); }, [liked]);
  useEffect(() => { writeJSON(STORE.history, history.slice(0, 30)); }, [history]);
  useEffect(() => { writeJSON(STORE.playlists, playlists); }, [playlists]);
  useEffect(() => { writeJSON(STORE.settings, { ambient: ambientEnabled, volume: ambientVolume, light: lightMode }); }, [ambientEnabled, ambientVolume, lightMode]);
  useEffect(() => { writeJSON(STORE.creator, creatorConfig); }, [creatorConfig]);

  useEffect(() => {
    if (!current?.videoId) return;
    setHistory(prev => [current.videoId, ...prev.filter(id => id !== current.videoId)].slice(0, 30));
  }, [current?.videoId]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 1900);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const initAmbient = useAmbientAudio({ enabled: ambientEnabled, volume: ambientVolume, themeId, playing: isPlaying });

  function selectTab(tab: Tab) {
    setActiveTab(tab);
    initAmbient();
  }

  function runPlay(track: any) {
    initAmbient();
    void playTrack(track).catch(() => undefined);
    setOverlay("player");
  }

  function toggleLike(track: any) {
    initAmbient();
    setLiked(prev => prev.includes(track.videoId) ? prev.filter(id => id !== track.videoId) : [track.videoId, ...prev]);
    setToast(prev => prev);
    setToast(liked.includes(track.videoId) ? "Removed from likes" : "Added to likes ❤️");
  }

  function createPlaylist() {
    const nextId = `playlist-${Date.now()}`;
    const newPlaylist: CanaryPlaylist = { id: nextId, name: "New Vibe", songs: [], color: currentColor, emoji: "🎧", favorite: false, isPublic: false };
    setPlaylists(prev => [newPlaylist, ...prev]);
    setToast("Playlist created ✨");
    setActiveTab("library");
  }

  async function submitSearch(query = searchQuery) {
    const q = query.trim();
    setSearchError(null);
    if (!q) { setSearchResults(LOCAL_CATALOG.slice(0, 8)); return; }
    setSearchLoading(true);
    try {
      const live = await (await import("../musicApi")).searchMusic(q, 18);
      setSearchResults(live.length ? live : LOCAL_CATALOG.filter(t => `${t.title} ${t.artist}`.toLowerCase().includes(q.toLowerCase())));
    } catch {
      const local = LOCAL_CATALOG.filter(t => `${t.title} ${t.artist} ${t.album || ""}`.toLowerCase().includes(q.toLowerCase()));
      setSearchResults(local);
      setSearchError(local.length ? "Live search is sleeping — showing the local catalog." : "No results here yet. Try another search.");
    } finally {
      setSearchLoading(false);
    }
  }

  const contextRecommendations = useMemo(() => {
    const seedText = `${currentTrack.title} ${currentTrack.artist} ${theme.name}`.toLowerCase();
    const scored = LOCAL_CATALOG.map((track, index) => {
      let score = 0;
      const text = `${track.title} ${track.artist} ${track.album || ""}`.toLowerCase();
      if (text.includes(currentTrack.artist.split(",")[0].toLowerCase())) score += 4;
      if (seedText.includes("night") && /night|midnight|dream|after/i.test(text)) score += 2;
      if (seedText.includes("forest") && /forest|beautiful|things/i.test(text)) score += 1;
      if (liked.includes(track.videoId)) score += 2;
      score += Math.max(0, 10 - index) / 10;
      return { track, score };
    });
    return scored.sort((a, b) => b.score - a.score).map(({ track }) => track).slice(0, 6);
  }, [currentTrack, theme.name, liked]);

  const view = activeTab === "home"
    ? <CanaryHome onSearch={() => { setActiveTab("search"); setTimeout(() => document.getElementById("canary-search")?.focus(), 40); }} onPlay={runPlay} onRoom={(room) => { setSelectedRoom(room); setOverlay("room"); }} recommendations={contextRecommendations} profile={profile} current={currentTrack} isPlaying={isPlaying} loading={loading} togglePlay={togglePlay} currentTime={currentTime} duration={duration} />
    : activeTab === "search"
    ? <CanarySearch query={searchQuery} onQuery={setSearchQuery} onSubmit={() => void submitSearch()} results={searchResults} loading={searchLoading} error={searchError} onPlay={runPlay} liked={liked} onLike={toggleLike} onAddQueue={(track) => { addToQueue(track); setToast("Added to queue ✚"); }} />
    : activeTab === "library"
    ? <CanaryLibrary liked={liked} history={history} playlists={playlists} onPlay={runPlay} onLike={toggleLike} onCreatePlaylist={createPlaylist} onDeletePlaylist={(id) => setPlaylists(prev => prev.filter(p => p.id !== id))} onAddToPlaylist={(playlistId, videoId) => setPlaylists(prev => prev.map(p => p.id === playlistId && !p.songs.includes(videoId) ? { ...p, songs: [...p.songs, videoId] } : p))} />
    : activeTab === "rooms"
    ? <CanaryRooms roomMode={roomMode} setRoomMode={setRoomMode} rooms={DEMO_ROOMS} selectedRoom={selectedRoom} onSelectRoom={(room) => { setSelectedRoom(room); setOverlay("room"); }} onCreate={() => setOverlay("create")} />
    : <CanaryProfile profile={profile} setProfile={setProfile} liked={liked} history={history} playlists={playlists} onTheme={() => setOverlay("themes")} onSettings={() => setOverlay("settings")} onLab={() => setOverlay("lab")} onCreator={() => setOverlay("creator")} />;

  return (
    <div
      data-theme={theme.id}
      className="canary-root flex items-center justify-center size-full"
      style={{ ...canaryThemeStyle, background: theme.sky }}
    >
      <div className="canary-phone relative overflow-hidden flex flex-col" style={{ background: "transparent" }}>
        <CanaryBackdrop theme={theme} />
        <div className="absolute inset-0 pointer-events-none" style={{ background: `radial-gradient(circle at 72% 12%, color-mix(in srgb, var(--art-color) 15%, transparent), transparent 34%), radial-gradient(circle at 12% 88%, color-mix(in srgb, var(--accent) 10%, transparent), transparent 28%)`, zIndex: 1 }} />

        <header className="relative flex items-center justify-between px-5 pt-6 pb-2" style={{ zIndex: 30 }}>
          <button onClick={() => selectTab("home")} className="flex items-center gap-2 text-left" style={{ border: 0, background: "transparent", color: "var(--text)" }}>
            <HearifyMark size={38} />
            <div>
              <div style={{ fontFamily: "Nunito", fontWeight: 1000, fontSize: 15, letterSpacing: -0.25 }}>hearify</div>
              <div style={{ fontSize: 8, color: "var(--muted-text)", fontWeight: 800, letterSpacing: .7, textTransform: "uppercase" }}>experimental everything</div>
            </div>
          </button>
          <div className="flex items-center gap-2">
            <button className="canary-icon-btn" aria-label="Toggle ambient audio" onClick={() => { initAmbient(); setAmbientEnabled(v => !v); }}>
              {ambientEnabled ? <Volume2 size={16} color="var(--primary)" /> : <Volume2 size={16} color="var(--muted-text)" />}
              <span className="canary-live-dot" />
            </button>
            <button className="canary-icon-btn" aria-label="Notifications" onClick={() => setOverlay("notifications")}><Bell size={16} color="var(--muted-text)" /><span className="canary-notify-dot" /></button>
          </div>
        </header>

        <main className="relative flex-1 min-h-0 overflow-hidden" style={{ zIndex: 10 }}>
          <AnimatePresence mode="wait">
            <motion.div key={activeTab} className="absolute inset-0 overflow-hidden" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: .18 }}>
              {view}
            </motion.div>
          </AnimatePresence>
        </main>

        {current && (
          <motion.button
            className="canary-mini-player"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            whileTap={{ scale: .985 }}
            onClick={() => setOverlay("player")}
            style={{ zIndex: 45 }}
          >
            <div className="canary-art" style={{ backgroundImage: current.thumbnail ? `url(${current.thumbnail})` : "none", backgroundColor: currentColor }}>
              {!current.thumbnail && <Music2 size={16} color="white" />}
            </div>
            <div className="min-w-0 flex-1 text-left">
              <div className="canary-scroller-text"><span>{current.title}</span></div>
              <div style={{ fontSize: 8, color: "var(--muted-text)", marginTop: 1 }}>{current.artist}</div>
            </div>
            <div className="canary-mini-progress" style={{ width: `${duration ? Math.min(100, currentTime / duration * 100) : 0}%` }} />
            <button className="canary-mini-play" aria-label={isPlaying ? "Pause" : "Play"} onClick={(event) => { event.stopPropagation(); initAmbient(); togglePlay(); }}>
              {loading ? <Loader2 size={13} color="white" className="animate-spin" /> : isPlaying ? <Pause size={14} color="white" fill="white" /> : <Play size={14} color="white" fill="white" />}
            </button>
          </motion.button>
        )}

        <nav className="canary-nav" style={{ zIndex: 40 }}>
          <NavItem active={activeTab === "home"} label="Home" icon={<Home size={18} />} onClick={() => selectTab("home")} />
          <NavItem active={activeTab === "search"} label="Search" icon={<Search size={18} />} onClick={() => selectTab("search")} />
          <NavItem active={activeTab === "library"} label="Library" icon={<LibraryBig size={18} />} onClick={() => selectTab("library")} />
          <NavItem active={activeTab === "rooms"} label="Rooms" icon={<Users size={18} />} onClick={() => selectTab("rooms")} />
          <NavItem active={activeTab === "profile"} label="You" icon={<UserRound size={18} />} onClick={() => selectTab("profile")} />
        </nav>

        <AnimatePresence>
          {overlay === "player" && <NowPlayingSheet onClose={() => setOverlay(null)} />}
          {overlay === "themes" && <ThemePicker value={themeId} onChange={(next) => { setThemeId(next); setCreatorApplied(false); setOverlay(null); }} onClose={() => setOverlay(null)} />}
          {overlay === "settings" && <CanarySettings theme={theme} ambientEnabled={ambientEnabled} setAmbientEnabled={setAmbientEnabled} ambientVolume={ambientVolume} setAmbientVolume={setAmbientVolume} lightMode={lightMode} setLightMode={setLightMode} onThemes={() => setOverlay("themes")} onLab={() => setOverlay("lab")} onClose={() => setOverlay(null)} muted={muted} volume={volume} setVolume={setVolume} toggleMute={toggleMute} />}
          {overlay === "notifications" && <NotificationsPanel onClose={() => setOverlay(null)} />}
          {overlay === "lab" && <LabOverlay onClose={() => setOverlay(null)} onCreator={() => setOverlay("creator")} />}
          {overlay === "creator" && <ThemeCreator config={creatorConfig} setConfig={setCreatorConfig} onApply={() => { setCreatorApplied(true); setToast("Your custom atmosphere is live ✨"); }} onClose={() => setOverlay(null)} />}
          {overlay === "create" && <div className="absolute inset-0 z-[90]"><CreateRoomScreen onBack={() => setOverlay(null)} onCreated={() => { setToast("Room created ☁️"); setOverlay("room"); }} /></div>}
          {overlay === "room" && selectedRoom && <div className="absolute inset-0 z-[90]"><RoomScreen onBack={() => setOverlay(null)} /></div>}
          {overlay === "onboarding" && <Onboarding onDone={() => { localStorage.setItem(STORE.firstRun, "1"); setOverlay(null); }} onTheme={() => { localStorage.setItem(STORE.firstRun, "1"); setOverlay("themes"); }} />}
        </AnimatePresence>

        <AnimatePresence>
          {toast && <motion.div className="canary-toast" initial={{ y: 14, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 14, opacity: 0 }}>{toast}</motion.div>}
        </AnimatePresence>
      </div>
    </div>
  );
}

function HearifyMark({ size = 38 }: { size?: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size * .28, display: "grid", placeItems: "center", background: "linear-gradient(135deg,var(--primary),var(--pink),var(--accent))", boxShadow: "0 10px 30px color-mix(in srgb,var(--primary) 25%,transparent)" }}>
      <svg width={size*.64} height={size*.64} viewBox="0 0 48 48" fill="none">
        <path d="M11 11v26M11 24h16M27 11v19M27 30l7-3v7" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="32.5" cy="35" r="3.2" fill="white" />
      </svg>
    </div>
  );
}

function NavItem({ active, label, icon, onClick }: { active: boolean; label: string; icon: ReactNode; onClick: () => void }) {
  return <motion.button whileTap={{ scale: .9 }} onClick={onClick} className="canary-nav-item" style={{ color: active ? "var(--primary)" : "var(--muted-text)" }}>
    <div className={active ? "canary-nav-icon active" : "canary-nav-icon"}>{icon}</div>
    <span>{label}</span>
  </motion.button>;
}

function CanaryBackdrop({ theme }: { theme: Theme }) {
  const night = ["night", "rainy", "rainycity", "quietforest", "neoncity", "latenightstudy", "retrovhs", "gamenight", "arcade", "midnight", "starlight", "lavendernight", "aurora", "space", "thunderstorm"].includes(theme.id);
  const city = ["rainy", "rainycity", "neoncity", "retrovhs", "arcade", "midnight", "starlight", "space"].includes(theme.id);
  return <div className="absolute inset-0 overflow-hidden" style={{ zIndex: 0 }}>
    <CloudBackground theme={theme} />
    {city && <div className="canary-cityline" aria-hidden="true"><span style={{ height: "28%" }} /><span style={{ height: "44%" }} /><span style={{ height: "23%" }} /><span style={{ height: "58%" }} /><span style={{ height: "36%" }} /><span style={{ height: "51%" }} /><span style={{ height: "30%" }} /></div>}
    {night && <div className="canary-vignette" aria-hidden="true" />}
    {theme.id === "rainy" || theme.id === "rainycity" || theme.id === "thunderstorm" || theme.id === "latenightstudy" ? <div className="canary-window-reflection" aria-hidden="true" /> : null}
  </div>;
}

function SectionTitle({ title, subtitle, action, onAction }: { title: string; subtitle?: string; action?: string; onAction?: () => void }) {
  return <div className="canary-section-title"><div><div className="canary-kicker">{title}</div>{subtitle && <div className="canary-subtitle">{subtitle}</div>}</div>{action && <button onClick={onAction} className="canary-link-btn">{action}</button>}</div>;
}

function CanaryHome({ onSearch, onPlay, onRoom, recommendations, profile, current, isPlaying, loading, togglePlay, currentTime, duration }: any) {
  const featured = current || LOCAL_CATALOG[0];
  return <div className="canary-scroll">
    <div className="canary-home-hero">
      <div>
        <p className="canary-greeting">Good evening, {profile.displayName.split(" ")[0]} <span>✦</span></p>
        <h1>What are we<br /><span>feeling tonight?</span></h1>
        <p className="canary-hero-copy">Music for the thing you're actually doing — together or on your own.</p>
      </div>
      <RaccoonMascot mood={isPlaying ? "listening" : "night"} small />
    </div>

    <button className="canary-search-pill" onClick={onSearch}><Search size={15} /><span>Search songs, artists, albums…</span><kbd>⌘K</kbd></button>

    <div className="canary-feature-card" onClick={() => onPlay(featured)}>
      <div className="canary-feature-art" style={{ backgroundImage: featured.thumbnail ? `linear-gradient(135deg,rgba(10,7,20,.06),rgba(10,7,20,.4)),url(${featured.thumbnail})` : "none", backgroundColor: getTrackColor(featured) }}>
        {!featured.thumbnail && <Music2 size={38} color="white" />}
        <div className="canary-feature-badge"><Radio size={11} /> NOW FOR YOU</div>
        <motion.div className="canary-equalizer" animate={{ opacity: isPlaying ? 1 : .6 }}><i/><i/><i/><i/></motion.div>
      </div>
      <div className="canary-feature-meta"><div className="min-w-0"><p className="canary-kicker">CONTINUE LISTENING</p><h2>{featured.title}</h2><p>{featured.artist}</p></div><motion.button whileTap={{ scale: .86 }} onClick={(e) => { e.stopPropagation(); togglePlay(); }} className="canary-round-play">{loading ? <Loader2 size={19} className="animate-spin" color="white" /> : isPlaying ? <Pause size={19} color="white" fill="white" /> : <Play size={19} color="white" fill="white" />}</motion.button></div>
      <div className="canary-progress"><span style={{ width: `${durationSafe(featured, current, currentTime, duration) }%` }} /></div>
    </div>

    <SectionTitle title="Made for your mood" subtitle="A tiny radio that adapts to you." />
    <div className="canary-horizontal">
      {["Late Night", "Study", "Gaming", "Road Trip", "Rainy Evening"].map((mood, i) => <button key={mood} className="canary-mood-card" onClick={() => onPlay(recommendations[i % recommendations.length] || LOCAL_CATALOG[i])}><span>{["🌙", "📚", "🎮", "🚗", "🌧️"][i]}</span><div><strong>{mood}</strong><small>{["soft & cinematic", "lock in", "turn it up", "windows down", "cozy mode"][i]}</small></div></button>)}
    </div>

    <SectionTitle title="Recently played" action="See all" />
    <div className="canary-list">{LOCAL_CATALOG.slice(0, 5).map((track, i) => <SongRow key={track.videoId} track={track} index={i} onPlay={onPlay} />)}</div>

    <SectionTitle title="Recommended for you" subtitle="Why these? Similar energy + your recent vibe." />
    <div className="canary-grid-2">{recommendations.slice(0, 4).map((track: any, i: number) => <AlbumCard key={track.videoId} track={track} onPlay={onPlay} label={i === 0 ? "MATCH 98%" : "FOR YOU"} />)}</div>

    <SectionTitle title="People are listening together" action="Explore rooms" onAction={() => undefined} />
    <div className="canary-horizontal rooms">{DEMO_ROOMS.slice(0, 4).map(room => <button key={room.id} className="canary-room-card" onClick={() => onRoom(room)}><div className="canary-room-art" style={{ background: `linear-gradient(135deg,${room.color},color-mix(in srgb,${room.color} 30%,#fff))` }}><span>{room.emoji}</span><b><i /> {room.listeners}</b></div><strong>{room.name}</strong><small>{room.song}</small></button>)}</div>

    <SectionTitle title="Friend activity" subtitle="A little corner of the social side." />
    <div className="canary-activity-card">{SOCIAL_ACTIVITY.map(([name, action, time, emoji]) => <div className="canary-activity-row" key={name}><div className="canary-avatar">{emoji}</div><div className="min-w-0 flex-1"><p><b>{name}</b> {action}</p><small>{time} ago</small></div><button><MoreHorizontal size={15} /></button></div>)}</div>

    <div className="canary-home-promo"><div><span className="canary-kicker">HEARIFY EXPERIMENT</span><h3>Try changing the whole atmosphere.</h3><p>The current theme can change visuals, motion, ambience and even the raccoon.</p></div><RaccoonMascot mood="idle" /></div>
  </div>;
}

function durationSafe(track: any, current: any, currentTime = 0, duration = 0) { return current?.videoId === track.videoId && duration > 0 ? Math.min(100, Math.max(0, (currentTime / duration) * 100)) : 34; }

function SongRow({ track, index = 0, onPlay, right }: { track: any; index?: number; onPlay: (track: any) => void; right?: ReactNode }) {
  return <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * .035 }} whileTap={{ scale: .985 }} onClick={() => onPlay(track)} className="canary-song-row" role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onPlay(track); } }}>
    <div className="canary-number">{String(index + 1).padStart(2, "0")}</div>
    <div className="canary-row-art" style={{ backgroundImage: track.thumbnail ? `url(${track.thumbnail})` : "none", backgroundColor: getTrackColor(track) }}>{!track.thumbnail && <Music2 size={15} color="white" />}</div>
    <div className="min-w-0 flex-1 text-left"><p>{track.title}</p><small>{track.artist}{track.album ? ` · ${track.album}` : ""}</small></div>
    {right || <MoreHorizontal size={17} color="var(--muted-text)" />}
  </motion.div>;
}

function AlbumCard({ track, onPlay, label }: { track: any; onPlay: (track: any) => void; label?: string }) {
  return <motion.button whileTap={{ scale: .97 }} onClick={() => onPlay(track)} className="canary-album-card"><div className="canary-album-art" style={{ backgroundImage: track.thumbnail ? `url(${track.thumbnail})` : "none", backgroundColor: getTrackColor(track) }}>{!track.thumbnail && <Music2 size={28} color="white" />}{label && <span>{label}</span>}</div><strong>{track.title}</strong><small>{track.artist}</small></motion.button>;
}

function CanarySearch({ query, onQuery, onSubmit, results, loading, error, onPlay, liked, onLike, onAddQueue }: any) {
  const [filter, setFilter] = useState<"all" | "songs" | "artists" | "albums" | "playlists">("all");
  return <div className="canary-scroll"><div className="canary-screen-title"><div><span className="canary-kicker">DISCOVERY</span><h1>Search</h1><p>Find something for the exact moment you're in.</p></div><Sparkles size={20} color="var(--primary)" /></div>
    <form className="canary-search-box" onSubmit={(e) => { e.preventDefault(); void onSubmit(); }}><Search size={17} color="var(--muted-text)" /><input id="canary-search" autoComplete="off" value={query} onChange={(e) => onQuery(e.target.value)} placeholder="Songs, artists, albums, playlists" /><button type="button" onClick={() => onQuery("")}><X size={15} /></button></form>
    <div className="canary-chip-row">{["all", "songs", "artists", "albums", "playlists"].map(f => <button key={f} className={filter === f ? "active" : ""} onClick={() => setFilter(f as any)}>{f[0].toUpperCase() + f.slice(1)}</button>)}</div>
    {!query && <div className="canary-suggest"><span>Try</span>{["The Weeknd", "late night", "lo-fi", "Greek pop", "game night"].map(q => <button key={q} onClick={() => { onQuery(q); void onSubmit(q); }}>#{q}</button>)}</div>}
    {loading && <div className="canary-status-card"><Loader2 size={18} className="animate-spin" color="var(--primary)" /><span>Searching the music cloud…</span></div>}
    {error && <div className="canary-status-card warning"><WifiOff size={16} /><span>{error}</span></div>}
    {!loading && results.length === 0 && <EmptyState icon="🔎" title="Nothing surfaced" copy="Try a broader artist, song or mood." />}
    {!loading && results.length > 0 && <div className="canary-search-results">{results.map((track: any, i: number) => <SongRow key={track.videoId} track={track} index={i} onPlay={onPlay} right={<div className="flex items-center gap-1"><button className="canary-row-icon" onClick={(e) => { e.stopPropagation(); onLike(track); }}><Heart size={15} color={liked.includes(track.videoId) ? "var(--pink)" : "var(--muted-text)"} fill={liked.includes(track.videoId) ? "var(--pink)" : "none"} /></button><button className="canary-row-icon" onClick={(e) => { e.stopPropagation(); onAddQueue(track); }}><Plus size={15} color="var(--primary)" /></button></div>} />)}</div>}
  </div>;
}

function CanaryLibrary({ liked, history, playlists, onPlay, onLike, onCreatePlaylist, onDeletePlaylist, onAddToPlaylist }: any) {
  const [filter, setFilter] = useState<"liked" | "history" | "playlists" | "albums" | "saved">("liked");
  const likedTracks = LOCAL_CATALOG.filter(t => liked.includes(t.videoId));
  const historyTracks = history.map((id: string) => LOCAL_CATALOG.find(t => t.videoId === id)).filter(Boolean);
  return <div className="canary-scroll"><div className="canary-screen-title"><div><span className="canary-kicker">YOUR MUSIC</span><h1>Library</h1><p>Everything you've decided to keep close.</p></div><Download size={19} color="var(--primary)" /></div>
    <div className="canary-chip-row">{[["liked", "Liked"], ["history", "History"], ["playlists", "Playlists"], ["albums", "Albums"], ["saved", "Saved"]].map(([id, label]) => <button key={id} className={filter === id ? "active" : ""} onClick={() => setFilter(id as any)}>{label}</button>)}</div>
    {filter === "liked" && <><div className="canary-library-hero"><div><span className="canary-kicker">FAVORITES</span><h2>Liked Songs</h2><p>{likedTracks.length} songs you've hearted.</p></div><div className="canary-heart-stack">❤️</div></div><div className="canary-list">{likedTracks.map((t: any, i: number) => <SongRow key={t.videoId} track={t} index={i} onPlay={onPlay} right={<button className="canary-row-icon" onClick={(e) => { e.stopPropagation(); onLike(t); }}><Heart size={15} color="var(--pink)" fill="var(--pink)" /></button>} />)}</div>{likedTracks.length === 0 && <EmptyState icon="🤍" title="Nothing liked yet" copy="Heart a song and it will land here." />}</>}
    {filter === "history" && <><SectionTitle title="Listening history" subtitle="Your latest little audio footprints." action="Clear" onAction={() => undefined} /><div className="canary-list">{historyTracks.map((t: any, i: number) => <SongRow key={`${t.videoId}-${i}`} track={t} index={i} onPlay={onPlay} />)}</div>{historyTracks.length === 0 && <EmptyState icon="🕘" title="Your history is empty" copy="Start a song and we'll remember it in this canary build." />}</>}
    {filter === "playlists" && <><div className="flex items-center justify-between mb-3"><SectionTitle title="Your playlists" subtitle="Messy experiments welcome." /><button className="canary-primary-small" onClick={onCreatePlaylist}><Plus size={14} /> New</button></div><div className="canary-playlist-grid">{playlists.map((p: CanaryPlaylist) => <PlaylistCard key={p.id} playlist={p} onPlay={onPlay} onDelete={() => onDeletePlaylist(p.id)} onAdd={onAddToPlaylist} />)}</div></>}
    {filter === "albums" && <><SectionTitle title="Saved albums" subtitle="Album pages are part of the experiment." /><div className="canary-grid-2">{LOCAL_CATALOG.slice(0, 6).map(t => <AlbumCard key={t.videoId} track={t} onPlay={onPlay} />)}</div></>}
    {filter === "saved" && <EmptyState icon="🔖" title="Saved spaces" copy="A future home for saved rooms, themes and community objects." action="Open themes" />}
  </div>;
}

function PlaylistCard({ playlist, onPlay, onDelete, onAdd }: { playlist: CanaryPlaylist; onPlay: (track: any) => void; onDelete: () => void; onAdd: (playlistId: string, videoId: string) => void }) {
  const track = LOCAL_CATALOG.find(t => playlist.songs.includes(t.videoId)) || LOCAL_CATALOG[0];
  return <motion.div whileTap={{ scale: .985 }} className="canary-playlist-card"><div className="canary-playlist-cover" style={{ background: `linear-gradient(135deg,${playlist.color},color-mix(in srgb,${playlist.color} 20%,#171224))` }}><span>{playlist.emoji}</span><small>{playlist.songs.length} tracks</small></div><div className="p-3"><div className="flex items-start justify-between gap-2"><div className="min-w-0"><strong>{playlist.name}</strong><small>{playlist.isPublic ? "Public" : "Private"} · {playlist.favorite ? "Favorite" : "Yours"}</small></div><button className="canary-row-icon" onClick={onDelete}><Trash2 size={14} /></button></div><div className="flex gap-1.5 mt-3"><button className="canary-primary-small" onClick={() => onPlay(track)}><Play size={12} fill="currentColor" /> Play</button><button className="canary-secondary-small" onClick={() => onAdd(playlist.id, LOCAL_CATALOG[(playlist.songs.length + 1) % LOCAL_CATALOG.length].videoId)}><Plus size={12} /> Add</button></div></div></motion.div>;
}

function CanaryRooms({ roomMode, setRoomMode, rooms, selectedRoom, onSelectRoom, onCreate }: any) {
  if (selectedRoom && roomMode === "joined") return <div className="canary-scroll"><JoinedRoom room={selectedRoom} onBack={() => setRoomMode("discover")} /></div>;
  return <div className="canary-scroll"><div className="canary-screen-title"><div><span className="canary-kicker">TOGETHER</span><h1>Rooms</h1><p>Do your own thing, together.</p></div><motion.button whileTap={{ scale: .9 }} onClick={onCreate} className="canary-primary-icon"><Plus size={17} /></motion.button></div>
    <div className="canary-room-tabs"><button className={roomMode === "discover" ? "active" : ""} onClick={() => setRoomMode("discover")}>Discover</button><button className={roomMode === "customize" ? "active" : ""} onClick={() => setRoomMode("customize")}>Customize</button></div>
    {roomMode === "discover" && <><div className="canary-live-banner"><div className="live-pulse" /><div><strong>Live right now</strong><small>{rooms.reduce((sum: number, r: any) => sum + r.listeners, 0)} people listening in demo rooms</small></div><Users size={17} /></div><div className="canary-room-list">{rooms.map((room: any, i: number) => <motion.button initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * .035 }} whileTap={{ scale: .985 }} key={room.id} className="canary-big-room" onClick={() => { onSelectRoom(room); setRoomMode("joined"); }}><div className="canary-room-art large" style={{ background: `linear-gradient(135deg,${room.color},color-mix(in srgb,${room.color} 40%,#141022))` }}><span>{room.emoji}</span><b><i /> {room.listeners}</b></div><div className="min-w-0 flex-1 text-left"><div className="flex items-center gap-1.5"><strong>{room.name}</strong><span className="canary-room-tag">{room.mood}</span></div><p>{room.song}</p><small>{room.artist} · {room.theme}</small><div className="canary-avatar-stack">{["🧑", "🧑‍🎤", "🦝", "🌸"].slice(0, Math.min(4, room.listeners > 8 ? 4 : 3)).map((a, j) => <span key={j}>{a}</span>)}</div></div><ChevronRight size={16} color="var(--muted-text)" /></motion.button>)}</div></>}
    {roomMode === "customize" && <RoomCustomizer />}
  </div>;
}

function JoinedRoom({ room, onBack }: { room: any; onBack: () => void }) {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([["Nora", "this vibe is immaculate", "🌸"], ["Kai", "queue is actually perfect", "🧑‍🚀"], ["You", "adding one more song", "🦝"]] as string[][]);
  const track = LOCAL_CATALOG.find(t => t.title === room.song) || LOCAL_CATALOG[0];
  return <>
    <div className="flex items-center gap-2 mb-3"><button className="canary-icon-btn" onClick={onBack}><ChevronLeft size={16} /></button><div className="flex-1"><span className="canary-kicker">ROOM</span><h2 style={{ fontSize: 18, fontWeight: 1000, color: "var(--text)" }}>{room.name}</h2></div><span className="canary-live-pill"><i /> LIVE</span></div>
    <div className="canary-room-hero" style={{ background: `linear-gradient(135deg,${room.color},color-mix(in srgb,${room.color} 20%,#111))` }}><div className="canary-room-hero-glow" /><div className="canary-room-hero-content"><div className="canary-mini-room-icon">{room.emoji}</div><span className="canary-kicker">NOW PLAYING</span><h2>{track.title}</h2><p>{track.artist}</p><div className="canary-room-progress"><span style={{ width: "47%" }} /></div><div className="flex items-center justify-between mt-2"><small>1:38</small><small>{track.durationText || "3:20"}</small></div></div></div>
    <div className="grid grid-cols-3 gap-2 mt-3"><InfoStat value={String(room.listeners)} label="listening" /><InfoStat value="12" label="queue" /><InfoStat value="38%" label="in sync" /></div>
    <div className="canary-room-panel"><div className="flex items-center justify-between"><SectionTitle title="Shared queue" subtitle="Anyone can add." /><button className="canary-row-icon"><Plus size={15} /></button></div><div className="canary-list compact">{[track, LOCAL_CATALOG[1], LOCAL_CATALOG[4]].map((t, i) => <SongRow key={`${t.videoId}-${i}`} track={t} index={i} onPlay={() => undefined} right={<span style={{ fontSize: 9, fontWeight: 900, color: i === 0 ? "var(--primary)" : "var(--muted-text)" }}>{i === 0 ? "PLAYING" : `${i + 1}`}</span>} />)}</div></div>
    <div className="canary-room-panel"><div className="flex items-center gap-2 mb-3"><MessageCircle size={15} color="var(--primary)" /><div><strong>Room chat</strong><small>Live conversation</small></div></div><div className="canary-chat">{chat.map(([name, text, emoji], i) => <div className={name === "You" ? "canary-chat-row mine" : "canary-chat-row"} key={i}><div className="canary-avatar">{emoji}</div><div><small>{name}</small><p>{text}</p></div></div>)}</div><form className="canary-chat-input" onSubmit={(e) => { e.preventDefault(); if (!message.trim()) return; setChat(prev => [...prev, ["You", message.trim(), "🦝"]]); setMessage(""); }}><input value={message} onChange={e => setMessage(e.target.value)} placeholder="Say something…"/><button><Sparkles size={15} /></button></form></div>
    <div className="canary-reaction-row">{["❤️", "🔥", "✨", "😂", "💿", "🌧️"].map(x => <button key={x} onClick={() => undefined}>{x}</button>)}</div>
  </>;
}

function InfoStat({ value, label }: { value: string; label: string }) { return <div className="canary-stat-mini"><strong>{value}</strong><small>{label}</small></div>; }

function RoomCustomizer() {
  const [selected, setSelected] = useState({ bg: "night", furniture: "desk", particles: true, lamp: true, plants: false });
  const objects = [{ id: "desk", label: "Desk", emoji: "🪑" }, { id: "lamp", label: "Lamp", emoji: "🛋️" }, { id: "plant", label: "Plant", emoji: "🪴" }, { id: "shelf", label: "Shelf", emoji: "📚" }, { id: "painting", label: "Painting", emoji: "🖼️" }, { id: "speaker", label: "Speaker", emoji: "🔊" }];
  return <div><div className="canary-custom-preview"><div className="canary-custom-grid" /><div className="canary-custom-room-object desk">🪑</div><div className="canary-custom-room-object lamp">💡</div><div className="canary-custom-room-object plant">{selected.plants ? "🪴" : ""}</div><div className="canary-custom-room-raccoon"><RaccoonMascot mood="room" /></div><div className="canary-custom-label">DRAGGABLE PREVIEW</div>{selected.particles && <div className="canary-fireflies">✦ · ✧ · ✦ · ✧</div>}</div><div className="canary-custom-panel"><div className="flex items-center justify-between mb-3"><div><span className="canary-kicker">ROOM LAB</span><h3>Build your little world</h3></div><Wand2 size={18} color="var(--primary)" /></div><div className="canary-object-grid">{objects.map(o => <button key={o.id} className={(o.id === "plant" && selected.plants) || (o.id === "desk" && selected.furniture === "desk") ? "active" : ""} onClick={() => o.id === "plant" ? setSelected(s => ({ ...s, plants: !s.plants })) : o.id === "desk" ? setSelected(s => ({ ...s, furniture: "desk" })) : undefined}><span>{o.emoji}</span><small>{o.label}</small></button>)}</div><div className="canary-toggle-line"><span>Animated particles</span><button className={selected.particles ? "toggle active" : "toggle"} onClick={() => setSelected(s => ({ ...s, particles: !s.particles }))}><i /></button></div><div className="canary-toggle-line"><span>Ambient lamp</span><button className={selected.lamp ? "toggle active" : "toggle"} onClick={() => setSelected(s => ({ ...s, lamp: !s.lamp }))}><i /></button></div></div></div>;
}

function CanaryProfile({ profile, setProfile, liked, history, playlists, onTheme, onSettings, onLab, onCreator }: any) {
  const [tab, setTab] = useState<"profile" | "achievements" | "echoes">("profile");
  const [editing, setEditing] = useState(false);
  const [selectedEcho, setSelectedEcho] = useState<string | null>(null);
  return <div className="canary-scroll"><div className="canary-profile-top"><div className="canary-profile-avatar-wrap"><div className="canary-profile-avatar">{profile.avatar}</div><span><i /></span></div><div className="flex-1 min-w-0"><span className="canary-kicker">YOUR CLOUD</span><h1>{profile.displayName}</h1><p>@{profile.username}</p><div className="canary-profile-tags">{profile.tags.slice(0, 3).map((tag: string) => <span key={tag}><Tag size={10} />{tag}</span>)}</div></div><button className="canary-icon-btn" onClick={onSettings}><Settings2 size={17} /></button></div>
    <div className="canary-profile-bio">{profile.bio}</div>
    <div className="grid grid-cols-3 gap-2.5"><InfoStat value={String(playlists.length)} label="playlists" /><InfoStat value={String(liked.length)} label="likes" /><InfoStat value={String(history.length)} label="plays" /></div>
    <div className="canary-profile-actions"><button onClick={() => setEditing(v => !v)}><UserRound size={14} /> {editing ? "Done" : "Edit profile"}</button><button onClick={onTheme}><Palette size={14} /> Themes</button><button onClick={onLab}><FlaskIcon /> Lab</button></div>
    {editing && <div className="canary-edit-card"><label>Display name<input value={profile.displayName} onChange={e => setProfile((p: CanaryProfile) => ({ ...p, displayName: e.target.value }))} /></label><label>Username<input value={profile.username} onChange={e => setProfile((p: CanaryProfile) => ({ ...p, username: e.target.value }))} /></label><label>Bio<textarea value={profile.bio} onChange={e => setProfile((p: CanaryProfile) => ({ ...p, bio: e.target.value }))} /></label><label>Avatar emoji<input value={profile.avatar} onChange={e => setProfile((p: CanaryProfile) => ({ ...p, avatar: e.target.value }))} /></label></div>}
    <div className="canary-chip-row profile">{[["profile", "Overview"], ["achievements", "Achievements"], ["echoes", "Echoes"]].map(([id, label]) => <button key={id} className={tab === id ? "active" : ""} onClick={() => setTab(id as any)}>{label}</button>)}</div>
    {tab === "profile" && <><SectionTitle title="Recent activity" subtitle="What your cloud has been doing."/><div className="canary-activity-card">{[...history.slice(0, 4)].map((id: string, i: number) => { const track = LOCAL_CATALOG.find(t => t.videoId === id) || LOCAL_CATALOG[i]; return <div key={`${id}-${i}`} className="canary-activity-row"><div className="canary-row-art" style={{ backgroundImage: track.thumbnail ? `url(${track.thumbnail})` : "none", backgroundColor: getTrackColor(track) }} /><div className="flex-1 min-w-0"><p><b>{i === 0 ? "You" : "Your cloud"}</b> listened to {track.title}</p><small>{i * 7 + 2} min ago</small></div><Music2 size={14} color="var(--primary)" /></div>})}</div><SectionTitle title="Little things you collected"/><div className="canary-collection-strip">{ECHOES.filter(e => e.unlocked).slice(0, 3).map(e => <button key={e.id} onClick={() => { setSelectedEcho(e.id); }}><span>{e.emoji}</span><strong>{e.name}</strong><small>{e.rarity}</small></button>)}</div><div className="canary-home-promo compact"><div><span className="canary-kicker">THEME CREATOR</span><h3>Make your own atmosphere.</h3><p>Color, particles, room objects, mascot and ambience — all in one little sandbox.</p></div><button onClick={onCreator} className="canary-primary-icon"><Wand2 size={17} /></button></div></>}
    {tab === "achievements" && <div className="canary-achievement-grid">{ACHIEVEMENTS.map(a => <AchievementCard key={a.id} achievement={a} />)}</div>}
    {tab === "echoes" && <div className="canary-echo-grid">{ECHOES.map(e => <button key={e.id} className={e.unlocked ? "canary-echo-card" : "canary-echo-card locked"} onClick={() => e.unlocked && setSelectedEcho(e.id)}><div className="canary-echo-art">{e.unlocked ? e.emoji : <Lock size={19} />}</div><div><strong>{e.name}</strong><small>{e.rarity}</small><p>{e.desc}</p></div>{e.unlocked ? <Check size={15} color="var(--success)" /> : <span className="canary-lock-label">LOCKED</span>}</button>)}</div>}
    <AnimatePresence>{selectedEcho && <motion.div className="canary-echo-modal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedEcho(null)}><motion.div initial={{ y: 20, scale: .97 }} animate={{ y: 0, scale: 1 }} onClick={e => e.stopPropagation()} className="canary-echo-modal-card"><div className="canary-echo-big">{ECHOES.find(e => e.id === selectedEcho)?.emoji}</div><span className="canary-kicker">COLLECTED ECHO</span><h2>{ECHOES.find(e => e.id === selectedEcho)?.name}</h2><p>{ECHOES.find(e => e.id === selectedEcho)?.desc}</p><button className="canary-primary-wide" onClick={() => setSelectedEcho(null)}>Equip this vibe</button></motion.div></motion.div>}</AnimatePresence>
  </div>;
}

function AchievementCard({ achievement }: { achievement: typeof ACHIEVEMENTS[number] }) { const done = achievement.progress >= achievement.goal; return <div className={done ? "canary-achievement done" : "canary-achievement"}><div className="canary-achievement-icon">{achievement.icon}</div><div className="flex-1 min-w-0"><div className="flex items-center justify-between"><strong>{achievement.title}</strong><span>{achievement.progress}/{achievement.goal}</span></div><div className="canary-progress small"><span style={{ width: `${Math.min(100, achievement.progress / achievement.goal * 100)}%` }} /></div><small>{done ? `Unlocked · ${achievement.reward}` : `Reward · ${achievement.reward}`}</small></div>{done && <Check size={15} color="var(--success)" />}</div>; }

function EmptyState({ icon, title, copy, action }: { icon: string; title: string; copy: string; action?: string }) { return <div className="canary-empty"><div className="canary-empty-icon">{icon}</div><RaccoonMascot mood="idle" /><h3>{title}</h3><p>{copy}</p>{action && <button className="canary-primary-small">{action}</button>}</div>; }

function RaccoonMascot({ mood = "idle", small = false }: { mood?: string; small?: boolean }) {
  const bob = mood === "listening" ? [0, -5, 0] : [0, -2, 0];
  return <motion.div animate={{ y: bob }} transition={{ duration: mood === "listening" ? 1.8 : 4, repeat: Infinity, ease: "easeInOut" }} className={small ? "canary-raccoon small" : "canary-raccoon"} data-mood={mood}>
    <svg viewBox="0 0 160 160" role="img" aria-label="Hearify raccoon mascot"><defs><linearGradient id="raccoonFur" x1="0" x2="1"><stop stopColor="var(--primary)"/><stop offset="1" stopColor="var(--pink)"/></linearGradient></defs><path d="M32 60L24 28l32 16c10-5 38-5 48 0l32-16-8 32c6 10 8 20 8 34 0 30-21 49-52 49s-52-19-52-49c0-14 2-24 8-34Z" fill="url(#raccoonFur)"/><path d="M40 88c3-18 18-29 40-29s37 11 40 29v23c-10 12-24 18-40 18s-30-6-40-18Z" fill="#393344" opacity=".88"/><ellipse cx="58" cy="91" rx="8" ry="6" fill="#111"/><ellipse cx="102" cy="91" rx="8" ry="6" fill="#111"/><circle cx="60" cy="89" r="2.2" fill="white"/><circle cx="104" cy="89" r="2.2" fill="white"/><path d="M76 103c3 3 5 3 8 0" stroke="#f4bed8" strokeWidth="4" strokeLinecap="round"/><path d="M50 50c8-12 52-12 60 0" stroke="var(--accent)" strokeWidth="11" strokeLinecap="round"/><path d="M41 55c-8 12-8 26 0 36" stroke="var(--accent)" strokeWidth="5" strokeLinecap="round"/><path d="M119 55c8 12 8 26 0 36" stroke="var(--accent)" strokeWidth="5" strokeLinecap="round"/><circle cx="49" cy="48" r="10" fill="none" stroke="var(--accent)" strokeWidth="5"/><circle cx="111" cy="48" r="10" fill="none" stroke="var(--accent)" strokeWidth="5"/><path d="M66 28h28" stroke="var(--pink)" strokeWidth="4" strokeLinecap="round"/><path d="M93 28h-1" stroke="white" strokeWidth="2"/><circle cx="95" cy="32" r="2" fill="white"/><path d="M32 122c-5 10-1 22 8 28" stroke="url(#raccoonFur)" strokeWidth="15" strokeLinecap="round"/><path d="M128 122c5 10 1 22-8 28" stroke="url(#raccoonFur)" strokeWidth="15" strokeLinecap="round"/></svg><div className="canary-raccoon-glow" />{mood === "listening" && <div className="canary-headphone-wave">♪ ♫ ♪</div>}{mood === "room" && <div className="canary-raccoon-bubble">room mode</div>}</motion.div>;
}

function CanarySettings({ theme, ambientEnabled, setAmbientEnabled, ambientVolume, setAmbientVolume, lightMode, setLightMode, onThemes, onLab, onClose, muted, volume, setVolume, toggleMute }: any) {
  return <motion.div className="canary-modal-screen" initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}><div className="canary-modal-head"><button className="canary-icon-btn" onClick={onClose}><ChevronDown size={17} /></button><div><span className="canary-kicker">CONTROL CENTER</span><h2>Settings</h2></div></div><div className="canary-scroll modal-scroll"><section className="canary-settings-card"><div className="canary-setting-row"><div><strong>Appearance</strong><small>{theme.name} · {lightMode ? "Light" : "Night"}</small></div><button onClick={onThemes} className="canary-secondary-small"><Palette size={12} /> Change</button></div><div className="canary-setting-row"><div><strong>Light mode</strong><small>Temporary canary accessibility toggle.</small></div><button className={lightMode ? "toggle active" : "toggle"} onClick={() => setLightMode((v: boolean) => !v)}><i /></button></div></section><section className="canary-settings-card"><div className="canary-setting-row"><div><strong>Ambient theme audio</strong><small>Only when no real song is playing.</small></div><button className={ambientEnabled ? "toggle active" : "toggle"} onClick={() => setAmbientEnabled((v: boolean) => !v)}><i /></button></div><label className="canary-range"><span>Ambient volume</span><b>{Math.round(ambientVolume * 100)}%</b><input type="range" min="0" max="0.15" step="0.005" value={ambientVolume} onChange={e => setAmbientVolume(Number(e.target.value))} /></label></section><section className="canary-settings-card"><div className="canary-setting-row"><div><strong>Playback</strong><small>Autoplay on · adaptive queue · {muted ? "muted" : `${Math.round(volume*100)}% volume`}</small></div><div className="flex items-center gap-1"><button className="canary-row-icon" onClick={toggleMute}><Volume2 size={14} /></button><button className="canary-row-icon" onClick={() => setVolume(Math.min(1, volume + .08))}>+</button></div></div><div className="canary-setting-row"><div><strong>Audio quality</strong><small>Canary bridge · best available</small></div><span className="canary-status-label">AUTO</span></div></section><section className="canary-settings-card"><div className="canary-setting-row"><div><strong>Social</strong><small>Activity sharing · room invites · reactions</small></div><ChevronRight size={15} /></div><div className="canary-setting-row"><div><strong>Data</strong><small>History and local canary data live on this device.</small></div><button className="canary-secondary-small" onClick={() => undefined}><Trash2 size={12}/> Clear</button></div></section><section className="canary-settings-card experimental"><div className="flex items-center gap-2"><Zap size={16} color="var(--pink)"/><div><strong>Experimental everything build</strong><small>Feature coverage · perfect architecture can wait. This build is disposable.</small></div></div><button className="canary-primary-wide" onClick={onLab}>Open Lab</button></section><div className="canary-build-stamp">HEARIFY · 0.X-EXPERIMENTAL · CANARY</div></div></motion.div>;
}

function LabOverlay({ onClose, onCreator }: { onClose: () => void; onCreator: () => void }) {
  return <motion.div className="canary-modal-screen" initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}><div className="canary-modal-head"><button className="canary-icon-btn" onClick={onClose}><ChevronDown size={17} /></button><div><span className="canary-kicker">EXPERIMENTAL</span><h2>Hearify Lab</h2></div></div><div className="canary-scroll modal-scroll"><div className="canary-lab-hero"><div><span className="canary-kicker">EVERYTHING BUILD</span><h3>Throw ideas at the wall.</h3><p>Some experiments will survive. Some will be scrapped. That's the point.</p></div><RaccoonMascot mood="idle" /></div><div className="canary-lab-grid"><LabTile icon="🎨" title="Theme Creator" copy="Build custom atmosphere rules." onClick={onCreator}/><LabTile icon="🦝" title="Mascot states" copy="Idle, loading, listening, room mode."/><LabTile icon="🌧️" title="Ambient audio" copy="Procedural theme soundscape."/><LabTile icon="🎛️" title="Player experiments" copy="Queue, sheet, lyrics, dynamic art."/><LabTile icon="☁️" title="Room experiments" copy="Furniture, layers and room mood."/><LabTile icon="✨" title="Transition lab" copy="Motion and interaction tests."/></div><div className="canary-changelog"><span className="canary-kicker">WHAT'S IN THIS CANARY</span>{["Atmospheric backgrounds + dynamic art glow", "Local likes/history/playlists", "Rooms + shared queue/chat mock", "Achievements + Echoes", "Theme creator + community preview", "Raccoon mascot + ambient audio", "Search + live music bridge fallback"].map(x => <div key={x}><Check size={13} color="var(--success)"/>{x}</div>)}</div><div className="canary-lab-note"><Flame size={15} color="var(--pink)"/><p>This version is intentionally temporary. Don't polish it forever. Use it to discover what deserves to survive.</p></div><PrototypeLab /></div></motion.div>;
}
function LabTile({ icon, title, copy, onClick }: { icon: string; title: string; copy: string; onClick?: () => void }) { return <motion.button whileTap={{ scale: .97 }} className="canary-lab-tile" onClick={onClick}><span>{icon}</span><div><strong>{title}</strong><small>{copy}</small></div><ChevronRight size={15} color="var(--muted-text)"/></motion.button>; }

function ThemeCreator({ config, setConfig, onApply, onClose }: any) {
  const palettes = ["#9b7bff", "#68e7ff", "#ef7fbb", "#7fcf9a", "#f19b78", "#b98cff"];
  const particles = ["stars", "rain", "petals", "bubbles", "notes"];
  return <motion.div className="canary-modal-screen" initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}><div className="canary-modal-head"><button className="canary-icon-btn" onClick={onClose}><ChevronDown size={17} /></button><div><span className="canary-kicker">CREATE YOUR VIBE</span><h2>Theme Creator</h2></div><button className="canary-primary-small" onClick={() => { setConfig({ ...config, name: config.name || "Untitled Vibe" }); onApply(); }}><Check size={13}/> Apply</button></div><div className="canary-scroll modal-scroll"><div className="canary-creator-preview" style={{ background: `linear-gradient(145deg, ${config.secondary}, #10101c 72%)` }}><div className="canary-creator-neon" style={{ background: config.primary }} /><div className="canary-creator-neon two" style={{ background: config.accent }} /><div className="canary-creator-card"><div className="canary-kicker">LIVE PREVIEW</div><strong>{config.name}</strong><span>Change one thing. Watch the world react.</span><div className="canary-creator-swatches"><i style={{ background: config.primary }} /><i style={{ background: config.secondary }} /><i style={{ background: config.accent }} /></div><RaccoonMascot mood="listening" /></div></div><label className="canary-form-field">Theme name<input value={config.name} onChange={e => setConfig({ ...config, name: e.target.value })}/></label><div className="canary-form-block"><span>Primary color</span><div className="canary-palette">{palettes.map(c => <button key={c} onClick={() => setConfig({ ...config, primary: c })} style={{ background: c }} className={config.primary === c ? "selected" : ""}/>)}</div></div><div className="canary-form-block"><span>Accent color</span><div className="canary-palette">{palettes.slice().reverse().map(c => <button key={c} onClick={() => setConfig({ ...config, accent: c })} style={{ background: c }} className={config.accent === c ? "selected" : ""}/>)}</div></div><div className="canary-form-block"><span>Particles</span><div className="canary-chip-row">{particles.map(p => <button key={p} className={config.particle === p ? "active" : ""} onClick={() => setConfig({ ...config, particle: p })}>{p}</button>)}</div></div><div className="canary-form-block"><span>Lighting</span><input type="range" min="0" max="100" value={config.lighting} onChange={e => setConfig({ ...config, lighting: Number(e.target.value) })}/></div><div className="canary-form-block"><span>UI style</span><div className="canary-chip-row">{["soft", "sharp", "playful"].map(u => <button key={u} className={config.ui === u ? "active" : ""} onClick={() => setConfig({ ...config, ui: u })}>{u}</button>)}</div></div><div className="grid grid-cols-2 gap-2"><button className="canary-secondary-wide" onClick={() => setConfig({ ...config, name: "Untitled Vibe", primary: "#9b7bff", secondary: "#3f2f67", accent: "#ef82bc", particle: "stars", lighting: 52, ui: "soft" })}>Reset</button><button className="canary-primary-wide" onClick={onClose}>Done</button></div><div className="canary-build-stamp">Community sharing/remixing is a visual mock in this canary.</div></div></motion.div>;
}

function Onboarding({ onDone, onTheme }: { onDone: () => void; onTheme: () => void }) {
  const [step, setStep] = useState(0);
  const slides = [
    { title: "Welcome to Hearify", copy: "A music app for people who are doing their own thing together.", emoji: "🦝" },
    { title: "Music is only half of it", copy: "Find your songs, build playlists, jump into rooms and share the moment.", emoji: "🎧" },
    { title: "Make the app feel like yours", copy: "Themes can change colors, atmosphere, movement, ambience and the mascot.", emoji: "🌙" },
  ];
  const s = slides[step];
  return <motion.div className="canary-onboarding" initial={{ opacity: 0 }} animate={{ opacity: 1 }}><div className="canary-onboard-orbit">{s.emoji}</div><div className="canary-onboard-card"><div className="canary-kicker">HEARIFY EXPERIMENT</div><h1>{s.title}</h1><p>{s.copy}</p><div className="canary-onboard-dots">{slides.map((_, i) => <span key={i} className={i === step ? "active" : ""}/>)}</div><div className="flex gap-2 mt-4"><button className="canary-secondary-wide" onClick={onDone}>Skip</button><button className="canary-primary-wide" onClick={() => step < slides.length - 1 ? setStep(step + 1) : onTheme()}>{step < slides.length - 1 ? "Next" : "Pick a vibe"}</button></div></div></motion.div>;
}

function FlaskIcon() { return <span style={{ fontSize: 13 }}>🧪</span>; }

function useAmbientAudio({ enabled, volume, themeId, playing }: { enabled: boolean; volume: number; themeId: ThemeId; playing: boolean }) {
  const engineRef = useRef<AmbientEngine | null>(null);
  useEffect(() => {
    if (!engineRef.current) engineRef.current = new AmbientEngine();
    engineRef.current.setProfile(themeId, volume);
    if (playing || !enabled) engineRef.current.fadeOut();
    else engineRef.current.fadeIn();
    return () => engineRef.current?.fadeOut();
  }, [enabled, volume, themeId, playing]);
  return () => engineRef.current?.resume();
}

class AmbientEngine {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  noise: AudioBufferSourceNode | null = null;
  filter: BiquadFilterNode | null = null;
  tone: OscillatorNode | null = null;
  profile: ThemeId = "night";
  maxGain = .07;
  started = false;

  resume() {
    if (!this.ctx) this.start();
    void this.ctx?.resume();
  }
  start() {
    try {
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0;
      this.master.connect(this.ctx.destination);
      const size = this.ctx.sampleRate * 2;
      const buffer = this.ctx.createBuffer(1, size, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < size; i++) data[i] = (Math.random() * 2 - 1) * 0.18;
      this.noise = this.ctx.createBufferSource();
      this.noise.buffer = buffer;
      this.noise.loop = true;
      this.filter = this.ctx.createBiquadFilter();
      this.filter.type = "lowpass";
      this.filter.frequency.value = 1150;
      this.noise.connect(this.filter).connect(this.master);
      this.tone = this.ctx.createOscillator();
      this.tone.type = "sine";
      this.tone.frequency.value = 180;
      this.tone.connect(this.master);
      this.noise.start();
      this.tone.start();
      this.started = true;
    } catch {
      this.ctx = null;
    }
  }
  setProfile(theme: ThemeId, volume: number) {
    this.profile = theme;
    this.maxGain = Math.min(.12, Math.max(.01, volume));
    if (!this.filter || !this.tone) return;
    const wet = ["rainy", "rainycity", "thunderstorm", "latenightstudy", "midnight", "neoncity", "retrovhs", "arcade"].includes(theme) ? 850 : ["forest", "aurora"].includes(theme) ? 520 : 1150;
    const tone = theme === "arcade" ? 240 : theme === "cafe" ? 135 : theme === "forest" ? 115 : 180;
    this.filter.frequency.setTargetAtTime(wet, this.filter.context.currentTime, .15);
    this.tone.frequency.setTargetAtTime(tone, this.tone.context.currentTime, .25);
  }
  fadeIn() {
    this.resume();
    if (!this.master || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(now);
    this.master.gain.setTargetAtTime(this.maxGain, now, .75);
  }
  fadeOut() {
    if (!this.master || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(now);
    this.master.gain.setTargetAtTime(0, now, .5);
  }
}
