import { AnimatePresence, motion } from "motion/react";
import { Check, Palette, X } from "lucide-react";
import { Theme, THEMES, ThemeId } from "../themes";

export function ThemePicker({
  value,
  onChange,
  onClose,
}: {
  value: ThemeId;
  onChange: (theme: ThemeId) => void;
  onClose: () => void;
}) {
  return (
    <div className="absolute inset-0 z-[95] flex items-end" style={{ background: "rgba(12,8,25,0.34)" }}>
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 28, stiffness: 310 }}
        className="w-full rounded-t-[32px] px-5 pt-4 pb-6"
        style={{
          background: "var(--glass-strong)",
          backdropFilter: "blur(24px)",
          borderTop: "1px solid var(--border)",
          boxShadow: "0 -20px 50px var(--shadow)",
        }}
      >
        <div className="mx-auto mb-4 h-1.5 w-12 rounded-full" style={{ background: "var(--muted)" }} />
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <Palette size={17} color="var(--primary)" />
              <h2 style={{ color: "var(--text)", fontSize: 18, fontWeight: 800 }}>Choose your vibe</h2>
            </div>
            <p style={{ color: "var(--muted-text)", fontSize: 11, marginTop: 2 }}>Themes change the whole cloud, not just the wallpaper.</p>
          </div>
          <button onClick={onClose} aria-label="Close themes" className="grid place-items-center h-9 w-9 rounded-full" style={{ background: "var(--glass)", border: "1px solid var(--border)" }}>
            <X size={16} color="var(--muted-text)" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 max-h-[58vh] overflow-y-auto pr-1" style={{ scrollbarWidth: "none" }}>
          <AnimatePresence initial={false}>
            {THEMES.map((theme) => (
              <ThemeTile key={theme.id} theme={theme} selected={theme.id === value} onSelect={onChange} />
            ))}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}

function ThemeTile({ theme, selected, onSelect }: { theme: Theme; selected: boolean; onSelect: (id: ThemeId) => void }) {
  return (
    <motion.button
      whileTap={{ scale: 0.96 }}
      onClick={() => onSelect(theme.id)}
      className="text-left overflow-hidden rounded-[22px]"
      style={{
        background: "var(--glass)",
        border: selected ? "2px solid var(--primary)" : "1px solid var(--border)",
        boxShadow: selected ? "0 8px 22px color-mix(in srgb, var(--primary) 22%, transparent)" : "0 5px 16px var(--shadow)",
        padding: 0,
      }}
    >
      <div className="h-24 p-3 relative overflow-hidden" style={{ background: theme.sky }}>
        <div className="text-2xl">{theme.icon}</div>
        <div className="absolute -right-5 -bottom-6 h-20 w-20 rounded-full" style={{ background: "rgba(255,255,255,0.32)" }} />
        {theme.effects === "rain" && <div className="absolute inset-0 opacity-40" style={{ backgroundImage: "repeating-linear-gradient(105deg, transparent 0 10px, rgba(200,230,255,.25) 11px 12px)" }} />}
        {theme.effects === "rainbow" && <div className="absolute left-2 right-2 bottom-2 h-2 rounded-full" style={{ background: "linear-gradient(90deg,#ff7aa8,#ffd166,#5fe1a9,#64c8ff,#ab88ff)", opacity: 0.85 }} />}
      </div>
      <div className="p-3">
        <div className="flex items-center justify-between gap-2">
          <span style={{ color: "var(--text)", fontSize: 13, fontWeight: 800 }}>{theme.name}</span>
          {selected && <span className="grid place-items-center h-5 w-5 rounded-full" style={{ background: "var(--primary)" }}><Check size={12} color="white" strokeWidth={3} /></span>}
        </div>
        <p style={{ color: "var(--muted-text)", fontSize: 10, lineHeight: 1.35, marginTop: 3 }}>{theme.description}</p>
      </div>
    </motion.button>
  );
}
