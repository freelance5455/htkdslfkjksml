
import { AnimatePresence, motion } from "motion/react";
import { Heart, ListMusic, Mic2, Pause, Play, Repeat2, Shuffle, SkipBack, SkipForward, X, Share2, Volume2, Loader2, AlertCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { useMusic } from "../MusicContext";
import { getLyrics, type MusicLyrics } from "../musicApi";

export function NowPlayingSheet({ onClose }: { onClose: () => void }) {
  const { current, isPlaying, currentTime, duration, volume, muted, loading, recommendationsLoading, error, togglePlay, next, previous, seek, setVolume, toggleMute, queue, upNext, addToQueue } = useMusic();
  const [liked, setLiked] = useState(false);
  const [lyricsOpen, setLyricsOpen] = useState(false);
  const [lyrics, setLyrics] = useState<MusicLyrics | null>(null);
  const [lyricsLoading, setLyricsLoading] = useState(false);
  const track = current;
  const total = duration || track?.duration || 1;

  useEffect(() => {
    setLiked(current ? localStorage.getItem(`hearify-liked-${current.videoId}`) === "1" : false);
  }, [current?.videoId]);

  useEffect(() => {
    let cancelled = false;
    setLyrics(null);
    setLyricsOpen(false);
    if (!current?.videoId) return;
    setLyricsLoading(true);
    void getLyrics(current.videoId).then((result) => {
      if (!cancelled) setLyrics(result);
    }).finally(() => { if (!cancelled) setLyricsLoading(false); });
    return () => { cancelled = true; };
  }, [current?.videoId]);

  function toggleLike() {
    const nextValue = !liked;
    setLiked(nextValue);
    localStorage.setItem(`hearify-liked-${track!.videoId}`, nextValue ? "1" : "0");
  }

  const format = (n: number) => `${Math.floor(n / 60)}:${String(Math.max(0, Math.floor(n % 60))).padStart(2, "0")}`;

  return (
    <div className="absolute inset-0 z-[90] flex flex-col" style={{ background: "color-mix(in srgb, var(--sky) 72%, var(--glass-strong))", backdropFilter: "blur(26px)" }}>
      <div className="flex items-center justify-between px-5 pt-12 pb-4">
        <button onClick={onClose} aria-label="Close player" style={{ width: 38, height: 38, borderRadius: 19, background: "var(--glass)", border: "1px solid var(--border)", display: "grid", placeItems: "center" }}><X size={17} color="var(--muted-text)" /></button>
        <div className="text-center"><p style={{ fontSize: 10, color: "var(--muted-text)", fontWeight: 800, textTransform: "uppercase" }}>Now playing</p><p style={{ fontSize: 12, color: "var(--text)", fontWeight: 800 }}>Hearify player</p></div>
        <button aria-label="Share" style={{ width: 38, height: 38, borderRadius: 19, background: "var(--glass)", border: "1px solid var(--border)", display: "grid", placeItems: "center" }}><Share2 size={16} color="var(--muted-text)" /></button>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6" style={{ scrollbarWidth: "none" }}>
        {!track ? (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} style={{ minHeight: "100%", display: "grid", placeItems: "center", textAlign: "center", padding: 24 }}>
            <div>
              <div style={{ width: 104, height: 104, margin: "0 auto 18px", borderRadius: 30, display: "grid", placeItems: "center", background: "linear-gradient(135deg,color-mix(in srgb,var(--primary) 20%,white),color-mix(in srgb,var(--accent) 16%,white))", fontSize: 44 }}>🎧</div>
              <h2 style={{ fontSize: 22, fontFamily: "Pacifico", color: "var(--text)" }}>Pick a song</h2>
              <p style={{ marginTop: 6, fontSize: 12, color: "var(--muted-text)", lineHeight: 1.5 }}>Search the catalog or tap a song anywhere in Hearify to start listening.</p>
              <button onClick={onClose} style={{ marginTop: 18, padding: "10px 16px", borderRadius: 14, border: "1px solid var(--border)", background: "var(--glass)", color: "var(--primary)", fontSize: 11, fontWeight: 900 }}>Back to Hearify</button>
            </div>
          </motion.div>
        ) : (
        <>
        <motion.div animate={{ rotate: isPlaying ? 360 : 0 }} transition={{ duration: 16, repeat: Infinity, ease: "linear" }} className="mx-auto mt-8" style={{ width: 250, height: 250, borderRadius: 34, overflow: "hidden", background: "var(--glass)", boxShadow: "0 24px 60px var(--shadow), 0 0 0 12px var(--glass)", display: "grid", placeItems: "center" }}>
          {track!.thumbnail ? <img src={track!.thumbnail} alt="" style={{ width:"100%", height:"100%", objectFit:"cover" }} /> : <div style={{ width:"100%", height:"100%", display:"grid", placeItems:"center", fontSize:90, background:"linear-gradient(135deg,color-mix(in srgb,var(--primary) 30%,white),color-mix(in srgb,var(--pink) 26%,white))" }}>🎵</div>}
        </motion.div>

        <div className="text-center mt-8"><h2 style={{ fontSize: 26, fontFamily: "Pacifico", color: "var(--text)", lineHeight: 1.2 }}>{track!.title}</h2><p style={{ marginTop: 4, fontSize: 14, color: "var(--muted-text)", fontWeight: 700 }}>{track!.artist}</p>{track!.album && <p style={{ marginTop: 2, fontSize: 10, color: "var(--muted-text)" }}>{track!.album}</p>}</div>

        {error && <div className="flex items-center gap-2 mt-5" style={{padding:10,borderRadius:14,background:"color-mix(in srgb,#ef4444 8%,var(--glass))",border:"1px solid color-mix(in srgb,#ef4444 16%,transparent)"}}><AlertCircle size={14} color="#ef4444"/><p style={{fontSize:9,color:"var(--muted-text)",lineHeight:1.4}}>{error}</p></div>}

        <div className="mt-7">
          <input aria-label="Seek" type="range" min={0} max={Math.max(total,1)} step={0.1} value={Math.min(currentTime,total)} onChange={(e)=>seek(Number(e.target.value))} style={{width:"100%",accentColor:"var(--primary)"}}/>
          <div className="flex justify-between mt-2"><span style={{ fontSize: 10, color: "var(--muted-text)" }}>{format(currentTime)}</span><span style={{ fontSize: 10, color: "var(--muted-text)" }}>{format(total)}</span></div>
        </div>

        <div className="flex justify-center items-center gap-7 mt-4">
          <button aria-label="Shuffle"><Shuffle size={17} color="var(--muted-text)" /></button>
          <button onClick={previous} aria-label="Previous"><SkipBack size={24} color="var(--text)" fill="var(--text)" /></button>
          <motion.button whileTap={{ scale: .88 }} onClick={togglePlay} aria-label={isPlaying ? "Pause" : "Play"} style={{ width: 68, height: 68, borderRadius: 34, background: "linear-gradient(135deg,var(--primary),var(--accent))", display: "grid", placeItems: "center", boxShadow: "0 12px 30px color-mix(in srgb,var(--primary) 40%,transparent)" }}>
            {loading ? <Loader2 size={25} color="white" className="animate-spin" /> : isPlaying ? <Pause size={27} color="white" fill="white" /> : <Play size={27} color="white" fill="white" />}
          </motion.button>
          <button onClick={next} aria-label="Next"><SkipForward size={24} color="var(--text)" fill="var(--text)" /></button>
          <button aria-label="Repeat"><Repeat2 size={17} color="var(--muted-text)" /></button>
        </div>

        <div className="flex items-center gap-3 mt-7">
          <button onClick={toggleLike} aria-label="Like song" style={{ width: 42, height: 42, borderRadius: 14, background: "var(--glass)", border: "1px solid var(--border)", display: "grid", placeItems: "center" }}><Heart size={17} color={liked ? "var(--pink)" : "var(--muted-text)"} fill={liked ? "var(--pink)" : "none"} /></button>
          <button onClick={() => upNext[0] && addToQueue(upNext[0])} style={{ flex: 1, height: 42, borderRadius: 14, background: "var(--glass)", border: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "center", gap: 7 }}><ListMusic size={16} color="var(--muted-text)"/><span style={{ fontSize: 12, fontWeight: 800, color: "var(--muted-text)" }}>Up next · {upNext.length}</span></button>
        </div>

        <div style={{ marginTop: 12, padding: 14, borderRadius: 18, background: "var(--glass)", border: "1px solid var(--border)" }}>
          <div className="flex items-center gap-2"><Volume2 size={15} color="var(--primary)"/><span style={{ fontSize: 11, color: "var(--muted-text)", fontWeight: 800 }}>Volume</span><button onClick={toggleMute} style={{marginLeft:"auto",fontSize:9,fontWeight:900,color:"var(--primary)",border:"none",background:"none"}}>{muted ? "MUTED" : "ON"}</button></div>
          <input aria-label="Volume" type="range" min="0" max="1" step="0.01" value={muted ? 0 : volume} onChange={(e)=>setVolume(Number(e.target.value))} style={{width:"100%",marginTop:8,accentColor:"var(--primary)"}}/>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-4">
          <button onClick={() => setLyricsOpen(true)} style={{ height: 44, borderRadius: 15, background: "var(--glass)", border: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}><Mic2 size={15} color="var(--muted-text)"/><span style={{ fontSize: 11, fontWeight: 800, color: "var(--muted-text)" }}>{lyricsLoading ? "Loading lyrics…" : "Lyrics"}</span></button>
          <button onClick={() => void next()} style={{ height: 44, borderRadius: 15, background: "var(--glass)", border: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}><span style={{ fontSize: 15 }}>✨</span><span style={{ fontSize: 11, fontWeight: 800, color: "var(--muted-text)" }}>Song radio</span></button>
        </div>

        <AnimatePresence>
          {upNext.length > 0 && <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.18 }} style={{ marginTop: 14, padding: 14, borderRadius: 18, background: "var(--glass)", border: "1px solid var(--border)" }}>
            <div className="flex items-center justify-between"><p style={{fontSize:10,fontWeight:900,color:"var(--muted-text)",textTransform:"uppercase"}}>Up next</p><span style={{fontSize:8,color:"var(--muted-text)"}}>{queue.length ? `${queue.length} queued · ` : ""}{recommendationsLoading ? "building mix…" : "autoplay ready"}</span></div>
            <div className="mt-2 space-y-2">{upNext.slice(0,6).map((item,index)=><div key={`${item.videoId}-${index}`} className="flex items-center gap-2"><span style={{fontSize:9,color:"var(--muted-text)",width:14}}>{index+1}</span><div className="flex-1 min-w-0"><p style={{fontSize:10,fontWeight:800,color:"var(--text)",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{item.title}</p><p style={{fontSize:8,color:"var(--muted-text)"}}>{item.artist}</p></div><button onClick={() => addToQueue(item)} aria-label={`Keep ${item.title} in queue`} style={{border:"none",background:"transparent",color:"var(--primary)",fontSize:12}}>＋</button></div>)}</div>
          </motion.div>}
        </AnimatePresence>
        </>
        )}
      </div>

      <AnimatePresence>
        {lyricsOpen && (
          <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 28, stiffness: 300 }} className="absolute inset-x-0 bottom-0 z-[110]" style={{ maxHeight: "78%", background: "color-mix(in srgb,var(--sky) 92%,var(--glass-strong))", backdropFilter: "blur(24px)", borderTop: "1px solid var(--border)", borderRadius: "28px 28px 0 0", boxShadow: "0 -20px 60px var(--shadow)" }}>
            <div className="flex items-center justify-between px-5 py-4"><div><p style={{fontSize:9,fontWeight:900,color:"var(--muted-text)",textTransform:"uppercase"}}>Lyrics</p><p style={{fontSize:14,fontWeight:900,color:"var(--text)"}}>{track.title}</p></div><button onClick={() => setLyricsOpen(false)} aria-label="Close lyrics" style={{width:36,height:36,borderRadius:18,background:"var(--glass)",border:"1px solid var(--border)",display:"grid",placeItems:"center"}}><X size={16} color="var(--muted-text)"/></button></div>
            <div className="overflow-y-auto px-5 pb-6" style={{maxHeight:"calc(78vh - 82px)",scrollbarWidth:"none"}}>
              {!lyrics && !lyricsLoading && <div style={{padding:"28px 12px",textAlign:"center"}}><div style={{fontSize:30}}>🎤</div><p style={{fontSize:12,fontWeight:900,color:"var(--text)",marginTop:8}}>Lyrics unavailable</p><p style={{fontSize:10,color:"var(--muted-text)",marginTop:4}}>This song does not currently expose lyrics through the music service.</p></div>}
              {lyricsLoading && <div style={{padding:30,textAlign:"center",fontSize:10,color:"var(--muted-text)"}}>Finding lyrics…</div>}
              {lyrics && typeof lyrics.lyrics === "string" && <p style={{whiteSpace:"pre-line",fontSize:13,lineHeight:1.8,color:"var(--text)",fontWeight:700}}>{lyrics.lyrics}</p>}
              {lyrics && Array.isArray(lyrics.lyrics) && <div className="space-y-3">{lyrics.lyrics.map((line,index)=><p key={`${index}-${line.startTime ?? 0}`} style={{fontSize:14,lineHeight:1.55,color:"var(--text)",fontWeight:700}}>{line.text}</p>)}</div>}
              {lyrics?.source && <p style={{fontSize:8,color:"var(--muted-text)",marginTop:16}}>Source: {lyrics.source}</p>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
