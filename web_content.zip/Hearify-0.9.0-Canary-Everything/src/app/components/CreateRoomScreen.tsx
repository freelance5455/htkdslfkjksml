import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Users, Lock, Globe, Plus } from "lucide-react";

const moods = [
  { emoji: "🌅", label: "Chill" },
  { emoji: "🔥", label: "Hype" },
  { emoji: "🌙", label: "Night" },
  { emoji: "☁️", label: "Dreamy" },
  { emoji: "🎉", label: "Party" },
  { emoji: "🌿", label: "Indie" },
];

const icons = ["🎵", "☁️", "🌸", "⭐", "🌙", "🎸", "🌊", "🦋"];

const friends = [
  { name: "Maya", emoji: "🌸" },
  { name: "Jae", emoji: "⚡" },
  { name: "Sofia", emoji: "☁️" },
  { name: "Noah", emoji: "🎸" },
  { name: "Ava", emoji: "💛" },
  { name: "Leo", emoji: "🌊" },
];

export function CreateRoomScreen({ onBack, onCreated }: { onBack: () => void; onCreated: () => void }) {
  const [roomType, setRoomType] = useState<"public" | "private">("public");
  const [roomName, setRoomName] = useState("");
  const [selectedMood, setSelectedMood] = useState("Chill");
  const [selectedIcon, setSelectedIcon] = useState("🎵");
  const [invitedFriends, setInvitedFriends] = useState<string[]>([]);
  const [created, setCreated] = useState(false);

  function toggleFriend(name: string) {
    setInvitedFriends((prev) =>
      prev.includes(name) ? prev.filter((f) => f !== name) : [...prev, name]
    );
  }

  function handleCreate() {
    setCreated(true);
    setTimeout(() => onCreated(), 1800);
  }

  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ fontFamily: "Nunito" }}>
      {/* Header */}
      <div className="flex items-center gap-3 px-5 pt-12 pb-4">
        <motion.button whileTap={{ scale: 0.9 }} onClick={onBack}>
          <ChevronLeft size={22} color="var(--muted-text)" />
        </motion.button>
        <h1 style={{ fontSize: 20, fontFamily: "Pacifico", color: "var(--text)" }}>Create a Cloud</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-5" style={{ scrollbarWidth: "none" }}>
        {/* Room type */}
        <div
          style={{
            background: "var(--glass)",
            backdropFilter: "blur(12px)",
            borderRadius: 22,
            border: "1.5px solid var(--glass-strong)",
            boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
            padding: 4,
            display: "flex",
            gap: 4,
          }}
        >
          {[
            { type: "public" as const, label: "Public Room", icon: Globe },
            { type: "private" as const, label: "Private Room", icon: Lock },
          ].map(({ type, label, icon: Icon }) => (
            <motion.button
              key={type}
              whileTap={{ scale: 0.97 }}
              onClick={() => setRoomType(type)}
              style={{
                flex: 1,
                height: 48,
                borderRadius: 18,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                background: roomType === type
                  ? "linear-gradient(135deg, var(--primary), var(--accent))"
                  : "transparent",
                border: "none",
                transition: "all 0.25s",
                boxShadow: roomType === type ? "0 4px 14px color-mix(in srgb, var(--primary) 40%, transparent)" : "none",
              }}
            >
              <Icon size={16} color={roomType === type ? "white" : "var(--muted-text)"} />
              <span style={{ fontSize: 13, fontWeight: 700, color: roomType === type ? "white" : "var(--muted-text)" }}>
                {label}
              </span>
            </motion.button>
          ))}
        </div>

        {/* Room name */}
        <div
          style={{
            background: "var(--glass)",
            backdropFilter: "blur(12px)",
            borderRadius: 22,
            border: "1.5px solid var(--glass-strong)",
            boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
            padding: 18,
          }}
        >
          <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 10 }}>
            Room Name
          </p>
          <input
            value={roomName}
            onChange={(e) => setRoomName(e.target.value)}
            placeholder="Name your cloud..."
            style={{
              width: "100%",
              background: "rgba(245,230,255,0.5)",
              border: "1.5px solid color-mix(in srgb, var(--primary) 20%, transparent)",
              borderRadius: 14,
              padding: "12px 14px",
              fontSize: 15,
              fontFamily: "Nunito",
              fontWeight: 700,
              color: "var(--text)",
              outline: "none",
            }}
          />
        </div>

        {/* Icon picker */}
        <div
          style={{
            background: "var(--glass)",
            backdropFilter: "blur(12px)",
            borderRadius: 22,
            border: "1.5px solid var(--glass-strong)",
            boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
            padding: 18,
          }}
        >
          <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 12 }}>
            Room Icon
          </p>
          <div className="flex gap-3 flex-wrap">
            {icons.map((icon) => (
              <motion.button
                key={icon}
                whileTap={{ scale: 1.2 }}
                onClick={() => setSelectedIcon(icon)}
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 14,
                  fontSize: 24,
                  background: selectedIcon === icon
                    ? "linear-gradient(135deg, #fde68a, #fbcfe8)"
                    : "rgba(245,230,255,0.5)",
                  border: selectedIcon === icon ? "2px solid var(--primary)" : "1.5px solid transparent",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: selectedIcon === icon ? "0 4px 12px color-mix(in srgb, var(--primary) 30%, transparent)" : "none",
                  transition: "all 0.2s",
                }}
              >
                {icon}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Mood picker */}
        <div
          style={{
            background: "var(--glass)",
            backdropFilter: "blur(12px)",
            borderRadius: 22,
            border: "1.5px solid var(--glass-strong)",
            boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
            padding: 18,
          }}
        >
          <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 12 }}>
            Room Mood
          </p>
          <div className="grid grid-cols-3 gap-2">
            {moods.map((mood) => (
              <motion.button
                key={mood.label}
                whileTap={{ scale: 0.93 }}
                onClick={() => setSelectedMood(mood.label)}
                style={{
                  height: 52,
                  borderRadius: 16,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 2,
                  background: selectedMood === mood.label
                    ? "linear-gradient(135deg, var(--primary)22, var(--accent)22)"
                    : "rgba(245,230,255,0.4)",
                  border: selectedMood === mood.label ? "1.5px solid var(--primary)" : "1.5px solid transparent",
                  transition: "all 0.2s",
                }}
              >
                <span style={{ fontSize: 20 }}>{mood.emoji}</span>
                <span style={{ fontSize: 10, fontWeight: 700, color: selectedMood === mood.label ? "var(--primary)" : "var(--muted-text)" }}>
                  {mood.label}
                </span>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Invite friends */}
        <div
          style={{
            background: "var(--glass)",
            backdropFilter: "blur(12px)",
            borderRadius: 22,
            border: "1.5px solid var(--glass-strong)",
            boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
            padding: 18,
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <p style={{ fontSize: 12, color: "var(--muted-text)", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>
              Invite Friends
            </p>
            <div className="flex items-center gap-1">
              <Users size={13} color="var(--primary)" />
              <span style={{ fontSize: 12, color: "var(--primary)", fontWeight: 700 }}>
                {invitedFriends.length} selected
              </span>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {friends.map((friend) => {
              const invited = invitedFriends.includes(friend.name);
              return (
                <motion.button
                  key={friend.name}
                  whileTap={{ scale: 0.93 }}
                  onClick={() => toggleFriend(friend.name)}
                  style={{
                    borderRadius: 16,
                    padding: "10px 6px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: 4,
                    background: invited ? "linear-gradient(135deg, #fde68a44, #fbcfe844)" : "rgba(245,230,255,0.4)",
                    border: invited ? "1.5px solid var(--pink)" : "1.5px solid transparent",
                    transition: "all 0.2s",
                  }}
                >
                  <div style={{ position: "relative" }}>
                    <div
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 20,
                        background: "linear-gradient(135deg, #fde68a, #fbcfe8)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 20,
                        border: invited ? "2px solid var(--pink)" : "2px solid transparent",
                      }}
                    >
                      {friend.emoji}
                    </div>
                    {invited && (
                      <div
                        style={{
                          position: "absolute",
                          bottom: -2,
                          right: -2,
                          width: 16,
                          height: 16,
                          borderRadius: 8,
                          background: "var(--pink)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          border: "1.5px solid white",
                          fontSize: 9,
                          color: "white",
                          fontWeight: 800,
                        }}
                      >
                        ✓
                      </div>
                    )}
                  </div>
                  <span style={{ fontSize: 11, fontWeight: 700, color: invited ? "var(--text)" : "var(--muted-text)" }}>
                    {friend.name}
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Create button */}
        <motion.button
          whileTap={{ scale: 0.96 }}
          onClick={handleCreate}
          style={{
            width: "100%",
            height: 58,
            borderRadius: 22,
            background: "linear-gradient(135deg, #fde68a, #fbcfe8, var(--primary))",
            border: "none",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            boxShadow: "0 8px 28px color-mix(in srgb, var(--primary) 40%, transparent)",
            cursor: "pointer",
          }}
        >
          <AnimatePresence mode="wait">
            {created ? (
              <motion.span
                key="done"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                style={{ fontSize: 20 }}
              >
                ☁️ Room Created!
              </motion.span>
            ) : (
              <motion.span
                key="create"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                style={{ fontSize: 16, fontWeight: 800, color: "white", fontFamily: "Nunito", display: "flex", alignItems: "center", gap: 8 }}
              >
                <Plus size={18} color="white" />
                Create My Cloud Room
              </motion.span>
            )}
          </AnimatePresence>
        </motion.button>

        {/* Decorative clouds */}
        <div className="flex justify-center gap-6 py-2">
          {["☁️", "🎵", "☁️"].map((e, i) => (
            <motion.span
              key={i}
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 3 + i, repeat: Infinity, ease: "easeInOut", delay: i * 0.5 }}
              style={{ fontSize: 22, opacity: 0.6 }}
            >
              {e}
            </motion.span>
          ))}
        </div>
      </div>
    </div>
  );
}
