import { motion } from "motion/react";
import { Download, HardDrive, MoreHorizontal, Play, Trash2, WifiOff } from "lucide-react";
import { LOCAL_CATALOG } from "../musicCatalog";
import { useMusic } from "../MusicContext";

const downloaded = LOCAL_CATALOG.slice(0, 6).map((track) => ({ ...track, mood: "Downloaded" }));


export function OfflineScreen({ onPlay }: { onPlay: () => void }) {
  const { playTrack } = useMusic();
  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ fontFamily: "Nunito" }}>
      <div className="px-5 pt-12 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <p style={{ fontSize: 11, color: "var(--muted-text)", fontWeight: 800, textTransform: "uppercase", letterSpacing: .6 }}>No signal? No problem.</p>
            <h1 style={{ fontSize: 24, color: "var(--text)", fontFamily: "Pacifico", lineHeight: 1.15 }}>Offline Library</h1>
          </div>
          <div style={{ width: 42, height: 42, borderRadius: 15, display: "grid", placeItems: "center", background: "var(--glass)", border: "1px solid var(--border)" }}>
            <WifiOff size={18} color="var(--primary)" />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6" style={{ scrollbarWidth: "none" }}>
        <div style={{ padding: 14, borderRadius: 20, background: "color-mix(in srgb, var(--primary) 8%, var(--glass))", border: "1px solid color-mix(in srgb, var(--primary) 15%, transparent)", marginBottom: 14 }}>
          <div className="flex items-center gap-3">
            <div style={{ width: 40, height: 40, borderRadius: 13, background: "linear-gradient(135deg, var(--primary), var(--accent))", display: "grid", placeItems: "center" }}>
              <HardDrive size={18} color="white" />
            </div>
            <div className="flex-1">
              <p style={{ fontSize: 13, fontWeight: 900, color: "var(--text)" }}>Downloaded songs</p>
              <p style={{ fontSize: 10, color: "var(--muted-text)", marginTop: 2 }}>5 songs · 18.6 MB · prototype storage</p>
            </div>
            <span style={{ fontSize: 10, fontWeight: 900, color: "var(--success)" }}>READY</span>
          </div>
        </div>

        <div className="space-y-2.5">
          {downloaded.map((track, index) => (
            <motion.button
              key={track.title}
              whileHover={{ y: -1 }}
              whileTap={{ scale: .98 }}
              onClick={() => { void playTrack(track); onPlay(); }}
              className="w-full text-left"
              style={{ padding: 12, borderRadius: 18, background: "var(--glass)", border: "1px solid var(--border)", backdropFilter: "blur(14px)" }}
            >
              <div className="flex items-center gap-3">
                <div style={{ width: 48, height: 48, borderRadius: 14, background: track.thumbnail ? `url(${track.thumbnail}) center/cover` : "var(--glass-strong)", display: "grid", placeItems: "center", flexShrink: 0, boxShadow: "0 5px 15px rgba(0,0,0,.07)" }}>
                  <span style={{ fontSize: 19 }}>🎵</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p style={{ fontSize: 13, fontWeight: 900, color: "var(--text)" }}>{track.title}</p>
                  <p style={{ fontSize: 10, color: "var(--muted-text)", marginTop: 2 }}>{track.artist} · {track.mood}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <div className="flex-1 h-1 rounded-full" style={{ background: "color-mix(in srgb, var(--primary) 14%, transparent)" }}>
                      <div style={{ width: "100%", height: "100%", borderRadius: 4, background: "linear-gradient(90deg, var(--primary), var(--accent))" }} />
                    </div>
                    <span style={{ fontSize: 9, color: "var(--muted-text)" }}>{track.durationText || "Cached track"}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <span style={{ width: 30, height: 30, borderRadius: 15, background: "color-mix(in srgb, var(--primary) 11%, transparent)", display: "grid", placeItems: "center" }}><Play size={13} fill="var(--primary)" color="var(--primary)" /></span>
                  {index === 0 ? <Download size={15} color="var(--success)" /> : <MoreHorizontal size={16} color="var(--muted-text)" />}
                </div>
              </div>
            </motion.button>
          ))}
        </div>

        <div style={{ marginTop: 16, padding: 14, borderRadius: 18, background: "var(--glass)", border: "1px dashed var(--border)" }}>
          <div className="flex items-center gap-3">
            <Trash2 size={17} color="var(--pink)" />
            <div className="flex-1"><p style={{ fontSize: 11, fontWeight: 900, color: "var(--text)" }}>Storage controls</p><p style={{ fontSize: 10, color: "var(--muted-text)", marginTop: 2 }}>Offline is a prototype cache; online tracks can be replayed through the connected catalog player.</p></div>
          </div>
        </div>
      </div>
    </div>
  );
}
