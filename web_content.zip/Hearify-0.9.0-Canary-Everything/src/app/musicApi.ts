import { LOCAL_CATALOG, LOCAL_SEARCH_HINTS } from './musicCatalog';

export type MusicTrack = {
  videoId: string;
  title: string;
  artist: string;
  album?: string;
  thumbnail?: string;
  duration?: number;
  durationText?: string;
  streamUrl?: string;
  source?: 'ytmusic' | 'youtube';
};

const DEFAULT_API = 'https://hearify-w782.onrender.com';

// IMPORTANT: Vite env values are baked in at build time. For Netlify, using the
// deployed bridge directly is more reliable than depending on a redirect/proxy.
// Set VITE_YTMUSIC_API_URL=/api to deliberately use the Netlify proxy instead.
export const API_BASE = String(
  import.meta.env.VITE_YTMUSIC_API_URL || DEFAULT_API
).replace(/\/$/, '');

const REQUEST_TIMEOUT_MS = 15_000;

function dedupeTracks(tracks: MusicTrack[], blocked: Set<string> = new Set()) {
  const seen = new Set(blocked);
  return tracks.filter((track) => {
    if (!track?.videoId || seen.has(track.videoId)) return false;
    seen.add(track.videoId);
    return true;
  });
}

const normalize = (raw: any): MusicTrack | null => {
  if (!raw?.videoId || !raw?.title) return null;
  const artists = Array.isArray(raw.artists)
    ? raw.artists.map((a: any) => a?.name).filter(Boolean).join(', ')
    : (raw.artist || '');
  const seconds = typeof raw.duration_seconds === 'number'
    ? raw.duration_seconds
    : (typeof raw.duration === 'number' ? raw.duration : undefined);
  return {
    videoId: String(raw.videoId),
    title: String(raw.title),
    artist: artists || 'Unknown artist',
    album: raw.album?.name || raw.album || undefined,
    thumbnail: raw.thumbnail || raw.thumbnails?.[0]?.url || undefined,
    duration: seconds,
    durationText: typeof raw.duration === 'string'
      ? raw.duration
      : (raw.duration_text || (seconds ? `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}` : undefined)),
    streamUrl: raw.streamUrl || undefined,
    source: 'ytmusic',
  };
};

function localSearch(query: string, limit: number): MusicTrack[] {
  const term = query.trim().toLowerCase();
  if (!term || LOCAL_SEARCH_HINTS.some((hint) => term.includes(hint))) return LOCAL_CATALOG.slice(0, limit);
  const matches = LOCAL_CATALOG.filter((track) => `${track.title} ${track.artist} ${track.album || ''}`.toLowerCase().includes(term));
  return (matches.length ? matches : LOCAL_CATALOG.slice(0, limit)).slice(0, limit);
}

async function fetchJson(path: string, signal?: AbortSignal): Promise<any> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  const onAbort = () => controller.abort();
  signal?.addEventListener('abort', onAbort, { once: true });

  try {
    const response = await fetch(`${API_BASE}${path}`, {
      headers: { Accept: 'application/json' },
      cache: 'no-store',
      signal: controller.signal,
    });

    if (!response.ok) {
      let detail = '';
      try {
        const body = await response.json();
        detail = typeof body?.detail === 'string' ? `: ${body.detail}` : '';
      } catch {
        // Keep the HTTP status as the useful error when the body is not JSON.
      }
      throw new Error(`Music API ${response.status}${detail}`);
    }

    return await response.json();
  } catch (error) {
    if (controller.signal.aborted && signal?.aborted) throw error;
    if (controller.signal.aborted) throw new Error('Music search timed out. Please try again.');
    throw error;
  } finally {
    window.clearTimeout(timer);
    signal?.removeEventListener('abort', onAbort);
  }
}

export async function searchMusic(query: string, limit = 12, signal?: AbortSignal): Promise<MusicTrack[]> {
  const trimmed = query.trim();
  if (!trimmed) return localSearch('', limit);

  const safeLimit = Math.max(1, Math.min(50, limit));
  const endpointQuery = encodeURIComponent(trimmed);

  // One live source of truth: the Hearify bridge. We intentionally do not
  // silently replace failed live results with the starter catalog, because that
  // made the UI look as if search was working while returning unrelated songs.
  const data = await fetchJson(`/search?q=${endpointQuery}&limit=${safeLimit}`, signal);
  const rawTracks = Array.isArray(data?.tracks)
    ? data.tracks
    : Array.isArray(data?.results)
      ? data.results
      : [];

  const tracks = rawTracks
    .map(normalize)
    .filter(Boolean) as MusicTrack[];

  if (!tracks.length) throw new Error('No songs returned by the music API');
  return tracks.slice(0, safeLimit);
}

const RANDOM_AUTOPLAY_SEEDS = [
  "popular songs",
  "new music",
  "pop songs",
  "rap songs",
  "rock songs",
  "indie songs",
  "r&b songs",
  "dance music",
  "electronic music",
  "greek songs",
  "alternative songs",
  "chill music",
];

export async function getSimilarMusic(videoId: string, limit = 15): Promise<MusicTrack[]> {
  const safeLimit = Math.max(1, Math.min(30, limit));

  // The bridge now ranks YTMusic's actual Related tab first. Keep this helper
  // intentionally thin so the frontend does not second-guess the provider's
  // recommendation order.
  try {
    const data = await fetchJson(`/radio/${encodeURIComponent(videoId)}?limit=${safeLimit}`);
    const rawTracks = Array.isArray(data?.tracks) ? data.tracks : [];
    const tracks = rawTracks
      .map(normalize)
      .filter(Boolean)
      .filter((track: MusicTrack | null) => track?.videoId !== videoId)
      .slice(0, safeLimit) as MusicTrack[];
    if (tracks.length) return tracks;
  } catch {
    // Fall through to a small catalogue fallback.
  }

  const seeds = RANDOM_AUTOPLAY_SEEDS
    .slice()
    .sort(() => Math.random() - 0.5)
    .slice(0, 3);
  const merged: MusicTrack[] = [];
  const seen = new Set<string>([videoId]);

  for (const seed of seeds) {
    try {
      const results = await searchMusic(seed, Math.max(12, safeLimit));
      for (const track of results) {
        if (!seen.has(track.videoId)) {
          seen.add(track.videoId);
          merged.push(track);
        }
      }
    } catch {
      // Try the next seed.
    }
    if (merged.length >= safeLimit) break;
  }

  return merged.sort(() => Math.random() - 0.5).slice(0, safeLimit);
}

export type LyricsLine = { text: string; startTime?: number; endTime?: number };
export type MusicLyrics = { lyrics: string | LyricsLine[]; source?: string; hasTimestamps?: boolean };

export async function getLyrics(videoId: string): Promise<MusicLyrics | null> {
  try {
    const data = await fetchJson(`/lyrics/${encodeURIComponent(videoId)}?timestamps=true`);
    if (!data?.lyrics) return null;
    return {
      lyrics: Array.isArray(data.lyrics)
        ? data.lyrics.map((line: any) => ({
            text: String(line?.text || ''),
            startTime: Number.isFinite(Number(line?.start_time)) ? Number(line.start_time) / 1000 : undefined,
            endTime: Number.isFinite(Number(line?.end_time)) ? Number(line.end_time) / 1000 : undefined,
          })).filter((line: LyricsLine) => line.text.trim())
        : String(data.lyrics),
      source: data.source ? String(data.source) : undefined,
      hasTimestamps: Boolean(data.hasTimestamps),
    };
  } catch {
    return null;
  }
}

export async function hydrateTrack(track: MusicTrack): Promise<MusicTrack> {
  if (track.source !== 'ytmusic' || track.streamUrl) return track;
  try {
    const data = await fetchJson(`/song/${encodeURIComponent(track.videoId)}`);
    return {
      ...track,
      title: data?.title || track.title,
      artist: data?.artist || track.artist,
      album: data?.album || track.album,
      thumbnail: data?.thumbnail || track.thumbnail,
      duration: data?.duration_seconds || track.duration,
      durationText: data?.duration_text || track.durationText,
      streamUrl: data?.streamUrl || undefined,
      source: 'ytmusic',
    };
  } catch {
    return track;
  }
}

export async function getMusicHealth(): Promise<{ ok: boolean; provider: string; version?: string }> {
  try {
    return await fetchJson('/health');
  } catch {
    return { ok: false, provider: 'YouTube Music' };
  }
}
