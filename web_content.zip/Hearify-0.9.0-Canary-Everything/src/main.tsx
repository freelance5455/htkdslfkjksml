import { createRoot } from "react-dom/client";
  import App from "./app/App.tsx";
  import { MusicProvider } from "./app/MusicContext";
  import "./styles/index.css";

  createRoot(document.getElementById("root")!).render(
    <MusicProvider><App /></MusicProvider>
  );

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    });
  }
