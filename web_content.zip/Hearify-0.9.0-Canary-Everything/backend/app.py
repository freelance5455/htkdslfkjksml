from __future__ import annotations

import os
import random
import time
from functools import lru_cache
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from ytmusicapi import YTMusic

app = FastAPI(title="Hearify YouTube Music Bridge", version="0.7.0")

allowed_origins = [origin.strip() for origin in os.getenv("HEARIFY_CORS_ORIGINS", "*").split(",") if origin.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins or ["*"],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)


@lru_cache(maxsize=1)
def client() -> YTMusic:
    return YTMusic()


def artist_names(raw: dict[str, Any]) -> str:
    artists = raw.get("artists") or []
    names = [str(a.get("name")) for a in artists if isinstance(a, dict) and a.get("name")]
    return ", ".join(names) or "Unknown artist"


def thumbnail_url(raw: dict[str, Any]) -> str | None:
    thumbs = raw.get("thumbnails") or raw.get("thumbnail") or []
    if isinstance(thumbs, list) and thumbs and isinstance(thumbs[-1], dict):
        return thumbs[-1].get("url")
    if isinstance(thumbs, dict):
        return thumbs.get("url")
    return raw.get("thumbnail") if isinstance(raw.get("thumbnail"), str) else None


def normalize_track(raw: dict[str, Any]) -> dict[str, Any] | None:
    video_id = raw.get("videoId")
    if not video_id:
        return None

    result_type = raw.get("resultType")
    video_type = str(raw.get("videoType") or "")
    title = raw.get("title")

    # Related results may omit resultType, while non-song recommendation sections
    # often have no videoId at all. Keep only clearly playable music/video items.
    if result_type not in (None, "song") and not video_type.startswith("MUSIC_VIDEO_TYPE"):
        return None
    if not title:
        return None

    album_raw = raw.get("album")
    if isinstance(album_raw, dict):
        album = album_raw.get("name")
    else:
        album = album_raw

    return {
        "videoId": str(video_id),
        "title": str(title),
        "artist": artist_names(raw),
        "album": str(album) if album else None,
        "thumbnail": thumbnail_url(raw),
        "duration": raw.get("duration"),
        "duration_seconds": raw.get("duration_seconds"),
        "source": "ytmusic",
    }


_signature_cache: tuple[int, float] | None = None


def current_signature_timestamp() -> int | None:
    global _signature_cache
    now = time.time()
    if _signature_cache and now - _signature_cache[1] < 1800:
        return _signature_cache[0]
    try:
        stamp = int(client().get_signatureTimestamp())
        _signature_cache = (stamp, now)
        return stamp
    except Exception:
        return None


def _section_title(section: dict[str, Any]) -> str:
    return str(section.get("title") or section.get("header") or "").strip().lower()


def _section_tracks(section: dict[str, Any], exclude: set[str]) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for item in section.get("contents") or []:
        if not isinstance(item, dict):
            continue
        track = normalize_track(item)
        if not track or track["videoId"] in exclude:
            continue
        found.append(track)
    return found


def _related_candidates(related: Any, video_id: str, limit: int) -> list[dict[str, Any]]:
    """Rank actual YT Music Related-tab songs for autoplay.

    Priority:
      1. You might also like
      2. Other song sections returned by get_song_related

    We intentionally ignore playlists, albums, artist cards and "Other
    performances" as primary recommendations. This keeps autoplay contextual
    instead of falling back to generic popularity.
    """
    if not isinstance(related, list):
        return []

    exclude = {video_id}
    primary: list[dict[str, Any]] = []
    secondary: list[dict[str, Any]] = []

    for section in related:
        if not isinstance(section, dict):
            continue
        title = _section_title(section)
        tracks = _section_tracks(section, exclude)
        if not tracks:
            continue

        if "you might also like" in title or "similar songs" in title or "recommended songs" in title:
            primary.extend(tracks)
        elif "other performances" not in title:
            secondary.extend(tracks)

    ordered: list[dict[str, Any]] = []
    seen: set[str] = {video_id}

    # First pass: walk the top recommendation section in provider order, which
    # is usually the strongest relevance signal.
    for track in primary:
        track_id = track["videoId"]
        if track_id in seen:
            continue
        seen.add(track_id)
        ordered.append(track)
        if len(ordered) >= limit:
            return ordered

    # Second pass: supplement from other genuine song sections.
    for track in secondary:
        track_id = track["videoId"]
        if track_id in seen:
            continue
        seen.add(track_id)
        ordered.append(track)
        if len(ordered) >= limit:
            break

    return ordered


RANDOM_SEARCH_SEEDS = [
    "popular songs",
    "new music",
    "pop songs",
    "rap songs",
    "rock songs",
    "indie songs",
    "r&b songs",
    "dance music",
    "electronic music",
    "greek songs",
    "alternative songs",
    "chill music",
]


def _random_fallback_tracks(exclude: set[str], needed: int) -> list[dict[str, Any]]:
    if needed <= 0:
        return []

    seeds = RANDOM_SEARCH_SEEDS[:]
    random.shuffle(seeds)
    candidates: list[dict[str, Any]] = []
    seen = set(exclude)

    for seed in seeds:
        try:
            results = client().search(seed, filter="songs", limit=min(20, max(8, needed)))
        except Exception:
            continue
        normalized = [track for item in results if (track := normalize_track(item))]
        random.shuffle(normalized)
        for track in normalized:
            track_id = track.get("videoId")
            if not track_id or track_id in seen:
                continue
            seen.add(track_id)
            candidates.append(track)
            if len(candidates) >= needed:
                return candidates

    return candidates


@app.get("/")
def root() -> dict[str, Any]:
    return {"status": "Hearify Music API is running", "app": "0.7.0"}


@app.get("/health")
def health() -> dict[str, Any]:
    try:
        client()
        return {"ok": True, "provider": "YouTube Music", "library": "ytmusicapi 1.12.2", "app": "0.7.0"}
    except Exception:
        return {"ok": False, "provider": "YouTube Music", "library": "ytmusicapi 1.12.2", "app": "0.7.0"}


@app.get("/search")
def search(q: str = Query(min_length=1, max_length=120), limit: int = Query(30, ge=1, le=50)) -> dict[str, Any]:
    try:
        results = client().search(q, filter="songs", limit=limit)
        tracks = [track for item in results if (track := normalize_track(item))]
        return {"tracks": tracks}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"YouTube Music search failed: {exc}") from exc


@app.get("/radio/{video_id}")
def radio(video_id: str, limit: int = Query(15, ge=1, le=30)) -> dict[str, Any]:
    if not video_id or len(video_id) > 32:
        raise HTTPException(status_code=400, detail="Invalid video id")

    unique: list[dict[str, Any]] = []
    seen = {video_id}
    strategy = "related"
    related_browse_id: str | None = None

    # This is the important change: get_song_related() is now the primary
    # source. We only use get_watch_playlist() to obtain the Related browse id.
    try:
        watch = client().get_watch_playlist(videoId=video_id, radio=False, limit=1)
        related_browse_id = watch.get("related") if isinstance(watch, dict) else None
        if related_browse_id:
            related = client().get_song_related(related_browse_id)
            related_tracks = _related_candidates(related, video_id, limit)
            for track in related_tracks:
                track_id = track.get("videoId")
                if not track_id or track_id in seen:
                    continue
                seen.add(track_id)
                unique.append(track)
                if len(unique) >= limit:
                    break
    except Exception:
        unique = []

    # Small resilience layer. We do not use watch.tracks as recommendations;
    # it was the source of the generic/unrelated autoplay behavior.
    if len(unique) < limit:
        try:
            watch_radio = client().get_watch_playlist(
                videoId=video_id,
                radio=True,
                limit=max(limit + 6, 20),
            )
            for item in watch_radio.get("tracks") or []:
                track = normalize_track(item) if isinstance(item, dict) else None
                if not track or track["videoId"] in seen:
                    continue
                seen.add(track["videoId"])
                unique.append(track)
                if len(unique) >= limit:
                    break
            if unique:
                strategy = "related+radio"
        except Exception:
            pass

    if len(unique) < limit:
        fallback = _random_fallback_tracks(seen, limit - len(unique))
        unique.extend(fallback)
        if fallback:
            strategy = "related+radio+random" if strategy == "related+radio" else "related+random"

    if not unique:
        raise HTTPException(status_code=502, detail="YouTube Music returned no autoplay tracks")

    # Only shuffle when we had to use a fallback. Pure Related results keep
    # provider relevance/order instead of turning a curated recommendation list
    # into noise.
    if "random" in strategy:
        random.shuffle(unique)

    return {
        "tracks": unique[:limit],
        "strategy": strategy,
        "relatedBrowseId": related_browse_id,
    }


# Debug endpoints retained for recommendation testing.
@app.get("/debug/related/{video_id}")
def debug_related(video_id: str) -> dict[str, Any]:
    try:
        watch = client().get_watch_playlist(videoId=video_id, radio=False, limit=1)
        related_id = watch.get("related") if isinstance(watch, dict) else None
        if not related_id:
            return {
                "videoId": video_id,
                "related": None,
                "message": "No related browse ID returned",
                "watch_keys": list(watch.keys()) if isinstance(watch, dict) else [],
            }
        related = client().get_song_related(related_id)
        return {"videoId": video_id, "relatedBrowseId": related_id, "watch": watch, "related": related}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Debug related failed: {exc}") from exc


@app.get("/debug/song-related/{browse_id}")
def debug_song_related(browse_id: str) -> dict[str, Any]:
    try:
        related = client().get_song_related(browse_id)
        return {"browseId": browse_id, "related": related}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Debug song-related failed: {exc}") from exc


@app.get("/lyrics/{video_id}")
def lyrics(video_id: str, timestamps: bool = True) -> dict[str, Any]:
    if not video_id or len(video_id) > 32:
        raise HTTPException(status_code=400, detail="Invalid video id")
    try:
        watch = client().get_watch_playlist(videoId=video_id, limit=1, radio=False)
        lyrics_browse_id = watch.get("lyrics") if isinstance(watch, dict) else None
        if not lyrics_browse_id:
            return {"lyrics": None, "source": None, "hasTimestamps": False}
        result = client().get_lyrics(lyrics_browse_id, timestamps=timestamps)
        if not result:
            return {"lyrics": None, "source": None, "hasTimestamps": False}
        if hasattr(result, "model_dump"):
            result = result.model_dump()
        elif hasattr(result, "dict"):
            result = result.dict()
        return {
            "lyrics": result.get("lyrics") if isinstance(result, dict) else None,
            "source": result.get("source") if isinstance(result, dict) else None,
            "hasTimestamps": bool(result.get("hasTimestamps")) if isinstance(result, dict) else False,
        }
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"YouTube Music lyrics failed: {exc}") from exc


@app.get("/song/{video_id}")
def song(video_id: str) -> dict[str, Any]:
    if not video_id or len(video_id) > 32:
        raise HTTPException(status_code=400, detail="Invalid video id")
    try:
        raw = client().get_song(video_id, signatureTimestamp=current_signature_timestamp())
        details = raw.get("videoDetails") or {}
        streaming = raw.get("streamingData") or {}
        formats = streaming.get("adaptiveFormats") or []
        audio_formats = [
            item
            for item in formats
            if isinstance(item, dict)
            and str(item.get("mimeType", "")).startswith("audio/")
            and item.get("url")
        ]
        audio_formats.sort(
            key=lambda item: (
                0 if "audio/mp4" in str(item.get("mimeType", "")) else 1,
                -(int(item.get("bitrate") or 0)),
            )
        )
        chosen = audio_formats[0] if audio_formats else None
        if not chosen:
            raise HTTPException(status_code=502, detail="No playable audio stream was returned")

        duration = int(float(details.get("lengthSeconds") or 0))
        owner = ((raw.get("microformat") or {}).get("microformatDataRenderer") or {}).get("ownerChannelName")
        artists = owner or details.get("author") or "Unknown artist"
        return {
            "videoId": video_id,
            "title": details.get("title") or "Untitled",
            "artist": artists,
            "thumbnail": ((details.get("thumbnail") or {}).get("thumbnails") or [{}])[-1].get("url"),
            "duration_seconds": duration,
            "duration_text": f"{duration // 60}:{duration % 60:02d}" if duration else None,
            "streamUrl": chosen["url"],
            "expiresInSeconds": int(streaming.get("expiresInSeconds") or 0),
            "mimeType": chosen.get("mimeType"),
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"YouTube Music song lookup failed: {exc}") from exc
