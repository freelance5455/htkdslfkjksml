# Hearify YouTube Music bridge

This optional Python service powers live YouTube Music catalogue search and playback for the prototype.

Requirements: Python 3.10+.

Run locally:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8787
```

Then set the frontend environment variable:

```env
VITE_YTMUSIC_API_URL=http://localhost:8787
```

For a hosted deployment, deploy this FastAPI service separately and put its HTTPS URL in `VITE_YTMUSIC_API_URL` on the frontend host. Set `HEARIFY_CORS_ORIGINS` to the exact frontend origin(s) you want to allow.

The bridge intentionally uses public, unauthenticated catalogue calls. Account/library features can be added later with ytmusicapi authentication.
