package com.arrowforge.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends Activity {
    private WebView webView;
    private InterstitialAd interstitialAd;
    private boolean adsReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.addJavascriptInterface(new AdsBridge(), "AndroidAds");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        MobileAds.initialize(this, initializationStatus -> loadInterstitial());
    }

    private void loadInterstitial() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, "ca-app-pub-6260927934631893/7484448707", request,
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) { interstitialAd = ad; }
                @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
            });
    }

    private class AdsBridge {
        @JavascriptInterface public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitialAd == null) {
                    continueGameAfterAd();
                    loadInterstitial();
                    return;
                }
                interstitialAd.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() {
                        interstitialAd = null;
                        continueGameAfterAd();
                        loadInterstitial();
                    }
                    @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError error) {
                        interstitialAd = null;
                        continueGameAfterAd();
                        loadInterstitial();
                    }
                });
                interstitialAd.show(MainActivity.this);
                interstitialAd = null;
            });
        }
    }

    private void continueGameAfterAd() {
        if (webView != null) webView.post(() -> webView.evaluateJavascript("window.onInterstitialClosed && window.onInterstitialClosed()", null));
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
