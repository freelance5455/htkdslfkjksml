ARROW FORGE ANDROID PROJECT

Ye Android Studio project hai, APK file nahi. Ismein aapki Arrow Forge HTML file app ke andar rakhi gayi hai.

APK banane ke liye computer par Android Studio install karke:
1. ZIP extract karein.
2. Android Studio > Open > extracted Arrow_Forge_Android_Project folder select karein.
3. Gradle sync complete hone dein (internet chahiye).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK aam taur par app/build/outputs/apk/debug/app-debug.apk mein milegi.

NOTE: AdMob abhi add nahi hai. Pehle app ko build/install karke game test karein.
