
import { pipeline } from "https://cdn.jsdelivr.net/npm/@huggingface/transformers@4.3.0";
let generator=null;
async function loadAI(){
 if(generator)return generator;
 generator=await pipeline("text-generation","onnx-community/Qwen2.5-0.5B-Instruct",{device:"webgpu",dtype:"q4"});
 return generator;
}
export async function askLegalAI(question, context=""){
 const pipe=await loadAI();
 const prompt=`أنت مساعد قانوني عربي للمحامي.
لا تدّعي أنك محامٍ ولا تقدم نتيجة نهائية ملزمة.
إذا كان السؤال متعلقًا بملف، اعتمد على النص الموجود في المستندات فقط.
اذكر اسم الملف ورقم الصفحة عند الاستناد إلى معلومة.
إذا لم تجد المعلومة قل: "لم أجدها في المستندات المرفوعة".
السؤال: ${question}
المستندات:${context||" لا توجد مستندات مرفوعة."}
الإجابة:`;
 const result=await pipe(prompt,{max_new_tokens:260,temperature:0.15,do_sample:true});
 return result?.[0]?.generated_text?.split("الإجابة:").pop()?.trim()||"تعذر توليد الإجابة.";
}
