/* Offline local identity: name + email + date of birth. No password or API. */
(()=>{
'use strict';
const ACCOUNT_KEY='pjsa.local.account.v1',SESSION_KEY='pjsa.local.session.v1';
const $=id=>document.getElementById(id), gate=$('authGate'),shell=$('appShell'),msg=$('authMessage');
const norm=s=>String(s||'').trim().toLowerCase();
const read=()=>{try{return JSON.parse(localStorage.getItem(ACCOUNT_KEY)||'null')}catch{return null}};
const write=a=>localStorage.setItem(ACCOUNT_KEY,JSON.stringify(a));
const say=(t,ok=false)=>{msg.textContent=t;msg.classList.toggle('ok',ok)};
const ageFromDob=dob=>{const d=new Date(dob+'T00:00:00');if(!dob||Number.isNaN(d.getTime())||d>new Date())return null;const n=new Date();return n.getFullYear()-d.getFullYear()-((n.getMonth()<d.getMonth()||(n.getMonth()===d.getMonth()&&n.getDate()<d.getDate()))?1:0)};
const show=tab=>{document.querySelectorAll('[data-auth-tab]').forEach(b=>b.classList.toggle('active',b.dataset.authTab===tab));['login','signup'].forEach(t=>$(t+'Form').hidden=t!==tab);$('successPanel').hidden=true;say('')};
const unlock=a=>{sessionStorage.setItem(SESSION_KEY,'1');gate.hidden=true;shell.hidden=false;window.dispatchEvent(new CustomEvent('pjsa-authenticated',{detail:{username:a.email,name:a.name,age:ageFromDob(a.dob)}}));};
const success=()=>{$('loginForm').hidden=true;$('signupForm').hidden=true;$('successPanel').hidden=false;document.querySelectorAll('[data-auth-tab]').forEach(b=>b.classList.remove('active'));say('Your account was created successfully.',true)};
const account=read();
if(sessionStorage.getItem(SESSION_KEY)==='1'&&account){gate.hidden=true;shell.hidden=false}else{gate.hidden=false;shell.hidden=true;show(account?'login':'signup')}
document.querySelectorAll('[data-auth-tab]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.authTab)));
$('loginForm').addEventListener('submit',e=>{e.preventDefault();const a=read(),email=norm($('loginEmail').value),dob=$('loginDob').value;if(!a||email!==norm(a.email||a.username)){say('No matching account found on this device. Create an account first.');return}if(!a.dob){say('This is an older account. Create your new local profile to continue; existing study data will be kept.');show('signup');$('signupName').value=a.name||'';$('signupEmail').value=email;return}if(dob!==a.dob){say('Date of birth does not match this local account.');return}say('Login successful.',true);unlock(a)});
$('signupForm').addEventListener('submit',e=>{e.preventDefault();const name=$('signupName').value.trim(),email=norm($('signupEmail').value),dob=$('signupDob').value,age=ageFromDob(dob);if(name.length<2){say('Please enter your name.');return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){say('Please enter a valid email address.');return}if(age===null||age>120){say('Please enter a valid date of birth.');return}const old=read();if(old&&norm(old.email||old.username)===email&&old.dob===dob){say('This account already exists on this device. Please log in.');show('login');$('loginEmail').value=email;return}if(old&&norm(old.email||old.username)!==email){say('One local account is supported on this device. Delete the existing account before creating another.');return}const a={name,email,dob,age,createdAt:old?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString(),accountVersion:2};write(a);$('successName').textContent='Welcome, '+name+'!';success();});
$('successLoginBtn').addEventListener('click',()=>{show('login');$('loginEmail').value=norm(read()?.email||'');$('loginDob').focus()});
$('successContinueBtn').addEventListener('click',()=>{const a=read();if(a)unlock(a)});
window.PJSAAuth={logout(){sessionStorage.removeItem(SESSION_KEY);location.reload()},verifyPassword:async dob=>{const a=read();return !!a&&String(dob||'')===a.dob},verifyDob:dob=>{const a=read();return !!a&&String(dob||'')===a.dob},deleteAccount(){const a=read();if(a){const k='pjsa.backup.key.v1.'+btoa(unescape(encodeURIComponent(String(a.email||a.username||'').trim().toLowerCase())));localStorage.removeItem(k)}localStorage.removeItem(ACCOUNT_KEY);localStorage.removeItem('studyCompanionSyllabusV2');localStorage.removeItem('pjsaCalcHistory');sessionStorage.removeItem(SESSION_KEY);try{indexedDB.deleteDatabase('pjsa-books-db')}catch{}location.reload()},username(){return read()?.email||''},dob(){return read()?.dob||''},age(){return ageFromDob(read()?.dob||'')}};
})();
