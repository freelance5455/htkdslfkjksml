
import * as pdfjsLib from "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs";
pdfjsLib.GlobalWorkerOptions.workerSrc =
  "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs";
import mammoth from "https://cdn.jsdelivr.net/npm/mammoth@1.8.0/+esm";

export async function extractDocument(file) {
  const name=file.name.toLowerCase();
  if (name.endsWith(".txt")) return {name:file.name, pages:[{page:1,text:await file.text()}]};
  if (name.endsWith(".pdf")) {
    const data=new Uint8Array(await file.arrayBuffer());
    const pdf=await pdfjsLib.getDocument({data}).promise;
    const pages=[];
    for(let i=1;i<=pdf.numPages;i++){
      const p=await pdf.getPage(i);
      const c=await p.getTextContent();
      pages.push({page:i,text:c.items.map(x=>x.str).join(" ")});
    }
    return {name:file.name,pages};
  }
  if(name.endsWith(".docx")){
    const buf=await file.arrayBuffer();
    const r=await mammoth.extractRawText({arrayBuffer:buf});
    return {name:file.name,pages:[{page:1,text:r.value}]};
  }
  throw new Error("صيغة الملف غير مدعومة في النسخة الحالية");
}

export function buildContext(docs, maxChars=12000){
  let out="";
  for(const d of docs){
    for(const p of d.pages){
      const part=`\n[الملف: ${d.name} | الصفحة: ${p.page}]\n${p.text}`;
      if(out.length+part.length>maxChars) return out;
      out+=part;
    }
  }
  return out;
}
