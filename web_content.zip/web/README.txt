========================================================================
ATC AVIATION WEATHER — MOBILE-FIRST HTML APPLICATION
Aviation Weather for Air Traffic Controllers and Pilots
========================================================================

1. OVERVIEW
------------------------------------------------------------------------
ATC Aviation Weather is a lightweight, mobile-first aviation weather application
designed specifically for professional air traffic controllers. It provides
instant access to genuine, untouched operational messages (METAR, SPECI, TAF,
SIGMET, and Upper-Air Winds) for airports across Iran and worldwide.

The application is completely self-contained in "index.html" with zero build
tools, zero server dependencies, and zero framework overhead. It runs directly
in any modern mobile browser or Android WebView.


2. FILE STRUCTURE
------------------------------------------------------------------------
- index.html   : Complete, self-contained application (HTML5 + CSS3 + JS)
- manifest.json: Progressive Web App (PWA) configuration metadata
- icon.png     : High-resolution application icon (512x512 pixels)
- README.txt   : This instruction file


3. HOW TO RUN DIRECTLY IN A BROWSER OR ON A PHONE
------------------------------------------------------------------------
Option A: Open "index.html" directly in any mobile or desktop browser
          (Chrome, Firefox, Safari, Samsung Internet).

Option B: Host on any static server:
          python3 -m http.server 8080
          Then open http://localhost:8080 on your phone.


4. HOW TO PACKAGE INTO AN ANDROID APK (HTML-TO-APK BUILDERS)
------------------------------------------------------------------------
Because this application is 100% client-side with all styling and scripts
self-contained, it is directly compatible with online HTML-to-APK converters:

Method 1: Using WebIntoApp (https://www.webintoapp.com)
   1. Go to https://www.webintoapp.com
   2. Select "HTML Files" mode.
   3. Upload "atc-weather-app.zip" (or simply upload "index.html" and "icon.png").
   4. Set App Name to: "ATC Aviation Weather"
   5. Set Package Name to: "com.atcweather.app"
   6. Click "Generate APK" and download your installable .apk file.

Method 2: Using AppsGeyser (https://appsgeyser.com)
   1. Choose the "Website / HTML" template.
   2. Upload the ZIP archive containing index.html, manifest.json, and icon.png.
   3. Set the icon to "icon.png" and click Build APK.

Method 3: Using PWABuilder (https://www.pwabuilder.com)
   1. Host the files on any static hosting (e.g. GitHub Pages).
   2. Enter the URL into PWABuilder.
   3. Click "Build My PWA" -> "Android" to generate a signed APK or AAB.


5. OPERATIONAL PAGES
------------------------------------------------------------------------
A. METAR / SPECI
   - Fast airport search by 4-letter ICAO code (e.g., OIIE, OIII, OMDB).
   - Instant quick-selection chips for Iranian aerodromes and world hubs.
   - Untranslated, undecoded raw METAR text with one-tap clipboard copy.
   - Highlighting of special weather reports (SPECI alert badge).
   - Separate display of message observation time and retrieval time.

B. TAF
   - Full aerodrome forecast display.
   - Preservation of original text and forecast change groups (FM, BECMG, TEMPO, PROB).
   - Issue time and validity period.

C. SIGMET
   - Real-time significant meteorological warnings (Thunderstorms, Severe Turbulence,
     Severe Icing, Volcanic Ash, etc.).
   - Filterable for Iran FIR (Tehran OIIX) and worldwide active bulletins.
   - Displays clear "No active SIGMET" status when no hazards are active.

D. UPPER WIND (باد سطوح فوقانی)
   - Multi-level vertical winds (Surface, FL050, FL100, FL180, FL300, FL340, FL390).
   - Numerical wind direction in degrees, speed in knots (KT), and temperature in °C.
   - Powered by WMO GFS numerical upper-air prediction model.


6. DATA ACCURACY & RELIABILITY
------------------------------------------------------------------------
- Real public OPMET data is queried directly from AviationWeather.gov API.
- Upper wind is queried directly from Open-Meteo Aviation GFS model.
- If network connection is unavailable, previously received bulletins are
  displayed from local cache with a clear "CACHED / OFFLINE" indicator.
- Manual Input mode allows air traffic controllers to paste AFTN / AMHS or
  local operational bulletins directly into the app.
- No simulated or fabricated operational messages are ever displayed.


7. OPERATIONAL SAFETY DISCLAIMER
------------------------------------------------------------------------
Operational decisions must be based on current authorized aviation information
sources and applicable local procedures.

تصمیمات عملیاتی مراقبت پرواز باید بر اساس منابع رسمی معتبر هوانوردی و
دستورالعمل‌های محلی مصوب سازمان هواپیمایی کشوری اتخاذ گردد.
========================================================================
