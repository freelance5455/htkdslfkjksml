(()=>{'use strict';
const DB='pjsa-books-db',STORE='books';let dbPromise;
const $=id=>document.getElementById(id);
function db(){if(dbPromise)return dbPromise;dbPromise=new Promise((resolve,reject)=>{const req=indexedDB.open(DB,1);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE)){const st=d.createObjectStore(STORE,{keyPath:'id',autoIncrement:true});st.createIndex('createdAt','createdAt')}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)});return dbPromise}
async function tx(mode,fn){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction(STORE,mode),s=t.objectStore(STORE);let result;try{result=fn(s)}catch(e){reject(e);return}t.oncomplete=()=>resolve(result?.result);t.onerror=()=>reject(t.error);t.onabort=()=>reject(t.error)})}
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function all(){const d=await db();return new Promise((resolve,reject)=>{const r=d.transaction(STORE).objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error)})}
function human(n){if(n<1024*1024)return (n/1024).toFixed(0)+' KB';return (n/1048576).toFixed(1)+' MB'}
async function render(){try{const books=(await all()).sort((a,b)=>b.createdAt-a.createdAt);$('pdfBookCount').textContent=books.length+' '+(books.length===1?'book':'books');$('pdfBooksList').innerHTML=books.length?books.map(b=>`<article class="pdf-book-card"><div class="pdf-file-icon">PDF</div><div class="pdf-book-info"><strong>${esc(b.name)}</strong><small>${esc(b.fileName)} · ${human(b.size)} · ${new Date(b.createdAt).toLocaleDateString()}</small></div><div class="pdf-book-actions"><button class="button button-primary" data-pdf-open="${b.id}" type="button">Read</button><button class="button button-secondary" data-pdf-external="${b.id}" type="button">Open in PDF app</button><button class="text-button" data-pdf-delete="${b.id}" type="button">Delete</button></div></article>`).join(''):'<div class="empty-state"><span>▤</span><strong>No PDFs added yet</strong><p>Choose a PDF above to build your library.</p></div>'}catch(e){$('pdfUploadStatus').textContent='Local PDF storage is unavailable in this WebView.'}}
let activeUrl=null;function release(){if(activeUrl){URL.revokeObjectURL(activeUrl);activeUrl=null}}
async function getBook(id){const d=await db();return new Promise((resolve,reject)=>{const r=d.transaction(STORE).objectStore(STORE).get(Number(id));r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function openBook(id,external=false){const b=await getBook(id);if(!b)return;release();activeUrl=URL.createObjectURL(b.blob);if(external){const a=document.createElement('a');a.href=activeUrl;a.target='_blank';a.rel='noopener';a.download=b.fileName;a.click();$('pdfUploadStatus').textContent='Opening PDF. If it downloads instead, open it from Downloads with your preferred PDF reader.';return}$('pdfViewerTitle').textContent=b.name;$('pdfFrame').src=activeUrl;$('pdfViewer').hidden=false;$('pdfViewer').scrollIntoView({behavior:'smooth',block:'start'})}
const picker=$('pdfBookFile'),dropZone=$('pdfDropZone');
async function importPdf(f){
  const status=$('pdfUploadStatus');
  if(!f)return;
  try{
    const signature=new Uint8Array(await f.slice(0,5).arrayBuffer());
    const hasPdfSignature=signature.length===5 && signature[0]===0x25 && signature[1]===0x50 && signature[2]===0x44 && signature[3]===0x46 && signature[4]===0x2D;
    if(!/\.pdf$/i.test(f.name) || !hasPdfSignature) throw new Error('This is not a valid PDF. Please choose a genuine .pdf file.');
    if(f.size===0)throw new Error('This PDF file is empty.');
    if(f.size>100*1024*1024)throw new Error('This PDF is larger than 100 MB. Please choose a smaller file.');
    const name=$('pdfBookName').value.trim()||f.name.replace(/\.pdf$/i,'');
    await tx('readwrite',s=>s.add({name,fileName:f.name,size:f.size,blob:f,createdAt:Date.now()}));
    $('pdfBookName').value='';
    status.textContent='✓ PDF saved to Your Books PDF on this device.';
    await render();
  }catch(err){status.textContent=err.message||'Could not save this PDF. Check available device storage.'}
}
picker.addEventListener('change',async e=>{await importPdf(e.target.files?.[0]);e.target.value=''});
['dragenter','dragover'].forEach(type=>dropZone.addEventListener(type,e=>{e.preventDefault();e.stopPropagation();dropZone.classList.add('is-dragover')}));
['dragleave','dragend'].forEach(type=>dropZone.addEventListener(type,e=>{e.preventDefault();dropZone.classList.remove('is-dragover')}));
dropZone.addEventListener('click',e=>{if(e.target.closest('button'))return;picker.click()});
dropZone.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();picker.click()}});
dropZone.setAttribute('tabindex','0');
dropZone.setAttribute('role','button');
dropZone.setAttribute('aria-label','Tap to choose a PDF, or drop a PDF file here');
dropZone.addEventListener('drop',async e=>{
  e.preventDefault();e.stopPropagation();dropZone.classList.remove('is-dragover');
  const list=Array.from(e.dataTransfer?.files||[]);
  if(!list.length){$('pdfUploadStatus').textContent='Your Android file manager did not pass the dragged file to the app. Tap Choose PDF to select it instead.';return}
  if(list.length>1){$('pdfUploadStatus').textContent='Please drop one PDF file at a time.';return}
  await importPdf(list[0]);
});
$('pdfBooksList').addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;try{if(b.dataset.pdfOpen)await openBook(b.dataset.pdfOpen);if(b.dataset.pdfExternal)await openBook(b.dataset.pdfExternal,true);if(b.dataset.pdfDelete&&confirm('Delete this PDF from your local library?')){await tx('readwrite',s=>s.delete(Number(b.dataset.pdfDelete)));await render()}}catch(err){$('pdfUploadStatus').textContent='Could not open this PDF in the current WebView. Try Open in PDF app.'}});
$('closePdfViewer').addEventListener('click',()=>{$('pdfFrame').src='about:blank';$('pdfViewer').hidden=true;release()});window.addEventListener('pagehide',release);window.addEventListener('pjsa-authenticated',render);document.addEventListener('DOMContentLoaded',render);render();
})();