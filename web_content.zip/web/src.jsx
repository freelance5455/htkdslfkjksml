import React, {useEffect, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {createClient} from '@supabase/supabase-js';
import {MessageCircle,Users,Compass,Plus,Settings,Search,Send,Moon,Sun,Hash,Paperclip,Crown,LogOut,Smile} from 'lucide-react';
import './style.css';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = url && key ? createClient(url,key) : null;

function App(){
 const [dark,setDark]=useState(true), [session,setSession]=useState(null), [email,setEmail]=useState(''), [password,setPassword]=useState(''), [display,setDisplay]=useState(''), [error,setError]=useState(''), [busy,setBusy]=useState(false);
 const [messages,setMessages]=useState([]), [draft,setDraft]=useState(''), [channel]=useState('general'), [status,setStatus]=useState('Connecting…');
 useEffect(()=>{if(!supabase){setStatus('Setup required');return}
   supabase.auth.getSession().then(({data})=>setSession(data.session));
   const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));
   return ()=>subscription.unsubscribe();
 },[]);
 useEffect(()=>{if(!supabase||!session){setMessages([]);return}
   let alive=true;
   async function load(){const {data,error}=await supabase.from('messages').select('id,content,created_at,user_id,profiles(display_name)').eq('channel_name',channel).order('created_at',{ascending:true}).limit(100);
     if(alive){if(error)setError(error.message);else setMessages(data||[]);}}
   load();
   const sub=supabase.channel('room-'+channel).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:'channel_name=eq.'+channel},async payload=>{
     const {data:profile}=await supabase.from('profiles').select('display_name').eq('id',payload.new.user_id).maybeSingle();
     if(alive)setMessages(old=>old.some(m=>m.id===payload.new.id)?old:[...old,{...payload.new,profiles:profile}]);
   }).subscribe(s=>setStatus(s==='SUBSCRIBED'?'Live':'Connecting…'));
   return ()=>{alive=false;supabase.removeChannel(sub)};
 },[session,channel]);
 async function signIn(e){e.preventDefault();setBusy(true);setError('');
   if(!supabase){setError('Add Supabase URL and key in web/.env before signing in.');setBusy(false);return}
   const {data,error}=await supabase.auth.signInWithPassword({email,password});
   if(error)setError(error.message);else setSession(data.session);setBusy(false);
 }
 async function signUp(e){e.preventDefault();setBusy(true);setError('');
   if(!supabase){setError('Add Supabase URL and key in web/.env before signing up.');setBusy(false);return}
   const {data,error}=await supabase.auth.signUp({email,password,options:{data:{display_name:display||email.split('@')[0]}}});
   if(error)setError(error.message);else setError('Check your email to confirm your account, then sign in.');setBusy(false);
 }
 async function google(){if(!supabase){setError('Configure Supabase first.');return}
   const {error}=await supabase.auth.signInWithOAuth({provider:'google',options:{redirectTo:window.location.origin}});
   if(error)setError(error.message);
 }
 async function send(){if(!draft.trim()||!supabase||!session)return;
   const content=draft.trim();setDraft('');
   const {error}=await supabase.from('messages').insert({channel_name:channel,user_id:session.user.id,content});
   if(error){setError(error.message);setDraft(content)}
 }
 async function logout(){await supabase?.auth.signOut();setSession(null)}
 const userLabel=session?.user?.user_metadata?.display_name||session?.user?.email?.split('@')[0]||'Member';
 return <div className={dark?'app dark':'app light'}>
 {!session?<main className="login"><div className="brand"><div className="logo">A</div>AERORE</div><p className="tag">Your community. Your rules.</p><form className="loginbox" onSubmit={signIn}><h1>Welcome aboard</h1><p>Sign in or create your AERORE account.</p><input value={display} onChange={e=>setDisplay(e.target.value)} placeholder="Display name (for signup)"/><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email address"/><input type="password" required minLength="8" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password (8+ characters)"/><button className="primary" disabled={busy}>Sign in</button><button type="button" className="secondary" disabled={busy} onClick={signUp}>Create account</button><button type="button" className="google" onClick={google}>G&nbsp; Continue with Google</button>{error&&<p className="error">{error}</p>}<small>{supabase?'Secure sign-in powered by Supabase.':'Setup needed: configure Supabase using the included guide.'}</small></form></main>:
 <div className="layout"><aside className="rail"><div className="logo">A</div><button className="railbtn active"><MessageCircle/></button><button className="railbtn"><Compass/></button><div className="railsep"/><button className="servericon selected">A</button><button className="addserver"><Plus/></button><div className="spacer"/><button className="railbtn" onClick={()=>setDark(!dark)}>{dark?<Sun/>:<Moon/>}</button></aside>
 <aside className="sidebar"><div className="serverhead"><b>AERORE HQ</b><span>⌄</span></div><div className="side-search"><Search size={15}/> Find anything</div><div className="section">CHANNELS</div><div className="channel chosen"><Hash size={16}/>{channel}</div><div className="section">FRIENDS & DMs</div><p className="hint">Friend requests and private DMs are the next module.</p><div className="usercard"><div className="avatar">{userLabel[0]?.toUpperCase()}</div><div><b>{userLabel}</b><small>{status}</small></div><button onClick={logout} title="Sign out"><LogOut size={17}/></button></div></aside>
 <main className="chat"><header><div><h3><Hash size={19}/>{channel}</h3><p>Messages sync live for signed-in members.</p></div><button onClick={()=>setDark(!dark)}>{dark?<Sun/>:<Moon/>}</button></header><div className="topic">✨ Unicode emojis work in messages. Standard file limit target: 10 MB.</div><div className="messages">{messages.map(m=><article key={m.id}><div className="avatar">{(m.profiles?.display_name||'A')[0].toUpperCase()}</div><div><div className="msgmeta"><b>{m.profiles?.display_name||'AERORE member'}</b><small>{new Date(m.created_at).toLocaleString()}</small></div><p>{m.content}</p></div></article>)}</div><div className="composer"><button title="Emoji keyboard is provided by your phone"><Smile/></button><input value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Message #general"/><button className="send" onClick={send}><Send size={18}/></button></div>{error&&<div className="errorbar">{error}</div>}</main><aside className="members"><h4>YOUR MEMBERSHIP</h4><div className="premium"><Crown/><b>AERORE Plus</b><p>Premium features will activate after subscription and payment integration.</p><button onClick={()=>alert('Plus billing is not enabled in this starter.')}>Explore Plus</button></div><p className="hint">Never share your password or private keys.</p></aside></div>}
 </div>
}
createRoot(document.getElementById('root')).render(<App/>);
