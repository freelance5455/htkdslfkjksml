export function triggerHaptic(enabled) {
  if (!enabled) return;
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(8);
    }
  } catch {
    // Vibration not supported or disallowed
  }
}

const activePressTimers = new WeakMap();

export function pulseKeyElement(el) {
  if (!el || !el.classList) return;
  const prevTimer = activePressTimers.get(el);
  if (prevTimer) clearTimeout(prevTimer);
  el.classList.add('is-pressed');
  const timer = setTimeout(() => {
    el.classList.remove('is-pressed');
    activePressTimers.delete(el);
  }, 70);
  if (typeof timer?.unref === 'function') timer.unref();
  activePressTimers.set(el, timer);
}

/**
 * Registers zero-latency pointerdown handling for tactile keypad containers while
 * preserving accessible keyboard/programmatic `click` activation with zero double-triggers.
 */
export function attachFastKeypadHandler(root, { onAction, keypadSelector = '.tactile-key' }) {
  let pressedEl = null;
  let lastPointerTarget = null;
  let lastPointerTs = 0;

  const nowMs = () =>
    typeof performance !== 'undefined' && typeof performance.now === 'function'
      ? performance.now()
      : Date.now();

  const clearPressed = () => {
    if (pressedEl) {
      pressedEl.classList.remove('is-pressed');
      pressedEl = null;
    }
  };

  const onPointerDown = (e) => {
    if (e.button !== undefined && e.button !== 0) return;
    const btn = e.target?.closest?.('[data-action]');
    clearPressed();
    if (!btn || !root.contains(btn)) return;

    const isKeypadKey = btn.classList?.contains?.('tactile-key') || Boolean(btn.closest?.(keypadSelector));
    if (isKeypadKey) {
      pressedEl = btn;
      btn.classList.add('is-pressed');
      lastPointerTarget = btn;
      lastPointerTs = nowMs();
      onAction(btn);
    }
  };

  const onPointerOut = (e) => {
    if (pressedEl && e.target === pressedEl) {
      clearPressed();
    }
  };

  const onClick = (e) => {
    const btn = e.target?.closest?.('[data-action]');
    if (!btn || !root.contains(btn)) return;
    if (lastPointerTarget === btn && nowMs() - lastPointerTs < 600) {
      lastPointerTarget = null;
      return;
    }
    lastPointerTarget = null;
    onAction(btn);
  };

  root.addEventListener('pointerdown', onPointerDown);
  root.addEventListener('pointerup', clearPressed);
  root.addEventListener('pointercancel', clearPressed);
  root.addEventListener('pointerleave', clearPressed);
  root.addEventListener('pointerout', onPointerOut);
  root.addEventListener('click', onClick);

  return () => {
    clearPressed();
    lastPointerTarget = null;
    root.removeEventListener('pointerdown', onPointerDown);
    root.removeEventListener('pointerup', clearPressed);
    root.removeEventListener('pointercancel', clearPressed);
    root.removeEventListener('pointerleave', clearPressed);
    root.removeEventListener('pointerout', onPointerOut);
    root.removeEventListener('click', onClick);
  };
}

export function escapeHtml(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}
