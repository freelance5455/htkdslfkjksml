import { ConverterCategories } from '../engine/unitConverter.js';
import { attachFastKeypadHandler, escapeHtml, triggerHaptic } from './haptics.js';
import { Icons } from './icons.js';

export function mountConverterView(container, { converterStore, preferencesStore, onCopyResult }) {
  container.innerHTML = `
    <div class="screen-container">
      <div class="converter-layout">
        <header class="top-bar" style="min-height:48px;">
          <h1 class="screen-title">Convert</h1>
          <div class="rate-badge tnum" data-slot="rate-label"></div>
        </header>

        <div class="chip-strip" data-slot="category-chips" role="tablist" aria-label="Unit categories">
          ${ConverterCategories.map(
            (cat) => `
            <button type="button" class="aether-chip" data-action="select-cat" data-cat="${cat.name}" data-testid="converter_cat_${cat.name}">
              ${escapeHtml(cat.title)}
            </button>`,
          ).join('')}
        </div>

        <div data-slot="currency-panel"></div>

        <div class="converter-cards-wrap">
          <div class="aether-card unit-card">
            <div class="unit-card-top">
              <div class="unit-select-wrap">
                <select class="unit-select" data-slot="from-select" data-testid="unit_picker_from" aria-label="From unit"></select>
                <span class="unit-select-chevron">${Icons.chevronDown()}</span>
              </div>
              <button type="button" class="icon-btn" style="width:36px;height:36px;min-width:36px;min-height:36px;" data-action="clear-conv" aria-label="Clear input" title="Clear input">
                ${Icons.clear()}
              </button>
            </div>
            <div class="unit-value tnum" data-slot="from-value" data-testid="converter_from_value">1</div>
          </div>

          <button type="button" class="tactile-key accent swap-fab" data-action="swap" data-testid="converter_swap_button" aria-label="Swap units" title="Swap units">
            ${Icons.swapVert()}
          </button>

          <div class="aether-card unit-card">
            <div class="unit-card-top">
              <div class="unit-select-wrap">
                <select class="unit-select" data-slot="to-select" data-testid="unit_picker_to" aria-label="To unit"></select>
                <span class="unit-select-chevron">${Icons.chevronDown()}</span>
              </div>
              <button type="button" class="icon-btn" style="width:36px;height:36px;min-width:36px;min-height:36px;" data-action="copy-conv" aria-label="Copy result" title="Copy result">
                ${Icons.copy()}
              </button>
            </div>
            <div class="unit-value output tnum" data-slot="to-value" data-testid="converter_to_value">—</div>
          </div>
        </div>

        <div class="converter-keypad" role="group" aria-label="Converter keypad">
          <div class="keypad-row">
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="7" data-testid="conv_key_7">7</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="8" data-testid="conv_key_8">8</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="9" data-testid="conv_key_9">9</button>
            <button type="button" class="tactile-key utility std-key" data-action="del" data-testid="conv_key_del" aria-label="Delete last character">${Icons.backspace()}</button>
          </div>
          <div class="keypad-row">
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="4" data-testid="conv_key_4">4</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="5" data-testid="conv_key_5">5</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="6" data-testid="conv_key_6">6</button>
            <button type="button" class="tactile-key utility std-key" data-action="clear-conv" data-testid="conv_key_clear">C</button>
          </div>
          <div class="keypad-row">
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="1" data-testid="conv_key_1">1</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="2" data-testid="conv_key_2">2</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="3" data-testid="conv_key_3">3</button>
            <button type="button" class="tactile-key utility std-key" data-action="copy-conv" data-testid="conv_key_copy" aria-label="Copy result">${Icons.copy()}</button>
          </div>
          <div class="keypad-row">
            <button type="button" class="tactile-key std-key sign" data-slot="sign-or-00" data-action="sign-or-00">00</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="0" data-testid="conv_key_0">0</button>
            <button type="button" class="tactile-key std-key" data-action="dot" data-testid="conv_key_dot">.</button>
            <button type="button" class="tactile-key accent std-key" style="font-size:14px;font-weight:600;" data-action="copy-conv">Copy</button>
          </div>
        </div>
      </div>
    </div>
  `;

  const root = container;
  const rateBadge = root.querySelector('[data-slot="rate-label"]');
  const catChipsSlot = root.querySelector('[data-slot="category-chips"]');
  const currencyPanelSlot = root.querySelector('[data-slot="currency-panel"]');
  const fromSelect = root.querySelector('[data-slot="from-select"]');
  const toSelect = root.querySelector('[data-slot="to-select"]');
  const fromValueEl = root.querySelector('[data-slot="from-value"]');
  const toValueEl = root.querySelector('[data-slot="to-value"]');
  const signOr00Btn = root.querySelector('[data-slot="sign-or-00"]');

  const chipMap = new Map();
  for (const btn of catChipsSlot.querySelectorAll('[data-cat]')) {
    chipMap.set(btn.dataset.cat, btn);
  }

  let renderedCategoryName = null;
  let renderedUnitPairKey = null;
  let customRateInputEl = null;
  let prevRateLabel = '';
  let prevInputText = '';
  let prevInputClass = '';
  let prevOutputText = '';
  let prevOutputClass = '';
  let prevSignLabel = '';

  const render = () => {
    const state = converterStore.state;
    const formatting = preferencesStore.value.formattingOptions;
    const outputText = converterStore.computeOutput(formatting);

    const rateLabel = converterStore.effectiveRateLabel();
    if (rateLabel !== prevRateLabel) {
      prevRateLabel = rateLabel;
      rateBadge.textContent = rateLabel;
    }

    if (renderedCategoryName !== state.category.name) {
      if (renderedCategoryName) {
        chipMap.get(renderedCategoryName)?.classList.remove('selected');
      }
      chipMap.get(state.category.name)?.classList.add('selected');
    }

    const pairKey = `${state.category.name}:${state.fromUnit.id}:${state.toUnit.id}`;
    if (state.category.isCurrency) {
      if (renderedCategoryName !== state.category.name || !customRateInputEl) {
        currencyPanelSlot.innerHTML = `
          <div class="aether-card elevated currency-banner">
            <div class="currency-note">
              <span style="color:var(--lavender);display:inline-flex;">${Icons.info()}</span>
              <span>Offline reference rates only — not live market data. Tap rate to edit.</span>
            </div>
            <div class="field-group">
              <label class="field-label" data-slot="custom-rate-label"></label>
              <input class="aether-input" type="text" inputmode="decimal" placeholder="Using offline reference rate" data-slot="custom-rate-input" />
            </div>
          </div>`;
        customRateInputEl = currencyPanelSlot.querySelector('[data-slot="custom-rate-input"]');
        customRateInputEl.addEventListener('input', (ev) => {
          converterStore.onCustomRateChanged(ev.target.value);
          if (ev.target.value !== converterStore.state.customRateText) {
            ev.target.value = converterStore.state.customRateText;
          }
        });
      }
      const labelEl = currencyPanelSlot.querySelector('[data-slot="custom-rate-label"]');
      const nextLabel = `Custom rate (1 ${state.fromUnit.symbol} → ${state.toUnit.symbol})`;
      if (labelEl.textContent !== nextLabel) {
        labelEl.textContent = nextLabel;
      }
      if (customRateInputEl.value !== state.customRateText) {
        customRateInputEl.value = state.customRateText;
      }
    } else if (renderedCategoryName !== state.category.name) {
      currencyPanelSlot.innerHTML = '';
      customRateInputEl = null;
    }

    if (renderedUnitPairKey !== pairKey) {
      const buildOptions = (selectedId) =>
        state.units
          .map(
            (u) =>
              `<option value="${escapeHtml(u.id)}" ${u.id === selectedId ? 'selected' : ''}>${escapeHtml(u.symbol)} · ${escapeHtml(u.name)}</option>`,
          )
          .join('');
      fromSelect.innerHTML = buildOptions(state.fromUnit.id);
      toSelect.innerHTML = buildOptions(state.toUnit.id);
      renderedUnitPairKey = pairKey;
    }

    renderedCategoryName = state.category.name;

    if (state.inputText !== prevInputText) {
      prevInputText = state.inputText;
      fromValueEl.textContent = state.inputText;
    }
    const nextInputClass = `unit-value tnum${state.inputText.length > 14 ? ' long' : ''}`;
    if (nextInputClass !== prevInputClass) {
      prevInputClass = nextInputClass;
      fromValueEl.className = nextInputClass;
    }

    if (outputText !== prevOutputText) {
      prevOutputText = outputText;
      toValueEl.textContent = outputText;
    }
    const nextOutputClass = `unit-value output tnum${outputText.length > 14 ? ' long' : ''}`;
    if (nextOutputClass !== prevOutputClass) {
      prevOutputClass = nextOutputClass;
      toValueEl.className = nextOutputClass;
    }

    const signLabel = state.category.name === 'TEMPERATURE' ? '+/−' : '00';
    if (signLabel !== prevSignLabel) {
      prevSignLabel = signLabel;
      signOr00Btn.textContent = signLabel;
    }
  };

  fromSelect.addEventListener('change', (e) => {
    const unit = converterStore.state.units.find((u) => u.id === e.target.value);
    if (unit) converterStore.selectFromUnit(unit);
  });

  toSelect.addEventListener('change', (e) => {
    const unit = converterStore.state.units.find((u) => u.id === e.target.value);
    if (unit) converterStore.selectToUnit(unit);
  });

  const handleAction = (btn) => {
    const action = btn.dataset.action;
    const arg = btn.dataset.arg ?? '';
    const haptics = preferencesStore.value.hapticEnabled;

    if (action !== 'copy-conv') triggerHaptic(haptics);

    switch (action) {
      case 'select-cat': {
        const cat = ConverterCategories.find((c) => c.name === btn.dataset.cat);
        if (cat) converterStore.selectCategory(cat);
        break;
      }
      case 'swap':
        converterStore.swapUnits();
        break;
      case 'digit':
        converterStore.onDigit(arg);
        break;
      case 'dot':
        converterStore.onDecimal();
        break;
      case 'del':
        converterStore.onBackspace();
        break;
      case 'clear-conv':
        converterStore.onClear();
        break;
      case 'sign-or-00':
        if (converterStore.state.category.name === 'TEMPERATURE') {
          converterStore.onToggleSign();
        } else {
          converterStore.onDigit('00');
        }
        break;
      case 'copy-conv': {
        const out = converterStore.computeOutput(preferencesStore.value.formattingOptions);
        if (out !== '—') onCopyResult(out);
        break;
      }
    }
  };

  const detachFastInput = attachFastKeypadHandler(root, {
    onAction: handleAction,
    keypadSelector: '.converter-keypad',
  });
  const unsubConv = converterStore.subscribe(render);
  const unsubPrefs = preferencesStore.subscribe(render);

  return () => {
    unsubConv();
    unsubPrefs();
    detachFastInput();
  };
}
