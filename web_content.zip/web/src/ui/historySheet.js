import { escapeHtml } from './haptics.js';
import { Icons } from './icons.js';

function formatHistoryTime(ts) {
  try {
    return new Intl.DateTimeFormat(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(ts));
  } catch {
    return '';
  }
}

export function openHistorySheet({ historyStore, onReuseExpression, onCopyResult, onDeleteItem, onClearAll }) {
  const existing = document.getElementById('aether-history-sheet');
  if (existing) existing.remove();

  const backdrop = document.createElement('div');
  backdrop.id = 'aether-history-sheet';
  backdrop.className = 'sheet-backdrop';
  backdrop.setAttribute('role', 'dialog');
  backdrop.setAttribute('aria-modal', 'true');
  backdrop.setAttribute('aria-label', 'History');

  let showClearConfirm = false;

  const render = (items) => {
    backdrop.innerHTML = `
      <div class="sheet-panel">
        <div class="sheet-handle"></div>
        <div class="sheet-header">
          <h2 class="sheet-title">History</h2>
          ${
            items.length > 0
              ? `<button type="button" class="text-btn danger" data-action="confirm-clear" data-testid="clear_history_button">
                   ${Icons.trash()}
                   <span>Clear all</span>
                 </button>`
              : ''
          }
        </div>
        ${
          items.length === 0
            ? `<div class="history-empty">
                 <div style="opacity:0.85;">${Icons.history()}</div>
                 <div style="font-size:16px;font-weight:600;color:var(--text-primary);margin-top:4px;">No calculations yet</div>
                 <div style="font-size:12px;">Completed calculations will appear here locally on your device.</div>
               </div>`
            : `<div class="history-list">
                 ${items
                   .map(
                     (item) => `
                   <div class="history-card" data-testid="history_item_${item.id}">
                     <div class="history-card-body" data-action="reuse" data-id="${item.id}" role="button" tabindex="0">
                       <div class="history-time">${escapeHtml(formatHistoryTime(item.timestamp))}</div>
                       <div class="history-expr tnum">${escapeHtml(item.expression)}</div>
                       <div class="history-res tnum">= ${escapeHtml(item.resultFormatted)}</div>
                     </div>
                     <div style="display:flex;align-items:center;">
                       <button type="button" class="icon-btn" style="color:var(--lavender);" data-action="copy" data-id="${item.id}" aria-label="Copy result" title="Copy result">
                         ${Icons.copy()}
                       </button>
                       <button type="button" class="icon-btn" data-action="delete" data-id="${item.id}" aria-label="Delete history item" title="Delete">
                         ${Icons.trash()}
                       </button>
                     </div>
                   </div>`,
                   )
                   .join('')}
               </div>`
        }
      </div>
      ${
        showClearConfirm
          ? `<div class="dialog-backdrop" data-action="cancel-clear-backdrop">
               <div class="dialog-card" role="alertdialog" aria-modal="true">
                 <div style="font-size:18px;font-weight:600;">Clear calculation history?</div>
                 <div style="font-size:14px;color:var(--text-secondary);">This will permanently remove all saved calculations from this device.</div>
                 <div class="dialog-actions">
                   <button type="button" class="text-btn accent" data-action="cancel-clear">Cancel</button>
                   <button type="button" class="text-btn danger" data-action="do-clear">Clear</button>
                 </div>
               </div>
             </div>`
          : ''
      }
    `;
  };

  const close = () => {
    unsub();
    document.removeEventListener('keydown', onKeyDown);
    backdrop.remove();
  };

  const onKeyDown = (e) => {
    if (e.key === 'Escape') {
      if (showClearConfirm) {
        showClearConfirm = false;
        render(historyStore.value);
      } else {
        close();
      }
    }
  };

  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) {
      close();
      return;
    }
    const target = e.target.closest('[data-action]');
    if (!target) return;
    const action = target.dataset.action;
    const id = Number(target.dataset.id);
    const items = historyStore.value;

    if (action === 'confirm-clear') {
      showClearConfirm = true;
      render(items);
    } else if (action === 'cancel-clear' || action === 'cancel-clear-backdrop') {
      if (action === 'cancel-clear-backdrop' && e.target !== target) return;
      showClearConfirm = false;
      render(items);
    } else if (action === 'do-clear') {
      showClearConfirm = false;
      onClearAll();
    } else if (action === 'reuse') {
      const item = items.find((x) => x.id === id);
      if (item) {
        onReuseExpression(item);
        close();
      }
    } else if (action === 'copy') {
      const item = items.find((x) => x.id === id);
      if (item) onCopyResult(item.resultFormatted);
    } else if (action === 'delete') {
      onDeleteItem(id);
    }
  });

  document.addEventListener('keydown', onKeyDown);
  const unsub = historyStore.subscribe(render);
  document.body.appendChild(backdrop);

  return close;
}
