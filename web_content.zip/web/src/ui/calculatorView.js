import { attachFastKeypadHandler, escapeHtml, triggerHaptic } from './haptics.js';
import { Icons } from './icons.js';

function getSciRows(uiState) {
  if (uiState.isHyperbolic) {
    return [
      [
        { label: 'sinh', type: 'fn', arg: 'sinh(' },
        { label: 'cosh', type: 'fn', arg: 'cosh(' },
        { label: 'tanh', type: 'fn', arg: 'tanh(' },
        { label: 'ln', type: 'fn', arg: 'ln(' },
        { label: 'log', type: 'fn', arg: 'log(' },
      ],
      [
        { label: '√', type: 'fn', arg: '√(' },
        { label: 'x²', type: 'post', arg: '^2' },
        { label: 'xʸ', type: 'op', arg: '^' },
        { label: 'x!', type: 'post', arg: '!' },
        { label: '|x|', type: 'fn', arg: 'abs(' },
      ],
    ];
  }
  if (uiState.isSecondPage) {
    return [
      [
        { label: 'sin⁻¹', type: 'fn', arg: 'asin(' },
        { label: 'cos⁻¹', type: 'fn', arg: 'acos(' },
        { label: 'tan⁻¹', type: 'fn', arg: 'atan(' },
        { label: 'logₙ', type: 'fn', arg: 'logBase(' },
        { label: '1/x', type: 'recip' },
      ],
      [
        { label: '∛', type: 'fn', arg: '∛(' },
        { label: 'x³', type: 'post', arg: '^3' },
        { label: 'ʸ√x', type: 'fn', arg: 'nroot(' },
        { label: 'x!', type: 'post', arg: '!' },
        { label: '|x|', type: 'fn', arg: 'abs(' },
      ],
    ];
  }
  return [
    [
      { label: 'sin', type: 'fn', arg: 'sin(' },
      { label: 'cos', type: 'fn', arg: 'cos(' },
      { label: 'tan', type: 'fn', arg: 'tan(' },
      { label: 'ln', type: 'fn', arg: 'ln(' },
      { label: 'log', type: 'fn', arg: 'log(' },
    ],
    [
      { label: '√', type: 'fn', arg: '√(' },
      { label: 'x²', type: 'post', arg: '^2' },
      { label: 'xʸ', type: 'op', arg: '^' },
      { label: 'π', type: 'const', arg: 'π' },
      { label: 'e', type: 'const', arg: 'e' },
    ],
  ];
}

export function mountCalculatorView(container, { calcStore, onOpenHistory, onOpenSettings, onCopyResult }) {
  container.innerHTML = `
    <div class="screen-container">
      <div class="calc-layout">
        <header class="top-bar">
          <h1 class="screen-title">Calculator</h1>
          <div class="top-bar-actions">
            <button type="button" class="sci-pill-btn" data-action="toggle-sci" data-testid="toggle_scientific_button" aria-label="Toggle scientific keypad">
              <span class="sci-pill-icon">${Icons.functions()}</span>
              <span>Sci</span>
            </button>
            <button type="button" class="icon-btn" data-action="open-history" data-testid="open_history_button" aria-label="Calculation history" title="History">
              ${Icons.history()}
            </button>
            <button type="button" class="icon-btn" data-action="open-settings" data-testid="open_settings_button" aria-label="Open settings" title="Settings">
              ${Icons.settings()}
            </button>
          </div>
        </header>

        <section class="calc-display" aria-live="polite">
          <div class="calc-status-row">
            <div data-slot="angle-pill">
              <button type="button" class="status-pill angle is-hidden" data-action="toggle-angle" data-testid="angle_mode_indicator">DEG</button>
            </div>
            <div data-slot="memory-pill">
              <div class="status-pill memory tnum is-hidden" data-testid="memory_active_indicator"></div>
            </div>
          </div>
          <div class="calc-readout-wrap">
            <div class="expr-scroll" data-slot="expr-scroll">
              <div class="calc-expression tnum muted" data-slot="expr-text" data-testid="calc_expression_display">0</div>
            </div>
            <div class="calc-result-row">
              <div data-slot="copy-slot" style="width:44px;display:flex;align-items:center;">
                <button type="button" class="icon-btn is-hidden" style="width:40px;height:40px;min-width:40px;min-height:40px;" data-action="copy-result" data-testid="copy_result_button" aria-label="Copy result" title="Copy result">${Icons.copy()}</button>
              </div>
              <div class="calc-result tnum" data-slot="result-text" data-testid="calc_result_display"></div>
            </div>
          </div>
        </section>

        <div class="memory-strip" role="group" aria-label="Memory">
          <button type="button" class="tactile-key mem-key" data-action="mc" data-testid="mem_mc">MC</button>
          <button type="button" class="tactile-key mem-key" data-action="mr" data-testid="mem_mr">MR</button>
          <button type="button" class="tactile-key mem-key" data-action="mplus" data-testid="mem_mplus">M+</button>
          <button type="button" class="tactile-key mem-key" data-action="mminus" data-testid="mem_mminus">M−</button>
        </div>

        <div class="sci-drawer" data-slot="sci-drawer" aria-hidden="true">
          <div class="sci-drawer-inner">
            <div class="sci-mode-strip">
              <button type="button" class="tactile-key sci-toggle-key" data-action="toggle-angle" data-testid="sci_deg_rad">DEG</button>
              <button type="button" class="tactile-key sci-toggle-key" data-action="toggle-2nd" data-testid="sci_2nd">2nd</button>
              <button type="button" class="tactile-key sci-toggle-key" data-action="toggle-hyp" data-testid="sci_hyp">HYP</button>
              <button type="button" class="tactile-key sci-func-key" style="min-height:36px;height:36px;border-radius:10px;" data-action="paren" data-arg="(" data-testid="sci_lparen">(</button>
              <button type="button" class="tactile-key sci-func-key" style="min-height:36px;height:36px;border-radius:10px;" data-action="paren" data-arg=")" data-testid="sci_rparen">)</button>
              <button type="button" class="tactile-key sci-func-key" style="min-height:36px;height:36px;border-radius:10px;" data-action="comma" data-testid="sci_comma">,</button>
            </div>
            <div data-slot="sci-rows" style="display:flex;flex-direction:column;gap:6px;"></div>
          </div>
        </div>

        <div class="standard-keypad" role="group" aria-label="Standard keypad">
          <div class="keypad-row">
            <button type="button" class="tactile-key utility std-key" data-action="ac" data-testid="key_ac">AC</button>
            <button type="button" class="tactile-key utility std-key" data-action="del" data-testid="key_del" aria-label="Delete last character">${Icons.backspace()}</button>
            <button type="button" class="tactile-key utility std-key" data-action="percent" data-testid="key_percent">%</button>
            <button type="button" class="tactile-key operator std-key" data-action="op" data-arg="÷" data-testid="key_div">÷</button>
          </div>
          <div class="keypad-row">
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="7" data-testid="key_7">7</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="8" data-testid="key_8">8</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="9" data-testid="key_9">9</button>
            <button type="button" class="tactile-key operator std-key" data-action="op" data-arg="×" data-testid="key_mul">×</button>
          </div>
          <div class="keypad-row">
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="4" data-testid="key_4">4</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="5" data-testid="key_5">5</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="6" data-testid="key_6">6</button>
            <button type="button" class="tactile-key operator std-key" data-action="op" data-arg="−" data-testid="key_sub">−</button>
          </div>
          <div class="keypad-row">
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="1" data-testid="key_1">1</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="2" data-testid="key_2">2</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="3" data-testid="key_3">3</button>
            <button type="button" class="tactile-key operator std-key" data-action="op" data-arg="+" data-testid="key_add">+</button>
          </div>
          <div class="keypad-row">
            <button type="button" class="tactile-key std-key sign" data-action="sign" data-testid="key_sign">+/−</button>
            <button type="button" class="tactile-key std-key" data-action="digit" data-arg="0" data-testid="key_0">0</button>
            <button type="button" class="tactile-key std-key" data-action="dot" data-testid="key_dot">.</button>
            <button type="button" class="tactile-key accent std-key equals" data-action="equals" data-testid="key_equals">=</button>
          </div>
        </div>
      </div>
    </div>
  `;

  const root = container;
  const sciPillBtn = root.querySelector('[data-action="toggle-sci"]');
  const anglePillBtn = root.querySelector('[data-testid="angle_mode_indicator"]');
  const memPillEl = root.querySelector('[data-testid="memory_active_indicator"]');
  const exprScroll = root.querySelector('[data-slot="expr-scroll"]');
  const exprEl = root.querySelector('[data-slot="expr-text"]');
  const copyBtnEl = root.querySelector('[data-testid="copy_result_button"]');
  const resultEl = root.querySelector('[data-slot="result-text"]');
  const sciDrawer = root.querySelector('[data-slot="sci-drawer"]');
  const sciRowsSlot = root.querySelector('[data-slot="sci-rows"]');
  const angleKeyBtn = root.querySelector('[data-action="toggle-angle"][data-testid="sci_deg_rad"]');
  const secondKeyBtn = root.querySelector('[data-action="toggle-2nd"]');
  const hypKeyBtn = root.querySelector('[data-action="toggle-hyp"]');
  const mcBtn = root.querySelector('[data-action="mc"]');
  const mrBtn = root.querySelector('[data-action="mr"]');

  // Memoize last rendered values to eliminate redundant DOM mutations & layout thrashing
  let prevSciMode = null;
  let prevAngleMode = null;
  let prevHasMemory = null;
  let prevMemoryText = '';
  let prevExprText = '0';
  let prevExprClass = 'calc-expression tnum muted';
  let prevResultText = '';
  let prevResultClass = 'calc-result tnum';
  let prevCanCopy = false;
  let prevSecondPage = null;
  let prevHyperbolic = null;
  let prevSciKeyState = '';
  let scrollRafId = null;

  const scheduleExprScrollRight = () => {
    if (typeof requestAnimationFrame === 'function') {
      if (scrollRafId !== null) return;
      scrollRafId = requestAnimationFrame(() => {
        scrollRafId = null;
        exprScroll.scrollLeft = exprScroll.scrollWidth;
      });
    } else {
      exprScroll.scrollLeft = exprScroll.scrollWidth;
    }
  };

  const renderState = (uiState) => {
    if (uiState.isScientificMode !== prevSciMode) {
      prevSciMode = uiState.isScientificMode;
      sciPillBtn.classList.toggle('active', uiState.isScientificMode);
      sciDrawer.classList.toggle('open', uiState.isScientificMode);
      sciDrawer.setAttribute('aria-hidden', String(!uiState.isScientificMode));
      anglePillBtn.classList.toggle('is-hidden', !uiState.isScientificMode);
    }

    if (uiState.angleMode !== prevAngleMode) {
      prevAngleMode = uiState.angleMode;
      anglePillBtn.textContent = uiState.angleMode;
      angleKeyBtn.textContent = uiState.angleMode;
    }

    if (uiState.hasMemory !== prevHasMemory) {
      prevHasMemory = uiState.hasMemory;
      memPillEl.classList.toggle('is-hidden', !uiState.hasMemory);
      mcBtn.classList.toggle('dim', !uiState.hasMemory);
      mrBtn.classList.toggle('dim', !uiState.hasMemory);
    }

    if (uiState.hasMemory) {
      const memLabel = `M · ${uiState.memoryFormatted}`;
      if (memLabel !== prevMemoryText) {
        prevMemoryText = memLabel;
        memPillEl.textContent = memLabel;
      }
    }

    // Expression readout (update only when text or visual class changes)
    const exprDisplay = uiState.formattedExpression || '0';
    const exprClass = !uiState.formattedExpression
      ? 'calc-expression tnum muted'
      : uiState.isEvaluated
        ? 'calc-expression tnum evaluated'
        : exprDisplay.length > 26
          ? 'calc-expression tnum len-long'
          : exprDisplay.length > 16
            ? 'calc-expression tnum len-mid'
            : 'calc-expression tnum';

    const exprChanged = exprDisplay !== prevExprText;
    if (exprChanged) {
      prevExprText = exprDisplay;
      exprEl.textContent = exprDisplay;
    }
    if (exprClass !== prevExprClass) {
      prevExprClass = exprClass;
      exprEl.className = exprClass;
    }
    if (exprChanged) {
      scheduleExprScrollRight();
    }

    // Result readout
    let resultClass = 'calc-result tnum';
    if (uiState.errorMessage) {
      resultClass = 'calc-result tnum error';
    } else if (!uiState.isEvaluated) {
      resultClass = 'calc-result tnum preview';
    } else {
      const len = uiState.resultText.length;
      if (len > 16) resultClass = 'calc-result tnum len-16';
      else if (len > 12) resultClass = 'calc-result tnum len-12';
      else if (len > 8) resultClass = 'calc-result tnum len-8';
    }

    if (uiState.resultText !== prevResultText) {
      prevResultText = uiState.resultText;
      resultEl.textContent = uiState.resultText;
    }
    if (resultClass !== prevResultClass) {
      prevResultClass = resultClass;
      resultEl.className = resultClass;
    }

    const canCopy = Boolean(uiState.resultText && !uiState.errorMessage);
    if (canCopy !== prevCanCopy) {
      prevCanCopy = canCopy;
      copyBtnEl.classList.toggle('is-hidden', !canCopy);
    }

    if (uiState.isSecondPage !== prevSecondPage) {
      prevSecondPage = uiState.isSecondPage;
      secondKeyBtn.classList.toggle('active', uiState.isSecondPage);
    }
    if (uiState.isHyperbolic !== prevHyperbolic) {
      prevHyperbolic = uiState.isHyperbolic;
      hypKeyBtn.classList.toggle('active', uiState.isHyperbolic);
    }

    const sciKeyState = `${uiState.isSecondPage}-${uiState.isHyperbolic}`;
    if (sciKeyState !== prevSciKeyState) {
      prevSciKeyState = sciKeyState;
      const rows = getSciRows(uiState);
      sciRowsSlot.innerHTML = rows
        .map(
          (row) => `
          <div class="sci-func-row">
            ${row
              .map(
                (item) => `
                <button type="button" class="tactile-key sci-func-key" data-action="sci-${item.type}" data-arg="${escapeHtml(item.arg ?? '')}" data-testid="sci_key_${escapeHtml(item.label)}">
                  ${escapeHtml(item.label)}
                </button>`,
              )
              .join('')}
          </div>`,
        )
        .join('');
    }
  };

  const handleAction = (btn) => {
    const action = btn.dataset.action;
    const arg = btn.dataset.arg ?? '';
    const haptics = calcStore.preferences.hapticEnabled;

    if (action !== 'open-history' && action !== 'open-settings' && action !== 'copy-result') {
      triggerHaptic(haptics);
    }

    switch (action) {
      case 'toggle-sci':
        calcStore.toggleScientificMode();
        break;
      case 'open-history':
        onOpenHistory();
        break;
      case 'open-settings':
        onOpenSettings();
        break;
      case 'copy-result':
        if (calcStore.uiState.resultText && !calcStore.uiState.errorMessage) {
          onCopyResult(calcStore.uiState.resultText);
        }
        break;
      case 'toggle-angle':
        calcStore.toggleAngleMode();
        break;
      case 'toggle-2nd':
        calcStore.toggleSecondPage();
        break;
      case 'toggle-hyp':
        calcStore.toggleHyperbolic();
        break;
      case 'mc':
        calcStore.onMemoryClear();
        break;
      case 'mr':
        calcStore.onMemoryRecall();
        break;
      case 'mplus':
        calcStore.onMemoryAdd();
        break;
      case 'mminus':
        calcStore.onMemorySubtract();
        break;
      case 'ac':
        calcStore.onClearAll();
        break;
      case 'del':
        calcStore.onBackspace();
        break;
      case 'percent':
        calcStore.onPercent();
        break;
      case 'digit':
        calcStore.onDigit(arg);
        break;
      case 'dot':
        calcStore.onDecimal();
        break;
      case 'sign':
        calcStore.onToggleSign();
        break;
      case 'op':
        calcStore.onOperator(arg);
        break;
      case 'equals':
        calcStore.onEquals();
        break;
      case 'paren':
        calcStore.onParen(arg);
        break;
      case 'comma':
        calcStore.onComma();
        break;
      case 'sci-fn':
        calcStore.onScientificFunction(arg);
        break;
      case 'sci-const':
        calcStore.onScientificConstant(arg);
        break;
      case 'sci-post':
        calcStore.onScientificPostfix(arg);
        break;
      case 'sci-op':
        calcStore.onOperator(arg);
        break;
      case 'sci-recip':
        calcStore.onReciprocal();
        break;
    }
  };

  const detachFastInput = attachFastKeypadHandler(root, {
    onAction: handleAction,
    keypadSelector: '.standard-keypad, .memory-strip, .sci-drawer',
  });
  const unsub = calcStore.subscribe(renderState);

  return () => {
    unsub();
    detachFastInput();
    if (scrollRafId !== null && typeof cancelAnimationFrame === 'function') {
      cancelAnimationFrame(scrollRafId);
      scrollRafId = null;
    }
  };
}
