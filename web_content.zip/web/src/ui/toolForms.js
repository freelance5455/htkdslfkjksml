import { NumberFormatter } from '../engine/numberFormatter.js';
import {
  CompoundingFrequencies,
  CompoundingFrequency,
  FractionOp,
  FractionOps,
  MotionTarget,
  MotionTargets,
  SimpleDate,
  ToolsEngine,
} from '../engine/toolsEngine.js';
import { parseStrictDouble } from '../state/converterStore.js';
import { escapeHtml, triggerHaptic } from './haptics.js';
import { Icons } from './icons.js';

function parseStrictInt(raw) {
  const s = (raw ?? '').trim().replaceAll('−', '-');
  if (!/^[+-]?\d+$/.test(s)) return null;
  const n = Number(s);
  return Number.isSafeInteger(n) ? n : null;
}

function parseBigIntOrNull(raw) {
  const s = (raw ?? '').trim().replaceAll('−', '-');
  if (!/^[+-]?\d+$/.test(s)) return null;
  try {
    return BigInt(s);
  } catch {
    return null;
  }
}

function filterNumberText(raw, { allowNegative = false, allowDecimal = true, isListInput = false } = {}) {
  const s = String(raw ?? '').replaceAll('−', '-');
  if (isListInput) {
    return s.replace(/[^0-9.\-, \n;]/g, '');
  }
  return s
    .split('')
    .filter((ch) => (ch >= '0' && ch <= '9') || (allowDecimal && ch === '.') || (allowNegative && ch === '-'))
    .join('');
}

function renderResultRow(label, value, { highlight = false, copyValue = null } = {}) {
  const copyAttr = copyValue !== null ? `data-copy="${escapeHtml(copyValue)}"` : '';
  return `
    <div class="result-row">
      <span class="result-label">${escapeHtml(label)}</span>
      <div class="result-val-wrap">
        <span class="result-val tnum ${highlight ? 'highlight' : ''}">${escapeHtml(value)}</span>
        ${
          copyValue !== null
            ? `<button type="button" class="icon-btn" style="width:40px;height:40px;min-width:40px;min-height:40px;" ${copyAttr} aria-label="Copy result" title="Copy">${Icons.copy()}</button>`
            : ''
        }
      </div>
    </div>`;
}

function renderField({ id, label, value, placeholder = '0', type = 'text', inputmode = 'decimal', min = null, max = null }) {
  const extra =
    type === 'date'
      ? `type="date"`
      : `type="text" inputmode="${inputmode}"`;
  const minMax =
    `${min !== null ? `min="${min}"` : ''} ${max !== null ? `max="${max}"` : ''}`;
  return `
    <div class="field-group">
      <label class="field-label" for="tool-field-${id}">${escapeHtml(label)}</label>
      <input id="tool-field-${id}" class="aether-input" ${extra} ${minMax} data-field="${id}" value="${escapeHtml(value)}" placeholder="${escapeHtml(placeholder)}" />
    </div>`;
}

function renderChips(groupKey, options, selectedKey) {
  return `
    <div class="chip-wrap" data-chip-group="${groupKey}">
      ${options
        .map(
          (opt) => `
          <button type="button" class="aether-chip ${opt.key === selectedKey ? 'selected' : ''}" data-chip="${groupKey}" data-key="${escapeHtml(opt.key)}">
            ${escapeHtml(opt.label)}
          </button>`,
        )
        .join('')}
    </div>`;
}

function getDefaultState(toolId) {
  const today = SimpleDate.today();
  switch (toolId.name) {
    case 'PERCENT_OF':
      return { pct: '15', num: '200' };
    case 'PERCENT_INCREASE':
      return { modeByValue: true, first: '100', second: '15' };
    case 'PERCENT_DECREASE':
      return { modeByValue: true, first: '100', second: '15' };
    case 'PERCENT_DIFFERENCE':
      return { valA: '80', valB: '100' };
    case 'SIMPLE_INTEREST':
      return { principal: '10000', rate: '6.5', years: '3' };
    case 'COMPOUND_INTEREST':
      return { principal: '10000', rate: '8', years: '5', freq: CompoundingFrequency.MONTHLY.name };
    case 'EMI_CALCULATOR':
      return { loan: '250000', rate: '8.5', tenure: '60', inYears: false };
    case 'DISCOUNT':
      return { price: '120', disc: '25' };
    case 'SALE_PRICE':
      return { price: '150', disc: '20', tax: '8' };
    case 'TAX_GST':
      return { amount: '1000', taxPct: '18', inclusive: false };
    case 'TIP':
      return { bill: '64', tipPct: '18' };
    case 'SPLIT_BILL':
      return { bill: '120', tipPct: '15', people: '4' };
    case 'RATIO':
      return { valA: '16', valB: '9', scaleC: '1920' };
    case 'AVERAGE':
      return { rawList: '12, 18, 24, 30, 16' };
    case 'FRACTION':
      return { n1: '3', d1: '4', n2: '2', d2: '5', op: FractionOp.ADD.name };
    case 'TIME_DURATION':
      return { sH: '9', sM: '30', eH: '17', eM: '45' };
    case 'DATE_DIFFERENCE':
      return {
        startDate: new SimpleDate(today.year, 1, 1).formatted(),
        endDate: today.formatted(),
      };
    case 'AGE':
      return {
        birthDate: new SimpleDate(Math.max(1900, today.year - 25), 6, 15).formatted(),
        today: today.formatted(),
      };
    case 'SPEED_DISTANCE_TIME':
      return { target: MotionTarget.SPEED.name, first: '180', second: '2.5' };
    case 'FUEL_COST':
      return { distance: '320', efficiency: '16', price: '1.65' };
    case 'UNIT_PRICE':
      return { pA: '4.99', qA: '500', pB: '7.49', qB: '1000' };
    default:
      return {};
  }
}

export function renderToolResultHtml(toolId, state, formatting) {
  const fmt = (n) => NumberFormatter.formatDouble(n, formatting);

  switch (toolId.name) {
    case 'PERCENT_OF': {
      const p = parseStrictDouble(state.pct);
      const n = parseStrictDouble(state.num);
      const res = p !== null && n !== null ? ToolsEngine.percentOf(p, n) : null;
      const formatted = res !== null ? fmt(res) : '—';
      return renderResultRow('Result', formatted, { highlight: true, copyValue: res !== null ? formatted : null });
    }

    case 'PERCENT_INCREASE': {
      const a = parseStrictDouble(state.first);
      const b = parseStrictDouble(state.second);
      if (a === null || b === null) return renderResultRow('Result', '—', { highlight: true });
      if (state.modeByValue) {
        const [finalVal, delta] = ToolsEngine.increaseByPercent(a, b);
        const fFinal = fmt(finalVal);
        const fDelta = fmt(delta);
        return (
          renderResultRow('New value', fFinal, { highlight: true, copyValue: fFinal }) +
          '<div class="hairline-divider"></div>' +
          renderResultRow('Increase amount', `+${fDelta}`)
        );
      }
      const change = ToolsEngine.percentChange(a, b);
      if (!change) return '<div class="error-text">Original value cannot be zero.</div>';
      const fPct = `${fmt(change[0])}%`;
      const fDelta = fmt(change[1]);
      return (
        renderResultRow('Percentage change', fPct, { highlight: true, copyValue: fPct }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Difference', fDelta)
      );
    }

    case 'PERCENT_DECREASE': {
      const a = parseStrictDouble(state.first);
      const b = parseStrictDouble(state.second);
      if (a === null || b === null) return renderResultRow('Result', '—', { highlight: true });
      if (state.modeByValue) {
        const [finalVal, delta] = ToolsEngine.decreaseByPercent(a, b);
        const fFinal = fmt(finalVal);
        const fDelta = fmt(delta);
        return (
          renderResultRow('New value', fFinal, { highlight: true, copyValue: fFinal }) +
          '<div class="hairline-divider"></div>' +
          renderResultRow('Decrease amount', `−${fDelta}`)
        );
      }
      const change = ToolsEngine.percentChange(a, b);
      if (!change) return '<div class="error-text">Original value cannot be zero.</div>';
      const dropPct = -change[0];
      const fPct = `${fmt(dropPct)}%`;
      const fDelta = fmt(a - b);
      return (
        renderResultRow('Percentage decrease', fPct, { highlight: true, copyValue: fPct }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Decrease amount', fDelta)
      );
    }

    case 'PERCENT_DIFFERENCE': {
      const a = parseStrictDouble(state.valA);
      const b = parseStrictDouble(state.valB);
      if (a === null || b === null) return renderResultRow('Percentage difference', '—', { highlight: true });
      const diff = ToolsEngine.percentDifference(a, b);
      const fDiff = `${fmt(diff)}%`;
      return (
        renderResultRow('Percentage difference', fDiff, { highlight: true, copyValue: fDiff }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Absolute difference', fmt(Math.abs(a - b)))
      );
    }

    case 'SIMPLE_INTEREST': {
      const p = parseStrictDouble(state.principal);
      const r = parseStrictDouble(state.rate);
      const t = parseStrictDouble(state.years);
      if (p === null || r === null || t === null) return renderResultRow('Total amount', '—', { highlight: true });
      const [interest, total] = ToolsEngine.simpleInterest(p, r, t);
      const fInt = fmt(interest);
      const fTot = fmt(total);
      return (
        renderResultRow('Total amount', fTot, { highlight: true, copyValue: fTot }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Total interest', fInt, { copyValue: fInt })
      );
    }

    case 'COMPOUND_INTEREST': {
      const p = parseStrictDouble(state.principal);
      const r = parseStrictDouble(state.rate);
      const t = parseStrictDouble(state.years);
      const freq = CompoundingFrequencies.find((f) => f.name === state.freq) ?? CompoundingFrequency.MONTHLY;
      if (p === null || r === null || t === null) return renderResultRow('Maturity value', '—', { highlight: true });
      const [interest, total] = ToolsEngine.compoundInterest(p, r, t, freq);
      const fInt = fmt(interest);
      const fTot = fmt(total);
      return (
        renderResultRow('Maturity value', fTot, { highlight: true, copyValue: fTot }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Compound interest', fInt, { copyValue: fInt })
      );
    }

    case 'EMI_CALCULATOR': {
      const p = parseStrictDouble(state.loan);
      const r = parseStrictDouble(state.rate);
      const tVal = parseStrictDouble(state.tenure);
      const months = tVal !== null ? Math.trunc(state.inYears ? tVal * 12 : tVal) : 0;
      const res = p !== null && r !== null && months > 0 ? ToolsEngine.calculateEmi(p, r, months) : null;
      if (!res) return renderResultRow('Monthly EMI', '—', { highlight: true });
      const fEmi = fmt(res[0]);
      const fInt = fmt(res[1]);
      const fTot = fmt(res[2]);
      return (
        renderResultRow('Monthly EMI', fEmi, { highlight: true, copyValue: fEmi }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Total interest', fInt, { copyValue: fInt }) +
        renderResultRow('Total payment', fTot, { copyValue: fTot })
      );
    }

    case 'DISCOUNT': {
      const p = parseStrictDouble(state.price);
      const d = parseStrictDouble(state.disc);
      if (p === null || d === null) return renderResultRow('Final price', '—', { highlight: true });
      const [saved, finalPrice] = ToolsEngine.discount(p, d);
      const fFinal = fmt(finalPrice);
      const fSaved = fmt(saved);
      return (
        renderResultRow('Final price', fFinal, { highlight: true, copyValue: fFinal }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('You save', fSaved, { copyValue: fSaved })
      );
    }

    case 'SALE_PRICE': {
      const p = parseStrictDouble(state.price);
      const d = parseStrictDouble(state.disc);
      const t = parseStrictDouble(state.tax);
      if (p === null || d === null || t === null) return renderResultRow('Checkout price', '—', { highlight: true });
      const [saved, taxAmt, total] = ToolsEngine.salePrice(p, d, t);
      const fTot = fmt(total);
      return (
        renderResultRow('Checkout price', fTot, { highlight: true, copyValue: fTot }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Discount savings', fmt(saved)) +
        renderResultRow('Tax added', fmt(taxAmt))
      );
    }

    case 'TAX_GST': {
      const a = parseStrictDouble(state.amount);
      const r = parseStrictDouble(state.taxPct);
      if (a === null || r === null) return renderResultRow('Result', '—', { highlight: true });
      const [base, tax, total] = ToolsEngine.taxGst(a, r, state.inclusive);
      const fTot = fmt(total);
      const fTax = fmt(tax);
      const fBase = fmt(base);
      return (
        renderResultRow(state.inclusive ? 'Net base price' : 'Total with tax', state.inclusive ? fBase : fTot, {
          highlight: true,
          copyValue: state.inclusive ? fBase : fTot,
        }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Tax / GST amount', fTax, { copyValue: fTax }) +
        renderResultRow(state.inclusive ? 'Gross total' : 'Net base price', state.inclusive ? fTot : fBase)
      );
    }

    case 'TIP': {
      const b = parseStrictDouble(state.bill);
      const t = parseStrictDouble(state.tipPct);
      const res = b !== null && t !== null ? ToolsEngine.tipAndSplit(b, t, 1) : null;
      if (!res) return renderResultRow('Total bill', '—', { highlight: true });
      const fTot = fmt(res[1]);
      const fTip = fmt(res[0]);
      return (
        renderResultRow('Total bill', fTot, { highlight: true, copyValue: fTot }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Tip amount', fTip, { copyValue: fTip })
      );
    }

    case 'SPLIT_BILL': {
      const b = parseStrictDouble(state.bill);
      const t = parseStrictDouble(state.tipPct);
      const p = parseStrictInt(state.people);
      const res = b !== null && t !== null && p !== null ? ToolsEngine.tipAndSplit(b, t, p) : null;
      if (!res) return renderResultRow('Each person pays', '—', { highlight: true });
      const fEach = fmt(res[2]);
      const fTot = fmt(res[1]);
      const fTip = fmt(res[0]);
      return (
        renderResultRow('Each person pays', fEach, { highlight: true, copyValue: fEach }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Tip amount', fTip) +
        renderResultRow('Grand total', fTot)
      );
    }

    case 'RATIO': {
      const a = parseBigIntOrNull(state.valA);
      const b = parseBigIntOrNull(state.valB);
      const c = parseStrictDouble(state.scaleC);
      const res = a !== null && b !== null ? ToolsEngine.ratio(a, b, c) : null;
      if (!res) return renderResultRow('Simplified ratio', '—', { highlight: true });
      const simp = `${res[0][0]} : ${res[0][1]}`;
      let html = renderResultRow('Simplified ratio', simp, { highlight: true, copyValue: simp });
      if (res[1] !== null) {
        const fScaled = fmt(res[1]);
        html +=
          '<div class="hairline-divider"></div>' +
          renderResultRow(`Scaled D (${state.scaleC} : D)`, fScaled, { copyValue: fScaled });
      }
      return html;
    }

    case 'AVERAGE': {
      const parsed = state.rawList
        .split(/[, \n;]+/)
        .map((tok) => parseStrictDouble(tok))
        .filter((v) => v !== null);
      const stats = ToolsEngine.average(parsed);
      if (!stats) return '<div style="font-size:14px;color:var(--text-secondary);">Enter one or more numbers above.</div>';
      const fMean = fmt(stats.mean);
      return (
        renderResultRow('Mean (Average)', fMean, { highlight: true, copyValue: fMean }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Median', fmt(stats.median)) +
        renderResultRow(`Sum (${stats.count} values)`, fmt(stats.sum)) +
        renderResultRow('Min / Max', `${fmt(stats.min)} / ${fmt(stats.max)}`)
      );
    }

    case 'FRACTION': {
      const ln1 = parseBigIntOrNull(state.n1);
      const ld1 = parseBigIntOrNull(state.d1);
      const ln2 = parseBigIntOrNull(state.n2);
      const ld2 = parseBigIntOrNull(state.d2);
      const op = FractionOps.find((o) => o.name === state.op) ?? FractionOp.ADD;
      const res =
        ln1 !== null && ld1 !== null && ln2 !== null && ld2 !== null
          ? ToolsEngine.fraction(ln1, ld1, ln2, ld2, op)
          : null;
      if (!res) return '<div class="error-text">Denominators (and divisor) cannot be zero.</div>';
      const fracStr = res.denominator === 1n ? `${res.numerator}` : `${res.numerator}/${res.denominator}`;
      let html =
        renderResultRow('Simplified fraction', fracStr, { highlight: true, copyValue: fracStr }) +
        '<div class="hairline-divider"></div>';
      if (res.mixedWhole !== 0n && res.mixedRemNum !== 0n) {
        html += renderResultRow('Mixed number', `${res.mixedWhole} ${res.mixedRemNum}/${res.denominator}`);
      }
      html += renderResultRow('Decimal', fmt(res.decimal));
      return html;
    }

    case 'TIME_DURATION': {
      const sH = parseStrictInt(state.sH) ?? -1;
      const sM = parseStrictInt(state.sM) ?? -1;
      const eH = parseStrictInt(state.eH) ?? -1;
      const eM = parseStrictInt(state.eM) ?? -1;
      const res = ToolsEngine.timeDuration(sH, sM, eH, eM);
      if (!res) return '<div class="error-text">Enter valid 24-hour times (0–23 and 0–59).</div>';
      const durStr = `${res[0]}h ${res[1]}m`;
      return (
        renderResultRow('Elapsed duration', durStr, { highlight: true, copyValue: durStr }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Total minutes', `${res[2]} min`) +
        renderResultRow('Decimal hours', fmt(res[2] / 60.0))
      );
    }

    case 'DATE_DIFFERENCE': {
      const sDate = SimpleDate.parseIso(state.startDate);
      const eDate = SimpleDate.parseIso(state.endDate);
      if (!sDate || !eDate) return renderResultRow('Total days', '—', { highlight: true });
      const diff = ToolsEngine.dateDifference(sDate, eDate);
      const daysStr = `${diff.totalDays} days`;
      return (
        renderResultRow('Total days', daysStr, { highlight: true, copyValue: daysStr }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Breakdown', `${diff.years}y ${diff.months}m ${diff.days}d`) +
        renderResultRow('Weeks', `${diff.weeks} wk ${diff.remainingDays} d`)
      );
    }

    case 'AGE': {
      const bDate = SimpleDate.parseIso(state.birthDate);
      const tDate = SimpleDate.parseIso(state.today) ?? SimpleDate.today();
      if (!bDate) return renderResultRow('Age', '—', { highlight: true });
      const age = ToolsEngine.calculateAge(bDate, tDate);
      if (!age) return '<div class="error-text">Birth date cannot be in the future.</div>';
      const ageStr = `${age.years} yrs ${age.months} mos ${age.days} d`;
      return (
        renderResultRow('Age', ageStr, { highlight: true, copyValue: ageStr }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Total days lived', fmt(age.totalDays)) +
        renderResultRow('Next birthday in', `${age.daysUntilNextBirthday} days`)
      );
    }

    case 'SPEED_DISTANCE_TIME': {
      const target = MotionTargets.find((t) => t.name === state.target) ?? MotionTarget.SPEED;
      const meta =
        target.name === 'SPEED'
          ? ['Speed', 'per hour']
          : target.name === 'DISTANCE'
            ? ['Distance', 'units']
            : ['Time', 'hours'];
      const a = parseStrictDouble(state.first);
      const b = parseStrictDouble(state.second);
      const res = a !== null && b !== null ? ToolsEngine.solveMotion(target, a, b) : null;
      if (res === null) return renderResultRow(meta[0], '—', { highlight: true });
      const formatted = `${fmt(res)} ${meta[1]}`;
      return renderResultRow(meta[0], formatted, { highlight: true, copyValue: formatted });
    }

    case 'FUEL_COST': {
      const d = parseStrictDouble(state.distance);
      const e = parseStrictDouble(state.efficiency);
      const p = parseStrictDouble(state.price);
      const res = d !== null && e !== null && p !== null ? ToolsEngine.fuelCost(d, e, p) : null;
      if (!res) return renderResultRow('Total fuel cost', '—', { highlight: true });
      const fCost = fmt(res[1]);
      const fFuel = fmt(res[0]);
      return (
        renderResultRow('Total fuel cost', fCost, { highlight: true, copyValue: fCost }) +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Fuel needed', `${fFuel} L / gal`)
      );
    }

    case 'UNIT_PRICE': {
      const pa = parseStrictDouble(state.pA);
      const qa = parseStrictDouble(state.qA);
      const pb = parseStrictDouble(state.pB);
      const qb = parseStrictDouble(state.qB);
      const res =
        pa !== null && qa !== null && pb !== null && qb !== null
          ? ToolsEngine.unitPriceCompare(pa, qa, pb, qb)
          : null;
      if (!res) return renderResultRow('Comparison', '—', { highlight: true });
      let winner;
      if (res[0] < res[1]) winner = `Option A is cheaper (${fmt(res[2])}% less)`;
      else if (res[1] < res[0]) winner = `Option B is cheaper (${fmt(res[2])}% less)`;
      else winner = 'Both options have equal unit price';
      return (
        `<div style="font-size:16px;font-weight:600;color:var(--lavender);">${escapeHtml(winner)}</div>` +
        '<div class="hairline-divider"></div>' +
        renderResultRow('Option A / unit', fmt(res[0])) +
        renderResultRow('Option B / unit', fmt(res[1]))
      );
    }

    default:
      return '';
  }
}

function buildToolBodyHtml(toolId, state) {
  switch (toolId.name) {
    case 'PERCENT_OF':
      return (
        renderField({ id: 'pct', label: 'Percentage (%)', value: state.pct }) +
        renderField({ id: 'num', label: 'Of number', value: state.num })
      );

    case 'PERCENT_INCREASE':
      return (
        renderChips(
          'mode',
          [
            { key: 'byval', label: 'Add X%' },
            { key: 'fromto', label: 'From → To' },
          ],
          state.modeByValue ? 'byval' : 'fromto',
        ) +
        renderField({
          id: 'first',
          label: state.modeByValue ? 'Base value' : 'Original value',
          value: state.first,
        }) +
        renderField({
          id: 'second',
          label: state.modeByValue ? 'Increase (%)' : 'New value',
          value: state.second,
        })
      );

    case 'PERCENT_DECREASE':
      return (
        renderChips(
          'mode',
          [
            { key: 'byval', label: 'Subtract X%' },
            { key: 'fromto', label: 'From → To' },
          ],
          state.modeByValue ? 'byval' : 'fromto',
        ) +
        renderField({
          id: 'first',
          label: state.modeByValue ? 'Base value' : 'Original value',
          value: state.first,
        }) +
        renderField({
          id: 'second',
          label: state.modeByValue ? 'Decrease (%)' : 'New value',
          value: state.second,
        })
      );

    case 'PERCENT_DIFFERENCE':
      return (
        renderField({ id: 'valA', label: 'Value A', value: state.valA }) +
        renderField({ id: 'valB', label: 'Value B', value: state.valB })
      );

    case 'SIMPLE_INTEREST':
      return (
        renderField({ id: 'principal', label: 'Principal amount', value: state.principal }) +
        renderField({ id: 'rate', label: 'Annual interest rate (%)', value: state.rate }) +
        renderField({ id: 'years', label: 'Time period (years)', value: state.years })
      );

    case 'COMPOUND_INTEREST':
      return (
        renderField({ id: 'principal', label: 'Principal amount', value: state.principal }) +
        renderField({ id: 'rate', label: 'Annual interest rate (%)', value: state.rate }) +
        renderField({ id: 'years', label: 'Time period (years)', value: state.years }) +
        '<div class="field-label">Compounding frequency</div>' +
        renderChips(
          'freq',
          CompoundingFrequencies.map((f) => ({ key: f.name, label: f.label })),
          state.freq,
        )
      );

    case 'EMI_CALCULATOR':
      return (
        renderField({ id: 'loan', label: 'Loan amount', value: state.loan }) +
        renderField({ id: 'rate', label: 'Annual interest rate (%)', value: state.rate }) +
        renderChips(
          'tenureUnit',
          [
            { key: 'months', label: 'Months' },
            { key: 'years', label: 'Years' },
          ],
          state.inYears ? 'years' : 'months',
        ) +
        renderField({
          id: 'tenure',
          label: state.inYears ? 'Tenure (years)' : 'Tenure (months)',
          value: state.tenure,
        })
      );

    case 'DISCOUNT':
      return (
        renderField({ id: 'price', label: 'Original price', value: state.price }) +
        renderField({ id: 'disc', label: 'Discount (%)', value: state.disc })
      );

    case 'SALE_PRICE':
      return (
        renderField({ id: 'price', label: 'Tag price', value: state.price }) +
        renderField({ id: 'disc', label: 'Discount (%)', value: state.disc }) +
        renderField({ id: 'tax', label: 'Sales tax (%)', value: state.tax })
      );

    case 'TAX_GST':
      return (
        renderChips(
          'taxMode',
          [
            { key: 'excl', label: 'Exclusive (+Tax)' },
            { key: 'incl', label: 'Inclusive (Extract)' },
          ],
          state.inclusive ? 'incl' : 'excl',
        ) +
        renderField({
          id: 'amount',
          label: state.inclusive ? 'Gross amount' : 'Net amount',
          value: state.amount,
        }) +
        renderField({ id: 'taxPct', label: 'Tax / GST rate (%)', value: state.taxPct })
      );

    case 'TIP':
      return (
        renderField({ id: 'bill', label: 'Bill amount', value: state.bill }) +
        renderChips(
          'tipPreset',
          ['10', '15', '18', '20', '25'].map((p) => ({ key: p, label: `${p}%` })),
          state.tipPct,
        ) +
        renderField({ id: 'tipPct', label: 'Tip (%)', value: state.tipPct })
      );

    case 'SPLIT_BILL':
      return (
        renderField({ id: 'bill', label: 'Bill subtotal', value: state.bill }) +
        renderField({ id: 'tipPct', label: 'Tip (%)', value: state.tipPct }) +
        renderField({ id: 'people', label: 'Number of people', value: state.people, inputmode: 'numeric' })
      );

    case 'RATIO':
      return (
        `<div class="form-row-2">
          ${renderField({ id: 'valA', label: 'Ratio A', value: state.valA, inputmode: 'numeric' })}
          ${renderField({ id: 'valB', label: 'Ratio B', value: state.valB, inputmode: 'numeric' })}
        </div>` +
        renderField({ id: 'scaleC', label: 'Scale A to C (optional)', value: state.scaleC })
      );

    case 'AVERAGE':
      return `
        <div class="field-group">
          <label class="field-label" for="tool-field-rawList">Numbers (comma or space separated)</label>
          <textarea id="tool-field-rawList" class="aether-textarea" data-field="rawList" rows="2">${escapeHtml(state.rawList)}</textarea>
        </div>`;

    case 'FRACTION':
      return (
        `<div class="form-row-2">
          ${renderField({ id: 'n1', label: 'Num 1', value: state.n1, inputmode: 'numeric' })}
          ${renderField({ id: 'd1', label: 'Den 1', value: state.d1, inputmode: 'numeric' })}
        </div>` +
        renderChips(
          'fracOp',
          FractionOps.map((o) => ({ key: o.name, label: o.symbol })),
          state.op,
        ) +
        `<div class="form-row-2">
          ${renderField({ id: 'n2', label: 'Num 2', value: state.n2, inputmode: 'numeric' })}
          ${renderField({ id: 'd2', label: 'Den 2', value: state.d2, inputmode: 'numeric' })}
        </div>`
      );

    case 'TIME_DURATION':
      return (
        '<div class="field-label">Start time (24h)</div>' +
        `<div class="form-row-2">
          ${renderField({ id: 'sH', label: 'Hour (0–23)', value: state.sH, inputmode: 'numeric' })}
          ${renderField({ id: 'sM', label: 'Min (0–59)', value: state.sM, inputmode: 'numeric' })}
        </div>` +
        '<div class="field-label">End time (24h)</div>' +
        `<div class="form-row-2">
          ${renderField({ id: 'eH', label: 'Hour (0–23)', value: state.eH, inputmode: 'numeric' })}
          ${renderField({ id: 'eM', label: 'Min (0–59)', value: state.eM, inputmode: 'numeric' })}
        </div>`
      );

    case 'DATE_DIFFERENCE':
      return (
        renderField({ id: 'startDate', label: 'Start date', value: state.startDate, type: 'date' }) +
        renderField({ id: 'endDate', label: 'End date', value: state.endDate, type: 'date' })
      );

    case 'AGE':
      return (
        renderField({ id: 'birthDate', label: 'Date of birth', value: state.birthDate, type: 'date' }) +
        renderField({ id: 'today', label: 'As of date', value: state.today, type: 'date' })
      );

    case 'SPEED_DISTANCE_TIME': {
      const [label1, label2] =
        state.target === 'SPEED'
          ? ['Distance (km / mi)', 'Time (hours)']
          : state.target === 'DISTANCE'
            ? ['Speed (per hour)', 'Time (hours)']
            : ['Distance', 'Speed (per hour)'];
      return (
        renderChips(
          'motion',
          MotionTargets.map((t) => ({ key: t.name, label: t.label })),
          state.target,
        ) +
        renderField({ id: 'first', label: label1, value: state.first }) +
        renderField({ id: 'second', label: label2, value: state.second })
      );
    }

    case 'FUEL_COST':
      return (
        renderField({ id: 'distance', label: 'Trip distance (km or mi)', value: state.distance }) +
        renderField({ id: 'efficiency', label: 'Efficiency (km/L or mpg)', value: state.efficiency }) +
        renderField({ id: 'price', label: 'Fuel price per L or gal', value: state.price })
      );

    case 'UNIT_PRICE':
      return (
        '<div class="field-label" style="color:var(--lavender);">Option A</div>' +
        `<div class="form-row-2">
          ${renderField({ id: 'pA', label: 'Price A', value: state.pA })}
          ${renderField({ id: 'qA', label: 'Quantity A', value: state.qA })}
        </div>` +
        '<div class="field-label" style="color:var(--lavender);">Option B</div>' +
        `<div class="form-row-2">
          ${renderField({ id: 'pB', label: 'Price B', value: state.pB })}
          ${renderField({ id: 'qB', label: 'Quantity B', value: state.qB })}
        </div>`
      );

    default:
      return '';
  }
}

export function mountToolForm(container, { toolId, preferencesStore, onCopyResult }) {
  const state = getDefaultState(toolId);

  const renderFull = () => {
    container.innerHTML = `
      <div class="tool-form">
        <div data-slot="fields" style="display:flex;flex-direction:column;gap:12px;">
          ${buildToolBodyHtml(toolId, state)}
        </div>
        <div class="aether-card elevated result-card" data-slot="result-card"></div>
      </div>
    `;
    renderResultOnly();
  };

  const renderResultOnly = () => {
    const resultCard = container.querySelector('[data-slot="result-card"]');
    if (!resultCard) return;
    resultCard.innerHTML = renderToolResultHtml(toolId, state, preferencesStore.value.formattingOptions);
  };

  const filterCfgForField = (field) => {
    if (toolId.name === 'DATE_DIFFERENCE' || toolId.name === 'AGE') return null;
    if (field === 'rawList') return { isListInput: true };
    if (['people', 'valA', 'valB', 'n1', 'd1', 'n2', 'd2'].includes(field)) {
      if (toolId.name === 'RATIO' || toolId.name === 'FRACTION') {
        return { allowNegative: true, allowDecimal: false };
      }
      return { allowNegative: false, allowDecimal: false };
    }
    if (['sH', 'sM', 'eH', 'eM'].includes(field)) {
      return { allowNegative: false, allowDecimal: false };
    }
    if (
      ['PERCENT_OF', 'PERCENT_INCREASE', 'PERCENT_DECREASE', 'PERCENT_DIFFERENCE'].includes(
        toolId.name,
      ) ||
      field === 'scaleC'
    ) {
      return { allowNegative: true, allowDecimal: true };
    }
    return { allowNegative: false, allowDecimal: true };
  };

  const onInput = (e) => {
    const input = e.target.closest('[data-field]');
    if (!input) return;
    const field = input.dataset.field;
    const cfg = filterCfgForField(field);
    let val = input.value;
    if (cfg) {
      const cleaned = filterNumberText(val, cfg);
      if (cleaned !== val) {
        val = cleaned;
        input.value = cleaned;
      }
    }
    state[field] = val;
    if (toolId.name === 'TIP' && field === 'tipPct') {
      container.querySelectorAll('[data-chip="tipPreset"]').forEach((c) => {
        c.classList.toggle('selected', c.dataset.key === val);
      });
    }
    renderResultOnly();
  };

  const onClick = (e) => {
    const copyBtn = e.target.closest('[data-copy]');
    if (copyBtn) {
      onCopyResult(copyBtn.dataset.copy);
      return;
    }

    const chip = e.target.closest('[data-chip]');
    if (!chip) return;
    triggerHaptic(preferencesStore.value.hapticEnabled);
    const group = chip.dataset.chip;
    const key = chip.dataset.key;

    if (group === 'mode') {
      state.modeByValue = key === 'byval';
      renderFull();
    } else if (group === 'freq') {
      state.freq = key;
      renderFull();
    } else if (group === 'tenureUnit') {
      state.inYears = key === 'years';
      renderFull();
    } else if (group === 'taxMode') {
      state.inclusive = key === 'incl';
      renderFull();
    } else if (group === 'tipPreset') {
      state.tipPct = key;
      renderFull();
    } else if (group === 'fracOp') {
      state.op = key;
      renderFull();
    } else if (group === 'motion') {
      state.target = key;
      renderFull();
    }
  };

  renderFull();
  container.addEventListener('input', onInput);
  container.addEventListener('click', onClick);
  const unsubPrefs = preferencesStore.subscribe(renderResultOnly);

  return () => {
    unsubPrefs();
    container.removeEventListener('input', onInput);
    container.removeEventListener('click', onClick);
  };
}
