import { NumberGroupingStyleList } from '../engine/numberFormatter.js';
import { AppThemeModes } from '../state/storage.js';
import { escapeHtml, triggerHaptic } from './haptics.js';

export const APP_VERSION_NAME = '1.2';
export const APP_VERSION_CODE = 3;

const PRECISION_OPTIONS = [
  [-1, 'Auto'],
  [0, '0'],
  [2, '2'],
  [4, '4'],
  [6, '6'],
  [8, '8'],
];

export function openSettingsSheet({ preferencesStore }) {
  const existing = document.getElementById('aether-settings-sheet');
  if (existing) existing.remove();

  const backdrop = document.createElement('div');
  backdrop.id = 'aether-settings-sheet';
  backdrop.className = 'sheet-backdrop';
  backdrop.setAttribute('role', 'dialog');
  backdrop.setAttribute('aria-modal', 'true');
  backdrop.setAttribute('aria-label', 'Settings');

  const render = (prefs) => {
    backdrop.innerHTML = `
      <div class="sheet-panel">
        <div class="sheet-handle"></div>
        <div class="sheet-header">
          <h2 class="sheet-title">Settings</h2>
          <button type="button" class="text-btn accent" data-action="close">Done</button>
        </div>

        <div class="aether-card elevated">
          <div class="settings-section-title">Appearance</div>
          <div class="chip-wrap">
            ${AppThemeModes.map(
              (mode) => `
              <button type="button" class="aether-chip ${prefs.themeMode.name === mode.name ? 'selected' : ''}" data-action="theme" data-val="${mode.name}" data-testid="theme_option_${mode.name}">
                ${escapeHtml(mode.label)}
              </button>`,
            ).join('')}
          </div>
        </div>

        <div class="aether-card elevated">
          <div class="settings-row">
            <div>
              <div style="font-size:16px;font-weight:600;color:var(--text-primary);">Haptic feedback</div>
              <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">Subtle tactile vibration on keypad presses</div>
            </div>
            <button type="button" role="switch" aria-checked="${prefs.hapticEnabled}" class="aether-switch ${prefs.hapticEnabled ? 'checked' : ''}" data-action="toggle-haptics" data-testid="haptics_switch" aria-label="Haptic feedback">
              <span class="aether-switch-thumb"></span>
            </button>
          </div>
        </div>

        <div class="aether-card elevated">
          <div class="settings-section-title">Number Formatting</div>
          <div style="font-size:14px;color:var(--text-primary);margin-bottom:8px;">Thousands separator</div>
          <div class="chip-wrap">
            ${NumberGroupingStyleList.map(
              (style) => `
              <button type="button" class="aether-chip ${prefs.groupingStyle.name === style.name ? 'selected' : ''}" data-action="grouping" data-val="${style.name}">
                ${escapeHtml(`${style.label} (${style.example})`)}
              </button>`,
            ).join('')}
          </div>

          <div style="font-size:14px;color:var(--text-primary);margin:16px 0 8px;">Decimal precision</div>
          <div class="chip-wrap">
            ${PRECISION_OPTIONS.map(
              ([val, label]) => `
              <button type="button" class="aether-chip ${prefs.decimalPrecision === val ? 'selected' : ''}" data-action="precision" data-val="${val}">
                ${escapeHtml(label)}
              </button>`,
            ).join('')}
          </div>
        </div>

        <div class="aether-card elevated">
          <div class="settings-section-title">About</div>
          <div class="settings-row">
            <span style="font-size:16px;font-weight:600;color:var(--text-primary);">Calculator</span>
            <span style="font-size:14px;color:var(--text-secondary);" data-testid="settings_app_version">v${APP_VERSION_NAME} (${APP_VERSION_CODE})</span>
          </div>
          <div style="font-size:12px;color:var(--text-secondary);margin-top:6px;">
            All calculations, history, memory, and preferences stay strictly on this device.
          </div>
        </div>
      </div>
    `;
  };

  const close = () => {
    unsub();
    document.removeEventListener('keydown', onKeyDown);
    backdrop.remove();
  };

  const onKeyDown = (e) => {
    if (e.key === 'Escape') close();
  };

  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) {
      close();
      return;
    }
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    const haptics = preferencesStore.value.hapticEnabled;

    if (action === 'close') {
      close();
    } else if (action === 'theme') {
      triggerHaptic(haptics);
      const mode = AppThemeModes.find((m) => m.name === btn.dataset.val);
      if (mode) preferencesStore.setThemeMode(mode);
    } else if (action === 'toggle-haptics') {
      const next = !preferencesStore.value.hapticEnabled;
      preferencesStore.setHapticEnabled(next);
      triggerHaptic(next);
    } else if (action === 'grouping') {
      triggerHaptic(haptics);
      const style = NumberGroupingStyleList.find((g) => g.name === btn.dataset.val);
      if (style) preferencesStore.setGroupingStyle(style);
    } else if (action === 'precision') {
      triggerHaptic(haptics);
      preferencesStore.setDecimalPrecision(Number(btn.dataset.val));
    }
  });

  document.addEventListener('keydown', onKeyDown);
  const unsub = preferencesStore.subscribe(render);
  document.body.appendChild(backdrop);

  return close;
}
