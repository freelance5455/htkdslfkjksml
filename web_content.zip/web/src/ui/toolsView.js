import { ToolGroups, ToolIds } from '../engine/toolsEngine.js';
import { escapeHtml, triggerHaptic } from './haptics.js';
import { Icons } from './icons.js';
import { mountToolForm } from './toolForms.js';

function iconForGroup(groupName) {
  if (groupName === 'PERCENTAGE') return Icons.percent();
  if (groupName === 'FINANCE') return Icons.finance();
  return Icons.calculator(false);
}

export function mountToolsView(container, { preferencesStore, onCopyResult, onDetailStateChange }) {
  let selectedGroup = null;
  let selectedTool = null;
  let unmountForm = null;

  const setTool = (tool) => {
    selectedTool = tool;
    if (onDetailStateChange) onDetailStateChange(tool !== null);
    render();
  };

  const render = () => {
    if (unmountForm) {
      unmountForm();
      unmountForm = null;
    }

    if (selectedTool) {
      container.innerHTML = `
        <div class="screen-container scrollable">
          <div class="tool-detail-header">
            <button type="button" class="icon-btn" data-action="back" data-testid="tool_back_button" aria-label="Navigate back">
              ${Icons.arrowBack()}
            </button>
            <div>
              <div style="font-family:var(--font-display);font-size:18px;font-weight:600;color:var(--text-primary);">${escapeHtml(selectedTool.title)}</div>
              <div class="tool-detail-group">${escapeHtml(selectedTool.group.title)}</div>
            </div>
          </div>
          <div data-slot="tool-form-host"></div>
        </div>
      `;
      const host = container.querySelector('[data-slot="tool-form-host"]');
      unmountForm = mountToolForm(host, {
        toolId: selectedTool,
        preferencesStore,
        onCopyResult,
      });
      return;
    }

    const visibleGroups = selectedGroup ? [selectedGroup] : ToolGroups;

    container.innerHTML = `
      <div class="screen-container scrollable">
        <header class="top-bar" style="min-height:48px;">
          <h1 class="screen-title">Tools</h1>
        </header>

        <div class="chip-strip" style="padding:6px 0;" role="tablist" aria-label="Tool categories">
          <button type="button" class="aether-chip ${selectedGroup === null ? 'selected' : ''}" data-action="filter-group" data-group="ALL">
            All (${ToolIds.length})
          </button>
          ${ToolGroups.map(
            (g) => `
            <button type="button" class="aether-chip ${selectedGroup?.name === g.name ? 'selected' : ''}" data-action="filter-group" data-group="${g.name}">
              ${escapeHtml(g.title)}
            </button>`,
          ).join('')}
        </div>

        <div class="tools-list">
          ${visibleGroups
            .map((group) => {
              const groupTools = ToolIds.filter((t) => t.group.name === group.name);
              return `
                <div class="tool-group-header">${escapeHtml(group.title)}</div>
                ${groupTools
                  .map(
                    (tool) => `
                  <button type="button" class="tool-row" data-action="open-tool" data-tool="${tool.name}" data-testid="tool_row_${tool.name}">
                    <span class="tool-row-icon">${iconForGroup(tool.group.name)}</span>
                    <span class="tool-row-text">
                      <span class="tool-row-title">${escapeHtml(tool.title)}</span>
                      <span class="tool-row-sub">${escapeHtml(tool.subtitle)}</span>
                    </span>
                    <span style="color:var(--text-secondary);display:inline-flex;">${Icons.chevronRight()}</span>
                  </button>`,
                  )
                  .join('')}
              `;
            })
            .join('')}
        </div>
      </div>
    `;
  };

  const onClick = (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn || !container.contains(btn)) return;
    const action = btn.dataset.action;

    if (action === 'back') {
      setTool(null);
    } else if (action === 'filter-group') {
      triggerHaptic(preferencesStore.value.hapticEnabled);
      const name = btn.dataset.group;
      selectedGroup = name === 'ALL' ? null : (ToolGroups.find((g) => g.name === name) ?? null);
      render();
    } else if (action === 'open-tool') {
      const tool = ToolIds.find((t) => t.name === btn.dataset.tool);
      if (tool) setTool(tool);
    }
  };

  render();
  container.addEventListener('click', onClick);

  return {
    unmount() {
      if (unmountForm) unmountForm();
      container.removeEventListener('click', onClick);
    },
    closeToolIfOpen() {
      if (selectedTool) {
        setTool(null);
        return true;
      }
      return false;
    },
  };
}
