import { CalculatorStore } from './state/calculatorStore.js';
import { ConverterStore } from './state/converterStore.js';
import { HistoryStore, PreferencesStore } from './state/storage.js';
import { mountCalculatorView } from './ui/calculatorView.js';
import { mountConverterView } from './ui/converterView.js';
import { openHistorySheet } from './ui/historySheet.js';
import { pulseKeyElement } from './ui/haptics.js';
import { Icons } from './ui/icons.js';
import { openSettingsSheet } from './ui/settingsSheet.js';
import { mountToolsView } from './ui/toolsView.js';

const TABS = [
  { id: 'CALCULATOR', label: 'Calculator', icon: (sel) => Icons.calculator(sel), testTag: 'nav_calculator' },
  { id: 'CONVERT', label: 'Convert', icon: () => Icons.swapHoriz(), testTag: 'nav_convert' },
  { id: 'TOOLS', label: 'Tools', icon: (sel) => Icons.tools(sel), testTag: 'nav_tools' },
];

const THEME_META_COLORS = {
  OLED_DARK: '#0B0B0F',
  AETHER_DARK: '#13131A',
  LIGHT: '#F7F7FA',
};

function applyThemeToDocument(themeMode) {
  const modeName = themeMode?.name ?? 'OLED_DARK';
  document.documentElement.setAttribute('data-theme', modeName);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) {
    meta.setAttribute('content', THEME_META_COLORS[modeName] ?? '#0B0B0F');
  }
}

export function createApp(rootEl) {
  const preferencesStore = new PreferencesStore();
  const historyStore = new HistoryStore();
  const calcStore = new CalculatorStore(historyStore, preferencesStore);
  const converterStore = new ConverterStore();

  let currentTab = 'CALCULATOR';
  let activeRenderedTab = null;
  let toolsController = null;
  let snackbarTimer = null;
  let closeActiveSheet = null;

  preferencesStore.subscribe((prefs) => {
    applyThemeToDocument(prefs.themeMode);
  });

  rootEl.innerHTML = `
    <div class="app-shell">
      <div class="app-body">
        <nav class="nav-rail" aria-label="Main navigation" data-slot="nav-rail"></nav>
        <main class="main-stage" data-slot="main-stage"></main>
      </div>
      <nav class="bottom-nav" aria-label="Main navigation" data-slot="bottom-nav">
        <div class="bottom-nav-inner" data-slot="bottom-nav-inner"></div>
      </nav>
    </div>
  `;

  const navRailEl = rootEl.querySelector('[data-slot="nav-rail"]');
  const bottomNavInnerEl = rootEl.querySelector('[data-slot="bottom-nav-inner"]');
  const stageEl = rootEl.querySelector('[data-slot="main-stage"]');

  const buildNavHtml = () =>
    TABS.map(
      (tab) => `
      <button type="button" class="nav-item" data-nav="${tab.id}" data-testid="${tab.testTag}" aria-current="false">
        <span class="nav-icon">
          <span class="icon-off">${tab.icon(false)}</span>
          <span class="icon-on">${tab.icon(true)}</span>
        </span>
        <span>${tab.label}</span>
      </button>`,
    ).join('');

  const navHtml = buildNavHtml();
  navRailEl.innerHTML = navHtml;
  bottomNavInnerEl.innerHTML = navHtml;

  const navNodesByTab = new Map();
  for (const tab of TABS) {
    navNodesByTab.set(tab.id, Array.from(rootEl.querySelectorAll(`[data-nav="${tab.id}"]`)));
  }

  const panes = new Map();
  const mountedPanes = new Set();
  for (const tab of TABS) {
    const pane = document.createElement('div');
    pane.className = 'tab-pane is-hidden';
    pane.setAttribute('data-pane', tab.id);
    pane.hidden = true;
    stageEl.appendChild(pane);
    panes.set(tab.id, pane);
  }

  const showSnackbar = (message) => {
    const existing = document.getElementById('aether-snackbar');
    if (existing) existing.remove();
    if (snackbarTimer) clearTimeout(snackbarTimer);

    const toast = document.createElement('div');
    toast.id = 'aether-snackbar';
    toast.className = 'snackbar';
    toast.setAttribute('role', 'status');
    toast.textContent = message;
    document.body.appendChild(toast);

    snackbarTimer = setTimeout(() => {
      toast.remove();
    }, 2200);
  };

  const copyToClipboard = async (text) => {
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        await navigator.clipboard.writeText(text);
      } else {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
      }
    } catch {
      // Clipboard fallback ignored if denied in restricted iframe
    }
    showSnackbar(`Copied to clipboard: ${text}`);
  };

  const updateNavButtonGroup = (tabId, selected) => {
    const buttons = navNodesByTab.get(tabId);
    if (!buttons) return;
    for (const btn of buttons) {
      btn.classList.toggle('active', selected);
      btn.setAttribute('aria-current', selected ? 'page' : 'false');
    }
  };

  const ensurePaneMounted = (tabId) => {
    if (mountedPanes.has(tabId)) return;
    mountedPanes.add(tabId);
    const pane = panes.get(tabId);
    if (tabId === 'CALCULATOR') {
      mountCalculatorView(pane, {
        calcStore,
        onOpenHistory: openHistory,
        onOpenSettings: openSettings,
        onCopyResult: copyToClipboard,
      });
    } else if (tabId === 'CONVERT') {
      mountConverterView(pane, {
        converterStore,
        preferencesStore,
        onCopyResult: copyToClipboard,
      });
    } else if (tabId === 'TOOLS') {
      toolsController = mountToolsView(pane, {
        preferencesStore,
        onCopyResult: copyToClipboard,
      });
    }
  };

  const openHistory = () => {
    closeActiveSheet = openHistorySheet({
      historyStore,
      onReuseExpression: (item) => calcStore.reuseHistoryItem(item),
      onCopyResult: copyToClipboard,
      onDeleteItem: (id) => calcStore.deleteHistoryItem(id),
      onClearAll: () => calcStore.clearAllHistory(),
    });
  };

  const openSettings = () => {
    closeActiveSheet = openSettingsSheet({ preferencesStore });
  };

  const renderNav = () => {
    if (activeRenderedTab !== null && activeRenderedTab !== currentTab) {
      updateNavButtonGroup(activeRenderedTab, false);
    }
    updateNavButtonGroup(currentTab, true);
  };

  const renderStage = () => {
    ensurePaneMounted(currentTab);
    if (activeRenderedTab !== null && activeRenderedTab !== currentTab) {
      const prevPane = panes.get(activeRenderedTab);
      if (prevPane) {
        prevPane.classList.add('is-hidden');
        prevPane.hidden = true;
      }
    }
    const activePane = panes.get(currentTab);
    if (activePane) {
      activePane.classList.remove('is-hidden');
      activePane.hidden = false;
    }
    activeRenderedTab = currentTab;
  };

  const selectTab = (tabId) => {
    if (tabId === currentTab) return;
    currentTab = tabId;
    renderNav();
    renderStage();
  };

  rootEl.addEventListener('click', (e) => {
    const navBtn = e.target.closest('[data-nav]');
    if (navBtn) {
      selectTab(navBtn.dataset.nav);
    }
  });

  // Physical keyboard support for desktop & tablets without stealing form input events
  document.addEventListener('keydown', (e) => {
    const tag = e.target?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    if (document.getElementById('aether-history-sheet') || document.getElementById('aether-settings-sheet')) {
      return;
    }
    if (e.metaKey || e.ctrlKey || e.altKey) return;

    const pulse = (testId) => {
      if (testId) pulseKeyElement(rootEl.querySelector(`[data-testid="${testId}"]`));
    };

    const key = e.key;
    if (currentTab === 'CALCULATOR') {
      if (key >= '0' && key <= '9') {
        e.preventDefault();
        calcStore.onDigit(key);
        pulse(`key_${key}`);
      } else if (key === '.') {
        e.preventDefault();
        calcStore.onDecimal();
        pulse('key_dot');
      } else if (key === '+') {
        e.preventDefault();
        calcStore.onOperator('+');
        pulse('key_add');
      } else if (key === '-') {
        e.preventDefault();
        calcStore.onOperator('−');
        pulse('key_sub');
      } else if (key === '*') {
        e.preventDefault();
        calcStore.onOperator('×');
        pulse('key_mul');
      } else if (key === '/') {
        e.preventDefault();
        calcStore.onOperator('÷');
        pulse('key_div');
      } else if (key === '^') {
        e.preventDefault();
        calcStore.onOperator('^');
      } else if (key === '%') {
        e.preventDefault();
        calcStore.onPercent();
        pulse('key_percent');
      } else if (key === '!') {
        e.preventDefault();
        calcStore.onScientificPostfix('!');
      } else if (key === '(') {
        e.preventDefault();
        calcStore.onParen('(');
        pulse('sci_lparen');
      } else if (key === ')') {
        e.preventDefault();
        calcStore.onParen(')');
        pulse('sci_rparen');
      } else if (key === ',') {
        e.preventDefault();
        calcStore.onComma();
        pulse('sci_comma');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        calcStore.onEquals();
        pulse('key_equals');
      } else if (key === 'Backspace') {
        e.preventDefault();
        calcStore.onBackspace();
        pulse('key_del');
      } else if (key === 'Delete') {
        e.preventDefault();
        calcStore.onClearAll();
        pulse('key_ac');
      } else if (key === 'Escape') {
        if (calcStore.uiState.isScientificMode) {
          calcStore.setScientificMode(false);
        } else {
          calcStore.onClearAll();
          pulse('key_ac');
        }
      } else if (key.toLowerCase() === 's') {
        calcStore.toggleScientificMode();
      }
    } else if (currentTab === 'CONVERT') {
      if (key >= '0' && key <= '9') {
        e.preventDefault();
        converterStore.onDigit(key);
        pulse(`conv_key_${key}`);
      } else if (key === '.') {
        e.preventDefault();
        converterStore.onDecimal();
        pulse('conv_key_dot');
      } else if (key === 'Backspace') {
        e.preventDefault();
        converterStore.onBackspace();
        pulse('conv_key_del');
      } else if (key === 'Delete' || key === 'Escape') {
        e.preventDefault();
        converterStore.onClear();
        pulse('conv_key_clear');
      }
    } else if (currentTab === 'TOOLS') {
      if (key === 'Escape') {
        toolsController?.closeToolIfOpen();
      }
    }
  });

  renderNav();
  renderStage();

  return {
    calcStore,
    converterStore,
    preferencesStore,
    historyStore,
    selectTab,
    closeActiveSheet: () => closeActiveSheet?.(),
  };
}

if (typeof document !== 'undefined') {
  const mountEl = document.getElementById('app');
  if (mountEl) {
    createApp(mountEl);
  }
  if (
    typeof navigator !== 'undefined' &&
    'serviceWorker' in navigator &&
    typeof window !== 'undefined' &&
    window.location?.protocol?.startsWith('http')
  ) {
    navigator.serviceWorker.register('./sw.js').catch(() => {
      // Service worker registration skipped on unsupported origins
    });
  }
}
