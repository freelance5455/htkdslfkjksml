export const ToolGroup = Object.freeze({
  PERCENTAGE: Object.freeze({ name: 'PERCENTAGE', title: 'Percentage Tools' }),
  FINANCE: Object.freeze({ name: 'FINANCE', title: 'Finance' }),
  EVERYDAY: Object.freeze({ name: 'EVERYDAY', title: 'Everyday Utilities' }),
});

export const ToolGroups = Object.freeze(Object.values(ToolGroup));

export const ToolId = Object.freeze({
  PERCENT_OF: Object.freeze({ name: 'PERCENT_OF', title: 'Percentage of Number', subtitle: 'Find X% of Y', group: ToolGroup.PERCENTAGE }),
  PERCENT_INCREASE: Object.freeze({ name: 'PERCENT_INCREASE', title: 'Percentage Increase', subtitle: 'Increase or % change up', group: ToolGroup.PERCENTAGE }),
  PERCENT_DECREASE: Object.freeze({ name: 'PERCENT_DECREASE', title: 'Percentage Decrease', subtitle: 'Decrease or % change down', group: ToolGroup.PERCENTAGE }),
  PERCENT_DIFFERENCE: Object.freeze({ name: 'PERCENT_DIFFERENCE', title: 'Percentage Difference', subtitle: 'Symmetric % diff between two values', group: ToolGroup.PERCENTAGE }),

  SIMPLE_INTEREST: Object.freeze({ name: 'SIMPLE_INTEREST', title: 'Simple Interest', subtitle: 'Principal, rate & time', group: ToolGroup.FINANCE }),
  COMPOUND_INTEREST: Object.freeze({ name: 'COMPOUND_INTEREST', title: 'Compound Interest', subtitle: 'Compound growth & yield', group: ToolGroup.FINANCE }),
  EMI_CALCULATOR: Object.freeze({ name: 'EMI_CALCULATOR', title: 'EMI Calculator', subtitle: 'Monthly loan payment schedule', group: ToolGroup.FINANCE }),

  DISCOUNT: Object.freeze({ name: 'DISCOUNT', title: 'Discount Calculator', subtitle: 'Savings & reduced price', group: ToolGroup.EVERYDAY }),
  SALE_PRICE: Object.freeze({ name: 'SALE_PRICE', title: 'Sale Price Calculator', subtitle: 'Discount + tax checkout price', group: ToolGroup.EVERYDAY }),
  TAX_GST: Object.freeze({ name: 'TAX_GST', title: 'Tax / GST Calculator', subtitle: 'Exclusive & inclusive tax breakdown', group: ToolGroup.EVERYDAY }),
  TIP: Object.freeze({ name: 'TIP', title: 'Tip Calculator', subtitle: 'Quick tip & total bill', group: ToolGroup.EVERYDAY }),
  SPLIT_BILL: Object.freeze({ name: 'SPLIT_BILL', title: 'Split Bill Calculator', subtitle: 'Divide total & tip per person', group: ToolGroup.EVERYDAY }),
  RATIO: Object.freeze({ name: 'RATIO', title: 'Ratio Calculator', subtitle: 'Simplify & scale proportions', group: ToolGroup.EVERYDAY }),
  AVERAGE: Object.freeze({ name: 'AVERAGE', title: 'Average Calculator', subtitle: 'Mean, median, min, max & sum', group: ToolGroup.EVERYDAY }),
  FRACTION: Object.freeze({ name: 'FRACTION', title: 'Fraction Calculator', subtitle: 'Exact arithmetic & mixed numbers', group: ToolGroup.EVERYDAY }),
  TIME_DURATION: Object.freeze({ name: 'TIME_DURATION', title: 'Time Duration', subtitle: 'Elapsed hours & minutes', group: ToolGroup.EVERYDAY }),
  DATE_DIFFERENCE: Object.freeze({ name: 'DATE_DIFFERENCE', title: 'Date Difference', subtitle: 'Days & weeks between dates', group: ToolGroup.EVERYDAY }),
  AGE: Object.freeze({ name: 'AGE', title: 'Age Calculator', subtitle: 'Exact age & next birthday', group: ToolGroup.EVERYDAY }),
  SPEED_DISTANCE_TIME: Object.freeze({ name: 'SPEED_DISTANCE_TIME', title: 'Speed · Distance · Time', subtitle: 'Solve for missing motion metric', group: ToolGroup.EVERYDAY }),
  FUEL_COST: Object.freeze({ name: 'FUEL_COST', title: 'Fuel Cost Calculator', subtitle: 'Trip fuel required & cost', group: ToolGroup.EVERYDAY }),
  UNIT_PRICE: Object.freeze({ name: 'UNIT_PRICE', title: 'Unit Price Comparison', subtitle: 'Compare two pack deals', group: ToolGroup.EVERYDAY }),
});

export const ToolIds = Object.freeze(Object.values(ToolId));

export const CompoundingFrequency = Object.freeze({
  YEARLY: Object.freeze({ name: 'YEARLY', label: 'Yearly (1×)', periodsPerYear: 1 }),
  HALF_YEARLY: Object.freeze({ name: 'HALF_YEARLY', label: 'Half-Yearly (2×)', periodsPerYear: 2 }),
  QUARTERLY: Object.freeze({ name: 'QUARTERLY', label: 'Quarterly (4×)', periodsPerYear: 4 }),
  MONTHLY: Object.freeze({ name: 'MONTHLY', label: 'Monthly (12×)', periodsPerYear: 12 }),
});

export const CompoundingFrequencies = Object.freeze(Object.values(CompoundingFrequency));

export const FractionOp = Object.freeze({
  ADD: Object.freeze({ name: 'ADD', symbol: '+' }),
  SUB: Object.freeze({ name: 'SUB', symbol: '−' }),
  MUL: Object.freeze({ name: 'MUL', symbol: '×' }),
  DIV: Object.freeze({ name: 'DIV', symbol: '÷' }),
});

export const FractionOps = Object.freeze(Object.values(FractionOp));

export const MotionTarget = Object.freeze({
  SPEED: Object.freeze({ name: 'SPEED', label: 'Solve Speed' }),
  DISTANCE: Object.freeze({ name: 'DISTANCE', label: 'Solve Distance' }),
  TIME: Object.freeze({ name: 'TIME', label: 'Solve Time' }),
});

export const MotionTargets = Object.freeze(Object.values(MotionTarget));

export class SimpleDate {
  constructor(year, month, day) {
    this.year = year | 0;
    this.month = month | 0;
    this.day = day | 0;
  }

  compareTo(other) {
    if (this.year !== other.year) return this.year < other.year ? -1 : 1;
    if (this.month !== other.month) return this.month < other.month ? -1 : 1;
    if (this.day !== other.day) return this.day < other.day ? -1 : 1;
    return 0;
  }

  formatted() {
    const y =
      this.year < 0
        ? '-' + String(Math.abs(this.year)).padStart(4, '0')
        : String(this.year).padStart(4, '0');
    const m = String(this.month).padStart(2, '0');
    const d = String(this.day).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  static parseIso(isoStr) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec((isoStr ?? '').trim());
    if (!m) return null;
    const year = Number(m[1]);
    const month = Number(m[2]);
    const day = Number(m[3]);
    if (month < 1 || month > 12) return null;
    const maxD = daysInMonth(year, month);
    if (day < 1 || day > maxD) return null;
    return new SimpleDate(year, month, day);
  }

  static today() {
    const d = new Date();
    return new SimpleDate(d.getFullYear(), d.getMonth() + 1, d.getDate());
  }
}

const BIG_INT_LONG_MIN = -9223372036854775808n;
const BIG_INT_LONG_MAX = 9223372036854775807n;

function toExactInt64OrNull(big) {
  if (big < BIG_INT_LONG_MIN || big > BIG_INT_LONG_MAX) return null;
  return big;
}

function gcdBigInt(a, b) {
  let x = a < 0n ? -a : a;
  let y = b < 0n ? -b : b;
  while (y !== 0n) {
    const t = x % y;
    x = y;
    y = t;
  }
  return x < 1n ? 1n : x;
}

function daysInMonth(year, month) {
  switch (month) {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
      return 31;
    case 4:
    case 6:
    case 9:
    case 11:
      return 30;
    case 2:
      return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28;
    default:
      return 30;
  }
}

function clampDay(year, month, day) {
  return new SimpleDate(year, month, Math.min(day, daysInMonth(year, month)));
}

function daysFromCivil(year, month, day) {
  const y = month <= 2 ? year - 1 : year;
  const era = Math.trunc(y >= 0 ? y / 400 : (y - 399) / 400);
  const yoe = y - era * 400;
  const doy = Math.trunc((153 * (month + (month > 2 ? -3 : 9)) + 2) / 5) + day - 1;
  const doe = yoe * 365 + Math.trunc(yoe / 4) - Math.trunc(yoe / 100) + doy;
  return era * 146097 + doe - 719468;
}

function daysBetween(from, to) {
  return (
    daysFromCivil(to.year, to.month, to.day) -
    daysFromCivil(from.year, from.month, from.day)
  );
}

function addMonthsClamped(start, monthsToAdd) {
  const totalMonthZeroBased = start.year * 12 + (start.month - 1) + monthsToAdd;
  const targetYear = Math.floor(totalMonthZeroBased / 12);
  const targetMonth = (totalMonthZeroBased - targetYear * 12) + 1;
  return clampDay(targetYear, targetMonth, start.day);
}

function calendarYmdDiff(from, to) {
  let totalMonths = (to.year - from.year) * 12 + (to.month - from.month);
  let days = to.day - from.day;
  if (totalMonths > 0 && days < 0) {
    totalMonths -= 1;
    const stepped = addMonthsClamped(from, totalMonths);
    days = daysBetween(stepped, to);
  }
  const years = Math.trunc(totalMonths / 12);
  const months = totalMonths % 12;
  return { years, months, days };
}

export const ToolsEngine = {
  percentOf(percent, number) {
    return (percent / 100.0) * number;
  },

  percentChange(from, to) {
    if (from === 0.0) return null;
    const delta = to - from;
    return [(delta / Math.abs(from)) * 100.0, delta];
  },

  increaseByPercent(base, percent) {
    const delta = base * (percent / 100.0);
    return [base + delta, delta];
  },

  decreaseByPercent(base, percent) {
    const delta = base * (percent / 100.0);
    return [base - delta, delta];
  },

  percentDifference(a, b) {
    const halfA = Math.abs(a) / 2.0;
    const halfB = Math.abs(b) / 2.0;
    const avg = halfA + halfB;
    if (avg === 0.0) return 0.0;
    return (Math.abs(a / 2.0 - b / 2.0) / avg) * 200.0;
  },

  simpleInterest(principal, annualRatePct, years) {
    const interest = (principal * annualRatePct * years) / 100.0;
    return [interest, principal + interest];
  },

  compoundInterest(principal, annualRatePct, years, frequency) {
    const n = typeof frequency === 'number' ? frequency : frequency.periodsPerYear;
    const r = annualRatePct / 100.0;
    const ratePerPeriod = r / n;
    let amount;
    if (ratePerPeriod === 0.0) {
      amount = principal;
    } else if (ratePerPeriod > -1.0) {
      amount = principal * Math.exp(n * years * Math.log1p(ratePerPeriod));
    } else {
      amount = principal * Math.pow(1.0 + ratePerPeriod, n * years);
    }
    return [amount - principal, amount];
  },

  calculateEmi(principal, annualRatePct, months) {
    if (
      !Number.isInteger(months) ||
      months <= 0 ||
      !Number.isFinite(principal) ||
      !Number.isFinite(annualRatePct) ||
      principal < 0.0 ||
      annualRatePct < 0.0
    ) {
      return null;
    }
    if (annualRatePct === 0.0) {
      const emi = principal / months;
      return [emi, 0.0, principal];
    }
    const monthlyRate = annualRatePct / 12.0 / 100.0;
    const logGrowth = months * Math.log1p(monthlyRate);
    const denom = Math.expm1(logGrowth);
    if (!Number.isFinite(denom) || logGrowth > 709.0) {
      const emi = principal * monthlyRate;
      const totalPayment = emi * months;
      if (!Number.isFinite(totalPayment)) return null;
      return [emi, totalPayment - principal, totalPayment];
    }
    if (denom === 0.0) {
      const emi = principal / months;
      return [emi, 0.0, principal];
    }
    const factor = 1.0 + denom;
    const emi = (principal * monthlyRate * factor) / denom;
    const totalPayment = emi * months;
    if (!Number.isFinite(emi) || !Number.isFinite(totalPayment)) return null;
    const totalInterest = totalPayment - principal;
    return [emi, totalInterest, totalPayment];
  },

  discount(originalPrice, discountPct) {
    const saved = originalPrice * (discountPct / 100.0);
    return [saved, originalPrice - saved];
  },

  salePrice(originalPrice, discountPct, taxPct) {
    const saved = originalPrice * (discountPct / 100.0);
    const discounted = originalPrice - saved;
    const tax = discounted * (taxPct / 100.0);
    return [saved, tax, discounted + tax];
  },

  taxGst(amount, taxPct, inclusive) {
    if (inclusive) {
      const divisor = 1.0 + taxPct / 100.0;
      const base = divisor === 0.0 ? amount : amount / divisor;
      const tax = amount - base;
      return [base, tax, amount];
    } else {
      const tax = amount * (taxPct / 100.0);
      return [amount, tax, amount + tax];
    }
  },

  tipAndSplit(bill, tipPct, people) {
    if (!Number.isInteger(people) || people <= 0) return null;
    const tip = bill * (tipPct / 100.0);
    const total = bill + tip;
    return [tip, total, total / people];
  },

  ratio(a, b, scaleC = null) {
    const ba = BigInt(a);
    const bb = BigInt(b);
    if (ba === 0n && bb === 0n) return null;
    const g = gcdBigInt(ba, bb);
    let simpA = ba / g;
    let simpB = bb / g;
    if (simpA < 0n && simpB < 0n) {
      simpA = -simpA;
      simpB = -simpB;
    }
    const exactA = toExactInt64OrNull(simpA);
    const exactB = toExactInt64OrNull(simpB);
    if (exactA === null || exactB === null) return null;

    const scaledD =
      scaleC !== null && scaleC !== undefined && Number.isFinite(scaleC) && ba !== 0n
        ? (Number(bb) * scaleC) / Number(ba)
        : null;
    return [[exactA, exactB], scaledD];
  },

  average(numbers) {
    if (!Array.isArray(numbers) || numbers.length === 0 || numbers.some((n) => !Number.isFinite(n))) {
      return null;
    }
    const sorted = [...numbers].sort((x, y) => x - y);
    let sum = 0.0;
    for (const v of numbers) sum += v;
    const mean = sum / numbers.length;
    const mid = Math.floor(sorted.length / 2);
    const median =
      sorted.length % 2 === 0 ? sorted[mid - 1] / 2.0 + sorted[mid] / 2.0 : sorted[mid];
    return {
      count: numbers.length,
      sum,
      mean,
      median,
      min: sorted[0],
      max: sorted[sorted.length - 1],
    };
  },

  fraction(n1, d1, n2, d2, op) {
    const bn1 = BigInt(n1);
    const bd1 = BigInt(d1);
    const bn2 = BigInt(n2);
    const bd2 = BigInt(d2);
    if (bd1 === 0n || bd2 === 0n) return null;

    const opName = typeof op === 'string' ? op : op.name;
    let rawNum;
    let rawDen;
    if (opName === 'ADD') {
      rawNum = bn1 * bd2 + bn2 * bd1;
      rawDen = bd1 * bd2;
    } else if (opName === 'SUB') {
      rawNum = bn1 * bd2 - bn2 * bd1;
      rawDen = bd1 * bd2;
    } else if (opName === 'MUL') {
      rawNum = bn1 * bn2;
      rawDen = bd1 * bd2;
    } else if (opName === 'DIV') {
      if (bn2 === 0n) return null;
      rawNum = bn1 * bd2;
      rawDen = bd1 * bn2;
    } else {
      return null;
    }

    if (rawDen < 0n) {
      rawNum = -rawNum;
      rawDen = -rawDen;
    }
    const g = gcdBigInt(rawNum, rawDen);
    const redNum = rawNum / g;
    const redDen = rawDen / g;
    const num = toExactInt64OrNull(redNum);
    const den = toExactInt64OrNull(redDen);
    if (num === null || den === null) return null;

    const whole = num / den;
    const remRaw = num % den;
    const rem = remRaw < 0n ? -remRaw : remRaw;

    return {
      numerator: num,
      denominator: den,
      mixedWhole: whole,
      mixedRemNum: rem,
      decimal: Number(num) / Number(den),
    };
  },

  timeDuration(startHour, startMinute, endHour, endMinute, overnightIfBefore = true) {
    if (
      !Number.isInteger(startHour) ||
      !Number.isInteger(startMinute) ||
      !Number.isInteger(endHour) ||
      !Number.isInteger(endMinute) ||
      startHour < 0 ||
      startHour > 23 ||
      endHour < 0 ||
      endHour > 23 ||
      startMinute < 0 ||
      startMinute > 59 ||
      endMinute < 0 ||
      endMinute > 59
    ) {
      return null;
    }
    const startTotal = startHour * 60 + startMinute;
    const endTotal = endHour * 60 + endMinute;
    let diff = endTotal - startTotal;
    if (diff < 0 && overnightIfBefore) {
      diff += 24 * 60;
    } else if (diff < 0) {
      diff = Math.abs(diff);
    }
    return [Math.trunc(diff / 60), diff % 60, diff];
  },

  dateDifference(start, end) {
    const [from, to] = start.compareTo(end) > 0 ? [end, start] : [start, end];
    const totalDays = daysBetween(from, to);
    const { years, months, days } = calendarYmdDiff(from, to);
    return {
      totalDays,
      weeks: Math.trunc(totalDays / 7),
      remainingDays: totalDays % 7,
      years,
      months,
      days,
    };
  },

  calculateAge(birthDate, today = SimpleDate.today()) {
    if (birthDate.compareTo(today) > 0) return null;
    const { years, months, days } = calendarYmdDiff(birthDate, today);
    const totalDays = daysBetween(birthDate, today);

    let nextYear = today.year;
    let candidate = clampDay(nextYear, birthDate.month, birthDate.day);
    if (candidate.compareTo(today) <= 0) {
      nextYear++;
      candidate = clampDay(nextYear, birthDate.month, birthDate.day);
    }
    const daysUntilNextBirthday = daysBetween(today, candidate);
    return {
      years,
      months,
      days,
      totalDays,
      daysUntilNextBirthday,
    };
  },

  solveMotion(target, first, second) {
    const tName = typeof target === 'string' ? target : target.name;
    if (tName === 'SPEED') return second <= 0.0 ? null : first / second;
    if (tName === 'DISTANCE') return first < 0.0 || second < 0.0 ? null : first * second;
    if (tName === 'TIME') return second <= 0.0 ? null : first / second;
    return null;
  },

  fuelCost(distance, efficiency, pricePerUnit) {
    if (efficiency <= 0.0 || distance < 0.0 || pricePerUnit < 0.0) return null;
    const fuel = distance / efficiency;
    return [fuel, fuel * pricePerUnit];
  },

  unitPriceCompare(priceA, qtyA, priceB, qtyB) {
    if (qtyA <= 0.0 || qtyB <= 0.0 || priceA < 0.0 || priceB < 0.0) return null;
    const unitA = priceA / qtyA;
    const unitB = priceB / qtyB;
    const higher = Math.max(unitA, unitB);
    const lower = Math.min(unitA, unitB);
    const pctSavings = higher === 0.0 ? 0.0 : ((higher - lower) / higher) * 100.0;
    return [unitA, unitB, pctSavings];
  },
};
