import { BigDecimal, MathContext, RoundingMode } from './bigDecimal.js';

export const NumberGroupingStyle = Object.freeze({
  COMMA: Object.freeze({ name: 'COMMA', label: 'Comma', example: '1,234.56' }),
  SPACE: Object.freeze({ name: 'SPACE', label: 'Space', example: '1 234.56' }),
  NONE: Object.freeze({ name: 'NONE', label: 'None', example: '1234.56' }),
});

export const NumberGroupingStyleList = Object.freeze([
  NumberGroupingStyle.COMMA,
  NumberGroupingStyle.SPACE,
  NumberGroupingStyle.NONE,
]);

export function parseGroupingStyle(name) {
  return NumberGroupingStyleList.find((g) => g.name === name) ?? NumberGroupingStyle.COMMA;
}

export class FormattingOptions {
  constructor({ grouping = NumberGroupingStyle.COMMA, decimalPrecision = -1 } = {}) {
    this.grouping = typeof grouping === 'string' ? parseGroupingStyle(grouping) : grouping;
    this.decimalPrecision = decimalPrecision;
  }
}

const ONE_E_12 = BigDecimal.parse('1e12');
const ONE_E_NEG_8 = BigDecimal.parse('1e-8');
const ONE_E_120 = BigDecimal.parse('1e120');
const ONE_E_NEG_18 = BigDecimal.parse('1e-18');
const MC_12 = new MathContext(12, RoundingMode.HALF_UP);
const MC_120 = new MathContext(120, RoundingMode.HALF_UP);

function clamp(val, min, max) {
  return Math.max(min, Math.min(max, val));
}

function isLetterChar(ch) {
  if (!ch) return false;
  return /\p{L}/u.test(ch);
}

function isDigitChar(ch) {
  return ch >= '0' && ch <= '9';
}

function groupDigitsOnly(num, sep) {
  const dotIdx = num.indexOf('.');
  const intPart = dotIdx >= 0 ? num.slice(0, dotIdx) : num;
  const fracPart = dotIdx >= 0 ? num.slice(dotIdx) : '';
  if (intPart.length <= 3) return intPart + fracPart;

  const out = [];
  let count = 0;
  for (let idx = intPart.length - 1; idx >= 0; idx--) {
    if (count > 0 && count % 3 === 0) {
      out.push(sep);
    }
    out.push(intPart[idx]);
    count++;
  }
  out.reverse();
  return out.join('') + fracPart;
}

function applyGrouping(plain, grouping) {
  const isNeg = plain.startsWith('-');
  const unsigned = isNeg ? plain.slice(1) : plain;
  const gName = typeof grouping === 'string' ? grouping : grouping.name;
  let grouped;
  if (gName === 'NONE') {
    grouped = unsigned;
  } else if (gName === 'COMMA') {
    grouped = groupDigitsOnly(unsigned, ',');
  } else {
    grouped = groupDigitsOnly(unsigned, ' ');
  }
  return isNeg && grouped !== '0' ? `−${grouped}` : grouped;
}

function formatScientific(value, options) {
  const sigDigits = options.decimalPrecision >= 0 ? clamp(options.decimalPrecision + 1, 2, 10) : 10;
  const rounded = value.round(new MathContext(sigDigits, RoundingMode.HALF_UP)).stripTrailingZeros();
  return rounded
    .toString()
    .replaceAll('-', '−')
    .replaceAll('E+', '×10^')
    .replaceAll('E', '×10^');
}

export const NumberFormatter = {
  formatResult(value, options = new FormattingOptions()) {
    const bd = value instanceof BigDecimal ? value : BigDecimal.of(value);
    const opts = options instanceof FormattingOptions ? options : new FormattingOptions(options);

    if (bd.compareTo(BigDecimal.ZERO) === 0) {
      return opts.decimalPrecision > 0
        ? '0.' + '0'.repeat(Math.min(opts.decimalPrecision, 10))
        : '0';
    }

    const absVal = bd.abs();
    if (
      absVal.compareTo(ONE_E_12) >= 0 ||
      (absVal.compareTo(BigDecimal.ZERO) > 0 && absVal.compareTo(ONE_E_NEG_8) < 0)
    ) {
      return formatScientific(bd, opts);
    }

    let rounded;
    if (opts.decimalPrecision >= 0) {
      const scale = clamp(opts.decimalPrecision, 0, 10);
      rounded = bd.setScale(scale, RoundingMode.HALF_UP);
    } else {
      const cleaned = bd.round(MC_12);
      const scaleCapped = cleaned.scale > 10 ? cleaned.setScale(10, RoundingMode.HALF_UP) : cleaned;
      rounded = scaleCapped.stripTrailingZeros();
    }

    if (opts.decimalPrecision < 0 && rounded.abs().compareTo(ONE_E_12) >= 0) {
      return formatScientific(rounded, opts);
    }

    const cleanRounded = rounded.compareTo(BigDecimal.ZERO) === 0 ? BigDecimal.ZERO : rounded;
    let plain;
    if (opts.decimalPrecision >= 0) {
      if (cleanRounded.compareTo(BigDecimal.ZERO) === 0) {
        plain =
          opts.decimalPrecision > 0
            ? '0.' + '0'.repeat(clamp(opts.decimalPrecision, 0, 10))
            : '0';
      } else {
        plain = cleanRounded.toPlainString();
      }
    } else {
      plain = cleanRounded.toPlainString();
    }

    return applyGrouping(plain, opts.grouping);
  },

  formatDouble(value, options = new FormattingOptions()) {
    if (!Number.isFinite(value)) return 'Error';
    const clean = Object.is(value, -0) || value === 0 ? 0.0 : value;
    const bd = BigDecimal.valueOf(clean);
    return NumberFormatter.formatResult(bd, options);
  },

  formatRawForExpression(value) {
    const bd = value instanceof BigDecimal ? value : BigDecimal.of(value);
    if (bd.compareTo(BigDecimal.ZERO) === 0) return '0';
    const cleaned = bd.round(MC_120).stripTrailingZeros();
    const absVal = cleaned.abs();
    const str =
      absVal.compareTo(ONE_E_120) >= 0 ||
      (absVal.compareTo(BigDecimal.ZERO) > 0 && absVal.compareTo(ONE_E_NEG_18) < 0)
        ? cleaned.toString()
        : cleaned.toPlainString();
    return str.startsWith('-') ? '−' + str.slice(1) : str;
  },

  formatExpressionForDisplay(expression, grouping = NumberGroupingStyle.COMMA) {
    const gName = typeof grouping === 'string' ? grouping : grouping.name;
    if (!expression || gName === 'NONE') return expression;
    const sepChar = gName === 'COMMA' ? ',' : ' ';
    let out = '';
    let i = 0;
    while (i < expression.length) {
      const c = expression[i];
      if (isDigitChar(c)) {
        const start = i;
        while (i < expression.length && (isDigitChar(expression[i]) || expression[i] === '.')) {
          i++;
        }
        const numToken = expression.slice(start, i);
        const prev = start > 0 ? expression[start - 1] : ' ';
        const prev2 = start > 1 ? expression[start - 2] : ' ';
        const isExponentDigits =
          prev === 'E' ||
          prev === 'e' ||
          ((prev === '+' || prev === '-') && (prev2 === 'E' || prev2 === 'e'));
        if (isExponentDigits || isLetterChar(prev)) {
          out += numToken;
        } else {
          out += groupDigitsOnly(numToken, sepChar);
        }
      } else {
        out += c;
        i++;
      }
    }
    return out;
  },
};
