import { BigDecimal, MATH_CONTEXT_DECIMAL128 } from './bigDecimal.js';

export const ConverterCategory = Object.freeze({
  LENGTH: Object.freeze({ name: 'LENGTH', title: 'Length', isCurrency: false }),
  WEIGHT: Object.freeze({ name: 'WEIGHT', title: 'Weight / Mass', isCurrency: false }),
  TEMPERATURE: Object.freeze({ name: 'TEMPERATURE', title: 'Temperature', isCurrency: false }),
  AREA: Object.freeze({ name: 'AREA', title: 'Area', isCurrency: false }),
  VOLUME: Object.freeze({ name: 'VOLUME', title: 'Volume', isCurrency: false }),
  SPEED: Object.freeze({ name: 'SPEED', title: 'Speed', isCurrency: false }),
  TIME: Object.freeze({ name: 'TIME', title: 'Time', isCurrency: false }),
  DATA_STORAGE: Object.freeze({ name: 'DATA_STORAGE', title: 'Data Storage', isCurrency: false }),
  PRESSURE: Object.freeze({ name: 'PRESSURE', title: 'Pressure', isCurrency: false }),
  ENERGY: Object.freeze({ name: 'ENERGY', title: 'Energy', isCurrency: false }),
  POWER: Object.freeze({ name: 'POWER', title: 'Power', isCurrency: false }),
  FORCE: Object.freeze({ name: 'FORCE', title: 'Force', isCurrency: false }),
  ANGLE: Object.freeze({ name: 'ANGLE', title: 'Angle', isCurrency: false }),
  FREQUENCY: Object.freeze({ name: 'FREQUENCY', title: 'Frequency', isCurrency: false }),
  FUEL_ECONOMY: Object.freeze({ name: 'FUEL_ECONOMY', title: 'Fuel Economy', isCurrency: false }),
  CURRENCY: Object.freeze({ name: 'CURRENCY', title: 'Currency (Offline)', isCurrency: true }),
});

export const ConverterCategories = Object.freeze(Object.values(ConverterCategory));

function unit(id, name, symbol, toBaseFactor = 1.0) {
  return Object.freeze({ id, name, symbol, toBaseFactor });
}

const UNITS_BY_CATEGORY = new Map([
  [
    'LENGTH',
    [
      unit('mm', 'Millimeter', 'mm', 0.001),
      unit('cm', 'Centimeter', 'cm', 0.01),
      unit('m', 'Meter', 'm', 1.0),
      unit('km', 'Kilometer', 'km', 1000.0),
      unit('in', 'Inch', 'in', 0.0254),
      unit('ft', 'Foot', 'ft', 0.3048),
      unit('yd', 'Yard', 'yd', 0.9144),
      unit('mi', 'Mile', 'mi', 1609.344),
      unit('nmi', 'Nautical Mile', 'nmi', 1852.0),
    ],
  ],
  [
    'WEIGHT',
    [
      unit('mg', 'Milligram', 'mg', 1e-6),
      unit('g', 'Gram', 'g', 0.001),
      unit('kg', 'Kilogram', 'kg', 1.0),
      unit('t', 'Metric Ton', 't', 1000.0),
      unit('oz', 'Ounce', 'oz', 0.028349523125),
      unit('lb', 'Pound', 'lb', 0.45359237),
      unit('st', 'Stone', 'st', 6.35029318),
    ],
  ],
  [
    'TEMPERATURE',
    [
      unit('c', 'Celsius', '°C'),
      unit('f', 'Fahrenheit', '°F'),
      unit('k', 'Kelvin', 'K'),
    ],
  ],
  [
    'AREA',
    [
      unit('mm2', 'Square Millimeter', 'mm²', 1e-6),
      unit('cm2', 'Square Centimeter', 'cm²', 1e-4),
      unit('m2', 'Square Meter', 'm²', 1.0),
      unit('ha', 'Hectare', 'ha', 10000.0),
      unit('km2', 'Square Kilometer', 'km²', 1e6),
      unit('in2', 'Square Inch', 'in²', 0.00064516),
      unit('ft2', 'Square Foot', 'ft²', 0.09290304),
      unit('yd2', 'Square Yard', 'yd²', 0.83612736),
      unit('ac', 'Acre', 'ac', 4046.8564224),
      unit('mi2', 'Square Mile', 'mi²', 2589988.110336),
    ],
  ],
  [
    'VOLUME',
    [
      unit('ml', 'Milliliter', 'mL', 0.001),
      unit('l', 'Liter', 'L', 1.0),
      unit('m3', 'Cubic Meter', 'm³', 1000.0),
      unit('tsp', 'Teaspoon (US)', 'tsp', 0.00492892159375),
      unit('tbsp', 'Tablespoon (US)', 'tbsp', 0.01478676478125),
      unit('floz', 'Fluid Ounce (US)', 'fl oz', 0.0295735295625),
      unit('cup', 'Cup (US)', 'cup', 0.2365882365),
      unit('pt', 'Pint (US)', 'pt', 0.473176473),
      unit('qt', 'Quart (US)', 'qt', 0.946352946),
      unit('gal', 'Gallon (US)', 'gal', 3.785411784),
    ],
  ],
  [
    'SPEED',
    [
      unit('ms', 'Meters / second', 'm/s', 1.0),
      unit('kmh', 'Kilometers / hour', 'km/h', 1.0 / 3.6),
      unit('mph', 'Miles / hour', 'mph', 0.44704),
      unit('kn', 'Knot', 'kn', 1852.0 / 3600.0),
      unit('fts', 'Feet / second', 'ft/s', 0.3048),
    ],
  ],
  [
    'TIME',
    [
      unit('ms', 'Millisecond', 'ms', 0.001),
      unit('s', 'Second', 's', 1.0),
      unit('min', 'Minute', 'min', 60.0),
      unit('h', 'Hour', 'h', 3600.0),
      unit('d', 'Day', 'd', 86400.0),
      unit('wk', 'Week', 'wk', 604800.0),
      unit('mo', 'Month (avg)', 'mo', 2629800.0),
      unit('yr', 'Year (Julian)', 'yr', 31557600.0),
    ],
  ],
  [
    'DATA_STORAGE',
    [
      unit('bit', 'Bit', 'bit', 0.125),
      unit('b', 'Byte', 'B', 1.0),
      unit('kb', 'Kilobyte (10³)', 'KB', 1000.0),
      unit('mb', 'Megabyte (10⁶)', 'MB', 1e6),
      unit('gb', 'Gigabyte (10⁹)', 'GB', 1e9),
      unit('tb', 'Terabyte (10¹²)', 'TB', 1e12),
      unit('kib', 'Kibibyte (2¹⁰)', 'KiB', 1024.0),
      unit('mib', 'Mebibyte (2²⁰)', 'MiB', 1048576.0),
      unit('gib', 'Gibibyte (2³⁰)', 'GiB', 1073741824.0),
      unit('tib', 'Tebibyte (2⁴⁰)', 'TiB', 1099511627776.0),
    ],
  ],
  [
    'PRESSURE',
    [
      unit('pa', 'Pascal', 'Pa', 1.0),
      unit('kpa', 'Kilopascal', 'kPa', 1000.0),
      unit('mpa', 'Megapascal', 'MPa', 1e6),
      unit('bar', 'Bar', 'bar', 100000.0),
      unit('atm', 'Atmosphere', 'atm', 101325.0),
      unit('psi', 'Pounds / sq inch', 'psi', 6894.757293168),
      unit('mmhg', 'Millimeter of Hg', 'mmHg', 133.322387415),
    ],
  ],
  [
    'ENERGY',
    [
      unit('j', 'Joule', 'J', 1.0),
      unit('kj', 'Kilojoule', 'kJ', 1000.0),
      unit('cal', 'Calorie', 'cal', 4.184),
      unit('kcal', 'Kilocalorie', 'kcal', 4184.0),
      unit('wh', 'Watt-hour', 'Wh', 3600.0),
      unit('kwh', 'Kilowatt-hour', 'kWh', 3.6e6),
      unit('btu', 'British Thermal Unit', 'BTU', 1055.05585262),
      unit('ev', 'Electronvolt', 'eV', 1.602176634e-19),
    ],
  ],
  [
    'POWER',
    [
      unit('w', 'Watt', 'W', 1.0),
      unit('kw', 'Kilowatt', 'kW', 1000.0),
      unit('mw', 'Megawatt', 'MW', 1e6),
      unit('hp', 'Horsepower (mech)', 'hp', 745.6998715822702),
      unit('btuh', 'BTU / hour', 'BTU/h', 0.2930710701722222),
    ],
  ],
  [
    'FORCE',
    [
      unit('n', 'Newton', 'N', 1.0),
      unit('kn', 'Kilonewton', 'kN', 1000.0),
      unit('lbf', 'Pound-force', 'lbf', 4.4482216152605),
      unit('kgf', 'Kilogram-force', 'kgf', 9.80665),
      unit('dyn', 'Dyne', 'dyn', 1e-5),
    ],
  ],
  [
    'ANGLE',
    [
      unit('deg', 'Degree', '°', 1.0),
      unit('rad', 'Radian', 'rad', 180.0 / Math.PI),
      unit('grad', 'Gradian', 'grad', 0.9),
      unit('arcmin', 'Arcminute', '′', 1.0 / 60.0),
      unit('arcsec', 'Arcsecond', '″', 1.0 / 3600.0),
      unit('rev', 'Revolution', 'rev', 360.0),
    ],
  ],
  [
    'FREQUENCY',
    [
      unit('hz', 'Hertz', 'Hz', 1.0),
      unit('khz', 'Kilohertz', 'kHz', 1000.0),
      unit('mhz', 'Megahertz', 'MHz', 1e6),
      unit('ghz', 'Gigahertz', 'GHz', 1e9),
    ],
  ],
  [
    'FUEL_ECONOMY',
    [
      unit('kml', 'Kilometers / Liter', 'km/L'),
      unit('l100km', 'Liters / 100 km', 'L/100km'),
      unit('mpg_us', 'Miles / Gallon (US)', 'mpg US'),
      unit('mpg_uk', 'Miles / Gallon (UK)', 'mpg UK'),
    ],
  ],
  [
    'CURRENCY',
    [
      unit('usd', 'US Dollar (Ref)', 'USD', 1.0),
      unit('eur', 'Euro (Ref)', 'EUR', 1.08),
      unit('gbp', 'British Pound (Ref)', 'GBP', 1.27),
      unit('inr', 'Indian Rupee (Ref)', 'INR', 0.012),
      unit('jpy', 'Japanese Yen (Ref)', 'JPY', 0.0065),
      unit('cad', 'Canadian Dollar (Ref)', 'CAD', 0.72),
      unit('aud', 'Australian Dollar (Ref)', 'AUD', 0.65),
      unit('chf', 'Swiss Franc (Ref)', 'CHF', 1.13),
    ],
  ],
]);

function convertTemperature(value, fromId, toId) {
  let celsius;
  if (fromId === 'c') celsius = value;
  else if (fromId === 'f') celsius = ((value - 32.0) * 5.0) / 9.0;
  else if (fromId === 'k') celsius = value - 273.15;
  else celsius = value;

  if (toId === 'c') return celsius;
  if (toId === 'f') return (celsius * 9.0) / 5.0 + 32.0;
  if (toId === 'k') return celsius + 273.15;
  return celsius;
}

function convertFuelEconomy(value, fromId, toId) {
  if (value < 0.0) return null;
  if (value === 0.0) {
    return fromId === 'l100km' || toId === 'l100km' ? null : 0.0;
  }
  let kmPerLiter;
  if (fromId === 'kml') kmPerLiter = value;
  else if (fromId === 'l100km') kmPerLiter = 100.0 / value;
  else if (fromId === 'mpg_us') kmPerLiter = value * (1.609344 / 3.785411784);
  else if (fromId === 'mpg_uk') kmPerLiter = value * (1.609344 / 4.54609);
  else return null;

  if (toId === 'kml') return kmPerLiter;
  if (toId === 'l100km') return kmPerLiter === 0.0 ? null : 100.0 / kmPerLiter;
  if (toId === 'mpg_us') return kmPerLiter / (1.609344 / 3.785411784);
  if (toId === 'mpg_uk') return kmPerLiter / (1.609344 / 4.54609);
  return null;
}

export const UnitConverter = {
  unitsFor(category) {
    const key = typeof category === 'string' ? category : category.name;
    return UNITS_BY_CATEGORY.get(key) ?? [];
  },

  convert(value, from, to, category, customCurrencyRate = null) {
    if (!Number.isFinite(value)) return null;
    if (from.id === to.id) return value;

    const catName = typeof category === 'string' ? category : category.name;
    if (catName === 'CURRENCY' && customCurrencyRate !== null && customCurrencyRate !== undefined) {
      if (!Number.isFinite(customCurrencyRate) || customCurrencyRate <= 0.0) return null;
      const res = value * customCurrencyRate;
      return Number.isFinite(res) ? res : null;
    }

    let result;
    if (catName === 'TEMPERATURE') {
      result = convertTemperature(value, from.id, to.id);
    } else if (catName === 'FUEL_ECONOMY') {
      result = convertFuelEconomy(value, from.id, to.id);
    } else {
      result = BigDecimal.valueOf(value)
        .multiply(BigDecimal.valueOf(from.toBaseFactor))
        .divide(BigDecimal.valueOf(to.toBaseFactor), MATH_CONTEXT_DECIMAL128)
        .toNumber();
    }

    return result !== null && Number.isFinite(result) ? result : null;
  },

  defaultRateBetween(from, to) {
    return from.toBaseFactor / to.toBaseFactor;
  },
};
