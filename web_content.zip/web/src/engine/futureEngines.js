import { AngleMode, CalculationEngine, isEvalSuccess } from './calculationEngine.js';

function substituteVariableX(expression, x) {
  const replacement = x < 0 ? `(${x})` : `${x}`;
  return expression.replace(/\bx\b/gi, replacement);
}

export const GraphSampler = {
  sampleFunction(spec, viewport = { xMin: -10, xMax: 10, yMin: -10, yMax: 10 }, sampleCount = 200, angleMode = AngleMode.RAD) {
    if (sampleCount < 2 || viewport.xMax <= viewport.xMin) return [];
    const step = (viewport.xMax - viewport.xMin) / (sampleCount - 1);
    const points = [];
    for (let idx = 0; idx < sampleCount; idx++) {
      const x = viewport.xMin + idx * step;
      const substituted = substituteVariableX(spec.expressionWithX, x);
      const res = CalculationEngine.evaluate(substituted, angleMode);
      const y = isEvalSuccess(res) ? res.value.toNumber() : null;
      points.push({ x, y });
    }
    return points;
  },
};

function fmt(v) {
  const clean = Math.abs(v) < 1e-12 ? 0.0 : v;
  if (Number.isInteger(clean) && Math.abs(clean) <= 9e15) {
    return String(Math.trunc(clean));
  }
  return Number(clean.toPrecision(6)).toString();
}

export const DeterministicMathSolver = {
  solveLinear(a, b, c) {
    if (a === 0.0) {
      if (b === c) {
        return { ok: true, summary: 'Infinite solutions (identity)', steps: [] };
      }
      return { ok: false, reason: `No solution (0x + ${b} = ${c})` };
    }
    const rhs = c - b;
    const x = rhs / a;
    const steps = [
      { description: 'Start with equation', equationState: `${fmt(a)}x + ${fmt(b)} = ${fmt(c)}` },
      { description: `Subtract ${fmt(b)} from both sides`, equationState: `${fmt(a)}x = ${fmt(rhs)}` },
      { description: `Divide both sides by ${fmt(a)}`, equationState: `x = ${fmt(x)}` },
    ];
    return { ok: true, summary: `x = ${fmt(x)}`, steps };
  },

  solveQuadratic(a, b, c) {
    if (a === 0.0) return DeterministicMathSolver.solveLinear(b, c, 0.0);
    const discriminant = b * b - 4.0 * a * c;
    const steps = [
      { description: 'Standard form', equationState: `${fmt(a)}x² + ${fmt(b)}x + ${fmt(c)} = 0` },
      { description: 'Compute discriminant Δ = b² − 4ac', equationState: `Δ = ${fmt(discriminant)}` },
    ];
    if (discriminant > 0) {
      const sqrtD = Math.sqrt(discriminant);
      const x1 = (-b + sqrtD) / (2.0 * a);
      const x2 = (-b - sqrtD) / (2.0 * a);
      steps.push({ description: 'Two real roots', equationState: `x₁ = ${fmt(x1)}, x₂ = ${fmt(x2)}` });
      return { ok: true, summary: `x₁ = ${fmt(x1)}, x₂ = ${fmt(x2)}`, steps };
    }
    if (Math.abs(discriminant) < 1e-12) {
      const x = -b / (2.0 * a);
      steps.push({ description: 'One repeated real root', equationState: `x = ${fmt(x)}` });
      return { ok: true, summary: `x = ${fmt(x)}`, steps };
    }
    const real = -b / (2.0 * a);
    const imag = Math.sqrt(-discriminant) / Math.abs(2.0 * a);
    const summary = `x₁ = ${fmt(real)} + ${fmt(imag)}i, x₂ = ${fmt(real)} − ${fmt(imag)}i`;
    steps.push({ description: 'Complex conjugate roots', equationState: summary });
    return { ok: true, summary, steps };
  },
};
