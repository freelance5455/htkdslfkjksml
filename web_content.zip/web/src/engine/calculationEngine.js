import {
  BigDecimal,
  MATH_CONTEXT_DECIMAL128,
  MATH_CONTEXT_EXACT_CAP,
  MathContext,
  RoundingMode,
} from './bigDecimal.js';
import { FormattingOptions, NumberFormatter } from './numberFormatter.js';

export const AngleMode = Object.freeze({
  DEG: 'DEG',
  RAD: 'RAD',
});

export const CalcError = Object.freeze({
  DIVISION_BY_ZERO: Object.freeze({ name: 'DIVISION_BY_ZERO', message: "Can't divide by zero" }),
  DOMAIN_ERROR: Object.freeze({ name: 'DOMAIN_ERROR', message: 'Domain error' }),
  SYNTAX_ERROR: Object.freeze({ name: 'SYNTAX_ERROR', message: 'Invalid expression' }),
  OVERFLOW: Object.freeze({ name: 'OVERFLOW', message: 'Value too large' }),
});

export function isEvalSuccess(res) {
  return res !== null && res !== undefined && res.ok === true;
}

export function isEvalError(res) {
  return res !== null && res !== undefined && res.ok === false;
}

const MATH_CTX = MATH_CONTEXT_DECIMAL128; // 34 digits
const EXACT_CAP_CTX = MATH_CONTEXT_EXACT_CAP; // 120 digits
const MC_14 = new MathContext(14, RoundingMode.HALF_UP);

const PI_BD = BigDecimal.parse('3.1415926535897932384626433832795029');
const E_BD = BigDecimal.parse('2.7182818284590452353602874713526625');
const LN_10_BD = BigDecimal.parse('2.3025850929940456840179914546843642');
const BD_100 = new BigDecimal(100n, 0);
const BD_180 = new BigDecimal(180n, 0);
const BD_90 = new BigDecimal(90n, 0);
const BD_270 = new BigDecimal(270n, 0);
const BD_360 = new BigDecimal(360n, 0);
const BD_50 = new BigDecimal(50n, 0);
const BD_NEG_50 = new BigDecimal(-50n, 0);
const BD_NEG_1 = new BigDecimal(-1n, 0);

const MAX_EXPONENT = 100_000;
const MAX_FACTORIAL = 1_000;
const MAX_EXACT_SPAN = 1_000;

class CalcException extends Error {
  constructor(error) {
    super(error.message);
    this.error = error;
  }
}

function isDigitChar(ch) {
  return ch !== undefined && ch >= '0' && ch <= '9';
}

function isLetterChar(ch) {
  return ch !== undefined && /\p{L}/u.test(ch);
}

function isLetterOrDigitChar(ch) {
  return ch !== undefined && (isDigitChar(ch) || isLetterChar(ch));
}

function insertImplicitMultiplicationIfNeeded(tokens) {
  if (tokens.length === 0) return;
  const prev = tokens[tokens.length - 1];
  if (
    prev.type === 'Number' ||
    prev.type === 'Constant' ||
    prev.type === 'RParen' ||
    prev.type === 'Percent' ||
    prev.type === 'Factorial'
  ) {
    tokens.push({ type: 'Op', symbol: '*' });
  }
}

function tokenize(input, autoCloseParens) {
  const tokens = [];
  let i = 0;
  const normalized = input
    .replaceAll(' ', '')
    .replaceAll('\u00A0', '')
    .replaceAll('−', '-')
    .replaceAll('×', '*')
    .replaceAll('÷', '/');

  while (i < normalized.length) {
    const ch = normalized[i];
    if (isDigitChar(ch) || ch === '.') {
      const start = i;
      let dotCount = ch === '.' ? 1 : 0;
      i++;
      while (i < normalized.length && (isDigitChar(normalized[i]) || normalized[i] === '.')) {
        if (normalized[i] === '.') {
          dotCount++;
          if (dotCount > 1) throw new CalcException(CalcError.SYNTAX_ERROR);
        }
        i++;
      }
      if (i < normalized.length && (normalized[i] === 'E' || normalized[i] === 'e')) {
        const next = normalized[i + 1];
        const afterNext = normalized[i + 2];
        const isSciNotation =
          (next !== undefined && isDigitChar(next)) ||
          ((next === '+' || next === '-') && afterNext !== undefined && isDigitChar(afterNext));
        if (isSciNotation) {
          i++;
          if (normalized[i] === '+' || normalized[i] === '-') i++;
          while (i < normalized.length && isDigitChar(normalized[i])) i++;
        }
      }
      const numStr = normalized.slice(start, i);
      if (numStr === '.') throw new CalcException(CalcError.SYNTAX_ERROR);
      insertImplicitMultiplicationIfNeeded(tokens);
      tokens.push({ type: 'Number', raw: numStr });
    } else if (ch === 'π') {
      insertImplicitMultiplicationIfNeeded(tokens);
      tokens.push({ type: 'Constant', symbol: 'π' });
      i++;
    } else if (ch === '√') {
      insertImplicitMultiplicationIfNeeded(tokens);
      tokens.push({ type: 'Function', name: 'sqrt' });
      i++;
      if (i < normalized.length && normalized[i] === '(') {
        tokens.push({ type: 'LParen' });
        i++;
      } else {
        tokens.push({ type: 'LParen' });
        const atomStart = i;
        while (i < normalized.length && (isDigitChar(normalized[i]) || normalized[i] === '.')) i++;
        if (i === atomStart) throw new CalcException(CalcError.SYNTAX_ERROR);
        tokens.push({ type: 'Number', raw: normalized.slice(atomStart, i) });
        tokens.push({ type: 'RParen' });
      }
    } else if (ch === '∛') {
      insertImplicitMultiplicationIfNeeded(tokens);
      tokens.push({ type: 'Function', name: 'cbrt' });
      i++;
      if (i < normalized.length && normalized[i] === '(') {
        tokens.push({ type: 'LParen' });
        i++;
      } else {
        throw new CalcException(CalcError.SYNTAX_ERROR);
      }
    } else if (isLetterChar(ch)) {
      const start = i;
      while (
        i < normalized.length &&
        (isLetterOrDigitChar(normalized[i]) || normalized[i] === '_' || normalized[i] === 'ₙ')
      ) {
        i++;
      }
      const ident = normalized.slice(start, i);
      if (ident === 'e' || ident === 'pi') {
        insertImplicitMultiplicationIfNeeded(tokens);
        tokens.push({ type: 'Constant', symbol: ident === 'pi' ? 'π' : 'e' });
      } else {
        const lower = ident.toLowerCase();
        const allowed = new Set([
          'sin',
          'cos',
          'tan',
          'asin',
          'acos',
          'atan',
          'sinh',
          'cosh',
          'tanh',
          'log',
          'ln',
          'logbase',
          'logₙ',
          'sqrt',
          'cbrt',
          'nroot',
          'abs',
        ]);
        if (!allowed.has(lower)) {
          throw new CalcException(CalcError.SYNTAX_ERROR);
        }
        const mappedFunc = lower.replace('logₙ', 'logbase');
        insertImplicitMultiplicationIfNeeded(tokens);
        tokens.push({ type: 'Function', name: mappedFunc });
        if (i >= normalized.length || normalized[i] !== '(') {
          throw new CalcException(CalcError.SYNTAX_ERROR);
        }
      }
    } else if (ch === '(') {
      const prev = tokens.length > 0 ? tokens[tokens.length - 1] : null;
      if (!prev || prev.type !== 'Function') {
        insertImplicitMultiplicationIfNeeded(tokens);
      }
      tokens.push({ type: 'LParen' });
      i++;
    } else if (ch === ')') {
      tokens.push({ type: 'RParen' });
      i++;
    } else if (ch === ',') {
      tokens.push({ type: 'Comma' });
      i++;
    } else if (ch === '%') {
      tokens.push({ type: 'Percent' });
      i++;
    } else if (ch === '!') {
      tokens.push({ type: 'Factorial' });
      i++;
    } else if (ch === '+' || ch === '-' || ch === '*' || ch === '/' || ch === '^') {
      tokens.push({ type: 'Op', symbol: ch });
      i++;
    } else {
      throw new CalcException(CalcError.SYNTAX_ERROR);
    }
  }

  if (autoCloseParens) {
    let openCount = 0;
    for (const t of tokens) {
      if (t.type === 'LParen') openCount++;
      else if (t.type === 'RParen') openCount--;
    }
    for (let k = 0; k < Math.max(0, openCount); k++) {
      tokens.push({ type: 'RParen' });
    }
  }

  return tokens;
}

class Parser {
  constructor(tokens) {
    this.tokens = tokens;
    this.pos = 0;
  }

  isAtEnd() {
    return this.pos >= this.tokens.length;
  }

  peek() {
    return this.tokens[this.pos] ?? null;
  }

  consume() {
    return this.tokens[this.pos++];
  }

  parseExpression() {
    return this.parseAddSub();
  }

  parseAddSub() {
    let left = this.parseMulDiv();
    while (true) {
      const t = this.peek();
      if (t && t.type === 'Op' && (t.symbol === '+' || t.symbol === '-')) {
        this.consume();
        const right = this.parseMulDiv();
        left = { kind: 'Binary', op: t.symbol, left, right };
      } else {
        break;
      }
    }
    return left;
  }

  parseMulDiv() {
    let left = this.parseUnary();
    while (true) {
      const t = this.peek();
      if (t && t.type === 'Op' && (t.symbol === '*' || t.symbol === '/')) {
        this.consume();
        const right = this.parseUnary();
        left = { kind: 'Binary', op: t.symbol, left, right };
      } else {
        break;
      }
    }
    return left;
  }

  parseUnary() {
    const t = this.peek();
    if (t && t.type === 'Op' && t.symbol === '-') {
      this.consume();
      return { kind: 'UnaryMinus', inner: this.parseUnary() };
    }
    return this.parsePower();
  }

  parsePower() {
    const base = this.parsePostfix();
    const t = this.peek();
    if (t && t.type === 'Op' && t.symbol === '^') {
      this.consume();
      const exponent = this.parseUnary();
      return { kind: 'Binary', op: '^', left: base, right: exponent };
    }
    return base;
  }

  parsePostfix() {
    let node = this.parsePrimary();
    while (true) {
      const t = this.peek();
      if (t && t.type === 'Percent') {
        this.consume();
        node = { kind: 'Percent', inner: node };
      } else if (t && t.type === 'Factorial') {
        this.consume();
        node = { kind: 'Factorial', inner: node };
      } else {
        break;
      }
    }
    return node;
  }

  parsePrimary() {
    const t = this.peek();
    if (!t) throw new CalcException(CalcError.SYNTAX_ERROR);
    if (t.type === 'Number') {
      this.consume();
      let bd = null;
      try {
        bd = BigDecimal.tryParse(t.raw);
      } catch {
        throw new CalcException(CalcError.OVERFLOW);
      }
      if (!bd) throw new CalcException(CalcError.SYNTAX_ERROR);
      return { kind: 'Num', value: bd };
    }
    if (t.type === 'Constant') {
      this.consume();
      return { kind: 'Const', symbol: t.symbol };
    }
    if (t.type === 'LParen') {
      this.consume();
      const inner = this.parseExpression();
      const close = this.peek();
      if (!close || close.type !== 'RParen') throw new CalcException(CalcError.SYNTAX_ERROR);
      this.consume();
      return inner;
    }
    if (t.type === 'Function') {
      this.consume();
      const open = this.peek();
      if (!open || open.type !== 'LParen') throw new CalcException(CalcError.SYNTAX_ERROR);
      this.consume();
      const args = [];
      if (this.peek()?.type === 'RParen') {
        throw new CalcException(CalcError.SYNTAX_ERROR);
      }
      args.push(this.parseExpression());
      while (this.peek()?.type === 'Comma') {
        this.consume();
        args.push(this.parseExpression());
      }
      if (this.peek()?.type !== 'RParen') throw new CalcException(CalcError.SYNTAX_ERROR);
      this.consume();
      return { kind: 'FuncCall', name: t.name, args };
    }
    throw new CalcException(CalcError.SYNTAX_ERROR);
  }
}

function toCheckedDouble(bd) {
  const d = bd.toNumber();
  if (!Number.isFinite(d)) throw new CalcException(CalcError.OVERFLOW);
  return d;
}

function fromCheckedDouble(d) {
  if (Number.isNaN(d)) throw new CalcException(CalcError.DOMAIN_ERROR);
  if (!Number.isFinite(d)) throw new CalcException(CalcError.OVERFLOW);
  return BigDecimal.valueOf(d).round(MC_14);
}

function safeExactAdd(a, b) {
  if (a.compareTo(BigDecimal.ZERO) === 0) return b;
  if (b.compareTo(BigDecimal.ZERO) === 0) return a;
  const maxMsb = Math.max(a.precision() - a.scale, b.precision() - b.scale);
  const minLsb = Math.min(-a.scale, -b.scale);
  const span = maxMsb - minLsb + 2;
  return span <= MAX_EXACT_SPAN ? a.add(b) : a.add(b, EXACT_CAP_CTX);
}

function safeExactSubtract(a, b) {
  if (b.compareTo(BigDecimal.ZERO) === 0) return a;
  if (a.compareTo(BigDecimal.ZERO) === 0) return b.negate();
  const maxMsb = Math.max(a.precision() - a.scale, b.precision() - b.scale);
  const minLsb = Math.min(-a.scale, -b.scale);
  const span = maxMsb - minLsb + 2;
  return span <= MAX_EXACT_SPAN ? a.subtract(b) : a.subtract(b, EXACT_CAP_CTX);
}

function evalPower(left, right) {
  const strippedExp = right.stripTrailingZeros();
  if (strippedExp.scale <= 0) {
    let expBig;
    try {
      expBig = strippedExp.longValueExact();
    } catch {
      throw new CalcException(CalcError.OVERFLOW);
    }
    if (expBig < -BigInt(MAX_EXPONENT) || expBig > BigInt(MAX_EXPONENT)) {
      if (left.compareTo(BigDecimal.ONE) === 0) return BigDecimal.ONE;
      if (left.compareTo(BigDecimal.ZERO) === 0) {
        if (expBig > 0n) return BigDecimal.ZERO;
        throw new CalcException(CalcError.DIVISION_BY_ZERO);
      }
      throw new CalcException(CalcError.OVERFLOW);
    }
    const n = Number(expBig);
    if (n === 0) return BigDecimal.ONE;
    if (n > 0) {
      return left.pow(n, MATH_CTX);
    }
    if (left.compareTo(BigDecimal.ZERO) === 0) {
      throw new CalcException(CalcError.DIVISION_BY_ZERO);
    }
    const posPow = left.pow(-n, MATH_CTX);
    return BigDecimal.ONE.divide(posPow, MATH_CTX);
  }

  if (left.compareTo(BigDecimal.ZERO) === 0) {
    if (right.signum() < 0) throw new CalcException(CalcError.DIVISION_BY_ZERO);
    return BigDecimal.ZERO;
  }
  if (left.signum() < 0) {
    throw new CalcException(CalcError.DOMAIN_ERROR);
  }

  const exp10 = left.precision() - left.scale - 1;
  const clampedExp10 = Math.max(-1_000_000, Math.min(1_000_000, exp10));
  const mantissa = left.movePointLeft(clampedExp10).toNumber();
  const rightDouble = toCheckedDouble(right);
  if (Math.abs(exp10) <= 250) {
    const leftDouble = left.toNumber();
    if (Number.isFinite(leftDouble) && leftDouble > 0.0) {
      const powRes = Math.pow(leftDouble, rightDouble);
      if (Number.isFinite(powRes) && (powRes !== 0.0 || leftDouble === 0.0)) {
        return fromCheckedDouble(powRes);
      }
    }
  }
  const totalLog10 = (Math.log10(mantissa) + exp10) * rightDouble;
  if (Number.isNaN(totalLog10)) throw new CalcException(CalcError.DOMAIN_ERROR);
  if (!Number.isFinite(totalLog10) || Math.abs(totalLog10) > 1_000_000.0) {
    throw new CalcException(CalcError.OVERFLOW);
  }
  const resExp10 = Math.floor(totalLog10);
  const fracExp = totalLog10 - resExp10;
  const resMantissa = Math.pow(10.0, fracExp);
  return BigDecimal.valueOf(resMantissa).round(MC_14).movePointRight(resExp10);
}

function evalLog10(argBd) {
  if (argBd.signum() <= 0) throw new CalcException(CalcError.DOMAIN_ERROR);
  const stripped = argBd.stripTrailingZeros();
  if (stripped.unscaledValue() === 1n) {
    return new BigDecimal(BigInt(-stripped.scale), 0);
  }
  const exp10 = argBd.precision() - argBd.scale - 1;
  if (exp10 < -1_000_000_000 || exp10 > 1_000_000_000) {
    throw new CalcException(CalcError.OVERFLOW);
  }
  const mantissa = argBd.movePointLeft(exp10).toNumber();
  const res = BigDecimal.valueOf(Math.log10(mantissa)).add(new BigDecimal(BigInt(exp10), 0), MATH_CTX);
  return res.round(MC_14);
}

function evalLnHighPrecision(argBd) {
  if (argBd.signum() <= 0) throw new CalcException(CalcError.DOMAIN_ERROR);
  if (argBd.compareTo(BigDecimal.ONE) === 0) return BigDecimal.ZERO;
  const exp10 = argBd.precision() - argBd.scale - 1;
  if (exp10 < -1_000_000_000 || exp10 > 1_000_000_000) {
    throw new CalcException(CalcError.OVERFLOW);
  }
  const mantissa = argBd.movePointLeft(exp10).toNumber();
  const lnMantissa = BigDecimal.valueOf(Math.log(mantissa));
  if (exp10 === 0) return lnMantissa;
  return lnMantissa.add(LN_10_BD.multiply(new BigDecimal(BigInt(exp10), 0), MATH_CTX), MATH_CTX);
}

function evalIntegerRoot(n, argBd) {
  if (n === 0) throw new CalcException(CalcError.DOMAIN_ERROR);
  if (n < 0) {
    const pos = evalIntegerRoot(-n, argBd);
    if (pos.compareTo(BigDecimal.ZERO) === 0) throw new CalcException(CalcError.DIVISION_BY_ZERO);
    return BigDecimal.ONE.divide(pos, MATH_CTX).round(MC_14);
  }
  if (argBd.compareTo(BigDecimal.ZERO) === 0) return BigDecimal.ZERO;
  if (argBd.signum() < 0) {
    if (n % 2 === 0) throw new CalcException(CalcError.DOMAIN_ERROR);
    return evalIntegerRoot(n, argBd.negate()).negate();
  }
  const exp10 = argBd.precision() - argBd.scale - 1;
  const k = Math.floor(exp10 / n);
  const remExp = exp10 - k * n;
  if (k < -1_000_000 || k > 1_000_000) throw new CalcException(CalcError.OVERFLOW);
  if (remExp >= 300) {
    return evalPower(argBd, BigDecimal.ONE.divide(new BigDecimal(BigInt(n), 0), MATH_CTX));
  }
  const shift = k * n;
  const scaled = argBd.movePointLeft(shift).toNumber();
  if (!Number.isFinite(scaled) || scaled <= 0.0) {
    return evalPower(argBd, BigDecimal.ONE.divide(new BigDecimal(BigInt(n), 0), MATH_CTX));
  }
  let rootScaled;
  if (n === 2) rootScaled = Math.sqrt(scaled);
  else if (n === 3) rootScaled = Math.cbrt(scaled);
  else rootScaled = Math.pow(scaled, 1.0 / n);
  return BigDecimal.valueOf(rootScaled).round(MC_14).movePointRight(k);
}

function evalTrig(func, argBd, angleMode) {
  if (angleMode === AngleMode.DEG) {
    const rem = argBd.remainder(BD_360).stripTrailingZeros();
    const degBd = rem.signum() < 0 ? rem.add(BD_360) : rem;
    if (degBd.compareTo(BigDecimal.ZERO) === 0 || degBd.compareTo(BD_180) === 0) {
      if (func === 'sin' || func === 'tan') return BigDecimal.ZERO;
      if (func === 'cos') return degBd.compareTo(BigDecimal.ZERO) === 0 ? BigDecimal.ONE : BD_NEG_1;
      return BigDecimal.ZERO;
    }
    if (degBd.compareTo(BD_90) === 0 || degBd.compareTo(BD_270) === 0) {
      if (func === 'sin') return degBd.compareTo(BD_90) === 0 ? BigDecimal.ONE : BD_NEG_1;
      if (func === 'cos') return BigDecimal.ZERO;
      if (func === 'tan') throw new CalcException(CalcError.DOMAIN_ERROR);
      return BigDecimal.ZERO;
    }
    const deg = toCheckedDouble(degBd);
    const rad = (deg * Math.PI) / 180.0;
    let res = 0.0;
    if (func === 'sin') res = Math.sin(rad);
    else if (func === 'cos') res = Math.cos(rad);
    else if (func === 'tan') {
      const c = Math.cos(rad);
      if (Math.abs(c) < 1e-12) throw new CalcException(CalcError.DOMAIN_ERROR);
      res = Math.tan(rad);
    }
    return fromCheckedDouble(res);
  }

  const x = toCheckedDouble(argBd);
  let raw = 0.0;
  if (func === 'sin') raw = Math.sin(x);
  else if (func === 'cos') raw = Math.cos(x);
  else if (func === 'tan') {
    const c = Math.cos(x);
    if (Math.abs(c) < 1e-12) throw new CalcException(CalcError.DOMAIN_ERROR);
    raw = Math.tan(x);
  }
  const cleaned = Math.abs(x) >= 1.0 && Math.abs(raw) < 1e-13 ? 0.0 : raw;
  return fromCheckedDouble(cleaned);
}

function evalFunction(name, args, angleMode) {
  if (name === 'logbase') {
    if (args.length !== 2) throw new CalcException(CalcError.SYNTAX_ERROR);
    const base = evalNode(args[0], angleMode);
    const value = evalNode(args[1], angleMode);
    if (base.signum() <= 0 || base.compareTo(BigDecimal.ONE) === 0 || value.signum() <= 0) {
      throw new CalcException(CalcError.DOMAIN_ERROR);
    }
    const lnVal = evalLnHighPrecision(value);
    const lnBase = evalLnHighPrecision(base);
    return lnVal.divide(lnBase, MATH_CTX).round(MC_14);
  }

  if (name === 'nroot') {
    if (args.length !== 2) throw new CalcException(CalcError.SYNTAX_ERROR);
    const nBd = evalNode(args[0], angleMode);
    const xBd = evalNode(args[1], angleMode);
    if (nBd.compareTo(BigDecimal.ZERO) === 0) throw new CalcException(CalcError.DOMAIN_ERROR);
    const nStripped = nBd.stripTrailingZeros();
    if (nStripped.scale <= 0) {
      let nInt = null;
      try {
        nInt = nStripped.intValueExact();
      } catch {
        nInt = null;
      }
      if (nInt !== null && nInt >= -MAX_EXPONENT && nInt <= MAX_EXPONENT) {
        return evalIntegerRoot(nInt, xBd);
      }
    }
    const n = toCheckedDouble(nBd);
    if (xBd.signum() < 0) {
      const nInt = Math.round(n);
      if (Math.abs(n - nInt) < 1e-12 && Math.abs(nInt % 2) === 1) {
        const posRoot = evalPower(xBd.negate(), BigDecimal.ONE.divide(nBd, MATH_CTX));
        return posRoot.negate();
      }
      throw new CalcException(CalcError.DOMAIN_ERROR);
    }
    return evalPower(xBd, BigDecimal.ONE.divide(nBd, MATH_CTX));
  }

  if (args.length !== 1) throw new CalcException(CalcError.SYNTAX_ERROR);
  const argBd = evalNode(args[0], angleMode);

  switch (name) {
    case 'sin':
    case 'cos':
    case 'tan':
      return evalTrig(name, argBd, angleMode);
    case 'asin': {
      const x = toCheckedDouble(argBd);
      if (x < -1.0 || x > 1.0) throw new CalcException(CalcError.DOMAIN_ERROR);
      const rad = Math.asin(x);
      return fromCheckedDouble(angleMode === AngleMode.DEG ? (rad * 180.0) / Math.PI : rad);
    }
    case 'acos': {
      const x = toCheckedDouble(argBd);
      if (x < -1.0 || x > 1.0) throw new CalcException(CalcError.DOMAIN_ERROR);
      const rad = Math.acos(x);
      return fromCheckedDouble(angleMode === AngleMode.DEG ? (rad * 180.0) / Math.PI : rad);
    }
    case 'atan': {
      const x = toCheckedDouble(argBd);
      const rad = Math.atan(x);
      return fromCheckedDouble(angleMode === AngleMode.DEG ? (rad * 180.0) / Math.PI : rad);
    }
    case 'sinh':
      return fromCheckedDouble(Math.sinh(toCheckedDouble(argBd)));
    case 'cosh':
      return fromCheckedDouble(Math.cosh(toCheckedDouble(argBd)));
    case 'tanh':
      if (argBd.compareTo(BD_50) > 0) return BigDecimal.ONE;
      if (argBd.compareTo(BD_NEG_50) < 0) return BD_NEG_1;
      return fromCheckedDouble(Math.tanh(toCheckedDouble(argBd)));
    case 'log':
      return evalLog10(argBd);
    case 'ln':
      return evalLnHighPrecision(argBd).round(MC_14);
    case 'sqrt':
      return evalIntegerRoot(2, argBd);
    case 'cbrt':
      return evalIntegerRoot(3, argBd);
    case 'abs':
      return argBd.abs();
    default:
      throw new CalcException(CalcError.SYNTAX_ERROR);
  }
}

function evalNode(node, angleMode) {
  switch (node.kind) {
    case 'Num':
      return node.value;
    case 'Const':
      if (node.symbol === 'π') return PI_BD;
      if (node.symbol === 'e') return E_BD;
      throw new CalcException(CalcError.SYNTAX_ERROR);
    case 'UnaryMinus':
      return evalNode(node.inner, angleMode).negate();
    case 'Percent': {
      const inner = evalNode(node.inner, angleMode);
      return inner.divide(BD_100, EXACT_CAP_CTX);
    }
    case 'Factorial': {
      const v = evalNode(node.inner, angleMode);
      const stripped = v.stripTrailingZeros();
      if (stripped.signum() < 0 || stripped.scale > 0) {
        throw new CalcException(CalcError.DOMAIN_ERROR);
      }
      if (stripped.compareTo(new BigDecimal(BigInt(MAX_FACTORIAL), 0)) > 0) {
        throw new CalcException(CalcError.OVERFLOW);
      }
      const n = stripped.intValueExact();
      let fact = BigDecimal.ONE;
      for (let k = 2; k <= n; k++) {
        fact = fact.multiply(new BigDecimal(BigInt(k), 0), EXACT_CAP_CTX);
      }
      return fact;
    }
    case 'Binary': {
      if ((node.op === '+' || node.op === '-') && node.right.kind === 'Percent') {
        const leftVal = evalNode(node.left, angleMode);
        const pctInner = evalNode(node.right.inner, angleMode);
        const delta = leftVal
          .multiply(pctInner, EXACT_CAP_CTX)
          .divide(BD_100, EXACT_CAP_CTX);
        return node.op === '+' ? safeExactAdd(leftVal, delta) : safeExactSubtract(leftVal, delta);
      }
      const left = evalNode(node.left, angleMode);
      const right = evalNode(node.right, angleMode);
      switch (node.op) {
        case '+':
          return safeExactAdd(left, right);
        case '-':
          return safeExactSubtract(left, right);
        case '*':
          return left.multiply(right, EXACT_CAP_CTX);
        case '/':
          if (right.compareTo(BigDecimal.ZERO) === 0) {
            throw new CalcException(CalcError.DIVISION_BY_ZERO);
          }
          return left.divide(right, MATH_CTX);
        case '^':
          return evalPower(left, right);
        default:
          throw new CalcException(CalcError.SYNTAX_ERROR);
      }
    }
    case 'FuncCall':
      return evalFunction(node.name, node.args, angleMode);
    default:
      throw new CalcException(CalcError.SYNTAX_ERROR);
  }
}

export const CalculationEngine = {
  evaluate(
    rawExpression,
    angleMode = AngleMode.DEG,
    formatting = new FormattingOptions(),
    autoCloseParens = true,
  ) {
    const trimmed = (rawExpression ?? '').trim();
    if (!trimmed) return { ok: false, error: CalcError.SYNTAX_ERROR };

    let tokens;
    try {
      tokens = tokenize(trimmed, autoCloseParens);
    } catch (e) {
      return { ok: false, error: e instanceof CalcException ? e.error : CalcError.SYNTAX_ERROR };
    }
    if (tokens.length === 0) return { ok: false, error: CalcError.SYNTAX_ERROR };

    const parser = new Parser(tokens);
    let ast;
    try {
      ast = parser.parseExpression();
      if (!parser.isAtEnd()) throw new CalcException(CalcError.SYNTAX_ERROR);
    } catch (e) {
      return { ok: false, error: e instanceof CalcException ? e.error : CalcError.SYNTAX_ERROR };
    }

    try {
      const result = evalNode(ast, angleMode);
      if (result.scale < -1_000_000 || result.scale > 1_000_000) {
        return { ok: false, error: CalcError.OVERFLOW };
      }
      const formatted = NumberFormatter.formatResult(result, formatting);
      const rawNumericString = NumberFormatter.formatRawForExpression(result);
      return {
        ok: true,
        value: result,
        formatted,
        rawNumericString,
      };
    } catch (e) {
      if (e instanceof CalcException) {
        return { ok: false, error: e.error };
      }
      if (e instanceof RangeError) {
        return { ok: false, error: CalcError.OVERFLOW };
      }
      return { ok: false, error: CalcError.DOMAIN_ERROR };
    }
  },

  evaluateLivePreview(
    rawExpression,
    angleMode = AngleMode.DEG,
    formatting = new FormattingOptions(),
  ) {
    const trimmed = (rawExpression ?? '').trim();
    if (!trimmed) return null;
    const lastChar = trimmed[trimmed.length - 1];
    if ('+−-×*/^(,'.includes(lastChar)) {
      return null;
    }
    return CalculationEngine.evaluate(trimmed, angleMode, formatting, true);
  },
};
