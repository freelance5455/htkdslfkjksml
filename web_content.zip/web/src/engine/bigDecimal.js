/**
 * Zero-dependency arbitrary-precision base-10 Decimal engine backed by native BigInt.
 * Mirrors Java java.math.BigDecimal & MathContext semantics (HALF_UP rounding)
 * used by the source Kotlin CalculationEngine and UnitConverter.
 */

export const RoundingMode = Object.freeze({
  HALF_UP: 'HALF_UP',
});

export class MathContext {
  constructor(precision, roundingMode = RoundingMode.HALF_UP) {
    this.precision = precision;
    this.roundingMode = roundingMode;
  }
}

export const MATH_CONTEXT_DECIMAL128 = new MathContext(34, RoundingMode.HALF_UP);
export const MATH_CONTEXT_EXACT_CAP = new MathContext(120, RoundingMode.HALF_UP);

const POW10_CACHE = new Map();
function pow10BigInt(exp) {
  if (exp <= 0) return 1n;
  const cached = POW10_CACHE.get(exp);
  if (cached !== undefined) return cached;
  const val = 10n ** BigInt(exp);
  if (exp <= 2000) POW10_CACHE.set(exp, val);
  return val;
}

function absBigInt(n) {
  return n < 0n ? -n : n;
}

function countDigitsBigInt(n) {
  const a = absBigInt(n);
  if (a === 0n) return 1;
  return a.toString().length;
}

export class BigDecimal {
  /**
   * @param {bigint} coeff unscaled signed BigInt
   * @param {number} scale integer scale (value = coeff * 10^-scale)
   */
  constructor(coeff, scale = 0) {
    this.coeff = typeof coeff === 'bigint' ? coeff : BigInt(coeff);
    this.scale = scale | 0;
    this._precision = null;
  }

  static get ZERO() {
    return ZERO_BD;
  }

  static get ONE() {
    return ONE_BD;
  }

  static get TEN() {
    return TEN_BD;
  }

  static of(value) {
    if (value instanceof BigDecimal) return value;
    if (typeof value === 'bigint') return new BigDecimal(value, 0);
    if (typeof value === 'number') return BigDecimal.valueOf(value);
    if (typeof value === 'string') return BigDecimal.parse(value);
    throw new Error('Invalid BigDecimal value');
  }

  static valueOf(num) {
    if (typeof num === 'bigint') return new BigDecimal(num, 0);
    if (!Number.isFinite(num)) {
      throw new RangeError('Infinite or NaN');
    }
    if (Object.is(num, -0) || num === 0) return ZERO_BD;
    return BigDecimal.parse(num.toString());
  }

  static tryParse(raw) {
    if (typeof raw !== 'string') return null;
    const cleaned = raw.trim().replaceAll('−', '-');
    if (cleaned.length === 0) return null;
    const match = /^([+-])?(?:(\d+)(?:\.(\d*))?|\.(\d+))(?:[eE]([+-]?\d+))?$/.exec(cleaned);
    if (!match) return null;

    const sign = match[1] === '-' ? -1n : 1n;
    const intPart = match[2] ?? '';
    const fracPart = match[3] ?? match[4] ?? '';
    const expPart = match[5] !== undefined ? Number(match[5]) : 0;

    if (!Number.isSafeInteger(expPart) || Math.abs(expPart) > 10_000_000) {
      throw new RangeError('Exponent overflow');
    }

    const digits = intPart + fracPart;
    if (digits.length === 0) return null;

    let coeff = BigInt(digits);
    if (coeff !== 0n) {
      coeff = sign * coeff;
    }
    const scale = fracPart.length - expPart;
    if (scale < -10_000_000 || scale > 10_000_000) {
      throw new RangeError('Scale overflow');
    }
    return new BigDecimal(coeff, scale);
  }

  static parse(raw) {
    const res = BigDecimal.tryParse(raw);
    if (!res) throw new SyntaxError(`Invalid BigDecimal string: ${raw}`);
    return res;
  }

  signum() {
    if (this.coeff > 0n) return 1;
    if (this.coeff < 0n) return -1;
    return 0;
  }

  isZero() {
    return this.coeff === 0n;
  }

  precision() {
    if (this._precision === null) {
      this._precision = countDigitsBigInt(this.coeff);
    }
    return this._precision;
  }

  unscaledValue() {
    return this.coeff;
  }

  negate() {
    if (this.coeff === 0n) return new BigDecimal(0n, this.scale);
    return new BigDecimal(-this.coeff, this.scale);
  }

  abs() {
    return this.coeff < 0n ? this.negate() : this;
  }

  stripTrailingZeros() {
    if (this.coeff === 0n) {
      return ZERO_BD;
    }
    let s = absBigInt(this.coeff).toString();
    let idx = s.length;
    while (idx > 0 && s[idx - 1] === '0') {
      idx--;
    }
    const zeros = s.length - idx;
    if (zeros === 0) return this;
    const trimmed = s.slice(0, idx);
    const newCoeff = this.coeff < 0n ? -BigInt(trimmed) : BigInt(trimmed);
    return new BigDecimal(newCoeff, this.scale - zeros);
  }

  movePointLeft(n) {
    if (n === 0) return this;
    const newScale = this.scale + n;
    if (newScale < -10_000_000 || newScale > 10_000_000) {
      throw new RangeError('Scale overflow');
    }
    return new BigDecimal(this.coeff, newScale);
  }

  movePointRight(n) {
    return this.movePointLeft(-n);
  }

  compareTo(other) {
    const o = BigDecimal.of(other);
    const s1 = this.signum();
    const s2 = o.signum();
    if (s1 !== s2) return s1 < s2 ? -1 : 1;
    if (s1 === 0) return 0;

    if (this.scale === o.scale) {
      if (this.coeff === o.coeff) return 0;
      return this.coeff < o.coeff ? -1 : 1;
    }

    // Compare order of magnitude first to avoid giant pow10 allocations
    const exp1 = this.precision() - this.scale;
    const exp2 = o.precision() - o.scale;
    if (exp1 !== exp2) {
      const magCmp = exp1 < exp2 ? -1 : 1;
      return s1 > 0 ? magCmp : -magCmp;
    }

    const diff = this.scale - o.scale;
    if (diff > 0) {
      const left = this.coeff;
      const right = o.coeff * pow10BigInt(diff);
      return left === right ? 0 : left < right ? -1 : 1;
    } else {
      const left = this.coeff * pow10BigInt(-diff);
      const right = o.coeff;
      return left === right ? 0 : left < right ? -1 : 1;
    }
  }

  round(ctx) {
    if (!ctx || ctx.precision <= 0) return this;
    if (this.coeff === 0n) return new BigDecimal(0n, this.scale);

    const p = this.precision();
    const drop = p - ctx.precision;
    if (drop <= 0) return this;

    const absStr = absBigInt(this.coeff).toString();
    const keptStr = absStr.slice(0, ctx.precision);
    const firstDropped = absStr.charCodeAt(ctx.precision) - 48;

    let roundedAbs = BigInt(keptStr);
    // RoundingMode.HALF_UP: round away from zero if first dropped digit >= 5
    if (firstDropped >= 5) {
      roundedAbs += 1n;
    }

    const signed = this.coeff < 0n ? -roundedAbs : roundedAbs;
    return new BigDecimal(signed, this.scale - drop);
  }

  setScale(newScale, roundingMode = RoundingMode.HALF_UP) {
    if (newScale === this.scale) return this;
    if (this.coeff === 0n) return new BigDecimal(0n, newScale);

    const diff = newScale - this.scale;
    if (diff > 0) {
      return new BigDecimal(this.coeff * pow10BigInt(diff), newScale);
    }

    // Reducing precision
    const drop = -diff;
    const absStr = absBigInt(this.coeff).toString();
    if (drop >= absStr.length) {
      // e.g. 0.001 setScale(2) -> drop=1 -> wait: absStr="1", length=1, drop=1 -> 0.00
      // Check if drop == absStr.length and first digit >= 5
      let roundedAbs = 0n;
      if (drop === absStr.length && absStr.charCodeAt(0) - 48 >= 5) {
        roundedAbs = 1n;
      }
      const signed = roundedAbs === 0n ? 0n : (this.coeff < 0n ? -roundedAbs : roundedAbs);
      return new BigDecimal(signed, newScale);
    }

    const keepLen = absStr.length - drop;
    const keptStr = absStr.slice(0, keepLen);
    const firstDropped = absStr.charCodeAt(keepLen) - 48;
    let roundedAbs = BigInt(keptStr);
    if (roundingMode === RoundingMode.HALF_UP && firstDropped >= 5) {
      roundedAbs += 1n;
    }
    const signed = this.coeff < 0n ? -roundedAbs : roundedAbs;
    return new BigDecimal(signed, newScale);
  }

  add(other, ctx = null) {
    const o = BigDecimal.of(other);
    if (this.coeff === 0n) return ctx ? o.round(ctx) : o;
    if (o.coeff === 0n) return ctx ? this.round(ctx) : this;

    // Fast magnitude-guarded path when MathContext is provided and spans are huge (e.g. 1e130 + 1)
    if (ctx && ctx.precision > 0) {
      const msbA = this.precision() - this.scale;
      const msbB = o.precision() - o.scale;
      const maxMsb = Math.max(msbA, msbB);
      const minLsb = Math.min(-this.scale, -o.scale);
      const span = maxMsb - minLsb;
      const guardDigits = ctx.precision + 6;
      if (span > guardDigits + 4) {
        const cutScale = -(maxMsb - guardDigits);
        const aTrunc = this.scale > cutScale ? this.setScale(cutScale, RoundingMode.HALF_UP) : this;
        const bTrunc = o.scale > cutScale ? o.setScale(cutScale, RoundingMode.HALF_UP) : o;
        return aTrunc.add(bTrunc).round(ctx);
      }
    }

    let sumCoeff;
    let resScale;
    if (this.scale === o.scale) {
      sumCoeff = this.coeff + o.coeff;
      resScale = this.scale;
    } else if (this.scale < o.scale) {
      sumCoeff = this.coeff * pow10BigInt(o.scale - this.scale) + o.coeff;
      resScale = o.scale;
    } else {
      sumCoeff = this.coeff + o.coeff * pow10BigInt(this.scale - o.scale);
      resScale = this.scale;
    }

    const res = new BigDecimal(sumCoeff, resScale);
    return ctx ? res.round(ctx) : res;
  }

  subtract(other, ctx = null) {
    return this.add(BigDecimal.of(other).negate(), ctx);
  }

  multiply(other, ctx = null) {
    const o = BigDecimal.of(other);
    if (this.coeff === 0n || o.coeff === 0n) {
      return new BigDecimal(0n, this.scale + o.scale);
    }
    const res = new BigDecimal(this.coeff * o.coeff, this.scale + o.scale);
    return ctx ? res.round(ctx) : res;
  }

  divide(other, ctx = MATH_CONTEXT_DECIMAL128) {
    const divisor = BigDecimal.of(other);
    if (divisor.coeff === 0n) {
      throw new RangeError('Division by zero');
    }
    const preferredScale = this.scale - divisor.scale;
    if (this.coeff === 0n) {
      return new BigDecimal(0n, preferredScale);
    }

    const mc = ctx || MATH_CONTEXT_DECIMAL128;
    const p = mc.precision;
    const neg = (this.coeff < 0n) !== (divisor.coeff < 0n);
    const absNum = absBigInt(this.coeff);
    const absDen = absBigInt(divisor.coeff);
    const sigNum = this.precision();
    const sigDen = divisor.precision();

    // Ensure quotient has at least p + 1 digits before rounding
    const shift = Math.max(0, p - sigNum + sigDen + 2);
    const scaledNum = shift > 0 ? absNum * pow10BigInt(shift) : absNum;
    const q = scaledNum / absDen;
    const rem = scaledNum % absDen;

    let resScale = preferredScale + shift;
    let resCoeff;

    if (rem === 0n) {
      resCoeff = q;
      // Exact division: trim unnecessary trailing zeros added by shift, respecting preferredScale
      let bd = new BigDecimal(neg ? -resCoeff : resCoeff, resScale);
      if (shift > 0) {
        const stripped = bd.stripTrailingZeros();
        bd = stripped.scale < preferredScale ? stripped.setScale(preferredScale) : stripped;
      }
      return bd.round(mc);
    }

    // Non-terminating: append 1 sticky guard digit so HALF_UP tie-breaking is exact
    const twoRem = rem * 2n;
    const sticky = twoRem > absDen ? 6n : twoRem === absDen ? 5n : 1n;
    resCoeff = q * 10n + sticky;
    resScale += 1;

    const bd = new BigDecimal(neg ? -resCoeff : resCoeff, resScale);
    return bd.round(mc);
  }

  pow(n, ctx = MATH_CONTEXT_DECIMAL128) {
    if (!Number.isInteger(n)) throw new RangeError('Exponent must be an integer');
    if (n === 0) return ONE_BD;
    if (n < 0) {
      const pos = this.pow(-n, ctx);
      return ONE_BD.divide(pos, ctx);
    }
    if (this.coeff === 0n) return ZERO_BD;
    if (this.compareTo(ONE_BD) === 0) return ONE_BD;

    // Guard precision prevents cumulative drift in binary exponentiation (matches BigDecimal.pow(n, mc))
    const guardCtx = ctx ? new MathContext(ctx.precision + 12, ctx.roundingMode) : null;
    let base = this;
    let exp = n;
    let acc = ONE_BD;

    while (exp > 0) {
      if ((exp & 1) === 1) {
        acc = acc.multiply(base, guardCtx);
      }
      exp >>>= 1;
      if (exp > 0) {
        base = base.multiply(base, guardCtx);
      }
    }
    return ctx ? acc.round(ctx) : acc;
  }

  divideToIntegralValue(other) {
    const divisor = BigDecimal.of(other);
    if (divisor.coeff === 0n) {
      throw new RangeError('Division by zero');
    }
    if (this.coeff === 0n || this.abs().compareTo(divisor.abs()) < 0) {
      const prefScale = this.scale - divisor.scale;
      return new BigDecimal(0n, prefScale > 0 ? 0 : prefScale);
    }
    const commonScale = Math.max(this.scale, divisor.scale);
    const aScaled = commonScale === this.scale ? this.coeff : this.coeff * pow10BigInt(commonScale - this.scale);
    const bScaled = commonScale === divisor.scale ? divisor.coeff : divisor.coeff * pow10BigInt(commonScale - divisor.scale);
    const q = aScaled / bScaled;
    return new BigDecimal(q, 0);
  }

  remainder(other) {
    const divisor = BigDecimal.of(other);
    if (divisor.coeff === 0n) {
      throw new RangeError('Division by zero');
    }
    if (this.coeff === 0n || this.abs().compareTo(divisor.abs()) < 0) {
      return this;
    }
    const commonScale = Math.max(this.scale, divisor.scale);
    const aScaled = commonScale === this.scale ? this.coeff : this.coeff * pow10BigInt(commonScale - this.scale);
    const bScaled = commonScale === divisor.scale ? divisor.coeff : divisor.coeff * pow10BigInt(commonScale - divisor.scale);
    const rem = aScaled % bScaled;
    return new BigDecimal(rem, commonScale);
  }

  intValueExact() {
    const s = this.stripTrailingZeros();
    if (s.scale > 0) throw new RangeError('Non-zero fractional part');
    const n = Number(s.scale === 0 ? s.coeff : s.coeff * pow10BigInt(-s.scale));
    if (!Number.isSafeInteger(n) || n < -2147483648 || n > 2147483647) {
      throw new RangeError('Integer overflow');
    }
    return n;
  }

  longValueExact() {
    const s = this.stripTrailingZeros();
    if (s.scale > 0) throw new RangeError('Non-zero fractional part');
    const val = s.scale === 0 ? s.coeff : s.coeff * pow10BigInt(-s.scale);
    if (val < -9223372036854775808n || val > 9223372036854775807n) {
      throw new RangeError('Long overflow');
    }
    return val;
  }

  toNumber() {
    if (this.coeff === 0n) return 0;
    return Number(this.toString());
  }

  toPlainString() {
    if (this.coeff === 0n) {
      if (this.scale <= 0) return '0';
      return '0.' + '0'.repeat(this.scale);
    }
    const neg = this.coeff < 0n;
    const digits = absBigInt(this.coeff).toString();
    let body;
    if (this.scale === 0) {
      body = digits;
    } else if (this.scale < 0) {
      body = digits + '0'.repeat(-this.scale);
    } else {
      const pointIdx = digits.length - this.scale;
      if (pointIdx > 0) {
        body = digits.slice(0, pointIdx) + '.' + digits.slice(pointIdx);
      } else {
        body = '0.' + '0'.repeat(-pointIdx) + digits;
      }
    }
    return neg ? '-' + body : body;
  }

  /**
   * Matches Java BigDecimal.toString() formatting:
   * Plain if scale >= 0 and adjustedExponent >= -6; otherwise E-notation.
   */
  toString() {
    const adjusted = this.precision() - 1 - this.scale;
    if (this.scale >= 0 && adjusted >= -6) {
      return this.toPlainString();
    }
    if (this.coeff === 0n) {
      return this.toPlainString();
    }
    const neg = this.coeff < 0n;
    const digits = absBigInt(this.coeff).toString();
    const mantissa = digits.length === 1 ? digits : digits[0] + '.' + digits.slice(1);
    const expStr = adjusted >= 0 ? `+${adjusted}` : `${adjusted}`;
    return `${neg ? '-' : ''}${mantissa}E${expStr}`;
  }
}

const ZERO_BD = new BigDecimal(0n, 0);
const ONE_BD = new BigDecimal(1n, 0);
const TEN_BD = new BigDecimal(10n, 0);
