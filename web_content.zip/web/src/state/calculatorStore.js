import { BigDecimal } from '../engine/bigDecimal.js';
import {
  AngleMode,
  CalculationEngine,
  isEvalSuccess,
} from '../engine/calculationEngine.js';
import { NumberFormatter } from '../engine/numberFormatter.js';

const BINARY_OPS = new Set(['+', '−', '×', '÷', '^']);
const FUNC_PREFIXES = [
  'logBase(',
  'nroot(',
  'sinh(',
  'cosh(',
  'tanh(',
  'asin(',
  'acos(',
  'atan(',
  'sin(',
  'cos(',
  'tan(',
  'log(',
  'abs(',
  'ln(',
  '√(',
  '∛(',
];

function isDigitChar(ch) {
  return ch !== undefined && ch >= '0' && ch <= '9';
}

function isBinaryOp(c) {
  return BINARY_OPS.has(c);
}

function extractTrailingNumberSegment(expr) {
  let i = expr.length - 1;
  while (i >= 0 && (isDigitChar(expr[i]) || expr[i] === '.')) {
    i--;
  }
  return expr.slice(i + 1);
}

function replaceTrailingZeroIfNeeded(expr, digit) {
  if (expr === '0') return digit;
  const resetPrev = ' (, + − × ÷ ^';
  if (
    expr.endsWith('−0') &&
    (expr.length === 2 ||
      ['(', ',', '+', '−', '×', '÷', '^'].includes(expr[expr.length - 3]))
  ) {
    return expr.slice(0, -1) + digit;
  }
  if (
    expr.length >= 2 &&
    expr[expr.length - 1] === '0' &&
    ['(', ',', '+', '−', '×', '÷', '^'].includes(expr[expr.length - 2])
  ) {
    return expr.slice(0, -1) + digit;
  }
  void resetPrev;
  return expr + digit;
}

function hasBinaryOpIgnoringSciExp(rhs) {
  for (let idx = 0; idx < rhs.length; idx++) {
    const c = rhs[idx];
    if (c === '×' || c === '÷') return true;
    if (c === '+' || c === '−' || c === '-') {
      const isSciExp =
        idx >= 2 &&
        (rhs[idx - 1] === 'E' || rhs[idx - 1] === 'e') &&
        (isDigitChar(rhs[idx - 2]) || rhs[idx - 2] === '.');
      if (!isSciExp) return true;
    }
  }
  return false;
}

function extractLastBinaryStep(expr) {
  let depth = 0;
  for (let i = expr.length - 1; i >= 1; i--) {
    const ch = expr[i];
    if (ch === ')') {
      depth++;
    } else if (ch === '(') {
      depth--;
    } else if (ch === '+' || ch === '−' || ch === '-' || ch === '×' || ch === '÷') {
      if (depth === 0) {
        const prev = expr[i - 1];
        if (
          (ch === '+' || ch === '-' || ch === '−') &&
          (prev === 'E' || prev === 'e') &&
          i >= 2 &&
          (isDigitChar(expr[i - 2]) || expr[i - 2] === '.')
        ) {
          continue;
        }
        if (
          isDigitChar(prev) ||
          prev === ')' ||
          prev === 'π' ||
          prev === 'e' ||
          prev === '%' ||
          prev === '!'
        ) {
          const rhs = expr.slice(i + 1);
          if (rhs.length > 0 && !hasBinaryOpIgnoringSciExp(rhs)) {
            return [ch, rhs];
          }
        }
        return [null, null];
      }
    }
  }
  return [null, null];
}

export class CalculatorStore {
  constructor(historyStore, preferencesStore) {
    this._history = historyStore;
    this._prefs = preferencesStore;
    this._listeners = new Set();

    this._internal = {
      expression: '',
      evaluatedResult: null,
      evaluatedRaw: null,
      errorMessage: null,
      isEvaluated: false,
      isScientificMode: false,
      isSecondPage: false,
      isHyperbolic: false,
      repeatOp: null,
      repeatOperand: null,
    };

    this._cachedMemValue = undefined;
    this._cachedMemGrouping = null;
    this._cachedMemPrecision = null;
    this._cachedMemFormatted = '';

    this._uiState = this._computeUiState();
    this._unsubPrefs = this._prefs.subscribe(() => {
      this._emit();
    });
  }

  get uiState() {
    return this._uiState;
  }

  get preferences() {
    return this._prefs.value;
  }

  get history() {
    return this._history.value;
  }

  subscribe(fn) {
    this._listeners.add(fn);
    fn(this._uiState);
    return () => this._listeners.delete(fn);
  }

  _updateInternal(updater) {
    this._internal = updater(this._internal);
    this._emit();
  }

  _emit() {
    this._uiState = this._computeUiState();
    for (const fn of this._listeners) {
      fn(this._uiState);
    }
  }

  _computeUiState() {
    const calc = this._internal;
    const prefs = this._prefs.value;
    const formattedExpression = NumberFormatter.formatExpressionForDisplay(
      calc.expression,
      prefs.groupingStyle,
    );
    const hasMemory = prefs.memoryValue !== null;
    let memoryFormatted = '';
    if (hasMemory) {
      if (
        this._cachedMemValue !== prefs.memoryValue ||
        this._cachedMemGrouping !== prefs.groupingStyle.name ||
        this._cachedMemPrecision !== prefs.decimalPrecision
      ) {
        this._cachedMemValue = prefs.memoryValue;
        this._cachedMemGrouping = prefs.groupingStyle.name;
        this._cachedMemPrecision = prefs.decimalPrecision;
        this._cachedMemFormatted = NumberFormatter.formatResult(
          prefs.memoryValue,
          prefs.formattingOptions,
        );
      }
      memoryFormatted = this._cachedMemFormatted;
    }

    if (calc.errorMessage !== null) {
      return {
        expression: calc.expression,
        formattedExpression,
        resultText: calc.errorMessage,
        isLivePreview: false,
        isEvaluated: calc.isEvaluated,
        errorMessage: calc.errorMessage,
        isScientificMode: calc.isScientificMode,
        isSecondPage: calc.isSecondPage,
        isHyperbolic: calc.isHyperbolic,
        angleMode: prefs.angleMode,
        hasMemory,
        memoryFormatted,
        lastResultRaw: null,
      };
    }

    if (calc.isEvaluated && calc.evaluatedResult !== null) {
      return {
        expression: calc.expression,
        formattedExpression,
        resultText: calc.evaluatedResult,
        isLivePreview: false,
        isEvaluated: true,
        errorMessage: null,
        isScientificMode: calc.isScientificMode,
        isSecondPage: calc.isSecondPage,
        isHyperbolic: calc.isHyperbolic,
        angleMode: prefs.angleMode,
        hasMemory,
        memoryFormatted,
        lastResultRaw: calc.evaluatedRaw,
      };
    }

    const live = CalculationEngine.evaluateLivePreview(
      calc.expression,
      prefs.angleMode,
      prefs.formattingOptions,
    );

    let previewText = '';
    let previewRaw = null;
    if (live && isEvalSuccess(live)) {
      const cleanExpr = calc.expression.replaceAll('−', '-');
      const parsedSingle = BigDecimal.tryParse(cleanExpr);
      const isSinglePlainNumber = parsedSingle !== null && !cleanExpr.includes('%');
      previewText = isSinglePlainNumber ? '' : live.formatted;
      previewRaw = live.rawNumericString;
    }

    return {
      expression: calc.expression,
      formattedExpression,
      resultText: previewText,
      isLivePreview: previewText.length > 0,
      isEvaluated: false,
      errorMessage: null,
      isScientificMode: calc.isScientificMode,
      isSecondPage: calc.isSecondPage,
      isHyperbolic: calc.isHyperbolic,
      angleMode: prefs.angleMode,
      hasMemory,
      memoryFormatted,
      lastResultRaw: previewRaw,
    };
  }

  onDigit(digit) {
    this._updateInternal((state) => {
      const base = state.isEvaluated ? '' : state.expression;
      const updated = replaceTrailingZeroIfNeeded(base, digit);
      return {
        ...state,
        expression: updated,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
        repeatOp: null,
        repeatOperand: null,
      };
    });
  }

  onDecimal() {
    this._updateInternal((state) => {
      const base = state.isEvaluated ? '' : state.expression;
      const currentSegment = extractTrailingNumberSegment(base);
      if (currentSegment.includes('.') || /[0-9.]E[+\-−]?\d*$/i.test(base)) {
        return state;
      }
      const last = base.length > 0 ? base[base.length - 1] : '';
      let toAppend;
      if (base.length === 0) toAppend = '0.';
      else if (isDigitChar(last)) toAppend = '.';
      else if ([')', '%', '!', 'π', 'e'].includes(last)) toAppend = '×0.';
      else toAppend = '0.';

      return {
        ...state,
        expression: base + toAppend,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
        repeatOp: null,
        repeatOperand: null,
      };
    });
  }

  onOperator(op) {
    this._updateInternal((state) => {
      let base;
      if (state.isEvaluated && state.evaluatedRaw !== null && state.errorMessage === null) {
        base = state.evaluatedRaw;
      } else if (state.errorMessage !== null) {
        base = '';
      } else {
        base = state.expression;
      }

      if (base.length === 0) {
        if (op === '−') {
          return {
            ...state,
            expression: '−',
            evaluatedResult: null,
            evaluatedRaw: null,
            errorMessage: null,
            isEvaluated: false,
          };
        }
        return state;
      }

      const last = base[base.length - 1];
      let updated;
      if (last === '(' || last === ',') {
        updated = op === '−' ? `${base}−` : base;
      } else if (isBinaryOp(last)) {
        if (base.length === 1 && last === '−' && op !== '−') {
          updated = '';
        } else if (
          base.length >= 2 &&
          ['(', ',', '×', '÷', '^'].includes(base[base.length - 2]) &&
          last === '−'
        ) {
          updated = base;
        } else {
          updated = base.slice(0, -1) + op;
        }
      } else {
        updated = base + op;
      }

      return {
        ...state,
        expression: updated,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
        repeatOp: null,
        repeatOperand: null,
      };
    });
  }

  onPercent() {
    this._updateInternal((state) => {
      const base =
        state.isEvaluated && state.evaluatedRaw !== null && state.errorMessage === null
          ? state.evaluatedRaw
          : state.expression;
      if (base.length === 0) return state;
      const last = base[base.length - 1];
      if (!isDigitChar(last) && last !== ')' && last !== 'π' && last !== 'e' && last !== '!') {
        return state;
      }
      return {
        ...state,
        expression: `${base}%`,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
        repeatOp: null,
        repeatOperand: null,
      };
    });
  }

  onToggleSign() {
    this._updateInternal((state) => {
      const base =
        state.isEvaluated && state.evaluatedRaw !== null && state.errorMessage === null
          ? state.evaluatedRaw
          : state.expression;

      if (base.length === 0) {
        return { ...state, expression: '−', isEvaluated: false, errorMessage: null };
      }
      if (base === '−') {
        return { ...state, expression: '', isEvaluated: false, errorMessage: null };
      }

      const wrappedMatch = /\(−(\d*\.?\d*(?:[Ee][+\-]?\d+)?)\)$/.exec(base);
      let updated;
      if (wrappedMatch) {
        updated = base.slice(0, wrappedMatch.index) + wrappedMatch[1];
      } else if (base.startsWith('−') && /^\d*\.?\d*(?:[Ee][+\-]?\d+)?$/.test(base.slice(1))) {
        updated = base.slice(1);
      } else {
        const numMatch = /(\d+\.?\d*(?:[Ee][+\-]?\d+)?|\.\d+(?:[Ee][+\-]?\d+)?)$/.exec(base);
        if (numMatch) {
          const prefix = base.slice(0, numMatch.index);
          if (prefix.length === 0) {
            updated = `−${numMatch[0]}`;
          } else if (
            prefix.endsWith('−') &&
            (prefix.length === 1 ||
              ['(', ',', '×', '÷', '^', '+', '−'].includes(prefix[prefix.length - 2]))
          ) {
            updated = prefix.slice(0, -1) + numMatch[0];
          } else {
            updated = `${prefix}(−${numMatch[0]})`;
          }
        } else {
          const last = base[base.length - 1];
          if (['+', '−', '×', '÷', '^', '(', ','].includes(last)) {
            updated = `${base}(−`;
          } else {
            updated = base;
          }
        }
      }

      return {
        ...state,
        expression: updated,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
      };
    });
  }

  onClearAll() {
    this._updateInternal((state) => ({
      ...state,
      expression: '',
      evaluatedResult: null,
      evaluatedRaw: null,
      errorMessage: null,
      isEvaluated: false,
      repeatOp: null,
      repeatOperand: null,
    }));
  }

  onBackspace() {
    this._updateInternal((state) => {
      if (state.isEvaluated || state.errorMessage !== null) {
        return {
          ...state,
          expression: '',
          evaluatedResult: null,
          evaluatedRaw: null,
          errorMessage: null,
          isEvaluated: false,
          repeatOp: null,
          repeatOperand: null,
        };
      }
      const expr = state.expression;
      if (expr.length === 0) return state;

      const matchedPrefix = FUNC_PREFIXES.find((p) => expr.endsWith(p));
      const updated = matchedPrefix ? expr.slice(0, -matchedPrefix.length) : expr.slice(0, -1);
      return { ...state, expression: updated, errorMessage: null };
    });
  }

  onEquals() {
    const state = this._internal;
    const prefs = this._prefs.value;

    if (
      state.isEvaluated &&
      state.evaluatedRaw !== null &&
      state.repeatOp !== null &&
      state.repeatOperand !== null
    ) {
      const repeatedExpr = `${state.evaluatedRaw}${state.repeatOp}${state.repeatOperand}`;
      this._evaluateAndPersist(repeatedExpr, state.repeatOp, state.repeatOperand, prefs);
      return;
    }

    const expr = state.expression.trim();
    if (!expr) return;
    const [lastOp, lastOperand] = extractLastBinaryStep(expr);
    this._evaluateAndPersist(expr, lastOp, lastOperand, prefs);
  }

  _evaluateAndPersist(expr, repeatOp, repeatOperand, prefs) {
    const res = CalculationEngine.evaluate(expr, prefs.angleMode, prefs.formattingOptions);
    if (isEvalSuccess(res)) {
      this._updateInternal((state) => ({
        ...state,
        expression: expr,
        evaluatedResult: res.formatted,
        evaluatedRaw: res.rawNumericString,
        errorMessage: null,
        isEvaluated: true,
        repeatOp,
        repeatOperand,
      }));
      const cleanInput = expr.replaceAll('−', '-');
      const isTrivialSameNumber = cleanInput === res.rawNumericString.replaceAll('−', '-');
      if (!isTrivialSameNumber) {
        this._history.saveCalculation({
          expression: expr,
          resultFormatted: res.formatted,
          resultRaw: res.rawNumericString,
          angleMode: prefs.angleMode,
          isScientific: this._internal.isScientificMode,
        });
      }
    } else {
      this._updateInternal((state) => ({
        ...state,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: res.error.message,
        isEvaluated: true,
        repeatOp: null,
        repeatOperand: null,
      }));
    }
  }

  onScientificFunction(prefixWithParen) {
    this._updateInternal((state) => {
      if (state.isEvaluated && state.evaluatedRaw !== null && state.errorMessage === null) {
        return {
          ...state,
          expression: `${prefixWithParen}${state.evaluatedRaw})`,
          evaluatedResult: null,
          evaluatedRaw: null,
          errorMessage: null,
          isEvaluated: false,
        };
      }
      const base = state.isEvaluated ? '' : state.expression;
      return {
        ...state,
        expression: base + prefixWithParen,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
        repeatOp: null,
        repeatOperand: null,
      };
    });
  }

  onScientificConstant(symbol) {
    this._updateInternal((state) => {
      const base = state.isEvaluated ? '' : state.expression;
      return {
        ...state,
        expression: base + symbol,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
        repeatOp: null,
        repeatOperand: null,
      };
    });
  }

  onScientificPostfix(suffix) {
    this._updateInternal((state) => {
      const base =
        state.isEvaluated && state.evaluatedRaw !== null && state.errorMessage === null
          ? state.evaluatedRaw
          : state.expression;
      if (base.length === 0) return state;
      const last = base[base.length - 1];
      if (!isDigitChar(last) && last !== ')' && last !== 'π' && last !== 'e' && last !== '!') {
        return state;
      }
      return {
        ...state,
        expression: base + suffix,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
      };
    });
  }

  onReciprocal() {
    this._updateInternal((state) => {
      if (state.isEvaluated && state.evaluatedRaw !== null && state.errorMessage === null) {
        return {
          ...state,
          expression: `1÷(${state.evaluatedRaw})`,
          evaluatedResult: null,
          evaluatedRaw: null,
          errorMessage: null,
          isEvaluated: false,
        };
      }
      const base = state.isEvaluated ? '' : state.expression;
      return {
        ...state,
        expression: `${base}1÷(`,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
      };
    });
  }

  onParen(paren) {
    this._updateInternal((state) => {
      const base = state.isEvaluated ? '' : state.expression;
      if (paren === ')') {
        let openCount = 0;
        for (const ch of base) {
          if (ch === '(') openCount++;
          else if (ch === ')') openCount--;
        }
        if (openCount <= 0) return state;
        if (
          base.length > 0 &&
          ['(', ',', '+', '−', '×', '÷', '^'].includes(base[base.length - 1])
        ) {
          return state;
        }
      }
      return {
        ...state,
        expression: base + paren,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
      };
    });
  }

  onComma() {
    this._updateInternal((state) => {
      const base = state.expression;
      if (
        base.length === 0 ||
        ['(', ',', '+', '−', '×', '÷', '^'].includes(base[base.length - 1])
      ) {
        return state;
      }
      return {
        ...state,
        expression: `${base},`,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
      };
    });
  }

  toggleScientificMode() {
    this._updateInternal((s) => ({ ...s, isScientificMode: !s.isScientificMode }));
  }

  setScientificMode(enabled) {
    this._updateInternal((s) => ({ ...s, isScientificMode: Boolean(enabled) }));
  }

  toggleSecondPage() {
    this._updateInternal((s) => ({ ...s, isSecondPage: !s.isSecondPage }));
  }

  toggleHyperbolic() {
    this._updateInternal((s) => ({ ...s, isHyperbolic: !s.isHyperbolic }));
  }

  toggleAngleMode() {
    const next = this._prefs.value.angleMode === AngleMode.DEG ? AngleMode.RAD : AngleMode.DEG;
    this._prefs.setAngleMode(next);
  }

  onMemoryClear() {
    this._prefs.setMemoryValue(null);
  }

  onMemoryRecall() {
    const mem = this._prefs.value.memoryValue;
    if (mem === null) return;
    const raw = NumberFormatter.formatRawForExpression(mem);
    const insertText =
      raw.startsWith('−') &&
      this._internal.expression.length > 0 &&
      !this._internal.isEvaluated
        ? `(${raw})`
        : raw;
    this._updateInternal((state) => {
      const base = state.isEvaluated ? '' : state.expression;
      return {
        ...state,
        expression: base + insertText,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
        repeatOp: null,
        repeatOperand: null,
      };
    });
  }

  onMemoryAdd() {
    const currentVal = this._resolveCurrentNumericValue();
    if (currentVal === null) return;
    const baseMem = this._prefs.value.memoryValue ?? BigDecimal.ZERO;
    this._prefs.setMemoryValue(baseMem.add(currentVal));
  }

  onMemorySubtract() {
    const currentVal = this._resolveCurrentNumericValue();
    if (currentVal === null) return;
    const baseMem = this._prefs.value.memoryValue ?? BigDecimal.ZERO;
    this._prefs.setMemoryValue(baseMem.subtract(currentVal));
  }

  _resolveCurrentNumericValue() {
    const expr = this._internal.expression;
    if (!expr.trim()) return null;
    const prefs = this._prefs.value;
    const res = CalculationEngine.evaluate(expr, prefs.angleMode, prefs.formattingOptions);
    return isEvalSuccess(res) ? res.value : null;
  }

  reuseHistoryItem(item) {
    this._updateInternal((state) => ({
      ...state,
      expression: item.expression,
      evaluatedResult: item.resultFormatted,
      evaluatedRaw: item.resultRaw,
      errorMessage: null,
      isEvaluated: false,
      repeatOp: null,
      repeatOperand: null,
    }));
  }

  reuseHistoryResult(item) {
    this._updateInternal((state) => {
      const base = state.isEvaluated ? '' : state.expression;
      const raw = item.resultRaw;
      const toAppend = raw.startsWith('−') && base.length > 0 ? `(${raw})` : raw;
      return {
        ...state,
        expression: base + toAppend,
        evaluatedResult: null,
        evaluatedRaw: null,
        errorMessage: null,
        isEvaluated: false,
      };
    });
  }

  deleteHistoryItem(id) {
    this._history.deleteById(id);
  }

  clearAllHistory() {
    this._history.clearAll();
  }
}
