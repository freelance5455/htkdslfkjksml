import { BigDecimal } from '../engine/bigDecimal.js';
import { AngleMode } from '../engine/calculationEngine.js';
import {
  FormattingOptions,
  NumberGroupingStyle,
  parseGroupingStyle,
} from '../engine/numberFormatter.js';

export const AppThemeMode = Object.freeze({
  OLED_DARK: Object.freeze({ name: 'OLED_DARK', label: 'OLED Dark' }),
  AETHER_DARK: Object.freeze({ name: 'AETHER_DARK', label: 'Slate Dark' }),
  LIGHT: Object.freeze({ name: 'LIGHT', label: 'Light' }),
});

export const AppThemeModes = Object.freeze(Object.values(AppThemeMode));

export function parseThemeMode(name) {
  return AppThemeModes.find((m) => m.name === name) ?? AppThemeMode.OLED_DARK;
}

export class UserPreferences {
  constructor({
    themeMode = AppThemeMode.OLED_DARK,
    hapticEnabled = true,
    groupingStyle = NumberGroupingStyle.COMMA,
    decimalPrecision = -1,
    angleMode = AngleMode.DEG,
    memoryValue = null,
  } = {}) {
    this.themeMode = typeof themeMode === 'string' ? parseThemeMode(themeMode) : themeMode;
    this.hapticEnabled = Boolean(hapticEnabled);
    this.groupingStyle =
      typeof groupingStyle === 'string' ? parseGroupingStyle(groupingStyle) : groupingStyle;
    this.decimalPrecision = Number.isInteger(decimalPrecision) ? decimalPrecision : -1;
    this.angleMode = angleMode === AngleMode.RAD ? AngleMode.RAD : AngleMode.DEG;
    this.memoryValue =
      memoryValue instanceof BigDecimal
        ? memoryValue
        : typeof memoryValue === 'string'
          ? BigDecimal.tryParse(memoryValue)
          : null;
  }

  get formattingOptions() {
    return new FormattingOptions({
      grouping: this.groupingStyle,
      decimalPrecision: this.decimalPrecision,
    });
  }

  copyWith(patch) {
    return new UserPreferences({
      themeMode: patch.themeMode !== undefined ? patch.themeMode : this.themeMode,
      hapticEnabled: patch.hapticEnabled !== undefined ? patch.hapticEnabled : this.hapticEnabled,
      groupingStyle: patch.groupingStyle !== undefined ? patch.groupingStyle : this.groupingStyle,
      decimalPrecision:
        patch.decimalPrecision !== undefined ? patch.decimalPrecision : this.decimalPrecision,
      angleMode: patch.angleMode !== undefined ? patch.angleMode : this.angleMode,
      memoryValue: patch.memoryValue !== undefined ? patch.memoryValue : this.memoryValue,
    });
  }
}

function getSafeStorage(explicitStorage) {
  if (explicitStorage) return explicitStorage;
  try {
    if (typeof globalThis !== 'undefined' && globalThis.localStorage) {
      return globalThis.localStorage;
    }
  } catch {
    // Ignore storage access restrictions
  }
  return null;
}

const PREFS_STORAGE_KEY = 'aether_calc_prefs_v1';
const HISTORY_STORAGE_KEY = 'aether_calc_history_v1';
const MAX_HISTORY_ITEMS = 500;

export class PreferencesStore {
  constructor({ storage = null, initial = null } = {}) {
    this._storage = getSafeStorage(storage);
    this._listeners = new Set();
    this._prefs = initial ?? this._loadFromStorage();
  }

  get value() {
    return this._prefs;
  }

  subscribe(fn) {
    this._listeners.add(fn);
    fn(this._prefs);
    return () => this._listeners.delete(fn);
  }

  _emit() {
    this._saveToStorage();
    for (const fn of this._listeners) {
      fn(this._prefs);
    }
  }

  _loadFromStorage() {
    if (!this._storage) return new UserPreferences();
    try {
      const raw = this._storage.getItem(PREFS_STORAGE_KEY);
      if (!raw) return new UserPreferences();
      const parsed = JSON.parse(raw);
      return new UserPreferences({
        themeMode: parseThemeMode(parsed.themeMode),
        hapticEnabled: typeof parsed.hapticEnabled === 'boolean' ? parsed.hapticEnabled : true,
        groupingStyle: parseGroupingStyle(parsed.groupingStyle),
        decimalPrecision: Number.isInteger(parsed.decimalPrecision) ? parsed.decimalPrecision : -1,
        angleMode: parsed.angleMode === 'RAD' ? AngleMode.RAD : AngleMode.DEG,
        memoryValue: parsed.memoryValue ? BigDecimal.tryParse(String(parsed.memoryValue)) : null,
      });
    } catch {
      return new UserPreferences();
    }
  }

  _saveToStorage() {
    if (!this._storage) return;
    try {
      const payload = {
        themeMode: this._prefs.themeMode.name,
        hapticEnabled: this._prefs.hapticEnabled,
        groupingStyle: this._prefs.groupingStyle.name,
        decimalPrecision: this._prefs.decimalPrecision,
        angleMode: this._prefs.angleMode,
        memoryValue: this._prefs.memoryValue ? this._prefs.memoryValue.toPlainString() : null,
      };
      this._storage.setItem(PREFS_STORAGE_KEY, JSON.stringify(payload));
    } catch {
      // Ignore quota errors
    }
  }

  setThemeMode(mode) {
    if (this._prefs.themeMode.name === mode?.name) return;
    this._prefs = this._prefs.copyWith({ themeMode: mode });
    this._emit();
  }

  setHapticEnabled(enabled) {
    const next = Boolean(enabled);
    if (this._prefs.hapticEnabled === next) return;
    this._prefs = this._prefs.copyWith({ hapticEnabled: next });
    this._emit();
  }

  setGroupingStyle(style) {
    if (this._prefs.groupingStyle.name === style?.name) return;
    this._prefs = this._prefs.copyWith({ groupingStyle: style });
    this._emit();
  }

  setDecimalPrecision(precision) {
    if (this._prefs.decimalPrecision === precision) return;
    this._prefs = this._prefs.copyWith({ decimalPrecision: precision });
    this._emit();
  }

  setAngleMode(mode) {
    if (this._prefs.angleMode === mode) return;
    this._prefs = this._prefs.copyWith({ angleMode: mode });
    this._emit();
  }

  setMemoryValue(value) {
    const next = value ?? null;
    if (this._prefs.memoryValue === null && next === null) return;
    this._prefs = this._prefs.copyWith({ memoryValue: next });
    this._emit();
  }
}

export class HistoryStore {
  constructor({ storage = null } = {}) {
    this._storage = getSafeStorage(storage);
    this._listeners = new Set();
    this._nextId = 1;
    this._items = this._loadFromStorage();
  }

  get value() {
    return this._items;
  }

  subscribe(fn) {
    this._listeners.add(fn);
    fn(this._items);
    return () => this._listeners.delete(fn);
  }

  _emit() {
    this._saveToStorage();
    for (const fn of this._listeners) {
      fn(this._items);
    }
  }

  _loadFromStorage() {
    if (!this._storage) return [];
    try {
      const raw = this._storage.getItem(HISTORY_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      const valid = parsed.filter(
        (it) =>
          it &&
          typeof it.expression === 'string' &&
          typeof it.resultFormatted === 'string' &&
          typeof it.resultRaw === 'string',
      );
      let maxId = 0;
      for (const item of valid) {
        if (typeof item.id === 'number' && item.id > maxId) maxId = item.id;
      }
      this._nextId = maxId + 1;
      return valid;
    } catch {
      return [];
    }
  }

  _saveToStorage() {
    if (!this._storage) return;
    try {
      this._storage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(this._items));
    } catch {
      // Ignore quota errors
    }
  }

  saveCalculation({ expression, resultFormatted, resultRaw, angleMode, isScientific }) {
    const entry = {
      id: this._nextId++,
      expression,
      resultFormatted,
      resultRaw,
      angleMode,
      isScientific: Boolean(isScientific),
      timestamp: Date.now(),
    };
    this._items = [entry, ...this._items].slice(0, MAX_HISTORY_ITEMS);
    this._emit();
    return entry;
  }

  deleteById(id) {
    this._items = this._items.filter((it) => it.id !== id);
    this._emit();
  }

  clearAll() {
    this._items = [];
    this._emit();
  }
}

export class InMemoryStorage {
  constructor() {
    this._map = new Map();
  }
  getItem(k) {
    return this._map.has(k) ? this._map.get(k) : null;
  }
  setItem(k, v) {
    this._map.set(k, String(v));
  }
  removeItem(k) {
    this._map.delete(k);
  }
  clear() {
    this._map.clear();
  }
}
