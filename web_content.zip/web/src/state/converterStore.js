import { FormattingOptions, NumberFormatter } from '../engine/numberFormatter.js';
import { ConverterCategory, UnitConverter } from '../engine/unitConverter.js';

export function parseStrictDouble(raw) {
  const s = (raw ?? '').trim().replaceAll('−', '-');
  if (!s) return null;
  if (!/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(s)) return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

export class ConverterStore {
  constructor() {
    const initialUnits = UnitConverter.unitsFor(ConverterCategory.LENGTH);
    this._state = {
      category: ConverterCategory.LENGTH,
      units: initialUnits,
      fromUnit: initialUnits[2], // m
      toUnit: initialUnits[5], // ft
      inputText: '1',
      customRateText: '',
    };
    this._listeners = new Set();
  }

  get state() {
    return this._state;
  }

  subscribe(fn) {
    this._listeners.add(fn);
    fn(this._state);
    return () => this._listeners.delete(fn);
  }

  _update(updater) {
    this._state = updater(this._state);
    for (const fn of this._listeners) {
      fn(this._state);
    }
  }

  computeOutput(formatting = new FormattingOptions()) {
    const inputVal = parseStrictDouble(this._state.inputText);
    if (inputVal === null) return '—';
    const customRate =
      this._state.category.isCurrency && this._state.customRateText.trim().length > 0
        ? parseStrictDouble(this._state.customRateText)
        : null;
    const converted = UnitConverter.convert(
      inputVal,
      this._state.fromUnit,
      this._state.toUnit,
      this._state.category,
      customRate,
    );
    if (converted === null) return '—';
    return NumberFormatter.formatDouble(converted, formatting);
  }

  effectiveRateLabel() {
    const { category, fromUnit, toUnit, customRateText } = this._state;
    if (fromUnit.id === toUnit.id) {
      return `1 ${fromUnit.symbol} = 1 ${toUnit.symbol}`;
    }
    if (category.name === 'TEMPERATURE') {
      const conv = UnitConverter.convert(1.0, fromUnit, toUnit, category) ?? 1.0;
      return `1 ${fromUnit.symbol} → ${NumberFormatter.formatDouble(conv)} ${toUnit.symbol}`;
    }
    if (category.name === 'FUEL_ECONOMY') {
      const conv = UnitConverter.convert(1.0, fromUnit, toUnit, category);
      return conv !== null
        ? `1 ${fromUnit.symbol} = ${NumberFormatter.formatDouble(conv)} ${toUnit.symbol}`
        : `${fromUnit.symbol} ↔ ${toUnit.symbol}`;
    }
    const custom = category.isCurrency ? parseStrictDouble(customRateText) : null;
    const rate =
      custom !== null && Number.isFinite(custom) && custom > 0.0
        ? custom
        : UnitConverter.defaultRateBetween(fromUnit, toUnit);
    return `1 ${fromUnit.symbol} = ${NumberFormatter.formatDouble(rate)} ${toUnit.symbol}`;
  }

  selectCategory(category) {
    const units = UnitConverter.unitsFor(category);
    const defaultFrom = units[0];
    const defaultTo = units.length > 1 ? units[1] : units[0];
    let from = defaultFrom;
    let to = defaultTo;
    if (category.name === 'LENGTH' || category.name === 'WEIGHT') {
      from = units[2];
      to = units[5];
    } else if (category.name === 'TEMPERATURE' || category.name === 'CURRENCY') {
      from = units[0];
      to = units[1];
    }

    this._update((current) => {
      const sanitizedInput =
        category.name !== 'TEMPERATURE' && current.inputText.startsWith('−')
          ? current.inputText.slice(1) || '0'
          : current.inputText;
      return {
        category,
        units,
        fromUnit: from,
        toUnit: to,
        inputText: sanitizedInput,
        customRateText: '',
      };
    });
  }

  selectFromUnit(unit) {
    this._update((s) => ({ ...s, fromUnit: unit, customRateText: '' }));
  }

  selectToUnit(unit) {
    this._update((s) => ({ ...s, toUnit: unit, customRateText: '' }));
  }

  swapUnits() {
    this._update((s) => ({
      ...s,
      fromUnit: s.toUnit,
      toUnit: s.fromUnit,
      customRateText: '',
    }));
  }

  onDigit(digit) {
    this._update((current) => {
      let next;
      if (current.inputText === '0') next = digit;
      else if (current.inputText === '−0') next = `−${digit}`;
      else if (current.inputText.length >= 16) next = current.inputText;
      else next = current.inputText + digit;
      return { ...current, inputText: next };
    });
  }

  onDecimal() {
    this._update((current) => {
      if (current.inputText.includes('.')) return current;
      const next =
        current.inputText.length === 0 || current.inputText === '−'
          ? `${current.inputText}0.`
          : `${current.inputText}.`;
      return { ...current, inputText: next };
    });
  }

  onToggleSign() {
    this._update((current) => {
      if (current.category.name !== 'TEMPERATURE') return current;
      const next = current.inputText.startsWith('−')
        ? current.inputText.slice(1)
        : `−${current.inputText}`;
      return { ...current, inputText: next };
    });
  }

  onBackspace() {
    this._update((current) => {
      const trimmed = current.inputText.slice(0, -1);
      return {
        ...current,
        inputText: trimmed.length === 0 || trimmed === '−' ? '0' : trimmed,
      };
    });
  }

  onClear() {
    this._update((s) => ({ ...s, inputText: '0' }));
  }

  onCustomRateChanged(rate) {
    const filtered = String(rate ?? '').replace(/[^0-9.]/g, '');
    this._update((s) => ({ ...s, customRateText: filtered }));
  }
}
