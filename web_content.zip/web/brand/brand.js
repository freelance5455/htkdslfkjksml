/* MR,KHORASANI — brand helpers (no build step needed) */
(function () {
  "use strict";

  // 1) Wordmark: the compiled bundle prints "MR KHORASANI"; brand spelling is "MR,KHORASANI".
  //    Only the existing text node's value is changed (React keeps ownership of the node).
  function fixWordmark() {
    var ps = document.querySelectorAll("#root p.font-display");
    for (var i = 0; i < ps.length; i++) {
      var t = ps[i].firstChild;
      if (t && t.nodeType === 3 && t.nodeValue.trim() === "MR KHORASANI") t.nodeValue = "MR,KHORASANI";
    }
  }
  var scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () { scheduled = false; fixWordmark(); });
  }
  function start() {
    var root = document.getElementById("root");
    if (!root) return;
    fixWordmark();
    var mo = new MutationObserver(schedule);
    mo.observe(root, { childList: true, subtree: true });
    setTimeout(function () { mo.disconnect(); }, 20000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();

  // 2) Offline / installable PWA (web only — the Android wrapper ships its own assets)
  var isWrapper = /MRKhorasaniFinance/.test(navigator.userAgent || "");
  if (!isWrapper && "serviceWorker" in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("./sw.js").catch(function () {});
    });
  }
})();
