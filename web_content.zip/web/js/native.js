// Pont vers les fonctions Android (plugins Capacitor). Regroupé dans l'APK par esbuild (voir build.mjs).
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { LocalNotifications } from '@capacitor/local-notifications';
import { App } from '@capacitor/app';
export const isNative = () => Capacitor.isNativePlatform();
export { Filesystem, Directory, Share, LocalNotifications, App };
