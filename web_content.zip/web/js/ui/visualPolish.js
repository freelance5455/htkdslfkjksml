/**
 * Visual polish helpers — progress rings, subject heroes, empty states, XP tick.
 */
import { subjectAccent } from "../engines/subjectRegistry.js";
import { mascotSvg, mascotLine, MASCOT_NAME } from "../engines/mascotEngine.js";

/** Circular progress ring (SVG). value 0–max. */
export function progressRing(el, value, max = 100, { size = 56, stroke = 5, label = "" } = {}) {
  const pct = max > 0 ? Math.max(0, Math.min(1, value / max)) : 0;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - pct);
  const wrap = el("div", {
    class: "progress-ring-wrap",
    style: `width:${size}px;height:${size}px;position:relative;flex-shrink:0;`
  });
  wrap.innerHTML = `<svg class="progress-ring" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <circle class="progress-ring-bg" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke-width="${stroke}"/>
    <circle class="progress-ring-fg" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke-width="${stroke}"
      stroke-dasharray="${c}" stroke-dashoffset="${offset}" stroke-linecap="round"
      transform="rotate(-90 ${size / 2} ${size / 2})"/>
  </svg>`;
  const mid = el("div", {
    class: "progress-ring-label",
    style: `position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;font-weight:800;font-size:${size < 50 ? 0.65 : 0.72}rem;line-height:1.1;text-align:center;pointer-events:none;`
  }, label || `${Math.round(pct * 100)}%`);
  wrap.appendChild(mid);
  return wrap;
}

/** Subject hero banner (gradient + simple scene SVG). */
export function subjectHero(el, subjectId, { title = "", subtitle = "" } = {}) {
  const acc = subjectAccent(subjectId);
  const scene = subjectSceneSvg(subjectId);
  const banner = el("div", {
    class: "subject-hero",
    style: `--subj-accent:${acc.hex};--subj-soft:${acc.soft};`
  }, [
    el("div", { class: "subject-hero-copy" }, [
      el("div", { class: "subject-hero-eyebrow" }, acc.label),
      el("div", { class: "subject-hero-title" }, title || acc.label),
      subtitle ? el("div", { class: "subject-hero-sub" }, subtitle) : null
    ].filter(Boolean)),
    el("div", { class: "subject-hero-art", "aria-hidden": "true" })
  ]);
  banner.querySelector(".subject-hero-art").innerHTML = scene;
  return banner;
}

function subjectSceneSvg(subjectId) {
  if (subjectId === "business_studies") {
    return `<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg" class="subject-scene">
      <rect x="18" y="28" width="28" height="40" rx="3" fill="#F59E0B" opacity="0.9"/>
      <rect x="50" y="18" width="28" height="50" rx="3" fill="#D97706"/>
      <rect x="82" y="34" width="24" height="34" rx="3" fill="#FBBF24" opacity="0.85"/>
      <rect x="24" y="34" width="8" height="8" rx="1" fill="#FFF7ED" opacity="0.7"/>
      <rect x="56" y="26" width="8" height="8" rx="1" fill="#FFF7ED" opacity="0.7"/>
      <rect x="88" y="40" width="8" height="8" rx="1" fill="#FFF7ED" opacity="0.7"/>
      <path d="M10 72 H110" stroke="#FDE68A" stroke-width="2" opacity="0.5"/>
    </svg>`;
  }
  if (subjectId === "tourism") {
    return `<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg" class="subject-scene">
      <circle cx="88" cy="22" r="12" fill="#FDE68A" opacity="0.9"/>
      <path d="M8 58 Q30 40 52 52 Q72 64 112 48" fill="none" stroke="#38BDF8" stroke-width="3" stroke-linecap="round"/>
      <path d="M20 70 Q40 55 60 62 Q85 72 110 58" fill="none" stroke="#7DD3FC" stroke-width="2.5" opacity="0.7"/>
      <path d="M48 48 L52 28 L62 48 Z" fill="#F8FAFC" opacity="0.95"/>
      <rect x="50" y="48" width="4" height="14" fill="#E2E8F0"/>
    </svg>`;
  }
  // Math Literacy — charts / coins feel
  return `<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg" class="subject-scene">
    <rect x="16" y="42" width="14" height="28" rx="2" fill="#2DD4BF" opacity="0.85"/>
    <rect x="36" y="28" width="14" height="42" rx="2" fill="#14B8A6"/>
    <rect x="56" y="18" width="14" height="52" rx="2" fill="#0D9488"/>
    <rect x="76" y="34" width="14" height="36" rx="2" fill="#5EEAD4" opacity="0.9"/>
    <circle cx="100" cy="28" r="14" fill="#FBBF24" opacity="0.95"/>
    <text x="100" y="33" text-anchor="middle" font-size="12" font-weight="800" fill="#78350F">R</text>
  </svg>`;
}

/** Empty state with Kepi. */
export function emptyState(el, { title = "Nothing here yet", body = "", ctaLabel = "", onCta = null, mood = "idle" } = {}) {
  const fig = el("div", { class: "empty-kepi", style: "line-height:0;display:flex;justify-content:center;" });
  fig.innerHTML = mascotSvg(mood, "72px");
  const kids = [
    fig,
    el("div", { class: "role-heading center", style: "margin-top:0.55rem;" }, title),
    body ? el("div", { class: "role-subtitle wrap center", style: "margin-top:0.25rem;" }, body) : null,
    el("div", { class: "role-muted center", style: "margin-top:0.35rem;font-size:0.8rem;" },
      `${MASCOT_NAME}: ${mascotLine(mood === "nudge" ? "empty" : "idle")}`)
  ].filter(Boolean);
  if (ctaLabel && onCta) {
    kids.push(el("button", { class: "btn cta-breathe", style: "margin-top:0.85rem;", onClick: onCta }, ctaLabel));
  }
  return el("div", { class: "card empty-state anim-rise", style: "text-align:center;padding:1.25rem 1rem;" }, kids);
}

/**
 * Animate a numeric text node from previous to next value.
 * elText: DOM element whose textContent is the number (or contains it).
 */
export function tickNumber(elText, from, to, { duration = 500, prefix = "", suffix = "" } = {}) {
  if (!elText) return;
  const reduce = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce || from === to) {
    elText.textContent = `${prefix}${to}${suffix}`;
    return;
  }
  const start = performance.now();
  const delta = to - from;
  function frame(now) {
    const t = Math.min(1, (now - start) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    const v = Math.round(from + delta * eased);
    elText.textContent = `${prefix}${v}${suffix}`;
    if (t < 1) requestAnimationFrame(frame);
    else {
      elText.textContent = `${prefix}${to}${suffix}`;
      elText.classList.add("score-pop");
      setTimeout(() => elText.classList.remove("score-pop"), 450);
    }
  }
  requestAnimationFrame(frame);
}
