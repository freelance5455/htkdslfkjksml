export const THEMES = [
  "Candy", "Classic Elite", "Midnight", "Academic", "Neon", "Glass",
  "Sunset", "Forest", "Ocean", "Aurora", "Gold", "High Contrast"
];

export const FONT_SCALES = { "Small": 0.85, "Normal": 1.0, "Large": 1.15, "Extra Large": 1.3 };

export function applyTheme(themeName, fontScaleName) {
  const theme = THEMES.includes(themeName) ? themeName : "Candy";
  const scale = FONT_SCALES[fontScaleName] ?? 1.0;
  document.documentElement.setAttribute("data-theme", theme);
  document.documentElement.style.fontSize = Math.max(10, Math.round(16 * scale)) + "px";
}

/** Tint chrome by current subject (ML teal / BS amber / Tourism sky). */
export function applySubjectAccent(subjectId) {
  const map = {
    mathematical_literacy: { hex: "#0D9488", soft: "rgba(13,148,136,0.14)", id: "ml" },
    business_studies: { hex: "#D97706", soft: "rgba(217,119,6,0.14)", id: "bs" },
    tourism: { hex: "#0284C7", soft: "rgba(2,132,199,0.14)", id: "tour" }
  };
  const a = map[subjectId] || map.mathematical_literacy;
  const root = document.documentElement;
  root.setAttribute("data-subject", a.id);
  root.style.setProperty("--subject-accent", a.hex);
  root.style.setProperty("--subject-soft", a.soft);
}
