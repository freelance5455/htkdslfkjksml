/**
 * Parseador del archivo Excel 'Calendari CTO 2026 L1.xlsm' en el cliente mediante SheetJS.
 */

// Mapeo exacto de columnas oficiales según ExcelTurnosParser.kt
const COLUMNAS_CONFIG = [
  // MAÑANA (D..P omitiendo N)
  { col: 3, letra: 'T1', franja: 'MAÑANA' },
  { col: 4, letra: 'T2', franja: 'MAÑANA' },
  { col: 5, letra: 'T3', franja: 'MAÑANA' },
  { col: 6, letra: 'T4', franja: 'MAÑANA' },
  { col: 7, letra: 'T5', franja: 'MAÑANA' },
  { col: 8, letra: 'T6', franja: 'MAÑANA' },
  { col: 9, letra: 'T7', franja: 'MAÑANA' },
  { col: 10, letra: 'T8', franja: 'MAÑANA' },
  { col: 11, letra: 'T9', franja: 'MAÑANA' },
  { col: 12, letra: 'ST2', franja: 'MAÑANA' },
  { col: 14, letra: 'ST9', franja: 'MAÑANA' },
  { col: 15, letra: 'ST4', franja: 'MAÑANA' },

  // TARDE (R..AB omitiendo AA)
  { col: 17, letra: 'R1', franja: 'TARDE' },
  { col: 18, letra: 'R2', franja: 'TARDE' },
  { col: 19, letra: 'R3', franja: 'TARDE' },
  { col: 20, letra: 'R4', franja: 'TARDE' },
  { col: 21, letra: 'R5', franja: 'TARDE' },
  { col: 22, letra: 'R6', franja: 'TARDE' },
  { col: 23, letra: 'CR7', franja: 'TARDE' },
  { col: 24, letra: 'R8', franja: 'TARDE' },
  { col: 25, letra: 'R9', franja: 'TARDE' },
  { col: 27, letra: 'SR6', franja: 'TARDE' },

  // NOCHE (AF..AM)
  { col: 31, letra: 'N1', franja: 'NOCHE' },
  { col: 32, letra: 'N2', franja: 'NOCHE' },
  { col: 33, letra: 'N3', franja: 'NOCHE' },
  { col: 34, letra: 'N5', franja: 'NOCHE' },
  { col: 35, letra: 'N5.1', franja: 'NOCHE' },
  { col: 36, letra: 'N6', franja: 'NOCHE' },
  { col: 37, letra: 'N1T', franja: 'NOCHE' },
  { col: 38, letra: 'N6R', franja: 'NOCHE' }
];

async function calcularHashMd5(texto) {
  try {
    const msgUint8 = new TextEncoder().encode(texto);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 32);
  } catch (_) {
    let hash = 0;
    for (let i = 0; i < texto.length; i++) {
      hash = ((hash << 5) - hash) + texto.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(16);
  }
}

function normalizarFechaExcel(valorCelda) {
  if (!valorCelda) return '';
  if (typeof valorCelda === 'string') {
    const s = valorCelda.trim();
    if (s.match(/^\d{4}-\d{2}-\d{2}$/)) return s;
    if (s.match(/^\d{2}-\d{2}-\d{4}$/)) {
      const p = s.split('-');
      return `${p[2]}-${p[1]}-${p[0]}`;
    }
    if (s.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
      const p = s.split('/');
      return `${p[2]}-${p[1]}-${p[0]}`;
    }
  }

  // Si es un número serial de fecha de Excel
  if (typeof valorCelda === 'number') {
    const fecha = new Date(Math.round((valorCelda - 25569) * 86400 * 1000));
    const y = fecha.getUTCFullYear();
    const m = String(fecha.getUTCMonth() + 1).padStart(2, '0');
    const d = String(fecha.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  if (valorCelda instanceof Date) {
    const y = valorCelda.getFullYear();
    const m = String(valorCelda.getMonth() + 1).padStart(2, '0');
    const d = String(valorCelda.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  return '';
}

/**
 * Parsea el ArrayBuffer del archivo Excel descargado o subido.
 */
async function parsearExcelCuadrante(arrayBuffer, onProgreso = null) {
  if (typeof XLSX === 'undefined') {
    throw new Error('Librería SheetJS (XLSX) no disponible');
  }

  if (onProgreso) onProgreso('Leyendo libro Excel...');
  const workbook = XLSX.read(arrayBuffer, { type: 'array', cellDates: true, cellComments: true });

  const nombreHoja = workbook.SheetNames.includes('COL1') ? 'COL1' : workbook.SheetNames[0];
  const worksheet = workbook.Sheets[nombreHoja];
  if (!worksheet) throw new Error(`No se encontró la hoja ${nombreHoja} en el Excel.`);

  if (onProgreso) onProgreso('Extrayendo servicios y turnos...');

  const serviciosNuevos = [];
  const empleadosDetectados = [];

  // 1. Extraer Nombres y Matrículas de filas 2 y 3 (índices base 0: row 1 y row 2)
  for (const cfg of COLUMNAS_CONFIG) {
    const cellRefNombre = XLSX.utils.encode_cell({ r: 1, c: cfg.col });
    const cellRefNumero = XLSX.utils.encode_cell({ r: 2, c: cfg.col });

    const nombre = worksheet[cellRefNombre] ? String(worksheet[cellRefNombre].v).trim() : '';
    let num = worksheet[cellRefNumero] ? String(worksheet[cellRefNumero].v).trim() : '';
    if (num.endsWith('.0')) num = num.substring(0, num.length - 2);

    if (num && nombre) {
      empleadosDetectados.push({
        numeroEmpleado: num,
        nombreCompleto: nombre,
        letra: cfg.letra,
        telefono: typeof obtenerTelefonoEmpleado === 'function' ? obtenerTelefonoEmpleado(num) : '',
        fotoUri: ''
      });
    }
  }

  // 2. Extraer Filas de Fechas (filas 5 a 379)
  const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1:AM400');
  const startRow = 4; // Fila 5 (índice 4 en base 0)
  const endRow = Math.min(range.e.r, 378);

  for (let r = startRow; r <= endRow; r++) {
    const cellRefFecha = XLSX.utils.encode_cell({ r: r, c: 0 });
    const rawFecha = worksheet[cellRefFecha] ? worksheet[cellRefFecha].v : null;
    const fechaIso = normalizarFechaExcel(rawFecha);

    if (!fechaIso) continue;

    for (const cfg of COLUMNAS_CONFIG) {
      const cellRef = XLSX.utils.encode_cell({ r: r, c: cfg.col });
      const cell = worksheet[cellRef];
      let servicio = cell && cell.v !== undefined ? String(cell.v).trim() : '';

      // Comentario / Nota de la celda
      let nota = '';
      if (cell && cell.c && cell.c.length > 0) {
        nota = cell.c[0].t ? cell.c[0].t.trim() : '';
      }

      serviciosNuevos.push({
        fecha: fechaIso,
        letra: cfg.letra,
        franja: cfg.franja,
        servicio: servicio,
        nota: nota,
        lineas: ''
      });
    }
  }

  if (onProgreso) onProgreso('Calculando variaciones de servicios...');

  // 3. Detectar variaciones respecto a los datos previos en IndexedDB
  const variacionesDetectadas = [];
  const timestampAhora = new Date().toLocaleString('es-ES');

  for (const nuevo of serviciosNuevos) {
    const previosDelDia = await obtenerServiciosPorFecha(nuevo.fecha);
    const previo = previosDelDia.find(p => p.letra === nuevo.letra);

    if (previo) {
      const servCambio = (previo.servicio || '').trim() !== (nuevo.servicio || '').trim();
      const notaCambio = (previo.nota || '').trim() !== (nuevo.nota || '').trim();
      const lineasCambio = (previo.lineas || '').trim() !== (nuevo.lineas || '').trim();

      if (servCambio || notaCambio || lineasCambio) {
        const emp = empleadosDetectados.find(e => e.letra === nuevo.letra);
        const hash = await calcularHashMd5(
          `${nuevo.fecha}|${nuevo.letra}|${previo.servicio}|${nuevo.servicio}|${nuevo.nota}|${nuevo.lineas}`
        );

        variacionesDetectadas.push({
          fechaModificacion: timestampAhora,
          fechaServicio: nuevo.fecha,
          letra: nuevo.letra,
          empleadoNombre: emp ? emp.nombreCompleto : '',
          servicioAnterior: previo.servicio || '',
          servicioNuevo: nuevo.servicio || '',
          notaAnterior: previo.nota || '',
          notaNueva: nuevo.nota || '',
          lineasAnterior: previo.lineas || '',
          lineasNueva: nuevo.lineas || '',
          tipoCambio: servCambio ? 'SERVICIO_MODIFICADO' : 'NOTA_MODIFICADA',
          origen: 'iPhone SharePoint Sync',
          visto: false,
          hashCambio: hash
        });
      }
    }
  }

  // 4. Guardar datos en IndexedDB
  if (onProgreso) onProgreso('Guardando servicios en almacenamiento local...');
  await guardarServiciosLote(serviciosNuevos);

  if (empleadosDetectados.length > 0) {
    await guardarEmpleadosLote(empleadosDetectados);
  }

  if (variacionesDetectadas.length > 0) {
    await guardarCambiosHistorial(variacionesDetectadas);
    // Subir variaciones a Supabase para auditoría común
    await supabase.subirVariacionesHistorial(variacionesDetectadas);
  }

  return {
    totalServicios: serviciosNuevos.length,
    variaciones: variacionesDetectadas.length,
    listaVariaciones: variacionesDetectadas
  };
}

// =================== PARSER OFICIAL DE CALENDARIO EVENTOS.xlsx ===================

/**
 * Parsea el archivo corporativo "CALENDARIO EVENTOS.xlsx" con la misma
 * lógica de negocio y reglas que ExcelEventosParser.kt de Android.
 */
async function parsearExcelEventos(arrayBuffer, onProgreso = null) {
  if (typeof XLSX === 'undefined') {
    throw new Error('Librería SheetJS (XLSX) no disponible');
  }

  if (onProgreso) onProgreso('Leyendo libro de Eventos...');
  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const eventosMap = {}; // Clave: "YYYY-MM-DD"

  const MESES_MAP = {
    'enero': 1, 'gener': 1,
    'febrero': 2, 'febrer': 2,
    'marzo': 3, 'març': 3, 'marc': 3,
    'abril': 4,
    'mayo': 5, 'maig': 5,
    'junio': 6, 'juny': 6,
    'julio': 7, 'juliol': 7,
    'agosto': 8, 'agost': 8,
    'septiembre': 9, 'setembre': 9,
    'octubre': 10,
    'noviembre': 11, 'novembre': 11,
    'diciembre': 12, 'desembre': 12, 'decembre': 12
  };

  const SEMANAS_FILAS = [
    [4, 5],   // Fila 5 (días, índice 4) y Fila 6 (eventos, índice 5)
    [6, 7],   // Fila 7 y Fila 8
    [8, 9],   // Fila 9 y Fila 10
    [10, 11], // Fila 11 y Fila 12
    [12, 13], // Fila 13 y Fila 14
    [14, 15]  // Fila 15 y Fila 16
  ];

  function detectarMesYAnio(nombreHoja, textoC2) {
    const combinado = `${textoC2 || ''} ${nombreHoja}`.toLowerCase().trim();

    // 1. Detectar mes
    let mes = null;
    for (const [nom, num] of Object.entries(MESES_MAP)) {
      const reg = new RegExp(`\\b${nom}\\b`, 'i');
      if (reg.test(combinado)) {
        mes = num;
        break;
      }
    }
    if (!mes) return null;

    // 2. Detectar año (4 dígitos o 2 dígitos)
    const match4 = combinado.match(/\b(202[4-9]|203[0-9])\b/);
    let anio = null;
    if (match4) {
      anio = parseInt(match4[1], 10);
    } else {
      const match2 = combinado.match(/\b(2[4-9]|3[0-9])\b/);
      if (match2) {
        anio = 2000 + parseInt(match2[1], 10);
      }
    }

    if (!anio) return null;
    return { mes, anio };
  }

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) continue;

    // Leer celda C2 (fila 2, columna C -> r: 1, c: 2)
    const cellC2 = sheet[XLSX.utils.encode_cell({ r: 1, c: 2 })];
    const textoC2 = cellC2 ? String(cellC2.v).trim() : '';

    const mesAnio = detectarMesYAnio(sheetName, textoC2);
    if (!mesAnio) continue;

    const { mes, anio } = mesAnio;
    // Filtrar solo 2026 en adelante por optimización
    if (anio < 2026) continue;

    let pasoDiaUno = false;

    for (const [filaDiaIdx, filaEventoIdx] of SEMANAS_FILAS) {
      for (let colIdx = 2; colIdx <= 8; colIdx++) { // Columnas C a I (Lunes a Domingo)
        const cellDia = sheet[XLSX.utils.encode_cell({ r: filaDiaIdx, c: colIdx })];
        if (!cellDia || cellDia.v === undefined || cellDia.v === null) continue;

        let diaNumero = null;
        if (typeof cellDia.v === 'number') {
          diaNumero = Math.round(cellDia.v);
        } else if (typeof cellDia.v === 'string') {
          const numParsed = parseInt(cellDia.v.trim(), 10);
          if (!isNaN(numParsed)) diaNumero = numParsed;
        }

        if (diaNumero === null || diaNumero < 1 || diaNumero > 31) continue;

        if (diaNumero === 1) {
          pasoDiaUno = true;
        }

        let fechaCalculada = null;
        try {
          if (!pasoDiaUno) {
            // Días previos al 1 corresponden al mes anterior
            if (mes === 1) {
              fechaCalculada = { a: anio - 1, m: 12, d: diaNumero };
            } else {
              fechaCalculada = { a: anio, m: mes - 1, d: diaNumero };
            }
          } else {
            // Si ya pasamos el día 1, y en las últimas semanas (filas >= 10) aparece un día pequeño (< 15), es del mes siguiente
            if (diaNumero < 15 && filaDiaIdx >= 10) {
              if (mes === 12) {
                fechaCalculada = { a: anio + 1, m: 1, d: diaNumero };
              } else {
                fechaCalculada = { a: anio, m: mes + 1, d: diaNumero };
              }
            } else {
              fechaCalculada = { a: anio, m: mes, d: diaNumero };
            }
          }
        } catch (_) {
          continue;
        }

        if (!fechaCalculada) continue;

        const cellEvento = sheet[XLSX.utils.encode_cell({ r: filaEventoIdx, c: colIdx })];
        const textoEvento = cellEvento && cellEvento.v !== undefined ? String(cellEvento.v).trim() : '';

        if (!textoEvento) continue;

        // Ignorar aforos generales que no son eventos
        const upper = textoEvento.toUpperCase();
        if (upper.includes('AFORO PALAU') || upper.includes('AFORO SANT JORDI')) {
          continue;
        }

        const fechaIso = `${fechaCalculada.a}-${String(fechaCalculada.m).padStart(2, '0')}-${String(fechaCalculada.d).padStart(2, '0')}`;

        if (eventosMap[fechaIso]) {
          if (!eventosMap[fechaIso].descripcion.toLowerCase().includes(textoEvento.toLowerCase())) {
            eventosMap[fechaIso].descripcion += '\n\n' + textoEvento;
          }
        } else {
          eventosMap[fechaIso] = {
            fecha: fechaIso,
            descripcion: textoEvento,
            mesOrigen: sheetName
          };
        }
      }
    }
  }

  const resultado = Object.values(eventosMap);
  if (onProgreso) onProgreso(`Guardando ${resultado.length} fechas con eventos...`);
  await guardarEventosLote(resultado);

  return resultado;
}

/**
 * Clasificador temático y visual oficial de eventos idéntico a EventoDetailDialog.kt de Android.
 */
function obtenerIconoYColorEvento(descripcion) {
  const texto = (descripcion || '').toLowerCase();

  if (
    texto.includes('concert') || texto.includes('concierto') || texto.includes('sonar') ||
    texto.includes('music') || texto.includes('ot 2025') || texto.includes('aitana') ||
    texto.includes('morat') || texto.includes('dani martin')
  ) {
    return {
      tipo: 'musica',
      primerColor: '#6750A4',
      segundoColor: '#EADDFF',
      icono: 'music'
    };
  }

  if (
    texto.includes('barça') || texto.includes('porto') || texto.includes('atletic') ||
    texto.includes('madrid') || texto.includes('padel') || texto.includes('cursa') ||
    texto.includes('tour france') || texto.includes('ciclista')
  ) {
    return {
      tipo: 'deporte',
      primerColor: '#B3261E',
      segundoColor: '#F9DEDC',
      icono: 'sports'
    };
  }

  if (
    texto.includes('vaga') || texto.includes('huelga') || texto.includes('manifestac') ||
    texto.includes('tancament') || texto.includes('afectaci')
  ) {
    return {
      tipo: 'alerta',
      primerColor: '#E65100',
      segundoColor: '#FFE0B2',
      icono: 'warning'
    };
  }

  return {
    tipo: 'general',
    primerColor: '#006C50',
    segundoColor: '#CCE8DE',
    icono: 'event'
  };
}

