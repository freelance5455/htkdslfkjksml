/**
 * Parseador del archivo Excel 'Calendari CTO 2026 L1.xlsm' en el cliente mediante SheetJS.
 */

// Mapeo exacto de columnas oficiales según ExcelTurnosParser.kt
const COLUMNAS_CONFIG = [
  // MAÑANA (D..P omitiendo N)
  { col: 3, letra: 'T1', franja: 'MAÑANA' },
  { col: 4, letra: 'T2', franja: 'MAÑANA' },
  { col: 5, letra: 'T3', franja: 'MAÑANA' },
  { col: 6, letra: 'T4', franja: 'MAÑANA' },
  { col: 7, letra: 'T5', franja: 'MAÑANA' },
  { col: 8, letra: 'T6', franja: 'MAÑANA' },
  { col: 9, letra: 'T7', franja: 'MAÑANA' },
  { col: 10, letra: 'T8', franja: 'MAÑANA' },
  { col: 11, letra: 'T9', franja: 'MAÑANA' },
  { col: 12, letra: 'ST2', franja: 'MAÑANA' },
  { col: 14, letra: 'ST9', franja: 'MAÑANA' },
  { col: 15, letra: 'ST4', franja: 'MAÑANA' },

  // TARDE (R..AB omitiendo AA)
  { col: 17, letra: 'R1', franja: 'TARDE' },
  { col: 18, letra: 'R2', franja: 'TARDE' },
  { col: 19, letra: 'R3', franja: 'TARDE' },
  { col: 20, letra: 'R4', franja: 'TARDE' },
  { col: 21, letra: 'R5', franja: 'TARDE' },
  { col: 22, letra: 'R6', franja: 'TARDE' },
  { col: 23, letra: 'CR7', franja: 'TARDE' },
  { col: 24, letra: 'R8', franja: 'TARDE' },
  { col: 25, letra: 'R9', franja: 'TARDE' },
  { col: 27, letra: 'SR6', franja: 'TARDE' },

  // NOCHE (AF..AM)
  { col: 31, letra: 'N1', franja: 'NOCHE' },
  { col: 32, letra: 'N2', franja: 'NOCHE' },
  { col: 33, letra: 'N3', franja: 'NOCHE' },
  { col: 34, letra: 'N5', franja: 'NOCHE' },
  { col: 35, letra: 'N5.1', franja: 'NOCHE' },
  { col: 36, letra: 'N6', franja: 'NOCHE' },
  { col: 37, letra: 'N1T', franja: 'NOCHE' },
  { col: 38, letra: 'N6R', franja: 'NOCHE' }
];

async function calcularHashMd5(texto) {
  try {
    const msgUint8 = new TextEncoder().encode(texto);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 32);
  } catch (_) {
    let hash = 0;
    for (let i = 0; i < texto.length; i++) {
      hash = ((hash << 5) - hash) + texto.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(16);
  }
}

function normalizarFechaExcel(valorCelda) {
  if (!valorCelda) return '';
  if (typeof valorCelda === 'string') {
    const s = valorCelda.trim();
    if (s.match(/^\d{4}-\d{2}-\d{2}$/)) return s;
    if (s.match(/^\d{2}-\d{2}-\d{4}$/)) {
      const p = s.split('-');
      return `${p[2]}-${p[1]}-${p[0]}`;
    }
    if (s.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
      const p = s.split('/');
      return `${p[2]}-${p[1]}-${p[0]}`;
    }
  }

  // Si es un número serial de fecha de Excel
  if (typeof valorCelda === 'number') {
    const fecha = new Date(Math.round((valorCelda - 25569) * 86400 * 1000));
    const y = fecha.getUTCFullYear();
    const m = String(fecha.getUTCMonth() + 1).padStart(2, '0');
    const d = String(fecha.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  if (valorCelda instanceof Date) {
    const y = valorCelda.getFullYear();
    const m = String(valorCelda.getMonth() + 1).padStart(2, '0');
    const d = String(valorCelda.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  return '';
}

/**
 * Parsea el ArrayBuffer del archivo Excel descargado o subido.
 */
async function parsearExcelCuadrante(arrayBuffer, onProgreso = null) {
  if (typeof XLSX === 'undefined') {
    throw new Error('Librería SheetJS (XLSX) no disponible');
  }

  if (onProgreso) onProgreso('Leyendo libro Excel...');
  const workbook = XLSX.read(arrayBuffer, { type: 'array', cellDates: true, cellComments: true });

  const nombreHoja = workbook.SheetNames.includes('COL1') ? 'COL1' : workbook.SheetNames[0];
  const worksheet = workbook.Sheets[nombreHoja];
  if (!worksheet) throw new Error(`No se encontró la hoja ${nombreHoja} en el Excel.`);

  if (onProgreso) onProgreso('Extrayendo servicios y turnos...');

  const serviciosNuevos = [];
  const empleadosDetectados = [];

  // 1. Extraer Nombres y Matrículas de filas 2 y 3 (índices base 0: row 1 y row 2)
  for (const cfg of COLUMNAS_CONFIG) {
    const cellRefNombre = XLSX.utils.encode_cell({ r: 1, c: cfg.col });
    const cellRefNumero = XLSX.utils.encode_cell({ r: 2, c: cfg.col });

    const nombre = worksheet[cellRefNombre] ? String(worksheet[cellRefNombre].v).trim() : '';
    let num = worksheet[cellRefNumero] ? String(worksheet[cellRefNumero].v).trim() : '';
    if (num.endsWith('.0')) num = num.substring(0, num.length - 2);

    if (num && nombre) {
      empleadosDetectados.push({
        numeroEmpleado: num,
        nombreCompleto: nombre,
        letra: cfg.letra,
        telefono: '',
        fotoUri: ''
      });
    }
  }

  // 2. Extraer Filas de Fechas (filas 5 a 379)
  const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1:AM400');
  const startRow = 4; // Fila 5 (índice 4 en base 0)
  const endRow = Math.min(range.e.r, 378);

  for (let r = startRow; r <= endRow; r++) {
    const cellRefFecha = XLSX.utils.encode_cell({ r: r, c: 0 });
    const rawFecha = worksheet[cellRefFecha] ? worksheet[cellRefFecha].v : null;
    const fechaIso = normalizarFechaExcel(rawFecha);

    if (!fechaIso) continue;

    for (const cfg of COLUMNAS_CONFIG) {
      const cellRef = XLSX.utils.encode_cell({ r: r, c: cfg.col });
      const cell = worksheet[cellRef];
      let servicio = cell && cell.v !== undefined ? String(cell.v).trim() : '';

      // Comentario / Nota de la celda
      let nota = '';
      if (cell && cell.c && cell.c.length > 0) {
        nota = cell.c[0].t ? cell.c[0].t.trim() : '';
      }

      serviciosNuevos.push({
        fecha: fechaIso,
        letra: cfg.letra,
        franja: cfg.franja,
        servicio: servicio,
        nota: nota,
        lineas: ''
      });
    }
  }

  if (onProgreso) onProgreso('Calculando variaciones de servicios...');

  // 3. Detectar variaciones respecto a los datos previos en IndexedDB
  const variacionesDetectadas = [];
  const timestampAhora = new Date().toLocaleString('es-ES');

  for (const nuevo of serviciosNuevos) {
    const previosDelDia = await obtenerServiciosPorFecha(nuevo.fecha);
    const previo = previosDelDia.find(p => p.letra === nuevo.letra);

    if (previo) {
      const servCambio = (previo.servicio || '').trim() !== (nuevo.servicio || '').trim();
      const notaCambio = (previo.nota || '').trim() !== (nuevo.nota || '').trim();
      const lineasCambio = (previo.lineas || '').trim() !== (nuevo.lineas || '').trim();

      if (servCambio || notaCambio || lineasCambio) {
        const emp = empleadosDetectados.find(e => e.letra === nuevo.letra);
        const hash = await calcularHashMd5(
          `${nuevo.fecha}|${nuevo.letra}|${previo.servicio}|${nuevo.servicio}|${nuevo.nota}|${nuevo.lineas}`
        );

        variacionesDetectadas.push({
          fechaModificacion: timestampAhora,
          fechaServicio: nuevo.fecha,
          letra: nuevo.letra,
          empleadoNombre: emp ? emp.nombreCompleto : '',
          servicioAnterior: previo.servicio || '',
          servicioNuevo: nuevo.servicio || '',
          notaAnterior: previo.nota || '',
          notaNueva: nuevo.nota || '',
          lineasAnterior: previo.lineas || '',
          lineasNueva: nuevo.lineas || '',
          tipoCambio: servCambio ? 'SERVICIO_MODIFICADO' : 'NOTA_MODIFICADA',
          origen: 'iPhone SharePoint Sync',
          visto: false,
          hashCambio: hash
        });
      }
    }
  }

  // 4. Guardar datos en IndexedDB
  if (onProgreso) onProgreso('Guardando servicios en almacenamiento local...');
  await guardarServiciosLote(serviciosNuevos);

  if (empleadosDetectados.length > 0) {
    await guardarEmpleadosLote(empleadosDetectados);
  }

  if (variacionesDetectadas.length > 0) {
    await guardarCambiosHistorial(variacionesDetectadas);
    // Subir variaciones a Supabase para auditoría común
    await supabase.subirVariacionesHistorial(variacionesDetectadas);
  }

  return {
    totalServicios: serviciosNuevos.length,
    variaciones: variacionesDetectadas.length,
    listaVariaciones: variacionesDetectadas
  };
}
