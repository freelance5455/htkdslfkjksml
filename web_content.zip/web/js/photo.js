// Champ photo : Caméra (prise de vue) ou Fichier (stockage du téléphone). Image réduite (JPEG) et stockée dans l'appareil.
import { h, icon, openSheet, toast } from './util.js';
import { t } from './i18n.js';

const MAX = 1280;
export function shrink(file, max = MAX, q = 0.8) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      res(c.toDataURL('image/jpeg', q));
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); };
    img.src = url;
  });
}
export function viewPhoto(src, title) {
  openSheet({ title, full: true, body: h('div', { class: 'photo-view' }, h('img', { src, alt: title })) });
}
export function buildPhoto(label, val) {
  let value = val || '';
  const prev = h('div', { class: 'photo-prev' }), node = h('div', { class: 'field photo-field' }, h('label', null, label), prev);
  const pick = (cam) => {
    const inp = h('input', { type: 'file', accept: 'image/*', class: 'photo-in', 'aria-label': t(cam ? 'photo.camera' : 'photo.file') });
    if (cam) inp.setAttribute('capture', 'environment');
    inp.addEventListener('change', async () => {
      const f = inp.files[0]; if (!f) return;
      try { value = await shrink(f); render(); } catch { toast(t('photo.err')); }
    });
    return h('label', { class: 'btn outline photo-btn' }, icon(cam ? 'camera' : 'upload', 18), t(cam ? 'photo.camera' : 'photo.file'), inp);
  };
  const render = () => {
    prev.replaceChildren(
      value ? h('img', { class: 'photo-img', src: value, alt: label, onclick: () => viewPhoto(value, label) }) : h('div', { class: 'photo-empty' }, t('photo.none')),
      h('div', { class: 'photo-btns' }, pick(true), pick(false),
        value ? h('button', { type: 'button', class: 'btn text', onclick: () => { value = ''; render(); } }, icon('delete', 18), t('common.delete')) : null));
  };
  render();
  return { node, get: () => value };
}
