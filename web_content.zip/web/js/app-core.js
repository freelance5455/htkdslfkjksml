import { state } from './store.js';
import { ACCENTS } from './schema.js';
import { isNative, App } from './native.js';
export const APP_VERSION = '1.0.0';

const hostTheme = document.documentElement.dataset.theme || '';
export function applySettings() {
  const s = state.settings, r = document.documentElement;
  const dark = s.theme === 'dark' || (s.theme === 'auto' && (hostTheme ? hostTheme === 'dark' : window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches));
  r.dataset.theme = dark ? 'dark' : 'light';
  r.style.setProperty('--primary', ACCENTS[s.accent] || ACCENTS.green);
  r.style.fontSize = 16 * (s.fontScale || 1) + 'px';
  r.lang = s.lang || 'fr';
  const m = document.querySelector('meta[name=theme-color]'); if (m) m.content = ACCENTS[s.accent] || ACCENTS.green;
}
export async function appInfo() {
  try { if (isNative()) { const i = await App.getInfo(); return `${i.version} (${i.build})`; } } catch (e) { /* ignore */ }
  return `${APP_VERSION} (web)`;
}
