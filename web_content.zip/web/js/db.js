import { GradeManager } from "./engines/gradeManager.js";

const KEY_PREFIX = "learnly:student:";
const keyFor = (code) => KEY_PREFIX + String(code).trim().toUpperCase();
const todayStr = () => new Date().toISOString().slice(0, 10);

export function readStudentRaw(code) {
  const raw = localStorage.getItem(keyFor(code));
  try { return raw ? JSON.parse(raw) : null; } catch { return null; }
}

export function writeStudentRaw(student) {
  student.updated_at = new Date().toISOString();
  localStorage.setItem(keyFor(student.code), JSON.stringify(student));
  return student;
}

// Matches app.py: engine.grade_manager.GradeManager.topic_ids() seeds mastery,
// so mastery is always grade-correct from creation, never a hardcoded topic list.
export function createDefaultStudent(code, grade = 8) {
  const gm = new GradeManager(grade);
  const now = new Date().toISOString();
  const mastery = {};
  gm.topicIds().forEach((t) => (mastery[t] = 0.5));
  return {
    code: String(code).trim().toUpperCase(),
    name: `Student ${String(code).trim().toUpperCase()}`,
    grade: gm.grade, subject: "Mathematics", term: 1,
    programme_name: "The Elites Academy",
    daily_goal: 20, today_done: 0, daily_goal_date: todayStr(),
    streak: 0, xp: 0, level: 1,
    created_at: now, updated_at: now, last_login: now,
    mastery, topic_stats: {},
    settings: {
      theme: "Classic Elite", font_scale: "Normal", hints: true, sound: true,
      animations: true, show_solutions: true, confirm_reset: true, difficulty_pref: "Standard"
    },
    history: [], papers: [], mistakes: [], strengths: [], weaknesses: [],
    mental_best_streak: 0, credits: 0, transactions: [], achievements: [],
    mastery_seen_low: {}, daily_goal_rewarded_date: null, schema_version: 5
  };
}

// Port of LearnlyApp.login(): existing students keep their own saved grade;
// the grade picker on the login screen only ever applies to brand-new profiles.
export function login(code, grade = 8, name = null) {
  code = String(code).trim().toUpperCase();
  let student = readStudentRaw(code);
  if (student) {
    const existingGrade = student.grade ?? grade;
    const defaults = createDefaultStudent(code, existingGrade);
    for (const k of Object.keys(defaults)) {
      if (k === "mastery") continue;
      if (student[k] === undefined) student[k] = defaults[k];
    }
    student.mastery = student.mastery || {};
    for (const [topic, v] of Object.entries(defaults.mastery)) {
      if (student.mastery[topic] === undefined) student.mastery[topic] = v;
    }
    if (name && name.trim()) student.name = name.trim();
  } else {
    student = createDefaultStudent(code, grade);
    if (name && name.trim()) student.name = name.trim();
  }
  const today = todayStr();
  if (student.daily_goal_date !== today) {
    student.daily_goal_date = today;
    student.today_done = 0;
  }
  student.last_login = new Date().toISOString();
  writeStudentRaw(student);
  return student;
}

// Port of LearnlyApp.change_grade(): purges mastery/weaknesses/strengths that
// don't belong to the new grade so nothing from the old grade leaks through.
export function changeGrade(student, newGrade) {
  const gm = new GradeManager(newGrade);
  student.grade = gm.grade;
  const validIds = new Set(gm.topicIds());
  const oldMastery = student.mastery || {};
  const mastery = {};
  validIds.forEach((t) => (mastery[t] = oldMastery[t] ?? 0.5));
  student.mastery = mastery;
  student.weaknesses = (student.weaknesses || []).filter((t) => validIds.has(t));
  student.strengths = (student.strengths || []).filter((t) => validIds.has(t));
  writeStudentRaw(student);
  return student;
}

export function exportStudent(student) {
  const payload = { format: "learnly_grade8_export_v1", exported_at: new Date().toISOString(), student };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${student.code}_${new Date().toISOString().replace(/[:.]/g, "-").slice(0, 15)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

// Timestamp-aware merge: an import can never silently overwrite newer local data.
export function importStudentText(text, currentStudent) {
  let data;
  try { data = JSON.parse(text); } catch (e) { return { imported: false, reason: "bad_json", error: String(e) }; }
  const incoming = data.student || data;
  const currentUpdated = currentStudent.updated_at || "";
  const incomingUpdated = incoming.updated_at || "";
  if (incomingUpdated && incomingUpdated <= currentUpdated) {
    return { imported: false, reason: "older_or_same" };
  }
  Object.assign(currentStudent, incoming);
  writeStudentRaw(currentStudent);
  return { imported: true };
}

export function resetTodayProgress(student) {
  student.today_done = 0;
  student.streak = 0;
  writeStudentRaw(student);
}


/* ——— 15-day device licence (The Elites Academy) ——— */
const LICENCE_KEY = "learnly_g10:licence_until";
export const LICENCE_DAYS = 15;
export function getLicenceUntil() {
  try {
    const raw = localStorage.getItem(LICENCE_KEY);
    if (!raw) return null;
    const t = Date.parse(raw);
    return Number.isFinite(t) ? t : null;
  } catch { return null; }
}
export function licenceDaysLeft() {
  const until = getLicenceUntil();
  if (!until) return 0;
  return Math.max(0, Math.ceil((until - Date.now()) / 86400000));
}
export function isLicenceValid() {
  const until = getLicenceUntil();
  return until != null && until > Date.now();
}
export function activateLicence(days = LICENCE_DAYS) {
  const until = new Date(Date.now() + days * 86400000);
  try { localStorage.setItem(LICENCE_KEY, until.toISOString()); } catch { /* ignore */ }
  return until;
}
