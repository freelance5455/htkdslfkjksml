/**
 * Gestión de la base de datos local IndexedDB para el almacenamiento en iPhone.
 */

const DB_NAME = 'CalendarioCTO2026DB';
const DB_VERSION = 2;

let dbInstance = null;

function abrirBaseDatos() {
  if (dbInstance) return Promise.resolve(dbInstance);

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // 1. Almacén de Servicios del cuadrante
      if (!db.objectStoreNames.contains('servicios')) {
        const storeServicios = db.createObjectStore('servicios', { keyPath: 'id' }); // id: "fecha_letra"
        storeServicios.createIndex('idx_fecha', 'fecha', { unique: false });
        storeServicios.createIndex('idx_letra', 'letra', { unique: false });
      }

      // 2. Almacén de Empleados
      if (!db.objectStoreNames.contains('empleados')) {
        const storeEmpleados = db.createObjectStore('empleados', { keyPath: 'numeroEmpleado' });
        storeEmpleados.createIndex('idx_letra', 'letra', { unique: false });
      }

      // 3. Almacén de Historial de Cambios
      if (!db.objectStoreNames.contains('historial_cambios')) {
        const storeHistorial = db.createObjectStore('historial_cambios', { keyPath: 'id', autoIncrement: true });
        storeHistorial.createIndex('idx_hash', 'hashCambio', { unique: true });
        storeHistorial.createIndex('idx_letra', 'letra', { unique: false });
        storeHistorial.createIndex('idx_fecha', 'fechaServicio', { unique: false });
      }

      // 4. Configuración y Sesión
      if (!db.objectStoreNames.contains('config')) {
        db.createObjectStore('config', { keyPath: 'clave' });
      }

      // 5. Almacén de Eventos Diarios Oficiales (Calendario Eventos)
      if (!db.objectStoreNames.contains('eventos')) {
        const storeEventos = db.createObjectStore('eventos', { keyPath: 'fecha' });
        storeEventos.createIndex('idx_fecha', 'fecha', { unique: true });
      }
    };

    request.onsuccess = (event) => {
      dbInstance = event.target.result;
      resolve(dbInstance);
    };

    request.onerror = (event) => {
      console.error('Error al abrir IndexedDB:', event.target.error);
      reject(event.target.error);
    };
  });
}

// =================== SERVICIOS ===================

async function guardarServiciosLote(servicios) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['servicios'], 'readwrite');
    const store = tx.objectStore('servicios');

    for (const s of servicios) {
      store.put({
        id: `${s.fecha}_${s.letra}`,
        fecha: s.fecha,
        letra: s.letra,
        franja: s.franja,
        servicio: s.servicio,
        nota: s.nota || '',
        lineas: s.lineas || ''
      });
    }

    tx.oncomplete = () => resolve(servicios.length);
    tx.onerror = (e) => reject(e.target.error);
  });
}

async function obtenerServiciosPorFecha(fecha) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['servicios'], 'readonly');
    const store = tx.objectStore('servicios');
    const index = store.index('idx_fecha');
    const request = index.getAll(fecha);

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = (e) => reject(e.target.error);
  });
}

async function obtenerServiciosPorLetra(letra) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['servicios'], 'readonly');
    const store = tx.objectStore('servicios');
    const index = store.index('idx_letra');
    const request = index.getAll(letra.trim().toUpperCase());

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = (e) => reject(e.target.error);
  });
}

async function contarServiciosTotal() {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['servicios'], 'readonly');
    const store = tx.objectStore('servicios');
    const request = store.count();

    request.onsuccess = () => resolve(request.result || 0);
    request.onerror = (e) => reject(e.target.error);
  });
}

// =================== EMPLEADOS ===================

async function guardarEmpleadosLote(empleados) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['empleados'], 'readwrite');
    const store = tx.objectStore('empleados');

    for (const emp of empleados) {
      store.put(emp);
    }

    tx.oncomplete = () => resolve(empleados.length);
    tx.onerror = (e) => reject(e.target.error);
  });
}

async function obtenerTodosLosEmpleados() {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['empleados'], 'readonly');
    const store = tx.objectStore('empleados');
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = (e) => reject(e.target.error);
  });
}

async function guardarEmpleadoIndividual(empleado) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['empleados'], 'readwrite');
    const store = tx.objectStore('empleados');
    const req = store.put(empleado);
    req.onsuccess = () => resolve(true);
    req.onerror = (e) => reject(e.target.error);
  });
}

async function eliminarEmpleadoDeBD(numeroEmpleado) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['empleados'], 'readwrite');
    const store = tx.objectStore('empleados');
    const req = store.delete(numeroEmpleado);
    req.onsuccess = () => resolve(true);
    req.onerror = (e) => reject(e.target.error);
  });
}

// =================== EVENTOS DEL CALENDARIO ===================

async function guardarEventosLote(eventos) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['eventos'], 'readwrite');
    const store = tx.objectStore('eventos');

    for (const ev of eventos) {
      if (ev && ev.fecha && ev.descripcion) {
        store.put({
          fecha: ev.fecha,
          descripcion: ev.descripcion,
          mesOrigen: ev.mesOrigen || ''
        });
      }
    }

    tx.oncomplete = () => resolve(eventos.length);
    tx.onerror = (e) => reject(e.target.error);
  });
}

async function obtenerEventoPorFecha(fecha) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['eventos'], 'readonly');
    const store = tx.objectStore('eventos');
    const request = store.get(fecha);

    request.onsuccess = () => resolve(request.result || null);
    request.onerror = (e) => reject(e.target.error);
  });
}

async function obtenerTodosLosEventos() {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['eventos'], 'readonly');
    const store = tx.objectStore('eventos');
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = (e) => reject(e.target.error);
  });
}

async function contarEventosTotal() {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['eventos'], 'readonly');
    const store = tx.objectStore('eventos');
    const request = store.count();

    request.onsuccess = () => resolve(request.result || 0);
    request.onerror = (e) => reject(e.target.error);
  });
}

async function borrarTodosLosEventos() {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['eventos'], 'readwrite');
    const store = tx.objectStore('eventos');
    const req = store.clear();
    req.onsuccess = () => resolve(true);
    req.onerror = (e) => reject(e.target.error);
  });
}

// =================== HISTORIAL CAMBIOS ===================

async function guardarCambiosHistorial(cambios) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['historial_cambios'], 'readwrite');
    const store = tx.objectStore('historial_cambios');

    for (const c of cambios) {
      try {
        store.put(c);
      } catch (_) {}
    }

    tx.oncomplete = () => resolve(cambios.length);
    tx.onerror = (e) => reject(e.target.error);
  });
}

async function obtenerCambiosNoVistosPorLetra(letra) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['historial_cambios'], 'readonly');
    const store = tx.objectStore('historial_cambios');
    const index = store.index('idx_letra');
    const request = index.getAll(letra.trim().toUpperCase());

    request.onsuccess = () => {
      const todos = request.result || [];
      const noVistos = todos.filter(c => !c.visto);
      resolve(noVistos);
    };
    request.onerror = (e) => reject(e.target.error);
  });
}

async function marcarCambiosComoVistos(ids) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['historial_cambios'], 'readwrite');
    const store = tx.objectStore('historial_cambios');

    let procesados = 0;
    for (const id of ids) {
      const getReq = store.get(id);
      getReq.onsuccess = () => {
        if (getReq.result) {
          const item = getReq.result;
          item.visto = true;
          store.put(item);
        }
        procesados++;
        if (procesados === ids.length) {
          resolve(true);
        }
      };
    }

    tx.onerror = (e) => reject(e.target.error);
  });
}

// =================== CONFIG Y SESIÓN ===================

async function getConfig(clave) {
  const db = await abrirBaseDatos();
  return new Promise((resolve) => {
    const tx = db.transaction(['config'], 'readonly');
    const store = tx.objectStore('config');
    const req = store.get(clave);
    req.onsuccess = () => resolve(req.result ? req.result.valor : null);
    req.onerror = () => resolve(null);
  });
}

async function setConfig(clave, valor) {
  const db = await abrirBaseDatos();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['config'], 'readwrite');
    const store = tx.objectStore('config');
    const req = store.put({ clave, valor });
    req.onsuccess = () => resolve(true);
    req.onerror = (e) => reject(e.target.error);
  });
}
