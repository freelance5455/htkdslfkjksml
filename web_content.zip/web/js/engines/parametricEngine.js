/**
 * learnyZ — Parametric drawing engine inspired by Hamid Naderi Yeganeh.
 *
 * Method 1 (exploratory): evaluate families of trig formulae over k = 1..N
 * Method 2 (constructive): compose known school shapes from parametric pieces
 *
 * Primitives:
 *  - line-segment clouds: endpoints (x1(k),y1(k)), (x2(k),y2(k))
 *  - circle unions: centre (A(k),B(k)), radius R(k)
 *  - parametric polylines: (x(t), y(t)) for t in [0,1]
 *
 * Reference (public formulae):
 *  Bird in flight (500 segments), endpoints for i=1..500:
 *   P1 = (1.5 * sin(2πi/500 + π/3)^7,  0.25 * cos(6πi/500)^2)
 *   P2 = (0.2 * sin(6πi/500 + π/5),   -2/3 * sin(2πi/500 - π/3)^2)
 */

import { RECIPES, slotRect, recipeById, listRecipes } from "./recipeTemplates.js";


const TWO_PI = Math.PI * 2;

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

/** Map normalised math coords [-1.2,1.2]² into canvas box */
function mapToCanvas(x, y, w, h, pad = 28) {
  const s = Math.min(w, h) / 2.6;
  const cx = w / 2, cy = h / 2 + 4;
  return [cx + x * s, cy - y * s];
}

/**
 * Draw Naderi-style segment cloud.
 * endpoints(i, N) -> {x1,y1,x2,y2} in math space
 */
export function drawSegmentCloud(ctx, w, h, N, endpoints, style = {}) {
  ctx.save();
  ctx.strokeStyle = style.stroke || "#1e293b";
  ctx.lineWidth = style.width || 1.1;
  ctx.lineCap = "round";
  for (let i = 1; i <= N; i++) {
    const e = endpoints(i, N);
    const [a, b] = mapToCanvas(e.x1, e.y1, w, h);
    const [c, d] = mapToCanvas(e.x2, e.y2, w, h);
    ctx.beginPath();
    ctx.moveTo(a, b);
    ctx.lineTo(c, d);
    ctx.stroke();
  }
  ctx.restore();
}

/**
 * Draw union of circles (filled silhouette).
 * circle(k, N) -> {x, y, r} in math space
 */
export function drawCircleUnion(ctx, w, h, N, circle, style = {}) {
  ctx.save();
  ctx.fillStyle = style.fill || "rgba(30,41,59,0.9)";
  for (let k = -N; k <= N; k++) {
    const c = circle(k, N);
    if (!c || c.r <= 0) continue;
    const [cx, cy] = mapToCanvas(c.x, c.y, w, h);
    const s = Math.min(w, h) / 2.6;
    ctx.beginPath();
    ctx.arc(cx, cy, c.r * s, 0, TWO_PI);
    ctx.fill();
  }
  ctx.restore();
}

/** Polyline from parametric (x(t),y(t)), t in [0,1] */
export function drawParametricPolyline(ctx, w, h, steps, xt, yt, style = {}) {
  ctx.save();
  ctx.strokeStyle = style.stroke || "#1e293b";
  ctx.lineWidth = style.width || 2;
  ctx.lineJoin = "round";
  ctx.beginPath();
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const [x, y] = mapToCanvas(xt(t), yt(t), w, h);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  if (style.close) ctx.closePath();
  if (style.fill) {
    ctx.fillStyle = style.fill;
    ctx.fill();
  }
  ctx.stroke();
  ctx.restore();
}

/** Filled region from parametric closed curve */
export function fillParametric(ctx, w, h, steps, xt, yt, fill, stroke) {
  drawParametricPolyline(ctx, w, h, steps, xt, yt, { fill, stroke: stroke || fill, width: 1.5, close: true });
}

// ---------- Published Naderi recipes (for study / labs) ----------

/** Exact public "Bird in Flight" 500-segment recipe */
export function birdInFlightEndpoints(i, N = 500) {
  const t = (TWO_PI * i) / N;
  return {
    x1: 1.5 * Math.pow(Math.sin(t + Math.PI / 3), 7),
    y1: 0.25 * Math.pow(Math.cos(3 * t), 2),
    x2: 0.2 * Math.sin(3 * t + Math.PI / 5),
    y2: (-2 / 3) * Math.pow(Math.sin(t - Math.PI / 3), 2)
  };
}

export function drawBirdInFlight(ctx, w, h) {
  drawSegmentCloud(ctx, w, h, 500, birdInFlightEndpoints, { stroke: "#0f172a", width: 1 });
}

// ---------- Constructive CAPS-oriented parametric outlines ----------

/** Smooth plant-cell outer wall: rounded rectangle via trig blend */
export function plantCellWall(t) {
  // superellipse-ish rectangle in [-1,1]
  const a = 1.05, b = 0.78, n = 5;
  const ang = t * TWO_PI;
  const c = Math.cos(ang), s = Math.sin(ang);
  const f = Math.pow(Math.abs(c), n) + Math.pow(Math.abs(s), n);
  const r = f === 0 ? 1 : Math.pow(f, -1 / n);
  return { x: a * r * c, y: b * r * s };
}

/** Large central vacuole — offset soft blob */
export function vacuoleCurve(t) {
  const ang = t * TWO_PI;
  const rx = 0.42 + 0.06 * Math.sin(3 * ang);
  const ry = 0.38 + 0.05 * Math.cos(2 * ang);
  return {
    x: -0.12 + rx * Math.cos(ang),
    y: 0.05 + ry * Math.sin(ang)
  };
}

/** Nucleus circle */
export function nucleusCurve(t, cx = 0.45, cy = -0.15, r = 0.18) {
  const ang = t * TWO_PI;
  return { x: cx + r * Math.cos(ang), y: cy + r * Math.sin(ang) };
}

/** Chloroplast oval at (cx,cy) */
export function chloroplastCurve(t, cx, cy, rot = 0) {
  const ang = t * TWO_PI;
  const rx = 0.12, ry = 0.06;
  const x = rx * Math.cos(ang), y = ry * Math.sin(ang);
  const cr = Math.cos(rot), sr = Math.sin(rot);
  return { x: cx + x * cr - y * sr, y: cy + x * sr + y * cr };
}

/** Heart silhouette (school schematic) via parametric */
export function heartCurve(t) {
  // Classic parametric heart, scaled
  const ang = t * TWO_PI;
  const x = 16 * Math.pow(Math.sin(ang), 3);
  const y =
    13 * Math.cos(ang) -
    5 * Math.cos(2 * ang) -
    2 * Math.cos(3 * ang) -
    Math.cos(4 * ang);
  return { x: x / 18, y: y / 18 + 0.1 };
}

/** Leaf outline */
export function leafCurve(t) {
  const ang = t * TWO_PI;
  // pointed oval with midrib asymmetry
  const r = 0.55 * (1 + 0.15 * Math.sin(ang)) * Math.abs(Math.cos(ang / 2));
  return {
    x: r * Math.cos(ang) * 0.7,
    y: r * Math.sin(ang)
  };
}

/** Simple fish silhouette (Naderi-adjacent demo) */
export function fishEndpoints(i, N = 400) {
  const t = (TWO_PI * i) / N;
  return {
    x1: 0.9 * Math.cos(t) + 0.15 * Math.cos(3 * t),
    y1: 0.35 * Math.sin(t) + 0.05 * Math.sin(5 * t),
    x2: 0.75 * Math.cos(t + 0.08) + 0.2 * Math.pow(Math.sin(t), 3),
    y2: 0.28 * Math.sin(t + 0.08)
  };
}

/**
 * High-level: draw a named parametric recipe onto ctx.
 */
export function drawParametricRecipe(ctx, w, h, name, opts = {}) {
  switch (name) {
    case "bird_in_flight":
      drawBirdInFlight(ctx, w, h);
      break;
    case "fish":
      drawSegmentCloud(ctx, w, h, 400, fishEndpoints, { stroke: "#0f172a", width: 1 });
      break;
    case "heart_outline": {
      const xt = (t) => heartCurve(t).x;
      const yt = (t) => heartCurve(t).y;
      fillParametric(ctx, w, h, 180, xt, yt, opts.fill || "#fecaca", opts.stroke || "#b91c1c");
      break;
    }
    case "leaf_outline": {
      const xt = (t) => leafCurve(t).x;
      const yt = (t) => leafCurve(t).y;
      fillParametric(ctx, w, h, 120, xt, yt, opts.fill || "#86efac", opts.stroke || "#166534");
      break;
    }
    case "plant_cell_wall": {
      const xt = (t) => plantCellWall(t).x;
      const yt = (t) => plantCellWall(t).y;
      fillParametric(ctx, w, h, 160, xt, yt, opts.fill || "#dcfce7", opts.stroke || "#166534");
      break;
    }
    default:
      break;
  }
}

/**
 * Compose a full CAPS plant-cell diagram from parametric parts + leaders.
 * This is constructive method 2: known school structure, parametric edges.
 */
export function composePlantCell(ctx, w, h) {
  // CAPS exam-style plant cell (parts): wall, membrane, vacuole, nucleus,
  // nucleolus, rough ER, Golgi, mitochondria, cytoplasm. Adapted from
  // textbook/label-diagram layout (rounded walls + labelled organelles).
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  const sx = w / 1000, sy = h / 1100;
  function X(x) { return x * sx; }
  function Y(y) { return h - y * sy; } // matplotlib y-up → canvas y-down
  function ellipse(cx, cy, ww, hh, stroke, fill, lw) {
    ctx.beginPath();
    ctx.ellipse(X(cx), Y(cy), (ww / 2) * sx, (hh / 2) * sy, 0, 0, TWO_PI);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    ctx.strokeStyle = stroke || "#0f172a";
    ctx.lineWidth = lw || 1.5;
    ctx.stroke();
  }
  function circle(cx, cy, r, stroke, fill, lw) {
    ctx.beginPath();
    ctx.arc(X(cx), Y(cy), r * Math.min(sx, sy), 0, TWO_PI);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    ctx.strokeStyle = stroke || "#0f172a";
    ctx.lineWidth = lw || 1.2;
    ctx.stroke();
  }
  function line(x1, y1, x2, y2, lw) {
    ctx.beginPath();
    ctx.moveTo(X(x1), Y(y1));
    ctx.lineTo(X(x2), Y(y2));
    ctx.strokeStyle = "#0f172a";
    ctx.lineWidth = lw || 1.5;
    ctx.stroke();
  }
  function label(text, x, y, align) {
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 12px system-ui,sans-serif";
    ctx.textAlign = align || "left";
    ctx.textBaseline = "middle";
    ctx.fillText(text, X(x), Y(y));
  }

  // 1. Triple rounded walls (cell wall + membrane layers)
  for (const [pad, rad, lw] of [[50, 85, 3.2], [80, 70, 2.8], [105, 55, 1.8]]) {
    const x = pad, y = pad, bw = 1000 - 2 * pad, bh = 1100 - 2 * pad;
    const r = rad * Math.min(sx, sy);
    ctx.beginPath();
    // rounded rect in canvas space
    const x0 = X(x), y0 = Y(y + bh), x1 = X(x + bw), y1 = Y(y);
    const rr = Math.min(r, (x1 - x0) / 2, (y0 - y1) / 2);
    ctx.moveTo(x0 + rr, y0);
    ctx.arcTo(x1, y0, x1, y1, rr);
    ctx.arcTo(x1, y1, x0, y1, rr);
    ctx.arcTo(x0, y1, x0, y0, rr);
    ctx.arcTo(x0, y0, x1, y0, rr);
    ctx.closePath();
    ctx.strokeStyle = lw > 2.5 ? "#166534" : "#0f172a";
    ctx.lineWidth = lw * 0.7;
    if (pad === 50) {
      ctx.fillStyle = "rgba(220,252,231,0.35)";
      ctx.fill();
    }
    ctx.stroke();
  }

  // 2. Large vacuole (left-centre)
  ellipse(360, 560, 280, 620, "#1d4ed8", "rgba(191,219,254,0.55)", 2.2);

  // 3. Nucleus (upper right)
  ellipse(630, 780, 280, 260, "#4338ca", "rgba(199,210,254,0.7)", 2.2);
  circle(680, 760, 22, "#312e81", "#4f46e5", 1); // nucleolus
  circle(600, 820, 10, "#4338ca", "#e0e7ff", 1.2);

  // 4. Rough ER around nucleus (stacked arcs + ribosome dots)
  for (let i = 0; i < 6; i++) {
    const pts = [];
    for (let k = 0; k <= 40; k++) {
      const theta = 0.2 * Math.PI + (1.6 * Math.PI * k) / 40;
      const r = 140 + i * 18 + 4 * Math.sin(theta * 4);
      pts.push([630 + r * Math.cos(theta), 780 + r * 0.95 * Math.sin(theta)]);
    }
    ctx.beginPath();
    pts.forEach(([px, py], idx) => {
      const cxp = X(px), cyp = Y(py);
      if (idx === 0) ctx.moveTo(cxp, cyp); else ctx.lineTo(cxp, cyp);
    });
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 1.3;
    ctx.stroke();
    if (i > 2) {
      for (let t = 0; t < 10; t++) {
        const tt = 0.3 + (1.4 * t) / 9;
        const ang = tt * Math.PI;
        const rr = 140 + i * 18;
        circle(630 + (rr + 2) * Math.cos(ang), 780 + rr * 0.95 * Math.sin(ang), 3.5, "#0f172a", "#0f172a", 0.5);
      }
    }
  }

  // 5. Golgi body (stacked wavy cisternae)
  const gcx = 620, gcy = 420;
  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    for (let k = 0; k <= 30; k++) {
      const xx = gcx - 110 + (220 * k) / 30;
      const yy = gcy + i * 18 + 10 * Math.sin((xx - gcx) / 45);
      const cxp = X(xx), cyp = Y(yy);
      if (k === 0) ctx.moveTo(cxp, cyp); else ctx.lineTo(cxp, cyp);
    }
    ctx.strokeStyle = "#0f172a";
    ctx.lineWidth = 1.8;
    ctx.stroke();
  }

  // 6. Mitochondria with cristae
  function mito(cx, cy, ww, hh, angDeg) {
    const ang = (angDeg * Math.PI) / 180;
    ctx.save();
    ctx.translate(X(cx), Y(cy));
    ctx.rotate(-ang); // screen coords
    ctx.beginPath();
    ctx.ellipse(0, 0, (ww / 2) * sx, (hh / 2) * sy, 0, 0, TWO_PI);
    ctx.fillStyle = "rgba(254,243,199,0.85)";
    ctx.fill();
    ctx.strokeStyle = "#92400e";
    ctx.lineWidth = 1.4;
    ctx.stroke();
    for (let k = 0; k < 3; k++) {
      ctx.beginPath();
      for (let t = 0; t <= 20; t++) {
        const xs = -ww / 2.8 + (ww / 1.4) * (t / 20);
        const ys = (k - 1) * 6 + 2 * Math.sin(xs * 0.5);
        const px = xs * sx, py = -ys * sy;
        if (t === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.strokeStyle = "#b45309";
      ctx.lineWidth = 0.9;
      ctx.stroke();
    }
    ctx.restore();
  }
  for (const c of [
    [180, 850, 60, 90, -20], [260, 880, 75, 55, 10], [170, 740, 65, 90, 25],
    [145, 620, 40, 70, 0], [170, 350, 65, 95, -15], [250, 150, 60, 85, 15]
  ]) mito(...c);

  // 7. Cytoplasm vesicles / dots
  for (const [x, y] of [[200, 920], [160, 850], [130, 680], [145, 530], [145, 430], [150, 260]]) {
    circle(x, y, 10, "#64748b", "#f8fafc", 1.1);
  }

  // 8. Chloroplasts (green ovals — CAPS must-have for plant cell)
  for (const [cx, cy, rot] of [[780, 200, 25], [820, 320, -15], [750, 100, 10]]) {
    ctx.save();
    ctx.translate(X(cx), Y(cy));
    ctx.rotate((-rot * Math.PI) / 180);
    ctx.beginPath();
    ctx.ellipse(0, 0, 28 * sx, 14 * sy, 0, 0, TWO_PI);
    ctx.fillStyle = "rgba(74,222,128,0.75)";
    ctx.fill();
    ctx.strokeStyle = "#15803d";
    ctx.lineWidth = 1.3;
    ctx.stroke();
    ctx.restore();
  }

  // Leaders + CAPS labels (exam style letters optional)
  line(660, 620, 900, 620, 1.6);
  label("C  rough ER", 910, 620, "left");
  line(660, 480, 900, 480, 1.6);
  label("D  Golgi body", 910, 480, "left");
  line(360, 560, 120, 560, 1.4);
  label("vacuole", 110, 560, "right");
  line(630, 780, 900, 780, 1.4);
  label("nucleus", 910, 780, "left");
  line(200, 200, 80, 120, 1.3);
  label("mitochondrion", 70, 110, "right");
  line(800, 200, 920, 140, 1.3);
  label("chloroplast", 930, 140, "left");
  line(100, 1000, 40, 1080, 1.3);
  label("cell wall", 30, 1090, "left");

  ctx.fillStyle = "#334155";
  ctx.font = "bold 12px system-ui,sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("Plant cell — CAPS parts (wall · membrane · vacuole · nucleus · ER · Golgi · mitochondria · chloroplasts)", w / 2, 12);
}

export function composeHeart(ctx, w, h) {
  const xt = (t) => heartCurve(t).x;
  const yt = (t) => heartCurve(t).y;
  fillParametric(ctx, w, h, 200, xt, yt, "#fecaca", "#b91c1c");
  // chamber guides
  const s = Math.min(w, h) / 2.6;
  const cx = w / 2, cy = h / 2 + 4;
  ctx.strokeStyle = "#991b1b";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(cx, cy - 0.35 * s);
  ctx.lineTo(cx, cy + 0.45 * s);
  ctx.moveTo(cx - 0.35 * s, cy + 0.05 * s);
  ctx.lineTo(cx + 0.35 * s, cy + 0.05 * s);
  ctx.stroke();
  ctx.font = "10px sans-serif";
  ctx.fillStyle = "#7f1d1d";
  ctx.textAlign = "center";
  ctx.fillText("RA", cx - 0.2 * s, cy - 0.08 * s);
  ctx.fillText("LA", cx + 0.2 * s, cy - 0.08 * s);
  ctx.fillText("RV", cx - 0.2 * s, cy + 0.22 * s);
  ctx.fillText("LV", cx + 0.2 * s, cy + 0.22 * s);
  ctx.font = "bold 12px sans-serif";
  ctx.fillStyle = "#334155";
  ctx.fillText("Heart (parametric outline)", w / 2, 14);
}


export function composeAnimalCell(ctx, w, h) {
  const cx = 0, cy = 0;
  // membrane — soft ellipse via parametric
  const memX = (t) => 0.95 * Math.cos(t * TWO_PI);
  const memY = (t) => 0.7 * Math.sin(t * TWO_PI);
  fillParametric(ctx, w, h, 120, memX, memY, "#fef3c7", "#2563eb");
  // nucleus
  const nx = (t) => nucleusCurve(t, -0.15, -0.05, 0.22).x;
  const ny = (t) => nucleusCurve(t, -0.15, -0.05, 0.22).y;
  fillParametric(ctx, w, h, 80, nx, ny, "#a5b4fc", "#4338ca");
  const [ncx, ncy] = mapToCanvas(-0.15, -0.05, w, h);
  ctx.fillStyle = "#6366f1";
  ctx.beginPath(); ctx.arc(ncx, ncy, 6, 0, TWO_PI); ctx.fill();
  // mitochondria
  [[0.4, 0.25, 0.5], [-0.45, 0.35, -0.3], [0.35, -0.35, 0.8]].forEach(([mx, my, rot]) => {
    const xt = (t) => {
      const a = t * TWO_PI;
      const x = 0.14 * Math.cos(a), y = 0.07 * Math.sin(a);
      return mx + x * Math.cos(rot) - y * Math.sin(rot);
    };
    const yt = (t) => {
      const a = t * TWO_PI;
      const x = 0.14 * Math.cos(a), y = 0.07 * Math.sin(a);
      return my + x * Math.sin(rot) + y * Math.cos(rot);
    };
    fillParametric(ctx, w, h, 50, xt, yt, "#fca5a5", "#b91c1c");
  });
  const s = Math.min(w, h) / 2.6;
  const ox = w / 2, oy = h / 2 + 4;
  function L(mx, my, lx, ly, label, align) {
    ctx.strokeStyle = "#475569"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(ox + mx * s, oy - my * s); ctx.lineTo(lx, ly); ctx.stroke();
    ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif";
    ctx.textAlign = align || "left"; ctx.textBaseline = "middle";
    ctx.fillText(label, align === "right" ? lx - 3 : lx + 3, ly);
  }
  L(0.95, 0, w - 10, h * 0.5, "cell membrane", "right");
  L(0.05, -0.05, w - 10, 40, "nucleus", "right");
  L(0.5, 0.25, w - 10, h - 36, "mitochondrion", "right");
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Animal cell (parametric)", w / 2, 14);
}

export function composeDigestive(ctx, w, h) {
  // path as parametric tube centreline sampled to thick stroke
  const pts = [];
  for (let i = 0; i <= 40; i++) {
    const t = i / 40;
    const y = 0.85 - t * 1.7;
    const x = 0.08 * Math.sin(t * Math.PI * 3);
    pts.push(mapToCanvas(x, y, w, h));
  }
  ctx.strokeStyle = "#e11d48"; ctx.lineWidth = 14; ctx.lineCap = "round"; ctx.lineJoin = "round";
  ctx.beginPath();
  pts.forEach((p, i) => { if (i === 0) ctx.moveTo(p[0], p[1]); else ctx.lineTo(p[0], p[1]); });
  ctx.stroke();
  // stomach
  const [sx, sy] = mapToCanvas(0.12, 0.15, w, h);
  ctx.fillStyle = "#fca5a5"; ctx.strokeStyle = "#b91c1c"; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.ellipse(sx, sy, 28, 18, 0.35, 0, TWO_PI); ctx.fill(); ctx.stroke();
  // liver
  const [lx, ly] = mapToCanvas(-0.35, 0.3, w, h);
  ctx.fillStyle = "#f87171";
  ctx.beginPath(); ctx.ellipse(lx, ly, 16, 12, -0.4, 0, TWO_PI); ctx.fill();
  ctx.strokeStyle = "#475569"; ctx.lineWidth = 1;
  function lead(x1, y1, x2, y2, lab, align) {
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif";
    ctx.textAlign = align; ctx.textBaseline = "middle";
    ctx.fillText(lab, align === "right" ? x2 - 3 : x2 + 3, y2);
  }
  const [m0x, m0y] = mapToCanvas(0, 0.8, w, h);
  lead(m0x, m0y, w - 10, 36, "mouth / oesophagus", "right");
  lead(sx + 20, sy, w - 10, sy, "stomach", "right");
  lead(lx - 10, ly, 10, ly, "liver", "left");
  const [ix, iy] = mapToCanvas(0.1, -0.45, w, h);
  lead(ix + 10, iy, w - 10, iy, "small intestine", "right");
  const [bx, by] = mapToCanvas(0, -0.85, w, h);
  lead(bx + 10, by, w - 10, by, "large intestine", "right");
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Digestive system (schematic)", w / 2, 14);
}

export function composePlantStructure(ctx, w, h) {
  const ox = w * 0.42, ground = h * 0.68;
  ctx.strokeStyle = "#a16207"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(20, ground); ctx.lineTo(w - 20, ground); ctx.stroke();
  ctx.fillStyle = "#fef3c7"; ctx.fillRect(20, ground, w - 40, h - ground - 8);
  // roots parametric branches
  ctx.strokeStyle = "#92400e"; ctx.lineWidth = 2.5;
  [[0, 0.2], [-0.15, 0.22], [0.14, 0.2]].forEach(([dx, dy], i) => {
    ctx.beginPath();
    ctx.moveTo(ox, ground);
    ctx.quadraticCurveTo(ox + dx * 80, ground + 30, ox + dx * 120, ground + dy * 140);
    ctx.stroke();
  });
  // stem
  ctx.strokeStyle = "#166534"; ctx.lineWidth = 7;
  ctx.beginPath(); ctx.moveTo(ox, ground); ctx.lineTo(ox, h * 0.28); ctx.stroke();
  // leaves parametric
  [[-1, 0.42], [1, 0.38], [-1, 0.52]].forEach(([side, fy]) => {
    const xt = (t) => leafCurve(t).x * 0.35 + side * 0.35;
    const yt = (t) => leafCurve(t).y * 0.25 + (0.5 - fy);
    // map manually with offset
    fillParametric(ctx, w, h, 80,
      (t) => { const L = leafCurve(t); return L.x * 0.4 + side * 0.28; },
      (t) => { const L = leafCurve(t); return L.y * 0.22 + (0.55 - fy) * 2; },
      "#22c55e", "#15803d");
  });
  // flower
  const fy = h * 0.2;
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * TWO_PI;
    ctx.fillStyle = "#f472b6";
    ctx.beginPath(); ctx.ellipse(ox + Math.cos(a) * 14, fy + Math.sin(a) * 14, 8, 5, a, 0, TWO_PI); ctx.fill();
  }
  ctx.fillStyle = "#fbbf24";
  ctx.beginPath(); ctx.arc(ox, fy, 7, 0, TWO_PI); ctx.fill();
  ctx.strokeStyle = "#475569"; ctx.lineWidth = 1;
  function lead(x1, y1, x2, y2, lab, align) {
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif";
    ctx.textAlign = align; ctx.textBaseline = "middle";
    ctx.fillText(lab, align === "right" ? x2 - 3 : x2 + 3, y2);
  }
  lead(ox - 20, ground + 40, 12, ground + 40, "roots", "left");
  lead(ox + 6, h * 0.48, w - 12, h * 0.48, "stem", "right");
  lead(ox + 40, h * 0.38, w - 12, h * 0.32, "leaf", "right");
  lead(ox + 18, fy, w - 12, fy, "flower", "right");
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Plant structure", w / 2, 14);
}

export function composeSolar(ctx, w, h) {
  const cx = w * 0.4, cy = h * 0.52;
  const maxR = Math.min(w, h) * 0.36;
  const bodies = [
    { name: "Sun", r: 0, color: "#f59e0b", rp: 16 },
    { name: "Mercury", r: 0.22, color: "#9ca3af", rp: 3 },
    { name: "Venus", r: 0.34, color: "#d4a574", rp: 5 },
    { name: "Earth", r: 0.48, color: "#2563eb", rp: 5 },
    { name: "Mars", r: 0.6, color: "#dc2626", rp: 4 },
    { name: "Jupiter", r: 0.8, color: "#c4a35a", rp: 9 }
  ];
  ctx.strokeStyle = "#cbd5e1"; ctx.lineWidth = 1;
  bodies.forEach((b) => {
    if (b.r > 0) {
      ctx.beginPath(); ctx.arc(cx, cy, b.r * maxR, 0, TWO_PI); ctx.stroke();
    }
  });
  bodies.forEach((b, i) => {
    if (b.r === 0) {
      const g = ctx.createRadialGradient(cx - 3, cy - 3, 2, cx, cy, b.rp);
      g.addColorStop(0, "#fde68a"); g.addColorStop(1, b.color);
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(cx, cy, b.rp, 0, TWO_PI); ctx.fill();
    } else {
      const ang = -0.5 + i * 0.5;
      const px = cx + Math.cos(ang) * b.r * maxR;
      const py = cy + Math.sin(ang) * b.r * maxR;
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(px, py, b.rp, 0, TWO_PI); ctx.fill();
    }
  });
  ctx.strokeStyle = "#475569"; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(cx + 16, cy); ctx.lineTo(w - 12, 36); ctx.stroke();
  ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif"; ctx.textAlign = "right";
  ctx.fillText("Sun", w - 14, 36);
  ctx.beginPath(); ctx.moveTo(cx + 0.48 * maxR, cy); ctx.lineTo(w - 12, 58); ctx.stroke();
  ctx.fillText("Earth", w - 14, 58);
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Solar system (not to scale)", w / 2, 14);
}

export function composeLever(ctx, w, h) {
  const y = h * 0.55;
  const fx = w * 0.4;
  ctx.strokeStyle = "#334155"; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.moveTo(40, y); ctx.lineTo(w - 40, y); ctx.stroke();
  ctx.fillStyle = "#64748b";
  ctx.beginPath(); ctx.moveTo(fx, y); ctx.lineTo(fx - 16, y + 40); ctx.lineTo(fx + 16, y + 40); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#fca5a5"; ctx.fillRect(50, y - 34, 30, 28);
  ctx.fillStyle = "#93c5fd"; ctx.fillRect(w - 80, y - 34, 30, 28);
  ctx.fillStyle = "#0f172a"; ctx.font = "11px sans-serif";
  ctx.fillText("Load", 52, y - 42);
  ctx.fillText("Effort", w - 78, y - 42);
  ctx.fillText("fulcrum", fx - 18, y + 56);
  ctx.font = "bold 12px sans-serif"; ctx.fillStyle = "#334155"; ctx.textAlign = "center";
  ctx.fillText("Lever", w / 2, 16);
}


/**
 * Parts registry — each diagram is a list of named parts the composer draws and labels.
 * Used by the diagram library and for future label-the-parts worksheets.
 */
export const DIAGRAM_PARTS = {
  cell_plant: [
    { id: "wall", label: "cell wall", role: "boundary" },
    { id: "membrane", label: "cell membrane", role: "boundary" },
    { id: "nucleus", label: "nucleus", role: "organelle" },
    { id: "nucleolus", label: "nucleolus", role: "organelle" },
    { id: "vacuole", label: "vacuole", role: "organelle" },
    { id: "rough_er", label: "rough ER", role: "organelle" },
    { id: "golgi", label: "Golgi body", role: "organelle" },
    { id: "mitochondria", label: "mitochondria", role: "organelle" },
    { id: "chloroplast", label: "chloroplast", role: "organelle" },
    { id: "cytoplasm", label: "cytoplasm", role: "matrix" }
  ],
  cell_animal: [
    { id: "membrane", label: "cell membrane", role: "boundary" },
    { id: "nucleus", label: "nucleus", role: "organelle" },
    { id: "mitochondria", label: "mitochondria", role: "organelle" },
    { id: "cytoplasm", label: "cytoplasm", role: "matrix" }
  ],
  organ_heart: [
    { id: "ra", label: "right atrium", role: "chamber" },
    { id: "la", label: "left atrium", role: "chamber" },
    { id: "rv", label: "right ventricle", role: "chamber" },
    { id: "lv", label: "left ventricle", role: "chamber" },
    { id: "aorta", label: "aorta", role: "vessel" }
  ],
  organ_digestive: [
    { id: "mouth", label: "mouth", role: "organ" },
    { id: "oesophagus", label: "oesophagus", role: "organ" },
    { id: "stomach", label: "stomach", role: "organ" },
    { id: "small_intestine", label: "small intestine", role: "organ" },
    { id: "large_intestine", label: "large intestine", role: "organ" },
    { id: "liver", label: "liver", role: "organ" }
  ],
  plant_structure: [
    { id: "roots", label: "roots", role: "part" },
    { id: "stem", label: "stem", role: "part" },
    { id: "leaf", label: "leaf", role: "part" },
    { id: "flower", label: "flower", role: "part" }
  ],
  solar_system: [
    { id: "sun", label: "Sun", role: "star" },
    { id: "mercury", label: "Mercury", role: "planet" },
    { id: "venus", label: "Venus", role: "planet" },
    { id: "earth", label: "Earth", role: "planet" },
    { id: "mars", label: "Mars", role: "planet" },
    { id: "jupiter", label: "Jupiter", role: "planet" },
    { id: "saturn", label: "Saturn", role: "planet" }
  ],
  lever: [
    { id: "fulcrum", label: "fulcrum", role: "pivot" },
    { id: "load", label: "load", role: "force" },
    { id: "effort", label: "effort", role: "force" },
    { id: "beam", label: "beam", role: "structure" }
  ],
  atom_bohr: [
    { id: "nucleus", label: "nucleus", role: "core" },
    { id: "electron", label: "electron", role: "shell" },
    { id: "shell", label: "energy shell", role: "orbit" }
  ],
  mitosis_stages: [
    { id: "prophase", label: "prophase", role: "stage" },
    { id: "metaphase", label: "metaphase", role: "stage" },
    { id: "anaphase", label: "anaphase", role: "stage" },
    { id: "telophase", label: "telophase", role: "stage" }
  ]
};

/** Simple Bohr-style atom from parts */
export function composeAtomBohr(ctx, w, h) {
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2 + 6;
  const r = Math.min(w, h) * 0.12;
  // nucleus
  ctx.fillStyle = "#f97316";
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, TWO_PI);
  ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.font = "bold 10px sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("p⁺ n⁰", cx, cy);
  // shells
  [0.28, 0.42, 0.55].forEach((f, i) => {
    const rr = Math.min(w, h) * f;
    ctx.strokeStyle = "#64748b";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, rr, 0, TWO_PI);
    ctx.stroke();
    // electrons on shell
    const n = i === 0 ? 2 : i === 1 ? 4 : 3;
    for (let k = 0; k < n; k++) {
      const a = (k / n) * TWO_PI - Math.PI / 2;
      ctx.fillStyle = "#2563eb";
      ctx.beginPath();
      ctx.arc(cx + rr * Math.cos(a), cy + rr * Math.sin(a), 4, 0, TWO_PI);
      ctx.fill();
    }
  });
  // leaders
  ctx.strokeStyle = "#475569";
  ctx.fillStyle = "#0f172a";
  ctx.font = "11px sans-serif";
  ctx.textAlign = "left";
  ctx.beginPath();
  ctx.moveTo(cx + r, cy);
  ctx.lineTo(w - 12, cy);
  ctx.stroke();
  ctx.fillText("nucleus", w - 70, cy - 4);
  ctx.beginPath();
  ctx.moveTo(cx + Math.min(w, h) * 0.42, cy);
  ctx.lineTo(w - 12, h * 0.28);
  ctx.stroke();
  ctx.fillText("electron", w - 70, h * 0.28 - 4);
  ctx.font = "bold 12px sans-serif";
  ctx.textAlign = "center";
  ctx.fillStyle = "#334155";
  ctx.fillText("Atom (Bohr model — parts)", w / 2, 14);
}

/** Mitosis stages as four mini panels with chromosome parts */
export function composeMitosisStages(ctx, w, h) {
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  const stages = ["Prophase", "Metaphase", "Anaphase", "Telophase"];
  const pw = (w - 20) / 4;
  stages.forEach((name, i) => {
    const x0 = 8 + i * pw;
    const y0 = 28;
    const ph = h - 40;
    ctx.strokeStyle = "#cbd5e1";
    ctx.strokeRect(x0, y0, pw - 6, ph);
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 10px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(name, x0 + (pw - 6) / 2, y0 + 14);
    const cx = x0 + (pw - 6) / 2;
    const cy = y0 + ph / 2 + 6;
    // chromosomes as X or rods depending on stage
    ctx.strokeStyle = "#7c3aed";
    ctx.lineWidth = 2;
    if (i === 0) {
      // tangled
      for (let k = 0; k < 3; k++) {
        ctx.beginPath();
        ctx.ellipse(cx + (k - 1) * 8, cy, 6, 10, k * 0.4, 0, TWO_PI);
        ctx.stroke();
      }
    } else if (i === 1) {
      // lined at equator
      for (let k = 0; k < 4; k++) {
        ctx.beginPath();
        ctx.moveTo(cx - 10, cy - 12 + k * 8);
        ctx.lineTo(cx + 10, cy - 12 + k * 8);
        ctx.stroke();
      }
      ctx.strokeStyle = "#94a3b8";
      ctx.beginPath();
      ctx.moveTo(x0 + 8, cy);
      ctx.lineTo(x0 + pw - 14, cy);
      ctx.stroke();
    } else if (i === 2) {
      // pulling apart
      for (let k = 0; k < 3; k++) {
        ctx.beginPath();
        ctx.moveTo(cx - 14, cy - 8 + k * 6);
        ctx.lineTo(cx - 4, cy - 4 + k * 4);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(cx + 4, cy - 4 + k * 4);
        ctx.lineTo(cx + 14, cy - 8 + k * 6);
        ctx.stroke();
      }
    } else {
      // two nuclei forming
      ctx.strokeStyle = "#6366f1";
      ctx.beginPath();
      ctx.ellipse(cx - 12, cy, 10, 14, 0, 0, TWO_PI);
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(cx + 12, cy, 10, 14, 0, 0, TWO_PI);
      ctx.stroke();
    }
  });
  ctx.font = "bold 12px sans-serif";
  ctx.fillStyle = "#334155";
  ctx.textAlign = "center";
  ctx.fillText("Mitosis stages (parts)", w / 2, 14);
}

export const DIAGRAM_CATALOG = [
  { id: "cell_plant", name: "Plant cell", group: "Life Sciences", draw: "composePlantCell", parts: "cell_plant" },
  { id: "cell_animal", name: "Animal cell", group: "Life Sciences", draw: "composeAnimalCell", parts: "cell_animal" },
  { id: "organ_heart", name: "Heart", group: "Life Sciences", draw: "composeHeart", parts: "organ_heart" },
  { id: "organ_digestive", name: "Digestive system", group: "Life Sciences", draw: "composeDigestive", parts: "organ_digestive" },
  { id: "mitosis_stages", name: "Mitosis stages", group: "Life Sciences", draw: "composeMitosisStages", parts: "mitosis_stages" },
  { id: "plant_structure", name: "Plant structure", group: "Natural Sciences", draw: "composePlantStructure", parts: "plant_structure" },
  { id: "solar_system", name: "Solar system", group: "Natural Sciences", draw: "composeSolar", parts: "solar_system" },
  { id: "atom_bohr", name: "Atom (Bohr)", group: "Natural Sciences", draw: "composeAtomBohr", parts: "atom_bohr" },
  { id: "lever", name: "Lever", group: "Technology", draw: "composeLever", parts: "lever" },
  { id: "leaf_outline", name: "Leaf outline", group: "Parametric", draw: "leaf" },
  { id: "bird_in_flight", name: "Bird in flight (Naderi)", group: "Parametric art", draw: "bird" },
  { id: "fish", name: "Fish (segment cloud)", group: "Parametric art", draw: "fish" },
  { id: "accounting_equation", name: "Accounting equation", group: "Accounting", draw: "render" },
  { id: "journal_table", name: "Journal table", group: "Accounting", draw: "render" },
  { id: "t_account", name: "T-account", group: "Accounting", draw: "render" },
  { id: "bank_recon", name: "Bank reconciliation", group: "Accounting", draw: "render" },
  { id: "food_web", name: "Food web", group: "Natural Sciences", draw: "render" },
  { id: "periodic_table", name: "Periodic table", group: "Reference", draw: "periodic" },
  { id: "formula_maths", name: "Maths formulae", group: "Reference", draw: "formula" }
];

export const PARAMETRIC_KINDS = DIAGRAM_CATALOG.map((d) => d.id);

/** Draw any catalog id onto canvas */
export function drawCatalogDiagram(ctx, w, h, id) {
  switch (id) {
    case "cell_plant": case "plant_cell_parametric": return composePlantCell(ctx, w, h);
    case "cell_animal": return composeAnimalCell(ctx, w, h);
    case "organ_heart": case "heart_parametric": case "heart_outline": return composeHeart(ctx, w, h);
    case "organ_digestive": return composeDigestive(ctx, w, h);
    case "plant_structure": return composePlantStructure(ctx, w, h);
    case "solar_system": return composeSolar(ctx, w, h);
    case "lever": return composeLever(ctx, w, h);
    case "atom_bohr": return composeAtomBohr(ctx, w, h);
    case "mitosis_stages": return composeMitosisStages(ctx, w, h);
    case "bird_in_flight": case "naderi_bird": return drawBirdInFlight(ctx, w, h);
    case "fish": return drawSegmentCloud(ctx, w, h, 400, fishEndpoints, { stroke: "#0f172a", width: 1 });
    case "leaf_outline": return drawParametricRecipe(ctx, w, h, "leaf_outline");
    case "circle_theorem_centre": return composeCircleTheoremCentre(ctx, w, h);
    case "water_cycle":
    case "simple_circuit":
      return composeFromRecipe(ctx, w, h, id);
    default: return null; // fall through to render.js drawDiagram
  }
}

export function partsForDiagram(id) {
  const entry = DIAGRAM_CATALOG.find((d) => d.id === id);
  if (!entry || !entry.parts) return [];
  return DIAGRAM_PARTS[entry.parts] || [];
}


// ----- Grid template composer (uses recipeTemplates) -----

function titleBand(ctx, w, title) {
  ctx.fillStyle = "#334155";
  ctx.font = "bold 12px system-ui,sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  ctx.fillText(title, w / 2, 4);
}

function leader(ctx, x1, y1, x2, y2, label, align = "left") {
  ctx.strokeStyle = "#64748b";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.fillStyle = "#0f172a";
  ctx.font = "11px system-ui,sans-serif";
  ctx.textAlign = align;
  ctx.textBaseline = "middle";
  ctx.fillText(label, align === "right" ? x2 - 3 : x2 + 3, y2);
}

/** Draw a recipe from the long template definitions onto a grid */
export function composeFromRecipe(ctx, w, h, recipeId) {
  const recipe = recipeById(recipeId);
  if (!recipe) return false;
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  titleBand(ctx, w, recipe.name + " (parts)");

  const grid = recipe.grid || { rows: 4, cols: 4 };
  const parts = recipe.parts || [];

  // Optional light grid guides (debug-friendly, faint)
  // Draw parts by draw-hint
  for (const part of parts) {
    const rect = slotRect(w, h, part.slot, grid, 14);
    drawPartPrimitive(ctx, part, rect, w, h);
  }

  // Labels along the right or bottom from parts list
  let ly = 28;
  ctx.font = "10px system-ui,sans-serif";
  ctx.textAlign = "left";
  ctx.fillStyle = "#475569";
  for (const part of parts) {
    if (part.role === "structure" || part.role === "path" || part.role === "matrix") continue;
    ctx.fillText("• " + part.label, 8, h - 8 - (parts.length - parts.indexOf(part)) * 12);
  }
  return true;
}

function drawPartPrimitive(ctx, part, rect, w, h) {
  const { x, y, w: rw, h: rh, cx, cy } = rect;
  const d = part.draw;
  ctx.save();
  if (d === "outer_wall") {
    ctx.fillStyle = "rgba(220,252,231,0.7)";
    ctx.strokeStyle = "#166534";
    ctx.lineWidth = 3;
    roundRect(ctx, x + 4, y + 4, rw - 8, rh - 8, 16);
    ctx.fill(); ctx.stroke();
  } else if (d === "inset_membrane") {
    ctx.strokeStyle = "#2563eb";
    ctx.lineWidth = 1.5;
    roundRect(ctx, x + 12, y + 12, rw - 24, rh - 24, 12);
    ctx.stroke();
  } else if (d === "fill_matrix") {
    ctx.fillStyle = "rgba(241,245,249,0.5)";
    ctx.fillRect(x, y, rw, rh);
  } else if (d === "large_oval") {
    ctx.fillStyle = "rgba(147,197,253,0.45)";
    ctx.strokeStyle = "#3b82f6";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(cx, cy, rw * 0.42, rh * 0.38, 0, 0, TWO_PI);
    ctx.fill(); ctx.stroke();
  } else if (d === "nucleus_blob") {
    ctx.fillStyle = "#a5b4fc";
    ctx.strokeStyle = "#4338ca";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(cx, cy, Math.min(rw, rh) * 0.35, Math.min(rw, rh) * 0.3, 0, 0, TWO_PI);
    ctx.fill(); ctx.stroke();
  } else if (d === "nucleolus_dot") {
    ctx.fillStyle = "#6366f1";
    ctx.beginPath();
    ctx.arc(cx, cy, 4, 0, TWO_PI);
    ctx.fill();
  } else if (d === "chloro_cluster") {
    for (let i = 0; i < 3; i++) {
      ctx.fillStyle = "#4ade80";
      ctx.strokeStyle = "#15803d";
      ctx.beginPath();
      ctx.ellipse(x + 18 + i * 22, cy, 12, 7, i * 0.3, 0, TWO_PI);
      ctx.fill(); ctx.stroke();
    }
  } else if (d === "soft_oval") {
    ctx.strokeStyle = "#2563eb";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(cx, cy, rw * 0.42, rh * 0.4, 0, 0, TWO_PI);
    ctx.stroke();
  } else if (d === "mito_cluster") {
    for (let i = 0; i < 2; i++) {
      ctx.strokeStyle = "#b45309";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.ellipse(cx - 12 + i * 24, cy, 14, 7, 0.2, 0, TWO_PI);
      ctx.stroke();
    }
  } else if (d === "heart_outline") {
    // Use existing heart parametric if available
    try {
      const xt = (t) => heartCurve(t).x;
      const yt = (t) => heartCurve(t).y;
      fillParametric(ctx, w, h, 180, xt, yt, "#fecaca", "#b91c1c");
    } catch {
      ctx.fillStyle = "#fecaca";
      ctx.beginPath();
      ctx.ellipse(cx, cy, rw * 0.35, rh * 0.4, 0, 0, TWO_PI);
      ctx.fill();
    }
  } else if (d === "chamber_label") {
    ctx.fillStyle = "#7f1d1d";
    ctx.font = "10px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(part.label, cx, cy);
  } else if (d === "aorta_arch") {
    ctx.strokeStyle = "#b91c1c";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy + 10, 18, Math.PI, 0);
    ctx.stroke();
  } else if (d === "mouth_oval" || d === "stomach_bag" || d === "tube" || d === "coils" || d === "frame_intestine" || d === "liver_lobe") {
    ctx.fillStyle = d === "liver_lobe" ? "#fca5a5" : "#fde68a";
    ctx.strokeStyle = "#92400e";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(cx, cy, rw * 0.35, rh * 0.3, 0, 0, TWO_PI);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#0f172a";
    ctx.font = "9px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(part.label, cx, cy + rh * 0.42);
  } else if (d && d.startsWith("stage_")) {
    ctx.strokeStyle = "#cbd5e1";
    ctx.strokeRect(x + 2, y + 2, rw - 4, rh - 4);
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 10px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(part.label, cx, y + 16);
    ctx.strokeStyle = "#7c3aed";
    ctx.lineWidth = 2;
    if (d === "stage_prophase") {
      for (let k = 0; k < 3; k++) {
        ctx.beginPath();
        ctx.ellipse(cx + (k - 1) * 10, cy + 8, 6, 11, k * 0.4, 0, TWO_PI);
        ctx.stroke();
      }
    } else if (d === "stage_metaphase") {
      for (let k = 0; k < 4; k++) {
        ctx.beginPath();
        ctx.moveTo(cx - 12, cy - 6 + k * 8);
        ctx.lineTo(cx + 12, cy - 6 + k * 8);
        ctx.stroke();
      }
    } else if (d === "stage_anaphase") {
      for (let k = 0; k < 3; k++) {
        ctx.beginPath();
        ctx.moveTo(cx - 16, cy - 4 + k * 8);
        ctx.lineTo(cx - 4, cy + k * 4);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(cx + 4, cy + k * 4);
        ctx.lineTo(cx + 16, cy - 4 + k * 8);
        ctx.stroke();
      }
    } else {
      ctx.beginPath();
      ctx.ellipse(cx - 14, cy + 4, 10, 14, 0, 0, TWO_PI);
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(cx + 14, cy + 4, 10, 14, 0, 0, TWO_PI);
      ctx.stroke();
    }
  } else if (d === "shells" || d === "nucleus_core" || d === "electrons") {
    // handled collectively by composeAtomBohr — skip partial
  } else if (d === "circle_outline") {
    const R = Math.min(w, h) * 0.36;
    const ox = w / 2, oy = h / 2 + 6;
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(ox, oy, R, 0, TWO_PI);
    ctx.stroke();
  } else if (d === "centre_dot") {
    const ox = w / 2, oy = h / 2 + 6;
    ctx.fillStyle = "#0f172a";
    ctx.beginPath();
    ctx.arc(ox, oy, 3.5, 0, TWO_PI);
    ctx.fill();
    ctx.font = "11px system-ui,sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("O", ox + 6, oy - 6);
  } else if (d === "radii_from_centre") {
    // Precise: radii must pass through exact centre
    const ox = w / 2, oy = h / 2 + 6;
    const R = Math.min(w, h) * 0.36;
    const angB = -0.9, angC = 0.7;
    const bx = ox + R * Math.cos(angB), by = oy + R * Math.sin(angB);
    const cx2 = ox + R * Math.cos(angC), cy2 = oy + R * Math.sin(angC);
    ctx.strokeStyle = "#3157D5";
    ctx.lineWidth = 1.8;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(ox, oy); ctx.lineTo(bx, by);
    ctx.moveTo(ox, oy); ctx.lineTo(cx2, cy2);
    ctx.stroke();
    ctx.fillStyle = "#0f172a";
    ctx.beginPath(); ctx.arc(bx, by, 3, 0, TWO_PI); ctx.fill();
    ctx.beginPath(); ctx.arc(cx2, cy2, 3, 0, TWO_PI); ctx.fill();
    ctx.font = "11px system-ui,sans-serif";
    ctx.fillText("B", bx + 6, by);
    ctx.fillText("C", cx2 + 6, cy2);
  } else if (d === "inscribed_angle") {
    const ox = w / 2, oy = h / 2 + 6;
    const R = Math.min(w, h) * 0.36;
    const angB = -0.9, angC = 0.7, angA = 2.5;
    const bx = ox + R * Math.cos(angB), by = oy + R * Math.sin(angB);
    const cx2 = ox + R * Math.cos(angC), cy2 = oy + R * Math.sin(angC);
    const ax = ox + R * Math.cos(angA), ay = oy + R * Math.sin(angA);
    ctx.strokeStyle = "#D64545";
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(ax, ay); ctx.lineTo(bx, by);
    ctx.moveTo(ax, ay); ctx.lineTo(cx2, cy2);
    ctx.stroke();
    ctx.fillStyle = "#0f172a";
    ctx.beginPath(); ctx.arc(ax, ay, 3, 0, TWO_PI); ctx.fill();
    ctx.font = "11px system-ui,sans-serif";
    ctx.fillText("A", ax - 14, ay);
  } else if (d === "wire_loop") {
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 2;
    ctx.lineJoin = "round";
    ctx.strokeRect(x + 20, y + 16, rw - 40, rh - 32);
  } else if (d === "cell_symbol") {
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx - 8, cy - 12); ctx.lineTo(cx - 8, cy + 12);
    ctx.moveTo(cx + 4, cy - 6); ctx.lineTo(cx + 4, cy + 6);
    ctx.stroke();
    ctx.font = "9px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillStyle = "#0f172a";
    ctx.fillText("cell", cx, cy + 22);
  } else if (d === "switch_symbol") {
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx - 18, cy); ctx.lineTo(cx - 4, cy);
    ctx.lineTo(cx + 10, cy - 10);
    ctx.moveTo(cx + 14, cy); ctx.lineTo(cx + 22, cy);
    ctx.stroke();
    ctx.fillStyle = "#0f172a";
    ctx.font = "9px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("switch", cx, cy + 16);
  } else if (d === "lamp_symbol") {
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, 10, 0, TWO_PI);
    ctx.moveTo(cx - 7, cy - 7); ctx.lineTo(cx + 7, cy + 7);
    ctx.moveTo(cx + 7, cy - 7); ctx.lineTo(cx - 7, cy + 7);
    ctx.stroke();
    ctx.fillStyle = "#0f172a";
    ctx.font = "9px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("lamp", cx, cy + 22);
  } else if (d === "sun_disk" || d === "planet_disk" || d === "sun_small") {
    const colors = { sun: "#F5A623", mercury: "#A0A0A0", venus: "#E8C07A", earth: "#3157D5", mars: "#D64545", jupiter: "#C4A35A", saturn: "#D4B56A" };
    const key = (part.id || "").replace("sun_small", "sun");
    ctx.fillStyle = colors[key] || colors.sun || "#F5A623";
    const rad = d === "sun_disk" || d === "sun_small" ? Math.min(rw, rh) * 0.35 : Math.min(rw, rh) * 0.22;
    ctx.beginPath();
    ctx.arc(cx, cy, rad, 0, TWO_PI);
    ctx.fill();
    ctx.fillStyle = "#0f172a";
    ctx.font = "9px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(part.label, cx, cy + rad + 12);
  } else if (d === "beam") {
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x + 8, cy);
    ctx.lineTo(x + rw - 8, cy);
    ctx.stroke();
  } else if (d === "fulcrum_triangle") {
    ctx.fillStyle = "#64748b";
    ctx.beginPath();
    ctx.moveTo(cx, y + 4);
    ctx.lineTo(cx - 14, y + rh - 4);
    ctx.lineTo(cx + 14, y + rh - 4);
    ctx.closePath();
    ctx.fill();
  } else if (d === "load_block" || d === "effort_block") {
    ctx.fillStyle = d === "load_block" ? "#fca5a5" : "#93c5fd";
    ctx.fillRect(cx - 14, cy - 12, 28, 24);
    ctx.fillStyle = "#0f172a";
    ctx.font = "10px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(part.label, cx, cy + 22);
  } else if (d === "cloud") {
    ctx.fillStyle = "#cbd5e1";
    ctx.beginPath();
    ctx.ellipse(cx, cy, 22, 12, 0, 0, TWO_PI);
    ctx.fill();
  } else if (d === "rain") {
    ctx.strokeStyle = "#3b82f6";
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(cx - 12 + i * 8, cy - 8);
      ctx.lineTo(cx - 10 + i * 8, cy + 10);
      ctx.stroke();
    }
  } else if (d === "up_arrows") {
    ctx.strokeStyle = "#64748b";
    ctx.beginPath();
    ctx.moveTo(cx, cy + 12); ctx.lineTo(cx, cy - 12);
    ctx.moveTo(cx - 5, cy - 6); ctx.lineTo(cx, cy - 12); ctx.lineTo(cx + 5, cy - 6);
    ctx.stroke();
  } else if (d === "sea_ground") {
    ctx.fillStyle = "#7dd3fc";
    ctx.fillRect(x + 4, cy, rw - 8, rh * 0.4);
    ctx.fillStyle = "#0f172a";
    ctx.font = "10px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(part.label, cx, cy - 6);
  } else if (d === "stem_line") {
    ctx.strokeStyle = "#166534";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(cx, y + 4);
    ctx.lineTo(cx, y + rh - 4);
    ctx.stroke();
  } else if (d === "leaves") {
    ctx.fillStyle = "#4ade80";
    ctx.beginPath();
    ctx.ellipse(cx - 30, cy, 22, 10, -0.5, 0, TWO_PI);
    ctx.ellipse(cx + 30, cy, 22, 10, 0.5, 0, TWO_PI);
    ctx.fill();
  } else if (d === "root_system") {
    ctx.strokeStyle = "#92400e";
    ctx.lineWidth = 1.5;
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath();
      ctx.moveTo(cx, y + 4);
      ctx.quadraticCurveTo(cx + i * 18, cy, cx + i * 28, y + rh - 6);
      ctx.stroke();
    }
  } else if (d === "flower_top") {
    ctx.fillStyle = "#f9a8d4";
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * TWO_PI;
      ctx.beginPath();
      ctx.ellipse(cx + Math.cos(a) * 8, cy + Math.sin(a) * 8, 6, 4, a, 0, TWO_PI);
      ctx.fill();
    }
    ctx.fillStyle = "#fbbf24";
    ctx.beginPath();
    ctx.arc(cx, cy, 4, 0, TWO_PI);
    ctx.fill();
  }
  ctx.restore();
}

function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

/** Precise circle-theorem figure: centre, radii through centre, inscribed angle */
export function composeCircleTheoremCentre(ctx, w, h) {
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  titleBand(ctx, w, "Angle at the centre = 2 × angle at circumference");
  const ox = w / 2;
  const oy = h / 2 + 8;
  const R = Math.min(w, h) * 0.36;
  // Circle
  ctx.strokeStyle = "#1e293b";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(ox, oy, R, 0, TWO_PI);
  ctx.stroke();
  // Centre O — exact
  ctx.fillStyle = "#0f172a";
  ctx.beginPath();
  ctx.arc(ox, oy, 3.5, 0, TWO_PI);
  ctx.fill();
  ctx.font = "12px system-ui,sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("O", ox + 6, oy - 6);
  // Points on circumference
  const angB = -1.0, angC = 0.85, angA = 2.55;
  const B = [ox + R * Math.cos(angB), oy + R * Math.sin(angB)];
  const C = [ox + R * Math.cos(angC), oy + R * Math.sin(angC)];
  const A = [ox + R * Math.cos(angA), oy + R * Math.sin(angA)];
  // Radii OB, OC — must pass through centre (single path each)
  ctx.strokeStyle = "#3157D5";
  ctx.lineWidth = 1.8;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(B[0], B[1]);
  ctx.lineTo(ox, oy);
  ctx.lineTo(C[0], C[1]);
  ctx.stroke();
  // Chords BA, CA
  ctx.strokeStyle = "#D64545";
  ctx.beginPath();
  ctx.moveTo(B[0], B[1]);
  ctx.lineTo(A[0], A[1]);
  ctx.lineTo(C[0], C[1]);
  ctx.stroke();
  // Points
  for (const [P, lab, off] of [[B, "B", [6, 0]], [C, "C", [6, 0]], [A, "A", [-14, 0]]]) {
    ctx.fillStyle = "#0f172a";
    ctx.beginPath();
    ctx.arc(P[0], P[1], 3.2, 0, TWO_PI);
    ctx.fill();
    ctx.font = "12px system-ui,sans-serif";
    ctx.fillText(lab, P[0] + off[0], P[1] + off[1]);
  }
  // Arc BC hint
  ctx.strokeStyle = "#159A68";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.arc(ox, oy, R, angB, angC);
  ctx.stroke();
  ctx.fillStyle = "#475569";
  ctx.font = "10px system-ui,sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("arc BC", ox, oy + R + 16);
}

// Extend catalog + drawCatalogDiagram
const EXTRA_CATALOG = [
  { id: "circle_theorem_centre", name: "Angle at the centre", group: "Euclidean geometry", draw: "composeCircleTheoremCentre", parts: "circle_theorem_centre" },
  { id: "water_cycle", name: "Water cycle", group: "Natural Sciences", draw: "recipe", parts: "water_cycle" },
  { id: "simple_circuit", name: "Simple circuit", group: "Natural Sciences", draw: "recipe", parts: "simple_circuit" }
];

// Merge extras if not present
for (const e of EXTRA_CATALOG) {
  if (!DIAGRAM_CATALOG.find((d) => d.id === e.id)) DIAGRAM_CATALOG.push(e);
}

// Patch parts registry
DIAGRAM_PARTS.circle_theorem_centre = [
  { id: "circle", label: "circle", role: "structure" },
  { id: "centre", label: "O (centre)", role: "point" },
  { id: "radii", label: "radii OB, OC", role: "line" },
  { id: "chord", label: "angle at A", role: "line" }
];
DIAGRAM_PARTS.water_cycle = [
  { id: "evaporation", label: "evaporation", role: "process" },
  { id: "condensation", label: "condensation", role: "process" },
  { id: "precipitation", label: "precipitation", role: "process" },
  { id: "collection", label: "collection", role: "process" }
];
DIAGRAM_PARTS.simple_circuit = [
  { id: "cell", label: "cell", role: "component" },
  { id: "switch", label: "switch", role: "component" },
  { id: "lamp", label: "lamp", role: "component" },
  { id: "wires", label: "wires", role: "path" }
];

