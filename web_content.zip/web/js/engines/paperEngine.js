// Port of engine/paper_engine.py. Papers are stored under localStorage key
// "learnly:paper:<id>" in place of data/papers/<id>.json — same shape, same rules.
import { AdaptiveEngine } from "./adaptive.js";
import { UnifiedQuestionEngine } from "./unifiedEngine.js";
import { GradeManager } from "./gradeManager.js";

// Term mapping only exists (and only matters) for Grade 8's fully-built term structure.
const GRADE8_TOPIC_TERM = {
  whole_numbers: 1, integers: 1, exponents: 1, patterns: 1, number_sense: 1,
  algebraic_expressions: 2, algebraic_equations: 2, geometry_lines: 2,
  pythagoras: 3, area_perimeter: 3, financial_maths: 3, transformations: 3,
  data_handling: 4, probability: 4, surface_area_volume: 4
};

export const PAPER_TYPES = [
  "Term / ATP Aligned",
  "Weakness Recovery",
  "Strength Challenge",
  "Diagnostic",
  "Mock Exam",
  "Past Paper Style",
  "Custom Topic Paper"
];
export const DIFFICULTY_MAP = { Foundation: 1, Standard: 2, Advanced: 3, Elite: 4 };

// Past-paper style section templates (Grade 8 + Grade 11 CAPS assessment windows).
const PAST_PAPER_TEMPLATES = {
  1: {
    sections: [
      { name: "Section A — Numbers & Integers", topics: ["whole_numbers", "integers", "exponents"], count: 6 },
      { name: "Section B — Patterns & Number Sense", topics: ["patterns", "number_sense"], count: 4 }
    ],
    timeMinutes: 60, defaultCount: 10
  },
  2: {
    sections: [
      { name: "Section A — Algebra", topics: ["algebraic_expressions", "algebraic_equations"], count: 6 },
      { name: "Section B — Geometry of Straight Lines", topics: ["geometry_lines"], count: 4 }
    ],
    timeMinutes: 60, defaultCount: 10
  },
  3: {
    sections: [
      { name: "Section A — Measurement & Pythagoras", topics: ["pythagoras", "area_perimeter"], count: 6 },
      { name: "Section B — Finance & Transformations", topics: ["financial_maths", "transformations"], count: 4 }
    ],
    timeMinutes: 60, defaultCount: 10
  },
  4: {
    sections: [
      { name: "Section A — Data Handling", topics: ["data_handling"], count: 4 },
      { name: "Section B — Probability", topics: ["probability"], count: 3 },
      { name: "Section C — Surface Area & Volume", topics: ["surface_area_volume"], count: 3 }
    ],
    timeMinutes: 60, defaultCount: 10
  },
  full: {
    sections: [
      { name: "Section A — Numbers & Algebra", topics: ["whole_numbers", "integers", "exponents", "patterns", "algebraic_expressions", "algebraic_equations"], count: 8 },
      { name: "Section B — Geometry & Measurement", topics: ["geometry_lines", "pythagoras", "area_perimeter", "transformations"], count: 6 },
      { name: "Section C — Data, Finance & Probability", topics: ["data_handling", "financial_maths", "probability"], count: 6 }
    ],
    timeMinutes: 120, defaultCount: 20
  }
};

/** Grade 12 CAPS-style assessment windows (Paper 1 algebra focus for Q1-style papers). */
const G12_PAST_PAPER_TEMPLATES = {
  1: { // March tests
    sections: [
      { name: "QUESTION 1 — Sequences and series", topics: ["sequences_series"], count: 5 },
      { name: "QUESTION 2 — Functions", topics: ["functions_graphs"], count: 4 }
    ],
    timeMinutes: 60, defaultCount: 9, label: "March Test"
  },
  2: { // June exams
    sections: [
      { name: "QUESTION 1 — Sequences and series", topics: ["sequences_series"], count: 5 },
      { name: "QUESTION 2 — Functions and graphs", topics: ["functions_graphs"], count: 5 },
      { name: "QUESTION 3 — Finance", topics: ["finance_12"], count: 4 },
      { name: "QUESTION 4 — Calculus", topics: ["algebra_calculus"], count: 5 }
    ],
    timeMinutes: 120, defaultCount: 19, label: "June Exam"
  },
  3: { // September / trials
    sections: [
      { name: "QUESTION 1 — Sequences", topics: ["sequences_series"], count: 5 },
      { name: "QUESTION 2 — Functions", topics: ["functions_graphs"], count: 5 },
      { name: "QUESTION 3 — Finance", topics: ["finance_12"], count: 4 },
      { name: "QUESTION 4 — Calculus", topics: ["algebra_calculus"], count: 6 },
      { name: "QUESTION 5 — Probability", topics: ["probability_12"], count: 4 }
    ],
    timeMinutes: 150, defaultCount: 24, label: "Trial Exam"
  },
  4: { // November P1-style
    sections: [
      { name: "QUESTION 1 — Algebra / calculus intro", topics: ["algebra_calculus"], count: 4 },
      { name: "QUESTION 2 — Sequences and series", topics: ["sequences_series"], count: 5 },
      { name: "QUESTION 3 — Functions and graphs", topics: ["functions_graphs"], count: 5 },
      { name: "QUESTION 4 — Finance", topics: ["finance_12"], count: 4 },
      { name: "QUESTION 5 — Differential calculus", topics: ["algebra_calculus"], count: 6 },
      { name: "QUESTION 6 — Probability", topics: ["probability_12"], count: 4 }
    ],
    timeMinutes: 150, defaultCount: 28, label: "November Paper 1"
  },
  5: { // Activities / short drills
    sections: [
      { name: "QUESTION 1 — Euclidean geometry", topics: ["euclidean_geometry"], count: 4 },
      { name: "QUESTION 2 — Analytical geometry", topics: ["analytical_geometry"], count: 4 },
      { name: "QUESTION 3 — Trigonometry", topics: ["trigonometry"], count: 4 }
    ],
    timeMinutes: 45, defaultCount: 12, label: "Topic activity"
  }
};

export const PAST_PAPER_PERIODS = [
  "March",
  "June",
  "September",
  "November",
  "Exemplar",
  "Activities"
];

/** Map older period labels / catalog periods onto display periods. */
const PERIOD_ALIASES = {
  "March tests": "March",
  "June exams": "June",
  "September tests": "September",
  "November exams": "November",
  "March": "March",
  "June": "June",
  "September": "September",
  "November": "November",
  "Exemplar": "Exemplar",
  "Activities": "Activities"
};


function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function newPaperId() {
  const d = new Date();
  const p2 = (n) => String(n).padStart(2, "0");
  return "P" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()) + ri(10, 99);
}

/**
 * Hierarchical CAPS-style numbering.
 * Prefers engine-provided partLabel (e.g. 1.1.1) when present.
 * Otherwise groups by section/topic → Question N with subparts N.1, N.2, …
 */
export function numberQuestionsHierarchical(questions) {
  if (!questions || !questions.length) return questions;
  let main = 0;
  let part = 0;
  let prevKey = null;
  let idx = 0;
  for (const q of questions) {
    if (q.partLabel) {
      // Engine already assigned CAPS labels (1.1.1, 1.2.1, …)
      const bits = String(q.partLabel).split(".");
      q.qMain = parseInt(bits[0], 10) || 1;
      q.qPart = q.partLabel;
      q.displayNumber = q.partLabel;
      q.number = ++idx;
      q.sectionLabel = q.section || `QUESTION ${q.qMain}`;
      if (q.groupStem) q.groupStem = q.groupStem;
      continue;
    }
    const key = q.section || q.topic || "_";
    if (key !== prevKey) {
      main += 1;
      part = 0;
      prevKey = key;
    }
    part += 1;
    idx += 1;
    q.qMain = main;
    q.qPart = part;
    q.displayNumber = `${main}.${part}`;
    q.number = idx;
    q.sectionLabel = q.section || (q.topic_name ? `QUESTION ${main} — ${q.topic_name}` : `QUESTION ${main}`);
  }
  return questions;
}


export class PaperEngine {

  generate(student, { paperType = "Term / ATP Aligned", term = null, topics = null, difficulty = "Standard", count = 15, timeMinutes = 45 } = {}) {
    const grade = student.grade ?? 8;
    const gm = new GradeManager(grade);
    const qe = new UnifiedQuestionEngine(grade);
    const ad = new AdaptiveEngine(student);
    term = term ?? student.term ?? 1;
    const diff = DIFFICULTY_MAP[difficulty] ?? 2;
    const allGradeTopics = gm.topicIds();

    // Past Paper Style: structured sections from templates (Grade 8 or Grade 11).
    if (paperType === "Past Paper Style" && (grade === 8 || grade === 11 || grade === 10 || grade === 12 || grade === 12)) {
      const tmplKey = (term >= 1 && term <= 4) ? term : "full";
      const tmplSet = (grade === 11 || grade === 10 || grade === 12 || grade === 12) ? G12_PAST_PAPER_TEMPLATES : PAST_PAPER_TEMPLATES;
      const tmpl = tmplSet[tmplKey] || tmplSet.full;
      const questions = [];
      const sections = {};
      const isFet = grade === 11 || grade === 10 || grade === 12 || grade === 12;
      for (const sec of tmpl.sections) {
        const secTopics = sec.topics.filter((t) => allGradeTopics.includes(t));
        if (!secTopics.length) continue;
        // For FET equations section: emit one full CAPS QUESTION 1 block
        if (isFet && secTopics.includes("equations_inequalities") && /equation/i.test(sec.name || "")) {
          const parts = qe.generatePaperParts("equations_inequalities", diff);
          for (const p of parts) {
            p.section = sec.name;
            questions.push(p);
          }
          continue;
        }
        for (let i = 0; i < sec.count; i++) {
          const topic = secTopics[i % secTopics.length];
          if (isFet && topic === "equations_inequalities" && i === 0) {
            const parts = qe.generatePaperParts(topic, diff);
            for (const p of parts) {
              p.section = sec.name;
              questions.push(p);
            }
            // Count this block as filling the section
            break;
          }
          const q = qe.generate(topic, diff);
          q.section = sec.name;
          questions.push(q);
        }
      }
      if (!questions.length) {
        for (let i = 0; i < (count || tmpl.defaultCount); i++) {
          const topic = allGradeTopics[i % allGradeTopics.length];
          const q = qe.generate(topic, diff);
          questions.push(q);
        }
      }
      numberQuestionsHierarchical(questions);
      for (const q of questions) {
        (sections[q.topic] = sections[q.topic] || []).push(q.displayNumber);
      }
      const totalMarks = questions.reduce((s, q) => s + (q.marks || 1), 0);
      const paperId = newPaperId();
      const paper = {
        paper_id: paperId, grade: gm.grade, grade_label: gm.label(), subject: "Mathematics",
        term, type: paperType, difficulty, topics: [...new Set(questions.map((q) => q.topic))],
        marks: totalMarks, time_minutes: timeMinutes || tmpl.timeMinutes,
        created_at: new Date().toISOString(), student_code: student.code || "",
        student_name: student.name || "", programme_name: student.programme_name || "",
        questions, sections, template: tmplKey, period_label: tmpl.label || null
      };
      localStorage.setItem("learnly:paper:" + paperId, JSON.stringify(paper));
      student.papers = student.papers || [];
      student.papers.push({ id: paperId, type: paperType, term, marks: totalMarks, created_at: paper.created_at });
      return paper;
    }


    if (!topics || !topics.length) {
      if (paperType === "Weakness Recovery") {
        topics = (student.weaknesses || []).filter((t) => allGradeTopics.includes(t));
        if (!topics.length) topics = [ad.chooseTopic("weakness")];
      } else if (paperType === "Strength Challenge") {
        topics = (student.strengths || []).filter((t) => allGradeTopics.includes(t));
        if (!topics.length) topics = [ad.chooseTopic("strength")];
      } else if (paperType === "Term / ATP Aligned" && grade === 8) {
        topics = Object.entries(GRADE8_TOPIC_TERM).filter(([, tm]) => tm === +term).map(([t]) => t);
      } else if (paperType === "Mock Exam") {
        topics = allGradeTopics;
        if (!timeMinutes || timeMinutes < 60) timeMinutes = 90;
        if (!count || count < 15) count = 20;
      } else {
        topics = allGradeTopics;
      }
    }
    // Safety net: strip anything that doesn't belong to this grade.
    topics = topics.filter((t) => allGradeTopics.includes(t));
    if (!topics.length) topics = allGradeTopics;

    // Prefer generating consecutive blocks per topic so hierarchical numbering groups cleanly.
    // Equations on FET: one full CAPS QUESTION 1 multi-part block.
    const questions = [];
    const sections = {};
    const isFet = grade === 11 || grade === 10 || grade === 12 || grade === 12;
    if (isFet && topics.length === 1 && topics[0] === "equations_inequalities") {
      const parts = qe.generatePaperParts("equations_inequalities", diff);
      for (const p of parts) questions.push(p);
    } else {
      const perTopic = Math.max(1, Math.ceil(count / topics.length));
      let produced = 0;
      for (const topic of topics) {
        if (isFet && topic === "equations_inequalities") {
          const parts = qe.generatePaperParts(topic, diff);
          for (const p of parts) questions.push(p);
          produced += parts.length;
          if (produced >= count) break;
          continue;
        }
        const n = Math.min(perTopic, count - produced);
        for (let i = 0; i < n; i++) {
          const qdiff = paperType === "Diagnostic" ? ri(1, 4) : diff;
          const q = qe.generate(topic, qdiff);
          questions.push(q);
          produced++;
        }
        if (produced >= count) break;
      }
      while (produced < count) {
        const topic = topics[produced % topics.length];
        const q = qe.generate(topic, paperType === "Diagnostic" ? ri(1, 4) : diff);
        questions.push(q);
        produced++;
      }
    }
    numberQuestionsHierarchical(questions);
    for (const q of questions) {
      (sections[q.topic] = sections[q.topic] || []).push(q.displayNumber);
    }

    const totalMarks = questions.reduce((s, q) => s + (q.marks || 1), 0);
    const paperId = newPaperId();
    const paper = {
      paper_id: paperId, grade: gm.grade, grade_label: gm.label(), subject: "Mathematics",
      term, type: paperType, difficulty, topics, marks: totalMarks, time_minutes: timeMinutes,
      created_at: new Date().toISOString(), student_code: student.code || "",
      student_name: student.name || "", programme_name: student.programme_name || "",
      questions, sections
    };

    localStorage.setItem("learnly:paper:" + paperId, JSON.stringify(paper));
    student.papers = student.papers || [];
    student.papers.push({ id: paperId, type: paperType, term, marks: totalMarks, created_at: paper.created_at });

    return paper;
  }

  load(paperId) {
    const raw = localStorage.getItem("learnly:paper:" + paperId);
    return raw ? JSON.parse(raw) : null;
  }

  listPapers(studentCode = null) {
    const out = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || !key.startsWith("learnly:paper:")) continue;
      try {
        const d = JSON.parse(localStorage.getItem(key));
        if (studentCode == null || d.student_code === studentCode) out.push(d);
      } catch { /* skip corrupt entries */ }
    }
    out.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    return out;
  }

  /** Optional static bank — Grade 12 uses live engines when absent. */
  async loadEquationsBank() {
    return null;
  }

  /** Load CAPS paper structure templates (lightweight JSON — no image assets). */
  async loadPaperTemplates() {
    if (this._templates) return this._templates;
    try {
      const res = await fetch("./content/grade12/past_papers/paper_templates.json");
      if (!res.ok) throw new Error("Templates not found");
      this._templates = await res.json();
      return this._templates;
    } catch (e) {
      console.warn("paper templates load failed", e);
      return null;
    }
  }

  async listCuratedByPeriod() {
    const groups = {};
    for (const p of PAST_PAPER_PERIODS) groups[p] = [];

    // Equations bank sample papers
    const bank = await this.loadEquationsBank();
    if (bank) {
      for (const s of bank.sample_papers || []) {
        const period = PERIOD_ALIASES[s.period] || s.period || "Activities";
        if (!groups[period]) groups[period] = [];
        groups[period].push({
          ...s,
          source: "bank",
          item_ids: s.item_ids || [],
          item_count: (s.item_ids || []).length
        });
      }
    }

    // Template-defined papers (structure + generator slots)
    const tpl = await this.loadPaperTemplates();
    if (tpl) {
      for (const s of tpl.papers || []) {
        const period = PERIOD_ALIASES[s.period] || s.period || "Activities";
        if (!groups[period]) groups[period] = [];
        groups[period].push({
          id: s.id,
          title: s.title,
          period,
          year: s.year || null,
          paper: s.paper || null,
          time_minutes: s.time_minutes || 60,
          item_ids: (s.sections || []).flatMap((sec) => (sec.slots || []).map((sl) => sl.id || sl.type)),
          source: "template",
          item_count: (s.sections || []).reduce((n, sec) => n + (sec.slots || []).length, 0)
        });
      }
    }
    return groups;
  }

  /**
   * Build a paper from a template by generating fresh questions for each slot
   * using the FET engine (unique every time). Falls back to equations bank.
   */
  async buildCuratedPaper(sampleId, student = {}) {
    const tpl = await this.loadPaperTemplates();
    if (tpl) {
      const sample = (tpl.papers || []).find((s) => s.id === sampleId);
      if (sample) return this._buildFromTemplate(sample, student);
    }

    const bank = await this.loadEquationsBank();
    if (!bank) return null;
    const sample = (bank.sample_papers || []).find((s) => s.id === sampleId);
    if (!sample) return null;
    const byId = Object.fromEntries((bank.items || []).map((it) => [it.id, it]));
    const questions = [];
    for (const id of sample.item_ids || []) {
      const it = byId[id];
      if (!it) continue;
      questions.push({
        id: it.id,
        topic: bank.topic,
        topic_name: bank.topic_name,
        section: `QUESTION 1 — ${bank.topic_name}`,
        question: it.question,
        answer: it.answer,
        explanation: it.explanation,
        hint: it.hint || "",
        marks: it.marks || 3,
        difficulty: 2,
        partLabel: it.partLabel || null,
        group: it.group || null,
        groupStem: it.groupStem || null,
        capsFormat: true
      });
    }
    numberQuestionsHierarchical(questions);
    const totalMarks = questions.reduce((s, q) => s + q.marks, 0);
    return {
      paper_id: sample.id,
      curated: true,
      grade: 11,
      grade_label: "Grade 11",
      subject: "Mathematics",
      term: sample.term || 0,
      type: sample.type || "Past Paper",
      period: sample.period || "Activities",
      title: sample.title,
      difficulty: "Standard",
      topics: [bank.topic],
      marks: totalMarks,
      time_minutes: sample.time_minutes || 60,
      created_at: new Date().toISOString(),
      student_code: student.code || "",
      student_name: student.name || "",
      questions,
      sections: { [bank.topic]: questions.map((q) => q.displayNumber) }
    };
  }

  _buildFromTemplate(sample, student = {}) {
    // Grade 12 Elites — use Grade 12 engines and CAPS topic IDs
    const eng = new UnifiedQuestionEngine(12);
    const questions = [];
    let qMain = 0;
    const structuredTopics = new Set([
      "sequences_series", "functions_graphs", "finance_12", "algebra_calculus",
      "probability_12", "trigonometry", "analytical_geometry", "euclidean_geometry",
      "statistics_12"
    ]);

    for (const sec of sample.sections || []) {
      qMain += 1;
      const topic = sec.topic || (sec.slots && sec.slots[0] && sec.slots[0].topic) || "algebra_calculus";
      const diff = (sec.slots && sec.slots[0] && sec.slots[0].difficulty) || 2;

      if (structuredTopics.has(topic) && typeof eng.generatePaperParts === "function") {
        let parts = eng.generatePaperParts(topic, diff) || [];
        // Fallback: multiple independent recipe items when multi-part is thin
        if (!parts.length || (parts.length === 1 && !parts[0].partLabel && !(sec.slots && sec.slots.length > 1))) {
          const slotCount = (sec.slots && sec.slots.length) || 3;
          parts = [];
          for (let i = 0; i < slotCount; i++) {
            const slotDiff = (sec.slots && sec.slots[i] && sec.slots[i].difficulty) || diff;
            const gen = eng.generate(topic, slotDiff);
            if (gen) {
              gen.partLabel = `${qMain}.${i + 1}`;
              gen.marks = (sec.slots && sec.slots[i] && sec.slots[i].marks) || gen.marks || 3;
              parts.push(gen);
            }
          }
        }
        for (const gen of parts) {
          questions.push({
            id: `tpl_${sample.id}_${qMain}_${gen.partLabel || ri(1000, 9999)}`,
            topic: gen.topic || topic,
            topic_name: gen.topic_name || topic.replaceAll("_", " "),
            section: sec.name || `QUESTION ${qMain}`,
            sectionLabel: sec.name || gen.sectionLabel || `QUESTION ${qMain}`,
            question: gen.question,
            answer: gen.answer,
            explanation: gen.explanation || "",
            hint: gen.hint || "",
            marks: gen.marks || 3,
            difficulty: diff,
            partLabel: gen.partLabel || String(qMain),
            qMain,
            group: gen.group || null,
            groupStem: gen.groupStem || sec.stem || null,
            capsFormat: true,
            diagram: gen.diagram || null
          });
        }
        continue;
      }

      const slots = sec.slots || [{ topic, difficulty: diff, marks: 3 }];
      slots.forEach((slot, i) => {
        const tId = slot.topic || topic;
        let gen;
        try {
          gen = eng.generate(tId, slot.difficulty || diff);
        } catch (e) {
          gen = {
            topic: tId,
            topic_name: tId.replaceAll("_", " "),
            question: `Complete a CAPS-style exercise for ${tId.replaceAll("_", " ")}.`,
            answer: "See memorandum",
            explanation: "",
            marks: slot.marks || 3
          };
        }
        const partLabel = slots.length > 1 ? `${qMain}.${i + 1}` : String(qMain);
        questions.push({
          id: `tpl_${sample.id}_${partLabel}_${ri(1000, 9999)}`,
          topic: gen.topic || tId,
          topic_name: gen.topic_name || tId.replaceAll("_", " "),
          section: sec.name || `QUESTION ${qMain}`,
          sectionLabel: sec.name || `QUESTION ${qMain}`,
          question: gen.question,
          answer: gen.answer,
          explanation: gen.explanation || "",
          hint: gen.hint || "",
          marks: slot.marks || gen.marks || 3,
          difficulty: slot.difficulty || diff,
          partLabel,
          qMain,
          qPart: i + 1,
          group: slots.length > 1 ? String(qMain) : null,
          groupStem: sec.stem || null,
          capsFormat: true,
          diagram: gen.diagram || null
        });
      });
    }
    numberQuestionsHierarchical(questions);
    const totalMarks = questions.reduce((s, q) => s + (q.marks || 0), 0);
    return {
      paper_id: sample.id + "_" + Date.now().toString(36),
      curated: true,
      generated: true,
      grade: 12,
      grade_label: "Grade 12",
      subject: "Mathematics",
      term: sample.term || 0,
      type: sample.type || "Past Paper",
      period: sample.period || "Activities",
      year: sample.year || null,
      title: sample.title,
      difficulty: sample.difficulty || "Standard",
      topics: [...new Set(questions.map((q) => q.topic))],
      marks: totalMarks,
      time_minutes: sample.time_minutes || 150,
      created_at: new Date().toISOString(),
      student_code: student.code || "",
      student_name: student.name || "",
      questions,
      sections: Object.fromEntries(
        (sample.sections || []).map((sec, idx) => [
          sec.name || `Q${idx + 1}`,
          questions.filter((q) => q.qMain === idx + 1).map((q) => q.partLabel)
        ])
      )
    };
  }
}
