import { applyTheme } from "../theme.js";

// Core story badges + generated level ladder (shows by learner level).
const CORE = [
  { id: "first_spark", name: "First Spark", icon: "✨", desc: "First answer.", minLevel: 1, check: (s) => (s.history || []).length >= 1, reward: 10 },
  { id: "warm_up", name: "Warm-Up", icon: "🌤️", desc: "10 answers.", minLevel: 1, check: (s) => (s.history || []).length >= 10, reward: 15 },
  { id: "fifty_club", name: "Fifty", icon: "5️⃣", desc: "50 answers.", minLevel: 1, check: (s) => (s.history || []).length >= 50, reward: 25 },
  { id: "hundred_club", name: "Hundred", icon: "💯", desc: "100 answers.", minLevel: 2, check: (s) => (s.history || []).length >= 100, reward: 50 },
  { id: "sprint_5", name: "Sprint 5", icon: "⚡", desc: "Sprint streak 5.", minLevel: 1, check: (s) => (s.mental_best_streak || 0) >= 5, reward: 15 },
  { id: "sprint_15", name: "Sprint 15", icon: "🏃", desc: "Sprint streak 15.", minLevel: 2, check: (s) => (s.mental_best_streak || 0) >= 15, reward: 30 },
  { id: "streak_3", name: "3-day streak", icon: "🔥", desc: "Practice 3 days.", minLevel: 1, check: (s) => (s.streak || 0) >= 3, reward: 20 },
  { id: "streak_7", name: "7-day streak", icon: "📅", desc: "Practice 7 days.", minLevel: 2, check: (s) => (s.streak || 0) >= 7, reward: 40 },
  { id: "struct_1", name: "Challenge start", icon: "📋", desc: "One multi-part question.", minLevel: 1, check: (s) => (s.history || []).some((h) => String(h.question_id || "").includes("struct")), reward: 20 },
  { id: "fraction_15", name: "Fraction 15", icon: "🍕", desc: "15 fraction wins.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("fraction") && h.correct).length >= 15, reward: 25 },
  { id: "data_15", name: "Data 15", icon: "📊", desc: "15 data wins.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("data") && h.correct).length >= 15, reward: 25 },
  { id: "shape_15", name: "Shape 15", icon: "🔺", desc: "15 shape wins.", minLevel: 1, check: (s) => (s.history || []).filter((h) => /geometry|shape/.test(String(h.topic || "")) && h.correct).length >= 15, reward: 25 },
  { id: "goal_1", name: "Daily goal", icon: "🎯", desc: "Hit today's goal.", minLevel: 1, check: (s) => (s.today_done || 0) >= (s.daily_goal || 20), reward: 20 },
  { id: "shop_1", name: "First buy", icon: "🛒", desc: "Buy from the shop.", minLevel: 1, check: (s) => (s.unlocked_rewards || []).length >= 1, reward: 15 },
  // Grade 11 / FET
  { id: "g11_eq_10", name: "Equation ten", icon: "🧮", desc: "10 correct equations.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("equation") && h.correct).length >= 10, reward: 30 },
  { id: "g11_pattern_10", name: "Pattern finder", icon: "🔢", desc: "10 correct number patterns.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("pattern") && h.correct).length >= 10, reward: 30 },
  { id: "g11_fn_10", name: "Function form", icon: "📈", desc: "10 correct functions.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("function") && h.correct).length >= 10, reward: 30 },
  { id: "g11_euc_10", name: "Circle rider", icon: "⭕", desc: "10 correct Euclidean.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("euclidean") && h.correct).length >= 10, reward: 35 },
  { id: "g11_trig_10", name: "Trig ten", icon: "📐", desc: "10 correct trigonometry.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").includes("trig") && h.correct).length >= 10, reward: 30 },
  { id: "g11_paper_1", name: "Paper starter", icon: "📄", desc: "Open a past paper.", minLevel: 1, check: (s) => !!(s.flags && s.flags.opened_paper), reward: 25 },
  { id: "g11_topic_practice", name: "Topic grind", icon: "🎯", desc: "Finish a topic practice set.", minLevel: 1, check: (s) => !!(s.flags && s.flags.topic_practice), reward: 25 },
  { id: "g11_theorem", name: "Theorem lab", icon: "📜", desc: "Visit Theorem Workshop.", minLevel: 1, check: (s) => !!(s.flags && s.flags.theorem_lab), reward: 20 },
  { id: "g11_five_topics", name: "Five topics", icon: "🌟", desc: "Correct answers in 5 different topics.", minLevel: 2, check: (s) => new Set((s.history || []).filter((h) => h.correct).map((h) => h.topic)).size >= 5, reward: 40 },
  { id: "star_spender", name: "Star spender", icon: "✨", desc: "Spend 100 stars in the shop.", minLevel: 1, check: (s) => (s.transactions || []).filter((t) => t.amount < 0).reduce((a, t) => a + Math.abs(t.amount), 0) >= 100, reward: 20 },
  // Grade 10 — Math Lit · Business · Tourism
  { id: "g10_first_ml", name: "Math Lit start", icon: "📐", desc: "First correct Math Literacy answer.", minLevel: 1, check: (s) => (s.history || []).some((h) => String(h.topic || "").startsWith("ml_") && h.correct), reward: 15 },
  { id: "g10_first_bs", name: "Business start", icon: "💼", desc: "First correct Business Studies answer.", minLevel: 1, check: (s) => (s.history || []).some((h) => String(h.topic || "").startsWith("bs_") && h.correct), reward: 15 },
  { id: "g10_first_tour", name: "Tourism start", icon: "✈️", desc: "First correct Tourism answer.", minLevel: 1, check: (s) => (s.history || []).some((h) => String(h.topic || "").startsWith("tour_") && h.correct), reward: 15 },
  { id: "g10_ml_10", name: "Finance focus", icon: "💰", desc: "10 correct Math Literacy answers.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").startsWith("ml_") && h.correct).length >= 10, reward: 30 },
  { id: "g10_bs_10", name: "Enterprise ten", icon: "🏢", desc: "10 correct Business answers.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").startsWith("bs_") && h.correct).length >= 10, reward: 30 },
  { id: "g10_tour_10", name: "Travel ten", icon: "🗺️", desc: "10 correct Tourism answers.", minLevel: 1, check: (s) => (s.history || []).filter((h) => String(h.topic || "").startsWith("tour_") && h.correct).length >= 10, reward: 30 },
  { id: "g10_vat", name: "VAT ready", icon: "🧾", desc: "5 correct finance / percentage answers.", minLevel: 1, check: (s) => (s.history || []).filter((h) => /ml_finance|ml_percentage|vat|budget/i.test(String(h.topic || "")) && h.correct).length >= 5, reward: 25 },
  { id: "g10_data", name: "Data reader", icon: "📊", desc: "5 correct data / probability answers.", minLevel: 1, check: (s) => (s.history || []).filter((h) => /ml_data|ml_probability|ml_graphs|ml_patterns/i.test(String(h.topic || "")) && h.correct).length >= 5, reward: 25 },
  { id: "g10_lesson", name: "Lesson finisher", icon: "📖", desc: "Complete a learning card.", minLevel: 1, check: (s) => !!(s.flags && s.flags.learning_card_done), reward: 20 },
  { id: "g10_paper", name: "Paper explorer", icon: "📄", desc: "Open an exam-style paper.", minLevel: 1, check: (s) => !!(s.flags && (s.flags.opened_paper || s.flags.g10_paper)), reward: 25 },
  { id: "g10_three_subjects", name: "Triple subject", icon: "🌟", desc: "Correct answers in all three subjects.", minLevel: 2, check: (s) => {
    const t = (s.history || []).filter((h) => h.correct).map((h) => String(h.topic || ""));
    return t.some((x) => x.startsWith("ml_")) && t.some((x) => x.startsWith("bs_")) && t.some((x) => x.startsWith("tour_"));
  }, reward: 50 },
  { id: "g10_streak_5", name: "Five-day fire", icon: "🔥", desc: "Calendar streak of 5 days.", minLevel: 1, check: (s) => (s.streak || 0) >= 5, reward: 35 },
  { id: "g10_daily_ch", name: "Challenge taker", icon: "🎯", desc: "Complete a daily challenge.", minLevel: 1, check: (s) => !!(s.flags && Object.keys(s.flags).some((k) => k.startsWith("daily_ch_"))), reward: 20 },
  { id: "g10_level_5", name: "Level five", icon: "5️⃣", desc: "Reach level 5.", minLevel: 1, check: (s) => (s.level || 1) >= 5, reward: 40 },
  { id: "g10_combo_5", name: "Combo five", icon: "💥", desc: "Answer 5 correctly in a row.", minLevel: 1, check: (s) => (s.best_combo || 0) >= 5, reward: 25 },
  { id: "g10_combo_10", name: "Combo ten", icon: "🔥", desc: "Answer 10 correctly in a row.", minLevel: 2, check: (s) => (s.best_combo || 0) >= 10, reward: 45 },
  { id: "g10_perfect_session", name: "Perfect session", icon: "💯", desc: "Finish a practice session with 100% accuracy (min 5 Qs).", minLevel: 1, check: (s) => !!(s.flags && s.flags.perfect_session), reward: 30 },
  { id: "g10_weekly_quest", name: "Weekly quest", icon: "🗓️", desc: "Complete a weekly quest.", minLevel: 1, check: (s) => !!(s.flags && Object.keys(s.flags).some((k) => k.startsWith("weekly_q_"))), reward: 35 },
  { id: "g10_ml_master", name: "Math Lit focus", icon: "📐", desc: "25 correct Math Literacy answers.", minLevel: 2, check: (s) => (s.history || []).filter((h) => String(h.topic || "").startsWith("ml_") && h.correct).length >= 25, reward: 40 },
  { id: "g10_bs_master", name: "Business focus", icon: "💼", desc: "25 correct Business answers.", minLevel: 2, check: (s) => (s.history || []).filter((h) => String(h.topic || "").startsWith("bs_") && h.correct).length >= 25, reward: 40 },
  { id: "g10_tour_master", name: "Tourism focus", icon: "✈️", desc: "25 correct Tourism answers.", minLevel: 2, check: (s) => (s.history || []).filter((h) => String(h.topic || "").startsWith("tour_") && h.correct).length >= 25, reward: 40 },
  { id: "g10_comeback", name: "Comeback", icon: "↩️", desc: "Get a correct answer after three wrongs.", minLevel: 1, check: (s) => !!(s.flags && s.flags.comeback), reward: 20 },
  { id: "g10_streak_14", name: "Two-week fire", icon: "🔥", desc: "Calendar streak of 14 days.", minLevel: 3, check: (s) => (s.streak || 0) >= 14, reward: 60 },
  { id: "g10_lesson_10", name: "Lesson learner", icon: "📖", desc: "Complete 10 learning cards.", minLevel: 1, check: (s) => (s.flags && (s.flags.lessons_done || 0) >= 10) || (s.history || []).filter((h) => String(h.mode || "").includes("lesson")).length >= 10, reward: 30 },
  { id: "g10_login_7", name: "Week visitor", icon: "🗓️", desc: "Claim daily login bonus 7 times.", minLevel: 1, check: (s) => (s.flags && (s.flags.login_days || 0) >= 7), reward: 35 },
  { id: "g10_missions_3", name: "Mission day", icon: "🎖️", desc: "Complete all 3 daily missions in one day.", minLevel: 1, check: (s) => !!(s.missions && s.missions.items && s.missions.items.every((m) => m.done)), reward: 40 },
  { id: "g10_paper_5", name: "Paper trail", icon: "📄", desc: "Open 5 exam-style papers.", minLevel: 2, check: (s) => (s.flags && (s.flags.papers_opened || 0) >= 5) || (s.papers || []).length >= 5, reward: 30 }
];

// Generate level ladder badges up to a large catalogue (level-gated display).
function buildLadder() {
  const out = [];
  const icons = ["⭐", "🌟", "💫", "🔥", "🎯", "🏆", "🎖️", "💎", "🚀", "🌈"];
  for (let lvl = 1; lvl <= 50; lvl++) {
    for (let i = 1; i <= 20; i++) {
      const id = `lvl_${lvl}_${i}`;
      const need = (lvl - 1) * 20 + i; // answers milestone
      out.push({
        id,
        name: `Level ${lvl} · ${i}`,
        icon: icons[(lvl + i) % icons.length],
        desc: `Reach ${need * 5} XP or level ${lvl}.`,
        minLevel: lvl,
        check: (s) => (s.level || 1) >= lvl && ((s.xp || 0) >= need * 5 || (s.history || []).length >= need * 3),
        reward: 5 + Math.floor(lvl / 2)
      });
    }
  }
  return out; // 1000 ladder badges
}

export const ACHIEVEMENTS = [...CORE, ...buildLadder()];

const THEME_REWARDS = [
  { id: "theme_sunset", name: "Sunset", icon: "🌅", cost: 40, desc: "Warm evening glow.", theme: "Sunset", minLevel: 1, kind: "theme" },
  { id: "theme_forest", name: "Forest", icon: "🌿", cost: 40, desc: "Calm greens.", theme: "Forest", minLevel: 1, kind: "theme" },
  { id: "theme_ocean", name: "Ocean", icon: "🌊", cost: 45, desc: "Deep blue focus.", theme: "Ocean", minLevel: 1, kind: "theme" },
  { id: "theme_candy", name: "Candy", icon: "🍭", cost: 45, desc: "Bright pink energy.", theme: "Candy", minLevel: 1, kind: "theme" },
  { id: "theme_midnight", name: "Midnight", icon: "🌙", cost: 35, desc: "True dark mode.", theme: "Midnight", minLevel: 1, kind: "theme" },
  { id: "theme_neon", name: "Neon", icon: "💜", cost: 50, desc: "Electric neon.", theme: "Neon", minLevel: 2, kind: "theme" },
  { id: "theme_academic", name: "Academic", icon: "🎓", cost: 55, desc: "Clean study look.", theme: "Academic", minLevel: 2, kind: "theme" },
  { id: "theme_glass", name: "Glass", icon: "🪟", cost: 60, desc: "Frosted glass UI.", theme: "Glass", minLevel: 3, kind: "theme" },
  { id: "theme_aurora", name: "Aurora", icon: "🌌", cost: 70, desc: "Northern-lights vibe.", theme: "Aurora", minLevel: 4, kind: "theme" },
  { id: "theme_gold", name: "Gold", icon: "👑", cost: 90, desc: "Premium gold accents.", theme: "Gold", minLevel: 5, kind: "theme" },
  { id: "theme_examdesk", name: "Exam desk", icon: "📝", cost: 65, desc: "Paper-white desk look for exams.", theme: "Academic", minLevel: 2, kind: "theme" },
  { id: "theme_safari", name: "Safari", icon: "🦁", cost: 55, desc: "Warm savannah tones with Kepi.", theme: "Sunset", minLevel: 2, kind: "theme" }
];

const UI_UPGRADES = [
  { id: "ui_compact", name: "Compact cards", icon: "📦", cost: 80, desc: "Tighter card spacing for more on screen.", minLevel: 2, kind: "ui" },
  { id: "ui_large_type", name: "Exam type size", icon: "🔤", cost: 60, desc: "Larger question text in papers.", minLevel: 1, kind: "ui" },
  { id: "ui_progress_ring", name: "Progress ring", icon: "⭕", cost: 70, desc: "Ring meter on Home for daily goal.", minLevel: 2, kind: "ui" },
  { id: "ui_confetti", name: "Confetti bursts", icon: "🎉", cost: 50, desc: "Celebrate correct multi-part answers.", minLevel: 1, kind: "ui" },
  { id: "ui_paper_serif", name: "Paper serif", icon: "✒️", cost: 65, desc: "Exam-style serif font in paper viewer.", minLevel: 2, kind: "ui" },
  { id: "ui_diagram_hd", name: "HD diagrams", icon: "🖼️", cost: 75, desc: "Sharper canvas diagrams on retina screens.", minLevel: 2, kind: "ui" },
  { id: "ui_focus_mode", name: "Focus mode", icon: "🎯", cost: 90, desc: "Dim chrome during practice for fewer distractions.", minLevel: 3, kind: "ui" },
  { id: "ui_combo_fx", name: "Combo effects", icon: "💥", cost: 55, desc: "Stronger feedback when you hit answer combos.", minLevel: 1, kind: "ui" },
  { id: "frame_gold", name: "Gold frame", icon: "🖼️", cost: 100, desc: "Gold border on profile avatar.", minLevel: 3, kind: "frame" },
  { id: "frame_neon", name: "Neon frame", icon: "💜", cost: 100, desc: "Neon border on profile avatar.", minLevel: 3, kind: "frame" },
  { id: "frame_maths", name: "π frame", icon: "π", cost: 85, desc: "Maths-symbol avatar frame.", minLevel: 2, kind: "frame" },
  { id: "frame_kepi", name: "Kepi frame", icon: "🦡", cost: 95, desc: "Meerkat badge around your avatar.", minLevel: 2, kind: "frame" },
  { id: "frame_travel", name: "Travel frame", icon: "✈️", cost: 90, desc: "Tourism-style passport frame.", minLevel: 2, kind: "frame" },
  { id: "title_scholar", name: "Title: Scholar", icon: "🏷️", cost: 120, desc: "Show Scholar under your name.", minLevel: 4, kind: "title" },
  { id: "title_elite", name: "Title: Elite G10", icon: "🏷️", cost: 110, desc: "Grade 10 elite under your name.", minLevel: 3, kind: "title" },
  { id: "title_ml", name: "Title: Math Lit pro", icon: "🏷️", cost: 80, desc: "For Mathematical Literacy grinders.", minLevel: 2, kind: "title" },
  { id: "title_biz", name: "Title: Business ace", icon: "🏷️", cost: 80, desc: "For Business Studies focus.", minLevel: 2, kind: "title" },
  { id: "title_tour", name: "Title: Tourism guide", icon: "🏷️", cost: 80, desc: "For Tourism explorers.", minLevel: 2, kind: "title" },
  { id: "boost_double_star", name: "Double-star hour", icon: "⭐", cost: 150, desc: "Next hour earns 2× stars from practice.", minLevel: 3, kind: "boost" },
  { id: "boost_streak_freeze", name: "Streak freeze", icon: "🧊", cost: 120, desc: "Protect your calendar streak for one missed day.", minLevel: 2, kind: "boost" },
  { id: "boost_combo_shield", name: "Combo shield", icon: "🛡️", cost: 100, desc: "One wrong answer will not reset your combo (once).", minLevel: 2, kind: "boost" },
  { id: "boost_hint_pack", name: "Hint pack", icon: "💡", cost: 70, desc: "Extra gentle hints flagged for the next session.", minLevel: 1, kind: "boost" }
];

function buildShopLadder() {
  const out = [...THEME_REWARDS, ...UI_UPGRADES];
  const frames = ["🥇", "🚀", "📚", "🦊", "⚡", "🎯", "🌟", "💎"];
  for (let lvl = 1; lvl <= 12; lvl++) {
    out.push({
      id: `shop_pack_${lvl}`,
      name: `Study pack L${lvl}`,
      icon: frames[lvl % frames.length],
      cost: 30 + lvl * 8,
      desc: `Level ${lvl} cosmetic study pack.`,
      minLevel: lvl,
      kind: "pack"
    });
  }
  ["Explorer", "Sprinter", "Budget boss", "Map reader", "Data detective", "Service star"].forEach((name, i) => {
    out.push({
      id: `title_core_${i}`,
      name: `Title: ${name}`,
      icon: "🏷️",
      cost: 40 + i * 12,
      desc: name,
      minLevel: 1 + Math.floor(i / 2),
      kind: "title"
    });
  });
  return out;
}

export const REWARD_SHOP = buildShopLadder();

export class GamificationEngine {
  constructor(student) {
    this.student = student;
    if (!student.achievements) student.achievements = [];
    if (!student.unlocked_rewards) student.unlocked_rewards = [];
    if (!student.active_reward) student.active_reward = null;
    if (!student.level) student.level = Math.max(1, Math.floor((student.xp || 0) / 100) + 1);
  }
  level() {
    const lvl = Math.max(1, Math.floor((this.student.xp || 0) / 100) + 1);
    this.student.level = lvl;
    return lvl;
  }
  checkNewUnlocks() {
    this.level();
    const unlocked = new Set(this.student.achievements);
    const newly = [];
    for (const ach of ACHIEVEMENTS) {
      if (unlocked.has(ach.id)) continue;
      // only evaluate badges at or below level+2 for performance
      if ((ach.minLevel || 1) > this.student.level + 2) continue;
      try {
        if (ach.check(this.student)) {
          this.student.achievements.push(ach.id);
          newly.push(ach);
          if (ach.reward) {
            this.student.credits = (this.student.credits || 0) + ach.reward;
            this.student.transactions = this.student.transactions || [];
            this.student.transactions.push({
              amount: ach.reward, reason: `Badge: ${ach.name}`,
              timestamp: new Date().toISOString(), balance_after: this.student.credits
            });
          }
        }
      } catch { /* ignore */ }
    }
    return newly;
  }
  allWithStatus() {
    const lvl = this.level();
    const unlocked = new Set(this.student.achievements || []);
    // Show core + badges up to level+1 (not all 1000 at once)
    return ACHIEVEMENTS
      .filter((a) => (a.minLevel || 1) <= lvl + 1)
      .map((a) => ({
        id: a.id, name: a.name, icon: a.icon, desc: a.desc,
        unlocked: unlocked.has(a.id), reward: a.reward || 0, minLevel: a.minLevel || 1
      }));
  }
  progressSummary() {
    const lvl = this.level();
    const visible = ACHIEVEMENTS.filter((a) => (a.minLevel || 1) <= lvl + 1);
    const unlocked = new Set(this.student.achievements || []);
    const have = visible.filter((a) => unlocked.has(a.id)).length;
    return [have, visible.length, ACHIEVEMENTS.length];
  }
  shopItems() {
    const lvl = this.level();
    const owned = new Set(this.student.unlocked_rewards || []);
    return REWARD_SHOP
      .filter((r) => (r.minLevel || 1) <= lvl)
      .map((r) => ({ ...r, owned: owned.has(r.id) }));
  }
  buy(rewardId) {
    const item = REWARD_SHOP.find((r) => r.id === rewardId);
    if (!item) return { ok: false, reason: "not_found" };
    if ((item.minLevel || 1) > this.level()) return { ok: false, reason: "level" };
    const owned = new Set(this.student.unlocked_rewards || []);
    if (owned.has(rewardId)) return { ok: false, reason: "owned" };
    const bal = this.student.credits || 0;
    if (bal < item.cost) return { ok: false, reason: "funds" };
    this.student.credits = bal - item.cost;
    this.student.unlocked_rewards.push(rewardId);
    this.student.transactions = this.student.transactions || [];
    this.student.transactions.push({
      amount: -item.cost, reason: `Shop: ${item.name}`,
      timestamp: new Date().toISOString(), balance_after: this.student.credits
    });
    return { ok: true, item };
  }
  equip(rewardId) {
    const owned = new Set(this.student.unlocked_rewards || []);
    if (!owned.has(rewardId)) return false;
    this.student.active_reward = rewardId;
    const item = REWARD_SHOP.find((r) => r.id === rewardId);
    this.student.settings = this.student.settings || {};
    this.student.flags = this.student.flags || {};
    if (item?.theme) {
      this.student.settings.theme = item.theme;
      applyTheme(item.theme, this.student.settings.font_scale || "Normal");
    }
    // Wire UI upgrade flags
    if (item?.kind === "ui" || item?.kind === "boost") {
      const ui = this.student.settings.ui = this.student.settings.ui || {};
      if (rewardId === "ui_compact") ui.compact = true;
      if (rewardId === "ui_large_type") ui.large_type = true;
      if (rewardId === "ui_progress_ring") ui.progress_ring = true;
      if (rewardId === "ui_confetti") ui.confetti = true;
      if (rewardId === "ui_paper_serif") ui.paper_serif = true;
      if (rewardId === "ui_diagram_hd") ui.diagram_hd = true;
      if (rewardId === "boost_double_star") {
        this.student.flags.double_star_active = true;
        this.student.flags.double_star_until = Date.now() + 60 * 60 * 1000;
      }
      if (rewardId === "boost_streak_freeze") {
        this.student.flags.streak_freeze = (this.student.flags.streak_freeze || 0) + 1;
      }
      if (rewardId === "boost_combo_shield") {
        this.student.flags.combo_shield = (this.student.flags.combo_shield || 0) + 1;
      }
      if (rewardId === "boost_hint_pack") {
        this.student.flags.hint_pack = true;
      }
      if (rewardId === "ui_focus_mode") ui.focus_mode = true;
      if (rewardId === "ui_combo_fx") ui.combo_fx = true;
    }
    if (item?.kind === "title") {
      this.student.settings.title = item.name.replace(/^Title:\s*/i, "");
    }
    if (item?.kind === "frame") {
      this.student.settings.frame = rewardId;
    }
    applyUiFlags(this.student);
    return true;
  }
}

/** Apply owned UI flags to document (compact, large type, paper serif, etc.). */
export function applyUiFlags(student) {
  const root = document.documentElement;
  const ui = (student?.settings && student.settings.ui) || {};
  root.classList.toggle("ui-compact", !!ui.compact);
  root.classList.toggle("ui-large-type", !!ui.large_type);
  root.classList.toggle("ui-paper-serif", !!ui.paper_serif);
  root.classList.toggle("ui-confetti", !!ui.confetti);
  // Expire double-star
  if (student?.flags?.double_star_active && student.flags.double_star_until && Date.now() > student.flags.double_star_until) {
    student.flags.double_star_active = false;
  }
}

/** ISO week key YYYY-Www */
export function weekKey(d = new Date()) {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
  return `${date.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

const WEEKLY_QUEST_POOL = [
  { id: "practice_20", label: "Answer 20 practice questions", target: 20, metric: "practice_count" },
  { id: "correct_15", label: "Get 15 correct answers", target: 15, metric: "correct_count" },
  { id: "ml_10", label: "10 correct Math Lit answers", target: 10, metric: "ml_correct" },
  { id: "bs_8", label: "8 correct Business answers", target: 8, metric: "bs_correct" },
  { id: "tour_8", label: "8 correct Tourism answers", target: 8, metric: "tour_correct" },
  { id: "lesson_5", label: "Finish 5 learning cards", target: 5, metric: "lessons" },
  { id: "streak_4", label: "Reach a 4-day calendar streak", target: 4, metric: "streak" },
  { id: "quiz_12", label: "Complete 12 quiz questions", target: 12, metric: "quiz_count" }
];

/** Stable weekly quest for the current ISO week (rotates by week number). */
export function getWeeklyQuest(student) {
  const wk = weekKey();
  student.flags = student.flags || {};
  student.weekly = student.weekly || {};
  if (student.weekly.week !== wk) {
    const idx = parseInt(wk.replace(/\D/g, ""), 10) % WEEKLY_QUEST_POOL.length;
    const q = WEEKLY_QUEST_POOL[idx];
    student.weekly = {
      week: wk,
      questId: q.id,
      label: q.label,
      target: q.target,
      metric: q.metric,
      progress: 0,
      done: false
    };
  }
  return student.weekly;
}

/** Update weekly quest progress from a metric event; returns true if just completed. */
export function tickWeeklyQuest(student, metric, amount = 1) {
  const q = getWeeklyQuest(student);
  if (q.done) return false;
  if (q.metric !== metric) return false;
  q.progress = Math.min(q.target, (q.progress || 0) + amount);
  if (q.progress >= q.target) {
    q.done = true;
    student.flags = student.flags || {};
    student.flags[`weekly_q_${q.week}`] = true;
    return true;
  }
  return false;
}

/** Daily mini-missions (rotate by date). */
const DAILY_MISSION_POOL = [
  { id: "m_practice_8", label: "Answer 8 practice questions", target: 8, metric: "practice_count", icon: "✏️" },
  { id: "m_correct_5", label: "Get 5 answers correct", target: 5, metric: "correct_count", icon: "✅" },
  { id: "m_lesson_1", label: "Finish 1 learning card", target: 1, metric: "lessons", icon: "📖" },
  { id: "m_quiz_6", label: "Complete 6 quiz questions", target: 6, metric: "quiz_count", icon: "❓" },
  { id: "m_combo_1", label: "Hit a ×3 answer combo", target: 1, metric: "combo_hit", icon: "💥" },
  { id: "m_paper_1", label: "Open 1 full paper", target: 1, metric: "papers_opened", icon: "📝" }
];

function dayKey() {
  return new Date().toISOString().slice(0, 10);
}

export function getDailyMissions(student) {
  const day = dayKey();
  student.missions = student.missions || {};
  if (student.missions.day !== day) {
    // Pick 3 stable missions from pool by date hash
    const seed = day.split("-").join("");
    const n = parseInt(seed.slice(-4), 10) || 1;
    const picks = [];
    for (let i = 0; i < 3; i++) {
      const idx = (n + i * 3) % DAILY_MISSION_POOL.length;
      const m = DAILY_MISSION_POOL[idx];
      picks.push({
        id: m.id,
        label: m.label,
        target: m.target,
        metric: m.metric,
        icon: m.icon,
        progress: 0,
        done: false
      });
    }
    student.missions = { day, items: picks, paid: {} };
  }
  if (!student.missions.items) student.missions.items = [];
  return student.missions;
}

/** Tick a mission metric; returns list of missions just completed. */
export function tickDailyMission(student, metric, amount = 1) {
  const pack = getDailyMissions(student);
  const just = [];
  (pack.items || []).forEach((m) => {
    if (m.done) return;
    if (m.metric !== metric) return;
    m.progress = Math.min(m.target, (m.progress || 0) + amount);
    if (m.progress >= m.target) {
      m.done = true;
      just.push(m);
    }
  });
  return just;
}

/** Grant star rewards for newly completed missions (once each). */
export function claimMissionRewards(student, economy) {
  const pack = getDailyMissions(student);
  pack.paid = pack.paid || {};
  let total = 0;
  (pack.items || []).forEach((m) => {
    if (!m.done || pack.paid[m.id]) return;
    pack.paid[m.id] = true;
    if (economy && typeof economy.earn === "function") {
      total += economy.earn("mission_complete", m.label) || 0;
    }
  });
  return total;
}
