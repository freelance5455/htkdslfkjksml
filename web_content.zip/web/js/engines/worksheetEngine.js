/**
 * learnyZ Grade 12 — fillable Accounting journals & worksheets (CAPS / NSC style).
 * Generative tables: CRJ, CPJ, DJ, CJ, GJ, bank recon, VAT, control accounts, trial balance.
 * Double-entry validated; randomised blanks remain solvable.
 */
import { recipe, diagramForTopic } from "./diagramEngine.js";

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function money(n) {
  return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}
const VAT_RATE = 0.15;
function vatOf(excl) { return Math.round(excl * VAT_RATE); }
function exclFromIncl(incl) { return Math.round(incl / (1 + VAT_RATE)); }

const DEBTORS = ["N. Dlamini", "S. Botha", "K. Naidoo", "M. Petersen", "L. van Wyk", "T. Mokoena"];
const CREDITORS = ["Cape Traders", "Coastal Supplies", "Metro Wholesalers", "Prime Stock CC", "Office Direct"];
const MONTHS = ["Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"];

/** General Journal — year-end adjustments + routine entries */
function genJournal(grade = 12) {
  const capital = ri(15, 40) * 1000;
  const purchases = ri(8, 25) * 100;
  const sales = ri(10, 30) * 100;
  const rent = ri(5, 18) * 100;
  const dep = ri(12, 40) * 100;
  const bad = ri(4, 15) * 100;
  const rows = [
    { date: "01 " + choice(MONTHS), details: "Bank", fol: "B1", debit: money(capital), credit: "", blank: false },
    { date: "", details: "Capital", fol: "B2", debit: "", credit: money(capital), blank: false },
    { date: "03 " + choice(MONTHS), details: "Purchases", fol: "B3", debit: money(purchases), credit: "", blank: true, key: money(purchases), keyField: "debit" },
    { date: "", details: "Bank", fol: "B1", debit: "", credit: money(purchases), blank: true, key: money(purchases), keyField: "credit" },
    { date: "05 " + choice(MONTHS), details: "Bank", fol: "B1", debit: money(sales), credit: "", blank: false },
    { date: "", details: "Sales", fol: "B4", debit: "", credit: money(sales), blank: true, key: money(sales), keyField: "credit" },
    { date: "10 " + choice(MONTHS), details: "Rent expense", fol: "B5", debit: money(rent), credit: "", blank: true, key: money(rent), keyField: "debit" },
    { date: "", details: "Bank", fol: "B1", debit: "", credit: money(rent), blank: false },
    { date: "28 " + choice(MONTHS), details: "Depreciation", fol: "B6", debit: money(dep), credit: "", blank: true, key: money(dep), keyField: "debit" },
    { date: "", details: "Accumulated depreciation", fol: "B7", debit: "", credit: money(dep), blank: true, key: money(dep), keyField: "credit" },
    { date: "28 " + choice(MONTHS), details: "Bad debts", fol: "B8", debit: money(bad), credit: "", blank: true, key: money(bad), keyField: "debit" },
    { date: "", details: "Debtors control", fol: "B9", debit: "", credit: money(bad), blank: false }
  ];
  return {
    type: "journal",
    title: "General Journal — complete the blank cells",
    narrative: "Record the capital contribution, cash purchases, cash sales, rent payment, year-end depreciation and a bad debt write-off. Fill every shaded (blank) amount so that each entry balances.",
    cols: ["Date", "Details", "Fol", "Debit (R)", "Credit (R)"],
    rows,
    marks: 10,
    topic: "acc_books",
    recipe_id: "GJ_G12_01"
  };
}

/** Cash Receipts Journal — bank, sales, debtors, VAT, sundries */
function genCRJ(grade = 12) {
  const cashSaleIncl = [1150, 2300, 3450, 1725][ri(0, 3)];
  const cashSaleExcl = exclFromIncl(cashSaleIncl);
  const cashVat = cashSaleIncl - cashSaleExcl;
  const debtorPay = ri(8, 25) * 100;
  const capital = ri(10, 30) * 1000;
  const interest = ri(40, 180);
  const debtor = choice(DEBTORS);
  const day1 = ri(1, 8), day2 = ri(9, 15), day3 = ri(16, 22), day4 = ri(23, 28);
  const mon = choice(MONTHS);
  const bankTotal = cashSaleIncl + debtorPay + capital + interest;
  const rows = [
    { date: `${day1} ${mon}`, details: "Cash sales", doc: "CR" + ri(100, 199), bank: money(cashSaleIncl), sales: money(cashSaleExcl), debtors: "", sundries: "", sundryAcc: "", blank: true, key: money(cashSaleExcl), keyField: "sales" },
    { date: `${day2} ${mon}`, details: debtor, doc: "R" + ri(200, 299), bank: money(debtorPay), sales: "", debtors: money(debtorPay), sundries: "", sundryAcc: "", blank: true, key: money(debtorPay), keyField: "debtors" },
    { date: `${day3} ${mon}`, details: "Capital", doc: "R" + ri(300, 399), bank: money(capital), sales: "", debtors: "", sundries: money(capital), sundryAcc: "Capital", blank: false },
    { date: `${day4} ${mon}`, details: "Interest income", doc: "BS", bank: money(interest), sales: "", debtors: "", sundries: money(interest), sundryAcc: "Interest income", blank: true, key: money(interest), keyField: "sundries" }
  ];
  return {
    type: "journal_crj",
    title: "Cash Receipts Journal — complete missing amounts",
    narrative: `VAT rate 15%. Cash sales inclusive R${money(cashSaleIncl)} (enter exclusive sales). Debtor receipt and interest must be allocated to the correct columns. Calculate the Bank total.`,
    cols: ["Date", "Details", "Doc", "Bank", "Sales", "Debtors control", "Sundries", "Sundry account"],
    rows,
    totals: { bank: money(bankTotal), sales: money(cashSaleExcl), debtors: money(debtorPay), sundries: money(capital + interest) },
    vatNote: `Output VAT on cash sales = R${money(cashVat)} (often shown in a separate VAT column in full CRJ).`,
    marks: 12,
    topic: "acc_books",
    recipe_id: "CRJ_G12_01"
  };
}

/** Cash Payments Journal */
function genCPJ(grade = 12) {
  const stockExcl = ri(15, 40) * 100;
  const stockVat = vatOf(stockExcl);
  const stockIncl = stockExcl + stockVat;
  const wages = ri(40, 90) * 100;
  const creditorPay = ri(12, 35) * 100;
  const drawings = ri(5, 20) * 100;
  const rent = ri(8, 18) * 100;
  const creditor = choice(CREDITORS);
  const mon = choice(MONTHS);
  const bankTotal = stockIncl + wages + creditorPay + drawings + rent;
  const rows = [
    { date: `02 ${mon}`, details: "Trading stock (cash)", chq: "EFT" + ri(10, 99), bank: money(stockIncl), creditors: "", stock: money(stockExcl), wages: "", sundries: money(stockVat), sundryAcc: "Input VAT", blank: true, key: money(stockExcl), keyField: "stock" },
    { date: `05 ${mon}`, details: "Wages", chq: "EFT" + ri(100, 199), bank: money(wages), creditors: "", stock: "", wages: money(wages), sundries: "", sundryAcc: "", blank: false },
    { date: `12 ${mon}`, details: creditor, chq: "EFT" + ri(200, 299), bank: money(creditorPay), creditors: money(creditorPay), stock: "", wages: "", sundries: "", sundryAcc: "", blank: true, key: money(creditorPay), keyField: "creditors" },
    { date: `18 ${mon}`, details: "Drawings", chq: "EFT" + ri(300, 399), bank: money(drawings), creditors: "", stock: "", wages: "", sundries: money(drawings), sundryAcc: "Drawings", blank: true, key: money(drawings), keyField: "sundries" },
    { date: `25 ${mon}`, details: "Rent expense", chq: "EFT" + ri(400, 499), bank: money(rent), creditors: "", stock: "", wages: "", sundries: money(rent), sundryAcc: "Rent expense", blank: false }
  ];
  return {
    type: "journal_cpj",
    title: "Cash Payments Journal — complete missing columns",
    narrative: `Complete the CPJ. Stock purchase is VAT-inclusive R${money(stockIncl)} (15% VAT). Allocate stock (exclusive), Input VAT in sundries, creditor payment and drawings.`,
    cols: ["Date", "Details", "Chq/EFT", "Bank", "Creditors control", "Trading stock", "Wages", "Sundries", "Sundry account"],
    rows,
    totals: { bank: money(bankTotal), creditors: money(creditorPay), stock: money(stockExcl), wages: money(wages) },
    marks: 12,
    topic: "acc_books",
    recipe_id: "CPJ_G12_01"
  };
}

/** Debtors Journal — credit sales + VAT */
function genDJ(grade = 12) {
  const mon = choice(MONTHS);
  const items = [];
  let totExcl = 0, totVat = 0, totIncl = 0;
  for (let i = 0; i < 3; i++) {
    const excl = ri(8, 25) * 100;
    const vat = vatOf(excl);
    const incl = excl + vat;
    totExcl += excl; totVat += vat; totIncl += incl;
    const debtor = DEBTORS[i % DEBTORS.length];
    items.push({
      date: `${ri(1, 28)} ${mon}`,
      debtor,
      inv: "INV" + (400 + i),
      sales: money(excl),
      vat: money(vat),
      control: money(incl),
      blank: i !== 0,
      key: money(excl),
      keyField: "sales"
    });
  }
  return {
    type: "journal_dj",
    title: "Debtors Journal — calculate exclusive sales and VAT",
    narrative: "Credit sales are given inclusive of 15% VAT in the Debtors control column for blank rows (or calculate exclusive and VAT). Complete Sales, Output VAT and Debtors control. Total the journal.",
    cols: ["Date", "Debtor", "Invoice", "Sales (excl.)", "Output VAT", "Debtors control"],
    rows: items.map((r, i) => ({
      date: r.date,
      details: r.debtor,
      doc: r.inv,
      sales: i === 0 ? r.sales : "",
      vat: i === 0 ? r.vat : "",
      control: r.control,
      blank: i !== 0,
      key: r.sales,
      keyField: "sales",
      keys: { sales: r.sales, vat: r.vat, control: r.control }
    })),
    totals: { sales: money(totExcl), vat: money(totVat), control: money(totIncl) },
    marks: 10,
    topic: "acc_debtors",
    recipe_id: "DJ_G12_01"
  };
}

/** Creditors Journal */
function genCJ(grade = 12) {
  const mon = choice(MONTHS);
  const excl = ri(20, 50) * 100;
  const vat = vatOf(excl);
  const incl = excl + vat;
  const assetExcl = ri(10, 30) * 100;
  const assetVat = vatOf(assetExcl);
  const assetIncl = assetExcl + assetVat;
  const creditor1 = CREDITORS[0], creditor2 = CREDITORS[1];
  return {
    type: "journal_cj",
    title: "Creditors Journal — stock and sundry on credit",
    narrative: `Complete the Creditors Journal. Invoice 1: trading stock exclusive R${money(excl)} + VAT. Invoice 2: equipment exclusive R${money(assetExcl)} + VAT (sundry).`,
    cols: ["Date", "Creditor", "Invoice", "Creditors control", "Trading stock", "Input VAT", "Sundries", "Sundry account"],
    rows: [
      { date: `04 ${mon}`, details: creditor1, doc: "SI" + ri(50, 99), control: money(incl), stock: money(excl), vat: money(vat), sundries: "", sundryAcc: "", blank: true, key: money(excl), keyField: "stock" },
      { date: `11 ${mon}`, details: creditor2, doc: "SI" + ri(100, 149), control: money(assetIncl), stock: "", vat: money(assetVat), sundries: money(assetExcl), sundryAcc: "Equipment", blank: true, key: money(assetExcl), keyField: "sundries" }
    ],
    totals: { control: money(incl + assetIncl), stock: money(excl), vat: money(vat + assetVat), sundries: money(assetExcl) },
    marks: 10,
    topic: "acc_books",
    recipe_id: "CJ_G12_01"
  };
}

function genTAccount(grade = 12) {
  const open = ri(20, 50) * 100;
  const sales = ri(8, 20) * 100;
  const purch = ri(5, 15) * 100;
  const rent = ri(3, 9) * 100;
  const bal = open + sales - purch - rent;
  return {
    type: "t_account",
    title: "Bank account — complete missing amounts",
    narrative: "Complete the Bank T-account. Opening balance and rent are given. Calculate sales and purchases postings and the closing balance.",
    account: "Bank",
    debit: [
      { label: "Balance b/d", amount: money(open), blank: false },
      { label: "Sales", amount: money(sales), blank: true, key: money(sales) }
    ],
    credit: [
      { label: "Purchases", amount: money(purch), blank: true, key: money(purch) },
      { label: "Rent", amount: money(rent), blank: false }
    ],
    closing: money(bal),
    marks: 5,
    topic: "acc_ledger",
    recipe_id: "LEDGER_WORKSHEET_G12_01"
  };
}

function genDebtorsControl(grade = 12) {
  const open = ri(40, 90) * 100;
  const creditSales = ri(50, 120) * 100;
  const receipts = ri(30, 80) * 100;
  const returns = ri(5, 20) * 100;
  const bad = ri(3, 12) * 100;
  const close = open + creditSales - receipts - returns - bad;
  return {
    type: "t_account",
    title: "Debtors control — complete the account",
    narrative: "Reconstruct Debtors control. Opening balance and credit sales are on the debit side; receipts, returns and bad debts on the credit side. Find the closing balance.",
    account: "Debtors control",
    debit: [
      { label: "Balance b/d", amount: money(open), blank: false },
      { label: "Sales (DJ)", amount: money(creditSales), blank: true, key: money(creditSales) }
    ],
    credit: [
      { label: "Bank (CRJ)", amount: money(receipts), blank: false },
      { label: "Sales returns", amount: money(returns), blank: true, key: money(returns) },
      { label: "Bad debts", amount: money(bad), blank: false },
      { label: "Balance c/d", amount: money(close), blank: true, key: money(close) }
    ],
    closing: money(close),
    marks: 8,
    topic: "acc_debtors",
    recipe_id: "ACC_DEBTORS_CONTROL_01"
  };
}

function genTrialBalance(grade = 12) {
  const rows = [
    { account: "Bank", debit: money(25000), credit: "", blank: false },
    { account: "Capital", debit: "", credit: money(40000), blank: false },
    { account: "Purchases", debit: money(15000), credit: "", blank: true, key: money(15000), keyField: "debit" },
    { account: "Sales", debit: "", credit: money(18000), blank: false },
    { account: "Rent expense", debit: money(4000), credit: "", blank: true, key: money(4000), keyField: "debit" },
    { account: "Drawings", debit: money(8000), credit: "", blank: false },
    { account: "Creditors control", debit: "", credit: money(6000), blank: true, key: money(6000), keyField: "credit" },
    { account: "Trading stock", debit: money(12000), credit: "", blank: false }
  ];
  return {
    type: "trial_balance",
    title: "Trial balance — complete missing balances",
    narrative: "Complete the trial balance so that total debits equal total credits. Classify each account correctly.",
    cols: ["Account", "Debit (R)", "Credit (R)"],
    rows,
    totals: { debit: money(25000 + 15000 + 4000 + 8000 + 12000), credit: money(40000 + 18000 + 6000) },
    marks: 8,
    topic: "acc_ledger",
    recipe_id: "ACC_TRIAL_BALANCE_01"
  };
}

function genBankRecon(grade = 12) {
  const stmt = ri(80, 180) * 100;
  const od = ri(8, 25) * 100;
  const oc1 = ri(5, 15) * 100;
  const oc2 = ri(4, 12) * 100;
  const charges = ri(50, 150);
  const interest = ri(30, 120);
  const bookBefore = stmt + od - oc1 - oc2;
  const bookAfter = bookBefore - charges + interest;
  return {
    type: "bank_recon",
    title: "Bank reconciliation statement",
    narrative: `Balance per bank statement: R${money(stmt)}.\nOutstanding deposit: R${money(od)}.\nOutstanding cheques: R${money(oc1)} and R${money(oc2)}.\nBank charges on statement not in cash book: R${money(charges)}.\nInterest income on statement not in cash book: R${money(interest)}.\n\nUpdate the cash book, then complete the reconciliation.`,
    lines: [
      { label: "Balance per bank statement", amount: money(stmt), blank: false },
      { label: "Add: Outstanding deposit", amount: money(od), blank: true, key: money(od) },
      { label: "Less: Outstanding cheque 1", amount: money(oc1), blank: false },
      { label: "Less: Outstanding cheque 2", amount: money(oc2), blank: true, key: money(oc2) },
      { label: "Reconciled balance", amount: money(bookBefore), blank: true, key: money(bookBefore) }
    ],
    cashBookUpdate: {
      charges: money(charges),
      interest: money(interest),
      correctedBalance: money(bookAfter)
    },
    marks: 10,
    topic: "acc_bank",
    recipe_id: "BANK_RECON_G12_01"
  };
}

function genVATWorksheet(grade = 12) {
  const salesExcl = ri(40, 100) * 100;
  const purchExcl = ri(20, 60) * 100;
  const outVat = vatOf(salesExcl);
  const inVat = vatOf(purchExcl);
  const payable = outVat - inVat;
  return {
    type: "vat_worksheet",
    title: "VAT worksheet — calculate and reconcile",
    narrative: "Complete exclusive amounts, input VAT, output VAT and VAT payable/refundable. Rate 15%.",
    cols: ["Transaction", "Exclusive (R)", "Input VAT", "Output VAT", "Inclusive (R)"],
    rows: [
      { tx: "Credit sales", excl: money(salesExcl), input: "", output: money(outVat), incl: money(salesExcl + outVat), blank: true, key: money(outVat), keyField: "output" },
      { tx: "Credit purchases", excl: money(purchExcl), input: money(inVat), output: "", incl: money(purchExcl + inVat), blank: true, key: money(inVat), keyField: "input" }
    ],
    payable: money(payable),
    marks: 8,
    topic: "acc_vat",
    recipe_id: "VAT_WORKSHEET_G12_01"
  };
}

function genPaperStyle(grade = 12) {
  const A = ri(40, 90) * 1000;
  const L = ri(10, 35) * 1000;
  const OE = A - L;
  return {
    type: "paper_style",
    title: "QUESTION — Accounting equation & journals",
    narrative: "REQUIRED:",
    parts: [
      { id: "1.1", prompt: `1.1 Assets R${money(A)}; liabilities R${money(L)}. Calculate owner's equity.`, key: money(OE), hint: "OE = A − L" },
      { id: "1.2", prompt: "1.2 Owner contributes R5 000 cash. Effect on the equation?", key: "Assets +5000; Equity +5000", hint: "Both sides increase" },
      { id: "1.3", prompt: "1.3 Name the journal for cash purchases of stock.", key: "Cash payments journal", hint: "Money leaves the business" },
      { id: "1.4", prompt: "1.4 Name the journal for credit sales to customers.", key: "Debtors journal", hint: "Also called sales journal" }
    ],
    marks: 10,
    topic: "acc_concepts",
    recipe_id: "ACC_SOURCE_01"
  };
}

function genPaperVAT(grade = 12) {
  const excl = [200, 400, 500, 1000, 2500][ri(0, 4)];
  const vat = vatOf(excl);
  const incl = excl + vat;
  return {
    type: "paper_style",
    title: "QUESTION — VAT calculations",
    narrative: `A registered VAT vendor sold goods with a VAT-exclusive price of R${money(excl)}. VAT rate is 15%.\n\nREQUIRED:`,
    parts: [
      { id: "2.1", prompt: "2.1 Calculate the VAT amount.", key: money(vat), hint: "Exclusive × 15%." },
      { id: "2.2", prompt: "2.2 Calculate the VAT-inclusive selling price.", key: money(incl), hint: "Exclusive + VAT." },
      { id: "2.3", prompt: "2.3 Is this output VAT or input VAT for the vendor?", key: "Output VAT", hint: "VAT on sales." },
      { id: "2.4", prompt: `2.4 If input VAT for the same period is R${money(Math.round(vat * 0.6))}, calculate VAT payable.`, key: money(vat - Math.round(vat * 0.6)), hint: "Output − Input" }
    ],
    marks: 8,
    topic: "acc_vat",
    recipe_id: "VAT_FILL_01"
  };
}

function genPaperRecon(grade = 12) {
  const stmt = [7000, 8500, 9200, 12500][ri(0, 3)];
  const dep = [800, 1200, 1500, 2000][ri(0, 3)];
  const chq = [450, 600, 900, 1100][ri(0, 3)];
  const charges = ri(40, 120);
  const book = stmt + dep - chq;
  return {
    type: "paper_style",
    title: "QUESTION — Bank reconciliation",
    narrative: `Balance per bank statement on 31 March 2025: R${money(stmt)}.\nOutstanding deposit: R${money(dep)}.\nOutstanding cheque: R${money(chq)}.\nBank charges R${money(charges)} appear on the statement only.\n\nREQUIRED:`,
    parts: [
      { id: "3.1", prompt: "3.1 Calculate the balance per cash book before recording bank charges.", key: money(book), hint: "Statement + OD − OC." },
      { id: "3.2", prompt: "3.2 After recording bank charges, what is the corrected cash book balance?", key: money(book - charges), hint: "Charges decrease the cash book." },
      { id: "3.3", prompt: "3.3 What is an outstanding cheque?", key: "A cheque recorded in the cash book but not yet presented at the bank", hint: "Timing difference." },
      { id: "3.4", prompt: "3.4 Give one item that appears on the bank statement but is not a timing difference.", key: "Bank charges (or interest, debit order, direct deposit)", hint: "Must be entered in the cash book." }
    ],
    marks: 10,
    topic: "acc_bank",
    recipe_id: "ACC_BANK_RECON_01"
  };
}

function genMatchDefinitions(subjectId = "accounting") {
  const DEF_BANKS = {
    accounting: [
      ["Assets = Owner's equity + Liabilities", "Accounting equation"],
      ["Journal for cash received", "Cash receipts journal"],
      ["Journal for cash paid", "Cash payments journal"],
      ["Credit sales journal", "Debtors journal"],
      ["Credit purchases journal", "Creditors journal"],
      ["VAT on sales", "Output VAT"],
      ["VAT on purchases", "Input VAT"],
      ["Customers who owe the business", "Debtors"],
      ["Suppliers to whom the business owes", "Creditors"],
      ["Statement comparing cash book and bank statement", "Bank reconciliation"]
    ],
    life_sciences: [
      ["Basic unit of life", "Cell"],
      ["Site of photosynthesis", "Chloroplast"],
      ["Genetic material", "DNA"],
      ["Division producing gametes", "Meiosis"]
    ],
    geography: [
      ["Long-term weather patterns", "Climate"],
      ["Lines of equal height", "Contours"],
      ["Geographic Information System", "GIS"]
    ]
  };
  const key = DEF_BANKS[subjectId] ? subjectId : "accounting";
  const pool = DEF_BANKS[key] || DEF_BANKS.accounting;
  const picked = [];
  const used = new Set();
  while (picked.length < Math.min(6, pool.length)) {
    const i = ri(0, pool.length - 1);
    if (used.has(i)) continue;
    used.add(i);
    picked.push(pool[i]);
  }
  return {
    type: "match",
    title: "Match definitions",
    narrative: "Match each description to the correct term.",
    pairs: picked.map(([def, term]) => ({ left: def, right: term })),
    marks: picked.length * 2,
    topic: "acc_concepts"
  };
}

function genLabelDiagram(subjectId, topicId, grade = 12) {
  let diagram = null;
  try {
    diagram = diagramForTopic(topicId || "acc_concepts", grade) || recipe("accounting_equation", grade);
  } catch (_) {
    diagram = recipe("accounting_equation", grade, { assets: 12000, liabilities: 4000, equity: 8000 });
  }
  return {
    type: "label_diagram",
    title: "Label / interpret the diagram",
    narrative: "Use the diagram to answer the prompts.",
    diagram,
    prompts: [
      { id: "a", prompt: "Name the three elements of the accounting equation.", key: "Assets, owner's equity, liabilities" },
      { id: "b", prompt: "If assets increase and equity is unchanged, what happens to liabilities?", key: "Liabilities increase" }
    ],
    marks: 4,
    topic: topicId || "acc_concepts"
  };
}

export class WorksheetEngine {
  constructor(subjectId = "accounting", grade = 12) {
    this.subjectId = subjectId || "accounting";
    this.grade = grade || 12;
  }

  generate(topicId = null, mode = null) {
    if (mode === "match" || topicId === "definitions") {
      return genMatchDefinitions(this.subjectId);
    }
    if (mode === "paper" || (this.subjectId === "accounting" && mode === "exam")) {
      return choice([genPaperStyle, genPaperVAT, genPaperRecon, genCRJ, genBankRecon])(this.grade);
    }
    const tid = topicId ? String(topicId) : null;
    if (tid && /^(ls_|ns_|geo_|tech_)/.test(tid)) {
      return genLabelDiagram(this.subjectId, tid, this.grade);
    }
    if (this.subjectId === "accounting" || (tid && tid.startsWith("acc_"))) {
      const t = tid || choice(["acc_books", "acc_ledger", "acc_bank", "acc_concepts", "acc_vat", "acc_debtors"]);
      if (t === "acc_books") return choice([genCRJ, genCPJ, genCJ, genJournal])(this.grade);
      if (t === "acc_inventory") return choice([genCJ, genCPJ])(this.grade);
      if (t === "acc_vat") return choice([genVATWorksheet, genPaperVAT, genDJ])(this.grade);
      if (t === "acc_ledger") return choice([genTAccount, genTrialBalance, genJournal])(this.grade);
      if (t === "acc_debtors") return choice([genDJ, genDebtorsControl, genCRJ])(this.grade);
      if (t === "acc_bank") return choice([genBankRecon, genPaperRecon, genCRJ])(this.grade);
      if (t === "acc_concepts" || t === "acc_financials" || t === "acc_analysis") {
        return choice([genPaperStyle, genTrialBalance, genJournal])(this.grade);
      }
      if (t === "acc_costing") return choice([genCPJ, genPaperStyle])(this.grade);
      return choice([genJournal, genCRJ, genBankRecon, genDJ])(this.grade);
    }
    if (Math.random() < 0.35) return genMatchDefinitions(this.subjectId);
    return genLabelDiagram(this.subjectId, tid, this.grade);
  }

  generateMatch() { return this.generate(null, "match"); }
  generatePaper() { return this.generate(null, "paper"); }

  /** List fillable modes for UI chips */
  modes() {
    if (this.subjectId === "accounting") {
      return [
        { id: "crj", label: "Cash receipts journal" },
        { id: "cpj", label: "Cash payments journal" },
        { id: "dj", label: "Debtors journal" },
        { id: "cj", label: "Creditors journal" },
        { id: "gj", label: "General journal" },
        { id: "bank", label: "Bank reconciliation" },
        { id: "vat", label: "VAT worksheet" },
        { id: "control", label: "Debtors control" },
        { id: "trial", label: "Trial balance" },
        { id: "paper", label: "Paper-style" }
      ];
    }
    return [
      { id: "match", label: "Match definitions" },
      { id: "diagram", label: "Label diagram" },
      { id: "paper", label: "Paper-style" }
    ];
  }

  generateMode(modeId) {
    const map = {
      crj: genCRJ, cpj: genCPJ, dj: genDJ, cj: genCJ, gj: genJournal,
      bank: genBankRecon, vat: genVATWorksheet, control: genDebtorsControl,
      trial: genTrialBalance, paper: () => choice([genPaperStyle, genPaperVAT, genPaperRecon])(this.grade),
      match: () => genMatchDefinitions(this.subjectId),
      diagram: () => genLabelDiagram(this.subjectId, null, this.grade)
    };
    const fn = map[modeId] || (() => this.generate());
    return fn(this.grade);
  }
}

export function isWorksheetTopic(id) {
  return /^(acc_|ls_|ns_|tech_|geo_)/.test(String(id || ""));
}
