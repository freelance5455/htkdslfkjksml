/**
 * Learnly Grade 10 — Mathematical Literacy generative recipes
 * CAPS-aligned practice from percentage, finance, measurement, maps, data, probability templates.
 * Offline, randomised numerical values; answers computed (not fixed past-paper text).
 */

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function round2(n) { return Math.round(n * 100) / 100; }
function money(n) {
  const v = round2(n);
  const s = v.toFixed(2);
  // South African style: space as thousands separator where useful
  const [w, d] = s.split(".");
  const withSpaces = w.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return d === "00" ? `R${withSpaces}` : `R${withSpaces}.${d}`;
}
function pct(n) { return `${round2(n)}%`; }
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { const t = b; b = a % b; a = t; } return a || 1; }

const NAMES = ["Thabo", "Lerato", "Sipho", "Aisha", "Johan", "Nomsa", "Pieter", "Zanele", "Fatima", "David"];
const ITEMS = ["jacket", "school uniform", "microwave", "laptop", "refrigerator", "phone", "bicycle", "textbook set"];
const PRODUCTS = ["rice", "flour", "sugar", "cooking oil", "maize meal", "coffee"];

/** Format answer that accepts common variants */
function ans(...variants) {
  return variants.map(String);
}

// ─── Percentage family ───────────────────────────────────────────────────────
function genPercentage() {
  const kind = choice(["of", "increase", "decrease", "reverse", "vat_add", "vat_remove", "discount"]);
  if (kind === "of") {
    const amount = ri(20, 80) * 50; // 1000–4000
    const p = choice([10, 12, 15, 18, 20, 25]);
    const a = round2(amount * p / 100);
    return {
      prompt: `A ${choice(ITEMS)} costs ${money(amount)}. Calculate ${p}% of the cost.`,
      answer: money(a),
      answers: ans(money(a), String(a), `R${a}`),
      explanation: `${p}% of ${amount} = ${amount} × ${p}/100 = ${a}.`,
      topic: "ml_numbers",
      subtopic: "percentage",
      marks: 2
    };
  }
  if (kind === "increase") {
    const old = ri(10, 40) * 100;
    const p = choice([8, 10, 12, 15, 20]);
    const neu = round2(old * (1 + p / 100));
    return {
      prompt: `The price of ${choice(ITEMS)} increases from ${money(old)} to ${money(neu)}. Calculate the percentage increase.`,
      answer: pct(p),
      answers: ans(pct(p), String(p), `${p}%`),
      explanation: `Increase = ${neu - old}. Percentage = (${neu - old})/${old} × 100 = ${p}%.`,
      topic: "ml_numbers",
      subtopic: "percentage_increase",
      marks: 3
    };
  }
  if (kind === "decrease") {
    const original = ri(8, 30) * 100;
    const p = choice([10, 15, 20, 25]);
    const sale = round2(original * (1 - p / 100));
    return {
      prompt: `A ${choice(ITEMS)} costs ${money(original)} and is discounted by ${p}%. Calculate the sale price.`,
      answer: money(sale),
      answers: ans(money(sale), String(sale)),
      explanation: `Discount = ${original} × ${p}/100. Sale price = ${original} - discount = ${sale}.`,
      topic: "ml_finance",
      subtopic: "discount",
      marks: 2
    };
  }
  if (kind === "reverse") {
    const p = choice([10, 15, 20, 25]);
    const original = ri(20, 50) * 100;
    const neu = round2(original * (1 + p / 100));
    return {
      prompt: `After a ${p}% increase, a monthly amount becomes ${money(neu)}. Calculate the original amount.`,
      answer: money(original),
      answers: ans(money(original), String(original)),
      explanation: `Original = ${neu} ÷ (1 + ${p}/100) = ${original}.`,
      topic: "ml_numbers",
      subtopic: "reverse_percentage",
      marks: 3
    };
  }
  if (kind === "vat_add") {
    const excl = ri(10, 40) * 100;
    const incl = round2(excl * 1.15);
    return {
      prompt: `An item costs ${money(excl)} excluding VAT. Calculate the price including 15% VAT.`,
      answer: money(incl),
      answers: ans(money(incl), String(incl)),
      explanation: `VAT = ${excl} × 0.15. Inclusive = ${excl} × 1.15 = ${incl}.`,
      topic: "ml_finance",
      subtopic: "vat",
      marks: 2,
      diagram: {
        type: "table_diagram",
        title: "VAT 15%",
        cols: ["Step", "Amount"],
        rows: [["Excl. price", money(excl)], ["× 1.15", money(incl)], ["VAT (×0.15)", money(round2(excl * 0.15))]]
      }
    };
  }
  if (kind === "vat_remove") {
    const excl = ri(10, 40) * 100;
    const incl = round2(excl * 1.15);
    return {
      prompt: `A product costs ${money(incl)} including 15% VAT. Calculate the price before VAT.`,
      answer: money(excl),
      answers: ans(money(excl), String(excl)),
      explanation: `Exclusive = ${incl} ÷ 1.15 = ${excl}.`,
      topic: "ml_finance",
      subtopic: "vat",
      marks: 2,
      diagram: {
        type: "table_diagram",
        title: "Remove VAT 15%",
        cols: ["Step", "Amount"],
        rows: [["Incl. price", money(incl)], ["÷ 1.15", money(excl)], ["VAT amount", money(round2(incl - excl))]]
      }
    };
  }
  // discount comparison default
  const price = ri(20, 50) * 100;
  const p = choice([15, 18, 20, 25]);
  const sale = round2(price * (1 - p / 100));
  return {
    prompt: `A television costs ${money(price)} and is discounted by ${p}%. Calculate the sale price.`,
    answer: money(sale),
    answers: ans(money(sale), String(sale)),
    explanation: `${price} × (1 - ${p}/100) = ${sale}.`,
    topic: "ml_finance",
    subtopic: "discount",
    marks: 2
  };
}

// ─── Finance / budget ────────────────────────────────────────────────────────
function genFinance() {
  const kind = choice(["expenditure", "remaining", "budget_pct", "interest", "loan", "profit", "salary_net", "simple_budget"]);
  const name = choice(NAMES);
  if (kind === "expenditure") {
    const rent = ri(20, 45) * 100;
    const food = ri(12, 30) * 100;
    const transport = ri(8, 20) * 100;
    const elec = ri(5, 12) * 100;
    const total = rent + food + transport + elec;
    return {
      prompt: `${name} has monthly expenses:\nRent: ${money(rent)}\nFood: ${money(food)}\nTransport: ${money(transport)}\nElectricity: ${money(elec)}\nCalculate the total expenditure.`,
      answer: money(total),
      answers: ans(money(total), String(total)),
      explanation: `${rent} + ${food} + ${transport} + ${elec} = ${total}.`,
      topic: "ml_finance",
      subtopic: "budget",
      marks: 3,
      diagram: {
        type: "budget_bars",
        title: `${name}'s monthly expenses`,
        items: [
          { label: "Rent", value: rent },
          { label: "Food", value: food },
          { label: "Transport", value: transport },
          { label: "Electricity", value: elec }
        ]
      }
    };
  }
  if (kind === "remaining") {
    const income = ri(80, 200) * 100;
    const spend = ri(40, Math.floor(income * 0.85 / 100) * 100);
    const rem = income - spend;
    return {
      prompt: `${name} has ${money(income)} available for the month and spends ${money(spend)}. How much remains?`,
      answer: money(rem),
      answers: ans(money(rem), String(rem)),
      explanation: `${income} - ${spend} = ${rem}.`,
      topic: "ml_finance",
      subtopic: "budget",
      marks: 2,
      diagram: {
        type: "pie_chart",
        title: "Income use",
        labels: ["Spent", "Remaining"],
        values: [spend, rem],
        colors: ["#F59E0B", "#10B981"]
      }
    };
  }
  if (kind === "budget_pct") {
    const income = ri(80, 200) * 100;
    const p = choice([20, 25, 30, 35]);
    const rent = round2(income * p / 100);
    return {
      prompt: `${name} earns ${money(income)} per month and spends ${money(rent)} on rent. What percentage of the income is spent on rent?`,
      answer: pct(p),
      answers: ans(pct(p), String(p), `${p}%`),
      explanation: `(${rent}/${income}) × 100 = ${p}%.`,
      topic: "ml_finance",
      subtopic: "budget_percentage",
      marks: 3
    };
  }
  if (kind === "interest") {
    const P = ri(50, 200) * 100;
    const r = choice([5, 6, 7, 8, 9, 10]);
    const t = choice([2, 3, 4, 5]);
    const I = round2(P * r / 100 * t);
    return {
      prompt: `${money(P)} is invested at ${r}% simple interest per year for ${t} years. Calculate the interest earned.`,
      answer: money(I),
      answers: ans(money(I), String(I)),
      explanation: `I = P × r × t = ${P} × ${r}/100 × ${t} = ${I}.`,
      topic: "ml_finance",
      subtopic: "simple_interest",
      marks: 3
    };
  }
  if (kind === "loan") {
    const loan = ri(100, 400) * 100;
    const months = choice([12, 18, 24, 36]);
    const monthly = ri(8, 20) * 50;
    const total = monthly * months;
    const interest = total - loan;
    const sub = choice(["total", "interest"]);
    if (sub === "total") {
      return {
        prompt: `A person borrows ${money(loan)} and repays ${money(monthly)} per month for ${months} months. Calculate the total repayment.`,
        answer: money(total),
        answers: ans(money(total), String(total)),
        explanation: `${monthly} × ${months} = ${total}.`,
        topic: "ml_finance",
        subtopic: "loans",
        marks: 2
      };
    }
    return {
      prompt: `A person borrows ${money(loan)} and repays ${money(total)} in total. Calculate the interest paid.`,
      answer: money(interest),
      answers: ans(money(interest), String(interest)),
      explanation: `Interest = total repayment - loan = ${total} - ${loan} = ${interest}.`,
      topic: "ml_finance",
      subtopic: "loans",
      marks: 2
    };
  }
  if (kind === "profit") {
    const cost = ri(20, 80) * 50;
    const sell = round2(cost * choice([1.15, 1.2, 1.25, 1.3]));
    const profit = round2(sell - cost);
    const pp = round2(profit / cost * 100);
    if (Math.random() < 0.5) {
      return {
        prompt: `A shop buys an item for ${money(cost)} and sells it for ${money(sell)}. Calculate the profit.`,
        answer: money(profit),
        answers: ans(money(profit), String(profit)),
        explanation: `${sell} - ${cost} = ${profit}.`,
        topic: "ml_finance",
        subtopic: "profit",
        marks: 2
      };
    }
    return {
      prompt: `A business buys a product for ${money(cost)} and sells it for ${money(sell)}. Calculate the profit percentage (on cost).`,
      answer: pct(pp),
      answers: ans(pct(pp), String(pp)),
      explanation: `Profit = ${profit}. Profit % = ${profit}/${cost} × 100 = ${pp}%.`,
      topic: "ml_finance",
      subtopic: "profit_percentage",
      marks: 3
    };
  }
  if (kind === "salary_net") {
    const gross = ri(100, 250) * 100;
    const ded = ri(15, 40) * 100;
    const net = gross - ded;
    return {
      prompt: `Gross salary is ${money(gross)}; total deductions are ${money(ded)}. Calculate the net pay.`,
      answer: money(net),
      answers: ans(money(net), String(net)),
      explanation: `${gross} - ${ded} = ${net}.`,
      topic: "ml_finance",
      subtopic: "salary",
      marks: 2
    };
  }
  // simple multi-step budget
  const income = ri(120, 200) * 100;
  const rentP = choice([25, 30, 35]);
  const food = ri(20, 40) * 100;
  const transport = ri(10, 25) * 100;
  const housing = round2(income * rentP / 100);
  const totalExp = housing + food + transport;
  const remain = income - totalExp;
  return {
    prompt: `A family earns ${money(income)} per month. They spend ${rentP}% on housing, ${money(food)} on food and ${money(transport)} on transport.\nCalculate:\n1. Housing cost\n2. Total of these three expenses\n3. Money remaining`,
    answer: `1. ${money(housing)}  2. ${money(totalExp)}  3. ${money(remain)}`,
    answers: ans(money(housing), String(housing), money(totalExp), money(remain)),
    explanation: `Housing = ${income} × ${rentP}/100 = ${housing}. Total = ${housing}+${food}+${transport} = ${totalExp}. Remaining = ${income}-${totalExp} = ${remain}.`,
    topic: "ml_finance",
    subtopic: "multi_step_budget",
    marks: 6,
    multi_part: true
  };
}

// ─── Ratio & rate ────────────────────────────────────────────────────────────
function genRatioRate() {
  const kind = choice(["simplify", "share", "recipe", "unit_price", "fuel", "speed"]);
  if (kind === "simplify") {
    const g = ri(2, 8);
    const a = g * ri(2, 9);
    const b = g * ri(2, 9);
    const d = gcd(a, b);
    return {
      prompt: `Simplify the ratio ${a}:${b}.`,
      answer: `${a / d}:${b / d}`,
      answers: ans(`${a / d}:${b / d}`, `${a / d} : ${b / d}`),
      explanation: `Divide both by ${d}.`,
      topic: "ml_numbers",
      subtopic: "ratio",
      marks: 2
    };
  }
  if (kind === "share") {
    const a = ri(2, 5);
    const b = ri(2, 5);
    const total = (a + b) * ri(100, 400);
    const part = total / (a + b);
    return {
      prompt: `${money(total)} is divided between two people in the ratio ${a}:${b}. Calculate each person's share.`,
      answer: `${money(part * a)} and ${money(part * b)}`,
      answers: ans(money(part * a), money(part * b), String(part * a), String(part * b)),
      explanation: `Parts = ${a + b}. One part = ${total}/${a + b} = ${part}. Shares = ${part * a} and ${part * b}.`,
      topic: "ml_numbers",
      subtopic: "ratio_sharing",
      marks: 3
    };
  }
  if (kind === "recipe") {
    const flour = choice([2, 3, 4, 5]);
    const milk = choice([2, 3, 4, 5]);
    const newFlour = flour * choice([2, 3, 4]);
    const newMilk = (newFlour / flour) * milk;
    return {
      prompt: `A recipe uses ${flour} cups of flour for every ${milk} cups of milk. How many cups of milk are needed for ${newFlour} cups of flour?`,
      answer: `${newMilk} cups`,
      answers: ans(String(newMilk), `${newMilk} cups`),
      explanation: `Scale factor = ${newFlour}/${flour}. Milk = ${milk} × ${newFlour}/${flour} = ${newMilk}.`,
      topic: "ml_numbers",
      subtopic: "proportion",
      marks: 2
    };
  }
  if (kind === "unit_price") {
    const n = choice([4, 5, 6, 8, 10, 12]);
    const unit = ri(8, 25);
    const total = n * unit;
    return {
      prompt: `${n} notebooks cost ${money(total)}. Calculate the price per notebook.`,
      answer: money(unit),
      answers: ans(money(unit), String(unit)),
      explanation: `${total} ÷ ${n} = ${unit}.`,
      topic: "ml_numbers",
      subtopic: "unit_rate",
      marks: 2
    };
  }
  if (kind === "fuel") {
    const dist = choice([240, 360, 480, 540, 600, 720]);
    const rate = choice([6, 7, 7.5, 8, 9, 10]); // L/100 km
    const litres = round2(dist / 100 * rate);
    const price = choice([22.5, 23.8, 24.5, 25.2]);
    const cost = round2(litres * price);
    if (Math.random() < 0.5) {
      return {
        prompt: `A vehicle uses ${rate} L of petrol per 100 km. How much fuel is required for a ${dist} km journey?`,
        answer: `${litres} L`,
        answers: ans(String(litres), `${litres} L`),
        explanation: `Fuel = ${dist}/100 × ${rate} = ${litres} L.`,
        topic: "ml_measurement",
        subtopic: "fuel",
        marks: 2
      };
    }
    return {
      prompt: `A vehicle uses ${rate} L/100 km. Petrol costs ${money(price)}/L. Calculate the fuel cost for a ${dist} km trip.`,
      answer: money(cost),
      answers: ans(money(cost), String(cost)),
      explanation: `Litres = ${litres}. Cost = ${litres} × ${price} = ${cost}.`,
      topic: "ml_measurement",
      subtopic: "fuel_cost",
      marks: 3
    };
  }
  // speed
  const dist = choice([180, 240, 300, 360, 450]);
  const hours = choice([2, 2.5, 3, 3.5, 4, 4.5, 5]);
  const speed = round2(dist / hours);
  return {
    prompt: `A car travels ${dist} km in ${hours} hours. Calculate its average speed in km/h.`,
    answer: `${speed} km/h`,
    answers: ans(String(speed), `${speed} km/h`),
    explanation: `Speed = distance ÷ time = ${dist}/${hours} = ${speed} km/h.`,
    topic: "ml_numbers",
    subtopic: "speed",
    marks: 2
  };
}

// ─── Measurement ─────────────────────────────────────────────────────────────
function genMeasurement() {
  const kind = choice([
    "area_rect", "perimeter_rect", "area_square", "perimeter_square",
    "area_triangle", "circumference", "area_circle", "volume_box",
    "convert_len", "convert_cap", "flooring", "fencing"
  ]);
  if (kind === "area_rect") {
    const L = ri(4, 18), W = ri(3, 12);
    const a = round2(L * W);
    return {
      prompt: `A rectangular classroom is ${L} m long and ${W} m wide. Calculate its floor area.`,
      answer: `${a} m²`,
      answers: ans(`${a} m²`, String(a)),
      explanation: `Area of rectangle = length × width = ${L} × ${W} = ${a} m².`,
      topic: "ml_measurement",
      subtopic: "area_rectangle",
      marks: 2,
      diagram: { type: "shape_rect", L, W, label: "Classroom" }
    };
  }
  if (kind === "perimeter_rect") {
    const L = ri(5, 20), W = ri(3, 12);
    const p = round2(2 * (L + W));
    return {
      prompt: `A rectangular garden is ${L} m by ${W} m. How much fencing is needed for the perimeter?`,
      answer: `${p} m`,
      answers: ans(`${p} m`, String(p)),
      explanation: `P = 2(L + W) = 2(${L} + ${W}) = ${p} m.`,
      topic: "ml_measurement",
      subtopic: "perimeter",
      marks: 2,
      diagram: { type: "shape_rect", L, W, label: "Garden" }
    };
  }
  if (kind === "area_square") {
    const s = ri(4, 15);
    const a = s * s;
    return {
      prompt: `A square courtyard has side ${s} m. Calculate its area.`,
      answer: `${a} m²`,
      answers: ans(`${a} m²`, String(a)),
      explanation: `Area of square = side × side = ${s}² = ${a} m².`,
      topic: "ml_measurement",
      subtopic: "area_square",
      marks: 2,
      diagram: { type: "shape_rect", L: s, W: s, label: "Square" }
    };
  }
  if (kind === "perimeter_square") {
    const s = ri(5, 16);
    const p = 4 * s;
    return {
      prompt: `A square park has side ${s} m. Calculate the perimeter.`,
      answer: `${p} m`,
      answers: ans(`${p} m`, String(p)),
      explanation: `P = 4 × side = 4 × ${s} = ${p} m.`,
      topic: "ml_measurement",
      subtopic: "perimeter",
      marks: 2,
      diagram: { type: "shape_rect", L: s, W: s, label: "Square" }
    };
  }
  if (kind === "area_triangle") {
    const b = ri(6, 20), h = ri(4, 14);
    const a = round2(0.5 * b * h);
    return {
      prompt: `A triangular flower bed has base ${b} m and perpendicular height ${h} m. Calculate its area.`,
      answer: `${a} m²`,
      answers: ans(`${a} m²`, String(a)),
      explanation: `Area of triangle = ½ × base × height = ½ × ${b} × ${h} = ${a} m².`,
      topic: "ml_measurement",
      subtopic: "area_triangle",
      marks: 2,
      diagram: { type: "shape_triangle", base: b, height: h }
    };
  }
  if (kind === "circumference") {
    const d = choice([7, 14, 21, 10, 5]);
    const c = round2(3.142 * d);
    return {
      prompt: `A circular fountain has diameter ${d} m. Calculate the circumference. Use π ≈ 3,142.`,
      answer: `${c} m`,
      answers: ans(`${c} m`, String(c)),
      explanation: `C = π × diameter = 3,142 × ${d} = ${c} m.`,
      topic: "ml_measurement",
      subtopic: "circumference",
      marks: 2,
      diagram: { type: "shape_circle", r: d / 2, label: "Fountain" }
    };
  }
  if (kind === "area_circle") {
    const r = choice([3, 5, 7, 10, 14]);
    const a = round2(3.142 * r * r);
    return {
      prompt: `A circular lawn has radius ${r} m. Calculate its area. Use π ≈ 3,142.`,
      answer: `${a} m²`,
      answers: ans(`${a} m²`, String(a)),
      explanation: `Area = πr² = 3,142 × ${r}² = ${a} m².`,
      topic: "ml_measurement",
      subtopic: "area_circle",
      marks: 2,
      diagram: { type: "shape_circle", r, label: "Lawn" }
    };
  }
  if (kind === "volume_box") {
    const L = ri(2, 8), W = ri(2, 6), H = ri(1, 4);
    const v = round2(L * W * H);
    return {
      prompt: `A rectangular water tank is ${L} m long, ${W} m wide and ${H} m high. Calculate its volume.`,
      answer: `${v} m³`,
      answers: ans(`${v} m³`, String(v)),
      explanation: `Volume of rectangular prism = L × W × H = ${L}×${W}×${H} = ${v} m³.`,
      topic: "ml_measurement",
      subtopic: "volume",
      marks: 2,
      diagram: { type: "shape_box", L, W, H }
    };
  }
  if (kind === "convert_len") {
    const m = ri(2, 9);
    const cm = m * 100;
    return {
      prompt: `Convert ${m} m to centimetres.`,
      answer: `${cm} cm`,
      answers: ans(`${cm} cm`, String(cm)),
      explanation: `1 m = 100 cm, so ${m} m = ${cm} cm.`,
      topic: "ml_measurement",
      subtopic: "conversion",
      marks: 1
    };
  }
  if (kind === "convert_cap") {
    const L = ri(2, 8);
    const ml = L * 1000;
    return {
      prompt: `Convert ${L} litres to millilitres.`,
      answer: `${ml} ml`,
      answers: ans(`${ml} ml`, String(ml)),
      explanation: `1 litre = 1 000 ml, so ${L} L = ${ml} ml.`,
      topic: "ml_measurement",
      subtopic: "conversion",
      marks: 1
    };
  }
  if (kind === "fencing") {
    const L = ri(10, 30), W = ri(8, 20);
    const p = 2 * (L + W);
    const rate = choice([45, 55, 65, 80]);
    const cost = p * rate;
    return {
      prompt: `A rectangular field is ${L} m by ${W} m. Fencing costs ${money(rate)} per metre. Calculate the cost to fence the field.`,
      answer: money(cost),
      answers: ans(money(cost), String(cost)),
      explanation: `Perimeter = 2(${L}+${W}) = ${p} m. Cost = ${p} × ${rate} = ${cost}.`,
      topic: "ml_measurement",
      subtopic: "fencing",
      marks: 3,
      diagram: { type: "shape_rect", L, W, label: "Field" }
    };
  }
  // flooring default
  const area = ri(15, 40);
  const rate = choice([80, 95, 120, 150]);
  const waste = choice([5, 8, 10]);
  const withWaste = round2(area * (1 + waste / 100));
  return {
    prompt: `A room requires ${area} m² of flooring. An additional ${waste}% is bought for wastage. How many m² should be purchased?`,
    answer: `${withWaste} m²`,
    answers: ans(`${withWaste} m²`, String(withWaste)),
    explanation: `${area} × (1 + ${waste}/100) = ${withWaste} m².`,
    topic: "ml_measurement",
    subtopic: "flooring",
    marks: 2
  };
}

function genMaps() {
  const kind = choice(["map_to_actual", "actual_to_map", "trip_distance", "direction"]);
  if (kind === "map_to_actual") {
    const scale = choice([25000, 50000, 100000]);
    const cm = choice([3, 4, 4.5, 5, 6, 7, 8]);
    const actualCm = cm * scale;
    const km = actualCm / 100000; // cm → km
    return {
      prompt: `A map has a scale of 1:${scale.toLocaleString("en-ZA").replace(/,/g, " ")}. Two places are ${cm} cm apart on the map. Calculate the actual distance in kilometres.`,
      answer: `${km} km`,
      answers: ans(String(km), `${km} km`),
      explanation: `Actual = ${cm} × ${scale} cm = ${actualCm} cm = ${km} km.`,
      topic: "ml_maps",
      subtopic: "scale",
      marks: 3,
      diagram: {
        type: "scale_bar",
        title: `Scale 1 : ${scale.toLocaleString("en-ZA").replace(/,/g, " ")}`,
        ratio: scale,
        mapCm: cm,
        actualKm: km
      }
    };
  }
  if (kind === "actual_to_map") {
    const scale = choice([50000, 100000]);
    const km = choice([2, 4, 5, 8, 10, 15]);
    const mapCm = (km * 100000) / scale;
    return {
      prompt: `A road is ${km} km long. A map uses a scale of 1:${scale.toLocaleString("en-ZA").replace(/,/g, " ")}. How long will the road be on the map?`,
      answer: `${mapCm} cm`,
      answers: ans(String(mapCm), `${mapCm} cm`),
      explanation: `Map distance = (actual cm) ÷ scale = ${km * 100000}/${scale} = ${mapCm} cm.`,
      topic: "ml_maps",
      subtopic: "scale",
      marks: 3,
      diagram: {
        type: "scale_bar",
        title: `Scale 1 : ${scale.toLocaleString("en-ZA").replace(/,/g, " ")}`,
        ratio: scale,
        mapCm,
        actualKm: km
      }
    };
  }
  if (kind === "trip_distance") {
    const a = round2(ri(20, 80) / 10);
    const b = round2(ri(30, 100) / 10);
    return {
      prompt: `A taxi travels ${a} km from A to B and then ${b} km from B to C. Calculate the total distance travelled.`,
      answer: `${round2(a + b)} km`,
      answers: ans(String(round2(a + b)), `${round2(a + b)} km`),
      explanation: `${a} + ${b} = ${round2(a + b)} km.`,
      topic: "ml_maps",
      subtopic: "distance",
      marks: 2
    };
  }
  const dirs = [["north", "south"], ["south", "north"], ["east", "west"], ["west", "east"]];
  const [d1, d2] = choice(dirs);
  return {
    prompt: `The clinic is ${d1} of the school. In which direction is the school from the clinic?`,
    answer: d2.charAt(0).toUpperCase() + d2.slice(1),
    answers: ans(d2, d2.charAt(0).toUpperCase() + d2.slice(1)),
    explanation: `Opposite of ${d1} is ${d2}.`,
    topic: "ml_maps",
    subtopic: "direction",
    marks: 1
  };
}

// ─── Data & statistics ───────────────────────────────────────────────────────
function genData() {
  const kind = choice(["mean", "median", "mode", "range", "table"]);
  if (kind === "mean") {
    const n = choice([5, 6, 7]);
    const vals = Array.from({ length: n }, () => ri(8, 40));
    const sum = vals.reduce((a, b) => a + b, 0);
    const mean = round2(sum / n);
    return {
      prompt: `Calculate the mean of: ${vals.join(", ")}.`,
      answer: String(mean),
      answers: ans(String(mean)),
      explanation: `Sum = ${sum}. Mean = ${sum}/${n} = ${mean}.`,
      topic: "ml_data",
      subtopic: "mean",
      marks: 3,
      diagram: {
        type: "line_graph",
        title: "Data values",
        labels: vals.map((_, i) => String(i + 1)),
        values: vals
      }
    };
  }
  if (kind === "median") {
    const n = choice([5, 7]);
    let vals = Array.from({ length: n }, () => ri(10, 50));
    vals.sort((a, b) => a - b);
    const med = vals[Math.floor(n / 2)];
    return {
      prompt: `Determine the median of: ${vals.join(", ")}.`,
      answer: String(med),
      answers: ans(String(med)),
      explanation: `Ordered list; middle value is ${med}.`,
      topic: "ml_data",
      subtopic: "median",
      marks: 2,
      diagram: {
        type: "line_graph",
        title: "Ordered data",
        labels: vals.map((_, i) => String(i + 1)),
        values: vals
      }
    };
  }
  if (kind === "mode") {
    const mode = ri(5, 15);
    const vals = [mode, mode, mode, ri(3, 20), ri(3, 20), ri(3, 20), ri(3, 20)];
    shuffleInPlace(vals);
    return {
      prompt: `Determine the mode of: ${vals.join(", ")}.`,
      answer: String(mode),
      answers: ans(String(mode)),
      explanation: `${mode} appears most often.`,
      topic: "ml_data",
      subtopic: "mode",
      marks: 1,
      diagram: {
        type: "line_graph",
        title: "Data set",
        labels: vals.map((_, i) => String(i + 1)),
        values: vals
      }
    };
  }
  if (kind === "range") {
    const vals = Array.from({ length: 6 }, () => ri(10, 50));
    const lo = Math.min(...vals);
    const hi = Math.max(...vals);
    return {
      prompt: `Calculate the range of: ${vals.join(", ")}.`,
      answer: String(hi - lo),
      answers: ans(String(hi - lo)),
      explanation: `Range = max - min = ${hi} - ${lo} = ${hi - lo}.`,
      topic: "ml_data",
      subtopic: "range",
      marks: 2,
      diagram: {
        type: "line_graph",
        title: "Data set (range)",
        labels: vals.map((_, i) => String(i + 1)),
        values: vals
      }
    };
  }
  const months = ["January", "February", "March", "April"];
  const sales = months.map(() => ri(80, 200) * 100);
  const maxI = sales.indexOf(Math.max(...sales));
  const total = sales.reduce((a, b) => a + b, 0);
  const avg = round2(total / 4);
  const diff = sales[3] - sales[0];
  return {
    prompt: `Monthly sales:\n${months.map((m, i) => `${m}: ${money(sales[i])}`).join("\n")}\n1. Which month had the highest sales?\n2. Calculate the difference between January and April.\n3. Calculate the average monthly sales.`,
    answer: `1. ${months[maxI]}  2. ${money(Math.abs(diff))}  3. ${money(avg)}`,
    answers: ans(months[maxI], money(Math.abs(diff)), money(avg)),
    explanation: `Highest = ${months[maxI]}. |Apr-Jan| = ${Math.abs(diff)}. Mean = ${total}/4 = ${avg}.`,
    topic: "ml_data",
    subtopic: "table_interpretation",
    marks: 6,
    multi_part: true,
    diagram: {
      type: "line_graph",
      title: "Monthly sales",
      labels: months.map(m => m.slice(0, 3)),
      values: sales.map(s => s / 100)
    }
  };
}

function shuffleInPlace(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ─── Probability ─────────────────────────────────────────────────────────────
function genProbability() {
  const kind = choice(["bag", "die", "complement", "experimental"]);
  if (kind === "bag") {
    const red = ri(3, 8);
    const total = red + ri(5, 15);
    const other = total - red;
    const g = gcd(red, total);
    return {
      prompt: `A bag contains ${total} sweets. ${red} are red. One sweet is selected at random. What is the probability of selecting a red sweet?`,
      answer: `${red / g}/${total / g}`,
      answers: ans(`${red}/${total}`, `${red / g}/${total / g}`, String(round2(red / total))),
      explanation: `P(red) = ${red}/${total}${g > 1 ? ` = ${red / g}/${total / g}` : ""}.`,
      topic: "ml_probability",
      subtopic: "basic",
      marks: 2,
      diagram: {
        type: "pie_chart",
        title: "Sweets in the bag",
        labels: ["Red", "Other"],
        values: [red, other],
        colors: ["#EF4444", "#94A3B8"]
      }
    };
  }
  if (kind === "die") {
    return {
      prompt: `A fair six-sided die is rolled once. What is the probability of obtaining a number greater than 4?`,
      answer: "1/3",
      answers: ans("1/3", "2/6", "0.333", "33.3%"),
      explanation: "Favourable: 5, 6 → 2/6 = 1/3.",
      topic: "ml_probability",
      subtopic: "die",
      marks: 2,
      diagram: { type: "dice", faces: 6, value: 5 }
    };
  }
  if (kind === "complement") {
    const p = choice([0.6, 0.7, 0.75, 0.8, 0.85]);
    return {
      prompt: `The probability that a bus arrives on time is ${p}. What is the probability that it does not arrive on time?`,
      answer: String(round2(1 - p)),
      answers: ans(String(round2(1 - p))),
      explanation: `P(not) = 1 - ${p} = ${round2(1 - p)}.`,
      topic: "ml_probability",
      subtopic: "complement",
      marks: 2,
      diagram: {
        type: "pie_chart",
        title: "On time vs late",
        labels: ["On time", "Not on time"],
        values: [Math.round(p * 100), Math.round((1 - p) * 100)],
        colors: ["#10B981", "#EF4444"]
      }
    };
  }
  const trials = 100;
  const heads = ri(45, 60);
  return {
    prompt: `A coin is tossed ${trials} times and lands on heads ${heads} times. Calculate the experimental probability of heads.`,
    answer: String(round2(heads / trials)),
    answers: ans(String(round2(heads / trials)), `${heads}/${trials}`),
    explanation: `Experimental P = ${heads}/${trials} = ${round2(heads / trials)}.`,
    topic: "ml_probability",
    subtopic: "experimental",
    marks: 2,
    diagram: {
      type: "pie_chart",
      title: `Coin tosses (n=${trials})`,
      labels: ["Heads", "Tails"],
      values: [heads, trials - heads],
      colors: ["#3B82F6", "#F59E0B"]
    }
  };
}

// ─── Patterns (taxi formulae etc.) ───────────────────────────────────────────
function genPatterns() {
  const fixed = choice([15, 20, 25, 30]);
  const rate = choice([6, 8, 9, 10, 12]);
  const d = ri(5, 25);
  const cost = fixed + rate * d;
  if (Math.random() < 0.4) {
    return {
      prompt: `A taxi charges ${money(fixed)} fixed plus ${money(rate)} per kilometre. Write a formula for cost C in terms of distance d (in km).`,
      answer: `C = ${fixed} + ${rate}d`,
      answers: ans(`C = ${fixed} + ${rate}d`, `C=${fixed}+${rate}d`, `${fixed}+${rate}d`),
      explanation: "Fixed component plus rate × distance.",
      topic: "ml_patterns",
      subtopic: "formula",
      marks: 2
    };
  }
  if (Math.random() < 0.5) {
    return {
      prompt: `A taxi charges ${money(fixed)} fixed plus ${money(rate)} per kilometre. Calculate the cost for a ${d} km trip.`,
      answer: money(cost),
      answers: ans(money(cost), String(cost)),
      explanation: `C = ${fixed} + ${rate}×${d} = ${cost}.`,
      topic: "ml_patterns",
      subtopic: "evaluate",
      marks: 2
    };
  }
  const start = ri(2, 10);
  const diff = ri(2, 6);
  const terms = [start, start + diff, start + 2 * diff, start + 3 * diff];
  return {
    prompt: `The first four terms of a pattern are ${terms.join(", ")}. What is the next term?`,
    answer: String(start + 4 * diff),
    answers: ans(String(start + 4 * diff)),
    explanation: `Constant first difference of ${diff}.`,
    topic: "ml_patterns",
    subtopic: "sequences",
    marks: 2
  };
}

// ─── Multi-part paper blocks ─────────────────────────────────────────────────
function genFinancePaperBlock() {
  const income = ri(120, 220) * 100;
  const rent = ri(30, 50) * 100;
  const food = ri(20, 40) * 100;
  const transport = ri(12, 25) * 100;
  const elec = ri(6, 15) * 100;
  const totalExp = rent + food + transport + elec;
  const remain = income - totalExp;
  const rentPct = round2(rent / income * 100);
  const elecUp = choice([10, 12, 15]);
  const newElec = round2(elec * (1 + elecUp / 100));
  return {
    topic: "ml_finance",
    title: "Personal finance — monthly budget",
    parts: [
      {
        label: "1.1",
        prompt: `Monthly income: ${money(income)}.\nExpenses — Rent ${money(rent)}, Food ${money(food)}, Transport ${money(transport)}, Electricity ${money(elec)}.\nCalculate total expenditure.`,
        answer: money(totalExp),
        explanation: `${rent}+${food}+${transport}+${elec}=${totalExp}`,
        marks: 3
      },
      {
        label: "1.2",
        prompt: "Calculate the amount remaining after these expenses.",
        answer: money(remain),
        explanation: `${income}-${totalExp}=${remain}`,
        marks: 2
      },
      {
        label: "1.3",
        prompt: "Calculate rent as a percentage of income (to 1 decimal place if needed).",
        answer: pct(rentPct),
        explanation: `(${rent}/${income})×100=${rentPct}%`,
        marks: 3
      },
      {
        label: "1.4",
        prompt: `Electricity increases by ${elecUp}%. Calculate the new electricity cost.`,
        answer: money(newElec),
        explanation: `${elec}×(1+${elecUp}/100)=${newElec}`,
        marks: 2
      }
    ]
  };
}

function genScalePaperBlock() {
  const scale = choice([25000, 50000, 100000]);
  const d1 = choice([3, 4, 4.5, 5, 6]);
  const d2 = choice([4, 5, 6, 7, 8]);
  const km1 = (d1 * scale) / 100000;
  const km2 = (d2 * scale) / 100000;
  const rate = choice([12, 14, 15, 18]);
  const fare = round2((km1 + km2) * rate);
  return {
    topic: "ml_maps",
    title: "Map scale and travel cost",
    parts: [
      {
        label: "1.1",
        prompt: `Map scale 1:${scale}. School to clinic measures ${d1} cm. Calculate the actual distance in km.`,
        answer: `${km1} km`,
        explanation: `${d1}×${scale} cm = ${km1} km`,
        marks: 3
      },
      {
        label: "1.2",
        prompt: `Clinic to station measures ${d2} cm on the same map. Calculate that actual distance.`,
        answer: `${km2} km`,
        explanation: `${d2}×${scale} cm = ${km2} km`,
        marks: 2
      },
      {
        label: "1.3",
        prompt: `A taxi charges ${money(rate)} per km. Estimate the fare for the full school→clinic→station trip.`,
        answer: money(fare),
        explanation: `(${km1}+${km2})×${rate}=${fare}`,
        marks: 3
      }
    ]
  };
}

function genDataPaperBlock() {
  const vals = Array.from({ length: 7 }, () => ri(15, 45) * 10);
  const sum = vals.reduce((a, b) => a + b, 0);
  const mean = round2(sum / 7);
  const sorted = vals.slice().sort((a, b) => a - b);
  const median = sorted[3];
  const range = sorted[6] - sorted[0];
  return {
    topic: "ml_data",
    title: "Daily sales data",
    parts: [
      {
        label: "1.1",
        prompt: `Daily sales (R): ${vals.join(", ")}.\nCalculate the mean sales.`,
        answer: money(mean),
        explanation: `Sum=${sum}; mean=${sum}/7=${mean}`,
        marks: 3
      },
      {
        label: "1.2",
        prompt: "Determine the median.",
        answer: money(median),
        explanation: `Ordered middle value = ${median}`,
        marks: 2
      },
      {
        label: "1.3",
        prompt: "Calculate the range.",
        answer: money(range),
        explanation: `Max-min = ${sorted[6]}-${sorted[0]}=${range}`,
        marks: 2
      }
    ]
  };
}

function genMeasurementPaperBlock() {
  const L = choice([4, 4.5, 5, 6]);
  const W = choice([3, 3.5, 4]);
  const area = round2(L * W);
  const rate = choice([180, 200, 220, 250]);
  const cost = round2(area * rate);
  const waste = 8;
  const buy = round2(area * 1.08);
  const cost2 = round2(buy * rate);
  return {
    topic: "ml_measurement",
    title: "Room flooring",
    diagram: {
      type: "floor_plan",
      L,
      W,
      label: "Bedroom floor plan",
      note: "Door indicated on south wall"
    },
    parts: [
      {
        label: "1.1",
        prompt: `A bedroom measures ${L} m by ${W} m. Calculate the floor area.`,
        answer: `${area} m²`,
        explanation: `${L}×${W}=${area}`,
        marks: 2
      },
      {
        label: "1.2",
        prompt: `Flooring costs ${money(rate)}/m². Calculate the cost for this area (no wastage).`,
        answer: money(cost),
        explanation: `${area}×${rate}=${cost}`,
        marks: 2
      },
      {
        label: "1.3",
        prompt: `Add ${waste}% for wastage. How much flooring (m²) should be purchased?`,
        answer: `${buy} m²`,
        explanation: `${area}×1.08=${buy}`,
        marks: 2
      },
      {
        label: "1.4",
        prompt: "Calculate the cost including wastage.",
        answer: money(cost2),
        explanation: `${buy}×${rate}=${cost2}`,
        marks: 2
      }
    ]
  };
}


// ─── Extra CAPS-style templates (payslip, tariff, break-even, floor plan, two-way table) ──
// Patterns inspired by open CAPS / Siyavula-style household and workplace contexts.

function genPayslip() {
  const basic = ri(80, 180) * 100;
  const overtime = ri(5, 25) * 100;
  const gross = basic + overtime;
  const tax = round2(gross * choice([0.12, 0.15, 0.18]));
  const uif = round2(gross * 0.01);
  const medical = ri(4, 12) * 50;
  const ded = round2(tax + uif + medical);
  const net = round2(gross - ded);
  const kind = choice(["gross", "net", "deductions", "basic"]);
  if (kind === "gross") {
    return {
      prompt: `Payslip extract:\nBasic salary: ${money(basic)}\nOvertime: ${money(overtime)}\nCalculate the gross salary.`,
      answer: money(gross),
      answers: ans(money(gross), String(gross)),
      explanation: `Gross = basic + overtime = ${basic} + ${overtime} = ${gross}.`,
      topic: "ml_finance",
      subtopic: "payslip",
      marks: 2,
      diagram: {
        type: "payslip",
        title: "Payslip extract",
        rows: [
          ["Basic salary", money(basic)],
          ["Overtime", money(overtime)],
          ["Gross (to find)", "?"]
        ]
      }
    };
  }
  if (kind === "deductions") {
    return {
      prompt: `Gross salary ${money(gross)}. Deductions: PAYE ${money(tax)}, UIF ${money(uif)}, medical aid ${money(medical)}. Calculate total deductions.`,
      answer: money(ded),
      answers: ans(money(ded), String(ded)),
      explanation: `Total deductions = ${tax} + ${uif} + ${medical} = ${ded}.`,
      topic: "ml_finance",
      subtopic: "payslip",
      marks: 2,
      diagram: {
        type: "payslip",
        title: "Deductions",
        rows: [
          ["Gross", money(gross)],
          ["PAYE", money(tax)],
          ["UIF", money(uif)],
          ["Medical aid", money(medical)],
          ["Total deductions", "?"]
        ]
      }
    };
  }
  if (kind === "net") {
    return {
      prompt: `Gross salary ${money(gross)}; total deductions ${money(ded)}. Calculate net pay.`,
      answer: money(net),
      answers: ans(money(net), String(net)),
      explanation: `Net = gross − deductions = ${gross} − ${ded} = ${net}.`,
      topic: "ml_finance",
      subtopic: "payslip",
      marks: 2
    };
  }
  return {
    prompt: `An employee’s basic salary is ${money(basic)} and overtime is ${money(overtime)}. What is the gross salary before deductions?`,
    answer: money(gross),
    answers: ans(money(gross), String(gross)),
    explanation: `${basic} + ${overtime} = ${gross}.`,
    topic: "ml_finance",
    subtopic: "payslip",
    marks: 2
  };
}

function genTariff() {
  // Electricity / water step tariff style
  const units = ri(150, 450);
  const block1 = 150;
  const rate1 = choice([1.5, 1.8, 2.0]);
  const rate2 = choice([2.2, 2.5, 2.8]);
  let cost;
  if (units <= block1) cost = round2(units * rate1);
  else cost = round2(block1 * rate1 + (units - block1) * rate2);
  const kind = choice(["cost", "units_in_block", "compare"]);
  if (kind === "cost") {
    return {
      prompt: `Electricity tariff:\n• First ${block1} kWh at R${rate1}/kWh\n• Above ${block1} kWh at R${rate2}/kWh\nA household used ${units} kWh. Calculate the total cost.`,
      answer: money(cost),
      answers: ans(money(cost), String(cost)),
      explanation: units <= block1
        ? `${units} × ${rate1} = ${cost}.`
        : `${block1}×${rate1} + (${units}-${block1})×${rate2} = ${cost}.`,
      topic: "ml_finance",
      subtopic: "tariff",
      marks: 3,
      diagram: {
        type: "tariff_steps",
        title: "Electricity tariff steps",
        usage: units,
        steps: [
          { from: 0, to: block1, rate: rate1 },
          { from: block1, to: Math.max(units, block1 + 50), rate: rate2 }
        ]
      }
    };
  }
  if (kind === "units_in_block") {
    const u = ri(40, 140);
    const c = round2(u * rate1);
    return {
      prompt: `Water is charged at R${rate1} per kilolitre for the first ${block1} kL. Cost for ${u} kL?`,
      answer: money(c),
      answers: ans(money(c), String(c)),
      explanation: `${u} × ${rate1} = ${c}.`,
      topic: "ml_finance",
      subtopic: "tariff",
      marks: 2,
      diagram: {
        type: "tariff_steps",
        title: "Water tariff (first block)",
        usage: u,
        steps: [{ from: 0, to: block1, rate: rate1 }]
      }
    };
  }
  const u2 = units + ri(20, 80);
  let cost2;
  if (u2 <= block1) cost2 = round2(u2 * rate1);
  else cost2 = round2(block1 * rate1 + (u2 - block1) * rate2);
  const diff = round2(cost2 - cost);
  return {
    prompt: `Same stepped tariff (R${rate1} then R${rate2} after ${block1} units). Cost for ${units} units is ${money(cost)}. How much more does ${u2} units cost?`,
    answer: money(diff),
    answers: ans(money(diff), String(diff)),
    explanation: `Cost at ${u2} = ${cost2}. Difference = ${cost2} − ${cost} = ${diff}.`,
    topic: "ml_finance",
    subtopic: "tariff",
    marks: 3,
    diagram: {
      type: "tariff_steps",
      title: "Stepped tariff comparison",
      usage: u2,
      steps: [
        { from: 0, to: block1, rate: rate1 },
        { from: block1, to: u2, rate: rate2 }
      ]
    }
  };
}

function genBreakEven() {
  const fixed = ri(20, 60) * 100;
  const varCost = choice([8, 10, 12, 15, 20]);
  const price = varCost + choice([5, 8, 10, 12, 15]);
  const units = Math.ceil(fixed / (price - varCost));
  const kind = choice(["units", "profit", "revenue"]);
  if (kind === "units") {
    return {
      prompt: `A small business has fixed costs of ${money(fixed)}. Variable cost per item is ${money(varCost)} and selling price is ${money(price)}. Calculate the break-even number of items (round up to whole items).`,
      answer: String(units),
      answers: ans(String(units), `${units} items`),
      explanation: `Break-even = fixed ÷ (price − variable) = ${fixed} ÷ (${price}−${varCost}) ≈ ${units}.`,
      topic: "ml_finance",
      subtopic: "break_even",
      marks: 3,
      diagram: {
        type: "table_diagram",
        title: "Break-even inputs",
        cols: ["Item", "Amount"],
        rows: [
          ["Fixed costs", money(fixed)],
          ["Variable / item", money(varCost)],
          ["Selling price", money(price)],
          ["Contribution", money(price - varCost)]
        ]
      }
    };
  }
  if (kind === "revenue") {
    const n = units + ri(5, 20);
    const rev = n * price;
    return {
      prompt: `Selling price ${money(price)} each. Revenue if ${n} items are sold?`,
      answer: money(rev),
      answers: ans(money(rev), String(rev)),
      explanation: `${n} × ${price} = ${rev}.`,
      topic: "ml_finance",
      subtopic: "break_even",
      marks: 2
    };
  }
  const n = units + ri(10, 30);
  const profit = n * (price - varCost) - fixed;
  return {
    prompt: `Fixed costs ${money(fixed)}; contribution per item ${money(price - varCost)}. Profit if ${n} items are sold?`,
    answer: money(profit),
    answers: ans(money(profit), String(profit)),
    explanation: `Profit = ${n}×(${price}−${varCost}) − ${fixed} = ${profit}.`,
    topic: "ml_finance",
    subtopic: "break_even",
    marks: 3
  };
}

function genFloorPlan() {
  const scale = choice([50, 100, 200]); // 1 cm : scale cm
  const Lcm = ri(4, 12);
  const Wcm = ri(3, 8);
  const Lm = round2((Lcm * scale) / 100); // cm on plan → m
  const Wm = round2((Wcm * scale) / 100);
  const area = round2(Lm * Wm);
  const peri = round2(2 * (Lm + Wm));
  const kind = choice(["length", "area", "perimeter", "tile"]);
  if (kind === "length") {
    return {
      prompt: `A floor plan uses scale 1:${scale}. A wall measures ${Lcm} cm on the plan. Actual length in metres?`,
      answer: `${Lm} m`,
      answers: ans(`${Lm} m`, String(Lm), money(Lm).replace("R", "")),
      explanation: `Actual = ${Lcm} × ${scale} cm = ${Lcm * scale} cm = ${Lm} m.`,
      topic: "ml_maps",
      subtopic: "floor_plan",
      marks: 2
    };
  }
  if (kind === "area") {
    return {
      prompt: `Room on a 1:${scale} plan is ${Lcm} cm by ${Wcm} cm. Calculate the actual floor area in m².`,
      answer: `${area} m²`,
      answers: ans(`${area} m²`, String(area)),
      explanation: `Actual ${Lm} m × ${Wm} m = ${area} m².`,
      topic: "ml_measurement",
      subtopic: "floor_plan",
      marks: 3,
      diagram: {
        type: "floor_plan",
        L: Lm,
        W: Wm,
        label: `Plan scale 1:${scale}`,
        note: `On plan: ${Lcm} cm × ${Wcm} cm`
      }
    };
  }
  if (kind === "perimeter") {
    return {
      prompt: `A rectangular room is ${Lm} m by ${Wm} m. Calculate the perimeter.`,
      answer: `${peri} m`,
      answers: ans(`${peri} m`, String(peri)),
      explanation: `P = 2(L+W) = 2(${Lm}+${Wm}) = ${peri} m.`,
      topic: "ml_measurement",
      subtopic: "perimeter",
      marks: 2,
      diagram: { type: "floor_plan", L: Lm, W: Wm, label: "Room" }
    };
  }
  const tile = 0.25; // m²
  const tiles = Math.ceil(area / tile);
  return {
    prompt: `A floor of ${area} m² is tiled with tiles of area 0,25 m² each. How many tiles are needed (round up)?`,
    answer: String(tiles),
    answers: ans(String(tiles)),
    explanation: `${area} ÷ 0,25 = ${area / tile}; round up → ${tiles}.`,
    topic: "ml_measurement",
    subtopic: "floor_plan",
    marks: 2
  };
}

function genTwoWayTable() {
  const boysYes = ri(8, 20);
  const boysNo = ri(5, 15);
  const girlsYes = ri(6, 18);
  const girlsNo = ri(4, 14);
  const total = boysYes + boysNo + girlsYes + girlsNo;
  const tableDiag = {
    type: "two_way_table",
    title: "Two-way table",
    rowHeaders: ["Boys", "Girls"],
    colHeaders: ["Yes", "No"],
    cells: [
      [boysYes, boysNo],
      [girlsYes, girlsNo]
    ]
  };
  const kind = choice(["total", "row", "prob", "compare"]);
  if (kind === "total") {
    return {
      prompt: `Survey of learners who prefer maths:\nBoys yes ${boysYes}, boys no ${boysNo}; girls yes ${girlsYes}, girls no ${girlsNo}.\nHow many learners were surveyed?`,
      answer: String(total),
      answers: ans(String(total)),
      explanation: `${boysYes}+${boysNo}+${girlsYes}+${girlsNo} = ${total}.`,
      topic: "ml_data",
      subtopic: "two_way_table",
      marks: 2,
      diagram: tableDiag
    };
  }
  if (kind === "row") {
    const boys = boysYes + boysNo;
    return {
      prompt: `Two-way table: boys who prefer sport ${boysYes}, boys who do not ${boysNo}. How many boys in total?`,
      answer: String(boys),
      answers: ans(String(boys)),
      explanation: `${boysYes} + ${boysNo} = ${boys}.`,
      topic: "ml_data",
      subtopic: "two_way_table",
      marks: 1,
      diagram: {
        type: "two_way_table",
        title: "Boys · sport preference",
        rowHeaders: ["Boys"],
        colHeaders: ["Prefer", "Do not"],
        cells: [[boysYes, boysNo]]
      }
    };
  }
  if (kind === "prob") {
    const p = simplifyFrac(boysYes, total);
    return {
      prompt: `Of ${total} learners, ${boysYes} are boys who prefer maths. Probability a randomly chosen learner is a boy who prefers maths?`,
      answer: p,
      answers: ans(p, `${boysYes}/${total}`),
      explanation: `P = ${boysYes}/${total}${p !== `${boysYes}/${total}` ? ` = ${p}` : ""}.`,
      topic: "ml_probability",
      subtopic: "two_way_table",
      marks: 2,
      diagram: tableDiag
    };
  }
  const more = boysYes > girlsYes ? "boys" : boysYes < girlsYes ? "girls" : "equal";
  return {
    prompt: `Boys preferring science: ${boysYes}; girls preferring science: ${girlsYes}. Who has the higher count?`,
    answer: more,
    answers: ans(more, more === "equal" ? "the same" : more),
    explanation: `Compare ${boysYes} and ${girlsYes} → ${more}.`,
    topic: "ml_data",
    subtopic: "two_way_table",
    marks: 1,
    diagram: {
      type: "two_way_table",
      title: "Science preference",
      rowHeaders: ["Boys", "Girls"],
      colHeaders: ["Prefer"],
      cells: [[boysYes], [girlsYes]]
    }
  };
}

function simplifyFrac(a, b) {
  function g(x, y) { return y === 0 ? x : g(y, x % y); }
  const d = g(a, b);
  return `${a / d}/${b / d}`;
}

function genBankStatement() {
  const open = ri(15, 40) * 100;
  const salary = ri(80, 150) * 100;
  const rent = ri(25, 45) * 100;
  const groceries = ri(8, 20) * 100;
  const close = open + salary - rent - groceries;
  const kind = choice(["close", "total_out", "salary"]);
  if (kind === "close") {
    return {
      prompt: `Bank statement extract:\nOpening balance ${money(open)}\nSalary deposit ${money(salary)}\nRent debit ${money(rent)}\nGroceries debit ${money(groceries)}\nCalculate the closing balance.`,
      answer: money(close),
      answers: ans(money(close), String(close)),
      explanation: `${open} + ${salary} − ${rent} − ${groceries} = ${close}.`,
      topic: "ml_finance",
      subtopic: "bank_statement",
      marks: 3,
      diagram: {
        type: "payslip",
        title: "Bank statement extract",
        rows: [
          ["Opening", money(open)],
          ["Salary (+)", money(salary)],
          ["Rent (−)", money(rent)],
          ["Groceries (−)", money(groceries)],
          ["Closing", "?"]
        ]
      }
    };
  }
  if (kind === "total_out") {
    const out = rent + groceries;
    return {
      prompt: `Debits on a statement: rent ${money(rent)}, groceries ${money(groceries)}. Total debits?`,
      answer: money(out),
      answers: ans(money(out), String(out)),
      explanation: `${rent} + ${groceries} = ${out}.`,
      topic: "ml_finance",
      subtopic: "bank_statement",
      marks: 2
    };
  }
  return {
    prompt: `Opening balance ${money(open)}; closing balance ${money(close)}; total debits ${money(rent + groceries)}. What was the salary deposit?`,
    answer: money(salary),
    answers: ans(money(salary), String(salary)),
    explanation: `Deposit = close − open + debits = ${close} − ${open} + ${rent + groceries} = ${salary}.`,
    topic: "ml_finance",
    subtopic: "bank_statement",
    marks: 3
  };
}

function genExchangeRate() {
  const rate = choice([17.5, 18.2, 18.8, 19.5, 20.1]); // ZAR per USD approx
  const kind = choice(["to_zar", "to_usd", "trip"]);
  if (kind === "to_zar") {
    const usd = ri(50, 400);
    const zar = round2(usd * rate);
    return {
      prompt: `Exchange rate: $1 = R${rate}. Convert $${usd} to rand.`,
      answer: money(zar),
      answers: ans(money(zar), String(zar)),
      explanation: `${usd} × ${rate} = ${zar}.`,
      topic: "ml_finance",
      subtopic: "exchange",
      marks: 2,
      diagram: {
        type: "exchange_rate",
        title: "USD → ZAR",
        from: "USD",
        to: "ZAR",
        rate,
        amountFrom: usd,
        amountTo: zar
      }
    };
  }
  if (kind === "to_usd") {
    const zar = ri(20, 80) * 100;
    const usd = round2(zar / rate);
    return {
      prompt: `Exchange rate: $1 = R${rate}. How many US dollars can you buy with ${money(zar)}?`,
      answer: `$${usd}`,
      answers: ans(`$${usd}`, String(usd), money(usd).replace("R", "")),
      explanation: `${zar} ÷ ${rate} = ${usd}.`,
      topic: "ml_finance",
      subtopic: "exchange",
      marks: 2,
      diagram: {
        type: "exchange_rate",
        title: "ZAR → USD",
        from: "ZAR",
        to: "USD",
        rate,
        amountFrom: zar,
        amountTo: usd
      }
    };
  }
  const days = ri(3, 10);
  const perDay = ri(40, 120);
  const totalUsd = days * perDay;
  const zar = round2(totalUsd * rate);
  return {
    prompt: `A trip lasts ${days} days. Budget $${perDay} per day. Rate $1 = R${rate}. Total rand needed?`,
    answer: money(zar),
    answers: ans(money(zar), String(zar)),
    explanation: `USD needed = ${days}×${perDay} = ${totalUsd}. Rand = ${totalUsd}×${rate} = ${zar}.`,
    topic: "ml_finance",
    subtopic: "exchange",
    marks: 3,
    diagram: {
      type: "exchange_rate",
      title: `Trip budget · ${days} days`,
      from: "USD",
      to: "ZAR",
      rate,
      amountFrom: totalUsd,
      amountTo: zar
    }
  };
}

const TOPIC_GENERATORS = {
  ml_numbers: [genPercentage, genRatioRate, genExchangeRate],
  ml_patterns: [genPatterns],
  ml_finance: [genFinance, genPercentage, genPayslip, genTariff, genBreakEven, genBankStatement, genExchangeRate],
  ml_measurement: [genMeasurement, genRatioRate, genFloorPlan],
  ml_maps: [genMaps, genFloorPlan],
  ml_data: [genData, genTwoWayTable],
  ml_probability: [genProbability, genTwoWayTable]
};

const PAPER_BLOCKS = {
  ml_numbers: [genFinancePaperBlock, genPercentage],
  ml_finance: [genFinancePaperBlock, genPayslip, genTariff, genBankStatement],
  ml_measurement: [genMeasurementPaperBlock, genFloorPlan],
  ml_maps: [genScalePaperBlock, genFloorPlan],
  ml_data: [genDataPaperBlock, genTwoWayTable],
  ml_patterns: [genPatterns],
  ml_probability: [genProbability, genTwoWayTable]
};

/**
 * Generate a single practice item for a Math Lit topic.
 */
export function generateMlQuestion(topicId, opts = {}) {
  const gens = TOPIC_GENERATORS[topicId];
  if (!gens || !gens.length) {
    return {
      prompt: `State one key fact about ${String(topicId).replaceAll("_", " ")}.`,
      answer: "See topic notes.",
      explanation: "",
      topic: topicId,
      marks: opts.marks || 2,
      type: "short"
    };
  }
  const g = choice(gens);
  const item = g();
  return {
    prompt: item.prompt,
    question: item.prompt,
    answer: String(item.answer),
    answers: item.answers || [String(item.answer)],
    explanation: item.explanation || "",
    topic: item.topic || topicId,
    topic_name: String(item.topic || topicId).replaceAll("_", " "),
    subtopic: item.subtopic || "",
    marks: item.marks || opts.marks || 2,
    type: item.multi_part ? "multi" : "short",
    multi_part: !!item.multi_part,
    diagram: item.diagram || null,
    difficulty: item.difficulty || opts.difficulty || 1
  };
}

/**
 * Generate a multi-part paper-style block for a topic.
 */
export function generateMlPaperParts(topicId, opts = {}) {
  const blocks = PAPER_BLOCKS[topicId];
  if (blocks && blocks.length) {
    const blockFn = choice(blocks);
    if (typeof blockFn === "function" && blockFn.name && blockFn.name.includes("Paper")) {
      const block = blockFn();
      if (block && block.parts) return block;
    }
  }
  // Fallback: several short items as parts
  const count = Math.min(opts.parts || 3, 4);
  const parts = [];
  let sharedDiagram = null;
  for (let i = 0; i < count; i++) {
    const q = generateMlQuestion(topicId, { marks: 2 });
    if (!sharedDiagram && q.diagram) sharedDiagram = q.diagram;
    parts.push({
      label: `1.${i + 1}`,
      prompt: q.prompt,
      answer: q.answer,
      explanation: q.explanation,
      marks: q.marks || 2,
      diagram: q.diagram || null
    });
  }
  return {
    topic: topicId,
    title: String(topicId).replaceAll("_", " "),
    diagram: sharedDiagram,
    parts
  };
}

export function isMlTopic(id) {
  return typeof id === "string" && id.startsWith("ml_");
}

export default { generateMlQuestion, generateMlPaperParts, isMlTopic };
