/**
 * Learnly Grade 10 — Subject paper engine (CAPS-style generative papers).
 * Mathematical Literacy · Business Studies · Tourism
 * Questions are generated programmatically — not copied from copyrighted PDFs.
 */

import { MultiSubjectEngine } from "./multiSubjectEngine.js";

function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

/** CAPS-inspired paper blueprints for Grade 10 */
const BLUEPRINTS = {
  mathematical_literacy: {
    papers: [
      {
        id: "ml_p1",
        name: "Mathematical Literacy Paper 1",
        period: "November",
        sections: [
          { heading: "SECTION A — Basic skills (numbers, ratio, rate, percentage)", topics: ["ml_numbers", "ml_patterns"], marks: 25, count: 4 },
          { heading: "SECTION B — Finance (budget, interest, VAT, profit)", topics: ["ml_finance"], marks: 40, count: 4 },
          { heading: "SECTION C — Measurement, maps & probability", topics: ["ml_measurement", "ml_maps", "ml_probability"], marks: 35, count: 3 },
          { heading: "SECTION D — Data handling", topics: ["ml_data"], marks: 25, count: 2 }
        ]
      },
      {
        id: "ml_p2",
        name: "Mathematical Literacy Paper 2",
        period: "November",
        sections: [
          { heading: "SECTION A — Finance & integrated budgets", topics: ["ml_finance", "ml_numbers"], marks: 40, count: 4 },
          { heading: "SECTION B — Measurement, plans & scale", topics: ["ml_measurement", "ml_maps"], marks: 40, count: 3 },
          { heading: "SECTION C — Data, probability & patterns", topics: ["ml_data", "ml_probability", "ml_patterns"], marks: 35, count: 3 }
        ]
      },
      {
        id: "ml_june",
        name: "Mathematical Literacy June Paper",
        period: "June",
        sections: [
          { heading: "SECTION A — Short items", topics: ["ml_numbers", "ml_finance", "ml_measurement"], marks: 30, count: 5 },
          { heading: "SECTION B — Structured finance & maps", topics: ["ml_finance", "ml_maps"], marks: 40, count: 3 },
          { heading: "SECTION C — Data & integrated", topics: ["ml_data", "ml_probability", "ml_patterns"], marks: 30, count: 2 }
        ]
      },
      {
        id: "ml_march",
        name: "Mathematical Literacy March Controlled Test",
        period: "March",
        sections: [
          { heading: "SECTION A — Numbers, ratio & percentage", topics: ["ml_numbers", "ml_patterns"], marks: 30, count: 4 },
          { heading: "SECTION B — Finance introduction", topics: ["ml_finance"], marks: 40, count: 3 },
          { heading: "SECTION C — Measurement basics", topics: ["ml_measurement", "ml_maps"], marks: 30, count: 3 }
        ]
      },
      {
        id: "ml_sept",
        name: "Mathematical Literacy September Trial",
        period: "September",
        sections: [
          { heading: "SECTION A — Finance & numbers", topics: ["ml_finance", "ml_numbers"], marks: 40, count: 4 },
          { heading: "SECTION B — Maps, measurement & data", topics: ["ml_maps", "ml_measurement", "ml_data"], marks: 40, count: 3 },
          { heading: "SECTION C — Probability & patterns", topics: ["ml_probability", "ml_patterns"], marks: 20, count: 2 }
        ]
      }
    ]
  },
  business_studies: {
    papers: [
      {
        id: "bs_p1",
        name: "Business Studies Paper 1",
        period: "November",
        sections: [
          { heading: "SECTION A — Compulsory short items", topics: ["bs_micro", "bs_market", "bs_macro", "bs_sectors"], marks: 30, count: 5 },
          { heading: "SECTION B — Business environments", topics: ["bs_micro", "bs_market", "bs_macro", "bs_socio"], marks: 40, count: 3 },
          { heading: "SECTION C — Essay / extended", topics: ["bs_entrepreneurship", "bs_ownership", "bs_opportunity"], marks: 40, count: 2 }
        ]
      },
      {
        id: "bs_p2",
        name: "Business Studies Paper 2",
        period: "November",
        sections: [
          { heading: "SECTION A — Compulsory short items", topics: ["bs_entrepreneurship", "bs_ownership", "bs_creative", "bs_self"], marks: 30, count: 5 },
          { heading: "SECTION B — Business ventures", topics: ["bs_opportunity", "bs_ownership", "bs_sectors"], marks: 40, count: 3 },
          { heading: "SECTION C — Essay / extended", topics: ["bs_socio", "bs_creative", "bs_self"], marks: 40, count: 2 }
        ]
      },
      {
        id: "bs_march",
        name: "Business Studies March Controlled Test",
        period: "March",
        sections: [
          { heading: "SECTION A — Short items", topics: ["bs_micro", "bs_market", "bs_macro"], marks: 30, count: 5 },
          { heading: "SECTION B — Environments & sectors", topics: ["bs_sectors", "bs_socio"], marks: 40, count: 3 },
          { heading: "SECTION C — Extended", topics: ["bs_entrepreneurship", "bs_ownership"], marks: 30, count: 2 }
        ]
      },
      {
        id: "bs_sept",
        name: "Business Studies September Trial",
        period: "September",
        sections: [
          { heading: "SECTION A — Short items", topics: ["bs_ownership", "bs_opportunity", "bs_creative"], marks: 30, count: 5 },
          { heading: "SECTION B — Ventures & roles", topics: ["bs_self", "bs_socio", "bs_sectors"], marks: 40, count: 3 },
          { heading: "SECTION C — Extended", topics: ["bs_macro", "bs_entrepreneurship"], marks: 30, count: 2 }
        ]
      }
    ]
  },
  tourism: {
    papers: [
      {
        id: "tour_p1",
        name: "Tourism Paper 1",
        period: "November",
        sections: [
          { heading: "SECTION A — Compulsory short items", topics: ["tour_intro", "tour_types", "tour_sectors", "tour_transport"], marks: 40, count: 5 },
          { heading: "SECTION B — Sectors & planning", topics: ["tour_accommodation", "tour_maps", "tour_attractions"], marks: 40, count: 3 },
          { heading: "SECTION C — Extended response", topics: ["tour_sustainable", "tour_domestic", "tour_service"], marks: 40, count: 2 }
        ]
      },
      {
        id: "tour_p2",
        name: "Tourism Paper 2",
        period: "June",
        sections: [
          { heading: "SECTION A — Short items", topics: ["tour_intro", "tour_types", "tour_service"], marks: 30, count: 4 },
          { heading: "SECTION B — Map work & attractions", topics: ["tour_maps", "tour_attractions", "tour_transport"], marks: 40, count: 3 },
          { heading: "SECTION C — Sustainable & domestic", topics: ["tour_sustainable", "tour_domestic", "tour_sectors"], marks: 30, count: 2 }
        ]
      },
      {
        id: "tour_march",
        name: "Tourism March Controlled Test",
        period: "March",
        sections: [
          { heading: "SECTION A — Introduction & types", topics: ["tour_intro", "tour_types"], marks: 30, count: 4 },
          { heading: "SECTION B — Sectors & transport", topics: ["tour_sectors", "tour_transport", "tour_accommodation"], marks: 40, count: 3 },
          { heading: "SECTION C — Service", topics: ["tour_service"], marks: 30, count: 2 }
        ]
      },
      {
        id: "tour_sept",
        name: "Tourism September Trial",
        period: "September",
        sections: [
          { heading: "SECTION A — Short items", topics: ["tour_maps", "tour_attractions", "tour_types"], marks: 30, count: 4 },
          { heading: "SECTION B — Sustainable tourism", topics: ["tour_sustainable", "tour_domestic"], marks: 40, count: 3 },
          { heading: "SECTION C — Service excellence", topics: ["tour_service", "tour_sectors"], marks: 30, count: 2 }
        ]
      }
    ]
  }
};

const YEARS = [2022, 2023, 2024, 2025];

export function listSubjectPapers(subjectId) {
  const bp = BLUEPRINTS[subjectId];
  if (!bp) return [];
  const out = [];
  bp.papers.forEach((tpl) => {
    YEARS.forEach((year) => {
      out.push({
        templateId: tpl.id,
        name: tpl.name,
        period: tpl.period,
        year,
        subjectId
      });
    });
  });
  return out;
}

export function generateSubjectPaper(subjectId, templateId = null, grade = 10, year = null) {
  const bp = BLUEPRINTS[subjectId];
  if (!bp) return null;
  const template = templateId
    ? bp.papers.find((p) => p.id === templateId) || bp.papers[0]
    : bp.papers[0];
  year = year || choice(YEARS);
  const eng = new MultiSubjectEngine(grade);
  const questions = [];
  let qn = 1;
  template.sections.forEach((sec) => {
    const perQ = Math.max(2, Math.round(sec.marks / sec.count));
    for (let i = 0; i < sec.count; i++) {
      const topic = choice(sec.topics);
      const marks = i === sec.count - 1
        ? sec.marks - perQ * (sec.count - 1)
        : perQ;
      const item = buildQuestion(topic, eng, marks, qn);
      if (item) {
        item.section = sec.heading;
        questions.push(item);
        qn += 1;
      }
    }
  });
  const totalMarks = questions.reduce((s, q) => s + (q.marks || 0), 0);
  const pid = `sp_${subjectId}_${template.id}_${year}_${Date.now()}`;
  return {
    id: pid,
    paper_id: pid,
    title: `${template.name} · ${year}`,
    name: template.name,
    period: template.period,
    year,
    subjectId,
    subject: subjectId,
    grade,
    grade_label: `Grade ${grade}`,
    questions,
    total_marks: totalMarks,
    marks: totalMarks,
    time_minutes: 150,
    source: "Learnly Grade 10 · generative CAPS-style (not a past-paper scan)"
  };
}

function buildQuestion(topic, eng, marks, number) {
  function pack(parts, title, diagram) {
    const partMarks = Math.max(1, Math.floor(marks / Math.max(1, parts.length)));
    const normalised = parts.map((p, i) => ({
      label: p.label || `${number}.${i + 1}`,
      prompt: p.prompt || p.question || "",
      answer: p.answer != null ? String(p.answer) : "",
      explanation: p.explanation || "",
      marks: p.marks || partMarks
    }));
    const questionText = normalised.map((p) => `${p.label} ${p.prompt}`).join("\n\n");
    const answerText = normalised.map((p) => `${p.label} ${p.answer}`).join("\n");
    const explText = normalised.map((p) => {
      const bit = p.explanation ? ` — ${p.explanation}` : "";
      return `${p.label} ${p.answer}${bit}`;
    }).join("\n");
    return {
      number,
      topic,
      topic_name: String(topic).replaceAll("_", " "),
      title: title || String(topic).replaceAll("_", " "),
      marks,
      question: questionText,
      answer: answerText,
      explanation: explText,
      diagram: diagram || null,
      parts: normalised
    };
  }
  try {
    if (typeof eng.generatePaperParts === "function") {
      const block = eng.generatePaperParts(topic, { parts: Math.min(4, Math.max(2, Math.ceil(marks / 3))) });
      if (block && block.parts && block.parts.length) {
        return pack(block.parts, block.title, block.diagram);
      }
    }
    const one = eng.generate(topic, { marks });
    return pack([{
      label: `${number}.1`,
      prompt: one.prompt || one.question,
      answer: one.answer,
      explanation: one.explanation || "",
      marks
    }], String(topic).replaceAll("_", " "), one.diagram);
  } catch (e) {
    return pack([{
      label: `${number}.1`,
      prompt: `Discuss a key idea from ${String(topic).replaceAll("_", " ")}.`,
      answer: "See topic notes.",
      explanation: "",
      marks
    }], String(topic).replaceAll("_", " "), null);
  }
}

export function subjectsWithPapers() {
  return Object.keys(BLUEPRINTS);
}


/**
 * Full topic practice paper: textbook / exam-style list of generative questions
 * for a single topic (8–12 items with hierarchical numbering).
 */
export function generateTopicPaper(subjectId, topicId, grade = 10, count = 10) {
  const eng = new MultiSubjectEngine(subjectId, grade);
  const title = String(topicId || "").replaceAll("_", " ");
  const n = Math.max(6, Math.min(14, count || 10));
  const questions = [];
  const seen = new Set();
  for (let i = 0; i < n * 3 && questions.length < n; i++) {
    const useBlock = questions.length % 3 === 0 && typeof eng.generatePaperParts === "function";
    if (useBlock) {
      const block = eng.generatePaperParts(topicId, { parts: 3 });
      if (block && block.parts && block.parts.length) {
        const qn = questions.length + 1;
        const body = block.parts.map((p, pi) => {
          const lab = p.label || `${qn}.${pi + 1}`;
          return `${lab} ${p.prompt || ""}`;
        }).join("\n\n");
        const ans = block.parts.map((p, pi) => {
          const lab = p.label || `${qn}.${pi + 1}`;
          return `${lab} ${p.answer || ""}`;
        }).join("\n");
        const exp = block.parts.map((p, pi) => {
          const lab = p.label || `${qn}.${pi + 1}`;
          return `${lab} ${p.answer || ""}${p.explanation ? " — " + p.explanation : ""}`;
        }).join("\n");
        const key = body.slice(0, 80);
        if (seen.has(key)) continue;
        seen.add(key);
        questions.push({
          number: qn,
          partLabel: String(qn),
          displayNumber: `QUESTION ${qn}`,
          sectionLabel: `QUESTION ${qn}`,
          question: body,
          prompt: body,
          answer: ans,
          explanation: exp,
          marks: block.parts.reduce((s, p) => s + (p.marks || 2), 0),
          topic: topicId,
          topic_name: title,
          parts: block.parts
        });
        continue;
      }
    }
    const one = eng.generate(topicId, { difficulty: 1 + (questions.length % 4) });
    if (!one) continue;
    const prompt = one.question || one.prompt || "";
    if (!prompt || seen.has(prompt.slice(0, 60))) continue;
    seen.add(prompt.slice(0, 60));
    const qn = questions.length + 1;
    questions.push({
      number: qn,
      partLabel: String(qn),
      displayNumber: `QUESTION ${qn}`,
      sectionLabel: `QUESTION ${qn}`,
      question: prompt,
      prompt,
      answer: one.answer,
      explanation: one.explanation || String(one.answer || ""),
      marks: one.marks || 2,
      topic: topicId,
      topic_name: one.topic_name || title,
      diagram: one.diagram || null
    });
  }
  const total = questions.reduce((s, q) => s + (q.marks || 2), 0);
  const pid = `topic_${topicId}_${Date.now()}`;
  return {
    id: pid,
    paper_id: pid,
    title: `${title} — topic practice paper`,
    name: title,
    period: "Topic practice",
    type: "Topic practice",
    subjectId,
    subject: subjectId,
    grade,
    grade_label: `Grade ${grade}`,
    questions,
    total_marks: total,
    marks: total,
    time_minutes: Math.max(30, questions.length * 4),
    source: "Learnly Grade 10 · generative CAPS topic paper · The Elites Academy"
  };
}


function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function money(n) {
  const v = Math.round(n * 100) / 100;
  return "R" + v.toFixed(2).replace(/\.00$/, "");
}

/** Multi-day tourism itinerary: distance + cost multi-part block */
export function generateTourismItinerary(grade = 10) {
  const days = [
    { place: "Durban beachfront", km: ri(8, 25), activity: "City tour", cost: ri(15, 40) * 10 },
    { place: "uShaka Marine World", km: ri(5, 18), activity: "Entrance", cost: ri(20, 45) * 10 },
    { place: "Midlands Meander", km: ri(40, 90), activity: "Craft stop", cost: ri(12, 30) * 10 }
  ];
  const fuelRate = [8.5, 9.2, 10.5][ri(0, 2)];
  const totalKm = days.reduce((s, d) => s + d.km, 0);
  const fuel = Math.round(totalKm * fuelRate * 100) / 100;
  const activities = days.reduce((s, d) => s + d.cost, 0);
  const total = Math.round((fuel + activities) * 100) / 100;
  const parts = [
    {
      label: "1.1",
      prompt: `A 3-day KZN itinerary covers: Day 1 ${days[0].place} (${days[0].km} km), Day 2 ${days[1].place} (${days[1].km} km), Day 3 ${days[2].place} (${days[2].km} km). Calculate the total distance.`,
      answer: `${totalKm} km`,
      explanation: `${days[0].km}+${days[1].km}+${days[2].km}=${totalKm}`,
      marks: 2
    },
    {
      label: "1.2",
      prompt: `Fuel consumption averages R${fuelRate} per kilometre. Calculate the total fuel cost for the trip.`,
      answer: money(fuel),
      explanation: `${totalKm}×${fuelRate}=${fuel}`,
      marks: 2
    },
    {
      label: "1.3",
      prompt: `Activity costs: ${days.map((d) => d.place + " " + money(d.cost)).join("; ")}. Calculate the total activity cost.`,
      answer: money(activities),
      explanation: days.map((d) => d.cost).join("+") + "=" + activities,
      marks: 2
    },
    {
      label: "1.4",
      prompt: "Calculate the combined cost of fuel and activities for the itinerary.",
      answer: money(total),
      explanation: `${fuel}+${activities}=${total}`,
      marks: 2
    }
  ];
  const body = parts.map((p) => `${p.label} ${p.prompt}`).join("\n\n");
  const pid = `tour_itin_${Date.now()}`;
  return {
    paper_id: pid,
    id: pid,
    title: "Tourism · 3-day itinerary (maps & costs)",
    name: "Tourism itinerary",
    period: "Topic practice",
    subjectId: "tourism",
    grade,
    questions: [{
      number: 1,
      question: body,
      prompt: body,
      answer: parts.map((p) => `${p.label} ${p.answer}`).join("\n"),
      explanation: parts.map((p) => `${p.label} ${p.explanation}`).join("\n"),
      marks: 8,
      topic: "tour_maps",
      parts,
      diagram: { type: "scale_bar", title: "Tour route (schematic)", ratio: 100000, actualKm: totalKm }
    }],
    total_marks: 8,
    marks: 8,
    time_minutes: 25,
    source: "Learnly Grade 10 · generative itinerary"
  };
}

/** Business case mini-paper: one scenario → ownership, PESTEL, sectors */
export function generateBusinessCase(grade = 10) {
  const names = ["Lerato", "Sipho", "Aisha", "Johan"];
  const name = names[ri(0, names.length - 1)];
  const idea = ["organic juice bar", "phone-repair kiosk", "township tour company", "school uniform shop"][ri(0, 3)];
  const capital = ri(40, 120) * 1000;
  const parts = [
    {
      label: "1.1",
      prompt: `${name} wants to start a ${idea} with capital of about ${money(capital)}. Name TWO suitable forms of ownership and state the liability of each.`,
      answer: "Sole trader — unlimited; Pty Ltd — limited (or Partnership — unlimited).",
      explanation: "Match form to liability: unlimited for sole trader/partnership; limited for companies.",
      marks: 4
    },
    {
      label: "1.2",
      prompt: `Identify ONE Political and ONE Economic factor from the PESTEL model that could affect the ${idea}.`,
      answer: "Political: e.g. licensing / local by-laws. Economic: e.g. inflation / interest rates / consumer income.",
      explanation: "PESTEL: Political, Economic, Social, Technological, Environmental, Legal.",
      marks: 4
    },
    {
      label: "1.3",
      prompt: `In which economic sector does a ${idea} mainly operate? Motivate briefly.`,
      answer: "Tertiary (service / retail) — provides a service or sells finished goods to customers.",
      explanation: "Primary extracts; secondary manufactures; tertiary serves.",
      marks: 3
    },
    {
      label: "1.4",
      prompt: "Recommend ONE micro-environment function that must be strong for this start-up (e.g. marketing or finance) and explain why.",
      answer: "Any valid function with reason linked to cash flow, customers, or operations.",
      explanation: "Eight functions include marketing, finance, HR, operations, etc.",
      marks: 3
    }
  ];
  const body = parts.map((p) => `${p.label} ${p.prompt}`).join("\n\n");
  const pid = `bs_case_${Date.now()}`;
  return {
    paper_id: pid,
    id: pid,
    title: `Business case · ${idea}`,
    name: "Business case study",
    period: "Topic practice",
    subjectId: "business_studies",
    grade,
    questions: [{
      number: 1,
      question: body,
      prompt: body,
      answer: parts.map((p) => `${p.label} ${p.answer}`).join("\n"),
      explanation: parts.map((p) => `${p.label} ${p.explanation}`).join("\n"),
      marks: 14,
      topic: "bs_ownership",
      parts,
      diagram: {
        type: "pestel",
        title: "PESTEL macro factors"
      }
    }],
    total_marks: 14,
    marks: 14,
    time_minutes: 30,
    source: "Learnly Grade 10 · generative business case"
  };
}
