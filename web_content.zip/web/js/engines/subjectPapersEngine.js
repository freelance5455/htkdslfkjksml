/**
 * learnyZ — Subject paper engine (CAPS-style generative papers).
 *
 * Builds multi-part examination-style papers per FET subject.
 * Structures follow CAPS weightings and common open exam patterns
 * (DBE/IEB-style sectioning). Questions are generated programmatically
 * from engines — not copied from copyrighted past-paper PDFs.
 */

import { MultiSubjectEngine } from "./multiSubjectEngine.js";
import { FetQuestionEngine } from "./fetEngine.js";
import { PhysSciEngine } from "./physSciEngine.js";

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

/** CAPS-inspired paper blueprints per subject (Paper 1 / Paper 2 where relevant) */
const BLUEPRINTS = {
  life_sciences: {
    papers: [
      {
        id: "ls_p1",
        name: "Life Sciences Paper 1",
        period: "November-style",
        sections: [
          { heading: "SECTION A — Short items", topics: ["ls_cells", "ls_tissues", "ls_mitosis"], marks: 20, count: 4 },
          { heading: "SECTION B — Structured", topics: ["ls_photosynthesis", "ls_nutrition", "ls_human"], marks: 40, count: 3 },
          { heading: "SECTION C — Essay / extended", topics: ["ls_environment", "ls_genetics"], marks: 20, count: 1 }
        ]
      },
      {
        id: "ls_p2",
        name: "Life Sciences Paper 2",
        period: "November-style",
        sections: [
          { heading: "SECTION A — Short items", topics: ["ls_genetics", "ls_evolution", "ls_biodiversity"], marks: 20, count: 4 },
          { heading: "SECTION B — Structured", topics: ["ls_human", "ls_reproduction", "ls_support"], marks: 40, count: 3 },
          { heading: "SECTION C — Extended response", topics: ["ls_environment", "ls_evolution"], marks: 20, count: 1 }
        ]
      }
    ]
  },
  geography: {
    papers: [
      {
        id: "geo_p1",
        name: "Geography Paper 1 (Theory)",
        period: "November-style",
        sections: [
          { heading: "Climate & weather", topics: ["geo_climate", "geo_atmosphere"], marks: 30, count: 3 },
          { heading: "Geomorphology", topics: ["geo_geomorphology", "geo_water"], marks: 30, count: 3 },
          { heading: "Settlement & economic", topics: ["geo_settlement", "geo_economy"], marks: 30, count: 2 }
        ]
      },
      {
        id: "geo_p2",
        name: "Geography Paper 2 (Mapwork)",
        period: "November-style",
        sections: [
          { heading: "Map skills", topics: ["geo_mapwork"], marks: 40, count: 4 },
          { heading: "GIS & interpretation", topics: ["geo_mapwork", "geo_population"], marks: 30, count: 3 }
        ]
      }
    ]
  },
  accounting: {
    papers: [
      {
        id: "acc_p1",
        name: "Accounting Paper 1",
        period: "November-style",
        sections: [
          { heading: "Concepts & equation", topics: ["acc_concepts"], marks: 20, count: 2 },
          { heading: "Books & ledger", topics: ["acc_books", "acc_ledger"], marks: 40, count: 3 },
          { heading: "VAT & year-end", topics: ["acc_vat", "acc_financials"], marks: 30, count: 2 }
        ]
      },
      {
        id: "acc_p2",
        name: "Accounting Paper 2",
        period: "November-style",
        sections: [
          { heading: "Bank reconciliation", topics: ["acc_bank"], marks: 30, count: 2 },
          { heading: "Analysis & interpretation", topics: ["acc_analysis", "acc_financials"], marks: 40, count: 3 },
          { heading: "Costing / inventory", topics: ["acc_costing", "acc_inventory"], marks: 20, count: 2 }
        ]
      }
    ]
  },
  cat: {
    papers: [
      {
        id: "cat_p1",
        name: "CAT Paper 1 (Theory)",
        period: "November-style",
        sections: [
          { heading: "Systems technologies", topics: ["cat_systems", "cat_hardware"], marks: 30, count: 4 },
          { heading: "Social implications", topics: ["cat_social", "cat_info_mgmt"], marks: 25, count: 3 },
          { heading: "Network & internet", topics: ["cat_network"], marks: 20, count: 2 }
        ]
      },
      {
        id: "cat_p2",
        name: "CAT Paper 2 (Practical theory)",
        period: "November-style",
        sections: [
          { heading: "Word / presentation concepts", topics: ["cat_presentation", "cat_files"], marks: 25, count: 3 },
          { heading: "Spreadsheet & database", topics: ["cat_spreadsheet", "cat_database"], marks: 40, count: 4 }
        ]
      }
    ]
  },
  physical_sciences: {
    papers: [
      {
        id: "ps_p1",
        name: "Physical Sciences Paper 1 (Physics)",
        period: "November-style",
        sections: [
          { heading: "Mechanics", topics: ["ps_vectors", "ps_newtons_laws", "ps_gravitation"], marks: 45, count: 4 },
          { heading: "Waves & electricity", topics: ["ps_waves", "ps_circuits", "ps_electrostatics"], marks: 45, count: 4 }
        ]
      },
      {
        id: "ps_p2",
        name: "Physical Sciences Paper 2 (Chemistry)",
        period: "November-style",
        sections: [
          { heading: "Matter & chemical change", topics: ["ps_bonding", "ps_imf", "ps_stoich"], marks: 45, count: 4 },
          { heading: "Chemical systems", topics: ["ps_energy_chem", "ps_acids_bases", "ps_redox"], marks: 45, count: 4 }
        ]
      }
    ]
  },
  maths: {
    papers: [
      {
        id: "maths_p1",
        name: "Mathematics Paper 1",
        period: "November-style",
        sections: [
          { heading: "Algebra & equations", topics: ["equations_inequalities", "exponents_surds", "number_patterns"], marks: 45, count: 4 },
          { heading: "Functions & finance", topics: ["functions_graphs", "finance_11"], marks: 45, count: 3 },
          { heading: "Probability", topics: ["probability_11"], marks: 15, count: 2 }
        ]
      },
      {
        id: "maths_p2",
        name: "Mathematics Paper 2",
        period: "November-style",
        sections: [
          { heading: "Statistics & analytical", topics: ["statistics_11", "analytical_geometry"], marks: 50, count: 4 },
          { heading: "Trigonometry", topics: ["trigonometry"], marks: 40, count: 3 },
          { heading: "Euclidean geometry", topics: ["euclidean_geometry"], marks: 40, count: 3 }
        ]
      }
    ]
  }
};

function yearChoices() {
  return [2022, 2023, 2024, 2025];
}

export function listSubjectPapers(subjectId) {
  const bp = BLUEPRINTS[subjectId];
  if (!bp) return [];
  const years = yearChoices();
  const out = [];
  for (const paper of bp.papers) {
    for (const year of years) {
      out.push({
        id: `${paper.id}_${year}`,
        templateId: paper.id,
        name: paper.name,
        period: paper.period,
        year,
        subjectId,
        label: `${paper.name} · ${year}`
      });
    }
  }
  return out;
}

/**
 * Generate a full multi-part paper instance for a subject.
 */
export function generateSubjectPaper(subjectId, templateId = null, grade = 12, year = null) {
  const bp = BLUEPRINTS[subjectId];
  if (!bp) return null;
  const template = templateId
    ? bp.papers.find((p) => p.id === templateId) || bp.papers[0]
    : choice(bp.papers);
  year = year || choice(yearChoices());

  const questions = [];
  let qn = 1;
  let totalMarks = 0;

  for (const section of template.sections) {
    const sectionStart = qn;
    for (let i = 0; i < section.count; i++) {
      const topic = choice(section.topics);
      const marks = Math.max(3, Math.round(section.marks / section.count));
      const item = buildQuestion(subjectId, topic, grade, marks, qn);
      if (item) {
        item.section = section.heading;
        questions.push(item);
        totalMarks += item.marks || marks;
        qn += 1;
      }
    }
    // Tag first question of section
    if (questions.length && questions[questions.length - (qn - sectionStart)] ) {
      /* section header carried on each item */
    }
  }

  const pid = `sp_${subjectId}_${template.id}_${year}_${Date.now()}`;
  return {
    id: pid,
    paper_id: pid,
    subjectId,
    subject: subjectId,
    templateId: template.id,
    name: template.name,
    title: `${template.name} · ${year}`,
    year,
    period: template.period,
    grade,
    grade_label: `Grade ${grade}`,
    curated: true,
    generated: true,
    marks: totalMarks,
    time_minutes: subjectId === "maths" || subjectId === "physical_sciences" ? 180 : 150,
    questions,
    created_at: new Date().toISOString(),
    source: "learnyZ generative CAPS-style (not a scanned past paper)"
  };
}

function buildQuestion(subjectId, topic, grade, marks, number) {
  try {
    if (subjectId === "maths") {
      const eng = new FetQuestionEngine(grade);
      const q = eng.generate(topic, 3) || eng.generate(null, 3);
      if (!q) return null;
      return {
        number,
        topic: q.topic || topic,
        topic_name: (q.topic_name || topic).replaceAll("_", " "),
        question: q.question,
        answer: q.answer,
        explanation: q.explanation || q.hint || "",
        diagram: q.diagram || null,
        marks: q.marks || marks,
        parts: q.parts || null
      };
    }
    if (subjectId === "physical_sciences") {
      const eng = new PhysSciEngine(grade);
      const q = eng.generate(topic, 3) || eng.generate(null, 3);
      if (!q) return null;
      return {
        number,
        topic: q.topic || topic,
        topic_name: (q.topic_name || topic).replaceAll("_", " "),
        question: q.question,
        answer: q.answer,
        explanation: q.explanation || "",
        diagram: q.diagram || null,
        marks: q.marks || marks
      };
    }
    const eng = new MultiSubjectEngine(subjectId, grade);
    // Prefer dedicated CAPS multi-part recipes (Accounting bank recon, equation, financials…)
    if (typeof eng.generatePaperParts === "function") {
      const paperParts = eng.generatePaperParts(topic, 3) || [];
      if (paperParts.length >= 2) {
        const stem = `QUESTION — ${(topic || "").replaceAll("_", " ")}\nAnswer the following sub-questions.`;
        const body = paperParts.map((p) => `${p.partLabel || ""} (${p.marks || 2}) ${p.question}`).join("\n\n");
        const answers = paperParts.map((p) => `${p.partLabel || ""}: ${p.answer}`).join(" · ");
        const working = paperParts.map((p) => `${p.partLabel || ""}: ${p.explanation || p.answer}`).join("\n");
        const totalM = paperParts.reduce((s, p) => s + (p.marks || 2), 0) || marks;
        return {
          number,
          topic: paperParts[0].topic || topic,
          topic_name: (paperParts[0].topic_name || topic).replaceAll("_", " "),
          question: stem + "\n\n" + body,
          answer: answers,
          explanation: working,
          diagram: paperParts[0].diagram || null,
          marks: totalM,
          parts: paperParts.map((p) => `${p.partLabel} (${p.marks}) ${p.question}`)
        };
      }
    }
    const q = eng.generate(topic, 3) || eng.generateConcept(topic, 3);
    if (!q) return null;
    const parts = buildStructuredParts(subjectId, topic, eng, marks);
    return {
      number,
      topic: q.topic || topic,
      topic_name: (q.topic_name || topic).replaceAll("_", " "),
      question: parts ? parts.stem : q.question,
      answer: parts ? parts.answers.join(" · ") : q.answer,
      explanation: parts ? parts.working : (q.explanation || ""),
      diagram: q.diagram || null,
      marks,
      parts: parts ? parts.parts : null
    };
  } catch {
    return {
      number,
      topic,
      topic_name: topic.replaceAll("_", " "),
      question: `Discuss the key CAPS ideas for ${topic.replaceAll("_", " ")} with one example.`,
      answer: "See CAPS notes for model content.",
      explanation: "Use definitions, a diagram if relevant, and a real-life link.",
      marks
    };
  }
}

function buildStructuredParts(subjectId, topic, eng, marks) {
  const q1 = eng.generate(topic, 2);
  const q2 = eng.generateConcept(topic, 2);
  const q3 = eng.generate(topic, 3);
  if (!q1 || !q2) return null;
  const parts = [
    { label: "1.1", text: q1.question, marks: Math.max(2, Math.floor(marks * 0.3)), answer: q1.answer },
    { label: "1.2", text: q2.question, marks: Math.max(2, Math.floor(marks * 0.3)), answer: q2.answer }
  ];
  if (q3) {
    parts.push({ label: "1.3", text: q3.question, marks: Math.max(2, marks - parts[0].marks - parts[1].marks), answer: q3.answer });
  }
  return {
    stem: `QUESTION — ${topic.replaceAll("_", " ")}\nAnswer the following sub-questions.`,
    parts: parts.map((p) => `${p.label} (${p.marks}) ${p.text}`),
    answers: parts.map((p) => `${p.label}: ${p.answer}`),
    working: parts.map((p) => `${p.label}: ${p.answer}`).join("\n")
  };
}

export function subjectsWithPapers() {
  return Object.keys(BLUEPRINTS);
}
