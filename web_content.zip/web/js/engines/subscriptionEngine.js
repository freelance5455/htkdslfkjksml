/**
 * learnyZ subscription plans — simulated (no payment provider yet).
 * Pricing in ZAR for South Africa.
 *
 * Ladder:
 *   Free        R0
 *   Learner     R49 / month   or  R450 / year   → 3-subject bundle
 *   Pro         R99 / month   or  R899 / year   → all core subjects, one grade
 *   Family      R999 / year                     → up to 5 profiles, full core each
 */

export const PLANS = {
  free: {
    id: "free",
    name: "Free",
    tagline: "Try learnyZ",
    monthly: 0,
    annual: 0,
    profiles: 1,
    subjectsMode: "one", // single subject
    maxSubjects: 1,
    assessmentCredits: 0, // earn only
    dailyFreeCredits: 3,
    signupCredits: 30,
    rewardedAdsPerDay: 4,
    creditsPerAd: 5,
    paperCost: 5,
    exportCost: 1,
    ads: true,
    focus: false,
    examLock: false
  },
  learner: {
    id: "learner",
    name: "Learner",
    tagline: "3 subjects · one grade",
    monthly: 49,
    annual: 450,
    profiles: 1,
    subjectsMode: "bundle", // 3-subject starter bundle
    maxSubjects: 3,
    assessmentCredits: 80,
    dailyFreeCredits: 0,
    signupCredits: 0,
    rewardedAdsPerDay: 0,
    creditsPerAd: 0,
    paperCost: 5,
    exportCost: 1,
    ads: false,
    focus: false,
    examLock: false
  },
  pro: {
    id: "pro",
    name: "Pro",
    tagline: "All core subjects · one grade",
    monthly: 99,
    annual: 899,
    profiles: 1,
    subjectsMode: "full_core",
    maxSubjects: 99,
    assessmentCredits: 250,
    dailyFreeCredits: 0,
    signupCredits: 0,
    rewardedAdsPerDay: 0,
    creditsPerAd: 0,
    paperCost: 5,
    exportCost: 1,
    ads: false,
    focus: true,
    examLock: false
  },
  family: {
    id: "family",
    name: "Family",
    tagline: "Up to 5 learners · all grades",
    monthly: 0,
    annual: 999,
    profiles: 5,
    subjectsMode: "full_core",
    maxSubjects: 99,
    assessmentCredits: 400,
    dailyFreeCredits: 0,
    signupCredits: 0,
    rewardedAdsPerDay: 0,
    creditsPerAd: 0,
    paperCost: 5,
    exportCost: 1,
    ads: false,
    focus: true,
    examLock: true
  }
};

/** FET / senior core subjects included in Pro & Family */
export const CORE_SUBJECTS_FET = [
  "maths",
  "physical_sciences",
  "life_sciences",
  "geography",
  "accounting",
  "business_studies",
  "economics"
];

export const CORE_SUBJECTS_GET = ["maths", "natural_sciences", "technology"];
export const CORE_SUBJECTS_IP = ["maths", "natural_sciences_technology"];
export const CORE_SUBJECTS_FP = ["maths"];

/** Starter bundles for Learner plan (pick one) */
export const STARTER_BUNDLES = {
  science: {
    id: "science",
    name: "Science route",
    grades: [10, 11, 12],
    subjects: ["maths", "physical_sciences", "life_sciences"]
  },
  commerce: {
    id: "commerce",
    name: "Commerce route",
    grades: [10, 11, 12],
    subjects: ["maths", "accounting", "business_studies"]
  },
  mixed: {
    id: "mixed",
    name: "Mixed FET",
    grades: [10, 11, 12],
    subjects: ["maths", "accounting", "geography"]
  },
  senior_gen: {
    id: "senior_gen",
    name: "Senior general",
    grades: [7, 8, 9],
    subjects: ["maths", "natural_sciences", "technology"]
  },
  intermediate: {
    id: "intermediate",
    name: "Intermediate",
    grades: [4, 5, 6],
    subjects: ["maths", "natural_sciences_technology"]
  },
  foundation: {
    id: "foundation",
    name: "Foundation maths",
    grades: [0, 1, 2, 3],
    subjects: ["maths"]
  }
};

export function planOf(student) {
  const id = student?.subscription?.plan || "free";
  return PLANS[id] || PLANS.free;
}

export function billingOf(student) {
  return student?.subscription?.billing || "monthly"; // monthly | annual
}

export function priceLabel(planId, billing = "monthly") {
  const p = PLANS[planId];
  if (!p) return "R0";
  if (planId === "free") return "R0";
  if (planId === "family") return `R${p.annual}/year`;
  if (billing === "annual" && p.annual) return `R${p.annual}/year`;
  return `R${p.monthly}/month`;
}

export function bundlesForGrade(grade) {
  const g = Number(grade);
  return Object.values(STARTER_BUNDLES).filter((b) => b.grades.includes(g));
}

export function defaultBundleForGrade(grade) {
  const list = bundlesForGrade(grade);
  return list[0] || STARTER_BUNDLES.foundation;
}

/** Subjects the student may use under their plan */
export function allowedSubjects(student, grade) {
  const plan = planOf(student);
  const g = Number(grade ?? student?.grade ?? 5);
  const allForGrade = subjectsAvailableForGrade(g);

  if (plan.subjectsMode === "one") {
    const chosen = student?.subscription?.freeSubject || "maths";
    return allForGrade.includes(chosen) ? [chosen] : ["maths"];
  }
  if (plan.subjectsMode === "bundle") {
    const bid = student?.subscription?.bundle || defaultBundleForGrade(g).id;
    const bundle = STARTER_BUNDLES[bid] || defaultBundleForGrade(g);
    return bundle.subjects.filter((s) => allForGrade.includes(s));
  }
  // full_core
  return allForGrade;
}

function subjectsAvailableForGrade(g) {
  if (g <= 3) return CORE_SUBJECTS_FP.slice();
  if (g <= 6) return CORE_SUBJECTS_IP.slice();
  if (g <= 9) return [...CORE_SUBJECTS_GET, "english_fal"];
  return [...CORE_SUBJECTS_FET, "english_fal"];
}

export function canAccessSubject(student, subjectId, grade) {
  return allowedSubjects(student, grade).includes(subjectId);
}

/** Assessment credit balance helpers */
export function ensureSubscription(student) {
  if (!student.subscription) {
    student.subscription = {
      plan: "free",
      billing: "monthly",
      bundle: null,
      freeSubject: "maths",
      assessmentCredits: 30,
      creditsMonth: monthKey(),
      adsWatchedToday: 0,
      adsDay: dayKey()
    };
  }
  const sub = student.subscription;
  if (sub.creditsMonth !== monthKey()) {
    const plan = PLANS[sub.plan] || PLANS.free;
    sub.creditsMonth = monthKey();
    if (plan.assessmentCredits > 0) {
      sub.assessmentCredits = plan.assessmentCredits;
    }
    sub.adsWatchedToday = 0;
  }
  if (sub.adsDay !== dayKey()) {
    sub.adsDay = dayKey();
    sub.adsWatchedToday = 0;
    const plan = PLANS[sub.plan] || PLANS.free;
    if (plan.dailyFreeCredits > 0) {
      sub.assessmentCredits = (sub.assessmentCredits || 0) + plan.dailyFreeCredits;
    }
  }
  return sub;
}

function monthKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function dayKey() {
  return new Date().toISOString().slice(0, 10);
}

export function spendAssessment(student, amount) {
  const sub = ensureSubscription(student);
  if ((sub.assessmentCredits || 0) < amount) return false;
  sub.assessmentCredits -= amount;
  return true;
}

export function grantAdCredits(student) {
  const sub = ensureSubscription(student);
  const plan = planOf(student);
  if (!plan.ads) return { ok: false, reason: "Ads not available on this plan" };
  if ((sub.adsWatchedToday || 0) >= plan.rewardedAdsPerDay) {
    return { ok: false, reason: "Daily ad limit reached" };
  }
  sub.adsWatchedToday = (sub.adsWatchedToday || 0) + 1;
  sub.assessmentCredits = (sub.assessmentCredits || 0) + plan.creditsPerAd;
  return { ok: true, credits: plan.creditsPerAd, balance: sub.assessmentCredits };
}

export function simulateUpgrade(student, planId, billing = "monthly", bundleId = null) {
  const plan = PLANS[planId];
  if (!plan) return false;
  const sub = ensureSubscription(student);
  sub.plan = planId;
  sub.billing = planId === "family" ? "annual" : billing;
  if (bundleId) sub.bundle = bundleId;
  if (plan.assessmentCredits > 0) sub.assessmentCredits = plan.assessmentCredits;
  if (planId === "learner" && !sub.bundle) {
    sub.bundle = defaultBundleForGrade(student.grade ?? 11).id;
  }
  return true;
}

export function planSummary(student) {
  const sub = ensureSubscription(student);
  const plan = planOf(student);
  return {
    planId: plan.id,
    name: plan.name,
    tagline: plan.tagline,
    price: priceLabel(plan.id, sub.billing),
    credits: sub.assessmentCredits || 0,
    subjects: allowedSubjects(student, student.grade),
    adsLeft: plan.ads ? Math.max(0, plan.rewardedAdsPerDay - (sub.adsWatchedToday || 0)) : 0
  };
}
