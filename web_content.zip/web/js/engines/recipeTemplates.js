/**
 * learnyZ — Grid-based diagram recipe templates.
 *
 * Design principle:
 *  1. Describe the finished diagram (what a CAPS textbook would show).
 *  2. Break it into named PARTS (organelles, chambers, stages, labels).
 *  3. Place each part on a logical GRID (rows × cols) with span.
 *  4. The engine maps grid cells → canvas rectangles, then draws each part
 *     inside its slot so leaders and shapes do not collide.
 *
 * Recipes may be long: they encode educational structure, not just pixels.
 */

/** Convert grid slot → pixel rect inside a padded canvas box */
export function slotRect(w, h, slot, grid = { rows: 6, cols: 6 }, pad = 12) {
  const { rows, cols } = grid;
  const innerW = w - pad * 2;
  const innerH = h - pad * 2 - 18; // title band
  const cellW = innerW / cols;
  const cellH = innerH / rows;
  const c = slot.col ?? 0;
  const r = slot.row ?? 0;
  const cs = slot.colSpan ?? 1;
  const rs = slot.rowSpan ?? 1;
  return {
    x: pad + c * cellW,
    y: pad + 18 + r * cellH,
    w: cs * cellW,
    h: rs * cellH,
    cx: pad + c * cellW + (cs * cellW) / 2,
    cy: pad + 18 + r * cellH + (rs * cellH) / 2
  };
}

/**
 * RECIPE DESCRIPTIONS + PART LAYOUTS
 * Each recipe:
 *  - description: textbook intent
 *  - look: how the finished figure should read
 *  - grid: rows/cols for part placement
 *  - parts: id, label, role, slot, draw hint
 */
export const RECIPES = {
  cell_plant: {
    id: "cell_plant",
    name: "Plant cell",
    group: "Life Sciences",
    description:
      "CAPS / exam-style labelled plant cell. Learners must distinguish cell wall from membrane, " +
      "identify the large permanent vacuole, nucleus with nucleolus, rough ER (with ribosomes), " +
      "Golgi body, mitochondria with cristae, chloroplasts, and cytoplasm. Structure is linked to function " +
      "(wall → support; chloroplast → photosynthesis; vacuole → turgor; mitochondrion → ATP; ER/Golgi → protein path).",
    look:
      "Triple rounded rectangular walls (outer wall emphasised). Large pale-blue vacuole on the left-centre. " +
      "Nucleus upper-right with dark nucleolus. Concentric rough-ER arcs with ribosome dots. Stacked Golgi " +
      "cisternae below the nucleus. Several mitochondria with internal cristae and green chloroplasts. " +
      "Leader lines to labels C (rough ER) and D (Golgi) and named organelles. Title states CAPS parts.",
    grid: { rows: 6, cols: 6 },
    parts: [
      { id: "wall", label: "cell wall", role: "boundary", slot: { row: 0, col: 0, rowSpan: 6, colSpan: 6 }, draw: "outer_wall" },
      { id: "membrane", label: "cell membrane", role: "boundary", slot: { row: 0, col: 0, rowSpan: 6, colSpan: 6 }, draw: "inset_membrane" },
      { id: "cytoplasm", label: "cytoplasm", role: "matrix", slot: { row: 1, col: 1, rowSpan: 4, colSpan: 4 }, draw: "fill_matrix" },
      { id: "vacuole", label: "vacuole", role: "organelle", slot: { row: 1, col: 0, rowSpan: 4, colSpan: 3 }, draw: "large_oval" },
      { id: "nucleus", label: "nucleus", role: "organelle", slot: { row: 0, col: 3, rowSpan: 2, colSpan: 3 }, draw: "nucleus_blob" },
      { id: "nucleolus", label: "nucleolus", role: "organelle", slot: { row: 0, col: 3, rowSpan: 2, colSpan: 3 }, draw: "nucleolus_dot" },
      { id: "rough_er", label: "rough ER", role: "organelle", slot: { row: 1, col: 3, rowSpan: 2, colSpan: 3 }, draw: "er_arcs" },
      { id: "golgi", label: "Golgi body", role: "organelle", slot: { row: 3, col: 3, rowSpan: 1, colSpan: 3 }, draw: "golgi_stack" },
      { id: "mitochondria", label: "mitochondria", role: "organelle", slot: { row: 4, col: 0, rowSpan: 2, colSpan: 2 }, draw: "mito_cluster" },
      { id: "chloroplast", label: "chloroplast", role: "organelle", slot: { row: 4, col: 4, rowSpan: 2, colSpan: 2 }, draw: "chloro_cluster" }
    ]
  },

  cell_animal: {
    id: "cell_animal",
    name: "Animal cell",
    group: "Life Sciences",
    description:
      "Generalised animal cell for comparison with the plant cell. No cell wall or chloroplasts. " +
      "Emphasis on membrane, nucleus, mitochondria (energy), and cytoplasm. CAPS expects learners " +
      "to contrast the two cell types in a table and on diagrams.",
    look:
      "Softer irregular oval outline (membrane only). Central-ish nucleus. Several bean-shaped " +
      "mitochondria. No large vacuole. Labels with leaders. Title: “Animal cell (parts on grid)”.",
    grid: { rows: 5, cols: 5 },
    parts: [
      { id: "membrane", label: "cell membrane", role: "boundary", slot: { row: 0, col: 0, rowSpan: 5, colSpan: 5 }, draw: "soft_oval" },
      { id: "cytoplasm", label: "cytoplasm", role: "matrix", slot: { row: 1, col: 1, rowSpan: 3, colSpan: 3 }, draw: "fill_matrix" },
      { id: "nucleus", label: "nucleus", role: "organelle", slot: { row: 1, col: 1, rowSpan: 2, colSpan: 2 }, draw: "nucleus_blob" },
      { id: "mitochondria", label: "mitochondria", role: "organelle", slot: { row: 3, col: 2, rowSpan: 1, colSpan: 2 }, draw: "mito_cluster" }
    ]
  },

  organ_heart: {
    id: "organ_heart",
    name: "Heart (four chambers)",
    group: "Life Sciences",
    description:
      "Frontal schematic of the human heart showing four chambers and the aorta. CAPS requires " +
      "learners to name right/left atrium and ventricle and relate oxygenated vs deoxygenated blood flow. " +
      "This is a labelled diagram, not a realistic anatomical plate.",
    look:
      "Heart silhouette. Vertical septum line and horizontal valve line dividing four chambers. " +
      "Aorta arch rising from the left ventricle region. Chamber labels inside or with short leaders. " +
      "Title: “Heart — chambers”.",
    grid: { rows: 4, cols: 4 },
    parts: [
      { id: "outline", label: "heart outline", role: "structure", slot: { row: 0, col: 0, rowSpan: 4, colSpan: 4 }, draw: "heart_outline" },
      { id: "ra", label: "right atrium", role: "chamber", slot: { row: 0, col: 0, rowSpan: 2, colSpan: 2 }, draw: "chamber_label" },
      { id: "la", label: "left atrium", role: "chamber", slot: { row: 0, col: 2, rowSpan: 2, colSpan: 2 }, draw: "chamber_label" },
      { id: "rv", label: "right ventricle", role: "chamber", slot: { row: 2, col: 0, rowSpan: 2, colSpan: 2 }, draw: "chamber_label" },
      { id: "lv", label: "left ventricle", role: "chamber", slot: { row: 2, col: 2, rowSpan: 2, colSpan: 2 }, draw: "chamber_label" },
      { id: "aorta", label: "aorta", role: "vessel", slot: { row: 0, col: 2, rowSpan: 1, colSpan: 2 }, draw: "aorta_arch" }
    ]
  },

  organ_digestive: {
    id: "organ_digestive",
    name: "Digestive system",
    group: "Life Sciences",
    description:
      "Simplified human digestive tract for CAPS: mouth → oesophagus → stomach → small intestine → " +
      "large intestine, with liver indicated. Learners sequence organs and match functions (e.g. absorption in small intestine).",
    look:
      "Vertical flow of organ shapes down the centre column. Mouth at top, then tube, bag-shaped stomach, " +
      "coiled small intestine, framing large intestine, liver lobe to the side. Labels on the right. " +
      "Title: “Digestive system (parts)”.",
    grid: { rows: 8, cols: 4 },
    parts: [
      { id: "mouth", label: "mouth", role: "organ", slot: { row: 0, col: 1, rowSpan: 1, colSpan: 2 }, draw: "mouth_oval" },
      { id: "oesophagus", label: "oesophagus", role: "organ", slot: { row: 1, col: 1, rowSpan: 1, colSpan: 2 }, draw: "tube" },
      { id: "stomach", label: "stomach", role: "organ", slot: { row: 2, col: 1, rowSpan: 2, colSpan: 2 }, draw: "stomach_bag" },
      { id: "liver", label: "liver", role: "organ", slot: { row: 2, col: 0, rowSpan: 2, colSpan: 1 }, draw: "liver_lobe" },
      { id: "small_intestine", label: "small intestine", role: "organ", slot: { row: 4, col: 1, rowSpan: 2, colSpan: 2 }, draw: "coils" },
      { id: "large_intestine", label: "large intestine", role: "organ", slot: { row: 6, col: 0, rowSpan: 2, colSpan: 4 }, draw: "frame_intestine" }
    ]
  },

  mitosis_stages: {
    id: "mitosis_stages",
    name: "Mitosis stages",
    group: "Life Sciences",
    description:
      "Four-panel sequence: prophase, metaphase, anaphase, telophase. Each panel is a part of the " +
      "overall recipe. Chromosome behaviour is stylised for CAPS (condensation, equatorial alignment, " +
      "separation, nuclear reformation).",
    look:
      "Four equal columns. Each has a stage title and a simple chromosome diagram. Shared baseline title. " +
      "No overlapping panels; clear gutters between columns.",
    grid: { rows: 1, cols: 4 },
    parts: [
      { id: "prophase", label: "prophase", role: "stage", slot: { row: 0, col: 0, rowSpan: 1, colSpan: 1 }, draw: "stage_prophase" },
      { id: "metaphase", label: "metaphase", role: "stage", slot: { row: 0, col: 1, rowSpan: 1, colSpan: 1 }, draw: "stage_metaphase" },
      { id: "anaphase", label: "anaphase", role: "stage", slot: { row: 0, col: 2, rowSpan: 1, colSpan: 1 }, draw: "stage_anaphase" },
      { id: "telophase", label: "telophase", role: "stage", slot: { row: 0, col: 3, rowSpan: 1, colSpan: 1 }, draw: "stage_telophase" }
    ]
  },

  atom_bohr: {
    id: "atom_bohr",
    name: "Atom (Bohr model)",
    group: "Natural Sciences",
    description:
      "Bohr-style atom for CAPS Natural Sciences / introductory Physical Sciences: central nucleus " +
      "(protons + neutrons) and electrons on circular energy shells. Not to scale; used to teach " +
      "shells and electron arrangement, not quantum mechanics.",
    look:
      "Orange nucleus at centre with “p⁺ n⁰”. Two or three concentric grey orbits. Blue electron dots " +
      "on orbits. Leader labels for nucleus and electron. Title centred at top.",
    grid: { rows: 5, cols: 5 },
    parts: [
      { id: "shell_outer", label: "energy shell", role: "orbit", slot: { row: 0, col: 0, rowSpan: 5, colSpan: 5 }, draw: "shells" },
      { id: "nucleus", label: "nucleus", role: "core", slot: { row: 2, col: 2, rowSpan: 1, colSpan: 1 }, draw: "nucleus_core" },
      { id: "electron", label: "electron", role: "shell", slot: { row: 0, col: 0, rowSpan: 5, colSpan: 5 }, draw: "electrons" }
    ]
  },

  solar_system: {
    id: "solar_system",
    name: "Solar system (layout)",
    group: "Natural Sciences",
    description:
      "Educational layout of the Sun and planets (not to scale). Foundation grades may show only the " +
      "inner planets; senior grades show more. Used for order from the Sun and relative positions.",
    look:
      "Yellow Sun near centre-left or centre. Concentric faint orbits. Coloured planet disks with short labels. " +
      "Clear separation so labels do not overlap disks.",
    grid: { rows: 3, cols: 8 },
    parts: [
      { id: "sun", label: "Sun", role: "star", slot: { row: 1, col: 0, rowSpan: 1, colSpan: 1 }, draw: "sun_disk" },
      { id: "mercury", label: "Mercury", role: "planet", slot: { row: 1, col: 1, rowSpan: 1, colSpan: 1 }, draw: "planet_disk" },
      { id: "venus", label: "Venus", role: "planet", slot: { row: 1, col: 2, rowSpan: 1, colSpan: 1 }, draw: "planet_disk" },
      { id: "earth", label: "Earth", role: "planet", slot: { row: 1, col: 3, rowSpan: 1, colSpan: 1 }, draw: "planet_disk" },
      { id: "mars", label: "Mars", role: "planet", slot: { row: 1, col: 4, rowSpan: 1, colSpan: 1 }, draw: "planet_disk" },
      { id: "jupiter", label: "Jupiter", role: "planet", slot: { row: 1, col: 5, rowSpan: 1, colSpan: 1 }, draw: "planet_disk" },
      { id: "saturn", label: "Saturn", role: "planet", slot: { row: 1, col: 6, rowSpan: 1, colSpan: 1 }, draw: "planet_disk" }
    ]
  },

  plant_structure: {
    id: "plant_structure",
    name: "Plant structure",
    group: "Natural Sciences",
    description:
      "Whole-plant schematic: roots, stem, leaves, and optionally flower. CAPS links each part to function " +
      "(roots absorb water; stem support/transport; leaf photosynthesis; flower reproduction).",
    look:
      "Roots in lower third (branched lines). Vertical stem. Pair of leaves mid-height. Simple flower at top " +
      "for intermediate+. Labels left/right with leaders.",
    grid: { rows: 6, cols: 3 },
    parts: [
      { id: "flower", label: "flower", role: "part", slot: { row: 0, col: 1, rowSpan: 1, colSpan: 1 }, draw: "flower_top" },
      { id: "leaf", label: "leaf", role: "part", slot: { row: 1, col: 0, rowSpan: 2, colSpan: 3 }, draw: "leaves" },
      { id: "stem", label: "stem", role: "part", slot: { row: 1, col: 1, rowSpan: 3, colSpan: 1 }, draw: "stem_line" },
      { id: "roots", label: "roots", role: "part", slot: { row: 4, col: 0, rowSpan: 2, colSpan: 3 }, draw: "root_system" }
    ]
  },

  lever: {
    id: "lever",
    name: "Lever",
    group: "Technology",
    description:
      "Class 1 lever schematic for Technology: beam, fulcrum (pivot), load and effort. Learners identify " +
      "class and compute ideal mechanical advantage ≈ load/effort.",
    look:
      "Horizontal beam. Triangle fulcrum under centre (or offset). Load block one side, effort the other. " +
      "Clear labels. Title: “Lever”.",
    grid: { rows: 3, cols: 5 },
    parts: [
      { id: "beam", label: "beam", role: "structure", slot: { row: 1, col: 0, rowSpan: 1, colSpan: 5 }, draw: "beam" },
      { id: "fulcrum", label: "fulcrum", role: "pivot", slot: { row: 2, col: 2, rowSpan: 1, colSpan: 1 }, draw: "fulcrum_triangle" },
      { id: "load", label: "load", role: "force", slot: { row: 0, col: 0, rowSpan: 1, colSpan: 1 }, draw: "load_block" },
      { id: "effort", label: "effort", role: "force", slot: { row: 0, col: 4, rowSpan: 1, colSpan: 1 }, draw: "effort_block" }
    ]
  },

  circle_theorem_centre: {
    id: "circle_theorem_centre",
    name: "Angle at the centre",
    group: "Euclidean geometry",
    description:
      "Circle with centre O, arc BC, inscribed angle BAC and central angle BOC. Classic CAPS theorem: " +
      "the angle at the centre is twice the angle at the circumference subtended by the same arc.",
    look:
      "Circle centred on canvas. Point O marked at exact centre. Points B and C on circumference. " +
      "Radii OB, OC drawn through O (must pass exactly through centre). Chord BA, CA. Arc BC highlighted. " +
      "Angle marks at O and A. No overlapping radii; clean joins at O and on the circumference.",
    grid: { rows: 4, cols: 4 },
    parts: [
      { id: "circle", label: "circle", role: "structure", slot: { row: 0, col: 0, rowSpan: 4, colSpan: 4 }, draw: "circle_outline" },
      { id: "centre", label: "O (centre)", role: "point", slot: { row: 1, col: 1, rowSpan: 2, colSpan: 2 }, draw: "centre_dot" },
      { id: "radii", label: "radii OB, OC", role: "line", slot: { row: 0, col: 0, rowSpan: 4, colSpan: 4 }, draw: "radii_from_centre" },
      { id: "chord", label: "chords / angle at A", role: "line", slot: { row: 0, col: 0, rowSpan: 4, colSpan: 4 }, draw: "inscribed_angle" }
    ]
  },

  water_cycle: {
    id: "water_cycle",
    name: "Water cycle",
    group: "Natural Sciences",
    description:
      "Simplified water cycle: evaporation, condensation, precipitation, collection. Used in Natural Sciences " +
      "and Geography foundation topics.",
    look:
      "Sun top-left, sea bottom, cloud top-right, rain arrows, ground/collection bottom-right. Cycle arrows. " +
      "Four process labels in grid corners.",
    grid: { rows: 3, cols: 3 },
    parts: [
      { id: "sun", label: "sun / heat", role: "driver", slot: { row: 0, col: 0, rowSpan: 1, colSpan: 1 }, draw: "sun_small" },
      { id: "evaporation", label: "evaporation", role: "process", slot: { row: 1, col: 0, rowSpan: 1, colSpan: 1 }, draw: "up_arrows" },
      { id: "condensation", label: "condensation", role: "process", slot: { row: 0, col: 2, rowSpan: 1, colSpan: 1 }, draw: "cloud" },
      { id: "precipitation", label: "precipitation", role: "process", slot: { row: 1, col: 2, rowSpan: 1, colSpan: 1 }, draw: "rain" },
      { id: "collection", label: "collection", role: "process", slot: { row: 2, col: 0, rowSpan: 1, colSpan: 3 }, draw: "sea_ground" }
    ]
  },

  simple_circuit: {
    id: "simple_circuit",
    name: "Simple electric circuit",
    group: "Natural Sciences",
    description:
      "CAPS circuit diagram: closed path with cell (long/short plates), open switch on the top wire, and lamp " +
      "(circle with cross). Series adds a resistor zigzag; parallel splits into lamp and resistor branches. " +
      "Learners must recognise a closed loop, series vs parallel, and that current needs a complete path.",
    look:
      "Rectangular wire loop with clean corner joins. Cell on the left vertical. Switch gap on the top wire " +
      "with angled arm. Lamp as circle with cross on the right. Optional parallel branches. Component labels.",
    grid: { rows: 3, cols: 4 },
    parts: [
      { id: "wires", label: "connecting wires", role: "path", slot: { row: 0, col: 0, rowSpan: 3, colSpan: 4 }, draw: "wire_loop" },
      { id: "cell", label: "cell", role: "component", slot: { row: 1, col: 0, rowSpan: 1, colSpan: 1 }, draw: "cell_symbol" },
      { id: "switch", label: "switch", role: "component", slot: { row: 0, col: 1, rowSpan: 1, colSpan: 2 }, draw: "switch_symbol" },
      { id: "lamp", label: "lamp", role: "component", slot: { row: 1, col: 3, rowSpan: 1, colSpan: 1 }, draw: "lamp_symbol" }
    ]
  }
};

export function listRecipes() {
  return Object.values(RECIPES);
}

export function recipeById(id) {
  return RECIPES[id] || null;
}
