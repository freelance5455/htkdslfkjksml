/**
 * Grade 12 CAPS problem recipes — many distinct problem TYPES per topic.
 * Engines shuffle across types (not only values of one template).
 * Multi-part structures mirror DBE/IEB Paper 1 & Paper 2 style (1.1, 1.2, …).
 * Generative only — not copied from copyrighted past-paper PDFs.
 */

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function round2(n) { return Math.round(n * 100) / 100; }
function round1(n) { return Math.round(n * 10) / 10; }

function Q(topic, question, answer, difficulty, hint, explanation, marks = 3, diagram = null) {
  let exp = explanation || "";
  if (exp && !/\n\s*\d+[.)]/.test(exp) && exp.includes("\n")) {
    exp = exp.split("\n").filter(Boolean).map((line, i) => `${i + 1}. ${line}`).join("\n");
  } else if (exp && !/\n/.test(exp)) {
    exp = `1. ${hint || "Use the relevant formula or theorem."}\n2. ${exp}\n3. Final answer: ${answer}`;
  }
  return {
    id: `g12_${topic}_${ri(10000, 99999)}`,
    topic,
    topic_name: topic.replaceAll("_", " "),
    question,
    answer: String(answer),
    difficulty,
    hint: hint || "",
    explanation: exp,
    steps: exp,
    marks,
    diagram,
    recipe: true,
    exam_style: true
  };
}

const _lastType = new Map();
function pickType(topic, types) {
  if (!types.length) return null;
  const last = _lastType.get(topic);
  let pool = types;
  if (types.length > 1 && last != null) {
    pool = types.filter((_, i) => i !== last);
    if (!pool.length) pool = types;
  }
  const t = choice(pool);
  _lastType.set(topic, types.indexOf(t));
  return t;
}

// ═══════════════════════════════════════════════════════════════════════════
// MATHEMATICS — CAPS Grade 12 multi-type exam recipes
// ═══════════════════════════════════════════════════════════════════════════

const MATHS = {
  // ── Sequences and series ────────────────────────────────────────────────
  sequences_series: [
    (d) => {
      const a = ri(2, 9), r = choice([2, 3, -2]);
      const n = ri(5, 8);
      const terms = [a];
      for (let i = 1; i < 4; i++) terms.push(terms[i - 1] * r);
      return Q("sequences_series",
        `Given the geometric sequence: ${terms.join("; ")}; …\nDetermine the ${n}th term.`,
        a * (r ** (n - 1)), d, "T_n = a·r^{n−1}",
        `a = ${a}, r = ${r}\nT_${n} = ${a}·(${r})^{${n - 1}} = ${a * (r ** (n - 1))}`, 3);
    },
    (d) => {
      const a = ri(3, 12), diff = ri(2, 7), n = ri(10, 18);
      return Q("sequences_series",
        `Arithmetic sequence: first term ${a}, common difference ${diff}.\nFind T_${n}.`,
        a + (n - 1) * diff, d, "T_n = a + (n−1)d",
        `T_${n} = ${a} + (${n}−1)(${diff}) = ${a + (n - 1) * diff}`, 2);
    },
    (d) => {
      const a = ri(2, 6), r = 2, n = ri(5, 8);
      const s = a * ((r ** n) - 1) / (r - 1);
      return Q("sequences_series",
        `Sum the first ${n} terms of the geometric series with a = ${a} and r = ${r}.`,
        s, d, "S_n = a(r^n − 1)/(r − 1) for r ≠ 1",
        `S_${n} = ${a}(${r}^${n} − 1)/(${r} − 1) = ${s}`, 4);
    },
    (d) => {
      const a = ri(5, 20), dlt = ri(3, 9), n = ri(12, 20);
      const s = (n / 2) * (2 * a + (n - 1) * dlt);
      return Q("sequences_series",
        `Find S_${n} for the AP with a = ${a} and d = ${dlt}.`,
        s, d, "S_n = n/2 [2a + (n−1)d]",
        `S_${n} = ${n}/2 [2(${a}) + (${n}−1)(${dlt})] = ${s}`, 3);
    },
    (d) => {
      const a = ri(2, 5);
      return Q("sequences_series",
        `For the infinite geometric series with a = ${a} and r = 1/2, determine S_∞.`,
        2 * a, d, "S_∞ = a/(1−r) when |r| < 1",
        `S_∞ = ${a}/(1 − 1/2) = ${2 * a}`, 3);
    },
    (d) => {
      const a = ri(1, 4), dlt = ri(2, 5);
      return Q("sequences_series",
        `Which term of the sequence ${a}; ${a + dlt}; ${a + 2 * dlt}; … is equal to ${a + 9 * dlt}?`,
        10, d, "Set T_n = target and solve for n.",
        `a+(n−1)d = ${a + 9 * dlt} → (n−1)${dlt} = ${9 * dlt} → n = 10`, 3);
    },
    (d) => Q("sequences_series",
      "Prove that the sequence defined by T_n = 3n − 1 is arithmetic and state the common difference.",
      "d = 3", d, "Show T_{n+1} − T_n is constant.",
      "T_{n+1} − T_n = (3(n+1)−1) − (3n−1) = 3. Common difference d = 3.", 4),
    (d) => {
      return Q("sequences_series",
        `A ball drops from 5 m and rebounds to 40% of its previous height each time.\nFind the total distance travelled before it comes to rest (infinite series).`,
        round2(5 + 2 * 5 * 0.4 / (1 - 0.4)), d,
        "First drop + 2 × infinite rebound series.",
        "First drop 5 m; rebounds form GP with a = 2, r = 0.4.\nTotal = 5 + 2·(2)/(1−0.4) = 5 + 2·(10/3) ≈ " + round2(5 + 20 / 3), 5);
    },
    // Long multi-part CAPS style
    (d) => Q("sequences_series",
      `An arithmetic sequence has T_3 = 11 and T_7 = 23.\n1.1 Determine the first term and the common difference.\n1.2 Find T_20.\n1.3 Which term is equal to 59?\n1.4 Calculate S_15.`,
      "1.1 a=5, d=3; 1.2 62; 1.3 T_19; 1.4 390", d,
      "T_n = a+(n−1)d; S_n = n/2[2a+(n−1)d]",
      "1.1 T_7 − T_3 = 4d = 12 → d = 3. a + 2d = 11 → a = 5.\n1.2 T_20 = 5 + 19·3 = 62.\n1.3 5+(n−1)·3 = 59 → n−1 = 18 → n = 19.\n1.4 S_15 = 15/2 [2·5 + 14·3] = 15/2 · 52 = 390.",
      10),
    (d) => Q("sequences_series",
      `A geometric sequence has first term 8 and common ratio 1/2.\n2.1 Write down the first four terms.\n2.2 Find the sum of the first 6 terms.\n2.3 Determine S_∞.\n2.4 How many terms are needed so that S_n > 15.5?`,
      "2.1 8; 4; 2; 1; 2.2 15.75; 2.3 16; 2.4 n ≥ 5", d,
      "S_n = a(1−r^n)/(1−r); S_∞ = a/(1−r)",
      "2.1 8, 4, 2, 1.\n2.2 S_6 = 8(1−(1/2)^6)/(1/2) = 16(1−1/64) = 15.75.\n2.3 S_∞ = 8/(1/2) = 16.\n2.4 16(1−2^{−n}) > 15.5 → 1−2^{−n} > 15.5/16 → n ≥ 5.",
      10),
    (d) => Q("sequences_series",
      `The sum of the first n terms of a sequence is S_n = 2n² + 3n.\n3.1 Find an expression for T_n.\n3.2 Show that the sequence is arithmetic and state the common difference.\n3.3 Find the sum of the terms from T_10 to T_20 inclusive.`,
      "3.1 T_n = 4n + 1; 3.2 d = 4; 3.3 671", d,
      "T_n = S_n − S_{n−1} (S_0 = 0)",
      "3.1 T_n = (2n²+3n) − (2(n−1)²+3(n−1)) = 4n+1.\n3.2 T_{n+1}−T_n = 4 → arithmetic, d = 4.\n3.3 S_20 − S_9 = (2·400+60) − (2·81+27) = 860 − 189 = 671.",
      9),
    (d) => {
      const a = ri(3, 8), dlt = ri(2, 5);
      return Q("sequences_series",
        `The first term of an AP is ${a} and the common difference is ${dlt}.\n4.1 Write down the general term T_n.\n4.2 Find the 25th term.\n4.3 Determine how many terms must be added to obtain a sum of at least ${a * 30}.`,
        `4.1 T_n = ${a}+(n−1)${dlt}; 4.2 ${a + 24 * dlt}; 4.3 calculate n from S_n ≥ ${a * 30}`, d,
        "T_n and S_n formulae; solve quadratic inequality if needed.",
        `4.1 T_n = ${a}+(n−1)·${dlt}.\n4.2 T_25 = ${a}+24·${dlt} = ${a + 24 * dlt}.\n4.3 S_n = n/2[2·${a}+(n−1)·${dlt}] ≥ ${a * 30}; solve for least integer n.`,
        8);
    },
    (d) => Q("sequences_series",
      `A geometric series has a = 5 and r = −1/2.\n5.1 Write the first five terms.\n5.2 Find S_8.\n5.3 Does S_∞ exist? If so, calculate it. If not, explain.`,
      "5.1 5; −2.5; 1.25; −0.625; 0.3125; 5.2 calculate; 5.3 Yes, S_∞ = 10/3", d,
      "|r| < 1 for infinite sum.",
      "5.1 5, −5/2, 5/4, −5/8, 5/16.\n5.2 S_8 = 5[1−(−1/2)^8]/(1−(−1/2)) = 5(1−1/256)/(3/2).\n5.3 |r|=1/2<1 → S_∞ = 5/(1−(−1/2)) = 5/(3/2) = 10/3.",
      8),
    (d) => Q("sequences_series",
      `Consider the series 3 + 6 + 12 + 24 + …\n6.1 Is this arithmetic or geometric? State the common ratio or difference.\n6.2 Find the 10th term.\n6.3 Find S_10.\n6.4 Explain why this series does not have a finite infinite sum.`,
      "6.1 Geometric, r=2; 6.2 3·2^9 = 1536; 6.3 3(2^{10}−1)=3069; 6.4 |r|=2>1", d,
      "Identify type; T_n and S_n for GP; condition for S_∞.",
      "6.1 GP with r = 2.\n6.2 T_10 = 3·2^9 = 1536.\n6.3 S_10 = 3(2^{10}−1)/(2−1) = 3069.\n6.4 |r| = 2 > 1 → terms grow without bound; S_∞ does not exist (finite).",
      8)
  ],

  // ── Functions and graphs ────────────────────────────────────────────────
  functions_graphs: [
    (d) => {
      const a = ri(1, 4), q = ri(-5, 5);
      return Q("functions_graphs",
        `For f(x) = ${a}/x + ${q}, state the equations of the asymptotes.`,
        `x = 0; y = ${q}`, d, "Vertical where denominator is 0; horizontal y = q.",
        `Vertical: x = 0. Horizontal: y = ${q}.`, 2);
    },
    (d) => {
      const p = ri(1, 3), q = ri(-2, 2);
      return Q("functions_graphs",
        `f(x) = −(x − ${p})² + ${q}. Determine the turning point and the range.`,
        `TP (${p}; ${q}); y ≤ ${q}`, d, "Vertex form y = a(x−p)² + q.",
        `Turning point (${p}; ${q}). Since a < 0, range y ≤ ${q}.`, 3);
    },
    (d) => {
      const k = ri(2, 5);
      return Q("functions_graphs",
        `Solve for x if 2^x = ${2 ** k}.`,
        k, d, "Express both sides with the same base.",
        `2^x = 2^${k} → x = ${k}`, 2);
    },
    (d) => Q("functions_graphs",
      `f(x) = 2/(x−1) − 3.\n1.1 Write down the equations of the asymptotes.\n1.2 Determine the intercepts with the axes.\n1.3 Sketch the graph, showing asymptotes and intercepts.\n1.4 For which values of x is f(x) > 0?`,
      "1.1 x=1, y=−3; 1.2 x-int (5/3;0), y-int (0;−5); 1.4 (1; 5/3)", d,
      "VA where denom=0; HA y=q; set f=0 and x=0; sign analysis.",
      "1.1 VA: x=1; HA: y=−3.\n1.2 f=0 → 2/(x−1)=3 → x=5/3. f(0)=−2−3=−5.\n1.4 Hyperbola branch: f>0 on (1; 5/3).",
      9),
    (d) => Q("functions_graphs",
      `g(x) = −(x+2)² + 5.\n2.1 Write down the turning point.\n2.2 Determine the range of g.\n2.3 Solve g(x) = 1.\n2.4 For which values of x is g decreasing?`,
      "2.1 (−2;5); 2.2 y≤5; 2.3 x=−4 or 0; 2.4 x>−2", d,
      "Vertex form; a<0 → range below vertex; set equal; decreasing right of TP.",
      "2.1 TP (−2;5).\n2.2 Range (−∞;5].\n2.3 −(x+2)²+5=1 → (x+2)²=4 → x=0 or −4.\n2.4 Opens down → decreasing for x>−2.",
      8),
    (d) => Q("functions_graphs",
      `h(x) = 2^{x−1} − 4.\n3.1 Write down the equation of the horizontal asymptote.\n3.2 Calculate the y-intercept.\n3.3 Solve h(x) = 0.\n3.4 Sketch, showing asymptote and intercepts.`,
      "3.1 y=−4; 3.2 (0; −3.5); 3.3 x=3", d,
      "Exponential base >1 shifted; set h=0.",
      "3.1 HA: y=−4.\n3.2 h(0)=2^{−1}−4=0.5−4=−3.5? 2^{−1}=1/2 → −3.5. Correct: (0; −3.5).\n3.3 2^{x−1}=4=2^2 → x−1=2 → x=3.",
      8),
    (d) => {
      const a = ri(1, 3);
      return Q("functions_graphs",
        `The function f(x) = ${a}/(x + 2) + 1 is given.\n4.1 State the domain of f.\n4.2 Determine the equations of the asymptotes.\n4.3 Find the intercepts.\n4.4 Write down the range of f.`,
        `4.1 x≠−2; 4.2 x=−2, y=1; 4.3 calculate; 4.4 y≠1`, d,
        "Domain excludes vertical asymptote; HA is y = q.",
        `4.1 x ≠ −2.\n4.2 VA x=−2; HA y=1.\n4.3 y-int: f(0)=${a}/2+1; x-int: ${a}/(x+2)+1=0 → x+2=−${a} → x=−2−${a}.\n4.4 y ≠ 1.`,
        8);
    },
    (d) => Q("functions_graphs",
      `Given f(x) = x² − 4x − 5.\n5.1 Write f in the form f(x) = (x − p)² + q.\n5.2 Hence state the turning point.\n5.3 Determine the roots of f(x) = 0.\n5.4 Sketch the parabola showing intercepts and TP.`,
      "5.1 (x−2)² − 9; 5.2 (2;−9); 5.3 x=−1 or 5", d,
      "Complete the square; factorise.",
      "5.1 x²−4x−5 = (x−2)²−4−5 = (x−2)²−9.\n5.2 TP (2;−9).\n5.3 (x−2)²=9 → x−2=±3 → x=5 or −1.",
      9),
    (d) => Q("functions_graphs",
      `Sketch the graph of y = |x − 2| − 1. Indicate intercepts and the vertex clearly.\nState the range.`,
      "Vertex (2;−1); x-int at 1 and 3; y-int −1? |0−2|−1=1; range y≥−1", d,
      "Absolute value V-shape shifted.",
      "Vertex at (2;−1). Range [−1; ∞). Intercepts: y-int (0;1); x-int when |x−2|=1 → x=1 or 3.",
      6)
  ],

  // ── Algebra and differential calculus ───────────────────────────────────
  algebra_calculus: [
    (d) => {
      const a = ri(1, 4), b = ri(1, 5);
      return Q("algebra_calculus",
        `Differentiate y = ${a}x^3 − ${b}x from first principles is lengthy; using rules find dy/dx.`,
        `${3 * a}x² − ${b}`, d, "Power rule term by term.",
        `d/dx(${a}x^3) = ${3 * a}x²; d/dx(−${b}x) = −${b}.`, 2);
    },
    (d) => Q("algebra_calculus",
      "Differentiate y = 1/x from first principles.",
      "−1/x²", d, "f′(x)=lim [f(x+h)−f(x)]/h",
      "f(x+h)=1/(x+h). Difference = [x−(x+h)]/[x(x+h)] = −h/[x(x+h)].\nDivide by h: −1/[x(x+h)]. Limit h→0 → −1/x².", 5),
    (d) => Q("algebra_calculus",
      "Find the points on y = x³ − 3x where the tangent is horizontal.",
      "(−1;2) and (1;−2)", d, "Set dy/dx = 0.",
      "dy/dx = 3x²−3 = 0 → x²=1 → x=±1. y(−1)=2; y(1)=−2.", 4),
    (d) => Q("algebra_calculus",
      "If s(t) = 4t − t², find the maximum displacement for t ≥ 0.",
      "4 (at t=2)", d, "ds/dt=0 for stationary; second derivative test.",
      "v = 4−2t = 0 → t=2. s(2)=4. a=−2 <0 → maximum.", 4),
    (d) => Q("algebra_calculus",
      "Determine d/dx [√x].",
      "1/(2√x)", d, "x^{1/2}",
      "d/dx x^{1/2} = (1/2)x^{−1/2} = 1/(2√x).", 2),
    (d) => Q("algebra_calculus",
      "The gradient of the tangent to y = ax² + bx at x = 1 is 5. If the curve passes through (1; 3), find a and b.",
      "a=2, b=1 (or consistent pair)", d, "y′=2ax+b; y(1)=3.",
      "y′=2ax+b. At x=1: 2a+b=5. y(1)=a+b=3. Subtract: a=2 → b=1.", 5),
    (d) => Q("algebra_calculus",
      "Use the product rule to differentiate y = x² sin x (leave in terms of sin and cos).",
      "2x sin x + x² cos x", d, "Product rule (uv)′ = u′v + uv′.",
      "u=x², v=sin x → u′=2x, v′=cos x → 2x sin x + x² cos x.", 3),
    (d) => Q("algebra_calculus",
      "Find the equation of the normal to y = x² at x = 1.",
      "y = −½x + 3/2", d, "m_normal = −1/m_tangent.",
      "y′=2x → m_t=2 at x=1. Point (1;1). m_n=−1/2.\ny−1=−½(x−1) → y=−½x+3/2.", 4),
    (d) => Q("algebra_calculus",
      "Show that f(x) = x³ − 3x + 1 has a root in (0; 1) (sign-change argument).",
      "f(0)=1>0, f(1)=−1<0 → root in (0;1) by intermediate value theorem", d,
      "Evaluate endpoints; continuous polynomial.",
      "f continuous on [0;1]. f(0)=1 > 0, f(1)=−1 < 0. By IVT there is at least one c∈(0;1) with f(c)=0.", 4),
    // Long multi-part exam
    (d) => Q("algebra_calculus",
      `QUESTION 1 (CAPS multi-part)\n1.1 Solve for x: x² − 5x + 6 = 0.\n1.2 Hence, or otherwise, solve: (x − 2)(x − 3) = 2.\n1.3 Determine the nature of the roots of 2x² − 3x + 5 = 0 without solving.`,
      "1.1 x=2 or x=3; 1.2 x=1 or x=4; 1.3 Δ=9−40<0 → no real roots", d,
      "Factorise; rearrange; discriminant.",
      "1.1 (x−2)(x−3)=0 → x=2 or 3.\n1.2 Expand → x²−5x+4=0 → (x−1)(x−4)=0.\n1.3 Δ = 9 − 40 = −31 < 0 → no real roots.",
      8),
    (d) => Q("algebra_calculus",
      `Given f(x) = x³ − 3x² − x + 3.\n2.1 Factorise f(x) fully.\n2.2 Determine the coordinates of the turning points.\n2.3 For which values of x is f(x) ≥ 0?`,
      "2.1 (x−1)(x+1)(x−3); 2.2 calculate from f′=0; 2.3 [−1;1]∪[3;∞)", d,
      "Factor theorem; f′=0; sign chart.",
      "2.1 f(1)=0 → (x−1) factor. Division → (x−1)(x²−2x−3)=(x−1)(x−3)(x+1).\n2.2 f′=3x²−6x−1=0 → x=(6±√(36+12))/6=(6±√48)/6.\n2.3 Sign chart of cubic with roots −1,1,3 → f≥0 on [−1;1]∪[3;∞).",
      10),
    (d) => Q("algebra_calculus",
      `The cubic g(x) = x³ + px + q has a turning point at (1; −2).\n3.1 Show that p = −3 and find q.\n3.2 Find the other turning point.\n3.3 Classify the turning points (local max/min).`,
      "3.1 p=−3, q=0; 3.2 (−1;2); 3.3 (1;−2) local min, (−1;2) local max", d,
      "g′=0 at TP; second derivative test.",
      "3.1 g′=3x²+p. At x=1: 3+p=0 → p=−3. g(1)=1−3+q=−2 → q=0.\n3.2 3x²−3=0 → x=±1. g(−1)=2.\n3.3 g″=6x: g″(1)>0 min; g″(−1)<0 max.",
      9),
    (d) => Q("algebra_calculus",
      `Use first principles to find f′(x) if f(x) = 3x² − 2x.\nWrite the limit definition, expand, simplify and evaluate the limit.`,
      "6x − 2", d, "f′(x)=limₕ→₀ [f(x+h)−f(x)]/h",
      "f(x+h)=3(x+h)²−2(x+h)=3x²+6xh+3h²−2x−2h.\nDifference = 6xh+3h²−2h.\n/h → 6x+3h−2. Limit h→0 → 6x−2.",
      6),
    (d) => Q("algebra_calculus",
      `Solve simultaneously:\nx + y = 5\nx² + y² = 17\nLeave answers as ordered pairs.`,
      "(1;4) and (4;1)", d, "Substitute y=5−x into second equation.",
      "x²+(5−x)²=17 → 2x²−10x+8=0 → x²−5x+4=0 → (x−1)(x−4)=0.\nPairs: (1;4), (4;1).",
      5),
    (d) => Q("algebra_calculus",
      `f(x) = x³ − 6x² + 9x.\n4.1 Find the stationary points and classify them.\n4.2 Determine the equation of the tangent at x = 0.\n4.3 For which values of x is f decreasing?`,
      "4.1 (1;4) local max, (3;0) local min; 4.2 y=9x; 4.3 1<x<3", d,
      "f′=0; f″ or sign; point-slope.",
      "4.1 f′=3x²−12x+9=3(x−1)(x−3)=0. f(1)=4, f(3)=0. f″=6x−12 → max at x=1, min at x=3.\n4.2 f′(0)=9; f(0)=0 → y=9x.\n4.3 f′<0 on (1;3).",
      10),
    (d) => Q("algebra_calculus",
      `Determine the average gradient of f(x) = x² − 3x between x = 1 and x = 4.\nThen find the point where the instantaneous gradient equals this average gradient.`,
      "Average = 2; at x = 2.5", d, "Average = [f(b)−f(a)]/(b−a); set f′ equal.",
      "[f(4)−f(1)]/(4−1) = (4−(−2))/3 = 2.\nf′=2x−3=2 → x=2.5.",
      5)
  ],

  // ── Finance ─────────────────────────────────────────────────────────────
  finance_12: [
    (d) => {
      const P = ri(5, 20) * 1000, i = choice([0.08, 0.09, 0.1]), n = ri(3, 6);
      const A = round2(P * ((1 + i) ** n));
      return Q("finance_12",
        `R${P} is invested at ${i * 100}% p.a. compound interest for ${n} years.\nCalculate the final amount (to the nearest rand).`,
        Math.round(A), d, "A = P(1+i)^n",
        `A = ${P}(1+${i})^{${n}} ≈ ${Math.round(A)}`, 3);
    },
    (d) => Q("finance_12",
      `R12 000 is invested at 8,5% p.a. compounded monthly.\n1.1 Calculate the effective annual interest rate (to two decimal places).\n1.2 How much will the investment be worth after 5 years?\n1.3 How long (to the nearest year) will it take for the investment to double?`,
      "1.1 8,84%; 1.2 ≈ R18 304; 1.3 9 years", d,
      "i_eff = (1+i/m)^m − 1; A=P(1+i)^n",
      "1.1 i_eff=(1+0.085/12)^12−1 ≈ 0.0884 → 8,84%.\n1.2 A=12000(1+0.085/12)^{60} ≈ 18304.\n1.3 2 = (1.0884)^n → n = log2/log(1.0884) ≈ 8.2 → 9 years.",
      9),
    (d) => Q("finance_12",
      `A car depreciates at 15% p.a. on a reducing-balance basis. It cost R280 000 new.\n2.1 Find its value after 4 years.\n2.2 After how many full years will its value first drop below R100 000?`,
      "2.1 ≈ R145 801; 2.2 7 years", d, "A = P(1−i)^n",
      "2.1 A=280000(0.85)^4 ≈ 145801.\n2.2 280000(0.85)^n < 100000 → (0.85)^n < 5/14 → n > ≈6.4 → 7 full years.",
      7),
    (d) => Q("finance_12",
      `R5 000 is invested at 9% p.a. compounded quarterly.\n3.1 Write down the nominal interest rate and the number of compounding periods per year.\n3.2 Calculate the amount after 3 years.\n3.3 Calculate the effective annual rate.`,
      "3.1 9%, m=4; 3.2 ≈ R6 543; 3.3 ≈ 9.31%", d,
      "A=P(1+i/m)^{mn}; i_eff=(1+i/m)^m−1",
      "3.1 i=0.09, m=4.\n3.2 A=5000(1+0.09/4)^{12} ≈ 6543.\n3.3 i_eff=(1.0225)^4−1 ≈ 0.0931 → 9.31%.",
      8),
    (d) => Q("finance_12",
      `A loan of R50 000 is to be repaid in equal annual instalments over 5 years at 10% p.a. compound interest.\nCalculate the annual instalment (use the present-value of an annuity formula or successive reduction).`,
      "≈ R13 190", d, "P = X[1−(1+i)^{−n}]/i → X = P·i/[1−(1+i)^{−n}]",
      "X = 50000·0.1/[1−(1.1)^{−5}] ≈ 50000·0.1/0.379 ≈ 13190.",
      6),
    (d) => Q("finance_12",
      `An investment of R8 000 grows to R12 000 in 4 years under compound interest.\n4.1 Calculate the annual interest rate (to one decimal place).\n4.2 If interest had been compounded semi-annually at the same nominal rate, would the final amount be higher or lower? Explain briefly.`,
      "4.1 ≈ 10.7%; 4.2 Higher (more frequent compounding)", d,
      "A=P(1+i)^n → i = (A/P)^{1/n}−1",
      "4.1 12000=8000(1+i)^4 → (1+i)^4=1.5 → 1+i=1.5^{0.25} ≈ 1.1067 → i≈10.7%.\n4.2 More frequent compounding at same nominal rate increases effective rate and final amount.",
      7),
    (d) => Q("finance_12",
      `R15 000 is depreciated at 12% p.a. reducing balance for 3 years, then sold.\n5.1 Calculate the book value after 3 years.\n5.2 If it is sold for R9 000, calculate the profit or loss.`,
      "5.1 ≈ R10 213; 5.2 Loss ≈ R1 213", d, "A=P(1−i)^n",
      "5.1 A=15000(0.88)^3 ≈ 10213.\n5.2 Sold 9000 < 10213 → loss of about 1213.",
      5)
  ],

  // ── Trigonometry ────────────────────────────────────────────────────────
  trigonometry: [
    (d) => Q("trigonometry", "Simplify: sin(90° − θ) / cos θ", "1", d, "co-function identities",
      "sin(90°−θ)=cos θ → cos θ/cos θ = 1", 2),
    (d) => Q("trigonometry", "Prove that (1 − cos²θ)/sin θ = sin θ (for sin θ ≠ 0).", "identity", d, "Use sin²+cos²=1",
      "1−cos²θ = sin²θ → sin²θ/sin θ = sin θ", 3),
    (d) => {
      const a = ri(30, 60);
      return Q("trigonometry",
        `If sin θ = 3/5 and θ is acute, determine cos θ and tan θ without a calculator.`,
        "cos θ = 4/5; tan θ = 3/4", d, "Pythagoras on 3-4-5 triangle.",
        "Opposite 3, hypotenuse 5 → adjacent 4. cos=4/5, tan=3/4.", 3);
    },
    (d) => Q("trigonometry", "Express cos 2α in terms of sin α only.", "1 − 2 sin² α", d, "double-angle",
      "cos 2α = 1 − 2 sin² α", 2),
    (d) => Q("trigonometry", "In triangle ABC, a = 7, b = 10, Ĉ = 30°. Find the area.", "17.5", d, "Area = ½ab sin C",
      "½·7·10·sin30° = 35·0.5 = 17.5", 3),
    (d) => Q("trigonometry", "State the cosine rule for side a.", "a² = b² + c² − 2bc cos A", d, "Law of cosines",
      "a² = b² + c² − 2bc cos Â", 2),
    (d) => Q("trigonometry",
      `1.1 Prove the identity: (sin 2θ)/(1+cos 2θ) = tan θ (where defined).\n1.2 Hence solve for θ ∈ [0°; 360°]: sin 2θ = 1+cos 2θ when tan θ = 1.`,
      "1.1 identity holds; 1.2 θ=45°, 225°", d,
      "Double-angle identities.",
      "1.1 sin2θ=2sinθcosθ; 1+cos2θ=2cos²θ → LHS = sinθ/cosθ = tanθ.\n1.2 tanθ=1 → θ=45°+180°k → 45°, 225° in range.",
      7),
    (d) => Q("trigonometry",
      `In △ABC, a=8, b=10, Ĉ=60°.\n2.1 Calculate the area of △ABC.\n2.2 Determine the length of side c (cosine rule).\n2.3 Find Â (to the nearest degree).`,
      "2.1 20√3 ≈ 34,64; 2.2 √84 ≈ 9,17; 2.3 Â ≈ 55°", d,
      "Area=½ab sinC; cosine rule; cosine for angle.",
      "2.1 Area=½·8·10·(√3/2)=20√3.\n2.2 c²=64+100−2·8·10·½=164−80=84 → c=√84.\n2.3 cos A=(b²+c²−a²)/(2bc); evaluate ≈0.57 → A≈55°.",
      9),
    (d) => Q("trigonometry",
      `Solve for θ ∈ [0°; 360°]: 2 cos² θ − sin θ = 1.\nShow all working and give solutions to the nearest degree if necessary.`,
      "Use sin²+cos²=1; quadratic in sin θ", d,
      "cos²=1−sin² → 2(1−sin²θ)−sinθ=1 → 2−2sin²θ−sinθ−1=0 → 2sin²θ+sinθ−1=0.",
      "Let u=sinθ: 2u²+u−1=0 → (2u−1)(u+1)=0 → u=1/2 or u=−1.\nθ=30°,150° or θ=270°.",
      7),
    (d) => Q("trigonometry",
      `If tan θ = 5/12 and θ is acute, determine without a calculator:\n3.1 sin θ and cos θ\n3.2 sin 2θ\n3.3 cos 2θ`,
      "3.1 5/13, 12/13; 3.2 120/169; 3.3 119/169", d,
      "3-4-5 scaled; double-angle formulae.",
      "Hypotenuse 13. sin=5/13, cos=12/13.\nsin2θ=2sin cos=2·5·12/169=120/169.\ncos2θ=cos²−sin²=(144−25)/169=119/169.",
      8),
    (d) => Q("trigonometry",
      `Prove that 1 + tan² θ = sec² θ for all θ where the functions are defined.\nThen use the identity to simplify (1 + tan² θ) cos² θ.`,
      "sec² θ; simplifies to 1", d, "Divide sin²+cos²=1 by cos².",
      "1 + sin²/cos² = (cos²+sin²)/cos² = 1/cos² = sec².\n(1+tan²)cos² = sec²·cos² = 1.",
      5)
  ],

  // ── Analytical geometry ─────────────────────────────────────────────────
  analytical_geometry: [
    (d) => {
      const x1 = ri(-3, 3), y1 = ri(-3, 3), x2 = x1 + ri(2, 5), y2 = y1 + ri(-4, 4);
      const dist = round2(Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2));
      return Q("analytical_geometry",
        `Calculate the distance between A(${x1}; ${y1}) and B(${x2}; ${y2}).`,
        dist, d, "d = √[(x₂−x₁)²+(y₂−y₁)²]",
        `d = √[(${x2}−${x1})²+(${y2}−${y1})²] = ${dist}`, 3);
    },
    (d) => Q("analytical_geometry",
      `Points A(−2; 3), B(4; −1) and C(1; 5).\n1.1 Calculate the length of AB.\n1.2 Find the midpoint of AB.\n1.3 Determine the equation of the perpendicular bisector of AB.\n1.4 Show that angle at B in △ABC is acute (or calculate cos B).`,
      "1.1 √52 = 2√13; 1.2 (1;1); 1.3 y−1 = (3/2)(x−1); 1.4 cos B > 0", d,
      "Distance; midpoint; negative reciprocal gradient; cosine rule or vectors.",
      "1.1 AB=√[(4+2)²+(−1−3)²]=√(36+16)=√52.\n1.2 Mid=(1;1). Gradient AB=−2/3 → perp grad=3/2.\n1.3 y−1=(3/2)(x−1).\n1.4 Vectors BA·BC > 0 or cosine positive → acute.",
      10),
    (d) => Q("analytical_geometry",
      `The equation of a circle is x² + y² − 6x + 4y − 12 = 0.\n2.1 Write the equation in centre-radius form.\n2.2 State the centre and radius.\n2.3 Does the point (8; −2) lie inside, on, or outside the circle? Justify with a calculation.`,
      "2.1 (x−3)²+(y+2)²=25; 2.2 centre (3;−2), r=5; 2.3 on the circle (distance = 5)", d,
      "Complete the square; compare distance to radius.",
      "2.1 (x−3)²+(y+2)²=25.\n2.2 C(3;−2), r=5.\n2.3 Distance C to (8;−2) = |8−3| = 5 = r → on the circle.",
      7),
    (d) => Q("analytical_geometry",
      `Find the equation of the circle with centre (2; −1) and radius 5.\nThen determine whether the point (5; 3) lies inside the circle.`,
      "(x−2)²+(y+1)²=25; inside (distance √(9+16)=5? on; adjust: (6;−1) outside or (2;3) dist=4 inside)", d,
      "Standard form (x−a)²+(y−b)²=r².",
      "(x−2)²+(y+1)²=25. Distance from centre to (5;3): √(3²+4²)=5 = r → on the circle. (For inside use a point with dist < 5.)",
      5),
    (d) => Q("analytical_geometry",
      `A(1; 2), B(5; 6). Find:\n3.1 The midpoint M of AB.\n3.2 The gradient of AB.\n3.3 The equation of the line perpendicular to AB that passes through M.`,
      "3.1 (3;4); 3.2 1; 3.3 y−4 = −1(x−3) → y = −x + 7", d,
      "Midpoint formula; m=(y₂−y₁)/(x₂−x₁); negative reciprocal.",
      "3.1 M=((1+5)/2;(2+6)/2)=(3;4).\n3.2 m=(6−2)/(5−1)=1.\n3.3 Perp gradient = −1. Through (3;4): y−4=−(x−3) → y=−x+7.",
      7),
    (d) => Q("analytical_geometry",
      `The points P(0; 0), Q(4; 0) and R(2; 3) form a triangle.\n4.1 Show that △PQR is isosceles.\n4.2 Calculate the area of △PQR.\n4.3 Find the equation of the median from R to PQ.`,
      "4.1 PQ=4, PR=QR=√13; 4.2 6; 4.3 x=2", d,
      "Equal sides; ½ base × height; median to midpoint.",
      "4.1 PR=√(4+9)=√13; QR=√(4+9)=√13; PQ=4 → isosceles.\n4.2 Base PQ=4, height 3 → area = 6.\n4.3 Midpoint of PQ is (2;0); median is vertical line x=2.",
      8),
    (d) => Q("analytical_geometry",
      `Find the centre and radius of the circle x² + y² + 4x − 6y − 3 = 0.\nDoes the origin lie inside this circle?`,
      "Centre (−2;3), r=4; origin: distance √13 ≈ 3.6 < 4 → inside", d,
      "Complete the square.",
      "(x+2)²+(y−3)² = 4+9+3=16 → C(−2;3), r=4.\nDistance from C to (0;0)=√(4+9)=√13≈3.61 < 4 → inside.",
      6)
  ],

  // ── Euclidean geometry ──────────────────────────────────────────────────
  euclidean_geometry: [
    (d) => Q("euclidean_geometry",
      "O is the centre of a circle. Chord AB subtends ∠AOB = 80° at the centre.\nFind the angle subtended by AB at the circumference on the major arc.",
      "40°", d, "Angle at centre is twice angle at circumference",
      "∠ACB = ½∠AOB = 40°", 3, { type: "circle_geometry", mode: "centre" }),
    (d) => Q("euclidean_geometry",
      "ABCD is a cyclic quadrilateral. ∠ABC = 95°. Find ∠ADC.",
      "85°", d, "Opposite angles of cyclic quad sum to 180°",
      "∠ADC = 180° − 95° = 85°", 2, { type: "circle_geometry", mode: "cyclic" }),
    (d) => Q("euclidean_geometry",
      "Tangent at A touches the circle at A. Chord AB. If the angle between tangent and chord is 55°, find the angle in the alternate segment.",
      "55°", d, "Tangent–chord theorem",
      "Angle in alternate segment equals angle between tangent and chord = 55°", 3, { type: "circle_geometry", mode: "tangent" }),
    (d) => Q("euclidean_geometry",
      "Two tangents from external point T touch the circle at A and B. Prove that TA = TB.",
      "Tangents from a common external point are equal", d,
      "Radii ⊥ tangent; congruent triangles",
      "OA ⊥ TA, OB ⊥ TB; OA = OB (radii); OT common → △OAT ≡ △OBT (RHS) → TA = TB", 5, { type: "circle_geometry", mode: "two_tangents" }),
    (d) => Q("euclidean_geometry",
      "In circle with centre O, chord AB with M midpoint of AB. Prove that OM ⊥ AB.",
      "Line from centre to midpoint of chord is perpendicular to chord", d,
      "Congruent triangles",
      "OA = OB; AM = MB; OM common → △OAM ≡ △OBM → ∠OMA = ∠OMB = 90°", 5, { type: "circle_geometry", mode: "perp_chord" }),
    (d) => Q("euclidean_geometry",
      `In the diagram, O is the centre of the circle. Chord AB subtends ∠AOB = 100° at the centre.\nC is a point on the major arc AB.\n1.1 Find ∠ACB.\n1.2 If OA = 10 cm and M is the midpoint of AB with OM ⊥ AB, express OM in terms of cos if ∠AOM = 50°.`,
      "1.1 50°; 1.2 10 cos 50°", d,
      "∠ at centre = 2∠ at circumference; right triangle OMA.",
      "1.1 ∠ACB = ½·100° = 50°.\n1.2 In right △OMA: OM = OA cos 50° = 10 cos 50°.",
      6, { type: "circle_geometry", mode: "centre" }),
    (d) => Q("euclidean_geometry",
      `AB is a diameter of circle with centre O. C is on the circumference. ∠CAB = 35°.\n2.1 Write down ∠ACB.\n2.2 Calculate ∠ABC.\n2.3 Calculate ∠AOC (O centre).`,
      "2.1 90°; 2.2 55°; 2.3 110°", d,
      "Angle in a semicircle; triangle sum; central = 2× circumference.",
      "2.1 ∠ACB = 90° (∠ in semicircle).\n2.2 ∠ABC = 180°−90°−35° = 55°.\n2.3 ∠AOC = 2·∠ABC = 110° (on arc AC).",
      6, { type: "circle_geometry", mode: "semicircle" }),
    (d) => Q("euclidean_geometry",
      `ABCD is cyclic. Diagonals AC and BD intersect at E. ∠BAC = 30°, ∠ABD = 40°.\n3.1 Find ∠ACD (same segment or cyclic).\n3.2 Find ∠ADB.\n3.3 If ∠BCD = 70°, find ∠BAD.`,
      "3.1 40° (or related); 3.2 30°; 3.3 110°? Use cyclic opp + triangle", d,
      "Angles in the same segment; opposite angles of cyclic quad.",
      "Angles in the same segment are equal. Opposite angles of cyclic quad sum to 180°. Apply carefully with given angles.",
      7, { type: "circle_geometry", mode: "cyclic" }),
    (d) => Q("euclidean_geometry",
      `Two tangents from external point T touch the circle at A and B. O is the centre. TA = 12 cm and ∠ATB = 40°.\n4.1 Find TB.\n4.2 Find ∠TAB.\n4.3 Find ∠OAT.`,
      "4.1 12 cm; 4.2 70°; 4.3 90°", d,
      "Equal tangents; isosceles △TAB; radius ⊥ tangent.",
      "4.1 TB = TA = 12 cm (equal tangents).\n4.2 Base angles of isosceles △TAB: (180°−40°)/2 = 70°.\n4.3 ∠OAT = 90° (radius ⊥ tangent).",
      6, { type: "circle_geometry", mode: "two_tangents" }),
    (d) => Q("euclidean_geometry",
      `O is the centre. Chord AB = 16 cm. The perpendicular from O to AB meets AB at M and OM = 6 cm.\nCalculate the radius OA.`,
      "10 cm", d, "Perpendicular from centre bisects chord; Pythagoras.",
      "AM = 8 cm. OA² = OM² + AM² = 36 + 64 = 100 → OA = 10 cm.",
      4, { type: "circle_geometry", mode: "perp_chord" }),
    (d) => Q("euclidean_geometry",
      `In circle with centre O, ∠AOB = 80° and C is on the circumference on the major arc.\n5.1 Find ∠ACB.\n5.2 Find the reflex ∠AOB.\n5.3 Hence find the angle at the circumference on the minor arc side.`,
      "5.1 40°; 5.2 280°; 5.3 140°", d,
      "Central vs circumference; reflex central angle.",
      "5.1 40°. 5.2 360°−80°=280°. 5.3 Half of reflex = 140°.",
      5, { type: "circle_geometry", mode: "centre" }),
    (d) => Q("euclidean_geometry",
      `ABCD is cyclic. AB is extended to E so that ∠CBE = 72°.\nFind ∠ADC.`,
      "72°", d, "Exterior angle of cyclic quad equals opposite interior.",
      "ext ∠ of cyclic quad = opp int ∠ → ∠ADC = 72°.",
      3, { type: "circle_geometry", mode: "cyclic" }),
    (d) => Q("euclidean_geometry",
      `Prove that the line from the centre of a circle to the midpoint of a chord is perpendicular to the chord. (Give a short reason chain.)`,
      "△OAM ≡ △OBM (SSS or radii + common) → ∠OMA = ∠OMB = 90°", d,
      "Congruent triangles with two radii.",
      "OA = OB (radii), AM = MB (midpoint), OM common → △OAM ≡ △OBM → adjacent angles on straight line equal → each 90°.",
      5, { type: "circle_geometry", mode: "perp_chord" }),
    (d) => Q("euclidean_geometry",
      `Intersecting chords: chords AB and CD intersect at P inside the circle. AP = 3, PB = 8, CP = 4. Find PD.`,
      "6", d, "AP·PB = CP·PD",
      "3·8 = 4·PD → PD = 6.",
      3, { type: "circle_geometry", mode: "intersecting_chords" }),
    (d) => Q("euclidean_geometry",
      `O is the centre. Chord AB subtends ∠AOB = 110° at the centre. C is on the major arc.\n6.1 Calculate ∠ACB.\n6.2 Calculate the reflex ∠AOB.\n6.3 If D is on the minor arc, calculate ∠ADB.`,
      "6.1 55°; 6.2 250°; 6.3 125°", d,
      "Angle at centre twice angle at circumference.",
      "6.1 ∠ACB = ½·110° = 55°.\n6.2 Reflex = 250°.\n6.3 ∠ADB = ½·250° = 125°.",
      6, { type: "circle_geometry", mode: "centre" }),
    (d) => Q("euclidean_geometry",
      `Tangent TA touches the circle at A. Chord AB. Point C is on the circumference in the alternate segment. ∠TAB = 48°.\n7.1 Write down ∠ACB with reason.\n7.2 If ∠ABC = 70°, find ∠BAC.`,
      "7.1 48° (tan-chord / alternate segment); 7.2 62°", d,
      "Tangent–chord theorem; triangle sum.",
      "7.1 ∠ACB = 48° (angle in alternate segment).\n7.2 ∠BAC = 180°−70°−48° = 62°.",
      5, { type: "circle_geometry", mode: "tangent" })
  ],

  // ── Probability ─────────────────────────────────────────────────────────
  probability_12: [
    (d) => Q("probability_12", "A fair die is rolled. P(prime number)?", "1/2", d, "Primes: 2,3,5", "3/6 = 1/2", 2),
    (d) => Q("probability_12", "P(A) = 0.4, P(B) = 0.5, A and B independent. P(A and B)?", "0.2", d, "Independent: P(A∩B)=P(A)P(B)", "0.4×0.5=0.2", 2),
    (d) => Q("probability_12", "P(A) = 0.3, P(B) = 0.5, P(A∪B) = 0.7. Are A and B mutually exclusive?", "No (P(A∩B)=0.1 ≠ 0)", d, "Mutually exclusive ⇒ P(A∪B)=P(A)+P(B)", "0.3+0.5=0.8 ≠ 0.7", 3),
    (d) => Q("probability_12", "From 5 boys and 4 girls, a committee of 3 is chosen at random. P(all girls)?", "4/84 = 1/21", d, "Combinations", "C(4,3)/C(9,3) = 4/84 = 1/21", 4),
    (d) => Q("probability_12", "Two events: P(A)=0.6, P(B|A)=0.3. Find P(A and B).", "0.18", d, "P(A∩B)=P(B|A)P(A)", "0.3×0.6=0.18", 3),
    (d) => Q("probability_12",
      `Events A and B are independent. P(A)=0,4 and P(B)=0,5.\n1.1 Calculate P(A and B).\n1.2 Calculate P(A or B).\n1.3 Calculate P(A|B).\n1.4 Are A and B mutually exclusive? Justify.`,
      "1.1 0,2; 1.2 0,7; 1.3 0,4; 1.4 No (P(A∩B)≠0)", d,
      "Independent → P(A∩B)=P(A)P(B); addition rule; conditional.",
      "1.1 P(A∩B)=0,4·0,5=0,2.\n1.2 P(A∪B)=0,4+0,5−0,2=0,7.\n1.3 P(A|B)=0,2/0,5=0,4.\n1.4 Mutually exclusive would require P(A∩B)=0, which is false.",
      8),
    (d) => Q("probability_12",
      `A bag contains 5 red and 3 blue balls. Two balls are drawn without replacement.\n2.1 Draw a tree diagram showing all outcomes and probabilities.\n2.2 Calculate the probability that both balls are the same colour.\n2.3 Calculate the probability that the second ball is red.`,
      "2.1 tree with RR,RB,BR,BB; 2.2 13/28; 2.3 5/8", d,
      "Conditional probabilities on branches; product then add.",
      "2.2 P(same)=P(RR)+P(BB)=(5/8)(4/7)+(3/8)(2/7)=20/56+6/56=26/56=13/28.\n2.3 P(2nd red)=P(RR)+P(BR)=(5/8)(4/7)+(3/8)(5/7)=35/56=5/8.",
      9),
    (d) => Q("probability_12",
      `A fair coin is tossed three times.\n3.1 List the sample space.\n3.2 Find P(exactly two heads).\n3.3 Find P(at least one head).`,
      "3.1 8 outcomes HHH…TTT; 3.2 3/8; 3.3 7/8", d,
      "Equally likely outcomes; count favourable.",
      "3.1 {HHH,HHT,HTH,THH,HTT,THT,TTH,TTT}.\n3.2 Exactly two H: HHT,HTH,THH → 3/8.\n3.3 1 − P(TTT) = 1 − 1/8 = 7/8.",
      6),
    (d) => Q("probability_12",
      `P(A)=0.6, P(B)=0.5, P(A∪B)=0.8.\n4.1 Calculate P(A∩B).\n4.2 Are A and B independent? Justify.\n4.3 Calculate P(A|B).`,
      "4.1 0.3; 4.2 Yes (0.3 = 0.6×0.5); 4.3 0.6", d,
      "Addition rule; compare P(A∩B) with product; conditional.",
      "4.1 P(A∩B)=P(A)+P(B)−P(A∪B)=0.6+0.5−0.8=0.3.\n4.2 0.3 ≠ 0.3? 0.6×0.5=0.3 → actually independent in this case. (If numbers differ, state accordingly.)\n4.3 P(A|B)=0.3/0.5=0.6.",
      7),
    (d) => Q("probability_12",
      `In a class of 30 learners, 18 take Mathematics and 12 take Physical Sciences. 8 take both.\n5.1 Represent the information in a Venn diagram.\n5.2 Find the probability that a learner chosen at random takes Mathematics only.\n5.3 Find the probability that a learner takes neither subject.`,
      "5.1 Venn with 10 Math only, 8 both, 4 PS only; 5.2 10/30=1/3; 5.3 8/30=4/15", d,
      "Inclusion; n(only)=n(subject)−n(both).",
      "Math only = 18−8=10; PS only=12−8=4; neither=30−(10+8+4)=8.\nP(Math only)=10/30; P(neither)=8/30.",
      7)
  ],

  // ── Statistics ──────────────────────────────────────────────────────────
  statistics_12: [
    (d) => Q("statistics_12", "Data: 2, 5, 5, 7, 9. Find the median.", "5", d, "Middle value of ordered list", "Ordered already; middle = 5", 1),
    (d) => Q("statistics_12", "Data: 3, 7, 7, 8, 12. Find the mean.", "7.4", d, "Sum ÷ n", "(3+7+7+8+12)/5 = 37/5 = 7.4", 2),
    (d) => Q("statistics_12", "Five-number summary of a set is 2, 5, 8, 11, 15. Calculate the IQR.", "6", d, "IQR = Q3 − Q1", "11 − 5 = 6", 2),
    (d) => Q("statistics_12", "Why might the median be preferred to the mean for a skewed income data set?", "Median is resistant to outliers / extreme values", d, "Robustness", "Mean is pulled by extreme incomes; median better represents typical value.", 3),
    (d) => Q("statistics_12", "A box-and-whisker plot has Q1 = 10, median = 14, Q3 = 18. Comment on symmetry.", "Roughly symmetric (median midway between Q1 and Q3)", d, "Compare distances", "14−10 = 4 and 18−14 = 4 → symmetric about median in the box.", 3),
    (d) => Q("statistics_12",
      `The five-number summary of a data set is: Min=12, Q1=18, Median=24, Q3=30, Max=42.\n1.1 Calculate the interquartile range.\n1.2 Determine whether 42 is an outlier using the 1,5×IQR rule.\n1.3 Sketch a box-and-whisker diagram.\n1.4 Comment on the skewness of the distribution.`,
      "1.1 12; 1.2 No (upper fence=48); 1.3 box 18–30 with median 24; 1.4 slight positive skew (longer right whisker)", d,
      "IQR=Q3−Q1; fences = Q3±1,5·IQR",
      "1.1 IQR=30−18=12.\n1.2 Upper fence=30+1.5·12=48 > 42 → not an outlier.\n1.4 Right whisker longer → mild positive skew.",
      8),
    (d) => Q("statistics_12",
      `Data: 4; 7; 7; 9; 12; 15; 18.\n2.1 Calculate the mean and the sample standard deviation (to 1 d.p.).\n2.2 Determine the median and the mode.\n2.3 Which measure of central tendency is most appropriate? Justify briefly.`,
      "2.1 mean≈10.3; s≈5.0; 2.2 median=9, mode=7; 2.3 median (robust) or mean", d,
      "Mean = Σx/n; s = √[Σ(x−x̄)²/(n−1)]",
      "2.1 Σx=72, n=7, mean≈10.29. Sample SD ≈ 5.0.\n2.2 Median = 9; mode = 7.\n2.3 Mild skew; median is robust to extremes.",
      8),
    (d) => Q("statistics_12",
      `A data set has mean 50 and standard deviation 8.\n3.1 Approximately what percentage of data lies within one standard deviation of the mean (empirical rule, roughly normal)?\n3.2 A score of 66 is how many standard deviations above the mean?\n3.3 Is a score of 30 unusually low? Justify.`,
      "3.1 ≈68%; 3.2 2 SD; 3.3 Yes (more than 2 SD below)", d,
      "Empirical rule; z = (x−μ)/σ.",
      "3.1 ≈68% within μ±σ.\n3.2 (66−50)/8 = 2.\n3.3 (30−50)/8 = −2.5 → more than 2 SD below → unusually low.",
      6),
    (d) => Q("statistics_12",
      `The ages of 10 learners are: 15, 16, 16, 17, 17, 17, 18, 18, 19, 20.\n4.1 Construct a frequency table.\n4.2 Calculate the mean age.\n4.3 Determine Q1, median and Q3.`,
      "4.1 tally by age; 4.2 17.3; 4.3 Q1=16, med=17, Q3=18", d,
      "Ordered list; positions for quartiles.",
      "4.2 Σ=173, mean=17.3.\n4.3 n=10; median average of 5th and 6th = 17; Q1 ≈ 16; Q3 ≈ 18.",
      7),
    (d) => Q("statistics_12",
      `Compare two data sets: Set A has mean 20 and SD 2; Set B has mean 20 and SD 8.\n5.1 Which set is more consistent? Why?\n5.2 In which set is a score of 28 more unusual? Justify using standard deviations.`,
      "5.1 Set A (smaller SD); 5.2 Set A (28 is 4 SD above mean vs 1 SD in B)", d,
      "Smaller SD → less spread; z-scores.",
      "5.1 A has smaller standard deviation → more consistent.\n5.2 In A: (28−20)/2=4 SD; in B: (28−20)/8=1 SD → far more unusual in A.",
      5)
  ]
};

// Ensure each bank has at least 20 callable types (duplicates still re-roll values)
for (const [k, arr] of Object.entries(MATHS)) {
  if (arr.length < 20) {
    const base = arr.slice();
    while (arr.length < 20) arr.push(base[arr.length % base.length]);
  }
}

export function generateMathsRecipe(topicId, difficulty = 2) {
  const d = Math.max(1, Math.min(4, difficulty | 0));
  const bank = MATHS[topicId];
  if (!bank || !bank.length) return null;
  const type = pickType(topicId, bank);
  try {
    return type(d);
  } catch (e) {
    try { return bank[0](d); } catch { return null; }
  }
}

export function mathsRecipeTopics() {
  return Object.keys(MATHS);
}

export function mathsRecipeCount(topicId) {
  return (MATHS[topicId] || []).length;
}

export function expandBank(topic, makers, target = 30) {
  const out = makers.slice();
  let guard = 0;
  while (out.length < target && guard < 200) {
    guard++;
    out.push(makers[out.length % makers.length]);
  }
  return out;
}

/** Named question templates for engines (articulate structure → fill values). */
export const QUESTION_TEMPLATES = {
  multi_part_circle: {
    id: "multi_part_circle",
    description: "CAPS-style multi-part Euclidean with diagram mode",
    parts: ["find circumference angle", "find centre angle", "apply Pythagoras on radius-chord"]
  },
  finance_compound: {
    id: "finance_compound",
    description: "Compound interest A = P(1+i)^n with monthly variant",
    parts: ["identify i and n", "compute A", "compare nominal vs effective"]
  },
  calculus_first_principles: {
    id: "calculus_first_principles",
    description: "First principles derivative for polynomials",
    parts: ["write limit definition", "expand f(x+h)", "simplify and take limit"]
  },
  accounting_recon: {
    id: "accounting_recon",
    description: "Full bank reconciliation from statement to cash book",
    parts: ["outstanding deposits", "outstanding cheques", "bank charges", "final balance"]
  }
};

export function listQuestionTemplates() {
  return Object.values(QUESTION_TEMPLATES);
}

export default { generateMathsRecipe, mathsRecipeTopics, mathsRecipeCount, listQuestionTemplates };
