/**
 * learnyZ — subject formula sheets and periodic table (canvas).
 * Offline, CAPS-oriented reference cards.
 */

/** Common CAPS formulae by subject key */
const FORMULAE = {
  maths: {
    title: "Mathematics — Formula sheet",
    sections: [
      {
        heading: "Algebra & equations",
        items: [
          "Quadratic formula: x = (−b ± √(b² − 4ac)) / (2a)",
          "Discriminant: Δ = b² − 4ac",
          "Sum of roots: −b/a · Product: c/a",
          "Difference of squares: a² − b² = (a − b)(a + b)"
        ]
      },
      {
        heading: "Functions",
        items: [
          "Linear: y = mx + c",
          "Parabola: y = a(x − p)² + q",
          "Hyperbola: y = a/x + q  or  xy = k",
          "Exponential: y = abˣ + q"
        ]
      },
      {
        heading: "Analytical geometry",
        items: [
          "Distance: √[(x₂−x₁)² + (y₂−y₁)²]",
          "Midpoint: ((x₁+x₂)/2 , (y₁+y₂)/2)",
          "Gradient: m = (y₂−y₁)/(x₂−x₁)",
          "Point–slope: y − y₁ = m(x − x₁)"
        ]
      },
      {
        heading: "Trigonometry",
        items: [
          "sin θ = opposite / hypotenuse",
          "cos θ = adjacent / hypotenuse",
          "tan θ = opposite / adjacent",
          "Area of Δ: ½ab sin C",
          "Sine rule: a/sin A = b/sin B = c/sin C",
          "Cosine rule: c² = a² + b² − 2ab cos C"
        ]
      },
      {
        heading: "Measurement & finance",
        items: [
          "Circle: C = 2πr · A = πr²",
          "Sphere: SA = 4πr² · V = (4/3)πr³",
          "Cylinder: SA = 2πr² + 2πrh · V = πr²h",
          "Simple interest: I = Prt",
          "Compound: A = P(1 + i)ⁿ"
        ]
      }
    ]
  },
  physical_sciences: {
    title: "Physical Sciences — Formula sheet",
    sections: [
      {
        heading: "Mechanics",
        items: [
          "v = u + at",
          "s = ut + ½at²",
          "v² = u² + 2as",
          "F = ma",
          "W = mg",
          "p = mv · Impulse = FΔt = Δp",
          "Work: W = FΔx cos θ · Power = W/Δt"
        ]
      },
      {
        heading: "Waves & light",
        items: [
          "v = fλ",
          "T = 1/f",
          "n = c/v · n₁sin θ₁ = n₂sin θ₂"
        ]
      },
      {
        heading: "Electricity",
        items: [
          "I = Q/Δt",
          "V = W/Q · V = IR",
          "R_series = R₁ + R₂ + …",
          "1/R_parallel = 1/R₁ + 1/R₂ + …",
          "P = VI = I²R = V²/R"
        ]
      },
      {
        heading: "Chemistry",
        items: [
          "n = m/M · n = N/N_A · c = n/V",
          "pV = nRT",
          "q = mcΔT",
          "% yield = (actual / theoretical) × 100"
        ]
      }
    ]
  },
  life_sciences: {
    title: "Life Sciences — Formula & key relations",
    sections: [
      {
        heading: "Cell & photosynthesis",
        items: [
          "Photosynthesis (word): CO₂ + H₂O → glucose + O₂ (light, chlorophyll)",
          "Respiration (word): glucose + O₂ → CO₂ + H₂O + energy (ATP)",
          "Surface area : volume decreases as cells grow (limits size)"
        ]
      },
      {
        heading: "Genetics",
        items: [
          "Diploid (2n) · Haploid (n)",
          "Phenotypic ratio monohybrid (complete dominance): 3 : 1",
          "Genotypic ratio monohybrid: 1 : 2 : 1"
        ]
      },
      {
        heading: "Ecology",
        items: [
          "Energy decreases ~10% each trophic level",
          "Population growth: birth − death + immigration − emigration"
        ]
      }
    ]
  },
  geography: {
    title: "Geography — Formula & mapwork",
    sections: [
      {
        heading: "Mapwork",
        items: [
          "Ground distance = map distance × scale factor",
          "Gradient = vertical interval / horizontal equivalent",
          "Magnetic declination: True = Magnetic ± declination (as stated)"
        ]
      },
      {
        heading: "Population & climate",
        items: [
          "Natural increase = birth rate − death rate",
          "Population density = population / area"
        ]
      }
    ]
  },
  accounting: {
    title: "Accounting — Formula sheet",
    sections: [
      {
        heading: "Core equation & equity",
        items: [
          "Assets = Owner's equity + Liabilities",
          "Owner's equity = Capital + Profit − Drawings",
          "Profit = Income − Expenses"
        ]
      },
      {
        heading: "Trading & VAT",
        items: [
          "Cost of sales = Opening stock + Purchases − Closing stock",
          "Gross profit = Sales − Cost of sales",
          "VAT = exclusive × 0,15 · Exclusive = inclusive × 100/115",
          "VAT payable = Output VAT − Input VAT"
        ]
      },
      {
        heading: "Analysis",
        items: [
          "Current ratio = Current assets / Current liabilities",
          "Acid-test = (Current assets − Inventory) / Current liabilities",
          "Gross profit % = (Gross profit / Sales) × 100"
        ]
      }
    ]
  },
  cat: {
    title: "CAT — Quick reference",
    sections: [
      {
        heading: "Systems & hardware",
        items: [
          "Information cycle: Input → Processing → Output → Storage (+ Communication)",
          "CPU executes instructions; RAM is volatile; secondary storage is non-volatile"
        ]
      },
      {
        heading: "Software & data",
        items: [
          "System software vs application software",
          "File hierarchy: drive → folder → subfolder → file",
          "Primary key uniquely identifies a record in a table"
        ]
      }
    ]
  },
  natural_sciences: {
    title: "Natural Sciences — Formula & relations",
    sections: [
      {
        heading: "Matter & energy",
        items: [
          "Density = mass / volume",
          "Speed = distance / time",
          "Energy transfers: chemical → electrical → light + heat (examples)"
        ]
      },
      {
        heading: "Life & Earth",
        items: [
          "Photosynthesis / respiration word equations (see Life Sciences)",
          "Planets order (inner): Mercury, Venus, Earth, Mars"
        ]
      }
    ]
  },
  technology: {
    title: "Technology — Formula & systems",
    sections: [
      {
        heading: "Mechanical",
        items: [
          "Mechanical advantage ≈ load / effort (ideal)",
          "Gear ratio = teeth on driven / teeth on driver",
          "Classes of lever: 1 (fulcrum middle), 2 (load middle), 3 (effort middle)"
        ]
      },
      {
        heading: "Systems",
        items: [
          "System: input → process → output (+ feedback for closed-loop)"
        ]
      }
    ]
  }
};

export function formulaSheetFor(subjectId) {
  const key = String(subjectId || "maths")
    .replace("natural_sciences_technology", "natural_sciences")
    .replace("physical_sciences", "physical_sciences");
  return FORMULAE[key] || FORMULAE.maths;
}

export function allFormulaSubjects() {
  return Object.keys(FORMULAE);
}

/** Simplified periodic table data (symbol, Z, period, group-ish column 0–17) */
const ELEMENTS = [
  { s: "H", z: 1, p: 1, g: 0 }, { s: "He", z: 2, p: 1, g: 17 },
  { s: "Li", z: 3, p: 2, g: 0 }, { s: "Be", z: 4, p: 2, g: 1 },
  { s: "B", z: 5, p: 2, g: 12 }, { s: "C", z: 6, p: 2, g: 13 },
  { s: "N", z: 7, p: 2, g: 14 }, { s: "O", z: 8, p: 2, g: 15 },
  { s: "F", z: 9, p: 2, g: 16 }, { s: "Ne", z: 10, p: 2, g: 17 },
  { s: "Na", z: 11, p: 3, g: 0 }, { s: "Mg", z: 12, p: 3, g: 1 },
  { s: "Al", z: 13, p: 3, g: 12 }, { s: "Si", z: 14, p: 3, g: 13 },
  { s: "P", z: 15, p: 3, g: 14 }, { s: "S", z: 16, p: 3, g: 15 },
  { s: "Cl", z: 17, p: 3, g: 16 }, { s: "Ar", z: 18, p: 3, g: 17 },
  { s: "K", z: 19, p: 4, g: 0 }, { s: "Ca", z: 20, p: 4, g: 1 },
  { s: "Sc", z: 21, p: 4, g: 2 }, { s: "Ti", z: 22, p: 4, g: 3 },
  { s: "V", z: 23, p: 4, g: 4 }, { s: "Cr", z: 24, p: 4, g: 5 },
  { s: "Mn", z: 25, p: 4, g: 6 }, { s: "Fe", z: 26, p: 4, g: 7 },
  { s: "Co", z: 27, p: 4, g: 8 }, { s: "Ni", z: 28, p: 4, g: 9 },
  { s: "Cu", z: 29, p: 4, g: 10 }, { s: "Zn", z: 30, p: 4, g: 11 },
  { s: "Ga", z: 31, p: 4, g: 12 }, { s: "Ge", z: 32, p: 4, g: 13 },
  { s: "As", z: 33, p: 4, g: 14 }, { s: "Se", z: 34, p: 4, g: 15 },
  { s: "Br", z: 35, p: 4, g: 16 }, { s: "Kr", z: 36, p: 4, g: 17 },
  { s: "Rb", z: 37, p: 5, g: 0 }, { s: "Sr", z: 38, p: 5, g: 1 },
  { s: "Y", z: 39, p: 5, g: 2 }, { s: "Zr", z: 40, p: 5, g: 3 },
  { s: "Nb", z: 41, p: 5, g: 4 }, { s: "Mo", z: 42, p: 5, g: 5 },
  { s: "Tc", z: 43, p: 5, g: 6 }, { s: "Ru", z: 44, p: 5, g: 7 },
  { s: "Rh", z: 45, p: 5, g: 8 }, { s: "Pd", z: 46, p: 5, g: 9 },
  { s: "Ag", z: 47, p: 5, g: 10 }, { s: "Cd", z: 48, p: 5, g: 11 },
  { s: "In", z: 49, p: 5, g: 12 }, { s: "Sn", z: 50, p: 5, g: 13 },
  { s: "Sb", z: 51, p: 5, g: 14 }, { s: "Te", z: 52, p: 5, g: 15 },
  { s: "I", z: 53, p: 5, g: 16 }, { s: "Xe", z: 54, p: 5, g: 17 },
  { s: "Cs", z: 55, p: 6, g: 0 }, { s: "Ba", z: 56, p: 6, g: 1 },
  { s: "La", z: 57, p: 6, g: 2 }, { s: "Hf", z: 72, p: 6, g: 3 },
  { s: "Ta", z: 73, p: 6, g: 4 }, { s: "W", z: 74, p: 6, g: 5 },
  { s: "Re", z: 75, p: 6, g: 6 }, { s: "Os", z: 76, p: 6, g: 7 },
  { s: "Ir", z: 77, p: 6, g: 8 }, { s: "Pt", z: 78, p: 6, g: 9 },
  { s: "Au", z: 79, p: 6, g: 10 }, { s: "Hg", z: 80, p: 6, g: 11 },
  { s: "Tl", z: 81, p: 6, g: 12 }, { s: "Pb", z: 82, p: 6, g: 13 },
  { s: "Bi", z: 83, p: 6, g: 14 }, { s: "Po", z: 84, p: 6, g: 15 },
  { s: "At", z: 85, p: 6, g: 16 }, { s: "Rn", z: 86, p: 6, g: 17 },
  { s: "Fr", z: 87, p: 7, g: 0 }, { s: "Ra", z: 88, p: 7, g: 1 }
];

function elementColor(z) {
  if (z === 1) return "#fde68a";
  if ([2, 10, 18, 36, 54, 86].includes(z)) return "#a5f3fc"; // noble
  if ([3, 11, 19, 37, 55, 87].includes(z)) return "#fecaca"; // alkali
  if ([4, 12, 20, 38, 56, 88].includes(z)) return "#fed7aa"; // alkaline earth
  if ([9, 17, 35, 53, 85].includes(z)) return "#bbf7d0"; // halogen
  if (z >= 21 && z <= 30 || z >= 39 && z <= 48 || z >= 72 && z <= 80) return "#ddd6fe"; // transition
  if ([5, 6, 7, 8, 14, 15, 16, 33, 34, 52].includes(z)) return "#bfdbfe"; // non-metal-ish
  return "#e5e7eb";
}

/**
 * Draw a compact CAPS-friendly periodic table on canvas.
 */
export function drawPeriodicTable(ctx, w, h) {
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  const pad = 8;
  const cols = 18;
  const rows = 7;
  const cellW = (w - pad * 2) / cols;
  const cellH = (h - pad * 2 - 18) / rows;
  ctx.fillStyle = "#0f172a";
  ctx.font = "bold 11px system-ui,sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("Periodic table (selected elements · CAPS reference)", pad, 14);

  for (const el of ELEMENTS) {
    const x = pad + el.g * cellW;
    const y = pad + 18 + (el.p - 1) * cellH;
    ctx.fillStyle = elementColor(el.z);
    ctx.fillRect(x + 0.5, y + 0.5, cellW - 1, cellH - 1);
    ctx.strokeStyle = "#94a3b8";
    ctx.lineWidth = 0.5;
    ctx.strokeRect(x + 0.5, y + 0.5, cellW - 1, cellH - 1);
    ctx.fillStyle = "#0f172a";
    ctx.font = `bold ${Math.max(8, Math.min(11, cellW * 0.45))}px system-ui,sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText(el.s, x + cellW / 2, y + cellH * 0.55);
    ctx.font = `${Math.max(6, Math.min(8, cellW * 0.28))}px system-ui,sans-serif`;
    ctx.fillStyle = "#475569";
    ctx.fillText(String(el.z), x + cellW / 2, y + cellH * 0.88);
  }
}

/** Canvas-friendly formula rendering: draw multi-line sheet */
export function drawFormulaSheet(ctx, w, h, subjectId) {
  const sheet = formulaSheetFor(subjectId);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  let y = 16;
  ctx.fillStyle = "#0f172a";
  ctx.font = "bold 13px system-ui,sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(sheet.title, 10, y);
  y += 18;
  ctx.strokeStyle = "#e2e8f0";
  ctx.beginPath();
  ctx.moveTo(10, y);
  ctx.lineTo(w - 10, y);
  ctx.stroke();
  y += 12;

  for (const sec of sheet.sections) {
    if (y > h - 24) break;
    ctx.fillStyle = "#4338ca";
    ctx.font = "bold 11px system-ui,sans-serif";
    ctx.fillText(sec.heading, 10, y);
    y += 14;
    ctx.fillStyle = "#1e293b";
    ctx.font = "10px system-ui,sans-serif";
    for (const item of sec.items) {
      if (y > h - 14) break;
      const maxChars = Math.floor((w - 20) / 5.5);
      const line = item.length > maxChars ? item.slice(0, maxChars - 1) + "…" : item;
      ctx.fillText("• " + line, 12, y);
      y += 13;
    }
    y += 6;
  }
}
