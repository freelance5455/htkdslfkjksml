/**
 * learnyZ — grade-aware procedural diagram recipes.
 * Engines request a diagram by id; this module returns a canvas-ready spec
 * scaled to the learner's grade (simpler labels in Foundation, denser in FET).
 *
 * Drawing is performed by js/ui/render.js (drawDiagram). This file only
 * encodes WHAT to draw and with which parameters.
 */

function clampGrade(g) {
  const n = parseInt(g, 10);
  if (Number.isNaN(n)) return 8;
  return Math.max(0, Math.min(12, n));
}

function phase(grade) {
  const g = clampGrade(grade);
  if (g <= 3) return "foundation";
  if (g <= 6) return "intermediate";
  if (g <= 9) return "senior";
  return "fet";
}

/** Kepler-inspired orbital radii (not to scale — educational layout). */
const SOLAR = [
  { name: "Sun", r: 0, color: "#F5A623", radiusPx: 22 },
  { name: "Mercury", r: 0.18, color: "#A0A0A0", radiusPx: 4 },
  { name: "Venus", r: 0.28, color: "#E8C07A", radiusPx: 6 },
  { name: "Earth", r: 0.38, color: "#3157D5", radiusPx: 7 },
  { name: "Mars", r: 0.48, color: "#D64545", radiusPx: 5 },
  { name: "Jupiter", r: 0.68, color: "#C4A35A", radiusPx: 12 },
  { name: "Saturn", r: 0.82, color: "#D4B56A", radiusPx: 10 },
  { name: "Uranus", r: 0.92, color: "#7EC8E3", radiusPx: 8 },
  { name: "Neptune", r: 1.0, color: "#4169E1", radiusPx: 8 }
];

/**
 * Build a diagram spec for a known kind.
 * @param {string} kind
 * @param {number|string} grade
 * @param {object} overrides
 */
export function recipe(kind, grade = 8, overrides = {}) {
  const g = clampGrade(grade);
  const ph = phase(g);
  const base = { type: kind, grade: g, phase: ph, caps_school_style: true };

  switch (kind) {
    case "solar_system": {
      const showOuter = ph !== "foundation";
      const bodies = showOuter ? SOLAR : SOLAR.slice(0, 5);
      return {
        ...base,
        bodies,
        showLabels: true,
        title: ph === "foundation" ? "Sun and planets" : "Solar system (layout)"
      };
    }
    case "plant_structure": {
      return {
        ...base,
        showRoots: true,
        showLeaves: true,
        showFlower: ph !== "foundation",
        labels: ph === "foundation"
          ? ["root", "stem", "leaf"]
          : ["roots", "stem", "leaf", "flower", "xylem/phloem"]
      };
    }
    case "heart_parametric":
    case "organ_heart": {
      return {
        ...base,
        chambers: ph === "fet" || ph === "senior",
        labels: ph === "foundation"
          ? ["heart"]
          : ["right atrium", "left atrium", "right ventricle", "left ventricle", "aorta"]
      };
    }
    case "organ_digestive": {
      return {
        ...base,
        labels: ph === "foundation"
          ? ["mouth", "stomach", "intestine"]
          : ["mouth", "oesophagus", "stomach", "small intestine", "large intestine", "liver"]
      };
    }
    case "plant_cell_parametric":
    case "cell_plant": {
      return {
        ...base,
        type: "cell_plant",
        showChloroplast: true,
        showWall: true,
        labels: ph === "foundation"
          ? ["wall", "nucleus", "chloroplast"]
          : ["cell wall", "membrane", "nucleus", "chloroplast", "vacuole", "cytoplasm"]
      };
    }
    case "cell_animal": {
      return {
        ...base,
        type: "cell_animal",
        labels: ph === "foundation"
          ? ["membrane", "nucleus"]
          : ["membrane", "nucleus", "mitochondria", "cytoplasm"]
      };
    }
    case "atom_bohr": {
      return {
        ...base,
        type: "atom_bohr",
        labels: ph === "foundation"
          ? ["nucleus", "electron"]
          : ["nucleus", "proton", "neutron", "electron", "shell"]
      };
    }
    case "mitosis_stages": {
      return {
        ...base,
        type: "mitosis_stages",
        labels: ["prophase", "metaphase", "anaphase", "telophase"]
      };
    }
    case "food_web": {
      return {
        ...base,
        nodes: overrides.nodes || [
          { id: "sun", label: "Sun", level: 0 },
          { id: "grass", label: "Grass", level: 1 },
          { id: "insect", label: "Insect", level: 2 },
          { id: "bird", label: "Bird", level: 3 },
          { id: "hawk", label: "Hawk", level: 4 }
        ],
        edges: overrides.edges || [
          ["sun", "grass"], ["grass", "insect"], ["insect", "bird"], ["bird", "hawk"]
        ]
      };
    }
    case "journal_table": {
      // Accounting books of first entry — looks like a paper journal
      const cols = overrides.cols || ["Date", "Details", "Fol", "Debit", "Credit"];
      const rows = overrides.rows || [
        ["01 Mar", "Bank", "B1", "5 000", ""],
        ["01 Mar", "Capital", "B2", "", "5 000"],
        ["03 Mar", "Purchases", "B3", "1 200", ""],
        ["03 Mar", "Bank", "B1", "", "1 200"]
      ];
      return { ...base, type: "journal_table", title: overrides.title || "General Journal", cols, rows };
    }
    case "t_account": {
      return {
        ...base,
        type: "t_account",
        account: overrides.account || "Bank",
        debit: overrides.debit || [["01 Mar Capital", "5 000"], ["05 Mar Sales", "800"]],
        credit: overrides.credit || [["03 Mar Purchases", "1 200"], ["10 Mar Rent", "500"]]
      };
    }
    case "trial_balance": {
      return {
        ...base,
        type: "trial_balance",
        title: overrides.title || "Trial Balance",
        rows: overrides.rows || [
          ["Bank", "4 100", ""],
          ["Capital", "", "5 000"],
          ["Purchases", "1 200", ""],
          ["Sales", "", "800"],
          ["Rent expense", "500", ""],
          ["Totals", "5 800", "5 800"]
        ]
      };
    }
    case "accounting_equation": {
      const a = overrides.assets ?? 12000;
      const l = overrides.liabilities ?? 4000;
      const e = overrides.equity ?? a - l;
      return { ...base, type: "accounting_equation", assets: a, liabilities: l, equity: e };
    }
    case "bank_recon": {
      return {
        ...base,
        type: "bank_recon",
        title: "Bank reconciliation",
        rows: overrides.rows || [
          ["Balance per bank statement", "8 450"],
          ["Add: Outstanding deposit", "1 200"],
          ["Less: Outstanding cheques", "(950)"],
          ["Balance per cash book", "8 700"]
        ]
      };
    }
    case "income_statement": {
      return {
        ...base,
        type: "income_statement",
        title: overrides.title || "Statement of Comprehensive Income (extract)",
        rows: overrides.rows || [
          ["Sales", "45 000"],
          ["Cost of sales", "(28 000)"],
          ["Gross profit", "17 000"],
          ["Operating expenses", "(9 500)"],
          ["Net profit", "7 500"]
        ]
      };
    }
    case "lever": {
      return {
        ...base,
        type: "lever",
        fulcrum: overrides.fulcrum ?? 0.4,
        load: overrides.load ?? "Load",
        effort: overrides.effort ?? "Effort"
      };
    }

    case "mitosis_stages": {
      return {
        ...base,
        type: "mitosis_stages",
        stages: ["Prophase", "Metaphase", "Anaphase", "Telophase"],
        title: "Mitosis (simplified stages)"
      };
    }
    case "photosynthesis": {
      return {
        ...base,
        type: "photosynthesis",
        title: "Photosynthesis overview"
      };
    }
    case "population_pyramid": {
      return {
        ...base,
        type: "population_pyramid",
        title: overrides.title || "Population pyramid (schematic)",
        male: overrides.male || [8, 10, 12, 11, 9, 7, 5, 3],
        female: overrides.female || [7, 10, 12, 11, 9, 8, 6, 4]
      };
    }
    case "plate_tectonics": {
      return {
        ...base,
        type: "plate_tectonics",
        title: "Plate boundaries (schematic)"
      };
    }
    case "water_cycle": {
      return {
        ...base,
        type: "water_cycle",
        title: "Water cycle",
        labels: ph === "foundation"
          ? ["evaporation", "rain", "river"]
          : ["evaporation", "condensation", "precipitation", "runoff", "groundwater"]
      };
    }
    case "states_of_matter": {
      return {
        ...base,
        type: "states_of_matter",
        title: "States of matter"
      };
    }
    case "food_chain": {
      return {
        ...base,
        type: "food_chain",
        title: "Food chain"
      };
    }
    case "simple_circuit": {
      return {
        ...base,
        type: "simple_circuit",
        title: "Simple circuit"
      };
    }
    case "cell_simple": {
      return {
        ...base,
        type: "cell_simple",
        title: "Cell structure"
      };
    }
    case "map_scale": {
      return {
        ...base,
        type: "map_scale",
        title: "Map scale"
      };
    }


    case "info_cycle": {
      return { ...base, type: "info_cycle", title: "Information processing cycle" };
    }
    case "computer_block": {
      return { ...base, type: "computer_block", title: "Computer system (block diagram)" };
    }
    case "file_tree": {
      return { ...base, type: "file_tree", title: "Folder hierarchy" };
    }
    case "spreadsheet_grid": {
      return { ...base, type: "spreadsheet_grid", title: "Spreadsheet cells" };
    }
    case "db_table": {
      return { ...base, type: "db_table", title: "Database table" };
    }
    case "network_star": {
      return { ...base, type: "network_star", title: "Star topology" };
    }
    default:
      return { ...base, type: kind, ...overrides };
  }
}

/** Map topic ids to a preferred diagram kind. */
export function diagramForTopic(topicId, grade = 8) {
  const map = {
    ns_planet_earth: "solar_system",
    ns_life_living: "plant_structure",
    ns_matter_materials: "atom_bohr",
    ns_energy_change: "simple_circuit",
    ns_cells: "cell_plant",
    ls_chemistry: "atom_bohr",
    ns_systems: "organ_digestive",
    ls_cells: "cell_plant",
    ls_mitosis: "mitosis_stages",
    ls_photosynthesis: "photosynthesis",
    ls_human: "organ_heart",
    ls_nutrition: "organ_digestive",
    ls_environment: "food_web",
    ls_tissues: "cell_animal",
    ls_support: "plant_structure",
    geo_atmosphere: "water_cycle",
    geo_water: "water_cycle",
    geo_mapwork: "map_scale",
    geo_population: "population_pyramid",
    geo_geomorphology: "plate_tectonics",
    geo_climate: "water_cycle",
    tech_structures: "lever",
    tech_electrical: "simple_circuit",
    tech_mechanical: "lever",
    acc_concepts: "accounting_equation",
    acc_books: "journal_table",
    acc_ledger: "t_account",
    acc_bank: "bank_recon",
    acc_financials: "income_statement",
    acc_debtors: "t_account",
    acc_inventory: "journal_table",
    acc_vat: "journal_table",
    acc_analysis: "income_statement",
    acc_costing: "journal_table",
    cat_systems: "info_cycle",
    cat_hardware: "computer_block",
    cat_files: "file_tree",
    cat_spreadsheet: "spreadsheet_grid",
    cat_database: "db_table",
    cat_network: "network_star"
  };
  const kind = map[topicId];
  if (!kind) return null;
  return recipe(kind, grade);
}

export function availableKinds() {
  return [
    "solar_system", "plant_structure", "organ_heart", "organ_digestive",
    "cell_plant", "cell_animal", "food_web", "journal_table", "t_account",
    "trial_balance", "accounting_equation", "bank_recon", "income_statement",
    "lever", "bird_in_flight", "leaf_outline", "water_cycle", "states_of_matter",
    "food_chain", "simple_circuit", "mitosis_stages", "photosynthesis", "atom_bohr",
    "population_pyramid", "plate_tectonics", "cell_simple", "map_scale",
    "info_cycle", "computer_block", "file_tree", "spreadsheet_grid", "db_table", "network_star"
  ];
}
