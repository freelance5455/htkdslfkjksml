import { generateMathsRecipe } from "./g12Recipes.js";
// FET Phase (Grade 10–11) mathematics question generators — CAPS-aligned.
// Equations & Inequalities expanded from authentic Grade 11 past-paper patterns.

function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function round2(n) { return Math.round(n * 100) / 100; }

function base(topic, q, a, d, hint, exp, diagram = null, marks = null) {
  return {
    id: `fet_${topic}_${ri(10000, 99999)}`,
    topic,
    topic_name: topic.replaceAll("_", " "),
    question: q,
    answer: String(a),
    difficulty: d,
    hint: hint || "",
    explanation: exp || "",
    marks: marks != null ? marks : Math.max(2, Math.min(6, d + 1)),
    diagram
  };
}

function quadraticRoots(a, b, c) {
  const disc = b * b - 4 * a * c;
  if (disc < 0) return { disc, real: false, roots: [] };
  const s = Math.sqrt(disc);
  return {
    disc,
    real: true,
    roots: [(-b + s) / (2 * a), (-b - s) / (2 * a)]
  };
}

export class FetQuestionEngine {
  constructor(grade = 11) {
    this.grade = grade;
  }

  generate(topicId, difficulty = 1) {
    const d = Math.max(1, Math.min(4, difficulty | 0));
    if (this.grade === 12) {
      const rq = generateMathsRecipe(topicId, d);
      if (rq && Math.random() < 0.65) return rq;
    }
    const map = {
      exponents_surds: () => this._exponentsSurds(d),
      equations_inequalities: () => this._equations(d),
      number_patterns: () => this._patterns(d),
      functions_graphs: () => this._functions(d),
      trigonometry: () => this._trig(d),
      analytical_geometry: () => this._analytical(d),
      euclidean_geometry: () => this._euclidean(d),
      measurement_11: () => this._measurement(d),
      finance_11: () => this._finance(d),
      probability_11: () => this._probability(d),
      statistics_11: () => this._statistics(d),
      // Grade 12 CAPS topic ids
      sequences_series: () => this._patterns(d),
      finance_12: () => this._finance(d),
      algebra_calculus: () => this._calculusG12(d),
      probability_12: () => this._probability(d),
      statistics_12: () => this._statistics(d),
      algebraic_expressions_10: () => this._equations(d),
      exponents_10: () => this._exponentsSurds(d),
      number_patterns_10: () => this._patterns(d),
      functions_10: () => this._functions(d),
      finance_10: () => this._finance(d),
      trigonometry_10: () => this._trig(d),
      analytical_geometry_10: () => this._analytical(d),
      euclidean_geometry_10: () => this._euclidean(d),
      statistics_10: () => this._statistics(d),
      probability_10: () => this._probability(d)
    };
    const fn = map[topicId] || (() => this._exponentsSurds(d));
    return fn();
  }

  // ─── EQUATIONS & INEQUALITIES (primary CAPS Q1 patterns from past papers) ─
  _equations(d) {
    if (d <= 1) return choice([this._linearFactor.bind(this), this._quadFactor.bind(this)])(d);
    if (d === 2) {
      return choice([
        this._quadFactor.bind(this),
        this._quadFormula.bind(this),
        this._simultaneous.bind(this),
        this._quadIneq.bind(this)
      ])(d);
    }
    return choice([
      this._quadFactor.bind(this),
      this._quadFormula.bind(this),
      this._quadIneq.bind(this),
      this._simultaneous.bind(this),
      this._surdEq.bind(this),
      this._expEq.bind(this),
      this._natureRoots.bind(this),
      this._rationalDomain.bind(this)
    ])(d);
  }

  _linearFactor(d) {
    const a = ri(1, 6), b = ri(-8, 8);
    const r = ri(-5, 6);
    const rhs = a * r + b;
    return base("equations_inequalities",
      `Solve for x:\n${a}x ${b >= 0 ? "+" : "−"} ${Math.abs(b)} = ${rhs}`,
      r, d,
      "Isolate the variable term, then divide.",
      `${a}x = ${rhs - b}\nx = ${r}`,
      null, 2);
  }

  _quadFactor(d) {
    const r1 = ri(-6, 6), r2 = ri(-6, 6);
    const b = -(r1 + r2);
    const c = r1 * r2;
    const bs = b === 0 ? "" : (b > 0 ? ` + ${b}x` : ` − ${Math.abs(b)}x`);
    const cs = c === 0 ? "" : (c > 0 ? ` + ${c}` : ` − ${Math.abs(c)}`);
    const ans = r1 === r2 ? `x = ${r1}` : `x = ${Math.min(r1, r2)} or x = ${Math.max(r1, r2)}`;
    return base("equations_inequalities",
      `Solve for x:\nx²${bs}${cs} = 0`,
      ans, d,
      "Factorise into two linear factors and use the zero-product property.",
      `x²${bs}${cs} = (x − ${r1})(x − ${r2}) = 0\n∴ x = ${r1} or x = ${r2}`,
      null, 3);
  }

  _quadFormula(d) {
    let a, b, c, roots, disc;
    do {
      a = ri(1, 4);
      b = ri(-9, 9);
      c = ri(-12, 8);
      ({ disc, roots } = quadraticRoots(a, b, c));
    } while (disc < 0 || !Number.isFinite(roots[0]));
    const r1 = round2(roots[0]), r2 = round2(roots[1]);
    const bs = b === 0 ? "" : (b > 0 ? ` + ${b}x` : ` − ${Math.abs(b)}x`);
    const cs = c === 0 ? "" : (c > 0 ? ` + ${c}` : ` − ${Math.abs(c)}`);
    const ans = r1 === r2 ? `x = ${r1}` : `x = ${Math.min(r1, r2)} or x = ${Math.max(r1, r2)}`;
    const lead = a === 1 ? "x²" : `${a}x²`;
    return base("equations_inequalities",
      `Solve for x (answers correct to TWO decimal places):\n${lead}${bs}${cs} = 0`,
      ans, d,
      "Use the quadratic formula: x = (−b ± √(b² − 4ac)) / (2a).",
      `a = ${a}, b = ${b}, c = ${c}\nΔ = ${b}² − 4(${a})(${c}) = ${disc}\nx = (${-b} ± √${disc}) / ${2 * a}\nx ≈ ${r1} or x ≈ ${r2}`,
      null, 4);
  }

  _quadIneq(d) {
    const r1 = ri(-5, 2), r2 = ri(r1 + 1, 6);
    const op = choice(["<", "≤", ">", "≥"]);
    const critical = [r1, r2].sort((x, y) => x - y);
    let interval;
    if (op === "<" || op === "≤") {
      interval = op === "<"
        ? `${critical[0]} < x < ${critical[1]}`
        : `${critical[0]} ≤ x ≤ ${critical[1]}`;
    } else {
      interval = op === ">"
        ? `x < ${critical[0]} or x > ${critical[1]}`
        : `x ≤ ${critical[0]} or x ≥ ${critical[1]}`;
    }
    const b = -(r1 + r2), c = r1 * r2;
    const bs = b === 0 ? "" : (b > 0 ? ` + ${b}x` : ` − ${Math.abs(b)}x`);
    const cs = c === 0 ? "" : (c > 0 ? ` + ${c}` : ` − ${Math.abs(c)}`);
    return base("equations_inequalities",
      `Solve for x:\nx²${bs}${cs} ${op} 0`,
      interval, d,
      "Factorise, find critical values, test intervals on a number line.",
      `Critical values: x = ${r1}, x = ${r2}.\nSign chart yields: ${interval}`,
      null, 4);
  }

  _simultaneous(d) {
    if (d <= 2) {
      const a = ri(1, 4), b = ri(1, 4);
      const x = ri(-4, 5), y = ri(-4, 5);
      const c1 = a * x + b * y;
      const c2 = x + y;
      return base("equations_inequalities",
        `Solve for x and y simultaneously:\n${a}x ${b >= 0 ? "+" : "−"} ${Math.abs(b)}y = ${c1}\nx + y = ${c2}`,
        `x = ${x}, y = ${y}`, d,
        "Solve the simpler equation for one variable and substitute.",
        `From x + y = ${c2}: y = ${c2} − x.\nSubstitute into first equation and solve.`,
        null, 5);
    }
    const x = ri(-5, 5) || 2;
    const y = ri(-4, 4) || 3;
    const k = x * y;
    const a = ri(1, 3);
    const c = a * x + y;
    return base("equations_inequalities",
      `Solve for x and y simultaneously:\n${a}x + y = ${c}\nxy = ${k}`,
      `x = ${x}, y = ${y}`, d,
      "Express y from the linear equation and substitute into the product equation.",
      `y = ${c} − ${a}x\nx(${c} − ${a}x) = ${k}\nSolve the resulting quadratic.`,
      null, 6);
  }

  _surdEq(d) {
    const m = ri(2, 6);
    const k = ri(0, 8);
    const xAns = m * m - k;
    return base("equations_inequalities",
      `Solve for x:\n√(x + ${k}) = ${m}`,
      xAns, d,
      "Square both sides; check the solution satisfies the original equation and domain.",
      `x + ${k} = ${m}² = ${m * m}\nx = ${xAns}\nCheck: √(${xAns} + ${k}) = ${m} ✓`,
      null, 4);
  }

  _expEq(d) {
    if (ri(0, 1) === 0) {
      const m = ri(2, 5);
      return base("equations_inequalities",
        `Solve for x:\n2^x = 2^${m}`,
        m, d,
        "If bases are equal and > 0, ≠ 1, then exponents are equal.",
        `Bases equal ⇒ x = ${m}`,
        null, 3);
    }
    const target = choice([12, 24, 48, 96]);
    const xAns = Math.log2(target / 3);
    if (!Number.isInteger(xAns)) {
      return base("equations_inequalities",
        `Solve for x:\n2^x + 2^{x+1} = ${target}`,
        `2^x = ${target / 3}`, d,
        "Factor out the smaller power of 2.",
        `2^x (1 + 2) = ${target}\n3 · 2^x = ${target}\n2^x = ${target / 3}`,
        null, 4);
    }
    return base("equations_inequalities",
      `Solve for x:\n2^x + 2^{x+1} = ${target}`,
      xAns, d,
      "Factor out 2^x.",
      `2^x (1 + 2) = ${target}\n3 · 2^x = ${target}\n2^x = ${target / 3}\nx = ${xAns}`,
      null, 4);
  }

  _natureRoots(d) {
    const p = ri(1, 6);
    return base("equations_inequalities",
      `Given: (x − ${p})² = k² − 4\nDetermine the value(s) of k for which the roots will be non-real.`,
      `−2 < k < 2`, d,
      "Roots are non-real when the right-hand side is negative.",
      `(x − ${p})² ≥ 0 for real x.\nNeed k² − 4 < 0 ⇒ k² < 4 ⇒ −2 < k < 2`,
      null, 5);
  }

  _rationalDomain(d) {
    const a = ri(1, 5), b = ri(1, 3), c = ri(1, 6), den = ri(2, 7);
    return base("equations_inequalities",
      `Given: P = [(x + ${a})(${b}x − ${c})] / (${den} − x)\nDetermine the value(s) of x for which P is:\n(a) equal to zero\n(b) undefined`,
      `(a) x = −${a} or x = ${c}/${b}\n(b) x = ${den}`, d,
      "Fraction = 0 when numerator = 0 (denominator ≠ 0). Undefined when denominator = 0.",
      `(a) (x + ${a})(${b}x − ${c}) = 0 ⇒ x = −${a} or x = ${c}/${b}\n(b) ${den} − x = 0 ⇒ x = ${den}`,
      null, 3);
  }

  // ─── OTHER TOPICS ────────────────────────────────────────────────────────
  _exponentsSurds(d) {
    const roll = ri(0, 5);
    if (roll === 0) {
      const a = ri(2, 5), m = ri(2, 4), n = ri(1, 3);
      const ans = a ** (m + n);
      return base("exponents_surds",
        `Simplify fully: ${a}^${m} × ${a}^${n}`,
        ans, d,
        "aᵐ × aⁿ = aᵐ⁺ⁿ",
        `${a}^${m} × ${a}^${n} = ${a}^${m + n} = ${ans}.`, null, 2);
    }
    if (roll === 1) {
      const a = ri(2, 5), m = ri(3, 6), n = ri(1, 2);
      const ans = a ** (m - n);
      return base("exponents_surds",
        `Simplify fully: ${a}^${m} ÷ ${a}^${n}`,
        ans, d,
        "aᵐ ÷ aⁿ = aᵐ⁻ⁿ",
        `${a}^${m} ÷ ${a}^${n} = ${a}^${m - n} = ${ans}.`, null, 2);
    }
    if (roll === 2 || d >= 3) {
      // exponential equation
      const baseN = choice([2, 3, 5]);
      const exp = ri(2, 4);
      const rhs = baseN ** exp;
      return base("exponents_surds",
        `Solve for x:\n${baseN}^x = ${rhs}`,
        exp, d,
        "Express both sides with the same base.",
        `${baseN}^x = ${baseN}^${exp}\n∴ x = ${exp}.`, null, 3);
    }
    if (roll === 3) {
      const a = choice([8, 27, 32, 64]);
      // simplify as power
      const map = { 8: "2³", 27: "3³", 32: "2⁵", 64: "2⁶ or 4³ or 8²" };
      return base("exponents_surds",
        `Write ${a} as a power with prime base.`,
        map[a].split(" or ")[0], d,
        "Factorise into primes and write in index form.",
        `${a} = ${map[a]}.`, null, 3);
    }
    if (roll === 4) {
      const a = choice([12, 18, 20, 24, 28, 45, 50]);
      // simplify sqrt
      const pairs = {
        12: ["2√3", "√12 = √(4×3) = 2√3"],
        18: ["3√2", "√18 = √(9×2) = 3√2"],
        20: ["2√5", "√20 = √(4×5) = 2√5"],
        24: ["2√6", "√24 = √(4×6) = 2√6"],
        28: ["2√7", "√28 = √(4×7) = 2√7"],
        45: ["3√5", "√45 = √(9×5) = 3√5"],
        50: ["5√2", "√50 = √(25×2) = 5√2"]
      };
      const [ans, exp] = pairs[a]
      return base("exponents_surds",
        `Simplify fully: √${a}`,
        ans, d,
        "Factor out perfect squares from the radicand.",
        exp, null, 3);
    }
    const a = [4, 9, 16, 25, 36, 49, 81][ri(0, 6)];
    const root = Math.round(Math.sqrt(a));
    return base("exponents_surds", `Simplify: √${a}`, root, d, "Find the positive square root.", `√${a} = ${root}.`);
  }

  _patterns(d) {
    // Quadratic number pattern (CAPS Grade 11 common form)
    if (d >= 2 && ri(0, 2) > 0) {
      const a = ri(1, 3);
      const b = ri(-6, 6);
      const c = ri(-10, 20);
      const T = (n) => a * n * n + b * n + c;
      const terms = [T(1), T(2), T(3), T(4)];
      if (d >= 3) {
        // Find consecutive terms with given first difference
        const targetDiff = -(ri(20, 80));
        // first difference between T_n and T_{n+1}: a(2n+1) + b
        // a(2n+1)+b = targetDiff → 2an + a + b = targetDiff → n = (targetDiff - a - b)/(2a)
        const num = targetDiff - a - b;
        if (num % (2 * a) === 0) {
          const n = num / (2 * a);
          if (n >= 1 && n <= 20) {
            return base("number_patterns",
              `Quadratic number pattern: ${terms.join("; ")}; …\nCalculate two consecutive terms whose first difference is ${targetDiff}.`,
              `T_${n} = ${T(n)}, T_${n + 1} = ${T(n + 1)}`,
              d,
              "First difference ΔTₙ = Tₙ₊₁ − Tₙ = a(2n + 1) + b.",
              `ΔTₙ = ${a}(2n + 1) + (${b}) = ${targetDiff}\n2n + 1 = ${(targetDiff - b) / a}\nn = ${n}\nT_${n} = ${T(n)}, T_${n + 1} = ${T(n + 1)}.`,
              null, 5);
          }
        }
        return base("number_patterns",
          `Quadratic number pattern: ${terms.join("; ")}; …\nDetermine the general term Tₙ.`,
          `Tₙ = ${a}n² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}n ${c >= 0 ? "+" : "−"} ${Math.abs(c)}`,
          d,
          "Second difference is constant (2a). Use Tₙ = an² + bn + c with the first three terms.",
          `Second differences = ${2 * a}. Hence a = ${a}.\nUsing T₁ and T₂: b = ${b}, c = ${c}.\nTₙ = ${a}n² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}n ${c >= 0 ? "+" : "−"} ${Math.abs(c)}.`,
          null, 5);
      }
      return base("number_patterns",
        `Quadratic number pattern: ${terms.join("; ")}; …\nDetermine the next two terms.`,
        `${T(5)}; ${T(6)}`,
        d,
        "Find the first and second differences, then extend the pattern.",
        `Next terms: T₅ = ${T(5)}, T₆ = ${T(6)}.`,
        null, 3);
    }
    // Geometric
    if (d >= 3 && ri(0, 1) === 0) {
      const a = ri(2, 5), r = ri(2, 4);
      const n = ri(4, 6);
      const Tn = a * (r ** (n - 1));
      return base("number_patterns",
        `Geometric sequence: first term a = ${a}, common ratio r = ${r}.\nFind T_${n}.`,
        Tn, d, "Tₙ = a rⁿ⁻¹",
        `T_${n} = ${a} × ${r}^${n - 1} = ${Tn}.`, null, 4);
    }
    // Linear / arithmetic
    const a = ri(2, 12), dlt = choice([-7, -5, -3, -2, 2, 3, 4, 5, 6]);
    if (d >= 2 && ri(0, 1) === 0) {
      const n = ri(5, 15);
      const Tn = a + (n - 1) * dlt;
      return base("number_patterns",
        `Linear number pattern: first term ${a}, common difference ${dlt}.\nDetermine T_${n}.`,
        Tn, d, "Tₙ = a + (n − 1)d",
        `T_${n} = ${a} + (${n} − 1)(${dlt}) = ${Tn}.`, null, 3);
    }
    const terms = [a, a + dlt, a + 2 * dlt, a + 3 * dlt];
    const next = a + 4 * dlt;
    // Sometimes ask for number of terms until a given last term
    if (ri(0, 1) === 0) {
      const last = a + (ri(20, 40) - 1) * dlt;
      const nTerms = Math.round((last - a) / dlt) + 1;
      return base("number_patterns",
        `Linear number pattern: ${terms.join("; ")}; … ; ${last}\nDetermine the number of terms in the pattern.`,
        nTerms, d, "n = (Tₙ − a)/d + 1",
        `n = (${last} − ${a})/(${dlt}) + 1 = ${nTerms}.`, null, 3);
    }
    return base("number_patterns",
      `Linear number pattern: ${terms.join("; ")}; …\nWrite down the next two terms and the general term Tₙ.`,
      `Next: ${next}; ${next + dlt}. Tₙ = ${a} + (n − 1)(${dlt})`,
      d, `Common difference is ${dlt}.`,
      `Next terms: ${next}; ${next + dlt}.\nTₙ = ${a} + (n − 1)(${dlt}).`, null, 4);
  }

  _functions(d) {
    const roll = ri(0, 4);
    if (roll <= 1) {
      const a = choice([1, 2, 3, -2]), p = ri(-3, 3), q = ri(-4, 4);
      const diagram = { type: "hyperbola", a, p, q };
      if (q !== 0) {
        const xi = round2(-p - a / q);
        diagram.intercept = { x: xi, y: 0 };
      }
      return base("functions_graphs",
        `The graph of f(x) = ${a}/(x ${p >= 0 ? "+" : "−"} ${Math.abs(p)}) ${q >= 0 ? "+" : "−"} ${Math.abs(q)} is shown.\nWrite down the equations of the asymptotes of f.`,
        `x = ${-p}; y = ${q}`,
        d,
        "Vertical asymptote: denominator zero; horizontal asymptote: y = q.",
        `Asymptotes: x = ${-p} and y = ${q}.`,
        diagram, 3);
    }
    if (roll === 2) {
      const a = choice([1, 2, 3]), b = choice([2, 3]), q = ri(-3, 2);
      const yInt = a + q;
      return base("functions_graphs",
        `Given f(x) = ${a}(${b})^x ${q >= 0 ? "+" : "−"} ${Math.abs(q)}.\nWrite down the y-intercept and the equation of the asymptote.`,
        `(0; ${yInt}); y = ${q}`,
        d,
        "y-intercept at x = 0; horizontal asymptote y = q.",
        `f(0) = ${a} + (${q}) = ${yInt}. Asymptote: y = ${q}.`,
        { type: "exponential", a, b, q }, 4);
    }
    if (roll === 3 || d >= 3) {
      const a = ri(1, 3), b = ri(-6, 6), c = ri(-5, 5);
      const xv = -b / (2 * a);
      const yv = a * xv * xv + b * xv + c;
      return base("functions_graphs",
        `f(x) = ${a}x² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}x ${c >= 0 ? "+" : "−"} ${Math.abs(c)}\nDetermine the coordinates of the turning point of f.`,
        `(${round2(xv)}; ${round2(yv)})`,
        d,
        "x = −b/(2a); substitute into f to find y.",
        `x = −(${b})/(2×${a}) = ${round2(xv)}\ny = f(${round2(xv)}) = ${round2(yv)}.`,
        null, 4);
    }
    const m = ri(1, 5), c = ri(-6, 8), x = ri(-3, 5);
    const y = m * x + c;
    return base("functions_graphs",
      `If f(x) = ${m}x ${c >= 0 ? "+" : "−"} ${Math.abs(c)}, find f(${x}).`,
      y, d, "Substitute the given x into the formula.",
      `f(${x}) = ${m}(${x}) ${c >= 0 ? "+" : "−"} ${Math.abs(c)} = ${y}.`);
  }

  _trig(d) {
    const roll = ri(0, 4);
    if (roll === 0 || (d >= 2 && roll === 1)) {
      const ang = choice([20, 25, 35, 40, 50, 55]);
      const forms = [
        [`sin(90° − ${ang}°)`, `cos(${ang}°)`, "sin(90° − θ) = cos θ"],
        [`cos(90° − ${ang}°)`, `sin(${ang}°)`, "cos(90° − θ) = sin θ"],
        [`sin(180° − ${ang}°)`, `sin(${ang}°)`, "sin(180° − θ) = sin θ"],
        [`cos(180° − ${ang}°)`, `−cos(${ang}°)`, "cos(180° − θ) = −cos θ"],
        [`sin(360° − ${ang}°)`, `−sin(${ang}°)`, "sin(360° − θ) = −sin θ"]
      ];
      const [q, a, why] = forms[ri(0, forms.length - 1)];
      return base("trigonometry",
        `Simplify fully:\n${q}`,
        a, d, "Use reduction formulae.",
        `${why}\n∴ ${q} = ${a}.`, null, 3);
    }
    if (roll === 2 || d >= 3) {
      const eq = choice([
        ["sin θ = 1/2", "θ = 30° or θ = 150°", "Reference 30°; sin positive in QI and QII."],
        ["cos θ = 1/2", "θ = 60° or θ = 300°", "Reference 60°; cos positive in QI and QIV."],
        ["tan θ = 1", "θ = 45° or θ = 225°", "Reference 45°; tan positive in QI and QIII."]
      ]);
      return base("trigonometry",
        `Solve for θ ∈ [0°; 360°]:\n${eq[0]}`,
        eq[1], d, eq[2],
        `${eq[2]}\n${eq[1]}.`, null, 4);
    }
    if (roll === 3) {
      const a = choice([3, 4, 5, 6, 8, 12]);
      const b = choice([3, 4, 5, 6, 8]);
      return base("trigonometry",
        `In right-angled △ABC with ∠B = 90°, AB = ${a} and BC = ${b}.\nWrite down tan Â as a fraction.`,
        `${b}/${a}`,
        d, "tan Â = opposite / adjacent = BC/AB.",
        `tan Â = ${b}/${a}.`,
        { type: "right_triangle", a: b, b: a, c: "?", find: "c" }, 3);
    }
    const table = [
      [30, "sin", "1/2"], [30, "cos", "√3/2"], [30, "tan", "1/√3"],
      [45, "sin", "√2/2"], [45, "cos", "√2/2"], [45, "tan", "1"],
      [60, "sin", "√3/2"], [60, "cos", "1/2"], [60, "tan", "√3"],
      [90, "sin", "1"], [0, "cos", "1"]
    ];
    const [ang, fn, ans] = table[ri(0, table.length - 1)];
    return base("trigonometry", `Evaluate: ${fn}(${ang}°)`, ans, d, "Use special-angle values.", `${fn}(${ang}°) = ${ans}.`);
  }

  _analytical(d) {
    const x1 = ri(-6, 6), y1 = ri(-6, 6), x2 = ri(-6, 6), y2 = ri(-6, 6);
    if (x1 === x2 && y1 === y2) return this._analytical(d);
    const dx = x2 - x1, dy = y2 - y1;
    const diagram = {
      type: "coordinate_plane",
      span: 16,
      points: [
        { label: "A", x: x1, y: y1 },
        { label: "B", x: x2, y: y2 }
      ],
      connect: true
    };
    const roll = ri(0, 4);
    if (roll === 0 || (d >= 3 && roll === 1)) {
      if (dx === 0) {
        return base("analytical_geometry",
          `Determine the gradient of the line through A(${x1}; ${y1}) and B(${x2}; ${y2}).`,
          "undefined", d, "Vertical line: gradient undefined.",
          "x₁ = x₂ ⇒ vertical line ⇒ gradient undefined.", diagram, 3);
      }
      const m = round2(dy / dx);
      return base("analytical_geometry",
        `Determine the gradient of the line through A(${x1}; ${y1}) and B(${x2}; ${y2}).`,
        m, d, "m = (y₂ − y₁)/(x₂ − x₁)",
        `m = (${dy})/(${dx}) = ${m}.`, diagram, 3);
    }
    if (roll === 2) {
      const mx = round2((x1 + x2) / 2), my = round2((y1 + y2) / 2);
      return base("analytical_geometry",
        `Determine the midpoint of A(${x1}; ${y1}) and B(${x2}; ${y2}).`,
        `(${mx}; ${my})`, d, "M = ((x₁+x₂)/2 ; (y₁+y₂)/2)",
        `M = ((${x1}+${x2})/2 ; (${y1}+${y2})/2) = (${mx}; ${my}).`, diagram, 3);
    }
    if (roll === 3 && dx !== 0) {
      const m = round2(dy / dx);
      // equation of line
      const c = round2(y1 - m * x1);
      const eq = m === 0 ? `y = ${y1}` : `y = ${m}x ${c >= 0 ? "+" : "−"} ${Math.abs(c)}`;
      return base("analytical_geometry",
        `Determine the equation of the line through A(${x1}; ${y1}) and B(${x2}; ${y2}) in the form y = mx + c.`,
        eq, d, "Find m, then use y − y₁ = m(x − x₁).",
        `m = ${m}\ny − ${y1} = ${m}(x − ${x1})\n${eq}.`, diagram, 4);
    }
    const dist2 = dx * dx + dy * dy;
    return base("analytical_geometry",
      `Distance between A(${x1}; ${y1}) and B(${x2}; ${y2}).\nGive the exact value as √k (enter k only).`,
      dist2, d, "Use d² = (x₂−x₁)² + (y₂−y₁)².",
      `d² = (${dx})² + (${dy})² = ${dist2}. So d = √${dist2}.`, diagram, 4);
  }

  _euclidean(d) {
    // Expanded CAPS G10–11 Euclidean: centre, same segment, cyclic, exterior,
    // tan-chord, radius⊥tangent, equal tangents, semicircle, perp-from-centre,
    // equal radii, multi-step riders. Diagram modes match render.js circle_geometry.
    const roll = ri(0, 17);

    if (roll === 14) {
      const centre = ri(50, 100);
      const baseAng = Math.round(((180 - centre) / 2) * 10) / 10;
      const inscribed = centre / 2;
      return base("euclidean_geometry",
        `O is the centre of circle ABC. OA, OB and OC are radii.\n∠AOB = ${centre}°.\n9.1 Calculate ∠OAB.\n9.2 Hence calculate ∠ACB if C is on the circumference standing on arc AB.\n9.3 Name the theorem used in 9.2.`,
        `${baseAng}° ; ${inscribed}° ; ∠ at centre = 2∠ at circ.`,
        d, "Equal radii ⇒ isosceles; angle at the centre is twice the angle at the circumference.",
        `9.1 OA = OB (radii) ⇒ ∠OAB = ∠OBA = (180° − ${centre}°)/2 = ${baseAng}°.\n9.2 ∠ACB = ½∠AOB = ${inscribed}° (∠ at centre = 2∠ at circ.).\n9.3 Angle at the centre theorem.`,
        { type: "circle_geometry", mode: "centre", radii: ["A", "B", "C"], points: [{ label: "A", ang: 200 }, { label: "B", ang: 320 }, { label: "C", ang: 50 }], chords: [["A", "B"], ["A", "C"], ["B", "C"]], angleLabel: `∠AOB = ${centre}°`, title: "Multi-step rider" }, 6);
    }
    if (roll === 15) {
      const abc = ri(75, 105);
      const adc = 180 - abc;
      return base("euclidean_geometry",
        `ABCD is a cyclic quadrilateral. ∠ABC = ${abc}°.\nSide AB is produced to E.\n10.1 Calculate ∠ADC.\n10.2 Write down ∠CBE.\n10.3 Give reasons for each answer.`,
        `${adc}° ; ${adc}°`, d,
        "Opposite angles of a cyclic quadrilateral are supplementary; exterior angle equals opposite interior angle.",
        `10.1 ∠ADC = 180° − ${abc}° = ${adc}° (opp. ∠s of cyclic quad).\n10.2 ∠CBE = ∠ADC = ${adc}° (ext. ∠ of cyclic quad).\n10.3 Reasons as above.`,
        { type: "circle_geometry", mode: "cyclic", points: [{ label: "A", ang: 150 }, { label: "B", ang: 230 }, { label: "C", ang: 310 }, { label: "D", ang: 50 }], chords: [["A", "B"], ["B", "C"], ["C", "D"], ["D", "A"]], angleLabel: `∠ABC = ${abc}°`, title: "Cyclic rider" }, 6);
    }
    if (roll === 16) {
      const tanAng = ri(28, 60);
      const other = ri(40, 70);
      const third = 180 - tanAng - other;
      return base("euclidean_geometry",
        `Tangent at A touches the circle. Chord AB makes an angle of ${tanAng}° with the tangent.\nC is a point in the alternate segment. ∠ABC = ${other}°.\n11.1 Calculate ∠ACB.\n11.2 Calculate ∠BAC.`,
        `${tanAng}° ; ${third}°`, d,
        "Tangent–chord theorem; angles in a triangle sum to 180°.",
        `11.1 ∠ACB = ${tanAng}° (tan-chord / alternate segment).\n11.2 ∠BAC = 180° − ${tanAng}° − ${other}° = ${third}°.`,
        { type: "circle_geometry", mode: "tangent", points: [{ label: "A", ang: 90 }, { label: "B", ang: 210 }, { label: "C", ang: 330 }], chords: [["A", "B"], ["B", "C"], ["A", "C"]], angleLabel: `tan∠ = ${tanAng}°`, title: "Tangent rider" }, 5);
    }
    if (roll === 17) {
      const a = ri(25, 50);
      const b = 90 - a;
      return base("euclidean_geometry",
        `AB is a diameter of a circle with centre O. C is on the circumference. ∠BAC = ${a}°.\n12.1 Write down ∠ACB and give a reason.\n12.2 Calculate ∠ABC.\n12.3 If OA = OC, calculate ∠AOC.`,
        `90° ; ${b}° ; ${2 * a}°`, d,
        "Angle in a semicircle is 90°; isosceles radii; centre–circumference.",
        `12.1 ∠ACB = 90° (∠ in a semicircle).\n12.2 ∠ABC = 180° − 90° − ${a}° = ${b}°.\n12.3 ∠AOC = 2 × ∠ABC = ${2 * a}° (∠ at centre = 2∠ at circ., same arc AC).`,
        { type: "circle_geometry", mode: "semicircle", radii: ["A", "B", "C"], points: [{ label: "A", ang: 180 }, { label: "B", ang: 0 }, { label: "C", ang: 70 }], chords: [["A", "C"], ["B", "C"]], angleLabel: `∠BAC = ${a}°`, title: "Diameter + centre rider" }, 6);
    }
    if (roll === 0) {
      const centre = ri(40, 140);
      const inscribed = centre / 2;
      return base("euclidean_geometry",
        `O is the centre of the circle. ∠AOB = ${centre}°. C is a point on the circumference standing on arc AB.\nCalculate ∠ACB.`,
        inscribed, d, "The angle at the centre is twice the angle at the circumference subtended by the same arc.",
        `∠ACB = ½ × ${centre}° = ${inscribed}° (∠ at centre = 2∠ at circ.).`,
        { type: "circle_geometry", mode: "centre", radii: ["A", "B"], points: [{ label: "A", ang: 200 }, { label: "B", ang: 320 }, { label: "C", ang: 50 }], chords: [["A", "C"], ["B", "C"]], angleLabel: `∠AOB = ${centre}°`, title: "Centre–circumference" }, 3);
    }
    if (roll === 1) {
      const ang = ri(30, 70);
      return base("euclidean_geometry",
        `A, B, C and D are points on a circle. ∠ACB = ${ang}° and ∠ADB stands on the same arc AB.\nWrite down the size of ∠ADB and give a reason.`,
        `${ang}°`, d, "Angles in the same segment are equal.",
        `∠ADB = ${ang}° (angles in the same segment / same arc AB).`,
        { type: "circle_geometry", mode: "same_segment", points: [{ label: "A", ang: 200 }, { label: "B", ang: 340 }, { label: "C", ang: 50 }, { label: "D", ang: 110 }], chords: [["A", "C"], ["B", "C"], ["A", "D"], ["B", "D"]], angleLabel: `∠ACB = ${ang}°`, title: "Same segment" }, 3);
    }
    if (roll === 2) {
      const abc = ri(70, 110);
      return base("euclidean_geometry",
        `ABCD is a cyclic quadrilateral with ∠ABC = ${abc}°.\nCalculate ∠ADC.`,
        180 - abc, d, "Opposite angles of a cyclic quadrilateral are supplementary.",
        `∠ADC = 180° − ${abc}° = ${180 - abc}° (opp. ∠s of cyclic quad).`,
        { type: "circle_geometry", mode: "cyclic", points: [{ label: "A", ang: 160 }, { label: "B", ang: 240 }, { label: "C", ang: 320 }, { label: "D", ang: 50 }], chords: [["A", "B"], ["B", "C"], ["C", "D"], ["D", "A"]], angleLabel: `∠ABC = ${abc}°`, title: "Cyclic quadrilateral" }, 3);
    }
    if (roll === 3) {
      const tanAng = ri(25, 65);
      return base("euclidean_geometry",
        `A tangent touches the circle at A. Chord AB makes an angle of ${tanAng}° with the tangent.\nC is a point on the major arc. Calculate ∠ACB.`,
        tanAng, d, "Tangent–chord (alternate segment) theorem.",
        `∠ACB = ${tanAng}° (tan-chord / alternate segment).`,
        { type: "circle_geometry", mode: "tangent", points: [{ label: "A", ang: 90 }, { label: "B", ang: 210 }, { label: "C", ang: 330 }], chords: [["A", "B"], ["A", "C"]], angleLabel: `tan∠ = ${tanAng}°`, title: "Tan-chord theorem" }, 3);
    }
    if (roll === 4) {
      const a = ri(25, 55);
      const b = 90 - a;
      return base("euclidean_geometry",
        `AB is a diameter of a circle with centre O. C is a point on the circumference. ∠BAC = ${a}°.\nCalculate ∠ABC.`,
        b, d, "The angle in a semicircle is 90°. Angles in a triangle sum to 180°.",
        `∠ACB = 90° (∠ in semicircle)\n∠ABC = 180° − 90° − ${a}° = ${b}°.`,
        { type: "circle_geometry", mode: "semicircle", radii: ["A", "B"], points: [{ label: "A", ang: 180 }, { label: "B", ang: 0 }, { label: "C", ang: 70 }], chords: [["A", "C"], ["B", "C"]], angleLabel: `∠BAC = ${a}°`, title: "Angle in a semicircle" }, 4);
    }
    if (roll === 5) {
      const len = ri(8, 20);
      return base("euclidean_geometry",
        `Two tangents from external point T touch a circle at A and B. TA = ${len} cm.\nWrite down the length of TB. Give a reason.`,
        `${len} cm`, d, "Tangents from a common external point are equal in length.",
        `TB = TA = ${len} cm (tangents from the same external point are equal).`,
        { type: "circle_geometry", mode: "two_tangents", points: [{ label: "A", ang: 130 }, { label: "B", ang: 50 }, { label: "T", ang: 90, external: true }], chords: [["A", "B"]], angleLabel: "TA = TB", title: "Equal tangents" }, 3);
    }
    if (roll === 6) {
      const centre = ri(60, 120);
      const baseAng = Math.round(((180 - centre) / 2) * 10) / 10;
      return base("euclidean_geometry",
        `O is the centre. OA and OB are radii. ∠AOB = ${centre}°.\nCalculate ∠OAB.`,
        baseAng, d, "Radii are equal, so △OAB is isosceles; base angles equal.",
        `OA = OB (radii) ⇒ ∠OAB = ∠OBA = (180° − ${centre}°)/2 = ${baseAng}°.`,
        { type: "circle_geometry", mode: "centre", radii: ["A", "B"], points: [{ label: "A", ang: 200 }, { label: "B", ang: 320 }], chords: [["A", "B"]], angleLabel: `∠AOB = ${centre}°`, title: "Equal radii" }, 3);
    }
    if (roll === 7) {
      const om = ri(5, 12);
      const half = ri(8, 20);
      const ab = 2 * half;
      const r = Math.round(Math.sqrt(om * om + half * half) * 10) / 10;
      return base("euclidean_geometry",
        `O is the centre of a circle. Chord AB has midpoint M. OM ⊥ AB, OM = ${om} cm and AB = ${ab} cm.\nCalculate the radius of the circle (to 1 d.p. if necessary).`,
        r, d, "The line from the centre perpendicular to a chord bisects the chord. Apply Pythagoras in △OMA.",
        `AM = ${half} cm (perp from centre bisects chord).\nOA² = OM² + AM² = ${om}² + ${half}² = ${om * om + half * half}.\nOA = √${om * om + half * half} = ${r} cm.`,
        { type: "circle_geometry", mode: "perp_chord", radii: ["M"], points: [{ label: "A", ang: 200 }, { label: "B", ang: 340 }, { label: "M", ang: 270 }], angleLabel: `OM = ${om}`, title: "Perp. from centre to chord" }, 4);
    }
    if (roll === 8) {
      const intAng = ri(55, 100);
      return base("euclidean_geometry",
        `ABCD is a cyclic quadrilateral. Side AD is produced to E. ∠BCD = ${intAng}°.\nCalculate ∠CDE.`,
        intAng, d, "The exterior angle of a cyclic quadrilateral equals the opposite interior angle.",
        `∠CDE = ∠BCD = ${intAng}° (ext. ∠ of cyclic quad = opp. interior ∠).`,
        { type: "circle_geometry", mode: "cyclic", points: [{ label: "A", ang: 150 }, { label: "B", ang: 230 }, { label: "C", ang: 310 }, { label: "D", ang: 50 }], chords: [["A", "B"], ["B", "C"], ["C", "D"], ["D", "A"]], angleLabel: `∠BCD = ${intAng}°`, title: "Exterior angle cyclic quad" }, 3);
    }
    if (roll === 9) {
      return base("euclidean_geometry",
        `A tangent touches a circle with centre O at point A.\nWrite down the size of the angle between the radius OA and the tangent. Give a reason.`,
        `90°`, d, "A tangent is perpendicular to the radius at the point of contact.",
        `The angle is 90° (tangent ⊥ radius at point of contact).`,
        { type: "circle_geometry", mode: "tangent", points: [{ label: "A", ang: 90 }, { label: "B", ang: 210 }], chords: [["A", "B"]], angleLabel: "OA ⊥ tangent", title: "Radius ⊥ tangent" }, 2);
    }
    if (roll === 10) {
      const which = ri(0, 4);
      const statements = [
        { q: "Complete: The angle subtended by an arc at the centre of a circle is … the angle subtended by the same arc at the circumference.", a: "twice / double", exp: "∠ at centre = 2 × ∠ at circumference (same arc)." },
        { q: "Complete: Opposite angles of a cyclic quadrilateral are …", a: "supplementary / add to 180°", exp: "Opp. ∠s of cyclic quad are supplementary." },
        { q: "Complete: The line drawn from the centre of a circle perpendicular to a chord … the chord.", a: "bisects", exp: "Perp. from centre to chord bisects the chord." },
        { q: "Complete: Tangents drawn from a common external point to a circle are …", a: "equal in length", exp: "Tangents from a common external point are equal." },
        { q: "Complete: The angle between a tangent and a chord is equal to the angle in the … segment.", a: "alternate", exp: "Tan-chord / alternate segment theorem." }
      ];
      const s = statements[which];
      return base("euclidean_geometry", s.q, s.a, d, "Recall the formal CAPS theorem statements.", s.exp, null, 2);
    }
    if (roll === 11) {
      const ang1 = ri(28, 55);
      const ang2 = ri(30, 60);
      return base("euclidean_geometry",
        `In the circle, ∠ACB = ${ang1}° and ∠ADB = ${ang1}° (same segment on arc AB).\nChord CD is drawn. If ∠CAD = ${ang2}°, calculate ∠CBD if the angles stand on the same arc CD.`,
        `${ang2}°`, d, "Angles in the same segment are equal; identify the correct arc.",
        `∠CBD = ${ang2}° (same segment on arc CD).`,
        { type: "circle_geometry", mode: "same_segment", points: [{ label: "A", ang: 200 }, { label: "B", ang: 340 }, { label: "C", ang: 50 }, { label: "D", ang: 110 }], chords: [["A", "C"], ["B", "C"], ["A", "D"], ["B", "D"], ["C", "D"]], angleLabel: `∠ACB = ${ang1}°`, title: "Same segment (extended)" }, 4);
    }
    if (roll === 12) {
      const ang = ri(40, 80);
      return base("euclidean_geometry",
        `Two tangents from T touch the circle at A and B. O is the centre. ∠AOB = ${ang}°.\nCalculate ∠OAT.`,
        `90°`, d, "Radius ⊥ tangent at point of contact.",
        `∠OAT = 90° (radius ⊥ tangent).`,
        { type: "circle_geometry", mode: "two_tangents", radii: ["A", "B"], points: [{ label: "A", ang: 130 }, { label: "B", ang: 50 }, { label: "T", ang: 90, external: true }], chords: [["A", "B"]], angleLabel: `∠AOB = ${ang}°`, title: "Two tangents + radii" }, 4);
    }
    if (roll === 13) {
      const ap = ri(3, 8), pb = ri(4, 10), cp = ri(2, 7);
      const pd = Math.round((ap * pb / cp) * 10) / 10;
      return base("euclidean_geometry",
        `Chords AB and CD intersect at P inside the circle. AP = ${ap} cm, PB = ${pb} cm, CP = ${cp} cm.\nCalculate PD.`,
        pd, d, "Intersecting chords theorem: AP × PB = CP × PD.",
        `AP × PB = CP × PD\n${ap} × ${pb} = ${cp} × PD\nPD = ${ap * pb}/${cp} = ${pd} cm.`,
        { type: "circle_geometry", mode: "intersecting_chords", points: [{ label: "A", ang: 200 }, { label: "B", ang: 20 }, { label: "C", ang: 110 }, { label: "D", ang: 290 }, { label: "P", ang: 0 }], chords: [["A", "B"], ["C", "D"]], angleLabel: "AP·PB = CP·PD", title: "Intersecting chords" }, 4);
    }
    const a = ri(30, 80), b = ri(30, 80);
    const c = 180 - a - b;
    if (c <= 0) return this._euclidean(d);
    return base("euclidean_geometry",
      `In △ABC, Â = ${a}° and B̂ = ${b}°. Find Ĉ.`,
      c, d, "Angles in a triangle sum to 180°.",
      `Ĉ = 180° − ${a}° − ${b}° = ${c}°.`);
  }

  _measurement(d) {
    const roll = ri(0, 6);
    const pi = 3.14;
    if (roll === 0) {
      const r = ri(3, 12);
      const area = Math.round(pi * r * r * 10) / 10;
      return base("measurement_11",
        `Calculate the surface area of a sphere with radius ${r} cm (π ≈ 3,14).\nRound to 1 decimal place.`,
        Math.round(4 * pi * r * r * 10) / 10, d, "A = 4πr²",
        `A = 4 × 3,14 × ${r}² = ${Math.round(4 * pi * r * r * 10) / 10} cm².`,
        { type: "circle", r }, 4);
    }
    if (roll === 1) {
      const r = ri(3, 10), h = ri(5, 15);
      const V = Math.round(pi * r * r * h * 10) / 10;
      return base("measurement_11",
        `Volume of a cylinder with radius ${r} cm and height ${h} cm (π ≈ 3,14). Round to 1 d.p.`,
        V, d, "V = πr²h",
        `V ≈ 3,14 × ${r}² × ${h} = ${V} cm³.`, null, 4);
    }
    if (roll === 2) {
      const r = ri(3, 8), h = ri(6, 14);
      // cone volume
      const V = Math.round((1 / 3) * pi * r * r * h * 10) / 10;
      return base("measurement_11",
        `Volume of a cone with radius ${r} cm and height ${h} cm (π ≈ 3,14). Round to 1 d.p.`,
        V, d, "V = (1/3)πr²h",
        `V ≈ (1/3) × 3,14 × ${r}² × ${h} = ${V} cm³.`, null, 4);
    }
    if (roll === 3) {
      const r = ri(3, 10);
      const V = Math.round((4 / 3) * pi * r * r * r * 10) / 10;
      return base("measurement_11",
        `Volume of a sphere with radius ${r} cm (π ≈ 3,14). Round to 1 d.p.`,
        V, d, "V = (4/3)πr³",
        `V ≈ (4/3) × 3,14 × ${r}³ = ${V} cm³.`,
        { type: "circle", r }, 4);
    }
    if (roll === 4) {
      const l = ri(4, 12), b = ri(3, 10), h = ri(2, 8);
      const V = l * b * h;
      const SA = 2 * (l * b + b * h + l * h);
      return base("measurement_11",
        `A rectangular prism has length ${l} cm, breadth ${b} cm and height ${h} cm.\nCalculate its total surface area.`,
        SA, d, "SA = 2(lb + bh + lh)",
        `SA = 2(${l}×${b} + ${b}×${h} + ${l}×${h}) = ${SA} cm².`, null, 4);
    }
    if (roll === 5) {
      const side = ri(4, 10);
      const V = side ** 3;
      return base("measurement_11",
        `A cube has side length ${side} cm.\nCalculate its volume.`,
        V, d, "V = a³",
        `V = ${side}³ = ${V} cm³.`, null, 3);
    }
    // pyramid
    const baseA = ri(16, 64);
    const h = ri(5, 12);
    const V = Math.round((1 / 3) * baseA * h * 10) / 10;
    return base("measurement_11",
      `A pyramid has base area ${baseA} cm² and vertical height ${h} cm.\nCalculate its volume.`,
      V, d, "V = (1/3) × base area × height",
      `V = (1/3) × ${baseA} × ${h} = ${V} cm³.`, null, 3);
  }

  _finance(d) {
    const P = ri(5, 20) * 1000;
    const rates = [0.05, 0.08, 0.1, 0.12];
    const i = rates[ri(0, 3)];
    const n = ri(2, 6);
    const roll = ri(0, 3);
    if (roll === 0 || d >= 3) {
      const nom = choice([8, 9, 10, 12]);
      const m = choice([2, 4, 12]);
      const iEff = Math.pow(1 + nom / 100 / m, m) - 1;
      const pct = round2(iEff * 100);
      return base("finance_11",
        `A bank offers ${nom}% p.a. compounded ${m === 2 ? "semi-annually" : m === 4 ? "quarterly" : "monthly"}.\nCalculate the effective annual interest rate (as a percentage, 2 d.p.).`,
        pct, d,
        "i_eff = (1 + i_nom/m)^m − 1",
        `i_eff = (1 + ${nom / 100}/${m})^${m} − 1 ≈ ${pct}%.`, null, 4);
    }
    if (roll === 1) {
      // depreciation
      const dep = choice([0.1, 0.15, 0.2]);
      const A = Math.round(P * Math.pow(1 - dep, n));
      return base("finance_11",
        `A machine bought for R${P} depreciates at ${dep * 100}% p.a. on the reducing-balance method for ${n} years.\nCalculate its book value (nearest rand).`,
        A, d, "A = P(1 − i)ⁿ", `A = ${P}(1 − ${dep})^${n} ≈ ${A}.`, null, 4);
    }
    if (roll === 2) {
      // simple interest
      const A = Math.round(P * (1 + i * n));
      return base("finance_11",
        `R${P} is invested at ${i * 100}% p.a. simple interest for ${n} years.\nCalculate the total amount.`,
        A, d, "A = P(1 + in)", `A = ${P}(1 + ${i}×${n}) = ${A}.`, null, 3);
    }
    const A = Math.round(P * Math.pow(1 + i, n));
    return base("finance_11",
      `R${P} is invested at ${i * 100}% p.a. compound interest for ${n} years.\nCalculate the final amount (nearest rand).`,
      A, d, "A = P(1 + i)ⁿ", `A = ${P}(1 + ${i})^${n} ≈ ${A}.`, null, 4);
  }

  _probability(d) {
    const roll = ri(0, 3);
    if (roll <= 1 || d >= 2) {
      const pA = choice([0.3, 0.4, 0.5, 0.6]);
      const pBgA = choice([0.2, 0.3, 0.4, 0.5]);
      const pBgAc = choice([0.1, 0.2, 0.3, 0.4]);
      if (roll === 0) {
        const pAB = round2(pA * pBgA);
        return base("probability_11",
          `P(A) = ${pA}, P(B|A) = ${pBgA}.\nCalculate P(A and B).`,
          pAB, d, "P(A and B) = P(A) × P(B|A)",
          `P(A ∩ B) = ${pA} × ${pBgA} = ${pAB}.`,
          { type: "tree_diagram", stages: [
            { labels: ["A", "A′"], probs: [String(pA).replace(".", ","), String(round2(1 - pA)).replace(".", ",")] },
            { labels: ["B", "B′"], probs: [String(pBgA).replace(".", ","), String(round2(1 - pBgA)).replace(".", ",")] }
          ] }, 4);
      }
      // total probability of B
      const pB = round2(pA * pBgA + (1 - pA) * pBgAc);
      return base("probability_11",
        `P(A) = ${pA}, P(B|A) = ${pBgA}, P(B|A′) = ${pBgAc}.\nCalculate P(B).`,
        pB, d, "P(B) = P(A)P(B|A) + P(A′)P(B|A′)",
        `P(B) = ${pA}×${pBgA} + ${round2(1 - pA)}×${pBgAc} = ${pB}.`,
        { type: "tree_diagram", stages: [
          { labels: ["A", "A′"], probs: [String(pA).replace(".", ","), String(round2(1 - pA)).replace(".", ",")] },
          { labels: ["B", "B′"], probs: [String(pBgA).replace(".", ","), String(round2(1 - pBgA)).replace(".", ",")] }
        ] }, 5);
    }
    if (roll === 2) {
      const n = ri(5, 10), r = ri(2, 4);
      // simplified: P both same colour style bag
      return base("probability_11",
        `A bag contains ${n} red and ${n - 2} blue balls. Two balls are drawn at random without replacement.\nWrite down the probability that the first ball is red.`,
        `${n}/${2 * n - 2}`, d, "P = favourable / total",
        `P(first red) = ${n}/${2 * n - 2}.`, null, 3);
    }
    const total = [6, 8, 10, 12][ri(0, 3)];
    const fav = ri(1, total - 1);
    return base("probability_11",
      `A fair ${total}-sided spinner is spun. Probability of landing on one of ${fav} marked sectors?\nAnswer as a fraction fav/total.`,
      `${fav}/${total}`, d, "P = favourable / total.", `P = ${fav}/${total}.`);
  }

  _statistics(d) {
    const roll = ri(0, 3);
    if (roll <= 1 || d >= 2) {
      const data = Array.from({ length: 9 }, () => ri(10, 90)).sort((a, b) => a - b);
      const min = data[0], max = data[data.length - 1];
      const q1 = data[2], med = data[4], q3 = data[6];
      if (roll === 0) {
        const range = max - min;
        return base("statistics_11",
          `The five-number summary of a data set is:\nMin = ${min}, Q₁ = ${q1}, Median = ${med}, Q₃ = ${q3}, Max = ${max}.\nCalculate the range of the data.`,
          range, d, "Range = maximum − minimum.",
          `Range = ${max} − ${min} = ${range}.`,
          { type: "box_whisker", values: data, q1, median: med, q3 }, 3);
      }
      const iqr = q3 - q1;
      return base("statistics_11",
        `Five-number summary: Min = ${min}, Q₁ = ${q1}, Median = ${med}, Q₃ = ${q3}, Max = ${max}.\nCalculate the interquartile range (IQR).`,
        iqr, d, "IQR = Q₃ − Q₁",
        `IQR = ${q3} − ${q1} = ${iqr}.`,
        { type: "box_whisker", values: data, q1, median: med, q3 }, 3);
    }
    if (roll === 2) {
      const data = Array.from({ length: 6 }, () => ri(5, 25));
      const sorted = data.slice().sort((a, b) => a - b);
      const med = sorted.length % 2 ? sorted[Math.floor(sorted.length / 2)] : round2((sorted[2] + sorted[3]) / 2);
      return base("statistics_11",
        `Determine the median of: ${data.join("; ")}`,
        med, d, "Sort the data; median is the middle value (or mean of two middle values).",
        `Ordered: ${sorted.join("; ")}\nMedian = ${med}.`, null, 3);
    }
    const n = 5;
    const data = Array.from({ length: n }, () => ri(2, 20));
    const mean = Math.round((data.reduce((s, x) => s + x, 0) / n) * 10) / 10;
    return base("statistics_11",
      `Find the mean of: ${data.join(", ")}`,
      mean, d, "Mean = sum ÷ count.",
      `Sum = ${data.reduce((s, x) => s + x, 0)}; mean = ${mean}.`);
  }

  /**
   * Multi-part quadratic / linear number pattern blocks matching authentic CAPS depth
   * (missing terms, first-difference targets, turning point, range, common n, mixed sequences).
   */

  // ─── Grade 12 Algebra / Calculus ───
  _calculusG12(d) {
    return choice([
      this._calcFirstPrinciples.bind(this),
      this._calcPowerRule.bind(this),
      this._calcProductSimple.bind(this),
      this._calcTangent.bind(this),
      this._calcStationary.bind(this),
      this._equations.bind(this)
    ])(d);
  }

  _calcFirstPrinciples(d) {
    const a = ri(1, 5);
    const b = ri(-4, 4);
    const bx = b === 0 ? "" : (b > 0 ? ` + ${b}x` : ` − ${Math.abs(b)}x`);
    const q = `Determine f'(x) from first principles if f(x) = ${a}x²${bx}.`;
    const ans = b === 0 ? `f'(x) = ${2 * a}x` : `f'(x) = ${2 * a}x ${b >= 0 ? "+ " + b : "− " + Math.abs(b)}`;
    return base("algebra_calculus", q, ans, d,
      "Use f'(x) = lim(h→0) [f(x+h) − f(x)] / h.",
      `f(x+h) − f(x) expands to h(${2 * a}x + ${a}h + ${b}). Divide by h and let h → 0.\n${ans}`,
      null, 5);
  }

  _calcPowerRule(d) {
    const n = ri(2, 6);
    const c = ri(2, 8);
    return base("algebra_calculus",
      `Differentiate: y = ${c}x^${n}`,
      `dy/dx = ${c * n}x^${n - 1}`, d,
      "Power rule: d/dx [ax^n] = a·n·x^{n−1}.",
      `d/dx [${c}x^${n}] = ${c}·${n}x^${n - 1} = ${c * n}x^${n - 1}`,
      null, 2);
  }

  _calcProductSimple(d) {
    const a = ri(1, 4), b = ri(1, 5);
    return base("algebra_calculus",
      `Differentiate: y = (${a}x + ${b})(x − 1)`,
      `dy/dx = ${2 * a}x + ${b - a}`, d,
      "Expand first or use the product rule.",
      `y = ${a}x² + (${b - a})x − ${b}\ndy/dx = ${2 * a}x + ${b - a}`,
      null, 3);
  }

  _calcTangent(d) {
    const a = ri(1, 3), x0 = ri(-2, 3);
    const m = 2 * a * x0;
    const y0 = a * x0 * x0;
    const c = y0 - m * x0;
    const cs = c === 0 ? "" : (c > 0 ? ` + ${c}` : ` − ${Math.abs(c)}`);
    const ans = m === 0 ? `y = ${c}` : `y = ${m}x${cs}`;
    return base("algebra_calculus",
      `Find the equation of the tangent to y = ${a}x² at x = ${x0}.`,
      ans, d,
      "Find dy/dx for the gradient, then use the point–gradient form.",
      `dy/dx = ${2 * a}x → m = ${m} at x = ${x0}. Point (${x0}; ${y0}).\n${ans}`,
      null, 4);
  }

  _calcStationary(d) {
    const b = -ri(2, 6);
    const c = ri(-5, 5);
    const xs = -b / 2;
    const ys = xs * xs + b * xs + c;
    const bs = b >= 0 ? ` + ${b}x` : ` − ${Math.abs(b)}x`;
    const cs = c >= 0 ? ` + ${c}` : ` − ${Math.abs(c)}`;
    return base("algebra_calculus",
      `Find the coordinates of the stationary point of y = x²${bs}${cs}.`,
      `(${xs}; ${ys})`, d,
      "Set dy/dx = 0, solve for x, then substitute into y.",
      `dy/dx = 2x ${b >= 0 ? "+ " + b : "− " + Math.abs(b)} = 0 → x = ${xs}\ny = ${ys}`,
      null, 4);
  }

  generateStructuredPattern(difficulty = 2) {
    const d = Math.max(1, Math.min(4, difficulty | 0));
    const style = ri(0, 2);

    // ── Style A: missing term + first difference + turning point + range + common n ──
    if (style === 0) {
      // Build T_n = 3n² - 4n + 5 style (or similar clean coeffs)
      const a = choice([2, 3, 4]);
      const b = choice([-5, -4, -3, -2, 2]);
      const c = choice([4, 5, 6, 7]);
      const T = (n) => a * n * n + b * n + c;
      const termsShow = [T(1), T(2), "x", T(4)];
      const xVal = T(3);
      // first difference formula: ΔT_n = T_{n+1}-T_n = a(2n+1)+b
      const targetDiff = a * (2 * ri(40, 80) + 1) + b;
      // solve a(2n+1)+b = targetDiff → n = (targetDiff - b - a)/(2a)
      const nDiff = (targetDiff - b - a) / (2 * a);
      const nFloor = Math.floor(nDiff);
      const turnType = a > 0 ? "local minimum" : "local maximum";
      // range for a>0: [vertex value, ∞)
      const nv = -b / (2 * a);
      const Tv = T(nv);
      const rangeStr = a > 0
        ? `Tₙ ≥ ${round2(Tv)}  (or [${round2(Tv)}; ∞))`
        : `Tₙ ≤ ${round2(Tv)}  (or (−∞; ${round2(Tv)}])`;

      // common n: set first-diff expression equal to T_n
      // 6n-1 style vs 3n²-4n+5
      const fdA = 2 * a, fdB = a + b; // Δ = 2a·n + (a+b)  actually Δ_n = a(2n+1)+b = 2a n + a + b

      const parts = [
        {
          partLabel: "2.1",
          marks: 4,
          question: `Given the quadratic pattern: ${termsShow.join(" ; ")}\n\nCalculate the value of x.`,
          answer: String(xVal),
          explanation: `First differences between known terms:\nT₂ − T₁ = ${T(2) - T(1)}\nSecond difference is constant for a quadratic.\nWith positions 1,2,4 known, interpolate or fit Tₙ = an²+bn+c:\nUsing T₁=${T(1)}, T₂=${T(2)}, T₄=${T(4)}:\na = ${a}, b = ${b}, c = ${c}\nT₃ = ${a}(9) + ${b}(3) + ${c} = ${xVal}\n∴ x = ${xVal}.`,
          hint: "A quadratic has a constant second difference. Fit Tₙ = an² + bn + c using the known terms.",
          diagram: { type: "second_diff_tree", terms: termsShow.map((x) => x === "x" ? xVal : x) }
        },
        {
          partLabel: "2.2",
          marks: 4,
          question: `If x = ${xVal}, calculate between which two consecutive terms of the quadratic pattern the FIRST difference will be ${targetDiff}.`,
          answer: `Between T_${nFloor} and T_${nFloor + 1}` + (Number.isInteger(nDiff) ? "" : ` (n ≈ ${round2(nDiff)})`),
          explanation: `First difference: ΔTₙ = Tₙ₊₁ − Tₙ = a(2n + 1) + b = ${2 * a}n + ${a + b}\nSet equal to ${targetDiff}:\n${2 * a}n + ${a + b} = ${targetDiff}\nn = ${round2(nDiff)}\n∴ the first difference of ${targetDiff} lies between T_${nFloor} and T_${nFloor + 1}.`,
          hint: "ΔTₙ = a(2n + 1) + b. Solve for n."
        },
        {
          partLabel: "2.3.1",
          marks: 3,
          question: `An expression for the n-th term can be written in the form Tₙ = an² + bn + c.\nState whether the turning point of Tₙ is a local minimum or local maximum value. Substantiate your answer.`,
          answer: `${turnType}, because a = ${a} ${a > 0 ? "> 0 (opens upwards)" : "< 0 (opens downwards)"}`,
          explanation: `Tₙ = ${a}n² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}n ${c >= 0 ? "+" : "−"} ${Math.abs(c)}\nCoefficient of n² is a = ${a} ${a > 0 ? "> 0" : "< 0"}.\nTherefore the parabola opens ${a > 0 ? "upwards ⇒ local minimum" : "downwards ⇒ local maximum"}.`,
          hint: "Look at the sign of a in Tₙ = an² + bn + c."
        },
        {
          partLabel: "2.3.2",
          marks: 3,
          question: `If Tₙ = ${a}n² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}n ${c >= 0 ? "+" : "−"} ${Math.abs(c)}, determine the range of Tₙ (n ∈ ℝ).`,
          answer: rangeStr,
          explanation: `Vertex at n = −b/(2a) = ${round2(nv)}\nT(${round2(nv)}) = ${round2(Tv)}\nSince a ${a > 0 ? "> 0" : "< 0"}, range is ${rangeStr}.`,
          hint: "Find the vertex value; the sign of a determines whether it is a min or max."
        },
        {
          partLabel: "2.4",
          marks: 3,
          question: `It is given that in related patterns:\n• The equation of the FIRST difference is ΔTₙ = ${2 * a}n + ${a + b}\n• The quadratic is Tₙ = ${a}n² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}n ${c >= 0 ? "+" : "−"} ${Math.abs(c)}\n\nDetermine if there is a possible common value of n for which Tₙ equals the first-difference value. Support your answer with an appropriate calculation.`,
          answer: (() => {
            // Solve an²+bn+c = 2a n + (a+b) → an² + (b-2a)n + (c-a-b) = 0
            const A = a, B = b - 2 * a, C = c - a - b;
            const disc = B * B - 4 * A * C;
            if (disc < 0) return "No real common n (discriminant negative)";
            const s = Math.sqrt(disc);
            const r1 = round2((-B + s) / (2 * A));
            const r2 = round2((-B - s) / (2 * A));
            return disc === 0 ? `Yes, n = ${r1}` : `Yes, n = ${r1} or n = ${r2}`;
          })(),
          explanation: `Set Tₙ = ΔTₙ:\n${a}n² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}n ${c >= 0 ? "+" : "−"} ${Math.abs(c)} = ${2 * a}n + ${a + b}\nBring to one side and solve the resulting quadratic in n. Check the discriminant.`,
          hint: "Set the two expressions equal and solve for n."
        }
      ];
      return {
        id: `struct_pat_${ri(10000, 99999)}`,
        topic: "number_patterns",
        topic_name: "Number Patterns",
        section: "QUESTION 2 — Number patterns",
        sectionLabel: "QUESTION 2",
        qMain: 2,
        structured: true,
        parts,
        totalMarks: 17
      };
    }

    // ── Style B: linear sequence with x, then 17;14;11;… and odd terms ──
    if (style === 1) {
      // x; 4x+5; 10x-5 with common difference
      // (4x+5) - x = (10x-5) - (4x+5) → 3x+5 = 6x - 10 → 15 = 3x → x = 5
      const xSol = 5;
      const a0 = 17, dlt = -3, last = -106;
      const Tn = (n) => a0 + (n - 1) * dlt;
      // n for last: -106 = 17+(n-1)(-3) → n-1 = 41 → n = 42
      const nLast = Math.round((last - a0) / dlt) + 1;
      // first negative: 17-3(n-1) < 0 → 17 < 3(n-1) → n-1 > 17/3 → n >= 7
      const firstNegN = 7;
      // 20th odd term of sequence: odd terms are T1,T3,T5... so 20th odd is T_39
      const oddN = 20 * 2 - 1; // 39
      const oddVal = Tn(oddN);

      const parts = [
        {
          partLabel: "3.1",
          marks: 2,
          question: `The FIRST three terms of a linear sequence are:\nx ; 4x + 5 ; 10x − 5 ; …\n\nDetermine the numerical value of x.`,
          answer: String(xSol),
          explanation: `Common difference:\n(4x + 5) − x = (10x − 5) − (4x + 5)\n3x + 5 = 6x − 10\n15 = 3x\nx = 5.`,
          hint: "Equate consecutive first differences."
        },
        {
          partLabel: "3.2.1",
          marks: 2,
          question: `Consider the linear sequence:\n17 ; 14 ; 11 ; … ; −106\n\nDetermine n if the n-th term is given as Tₙ = −3n + 20 and Tₙ = −106.`,
          answer: String(nLast),
          explanation: `−3n + 20 = −106\n−3n = −126\nn = 42.`,
          hint: "Set Tₙ equal to −106 and solve."
        },
        {
          partLabel: "3.2.2",
          marks: 2,
          question: `Which term is the FIRST negative term in the sequence?`,
          answer: `T_${firstNegN} = ${Tn(firstNegN)}`,
          explanation: `Tₙ = −3n + 20 < 0\n−3n < −20\nn > 20/3 ≈ 6,67\nFirst natural n is 7: T₇ = ${Tn(7)}.`,
          hint: "Solve Tₙ < 0 for the smallest natural n."
        },
        {
          partLabel: "3.2.3",
          marks: 3,
          question: `Determine the value of the 20th ODD-positioned term in the sequence (T₁, T₃, T₅, …).`,
          answer: String(oddVal),
          explanation: `The k-th odd-positioned term is T_{2k−1}.\nFor k = 20: n = 39\nT₃₉ = −3(39) + 20 = ${oddVal}.`,
          hint: "The 20th odd-positioned term is T₃₉."
        },
        {
          partLabel: "3.3",
          marks: 4,
          question: `Consider the pattern:\n3 ; a ; 10 ; b ; 21\n\nThe pattern has a second difference of 1.\nDetermine the values of a and b.`,
          answer: "a = 6, b = 15",
          explanation: `Let first differences: a−3, 10−a, b−10, 21−b\nSecond differences = 1:\n(10−a)−(a−3) = 1 → 13 − 2a = 1 → 2a = 12 → a = 6\n(b−10)−(10−a) = 1 → b − 20 + a = 1 → b + 6 = 21 → b = 15\nCheck: (21−b)−(b−10) = 1 → 31 − 2b = 1 → b = 15.`,
          hint: "Write first differences in terms of a and b; set each second difference equal to 1."
        }
      ];
      return {
        id: `struct_pat_${ri(10000, 99999)}`,
        topic: "number_patterns",
        topic_name: "Number Patterns",
        section: "QUESTION 3 — Number patterns",
        sectionLabel: "QUESTION 3",
        qMain: 3,
        structured: true,
        parts,
        totalMarks: 13
      };
    }

    // ── Style C: classic 94;90;82;70 style ──
    const a = choice([-2, -1, -3]);
    const b = ri(-10, 5);
    const c = ri(50, 120);
    const T = (n) => a * n * n + b * n + c;
    const terms = [T(1), T(2), T(3), T(4)];
    const targetDiff = a * (2 * 8 + 1) + b;
    const nForDiff = 8;
    const parts = [
      {
        partLabel: "4.1.1",
        marks: 2,
        question: `Given the quadratic number pattern: ${terms.join(" ; ")} ; …\nDetermine the next two terms of the number pattern.`,
        answer: `${T(5)} ; ${T(6)}`,
        explanation: `Second difference = ${2 * a}. Extend differences to find T₅ = ${T(5)}, T₆ = ${T(6)}.`,
        hint: "Use constant second differences.",
        diagram: { type: "second_diff_tree", terms }
      },
      {
        partLabel: "4.1.2",
        marks: 4,
        question: `Determine Tₙ, the general term of the number pattern.`,
        answer: `Tₙ = ${a}n² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}n ${c >= 0 ? "+" : "−"} ${Math.abs(c)}`,
        explanation: `2a = ${2 * a} ⇒ a = ${a}. Using T₁ and T₂: b = ${b}, c = ${c}.`,
        hint: "2a = second difference."
      },
      {
        partLabel: "4.1.3",
        marks: 4,
        question: `Calculate two consecutive terms whose first difference is ${targetDiff}.`,
        answer: `T_${nForDiff} = ${T(nForDiff)}, T_${nForDiff + 1} = ${T(nForDiff + 1)}`,
        explanation: `ΔTₙ = a(2n+1)+b = ${targetDiff} ⇒ n = ${nForDiff}.`,
        hint: "Set a(2n+1)+b equal to the given difference."
      },
      {
        partLabel: "4.2",
        marks: 5,
        question: `A quadratic number pattern has general term Tₙ = an² + bn − 15.\nT₂ − T₁ = 3 and T₃ − T₂ = 7. Determine the values of a and b.`,
        answer: "a = 2, b = −3",
        explanation: `T₂ − T₁ = 3a + b = 3\nT₃ − T₂ = 5a + b = 7\nSubtract: 2a = 4 ⇒ a = 2\n3(2) + b = 3 ⇒ b = −3.`,
        hint: "T₂−T₁ = 3a+b; T₃−T₂ = 5a+b."
      }
    ];
    return {
      id: `struct_pat_${ri(10000, 99999)}`,
      topic: "number_patterns",
      topic_name: "Number Patterns",
      section: "QUESTION 4 — Number patterns",
      sectionLabel: "QUESTION 4",
      qMain: 4,
      structured: true,
      parts,
      totalMarks: 15
    };
  }

  /** Expand a structured block into flat question list for the paper viewer. */
  /** Expand a structured block into flat question list for the paper viewer. */
  expandStructured(block) {
    return (block.parts || []).map((p, i) => ({
      id: `${block.id}_${p.partLabel}`,
      topic: block.topic,
      topic_name: block.topic_name,
      section: block.section,
      sectionLabel: block.sectionLabel,
      qMain: block.qMain,
      partLabel: p.partLabel,
      question: p.question,
      answer: p.answer,
      explanation: p.explanation,
      hint: p.hint || "",
      marks: p.marks || 2,
      difficulty: 2,
      capsFormat: true,
      diagram: p.diagram || null,
      structured: true
    }));
  }

  generateCapsQuestion1(difficulty = 2) {
    const d = Math.max(1, Math.min(4, difficulty | 0));
    const parts = [];

    // ── 1.1 Solve for x (factor / formula / inequality) ────────────────────
    const f1 = this._quadFactor(Math.min(d, 2));
    parts.push({
      ...f1,
      stem: "Solve for x:",
      partLabel: "1.1.1",
      group: "1.1",
      groupStem: "Solve for x:"
    });

    const f2 = this._quadFormula(Math.max(2, d));
    parts.push({
      ...f2,
      stem: "Solve for x (answers correct to TWO decimal places):",
      partLabel: "1.1.2",
      group: "1.1",
      groupStem: "Solve for x:"
    });

    const f3 = this._quadIneq(d);
    parts.push({
      ...f3,
      stem: "Solve for x:",
      partLabel: "1.1.3",
      group: "1.1",
      groupStem: "Solve for x:"
    });

    // ── 1.2 Linked “Given / Hence” pair (surd or rational substitution) ───
    const pRoot = ri(2, 5);
    const pSum = ri(3, 8);
    // 14/p = p + k  style
    const k = pSum;
    const product = pRoot * (pRoot + k); // ensure one positive root works
    // Better fixed pattern from PDF: 14/p = p+5 → p²+5p-14=0
    const givenK = choice([4, 5, 6, 7]);
    const givenNum = choice([12, 14, 15, 18, 20]);
    // Solve p² + givenK*p - givenNum = 0 for integer-ish roots when possible
    parts.push({
      id: `fet_eq_${ri(10000, 99999)}`,
      topic: "equations_inequalities",
      topic_name: "equations inequalities",
      question: `Given:  ${givenNum}/p = p + ${givenK}\nSolve for p.`,
      answer: this._solveQuadraticText(1, givenK, -givenNum),
      difficulty: d,
      hint: "Multiply both sides by p and rearrange into a quadratic equation.",
      explanation: `${givenNum} = p(p + ${givenK})\np² + ${givenK}p − ${givenNum} = 0\n${this._solveQuadraticText(1, givenK, -givenNum)}`,
      marks: 3,
      stem: `Given: ${givenNum}/p = p + ${givenK}`,
      partLabel: "1.2.1",
      group: "1.2",
      groupStem: `Given: ${givenNum}/p = p + ${givenK}`
    });

    // 1.2.2 Hence surd form
    parts.push({
      id: `fet_eq_${ri(10000, 99999)}`,
      topic: "equations_inequalities",
      topic_name: "equations inequalities",
      question: `Hence, or otherwise, solve for x if\n${givenNum}/√(x + ${givenK}) = √(x + ${givenK}) + ${givenK}`,
      answer: "Use substitution p = √(x + k); reject negative root; check domain",
      difficulty: d,
      hint: "Let p = √(x + k) and use the result from 1.2.1.",
      explanation: `Let p = √(x + ${givenK}). Then the equation is identical to 1.2.1.\nTake the positive root for p, square to find x, and verify domain x ≥ −${givenK}.`,
      marks: 4,
      stem: "Hence, or otherwise, solve for x if",
      partLabel: "1.2.2",
      group: "1.2",
      groupStem: `Given: ${givenNum}/p = p + ${givenK}`
    });

    // ── 1.3 Simultaneous ───────────────────────────────────────────────────
    const sim = this._simultaneous(Math.max(2, d));
    parts.push({
      ...sim,
      stem: "Solve for x and y simultaneously:",
      partLabel: "1.3",
      group: "1.3",
      groupStem: "Solve for x and y simultaneously:"
    });

    // ── 1.4 Nature of roots ────────────────────────────────────────────────
    const nat = this._natureRoots(d);
    parts.push({
      ...nat,
      stem: null,
      partLabel: "1.4",
      group: "1.4",
      groupStem: null
    });

    // Attach CAPS display text for each part
    for (const p of parts) {
      p.capsFormat = true;
      p.questionDisplay = this._formatCapsPart(p);
    }
    return parts;
  }

  _solveQuadraticText(a, b, c) {
    const { disc, real, roots } = quadraticRoots(a, b, c);
    if (!real) return "No real roots";
    const r1 = roots[0], r2 = roots[1];
    const nice = (x) => (Math.abs(x - Math.round(x)) < 1e-9 ? String(Math.round(x)) : round2(x));
    if (Math.abs(r1 - r2) < 1e-9) return `p = ${nice(r1)}`;
    return `p = ${nice(Math.min(r1, r2))} or p = ${nice(Math.max(r1, r2))}`;
  }

  _formatCapsPart(p) {
    const lines = [];
    if (p.stem && p.partLabel && p.partLabel.includes(".")) {
      // sub-part under a stem already shown at group level — only show equation body
      const body = String(p.question || "")
        .replace(/^Solve for x[^\n]*\n?/i, "")
        .replace(/^Given:[^\n]*\n?/i, "")
        .replace(/^Hence[^\n]*\n?/i, "")
        .trim();
      lines.push(body || p.question);
    } else {
      lines.push(p.question);
    }
    return lines.join("\n");
  }

  /**
   * Single flat question still available; for papers prefer generateCapsQuestion1.
   */
  generateStructuredFunctions(difficulty = 2) {
    const a = choice([1, 2, -1, -2]);
    const p = ri(-2, 2);
    const q = ri(-3, 3);
    const parts = [
      {
        partLabel: "5.1",
        marks: 2,
        question: `The graph of f(x) = ${a}/(x ${p >= 0 ? "+" : "−"} ${Math.abs(p)}) ${q >= 0 ? "+" : "−"} ${Math.abs(q)} is shown.\nWrite down the equations of the asymptotes of f.`,
        answer: `x = ${-p} ; y = ${q}`,
        explanation: `Vertical asymptote: x = ${-p}\nHorizontal asymptote: y = ${q}.`,
        hint: "Denominator zero; constant term after division.",
        diagram: { type: "hyperbola", a, p, q }
      },
      {
        partLabel: "5.2",
        marks: 3,
        question: `Determine the coordinates of the intercepts of f with the axes (if they exist).`,
        answer: (() => {
          const lines = [];
          if (p !== 0) lines.push(`y-intercept: (0; ${round2(a / p + q)})`);
          else lines.push("No y-intercept");
          if (q !== 0) lines.push(`x-intercept: (${round2(-p - a / q)}; 0)`);
          else lines.push("No x-intercept");
          return lines.join("; ");
        })(),
        explanation: "Set x = 0 for y-intercept; set f(x) = 0 for x-intercept.",
        hint: "Set x = 0 and f(x) = 0 separately."
      },
      {
        partLabel: "5.3",
        marks: 3,
        question: `Write down the domain and range of f.`,
        answer: `Domain: x ∈ ℝ, x ≠ ${-p}\nRange: y ∈ ℝ, y ≠ ${q}`,
        explanation: `Exclude the asymptotes x = ${-p} and y = ${q}.`,
        hint: "Exclude asymptote values."
      },
      {
        partLabel: "5.4",
        marks: 4,
        question: `Given g(x) = 2(3)^x − 1.\nDetermine the y-intercept of g and the equation of its asymptote.`,
        answer: "(0; 1); y = −1",
        explanation: "g(0) = 2 − 1 = 1. Horizontal asymptote y = −1.",
        hint: "Substitute x = 0; asymptote from constant term.",
        diagram: { type: "exponential", a: 2, b: 3, q: -1 }
      }
    ];
    return {
      id: `struct_fn_${ri(10000, 99999)}`,
      topic: "functions_graphs",
      topic_name: "Functions and Graphs",
      section: "QUESTION 5 — Functions",
      sectionLabel: "QUESTION 5",
      qMain: 5,
      structured: true,
      parts,
      totalMarks: 12
    };
  }

  generateStructuredFinance(difficulty = 2) {
    const P = ri(8, 25) * 1000;
    const i = choice([0.08, 0.09, 0.1, 0.12]);
    const n = ri(3, 6);
    const Acomp = Math.round(P * Math.pow(1 + i, n));
    const nom = choice([8, 9, 10, 12]);
    const m = choice([2, 4, 12]);
    const iEff = round2((Math.pow(1 + nom / 100 / m, m) - 1) * 100);
    const dep = choice([0.1, 0.15, 0.2]);
    const Adep = Math.round(P * Math.pow(1 - dep, n));
    const parts = [
      {
        partLabel: "6.1",
        marks: 4,
        question: `R${P} is invested for ${n} years at ${i * 100}% p.a. compounded annually.\nCalculate the future value of the investment (nearest rand).`,
        answer: String(Acomp),
        explanation: `A = ${P}(1 + ${i})^${n} ≈ ${Acomp}.`,
        hint: "A = P(1 + i)ⁿ"
      },
      {
        partLabel: "6.2",
        marks: 4,
        question: `A bank advertises ${nom}% p.a. compounded ${m === 2 ? "semi-annually" : m === 4 ? "quarterly" : "monthly"}.\nCalculate the effective annual rate as a percentage (two decimal places).`,
        answer: String(iEff),
        explanation: `i_eff = (1 + ${nom}/100/${m})^${m} − 1 ≈ ${iEff}%.`,
        hint: "i_eff = (1 + i_nom/m)^m − 1"
      },
      {
        partLabel: "6.3",
        marks: 4,
        question: `Equipment bought for R${P} depreciates at ${dep * 100}% p.a. on the reducing-balance method for ${n} years.\nCalculate the book value at the end of the period (nearest rand).`,
        answer: String(Adep),
        explanation: `A = ${P}(1 − ${dep})^${n} ≈ ${Adep}.`,
        hint: "A = P(1 − i)ⁿ"
      }
    ];
    return {
      id: `struct_fin_${ri(10000, 99999)}`,
      topic: "finance_11",
      topic_name: "Finance",
      section: "QUESTION 6 — Finance",
      sectionLabel: "QUESTION 6",
      qMain: 6,
      structured: true,
      parts,
      totalMarks: 12
    };
  }

  generateStructuredExponents(difficulty = 2) {
    const baseN = choice([2, 3, 5]);
    const exp = ri(2, 5);
    const rhs = baseN ** exp;
    const surd = choice([12, 18, 20, 50, 45]);
    const surdMap = { 12: "2√3", 18: "3√2", 20: "2√5", 50: "5√2", 45: "3√5" };
    const parts = [
      {
        partLabel: "2.1",
        marks: 3,
        question: `Simplify fully, without using a calculator:\n${baseN}^3 × ${baseN}^${exp} ÷ ${baseN}^2`,
        answer: String(baseN ** (3 + exp - 2)),
        explanation: `${baseN}^{${3 + exp - 2}} = ${baseN ** (3 + exp - 2)}.`,
        hint: "aᵐ × aⁿ ÷ aᵖ = aᵐ⁺ⁿ⁻ᵖ"
      },
      {
        partLabel: "2.2",
        marks: 4,
        question: `Solve for x:\n${baseN}^x = ${rhs}`,
        answer: String(exp),
        explanation: `${baseN}^x = ${baseN}^${exp}\n∴ x = ${exp}.`,
        hint: "Same base on both sides."
      },
      {
        partLabel: "2.3",
        marks: 3,
        question: `Simplify fully: √${surd}`,
        answer: surdMap[surd],
        explanation: `√${surd} = ${surdMap[surd]}.`,
        hint: "Factor out perfect squares."
      },
      {
        partLabel: "2.4",
        marks: 4,
        question: `Solve for x:\n2^x = 2^{x+1} − 4\n(Hint: rearrange and factorise where possible.)`,
        answer: "x = 2",
        explanation: "2^x = 2·2^x − 4 → 4 = 2^x → x = 2.",
        hint: "Express all powers of 2 and solve."
      }
    ];
    return {
      id: `struct_exp_${ri(10000, 99999)}`,
      topic: "exponents_surds",
      topic_name: "Exponents and Surds",
      section: "QUESTION 2 — Exponents and surds",
      sectionLabel: "QUESTION 2",
      qMain: 2,
      structured: true,
      parts,
      totalMarks: 14
    };
  }

  generateStructuredEuclidean(difficulty = 2) {
    const centre = ri(50, 120);
    const insc = centre / 2;
    const cyclic = ri(70, 110);
    const tanAng = ri(28, 55);
    const baseAng = round2((180 - centre) / 2);
    const parts = [
      {
        partLabel: "7.1",
        marks: 4,
        question: `O is the centre of the circle. ∠AOB = ${centre}°.\nC lies on the circumference. Calculate ∠ACB. Give a reason.`,
        answer: `${insc}° (angle at centre = 2 × angle at circumference)`,
        explanation: `∠ACB = ½ × ${centre}° = ${insc}°\nReason: The angle at the centre is twice the angle at the circumference subtended by the same arc.`,
        hint: "Centre–circumference theorem.",
        diagram: { type: "circle_geometry", points: [{ label: "A", ang: 200 }, { label: "B", ang: 320 }, { label: "C", ang: 40 }], chords: [[0, 1], [1, 2], [0, 2]], angleLabel: `∠AOB = ${centre}°` }
      },
      {
        partLabel: "7.2",
        marks: 3,
        question: `ABCD is a cyclic quadrilateral with ∠ABC = ${cyclic}°.\nCalculate ∠ADC.`,
        answer: `${180 - cyclic}°`,
        explanation: `Opposite angles of a cyclic quadrilateral are supplementary.\n∠ADC = 180° − ${cyclic}° = ${180 - cyclic}°.`,
        hint: "Cyclic quadrilateral: opposite angles sum to 180°.",
        diagram: { type: "circle_geometry", points: [{ label: "A", ang: 160 }, { label: "B", ang: 240 }, { label: "C", ang: 320 }, { label: "D", ang: 50 }], chords: [[0, 1], [1, 2], [2, 3], [3, 0]], angleLabel: `∠ABC = ${cyclic}°` }
      },
      {
        partLabel: "7.3",
        marks: 4,
        question: `A tangent touches the circle at A. Chord AB makes an angle of ${tanAng}° with the tangent.\nC is a point on the major arc. Calculate ∠ACB.`,
        answer: `${tanAng}° (tangent–chord / alternate segment)`,
        explanation: `By the tangent–chord theorem, the angle between the tangent and the chord equals the angle in the alternate segment.\n∠ACB = ${tanAng}°.`,
        hint: "Tangent–chord (alternate segment) theorem.",
        diagram: { type: "circle_geometry", points: [{ label: "A", ang: 180 }, { label: "B", ang: 280 }, { label: "C", ang: 40 }], chords: [[0, 1], [1, 2], [0, 2]], angleLabel: `tan∠ = ${tanAng}°` }
      },
      {
        partLabel: "7.4",
        marks: 4,
        question: `O is the centre. OA and OB are radii and ∠AOB = ${centre}°.\nCalculate ∠OAB.`,
        answer: `${baseAng}°`,
        explanation: `OA = OB (radii) ⇒ △OAB is isosceles.\n∠OAB = ∠OBA = (180° − ${centre}°)/2 = ${baseAng}°.`,
        hint: "Equal radii form an isosceles triangle.",
        diagram: { type: "circle_geometry", points: [{ label: "A", ang: 200 }, { label: "B", ang: 320 }], chords: [[0, 1]], angleLabel: `∠AOB = ${centre}°` }
      }
    ];
    return {
      id: `struct_euc_${ri(10000, 99999)}`,
      topic: "euclidean_geometry",
      topic_name: "Euclidean Geometry",
      section: "QUESTION 7 — Euclidean geometry",
      sectionLabel: "QUESTION 7",
      qMain: 7,
      structured: true,
      parts,
      totalMarks: 15
    };
  }

  generatePaperParts(topicId, difficulty = 2) {
    if (topicId === "equations_inequalities") {
      return this.generateCapsQuestion1(difficulty);
    }
    if (topicId === "number_patterns") {
      return this.expandStructured(this.generateStructuredPattern(difficulty));
    }
    if (topicId === "functions_graphs") {
      return this.expandStructured(this.generateStructuredFunctions(difficulty));
    }
    if (topicId === "finance_11") {
      return this.expandStructured(this.generateStructuredFinance(difficulty));
    }
    if (topicId === "exponents_surds") {
      return this.expandStructured(this.generateStructuredExponents(difficulty));
    }
    if (topicId === "euclidean_geometry") {
      return this.expandStructured(this.generateStructuredEuclidean(difficulty));
    }
    // Other topics: multi-part CAPS-style block
    const n = 4 + (difficulty > 2 ? 1 : 0);
    const out = [];
    for (let i = 0; i < n; i++) {
      const q = this.generate(topicId, difficulty);
      q.partLabel = `1.${i + 1}`;
      q.qMain = 1;
      q.group = "1";
      q.sectionLabel = `QUESTION 1 — ${(q.topic_name || topicId)}`;
      q.section = q.sectionLabel;
      q.capsFormat = true;
      out.push(q);
    }
    return out;
  }
}
