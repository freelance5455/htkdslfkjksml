/**
 * Kepi — Learnly meerkat mascot (offline SVG, mood lines).
 * Simple geometry for small sizes and CSS animation hooks.
 */

export const MASCOT_NAME = "Kepi";
export const MASCOT_SPECIES = "meerkat";
export const MASCOT_TAGLINE = "Your study lookout";

/** Mood → short speech lines (Duolingo-style, CAPS-friendly). */
const LINES = {
  greet: [
    "Standing tall for today’s goals.",
    "Ready when you are.",
    "One focused session at a time.",
    "I’ve got your streak covered.",
    "Let’s make today count."
  ],
  idle: [
    "Practice a little — stay sharp.",
    "Notes, quiz, or a paper?",
    "Small steps still move you forward.",
    "I’m watching the daily goal with you."
  ],
  correct: [
    "Yes! Keep that streak warm.",
    "Solid. Next one?",
    "That’s the way.",
    "Lookout approved."
  ],
  wrong: [
    "Not quite — check the method.",
    "Close. Read the solution once.",
    "Mistakes teach. Try the next.",
    "We’ve got this — review and go again."
  ],
  streak: [
    "Streak safe. Don’t break the chain.",
    "Consistency is the real flex.",
    "Another day on the board."
  ],
  goal: [
    "Daily goal in reach.",
    "Finish strong — goal almost done.",
    "Goal met. Well stood."
  ],
  invite: [
    "Welcome to The Elites Academy.",
    "Enter the code to unlock Grade 10.",
    "Math Lit · Business · Tourism — I’m with you."
  ],
  empty: [
    "Nothing here yet — start with a short quiz.",
    "Your progress will show up here.",
    "First practice unlocks insights."
  ]
};

export function mascotLine(mood = "idle") {
  const pool = LINES[mood] || LINES.idle;
  return pool[Math.floor(Math.random() * pool.length)];
}

/**
 * Inline SVG meerkat. mood: idle | happy | think | nudge | celebrate
 * size: css length string
 */
export function mascotSvg(mood = "idle", size = "72px") {
  const eyes =
    mood === "happy" || mood === "celebrate"
      ? `<ellipse cx="38" cy="36" rx="3.2" ry="3.6" fill="#1a1520"/>
         <ellipse cx="54" cy="36" rx="3.2" ry="3.6" fill="#1a1520"/>
         <path d="M36 46 Q46 52 56 46" fill="none" stroke="#1a1520" stroke-width="2.2" stroke-linecap="round"/>`
      : mood === "nudge"
        ? `<ellipse cx="38" cy="36" rx="3.2" ry="3.6" fill="#1a1520"/>
           <ellipse cx="54" cy="36" rx="3.2" ry="3.6" fill="#1a1520"/>
           <path d="M38 48 H54" fill="none" stroke="#1a1520" stroke-width="2.2" stroke-linecap="round"/>`
        : mood === "think"
          ? `<ellipse cx="38" cy="36" rx="3.2" ry="2.8" fill="#1a1520"/>
             <ellipse cx="54" cy="37" rx="3.2" ry="2.4" fill="#1a1520"/>
             <path d="M40 48 Q46 50 52 47" fill="none" stroke="#1a1520" stroke-width="2" stroke-linecap="round"/>`
          : `<ellipse cx="38" cy="36" rx="3.2" ry="3.6" fill="#1a1520"/>
             <ellipse cx="54" cy="36" rx="3.2" ry="3.6" fill="#1a1520"/>
             <ellipse cx="46" cy="48" rx="4" ry="2.5" fill="#1a1520"/>`;

  const arm =
    mood === "celebrate"
      ? `<ellipse cx="22" cy="58" rx="7" ry="11" fill="#C4A574" transform="rotate(-25 22 58)"/>`
      : mood === "nudge"
        ? `<ellipse cx="20" cy="62" rx="7" ry="11" fill="#C4A574" transform="rotate(-40 20 62)"/>`
        : `<ellipse cx="24" cy="68" rx="7" ry="12" fill="#C4A574"/>`;

  const armR =
    mood === "celebrate"
      ? `<ellipse cx="70" cy="58" rx="7" ry="11" fill="#C4A574" transform="rotate(25 70 58)"/>`
      : `<ellipse cx="68" cy="68" rx="7" ry="12" fill="#C4A574"/>`;

  const sparkles =
    mood === "celebrate"
      ? `<circle cx="16" cy="28" r="2.5" fill="#F5C542"/><circle cx="78" cy="24" r="2" fill="#F5C542"/><circle cx="12" cy="48" r="1.6" fill="#F5C542"/>`
      : "";

  return `<svg class="mascot-svg mascot-${mood}" width="${size}" height="${size}" viewBox="0 0 92 110" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
  ${sparkles}
  <!-- tail -->
  <path d="M70 95 Q88 88 82 70" fill="none" stroke="#A8895C" stroke-width="7" stroke-linecap="round"/>
  <!-- body -->
  <ellipse cx="46" cy="78" rx="22" ry="28" fill="#C4A574"/>
  <ellipse cx="46" cy="82" rx="14" ry="18" fill="#E8D4B0"/>
  <!-- head -->
  <ellipse cx="46" cy="38" rx="22" ry="24" fill="#C4A574"/>
  <ellipse cx="46" cy="42" rx="14" ry="14" fill="#E8D4B0"/>
  <!-- ears -->
  <ellipse cx="28" cy="20" rx="7" ry="9" fill="#C4A574"/>
  <ellipse cx="64" cy="20" rx="7" ry="9" fill="#C4A574"/>
  <ellipse cx="28" cy="21" rx="3.5" ry="5" fill="#E8D4B0"/>
  <ellipse cx="64" cy="21" rx="3.5" ry="5" fill="#E8D4B0"/>
  <!-- arms -->
  ${arm}${armR}
  <!-- eyes + mouth -->
  ${eyes}
  <!-- nose -->
  <ellipse cx="46" cy="43" rx="3.5" ry="2.5" fill="#5C4030"/>
  <!-- feet -->
  <ellipse cx="36" cy="104" rx="9" ry="5" fill="#A8895C"/>
  <ellipse cx="56" cy="104" rx="9" ry="5" fill="#A8895C"/>
</svg>`;
}

/**
 * Build a mascot row: SVG + speech bubble.
 * Returns a DOM element via provided el().
 */
export function mascotCard(el, { mood = "idle", line = null, size = "64px", compact = false } = {}) {
  const text = line || mascotLine(mood);
  const svgWrap = el("div", {
    class: "mascot-figure" + (mood === "celebrate" ? " anim-star" : mood === "happy" ? " anim-pop" : ""),
    style: "flex-shrink:0;line-height:0;"
  });
  svgWrap.innerHTML = mascotSvg(mood, size);

  const bubble = el("div", {
    class: "mascot-bubble",
    style: compact
      ? "flex:1;font-size:0.82rem;font-weight:650;line-height:1.35;"
      : "flex:1;font-size:0.88rem;font-weight:650;line-height:1.4;"
  }, [
    el("div", {
      style: "font-size:0.68rem;font-weight:800;letter-spacing:0.06em;text-transform:uppercase;opacity:0.75;margin-bottom:0.15rem;"
    }, MASCOT_NAME),
    el("div", { class: "wrap" }, text)
  ]);

  return el("div", {
    class: "mascot-row card",
    style: "display:flex;align-items:center;gap:0.75rem;padding:0.75rem 0.9rem;"
  }, [svgWrap, bubble]);
}

/** Mood from learner state for Home. */
export function homeMood(student) {
  const done = student?.today_done ?? 0;
  const goal = student?.daily_goal ?? 20;
  const streak = student?.streak ?? 0;
  if (done >= goal && goal > 0) return "celebrate";
  if (streak >= 3) return "happy";
  if (done === 0) return "nudge";
  return "idle";
}
