/**
 * learnyZ — subscription / support plans (ZAR).
 * Local unlock for demo and offline use; payment gateway can be wired later.
 */

export const PLANS = [
  {
    id: "learner",
    name: "Learner",
    price: 49,
    period: "month",
    currency: "R",
    badge: "Individual",
    tagline: "Solid foundation for one learner",
    features: [
      "Full Mathematics for your grade",
      "One additional CAPS subject of choice",
      "Unlimited practice, papers and workshops",
      "Diagrams, notes and worksheets",
      "Ad-free experience"
    ],
    highlight: false
  },
  {
    id: "scholar",
    name: "Scholar",
    price: 99,
    period: "month",
    currency: "R",
    badge: "Most popular",
    tagline: "All subjects, deeper practice",
    features: [
      "All subjects available for your grade",
      "Everything in Learner",
      "Advanced labs, theorem workshop and fillable worksheets",
      "Priority content and note updates",
      "Full past-paper style generation"
    ],
    highlight: true
  },
  {
    id: "family",
    name: "Family",
    price: 450,
    period: "year",
    currency: "R",
    badge: "Household",
    tagline: "Up to three learners under one roof",
    features: [
      "Up to 3 learner profiles",
      "All Scholar features on every profile",
      "Parent / guardian progress overview",
      "Shared stars and badge progress",
      "Equivalent to under R38 per month"
    ],
    highlight: false
  },
  {
    id: "campus",
    name: "Campus",
    price: 999,
    period: "year",
    currency: "R",
    badge: "Tutor & school",
    tagline: "For tutors and small learning centres",
    features: [
      "Unlimited profiles for a tutor or centre",
      "Custom programme / academy name branding",
      "Export of learner progress reports",
      "All subjects Grades R–12",
      "Offline-first priority and early content access"
    ],
    highlight: false
  }
];

export function planById(id) {
  return PLANS.find((p) => p.id === id) || null;
}

export function currentPlan(student) {
  const id = student?.subscription?.planId || student?.plan || "free";
  if (id === "free") {
    return {
      id: "free",
      name: "Explorer (Free)",
      price: 0,
      period: "",
      currency: "R",
      features: ["Core practice and notes", "Daily star caps", "Single profile"]
    };
  }
  return planById(id) || { id: "free", name: "Explorer (Free)", price: 0 };
}

/** Activate a plan locally (demo / offline unlock). Real payment can replace this later. */
export function activatePlan(student, planId) {
  const plan = planById(planId);
  if (!plan) return { ok: false, reason: "unknown_plan" };
  student.subscription = {
    planId: plan.id,
    activatedAt: new Date().toISOString(),
    period: plan.period,
    price: plan.price,
    demo: true
  };
  student.plan = plan.id;
  return { ok: true, plan };
}

export function clearPlan(student) {
  delete student.subscription;
  delete student.plan;
}

export function formatPrice(plan) {
  if (!plan || !plan.price) return "Free";
  return `${plan.currency || "R"}${plan.price}${plan.period ? " / " + plan.period : ""}`;
}
