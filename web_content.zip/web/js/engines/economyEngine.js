// Strict stars/credits — earned by real work, never free for opening screens.
export const REWARD_TABLE = {
  correct_soft: 1,
  correct_standard: 2,
  correct_hard: 3,
  session_complete: 5,
  session_perfect: 8,
  daily_goal_met: 10,
  streak_bonus_5: 5,
  streak_day: 3,
  structured_part: 1,
  structured_full: 12,
  teach_exit: 4,
  sprint_correct: 1,
  sprint_streak_5: 5,
  challenge_complete: 6,
  challenge_perfect: 10,
  learning_card: 4,
  learning_card_strong: 7,
  quiz_correct: 2,
  daily_challenge: 8,
  level_up: 15,
  achievement_unlocked: 0, // stars already granted on badge
  combo_3: 2,
  combo_5: 4,
  combo_10: 8,
  weekly_quest: 12,
  subject_mastery: 15,
  comeback: 5,
  daily_login: 5,
  paper_complete: 6,
  paper_perfect: 12,
  mission_complete: 8,
  first_paper: 10,
  lesson_streak_3: 6
};

// Daily caps so stars can't be farmed endlessly
const DAILY_CAPS = {
  practice: 40,
  sprint: 25,
  structured: 30,
  challenge: 30,
  teach: 15,
  quiz: 30,
  lesson: 20
};

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

export class EconomyEngine {
  constructor(student) {
    this.student = student;
    if (student.credits === undefined) student.credits = 0;
    if (!student.transactions) student.transactions = [];
    if (!student.star_day) {
      student.star_day = { date: todayKey(), practice: 0, sprint: 0, structured: 0, challenge: 0, teach: 0, quiz: 0, lesson: 0 };
    }
    if (student.star_day.date !== todayKey()) {
      student.star_day = { date: todayKey(), practice: 0, sprint: 0, structured: 0, challenge: 0, teach: 0, quiz: 0, lesson: 0 };
    }
  }
  balance() { return this.student.credits || 0; }

  _record(amount, kind, reason) {
    const entry = {
      amount, kind, reason,
      balance_after: this.student.credits,
      timestamp: new Date().toISOString()
    };
    this.student.transactions.push(entry);
    if (this.student.transactions.length > 300) {
      this.student.transactions = this.student.transactions.slice(-300);
    }
    return entry;
  }

  _bucketFor(eventKey) {
    if (eventKey.startsWith("sprint")) return "sprint";
    if (eventKey.startsWith("structured")) return "structured";
    if (eventKey.startsWith("challenge") || eventKey === "daily_challenge") return "challenge";
    if (eventKey.startsWith("teach") || eventKey.startsWith("learning") || eventKey.startsWith("lesson")) return "lesson";
    if (eventKey.startsWith("paper") || eventKey === "first_paper") return "practice";
    if (eventKey === "daily_login" || eventKey === "mission_complete") return "challenge";
    if (eventKey.startsWith("quiz")) return "quiz";
    return "practice";
  }

  /** Earn stars for a named event. Respects daily caps. Multiplier if double-star boost active. */
  earn(eventKey, note = "") {
    let amount = REWARD_TABLE[eventKey];
    if (amount === undefined) amount = 0;
    if (amount <= 0) return null;

    const day = this.student.star_day;
    if (day.date !== todayKey()) {
      this.student.star_day = { date: todayKey(), practice: 0, sprint: 0, structured: 0, challenge: 0, teach: 0, quiz: 0, lesson: 0 };
    }

    // Double-star boost (shop) — one session window
    if (this.student.flags?.double_star_active) {
      amount = amount * 2;
    }

    const bucket = this._bucketFor(eventKey);
    const cap = DAILY_CAPS[bucket] ?? 40;
    const used = this.student.star_day[bucket] || 0;
    if (used >= cap) return null;

    const room = cap - used;
    const grant = Math.min(amount, room);
    if (grant <= 0) return null;

    this.student.credits = (this.student.credits || 0) + grant;
    this.student.star_day[bucket] = used + grant;
    return this._record(grant, "earn", note || eventKey);
  }

  earnCorrect(difficulty = 1, note = "Correct") {
    const key = difficulty >= 3 ? "correct_hard" : difficulty >= 2 ? "correct_standard" : "correct_soft";
    return this.earn(key, note);
  }

  /** Extra stars for answer combos (3 / 5 / 10 in a row within a session). */
  earnCombo(comboCount) {
    if (comboCount === 3) return this.earn("combo_3", "Combo ×3");
    if (comboCount === 5) return this.earn("combo_5", "Combo ×5");
    if (comboCount === 10) return this.earn("combo_10", "Combo ×10");
    return null;
  }

  reward(eventKey, note = "") {
    const map = {
      correct_answer: "correct_soft",
      session_complete: "session_complete",
      daily_goal_met: "daily_goal_met",
      streak_day: "streak_day",
      perfect_struct: "structured_full",
      achievement_unlocked: "achievement_unlocked",
      learning_card: "learning_card",
      quiz_correct: "quiz_correct",
      daily_challenge: "daily_challenge",
      level_up: "level_up"
    };
    return this.earn(map[eventKey] || eventKey, note);
  }

  spend(amount, reason) {
    amount = Math.abs(Math.trunc(amount));
    if (amount > (this.student.credits || 0)) return false;
    this.student.credits -= amount;
    this._record(-amount, "spend", reason);
    return true;
  }

  history(limit = 20) {
    return [...(this.student.transactions || [])].reverse().slice(0, limit);
  }

  devAdd(amount, reason = "Dev: add") {
    amount = Math.abs(Math.trunc(amount));
    this.student.credits = (this.student.credits || 0) + amount;
    return this._record(amount, "dev", reason);
  }
  devRemove(amount, reason = "Dev: remove") {
    amount = Math.min(Math.abs(Math.trunc(amount)), this.student.credits || 0);
    this.student.credits -= amount;
    return this._record(-amount, "dev", reason);
  }
  devSetBalance(n, reason = "Dev: set") {
    n = Math.max(0, Math.trunc(n));
    const delta = n - (this.student.credits || 0);
    this.student.credits = n;
    return this._record(delta, "dev", reason);
  }
  devSimulatePurchase(name, cost) { return this.spend(cost, `Dev buy: ${name}`); }
  devReset() {
    this.student.credits = 0;
    this.student.transactions = [];
    this.student.star_day = { date: todayKey(), practice: 0, sprint: 0, structured: 0, challenge: 0, teach: 0, quiz: 0, lesson: 0 };
    return this._record(0, "dev", "reset");
  }

  /** Once-per-calendar-day login bonus. Returns stars granted or 0. */
  claimDailyLogin() {
    const key = todayKey();
    this.student.flags = this.student.flags || {};
    if (this.student.flags.login_bonus_day === key) return 0;
    this.student.flags.login_bonus_day = key;
    this.student.flags.login_days = (this.student.flags.login_days || 0) + 1;
    return this.earn("daily_login", "Daily login bonus");
  }

    grantStarterStars(amount = 2000) {
    if (this.student.flags && this.student.flags.starter_stars_granted) return false;
    this.student.flags = this.student.flags || {};
    this.student.flags.starter_stars_granted = true;
    this.student.credits = (this.student.credits || 0) + amount;
    this.student.transactions = this.student.transactions || [];
    this.student.transactions.push({
      amount,
      reason: "Starter stars",
      timestamp: new Date().toISOString(),
      balance_after: this.student.credits
    });
    return true;
  }
}

/** Calendar streak: one qualifying day of activity. Call after any real work. */
export function touchCalendarStreak(student) {
  const today = todayKey();
  const last = student.streak_last_date || null;
  if (last === today) return student.streak || 0;

  if (!last) {
    student.streak = 1;
  } else {
    const prev = new Date(last + "T12:00:00");
    const now = new Date(today + "T12:00:00");
    const diffDays = Math.round((now - prev) / 86400000);
    if (diffDays === 1) {
      student.streak = (student.streak || 0) + 1;
    } else if (diffDays > 1 && (student.flags?.streak_freeze || 0) > 0) {
      student.flags.streak_freeze -= 1;
      student.streak = (student.streak || 0) + 1;
    } else {
      student.streak = 1;
    }
  }
  student.streak_last_date = today;
  student.streak_best = Math.max(student.streak_best || 0, student.streak || 0);

  // Milestone star bonus
  if (student.streak === 5 || student.streak === 7 || student.streak === 14 || student.streak === 30) {
    const econ = new EconomyEngine(student);
    econ.earn("streak_bonus_5", `${student.streak}-day streak`);
  }
  return student.streak || 0;
}
