import { diagramForTopic, recipe } from "./diagramEngine.js";
/**
 * learnyZ — lightweight generative engine for Life Sciences, Geography, Accounting,
 * Natural Sciences & Technology (scaffold content; expands over time).
 */
function ri(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

const NOTES = {
  ls_cells: {
    about: "All living organisms are made of cells. The cell theory and differences between plant and animal cells form a core CAPS foundation for Life Sciences. Parts of the cell (organelles) each have a specific function. Exam diagrams often ask you to label wall, membrane, nucleus, nucleolus, vacuole, chloroplast, mitochondrion, ER and Golgi body.",
    key_facts: [
      "Cell theory: all living things are composed of cells; the cell is the basic unit of life; cells arise from pre-existing cells.",
      "Nucleus contains DNA and controls cell activities; the nucleolus is involved in making ribosomes.",
      "Mitochondria release energy through cellular respiration (ATP).",
      "Plant cells have a cellulose cell wall (support), chloroplasts (photosynthesis) and a large permanent vacuole (turgor and storage).",
      "Animal cells lack a cell wall and chloroplasts; they may have many small temporary vacuoles.",
      "Cell membrane is selectively permeable and controls movement of substances in and out of the cell.",
      "Rough endoplasmic reticulum (ER) has ribosomes and helps make and transport proteins; Golgi body packages and modifies substances.",
      "Cytoplasm is the jelly-like matrix where organelles are suspended and many reactions occur.",
      "As a cell grows, its surface area to volume ratio decreases, which limits how large a single cell can become."
    ],
    formulae: ["Surface area : volume ratio decreases as cell size increases"],
    diagram: { type: "cell_plant" },
    table: {
      title: "Plant cell vs animal cell",
      cols: ["Feature", "Plant cell", "Animal cell"],
      rows: [
        ["Cell wall", "Present (cellulose)", "Absent"],
        ["Cell membrane", "Present", "Present"],
        ["Chloroplasts", "Present", "Absent"],
        ["Vacuole", "Large permanent", "Small / temporary"],
        ["Nucleus", "Present (usually peripheral)", "Present (often central)"],
        ["Mitochondria", "Present", "Present"],
        ["Rough ER / Golgi", "Present", "Present"],
        ["Shape", "Often regular / box-like", "Often irregular"]
      ]
    },
    method: "1. Draw and label both cell types (wall, membrane, nucleus, nucleolus, vacuole, chloroplast, mitochondrion, ER, Golgi). 2. Complete a comparison table. 3. Link each organelle to its function. 4. Explain why plant cells need a wall and chloroplasts. 5. Use structure–function language in full sentences for paper-style answers.",
    common_mistakes: [
      "Confusing cell wall with cell membrane",
      "Saying animals have chloroplasts",
      "Forgetting that both cell types have mitochondria",
      "Labelling the nucleolus as the whole nucleus",
      "Claiming the vacuole is only for waste",
      "Omitting ER or Golgi on higher-level diagrams"
    ],
    worked_examples: [
      "Example: A leaf cell is green because it contains chloroplasts with chlorophyll that absorb light for photosynthesis.",
      "Example: Muscle cells have many mitochondria because they need large amounts of ATP for contraction.",
      "Example (table skill): Feature = chloroplasts → Plant: present; Animal: absent."
    ]
  },
  ls_tissues: {
    table: {
      title: "Plant tissue types",
      cols: ["Tissue", "Main role"],
      rows: [
        ["Meristematic", "Cell division / growth"],
        ["Epidermis", "Protection; cuticle reduces water loss"],
        ["Parenchyma", "Storage; packing"],
        ["Collenchyma / sclerenchyma", "Support"],
        ["Xylem", "Transport water and minerals"],
        ["Phloem", "Transport organic nutrients (sugars)"]
      ]
    },
    about: "Tissues are groups of similar cells that perform a specific function. Plant and animal tissues support growth, transport and protection.",
    key_facts: [
      "Meristematic tissue allows plant growth; permanent tissues include epidermis, parenchyma, xylem and phloem.",
      "Xylem transports water and minerals; phloem transports organic nutrients.",
      "Animal epithelial tissue covers surfaces; connective tissue supports; muscle contracts; nerve transmits impulses.",
      "Tissues combine to form organs; organs form systems."
    ],
    formulae: [],
    diagram: { type: "plant_structure" },
    method: "Identify tissue type from structure and location. Relate structure (e.g. hollow xylem vessels) to function (transport under tension)."
  },
  ls_genetics: {
    about: "Genetics studies how characteristics are inherited through genes located on chromosomes. CAPS emphasises basic Mendelian inheritance and DNA.",
    key_facts: [
      "Genes are sections of DNA that code for particular traits.",
      "Alleles are alternative forms of a gene; an individual inherits two alleles for each gene (one from each parent).",
      "Dominant alleles are expressed in the phenotype of heterozygotes; recessive alleles are expressed only when homozygous.",
      "Genotype is the genetic makeup; phenotype is the observable characteristic.",
      "Punnett squares predict probable offspring genotypes and phenotypes."
    ],
    formulae: [],
    diagram: null,
    method: "Define the alleles, construct a Punnett square, list genotypes and phenotypes with ratios. Always state which allele is dominant.",
    common_mistakes: ["Mixing genotype and phenotype", "Forgetting to use two letters for each parent in a monohybrid cross"]
  },
  ls_human: {
    about: "Human body systems work together to maintain homeostasis. CAPS focuses on circulatory, respiratory, digestive, excretory and nervous systems.",
    key_facts: [
      "The heart is a double pump: right side to lungs, left side to the body.",
      "Arteries carry blood away from the heart; veins return blood; capillaries allow exchange.",
      "Lungs exchange oxygen and carbon dioxide across alveolar surfaces.",
      "The digestive system breaks down food mechanically and chemically; absorption occurs mainly in the small intestine.",
      "Neurons transmit electrical impulses; the brain and spinal cord form the central nervous system."
    ],
    formulae: [],
    diagram: { type: "heart" },
    method: "Trace the path of blood or food through the relevant system. Name organs in order and state the main process at each stage."
  },
  ls_support: {
    about: "Support and transport systems in plants and animals enable upright structure and movement of substances.",
    key_facts: [
      "Plant support comes from cell walls, turgor pressure and specialised tissues such as xylem.",
      "Transport in plants: transpiration pull and root pressure for water; translocation for sugars.",
      "Animal skeletons may be hydrostatic, exoskeleton or endoskeleton.",
      "Blood, lymph and tissue fluid transport substances in mammals."
    ],
    formulae: [],
    diagram: null
  },
  ls_environment: {
    about: "Biodiversity and the environment examine interactions between organisms and their habitats, including human impact.",
    key_facts: [
      "Biodiversity is the variety of life at genetic, species and ecosystem levels.",
      "Food chains and food webs show energy flow; only about 10% of energy transfers to the next trophic level.",
      "Human activities (habitat destruction, pollution, over-exploitation) reduce biodiversity.",
      "Conservation strategies include protected areas, sustainable use and restoration."
    ],
    formulae: [],
    diagram: { type: "food_web" }
  },
  ls_reproduction: {
    about: "Reproduction ensures continuity of species. CAPS covers asexual and sexual reproduction in plants and animals, including human reproduction at higher grades.",
    key_facts: [
      "Asexual reproduction produces genetically identical offspring (clones).",
      "Sexual reproduction involves gametes and produces genetic variation.",
      "Flower structure supports pollination and fertilisation in flowering plants.",
      "Human reproductive systems produce gametes; fertilisation leads to a zygote and embryo development."
    ],
    formulae: [],
    diagram: null
  },
  ls_evolution: {
    about: "The history of life on Earth includes fossil evidence, extinction events and theories of evolution, with natural selection as a key mechanism.",
    key_facts: [
      "Fossils provide evidence of past life and environmental change.",
      "Natural selection: variation, over-production, competition, survival of better-adapted individuals, inheritance of advantageous traits.",
      "Extinction occurs when species cannot adapt to changing conditions.",
      "Homologous structures and biogeography support evolutionary relationships."
    ],
    formulae: [],
    diagram: null
  },
  geo_mapwork: {
    about: "Mapwork and GIS develop spatial skills: scale, direction, contours, coordinates and digital layers for interpreting landscapes.",
    key_facts: [
      "Scale links map distance to ground distance (representative fraction, line scale or statement).",
      "Contour lines join points of equal height; close contours indicate steep slopes.",
      "Direction uses the 16-point compass or bearings measured clockwise from north.",
      "GIS stores, analyses and displays spatial data in thematic layers.",
      "Coordinates (latitude/longitude or grid references) locate features precisely."
    ],
    formulae: ["Ground distance = map distance × scale factor", "Gradient = vertical interval / horizontal equivalent"],
    diagram: { type: "map_scale" },
    method: "Read the scale carefully. Measure map distance, convert to ground distance. Use contour patterns to describe relief. State direction with a bearing or compass point."
  },
  geo_climate: {
    about: "Climate is the long-term average of weather conditions. Factors controlling climate include latitude, altitude, ocean currents, distance from the sea and prevailing winds.",
    key_facts: [
      "Weather is the short-term state of the atmosphere; climate is the long-term pattern (usually 30-year averages).",
      "Temperature generally decreases with increasing latitude and altitude.",
      "Ocean currents transfer heat; warm currents raise coastal temperatures, cold currents lower them.",
      "South Africa has diverse climate regions: Mediterranean (SW), subtropical (E), arid (W) and plateau climates.",
      "Climate graphs show monthly temperature and rainfall; interpret peaks, ranges and seasonal patterns."
    ],
    formulae: [],
    diagram: null,
    method: "Identify the climate type from temperature range and rainfall distribution. Link each controlling factor to its effect on the local climate."
  },
  geo_population: {
    about: "Population geography studies distribution, density, structure, growth and development indicators at local to global scales.",
    key_facts: [
      "Population density = number of people per unit area; distribution is uneven because of physical and human factors.",
      "Birth rate, death rate and net migration determine population change.",
      "Population pyramids show age–sex structure and can indicate stage of demographic transition.",
      "Development indicators include GDP per capita, literacy rate, life expectancy and HDI.",
      "Urbanisation and migration shape settlement patterns and service demand."
    ],
    formulae: ["Natural increase = birth rate − death rate"],
    diagram: null
  },
  geo_atmosphere: {
    about: "The atmosphere is the layer of gases surrounding Earth. CAPS examines composition, heating, pressure systems and weather phenomena.",
    key_facts: [
      "Troposphere contains most weather; temperature decreases with height in this layer.",
      "Insolation is uneven because of Earth’s curvature and tilt; this drives atmospheric circulation.",
      "High-pressure systems are associated with stable, clear conditions; low pressure with rising air and precipitation.",
      "South African weather is influenced by the subtropical high, the ITCZ seasonally, and mid-latitude cyclones in winter."
    ],
    formulae: [],
    diagram: null
  },
  geo_geomorphology: {
    about: "Geomorphology studies landforms and the processes that shape them: weathering, erosion, deposition and tectonic activity.",
    key_facts: [
      "Weathering breaks rock in place; erosion transports material; deposition builds new landforms.",
      "River processes create valleys, meanders, floodplains and deltas.",
      "Coastal processes form cliffs, beaches, spits and wave-cut platforms.",
      "South African landscapes include the escarpment, highveld plateau and coastal plains."
    ],
    formulae: [],
    diagram: null
  },
  geo_resources: {
    about: "Resources and sustainability examine how people use natural resources and the need to manage them for future generations.",
    key_facts: [
      "Renewable resources can be replenished; non-renewable resources exist in finite amounts.",
      "Sustainable use meets present needs without compromising future generations.",
      "Water, soil, minerals and energy are critical resources in South Africa.",
      "Conservation, recycling and efficient technology reduce pressure on resources."
    ],
    formulae: [],
    diagram: null
  },
  geo_settlement: {
    about: "Settlement geography studies the location, size, hierarchy and functions of rural and urban settlements.",
    key_facts: [
      "Site is the actual land on which a settlement is built; situation is its relative location.",
      "Urban hierarchy ranges from hamlet and village to town, city and metropolis.",
      "Functions include residential, commercial, industrial, administrative and recreational.",
      "South African urban issues include informal settlements, service delivery and spatial inequality rooted in history."
    ],
    formulae: [],
    diagram: null
  },
  ns_life_living: {
    diagram: { type: "plant_structure" },
    about: "Life and living is a core Natural Sciences strand covering organisms, life processes, habitats and ecosystems appropriate to the Intermediate and Senior Phase.",
    key_facts: [
      "Living things need energy, water, gases and a suitable habitat to survive.",
      "Food chains show energy flow: producer → primary consumer → secondary consumer.",
      "Habitats provide food, water, shelter and space; different habitats support different communities.",
      "Plants make food by photosynthesis; animals obtain food by consuming other organisms.",
      "Interdependence means organisms rely on each other and on the non-living environment."
    ],
    formulae: [],
    diagram: { type: "food_chain" },
    method: "Construct a simple food chain from a local habitat. Identify producers and consumers. State what would happen if one organism were removed."
  },
  ns_matter_materials: {
    about: "Matter is anything that has mass and occupies space. Materials are chosen for their properties; mixtures can often be separated by physical methods.",
    key_facts: [
      "Solids, liquids and gases are the three common states of matter; particles are arranged differently in each.",
      "Physical properties include hardness, flexibility, strength, density and electrical/thermal conductivity.",
      "Mixtures can be separated by filtration, evaporation, distillation, magnetism or chromatography depending on the components.",
      "Metals are generally shiny, malleable and good conductors; non-metals show a wider range of properties.",
      "Safety rules apply when heating, mixing or handling chemicals and materials."
    ],
    formulae: [],
    diagram: { type: "states_of_matter" },
    method: "Describe particle arrangement in each state. Choose a separation method that exploits a difference in property between the substances."
  },
  ns_energy_change: {
    about: "Energy can be stored, transferred and transformed. CAPS explores heat, light, sound, electrical and mechanical energy and simple circuits.",
    key_facts: [
      "Energy cannot be created or destroyed; it only changes form (law of conservation of energy).",
      "Heat flows from hotter to cooler regions by conduction, convection or radiation.",
      "A complete circuit needs a source of energy, conducting path and a load (e.g. bulb or motor).",
      "Series circuits share the same current; parallel circuits provide alternative paths.",
      "Fossil fuels, the Sun, wind and moving water are common energy sources; many involve transfers that produce heat and light."
    ],
    formulae: [],
    diagram: { type: "simple_circuit" },
    method: "Identify the energy transfers in a system (e.g. chemical → electrical → light + heat). Draw a simple circuit and state the role of each component."
  },
  ns_planet_earth: {
    diagram: { type: "solar_system" },
    about: "Planet Earth and beyond includes the solar system, day and night, seasons, the Moon, and Earth’s resources and surface features.",
    key_facts: [
      "Earth rotates on its axis once every 24 hours (day and night) and orbits the Sun once every year (seasons, with axial tilt).",
      "The Moon orbits Earth; phases result from the changing portion of the sunlit side that we see.",
      "The solar system contains the Sun, planets, moons, asteroids and comets; gravity holds the system together.",
      "Rocks, soil, water and air are essential Earth resources that must be used responsibly.",
      "Weathering, erosion and deposition continually reshape Earth’s surface."
    ],
    formulae: [],
    diagram: null,
    method: "Explain day/night and seasons using a globe and light source. Sequence the phases of the Moon and link them to relative positions of Earth, Moon and Sun."
  },
  tech_structures: {
    about: "Structures support loads and resist forces. Frame and shell structures appear in nature, buildings, bridges and everyday products.",
    key_facts: [
      "Strong, stable shapes include triangles, arches and domes; they distribute forces effectively.",
      "Materials (wood, metal, plastic, concrete) and joints (fixed, pinned, flexible) determine strength and stiffness.",
      "Structures must resist compression, tension, shear and torsion without collapsing or excessive deformation.",
      "Frame structures use struts and ties; shell structures use continuous surfaces.",
      "Design considerations include safety factors, cost, aesthetics and environmental impact."
    ],
    formulae: [],
    diagram: null,
    method: "Identify forces acting on a structure. Classify it as frame or shell. Suggest how geometry or material choice improves stability."
  },
  tech_electrical: {
    about: "Electrical systems use components in circuits to control the flow of energy for lighting, heating, motion and sensing. CAPS expects learners to draw and interpret series and parallel circuits using standard symbols (cell, switch, lamp, resistor).",
    key_facts: [
      "A simple circuit needs an energy source, a closed conducting path and a load.",
      "Switches open or close the path; resistors control current; sensors respond to the environment.",
      "Series circuits have one path; parallel circuits have multiple paths so one failure need not stop the whole system.",
      "In series, current is the same through each component; voltage is shared.",
      "In parallel, voltage is the same across branches; current splits at junctions.",
      "Safety: never overload circuits; use appropriate insulation and protective devices.",
      "Symbols are standardised so circuit diagrams can be read internationally (long/short plates for a cell; circle with cross for a lamp)."
    ],
    formulae: ["V = IR (Ohm's law, where used)", "Series: R_total = R₁ + R₂ + …"],
    table: {
      title: "Series vs parallel circuits",
      cols: ["Feature", "Series", "Parallel"],
      rows: [
        ["Path for current", "One path", "Multiple paths"],
        ["Current", "Same through all components", "Splits at junctions"],
        ["Voltage", "Shares across components", "Same across each branch"],
        ["If one lamp fails", "Whole circuit stops", "Other branches may still work"],
        ["Typical use", "Simple string of lights", "Household lighting circuits"]
      ]
    },
    diagram: { type: "simple_circuit" },
    method: "Draw the circuit using correct symbols. Trace the path of current. Predict the effect of opening a switch or removing one component in series versus parallel."
  },
  tech_mechanical: {
    diagram: { type: "lever" },
    about: "Mechanical systems use levers, gears, pulleys, cams and linkages to transfer and transform motion and force.",
    key_facts: [
      "Levers multiply force or distance depending on the relative positions of effort, load and fulcrum (classes 1, 2 and 3).",
      "Gears change speed, torque and direction of rotation; gear ratio = teeth on driven / teeth on driver.",
      "Pulleys can change direction of force or provide mechanical advantage in block-and-tackle systems.",
      "Friction can be useful (grip, brakes) or wasteful (heat and wear); lubrication reduces unwanted friction.",
      "Linkages convert input motion into a desired output motion (e.g. push-pull to rotation)."
    ],
    formulae: ["Mechanical advantage ≈ load / effort (ideal)", "Gear ratio = teeth driven / teeth driver"],
    diagram: null,
    method: "Identify the class of lever. Calculate ideal mechanical advantage or gear ratio. State whether the system multiplies force or speed."
  },
  tech_processing: {
    about: "Processing changes raw materials into useful products through physical or chemical methods while considering safety, waste and quality.",
    key_facts: [
      "Raw materials are transformed by sorting, mixing, heating, cooling, shaping, joining and finishing.",
      "Physical processes change form without changing chemical composition; chemical processes form new substances.",
      "Quality control checks dimensions, strength and appearance against specifications.",
      "Waste minimisation, recycling and safe disposal are part of responsible processing.",
      "Safety data and protective equipment are essential when heat, chemicals or moving machinery are involved."
    ],
    formulae: [],
    diagram: null,
    method: "Sequence the main processing steps for a familiar product. Classify each step as physical or chemical. Identify one safety and one environmental consideration."
  },
  tech_systems: {
    about: "Systems and control examine how inputs, processes and outputs work together, including simple electronic and mechanical control with feedback.",
    key_facts: [
      "A system can be described as input → process → output.",
      "Feedback compares the actual output with a desired value and adjusts the process (closed-loop control).",
      "Sensors detect changes (light, temperature, position, moisture); actuators produce a physical response.",
      "Open-loop systems do not use feedback; they are simpler but less accurate under changing conditions.",
      "Control systems appear in household appliances, vehicles, irrigation and industrial processes."
    ],
    formulae: [],
    diagram: null,
    method: "Draw a systems diagram with input, process, output and (if present) feedback. Name a real sensor and actuator that could form part of the system."
  },

  acc_concepts: {
    diagram: { type: "accounting_equation", assets: 12000, liabilities: 4000, equity: 8000 },
        definitions: [
      ["Asset", "Resource controlled by the business"],
      ["Liability", "Present obligation to outsiders"],
      ["Equity", "Owner's interest in the business"],
      ["Expense", "Cost incurred to earn income"],
      ["Income", "Earnings from operations or other sources"]
    ],
about: "Accounting records, classifies and reports financial information. The accounting equation Assets = Owner's equity + Liabilities must always balance.",
    key_facts: [
      "Assets are resources controlled by the business (cash, inventory, equipment).",
      "Liabilities are amounts owed to outsiders (creditors, loans).",
      "Owner's equity is the owner's interest: capital + profits − drawings.",
      "Every transaction has a dual effect that keeps the equation in balance."
    ],
    formulae: ["Assets = Owner's equity + Liabilities", "Owner's equity = Capital + Profit − Drawings"],
    diagram: null
  },
  acc_books: {
    diagram: { type: "journal_table" },
    table: {
      title: "Example — Cash Receipts Journal (extract)",
      cols: ["Date", "Details", "Analysis of receipts", "Bank"],
      rows: [
        ["01 Mar", "Capital", "Capital 20 000", "20 000"],
        ["05 Mar", "Cash sales", "Sales 3 500", "3 500"],
        ["12 Mar", "D. Dlamini", "Debtors 1 200", "1 200"]
      ]
    },
    about: "Books of first entry (journals) record transactions chronologically before posting to the general ledger. Common journals: Cash Receipts, Cash Payments, Sales, Purchases, Petty Cash, General Journal.",
    key_facts: [
      "Source documents (invoices, receipts, cheques) support each entry.",
      "Cash receipts journal records money received; cash payments journal records money paid.",
      "Sales journal records credit sales; purchases journal records credit purchases.",
      "The general journal is used for non-routine entries and corrections."
    ],
    formulae: [],
    diagram: null
  },
  acc_ledger: {
    diagram: { type: "t_account", account: "Bank" },
    table: {
      title: "Example — Trial balance (extract)",
      cols: ["Account", "Debit (R)", "Credit (R)"],
      rows: [
        ["Bank", "25 000", ""],
        ["Capital", "", "40 000"],
        ["Purchases", "15 000", ""],
        ["Sales", "", "12 000"],
        ["Rent expense", "3 000", ""],
        ["Drawings", "9 000", ""],
        ["Totals", "52 000", "52 000"]
      ]
    },
    about: "The general ledger holds individual accounts. Debits and credits post from journals. A trial balance lists account balances to check that total debits equal total credits.",
    key_facts: [
      "Assets and expenses normally have debit balances; equity, liabilities and income have credit balances.",
      "Posting transfers journal totals or individual amounts to ledger accounts.",
      "A trial balance that balances does not prove all entries are correct—only that debits equal credits.",
      "Closing entries transfer temporary accounts (income, expenses) to the capital account."
    ],
    formulae: ["Total debits = Total credits (trial balance)"],
    diagram: null
  },
  acc_debtors: {
    about: "Debtors (accounts receivable) owe the business for credit sales. Creditors (accounts payable) are suppliers the business owes for credit purchases. Control accounts summarise subsidiary ledgers.",
    key_facts: [
      "Debtors control account total should equal the sum of individual debtor balances.",
      "Bad debts arise when a debtor cannot pay; provision for bad debts is an estimate.",
      "Credit notes reduce debtors for returns or allowances.",
      "Age analysis helps manage collection of overdue accounts."
    ],
    formulae: [],
    diagram: null
  },
  acc_bank: {
    diagram: { type: "bank_recon" },
    table: {
      title: "Example — Bank reconciliation",
      cols: ["Details", "Amount (R)"],
      rows: [
        ["Balance per bank statement", "8 450"],
        ["Add: Outstanding deposit", "1 200"],
        ["Less: Outstanding cheques", "(950)"],
        ["Balance per cash book", "8 700"]
      ]
    },
    about: "A bank reconciliation explains differences between the cash book balance and the bank statement balance. Timing differences and errors must be identified and adjusted.",
    key_facts: [
      "Outstanding deposits: recorded in the cash book but not yet on the bank statement.",
      "Outstanding cheques: issued and recorded but not yet cleared by the bank.",
      "Bank charges, interest and direct deposits appear on the statement first.",
      "Errors in the cash book are corrected before preparing the reconciliation."
    ],
    formulae: [],
    diagram: null
  },
  acc_vat: {
    table: {
      title: "VAT calculation (15%)",
      cols: ["Item", "Exclusive", "VAT", "Inclusive"],
      rows: [
        ["Taxable supply", "200", "30", "230"],
        ["Another supply", "1 000", "150", "1 150"]
      ]
    },
    about: "Value-Added Tax (VAT) is a consumption tax collected by registered vendors. Output VAT is charged on taxable supplies; input VAT is paid on purchases and can usually be claimed back.",
    key_facts: [
      "Standard rate in South Africa is currently 15%.",
      "Output VAT − Input VAT = VAT payable (or refundable) to SARS.",
      "VAT-exclusive price × 15% = VAT amount; inclusive price × 15/115 = VAT.",
      "Zero-rated and exempt supplies are treated differently for input claims."
    ],
    formulae: ["VAT = exclusive amount × 0.15", "Exclusive = inclusive × 100/115", "VAT payable = Output VAT − Input VAT"],
    diagram: null
  },
  acc_inventory: {
    about: "Inventory systems track stock. Periodic systems update inventory at period end; perpetual systems update continuously. Cost of sales depends on the cost flow assumption (FIFO, weighted average).",
    key_facts: [
      "Cost of sales = Opening inventory + Purchases − Closing inventory (periodic).",
      "FIFO assumes oldest goods are sold first.",
      "Weighted average uses a moving average cost per unit.",
      "Stocktake verifies physical quantities against records."
    ],
    formulae: ["Cost of sales = Opening stock + Net purchases − Closing stock"],
    diagram: null
  },
  acc_financials: {
    diagram: { type: "income_statement" },
    table: {
      title: "Example — Income statement extract",
      cols: ["Details", "R"],
      rows: [
        ["Sales", "45 000"],
        ["Cost of sales", "(28 000)"],
        ["Gross profit", "17 000"],
        ["Operating expenses", "(9 500)"],
        ["Net profit", "7 500"]
      ]
    },
    about: "Financial statements communicate results and position. The Statement of Comprehensive Income (Income Statement) reports profit; the Statement of Financial Position (Balance Sheet) reports assets, equity and liabilities.",
    key_facts: [
      "Gross profit = Sales − Cost of sales.",
      "Net profit is after operating expenses and other income/expenses.",
      "Current assets are expected to be realised within 12 months.",
      "Non-current liabilities are due after more than one year."
    ],
    formulae: ["Gross profit = Sales − Cost of sales", "Assets = Equity + Liabilities"],
    diagram: null
  },
  acc_analysis: {
    about: "Analysis and interpretation uses ratios and trends to assess liquidity, solvency, profitability and efficiency. Comparisons over time and against industry norms improve insight.",
    key_facts: [
      "Current ratio = Current assets ÷ Current liabilities (liquidity).",
      "Acid-test ratio excludes inventory from current assets.",
      "Gross profit percentage = Gross profit ÷ Sales × 100.",
      "Return on equity measures profit relative to owner's investment."
    ],
    formulae: [
      "Current ratio = Current assets / Current liabilities",
      "Gross profit % = Gross profit / Sales × 100",
      "Net profit % = Net profit / Sales × 100"
    ],
    diagram: null
  },
  acc_ethics: {
    about: "Ethics and internal control protect stakeholders. Integrity, objectivity and confidentiality guide professional conduct. Internal controls reduce error and fraud risk.",
    key_facts: [
      "Segregation of duties separates authorisation, custody and recording.",
      "Source documents and authorisation trails support accountability.",
      "GAAP and IFRS provide frameworks for fair presentation.",
      "Whistle-blowing and audit processes help detect misconduct."
    ],
    formulae: [],
    diagram: null
  },
  acc_companies: {
    about: "Companies are separate legal entities. Share capital, retained income, dividends and limited liability distinguish company accounting from sole traders and partnerships.",
    key_facts: [
      "Ordinary shares represent ownership; dividends are distributions of profit.",
      "Retained income accumulates undistributed profits.",
      "Directors manage the company on behalf of shareholders.",
      "Financial statements of companies follow formal presentation requirements."
    ],
    formulae: [],
    diagram: null
  },
  acc_costing: {
    about: "Cost accounting analyses manufacturing costs: direct materials, direct labour and manufacturing overhead. Prime cost and conversion cost support inventory valuation and pricing decisions.",
    key_facts: [
      "Prime cost = Direct materials + Direct labour.",
      "Conversion cost = Direct labour + Manufacturing overhead.",
      "Overheads may be allocated using predetermined rates.",
      "Unit cost supports pricing and inventory valuation."
    ],
    formulae: ["Prime cost = Direct materials + Direct labour", "Total manufacturing cost = Prime cost + Overhead"],
    diagram: null
  },

  ls_chemistry: {
    about: "Chemistry of life covers the inorganic and organic compounds essential to living organisms: water, minerals, carbohydrates, lipids, proteins and nucleic acids.",
    key_facts: [
      "Water is a universal solvent, has high specific heat and is involved in hydrolysis and condensation reactions.",
      "Carbohydrates (monosaccharides, disaccharides, polysaccharides) provide energy and structure (cellulose).",
      "Lipids store energy, form membranes (phospholipids) and act as hormones (steroids).",
      "Proteins are polymers of amino acids; enzymes are biological catalysts.",
      "Nucleic acids (DNA and RNA) store and transfer genetic information."
    ],
    formulae: ["Condensation builds polymers; hydrolysis breaks them down"],
    method: "Classify a compound as inorganic or organic. Link structure (e.g. peptide bond) to function (e.g. enzyme active site).",
    common_mistakes: ["Calling all organic compounds living", "Confusing hydrolysis with condensation"]
  },
  ls_mitosis: {
    table: {
      title: "Mitosis stages (summary)",
      cols: ["Stage", "What happens"],
      rows: [
        ["Prophase", "Chromosomes condense; nuclear membrane breaks down"],
        ["Metaphase", "Chromosomes line up at the equator"],
        ["Anaphase", "Sister chromatids separate to opposite poles"],
        ["Telophase", "Nuclear membranes reform; chromosomes unwind"],
        ["Cytokinesis", "Cytoplasm divides → two daughter cells"]
      ]
    },
    about: "Mitosis is nuclear division that produces two genetically identical daughter nuclei. It enables growth, repair and asexual reproduction.",
    key_facts: [
      "Stages: prophase (chromosomes condense, spindle forms), metaphase (chromosomes on equator), anaphase (chromatids separate), telophase (nuclei reform).",
      "Cytokinesis divides the cytoplasm after mitosis.",
      "Chromosome number is conserved (diploid → diploid).",
      "Cancer involves uncontrolled cell division."
    ],
    formulae: [],
    diagram: { type: "mitosis_stages" },
    method: "Sequence the stages and state what happens to the chromosomes in each. Distinguish mitosis from cytokinesis.",
    common_mistakes: ["Mixing mitosis stages with meiosis", "Saying mitosis halves chromosome number"]
  },
  ls_photosynthesis: {
    about: "Photosynthesis converts light energy into chemical energy in carbohydrates. Respiration releases energy from organic molecules.",
    key_facts: [
      "Photosynthesis equation (simplified): 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ (light and chlorophyll required).",
      "Light-dependent reactions occur in thylakoids; Calvin cycle in the stroma.",
      "Factors affecting rate: light intensity, CO₂ concentration, temperature.",
      "Aerobic respiration: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + energy (ATP).",
      "Anaerobic respiration in muscles produces lactic acid; in yeast produces ethanol and CO₂."
    ],
    formulae: ["Photosynthesis: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂", "Aerobic respiration: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + ATP"],
    diagram: { type: "photosynthesis" },
    table: {
      title: "Photosynthesis vs aerobic respiration",
      cols: ["Aspect", "Photosynthesis", "Aerobic respiration"],
      rows: [
        ["Location", "Chloroplasts", "Mitochondria"],
        ["Energy", "Stores energy in glucose", "Releases energy as ATP"],
        ["Gas in", "CO₂", "O₂"],
        ["Gas out", "O₂", "CO₂"],
        ["When", "In light (mainly)", "Continuously in living cells"]
      ]
    },
    method: "State the requirements and products. Explain how changing one limiting factor affects the rate."
  },
  ls_nutrition: {
    about: "Animal nutrition covers ingestion, digestion, absorption and assimilation. Gas exchange supplies oxygen for respiration and removes carbon dioxide.",
    key_facts: [
      "Human digestive tract: mouth → oesophagus → stomach → small intestine → large intestine.",
      "Enzymes: amylase (starch), protease/pepsin (protein), lipase (fats).",
      "Absorption of nutrients mainly in the ileum; villi increase surface area.",
      "Gas exchange in humans occurs in alveoli; oxygen diffuses into blood, CO₂ out.",
      "Breathing movements are driven by the diaphragm and intercostal muscles."
    ],
    formulae: [],
    diagram: { type: "organ_digestive" },
    method: "Trace a food molecule or an oxygen molecule through the relevant system and name the processes at each stage."
  },
  ls_excretion: {
    about: "Excretion removes metabolic waste products. In humans the kidneys filter blood and produce urine; the skin and lungs also contribute.",
    key_facts: [
      "Main nitrogenous waste in mammals is urea (from deamination of amino acids).",
      "Nephron structure: glomerulus, Bowman's capsule, proximal tubule, loop of Henle, distal tubule, collecting duct.",
      "Ultrafiltration occurs in the glomerulus; selective reabsorption recovers useful substances.",
      "ADH controls water reabsorption in response to blood water potential.",
      "Homeostasis of water, salts and pH is maintained partly through kidney function."
    ],
    formulae: [],
    diagram: null,
    method: "Describe the path of filtrate through a nephron and state where ultrafiltration and reabsorption occur."
  },
  ls_dna: {
    about: "DNA carries the genetic code. RNA and protein synthesis translate that code into polypeptides.",
    key_facts: [
      "DNA is a double helix of complementary base pairs: A–T and C–G.",
      "Replication is semi-conservative: each new molecule has one old and one new strand.",
      "Transcription produces mRNA from a DNA template in the nucleus.",
      "Translation occurs at ribosomes: tRNA brings amino acids according to codons on mRNA.",
      "A codon is a triplet of bases coding for one amino acid (or stop)."
    ],
    formulae: [],
    diagram: null,
    method: "State base-pairing rules. Distinguish transcription from translation and locate each process in the cell."
  },
  ls_meiosis: {
    table: {
      title: "Mitosis vs meiosis",
      cols: ["Feature", "Mitosis", "Meiosis"],
      rows: [
        ["Purpose", "Growth / repair", "Gamete production"],
        ["Daughter cells", "2 diploid (2n)", "4 haploid (n)"],
        ["Genetic identity", "Identical to parent", "Variation (crossing over)"],
        ["Divisions", "One", "Two (I and II)"]
      ]
    },
    about: "Meiosis is reduction division that produces haploid gametes, introducing genetic variation through crossing over and independent assortment.",
    key_facts: [
      "Meiosis I separates homologous chromosomes; Meiosis II separates sister chromatids.",
      "Crossing over in prophase I exchanges genetic material between homologues.",
      "Independent assortment of homologous pairs increases variation.",
      "Result: four haploid cells that are genetically different.",
      "Errors in meiosis can cause aneuploidy (e.g. Down syndrome)."
    ],
    formulae: [],
    diagram: null,
    method: "Compare chromosome behaviour in mitosis vs meiosis. Explain two sources of genetic variation in meiosis."
  },
  ls_impact: {
    about: "Human impact on the environment examines current crises: climate change, habitat destruction, pollution, over-exploitation and strategies for sustainability.",
    key_facts: [
      "Greenhouse gases (CO₂, CH₄, N₂O) trap heat and contribute to global warming.",
      "Deforestation and land-use change reduce biodiversity and carbon sinks.",
      "Pollution of air, water and soil harms ecosystems and human health.",
      "Overfishing and overhunting deplete populations beyond recovery rates.",
      "Mitigation includes renewable energy, protected areas, recycling and sustainable agriculture."
    ],
    formulae: [],
    diagram: null,
    method: "Link a human activity to an environmental effect and propose one practical mitigation strategy."
  },
  geo_water: {
    about: "Water resources include oceans, rivers, wetlands, groundwater and the management of water for human and ecological needs.",
    key_facts: [
      "The hydrological cycle moves water between atmosphere, land and oceans.",
      "South Africa is a water-scarce country; demand management and infrastructure are critical.",
      "Floods result from excess discharge; drought from prolonged rainfall deficit.",
      "Wetlands filter water, reduce floods and support biodiversity.",
      "Groundwater is stored in aquifers; over-abstraction lowers the water table."
    ],
    formulae: [],
    diagram: { type: "water_cycle" },
    method: "Describe the main stores and transfers in the water cycle. Discuss one water-management strategy used in South Africa."
  },
  geo_development: {
    about: "Development geography examines differences in levels of development, indicators, frameworks and strategies to reduce inequality.",
    key_facts: [
      "Development is multi-dimensional: economic, social, environmental and political.",
      "Indicators include GDP per capita, HDI, literacy, life expectancy and access to services.",
      "The Brandt Line historically divided North and South; reality is more complex.",
      "Sustainable Development Goals (SDGs) provide a global framework.",
      "Obstacles include debt, trade barriers, conflict, corruption and environmental limits."
    ],
    formulae: [],
    diagram: null,
    method: "Compare two countries using at least three development indicators. Suggest one strategy that could improve a chosen indicator."
  },
  geo_economic: {
    about: "Economic geography of South Africa covers primary, secondary and tertiary sectors, mining, industry, agriculture and the informal sector.",
    key_facts: [
      "Primary sector extracts raw materials (mining, agriculture, fishing, forestry).",
      "Secondary sector manufactures goods; tertiary provides services.",
      "Mining has historically driven South African economic development but faces challenges (costs, labour, environment).",
      "Industrial Development Zones (IDZs) and Spatial Development Initiatives aim to attract investment.",
      "The informal sector employs many people but offers limited protection and tax contribution."
    ],
    formulae: [],
    diagram: null,
    method: "Classify an economic activity by sector. Discuss one factor that favours or hinders industrial development in South Africa."
  },
  ns_cells: {
    about: "Cells are the basic structural and functional units of life. Intermediate and Senior Phase Natural Sciences introduce cell structure and simple microscopy.",
    key_facts: [
      "All living organisms are made of one or more cells.",
      "Plant cells have a cell wall and often chloroplasts; animal cells do not.",
      "The nucleus controls the cell; cytoplasm is where most chemical reactions occur.",
      "Microscopes magnify cells so that structures can be observed.",
      "Cells specialise to form tissues with particular functions."
    ],
    formulae: [],
    diagram: { type: "cell_plant" },
    method: "Draw and label a plant and an animal cell. State one difference and one similarity."
  },
  ns_systems: {
    about: "An overview of systems in the human body shows how organs work together: digestive, circulatory, respiratory, nervous and others.",
    key_facts: [
      "A system is a group of organs that perform a major function together.",
      "The digestive system breaks down food and absorbs nutrients.",
      "The circulatory system transports blood, oxygen, nutrients and waste.",
      "The respiratory system exchanges gases between air and blood.",
      "Systems are interdependent; failure in one affects others."
    ],
    formulae: [],
    diagram: { type: "organ_digestive" }
  },

  // ---- Computer Applications Technology (CAT) ----
  cat_systems: {
    about: "Systems technologies cover the information processing cycle and the physical and non-physical components of a computer system: input, processing, output, storage and communication.",
    key_facts: [
      "A computer is an electronic device that accepts data (input), processes it, stores it and produces information (output).",
      "The information processing cycle: input → processing → output → storage (with communication linking systems).",
      "Types of computing devices: desktop, laptop, tablet, smartphone, server, embedded systems.",
      "A GUI (graphical user interface) uses windows, icons, menus and pointers for interaction.",
      "Device drivers allow the operating system to communicate with hardware."
    ],
    formulae: [],
    diagram: { type: "info_cycle" },
    table: {
      title: "Information processing cycle",
      cols: ["Stage", "Purpose", "Example"],
      rows: [
        ["Input", "Enter data into the system", "Keyboard, scanner, sensor"],
        ["Processing", "Transform data using CPU and software", "Calculate totals, edit a photo"],
        ["Output", "Present results to the user", "Monitor, printer, speakers"],
        ["Storage", "Keep data for later use", "SSD, cloud drive, USB"],
        ["Communication", "Transfer data between devices", "Wi-Fi, Ethernet, Bluetooth"]
      ]
    },
    method: "Identify which stage of the cycle a scenario describes. Link hardware and software to each stage.",
    common_mistakes: ["Confusing storage with memory (RAM)", "Treating communication as optional rather than part of modern systems"]
  },
  cat_hardware: {
    about: "Hardware is the physical equipment of a computer system: the system unit, input devices, output devices, storage and communication hardware.",
    key_facts: [
      "The CPU (central processing unit) executes instructions; clock speed and cores affect performance.",
      "RAM is volatile primary memory; secondary storage (HDD, SSD, optical, flash) is non-volatile.",
      "Input devices capture data; output devices present information.",
      "Ports and buses connect peripherals; USB, HDMI and wireless interfaces are common.",
      "Ergonomics and green computing influence hardware choice and use."
    ],
    formulae: [],
    diagram: { type: "computer_block" },
    table: {
      title: "Storage comparison (typical)",
      cols: ["Medium", "Volatility", "Typical use", "Relative speed"],
      rows: [
        ["RAM", "Volatile", "Running programs", "Very fast"],
        ["SSD", "Non-volatile", "OS and apps", "Fast"],
        ["HDD", "Non-volatile", "Bulk storage", "Slower"],
        ["USB flash", "Non-volatile", "Portable files", "Medium"],
        ["Cloud", "Non-volatile", "Backup and share", "Depends on network"]
      ]
    },
    method: "Classify a device as input, output, storage or processing. Compare storage options by speed, capacity and volatility."
  },
  cat_software: {
    about: "Software includes system software (operating systems, utilities, drivers) and application software (word processors, spreadsheets, databases, browsers).",
    key_facts: [
      "System software manages hardware and provides services to applications.",
      "Application software helps users complete specific tasks.",
      "Licensing models include proprietary, open-source, freeware and subscription.",
      "Updates and patches improve security and functionality.",
      "Malware protection and safe download practices are essential."
    ],
    formulae: [],
    diagram: null,
    table: {
      title: "Software categories",
      cols: ["Category", "Examples", "Role"],
      rows: [
        ["Operating system", "Windows, macOS, Linux, Android", "Manage hardware and apps"],
        ["Utility", "Antivirus, disk cleanup, backup", "Maintain and protect system"],
        ["Application", "Word, Excel, Access, browser", "End-user tasks"],
        ["Driver", "Printer driver, GPU driver", "Interface hardware to OS"]
      ]
    }
  },
  cat_files: {
    about: "File organisation covers drives, folders, files, extensions, paths and good naming and backup habits.",
    key_facts: [
      "A file is a named collection of data; a folder groups files in a hierarchy.",
      "File extensions indicate type (e.g. .docx, .xlsx, .pdf, .jpg, .mp4).",
      "Paths specify location: drive → folders → file name.",
      "Backup strategies protect against loss: local copy, external drive, cloud.",
      "Compression reduces size for storage or transfer (e.g. ZIP)."
    ],
    formulae: [],
    diagram: { type: "file_tree" },
    method: "Create a sensible folder structure for a school project. State the full path of a chosen file."
  },
  cat_word: {
    about: "Word processing develops documents using formatting, styles, tables, images, headers/footers, mail merge and export to PDF.",
    key_facts: [
      "Character, paragraph and page formatting control appearance.",
      "Styles ensure consistent headings and body text.",
      "Tables organise information in rows and columns.",
      "Mail merge combines a main document with a data source for personalised letters.",
      "Track changes and comments support collaborative editing."
    ],
    formulae: [],
    diagram: null,
    table: {
      title: "Useful word-processing features",
      cols: ["Feature", "Purpose"],
      rows: [
        ["Styles", "Consistent heading hierarchy"],
        ["Table of contents", "Auto-built from heading styles"],
        ["Headers/footers", "Page numbers and document title"],
        ["Mail merge", "Personalised bulk letters"],
        ["PDF export", "Fixed layout for sharing"]
      ]
    }
  },
  cat_spreadsheet: {
    about: "Spreadsheets organise data in cells, use formulae and functions, chart results and support what-if analysis.",
    key_facts: [
      "A cell is referenced by column letter and row number (e.g. B3).",
      "Formulae begin with = and can use operators and functions (SUM, AVERAGE, IF, VLOOKUP).",
      "Relative references change when copied; absolute references ($A$1) stay fixed.",
      "Charts visualise data: column, line, pie, scatter.",
      "Sorting and filtering help analyse large tables."
    ],
    formulae: ["=SUM(A1:A10)", "=AVERAGE(B2:B20)", "=IF(C2>=50,\"Pass\",\"Fail\")"],
    diagram: { type: "spreadsheet_grid" },
    table: {
      title: "Common spreadsheet functions",
      cols: ["Function", "Use"],
      rows: [
        ["SUM", "Total of a range"],
        ["AVERAGE", "Mean of a range"],
        ["COUNT / COUNTA", "Count numbers / non-empty cells"],
        ["IF", "Conditional result"],
        ["VLOOKUP / XLOOKUP", "Look up a value in a table"]
      ]
    },
    method: "Write a formula for a given task. Decide when a cell reference should be absolute."
  },
  cat_database: {
    about: "Databases store structured data in tables with fields and records. Queries, forms and reports support information management.",
    key_facts: [
      "A table has fields (columns) and records (rows).",
      "A primary key uniquely identifies each record.",
      "Relationships link tables (one-to-many is common).",
      "Queries select and filter data; reports present formatted output.",
      "Data integrity and validation reduce errors."
    ],
    formulae: [],
    diagram: { type: "db_table" },
    table: {
      title: "Example learner table",
      cols: ["LearnerID (PK)", "Surname", "Grade", "Maths"],
      rows: [
        ["L001", "Dlamini", "11", "72"],
        ["L002", "Naidoo", "11", "65"],
        ["L003", "Botha", "12", "81"]
      ]
    },
    method: "Identify the primary key. Design fields for a simple school database table."
  },
  cat_presentation: {
    about: "Presentation software structures slides with titles, bullet points, images, transitions and speaker notes for clear communication.",
    key_facts: [
      "One main idea per slide improves clarity.",
      "Consistent theme, fonts and colours look professional.",
      "Images and diagrams should support, not distract from, the message.",
      "Transitions and animations used sparingly aid focus.",
      "Speaker notes help the presenter without cluttering the slide."
    ],
    formulae: [],
    diagram: null
  },
  cat_network: {
    about: "Network technologies connect computers to share resources. LANs, WANs, topologies, protocols and security are core concepts.",
    key_facts: [
      "LAN covers a limited area (school, office); WAN spans larger distances (internet).",
      "Common topologies: star, bus, ring, mesh.",
      "Protocols (e.g. TCP/IP, HTTP, HTTPS) define rules for communication.",
      "Network devices: switch, router, modem, access point, NIC.",
      "Security: passwords, firewalls, encryption, updates."
    ],
    formulae: [],
    diagram: { type: "network_star" },
    table: {
      title: "Network devices",
      cols: ["Device", "Role"],
      rows: [
        ["Switch", "Connect devices in a LAN"],
        ["Router", "Connect networks; route packets"],
        ["Modem", "Modulate/demodulate for ISP link"],
        ["Access point", "Wireless entry to a network"],
        ["NIC", "Network interface in a device"]
      ]
    }
  },
  cat_internet: {
    about: "Internet technologies include the WWW, browsers, search, e-communication (email, messaging), cloud services and safe online behaviour.",
    key_facts: [
      "The internet is a global network of networks; the WWW is a service on the internet.",
      "URLs identify resources; HTTPS encrypts traffic.",
      "Search engines index pages; evaluate sources for credibility.",
      "Cloud services provide storage and apps over the internet.",
      "Phishing, malware and privacy risks require caution."
    ],
    formulae: [],
    diagram: null,
    method: "Distinguish internet from WWW. Evaluate whether a website is a reliable source for a research task."
  },
  cat_info_mgmt: {
    about: "Information management is finding, accessing, processing and presenting data so that it becomes useful information for decision-making.",
    key_facts: [
      "Data are raw facts; information is processed data in context.",
      "Sources may be primary (questionnaire, interview) or secondary (books, websites).",
      "A clear problem statement guides what data to collect.",
      "Processing includes sorting, calculating, summarising and visualising.",
      "Present solutions with appropriate application tools (document, spreadsheet, slides)."
    ],
    formulae: [],
    diagram: null,
    table: {
      title: "Data vs information",
      cols: ["Data", "Information"],
      rows: [
        ["23, 19, 27", "Class average is 23"],
        ["List of marks", "Who passed or failed"],
        ["Sensor readings", "Temperature is rising"]
      ]
    },
    method: "State a problem, list two data sources, describe how you would process the data, and choose a presentation format."
  },
  cat_social: {
    about: "Social implications of ICT cover impact on society, legal and ethical issues, security, health and ergonomics, and environmental (green computing) concerns.",
    key_facts: [
      "ICTs change work, education, communication and entertainment.",
      "Legal issues include copyright, privacy, cybercrime and acceptable use.",
      "Ethical use respects others' rights and data.",
      "Ergonomics reduces strain: posture, screen height, breaks.",
      "Green computing: energy efficiency, e-waste recycling, paper reduction."
    ],
    formulae: [],
    diagram: null,
    method: "For a given scenario, identify one social, one legal/ethical and one environmental issue and suggest a responsible response."
  }
};

function defaultNote(topicId) {
  const name = String(topicId || "topic").replaceAll("_", " ");
  return {
    about: `CAPS topic: ${name}. Key ideas for this grade band.`,
    key_facts: [
      `Focus on the core definitions for ${name}.`,
      "Use diagrams and real-life examples when you revise.",
      "Practise short questions, then longer explanations."
    ],
    formulae: [],
    diagram: null
  };
}

const BANK = {

  acc_concepts: [
    ["State the basic accounting equation.", "Assets = Owner's equity + Liabilities", "Every transaction keeps this equation in balance."],
    ["Name the three elements of the accounting equation.", "Assets, owner's equity, liabilities", "Also written A = OE + L."],
    ["Does buying equipment with cash increase total assets?", "No", "One asset (equipment) increases; another (cash) decreases by the same amount."],
    ["Assets are R45 000 and liabilities are R12 000. Calculate owner's equity.", "R33 000", "OE = A − L = 45000 − 12000 = 33000."],
    ["Owner contributes R5 000 cash. Effect on the accounting equation?", "Assets +5000; Equity +5000", "Both sides increase equally."],
    ["Business pays a creditor R2 000 by EFT. Effect on the equation?", "Assets −2000; Liabilities −2000", "Bank decreases; creditors decrease."],
    ["Bought equipment on credit for R8 000. Effect?", "Assets +8000; Liabilities +8000", "Equipment up; creditors up."],

  ],
  acc_books: [
    ["Which journal records cash received from customers?", "Cash receipts journal", "Often abbreviated CRJ."],
    ["What supports entries in the books of first entry?", "Source documents", "Invoices, receipts, cheques, credit notes."],
    ["Which journal is used for non-routine adjustments?", "General journal", "Also used for error corrections."]
  ],
  acc_ledger: [
    ["What does a trial balance test?", "That total debits equal total credits", "It does not prove every entry is correct."],
    ["Do asset accounts normally have debit or credit balances?", "Debit", "Expenses also normally debit; equity, liabilities and income credit."],
    ["What is posting?", "Transferring journal entries to ledger accounts", "From books of first entry to the general ledger."]
  ],
  acc_debtors: [
    ["Who are debtors?", "Customers who owe the business", "Also called accounts receivable."],
    ["What is a bad debt?", "An amount that a debtor cannot pay", "It is written off as an expense."],
    ["What should the debtors control account equal?", "The sum of individual debtor balances", "It is a control total for the subsidiary ledger."]
  ],
  acc_bank: [
    ["What is an outstanding cheque?", "A cheque recorded in the cash book but not yet cleared by the bank", "It appears in the reconciliation as a deduction from the bank statement balance."],
    ["Where do bank charges usually appear first?", "On the bank statement", "They must then be entered in the cash book."],
    ["Why prepare a bank reconciliation?", "To explain differences between cash book and bank statement balances", "Timing differences and errors are identified."],
    ["Bank statement balance R12 500. Outstanding deposit R2 000. Outstanding cheques R1 500. Calculate the cash book balance.", "R13 000", "CB = statement + outstanding deposits − outstanding cheques = 12500 + 2000 − 1500 = 13000."],
    ["Cash book balance R8 400. Outstanding cheques R1 200. Outstanding deposit R900. Bank charges not in cash book R50. Calculate the bank statement balance before updating the cash book for charges.", "R8 150", "Statement ≈ CB − outstanding deposit + outstanding cheques (before charges): 8400 − 900 + 1200 = 8700; after considering charges treatment may vary — primary recon identity: Statement + OD − OC = CB (updated)."],
    ["A bank statement shows charges of R75 and interest income of R40 not yet in the cash book. Should the cash book balance increase or decrease overall, and by how much?", "Decrease by R35", "Charges decrease CB by 75; interest increases CB by 40; net −35."],
    ["Name two items that typically appear on the bank statement but not yet in the cash book.", "Bank charges and direct deposits (or interest, debit orders)", "These must be entered in the cash book before reconciling."],
    ["Outstanding cheques total R3 200 and the bank statement balance is R15 000. Outstanding deposit is R1 800. What is the cash book balance?", "R13 600", "15000 + 1800 − 3200 = 13600."],
    ["Explain the treatment of a post-dated cheque received from a customer.", "Do not deposit until the date; do not treat as cash until bankable", "It is not an outstanding deposit until lodged."],
    ["A cheque for R500 was recorded in the cash book as R50. What is the effect on the cash book balance before correction?", "Overstated by R450 (if a payment) or understated (if a receipt) — state direction", "Error of transposition; correct by adjusting CB with the difference."],
    ["List the standard order of a bank reconciliation statement starting from the bank statement balance.", "Statement balance + outstanding deposits − outstanding cheques = cash book balance", "Some presentations start from CB and work to statement; both must agree after updates."],
    ["Debit order for insurance R600 appears on the bank statement only. What entry is made in the cash book?", "Debit Insurance (expense) R600; Credit Bank R600", "Update CB so it reflects the payment already taken by the bank."]
  ],
  acc_vat: [
    ["What is the standard VAT rate in South Africa?", "15%", "Applied to most taxable supplies."],
    ["How is VAT calculated on a VAT-exclusive amount?", "Multiply by 0.15 (or 15%)", "Inclusive amount × 15/115 extracts the VAT."],
    ["What is VAT payable to SARS?", "Output VAT minus Input VAT", "A negative result may mean a refund."]
  ],
  acc_inventory: [
    ["Give the formula for cost of sales (periodic system).", "Opening inventory + Purchases − Closing inventory", "Net purchases adjust for returns and carriage where applicable."],
    ["What does FIFO assume?", "Oldest goods are sold first", "Closing inventory reflects more recent costs."],
    ["Name two inventory systems.", "Periodic and perpetual", "Perpetual updates continuously; periodic updates at period end."]
  ],
  acc_financials: [
    ["How is gross profit calculated?", "Sales minus cost of sales", "Shown near the top of the income statement."],
    ["Which statement reports assets, equity and liabilities?", "Statement of financial position (balance sheet)", "It reflects the accounting equation."],
    ["Are current assets expected to be realised within 12 months?", "Yes", "Non-current assets are longer-term."]
  ],
  acc_analysis: [
    ["State the current ratio formula.", "Current assets ÷ Current liabilities", "A common liquidity measure."],
    ["How is gross profit percentage calculated?", "Gross profit ÷ Sales × 100", "Shows markup relative to sales."],
    ["What does the acid-test ratio exclude from current assets?", "Inventory", "It is a stricter liquidity test."]
  ],
  acc_ethics: [
    ["Name one purpose of internal control.", "To reduce error and fraud", "Also improves reliability of records."],
    ["What is segregation of duties?", "Separating authorisation, custody and recording", "No one person should control all steps of a transaction."],
    ["Why is professional ethics important in accounting?", "To protect stakeholders and maintain trust", "Integrity and objectivity are core principles."]
  ],
  acc_companies: [
    ["What do ordinary shares represent?", "Ownership in the company", "Shareholders may receive dividends."],
    ["What is retained income?", "Accumulated profits not distributed as dividends", "Part of equity on the statement of financial position."],
    ["Are companies separate legal entities?", "Yes", "They have limited liability distinct from their owners."]
  ],
  acc_costing: [
    ["What is prime cost?", "Direct materials + Direct labour", "Excludes manufacturing overhead."],
    ["Name the three main elements of manufacturing cost.", "Direct materials, direct labour, manufacturing overhead", "Together they form total manufacturing cost."],
    ["What is conversion cost?", "Direct labour + Manufacturing overhead", "Cost to convert materials into finished goods."]
  ],

  ls_cells: [
    ["What organelle contains the genetic material DNA?", "Nucleus", "The nucleus holds chromosomes made of DNA."],
    ["Name one organelle found in plant cells but not animal cells.", "Chloroplast", "Chloroplasts carry out photosynthesis. Cell wall is also valid."],
    ["What is the basic unit of life?", "Cell", "Cell theory states all living things are made of cells."]
  ],
  ls_genetics: [
    ["What is an alternative form of a gene called?", "Allele", "Alleles occupy the same locus on homologous chromosomes."],
    ["If an allele is always expressed when present, it is called…", "Dominant", "Recessive alleles are only expressed when homozygous."]
  ],
  ls_human: [
    ["Which organ pumps blood around the body?", "Heart", "The heart is a muscular pump in the circulatory system."],
    ["Which gas do we inhale for respiration?", "Oxygen", "Oxygen is used in cellular respiration; CO₂ is exhaled."]
  ],
  geo_mapwork: [
    ["What do contour lines join?", "Points of equal height", "Close contours mean steep slopes."],
    ["What does GIS stand for?", "Geographic Information System", "GIS layers spatial data for analysis."]
  ],
  geo_climate: [
    ["Is climate short-term or long-term weather patterns?", "Long-term", "Weather is day-to-day; climate is long-term average."],
    ["Name one factor that affects climate.", "Latitude", "Also altitude, ocean currents, distance from sea, winds."]
  ],
  geo_population: [
    ["What does a population pyramid show?", "Age and sex structure", "Wide base suggests high birth rates."],
    ["Birth rate minus death rate is called…", "Natural increase", "Migration also changes total population."]
  ],
  ns_life_living: [
    ["What is the first organism in a food chain called?", "Producer", "Producers make food by photosynthesis."],
    ["Name one thing a habitat must provide.", "Food", "Also water, shelter and space."]
  ],
  ns_matter_materials: [
    ["Name the three common states of matter.", "Solid, liquid, gas", "Plasma is a fourth state but less common in this grade."],
    ["Does a solid have a fixed shape?", "Yes", "Liquids take the shape of their container."]
  ],
  ns_energy_change: [
    ["Heat flows from … to … objects.", "Hot to cold", "Energy transfers from higher to lower temperature."],
    ["What must a circuit be for current to flow?", "Closed", "An open switch breaks the path."]
  ],
  ns_planet_earth: [
    ["How long does Earth take to rotate once?", "One day", "About 24 hours."],
    ["What causes the phases of the Moon?", "The Moon orbiting Earth", "We see different portions of the sunlit half."]
  ],
  tech_structures: [
    ["Which shape is especially strong in frames?", "Triangle", "Triangles resist changing shape under load."],
    ["What is a structure designed to do?", "Support loads", "It must be strong and stable."]
  ],
  tech_electrical: [
    ["Name three parts of a simple circuit.", "Source, path, load", "e.g. battery, wires, bulb."],
    ["What does a switch do?", "Opens or closes the circuit", "It controls whether current can flow."]
  ],
  tech_mechanical: [
    ["What is the pivot of a lever called?", "Fulcrum", "Load and effort positions determine mechanical advantage."],
    ["Gears can change speed and…", "Direction", "Meshed gears reverse rotation direction."]
  ],
  acc_concepts_def: [
    ["Define an asset.", "A resource controlled by the business from which future economic benefits are expected", "Examples: cash, inventory, equipment."],
    ["Define a liability.", "A present obligation of the business arising from past events", "Examples: creditors, loans."],
    ["State the dual-aspect concept.", "Every transaction has two effects that keep the accounting equation in balance", "Also called double-entry."]
  ],
  acc_books_def: [
    ["What is a source document?", "Evidence that a transaction occurred", "Invoice, receipt, cheque counterfoil, credit note."],
    ["Name the journal used for credit sales.", "Sales journal", "Also called the debtors journal in some texts."],
    ["Owner deposited capital into the business bank account. Which two accounts are affected?", "Bank and Capital", "Bank debited; Capital credited."]
  ],
  acc_ledger_def: [
    ["What is a trial balance?", "A list of ledger account balances to check that total debits equal total credits", "It does not prove accuracy of every entry."],
    ["On which side of a T-account do assets increase?", "Debit", "Assets and expenses increase on the debit side."],
    ["What is posting?", "Transferring amounts from journals to ledger accounts", "Each journal entry is posted to at least two accounts."]
  ],
  acc_vat_def: [
    ["Define output VAT.", "VAT charged by a vendor on taxable supplies (sales)", "Collected from customers."],
    ["Define input VAT.", "VAT paid by a vendor on taxable purchases", "Usually claimable from SARS."],
    ["Calculate VAT on a VAT-exclusive price of R200 at 15%.", "R30", "200 × 0.15 = 30."]
  ],
  acc_bank_def: [
    ["What is an outstanding deposit?", "An amount recorded in the cash book but not yet on the bank statement", "Added to the bank statement balance in the reconciliation."],
    ["Why might the cash book and bank statement balances differ?", "Timing differences and errors", "Outstanding cheques, deposits, bank charges, interest."]
  ],
  acc_financials_def: [
    ["Define gross profit.", "Sales minus cost of sales", "Shown near the top of the income statement."],
    ["Which statement reports assets, equity and liabilities?", "Statement of financial position", "Also called the balance sheet."]
  ],
  ls_cells_def: [
    ["Define a cell.", "The basic structural and functional unit of living organisms", "All living things are made of cells."],
    ["Name the organelle that contains DNA.", "Nucleus", "Controls cell activities."],
    ["Which organelle performs photosynthesis?", "Chloroplast", "Found in plant cells."]
  ],
  ls_human_def: [
    ["Name the organ that pumps blood.", "Heart", "Part of the circulatory system."],
    ["Where does most nutrient absorption occur?", "Small intestine", "Large surface area from villi."]
  ],
  geo_mapwork_def: [
    ["Define map scale.", "The ratio of a distance on the map to the corresponding distance on the ground", "May be a representative fraction."],
    ["What do contour lines join?", "Points of equal height above sea level", "Closer contours mean steeper slopes."],
    ["What does GIS stand for?", "Geographic Information System", "Layers of spatial data for analysis."]
  ],
  ns_planet_earth_def: [
    ["Name the planet third from the Sun.", "Earth", "Mercury, Venus, Earth, Mars."],
    ["What force keeps planets in orbit around the Sun?", "Gravity", "Attractive force between masses."],
    ["How long does Earth take to orbit the Sun once?", "One year", "About 365.25 days."]
  ],
  ns_life_living_def: [
    ["Define a habitat.", "The place where an organism lives", "Provides food, water, shelter and space."],
    ["What is a producer in a food chain?", "An organism that makes its own food", "Usually a green plant using photosynthesis."]
  ],

  ls_chemistry: [
    ["Name two organic compounds essential to life.", "Carbohydrates / lipids / proteins / nucleic acids", "Any two valid."],
    ["What type of reaction joins amino acids?", "Condensation", "Water is released."],
    ["State one property of water important to life.", "Solvent / high specific heat / cohesion", "Accept any valid property."]
  ],
  ls_mitosis: [
    ["Name the stage when chromosomes line up at the equator.", "Metaphase", "Spindle fibres attach to centromeres."],
    ["Does mitosis change the chromosome number?", "No", "Daughter cells are genetically identical."],
    ["What process divides the cytoplasm after mitosis?", "Cytokinesis", "Produces two separate cells."]
  ],
  ls_photosynthesis: [
    ["Write the word equation for photosynthesis.", "Carbon dioxide + water → glucose + oxygen (light, chlorophyll)", "Accept balanced formula."],
    ["Where do the light-dependent reactions occur?", "Thylakoid membranes / grana", "Chloroplast."],
    ["Name one factor that can limit the rate of photosynthesis.", "Light intensity / CO₂ / temperature", "Any one."]
  ],
  ls_nutrition: [
    ["Where does most absorption of nutrients occur?", "Small intestine / ileum", "Villi increase surface area."],
    ["Which enzyme digests starch?", "Amylase", "Produced in salivary glands and pancreas."],
    ["Name the structures in the lungs where gas exchange occurs.", "Alveoli", "Thin walls, moist, large surface area."]
  ],
  ls_dna: [
    ["Which bases pair with adenine in DNA?", "Thymine", "A–T; C–G."],
    ["Where does transcription take place?", "Nucleus", "mRNA is produced from DNA."],
    ["What is a codon?", "A triplet of bases coding for an amino acid", "On mRNA."]
  ],
  ls_meiosis: [
    ["How many daughter cells does meiosis produce?", "Four", "Haploid and genetically different."],
    ["In which stage does crossing over occur?", "Prophase I", "Between homologous chromosomes."],
    ["What is the chromosome number of a human gamete?", "23", "Haploid."]
  ],
  ls_impact: [
    ["Name one greenhouse gas.", "Carbon dioxide / methane / nitrous oxide", "Any one."],
    ["State one effect of deforestation.", "Loss of biodiversity / increased CO₂ / soil erosion", "Any valid."],
    ["Give one sustainable practice that reduces human impact.", "Recycling / renewable energy / protected areas", "Any valid."]
  ],
  geo_water: [
    ["Name two stores in the hydrological cycle.", "Oceans / atmosphere / groundwater / ice", "Any two."],
    ["Why is South Africa considered water-scarce?", "Low average rainfall / uneven distribution / high demand", "Any valid reason."],
    ["What is an aquifer?", "A body of rock or sediment that holds groundwater", "Can be abstracted via boreholes."]
  ],
  geo_development: [
    ["Name one social indicator of development.", "Literacy rate / life expectancy / access to services", "Any valid."],
    ["What does HDI stand for?", "Human Development Index", "Composite of health, education and income."],
    ["Give one obstacle to development in many countries.", "Debt / conflict / trade barriers / corruption", "Any valid."]
  ],
  geo_economic: [
    ["Which sector includes mining and agriculture?", "Primary", "Extraction of raw materials."],
    ["Name one challenge facing mining in South Africa.", "Rising costs / labour issues / environmental impact / depleting reserves", "Any valid."],
    ["What is the informal sector?", "Economic activity not formally registered or taxed", "Often street trading and small services."]
  ],
  ns_cells: [
    ["Name one structure found in plant cells but not animal cells.", "Cell wall / chloroplast / large vacuole", "Any one."],
    ["What is the function of the nucleus?", "Controls the cell / contains DNA", "Accept either."],
    ["Why do we use microscopes to study cells?", "Cells are too small to see with the naked eye", "Magnification."]
  ],
  ns_systems: [
    ["Name one human body system.", "Digestive / circulatory / respiratory / nervous", "Any valid."],
    ["What does the circulatory system transport?", "Blood / oxygen / nutrients / waste", "Any valid."],
    ["Why are body systems interdependent?", "They work together; failure in one affects others", "Homeostasis."]
  ],

  cat_systems: [
    ["List the stages of the information processing cycle.", "Input, processing, output, storage (and communication)", "Accept communication as fifth stage."],
    ["Is RAM volatile or non-volatile?", "Volatile", "Contents are lost without power."],
    ["What does GUI stand for?", "Graphical user interface", "Windows, icons, menus, pointer."]
  ],
  cat_hardware: [
    ["Name one input device and one output device.", "Keyboard / mouse (input); monitor / printer (output)", "Any valid pair."],
    ["Which storage is typically fastest for running programs?", "RAM", "Primary memory."],
    ["What is the role of the CPU?", "Execute instructions / process data", "Central processing unit."]
  ],
  cat_software: [
    ["Give one example of system software.", "Operating system / utility / driver", "Any valid."],
    ["What is the difference between system and application software?", "System manages hardware; application performs user tasks", "Accept clear distinction."],
    ["Why should software be updated?", "Security patches / new features / bug fixes", "Any valid reason."]
  ],
  cat_files: [
    ["What does a file extension indicate?", "The type of file / associated application", "e.g. .docx, .xlsx."],
    ["Why is a backup important?", "Protects against data loss", "Hardware failure, accidental delete, malware."],
    ["Name one common compressed file format.", "ZIP / RAR", "Any valid."]
  ],
  cat_word: [
    ["What is mail merge used for?", "Producing personalised documents from a data source", "Letters, labels, certificates."],
    ["Why use styles instead of manual formatting?", "Consistency and easy updates / TOC generation", "Any valid."],
    ["Name one benefit of exporting to PDF.", "Fixed layout / widely viewable / harder to edit accidentally", "Any valid."]
  ],
  cat_spreadsheet: [
    ["What symbol starts a spreadsheet formula?", "=", "Equals sign."],
    ["Write a formula to total cells A1 to A5.", "=SUM(A1:A5)", "Accept equivalent."],
    ["When would you use an absolute cell reference?", "When the reference must not change when copied", "e.g. $A$1."]
  ],
  cat_database: [
    ["What is a primary key?", "A field that uniquely identifies each record", "No duplicates."],
    ["What is a record in a database table?", "A single row of data", "One entity instance."],
    ["What is the purpose of a query?", "Select and filter data from tables", "Answer questions about the data."]
  ],
  cat_network: [
    ["What is the difference between a LAN and a WAN?", "LAN is local/limited area; WAN covers large distances", "Accept school vs internet example."],
    ["Name one network device that connects a LAN to the internet.", "Router / modem", "Any valid."],
    ["Give one network security measure.", "Password / firewall / encryption / updates", "Any valid."]
  ],
  cat_internet: [
    ["Is the World Wide Web the same as the internet?", "No", "WWW is a service on the internet."],
    ["What does HTTPS add compared with HTTP?", "Encryption / secure connection", "Protects data in transit."],
    ["Name one risk of phishing.", "Stealing passwords / identity theft / malware", "Any valid."]
  ],
  cat_info_mgmt: [
    ["Define data versus information.", "Data = raw facts; information = processed data in context", "Accept clear distinction."],
    ["Name one primary data source.", "Questionnaire / interview / observation / experiment", "Any valid."],
    ["Why is a clear problem statement important?", "Guides what data to collect and how to process it", "Focus."]
  ],
  cat_social: [
    ["Give one example of green computing.", "Energy-efficient devices / recycling e-waste / paperless work", "Any valid."],
    ["Name one ergonomic recommendation for computer use.", "Correct posture / screen at eye level / regular breaks", "Any valid."],
    ["State one legal issue related to ICT use.", "Copyright / privacy / cybercrime / acceptable use", "Any valid."]
  ],
  cat_presentation: [
    ["Why limit text on a slide?", "Clarity / audience focus / readability", "Any valid."],
    ["What are speaker notes for?", "Prompts for the presenter without showing on the slide", "Support delivery."]
  ],
};

export class MultiSubjectEngine {
  constructor(subjectId = "life_sciences", grade = 8) {
    this.subjectId = subjectId || "life_sciences";
    this.grade = grade;
  }

  notesFor(topicId) {
    const id = String(topicId || "").replace(/_def$/, "");
    const note = { ...(NOTES[id] || defaultNote(id)) };
    try {
      const diag = diagramForTopic(id, this.grade);
      if (diag && !note.diagram) note.diagram = diag;
      else if (diag && note.diagram && typeof note.diagram === "object" && note.diagram.type) {
        note.diagram = { ...diag, ...note.diagram };
      }
    } catch (_) {}
    // Ensure notes always have usable fields for the UI (avoid empty "below")
    if (!note.about) note.about = "CAPS-aligned Grade 12 notes for this topic.";
    if (!note.key_facts) note.key_facts = [];
    if (!note.method && note.step_by_step_method) note.method = Array.isArray(note.step_by_step_method) ? note.step_by_step_method.join(" ") : String(note.step_by_step_method);
    if (!note.method && note.key_facts.length) {
      note.method = "Study the key facts, then attempt a short quiz. Work systematically and check each step.";
    }
    if (!note.worked_examples) note.worked_examples = [];
    if (!note.common_mistakes) note.common_mistakes = [];
    if (!note.formulae) note.formulae = [];
    return note;
  }

  generate(topicId = null, difficulty = 2, opts = {}) {
    const concept = !!(opts && opts.concept);
    let candidates = Object.keys(BANK);
    if (topicId) {
      const base = String(topicId).replace(/_def$/, "");
      candidates = candidates.filter((id) => id === base || id === base + "_def" || id.startsWith(base + "_"));
      if (concept) {
        const defs = candidates.filter((id) => id.endsWith("_def"));
        if (defs.length) candidates = defs;
      } else {
        const practice = candidates.filter((id) => !id.endsWith("_def"));
        if (practice.length) candidates = practice;
      }
      if (!candidates.length) candidates = Object.keys(BANK).filter((id) => id.startsWith(base.split("_")[0]));
    } else if (concept) {
      const defs = candidates.filter((id) => id.endsWith("_def"));
      if (defs.length) candidates = defs;
    }
    candidates = candidates.filter((id) => BANK[id] && BANK[id].length);
    if (!candidates.length) candidates = Object.keys(BANK).filter((id) => BANK[id] && BANK[id].length);
    const tid = choice(candidates);
    const pool = BANK[tid];
    const [question, answer, explanation] = choice(pool);
    const baseTopic = tid.replace(/_def$/, "");
    const note = this.notesFor(baseTopic);
    let diagram = note.diagram || null;
    try {
      const recipeDiag = diagramForTopic(baseTopic, this.grade);
      if (recipeDiag) diagram = recipeDiag;
    } catch (_) {}
    if (baseTopic === "acc_books") diagram = recipe("journal_table", this.grade);
    else if (baseTopic === "acc_ledger" || baseTopic === "acc_debtors") diagram = recipe("t_account", this.grade, { account: baseTopic === "acc_debtors" ? "Debtors control" : "Bank" });
    else if (baseTopic === "acc_bank") diagram = recipe("bank_recon", this.grade);
    else if (baseTopic === "acc_concepts") diagram = recipe("accounting_equation", this.grade);
    else if (baseTopic === "acc_financials" || baseTopic === "acc_analysis") diagram = recipe("income_statement", this.grade);
    else if (baseTopic === "ns_planet_earth") diagram = recipe("solar_system", this.grade);
    else if (baseTopic === "ns_life_living") diagram = recipe("plant_structure", this.grade);
    else if (baseTopic === "ls_cells") diagram = recipe("cell_plant", this.grade);
    else if (baseTopic === "ls_human") diagram = recipe("organ_digestive", this.grade);
    let qText = String(question || "").trim();
    // Remove dangling "below" / "in the figure" when no diagram is available
    if (!diagram) {
      qText = qText.replace(/\s*(shown\s+)?below\.?$/i, ".")
        .replace(/\s*in the (figure|diagram)\s*below\.?/gi, "")
        .replace(/\s*study the (figure|diagram)\s*below\.?/gi, "")
        .replace(/\s{2,}/g, " ")
        .trim();
    }
    if (!qText) qText = "Answer the question for this topic.";
    // Step-style explanation
    let steps = explanation || "";
    if (steps && !/\n|\d\./.test(steps)) {
      steps = "1. Identify what is asked.\n2. " + steps + "\n3. Write the final answer clearly.";
    }
    return {
      id: `ms_${tid}_${ri(1000, 9999)}`,
      topic: baseTopic,
      topic_name: baseTopic.replaceAll("_", " "),
      subject: this.subjectId,
      question: qText,
      answer,
      explanation: steps,
      steps: steps,
      diagram,
      difficulty,
      marks: concept ? 1 : 2,
      mode: concept ? "concept" : "practice"
    };
  }

  generateConcept(topicId = null, difficulty = 2) {
    return this.generate(topicId, difficulty, { concept: true });
  }

  /**
   * CAPS-style multi-part paper block for a single topic (Accounting, LS, Geo, CAT…).
   * Returns an array of sub-questions with part labels 1.1, 1.2, …
   */
  generatePaperParts(topicId = null, difficulty = 2) {
    const base = String(topicId || "acc_concepts").replace(/_def$/, "");
    const parts = [];
    const count = Math.min(4, Math.max(2, difficulty + 1));
    // Prefer numerical / structured recipes for accounting bank recon and equation
    if (base === "acc_bank") {
      const statement = ri(12000, 28000);
      const od = ri(800, 3500);
      const oc = ri(600, 2800);
      const charges = ri(40, 120);
      const interest = ri(20, 90);
      const cbUpdated = statement + od - oc;
      const cbBefore = cbUpdated + charges - interest;
      parts.push({
        topic: base, topic_name: "bank reconciliation", partLabel: "1.1", marks: 3, difficulty,
        question: `The bank statement balance is R${statement.toLocaleString("en-ZA")}. Outstanding deposits total R${od.toLocaleString("en-ZA")} and outstanding cheques total R${oc.toLocaleString("en-ZA")}. Calculate the cash book balance after all known differences (before new charges/interest).`,
        answer: `R${cbUpdated.toLocaleString("en-ZA")}`,
        explanation: `Cash book = statement + outstanding deposits − outstanding cheques\n= ${statement} + ${od} − ${oc} = ${cbUpdated}`
      });
      parts.push({
        topic: base, topic_name: "bank reconciliation", partLabel: "1.2", marks: 2, difficulty,
        question: `Bank charges of R${charges} and interest income of R${interest} appear on the bank statement but not yet in the cash book. State the net effect on the cash book balance.`,
        answer: interest >= charges ? `Increase by R${interest - charges}` : `Decrease by R${charges - interest}`,
        explanation: `Charges decrease CB by ${charges}; interest increases CB by ${interest}; net ${interest - charges}.`
      });
      parts.push({
        topic: base, topic_name: "bank reconciliation", partLabel: "1.3", marks: 3, difficulty,
        question: "List two reasons why the cash book balance may differ from the bank statement balance before reconciliation.",
        answer: "Outstanding cheques; outstanding deposits; bank charges; interest; direct deposits; errors",
        explanation: "Timing differences and items recorded by only one party cause temporary differences."
      });
      return parts;
    }
    if (base === "acc_concepts") {
      const A = ri(40000, 90000);
      const L = ri(10000, 35000);
      const OE = A - L;
      parts.push({
        topic: base, topic_name: "accounting equation", partLabel: "1.1", marks: 2, difficulty,
        question: "State the basic accounting equation.",
        answer: "Assets = Owner's equity + Liabilities",
        explanation: "The equation must always balance after every transaction."
      });
      parts.push({
        topic: base, topic_name: "accounting equation", partLabel: "1.2", marks: 3, difficulty,
        question: `Assets are R${A.toLocaleString("en-ZA")} and liabilities are R${L.toLocaleString("en-ZA")}. Calculate owner's equity.`,
        answer: `R${OE.toLocaleString("en-ZA")}`,
        explanation: `OE = A − L = ${A} − ${L} = ${OE}`
      });
      parts.push({
        topic: base, topic_name: "accounting equation", partLabel: "1.3", marks: 3, difficulty,
        question: "The owner contributes R5 000 cash and the business buys equipment on credit for R8 000. Describe the effect of each transaction on the accounting equation.",
        answer: "Contribution: Assets +5000, Equity +5000. Equipment on credit: Assets +8000, Liabilities +8000.",
        explanation: "Each transaction keeps both sides of the equation in balance."
      });
      return parts;
    }
    if (base === "acc_financials" || base === "acc_analysis") {
      const sales = ri(80000, 200000);
      const cos = Math.round(sales * (0.55 + Math.random() * 0.15));
      const gp = sales - cos;
      const expenses = ri(15000, 40000);
      const np = gp - expenses;
      parts.push({
        topic: base, topic_name: "financial statements", partLabel: "1.1", marks: 3, difficulty,
        question: `Sales R${sales.toLocaleString("en-ZA")}; cost of sales R${cos.toLocaleString("en-ZA")}. Calculate gross profit.`,
        answer: `R${gp.toLocaleString("en-ZA")}`,
        explanation: `GP = Sales − COS = ${sales} − ${cos} = ${gp}`
      });
      parts.push({
        topic: base, topic_name: "financial statements", partLabel: "1.2", marks: 3, difficulty,
        question: `Operating expenses total R${expenses.toLocaleString("en-ZA")}. Calculate net profit for the year.`,
        answer: `R${np.toLocaleString("en-ZA")}`,
        explanation: `NP = GP − expenses = ${gp} − ${expenses} = ${np}`
      });
      parts.push({
        topic: base, topic_name: "financial statements", partLabel: "1.3", marks: 2, difficulty,
        question: "Name the statement that reports assets, equity and liabilities at a point in time.",
        answer: "Statement of financial position (balance sheet)",
        explanation: "It reflects the accounting equation at the reporting date."
      });
      return parts;
    }
    // Generic multi-part: mix practice + concept
    for (let i = 0; i < count; i++) {
      const gen = this.generate(base, difficulty + (i > 1 ? 1 : 0), { concept: i === 1 });
      if (!gen) continue;
      parts.push({
        ...gen,
        partLabel: `1.${i + 1}`,
        marks: gen.marks || (i === 0 ? 3 : 2),
        difficulty
      });
    }
    if (!parts.length) {
      const gen = this.generate(base, difficulty);
      if (gen) parts.push({ ...gen, partLabel: "1.1", marks: 4 });
    }
    return parts;
  }
}

export function isMultiSubjectTopic(id) {
  const s = String(id || "");
  return /^(ls_|geo_|ns_|tech_|acc_|cat_)/.test(s);
}
