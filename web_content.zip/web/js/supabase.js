/**
 * Cliente REST de Supabase para autenticación, empleados y sincronización de cambios.
 */

class SupabaseClient {
  constructor(config) {
    this.baseUrl = config.url;
    this.apiKey = config.anonKey;
  }

  getHeaders() {
    return {
      'apikey': this.apiKey,
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json'
    };
  }

  /**
   * Autenticación idéntica a Android: Matrícula + Email + Contraseña (solo Administrador).
   */
  async login(numeroEmpleado, email, passwordAdmin = '') {
    const numTrim = (numeroEmpleado || '').trim();
    const emailTrim = (email || '').trim().toLowerCase();

    // 1. CASO ADMINISTRADOR (0000 o admin@metro.es)
    if (numTrim === '0000' || emailTrim === 'admin@metro.es') {
      const pass = (passwordAdmin || '').trim();
      if (pass !== 'Admin2026!') {
        throw new Error('Contraseña de administrador incorrecta.');
      }

      const sesionAdmin = {
        numeroEmpleado: '0000',
        email: 'admin@metro.es',
        nombreCompleto: 'Administrador CTO',
        letra: 'ADMIN',
        rol: 'ADMIN',
        fotoUri: '',
        isLoggedIn: true
      };

      localStorage.setItem('cto_sesion_iphone', JSON.stringify(sesionAdmin));
      await setConfig('user_session', sesionAdmin);
      return sesionAdmin;
    }

    // 2. CASO CONDUCTOR / EMPLEADO
    if (!numTrim || !emailTrim) {
      throw new Error('Debes introducir tu número de matrícula y tu correo electrónico.');
    }

    const url = `${this.baseUrl}/rest/v1/empleados?numero_empleado=eq.${encodeURIComponent(numTrim)}&select=*`;
    const res = await fetch(url, {
      method: 'GET',
      headers: this.getHeaders()
    });

    if (!res.ok) {
      throw new Error(`Error conectando con Supabase: ${res.statusText}`);
    }

    const data = await res.json();
    if (!data || data.length === 0) {
      throw new Error('Matrícula o número de empleado no encontrado en el censo oficial.');
    }

    const emp = data[0];

    // Comprobación de estado activo
    if (emp.activo === false) {
      throw new Error('Este usuario no está activado, solicita activación al administrador.');
    }

    // Comprobación de correo electrónico
    const emailRegistrado = (emp.email || '').trim().toLowerCase();
    if (emailRegistrado && emailRegistrado !== emailTrim) {
      throw new Error('El correo electrónico no coincide con el registrado para esta matrícula.');
    }

    // Si en Supabase no tenía email registrado, lo vinculamos automáticamente para futuros inicios
    if (!emailRegistrado) {
      try {
        await fetch(`${this.baseUrl}/rest/v1/empleados?numero_empleado=eq.${encodeURIComponent(numTrim)}`, {
          method: 'PATCH',
          headers: this.getHeaders(),
          body: JSON.stringify({ email: emailTrim })
        });
      } catch (_) {}
    }

    // Obtener o generar identificador de instalación de iPhone
    let deviceId = localStorage.getItem('iphone_device_id');
    if (!deviceId) {
      deviceId = 'ios_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
      localStorage.setItem('iphone_device_id', deviceId);
    }

    // Registrar terminal en dispositivos_registro
    await this.registrarDispositivo(numTrim, deviceId);

    const sesion = {
      numeroEmpleado: emp.numero_empleado,
      nombreCompleto: emp.nombre_completo || '',
      letra: emp.letra || '',
      rol: emp.rol || 'EMPLEADO',
      fotoUri: emp.foto_uri || '',
      isLoggedIn: true
    };

    localStorage.setItem('cto_sesion_iphone', JSON.stringify(sesion));
    await setConfig('user_session', sesion);

    return sesion;
  }

  async registrarDispositivo(numeroEmpleado, deviceId) {
    try {
      const url = `${this.baseUrl}/rest/v1/dispositivos_registro?on_conflict=numero_empleado,device_id`;
      const body = [{
        numero_empleado: numeroEmpleado,
        device_id: deviceId,
        device_model: 'Apple iPhone (PWA)',
        android_version: 'iOS Safari Standalone',
        app_version: '1.4.4-PWA',
        ultima_conexion: new Date().toISOString(),
        activo: true
      }];

      await fetch(url, {
        method: 'POST',
        headers: {
          ...this.getHeaders(),
          'Prefer': 'resolution=merge-duplicates'
        },
        body: JSON.stringify(body)
      });
    } catch (e) {
      console.warn('Error registrando terminal en Supabase:', e);
    }
  }

  /**
   * Sincroniza el censo oficial de empleados y fotos de perfil en segundo plano.
   */
  async sincronizarCensoEmpleados() {
    try {
      const url = `${this.baseUrl}/rest/v1/empleados?select=*`;
      const res = await fetch(url, { headers: this.getHeaders() });
      if (!res.ok) return [];

      const data = await res.json();
      const empleadosMapeados = data.map(e => ({
        numeroEmpleado: e.numero_empleado,
        nombreCompleto: e.nombre_completo,
        letra: e.letra || '',
        telefono: e.telefono || '',
        fotoUri: e.foto_uri || '',
        rol: e.rol || 'EMPLEADO'
      }));

      await guardarEmpleadosLote(empleadosMapeados);
      return empleadosMapeados;
    } catch (e) {
      console.warn('Error sincronizando empleados desde Supabase:', e);
      return [];
    }
  }

  /**
   * Sube variaciones detectadas en el Excel a Supabase para auditoría común con Android.
   */
  async subirVariacionesHistorial(variaciones) {
    if (!variaciones || variaciones.length === 0) return;

    try {
      const url = `${this.baseUrl}/rest/v1/historial_cambios_excel?on_conflict=hash_cambio`;
      const items = variaciones.map(v => ({
        fecha_modificacion: v.fechaModificacion,
        fecha_servicio: v.fechaServicio,
        letra: v.letra,
        empleado_nombre: v.empleadoNombre || '',
        servicio_anterior: v.servicioAnterior || '',
        servicio_nuevo: v.servicioNuevo || '',
        nota_anterior: v.notaAnterior || '',
        nota_nueva: v.notaNueva || '',
        lineas_anterior: v.lineasAnterior || '',
        lineas_nueva: v.lineasNueva || '',
        tipo_cambio: v.tipoCambio || 'MODIFICACION',
        origen: 'iPhone SharePoint Sync',
        hash_cambio: v.hashCambio
      }));

      await fetch(url, {
        method: 'POST',
        headers: {
          ...this.getHeaders(),
          'Prefer': 'resolution=ignore-duplicates'
        },
        body: JSON.stringify(items)
      });
    } catch (e) {
      console.warn('Error subiendo variaciones a Supabase:', e);
    }
  }

  /**
   * Descarga las variaciones recientes de historial_cambios_excel desde Supabase y las guarda en IndexedDB.
   */
  async sincronizarHistorialCambiosDesdeSupabase() {
    try {
      const url = `${this.baseUrl}/rest/v1/historial_cambios_excel?order=fecha_modificacion.desc&limit=50`;
      const res = await fetch(url, { headers: this.getHeaders() });
      if (!res.ok) return [];

      const data = await res.json();
      const mapeados = data.map(item => ({
        fechaModificacion: item.fecha_modificacion,
        fechaServicio: item.fecha_servicio,
        letra: (item.letra || '').trim().toUpperCase(),
        empleadoNombre: item.empleado_nombre || '',
        servicioAnterior: item.servicio_anterior || '',
        servicioNuevo: item.servicio_nuevo || '',
        notaAnterior: item.nota_anterior || '',
        notaNueva: item.nota_nueva || '',
        lineasAnterior: item.lineas_anterior || '',
        lineasNueva: item.lineas_nueva || '',
        tipoCambio: item.tipo_cambio || 'MODIFICACION',
        hashCambio: item.hash_cambio,
        visto: false
      }));

      await guardarCambiosHistorial(mapeados);
      return mapeados;
    } catch (e) {
      console.warn('Error sincronizando historial desde Supabase:', e);
      return [];
    }
  }
}

const supabase = new SupabaseClient(SUPABASE_CONFIG);
