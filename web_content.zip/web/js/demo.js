/* Demo screens – delete or replace with your own UI. Any element with data-g gets hover highlight. */
(() => {
  const $ = s => document.querySelector(s);
  let n = 0;
  const count = $('#count');
  $('#plus').addEventListener('click', () => count.textContent = ++n);
  $('#minus').addEventListener('click', () => count.textContent = --n);

  const sw = $('#sw');
  sw.addEventListener('click', () => {
    const on = sw.getAttribute('aria-pressed') !== 'true';
    sw.setAttribute('aria-pressed', on); $('#swLabel').textContent = on ? 'On' : 'Off';
  });

  $('#heartCard').addEventListener('dblclick', () => {
    const h = $('#heart'); const on = h.classList.toggle('on'); h.textContent = on ? '♥' : '♡';
  });

  document.querySelectorAll('[data-theme]').forEach(b => b.addEventListener('click', () => {
    document.documentElement.style.setProperty('--bg', b.dataset.theme);
    document.querySelector('meta[name=theme-color]').content = b.dataset.theme;
  }));

  const list = $('#list');
  for (let i = 1; i <= 25; i++) { const li = document.createElement('li'); li.textContent = 'Scroll item ' + i; list.appendChild(li); }
})();
