/* AirTouch – hands-free control engine
 * Camera -> MediaPipe Hands -> smoothed pointer -> pinch gestures -> real DOM events
 */
(() => {
'use strict';
const MP_BASE = 'https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/';
const $ = s => document.querySelector(s);

/* ---------- settings ---------- */
const DEF = { area: 0.7, smooth: 0.6, pinch: 0.28, source: 'palm', preview: true };
let cfg = { ...DEF };
try { cfg = { ...DEF, ...JSON.parse(localStorage.getItem('airtouch.cfg') || '{}') }; } catch (e) {}
const saveCfg = () => { try { localStorage.setItem('airtouch.cfg', JSON.stringify(cfg)); } catch (e) {} };

/* ---------- elements ---------- */
const video = $('#cam'), overlay = $('#overlay'), octx = overlay.getContext('2d');
const cursor = $('#cursor'), statusEl = $('#status'), pip = $('#pip');
const intro = $('#intro'), introMsg = $('#introMsg'), startBtn = $('#startBtn'), bar = $('#bar');

/* ---------- One-Euro filter (smooth when slow, responsive when fast) ---------- */
const alphaOf = (rate, cut) => { const tau = 1 / (2 * Math.PI * cut); return 1 / (1 + tau * rate); };
class OneEuro {
  constructor() { this.reset(); }
  reset() { this.x = null; this.dx = 0; this.t = 0; }
  filter(v, t, minCut, beta) {
    if (this.x === null) { this.x = v; this.t = t; return v; }
    const dt = Math.max((t - this.t) / 1000, 1e-3); this.t = t;
    const rate = 1 / dt;
    this.dx += alphaOf(rate, 1) * ((v - this.x) / dt - this.dx);
    const cut = minCut + beta * Math.abs(this.dx);
    this.x += alphaOf(rate, cut) * (v - this.x);
    return this.x;
  }
}
const fx = new OneEuro(), fy = new OneEuro();

/* ---------- state ---------- */
let stream = null, hands = null, running = false, paused = false, wakeLock = null;
let lastSeen = 0, lastVT = -1, busy = false;
let pos = { x: innerWidth / 2, y: innerHeight / 2 };
let pinching = false, pinchStart = 0, pinchPos = null, movedFar = false, scrolling = false;
let scrollEl = null, prevY = 0, lastTap = 0, lastTapPos = null, hoverEl = null;

const EDGES = [[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],[13,17],[17,18],[18,19],[19,20],[0,17]];

function setStatus(text, cls) { statusEl.textContent = text; statusEl.className = cls || ''; }

/* ---------- start / stop ---------- */
async function start() {
  introMsg.textContent = '';
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    introMsg.textContent = 'Camera needs HTTPS (or localhost). Open this app from a secure address.'; return;
  }
  if (typeof Hands === 'undefined') {
    introMsg.textContent = 'Hand-tracking library could not load. Check your internet connection and reload.'; return;
  }
  startBtn.disabled = true; startBtn.textContent = 'Waiting for camera permission…';
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, audio: false
    });
  } catch (e) {
    startBtn.disabled = false; startBtn.textContent = 'Allow camera & start';
    introMsg.textContent = (e && e.name === 'NotAllowedError')
      ? 'Camera permission was denied. Allow it in the browser/site settings and try again.'
      : 'Could not open the camera: ' + (e && e.message ? e.message : e);
    return;
  }
  video.srcObject = stream;
  try { await video.play(); } catch (e) {}
  startBtn.textContent = 'Loading hand model…';
  try {
    if (!hands) {
      hands = new Hands({ locateFile: f => MP_BASE + f });
      hands.setOptions({ maxNumHands: 1, modelComplexity: 0, minDetectionConfidence: 0.6, minTrackingConfidence: 0.5 });
      hands.onResults(onResults);
      await hands.initialize();
    }
  } catch (e) {
    introMsg.textContent = 'Could not load the hand model: ' + (e && e.message ? e.message : e);
    startBtn.disabled = false; startBtn.textContent = 'Allow camera & start'; return;
  }
  intro.classList.add('hidden');
  [bar, statusEl].forEach(e => e.classList.remove('hidden'));
  running = true; paused = false;
  applyPreview();
  $('#btnPause').textContent = '⏸ Pause';
  setStatus('Show your hand ✋', 'warn');
  requestWake();
  loop();
}

function stop() {
  running = false;
  if (stream) stream.getTracks().forEach(t => t.stop());
  stream = null; video.srcObject = null;
  releaseWake(); resetHand();
  [bar, statusEl, pip].forEach(e => e.classList.add('hidden'));
  intro.classList.remove('hidden');
  startBtn.disabled = false; startBtn.textContent = 'Allow camera & start';
}

async function loop() {
  if (!running) return;
  if (!paused && !busy && video.readyState >= 2 && video.currentTime !== lastVT) {
    lastVT = video.currentTime; busy = true;
    try { await hands.send({ image: video }); } catch (e) {}
    busy = false;
  }
  requestAnimationFrame(loop);
}

/* keep the screen awake and recover when the tab comes back */
async function requestWake() { try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {} }
function releaseWake() { try { wakeLock && wakeLock.release(); } catch (e) {} wakeLock = null; }
document.addEventListener('visibilitychange', async () => {
  if (document.visibilityState !== 'visible' || !running) return;
  requestWake();
  const t = stream && stream.getVideoTracks()[0];
  if (!t || t.readyState !== 'live') { stop(); introMsg.textContent = 'Camera was paused by the browser. Tap start again.'; }
  else { try { await video.play(); } catch (e) {} }
});

/* ---------- results ---------- */
function onResults(res) {
  if (!running) return;
  const now = performance.now();
  const lm = res.multiHandLandmarks && res.multiHandLandmarks[0];
  drawPreview(lm);
  if (paused) return;
  if (!lm) { if (now - lastSeen > 350) handLost(); return; }
  lastSeen = now;

  const W = video.videoWidth || 640, H = video.videoHeight || 480;
  const d = (a, b) => Math.hypot((lm[a].x - lm[b].x) * W, (lm[a].y - lm[b].y) * H);
  const handSize = d(0, 9) || 1;
  const ratio = d(4, 8) / handSize;               // thumb–index distance relative to hand size

  let rx, ry;
  if (cfg.source === 'tip') { rx = lm[8].x; ry = lm[8].y; }
  else { const ids = [0, 5, 9, 13, 17]; rx = ids.reduce((s, i) => s + lm[i].x, 0) / 5; ry = ids.reduce((s, i) => s + lm[i].y, 0) / 5; }
  rx = 1 - rx;                                    // mirror like a selfie
  const m = (1 - cfg.area) / 2;
  const nx = Math.min(1, Math.max(0, (rx - m) / cfg.area));
  const ny = Math.min(1, Math.max(0, (ry - m) / cfg.area));

  const minCut = 0.4 + (1 - cfg.smooth) * 2.6;
  pos.x = fx.filter(nx * innerWidth, now, minCut, 0.02);
  pos.y = fy.filter(ny * innerHeight, now, minCut, 0.02);

  cursor.style.transform = `translate3d(${pos.x}px,${pos.y}px,0)`;
  cursor.classList.add('show');
  updateHover(pinching ? pinchPos : pos);
  updatePinch(ratio, now);
  if (!pinching) setStatus('Hand tracking ✓  (pinch to tap)', 'ok');
}

function handLost() {
  resetHand();
  setStatus('Show your hand ✋', 'warn');
}
function resetHand() {
  cursor.classList.remove('show', 'pinch');
  pinching = false; scrolling = false; fx.reset(); fy.reset();
  if (hoverEl) { hoverEl.classList.remove('g-hover'); hoverEl = null; }
}

/* ---------- pinch state machine ---------- */
function updatePinch(ratio, now) {
  const on = cfg.pinch, off = cfg.pinch + 0.12;   // hysteresis avoids flicker
  if (!pinching && ratio < on) {
    pinching = true; pinchStart = now; pinchPos = { ...pos }; movedFar = false; scrolling = false;
    scrollEl = null; prevY = pos.y; cursor.classList.add('pinch');
    setStatus('Pinch ●', 'ok');
  } else if (pinching && ratio > off) {
    pinching = false; cursor.classList.remove('pinch');
    onRelease(now);
  } else if (pinching) {
    if (Math.hypot(pos.x - pinchPos.x, pos.y - pinchPos.y) > 30) movedFar = true;
    if (movedFar && now - pinchStart > 220) {
      if (!scrolling) { scrolling = true; scrollEl = scroller(document.elementFromPoint(pinchPos.x, pinchPos.y)); prevY = pos.y; }
      if (scrollEl) scrollEl.scrollTop -= (pos.y - prevY) * 1.6;   // content follows the hand
      prevY = pos.y;
    }
  }
}

function onRelease(now) {
  if (scrolling) { scrolling = false; return; }
  if (now - pinchStart > 700) return;             // long press without movement: ignore
  const p = pinchPos;
  fire('click', p);
  if (lastTapPos && now - lastTap < 550 && Math.hypot(p.x - lastTapPos.x, p.y - lastTapPos.y) < 70) {
    fire('dblclick', p); lastTap = 0; lastTapPos = null;
    document.dispatchEvent(new CustomEvent('gesture', { detail: { type: 'doubletap', x: p.x, y: p.y } }));
  } else {
    lastTap = now; lastTapPos = { ...p };
    document.dispatchEvent(new CustomEvent('gesture', { detail: { type: 'tap', x: p.x, y: p.y } }));
  }
  ripple(p);
}

/* ---------- DOM helpers ---------- */
function fire(type, p) {
  const el = document.elementFromPoint(p.x, p.y);
  if (!el) return;
  const opts = { bubbles: true, cancelable: true, view: window, clientX: p.x, clientY: p.y };
  if (type === 'click') {
    el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerType: 'touch', isPrimary: true }));
    el.dispatchEvent(new MouseEvent('mousedown', opts));
    el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerType: 'touch', isPrimary: true }));
    el.dispatchEvent(new MouseEvent('mouseup', opts));
    const focusable = el.closest('input,textarea,select,button,a,[tabindex]');
    if (focusable && focusable.focus) focusable.focus({ preventScroll: true });
  }
  el.dispatchEvent(new MouseEvent(type, opts));
}
function ripple(p) {
  const r = document.createElement('div'); r.className = 'ripple';
  r.style.left = p.x + 'px'; r.style.top = p.y + 'px';
  document.body.appendChild(r); setTimeout(() => r.remove(), 520);
}
function updateHover(p) {
  const el = document.elementFromPoint(p.x, p.y);
  const target = el && el.closest('button,a,input,select,label,[data-g]');
  if (target === hoverEl) return;
  if (hoverEl) hoverEl.classList.remove('g-hover');
  hoverEl = target; if (hoverEl) hoverEl.classList.add('g-hover');
}
function scroller(el) {
  while (el && el !== document.body && el !== document.documentElement) {
    const s = getComputedStyle(el);
    if (/(auto|scroll)/.test(s.overflowY) && el.scrollHeight > el.clientHeight) return el;
    el = el.parentElement;
  }
  return document.scrollingElement;
}

/* ---------- preview ---------- */
function drawPreview(lm) {
  if (!cfg.preview) return;
  const W = video.videoWidth || 640, H = video.videoHeight || 480;
  if (overlay.width !== W) { overlay.width = W; overlay.height = H; }
  octx.clearRect(0, 0, W, H);
  if (!lm) return;
  octx.lineWidth = 3; octx.strokeStyle = '#5b8cff'; octx.fillStyle = '#2ee59d';
  octx.beginPath();
  EDGES.forEach(([a, b]) => { octx.moveTo(lm[a].x * W, lm[a].y * H); octx.lineTo(lm[b].x * W, lm[b].y * H); });
  octx.stroke();
  lm.forEach(p => { octx.beginPath(); octx.arc(p.x * W, p.y * H, 4, 0, 7); octx.fill(); });
}
function applyPreview() { pip.classList.toggle('hidden', !(cfg.preview && running)); }

/* ---------- UI wiring ---------- */
startBtn.addEventListener('click', start);
$('#stopBtn').addEventListener('click', stop);
$('#btnPause').addEventListener('click', () => {
  paused = !paused; $('#btnPause').textContent = paused ? '▶ Resume' : '⏸ Pause';
  if (paused) { resetHand(); setStatus('Paused', 'warn'); } else setStatus('Show your hand ✋', 'warn');
});
$('#btnPip').addEventListener('click', () => { cfg.preview = !cfg.preview; saveCfg(); applyPreview(); });
$('#fsBtn').addEventListener('click', () => {
  const d = document;
  if (d.fullscreenElement) d.exitFullscreen(); else if (d.documentElement.requestFullscreen) d.documentElement.requestFullscreen().catch(() => {});
});

/* settings sheet (stepper buttons so it works without touching) */
const ROWS = [
  { k: 'area',   label: 'Hand reach',        hint: 'lower = less arm movement', min: .5, max: 1, step: .05, fmt: v => Math.round(v * 100) + '%' },
  { k: 'smooth', label: 'Smoothness',        hint: 'higher = steadier dot',     min: 0,  max: 1, step: .1,  fmt: v => Math.round(v * 10) + '/10' },
  { k: 'pinch',  label: 'Pinch sensitivity', hint: 'higher = easier to pinch',  min: .16, max: .42, step: .02, fmt: v => Math.round((v - .16) / .26 * 10) + '/10' },
  { k: 'source', label: 'Pointer',           hint: 'palm = stable, tip = precise', toggle: ['palm', 'tip'], fmt: v => v === 'palm' ? 'Palm' : 'Fingertip' },
  { k: 'preview', label: 'Camera preview',   hint: '',                          toggle: [true, false], fmt: v => v ? 'On' : 'Off' }
];
function renderSettings() {
  const box = $('#settingsRows'); box.innerHTML = '';
  ROWS.forEach(r => {
    const row = document.createElement('div'); row.className = 'srow';
    row.innerHTML = `<div>${r.label}<small>${r.hint}</small></div><div class="stepper"></div>`;
    const st = row.querySelector('.stepper');
    const val = document.createElement('span'); val.className = 'val'; val.textContent = r.fmt(cfg[r.k]);
    const mk = (txt, fn) => { const b = document.createElement('button'); b.textContent = txt; b.setAttribute('data-g', ''); b.addEventListener('click', () => { fn(); saveCfg(); val.textContent = r.fmt(cfg[r.k]); applyPreview(); }); return b; };
    if (r.toggle) { st.append(mk('Change', () => { const i = r.toggle.indexOf(cfg[r.k]); cfg[r.k] = r.toggle[(i + 1) % r.toggle.length]; }), val); }
    else {
      const clamp = v => Math.min(r.max, Math.max(r.min, Math.round(v * 100) / 100));
      st.append(mk('−', () => cfg[r.k] = clamp(cfg[r.k] - r.step)), val, mk('+', () => cfg[r.k] = clamp(cfg[r.k] + r.step)));
    }
    box.appendChild(row);
  });
}
$('#openSettings').addEventListener('click', () => { renderSettings(); $('#settings').classList.remove('hidden'); });
$('#closeSettings').addEventListener('click', () => $('#settings').classList.add('hidden'));
$('#resetCfg').addEventListener('click', () => { cfg = { ...DEF }; saveCfg(); renderSettings(); applyPreview(); });

window.AirTouch = { start, stop, get config() { return cfg; } };
})();
