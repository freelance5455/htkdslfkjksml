/**
 * Lógica principal de la aplicación PWA para iPhone y navegadores web.
 * Paridad 100% fiel con la app Android oficial de Metro CTO 2026.
 */

// Estado global de la aplicación
const AppState = {
  usuarioActual: null,
  fechaSeleccionada: formatearFechaIso(new Date()),
  franjaSeleccionada: 'TODAS',
  busquedaTexto: '',
  serviciosDelDia: [],
  empleadosCenso: [],
  empleadoDetalleActual: null,
  mesCalendarioPersonalIndex: 9, // Índice en MESES_CALENDARIO (0 a 12), por defecto Octubre 2026
  fechaCalendarioPersonalSeleccionada: null,
  fechaHoyIsoCalendario: '2026-10-12',
  serviciosCalendarioCache: new Map()
};

// =================== UTILIDADES DE FECHA ===================

function formatearFechaIso(date) {
  const d = new Date(date);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function parsearFechaSegura(fechaRaw) {
  if (!fechaRaw) return null;
  const s = String(fechaRaw).trim();
  if (s.match(/^\d{4}-\d{2}-\d{2}$/)) {
    return new Date(s + 'T00:00:00');
  }
  if (s.match(/^\d{2}-\d{2}-\d{4}$/)) {
    const p = s.split('-');
    return new Date(`${p[2]}-${p[1]}-${p[0]}T00:00:00`);
  }
  if (s.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
    const p = s.split('/');
    return new Date(`${p[2]}-${p[1]}-${p[0]}T00:00:00`);
  }
  return null;
}

function formatearFechaVisual(fechaIso) {
  const d = parsearFechaSegura(fechaIso);
  if (!d || isNaN(d.getTime())) return fechaIso;

  const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

  const diaSemana = dias[d.getDay()];
  const diaMes = d.getDate();
  const mes = meses[d.getMonth()];
  const ano = d.getFullYear();

  return `${diaSemana}, ${diaMes} de ${mes} de ${ano}`;
}

// =================== INICIALIZACIÓN ===================

document.addEventListener('DOMContentLoaded', async () => {
  // Registrar Service Worker para soporte offline
  if ('serviceWorker' in navigator) {
    try {
      await navigator.serviceWorker.register('./sw.js');
    } catch (_) {}
  }

  // Comprobar si está en iPhone y mostrar banner de instalación si no es standalone
  comprobarBannerInstalacionIphone();

  // Configurar listeners de la interfaz
  configurarEventosUI();

  // Comprobar sesión existente
  await inicializarSesion();
});

function comprobarBannerInstalacionIphone() {
  const esIos = /iphone|ipad|ipod/i.test(window.navigator.userAgent);
  const esStandalone = window.navigator.standalone === true || window.matchMedia('(display-mode: standalone)').matches;

  const banner = document.getElementById('iphone-install-banner');
  if (banner) {
    banner.style.display = (esIos && !esStandalone) ? 'flex' : 'none';
  }
}

async function inicializarSesion() {
  const sesionLocal = localStorage.getItem('cto_sesion_iphone');
  if (sesionLocal) {
    try {
      AppState.usuarioActual = JSON.parse(sesionLocal);
    } catch (_) {}
  }

  if (!AppState.usuarioActual) {
    mostrarPantalla('login-screen');
    return;
  }

  // Cargar censo de empleados en segundo plano
  AppState.empleadosCenso = await obtenerTodosLosEmpleados();
  if (AppState.empleadosCenso.length === 0) {
    AppState.empleadosCenso = await supabase.sincronizarCensoEmpleados();
  }

  // Comprobar si ya existen servicios cargados
  const totalServicios = await contarServiciosTotal();

  if (totalServicios === 0) {
    // Sincronización automática inicial transparente
    mostrarPantalla('sharepoint-screen');
    const spStatusText = document.getElementById('sharepoint-status-text');
    const spSpinner = document.getElementById('sharepoint-loading-spinner');
    if (spSpinner) spSpinner.style.display = 'block';

    const exito = await descargarYSincronizarCuadranteOficial((msg) => {
      if (spStatusText) spStatusText.textContent = msg;
    });

    if (exito) {
      mostrarPantalla('home-screen');
      await cargarDatosApp();
    } else {
      if (spSpinner) spSpinner.style.display = 'none';
    }
  } else {
    mostrarPantalla('home-screen');
    await cargarDatosApp();
  }
}

function mostrarPantalla(screenId) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(screenId);
  if (target) {
    target.classList.add('active');
    window.scrollTo(0, 0);
    const container = document.querySelector('.app-container');
    if (container) container.scrollTop = 0;
  }
}

/**
 * Descarga y parsea el cuadrante oficial de forma 100% transparente.
 * Primero intenta desde Supabase Storage (CORS abierto, funciona desde cualquier navegador y file://).
 * Si no hay red, intenta el archivo local empotrado.
 */
async function descargarYSincronizarCuadranteOficial(onProgreso = null) {
  // 1. Descarga transparente desde Supabase Storage (CORS habilitado internacionalmente)
  try {
    if (onProgreso) onProgreso('Conectando con servidor y descargando cuadrante oficial...');
    const res = await fetch(SUPABASE_STORAGE_CONFIG.cuadranteUrl, { cache: 'no-cache' });
    if (res.ok) {
      const buffer = await res.arrayBuffer();
      if (buffer && buffer.byteLength > 1000) {
        if (onProgreso) onProgreso('Parseando matriz de turnos y notas...');
        await parsearExcelCuadrante(buffer, onProgreso);
        await setConfig('setup_completado', true);
        return true;
      }
    }
  } catch (e) {
    console.warn('Descarga por Supabase Storage no disponible:', e);
  }

  // 2. Fallback a archivo local data/cuadrante.xlsm (para entornos con servidor local)
  try {
    const resLocal = await fetch('./data/cuadrante.xlsm');
    if (resLocal.ok) {
      const bufLocal = await resLocal.arrayBuffer();
      await parsearExcelCuadrante(bufLocal, onProgreso);
      await setConfig('setup_completado', true);
      return true;
    }
  } catch (_) {}

  return false;
}

// =================== GESTIÓN DE EVENTOS UI ===================

function configurarEventosUI() {
  // 1. LOGIN CON VISIBILIDAD DINÁMICA DE ADMINISTRADOR
  const inputMatricula = document.getElementById('input-matricula');
  const inputEmail = document.getElementById('input-email');
  const groupPassAdmin = document.getElementById('group-password-admin');
  const inputPassword = document.getElementById('input-password');
  const errorMsgP = document.getElementById('login-error-msg');
  const formLogin = document.getElementById('form-login');

  function actualizarVisibilidadAdmin() {
    const num = (inputMatricula?.value || '').trim();
    const em = (inputEmail?.value || '').trim().toLowerCase();
    const esAdmin = (num === '0000' || em === 'admin@metro.es');

    if (groupPassAdmin) {
      groupPassAdmin.style.display = esAdmin ? 'block' : 'none';
      if (!esAdmin && inputPassword) {
        inputPassword.value = '';
        inputPassword.removeAttribute('required');
      } else if (esAdmin && inputPassword) {
        inputPassword.setAttribute('required', 'required');
      }
    }
  }

  inputMatricula?.addEventListener('input', actualizarVisibilidadAdmin);
  inputEmail?.addEventListener('input', actualizarVisibilidadAdmin);

  if (formLogin) {
    formLogin.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (errorMsgP) errorMsgP.style.display = 'none';

      const numInput = (inputMatricula?.value || '').trim();
      const emailInput = (inputEmail?.value || '').trim();
      const passInput = (inputPassword?.value || '').trim();
      const btn = document.getElementById('btn-login-submit');

      try {
        if (btn) {
          btn.disabled = true;
          btn.querySelector('span').textContent = 'Verificando con Supabase...';
        }

        const sesion = await supabase.login(numInput, emailInput, passInput);
        AppState.usuarioActual = sesion;

        // Cargar censo de empleados en segundo plano
        AppState.empleadosCenso = await supabase.sincronizarCensoEmpleados();

        const totalServicios = await contarServiciosTotal();
        if (totalServicios === 0) {
          // Pasar inmediatamente a la sincronización automática transparente
          mostrarPantalla('sharepoint-screen');
          const spSpinner = document.getElementById('sharepoint-loading-spinner');
          const spStatusText = document.getElementById('sharepoint-status-text');
          if (spSpinner) spSpinner.style.display = 'block';

          const exito = await descargarYSincronizarCuadranteOficial((msg) => {
            if (spStatusText) spStatusText.textContent = msg;
          });

          if (exito) {
            mostrarPantalla('home-screen');
            await cargarDatosApp();
          } else {
            if (spSpinner) spSpinner.style.display = 'none';
          }
        } else {
          mostrarPantalla('home-screen');
          await cargarDatosApp();
        }
      } catch (err) {
        if (errorMsgP) {
          errorMsgP.textContent = err.message || 'Error al autenticar';
          errorMsgP.style.display = 'block';
        } else {
          alert(err.message || 'Error al autenticar');
        }
      } finally {
        if (btn) {
          btn.disabled = false;
          btn.querySelector('span').textContent = 'Iniciar Sesión';
        }
      }
    });
  }

  // 2. SHAREPOINT / CARGA DE ARCHIVO
  // Botón 1: Sincronizar Cuadrante Oficial Integrado (descarga transparente desde Supabase Storage)
  document.getElementById('btn-load-bundled-excel')?.addEventListener('click', async () => {
    const spSpinner = document.getElementById('sharepoint-loading-spinner');
    const spStatusText = document.getElementById('sharepoint-status-text');
    try {
      if (spSpinner) spSpinner.style.display = 'block';
      const exito = await descargarYSincronizarCuadranteOficial((msg) => {
        if (spStatusText) spStatusText.textContent = msg;
      });

      if (exito) {
        mostrarPantalla('home-screen');
        await cargarDatosApp();
      } else {
        throw new Error('No se pudo descargar automáticamente. Por favor selecciona el archivo .xlsm abajo.');
      }
    } catch (e) {
      if (spSpinner) spSpinner.style.display = 'none';
      alert(e.message);
    }
  });

  // Botón 2: Conectar con Microsoft SharePoint
  document.getElementById('btn-sharepoint-sync-auto')?.addEventListener('click', () => {
    sharepointManager.iniciarLoginSharePoint();
    mostrarToastAviso('Descarga iniciada desde SharePoint.');
  });

  // Selector de archivos compatible 100% con Chrome, Edge, Safari y Firefox
  const inputFileExcel = document.getElementById('input-file-excel');
  if (inputFileExcel) {
    inputFileExcel.addEventListener('change', (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      procesarArchivoExcelLocal(file);
      e.target.value = ''; // Reset para permitir volver a seleccionar el mismo archivo
    });
  }

  // Zona de Arrastrar y Soltar (Drag & Drop)
  const dropZone = document.getElementById('drop-zone-excel');
  if (dropZone) {
    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.style.borderColor = 'var(--primary)';
    });
    dropZone.addEventListener('dragleave', () => {
      dropZone.style.borderColor = 'var(--border)';
    });
    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.style.borderColor = 'var(--border)';
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (file) procesarArchivoExcelLocal(file);
    });
  }

  // 3. SELECTOR DE FECHAS
  document.getElementById('btn-prev-day')?.addEventListener('click', () => cambiarDia(-1));
  document.getElementById('btn-next-day')?.addEventListener('click', () => cambiarDia(1));
  document.getElementById('btn-today')?.addEventListener('click', () => {
    AppState.fechaSeleccionada = formatearFechaIso(new Date());
    renderizarFechaActual();
    cargarServiciosDelDia();
    actualizarEventoDiaUI();
  });

  const datePicker = document.getElementById('native-date-picker');
  document.getElementById('date-display-box')?.addEventListener('click', () => {
    if (datePicker) {
      try { datePicker.showPicker(); } catch (_) { datePicker.click(); }
    }
  });

  datePicker?.addEventListener('change', (e) => {
    if (e.target.value) {
      AppState.fechaSeleccionada = e.target.value;
      renderizarFechaActual();
      cargarServiciosDelDia();
      actualizarEventoDiaUI();
    }
  });

  // Cápsula de Eventos del Día (Abre detalle con diseño Android)
  document.getElementById('capsule-eventos-dia')?.addEventListener('click', () => {
    if (eventoDelDiaActual && eventoDelDiaActual.descripcion) {
      mostrarDetalleEventoModal(eventoDelDiaActual, AppState.fechaSeleccionada);
    } else {
      mostrarToastAviso('No hay eventos registrados para este día.');
    }
  });

  document.getElementById('btn-close-evento-detail')?.addEventListener('click', () => {
    document.getElementById('modal-evento-detail')?.classList.remove('active');
  });

  document.getElementById('btn-confirm-evento-detail')?.addEventListener('click', () => {
    document.getElementById('modal-evento-detail')?.classList.remove('active');
  });

  // Selector e importación de archivo CALENDARIO EVENTOS.xlsx
  const inputFileEventos = document.getElementById('input-file-eventos');
  inputFileEventos?.addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    mostrarToastAviso('Procesando archivo de eventos...');
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const evs = await parsearExcelEventos(ev.target.result, (msg) => {
          mostrarToastAviso(msg);
        });
        await actualizarEventoDiaUI();
        mostrarToastAviso(`Se importaron ${evs.length} fechas con eventos correctamente.`);
      } catch (err) {
        alert('Error al importar eventos: ' + err.message);
      }
    };
    reader.onerror = () => alert('Error al leer el archivo de eventos.');
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  });

  // 4. FRANJA TABS
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      AppState.franjaSeleccionada = btn.getAttribute('data-franja') || 'TODAS';
      renderizarListaServicios();
    });
  });

  // 5. BÚSQUEDA
  const inputBusqueda = document.getElementById('input-search');
  inputBusqueda?.addEventListener('input', (e) => {
    AppState.busquedaTexto = e.target.value.trim().toLowerCase();
    renderizarListaServicios();
  });

  // 6. TOP BAR: AVATAR / PERFIL PROPIO (Abre su Ficha y Calendario Personal)
  document.getElementById('user-avatar-btn')?.addEventListener('click', () => {
    const usr = AppState.usuarioActual;
    if (!usr) return;
    abrirDetalleEmpleado(usr);
  });

  // 7. TOP BAR: BOTÓN RE-SINCRONIZAR SHAREPOINT
  document.getElementById('btn-topbar-sync')?.addEventListener('click', () => {
    mostrarPantalla('sharepoint-screen');
  });

  // 8. TOP BAR: BOTÓN GESTIÓN DE PERSONAL
  document.getElementById('btn-topbar-empleados')?.addEventListener('click', () => {
    abrirPantallaEmpleados();
  });

  // 9. TOP BAR: MENÚ DESPLEGABLE MÁS OPCIONES
  const btnMenu = document.getElementById('btn-topbar-menu');
  const dropdownMenu = document.getElementById('dropdown-menu-options');
  btnMenu?.addEventListener('click', (e) => {
    e.stopPropagation();
    if (dropdownMenu) {
      dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
    }
  });

  document.addEventListener('click', () => {
    if (dropdownMenu) dropdownMenu.style.display = 'none';
  });

  // Opciones del Menú:
  document.getElementById('menu-opt-importar-xlsm')?.addEventListener('click', () => {
    mostrarPantalla('sharepoint-screen');
  });

  document.getElementById('menu-opt-importar-eventos')?.addEventListener('click', async () => {
    if (inputFileEventos) {
      inputFileEventos.click();
    }
  });

  document.getElementById('menu-opt-historial-cambios')?.addEventListener('click', async () => {
    await comprobarCambiosAlIniciar(true);
  });

  document.getElementById('menu-opt-cerrar-sesion')?.addEventListener('click', () => {
    const conf = confirm('¿Deseas cerrar sesión?');
    if (conf) {
      localStorage.removeItem('cto_sesion_iphone');
      AppState.usuarioActual = null;
      mostrarPantalla('login-screen');
    }
  });

  // 10. PANTALLA GESTIÓN DE PERSONAL: RETROCESO, BÚSQUEDA Y ACCIONES
  document.getElementById('btn-empleados-back')?.addEventListener('click', () => {
    mostrarPantalla('home-screen');
  });

  document.getElementById('btn-empleados-sync-supabase')?.addEventListener('click', async () => {
    const icon = document.getElementById('icon-sync-empleados');
    if (icon) icon.style.animation = 'spin 1s linear infinite';
    mostrarToastAviso('Sincronizando censo desde Supabase...');
    AppState.empleadosCenso = await supabase.sincronizarCensoEmpleados();
    renderizarListaEmpleados();
    if (icon) icon.style.animation = 'none';
    mostrarToastAviso('Censo de empleados actualizado');
  });

  document.getElementById('btn-empleados-restart-mock')?.addEventListener('click', async () => {
    const conf = confirm('¿Deseas restaurar y resincronizar el censo de personal desde Supabase?');
    if (conf) {
      mostrarToastAviso('Restaurando censo oficial...');
      AppState.empleadosCenso = await supabase.sincronizarCensoEmpleados();
      renderizarListaEmpleados();
      mostrarToastAviso('Censo oficial restaurado');
    }
  });

  const inputSearchEmpleados = document.getElementById('input-search-empleados');
  const btnClearSearchEmpleados = document.getElementById('btn-clear-search-empleados');

  inputSearchEmpleados?.addEventListener('input', (e) => {
    const val = e.target.value;
    if (btnClearSearchEmpleados) {
      btnClearSearchEmpleados.style.display = val ? 'flex' : 'none';
    }
    renderizarListaEmpleados(val.trim().toLowerCase());
  });

  btnClearSearchEmpleados?.addEventListener('click', () => {
    if (inputSearchEmpleados) {
      inputSearchEmpleados.value = '';
      btnClearSearchEmpleados.style.display = 'none';
      inputSearchEmpleados.focus();
    }
    renderizarListaEmpleados('');
  });

  // Botón FAB para añadir empleado
  document.getElementById('btn-fab-add-empleado')?.addEventListener('click', () => {
    abrirModalEdicionEmpleado(null);
  });

  document.getElementById('btn-close-emp-edit')?.addEventListener('click', () => {
    document.getElementById('modal-empleado-edit')?.classList.remove('active');
  });

  // 11. MODAL DETALLE DE EMPLEADO (Idéntico a Android)
  document.getElementById('btn-close-emp-detail')?.addEventListener('click', () => {
    document.getElementById('modal-empleado-detail')?.classList.remove('active');
  });

  // Alternar conceptos calculados al pulsar el icono de calculadora
  document.getElementById('btn-emp-calc-toggle')?.addEventListener('click', () => {
    const collapse = document.getElementById('emp-computo-collapse');
    if (collapse) {
      const visible = (collapse.style.display !== 'none');
      collapse.style.display = visible ? 'none' : 'block';
    }
  });

  // Abrir vista calendario individual al pulsar el icono de calendario
  document.getElementById('btn-emp-cal-open')?.addEventListener('click', async () => {
    const viewFicha = document.getElementById('emp-view-ficha');
    const viewCal = document.getElementById('emp-view-calendario');
    if (viewFicha) viewFicha.style.display = 'none';
    if (viewCal) viewCal.style.display = 'block';

    const emp = AppState.empleadoDetalleActual;
    const titleEl = document.getElementById('emp-cal-topbar-title');
    if (titleEl && emp) {
      titleEl.textContent = `Ficha de ${emp.nombreCompleto || 'Empleado'}`;
    }

    const turnoPillVal = document.getElementById('cal-hero-turno');
    if (turnoPillVal && emp) {
      turnoPillVal.textContent = (emp.letra && emp.letra.trim().length > 0) ? emp.letra : '—';
    }

    // Calcular mes actual exactamente como Android EmpleadoCalendarioView.kt
    const now = new Date();
    const anioActual = now.getFullYear();
    const mesActualNum = now.getMonth() + 1;
    let mesIdx = 0;
    if (anioActual === 2027 && mesActualNum === 1) {
      mesIdx = 12;
    } else if (anioActual === 2026) {
      mesIdx = Math.max(0, Math.min(11, mesActualNum - 1));
    } else {
      mesIdx = Math.max(0, Math.min(11, mesActualNum - 1));
    }
    AppState.mesCalendarioPersonalIndex = mesIdx;

    // Resaltar día en curso (Hoy)
    const diaHoy = String(now.getDate()).padStart(2, '0');
    const mesHoy = String(now.getMonth() + 1).padStart(2, '0');
    const anioHoy = (anioActual === 2026 || (anioActual === 2027 && mesActualNum === 1)) ? anioActual : 2026;
    AppState.fechaHoyIsoCalendario = `${anioHoy}-${mesHoy}-${diaHoy}`;
    AppState.fechaCalendarioPersonalSeleccionada = AppState.fechaHoyIsoCalendario;

    renderizarChipsMeses();
    await renderizarMesCalendarioPersonal();
  });

  // Volver de la vista calendario a la ficha
  document.getElementById('btn-emp-cal-back')?.addEventListener('click', () => {
    const viewFicha = document.getElementById('emp-view-ficha');
    const viewCal = document.getElementById('emp-view-calendario');
    if (viewCal) viewCal.style.display = 'none';
    if (viewFicha) viewFicha.style.display = 'block';
  });

  // Copiar campos al portapapeles con toast
  document.getElementById('btn-emp-copy-num')?.addEventListener('click', () => {
    const emp = AppState.empleadoDetalleActual;
    copiarTextoPortapapeles('Número de empleado', emp?.numeroEmpleado);
  });

  document.getElementById('btn-emp-copy-tel')?.addEventListener('click', () => {
    const emp = AppState.empleadoDetalleActual;
    copiarTextoPortapapeles('Teléfono', emp?.telefono);
  });

  document.getElementById('btn-emp-copy-email')?.addEventListener('click', () => {
    const emp = AppState.empleadoDetalleActual;
    const email = emp?.email || (emp?.numeroEmpleado === '2010649' ? 'maransanz@tmb.cat' : '');
    copiarTextoPortapapeles('Correo electrónico', email);
  });

  // Eliminar empleado
  document.getElementById('btn-emp-delete')?.addEventListener('click', async () => {
    const emp = AppState.empleadoDetalleActual;
    if (!emp) return;

    const conf = confirm(`¿Estás seguro de eliminar a ${emp.nombreCompleto} (Nº ${emp.numeroEmpleado})?`);
    if (!conf) return;

    try {
      mostrarToastAviso('Eliminando empleado...');
      await eliminarEmpleadoDeBD(emp.numeroEmpleado);
      await supabase.eliminarEmpleado(emp.numeroEmpleado);

      AppState.empleadosCenso = AppState.empleadosCenso.filter(x => String(x.numeroEmpleado).trim() !== String(emp.numeroEmpleado).trim());
      renderizarListaEmpleados();

      document.getElementById('modal-empleado-detail')?.classList.remove('active');
      mostrarToastAviso('Empleado eliminado correctamente');
    } catch (err) {
      alert('Error al eliminar empleado: ' + err.message);
    }
  });

  // Editar empleado
  document.getElementById('btn-emp-edit')?.addEventListener('click', () => {
    abrirModalEdicionEmpleado(AppState.empleadoDetalleActual);
  });

  // Formulario para guardar o crear empleado
  const formEmpEdit = document.getElementById('form-emp-edit');
  if (formEmpEdit) {
    formEmpEdit.addEventListener('submit', async (e) => {
      e.preventDefault();
      const num = document.getElementById('edit-emp-numero')?.value.trim();
      const nom = document.getElementById('edit-emp-nombre')?.value.trim();
      const letra = document.getElementById('edit-emp-letra')?.value.trim().toUpperCase();
      const tel = document.getElementById('edit-emp-telefono')?.value.trim();
      const email = document.getElementById('edit-emp-email')?.value.trim();
      const foto = document.getElementById('edit-emp-foto')?.value.trim();

      if (!num || !nom) {
        alert('El número de empleado y el nombre son obligatorios');
        return;
      }

      const empObj = {
        numeroEmpleado: num,
        nombreCompleto: nom,
        letra: letra,
        telefono: tel,
        email: email,
        fotoUri: foto
      };

      try {
        mostrarToastAviso('Guardando empleado...');
        await guardarEmpleadoIndividual(empObj);
        await supabase.guardarEmpleado(empObj);

        // Actualizar lista en memoria
        const idx = AppState.empleadosCenso.findIndex(x => String(x.numeroEmpleado).trim() === num);
        if (idx >= 0) {
          AppState.empleadosCenso[idx] = empObj;
        } else {
          AppState.empleadosCenso.push(empObj);
        }

        renderizarListaEmpleados();

        if (AppState.empleadoDetalleActual && String(AppState.empleadoDetalleActual.numeroEmpleado).trim() === num) {
          await abrirDetalleEmpleado(empObj);
        }

        document.getElementById('modal-empleado-edit')?.classList.remove('active');
        mostrarToastAviso('Empleado guardado correctamente');
      } catch (err) {
        alert('Error al guardar empleado: ' + err.message);
      }
    });
  }

  document.getElementById('btn-cal-prev-month')?.addEventListener('click', async () => {
    if (AppState.mesCalendarioPersonalIndex > 0) {
      AppState.mesCalendarioPersonalIndex--;
      actualizarChipsMesesActivo();
      await renderizarMesCalendarioPersonal();
    }
  });

  document.getElementById('btn-cal-next-month')?.addEventListener('click', async () => {
    if (AppState.mesCalendarioPersonalIndex < MESES_CALENDARIO.length - 1) {
      AppState.mesCalendarioPersonalIndex++;
      actualizarChipsMesesActivo();
      await renderizarMesCalendarioPersonal();
    }
  });

  // 12. GUÍA DE INSTALACIÓN IPHONE
  document.getElementById('btn-show-install-guide')?.addEventListener('click', () => {
    document.getElementById('modal-install-guide')?.classList.add('active');
  });

  document.getElementById('btn-close-install-guide')?.addEventListener('click', () => {
    document.getElementById('modal-install-guide')?.classList.remove('active');
  });

  document.getElementById('btn-notif-entendido')?.addEventListener('click', () => {
    document.getElementById('modal-notificacion-cambios')?.classList.remove('active');
  });
}

/**
 * Lee y parsea un archivo Excel seleccionado localmente con máxima compatibilidad Chrome/Edge/Safari
 */
function procesarArchivoExcelLocal(file) {
  const spSpinner = document.getElementById('sharepoint-loading-spinner');
  const spStatusText = document.getElementById('sharepoint-status-text');

  if (spSpinner) spSpinner.style.display = 'block';
  if (spStatusText) spStatusText.textContent = 'Leyendo archivo Excel...';

  const reader = new FileReader();
  reader.onload = async (event) => {
    try {
      const buffer = event.target.result;
      if (spStatusText) spStatusText.textContent = 'Parseando matriz de turnos y notas...';

      const res = await parsearExcelCuadrante(buffer, (msg) => {
        if (spStatusText) spStatusText.textContent = msg;
      });

      await setConfig('setup_completado', true);
      mostrarPantalla('home-screen');
      await cargarDatosApp();
    } catch (err) {
      if (spSpinner) spSpinner.style.display = 'none';
      alert('Error al procesar el archivo Excel: ' + err.message);
    }
  };

  reader.onerror = () => {
    if (spSpinner) spSpinner.style.display = 'none';
    alert('Error al leer el archivo en el navegador.');
  };

  reader.readAsArrayBuffer(file);
}

function cambiarDia(offset) {
  const d = parsearFechaSegura(AppState.fechaSeleccionada) || new Date();
  d.setDate(d.getDate() + offset);
  AppState.fechaSeleccionada = formatearFechaIso(d);
  renderizarFechaActual();
  cargarServiciosDelDia();
  actualizarEventoDiaUI();
}

function renderizarFechaActual() {
  const datePicker = document.getElementById('native-date-picker');
  if (datePicker) datePicker.value = AppState.fechaSeleccionada;

  const d = parsearFechaSegura(AppState.fechaSeleccionada) || new Date();
  const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const diaSemana = dias[d.getDay()];
  const diaMes = d.getDate();
  const mes = meses[d.getMonth()];
  const ano = d.getFullYear();

  const diaSemanaEl = document.getElementById('date-display-dia-semana');
  const diaMesAnoEl = document.getElementById('date-display-dia-mes-ano');
  if (diaSemanaEl) diaSemanaEl.textContent = diaSemana;
  if (diaMesAnoEl) diaMesAnoEl.textContent = `${diaMes} de ${mes} de ${ano}`;

  // Compatibilidad hacia atrás con elementos anteriores si estuvieran presentes
  const dateDisp = document.getElementById('date-display-day');
  if (dateDisp) dateDisp.textContent = formatearFechaVisual(AppState.fechaSeleccionada);

  const hoyIso = formatearFechaIso(new Date());
  const esHoy = (AppState.fechaSeleccionada === hoyIso);

  const labelHoy = document.getElementById('label-btn-today');
  if (labelHoy) {
    labelHoy.textContent = esHoy ? 'Es Hoy' : 'Ir a Hoy';
  }

  const btnToday = document.getElementById('btn-today');
  if (btnToday) {
    if (esHoy) {
      btnToday.classList.add('is-today');
    } else {
      btnToday.classList.remove('is-today');
    }
  }

  const dateSub = document.getElementById('date-display-sub');
  if (dateSub) {
    dateSub.textContent = esHoy ? 'HOY' : AppState.fechaSeleccionada;
  }
}

// =================== CARGA DE DATOS PRINCIPALES ===================

async function cargarDatosApp() {
  renderizarHeaderUsuario();
  renderizarFechaActual();

  // Cargar censo de empleados si no está hidratado
  if (AppState.empleadosCenso.length === 0) {
    AppState.empleadosCenso = await obtenerTodosLosEmpleados();
    if (AppState.empleadosCenso.length === 0 && typeof CENSO_EMPLEADOS_INICIAL_DEFAULT !== 'undefined') {
      AppState.empleadosCenso = [...CENSO_EMPLEADOS_INICIAL_DEFAULT];
      guardarEmpleadosLote(AppState.empleadosCenso).catch(() => {});
    }
  }

  await cargarServiciosDelDia();
  await actualizarEventoDiaUI();

  // Sincronizar eventos desde Supabase Storage / local si no hay datos en IndexedDB
  sincronizarEventosDesdeServidor();

  // Comprobar automáticamente modificaciones y estado del calendario
  await comprobarCambiosAlIniciar();
}

function renderizarHeaderUsuario() {
  const u = AppState.usuarioActual;
  if (!u) return;

  const title = document.getElementById('topbar-user-name');
  if (title) title.textContent = 'Servicios del Día';

  const subtitle = document.getElementById('topbar-user-subtitle');
  if (subtitle) {
    subtitle.textContent = 'Calendario CTO 2026 L1';
  }
}

async function cargarServiciosDelDia() {
  const lista = await obtenerServiciosPorFecha(AppState.fechaSeleccionada);
  AppState.serviciosDelDia = lista;

  actualizarBadgesFranjas();
  renderizarListaServicios();
}

function actualizarBadgesFranjas() {
  const todos = AppState.serviciosDelDia;
  const countM = todos.filter(s => s.franja === 'MAÑANA').length;
  const countT = todos.filter(s => s.franja === 'TARDE').length;
  const countN = todos.filter(s => s.franja === 'NOCHE').length;

  document.getElementById('badge-count-todas').textContent = todos.length;
  document.getElementById('badge-count-manana').textContent = countM;
  document.getElementById('badge-count-tarde').textContent = countT;
  document.getElementById('badge-count-noche').textContent = countN;
}

/**
 * Renderiza la lista con el ORDEN OFICIAL ESTRICTO DE ANDROID (HomeViewModel.kt líneas 117..141):
 * - En vista "TODAS": los servicios se ordenan estrictamente por letra
 *   (agrupados por turno MAÑANA -> TARDE -> NOCHE).
 * - En filtros de turno individual (MAÑANA, TARDE, NOCHE): los servicios se ordenan
 *   estrictamente según prioridad de servicio oficial:
 *   (CC, CE, TL, CC1, CE1, TL1, FR, FI, t, [vacío], A, E, AS, D, F, RJ, V, FA, DA, P).
 */
function renderizarListaServicios() {
  const container = document.getElementById('services-list-container');
  if (!container) return;

  const mapaEmpleados = new Map(AppState.empleadosCenso.map(e => [e.letra.toUpperCase(), e]));

  // 1. Filtrar por franja
  let filtrados = AppState.serviciosDelDia.filter(s => {
    if (AppState.franjaSeleccionada === 'TODAS') return true;
    return s.franja.toUpperCase() === AppState.franjaSeleccionada;
  });

  // 2. Filtrar por texto de búsqueda
  const q = AppState.busquedaTexto;
  if (q) {
    filtrados = filtrados.filter(s => {
      const emp = mapaEmpleados.get(s.letra.toUpperCase());
      const nom = emp ? emp.nombreCompleto.toLowerCase() : '';
      const num = emp ? emp.numeroEmpleado.toLowerCase() : '';
      const serv = s.servicio.toLowerCase();
      const letra = s.letra.toLowerCase();
      const desc = obtenerInfoServicio(s.servicio).desc.toLowerCase();

      return letra.includes(q) || serv.includes(q) || desc.includes(q) || nom.includes(q) || num.includes(q);
    });
  }

  // 3. Ordenación oficial idéntica a HomeViewModel.kt de Android
  if (AppState.franjaSeleccionada === 'TODAS') {
    filtrados.sort((a, b) => {
      // Primero agrupados por turno (MAÑANA -> TARDE -> NOCHE)
      const franjaA = ORDEN_FRANJAS[a.franja?.toUpperCase()] || 4;
      const franjaB = ORDEN_FRANJAS[b.franja?.toUpperCase()] || 4;
      if (franjaA !== franjaB) return franjaA - franjaB;

      // Luego por orden de letra oficial dentro del turno (T1..T9.. / R1..R9.. / N1..N6R..)
      const ordenLetraA = obtenerOrdenLetraOficial(a.letra);
      const ordenLetraB = obtenerOrdenLetraOficial(b.letra);
      if (ordenLetraA !== ordenLetraB) return ordenLetraA - ordenLetraB;

      if (a.letra !== b.letra) return a.letra.localeCompare(b.letra);

      return obtenerPrioridadServicio(a.servicio) - obtenerPrioridadServicio(b.servicio);
    });
  } else {
    // En filtros de turno (MAÑANA, TARDE, NOCHE): estrictamente por prioridad de servicio oficial
    filtrados.sort((a, b) => {
      const prioA = obtenerPrioridadServicio(a.servicio);
      const prioB = obtenerPrioridadServicio(b.servicio);
      if (prioA !== prioB) return prioA - prioB;

      const ordenLetraA = obtenerOrdenLetraOficial(a.letra);
      const ordenLetraB = obtenerOrdenLetraOficial(b.letra);
      if (ordenLetraA !== ordenLetraB) return ordenLetraA - ordenLetraB;

      return a.letra.localeCompare(b.letra);
    });
  }

  if (filtrados.length === 0) {
    const qActivo = !!AppState.busquedaTexto;
    container.innerHTML = `
      <div style="text-align: center; padding: 48px 24px; color: var(--text-muted); display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <div style="width: 72px; height: 72px; border-radius: 50%; background: var(--surface-variant); display: flex; align-items: center; justify-content: center; margin-bottom: 16px;">
          <svg style="width: 36px; height: 36px; fill: #5A6B82;" viewBox="0 0 24 24"><path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zm0-12H5V6h14v2z"/></svg>
        </div>
        <p style="font-size: 16px; font-weight: 700; color: var(--text-main); margin: 0;">
          ${qActivo ? "No se encontraron coincidencias" : "No hay servicios registrados para este día"}
        </p>
        <p style="font-size: 13px; color: var(--text-muted); margin-top: 6px; max-width: 280px; line-height: 1.4;">
          ${qActivo ? "Prueba con otra letra, código o nombre de empleado." : "Sincroniza desde SharePoint o importa el archivo del cuadrante .xlsm."}
        </p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtrados.map(s => {
    const emp = mapaEmpleados.get(s.letra.toUpperCase());
    const infoServ = obtenerInfoServicio(s.servicio);
    const borderStyle = infoServ.border ? `border: 1px solid ${infoServ.border};` : '';
    const franjaCfg = obtenerColoresFranja(s.franja);
    const tieneNota = !!(s.nota && s.nota.trim());

    const nombreEmpleado = emp ? emp.nombreCompleto : 'Sin asignar';
    const numeroEmpleado = (emp && emp.numeroEmpleado) ? emp.numeroEmpleado : '---';

    // Insignias de líneas cubiertas (CE en NOCHE)
    const lineasBadges = (typeof parsearLineasMetro === 'function') ? parsearLineasMetro(s.lineas) : [];
    const lineasHtml = lineasBadges.map(l => `
      <span class="service-chip-linea" style="background-color: ${l.bg}; color: ${l.color};">${l.nombre}</span>
    `).join('');

    const esRefuerzo = !!s.esRefuerzoT3;
    const esCubierto = !!s.esCubiertoPorOtraLinea;

    return `
      <div class="service-card ${tieneNota ? 'has-note' : ''} ${esRefuerzo ? 'is-refuerzo' : ''} ${esCubierto ? 'is-cubierto' : ''}"
           onclick="abrirDetalleServicio('${s.letra}', '${s.servicio}', '${encodeURIComponent(s.nota || '')}', '${s.franja}')">
        
        <div class="service-card-left">
          <!-- 1. Izquierda: Recuadro del Servicio (con marco exterior según franja y caja oficial del servicio) -->
          <div class="service-badge-outer" style="background-color: ${franjaCfg.container}; border-color: ${franjaCfg.border};">
            <div class="service-badge-inner" style="background-color: ${infoServ.bg}; color: ${infoServ.color}; ${borderStyle}">
              <span>${(s.servicio && s.servicio !== '-') ? s.servicio : ''}</span>
            </div>
          </div>

          <!-- 2. Centro: Nombre del empleado arriba, y debajo número con icono y chip de letra -->
          <div class="service-card-info">
            <div class="service-card-nombre" title="${nombreEmpleado}">
              ${nombreEmpleado}
            </div>

            <div class="service-card-meta">
              <span class="service-card-matricula">
                <svg class="icon-badge" viewBox="0 0 24 24"><path d="M20 7h-5V4c0-1.1-.9-2-2-2h-2c-1.1 0-2 .9-2 2v3H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm-9-3h2v5h-2V4zm-1 10.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5zm7 3.5H7v-.5c0-1.33 2.67-2 4-2s4 .67 4 2v.5z"/></svg>
                Nº ${numeroEmpleado}
              </span>

              <span class="service-chip-letra" style="background-color: ${franjaCfg.chip};">
                ${s.letra}
              </span>

              ${esRefuerzo ? `<span class="service-chip-refuerzo">🌙 Refuerzo T3</span>` : ''}
              ${lineasHtml}
            </div>
          </div>
        </div>

        <!-- 3. Derecha: Botón circular con icono (i) si el servicio tiene una nota asociada -->
        ${tieneNota ? `
          <div class="service-card-nota-btn" title="Ver anotación corporativa" onclick="event.stopPropagation(); abrirDetalleServicio('${s.letra}', '${s.servicio}', '${encodeURIComponent(s.nota || '')}', '${s.franja}')">
            <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
          </div>
        ` : ''}

      </div>
    `;
  }).join('');
}

// =================== GESTIÓN DE EVENTOS DEL DÍA (100% ANDROID) ===================

let eventoDelDiaActual = null;

async function actualizarEventoDiaUI() {
  const capsule = document.getElementById('capsule-eventos-dia');
  const label = document.getElementById('label-evento-dia');
  const iconWrap = document.getElementById('capsule-evento-icon-wrap');
  if (!capsule || !label) return;

  const evento = await obtenerEventoPorFecha(AppState.fechaSeleccionada);
  eventoDelDiaActual = (evento && evento.descripcion && evento.descripcion.trim().length > 0) ? evento : null;

  // Limpiar clases temáticas previas
  capsule.classList.remove('theme-musica', 'theme-deporte', 'theme-alerta', 'theme-general', 'is-empty');

  if (eventoDelDiaActual) {
    const estilo = obtenerIconoYColorEvento(eventoDelDiaActual.descripcion);
    capsule.classList.add(estilo.claseCss);

    if (iconWrap) {
      iconWrap.innerHTML = estilo.svg;
    }

    const primeraLinea = eventoDelDiaActual.descripcion
      .split('\n')
      .map(l => l.trim())
      .find(l => l.length > 0) || eventoDelDiaActual.descripcion;

    label.textContent = primeraLinea;
  } else {
    capsule.classList.add('is-empty');
    if (iconWrap) {
      iconWrap.innerHTML = `
        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zm0-12H5V6h14v2z"/></svg>
      `;
    }
    label.textContent = 'No hay eventos para este día';
  }
}

async function sincronizarEventosDesdeServidor(forzar = false) {
  try {
    const total = await contarEventosTotal();
    if (total > 0 && !forzar) return;

    // 1. Descarga desde Supabase Storage
    try {
      const res = await fetch(SUPABASE_STORAGE_CONFIG.eventosUrl, { cache: 'no-cache' });
      if (res.ok) {
        const buf = await res.arrayBuffer();
        if (buf && buf.byteLength > 1000) {
          await parsearExcelEventos(buf);
          await actualizarEventoDiaUI();
          return;
        }
      }
    } catch (_) {}

    // 2. Fallback archivo local en web/data/eventos.xlsx
    try {
      const resLocal = await fetch('./data/eventos.xlsx');
      if (resLocal.ok) {
        const bufLocal = await resLocal.arrayBuffer();
        if (bufLocal && bufLocal.byteLength > 1000) {
          await parsearExcelEventos(bufLocal);
          await actualizarEventoDiaUI();
        }
      }
    } catch (_) {}
  } catch (e) {
    console.warn('Sincronización en segundo plano de eventos omitida:', e);
  }
}

function mostrarDetalleEventoModal(evento, fechaIso) {
  const modal = document.getElementById('modal-evento-detail');
  const body = document.getElementById('evento-sheet-body');
  const fechaEl = document.getElementById('evento-sheet-fecha-larga');
  const fuenteEl = document.getElementById('evento-sheet-fuente');
  const iconCircle = document.getElementById('evento-sheet-icon-circle');
  if (!modal || !body || !evento) return;

  const d = parsearFechaSegura(fechaIso) || new Date();
  const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const fechaLarga = `${dias[d.getDay()]}, ${d.getDate()} de ${meses[d.getMonth()]} de ${d.getFullYear()}`;

  if (fechaEl) fechaEl.textContent = fechaLarga;

  const estilo = obtenerIconoYColorEvento(evento.descripcion);
  if (iconCircle) {
    iconCircle.style.backgroundColor = estilo.segundoColor;
    iconCircle.style.color = estilo.primerColor;
    iconCircle.innerHTML = estilo.svg;
  }

  // Separar en bloques según saltos de línea dobles o sencillos
  const bloques = evento.descripcion
    .split(/\n\s*\n/)
    .map(b => b.trim())
    .filter(Boolean);

  body.innerHTML = bloques.map(bloque => {
    // Detectar hora (ej: 21:00h, 20:30 h, 21h)
    const matchHora = bloque.match(/\b(\d{1,2}(?::\d{2})?\s*h(?:oras)?)\b/i);
    const horaTexto = matchHora ? matchHora[1] : null;

    // Detectar recinto conocido
    let recinto = null;
    const bLower = bloque.toLowerCase();
    if (bLower.includes('palau sant jordi') || bLower.includes('palau sj')) {
      recinto = 'Palau Sant Jordi';
    } else if (bLower.includes('sant jordi club') || bLower.includes('st jordi club')) {
      recinto = 'Sant Jordi Club';
    } else if (bLower.includes('estadi olimpic') || bLower.includes('estadi olímpic')) {
      recinto = 'Estadi Olímpic Lluís Companys';
    } else if (bLower.includes('platja del bogatell')) {
      recinto = 'Platja del Bogatell';
    } else if (bLower.includes('pl. catalunya') || bLower.includes('plaza catalu')) {
      recinto = 'Plaza Cataluña';
    } else if (bLower.includes('espanya') || bLower.includes('españa')) {
      recinto = 'Plaza España';
    }

    return `
      <div class="evento-card-block">
        ${(horaTexto || recinto) ? `
          <div class="evento-chips-row">
            ${horaTexto ? `
              <span class="evento-chip-pill">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                ${horaTexto}
              </span>
            ` : ''}
            ${recinto ? `
              <span class="evento-chip-pill recinto">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M7 5h10v2h2V3c0-1.1-.9-2-2-2H7c-1.1 0-2 .9-2 2v4h2V5zm14 8v-2h-2V7h-2v4H7V7H5v4H3v2h2v6H3v2h18v-2h-2v-6h2zm-4 6H7v-6h10v6z"/></svg>
                ${recinto}
              </span>
            ` : ''}
          </div>
        ` : ''}
        <div class="evento-card-text">${bloque.replace(/\n/g, '<br>')}</div>
      </div>
    `;
  }).join('');

  if (fuenteEl) {
    fuenteEl.textContent = evento.mesOrigen
      ? `Fuente oficial: Hoja '${evento.mesOrigen}' (SharePoint CTO)`
      : `Fuente oficial: Calendario Eventos (SharePoint CTO)`;
  }

  modal.classList.add('active');
}

// =================== GESTIÓN DE PERSONAL (100% ANDROID) ===================

function obtenerFranjaDeLetraAndroid(letraRaw) {
  const l = (letraRaw || '').trim().toUpperCase();
  if (l.startsWith('N')) {
    return {
      badgeClass: 'badge-turno-noche',
      descripcionTurno: 'Turno Noche (L1)',
      chipColor: '#BE185D',
      chipBg: '#FCE7F3'
    };
  }
  if (l.startsWith('R') || l.startsWith('CR') || l.startsWith('SR')) {
    return {
      badgeClass: 'badge-turno-tarde',
      descripcionTurno: 'Turno Tarde (L1)',
      chipColor: '#0284C7',
      chipBg: '#E0F2FE'
    };
  }
  if (l.startsWith('T') || l.startsWith('ST')) {
    return {
      badgeClass: 'badge-turno-manana',
      descripcionTurno: 'Turno Mañana (L1)',
      chipColor: '#6D28D9',
      chipBg: '#EDE9FE'
    };
  }
  return {
    badgeClass: 'badge-turno-default',
    descripcionTurno: 'Turno General (L1)',
    chipColor: '#64748B',
    chipBg: '#F1F5F9'
  };
}

function obtenerInicialesNombre(nombreCompleto) {
  if (!nombreCompleto) return 'CTO';
  const partes = nombreCompleto.includes(',') ? nombreCompleto.split(',') : nombreCompleto.split(' ');
  if (nombreCompleto.includes(',')) {
    const ape = partes[0].trim();
    const nom = (partes[1] || '').trim();
    const iniApe = ape.charAt(0).toUpperCase();
    const iniNom = nom ? nom.charAt(0).toUpperCase() : '';
    return (iniNom + iniApe) || iniApe || 'M';
  }
  const palabras = nombreCompleto.trim().split(/\s+/);
  if (palabras.length === 1) return palabras[0].substring(0, 2).toUpperCase();
  return (palabras[0].charAt(0) + palabras[1].charAt(0)).toUpperCase();
}

async function abrirPantallaEmpleados() {
  mostrarPantalla('screen-empleados');

  if (!AppState.empleadosCenso || AppState.empleadosCenso.length === 0) {
    const cargados = await obtenerTodosLosEmpleados();
    if (cargados && cargados.length > 0) {
      AppState.empleadosCenso = cargados;
    } else if (typeof CENSO_EMPLEADOS_INICIAL_DEFAULT !== 'undefined') {
      AppState.empleadosCenso = [...CENSO_EMPLEADOS_INICIAL_DEFAULT];
      guardarEmpleadosLote(AppState.empleadosCenso).catch(() => {});
    }
  }

  renderizarListaEmpleados();

  // Sincronizar automáticamente el censo con Supabase al abrir la pantalla (idéntico a Android)
  try {
    const icon = document.getElementById('icon-sync-empleados');
    if (icon) icon.style.animation = 'spin 1s linear infinite';
    const empleadosSync = await supabase.sincronizarCensoEmpleados();
    if (empleadosSync && empleadosSync.length > 0) {
      AppState.empleadosCenso = empleadosSync;
      renderizarListaEmpleados();
    }
  } catch (e) {
    console.warn('Sync automático de empleados desde Supabase:', e);
  } finally {
    const icon = document.getElementById('icon-sync-empleados');
    if (icon) icon.style.animation = 'none';
  }
}

function renderizarListaEmpleados(filtroQuery = '') {
  const container = document.getElementById('lista-empleados-container');
  if (!container) return;

  if (!AppState.empleadosCenso || AppState.empleadosCenso.length === 0) {
    if (typeof CENSO_EMPLEADOS_INICIAL_DEFAULT !== 'undefined') {
      AppState.empleadosCenso = [...CENSO_EMPLEADOS_INICIAL_DEFAULT];
    }
  }

  let lista = [...(AppState.empleadosCenso || [])];

  // Orden alfabético estricto según las normas en castellano (exacto a Android EmpleadosViewModel)
  lista.sort((a, b) => {
    const nomA = (a.nombreCompleto || '').trim();
    const nomB = (b.nombreCompleto || '').trim();
    return nomA.localeCompare(nomB, 'es', { sensitivity: 'base' });
  });

  if (filtroQuery) {
    const q = filtroQuery.toLowerCase();
    lista = lista.filter(e =>
      (e.nombreCompleto && e.nombreCompleto.toLowerCase().includes(q)) ||
      (e.numeroEmpleado && e.numeroEmpleado.toLowerCase().includes(q)) ||
      (e.letra && e.letra.toLowerCase().includes(q)) ||
      (e.telefono && e.telefono.includes(q))
    );
  }

  if (lista.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 48px 24px; color: var(--text-muted);">
        <p style="font-size: 15px; font-weight: 700; color: var(--text-main);">No se encontraron empleados</p>
        <p style="font-size: 13px; margin-top: 4px;">Comprueba el término de búsqueda o sincroniza con Supabase.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = lista.map(emp => {
    const franjaInfo = obtenerFranjaDeLetraAndroid(emp.letra);
    const letraTexto = (emp.letra && emp.letra.trim().length > 0) ? emp.letra.trim() : '—';
    const tel = (emp.telefono && emp.telefono.trim().length > 0)
      ? emp.telefono.trim()
      : (typeof obtenerTelefonoEmpleado === 'function' ? obtenerTelefonoEmpleado(emp.numeroEmpleado) : '');

    return `
      <div class="emp-card-android" onclick="abrirDetalleEmpleadoPorNumero('${emp.numeroEmpleado}')" role="button" tabindex="0">
        <div class="emp-card-left">
          <!-- Badge cuadrado de 48px con esquinas de 12px idéntico a Android Surface -->
          <div class="emp-card-badge ${franjaInfo.badgeClass}">
            ${letraTexto}
          </div>

          <!-- Columna con Nombre y fila con matrícula y teléfono azul -->
          <div class="emp-card-content">
            <div class="emp-card-nombre">${emp.nombreCompleto}</div>
            <div class="emp-card-meta">
              <span class="emp-meta-item">
                <svg width="13" height="13" viewBox="0 0 24 24"><path fill="currentColor" d="M20 7h-4V5l-2-2h-4L8 5v2H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zM10 5h4v2h-4V5zm10 15H4V9h16v11z"/></svg>
                Nº ${emp.numeroEmpleado || '---'}
              </span>
              ${tel ? `
                <span class="emp-meta-item meta-phone">
                  <svg width="12" height="12" viewBox="0 0 24 24"><path fill="currentColor" d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/></svg>
                  ${tel}
                </span>
              ` : ''}
            </div>
          </div>
        </div>

        <!-- Indicador de flecha chevron idéntico a Android ArrowForwardIos (estricto 14px) -->
        <svg class="emp-card-chevron" width="14" height="14" viewBox="0 0 24 24">
          <path fill="currentColor" d="M6.23 20.23l1.77 1.77L18 12 8 2 6.23 3.77 14.46 12z"/>
        </svg>
      </div>
    `;
  }).join('');
}

window.abrirDetalleEmpleadoPorNumero = function(num) {
  const emp = AppState.empleadosCenso.find(e => String(e.numeroEmpleado).trim() === String(num).trim());
  if (emp) {
    abrirDetalleEmpleado(emp);
  }
};

window.abrirDetalleEmpleadoPorLetra = function(letra) {
  const emp = AppState.empleadosCenso.find(e => e.letra?.toUpperCase() === letra?.toUpperCase());
  if (emp) {
    abrirDetalleEmpleado(emp);
  } else {
    abrirDetalleEmpleado({
      letra: letra,
      nombreCompleto: `Turno ${letra}`,
      numeroEmpleado: '---',
      telefono: '',
      email: ''
    });
  }
};

async function abrirDetalleEmpleado(empleado) {
  AppState.empleadoDetalleActual = empleado;

  const modal = document.getElementById('modal-empleado-detail');
  if (!modal) return;

  // Restablecer vistas internas: ficha activa y calendario oculto
  document.getElementById('emp-view-ficha')?.classList.add('active');
  const viewFicha = document.getElementById('emp-view-ficha');
  if (viewFicha) viewFicha.style.display = 'block';

  const viewCal = document.getElementById('emp-view-calendario');
  if (viewCal) viewCal.style.display = 'none';

  // Ocultar sección de cómputo anual inicialmente
  const collapseComputo = document.getElementById('emp-computo-collapse');
  if (collapseComputo) collapseComputo.style.display = 'none';

  const franjaInfo = obtenerFranjaDeLetraAndroid(empleado.letra);

  // 1. Hero Header
  // Avatar central
  const avatarCircle = document.getElementById('emp-detail-avatar-circle');
  if (avatarCircle) {
    if (empleado.fotoUri && empleado.fotoUri.trim().length > 0) {
      avatarCircle.innerHTML = `<img src="${empleado.fotoUri}" alt="${empleado.nombreCompleto}">`;
    } else {
      const iniciales = obtenerInicialesNombre(empleado.nombreCompleto);
      avatarCircle.innerHTML = `<span style="font-size: 32px; font-weight: 800; color: #1E293B;">${iniciales}</span>`;
    }
  }

  // Badge de Turno superpuesto en el avatar
  const badgeTurno = document.getElementById('emp-detail-turno-badge');
  if (badgeTurno) {
    badgeTurno.textContent = (empleado.letra && empleado.letra.trim().length > 0) ? empleado.letra : '—';
  }

  // Nombre Completo
  const nombreEl = document.getElementById('emp-detail-nombre');
  if (nombreEl) {
    nombreEl.textContent = empleado.nombreCompleto || 'Sin nombre';
  }

  // Chip de Turno (icono tren + texto)
  const turnoLabel = document.getElementById('emp-detail-turno-label');
  if (turnoLabel) {
    turnoLabel.textContent = franjaInfo.descripcionTurno;
  }

  // 2. Tarjeta de Información de Contacto (3 Filas)
  // Fila 1: Número de Empleado
  const numMatricula = String(empleado.numeroEmpleado || '---').trim();
  const elMatricula = document.getElementById('emp-detail-matricula');
  if (elMatricula) elMatricula.textContent = numMatricula;

  // Fila 2: Teléfono de Contacto
  const telNum = (empleado.telefono || '').trim();
  const elTel = document.getElementById('emp-detail-telefono');
  const btnCall = document.getElementById('btn-emp-call');
  if (elTel) {
    elTel.textContent = telNum || 'Sin teléfono asignado';
    elTel.style.color = telNum ? 'var(--text-main)' : 'var(--text-muted)';
  }
  if (btnCall) {
    if (telNum) {
      btnCall.href = `tel:${telNum}`;
      btnCall.style.display = 'flex';
    } else {
      btnCall.style.display = 'none';
    }
  }

  // Fila 3: Correo Electrónico (con fallback oficial para Marta Arasnaz si faltara)
  let emailVal = (empleado.email || '').trim();
  if (!emailVal && numMatricula === '2010649') {
    emailVal = 'maransanz@tmb.cat';
  }
  const elEmail = document.getElementById('emp-detail-email');
  const btnEmail = document.getElementById('btn-emp-email');
  if (elEmail) {
    elEmail.textContent = emailVal || 'Sin correo asignado';
    elEmail.style.color = emailVal ? 'var(--text-main)' : 'var(--text-muted)';
  }
  if (btnEmail) {
    if (emailVal) {
      btnEmail.href = `mailto:${emailVal}`;
      btnEmail.style.display = 'flex';
    } else {
      btnEmail.style.display = 'none';
    }
  }

  // 3. Pre-renderizar Cómputo Anual
  await renderizarComputoAnualDesplegable(empleado.letra);

  // 4. Configurar botones inferiores
  const btnDelete = document.getElementById('btn-emp-delete');
  const btnEdit = document.getElementById('btn-emp-edit');
  const btnEditLabel = document.getElementById('btn-emp-edit-label');

  const esAdmin = AppState.usuarioActual?.rol === 'ADMIN';
  const esMiPropioPerfil = String(empleado.numeroEmpleado || '').trim() === String(AppState.usuarioActual?.numeroEmpleado || '').trim();

  if (btnDelete) {
    btnDelete.style.display = esAdmin ? 'flex' : 'none';
  }
  if (btnEditLabel) {
    btnEditLabel.textContent = esAdmin ? 'Editar' : 'Cambiar mi Foto';
  }
  if (btnEdit) {
    btnEdit.style.display = (esAdmin || esMiPropioPerfil) ? 'flex' : 'none';
  }

  modal.classList.add('active');
}

async function renderizarComputoAnualDesplegable(letra) {
  const container = document.getElementById('emp-computo-items');
  if (!container) return;

  if (!letra) {
    container.innerHTML = `
      <div style="text-align: center; padding: 12px; color: var(--text-muted); font-size: 13px;">
        Sin turno asignado para calcular cómputos.
      </div>
    `;
    return;
  }

  const serviciosAno = await obtenerServiciosPorLetra(letra);

  const conteo = {};
  for (const s of serviciosAno) {
    const cod = (s.servicio || '').trim().toUpperCase();
    if (cod) {
      conteo[cod] = (conteo[cod] || 0) + 1;
    }
  }

  const conceptos = [
    { abrev: 'V', concepto: 'Contingente Vacaciones', valor: conteo['V'] || 0 },
    { abrev: 'RJ', concepto: 'RJ pendientes 2026', valor: conteo['RJ'] || 0 },
    { abrev: 'D', concepto: 'DCOM (Descansos)', valor: (conteo['D'] || 0) + (conteo['DA'] || 0) },
    { abrev: 'F', concepto: 'FEST (Festivos)', valor: (conteo['F'] || 0) + (conteo['FA'] || 0) },
    { abrev: 'CC', concepto: 'Panel Circulación (CC / CC1)', valor: (conteo['CC'] || 0) + (conteo['CC1'] || 0) },
    { abrev: 'CE', concepto: 'Panel Estaciones (CE / CE1)', valor: (conteo['CE'] || 0) + (conteo['CE1'] || 0) },
    { abrev: 'TL', concepto: 'Titular de Línea (TL / TL1)', valor: (conteo['TL'] || 0) + (conteo['TL1'] || 0) },
    { abrev: 'FR', concepto: 'Formación (FR / FI)', valor: (conteo['FR'] || 0) + (conteo['FI'] || 0) },
    { abrev: 'E', concepto: 'Baja (Enfermedad / Accidente)', valor: (conteo['E'] || 0) + (conteo['A'] || 0) }
  ];

  container.innerHTML = conceptos.map(item => {
    const info = obtenerInfoServicio(item.abrev);
    const border = info.border ? `border: 1px solid ${info.border};` : '';

    return `
      <div class="emp-computo-row">
        <div class="emp-computo-row-left">
          <div class="emp-computo-badge" style="background-color: ${info.bg}; color: ${info.color}; ${border}">
            ${item.abrev}
          </div>
          <span class="emp-computo-concepto">${item.concepto}</span>
        </div>
        <span class="emp-computo-valor">${item.valor}</span>
      </div>
    `;
  }).join('');
}

function renderizarChipsMeses() {
  const container = document.getElementById('cal-month-chips-bar');
  if (!container || !Array.isArray(MESES_CALENDARIO)) return;

  container.innerHTML = MESES_CALENDARIO.map((item, idx) => {
    const esActivo = idx === AppState.mesCalendarioPersonalIndex;
    return `
      <button class="cal-month-chip ${esActivo ? 'active' : ''}" data-idx="${idx}">
        ${item.chipTexto}
      </button>
    `;
  }).join('');

  container.querySelectorAll('.cal-month-chip').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const idx = parseInt(e.currentTarget.getAttribute('data-idx'), 10);
      if (!isNaN(idx)) {
        AppState.mesCalendarioPersonalIndex = idx;
        actualizarChipsMesesActivo();
        await renderizarMesCalendarioPersonal();
      }
    });
  });

  actualizarChipsMesesActivo();
}

function actualizarChipsMesesActivo() {
  const container = document.getElementById('cal-month-chips-bar');
  if (!container) return;

  const chips = container.querySelectorAll('.cal-month-chip');
  chips.forEach((chip, idx) => {
    if (idx === AppState.mesCalendarioPersonalIndex) {
      chip.classList.add('active');
      chip.scrollIntoView({ inline: 'center', behavior: 'smooth', block: 'nearest' });
    } else {
      chip.classList.remove('active');
    }
  });

  // Habilitar / deshabilitar flechas
  const btnPrev = document.getElementById('btn-cal-prev-month');
  const btnNext = document.getElementById('btn-cal-next-month');
  if (btnPrev) btnPrev.disabled = (AppState.mesCalendarioPersonalIndex <= 0);
  if (btnNext) btnNext.disabled = (AppState.mesCalendarioPersonalIndex >= MESES_CALENDARIO.length - 1);
}

async function renderizarMesCalendarioPersonal() {
  const emp = AppState.empleadoDetalleActual;
  if (!emp || !emp.letra) return;

  const mesItem = (Array.isArray(MESES_CALENDARIO) && MESES_CALENDARIO[AppState.mesCalendarioPersonalIndex])
    ? MESES_CALENDARIO[AppState.mesCalendarioPersonalIndex]
    : { mesNumero: 10, anio: 2026, nombreMes: "OCTUBRE", tituloCompleto: "OCTUBRE 2026" };

  const anio = mesItem.anio;
  const mesNum = mesItem.mesNumero;

  // Actualizar textos de cabecera
  const heroYear = document.getElementById('cal-hero-year');
  if (heroYear) heroYear.textContent = anio;

  const navTitle = document.getElementById('cal-nav-month-title');
  if (navTitle) navTitle.textContent = mesItem.tituloCompleto;

  const cardHeaderTitle = document.getElementById('mes-card-header-title');
  if (cardHeaderTitle) cardHeaderTitle.textContent = mesItem.nombreMes;

  actualizarChipsMesesActivo();

  const grid = document.getElementById('mes-cuadricula-celdas');
  if (!grid) return;

  // Cargar servicios del empleado desde IndexedDB
  const serviciosAno = await obtenerServiciosPorLetra(emp.letra);
  const mapaServicios = new Map(serviciosAno.map(s => [s.fecha, s]));
  AppState.serviciosCalendarioCache = mapaServicios;

  const primerDia = new Date(anio, mesNum - 1, 1);
  const diasEnMes = new Date(anio, mesNum, 0).getDate();

  // Día de la semana en formato Lunes=0..Domingo=6
  let offsetInicio = primerDia.getDay() - 1;
  if (offsetInicio === -1) offsetInicio = 6;

  // Exactamente 6 filas x 7 columnas = 42 celdas como en MesCuadradoCard de Android
  const totalCeldasMatriz = 42;
  const totalDiasMes = offsetInicio + diasEnMes;

  let htmlCeldas = '';

  for (let i = 0; i < totalCeldasMatriz; i++) {
    if (i < offsetInicio || i >= totalDiasMes) {
      htmlCeldas += '<div class="mes-celda is-outside"></div>';
    } else {
      const dia = i - offsetInicio + 1;
      const fechaIso = `${anio}-${String(mesNum).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
      const servObj = mapaServicios.get(fechaIso);
      const codServicio = (servObj?.servicio || '').trim();
      const visual = obtenerInfoServicio(codServicio);

      const esHoy = (fechaIso === AppState.fechaHoyIsoCalendario);
      const esSeleccionado = (fechaIso === AppState.fechaCalendarioPersonalSeleccionada);

      const tieneServicio = codServicio && codServicio !== '-';
      let srvHtml = '';
      if (tieneServicio) {
        const borderStyle = visual.border ? `border: 0.5px solid ${visual.border};` : '';
        srvHtml = `<div class="mes-dia-srv-box" style="background-color: ${visual.bg}; color: ${visual.color}; ${borderStyle}">${codServicio}</div>`;
      } else {
        srvHtml = `<div class="mes-dia-srv-box" style="visibility: hidden;">-</div>`;
      }

      const numHtml = esHoy
        ? `<div class="mes-dia-num-box"><span class="mes-dia-num-today">${dia}</span></div>`
        : `<div class="mes-dia-num-box"><span class="mes-dia-num">${dia}</span></div>`;

      htmlCeldas += `
        <div class="mes-celda is-day ${esHoy ? 'is-today' : ''} ${esSeleccionado ? 'is-selected' : ''}" data-fecha="${fechaIso}">
          ${numHtml}
          ${srvHtml}
        </div>
      `;
    }
  }

  grid.innerHTML = htmlCeldas;

  // Asignar listeners de selección interactiva a cada celda
  grid.querySelectorAll('.mes-celda.is-day').forEach(celda => {
    celda.addEventListener('click', (e) => {
      const fecha = e.currentTarget.getAttribute('data-fecha');
      if (AppState.fechaCalendarioPersonalSeleccionada === fecha) {
        AppState.fechaCalendarioPersonalSeleccionada = null;
      } else {
        AppState.fechaCalendarioPersonalSeleccionada = fecha;
      }

      // Actualizar selección visual de bordes
      grid.querySelectorAll('.mes-celda.is-day').forEach(c => {
        if (c.getAttribute('data-fecha') === AppState.fechaCalendarioPersonalSeleccionada) {
          c.classList.add('is-selected');
        } else {
          c.classList.remove('is-selected');
        }
      });

      renderizarDetalleDiaCalendario(AppState.serviciosCalendarioCache);
    });
  });

  renderizarDetalleDiaCalendario(mapaServicios);
}

function renderizarDetalleDiaCalendario(mapaServicios) {
  const container = document.getElementById('cal-dia-detalle-container');
  if (!container) return;

  const fechaIso = AppState.fechaCalendarioPersonalSeleccionada;
  if (!fechaIso) {
    container.innerHTML = '';
    return;
  }

  const servObj = (mapaServicios && mapaServicios.get) ? mapaServicios.get(fechaIso) : null;
  const codigoServicio = (servObj?.servicio || '').trim();
  const visual = obtenerInfoServicio(codigoServicio);
  const fechaTexto = formatearFechaCastellano(fechaIso);

  const codigoLimpio = codigoServicio.toUpperCase();
  const esDiaSinServicio = ['D', 'F', 'RJ', 'V', 'FA', 'DA', 'P', 'E', 'A', 'AS', '-', ''].includes(codigoLimpio);

  let franjaHtml = '';
  if (!esDiaSinServicio && servObj?.franja && servObj.franja.trim().length > 0) {
    franjaHtml = `
      <div class="cal-dia-franja-row">
        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
        <span>Franja: ${servObj.franja}</span>
      </div>
    `;
  }

  let notaMostrar = '';
  if (servObj?.nota && servObj.nota.trim().length > 0) {
    notaMostrar = servObj.nota.trim();
  } else if (fechaIso.startsWith('2027-01-') && parseInt(fechaIso.slice(8), 10) > 10) {
    notaMostrar = 'Cuadrante oficial publicado en SharePoint con servicios hasta el 10/01/2027.';
  }

  const borderStyle = visual.border ? `border: 1px solid ${visual.border};` : '';

  container.innerHTML = `
    <div class="cal-dia-detalle-card">
      <div class="cal-dia-badge-srv" style="background-color: ${visual.bg}; color: ${visual.color}; ${borderStyle}">
        ${codigoServicio || '—'}
      </div>
      <div class="cal-dia-info-col">
        <div class="cal-dia-fecha-txt">${fechaTexto}</div>
        <div class="cal-dia-desc-txt">${visual.desc}</div>
        ${franjaHtml}
        ${notaMostrar ? `<div class="cal-dia-nota-txt">${servObj?.nota ? 'Nota: ' + notaMostrar : notaMostrar}</div>` : ''}
      </div>
    </div>
  `;
}

function formatearFechaCastellano(fechaIso) {
  try {
    const d = parsearFechaSegura(fechaIso);
    if (!d || isNaN(d.getTime())) return fechaIso;

    const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

    const diaSemana = dias[d.getDay()];
    const diaMes = d.getDate();
    const mes = meses[d.getMonth()];
    const anio = d.getFullYear();

    return `${diaSemana}, ${diaMes} de ${mes} de ${anio}`;
  } catch (_) {
    return fechaIso;
  }
}

function abrirModalEdicionEmpleado(empleado) {
  const modal = document.getElementById('modal-empleado-edit');
  const title = document.getElementById('modal-emp-edit-title');
  const numInput = document.getElementById('edit-emp-numero');
  const nomInput = document.getElementById('edit-emp-nombre');
  const letraInput = document.getElementById('edit-emp-letra');
  const telInput = document.getElementById('edit-emp-telefono');
  const emailInput = document.getElementById('edit-emp-email');
  const fotoInput = document.getElementById('edit-emp-foto');

  if (!modal) return;

  if (empleado) {
    if (title) title.textContent = 'Editar Empleado';
    if (numInput) {
      numInput.value = empleado.numeroEmpleado || '';
      numInput.setAttribute('readonly', 'readonly');
    }
    if (nomInput) nomInput.value = empleado.nombreCompleto || '';
    if (letraInput) letraInput.value = empleado.letra || '';
    if (telInput) telInput.value = empleado.telefono || '';
    if (emailInput) emailInput.value = empleado.email || (empleado.numeroEmpleado === '2010649' ? 'maransanz@tmb.cat' : '');
    if (fotoInput) fotoInput.value = empleado.fotoUri || '';
  } else {
    if (title) title.textContent = 'Añadir Asignación / Empleado';
    if (numInput) {
      numInput.value = '';
      numInput.removeAttribute('readonly');
    }
    if (nomInput) nomInput.value = '';
    if (letraInput) letraInput.value = '';
    if (telInput) telInput.value = '';
    if (emailInput) emailInput.value = '';
    if (fotoInput) fotoInput.value = '';
  }

  modal.classList.add('active');
}

function copiarTextoPortapapeles(etiqueta, texto) {
  if (!texto || texto === '---') {
    mostrarToastAviso(`No hay ${etiqueta.toLowerCase()} para copiar.`);
    return;
  }

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(texto).then(() => {
      mostrarToastAviso(`${etiqueta} copiado al portapapeles`);
    }).catch(() => {
      copiarFallback(etiqueta, texto);
    });
  } else {
    copiarFallback(etiqueta, texto);
  }
}

function copiarFallback(etiqueta, texto) {
  const ta = document.createElement('textarea');
  ta.value = texto;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try {
    document.execCommand('copy');
    mostrarToastAviso(`${etiqueta} copiado al portapapeles`);
  } catch (_) {
    mostrarToastAviso(`Copia manual: ${texto}`);
  }
  document.body.removeChild(ta);
}

// =================== DETALLE DE SERVICIO MODAL ===================

window.abrirDetalleServicio = function(letra, servicio, notaEncoded, franjaRaw) {
  const nota = decodeURIComponent(notaEncoded);
  const infoServ = obtenerInfoServicio(servicio);
  const emp = AppState.empleadosCenso.find(e => e.letra?.toUpperCase() === letra?.toUpperCase());
  
  // Buscar franja si no viene en parámetro
  let franja = franjaRaw;
  if (!franja) {
    const sFound = AppState.serviciosDelDia.find(s => s.letra?.toUpperCase() === letra?.toUpperCase());
    franja = sFound ? sFound.franja : '';
  }
  const franjaCfg = obtenerColoresFranja(franja);
  const borderStyle = infoServ.border ? `border: 1px solid ${infoServ.border};` : 'border: 1px solid #F6C768;';

  const modal = document.getElementById('modal-service-detail');
  const body = document.getElementById('service-detail-body');
  if (!modal || !body) return;

  body.innerHTML = `
    <!-- Cabecera del BottomSheet -->
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="width: 10px; height: 10px; border-radius: 50%; background-color: ${franjaCfg.chip}; display: inline-block;"></span>
        <h3 style="font-size: 18px; font-weight: 800; color: var(--text-main); margin: 0;">Detalle del Servicio</h3>
      </div>
      <button class="icon-btn" onclick="document.getElementById('modal-service-detail').classList.remove('active')" title="Cerrar">
        <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
      </button>
    </div>

    <!-- Tarjeta Principal con Información del Servicio -->
    <div style="background: var(--surface-variant); border-radius: 16px; padding: 16px; margin-bottom: 16px;">
      
      <!-- Fila Superior: Letra y Servicio Asignado -->
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
          <span style="font-size: 11px; color: var(--text-muted); font-weight: 600; display: block; margin-bottom: 4px;">Letra</span>
          <span class="service-chip-letra" style="background-color: ${franjaCfg.chip}; font-size: 14px; padding: 3px 12px; border-radius: 6px;">
            ${letra}
          </span>
        </div>

        <div style="text-align: right;">
          <span style="font-size: 11px; color: var(--text-muted); font-weight: 600; display: block; margin-bottom: 4px;">Servicio Asignado</span>
          <div style="display: inline-flex; align-items: center; gap: 6px;">
            <span style="display: inline-block; padding: 2px 8px; border-radius: 8px; font-weight: 800; font-size: 15px; background-color: ${infoServ.bg}; color: ${infoServ.color}; ${borderStyle}">
              ${(servicio && servicio !== '-') ? servicio : '—'}
            </span>
            <span style="font-size: 14px; font-weight: 700; color: var(--text-main);">${infoServ.desc}</span>
          </div>
        </div>
      </div>

      <hr style="border: none; border-top: 1px solid var(--border); margin: 12px 0;">

      <!-- Fila Intermedia: Franja Horaria y Fecha -->
      <div style="display: flex; justify-content: space-between; align-items: center; font-size: 13px; font-weight: 600; color: var(--text-main);">
        <div style="display: flex; align-items: center; gap: 6px;">
          <svg style="width: 16px; height: 16px; fill: var(--text-muted);" viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
          <span>${franjaCfg.nombre} (${franjaCfg.horario})</span>
        </div>
        <div style="display: flex; align-items: center; gap: 6px;">
          <svg style="width: 16px; height: 16px; fill: var(--text-muted);" viewBox="0 0 24 24"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/></svg>
          <span>${formatearFechaVisual(AppState.fechaSeleccionada)}</span>
        </div>
      </div>

      <hr style="border: none; border-top: 1px solid var(--border); margin: 12px 0;">

      <!-- Fila Inferior: Empleado asignado -->
      <div style="display: flex; align-items: center; gap: 12px;">
        <div style="width: 36px; height: 36px; border-radius: 50%; background: #FFFFFF; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px; color: var(--primary); border: 1px solid var(--border); overflow: hidden; flex-shrink: 0;">
          ${emp && emp.fotoUri ? `<img src="${emp.fotoUri}" style="width:100%;height:100%;object-fit:cover;">` : `<svg viewBox="0 0 24 24" style="width:20px;height:20px;fill:var(--primary);"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>`}
        </div>
        <div style="flex: 1; min-width: 0;">
          <div style="font-size: 15px; font-weight: 700; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            ${emp ? emp.nombreCompleto : 'Sin empleado asignado'}
          </div>
          <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
            Nº ${emp && emp.numeroEmpleado ? emp.numeroEmpleado : '---'}
            ${emp && emp.telefono ? ` &bull; <a href="tel:${emp.telefono}" style="color: var(--primary); font-weight: 700; text-decoration: none;">📞 ${emp.telefono}</a>` : ''}
          </div>
        </div>
      </div>
    </div>

    <!-- Sección destacada de Anotación Corporativa si existe nota -->
    ${nota ? `
      <div style="background: #FFFBEB; border: 1.5px solid #FDE68A; border-radius: 16px; padding: 16px; margin-bottom: 16px;">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
          <svg style="width: 22px; height: 22px; fill: #D97706;" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
          <span style="font-size: 12px; font-weight: 800; color: #92400E; letter-spacing: 0.8px; text-transform: uppercase;">Anotación Corporativa</span>
        </div>
        <div style="font-size: 15px; color: #451A03; font-weight: 500; line-height: 1.5; white-space: pre-line;">
          ${nota}
        </div>
      </div>
    ` : `
      <div style="background: var(--surface-variant); border-radius: 12px; padding: 12px; margin-bottom: 16px; text-align: center; color: var(--text-muted); font-size: 12px;">
        Sin comentarios ni notas adicionales para este servicio.
      </div>
    `}
  `;

  modal.classList.add('active');
};

document.getElementById('btn-close-service-detail')?.addEventListener('click', () => {
  document.getElementById('modal-service-detail')?.classList.remove('active');
});

// =================== COMPROBACIÓN DE CAMBIOS Y MODAL DE 5 DÍAS ===================

async function comprobarCambiosAlIniciar(forzarAviso = false) {
  const u = AppState.usuarioActual;
  if (!u) return;

  // 1. Sincronizar automáticamente historial de cambios desde Supabase
  const cambiosSupabase = await supabase.sincronizarHistorialCambiosDesdeSupabase();

  // 2. Si hay cambios en Supabase, actualizar de inmediato los registros en IndexedDB
  if (cambiosSupabase && cambiosSupabase.length > 0) {
    for (const c of cambiosSupabase) {
      if (c.fechaServicio && c.letra && c.servicioNuevo) {
        await guardarServiciosLote([{
          fecha: c.fechaServicio,
          letra: c.letra,
          franja: LETRAS_POR_FRANJA.MANANA.includes(c.letra) ? 'MAÑANA' : (LETRAS_POR_FRANJA.TARDE.includes(c.letra) ? 'TARDE' : 'NOCHE'),
          servicio: c.servicioNuevo,
          nota: c.notaNueva || '',
          lineas: c.lineasNueva || ''
        }]);
      }
    }
  }

  // 3. Notificaciones según rol
  if (u.rol === 'ADMIN') {
    if (cambiosSupabase.length > 0) {
      mostrarToastAviso(`¡Se detectaron ${cambiosSupabase.length} cambios en el cuadrante!`);
    } else if (forzarAviso) {
      mostrarToastAviso('El Calendario se encuentra actualizado');
    }
    return;
  }

  // Empleado normal: comprobar próximos 5 días (desde hoy incluido)
  if (!u.letra) {
    if (forzarAviso) mostrarToastAviso('El Calendario se encuentra actualizado');
    return;
  }

  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);

  const fin5Dias = new Date(hoy);
  fin5Dias.setDate(fin5Dias.getDate() + 4);

  const noVistos = await obtenerCambiosNoVistosPorLetra(u.letra);

  const dentroDeRango = (noVistos || []).filter(c => {
    const d = parsearFechaSegura(c.fechaServicio);
    if (!d) return false;
    return d >= hoy && d <= fin5Dias;
  }).sort((a, b) => {
    const da = parsearFechaSegura(a.fechaServicio) || 0;
    const db = parsearFechaSegura(b.fechaServicio) || 0;
    return da - db;
  });

  if (dentroDeRango.length > 0) {
    mostrarModalNotificacionCambios(u, dentroDeRango);
  } else {
    // Si no hay variaciones pendientes, mostrar el aviso oficial idéntico a Android
    mostrarToastAviso('El Calendario se encuentra actualizado');
  }
}

function mostrarModalNotificacionCambios(usuario, cambios) {
  const modal = document.getElementById('modal-notificacion-cambios');
  const container = document.getElementById('notificacion-cambios-cards');
  if (!modal || !container) return;

  const primerNombre = usuario.nombreCompleto.includes(',')
    ? usuario.nombreCompleto.split(',')[1].trim().split(' ')[0]
    : usuario.nombreCompleto.split(' ')[0];

  document.getElementById('notif-saludo-nombre').textContent = `¡Hola, ${primerNombre}!`;
  document.getElementById('notif-subtitulo').textContent = cambios.length === 1
    ? 'Se ha modificado 1 servicio en tus próximos 5 días.'
    : `Se han modificado ${cambios.length} servicios en tus próximos 5 días.`;

  container.innerHTML = cambios.map(c => {
    const infoNuevo = obtenerInfoServicio(c.servicioNuevo);
    const borderStyle = infoNuevo.border ? `border: 1px solid ${infoNuevo.border};` : '';

    return `
      <div class="diff-card">
        <div class="diff-card-header">
          <svg style="width:14px;height:14px;fill:var(--primary);" viewBox="0 0 24 24"><path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10z"/></svg>
          <span>${formatearFechaVisual(c.fechaServicio)}</span>
        </div>
        <div class="diff-row">
          <div class="diff-pill-prev">
            <span style="font-size: 10px; display: block; opacity: 0.7;">Anterior</span>
            ${c.servicioAnterior || '(Vacío)'}
          </div>
          <span class="diff-arrow">&rarr;</span>
          <div class="diff-pill-new" style="background-color: ${infoNuevo.bg}; color: ${infoNuevo.color}; ${borderStyle}">
            <span style="font-size: 10px; display: block; opacity: 0.8;">Nuevo</span>
            ${c.servicioNuevo || 'Sin asignar'}
          </div>
        </div>
        ${infoNuevo.desc ? `<p style="font-size: 12px; font-weight: 600; margin-top: 6px; color: var(--text-muted);">&bull; ${infoNuevo.desc}</p>` : ''}
        ${c.notaNueva ? `<p style="font-size: 11px; color: #B45309; margin-top: 4px; font-style: italic;">Nota: "${c.notaNueva}"</p>` : ''}
      </div>
    `;
  }).join('');

  // Botón "Ver en Calendario"
  const btnVerCalendario = document.getElementById('btn-notif-ver-calendario');
  if (btnVerCalendario) {
    btnVerCalendario.onclick = async () => {
      const primerDia = cambios[0].fechaServicio;
      const ids = cambios.map(c => c.id).filter(id => Boolean(id));
      await marcarCambiosComoVistos(ids);

      modal.classList.remove('active');
      AppState.fechaSeleccionada = formatearFechaIso(parsearFechaSegura(primerDia));
      renderizarFechaActual();
      cargarServiciosDelDia();
    };
  }

  modal.classList.add('active');
}

// =================== TOAST FLOTANTE ===================

let toastTimer = null;
function mostrarToastAviso(mensaje, duracionMs = 3500) {
  const toast = document.getElementById('toast-aviso');
  const txt = document.getElementById('toast-aviso-texto');
  if (!toast || !txt) return;

  txt.textContent = mensaje;
  toast.style.display = 'flex';

  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.style.display = 'none';
  }, duracionMs);
}
