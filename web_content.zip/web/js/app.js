/**
 * Lógica principal de la aplicación PWA para iPhone y navegadores web.
 * Paridad 100% fiel con la app Android oficial de Metro CTO 2026.
 */

// Estado global de la aplicación
const AppState = {
  usuarioActual: null,
  fechaSeleccionada: formatearFechaIso(new Date()),
  franjaSeleccionada: 'TODAS',
  busquedaTexto: '',
  serviciosDelDia: [],
  empleadosCenso: [],
  empleadoDetalleActual: null,
  mesCalendarioPersonal: new Date().getMonth(), // 0 = Enero, 11 = Diciembre
  anoCalendarioPersonal: 2026
};

// =================== UTILIDADES DE FECHA ===================

function formatearFechaIso(date) {
  const d = new Date(date);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function parsearFechaSegura(fechaRaw) {
  if (!fechaRaw) return null;
  const s = String(fechaRaw).trim();
  if (s.match(/^\d{4}-\d{2}-\d{2}$/)) {
    return new Date(s + 'T00:00:00');
  }
  if (s.match(/^\d{2}-\d{2}-\d{4}$/)) {
    const p = s.split('-');
    return new Date(`${p[2]}-${p[1]}-${p[0]}T00:00:00`);
  }
  if (s.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
    const p = s.split('/');
    return new Date(`${p[2]}-${p[1]}-${p[0]}T00:00:00`);
  }
  return null;
}

function formatearFechaVisual(fechaIso) {
  const d = parsearFechaSegura(fechaIso);
  if (!d || isNaN(d.getTime())) return fechaIso;

  const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

  const diaSemana = dias[d.getDay()];
  const diaMes = d.getDate();
  const mes = meses[d.getMonth()];
  const ano = d.getFullYear();

  return `${diaSemana}, ${diaMes} de ${mes} de ${ano}`;
}

// =================== INICIALIZACIÓN ===================

document.addEventListener('DOMContentLoaded', async () => {
  // Registrar Service Worker para soporte offline
  if ('serviceWorker' in navigator) {
    try {
      await navigator.serviceWorker.register('./sw.js');
    } catch (_) {}
  }

  // Comprobar si está en iPhone y mostrar banner de instalación si no es standalone
  comprobarBannerInstalacionIphone();

  // Configurar listeners de la interfaz
  configurarEventosUI();

  // Comprobar sesión existente
  await inicializarSesion();
});

function comprobarBannerInstalacionIphone() {
  const esIos = /iphone|ipad|ipod/i.test(window.navigator.userAgent);
  const esStandalone = window.navigator.standalone === true || window.matchMedia('(display-mode: standalone)').matches;

  const banner = document.getElementById('iphone-install-banner');
  if (banner) {
    banner.style.display = (esIos && !esStandalone) ? 'flex' : 'none';
  }
}

async function inicializarSesion() {
  const sesionLocal = localStorage.getItem('cto_sesion_iphone');
  if (sesionLocal) {
    try {
      AppState.usuarioActual = JSON.parse(sesionLocal);
    } catch (_) {}
  }

  if (!AppState.usuarioActual) {
    mostrarPantalla('login-screen');
    return;
  }

  // Cargar censo de empleados en segundo plano
  AppState.empleadosCenso = await obtenerTodosLosEmpleados();
  if (AppState.empleadosCenso.length === 0) {
    AppState.empleadosCenso = await supabase.sincronizarCensoEmpleados();
  }

  // Comprobar si ya existen servicios cargados
  const totalServicios = await contarServiciosTotal();

  if (totalServicios === 0) {
    // Sincronización automática inicial transparente
    mostrarPantalla('sharepoint-screen');
    const spStatusText = document.getElementById('sharepoint-status-text');
    const spSpinner = document.getElementById('sharepoint-loading-spinner');
    if (spSpinner) spSpinner.style.display = 'block';

    const exito = await descargarYSincronizarCuadranteOficial((msg) => {
      if (spStatusText) spStatusText.textContent = msg;
    });

    if (exito) {
      mostrarPantalla('home-screen');
      await cargarDatosApp();
    } else {
      if (spSpinner) spSpinner.style.display = 'none';
    }
  } else {
    mostrarPantalla('home-screen');
    await cargarDatosApp();
  }
}

function mostrarPantalla(screenId) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(screenId);
  if (target) target.classList.add('active');
}

/**
 * Descarga y parsea el cuadrante oficial de forma 100% transparente.
 * Primero intenta desde Supabase Storage (CORS abierto, funciona desde cualquier navegador y file://).
 * Si no hay red, intenta el archivo local empotrado.
 */
async function descargarYSincronizarCuadranteOficial(onProgreso = null) {
  // 1. Descarga transparente desde Supabase Storage (CORS habilitado internacionalmente)
  try {
    if (onProgreso) onProgreso('Conectando con servidor y descargando cuadrante oficial...');
    const res = await fetch(SUPABASE_STORAGE_CONFIG.cuadranteUrl, { cache: 'no-cache' });
    if (res.ok) {
      const buffer = await res.arrayBuffer();
      if (buffer && buffer.byteLength > 1000) {
        if (onProgreso) onProgreso('Parseando matriz de turnos y notas...');
        await parsearExcelCuadrante(buffer, onProgreso);
        await setConfig('setup_completado', true);
        return true;
      }
    }
  } catch (e) {
    console.warn('Descarga por Supabase Storage no disponible:', e);
  }

  // 2. Fallback a archivo local data/cuadrante.xlsm (para entornos con servidor local)
  try {
    const resLocal = await fetch('./data/cuadrante.xlsm');
    if (resLocal.ok) {
      const bufLocal = await resLocal.arrayBuffer();
      await parsearExcelCuadrante(bufLocal, onProgreso);
      await setConfig('setup_completado', true);
      return true;
    }
  } catch (_) {}

  return false;
}

// =================== GESTIÓN DE EVENTOS UI ===================

function configurarEventosUI() {
  // 1. LOGIN CON VISIBILIDAD DINÁMICA DE ADMINISTRADOR
  const inputMatricula = document.getElementById('input-matricula');
  const inputEmail = document.getElementById('input-email');
  const groupPassAdmin = document.getElementById('group-password-admin');
  const inputPassword = document.getElementById('input-password');
  const errorMsgP = document.getElementById('login-error-msg');
  const formLogin = document.getElementById('form-login');

  function actualizarVisibilidadAdmin() {
    const num = (inputMatricula?.value || '').trim();
    const em = (inputEmail?.value || '').trim().toLowerCase();
    const esAdmin = (num === '0000' || em === 'admin@metro.es');

    if (groupPassAdmin) {
      groupPassAdmin.style.display = esAdmin ? 'block' : 'none';
      if (!esAdmin && inputPassword) {
        inputPassword.value = '';
        inputPassword.removeAttribute('required');
      } else if (esAdmin && inputPassword) {
        inputPassword.setAttribute('required', 'required');
      }
    }
  }

  inputMatricula?.addEventListener('input', actualizarVisibilidadAdmin);
  inputEmail?.addEventListener('input', actualizarVisibilidadAdmin);

  if (formLogin) {
    formLogin.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (errorMsgP) errorMsgP.style.display = 'none';

      const numInput = (inputMatricula?.value || '').trim();
      const emailInput = (inputEmail?.value || '').trim();
      const passInput = (inputPassword?.value || '').trim();
      const btn = document.getElementById('btn-login-submit');

      try {
        if (btn) {
          btn.disabled = true;
          btn.querySelector('span').textContent = 'Verificando con Supabase...';
        }

        const sesion = await supabase.login(numInput, emailInput, passInput);
        AppState.usuarioActual = sesion;

        // Cargar censo de empleados en segundo plano
        AppState.empleadosCenso = await supabase.sincronizarCensoEmpleados();

        const totalServicios = await contarServiciosTotal();
        if (totalServicios === 0) {
          // Pasar inmediatamente a la sincronización automática transparente
          mostrarPantalla('sharepoint-screen');
          const spSpinner = document.getElementById('sharepoint-loading-spinner');
          const spStatusText = document.getElementById('sharepoint-status-text');
          if (spSpinner) spSpinner.style.display = 'block';

          const exito = await descargarYSincronizarCuadranteOficial((msg) => {
            if (spStatusText) spStatusText.textContent = msg;
          });

          if (exito) {
            mostrarPantalla('home-screen');
            await cargarDatosApp();
          } else {
            if (spSpinner) spSpinner.style.display = 'none';
          }
        } else {
          mostrarPantalla('home-screen');
          await cargarDatosApp();
        }
      } catch (err) {
        if (errorMsgP) {
          errorMsgP.textContent = err.message || 'Error al autenticar';
          errorMsgP.style.display = 'block';
        } else {
          alert(err.message || 'Error al autenticar');
        }
      } finally {
        if (btn) {
          btn.disabled = false;
          btn.querySelector('span').textContent = 'Iniciar Sesión';
        }
      }
    });
  }

  // 2. SHAREPOINT / CARGA DE ARCHIVO
  // Botón 1: Sincronizar Cuadrante Oficial Integrado (descarga transparente desde Supabase Storage)
  document.getElementById('btn-load-bundled-excel')?.addEventListener('click', async () => {
    const spSpinner = document.getElementById('sharepoint-loading-spinner');
    const spStatusText = document.getElementById('sharepoint-status-text');
    try {
      if (spSpinner) spSpinner.style.display = 'block';
      const exito = await descargarYSincronizarCuadranteOficial((msg) => {
        if (spStatusText) spStatusText.textContent = msg;
      });

      if (exito) {
        mostrarPantalla('home-screen');
        await cargarDatosApp();
      } else {
        throw new Error('No se pudo descargar automáticamente. Por favor selecciona el archivo .xlsm abajo.');
      }
    } catch (e) {
      if (spSpinner) spSpinner.style.display = 'none';
      alert(e.message);
    }
  });

  // Botón 2: Conectar con Microsoft SharePoint
  document.getElementById('btn-sharepoint-sync-auto')?.addEventListener('click', () => {
    sharepointManager.iniciarLoginSharePoint();
    mostrarToastAviso('Descarga iniciada desde SharePoint.');
  });

  // Selector de archivos compatible 100% con Chrome, Edge, Safari y Firefox
  const inputFileExcel = document.getElementById('input-file-excel');
  if (inputFileExcel) {
    inputFileExcel.addEventListener('change', (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      procesarArchivoExcelLocal(file);
      e.target.value = ''; // Reset para permitir volver a seleccionar el mismo archivo
    });
  }

  // Zona de Arrastrar y Soltar (Drag & Drop)
  const dropZone = document.getElementById('drop-zone-excel');
  if (dropZone) {
    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.style.borderColor = 'var(--primary)';
    });
    dropZone.addEventListener('dragleave', () => {
      dropZone.style.borderColor = 'var(--border)';
    });
    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.style.borderColor = 'var(--border)';
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (file) procesarArchivoExcelLocal(file);
    });
  }

  // 3. SELECTOR DE FECHAS
  document.getElementById('btn-prev-day')?.addEventListener('click', () => cambiarDia(-1));
  document.getElementById('btn-next-day')?.addEventListener('click', () => cambiarDia(1));
  document.getElementById('btn-today')?.addEventListener('click', () => {
    AppState.fechaSeleccionada = formatearFechaIso(new Date());
    renderizarFechaActual();
    cargarServiciosDelDia();
  });

  const datePicker = document.getElementById('native-date-picker');
  document.getElementById('date-display-trigger')?.addEventListener('click', () => {
    if (datePicker) {
      try { datePicker.showPicker(); } catch (_) { datePicker.click(); }
    }
  });

  datePicker?.addEventListener('change', (e) => {
    if (e.target.value) {
      AppState.fechaSeleccionada = e.target.value;
      renderizarFechaActual();
      cargarServiciosDelDia();
    }
  });

  // 4. FRANJA TABS
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      AppState.franjaSeleccionada = btn.getAttribute('data-franja') || 'TODAS';
      renderizarListaServicios();
    });
  });

  // 5. BÚSQUEDA
  const inputBusqueda = document.getElementById('input-search');
  inputBusqueda?.addEventListener('input', (e) => {
    AppState.busquedaTexto = e.target.value.trim().toLowerCase();
    renderizarListaServicios();
  });

  // 6. TOP BAR: AVATAR / PERFIL PROPIO (Abre su Calendario Personal y Contadores)
  document.getElementById('user-avatar-btn')?.addEventListener('click', () => {
    const usr = AppState.usuarioActual;
    if (!usr) return;
    abrirDetalleEmpleado(usr);
  });

  // 7. TOP BAR: BOTÓN RE-SINCRONIZAR SHAREPOINT
  document.getElementById('btn-topbar-sync')?.addEventListener('click', () => {
    mostrarPantalla('sharepoint-screen');
  });

  // 8. TOP BAR: BOTÓN GESTIÓN DE PERSONAL
  document.getElementById('btn-topbar-empleados')?.addEventListener('click', () => {
    abrirPantallaEmpleados();
  });

  // 9. TOP BAR: MENÚ DESPLEGABLE MÁS OPCIONES
  const btnMenu = document.getElementById('btn-topbar-menu');
  const dropdownMenu = document.getElementById('dropdown-menu-options');
  btnMenu?.addEventListener('click', (e) => {
    e.stopPropagation();
    if (dropdownMenu) {
      dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
    }
  });

  document.addEventListener('click', () => {
    if (dropdownMenu) dropdownMenu.style.display = 'none';
  });

  // Opciones del Menú:
  document.getElementById('menu-opt-importar-xlsm')?.addEventListener('click', () => {
    mostrarPantalla('sharepoint-screen');
  });

  document.getElementById('menu-opt-importar-eventos')?.addEventListener('click', async () => {
    alert('Importación de Eventos: Puedes seleccionar tu archivo CALENDARIO EVENTOS.xlsx.');
  });

  document.getElementById('menu-opt-historial-cambios')?.addEventListener('click', async () => {
    await comprobarCambiosAlIniciar(true);
  });

  document.getElementById('menu-opt-cerrar-sesion')?.addEventListener('click', () => {
    const conf = confirm('¿Deseas cerrar sesión?');
    if (conf) {
      localStorage.removeItem('cto_sesion_iphone');
      AppState.usuarioActual = null;
      mostrarPantalla('login-screen');
    }
  });

  // 10. PANTALLA GESTIÓN DE PERSONAL: RETROCESO Y BÚSQUEDA
  document.getElementById('btn-empleados-back')?.addEventListener('click', () => {
    mostrarPantalla('home-screen');
  });

  document.getElementById('btn-empleados-sync-supabase')?.addEventListener('click', async () => {
    mostrarToastAviso('Sincronizando censo desde Supabase...');
    AppState.empleadosCenso = await supabase.sincronizarCensoEmpleados();
    renderizarListaEmpleados();
    mostrarToastAviso('Censo de empleados actualizado');
  });

  document.getElementById('input-search-empleados')?.addEventListener('input', (e) => {
    renderizarListaEmpleados(e.target.value.trim().toLowerCase());
  });

  // 11. MODAL DETALLE DE EMPLEADO: TABS Y MESES
  document.getElementById('btn-close-emp-detail')?.addEventListener('click', () => {
    document.getElementById('modal-empleado-detail')?.classList.remove('active');
  });

  document.getElementById('tab-emp-contadores')?.addEventListener('click', () => {
    document.getElementById('tab-emp-contadores').classList.add('active');
    document.getElementById('tab-emp-calendario').classList.remove('active');
    document.getElementById('sec-emp-contadores').classList.add('active');
    document.getElementById('sec-emp-calendario').classList.remove('active');
  });

  document.getElementById('tab-emp-calendario')?.addEventListener('click', () => {
    document.getElementById('tab-emp-calendario').classList.add('active');
    document.getElementById('tab-emp-contadores').classList.remove('active');
    document.getElementById('sec-emp-calendario').classList.add('active');
    document.getElementById('sec-emp-contadores').classList.remove('active');
    renderizarMesCalendarioPersonal();
  });

  document.getElementById('btn-cal-prev-month')?.addEventListener('click', () => {
    AppState.mesCalendarioPersonal = (AppState.mesCalendarioPersonal - 1 + 12) % 12;
    renderizarMesCalendarioPersonal();
  });

  document.getElementById('btn-cal-next-month')?.addEventListener('click', () => {
    AppState.mesCalendarioPersonal = (AppState.mesCalendarioPersonal + 1) % 12;
    renderizarMesCalendarioPersonal();
  });

  // 12. GUÍA DE INSTALACIÓN IPHONE
  document.getElementById('btn-show-install-guide')?.addEventListener('click', () => {
    document.getElementById('modal-install-guide')?.classList.add('active');
  });

  document.getElementById('btn-close-install-guide')?.addEventListener('click', () => {
    document.getElementById('modal-install-guide')?.classList.remove('active');
  });

  document.getElementById('btn-notif-entendido')?.addEventListener('click', () => {
    document.getElementById('modal-notificacion-cambios')?.classList.remove('active');
  });
}

/**
 * Lee y parsea un archivo Excel seleccionado localmente con máxima compatibilidad Chrome/Edge/Safari
 */
function procesarArchivoExcelLocal(file) {
  const spSpinner = document.getElementById('sharepoint-loading-spinner');
  const spStatusText = document.getElementById('sharepoint-status-text');

  if (spSpinner) spSpinner.style.display = 'block';
  if (spStatusText) spStatusText.textContent = 'Leyendo archivo Excel...';

  const reader = new FileReader();
  reader.onload = async (event) => {
    try {
      const buffer = event.target.result;
      if (spStatusText) spStatusText.textContent = 'Parseando matriz de turnos y notas...';

      const res = await parsearExcelCuadrante(buffer, (msg) => {
        if (spStatusText) spStatusText.textContent = msg;
      });

      await setConfig('setup_completado', true);
      mostrarPantalla('home-screen');
      await cargarDatosApp();
    } catch (err) {
      if (spSpinner) spSpinner.style.display = 'none';
      alert('Error al procesar el archivo Excel: ' + err.message);
    }
  };

  reader.onerror = () => {
    if (spSpinner) spSpinner.style.display = 'none';
    alert('Error al leer el archivo en el navegador.');
  };

  reader.readAsArrayBuffer(file);
}

function cambiarDia(offset) {
  const d = parsearFechaSegura(AppState.fechaSeleccionada) || new Date();
  d.setDate(d.getDate() + offset);
  AppState.fechaSeleccionada = formatearFechaIso(d);
  renderizarFechaActual();
  cargarServiciosDelDia();
}

function renderizarFechaActual() {
  const dateDisp = document.getElementById('date-display-day');
  const dateSub = document.getElementById('date-display-sub');
  const datePicker = document.getElementById('native-date-picker');

  if (dateDisp) dateDisp.textContent = formatearFechaVisual(AppState.fechaSeleccionada);
  if (datePicker) datePicker.value = AppState.fechaSeleccionada;

  const hoyIso = formatearFechaIso(new Date());
  if (dateSub) {
    dateSub.textContent = (AppState.fechaSeleccionada === hoyIso) ? 'HOY' : AppState.fechaSeleccionada;
  }
}

// =================== CARGA DE DATOS PRINCIPALES ===================

async function cargarDatosApp() {
  renderizarHeaderUsuario();
  renderizarFechaActual();

  // Cargar censo de empleados si no está hidratado
  if (AppState.empleadosCenso.length === 0) {
    AppState.empleadosCenso = await obtenerTodosLosEmpleados();
  }

  await cargarServiciosDelDia();

  // Comprobar automáticamente modificaciones y estado del calendario
  await comprobarCambiosAlIniciar();
}

function renderizarHeaderUsuario() {
  const u = AppState.usuarioActual;
  if (!u) return;

  const avatar = document.getElementById('user-avatar-btn');
  if (avatar) avatar.textContent = u.letra || 'L1';

  const title = document.getElementById('topbar-user-name');
  if (title) title.textContent = 'Servicios del Día';

  const subtitle = document.getElementById('topbar-user-subtitle');
  if (subtitle) {
    subtitle.textContent = u.nombreCompleto ? `${u.nombreCompleto} · L1` : 'Calendario CTO 2026 L1';
  }
}

async function cargarServiciosDelDia() {
  const lista = await obtenerServiciosPorFecha(AppState.fechaSeleccionada);
  AppState.serviciosDelDia = lista;

  actualizarBadgesFranjas();
  renderizarListaServicios();
}

function actualizarBadgesFranjas() {
  const todos = AppState.serviciosDelDia;
  const countM = todos.filter(s => s.franja === 'MAÑANA').length;
  const countT = todos.filter(s => s.franja === 'TARDE').length;
  const countN = todos.filter(s => s.franja === 'NOCHE').length;

  document.getElementById('badge-count-todas').textContent = todos.length;
  document.getElementById('badge-count-manana').textContent = countM;
  document.getElementById('badge-count-tarde').textContent = countT;
  document.getElementById('badge-count-noche').textContent = countN;
}

/**
 * Renderiza la lista con el ORDEN OFICIAL ESTRICTO DE ANDROID (HomeViewModel.kt líneas 117..141):
 * - En vista "TODAS": los servicios se ordenan estrictamente por letra
 *   (agrupados por turno MAÑANA -> TARDE -> NOCHE).
 * - En filtros de turno individual (MAÑANA, TARDE, NOCHE): los servicios se ordenan
 *   estrictamente según prioridad de servicio oficial:
 *   (CC, CE, TL, CC1, CE1, TL1, FR, FI, t, [vacío], A, E, AS, D, F, RJ, V, FA, DA, P).
 */
function renderizarListaServicios() {
  const container = document.getElementById('services-list-container');
  if (!container) return;

  const mapaEmpleados = new Map(AppState.empleadosCenso.map(e => [e.letra.toUpperCase(), e]));

  // 1. Filtrar por franja
  let filtrados = AppState.serviciosDelDia.filter(s => {
    if (AppState.franjaSeleccionada === 'TODAS') return true;
    return s.franja.toUpperCase() === AppState.franjaSeleccionada;
  });

  // 2. Filtrar por texto de búsqueda
  const q = AppState.busquedaTexto;
  if (q) {
    filtrados = filtrados.filter(s => {
      const emp = mapaEmpleados.get(s.letra.toUpperCase());
      const nom = emp ? emp.nombreCompleto.toLowerCase() : '';
      const num = emp ? emp.numeroEmpleado.toLowerCase() : '';
      const serv = s.servicio.toLowerCase();
      const letra = s.letra.toLowerCase();
      const desc = obtenerInfoServicio(s.servicio).desc.toLowerCase();

      return letra.includes(q) || serv.includes(q) || desc.includes(q) || nom.includes(q) || num.includes(q);
    });
  }

  // 3. Ordenación oficial idéntica a HomeViewModel.kt de Android
  if (AppState.franjaSeleccionada === 'TODAS') {
    filtrados.sort((a, b) => {
      // Primero agrupados por turno (MAÑANA -> TARDE -> NOCHE)
      const franjaA = ORDEN_FRANJAS[a.franja?.toUpperCase()] || 4;
      const franjaB = ORDEN_FRANJAS[b.franja?.toUpperCase()] || 4;
      if (franjaA !== franjaB) return franjaA - franjaB;

      // Luego por orden de letra oficial dentro del turno (T1..T9.. / R1..R9.. / N1..N6R..)
      const ordenLetraA = obtenerOrdenLetraOficial(a.letra);
      const ordenLetraB = obtenerOrdenLetraOficial(b.letra);
      if (ordenLetraA !== ordenLetraB) return ordenLetraA - ordenLetraB;

      if (a.letra !== b.letra) return a.letra.localeCompare(b.letra);

      return obtenerPrioridadServicio(a.servicio) - obtenerPrioridadServicio(b.servicio);
    });
  } else {
    // En filtros de turno (MAÑANA, TARDE, NOCHE): estrictamente por prioridad de servicio oficial
    filtrados.sort((a, b) => {
      const prioA = obtenerPrioridadServicio(a.servicio);
      const prioB = obtenerPrioridadServicio(b.servicio);
      if (prioA !== prioB) return prioA - prioB;

      const ordenLetraA = obtenerOrdenLetraOficial(a.letra);
      const ordenLetraB = obtenerOrdenLetraOficial(b.letra);
      if (ordenLetraA !== ordenLetraB) return ordenLetraA - ordenLetraB;

      return a.letra.localeCompare(b.letra);
    });
  }

  if (filtrados.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 40px 20px; color: var(--text-muted);">
        <p style="font-size: 16px; font-weight: 700;">No se encontraron servicios</p>
        <p style="font-size: 13px; margin-top: 4px;">Comprueba la fecha seleccionada o los filtros de búsqueda.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtrados.map(s => {
    const emp = mapaEmpleados.get(s.letra.toUpperCase());
    const infoServ = obtenerInfoServicio(s.servicio);
    const borderStyle = infoServ.border ? `border: 1px solid ${infoServ.border};` : '';

    return `
      <div class="service-card" onclick="abrirDetalleServicio('${s.letra}', '${s.servicio}', '${encodeURIComponent(s.nota || '')}')">
        <div class="service-card-left">
          <div class="emp-avatar-slot" onclick="event.stopPropagation(); abrirDetalleEmpleadoPorLetra('${s.letra}')">
            ${emp && emp.fotoUri ? `<img class="emp-avatar-img" src="${emp.fotoUri}" alt="${emp.nombreCompleto}" />` : (s.letra || 'L1')}
          </div>
          <div class="emp-info">
            <span class="emp-letra-badge">${s.letra} &bull; ${s.franja}</span>
            <span class="emp-nombre">${emp ? emp.nombreCompleto : 'Vacante / Sin asignar'}</span>
            <span class="emp-matricula">${emp ? `Matrícula: ${emp.numeroEmpleado}` : ''}</span>
          </div>
        </div>
        <div class="service-pill" style="background-color: ${infoServ.bg}; color: ${infoServ.color}; ${borderStyle}">
          <span>${s.servicio || '-'}</span>
          <span class="service-pill-desc">${infoServ.desc}</span>
        </div>
      </div>
    `;
  }).join('');
}

// =================== GESTIÓN DE PERSONAL ===================

function abrirPantallaEmpleados() {
  mostrarPantalla('screen-empleados');
  renderizarListaEmpleados();
}

function renderizarListaEmpleados(filtroQuery = '') {
  const container = document.getElementById('lista-empleados-container');
  if (!container) return;

  let lista = [...AppState.empleadosCenso];

  // Ordenar empleados por el orden oficial de turnos
  lista.sort((a, b) => {
    const oa = obtenerOrdenLetraOficial(a.letra);
    const ob = obtenerOrdenLetraOficial(b.letra);
    if (oa !== ob) return oa - ob;
    return a.nombreCompleto.localeCompare(b.nombreCompleto);
  });

  if (filtroQuery) {
    lista = lista.filter(e =>
      e.nombreCompleto.toLowerCase().includes(filtroQuery) ||
      e.numeroEmpleado.toLowerCase().includes(filtroQuery) ||
      (e.letra && e.letra.toLowerCase().includes(filtroQuery))
    );
  }

  container.innerHTML = lista.map(emp => `
    <div class="emp-item-card" onclick="abrirDetalleEmpleadoPorLetra('${emp.letra}')">
      <div class="emp-avatar-badge">
        ${emp.fotoUri ? `<img src="${emp.fotoUri}" alt="${emp.nombreCompleto}">` : (emp.letra || 'L1')}
      </div>
      <div class="emp-info">
        <div class="emp-info-nombre">${emp.nombreCompleto}</div>
        <div class="emp-info-sub">Turno: <strong>${emp.letra || 'Sin asignar'}</strong> &bull; Matrícula: ${emp.numeroEmpleado}</div>
      </div>
      ${emp.telefono ? `
        <a class="emp-call-btn" href="tel:${emp.telefono}" onclick="event.stopPropagation();" title="Llamar">
          📞
        </a>
      ` : ''}
    </div>
  `).join('');
}

// =================== FICHA DE DETALLE DE EMPLEADO (CONTADORES Y CALENDARIO ANUAL) ===================

window.abrirDetalleEmpleadoPorLetra = function(letra) {
  const emp = AppState.empleadosCenso.find(e => e.letra?.toUpperCase() === letra?.toUpperCase());
  if (emp) {
    abrirDetalleEmpleado(emp);
  } else {
    abrirDetalleEmpleado({ letra: letra, nombreCompleto: `Turno ${letra}`, numeroEmpleado: '-' });
  }
};

async function abrirDetalleEmpleado(empleado) {
  AppState.empleadoDetalleActual = empleado;

  const modal = document.getElementById('modal-empleado-detail');
  if (!modal) return;

  // Cabecera
  const avatar = document.getElementById('emp-detail-avatar');
  if (avatar) avatar.textContent = empleado.letra || 'L1';

  document.getElementById('emp-detail-nombre').textContent = empleado.nombreCompleto || 'Sin asignar';
  document.getElementById('emp-detail-sub').textContent = `Matrícula: ${empleado.numeroEmpleado || '-'} • Turno: ${empleado.letra || '-'}`;

  const telLink = document.getElementById('emp-detail-telefono-link');
  if (telLink) {
    if (empleado.telefono) {
      telLink.textContent = `📞 ${empleado.telefono}`;
      telLink.href = `tel:${empleado.telefono}`;
      telLink.style.display = 'inline-block';
    } else {
      telLink.style.display = 'none';
    }
  }

  // REGLA DE PRIVACIDAD OFICIAL ANDROID (EmpleadoDetailSheet.kt):
  // Solo el propio empleado registrado o el Administrador pueden ver los contadores y calendario anual individual
  const esAdmin = AppState.usuarioActual?.rol === 'ADMIN';
  const esMiPropioPerfil = String(empleado.numeroEmpleado || '').trim() === String(AppState.usuarioActual?.numeroEmpleado || '').trim();
  const puedeVerPrivado = esAdmin || esMiPropioPerfil;

  const tabsBar = document.querySelector('.emp-mode-tabs');
  const secContadores = document.getElementById('sec-emp-contadores');
  const secCalendario = document.getElementById('sec-emp-calendario');

  if (tabsBar) tabsBar.style.display = puedeVerPrivado ? 'flex' : 'none';

  if (!puedeVerPrivado) {
    secContadores.classList.remove('active');
    secCalendario.classList.remove('active');
    // Mostrar mensaje informativo de privacidad
    let privacyNotice = document.getElementById('emp-privacy-notice');
    if (!privacyNotice) {
      privacyNotice = document.createElement('div');
      privacyNotice.id = 'emp-privacy-notice';
      privacyNotice.style.cssText = 'padding: 24px 16px; text-align: center; color: var(--text-muted); font-size: 13px; line-height: 1.5;';
      tabsBar.parentNode.insertBefore(privacyNotice, tabsBar.nextSibling);
    }
    privacyNotice.style.display = 'block';
    privacyNotice.innerHTML = `
      <div style="font-size: 32px; margin-bottom: 8px;">🔒</div>
      <p style="font-weight: 700; color: var(--text-main); margin-bottom: 4px;">Información Personal Protegida</p>
      <p>Los contadores anuales y el calendario individual solo son accesibles por el propio empleado o el administrador.</p>
    `;
  } else {
    const privacyNotice = document.getElementById('emp-privacy-notice');
    if (privacyNotice) privacyNotice.style.display = 'none';

    // Activar pestaña Contadores por defecto
    document.getElementById('tab-emp-contadores').classList.add('active');
    document.getElementById('tab-emp-calendario').classList.remove('active');
    secContadores.classList.add('active');
    secCalendario.classList.remove('active');

    // Calcular contadores y renderizar
    await renderizarContadoresEmpleado(empleado.letra);
  }

  modal.classList.add('active');
}

async function renderizarContadoresEmpleado(letra) {
  const grid = document.getElementById('emp-contadores-grid');
  const listaConceptos = document.getElementById('emp-conceptos-list');
  if (!grid || !letra) return;

  const serviciosAno = await obtenerServiciosPorLetra(letra);

  // Calcular métricas
  const conteo = {};
  for (const s of serviciosAno) {
    const cod = (s.servicio || '').trim().toUpperCase();
    conteo[cod] = (conteo[cod] || 0) + 1;
  }

  const dcom = (conteo['D'] || 0) + (conteo['DA'] || 0);
  const fest = (conteo['F'] || 0) + (conteo['FA'] || 0);
  const vac = conteo['V'] || 0;
  const rj = conteo['RJ'] || 0;
  const cc = (conteo['CC'] || 0) + (conteo['CC1'] || 0);
  const ce = (conteo['CE'] || 0) + (conteo['CE1'] || 0);
  const tl = (conteo['TL'] || 0) + (conteo['TL1'] || 0);
  const baja = (conteo['E'] || 0) + (conteo['A'] || 0);
  const trabajados = Math.max(0, serviciosAno.length - dcom - fest - vac - baja);

  grid.innerHTML = `
    <div class="contador-card">
      <div class="contador-val">${trabajados}</div>
      <div class="contador-lbl">Días Trabajados</div>
    </div>
    <div class="contador-card">
      <div class="contador-val">${dcom}</div>
      <div class="contador-lbl">Descansos (DCOM)</div>
    </div>
    <div class="contador-card">
      <div class="contador-val">${fest}</div>
      <div class="contador-lbl">Festivos (FEST)</div>
    </div>
    <div class="contador-card">
      <div class="contador-val">${vac}</div>
      <div class="contador-lbl">Vacaciones (V)</div>
    </div>
    <div class="contador-card">
      <div class="contador-val">${cc}</div>
      <div class="contador-lbl">Circulación (CC)</div>
    </div>
    <div class="contador-card">
      <div class="contador-val">${tl}</div>
      <div class="contador-lbl">Titular Línea (TL)</div>
    </div>
  `;

  // Tabla completa de conceptos de cómputo oficial
  if (listaConceptos) {
    const filas = [
      { label: 'Días trabajados anuales', val: trabajados },
      { label: 'DCOM (Descansos semanales)', val: dcom },
      { label: 'FEST (Festivos oficiales)', val: fest },
      { label: 'Vacaciones (V)', val: vac },
      { label: 'RJ (Recuperación jornada)', val: rj },
      { label: 'Panel Circulación (CC / CC1)', val: cc },
      { label: 'Panel Estaciones (CE / CE1)', val: ce },
      { label: 'Titular de línea (TL / TL1)', val: tl },
      { label: 'Enfermedad / Accidente', val: baja }
    ];

    listaConceptos.innerHTML = filas.map(f => `
      <div class="concepto-row">
        <span>${f.label}</span>
        <strong>${f.val}</strong>
      </div>
    `).join('');
  }
}

async function renderizarMesCalendarioPersonal() {
  const emp = AppState.empleadoDetalleActual;
  if (!emp || !emp.letra) return;

  const mesIdx = AppState.mesCalendarioPersonal;
  const mesesNombres = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  document.getElementById('cal-month-title').textContent = `${mesesNombres[mesIdx]} 2026`;

  const grid = document.getElementById('cal-grid-dias');
  if (!grid) return;

  const serviciosAno = await obtenerServiciosPorLetra(emp.letra);
  const mapaFechas = new Map(serviciosAno.map(s => [s.fecha, s.servicio]));

  // Calcular primer día del mes y total de días
  const primerDia = new Date(2026, mesIdx, 1);
  const totalDias = new Date(2026, mesIdx + 1, 0).getDate();

  // Día de la semana (0 = Domingo -> convertir a Lunes=0..Domingo=6)
  let offsetInicio = primerDia.getDay() - 1;
  if (offsetInicio === -1) offsetInicio = 6;

  let html = '';

  // Huecos vacíos antes del día 1
  for (let i = 0; i < offsetInicio; i++) {
    html += '<div style="aspect-ratio:1;"></div>';
  }

  // Días del mes
  for (let dia = 1; dia <= totalDias; dia++) {
    const fechaIso = `2026-${String(mesIdx + 1).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
    const srv = mapaFechas.get(fechaIso) || '';
    const info = obtenerInfoServicio(srv);
    const border = info.border ? `border: 1px solid ${info.border};` : '';

    html += `
      <div class="cal-cell" style="background-color: ${info.bg}; color: ${info.color}; ${border}">
        <span class="cal-cell-num">${dia}</span>
        <span class="cal-cell-srv">${srv || '-'}</span>
      </div>
    `;
  }

  grid.innerHTML = html;
}

// =================== DETALLE DE SERVICIO MODAL ===================

window.abrirDetalleServicio = function(letra, servicio, notaEncoded) {
  const nota = decodeURIComponent(notaEncoded);
  const infoServ = obtenerInfoServicio(servicio);
  const emp = AppState.empleadosCenso.find(e => e.letra.toUpperCase() === letra.toUpperCase());

  const modal = document.getElementById('modal-service-detail');
  const body = document.getElementById('service-detail-body');
  if (!modal || !body) return;

  body.innerHTML = `
    <div style="text-align: center; margin-bottom: 16px;">
      <div class="service-pill" style="display: inline-flex; padding: 12px 24px; font-size: 24px; background: ${infoServ.bg}; color: ${infoServ.color};">
        ${servicio || 'Sin Asignar'}
      </div>
      <p style="font-size: 15px; font-weight: 700; margin-top: 8px;">${infoServ.desc}</p>
      <p style="font-size: 13px; color: var(--text-muted);">${formatearFechaVisual(AppState.fechaSeleccionada)}</p>
    </div>

    <div style="background: var(--surface-variant); padding: 14px; border-radius: var(--radius-md); margin-bottom: 12px;">
      <p style="font-size: 12px; font-weight: 700; color: var(--primary); text-transform: uppercase;">Puesto / Empleado</p>
      <p style="font-size: 16px; font-weight: 800; margin-top: 2px;">Turno ${letra} &bull; ${emp ? emp.nombreCompleto : 'Sin asignar'}</p>
      ${emp && emp.telefono ? `<p style="font-size: 13px; color: var(--text-muted); margin-top: 4px;">Teléfono corporativo: ${emp.telefono}</p>` : ''}
    </div>

    ${nota ? `
      <div style="background: #FEF3C7; border: 1px solid #FDE68A; padding: 12px; border-radius: var(--radius-md); margin-bottom: 14px;">
        <p style="font-size: 11px; font-weight: 800; color: #B45309; text-transform: uppercase;">Nota del Cuadrante</p>
        <p style="font-size: 14px; color: #92400E; margin-top: 2px; font-style: italic;">"${nota}"</p>
      </div>
    ` : ''}
  `;

  modal.classList.add('active');
};

document.getElementById('btn-close-service-detail')?.addEventListener('click', () => {
  document.getElementById('modal-service-detail')?.classList.remove('active');
});

// =================== COMPROBACIÓN DE CAMBIOS Y MODAL DE 5 DÍAS ===================

async function comprobarCambiosAlIniciar(forzarAviso = false) {
  const u = AppState.usuarioActual;
  if (!u) return;

  // 1. Sincronizar automáticamente historial de cambios desde Supabase
  const cambiosSupabase = await supabase.sincronizarHistorialCambiosDesdeSupabase();

  // 2. Si hay cambios en Supabase, actualizar de inmediato los registros en IndexedDB
  if (cambiosSupabase && cambiosSupabase.length > 0) {
    for (const c of cambiosSupabase) {
      if (c.fechaServicio && c.letra && c.servicioNuevo) {
        await guardarServiciosLote([{
          fecha: c.fechaServicio,
          letra: c.letra,
          franja: LETRAS_POR_FRANJA.MANANA.includes(c.letra) ? 'MAÑANA' : (LETRAS_POR_FRANJA.TARDE.includes(c.letra) ? 'TARDE' : 'NOCHE'),
          servicio: c.servicioNuevo,
          nota: c.notaNueva || '',
          lineas: c.lineasNueva || ''
        }]);
      }
    }
  }

  // 3. Notificaciones según rol
  if (u.rol === 'ADMIN') {
    if (cambiosSupabase.length > 0) {
      mostrarToastAviso(`¡Se detectaron ${cambiosSupabase.length} cambios en el cuadrante!`);
    } else if (forzarAviso) {
      mostrarToastAviso('El Calendario se encuentra actualizado');
    }
    return;
  }

  // Empleado normal: comprobar próximos 5 días (desde hoy incluido)
  if (!u.letra) {
    if (forzarAviso) mostrarToastAviso('El Calendario se encuentra actualizado');
    return;
  }

  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);

  const fin5Dias = new Date(hoy);
  fin5Dias.setDate(fin5Dias.getDate() + 4);

  const noVistos = await obtenerCambiosNoVistosPorLetra(u.letra);

  const dentroDeRango = (noVistos || []).filter(c => {
    const d = parsearFechaSegura(c.fechaServicio);
    if (!d) return false;
    return d >= hoy && d <= fin5Dias;
  }).sort((a, b) => {
    const da = parsearFechaSegura(a.fechaServicio) || 0;
    const db = parsearFechaSegura(b.fechaServicio) || 0;
    return da - db;
  });

  if (dentroDeRango.length > 0) {
    mostrarModalNotificacionCambios(u, dentroDeRango);
  } else {
    // Si no hay variaciones pendientes, mostrar el aviso oficial idéntico a Android
    mostrarToastAviso('El Calendario se encuentra actualizado');
  }
}

function mostrarModalNotificacionCambios(usuario, cambios) {
  const modal = document.getElementById('modal-notificacion-cambios');
  const container = document.getElementById('notificacion-cambios-cards');
  if (!modal || !container) return;

  const primerNombre = usuario.nombreCompleto.includes(',')
    ? usuario.nombreCompleto.split(',')[1].trim().split(' ')[0]
    : usuario.nombreCompleto.split(' ')[0];

  document.getElementById('notif-saludo-nombre').textContent = `¡Hola, ${primerNombre}!`;
  document.getElementById('notif-subtitulo').textContent = cambios.length === 1
    ? 'Se ha modificado 1 servicio en tus próximos 5 días.'
    : `Se han modificado ${cambios.length} servicios en tus próximos 5 días.`;

  container.innerHTML = cambios.map(c => {
    const infoNuevo = obtenerInfoServicio(c.servicioNuevo);
    const borderStyle = infoNuevo.border ? `border: 1px solid ${infoNuevo.border};` : '';

    return `
      <div class="diff-card">
        <div class="diff-card-header">
          <svg style="width:14px;height:14px;fill:var(--primary);" viewBox="0 0 24 24"><path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10z"/></svg>
          <span>${formatearFechaVisual(c.fechaServicio)}</span>
        </div>
        <div class="diff-row">
          <div class="diff-pill-prev">
            <span style="font-size: 10px; display: block; opacity: 0.7;">Anterior</span>
            ${c.servicioAnterior || '(Vacío)'}
          </div>
          <span class="diff-arrow">&rarr;</span>
          <div class="diff-pill-new" style="background-color: ${infoNuevo.bg}; color: ${infoNuevo.color}; ${borderStyle}">
            <span style="font-size: 10px; display: block; opacity: 0.8;">Nuevo</span>
            ${c.servicioNuevo || 'Sin asignar'}
          </div>
        </div>
        ${infoNuevo.desc ? `<p style="font-size: 12px; font-weight: 600; margin-top: 6px; color: var(--text-muted);">&bull; ${infoNuevo.desc}</p>` : ''}
        ${c.notaNueva ? `<p style="font-size: 11px; color: #B45309; margin-top: 4px; font-style: italic;">Nota: "${c.notaNueva}"</p>` : ''}
      </div>
    `;
  }).join('');

  // Botón "Ver en Calendario"
  const btnVerCalendario = document.getElementById('btn-notif-ver-calendario');
  if (btnVerCalendario) {
    btnVerCalendario.onclick = async () => {
      const primerDia = cambios[0].fechaServicio;
      const ids = cambios.map(c => c.id).filter(id => Boolean(id));
      await marcarCambiosComoVistos(ids);

      modal.classList.remove('active');
      AppState.fechaSeleccionada = formatearFechaIso(parsearFechaSegura(primerDia));
      renderizarFechaActual();
      cargarServiciosDelDia();
    };
  }

  modal.classList.add('active');
}

// =================== TOAST FLOTANTE ===================

let toastTimer = null;
function mostrarToastAviso(mensaje, duracionMs = 3500) {
  const toast = document.getElementById('toast-aviso');
  const txt = document.getElementById('toast-aviso-texto');
  if (!toast || !txt) return;

  txt.textContent = mensaje;
  toast.style.display = 'flex';

  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.style.display = 'none';
  }, duracionMs);
}
