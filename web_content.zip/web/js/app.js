import { preload as preloadGrades, GradeManager } from "./engines/gradeManager.js";
import { UnifiedQuestionEngine } from "./engines/unifiedEngine.js";
import * as db from "./db.js";
import { applyTheme } from "./theme.js";
import { el, bottomNav, showAlert, showPrompt } from "./ui/widgets.js";

import { Login } from "./screens/login.js";
import { Home } from "./screens/home.js";
import { Learn, TopicDetail, TopicDetailLite } from "./screens/learn.js";
import { PracticeSetup, PracticeSession } from "./screens/practice.js";
import { Papers, PaperViewer } from "./screens/papers.js";
import { Profile } from "./screens/profile.js";
import { Settings } from "./screens/settings.js";
import { DiagramGallery } from "./screens/diagramGallery.js";
import { Labs, GeometryLab, DataLab, ProbabilityLab, Mental, SolidsLab } from "./screens/labs.js";
import { TheoremLab, TheoremRound } from "./screens/theoremLab.js";
import { WorkshopSession } from "./screens/workshopSession.js";
import { syncFromSettings, startMusic, playSfx } from "./engines/audioEngine.js";
import { TeachHub, TeachDeck } from "./screens/teach.js";
import { StructuredPractice, StructuredHub } from "./screens/structured.js";
import { Achievements, Economy, DevMode, Rewards } from "./screens/gamification.js";
import { Science, ScienceTopic, Quiz, TipsTricks } from "./screens/science.js";
import { PsQuizSession } from "./screens/psQuiz.js";
import { SubjectHub, SubjectTopic, SubjectQuiz, SubjectPaperViewer } from "./screens/subjectHub.js";
import { WorksheetSession } from "./screens/worksheet.js";
import { ReferenceSheets } from "./screens/referenceSheets.js";

/** Invite-only access password (once-off at first launch). */
export const INVITE_PASSWORD = "childrenofthesun";
export const ACCESS_CODE = "children of the sun";
export const LOCKED_GRADE = 12;
export const SUPPORTED_GRADES = [12];
export const PRODUCT = "Learnly for the grade 12s";
export const OWNER = "The Elites Academy";
export const SINGLE_CODE = "G12";

const SESSION_KEY = "learnly_g12:session_active";
const INVITE_KEY = "learnly_g12:invite_ok";

const SCREENS = {
  login: Login, home: Home, learn: Learn, topicDetail: TopicDetail, topicDetailLite: TopicDetailLite,
  practiceSetup: PracticeSetup, practiceSession: PracticeSession, papers: Papers, paperViewer: PaperViewer,
  profile: Profile, settings: Settings, diagramGallery: DiagramGallery, labs: Labs, theoremLab: TheoremLab, theoremRound: TheoremRound, workshopSession: WorkshopSession, geometryLab: GeometryLab, dataLab: DataLab,
  probabilityLab: ProbabilityLab, mental: Mental, solidsLab: SolidsLab, teachHub: TeachHub, teachDeck: TeachDeck, structuredPractice: StructuredPractice, structuredHub: StructuredHub,
  achievements: Achievements, economy: Economy, rewards: Rewards, devMode: DevMode,
  science: Science, scienceTopic: ScienceTopic, quiz: Quiz, tipsTricks: TipsTricks,
  psQuizSession: PsQuizSession,
  subjectHub: SubjectHub, subjectTopic: SubjectTopic, subjectQuiz: SubjectQuiz, subjectPaperViewer: SubjectPaperViewer, worksheet: WorksheetSession,
  referenceSheets: ReferenceSheets
};

export const app = {
  student: null,
  history: [],
  _current: null,

  gradeManager() { return new GradeManager(this.student?.grade ?? LOCKED_GRADE); },
  questionEngine() { return new UnifiedQuestionEngine(this.student?.grade ?? LOCKED_GRADE); },

  saveStudent() { if (this.student) db.writeStudentRaw(this.student); },
  loadStudentByCode(code) { return db.readStudentRaw(code); },
  saveStudentByCode(student) { db.writeStudentRaw(student); },

  applyThemeAndFont() {
    const s = this.student?.settings || {};
    applyTheme(s.theme || "Candy", s.font_scale || "Normal");
  },
  syncAudioFromSettings() {
    const s = this.student?.settings || {};
    try { syncFromSettings(s); } catch (e) { /* audio optional */ }
  },

  async navigate(name, params = {}) {
    if (this._current) this.history.push(this._current);
    await this._render(name, params);
  },
  async replace(name, params = {}) { await this._render(name, params); },
  async resetTo(name, params = {}) { this.history = []; await this._render(name, params); },
  async goBack() {
    const prev = this.history.pop();
    if (prev) await this._render(prev.name, prev.params);
    else await this._render("home", {});
  },
  async refreshCurrentScreen() {
    if (this._current) await this._render(this._current.name, this._current.params, true);
  },

  async _render(name, params, isRefresh = false) {
    const fn = SCREENS[name];
    if (!fn) { console.error("Unknown screen:", name); return; }
    if (this._cleanup) { try { this._cleanup(); } catch { /* ignore */ } this._cleanup = null; }
    if (this.student && name !== "login") this.saveStudent();
    const root = document.getElementById("app");
    root.innerHTML = "";
    root.className = "";
    let def;
    try {
      def = await fn(this, params);
    } catch (err) {
      console.error(err);
      def = {
        title: "Oops",
        showBack: true,
        body: [el("div", { class: "card" }, [
          el("div", { class: "role-heading" }, "Something went wrong"),
          el("div", { class: "role-subtitle wrap" }, String(err && err.message || err))
        ])]
      };
    }
    if (!isRefresh) this._current = { name, params };
    this._cleanup = def.onUnmount || null;
    this._mount(def);
  },

  _mount(def) {
    const root = document.getElementById("app");
    const showBack = def.showBack === false ? false : true;
    const top = !showBack
      ? el("div", { class: "screen-top" }, [el("div", { class: "screen-title" }, def.title)])
      : el("div", { class: "screen-top" }, [
          el("button", { class: "btn-secondary btn-sm", style: "width:2.6rem;flex:none;", onClick: () => this.goBack() }, "←"),
          el("div", { class: "screen-title" }, def.title)
        ]);
    const screen = el("div", { class: "screen" }, [top, el("div", { class: "screen-body" }, def.body || [])]);
    if (def.bottomNavKey) root.className = "has-bottomnav";
    root.appendChild(screen);
    if (def.bottomNavKey) root.appendChild(bottomNav(this, def.bottomNavKey));
    window.scrollTo(0, 0);
  },

  showHome() { return this.resetTo("home"); },
  showLearn() {
    const sub = this.student?.subject || "maths";
    if (sub === "physical_sciences") return this.navigate("science");
    if (sub === "life_sciences" || sub === "accounting") return this.navigate("subjectHub");
    return this.navigate("learn");
  },
  showTopicDetail(topicId) {
    return this.navigate("topicDetailLite", { topicId });
  },
  showTopicPicker() { return this.navigate("practiceSetup", { mode: "choose" }); },
  showPractice(mode, topics) {
    const sub = this.student?.subject || "maths";
    if (sub === "physical_sciences") {
      // Always stay in Physical Sciences — never fall through to NS/generic
      if (topics && topics.length && String(topics[0]).startsWith("ps_")) {
        return this.navigate("practiceSetup", { mode, topics });
      }
      return this.navigate("science");
    }
    if (sub === "life_sciences" || sub === "accounting") {
      return this.navigate("subjectHub");
    }
    return this.navigate("practiceSetup", { mode, topics });
  },
  launchPracticeSession(opts) { return this.navigate("practiceSession", opts); },
  showPapers() {
    return this.navigate("papers", { view: "hub" });
  },
  showPaperViewer(paperId, opts = {}) { return this.navigate("paperViewer", { paperId, ...opts }); },
  showProfile() { return this.navigate("profile"); },
  showSettings() { return this.navigate("settings"); },
  showDiagramGallery() { return this.navigate("diagramGallery"); },
  showLabs() { return this.navigate("labs"); },
  showGeometryLab() { return this.navigate("geometryLab"); },
  showDataLab() { return this.navigate("dataLab"); },
  showProbabilityLab() { return this.navigate("probabilityLab"); },
  showMental() { return this.navigate("mental"); },
  showScience() { return this.navigate("science"); },
  showWorksheet(opts = {}) { return this.navigate("worksheet", opts); },
  showSubjectHub() {
    const sub = this.student?.subject || "maths";
    if (sub === "physical_sciences") return this.navigate("science");
    if (sub === "maths") return this.navigate("learn");
    if (sub === "life_sciences" || sub === "accounting") return this.navigate("subjectHub");
    // Never route unknown subjects to natural sciences
    return this.navigate("learn");
  },
  showScienceTopic(topicId) { return this.navigate("scienceTopic", { topicId }); },
  showQuiz(subject = "math", topicId = null) { return this.navigate("quiz", { subject, topicId }); },
  showTipsTricks() { return this.navigate("tipsTricks"); },
  showAchievements() { return this.navigate("achievements"); },
  showEconomy() { return this.navigate("economy"); },
  showRewards() { return this.navigate("rewards"); },
  showTeach() { return this.navigate("teachHub"); },
  showStructured() { return this.navigate("structuredHub"); },
  showSolidsLab() { return this.navigate("solidsLab"); },
  showReferenceSheets() { return this.navigate("referenceSheets"); },

  async showDevModeGate() {
    const code = await showPrompt("Dev Mode", "Access code:", "", true);
    if (code === null) return;
    if (code.trim().toLowerCase() === ACCESS_CODE) this.navigate("devMode");
    else showAlert("Access denied", "Incorrect code.");
  },

  // -------- auth (Grade 12 lock) --------
  async login(code, grade = LOCKED_GRADE, name = null, opts = {}) {
    const g = LOCKED_GRADE;
    this.student = db.login(code || SINGLE_CODE, g, name);
    this.student.grade = LOCKED_GRADE;
    this.student.programme_name = this.student.programme_name || OWNER;
    if (opts && opts.gender) this.student.gender = opts.gender;
    if (opts && opts.theme) {
      this.student.settings = this.student.settings || {};
      this.student.settings.theme = opts.theme;
      try {
        const { applyTheme } = await import("./theme.js");
        applyTheme(opts.theme, this.student.settings.font_scale || "Normal");
      } catch { /* ignore */ }
    }
    try {
      const { loadSubjectRegistry, defaultSubject } = await import("./engines/subjectRegistry.js");
      await loadSubjectRegistry();
      this.student.subject = this.student.subject || defaultSubject(LOCKED_GRADE);
      const allowed = ["maths", "physical_sciences", "life_sciences", "accounting"];
      if (!allowed.includes(this.student.subject)) this.student.subject = "maths";
    } catch {
      this.student.subject = this.student.subject || "maths";
    }
    this.student.settings = this.student.settings || {};
    if (opts.theme) this.student.settings.theme = opts.theme;
    try {
      const { EconomyEngine } = await import("./engines/economyEngine.js");
      const granted = new EconomyEngine(this.student).grantStarterStars(2000);
      if (granted) this.saveStudent();
    } catch { /* ignore */ }
    this.saveStudent();
    try { localStorage.setItem(SESSION_KEY, "1"); } catch { /* ignore */ }
    this.applyThemeAndFont();
    this.syncAudioFromSettings();
    await this.resetTo("home");
  },

  async logout() {
    // Soft sign-out only clears in-memory state; invite remains valid and profile stays.
    this.saveStudent();
    this.student = null;
    this.history = [];
    try { localStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
    await this.resetTo("login");
  },

  async changeGrade() {
    showAlert("Grade locked", "This build is Grade 12 only.");
  }
};

function inviteAccepted() {
  try { return localStorage.getItem(INVITE_KEY) === "1"; } catch { return false; }
}
function markInviteAccepted() {
  try { localStorage.setItem(INVITE_KEY, "1"); } catch { /* ignore */ }
}
function sessionActive() {
  try { return localStorage.getItem(SESSION_KEY) === "1"; } catch { return false; }
}

async function showInviteGate() {
  const root = document.getElementById("app");
  root.innerHTML = "";
  root.className = "";
  applyTheme("Midnight", "Normal");

  const pw = el("input", {
    type: "password",
    placeholder: "Enter invite password",
    autocomplete: "current-password",
    style: "width:100%;letter-spacing:0.08em;font-size:1.05rem;padding:0.85rem 1rem;border-radius:0.75rem;"
  });

  const status = el("div", {
    class: "role-muted wrap center",
    style: "min-height:1.3rem;margin-top:0.35rem;font-weight:600;"
  }, "");

  const enter = async () => {
    const val = (pw.value || "").trim();
    if (val === INVITE_PASSWORD) {
      markInviteAccepted();
      status.textContent = "Access granted · preparing your workspace…";
      status.style.color = "#34d399";
      await bootAfterInvite();
    } else {
      status.textContent = "Incorrect password. This app is invite only.";
      status.style.color = "#f87171";
      pw.value = "";
      pw.focus();
    }
  };

  pw.addEventListener("keydown", (e) => { if (e.key === "Enter") enter(); });

  const subjects = el("div", {
    style: "display:grid;grid-template-columns:1fr 1fr;gap:0.45rem;margin:0.85rem 0 1rem;"
  }, [
    ["📘 Mathematics", "P1 · P2"],
    ["🔬 Physical Sciences", "Physics · Chemistry"],
    ["🧬 Life Sciences", "CAPS topics"],
    ["📒 Accounting", "Journals · statements"]
  ].map(([t, s]) => el("div", {
    style: "padding:0.55rem 0.6rem;border-radius:0.65rem;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.08);"
  }, [
    el("div", { style: "font-weight:700;font-size:0.82rem;" }, t),
    el("div", { style: "opacity:0.7;font-size:0.72rem;margin-top:0.15rem;" }, s)
  ])));

  const panel = el("div", {
    style: "max-width:24rem;width:100%;margin:0 auto;padding:1.5rem 1.35rem 1.4rem;border-radius:1.25rem;" +
      "background:linear-gradient(160deg,rgba(30,41,59,0.95),rgba(15,23,42,0.98));" +
      "border:1px solid rgba(148,163,184,0.18);box-shadow:0 24px 60px rgba(0,0,0,0.45);"
  }, [
    el("div", {
      style: "display:inline-block;padding:0.28rem 0.65rem;border-radius:999px;font-size:0.7rem;font-weight:800;" +
        "letter-spacing:0.08em;text-transform:uppercase;background:rgba(251,191,36,0.15);color:#fbbf24;margin-bottom:0.85rem;"
    }, "Invite only"),
    el("div", { style: "font-size:1.7rem;font-weight:800;letter-spacing:-0.03em;line-height:1.2;" }, "Learnly for the grade 12s"),
    el("div", { style: "margin-top:0.4rem;opacity:0.88;font-size:0.95rem;" }, "Owned by The Elites Academy"),
    el("div", {
      style: "margin-top:0.85rem;padding:0.7rem 0.8rem;border-radius:0.75rem;background:rgba(99,102,241,0.12);" +
        "border:1px solid rgba(129,140,248,0.25);font-size:0.88rem;line-height:1.45;"
    }, "Private CAPS Grade 12 workspace. Unlock once with your invite password — Mathematics, Physical Sciences, Life Sciences and Accounting."),
    subjects,
    el("label", { class: "field-label", style: "opacity:0.9;" }, "Invite password"),
    pw,
    el("button", {
      class: "btn",
      style: "margin-top:0.85rem;width:100%;padding:0.9rem;font-weight:800;border-radius:0.75rem;" +
        "background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;",
      onClick: enter
    }, "Unlock access"),
    status,
    el("div", {
      style: "margin-top:1.1rem;text-align:center;font-size:0.75rem;opacity:0.55;line-height:1.4;"
    }, "One-time unlock on this device · then sign in once and stay signed in")
  ]);

  root.appendChild(el("div", {
    class: "screen",
    style: "display:flex;align-items:center;justify-content:center;min-height:100dvh;padding:1.25rem;" +
      "background:radial-gradient(ellipse at 20% 10%,rgba(99,102,241,0.25),transparent 50%)," +
      "radial-gradient(ellipse at 80% 90%,rgba(139,92,246,0.2),transparent 45%),#0B1220;"
  }, [panel]));

  setTimeout(() => pw.focus(), 80);
}

async function bootAfterInvite() {
  applyTheme("Candy", "Normal");
  // Restore session if student already signed in on this device
  if (sessionActive()) {
    const existing = db.readStudentRaw(SINGLE_CODE);
    if (existing && existing.name) {
      app.student = existing;
      app.student.grade = LOCKED_GRADE;
      app.student.programme_name = app.student.programme_name || OWNER;
      try {
        const { loadSubjectRegistry, defaultSubject } = await import("./engines/subjectRegistry.js");
        await loadSubjectRegistry();
        const allowed = ["maths", "physical_sciences", "life_sciences", "accounting"];
        if (!app.student.subject || !allowed.includes(app.student.subject)) {
          app.student.subject = defaultSubject(LOCKED_GRADE);
        }
      } catch {
        app.student.subject = app.student.subject || "maths";
      }
      app.applyThemeAndFont();
      app.syncAudioFromSettings();
      await app.resetTo("home");
      return;
    }
  }
  await app.resetTo("login");
}

export async function boot() {
  try {
    await preloadGrades();
  } catch (err) {
    document.getElementById("app").innerHTML =
      `<div class="screen"><div class="card"><div class="role-heading">Could not load Learnly</div><div class="role-subtitle wrap">${String(err.message || err)}</div></div></div>`;
    return;
  }

  if (!inviteAccepted()) {
    await showInviteGate();
    return;
  }
  await bootAfterInvite();
}
