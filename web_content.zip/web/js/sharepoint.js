/**
 * Manejo de la autenticación y descarga del archivo Excel desde SharePoint corporativo de Metro.
 */

class SharePointManager {
  constructor(config) {
    this.urlTurnos = config.urlExcelTurnos;
    this.urlEventos = config.urlExcelEventos;
  }

  /**
   * Abre la ventana corporativa oficial de Microsoft / SharePoint de Metro para que
   * el empleado inicie sesión con su usuario y contraseña corporativos.
   */
  iniciarLoginSharePoint() {
    const ancho = 500;
    const alto = 650;
    const izquierda = (window.innerWidth - ancho) / 2;
    const arriba = (window.innerHeight - alto) / 2;

    const popup = window.open(
      this.urlTurnos,
      'SharePointMetroLogin',
      `width=${ancho},height=${alto},top=${arriba},left=${izquierda},resizable=yes,scrollbars=yes,status=yes`
    );

    return popup;
  }

  /**
   * Intenta descargar el archivo binario directamente usando las cookies de sesión del navegador.
   */
  async descargarArchivoDirecto() {
    // Generar URL de descarga directa binaria
    let downloadUrl = this.urlTurnos;
    if (downloadUrl.includes('Doc.aspx')) {
      downloadUrl = downloadUrl.replace('Doc.aspx', 'download.aspx');
    }

    try {
      const res = await fetch(downloadUrl, {
        method: 'GET',
        credentials: 'include', // Incluir cookies corporativas de Microsoft / SharePoint
        headers: {
          'Accept': 'application/vnd.ms-excel.sheet.macroEnabled.12,application/octet-stream,*/*'
        }
      });

      if (!res.ok) {
        throw new Error(`Servidor SharePoint respondió con estado: ${res.status}`);
      }

      const buffer = await res.arrayBuffer();
      return buffer;
    } catch (e) {
      throw new Error(`No se pudo descargar automáticamente: ${e.message}`);
    }
  }
}

const sharepointManager = new SharePointManager(SHAREPOINT_CONFIG);
