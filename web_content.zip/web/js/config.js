/**
 * Configuración oficial de Supabase, SharePoint y diccionario visual de servicios.
 */

const SUPABASE_CONFIG = {
  url: "https://zpgvexfioncgxmhthdqa.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpwZ3ZleGZpb25jZ3htaHRoZHFhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTEyMjI1OTEsImV4cCI6MjEwNjc5ODU5MX0.5YqZuw7msxrdWUHRiDWhj1pXlo5yrQcekmcR8Z7P1P0"
};

const SHAREPOINT_CONFIG = {
  // Endpoint nativo de descarga directa binaria (evita que SharePoint abra el visor de Excel Online)
  urlExcelTurnos: "https://tmbbcn.sharepoint.com/sites/LC/_layouts/15/download.aspx?UniqueId=6de76f6c-dbb9-47c0-a508-8d5ef627ca79",
  urlExcelTurnosFallback: "https://tmbbcn.sharepoint.com/sites/LC/_layouts/15/download.aspx?sourcedoc=%7B6DE76F6C-DBB9-47C0-A508-8D5EF627CA79%7D",
  urlExcelEventos: "https://tmbbcn.sharepoint.com/:x:/r/sites/LC/Documents%20COL%20L1/CTO/CALENDARIO%20EVENTOS.xlsx?d=w0543e9e1e63643bbb085783700e05c79&download=1"
};

const LETRAS_POR_FRANJA = {
  MANANA: ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'ST2', 'ST9', 'ST4'],
  TARDE: ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'CR7', 'R8', 'R9', 'SR5', 'SR6'],
  NOCHE: ['N1', 'N2', 'N3', 'N5', 'N5.1', 'N6', 'N1T', 'N6R']
};

const SERVICIOS_INFO = {
  'CC': { desc: 'Panel Circulación', bg: '#F8C3A4', color: '#000000', border: null },
  'CE': { desc: 'Panel Estaciones', bg: '#B9D7F2', color: '#000000', border: null },
  'TL': { desc: 'Titular de línea', bg: '#C6E0B4', color: '#000000', border: null },
  'CC1': { desc: 'CC parcial', bg: '#F8C3A4', color: '#000000', border: null },
  'CE1': { desc: 'CE parcial', bg: '#B9D7F2', color: '#000000', border: null },
  'TL1': { desc: 'TL parcial', bg: '#C6E0B4', color: '#000000', border: null },
  'FR': { desc: 'Formación', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'FI': { desc: 'Impartir formación', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  't': { desc: 'Servicio t', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  '': { desc: 'Sin asignar', bg: '#F3F4F6', color: '#6B7280', border: '#E5E7EB' },
  '-': { desc: 'Sin asignar', bg: '#F3F4F6', color: '#6B7280', border: '#E5E7EB' },
  'RM': { desc: 'Revisión Médica', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'A': { desc: 'Accidente', bg: '#000000', color: '#FF3B30', border: null },
  'E': { desc: 'Enfermedad', bg: '#2E2E2E', color: '#FF3B30', border: null },
  'AS': { desc: 'Asunto Sindical', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'D': { desc: 'Descanso (DCOM)', bg: '#2E2E2E', color: '#FFFFFF', border: null },
  'F': { desc: 'Festivo (FEST)', bg: '#2E2E2E', color: '#FFFFFF', border: null },
  'RJ': { desc: 'RJ', bg: '#FF6E00', color: '#000000', border: null },
  'V': { desc: 'Vacaciones', bg: '#FF6E00', color: '#000000', border: null },
  'FA': { desc: 'Fiesta Abonable', bg: '#2E2E2E', color: '#FFFFFF', border: null },
  'DA': { desc: 'Descanso Abonable', bg: '#2E2E2E', color: '#FFFFFF', border: null },
  'P': { desc: 'Permiso', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' }
};

function obtenerInfoServicio(codigo) {
  const cod = (codigo || '').trim();
  if (SERVICIOS_INFO[cod]) return SERVICIOS_INFO[cod];
  return {
    desc: cod ? `Servicio ${cod}` : 'Sin asignar',
    bg: '#E2E8F0',
    color: '#1E293B',
    border: null
  };
}

// =================== ORDEN OFICIAL DE LETRAS SEGÚN CUADRANTE ANDROID ===================
// MAÑANA: 1..12 (T1..T9, ST2, ST9, ST4)
// TARDE: 21..30 (R1..R6, CR7, R8, R9, SR5, SR6)
// NOCHE: 31..38 (N1, N2, N3, N5, N5.1, N6, N1T, N6R)
const ORDEN_LETRAS_OFICIAL = {
  // MAÑANA
  'T1': 1, 'T2': 2, 'T3': 3, 'T4': 4, 'T5': 5, 'T6': 6,
  'T7': 7, 'T8': 8, 'T9': 9, 'ST2': 10, 'ST9': 11, 'ST4': 12,
  // TARDE
  'R1': 21, 'R2': 22, 'R3': 23, 'R4': 24, 'R5': 25, 'R6': 26,
  'CR7': 27, 'R8': 28, 'R9': 29, 'SR5': 30, 'SR6': 30,
  // NOCHE
  'N1': 31, 'N2': 32, 'N3': 33, 'N5': 34, 'N5.1': 35,
  'N6': 36, 'N1T': 37, 'N6R': 38
};

function obtenerOrdenLetraOficial(letraRaw) {
  const l = (letraRaw || '').trim().toUpperCase();
  return ORDEN_LETRAS_OFICIAL[l] !== undefined ? ORDEN_LETRAS_OFICIAL[l] : 99;
}

const ORDEN_FRANJAS = {
  'MAÑANA': 1, 'MANANA': 1,
  'TARDE': 2,
  'NOCHE': 3
};

// =================== PRIORIDAD OFICIAL DE SERVICIOS SEGÚN ANDROID ===================
// En filtros de turno individual (MAÑANA, TARDE, NOCHE), se ordenan por tipo de servicio:
// 1. CC, 2. CE, 3. TL, 4. CC1, 5. CE1, 6. TL1, 7. FR, 8. FI, 9. t, 10. Vacío/-, 11. A, 12. E,
// 13. AS, 14. D, 15. F, 16. RJ, 17. V, 18. FA, 19. DA, 20. P, 21. RM
const PRIORIDAD_SERVICIOS = {
  'CC': 1,
  'CE': 2,
  'TL': 3,
  'CC1': 4,
  'CE1': 5,
  'TL1': 6,
  'FR': 7,
  'FI': 8,
  't': 9,
  '': 10,
  '-': 10,
  'A': 11,
  'E': 12,
  'AS': 13,
  'D': 14,
  'F': 15,
  'RJ': 16,
  'V': 17,
  'FA': 18,
  'DA': 19,
  'P': 20,
  'RM': 21
};

function obtenerPrioridadServicio(codigoRaw) {
  const clave = (codigoRaw || '').trim();
  if (!clave || clave === '-') return 10;
  if (PRIORIDAD_SERVICIOS[clave] !== undefined) return PRIORIDAD_SERVICIOS[clave];
  if (PRIORIDAD_SERVICIOS[clave.toUpperCase()] !== undefined) return PRIORIDAD_SERVICIOS[clave.toUpperCase()];
  return 99;
}

// URLs públicas con CORS habilitado en Supabase Storage para descarga directa 100% transparente
const SUPABASE_STORAGE_CONFIG = {
  cuadranteUrl: 'https://zpgvexfioncgxmhthdqa.supabase.co/storage/v1/object/public/app-releases/cuadrante.xlsm',
  eventosUrl: 'https://zpgvexfioncgxmhthdqa.supabase.co/storage/v1/object/public/app-releases/eventos.xlsx'
};

// Orden oficial de conceptos de cómputo para el detalle de empleado
const ORDEN_CONCEPTOS_OFICIAL = [
  'V pendientes 2026', 'RJ pendientes 2026', 'Contingente RJ 2026', 'Contingente Vacaciones',
  'Cómputo 26', 'Cómputo pendiente 25', 'RJ pendientes 25', 'V pendientes 25',
  'DCOM', 'FEST', 'RJ', 'Vacaciones', 'Formación', 'Impartir formación',
  'Titular de línea', 'Panel Circulación', 'Panel Estaciones', 'TL parcial', 'CC parcial', 'CE parcial',
  'Accidente', 'Enfermedad', 'Asunto Sindical', 'Fiesta OTRO AÑO', 'DCOM OTRO AÑO', 'PERMISOS'
];

