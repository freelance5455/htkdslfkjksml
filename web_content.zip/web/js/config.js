/**
 * Configuración oficial de Supabase, SharePoint y diccionario visual de servicios.
 */

const SUPABASE_CONFIG = {
  url: "https://zpgvexfioncgxmhthdqa.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpwZ3ZleGZpb25jZ3htaHRoZHFhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTEyMjI1OTEsImV4cCI6MjEwNjc5ODU5MX0.5YqZuw7msxrdWUHRiDWhj1pXlo5yrQcekmcR8Z7P1P0"
};

const SHAREPOINT_CONFIG = {
  // Endpoint nativo de descarga directa binaria (evita que SharePoint abra el visor de Excel Online)
  urlExcelTurnos: "https://tmbbcn.sharepoint.com/sites/LC/_layouts/15/download.aspx?UniqueId=6de76f6c-dbb9-47c0-a508-8d5ef627ca79",
  urlExcelTurnosFallback: "https://tmbbcn.sharepoint.com/sites/LC/_layouts/15/download.aspx?sourcedoc=%7B6DE76F6C-DBB9-47C0-A508-8D5EF627CA79%7D",
  urlExcelEventos: "https://tmbbcn.sharepoint.com/:x:/r/sites/LC/Documents%20COL%20L1/CTO/CALENDARIO%20EVENTOS.xlsx?d=w0543e9e1e63643bbb085783700e05c79&download=1"
};

const LETRAS_POR_FRANJA = {
  MANANA: ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'ST2', 'ST9', 'ST4'],
  TARDE: ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'CR7', 'R8', 'R9', 'SR5', 'SR6'],
  NOCHE: ['N1', 'N2', 'N3', 'N5', 'N5.1', 'N6', 'N1T', 'N6R']
};

const SERVICIOS_INFO = {
  'CC': { desc: 'Panel Circulación', bg: '#F8C3A4', color: '#000000', border: null },
  'CE': { desc: 'Panel Estaciones', bg: '#B9D7F2', color: '#000000', border: null },
  'TL': { desc: 'Titular de línea', bg: '#C6E0B4', color: '#000000', border: null },
  'CC1': { desc: 'CC parcial', bg: '#F8C3A4', color: '#000000', border: null },
  'CE1': { desc: 'CE parcial', bg: '#B9D7F2', color: '#000000', border: null },
  'TL1': { desc: 'TL parcial', bg: '#C6E0B4', color: '#000000', border: null },
  'FR': { desc: 'Formación', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'FI': { desc: 'Impartir formación', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  't': { desc: 'Servicio t', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  '': { desc: 'Sin asignar', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  '-': { desc: 'Sin asignar', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'RM': { desc: 'Revisión Médica', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'A': { desc: 'Accidente', bg: '#000000', color: '#FF0000', border: null },
  'E': { desc: 'Enfermedad', bg: '#2E2E2E', color: '#FF0000', border: null },
  'AS': { desc: 'Asunto Sindical', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'D': { desc: 'DCOM', bg: '#2E2E2E', color: '#FFFFFF', border: null },
  'F': { desc: 'FEST', bg: '#2E2E2E', color: '#FFFFFF', border: null },
  'RJ': { desc: 'RJ', bg: '#FF6E00', color: '#000000', border: null },
  'V': { desc: 'Vacaciones', bg: '#FF6E00', color: '#000000', border: null },
  'FA': { desc: 'Fiesta OTRO AÑO', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'DA': { desc: 'DCOM OTRO AÑO', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' },
  'P': { desc: 'PERMISOS', bg: '#FFFFFF', color: '#000000', border: '#D1D5DB' }
};

function obtenerInfoServicio(codigo) {
  const cod = (codigo || '').trim();
  if (SERVICIOS_INFO[cod]) return SERVICIOS_INFO[cod];
  if (SERVICIOS_INFO[cod.toUpperCase()]) return SERVICIOS_INFO[cod.toUpperCase()];
  return {
    desc: cod ? `Servicio ${cod}` : 'Sin asignar',
    bg: '#F1F5F9',
    color: '#1E293B',
    border: '#CBD5E1'
  };
}

// Configuración semántica y visual oficial por Franja de Turno idéntica a Android
const FRANJAS_CONFIG = {
  'MAÑANA': {
    border: '#F59E0B',
    container: 'rgba(254, 243, 199, 0.5)',
    chip: '#D97706',
    nombre: 'MAÑANA',
    horario: '06:00 - 14:00'
  },
  'MANANA': {
    border: '#F59E0B',
    container: 'rgba(254, 243, 199, 0.5)',
    chip: '#D97706',
    nombre: 'MAÑANA',
    horario: '06:00 - 14:00'
  },
  'TARDE': {
    border: '#38BDF8',
    container: 'rgba(224, 242, 254, 0.6)',
    chip: '#0284C7',
    nombre: 'TARDE',
    horario: '14:00 - 22:00'
  },
  'NOCHE': {
    border: '#A78BFA',
    container: 'rgba(237, 233, 254, 0.6)',
    chip: '#7C3AED',
    nombre: 'NOCHE',
    horario: '22:00 - 06:00'
  }
};

function obtenerColoresFranja(franjaRaw) {
  const f = (franjaRaw || '').trim().toUpperCase();
  if (FRANJAS_CONFIG[f]) return FRANJAS_CONFIG[f];
  return {
    border: '#CBD5E1',
    container: 'rgba(223, 226, 235, 0.4)',
    chip: '#64748B',
    nombre: f || 'TODAS',
    horario: 'Cuadrante CTO'
  };
}

// Configuración de líneas de Metro de Barcelona para coberturas de servicio
const METRO_LINEAS_CONFIG = {
  'L1': { bg: '#E52320', color: '#FFFFFF', nombre: 'L1' },
  'L2': { bg: '#7C3AED', color: '#FFFFFF', nombre: 'L2' },
  'L3': { bg: '#16A34A', color: '#FFFFFF', nombre: 'L3' },
  'L4': { bg: '#F59E0B', color: '#000000', nombre: 'L4' },
  'L5': { bg: '#0284C7', color: '#FFFFFF', nombre: 'L5' }
};

function parsearLineasMetro(lineasStr) {
  if (!lineasStr) return [];
  return lineasStr.split(',')
    .map(l => l.trim().toUpperCase())
    .filter(Boolean)
    .map(l => METRO_LINEAS_CONFIG[l] || { bg: '#64748B', color: '#FFFFFF', nombre: l });
}

// =================== ORDEN OFICIAL DE LETRAS SEGÚN CUADRANTE ANDROID ===================
// MAÑANA: 1..12 (T1..T9, ST2, ST9, ST4)
// TARDE: 21..30 (R1..R6, CR7, R8, R9, SR5, SR6)
// NOCHE: 31..38 (N1, N2, N3, N5, N5.1, N6, N1T, N6R)
const ORDEN_LETRAS_OFICIAL = {
  // MAÑANA
  'T1': 1, 'T2': 2, 'T3': 3, 'T4': 4, 'T5': 5, 'T6': 6,
  'T7': 7, 'T8': 8, 'T9': 9, 'ST2': 10, 'ST9': 11, 'ST4': 12,
  // TARDE
  'R1': 21, 'R2': 22, 'R3': 23, 'R4': 24, 'R5': 25, 'R6': 26,
  'CR7': 27, 'R8': 28, 'R9': 29, 'SR5': 30, 'SR6': 30,
  // NOCHE
  'N1': 31, 'N2': 32, 'N3': 33, 'N5': 34, 'N5.1': 35,
  'N6': 36, 'N1T': 37, 'N6R': 38
};

function obtenerOrdenLetraOficial(letraRaw) {
  const l = (letraRaw || '').trim().toUpperCase();
  return ORDEN_LETRAS_OFICIAL[l] !== undefined ? ORDEN_LETRAS_OFICIAL[l] : 99;
}

const ORDEN_FRANJAS = {
  'MAÑANA': 1, 'MANANA': 1,
  'TARDE': 2,
  'NOCHE': 3
};

// =================== PRIORIDAD OFICIAL DE SERVICIOS SEGÚN ANDROID ===================
// En filtros de turno individual (MAÑANA, TARDE, NOCHE), se ordenan por tipo de servicio:
// 1. CC, 2. CE, 3. TL, 4. CC1, 5. CE1, 6. TL1, 7. FR, 8. FI, 9. t, 10. Vacío/-, 11. A, 12. E,
// 13. AS, 14. D, 15. F, 16. RJ, 17. V, 18. FA, 19. DA, 20. P, 21. RM
const PRIORIDAD_SERVICIOS = {
  'CC': 1,
  'CE': 2,
  'TL': 3,
  'CC1': 4,
  'CE1': 5,
  'TL1': 6,
  'FR': 7,
  'FI': 8,
  't': 9,
  '': 10,
  '-': 10,
  'A': 11,
  'E': 12,
  'AS': 13,
  'D': 14,
  'F': 15,
  'RJ': 16,
  'V': 17,
  'FA': 18,
  'DA': 19,
  'P': 20,
  'RM': 21
};

function obtenerPrioridadServicio(codigoRaw) {
  const clave = (codigoRaw || '').trim();
  if (!clave || clave === '-') return 10;
  if (PRIORIDAD_SERVICIOS[clave] !== undefined) return PRIORIDAD_SERVICIOS[clave];
  if (PRIORIDAD_SERVICIOS[clave.toUpperCase()] !== undefined) return PRIORIDAD_SERVICIOS[clave.toUpperCase()];
  return 99;
}

// URLs públicas con CORS habilitado en Supabase Storage para descarga directa 100% transparente
const SUPABASE_STORAGE_CONFIG = {
  cuadranteUrl: 'https://zpgvexfioncgxmhthdqa.supabase.co/storage/v1/object/public/app-releases/cuadrante.xlsm',
  eventosUrl: 'https://zpgvexfioncgxmhthdqa.supabase.co/storage/v1/object/public/app-releases/eventos.xlsx'
};

// Orden oficial de conceptos de cómputo para el detalle de empleado
const ORDEN_CONCEPTOS_OFICIAL = [
  'V pendientes 2026', 'RJ pendientes 2026', 'Contingente RJ 2026', 'Contingente Vacaciones',
  'Cómputo 26', 'Cómputo pendiente 25', 'RJ pendientes 25', 'V pendientes 25',
  'DCOM', 'FEST', 'RJ', 'Vacaciones', 'Formación', 'Impartir formación',
  'Titular de línea', 'Panel Circulación', 'Panel Estaciones', 'TL parcial', 'CC parcial', 'CE parcial',
  'Accidente', 'Enfermedad', 'Asunto Sindical', 'Fiesta OTRO AÑO', 'DCOM OTRO AÑO', 'PERMISOS'
];

// Directorio telefónico oficial Metro L1 (DirectorioTelefonico.kt)
const DIRECTORIO_TELEFONICO_OFICIAL = {
  // Franja MAÑANA
  "2010208": "65704", "10208": "65704", // Mateo Pardo, Ferran (T1)
  "2007337": "65523", "7337": "65523",  // Herranz Blasco, Marta (T2)
  "2007686": "65637", "7686": "65637",  // Durán Franch, Carlos (T3)
  "2005278": "65537", "5278": "65537",  // Batlle Ruiz, Jordi (T4)
  "2007430": "65539", "7430": "65539",  // Nogueira Otero, Miguel Angel (T5)
  "2009660": "65548", "9660": "65548",  // Sagarra Liñan, Dídac (T6)
  "2006789": "65538", "6789": "65538",  // Camacho Portales, Jose Luis (T7)
  "2010205": "65705", "10205": "65705", // Homs Betes, Andreu (T8)
  "2008773": "65367", "8773": "65367",  // Arroyo Prieto, Jonatan (T9)
  "2010211": "65706", "10211": "65706", // Maestre Prieto, Daniel (ST2)
  "2007663": "65649", "7663": "65649",  // Marsà Manteca, Daniel (ST9)
  "2010990": "60832", "10990": "60832", // Martin Junqueras, Aida (ST4)

  // Franja TARDE
  "2010696": "60813", "10696": "60813", // Morote Gómez, Ismael (R1)
  "2010055": "65957", "10055": "65957", // Yechou Chelli, Sohail (R2)
  "2010255": "64702", "10255": "64702", // Ceña Aznar, Judit (R3)
  "2009518": "64206", "9518": "64206",  // Alvarez Cano, Rubén (R4)
  "2010623": "66213", "10623": "66213", // López Martínez, Mónica (R5)
  "2010498": "64302", "10498": "64302", // Argüello Lopez, Martin (R6)
  "2005209": "67012", "5209": "67012",  // Prieto Caballero, Juan Pablo (CR7)
  "2009527": "65909", "9527": "65909",  // El Matalsi El Kouhli, Mostafa (R8)
  "2009266": "67002", "9266": "67002",  // Morales Torrecillas, Rubén (R9)
  "2010148": "",                        // Ruiz Fernández, Victor (Sin teléfono)
  "2010992": "62427", "10992": "62427", // Patxot Silva, Edgar (SR6)

  // Franja NOCHE
  "2010649": "63462", "10649": "63462", // Arasnaz Melero, Marta (N1)
  "2010574": "65031", "10574": "65031", // Ares Marquina, Fernando (—)
  "2008354": "65762", "8354": "65762",  // Puerto Oller, Gerard (N2)
  "2010936": "66201", "10936": "66201", // Borrajo Gómez, Cristina (N3)
  "2008378": "65546", "8378": "65546",  // Martin Martin, Jonatan (N5)
  "2010206": "65708", "10206": "65708", // Marin Mora, Oscar Antonio (N5.1)
  "2010807": "64251", "10807": "64251", // Riera Sabaté, Gerard (N6)
  "2010575": "65160", "10575": "65160", // Soler Neira, Pau (N1T)
  "2010983": "62959", "10983": "62959"  // Soto Rivera, Sergio (N6R)
};

function obtenerTelefonoEmpleado(numeroEmpleado) {
  const num = (numeroEmpleado || '').toString().trim();
  if (!num) return '';
  if (DIRECTORIO_TELEFONICO_OFICIAL[num] !== undefined) return DIRECTORIO_TELEFONICO_OFICIAL[num];
  if (num.length >= 4 && num.length <= 5 && DIRECTORIO_TELEFONICO_OFICIAL['20' + num] !== undefined) {
    return DIRECTORIO_TELEFONICO_OFICIAL['20' + num];
  }
  if (num.length === 7 && num.startsWith('20') && DIRECTORIO_TELEFONICO_OFICIAL[num.substring(2)] !== undefined) {
    return DIRECTORIO_TELEFONICO_OFICIAL[num.substring(2)];
  }
  return '';
}

// Censo oficial inicial de empleados Metro L1 idéntico al censo de Android / Supabase
const CENSO_EMPLEADOS_INICIAL_DEFAULT = [
  { numeroEmpleado: '2009518', letra: 'R4', nombreCompleto: 'Alvarez Cano, Rubén', telefono: '64206', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010649', letra: 'N1', nombreCompleto: 'Arasnaz Melero, Marta', telefono: '63462', email: 'maransanz@tmb.cat', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010574', letra: '', nombreCompleto: 'Ares Marquina, Fernando', telefono: '65031', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010498', letra: 'R6', nombreCompleto: 'Argüello Lopez, Martin', telefono: '64302', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2008773', letra: 'T9', nombreCompleto: 'Arroyo Prieto, Jonatan', telefono: '65367', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2005278', letra: 'T4', nombreCompleto: 'Batlle Ruiz, Jordi', telefono: '65537', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010936', letra: 'N3', nombreCompleto: 'Borrajo Gómez, Cristina', telefono: '66201', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2006789', letra: 'T7', nombreCompleto: 'Camacho Portales, Jose Luis', telefono: '65538', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010255', letra: 'R3', nombreCompleto: 'Ceña Aznar, Judit', telefono: '64702', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2007686', letra: 'T3', nombreCompleto: 'Durán Franch, Carlos', telefono: '65637', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2009527', letra: 'R8', nombreCompleto: 'El Matalsi El Kouhli, Mostafa', telefono: '65909', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2007337', letra: 'T2', nombreCompleto: 'Herranz Blasco, Marta', telefono: '65523', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010205', letra: 'T8', nombreCompleto: 'Homs Betes, Andreu', telefono: '65705', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010623', letra: 'R5', nombreCompleto: 'López Martínez, Mónica', telefono: '66213', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010211', letra: 'ST2', nombreCompleto: 'Maestre Prieto, Daniel', telefono: '65706', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010206', letra: 'N5.1', nombreCompleto: 'Marin Mora, Oscar Antonio', telefono: '65708', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2007663', letra: 'ST9', nombreCompleto: 'Marsà Manteca, Daniel', telefono: '65649', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010990', letra: 'ST4', nombreCompleto: 'Martin Junqueras, Aida', telefono: '60832', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2008378', letra: 'N5', nombreCompleto: 'Martin Martin, Jonatan', telefono: '65546', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010208', letra: 'T1', nombreCompleto: 'Mateo Pardo, Ferran', telefono: '65704', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2009266', letra: 'R9', nombreCompleto: 'Morales Torrecillas, Rubén', telefono: '67002', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010696', letra: 'R1', nombreCompleto: 'Morote Gómez, Ismael', telefono: '60813', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2007430', letra: 'T5', nombreCompleto: 'Nogueira Otero, Miguel Angel', telefono: '65539', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010992', letra: 'SR6', nombreCompleto: 'Patxot Silva, Edgar', telefono: '62427', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2005209', letra: 'CR7', nombreCompleto: 'Prieto Caballero, Juan Pablo', telefono: '67012', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2008354', letra: 'N2', nombreCompleto: 'Puerto Oller, Gerard', telefono: '65762', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010807', letra: 'N6', nombreCompleto: 'Riera Sabaté, Gerard', telefono: '64251', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010148', letra: 'SR5', nombreCompleto: 'Ruiz Fernández, Victor', telefono: '', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2009660', letra: 'T6', nombreCompleto: 'Sagarra Liñan, Dídac', telefono: '65548', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010575', letra: 'N1T', nombreCompleto: 'Soler Neira, Pau', telefono: '65160', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010983', letra: 'N6R', nombreCompleto: 'Soto Rivera, Sergio', telefono: '62959', email: '', rol: 'EMPLEADO' },
  { numeroEmpleado: '2010055', letra: 'R2', nombreCompleto: 'Yechou Chelli, Sohail', telefono: '65957', email: '', rol: 'EMPLEADO' }
];

// Lista oficial de los 13 meses del calendario (2026 + Enero 2027) según EmpleadoCalendarioView.kt
const MESES_CALENDARIO = [
  { mesNumero: 1, anio: 2026, nombreMes: "ENERO", chipTexto: "Ene", tituloCompleto: "ENERO 2026" },
  { mesNumero: 2, anio: 2026, nombreMes: "FEBRERO", chipTexto: "Feb", tituloCompleto: "FEBRERO 2026" },
  { mesNumero: 3, anio: 2026, nombreMes: "MARZO", chipTexto: "Mar", tituloCompleto: "MARZO 2026" },
  { mesNumero: 4, anio: 2026, nombreMes: "ABRIL", chipTexto: "Abr", tituloCompleto: "ABRIL 2026" },
  { mesNumero: 5, anio: 2026, nombreMes: "MAYO", chipTexto: "May", tituloCompleto: "MAYO 2026" },
  { mesNumero: 6, anio: 2026, nombreMes: "JUNIO", chipTexto: "Jun", tituloCompleto: "JUNIO 2026" },
  { mesNumero: 7, anio: 2026, nombreMes: "JULIO", chipTexto: "Jul", tituloCompleto: "JULIO 2026" },
  { mesNumero: 8, anio: 2026, nombreMes: "AGOSTO", chipTexto: "Ago", tituloCompleto: "AGOSTO 2026" },
  { mesNumero: 9, anio: 2026, nombreMes: "SEPTIEMBRE", chipTexto: "Sep", tituloCompleto: "SEPTIEMBRE 2026" },
  { mesNumero: 10, anio: 2026, nombreMes: "OCTUBRE", chipTexto: "Oct", tituloCompleto: "OCTUBRE 2026" },
  { mesNumero: 11, anio: 2026, nombreMes: "NOVIEMBRE", chipTexto: "Nov", tituloCompleto: "NOVIEMBRE 2026" },
  { mesNumero: 12, anio: 2026, nombreMes: "DICIEMBRE", chipTexto: "Dic", tituloCompleto: "DICIEMBRE 2026" },
  { mesNumero: 1, anio: 2027, nombreMes: "ENERO", chipTexto: "Ene '27", tituloCompleto: "ENERO 2027" }
];



