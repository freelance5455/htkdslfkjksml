import { el, card, showAlert, showConfirm } from "../ui/widgets.js";
import { PLANS, currentPlan, activatePlan, clearPlan, formatPrice } from "../engines/plansEngine.js";

export async function Plans(app) {
  const s = app.student;
  const active = currentPlan(s);

  const header = el("div", { class: "role-heading" }, "Plans & support");
  const sub = el("div", { class: "role-subtitle wrap" },
    "learnyZ is built for South African CAPS learners. Choose a plan that matches your needs. " +
    "Prices are in South African Rand. Payment integration is forthcoming; for now you may activate a plan locally for demonstration.");

  const currentCard = card(
    "Current plan",
    `${active.name}${active.price ? " · " + formatPrice(active) : ""}\n` +
    (s.subscription?.demo ? "(Local demo activation)" : "Explorer tier — full core features available"),
    active.id !== "free"
      ? [{ label: "SWITCH TO FREE", onClick: async () => {
          const ok = await showConfirm("Clear plan", "Return this profile to the free Explorer tier?");
          if (!ok) return;
          clearPlan(s);
          app.saveStudent();
          showAlert("Plan cleared", "You are now on the free Explorer tier.");
          app.showPlans();
        }}]
      : []
  );

  const planCards = PLANS.map((p) => {
    const isActive = active.id === p.id;
    const priceLine = formatPrice(p);
    const featureText = p.features.map((f) => "• " + f).join("\n");
    const actions = isActive
      ? [{ label: "ACTIVE", onClick: () => showAlert("Active", `${p.name} is already active on this profile.`) }]
      : [{
          label: "ACTIVATE",
          onClick: async () => {
            const ok = await showConfirm(
              `Activate ${p.name}?`,
              `${priceLine}\n\nThis will unlock the plan features on this device for demonstration. Real billing will be added in a future release.`
            );
            if (!ok) return;
            const res = activatePlan(s, p.id);
            if (res.ok) {
              app.saveStudent();
              showAlert("Plan activated", `${p.name} is now active on this profile.`);
              app.showPlans();
            } else {
              showAlert("Unable to activate", "Please try again.");
            }
          }
        }];

    const title = p.highlight ? `${p.name} ★` : p.name;
    const body = `${p.badge ? p.badge + " · " : ""}${p.tagline}\n${priceLine}\n\n${featureText}`;
    return card(title, body, actions);
  });

  const note = card(
    "About these plans",
    "• Learner (R49/mo) suits a single learner focused on Maths plus one other subject.\n" +
    "• Scholar (R99/mo) opens every subject for the grade and the full workshop suite.\n" +
    "• Family (R450/yr) covers up to three profiles at a lower effective monthly rate.\n" +
    "• Campus (R999/yr) is intended for tutors and small centres needing many profiles and branding.\n\n" +
    "Core practice remains available on the free tier. Plans support ongoing CAPS content development."
  );

  return el("div", { class: "screen" }, [
    header,
    sub,
    currentCard,
    ...planCards,
    note,
    el("div", { style: "height:1.5rem" })
  ]);
}
