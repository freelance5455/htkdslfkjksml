import { el, showAlert } from "../ui/widgets.js";
import { THEMES, applyTheme } from "../theme.js";
import { SINGLE_CODE, OWNER } from "../app.js";
import { mascotCard, mascotLine } from "../engines/mascotEngine.js";

const GENDERS = [
  { value: "girl", label: "Girl" },
  { value: "boy", label: "Boy" },
  { value: "prefer_not", label: "Prefer not to say" }
];

const THEME_BLURBS = {
  Candy: "Soft pinks and playful cards — light and friendly.",
  "Classic Elite": "Deep navy and gold accents — formal academy look.",
  Midnight: "Dark slate with indigo highlights — easy on the eyes at night.",
  Academic: "Clean paper-white with ink blue — textbook calm.",
  Neon: "High-contrast neon on dark — bold and energetic.",
  Glass: "Frosted glass panels over a soft gradient.",
  Sunset: "Warm orange-to-rose gradient — evening study mood.",
  Forest: "Deep greens and earth tones — calm focus.",
  Ocean: "Cool blues and teal — clear and open.",
  Aurora: "Shifting violet–teal glow — premium feel.",
  Gold: "Champagne and charcoal — polished exam mode."
};

export async function Login(app) {
  const nameInput = el("input", {
    type: "text",
    placeholder: "Your full name",
    autocomplete: "name",
    value: ""
  });

  const genderSelect = el("select", {}, GENDERS.map((g) =>
    el("option", { value: g.value }, g.label)
  ));

  const themeSelect = el("select", {}, THEMES.map((t) =>
    el("option", { value: t }, t)
  ));
  themeSelect.value = "Candy";

  const previewCard = el("div", {
    class: "card",
    style: "margin-top:0.35rem;transition:background 0.25s ease,border-color 0.25s ease;"
  }, [
    el("div", { class: "role-heading", style: "font-size:0.95rem;" }, "Theme preview"),
    el("div", { class: "role-subtitle wrap", id: "theme-preview-blurb" }, THEME_BLURBS.Candy),
    el("div", {
      style: "margin-top:0.65rem;display:flex;gap:0.4rem;flex-wrap:wrap;"
    }, [
      el("span", { class: "chip active", style: "pointer-events:none;" }, "Active chip"),
      el("span", { class: "chip", style: "pointer-events:none;" }, "Idle chip"),
      el("button", { class: "btn", style: "pointer-events:none;padding:0.4rem 0.75rem;font-size:0.8rem;" }, "Primary"),
      el("button", { class: "btn-secondary", style: "pointer-events:none;padding:0.4rem 0.75rem;font-size:0.8rem;" }, "Secondary")
    ]),
    el("div", {
      style: "margin-top:0.7rem;height:8px;border-radius:999px;background:color-mix(in srgb,var(--accent) 25%,transparent);overflow:hidden;"
    }, [
      el("div", { style: "height:100%;width:62%;background:var(--accent);border-radius:999px;" })
    ]),
    el("div", { class: "role-muted", style: "margin-top:0.35rem;font-size:0.78rem;" }, "Progress · sample card · live theme")
  ]);

  function syncThemePreview() {
    const t = themeSelect.value || "Candy";
    applyTheme(t, "Normal");
    const blurb = previewCard.querySelector("#theme-preview-blurb");
    if (blurb) blurb.textContent = THEME_BLURBS[t] || `Preview of the ${t} theme applied across the app.`;
  }
  themeSelect.addEventListener("change", syncThemePreview);
  syncThemePreview();

  const existing = app.loadStudentByCode(SINGLE_CODE);

  async function startFresh() {
    const name = nameInput.value.trim();
    if (!name || name.length < 2) {
      return showAlert("Name needed", "Please enter your name so we can personalise your study space.");
    }
    const gender = genderSelect.value;
    const theme = themeSelect.value;
    await app.login(SINGLE_CODE, 10, name, { gender, theme });
  }

  async function continueExisting() {
    await app.login(SINGLE_CODE, 10, null);
  }

  nameInput.addEventListener("keydown", (e) => { if (e.key === "Enter") startFresh(); });

  const kids = [
    el("div", { class: "center", style: "font-size:0.72rem;font-weight:800;letter-spacing:0.14em;text-transform:uppercase;opacity:0.75;" }, "The Elites Academy"),
    el("div", { class: "center", style: "font-size:1.85rem;font-weight:800;letter-spacing:-0.02em;" }, "Learnly Grade 10"),
    el("div", { class: "center role-subtitle" }, "Mathematical Literacy · Business Studies · Tourism"),
    el("div", {
      class: "center role-muted",
      style: "margin-top:0.35rem;font-size:0.8rem;font-weight:700;letter-spacing:0.04em;text-transform:uppercase;"
    }, "CAPS · Grade 10"),
    el("div", { style: "height:0.35rem" }),
    mascotCard(el, {
      mood: existing?.name ? "happy" : "idle",
      line: existing?.name
        ? mascotLine("greet")
        : "I’m Kepi — your study lookout. Set your name and we’ll start.",
      size: "72px"
    }),
    el("div", { style: "height:0.25rem" })
  ];

  if (existing && existing.name) {
    kids.push(
      el("div", { class: "card" }, [
        el("div", { class: "role-heading" }, `Welcome back, ${existing.name}`),
        el("div", { class: "role-subtitle wrap" },
          `Grade 10 · ⭐ ${existing.xp || 0} XP · Level ${existing.level || 1}`)
      ]),
      el("button", { class: "btn", onClick: continueExisting }, "Continue studying"),
      el("div", { class: "section-eyebrow" }, "OR CREATE A NEW PROFILE")
    );
  }

  kids.push(
    el("label", { class: "field-label" }, "Learner name"),
    nameInput,
    el("label", { class: "field-label" }, "Gender"),
    genderSelect,
    el("label", { class: "field-label" }, "Preferred theme"),
    themeSelect,
    previewCard,
    el("button", { class: "btn", onClick: startFresh }, existing?.name ? "Save & continue" : "Start studying"),
    el("div", { class: "role-muted wrap", style: "margin-top:0.5rem;" },
      "Subjects: Mathematical Literacy · Business Studies · Tourism. You sign in once on this device.")
  );

  return {
    title: "",
    showBack: false,
    body: [
      el("div", {
        style: "flex:1;display:flex;flex-direction:column;justify-content:center;gap:0.75rem;padding:1.25rem 0;"
      }, kids)
    ]
  };
}
