import { el, card, topicTile } from "../ui/widgets.js";
import { allScienceTopics, loadScienceTopic, loadTips, generateDefinitionsQuiz } from "../engines/contentLoader.js";
import { drawScienceDiagram, drawDiagram } from "../ui/render.js";

function section(title, body) {
  const kids = [el("div", { class: "role-heading wrap" }, title)];
  if (Array.isArray(body)) body.forEach((item) => kids.push(el("div", { class: "wrap" }, "•  " + item)));
  else if (body) kids.push(el("div", { class: "wrap" }, String(body)));
  return el("div", { class: "card" }, kids);
}

// ==================== SCIENCE TOPIC LIST ====================
export async function Science(app) {
  const grade = app.student?.grade ?? 8;
  if (grade === 12 || grade === 11 || grade === 10) {
    const { allPhysSciTopics } = await import("../engines/contentLoader.js");
    const topics = await allPhysSciTopics();
    const p1 = topics.filter((t) => t.paper === 1);
    const p2 = topics.filter((t) => t.paper === 2);
    const body = [
      el("div", { class: "role-subtitle wrap" }, "Grade 12 Physical Sciences · CAPS Paper 1 Physics and Paper 2 Chemistry."),
      el("div", { class: "section-eyebrow" }, "PAPER 1 — PHYSICS"),
      ...p1.map((t) => topicTile(t.icon || "🔬", t.name, t.area || "Physics",
        () => app.showScienceTopic(t.id),
        () => app.showPractice("choose", [t.id]))),
      el("div", { class: "section-eyebrow", style: "margin-top:0.75rem;" }, "PAPER 2 — CHEMISTRY"),
      ...p2.map((t) => topicTile(t.icon || "🧪", t.name, t.area || "Chemistry",
        () => app.showScienceTopic(t.id),
        () => app.showPractice("choose", [t.id])))
    ];
    return { title: "🔬 Physical Sciences", bottomNavKey: "learn", body };
  }
  const topics = await allScienceTopics();
  return {
    title: "🔬 Natural Sciences", bottomNavKey: "learn",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Grade 8 CAPS Natural Sciences — the four core strands, with code-generated diagrams."),
      ...topics.map((t) => topicTile(t.icon || "🔬", t.name, "Tap to open notes, key facts and a diagram.",
        () => app.showScienceTopic(t.id), () => app.showQuiz("science")))
    ]
  };
}

// ==================== SCIENCE TOPIC DETAIL ====================
export async function ScienceTopic(app, { topicId }) {
  let data = null;
  if (String(topicId).startsWith("ps_")) {
    const { loadPhysSciTopic } = await import("../engines/contentLoader.js");
    data = await loadPhysSciTopic(topicId);
  } else {
    data = await loadScienceTopic(topicId);
  }
  const name = data ? data.name : topicId;
  if (!data) return { title: `🔬 ${name}`, body: [el("div", { class: "wrap" }, "Content not found for this topic.")] };

  const body = [];
  if (data.about) body.push(card("About this topic", data.about));
  if (data.illustrations && data.illustrations.length) {
    body.push(el("div", { class: "section-eyebrow" }, "DIAGRAMS"));
    data.illustrations.forEach((ill) => {
      const wrap = el("div", { class: "card" });
      wrap.appendChild(el("div", { class: "role-heading wrap" }, ill.title || "Diagram"));
      if (ill.caption) wrap.appendChild(el("div", { class: "role-muted wrap", style: "margin-bottom:0.35rem;" }, ill.caption));
      if (ill.diagram) {
        const holder = el("div", { style: "width:100%;max-width:340px;margin:0.35rem auto;" });
        const c = el("canvas", { style: "display:block;width:100%;max-width:100%;height:auto;" });
        holder.appendChild(c);
        wrap.appendChild(holder);
        requestAnimationFrame(() => {
          const w = Math.min(320, holder.clientWidth || 280);
          drawDiagram(c, ill.diagram, w, Math.round(w * 0.72));
        });
      }
      body.push(wrap);
    });
  }
  if (data.formulae && data.formulae.length) {
    body.push(card("Formulae", data.formulae.map((f) => "• " + f).join("\n")));
  }
  if (data.step_by_step_method && data.step_by_step_method.length) {
    body.push(card("Method", data.step_by_step_method.map((s, i) => `${i + 1}. ${s}`).join("\n")));
  }
  if (data.worked_examples && data.worked_examples.length) {
    data.worked_examples.forEach((ex, i) => {
      body.push(card(`Worked example ${i + 1}`, `Q: ${ex.question}\n\nA: ${ex.solution}`));
    });
  }

  if (String(topicId).startsWith("ps_")) {
    body.push(card("Practice", "Generated CAPS-style questions for this topic.", [
      { label: "PRACTISE", onClick: () => app.showPractice("choose", [topicId]) }
    ]));
  }
  body.push(card("Quiz yourself", "Test your recall of key terms and facts from this strand.",
      [{ label: "DEFINITIONS QUIZ", onClick: () => app.showQuiz("science", topicId) }]));
  if (data.diagram) {
    const c = el("canvas", { style: "display:block;margin:0 auto;" });
    body.push(el("div", { class: "card" }, c));
    requestAnimationFrame(() => drawScienceDiagram(c, data.diagram.type || data.diagram, 320, 220));
  }
  if (data.key_facts && data.key_facts.length) {
    body.push(card("Key facts", data.key_facts.map((f) => "• " + f).join("\n")));
  }
  if (data.common_mistakes && data.common_mistakes.length) {
    body.push(card("Common mistakes", data.common_mistakes.map((f) => "• " + f).join("\n")));
  }
  if (data.caps_alignment) {
    body.push(card("CAPS alignment", data.caps_alignment));
  }
  // Grade 8 Natural Sciences layout (legacy fields)
  if (data.what_is_it || data.why_it_matters || data.core_concept) {
  body.push(
    section("1️⃣ What is it?", data.what_is_it),
    section("2️⃣ Why it matters", data.why_it_matters),
    section("3️⃣ Key vocabulary", data.key_vocabulary),
    section("4️⃣ Core concept", data.core_concept),
    section("5️⃣ Key facts", data.key_facts),
    data.formulae && data.formulae.length ? section("Formulae", data.formulae) : null,
    section("⚠️ Common misconceptions", data.common_misconceptions),
    section("✅ Quick test", data.quick_test)
  );
  }

  return { title: `🔬 ${name}`, body };
}

// ==================== DEFINITIONS QUIZ ====================
export async function Quiz(app, { subject = "math", topicId = null } = {}) {
  const state = { subject, score: 0, asked: 0, current: null };
  const subjectSelect = el("select", {}, ["Mathematics", "Natural Sciences"].map((s) => el("option", { value: s }, s)));
  subjectSelect.value = subject === "science" ? "Natural Sciences" : "Mathematics";

  const scoreLabel = el("div", {});
  const questionLabel = el("div", { class: "wrap", style: "font-size:1.05rem;font-weight:700;" });
  const optionsWrap = el("div", { class: "btn-row", style: "flex-direction:column;" });
  const feedback = el("div", { class: "wrap" });

  function updateScore() { scoreLabel.textContent = `Score: ${state.score}/${state.asked}`; }

  async function nextQuestion() {
    optionsWrap.innerHTML = "";
    feedback.textContent = "";
    const q = await generateDefinitionsQuiz(state.subject);
    if (!q) { questionLabel.textContent = "Not enough vocabulary loaded for a quiz yet."; state.current = null; return; }
    state.current = q;
    questionLabel.textContent = `[${q.topic}]\n\n${q.question}`;
    q.options.forEach((opt) => {
      const b = el("button", { class: "btn-secondary", onClick: () => answer(opt, b) }, opt);
      optionsWrap.appendChild(b);
    });
    updateScore();
  }
  function answer(selected, btnEl) {
    if (!state.current) return;
    state.asked += 1;
    const correct = selected === state.current.answer;
    if (correct) { state.score += 1; feedback.textContent = `✓ Correct! ${selected}`; app.student.xp = (app.student.xp || 0) + 5; }
    else feedback.textContent = `✗ Not quite. Correct answer: ${state.current.answer}`;
    app.saveStudent();
    [...optionsWrap.children].forEach((b) => (b.disabled = true));
    updateScore();
  }
  subjectSelect.addEventListener("change", () => {
    state.subject = subjectSelect.value === "Natural Sciences" ? "science" : "math";
    state.score = 0; state.asked = 0;
    nextQuestion();
  });

  await nextQuestion();
  return {
    title: "🧠 Definitions Quiz",
    body: [
      el("label", { class: "field-label" }, "Subject"), subjectSelect,
      scoreLabel, questionLabel, optionsWrap, feedback,
      el("button", { class: "btn-secondary", onClick: () => nextQuestion() }, "NEXT QUESTION →")
    ]
  };
}

// ==================== TIPS & TRICKS LIBRARY ====================
export async function TipsTricks(app) {
  const data = await loadTips();
  const categories = data.categories || [];
  const listWrap = el("div", {});

  function renderCategories(onlyIndex) {
    listWrap.innerHTML = "";
    const shown = onlyIndex < 0 ? categories : [categories[onlyIndex]];
    shown.forEach((cat) => {
      listWrap.appendChild(el("div", { class: "section-eyebrow" }, `${cat.icon || "💡"} ${(cat.name || "").toUpperCase()}`));
      (cat.tricks || []).forEach((trick) => {
        listWrap.appendChild(el("div", { class: "card" }, [
          el("div", { class: "role-heading wrap" }, `⚡ ${trick.title}`),
          el("div", { class: "role-subtitle wrap" }, `When to use it: ${trick.when}`),
          el("div", { class: "wrap" }, `Example: ${trick.example}`),
          el("div", { class: "wrap" }, `Method: ${trick.method}`),
          el("div", { class: "role-subtitle wrap" }, `Why it works: ${trick.why}`)
        ]));
      });
    });
  }

  const selector = el("select", {}, [el("option", { value: "-1" }, "Show all"), ...categories.map((c, i) => el("option", { value: String(i) }, `${c.icon || "💡"} ${c.name}`))]);
  selector.addEventListener("change", () => renderCategories(parseInt(selector.value, 10)));
  renderCategories(-1);

  return {
    title: "💡 Tips & Tricks",
    body: [
      el("div", { class: "role-subtitle wrap" }, "Fast methods for every core maths skill — each with WHY it works, not just the shortcut, so it actually sticks."),
      el("label", { class: "field-label" }, "Jump to category"), selector,
      listWrap
    ]
  };
}
