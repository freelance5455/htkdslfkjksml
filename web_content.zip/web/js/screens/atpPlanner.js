import { el, card } from "../ui/widgets.js";
import { subjectLabel, topicsForSubject, loadSubjectRegistry } from "../engines/subjectRegistry.js";

/** CAPS / ATP-style term groupings for Grade 10 line subjects */
const ATP = {
  mathematical_literacy: {
    1: {
      title: "Term 1 — Numbers & patterns",
      topics: ["ml_numbers", "ml_patterns", "ml_finance"],
      focus: "Ratio, rate, percentage, simple patterns, intro budgets and VAT"
    },
    2: {
      title: "Term 2 — Finance & measurement",
      topics: ["ml_finance", "ml_measurement", "ml_maps"],
      focus: "Interest, tariffs, perimeter/area, scale and plans"
    },
    3: {
      title: "Term 3 — Data, maps & probability",
      topics: ["ml_data", "ml_maps", "ml_probability", "ml_measurement"],
      focus: "Graphs, two-way tables, scale, chance"
    },
    4: {
      title: "Term 4 — Revision & integrated papers",
      topics: ["ml_finance", "ml_data", "ml_measurement", "ml_probability"],
      focus: "Exam-style multi-section papers and weak-topic repair"
    }
  },
  business_studies: {
    1: {
      title: "Term 1 — Business environments",
      topics: ["bs_micro", "bs_market", "bs_macro", "bs_sectors"],
      focus: "Micro, market, macro (PESTEL), economic sectors"
    },
    2: {
      title: "Term 2 — Socio-economic & entrepreneurship",
      topics: ["bs_socio", "bs_entrepreneurship", "bs_ownership"],
      focus: "CSR/CSI, entrepreneur qualities, forms of ownership"
    },
    3: {
      title: "Term 3 — Ventures & creative thinking",
      topics: ["bs_opportunity", "bs_creative", "bs_self", "bs_ownership"],
      focus: "Business plan, creative problem-solving, teams"
    },
    4: {
      title: "Term 4 — Revision papers",
      topics: ["bs_macro", "bs_ownership", "bs_entrepreneurship", "bs_socio"],
      focus: "Paper 1 / Paper 2 style practice"
    }
  },
  tourism: {
    1: {
      title: "Term 1 — Tourism introduction",
      topics: ["tour_intro", "tour_types", "tour_sectors"],
      focus: "What tourism is, tourist types, industry sectors"
    },
    2: {
      title: "Term 2 — Transport & accommodation",
      topics: ["tour_transport", "tour_accommodation", "tour_maps"],
      focus: "Modes of transport, accommodation grades, tour maps"
    },
    3: {
      title: "Term 3 — Attractions & sustainability",
      topics: ["tour_attractions", "tour_sustainable", "tour_domestic"],
      focus: "Attractions, triple bottom line, domestic vs international"
    },
    4: {
      title: "Term 4 — Service & exam prep",
      topics: ["tour_service", "tour_maps", "tour_sectors"],
      focus: "Service excellence, itineraries, full papers"
    }
  }
};

function topicName(id, list) {
  const t = (list || []).find((x) => (x.id || x) === id);
  return (t && t.name) || String(id).replaceAll("_", " ");
}

export async function AtpPlanner(app) {
  await loadSubjectRegistry();
  const sid = app.student?.subject || "mathematical_literacy";
  const plan = ATP[sid] || ATP.mathematical_literacy;
  const topics = topicsForSubject(sid) || [];
  app.student.atp = app.student.atp || {};
  const done = app.student.atp[sid] || {};

  const body = [
    el("button", { class: "btn-secondary", onClick: () => app.showSettings() }, "← Settings"),
    el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.75rem;" },
      `${subjectLabel(sid)} · Grade 10 ATP-style planner. Tick topics as you finish notes + practice.`),
    el("div", { class: "role-muted wrap", style: "font-size:0.82rem;margin-bottom:0.65rem;" },
      "This is a study guide aligned to typical CAPS term flow — not an official DBE PDF.")
  ];

  for (const term of [1, 2, 3, 4]) {
    const block = plan[term];
    if (!block) continue;
    const items = [];
    block.topics.forEach((tid) => {
      const key = tid;
      const isDone = !!done[key];
      const row = el("label", {
        class: "checkline" + (isDone ? " atp-done" : ""),
        style: "display:flex;align-items:center;gap:0.5rem;margin:0.25rem 0;"
      });
      const cb = el("input", { type: "checkbox" });
      cb.checked = isDone;
      cb.addEventListener("change", () => {
        app.student.atp[sid] = app.student.atp[sid] || {};
        if (cb.checked) app.student.atp[sid][key] = true;
        else delete app.student.atp[sid][key];
        app.saveStudent();
        row.classList.toggle("atp-done", cb.checked);
      });
      row.appendChild(cb);
      row.appendChild(el("span", {}, topicName(tid, topics)));
      items.push(row);
    });
    const actions = el("div", { class: "btn-row", style: "margin-top:0.55rem;flex-wrap:wrap;gap:0.4rem;" }, [
      el("button", {
        class: "btn-secondary",
        style: "padding:0.45rem 0.7rem;font-size:0.85rem;",
        onClick: () => app.navigate("learningCardHub")
      }, "Learning cards"),
      el("button", {
        class: "btn-secondary",
        style: "padding:0.45rem 0.7rem;font-size:0.85rem;",
        onClick: () => app.navigate("papers", { view: "subject_past" })
      }, "Past papers"),
      el("button", {
        class: "btn",
        style: "padding:0.45rem 0.7rem;font-size:0.85rem;",
        onClick: () => app.navigate("practiceSession", {
          mode: "choose",
          topics: block.topics,
          difficulty: 2,
          count: 8,
          timed: false,
          hints: true,
          showSolution: true
        })
      }, "Practise term topics")
    ]);
    body.push(el("div", { class: "card atp-term-card", style: "margin-bottom:0.65rem;" }, [
      el("div", { class: "role-heading wrap" }, block.title),
      el("div", { class: "role-muted wrap", style: "font-size:0.85rem;margin:0.25rem 0 0.45rem;" }, block.focus),
      ...items,
      actions
    ]));
  }

  body.push(el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "Open subject hub"));
  return { title: "ATP term planner", bottomNavKey: "learn", body };
}
