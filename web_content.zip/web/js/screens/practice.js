import { el, progressBar, showAlert, formatQuestionHTML, mathKeyboard } from "../ui/widgets.js";
import { drawDiagram } from "../ui/render.js";
import { drawLessonVisual } from "../ui/imageBuilder.js";
import { AdaptiveEngine } from "../engines/adaptive.js";
import { MasteryEngine } from "../engines/mastery.js";
import { EconomyEngine, touchCalendarStreak } from "../engines/economyEngine.js";
import { GamificationEngine, tickWeeklyQuest, getWeeklyQuest, tickDailyMission, claimMissionRewards } from "../engines/gamificationEngine.js";
import { answersMatch } from "../engines/answerCheck.js";
import { CountdownTimer } from "../engines/timerEngine.js";
import { mascotLine, MASCOT_NAME } from "../engines/mascotEngine.js";
import { progressRing } from "../ui/visualPolish.js";

/**
 * Build a compact visual that shows only a number, fraction, or shape —
 * never the full question sentence.
 */
function buildNumberOrShapeVisual(q) {
  if (!q) return null;
  const text = String(q.question || "").replace(/⟦FRAC:(\d+)\/(\d+)⟧/g, "$1/$2");
  const frac = text.match(/(\d+)\s*\/\s*(\d+)/);
  if (frac) {
    const num = parseInt(frac[1], 10), den = parseInt(frac[2], 10);
    if (den > 0 && den <= 12 && num >= 0 && num <= den * 2) {
      return { type: "fraction", num, den };
    }
  }
  const solidMatch = text.match(/\b(cube|cuboid|cylinder|cone|sphere|pyramid|prism)\b/i);
  if (solidMatch) return { type: "solid3d", kind: solidMatch[1].toLowerCase() };
  const shortExpr = text.match(/^[\s]*(?:Calculate|Find|What is|Work out)?[:\s]*([\d\s+\-×÷*/=().,]+)\s*$/i);
  if (shortExpr) {
    const expr = shortExpr[1].trim();
    if (expr.length <= 18) return { type: "banner", bigText: expr, title: "", steps: [] };
  }
  const nums = text.match(/\b\d[\d\s]*\d\b|\b\d+\b/g) || [];
  const big = nums.map((n) => n.replace(/\s/g, "")).filter((n) => n.length >= 2 && n.length <= 6);
  if (big.length === 1 && /^\d+$/.test(big[0])) {
    return { type: "place_value", number: parseInt(big[0], 10) };
  }
  if (big.length >= 1 && big[0].length <= 8) {
    return { type: "banner", bigText: big[0], title: "", steps: [] };
  }
  if (/dice|die|probability|chance/i.test(text)) {
    return { type: "dice", faces: 6, value: (parseInt((nums[0] || "3"), 10) % 6) + 1 };
  }
  return null;
}

const MODES = ["Pick a topic", "Today", "For you", "Needs work", "Strong topics", "Mix it up", "Speed run", "Mental Maths"];
const DIFFICULTIES = ["Foundation", "Standard", "Advanced", "Elite"];
const DIFF_MAP = { Foundation: 1, Standard: 2, Advanced: 3, Elite: 4 };
const MODE_LABELS = { recommended: "For you", weakness: "Needs work", strength: "Strong topics", mixed: "Mix it up", choose: "Pick a topic", daily: "Today" };
const MODE_KEYS = { "Today": "daily", "For you": "recommended", "Needs work": "weakness", "Strong topics": "strength", "Mix it up": "mixed", "Speed run": "speed", "Pick a topic": "choose" };

// ==================== SETUP ====================
export async function PracticeSetup(app, { mode = null, topics = null } = {}) {
  const gm = app.gradeManager();
  let selectedDiff = "Foundation", selectedCount = 10;
  const selectedTopics = new Set(topics || []);

  const modeSelect = el("select", {}, MODES.map((m) => el("option", { value: m }, m)));
  modeSelect.value = mode ? (MODE_LABELS[mode] || mode) : "Pick a topic";

  let topicList = gm.topics().slice();
  const subj = app.student?.subject || "maths";
  if (subj === "physical_sciences") {
    try {
      const { allPhysSciTopics } = await import("../engines/contentLoader.js");
      topicList = (await allPhysSciTopics()).map((t) => ({ ...t, name: t.name }));
    } catch { /* optional */ }
  } else if (subj !== "maths") {
    try {
      const { loadSubjectRegistry, topicsForSubject } = await import("../engines/subjectRegistry.js");
      await loadSubjectRegistry();
      topicList = topicsForSubject(subj);
    } catch { /* optional */ }
  }
  // Ensure adaptive mastery keys exist for current subject topics
  app.student.mastery = app.student.mastery || {};
  topicList.forEach((t) => {
    const id = t.id || t;
    if (app.student.mastery[id] == null) app.student.mastery[id] = 0.35;
  });

    const topicWrap = el("div", { class: "topic-list" }, topicList.map((t) => {
    const cb = el("input", { type: "checkbox" });
    cb.checked = selectedTopics.has(t.id);
    cb.addEventListener("change", () => { cb.checked ? selectedTopics.add(t.id) : selectedTopics.delete(t.id); });
    return el("label", { class: "topic-check" }, [cb, `${t.icon || "📘"} ${t.name}`]);
  }));
  const topicSection = el("div", {}, [el("label", { class: "field-label" }, "Topics (select one or more)"), topicWrap]);
  function syncTopicVisibility() { topicSection.style.display = modeSelect.value === "Pick a topic" ? "" : "none"; }
  modeSelect.addEventListener("change", syncTopicVisibility);

  const diffRow = el("div", { class: "chip-row" });
  DIFFICULTIES.forEach((d) => {
    const chip = el("button", { class: "chip" + (d === selectedDiff ? " active" : ""), onClick: () => { selectedDiff = d; [...diffRow.children].forEach((c) => c.classList.toggle("active", c.textContent === d)); } }, d);
    diffRow.appendChild(chip);
  });

  const countRow = el("div", { class: "chip-row" });
  [5, 10, 15, 20].forEach((c) => {
    const chip = el("button", { class: "chip" + (c === selectedCount ? " active" : ""), onClick: () => { selectedCount = c; [...countRow.children].forEach((el2) => el2.classList.toggle("active", el2.textContent === String(c))); } }, String(c));
    countRow.appendChild(chip);
  });

  const timedBox = el("input", { type: "checkbox" });
  const hintsBox = el("input", { type: "checkbox" }); hintsBox.checked = true;
  const solutionBox = el("input", { type: "checkbox" }); solutionBox.checked = true;

  async function start() {
    const modeText = modeSelect.value;
    if (modeText === "Mental Maths") return app.showMental();
    const modeKey = MODE_KEYS[modeText] || "recommended";
    let chosenTopics = [];
    if (modeKey === "choose") {
      chosenTopics = [...selectedTopics];
      if (!chosenTopics.length) return showAlert("Choose a topic", "Please select at least one topic to practise.");
    }
    app.launchPracticeSession({
      mode: modeKey, topics: chosenTopics, difficulty: DIFF_MAP[selectedDiff], count: selectedCount,
      timed: timedBox.checked, hints: hintsBox.checked, showSolution: solutionBox.checked
    });
  }

  syncTopicVisibility();
  return {
    title: `✏️ Practice — ${gm.label()}`,
    body: [
      el("div", { class: "role-subtitle wrap" }, `Choose what you want to practise. Topics and numbers are matched to ${gm.label()} only.`),
      el("label", { class: "field-label" }, "Mode"), modeSelect,
      topicSection,
      el("label", { class: "field-label" }, "Difficulty"), diffRow,
      el("label", { class: "field-label" }, "Number of questions"), countRow,
      el("label", { class: "checkline" }, [timedBox, "⏱ Timed"]),
      el("label", { class: "checkline" }, [hintsBox, "💡 Hints"]),
      el("label", { class: "checkline" }, [solutionBox, "✅ Show solution after each answer"]),
      el("button", { class: "btn", onClick: start }, "🚀 START PRACTICE")
    ]
  };
}

// ==================== SESSION ====================
export async function PracticeSession(app, { mode = "recommended", topics = [], difficulty = 1, count = 10, timed = false, hints = true, showSolution = true }) {
  const state = { answered: 0, correct: 0, q: null, xpGained: 0, starsGained: 0, levelStart: 0, combo: 0, wrongStreak: 0 };
  const qe = app.questionEngine();
  const ad = new AdaptiveEngine(app.student);
  const me = new MasteryEngine(app.student);
  const econ = new EconomyEngine(app.student);
  const gam = new GamificationEngine(app.student);
  const timer = new CountdownTimer();
  state.levelStart = gam.level();

  const ringHost = el("div", { class: "orbit-ring", style: "display:flex;align-items:center;gap:0.75rem;margin-bottom:0.35rem;" });
  const ring = progressRing(el, 0, count, { size: 52, stroke: 5, label: `0/${count}` });
  const metaCol = el("div", { style: "flex:1;min-width:0;" });
  const statusEl = el("div", { class: "role-subtitle", style: "font-size:0.85rem;" }, `Question 1 of ${count}`);
  const scoreLive = el("div", { class: "role-muted", style: "font-size:0.8rem;font-weight:700;" }, "✓ 0  ·  XP +0");
  const comboMeter = el("div", { class: "meter", style: "margin-top:0.35rem;max-width:9rem;" }, [
    el("i", { style: "--meter:0%" })
  ]);
  const comboLbl = el("div", { class: "role-muted", style: "font-size:0.72rem;margin-top:0.15rem;" }, "Combo 0");
  metaCol.appendChild(statusEl);
  metaCol.appendChild(scoreLive);
  metaCol.appendChild(comboMeter);
  metaCol.appendChild(comboLbl);
  ringHost.appendChild(ring);
  ringHost.appendChild(metaCol);

  function setProgress(value) {
    const pct = count > 0 ? Math.max(0, Math.min(100, (value / count) * 100)) : 0;
    const fg = ring.querySelector(".progress-ring-fg");
    const r = (52 - 5) / 2;
    const c = 2 * Math.PI * r;
    if (fg) fg.setAttribute("stroke-dashoffset", String(c * (1 - value / Math.max(1, count))));
    const lab = ring.querySelector(".progress-ring-label");
    if (lab) lab.textContent = `${value}/${count}`;
    const comboBit = state.combo >= 2 ? `  ·  💥×${state.combo}` : "";
    scoreLive.textContent = `✓ ${state.correct}  ·  XP +${state.xpGained}${state.starsGained ? `  ·  ★ +${state.starsGained}` : ""}${comboBit}`;
    const comboPct = Math.min(100, Math.round((state.combo / 10) * 100));
    const fill = comboMeter.querySelector("i");
    if (fill) fill.style.setProperty("--meter", comboPct + "%");
    comboLbl.textContent = state.combo >= 3
      ? `Combo ×${state.combo} · bonus active`
      : `Combo ${state.combo} · ×3 for stars`;
    comboLbl.className = state.combo >= 3 ? "role-muted anim-count" : "role-muted";
  }

  const topicLbl = el("div", { class: "practice-topic-chip" });
  const questionCard = el("div", { class: "card practice-q-card anim-step" });
  const questionEl = el("div", { class: "wrap practice-q-text" });
  const diagramCanvas = el("canvas", { style: "display:none;margin:0.55rem auto 0;width:100%;max-width:320px;height:auto;border-radius:0.75rem;" });
  questionCard.appendChild(topicLbl);
  questionCard.appendChild(questionEl);
  questionCard.appendChild(diagramCanvas);

  const answerInput = el("input", { type: "text", class: "quiz-input", placeholder: "Type your answer" });
  const checkBtn = el("button", { class: "btn", onClick: () => check(false) }, "CHECK ANSWER");
  const nextBtn = el("button", { class: "btn-secondary", onClick: () => nextQuestion() }, "NEXT →");
  nextBtn.disabled = true;
  const hintEl = el("div", { class: "wrap role-subtitle", style: "font-size:0.88rem;" });
  const resultEl = el("div", { class: "wrap practice-result" });
  const timerLbl = el("div", { class: "role-muted", style: "font-weight:700;" });
  const container = el("div", { class: "practice-session" }, [
    ringHost,
    questionCard,
    answerInput,
    ((app.student.settings || {}).maths_keyboard ? mathKeyboard(answerInput) : null),
    el("div", { class: "btn-row", style: "margin-top:0.35rem;" }, [checkBtn, nextBtn]),
    timerLbl,
    hintEl,
    resultEl
  ]);
  answerInput.addEventListener("keydown", (e) => { if (e.key === "Enter") check(false); });

  timer.onTick = (sec) => {
    timerLbl.textContent = `⏱ ${sec}s remaining`;
    timerLbl.style.color = sec <= 10 ? "var(--bad)" : "var(--muted)";
  };
  timer.onFinished = () => { if (!answerInput.disabled) check(true); };

  function pickTopic() {
    if (mode === "choose" && topics.length) {
      const t = topics[Math.floor(Math.random() * topics.length)];
      return typeof t === "string" ? t : (t.id || t);
    }
    const picked = ad.chooseTopic(mode === "speed" ? "mixed" : mode);
    // If adaptive falls back to a non-G10 id, prefer current subject topics
    const subj = app.student?.subject || "mathematical_literacy";
    const prefixes = {
      mathematical_literacy: "ml_",
      business_studies: "bs_",
      tourism: "tour_"
    };
    const pref = prefixes[subj];
    if (pref && picked && !String(picked).startsWith(pref) && topics && topics.length) {
      const t = topics[Math.floor(Math.random() * topics.length)];
      return typeof t === "string" ? t : (t.id || t);
    }
    return picked;
  }

  function nextQuestion() {
    if (state.answered >= count) return finishSession();
    const topic = pickTopic();
    const diff = mode === "recommended" ? ad.recommendDifficulty(topic) : difficulty;
    state.q = qe.generate(topic, diff);
    if (!state.q) state.q = { question: "No question generated.", answer: "—", topic: topic, topic_name: String(topic), difficulty: diff, explanation: "" };
    // Normalise multi-subject shape (prompt vs question)
    if (!state.q.question && state.q.prompt) state.q.question = state.q.prompt;
    if (!state.q.topic_name) state.q.topic_name = String(state.q.topic || topic || "").replaceAll("_", " ");
    if (state.q.difficulty == null) state.q.difficulty = diff;

    const diffLabel = ["", "Foundation", "Standard", "Advanced", "Elite"][state.q.difficulty] || `Diff ${state.q.difficulty}`;
    topicLbl.textContent = `${state.q.topic_name}  ·  ${diffLabel}`;
    questionEl.innerHTML = formatQuestionHTML(state.q.question || state.q.prompt || "");
    questionCard.classList.remove("anim-step");
    void questionCard.offsetWidth;
    questionCard.classList.add("anim-step");

    diagramCanvas.style.display = "block";
    if (state.q.diagram) {
      const dw = Math.min(320, (diagramCanvas.parentElement?.clientWidth || 300));
      drawDiagram(diagramCanvas, state.q.diagram, dw, Math.round(dw * 0.65));
    } else {
      const visual = buildNumberOrShapeVisual(state.q);
      if (visual) {
        drawLessonVisual(diagramCanvas, visual, 320, 160);
      } else {
        diagramCanvas.style.display = "none";
      }
    }

    hintEl.textContent = hints && state.q.hint ? "💡 " + state.q.hint : "";
    resultEl.textContent = "";
    resultEl.className = "wrap practice-result";
    answerInput.value = "";
    answerInput.classList.remove("quiz-input-correct", "quiz-input-wrong", "anim-success", "anim-error");
    answerInput.disabled = false;
    nextBtn.disabled = true;
    checkBtn.style.display = "";
    statusEl.textContent = `Question ${state.answered + 1} of ${count}`;
    setProgress(state.answered);
    if (timed) timer.start(60); else timerLbl.textContent = "";
    setTimeout(() => answerInput.focus(), 40);
  }

  function check(timeout) {
    if (!state.q || answerInput.disabled) return;
    timer.stop();
    const userText = answerInput.value.trim();
    const correct = !timeout && answersMatch(userText, state.q.answer);
    const mastery = me.score(state.q.topic, correct, state.q.difficulty);
    state.answered += 1;
    if (correct) state.correct += 1;

    const s = app.student;
    (s.history = s.history || []).push({
      question_id: state.q.id,
      topic: state.q.topic,
      correct,
      difficulty: state.q.difficulty,
      source: "practice"
    });
    s.today_done = (s.today_done || 0) + 1;
    touchCalendarStreak(s);

    if (correct) {
      state.combo += 1;
      state.wrongStreak = 0;
      s.best_combo = Math.max(s.best_combo || 0, state.combo);
      const xpAdd = 10 + state.q.difficulty * 2 + Math.min(5, Math.floor(state.combo / 3));
      s.xp = (s.xp || 0) + xpAdd;
      state.xpGained += xpAdd;
      const entry = econ.earnCorrect(state.q.difficulty, `Correct — ${state.q.topic_name}`);
      if (entry) state.starsGained += entry.amount;
      const comboEntry = econ.earnCombo(state.combo);
      if (comboEntry) state.starsGained += comboEntry.amount;
      // Comeback after 3 wrongs
      if (s.flags && s.flags._pending_comeback) {
        s.flags.comeback = true;
        s.flags._pending_comeback = false;
        econ.earn("comeback", "Comeback correct");
      }
      // Weekly quest ticks
      tickWeeklyQuest(s, "practice_count", 1);
      tickWeeklyQuest(s, "correct_count", 1);
      tickDailyMission(s, "practice_count", 1);
      tickDailyMission(s, "correct_count", 1);
      if (state.combo >= 3) tickDailyMission(s, "combo_hit", 1);
      const tid = String(state.q.topic || "");
      if (tid.startsWith("ml_")) tickWeeklyQuest(s, "ml_correct", 1);
      if (tid.startsWith("bs_")) tickWeeklyQuest(s, "bs_correct", 1);
      if (tid.startsWith("tour_")) tickWeeklyQuest(s, "tour_correct", 1);
    } else {
      if (state.wrongStreak >= 2) s.flags = Object.assign(s.flags || {}, { _pending_comeback: true });
      state.wrongStreak += 1;
      if ((s.flags?.combo_shield || 0) > 0 && state.combo > 0) {
        s.flags.combo_shield -= 1;
      } else {
        state.combo = 0;
      }
      tickWeeklyQuest(s, "practice_count", 1);
    }
    const today = new Date().toISOString().slice(0, 10);
    if (s.today_done >= (s.daily_goal || 20) && s.daily_goal_rewarded_date !== today) {
      econ.reward("daily_goal_met", "Daily goal reached");
      s.daily_goal_rewarded_date = today;
    }

    const kepi = correct ? mascotLine("correct") : mascotLine("wrong");
    const comboNote = correct && state.combo >= 3 ? ` · Combo ×${state.combo}` : "";
    if (showSolution) {
      resultEl.innerHTML = correct
        ? `<strong>✓ Correct</strong>${comboNote} · +XP · Mastery ${Math.round(mastery * 100)}%<br><span class="role-muted">${MASCOT_NAME}: ${kepi}</span>${state.q.explanation ? `<br><br>${state.q.explanation}` : ""}`
        : `<strong>✗ Not quite${timeout ? " (time’s up)" : ""}</strong><br>Answer: <strong>${state.q.answer}</strong><br><span class="role-muted">${MASCOT_NAME}: ${kepi}</span>${state.q.explanation ? `<br><br>${state.q.explanation}` : ""}`;
    } else {
      resultEl.textContent = correct ? "✓ Recorded." : "✗ Recorded.";
    }
    resultEl.className = correct ? "wrap practice-result anim-success paint-good" : "wrap practice-result anim-error anim-soft-shake paint-bad";
    answerInput.classList.remove("quiz-input-correct", "quiz-input-wrong", "anim-success", "anim-error");
    answerInput.classList.add(correct ? "quiz-input-correct" : "quiz-input-wrong", correct ? "anim-success" : "anim-error");
    answerInput.disabled = true;
    nextBtn.disabled = false;
    setProgress(state.answered);
    app.saveStudent();
  }

  function finishSession() {
    const s = app.student;
    const accuracy = count ? state.correct / count : 0;
    touchCalendarStreak(s);
    if (accuracy >= 0.999 && count >= 5) {
      econ.reward("session_perfect", `Perfect ${count}-question session`);
      s.flags = s.flags || {};
      s.flags.perfect_session = true;
    } else {
      econ.reward("session_complete", `Completed a ${count}-question session`);
    }

    // Weekly quest completion reward
    const wq = getWeeklyQuest(s);
    if (wq.done && !s.flags?.[`weekly_paid_${wq.week}`]) {
      econ.earn("weekly_quest", wq.label || "Weekly quest");
      s.flags = s.flags || {};
      s.flags[`weekly_paid_${wq.week}`] = true;
    }

    const levelNow = gam.level();
    if (levelNow > state.levelStart) {
      econ.reward("level_up", `Reached level ${levelNow}`);
    }

    claimMissionRewards(s, econ);
    const newlyUnlocked = gam.checkNewUnlocks();
    app.saveStudent();

    const rec = ad.nextAction(state.q ? state.q.topic : "", accuracy, null);
    topicLbl.textContent = "Session complete";
    questionEl.innerHTML = "";
    if (accuracy >= 0.7) {
      const burst = el("div", { class: "confetti-burst", style: "height:0;margin:0 auto;" });
      for (let i = 0; i < 6; i++) burst.appendChild(el("span"));
      questionEl.appendChild(burst);
    }
    const title = el("div", {
      class: "role-heading " + (accuracy >= 0.8 ? "anim-stamp" : "anim-pop"),
      style: "font-size:1.35rem;"
    }, accuracy >= 0.8 ? "Strong finish" : accuracy >= 0.5 ? "Solid session" : "Keep going");
    questionEl.appendChild(title);
    questionEl.appendChild(el("div", { class: "wrap anim-count", style: "margin-top:0.35rem;" },
      `Score ${state.correct}/${count} (${Math.round(accuracy * 100)}%) · XP +${state.xpGained} · ★ +${state.starsGained}`));
    const meter = el("div", { class: "meter", style: "margin-top:0.65rem;" }, [
      el("i", { style: `--meter:${Math.round(accuracy * 100)}%` })
    ]);
    questionEl.appendChild(meter);
    if (levelNow > state.levelStart) {
      questionEl.appendChild(el("div", { class: "anim-star anim-glow", style: "margin-top:0.45rem;font-weight:800;color:var(--accent);" },
        `Level up · now Level ${levelNow}`));
      const toast = el("div", { class: "level-toast" }, `Level ${levelNow} unlocked`);
      document.body.appendChild(toast);
      setTimeout(() => { try { toast.remove(); } catch (_) {} }, 2200);
    }
    if ((s.streak || 0) >= 2) {
      questionEl.appendChild(el("div", { class: "wrap", style: "margin-top:0.35rem;" }, [
        el("span", { class: "anim-heartbeat" }, "🔥"),
        el("span", {}, ` ${s.streak}-day streak`)
      ]));
    }
    diagramCanvas.style.display = "none";
    answerInput.style.display = "none";
    checkBtn.style.display = "none";
    nextBtn.style.display = "none";
    hintEl.textContent = rec;
    resultEl.textContent = `${MASCOT_NAME}: ${accuracy >= 0.7 ? mascotLine("goal") : mascotLine("idle")}`;
    resultEl.className = "wrap practice-result anim-fade";
    statusEl.textContent = `Streak ${s.streak || 0} day${(s.streak || 0) === 1 ? "" : "s"}`;
    setProgress(count);

    if (newlyUnlocked.length) {
      container.appendChild(el("div", { class: "card anim-star anim-flip", style: "font-weight:700;" },
        `🏆 New badge${newlyUnlocked.length > 1 ? "s" : ""}\n` +
        newlyUnlocked.map((a) => `${a.icon} ${a.name} — ${a.desc}`).join("\n")));
    }
    container.appendChild(el("button", { class: "btn btn-glow", onClick: () => app.showHome() }, "Back to Home"));
    container.appendChild(el("button", { class: "btn-secondary", onClick: () => app.showPractice() }, "Practice again"));
  }

  nextQuestion();
  return { title: "Practice", body: [container], onUnmount: () => timer.stop() };
}
