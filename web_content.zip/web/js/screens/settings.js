import { licenceDaysLeft, activateLicence, ACTIVATION_CODE, LICENCE_DAYS, OWNER } from "../app.js";
import { el, card, showAlert, showConfirm } from "../ui/widgets.js";
import { THEMES, FONT_SCALES } from "../theme.js";
import { exportStudent, importStudentText } from "../db.js";
import { setSfxEnabled, setMusicEnabled, startMusic, stopMusic } from "../engines/audioEngine.js";

export async function Settings(app) {
  let licenceLine = "";
  try {
    const d = licenceDaysLeft();
    licenceLine = d > 0
      ? `Licence active · ${d} day(s) left · ${OWNER}`
      : `Licence expired · enter activation code to renew (${LICENCE_DAYS} days)`;
  } catch { licenceLine = "Licence status unavailable"; }

  const settings = app.student.settings = app.student.settings || {};

  const nameInput = el("input", { type: "text", value: app.student.name || "", placeholder: "Student full name" });
  const programmeInput = el("input", { type: "text", value: app.student.programme_name || "The Elites Academy", placeholder: "Programme name" });
  function saveIdentity() {
    const n = nameInput.value.trim();
    const p = programmeInput.value.trim();
    if (n) app.student.name = n;
    if (p) app.student.programme_name = p;
    app.saveStudent();
    showAlert("Saved", "Name and programme updated.");
  }

  const themeSelect = el("select", {}, THEMES.map((t) => el("option", { value: t }, t)));
  themeSelect.value = settings.theme || "Candy";
  themeSelect.addEventListener("change", () => {
    settings.theme = themeSelect.value;
    app.applyThemeAndFont();
    app.saveStudent();
  });

  const fontSelect = el("select", {}, Object.keys(FONT_SCALES).map((f) => el("option", { value: f }, f)));
  fontSelect.value = settings.font_scale || "Normal";
  fontSelect.addEventListener("change", () => {
    settings.font_scale = fontSelect.value;
    app.applyThemeAndFont();
    app.saveStudent();
  });

  function check(v) {
    const c = el("input", { type: "checkbox" });
    c.checked = v;
    c.addEventListener("change", savePrefs);
    return c;
  }
  const hintsBox = check(settings.hints !== false);
  const soundBox = check(settings.sound !== false);
  const musicBox = check(settings.music === true);
  const animBox = check(settings.animations !== false);
  const mathKeyBox = check(settings.maths_keyboard === true);
  const autoExplainBox = check(settings.show_solutions !== false);
  const confirmResetBox = check(settings.confirm_reset !== false);
  const largeTargetBox = check(!!settings.large_targets);

  const diffSelect = el("select", {}, ["Foundation", "Standard", "Advanced", "Elite"].map((d) => el("option", { value: d }, d)));
  diffSelect.value = settings.difficulty_pref || "Standard";
  diffSelect.addEventListener("change", savePrefs);

  function savePrefs() {
    settings.hints = hintsBox.checked;
    settings.sound = soundBox.checked;
    settings.music = musicBox.checked;
    settings.animations = animBox.checked;
    settings.maths_keyboard = mathKeyBox.checked;
    settings.show_solutions = autoExplainBox.checked;
    settings.confirm_reset = confirmResetBox.checked;
    settings.large_targets = largeTargetBox.checked;
    settings.difficulty_pref = diffSelect.value;
    try {
      setSfxEnabled(settings.sound);
      setMusicEnabled(settings.music);
      if (settings.music) startMusic(); else stopMusic();
    } catch (e) { /* ignore */ }
    try { app.applyThemeAndFont(); } catch (_) {}
    app.saveStudent();
  }

  const goalInput = el("input", { type: "number", min: "5", max: "100", value: String(app.student.daily_goal ?? 20) });
  function saveGoal() {
    app.student.daily_goal = parseInt(goalInput.value, 10) || 20;
    app.saveStudent();
    showAlert("Saved", "Daily goal updated.");
  }

  function exportData() {
    exportStudent(app.student);
    showAlert("Export complete", "Your Learnly backup has been downloaded.");
  }

  const fileInput = el("input", { type: "file", accept: "application/json", style: "display:none" });
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0];
    if (!file) return;
    const text = await file.text();
    const result = importStudentText(text, app.student);
    if (!result.imported && result.reason === "older_or_same") {
      await showAlert("Import Skipped", "The imported profile is older than or the same age as your current data.");
    } else if (!result.imported) {
      await showAlert("Import Error", result.error || "Could not read that file.");
    } else {
      await showAlert("Import Complete", "Newer student data imported successfully.");
      app.showSettings();
    }
    fileInput.value = "";
  });
  function importData() { fileInput.click(); }

  async function resetData() {
    if (confirmResetBox.checked) {
      const ok = await showConfirm("Confirm Reset", "This will reset today's progress and streak. Mastery history is kept. Continue?");
      if (!ok) return;
    }
    app.student.today_done = 0;
    app.student.streak = 0;
    app.saveStudent();
    showAlert("Reset Complete", "Today's progress has been reset.");
  }

  return {
    title: "Settings",
    body: [
      el("div", { class: "card" }, [
        el("div", { class: "role-heading" }, "Licence · The Elites Academy"),
        el("div", { class: "role-subtitle wrap" }, licenceLine),
        el("button", { class: "btn", style: "margin-top:0.5rem;", onClick: () => {
          const code = prompt("Activation code from The Elites Academy:");
          if (!code) return;
          if (code.trim().toLowerCase() === String(ACTIVATION_CODE).toLowerCase()) {
            const until = activateLicence(LICENCE_DAYS);
            showAlert("Licence renewed", "Valid until " + until.toLocaleDateString());
            app.showSettings();
          } else {
            showAlert("Invalid code", "Contact The Elites Academy for activation.");
          }
        }}, "Renew / activate")
      ]),

      el("div", { class: "section-eyebrow" }, "YOUR NAME"),
      el("label", { class: "field-label" }, "Learner name"), nameInput,
      el("label", { class: "field-label" }, "Programme"), programmeInput,
      el("button", { class: "btn", onClick: saveIdentity }, "Save name"),

      el("div", { class: "section-eyebrow" }, "GRADE"),
      el("div", { class: "role-subtitle wrap" }, "This build is Grade 10 · Mathematical Literacy, Business Studies and Tourism."),

      el("div", { class: "section-eyebrow" }, "DISPLAY — THEME"), themeSelect,
      el("div", { class: "section-eyebrow" }, "DISPLAY — FONT SIZE"), fontSelect,

      el("div", { class: "section-eyebrow" }, "ACCESSIBILITY"),
      el("label", { class: "checkline" }, [largeTargetBox, "Larger tap targets"]),
      el("div", { class: "role-muted wrap", style: "font-size:0.82rem;margin-bottom:0.5rem;" },
        "High Contrast is available in the theme list. Font size scales the whole interface."),

      el("div", { class: "section-eyebrow" }, "INSTALL & OFFLINE"),
      card("Install checklist", "Add to Home Screen, offline cache status, and tips for exam mode.", [
        { label: "OPEN", onClick: () => app.navigate("installGuide") }
      ]),
      card("ATP term planner", "Term 1–4 CAPS checklist linked to topics and papers.", [
        { label: "OPEN", onClick: () => app.navigate("atpPlanner") }
      ]),

      el("div", { class: "section-eyebrow" }, "LEARNING PREFERENCES"),
      el("label", { class: "checkline" }, [hintsBox, "Smart hints during practice"]),
      el("label", { class: "checkline" }, [mathKeyBox, "Maths number keyboard"]),
      el("label", { class: "checkline" }, [soundBox, "Sound effects"]),
      el("label", { class: "checkline" }, [musicBox, "Background music"]),
      el("label", { class: "checkline" }, [animBox, "Animations"]),
      el("label", { class: "checkline" }, [autoExplainBox, "Auto-show explanations after answering"]),
      el("label", { class: "checkline" }, [confirmResetBox, "Confirm before resetting data"]),

      el("div", { class: "section-eyebrow" }, "DIFFICULTY PREFERENCE"), diffSelect,

      el("div", { class: "section-eyebrow" }, "DAILY GOAL (problems)"), goalInput,
      el("button", { class: "btn", onClick: saveGoal }, "Save daily goal"),

      el("div", { class: "section-eyebrow" }, "DATA"),
      card("Export student data", "Save a portable JSON backup of your profile.", [{ label: "EXPORT", onClick: exportData }]),
      card("Import student data", "Load a profile export (newer data always wins).", [{ label: "IMPORT", onClick: importData }]),
      fileInput,
      card("Reset local data", "Clear today's progress and streak for this profile.", [{ label: "RESET", onClick: resetData }]),

      el("div", { class: "section-eyebrow" }, "REFERENCE"),
      card("Formula sheets & periodic table", "Maths, Physical Sciences, Life Sciences and Accounting formula cards.", [
        { label: "OPEN", onClick: () => app.navigate("referenceSheets", { subjectId: app.student?.subject }) }
      ]),

      el("div", { class: "section-eyebrow" }, "ABOUT"),
      card("Learnly Grade 10 · Beta",
        "Invite-only Grade 10 build · Mathematical Literacy, Business Studies, Tourism.\nOwned by The Elites Academy.\nBuild: g10-ml-v27-beta · offline-first PWA."),

      el("button", { class: "btn-secondary", onClick: () => app.logout() }, "Sign out on this device")
    ]
  };
}
