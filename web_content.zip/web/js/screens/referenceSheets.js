/**
 * Reference sheets: periodic table + subject formula cards.
 */
import { el, card } from "../ui/widgets.js";
import {
  formulaSheetFor,
  allFormulaSubjects,
  drawPeriodicTable,
  drawFormulaSheet
} from "../engines/referenceEngine.js";
import { subjectLabel } from "../engines/subjectRegistry.js";

function paintCanvas(canvas, drawFn, w, h) {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + "px";
  canvas.style.height = h + "px";
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  drawFn(ctx, w, h);
}

export async function ReferenceSheets(app, params = {}) {
  const focus = params.subjectId || app.student?.subject || "maths";
  const subjects = allFormulaSubjects();

  const body = [
    el("button", { class: "btn-secondary", onClick: () => app.goBack() }, "← Back"),
    el("div", { class: "role-subtitle wrap" },
      "Offline CAPS-oriented formula sheets and a compact periodic table. Use these while practising.")
  ];

  // Periodic table
  body.push(el("div", { class: "section-eyebrow" }, "PERIODIC TABLE"));
  const ptHost = el("div", {
    style: "width:100%;max-width:520px;margin:0.35rem auto;border:1px solid var(--hairline);border-radius:0.75rem;overflow:hidden;background:#fff;"
  });
  const ptCanvas = el("canvas");
  ptHost.appendChild(ptCanvas);
  body.push(el("div", { class: "card" }, [
    el("div", { class: "role-heading" }, "Periodic table"),
    el("div", { class: "role-muted" }, "Symbols and atomic numbers · colour by family"),
    ptHost
  ]));
  requestAnimationFrame(() => {
    try { paintCanvas(ptCanvas, drawPeriodicTable, 520, 280); } catch (e) { console.warn(e); }
  });

  // Formula sheets — current subject first, then the rest
  body.push(el("div", { class: "section-eyebrow" }, "FORMULA SHEETS (CURRENT SUBJECT FIRST)"));

  const ordered = [...subjects].sort((a, b) => {
    const af = (a === focus || (focus === "natural_sciences_technology" && a === "natural_sciences")) ? 0 : 1;
    const bf = (b === focus || (focus === "natural_sciences_technology" && b === "natural_sciences")) ? 0 : 1;
    return af - bf;
  });

  ordered.forEach((sid) => {
    const sheet = formulaSheetFor(sid);
    const isFocus = sid === focus || (focus === "natural_sciences_technology" && sid === "natural_sciences");
    const host = el("div", {
      style: "width:100%;max-width:480px;margin:0.25rem auto;border:1px solid var(--hairline);border-radius:0.75rem;overflow:hidden;background:#fff;"
    });
    const cv = el("canvas");
    host.appendChild(cv);
    body.push(el("div", { class: "card" + (isFocus ? " card-highlight" : "") }, [
      el("div", { class: "role-heading" }, (isFocus ? "★ " : "") + sheet.title),
      el("div", { class: "role-muted" }, (isFocus ? "Aligned to your current subject · " : "") + (subjectLabel(sid) || sid)),
      host
    ]));
    requestAnimationFrame(() => {
      try { paintCanvas(cv, (ctx, w, h) => drawFormulaSheet(ctx, w, h, sid), 480, 220); } catch (e) { console.warn(e); }
    });
  });

  // Text fallback list for accessibility / copy
  body.push(el("div", { class: "section-eyebrow" }, "TEXT VIEW — CURRENT SUBJECT"));
  const current = formulaSheetFor(focus);
  current.sections.forEach((sec) => {
    body.push(card(sec.heading, sec.items.map((i) => "• " + i).join("\n")));
  });

  return { title: "📐 Formula sheets", bottomNavKey: "home", body };
}
