import { el, card, progressBar, showAlert } from "../ui/widgets.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { EconomyEngine } from "../engines/economyEngine.js";

export async function Achievements(app) {
  const ge = new GamificationEngine(app.student);
  ge.checkNewUnlocks();
  app.saveStudent();
  const econ = new EconomyEngine(app.student);
  const [have, visible, totalAll] = ge.progressSummary();

  const body = [
    card("Badges", `${have} / ${visible} shown · ${totalAll} in game\nLevel ${app.student.level || 1} · ${econ.balance()} stars`),
    progressBar(have, Math.max(1, visible), `${have}/${visible}`),
    el("div", { class: "role-muted wrap" }, "More badges unlock as your level grows.")
  ];
  ge.allWithStatus().forEach((a) => {
    body.push(el("div", { class: "card" }, [
      el("div", { class: "role-heading wrap", style: a.unlocked ? "" : "opacity:0.5;" },
        `${a.icon} ${a.name}${a.unlocked ? "" : " 🔒"}`),
      el("div", { class: "role-subtitle wrap" }, a.desc)
    ]));
  });
  body.push(el("button", { class: "btn", onClick: () => app.showRewards() }, "Shop"));
  return { title: "Badges", bottomNavKey: "profile", body };
}

export async function Economy(app) {
  const econ = new EconomyEngine(app.student);
  const history = econ.history(20);
  const body = [
    card("Stars", `${econ.balance()}`),
    ...(history.length ? history.map((tx) => el("div", { class: "card" }, [
      el("div", { class: "wrap" }, `${tx.amount >= 0 ? "+" : ""}${tx.amount} — ${tx.reason}`)
    ])) : [card("Empty", "Practice to earn stars.")]),
    el("button", { class: "btn", onClick: () => app.showRewards() }, "Shop")
  ];
  return { title: "Stars", bottomNavKey: "profile", body };
}

export async function Rewards(app) {
  const ge = new GamificationEngine(app.student);
  const econ = new EconomyEngine(app.student);
  const items = ge.shopItems();
  const boostOn = !!(app.student.flags?.double_star_active &&
    (!app.student.flags.double_star_until || Date.now() < app.student.flags.double_star_until));
  const freeze = app.student.flags?.streak_freeze || 0;
  const shield = app.student.flags?.combo_shield || 0;
  const body = [
    card(
      "Shop",
      `${econ.balance()} ★ · Level ${app.student.level || 1}` +
        (boostOn ? " · 2× stars active" : "") +
        (freeze ? ` · 🧊×${freeze}` : "") +
        (shield ? ` · 🛡️×${shield}` : "")
    ),
    el("div", { class: "role-muted wrap" },
      "Earn stars from practice, quizzes, papers and lessons. Buy themes, boosts and titles — tap USE to equip.")
  ];

  async function buyOrUse(item) {
    if (item.owned) {
      ge.equip(item.id);
      app.saveStudent();
      app.showRewards();
      return;
    }
    const res = ge.buy(item.id);
    if (!res.ok) {
      const msg = res.reason === "funds" ? "Not enough stars." : res.reason === "level" ? "Level too low." : "Could not buy.";
      showAlert("Shop", msg);
      return;
    }
    ge.equip(item.id);
    app.saveStudent();
    app.showRewards();
  }

  const groups = [
    { key: "theme", title: "🎨 Themes" },
    { key: "ui", title: "✨ UI upgrades" },
    { key: "frame", title: "🖼️ Frames" },
    { key: "title", title: "🏷️ Titles" },
    { key: "boost", title: "⚡ Boosts" },
    { key: "pack", title: "📦 Packs" }
  ];

  const used = new Set();
  for (const g of groups) {
    const list = items.filter((it) => (it.kind || (it.theme ? "theme" : "pack")) === g.key);
    if (!list.length) continue;
    body.push(el("div", { class: "section-eyebrow", style: "margin-top:0.75rem;" }, g.title));
    list.forEach((item) => {
      used.add(item.id);
      const status = item.owned
        ? (app.student.active_reward === item.id ? "Equipped" : "Owned — tap to use")
        : item.desc || "";
      body.push(card(
        `${item.icon || "🎁"} ${item.name}`,
        status + (item.owned ? "" : `\n${item.cost} stars · Lv ${item.minLevel || 1}+`),
        [{ label: item.owned ? (app.student.active_reward === item.id ? "ON" : "USE") : `${item.cost} ★`, onClick: () => buyOrUse(item) }]
      ));
    });
  }
  const rest = items.filter((it) => !used.has(it.id));
  if (rest.length) {
    body.push(el("div", { class: "section-eyebrow", style: "margin-top:0.75rem;" }, "More"));
    rest.forEach((item) => {
      body.push(card(
        `${item.icon || "🎁"} ${item.name}`,
        item.owned ? "Owned" : `${item.desc || ""}\n${item.cost} stars`,
        [{ label: item.owned ? "USE" : `${item.cost} ★`, onClick: () => buyOrUse(item) }]
      ));
    });
  }

  return { title: "Shop", bottomNavKey: "profile", body };
}


export async function DevMode(app) {
  const econ = new EconomyEngine(app.student);
  const body = [
    card("Dev mode", "Tools for testing. Not for learners."),
    card("Stars", `${econ.balance()}`, [
      { label: "+100", onClick: () => { econ.devAdd(100); app.saveStudent(); app.navigate("devMode"); } },
      { label: "+500", onClick: () => { econ.devAdd(500); app.saveStudent(); app.navigate("devMode"); } },
      { label: "Set 2000", onClick: () => { econ.devSetBalance(2000); app.saveStudent(); app.navigate("devMode"); } }
    ]),
    card("Reset stars", "Clear balance and transactions.", [
      { label: "RESET", onClick: () => { econ.devReset(); app.saveStudent(); app.navigate("devMode"); } }
    ]),
    el("button", { class: "btn-secondary", onClick: () => app.showProfile() }, "← Profile")
  ];
  return { title: "Dev", bottomNavKey: "profile", body };
}
