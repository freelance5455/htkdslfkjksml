import { el, card, showAlert } from "../ui/widgets.js";
import { getLesson, listLessonsForSubject } from "../engines/learningCards.js";
import { subjectLabel, loadSubjectRegistry } from "../engines/subjectRegistry.js";
import { MultiSubjectEngine } from "../engines/multiSubjectEngine.js";
import { EconomyEngine, touchCalendarStreak } from "../engines/economyEngine.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { mascotCard, mascotLine, MASCOT_NAME, mascotSvg } from "../engines/mascotEngine.js";
import { emptyState } from "../ui/visualPolish.js";

/**
 * Learning card flow: plain intro → step-by-step teaching → retention check.
 * Animated step transitions, progress, Kepi coaching, celebrate on finish.
 */
export async function LearningCardHub(app) {
  await loadSubjectRegistry();
  const sid = app.student?.subject || "mathematical_literacy";
  const lessons = listLessonsForSubject(sid);
  const body = [
    mascotCard(el, {
      mood: "idle",
      line: lessons.length
        ? "Pick a card. I’ll walk you through it step by step."
        : "Cards for this subject are still on the way.",
      size: "64px"
    }),
    el("div", { class: "role-subtitle wrap" },
      "Short lessons in everyday language. Each card teaches one idea, then checks what you remember."),
    el("div", { class: "section-eyebrow" }, subjectLabel(sid) || sid)
  ];
  if (!lessons.length) {
    body.push(emptyState(el, {
      title: "Cards on the way",
      body: "Learning cards for this subject are being added. Try a short quiz meanwhile.",
      ctaLabel: "Open subject hub",
      onCta: () => app.showSubjectHub(),
      mood: "nudge"
    }));
  } else {
    lessons.forEach((L, i) => {
      const tile = card("📖 " + L.title, L.plain.slice(0, 120) + (L.plain.length > 120 ? "…" : ""), [
        { label: "LEARN", onClick: () => app.navigate("learningCard", { topicId: L.id }) }
      ]);
      tile.style.animationDelay = `${0.04 + i * 0.04}s`;
      tile.classList.add("anim-rise");
      body.push(tile);
    });
  }
  body.push(el("button", { class: "btn-secondary", onClick: () => app.showSubjectHub() }, "← Topics"));
  return { title: "Learning cards", bottomNavKey: "learn", body };
}

export async function LearningCard(app, { topicId } = {}) {
  const lesson = getLesson(topicId);
  if (!lesson) {
    return {
      title: "Learning card",
      body: [
        el("div", { class: "wrap" }, "Lesson not found."),
        el("button", { class: "btn-secondary", onClick: () => app.navigate("learningCardHub") }, "← Back")
      ]
    };
  }

  let phase = "teach"; // teach | check | done
  let step = 0;
  let checkIdx = 0;
  let score = 0;
  let answered = 0;
  let stepKey = 0; // force re-animate on each step

  const host = el("div", { class: "learning-card-host" });

  function stepProgress() {
    const n = lesson.steps.length;
    const pct = Math.round(((step + 1) / n) * 100);
    const bar = el("div", { class: "lc-progress" }, [
      el("div", { class: "lc-progress-fill", style: `width:${pct}%` })
    ]);
    const label = el("div", {
      class: "lc-progress-label"
    }, `Step ${step + 1} of ${n}`);
    return el("div", { class: "lc-progress-wrap anim-fade" }, [label, bar]);
  }

  function checkProgress() {
    const items = lesson.check || [];
    const n = items.length || 1;
    const pct = Math.round((checkIdx / n) * 100);
    return el("div", { class: "lc-progress-wrap anim-fade" }, [
      el("div", { class: "lc-progress-label" }, `Check ${Math.min(checkIdx + 1, n)} of ${n}`),
      el("div", { class: "lc-progress" }, [
        el("div", { class: "lc-progress-fill", style: `width:${pct}%` })
      ])
    ]);
  }

  function burstCelebrate() {
    const layer = el("div", { class: "lc-burst", "aria-hidden": "true" });
    const colors = ["#F5C542", "#34D399", "#7B93FF", "#FB7185", "#C45CFF", "#E67E22"];
    for (let i = 0; i < 18; i++) {
      const p = el("span", { class: "lc-particle" });
      const angle = (i / 18) * Math.PI * 2;
      const dist = 48 + (i % 5) * 14;
      p.style.setProperty("--dx", `${Math.cos(angle) * dist}px`);
      p.style.setProperty("--dy", `${Math.sin(angle) * dist - 20}px`);
      p.style.background = colors[i % colors.length];
      p.style.animationDelay = `${(i % 6) * 0.03}s`;
      layer.appendChild(p);
    }
    host.appendChild(layer);
    setTimeout(() => layer.remove(), 900);
  }

  function render() {
    host.innerHTML = "";
    stepKey += 1;

    if (phase === "teach") {
      host.appendChild(stepProgress());

      const stepCard = el("div", {
        class: "card lc-step-card anim-step",
        style: "border-left:4px solid var(--accent);"
      }, [
        el("div", { class: "role-heading" }, lesson.title),
        step === 0
          ? el("div", { class: "wrap lc-plain", style: "margin:0.4rem 0 0.6rem;opacity:0.9;" }, lesson.plain)
          : null,
        el("div", {
          class: "wrap lc-step-text",
          style: "white-space:pre-wrap;line-height:1.55;font-size:1.02rem;"
        }, lesson.steps[step])
      ].filter(Boolean));
      host.appendChild(stepCard);

      if (step === 0 && lesson.terms?.length) {
        const terms = card("Words to know",
          lesson.terms.map(([w, d]) => `• ${w} — ${d}`).join("\n"));
        terms.classList.add("anim-rise");
        host.appendChild(terms);
      }

      if (lesson.example && step === Math.min(1, lesson.steps.length - 1)) {
        const ex = card("Worked example", lesson.example);
        ex.classList.add("anim-rise");
        host.appendChild(ex);
      }

      if (lesson.mistakes?.length && step === Math.max(0, lesson.steps.length - 2)) {
        const m = card("Avoid these mistakes",
          lesson.mistakes.map((x) => `• ${x}`).join("\n"));
        m.classList.add("anim-rise");
        host.appendChild(m);
      }

      if (lesson.caps_tip && step === lesson.steps.length - 1) {
        const tip = card("Exam tip", lesson.caps_tip);
        tip.classList.add("anim-rise");
        host.appendChild(tip);
      }

      if (step === Math.floor(lesson.steps.length / 2)) {
        host.appendChild(mascotCard(el, {
          mood: "think",
          line: mascotLine("idle"),
          size: "56px",
          compact: true
        }));
      }

      const nav = el("div", { class: "btn-row lc-nav anim-fade", style: "margin-top:0.75rem;gap:0.4rem;flex-wrap:wrap;" });
      if (step > 0) {
        nav.appendChild(el("button", {
          class: "btn-secondary",
          onClick: () => { step -= 1; render(); }
        }, "← Back"));
      }
      if (step < lesson.steps.length - 1) {
        nav.appendChild(el("button", {
          class: "btn",
          onClick: () => { step += 1; render(); }
        }, "Next →"));
      } else {
        nav.appendChild(el("button", {
          class: "btn anim-pulse",
          style: "background:linear-gradient(135deg,#0d9488,#059669);border:none;",
          onClick: () => { phase = "check"; checkIdx = 0; score = 0; answered = 0; render(); }
        }, "Check what I remember"));
      }
      host.appendChild(nav);
      return;
    }

    if (phase === "check") {
      const items = lesson.check || [];
      if (!items.length || checkIdx >= items.length) {
        phase = "done";
        render();
        return;
      }
      const item = items[checkIdx];
      host.appendChild(checkProgress());
      host.appendChild(el("div", { class: "card anim-step" }, [
        el("div", { class: "wrap", style: "font-weight:650;line-height:1.45;" }, item.q)
      ]));
      const input = el("input", {
        type: "text",
        placeholder: "Your answer",
        class: "quiz-input",
        style: "width:100%;margin-top:0.5rem;"
      });
      const feedback = el("div", { class: "wrap", style: "margin-top:0.45rem;min-height:1.2rem;font-weight:600;" }, "");
      const submit = () => {
        if (input.disabled) return;
        const raw = (input.value || "").trim();
        if (!raw) return;
        input.disabled = true;
        answered += 1;
        const ok = softMatch(raw, item.a);
        if (ok) {
          score += 1;
          feedback.textContent = `Correct — ${MASCOT_NAME}: ${mascotLine("correct")}`;
          feedback.className = "wrap quiz-feedback-ok anim-success";
          input.classList.add("quiz-input-correct", "anim-success");
        } else {
          feedback.textContent = `Not quite. Expected: ${item.a}` + (item.hint ? ` · Hint: ${item.hint}` : "") +
            ` · ${MASCOT_NAME}: ${mascotLine("wrong")}`;
          feedback.className = "wrap quiz-feedback-bad anim-error";
          input.classList.add("quiz-input-wrong", "anim-error");
        }
        setTimeout(() => {
          checkIdx += 1;
          render();
        }, 1000);
      };
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });
      host.appendChild(input);
      host.appendChild(el("button", { class: "btn", style: "margin-top:0.55rem;", onClick: submit }, "Check"));
      host.appendChild(feedback);
      if (item.hint) {
        host.appendChild(el("div", { class: "role-muted wrap anim-fade", style: "margin-top:0.35rem;font-size:0.85rem;" },
          "Hint shows after you answer."));
      }
      setTimeout(() => input.focus(), 60);
      return;
    }

    // done
    const total = (lesson.check || []).length || 1;
    const pct = Math.round((score / total) * 100);
    try {
      const econ = new EconomyEngine(app.student);
      if (pct >= 70) econ.earn("learning_card_strong", "Learning card · strong recall");
      else if (score > 0) econ.earn("learning_card", "Learning card");
      app.student.mastery = app.student.mastery || {};
      const prev = app.student.mastery[topicId] ?? 0.35;
      app.student.mastery[topicId] = Math.min(1, prev + 0.05 + (pct / 100) * 0.1);
      app.student.xp = (app.student.xp || 0) + (pct >= 70 ? 18 : 8);
      app.student.flags = app.student.flags || {};
      app.student.flags.learning_card_done = true;
      app.student.today_done = (app.student.today_done || 0) + 1;
      try { touchCalendarStreak(app.student); } catch { /* optional */ }
      try { new GamificationEngine(app.student).checkNewUnlocks(); } catch { /* optional */ }
      app.saveStudent();
    } catch { /* ignore */ }

    const celebrate = pct >= 70;
    const doneCard = el("div", {
      class: "card anim-pop",
      style: "text-align:center;padding:1.35rem;position:relative;overflow:hidden;"
    }, [
      el("div", {
        style: "display:flex;justify-content:center;margin-bottom:0.35rem;line-height:0;"
      }),
      el("div", { class: "role-heading", style: "margin-top:0.25rem;" },
        celebrate ? "Lesson complete — well done" : "Lesson complete"),
      el("div", { class: "wrap", style: "margin-top:0.35rem;" },
        `You got ${score} of ${total} on the retention check (${pct}%).`),
      el("div", { class: "role-muted wrap", style: "margin-top:0.35rem;" },
        celebrate
          ? "Strong recall — try a practice session next."
          : "Re-read the steps, then try the check again.")
    ]);
    const fig = doneCard.querySelector("div");
    if (fig) {
      fig.innerHTML = mascotSvg(celebrate ? "celebrate" : "nudge", "80px");
      fig.classList.add(celebrate ? "anim-star" : "anim-pop");
    }
    host.appendChild(doneCard);
    host.appendChild(mascotCard(el, {
      mood: celebrate ? "celebrate" : "nudge",
      line: celebrate ? mascotLine("goal") : "Revise once more — then we try again.",
      size: "56px",
      compact: true
    }));
    if (celebrate) {
      setTimeout(burstCelebrate, 80);
    }

    host.appendChild(el("div", { class: "btn-row anim-fade", style: "margin-top:0.75rem;gap:0.4rem;flex-wrap:wrap;" }, [
      el("button", {
        class: "btn",
        onClick: () => app.navigate("practiceSetup", { mode: "choose", topics: [topicId] })
      }, "Practise this topic"),
      el("button", {
        class: "btn-secondary",
        onClick: () => { phase = "teach"; step = 0; render(); }
      }, "Revise lesson"),
      el("button", {
        class: "btn-secondary",
        onClick: () => app.navigate("learningCardHub")
      }, "More cards")
    ]));
  }

  function softMatch(user, expected) {
    const u = String(user).toLowerCase().replace(/,/g, ".").replace(/\s+/g, " ").trim();
    const options = String(expected).toLowerCase().split("/").map((s) => s.trim());
    return options.some((e) => {
      if (!e) return false;
      if (u === e) return true;
      if (e.includes(u) && u.length >= 2) return true;
      if (u.includes(e) && e.length >= 3) return true;
      const nu = parseFloat(u.replace(/[^\d.-]/g, ""));
      const ne = parseFloat(e.replace(/[^\d.-]/g, ""));
      if (Number.isFinite(nu) && Number.isFinite(ne) && Math.abs(nu - ne) < 0.05) return true;
      return false;
    });
  }

  render();
  return {
    title: "📖 " + lesson.title,
    bottomNavKey: "learn",
    body: [
      el("button", { class: "btn-secondary", onClick: () => app.navigate("learningCardHub") }, "← Learning cards"),
      host
    ]
  };
}
