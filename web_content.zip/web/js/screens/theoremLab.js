import { el, card, showAlert } from "../ui/widgets.js";
import { TheoremEngine } from "../engines/theoremEngine.js";

/**
 * Theorem Workshop — simple, friendly practice for CAPS formulae.
 * Primary mode: tap the correct answer for each blank (no drag complexity).
 */
export async function TheoremLab(app) {
  const grade = app.student?.grade ?? 12;
  const engine = new TheoremEngine(grade);
  const isPS = app.student?.subject === "physical_sciences";
  let theorems = engine.list();
  if (isPS) theorems = theorems.filter((th) => String(th.topic || "").startsWith("ps_"));
  else theorems = theorems.filter((th) => !String(th.topic || "").startsWith("ps_"));

  // Prefer Euclidean + core maths when on maths
  const euclid = theorems.filter((t) => t.topic === "euclidean_geometry");
  const other = theorems.filter((t) => t.topic !== "euclidean_geometry");

  function cardFor(t) {
    return card(
      t.name,
      t.formula,
      [{ label: "PRACTISE", onClick: () => app.navigate("theoremRound", { theoremId: t.id, mode: "tap" }) }]
    );
  }

  const body = [
    el("div", { class: "wrap role-muted", style: "margin-bottom:0.5rem;" },
      "Pick a theorem. Tap the correct option for each blank — short and clear."),
    el("button", {
      class: "btn",
      onClick: () => app.navigate("theoremRound", { theoremId: null, mode: "tap" })
    }, "Random practice"),
  ];

  if (euclid.length) {
    body.push(el("div", { class: "section-eyebrow" }, "EUCLIDEAN GEOMETRY"));
    euclid.forEach((t) => body.push(cardFor(t)));
  }
  if (other.length) {
    body.push(el("div", { class: "section-eyebrow" }, "OTHER FORMULAE"));
    other.forEach((t) => body.push(cardFor(t)));
  }

  return { title: "Theorem Workshop", bottomNavKey: "learn", body };
}

export async function TheoremRound(app, { theoremId = null, mode = "tap" } = {}) {
  const engine = new TheoremEngine(app.student?.grade ?? 12);
  // Always use drag-round data shape (slots + options) for the simple tap UI
  const round = engine.buildDragRound(theoremId);
  if (!round || !round.slots || !round.slots.length) {
    return {
      title: "Theorem practice",
      body: [card("Unavailable", "No theorem data for this selection."),
        el("button", { class: "btn", onClick: () => app.navigate("theoremLab") }, "Back to list")]
    };
  }

  let score = 0;
  let done = 0;
  const total = round.slots.length;
  const status = el("div", {
    class: "role-subtitle wrap",
    style: "margin:0.35rem 0 0.75rem;"
  }, `Question 1 of ${total} · Tap the correct answer`);

  const promptEl = el("div", { class: "role-heading wrap", style: "margin-bottom:0.5rem;" }, "");
  const optionsWrap = el("div", { style: "display:flex;flex-direction:column;gap:0.45rem;" });
  const explainEl = el("div", { class: "card", style: "display:none;" }, []);

  let idx = 0;
  const slots = round.slots.slice();

  function showSlot() {
    if (idx >= slots.length) {
      promptEl.textContent = "Done";
      optionsWrap.innerHTML = "";
      status.textContent = `Score ${score}/${total * 10}`;
      explainEl.style.display = "";
      explainEl.innerHTML = "";
      explainEl.appendChild(el("div", { class: "role-heading" }, "Quick recap"));
      explainEl.appendChild(el("div", { class: "wrap", style: "white-space:pre-wrap;" },
        (round.explanation && (round.explanation.formula || round.explanation.steps?.join("\n"))) ||
        round.formula || "Well done."));
      optionsWrap.appendChild(el("button", {
        class: "btn",
        onClick: () => app.navigate("theoremRound", { theoremId: round.id || theoremId, mode: "tap" })
      }, "Practise again"));
      optionsWrap.appendChild(el("button", {
        class: "btn-secondary",
        onClick: () => app.navigate("theoremLab")
      }, "Back to theorems"));
      return;
    }
    const slot = slots[idx];
    status.textContent = `Question ${idx + 1} of ${total} · Tap the correct answer`;
    promptEl.textContent = slot.prompt || "Complete the statement";
    optionsWrap.innerHTML = "";
    const opts = (slot.options && slot.options.length)
      ? slot.options.slice()
      : [slot.answer, "Not sure", "Skip"];
    // shuffle
    for (let i = opts.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [opts[i], opts[j]] = [opts[j], opts[i]];
    }
    opts.forEach((opt) => {
      optionsWrap.appendChild(el("button", {
        class: "btn-secondary",
        style: "text-align:left;width:100%;",
        onClick: () => {
          const ok = String(opt) === String(slot.answer);
          if (ok) {
            score += 10;
            done++;
            status.textContent = "Correct";
          } else {
            status.textContent = `Not quite — answer: ${slot.answer}`;
          }
          idx++;
          setTimeout(showSlot, ok ? 350 : 900);
        }
      }, opt));
    });
  }

  showSlot();

  return {
    title: round.name || "Theorem practice",
    showBack: true,
    body: [
      card(round.name, round.formula),
      status,
      promptEl,
      optionsWrap,
      explainEl
    ]
  };
}
