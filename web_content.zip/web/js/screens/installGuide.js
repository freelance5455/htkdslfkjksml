import { el, card } from "../ui/widgets.js";

function isStandalone() {
  try {
    return window.matchMedia("(display-mode: standalone)").matches
      || window.navigator.standalone === true;
  } catch {
    return false;
  }
}

async function cacheStatus() {
  if (!("caches" in window)) return { ok: false, label: "Cache API not available" };
  try {
    const keys = await caches.keys();
    const learnly = keys.filter((k) => /learnly/i.test(k));
    if (!learnly.length) return { ok: false, label: "No Learnly cache yet — open the app online once" };
    return { ok: true, label: `Cached · ${learnly[learnly.length - 1]}` };
  } catch {
    return { ok: false, label: "Could not read cache status" };
  }
}

export async function InstallGuide(app) {
  const standalone = isStandalone();
  const cache = await cacheStatus();
  const online = typeof navigator !== "undefined" ? navigator.onLine : true;

  const body = [
    el("button", { class: "btn-secondary", onClick: () => app.showSettings() }, "← Settings"),
    el("div", { class: "role-subtitle wrap", style: "margin:0.35rem 0 0.75rem;" },
      "Install Learnly on your phone so it works offline in class or during revision."),

    card("Status", [
      el("div", { class: "install-check-item" }, [
        el("span", { class: "ic-mark" }, standalone ? "✅" : "⬜"),
        el("span", {}, standalone ? "Running as installed app" : "Still in the browser — add to Home Screen")
      ]),
      el("div", { class: "install-check-item" }, [
        el("span", { class: "ic-mark" }, cache.ok ? "✅" : "⬜"),
        el("span", {}, cache.label)
      ]),
      el("div", { class: "install-check-item" }, [
        el("span", { class: "ic-mark" }, online ? "🌐" : "📴"),
        el("span", {}, online ? "Currently online" : "Currently offline")
      ])
    ].map((n) => n)),

    el("div", { class: "section-eyebrow" }, "ADD TO HOME SCREEN"),
    card("iPhone / iPad (Safari)",
      "1. Open Learnly in Safari.\n2. Tap Share → Add to Home Screen.\n3. Open the icon from your home screen (not a Safari tab)."),
    card("Android (Chrome)",
      "1. Open Learnly in Chrome.\n2. Menu (⋮) → Install app or Add to Home screen.\n3. Confirm. Launch from the home screen icon."),

    el("div", { class: "section-eyebrow" }, "OFFLINE TIPS"),
    card("Before an exam block",
      "While online: open each subject once, open Papers → Past papers, and open a learning card. That warms the cache."),
    card("If content looks empty offline",
      "Reconnect briefly, refresh, then reopen the topic. The service worker stores pages after the first successful load."),

    el("button", {
      class: "btn",
      onClick: async () => {
        app.student.flags = app.student.flags || {};
        app.student.flags.install_guide_seen = true;
        app.saveStudent();
        app.showHome();
      }
    }, "Mark as done · Home")
  ];

  return { title: "Install & offline", bottomNavKey: "profile", body };
}
